import { n as __exportAll, r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=e9f94b2e";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-cNwuCTLA.js?v=e9f94b2e";
import { r as useIsoLayoutEffect } from "/node_modules/.vite/deps/formatErrorMessage-BEgQI17N.js?v=e9f94b2e";
import { M as CLICK_TRIGGER_IDENTIFIER, S as useDismiss, _ as usePopupRootSync, a as fastComponentRef, c as PopupHandleAttachment, d as createDefaultInitialFocus, dt as closed$3, f as createPopupOpenState, ft as endingStyle$3, g as usePopupRootStore, h as usePopupInteractionProps, ht as startingStyle$3, it as popupTransitionStateMapping, k as FloatingPortal, m as useOpenStateTransitions, n as ReactStore, o as PopupTriggerMap, ot as triggerOpenStateMapping, p as useImplicitActiveTrigger, pt as open$3, rt as popupStateMapping, s as FOCUSABLE_POPUP_PROPS, v as useTriggerDataForwarding } from "/node_modules/.vite/deps/FloatingRootStore-BMBEPfxq.js?v=e9f94b2e";
import { t as inertValue } from "/node_modules/.vite/deps/inertValue-DbKApsSW.js?v=e9f94b2e";
import { n as useRenderElement } from "/node_modules/.vite/deps/useRenderElement-CvMw8z9e.js?v=e9f94b2e";
import { a as transitionStatusMapping, t as useOpenChangeComplete } from "/node_modules/.vite/deps/useOpenChangeComplete-BJDlY1Cs.js?v=e9f94b2e";
import { a as useClick, c as useScrollLock, i as InternalBackdrop, n as useOpenMethodTriggerProps, o as FloatingFocusManager } from "/node_modules/.vite/deps/useOpenInteractionType-DACsa5HR.js?v=e9f94b2e";
import { d as getTarget, u as contains } from "/node_modules/.vite/deps/composite-DUPI88po.js?v=e9f94b2e";
import { r as closePress, s as imperativeAction, w as createChangeEventDetails } from "/node_modules/.vite/deps/reason-parts-D-IkPsXA.js?v=e9f94b2e";
import { t as useBaseUiId } from "/node_modules/.vite/deps/useBaseUiId-UM7l9pLZ.js?v=e9f94b2e";
import { a as BasePopupHandle, i as popupStoreSelectors, n as usePopupHandleStore, r as createInitialPopupStoreState, t as NullStore } from "/node_modules/.vite/deps/NullStore-CE4rtHXf.js?v=e9f94b2e";
import { t as useButton } from "/node_modules/.vite/deps/useButton-DC28DUmR.js?v=e9f94b2e";
import { a as COMPOSITE_KEYS } from "/node_modules/.vite/deps/composite-BSvBzXai.js?v=e9f94b2e";
// node_modules/@base-ui/react/dialog/root/useDialogRoot.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function DialogInteractions({ store, parentContext, isDrawer }) {
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const disablePointerDismissal = store.useState("disablePointerDismissal");
	const modal = store.useState("modal");
	const popupElement = store.useState("popupElement");
	const floatingRootContext = store.useState("floatingRootContext");
	const [ownNestedOpenDialogs, setOwnNestedOpenDialogs] = import_react.useState(0);
	const [ownNestedOpenDrawers, setOwnNestedOpenDrawers] = import_react.useState(0);
	const isTopmost = ownNestedOpenDialogs === 0;
	const dismiss = useDismiss(floatingRootContext, {
		outsidePressEvent() {
			if (store.context.internalBackdropRef.current || store.context.backdropRef.current) return "intentional";
			return {
				mouse: modal === "trap-focus" ? "sloppy" : "intentional",
				touch: "sloppy"
			};
		},
		outsidePress(event) {
			if (!store.context.outsidePressEnabledRef.current) return false;
			if ("button" in event && event.button !== 0) return false;
			if ("touches" in event) {
				if (event.type === "touchend") {
					if (event.changedTouches.length !== 1 || event.touches.length !== 0) return false;
				} else if (event.touches.length !== 1) return false;
			}
			const target = getTarget(event);
			if (isTopmost && !disablePointerDismissal) {
				if (modal) {
					const internalBackdrop = store.context.internalBackdropRef.current;
					const backdrop = store.context.backdropRef.current;
					return internalBackdrop || backdrop ? internalBackdrop === target || backdrop === target || contains(target, popupElement) && !target?.hasAttribute("data-base-ui-portal") : true;
				}
				return true;
			}
			return false;
		},
		escapeKey: isTopmost
	});
	useScrollLock(open && modal === true, popupElement);
	store.useContextCallback("onNestedDialogOpen", (dialogCount, drawerCount) => {
		if (!store.select("open") && !store.select("mounted")) return;
		setOwnNestedOpenDialogs(dialogCount);
		setOwnNestedOpenDrawers(drawerCount);
	});
	useIsoLayoutEffect(() => {
		if (!open && !mounted) {
			setOwnNestedOpenDialogs(0);
			setOwnNestedOpenDrawers(0);
		}
	}, [open, mounted]);
	useIsoLayoutEffect(() => {
		if (parentContext?.onNestedDialogOpen) {
			if (open) parentContext.onNestedDialogOpen(ownNestedOpenDialogs + 1, ownNestedOpenDrawers + (isDrawer ? 1 : 0));
		}
		return () => {
			if (parentContext?.onNestedDialogOpen && open) parentContext.onNestedDialogOpen(0, 0);
		};
	}, [
		isDrawer,
		open,
		ownNestedOpenDialogs,
		ownNestedOpenDrawers,
		parentContext
	]);
	usePopupInteractionProps(store, {
		activeTriggerProps: dismiss.reference,
		inactiveTriggerProps: dismiss.trigger,
		popupProps: dismiss.floating,
		nestedOpenDialogCount: ownNestedOpenDialogs,
		nestedOpenDrawerCount: ownNestedOpenDrawers
	});
	return null;
}
// node_modules/@base-ui/react/dialog/root/DialogRootContext.mjs
var DialogRootContext = /*#__PURE__*/ import_react.createContext(void 0);
DialogRootContext.displayName = "DialogRootContext";
function useDialogRootContext(optional) {
	const store = import_react.useContext(DialogRootContext);
	if (!optional && store === void 0) throw new Error("Base UI: DialogRootContext is missing. Dialog parts must be placed within <Dialog.Root>.");
	return store;
}
// node_modules/@base-ui/react/dialog/store/DialogStore.mjs
var selectors = {
	...popupStoreSelectors,
	modal: (state) => state.modal,
	nested: (state) => state.nested,
	nestedOpenDialogCount: (state) => state.nestedOpenDialogCount,
	nestedOpenDrawerCount: (state) => state.nestedOpenDrawerCount,
	disablePointerDismissal: (state) => state.disablePointerDismissal,
	openMethod: (state) => state.openMethod,
	descriptionElementId: (state) => state.descriptionElementId,
	titleElementId: (state) => state.titleElementId,
	viewportElement: (state) => state.viewportElement,
	role: (state) => state.role
};
/**
* The subset of `DialogStore` that detached handle-backed triggers rely on. Both the real
* `DialogStore` and the inert fallback store satisfy it, so a trigger can read from whichever
* store the handle currently exposes.
*/
var DialogStore = class extends ReactStore {
	constructor(initialState, floatingId, nested) {
		const triggerElements = new PopupTriggerMap();
		const state = createInitialState(initialState, triggerElements, floatingId, nested);
		super(state, createInitialContext(triggerElements), selectors);
	}
	setOpen = (nextOpen, eventDetails) => {
		eventDetails.preventUnmountOnClose = () => {
			this.set("preventUnmountingOnClose", true);
		};
		if (!nextOpen && eventDetails.trigger == null && this.state.activeTriggerId != null) eventDetails.trigger = this.state.activeTriggerElement ?? void 0;
		this.context.onOpenChange?.(nextOpen, eventDetails);
		if (eventDetails.isCanceled) return;
		this.state.floatingRootContext.dispatchOpenChange(nextOpen, eventDetails);
		this.update(createPopupOpenState(this.state, nextOpen, eventDetails.trigger));
	};
};
/**
* Creates the inert fallback store used by detached handle-backed triggers while no
* `Dialog.Root` is attached. It preserves a dialog-specific trigger registry in context so
* detached triggers can register before migrating to the live root store.
*/
function createNullDialogStore() {
	const triggerElements = new PopupTriggerMap();
	return new NullStore(Object.freeze(createInitialState(void 0, triggerElements)), Object.freeze(createInitialContext(triggerElements)), selectors);
}
function createInitialState(initialState, triggerElements, floatingId, nested = false) {
	return {
		...createInitialPopupStoreState(triggerElements, floatingId, nested),
		modal: true,
		disablePointerDismissal: false,
		viewportElement: null,
		descriptionElementId: void 0,
		titleElementId: void 0,
		openMethod: null,
		nested: false,
		nestedOpenDialogCount: 0,
		nestedOpenDrawerCount: 0,
		role: "dialog",
		...initialState
	};
}
function createInitialContext(triggerElements) {
	return {
		popupRef: /*#__PURE__*/ import_react.createRef(),
		backdropRef: /*#__PURE__*/ import_react.createRef(),
		internalBackdropRef: /*#__PURE__*/ import_react.createRef(),
		outsidePressEnabledRef: { current: true },
		triggerElements,
		onOpenChange: void 0,
		onOpenChangeComplete: void 0
	};
}
// node_modules/@base-ui/react/dialog/root/useRenderDialogRoot.mjs
var import_jsx_runtime = require_jsx_runtime();
function useRenderDialogRoot(mode, props) {
	const { children, open: openProp, defaultOpen = false, onOpenChange, onOpenChangeComplete, disablePointerDismissal: disablePointerDismissalProp = false, modal: modalProp = true, actionsRef, handle, triggerId: triggerIdProp, defaultTriggerId: defaultTriggerIdProp = null } = props;
	const isDrawer = mode === "drawer";
	const isAlertDialog = mode === "alert-dialog";
	const modal = isAlertDialog ? true : modalProp;
	const disablePointerDismissal = isAlertDialog || disablePointerDismissalProp;
	const role = isAlertDialog ? "alertdialog" : "dialog";
	const parentStore = useDialogRootContext(true);
	const rootState = {
		modal,
		disablePointerDismissal,
		nested: parentStore != null,
		role
	};
	const store = usePopupRootStore((floatingId, floatingNested) => new DialogStore({
		open: defaultOpen,
		openProp,
		activeTriggerId: defaultTriggerIdProp,
		triggerIdProp,
		...rootState
	}, floatingId, floatingNested), true);
	store.useControlledProp("openProp", openProp);
	store.useControlledProp("triggerIdProp", triggerIdProp);
	store.useSyncedValues(rootState);
	store.useContextCallback("onOpenChange", onOpenChange);
	store.useContextCallback("onOpenChangeComplete", onOpenChangeComplete);
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const payload = store.useState("payload");
	usePopupRootSync(store, open);
	useImplicitActiveTrigger(store);
	const { forceUnmount } = useOpenStateTransitions(open, store);
	import_react.useImperativeHandle(actionsRef, () => ({
		unmount: forceUnmount,
		close: () => store.setOpen(false, createChangeEventDetails(imperativeAction))
	}), [forceUnmount, store]);
	const shouldRenderInteractions = open || mounted || handle != null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(DialogRootContext.Provider, {
		value: store,
		children: [
			handle && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PopupHandleAttachment, {
				handle,
				store
			}),
			shouldRenderInteractions && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(DialogInteractions, {
				store,
				parentContext: parentStore?.context,
				isDrawer
			}),
			typeof children === "function" ? children({ payload }) : children
		]
	});
}
// node_modules/@base-ui/react/dialog/backdrop/DialogBackdrop.mjs
/**
* An overlay displayed beneath the popup.
* Renders a `<div>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogBackdrop = /*#__PURE__*/ import_react.forwardRef(function DialogBackdrop(componentProps, forwardedRef) {
	const { render, className, style, forceRender = false, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const open = store.useState("open");
	const nested = store.useState("nested");
	const mounted = store.useState("mounted");
	const state = {
		open,
		transitionStatus: store.useState("transitionStatus")
	};
	return useRenderElement("div", componentProps, {
		state,
		ref: [store.context.backdropRef, forwardedRef],
		stateAttributesMapping: popupTransitionStateMapping,
		props: [{
			role: "presentation",
			hidden: !mounted,
			style: {
				userSelect: "none",
				WebkitUserSelect: "none"
			}
		}, elementProps],
		enabled: forceRender || !nested
	});
});
DialogBackdrop.displayName = "DialogBackdrop";
// node_modules/@base-ui/react/dialog/close/DialogClose.mjs
/**
* A button that closes the dialog.
* Renders a `<button>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogClose = /*#__PURE__*/ import_react.forwardRef(function DialogClose(componentProps, forwardedRef) {
	const { render, className, style, disabled = false, nativeButton = true, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const open = store.useState("open");
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	const state = { disabled };
	function handleClick(event) {
		if (open) store.setOpen(false, createChangeEventDetails(closePress, event.nativeEvent));
	}
	return useRenderElement("button", componentProps, {
		state,
		ref: [forwardedRef, buttonRef],
		props: [
			{ onClick: handleClick },
			elementProps,
			getButtonProps
		]
	});
});
DialogClose.displayName = "DialogClose";
// node_modules/@base-ui/react/dialog/description/DialogDescription.mjs
/**
* A paragraph with additional information about the dialog.
* Renders a `<p>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogDescription = /*#__PURE__*/ import_react.forwardRef(function DialogDescription(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const id = useBaseUiId(idProp);
	store.useSyncedValueWithCleanup("descriptionElementId", id);
	return useRenderElement("p", componentProps, {
		ref: forwardedRef,
		props: [{ id }, elementProps]
	});
});
DialogDescription.displayName = "DialogDescription";
// node_modules/@base-ui/react/dialog/portal/DialogPortalContext.mjs
var DialogPortalContext = /*#__PURE__*/ import_react.createContext(void 0);
DialogPortalContext.displayName = "DialogPortalContext";
function useDialogPortalContext() {
	const value = import_react.useContext(DialogPortalContext);
	if (value === void 0) throw new Error("Base UI: <Dialog.Portal> is missing.");
	return value;
}
// node_modules/@base-ui/react/dialog/popup/DialogPopupCssVars.mjs
var DialogPopupCssVars_exports = /* @__PURE__ */ __exportAll({ nestedDialogs: () => nestedDialogs });
/**
* Indicates how many dialogs are nested within.
* @type {number}
*/
var nestedDialogs = "--nested-dialogs";
// node_modules/@base-ui/react/dialog/popup/DialogPopupDataAttributes.mjs
var DialogPopupDataAttributes_exports = /* @__PURE__ */ __exportAll({
	closed: () => closed$2,
	endingStyle: () => endingStyle$2,
	nested: () => nested$1,
	nestedDialogOpen: () => nestedDialogOpen$1,
	open: () => open$2,
	startingStyle: () => startingStyle$2
});
/**
* Present when the dialog is open.
*/
var open$2 = open$3;
/**
* Present when the dialog is closed.
*/
var closed$2 = closed$3;
/**
* Present when the dialog begins animating in.
*/
var startingStyle$2 = startingStyle$3;
/**
* Present when the dialog is animating out.
*/
var endingStyle$2 = endingStyle$3;
/**
* Present when the dialog is nested within another dialog.
*/
var nested$1 = "data-nested";
/**
* Present when the dialog has other open dialogs nested within it.
*/
var nestedDialogOpen$1 = "data-nested-dialog-open";
// node_modules/@base-ui/react/dialog/utils/stateAttributesMapping.mjs
/**
* Shared by `Dialog.Popup` and `Dialog.Viewport`, whose states have the same shape.
* `nested` is not mapped: unmapped `true` booleans already render as `data-nested`.
*/
var dialogStateAttributesMapping = {
	...popupStateMapping,
	...transitionStatusMapping,
	nestedDialogOpen(value) {
		return value ? { [nestedDialogOpen$1]: "" } : null;
	}
};
// node_modules/@base-ui/react/dialog/popup/DialogPopup.mjs
/**
* A container for the dialog contents.
* Renders a `<div>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogPopup = /*#__PURE__*/ import_react.forwardRef(function DialogPopup(componentProps, forwardedRef) {
	const { render, className, style, finalFocus, initialFocus, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const descriptionElementId = store.useState("descriptionElementId");
	const disablePointerDismissal = store.useState("disablePointerDismissal");
	const floatingRootContext = store.useState("floatingRootContext");
	const rootPopupProps = store.useState("popupProps");
	const modal = store.useState("modal");
	const mounted = store.useState("mounted");
	const nested = store.useState("nested");
	const nestedOpenDialogCount = store.useState("nestedOpenDialogCount");
	const open = store.useState("open");
	const openMethod = store.useState("openMethod");
	const titleElementId = store.useState("titleElementId");
	const transitionStatus = store.useState("transitionStatus");
	const role = store.useState("role");
	const floatingId = floatingRootContext.useState("floatingId");
	useDialogPortalContext();
	useOpenChangeComplete({
		open,
		ref: store.context.popupRef,
		onComplete() {
			if (open) store.context.onOpenChangeComplete?.(true);
		}
	});
	const resolvedInitialFocus = initialFocus === void 0 ? createDefaultInitialFocus(store.context.popupRef) : initialFocus;
	const nestedDialogOpen = nestedOpenDialogCount > 0;
	const setPopupElement = store.useStateSetter("popupElement");
	const element = useRenderElement("div", componentProps, {
		state: {
			open,
			nested,
			transitionStatus,
			nestedDialogOpen
		},
		props: [
			rootPopupProps,
			{
				id: floatingId,
				"aria-labelledby": titleElementId,
				"aria-describedby": descriptionElementId,
				role,
				...FOCUSABLE_POPUP_PROPS,
				hidden: !mounted,
				onKeyDown(event) {
					if (COMPOSITE_KEYS.has(event.key)) event.stopPropagation();
				},
				style: { [nestedDialogs]: nestedOpenDialogCount }
			},
			elementProps
		],
		ref: [
			forwardedRef,
			store.context.popupRef,
			setPopupElement
		],
		stateAttributesMapping: dialogStateAttributesMapping
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingFocusManager, {
		context: floatingRootContext,
		openInteractionType: openMethod,
		disabled: !mounted,
		closeOnFocusOut: !disablePointerDismissal,
		initialFocus: resolvedInitialFocus,
		returnFocus: finalFocus,
		modal: modal !== false,
		restoreFocus: "popup",
		children: element
	});
});
DialogPopup.displayName = "DialogPopup";
// node_modules/@base-ui/react/dialog/portal/DialogPortal.mjs
/**
* A portal element that moves the popup to a different part of the DOM.
* By default, the portal element is appended to `<body>`.
* Renders a `<div>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogPortal = /*#__PURE__*/ import_react.forwardRef(function DialogPortal(props, forwardedRef) {
	const { keepMounted = false, ...portalProps } = props;
	const store = useDialogRootContext();
	const mounted = store.useState("mounted");
	const modal = store.useState("modal");
	const open = store.useState("open");
	if (!(mounted || keepMounted)) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(DialogPortalContext.Provider, {
		value: keepMounted,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(FloatingPortal, {
			ref: forwardedRef,
			...portalProps,
			children: [mounted && modal === true && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(InternalBackdrop, {
				ref: store.context.internalBackdropRef,
				inert: inertValue(!open)
			}), props.children]
		})
	});
});
DialogPortal.displayName = "DialogPortal";
// node_modules/@base-ui/react/dialog/title/DialogTitle.mjs
/**
* A heading that labels the dialog.
* Renders an `<h2>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogTitle = /*#__PURE__*/ import_react.forwardRef(function DialogTitle(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, ...elementProps } = componentProps;
	const store = useDialogRootContext();
	const id = useBaseUiId(idProp);
	store.useSyncedValueWithCleanup("titleElementId", id);
	return useRenderElement("h2", componentProps, {
		ref: forwardedRef,
		props: [{ id }, elementProps]
	});
});
DialogTitle.displayName = "DialogTitle";
// node_modules/@base-ui/react/dialog/trigger/DialogTrigger.mjs
/**
* A button that opens the dialog.
* Renders a `<button>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogTrigger = fastComponentRef(function DialogTrigger(componentProps, forwardedRef) {
	const { render, className, style, disabled = false, nativeButton = true, id: idProp, payload, handle, ...elementProps } = componentProps;
	const dialogRootStore = useDialogRootContext(true);
	const store = usePopupHandleStore(handle) ?? dialogRootStore;
	if (!store) throw new Error("Base UI: <Dialog.Trigger> must be used within <Dialog.Root> or provided with a handle.");
	const thisTriggerId = useBaseUiId(idProp);
	const floatingContext = store.useState("floatingRootContext");
	const isOpenedByThisTrigger = store.useState("isOpenedByTrigger", thisTriggerId);
	const popupId = store.useState("triggerPopupId", thisTriggerId);
	const triggerElementRef = import_react.useRef(null);
	const { registerTrigger, isMountedByThisTrigger } = useTriggerDataForwarding(thisTriggerId, triggerElementRef, store, { payload });
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	const click = useClick(floatingContext);
	const interactionTypeProps = useOpenMethodTriggerProps(() => store.select("open"), (interactionType) => {
		store.set("openMethod", interactionType);
	});
	const state = {
		disabled,
		open: isOpenedByThisTrigger
	};
	const rootTriggerProps = store.useState("triggerProps", isMountedByThisTrigger);
	return useRenderElement("button", componentProps, {
		state,
		ref: [
			buttonRef,
			forwardedRef,
			registerTrigger,
			triggerElementRef
		],
		props: [
			click.reference,
			rootTriggerProps,
			interactionTypeProps,
			{
				[CLICK_TRIGGER_IDENTIFIER]: "",
				id: thisTriggerId,
				"aria-haspopup": "dialog",
				"aria-expanded": isOpenedByThisTrigger,
				"aria-controls": popupId
			},
			elementProps,
			getButtonProps
		],
		stateAttributesMapping: triggerOpenStateMapping
	});
});
DialogTrigger.displayName = "DialogTrigger";
// node_modules/@base-ui/react/dialog/viewport/DialogViewport.mjs
/**
* A positioning container for the dialog popup that can be made scrollable.
* Renders a `<div>` element.
*
* Documentation: [Base UI Dialog](https://base-ui.com/react/components/dialog)
*/
var DialogViewport = /*#__PURE__*/ import_react.forwardRef(function DialogViewport(componentProps, forwardedRef) {
	const { render, className, style, children, ...elementProps } = componentProps;
	const keepMounted = useDialogPortalContext();
	const store = useDialogRootContext();
	const open = store.useState("open");
	const nested = store.useState("nested");
	const transitionStatus = store.useState("transitionStatus");
	const nestedOpenDialogCount = store.useState("nestedOpenDialogCount");
	const mounted = store.useState("mounted");
	const setViewportElement = store.useStateSetter("viewportElement");
	return useRenderElement("div", componentProps, {
		enabled: keepMounted || mounted,
		state: {
			open,
			nested,
			transitionStatus,
			nestedDialogOpen: nestedOpenDialogCount > 0
		},
		ref: [forwardedRef, setViewportElement],
		stateAttributesMapping: dialogStateAttributesMapping,
		props: [{
			role: "presentation",
			hidden: !mounted,
			style: { pointerEvents: !open ? "none" : void 0 },
			children
		}, elementProps]
	});
});
DialogViewport.displayName = "DialogViewport";
// node_modules/@base-ui/react/dialog/store/DialogHandle.mjs
/**
* Controls a Dialog imperatively and associates detached `Dialog.Trigger` components with a
* `Dialog.Root`. Create one with `Dialog.createHandle()` and pass it to the `handle` prop of the
* root and of any triggers rendered outside of it.
*
* The imperative methods take effect only while a root using this handle is mounted; calls made
* before a root attaches (or after it unmounts) are ignored.
*/
var DialogHandle = class extends BasePopupHandle {
	constructor() {
		super(createNullDialogStore(), "Dialog", false);
	}
	/**
	* Opens the dialog, optionally associating it with a trigger.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*
	* @param triggerId ID of the trigger to associate with the dialog. The trigger must be a matching
	* `Dialog.Trigger` with this handle passed as a prop. Pass `null` to open without associating any trigger.
	*/
	open(triggerId) {
		this.openByTrigger(triggerId);
	}
	/**
	* Opens the dialog with the given payload, without associating it with any trigger.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*
	* @param payload Payload to set when opening the dialog. It is exposed to the root's render-prop children.
	*/
	openWithPayload(payload) {
		const attachedStore = this.attachedStore;
		if (attachedStore === null) {
			console.warn("Base UI: DialogHandle.openWithPayload() was called while no root using this handle is mounted. The call and its payload were ignored; mount a root with this handle before opening it imperatively.");
			return;
		}
		attachedStore.set("payload", payload);
		attachedStore.setOpen(true, createChangeEventDetails(imperativeAction));
	}
	/**
	* Closes the dialog.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*/
	close() {
		this.closePopup();
	}
	/**
	* Whether the dialog is currently open. Returns `false` while no root is attached to the handle.
	*/
	get isOpen() {
		return this.attachedStore?.select("open") ?? false;
	}
};
/**
* Creates a new handle to connect a Dialog.Root with detached Dialog.Trigger components.
*/
function createDialogHandle() {
	return new DialogHandle();
}
// node_modules/@base-ui/react/dialog/backdrop/DialogBackdropDataAttributes.mjs
var DialogBackdropDataAttributes_exports = /* @__PURE__ */ __exportAll({
	closed: () => closed$1,
	endingStyle: () => endingStyle$1,
	open: () => open$1,
	startingStyle: () => startingStyle$1
});
/**
* Present when the dialog is open.
*/
var open$1 = open$3;
/**
* Present when the dialog is closed.
*/
var closed$1 = closed$3;
/**
* Present when the dialog begins animating in.
*/
var startingStyle$1 = startingStyle$3;
/**
* Present when the dialog is animating out.
*/
var endingStyle$1 = endingStyle$3;
// node_modules/@base-ui/react/dialog/close/DialogCloseDataAttributes.mjs
var DialogCloseDataAttributes_exports = /* @__PURE__ */ __exportAll({ disabled: () => disabled });
/**
* Present when the button is disabled.
*/
var disabled = "data-disabled";
// node_modules/@base-ui/react/dialog/viewport/DialogViewportDataAttributes.mjs
var DialogViewportDataAttributes_exports = /* @__PURE__ */ __exportAll({
	closed: () => closed,
	endingStyle: () => endingStyle,
	nested: () => nested,
	nestedDialogOpen: () => nestedDialogOpen,
	open: () => open,
	startingStyle: () => startingStyle
});
/**
* Present when the dialog is open.
*/
var open = open$3;
/**
* Present when the dialog is closed.
*/
var closed = closed$3;
/**
* Present when the dialog begins animating in.
*/
var startingStyle = startingStyle$3;
/**
* Present when the dialog is animating out.
*/
var endingStyle = endingStyle$3;
/**
* Present when the dialog is nested within another dialog.
*/
var nested = "data-nested";
/**
* Present when the dialog has other open dialogs nested within it.
*/
var nestedDialogOpen = "data-nested-dialog-open";
export { createDialogHandle as a, DialogTitle as c, DialogPopupDataAttributes_exports as d, DialogPopupCssVars_exports as f, useRenderDialogRoot as g, DialogBackdrop as h, DialogHandle as i, DialogPortal as l, DialogClose as m, DialogCloseDataAttributes_exports as n, DialogViewport as o, DialogDescription as p, DialogBackdropDataAttributes_exports as r, DialogTrigger as s, DialogViewportDataAttributes_exports as t, DialogPopup as u };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiRGlhbG9nVmlld3BvcnREYXRhQXR0cmlidXRlcy1EakhxVW5MYi5qcyIsIm5hbWVzIjpbIlJFQVNPTlMuaW1wZXJhdGl2ZUFjdGlvbiIsIlJFQVNPTlMuY2xvc2VQcmVzcyIsIm9wZW4iLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW4iLCJjbG9zZWQiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmNsb3NlZCIsInN0YXJ0aW5nU3R5bGUiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnN0YXJ0aW5nU3R5bGUiLCJlbmRpbmdTdHlsZSIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuZW5kaW5nU3R5bGUiLCJuZXN0ZWQiLCJuZXN0ZWREaWFsb2dPcGVuIiwiRGlhbG9nUG9wdXBEYXRhQXR0cmlidXRlcy5uZXN0ZWREaWFsb2dPcGVuIiwiRGlhbG9nUG9wdXBDc3NWYXJzLm5lc3RlZERpYWxvZ3MiLCJSRUFTT05TLmltcGVyYXRpdmVBY3Rpb24iLCJvcGVuIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5vcGVuIiwiY2xvc2VkIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5jbG9zZWQiLCJzdGFydGluZ1N0eWxlIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zdGFydGluZ1N0eWxlIiwiZW5kaW5nU3R5bGUiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmVuZGluZ1N0eWxlIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5vcGVuIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5jbG9zZWQiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnN0YXJ0aW5nU3R5bGUiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmVuZGluZ1N0eWxlIl0sInNvdXJjZXMiOlsiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3Jvb3QvdXNlRGlhbG9nUm9vdC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvcm9vdC9EaWFsb2dSb290Q29udGV4dC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvc3RvcmUvRGlhbG9nU3RvcmUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3Jvb3QvdXNlUmVuZGVyRGlhbG9nUm9vdC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvYmFja2Ryb3AvRGlhbG9nQmFja2Ryb3AubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL2Nsb3NlL0RpYWxvZ0Nsb3NlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2RpYWxvZy9kZXNjcmlwdGlvbi9EaWFsb2dEZXNjcmlwdGlvbi5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvcG9ydGFsL0RpYWxvZ1BvcnRhbENvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3BvcHVwL0RpYWxvZ1BvcHVwQ3NzVmFycy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvcG9wdXAvRGlhbG9nUG9wdXBEYXRhQXR0cmlidXRlcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvdXRpbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9kaWFsb2cvcG9wdXAvRGlhbG9nUG9wdXAubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3BvcnRhbC9EaWFsb2dQb3J0YWwubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3RpdGxlL0RpYWxvZ1RpdGxlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2RpYWxvZy90cmlnZ2VyL0RpYWxvZ1RyaWdnZXIubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3ZpZXdwb3J0L0RpYWxvZ1ZpZXdwb3J0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2RpYWxvZy9zdG9yZS9EaWFsb2dIYW5kbGUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL2JhY2tkcm9wL0RpYWxvZ0JhY2tkcm9wRGF0YUF0dHJpYnV0ZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL2Nsb3NlL0RpYWxvZ0Nsb3NlRGF0YUF0dHJpYnV0ZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZGlhbG9nL3ZpZXdwb3J0L0RpYWxvZ1ZpZXdwb3J0RGF0YUF0dHJpYnV0ZXMubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZVNjcm9sbExvY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTY3JvbGxMb2NrJztcbmltcG9ydCB7IHVzZURpc21pc3MgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBjb250YWlucywgZ2V0VGFyZ2V0IH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzLm1qc1wiO1xuaW1wb3J0IHsgdXNlUG9wdXBJbnRlcmFjdGlvblByb3BzIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwcy9pbmRleC5tanNcIjtcbmV4cG9ydCBmdW5jdGlvbiBEaWFsb2dJbnRlcmFjdGlvbnMoe1xuICBzdG9yZSxcbiAgcGFyZW50Q29udGV4dCxcbiAgaXNEcmF3ZXJcbn0pIHtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IG1vdW50ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbW91bnRlZCcpO1xuICBjb25zdCBkaXNhYmxlUG9pbnRlckRpc21pc3NhbCA9IHN0b3JlLnVzZVN0YXRlKCdkaXNhYmxlUG9pbnRlckRpc21pc3NhbCcpO1xuICBjb25zdCBtb2RhbCA9IHN0b3JlLnVzZVN0YXRlKCdtb2RhbCcpO1xuICBjb25zdCBwb3B1cEVsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZSgncG9wdXBFbGVtZW50Jyk7XG4gIGNvbnN0IGZsb2F0aW5nUm9vdENvbnRleHQgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdSb290Q29udGV4dCcpO1xuICBjb25zdCBbb3duTmVzdGVkT3BlbkRpYWxvZ3MsIHNldE93bk5lc3RlZE9wZW5EaWFsb2dzXSA9IFJlYWN0LnVzZVN0YXRlKDApO1xuICBjb25zdCBbb3duTmVzdGVkT3BlbkRyYXdlcnMsIHNldE93bk5lc3RlZE9wZW5EcmF3ZXJzXSA9IFJlYWN0LnVzZVN0YXRlKDApO1xuICBjb25zdCBpc1RvcG1vc3QgPSBvd25OZXN0ZWRPcGVuRGlhbG9ncyA9PT0gMDtcbiAgY29uc3QgZGlzbWlzcyA9IHVzZURpc21pc3MoZmxvYXRpbmdSb290Q29udGV4dCwge1xuICAgIG91dHNpZGVQcmVzc0V2ZW50KCkge1xuICAgICAgaWYgKHN0b3JlLmNvbnRleHQuaW50ZXJuYWxCYWNrZHJvcFJlZi5jdXJyZW50IHx8IHN0b3JlLmNvbnRleHQuYmFja2Ryb3BSZWYuY3VycmVudCkge1xuICAgICAgICByZXR1cm4gJ2ludGVudGlvbmFsJztcbiAgICAgIH1cbiAgICAgIC8vIEVuc3VyZSBgYXJpYS1oaWRkZW5gIG9uIG91dHNpZGUgZWxlbWVudHMgaXMgcmVtb3ZlZCBpbW1lZGlhdGVseVxuICAgICAgLy8gb24gb3V0c2lkZSBwcmVzcyB3aGVuIHRyYXBwaW5nIGZvY3VzLlxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbW91c2U6IG1vZGFsID09PSAndHJhcC1mb2N1cycgPyAnc2xvcHB5JyA6ICdpbnRlbnRpb25hbCcsXG4gICAgICAgIHRvdWNoOiAnc2xvcHB5J1xuICAgICAgfTtcbiAgICB9LFxuICAgIG91dHNpZGVQcmVzcyhldmVudCkge1xuICAgICAgaWYgKCFzdG9yZS5jb250ZXh0Lm91dHNpZGVQcmVzc0VuYWJsZWRSZWYuY3VycmVudCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG5cbiAgICAgIC8vIEZvciBtb3VzZSBldmVudHMsIG9ubHkgYWNjZXB0IGxlZnQgYnV0dG9uIChidXR0b24gMClcbiAgICAgIC8vIEZvciB0b3VjaCBldmVudHMsIGEgc2luZ2xlIHRvdWNoIGlzIGVxdWl2YWxlbnQgdG8gbGVmdCBidXR0b25cbiAgICAgIGlmICgnYnV0dG9uJyBpbiBldmVudCAmJiBldmVudC5idXR0b24gIT09IDApIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgaWYgKCd0b3VjaGVzJyBpbiBldmVudCkge1xuICAgICAgICAvLyBPdXRzaWRlIHByZXNzIGNhbiBiZSBoYW5kbGVkIG9uIGB0b3VjaGVuZGAsIHdoZXJlIHRoZSBsaWZ0ZWQgcG9pbnQgaXNcbiAgICAgICAgLy8gcmVwb3J0ZWQgaW4gYGNoYW5nZWRUb3VjaGVzYCBhbmQgYHRvdWNoZXNgIGNvbnRhaW5zIGFueSByZW1haW5pbmdcbiAgICAgICAgLy8gYWN0aXZlIHBvaW50cy4gVHJlYXQgaXQgYXMgYSBzaW5nbGUtZmluZ2VyIHRhcCBvbmx5IHdoZW4gZXhhY3RseSBvbmVcbiAgICAgICAgLy8gdG91Y2ggZW5kZWQgYW5kIG5vIG90aGVyIGZpbmdlcnMgYXJlIHN0aWxsIGRvd24uXG4gICAgICAgIGlmIChldmVudC50eXBlID09PSAndG91Y2hlbmQnKSB7XG4gICAgICAgICAgaWYgKGV2ZW50LmNoYW5nZWRUb3VjaGVzLmxlbmd0aCAhPT0gMSB8fCBldmVudC50b3VjaGVzLmxlbmd0aCAhPT0gMCkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmIChldmVudC50b3VjaGVzLmxlbmd0aCAhPT0gMSkge1xuICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgY29uc3QgdGFyZ2V0ID0gZ2V0VGFyZ2V0KGV2ZW50KTtcbiAgICAgIGlmIChpc1RvcG1vc3QgJiYgIWRpc2FibGVQb2ludGVyRGlzbWlzc2FsKSB7XG4gICAgICAgIC8vIE9ubHkgY2xvc2UgaWYgdGhlIGNsaWNrIG9jY3VycmVkIG9uIHRoZSBkaWFsb2cncyBvd25pbmcgYmFja2Ryb3AuXG4gICAgICAgIC8vIFRoaXMgc3VwcG9ydHMgbXVsdGlwbGUgbW9kYWwgZGlhbG9ncyB0aGF0IGFyZW4ndCBuZXN0ZWQgaW4gdGhlIFJlYWN0IHRyZWU6XG4gICAgICAgIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9tdWkvYmFzZS11aS9pc3N1ZXMvMTMyMFxuICAgICAgICBpZiAobW9kYWwpIHtcbiAgICAgICAgICBjb25zdCBpbnRlcm5hbEJhY2tkcm9wID0gc3RvcmUuY29udGV4dC5pbnRlcm5hbEJhY2tkcm9wUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgY29uc3QgYmFja2Ryb3AgPSBzdG9yZS5jb250ZXh0LmJhY2tkcm9wUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgcmV0dXJuIGludGVybmFsQmFja2Ryb3AgfHwgYmFja2Ryb3AgPyBpbnRlcm5hbEJhY2tkcm9wID09PSB0YXJnZXQgfHwgYmFja2Ryb3AgPT09IHRhcmdldCB8fCBjb250YWlucyh0YXJnZXQsIHBvcHVwRWxlbWVudCkgJiYgIXRhcmdldD8uaGFzQXR0cmlidXRlKCdkYXRhLWJhc2UtdWktcG9ydGFsJykgOiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgZXNjYXBlS2V5OiBpc1RvcG1vc3RcbiAgfSk7XG4gIHVzZVNjcm9sbExvY2sob3BlbiAmJiBtb2RhbCA9PT0gdHJ1ZSwgcG9wdXBFbGVtZW50KTtcblxuICAvLyBMaXN0ZW4gZm9yIG5lc3RlZCBvcGVuL2Nsb3NlIGV2ZW50cyBvbiB0aGlzIHN0b3JlIHRvIG1haW50YWluIHRoZSBjb3VudHMuXG4gIC8vIEEgY2xvc2Ugbm90aWZpY2F0aW9uIGlzIGFuIG9wZW4gbm90aWZpY2F0aW9uIHdpdGggemVyb2VkIGNvdW50cy5cbiAgc3RvcmUudXNlQ29udGV4dENhbGxiYWNrKCdvbk5lc3RlZERpYWxvZ09wZW4nLCAoZGlhbG9nQ291bnQsIGRyYXdlckNvdW50KSA9PiB7XG4gICAgLy8gQSBoYW5kbGUtYmFja2VkIHJvb3Qga2VlcHMgdGhlc2UgaW50ZXJhY3Rpb25zIG1vdW50ZWQgd2hpbGUgY2xvc2VkLiBJZ25vcmUgbmVzdGVkIHJvb3RzIHRoYXRcbiAgICAvLyBvcGVuIG1lYW53aGlsZSBzbyB0aGVpciBjb3VudHMgZG9uJ3QgY2FycnkgaW50byB0aGUgbmV4dCBvcGVuIHNlc3Npb24uXG4gICAgaWYgKCFzdG9yZS5zZWxlY3QoJ29wZW4nKSAmJiAhc3RvcmUuc2VsZWN0KCdtb3VudGVkJykpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc2V0T3duTmVzdGVkT3BlbkRpYWxvZ3MoZGlhbG9nQ291bnQpO1xuICAgIHNldE93bk5lc3RlZE9wZW5EcmF3ZXJzKGRyYXdlckNvdW50KTtcbiAgfSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuICYmICFtb3VudGVkKSB7XG4gICAgICBzZXRPd25OZXN0ZWRPcGVuRGlhbG9ncygwKTtcbiAgICAgIHNldE93bk5lc3RlZE9wZW5EcmF3ZXJzKDApO1xuICAgIH1cbiAgfSwgW29wZW4sIG1vdW50ZWRdKTtcblxuICAvLyBOb3RpZnkgcGFyZW50IG9mIG91ciBvcGVuL2Nsb3NlIHN0YXRlIHVzaW5nIHBhcmVudCBjYWxsYmFja3MsIGlmIGFueVxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChwYXJlbnRDb250ZXh0Py5vbk5lc3RlZERpYWxvZ09wZW4pIHtcbiAgICAgIGlmIChvcGVuKSB7XG4gICAgICAgIHBhcmVudENvbnRleHQub25OZXN0ZWREaWFsb2dPcGVuKG93bk5lc3RlZE9wZW5EaWFsb2dzICsgMSwgb3duTmVzdGVkT3BlbkRyYXdlcnMgKyAoaXNEcmF3ZXIgPyAxIDogMCkpO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaWYgKHBhcmVudENvbnRleHQ/Lm9uTmVzdGVkRGlhbG9nT3BlbiAmJiBvcGVuKSB7XG4gICAgICAgIHBhcmVudENvbnRleHQub25OZXN0ZWREaWFsb2dPcGVuKDAsIDApO1xuICAgICAgfVxuICAgIH07XG4gIH0sIFtpc0RyYXdlciwgb3Blbiwgb3duTmVzdGVkT3BlbkRpYWxvZ3MsIG93bk5lc3RlZE9wZW5EcmF3ZXJzLCBwYXJlbnRDb250ZXh0XSk7XG4gIHVzZVBvcHVwSW50ZXJhY3Rpb25Qcm9wcyhzdG9yZSwge1xuICAgIC8vIGBlbmFibGVkYCBpcyBub3QgcGFzc2VkIHRvIGB1c2VEaXNtaXNzYCwgc28gaXRzIHByb3BzIGFyZSBhbHdheXMgZGVmaW5lZCxcbiAgICAvLyBhbmQgYHRyaWdnZXJgIGlzIHRoZSBzYW1lIG9iamVjdCBhcyBgcmVmZXJlbmNlYC5cbiAgICBhY3RpdmVUcmlnZ2VyUHJvcHM6IGRpc21pc3MucmVmZXJlbmNlLFxuICAgIGluYWN0aXZlVHJpZ2dlclByb3BzOiBkaXNtaXNzLnRyaWdnZXIsXG4gICAgLy8gRGlhbG9nUG9wdXAgYW5kIERyYXdlclBvcHVwIHNwcmVhZCBgRk9DVVNBQkxFX1BPUFVQX1BST1BTYCBkaXJlY3RseSwgc29cbiAgICAvLyB0aGlzIG9ubHkgbmVlZHMgdG8gY2FycnkgdGhlIGRpc21pc3MgaGFuZGxlcnMuXG4gICAgcG9wdXBQcm9wczogZGlzbWlzcy5mbG9hdGluZyxcbiAgICBuZXN0ZWRPcGVuRGlhbG9nQ291bnQ6IG93bk5lc3RlZE9wZW5EaWFsb2dzLFxuICAgIG5lc3RlZE9wZW5EcmF3ZXJDb3VudDogb3duTmVzdGVkT3BlbkRyYXdlcnNcbiAgfSk7XG4gIHJldHVybiBudWxsO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IERpYWxvZ1Jvb3RDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIERpYWxvZ1Jvb3RDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJEaWFsb2dSb290Q29udGV4dFwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZURpYWxvZ1Jvb3RDb250ZXh0KG9wdGlvbmFsKSB7XG4gIGNvbnN0IHN0b3JlID0gUmVhY3QudXNlQ29udGV4dChEaWFsb2dSb290Q29udGV4dCk7XG4gIGlmICghb3B0aW9uYWwgJiYgc3RvcmUgPT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAnQmFzZSBVSTogRGlhbG9nUm9vdENvbnRleHQgaXMgbWlzc2luZy4gRGlhbG9nIHBhcnRzIG11c3QgYmUgcGxhY2VkIHdpdGhpbiA8RGlhbG9nLlJvb3Q+LicgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDI3KSk7XG4gIH1cbiAgcmV0dXJuIHN0b3JlO1xufSIsImltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFJlYWN0U3RvcmUgfSBmcm9tICdAYmFzZS11aS91dGlscy9zdG9yZSc7XG5pbXBvcnQgeyBOdWxsU3RvcmUgfSBmcm9tIFwiLi4vLi4vdXRpbHMvTnVsbFN0b3JlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlSW5pdGlhbFBvcHVwU3RvcmVTdGF0ZSwgcG9wdXBTdG9yZVNlbGVjdG9ycywgUG9wdXBUcmlnZ2VyTWFwLCBjcmVhdGVQb3B1cE9wZW5TdGF0ZSB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cHMvaW5kZXgubWpzXCI7XG5jb25zdCBzZWxlY3RvcnMgPSB7XG4gIC4uLnBvcHVwU3RvcmVTZWxlY3RvcnMsXG4gIG1vZGFsOiBzdGF0ZSA9PiBzdGF0ZS5tb2RhbCxcbiAgbmVzdGVkOiBzdGF0ZSA9PiBzdGF0ZS5uZXN0ZWQsXG4gIG5lc3RlZE9wZW5EaWFsb2dDb3VudDogc3RhdGUgPT4gc3RhdGUubmVzdGVkT3BlbkRpYWxvZ0NvdW50LFxuICBuZXN0ZWRPcGVuRHJhd2VyQ291bnQ6IHN0YXRlID0+IHN0YXRlLm5lc3RlZE9wZW5EcmF3ZXJDb3VudCxcbiAgZGlzYWJsZVBvaW50ZXJEaXNtaXNzYWw6IHN0YXRlID0+IHN0YXRlLmRpc2FibGVQb2ludGVyRGlzbWlzc2FsLFxuICBvcGVuTWV0aG9kOiBzdGF0ZSA9PiBzdGF0ZS5vcGVuTWV0aG9kLFxuICBkZXNjcmlwdGlvbkVsZW1lbnRJZDogc3RhdGUgPT4gc3RhdGUuZGVzY3JpcHRpb25FbGVtZW50SWQsXG4gIHRpdGxlRWxlbWVudElkOiBzdGF0ZSA9PiBzdGF0ZS50aXRsZUVsZW1lbnRJZCxcbiAgdmlld3BvcnRFbGVtZW50OiBzdGF0ZSA9PiBzdGF0ZS52aWV3cG9ydEVsZW1lbnQsXG4gIHJvbGU6IHN0YXRlID0+IHN0YXRlLnJvbGVcbn07XG5cbi8qKlxuICogVGhlIHN1YnNldCBvZiBgRGlhbG9nU3RvcmVgIHRoYXQgZGV0YWNoZWQgaGFuZGxlLWJhY2tlZCB0cmlnZ2VycyByZWx5IG9uLiBCb3RoIHRoZSByZWFsXG4gKiBgRGlhbG9nU3RvcmVgIGFuZCB0aGUgaW5lcnQgZmFsbGJhY2sgc3RvcmUgc2F0aXNmeSBpdCwgc28gYSB0cmlnZ2VyIGNhbiByZWFkIGZyb20gd2hpY2hldmVyXG4gKiBzdG9yZSB0aGUgaGFuZGxlIGN1cnJlbnRseSBleHBvc2VzLlxuICovXG5cbmV4cG9ydCBjbGFzcyBEaWFsb2dTdG9yZSBleHRlbmRzIFJlYWN0U3RvcmUge1xuICBjb25zdHJ1Y3Rvcihpbml0aWFsU3RhdGUsIGZsb2F0aW5nSWQsIG5lc3RlZCkge1xuICAgIGNvbnN0IHRyaWdnZXJFbGVtZW50cyA9IG5ldyBQb3B1cFRyaWdnZXJNYXAoKTtcbiAgICBjb25zdCBzdGF0ZSA9IGNyZWF0ZUluaXRpYWxTdGF0ZShpbml0aWFsU3RhdGUsIHRyaWdnZXJFbGVtZW50cywgZmxvYXRpbmdJZCwgbmVzdGVkKTtcbiAgICBzdXBlcihzdGF0ZSwgY3JlYXRlSW5pdGlhbENvbnRleHQodHJpZ2dlckVsZW1lbnRzKSwgc2VsZWN0b3JzKTtcbiAgfVxuICBzZXRPcGVuID0gKG5leHRPcGVuLCBldmVudERldGFpbHMpID0+IHtcbiAgICBldmVudERldGFpbHMucHJldmVudFVubW91bnRPbkNsb3NlID0gKCkgPT4ge1xuICAgICAgdGhpcy5zZXQoJ3ByZXZlbnRVbm1vdW50aW5nT25DbG9zZScsIHRydWUpO1xuICAgIH07XG4gICAgaWYgKCFuZXh0T3BlbiAmJiBldmVudERldGFpbHMudHJpZ2dlciA9PSBudWxsICYmIHRoaXMuc3RhdGUuYWN0aXZlVHJpZ2dlcklkICE9IG51bGwpIHtcbiAgICAgIC8vIFdoZW4gY2xvc2luZyB0aGUgZGlhbG9nLCBwYXNzIHRoZSBvbGQgdHJpZ2dlciB0byB0aGUgb25PcGVuQ2hhbmdlIGV2ZW50XG4gICAgICAvLyBzbyBpdCdzIG5vdCByZXNldCB0b28gZWFybHkgKHBvdGVudGlhbGx5IGNhdXNpbmcgZm9jdXMgaXNzdWVzIGluIGNvbnRyb2xsZWQgc2NlbmFyaW9zKS5cbiAgICAgIGV2ZW50RGV0YWlscy50cmlnZ2VyID0gdGhpcy5zdGF0ZS5hY3RpdmVUcmlnZ2VyRWxlbWVudCA/PyB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHRoaXMuY29udGV4dC5vbk9wZW5DaGFuZ2U/LihuZXh0T3BlbiwgZXZlbnREZXRhaWxzKTtcbiAgICBpZiAoZXZlbnREZXRhaWxzLmlzQ2FuY2VsZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5zdGF0ZS5mbG9hdGluZ1Jvb3RDb250ZXh0LmRpc3BhdGNoT3BlbkNoYW5nZShuZXh0T3BlbiwgZXZlbnREZXRhaWxzKTtcbiAgICB0aGlzLnVwZGF0ZShjcmVhdGVQb3B1cE9wZW5TdGF0ZSh0aGlzLnN0YXRlLCBuZXh0T3BlbiwgZXZlbnREZXRhaWxzLnRyaWdnZXIpKTtcbiAgfTtcbn1cblxuLyoqXG4gKiBDcmVhdGVzIHRoZSBpbmVydCBmYWxsYmFjayBzdG9yZSB1c2VkIGJ5IGRldGFjaGVkIGhhbmRsZS1iYWNrZWQgdHJpZ2dlcnMgd2hpbGUgbm9cbiAqIGBEaWFsb2cuUm9vdGAgaXMgYXR0YWNoZWQuIEl0IHByZXNlcnZlcyBhIGRpYWxvZy1zcGVjaWZpYyB0cmlnZ2VyIHJlZ2lzdHJ5IGluIGNvbnRleHQgc29cbiAqIGRldGFjaGVkIHRyaWdnZXJzIGNhbiByZWdpc3RlciBiZWZvcmUgbWlncmF0aW5nIHRvIHRoZSBsaXZlIHJvb3Qgc3RvcmUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVOdWxsRGlhbG9nU3RvcmUoKSB7XG4gIGNvbnN0IHRyaWdnZXJFbGVtZW50cyA9IG5ldyBQb3B1cFRyaWdnZXJNYXAoKTtcbiAgcmV0dXJuIG5ldyBOdWxsU3RvcmUoT2JqZWN0LmZyZWV6ZShjcmVhdGVJbml0aWFsU3RhdGUodW5kZWZpbmVkLCB0cmlnZ2VyRWxlbWVudHMpKSwgT2JqZWN0LmZyZWV6ZShjcmVhdGVJbml0aWFsQ29udGV4dCh0cmlnZ2VyRWxlbWVudHMpKSwgc2VsZWN0b3JzKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUluaXRpYWxTdGF0ZShpbml0aWFsU3RhdGUsIHRyaWdnZXJFbGVtZW50cywgZmxvYXRpbmdJZCwgbmVzdGVkID0gZmFsc2UpIHtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgLi4uY3JlYXRlSW5pdGlhbFBvcHVwU3RvcmVTdGF0ZSh0cmlnZ2VyRWxlbWVudHMsIGZsb2F0aW5nSWQsIG5lc3RlZCksXG4gICAgbW9kYWw6IHRydWUsXG4gICAgZGlzYWJsZVBvaW50ZXJEaXNtaXNzYWw6IGZhbHNlLFxuICAgIHZpZXdwb3J0RWxlbWVudDogbnVsbCxcbiAgICBkZXNjcmlwdGlvbkVsZW1lbnRJZDogdW5kZWZpbmVkLFxuICAgIHRpdGxlRWxlbWVudElkOiB1bmRlZmluZWQsXG4gICAgb3Blbk1ldGhvZDogbnVsbCxcbiAgICBuZXN0ZWQ6IGZhbHNlLFxuICAgIG5lc3RlZE9wZW5EaWFsb2dDb3VudDogMCxcbiAgICBuZXN0ZWRPcGVuRHJhd2VyQ291bnQ6IDAsXG4gICAgcm9sZTogJ2RpYWxvZycsXG4gICAgLi4uaW5pdGlhbFN0YXRlXG4gIH07XG4gIHJldHVybiBzdGF0ZTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUluaXRpYWxDb250ZXh0KHRyaWdnZXJFbGVtZW50cykge1xuICByZXR1cm4ge1xuICAgIHBvcHVwUmVmOiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlUmVmKCksXG4gICAgYmFja2Ryb3BSZWY6IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVSZWYoKSxcbiAgICBpbnRlcm5hbEJhY2tkcm9wUmVmOiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlUmVmKCksXG4gICAgb3V0c2lkZVByZXNzRW5hYmxlZFJlZjoge1xuICAgICAgY3VycmVudDogdHJ1ZVxuICAgIH0sXG4gICAgdHJpZ2dlckVsZW1lbnRzLFxuICAgIG9uT3BlbkNoYW5nZTogdW5kZWZpbmVkLFxuICAgIG9uT3BlbkNoYW5nZUNvbXBsZXRlOiB1bmRlZmluZWRcbiAgfTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IERpYWxvZ0ludGVyYWN0aW9ucyB9IGZyb20gXCIuL3VzZURpYWxvZ1Jvb3QubWpzXCI7XG5pbXBvcnQgeyBEaWFsb2dSb290Q29udGV4dCwgdXNlRGlhbG9nUm9vdENvbnRleHQgfSBmcm9tIFwiLi9EaWFsb2dSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IERpYWxvZ1N0b3JlIH0gZnJvbSBcIi4uL3N0b3JlL0RpYWxvZ1N0b3JlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsgdXNlSW1wbGljaXRBY3RpdmVUcmlnZ2VyLCB1c2VPcGVuU3RhdGVUcmFuc2l0aW9ucywgUG9wdXBIYW5kbGVBdHRhY2htZW50LCB1c2VQb3B1cFJvb3RTdG9yZSwgdXNlUG9wdXBSb290U3luYyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cHMvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBqc3ggYXMgX2pzeCwganN4cyBhcyBfanN4cyB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVJlbmRlckRpYWxvZ1Jvb3QobW9kZSwgcHJvcHMpIHtcbiAgY29uc3Qge1xuICAgIGNoaWxkcmVuLFxuICAgIG9wZW46IG9wZW5Qcm9wLFxuICAgIGRlZmF1bHRPcGVuID0gZmFsc2UsXG4gICAgb25PcGVuQ2hhbmdlLFxuICAgIG9uT3BlbkNoYW5nZUNvbXBsZXRlLFxuICAgIGRpc2FibGVQb2ludGVyRGlzbWlzc2FsOiBkaXNhYmxlUG9pbnRlckRpc21pc3NhbFByb3AgPSBmYWxzZSxcbiAgICBtb2RhbDogbW9kYWxQcm9wID0gdHJ1ZSxcbiAgICBhY3Rpb25zUmVmLFxuICAgIGhhbmRsZSxcbiAgICB0cmlnZ2VySWQ6IHRyaWdnZXJJZFByb3AsXG4gICAgZGVmYXVsdFRyaWdnZXJJZDogZGVmYXVsdFRyaWdnZXJJZFByb3AgPSBudWxsXG4gIH0gPSBwcm9wcztcbiAgY29uc3QgaXNEcmF3ZXIgPSBtb2RlID09PSAnZHJhd2VyJztcbiAgY29uc3QgaXNBbGVydERpYWxvZyA9IG1vZGUgPT09ICdhbGVydC1kaWFsb2cnO1xuICBjb25zdCBtb2RhbCA9IGlzQWxlcnREaWFsb2cgPyB0cnVlIDogbW9kYWxQcm9wO1xuICBjb25zdCBkaXNhYmxlUG9pbnRlckRpc21pc3NhbCA9IGlzQWxlcnREaWFsb2cgfHwgZGlzYWJsZVBvaW50ZXJEaXNtaXNzYWxQcm9wO1xuICBjb25zdCByb2xlID0gaXNBbGVydERpYWxvZyA/ICdhbGVydGRpYWxvZycgOiAnZGlhbG9nJztcbiAgY29uc3QgcGFyZW50U3RvcmUgPSB1c2VEaWFsb2dSb290Q29udGV4dCh0cnVlKTtcbiAgY29uc3QgbmVzdGVkID0gcGFyZW50U3RvcmUgIT0gbnVsbDtcbiAgY29uc3Qgcm9vdFN0YXRlID0ge1xuICAgIG1vZGFsLFxuICAgIGRpc2FibGVQb2ludGVyRGlzbWlzc2FsLFxuICAgIG5lc3RlZCxcbiAgICByb2xlXG4gIH07XG5cbiAgLy8gVGhlIHN0b3JlIGlzIG93bmVkIGJ5IHRoaXMgUm9vdCBpbnN0YW5jZSBhbmQgY3JlYXRlZCBleGFjdGx5IG9uY2UuIEl0IGlzIG5vdCB0aWVkIHRvIHRoZSBoYW5kbGU6XG4gIC8vIHRoZSBoYW5kbGUgYXR0YWNoZXMgdG8gaXQsIHNvIHN3YXBwaW5nIHRoZSBoYW5kbGUgcmUtYXR0YWNoZXMgcmF0aGVyIHRoYW4gcmVjcmVhdGluZyBzdGF0ZS5cbiAgLy8gRGVmYXVsdCB2YWx1ZXMgYXJlIG9ubHkgaW5pdGlhbCB2YWx1ZXM7IGNvbnRyb2xsZWQgdmFsdWVzIGFuZCByb290IHN0YXRlIGFyZSBzeW5jZWQgYWZ0ZXIgY3JlYXRpb24uXG4gIC8vIERpYWxvZ3MgcGFzcyB0aGUgcG9wdXAgZWxlbWVudCB0byBGbG9hdGluZyBVSSBhcyB0aGUgZmxvYXRpbmcgZWxlbWVudCAoYHRyZWF0UG9wdXBBc0Zsb2F0aW5nRWxlbWVudGApLlxuICBjb25zdCBzdG9yZSA9IHVzZVBvcHVwUm9vdFN0b3JlKChmbG9hdGluZ0lkLCBmbG9hdGluZ05lc3RlZCkgPT4gbmV3IERpYWxvZ1N0b3JlKHtcbiAgICBvcGVuOiBkZWZhdWx0T3BlbixcbiAgICBvcGVuUHJvcCxcbiAgICBhY3RpdmVUcmlnZ2VySWQ6IGRlZmF1bHRUcmlnZ2VySWRQcm9wLFxuICAgIHRyaWdnZXJJZFByb3AsXG4gICAgLi4ucm9vdFN0YXRlXG4gIH0sIGZsb2F0aW5nSWQsIGZsb2F0aW5nTmVzdGVkKSwgdHJ1ZSk7XG4gIHN0b3JlLnVzZUNvbnRyb2xsZWRQcm9wKCdvcGVuUHJvcCcsIG9wZW5Qcm9wKTtcbiAgc3RvcmUudXNlQ29udHJvbGxlZFByb3AoJ3RyaWdnZXJJZFByb3AnLCB0cmlnZ2VySWRQcm9wKTtcbiAgc3RvcmUudXNlU3luY2VkVmFsdWVzKHJvb3RTdGF0ZSk7XG4gIHN0b3JlLnVzZUNvbnRleHRDYWxsYmFjaygnb25PcGVuQ2hhbmdlJywgb25PcGVuQ2hhbmdlKTtcbiAgc3RvcmUudXNlQ29udGV4dENhbGxiYWNrKCdvbk9wZW5DaGFuZ2VDb21wbGV0ZScsIG9uT3BlbkNoYW5nZUNvbXBsZXRlKTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IG1vdW50ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbW91bnRlZCcpO1xuICBjb25zdCBwYXlsb2FkID0gc3RvcmUudXNlU3RhdGUoJ3BheWxvYWQnKTtcbiAgdXNlUG9wdXBSb290U3luYyhzdG9yZSwgb3Blbik7XG4gIHVzZUltcGxpY2l0QWN0aXZlVHJpZ2dlcihzdG9yZSk7XG4gIGNvbnN0IHtcbiAgICBmb3JjZVVubW91bnRcbiAgfSA9IHVzZU9wZW5TdGF0ZVRyYW5zaXRpb25zKG9wZW4sIHN0b3JlKTtcbiAgUmVhY3QudXNlSW1wZXJhdGl2ZUhhbmRsZShhY3Rpb25zUmVmLCAoKSA9PiAoe1xuICAgIHVubW91bnQ6IGZvcmNlVW5tb3VudCxcbiAgICBjbG9zZTogKCkgPT4gc3RvcmUuc2V0T3BlbihmYWxzZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuaW1wZXJhdGl2ZUFjdGlvbikpXG4gIH0pLCBbZm9yY2VVbm1vdW50LCBzdG9yZV0pO1xuXG4gIC8vIERldGFjaGVkIHRyaWdnZXJzIHNoYXJlIHRoaXMgb25lIFJvb3QsIHNvIG1vdW50aW5nIGl0cyBpbnRlcmFjdGlvbnMgZWFnZXJseSBpcyBjaGVhcC4gVGhlXG4gIC8vIHRyaWdnZXIgcHJvcHMgdGhleSBwdWJsaXNoIHRoZW4gc3RheSBzdGFibGUsIHNvIG9wZW5pbmcgYW5kIGNsb3NpbmcgZG9lc24ndCByZS1yZW5kZXIgaW5hY3RpdmVcbiAgLy8gdHJpZ2dlcnMuXG4gIGNvbnN0IHNob3VsZFJlbmRlckludGVyYWN0aW9ucyA9IG9wZW4gfHwgbW91bnRlZCB8fCBoYW5kbGUgIT0gbnVsbDtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4cyhEaWFsb2dSb290Q29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBzdG9yZSxcbiAgICBjaGlsZHJlbjogW2hhbmRsZSAmJiAvKiNfX1BVUkVfXyovX2pzeChQb3B1cEhhbmRsZUF0dGFjaG1lbnQsIHtcbiAgICAgIGhhbmRsZTogaGFuZGxlLFxuICAgICAgc3RvcmU6IHN0b3JlXG4gICAgfSksIHNob3VsZFJlbmRlckludGVyYWN0aW9ucyAmJiAvKiNfX1BVUkVfXyovX2pzeChEaWFsb2dJbnRlcmFjdGlvbnMsIHtcbiAgICAgIHN0b3JlOiBzdG9yZSxcbiAgICAgIHBhcmVudENvbnRleHQ6IHBhcmVudFN0b3JlPy5jb250ZXh0LFxuICAgICAgaXNEcmF3ZXI6IGlzRHJhd2VyXG4gICAgfSksIHR5cGVvZiBjaGlsZHJlbiA9PT0gJ2Z1bmN0aW9uJyA/IGNoaWxkcmVuKHtcbiAgICAgIHBheWxvYWRcbiAgICB9KSA6IGNoaWxkcmVuXVxuICB9KTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZURpYWxvZ1Jvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvRGlhbG9nUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgcG9wdXBUcmFuc2l0aW9uU3RhdGVNYXBwaW5nIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwU3RhdGVNYXBwaW5nLm1qc1wiO1xuXG4vKipcbiAqIEFuIG92ZXJsYXkgZGlzcGxheWVkIGJlbmVhdGggdGhlIHBvcHVwLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBEaWFsb2ddKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9kaWFsb2cpXG4gKi9cbmV4cG9ydCBjb25zdCBEaWFsb2dCYWNrZHJvcCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIERpYWxvZ0JhY2tkcm9wKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgZm9yY2VSZW5kZXIgPSBmYWxzZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCBzdG9yZSA9IHVzZURpYWxvZ1Jvb3RDb250ZXh0KCk7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCBuZXN0ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbmVzdGVkJyk7XG4gIGNvbnN0IG1vdW50ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbW91bnRlZCcpO1xuICBjb25zdCB0cmFuc2l0aW9uU3RhdHVzID0gc3RvcmUudXNlU3RhdGUoJ3RyYW5zaXRpb25TdGF0dXMnKTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgb3BlbixcbiAgICB0cmFuc2l0aW9uU3RhdHVzXG4gIH07XG4gIHJldHVybiB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHN0YXRlLFxuICAgIHJlZjogW3N0b3JlLmNvbnRleHQuYmFja2Ryb3BSZWYsIGZvcndhcmRlZFJlZl0sXG4gICAgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZzogcG9wdXBUcmFuc2l0aW9uU3RhdGVNYXBwaW5nLFxuICAgIHByb3BzOiBbe1xuICAgICAgcm9sZTogJ3ByZXNlbnRhdGlvbicsXG4gICAgICBoaWRkZW46ICFtb3VudGVkLFxuICAgICAgc3R5bGU6IHtcbiAgICAgICAgdXNlclNlbGVjdDogJ25vbmUnLFxuICAgICAgICBXZWJraXRVc2VyU2VsZWN0OiAnbm9uZSdcbiAgICAgIH1cbiAgICB9LCBlbGVtZW50UHJvcHNdLFxuICAgIGVuYWJsZWQ6IGZvcmNlUmVuZGVyIHx8ICFuZXN0ZWRcbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIERpYWxvZ0JhY2tkcm9wLmRpc3BsYXlOYW1lID0gXCJEaWFsb2dCYWNrZHJvcFwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlRGlhbG9nUm9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9EaWFsb2dSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VCdXR0b24gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZS1idXR0b24vaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5cbi8qKlxuICogQSBidXR0b24gdGhhdCBjbG9zZXMgdGhlIGRpYWxvZy5cbiAqIFJlbmRlcnMgYSBgPGJ1dHRvbj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgRGlhbG9nXShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvZGlhbG9nKVxuICovXG5leHBvcnQgY29uc3QgRGlhbG9nQ2xvc2UgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBEaWFsb2dDbG9zZShjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIGRpc2FibGVkID0gZmFsc2UsXG4gICAgbmF0aXZlQnV0dG9uID0gdHJ1ZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCBzdG9yZSA9IHVzZURpYWxvZ1Jvb3RDb250ZXh0KCk7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCB7XG4gICAgZ2V0QnV0dG9uUHJvcHMsXG4gICAgYnV0dG9uUmVmXG4gIH0gPSB1c2VCdXR0b24oe1xuICAgIGRpc2FibGVkLFxuICAgIG5hdGl2ZTogbmF0aXZlQnV0dG9uXG4gIH0pO1xuICBjb25zdCBzdGF0ZSA9IHtcbiAgICBkaXNhYmxlZFxuICB9O1xuICBmdW5jdGlvbiBoYW5kbGVDbGljayhldmVudCkge1xuICAgIGlmIChvcGVuKSB7XG4gICAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5jbG9zZVByZXNzLCBldmVudC5uYXRpdmVFdmVudCkpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdXNlUmVuZGVyRWxlbWVudCgnYnV0dG9uJywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICByZWY6IFtmb3J3YXJkZWRSZWYsIGJ1dHRvblJlZl0sXG4gICAgcHJvcHM6IFt7XG4gICAgICBvbkNsaWNrOiBoYW5kbGVDbGlja1xuICAgIH0sIGVsZW1lbnRQcm9wcywgZ2V0QnV0dG9uUHJvcHNdXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBEaWFsb2dDbG9zZS5kaXNwbGF5TmFtZSA9IFwiRGlhbG9nQ2xvc2VcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZURpYWxvZ1Jvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvRGlhbG9nUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQmFzZVVpSWQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZUJhc2VVaUlkLm1qc1wiO1xuLyoqXG4gKiBBIHBhcmFncmFwaCB3aXRoIGFkZGl0aW9uYWwgaW5mb3JtYXRpb24gYWJvdXQgdGhlIGRpYWxvZy5cbiAqIFJlbmRlcnMgYSBgPHA+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIERpYWxvZ10oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL2RpYWxvZylcbiAqL1xuZXhwb3J0IGNvbnN0IERpYWxvZ0Rlc2NyaXB0aW9uID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gRGlhbG9nRGVzY3JpcHRpb24oY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIGNsYXNzTmFtZSxcbiAgICBzdHlsZSxcbiAgICBpZDogaWRQcm9wLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IHN0b3JlID0gdXNlRGlhbG9nUm9vdENvbnRleHQoKTtcbiAgY29uc3QgaWQgPSB1c2VCYXNlVWlJZChpZFByb3ApO1xuICBzdG9yZS51c2VTeW5jZWRWYWx1ZVdpdGhDbGVhbnVwKCdkZXNjcmlwdGlvbkVsZW1lbnRJZCcsIGlkKTtcbiAgcmV0dXJuIHVzZVJlbmRlckVsZW1lbnQoJ3AnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgIHByb3BzOiBbe1xuICAgICAgaWRcbiAgICB9LCBlbGVtZW50UHJvcHNdXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBEaWFsb2dEZXNjcmlwdGlvbi5kaXNwbGF5TmFtZSA9IFwiRGlhbG9nRGVzY3JpcHRpb25cIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCBfZm9ybWF0RXJyb3JNZXNzYWdlIGZyb20gXCJAYmFzZS11aS91dGlscy9mb3JtYXRFcnJvck1lc3NhZ2VcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBEaWFsb2dQb3J0YWxDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIERpYWxvZ1BvcnRhbENvbnRleHQuZGlzcGxheU5hbWUgPSBcIkRpYWxvZ1BvcnRhbENvbnRleHRcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VEaWFsb2dQb3J0YWxDb250ZXh0KCkge1xuICBjb25zdCB2YWx1ZSA9IFJlYWN0LnVzZUNvbnRleHQoRGlhbG9nUG9ydGFsQ29udGV4dCk7XG4gIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/ICdCYXNlIFVJOiA8RGlhbG9nLlBvcnRhbD4gaXMgbWlzc2luZy4nIDogX2Zvcm1hdEVycm9yTWVzc2FnZSgyNikpO1xuICB9XG4gIHJldHVybiB2YWx1ZTtcbn0iLCIvKipcbiAqIEluZGljYXRlcyBob3cgbWFueSBkaWFsb2dzIGFyZSBuZXN0ZWQgd2l0aGluLlxuICogQHR5cGUge251bWJlcn1cbiAqL1xuZXhwb3J0IGNvbnN0IG5lc3RlZERpYWxvZ3MgPSAnLS1uZXN0ZWQtZGlhbG9ncyc7IiwiaW1wb3J0IHsgQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGRpYWxvZyBpcyBvcGVuLlxuICovXG5leHBvcnQgY29uc3Qgb3BlbiA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMub3Blbjtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBkaWFsb2cgaXMgY2xvc2VkLlxuICovXG5leHBvcnQgY29uc3QgY2xvc2VkID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5jbG9zZWQ7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgZGlhbG9nIGJlZ2lucyBhbmltYXRpbmcgaW4uXG4gKi9cbmV4cG9ydCBjb25zdCBzdGFydGluZ1N0eWxlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zdGFydGluZ1N0eWxlO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGRpYWxvZyBpcyBhbmltYXRpbmcgb3V0LlxuICovXG5leHBvcnQgY29uc3QgZW5kaW5nU3R5bGUgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmVuZGluZ1N0eWxlO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGRpYWxvZyBpcyBuZXN0ZWQgd2l0aGluIGFub3RoZXIgZGlhbG9nLlxuICovXG5leHBvcnQgY29uc3QgbmVzdGVkID0gJ2RhdGEtbmVzdGVkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBkaWFsb2cgaGFzIG90aGVyIG9wZW4gZGlhbG9ncyBuZXN0ZWQgd2l0aGluIGl0LlxuICovXG5leHBvcnQgY29uc3QgbmVzdGVkRGlhbG9nT3BlbiA9ICdkYXRhLW5lc3RlZC1kaWFsb2ctb3Blbic7IiwiaW1wb3J0IHsgdHJhbnNpdGlvblN0YXR1c01hcHBpbmcgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3N0YXRlQXR0cmlidXRlc01hcHBpbmcubWpzXCI7XG5pbXBvcnQgeyBwb3B1cFN0YXRlTWFwcGluZyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcbmltcG9ydCAqIGFzIERpYWxvZ1BvcHVwRGF0YUF0dHJpYnV0ZXMgZnJvbSBcIi4uL3BvcHVwL0RpYWxvZ1BvcHVwRGF0YUF0dHJpYnV0ZXMubWpzXCI7XG5cbi8qKlxuICogU2hhcmVkIGJ5IGBEaWFsb2cuUG9wdXBgIGFuZCBgRGlhbG9nLlZpZXdwb3J0YCwgd2hvc2Ugc3RhdGVzIGhhdmUgdGhlIHNhbWUgc2hhcGUuXG4gKiBgbmVzdGVkYCBpcyBub3QgbWFwcGVkOiB1bm1hcHBlZCBgdHJ1ZWAgYm9vbGVhbnMgYWxyZWFkeSByZW5kZXIgYXMgYGRhdGEtbmVzdGVkYC5cbiAqL1xuZXhwb3J0IGNvbnN0IGRpYWxvZ1N0YXRlQXR0cmlidXRlc01hcHBpbmcgPSB7XG4gIC4uLnBvcHVwU3RhdGVNYXBwaW5nLFxuICAuLi50cmFuc2l0aW9uU3RhdHVzTWFwcGluZyxcbiAgbmVzdGVkRGlhbG9nT3Blbih2YWx1ZSkge1xuICAgIHJldHVybiB2YWx1ZSA/IHtcbiAgICAgIFtEaWFsb2dQb3B1cERhdGFBdHRyaWJ1dGVzLm5lc3RlZERpYWxvZ09wZW5dOiAnJ1xuICAgIH0gOiBudWxsO1xuICB9XG59OyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgRmxvYXRpbmdGb2N1c01hbmFnZXIgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyB1c2VEaWFsb2dSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L0RpYWxvZ1Jvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVuZGVyRWxlbWVudCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlUmVuZGVyRWxlbWVudC5tanNcIjtcbmltcG9ydCB7IHVzZURpYWxvZ1BvcnRhbENvbnRleHQgfSBmcm9tIFwiLi4vcG9ydGFsL0RpYWxvZ1BvcnRhbENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VPcGVuQ2hhbmdlQ29tcGxldGUgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZU9wZW5DaGFuZ2VDb21wbGV0ZS5tanNcIjtcbmltcG9ydCB7IENPTVBPU0lURV9LRVlTIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jb21wb3NpdGUvY29tcG9zaXRlLm1qc1wiO1xuaW1wb3J0IHsgRk9DVVNBQkxFX1BPUFVQX1BST1BTLCBjcmVhdGVEZWZhdWx0SW5pdGlhbEZvY3VzIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwcy9pbmRleC5tanNcIjtcbmltcG9ydCAqIGFzIERpYWxvZ1BvcHVwQ3NzVmFycyBmcm9tIFwiLi9EaWFsb2dQb3B1cENzc1ZhcnMubWpzXCI7XG5pbXBvcnQgeyBkaWFsb2dTdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nIH0gZnJvbSBcIi4uL3V0aWxzL3N0YXRlQXR0cmlidXRlc01hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogQSBjb250YWluZXIgZm9yIHRoZSBkaWFsb2cgY29udGVudHMuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIERpYWxvZ10oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL2RpYWxvZylcbiAqL1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCBjb25zdCBEaWFsb2dQb3B1cCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIERpYWxvZ1BvcHVwKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgZmluYWxGb2N1cyxcbiAgICBpbml0aWFsRm9jdXMsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qgc3RvcmUgPSB1c2VEaWFsb2dSb290Q29udGV4dCgpO1xuICBjb25zdCBkZXNjcmlwdGlvbkVsZW1lbnRJZCA9IHN0b3JlLnVzZVN0YXRlKCdkZXNjcmlwdGlvbkVsZW1lbnRJZCcpO1xuICBjb25zdCBkaXNhYmxlUG9pbnRlckRpc21pc3NhbCA9IHN0b3JlLnVzZVN0YXRlKCdkaXNhYmxlUG9pbnRlckRpc21pc3NhbCcpO1xuICBjb25zdCBmbG9hdGluZ1Jvb3RDb250ZXh0ID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nUm9vdENvbnRleHQnKTtcbiAgY29uc3Qgcm9vdFBvcHVwUHJvcHMgPSBzdG9yZS51c2VTdGF0ZSgncG9wdXBQcm9wcycpO1xuICBjb25zdCBtb2RhbCA9IHN0b3JlLnVzZVN0YXRlKCdtb2RhbCcpO1xuICBjb25zdCBtb3VudGVkID0gc3RvcmUudXNlU3RhdGUoJ21vdW50ZWQnKTtcbiAgY29uc3QgbmVzdGVkID0gc3RvcmUudXNlU3RhdGUoJ25lc3RlZCcpO1xuICBjb25zdCBuZXN0ZWRPcGVuRGlhbG9nQ291bnQgPSBzdG9yZS51c2VTdGF0ZSgnbmVzdGVkT3BlbkRpYWxvZ0NvdW50Jyk7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCBvcGVuTWV0aG9kID0gc3RvcmUudXNlU3RhdGUoJ29wZW5NZXRob2QnKTtcbiAgY29uc3QgdGl0bGVFbGVtZW50SWQgPSBzdG9yZS51c2VTdGF0ZSgndGl0bGVFbGVtZW50SWQnKTtcbiAgY29uc3QgdHJhbnNpdGlvblN0YXR1cyA9IHN0b3JlLnVzZVN0YXRlKCd0cmFuc2l0aW9uU3RhdHVzJyk7XG4gIGNvbnN0IHJvbGUgPSBzdG9yZS51c2VTdGF0ZSgncm9sZScpO1xuICBjb25zdCBmbG9hdGluZ0lkID0gZmxvYXRpbmdSb290Q29udGV4dC51c2VTdGF0ZSgnZmxvYXRpbmdJZCcpO1xuICB1c2VEaWFsb2dQb3J0YWxDb250ZXh0KCk7XG4gIHVzZU9wZW5DaGFuZ2VDb21wbGV0ZSh7XG4gICAgb3BlbixcbiAgICByZWY6IHN0b3JlLmNvbnRleHQucG9wdXBSZWYsXG4gICAgb25Db21wbGV0ZSgpIHtcbiAgICAgIGlmIChvcGVuKSB7XG4gICAgICAgIHN0b3JlLmNvbnRleHQub25PcGVuQ2hhbmdlQ29tcGxldGU/Lih0cnVlKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuICBjb25zdCByZXNvbHZlZEluaXRpYWxGb2N1cyA9IGluaXRpYWxGb2N1cyA9PT0gdW5kZWZpbmVkID8gY3JlYXRlRGVmYXVsdEluaXRpYWxGb2N1cyhzdG9yZS5jb250ZXh0LnBvcHVwUmVmKSA6IGluaXRpYWxGb2N1cztcbiAgY29uc3QgbmVzdGVkRGlhbG9nT3BlbiA9IG5lc3RlZE9wZW5EaWFsb2dDb3VudCA+IDA7XG4gIGNvbnN0IHNldFBvcHVwRWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlU2V0dGVyKCdwb3B1cEVsZW1lbnQnKTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgb3BlbixcbiAgICBuZXN0ZWQsXG4gICAgdHJhbnNpdGlvblN0YXR1cyxcbiAgICBuZXN0ZWREaWFsb2dPcGVuXG4gIH07XG4gIGNvbnN0IGVsZW1lbnQgPSB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHN0YXRlLFxuICAgIHByb3BzOiBbcm9vdFBvcHVwUHJvcHMsIHtcbiAgICAgIGlkOiBmbG9hdGluZ0lkLFxuICAgICAgJ2FyaWEtbGFiZWxsZWRieSc6IHRpdGxlRWxlbWVudElkLFxuICAgICAgJ2FyaWEtZGVzY3JpYmVkYnknOiBkZXNjcmlwdGlvbkVsZW1lbnRJZCxcbiAgICAgIHJvbGUsXG4gICAgICAuLi5GT0NVU0FCTEVfUE9QVVBfUFJPUFMsXG4gICAgICBoaWRkZW46ICFtb3VudGVkLFxuICAgICAgb25LZXlEb3duKGV2ZW50KSB7XG4gICAgICAgIGlmIChDT01QT1NJVEVfS0VZUy5oYXMoZXZlbnQua2V5KSkge1xuICAgICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgc3R5bGU6IHtcbiAgICAgICAgW0RpYWxvZ1BvcHVwQ3NzVmFycy5uZXN0ZWREaWFsb2dzXTogbmVzdGVkT3BlbkRpYWxvZ0NvdW50XG4gICAgICB9XG4gICAgfSwgZWxlbWVudFByb3BzXSxcbiAgICByZWY6IFtmb3J3YXJkZWRSZWYsIHN0b3JlLmNvbnRleHQucG9wdXBSZWYsIHNldFBvcHVwRWxlbWVudF0sXG4gICAgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZzogZGlhbG9nU3RhdGVBdHRyaWJ1dGVzTWFwcGluZ1xuICB9KTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KEZsb2F0aW5nRm9jdXNNYW5hZ2VyLCB7XG4gICAgY29udGV4dDogZmxvYXRpbmdSb290Q29udGV4dCxcbiAgICBvcGVuSW50ZXJhY3Rpb25UeXBlOiBvcGVuTWV0aG9kLFxuICAgIGRpc2FibGVkOiAhbW91bnRlZCxcbiAgICBjbG9zZU9uRm9jdXNPdXQ6ICFkaXNhYmxlUG9pbnRlckRpc21pc3NhbCxcbiAgICBpbml0aWFsRm9jdXM6IHJlc29sdmVkSW5pdGlhbEZvY3VzLFxuICAgIHJldHVybkZvY3VzOiBmaW5hbEZvY3VzLFxuICAgIG1vZGFsOiBtb2RhbCAhPT0gZmFsc2UsXG4gICAgcmVzdG9yZUZvY3VzOiBcInBvcHVwXCIsXG4gICAgY2hpbGRyZW46IGVsZW1lbnRcbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIERpYWxvZ1BvcHVwLmRpc3BsYXlOYW1lID0gXCJEaWFsb2dQb3B1cFwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgaW5lcnRWYWx1ZSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2luZXJ0VmFsdWUnO1xuaW1wb3J0IHsgRmxvYXRpbmdQb3J0YWwgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyB1c2VEaWFsb2dSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L0RpYWxvZ1Jvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgRGlhbG9nUG9ydGFsQ29udGV4dCB9IGZyb20gXCIuL0RpYWxvZ1BvcnRhbENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBJbnRlcm5hbEJhY2tkcm9wIH0gZnJvbSBcIi4uLy4uL3V0aWxzL0ludGVybmFsQmFja2Ryb3AubWpzXCI7XG5cbi8qKlxuICogQSBwb3J0YWwgZWxlbWVudCB0aGF0IG1vdmVzIHRoZSBwb3B1cCB0byBhIGRpZmZlcmVudCBwYXJ0IG9mIHRoZSBET00uXG4gKiBCeSBkZWZhdWx0LCB0aGUgcG9ydGFsIGVsZW1lbnQgaXMgYXBwZW5kZWQgdG8gYDxib2R5PmAuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIERpYWxvZ10oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL2RpYWxvZylcbiAqL1xuaW1wb3J0IHsganN4IGFzIF9qc3gsIGpzeHMgYXMgX2pzeHMgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCBjb25zdCBEaWFsb2dQb3J0YWwgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBEaWFsb2dQb3J0YWwocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAga2VlcE1vdW50ZWQgPSBmYWxzZSxcbiAgICAuLi5wb3J0YWxQcm9wc1xuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHN0b3JlID0gdXNlRGlhbG9nUm9vdENvbnRleHQoKTtcbiAgY29uc3QgbW91bnRlZCA9IHN0b3JlLnVzZVN0YXRlKCdtb3VudGVkJyk7XG4gIGNvbnN0IG1vZGFsID0gc3RvcmUudXNlU3RhdGUoJ21vZGFsJyk7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCBzaG91bGRSZW5kZXIgPSBtb3VudGVkIHx8IGtlZXBNb3VudGVkO1xuICBpZiAoIXNob3VsZFJlbmRlcikge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChEaWFsb2dQb3J0YWxDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IGtlZXBNb3VudGVkLFxuICAgIGNoaWxkcmVuOiAvKiNfX1BVUkVfXyovX2pzeHMoRmxvYXRpbmdQb3J0YWwsIHtcbiAgICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgICAgLi4ucG9ydGFsUHJvcHMsXG4gICAgICBjaGlsZHJlbjogW21vdW50ZWQgJiYgbW9kYWwgPT09IHRydWUgJiYgLyojX19QVVJFX18qL19qc3goSW50ZXJuYWxCYWNrZHJvcCwge1xuICAgICAgICByZWY6IHN0b3JlLmNvbnRleHQuaW50ZXJuYWxCYWNrZHJvcFJlZixcbiAgICAgICAgaW5lcnQ6IGluZXJ0VmFsdWUoIW9wZW4pXG4gICAgICB9KSwgcHJvcHMuY2hpbGRyZW5dXG4gICAgfSlcbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIERpYWxvZ1BvcnRhbC5kaXNwbGF5TmFtZSA9IFwiRGlhbG9nUG9ydGFsXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VEaWFsb2dSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L0RpYWxvZ1Jvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVuZGVyRWxlbWVudCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlUmVuZGVyRWxlbWVudC5tanNcIjtcbmltcG9ydCB7IHVzZUJhc2VVaUlkIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VCYXNlVWlJZC5tanNcIjtcbi8qKlxuICogQSBoZWFkaW5nIHRoYXQgbGFiZWxzIHRoZSBkaWFsb2cuXG4gKiBSZW5kZXJzIGFuIGA8aDI+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIERpYWxvZ10oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL2RpYWxvZylcbiAqL1xuZXhwb3J0IGNvbnN0IERpYWxvZ1RpdGxlID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gRGlhbG9nVGl0bGUoY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIGNsYXNzTmFtZSxcbiAgICBzdHlsZSxcbiAgICBpZDogaWRQcm9wLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IHN0b3JlID0gdXNlRGlhbG9nUm9vdENvbnRleHQoKTtcbiAgY29uc3QgaWQgPSB1c2VCYXNlVWlJZChpZFByb3ApO1xuICBzdG9yZS51c2VTeW5jZWRWYWx1ZVdpdGhDbGVhbnVwKCd0aXRsZUVsZW1lbnRJZCcsIGlkKTtcbiAgcmV0dXJuIHVzZVJlbmRlckVsZW1lbnQoJ2gyJywgY29tcG9uZW50UHJvcHMsIHtcbiAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICBwcm9wczogW3tcbiAgICAgIGlkXG4gICAgfSwgZWxlbWVudFByb3BzXVxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRGlhbG9nVGl0bGUuZGlzcGxheU5hbWUgPSBcIkRpYWxvZ1RpdGxlXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgX2Zvcm1hdEVycm9yTWVzc2FnZSBmcm9tIFwiQGJhc2UtdWkvdXRpbHMvZm9ybWF0RXJyb3JNZXNzYWdlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBmYXN0Q29tcG9uZW50UmVmIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZmFzdEhvb2tzJztcbmltcG9ydCB7IHVzZURpYWxvZ1Jvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvRGlhbG9nUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VCdXR0b24gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZS1idXR0b24vdXNlQnV0dG9uLm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVuZGVyRWxlbWVudCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlUmVuZGVyRWxlbWVudC5tanNcIjtcbmltcG9ydCB7IHRyaWdnZXJPcGVuU3RhdGVNYXBwaW5nIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwU3RhdGVNYXBwaW5nLm1qc1wiO1xuaW1wb3J0IHsgQ0xJQ0tfVFJJR0dFUl9JREVOVElGSUVSIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jb25zdGFudHMubWpzXCI7XG5pbXBvcnQgeyB1c2VQb3B1cEhhbmRsZVN0b3JlLCB1c2VUcmlnZ2VyRGF0YUZvcndhcmRpbmcgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBzL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQmFzZVVpSWQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZUJhc2VVaUlkLm1qc1wiO1xuaW1wb3J0IHsgdXNlQ2xpY2sgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyB1c2VPcGVuTWV0aG9kVHJpZ2dlclByb3BzIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3VzZU9wZW5JbnRlcmFjdGlvblR5cGUubWpzXCI7XG5cbi8qKlxuICogQSBidXR0b24gdGhhdCBvcGVucyB0aGUgZGlhbG9nLlxuICogUmVuZGVycyBhIGA8YnV0dG9uPmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBEaWFsb2ddKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9kaWFsb2cpXG4gKi9cbmV4cG9ydCBjb25zdCBEaWFsb2dUcmlnZ2VyID0gZmFzdENvbXBvbmVudFJlZihmdW5jdGlvbiBEaWFsb2dUcmlnZ2VyKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgZGlzYWJsZWQgPSBmYWxzZSxcbiAgICBuYXRpdmVCdXR0b24gPSB0cnVlLFxuICAgIGlkOiBpZFByb3AsXG4gICAgcGF5bG9hZCxcbiAgICBoYW5kbGUsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3QgZGlhbG9nUm9vdFN0b3JlID0gdXNlRGlhbG9nUm9vdENvbnRleHQodHJ1ZSk7XG4gIGNvbnN0IGhhbmRsZVN0b3JlID0gdXNlUG9wdXBIYW5kbGVTdG9yZShoYW5kbGUpO1xuICBjb25zdCBzdG9yZSA9IGhhbmRsZVN0b3JlID8/IGRpYWxvZ1Jvb3RTdG9yZTtcbiAgaWYgKCFzdG9yZSkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAnQmFzZSBVSTogPERpYWxvZy5UcmlnZ2VyPiBtdXN0IGJlIHVzZWQgd2l0aGluIDxEaWFsb2cuUm9vdD4gb3IgcHJvdmlkZWQgd2l0aCBhIGhhbmRsZS4nIDogX2Zvcm1hdEVycm9yTWVzc2FnZSg3OSkpO1xuICB9XG4gIGNvbnN0IHRoaXNUcmlnZ2VySWQgPSB1c2VCYXNlVWlJZChpZFByb3ApO1xuICBjb25zdCBmbG9hdGluZ0NvbnRleHQgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdSb290Q29udGV4dCcpO1xuICBjb25zdCBpc09wZW5lZEJ5VGhpc1RyaWdnZXIgPSBzdG9yZS51c2VTdGF0ZSgnaXNPcGVuZWRCeVRyaWdnZXInLCB0aGlzVHJpZ2dlcklkKTtcbiAgY29uc3QgcG9wdXBJZCA9IHN0b3JlLnVzZVN0YXRlKCd0cmlnZ2VyUG9wdXBJZCcsIHRoaXNUcmlnZ2VySWQpO1xuICBjb25zdCB0cmlnZ2VyRWxlbWVudFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3Qge1xuICAgIHJlZ2lzdGVyVHJpZ2dlcixcbiAgICBpc01vdW50ZWRCeVRoaXNUcmlnZ2VyXG4gIH0gPSB1c2VUcmlnZ2VyRGF0YUZvcndhcmRpbmcodGhpc1RyaWdnZXJJZCwgdHJpZ2dlckVsZW1lbnRSZWYsIHN0b3JlLCB7XG4gICAgcGF5bG9hZFxuICB9KTtcbiAgY29uc3Qge1xuICAgIGdldEJ1dHRvblByb3BzLFxuICAgIGJ1dHRvblJlZlxuICB9ID0gdXNlQnV0dG9uKHtcbiAgICBkaXNhYmxlZCxcbiAgICBuYXRpdmU6IG5hdGl2ZUJ1dHRvblxuICB9KTtcbiAgY29uc3QgY2xpY2sgPSB1c2VDbGljayhmbG9hdGluZ0NvbnRleHQpO1xuICBjb25zdCBpbnRlcmFjdGlvblR5cGVQcm9wcyA9IHVzZU9wZW5NZXRob2RUcmlnZ2VyUHJvcHMoKCkgPT4gc3RvcmUuc2VsZWN0KCdvcGVuJyksIGludGVyYWN0aW9uVHlwZSA9PiB7XG4gICAgc3RvcmUuc2V0KCdvcGVuTWV0aG9kJywgaW50ZXJhY3Rpb25UeXBlKTtcbiAgfSk7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIGRpc2FibGVkLFxuICAgIG9wZW46IGlzT3BlbmVkQnlUaGlzVHJpZ2dlclxuICB9O1xuICBjb25zdCByb290VHJpZ2dlclByb3BzID0gc3RvcmUudXNlU3RhdGUoJ3RyaWdnZXJQcm9wcycsIGlzTW91bnRlZEJ5VGhpc1RyaWdnZXIpO1xuICByZXR1cm4gdXNlUmVuZGVyRWxlbWVudCgnYnV0dG9uJywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICByZWY6IFtidXR0b25SZWYsIGZvcndhcmRlZFJlZiwgcmVnaXN0ZXJUcmlnZ2VyLCB0cmlnZ2VyRWxlbWVudFJlZl0sXG4gICAgcHJvcHM6IFtjbGljay5yZWZlcmVuY2UsIHJvb3RUcmlnZ2VyUHJvcHMsIGludGVyYWN0aW9uVHlwZVByb3BzLCB7XG4gICAgICBbQ0xJQ0tfVFJJR0dFUl9JREVOVElGSUVSXTogJycsXG4gICAgICBpZDogdGhpc1RyaWdnZXJJZCxcbiAgICAgICdhcmlhLWhhc3BvcHVwJzogJ2RpYWxvZycsXG4gICAgICAnYXJpYS1leHBhbmRlZCc6IGlzT3BlbmVkQnlUaGlzVHJpZ2dlcixcbiAgICAgICdhcmlhLWNvbnRyb2xzJzogcG9wdXBJZFxuICAgIH0sIGVsZW1lbnRQcm9wcywgZ2V0QnV0dG9uUHJvcHNdLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmc6IHRyaWdnZXJPcGVuU3RhdGVNYXBwaW5nXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBEaWFsb2dUcmlnZ2VyLmRpc3BsYXlOYW1lID0gXCJEaWFsb2dUcmlnZ2VyXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlRGlhbG9nUm9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9EaWFsb2dSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZURpYWxvZ1BvcnRhbENvbnRleHQgfSBmcm9tIFwiLi4vcG9ydGFsL0RpYWxvZ1BvcnRhbENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBkaWFsb2dTdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nIH0gZnJvbSBcIi4uL3V0aWxzL3N0YXRlQXR0cmlidXRlc01hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogQSBwb3NpdGlvbmluZyBjb250YWluZXIgZm9yIHRoZSBkaWFsb2cgcG9wdXAgdGhhdCBjYW4gYmUgbWFkZSBzY3JvbGxhYmxlLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBEaWFsb2ddKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9kaWFsb2cpXG4gKi9cbmV4cG9ydCBjb25zdCBEaWFsb2dWaWV3cG9ydCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIERpYWxvZ1ZpZXdwb3J0KGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgY2hpbGRyZW4sXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qga2VlcE1vdW50ZWQgPSB1c2VEaWFsb2dQb3J0YWxDb250ZXh0KCk7XG4gIGNvbnN0IHN0b3JlID0gdXNlRGlhbG9nUm9vdENvbnRleHQoKTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IG5lc3RlZCA9IHN0b3JlLnVzZVN0YXRlKCduZXN0ZWQnKTtcbiAgY29uc3QgdHJhbnNpdGlvblN0YXR1cyA9IHN0b3JlLnVzZVN0YXRlKCd0cmFuc2l0aW9uU3RhdHVzJyk7XG4gIGNvbnN0IG5lc3RlZE9wZW5EaWFsb2dDb3VudCA9IHN0b3JlLnVzZVN0YXRlKCduZXN0ZWRPcGVuRGlhbG9nQ291bnQnKTtcbiAgY29uc3QgbW91bnRlZCA9IHN0b3JlLnVzZVN0YXRlKCdtb3VudGVkJyk7XG4gIGNvbnN0IHNldFZpZXdwb3J0RWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlU2V0dGVyKCd2aWV3cG9ydEVsZW1lbnQnKTtcbiAgY29uc3QgbmVzdGVkRGlhbG9nT3BlbiA9IG5lc3RlZE9wZW5EaWFsb2dDb3VudCA+IDA7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIG9wZW4sXG4gICAgbmVzdGVkLFxuICAgIHRyYW5zaXRpb25TdGF0dXMsXG4gICAgbmVzdGVkRGlhbG9nT3BlblxuICB9O1xuICBjb25zdCBzaG91bGRSZW5kZXIgPSBrZWVwTW91bnRlZCB8fCBtb3VudGVkO1xuICByZXR1cm4gdXNlUmVuZGVyRWxlbWVudCgnZGl2JywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBlbmFibGVkOiBzaG91bGRSZW5kZXIsXG4gICAgc3RhdGUsXG4gICAgcmVmOiBbZm9yd2FyZGVkUmVmLCBzZXRWaWV3cG9ydEVsZW1lbnRdLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmc6IGRpYWxvZ1N0YXRlQXR0cmlidXRlc01hcHBpbmcsXG4gICAgcHJvcHM6IFt7XG4gICAgICByb2xlOiAncHJlc2VudGF0aW9uJyxcbiAgICAgIGhpZGRlbjogIW1vdW50ZWQsXG4gICAgICBzdHlsZToge1xuICAgICAgICBwb2ludGVyRXZlbnRzOiAhb3BlbiA/ICdub25lJyA6IHVuZGVmaW5lZFxuICAgICAgfSxcbiAgICAgIGNoaWxkcmVuXG4gICAgfSwgZWxlbWVudFByb3BzXVxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRGlhbG9nVmlld3BvcnQuZGlzcGxheU5hbWUgPSBcIkRpYWxvZ1ZpZXdwb3J0XCI7IiwiaW1wb3J0IHsgY3JlYXRlTnVsbERpYWxvZ1N0b3JlIH0gZnJvbSBcIi4vRGlhbG9nU3RvcmUubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5pbXBvcnQgeyBCYXNlUG9wdXBIYW5kbGUgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBzL3BvcHVwSGFuZGxlLm1qc1wiO1xuXG4vKipcbiAqIENvbnRyb2xzIGEgRGlhbG9nIGltcGVyYXRpdmVseSBhbmQgYXNzb2NpYXRlcyBkZXRhY2hlZCBgRGlhbG9nLlRyaWdnZXJgIGNvbXBvbmVudHMgd2l0aCBhXG4gKiBgRGlhbG9nLlJvb3RgLiBDcmVhdGUgb25lIHdpdGggYERpYWxvZy5jcmVhdGVIYW5kbGUoKWAgYW5kIHBhc3MgaXQgdG8gdGhlIGBoYW5kbGVgIHByb3Agb2YgdGhlXG4gKiByb290IGFuZCBvZiBhbnkgdHJpZ2dlcnMgcmVuZGVyZWQgb3V0c2lkZSBvZiBpdC5cbiAqXG4gKiBUaGUgaW1wZXJhdGl2ZSBtZXRob2RzIHRha2UgZWZmZWN0IG9ubHkgd2hpbGUgYSByb290IHVzaW5nIHRoaXMgaGFuZGxlIGlzIG1vdW50ZWQ7IGNhbGxzIG1hZGVcbiAqIGJlZm9yZSBhIHJvb3QgYXR0YWNoZXMgKG9yIGFmdGVyIGl0IHVubW91bnRzKSBhcmUgaWdub3JlZC5cbiAqL1xuZXhwb3J0IGNsYXNzIERpYWxvZ0hhbmRsZSBleHRlbmRzIEJhc2VQb3B1cEhhbmRsZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKGNyZWF0ZU51bGxEaWFsb2dTdG9yZSgpLCAnRGlhbG9nJywgZmFsc2UpO1xuICB9XG5cbiAgLyoqXG4gICAqIE9wZW5zIHRoZSBkaWFsb2csIG9wdGlvbmFsbHkgYXNzb2NpYXRpbmcgaXQgd2l0aCBhIHRyaWdnZXIuXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBpbiBhbiBldmVudCBoYW5kbGVyIG9yIGFuIGVmZmVjdCAobm90IGR1cmluZyByZW5kZXJpbmcpLlxuICAgKlxuICAgKiBAcGFyYW0gdHJpZ2dlcklkIElEIG9mIHRoZSB0cmlnZ2VyIHRvIGFzc29jaWF0ZSB3aXRoIHRoZSBkaWFsb2cuIFRoZSB0cmlnZ2VyIG11c3QgYmUgYSBtYXRjaGluZ1xuICAgKiBgRGlhbG9nLlRyaWdnZXJgIHdpdGggdGhpcyBoYW5kbGUgcGFzc2VkIGFzIGEgcHJvcC4gUGFzcyBgbnVsbGAgdG8gb3BlbiB3aXRob3V0IGFzc29jaWF0aW5nIGFueSB0cmlnZ2VyLlxuICAgKi9cbiAgb3Blbih0cmlnZ2VySWQpIHtcbiAgICB0aGlzLm9wZW5CeVRyaWdnZXIodHJpZ2dlcklkKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBPcGVucyB0aGUgZGlhbG9nIHdpdGggdGhlIGdpdmVuIHBheWxvYWQsIHdpdGhvdXQgYXNzb2NpYXRpbmcgaXQgd2l0aCBhbnkgdHJpZ2dlci5cbiAgICpcbiAgICogVGhpcyBtZXRob2Qgc2hvdWxkIG9ubHkgYmUgY2FsbGVkIGluIGFuIGV2ZW50IGhhbmRsZXIgb3IgYW4gZWZmZWN0IChub3QgZHVyaW5nIHJlbmRlcmluZykuXG4gICAqXG4gICAqIEBwYXJhbSBwYXlsb2FkIFBheWxvYWQgdG8gc2V0IHdoZW4gb3BlbmluZyB0aGUgZGlhbG9nLiBJdCBpcyBleHBvc2VkIHRvIHRoZSByb290J3MgcmVuZGVyLXByb3AgY2hpbGRyZW4uXG4gICAqL1xuICBvcGVuV2l0aFBheWxvYWQocGF5bG9hZCkge1xuICAgIGNvbnN0IGF0dGFjaGVkU3RvcmUgPSB0aGlzLmF0dGFjaGVkU3RvcmU7XG4gICAgaWYgKGF0dGFjaGVkU3RvcmUgPT09IG51bGwpIHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICAgIGNvbnNvbGUud2FybignQmFzZSBVSTogRGlhbG9nSGFuZGxlLm9wZW5XaXRoUGF5bG9hZCgpIHdhcyBjYWxsZWQgd2hpbGUgbm8gcm9vdCB1c2luZyB0aGlzIGhhbmRsZSBpcyBtb3VudGVkLiAnICsgJ1RoZSBjYWxsIGFuZCBpdHMgcGF5bG9hZCB3ZXJlIGlnbm9yZWQ7IG1vdW50IGEgcm9vdCB3aXRoIHRoaXMgaGFuZGxlIGJlZm9yZSBvcGVuaW5nIGl0IGltcGVyYXRpdmVseS4nKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgYXR0YWNoZWRTdG9yZS5zZXQoJ3BheWxvYWQnLCBwYXlsb2FkKTtcbiAgICBhdHRhY2hlZFN0b3JlLnNldE9wZW4odHJ1ZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuaW1wZXJhdGl2ZUFjdGlvbikpO1xuICB9XG5cbiAgLyoqXG4gICAqIENsb3NlcyB0aGUgZGlhbG9nLlxuICAgKlxuICAgKiBUaGlzIG1ldGhvZCBzaG91bGQgb25seSBiZSBjYWxsZWQgaW4gYW4gZXZlbnQgaGFuZGxlciBvciBhbiBlZmZlY3QgKG5vdCBkdXJpbmcgcmVuZGVyaW5nKS5cbiAgICovXG4gIGNsb3NlKCkge1xuICAgIHRoaXMuY2xvc2VQb3B1cCgpO1xuICB9XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIGRpYWxvZyBpcyBjdXJyZW50bHkgb3Blbi4gUmV0dXJucyBgZmFsc2VgIHdoaWxlIG5vIHJvb3QgaXMgYXR0YWNoZWQgdG8gdGhlIGhhbmRsZS5cbiAgICovXG4gIGdldCBpc09wZW4oKSB7XG4gICAgcmV0dXJuIHRoaXMuYXR0YWNoZWRTdG9yZT8uc2VsZWN0KCdvcGVuJykgPz8gZmFsc2U7XG4gIH1cbn1cblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IGhhbmRsZSB0byBjb25uZWN0IGEgRGlhbG9nLlJvb3Qgd2l0aCBkZXRhY2hlZCBEaWFsb2cuVHJpZ2dlciBjb21wb25lbnRzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlRGlhbG9nSGFuZGxlKCkge1xuICByZXR1cm4gbmV3IERpYWxvZ0hhbmRsZSgpO1xufSIsImltcG9ydCB7IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBkaWFsb2cgaXMgb3Blbi5cbiAqL1xuZXhwb3J0IGNvbnN0IG9wZW4gPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW47XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgZGlhbG9nIGlzIGNsb3NlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGNsb3NlZCA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuY2xvc2VkO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGRpYWxvZyBiZWdpbnMgYW5pbWF0aW5nIGluLlxuICovXG5leHBvcnQgY29uc3Qgc3RhcnRpbmdTdHlsZSA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuc3RhcnRpbmdTdHlsZTtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBkaWFsb2cgaXMgYW5pbWF0aW5nIG91dC5cbiAqL1xuZXhwb3J0IGNvbnN0IGVuZGluZ1N0eWxlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5lbmRpbmdTdHlsZTsiLCIvKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgYnV0dG9uIGlzIGRpc2FibGVkLlxuICovXG5leHBvcnQgY29uc3QgZGlzYWJsZWQgPSAnZGF0YS1kaXNhYmxlZCc7IiwiaW1wb3J0IHsgQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGRpYWxvZyBpcyBvcGVuLlxuICovXG5leHBvcnQgY29uc3Qgb3BlbiA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMub3Blbjtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBkaWFsb2cgaXMgY2xvc2VkLlxuICovXG5leHBvcnQgY29uc3QgY2xvc2VkID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5jbG9zZWQ7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgZGlhbG9nIGJlZ2lucyBhbmltYXRpbmcgaW4uXG4gKi9cbmV4cG9ydCBjb25zdCBzdGFydGluZ1N0eWxlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zdGFydGluZ1N0eWxlO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGRpYWxvZyBpcyBhbmltYXRpbmcgb3V0LlxuICovXG5leHBvcnQgY29uc3QgZW5kaW5nU3R5bGUgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmVuZGluZ1N0eWxlO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGRpYWxvZyBpcyBuZXN0ZWQgd2l0aGluIGFub3RoZXIgZGlhbG9nLlxuICovXG5leHBvcnQgY29uc3QgbmVzdGVkID0gJ2RhdGEtbmVzdGVkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBkaWFsb2cgaGFzIG90aGVyIG9wZW4gZGlhbG9ncyBuZXN0ZWQgd2l0aGluIGl0LlxuICovXG5leHBvcnQgY29uc3QgbmVzdGVkRGlhbG9nT3BlbiA9ICdkYXRhLW5lc3RlZC1kaWFsb2ctb3Blbic7Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQVFBLFNBQWdCLG1CQUFtQixFQUNqQyxPQUNBLGVBQ0EsWUFDQztDQUNELE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLFVBQVUsTUFBTSxTQUFTLFNBQVM7Q0FDeEMsTUFBTSwwQkFBMEIsTUFBTSxTQUFTLHlCQUF5QjtDQUN4RSxNQUFNLFFBQVEsTUFBTSxTQUFTLE9BQU87Q0FDcEMsTUFBTSxlQUFlLE1BQU0sU0FBUyxjQUFjO0NBQ2xELE1BQU0sc0JBQXNCLE1BQU0sU0FBUyxxQkFBcUI7Q0FDaEUsTUFBTSxDQUFDLHNCQUFzQiwyQkFBQSxhQUFpQyxTQUFTLENBQUM7Q0FDeEUsTUFBTSxDQUFDLHNCQUFzQiwyQkFBQSxhQUFpQyxTQUFTLENBQUM7Q0FDeEUsTUFBTSxZQUFZLHlCQUF5QjtDQUMzQyxNQUFNLFVBQVUsV0FBVyxxQkFBcUI7RUFDOUMsb0JBQW9CO0dBQ2xCLElBQUksTUFBTSxRQUFRLG9CQUFvQixXQUFXLE1BQU0sUUFBUSxZQUFZLFNBQ3pFLE9BQU87R0FJVCxPQUFPO0lBQ0wsT0FBTyxVQUFVLGVBQWUsV0FBVztJQUMzQyxPQUFPO0dBQ1Q7RUFDRjtFQUNBLGFBQWEsT0FBTztHQUNsQixJQUFJLENBQUMsTUFBTSxRQUFRLHVCQUF1QixTQUN4QyxPQUFPO0dBS1QsSUFBSSxZQUFZLFNBQVMsTUFBTSxXQUFXLEdBQ3hDLE9BQU87R0FFVCxJQUFJLGFBQWEsT0FBTztJQUt0QixJQUFJLE1BQU0sU0FBUyxZQUNiO1NBQUEsTUFBTSxlQUFlLFdBQVcsS0FBSyxNQUFNLFFBQVEsV0FBVyxHQUNoRSxPQUFPO0lBQUEsT0FFSixJQUFJLE1BQU0sUUFBUSxXQUFXLEdBQ2xDLE9BQU87R0FFWDtHQUNBLE1BQU0sU0FBUyxVQUFVLEtBQUs7R0FDOUIsSUFBSSxhQUFhLENBQUMseUJBQXlCO0lBSXpDLElBQUksT0FBTztLQUNULE1BQU0sbUJBQW1CLE1BQU0sUUFBUSxvQkFBb0I7S0FDM0QsTUFBTSxXQUFXLE1BQU0sUUFBUSxZQUFZO0tBQzNDLE9BQU8sb0JBQW9CLFdBQVcscUJBQXFCLFVBQVUsYUFBYSxVQUFVLFNBQVMsUUFBUSxZQUFZLEtBQUssQ0FBQyxRQUFRLGFBQWEscUJBQXFCLElBQUk7SUFDL0s7SUFDQSxPQUFPO0dBQ1Q7R0FDQSxPQUFPO0VBQ1Q7RUFDQSxXQUFXO0NBQ2IsQ0FBQztDQUNELGNBQWMsUUFBUSxVQUFVLE1BQU0sWUFBWTtDQUlsRCxNQUFNLG1CQUFtQix1QkFBdUIsYUFBYSxnQkFBZ0I7RUFHM0UsSUFBSSxDQUFDLE1BQU0sT0FBTyxNQUFNLEtBQUssQ0FBQyxNQUFNLE9BQU8sU0FBUyxHQUNsRDtFQUVGLHdCQUF3QixXQUFXO0VBQ25DLHdCQUF3QixXQUFXO0NBQ3JDLENBQUM7Q0FDRCx5QkFBeUI7RUFDdkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTO0dBQ3JCLHdCQUF3QixDQUFDO0dBQ3pCLHdCQUF3QixDQUFDO0VBQzNCO0NBQ0YsR0FBRyxDQUFDLE1BQU0sT0FBTyxDQUFDO0NBR2xCLHlCQUF5QjtFQUN2QixJQUFJLGVBQWUsb0JBQ2I7T0FBQSxNQUNGLGNBQWMsbUJBQW1CLHVCQUF1QixHQUFHLHdCQUF3QixXQUFXLElBQUksRUFBRTtFQUFBO0VBR3hHLGFBQWE7R0FDWCxJQUFJLGVBQWUsc0JBQXNCLE1BQ3ZDLGNBQWMsbUJBQW1CLEdBQUcsQ0FBQztFQUV6QztDQUNGLEdBQUc7RUFBQztFQUFVO0VBQU07RUFBc0I7RUFBc0I7Q0FBYSxDQUFDO0NBQzlFLHlCQUF5QixPQUFPO0VBRzlCLG9CQUFvQixRQUFRO0VBQzVCLHNCQUFzQixRQUFRO0VBRzlCLFlBQVksUUFBUTtFQUNwQix1QkFBdUI7RUFDdkIsdUJBQXVCO0NBQ3pCLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7O0FDbEhBLElBQWEsb0JBQWlDLDJCQUFNLGNBQWMsS0FBQSxDQUFTO0FBQ2hDLGtCQUFrQixjQUFjO0FBQzNFLFNBQWdCLHFCQUFxQixVQUFVO0NBQzdDLE1BQU0sUUFBQSxhQUFjLFdBQVcsaUJBQWlCO0NBQ2hELElBQUksQ0FBQyxZQUFZLFVBQVUsS0FBQSxHQUN6QixNQUFNLElBQUksTUFBOEMsMEZBQW9IO0NBRTlLLE9BQU87QUFDVDs7QUNSQSxJQUFNLFlBQVk7Q0FDaEIsR0FBRztDQUNILFFBQU8sVUFBUyxNQUFNO0NBQ3RCLFNBQVEsVUFBUyxNQUFNO0NBQ3ZCLHdCQUF1QixVQUFTLE1BQU07Q0FDdEMsd0JBQXVCLFVBQVMsTUFBTTtDQUN0QywwQkFBeUIsVUFBUyxNQUFNO0NBQ3hDLGFBQVksVUFBUyxNQUFNO0NBQzNCLHVCQUFzQixVQUFTLE1BQU07Q0FDckMsaUJBQWdCLFVBQVMsTUFBTTtDQUMvQixrQkFBaUIsVUFBUyxNQUFNO0NBQ2hDLE9BQU0sVUFBUyxNQUFNO0FBQ3ZCOzs7Ozs7QUFRQSxJQUFhLGNBQWIsY0FBaUMsV0FBVztDQUMxQyxZQUFZLGNBQWMsWUFBWSxRQUFRO0VBQzVDLE1BQU0sa0JBQWtCLElBQUksZ0JBQWdCO0VBQzVDLE1BQU0sUUFBUSxtQkFBbUIsY0FBYyxpQkFBaUIsWUFBWSxNQUFNO0VBQ2xGLE1BQU0sT0FBTyxxQkFBcUIsZUFBZSxHQUFHLFNBQVM7Q0FDL0Q7Q0FDQSxXQUFXLFVBQVUsaUJBQWlCO0VBQ3BDLGFBQWEsOEJBQThCO0dBQ3pDLEtBQUssSUFBSSw0QkFBNEIsSUFBSTtFQUMzQztFQUNBLElBQUksQ0FBQyxZQUFZLGFBQWEsV0FBVyxRQUFRLEtBQUssTUFBTSxtQkFBbUIsTUFHN0UsYUFBYSxVQUFVLEtBQUssTUFBTSx3QkFBd0IsS0FBQTtFQUU1RCxLQUFLLFFBQVEsZUFBZSxVQUFVLFlBQVk7RUFDbEQsSUFBSSxhQUFhLFlBQ2Y7RUFFRixLQUFLLE1BQU0sb0JBQW9CLG1CQUFtQixVQUFVLFlBQVk7RUFDeEUsS0FBSyxPQUFPLHFCQUFxQixLQUFLLE9BQU8sVUFBVSxhQUFhLE9BQU8sQ0FBQztDQUM5RTtBQUNGOzs7Ozs7QUFPQSxTQUFnQix3QkFBd0I7Q0FDdEMsTUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0I7Q0FDNUMsT0FBTyxJQUFJLFVBQVUsT0FBTyxPQUFPLG1CQUFtQixLQUFBLEdBQVcsZUFBZSxDQUFDLEdBQUcsT0FBTyxPQUFPLHFCQUFxQixlQUFlLENBQUMsR0FBRyxTQUFTO0FBQ3JKO0FBQ0EsU0FBUyxtQkFBbUIsY0FBYyxpQkFBaUIsWUFBWSxTQUFTLE9BQU87Q0FlckYsT0FBTztFQWJMLEdBQUcsNkJBQTZCLGlCQUFpQixZQUFZLE1BQU07RUFDbkUsT0FBTztFQUNQLHlCQUF5QjtFQUN6QixpQkFBaUI7RUFDakIsc0JBQXNCLEtBQUE7RUFDdEIsZ0JBQWdCLEtBQUE7RUFDaEIsWUFBWTtFQUNaLFFBQVE7RUFDUix1QkFBdUI7RUFDdkIsdUJBQXVCO0VBQ3ZCLE1BQU07RUFDTixHQUFHO0NBRU07QUFDYjtBQUNBLFNBQVMscUJBQXFCLGlCQUFpQjtDQUM3QyxPQUFPO0VBQ0wsVUFBdUIsMkJBQU0sVUFBVTtFQUN2QyxhQUEwQiwyQkFBTSxVQUFVO0VBQzFDLHFCQUFrQywyQkFBTSxVQUFVO0VBQ2xELHdCQUF3QixFQUN0QixTQUFTLEtBQ1g7RUFDQTtFQUNBLGNBQWMsS0FBQTtFQUNkLHNCQUFzQixLQUFBO0NBQ3hCO0FBQ0Y7OztBQzVFQSxTQUFnQixvQkFBb0IsTUFBTSxPQUFPO0NBQy9DLE1BQU0sRUFDSixVQUNBLE1BQU0sVUFDTixjQUFjLE9BQ2QsY0FDQSxzQkFDQSx5QkFBeUIsOEJBQThCLE9BQ3ZELE9BQU8sWUFBWSxNQUNuQixZQUNBLFFBQ0EsV0FBVyxlQUNYLGtCQUFrQix1QkFBdUIsU0FDdkM7Q0FDSixNQUFNLFdBQVcsU0FBUztDQUMxQixNQUFNLGdCQUFnQixTQUFTO0NBQy9CLE1BQU0sUUFBUSxnQkFBZ0IsT0FBTztDQUNyQyxNQUFNLDBCQUEwQixpQkFBaUI7Q0FDakQsTUFBTSxPQUFPLGdCQUFnQixnQkFBZ0I7Q0FDN0MsTUFBTSxjQUFjLHFCQUFxQixJQUFJO0NBRTdDLE1BQU0sWUFBWTtFQUNoQjtFQUNBO0VBQ0EsUUFKYSxlQUFlO0VBSzVCO0NBQ0Y7Q0FNQSxNQUFNLFFBQVEsbUJBQW1CLFlBQVksbUJBQW1CLElBQUksWUFBWTtFQUM5RSxNQUFNO0VBQ047RUFDQSxpQkFBaUI7RUFDakI7RUFDQSxHQUFHO0NBQ0wsR0FBRyxZQUFZLGNBQWMsR0FBRyxJQUFJO0NBQ3BDLE1BQU0sa0JBQWtCLFlBQVksUUFBUTtDQUM1QyxNQUFNLGtCQUFrQixpQkFBaUIsYUFBYTtDQUN0RCxNQUFNLGdCQUFnQixTQUFTO0NBQy9CLE1BQU0sbUJBQW1CLGdCQUFnQixZQUFZO0NBQ3JELE1BQU0sbUJBQW1CLHdCQUF3QixvQkFBb0I7Q0FDckUsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sVUFBVSxNQUFNLFNBQVMsU0FBUztDQUN4QyxNQUFNLFVBQVUsTUFBTSxTQUFTLFNBQVM7Q0FDeEMsaUJBQWlCLE9BQU8sSUFBSTtDQUM1Qix5QkFBeUIsS0FBSztDQUM5QixNQUFNLEVBQ0osaUJBQ0Usd0JBQXdCLE1BQU0sS0FBSztDQUN2QyxhQUFNLG9CQUFvQixtQkFBbUI7RUFDM0MsU0FBUztFQUNULGFBQWEsTUFBTSxRQUFRLE9BQU8seUJBQXlCQSxnQkFBd0IsQ0FBQztDQUN0RixJQUFJLENBQUMsY0FBYyxLQUFLLENBQUM7Q0FLekIsTUFBTSwyQkFBMkIsUUFBUSxXQUFXLFVBQVU7Q0FDOUQsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBTSxrQkFBa0IsVUFBVTtFQUNwRCxPQUFPO0VBQ1AsVUFBVTtHQUFDLFVBQXVCLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssdUJBQXVCO0lBQ3BEO0lBQ0Q7R0FDVCxDQUFDO0dBQUcsNEJBQXlDLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssb0JBQW9CO0lBQzdEO0lBQ1AsZUFBZSxhQUFhO0lBQ2xCO0dBQ1osQ0FBQztHQUFHLE9BQU8sYUFBYSxhQUFhLFNBQVMsRUFDNUMsUUFDRixDQUFDLElBQUk7RUFBUTtDQUNmLENBQUM7QUFDSDs7Ozs7Ozs7QUN2RUEsSUFBYSxpQkFBOEIsMkJBQU0sV0FBVyxTQUFTLGVBQWUsZ0JBQWdCLGNBQWM7Q0FDaEgsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLGNBQWMsT0FDZCxHQUFHLGlCQUNEO0NBQ0osTUFBTSxRQUFRLHFCQUFxQjtDQUNuQyxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxTQUFTLE1BQU0sU0FBUyxRQUFRO0NBQ3RDLE1BQU0sVUFBVSxNQUFNLFNBQVMsU0FBUztDQUV4QyxNQUFNLFFBQVE7RUFDWjtFQUNBLGtCQUh1QixNQUFNLFNBQVMsa0JBR3ZCO0NBQ2pCO0NBQ0EsT0FBTyxpQkFBaUIsT0FBTyxnQkFBZ0I7RUFDN0M7RUFDQSxLQUFLLENBQUMsTUFBTSxRQUFRLGFBQWEsWUFBWTtFQUM3Qyx3QkFBd0I7RUFDeEIsT0FBTyxDQUFDO0dBQ04sTUFBTTtHQUNOLFFBQVEsQ0FBQztHQUNULE9BQU87SUFDTCxZQUFZO0lBQ1osa0JBQWtCO0dBQ3BCO0VBQ0YsR0FBRyxZQUFZO0VBQ2YsU0FBUyxlQUFlLENBQUM7Q0FDM0IsQ0FBQztBQUNILENBQUM7QUFDMEMsZUFBZSxjQUFjOzs7Ozs7OztBQzlCeEUsSUFBYSxjQUEyQiwyQkFBTSxXQUFXLFNBQVMsWUFBWSxnQkFBZ0IsY0FBYztDQUMxRyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsV0FBVyxPQUNYLGVBQWUsTUFDZixHQUFHLGlCQUNEO0NBQ0osTUFBTSxRQUFRLHFCQUFxQjtDQUNuQyxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxFQUNKLGdCQUNBLGNBQ0UsVUFBVTtFQUNaO0VBQ0EsUUFBUTtDQUNWLENBQUM7Q0FDRCxNQUFNLFFBQVEsRUFDWixTQUNGO0NBQ0EsU0FBUyxZQUFZLE9BQU87RUFDMUIsSUFBSSxNQUNGLE1BQU0sUUFBUSxPQUFPLHlCQUF5QkMsWUFBb0IsTUFBTSxXQUFXLENBQUM7Q0FFeEY7Q0FDQSxPQUFPLGlCQUFpQixVQUFVLGdCQUFnQjtFQUNoRDtFQUNBLEtBQUssQ0FBQyxjQUFjLFNBQVM7RUFDN0IsT0FBTztHQUFDLEVBQ04sU0FBUyxZQUNYO0dBQUc7R0FBYztFQUFjO0NBQ2pDLENBQUM7QUFDSCxDQUFDO0FBQzBDLFlBQVksY0FBYzs7Ozs7Ozs7QUNyQ3JFLElBQWEsb0JBQWlDLDJCQUFNLFdBQVcsU0FBUyxrQkFBa0IsZ0JBQWdCLGNBQWM7Q0FDdEgsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLElBQUksUUFDSixHQUFHLGlCQUNEO0NBQ0osTUFBTSxRQUFRLHFCQUFxQjtDQUNuQyxNQUFNLEtBQUssWUFBWSxNQUFNO0NBQzdCLE1BQU0sMEJBQTBCLHdCQUF3QixFQUFFO0NBQzFELE9BQU8saUJBQWlCLEtBQUssZ0JBQWdCO0VBQzNDLEtBQUs7RUFDTCxPQUFPLENBQUMsRUFDTixHQUNGLEdBQUcsWUFBWTtDQUNqQixDQUFDO0FBQ0gsQ0FBQztBQUMwQyxrQkFBa0IsY0FBYzs7QUMxQjNFLElBQWEsc0JBQW1DLDJCQUFNLGNBQWMsS0FBQSxDQUFTO0FBQ2xDLG9CQUFvQixjQUFjO0FBQzdFLFNBQWdCLHlCQUF5QjtDQUN2QyxNQUFNLFFBQUEsYUFBYyxXQUFXLG1CQUFtQjtDQUNsRCxJQUFJLFVBQVUsS0FBQSxHQUNaLE1BQU0sSUFBSSxNQUE4QyxzQ0FBZ0U7Q0FFMUgsT0FBTztBQUNUOzs7Ozs7O0FDUkEsSUFBYSxnQkFBZ0I7Ozs7Ozs7Ozs7Ozs7QUNDN0IsSUFBYUMsU0FBT0M7Ozs7QUFJcEIsSUFBYUMsV0FBU0M7Ozs7QUFJdEIsSUFBYUMsa0JBQWdCQzs7OztBQUk3QixJQUFhQyxnQkFBY0M7Ozs7QUFJM0IsSUFBYUMsV0FBUzs7OztBQUl0QixJQUFhQyxxQkFBbUI7Ozs7OztBQ2pCaEMsSUFBYSwrQkFBK0I7Q0FDMUMsR0FBRztDQUNILEdBQUc7Q0FDSCxpQkFBaUIsT0FBTztFQUN0QixPQUFPLFFBQVEsR0FDWkMscUJBQTZDLEdBQ2hELElBQUk7Q0FDTjtBQUNGOzs7Ozs7OztBQ0lBLElBQWEsY0FBMkIsMkJBQU0sV0FBVyxTQUFTLFlBQVksZ0JBQWdCLGNBQWM7Q0FDMUcsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLFlBQ0EsY0FDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxRQUFRLHFCQUFxQjtDQUNuQyxNQUFNLHVCQUF1QixNQUFNLFNBQVMsc0JBQXNCO0NBQ2xFLE1BQU0sMEJBQTBCLE1BQU0sU0FBUyx5QkFBeUI7Q0FDeEUsTUFBTSxzQkFBc0IsTUFBTSxTQUFTLHFCQUFxQjtDQUNoRSxNQUFNLGlCQUFpQixNQUFNLFNBQVMsWUFBWTtDQUNsRCxNQUFNLFFBQVEsTUFBTSxTQUFTLE9BQU87Q0FDcEMsTUFBTSxVQUFVLE1BQU0sU0FBUyxTQUFTO0NBQ3hDLE1BQU0sU0FBUyxNQUFNLFNBQVMsUUFBUTtDQUN0QyxNQUFNLHdCQUF3QixNQUFNLFNBQVMsdUJBQXVCO0NBQ3BFLE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLGFBQWEsTUFBTSxTQUFTLFlBQVk7Q0FDOUMsTUFBTSxpQkFBaUIsTUFBTSxTQUFTLGdCQUFnQjtDQUN0RCxNQUFNLG1CQUFtQixNQUFNLFNBQVMsa0JBQWtCO0NBQzFELE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLGFBQWEsb0JBQW9CLFNBQVMsWUFBWTtDQUM1RCx1QkFBdUI7Q0FDdkIsc0JBQXNCO0VBQ3BCO0VBQ0EsS0FBSyxNQUFNLFFBQVE7RUFDbkIsYUFBYTtHQUNYLElBQUksTUFDRixNQUFNLFFBQVEsdUJBQXVCLElBQUk7RUFFN0M7Q0FDRixDQUFDO0NBQ0QsTUFBTSx1QkFBdUIsaUJBQWlCLEtBQUEsSUFBWSwwQkFBMEIsTUFBTSxRQUFRLFFBQVEsSUFBSTtDQUM5RyxNQUFNLG1CQUFtQix3QkFBd0I7Q0FDakQsTUFBTSxrQkFBa0IsTUFBTSxlQUFlLGNBQWM7Q0FPM0QsTUFBTSxVQUFVLGlCQUFpQixPQUFPLGdCQUFnQjtFQUN0RCxPQUFBO0dBTkE7R0FDQTtHQUNBO0dBQ0E7RUFHSTtFQUNKLE9BQU87R0FBQztHQUFnQjtJQUN0QixJQUFJO0lBQ0osbUJBQW1CO0lBQ25CLG9CQUFvQjtJQUNwQjtJQUNBLEdBQUc7SUFDSCxRQUFRLENBQUM7SUFDVCxVQUFVLE9BQU87S0FDZixJQUFJLGVBQWUsSUFBSSxNQUFNLEdBQUcsR0FDOUIsTUFBTSxnQkFBZ0I7SUFFMUI7SUFDQSxPQUFPLEdBQ0pDLGdCQUFtQyxzQkFDdEM7R0FDRjtHQUFHO0VBQVk7RUFDZixLQUFLO0dBQUM7R0FBYyxNQUFNLFFBQVE7R0FBVTtFQUFlO0VBQzNELHdCQUF3QjtDQUMxQixDQUFDO0NBQ0QsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxzQkFBc0I7RUFDN0MsU0FBUztFQUNULHFCQUFxQjtFQUNyQixVQUFVLENBQUM7RUFDWCxpQkFBaUIsQ0FBQztFQUNsQixjQUFjO0VBQ2QsYUFBYTtFQUNiLE9BQU8sVUFBVTtFQUNqQixjQUFjO0VBQ2QsVUFBVTtDQUNaLENBQUM7QUFDSCxDQUFDO0FBQzBDLFlBQVksY0FBYzs7Ozs7Ozs7O0FDL0VyRSxJQUFhLGVBQTRCLDJCQUFNLFdBQVcsU0FBUyxhQUFhLE9BQU8sY0FBYztDQUNuRyxNQUFNLEVBQ0osY0FBYyxPQUNkLEdBQUcsZ0JBQ0Q7Q0FDSixNQUFNLFFBQVEscUJBQXFCO0NBQ25DLE1BQU0sVUFBVSxNQUFNLFNBQVMsU0FBUztDQUN4QyxNQUFNLFFBQVEsTUFBTSxTQUFTLE9BQU87Q0FDcEMsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBRWxDLElBQUksRUFEaUIsV0FBVyxjQUU5QixPQUFPO0NBRVQsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxvQkFBb0IsVUFBVTtFQUNyRCxPQUFPO0VBQ1AsVUFBdUIsZUFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBTSxnQkFBZ0I7R0FDM0MsS0FBSztHQUNMLEdBQUc7R0FDSCxVQUFVLENBQUMsV0FBVyxVQUFVLFFBQXFCLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssa0JBQWtCO0lBQzFFLEtBQUssTUFBTSxRQUFRO0lBQ25CLE9BQU8sV0FBVyxDQUFDLElBQUk7R0FDekIsQ0FBQyxHQUFHLE1BQU0sUUFBUTtFQUNwQixDQUFDO0NBQ0gsQ0FBQztBQUNILENBQUM7QUFDMEMsYUFBYSxjQUFjOzs7Ozs7OztBQzlCdEUsSUFBYSxjQUEyQiwyQkFBTSxXQUFXLFNBQVMsWUFBWSxnQkFBZ0IsY0FBYztDQUMxRyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsSUFBSSxRQUNKLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLFFBQVEscUJBQXFCO0NBQ25DLE1BQU0sS0FBSyxZQUFZLE1BQU07Q0FDN0IsTUFBTSwwQkFBMEIsa0JBQWtCLEVBQUU7Q0FDcEQsT0FBTyxpQkFBaUIsTUFBTSxnQkFBZ0I7RUFDNUMsS0FBSztFQUNMLE9BQU8sQ0FBQyxFQUNOLEdBQ0YsR0FBRyxZQUFZO0NBQ2pCLENBQUM7QUFDSCxDQUFDO0FBQzBDLFlBQVksY0FBYzs7Ozs7Ozs7QUNUckUsSUFBYSxnQkFBZ0IsaUJBQWlCLFNBQVMsY0FBYyxnQkFBZ0IsY0FBYztDQUNqRyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsV0FBVyxPQUNYLGVBQWUsTUFDZixJQUFJLFFBQ0osU0FDQSxRQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLGtCQUFrQixxQkFBcUIsSUFBSTtDQUVqRCxNQUFNLFFBRGMsb0JBQW9CLE1BQ2hCLEtBQUs7Q0FDN0IsSUFBSSxDQUFDLE9BQ0gsTUFBTSxJQUFJLE1BQThDLHdGQUFrSDtDQUU1SyxNQUFNLGdCQUFnQixZQUFZLE1BQU07Q0FDeEMsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLHFCQUFxQjtDQUM1RCxNQUFNLHdCQUF3QixNQUFNLFNBQVMscUJBQXFCLGFBQWE7Q0FDL0UsTUFBTSxVQUFVLE1BQU0sU0FBUyxrQkFBa0IsYUFBYTtDQUM5RCxNQUFNLG9CQUFBLGFBQTBCLE9BQU8sSUFBSTtDQUMzQyxNQUFNLEVBQ0osaUJBQ0EsMkJBQ0UseUJBQXlCLGVBQWUsbUJBQW1CLE9BQU8sRUFDcEUsUUFDRixDQUFDO0NBQ0QsTUFBTSxFQUNKLGdCQUNBLGNBQ0UsVUFBVTtFQUNaO0VBQ0EsUUFBUTtDQUNWLENBQUM7Q0FDRCxNQUFNLFFBQVEsU0FBUyxlQUFlO0NBQ3RDLE1BQU0sdUJBQXVCLGdDQUFnQyxNQUFNLE9BQU8sTUFBTSxJQUFHLG9CQUFtQjtFQUNwRyxNQUFNLElBQUksY0FBYyxlQUFlO0NBQ3pDLENBQUM7Q0FDRCxNQUFNLFFBQVE7RUFDWjtFQUNBLE1BQU07Q0FDUjtDQUNBLE1BQU0sbUJBQW1CLE1BQU0sU0FBUyxnQkFBZ0Isc0JBQXNCO0NBQzlFLE9BQU8saUJBQWlCLFVBQVUsZ0JBQWdCO0VBQ2hEO0VBQ0EsS0FBSztHQUFDO0dBQVc7R0FBYztHQUFpQjtFQUFpQjtFQUNqRSxPQUFPO0dBQUMsTUFBTTtHQUFXO0dBQWtCO0dBQXNCO0tBQzlELDJCQUEyQjtJQUM1QixJQUFJO0lBQ0osaUJBQWlCO0lBQ2pCLGlCQUFpQjtJQUNqQixpQkFBaUI7R0FDbkI7R0FBRztHQUFjO0VBQWM7RUFDL0Isd0JBQXdCO0NBQzFCLENBQUM7QUFDSCxDQUFDO0FBQzBDLGNBQWMsY0FBYzs7Ozs7Ozs7QUNqRXZFLElBQWEsaUJBQThCLDJCQUFNLFdBQVcsU0FBUyxlQUFlLGdCQUFnQixjQUFjO0NBQ2hILE1BQU0sRUFDSixRQUNBLFdBQ0EsT0FDQSxVQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLGNBQWMsdUJBQXVCO0NBQzNDLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sU0FBUyxNQUFNLFNBQVMsUUFBUTtDQUN0QyxNQUFNLG1CQUFtQixNQUFNLFNBQVMsa0JBQWtCO0NBQzFELE1BQU0sd0JBQXdCLE1BQU0sU0FBUyx1QkFBdUI7Q0FDcEUsTUFBTSxVQUFVLE1BQU0sU0FBUyxTQUFTO0NBQ3hDLE1BQU0scUJBQXFCLE1BQU0sZUFBZSxpQkFBaUI7Q0FTakUsT0FBTyxpQkFBaUIsT0FBTyxnQkFBZ0I7RUFDN0MsU0FGbUIsZUFBZTtFQUdsQyxPQUFBO0dBUkE7R0FDQTtHQUNBO0dBQ0Esa0JBTHVCLHdCQUF3QjtFQVUzQztFQUNKLEtBQUssQ0FBQyxjQUFjLGtCQUFrQjtFQUN0Qyx3QkFBd0I7RUFDeEIsT0FBTyxDQUFDO0dBQ04sTUFBTTtHQUNOLFFBQVEsQ0FBQztHQUNULE9BQU8sRUFDTCxlQUFlLENBQUMsT0FBTyxTQUFTLEtBQUEsRUFDbEM7R0FDQTtFQUNGLEdBQUcsWUFBWTtDQUNqQixDQUFDO0FBQ0gsQ0FBQztBQUMwQyxlQUFlLGNBQWM7Ozs7Ozs7Ozs7QUN4Q3hFLElBQWEsZUFBYixjQUFrQyxnQkFBZ0I7Q0FDaEQsY0FBYztFQUNaLE1BQU0sc0JBQXNCLEdBQUcsVUFBVSxLQUFLO0NBQ2hEOzs7Ozs7Ozs7Q0FVQSxLQUFLLFdBQVc7RUFDZCxLQUFLLGNBQWMsU0FBUztDQUM5Qjs7Ozs7Ozs7Q0FTQSxnQkFBZ0IsU0FBUztFQUN2QixNQUFNLGdCQUFnQixLQUFLO0VBQzNCLElBQUksa0JBQWtCLE1BQU07R0FFeEIsUUFBUSxLQUFLLHFNQUEwTTtHQUV6TjtFQUNGO0VBQ0EsY0FBYyxJQUFJLFdBQVcsT0FBTztFQUNwQyxjQUFjLFFBQVEsTUFBTSx5QkFBeUJDLGdCQUF3QixDQUFDO0NBQ2hGOzs7Ozs7Q0FPQSxRQUFRO0VBQ04sS0FBSyxXQUFXO0NBQ2xCOzs7O0NBS0EsSUFBSSxTQUFTO0VBQ1gsT0FBTyxLQUFLLGVBQWUsT0FBTyxNQUFNLEtBQUs7Q0FDL0M7QUFDRjs7OztBQUtBLFNBQWdCLHFCQUFxQjtDQUNuQyxPQUFPLElBQUksYUFBYTtBQUMxQjs7Ozs7Ozs7Ozs7QUNsRUEsSUFBYUMsU0FBT0M7Ozs7QUFJcEIsSUFBYUMsV0FBU0M7Ozs7QUFJdEIsSUFBYUMsa0JBQWdCQzs7OztBQUk3QixJQUFhQyxnQkFBY0M7Ozs7OztBQ2QzQixJQUFhLFdBQVc7Ozs7Ozs7Ozs7Ozs7QUNFeEIsSUFBYSxPQUFPQzs7OztBQUlwQixJQUFhLFNBQVNDOzs7O0FBSXRCLElBQWEsZ0JBQWdCQzs7OztBQUk3QixJQUFhLGNBQWNDOzs7O0FBSTNCLElBQWEsU0FBUzs7OztBQUl0QixJQUFhLG1CQUFtQiIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5XX0=