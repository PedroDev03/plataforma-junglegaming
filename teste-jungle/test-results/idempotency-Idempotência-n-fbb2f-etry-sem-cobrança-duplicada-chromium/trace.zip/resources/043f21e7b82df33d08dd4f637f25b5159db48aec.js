import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/login.tsx?tsr-split=component");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { AuthCard } from "/src/components/auth/auth-card.tsx";
import { LoginForm } from "/src/components/auth/login-form.tsx";
import { Route } from "/src/routes/login.tsx";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/routes/login.tsx?tsr-split=component";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
function LoginPage() {
	_s();
	const $ = _c(3);
	if ($[0] !== "208f341d58115b82fdf31293d9138fb958e5b35b124ee3d3dd62e41fb09f795b") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "208f341d58115b82fdf31293d9138fb958e5b35b124ee3d3dd62e41fb09f795b";
	}
	const { redirect } = Route.useSearch();
	let t0;
	if ($[1] !== redirect) {
		t0 = /* @__PURE__ */ _jsxDEV(AuthCard, {
			title: "Entrar",
			description: "Acesse sua conta de colecionador.",
			children: /* @__PURE__ */ _jsxDEV(LoginForm, { redirect }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 83
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 10
		}, this);
		$[1] = redirect;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return t0;
}
_s(LoginPage, "IyNFseoJVZ9JtI2rYQFknZvpkDM=", false, function() {
	return [Route.useSearch];
});
_c2 = LoginPage;
export { LoginPage as component };
var _c2;
$RefreshReg$(_c2, "LoginPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/login.tsx?tsr-split=component";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/routes/login.tsx?tsr-split=component", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/routes/login.tsx?tsr-split=component", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/routes/login.tsx?tsr-split=component" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUVBLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxpQkFBaUI7QUFBOEIsU0FBQUMsYUFBQTs7OztBQWlCeEQsU0FBQUMsWUFBQTs7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FDRSxRQUFBSyxhQUFxQlAsTUFBS1EsVUFBVztDQUFDLElBQUFDO0NBQUEsSUFBQVAsRUFBQSxPQUFBSyxVQUFBO0VBRXBDRSxLQUFBLHdCQUFDLFVBQUQ7R0FBZ0I7R0FBcUI7YUFDbkMsd0JBQUMsV0FBRCxFQUFxQkYsU0FBUTs7Ozs7RUFEdEI7Ozs7O0VBRUVMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTztDQUFBO0VBQUFBLEtBQUFQLEVBQUE7Q0FBQTtDQUFBLE9BRlhPO0FBRVc7Ozs7O0FBRWQsU0FBQVIsYUFBQVMiLCJuYW1lcyI6WyJBdXRoQ2FyZCIsIkxvZ2luRm9ybSIsIlJvdXRlIiwiTG9naW5QYWdlIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJyZWRpcmVjdCIsInVzZVNlYXJjaCIsInQwIiwiY29tcG9uZW50Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImxvZ2luLnRzeD90c3Itc3BsaXQ9Y29tcG9uZW50Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUZpbGVSb3V0ZSwgcmVkaXJlY3QgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgeiB9IGZyb20gJ3pvZCdcbmltcG9ydCB7IEF1dGhDYXJkIH0gZnJvbSAnQC9jb21wb25lbnRzL2F1dGgvYXV0aC1jYXJkJ1xuaW1wb3J0IHsgTG9naW5Gb3JtIH0gZnJvbSAnQC9jb21wb25lbnRzL2F1dGgvbG9naW4tZm9ybSdcbmltcG9ydCB7IHNhZmVSZWRpcmVjdCB9IGZyb20gJ0AvbGliL3JlZGlyZWN0J1xuaW1wb3J0IHsgc2Vzc2lvbiB9IGZyb20gJ0AvbGliL3Nlc3Npb24nXG5cbmNvbnN0IGxvZ2luU2VhcmNoU2NoZW1hID0gei5vYmplY3Qoe1xuICByZWRpcmVjdDogei5zdHJpbmcoKS5vcHRpb25hbCgpLFxufSlcblxuZXhwb3J0IGNvbnN0IFJvdXRlID0gY3JlYXRlRmlsZVJvdXRlKCcvbG9naW4nKSh7XG4gIHZhbGlkYXRlU2VhcmNoOiBsb2dpblNlYXJjaFNjaGVtYSxcbiAgLy8gVXN1w6FyaW8gasOhIGF1dGVudGljYWRvIG7Do28gcHJlY2lzYSB2ZXIgbyBsb2dpblxuICBiZWZvcmVMb2FkOiAoeyBzZWFyY2ggfSkgPT4ge1xuICAgIGlmIChzZXNzaW9uLmlzQXV0aGVudGljYXRlZCgpKSB0aHJvdyByZWRpcmVjdCh7IHRvOiBzYWZlUmVkaXJlY3Qoc2VhcmNoLnJlZGlyZWN0KSB9KVxuICB9LFxuICBjb21wb25lbnQ6IExvZ2luUGFnZSxcbn0pXG5cbmZ1bmN0aW9uIExvZ2luUGFnZSgpIHtcbiAgY29uc3QgeyByZWRpcmVjdCB9ID0gUm91dGUudXNlU2VhcmNoKClcbiAgcmV0dXJuIChcbiAgICA8QXV0aENhcmQgdGl0bGU9XCJFbnRyYXJcIiBkZXNjcmlwdGlvbj1cIkFjZXNzZSBzdWEgY29udGEgZGUgY29sZWNpb25hZG9yLlwiPlxuICAgICAgPExvZ2luRm9ybSByZWRpcmVjdD17cmVkaXJlY3R9IC8+XG4gICAgPC9BdXRoQ2FyZD5cbiAgKVxufVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvcm91dGVzL2xvZ2luLnRzeCJ9