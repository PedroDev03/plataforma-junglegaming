import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/alert-dialog.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport1_react, 1);const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];"use client";
import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=e9f94b2e";
import { AlertDialog as AlertDialogPrimitive } from "/node_modules/.vite/deps/@base-ui_react_alert-dialog.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
import { Button } from "/src/components/ui/button.tsx";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/alert-dialog.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
function AlertDialog(t0) {
	const $ = _c(5);
	if ($[0] !== "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Root, {
			"data-slot": "alert-dialog",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c2 = AlertDialog;
function AlertDialogTrigger(t0) {
	const $ = _c(5);
	if ($[0] !== "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Trigger, {
			"data-slot": "alert-dialog-trigger",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c3 = AlertDialogTrigger;
function AlertDialogPortal(t0) {
	const $ = _c(5);
	if ($[0] !== "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Portal, {
			"data-slot": "alert-dialog-portal",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 84,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c4 = AlertDialogPortal;
function AlertDialogOverlay(t0) {
	const $ = _c(9);
	if ($[0] !== "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("fixed inset-0 isolate z-50 bg-black/10 duration-100 supports-backdrop-filter:backdrop-blur-xs data-open:animate-in data-open:fade-in-0 data-closed:animate-out data-closed:fade-out-0", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Backdrop, {
			"data-slot": "alert-dialog-overlay",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 124,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c5 = AlertDialogOverlay;
function AlertDialogContent(t0) {
	const $ = _c(12);
	if ($[0] !== "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0") {
		for (let $i = 0; $i < 12; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0";
	}
	let className;
	let props;
	let t1;
	if ($[1] !== t0) {
		({className, size: t1, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
		$[4] = t1;
	} else {
		className = $[2];
		props = $[3];
		t1 = $[4];
	}
	const size = t1 === undefined ? "default" : t1;
	let t2;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV(AlertDialogOverlay, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 162,
			columnNumber: 10
		}, this);
		$[5] = t2;
	} else {
		t2 = $[5];
	}
	let t3;
	if ($[6] !== className) {
		t3 = cn("group/alert-dialog-content fixed top-1/2 left-1/2 z-50 grid w-full -translate-x-1/2 -translate-y-1/2 gap-4 rounded-xl bg-popover p-4 text-popover-foreground ring-1 ring-foreground/10 duration-100 outline-none data-[size=default]:max-w-xs data-[size=sm]:max-w-xs data-[size=default]:sm:max-w-sm data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", className);
		$[6] = className;
		$[7] = t3;
	} else {
		t3 = $[7];
	}
	let t4;
	if ($[8] !== props || $[9] !== size || $[10] !== t3) {
		t4 = /* @__PURE__ */ _jsxDEV(AlertDialogPortal, { children: [t2, /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Popup, {
			"data-slot": "alert-dialog-content",
			"data-size": size,
			className: t3,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 177,
			columnNumber: 33
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 177,
			columnNumber: 10
		}, this);
		$[8] = props;
		$[9] = size;
		$[10] = t3;
		$[11] = t4;
	} else {
		t4 = $[11];
	}
	return t4;
}
_c6 = AlertDialogContent;
function AlertDialogHeader(t0) {
	const $ = _c(9);
	if ($[0] !== "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("grid grid-rows-[auto_1fr] place-items-center gap-1.5 text-center has-data-[slot=alert-dialog-media]:grid-rows-[auto_auto_1fr] has-data-[slot=alert-dialog-media]:gap-x-4 sm:group-data-[size=default]/alert-dialog-content:place-items-start sm:group-data-[size=default]/alert-dialog-content:text-left sm:group-data-[size=default]/alert-dialog-content:has-data-[slot=alert-dialog-media]:grid-rows-[auto_1fr]", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "alert-dialog-header",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 219,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c7 = AlertDialogHeader;
function AlertDialogFooter(t0) {
	const $ = _c(9);
	if ($[0] !== "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("-mx-4 -mb-4 flex flex-col-reverse gap-2 rounded-b-xl border-t bg-muted/50 p-4 group-data-[size=sm]/alert-dialog-content:grid group-data-[size=sm]/alert-dialog-content:grid-cols-2 sm:flex-row sm:justify-end", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "alert-dialog-footer",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 260,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c8 = AlertDialogFooter;
function AlertDialogMedia(t0) {
	const $ = _c(9);
	if ($[0] !== "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("mb-2 inline-flex size-10 items-center justify-center rounded-md bg-muted sm:group-data-[size=default]/alert-dialog-content:row-span-2 *:[svg:not([class*='size-'])]:size-6", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "alert-dialog-media",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 301,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c9 = AlertDialogMedia;
function AlertDialogTitle(t0) {
	const $ = _c(9);
	if ($[0] !== "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("font-heading text-base font-medium sm:group-data-[size=default]/alert-dialog-content:group-has-data-[slot=alert-dialog-media]/alert-dialog-content:col-start-2", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Title, {
			"data-slot": "alert-dialog-title",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 342,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c10 = AlertDialogTitle;
function AlertDialogDescription(t0) {
	const $ = _c(9);
	if ($[0] !== "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("text-sm text-balance text-muted-foreground md:text-pretty *:[a]:underline *:[a]:underline-offset-3 *:[a]:hover:text-foreground", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Description, {
			"data-slot": "alert-dialog-description",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 383,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c11 = AlertDialogDescription;
function AlertDialogAction(t0) {
	const $ = _c(9);
	if ($[0] !== "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn(className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(Button, {
			"data-slot": "alert-dialog-action",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 424,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c12 = AlertDialogAction;
function AlertDialogCancel(t0) {
	const $ = _c(15);
	if ($[0] !== "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0") {
		for (let $i = 0; $i < 15; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "460da1e9299c10c02cfcb15daf4471d052d8fddc48e82938406a65e40e82f2a0";
	}
	let className;
	let props;
	let t1;
	let t2;
	if ($[1] !== t0) {
		({className, variant: t1, size: t2, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
		$[4] = t1;
		$[5] = t2;
	} else {
		className = $[2];
		props = $[3];
		t1 = $[4];
		t2 = $[5];
	}
	const variant = t1 === undefined ? "outline" : t1;
	const size = t2 === undefined ? "default" : t2;
	let t3;
	if ($[6] !== className) {
		t3 = cn(className);
		$[6] = className;
		$[7] = t3;
	} else {
		t3 = $[7];
	}
	let t4;
	if ($[8] !== size || $[9] !== variant) {
		t4 = /* @__PURE__ */ _jsxDEV(Button, {
			variant,
			size
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 475,
			columnNumber: 10
		}, this);
		$[8] = size;
		$[9] = variant;
		$[10] = t4;
	} else {
		t4 = $[10];
	}
	let t5;
	if ($[11] !== props || $[12] !== t3 || $[13] !== t4) {
		t5 = /* @__PURE__ */ _jsxDEV(AlertDialogPrimitive.Close, {
			"data-slot": "alert-dialog-cancel",
			className: t3,
			render: t4,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 484,
			columnNumber: 10
		}, this);
		$[11] = props;
		$[12] = t3;
		$[13] = t4;
		$[14] = t5;
	} else {
		t5 = $[14];
	}
	return t5;
}
_c13 = AlertDialogCancel;
export { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogMedia, AlertDialogOverlay, AlertDialogPortal, AlertDialogTitle, AlertDialogTrigger };
var _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13;
$RefreshReg$(_c2, "AlertDialog");
$RefreshReg$(_c3, "AlertDialogTrigger");
$RefreshReg$(_c4, "AlertDialogPortal");
$RefreshReg$(_c5, "AlertDialogOverlay");
$RefreshReg$(_c6, "AlertDialogContent");
$RefreshReg$(_c7, "AlertDialogHeader");
$RefreshReg$(_c8, "AlertDialogFooter");
$RefreshReg$(_c9, "AlertDialogMedia");
$RefreshReg$(_c10, "AlertDialogTitle");
$RefreshReg$(_c11, "AlertDialogDescription");
$RefreshReg$(_c12, "AlertDialogAction");
$RefreshReg$(_c13, "AlertDialogCancel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/alert-dialog.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/alert-dialog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/alert-dialog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/alert-dialog.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFBWSxTQUFBQSxLQUFBQyxVQUFBO0FBRVosWUFBWUMsV0FBVztBQUN2QixTQUFTQyxlQUFlQyw0QkFBNEI7QUFDcEQsU0FBU0MsVUFBVTtBQUVuQixTQUFTQyxjQUFjOzs7QUFFdkIsU0FBQUgsWUFBQUksSUFBQTtDQUFBLE1BQUFDLElBQUFQLEdBQUE7Q0FBQSxJQUFBTyxFQUFBO0VBQUEsU0FBQUMsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUQsRUFBQUMsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFILEVBQUE7Q0FBQTtDQUFBLElBQUFJO0NBQUEsSUFBQUosRUFBQSxPQUFBRCxJQUFBO0VBQXFCLEtBQUFLLFNBQUFMO0VBQTZDQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQUk7Q0FBQTtFQUFBQSxRQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBSztDQUFBLElBQUFMLEVBQUEsT0FBQUksT0FBQTtFQUN6REMsS0FBQTtHQUFxQztHQUFjLEdBQUtEO0VBQUs7Ozs7O0VBQUlKLEVBQUEsS0FBQUk7RUFBQUosRUFBQSxLQUFBSztDQUFBO0VBQUFBLEtBQUFMLEVBQUE7Q0FBQTtDQUFBLE9BQWpFSztBQUFpRTs7QUFHMUUsU0FBQUMsbUJBQUFQLElBQUE7Q0FBQSxNQUFBQyxJQUFBUCxHQUFBO0NBQUEsSUFBQU8sRUFBQTtFQUFBLFNBQUFDLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFELEVBQUFDLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSCxFQUFBO0NBQUE7Q0FBQSxJQUFBSTtDQUFBLElBQUFKLEVBQUEsT0FBQUQsSUFBQTtFQUE0QixLQUFBSyxTQUFBTDtFQUFnREMsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFJO0NBQUE7RUFBQUEsUUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFJLE9BQUE7RUFFeEVDLEtBQUE7R0FBd0M7R0FBc0IsR0FBS0Q7RUFBSzs7Ozs7RUFBSUosRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFLO0NBQUE7RUFBQUEsS0FBQUwsRUFBQTtDQUFBO0NBQUEsT0FBNUVLO0FBQTRFOztBQUloRixTQUFBRSxrQkFBQVIsSUFBQTtDQUFBLE1BQUFDLElBQUFQLEdBQUE7Q0FBQSxJQUFBTyxFQUFBO0VBQUEsU0FBQUMsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUQsRUFBQUMsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFILEVBQUE7Q0FBQTtDQUFBLElBQUFJO0NBQUEsSUFBQUosRUFBQSxPQUFBRCxJQUFBO0VBQTJCLEtBQUFLLFNBQUFMO0VBQStDQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQUk7Q0FBQTtFQUFBQSxRQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBSztDQUFBLElBQUFMLEVBQUEsT0FBQUksT0FBQTtFQUV0RUMsS0FBQTtHQUF1QztHQUFxQixHQUFLRDtFQUFLOzs7OztFQUFJSixFQUFBLEtBQUFJO0VBQUFKLEVBQUEsS0FBQUs7Q0FBQTtFQUFBQSxLQUFBTCxFQUFBO0NBQUE7Q0FBQSxPQUExRUs7QUFBMEU7O0FBSTlFLFNBQUFHLG1CQUFBVCxJQUFBO0NBQUEsTUFBQUMsSUFBQVAsR0FBQTtDQUFBLElBQUFPLEVBQUE7RUFBQSxTQUFBQyxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRCxFQUFBQyxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUgsRUFBQTtDQUFBO0NBQUEsSUFBQVM7Q0FBQSxJQUFBTDtDQUFBLElBQUFKLEVBQUEsT0FBQUQsSUFBQTtFQUE0QixFQUFBVSxXQUFBLEdBQUFMLFNBQUFMO0VBR1VDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBUztFQUFBVCxFQUFBLEtBQUFJO0NBQUE7RUFBQUssWUFBQVQsRUFBQTtFQUFBSSxRQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBSztDQUFBLElBQUFMLEVBQUEsT0FBQVMsV0FBQTtFQUlyQkosS0FBQVIsR0FDVCx5TEFDQVksU0FDRjtFQUFDVCxFQUFBLEtBQUFTO0VBQUFULEVBQUEsS0FBQUs7Q0FBQTtFQUFBQSxLQUFBTCxFQUFBO0NBQUE7Q0FBQSxJQUFBVTtDQUFBLElBQUFWLEVBQUEsT0FBQUksU0FBQUosRUFBQSxPQUFBSyxJQUFBO0VBTEhLLEtBQUE7R0FDWTtHQUNDLFdBQUFMO0dBR1YsR0FDR0Q7RUFBSzs7Ozs7RUFDVEosRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQVU7Q0FBQTtFQUFBQSxLQUFBVixFQUFBO0NBQUE7Q0FBQSxPQVBGVTtBQU9FOztBQUlOLFNBQUFDLG1CQUFBWixJQUFBO0NBQUEsTUFBQUMsSUFBQVAsR0FBQTtDQUFBLElBQUFPLEVBQUE7RUFBQSxTQUFBQyxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRCxFQUFBQyxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUgsRUFBQTtDQUFBO0NBQUEsSUFBQVM7Q0FBQSxJQUFBTDtDQUFBLElBQUFDO0NBQUEsSUFBQUwsRUFBQSxPQUFBRCxJQUFBO0VBQTRCLEVBQUFVLFdBQUFHLE1BQUFQLElBQUEsR0FBQUQsU0FBQUw7RUFNM0JDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBUztFQUFBVCxFQUFBLEtBQUFJO0VBQUFKLEVBQUEsS0FBQUs7Q0FBQTtFQUFBSSxZQUFBVCxFQUFBO0VBQUFJLFFBQUFKLEVBQUE7RUFBQUssS0FBQUwsRUFBQTtDQUFBO0NBSkMsTUFBQVksT0FBQVAsT0FBQVEsWUFBQSxZQUFBUjtDQUFnQixJQUFBSztDQUFBLElBQUFWLEVBQUEsT0FBQUUsT0FBQUMsSUFBQTtFQU9aTyxLQUFBLHdCQUFDLG9CQUFELENBQW1COzs7OztFQUFHVixFQUFBLEtBQUFVO0NBQUE7RUFBQUEsS0FBQVYsRUFBQTtDQUFBO0NBQUEsSUFBQWM7Q0FBQSxJQUFBZCxFQUFBLE9BQUFTLFdBQUE7RUFJVEssS0FBQWpCLEdBQ1QsOGFBQ0FZLFNBQ0Y7RUFBQ1QsRUFBQSxLQUFBUztFQUFBVCxFQUFBLEtBQUFjO0NBQUE7RUFBQUEsS0FBQWQsRUFBQTtDQUFBO0NBQUEsSUFBQWU7Q0FBQSxJQUFBZixFQUFBLE9BQUFJLFNBQUFKLEVBQUEsT0FBQVksUUFBQVosRUFBQSxRQUFBYyxJQUFBO0VBUkxDLEtBQUEsd0JBQUMsbUJBQUQsYUFDRUwsSUFDQTtHQUNZO0dBQ0NFO0dBQ0EsV0FBQUU7R0FHVixHQUNHVjtFQUFLOzs7O1VBVEs7Ozs7O0VBV0VKLEVBQUEsS0FBQUk7RUFBQUosRUFBQSxLQUFBWTtFQUFBWixFQUFBLE1BQUFjO0VBQUFkLEVBQUEsTUFBQWU7Q0FBQTtFQUFBQSxLQUFBZixFQUFBO0NBQUE7Q0FBQSxPQVhwQmU7QUFXb0I7O0FBSXhCLFNBQUFDLGtCQUFBakIsSUFBQTtDQUFBLE1BQUFDLElBQUFQLEdBQUE7Q0FBQSxJQUFBTyxFQUFBO0VBQUEsU0FBQUMsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUQsRUFBQUMsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFILEVBQUE7Q0FBQTtDQUFBLElBQUFTO0NBQUEsSUFBQUw7Q0FBQSxJQUFBSixFQUFBLE9BQUFELElBQUE7RUFBMkIsRUFBQVUsV0FBQSxHQUFBTCxTQUFBTDtFQUdHQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQVM7RUFBQVQsRUFBQSxLQUFBSTtDQUFBO0VBQUFLLFlBQUFULEVBQUE7RUFBQUksUUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFTLFdBQUE7RUFJYkosS0FBQVIsR0FDVCxzWkFDQVksU0FDRjtFQUFDVCxFQUFBLEtBQUFTO0VBQUFULEVBQUEsS0FBQUs7Q0FBQTtFQUFBQSxLQUFBTCxFQUFBO0NBQUE7Q0FBQSxJQUFBVTtDQUFBLElBQUFWLEVBQUEsT0FBQUksU0FBQUosRUFBQSxPQUFBSyxJQUFBO0VBTEhLLEtBQUE7R0FDWTtHQUNDLFdBQUFMO0dBR1YsR0FDR0Q7RUFBSzs7Ozs7RUFDVEosRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQVU7Q0FBQTtFQUFBQSxLQUFBVixFQUFBO0NBQUE7Q0FBQSxPQVBGVTtBQU9FOztBQUlOLFNBQUFPLGtCQUFBbEIsSUFBQTtDQUFBLE1BQUFDLElBQUFQLEdBQUE7Q0FBQSxJQUFBTyxFQUFBO0VBQUEsU0FBQUMsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUQsRUFBQUMsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFILEVBQUE7Q0FBQTtDQUFBLElBQUFTO0NBQUEsSUFBQUw7Q0FBQSxJQUFBSixFQUFBLE9BQUFELElBQUE7RUFBMkIsRUFBQVUsV0FBQSxHQUFBTCxTQUFBTDtFQUdHQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQVM7RUFBQVQsRUFBQSxLQUFBSTtDQUFBO0VBQUFLLFlBQUFULEVBQUE7RUFBQUksUUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFTLFdBQUE7RUFJYkosS0FBQVIsR0FDVCxpTkFDQVksU0FDRjtFQUFDVCxFQUFBLEtBQUFTO0VBQUFULEVBQUEsS0FBQUs7Q0FBQTtFQUFBQSxLQUFBTCxFQUFBO0NBQUE7Q0FBQSxJQUFBVTtDQUFBLElBQUFWLEVBQUEsT0FBQUksU0FBQUosRUFBQSxPQUFBSyxJQUFBO0VBTEhLLEtBQUE7R0FDWTtHQUNDLFdBQUFMO0dBR1YsR0FDR0Q7RUFBSzs7Ozs7RUFDVEosRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQVU7Q0FBQTtFQUFBQSxLQUFBVixFQUFBO0NBQUE7Q0FBQSxPQVBGVTtBQU9FOztBQUlOLFNBQUFRLGlCQUFBbkIsSUFBQTtDQUFBLE1BQUFDLElBQUFQLEdBQUE7Q0FBQSxJQUFBTyxFQUFBO0VBQUEsU0FBQUMsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUQsRUFBQUMsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFILEVBQUE7Q0FBQTtDQUFBLElBQUFTO0NBQUEsSUFBQUw7Q0FBQSxJQUFBSixFQUFBLE9BQUFELElBQUE7RUFBMEIsRUFBQVUsV0FBQSxHQUFBTCxTQUFBTDtFQUdJQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQVM7RUFBQVQsRUFBQSxLQUFBSTtDQUFBO0VBQUFLLFlBQUFULEVBQUE7RUFBQUksUUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFTLFdBQUE7RUFJYkosS0FBQVIsR0FDVCw4S0FDQVksU0FDRjtFQUFDVCxFQUFBLEtBQUFTO0VBQUFULEVBQUEsS0FBQUs7Q0FBQTtFQUFBQSxLQUFBTCxFQUFBO0NBQUE7Q0FBQSxJQUFBVTtDQUFBLElBQUFWLEVBQUEsT0FBQUksU0FBQUosRUFBQSxPQUFBSyxJQUFBO0VBTEhLLEtBQUE7R0FDWTtHQUNDLFdBQUFMO0dBR1YsR0FDR0Q7RUFBSzs7Ozs7RUFDVEosRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQVU7Q0FBQTtFQUFBQSxLQUFBVixFQUFBO0NBQUE7Q0FBQSxPQVBGVTtBQU9FOztBQUlOLFNBQUFTLGlCQUFBcEIsSUFBQTtDQUFBLE1BQUFDLElBQUFQLEdBQUE7Q0FBQSxJQUFBTyxFQUFBO0VBQUEsU0FBQUMsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUQsRUFBQUMsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFILEVBQUE7Q0FBQTtDQUFBLElBQUFTO0NBQUEsSUFBQUw7Q0FBQSxJQUFBSixFQUFBLE9BQUFELElBQUE7RUFBMEIsRUFBQVUsV0FBQSxHQUFBTCxTQUFBTDtFQUdnQ0MsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFTO0VBQUFULEVBQUEsS0FBQUk7Q0FBQTtFQUFBSyxZQUFBVCxFQUFBO0VBQUFJLFFBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUwsRUFBQSxPQUFBUyxXQUFBO0VBSXpDSixLQUFBUixHQUNULGtLQUNBWSxTQUNGO0VBQUNULEVBQUEsS0FBQVM7RUFBQVQsRUFBQSxLQUFBSztDQUFBO0VBQUFBLEtBQUFMLEVBQUE7Q0FBQTtDQUFBLElBQUFVO0NBQUEsSUFBQVYsRUFBQSxPQUFBSSxTQUFBSixFQUFBLE9BQUFLLElBQUE7RUFMSEssS0FBQTtHQUNZO0dBQ0MsV0FBQUw7R0FHVixHQUNHRDtFQUFLOzs7OztFQUNUSixFQUFBLEtBQUFJO0VBQUFKLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBVTtDQUFBO0VBQUFBLEtBQUFWLEVBQUE7Q0FBQTtDQUFBLE9BUEZVO0FBT0U7O0FBSU4sU0FBQVUsdUJBQUFyQixJQUFBO0NBQUEsTUFBQUMsSUFBQVAsR0FBQTtDQUFBLElBQUFPLEVBQUE7RUFBQSxTQUFBQyxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRCxFQUFBQyxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUgsRUFBQTtDQUFBO0NBQUEsSUFBQVM7Q0FBQSxJQUFBTDtDQUFBLElBQUFKLEVBQUEsT0FBQUQsSUFBQTtFQUFnQyxFQUFBVSxXQUFBLEdBQUFMLFNBQUFMO0VBR2dDQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQVM7RUFBQVQsRUFBQSxLQUFBSTtDQUFBO0VBQUFLLFlBQUFULEVBQUE7RUFBQUksUUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFTLFdBQUE7RUFJL0NKLEtBQUFSLEdBQ1Qsa0lBQ0FZLFNBQ0Y7RUFBQ1QsRUFBQSxLQUFBUztFQUFBVCxFQUFBLEtBQUFLO0NBQUE7RUFBQUEsS0FBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQVU7Q0FBQSxJQUFBVixFQUFBLE9BQUFJLFNBQUFKLEVBQUEsT0FBQUssSUFBQTtFQUxISyxLQUFBO0dBQ1k7R0FDQyxXQUFBTDtHQUdWLEdBQ0dEO0VBQUs7Ozs7O0VBQ1RKLEVBQUEsS0FBQUk7RUFBQUosRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFVO0NBQUE7RUFBQUEsS0FBQVYsRUFBQTtDQUFBO0NBQUEsT0FQRlU7QUFPRTs7QUFJTixTQUFBVyxrQkFBQXRCLElBQUE7Q0FBQSxNQUFBQyxJQUFBUCxHQUFBO0NBQUEsSUFBQU8sRUFBQTtFQUFBLFNBQUFDLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFELEVBQUFDLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSCxFQUFBO0NBQUE7Q0FBQSxJQUFBUztDQUFBLElBQUFMO0NBQUEsSUFBQUosRUFBQSxPQUFBRCxJQUFBO0VBQTJCLEVBQUFVLFdBQUEsR0FBQUwsU0FBQUw7RUFHV0MsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFTO0VBQUFULEVBQUEsS0FBQUk7Q0FBQTtFQUFBSyxZQUFBVCxFQUFBO0VBQUFJLFFBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUwsRUFBQSxPQUFBUyxXQUFBO0VBSXJCSixLQUFBUixHQUFHWSxTQUFTO0VBQUNULEVBQUEsS0FBQVM7RUFBQVQsRUFBQSxLQUFBSztDQUFBO0VBQUFBLEtBQUFMLEVBQUE7Q0FBQTtDQUFBLElBQUFVO0NBQUEsSUFBQVYsRUFBQSxPQUFBSSxTQUFBSixFQUFBLE9BQUFLLElBQUE7RUFGMUJLLEtBQUEsd0JBQUMsUUFBRDtHQUNZO0dBQ0MsV0FBQUw7R0FBYSxHQUNwQkQ7RUFBSzs7Ozs7RUFDVEosRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQVU7Q0FBQTtFQUFBQSxLQUFBVixFQUFBO0NBQUE7Q0FBQSxPQUpGVTtBQUlFOztBQUlOLFNBQUFZLGtCQUFBdkIsSUFBQTtDQUFBLE1BQUFDLElBQUFQLEdBQUE7Q0FBQSxJQUFBTyxFQUFBO0VBQUEsU0FBQUMsS0FBQSxHQUFBQSxLQUFBLElBQUFBLE1BQUE7R0FBQUQsRUFBQUMsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFILEVBQUE7Q0FBQTtDQUFBLElBQUFTO0NBQUEsSUFBQUw7Q0FBQSxJQUFBQztDQUFBLElBQUFLO0NBQUEsSUFBQVYsRUFBQSxPQUFBRCxJQUFBO0VBQTJCLEVBQUFVLFdBQUFjLFNBQUFsQixJQUFBTyxNQUFBRixJQUFBLEdBQUFOLFNBQUFMO0VBTW9DQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQVM7RUFBQVQsRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQVU7Q0FBQTtFQUFBRCxZQUFBVCxFQUFBO0VBQUFJLFFBQUFKLEVBQUE7RUFBQUssS0FBQUwsRUFBQTtFQUFBVSxLQUFBVixFQUFBO0NBQUE7Q0FKN0QsTUFBQXVCLFVBQUFsQixPQUFBUSxZQUFBLFlBQUFSO0NBQ0EsTUFBQU8sT0FBQUYsT0FBQUcsWUFBQSxZQUFBSDtDQUFnQixJQUFBSTtDQUFBLElBQUFkLEVBQUEsT0FBQVMsV0FBQTtFQU9ESyxLQUFBakIsR0FBR1ksU0FBUztFQUFDVCxFQUFBLEtBQUFTO0VBQUFULEVBQUEsS0FBQWM7Q0FBQTtFQUFBQSxLQUFBZCxFQUFBO0NBQUE7Q0FBQSxJQUFBZTtDQUFBLElBQUFmLEVBQUEsT0FBQVksUUFBQVosRUFBQSxPQUFBdUIsU0FBQTtFQUNoQlIsS0FBQSx3QkFBQyxRQUFEO0dBQWlCUTtHQUFlWDtFQUFJOzs7OztFQUFJWixFQUFBLEtBQUFZO0VBQUFaLEVBQUEsS0FBQXVCO0VBQUF2QixFQUFBLE1BQUFlO0NBQUE7RUFBQUEsS0FBQWYsRUFBQTtDQUFBO0NBQUEsSUFBQXdCO0NBQUEsSUFBQXhCLEVBQUEsUUFBQUksU0FBQUosRUFBQSxRQUFBYyxNQUFBZCxFQUFBLFFBQUFlLElBQUE7RUFIbERTLEtBQUE7R0FDWTtHQUNDLFdBQUFWO0dBQ0gsUUFBQUM7R0FBd0MsR0FDNUNYO0VBQUs7Ozs7O0VBQ1RKLEVBQUEsTUFBQUk7RUFBQUosRUFBQSxNQUFBYztFQUFBZCxFQUFBLE1BQUFlO0VBQUFmLEVBQUEsTUFBQXdCO0NBQUE7RUFBQUEsS0FBQXhCLEVBQUE7Q0FBQTtDQUFBLE9BTEZ3QjtBQUtFOztBQUlOLFNBQ0U3QixhQUNBMEIsbUJBQ0FDLG1CQUNBWCxvQkFDQVMsd0JBQ0FILG1CQUNBRCxtQkFDQUUsa0JBQ0FWLG9CQUNBRCxtQkFDQVksa0JBQ0FiIiwibmFtZXMiOlsiYyIsIl9jIiwiUmVhY3QiLCJBbGVydERpYWxvZyIsIkFsZXJ0RGlhbG9nUHJpbWl0aXZlIiwiY24iLCJCdXR0b24iLCJ0MCIsIiQiLCIkaSIsIlN5bWJvbCIsImZvciIsInByb3BzIiwidDEiLCJBbGVydERpYWxvZ1RyaWdnZXIiLCJBbGVydERpYWxvZ1BvcnRhbCIsIkFsZXJ0RGlhbG9nT3ZlcmxheSIsImNsYXNzTmFtZSIsInQyIiwiQWxlcnREaWFsb2dDb250ZW50Iiwic2l6ZSIsInVuZGVmaW5lZCIsInQzIiwidDQiLCJBbGVydERpYWxvZ0hlYWRlciIsIkFsZXJ0RGlhbG9nRm9vdGVyIiwiQWxlcnREaWFsb2dNZWRpYSIsIkFsZXJ0RGlhbG9nVGl0bGUiLCJBbGVydERpYWxvZ0Rlc2NyaXB0aW9uIiwiQWxlcnREaWFsb2dBY3Rpb24iLCJBbGVydERpYWxvZ0NhbmNlbCIsInZhcmlhbnQiLCJ0NSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJhbGVydC1kaWFsb2cudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIGNsaWVudFwiXG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiXG5pbXBvcnQgeyBBbGVydERpYWxvZyBhcyBBbGVydERpYWxvZ1ByaW1pdGl2ZSB9IGZyb20gXCJAYmFzZS11aS9yZWFjdC9hbGVydC1kaWFsb2dcIlxuaW1wb3J0IHsgY24gfSBmcm9tIFwiY25cIlxuXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tIFwiQC9jb21wb25lbnRzL3VpL2J1dHRvblwiXG5cbmZ1bmN0aW9uIEFsZXJ0RGlhbG9nKHsgLi4ucHJvcHMgfTogQWxlcnREaWFsb2dQcmltaXRpdmUuUm9vdC5Qcm9wcykge1xuICByZXR1cm4gPEFsZXJ0RGlhbG9nUHJpbWl0aXZlLlJvb3QgZGF0YS1zbG90PVwiYWxlcnQtZGlhbG9nXCIgey4uLnByb3BzfSAvPlxufVxuXG5mdW5jdGlvbiBBbGVydERpYWxvZ1RyaWdnZXIoeyAuLi5wcm9wcyB9OiBBbGVydERpYWxvZ1ByaW1pdGl2ZS5UcmlnZ2VyLlByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPEFsZXJ0RGlhbG9nUHJpbWl0aXZlLlRyaWdnZXIgZGF0YS1zbG90PVwiYWxlcnQtZGlhbG9nLXRyaWdnZXJcIiB7Li4ucHJvcHN9IC8+XG4gIClcbn1cblxuZnVuY3Rpb24gQWxlcnREaWFsb2dQb3J0YWwoeyAuLi5wcm9wcyB9OiBBbGVydERpYWxvZ1ByaW1pdGl2ZS5Qb3J0YWwuUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8QWxlcnREaWFsb2dQcmltaXRpdmUuUG9ydGFsIGRhdGEtc2xvdD1cImFsZXJ0LWRpYWxvZy1wb3J0YWxcIiB7Li4ucHJvcHN9IC8+XG4gIClcbn1cblxuZnVuY3Rpb24gQWxlcnREaWFsb2dPdmVybGF5KHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogQWxlcnREaWFsb2dQcmltaXRpdmUuQmFja2Ryb3AuUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8QWxlcnREaWFsb2dQcmltaXRpdmUuQmFja2Ryb3BcbiAgICAgIGRhdGEtc2xvdD1cImFsZXJ0LWRpYWxvZy1vdmVybGF5XCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiZml4ZWQgaW5zZXQtMCBpc29sYXRlIHotNTAgYmctYmxhY2svMTAgZHVyYXRpb24tMTAwIHN1cHBvcnRzLWJhY2tkcm9wLWZpbHRlcjpiYWNrZHJvcC1ibHVyLXhzIGRhdGEtb3BlbjphbmltYXRlLWluIGRhdGEtb3BlbjpmYWRlLWluLTAgZGF0YS1jbG9zZWQ6YW5pbWF0ZS1vdXQgZGF0YS1jbG9zZWQ6ZmFkZS1vdXQtMFwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBBbGVydERpYWxvZ0NvbnRlbnQoe1xuICBjbGFzc05hbWUsXG4gIHNpemUgPSBcImRlZmF1bHRcIixcbiAgLi4ucHJvcHNcbn06IEFsZXJ0RGlhbG9nUHJpbWl0aXZlLlBvcHVwLlByb3BzICYge1xuICBzaXplPzogXCJkZWZhdWx0XCIgfCBcInNtXCJcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8QWxlcnREaWFsb2dQb3J0YWw+XG4gICAgICA8QWxlcnREaWFsb2dPdmVybGF5IC8+XG4gICAgICA8QWxlcnREaWFsb2dQcmltaXRpdmUuUG9wdXBcbiAgICAgICAgZGF0YS1zbG90PVwiYWxlcnQtZGlhbG9nLWNvbnRlbnRcIlxuICAgICAgICBkYXRhLXNpemU9e3NpemV9XG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgXCJncm91cC9hbGVydC1kaWFsb2ctY29udGVudCBmaXhlZCB0b3AtMS8yIGxlZnQtMS8yIHotNTAgZ3JpZCB3LWZ1bGwgLXRyYW5zbGF0ZS14LTEvMiAtdHJhbnNsYXRlLXktMS8yIGdhcC00IHJvdW5kZWQteGwgYmctcG9wb3ZlciBwLTQgdGV4dC1wb3BvdmVyLWZvcmVncm91bmQgcmluZy0xIHJpbmctZm9yZWdyb3VuZC8xMCBkdXJhdGlvbi0xMDAgb3V0bGluZS1ub25lIGRhdGEtW3NpemU9ZGVmYXVsdF06bWF4LXcteHMgZGF0YS1bc2l6ZT1zbV06bWF4LXcteHMgZGF0YS1bc2l6ZT1kZWZhdWx0XTpzbTptYXgtdy1zbSBkYXRhLW9wZW46YW5pbWF0ZS1pbiBkYXRhLW9wZW46ZmFkZS1pbi0wIGRhdGEtb3Blbjp6b29tLWluLTk1IGRhdGEtY2xvc2VkOmFuaW1hdGUtb3V0IGRhdGEtY2xvc2VkOmZhZGUtb3V0LTAgZGF0YS1jbG9zZWQ6em9vbS1vdXQtOTVcIixcbiAgICAgICAgICBjbGFzc05hbWVcbiAgICAgICAgKX1cbiAgICAgICAgey4uLnByb3BzfVxuICAgICAgLz5cbiAgICA8L0FsZXJ0RGlhbG9nUG9ydGFsPlxuICApXG59XG5cbmZ1bmN0aW9uIEFsZXJ0RGlhbG9nSGVhZGVyKHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8XCJkaXZcIj4pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBkYXRhLXNsb3Q9XCJhbGVydC1kaWFsb2ctaGVhZGVyXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiZ3JpZCBncmlkLXJvd3MtW2F1dG9fMWZyXSBwbGFjZS1pdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LWNlbnRlciBoYXMtZGF0YS1bc2xvdD1hbGVydC1kaWFsb2ctbWVkaWFdOmdyaWQtcm93cy1bYXV0b19hdXRvXzFmcl0gaGFzLWRhdGEtW3Nsb3Q9YWxlcnQtZGlhbG9nLW1lZGlhXTpnYXAteC00IHNtOmdyb3VwLWRhdGEtW3NpemU9ZGVmYXVsdF0vYWxlcnQtZGlhbG9nLWNvbnRlbnQ6cGxhY2UtaXRlbXMtc3RhcnQgc206Z3JvdXAtZGF0YS1bc2l6ZT1kZWZhdWx0XS9hbGVydC1kaWFsb2ctY29udGVudDp0ZXh0LWxlZnQgc206Z3JvdXAtZGF0YS1bc2l6ZT1kZWZhdWx0XS9hbGVydC1kaWFsb2ctY29udGVudDpoYXMtZGF0YS1bc2xvdD1hbGVydC1kaWFsb2ctbWVkaWFdOmdyaWQtcm93cy1bYXV0b18xZnJdXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIEFsZXJ0RGlhbG9nRm9vdGVyKHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8XCJkaXZcIj4pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBkYXRhLXNsb3Q9XCJhbGVydC1kaWFsb2ctZm9vdGVyXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiLW14LTQgLW1iLTQgZmxleCBmbGV4LWNvbC1yZXZlcnNlIGdhcC0yIHJvdW5kZWQtYi14bCBib3JkZXItdCBiZy1tdXRlZC81MCBwLTQgZ3JvdXAtZGF0YS1bc2l6ZT1zbV0vYWxlcnQtZGlhbG9nLWNvbnRlbnQ6Z3JpZCBncm91cC1kYXRhLVtzaXplPXNtXS9hbGVydC1kaWFsb2ctY29udGVudDpncmlkLWNvbHMtMiBzbTpmbGV4LXJvdyBzbTpqdXN0aWZ5LWVuZFwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBBbGVydERpYWxvZ01lZGlhKHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8XCJkaXZcIj4pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBkYXRhLXNsb3Q9XCJhbGVydC1kaWFsb2ctbWVkaWFcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJtYi0yIGlubGluZS1mbGV4IHNpemUtMTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbWQgYmctbXV0ZWQgc206Z3JvdXAtZGF0YS1bc2l6ZT1kZWZhdWx0XS9hbGVydC1kaWFsb2ctY29udGVudDpyb3ctc3Bhbi0yICo6W3N2Zzpub3QoW2NsYXNzKj0nc2l6ZS0nXSldOnNpemUtNlwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBBbGVydERpYWxvZ1RpdGxlKHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIEFsZXJ0RGlhbG9nUHJpbWl0aXZlLlRpdGxlPikge1xuICByZXR1cm4gKFxuICAgIDxBbGVydERpYWxvZ1ByaW1pdGl2ZS5UaXRsZVxuICAgICAgZGF0YS1zbG90PVwiYWxlcnQtZGlhbG9nLXRpdGxlXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiZm9udC1oZWFkaW5nIHRleHQtYmFzZSBmb250LW1lZGl1bSBzbTpncm91cC1kYXRhLVtzaXplPWRlZmF1bHRdL2FsZXJ0LWRpYWxvZy1jb250ZW50Omdyb3VwLWhhcy1kYXRhLVtzbG90PWFsZXJ0LWRpYWxvZy1tZWRpYV0vYWxlcnQtZGlhbG9nLWNvbnRlbnQ6Y29sLXN0YXJ0LTJcIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZnVuY3Rpb24gQWxlcnREaWFsb2dEZXNjcmlwdGlvbih7XG4gIGNsYXNzTmFtZSxcbiAgLi4ucHJvcHNcbn06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBBbGVydERpYWxvZ1ByaW1pdGl2ZS5EZXNjcmlwdGlvbj4pIHtcbiAgcmV0dXJuIChcbiAgICA8QWxlcnREaWFsb2dQcmltaXRpdmUuRGVzY3JpcHRpb25cbiAgICAgIGRhdGEtc2xvdD1cImFsZXJ0LWRpYWxvZy1kZXNjcmlwdGlvblwiXG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcInRleHQtc20gdGV4dC1iYWxhbmNlIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBtZDp0ZXh0LXByZXR0eSAqOlthXTp1bmRlcmxpbmUgKjpbYV06dW5kZXJsaW5lLW9mZnNldC0zICo6W2FdOmhvdmVyOnRleHQtZm9yZWdyb3VuZFwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBBbGVydERpYWxvZ0FjdGlvbih7XG4gIGNsYXNzTmFtZSxcbiAgLi4ucHJvcHNcbn06IFJlYWN0LkNvbXBvbmVudFByb3BzPHR5cGVvZiBCdXR0b24+KSB7XG4gIHJldHVybiAoXG4gICAgPEJ1dHRvblxuICAgICAgZGF0YS1zbG90PVwiYWxlcnQtZGlhbG9nLWFjdGlvblwiXG4gICAgICBjbGFzc05hbWU9e2NuKGNsYXNzTmFtZSl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBBbGVydERpYWxvZ0NhbmNlbCh7XG4gIGNsYXNzTmFtZSxcbiAgdmFyaWFudCA9IFwib3V0bGluZVwiLFxuICBzaXplID0gXCJkZWZhdWx0XCIsXG4gIC4uLnByb3BzXG59OiBBbGVydERpYWxvZ1ByaW1pdGl2ZS5DbG9zZS5Qcm9wcyAmXG4gIFBpY2s8UmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIEJ1dHRvbj4sIFwidmFyaWFudFwiIHwgXCJzaXplXCI+KSB7XG4gIHJldHVybiAoXG4gICAgPEFsZXJ0RGlhbG9nUHJpbWl0aXZlLkNsb3NlXG4gICAgICBkYXRhLXNsb3Q9XCJhbGVydC1kaWFsb2ctY2FuY2VsXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oY2xhc3NOYW1lKX1cbiAgICAgIHJlbmRlcj17PEJ1dHRvbiB2YXJpYW50PXt2YXJpYW50fSBzaXplPXtzaXplfSAvPn1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmV4cG9ydCB7XG4gIEFsZXJ0RGlhbG9nLFxuICBBbGVydERpYWxvZ0FjdGlvbixcbiAgQWxlcnREaWFsb2dDYW5jZWwsXG4gIEFsZXJ0RGlhbG9nQ29udGVudCxcbiAgQWxlcnREaWFsb2dEZXNjcmlwdGlvbixcbiAgQWxlcnREaWFsb2dGb290ZXIsXG4gIEFsZXJ0RGlhbG9nSGVhZGVyLFxuICBBbGVydERpYWxvZ01lZGlhLFxuICBBbGVydERpYWxvZ092ZXJsYXksXG4gIEFsZXJ0RGlhbG9nUG9ydGFsLFxuICBBbGVydERpYWxvZ1RpdGxlLFxuICBBbGVydERpYWxvZ1RyaWdnZXIsXG59XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9jb21wb25lbnRzL3VpL2FsZXJ0LWRpYWxvZy50c3gifQ==