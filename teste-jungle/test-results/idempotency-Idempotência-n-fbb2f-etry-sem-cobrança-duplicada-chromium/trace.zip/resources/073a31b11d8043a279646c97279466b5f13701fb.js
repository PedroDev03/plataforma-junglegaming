import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=e9f94b2e";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom-CRx58tZq.js?v=e9f94b2e";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-cNwuCTLA.js?v=e9f94b2e";
import { r as useIsoLayoutEffect, t as useStableCallback } from "/node_modules/.vite/deps/formatErrorMessage-BEgQI17N.js?v=e9f94b2e";
import { d as isElement, f as isHTMLElement, l as getWindow } from "/node_modules/.vite/deps/floating-ui.utils.dom-B45hE2lE.js?v=e9f94b2e";
import { $ as isTypeableElement, At as addEventListener, D as useFloatingTree, E as useFloatingParentNodeId, Et as webkit, I as createAttribute, J as mergeCleanups, R as getNodeChildren, X as isInteractiveElement, Z as isTargetInsideEnabledTrigger, bt as isMouseLikePointerType, et as matchesFocusVisible, kt as mac, q as useValueAsRef } from "/node_modules/.vite/deps/FloatingRootStore-BMBEPfxq.js?v=e9f94b2e";
import { n as ownerDocument, t as inertValue } from "/node_modules/.vite/deps/inertValue-DbKApsSW.js?v=e9f94b2e";
import { c as EMPTY_OBJECT, l as NOOP, u as useRefWithInit } from "/node_modules/.vite/deps/useRenderElement-CvMw8z9e.js?v=e9f94b2e";
import { t as useOnMount } from "/node_modules/.vite/deps/useOnMount-BYrs6Ouk.js?v=e9f94b2e";
import { n as useTimeout, t as Timeout } from "/node_modules/.vite/deps/useTimeout-w0MCIDxv.js?v=e9f94b2e";
import { l as useAnimationFrame, n as useAnimationsFinished } from "/node_modules/.vite/deps/useOpenChangeComplete-BJDlY1Cs.js?v=e9f94b2e";
import { c as activeElement, d as getTarget, l as closest, u as contains } from "/node_modules/.vite/deps/composite-DUPI88po.js?v=e9f94b2e";
import { b as triggerFocus, w as createChangeEventDetails, x as triggerHover } from "/node_modules/.vite/deps/reason-parts-D-IkPsXA.js?v=e9f94b2e";
import { m as getSide } from "/node_modules/.vite/deps/floating-ui.utils-BnTHImEf.js?v=e9f94b2e";
import { a as availableWidth, c as DEFAULT_SIDES, i as availableHeight, o as positionerHeight, s as positionerWidth, t as usePreviousValue } from "/node_modules/.vite/deps/usePreviousValue-e4KgGpny.js?v=e9f94b2e";
import { t as useDirection } from "/node_modules/.vite/deps/DirectionContext-BppzJsM-.js?v=e9f94b2e";
import { t as getCssDimensions } from "/node_modules/.vite/deps/getCssDimensions-X1JHqR9k.js?v=e9f94b2e";
// node_modules/@base-ui/react/floating-ui-react/hooks/useHoverShared.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function resolveValue(value, pointerType) {
	if (pointerType != null && !isMouseLikePointerType(pointerType)) return 0;
	if (typeof value === "function") return value();
	return value;
}
function getDelay(value, prop, pointerType) {
	const result = resolveValue(value, pointerType);
	if (typeof result === "number") return result;
	return result?.[prop];
}
function getRestMs(value) {
	if (typeof value === "function") return value();
	return value;
}
function isClickLikeOpenEvent(openEventType, interactedInside) {
	return interactedInside || openEventType === "click" || openEventType === "mousedown";
}
function isHoverOpenEvent(openEventType) {
	return openEventType?.includes("mouse") && openEventType !== "mousedown";
}
// node_modules/@base-ui/react/floating-ui-react/hooks/useFocus.mjs
var isMacSafari = mac && webkit;
/**
* Opens the floating element while the reference element has focus, like CSS
* `:focus`.
* @see https://floating-ui.com/docs/useFocus
*/
function useFocus(store, props = {}) {
	const { enabled = true, delay } = props;
	const { events, dataRef } = store.context;
	const blockFocusRef = import_react.useRef(false);
	const blockedReferenceRef = import_react.useRef(null);
	const keyboardModalityRef = import_react.useRef(true);
	const timeout = useTimeout();
	import_react.useEffect(() => {
		const domReference = store.select("domReferenceElement");
		if (!enabled) return;
		const win = getWindow(domReference);
		function onBlur() {
			const currentDomReference = store.select("domReferenceElement");
			if (!store.select("open") && isHTMLElement(currentDomReference) && currentDomReference === activeElement(ownerDocument(currentDomReference))) {
				blockFocusRef.current = true;
				blockedReferenceRef.current = currentDomReference;
			}
		}
		function onKeyDown() {
			keyboardModalityRef.current = true;
		}
		function onPointerDown() {
			keyboardModalityRef.current = false;
		}
		return mergeCleanups(addEventListener(win, "blur", onBlur), isMacSafari && addEventListener(win, "keydown", onKeyDown, true), isMacSafari && addEventListener(win, "pointerdown", onPointerDown, true));
	}, [store, enabled]);
	import_react.useEffect(() => {
		if (!enabled) return;
		function onOpenChangeLocal(details) {
			if (details.reason === "trigger-press" || details.reason === "escape-key") {
				const referenceElement = store.select("domReferenceElement");
				if (isElement(referenceElement)) {
					blockedReferenceRef.current = referenceElement;
					blockFocusRef.current = true;
				}
			}
		}
		events.on("openchange", onOpenChangeLocal);
		return () => {
			events.off("openchange", onOpenChangeLocal);
		};
	}, [
		events,
		enabled,
		store
	]);
	const reference = import_react.useMemo(() => {
		function resetBlockedFocus() {
			blockFocusRef.current = false;
			blockedReferenceRef.current = null;
		}
		return {
			onMouseLeave() {
				resetBlockedFocus();
			},
			onFocus(event) {
				const focusTarget = event.currentTarget;
				if (blockFocusRef.current) {
					if (blockedReferenceRef.current === focusTarget) return;
					resetBlockedFocus();
				}
				const target = getTarget(event.nativeEvent);
				if (isElement(target)) {
					if (isMacSafari && !event.relatedTarget) {
						if (!keyboardModalityRef.current && !isTypeableElement(target)) return;
					} else if (!matchesFocusVisible(target)) return;
				}
				const movedFromOtherEnabledTrigger = isTargetInsideEnabledTrigger(event.relatedTarget, store.context.triggerElements);
				const { nativeEvent, currentTarget } = event;
				if (store.select("open") && movedFromOtherEnabledTrigger || !delay) {
					store.setOpen(true, createChangeEventDetails(triggerFocus, nativeEvent, currentTarget));
					return;
				}
				timeout.start(delay, () => {
					if (blockFocusRef.current) return;
					store.setOpen(true, createChangeEventDetails(triggerFocus, nativeEvent, currentTarget));
				});
			},
			onBlur(event) {
				resetBlockedFocus();
				const relatedTarget = event.relatedTarget;
				const nativeEvent = event.nativeEvent;
				const movedToFocusGuard = isElement(relatedTarget) && relatedTarget.hasAttribute(createAttribute("focus-guard")) && relatedTarget.getAttribute("data-type") === "outside";
				timeout.start(0, () => {
					const domReference = store.select("domReferenceElement");
					const activeEl = activeElement(ownerDocument(domReference));
					if (!relatedTarget && activeEl === domReference) return;
					if (contains(dataRef.current.floatingContext?.refs.floating.current, activeEl) || contains(domReference, activeEl) || movedToFocusGuard) return;
					if (isTargetInsideEnabledTrigger(relatedTarget ?? activeEl, store.context.triggerElements)) return;
					store.setOpen(false, createChangeEventDetails(triggerFocus, nativeEvent));
				});
			}
		};
	}, [
		dataRef,
		delay,
		store,
		timeout
	]);
	return import_react.useMemo(() => enabled ? {
		reference,
		trigger: reference
	} : {}, [enabled, reference]);
}
// node_modules/@base-ui/react/floating-ui-react/hooks/useHoverInteractionSharedState.mjs
var HoverInteraction = class HoverInteraction {
	pointerType = void 0;
	interactedInside = false;
	handler = void 0;
	blockMouseMove = true;
	performedPointerEventsMutation = false;
	pointerEventsScopeElement = null;
	pointerEventsReferenceElement = null;
	pointerEventsFloatingElement = null;
	restTimeoutPending = false;
	openChangeTimeout = new Timeout();
	restTimeout = new Timeout();
	handleCloseOptions = void 0;
	static create() {
		return new HoverInteraction();
	}
	dispose = () => {
		this.openChangeTimeout.clear();
		this.restTimeout.clear();
	};
	disposeEffect = () => {
		return this.dispose;
	};
};
var pointerEventsMutationOwnerByScopeElement = /* @__PURE__ */ new WeakMap();
function clearSafePolygonPointerEventsMutation(instance) {
	if (!instance.performedPointerEventsMutation) return;
	const scopeElement = instance.pointerEventsScopeElement;
	if (scopeElement && pointerEventsMutationOwnerByScopeElement.get(scopeElement) === instance) {
		instance.pointerEventsScopeElement?.style.removeProperty("pointer-events");
		instance.pointerEventsReferenceElement?.style.removeProperty("pointer-events");
		instance.pointerEventsFloatingElement?.style.removeProperty("pointer-events");
		pointerEventsMutationOwnerByScopeElement.delete(scopeElement);
	}
	instance.performedPointerEventsMutation = false;
	instance.pointerEventsScopeElement = null;
	instance.pointerEventsReferenceElement = null;
	instance.pointerEventsFloatingElement = null;
}
function applySafePolygonPointerEventsMutation(instance, options) {
	const { scopeElement, referenceElement, floatingElement } = options;
	const existingOwner = pointerEventsMutationOwnerByScopeElement.get(scopeElement);
	if (existingOwner && existingOwner !== instance) clearSafePolygonPointerEventsMutation(existingOwner);
	clearSafePolygonPointerEventsMutation(instance);
	instance.performedPointerEventsMutation = true;
	instance.pointerEventsScopeElement = scopeElement;
	instance.pointerEventsReferenceElement = referenceElement;
	instance.pointerEventsFloatingElement = floatingElement;
	pointerEventsMutationOwnerByScopeElement.set(scopeElement, instance);
	scopeElement.style.pointerEvents = "none";
	referenceElement.style.pointerEvents = "auto";
	floatingElement.style.pointerEvents = "auto";
}
function useHoverInteractionSharedState(store) {
	const data = store.context.dataRef.current;
	const instance = useRefWithInit(() => data.hoverInteractionState ?? HoverInteraction.create()).current;
	if (!data.hoverInteractionState) data.hoverInteractionState = instance;
	useOnMount(data.hoverInteractionState.disposeEffect);
	return data.hoverInteractionState;
}
// node_modules/@base-ui/react/floating-ui-react/hooks/useHoverFloatingInteraction.mjs
/**
* Provides hover interactions that should be attached to the floating element.
*/
function useHoverFloatingInteraction(store, parameters = {}) {
	const { enabled = true, closeDelay: closeDelayProp = 0, nodeId: nodeIdProp } = parameters;
	const open = store.useState("open");
	const floatingElement = store.useState("floatingElement");
	const domReferenceElement = store.useState("domReferenceElement");
	const { dataRef } = store.context;
	const tree = useFloatingTree();
	const parentId = useFloatingParentNodeId();
	const instance = useHoverInteractionSharedState(store);
	const childClosedTimeout = useTimeout();
	const isClickLikeOpenEvent$2 = useStableCallback(() => {
		return isClickLikeOpenEvent(dataRef.current.openEvent?.type, instance.interactedInside);
	});
	const isHoverOpen = useStableCallback(() => {
		return isHoverOpenEvent(dataRef.current.openEvent?.type);
	});
	const clearPointerEvents = useStableCallback(() => {
		clearSafePolygonPointerEventsMutation(instance);
	});
	useIsoLayoutEffect(() => {
		if (!open) {
			instance.pointerType = void 0;
			instance.restTimeoutPending = false;
			instance.interactedInside = false;
			clearPointerEvents();
		}
	}, [
		open,
		instance,
		clearPointerEvents
	]);
	import_react.useEffect(() => {
		return clearPointerEvents;
	}, [clearPointerEvents]);
	useIsoLayoutEffect(() => {
		if (!enabled) return;
		if (open && instance.handleCloseOptions?.blockPointerEvents && isHoverOpen() && isElement(domReferenceElement) && floatingElement) {
			const ref = domReferenceElement;
			const floatingEl = floatingElement;
			const doc = ownerDocument(floatingElement);
			const parentFloating = tree?.nodesRef.current.find((node) => node.id === parentId)?.context?.elements.floating;
			if (parentFloating) parentFloating.style.pointerEvents = "";
			const cachedScopeElement = instance.pointerEventsScopeElement !== floatingEl ? instance.pointerEventsScopeElement : null;
			const parentScopeElement = parentFloating !== floatingEl ? parentFloating : null;
			const scopeElement = instance.handleCloseOptions?.getScope?.() ?? cachedScopeElement ?? parentScopeElement ?? closest(ref, "[data-rootownerid]") ?? doc.body;
			applySafePolygonPointerEventsMutation(instance, {
				scopeElement,
				referenceElement: ref,
				floatingElement: floatingEl
			});
			return () => {
				clearPointerEvents();
			};
		}
	}, [
		enabled,
		open,
		domReferenceElement,
		floatingElement,
		instance,
		isHoverOpen,
		tree,
		parentId,
		clearPointerEvents
	]);
	import_react.useEffect(() => {
		if (!enabled) return;
		function hasParentChildren() {
			return !!(tree && parentId && getNodeChildren(tree.nodesRef.current, parentId).length > 0);
		}
		function closeWithDelay(event) {
			const closeDelay = getDelay(closeDelayProp, "close", instance.pointerType);
			const close = () => {
				store.setOpen(false, createChangeEventDetails(triggerHover, event));
				tree?.events.emit("floating.closed", event);
			};
			if (closeDelay) instance.openChangeTimeout.start(closeDelay, close);
			else {
				instance.openChangeTimeout.clear();
				close();
			}
		}
		function handleInteractInside(event) {
			const target = getTarget(event);
			if (!isInteractiveElement(target)) {
				instance.interactedInside = false;
				return;
			}
			instance.interactedInside = closest(target, "[aria-haspopup]") != null;
		}
		function onFloatingMouseEnter() {
			instance.openChangeTimeout.clear();
			childClosedTimeout.clear();
			tree?.events.off("floating.closed", onNodeClosed);
			clearPointerEvents();
		}
		function onFloatingMouseLeave(event) {
			if (hasParentChildren() && tree) {
				tree.events.on("floating.closed", onNodeClosed);
				return;
			}
			if (isTargetInsideEnabledTrigger(event.relatedTarget, store.context.triggerElements)) return;
			const currentNodeId = dataRef.current.floatingContext?.nodeId ?? nodeIdProp;
			const relatedTarget = event.relatedTarget;
			if (tree && currentNodeId && isElement(relatedTarget) && getNodeChildren(tree.nodesRef.current, currentNodeId, false).some((node) => contains(node.context?.elements.floating, relatedTarget))) return;
			if (instance.handler) {
				instance.handler(event);
				return;
			}
			clearPointerEvents();
			if (isHoverOpen() && !isClickLikeOpenEvent$2()) closeWithDelay(event);
		}
		function onNodeClosed(event) {
			if (!tree || !parentId || hasParentChildren()) return;
			childClosedTimeout.start(0, () => {
				tree.events.off("floating.closed", onNodeClosed);
				store.setOpen(false, createChangeEventDetails(triggerHover, event));
				tree.events.emit("floating.closed", event);
			});
		}
		const floating = floatingElement;
		return mergeCleanups(floating && addEventListener(floating, "mouseenter", onFloatingMouseEnter), floating && addEventListener(floating, "mouseleave", onFloatingMouseLeave), floating && addEventListener(floating, "pointerdown", handleInteractInside, true), () => {
			tree?.events.off("floating.closed", onNodeClosed);
		});
	}, [
		enabled,
		floatingElement,
		store,
		dataRef,
		closeDelayProp,
		nodeIdProp,
		isHoverOpen,
		isClickLikeOpenEvent$2,
		clearPointerEvents,
		instance,
		tree,
		parentId,
		childClosedTimeout
	]);
}
// node_modules/@base-ui/react/floating-ui-react/hooks/useHoverReferenceInteraction.mjs
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
var EMPTY_REF = { current: null };
/**
* Provides hover interactions that should be attached to reference or trigger
* elements.
*/
function useHoverReferenceInteraction(store, props = {}) {
	const { enabled = true, delay = 0, handleClose = null, mouseOnly = false, restMs = 0, move = true, triggerElementRef = EMPTY_REF, externalTree, isActiveTrigger = true, getHandleCloseContext, isClosing, shouldOpen: shouldOpenProp, guardStaleOpen = false } = props;
	const { dataRef, events } = store.context;
	const tree = useFloatingTree(externalTree);
	const instance = useHoverInteractionSharedState(store);
	const isHoverCloseActiveRef = import_react.useRef(false);
	const handleCloseRef = useValueAsRef(handleClose);
	const delayRef = useValueAsRef(delay);
	const restMsRef = useValueAsRef(restMs);
	const enabledRef = useValueAsRef(enabled);
	const shouldOpenRef = useValueAsRef(shouldOpenProp);
	const isClosingRef = useValueAsRef(isClosing);
	const isClickLikeOpenEvent$1 = useStableCallback(() => {
		return isClickLikeOpenEvent(dataRef.current.openEvent?.type, instance.interactedInside);
	});
	const checkShouldOpen = useStableCallback(() => {
		return shouldOpenRef.current?.() !== false;
	});
	const isOverInactiveTrigger = useStableCallback((currentDomReference, currentTarget, target) => {
		const allTriggers = store.context.triggerElements;
		if (allTriggers.hasElement(currentTarget)) return !currentDomReference || !contains(currentDomReference, currentTarget);
		if (!isElement(target)) return false;
		const targetElement = target;
		return allTriggers.hasMatchingElement((trigger) => contains(trigger, targetElement)) && (!currentDomReference || !contains(currentDomReference, targetElement));
	});
	const cleanupMouseMoveHandler = useStableCallback(() => {
		if (!instance.handler) return;
		ownerDocument(store.select("domReferenceElement")).removeEventListener("mousemove", instance.handler);
		instance.handler = void 0;
	});
	const clearPointerEvents = useStableCallback(() => {
		clearSafePolygonPointerEventsMutation(instance);
	});
	if (isActiveTrigger) instance.handleCloseOptions = handleClose?.__options;
	import_react.useEffect(() => cleanupMouseMoveHandler, [cleanupMouseMoveHandler]);
	import_react.useEffect(() => {
		if (!enabled) return;
		function onOpenChangeLocal(details) {
			if (!details.open) {
				isHoverCloseActiveRef.current = details.reason === triggerHover;
				cleanupMouseMoveHandler();
				instance.openChangeTimeout.clear();
				instance.restTimeout.clear();
				instance.blockMouseMove = true;
				instance.restTimeoutPending = false;
			} else isHoverCloseActiveRef.current = false;
		}
		events.on("openchange", onOpenChangeLocal);
		return () => {
			events.off("openchange", onOpenChangeLocal);
		};
	}, [
		enabled,
		events,
		instance,
		cleanupMouseMoveHandler
	]);
	import_react.useEffect(() => {
		if (!enabled) return;
		function closeWithDelay(event, runElseBranch = true) {
			const closeDelay = getDelay(delayRef.current, "close", instance.pointerType);
			if (closeDelay) instance.openChangeTimeout.start(closeDelay, () => {
				store.setOpen(false, createChangeEventDetails(triggerHover, event));
				tree?.events.emit("floating.closed", event);
			});
			else if (runElseBranch) {
				instance.openChangeTimeout.clear();
				store.setOpen(false, createChangeEventDetails(triggerHover, event));
				tree?.events.emit("floating.closed", event);
			}
		}
		const trigger = triggerElementRef.current ?? (isActiveTrigger ? store.select("domReferenceElement") : null);
		if (!isElement(trigger)) return;
		function onMouseEnter(event) {
			instance.openChangeTimeout.clear();
			instance.blockMouseMove = false;
			if (mouseOnly && !isMouseLikePointerType(instance.pointerType)) return;
			const restMsValue = getRestMs(restMsRef.current);
			const openDelay = getDelay(delayRef.current, "open", instance.pointerType);
			const eventTarget = getTarget(event);
			const currentTarget = event.currentTarget ?? null;
			const currentDomReference = store.select("domReferenceElement");
			let triggerNode = currentTarget;
			if (isElement(eventTarget) && !store.context.triggerElements.hasElement(eventTarget)) {
				for (const triggerElement of store.context.triggerElements.elements()) if (contains(triggerElement, eventTarget)) {
					triggerNode = triggerElement;
					break;
				}
			}
			if (isElement(currentTarget) && isElement(currentDomReference) && !store.context.triggerElements.hasElement(currentTarget) && contains(currentTarget, currentDomReference)) triggerNode = currentDomReference;
			const isOverInactive = triggerNode == null ? false : isOverInactiveTrigger(currentDomReference, triggerNode, eventTarget);
			const isOpen = store.select("open");
			const isInClosingTransition = isClosingRef.current?.() ?? store.select("transitionStatus") === "ending";
			const isHoverCloseTransition = !isOpen && isInClosingTransition && isHoverCloseActiveRef.current;
			const isReenteringSameTriggerDuringCloseTransition = !isOverInactive && isElement(triggerNode) && isElement(currentDomReference) && contains(currentDomReference, triggerNode) && isHoverCloseTransition;
			const isRestOnlyDelay = restMsValue > 0 && !openDelay;
			const shouldOpenImmediately = isOverInactive && (isOpen || isHoverCloseTransition) || isReenteringSameTriggerDuringCloseTransition;
			const shouldOpen = !isOpen || isOverInactive;
			if (shouldOpenImmediately) {
				if (checkShouldOpen()) store.setOpen(true, createChangeEventDetails(triggerHover, event, triggerNode));
				return;
			}
			if (isRestOnlyDelay) return;
			if (openDelay) instance.openChangeTimeout.start(openDelay, () => {
				if (shouldOpen && checkShouldOpen()) store.setOpen(true, createChangeEventDetails(triggerHover, event, triggerNode));
			});
			else if (shouldOpen) {
				if (checkShouldOpen()) store.setOpen(true, createChangeEventDetails(triggerHover, event, triggerNode));
			}
		}
		function onMouseLeave(event) {
			if (isClickLikeOpenEvent$1()) {
				clearPointerEvents();
				return;
			}
			cleanupMouseMoveHandler();
			const domReferenceElement = store.select("domReferenceElement");
			const doc = ownerDocument(domReferenceElement);
			instance.restTimeout.clear();
			instance.restTimeoutPending = false;
			const handleCloseContextBase = dataRef.current.floatingContext ?? getHandleCloseContext?.();
			if (isTargetInsideEnabledTrigger(event.relatedTarget, store.context.triggerElements)) return;
			if (handleCloseRef.current && handleCloseContextBase) {
				if (!store.select("open")) instance.openChangeTimeout.clear();
				const currentTrigger = triggerElementRef.current;
				instance.handler = handleCloseRef.current({
					...handleCloseContextBase,
					tree,
					x: event.clientX,
					y: event.clientY,
					onClose() {
						clearPointerEvents();
						cleanupMouseMoveHandler();
						if (enabledRef.current && !isClickLikeOpenEvent$1() && currentTrigger === store.select("domReferenceElement")) closeWithDelay(event, true);
					}
				});
				doc.addEventListener("mousemove", instance.handler);
				instance.handler(event);
				return;
			}
			if (instance.pointerType === "touch" ? !contains(store.select("floatingElement"), event.relatedTarget) : true) closeWithDelay(event);
		}
		function onMouseOut(event) {
			if (contains(trigger, event.relatedTarget)) return;
			instance.openChangeTimeout.clear();
			instance.restTimeout.clear();
			instance.restTimeoutPending = false;
		}
		const staleOpenGuard = guardStaleOpen ? addEventListener(trigger, "mouseout", onMouseOut) : void 0;
		if (move) return mergeCleanups(addEventListener(trigger, "mousemove", onMouseEnter, { once: true }), addEventListener(trigger, "mouseenter", onMouseEnter), addEventListener(trigger, "mouseleave", onMouseLeave), staleOpenGuard);
		return mergeCleanups(addEventListener(trigger, "mouseenter", onMouseEnter), addEventListener(trigger, "mouseleave", onMouseLeave), staleOpenGuard);
	}, [
		cleanupMouseMoveHandler,
		clearPointerEvents,
		dataRef,
		delayRef,
		store,
		enabled,
		handleCloseRef,
		instance,
		isActiveTrigger,
		isOverInactiveTrigger,
		isClickLikeOpenEvent$1,
		mouseOnly,
		move,
		restMsRef,
		triggerElementRef,
		tree,
		enabledRef,
		getHandleCloseContext,
		isClosingRef,
		checkShouldOpen,
		guardStaleOpen
	]);
	return import_react.useMemo(() => {
		if (!enabled) return;
		function setPointerRef(event) {
			instance.pointerType = event.pointerType;
		}
		return {
			onPointerDown: setPointerRef,
			onPointerEnter: setPointerRef,
			onMouseMove(event) {
				const { nativeEvent } = event;
				const trigger = event.currentTarget;
				const currentDomReference = store.select("domReferenceElement");
				const currentOpen = store.select("open");
				const isOverInactive = isOverInactiveTrigger(currentDomReference, trigger, event.target);
				if (mouseOnly && !isMouseLikePointerType(instance.pointerType)) return;
				if (currentOpen && isOverInactive && instance.handleCloseOptions?.blockPointerEvents) {
					const floatingElement = store.select("floatingElement");
					if (floatingElement) {
						const scopeElement = instance.handleCloseOptions?.getScope?.() ?? trigger.ownerDocument.body;
						applySafePolygonPointerEventsMutation(instance, {
							scopeElement,
							referenceElement: trigger,
							floatingElement
						});
					}
				}
				const restMsValue = getRestMs(restMsRef.current);
				if (currentOpen && !isOverInactive || restMsValue === 0) return;
				if (!isOverInactive && instance.restTimeoutPending && event.movementX ** 2 + event.movementY ** 2 < 2) return;
				instance.restTimeout.clear();
				function handleMouseMove() {
					instance.restTimeoutPending = false;
					if (isClickLikeOpenEvent$1()) return;
					const latestOpen = store.select("open");
					if (!instance.blockMouseMove && (!latestOpen || isOverInactive) && checkShouldOpen()) store.setOpen(true, createChangeEventDetails(triggerHover, nativeEvent, trigger));
				}
				if (instance.pointerType === "touch") import_react_dom.flushSync(() => {
					handleMouseMove();
				});
				else if (isOverInactive && currentOpen) handleMouseMove();
				else {
					instance.restTimeoutPending = true;
					instance.restTimeout.start(restMsValue, handleMouseMove);
				}
			}
		};
	}, [
		enabled,
		instance,
		isClickLikeOpenEvent$1,
		isOverInactiveTrigger,
		mouseOnly,
		store,
		restMsRef,
		checkShouldOpen
	]);
}
// node_modules/@base-ui/react/floating-ui-react/safePolygon.mjs
var CURSOR_SPEED_THRESHOLD = .1;
var CURSOR_SPEED_THRESHOLD_SQUARED = CURSOR_SPEED_THRESHOLD * CURSOR_SPEED_THRESHOLD;
var POLYGON_BUFFER = .5;
function hasIntersectingEdge(pointX, pointY, xi, yi, xj, yj) {
	return yi >= pointY !== yj >= pointY && pointX <= (xj - xi) * (pointY - yi) / (yj - yi) + xi;
}
function isPointInQuadrilateral(pointX, pointY, x1, y1, x2, y2, x3, y3, x4, y4) {
	let isInsideValue = false;
	if (hasIntersectingEdge(pointX, pointY, x1, y1, x2, y2)) isInsideValue = !isInsideValue;
	if (hasIntersectingEdge(pointX, pointY, x2, y2, x3, y3)) isInsideValue = !isInsideValue;
	if (hasIntersectingEdge(pointX, pointY, x3, y3, x4, y4)) isInsideValue = !isInsideValue;
	if (hasIntersectingEdge(pointX, pointY, x4, y4, x1, y1)) isInsideValue = !isInsideValue;
	return isInsideValue;
}
function isInsideRect(pointX, pointY, rect) {
	return pointX >= rect.x && pointX <= rect.x + rect.width && pointY >= rect.y && pointY <= rect.y + rect.height;
}
function isInsideAxisAlignedRect(pointX, pointY, x1, y1, x2, y2) {
	return pointX >= Math.min(x1, x2) && pointX <= Math.max(x1, x2) && pointY >= Math.min(y1, y2) && pointY <= Math.max(y1, y2);
}
/**
* Generates a safe polygon area that the user can traverse without closing the
* floating element once leaving the reference element.
* @see https://floating-ui.com/docs/useHover#safepolygon
*/
function safePolygon(options = {}) {
	const { blockPointerEvents = false } = options;
	const timeout = new Timeout();
	const fn = ({ x, y, placement, elements, onClose, nodeId, tree }) => {
		const side = placement?.split("-")[0];
		let hasLanded = false;
		let lastX = null;
		let lastY = null;
		let lastCursorTime = typeof performance !== "undefined" ? performance.now() : 0;
		function isCursorMovingSlowly(nextX, nextY) {
			const currentTime = performance.now();
			const elapsedTime = currentTime - lastCursorTime;
			if (lastX === null || lastY === null || elapsedTime === 0) {
				lastX = nextX;
				lastY = nextY;
				lastCursorTime = currentTime;
				return false;
			}
			const deltaX = nextX - lastX;
			const deltaY = nextY - lastY;
			const distanceSquared = deltaX * deltaX + deltaY * deltaY;
			const thresholdSquared = elapsedTime * elapsedTime * CURSOR_SPEED_THRESHOLD_SQUARED;
			lastX = nextX;
			lastY = nextY;
			lastCursorTime = currentTime;
			return distanceSquared < thresholdSquared;
		}
		function close() {
			timeout.clear();
			onClose();
		}
		return function onMouseMove(event) {
			timeout.clear();
			const domReference = elements.domReference;
			const floating = elements.floating;
			if (!domReference || !floating || side == null || x == null || y == null) return;
			const { clientX, clientY } = event;
			const target = getTarget(event);
			const isLeave = event.type === "mouseleave";
			const isOverFloatingEl = contains(floating, target);
			const isOverReferenceEl = contains(domReference, target);
			if (isOverFloatingEl) {
				hasLanded = true;
				if (!isLeave) return;
			}
			if (isOverReferenceEl) {
				hasLanded = false;
				if (!isLeave) {
					hasLanded = true;
					return;
				}
			}
			if (isLeave && isElement(event.relatedTarget) && contains(floating, event.relatedTarget)) return;
			function hasOpenChildNode() {
				return Boolean(tree && getNodeChildren(tree.nodesRef.current, nodeId).length > 0);
			}
			function closeIfNoOpenChild() {
				if (!hasOpenChildNode()) close();
			}
			if (hasOpenChildNode()) return;
			const refRect = domReference.getBoundingClientRect();
			const rect = floating.getBoundingClientRect();
			const cursorLeaveFromRight = x > rect.right - rect.width / 2;
			const cursorLeaveFromBottom = y > rect.bottom - rect.height / 2;
			const isFloatingWider = rect.width > refRect.width;
			const isFloatingTaller = rect.height > refRect.height;
			const left = (isFloatingWider ? refRect : rect).left;
			const right = (isFloatingWider ? refRect : rect).right;
			const top = (isFloatingTaller ? refRect : rect).top;
			const bottom = (isFloatingTaller ? refRect : rect).bottom;
			if (side === "top" && y >= refRect.bottom - 1 || side === "bottom" && y <= refRect.top + 1 || side === "left" && x >= refRect.right - 1 || side === "right" && x <= refRect.left + 1) {
				closeIfNoOpenChild();
				return;
			}
			let isInsideTroughRect = false;
			switch (side) {
				case "top":
					isInsideTroughRect = isInsideAxisAlignedRect(clientX, clientY, left, refRect.top + 1, right, rect.bottom - 1);
					break;
				case "bottom":
					isInsideTroughRect = isInsideAxisAlignedRect(clientX, clientY, left, rect.top + 1, right, refRect.bottom - 1);
					break;
				case "left":
					isInsideTroughRect = isInsideAxisAlignedRect(clientX, clientY, rect.right - 1, bottom, refRect.left + 1, top);
					break;
				case "right": isInsideTroughRect = isInsideAxisAlignedRect(clientX, clientY, refRect.right - 1, bottom, rect.left + 1, top);
			}
			if (isInsideTroughRect) return;
			if (hasLanded && !isInsideRect(clientX, clientY, refRect)) {
				closeIfNoOpenChild();
				return;
			}
			if (!isLeave && isCursorMovingSlowly(clientX, clientY)) {
				closeIfNoOpenChild();
				return;
			}
			let isInsidePolygon = false;
			switch (side) {
				case "top": {
					const cursorXOffset = isFloatingWider ? POLYGON_BUFFER / 2 : POLYGON_BUFFER * 4;
					const cursorPointOneX = isFloatingWider ? x + cursorXOffset : cursorLeaveFromRight ? x + cursorXOffset : x - cursorXOffset;
					const cursorPointTwoX = isFloatingWider ? x - cursorXOffset : cursorLeaveFromRight ? x + cursorXOffset : x - cursorXOffset;
					const cursorPointY = y + POLYGON_BUFFER + 1;
					const commonYLeft = cursorLeaveFromRight ? rect.bottom - POLYGON_BUFFER : isFloatingWider ? rect.bottom - POLYGON_BUFFER : rect.top;
					const commonYRight = cursorLeaveFromRight ? isFloatingWider ? rect.bottom - POLYGON_BUFFER : rect.top : rect.bottom - POLYGON_BUFFER;
					isInsidePolygon = isPointInQuadrilateral(clientX, clientY, cursorPointOneX, cursorPointY, cursorPointTwoX, cursorPointY, rect.left, commonYLeft, rect.right, commonYRight);
					break;
				}
				case "bottom": {
					const cursorXOffset = isFloatingWider ? POLYGON_BUFFER / 2 : POLYGON_BUFFER * 4;
					const cursorPointOneX = isFloatingWider ? x + cursorXOffset : cursorLeaveFromRight ? x + cursorXOffset : x - cursorXOffset;
					const cursorPointTwoX = isFloatingWider ? x - cursorXOffset : cursorLeaveFromRight ? x + cursorXOffset : x - cursorXOffset;
					const cursorPointY = y - POLYGON_BUFFER;
					const commonYLeft = cursorLeaveFromRight ? rect.top + POLYGON_BUFFER : isFloatingWider ? rect.top + POLYGON_BUFFER : rect.bottom;
					const commonYRight = cursorLeaveFromRight ? isFloatingWider ? rect.top + POLYGON_BUFFER : rect.bottom : rect.top + POLYGON_BUFFER;
					isInsidePolygon = isPointInQuadrilateral(clientX, clientY, cursorPointOneX, cursorPointY, cursorPointTwoX, cursorPointY, rect.left, commonYLeft, rect.right, commonYRight);
					break;
				}
				case "left": {
					const cursorYOffset = isFloatingTaller ? POLYGON_BUFFER / 2 : POLYGON_BUFFER * 4;
					const cursorPointOneY = isFloatingTaller ? y + cursorYOffset : cursorLeaveFromBottom ? y + cursorYOffset : y - cursorYOffset;
					const cursorPointTwoY = isFloatingTaller ? y - cursorYOffset : cursorLeaveFromBottom ? y + cursorYOffset : y - cursorYOffset;
					const cursorPointX = x + POLYGON_BUFFER + 1;
					const commonXTop = cursorLeaveFromBottom ? rect.right - POLYGON_BUFFER : isFloatingTaller ? rect.right - POLYGON_BUFFER : rect.left;
					const commonXBottom = cursorLeaveFromBottom ? isFloatingTaller ? rect.right - POLYGON_BUFFER : rect.left : rect.right - POLYGON_BUFFER;
					isInsidePolygon = isPointInQuadrilateral(clientX, clientY, commonXTop, rect.top, commonXBottom, rect.bottom, cursorPointX, cursorPointOneY, cursorPointX, cursorPointTwoY);
					break;
				}
				case "right": {
					const cursorYOffset = isFloatingTaller ? POLYGON_BUFFER / 2 : POLYGON_BUFFER * 4;
					const cursorPointOneY = isFloatingTaller ? y + cursorYOffset : cursorLeaveFromBottom ? y + cursorYOffset : y - cursorYOffset;
					const cursorPointTwoY = isFloatingTaller ? y - cursorYOffset : cursorLeaveFromBottom ? y + cursorYOffset : y - cursorYOffset;
					const cursorPointX = x - POLYGON_BUFFER;
					const commonXTop = cursorLeaveFromBottom ? rect.left + POLYGON_BUFFER : isFloatingTaller ? rect.left + POLYGON_BUFFER : rect.right;
					const commonXBottom = cursorLeaveFromBottom ? isFloatingTaller ? rect.left + POLYGON_BUFFER : rect.right : rect.left + POLYGON_BUFFER;
					isInsidePolygon = isPointInQuadrilateral(clientX, clientY, cursorPointX, cursorPointOneY, cursorPointX, cursorPointTwoY, commonXTop, rect.top, commonXBottom, rect.bottom);
					break;
				}
			}
			if (!isInsidePolygon) closeIfNoOpenChild();
			else if (!hasLanded) timeout.start(40, closeIfNoOpenChild);
		};
	};
	fn.__options = {
		...options,
		blockPointerEvents
	};
	return fn;
}
// node_modules/@base-ui/react/utils/CommonPopupCssVars.mjs
/**
* The width of the parent popup.
* This variable is placed on the 'previous' container and stores the width of the popup when the previous content was rendered.
* It can be used to freeze the dimensions of the popup when animating between different content.
*/
var popupWidth = "--popup-width";
/**
* The height of the parent popup.
* This variable is placed on the 'previous' container and stores the height of the popup when the previous content was rendered.
* It can be used to freeze the dimensions of the popup when animating between different content.
*/
var popupHeight = "--popup-height";
// node_modules/@base-ui/react/utils/usePopupAutoResize.mjs
/**
* Allows the element to automatically resize based on its content while supporting animations.
*/
function usePopupAutoResize(parameters) {
	const { popupElement, positionerElement, content, mounted, onMeasureLayout: onMeasureLayoutParam, onMeasureLayoutComplete: onMeasureLayoutCompleteParam, side, direction } = parameters;
	const runOnceAnimationsFinish = useAnimationsFinished(popupElement, true);
	const animationFrame = useAnimationFrame();
	const committedDimensionsRef = import_react.useRef(null);
	const onMeasureLayout = useStableCallback(onMeasureLayoutParam);
	const onMeasureLayoutComplete = useStableCallback(onMeasureLayoutCompleteParam);
	const anchoringStyles = import_react.useMemo(() => getPopupAnchoringStyles(side, direction), [side, direction]);
	useIsoLayoutEffect(() => {
		if (!mounted) {
			committedDimensionsRef.current = null;
			return;
		}
		if (!popupElement || !positionerElement) return;
		const restoreAnchoringStyles = applyElementStyles(popupElement, anchoringStyles);
		setPopupCssSize(popupElement, "auto");
		const restorePopupPosition = overrideElementStyle(popupElement, "position", "static");
		const restorePopupTransform = overrideElementStyle(popupElement, "transform", "none");
		const restorePopupScale = overrideElementStyle(popupElement, "scale", "1");
		const restorePositionerAvailableSize = applyElementStyles(positionerElement, {
			[availableWidth]: "max-content",
			[availableHeight]: "max-content"
		});
		function restoreMeasurementOverrides() {
			restorePopupPosition();
			restorePopupTransform();
			restorePositionerAvailableSize();
			restorePopupScale();
		}
		onMeasureLayout?.();
		if (committedDimensionsRef.current === null) {
			setPositionerCssSize(positionerElement, "max-content");
			const dimensions = getCssDimensions(popupElement);
			committedDimensionsRef.current = dimensions;
			setPositionerCssSize(positionerElement, dimensions);
			restoreMeasurementOverrides();
			onMeasureLayoutComplete?.(null, dimensions);
			return restoreAnchoringStyles;
		}
		setPositionerCssSize(positionerElement, "max-content");
		const previousDimensions = committedDimensionsRef.current;
		const newDimensions = getCssDimensions(popupElement);
		committedDimensionsRef.current = newDimensions;
		setPopupCssSize(popupElement, previousDimensions);
		restoreMeasurementOverrides();
		onMeasureLayoutComplete?.(previousDimensions, newDimensions);
		setPositionerCssSize(positionerElement, newDimensions);
		const abortController = new AbortController();
		animationFrame.request(() => {
			setPopupCssSize(popupElement, newDimensions);
			runOnceAnimationsFinish(() => {
				popupElement.style.setProperty(popupWidth, "auto");
				popupElement.style.setProperty(popupHeight, "auto");
			}, abortController.signal);
		});
		return () => {
			abortController.abort();
			animationFrame.cancel();
			restoreAnchoringStyles();
		};
	}, [
		content,
		popupElement,
		positionerElement,
		runOnceAnimationsFinish,
		animationFrame,
		mounted,
		onMeasureLayout,
		onMeasureLayoutComplete,
		anchoringStyles
	]);
}
function getPopupAnchoringStyles(side, direction) {
	const isPhysicalTop = side === "top";
	const isPhysicalLeft = side === "left" || side === (direction === "rtl" ? "inline-end" : "inline-start");
	if (!isPhysicalTop && !isPhysicalLeft) return EMPTY_OBJECT;
	return {
		position: "absolute",
		[isPhysicalTop ? "bottom" : "top"]: "0",
		[isPhysicalLeft ? "right" : "left"]: "0"
	};
}
function overrideElementStyle(element, property, value) {
	const originalValue = element.style.getPropertyValue(property);
	element.style.setProperty(property, value);
	return () => {
		element.style.setProperty(property, originalValue);
	};
}
function applyElementStyles(element, styles) {
	const restorers = [];
	for (const [key, value] of Object.entries(styles)) restorers.push(overrideElementStyle(element, key, value));
	return restorers.length ? () => {
		restorers.forEach((restore) => restore());
	} : NOOP;
}
function setPopupCssSize(popupElement, size) {
	const width = size === "auto" ? "auto" : `${size.width}px`;
	const height = size === "auto" ? "auto" : `${size.height}px`;
	popupElement.style.setProperty(popupWidth, width);
	popupElement.style.setProperty(popupHeight, height);
}
function setPositionerCssSize(positionerElement, size) {
	const width = size === "max-content" ? "max-content" : `${size.width}px`;
	const height = size === "max-content" ? "max-content" : `${size.height}px`;
	positionerElement.style.setProperty(positionerWidth, width);
	positionerElement.style.setProperty(positionerHeight, height);
}
// node_modules/@base-ui/react/utils/adaptiveOriginMiddleware.mjs
var adaptiveOrigin = {
	name: "adaptiveOrigin",
	async fn(state) {
		const { x: rawX, y: rawY, rects: { floating: floatRect }, elements: { floating }, platform, strategy, placement } = state;
		const win = getWindow(floating);
		const styles = win.getComputedStyle(floating);
		if (!(styles.transitionDuration !== "0s" && styles.transitionDuration !== "")) return {
			x: rawX,
			y: rawY,
			data: DEFAULT_SIDES
		};
		const offsetParent = await platform.getOffsetParent?.(floating);
		let offsetDimensions = {
			width: 0,
			height: 0
		};
		if (strategy === "fixed" && win?.visualViewport) offsetDimensions = {
			width: win.visualViewport.width,
			height: win.visualViewport.height
		};
		else if (offsetParent === win) {
			const doc = ownerDocument(floating);
			offsetDimensions = {
				width: doc.documentElement.clientWidth,
				height: doc.documentElement.clientHeight
			};
		} else if (await platform.isElement?.(offsetParent)) offsetDimensions = await platform.getDimensions(offsetParent);
		const currentSide = getSide(placement);
		let x = rawX;
		let y = rawY;
		if (currentSide === "left") x = offsetDimensions.width - (rawX + floatRect.width);
		if (currentSide === "top") y = offsetDimensions.height - (rawY + floatRect.height);
		const sideX = currentSide === "left" ? "right" : DEFAULT_SIDES.sideX;
		const sideY = currentSide === "top" ? "bottom" : DEFAULT_SIDES.sideY;
		return {
			x,
			y,
			data: {
				sideX,
				sideY
			}
		};
	}
};
// node_modules/@base-ui/react/utils/CommonViewportDataAttributes.mjs
/**
* Indicates the direction from which the popup was activated.
* This can be used to create directional animations based on how the popup was triggered.
* Contains space-separated values for both horizontal and vertical axes.
* @type {`${'left' | 'right' | ''} ${'down' | 'up' | ''}`}
*/
var activationDirection = "data-activation-direction";
// node_modules/@base-ui/react/utils/usePopupViewport.mjs
var import_jsx_runtime = require_jsx_runtime();
var popupViewportStateMapping = { activationDirection: (value) => value ? { [activationDirection]: value } : null };
/**
* Builds morphing viewport containers for popups that animate between trigger-based content.
* Handles previous-content snapshots, auto-resize, and state attributes for transitions.
*/
function usePopupViewport(parameters) {
	const { store, side, children } = parameters;
	const direction = useDirection();
	const activeTrigger = store.useState("activeTriggerElement");
	const activeTriggerId = store.useState("activeTriggerId");
	const open = store.useState("open");
	const payload = store.useState("payload");
	const mounted = store.useState("mounted");
	const popupElement = store.useState("popupElement");
	const positionerElement = store.useState("positionerElement");
	const previousActiveTrigger = usePreviousValue(open ? activeTrigger : null);
	const currentContentKey = usePopupContentKey(activeTriggerId, payload);
	const capturedNodeRef = import_react.useRef(null);
	const [previousContentNode, setPreviousContentNode] = import_react.useState(null);
	const [newTriggerOffset, setNewTriggerOffset] = import_react.useState(null);
	const currentContainerRef = import_react.useRef(null);
	const previousContainerRef = import_react.useRef(null);
	const onAnimationsFinished = useAnimationsFinished(currentContainerRef, true);
	const cleanupFrame = useAnimationFrame();
	const cleanupControllerRef = import_react.useRef(null);
	const [previousContentDimensions, setPreviousContentDimensions] = import_react.useState(null);
	const [showStartingStyleAttribute, setShowStartingStyleAttribute] = import_react.useState(false);
	useIsoLayoutEffect(() => {
		store.set("adaptiveOrigin", adaptiveOrigin);
		return () => {
			store.set("adaptiveOrigin", void 0);
		};
	}, [store]);
	const handleMeasureLayout = useStableCallback(() => {
		currentContainerRef.current?.style.setProperty("animation", "none");
		currentContainerRef.current?.style.setProperty("transition", "none");
		previousContainerRef.current?.style.setProperty("display", "none");
	});
	const handleMeasureLayoutComplete = useStableCallback((previousDimensions) => {
		currentContainerRef.current?.style.removeProperty("animation");
		currentContainerRef.current?.style.removeProperty("transition");
		previousContainerRef.current?.style.removeProperty("display");
		if (previousDimensions) setPreviousContentDimensions(previousDimensions);
	});
	const armViewportCleanup = useStableCallback(() => {
		cleanupControllerRef.current?.abort();
		const controller = new AbortController();
		cleanupControllerRef.current = controller;
		onAnimationsFinished(() => {
			setPreviousContentNode(null);
			setPreviousContentDimensions(null);
			capturedNodeRef.current = null;
		}, controller.signal);
	});
	const lastHandledTriggerRef = import_react.useRef(null);
	useIsoLayoutEffect(() => {
		if (!open || !mounted) lastHandledTriggerRef.current = null;
	}, [open, mounted]);
	useIsoLayoutEffect(() => {
		if (open && activeTrigger && previousActiveTrigger && activeTrigger !== previousActiveTrigger && lastHandledTriggerRef.current !== activeTrigger && capturedNodeRef.current) {
			setPreviousContentNode(capturedNodeRef.current);
			setShowStartingStyleAttribute(true);
			const offset = calculateRelativePosition(previousActiveTrigger, activeTrigger);
			setNewTriggerOffset(offset);
			lastHandledTriggerRef.current = activeTrigger;
		}
	}, [
		open,
		activeTrigger,
		previousActiveTrigger
	]);
	useIsoLayoutEffect(() => {
		if (previousContentNode == null) return;
		cleanupControllerRef.current?.abort();
		setShowStartingStyleAttribute(true);
		cleanupFrame.request(() => {
			import_react_dom.flushSync(() => {
				setShowStartingStyleAttribute(false);
			});
			armViewportCleanup();
		});
	}, [
		currentContentKey,
		previousContentNode,
		armViewportCleanup,
		cleanupFrame
	]);
	useIsoLayoutEffect(() => {
		const source = currentContainerRef.current;
		if (!source) return;
		const wrapper = ownerDocument(source).createElement("div");
		for (const child of Array.from(source.childNodes)) wrapper.appendChild(child.cloneNode(true));
		capturedNodeRef.current = wrapper;
	});
	const isTransitioning = previousContentNode != null;
	let childrenToRender;
	if (!isTransitioning) childrenToRender = /*#__PURE__*/ (0, import_jsx_runtime.jsx)("div", {
		"data-current": true,
		ref: currentContainerRef,
		children
	}, currentContentKey);
	else childrenToRender = /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [/*#__PURE__*/ (0, import_jsx_runtime.jsx)("div", {
		"data-previous": true,
		inert: inertValue(true),
		ref: previousContainerRef,
		style: {
			...previousContentDimensions ? {
				[popupWidth]: `${previousContentDimensions.width}px`,
				[popupHeight]: `${previousContentDimensions.height}px`
			} : null,
			position: "absolute"
		},
		"data-ending-style": showStartingStyleAttribute ? void 0 : ""
	}, "previous"), /*#__PURE__*/ (0, import_jsx_runtime.jsx)("div", {
		"data-current": true,
		ref: currentContainerRef,
		"data-starting-style": showStartingStyleAttribute ? "" : void 0,
		children
	}, currentContentKey)] });
	useIsoLayoutEffect(() => {
		const container = previousContainerRef.current;
		if (!container || !previousContentNode) return;
		container.replaceChildren(...Array.from(previousContentNode.childNodes));
	}, [previousContentNode]);
	usePopupAutoResize({
		popupElement,
		positionerElement,
		mounted,
		content: payload,
		onMeasureLayout: handleMeasureLayout,
		onMeasureLayoutComplete: handleMeasureLayoutComplete,
		side,
		direction
	});
	const state = {
		activationDirection: getActivationDirection(newTriggerOffset),
		transitioning: isTransitioning
	};
	return {
		children: childrenToRender,
		state
	};
}
/**
* Returns a string describing the provided offset.
* It describes both the horizontal and vertical offset, separated by a space.
*
* @param offset
*/
function getActivationDirection(offset) {
	if (!offset) return;
	return `${getValueWithTolerance(offset.horizontal, 5, "right", "left")} ${getValueWithTolerance(offset.vertical, 5, "down", "up")}`;
}
/**
* Returns a label describing the value (positive/negative) treating values
* within tolerance as zero.
*
* @param value Value to check
* @param tolerance Tolerance to treat the value as zero.
* @param positiveLabel
* @param negativeLabel
* @returns If 0 < abs(value) < tolerance, returns an empty string. Otherwise returns positiveLabel or negativeLabel.
*/
function getValueWithTolerance(value, tolerance, positiveLabel, negativeLabel) {
	if (value > tolerance) return positiveLabel;
	if (value < -tolerance) return negativeLabel;
	return "";
}
/**
* Calculates the relative position between centers of two elements.
*/
function calculateRelativePosition(from, to) {
	const fromRect = from.getBoundingClientRect();
	const toRect = to.getBoundingClientRect();
	const fromCenter = {
		x: fromRect.left + fromRect.width / 2,
		y: fromRect.top + fromRect.height / 2
	};
	const toCenter = {
		x: toRect.left + toRect.width / 2,
		y: toRect.top + toRect.height / 2
	};
	return {
		horizontal: toCenter.x - fromCenter.x,
		vertical: toCenter.y - fromCenter.y
	};
}
/**
* Returns a key that forces remounting content when triggers change or a payload is updated.
*/
function usePopupContentKey(activeTriggerId, payload) {
	const [contentKey, setContentKey] = import_react.useState(0);
	const previousActiveTriggerIdRef = import_react.useRef(activeTriggerId);
	const previousPayloadRef = import_react.useRef(payload);
	const pendingPayloadUpdateRef = import_react.useRef(false);
	useIsoLayoutEffect(() => {
		const previousActiveTriggerId = previousActiveTriggerIdRef.current;
		const previousPayload = previousPayloadRef.current;
		const triggerIdChanged = activeTriggerId !== previousActiveTriggerId;
		const payloadChanged = payload !== previousPayload;
		if (triggerIdChanged) {
			setContentKey((value) => value + 1);
			pendingPayloadUpdateRef.current = !payloadChanged;
		} else if (pendingPayloadUpdateRef.current && payloadChanged) {
			setContentKey((value) => value + 1);
			pendingPayloadUpdateRef.current = false;
		}
		previousActiveTriggerIdRef.current = activeTriggerId;
		previousPayloadRef.current = payload;
	}, [activeTriggerId, payload]);
	return `${activeTriggerId ?? "current"}-${contentKey}`;
}
export { useHoverFloatingInteraction as a, getDelay as c, useHoverReferenceInteraction as i, usePopupViewport as n, useHoverInteractionSharedState as o, safePolygon as r, useFocus as s, popupViewportStateMapping as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlUG9wdXBWaWV3cG9ydC1CYk53X081OS5qcyIsIm5hbWVzIjpbInBsYXRmb3JtLm9zLm1hYyIsInBsYXRmb3JtLmVuZ2luZS53ZWJraXQiLCJSRUFTT05TLnRyaWdnZXJGb2N1cyIsImlzQ2xpY2tMaWtlT3BlbkV2ZW50IiwiaXNDbGlja0xpa2VPcGVuRXZlbnRTaGFyZWQiLCJSRUFTT05TLnRyaWdnZXJIb3ZlciIsImlzSW5zaWRlRW5hYmxlZFRyaWdnZXIiLCJpc0NsaWNrTGlrZU9wZW5FdmVudCIsImlzQ2xpY2tMaWtlT3BlbkV2ZW50U2hhcmVkIiwiUkVBU09OUy50cmlnZ2VySG92ZXIiLCJpc0luc2lkZUVuYWJsZWRUcmlnZ2VyIiwiQ29tbW9uUG9zaXRpb25lckNzc1ZhcnMuYXZhaWxhYmxlV2lkdGgiLCJDb21tb25Qb3NpdGlvbmVyQ3NzVmFycy5hdmFpbGFibGVIZWlnaHQiLCJDb21tb25Qb3B1cENzc1ZhcnMucG9wdXBXaWR0aCIsIkNvbW1vblBvcHVwQ3NzVmFycy5wb3B1cEhlaWdodCIsIkNvbW1vblBvc2l0aW9uZXJDc3NWYXJzLnBvc2l0aW9uZXJXaWR0aCIsIkNvbW1vblBvc2l0aW9uZXJDc3NWYXJzLnBvc2l0aW9uZXJIZWlnaHQiLCJvd25lcldpbmRvdyIsIkNvbW1vblZpZXdwb3J0RGF0YUF0dHJpYnV0ZXMuYWN0aXZhdGlvbkRpcmVjdGlvbiIsIkNvbW1vblBvcHVwQ3NzVmFycy5wb3B1cFdpZHRoIiwiQ29tbW9uUG9wdXBDc3NWYXJzLnBvcHVwSGVpZ2h0Il0sInNvdXJjZXMiOlsiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvaG9va3MvdXNlSG92ZXJTaGFyZWQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvaG9va3MvdXNlRm9jdXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvaG9va3MvdXNlSG92ZXJJbnRlcmFjdGlvblNoYXJlZFN0YXRlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L2hvb2tzL3VzZUhvdmVyRmxvYXRpbmdJbnRlcmFjdGlvbi5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC9ob29rcy91c2VIb3ZlclJlZmVyZW5jZUludGVyYWN0aW9uLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L3NhZmVQb2x5Z29uLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3V0aWxzL0NvbW1vblBvcHVwQ3NzVmFycy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy91c2VQb3B1cEF1dG9SZXNpemUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvYWRhcHRpdmVPcmlnaW5NaWRkbGV3YXJlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3V0aWxzL0NvbW1vblZpZXdwb3J0RGF0YUF0dHJpYnV0ZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvdXNlUG9wdXBWaWV3cG9ydC5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaXNNb3VzZUxpa2VQb2ludGVyVHlwZSB9IGZyb20gXCIuLi91dGlscy9ldmVudC5tanNcIjtcbmV4cG9ydCB7IGlzVGFyZ2V0SW5zaWRlRW5hYmxlZFRyaWdnZXIgYXMgaXNJbnNpZGVFbmFibGVkVHJpZ2dlciB9IGZyb20gXCIuLi91dGlscy9lbGVtZW50Lm1qc1wiO1xuZnVuY3Rpb24gcmVzb2x2ZVZhbHVlKHZhbHVlLCBwb2ludGVyVHlwZSkge1xuICBpZiAocG9pbnRlclR5cGUgIT0gbnVsbCAmJiAhaXNNb3VzZUxpa2VQb2ludGVyVHlwZShwb2ludGVyVHlwZSkpIHtcbiAgICByZXR1cm4gMDtcbiAgfVxuICBpZiAodHlwZW9mIHZhbHVlID09PSAnZnVuY3Rpb24nKSB7XG4gICAgcmV0dXJuIHZhbHVlKCk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdldERlbGF5KHZhbHVlLCBwcm9wLCBwb2ludGVyVHlwZSkge1xuICBjb25zdCByZXN1bHQgPSByZXNvbHZlVmFsdWUodmFsdWUsIHBvaW50ZXJUeXBlKTtcbiAgaWYgKHR5cGVvZiByZXN1bHQgPT09ICdudW1iZXInKSB7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxuICByZXR1cm4gcmVzdWx0Py5bcHJvcF07XG59XG5leHBvcnQgZnVuY3Rpb24gZ2V0UmVzdE1zKHZhbHVlKSB7XG4gIGlmICh0eXBlb2YgdmFsdWUgPT09ICdmdW5jdGlvbicpIHtcbiAgICByZXR1cm4gdmFsdWUoKTtcbiAgfVxuICByZXR1cm4gdmFsdWU7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNDbGlja0xpa2VPcGVuRXZlbnQob3BlbkV2ZW50VHlwZSwgaW50ZXJhY3RlZEluc2lkZSkge1xuICByZXR1cm4gaW50ZXJhY3RlZEluc2lkZSB8fCBvcGVuRXZlbnRUeXBlID09PSAnY2xpY2snIHx8IG9wZW5FdmVudFR5cGUgPT09ICdtb3VzZWRvd24nO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzSG92ZXJPcGVuRXZlbnQob3BlbkV2ZW50VHlwZSkge1xuICByZXR1cm4gb3BlbkV2ZW50VHlwZT8uaW5jbHVkZXMoJ21vdXNlJykgJiYgb3BlbkV2ZW50VHlwZSAhPT0gJ21vdXNlZG93bic7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBhZGRFdmVudExpc3RlbmVyIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvYWRkRXZlbnRMaXN0ZW5lcic7XG5pbXBvcnQgeyBwbGF0Zm9ybSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtJztcbmltcG9ydCB7IG1lcmdlQ2xlYW51cHMgfSBmcm9tICdAYmFzZS11aS91dGlscy9tZXJnZUNsZWFudXBzJztcbmltcG9ydCB7IG93bmVyRG9jdW1lbnQgfSBmcm9tICdAYmFzZS11aS91dGlscy9vd25lcic7XG5pbXBvcnQgeyB1c2VUaW1lb3V0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlVGltZW91dCc7XG5pbXBvcnQgeyBnZXRXaW5kb3csIGlzRWxlbWVudCwgaXNIVE1MRWxlbWVudCB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuaW1wb3J0IHsgY3JlYXRlQXR0cmlidXRlIH0gZnJvbSBcIi4uL3V0aWxzL2NyZWF0ZUF0dHJpYnV0ZS5tanNcIjtcbmltcG9ydCB7IGFjdGl2ZUVsZW1lbnQsIGNvbnRhaW5zLCBnZXRUYXJnZXQsIGlzVGFyZ2V0SW5zaWRlRW5hYmxlZFRyaWdnZXIsIGlzVHlwZWFibGVFbGVtZW50LCBtYXRjaGVzRm9jdXNWaXNpYmxlIH0gZnJvbSBcIi4uL3V0aWxzL2VsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5jb25zdCBpc01hY1NhZmFyaSA9IHBsYXRmb3JtLm9zLm1hYyAmJiBwbGF0Zm9ybS5lbmdpbmUud2Via2l0O1xuLyoqXG4gKiBPcGVucyB0aGUgZmxvYXRpbmcgZWxlbWVudCB3aGlsZSB0aGUgcmVmZXJlbmNlIGVsZW1lbnQgaGFzIGZvY3VzLCBsaWtlIENTU1xuICogYDpmb2N1c2AuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlRm9jdXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUZvY3VzKHN0b3JlLCBwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBlbmFibGVkID0gdHJ1ZSxcbiAgICBkZWxheVxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHtcbiAgICBldmVudHMsXG4gICAgZGF0YVJlZlxuICB9ID0gc3RvcmUuY29udGV4dDtcbiAgY29uc3QgYmxvY2tGb2N1c1JlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIC8vIFRyYWNrIHdoaWNoIHJlZmVyZW5jZSBzaG91bGQgYmUgYmxvY2tlZCBmcm9tIHJlLW9wZW5pbmcgYWZ0ZXIgRXNjYXBlL3ByZXNzIGRpc21pc3NhbC5cbiAgY29uc3QgYmxvY2tlZFJlZmVyZW5jZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3Qga2V5Ym9hcmRNb2RhbGl0eVJlZiA9IFJlYWN0LnVzZVJlZih0cnVlKTtcbiAgY29uc3QgdGltZW91dCA9IHVzZVRpbWVvdXQoKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBkb21SZWZlcmVuY2UgPSBzdG9yZS5zZWxlY3QoJ2RvbVJlZmVyZW5jZUVsZW1lbnQnKTtcbiAgICBpZiAoIWVuYWJsZWQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGNvbnN0IHdpbiA9IGdldFdpbmRvdyhkb21SZWZlcmVuY2UpO1xuXG4gICAgLy8gSWYgdGhlIHJlZmVyZW5jZSB3YXMgZm9jdXNlZCBhbmQgdGhlIHVzZXIgbGVmdCB0aGUgdGFiL3dpbmRvdywgYW5kIHRoZVxuICAgIC8vIGZsb2F0aW5nIGVsZW1lbnQgd2FzIG5vdCBvcGVuLCB0aGUgZm9jdXMgc2hvdWxkIGJlIGJsb2NrZWQgd2hlbiB0aGV5XG4gICAgLy8gcmV0dXJuIHRvIHRoZSB0YWIvd2luZG93LlxuICAgIGZ1bmN0aW9uIG9uQmx1cigpIHtcbiAgICAgIGNvbnN0IGN1cnJlbnREb21SZWZlcmVuY2UgPSBzdG9yZS5zZWxlY3QoJ2RvbVJlZmVyZW5jZUVsZW1lbnQnKTtcbiAgICAgIGlmICghc3RvcmUuc2VsZWN0KCdvcGVuJykgJiYgaXNIVE1MRWxlbWVudChjdXJyZW50RG9tUmVmZXJlbmNlKSAmJiBjdXJyZW50RG9tUmVmZXJlbmNlID09PSBhY3RpdmVFbGVtZW50KG93bmVyRG9jdW1lbnQoY3VycmVudERvbVJlZmVyZW5jZSkpKSB7XG4gICAgICAgIGJsb2NrRm9jdXNSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgIGJsb2NrZWRSZWZlcmVuY2VSZWYuY3VycmVudCA9IGN1cnJlbnREb21SZWZlcmVuY2U7XG4gICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIG9uS2V5RG93bigpIHtcbiAgICAgIGtleWJvYXJkTW9kYWxpdHlSZWYuY3VycmVudCA9IHRydWU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIG9uUG9pbnRlckRvd24oKSB7XG4gICAgICBrZXlib2FyZE1vZGFsaXR5UmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuIG1lcmdlQ2xlYW51cHMoYWRkRXZlbnRMaXN0ZW5lcih3aW4sICdibHVyJywgb25CbHVyKSwgaXNNYWNTYWZhcmkgJiYgYWRkRXZlbnRMaXN0ZW5lcih3aW4sICdrZXlkb3duJywgb25LZXlEb3duLCB0cnVlKSwgaXNNYWNTYWZhcmkgJiYgYWRkRXZlbnRMaXN0ZW5lcih3aW4sICdwb2ludGVyZG93bicsIG9uUG9pbnRlckRvd24sIHRydWUpKTtcbiAgfSwgW3N0b3JlLCBlbmFibGVkXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFlbmFibGVkKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBmdW5jdGlvbiBvbk9wZW5DaGFuZ2VMb2NhbChkZXRhaWxzKSB7XG4gICAgICBpZiAoZGV0YWlscy5yZWFzb24gPT09IFJFQVNPTlMudHJpZ2dlclByZXNzIHx8IGRldGFpbHMucmVhc29uID09PSBSRUFTT05TLmVzY2FwZUtleSkge1xuICAgICAgICBjb25zdCByZWZlcmVuY2VFbGVtZW50ID0gc3RvcmUuc2VsZWN0KCdkb21SZWZlcmVuY2VFbGVtZW50Jyk7XG4gICAgICAgIGlmIChpc0VsZW1lbnQocmVmZXJlbmNlRWxlbWVudCkpIHtcbiAgICAgICAgICBibG9ja2VkUmVmZXJlbmNlUmVmLmN1cnJlbnQgPSByZWZlcmVuY2VFbGVtZW50O1xuICAgICAgICAgIGJsb2NrRm9jdXNSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgZXZlbnRzLm9uKCdvcGVuY2hhbmdlJywgb25PcGVuQ2hhbmdlTG9jYWwpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBldmVudHMub2ZmKCdvcGVuY2hhbmdlJywgb25PcGVuQ2hhbmdlTG9jYWwpO1xuICAgIH07XG4gIH0sIFtldmVudHMsIGVuYWJsZWQsIHN0b3JlXSk7XG4gIGNvbnN0IHJlZmVyZW5jZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGZ1bmN0aW9uIHJlc2V0QmxvY2tlZEZvY3VzKCkge1xuICAgICAgYmxvY2tGb2N1c1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICBibG9ja2VkUmVmZXJlbmNlUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgb25Nb3VzZUxlYXZlKCkge1xuICAgICAgICByZXNldEJsb2NrZWRGb2N1cygpO1xuICAgICAgfSxcbiAgICAgIG9uRm9jdXMoZXZlbnQpIHtcbiAgICAgICAgY29uc3QgZm9jdXNUYXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICBpZiAoYmxvY2tGb2N1c1JlZi5jdXJyZW50KSB7XG4gICAgICAgICAgaWYgKGJsb2NrZWRSZWZlcmVuY2VSZWYuY3VycmVudCA9PT0gZm9jdXNUYXJnZXQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmVzZXRCbG9ja2VkRm9jdXMoKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQubmF0aXZlRXZlbnQpO1xuICAgICAgICBpZiAoaXNFbGVtZW50KHRhcmdldCkpIHtcbiAgICAgICAgICAvLyBTYWZhcmkgZmFpbHMgdG8gbWF0Y2ggYDpmb2N1cy12aXNpYmxlYCBpZiBmb2N1cyB3YXMgaW5pdGlhbGx5XG4gICAgICAgICAgLy8gb3V0c2lkZSB0aGUgZG9jdW1lbnQuXG4gICAgICAgICAgaWYgKGlzTWFjU2FmYXJpICYmICFldmVudC5yZWxhdGVkVGFyZ2V0KSB7XG4gICAgICAgICAgICBpZiAoIWtleWJvYXJkTW9kYWxpdHlSZWYuY3VycmVudCAmJiAhaXNUeXBlYWJsZUVsZW1lbnQodGFyZ2V0KSkge1xuICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIGlmICghbWF0Y2hlc0ZvY3VzVmlzaWJsZSh0YXJnZXQpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG1vdmVkRnJvbU90aGVyRW5hYmxlZFRyaWdnZXIgPSBpc1RhcmdldEluc2lkZUVuYWJsZWRUcmlnZ2VyKGV2ZW50LnJlbGF0ZWRUYXJnZXQsIHN0b3JlLmNvbnRleHQudHJpZ2dlckVsZW1lbnRzKTtcbiAgICAgICAgY29uc3Qge1xuICAgICAgICAgIG5hdGl2ZUV2ZW50LFxuICAgICAgICAgIGN1cnJlbnRUYXJnZXRcbiAgICAgICAgfSA9IGV2ZW50O1xuICAgICAgICBpZiAoc3RvcmUuc2VsZWN0KCdvcGVuJykgJiYgbW92ZWRGcm9tT3RoZXJFbmFibGVkVHJpZ2dlciB8fCAhZGVsYXkpIHtcbiAgICAgICAgICBzdG9yZS5zZXRPcGVuKHRydWUsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLnRyaWdnZXJGb2N1cywgbmF0aXZlRXZlbnQsIGN1cnJlbnRUYXJnZXQpKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdGltZW91dC5zdGFydChkZWxheSwgKCkgPT4ge1xuICAgICAgICAgIGlmIChibG9ja0ZvY3VzUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgc3RvcmUuc2V0T3Blbih0cnVlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy50cmlnZ2VyRm9jdXMsIG5hdGl2ZUV2ZW50LCBjdXJyZW50VGFyZ2V0KSk7XG4gICAgICAgIH0pO1xuICAgICAgfSxcbiAgICAgIG9uQmx1cihldmVudCkge1xuICAgICAgICByZXNldEJsb2NrZWRGb2N1cygpO1xuICAgICAgICBjb25zdCByZWxhdGVkVGFyZ2V0ID0gZXZlbnQucmVsYXRlZFRhcmdldDtcbiAgICAgICAgY29uc3QgbmF0aXZlRXZlbnQgPSBldmVudC5uYXRpdmVFdmVudDtcblxuICAgICAgICAvLyBIaXQgdGhlIG5vbi1tb2RhbCBmb2N1cyBtYW5hZ2VtZW50IHBvcnRhbCBndWFyZC4gRm9jdXMgd2lsbCBiZVxuICAgICAgICAvLyBtb3ZlZCBpbnRvIHRoZSBmbG9hdGluZyBlbGVtZW50IGltbWVkaWF0ZWx5IGFmdGVyLlxuICAgICAgICBjb25zdCBtb3ZlZFRvRm9jdXNHdWFyZCA9IGlzRWxlbWVudChyZWxhdGVkVGFyZ2V0KSAmJiByZWxhdGVkVGFyZ2V0Lmhhc0F0dHJpYnV0ZShjcmVhdGVBdHRyaWJ1dGUoJ2ZvY3VzLWd1YXJkJykpICYmIHJlbGF0ZWRUYXJnZXQuZ2V0QXR0cmlidXRlKCdkYXRhLXR5cGUnKSA9PT0gJ291dHNpZGUnO1xuXG4gICAgICAgIC8vIFdhaXQgZm9yIHRoZSB3aW5kb3cgYmx1ciBsaXN0ZW5lciB0byBmaXJlLlxuICAgICAgICB0aW1lb3V0LnN0YXJ0KDAsICgpID0+IHtcbiAgICAgICAgICBjb25zdCBkb21SZWZlcmVuY2UgPSBzdG9yZS5zZWxlY3QoJ2RvbVJlZmVyZW5jZUVsZW1lbnQnKTtcbiAgICAgICAgICBjb25zdCBhY3RpdmVFbCA9IGFjdGl2ZUVsZW1lbnQob3duZXJEb2N1bWVudChkb21SZWZlcmVuY2UpKTtcblxuICAgICAgICAgIC8vIEZvY3VzIGxlZnQgdGhlIHBhZ2UsIGtlZXAgaXQgb3Blbi5cbiAgICAgICAgICBpZiAoIXJlbGF0ZWRUYXJnZXQgJiYgYWN0aXZlRWwgPT09IGRvbVJlZmVyZW5jZSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIFdoZW4gZm9jdXNpbmcgdGhlIHJlZmVyZW5jZSBlbGVtZW50IChlLmcuIHJlZ3VsYXIgY2xpY2spLCB0aGVuXG4gICAgICAgICAgLy8gY2xpY2tpbmcgaW50byB0aGUgZmxvYXRpbmcgZWxlbWVudCwgcHJldmVudCBpdCBmcm9tIGhpZGluZy5cbiAgICAgICAgICAvLyBOb3RlOiBpdCBtdXN0IGJlIGZvY3VzYWJsZSwgZS5nLiBgdGFiaW5kZXg9XCItMVwiYC5cbiAgICAgICAgICAvLyBXZSBjYW4gbm90IHJlbHkgb24gcmVsYXRlZFRhcmdldCB0byBwb2ludCB0byB0aGUgY29ycmVjdCBlbGVtZW50XG4gICAgICAgICAgLy8gYXMgaXQgd2lsbCBvbmx5IHBvaW50IHRvIHRoZSBzaGFkb3cgaG9zdCBvZiB0aGUgbmV3bHkgZm9jdXNlZCBlbGVtZW50XG4gICAgICAgICAgLy8gYW5kIG5vdCB0aGUgZWxlbWVudCB0aGF0IGFjdHVhbGx5IGhhcyByZWNlaXZlZCBmb2N1cyBpZiBpdCBpcyBsb2NhdGVkXG4gICAgICAgICAgLy8gaW5zaWRlIGEgc2hhZG93IHJvb3QuXG4gICAgICAgICAgaWYgKGNvbnRhaW5zKGRhdGFSZWYuY3VycmVudC5mbG9hdGluZ0NvbnRleHQ/LnJlZnMuZmxvYXRpbmcuY3VycmVudCwgYWN0aXZlRWwpIHx8IGNvbnRhaW5zKGRvbVJlZmVyZW5jZSwgYWN0aXZlRWwpIHx8IG1vdmVkVG9Gb2N1c0d1YXJkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gSWYgdGhlIG5leHQgZm9jdXNlZCBlbGVtZW50IGlzIG9uZSBvZiB0aGUgdHJpZ2dlcnMsIGRvIG5vdCBjbG9zZVxuICAgICAgICAgIC8vIHRoZSBmbG9hdGluZyBlbGVtZW50LiBUaGUgZm9jdXMgaGFuZGxlciBvZiB0aGF0IHRyaWdnZXIgd2lsbFxuICAgICAgICAgIC8vIGhhbmRsZSB0aGUgb3BlbiBzdGF0ZS5cbiAgICAgICAgICBjb25zdCBuZXh0Rm9jdXNlZEVsZW1lbnQgPSByZWxhdGVkVGFyZ2V0ID8/IGFjdGl2ZUVsO1xuICAgICAgICAgIGlmIChpc1RhcmdldEluc2lkZUVuYWJsZWRUcmlnZ2VyKG5leHRGb2N1c2VkRWxlbWVudCwgc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIHN0b3JlLnNldE9wZW4oZmFsc2UsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLnRyaWdnZXJGb2N1cywgbmF0aXZlRXZlbnQpKTtcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW2RhdGFSZWYsIGRlbGF5LCBzdG9yZSwgdGltZW91dF0pO1xuICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiBlbmFibGVkID8ge1xuICAgIHJlZmVyZW5jZSxcbiAgICB0cmlnZ2VyOiByZWZlcmVuY2VcbiAgfSA6IHt9LCBbZW5hYmxlZCwgcmVmZXJlbmNlXSk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgeyB1c2VPbk1vdW50IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlT25Nb3VudCc7XG5pbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVJlZldpdGhJbml0JztcbmltcG9ydCB7IFRpbWVvdXQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VUaW1lb3V0JztcbmltcG9ydCB7IGlzSW50ZXJhY3RpdmVFbGVtZW50IH0gZnJvbSBcIi4uL3V0aWxzLm1qc1wiO1xuZXhwb3J0IHsgaXNJbnRlcmFjdGl2ZUVsZW1lbnQgfTtcbmV4cG9ydCBjbGFzcyBIb3ZlckludGVyYWN0aW9uIHtcbiAgcG9pbnRlclR5cGUgPSB1bmRlZmluZWQ7XG4gIGludGVyYWN0ZWRJbnNpZGUgPSBmYWxzZTtcbiAgaGFuZGxlciA9IHVuZGVmaW5lZDtcbiAgYmxvY2tNb3VzZU1vdmUgPSB0cnVlO1xuICBwZXJmb3JtZWRQb2ludGVyRXZlbnRzTXV0YXRpb24gPSBmYWxzZTtcbiAgcG9pbnRlckV2ZW50c1Njb3BlRWxlbWVudCA9IG51bGw7XG4gIHBvaW50ZXJFdmVudHNSZWZlcmVuY2VFbGVtZW50ID0gbnVsbDtcbiAgcG9pbnRlckV2ZW50c0Zsb2F0aW5nRWxlbWVudCA9IG51bGw7XG4gIHJlc3RUaW1lb3V0UGVuZGluZyA9IGZhbHNlO1xuICBvcGVuQ2hhbmdlVGltZW91dCA9IG5ldyBUaW1lb3V0KCk7XG4gIHJlc3RUaW1lb3V0ID0gbmV3IFRpbWVvdXQoKTtcbiAgaGFuZGxlQ2xvc2VPcHRpb25zID0gdW5kZWZpbmVkO1xuICBzdGF0aWMgY3JlYXRlKCkge1xuICAgIHJldHVybiBuZXcgSG92ZXJJbnRlcmFjdGlvbigpO1xuICB9XG4gIGRpc3Bvc2UgPSAoKSA9PiB7XG4gICAgdGhpcy5vcGVuQ2hhbmdlVGltZW91dC5jbGVhcigpO1xuICAgIHRoaXMucmVzdFRpbWVvdXQuY2xlYXIoKTtcbiAgfTtcbiAgZGlzcG9zZUVmZmVjdCA9ICgpID0+IHtcbiAgICByZXR1cm4gdGhpcy5kaXNwb3NlO1xuICB9O1xufVxuY29uc3QgcG9pbnRlckV2ZW50c011dGF0aW9uT3duZXJCeVNjb3BlRWxlbWVudCA9IG5ldyBXZWFrTWFwKCk7XG5leHBvcnQgZnVuY3Rpb24gY2xlYXJTYWZlUG9seWdvblBvaW50ZXJFdmVudHNNdXRhdGlvbihpbnN0YW5jZSkge1xuICBpZiAoIWluc3RhbmNlLnBlcmZvcm1lZFBvaW50ZXJFdmVudHNNdXRhdGlvbikge1xuICAgIHJldHVybjtcbiAgfVxuICBjb25zdCBzY29wZUVsZW1lbnQgPSBpbnN0YW5jZS5wb2ludGVyRXZlbnRzU2NvcGVFbGVtZW50O1xuICBpZiAoc2NvcGVFbGVtZW50ICYmIHBvaW50ZXJFdmVudHNNdXRhdGlvbk93bmVyQnlTY29wZUVsZW1lbnQuZ2V0KHNjb3BlRWxlbWVudCkgPT09IGluc3RhbmNlKSB7XG4gICAgaW5zdGFuY2UucG9pbnRlckV2ZW50c1Njb3BlRWxlbWVudD8uc3R5bGUucmVtb3ZlUHJvcGVydHkoJ3BvaW50ZXItZXZlbnRzJyk7XG4gICAgaW5zdGFuY2UucG9pbnRlckV2ZW50c1JlZmVyZW5jZUVsZW1lbnQ/LnN0eWxlLnJlbW92ZVByb3BlcnR5KCdwb2ludGVyLWV2ZW50cycpO1xuICAgIGluc3RhbmNlLnBvaW50ZXJFdmVudHNGbG9hdGluZ0VsZW1lbnQ/LnN0eWxlLnJlbW92ZVByb3BlcnR5KCdwb2ludGVyLWV2ZW50cycpO1xuICAgIHBvaW50ZXJFdmVudHNNdXRhdGlvbk93bmVyQnlTY29wZUVsZW1lbnQuZGVsZXRlKHNjb3BlRWxlbWVudCk7XG4gIH1cbiAgaW5zdGFuY2UucGVyZm9ybWVkUG9pbnRlckV2ZW50c011dGF0aW9uID0gZmFsc2U7XG4gIGluc3RhbmNlLnBvaW50ZXJFdmVudHNTY29wZUVsZW1lbnQgPSBudWxsO1xuICBpbnN0YW5jZS5wb2ludGVyRXZlbnRzUmVmZXJlbmNlRWxlbWVudCA9IG51bGw7XG4gIGluc3RhbmNlLnBvaW50ZXJFdmVudHNGbG9hdGluZ0VsZW1lbnQgPSBudWxsO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGFwcGx5U2FmZVBvbHlnb25Qb2ludGVyRXZlbnRzTXV0YXRpb24oaW5zdGFuY2UsIG9wdGlvbnMpIHtcbiAgY29uc3Qge1xuICAgIHNjb3BlRWxlbWVudCxcbiAgICByZWZlcmVuY2VFbGVtZW50LFxuICAgIGZsb2F0aW5nRWxlbWVudFxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgZXhpc3RpbmdPd25lciA9IHBvaW50ZXJFdmVudHNNdXRhdGlvbk93bmVyQnlTY29wZUVsZW1lbnQuZ2V0KHNjb3BlRWxlbWVudCk7XG4gIGlmIChleGlzdGluZ093bmVyICYmIGV4aXN0aW5nT3duZXIgIT09IGluc3RhbmNlKSB7XG4gICAgY2xlYXJTYWZlUG9seWdvblBvaW50ZXJFdmVudHNNdXRhdGlvbihleGlzdGluZ093bmVyKTtcbiAgfVxuICBjbGVhclNhZmVQb2x5Z29uUG9pbnRlckV2ZW50c011dGF0aW9uKGluc3RhbmNlKTtcbiAgaW5zdGFuY2UucGVyZm9ybWVkUG9pbnRlckV2ZW50c011dGF0aW9uID0gdHJ1ZTtcbiAgaW5zdGFuY2UucG9pbnRlckV2ZW50c1Njb3BlRWxlbWVudCA9IHNjb3BlRWxlbWVudDtcbiAgaW5zdGFuY2UucG9pbnRlckV2ZW50c1JlZmVyZW5jZUVsZW1lbnQgPSByZWZlcmVuY2VFbGVtZW50O1xuICBpbnN0YW5jZS5wb2ludGVyRXZlbnRzRmxvYXRpbmdFbGVtZW50ID0gZmxvYXRpbmdFbGVtZW50O1xuICBwb2ludGVyRXZlbnRzTXV0YXRpb25Pd25lckJ5U2NvcGVFbGVtZW50LnNldChzY29wZUVsZW1lbnQsIGluc3RhbmNlKTtcbiAgc2NvcGVFbGVtZW50LnN0eWxlLnBvaW50ZXJFdmVudHMgPSAnbm9uZSc7XG4gIHJlZmVyZW5jZUVsZW1lbnQuc3R5bGUucG9pbnRlckV2ZW50cyA9ICdhdXRvJztcbiAgZmxvYXRpbmdFbGVtZW50LnN0eWxlLnBvaW50ZXJFdmVudHMgPSAnYXV0byc7XG59XG5leHBvcnQgZnVuY3Rpb24gdXNlSG92ZXJJbnRlcmFjdGlvblNoYXJlZFN0YXRlKHN0b3JlKSB7XG4gIGNvbnN0IGRhdGEgPSBzdG9yZS5jb250ZXh0LmRhdGFSZWYuY3VycmVudDtcbiAgY29uc3QgaW5zdGFuY2UgPSB1c2VSZWZXaXRoSW5pdCgoKSA9PiBkYXRhLmhvdmVySW50ZXJhY3Rpb25TdGF0ZSA/PyBIb3ZlckludGVyYWN0aW9uLmNyZWF0ZSgpKS5jdXJyZW50O1xuICBpZiAoIWRhdGEuaG92ZXJJbnRlcmFjdGlvblN0YXRlKSB7XG4gICAgZGF0YS5ob3ZlckludGVyYWN0aW9uU3RhdGUgPSBpbnN0YW5jZTtcbiAgfVxuICB1c2VPbk1vdW50KGRhdGEuaG92ZXJJbnRlcmFjdGlvblN0YXRlLmRpc3Bvc2VFZmZlY3QpO1xuICByZXR1cm4gZGF0YS5ob3ZlckludGVyYWN0aW9uU3RhdGU7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBhZGRFdmVudExpc3RlbmVyIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvYWRkRXZlbnRMaXN0ZW5lcic7XG5pbXBvcnQgeyBtZXJnZUNsZWFudXBzIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvbWVyZ2VDbGVhbnVwcyc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgb3duZXJEb2N1bWVudCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL293bmVyJztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuaW1wb3J0IHsgdXNlVGltZW91dCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVRpbWVvdXQnO1xuaW1wb3J0IHsgaXNFbGVtZW50IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzL2RvbSc7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5pbXBvcnQgeyB1c2VGbG9hdGluZ1BhcmVudE5vZGVJZCwgdXNlRmxvYXRpbmdUcmVlIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvRmxvYXRpbmdUcmVlLm1qc1wiO1xuaW1wb3J0IHsgY2xvc2VzdCwgY29udGFpbnMsIGdldFRhcmdldCB9IGZyb20gXCIuLi91dGlscy9lbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgZ2V0Tm9kZUNoaWxkcmVuIH0gZnJvbSBcIi4uL3V0aWxzL25vZGVzLm1qc1wiO1xuaW1wb3J0IHsgYXBwbHlTYWZlUG9seWdvblBvaW50ZXJFdmVudHNNdXRhdGlvbiwgY2xlYXJTYWZlUG9seWdvblBvaW50ZXJFdmVudHNNdXRhdGlvbiwgaXNJbnRlcmFjdGl2ZUVsZW1lbnQsIHVzZUhvdmVySW50ZXJhY3Rpb25TaGFyZWRTdGF0ZSB9IGZyb20gXCIuL3VzZUhvdmVySW50ZXJhY3Rpb25TaGFyZWRTdGF0ZS5tanNcIjtcbmltcG9ydCB7IGdldERlbGF5LCBpc0NsaWNrTGlrZU9wZW5FdmVudCBhcyBpc0NsaWNrTGlrZU9wZW5FdmVudFNoYXJlZCwgaXNIb3Zlck9wZW5FdmVudCwgaXNJbnNpZGVFbmFibGVkVHJpZ2dlciB9IGZyb20gXCIuL3VzZUhvdmVyU2hhcmVkLm1qc1wiO1xuLyoqXG4gKiBQcm92aWRlcyBob3ZlciBpbnRlcmFjdGlvbnMgdGhhdCBzaG91bGQgYmUgYXR0YWNoZWQgdG8gdGhlIGZsb2F0aW5nIGVsZW1lbnQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VIb3ZlckZsb2F0aW5nSW50ZXJhY3Rpb24oc3RvcmUsIHBhcmFtZXRlcnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgZW5hYmxlZCA9IHRydWUsXG4gICAgY2xvc2VEZWxheTogY2xvc2VEZWxheVByb3AgPSAwLFxuICAgIG5vZGVJZDogbm9kZUlkUHJvcFxuICB9ID0gcGFyYW1ldGVycztcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IGZsb2F0aW5nRWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlKCdmbG9hdGluZ0VsZW1lbnQnKTtcbiAgY29uc3QgZG9tUmVmZXJlbmNlRWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlKCdkb21SZWZlcmVuY2VFbGVtZW50Jyk7XG4gIGNvbnN0IHtcbiAgICBkYXRhUmVmXG4gIH0gPSBzdG9yZS5jb250ZXh0O1xuICBjb25zdCB0cmVlID0gdXNlRmxvYXRpbmdUcmVlKCk7XG4gIGNvbnN0IHBhcmVudElkID0gdXNlRmxvYXRpbmdQYXJlbnROb2RlSWQoKTtcbiAgY29uc3QgaW5zdGFuY2UgPSB1c2VIb3ZlckludGVyYWN0aW9uU2hhcmVkU3RhdGUoc3RvcmUpO1xuICBjb25zdCBjaGlsZENsb3NlZFRpbWVvdXQgPSB1c2VUaW1lb3V0KCk7XG4gIGNvbnN0IGlzQ2xpY2tMaWtlT3BlbkV2ZW50ID0gdXNlU3RhYmxlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHJldHVybiBpc0NsaWNrTGlrZU9wZW5FdmVudFNoYXJlZChkYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50Py50eXBlLCBpbnN0YW5jZS5pbnRlcmFjdGVkSW5zaWRlKTtcbiAgfSk7XG4gIGNvbnN0IGlzSG92ZXJPcGVuID0gdXNlU3RhYmxlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHJldHVybiBpc0hvdmVyT3BlbkV2ZW50KGRhdGFSZWYuY3VycmVudC5vcGVuRXZlbnQ/LnR5cGUpO1xuICB9KTtcbiAgY29uc3QgY2xlYXJQb2ludGVyRXZlbnRzID0gdXNlU3RhYmxlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNsZWFyU2FmZVBvbHlnb25Qb2ludGVyRXZlbnRzTXV0YXRpb24oaW5zdGFuY2UpO1xuICB9KTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW9wZW4pIHtcbiAgICAgIGluc3RhbmNlLnBvaW50ZXJUeXBlID0gdW5kZWZpbmVkO1xuICAgICAgaW5zdGFuY2UucmVzdFRpbWVvdXRQZW5kaW5nID0gZmFsc2U7XG4gICAgICBpbnN0YW5jZS5pbnRlcmFjdGVkSW5zaWRlID0gZmFsc2U7XG4gICAgICBjbGVhclBvaW50ZXJFdmVudHMoKTtcbiAgICB9XG4gIH0sIFtvcGVuLCBpbnN0YW5jZSwgY2xlYXJQb2ludGVyRXZlbnRzXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgcmV0dXJuIGNsZWFyUG9pbnRlckV2ZW50cztcbiAgfSwgW2NsZWFyUG9pbnRlckV2ZW50c10pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgaWYgKG9wZW4gJiYgaW5zdGFuY2UuaGFuZGxlQ2xvc2VPcHRpb25zPy5ibG9ja1BvaW50ZXJFdmVudHMgJiYgaXNIb3Zlck9wZW4oKSAmJiBpc0VsZW1lbnQoZG9tUmVmZXJlbmNlRWxlbWVudCkgJiYgZmxvYXRpbmdFbGVtZW50KSB7XG4gICAgICBjb25zdCByZWYgPSBkb21SZWZlcmVuY2VFbGVtZW50O1xuICAgICAgY29uc3QgZmxvYXRpbmdFbCA9IGZsb2F0aW5nRWxlbWVudDtcbiAgICAgIGNvbnN0IGRvYyA9IG93bmVyRG9jdW1lbnQoZmxvYXRpbmdFbGVtZW50KTtcbiAgICAgIGNvbnN0IHBhcmVudEZsb2F0aW5nID0gdHJlZT8ubm9kZXNSZWYuY3VycmVudC5maW5kKG5vZGUgPT4gbm9kZS5pZCA9PT0gcGFyZW50SWQpPy5jb250ZXh0Py5lbGVtZW50cy5mbG9hdGluZztcbiAgICAgIGlmIChwYXJlbnRGbG9hdGluZykge1xuICAgICAgICBwYXJlbnRGbG9hdGluZy5zdHlsZS5wb2ludGVyRXZlbnRzID0gJyc7XG4gICAgICB9XG5cbiAgICAgIC8vIEEga2VlcC1tb3VudGVkIHN1Ym1lbnUgY2FuIGFwcGVhciBpbiB0aGUgdHJlZSBiZWZvcmUgaXQgb3BlbnMsIHNvIGFcbiAgICAgIC8vIGNhY2hlZCBzY29wZSBvciBwYXJlbnQgbG9va3VwIG1heSByZXNvbHZlIHRvIHRoZSBzdWJtZW51IGl0c2VsZi4gVGhhdFxuICAgICAgLy8gd291bGQgbm90IHNoaWVsZCBzaWJsaW5nIGl0ZW1zIGluIHRoZSBwYXJlbnQgbWVudS5cbiAgICAgIGNvbnN0IGNhY2hlZFNjb3BlRWxlbWVudCA9IGluc3RhbmNlLnBvaW50ZXJFdmVudHNTY29wZUVsZW1lbnQgIT09IGZsb2F0aW5nRWwgPyBpbnN0YW5jZS5wb2ludGVyRXZlbnRzU2NvcGVFbGVtZW50IDogbnVsbDtcbiAgICAgIGNvbnN0IHBhcmVudFNjb3BlRWxlbWVudCA9IHBhcmVudEZsb2F0aW5nICE9PSBmbG9hdGluZ0VsID8gcGFyZW50RmxvYXRpbmcgOiBudWxsO1xuICAgICAgY29uc3Qgc2NvcGVFbGVtZW50ID0gaW5zdGFuY2UuaGFuZGxlQ2xvc2VPcHRpb25zPy5nZXRTY29wZT8uKCkgPz8gY2FjaGVkU2NvcGVFbGVtZW50ID8/IHBhcmVudFNjb3BlRWxlbWVudCA/PyBjbG9zZXN0KHJlZiwgJ1tkYXRhLXJvb3Rvd25lcmlkXScpID8/IGRvYy5ib2R5O1xuICAgICAgYXBwbHlTYWZlUG9seWdvblBvaW50ZXJFdmVudHNNdXRhdGlvbihpbnN0YW5jZSwge1xuICAgICAgICBzY29wZUVsZW1lbnQsXG4gICAgICAgIHJlZmVyZW5jZUVsZW1lbnQ6IHJlZixcbiAgICAgICAgZmxvYXRpbmdFbGVtZW50OiBmbG9hdGluZ0VsXG4gICAgICB9KTtcbiAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgIGNsZWFyUG9pbnRlckV2ZW50cygpO1xuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfSwgW2VuYWJsZWQsIG9wZW4sIGRvbVJlZmVyZW5jZUVsZW1lbnQsIGZsb2F0aW5nRWxlbWVudCwgaW5zdGFuY2UsIGlzSG92ZXJPcGVuLCB0cmVlLCBwYXJlbnRJZCwgY2xlYXJQb2ludGVyRXZlbnRzXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFlbmFibGVkKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBmdW5jdGlvbiBoYXNQYXJlbnRDaGlsZHJlbigpIHtcbiAgICAgIHJldHVybiAhISh0cmVlICYmIHBhcmVudElkICYmIGdldE5vZGVDaGlsZHJlbih0cmVlLm5vZGVzUmVmLmN1cnJlbnQsIHBhcmVudElkKS5sZW5ndGggPiAwKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gY2xvc2VXaXRoRGVsYXkoZXZlbnQpIHtcbiAgICAgIGNvbnN0IGNsb3NlRGVsYXkgPSBnZXREZWxheShjbG9zZURlbGF5UHJvcCwgJ2Nsb3NlJywgaW5zdGFuY2UucG9pbnRlclR5cGUpO1xuICAgICAgY29uc3QgY2xvc2UgPSAoKSA9PiB7XG4gICAgICAgIHN0b3JlLnNldE9wZW4oZmFsc2UsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLnRyaWdnZXJIb3ZlciwgZXZlbnQpKTtcbiAgICAgICAgdHJlZT8uZXZlbnRzLmVtaXQoJ2Zsb2F0aW5nLmNsb3NlZCcsIGV2ZW50KTtcbiAgICAgIH07XG4gICAgICBpZiAoY2xvc2VEZWxheSkge1xuICAgICAgICBpbnN0YW5jZS5vcGVuQ2hhbmdlVGltZW91dC5zdGFydChjbG9zZURlbGF5LCBjbG9zZSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpbnN0YW5jZS5vcGVuQ2hhbmdlVGltZW91dC5jbGVhcigpO1xuICAgICAgICBjbG9zZSgpO1xuICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVJbnRlcmFjdEluc2lkZShldmVudCkge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gZ2V0VGFyZ2V0KGV2ZW50KTtcbiAgICAgIGlmICghaXNJbnRlcmFjdGl2ZUVsZW1lbnQodGFyZ2V0KSkge1xuICAgICAgICBpbnN0YW5jZS5pbnRlcmFjdGVkSW5zaWRlID0gZmFsc2U7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGluc3RhbmNlLmludGVyYWN0ZWRJbnNpZGUgPSBjbG9zZXN0KHRhcmdldCwgJ1thcmlhLWhhc3BvcHVwXScpICE9IG51bGw7XG4gICAgfVxuICAgIGZ1bmN0aW9uIG9uRmxvYXRpbmdNb3VzZUVudGVyKCkge1xuICAgICAgaW5zdGFuY2Uub3BlbkNoYW5nZVRpbWVvdXQuY2xlYXIoKTtcbiAgICAgIGNoaWxkQ2xvc2VkVGltZW91dC5jbGVhcigpO1xuICAgICAgdHJlZT8uZXZlbnRzLm9mZignZmxvYXRpbmcuY2xvc2VkJywgb25Ob2RlQ2xvc2VkKTtcbiAgICAgIGNsZWFyUG9pbnRlckV2ZW50cygpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBvbkZsb2F0aW5nTW91c2VMZWF2ZShldmVudCkge1xuICAgICAgaWYgKGhhc1BhcmVudENoaWxkcmVuKCkgJiYgdHJlZSkge1xuICAgICAgICB0cmVlLmV2ZW50cy5vbignZmxvYXRpbmcuY2xvc2VkJywgb25Ob2RlQ2xvc2VkKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGlzSW5zaWRlRW5hYmxlZFRyaWdnZXIoZXZlbnQucmVsYXRlZFRhcmdldCwgc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMpKSB7XG4gICAgICAgIC8vIElmIHRoZSBtb3VzZSBpcyBsZWF2aW5nIHRoZSByZWZlcmVuY2UgZWxlbWVudCB0byBhbm90aGVyIHRyaWdnZXIsIGRvbid0IGV4cGxpY2l0bHkgY2xvc2UgdGhlIHBvcHVwXG4gICAgICAgIC8vIGFzIGl0IHdpbGwgYmUgbW92ZWQuXG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGN1cnJlbnROb2RlSWQgPSBkYXRhUmVmLmN1cnJlbnQuZmxvYXRpbmdDb250ZXh0Py5ub2RlSWQgPz8gbm9kZUlkUHJvcDtcbiAgICAgIGNvbnN0IHJlbGF0ZWRUYXJnZXQgPSBldmVudC5yZWxhdGVkVGFyZ2V0O1xuICAgICAgY29uc3QgaXNNb3ZpbmdJbnRvRGVzY2VuZGFudEZsb2F0aW5nID0gdHJlZSAmJiBjdXJyZW50Tm9kZUlkICYmIGlzRWxlbWVudChyZWxhdGVkVGFyZ2V0KSAmJiBnZXROb2RlQ2hpbGRyZW4odHJlZS5ub2Rlc1JlZi5jdXJyZW50LCBjdXJyZW50Tm9kZUlkLCBmYWxzZSkuc29tZShub2RlID0+IGNvbnRhaW5zKG5vZGUuY29udGV4dD8uZWxlbWVudHMuZmxvYXRpbmcsIHJlbGF0ZWRUYXJnZXQpKTtcbiAgICAgIGlmIChpc01vdmluZ0ludG9EZXNjZW5kYW50RmxvYXRpbmcpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBJZiB0aGUgc2FmZVBvbHlnb24gaGFuZGxlciBpcyBhY3RpdmUsIGxldCBpdCBoYW5kbGUgdGhlIGNsb3NlIGxvZ2ljLlxuICAgICAgaWYgKGluc3RhbmNlLmhhbmRsZXIpIHtcbiAgICAgICAgaW5zdGFuY2UuaGFuZGxlcihldmVudCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNsZWFyUG9pbnRlckV2ZW50cygpO1xuICAgICAgaWYgKGlzSG92ZXJPcGVuKCkgJiYgIWlzQ2xpY2tMaWtlT3BlbkV2ZW50KCkpIHtcbiAgICAgICAgY2xvc2VXaXRoRGVsYXkoZXZlbnQpO1xuICAgICAgfVxuICAgIH1cbiAgICBmdW5jdGlvbiBvbk5vZGVDbG9zZWQoZXZlbnQpIHtcbiAgICAgIGlmICghdHJlZSB8fCAhcGFyZW50SWQgfHwgaGFzUGFyZW50Q2hpbGRyZW4oKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICAvLyBBbGxvdyB0aGUgbW91c2VlbnRlciBldmVudCB0byBmaXJlIGluIGNhc2UgY2hpbGQgd2FzIGNsb3NlZCBiZWNhdXNlIG1vdXNlIG1vdmVkIGludG8gcGFyZW50LlxuICAgICAgY2hpbGRDbG9zZWRUaW1lb3V0LnN0YXJ0KDAsICgpID0+IHtcbiAgICAgICAgdHJlZS5ldmVudHMub2ZmKCdmbG9hdGluZy5jbG9zZWQnLCBvbk5vZGVDbG9zZWQpO1xuICAgICAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy50cmlnZ2VySG92ZXIsIGV2ZW50KSk7XG4gICAgICAgIHRyZWUuZXZlbnRzLmVtaXQoJ2Zsb2F0aW5nLmNsb3NlZCcsIGV2ZW50KTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCBmbG9hdGluZyA9IGZsb2F0aW5nRWxlbWVudDtcbiAgICByZXR1cm4gbWVyZ2VDbGVhbnVwcyhmbG9hdGluZyAmJiBhZGRFdmVudExpc3RlbmVyKGZsb2F0aW5nLCAnbW91c2VlbnRlcicsIG9uRmxvYXRpbmdNb3VzZUVudGVyKSwgZmxvYXRpbmcgJiYgYWRkRXZlbnRMaXN0ZW5lcihmbG9hdGluZywgJ21vdXNlbGVhdmUnLCBvbkZsb2F0aW5nTW91c2VMZWF2ZSksIGZsb2F0aW5nICYmIGFkZEV2ZW50TGlzdGVuZXIoZmxvYXRpbmcsICdwb2ludGVyZG93bicsIGhhbmRsZUludGVyYWN0SW5zaWRlLCB0cnVlKSwgKCkgPT4ge1xuICAgICAgdHJlZT8uZXZlbnRzLm9mZignZmxvYXRpbmcuY2xvc2VkJywgb25Ob2RlQ2xvc2VkKTtcbiAgICB9KTtcbiAgfSwgW2VuYWJsZWQsIGZsb2F0aW5nRWxlbWVudCwgc3RvcmUsIGRhdGFSZWYsIGNsb3NlRGVsYXlQcm9wLCBub2RlSWRQcm9wLCBpc0hvdmVyT3BlbiwgaXNDbGlja0xpa2VPcGVuRXZlbnQsIGNsZWFyUG9pbnRlckV2ZW50cywgaW5zdGFuY2UsIHRyZWUsIHBhcmVudElkLCBjaGlsZENsb3NlZFRpbWVvdXRdKTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCAqIGFzIFJlYWN0RE9NIGZyb20gJ3JlYWN0LWRvbSc7XG5pbXBvcnQgeyBhZGRFdmVudExpc3RlbmVyIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvYWRkRXZlbnRMaXN0ZW5lcic7XG5pbXBvcnQgeyBtZXJnZUNsZWFudXBzIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvbWVyZ2VDbGVhbnVwcyc7XG5pbXBvcnQgeyBvd25lckRvY3VtZW50IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvb3duZXInO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyB1c2VWYWx1ZUFzUmVmIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlVmFsdWVBc1JlZic7XG5pbXBvcnQgeyBpc0VsZW1lbnQgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY3JlYXRlQmFzZVVJRXZlbnREZXRhaWxzLm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcbmltcG9ydCB7IHVzZUZsb2F0aW5nVHJlZSB9IGZyb20gXCIuLi9jb21wb25lbnRzL0Zsb2F0aW5nVHJlZS5tanNcIjtcbmltcG9ydCB7IGNvbnRhaW5zLCBnZXRUYXJnZXQgfSBmcm9tIFwiLi4vdXRpbHMvZWxlbWVudC5tanNcIjtcbmltcG9ydCB7IGlzTW91c2VMaWtlUG9pbnRlclR5cGUgfSBmcm9tIFwiLi4vdXRpbHMvZXZlbnQubWpzXCI7XG5pbXBvcnQgeyBhcHBseVNhZmVQb2x5Z29uUG9pbnRlckV2ZW50c011dGF0aW9uLCBjbGVhclNhZmVQb2x5Z29uUG9pbnRlckV2ZW50c011dGF0aW9uLCB1c2VIb3ZlckludGVyYWN0aW9uU2hhcmVkU3RhdGUgfSBmcm9tIFwiLi91c2VIb3ZlckludGVyYWN0aW9uU2hhcmVkU3RhdGUubWpzXCI7XG5pbXBvcnQgeyBnZXREZWxheSwgZ2V0UmVzdE1zLCBpc0NsaWNrTGlrZU9wZW5FdmVudCBhcyBpc0NsaWNrTGlrZU9wZW5FdmVudFNoYXJlZCwgaXNJbnNpZGVFbmFibGVkVHJpZ2dlciB9IGZyb20gXCIuL3VzZUhvdmVyU2hhcmVkLm1qc1wiO1xuY29uc3QgRU1QVFlfUkVGID0ge1xuICBjdXJyZW50OiBudWxsXG59O1xuXG4vKipcbiAqIFByb3ZpZGVzIGhvdmVyIGludGVyYWN0aW9ucyB0aGF0IHNob3VsZCBiZSBhdHRhY2hlZCB0byByZWZlcmVuY2Ugb3IgdHJpZ2dlclxuICogZWxlbWVudHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VIb3ZlclJlZmVyZW5jZUludGVyYWN0aW9uKHN0b3JlLCBwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBlbmFibGVkID0gdHJ1ZSxcbiAgICBkZWxheSA9IDAsXG4gICAgaGFuZGxlQ2xvc2UgPSBudWxsLFxuICAgIG1vdXNlT25seSA9IGZhbHNlLFxuICAgIHJlc3RNcyA9IDAsXG4gICAgbW92ZSA9IHRydWUsXG4gICAgdHJpZ2dlckVsZW1lbnRSZWYgPSBFTVBUWV9SRUYsXG4gICAgZXh0ZXJuYWxUcmVlLFxuICAgIGlzQWN0aXZlVHJpZ2dlciA9IHRydWUsXG4gICAgZ2V0SGFuZGxlQ2xvc2VDb250ZXh0LFxuICAgIGlzQ2xvc2luZyxcbiAgICBzaG91bGRPcGVuOiBzaG91bGRPcGVuUHJvcCxcbiAgICBndWFyZFN0YWxlT3BlbiA9IGZhbHNlXG4gIH0gPSBwcm9wcztcbiAgY29uc3Qge1xuICAgIGRhdGFSZWYsXG4gICAgZXZlbnRzXG4gIH0gPSBzdG9yZS5jb250ZXh0O1xuICBjb25zdCB0cmVlID0gdXNlRmxvYXRpbmdUcmVlKGV4dGVybmFsVHJlZSk7XG4gIGNvbnN0IGluc3RhbmNlID0gdXNlSG92ZXJJbnRlcmFjdGlvblNoYXJlZFN0YXRlKHN0b3JlKTtcbiAgY29uc3QgaXNIb3ZlckNsb3NlQWN0aXZlUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgaGFuZGxlQ2xvc2VSZWYgPSB1c2VWYWx1ZUFzUmVmKGhhbmRsZUNsb3NlKTtcbiAgY29uc3QgZGVsYXlSZWYgPSB1c2VWYWx1ZUFzUmVmKGRlbGF5KTtcbiAgY29uc3QgcmVzdE1zUmVmID0gdXNlVmFsdWVBc1JlZihyZXN0TXMpO1xuICBjb25zdCBlbmFibGVkUmVmID0gdXNlVmFsdWVBc1JlZihlbmFibGVkKTtcbiAgY29uc3Qgc2hvdWxkT3BlblJlZiA9IHVzZVZhbHVlQXNSZWYoc2hvdWxkT3BlblByb3ApO1xuICBjb25zdCBpc0Nsb3NpbmdSZWYgPSB1c2VWYWx1ZUFzUmVmKGlzQ2xvc2luZyk7XG4gIGNvbnN0IGlzQ2xpY2tMaWtlT3BlbkV2ZW50ID0gdXNlU3RhYmxlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHJldHVybiBpc0NsaWNrTGlrZU9wZW5FdmVudFNoYXJlZChkYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50Py50eXBlLCBpbnN0YW5jZS5pbnRlcmFjdGVkSW5zaWRlKTtcbiAgfSk7XG4gIGNvbnN0IGNoZWNrU2hvdWxkT3BlbiA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IHtcbiAgICByZXR1cm4gc2hvdWxkT3BlblJlZi5jdXJyZW50Py4oKSAhPT0gZmFsc2U7XG4gIH0pO1xuICBjb25zdCBpc092ZXJJbmFjdGl2ZVRyaWdnZXIgPSB1c2VTdGFibGVDYWxsYmFjaygoY3VycmVudERvbVJlZmVyZW5jZSwgY3VycmVudFRhcmdldCwgdGFyZ2V0KSA9PiB7XG4gICAgY29uc3QgYWxsVHJpZ2dlcnMgPSBzdG9yZS5jb250ZXh0LnRyaWdnZXJFbGVtZW50cztcblxuICAgIC8vIEZhc3QgcGF0aCBmb3Igbm9ybWFsIHVzYWdlIHdoZXJlIGhhbmRsZXJzIGFyZSBhdHRhY2hlZCBkaXJlY3RseSB0byB0cmlnZ2Vycy5cbiAgICBpZiAoYWxsVHJpZ2dlcnMuaGFzRWxlbWVudChjdXJyZW50VGFyZ2V0KSkge1xuICAgICAgcmV0dXJuICFjdXJyZW50RG9tUmVmZXJlbmNlIHx8ICFjb250YWlucyhjdXJyZW50RG9tUmVmZXJlbmNlLCBjdXJyZW50VGFyZ2V0KTtcbiAgICB9XG5cbiAgICAvLyBGYWxsYmFjayBmb3IgZGVsZWdhdGVkL3dyYXBwZXIgdXNhZ2Ugd2hlcmUgY3VycmVudFRhcmdldCBtYXkgYmUgb3V0c2lkZSB0aGUgdHJpZ2dlciBtYXAuXG4gICAgaWYgKCFpc0VsZW1lbnQodGFyZ2V0KSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCB0YXJnZXRFbGVtZW50ID0gdGFyZ2V0O1xuICAgIHJldHVybiBhbGxUcmlnZ2Vycy5oYXNNYXRjaGluZ0VsZW1lbnQodHJpZ2dlciA9PiBjb250YWlucyh0cmlnZ2VyLCB0YXJnZXRFbGVtZW50KSkgJiYgKCFjdXJyZW50RG9tUmVmZXJlbmNlIHx8ICFjb250YWlucyhjdXJyZW50RG9tUmVmZXJlbmNlLCB0YXJnZXRFbGVtZW50KSk7XG4gIH0pO1xuICBjb25zdCBjbGVhbnVwTW91c2VNb3ZlSGFuZGxlciA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IHtcbiAgICBpZiAoIWluc3RhbmNlLmhhbmRsZXIpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChzdG9yZS5zZWxlY3QoJ2RvbVJlZmVyZW5jZUVsZW1lbnQnKSk7XG4gICAgZG9jLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21vdXNlbW92ZScsIGluc3RhbmNlLmhhbmRsZXIpO1xuICAgIGluc3RhbmNlLmhhbmRsZXIgPSB1bmRlZmluZWQ7XG4gIH0pO1xuICBjb25zdCBjbGVhclBvaW50ZXJFdmVudHMgPSB1c2VTdGFibGVDYWxsYmFjaygoKSA9PiB7XG4gICAgY2xlYXJTYWZlUG9seWdvblBvaW50ZXJFdmVudHNNdXRhdGlvbihpbnN0YW5jZSk7XG4gIH0pO1xuICBpZiAoaXNBY3RpdmVUcmlnZ2VyKSB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVuZGVyc2NvcmUtZGFuZ2xlXG4gICAgaW5zdGFuY2UuaGFuZGxlQ2xvc2VPcHRpb25zID0gaGFuZGxlQ2xvc2U/Ll9fb3B0aW9ucztcbiAgfVxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4gY2xlYW51cE1vdXNlTW92ZUhhbmRsZXIsIFtjbGVhbnVwTW91c2VNb3ZlSGFuZGxlcl0pO1xuXG4gIC8vIFdoZW4gY2xvc2luZyBiZWZvcmUgb3BlbmluZywgY2xlYXIgdGhlIGRlbGF5IHRpbWVvdXRzIHRvIGNhbmNlbCBpdFxuICAvLyBmcm9tIHNob3dpbmcuXG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFlbmFibGVkKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBmdW5jdGlvbiBvbk9wZW5DaGFuZ2VMb2NhbChkZXRhaWxzKSB7XG4gICAgICBpZiAoIWRldGFpbHMub3Blbikge1xuICAgICAgICBpc0hvdmVyQ2xvc2VBY3RpdmVSZWYuY3VycmVudCA9IGRldGFpbHMucmVhc29uID09PSBSRUFTT05TLnRyaWdnZXJIb3ZlcjtcbiAgICAgICAgY2xlYW51cE1vdXNlTW92ZUhhbmRsZXIoKTtcbiAgICAgICAgaW5zdGFuY2Uub3BlbkNoYW5nZVRpbWVvdXQuY2xlYXIoKTtcbiAgICAgICAgaW5zdGFuY2UucmVzdFRpbWVvdXQuY2xlYXIoKTtcbiAgICAgICAgaW5zdGFuY2UuYmxvY2tNb3VzZU1vdmUgPSB0cnVlO1xuICAgICAgICBpbnN0YW5jZS5yZXN0VGltZW91dFBlbmRpbmcgPSBmYWxzZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGlzSG92ZXJDbG9zZUFjdGl2ZVJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICAgIGV2ZW50cy5vbignb3BlbmNoYW5nZScsIG9uT3BlbkNoYW5nZUxvY2FsKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZXZlbnRzLm9mZignb3BlbmNoYW5nZScsIG9uT3BlbkNoYW5nZUxvY2FsKTtcbiAgICB9O1xuICB9LCBbZW5hYmxlZCwgZXZlbnRzLCBpbnN0YW5jZSwgY2xlYW51cE1vdXNlTW92ZUhhbmRsZXJdKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWVuYWJsZWQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNsb3NlV2l0aERlbGF5KGV2ZW50LCBydW5FbHNlQnJhbmNoID0gdHJ1ZSkge1xuICAgICAgY29uc3QgY2xvc2VEZWxheSA9IGdldERlbGF5KGRlbGF5UmVmLmN1cnJlbnQsICdjbG9zZScsIGluc3RhbmNlLnBvaW50ZXJUeXBlKTtcbiAgICAgIGlmIChjbG9zZURlbGF5KSB7XG4gICAgICAgIGluc3RhbmNlLm9wZW5DaGFuZ2VUaW1lb3V0LnN0YXJ0KGNsb3NlRGVsYXksICgpID0+IHtcbiAgICAgICAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy50cmlnZ2VySG92ZXIsIGV2ZW50KSk7XG4gICAgICAgICAgdHJlZT8uZXZlbnRzLmVtaXQoJ2Zsb2F0aW5nLmNsb3NlZCcsIGV2ZW50KTtcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2UgaWYgKHJ1bkVsc2VCcmFuY2gpIHtcbiAgICAgICAgaW5zdGFuY2Uub3BlbkNoYW5nZVRpbWVvdXQuY2xlYXIoKTtcbiAgICAgICAgc3RvcmUuc2V0T3BlbihmYWxzZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMudHJpZ2dlckhvdmVyLCBldmVudCkpO1xuICAgICAgICB0cmVlPy5ldmVudHMuZW1pdCgnZmxvYXRpbmcuY2xvc2VkJywgZXZlbnQpO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCB0cmlnZ2VyID0gdHJpZ2dlckVsZW1lbnRSZWYuY3VycmVudCA/PyAoaXNBY3RpdmVUcmlnZ2VyID8gc3RvcmUuc2VsZWN0KCdkb21SZWZlcmVuY2VFbGVtZW50JykgOiBudWxsKTtcbiAgICBpZiAoIWlzRWxlbWVudCh0cmlnZ2VyKSkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgZnVuY3Rpb24gb25Nb3VzZUVudGVyKGV2ZW50KSB7XG4gICAgICBpbnN0YW5jZS5vcGVuQ2hhbmdlVGltZW91dC5jbGVhcigpO1xuICAgICAgaW5zdGFuY2UuYmxvY2tNb3VzZU1vdmUgPSBmYWxzZTtcbiAgICAgIGlmIChtb3VzZU9ubHkgJiYgIWlzTW91c2VMaWtlUG9pbnRlclR5cGUoaW5zdGFuY2UucG9pbnRlclR5cGUpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gT25seSByZXN0IGRlbGF5IGlzIHNldDsgdGhlcmUncyBubyBmYWxsYmFjayBkZWxheS5cbiAgICAgIC8vIFRoaXMgd2lsbCBiZSBoYW5kbGVkIGJ5IGBvbk1vdXNlTW92ZWAuXG4gICAgICBjb25zdCByZXN0TXNWYWx1ZSA9IGdldFJlc3RNcyhyZXN0TXNSZWYuY3VycmVudCk7XG4gICAgICBjb25zdCBvcGVuRGVsYXkgPSBnZXREZWxheShkZWxheVJlZi5jdXJyZW50LCAnb3BlbicsIGluc3RhbmNlLnBvaW50ZXJUeXBlKTtcbiAgICAgIGNvbnN0IGV2ZW50VGFyZ2V0ID0gZ2V0VGFyZ2V0KGV2ZW50KTtcbiAgICAgIGNvbnN0IGN1cnJlbnRUYXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0ID8/IG51bGw7XG4gICAgICBjb25zdCBjdXJyZW50RG9tUmVmZXJlbmNlID0gc3RvcmUuc2VsZWN0KCdkb21SZWZlcmVuY2VFbGVtZW50Jyk7XG4gICAgICBsZXQgdHJpZ2dlck5vZGUgPSBjdXJyZW50VGFyZ2V0O1xuXG4gICAgICAvLyBXcmFwcGVyL2RlbGVnYXRlZCBtb2RlOiByZXNvbHZlIHRoZSBhY3R1YWwgdHJpZ2dlciBmcm9tIHRoZSBldmVudCB0YXJnZXQuXG4gICAgICBpZiAoaXNFbGVtZW50KGV2ZW50VGFyZ2V0KSAmJiAhc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuaGFzRWxlbWVudChldmVudFRhcmdldCkpIHtcbiAgICAgICAgZm9yIChjb25zdCB0cmlnZ2VyRWxlbWVudCBvZiBzdG9yZS5jb250ZXh0LnRyaWdnZXJFbGVtZW50cy5lbGVtZW50cygpKSB7XG4gICAgICAgICAgaWYgKGNvbnRhaW5zKHRyaWdnZXJFbGVtZW50LCBldmVudFRhcmdldCkpIHtcbiAgICAgICAgICAgIHRyaWdnZXJOb2RlID0gdHJpZ2dlckVsZW1lbnQ7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gV3JhcHBlci9kZWxlZ2F0ZWQgbW9kZSBmYWxsYmFjazogaWYgdGhlIHdyYXBwZXIgY29udGFpbnMgdGhlIGFjdGl2ZSB0cmlnZ2VyLFxuICAgICAgLy8gdHJlYXQgdGhpcyBhcyByZS1lbnRlcmluZyB0aGF0IGFjdGl2ZSB0cmlnZ2VyLlxuICAgICAgaWYgKGlzRWxlbWVudChjdXJyZW50VGFyZ2V0KSAmJiBpc0VsZW1lbnQoY3VycmVudERvbVJlZmVyZW5jZSkgJiYgIXN0b3JlLmNvbnRleHQudHJpZ2dlckVsZW1lbnRzLmhhc0VsZW1lbnQoY3VycmVudFRhcmdldCkgJiYgY29udGFpbnMoY3VycmVudFRhcmdldCwgY3VycmVudERvbVJlZmVyZW5jZSkpIHtcbiAgICAgICAgdHJpZ2dlck5vZGUgPSBjdXJyZW50RG9tUmVmZXJlbmNlO1xuICAgICAgfVxuICAgICAgY29uc3QgaXNPdmVySW5hY3RpdmUgPSB0cmlnZ2VyTm9kZSA9PSBudWxsID8gZmFsc2UgOiBpc092ZXJJbmFjdGl2ZVRyaWdnZXIoY3VycmVudERvbVJlZmVyZW5jZSwgdHJpZ2dlck5vZGUsIGV2ZW50VGFyZ2V0KTtcbiAgICAgIGNvbnN0IGlzT3BlbiA9IHN0b3JlLnNlbGVjdCgnb3BlbicpO1xuICAgICAgY29uc3QgaXNJbkNsb3NpbmdUcmFuc2l0aW9uID0gaXNDbG9zaW5nUmVmLmN1cnJlbnQ/LigpID8/IHN0b3JlLnNlbGVjdCgndHJhbnNpdGlvblN0YXR1cycpID09PSAnZW5kaW5nJztcbiAgICAgIGNvbnN0IGlzSG92ZXJDbG9zZVRyYW5zaXRpb24gPSAhaXNPcGVuICYmIGlzSW5DbG9zaW5nVHJhbnNpdGlvbiAmJiBpc0hvdmVyQ2xvc2VBY3RpdmVSZWYuY3VycmVudDtcbiAgICAgIGNvbnN0IGlzUmVlbnRlcmluZ1NhbWVUcmlnZ2VyRHVyaW5nQ2xvc2VUcmFuc2l0aW9uID0gIWlzT3ZlckluYWN0aXZlICYmIGlzRWxlbWVudCh0cmlnZ2VyTm9kZSkgJiYgaXNFbGVtZW50KGN1cnJlbnREb21SZWZlcmVuY2UpICYmIGNvbnRhaW5zKGN1cnJlbnREb21SZWZlcmVuY2UsIHRyaWdnZXJOb2RlKSAmJiBpc0hvdmVyQ2xvc2VUcmFuc2l0aW9uO1xuICAgICAgY29uc3QgaXNSZXN0T25seURlbGF5ID0gcmVzdE1zVmFsdWUgPiAwICYmICFvcGVuRGVsYXk7XG4gICAgICBjb25zdCBzaG91bGRPcGVuSW1tZWRpYXRlbHkgPSBpc092ZXJJbmFjdGl2ZSAmJiAoaXNPcGVuIHx8IGlzSG92ZXJDbG9zZVRyYW5zaXRpb24pIHx8IGlzUmVlbnRlcmluZ1NhbWVUcmlnZ2VyRHVyaW5nQ2xvc2VUcmFuc2l0aW9uO1xuICAgICAgY29uc3Qgc2hvdWxkT3BlbiA9ICFpc09wZW4gfHwgaXNPdmVySW5hY3RpdmU7XG5cbiAgICAgIC8vIE9wZW4gaW1tZWRpYXRlbHkgd2hlbiBtb3ZpbmcgYmV0d2VlbiB0cmlnZ2VycyB3aGlsZSBvcGVuLCBvciBkdXJpbmdcbiAgICAgIC8vIGEgaG92ZXItZHJpdmVuIGNsb3NlIHRyYW5zaXRpb24gKGluY2x1ZGluZyBzYW1lLXRyaWdnZXIgcmUtZW50cnkpLlxuICAgICAgaWYgKHNob3VsZE9wZW5JbW1lZGlhdGVseSkge1xuICAgICAgICBpZiAoY2hlY2tTaG91bGRPcGVuKCkpIHtcbiAgICAgICAgICBzdG9yZS5zZXRPcGVuKHRydWUsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLnRyaWdnZXJIb3ZlciwgZXZlbnQsIHRyaWdnZXJOb2RlKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGlzUmVzdE9ubHlEZWxheSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAob3BlbkRlbGF5KSB7XG4gICAgICAgIGluc3RhbmNlLm9wZW5DaGFuZ2VUaW1lb3V0LnN0YXJ0KG9wZW5EZWxheSwgKCkgPT4ge1xuICAgICAgICAgIGlmIChzaG91bGRPcGVuICYmIGNoZWNrU2hvdWxkT3BlbigpKSB7XG4gICAgICAgICAgICBzdG9yZS5zZXRPcGVuKHRydWUsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLnRyaWdnZXJIb3ZlciwgZXZlbnQsIHRyaWdnZXJOb2RlKSk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0gZWxzZSBpZiAoc2hvdWxkT3Blbikge1xuICAgICAgICBpZiAoY2hlY2tTaG91bGRPcGVuKCkpIHtcbiAgICAgICAgICBzdG9yZS5zZXRPcGVuKHRydWUsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLnRyaWdnZXJIb3ZlciwgZXZlbnQsIHRyaWdnZXJOb2RlKSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gb25Nb3VzZUxlYXZlKGV2ZW50KSB7XG4gICAgICBpZiAoaXNDbGlja0xpa2VPcGVuRXZlbnQoKSkge1xuICAgICAgICBjbGVhclBvaW50ZXJFdmVudHMoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY2xlYW51cE1vdXNlTW92ZUhhbmRsZXIoKTtcbiAgICAgIGNvbnN0IGRvbVJlZmVyZW5jZUVsZW1lbnQgPSBzdG9yZS5zZWxlY3QoJ2RvbVJlZmVyZW5jZUVsZW1lbnQnKTtcbiAgICAgIGNvbnN0IGRvYyA9IG93bmVyRG9jdW1lbnQoZG9tUmVmZXJlbmNlRWxlbWVudCk7XG4gICAgICBpbnN0YW5jZS5yZXN0VGltZW91dC5jbGVhcigpO1xuICAgICAgaW5zdGFuY2UucmVzdFRpbWVvdXRQZW5kaW5nID0gZmFsc2U7XG4gICAgICBjb25zdCBoYW5kbGVDbG9zZUNvbnRleHRCYXNlID0gZGF0YVJlZi5jdXJyZW50LmZsb2F0aW5nQ29udGV4dCA/PyBnZXRIYW5kbGVDbG9zZUNvbnRleHQ/LigpO1xuICAgICAgaWYgKGlzSW5zaWRlRW5hYmxlZFRyaWdnZXIoZXZlbnQucmVsYXRlZFRhcmdldCwgc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChoYW5kbGVDbG9zZVJlZi5jdXJyZW50ICYmIGhhbmRsZUNsb3NlQ29udGV4dEJhc2UpIHtcbiAgICAgICAgaWYgKCFzdG9yZS5zZWxlY3QoJ29wZW4nKSkge1xuICAgICAgICAgIGluc3RhbmNlLm9wZW5DaGFuZ2VUaW1lb3V0LmNsZWFyKCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY3VycmVudFRyaWdnZXIgPSB0cmlnZ2VyRWxlbWVudFJlZi5jdXJyZW50O1xuICAgICAgICBpbnN0YW5jZS5oYW5kbGVyID0gaGFuZGxlQ2xvc2VSZWYuY3VycmVudCh7XG4gICAgICAgICAgLi4uaGFuZGxlQ2xvc2VDb250ZXh0QmFzZSxcbiAgICAgICAgICB0cmVlLFxuICAgICAgICAgIHg6IGV2ZW50LmNsaWVudFgsXG4gICAgICAgICAgeTogZXZlbnQuY2xpZW50WSxcbiAgICAgICAgICBvbkNsb3NlKCkge1xuICAgICAgICAgICAgY2xlYXJQb2ludGVyRXZlbnRzKCk7XG4gICAgICAgICAgICBjbGVhbnVwTW91c2VNb3ZlSGFuZGxlcigpO1xuICAgICAgICAgICAgaWYgKGVuYWJsZWRSZWYuY3VycmVudCAmJiAhaXNDbGlja0xpa2VPcGVuRXZlbnQoKSAmJiBjdXJyZW50VHJpZ2dlciA9PT0gc3RvcmUuc2VsZWN0KCdkb21SZWZlcmVuY2VFbGVtZW50JykpIHtcbiAgICAgICAgICAgICAgY2xvc2VXaXRoRGVsYXkoZXZlbnQsIHRydWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGRvYy5hZGRFdmVudExpc3RlbmVyKCdtb3VzZW1vdmUnLCBpbnN0YW5jZS5oYW5kbGVyKTtcbiAgICAgICAgaW5zdGFuY2UuaGFuZGxlcihldmVudCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHNob3VsZENsb3NlID0gaW5zdGFuY2UucG9pbnRlclR5cGUgPT09ICd0b3VjaCcgPyAhY29udGFpbnMoc3RvcmUuc2VsZWN0KCdmbG9hdGluZ0VsZW1lbnQnKSwgZXZlbnQucmVsYXRlZFRhcmdldCkgOiB0cnVlO1xuICAgICAgaWYgKHNob3VsZENsb3NlKSB7XG4gICAgICAgIGNsb3NlV2l0aERlbGF5KGV2ZW50KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBCYWNrdXAgY2FuY2VsbGF0aW9uIGZvciBDaHJvbWUncyBkcm9wcGVkIGBtb3VzZWxlYXZlYCDigJQgc2VlIGBndWFyZFN0YWxlT3BlbmAuXG4gICAgZnVuY3Rpb24gb25Nb3VzZU91dChldmVudCkge1xuICAgICAgaWYgKGNvbnRhaW5zKHRyaWdnZXIsIGV2ZW50LnJlbGF0ZWRUYXJnZXQpKSB7XG4gICAgICAgIHJldHVybjsgLy8gbW92ZWQgd2l0aGluIHRoZSB0cmlnZ2VyJ3Mgb3duIHN1YnRyZWVcbiAgICAgIH1cbiAgICAgIGluc3RhbmNlLm9wZW5DaGFuZ2VUaW1lb3V0LmNsZWFyKCk7XG4gICAgICBpbnN0YW5jZS5yZXN0VGltZW91dC5jbGVhcigpO1xuICAgICAgaW5zdGFuY2UucmVzdFRpbWVvdXRQZW5kaW5nID0gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IHN0YWxlT3Blbkd1YXJkID0gZ3VhcmRTdGFsZU9wZW4gPyBhZGRFdmVudExpc3RlbmVyKHRyaWdnZXIsICdtb3VzZW91dCcsIG9uTW91c2VPdXQpIDogdW5kZWZpbmVkO1xuICAgIGlmIChtb3ZlKSB7XG4gICAgICByZXR1cm4gbWVyZ2VDbGVhbnVwcyhhZGRFdmVudExpc3RlbmVyKHRyaWdnZXIsICdtb3VzZW1vdmUnLCBvbk1vdXNlRW50ZXIsIHtcbiAgICAgICAgb25jZTogdHJ1ZVxuICAgICAgfSksIGFkZEV2ZW50TGlzdGVuZXIodHJpZ2dlciwgJ21vdXNlZW50ZXInLCBvbk1vdXNlRW50ZXIpLCBhZGRFdmVudExpc3RlbmVyKHRyaWdnZXIsICdtb3VzZWxlYXZlJywgb25Nb3VzZUxlYXZlKSwgc3RhbGVPcGVuR3VhcmQpO1xuICAgIH1cbiAgICByZXR1cm4gbWVyZ2VDbGVhbnVwcyhhZGRFdmVudExpc3RlbmVyKHRyaWdnZXIsICdtb3VzZWVudGVyJywgb25Nb3VzZUVudGVyKSwgYWRkRXZlbnRMaXN0ZW5lcih0cmlnZ2VyLCAnbW91c2VsZWF2ZScsIG9uTW91c2VMZWF2ZSksIHN0YWxlT3Blbkd1YXJkKTtcbiAgfSwgW2NsZWFudXBNb3VzZU1vdmVIYW5kbGVyLCBjbGVhclBvaW50ZXJFdmVudHMsIGRhdGFSZWYsIGRlbGF5UmVmLCBzdG9yZSwgZW5hYmxlZCwgaGFuZGxlQ2xvc2VSZWYsIGluc3RhbmNlLCBpc0FjdGl2ZVRyaWdnZXIsIGlzT3ZlckluYWN0aXZlVHJpZ2dlciwgaXNDbGlja0xpa2VPcGVuRXZlbnQsIG1vdXNlT25seSwgbW92ZSwgcmVzdE1zUmVmLCB0cmlnZ2VyRWxlbWVudFJlZiwgdHJlZSwgZW5hYmxlZFJlZiwgZ2V0SGFuZGxlQ2xvc2VDb250ZXh0LCBpc0Nsb3NpbmdSZWYsIGNoZWNrU2hvdWxkT3BlbiwgZ3VhcmRTdGFsZU9wZW5dKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgZnVuY3Rpb24gc2V0UG9pbnRlclJlZihldmVudCkge1xuICAgICAgaW5zdGFuY2UucG9pbnRlclR5cGUgPSBldmVudC5wb2ludGVyVHlwZTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIG9uUG9pbnRlckRvd246IHNldFBvaW50ZXJSZWYsXG4gICAgICBvblBvaW50ZXJFbnRlcjogc2V0UG9pbnRlclJlZixcbiAgICAgIG9uTW91c2VNb3ZlKGV2ZW50KSB7XG4gICAgICAgIGNvbnN0IHtcbiAgICAgICAgICBuYXRpdmVFdmVudFxuICAgICAgICB9ID0gZXZlbnQ7XG4gICAgICAgIGNvbnN0IHRyaWdnZXIgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuICAgICAgICBjb25zdCBjdXJyZW50RG9tUmVmZXJlbmNlID0gc3RvcmUuc2VsZWN0KCdkb21SZWZlcmVuY2VFbGVtZW50Jyk7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRPcGVuID0gc3RvcmUuc2VsZWN0KCdvcGVuJyk7XG4gICAgICAgIGNvbnN0IGlzT3ZlckluYWN0aXZlID0gaXNPdmVySW5hY3RpdmVUcmlnZ2VyKGN1cnJlbnREb21SZWZlcmVuY2UsIHRyaWdnZXIsIGV2ZW50LnRhcmdldCk7XG4gICAgICAgIGlmIChtb3VzZU9ubHkgJiYgIWlzTW91c2VMaWtlUG9pbnRlclR5cGUoaW5zdGFuY2UucG9pbnRlclR5cGUpKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjdXJyZW50T3BlbiAmJiBpc092ZXJJbmFjdGl2ZSAmJiBpbnN0YW5jZS5oYW5kbGVDbG9zZU9wdGlvbnM/LmJsb2NrUG9pbnRlckV2ZW50cykge1xuICAgICAgICAgIGNvbnN0IGZsb2F0aW5nRWxlbWVudCA9IHN0b3JlLnNlbGVjdCgnZmxvYXRpbmdFbGVtZW50Jyk7XG4gICAgICAgICAgaWYgKGZsb2F0aW5nRWxlbWVudCkge1xuICAgICAgICAgICAgY29uc3Qgc2NvcGVFbGVtZW50ID0gaW5zdGFuY2UuaGFuZGxlQ2xvc2VPcHRpb25zPy5nZXRTY29wZT8uKCkgPz8gdHJpZ2dlci5vd25lckRvY3VtZW50LmJvZHk7XG4gICAgICAgICAgICBhcHBseVNhZmVQb2x5Z29uUG9pbnRlckV2ZW50c011dGF0aW9uKGluc3RhbmNlLCB7XG4gICAgICAgICAgICAgIHNjb3BlRWxlbWVudCxcbiAgICAgICAgICAgICAgcmVmZXJlbmNlRWxlbWVudDogdHJpZ2dlcixcbiAgICAgICAgICAgICAgZmxvYXRpbmdFbGVtZW50XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcmVzdE1zVmFsdWUgPSBnZXRSZXN0TXMocmVzdE1zUmVmLmN1cnJlbnQpO1xuICAgICAgICBpZiAoY3VycmVudE9wZW4gJiYgIWlzT3ZlckluYWN0aXZlIHx8IHJlc3RNc1ZhbHVlID09PSAwKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmICghaXNPdmVySW5hY3RpdmUgJiYgaW5zdGFuY2UucmVzdFRpbWVvdXRQZW5kaW5nICYmIGV2ZW50Lm1vdmVtZW50WCAqKiAyICsgZXZlbnQubW92ZW1lbnRZICoqIDIgPCAyKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGluc3RhbmNlLnJlc3RUaW1lb3V0LmNsZWFyKCk7XG4gICAgICAgIGZ1bmN0aW9uIGhhbmRsZU1vdXNlTW92ZSgpIHtcbiAgICAgICAgICBpbnN0YW5jZS5yZXN0VGltZW91dFBlbmRpbmcgPSBmYWxzZTtcblxuICAgICAgICAgIC8vIEEgZGVsYXllZCBob3ZlciBvcGVuIHNob3VsZCBub3Qgb3ZlcnJpZGUgYSBjbGljay1saWtlIG9wZW4gdGhhdCBoYXBwZW5lZFxuICAgICAgICAgIC8vIHdoaWxlIHRoZSBob3ZlciBkZWxheSB3YXMgcGVuZGluZy5cbiAgICAgICAgICBpZiAoaXNDbGlja0xpa2VPcGVuRXZlbnQoKSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBsYXRlc3RPcGVuID0gc3RvcmUuc2VsZWN0KCdvcGVuJyk7XG4gICAgICAgICAgaWYgKCFpbnN0YW5jZS5ibG9ja01vdXNlTW92ZSAmJiAoIWxhdGVzdE9wZW4gfHwgaXNPdmVySW5hY3RpdmUpICYmIGNoZWNrU2hvdWxkT3BlbigpKSB7XG4gICAgICAgICAgICBzdG9yZS5zZXRPcGVuKHRydWUsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLnRyaWdnZXJIb3ZlciwgbmF0aXZlRXZlbnQsIHRyaWdnZXIpKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGluc3RhbmNlLnBvaW50ZXJUeXBlID09PSAndG91Y2gnKSB7XG4gICAgICAgICAgUmVhY3RET00uZmx1c2hTeW5jKCgpID0+IHtcbiAgICAgICAgICAgIGhhbmRsZU1vdXNlTW92ZSgpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKGlzT3ZlckluYWN0aXZlICYmIGN1cnJlbnRPcGVuKSB7XG4gICAgICAgICAgaGFuZGxlTW91c2VNb3ZlKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgaW5zdGFuY2UucmVzdFRpbWVvdXRQZW5kaW5nID0gdHJ1ZTtcbiAgICAgICAgICBpbnN0YW5jZS5yZXN0VGltZW91dC5zdGFydChyZXN0TXNWYWx1ZSwgaGFuZGxlTW91c2VNb3ZlKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gIH0sIFtlbmFibGVkLCBpbnN0YW5jZSwgaXNDbGlja0xpa2VPcGVuRXZlbnQsIGlzT3ZlckluYWN0aXZlVHJpZ2dlciwgbW91c2VPbmx5LCBzdG9yZSwgcmVzdE1zUmVmLCBjaGVja1Nob3VsZE9wZW5dKTtcbn0iLCJpbXBvcnQgeyBpc0VsZW1lbnQgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IFRpbWVvdXQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VUaW1lb3V0JztcbmltcG9ydCB7IGNvbnRhaW5zLCBnZXRUYXJnZXQgfSBmcm9tIFwiLi91dGlscy9lbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgZ2V0Tm9kZUNoaWxkcmVuIH0gZnJvbSBcIi4vdXRpbHMvbm9kZXMubWpzXCI7XG5cbi8qIGVzbGludC1kaXNhYmxlIG5vLW5lc3RlZC10ZXJuYXJ5ICovXG5cbmNvbnN0IENVUlNPUl9TUEVFRF9USFJFU0hPTEQgPSAwLjE7XG5jb25zdCBDVVJTT1JfU1BFRURfVEhSRVNIT0xEX1NRVUFSRUQgPSBDVVJTT1JfU1BFRURfVEhSRVNIT0xEICogQ1VSU09SX1NQRUVEX1RIUkVTSE9MRDtcbmNvbnN0IFBPTFlHT05fQlVGRkVSID0gMC41O1xuZnVuY3Rpb24gaGFzSW50ZXJzZWN0aW5nRWRnZShwb2ludFgsIHBvaW50WSwgeGksIHlpLCB4aiwgeWopIHtcbiAgcmV0dXJuIHlpID49IHBvaW50WSAhPT0geWogPj0gcG9pbnRZICYmIHBvaW50WCA8PSAoeGogLSB4aSkgKiAocG9pbnRZIC0geWkpIC8gKHlqIC0geWkpICsgeGk7XG59XG5mdW5jdGlvbiBpc1BvaW50SW5RdWFkcmlsYXRlcmFsKHBvaW50WCwgcG9pbnRZLCB4MSwgeTEsIHgyLCB5MiwgeDMsIHkzLCB4NCwgeTQpIHtcbiAgbGV0IGlzSW5zaWRlVmFsdWUgPSBmYWxzZTtcbiAgaWYgKGhhc0ludGVyc2VjdGluZ0VkZ2UocG9pbnRYLCBwb2ludFksIHgxLCB5MSwgeDIsIHkyKSkge1xuICAgIGlzSW5zaWRlVmFsdWUgPSAhaXNJbnNpZGVWYWx1ZTtcbiAgfVxuICBpZiAoaGFzSW50ZXJzZWN0aW5nRWRnZShwb2ludFgsIHBvaW50WSwgeDIsIHkyLCB4MywgeTMpKSB7XG4gICAgaXNJbnNpZGVWYWx1ZSA9ICFpc0luc2lkZVZhbHVlO1xuICB9XG4gIGlmIChoYXNJbnRlcnNlY3RpbmdFZGdlKHBvaW50WCwgcG9pbnRZLCB4MywgeTMsIHg0LCB5NCkpIHtcbiAgICBpc0luc2lkZVZhbHVlID0gIWlzSW5zaWRlVmFsdWU7XG4gIH1cbiAgaWYgKGhhc0ludGVyc2VjdGluZ0VkZ2UocG9pbnRYLCBwb2ludFksIHg0LCB5NCwgeDEsIHkxKSkge1xuICAgIGlzSW5zaWRlVmFsdWUgPSAhaXNJbnNpZGVWYWx1ZTtcbiAgfVxuICByZXR1cm4gaXNJbnNpZGVWYWx1ZTtcbn1cbmZ1bmN0aW9uIGlzSW5zaWRlUmVjdChwb2ludFgsIHBvaW50WSwgcmVjdCkge1xuICByZXR1cm4gcG9pbnRYID49IHJlY3QueCAmJiBwb2ludFggPD0gcmVjdC54ICsgcmVjdC53aWR0aCAmJiBwb2ludFkgPj0gcmVjdC55ICYmIHBvaW50WSA8PSByZWN0LnkgKyByZWN0LmhlaWdodDtcbn1cbmZ1bmN0aW9uIGlzSW5zaWRlQXhpc0FsaWduZWRSZWN0KHBvaW50WCwgcG9pbnRZLCB4MSwgeTEsIHgyLCB5Mikge1xuICBjb25zdCBtaW5YID0gTWF0aC5taW4oeDEsIHgyKTtcbiAgY29uc3QgbWF4WCA9IE1hdGgubWF4KHgxLCB4Mik7XG4gIGNvbnN0IG1pblkgPSBNYXRoLm1pbih5MSwgeTIpO1xuICBjb25zdCBtYXhZID0gTWF0aC5tYXgoeTEsIHkyKTtcbiAgcmV0dXJuIHBvaW50WCA+PSBtaW5YICYmIHBvaW50WCA8PSBtYXhYICYmIHBvaW50WSA+PSBtaW5ZICYmIHBvaW50WSA8PSBtYXhZO1xufVxuLyoqXG4gKiBHZW5lcmF0ZXMgYSBzYWZlIHBvbHlnb24gYXJlYSB0aGF0IHRoZSB1c2VyIGNhbiB0cmF2ZXJzZSB3aXRob3V0IGNsb3NpbmcgdGhlXG4gKiBmbG9hdGluZyBlbGVtZW50IG9uY2UgbGVhdmluZyB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlSG92ZXIjc2FmZXBvbHlnb25cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNhZmVQb2x5Z29uKG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgYmxvY2tQb2ludGVyRXZlbnRzID0gZmFsc2VcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IHRpbWVvdXQgPSBuZXcgVGltZW91dCgpO1xuICBjb25zdCBmbiA9ICh7XG4gICAgeCxcbiAgICB5LFxuICAgIHBsYWNlbWVudCxcbiAgICBlbGVtZW50cyxcbiAgICBvbkNsb3NlLFxuICAgIG5vZGVJZCxcbiAgICB0cmVlXG4gIH0pID0+IHtcbiAgICBjb25zdCBzaWRlID0gcGxhY2VtZW50Py5zcGxpdCgnLScpWzBdO1xuICAgIGxldCBoYXNMYW5kZWQgPSBmYWxzZTtcbiAgICBsZXQgbGFzdFggPSBudWxsO1xuICAgIGxldCBsYXN0WSA9IG51bGw7XG4gICAgbGV0IGxhc3RDdXJzb3JUaW1lID0gdHlwZW9mIHBlcmZvcm1hbmNlICE9PSAndW5kZWZpbmVkJyA/IHBlcmZvcm1hbmNlLm5vdygpIDogMDtcbiAgICBmdW5jdGlvbiBpc0N1cnNvck1vdmluZ1Nsb3dseShuZXh0WCwgbmV4dFkpIHtcbiAgICAgIGNvbnN0IGN1cnJlbnRUaW1lID0gcGVyZm9ybWFuY2Uubm93KCk7XG4gICAgICBjb25zdCBlbGFwc2VkVGltZSA9IGN1cnJlbnRUaW1lIC0gbGFzdEN1cnNvclRpbWU7XG4gICAgICBpZiAobGFzdFggPT09IG51bGwgfHwgbGFzdFkgPT09IG51bGwgfHwgZWxhcHNlZFRpbWUgPT09IDApIHtcbiAgICAgICAgbGFzdFggPSBuZXh0WDtcbiAgICAgICAgbGFzdFkgPSBuZXh0WTtcbiAgICAgICAgbGFzdEN1cnNvclRpbWUgPSBjdXJyZW50VGltZTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgY29uc3QgZGVsdGFYID0gbmV4dFggLSBsYXN0WDtcbiAgICAgIGNvbnN0IGRlbHRhWSA9IG5leHRZIC0gbGFzdFk7XG4gICAgICBjb25zdCBkaXN0YW5jZVNxdWFyZWQgPSBkZWx0YVggKiBkZWx0YVggKyBkZWx0YVkgKiBkZWx0YVk7XG4gICAgICBjb25zdCB0aHJlc2hvbGRTcXVhcmVkID0gZWxhcHNlZFRpbWUgKiBlbGFwc2VkVGltZSAqIENVUlNPUl9TUEVFRF9USFJFU0hPTERfU1FVQVJFRDtcbiAgICAgIGxhc3RYID0gbmV4dFg7XG4gICAgICBsYXN0WSA9IG5leHRZO1xuICAgICAgbGFzdEN1cnNvclRpbWUgPSBjdXJyZW50VGltZTtcbiAgICAgIHJldHVybiBkaXN0YW5jZVNxdWFyZWQgPCB0aHJlc2hvbGRTcXVhcmVkO1xuICAgIH1cbiAgICBmdW5jdGlvbiBjbG9zZSgpIHtcbiAgICAgIHRpbWVvdXQuY2xlYXIoKTtcbiAgICAgIG9uQ2xvc2UoKTtcbiAgICB9XG4gICAgcmV0dXJuIGZ1bmN0aW9uIG9uTW91c2VNb3ZlKGV2ZW50KSB7XG4gICAgICB0aW1lb3V0LmNsZWFyKCk7XG4gICAgICBjb25zdCBkb21SZWZlcmVuY2UgPSBlbGVtZW50cy5kb21SZWZlcmVuY2U7XG4gICAgICBjb25zdCBmbG9hdGluZyA9IGVsZW1lbnRzLmZsb2F0aW5nO1xuICAgICAgaWYgKCFkb21SZWZlcmVuY2UgfHwgIWZsb2F0aW5nIHx8IHNpZGUgPT0gbnVsbCB8fCB4ID09IG51bGwgfHwgeSA9PSBudWxsKSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgICBjb25zdCB7XG4gICAgICAgIGNsaWVudFgsXG4gICAgICAgIGNsaWVudFlcbiAgICAgIH0gPSBldmVudDtcbiAgICAgIGNvbnN0IHRhcmdldCA9IGdldFRhcmdldChldmVudCk7XG4gICAgICBjb25zdCBpc0xlYXZlID0gZXZlbnQudHlwZSA9PT0gJ21vdXNlbGVhdmUnO1xuICAgICAgY29uc3QgaXNPdmVyRmxvYXRpbmdFbCA9IGNvbnRhaW5zKGZsb2F0aW5nLCB0YXJnZXQpO1xuICAgICAgY29uc3QgaXNPdmVyUmVmZXJlbmNlRWwgPSBjb250YWlucyhkb21SZWZlcmVuY2UsIHRhcmdldCk7XG4gICAgICBpZiAoaXNPdmVyRmxvYXRpbmdFbCkge1xuICAgICAgICBoYXNMYW5kZWQgPSB0cnVlO1xuICAgICAgICBpZiAoIWlzTGVhdmUpIHtcbiAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoaXNPdmVyUmVmZXJlbmNlRWwpIHtcbiAgICAgICAgaGFzTGFuZGVkID0gZmFsc2U7XG4gICAgICAgIGlmICghaXNMZWF2ZSkge1xuICAgICAgICAgIGhhc0xhbmRlZCA9IHRydWU7XG4gICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICAvLyBQcmV2ZW50IG92ZXJsYXBwaW5nIGZsb2F0aW5nIGVsZW1lbnQgZnJvbSBiZWluZyBzdHVjayBpbiBhbiBvcGVuLWNsb3NlXG4gICAgICAvLyBsb29wOiBodHRwczovL2dpdGh1Yi5jb20vZmxvYXRpbmctdWkvZmxvYXRpbmctdWkvaXNzdWVzLzE5MTBcbiAgICAgIGlmIChpc0xlYXZlICYmIGlzRWxlbWVudChldmVudC5yZWxhdGVkVGFyZ2V0KSAmJiBjb250YWlucyhmbG9hdGluZywgZXZlbnQucmVsYXRlZFRhcmdldCkpIHtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgIH1cbiAgICAgIGZ1bmN0aW9uIGhhc09wZW5DaGlsZE5vZGUoKSB7XG4gICAgICAgIHJldHVybiBCb29sZWFuKHRyZWUgJiYgZ2V0Tm9kZUNoaWxkcmVuKHRyZWUubm9kZXNSZWYuY3VycmVudCwgbm9kZUlkKS5sZW5ndGggPiAwKTtcbiAgICAgIH1cbiAgICAgIGZ1bmN0aW9uIGNsb3NlSWZOb09wZW5DaGlsZCgpIHtcbiAgICAgICAgaWYgKCFoYXNPcGVuQ2hpbGROb2RlKCkpIHtcbiAgICAgICAgICBjbG9zZSgpO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIElmIGFueSBuZXN0ZWQgY2hpbGQgaXMgb3BlbiwgYWJvcnQuXG4gICAgICBpZiAoaGFzT3BlbkNoaWxkTm9kZSgpKSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgICBjb25zdCByZWZSZWN0ID0gZG9tUmVmZXJlbmNlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgY29uc3QgcmVjdCA9IGZsb2F0aW5nLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgY29uc3QgY3Vyc29yTGVhdmVGcm9tUmlnaHQgPSB4ID4gcmVjdC5yaWdodCAtIHJlY3Qud2lkdGggLyAyO1xuICAgICAgY29uc3QgY3Vyc29yTGVhdmVGcm9tQm90dG9tID0geSA+IHJlY3QuYm90dG9tIC0gcmVjdC5oZWlnaHQgLyAyO1xuICAgICAgY29uc3QgaXNGbG9hdGluZ1dpZGVyID0gcmVjdC53aWR0aCA+IHJlZlJlY3Qud2lkdGg7XG4gICAgICBjb25zdCBpc0Zsb2F0aW5nVGFsbGVyID0gcmVjdC5oZWlnaHQgPiByZWZSZWN0LmhlaWdodDtcbiAgICAgIGNvbnN0IGxlZnQgPSAoaXNGbG9hdGluZ1dpZGVyID8gcmVmUmVjdCA6IHJlY3QpLmxlZnQ7XG4gICAgICBjb25zdCByaWdodCA9IChpc0Zsb2F0aW5nV2lkZXIgPyByZWZSZWN0IDogcmVjdCkucmlnaHQ7XG4gICAgICBjb25zdCB0b3AgPSAoaXNGbG9hdGluZ1RhbGxlciA/IHJlZlJlY3QgOiByZWN0KS50b3A7XG4gICAgICBjb25zdCBib3R0b20gPSAoaXNGbG9hdGluZ1RhbGxlciA/IHJlZlJlY3QgOiByZWN0KS5ib3R0b207XG5cbiAgICAgIC8vIElmIHRoZSBwb2ludGVyIGlzIGxlYXZpbmcgZnJvbSB0aGUgb3Bwb3NpdGUgc2lkZSwgdGhlIFwiYnVmZmVyXCIgbG9naWNcbiAgICAgIC8vIGNyZWF0ZXMgYSBwb2ludCB3aGVyZSB0aGUgZmxvYXRpbmcgZWxlbWVudCByZW1haW5zIG9wZW4sIGJ1dCBzaG91bGQgYmVcbiAgICAgIC8vIGlnbm9yZWQuXG4gICAgICAvLyBBIGNvbnN0YW50IG9mIDEgaGFuZGxlcyBmbG9hdGluZyBwb2ludCByb3VuZGluZyBlcnJvcnMuXG4gICAgICBpZiAoc2lkZSA9PT0gJ3RvcCcgJiYgeSA+PSByZWZSZWN0LmJvdHRvbSAtIDEgfHwgc2lkZSA9PT0gJ2JvdHRvbScgJiYgeSA8PSByZWZSZWN0LnRvcCArIDEgfHwgc2lkZSA9PT0gJ2xlZnQnICYmIHggPj0gcmVmUmVjdC5yaWdodCAtIDEgfHwgc2lkZSA9PT0gJ3JpZ2h0JyAmJiB4IDw9IHJlZlJlY3QubGVmdCArIDEpIHtcbiAgICAgICAgY2xvc2VJZk5vT3BlbkNoaWxkKCk7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICB9XG5cbiAgICAgIC8vIElnbm9yZSB3aGVuIHRoZSBjdXJzb3IgaXMgd2l0aGluIHRoZSByZWN0YW5ndWxhciB0cm91Z2ggYmV0d2VlbiB0aGVcbiAgICAgIC8vIHR3byBlbGVtZW50cy4gU2luY2UgdGhlIHRyaWFuZ2xlIGlzIGNyZWF0ZWQgZnJvbSB0aGUgY3Vyc29yIHBvaW50LFxuICAgICAgLy8gd2hpY2ggY2FuIHN0YXJ0IGJleW9uZCB0aGUgcmVmIGVsZW1lbnQncyBlZGdlLCB0cmF2ZXJzaW5nIGJhY2sgYW5kXG4gICAgICAvLyBmb3J0aCBmcm9tIHRoZSByZWYgdG8gdGhlIGZsb2F0aW5nIGVsZW1lbnQgY2FuIGNhdXNlIGl0IHRvIGNsb3NlLiBUaGlzXG4gICAgICAvLyBlbnN1cmVzIGl0IGFsd2F5cyByZW1haW5zIG9wZW4gaW4gdGhhdCBjYXNlLlxuICAgICAgbGV0IGlzSW5zaWRlVHJvdWdoUmVjdCA9IGZhbHNlO1xuICAgICAgc3dpdGNoIChzaWRlKSB7XG4gICAgICAgIGNhc2UgJ3RvcCc6XG4gICAgICAgICAgaXNJbnNpZGVUcm91Z2hSZWN0ID0gaXNJbnNpZGVBeGlzQWxpZ25lZFJlY3QoY2xpZW50WCwgY2xpZW50WSwgbGVmdCwgcmVmUmVjdC50b3AgKyAxLCByaWdodCwgcmVjdC5ib3R0b20gLSAxKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnYm90dG9tJzpcbiAgICAgICAgICBpc0luc2lkZVRyb3VnaFJlY3QgPSBpc0luc2lkZUF4aXNBbGlnbmVkUmVjdChjbGllbnRYLCBjbGllbnRZLCBsZWZ0LCByZWN0LnRvcCArIDEsIHJpZ2h0LCByZWZSZWN0LmJvdHRvbSAtIDEpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdsZWZ0JzpcbiAgICAgICAgICBpc0luc2lkZVRyb3VnaFJlY3QgPSBpc0luc2lkZUF4aXNBbGlnbmVkUmVjdChjbGllbnRYLCBjbGllbnRZLCByZWN0LnJpZ2h0IC0gMSwgYm90dG9tLCByZWZSZWN0LmxlZnQgKyAxLCB0b3ApO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdyaWdodCc6XG4gICAgICAgICAgaXNJbnNpZGVUcm91Z2hSZWN0ID0gaXNJbnNpZGVBeGlzQWxpZ25lZFJlY3QoY2xpZW50WCwgY2xpZW50WSwgcmVmUmVjdC5yaWdodCAtIDEsIGJvdHRvbSwgcmVjdC5sZWZ0ICsgMSwgdG9wKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgIH1cbiAgICAgIGlmIChpc0luc2lkZVRyb3VnaFJlY3QpIHtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgIH1cbiAgICAgIGlmIChoYXNMYW5kZWQgJiYgIWlzSW5zaWRlUmVjdChjbGllbnRYLCBjbGllbnRZLCByZWZSZWN0KSkge1xuICAgICAgICBjbG9zZUlmTm9PcGVuQ2hpbGQoKTtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgIH1cbiAgICAgIGlmICghaXNMZWF2ZSAmJiBpc0N1cnNvck1vdmluZ1Nsb3dseShjbGllbnRYLCBjbGllbnRZKSkge1xuICAgICAgICBjbG9zZUlmTm9PcGVuQ2hpbGQoKTtcbiAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgIH1cbiAgICAgIGxldCBpc0luc2lkZVBvbHlnb24gPSBmYWxzZTtcbiAgICAgIHN3aXRjaCAoc2lkZSkge1xuICAgICAgICBjYXNlICd0b3AnOlxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGNvbnN0IGN1cnNvclhPZmZzZXQgPSBpc0Zsb2F0aW5nV2lkZXIgPyBQT0xZR09OX0JVRkZFUiAvIDIgOiBQT0xZR09OX0JVRkZFUiAqIDQ7XG4gICAgICAgICAgICBjb25zdCBjdXJzb3JQb2ludE9uZVggPSBpc0Zsb2F0aW5nV2lkZXIgPyB4ICsgY3Vyc29yWE9mZnNldCA6IGN1cnNvckxlYXZlRnJvbVJpZ2h0ID8geCArIGN1cnNvclhPZmZzZXQgOiB4IC0gY3Vyc29yWE9mZnNldDtcbiAgICAgICAgICAgIGNvbnN0IGN1cnNvclBvaW50VHdvWCA9IGlzRmxvYXRpbmdXaWRlciA/IHggLSBjdXJzb3JYT2Zmc2V0IDogY3Vyc29yTGVhdmVGcm9tUmlnaHQgPyB4ICsgY3Vyc29yWE9mZnNldCA6IHggLSBjdXJzb3JYT2Zmc2V0O1xuICAgICAgICAgICAgY29uc3QgY3Vyc29yUG9pbnRZID0geSArIFBPTFlHT05fQlVGRkVSICsgMTtcbiAgICAgICAgICAgIGNvbnN0IGNvbW1vbllMZWZ0ID0gY3Vyc29yTGVhdmVGcm9tUmlnaHQgPyByZWN0LmJvdHRvbSAtIFBPTFlHT05fQlVGRkVSIDogaXNGbG9hdGluZ1dpZGVyID8gcmVjdC5ib3R0b20gLSBQT0xZR09OX0JVRkZFUiA6IHJlY3QudG9wO1xuICAgICAgICAgICAgY29uc3QgY29tbW9uWVJpZ2h0ID0gY3Vyc29yTGVhdmVGcm9tUmlnaHQgPyBpc0Zsb2F0aW5nV2lkZXIgPyByZWN0LmJvdHRvbSAtIFBPTFlHT05fQlVGRkVSIDogcmVjdC50b3AgOiByZWN0LmJvdHRvbSAtIFBPTFlHT05fQlVGRkVSO1xuICAgICAgICAgICAgaXNJbnNpZGVQb2x5Z29uID0gaXNQb2ludEluUXVhZHJpbGF0ZXJhbChjbGllbnRYLCBjbGllbnRZLCBjdXJzb3JQb2ludE9uZVgsIGN1cnNvclBvaW50WSwgY3Vyc29yUG9pbnRUd29YLCBjdXJzb3JQb2ludFksIHJlY3QubGVmdCwgY29tbW9uWUxlZnQsIHJlY3QucmlnaHQsIGNvbW1vbllSaWdodCk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgIGNhc2UgJ2JvdHRvbSc6XG4gICAgICAgICAge1xuICAgICAgICAgICAgY29uc3QgY3Vyc29yWE9mZnNldCA9IGlzRmxvYXRpbmdXaWRlciA/IFBPTFlHT05fQlVGRkVSIC8gMiA6IFBPTFlHT05fQlVGRkVSICogNDtcbiAgICAgICAgICAgIGNvbnN0IGN1cnNvclBvaW50T25lWCA9IGlzRmxvYXRpbmdXaWRlciA/IHggKyBjdXJzb3JYT2Zmc2V0IDogY3Vyc29yTGVhdmVGcm9tUmlnaHQgPyB4ICsgY3Vyc29yWE9mZnNldCA6IHggLSBjdXJzb3JYT2Zmc2V0O1xuICAgICAgICAgICAgY29uc3QgY3Vyc29yUG9pbnRUd29YID0gaXNGbG9hdGluZ1dpZGVyID8geCAtIGN1cnNvclhPZmZzZXQgOiBjdXJzb3JMZWF2ZUZyb21SaWdodCA/IHggKyBjdXJzb3JYT2Zmc2V0IDogeCAtIGN1cnNvclhPZmZzZXQ7XG4gICAgICAgICAgICBjb25zdCBjdXJzb3JQb2ludFkgPSB5IC0gUE9MWUdPTl9CVUZGRVI7XG4gICAgICAgICAgICBjb25zdCBjb21tb25ZTGVmdCA9IGN1cnNvckxlYXZlRnJvbVJpZ2h0ID8gcmVjdC50b3AgKyBQT0xZR09OX0JVRkZFUiA6IGlzRmxvYXRpbmdXaWRlciA/IHJlY3QudG9wICsgUE9MWUdPTl9CVUZGRVIgOiByZWN0LmJvdHRvbTtcbiAgICAgICAgICAgIGNvbnN0IGNvbW1vbllSaWdodCA9IGN1cnNvckxlYXZlRnJvbVJpZ2h0ID8gaXNGbG9hdGluZ1dpZGVyID8gcmVjdC50b3AgKyBQT0xZR09OX0JVRkZFUiA6IHJlY3QuYm90dG9tIDogcmVjdC50b3AgKyBQT0xZR09OX0JVRkZFUjtcbiAgICAgICAgICAgIGlzSW5zaWRlUG9seWdvbiA9IGlzUG9pbnRJblF1YWRyaWxhdGVyYWwoY2xpZW50WCwgY2xpZW50WSwgY3Vyc29yUG9pbnRPbmVYLCBjdXJzb3JQb2ludFksIGN1cnNvclBvaW50VHdvWCwgY3Vyc29yUG9pbnRZLCByZWN0LmxlZnQsIGNvbW1vbllMZWZ0LCByZWN0LnJpZ2h0LCBjb21tb25ZUmlnaHQpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICBjYXNlICdsZWZ0JzpcbiAgICAgICAgICB7XG4gICAgICAgICAgICBjb25zdCBjdXJzb3JZT2Zmc2V0ID0gaXNGbG9hdGluZ1RhbGxlciA/IFBPTFlHT05fQlVGRkVSIC8gMiA6IFBPTFlHT05fQlVGRkVSICogNDtcbiAgICAgICAgICAgIGNvbnN0IGN1cnNvclBvaW50T25lWSA9IGlzRmxvYXRpbmdUYWxsZXIgPyB5ICsgY3Vyc29yWU9mZnNldCA6IGN1cnNvckxlYXZlRnJvbUJvdHRvbSA/IHkgKyBjdXJzb3JZT2Zmc2V0IDogeSAtIGN1cnNvcllPZmZzZXQ7XG4gICAgICAgICAgICBjb25zdCBjdXJzb3JQb2ludFR3b1kgPSBpc0Zsb2F0aW5nVGFsbGVyID8geSAtIGN1cnNvcllPZmZzZXQgOiBjdXJzb3JMZWF2ZUZyb21Cb3R0b20gPyB5ICsgY3Vyc29yWU9mZnNldCA6IHkgLSBjdXJzb3JZT2Zmc2V0O1xuICAgICAgICAgICAgY29uc3QgY3Vyc29yUG9pbnRYID0geCArIFBPTFlHT05fQlVGRkVSICsgMTtcbiAgICAgICAgICAgIGNvbnN0IGNvbW1vblhUb3AgPSBjdXJzb3JMZWF2ZUZyb21Cb3R0b20gPyByZWN0LnJpZ2h0IC0gUE9MWUdPTl9CVUZGRVIgOiBpc0Zsb2F0aW5nVGFsbGVyID8gcmVjdC5yaWdodCAtIFBPTFlHT05fQlVGRkVSIDogcmVjdC5sZWZ0O1xuICAgICAgICAgICAgY29uc3QgY29tbW9uWEJvdHRvbSA9IGN1cnNvckxlYXZlRnJvbUJvdHRvbSA/IGlzRmxvYXRpbmdUYWxsZXIgPyByZWN0LnJpZ2h0IC0gUE9MWUdPTl9CVUZGRVIgOiByZWN0LmxlZnQgOiByZWN0LnJpZ2h0IC0gUE9MWUdPTl9CVUZGRVI7XG4gICAgICAgICAgICBpc0luc2lkZVBvbHlnb24gPSBpc1BvaW50SW5RdWFkcmlsYXRlcmFsKGNsaWVudFgsIGNsaWVudFksIGNvbW1vblhUb3AsIHJlY3QudG9wLCBjb21tb25YQm90dG9tLCByZWN0LmJvdHRvbSwgY3Vyc29yUG9pbnRYLCBjdXJzb3JQb2ludE9uZVksIGN1cnNvclBvaW50WCwgY3Vyc29yUG9pbnRUd29ZKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgY2FzZSAncmlnaHQnOlxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGNvbnN0IGN1cnNvcllPZmZzZXQgPSBpc0Zsb2F0aW5nVGFsbGVyID8gUE9MWUdPTl9CVUZGRVIgLyAyIDogUE9MWUdPTl9CVUZGRVIgKiA0O1xuICAgICAgICAgICAgY29uc3QgY3Vyc29yUG9pbnRPbmVZID0gaXNGbG9hdGluZ1RhbGxlciA/IHkgKyBjdXJzb3JZT2Zmc2V0IDogY3Vyc29yTGVhdmVGcm9tQm90dG9tID8geSArIGN1cnNvcllPZmZzZXQgOiB5IC0gY3Vyc29yWU9mZnNldDtcbiAgICAgICAgICAgIGNvbnN0IGN1cnNvclBvaW50VHdvWSA9IGlzRmxvYXRpbmdUYWxsZXIgPyB5IC0gY3Vyc29yWU9mZnNldCA6IGN1cnNvckxlYXZlRnJvbUJvdHRvbSA/IHkgKyBjdXJzb3JZT2Zmc2V0IDogeSAtIGN1cnNvcllPZmZzZXQ7XG4gICAgICAgICAgICBjb25zdCBjdXJzb3JQb2ludFggPSB4IC0gUE9MWUdPTl9CVUZGRVI7XG4gICAgICAgICAgICBjb25zdCBjb21tb25YVG9wID0gY3Vyc29yTGVhdmVGcm9tQm90dG9tID8gcmVjdC5sZWZ0ICsgUE9MWUdPTl9CVUZGRVIgOiBpc0Zsb2F0aW5nVGFsbGVyID8gcmVjdC5sZWZ0ICsgUE9MWUdPTl9CVUZGRVIgOiByZWN0LnJpZ2h0O1xuICAgICAgICAgICAgY29uc3QgY29tbW9uWEJvdHRvbSA9IGN1cnNvckxlYXZlRnJvbUJvdHRvbSA/IGlzRmxvYXRpbmdUYWxsZXIgPyByZWN0LmxlZnQgKyBQT0xZR09OX0JVRkZFUiA6IHJlY3QucmlnaHQgOiByZWN0LmxlZnQgKyBQT0xZR09OX0JVRkZFUjtcbiAgICAgICAgICAgIGlzSW5zaWRlUG9seWdvbiA9IGlzUG9pbnRJblF1YWRyaWxhdGVyYWwoY2xpZW50WCwgY2xpZW50WSwgY3Vyc29yUG9pbnRYLCBjdXJzb3JQb2ludE9uZVksIGN1cnNvclBvaW50WCwgY3Vyc29yUG9pbnRUd29ZLCBjb21tb25YVG9wLCByZWN0LnRvcCwgY29tbW9uWEJvdHRvbSwgcmVjdC5ib3R0b20pO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICBkZWZhdWx0OlxuICAgICAgfVxuICAgICAgaWYgKCFpc0luc2lkZVBvbHlnb24pIHtcbiAgICAgICAgY2xvc2VJZk5vT3BlbkNoaWxkKCk7XG4gICAgICB9IGVsc2UgaWYgKCFoYXNMYW5kZWQpIHtcbiAgICAgICAgdGltZW91dC5zdGFydCg0MCwgY2xvc2VJZk5vT3BlbkNoaWxkKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfTtcbiAgfTtcblxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tdW5kZXJzY29yZS1kYW5nbGVcbiAgZm4uX19vcHRpb25zID0ge1xuICAgIC4uLm9wdGlvbnMsXG4gICAgYmxvY2tQb2ludGVyRXZlbnRzXG4gIH07XG4gIHJldHVybiBmbjtcbn0iLCIvKipcbiAqIFRoZSB3aWR0aCBvZiB0aGUgcGFyZW50IHBvcHVwLlxuICogVGhpcyB2YXJpYWJsZSBpcyBwbGFjZWQgb24gdGhlICdwcmV2aW91cycgY29udGFpbmVyIGFuZCBzdG9yZXMgdGhlIHdpZHRoIG9mIHRoZSBwb3B1cCB3aGVuIHRoZSBwcmV2aW91cyBjb250ZW50IHdhcyByZW5kZXJlZC5cbiAqIEl0IGNhbiBiZSB1c2VkIHRvIGZyZWV6ZSB0aGUgZGltZW5zaW9ucyBvZiB0aGUgcG9wdXAgd2hlbiBhbmltYXRpbmcgYmV0d2VlbiBkaWZmZXJlbnQgY29udGVudC5cbiAqL1xuZXhwb3J0IGNvbnN0IHBvcHVwV2lkdGggPSAnLS1wb3B1cC13aWR0aCc7XG4vKipcbiAqIFRoZSBoZWlnaHQgb2YgdGhlIHBhcmVudCBwb3B1cC5cbiAqIFRoaXMgdmFyaWFibGUgaXMgcGxhY2VkIG9uIHRoZSAncHJldmlvdXMnIGNvbnRhaW5lciBhbmQgc3RvcmVzIHRoZSBoZWlnaHQgb2YgdGhlIHBvcHVwIHdoZW4gdGhlIHByZXZpb3VzIGNvbnRlbnQgd2FzIHJlbmRlcmVkLlxuICogSXQgY2FuIGJlIHVzZWQgdG8gZnJlZXplIHRoZSBkaW1lbnNpb25zIG9mIHRoZSBwb3B1cCB3aGVuIGFuaW1hdGluZyBiZXR3ZWVuIGRpZmZlcmVudCBjb250ZW50LlxuICovXG5leHBvcnQgY29uc3QgcG9wdXBIZWlnaHQgPSAnLS1wb3B1cC1oZWlnaHQnOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlQW5pbWF0aW9uRnJhbWUgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VBbmltYXRpb25GcmFtZSc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyBOT09QLCBFTVBUWV9PQkpFQ1QgfSBmcm9tICdAYmFzZS11aS91dGlscy9lbXB0eSc7XG5pbXBvcnQgeyB1c2VBbmltYXRpb25zRmluaXNoZWQgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL3VzZUFuaW1hdGlvbnNGaW5pc2hlZC5tanNcIjtcbmltcG9ydCB7IGdldENzc0RpbWVuc2lvbnMgfSBmcm9tIFwiLi9nZXRDc3NEaW1lbnNpb25zLm1qc1wiO1xuaW1wb3J0ICogYXMgQ29tbW9uUG9wdXBDc3NWYXJzIGZyb20gXCIuL0NvbW1vblBvcHVwQ3NzVmFycy5tanNcIjtcbmltcG9ydCAqIGFzIENvbW1vblBvc2l0aW9uZXJDc3NWYXJzIGZyb20gXCIuL0NvbW1vblBvc2l0aW9uZXJDc3NWYXJzLm1qc1wiO1xuXG4vKipcbiAqIEFsbG93cyB0aGUgZWxlbWVudCB0byBhdXRvbWF0aWNhbGx5IHJlc2l6ZSBiYXNlZCBvbiBpdHMgY29udGVudCB3aGlsZSBzdXBwb3J0aW5nIGFuaW1hdGlvbnMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VQb3B1cEF1dG9SZXNpemUocGFyYW1ldGVycykge1xuICBjb25zdCB7XG4gICAgcG9wdXBFbGVtZW50LFxuICAgIHBvc2l0aW9uZXJFbGVtZW50LFxuICAgIGNvbnRlbnQsXG4gICAgbW91bnRlZCxcbiAgICBvbk1lYXN1cmVMYXlvdXQ6IG9uTWVhc3VyZUxheW91dFBhcmFtLFxuICAgIG9uTWVhc3VyZUxheW91dENvbXBsZXRlOiBvbk1lYXN1cmVMYXlvdXRDb21wbGV0ZVBhcmFtLFxuICAgIHNpZGUsXG4gICAgZGlyZWN0aW9uXG4gIH0gPSBwYXJhbWV0ZXJzO1xuICBjb25zdCBydW5PbmNlQW5pbWF0aW9uc0ZpbmlzaCA9IHVzZUFuaW1hdGlvbnNGaW5pc2hlZChwb3B1cEVsZW1lbnQsIHRydWUpO1xuICBjb25zdCBhbmltYXRpb25GcmFtZSA9IHVzZUFuaW1hdGlvbkZyYW1lKCk7XG4gIGNvbnN0IGNvbW1pdHRlZERpbWVuc2lvbnNSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IG9uTWVhc3VyZUxheW91dCA9IHVzZVN0YWJsZUNhbGxiYWNrKG9uTWVhc3VyZUxheW91dFBhcmFtKTtcbiAgY29uc3Qgb25NZWFzdXJlTGF5b3V0Q29tcGxldGUgPSB1c2VTdGFibGVDYWxsYmFjayhvbk1lYXN1cmVMYXlvdXRDb21wbGV0ZVBhcmFtKTtcbiAgY29uc3QgYW5jaG9yaW5nU3R5bGVzID0gUmVhY3QudXNlTWVtbygoKSA9PiBnZXRQb3B1cEFuY2hvcmluZ1N0eWxlcyhzaWRlLCBkaXJlY3Rpb24pLCBbc2lkZSwgZGlyZWN0aW9uXSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgLy8gUmVzZXQgdGhlIHN0YXRlIHdoZW4gdGhlIHBvcHVwIGlzIGNsb3NlZC5cbiAgICBpZiAoIW1vdW50ZWQpIHtcbiAgICAgIGNvbW1pdHRlZERpbWVuc2lvbnNSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBpZiAoIXBvcHVwRWxlbWVudCB8fCAhcG9zaXRpb25lckVsZW1lbnQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGNvbnN0IHJlc3RvcmVBbmNob3JpbmdTdHlsZXMgPSBhcHBseUVsZW1lbnRTdHlsZXMocG9wdXBFbGVtZW50LCBhbmNob3JpbmdTdHlsZXMpO1xuXG4gICAgLy8gTWVhc3VyZSB0aGUgcmVuZGVyZWQgc2l6ZSB0byBlbmFibGUgdHJhbnNpdGlvbnM6XG4gICAgc2V0UG9wdXBDc3NTaXplKHBvcHVwRWxlbWVudCwgJ2F1dG8nKTtcbiAgICBjb25zdCByZXN0b3JlUG9wdXBQb3NpdGlvbiA9IG92ZXJyaWRlRWxlbWVudFN0eWxlKHBvcHVwRWxlbWVudCwgJ3Bvc2l0aW9uJywgJ3N0YXRpYycpO1xuICAgIGNvbnN0IHJlc3RvcmVQb3B1cFRyYW5zZm9ybSA9IG92ZXJyaWRlRWxlbWVudFN0eWxlKHBvcHVwRWxlbWVudCwgJ3RyYW5zZm9ybScsICdub25lJyk7XG4gICAgY29uc3QgcmVzdG9yZVBvcHVwU2NhbGUgPSBvdmVycmlkZUVsZW1lbnRTdHlsZShwb3B1cEVsZW1lbnQsICdzY2FsZScsICcxJyk7XG4gICAgY29uc3QgcmVzdG9yZVBvc2l0aW9uZXJBdmFpbGFibGVTaXplID0gYXBwbHlFbGVtZW50U3R5bGVzKHBvc2l0aW9uZXJFbGVtZW50LCB7XG4gICAgICBbQ29tbW9uUG9zaXRpb25lckNzc1ZhcnMuYXZhaWxhYmxlV2lkdGhdOiAnbWF4LWNvbnRlbnQnLFxuICAgICAgW0NvbW1vblBvc2l0aW9uZXJDc3NWYXJzLmF2YWlsYWJsZUhlaWdodF06ICdtYXgtY29udGVudCdcbiAgICB9KTtcbiAgICBmdW5jdGlvbiByZXN0b3JlTWVhc3VyZW1lbnRPdmVycmlkZXMoKSB7XG4gICAgICByZXN0b3JlUG9wdXBQb3NpdGlvbigpO1xuICAgICAgcmVzdG9yZVBvcHVwVHJhbnNmb3JtKCk7XG4gICAgICByZXN0b3JlUG9zaXRpb25lckF2YWlsYWJsZVNpemUoKTtcbiAgICAgIHJlc3RvcmVQb3B1cFNjYWxlKCk7XG4gICAgfVxuICAgIG9uTWVhc3VyZUxheW91dD8uKCk7XG5cbiAgICAvLyBJbml0aWFsIHJlbmRlciAoZm9yIGVhY2ggdGltZSB0aGUgcG9wdXAgb3BlbnMpLlxuICAgIGlmIChjb21taXR0ZWREaW1lbnNpb25zUmVmLmN1cnJlbnQgPT09IG51bGwpIHtcbiAgICAgIHNldFBvc2l0aW9uZXJDc3NTaXplKHBvc2l0aW9uZXJFbGVtZW50LCAnbWF4LWNvbnRlbnQnKTtcbiAgICAgIGNvbnN0IGRpbWVuc2lvbnMgPSBnZXRDc3NEaW1lbnNpb25zKHBvcHVwRWxlbWVudCk7XG4gICAgICBjb21taXR0ZWREaW1lbnNpb25zUmVmLmN1cnJlbnQgPSBkaW1lbnNpb25zO1xuICAgICAgc2V0UG9zaXRpb25lckNzc1NpemUocG9zaXRpb25lckVsZW1lbnQsIGRpbWVuc2lvbnMpO1xuICAgICAgcmVzdG9yZU1lYXN1cmVtZW50T3ZlcnJpZGVzKCk7XG4gICAgICBvbk1lYXN1cmVMYXlvdXRDb21wbGV0ZT8uKG51bGwsIGRpbWVuc2lvbnMpO1xuICAgICAgcmV0dXJuIHJlc3RvcmVBbmNob3JpbmdTdHlsZXM7XG4gICAgfVxuXG4gICAgLy8gU3Vic2VxdWVudCByZW5kZXJzIHdoaWxlIG9wZW4gKHdoZW4gYGNvbnRlbnRgIGNoYW5nZXMpLlxuICAgIHNldFBvc2l0aW9uZXJDc3NTaXplKHBvc2l0aW9uZXJFbGVtZW50LCAnbWF4LWNvbnRlbnQnKTtcbiAgICBjb25zdCBwcmV2aW91c0RpbWVuc2lvbnMgPSBjb21taXR0ZWREaW1lbnNpb25zUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgbmV3RGltZW5zaW9ucyA9IGdldENzc0RpbWVuc2lvbnMocG9wdXBFbGVtZW50KTtcblxuICAgIC8vIENvbW1pdCBpbW1lZGlhdGVseSBzbyBmdXR1cmUgY29udGVudCBjaGFuZ2VzIGhhdmUgYSBzdGFibGUgcHJldmlvdXMgc2l6ZS5cbiAgICBjb21taXR0ZWREaW1lbnNpb25zUmVmLmN1cnJlbnQgPSBuZXdEaW1lbnNpb25zO1xuICAgIHNldFBvcHVwQ3NzU2l6ZShwb3B1cEVsZW1lbnQsIHByZXZpb3VzRGltZW5zaW9ucyk7XG4gICAgcmVzdG9yZU1lYXN1cmVtZW50T3ZlcnJpZGVzKCk7XG4gICAgb25NZWFzdXJlTGF5b3V0Q29tcGxldGU/LihwcmV2aW91c0RpbWVuc2lvbnMsIG5ld0RpbWVuc2lvbnMpO1xuICAgIHNldFBvc2l0aW9uZXJDc3NTaXplKHBvc2l0aW9uZXJFbGVtZW50LCBuZXdEaW1lbnNpb25zKTtcbiAgICBjb25zdCBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgYW5pbWF0aW9uRnJhbWUucmVxdWVzdCgoKSA9PiB7XG4gICAgICBzZXRQb3B1cENzc1NpemUocG9wdXBFbGVtZW50LCBuZXdEaW1lbnNpb25zKTtcbiAgICAgIHJ1bk9uY2VBbmltYXRpb25zRmluaXNoKCgpID0+IHtcbiAgICAgICAgcG9wdXBFbGVtZW50LnN0eWxlLnNldFByb3BlcnR5KENvbW1vblBvcHVwQ3NzVmFycy5wb3B1cFdpZHRoLCAnYXV0bycpO1xuICAgICAgICBwb3B1cEVsZW1lbnQuc3R5bGUuc2V0UHJvcGVydHkoQ29tbW9uUG9wdXBDc3NWYXJzLnBvcHVwSGVpZ2h0LCAnYXV0bycpO1xuICAgICAgfSwgYWJvcnRDb250cm9sbGVyLnNpZ25hbCk7XG4gICAgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGFib3J0Q29udHJvbGxlci5hYm9ydCgpO1xuICAgICAgYW5pbWF0aW9uRnJhbWUuY2FuY2VsKCk7XG4gICAgICByZXN0b3JlQW5jaG9yaW5nU3R5bGVzKCk7XG4gICAgfTtcbiAgfSwgW2NvbnRlbnQsIHBvcHVwRWxlbWVudCwgcG9zaXRpb25lckVsZW1lbnQsIHJ1bk9uY2VBbmltYXRpb25zRmluaXNoLCBhbmltYXRpb25GcmFtZSwgbW91bnRlZCwgb25NZWFzdXJlTGF5b3V0LCBvbk1lYXN1cmVMYXlvdXRDb21wbGV0ZSwgYW5jaG9yaW5nU3R5bGVzXSk7XG59XG5mdW5jdGlvbiBnZXRQb3B1cEFuY2hvcmluZ1N0eWxlcyhzaWRlLCBkaXJlY3Rpb24pIHtcbiAgLy8gRW5zdXJlIHBvcHVwIHNpemUgdHJhbnNpdGlvbnMgY29ycmVjdGx5IHdoZW4gYW5jaG9yZWQgdG8gYGJvdHRvbWAgKHNpZGU9dG9wKSBvciBgcmlnaHRgIChzaWRlPWxlZnQpLlxuICBjb25zdCBpc1BoeXNpY2FsVG9wID0gc2lkZSA9PT0gJ3RvcCc7XG4gIGNvbnN0IGlzUGh5c2ljYWxMZWZ0ID0gc2lkZSA9PT0gJ2xlZnQnIHx8IHNpZGUgPT09IChkaXJlY3Rpb24gPT09ICdydGwnID8gJ2lubGluZS1lbmQnIDogJ2lubGluZS1zdGFydCcpO1xuICBpZiAoIWlzUGh5c2ljYWxUb3AgJiYgIWlzUGh5c2ljYWxMZWZ0KSB7XG4gICAgcmV0dXJuIEVNUFRZX09CSkVDVDtcbiAgfVxuICByZXR1cm4ge1xuICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuICAgIFtpc1BoeXNpY2FsVG9wID8gJ2JvdHRvbScgOiAndG9wJ106ICcwJyxcbiAgICBbaXNQaHlzaWNhbExlZnQgPyAncmlnaHQnIDogJ2xlZnQnXTogJzAnXG4gIH07XG59XG5mdW5jdGlvbiBvdmVycmlkZUVsZW1lbnRTdHlsZShlbGVtZW50LCBwcm9wZXJ0eSwgdmFsdWUpIHtcbiAgY29uc3Qgb3JpZ2luYWxWYWx1ZSA9IGVsZW1lbnQuc3R5bGUuZ2V0UHJvcGVydHlWYWx1ZShwcm9wZXJ0eSk7XG4gIGVsZW1lbnQuc3R5bGUuc2V0UHJvcGVydHkocHJvcGVydHksIHZhbHVlKTtcbiAgcmV0dXJuICgpID0+IHtcbiAgICBlbGVtZW50LnN0eWxlLnNldFByb3BlcnR5KHByb3BlcnR5LCBvcmlnaW5hbFZhbHVlKTtcbiAgfTtcbn1cbmZ1bmN0aW9uIGFwcGx5RWxlbWVudFN0eWxlcyhlbGVtZW50LCBzdHlsZXMpIHtcbiAgY29uc3QgcmVzdG9yZXJzID0gW107XG4gIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKHN0eWxlcykpIHtcbiAgICByZXN0b3JlcnMucHVzaChvdmVycmlkZUVsZW1lbnRTdHlsZShlbGVtZW50LCBrZXksIHZhbHVlKSk7XG4gIH1cbiAgcmV0dXJuIHJlc3RvcmVycy5sZW5ndGggPyAoKSA9PiB7XG4gICAgcmVzdG9yZXJzLmZvckVhY2gocmVzdG9yZSA9PiByZXN0b3JlKCkpO1xuICB9IDogTk9PUDtcbn1cbmZ1bmN0aW9uIHNldFBvcHVwQ3NzU2l6ZShwb3B1cEVsZW1lbnQsIHNpemUpIHtcbiAgY29uc3Qgd2lkdGggPSBzaXplID09PSAnYXV0bycgPyAnYXV0bycgOiBgJHtzaXplLndpZHRofXB4YDtcbiAgY29uc3QgaGVpZ2h0ID0gc2l6ZSA9PT0gJ2F1dG8nID8gJ2F1dG8nIDogYCR7c2l6ZS5oZWlnaHR9cHhgO1xuICBwb3B1cEVsZW1lbnQuc3R5bGUuc2V0UHJvcGVydHkoQ29tbW9uUG9wdXBDc3NWYXJzLnBvcHVwV2lkdGgsIHdpZHRoKTtcbiAgcG9wdXBFbGVtZW50LnN0eWxlLnNldFByb3BlcnR5KENvbW1vblBvcHVwQ3NzVmFycy5wb3B1cEhlaWdodCwgaGVpZ2h0KTtcbn1cbmZ1bmN0aW9uIHNldFBvc2l0aW9uZXJDc3NTaXplKHBvc2l0aW9uZXJFbGVtZW50LCBzaXplKSB7XG4gIGNvbnN0IHdpZHRoID0gc2l6ZSA9PT0gJ21heC1jb250ZW50JyA/ICdtYXgtY29udGVudCcgOiBgJHtzaXplLndpZHRofXB4YDtcbiAgY29uc3QgaGVpZ2h0ID0gc2l6ZSA9PT0gJ21heC1jb250ZW50JyA/ICdtYXgtY29udGVudCcgOiBgJHtzaXplLmhlaWdodH1weGA7XG4gIHBvc2l0aW9uZXJFbGVtZW50LnN0eWxlLnNldFByb3BlcnR5KENvbW1vblBvc2l0aW9uZXJDc3NWYXJzLnBvc2l0aW9uZXJXaWR0aCwgd2lkdGgpO1xuICBwb3NpdGlvbmVyRWxlbWVudC5zdHlsZS5zZXRQcm9wZXJ0eShDb21tb25Qb3NpdGlvbmVyQ3NzVmFycy5wb3NpdGlvbmVySGVpZ2h0LCBoZWlnaHQpO1xufSIsImltcG9ydCB7IG93bmVyRG9jdW1lbnQsIG93bmVyV2luZG93IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvb3duZXInO1xuaW1wb3J0IHsgZ2V0U2lkZSB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscyc7XG5pbXBvcnQgeyBERUZBVUxUX1NJREVTIH0gZnJvbSBcIi4vYWRhcHRpdmVPcmlnaW5Db25zdGFudHMubWpzXCI7XG5leHBvcnQgY29uc3QgYWRhcHRpdmVPcmlnaW4gPSB7XG4gIG5hbWU6ICdhZGFwdGl2ZU9yaWdpbicsXG4gIGFzeW5jIGZuKHN0YXRlKSB7XG4gICAgY29uc3Qge1xuICAgICAgeDogcmF3WCxcbiAgICAgIHk6IHJhd1ksXG4gICAgICByZWN0czoge1xuICAgICAgICBmbG9hdGluZzogZmxvYXRSZWN0XG4gICAgICB9LFxuICAgICAgZWxlbWVudHM6IHtcbiAgICAgICAgZmxvYXRpbmdcbiAgICAgIH0sXG4gICAgICBwbGF0Zm9ybSxcbiAgICAgIHN0cmF0ZWd5LFxuICAgICAgcGxhY2VtZW50XG4gICAgfSA9IHN0YXRlO1xuICAgIGNvbnN0IHdpbiA9IG93bmVyV2luZG93KGZsb2F0aW5nKTtcbiAgICBjb25zdCBzdHlsZXMgPSB3aW4uZ2V0Q29tcHV0ZWRTdHlsZShmbG9hdGluZyk7XG4gICAgY29uc3QgaGFzVHJhbnNpdGlvbiA9IHN0eWxlcy50cmFuc2l0aW9uRHVyYXRpb24gIT09ICcwcycgJiYgc3R5bGVzLnRyYW5zaXRpb25EdXJhdGlvbiAhPT0gJyc7XG4gICAgaWYgKCFoYXNUcmFuc2l0aW9uKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB4OiByYXdYLFxuICAgICAgICB5OiByYXdZLFxuICAgICAgICBkYXRhOiBERUZBVUxUX1NJREVTXG4gICAgICB9O1xuICAgIH1cbiAgICBjb25zdCBvZmZzZXRQYXJlbnQgPSBhd2FpdCBwbGF0Zm9ybS5nZXRPZmZzZXRQYXJlbnQ/LihmbG9hdGluZyk7XG4gICAgbGV0IG9mZnNldERpbWVuc2lvbnMgPSB7XG4gICAgICB3aWR0aDogMCxcbiAgICAgIGhlaWdodDogMFxuICAgIH07XG5cbiAgICAvLyBGb3IgZml4ZWQgc3RyYXRlZ3ksIHByZWZlciB2aXN1YWxWaWV3cG9ydCBpZiBhdmFpbGFibGVcbiAgICBpZiAoc3RyYXRlZ3kgPT09ICdmaXhlZCcgJiYgd2luPy52aXN1YWxWaWV3cG9ydCkge1xuICAgICAgb2Zmc2V0RGltZW5zaW9ucyA9IHtcbiAgICAgICAgd2lkdGg6IHdpbi52aXN1YWxWaWV3cG9ydC53aWR0aCxcbiAgICAgICAgaGVpZ2h0OiB3aW4udmlzdWFsVmlld3BvcnQuaGVpZ2h0XG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAob2Zmc2V0UGFyZW50ID09PSB3aW4pIHtcbiAgICAgIGNvbnN0IGRvYyA9IG93bmVyRG9jdW1lbnQoZmxvYXRpbmcpO1xuICAgICAgb2Zmc2V0RGltZW5zaW9ucyA9IHtcbiAgICAgICAgd2lkdGg6IGRvYy5kb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGgsXG4gICAgICAgIGhlaWdodDogZG9jLmRvY3VtZW50RWxlbWVudC5jbGllbnRIZWlnaHRcbiAgICAgIH07XG4gICAgfSBlbHNlIGlmIChhd2FpdCBwbGF0Zm9ybS5pc0VsZW1lbnQ/LihvZmZzZXRQYXJlbnQpKSB7XG4gICAgICBvZmZzZXREaW1lbnNpb25zID0gYXdhaXQgcGxhdGZvcm0uZ2V0RGltZW5zaW9ucyhvZmZzZXRQYXJlbnQpO1xuICAgIH1cbiAgICBjb25zdCBjdXJyZW50U2lkZSA9IGdldFNpZGUocGxhY2VtZW50KTtcbiAgICBsZXQgeCA9IHJhd1g7XG4gICAgbGV0IHkgPSByYXdZO1xuICAgIGlmIChjdXJyZW50U2lkZSA9PT0gJ2xlZnQnKSB7XG4gICAgICB4ID0gb2Zmc2V0RGltZW5zaW9ucy53aWR0aCAtIChyYXdYICsgZmxvYXRSZWN0LndpZHRoKTtcbiAgICB9XG4gICAgaWYgKGN1cnJlbnRTaWRlID09PSAndG9wJykge1xuICAgICAgeSA9IG9mZnNldERpbWVuc2lvbnMuaGVpZ2h0IC0gKHJhd1kgKyBmbG9hdFJlY3QuaGVpZ2h0KTtcbiAgICB9XG4gICAgY29uc3Qgc2lkZVggPSBjdXJyZW50U2lkZSA9PT0gJ2xlZnQnID8gJ3JpZ2h0JyA6IERFRkFVTFRfU0lERVMuc2lkZVg7XG4gICAgY29uc3Qgc2lkZVkgPSBjdXJyZW50U2lkZSA9PT0gJ3RvcCcgPyAnYm90dG9tJyA6IERFRkFVTFRfU0lERVMuc2lkZVk7XG4gICAgcmV0dXJuIHtcbiAgICAgIHgsXG4gICAgICB5LFxuICAgICAgZGF0YToge1xuICAgICAgICBzaWRlWCxcbiAgICAgICAgc2lkZVlcbiAgICAgIH1cbiAgICB9O1xuICB9XG59OyIsIi8qKlxuICogSW5kaWNhdGVzIHRoZSBkaXJlY3Rpb24gZnJvbSB3aGljaCB0aGUgcG9wdXAgd2FzIGFjdGl2YXRlZC5cbiAqIFRoaXMgY2FuIGJlIHVzZWQgdG8gY3JlYXRlIGRpcmVjdGlvbmFsIGFuaW1hdGlvbnMgYmFzZWQgb24gaG93IHRoZSBwb3B1cCB3YXMgdHJpZ2dlcmVkLlxuICogQ29udGFpbnMgc3BhY2Utc2VwYXJhdGVkIHZhbHVlcyBmb3IgYm90aCBob3Jpem9udGFsIGFuZCB2ZXJ0aWNhbCBheGVzLlxuICogQHR5cGUge2AkeydsZWZ0JyB8ICdyaWdodCcgfCAnJ30gJHsnZG93bicgfCAndXAnIHwgJyd9YH1cbiAqL1xuZXhwb3J0IGNvbnN0IGFjdGl2YXRpb25EaXJlY3Rpb24gPSAnZGF0YS1hY3RpdmF0aW9uLWRpcmVjdGlvbic7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgKiBhcyBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20nO1xuaW1wb3J0IHsgaW5lcnRWYWx1ZSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2luZXJ0VmFsdWUnO1xuaW1wb3J0IHsgdXNlQW5pbWF0aW9uRnJhbWUgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VBbmltYXRpb25GcmFtZSc7XG5pbXBvcnQgeyB1c2VQcmV2aW91c1ZhbHVlIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlUHJldmlvdXNWYWx1ZSc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyBvd25lckRvY3VtZW50IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvb3duZXInO1xuaW1wb3J0IHsgdXNlQW5pbWF0aW9uc0ZpbmlzaGVkIH0gZnJvbSBcIi4uL2ludGVybmFscy91c2VBbmltYXRpb25zRmluaXNoZWQubWpzXCI7XG5pbXBvcnQgeyB1c2VQb3B1cEF1dG9SZXNpemUgfSBmcm9tIFwiLi91c2VQb3B1cEF1dG9SZXNpemUubWpzXCI7XG5pbXBvcnQgeyB1c2VEaXJlY3Rpb24gfSBmcm9tIFwiLi4vZGlyZWN0aW9uLXByb3ZpZGVyL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgYWRhcHRpdmVPcmlnaW4gfSBmcm9tIFwiLi9hZGFwdGl2ZU9yaWdpbk1pZGRsZXdhcmUubWpzXCI7XG5pbXBvcnQgKiBhcyBDb21tb25Qb3B1cENzc1ZhcnMgZnJvbSBcIi4vQ29tbW9uUG9wdXBDc3NWYXJzLm1qc1wiO1xuaW1wb3J0ICogYXMgQ29tbW9uVmlld3BvcnREYXRhQXR0cmlidXRlcyBmcm9tIFwiLi9Db21tb25WaWV3cG9ydERhdGFBdHRyaWJ1dGVzLm1qc1wiO1xuaW1wb3J0IHsganN4IGFzIF9qc3gsIGpzeHMgYXMgX2pzeHMgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCBjb25zdCBwb3B1cFZpZXdwb3J0U3RhdGVNYXBwaW5nID0ge1xuICBhY3RpdmF0aW9uRGlyZWN0aW9uOiB2YWx1ZSA9PiB2YWx1ZSA/IHtcbiAgICBbQ29tbW9uVmlld3BvcnREYXRhQXR0cmlidXRlcy5hY3RpdmF0aW9uRGlyZWN0aW9uXTogdmFsdWVcbiAgfSA6IG51bGxcbn07XG4vKipcbiAqIEJ1aWxkcyBtb3JwaGluZyB2aWV3cG9ydCBjb250YWluZXJzIGZvciBwb3B1cHMgdGhhdCBhbmltYXRlIGJldHdlZW4gdHJpZ2dlci1iYXNlZCBjb250ZW50LlxuICogSGFuZGxlcyBwcmV2aW91cy1jb250ZW50IHNuYXBzaG90cywgYXV0by1yZXNpemUsIGFuZCBzdGF0ZSBhdHRyaWJ1dGVzIGZvciB0cmFuc2l0aW9ucy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVBvcHVwVmlld3BvcnQocGFyYW1ldGVycykge1xuICBjb25zdCB7XG4gICAgc3RvcmUsXG4gICAgc2lkZSxcbiAgICBjaGlsZHJlblxuICB9ID0gcGFyYW1ldGVycztcbiAgY29uc3QgZGlyZWN0aW9uID0gdXNlRGlyZWN0aW9uKCk7XG4gIGNvbnN0IGFjdGl2ZVRyaWdnZXIgPSBzdG9yZS51c2VTdGF0ZSgnYWN0aXZlVHJpZ2dlckVsZW1lbnQnKTtcbiAgY29uc3QgYWN0aXZlVHJpZ2dlcklkID0gc3RvcmUudXNlU3RhdGUoJ2FjdGl2ZVRyaWdnZXJJZCcpO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3QgcGF5bG9hZCA9IHN0b3JlLnVzZVN0YXRlKCdwYXlsb2FkJyk7XG4gIGNvbnN0IG1vdW50ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbW91bnRlZCcpO1xuICBjb25zdCBwb3B1cEVsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZSgncG9wdXBFbGVtZW50Jyk7XG4gIGNvbnN0IHBvc2l0aW9uZXJFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ3Bvc2l0aW9uZXJFbGVtZW50Jyk7XG4gIGNvbnN0IHByZXZpb3VzQWN0aXZlVHJpZ2dlciA9IHVzZVByZXZpb3VzVmFsdWUob3BlbiA/IGFjdGl2ZVRyaWdnZXIgOiBudWxsKTtcbiAgLy8gUmVtb3VudCBjdXJyZW50IGNvbnRlbnQgb24gdHJpZ2dlciBjaGFuZ2VzIChhbmQgb25jZSBtb3JlIHdoZW4gcGF5bG9hZCBsYWdzKSB0byBhdm9pZCBET00gcmV1c2UgZmxhc2hlcy5cbiAgLy8gVGhlIGtleSBidW1wcyBpbW1lZGlhdGVseSBvbiB0cmlnZ2VyIHN3aXRjaGVzLCB0aGVuIGFnYWluIGlmIHRoZSBwYXlsb2FkIGFycml2ZXMgb24gYSBsYXRlciByZW5kZXIuXG4gIGNvbnN0IGN1cnJlbnRDb250ZW50S2V5ID0gdXNlUG9wdXBDb250ZW50S2V5KGFjdGl2ZVRyaWdnZXJJZCwgcGF5bG9hZCk7XG4gIGNvbnN0IGNhcHR1cmVkTm9kZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgW3ByZXZpb3VzQ29udGVudE5vZGUsIHNldFByZXZpb3VzQ29udGVudE5vZGVdID0gUmVhY3QudXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IFtuZXdUcmlnZ2VyT2Zmc2V0LCBzZXROZXdUcmlnZ2VyT2Zmc2V0XSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBjdXJyZW50Q29udGFpbmVyUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBwcmV2aW91c0NvbnRhaW5lclJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3Qgb25BbmltYXRpb25zRmluaXNoZWQgPSB1c2VBbmltYXRpb25zRmluaXNoZWQoY3VycmVudENvbnRhaW5lclJlZiwgdHJ1ZSk7XG4gIGNvbnN0IGNsZWFudXBGcmFtZSA9IHVzZUFuaW1hdGlvbkZyYW1lKCk7XG4gIGNvbnN0IGNsZWFudXBDb250cm9sbGVyUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBbcHJldmlvdXNDb250ZW50RGltZW5zaW9ucywgc2V0UHJldmlvdXNDb250ZW50RGltZW5zaW9uc10gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW3Nob3dTdGFydGluZ1N0eWxlQXR0cmlidXRlLCBzZXRTaG93U3RhcnRpbmdTdHlsZUF0dHJpYnV0ZV0gPSBSZWFjdC51c2VTdGF0ZShmYWxzZSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgc3RvcmUuc2V0KCdhZGFwdGl2ZU9yaWdpbicsIGFkYXB0aXZlT3JpZ2luKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgc3RvcmUuc2V0KCdhZGFwdGl2ZU9yaWdpbicsIHVuZGVmaW5lZCk7XG4gICAgfTtcbiAgfSwgW3N0b3JlXSk7XG4gIGNvbnN0IGhhbmRsZU1lYXN1cmVMYXlvdXQgPSB1c2VTdGFibGVDYWxsYmFjaygoKSA9PiB7XG4gICAgY3VycmVudENvbnRhaW5lclJlZi5jdXJyZW50Py5zdHlsZS5zZXRQcm9wZXJ0eSgnYW5pbWF0aW9uJywgJ25vbmUnKTtcbiAgICBjdXJyZW50Q29udGFpbmVyUmVmLmN1cnJlbnQ/LnN0eWxlLnNldFByb3BlcnR5KCd0cmFuc2l0aW9uJywgJ25vbmUnKTtcbiAgICBwcmV2aW91c0NvbnRhaW5lclJlZi5jdXJyZW50Py5zdHlsZS5zZXRQcm9wZXJ0eSgnZGlzcGxheScsICdub25lJyk7XG4gIH0pO1xuICBjb25zdCBoYW5kbGVNZWFzdXJlTGF5b3V0Q29tcGxldGUgPSB1c2VTdGFibGVDYWxsYmFjayhwcmV2aW91c0RpbWVuc2lvbnMgPT4ge1xuICAgIGN1cnJlbnRDb250YWluZXJSZWYuY3VycmVudD8uc3R5bGUucmVtb3ZlUHJvcGVydHkoJ2FuaW1hdGlvbicpO1xuICAgIGN1cnJlbnRDb250YWluZXJSZWYuY3VycmVudD8uc3R5bGUucmVtb3ZlUHJvcGVydHkoJ3RyYW5zaXRpb24nKTtcbiAgICBwcmV2aW91c0NvbnRhaW5lclJlZi5jdXJyZW50Py5zdHlsZS5yZW1vdmVQcm9wZXJ0eSgnZGlzcGxheScpO1xuICAgIGlmIChwcmV2aW91c0RpbWVuc2lvbnMpIHtcbiAgICAgIHNldFByZXZpb3VzQ29udGVudERpbWVuc2lvbnMocHJldmlvdXNEaW1lbnNpb25zKTtcbiAgICB9XG4gIH0pO1xuICBjb25zdCBhcm1WaWV3cG9ydENsZWFudXAgPSB1c2VTdGFibGVDYWxsYmFjaygoKSA9PiB7XG4gICAgY2xlYW51cENvbnRyb2xsZXJSZWYuY3VycmVudD8uYWJvcnQoKTtcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIGNsZWFudXBDb250cm9sbGVyUmVmLmN1cnJlbnQgPSBjb250cm9sbGVyO1xuICAgIG9uQW5pbWF0aW9uc0ZpbmlzaGVkKCgpID0+IHtcbiAgICAgIHNldFByZXZpb3VzQ29udGVudE5vZGUobnVsbCk7XG4gICAgICBzZXRQcmV2aW91c0NvbnRlbnREaW1lbnNpb25zKG51bGwpO1xuICAgICAgY2FwdHVyZWROb2RlUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH0sIGNvbnRyb2xsZXIuc2lnbmFsKTtcbiAgfSk7XG4gIGNvbnN0IGxhc3RIYW5kbGVkVHJpZ2dlclJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW9wZW4gfHwgIW1vdW50ZWQpIHtcbiAgICAgIGxhc3RIYW5kbGVkVHJpZ2dlclJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gIH0sIFtvcGVuLCBtb3VudGVkXSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgLy8gV2hlbiBhIHRyaWdnZXIgY2hhbmdlcywgc2V0IHRoZSBjYXB0dXJlZCBjaGlsZHJlbiBIVE1MIHRvIHN0YXRlLFxuICAgIC8vIHNvIHdlIGNhbiByZW5kZXIgYm90aCBuZXcgYW5kIG9sZCBjb250ZW50LlxuICAgIC8vIGBwcmV2aW91c0FjdGl2ZVRyaWdnZXJgIGtlZXBzIHRoZSBsYXN0IG9wZW4gdHJpZ2dlciB3aGlsZSBjbG9zZWQsIHNvIGEgdHJpZ2dlciB0aGF0XG4gICAgLy8gcmVtb3VudHMgd2hpbGUgdGhlIHBvcHVwIGlzIGNsb3NlZCBtdXN0IG5vdCBzdGFydCBhIHRyYW5zaXRpb24uXG4gICAgaWYgKG9wZW4gJiYgYWN0aXZlVHJpZ2dlciAmJiBwcmV2aW91c0FjdGl2ZVRyaWdnZXIgJiYgYWN0aXZlVHJpZ2dlciAhPT0gcHJldmlvdXNBY3RpdmVUcmlnZ2VyICYmIGxhc3RIYW5kbGVkVHJpZ2dlclJlZi5jdXJyZW50ICE9PSBhY3RpdmVUcmlnZ2VyICYmIGNhcHR1cmVkTm9kZVJlZi5jdXJyZW50KSB7XG4gICAgICBzZXRQcmV2aW91c0NvbnRlbnROb2RlKGNhcHR1cmVkTm9kZVJlZi5jdXJyZW50KTtcbiAgICAgIHNldFNob3dTdGFydGluZ1N0eWxlQXR0cmlidXRlKHRydWUpO1xuXG4gICAgICAvLyBDYWxjdWxhdGUgdGhlIHJlbGF0aXZlIHBvc2l0aW9uIGJldHdlZW4gdGhlIHByZXZpb3VzIGFuZCBuZXcgdHJpZ2dlcixcbiAgICAgIC8vIHNvIHdlIGNhbiBwYXNzIGl0IHRvIHRoZSBzdHlsZSBob29rIGZvciBhbmltYXRpb24gcHVycG9zZXMuXG4gICAgICBjb25zdCBvZmZzZXQgPSBjYWxjdWxhdGVSZWxhdGl2ZVBvc2l0aW9uKHByZXZpb3VzQWN0aXZlVHJpZ2dlciwgYWN0aXZlVHJpZ2dlcik7XG4gICAgICBzZXROZXdUcmlnZ2VyT2Zmc2V0KG9mZnNldCk7XG4gICAgICBsYXN0SGFuZGxlZFRyaWdnZXJSZWYuY3VycmVudCA9IGFjdGl2ZVRyaWdnZXI7XG4gICAgfVxuICB9LCBbb3BlbiwgYWN0aXZlVHJpZ2dlciwgcHJldmlvdXNBY3RpdmVUcmlnZ2VyXSk7XG5cbiAgLy8gQXJtIGNsZWFudXAgYWZ0ZXIgYSB0cmlnZ2VyIGNoYW5nZSwgYW5kIHJlLWFybSBpdCBpZiB0aGUgY3VycmVudCBjb250YWluZXIgcmVtb3VudHNcbiAgLy8gbWlkLXRyYW5zaXRpb24gd2hlbiBhIGxhZ2dpbmcgcGF5bG9hZCBidW1wcyBgY3VycmVudENvbnRlbnRLZXlgLiBUaGUgcmVtb3VudCBkaXNjYXJkc1xuICAvLyB0aGUgcnVubmluZyBlbnRyeSBhbmltYXRpb24gKGFuZCB3aXRoIHRyYW5zaXRpb24tc3R5bGUgQ1NTIHRoZSByZXBsYWNlbWVudCBtb3VudHMgYXRcbiAgLy8gZmluYWwgc3R5bGVzIHdpdGggbm8gYW5pbWF0aW9uIGF0IGFsbCksIHNvIHJlLXJ1biB0aGUgc3RhcnRpbmctc3R5bGUgY2hvcmVvZ3JhcGh5IOKAlFxuICAvLyBvdGhlcndpc2UgdGhlIHdhdGNoZXIgZWl0aGVyIHN0cmFuZHMgb3IgZmlyZXMgYmVmb3JlIHRoZSBwcmV2aW91cyBjb250YWluZXIncyBleGl0XG4gIC8vIGFuaW1hdGlvbiBmaW5pc2hlcy5cbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAocHJldmlvdXNDb250ZW50Tm9kZSA9PSBudWxsKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gQWJvcnQgdGhlIHN0YWxlIHdhdGNoZXIgc3luY2hyb25vdXNseS4gVGhlIHJlbW91bnQgY2FuY2VscyB0aGUgb2xkIGNvbnRhaW5lcidzXG4gICAgLy8gYW5pbWF0aW9ucywgYW5kIHRoZSByZXN1bHRpbmcgcHJvbWlzZSByZWplY3Rpb24gd291bGQgb3RoZXJ3aXNlIHJ1biB0aGUgY2xlYW51cFxuICAgIC8vIGluIGEgbWljcm90YXNrIGJlZm9yZSB0aGUgcmUtYXJtZWQgd2F0Y2hlciBiZWxvdyBpcyBpbiBwbGFjZS5cbiAgICBjbGVhbnVwQ29udHJvbGxlclJlZi5jdXJyZW50Py5hYm9ydCgpO1xuICAgIHNldFNob3dTdGFydGluZ1N0eWxlQXR0cmlidXRlKHRydWUpO1xuICAgIGNsZWFudXBGcmFtZS5yZXF1ZXN0KCgpID0+IHtcbiAgICAgIFJlYWN0RE9NLmZsdXNoU3luYygoKSA9PiB7XG4gICAgICAgIHNldFNob3dTdGFydGluZ1N0eWxlQXR0cmlidXRlKGZhbHNlKTtcbiAgICAgIH0pO1xuICAgICAgYXJtVmlld3BvcnRDbGVhbnVwKCk7XG4gICAgfSk7XG4gIH0sIFtjdXJyZW50Q29udGVudEtleSwgcHJldmlvdXNDb250ZW50Tm9kZSwgYXJtVmlld3BvcnRDbGVhbnVwLCBjbGVhbnVwRnJhbWVdKTtcblxuICAvLyBDYXB0dXJlIGEgY2xvbmUgb2YgdGhlIGN1cnJlbnQgY29udGVudCBET00gc3VidHJlZSB3aGVuIG5vdCB0cmFuc2l0aW9uaW5nLlxuICAvLyBXZSBjYW4ndCBzdG9yZSBwcmV2aW91cyBSZWFjdCBub2RlcyBhcyB0aGV5IG1heSBiZSBzdGF0ZWZ1bDsgaW5zdGVhZCB3ZSBjYXB0dXJlIERPTSBjbG9uZXMgZm9yIHZpc3VhbCBjb250aW51aXR5LlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIC8vIFdoZW4gYSB0cmFuc2l0aW9uIGlzIGluIHByb2dyZXNzLCB3ZSBzdG9yZSB0aGUgbmV4dCBjb250ZW50IGluIGNhcHR1cmVkTm9kZVJlZi5cbiAgICAvLyBUaGlzIGhhbmRsZXMgdGhlIGNhc2Ugd2hlcmUgdGhlIHRyaWdnZXIgY2hhbmdlcyBtdWx0aXBsZSB0aW1lcyBiZWZvcmUgdGhlIHRyYW5zaXRpb24gZmluaXNoZXMuXG4gICAgLy8gV2Ugd2FudCB0byBhbHdheXMgY2FwdHVyZSB0aGUgbGF0ZXN0IGNvbnRlbnQgZm9yIHRoZSBwcmV2aW91cyBzbmFwc2hvdC5cbiAgICAvLyBTbyBjbGlja2luZyBxdWlja2x5IG9uIFQxLCBUMiwgVDMgd2lsbCByZXN1bHQgaW4gdGhlIGZvbGxvd2luZyBzZXF1ZW5jZTpcbiAgICAvLyAxLiBUMSAtPiBUMjogcHJldmlvdXNDb250ZW50ID0gVDEsIGN1cnJlbnRDb250ZW50ID0gVDJcbiAgICAvLyAyLiBUMiAtPiBUMzogcHJldmlvdXNDb250ZW50ID0gVDIsIGN1cnJlbnRDb250ZW50ID0gVDNcbiAgICBjb25zdCBzb3VyY2UgPSBjdXJyZW50Q29udGFpbmVyUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFzb3VyY2UpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgd3JhcHBlciA9IG93bmVyRG9jdW1lbnQoc291cmNlKS5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBmb3IgKGNvbnN0IGNoaWxkIG9mIEFycmF5LmZyb20oc291cmNlLmNoaWxkTm9kZXMpKSB7XG4gICAgICB3cmFwcGVyLmFwcGVuZENoaWxkKGNoaWxkLmNsb25lTm9kZSh0cnVlKSk7XG4gICAgfVxuICAgIGNhcHR1cmVkTm9kZVJlZi5jdXJyZW50ID0gd3JhcHBlcjtcbiAgfSk7XG4gIGNvbnN0IGlzVHJhbnNpdGlvbmluZyA9IHByZXZpb3VzQ29udGVudE5vZGUgIT0gbnVsbDtcbiAgbGV0IGNoaWxkcmVuVG9SZW5kZXI7XG4gIGlmICghaXNUcmFuc2l0aW9uaW5nKSB7XG4gICAgY2hpbGRyZW5Ub1JlbmRlciA9IC8qI19fUFVSRV9fKi9fanN4KFwiZGl2XCIsIHtcbiAgICAgIFwiZGF0YS1jdXJyZW50XCI6IHRydWUsXG4gICAgICByZWY6IGN1cnJlbnRDb250YWluZXJSZWYsXG4gICAgICBjaGlsZHJlbjogY2hpbGRyZW5cbiAgICB9LCBjdXJyZW50Q29udGVudEtleSk7XG4gIH0gZWxzZSB7XG4gICAgY2hpbGRyZW5Ub1JlbmRlciA9IC8qI19fUFVSRV9fKi9fanN4cyhSZWFjdC5GcmFnbWVudCwge1xuICAgICAgY2hpbGRyZW46IFsvKiNfX1BVUkVfXyovX2pzeChcImRpdlwiLCB7XG4gICAgICAgIFwiZGF0YS1wcmV2aW91c1wiOiB0cnVlLFxuICAgICAgICBpbmVydDogaW5lcnRWYWx1ZSh0cnVlKSxcbiAgICAgICAgcmVmOiBwcmV2aW91c0NvbnRhaW5lclJlZixcbiAgICAgICAgc3R5bGU6IHtcbiAgICAgICAgICAuLi4ocHJldmlvdXNDb250ZW50RGltZW5zaW9ucyA/IHtcbiAgICAgICAgICAgIFtDb21tb25Qb3B1cENzc1ZhcnMucG9wdXBXaWR0aF06IGAke3ByZXZpb3VzQ29udGVudERpbWVuc2lvbnMud2lkdGh9cHhgLFxuICAgICAgICAgICAgW0NvbW1vblBvcHVwQ3NzVmFycy5wb3B1cEhlaWdodF06IGAke3ByZXZpb3VzQ29udGVudERpbWVuc2lvbnMuaGVpZ2h0fXB4YFxuICAgICAgICAgIH0gOiBudWxsKSxcbiAgICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJ1xuICAgICAgICB9LFxuICAgICAgICBcImRhdGEtZW5kaW5nLXN0eWxlXCI6IHNob3dTdGFydGluZ1N0eWxlQXR0cmlidXRlID8gdW5kZWZpbmVkIDogJydcbiAgICAgIH0sIFwicHJldmlvdXNcIiksIC8qI19fUFVSRV9fKi9fanN4KFwiZGl2XCIsIHtcbiAgICAgICAgXCJkYXRhLWN1cnJlbnRcIjogdHJ1ZSxcbiAgICAgICAgcmVmOiBjdXJyZW50Q29udGFpbmVyUmVmLFxuICAgICAgICBcImRhdGEtc3RhcnRpbmctc3R5bGVcIjogc2hvd1N0YXJ0aW5nU3R5bGVBdHRyaWJ1dGUgPyAnJyA6IHVuZGVmaW5lZCxcbiAgICAgICAgY2hpbGRyZW46IGNoaWxkcmVuXG4gICAgICB9LCBjdXJyZW50Q29udGVudEtleSldXG4gICAgfSk7XG4gIH1cblxuICAvLyBXaGVuIHByZXZpb3VzQ29udGVudE5vZGUgaXMgcHJlc2VudCwgaW1wZXJhdGl2ZWx5IHBvcHVsYXRlIHRoZSBwcmV2aW91cyBjb250YWluZXIgd2l0aCB0aGUgY2xvbmVkIGNoaWxkcmVuLlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGNvbnRhaW5lciA9IHByZXZpb3VzQ29udGFpbmVyUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFjb250YWluZXIgfHwgIXByZXZpb3VzQ29udGVudE5vZGUpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29udGFpbmVyLnJlcGxhY2VDaGlsZHJlbiguLi5BcnJheS5mcm9tKHByZXZpb3VzQ29udGVudE5vZGUuY2hpbGROb2RlcykpO1xuICB9LCBbcHJldmlvdXNDb250ZW50Tm9kZV0pO1xuICB1c2VQb3B1cEF1dG9SZXNpemUoe1xuICAgIHBvcHVwRWxlbWVudCxcbiAgICBwb3NpdGlvbmVyRWxlbWVudCxcbiAgICBtb3VudGVkLFxuICAgIGNvbnRlbnQ6IHBheWxvYWQsXG4gICAgb25NZWFzdXJlTGF5b3V0OiBoYW5kbGVNZWFzdXJlTGF5b3V0LFxuICAgIG9uTWVhc3VyZUxheW91dENvbXBsZXRlOiBoYW5kbGVNZWFzdXJlTGF5b3V0Q29tcGxldGUsXG4gICAgc2lkZSxcbiAgICBkaXJlY3Rpb25cbiAgfSk7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIGFjdGl2YXRpb25EaXJlY3Rpb246IGdldEFjdGl2YXRpb25EaXJlY3Rpb24obmV3VHJpZ2dlck9mZnNldCksXG4gICAgdHJhbnNpdGlvbmluZzogaXNUcmFuc2l0aW9uaW5nXG4gIH07XG4gIHJldHVybiB7XG4gICAgY2hpbGRyZW46IGNoaWxkcmVuVG9SZW5kZXIsXG4gICAgc3RhdGVcbiAgfTtcbn1cbi8qKlxuICogUmV0dXJucyBhIHN0cmluZyBkZXNjcmliaW5nIHRoZSBwcm92aWRlZCBvZmZzZXQuXG4gKiBJdCBkZXNjcmliZXMgYm90aCB0aGUgaG9yaXpvbnRhbCBhbmQgdmVydGljYWwgb2Zmc2V0LCBzZXBhcmF0ZWQgYnkgYSBzcGFjZS5cbiAqXG4gKiBAcGFyYW0gb2Zmc2V0XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRBY3RpdmF0aW9uRGlyZWN0aW9uKG9mZnNldCkge1xuICBpZiAoIW9mZnNldCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIGAke2dldFZhbHVlV2l0aFRvbGVyYW5jZShvZmZzZXQuaG9yaXpvbnRhbCwgNSwgJ3JpZ2h0JywgJ2xlZnQnKX0gJHtnZXRWYWx1ZVdpdGhUb2xlcmFuY2Uob2Zmc2V0LnZlcnRpY2FsLCA1LCAnZG93bicsICd1cCcpfWA7XG59XG5cbi8qKlxuICogUmV0dXJucyBhIGxhYmVsIGRlc2NyaWJpbmcgdGhlIHZhbHVlIChwb3NpdGl2ZS9uZWdhdGl2ZSkgdHJlYXRpbmcgdmFsdWVzXG4gKiB3aXRoaW4gdG9sZXJhbmNlIGFzIHplcm8uXG4gKlxuICogQHBhcmFtIHZhbHVlIFZhbHVlIHRvIGNoZWNrXG4gKiBAcGFyYW0gdG9sZXJhbmNlIFRvbGVyYW5jZSB0byB0cmVhdCB0aGUgdmFsdWUgYXMgemVyby5cbiAqIEBwYXJhbSBwb3NpdGl2ZUxhYmVsXG4gKiBAcGFyYW0gbmVnYXRpdmVMYWJlbFxuICogQHJldHVybnMgSWYgMCA8IGFicyh2YWx1ZSkgPCB0b2xlcmFuY2UsIHJldHVybnMgYW4gZW1wdHkgc3RyaW5nLiBPdGhlcndpc2UgcmV0dXJucyBwb3NpdGl2ZUxhYmVsIG9yIG5lZ2F0aXZlTGFiZWwuXG4gKi9cbmZ1bmN0aW9uIGdldFZhbHVlV2l0aFRvbGVyYW5jZSh2YWx1ZSwgdG9sZXJhbmNlLCBwb3NpdGl2ZUxhYmVsLCBuZWdhdGl2ZUxhYmVsKSB7XG4gIGlmICh2YWx1ZSA+IHRvbGVyYW5jZSkge1xuICAgIHJldHVybiBwb3NpdGl2ZUxhYmVsO1xuICB9XG4gIGlmICh2YWx1ZSA8IC10b2xlcmFuY2UpIHtcbiAgICByZXR1cm4gbmVnYXRpdmVMYWJlbDtcbiAgfVxuICByZXR1cm4gJyc7XG59XG5cbi8qKlxuICogQ2FsY3VsYXRlcyB0aGUgcmVsYXRpdmUgcG9zaXRpb24gYmV0d2VlbiBjZW50ZXJzIG9mIHR3byBlbGVtZW50cy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNhbGN1bGF0ZVJlbGF0aXZlUG9zaXRpb24oZnJvbSwgdG8pIHtcbiAgY29uc3QgZnJvbVJlY3QgPSBmcm9tLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICBjb25zdCB0b1JlY3QgPSB0by5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgY29uc3QgZnJvbUNlbnRlciA9IHtcbiAgICB4OiBmcm9tUmVjdC5sZWZ0ICsgZnJvbVJlY3Qud2lkdGggLyAyLFxuICAgIHk6IGZyb21SZWN0LnRvcCArIGZyb21SZWN0LmhlaWdodCAvIDJcbiAgfTtcbiAgY29uc3QgdG9DZW50ZXIgPSB7XG4gICAgeDogdG9SZWN0LmxlZnQgKyB0b1JlY3Qud2lkdGggLyAyLFxuICAgIHk6IHRvUmVjdC50b3AgKyB0b1JlY3QuaGVpZ2h0IC8gMlxuICB9O1xuICByZXR1cm4ge1xuICAgIGhvcml6b250YWw6IHRvQ2VudGVyLnggLSBmcm9tQ2VudGVyLngsXG4gICAgdmVydGljYWw6IHRvQ2VudGVyLnkgLSBmcm9tQ2VudGVyLnlcbiAgfTtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEga2V5IHRoYXQgZm9yY2VzIHJlbW91bnRpbmcgY29udGVudCB3aGVuIHRyaWdnZXJzIGNoYW5nZSBvciBhIHBheWxvYWQgaXMgdXBkYXRlZC5cbiAqL1xuZnVuY3Rpb24gdXNlUG9wdXBDb250ZW50S2V5KGFjdGl2ZVRyaWdnZXJJZCwgcGF5bG9hZCkge1xuICBjb25zdCBbY29udGVudEtleSwgc2V0Q29udGVudEtleV0gPSBSZWFjdC51c2VTdGF0ZSgwKTtcbiAgY29uc3QgcHJldmlvdXNBY3RpdmVUcmlnZ2VySWRSZWYgPSBSZWFjdC51c2VSZWYoYWN0aXZlVHJpZ2dlcklkKTtcbiAgY29uc3QgcHJldmlvdXNQYXlsb2FkUmVmID0gUmVhY3QudXNlUmVmKHBheWxvYWQpO1xuICBjb25zdCBwZW5kaW5nUGF5bG9hZFVwZGF0ZVJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgLy8gQ29tcGFyZSBhZ2FpbnN0IHRoZSBsYXN0IGNvbW1pdHRlZCB2YWx1ZXMgdG8gZGVjaWRlIHdoZXRoZXIgd2UgbmVlZCBhIG5ldyBET00gc3VidHJlZS5cbiAgICBjb25zdCBwcmV2aW91c0FjdGl2ZVRyaWdnZXJJZCA9IHByZXZpb3VzQWN0aXZlVHJpZ2dlcklkUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgcHJldmlvdXNQYXlsb2FkID0gcHJldmlvdXNQYXlsb2FkUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgdHJpZ2dlcklkQ2hhbmdlZCA9IGFjdGl2ZVRyaWdnZXJJZCAhPT0gcHJldmlvdXNBY3RpdmVUcmlnZ2VySWQ7XG4gICAgY29uc3QgcGF5bG9hZENoYW5nZWQgPSBwYXlsb2FkICE9PSBwcmV2aW91c1BheWxvYWQ7XG4gICAgaWYgKHRyaWdnZXJJZENoYW5nZWQpIHtcbiAgICAgIC8vIFJlbW91bnQgaW1tZWRpYXRlbHkgb24gdHJpZ2dlciBjaGFuZ2U7IHJlbWVtYmVyIGlmIHBheWxvYWQgaGFzbid0IGNhdWdodCB1cCB5ZXQuXG4gICAgICBzZXRDb250ZW50S2V5KHZhbHVlID0+IHZhbHVlICsgMSk7XG4gICAgICBwZW5kaW5nUGF5bG9hZFVwZGF0ZVJlZi5jdXJyZW50ID0gIXBheWxvYWRDaGFuZ2VkO1xuICAgIH0gZWxzZSBpZiAocGVuZGluZ1BheWxvYWRVcGRhdGVSZWYuY3VycmVudCAmJiBwYXlsb2FkQ2hhbmdlZCkge1xuICAgICAgLy8gUGF5bG9hZCBhcnJpdmVkIGEgcmVuZGVyIGxhdGVyLCBzbyByZW1vdW50IG9uY2UgbW9yZSB0byBhdm9pZCByZXVzaW5nIHRoZSBvbGQgPGltZz4uXG4gICAgICBzZXRDb250ZW50S2V5KHZhbHVlID0+IHZhbHVlICsgMSk7XG4gICAgICBwZW5kaW5nUGF5bG9hZFVwZGF0ZVJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgfVxuXG4gICAgLy8gUGVyc2lzdCBjdXJyZW50IHZhbHVlcyBmb3IgdGhlIG5leHQgcmVuZGVyJ3MgY29tcGFyaXNvbi5cbiAgICBwcmV2aW91c0FjdGl2ZVRyaWdnZXJJZFJlZi5jdXJyZW50ID0gYWN0aXZlVHJpZ2dlcklkO1xuICAgIHByZXZpb3VzUGF5bG9hZFJlZi5jdXJyZW50ID0gcGF5bG9hZDtcbiAgfSwgW2FjdGl2ZVRyaWdnZXJJZCwgcGF5bG9hZF0pO1xuICByZXR1cm4gYCR7YWN0aXZlVHJpZ2dlcklkID8/ICdjdXJyZW50J30tJHtjb250ZW50S2V5fWA7XG59Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVBLFNBQVMsYUFBYSxPQUFPLGFBQWE7Q0FDeEMsSUFBSSxlQUFlLFFBQVEsQ0FBQyx1QkFBdUIsV0FBVyxHQUM1RCxPQUFPO0NBRVQsSUFBSSxPQUFPLFVBQVUsWUFDbkIsT0FBTyxNQUFNO0NBRWYsT0FBTztBQUNUO0FBQ0EsU0FBZ0IsU0FBUyxPQUFPLE1BQU0sYUFBYTtDQUNqRCxNQUFNLFNBQVMsYUFBYSxPQUFPLFdBQVc7Q0FDOUMsSUFBSSxPQUFPLFdBQVcsVUFDcEIsT0FBTztDQUVULE9BQU8sU0FBUztBQUNsQjtBQUNBLFNBQWdCLFVBQVUsT0FBTztDQUMvQixJQUFJLE9BQU8sVUFBVSxZQUNuQixPQUFPLE1BQU07Q0FFZixPQUFPO0FBQ1Q7QUFDQSxTQUFnQixxQkFBcUIsZUFBZSxrQkFBa0I7Q0FDcEUsT0FBTyxvQkFBb0Isa0JBQWtCLFdBQVcsa0JBQWtCO0FBQzVFO0FBQ0EsU0FBZ0IsaUJBQWlCLGVBQWU7Q0FDOUMsT0FBTyxlQUFlLFNBQVMsT0FBTyxLQUFLLGtCQUFrQjtBQUMvRDs7QUNoQkEsSUFBTSxjQUFjQSxPQUFtQkM7Ozs7OztBQU12QyxTQUFnQixTQUFTLE9BQU8sUUFBUSxDQUFDLEdBQUc7Q0FDMUMsTUFBTSxFQUNKLFVBQVUsTUFDVixVQUNFO0NBQ0osTUFBTSxFQUNKLFFBQ0EsWUFDRSxNQUFNO0NBQ1YsTUFBTSxnQkFBQSxhQUFzQixPQUFPLEtBQUs7Q0FFeEMsTUFBTSxzQkFBQSxhQUE0QixPQUFPLElBQUk7Q0FDN0MsTUFBTSxzQkFBQSxhQUE0QixPQUFPLElBQUk7Q0FDN0MsTUFBTSxVQUFVLFdBQVc7Q0FDM0IsYUFBTSxnQkFBZ0I7RUFDcEIsTUFBTSxlQUFlLE1BQU0sT0FBTyxxQkFBcUI7RUFDdkQsSUFBSSxDQUFDLFNBQ0g7RUFFRixNQUFNLE1BQU0sVUFBVSxZQUFZO0VBS2xDLFNBQVMsU0FBUztHQUNoQixNQUFNLHNCQUFzQixNQUFNLE9BQU8scUJBQXFCO0dBQzlELElBQUksQ0FBQyxNQUFNLE9BQU8sTUFBTSxLQUFLLGNBQWMsbUJBQW1CLEtBQUssd0JBQXdCLGNBQWMsY0FBYyxtQkFBbUIsQ0FBQyxHQUFHO0lBQzVJLGNBQWMsVUFBVTtJQUN4QixvQkFBb0IsVUFBVTtHQUNoQztFQUNGO0VBQ0EsU0FBUyxZQUFZO0dBQ25CLG9CQUFvQixVQUFVO0VBQ2hDO0VBQ0EsU0FBUyxnQkFBZ0I7R0FDdkIsb0JBQW9CLFVBQVU7RUFDaEM7RUFDQSxPQUFPLGNBQWMsaUJBQWlCLEtBQUssUUFBUSxNQUFNLEdBQUcsZUFBZSxpQkFBaUIsS0FBSyxXQUFXLFdBQVcsSUFBSSxHQUFHLGVBQWUsaUJBQWlCLEtBQUssZUFBZSxlQUFlLElBQUksQ0FBQztDQUN4TSxHQUFHLENBQUMsT0FBTyxPQUFPLENBQUM7Q0FDbkIsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxDQUFDLFNBQ0g7RUFFRixTQUFTLGtCQUFrQixTQUFTO0dBQ2xDLElBQUksUUFBUSxXQUFXLG1CQUF3QixRQUFRLFdBQVcsY0FBbUI7SUFDbkYsTUFBTSxtQkFBbUIsTUFBTSxPQUFPLHFCQUFxQjtJQUMzRCxJQUFJLFVBQVUsZ0JBQWdCLEdBQUc7S0FDL0Isb0JBQW9CLFVBQVU7S0FDOUIsY0FBYyxVQUFVO0lBQzFCO0dBQ0Y7RUFDRjtFQUNBLE9BQU8sR0FBRyxjQUFjLGlCQUFpQjtFQUN6QyxhQUFhO0dBQ1gsT0FBTyxJQUFJLGNBQWMsaUJBQWlCO0VBQzVDO0NBQ0YsR0FBRztFQUFDO0VBQVE7RUFBUztDQUFLLENBQUM7Q0FDM0IsTUFBTSxZQUFBLGFBQWtCLGNBQWM7RUFDcEMsU0FBUyxvQkFBb0I7R0FDM0IsY0FBYyxVQUFVO0dBQ3hCLG9CQUFvQixVQUFVO0VBQ2hDO0VBQ0EsT0FBTztHQUNMLGVBQWU7SUFDYixrQkFBa0I7R0FDcEI7R0FDQSxRQUFRLE9BQU87SUFDYixNQUFNLGNBQWMsTUFBTTtJQUMxQixJQUFJLGNBQWMsU0FBUztLQUN6QixJQUFJLG9CQUFvQixZQUFZLGFBQ2xDO0tBRUYsa0JBQWtCO0lBQ3BCO0lBQ0EsTUFBTSxTQUFTLFVBQVUsTUFBTSxXQUFXO0lBQzFDLElBQUksVUFBVSxNQUFNLEdBQUc7S0FHckIsSUFBSSxlQUFlLENBQUMsTUFBTSxlQUNwQjtVQUFBLENBQUMsb0JBQW9CLFdBQVcsQ0FBQyxrQkFBa0IsTUFBTSxHQUMzRDtLQUFBLE9BRUcsSUFBSSxDQUFDLG9CQUFvQixNQUFNLEdBQ3BDO0lBRUo7SUFDQSxNQUFNLCtCQUErQiw2QkFBNkIsTUFBTSxlQUFlLE1BQU0sUUFBUSxlQUFlO0lBQ3BILE1BQU0sRUFDSixhQUNBLGtCQUNFO0lBQ0osSUFBSSxNQUFNLE9BQU8sTUFBTSxLQUFLLGdDQUFnQyxDQUFDLE9BQU87S0FDbEUsTUFBTSxRQUFRLE1BQU0seUJBQXlCQyxjQUFzQixhQUFhLGFBQWEsQ0FBQztLQUM5RjtJQUNGO0lBQ0EsUUFBUSxNQUFNLGFBQWE7S0FDekIsSUFBSSxjQUFjLFNBQ2hCO0tBRUYsTUFBTSxRQUFRLE1BQU0seUJBQXlCQSxjQUFzQixhQUFhLGFBQWEsQ0FBQztJQUNoRyxDQUFDO0dBQ0g7R0FDQSxPQUFPLE9BQU87SUFDWixrQkFBa0I7SUFDbEIsTUFBTSxnQkFBZ0IsTUFBTTtJQUM1QixNQUFNLGNBQWMsTUFBTTtJQUkxQixNQUFNLG9CQUFvQixVQUFVLGFBQWEsS0FBSyxjQUFjLGFBQWEsZ0JBQWdCLGFBQWEsQ0FBQyxLQUFLLGNBQWMsYUFBYSxXQUFXLE1BQU07SUFHaEssUUFBUSxNQUFNLFNBQVM7S0FDckIsTUFBTSxlQUFlLE1BQU0sT0FBTyxxQkFBcUI7S0FDdkQsTUFBTSxXQUFXLGNBQWMsY0FBYyxZQUFZLENBQUM7S0FHMUQsSUFBSSxDQUFDLGlCQUFpQixhQUFhLGNBQ2pDO0tBVUYsSUFBSSxTQUFTLFFBQVEsUUFBUSxpQkFBaUIsS0FBSyxTQUFTLFNBQVMsUUFBUSxLQUFLLFNBQVMsY0FBYyxRQUFRLEtBQUssbUJBQ3BIO0tBT0YsSUFBSSw2QkFEdUIsaUJBQWlCLFVBQ1MsTUFBTSxRQUFRLGVBQWUsR0FDaEY7S0FFRixNQUFNLFFBQVEsT0FBTyx5QkFBeUJBLGNBQXNCLFdBQVcsQ0FBQztJQUNsRixDQUFDO0dBQ0g7RUFDRjtDQUNGLEdBQUc7RUFBQztFQUFTO0VBQU87RUFBTztDQUFPLENBQUM7Q0FDbkMsT0FBQSxhQUFhLGNBQWMsVUFBVTtFQUNuQztFQUNBLFNBQVM7Q0FDWCxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsU0FBUyxDQUFDO0FBQzlCOztBQ2hLQSxJQUFhLG1CQUFiLE1BQWEsaUJBQWlCO0NBQzVCLGNBQWMsS0FBQTtDQUNkLG1CQUFtQjtDQUNuQixVQUFVLEtBQUE7Q0FDVixpQkFBaUI7Q0FDakIsaUNBQWlDO0NBQ2pDLDRCQUE0QjtDQUM1QixnQ0FBZ0M7Q0FDaEMsK0JBQStCO0NBQy9CLHFCQUFxQjtDQUNyQixvQkFBb0IsSUFBSSxRQUFRO0NBQ2hDLGNBQWMsSUFBSSxRQUFRO0NBQzFCLHFCQUFxQixLQUFBO0NBQ3JCLE9BQU8sU0FBUztFQUNkLE9BQU8sSUFBSSxpQkFBaUI7Q0FDOUI7Q0FDQSxnQkFBZ0I7RUFDZCxLQUFLLGtCQUFrQixNQUFNO0VBQzdCLEtBQUssWUFBWSxNQUFNO0NBQ3pCO0NBQ0Esc0JBQXNCO0VBQ3BCLE9BQU8sS0FBSztDQUNkO0FBQ0Y7QUFDQSxJQUFNLDJEQUEyQyxJQUFJLFFBQVE7QUFDN0QsU0FBZ0Isc0NBQXNDLFVBQVU7Q0FDOUQsSUFBSSxDQUFDLFNBQVMsZ0NBQ1o7Q0FFRixNQUFNLGVBQWUsU0FBUztDQUM5QixJQUFJLGdCQUFnQix5Q0FBeUMsSUFBSSxZQUFZLE1BQU0sVUFBVTtFQUMzRixTQUFTLDJCQUEyQixNQUFNLGVBQWUsZ0JBQWdCO0VBQ3pFLFNBQVMsK0JBQStCLE1BQU0sZUFBZSxnQkFBZ0I7RUFDN0UsU0FBUyw4QkFBOEIsTUFBTSxlQUFlLGdCQUFnQjtFQUM1RSx5Q0FBeUMsT0FBTyxZQUFZO0NBQzlEO0NBQ0EsU0FBUyxpQ0FBaUM7Q0FDMUMsU0FBUyw0QkFBNEI7Q0FDckMsU0FBUyxnQ0FBZ0M7Q0FDekMsU0FBUywrQkFBK0I7QUFDMUM7QUFDQSxTQUFnQixzQ0FBc0MsVUFBVSxTQUFTO0NBQ3ZFLE1BQU0sRUFDSixjQUNBLGtCQUNBLG9CQUNFO0NBQ0osTUFBTSxnQkFBZ0IseUNBQXlDLElBQUksWUFBWTtDQUMvRSxJQUFJLGlCQUFpQixrQkFBa0IsVUFDckMsc0NBQXNDLGFBQWE7Q0FFckQsc0NBQXNDLFFBQVE7Q0FDOUMsU0FBUyxpQ0FBaUM7Q0FDMUMsU0FBUyw0QkFBNEI7Q0FDckMsU0FBUyxnQ0FBZ0M7Q0FDekMsU0FBUywrQkFBK0I7Q0FDeEMseUNBQXlDLElBQUksY0FBYyxRQUFRO0NBQ25FLGFBQWEsTUFBTSxnQkFBZ0I7Q0FDbkMsaUJBQWlCLE1BQU0sZ0JBQWdCO0NBQ3ZDLGdCQUFnQixNQUFNLGdCQUFnQjtBQUN4QztBQUNBLFNBQWdCLCtCQUErQixPQUFPO0NBQ3BELE1BQU0sT0FBTyxNQUFNLFFBQVEsUUFBUTtDQUNuQyxNQUFNLFdBQVcscUJBQXFCLEtBQUsseUJBQXlCLGlCQUFpQixPQUFPLENBQUMsQ0FBQyxDQUFDO0NBQy9GLElBQUksQ0FBQyxLQUFLLHVCQUNSLEtBQUssd0JBQXdCO0NBRS9CLFdBQVcsS0FBSyxzQkFBc0IsYUFBYTtDQUNuRCxPQUFPLEtBQUs7QUFDZDs7Ozs7QUN4REEsU0FBZ0IsNEJBQTRCLE9BQU8sYUFBYSxDQUFDLEdBQUc7Q0FDbEUsTUFBTSxFQUNKLFVBQVUsTUFDVixZQUFZLGlCQUFpQixHQUM3QixRQUFRLGVBQ047Q0FDSixNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLGlCQUFpQjtDQUN4RCxNQUFNLHNCQUFzQixNQUFNLFNBQVMscUJBQXFCO0NBQ2hFLE1BQU0sRUFDSixZQUNFLE1BQU07Q0FDVixNQUFNLE9BQU8sZ0JBQWdCO0NBQzdCLE1BQU0sV0FBVyx3QkFBd0I7Q0FDekMsTUFBTSxXQUFXLCtCQUErQixLQUFLO0NBQ3JELE1BQU0scUJBQXFCLFdBQVc7Q0FDdEMsTUFBTUMseUJBQXVCLHdCQUF3QjtFQUNuRCxPQUFPQyxxQkFBMkIsUUFBUSxRQUFRLFdBQVcsTUFBTSxTQUFTLGdCQUFnQjtDQUM5RixDQUFDO0NBQ0QsTUFBTSxjQUFjLHdCQUF3QjtFQUMxQyxPQUFPLGlCQUFpQixRQUFRLFFBQVEsV0FBVyxJQUFJO0NBQ3pELENBQUM7Q0FDRCxNQUFNLHFCQUFxQix3QkFBd0I7RUFDakQsc0NBQXNDLFFBQVE7Q0FDaEQsQ0FBQztDQUNELHlCQUF5QjtFQUN2QixJQUFJLENBQUMsTUFBTTtHQUNULFNBQVMsY0FBYyxLQUFBO0dBQ3ZCLFNBQVMscUJBQXFCO0dBQzlCLFNBQVMsbUJBQW1CO0dBQzVCLG1CQUFtQjtFQUNyQjtDQUNGLEdBQUc7RUFBQztFQUFNO0VBQVU7Q0FBa0IsQ0FBQztDQUN2QyxhQUFNLGdCQUFnQjtFQUNwQixPQUFPO0NBQ1QsR0FBRyxDQUFDLGtCQUFrQixDQUFDO0NBQ3ZCLHlCQUF5QjtFQUN2QixJQUFJLENBQUMsU0FDSDtFQUVGLElBQUksUUFBUSxTQUFTLG9CQUFvQixzQkFBc0IsWUFBWSxLQUFLLFVBQVUsbUJBQW1CLEtBQUssaUJBQWlCO0dBQ2pJLE1BQU0sTUFBTTtHQUNaLE1BQU0sYUFBYTtHQUNuQixNQUFNLE1BQU0sY0FBYyxlQUFlO0dBQ3pDLE1BQU0saUJBQWlCLE1BQU0sU0FBUyxRQUFRLE1BQUssU0FBUSxLQUFLLE9BQU8sUUFBUSxDQUFDLEVBQUUsU0FBUyxTQUFTO0dBQ3BHLElBQUksZ0JBQ0YsZUFBZSxNQUFNLGdCQUFnQjtHQU12QyxNQUFNLHFCQUFxQixTQUFTLDhCQUE4QixhQUFhLFNBQVMsNEJBQTRCO0dBQ3BILE1BQU0scUJBQXFCLG1CQUFtQixhQUFhLGlCQUFpQjtHQUM1RSxNQUFNLGVBQWUsU0FBUyxvQkFBb0IsV0FBVyxLQUFLLHNCQUFzQixzQkFBc0IsUUFBUSxLQUFLLG9CQUFvQixLQUFLLElBQUk7R0FDeEosc0NBQXNDLFVBQVU7SUFDOUM7SUFDQSxrQkFBa0I7SUFDbEIsaUJBQWlCO0dBQ25CLENBQUM7R0FDRCxhQUFhO0lBQ1gsbUJBQW1CO0dBQ3JCO0VBQ0Y7Q0FFRixHQUFHO0VBQUM7RUFBUztFQUFNO0VBQXFCO0VBQWlCO0VBQVU7RUFBYTtFQUFNO0VBQVU7Q0FBa0IsQ0FBQztDQUNuSCxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLENBQUMsU0FDSDtFQUVGLFNBQVMsb0JBQW9CO0dBQzNCLE9BQU8sQ0FBQyxFQUFFLFFBQVEsWUFBWSxnQkFBZ0IsS0FBSyxTQUFTLFNBQVMsUUFBUSxDQUFDLENBQUMsU0FBUztFQUMxRjtFQUNBLFNBQVMsZUFBZSxPQUFPO0dBQzdCLE1BQU0sYUFBYSxTQUFTLGdCQUFnQixTQUFTLFNBQVMsV0FBVztHQUN6RSxNQUFNLGNBQWM7SUFDbEIsTUFBTSxRQUFRLE9BQU8seUJBQXlCQyxjQUFzQixLQUFLLENBQUM7SUFDMUUsTUFBTSxPQUFPLEtBQUssbUJBQW1CLEtBQUs7R0FDNUM7R0FDQSxJQUFJLFlBQ0YsU0FBUyxrQkFBa0IsTUFBTSxZQUFZLEtBQUs7UUFDN0M7SUFDTCxTQUFTLGtCQUFrQixNQUFNO0lBQ2pDLE1BQU07R0FDUjtFQUNGO0VBQ0EsU0FBUyxxQkFBcUIsT0FBTztHQUNuQyxNQUFNLFNBQVMsVUFBVSxLQUFLO0dBQzlCLElBQUksQ0FBQyxxQkFBcUIsTUFBTSxHQUFHO0lBQ2pDLFNBQVMsbUJBQW1CO0lBQzVCO0dBQ0Y7R0FDQSxTQUFTLG1CQUFtQixRQUFRLFFBQVEsaUJBQWlCLEtBQUs7RUFDcEU7RUFDQSxTQUFTLHVCQUF1QjtHQUM5QixTQUFTLGtCQUFrQixNQUFNO0dBQ2pDLG1CQUFtQixNQUFNO0dBQ3pCLE1BQU0sT0FBTyxJQUFJLG1CQUFtQixZQUFZO0dBQ2hELG1CQUFtQjtFQUNyQjtFQUNBLFNBQVMscUJBQXFCLE9BQU87R0FDbkMsSUFBSSxrQkFBa0IsS0FBSyxNQUFNO0lBQy9CLEtBQUssT0FBTyxHQUFHLG1CQUFtQixZQUFZO0lBQzlDO0dBQ0Y7R0FDQSxJQUFJQyw2QkFBdUIsTUFBTSxlQUFlLE1BQU0sUUFBUSxlQUFlLEdBRzNFO0dBRUYsTUFBTSxnQkFBZ0IsUUFBUSxRQUFRLGlCQUFpQixVQUFVO0dBQ2pFLE1BQU0sZ0JBQWdCLE1BQU07R0FFNUIsSUFEdUMsUUFBUSxpQkFBaUIsVUFBVSxhQUFhLEtBQUssZ0JBQWdCLEtBQUssU0FBUyxTQUFTLGVBQWUsS0FBSyxDQUFDLENBQUMsTUFBSyxTQUFRLFNBQVMsS0FBSyxTQUFTLFNBQVMsVUFBVSxhQUFhLENBQUMsR0FFNU47R0FJRixJQUFJLFNBQVMsU0FBUztJQUNwQixTQUFTLFFBQVEsS0FBSztJQUN0QjtHQUNGO0dBQ0EsbUJBQW1CO0dBQ25CLElBQUksWUFBWSxLQUFLLENBQUNILHVCQUFxQixHQUN6QyxlQUFlLEtBQUs7RUFFeEI7RUFDQSxTQUFTLGFBQWEsT0FBTztHQUMzQixJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksa0JBQWtCLEdBQzFDO0dBR0YsbUJBQW1CLE1BQU0sU0FBUztJQUNoQyxLQUFLLE9BQU8sSUFBSSxtQkFBbUIsWUFBWTtJQUMvQyxNQUFNLFFBQVEsT0FBTyx5QkFBeUJFLGNBQXNCLEtBQUssQ0FBQztJQUMxRSxLQUFLLE9BQU8sS0FBSyxtQkFBbUIsS0FBSztHQUMzQyxDQUFDO0VBQ0g7RUFDQSxNQUFNLFdBQVc7RUFDakIsT0FBTyxjQUFjLFlBQVksaUJBQWlCLFVBQVUsY0FBYyxvQkFBb0IsR0FBRyxZQUFZLGlCQUFpQixVQUFVLGNBQWMsb0JBQW9CLEdBQUcsWUFBWSxpQkFBaUIsVUFBVSxlQUFlLHNCQUFzQixJQUFJLFNBQVM7R0FDcFEsTUFBTSxPQUFPLElBQUksbUJBQW1CLFlBQVk7RUFDbEQsQ0FBQztDQUNILEdBQUc7RUFBQztFQUFTO0VBQWlCO0VBQU87RUFBUztFQUFnQjtFQUFZO0VBQWFGO0VBQXNCO0VBQW9CO0VBQVU7RUFBTTtFQUFVO0NBQWtCLENBQUM7QUFDaEw7OztBQ2xKQSxJQUFNLFlBQVksRUFDaEIsU0FBUyxLQUNYOzs7OztBQU1BLFNBQWdCLDZCQUE2QixPQUFPLFFBQVEsQ0FBQyxHQUFHO0NBQzlELE1BQU0sRUFDSixVQUFVLE1BQ1YsUUFBUSxHQUNSLGNBQWMsTUFDZCxZQUFZLE9BQ1osU0FBUyxHQUNULE9BQU8sTUFDUCxvQkFBb0IsV0FDcEIsY0FDQSxrQkFBa0IsTUFDbEIsdUJBQ0EsV0FDQSxZQUFZLGdCQUNaLGlCQUFpQixVQUNmO0NBQ0osTUFBTSxFQUNKLFNBQ0EsV0FDRSxNQUFNO0NBQ1YsTUFBTSxPQUFPLGdCQUFnQixZQUFZO0NBQ3pDLE1BQU0sV0FBVywrQkFBK0IsS0FBSztDQUNyRCxNQUFNLHdCQUFBLGFBQThCLE9BQU8sS0FBSztDQUNoRCxNQUFNLGlCQUFpQixjQUFjLFdBQVc7Q0FDaEQsTUFBTSxXQUFXLGNBQWMsS0FBSztDQUNwQyxNQUFNLFlBQVksY0FBYyxNQUFNO0NBQ3RDLE1BQU0sYUFBYSxjQUFjLE9BQU87Q0FDeEMsTUFBTSxnQkFBZ0IsY0FBYyxjQUFjO0NBQ2xELE1BQU0sZUFBZSxjQUFjLFNBQVM7Q0FDNUMsTUFBTUkseUJBQXVCLHdCQUF3QjtFQUNuRCxPQUFPQyxxQkFBMkIsUUFBUSxRQUFRLFdBQVcsTUFBTSxTQUFTLGdCQUFnQjtDQUM5RixDQUFDO0NBQ0QsTUFBTSxrQkFBa0Isd0JBQXdCO0VBQzlDLE9BQU8sY0FBYyxVQUFVLE1BQU07Q0FDdkMsQ0FBQztDQUNELE1BQU0sd0JBQXdCLG1CQUFtQixxQkFBcUIsZUFBZSxXQUFXO0VBQzlGLE1BQU0sY0FBYyxNQUFNLFFBQVE7RUFHbEMsSUFBSSxZQUFZLFdBQVcsYUFBYSxHQUN0QyxPQUFPLENBQUMsdUJBQXVCLENBQUMsU0FBUyxxQkFBcUIsYUFBYTtFQUk3RSxJQUFJLENBQUMsVUFBVSxNQUFNLEdBQ25CLE9BQU87RUFFVCxNQUFNLGdCQUFnQjtFQUN0QixPQUFPLFlBQVksb0JBQW1CLFlBQVcsU0FBUyxTQUFTLGFBQWEsQ0FBQyxNQUFNLENBQUMsdUJBQXVCLENBQUMsU0FBUyxxQkFBcUIsYUFBYTtDQUM3SixDQUFDO0NBQ0QsTUFBTSwwQkFBMEIsd0JBQXdCO0VBQ3RELElBQUksQ0FBQyxTQUFTLFNBQ1o7RUFHRixjQUQwQixNQUFNLE9BQU8scUJBQXFCLENBQzFELENBQUMsQ0FBQyxvQkFBb0IsYUFBYSxTQUFTLE9BQU87RUFDckQsU0FBUyxVQUFVLEtBQUE7Q0FDckIsQ0FBQztDQUNELE1BQU0scUJBQXFCLHdCQUF3QjtFQUNqRCxzQ0FBc0MsUUFBUTtDQUNoRCxDQUFDO0NBQ0QsSUFBSSxpQkFFRixTQUFTLHFCQUFxQixhQUFhO0NBRTdDLGFBQU0sZ0JBQWdCLHlCQUF5QixDQUFDLHVCQUF1QixDQUFDO0NBSXhFLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksQ0FBQyxTQUNIO0VBRUYsU0FBUyxrQkFBa0IsU0FBUztHQUNsQyxJQUFJLENBQUMsUUFBUSxNQUFNO0lBQ2pCLHNCQUFzQixVQUFVLFFBQVEsV0FBV0M7SUFDbkQsd0JBQXdCO0lBQ3hCLFNBQVMsa0JBQWtCLE1BQU07SUFDakMsU0FBUyxZQUFZLE1BQU07SUFDM0IsU0FBUyxpQkFBaUI7SUFDMUIsU0FBUyxxQkFBcUI7R0FDaEMsT0FDRSxzQkFBc0IsVUFBVTtFQUVwQztFQUNBLE9BQU8sR0FBRyxjQUFjLGlCQUFpQjtFQUN6QyxhQUFhO0dBQ1gsT0FBTyxJQUFJLGNBQWMsaUJBQWlCO0VBQzVDO0NBQ0YsR0FBRztFQUFDO0VBQVM7RUFBUTtFQUFVO0NBQXVCLENBQUM7Q0FDdkQsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxDQUFDLFNBQ0g7RUFFRixTQUFTLGVBQWUsT0FBTyxnQkFBZ0IsTUFBTTtHQUNuRCxNQUFNLGFBQWEsU0FBUyxTQUFTLFNBQVMsU0FBUyxTQUFTLFdBQVc7R0FDM0UsSUFBSSxZQUNGLFNBQVMsa0JBQWtCLE1BQU0sa0JBQWtCO0lBQ2pELE1BQU0sUUFBUSxPQUFPLHlCQUF5QkEsY0FBc0IsS0FBSyxDQUFDO0lBQzFFLE1BQU0sT0FBTyxLQUFLLG1CQUFtQixLQUFLO0dBQzVDLENBQUM7UUFDSSxJQUFJLGVBQWU7SUFDeEIsU0FBUyxrQkFBa0IsTUFBTTtJQUNqQyxNQUFNLFFBQVEsT0FBTyx5QkFBeUJBLGNBQXNCLEtBQUssQ0FBQztJQUMxRSxNQUFNLE9BQU8sS0FBSyxtQkFBbUIsS0FBSztHQUM1QztFQUNGO0VBQ0EsTUFBTSxVQUFVLGtCQUFrQixZQUFZLGtCQUFrQixNQUFNLE9BQU8scUJBQXFCLElBQUk7RUFDdEcsSUFBSSxDQUFDLFVBQVUsT0FBTyxHQUNwQjtFQUVGLFNBQVMsYUFBYSxPQUFPO0dBQzNCLFNBQVMsa0JBQWtCLE1BQU07R0FDakMsU0FBUyxpQkFBaUI7R0FDMUIsSUFBSSxhQUFhLENBQUMsdUJBQXVCLFNBQVMsV0FBVyxHQUMzRDtHQUtGLE1BQU0sY0FBYyxVQUFVLFVBQVUsT0FBTztHQUMvQyxNQUFNLFlBQVksU0FBUyxTQUFTLFNBQVMsUUFBUSxTQUFTLFdBQVc7R0FDekUsTUFBTSxjQUFjLFVBQVUsS0FBSztHQUNuQyxNQUFNLGdCQUFnQixNQUFNLGlCQUFpQjtHQUM3QyxNQUFNLHNCQUFzQixNQUFNLE9BQU8scUJBQXFCO0dBQzlELElBQUksY0FBYztHQUdsQixJQUFJLFVBQVUsV0FBVyxLQUFLLENBQUMsTUFBTSxRQUFRLGdCQUFnQixXQUFXLFdBQVcsR0FDNUU7U0FBQSxNQUFNLGtCQUFrQixNQUFNLFFBQVEsZ0JBQWdCLFNBQVMsR0FDbEUsSUFBSSxTQUFTLGdCQUFnQixXQUFXLEdBQUc7S0FDekMsY0FBYztLQUNkO0lBQ0Y7O0dBTUosSUFBSSxVQUFVLGFBQWEsS0FBSyxVQUFVLG1CQUFtQixLQUFLLENBQUMsTUFBTSxRQUFRLGdCQUFnQixXQUFXLGFBQWEsS0FBSyxTQUFTLGVBQWUsbUJBQW1CLEdBQ3ZLLGNBQWM7R0FFaEIsTUFBTSxpQkFBaUIsZUFBZSxPQUFPLFFBQVEsc0JBQXNCLHFCQUFxQixhQUFhLFdBQVc7R0FDeEgsTUFBTSxTQUFTLE1BQU0sT0FBTyxNQUFNO0dBQ2xDLE1BQU0sd0JBQXdCLGFBQWEsVUFBVSxLQUFLLE1BQU0sT0FBTyxrQkFBa0IsTUFBTTtHQUMvRixNQUFNLHlCQUF5QixDQUFDLFVBQVUseUJBQXlCLHNCQUFzQjtHQUN6RixNQUFNLCtDQUErQyxDQUFDLGtCQUFrQixVQUFVLFdBQVcsS0FBSyxVQUFVLG1CQUFtQixLQUFLLFNBQVMscUJBQXFCLFdBQVcsS0FBSztHQUNsTCxNQUFNLGtCQUFrQixjQUFjLEtBQUssQ0FBQztHQUM1QyxNQUFNLHdCQUF3QixtQkFBbUIsVUFBVSwyQkFBMkI7R0FDdEYsTUFBTSxhQUFhLENBQUMsVUFBVTtHQUk5QixJQUFJLHVCQUF1QjtJQUN6QixJQUFJLGdCQUFnQixHQUNsQixNQUFNLFFBQVEsTUFBTSx5QkFBeUJBLGNBQXNCLE9BQU8sV0FBVyxDQUFDO0lBRXhGO0dBQ0Y7R0FDQSxJQUFJLGlCQUNGO0dBRUYsSUFBSSxXQUNGLFNBQVMsa0JBQWtCLE1BQU0saUJBQWlCO0lBQ2hELElBQUksY0FBYyxnQkFBZ0IsR0FDaEMsTUFBTSxRQUFRLE1BQU0seUJBQXlCQSxjQUFzQixPQUFPLFdBQVcsQ0FBQztHQUUxRixDQUFDO1FBQ0ksSUFBSSxZQUNMO1FBQUEsZ0JBQWdCLEdBQ2xCLE1BQU0sUUFBUSxNQUFNLHlCQUF5QkEsY0FBc0IsT0FBTyxXQUFXLENBQUM7R0FBQTtFQUc1RjtFQUNBLFNBQVMsYUFBYSxPQUFPO0dBQzNCLElBQUlGLHVCQUFxQixHQUFHO0lBQzFCLG1CQUFtQjtJQUNuQjtHQUNGO0dBQ0Esd0JBQXdCO0dBQ3hCLE1BQU0sc0JBQXNCLE1BQU0sT0FBTyxxQkFBcUI7R0FDOUQsTUFBTSxNQUFNLGNBQWMsbUJBQW1CO0dBQzdDLFNBQVMsWUFBWSxNQUFNO0dBQzNCLFNBQVMscUJBQXFCO0dBQzlCLE1BQU0seUJBQXlCLFFBQVEsUUFBUSxtQkFBbUIsd0JBQXdCO0dBQzFGLElBQUlHLDZCQUF1QixNQUFNLGVBQWUsTUFBTSxRQUFRLGVBQWUsR0FDM0U7R0FFRixJQUFJLGVBQWUsV0FBVyx3QkFBd0I7SUFDcEQsSUFBSSxDQUFDLE1BQU0sT0FBTyxNQUFNLEdBQ3RCLFNBQVMsa0JBQWtCLE1BQU07SUFFbkMsTUFBTSxpQkFBaUIsa0JBQWtCO0lBQ3pDLFNBQVMsVUFBVSxlQUFlLFFBQVE7S0FDeEMsR0FBRztLQUNIO0tBQ0EsR0FBRyxNQUFNO0tBQ1QsR0FBRyxNQUFNO0tBQ1QsVUFBVTtNQUNSLG1CQUFtQjtNQUNuQix3QkFBd0I7TUFDeEIsSUFBSSxXQUFXLFdBQVcsQ0FBQ0gsdUJBQXFCLEtBQUssbUJBQW1CLE1BQU0sT0FBTyxxQkFBcUIsR0FDeEcsZUFBZSxPQUFPLElBQUk7S0FFOUI7SUFDRixDQUFDO0lBQ0QsSUFBSSxpQkFBaUIsYUFBYSxTQUFTLE9BQU87SUFDbEQsU0FBUyxRQUFRLEtBQUs7SUFDdEI7R0FDRjtHQUVBLElBRG9CLFNBQVMsZ0JBQWdCLFVBQVUsQ0FBQyxTQUFTLE1BQU0sT0FBTyxpQkFBaUIsR0FBRyxNQUFNLGFBQWEsSUFBSSxNQUV2SCxlQUFlLEtBQUs7RUFFeEI7RUFHQSxTQUFTLFdBQVcsT0FBTztHQUN6QixJQUFJLFNBQVMsU0FBUyxNQUFNLGFBQWEsR0FDdkM7R0FFRixTQUFTLGtCQUFrQixNQUFNO0dBQ2pDLFNBQVMsWUFBWSxNQUFNO0dBQzNCLFNBQVMscUJBQXFCO0VBQ2hDO0VBQ0EsTUFBTSxpQkFBaUIsaUJBQWlCLGlCQUFpQixTQUFTLFlBQVksVUFBVSxJQUFJLEtBQUE7RUFDNUYsSUFBSSxNQUNGLE9BQU8sY0FBYyxpQkFBaUIsU0FBUyxhQUFhLGNBQWMsRUFDeEUsTUFBTSxLQUNSLENBQUMsR0FBRyxpQkFBaUIsU0FBUyxjQUFjLFlBQVksR0FBRyxpQkFBaUIsU0FBUyxjQUFjLFlBQVksR0FBRyxjQUFjO0VBRWxJLE9BQU8sY0FBYyxpQkFBaUIsU0FBUyxjQUFjLFlBQVksR0FBRyxpQkFBaUIsU0FBUyxjQUFjLFlBQVksR0FBRyxjQUFjO0NBQ25KLEdBQUc7RUFBQztFQUF5QjtFQUFvQjtFQUFTO0VBQVU7RUFBTztFQUFTO0VBQWdCO0VBQVU7RUFBaUI7RUFBdUJBO0VBQXNCO0VBQVc7RUFBTTtFQUFXO0VBQW1CO0VBQU07RUFBWTtFQUF1QjtFQUFjO0VBQWlCO0NBQWMsQ0FBQztDQUNsVCxPQUFBLGFBQWEsY0FBYztFQUN6QixJQUFJLENBQUMsU0FDSDtFQUVGLFNBQVMsY0FBYyxPQUFPO0dBQzVCLFNBQVMsY0FBYyxNQUFNO0VBQy9CO0VBQ0EsT0FBTztHQUNMLGVBQWU7R0FDZixnQkFBZ0I7R0FDaEIsWUFBWSxPQUFPO0lBQ2pCLE1BQU0sRUFDSixnQkFDRTtJQUNKLE1BQU0sVUFBVSxNQUFNO0lBQ3RCLE1BQU0sc0JBQXNCLE1BQU0sT0FBTyxxQkFBcUI7SUFDOUQsTUFBTSxjQUFjLE1BQU0sT0FBTyxNQUFNO0lBQ3ZDLE1BQU0saUJBQWlCLHNCQUFzQixxQkFBcUIsU0FBUyxNQUFNLE1BQU07SUFDdkYsSUFBSSxhQUFhLENBQUMsdUJBQXVCLFNBQVMsV0FBVyxHQUMzRDtJQUVGLElBQUksZUFBZSxrQkFBa0IsU0FBUyxvQkFBb0Isb0JBQW9CO0tBQ3BGLE1BQU0sa0JBQWtCLE1BQU0sT0FBTyxpQkFBaUI7S0FDdEQsSUFBSSxpQkFBaUI7TUFDbkIsTUFBTSxlQUFlLFNBQVMsb0JBQW9CLFdBQVcsS0FBSyxRQUFRLGNBQWM7TUFDeEYsc0NBQXNDLFVBQVU7T0FDOUM7T0FDQSxrQkFBa0I7T0FDbEI7TUFDRixDQUFDO0tBQ0g7SUFDRjtJQUNBLE1BQU0sY0FBYyxVQUFVLFVBQVUsT0FBTztJQUMvQyxJQUFJLGVBQWUsQ0FBQyxrQkFBa0IsZ0JBQWdCLEdBQ3BEO0lBRUYsSUFBSSxDQUFDLGtCQUFrQixTQUFTLHNCQUFzQixNQUFNLGFBQWEsSUFBSSxNQUFNLGFBQWEsSUFBSSxHQUNsRztJQUVGLFNBQVMsWUFBWSxNQUFNO0lBQzNCLFNBQVMsa0JBQWtCO0tBQ3pCLFNBQVMscUJBQXFCO0tBSTlCLElBQUlBLHVCQUFxQixHQUN2QjtLQUVGLE1BQU0sYUFBYSxNQUFNLE9BQU8sTUFBTTtLQUN0QyxJQUFJLENBQUMsU0FBUyxtQkFBbUIsQ0FBQyxjQUFjLG1CQUFtQixnQkFBZ0IsR0FDakYsTUFBTSxRQUFRLE1BQU0seUJBQXlCRSxjQUFzQixhQUFhLE9BQU8sQ0FBQztJQUU1RjtJQUNBLElBQUksU0FBUyxnQkFBZ0IsU0FDM0IsaUJBQVMsZ0JBQWdCO0tBQ3ZCLGdCQUFnQjtJQUNsQixDQUFDO1NBQ0ksSUFBSSxrQkFBa0IsYUFDM0IsZ0JBQWdCO1NBQ1g7S0FDTCxTQUFTLHFCQUFxQjtLQUM5QixTQUFTLFlBQVksTUFBTSxhQUFhLGVBQWU7SUFDekQ7R0FDRjtFQUNGO0NBQ0YsR0FBRztFQUFDO0VBQVM7RUFBVUY7RUFBc0I7RUFBdUI7RUFBVztFQUFPO0VBQVc7Q0FBZSxDQUFDO0FBQ25IOztBQzdUQSxJQUFNLHlCQUF5QjtBQUMvQixJQUFNLGlDQUFpQyx5QkFBeUI7QUFDaEUsSUFBTSxpQkFBaUI7QUFDdkIsU0FBUyxvQkFBb0IsUUFBUSxRQUFRLElBQUksSUFBSSxJQUFJLElBQUk7Q0FDM0QsT0FBTyxNQUFNLFdBQVcsTUFBTSxVQUFVLFdBQVcsS0FBSyxPQUFPLFNBQVMsT0FBTyxLQUFLLE1BQU07QUFDNUY7QUFDQSxTQUFTLHVCQUF1QixRQUFRLFFBQVEsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJO0NBQzlFLElBQUksZ0JBQWdCO0NBQ3BCLElBQUksb0JBQW9CLFFBQVEsUUFBUSxJQUFJLElBQUksSUFBSSxFQUFFLEdBQ3BELGdCQUFnQixDQUFDO0NBRW5CLElBQUksb0JBQW9CLFFBQVEsUUFBUSxJQUFJLElBQUksSUFBSSxFQUFFLEdBQ3BELGdCQUFnQixDQUFDO0NBRW5CLElBQUksb0JBQW9CLFFBQVEsUUFBUSxJQUFJLElBQUksSUFBSSxFQUFFLEdBQ3BELGdCQUFnQixDQUFDO0NBRW5CLElBQUksb0JBQW9CLFFBQVEsUUFBUSxJQUFJLElBQUksSUFBSSxFQUFFLEdBQ3BELGdCQUFnQixDQUFDO0NBRW5CLE9BQU87QUFDVDtBQUNBLFNBQVMsYUFBYSxRQUFRLFFBQVEsTUFBTTtDQUMxQyxPQUFPLFVBQVUsS0FBSyxLQUFLLFVBQVUsS0FBSyxJQUFJLEtBQUssU0FBUyxVQUFVLEtBQUssS0FBSyxVQUFVLEtBQUssSUFBSSxLQUFLO0FBQzFHO0FBQ0EsU0FBUyx3QkFBd0IsUUFBUSxRQUFRLElBQUksSUFBSSxJQUFJLElBQUk7Q0FLL0QsT0FBTyxVQUpNLEtBQUssSUFBSSxJQUFJLEVBSU4sS0FBSyxVQUhaLEtBQUssSUFBSSxJQUFJLEVBR1ksS0FBSyxVQUY5QixLQUFLLElBQUksSUFBSSxFQUU4QixLQUFLLFVBRGhELEtBQUssSUFBSSxJQUFJLEVBQ2dEO0FBQzVFOzs7Ozs7QUFNQSxTQUFnQixZQUFZLFVBQVUsQ0FBQyxHQUFHO0NBQ3hDLE1BQU0sRUFDSixxQkFBcUIsVUFDbkI7Q0FDSixNQUFNLFVBQVUsSUFBSSxRQUFRO0NBQzVCLE1BQU0sTUFBTSxFQUNWLEdBQ0EsR0FDQSxXQUNBLFVBQ0EsU0FDQSxRQUNBLFdBQ0k7RUFDSixNQUFNLE9BQU8sV0FBVyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQ25DLElBQUksWUFBWTtFQUNoQixJQUFJLFFBQVE7RUFDWixJQUFJLFFBQVE7RUFDWixJQUFJLGlCQUFpQixPQUFPLGdCQUFnQixjQUFjLFlBQVksSUFBSSxJQUFJO0VBQzlFLFNBQVMscUJBQXFCLE9BQU8sT0FBTztHQUMxQyxNQUFNLGNBQWMsWUFBWSxJQUFJO0dBQ3BDLE1BQU0sY0FBYyxjQUFjO0dBQ2xDLElBQUksVUFBVSxRQUFRLFVBQVUsUUFBUSxnQkFBZ0IsR0FBRztJQUN6RCxRQUFRO0lBQ1IsUUFBUTtJQUNSLGlCQUFpQjtJQUNqQixPQUFPO0dBQ1Q7R0FDQSxNQUFNLFNBQVMsUUFBUTtHQUN2QixNQUFNLFNBQVMsUUFBUTtHQUN2QixNQUFNLGtCQUFrQixTQUFTLFNBQVMsU0FBUztHQUNuRCxNQUFNLG1CQUFtQixjQUFjLGNBQWM7R0FDckQsUUFBUTtHQUNSLFFBQVE7R0FDUixpQkFBaUI7R0FDakIsT0FBTyxrQkFBa0I7RUFDM0I7RUFDQSxTQUFTLFFBQVE7R0FDZixRQUFRLE1BQU07R0FDZCxRQUFRO0VBQ1Y7RUFDQSxPQUFPLFNBQVMsWUFBWSxPQUFPO0dBQ2pDLFFBQVEsTUFBTTtHQUNkLE1BQU0sZUFBZSxTQUFTO0dBQzlCLE1BQU0sV0FBVyxTQUFTO0dBQzFCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLFFBQVEsUUFBUSxLQUFLLFFBQVEsS0FBSyxNQUNsRTtHQUVGLE1BQU0sRUFDSixTQUNBLFlBQ0U7R0FDSixNQUFNLFNBQVMsVUFBVSxLQUFLO0dBQzlCLE1BQU0sVUFBVSxNQUFNLFNBQVM7R0FDL0IsTUFBTSxtQkFBbUIsU0FBUyxVQUFVLE1BQU07R0FDbEQsTUFBTSxvQkFBb0IsU0FBUyxjQUFjLE1BQU07R0FDdkQsSUFBSSxrQkFBa0I7SUFDcEIsWUFBWTtJQUNaLElBQUksQ0FBQyxTQUNIO0dBRUo7R0FDQSxJQUFJLG1CQUFtQjtJQUNyQixZQUFZO0lBQ1osSUFBSSxDQUFDLFNBQVM7S0FDWixZQUFZO0tBQ1o7SUFDRjtHQUNGO0dBSUEsSUFBSSxXQUFXLFVBQVUsTUFBTSxhQUFhLEtBQUssU0FBUyxVQUFVLE1BQU0sYUFBYSxHQUNyRjtHQUVGLFNBQVMsbUJBQW1CO0lBQzFCLE9BQU8sUUFBUSxRQUFRLGdCQUFnQixLQUFLLFNBQVMsU0FBUyxNQUFNLENBQUMsQ0FBQyxTQUFTLENBQUM7R0FDbEY7R0FDQSxTQUFTLHFCQUFxQjtJQUM1QixJQUFJLENBQUMsaUJBQWlCLEdBQ3BCLE1BQU07R0FFVjtHQUdBLElBQUksaUJBQWlCLEdBQ25CO0dBRUYsTUFBTSxVQUFVLGFBQWEsc0JBQXNCO0dBQ25ELE1BQU0sT0FBTyxTQUFTLHNCQUFzQjtHQUM1QyxNQUFNLHVCQUF1QixJQUFJLEtBQUssUUFBUSxLQUFLLFFBQVE7R0FDM0QsTUFBTSx3QkFBd0IsSUFBSSxLQUFLLFNBQVMsS0FBSyxTQUFTO0dBQzlELE1BQU0sa0JBQWtCLEtBQUssUUFBUSxRQUFRO0dBQzdDLE1BQU0sbUJBQW1CLEtBQUssU0FBUyxRQUFRO0dBQy9DLE1BQU0sUUFBUSxrQkFBa0IsVUFBVSxLQUFBLENBQU07R0FDaEQsTUFBTSxTQUFTLGtCQUFrQixVQUFVLEtBQUEsQ0FBTTtHQUNqRCxNQUFNLE9BQU8sbUJBQW1CLFVBQVUsS0FBQSxDQUFNO0dBQ2hELE1BQU0sVUFBVSxtQkFBbUIsVUFBVSxLQUFBLENBQU07R0FNbkQsSUFBSSxTQUFTLFNBQVMsS0FBSyxRQUFRLFNBQVMsS0FBSyxTQUFTLFlBQVksS0FBSyxRQUFRLE1BQU0sS0FBSyxTQUFTLFVBQVUsS0FBSyxRQUFRLFFBQVEsS0FBSyxTQUFTLFdBQVcsS0FBSyxRQUFRLE9BQU8sR0FBRztJQUNwTCxtQkFBbUI7SUFDbkI7R0FDRjtHQU9BLElBQUkscUJBQXFCO0dBQ3pCLFFBQVEsTUFBUjtJQUNFLEtBQUs7S0FDSCxxQkFBcUIsd0JBQXdCLFNBQVMsU0FBUyxNQUFNLFFBQVEsTUFBTSxHQUFHLE9BQU8sS0FBSyxTQUFTLENBQUM7S0FDNUc7SUFDRixLQUFLO0tBQ0gscUJBQXFCLHdCQUF3QixTQUFTLFNBQVMsTUFBTSxLQUFLLE1BQU0sR0FBRyxPQUFPLFFBQVEsU0FBUyxDQUFDO0tBQzVHO0lBQ0YsS0FBSztLQUNILHFCQUFxQix3QkFBd0IsU0FBUyxTQUFTLEtBQUssUUFBUSxHQUFHLFFBQVEsUUFBUSxPQUFPLEdBQUcsR0FBRztLQUM1RztJQUNGLEtBQUssU0FDSCxxQkFBcUIsd0JBQXdCLFNBQVMsU0FBUyxRQUFRLFFBQVEsR0FBRyxRQUFRLEtBQUssT0FBTyxHQUFHLEdBQUc7R0FHaEg7R0FDQSxJQUFJLG9CQUNGO0dBRUYsSUFBSSxhQUFhLENBQUMsYUFBYSxTQUFTLFNBQVMsT0FBTyxHQUFHO0lBQ3pELG1CQUFtQjtJQUNuQjtHQUNGO0dBQ0EsSUFBSSxDQUFDLFdBQVcscUJBQXFCLFNBQVMsT0FBTyxHQUFHO0lBQ3RELG1CQUFtQjtJQUNuQjtHQUNGO0dBQ0EsSUFBSSxrQkFBa0I7R0FDdEIsUUFBUSxNQUFSO0lBQ0UsS0FBSyxPQUNIO0tBQ0UsTUFBTSxnQkFBZ0Isa0JBQWtCLGlCQUFpQixJQUFJLGlCQUFpQjtLQUM5RSxNQUFNLGtCQUFrQixrQkFBa0IsSUFBSSxnQkFBZ0IsdUJBQXVCLElBQUksZ0JBQWdCLElBQUk7S0FDN0csTUFBTSxrQkFBa0Isa0JBQWtCLElBQUksZ0JBQWdCLHVCQUF1QixJQUFJLGdCQUFnQixJQUFJO0tBQzdHLE1BQU0sZUFBZSxJQUFJLGlCQUFpQjtLQUMxQyxNQUFNLGNBQWMsdUJBQXVCLEtBQUssU0FBUyxpQkFBaUIsa0JBQWtCLEtBQUssU0FBUyxpQkFBaUIsS0FBSztLQUNoSSxNQUFNLGVBQWUsdUJBQXVCLGtCQUFrQixLQUFLLFNBQVMsaUJBQWlCLEtBQUssTUFBTSxLQUFLLFNBQVM7S0FDdEgsa0JBQWtCLHVCQUF1QixTQUFTLFNBQVMsaUJBQWlCLGNBQWMsaUJBQWlCLGNBQWMsS0FBSyxNQUFNLGFBQWEsS0FBSyxPQUFPLFlBQVk7S0FDeks7SUFDRjtJQUNGLEtBQUssVUFDSDtLQUNFLE1BQU0sZ0JBQWdCLGtCQUFrQixpQkFBaUIsSUFBSSxpQkFBaUI7S0FDOUUsTUFBTSxrQkFBa0Isa0JBQWtCLElBQUksZ0JBQWdCLHVCQUF1QixJQUFJLGdCQUFnQixJQUFJO0tBQzdHLE1BQU0sa0JBQWtCLGtCQUFrQixJQUFJLGdCQUFnQix1QkFBdUIsSUFBSSxnQkFBZ0IsSUFBSTtLQUM3RyxNQUFNLGVBQWUsSUFBSTtLQUN6QixNQUFNLGNBQWMsdUJBQXVCLEtBQUssTUFBTSxpQkFBaUIsa0JBQWtCLEtBQUssTUFBTSxpQkFBaUIsS0FBSztLQUMxSCxNQUFNLGVBQWUsdUJBQXVCLGtCQUFrQixLQUFLLE1BQU0saUJBQWlCLEtBQUssU0FBUyxLQUFLLE1BQU07S0FDbkgsa0JBQWtCLHVCQUF1QixTQUFTLFNBQVMsaUJBQWlCLGNBQWMsaUJBQWlCLGNBQWMsS0FBSyxNQUFNLGFBQWEsS0FBSyxPQUFPLFlBQVk7S0FDeks7SUFDRjtJQUNGLEtBQUssUUFDSDtLQUNFLE1BQU0sZ0JBQWdCLG1CQUFtQixpQkFBaUIsSUFBSSxpQkFBaUI7S0FDL0UsTUFBTSxrQkFBa0IsbUJBQW1CLElBQUksZ0JBQWdCLHdCQUF3QixJQUFJLGdCQUFnQixJQUFJO0tBQy9HLE1BQU0sa0JBQWtCLG1CQUFtQixJQUFJLGdCQUFnQix3QkFBd0IsSUFBSSxnQkFBZ0IsSUFBSTtLQUMvRyxNQUFNLGVBQWUsSUFBSSxpQkFBaUI7S0FDMUMsTUFBTSxhQUFhLHdCQUF3QixLQUFLLFFBQVEsaUJBQWlCLG1CQUFtQixLQUFLLFFBQVEsaUJBQWlCLEtBQUs7S0FDL0gsTUFBTSxnQkFBZ0Isd0JBQXdCLG1CQUFtQixLQUFLLFFBQVEsaUJBQWlCLEtBQUssT0FBTyxLQUFLLFFBQVE7S0FDeEgsa0JBQWtCLHVCQUF1QixTQUFTLFNBQVMsWUFBWSxLQUFLLEtBQUssZUFBZSxLQUFLLFFBQVEsY0FBYyxpQkFBaUIsY0FBYyxlQUFlO0tBQ3pLO0lBQ0Y7SUFDRixLQUFLLFNBQ0g7S0FDRSxNQUFNLGdCQUFnQixtQkFBbUIsaUJBQWlCLElBQUksaUJBQWlCO0tBQy9FLE1BQU0sa0JBQWtCLG1CQUFtQixJQUFJLGdCQUFnQix3QkFBd0IsSUFBSSxnQkFBZ0IsSUFBSTtLQUMvRyxNQUFNLGtCQUFrQixtQkFBbUIsSUFBSSxnQkFBZ0Isd0JBQXdCLElBQUksZ0JBQWdCLElBQUk7S0FDL0csTUFBTSxlQUFlLElBQUk7S0FDekIsTUFBTSxhQUFhLHdCQUF3QixLQUFLLE9BQU8saUJBQWlCLG1CQUFtQixLQUFLLE9BQU8saUJBQWlCLEtBQUs7S0FDN0gsTUFBTSxnQkFBZ0Isd0JBQXdCLG1CQUFtQixLQUFLLE9BQU8saUJBQWlCLEtBQUssUUFBUSxLQUFLLE9BQU87S0FDdkgsa0JBQWtCLHVCQUF1QixTQUFTLFNBQVMsY0FBYyxpQkFBaUIsY0FBYyxpQkFBaUIsWUFBWSxLQUFLLEtBQUssZUFBZSxLQUFLLE1BQU07S0FDeks7SUFDRjtHQUVKO0dBQ0EsSUFBSSxDQUFDLGlCQUNILG1CQUFtQjtRQUNkLElBQUksQ0FBQyxXQUNWLFFBQVEsTUFBTSxJQUFJLGtCQUFrQjtFQUd4QztDQUNGO0NBR0EsR0FBRyxZQUFZO0VBQ2IsR0FBRztFQUNIO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7Ozs7Ozs7QUNsUEEsSUFBYSxhQUFhOzs7Ozs7QUFNMUIsSUFBYSxjQUFjOzs7OztBQ0kzQixTQUFnQixtQkFBbUIsWUFBWTtDQUM3QyxNQUFNLEVBQ0osY0FDQSxtQkFDQSxTQUNBLFNBQ0EsaUJBQWlCLHNCQUNqQix5QkFBeUIsOEJBQ3pCLE1BQ0EsY0FDRTtDQUNKLE1BQU0sMEJBQTBCLHNCQUFzQixjQUFjLElBQUk7Q0FDeEUsTUFBTSxpQkFBaUIsa0JBQWtCO0NBQ3pDLE1BQU0seUJBQUEsYUFBK0IsT0FBTyxJQUFJO0NBQ2hELE1BQU0sa0JBQWtCLGtCQUFrQixvQkFBb0I7Q0FDOUQsTUFBTSwwQkFBMEIsa0JBQWtCLDRCQUE0QjtDQUM5RSxNQUFNLGtCQUFBLGFBQXdCLGNBQWMsd0JBQXdCLE1BQU0sU0FBUyxHQUFHLENBQUMsTUFBTSxTQUFTLENBQUM7Q0FDdkcseUJBQXlCO0VBRXZCLElBQUksQ0FBQyxTQUFTO0dBQ1osdUJBQXVCLFVBQVU7R0FDakM7RUFDRjtFQUNBLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxtQkFDcEI7RUFFRixNQUFNLHlCQUF5QixtQkFBbUIsY0FBYyxlQUFlO0VBRy9FLGdCQUFnQixjQUFjLE1BQU07RUFDcEMsTUFBTSx1QkFBdUIscUJBQXFCLGNBQWMsWUFBWSxRQUFRO0VBQ3BGLE1BQU0sd0JBQXdCLHFCQUFxQixjQUFjLGFBQWEsTUFBTTtFQUNwRixNQUFNLG9CQUFvQixxQkFBcUIsY0FBYyxTQUFTLEdBQUc7RUFDekUsTUFBTSxpQ0FBaUMsbUJBQW1CLG1CQUFtQjtJQUMxRUksaUJBQXlDO0lBQ3pDQyxrQkFBMEM7RUFDN0MsQ0FBQztFQUNELFNBQVMsOEJBQThCO0dBQ3JDLHFCQUFxQjtHQUNyQixzQkFBc0I7R0FDdEIsK0JBQStCO0dBQy9CLGtCQUFrQjtFQUNwQjtFQUNBLGtCQUFrQjtFQUdsQixJQUFJLHVCQUF1QixZQUFZLE1BQU07R0FDM0MscUJBQXFCLG1CQUFtQixhQUFhO0dBQ3JELE1BQU0sYUFBYSxpQkFBaUIsWUFBWTtHQUNoRCx1QkFBdUIsVUFBVTtHQUNqQyxxQkFBcUIsbUJBQW1CLFVBQVU7R0FDbEQsNEJBQTRCO0dBQzVCLDBCQUEwQixNQUFNLFVBQVU7R0FDMUMsT0FBTztFQUNUO0VBR0EscUJBQXFCLG1CQUFtQixhQUFhO0VBQ3JELE1BQU0scUJBQXFCLHVCQUF1QjtFQUNsRCxNQUFNLGdCQUFnQixpQkFBaUIsWUFBWTtFQUduRCx1QkFBdUIsVUFBVTtFQUNqQyxnQkFBZ0IsY0FBYyxrQkFBa0I7RUFDaEQsNEJBQTRCO0VBQzVCLDBCQUEwQixvQkFBb0IsYUFBYTtFQUMzRCxxQkFBcUIsbUJBQW1CLGFBQWE7RUFDckQsTUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0I7RUFDNUMsZUFBZSxjQUFjO0dBQzNCLGdCQUFnQixjQUFjLGFBQWE7R0FDM0MsOEJBQThCO0lBQzVCLGFBQWEsTUFBTSxZQUFZQyxZQUErQixNQUFNO0lBQ3BFLGFBQWEsTUFBTSxZQUFZQyxhQUFnQyxNQUFNO0dBQ3ZFLEdBQUcsZ0JBQWdCLE1BQU07RUFDM0IsQ0FBQztFQUNELGFBQWE7R0FDWCxnQkFBZ0IsTUFBTTtHQUN0QixlQUFlLE9BQU87R0FDdEIsdUJBQXVCO0VBQ3pCO0NBQ0YsR0FBRztFQUFDO0VBQVM7RUFBYztFQUFtQjtFQUF5QjtFQUFnQjtFQUFTO0VBQWlCO0VBQXlCO0NBQWUsQ0FBQztBQUM1SjtBQUNBLFNBQVMsd0JBQXdCLE1BQU0sV0FBVztDQUVoRCxNQUFNLGdCQUFnQixTQUFTO0NBQy9CLE1BQU0saUJBQWlCLFNBQVMsVUFBVSxVQUFVLGNBQWMsUUFBUSxlQUFlO0NBQ3pGLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxnQkFDckIsT0FBTztDQUVULE9BQU87RUFDTCxVQUFVO0dBQ1QsZ0JBQWdCLFdBQVcsUUFBUTtHQUNuQyxpQkFBaUIsVUFBVSxTQUFTO0NBQ3ZDO0FBQ0Y7QUFDQSxTQUFTLHFCQUFxQixTQUFTLFVBQVUsT0FBTztDQUN0RCxNQUFNLGdCQUFnQixRQUFRLE1BQU0saUJBQWlCLFFBQVE7Q0FDN0QsUUFBUSxNQUFNLFlBQVksVUFBVSxLQUFLO0NBQ3pDLGFBQWE7RUFDWCxRQUFRLE1BQU0sWUFBWSxVQUFVLGFBQWE7Q0FDbkQ7QUFDRjtBQUNBLFNBQVMsbUJBQW1CLFNBQVMsUUFBUTtDQUMzQyxNQUFNLFlBQVksQ0FBQztDQUNuQixLQUFLLE1BQU0sQ0FBQyxLQUFLLFVBQVUsT0FBTyxRQUFRLE1BQU0sR0FDOUMsVUFBVSxLQUFLLHFCQUFxQixTQUFTLEtBQUssS0FBSyxDQUFDO0NBRTFELE9BQU8sVUFBVSxlQUFlO0VBQzlCLFVBQVUsU0FBUSxZQUFXLFFBQVEsQ0FBQztDQUN4QyxJQUFJO0FBQ047QUFDQSxTQUFTLGdCQUFnQixjQUFjLE1BQU07Q0FDM0MsTUFBTSxRQUFRLFNBQVMsU0FBUyxTQUFTLEdBQUcsS0FBSyxNQUFNO0NBQ3ZELE1BQU0sU0FBUyxTQUFTLFNBQVMsU0FBUyxHQUFHLEtBQUssT0FBTztDQUN6RCxhQUFhLE1BQU0sWUFBWUQsWUFBK0IsS0FBSztDQUNuRSxhQUFhLE1BQU0sWUFBWUMsYUFBZ0MsTUFBTTtBQUN2RTtBQUNBLFNBQVMscUJBQXFCLG1CQUFtQixNQUFNO0NBQ3JELE1BQU0sUUFBUSxTQUFTLGdCQUFnQixnQkFBZ0IsR0FBRyxLQUFLLE1BQU07Q0FDckUsTUFBTSxTQUFTLFNBQVMsZ0JBQWdCLGdCQUFnQixHQUFHLEtBQUssT0FBTztDQUN2RSxrQkFBa0IsTUFBTSxZQUFZQyxpQkFBeUMsS0FBSztDQUNsRixrQkFBa0IsTUFBTSxZQUFZQyxrQkFBMEMsTUFBTTtBQUN0Rjs7QUN0SUEsSUFBYSxpQkFBaUI7Q0FDNUIsTUFBTTtDQUNOLE1BQU0sR0FBRyxPQUFPO0VBQ2QsTUFBTSxFQUNKLEdBQUcsTUFDSCxHQUFHLE1BQ0gsT0FBTyxFQUNMLFVBQVUsYUFFWixVQUFVLEVBQ1IsWUFFRixVQUNBLFVBQ0EsY0FDRTtFQUNKLE1BQU0sTUFBTUMsVUFBWSxRQUFRO0VBQ2hDLE1BQU0sU0FBUyxJQUFJLGlCQUFpQixRQUFRO0VBRTVDLElBQUksRUFEa0IsT0FBTyx1QkFBdUIsUUFBUSxPQUFPLHVCQUF1QixLQUV4RixPQUFPO0dBQ0wsR0FBRztHQUNILEdBQUc7R0FDSCxNQUFNO0VBQ1I7RUFFRixNQUFNLGVBQWUsTUFBTSxTQUFTLGtCQUFrQixRQUFRO0VBQzlELElBQUksbUJBQW1CO0dBQ3JCLE9BQU87R0FDUCxRQUFRO0VBQ1Y7RUFHQSxJQUFJLGFBQWEsV0FBVyxLQUFLLGdCQUMvQixtQkFBbUI7R0FDakIsT0FBTyxJQUFJLGVBQWU7R0FDMUIsUUFBUSxJQUFJLGVBQWU7RUFDN0I7T0FDSyxJQUFJLGlCQUFpQixLQUFLO0dBQy9CLE1BQU0sTUFBTSxjQUFjLFFBQVE7R0FDbEMsbUJBQW1CO0lBQ2pCLE9BQU8sSUFBSSxnQkFBZ0I7SUFDM0IsUUFBUSxJQUFJLGdCQUFnQjtHQUM5QjtFQUNGLE9BQU8sSUFBSSxNQUFNLFNBQVMsWUFBWSxZQUFZLEdBQ2hELG1CQUFtQixNQUFNLFNBQVMsY0FBYyxZQUFZO0VBRTlELE1BQU0sY0FBYyxRQUFRLFNBQVM7RUFDckMsSUFBSSxJQUFJO0VBQ1IsSUFBSSxJQUFJO0VBQ1IsSUFBSSxnQkFBZ0IsUUFDbEIsSUFBSSxpQkFBaUIsU0FBUyxPQUFPLFVBQVU7RUFFakQsSUFBSSxnQkFBZ0IsT0FDbEIsSUFBSSxpQkFBaUIsVUFBVSxPQUFPLFVBQVU7RUFFbEQsTUFBTSxRQUFRLGdCQUFnQixTQUFTLFVBQVUsY0FBYztFQUMvRCxNQUFNLFFBQVEsZ0JBQWdCLFFBQVEsV0FBVyxjQUFjO0VBQy9ELE9BQU87R0FDTDtHQUNBO0dBQ0EsTUFBTTtJQUNKO0lBQ0E7R0FDRjtFQUNGO0NBQ0Y7QUFDRjs7Ozs7Ozs7QUNoRUEsSUFBYSxzQkFBc0I7OztBQ1duQyxJQUFhLDRCQUE0QixFQUN2QyxzQkFBcUIsVUFBUyxRQUFRLEdBQ25DQyxzQkFBbUQsTUFDdEQsSUFBSSxLQUNOOzs7OztBQUtBLFNBQWdCLGlCQUFpQixZQUFZO0NBQzNDLE1BQU0sRUFDSixPQUNBLE1BQ0EsYUFDRTtDQUNKLE1BQU0sWUFBWSxhQUFhO0NBQy9CLE1BQU0sZ0JBQWdCLE1BQU0sU0FBUyxzQkFBc0I7Q0FDM0QsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLGlCQUFpQjtDQUN4RCxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxVQUFVLE1BQU0sU0FBUyxTQUFTO0NBQ3hDLE1BQU0sVUFBVSxNQUFNLFNBQVMsU0FBUztDQUN4QyxNQUFNLGVBQWUsTUFBTSxTQUFTLGNBQWM7Q0FDbEQsTUFBTSxvQkFBb0IsTUFBTSxTQUFTLG1CQUFtQjtDQUM1RCxNQUFNLHdCQUF3QixpQkFBaUIsT0FBTyxnQkFBZ0IsSUFBSTtDQUcxRSxNQUFNLG9CQUFvQixtQkFBbUIsaUJBQWlCLE9BQU87Q0FDckUsTUFBTSxrQkFBQSxhQUF3QixPQUFPLElBQUk7Q0FDekMsTUFBTSxDQUFDLHFCQUFxQiwwQkFBQSxhQUFnQyxTQUFTLElBQUk7Q0FDekUsTUFBTSxDQUFDLGtCQUFrQix1QkFBQSxhQUE2QixTQUFTLElBQUk7Q0FDbkUsTUFBTSxzQkFBQSxhQUE0QixPQUFPLElBQUk7Q0FDN0MsTUFBTSx1QkFBQSxhQUE2QixPQUFPLElBQUk7Q0FDOUMsTUFBTSx1QkFBdUIsc0JBQXNCLHFCQUFxQixJQUFJO0NBQzVFLE1BQU0sZUFBZSxrQkFBa0I7Q0FDdkMsTUFBTSx1QkFBQSxhQUE2QixPQUFPLElBQUk7Q0FDOUMsTUFBTSxDQUFDLDJCQUEyQixnQ0FBQSxhQUFzQyxTQUFTLElBQUk7Q0FDckYsTUFBTSxDQUFDLDRCQUE0QixpQ0FBQSxhQUF1QyxTQUFTLEtBQUs7Q0FDeEYseUJBQXlCO0VBQ3ZCLE1BQU0sSUFBSSxrQkFBa0IsY0FBYztFQUMxQyxhQUFhO0dBQ1gsTUFBTSxJQUFJLGtCQUFrQixLQUFBLENBQVM7RUFDdkM7Q0FDRixHQUFHLENBQUMsS0FBSyxDQUFDO0NBQ1YsTUFBTSxzQkFBc0Isd0JBQXdCO0VBQ2xELG9CQUFvQixTQUFTLE1BQU0sWUFBWSxhQUFhLE1BQU07RUFDbEUsb0JBQW9CLFNBQVMsTUFBTSxZQUFZLGNBQWMsTUFBTTtFQUNuRSxxQkFBcUIsU0FBUyxNQUFNLFlBQVksV0FBVyxNQUFNO0NBQ25FLENBQUM7Q0FDRCxNQUFNLDhCQUE4QixtQkFBa0IsdUJBQXNCO0VBQzFFLG9CQUFvQixTQUFTLE1BQU0sZUFBZSxXQUFXO0VBQzdELG9CQUFvQixTQUFTLE1BQU0sZUFBZSxZQUFZO0VBQzlELHFCQUFxQixTQUFTLE1BQU0sZUFBZSxTQUFTO0VBQzVELElBQUksb0JBQ0YsNkJBQTZCLGtCQUFrQjtDQUVuRCxDQUFDO0NBQ0QsTUFBTSxxQkFBcUIsd0JBQXdCO0VBQ2pELHFCQUFxQixTQUFTLE1BQU07RUFDcEMsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0VBQ3ZDLHFCQUFxQixVQUFVO0VBQy9CLDJCQUEyQjtHQUN6Qix1QkFBdUIsSUFBSTtHQUMzQiw2QkFBNkIsSUFBSTtHQUNqQyxnQkFBZ0IsVUFBVTtFQUM1QixHQUFHLFdBQVcsTUFBTTtDQUN0QixDQUFDO0NBQ0QsTUFBTSx3QkFBQSxhQUE4QixPQUFPLElBQUk7Q0FDL0MseUJBQXlCO0VBQ3ZCLElBQUksQ0FBQyxRQUFRLENBQUMsU0FDWixzQkFBc0IsVUFBVTtDQUVwQyxHQUFHLENBQUMsTUFBTSxPQUFPLENBQUM7Q0FDbEIseUJBQXlCO0VBS3ZCLElBQUksUUFBUSxpQkFBaUIseUJBQXlCLGtCQUFrQix5QkFBeUIsc0JBQXNCLFlBQVksaUJBQWlCLGdCQUFnQixTQUFTO0dBQzNLLHVCQUF1QixnQkFBZ0IsT0FBTztHQUM5Qyw4QkFBOEIsSUFBSTtHQUlsQyxNQUFNLFNBQVMsMEJBQTBCLHVCQUF1QixhQUFhO0dBQzdFLG9CQUFvQixNQUFNO0dBQzFCLHNCQUFzQixVQUFVO0VBQ2xDO0NBQ0YsR0FBRztFQUFDO0VBQU07RUFBZTtDQUFxQixDQUFDO0NBUS9DLHlCQUF5QjtFQUN2QixJQUFJLHVCQUF1QixNQUN6QjtFQU1GLHFCQUFxQixTQUFTLE1BQU07RUFDcEMsOEJBQThCLElBQUk7RUFDbEMsYUFBYSxjQUFjO0dBQ3pCLGlCQUFTLGdCQUFnQjtJQUN2Qiw4QkFBOEIsS0FBSztHQUNyQyxDQUFDO0dBQ0QsbUJBQW1CO0VBQ3JCLENBQUM7Q0FDSCxHQUFHO0VBQUM7RUFBbUI7RUFBcUI7RUFBb0I7Q0FBWSxDQUFDO0NBSTdFLHlCQUF5QjtFQU92QixNQUFNLFNBQVMsb0JBQW9CO0VBQ25DLElBQUksQ0FBQyxRQUNIO0VBRUYsTUFBTSxVQUFVLGNBQWMsTUFBTSxDQUFDLENBQUMsY0FBYyxLQUFLO0VBQ3pELEtBQUssTUFBTSxTQUFTLE1BQU0sS0FBSyxPQUFPLFVBQVUsR0FDOUMsUUFBUSxZQUFZLE1BQU0sVUFBVSxJQUFJLENBQUM7RUFFM0MsZ0JBQWdCLFVBQVU7Q0FDNUIsQ0FBQztDQUNELE1BQU0sa0JBQWtCLHVCQUF1QjtDQUMvQyxJQUFJO0NBQ0osSUFBSSxDQUFDLGlCQUNILG1CQUFnQyxlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLE9BQU87RUFDMUMsZ0JBQWdCO0VBQ2hCLEtBQUs7RUFDSztDQUNaLEdBQUcsaUJBQWlCO01BRXBCLG1CQUFnQyxlQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFBLGFBQVksVUFBVSxFQUNwRCxVQUFVLENBQWMsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxPQUFPO0VBQ2xDLGlCQUFpQjtFQUNqQixPQUFPLFdBQVcsSUFBSTtFQUN0QixLQUFLO0VBQ0wsT0FBTztHQUNMLEdBQUksNEJBQTRCO0tBQzdCQyxhQUFnQyxHQUFHLDBCQUEwQixNQUFNO0tBQ25FQyxjQUFpQyxHQUFHLDBCQUEwQixPQUFPO0dBQ3hFLElBQUk7R0FDSixVQUFVO0VBQ1o7RUFDQSxxQkFBcUIsNkJBQTZCLEtBQUEsSUFBWTtDQUNoRSxHQUFHLFVBQVUsR0FBZ0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxPQUFPO0VBQ3ZDLGdCQUFnQjtFQUNoQixLQUFLO0VBQ0wsdUJBQXVCLDZCQUE2QixLQUFLLEtBQUE7RUFDL0M7Q0FDWixHQUFHLGlCQUFpQixDQUFDLEVBQ3ZCLENBQUM7Q0FJSCx5QkFBeUI7RUFDdkIsTUFBTSxZQUFZLHFCQUFxQjtFQUN2QyxJQUFJLENBQUMsYUFBYSxDQUFDLHFCQUNqQjtFQUVGLFVBQVUsZ0JBQWdCLEdBQUcsTUFBTSxLQUFLLG9CQUFvQixVQUFVLENBQUM7Q0FDekUsR0FBRyxDQUFDLG1CQUFtQixDQUFDO0NBQ3hCLG1CQUFtQjtFQUNqQjtFQUNBO0VBQ0E7RUFDQSxTQUFTO0VBQ1QsaUJBQWlCO0VBQ2pCLHlCQUF5QjtFQUN6QjtFQUNBO0NBQ0YsQ0FBQztDQUNELE1BQU0sUUFBUTtFQUNaLHFCQUFxQix1QkFBdUIsZ0JBQWdCO0VBQzVELGVBQWU7Q0FDakI7Q0FDQSxPQUFPO0VBQ0wsVUFBVTtFQUNWO0NBQ0Y7QUFDRjs7Ozs7OztBQU9BLFNBQWdCLHVCQUF1QixRQUFRO0NBQzdDLElBQUksQ0FBQyxRQUNIO0NBRUYsT0FBTyxHQUFHLHNCQUFzQixPQUFPLFlBQVksR0FBRyxTQUFTLE1BQU0sRUFBRSxHQUFHLHNCQUFzQixPQUFPLFVBQVUsR0FBRyxRQUFRLElBQUk7QUFDbEk7Ozs7Ozs7Ozs7O0FBWUEsU0FBUyxzQkFBc0IsT0FBTyxXQUFXLGVBQWUsZUFBZTtDQUM3RSxJQUFJLFFBQVEsV0FDVixPQUFPO0NBRVQsSUFBSSxRQUFRLENBQUMsV0FDWCxPQUFPO0NBRVQsT0FBTztBQUNUOzs7O0FBS0EsU0FBZ0IsMEJBQTBCLE1BQU0sSUFBSTtDQUNsRCxNQUFNLFdBQVcsS0FBSyxzQkFBc0I7Q0FDNUMsTUFBTSxTQUFTLEdBQUcsc0JBQXNCO0NBQ3hDLE1BQU0sYUFBYTtFQUNqQixHQUFHLFNBQVMsT0FBTyxTQUFTLFFBQVE7RUFDcEMsR0FBRyxTQUFTLE1BQU0sU0FBUyxTQUFTO0NBQ3RDO0NBQ0EsTUFBTSxXQUFXO0VBQ2YsR0FBRyxPQUFPLE9BQU8sT0FBTyxRQUFRO0VBQ2hDLEdBQUcsT0FBTyxNQUFNLE9BQU8sU0FBUztDQUNsQztDQUNBLE9BQU87RUFDTCxZQUFZLFNBQVMsSUFBSSxXQUFXO0VBQ3BDLFVBQVUsU0FBUyxJQUFJLFdBQVc7Q0FDcEM7QUFDRjs7OztBQUtBLFNBQVMsbUJBQW1CLGlCQUFpQixTQUFTO0NBQ3BELE1BQU0sQ0FBQyxZQUFZLGlCQUFBLGFBQXVCLFNBQVMsQ0FBQztDQUNwRCxNQUFNLDZCQUFBLGFBQW1DLE9BQU8sZUFBZTtDQUMvRCxNQUFNLHFCQUFBLGFBQTJCLE9BQU8sT0FBTztDQUMvQyxNQUFNLDBCQUFBLGFBQWdDLE9BQU8sS0FBSztDQUNsRCx5QkFBeUI7RUFFdkIsTUFBTSwwQkFBMEIsMkJBQTJCO0VBQzNELE1BQU0sa0JBQWtCLG1CQUFtQjtFQUMzQyxNQUFNLG1CQUFtQixvQkFBb0I7RUFDN0MsTUFBTSxpQkFBaUIsWUFBWTtFQUNuQyxJQUFJLGtCQUFrQjtHQUVwQixlQUFjLFVBQVMsUUFBUSxDQUFDO0dBQ2hDLHdCQUF3QixVQUFVLENBQUM7RUFDckMsT0FBTyxJQUFJLHdCQUF3QixXQUFXLGdCQUFnQjtHQUU1RCxlQUFjLFVBQVMsUUFBUSxDQUFDO0dBQ2hDLHdCQUF3QixVQUFVO0VBQ3BDO0VBR0EsMkJBQTJCLFVBQVU7RUFDckMsbUJBQW1CLFVBQVU7Q0FDL0IsR0FBRyxDQUFDLGlCQUFpQixPQUFPLENBQUM7Q0FDN0IsT0FBTyxHQUFHLG1CQUFtQixVQUFVLEdBQUc7QUFDNUMiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMF19