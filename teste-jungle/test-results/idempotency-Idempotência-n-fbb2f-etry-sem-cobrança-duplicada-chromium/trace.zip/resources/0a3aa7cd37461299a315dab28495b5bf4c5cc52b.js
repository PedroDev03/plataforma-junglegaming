import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/sonner.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { useTheme } from "/node_modules/.vite/deps/next-themes.js?v=e9f94b2e";
import { Toaster as Sonner } from "/node_modules/.vite/deps/sonner.js?v=e9f94b2e";
import { CircleCheckIcon, InfoIcon, TriangleAlertIcon, OctagonXIcon, Loader2Icon } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/sonner.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
const Toaster = (t0) => {
	_s();
	const $ = _c(9);
	if ($[0] !== "c8a19f03a6917f8a6e8f5fa66abc02065f8abe7ed08a70868a410e5c8dbad0fd") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "c8a19f03a6917f8a6e8f5fa66abc02065f8abe7ed08a70868a410e5c8dbad0fd";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	const { theme: t1 } = useTheme();
	const theme = t1 === undefined ? "system" : t1;
	const t2 = theme;
	let t3;
	let t4;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = {
			success: /* @__PURE__ */ _jsxDEV(CircleCheckIcon, { className: "size-4" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 16
			}, this),
			info: /* @__PURE__ */ _jsxDEV(InfoIcon, { className: "size-4" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 13
			}, this),
			warning: /* @__PURE__ */ _jsxDEV(TriangleAlertIcon, { className: "size-4" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 34,
				columnNumber: 16
			}, this),
			error: /* @__PURE__ */ _jsxDEV(OctagonXIcon, { className: "size-4" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 14
			}, this),
			loading: /* @__PURE__ */ _jsxDEV(Loader2Icon, { className: "size-4 animate-spin" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 36,
				columnNumber: 16
			}, this)
		};
		t4 = {
			"--normal-bg": "var(--popover)",
			"--normal-text": "var(--popover-foreground)",
			"--normal-border": "var(--border)",
			"--border-radius": "var(--radius)"
		};
		$[3] = t3;
		$[4] = t4;
	} else {
		t3 = $[3];
		t4 = $[4];
	}
	let t5;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = { classNames: { toast: "cn-toast" } };
		$[5] = t5;
	} else {
		t5 = $[5];
	}
	let t6;
	if ($[6] !== props || $[7] !== t2) {
		t6 = /* @__PURE__ */ _jsxDEV(Sonner, {
			theme: t2,
			className: "toaster group",
			icons: t3,
			style: t4,
			toastOptions: t5,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t2;
		$[8] = t6;
	} else {
		t6 = $[8];
	}
	return t6;
};
_s(Toaster, "j77/rDRstnJZ8jmBpfv55236hS4=", false, function() {
	return [useTheme];
});
_c2 = Toaster;
export { Toaster };
var _c2;
$RefreshReg$(_c2, "Toaster");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/sonner.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/sonner.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/sonner.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/sonner.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxXQUFXQyxjQUFpQztBQUNyRCxTQUFTQyxpQkFBaUJDLFVBQVVDLG1CQUFtQkMsY0FBY0MsbUJBQW1COzs7O0FBRXhGLE1BQU1OLFdBQVVPLE9BQUE7O0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFELElBQUE7RUFBQyxLQUFBTSxTQUFBTjtFQUEwQkMsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFLO0NBQUE7RUFBQUEsUUFBQUwsRUFBQTtDQUFBO0NBQ3pDLFFBQUFNLE9BQUFDLE9BQTZCaEIsU0FBUztDQUE5QixNQUFBZSxRQUFBQyxPQUFBQyxZQUFBLFdBQUFEO0NBSUcsTUFBQUUsS0FBQUg7Q0FBOEIsSUFBQUk7Q0FBQSxJQUFBQztDQUFBLElBQUFYLEVBQUEsT0FBQUcsT0FBQUMsSUFBQTtFQUU5Qk0sS0FBQTtHQUFBRSxTQUVILHdCQUFDLGlCQUFELEVBQTJCLG9CQUFROzs7OztHQUFHQyxNQUd0Qyx3QkFBQyxVQUFELEVBQW9CLG9CQUFROzs7OztHQUFHQyxTQUcvQix3QkFBQyxtQkFBRCxFQUE2QixvQkFBUTs7Ozs7R0FBR0MsT0FHeEMsd0JBQUMsY0FBRCxFQUF3QixvQkFBUTs7Ozs7R0FBR0MsU0FHbkMsd0JBQUMsYUFBRCxFQUF1QixpQ0FBcUI7Ozs7O0VBRWhEO0VBRUVMLEtBQUE7R0FBQSxlQUNpQjtHQUFnQixpQkFDZDtHQUEyQixtQkFDekI7R0FBZSxtQkFDZjtFQUNyQjtFQUFDWCxFQUFBLEtBQUFVO0VBQUFWLEVBQUEsS0FBQVc7Q0FBQTtFQUFBRCxLQUFBVixFQUFBO0VBQUFXLEtBQUFYLEVBQUE7Q0FBQTtDQUFBLElBQUFpQjtDQUFBLElBQUFqQixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFFV2EsS0FBQSxFQUFBQyxZQUNBLEVBQUFDLE9BQ0gsV0FDVCxFQUNGO0VBQUNuQixFQUFBLEtBQUFpQjtDQUFBO0VBQUFBLEtBQUFqQixFQUFBO0NBQUE7Q0FBQSxJQUFBb0I7Q0FBQSxJQUFBcEIsRUFBQSxPQUFBSyxTQUFBTCxFQUFBLE9BQUFTLElBQUE7RUFoQ0hXLEtBQUEsd0JBQUMsUUFBRDtHQUNTLE9BQUFYO0dBQ0c7R0FDSCxPQUFBQztHQWtCTCxPQUFBQztHQU9ZLGNBQUFNO0dBSWIsR0FDR1o7RUFBSzs7Ozs7RUFDVEwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFTO0VBQUFULEVBQUEsS0FBQW9CO0NBQUE7RUFBQUEsS0FBQXBCLEVBQUE7Q0FBQTtDQUFBLE9BbENGb0I7QUFrQ0U7Ozs7O0FBSU4sU0FBUzVCIiwibmFtZXMiOlsidXNlVGhlbWUiLCJUb2FzdGVyIiwiU29ubmVyIiwiQ2lyY2xlQ2hlY2tJY29uIiwiSW5mb0ljb24iLCJUcmlhbmdsZUFsZXJ0SWNvbiIsIk9jdGFnb25YSWNvbiIsIkxvYWRlcjJJY29uIiwidDAiLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsInByb3BzIiwidGhlbWUiLCJ0MSIsInVuZGVmaW5lZCIsInQyIiwidDMiLCJ0NCIsInN1Y2Nlc3MiLCJpbmZvIiwid2FybmluZyIsImVycm9yIiwibG9hZGluZyIsInQ1IiwiY2xhc3NOYW1lcyIsInRvYXN0IiwidDYiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsic29ubmVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gXCJuZXh0LXRoZW1lc1wiXG5pbXBvcnQgeyBUb2FzdGVyIGFzIFNvbm5lciwgdHlwZSBUb2FzdGVyUHJvcHMgfSBmcm9tIFwic29ubmVyXCJcbmltcG9ydCB7IENpcmNsZUNoZWNrSWNvbiwgSW5mb0ljb24sIFRyaWFuZ2xlQWxlcnRJY29uLCBPY3RhZ29uWEljb24sIExvYWRlcjJJY29uIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiXG5cbmNvbnN0IFRvYXN0ZXIgPSAoeyAuLi5wcm9wcyB9OiBUb2FzdGVyUHJvcHMpID0+IHtcbiAgY29uc3QgeyB0aGVtZSA9IFwic3lzdGVtXCIgfSA9IHVzZVRoZW1lKClcblxuICByZXR1cm4gKFxuICAgIDxTb25uZXJcbiAgICAgIHRoZW1lPXt0aGVtZSBhcyBUb2FzdGVyUHJvcHNbXCJ0aGVtZVwiXX1cbiAgICAgIGNsYXNzTmFtZT1cInRvYXN0ZXIgZ3JvdXBcIlxuICAgICAgaWNvbnM9e3tcbiAgICAgICAgc3VjY2VzczogKFxuICAgICAgICAgIDxDaXJjbGVDaGVja0ljb24gY2xhc3NOYW1lPVwic2l6ZS00XCIgLz5cbiAgICAgICAgKSxcbiAgICAgICAgaW5mbzogKFxuICAgICAgICAgIDxJbmZvSWNvbiBjbGFzc05hbWU9XCJzaXplLTRcIiAvPlxuICAgICAgICApLFxuICAgICAgICB3YXJuaW5nOiAoXG4gICAgICAgICAgPFRyaWFuZ2xlQWxlcnRJY29uIGNsYXNzTmFtZT1cInNpemUtNFwiIC8+XG4gICAgICAgICksXG4gICAgICAgIGVycm9yOiAoXG4gICAgICAgICAgPE9jdGFnb25YSWNvbiBjbGFzc05hbWU9XCJzaXplLTRcIiAvPlxuICAgICAgICApLFxuICAgICAgICBsb2FkaW5nOiAoXG4gICAgICAgICAgPExvYWRlcjJJY29uIGNsYXNzTmFtZT1cInNpemUtNCBhbmltYXRlLXNwaW5cIiAvPlxuICAgICAgICApLFxuICAgICAgfX1cbiAgICAgIHN0eWxlPXtcbiAgICAgICAge1xuICAgICAgICAgIFwiLS1ub3JtYWwtYmdcIjogXCJ2YXIoLS1wb3BvdmVyKVwiLFxuICAgICAgICAgIFwiLS1ub3JtYWwtdGV4dFwiOiBcInZhcigtLXBvcG92ZXItZm9yZWdyb3VuZClcIixcbiAgICAgICAgICBcIi0tbm9ybWFsLWJvcmRlclwiOiBcInZhcigtLWJvcmRlcilcIixcbiAgICAgICAgICBcIi0tYm9yZGVyLXJhZGl1c1wiOiBcInZhcigtLXJhZGl1cylcIixcbiAgICAgICAgfSBhcyBSZWFjdC5DU1NQcm9wZXJ0aWVzXG4gICAgICB9XG4gICAgICB0b2FzdE9wdGlvbnM9e3tcbiAgICAgICAgY2xhc3NOYW1lczoge1xuICAgICAgICAgIHRvYXN0OiBcImNuLXRvYXN0XCIsXG4gICAgICAgIH0sXG4gICAgICB9fVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZXhwb3J0IHsgVG9hc3RlciB9XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9jb21wb25lbnRzL3VpL3Nvbm5lci50c3gifQ==