import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=e9f94b2e";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-cNwuCTLA.js?v=e9f94b2e";
import { r as useIsoLayoutEffect, t as useStableCallback } from "/node_modules/.vite/deps/formatErrorMessage-BEgQI17N.js?v=e9f94b2e";
import { a as getNodeName, f as isHTMLElement, g as isShadowRoot, h as isOverflowElement, l as getWindow } from "/node_modules/.vite/deps/floating-ui.utils.dom-B45hE2lE.js?v=e9f94b2e";
import { $ as isTypeableElement, At as addEventListener, B as getNextTabbable, Ct as stopEvent, D as useFloatingTree, Et as webkit, G as tabbable, I as createAttribute, J as mergeCleanups, K as FocusGuard, L as getNodeAncestors, Ot as ios, Q as isTypeableCombobox, R as getNodeChildren, St as isVirtualPointerEvent, U as isOutsideEvent, V as getPreviousTabbable, W as isTabbable, Y as getFloatingFocusElement, bt as isMouseLikePointerType, j as usePortalContext, q as useValueAsRef, xt as isVirtualClick, z as focusable } from "/node_modules/.vite/deps/FloatingRootStore-BMBEPfxq.js?v=e9f94b2e";
import { n as ownerDocument } from "/node_modules/.vite/deps/inertValue-DbKApsSW.js?v=e9f94b2e";
import { c as EMPTY_OBJECT, l as NOOP, o as useMergedRefs } from "/node_modules/.vite/deps/useRenderElement-CvMw8z9e.js?v=e9f94b2e";
import { n as useTimeout, t as Timeout } from "/node_modules/.vite/deps/useTimeout-w0MCIDxv.js?v=e9f94b2e";
import { c as AnimationFrame, i as resolveRef, l as useAnimationFrame } from "/node_modules/.vite/deps/useOpenChangeComplete-BJDlY1Cs.js?v=e9f94b2e";
import { a as isElementVisible, c as activeElement, d as getTarget, l as closest, u as contains } from "/node_modules/.vite/deps/composite-DUPI88po.js?v=e9f94b2e";
import { S as triggerPress, o as focusOut, w as createChangeEventDetails } from "/node_modules/.vite/deps/reason-parts-D-IkPsXA.js?v=e9f94b2e";
import { t as useValueChanged } from "/node_modules/.vite/deps/useValueChanged-DCSKsMx_.js?v=e9f94b2e";
// node_modules/@base-ui/utils/useScrollLock.mjs
var originalHtmlStyles = {};
var originalBodyStyles = {};
var originalHtmlScrollBehavior = "";
function getViewportScroller(html, body) {
	return isOverflowElement(html) ? html : body;
}
function isPageScrollLocked(win, html, body) {
	return /hidden|clip/.test(win.getComputedStyle(getViewportScroller(html, body)).overflowY);
}
function hasInsetScrollbars(referenceElement) {
	if (typeof document === "undefined") return false;
	const doc = ownerDocument(referenceElement);
	return getWindow(doc).innerWidth - doc.documentElement.clientWidth > 0;
}
function supportsStableScrollbarGutter(referenceElement) {
	if (!(typeof CSS !== "undefined" && CSS.supports && CSS.supports("scrollbar-gutter", "stable")) || typeof document === "undefined") return false;
	const doc = ownerDocument(referenceElement);
	const html = doc.documentElement;
	const body = doc.body;
	const scrollContainer = getViewportScroller(html, body);
	const originalScrollContainerOverflowY = scrollContainer.style.overflowY;
	const originalHtmlStyleGutter = html.style.scrollbarGutter;
	html.style.scrollbarGutter = "stable";
	scrollContainer.style.overflowY = "scroll";
	const before = scrollContainer.offsetWidth;
	scrollContainer.style.overflowY = "hidden";
	const after = scrollContainer.offsetWidth;
	scrollContainer.style.overflowY = originalScrollContainerOverflowY;
	html.style.scrollbarGutter = originalHtmlStyleGutter;
	return before === after;
}
function preventScrollOverlayScrollbars(referenceElement) {
	const doc = ownerDocument(referenceElement);
	const html = doc.documentElement;
	const body = doc.body;
	const elementToLock = getViewportScroller(html, body);
	const originalElementToLockStyles = {
		overflowY: elementToLock.style.overflowY,
		overflowX: elementToLock.style.overflowX
	};
	Object.assign(elementToLock.style, {
		overflowY: "hidden",
		overflowX: "hidden"
	});
	return () => {
		Object.assign(elementToLock.style, originalElementToLockStyles);
	};
}
function preventScrollInsetScrollbars(referenceElement) {
	const doc = ownerDocument(referenceElement);
	const html = doc.documentElement;
	const body = doc.body;
	const win = getWindow(html);
	let scrollTop = 0;
	let scrollLeft = 0;
	let updateGutterOnly = false;
	const resizeFrame = AnimationFrame.create();
	if (webkit && (win.visualViewport?.scale ?? 1) !== 1) return () => {};
	function lockScroll() {
		const htmlStyles = win.getComputedStyle(html);
		const bodyStyles = win.getComputedStyle(body);
		const scrollbarGutterValue = (htmlStyles.scrollbarGutter || "").includes("both-edges") ? "stable both-edges" : "stable";
		scrollTop = html.scrollTop;
		scrollLeft = html.scrollLeft;
		originalHtmlStyles = {
			scrollbarGutter: html.style.scrollbarGutter,
			overflowY: html.style.overflowY,
			overflowX: html.style.overflowX
		};
		originalHtmlScrollBehavior = html.style.scrollBehavior;
		originalBodyStyles = {
			position: body.style.position,
			height: body.style.height,
			width: body.style.width,
			boxSizing: body.style.boxSizing,
			overflowY: body.style.overflowY,
			overflowX: body.style.overflowX,
			scrollBehavior: body.style.scrollBehavior
		};
		const isScrollableY = html.scrollHeight > html.clientHeight;
		const isScrollableX = html.scrollWidth > html.clientWidth;
		const hasConstantOverflowY = htmlStyles.overflowY === "scroll" || bodyStyles.overflowY === "scroll";
		const hasConstantOverflowX = htmlStyles.overflowX === "scroll" || bodyStyles.overflowX === "scroll";
		const scrollbarWidth = Math.max(0, win.innerWidth - body.clientWidth);
		const scrollbarHeight = Math.max(0, win.innerHeight - body.clientHeight);
		const marginY = parseFloat(bodyStyles.marginTop) + parseFloat(bodyStyles.marginBottom);
		const marginX = parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight);
		const elementToLock = getViewportScroller(html, body);
		updateGutterOnly = supportsStableScrollbarGutter(referenceElement);
		if (updateGutterOnly) {
			html.style.scrollbarGutter = scrollbarGutterValue;
			elementToLock.style.overflowY = "hidden";
			elementToLock.style.overflowX = "hidden";
			return;
		}
		Object.assign(html.style, {
			scrollbarGutter: scrollbarGutterValue,
			overflowY: "hidden",
			overflowX: "hidden"
		});
		if (isScrollableY || hasConstantOverflowY) html.style.overflowY = "scroll";
		if (isScrollableX || hasConstantOverflowX) html.style.overflowX = "scroll";
		Object.assign(body.style, {
			position: "relative",
			height: marginY || scrollbarHeight ? `calc(100dvh - ${marginY + scrollbarHeight}px)` : "100dvh",
			width: marginX || scrollbarWidth ? `calc(100vw - ${marginX + scrollbarWidth}px)` : "100vw",
			boxSizing: "border-box",
			overflowY: "hidden",
			overflowX: "hidden",
			scrollBehavior: "unset"
		});
		body.scrollTop = scrollTop;
		body.scrollLeft = scrollLeft;
		html.setAttribute("data-base-ui-scroll-locked", "");
		html.style.scrollBehavior = "unset";
	}
	function cleanup() {
		Object.assign(html.style, originalHtmlStyles);
		Object.assign(body.style, originalBodyStyles);
		if (!updateGutterOnly) {
			html.scrollTop = scrollTop;
			html.scrollLeft = scrollLeft;
			html.removeAttribute("data-base-ui-scroll-locked");
			html.style.scrollBehavior = originalHtmlScrollBehavior;
		}
	}
	function handleResize() {
		cleanup();
		resizeFrame.request(lockScroll);
	}
	lockScroll();
	const unsubscribeResize = addEventListener(win, "resize", handleResize);
	return () => {
		resizeFrame.cancel();
		cleanup();
		if (typeof win.removeEventListener === "function") unsubscribeResize();
	};
}
var ScrollLocker = class {
	lockCount = 0;
	restore = null;
	timeoutLock = Timeout.create();
	timeoutUnlock = Timeout.create();
	acquire(referenceElement) {
		this.lockCount += 1;
		if (this.lockCount === 1 && this.restore === null) this.timeoutLock.start(0, () => this.lock(referenceElement));
		return this.release;
	}
	release = () => {
		this.lockCount -= 1;
		if (this.lockCount === 0 && this.restore) this.timeoutUnlock.start(0, this.unlock);
	};
	unlock = () => {
		if (this.lockCount === 0 && this.restore) {
			this.restore?.();
			this.restore = null;
		}
	};
	lock(referenceElement) {
		if (this.lockCount === 0 || this.restore !== null) return;
		const doc = ownerDocument(referenceElement);
		const html = doc.documentElement;
		const body = doc.body;
		const win = getWindow(html);
		if (isPageScrollLocked(win, html, body)) {
			const observer = new win.MutationObserver(() => {
				if (isPageScrollLocked(win, html, body)) return;
				observer.disconnect();
				this.restore = null;
				this.lock(referenceElement);
			});
			const options = { attributes: true };
			observer.observe(html, options);
			observer.observe(body, options);
			this.restore = () => observer.disconnect();
			return;
		}
		const hasOverlayScrollbars = ios || !hasInsetScrollbars(referenceElement);
		this.restore = hasOverlayScrollbars ? preventScrollOverlayScrollbars(referenceElement) : preventScrollInsetScrollbars(referenceElement);
	}
};
var SCROLL_LOCKER = new ScrollLocker();
/**
* Locks the scroll of the document when enabled.
*
* @param enabled - Whether to enable the scroll lock.
* @param referenceElement - Element to use as a reference for lock calculations.
*/
function useScrollLock(enabled = true, referenceElement = null) {
	useIsoLayoutEffect(() => {
		if (!enabled) return;
		return SCROLL_LOCKER.acquire(referenceElement);
	}, [enabled, referenceElement]);
}
// node_modules/@base-ui/react/floating-ui-react/utils/enqueueFocus.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var rafId = 0;
function enqueueFocus(el, options = {}) {
	const { preventScroll = false, sync = false, shouldFocus } = options;
	cancelAnimationFrame(rafId);
	function exec() {
		if (shouldFocus && !shouldFocus()) return;
		el?.focus({ preventScroll });
	}
	if (sync) {
		exec();
		return NOOP;
	}
	const currentRafId = requestAnimationFrame(exec);
	rafId = currentRafId;
	return () => {
		if (rafId === currentRafId) {
			cancelAnimationFrame(currentRafId);
			rafId = 0;
		}
	};
}
// node_modules/@base-ui/react/floating-ui-react/utils/markOthers.mjs
var markerName = "data-base-ui-inert";
var ariaHiddenCounterMap = /* @__PURE__ */ new WeakMap();
var uncontrolledElementsSet = /* @__PURE__ */ new WeakSet();
var markerCounterMap = /* @__PURE__ */ new WeakMap();
var lockCount = 0;
function unwrapHost(node) {
	if (!node) return null;
	return isShadowRoot(node) ? node.host : unwrapHost(node.parentNode);
}
var correctElements = (parent, targets) => targets.map((target) => {
	if (parent.contains(target)) return target;
	const correctedTarget = unwrapHost(target);
	if (parent.contains(correctedTarget)) return correctedTarget;
	return null;
}).filter((x) => x != null);
var buildKeepSet = (targets) => {
	const keep = /* @__PURE__ */ new Set();
	targets.forEach((target) => {
		let node = target;
		while (node && !keep.has(node)) {
			keep.add(node);
			node = node.parentNode;
		}
	});
	return keep;
};
var collectOutsideElements = (root, keepElements, stopElements) => {
	const outside = [];
	const walk = (parent) => {
		if (!parent || stopElements.has(parent)) return;
		Array.from(parent.children).forEach((node) => {
			if (getNodeName(node) === "script") return;
			if (keepElements.has(node)) walk(node);
			else outside.push(node);
		});
	};
	walk(root);
	return outside;
};
function applyAttributeToOthers(uncorrectedAvoidElements, body, ariaHidden, { mark = true }) {
	const avoidElements = correctElements(body, uncorrectedAvoidElements);
	const markerTargets = mark ? collectOutsideElements(body, buildKeepSet(avoidElements), new Set(avoidElements)) : [];
	const hiddenElements = [];
	const markedElements = [];
	if (ariaHidden) {
		const ariaLiveElements = correctElements(body, Array.from(body.querySelectorAll("[aria-live]")));
		const controlElements = avoidElements.concat(ariaLiveElements);
		collectOutsideElements(body, buildKeepSet(controlElements), new Set(controlElements)).forEach((node) => {
			const attr = node.getAttribute("aria-hidden");
			const alreadyHidden = attr !== null && attr !== "false";
			const counterValue = (ariaHiddenCounterMap.get(node) || 0) + 1;
			ariaHiddenCounterMap.set(node, counterValue);
			hiddenElements.push(node);
			if (counterValue === 1 && alreadyHidden) uncontrolledElementsSet.add(node);
			if (!alreadyHidden) node.setAttribute("aria-hidden", "true");
		});
	}
	if (mark) markerTargets.forEach((node) => {
		const markerValue = (markerCounterMap.get(node) || 0) + 1;
		markerCounterMap.set(node, markerValue);
		markedElements.push(node);
		if (markerValue === 1) node.setAttribute(markerName, "");
	});
	lockCount += 1;
	return () => {
		hiddenElements.forEach((element) => {
			const counterValue = (ariaHiddenCounterMap.get(element) || 0) - 1;
			ariaHiddenCounterMap.set(element, counterValue);
			if (!counterValue) {
				if (!uncontrolledElementsSet.has(element)) element.removeAttribute("aria-hidden");
				uncontrolledElementsSet.delete(element);
			}
		});
		if (mark) markedElements.forEach((element) => {
			const markerValue = (markerCounterMap.get(element) || 0) - 1;
			markerCounterMap.set(element, markerValue);
			if (!markerValue) element.removeAttribute(markerName);
		});
		lockCount -= 1;
		if (!lockCount) {
			ariaHiddenCounterMap = /* @__PURE__ */ new WeakMap();
			uncontrolledElementsSet = /* @__PURE__ */ new WeakSet();
			markerCounterMap = /* @__PURE__ */ new WeakMap();
		}
	};
}
function markOthers(avoidElements, options = {}) {
	const { ariaHidden = false, mark = true } = options;
	const body = ownerDocument(avoidElements[0]).body;
	return applyAttributeToOthers(avoidElements, body, ariaHidden, { mark });
}
// node_modules/@base-ui/react/floating-ui-react/components/FloatingFocusManager.mjs
var import_jsx_runtime = require_jsx_runtime();
function getEventType(event, lastInteractionType) {
	const win = getWindow(getTarget(event));
	if (event instanceof win.KeyboardEvent) return "keyboard";
	if (event instanceof win.FocusEvent) return lastInteractionType || "keyboard";
	if ("pointerType" in event) return event.pointerType || (isVirtualClick(event) ? "keyboard" : lastInteractionType || "mouse");
	if ("touches" in event) return "touch";
	if (event instanceof win.MouseEvent) return lastInteractionType || (event.detail === 0 ? "keyboard" : "mouse");
	return "";
}
var LIST_LIMIT = 20;
var previouslyFocusedElements = [];
function clearDisconnectedPreviouslyFocusedElements() {
	previouslyFocusedElements = previouslyFocusedElements.filter((entry) => {
		return entry.deref()?.isConnected;
	});
}
function addPreviouslyFocusedElement(element) {
	clearDisconnectedPreviouslyFocusedElements();
	if (element && getNodeName(element) !== "body") {
		previouslyFocusedElements.push(new WeakRef(element));
		if (previouslyFocusedElements.length > LIST_LIMIT) previouslyFocusedElements = previouslyFocusedElements.slice(-20);
	}
}
function getPreviouslyFocusedElement() {
	clearDisconnectedPreviouslyFocusedElements();
	return previouslyFocusedElements[previouslyFocusedElements.length - 1]?.deref();
}
function getFirstTabbableElement(container) {
	if (!container) return null;
	if (isTabbable(container)) return container;
	return tabbable(container)[0] || container;
}
function handleTabIndex(floatingFocusElement) {
	if (floatingFocusElement.hasAttribute("tabindex") && !floatingFocusElement.hasAttribute("data-tabindex")) return;
	if (!floatingFocusElement.getAttribute("role")?.includes("dialog")) return;
	const tabbableContent = focusable(floatingFocusElement).filter((element) => {
		const dataTabIndex = element.getAttribute("data-tabindex") || "";
		return isTabbable(element) || element.hasAttribute("data-tabindex") && !dataTabIndex.startsWith("-");
	});
	const tabIndex = floatingFocusElement.getAttribute("tabindex");
	if (tabbableContent.length === 0) {
		if (tabIndex !== "0") {
			floatingFocusElement.setAttribute("tabindex", "0");
			floatingFocusElement.setAttribute("data-tabindex", "0");
		}
	} else if (tabIndex !== "-1" || floatingFocusElement.hasAttribute("data-tabindex") && floatingFocusElement.getAttribute("data-tabindex") !== "-1") {
		floatingFocusElement.setAttribute("tabindex", "-1");
		floatingFocusElement.setAttribute("data-tabindex", "-1");
	}
}
/**
* Provides focus management for the floating element.
* @see https://floating-ui.com/docs/FloatingFocusManager
* @internal
*/
function FloatingFocusManager(props) {
	const { context: store, children, disabled = false, initialFocus = true, returnFocus = true, explicitReturnFocus, restoreFocus = false, modal = true, closeOnFocusOut = true, openInteractionType = "", nextFocusableElement, previousFocusableElement, beforeContentFocusGuardRef, externalTree, getInsideElements } = props;
	const open = store.useState("open");
	const domReference = store.useState("domReferenceElement");
	const floating = store.useState("floatingElement");
	const { events, dataRef } = store.context;
	const getNodeId = useStableCallback(() => dataRef.current.floatingContext?.nodeId);
	const ignoreInitialFocus = initialFocus === false;
	const isUntrappedTypeableCombobox = isTypeableCombobox(domReference) && ignoreInitialFocus;
	const initialFocusRef = useValueAsRef(initialFocus);
	const returnFocusRef = useValueAsRef(returnFocus);
	const explicitReturnFocusRef = useValueAsRef(explicitReturnFocus);
	const openInteractionTypeRef = useValueAsRef(openInteractionType);
	const openRef = useValueAsRef(open);
	const tree = useFloatingTree(externalTree);
	const portalContext = usePortalContext();
	const preventReturnFocusRef = import_react.useRef(false);
	const isPointerDownRef = import_react.useRef(false);
	const pointerDownOutsideRef = import_react.useRef(false);
	const lastFocusedTabbableRef = import_react.useRef(null);
	const closeTypeRef = import_react.useRef("");
	const lastInteractionTypeRef = import_react.useRef("");
	const beforeGuardRef = import_react.useRef(null);
	const afterGuardRef = import_react.useRef(null);
	const mergedBeforeGuardRef = useMergedRefs(beforeGuardRef, beforeContentFocusGuardRef, portalContext?.beforeInsideRef);
	const mergedAfterGuardRef = useMergedRefs(afterGuardRef, portalContext?.afterInsideRef);
	const blurTimeout = useTimeout();
	const pointerDownTimeout = useTimeout();
	const restoreFocusFrame = useAnimationFrame();
	const isInsidePortal = portalContext != null;
	const floatingFocusElement = getFloatingFocusElement(floating);
	const getTabbableContent = useStableCallback((container = floatingFocusElement) => {
		return container ? tabbable(container) : [];
	});
	const getResolvedInsideElements = useStableCallback(() => getInsideElements?.().filter((element) => element != null) ?? []);
	import_react.useEffect(() => {
		if (disabled || !modal) return;
		function onKeyDown(event) {
			if (event.key === "Tab") {
				if (contains(floatingFocusElement, activeElement(ownerDocument(floatingFocusElement))) && getTabbableContent().length === 0 && !isUntrappedTypeableCombobox) stopEvent(event);
			}
		}
		const doc = ownerDocument(floatingFocusElement);
		return addEventListener(doc, "keydown", onKeyDown);
	}, [
		disabled,
		floatingFocusElement,
		modal,
		isUntrappedTypeableCombobox,
		getTabbableContent
	]);
	import_react.useEffect(() => {
		if (disabled || !open) return;
		const doc = ownerDocument(floatingFocusElement);
		function clearPointerDownOutside() {
			pointerDownOutsideRef.current = false;
		}
		function onPointerDown(event) {
			const target = getTarget(event);
			const insideElements = getResolvedInsideElements();
			const pointerTargetInside = contains(floating, target) || contains(domReference, target) || contains(portalContext?.portalNode, target) || insideElements.some((element) => element === target || contains(element, target));
			pointerDownOutsideRef.current = !pointerTargetInside;
			lastInteractionTypeRef.current = event.pointerType || "keyboard";
			if (closest(target, `[data-base-ui-click-trigger]`)) {
				isPointerDownRef.current = true;
				pointerDownTimeout.start(0, () => {
					isPointerDownRef.current = false;
				});
			}
		}
		function onKeyDown() {
			lastInteractionTypeRef.current = "keyboard";
		}
		return mergeCleanups(addEventListener(doc, "pointerdown", onPointerDown, true), addEventListener(doc, "pointerup", clearPointerDownOutside, true), addEventListener(doc, "pointercancel", clearPointerDownOutside, true), addEventListener(doc, "keydown", onKeyDown, true), clearPointerDownOutside);
	}, [
		disabled,
		floating,
		domReference,
		floatingFocusElement,
		open,
		portalContext,
		pointerDownTimeout,
		getResolvedInsideElements
	]);
	import_react.useEffect(() => {
		if (disabled || !closeOnFocusOut) return;
		const doc = ownerDocument(floatingFocusElement);
		function handlePointerDown() {
			isPointerDownRef.current = true;
			pointerDownTimeout.start(0, () => {
				isPointerDownRef.current = false;
			});
		}
		function handleFocusIn(event) {
			const target = getTarget(event);
			if (isTabbable(target)) lastFocusedTabbableRef.current = target;
		}
		function handleFocusOutside(event) {
			const relatedTarget = event.relatedTarget;
			const currentTarget = event.currentTarget;
			const target = getTarget(event);
			if (modal && relatedTarget == null && target != null && contains(floating, target)) addPreviouslyFocusedElement(target);
			queueMicrotask(() => {
				const nodeId = getNodeId();
				const triggers = store.context.triggerElements;
				const insideElements = getResolvedInsideElements();
				const isRelatedFocusGuard = relatedTarget?.hasAttribute(createAttribute("focus-guard")) && [
					beforeGuardRef.current,
					afterGuardRef.current,
					portalContext?.beforeInsideRef.current,
					portalContext?.afterInsideRef.current,
					portalContext?.beforeOutsideRef.current,
					portalContext?.afterOutsideRef.current,
					resolveRef(previousFocusableElement),
					resolveRef(nextFocusableElement)
				].includes(relatedTarget);
				const movedToUnrelatedNode = !(contains(domReference, relatedTarget) || contains(floating, relatedTarget) || contains(relatedTarget, floating) || contains(portalContext?.portalNode, relatedTarget) || insideElements.some((element) => element === relatedTarget || contains(element, relatedTarget)) || triggers.hasMatchingElement((trigger) => contains(trigger, relatedTarget)) || isRelatedFocusGuard || tree && (getNodeChildren(tree.nodesRef.current, nodeId).find((node) => contains(node.context?.elements.floating, relatedTarget) || contains(node.context?.elements.domReference, relatedTarget)) || getNodeAncestors(tree.nodesRef.current, nodeId).find((node) => [node.context?.elements.floating, getFloatingFocusElement(node.context?.elements.floating)].includes(relatedTarget) || node.context?.elements.domReference === relatedTarget)));
				if (currentTarget === domReference && floatingFocusElement) handleTabIndex(floatingFocusElement);
				if (restoreFocus && currentTarget !== domReference && !isElementVisible(target) && activeElement(doc) === doc.body) {
					if (isHTMLElement(floatingFocusElement)) {
						floatingFocusElement.focus();
						if (restoreFocus === "popup") {
							restoreFocusFrame.request(() => {
								floatingFocusElement.focus();
							});
							return;
						}
					}
					const tabbableContent = getTabbableContent();
					const prevTabbable = lastFocusedTabbableRef.current;
					const nodeToFocus = (prevTabbable && tabbableContent.includes(prevTabbable) ? prevTabbable : null) || tabbableContent[tabbableContent.length - 1] || floatingFocusElement;
					if (isHTMLElement(nodeToFocus)) nodeToFocus.focus();
				}
				if (dataRef.current.insideReactTree) {
					dataRef.current.insideReactTree = false;
					return;
				}
				if ((isUntrappedTypeableCombobox ? true : !modal) && relatedTarget && movedToUnrelatedNode && !isPointerDownRef.current && (isUntrappedTypeableCombobox || relatedTarget !== getPreviouslyFocusedElement())) {
					preventReturnFocusRef.current = true;
					store.setOpen(false, createChangeEventDetails(focusOut, event));
				}
			});
		}
		function markInsideReactTree() {
			if (pointerDownOutsideRef.current) return;
			dataRef.current.insideReactTree = true;
			blurTimeout.start(0, () => {
				dataRef.current.insideReactTree = false;
			});
		}
		const domReferenceElement = isHTMLElement(domReference) ? domReference : null;
		if (!floating && !domReferenceElement) return;
		return mergeCleanups(domReferenceElement && addEventListener(domReferenceElement, "focusout", handleFocusOutside), domReferenceElement && addEventListener(domReferenceElement, "pointerdown", handlePointerDown), floating && addEventListener(floating, "focusin", handleFocusIn), floating && addEventListener(floating, "focusout", handleFocusOutside), floating && portalContext && addEventListener(floating, "focusout", markInsideReactTree, true));
	}, [
		disabled,
		domReference,
		floating,
		floatingFocusElement,
		modal,
		tree,
		portalContext,
		store,
		closeOnFocusOut,
		restoreFocus,
		getTabbableContent,
		isUntrappedTypeableCombobox,
		getNodeId,
		dataRef,
		blurTimeout,
		pointerDownTimeout,
		restoreFocusFrame,
		nextFocusableElement,
		previousFocusableElement,
		getResolvedInsideElements
	]);
	import_react.useEffect(() => {
		if (disabled || !floating || !open) return;
		const portalNodes = Array.from(portalContext?.portalNode?.querySelectorAll(`[${createAttribute("portal")}]`) || []);
		const rootAncestorComboboxDomReference = (tree ? getNodeAncestors(tree.nodesRef.current, getNodeId()) : []).find((node) => isTypeableCombobox(node.context?.elements.domReference || null))?.context?.elements.domReference;
		const ariaHiddenCleanup = markOthers([
			...[
				floating,
				...portalNodes,
				beforeGuardRef.current,
				afterGuardRef.current,
				portalContext?.beforeOutsideRef.current,
				portalContext?.afterOutsideRef.current,
				...getResolvedInsideElements()
			],
			rootAncestorComboboxDomReference,
			resolveRef(previousFocusableElement),
			resolveRef(nextFocusableElement),
			isUntrappedTypeableCombobox ? domReference : null
		].filter((x) => x != null), {
			ariaHidden: modal || isUntrappedTypeableCombobox,
			mark: false
		});
		const markerCleanup = markOthers([floating, ...portalNodes].filter((x) => x != null));
		return () => {
			markerCleanup();
			ariaHiddenCleanup();
		};
	}, [
		open,
		disabled,
		domReference,
		floating,
		modal,
		portalContext,
		isUntrappedTypeableCombobox,
		tree,
		getNodeId,
		nextFocusableElement,
		previousFocusableElement,
		getResolvedInsideElements
	]);
	useIsoLayoutEffect(() => {
		if (!open || disabled || !isHTMLElement(floatingFocusElement)) return;
		closeTypeRef.current = "";
		lastInteractionTypeRef.current = "";
		const doc = ownerDocument(floatingFocusElement);
		const previouslyFocusedElement = activeElement(doc);
		queueMicrotask(() => {
			const initialFocusValueOrFn = initialFocusRef.current;
			const resolvedInitialFocus = typeof initialFocusValueOrFn === "function" ? initialFocusValueOrFn(openInteractionTypeRef.current || "") : initialFocusValueOrFn;
			if (resolvedInitialFocus === void 0 || resolvedInitialFocus === false) return;
			if (contains(floatingFocusElement, previouslyFocusedElement)) return;
			let focusableElements = null;
			const getDefaultFocusElement = () => {
				if (focusableElements == null) focusableElements = getTabbableContent(floatingFocusElement);
				return focusableElements[0] || floatingFocusElement;
			};
			let elToFocus;
			if (resolvedInitialFocus === true || resolvedInitialFocus === null) elToFocus = getDefaultFocusElement();
			else elToFocus = resolveRef(resolvedInitialFocus);
			elToFocus = elToFocus || getDefaultFocusElement();
			const hadFocusInside = contains(floatingFocusElement, activeElement(doc));
			const openEvent = dataRef.current.openEvent;
			const openedByVirtualPress = openEvent?.type === "mousedown" && isVirtualClick(openEvent);
			enqueueFocus(elToFocus, {
				sync: openedByVirtualPress,
				preventScroll: elToFocus === floatingFocusElement,
				shouldFocus() {
					if (!openRef.current) return false;
					if (hadFocusInside) return true;
					const currentActiveElement = activeElement(doc);
					return !(currentActiveElement !== elToFocus && contains(floatingFocusElement, currentActiveElement));
				}
			});
		});
	}, [
		disabled,
		open,
		floatingFocusElement,
		getTabbableContent,
		initialFocusRef,
		openInteractionTypeRef,
		openRef,
		dataRef
	]);
	const pendingReturnFocusRef = import_react.useRef(null);
	useIsoLayoutEffect(() => {
		if (disabled || !floatingFocusElement) {
			pendingReturnFocusRef.current = null;
			return;
		}
		if (pendingReturnFocusRef.current) {
			pendingReturnFocusRef.current.cancelled = true;
			pendingReturnFocusRef.current = null;
		}
		const doc = ownerDocument(floatingFocusElement);
		const elementFocusedBeforeOpen = activeElement(doc);
		const preferPreviousFocus = openInteractionTypeRef.current == null;
		addPreviouslyFocusedElement(elementFocusedBeforeOpen);
		function onOpenChangeLocal(details) {
			if (!details.open) closeTypeRef.current = getEventType(details.nativeEvent, lastInteractionTypeRef.current);
			if (details.reason === "focus-out" && details.triggerElement?.hasAttribute(createAttribute("focus-guard")) || details.reason === "trigger-hover" && details.nativeEvent.type === "mouseleave") preventReturnFocusRef.current = true;
			if (details.reason !== "outside-press") return;
			if (details.nested) preventReturnFocusRef.current = false;
			else if (isVirtualClick(details.nativeEvent) || isVirtualPointerEvent(details.nativeEvent)) preventReturnFocusRef.current = false;
			else {
				let isPreventScrollSupported = false;
				ownerDocument(floatingFocusElement).createElement("div").focus({ get preventScroll() {
					isPreventScrollSupported = true;
					return false;
				} });
				if (isPreventScrollSupported) preventReturnFocusRef.current = false;
				else preventReturnFocusRef.current = true;
			}
		}
		events.on("openchange", onOpenChangeLocal);
		function getReturnElement(closeType) {
			const returnFocusValueOrFn = returnFocusRef.current;
			let resolvedReturnFocusValue = typeof returnFocusValueOrFn === "function" ? returnFocusValueOrFn(closeType) : returnFocusValueOrFn;
			if (resolvedReturnFocusValue === void 0 || resolvedReturnFocusValue === false) return null;
			if (resolvedReturnFocusValue === null) resolvedReturnFocusValue = true;
			const referenceReturnElement = domReference?.isConnected ? domReference : null;
			const previousReturnElement = elementFocusedBeforeOpen?.isConnected && getNodeName(elementFocusedBeforeOpen) !== "body" ? elementFocusedBeforeOpen : null;
			let defaultReturnElement = preferPreviousFocus ? previousReturnElement || referenceReturnElement : referenceReturnElement || previousReturnElement;
			if (!defaultReturnElement) defaultReturnElement = getPreviouslyFocusedElement() || null;
			if (typeof resolvedReturnFocusValue === "boolean") return defaultReturnElement;
			return resolveRef(resolvedReturnFocusValue) || defaultReturnElement || null;
		}
		return () => {
			events.off("openchange", onOpenChangeLocal);
			const activeEl = activeElement(doc);
			const insideElements = getResolvedInsideElements();
			const isFocusInsideFloatingTree = contains(floating, activeEl) || insideElements.some((element) => element === activeEl || contains(element, activeEl)) || tree && getNodeChildren(tree.nodesRef.current, getNodeId(), false).some((node) => contains(node.context?.elements.floating, activeEl));
			const returnFocusValueOrFn = returnFocusRef.current;
			const closeType = closeTypeRef.current;
			const returnElement = getReturnElement(closeType);
			const job = { cancelled: false };
			pendingReturnFocusRef.current = job;
			queueMicrotask(() => {
				if (pendingReturnFocusRef.current === job) pendingReturnFocusRef.current = null;
				const tabbableReturnElement = getFirstTabbableElement(returnElement);
				const hasExplicitReturnFocus = explicitReturnFocusRef.current ?? typeof returnFocusValueOrFn !== "boolean";
				if (!job.cancelled && returnFocusValueOrFn && !preventReturnFocusRef.current && isHTMLElement(tabbableReturnElement) && (!hasExplicitReturnFocus && tabbableReturnElement !== activeEl && activeEl !== doc.body ? isFocusInsideFloatingTree : true)) {
					const focusOptions = { preventScroll: true };
					if (closeType === "keyboard") focusOptions.focusVisible = true;
					tabbableReturnElement.focus(focusOptions);
				}
				preventReturnFocusRef.current = false;
			});
		};
	}, [
		disabled,
		floating,
		floatingFocusElement,
		returnFocusRef,
		explicitReturnFocusRef,
		openInteractionTypeRef,
		events,
		tree,
		domReference,
		getNodeId,
		getResolvedInsideElements
	]);
	useIsoLayoutEffect(() => {
		if (!webkit || open || !floating) return;
		const activeEl = activeElement(ownerDocument(floating));
		if (!isHTMLElement(activeEl) || !isTypeableElement(activeEl)) return;
		if (contains(floating, activeEl)) activeEl.blur();
	}, [open, floating]);
	useIsoLayoutEffect(() => {
		if (disabled || !portalContext) return;
		portalContext.setFocusManagerState({
			modal,
			closeOnFocusOut,
			open,
			onOpenChange: store.setOpen,
			domReference
		});
		return () => {
			portalContext.setFocusManagerState(null);
		};
	}, [
		disabled,
		portalContext,
		modal,
		open,
		store,
		closeOnFocusOut,
		domReference
	]);
	useIsoLayoutEffect(() => {
		if (disabled || !floatingFocusElement) return;
		handleTabIndex(floatingFocusElement);
		return () => {
			queueMicrotask(clearDisconnectedPreviouslyFocusedElements);
		};
	}, [disabled, floatingFocusElement]);
	const shouldRenderGuards = !disabled && (modal ? !isUntrappedTypeableCombobox : true) && (isInsidePortal || modal);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [
		shouldRenderGuards && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
			"data-type": "inside",
			ref: mergedBeforeGuardRef,
			onFocus: (event) => {
				if (modal) {
					const els = getTabbableContent();
					enqueueFocus(els[els.length - 1]);
				} else if (portalContext?.portalNode) {
					preventReturnFocusRef.current = false;
					if (isOutsideEvent(event, portalContext.portalNode)) getNextTabbable(domReference)?.focus();
					else resolveRef(previousFocusableElement ?? portalContext.beforeOutsideRef)?.focus();
				}
			}
		}),
		children,
		shouldRenderGuards && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
			"data-type": "inside",
			ref: mergedAfterGuardRef,
			onFocus: (event) => {
				if (modal) enqueueFocus(getTabbableContent()[0]);
				else if (portalContext?.portalNode) {
					if (closeOnFocusOut) preventReturnFocusRef.current = true;
					if (isOutsideEvent(event, portalContext.portalNode)) getPreviousTabbable(domReference)?.focus();
					else resolveRef(nextFocusableElement ?? portalContext.afterOutsideRef)?.focus();
				}
			}
		})
	] });
}
// node_modules/@base-ui/react/floating-ui-react/hooks/useClick.mjs
/**
* Opens or closes the floating element when clicking the reference element.
* @see https://floating-ui.com/docs/useClick
*/
function useClick(store, props = {}) {
	const { enabled = true, event: eventOption = "click", toggle = true, ignoreMouse = false, stickIfOpen = true, touchOpenDelay = 0, reason = triggerPress } = props;
	const dataRef = store.context.dataRef;
	const pointerTypeRef = import_react.useRef(void 0);
	const frame = useAnimationFrame();
	const touchOpenTimeout = useTimeout();
	const reference = import_react.useMemo(() => {
		function setOpenWithTouchDelay(nextOpen, nativeEvent, target, pointerType) {
			const details = createChangeEventDetails(reason, nativeEvent, target);
			if (nextOpen && pointerType === "touch" && touchOpenDelay > 0) touchOpenTimeout.start(touchOpenDelay, () => {
				store.setOpen(true, details);
			});
			else store.setOpen(nextOpen, details);
		}
		function getNextOpen(open, currentTarget, isClickLikeOpenEvent) {
			const openEvent = dataRef.current.openEvent;
			const hasClickedOnInactiveTrigger = store.select("domReferenceElement") !== currentTarget;
			if (open && hasClickedOnInactiveTrigger) return true;
			if (!open) return true;
			if (!toggle) return true;
			if (openEvent && (typeof stickIfOpen === "function" ? stickIfOpen() : stickIfOpen)) return !isClickLikeOpenEvent(openEvent.type);
			return false;
		}
		return {
			onPointerDown(event) {
				pointerTypeRef.current = isMouseLikePointerType(event.pointerType, true) && isVirtualPointerEvent(event.nativeEvent) ? "virtual" : event.pointerType;
			},
			onMouseDown(event) {
				const pointerType = pointerTypeRef.current;
				const nativeEvent = event.nativeEvent;
				const open = store.select("open");
				if (event.button !== 0 || eventOption === "click" || isMouseLikePointerType(pointerType, true) && ignoreMouse) return;
				const nextOpen = getNextOpen(open, event.currentTarget, (openEventType) => openEventType === "click" || openEventType === "mousedown");
				const target = getTarget(nativeEvent);
				const isTypeable = isTypeableElement(target);
				if (isTypeable || pointerType === "virtual") {
					setOpenWithTouchDelay(nextOpen, nativeEvent, isTypeable ? target : event.currentTarget, pointerType);
					return;
				}
				const eventCurrentTarget = event.currentTarget;
				frame.request(() => {
					setOpenWithTouchDelay(nextOpen, nativeEvent, eventCurrentTarget, pointerType);
				});
			},
			onClick(event) {
				if (eventOption === "mousedown-only") return;
				const pointerType = pointerTypeRef.current;
				if (eventOption === "mousedown" && pointerType) {
					pointerTypeRef.current = void 0;
					return;
				}
				if (isMouseLikePointerType(pointerType, true) && ignoreMouse) return;
				setOpenWithTouchDelay(getNextOpen(store.select("open"), event.currentTarget, (openEventType) => openEventType === "click" || openEventType === "mousedown" || openEventType === "keydown" || openEventType === "keyup"), event.nativeEvent, event.currentTarget, pointerType);
			},
			onKeyDown() {
				pointerTypeRef.current = void 0;
			}
		};
	}, [
		dataRef,
		eventOption,
		ignoreMouse,
		reason,
		store,
		stickIfOpen,
		toggle,
		frame,
		touchOpenTimeout,
		touchOpenDelay
	]);
	return import_react.useMemo(() => enabled ? { reference } : EMPTY_OBJECT, [enabled, reference]);
}
// node_modules/@base-ui/react/utils/InternalBackdrop.mjs
/**
* @internal
*/
var InternalBackdrop = /*#__PURE__*/ import_react.forwardRef(function InternalBackdrop(props, ref) {
	const { cutout, ...otherProps } = props;
	let clipPath;
	if (cutout) {
		const rect = cutout.getBoundingClientRect();
		clipPath = `polygon(0% 0%,100% 0%,100% 100%,0% 100%,0% 0%,${rect.left}px ${rect.top}px,${rect.left}px ${rect.bottom}px,${rect.right}px ${rect.bottom}px,${rect.right}px ${rect.top}px,${rect.left}px ${rect.top}px)`;
	}
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)("div", {
		ref,
		role: "presentation",
		"data-base-ui-inert": "",
		...otherProps,
		style: {
			position: "fixed",
			inset: 0,
			userSelect: "none",
			WebkitUserSelect: "none",
			clipPath
		}
	});
});
InternalBackdrop.displayName = "InternalBackdrop";
// node_modules/@base-ui/utils/useEnhancedClickHandler.mjs
/**
* Provides a cross-browser way to determine the type of the pointer used to click.
* Safari and Firefox do not provide the PointerEvent to the click handler (they use MouseEvent) yet.
* Additionally, this implementation detects if the click was triggered by the keyboard.
*
* @param handler The function to be called when the button is clicked. The first parameter is the original event and the second parameter is the pointer type.
*/
function useEnhancedClickHandler(handler) {
	const lastClickInteractionTypeRef = import_react.useRef("");
	const handlePointerDown = import_react.useCallback((event) => {
		if (event.defaultPrevented) return;
		lastClickInteractionTypeRef.current = event.pointerType;
		handler(event, event.pointerType);
	}, [handler]);
	return {
		onClick: import_react.useCallback((event) => {
			if (event.detail === 0) {
				handler(event, "keyboard");
				return;
			}
			if ("pointerType" in event) handler(event, event.pointerType);
			else handler(event, lastClickInteractionTypeRef.current);
			lastClickInteractionTypeRef.current = "";
		}, [handler]),
		onPointerDown: handlePointerDown
	};
}
// node_modules/@base-ui/react/utils/useOpenInteractionType.mjs
function useOpenMethodTriggerProps(open, setOpenMethod) {
	const { onClick, onPointerDown } = useEnhancedClickHandler(useStableCallback((_, interactionType) => {
		if (!(typeof open === "function" ? open() : open)) setOpenMethod(interactionType || (ios ? "touch" : ""));
	}));
	return import_react.useMemo(() => ({
		onClick,
		onPointerDown
	}), [onClick, onPointerDown]);
}
/**
* Determines the interaction type (keyboard, mouse, touch, etc.) that opened the component.
*
* @param open The open state of the component.
*/
function useOpenInteractionType(open) {
	const [openMethod, setOpenMethod] = import_react.useState(null);
	const triggerProps = useOpenMethodTriggerProps(open, setOpenMethod);
	useValueChanged(open, (previousOpen) => {
		if (previousOpen && !open) setOpenMethod(null);
	});
	return import_react.useMemo(() => ({
		openMethod,
		triggerProps
	}), [openMethod, triggerProps]);
}
export { useClick as a, useScrollLock as c, InternalBackdrop as i, useOpenMethodTriggerProps as n, FloatingFocusManager as o, useEnhancedClickHandler as r, enqueueFocus as s, useOpenInteractionType as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlT3BlbkludGVyYWN0aW9uVHlwZS1EQUNzYTVIUi5qcyIsIm5hbWVzIjpbIm93bmVyV2luZG93IiwicGxhdGZvcm0uZW5naW5lLndlYmtpdCIsInBsYXRmb3JtLm9zLmlvcyIsIm93bmVyV2luZG93IiwiUkVBU09OUy5mb2N1c091dCIsInBsYXRmb3JtLmVuZ2luZS53ZWJraXQiLCJSRUFTT05TLnRyaWdnZXJQcmVzcyIsInBsYXRmb3JtLm9zLmlvcyJdLCJzb3VyY2VzIjpbIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3VzZVNjcm9sbExvY2subWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvdXRpbHMvZW5xdWV1ZUZvY3VzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL21hcmtPdGhlcnMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvY29tcG9uZW50cy9GbG9hdGluZ0ZvY3VzTWFuYWdlci5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC9ob29rcy91c2VDbGljay5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9JbnRlcm5hbEJhY2tkcm9wLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3VzZUVuaGFuY2VkQ2xpY2tIYW5kbGVyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3V0aWxzL3VzZU9wZW5JbnRlcmFjdGlvblR5cGUubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2UgY2xpZW50JztcblxuaW1wb3J0IHsgaXNPdmVyZmxvd0VsZW1lbnQgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IGFkZEV2ZW50TGlzdGVuZXIgfSBmcm9tIFwiLi9hZGRFdmVudExpc3RlbmVyLm1qc1wiO1xuaW1wb3J0IHsgcGxhdGZvcm0gfSBmcm9tIFwiLi9wbGF0Zm9ybS9pbmRleC5tanNcIjtcbmltcG9ydCB7IG93bmVyRG9jdW1lbnQsIG93bmVyV2luZG93IH0gZnJvbSBcIi4vb3duZXIubWpzXCI7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tIFwiLi91c2VJc29MYXlvdXRFZmZlY3QubWpzXCI7XG5pbXBvcnQgeyBUaW1lb3V0IH0gZnJvbSBcIi4vdXNlVGltZW91dC5tanNcIjtcbmltcG9ydCB7IEFuaW1hdGlvbkZyYW1lIH0gZnJvbSBcIi4vdXNlQW5pbWF0aW9uRnJhbWUubWpzXCI7XG5sZXQgb3JpZ2luYWxIdG1sU3R5bGVzID0ge307XG5sZXQgb3JpZ2luYWxCb2R5U3R5bGVzID0ge307XG5sZXQgb3JpZ2luYWxIdG1sU2Nyb2xsQmVoYXZpb3IgPSAnJztcblxuLy8gVGhlIHZpZXdwb3J0J3Mgb3ZlcmZsb3cgY29tZXMgZnJvbSA8aHRtbD4gd2hlbiBpdCBlc3RhYmxpc2hlcyBpdHMgb3duIHNjcm9sbCBjb250YWluZXIsIGFuZFxuLy8gcHJvcGFnYXRlcyBmcm9tIDxib2R5PiBvdGhlcndpc2UuIEFuIGBvdmVyZmxvd2Agc3R5bGUgb24gdGhlIG90aGVyIGVsZW1lbnQgZG9lc24ndCBsb2NrIHRoZSBwYWdlLlxuZnVuY3Rpb24gZ2V0Vmlld3BvcnRTY3JvbGxlcihodG1sLCBib2R5KSB7XG4gIHJldHVybiBpc092ZXJmbG93RWxlbWVudChodG1sKSA/IGh0bWwgOiBib2R5O1xufVxuZnVuY3Rpb24gaXNQYWdlU2Nyb2xsTG9ja2VkKHdpbiwgaHRtbCwgYm9keSkge1xuICByZXR1cm4gL2hpZGRlbnxjbGlwLy50ZXN0KHdpbi5nZXRDb21wdXRlZFN0eWxlKGdldFZpZXdwb3J0U2Nyb2xsZXIoaHRtbCwgYm9keSkpLm92ZXJmbG93WSk7XG59XG5mdW5jdGlvbiBoYXNJbnNldFNjcm9sbGJhcnMocmVmZXJlbmNlRWxlbWVudCkge1xuICBpZiAodHlwZW9mIGRvY3VtZW50ID09PSAndW5kZWZpbmVkJykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjb25zdCBkb2MgPSBvd25lckRvY3VtZW50KHJlZmVyZW5jZUVsZW1lbnQpO1xuICBjb25zdCB3aW4gPSBvd25lcldpbmRvdyhkb2MpO1xuICByZXR1cm4gd2luLmlubmVyV2lkdGggLSBkb2MuZG9jdW1lbnRFbGVtZW50LmNsaWVudFdpZHRoID4gMDtcbn1cbmZ1bmN0aW9uIHN1cHBvcnRzU3RhYmxlU2Nyb2xsYmFyR3V0dGVyKHJlZmVyZW5jZUVsZW1lbnQpIHtcbiAgY29uc3Qgc3VwcG9ydGVkID0gdHlwZW9mIENTUyAhPT0gJ3VuZGVmaW5lZCcgJiYgQ1NTLnN1cHBvcnRzICYmIENTUy5zdXBwb3J0cygnc2Nyb2xsYmFyLWd1dHRlcicsICdzdGFibGUnKTtcbiAgaWYgKCFzdXBwb3J0ZWQgfHwgdHlwZW9mIGRvY3VtZW50ID09PSAndW5kZWZpbmVkJykge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBjb25zdCBkb2MgPSBvd25lckRvY3VtZW50KHJlZmVyZW5jZUVsZW1lbnQpO1xuICBjb25zdCBodG1sID0gZG9jLmRvY3VtZW50RWxlbWVudDtcbiAgY29uc3QgYm9keSA9IGRvYy5ib2R5O1xuICBjb25zdCBzY3JvbGxDb250YWluZXIgPSBnZXRWaWV3cG9ydFNjcm9sbGVyKGh0bWwsIGJvZHkpO1xuICBjb25zdCBvcmlnaW5hbFNjcm9sbENvbnRhaW5lck92ZXJmbG93WSA9IHNjcm9sbENvbnRhaW5lci5zdHlsZS5vdmVyZmxvd1k7XG4gIGNvbnN0IG9yaWdpbmFsSHRtbFN0eWxlR3V0dGVyID0gaHRtbC5zdHlsZS5zY3JvbGxiYXJHdXR0ZXI7XG4gIGh0bWwuc3R5bGUuc2Nyb2xsYmFyR3V0dGVyID0gJ3N0YWJsZSc7XG4gIHNjcm9sbENvbnRhaW5lci5zdHlsZS5vdmVyZmxvd1kgPSAnc2Nyb2xsJztcbiAgY29uc3QgYmVmb3JlID0gc2Nyb2xsQ29udGFpbmVyLm9mZnNldFdpZHRoO1xuICBzY3JvbGxDb250YWluZXIuc3R5bGUub3ZlcmZsb3dZID0gJ2hpZGRlbic7XG4gIGNvbnN0IGFmdGVyID0gc2Nyb2xsQ29udGFpbmVyLm9mZnNldFdpZHRoO1xuICBzY3JvbGxDb250YWluZXIuc3R5bGUub3ZlcmZsb3dZID0gb3JpZ2luYWxTY3JvbGxDb250YWluZXJPdmVyZmxvd1k7XG4gIGh0bWwuc3R5bGUuc2Nyb2xsYmFyR3V0dGVyID0gb3JpZ2luYWxIdG1sU3R5bGVHdXR0ZXI7XG4gIHJldHVybiBiZWZvcmUgPT09IGFmdGVyO1xufVxuZnVuY3Rpb24gcHJldmVudFNjcm9sbE92ZXJsYXlTY3JvbGxiYXJzKHJlZmVyZW5jZUVsZW1lbnQpIHtcbiAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChyZWZlcmVuY2VFbGVtZW50KTtcbiAgY29uc3QgaHRtbCA9IGRvYy5kb2N1bWVudEVsZW1lbnQ7XG4gIGNvbnN0IGJvZHkgPSBkb2MuYm9keTtcblxuICAvLyBJZiBhbiBgb3ZlcmZsb3dgIHN0eWxlIGlzIHByZXNlbnQgb24gPGh0bWw+LCB3ZSBuZWVkIHRvIGxvY2sgaXQsIGJlY2F1c2UgYSBsb2NrIG9uIDxib2R5PlxuICAvLyB3b24ndCBoYXZlIGFueSBlZmZlY3QuXG4gIC8vIEJ1dCBpZiA8Ym9keT4gaGFzIGFuIGBvdmVyZmxvd2Agc3R5bGUgKGxpa2UgYG92ZXJmbG93LXg6IGhpZGRlbmApLCB3ZSBuZWVkIHRvIGxvY2sgaXRcbiAgLy8gaW5zdGVhZCwgYXMgc3RpY2t5IGVsZW1lbnRzIHNoaWZ0IG90aGVyd2lzZS5cbiAgY29uc3QgZWxlbWVudFRvTG9jayA9IGdldFZpZXdwb3J0U2Nyb2xsZXIoaHRtbCwgYm9keSk7XG4gIGNvbnN0IG9yaWdpbmFsRWxlbWVudFRvTG9ja1N0eWxlcyA9IHtcbiAgICBvdmVyZmxvd1k6IGVsZW1lbnRUb0xvY2suc3R5bGUub3ZlcmZsb3dZLFxuICAgIG92ZXJmbG93WDogZWxlbWVudFRvTG9jay5zdHlsZS5vdmVyZmxvd1hcbiAgfTtcbiAgT2JqZWN0LmFzc2lnbihlbGVtZW50VG9Mb2NrLnN0eWxlLCB7XG4gICAgb3ZlcmZsb3dZOiAnaGlkZGVuJyxcbiAgICBvdmVyZmxvd1g6ICdoaWRkZW4nXG4gIH0pO1xuICByZXR1cm4gKCkgPT4ge1xuICAgIE9iamVjdC5hc3NpZ24oZWxlbWVudFRvTG9jay5zdHlsZSwgb3JpZ2luYWxFbGVtZW50VG9Mb2NrU3R5bGVzKTtcbiAgfTtcbn1cbmZ1bmN0aW9uIHByZXZlbnRTY3JvbGxJbnNldFNjcm9sbGJhcnMocmVmZXJlbmNlRWxlbWVudCkge1xuICBjb25zdCBkb2MgPSBvd25lckRvY3VtZW50KHJlZmVyZW5jZUVsZW1lbnQpO1xuICBjb25zdCBodG1sID0gZG9jLmRvY3VtZW50RWxlbWVudDtcbiAgY29uc3QgYm9keSA9IGRvYy5ib2R5O1xuICBjb25zdCB3aW4gPSBvd25lcldpbmRvdyhodG1sKTtcbiAgbGV0IHNjcm9sbFRvcCA9IDA7XG4gIGxldCBzY3JvbGxMZWZ0ID0gMDtcbiAgbGV0IHVwZGF0ZUd1dHRlck9ubHkgPSBmYWxzZTtcbiAgY29uc3QgcmVzaXplRnJhbWUgPSBBbmltYXRpb25GcmFtZS5jcmVhdGUoKTtcblxuICAvLyBQaW5jaC16b29tIGluIFNhZmFyaSBjYXVzZXMgYSBzaGlmdC4gSnVzdCBkb24ndCBsb2NrIHNjcm9sbCBpZiB0aGVyZSdzIGFueSBwaW5jaC16b29tLlxuICBpZiAocGxhdGZvcm0uZW5naW5lLndlYmtpdCAmJiAod2luLnZpc3VhbFZpZXdwb3J0Py5zY2FsZSA/PyAxKSAhPT0gMSkge1xuICAgIHJldHVybiAoKSA9PiB7fTtcbiAgfVxuICBmdW5jdGlvbiBsb2NrU2Nyb2xsKCkge1xuICAgIC8qIERPTSByZWFkczogKi9cblxuICAgIGNvbnN0IGh0bWxTdHlsZXMgPSB3aW4uZ2V0Q29tcHV0ZWRTdHlsZShodG1sKTtcbiAgICBjb25zdCBib2R5U3R5bGVzID0gd2luLmdldENvbXB1dGVkU3R5bGUoYm9keSk7XG4gICAgY29uc3QgaHRtbFNjcm9sbGJhckd1dHRlclZhbHVlID0gaHRtbFN0eWxlcy5zY3JvbGxiYXJHdXR0ZXIgfHwgJyc7XG4gICAgY29uc3QgaGFzQm90aEVkZ2VzID0gaHRtbFNjcm9sbGJhckd1dHRlclZhbHVlLmluY2x1ZGVzKCdib3RoLWVkZ2VzJyk7XG4gICAgY29uc3Qgc2Nyb2xsYmFyR3V0dGVyVmFsdWUgPSBoYXNCb3RoRWRnZXMgPyAnc3RhYmxlIGJvdGgtZWRnZXMnIDogJ3N0YWJsZSc7XG4gICAgc2Nyb2xsVG9wID0gaHRtbC5zY3JvbGxUb3A7XG4gICAgc2Nyb2xsTGVmdCA9IGh0bWwuc2Nyb2xsTGVmdDtcbiAgICBvcmlnaW5hbEh0bWxTdHlsZXMgPSB7XG4gICAgICBzY3JvbGxiYXJHdXR0ZXI6IGh0bWwuc3R5bGUuc2Nyb2xsYmFyR3V0dGVyLFxuICAgICAgb3ZlcmZsb3dZOiBodG1sLnN0eWxlLm92ZXJmbG93WSxcbiAgICAgIG92ZXJmbG93WDogaHRtbC5zdHlsZS5vdmVyZmxvd1hcbiAgICB9O1xuICAgIG9yaWdpbmFsSHRtbFNjcm9sbEJlaGF2aW9yID0gaHRtbC5zdHlsZS5zY3JvbGxCZWhhdmlvcjtcbiAgICBvcmlnaW5hbEJvZHlTdHlsZXMgPSB7XG4gICAgICBwb3NpdGlvbjogYm9keS5zdHlsZS5wb3NpdGlvbixcbiAgICAgIGhlaWdodDogYm9keS5zdHlsZS5oZWlnaHQsXG4gICAgICB3aWR0aDogYm9keS5zdHlsZS53aWR0aCxcbiAgICAgIGJveFNpemluZzogYm9keS5zdHlsZS5ib3hTaXppbmcsXG4gICAgICBvdmVyZmxvd1k6IGJvZHkuc3R5bGUub3ZlcmZsb3dZLFxuICAgICAgb3ZlcmZsb3dYOiBib2R5LnN0eWxlLm92ZXJmbG93WCxcbiAgICAgIHNjcm9sbEJlaGF2aW9yOiBib2R5LnN0eWxlLnNjcm9sbEJlaGF2aW9yXG4gICAgfTtcbiAgICBjb25zdCBpc1Njcm9sbGFibGVZID0gaHRtbC5zY3JvbGxIZWlnaHQgPiBodG1sLmNsaWVudEhlaWdodDtcbiAgICBjb25zdCBpc1Njcm9sbGFibGVYID0gaHRtbC5zY3JvbGxXaWR0aCA+IGh0bWwuY2xpZW50V2lkdGg7XG4gICAgY29uc3QgaGFzQ29uc3RhbnRPdmVyZmxvd1kgPSBodG1sU3R5bGVzLm92ZXJmbG93WSA9PT0gJ3Njcm9sbCcgfHwgYm9keVN0eWxlcy5vdmVyZmxvd1kgPT09ICdzY3JvbGwnO1xuICAgIGNvbnN0IGhhc0NvbnN0YW50T3ZlcmZsb3dYID0gaHRtbFN0eWxlcy5vdmVyZmxvd1ggPT09ICdzY3JvbGwnIHx8IGJvZHlTdHlsZXMub3ZlcmZsb3dYID09PSAnc2Nyb2xsJztcblxuICAgIC8vIFZhbHVlcyBjYW4gYmUgbmVnYXRpdmUgaW4gRmlyZWZveFxuICAgIGNvbnN0IHNjcm9sbGJhcldpZHRoID0gTWF0aC5tYXgoMCwgd2luLmlubmVyV2lkdGggLSBib2R5LmNsaWVudFdpZHRoKTtcbiAgICBjb25zdCBzY3JvbGxiYXJIZWlnaHQgPSBNYXRoLm1heCgwLCB3aW4uaW5uZXJIZWlnaHQgLSBib2R5LmNsaWVudEhlaWdodCk7XG5cbiAgICAvLyBBdm9pZCBzaGlmdCBkdWUgdG8gdGhlIGRlZmF1bHQgPGJvZHk+IG1hcmdpbi4gVGhpcyBkb2VzIGNhdXNlIGVsZW1lbnRzIHRvIGJlIGNsaXBwZWRcbiAgICAvLyB3aXRoIHdoaXRlc3BhY2UuIFdhcm4gaWYgPGJvZHk+IGhhcyBtYXJnaW5zP1xuICAgIGNvbnN0IG1hcmdpblkgPSBwYXJzZUZsb2F0KGJvZHlTdHlsZXMubWFyZ2luVG9wKSArIHBhcnNlRmxvYXQoYm9keVN0eWxlcy5tYXJnaW5Cb3R0b20pO1xuICAgIGNvbnN0IG1hcmdpblggPSBwYXJzZUZsb2F0KGJvZHlTdHlsZXMubWFyZ2luTGVmdCkgKyBwYXJzZUZsb2F0KGJvZHlTdHlsZXMubWFyZ2luUmlnaHQpO1xuICAgIGNvbnN0IGVsZW1lbnRUb0xvY2sgPSBnZXRWaWV3cG9ydFNjcm9sbGVyKGh0bWwsIGJvZHkpO1xuICAgIHVwZGF0ZUd1dHRlck9ubHkgPSBzdXBwb3J0c1N0YWJsZVNjcm9sbGJhckd1dHRlcihyZWZlcmVuY2VFbGVtZW50KTtcblxuICAgIC8qXG4gICAgICogRE9NIHdyaXRlczpcbiAgICAgKiBEbyBub3QgcmVhZCB0aGUgRE9NIHBhc3QgdGhpcyBwb2ludCFcbiAgICAgKi9cblxuICAgIGlmICh1cGRhdGVHdXR0ZXJPbmx5KSB7XG4gICAgICBodG1sLnN0eWxlLnNjcm9sbGJhckd1dHRlciA9IHNjcm9sbGJhckd1dHRlclZhbHVlO1xuICAgICAgZWxlbWVudFRvTG9jay5zdHlsZS5vdmVyZmxvd1kgPSAnaGlkZGVuJztcbiAgICAgIGVsZW1lbnRUb0xvY2suc3R5bGUub3ZlcmZsb3dYID0gJ2hpZGRlbic7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIE9iamVjdC5hc3NpZ24oaHRtbC5zdHlsZSwge1xuICAgICAgc2Nyb2xsYmFyR3V0dGVyOiBzY3JvbGxiYXJHdXR0ZXJWYWx1ZSxcbiAgICAgIG92ZXJmbG93WTogJ2hpZGRlbicsXG4gICAgICBvdmVyZmxvd1g6ICdoaWRkZW4nXG4gICAgfSk7XG4gICAgaWYgKGlzU2Nyb2xsYWJsZVkgfHwgaGFzQ29uc3RhbnRPdmVyZmxvd1kpIHtcbiAgICAgIGh0bWwuc3R5bGUub3ZlcmZsb3dZID0gJ3Njcm9sbCc7XG4gICAgfVxuICAgIGlmIChpc1Njcm9sbGFibGVYIHx8IGhhc0NvbnN0YW50T3ZlcmZsb3dYKSB7XG4gICAgICBodG1sLnN0eWxlLm92ZXJmbG93WCA9ICdzY3JvbGwnO1xuICAgIH1cbiAgICBPYmplY3QuYXNzaWduKGJvZHkuc3R5bGUsIHtcbiAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgICAgaGVpZ2h0OiBtYXJnaW5ZIHx8IHNjcm9sbGJhckhlaWdodCA/IGBjYWxjKDEwMGR2aCAtICR7bWFyZ2luWSArIHNjcm9sbGJhckhlaWdodH1weClgIDogJzEwMGR2aCcsXG4gICAgICB3aWR0aDogbWFyZ2luWCB8fCBzY3JvbGxiYXJXaWR0aCA/IGBjYWxjKDEwMHZ3IC0gJHttYXJnaW5YICsgc2Nyb2xsYmFyV2lkdGh9cHgpYCA6ICcxMDB2dycsXG4gICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICAgIC8vIEFzc2lnbiB0aGUgbG9uZ2hhbmRzIHRoYXQgYGNsZWFudXBgIHJlc3RvcmVzLCBzbyBub3RoaW5nIGlzIGxlZnQgYmVoaW5kLlxuICAgICAgb3ZlcmZsb3dZOiAnaGlkZGVuJyxcbiAgICAgIG92ZXJmbG93WDogJ2hpZGRlbicsXG4gICAgICBzY3JvbGxCZWhhdmlvcjogJ3Vuc2V0J1xuICAgIH0pO1xuICAgIGJvZHkuc2Nyb2xsVG9wID0gc2Nyb2xsVG9wO1xuICAgIGJvZHkuc2Nyb2xsTGVmdCA9IHNjcm9sbExlZnQ7XG4gICAgaHRtbC5zZXRBdHRyaWJ1dGUoJ2RhdGEtYmFzZS11aS1zY3JvbGwtbG9ja2VkJywgJycpO1xuICAgIGh0bWwuc3R5bGUuc2Nyb2xsQmVoYXZpb3IgPSAndW5zZXQnO1xuICB9XG4gIGZ1bmN0aW9uIGNsZWFudXAoKSB7XG4gICAgT2JqZWN0LmFzc2lnbihodG1sLnN0eWxlLCBvcmlnaW5hbEh0bWxTdHlsZXMpO1xuICAgIE9iamVjdC5hc3NpZ24oYm9keS5zdHlsZSwgb3JpZ2luYWxCb2R5U3R5bGVzKTtcbiAgICBpZiAoIXVwZGF0ZUd1dHRlck9ubHkpIHtcbiAgICAgIGh0bWwuc2Nyb2xsVG9wID0gc2Nyb2xsVG9wO1xuICAgICAgaHRtbC5zY3JvbGxMZWZ0ID0gc2Nyb2xsTGVmdDtcbiAgICAgIGh0bWwucmVtb3ZlQXR0cmlidXRlKCdkYXRhLWJhc2UtdWktc2Nyb2xsLWxvY2tlZCcpO1xuICAgICAgaHRtbC5zdHlsZS5zY3JvbGxCZWhhdmlvciA9IG9yaWdpbmFsSHRtbFNjcm9sbEJlaGF2aW9yO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBoYW5kbGVSZXNpemUoKSB7XG4gICAgY2xlYW51cCgpO1xuICAgIHJlc2l6ZUZyYW1lLnJlcXVlc3QobG9ja1Njcm9sbCk7XG4gIH1cbiAgbG9ja1Njcm9sbCgpO1xuICBjb25zdCB1bnN1YnNjcmliZVJlc2l6ZSA9IGFkZEV2ZW50TGlzdGVuZXIod2luLCAncmVzaXplJywgaGFuZGxlUmVzaXplKTtcbiAgcmV0dXJuICgpID0+IHtcbiAgICByZXNpemVGcmFtZS5jYW5jZWwoKTtcbiAgICBjbGVhbnVwKCk7XG4gICAgLy8gU29tZXRpbWVzIHRoaXMgY2xlYW51cCBjYW4gcnVuIGFmdGVyIHRlc3QgdGVhcmRvd24gYmVjYXVzZSBpdCBpcyBjYWxsZWRcbiAgICAvLyBpbiBhIGBzZXRUaW1lb3V0KGZuLCAwKWAuIEd1YXJkIHRoZSByZXR1cm5lZCBjbGVhbnVwIHRvIGF2b2lkIGNhbGxpbmdcbiAgICAvLyBgcmVtb3ZlRXZlbnRMaXN0ZW5lcmAgd2hlbiBpdCBpcyBubyBsb25nZXIgYXZhaWxhYmxlIGluIHRlc3RzLlxuICAgIGlmICh0eXBlb2Ygd2luLnJlbW92ZUV2ZW50TGlzdGVuZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIHVuc3Vic2NyaWJlUmVzaXplKCk7XG4gICAgfVxuICB9O1xufVxuY2xhc3MgU2Nyb2xsTG9ja2VyIHtcbiAgbG9ja0NvdW50ID0gMDtcbiAgcmVzdG9yZSA9IG51bGw7XG4gIHRpbWVvdXRMb2NrID0gVGltZW91dC5jcmVhdGUoKTtcbiAgdGltZW91dFVubG9jayA9IFRpbWVvdXQuY3JlYXRlKCk7XG4gIGFjcXVpcmUocmVmZXJlbmNlRWxlbWVudCkge1xuICAgIHRoaXMubG9ja0NvdW50ICs9IDE7XG4gICAgaWYgKHRoaXMubG9ja0NvdW50ID09PSAxICYmIHRoaXMucmVzdG9yZSA9PT0gbnVsbCkge1xuICAgICAgdGhpcy50aW1lb3V0TG9jay5zdGFydCgwLCAoKSA9PiB0aGlzLmxvY2socmVmZXJlbmNlRWxlbWVudCkpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5yZWxlYXNlO1xuICB9XG4gIHJlbGVhc2UgPSAoKSA9PiB7XG4gICAgdGhpcy5sb2NrQ291bnQgLT0gMTtcbiAgICBpZiAodGhpcy5sb2NrQ291bnQgPT09IDAgJiYgdGhpcy5yZXN0b3JlKSB7XG4gICAgICB0aGlzLnRpbWVvdXRVbmxvY2suc3RhcnQoMCwgdGhpcy51bmxvY2spO1xuICAgIH1cbiAgfTtcbiAgdW5sb2NrID0gKCkgPT4ge1xuICAgIGlmICh0aGlzLmxvY2tDb3VudCA9PT0gMCAmJiB0aGlzLnJlc3RvcmUpIHtcbiAgICAgIHRoaXMucmVzdG9yZT8uKCk7XG4gICAgICB0aGlzLnJlc3RvcmUgPSBudWxsO1xuICAgIH1cbiAgfTtcbiAgbG9jayhyZWZlcmVuY2VFbGVtZW50KSB7XG4gICAgaWYgKHRoaXMubG9ja0NvdW50ID09PSAwIHx8IHRoaXMucmVzdG9yZSAhPT0gbnVsbCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBkb2MgPSBvd25lckRvY3VtZW50KHJlZmVyZW5jZUVsZW1lbnQpO1xuICAgIGNvbnN0IGh0bWwgPSBkb2MuZG9jdW1lbnRFbGVtZW50O1xuICAgIGNvbnN0IGJvZHkgPSBkb2MuYm9keTtcbiAgICBjb25zdCB3aW4gPSBvd25lcldpbmRvdyhodG1sKTtcblxuICAgIC8vIFRoZSBwYWdlIGlzIGFscmVhZHkgbG9ja2VkLCBlaXRoZXIgYnkgdGhlIHNpdGUgYXV0aG9yIG9yIGJ5IGEgbm9uLUJhc2UgVUkgb3ZlcmxheSB0aGF0XG4gICAgLy8gaGFzbid0IGNsZWFuZWQgdXAgeWV0LiBMZWF2ZSBpdCBhbG9uZSBhbmQgd2FpdCBmb3IgdGhlIGxvY2sgdG8gY2xlYXIgYmVmb3JlIHRha2luZyBvdmVyLFxuICAgIC8vIG90aGVyd2lzZSB3ZSdkIHNuYXBzaG90IHRoZSBsb2NrZWQgc3RhdGUgYW5kIHJlc3RvcmUgaXQgYWZ0ZXIgb3VyIG93biBsb2NrIGlzIHJlbGVhc2VkLlxuICAgIGlmIChpc1BhZ2VTY3JvbGxMb2NrZWQod2luLCBodG1sLCBib2R5KSkge1xuICAgICAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgd2luLk11dGF0aW9uT2JzZXJ2ZXIoKCkgPT4ge1xuICAgICAgICBpZiAoaXNQYWdlU2Nyb2xsTG9ja2VkKHdpbiwgaHRtbCwgYm9keSkpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICB0aGlzLnJlc3RvcmUgPSBudWxsO1xuICAgICAgICB0aGlzLmxvY2socmVmZXJlbmNlRWxlbWVudCk7XG4gICAgICB9KTtcblxuICAgICAgLy8gV2F0Y2ggZXZlcnkgYXR0cmlidXRlOiBsb2NrcyBhcmUgYXBwbGllZCB0aHJvdWdoIGlubGluZSBzdHlsZXMsIGNsYXNzZXMsIG9yIGF0dHJpYnV0ZXNcbiAgICAgIC8vIHBhaXJlZCB3aXRoIGEgc3R5bGVzaGVldCAoYGRhdGEtc2Nyb2xsLWxvY2tlZGAgaW4gcmVhY3QtcmVtb3ZlLXNjcm9sbCwgZm9yIGV4YW1wbGUpLlxuICAgICAgY29uc3Qgb3B0aW9ucyA9IHtcbiAgICAgICAgYXR0cmlidXRlczogdHJ1ZVxuICAgICAgfTtcbiAgICAgIG9ic2VydmVyLm9ic2VydmUoaHRtbCwgb3B0aW9ucyk7XG4gICAgICBvYnNlcnZlci5vYnNlcnZlKGJvZHksIG9wdGlvbnMpO1xuICAgICAgdGhpcy5yZXN0b3JlID0gKCkgPT4gb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBoYXNPdmVybGF5U2Nyb2xsYmFycyA9IHBsYXRmb3JtLm9zLmlvcyB8fCAhaGFzSW5zZXRTY3JvbGxiYXJzKHJlZmVyZW5jZUVsZW1lbnQpO1xuXG4gICAgLy8gT24gaU9TLCBzY3JvbGwgbG9ja2luZyBkb2VzIG5vdCB3b3JrIGlmIHRoZSBuYXZiYXIgaXMgY29sbGFwc2VkLiBEdWUgdG8gbnVtZXJvdXNcbiAgICAvLyBzaWRlIGVmZmVjdHMgYW5kIGJ1Z3MgdGhhdCBhcmlzZSBvbiBpT1MsIGl0IG11c3QgYmUgcmVzZWFyY2hlZCBleHRlbnNpdmVseSBiZWZvcmVcbiAgICAvLyBiZWluZyBlbmFibGVkIHRvIGVuc3VyZSBpdCBkb2Vzbid0IGNhdXNlIHRoZSBmb2xsb3dpbmcgaXNzdWVzOlxuICAgIC8vIC0gVGV4dGJveGVzIG11c3Qgc2Nyb2xsIGludG8gdmlldyB3aGVuIGZvY3VzZWQsIG5vciBjYXVzZSBhIGdsaXRjaHkgc2Nyb2xsIGFuaW1hdGlvbi5cbiAgICAvLyAtIFRoZSBuYXZiYXIgbXVzdCBub3QgZm9yY2UgaXRzZWxmIGludG8gdmlldyBhbmQgY2F1c2UgbGF5b3V0IHNoaWZ0LlxuICAgIC8vIC0gU2Nyb2xsIGNvbnRhaW5lcnMgbXVzdCBub3QgZmxpY2tlciB1cG9uIGNsb3NpbmcgYSBwb3B1cCB3aGVuIGl0IGhhcyBhbiBleGl0IGFuaW1hdGlvbi5cbiAgICB0aGlzLnJlc3RvcmUgPSBoYXNPdmVybGF5U2Nyb2xsYmFycyA/IHByZXZlbnRTY3JvbGxPdmVybGF5U2Nyb2xsYmFycyhyZWZlcmVuY2VFbGVtZW50KSA6IHByZXZlbnRTY3JvbGxJbnNldFNjcm9sbGJhcnMocmVmZXJlbmNlRWxlbWVudCk7XG4gIH1cbn1cbmNvbnN0IFNDUk9MTF9MT0NLRVIgPSBuZXcgU2Nyb2xsTG9ja2VyKCk7XG5cbi8qKlxuICogTG9ja3MgdGhlIHNjcm9sbCBvZiB0aGUgZG9jdW1lbnQgd2hlbiBlbmFibGVkLlxuICpcbiAqIEBwYXJhbSBlbmFibGVkIC0gV2hldGhlciB0byBlbmFibGUgdGhlIHNjcm9sbCBsb2NrLlxuICogQHBhcmFtIHJlZmVyZW5jZUVsZW1lbnQgLSBFbGVtZW50IHRvIHVzZSBhcyBhIHJlZmVyZW5jZSBmb3IgbG9jayBjYWxjdWxhdGlvbnMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VTY3JvbGxMb2NrKGVuYWJsZWQgPSB0cnVlLCByZWZlcmVuY2VFbGVtZW50ID0gbnVsbCkge1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgcmV0dXJuIFNDUk9MTF9MT0NLRVIuYWNxdWlyZShyZWZlcmVuY2VFbGVtZW50KTtcbiAgfSwgW2VuYWJsZWQsIHJlZmVyZW5jZUVsZW1lbnRdKTtcbn0iLCJpbXBvcnQgeyBOT09QIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xubGV0IHJhZklkID0gMDtcbmV4cG9ydCBmdW5jdGlvbiBlbnF1ZXVlRm9jdXMoZWwsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgcHJldmVudFNjcm9sbCA9IGZhbHNlLFxuICAgIHN5bmMgPSBmYWxzZSxcbiAgICBzaG91bGRGb2N1c1xuICB9ID0gb3B0aW9ucztcbiAgY2FuY2VsQW5pbWF0aW9uRnJhbWUocmFmSWQpO1xuICBmdW5jdGlvbiBleGVjKCkge1xuICAgIGlmIChzaG91bGRGb2N1cyAmJiAhc2hvdWxkRm9jdXMoKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBlbD8uZm9jdXMoe1xuICAgICAgcHJldmVudFNjcm9sbFxuICAgIH0pO1xuICB9XG4gIGlmIChzeW5jKSB7XG4gICAgZXhlYygpO1xuICAgIHJldHVybiBOT09QO1xuICB9XG4gIGNvbnN0IGN1cnJlbnRSYWZJZCA9IHJlcXVlc3RBbmltYXRpb25GcmFtZShleGVjKTtcbiAgcmFmSWQgPSBjdXJyZW50UmFmSWQ7XG4gIHJldHVybiAoKSA9PiB7XG4gICAgaWYgKHJhZklkID09PSBjdXJyZW50UmFmSWQpIHtcbiAgICAgIGNhbmNlbEFuaW1hdGlvbkZyYW1lKGN1cnJlbnRSYWZJZCk7XG4gICAgICByYWZJZCA9IDA7XG4gICAgfVxuICB9O1xufSIsIi8vIE1vZGlmaWVkIHRvIGFkZCBjb25kaXRpb25hbCBgYXJpYS1oaWRkZW5gIHN1cHBvcnQ6XG4vLyBodHRwczovL2dpdGh1Yi5jb20vdGhlS2FzaGV5L2FyaWEtaGlkZGVuL2Jsb2IvOTIyMGM4ZjRhNGZkMzVmNjNiZWU1NTEwYTlmNDFhMzcyNjQzODJkNC9zcmMvaW5kZXgudHNcbmltcG9ydCB7IGdldE5vZGVOYW1lLCBpc1NoYWRvd1Jvb3QgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IG93bmVyRG9jdW1lbnQgfSBmcm9tICdAYmFzZS11aS91dGlscy9vd25lcic7XG5jb25zdCBtYXJrZXJOYW1lID0gJ2RhdGEtYmFzZS11aS1pbmVydCc7XG5sZXQgYXJpYUhpZGRlbkNvdW50ZXJNYXAgPSBuZXcgV2Vha01hcCgpO1xubGV0IHVuY29udHJvbGxlZEVsZW1lbnRzU2V0ID0gbmV3IFdlYWtTZXQoKTtcbmxldCBtYXJrZXJDb3VudGVyTWFwID0gbmV3IFdlYWtNYXAoKTtcbmxldCBsb2NrQ291bnQgPSAwO1xuZnVuY3Rpb24gdW53cmFwSG9zdChub2RlKSB7XG4gIGlmICghbm9kZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiBpc1NoYWRvd1Jvb3Qobm9kZSkgPyBub2RlLmhvc3QgOiB1bndyYXBIb3N0KG5vZGUucGFyZW50Tm9kZSk7XG59XG5jb25zdCBjb3JyZWN0RWxlbWVudHMgPSAocGFyZW50LCB0YXJnZXRzKSA9PiB0YXJnZXRzLm1hcCh0YXJnZXQgPT4ge1xuICBpZiAocGFyZW50LmNvbnRhaW5zKHRhcmdldCkpIHtcbiAgICByZXR1cm4gdGFyZ2V0O1xuICB9XG4gIGNvbnN0IGNvcnJlY3RlZFRhcmdldCA9IHVud3JhcEhvc3QodGFyZ2V0KTtcbiAgaWYgKHBhcmVudC5jb250YWlucyhjb3JyZWN0ZWRUYXJnZXQpKSB7XG4gICAgcmV0dXJuIGNvcnJlY3RlZFRhcmdldDtcbiAgfVxuICByZXR1cm4gbnVsbDtcbn0pLmZpbHRlcih4ID0+IHggIT0gbnVsbCk7XG5jb25zdCBidWlsZEtlZXBTZXQgPSB0YXJnZXRzID0+IHtcbiAgY29uc3Qga2VlcCA9IG5ldyBTZXQoKTtcbiAgdGFyZ2V0cy5mb3JFYWNoKHRhcmdldCA9PiB7XG4gICAgbGV0IG5vZGUgPSB0YXJnZXQ7XG4gICAgd2hpbGUgKG5vZGUgJiYgIWtlZXAuaGFzKG5vZGUpKSB7XG4gICAgICBrZWVwLmFkZChub2RlKTtcbiAgICAgIG5vZGUgPSBub2RlLnBhcmVudE5vZGU7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIGtlZXA7XG59O1xuY29uc3QgY29sbGVjdE91dHNpZGVFbGVtZW50cyA9IChyb290LCBrZWVwRWxlbWVudHMsIHN0b3BFbGVtZW50cykgPT4ge1xuICBjb25zdCBvdXRzaWRlID0gW107XG4gIGNvbnN0IHdhbGsgPSBwYXJlbnQgPT4ge1xuICAgIGlmICghcGFyZW50IHx8IHN0b3BFbGVtZW50cy5oYXMocGFyZW50KSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBBcnJheS5mcm9tKHBhcmVudC5jaGlsZHJlbikuZm9yRWFjaChub2RlID0+IHtcbiAgICAgIGlmIChnZXROb2RlTmFtZShub2RlKSA9PT0gJ3NjcmlwdCcpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGtlZXBFbGVtZW50cy5oYXMobm9kZSkpIHtcbiAgICAgICAgd2Fsayhub2RlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG91dHNpZGUucHVzaChub2RlKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfTtcbiAgd2Fsayhyb290KTtcbiAgcmV0dXJuIG91dHNpZGU7XG59O1xuZnVuY3Rpb24gYXBwbHlBdHRyaWJ1dGVUb090aGVycyh1bmNvcnJlY3RlZEF2b2lkRWxlbWVudHMsIGJvZHksIGFyaWFIaWRkZW4sIHtcbiAgbWFyayA9IHRydWVcbn0pIHtcbiAgY29uc3QgYXZvaWRFbGVtZW50cyA9IGNvcnJlY3RFbGVtZW50cyhib2R5LCB1bmNvcnJlY3RlZEF2b2lkRWxlbWVudHMpO1xuICBjb25zdCBtYXJrZXJUYXJnZXRzID0gbWFyayA/IGNvbGxlY3RPdXRzaWRlRWxlbWVudHMoYm9keSwgYnVpbGRLZWVwU2V0KGF2b2lkRWxlbWVudHMpLCBuZXcgU2V0KGF2b2lkRWxlbWVudHMpKSA6IFtdO1xuICBjb25zdCBoaWRkZW5FbGVtZW50cyA9IFtdO1xuICBjb25zdCBtYXJrZWRFbGVtZW50cyA9IFtdO1xuICBpZiAoYXJpYUhpZGRlbikge1xuICAgIGNvbnN0IGFyaWFMaXZlRWxlbWVudHMgPSBjb3JyZWN0RWxlbWVudHMoYm9keSwgQXJyYXkuZnJvbShib2R5LnF1ZXJ5U2VsZWN0b3JBbGwoJ1thcmlhLWxpdmVdJykpKTtcbiAgICBjb25zdCBjb250cm9sRWxlbWVudHMgPSBhdm9pZEVsZW1lbnRzLmNvbmNhdChhcmlhTGl2ZUVsZW1lbnRzKTtcbiAgICBjb25zdCBjb250cm9sVGFyZ2V0cyA9IGNvbGxlY3RPdXRzaWRlRWxlbWVudHMoYm9keSwgYnVpbGRLZWVwU2V0KGNvbnRyb2xFbGVtZW50cyksIG5ldyBTZXQoY29udHJvbEVsZW1lbnRzKSk7XG4gICAgY29udHJvbFRhcmdldHMuZm9yRWFjaChub2RlID0+IHtcbiAgICAgIGNvbnN0IGF0dHIgPSBub2RlLmdldEF0dHJpYnV0ZSgnYXJpYS1oaWRkZW4nKTtcbiAgICAgIGNvbnN0IGFscmVhZHlIaWRkZW4gPSBhdHRyICE9PSBudWxsICYmIGF0dHIgIT09ICdmYWxzZSc7XG4gICAgICBjb25zdCBjb3VudGVyVmFsdWUgPSAoYXJpYUhpZGRlbkNvdW50ZXJNYXAuZ2V0KG5vZGUpIHx8IDApICsgMTtcbiAgICAgIGFyaWFIaWRkZW5Db3VudGVyTWFwLnNldChub2RlLCBjb3VudGVyVmFsdWUpO1xuICAgICAgaGlkZGVuRWxlbWVudHMucHVzaChub2RlKTtcbiAgICAgIGlmIChjb3VudGVyVmFsdWUgPT09IDEgJiYgYWxyZWFkeUhpZGRlbikge1xuICAgICAgICB1bmNvbnRyb2xsZWRFbGVtZW50c1NldC5hZGQobm9kZSk7XG4gICAgICB9XG4gICAgICBpZiAoIWFscmVhZHlIaWRkZW4pIHtcbiAgICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUoJ2FyaWEtaGlkZGVuJywgJ3RydWUnKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBpZiAobWFyaykge1xuICAgIG1hcmtlclRhcmdldHMuZm9yRWFjaChub2RlID0+IHtcbiAgICAgIGNvbnN0IG1hcmtlclZhbHVlID0gKG1hcmtlckNvdW50ZXJNYXAuZ2V0KG5vZGUpIHx8IDApICsgMTtcbiAgICAgIG1hcmtlckNvdW50ZXJNYXAuc2V0KG5vZGUsIG1hcmtlclZhbHVlKTtcbiAgICAgIG1hcmtlZEVsZW1lbnRzLnB1c2gobm9kZSk7XG4gICAgICBpZiAobWFya2VyVmFsdWUgPT09IDEpIHtcbiAgICAgICAgbm9kZS5zZXRBdHRyaWJ1dGUobWFya2VyTmFtZSwgJycpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIGxvY2tDb3VudCArPSAxO1xuICByZXR1cm4gKCkgPT4ge1xuICAgIGhpZGRlbkVsZW1lbnRzLmZvckVhY2goZWxlbWVudCA9PiB7XG4gICAgICBjb25zdCBjb3VudGVyVmFsdWUgPSAoYXJpYUhpZGRlbkNvdW50ZXJNYXAuZ2V0KGVsZW1lbnQpIHx8IDApIC0gMTtcbiAgICAgIGFyaWFIaWRkZW5Db3VudGVyTWFwLnNldChlbGVtZW50LCBjb3VudGVyVmFsdWUpO1xuICAgICAgaWYgKCFjb3VudGVyVmFsdWUpIHtcbiAgICAgICAgaWYgKCF1bmNvbnRyb2xsZWRFbGVtZW50c1NldC5oYXMoZWxlbWVudCkpIHtcbiAgICAgICAgICBlbGVtZW50LnJlbW92ZUF0dHJpYnV0ZSgnYXJpYS1oaWRkZW4nKTtcbiAgICAgICAgfVxuICAgICAgICB1bmNvbnRyb2xsZWRFbGVtZW50c1NldC5kZWxldGUoZWxlbWVudCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgaWYgKG1hcmspIHtcbiAgICAgIG1hcmtlZEVsZW1lbnRzLmZvckVhY2goZWxlbWVudCA9PiB7XG4gICAgICAgIGNvbnN0IG1hcmtlclZhbHVlID0gKG1hcmtlckNvdW50ZXJNYXAuZ2V0KGVsZW1lbnQpIHx8IDApIC0gMTtcbiAgICAgICAgbWFya2VyQ291bnRlck1hcC5zZXQoZWxlbWVudCwgbWFya2VyVmFsdWUpO1xuICAgICAgICBpZiAoIW1hcmtlclZhbHVlKSB7XG4gICAgICAgICAgZWxlbWVudC5yZW1vdmVBdHRyaWJ1dGUobWFya2VyTmFtZSk7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgICBsb2NrQ291bnQgLT0gMTtcbiAgICBpZiAoIWxvY2tDb3VudCkge1xuICAgICAgYXJpYUhpZGRlbkNvdW50ZXJNYXAgPSBuZXcgV2Vha01hcCgpO1xuICAgICAgdW5jb250cm9sbGVkRWxlbWVudHNTZXQgPSBuZXcgV2Vha1NldCgpO1xuICAgICAgbWFya2VyQ291bnRlck1hcCA9IG5ldyBXZWFrTWFwKCk7XG4gICAgfVxuICB9O1xufVxuZXhwb3J0IGZ1bmN0aW9uIG1hcmtPdGhlcnMoYXZvaWRFbGVtZW50cywgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBhcmlhSGlkZGVuID0gZmFsc2UsXG4gICAgbWFyayA9IHRydWVcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGJvZHkgPSBvd25lckRvY3VtZW50KGF2b2lkRWxlbWVudHNbMF0pLmJvZHk7XG4gIHJldHVybiBhcHBseUF0dHJpYnV0ZVRvT3RoZXJzKGF2b2lkRWxlbWVudHMsIGJvZHksIGFyaWFIaWRkZW4sIHtcbiAgICBtYXJrXG4gIH0pO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgZ2V0Tm9kZU5hbWUsIGlzSFRNTEVsZW1lbnQgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IGFkZEV2ZW50TGlzdGVuZXIgfSBmcm9tICdAYmFzZS11aS91dGlscy9hZGRFdmVudExpc3RlbmVyJztcbmltcG9ydCB7IG1lcmdlQ2xlYW51cHMgfSBmcm9tICdAYmFzZS11aS91dGlscy9tZXJnZUNsZWFudXBzJztcbmltcG9ydCB7IHVzZU1lcmdlZFJlZnMgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VNZXJnZWRSZWZzJztcbmltcG9ydCB7IHVzZVZhbHVlQXNSZWYgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VWYWx1ZUFzUmVmJztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZVRpbWVvdXQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VUaW1lb3V0JztcbmltcG9ydCB7IHBsYXRmb3JtIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvcGxhdGZvcm0nO1xuaW1wb3J0IHsgdXNlQW5pbWF0aW9uRnJhbWUgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VBbmltYXRpb25GcmFtZSc7XG5pbXBvcnQgeyBvd25lckRvY3VtZW50LCBvd25lcldpbmRvdyB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL293bmVyJztcbmltcG9ydCB7IEZvY3VzR3VhcmQgfSBmcm9tIFwiLi4vLi4vdXRpbHMvRm9jdXNHdWFyZC5tanNcIjtcbmltcG9ydCB7IGFjdGl2ZUVsZW1lbnQsIGNsb3Nlc3QsIGNvbnRhaW5zLCBnZXRUYXJnZXQsIGlzVHlwZWFibGVDb21ib2JveCwgZ2V0RmxvYXRpbmdGb2N1c0VsZW1lbnQsIGlzVHlwZWFibGVFbGVtZW50IH0gZnJvbSBcIi4uL3V0aWxzL2VsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBpc1ZpcnR1YWxDbGljaywgaXNWaXJ0dWFsUG9pbnRlckV2ZW50LCBzdG9wRXZlbnQgfSBmcm9tIFwiLi4vdXRpbHMvZXZlbnQubWpzXCI7XG5pbXBvcnQgeyB0YWJiYWJsZSwgZm9jdXNhYmxlLCBpc091dHNpZGVFdmVudCwgaXNUYWJiYWJsZSwgZ2V0TmV4dFRhYmJhYmxlLCBnZXRQcmV2aW91c1RhYmJhYmxlIH0gZnJvbSBcIi4uL3V0aWxzL3RhYmJhYmxlLm1qc1wiO1xuaW1wb3J0IHsgZ2V0Tm9kZUFuY2VzdG9ycywgZ2V0Tm9kZUNoaWxkcmVuIH0gZnJvbSBcIi4uL3V0aWxzL25vZGVzLm1qc1wiO1xuaW1wb3J0IHsgaXNFbGVtZW50VmlzaWJsZSB9IGZyb20gXCIuLi91dGlscy9jb21wb3NpdGUubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVBdHRyaWJ1dGUgfSBmcm9tIFwiLi4vdXRpbHMvY3JlYXRlQXR0cmlidXRlLm1qc1wiO1xuaW1wb3J0IHsgZW5xdWV1ZUZvY3VzIH0gZnJvbSBcIi4uL3V0aWxzL2VucXVldWVGb2N1cy5tanNcIjtcbmltcG9ydCB7IG1hcmtPdGhlcnMgfSBmcm9tIFwiLi4vdXRpbHMvbWFya090aGVycy5tanNcIjtcbmltcG9ydCB7IHVzZVBvcnRhbENvbnRleHQgfSBmcm9tIFwiLi9GbG9hdGluZ1BvcnRhbC5tanNcIjtcbmltcG9ydCB7IHVzZUZsb2F0aW5nVHJlZSB9IGZyb20gXCIuL0Zsb2F0aW5nVHJlZS5tanNcIjtcbmltcG9ydCB7IENMSUNLX1RSSUdHRVJfSURFTlRJRklFUiB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY29uc3RhbnRzLm1qc1wiO1xuaW1wb3J0IHsgcmVzb2x2ZVJlZiB9IGZyb20gXCIuLi8uLi91dGlscy9yZXNvbHZlUmVmLm1qc1wiO1xuaW1wb3J0IHsganN4IGFzIF9qc3gsIGpzeHMgYXMgX2pzeHMgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmZ1bmN0aW9uIGdldEV2ZW50VHlwZShldmVudCwgbGFzdEludGVyYWN0aW9uVHlwZSkge1xuICBjb25zdCB3aW4gPSBvd25lcldpbmRvdyhnZXRUYXJnZXQoZXZlbnQpKTtcbiAgaWYgKGV2ZW50IGluc3RhbmNlb2Ygd2luLktleWJvYXJkRXZlbnQpIHtcbiAgICByZXR1cm4gJ2tleWJvYXJkJztcbiAgfVxuICBpZiAoZXZlbnQgaW5zdGFuY2VvZiB3aW4uRm9jdXNFdmVudCkge1xuICAgIC8vIEZvY3VzIGV2ZW50cyBjYW4gYmUgY2F1c2VkIGJ5IGEgcHJlY2VkaW5nIHBvaW50ZXIgaW50ZXJhY3Rpb24gKGUuZy4sIGZvY3Vzb3V0IG9uIG91dHNpZGUgcHJlc3MpLlxuICAgIC8vIFByZWZlciB0aGUgbGFzdCBrbm93biBwb2ludGVyIHR5cGUgaWYgcHJvdmlkZWQsIGVsc2UgdHJlYXQgYXMga2V5Ym9hcmQuXG4gICAgcmV0dXJuIGxhc3RJbnRlcmFjdGlvblR5cGUgfHwgJ2tleWJvYXJkJztcbiAgfVxuICBpZiAoJ3BvaW50ZXJUeXBlJyBpbiBldmVudCkge1xuICAgIC8vIEEgdHJ1c3RlZCBjbGljayB3aXRob3V0IGEgcG9pbnRlclR5cGUgaXMga2V5Ym9hcmQvQVQ7IG9ubHkgc3ludGhlc2l6ZWRcbiAgICAvLyBjbGlja3MgKGUuZy4gYSB0ZXN0IGhhcm5lc3MpIHBhaXIgYW4gZW1wdHkgcG9pbnRlclR5cGUgd2l0aCBhIGNsaWNrIGNvdW50LlxuICAgIHJldHVybiBldmVudC5wb2ludGVyVHlwZSB8fCAoaXNWaXJ0dWFsQ2xpY2soZXZlbnQpID8gJ2tleWJvYXJkJyA6IGxhc3RJbnRlcmFjdGlvblR5cGUgfHwgJ21vdXNlJyk7XG4gIH1cbiAgaWYgKCd0b3VjaGVzJyBpbiBldmVudCkge1xuICAgIHJldHVybiAndG91Y2gnO1xuICB9XG4gIGlmIChldmVudCBpbnN0YW5jZW9mIHdpbi5Nb3VzZUV2ZW50KSB7XG4gICAgLy8gb25DbGljayBldmVudHMgbWF5IG5vdCBjb250YWluIHBvaW50ZXIgZXZlbnRzLCBhbmQgd2lsbCBmYWxsIHRocm91Z2ggdG8gaGVyZVxuICAgIHJldHVybiBsYXN0SW50ZXJhY3Rpb25UeXBlIHx8IChldmVudC5kZXRhaWwgPT09IDAgPyAna2V5Ym9hcmQnIDogJ21vdXNlJyk7XG4gIH1cbiAgcmV0dXJuICcnO1xufVxuY29uc3QgTElTVF9MSU1JVCA9IDIwO1xubGV0IHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudHMgPSBbXTtcbmZ1bmN0aW9uIGNsZWFyRGlzY29ubmVjdGVkUHJldmlvdXNseUZvY3VzZWRFbGVtZW50cygpIHtcbiAgcHJldmlvdXNseUZvY3VzZWRFbGVtZW50cyA9IHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudHMuZmlsdGVyKGVudHJ5ID0+IHtcbiAgICByZXR1cm4gZW50cnkuZGVyZWYoKT8uaXNDb25uZWN0ZWQ7XG4gIH0pO1xufVxuZnVuY3Rpb24gYWRkUHJldmlvdXNseUZvY3VzZWRFbGVtZW50KGVsZW1lbnQpIHtcbiAgY2xlYXJEaXNjb25uZWN0ZWRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzKCk7XG4gIGlmIChlbGVtZW50ICYmIGdldE5vZGVOYW1lKGVsZW1lbnQpICE9PSAnYm9keScpIHtcbiAgICBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzLnB1c2gobmV3IFdlYWtSZWYoZWxlbWVudCkpO1xuICAgIGlmIChwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzLmxlbmd0aCA+IExJU1RfTElNSVQpIHtcbiAgICAgIHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudHMgPSBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzLnNsaWNlKC1MSVNUX0xJTUlUKTtcbiAgICB9XG4gIH1cbn1cbmZ1bmN0aW9uIGdldFByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCgpIHtcbiAgY2xlYXJEaXNjb25uZWN0ZWRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzKCk7XG4gIHJldHVybiBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnRzW3ByZXZpb3VzbHlGb2N1c2VkRWxlbWVudHMubGVuZ3RoIC0gMV0/LmRlcmVmKCk7XG59XG5mdW5jdGlvbiBnZXRGaXJzdFRhYmJhYmxlRWxlbWVudChjb250YWluZXIpIHtcbiAgaWYgKCFjb250YWluZXIpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBpZiAoaXNUYWJiYWJsZShjb250YWluZXIpKSB7XG4gICAgcmV0dXJuIGNvbnRhaW5lcjtcbiAgfVxuICByZXR1cm4gdGFiYmFibGUoY29udGFpbmVyKVswXSB8fCBjb250YWluZXI7XG59XG5mdW5jdGlvbiBoYW5kbGVUYWJJbmRleChmbG9hdGluZ0ZvY3VzRWxlbWVudCkge1xuICBpZiAoZmxvYXRpbmdGb2N1c0VsZW1lbnQuaGFzQXR0cmlidXRlKCd0YWJpbmRleCcpICYmICFmbG9hdGluZ0ZvY3VzRWxlbWVudC5oYXNBdHRyaWJ1dGUoJ2RhdGEtdGFiaW5kZXgnKSkge1xuICAgIHJldHVybjtcbiAgfVxuICBpZiAoIWZsb2F0aW5nRm9jdXNFbGVtZW50LmdldEF0dHJpYnV0ZSgncm9sZScpPy5pbmNsdWRlcygnZGlhbG9nJykpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgY29uc3QgZm9jdXNhYmxlRWxlbWVudHMgPSBmb2N1c2FibGUoZmxvYXRpbmdGb2N1c0VsZW1lbnQpO1xuICBjb25zdCB0YWJiYWJsZUNvbnRlbnQgPSBmb2N1c2FibGVFbGVtZW50cy5maWx0ZXIoZWxlbWVudCA9PiB7XG4gICAgY29uc3QgZGF0YVRhYkluZGV4ID0gZWxlbWVudC5nZXRBdHRyaWJ1dGUoJ2RhdGEtdGFiaW5kZXgnKSB8fCAnJztcbiAgICByZXR1cm4gaXNUYWJiYWJsZShlbGVtZW50KSB8fCBlbGVtZW50Lmhhc0F0dHJpYnV0ZSgnZGF0YS10YWJpbmRleCcpICYmICFkYXRhVGFiSW5kZXguc3RhcnRzV2l0aCgnLScpO1xuICB9KTtcbiAgY29uc3QgdGFiSW5kZXggPSBmbG9hdGluZ0ZvY3VzRWxlbWVudC5nZXRBdHRyaWJ1dGUoJ3RhYmluZGV4Jyk7XG4gIGlmICh0YWJiYWJsZUNvbnRlbnQubGVuZ3RoID09PSAwKSB7XG4gICAgaWYgKHRhYkluZGV4ICE9PSAnMCcpIHtcbiAgICAgIGZsb2F0aW5nRm9jdXNFbGVtZW50LnNldEF0dHJpYnV0ZSgndGFiaW5kZXgnLCAnMCcpO1xuICAgICAgLy8gTWFyayBvdXIgb3duIHdyaXRlIHNvIHRoZSBleHRlcm5hbGx5LW1hbmFnZWQgZWFybHktcmV0dXJuIGFib3ZlIGRvZXNuJ3RcbiAgICAgIC8vIG1pc3Rha2UgaXQgZm9yIGEgdXNlci1hdXRob3JlZCBgdGFiaW5kZXhgIGFuZCBmcmVlemUgbWFuYWdlbWVudC5cbiAgICAgIGZsb2F0aW5nRm9jdXNFbGVtZW50LnNldEF0dHJpYnV0ZSgnZGF0YS10YWJpbmRleCcsICcwJyk7XG4gICAgfVxuICB9IGVsc2UgaWYgKHRhYkluZGV4ICE9PSAnLTEnIHx8IGZsb2F0aW5nRm9jdXNFbGVtZW50Lmhhc0F0dHJpYnV0ZSgnZGF0YS10YWJpbmRleCcpICYmIGZsb2F0aW5nRm9jdXNFbGVtZW50LmdldEF0dHJpYnV0ZSgnZGF0YS10YWJpbmRleCcpICE9PSAnLTEnKSB7XG4gICAgZmxvYXRpbmdGb2N1c0VsZW1lbnQuc2V0QXR0cmlidXRlKCd0YWJpbmRleCcsICctMScpO1xuICAgIGZsb2F0aW5nRm9jdXNFbGVtZW50LnNldEF0dHJpYnV0ZSgnZGF0YS10YWJpbmRleCcsICctMScpO1xuICB9XG59XG4vKipcbiAqIFByb3ZpZGVzIGZvY3VzIG1hbmFnZW1lbnQgZm9yIHRoZSBmbG9hdGluZyBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL0Zsb2F0aW5nRm9jdXNNYW5hZ2VyXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEZsb2F0aW5nRm9jdXNNYW5hZ2VyKHByb3BzKSB7XG4gIGNvbnN0IHtcbiAgICBjb250ZXh0OiBzdG9yZSxcbiAgICBjaGlsZHJlbixcbiAgICBkaXNhYmxlZCA9IGZhbHNlLFxuICAgIGluaXRpYWxGb2N1cyA9IHRydWUsXG4gICAgcmV0dXJuRm9jdXMgPSB0cnVlLFxuICAgIGV4cGxpY2l0UmV0dXJuRm9jdXMsXG4gICAgcmVzdG9yZUZvY3VzID0gZmFsc2UsXG4gICAgbW9kYWwgPSB0cnVlLFxuICAgIGNsb3NlT25Gb2N1c091dCA9IHRydWUsXG4gICAgb3BlbkludGVyYWN0aW9uVHlwZSA9ICcnLFxuICAgIG5leHRGb2N1c2FibGVFbGVtZW50LFxuICAgIHByZXZpb3VzRm9jdXNhYmxlRWxlbWVudCxcbiAgICBiZWZvcmVDb250ZW50Rm9jdXNHdWFyZFJlZixcbiAgICBleHRlcm5hbFRyZWUsXG4gICAgZ2V0SW5zaWRlRWxlbWVudHNcbiAgfSA9IHByb3BzO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3QgZG9tUmVmZXJlbmNlID0gc3RvcmUudXNlU3RhdGUoJ2RvbVJlZmVyZW5jZUVsZW1lbnQnKTtcbiAgY29uc3QgZmxvYXRpbmcgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdFbGVtZW50Jyk7XG4gIGNvbnN0IHtcbiAgICBldmVudHMsXG4gICAgZGF0YVJlZlxuICB9ID0gc3RvcmUuY29udGV4dDtcbiAgY29uc3QgZ2V0Tm9kZUlkID0gdXNlU3RhYmxlQ2FsbGJhY2soKCkgPT4gZGF0YVJlZi5jdXJyZW50LmZsb2F0aW5nQ29udGV4dD8ubm9kZUlkKTtcbiAgY29uc3QgaWdub3JlSW5pdGlhbEZvY3VzID0gaW5pdGlhbEZvY3VzID09PSBmYWxzZTtcbiAgLy8gQSB0eXBlYWJsZSBjb21ib2JveCByZWZlcmVuY2UgKGUuZy4gaW5wdXQvdGV4dGFyZWEpIHdpdGggYGluaXRpYWxGb2N1cz17ZmFsc2V9YFxuICAvLyBoYXMgZGlmZmVyZW50IGZvY3VzIHNlbWFudGljczogZm9jdXMgaXMgbm90IHRyYXBwZWQgaW5zaWRlIHRoZSBmbG9hdGluZyBlbGVtZW50LFxuICAvLyBzbyBpbiB0aGUgbW9kYWwgY2FzZSB0aGUgZ3VhcmRzIGFyZSBub3QgcmVuZGVyZWQsIGJ1dCBgYXJpYS1oaWRkZW5gIGlzIHN0aWxsXG4gIC8vIGFwcGxpZWQgdG8gdGhlIG91dHNpZGUgbm9kZXMuXG4gIGNvbnN0IGlzVW50cmFwcGVkVHlwZWFibGVDb21ib2JveCA9IGlzVHlwZWFibGVDb21ib2JveChkb21SZWZlcmVuY2UpICYmIGlnbm9yZUluaXRpYWxGb2N1cztcbiAgY29uc3QgaW5pdGlhbEZvY3VzUmVmID0gdXNlVmFsdWVBc1JlZihpbml0aWFsRm9jdXMpO1xuICBjb25zdCByZXR1cm5Gb2N1c1JlZiA9IHVzZVZhbHVlQXNSZWYocmV0dXJuRm9jdXMpO1xuICAvLyBSZWFkIHRocm91Z2ggYSByZWYgc28gYSBtaWQtb3BlbiBjaGFuZ2UgY2FuJ3QgcmUtcnVuIHRoZSByZXR1cm4tZm9jdXMgZWZmZWN0LCB3aG9zZSBjbGVhbnVwXG4gIC8vIHdvdWxkIG1vdmUgZm9jdXMgd2hpbGUgdGhlIGZsb2F0aW5nIGVsZW1lbnQgaXMgc3RpbGwgb3Blbi5cbiAgY29uc3QgZXhwbGljaXRSZXR1cm5Gb2N1c1JlZiA9IHVzZVZhbHVlQXNSZWYoZXhwbGljaXRSZXR1cm5Gb2N1cyk7XG4gIGNvbnN0IG9wZW5JbnRlcmFjdGlvblR5cGVSZWYgPSB1c2VWYWx1ZUFzUmVmKG9wZW5JbnRlcmFjdGlvblR5cGUpO1xuICBjb25zdCBvcGVuUmVmID0gdXNlVmFsdWVBc1JlZihvcGVuKTtcbiAgY29uc3QgdHJlZSA9IHVzZUZsb2F0aW5nVHJlZShleHRlcm5hbFRyZWUpO1xuICBjb25zdCBwb3J0YWxDb250ZXh0ID0gdXNlUG9ydGFsQ29udGV4dCgpO1xuICBjb25zdCBwcmV2ZW50UmV0dXJuRm9jdXNSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBjb25zdCBpc1BvaW50ZXJEb3duUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgcG9pbnRlckRvd25PdXRzaWRlUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgbGFzdEZvY3VzZWRUYWJiYWJsZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgY2xvc2VUeXBlUmVmID0gUmVhY3QudXNlUmVmKCcnKTtcbiAgY29uc3QgbGFzdEludGVyYWN0aW9uVHlwZVJlZiA9IFJlYWN0LnVzZVJlZignJyk7XG4gIGNvbnN0IGJlZm9yZUd1YXJkUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBhZnRlckd1YXJkUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBtZXJnZWRCZWZvcmVHdWFyZFJlZiA9IHVzZU1lcmdlZFJlZnMoYmVmb3JlR3VhcmRSZWYsIGJlZm9yZUNvbnRlbnRGb2N1c0d1YXJkUmVmLCBwb3J0YWxDb250ZXh0Py5iZWZvcmVJbnNpZGVSZWYpO1xuICBjb25zdCBtZXJnZWRBZnRlckd1YXJkUmVmID0gdXNlTWVyZ2VkUmVmcyhhZnRlckd1YXJkUmVmLCBwb3J0YWxDb250ZXh0Py5hZnRlckluc2lkZVJlZik7XG4gIGNvbnN0IGJsdXJUaW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICBjb25zdCBwb2ludGVyRG93blRpbWVvdXQgPSB1c2VUaW1lb3V0KCk7XG4gIGNvbnN0IHJlc3RvcmVGb2N1c0ZyYW1lID0gdXNlQW5pbWF0aW9uRnJhbWUoKTtcbiAgY29uc3QgaXNJbnNpZGVQb3J0YWwgPSBwb3J0YWxDb250ZXh0ICE9IG51bGw7XG4gIGNvbnN0IGZsb2F0aW5nRm9jdXNFbGVtZW50ID0gZ2V0RmxvYXRpbmdGb2N1c0VsZW1lbnQoZmxvYXRpbmcpO1xuICBjb25zdCBnZXRUYWJiYWJsZUNvbnRlbnQgPSB1c2VTdGFibGVDYWxsYmFjaygoY29udGFpbmVyID0gZmxvYXRpbmdGb2N1c0VsZW1lbnQpID0+IHtcbiAgICByZXR1cm4gY29udGFpbmVyID8gdGFiYmFibGUoY29udGFpbmVyKSA6IFtdO1xuICB9KTtcbiAgY29uc3QgZ2V0UmVzb2x2ZWRJbnNpZGVFbGVtZW50cyA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IGdldEluc2lkZUVsZW1lbnRzPy4oKS5maWx0ZXIoZWxlbWVudCA9PiBlbGVtZW50ICE9IG51bGwpID8/IFtdKTtcblxuICAvLyBQcmV2ZW50IFRhYiBmcm9tIGVzY2FwaW5nIHRoZSBtb2RhbCB3aGVuIHRoZXJlIGFyZSBubyB0YWJiYWJsZSBlbGVtZW50cy5cbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoZGlzYWJsZWQgfHwgIW1vZGFsKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBmdW5jdGlvbiBvbktleURvd24oZXZlbnQpIHtcbiAgICAgIGlmIChldmVudC5rZXkgPT09ICdUYWInKSB7XG4gICAgICAgIC8vIFRoZSBmb2N1cyBndWFyZHMgaGF2ZSBub3RoaW5nIHRvIGZvY3VzLCBzbyB3ZSBuZWVkIHRvIHN0b3AgdGhlIGV2ZW50LlxuICAgICAgICBpZiAoY29udGFpbnMoZmxvYXRpbmdGb2N1c0VsZW1lbnQsIGFjdGl2ZUVsZW1lbnQob3duZXJEb2N1bWVudChmbG9hdGluZ0ZvY3VzRWxlbWVudCkpKSAmJiBnZXRUYWJiYWJsZUNvbnRlbnQoKS5sZW5ndGggPT09IDAgJiYgIWlzVW50cmFwcGVkVHlwZWFibGVDb21ib2JveCkge1xuICAgICAgICAgIHN0b3BFdmVudChldmVudCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChmbG9hdGluZ0ZvY3VzRWxlbWVudCk7XG4gICAgcmV0dXJuIGFkZEV2ZW50TGlzdGVuZXIoZG9jLCAna2V5ZG93bicsIG9uS2V5RG93bik7XG4gIH0sIFtkaXNhYmxlZCwgZmxvYXRpbmdGb2N1c0VsZW1lbnQsIG1vZGFsLCBpc1VudHJhcHBlZFR5cGVhYmxlQ29tYm9ib3gsIGdldFRhYmJhYmxlQ29udGVudF0pO1xuXG4gIC8vIFRyYWNrIHBvaW50ZXIva2V5Ym9hcmQgaW50ZXJhY3Rpb25zIHRvIGRpc2FtYmlndWF0ZSBmb2N1cyBhbmQgb3V0c2lkZSBwcmVzc2VzLlxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCB8fCAhb3Blbikge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChmbG9hdGluZ0ZvY3VzRWxlbWVudCk7XG4gICAgZnVuY3Rpb24gY2xlYXJQb2ludGVyRG93bk91dHNpZGUoKSB7XG4gICAgICBwb2ludGVyRG93bk91dHNpZGVSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIH1cbiAgICBmdW5jdGlvbiBvblBvaW50ZXJEb3duKGV2ZW50KSB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQpO1xuICAgICAgY29uc3QgaW5zaWRlRWxlbWVudHMgPSBnZXRSZXNvbHZlZEluc2lkZUVsZW1lbnRzKCk7XG4gICAgICBjb25zdCBwb2ludGVyVGFyZ2V0SW5zaWRlID0gY29udGFpbnMoZmxvYXRpbmcsIHRhcmdldCkgfHwgY29udGFpbnMoZG9tUmVmZXJlbmNlLCB0YXJnZXQpIHx8IGNvbnRhaW5zKHBvcnRhbENvbnRleHQ/LnBvcnRhbE5vZGUsIHRhcmdldCkgfHwgaW5zaWRlRWxlbWVudHMuc29tZShlbGVtZW50ID0+IGVsZW1lbnQgPT09IHRhcmdldCB8fCBjb250YWlucyhlbGVtZW50LCB0YXJnZXQpKTtcbiAgICAgIHBvaW50ZXJEb3duT3V0c2lkZVJlZi5jdXJyZW50ID0gIXBvaW50ZXJUYXJnZXRJbnNpZGU7XG4gICAgICBsYXN0SW50ZXJhY3Rpb25UeXBlUmVmLmN1cnJlbnQgPSBldmVudC5wb2ludGVyVHlwZSB8fCAna2V5Ym9hcmQnO1xuICAgICAgaWYgKGNsb3Nlc3QodGFyZ2V0LCBgWyR7Q0xJQ0tfVFJJR0dFUl9JREVOVElGSUVSfV1gKSkge1xuICAgICAgICBpc1BvaW50ZXJEb3duUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICAvLyBSZXNldCBvbiB0aGUgbmV4dCB0aWNrIHNvIGEgc2luZ2xlIGNsaWNrIG9uIGEgY2xpY2stdHJpZ2dlciBkb2Vzbid0XG4gICAgICAgIC8vIHBlcm1hbmVudGx5IHN1cHByZXNzIGZvY3VzLW91dCBjbG9zaW5nIGZvciB0aGUgbGlmZXRpbWUgb2YgdGhlIGluc3RhbmNlLlxuICAgICAgICBwb2ludGVyRG93blRpbWVvdXQuc3RhcnQoMCwgKCkgPT4ge1xuICAgICAgICAgIGlzUG9pbnRlckRvd25SZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gb25LZXlEb3duKCkge1xuICAgICAgbGFzdEludGVyYWN0aW9uVHlwZVJlZi5jdXJyZW50ID0gJ2tleWJvYXJkJztcbiAgICB9XG4gICAgcmV0dXJuIG1lcmdlQ2xlYW51cHMoYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdwb2ludGVyZG93bicsIG9uUG9pbnRlckRvd24sIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ3BvaW50ZXJ1cCcsIGNsZWFyUG9pbnRlckRvd25PdXRzaWRlLCB0cnVlKSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdwb2ludGVyY2FuY2VsJywgY2xlYXJQb2ludGVyRG93bk91dHNpZGUsIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ2tleWRvd24nLCBvbktleURvd24sIHRydWUpLFxuICAgIC8vIEF2b2lkIGEgc3RhbGUgYHRydWVgIGxlYWtpbmcgaW50byB0aGUgbmV4dCBvcGVuIChlLmcuIGtlZXAtbW91bnRlZCBwb3B1cHMpXG4gICAgLy8gaWYgdGhlIHBvcHVwIGRpc21pc3NlZCBiZXR3ZWVuIHBvaW50ZXJkb3duIGFuZCBwb2ludGVydXAuXG4gICAgY2xlYXJQb2ludGVyRG93bk91dHNpZGUpO1xuICB9LCBbZGlzYWJsZWQsIGZsb2F0aW5nLCBkb21SZWZlcmVuY2UsIGZsb2F0aW5nRm9jdXNFbGVtZW50LCBvcGVuLCBwb3J0YWxDb250ZXh0LCBwb2ludGVyRG93blRpbWVvdXQsIGdldFJlc29sdmVkSW5zaWRlRWxlbWVudHNdKTtcblxuICAvLyBDbG9zZSBvbiBmb2N1cyBvdXQgYW5kIHJlc3RvcmUgZm9jdXMgd2l0aGluIHRoZSBmbG9hdGluZyB0cmVlIHdoZW4gbmVlZGVkLlxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCB8fCAhY2xvc2VPbkZvY3VzT3V0KSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBjb25zdCBkb2MgPSBvd25lckRvY3VtZW50KGZsb2F0aW5nRm9jdXNFbGVtZW50KTtcblxuICAgIC8vIEluIFNhZmFyaSwgYnV0dG9ucyBsb3NlIGZvY3VzIHdoZW4gcHJlc3NpbmcgdGhlbS5cbiAgICBmdW5jdGlvbiBoYW5kbGVQb2ludGVyRG93bigpIHtcbiAgICAgIGlzUG9pbnRlckRvd25SZWYuY3VycmVudCA9IHRydWU7XG4gICAgICBwb2ludGVyRG93blRpbWVvdXQuc3RhcnQoMCwgKCkgPT4ge1xuICAgICAgICBpc1BvaW50ZXJEb3duUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVGb2N1c0luKGV2ZW50KSB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQpO1xuICAgICAgaWYgKGlzVGFiYmFibGUodGFyZ2V0KSkge1xuICAgICAgICBsYXN0Rm9jdXNlZFRhYmJhYmxlUmVmLmN1cnJlbnQgPSB0YXJnZXQ7XG4gICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIGhhbmRsZUZvY3VzT3V0c2lkZShldmVudCkge1xuICAgICAgY29uc3QgcmVsYXRlZFRhcmdldCA9IGV2ZW50LnJlbGF0ZWRUYXJnZXQ7XG4gICAgICBjb25zdCBjdXJyZW50VGFyZ2V0ID0gZXZlbnQuY3VycmVudFRhcmdldDtcbiAgICAgIGNvbnN0IHRhcmdldCA9IGdldFRhcmdldChldmVudCk7XG5cbiAgICAgIC8vIFdoZW4gZm9jdXMgaXMgbG9zdCB0byB0aGUgYm9keSAoZS5nLiBvbiBhIGJhY2tkcm9wIHByZXNzKSwgcmVjb3JkIHRoZSBlbGVtZW50IHRoYXRcbiAgICAgIC8vIGhhZCBmb2N1cyBzbyBhIGNvbmZpcm1hdGlvbiBkaWFsb2cgb3BlbmVkIHdoaWxlIHRoZSBib2R5IGlzIGZvY3VzZWQgY2FuIHJldHVybiBmb2N1c1xuICAgICAgLy8gdG8gaXQuIFNjb3BlZCB0byBgbW9kYWxgIHRvIGF2b2lkIG5vbi1tb2RhbCBwb3B1cHMgcG9sbHV0aW5nIHRoZSBzaGFyZWQgc3RhY2suXG4gICAgICBpZiAobW9kYWwgJiYgcmVsYXRlZFRhcmdldCA9PSBudWxsICYmIHRhcmdldCAhPSBudWxsICYmIGNvbnRhaW5zKGZsb2F0aW5nLCB0YXJnZXQpKSB7XG4gICAgICAgIGFkZFByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCh0YXJnZXQpO1xuICAgICAgfVxuICAgICAgcXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuICAgICAgICBjb25zdCBub2RlSWQgPSBnZXROb2RlSWQoKTtcbiAgICAgICAgY29uc3QgdHJpZ2dlcnMgPSBzdG9yZS5jb250ZXh0LnRyaWdnZXJFbGVtZW50cztcbiAgICAgICAgY29uc3QgaW5zaWRlRWxlbWVudHMgPSBnZXRSZXNvbHZlZEluc2lkZUVsZW1lbnRzKCk7XG4gICAgICAgIGNvbnN0IGlzUmVsYXRlZEZvY3VzR3VhcmQgPSByZWxhdGVkVGFyZ2V0Py5oYXNBdHRyaWJ1dGUoY3JlYXRlQXR0cmlidXRlKCdmb2N1cy1ndWFyZCcpKSAmJiBbYmVmb3JlR3VhcmRSZWYuY3VycmVudCwgYWZ0ZXJHdWFyZFJlZi5jdXJyZW50LCBwb3J0YWxDb250ZXh0Py5iZWZvcmVJbnNpZGVSZWYuY3VycmVudCwgcG9ydGFsQ29udGV4dD8uYWZ0ZXJJbnNpZGVSZWYuY3VycmVudCwgcG9ydGFsQ29udGV4dD8uYmVmb3JlT3V0c2lkZVJlZi5jdXJyZW50LCBwb3J0YWxDb250ZXh0Py5hZnRlck91dHNpZGVSZWYuY3VycmVudCwgcmVzb2x2ZVJlZihwcmV2aW91c0ZvY3VzYWJsZUVsZW1lbnQpLCByZXNvbHZlUmVmKG5leHRGb2N1c2FibGVFbGVtZW50KV0uaW5jbHVkZXMocmVsYXRlZFRhcmdldCk7XG4gICAgICAgIGNvbnN0IG1vdmVkVG9VbnJlbGF0ZWROb2RlID0gIShjb250YWlucyhkb21SZWZlcmVuY2UsIHJlbGF0ZWRUYXJnZXQpIHx8IGNvbnRhaW5zKGZsb2F0aW5nLCByZWxhdGVkVGFyZ2V0KSB8fCBjb250YWlucyhyZWxhdGVkVGFyZ2V0LCBmbG9hdGluZykgfHwgY29udGFpbnMocG9ydGFsQ29udGV4dD8ucG9ydGFsTm9kZSwgcmVsYXRlZFRhcmdldCkgfHwgaW5zaWRlRWxlbWVudHMuc29tZShlbGVtZW50ID0+IGVsZW1lbnQgPT09IHJlbGF0ZWRUYXJnZXQgfHwgY29udGFpbnMoZWxlbWVudCwgcmVsYXRlZFRhcmdldCkpIHx8IHRyaWdnZXJzLmhhc01hdGNoaW5nRWxlbWVudCh0cmlnZ2VyID0+IGNvbnRhaW5zKHRyaWdnZXIsIHJlbGF0ZWRUYXJnZXQpKSB8fCBpc1JlbGF0ZWRGb2N1c0d1YXJkIHx8IHRyZWUgJiYgKGdldE5vZGVDaGlsZHJlbih0cmVlLm5vZGVzUmVmLmN1cnJlbnQsIG5vZGVJZCkuZmluZChub2RlID0+IGNvbnRhaW5zKG5vZGUuY29udGV4dD8uZWxlbWVudHMuZmxvYXRpbmcsIHJlbGF0ZWRUYXJnZXQpIHx8IGNvbnRhaW5zKG5vZGUuY29udGV4dD8uZWxlbWVudHMuZG9tUmVmZXJlbmNlLCByZWxhdGVkVGFyZ2V0KSkgfHwgZ2V0Tm9kZUFuY2VzdG9ycyh0cmVlLm5vZGVzUmVmLmN1cnJlbnQsIG5vZGVJZCkuZmluZChub2RlID0+IFtub2RlLmNvbnRleHQ/LmVsZW1lbnRzLmZsb2F0aW5nLCBnZXRGbG9hdGluZ0ZvY3VzRWxlbWVudChub2RlLmNvbnRleHQ/LmVsZW1lbnRzLmZsb2F0aW5nKV0uaW5jbHVkZXMocmVsYXRlZFRhcmdldCkgfHwgbm9kZS5jb250ZXh0Py5lbGVtZW50cy5kb21SZWZlcmVuY2UgPT09IHJlbGF0ZWRUYXJnZXQpKSk7XG4gICAgICAgIGlmIChjdXJyZW50VGFyZ2V0ID09PSBkb21SZWZlcmVuY2UgJiYgZmxvYXRpbmdGb2N1c0VsZW1lbnQpIHtcbiAgICAgICAgICBoYW5kbGVUYWJJbmRleChmbG9hdGluZ0ZvY3VzRWxlbWVudCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBSZXN0b3JlIGZvY3VzIHRvIHRoZSBwcmV2aW91c2x5IGZvY3VzZWQgdGFiYmFibGUgZWxlbWVudCB0byBwcmV2ZW50XG4gICAgICAgIC8vIGZvY3VzIGZyb20gYmVpbmcgbG9zdCBvdXRzaWRlIHRoZSBmbG9hdGluZyB0cmVlLlxuICAgICAgICBpZiAocmVzdG9yZUZvY3VzICYmIGN1cnJlbnRUYXJnZXQgIT09IGRvbVJlZmVyZW5jZSAmJiAhaXNFbGVtZW50VmlzaWJsZSh0YXJnZXQpICYmIGFjdGl2ZUVsZW1lbnQoZG9jKSA9PT0gZG9jLmJvZHkpIHtcbiAgICAgICAgICAvLyBMZXQgYEZsb2F0aW5nUG9ydGFsYCBlZmZlY3Qga25vd3MgdGhhdCBmb2N1cyBpcyBzdGlsbCBpbnNpZGUgdGhlXG4gICAgICAgICAgLy8gZmxvYXRpbmcgdHJlZS5cbiAgICAgICAgICBpZiAoaXNIVE1MRWxlbWVudChmbG9hdGluZ0ZvY3VzRWxlbWVudCkpIHtcbiAgICAgICAgICAgIGZsb2F0aW5nRm9jdXNFbGVtZW50LmZvY3VzKCk7XG4gICAgICAgICAgICAvLyBJZiBleHBsaWNpdGx5IHJlcXVlc3RlZCB0byByZXN0b3JlIGZvY3VzIHRvIHRoZSBwb3B1cCBjb250YWluZXIsIGRvIG5vdCBzZWFyY2hcbiAgICAgICAgICAgIC8vIGZvciB0aGUgbmV4dC9wcmV2aW91cyB0YWJiYWJsZSBlbGVtZW50LlxuICAgICAgICAgICAgaWYgKHJlc3RvcmVGb2N1cyA9PT0gJ3BvcHVwJykge1xuICAgICAgICAgICAgICAvLyBJZiB0aGUgZm9jdXNlZCBlbGVtZW50IGlzIHJlbW92ZWQgb24gcG9pbnRlcmRvd24sIHRoZSBicm93c2VyXG4gICAgICAgICAgICAgIC8vIHRyaWVzIHRvIG1vdmUgZm9jdXMgdG8gaXQgcmlnaHQgYWZ0ZXIgdGhlIGAuZm9jdXMoKWAgY2FsbCBhYm92ZSxcbiAgICAgICAgICAgICAgLy8gYnV0IGJlY2F1c2UgaXQncyByZW1vdmVkIGluIHRoZSBzYW1lIHRpY2ssIGZvY3VzIGlzIGxvc3QgaW5zdGVhZC5cbiAgICAgICAgICAgICAgLy8gUmUtZm9jdXNpbmcgYXN5bmNocm9ub3VzbHkgKG5leHQgZnJhbWUpIHdpbnMgdGhhdCByYWNlLlxuICAgICAgICAgICAgICByZXN0b3JlRm9jdXNGcmFtZS5yZXF1ZXN0KCgpID0+IHtcbiAgICAgICAgICAgICAgICBmbG9hdGluZ0ZvY3VzRWxlbWVudC5mb2N1cygpO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCB0YWJiYWJsZUNvbnRlbnQgPSBnZXRUYWJiYWJsZUNvbnRlbnQoKTtcbiAgICAgICAgICBjb25zdCBwcmV2VGFiYmFibGUgPSBsYXN0Rm9jdXNlZFRhYmJhYmxlUmVmLmN1cnJlbnQ7XG4gICAgICAgICAgY29uc3Qgbm9kZVRvRm9jdXMgPSAocHJldlRhYmJhYmxlICYmIHRhYmJhYmxlQ29udGVudC5pbmNsdWRlcyhwcmV2VGFiYmFibGUpID8gcHJldlRhYmJhYmxlIDogbnVsbCkgfHwgdGFiYmFibGVDb250ZW50W3RhYmJhYmxlQ29udGVudC5sZW5ndGggLSAxXSB8fCBmbG9hdGluZ0ZvY3VzRWxlbWVudDtcbiAgICAgICAgICBpZiAoaXNIVE1MRWxlbWVudChub2RlVG9Gb2N1cykpIHtcbiAgICAgICAgICAgIG5vZGVUb0ZvY3VzLmZvY3VzKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gaHR0cHM6Ly9naXRodWIuY29tL2Zsb2F0aW5nLXVpL2Zsb2F0aW5nLXVpL2lzc3Vlcy8zMDYwXG4gICAgICAgIGlmIChkYXRhUmVmLmN1cnJlbnQuaW5zaWRlUmVhY3RUcmVlKSB7XG4gICAgICAgICAgZGF0YVJlZi5jdXJyZW50Lmluc2lkZVJlYWN0VHJlZSA9IGZhbHNlO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIEZvY3VzIGRpZCBub3QgbW92ZSBpbnNpZGUgdGhlIGZsb2F0aW5nIHRyZWUsIGFuZCB0aGVyZSBhcmUgbm8gdGFiYmFibGVcbiAgICAgICAgLy8gcG9ydGFsIGd1YXJkcyB0byBoYW5kbGUgY2xvc2luZy5cbiAgICAgICAgaWYgKChpc1VudHJhcHBlZFR5cGVhYmxlQ29tYm9ib3ggPyB0cnVlIDogIW1vZGFsKSAmJiByZWxhdGVkVGFyZ2V0ICYmIG1vdmVkVG9VbnJlbGF0ZWROb2RlICYmICFpc1BvaW50ZXJEb3duUmVmLmN1cnJlbnQgJiYgKFxuICAgICAgICAvLyBGaXggUmVhY3QgMTggU3RyaWN0IE1vZGUgcmV0dXJuRm9jdXMgZHVlIHRvIGRvdWJsZSByZW5kZXJpbmcuXG4gICAgICAgIC8vIEZvciBhbiBcInVudHJhcHBlZFwiIHR5cGVhYmxlIGNvbWJvYm94IChpbnB1dCByb2xlPWNvbWJvYm94IHdpdGhcbiAgICAgICAgLy8gaW5pdGlhbEZvY3VzPWZhbHNlKSwgcmUtb3BlbmluZyB0aGUgcG9wdXAgYW5kIHRhYmJpbmcgb3V0IHNob3VsZCBzdGlsbCBjbG9zZSBpdCBldmVuXG4gICAgICAgIC8vIHdoZW4gdGhlIHByZXZpb3VzbHkgZm9jdXNlZCBlbGVtZW50IChlLmcuIHRoZSBuZXh0IHRhYmJhYmxlIG91dHNpZGUgdGhlIHBvcHVwKSBpc1xuICAgICAgICAvLyBmb2N1c2VkIGFnYWluLiBPdGhlcndpc2UsIHRoZSBwb3B1cCByZW1haW5zIG9wZW4gb24gdGhlIHNlY29uZCBUYWIgc2VxdWVuY2U6XG4gICAgICAgIC8vIGNsaWNrIGlucHV0IC0+IFRhYiAoY2xvc2VzKSAtPiBjbGljayBpbnB1dCAtPiBUYWIuXG4gICAgICAgIC8vIEFsbG93IGNsb3Npbmcgd2hlbiBgaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94YCByZWdhcmRsZXNzIG9mIHRoZSBwcmV2aW91c2x5IGZvY3VzZWQgZWxlbWVudC5cbiAgICAgICAgaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94IHx8IHJlbGF0ZWRUYXJnZXQgIT09IGdldFByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCgpKSkge1xuICAgICAgICAgIHByZXZlbnRSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5mb2N1c091dCwgZXZlbnQpKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIG1hcmtJbnNpZGVSZWFjdFRyZWUoKSB7XG4gICAgICBpZiAocG9pbnRlckRvd25PdXRzaWRlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgZGF0YVJlZi5jdXJyZW50Lmluc2lkZVJlYWN0VHJlZSA9IHRydWU7XG4gICAgICBibHVyVGltZW91dC5zdGFydCgwLCAoKSA9PiB7XG4gICAgICAgIGRhdGFSZWYuY3VycmVudC5pbnNpZGVSZWFjdFRyZWUgPSBmYWxzZTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCBkb21SZWZlcmVuY2VFbGVtZW50ID0gaXNIVE1MRWxlbWVudChkb21SZWZlcmVuY2UpID8gZG9tUmVmZXJlbmNlIDogbnVsbDtcbiAgICBpZiAoIWZsb2F0aW5nICYmICFkb21SZWZlcmVuY2VFbGVtZW50KSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICByZXR1cm4gbWVyZ2VDbGVhbnVwcyhkb21SZWZlcmVuY2VFbGVtZW50ICYmIGFkZEV2ZW50TGlzdGVuZXIoZG9tUmVmZXJlbmNlRWxlbWVudCwgJ2ZvY3Vzb3V0JywgaGFuZGxlRm9jdXNPdXRzaWRlKSwgZG9tUmVmZXJlbmNlRWxlbWVudCAmJiBhZGRFdmVudExpc3RlbmVyKGRvbVJlZmVyZW5jZUVsZW1lbnQsICdwb2ludGVyZG93bicsIGhhbmRsZVBvaW50ZXJEb3duKSwgZmxvYXRpbmcgJiYgYWRkRXZlbnRMaXN0ZW5lcihmbG9hdGluZywgJ2ZvY3VzaW4nLCBoYW5kbGVGb2N1c0luKSwgZmxvYXRpbmcgJiYgYWRkRXZlbnRMaXN0ZW5lcihmbG9hdGluZywgJ2ZvY3Vzb3V0JywgaGFuZGxlRm9jdXNPdXRzaWRlKSwgZmxvYXRpbmcgJiYgcG9ydGFsQ29udGV4dCAmJiBhZGRFdmVudExpc3RlbmVyKGZsb2F0aW5nLCAnZm9jdXNvdXQnLCBtYXJrSW5zaWRlUmVhY3RUcmVlLCB0cnVlKSk7XG4gIH0sIFtkaXNhYmxlZCwgZG9tUmVmZXJlbmNlLCBmbG9hdGluZywgZmxvYXRpbmdGb2N1c0VsZW1lbnQsIG1vZGFsLCB0cmVlLCBwb3J0YWxDb250ZXh0LCBzdG9yZSwgY2xvc2VPbkZvY3VzT3V0LCByZXN0b3JlRm9jdXMsIGdldFRhYmJhYmxlQ29udGVudCwgaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94LCBnZXROb2RlSWQsIGRhdGFSZWYsIGJsdXJUaW1lb3V0LCBwb2ludGVyRG93blRpbWVvdXQsIHJlc3RvcmVGb2N1c0ZyYW1lLCBuZXh0Rm9jdXNhYmxlRWxlbWVudCwgcHJldmlvdXNGb2N1c2FibGVFbGVtZW50LCBnZXRSZXNvbHZlZEluc2lkZUVsZW1lbnRzXSk7XG5cbiAgLy8gSGlkZSBldmVyeXRoaW5nIG91dHNpZGUgdGhlIGZsb2F0aW5nIHRyZWUgZnJvbSBhc3Npc3RpdmUgdGVjaCB3aGlsZSBvcGVuLlxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCB8fCAhZmxvYXRpbmcgfHwgIW9wZW4pIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgLy8gRG9uJ3QgaGlkZSBwb3J0YWxzIG5lc3RlZCB3aXRoaW4gdGhlIHBhcmVudCBwb3J0YWwuXG4gICAgY29uc3QgcG9ydGFsTm9kZXMgPSBBcnJheS5mcm9tKHBvcnRhbENvbnRleHQ/LnBvcnRhbE5vZGU/LnF1ZXJ5U2VsZWN0b3JBbGwoYFske2NyZWF0ZUF0dHJpYnV0ZSgncG9ydGFsJyl9XWApIHx8IFtdKTtcbiAgICBjb25zdCBhbmNlc3RvcnMgPSB0cmVlID8gZ2V0Tm9kZUFuY2VzdG9ycyh0cmVlLm5vZGVzUmVmLmN1cnJlbnQsIGdldE5vZGVJZCgpKSA6IFtdO1xuICAgIGNvbnN0IHJvb3RBbmNlc3RvckNvbWJvYm94RG9tUmVmZXJlbmNlID0gYW5jZXN0b3JzLmZpbmQobm9kZSA9PiBpc1R5cGVhYmxlQ29tYm9ib3gobm9kZS5jb250ZXh0Py5lbGVtZW50cy5kb21SZWZlcmVuY2UgfHwgbnVsbCkpPy5jb250ZXh0Py5lbGVtZW50cy5kb21SZWZlcmVuY2U7XG4gICAgY29uc3QgY29udHJvbEluc2lkZUVsZW1lbnRzID0gW2Zsb2F0aW5nLCAuLi5wb3J0YWxOb2RlcywgYmVmb3JlR3VhcmRSZWYuY3VycmVudCwgYWZ0ZXJHdWFyZFJlZi5jdXJyZW50LCBwb3J0YWxDb250ZXh0Py5iZWZvcmVPdXRzaWRlUmVmLmN1cnJlbnQsIHBvcnRhbENvbnRleHQ/LmFmdGVyT3V0c2lkZVJlZi5jdXJyZW50LCAuLi5nZXRSZXNvbHZlZEluc2lkZUVsZW1lbnRzKCldO1xuICAgIGNvbnN0IGluc2lkZUVsZW1lbnRzID0gWy4uLmNvbnRyb2xJbnNpZGVFbGVtZW50cywgcm9vdEFuY2VzdG9yQ29tYm9ib3hEb21SZWZlcmVuY2UsIHJlc29sdmVSZWYocHJldmlvdXNGb2N1c2FibGVFbGVtZW50KSwgcmVzb2x2ZVJlZihuZXh0Rm9jdXNhYmxlRWxlbWVudCksIGlzVW50cmFwcGVkVHlwZWFibGVDb21ib2JveCA/IGRvbVJlZmVyZW5jZSA6IG51bGxdLmZpbHRlcih4ID0+IHggIT0gbnVsbCk7XG4gICAgY29uc3QgYXJpYUhpZGRlbkNsZWFudXAgPSBtYXJrT3RoZXJzKGluc2lkZUVsZW1lbnRzLCB7XG4gICAgICBhcmlhSGlkZGVuOiBtb2RhbCB8fCBpc1VudHJhcHBlZFR5cGVhYmxlQ29tYm9ib3gsXG4gICAgICBtYXJrOiBmYWxzZVxuICAgIH0pO1xuICAgIGNvbnN0IG1hcmtlckluc2lkZUVsZW1lbnRzID0gW2Zsb2F0aW5nLCAuLi5wb3J0YWxOb2Rlc10uZmlsdGVyKHggPT4geCAhPSBudWxsKTtcbiAgICBjb25zdCBtYXJrZXJDbGVhbnVwID0gbWFya090aGVycyhtYXJrZXJJbnNpZGVFbGVtZW50cyk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIG1hcmtlckNsZWFudXAoKTtcbiAgICAgIGFyaWFIaWRkZW5DbGVhbnVwKCk7XG4gICAgfTtcbiAgfSwgW29wZW4sIGRpc2FibGVkLCBkb21SZWZlcmVuY2UsIGZsb2F0aW5nLCBtb2RhbCwgcG9ydGFsQ29udGV4dCwgaXNVbnRyYXBwZWRUeXBlYWJsZUNvbWJvYm94LCB0cmVlLCBnZXROb2RlSWQsIG5leHRGb2N1c2FibGVFbGVtZW50LCBwcmV2aW91c0ZvY3VzYWJsZUVsZW1lbnQsIGdldFJlc29sdmVkSW5zaWRlRWxlbWVudHNdKTtcblxuICAvLyBGb2N1cyB0aGUgaW5pdGlhbCBlbGVtZW50IHdoZW4gdGhlIGZsb2F0aW5nIGVsZW1lbnQgb3BlbnMuXG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuIHx8IGRpc2FibGVkIHx8ICFpc0hUTUxFbGVtZW50KGZsb2F0aW5nRm9jdXNFbGVtZW50KSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjbG9zZVR5cGVSZWYuY3VycmVudCA9ICcnO1xuICAgIGxhc3RJbnRlcmFjdGlvblR5cGVSZWYuY3VycmVudCA9ICcnO1xuICAgIGNvbnN0IGRvYyA9IG93bmVyRG9jdW1lbnQoZmxvYXRpbmdGb2N1c0VsZW1lbnQpO1xuICAgIGNvbnN0IHByZXZpb3VzbHlGb2N1c2VkRWxlbWVudCA9IGFjdGl2ZUVsZW1lbnQoZG9jKTtcblxuICAgIC8vIFdhaXQgZm9yIGFueSBsYXlvdXQgZWZmZWN0IHN0YXRlIHNldHRlcnMgdG8gZXhlY3V0ZSB0byBzZXQgYHRhYkluZGV4YC5cbiAgICBxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG4gICAgICBjb25zdCBpbml0aWFsRm9jdXNWYWx1ZU9yRm4gPSBpbml0aWFsRm9jdXNSZWYuY3VycmVudDtcbiAgICAgIGNvbnN0IHJlc29sdmVkSW5pdGlhbEZvY3VzID0gdHlwZW9mIGluaXRpYWxGb2N1c1ZhbHVlT3JGbiA9PT0gJ2Z1bmN0aW9uJyA/IGluaXRpYWxGb2N1c1ZhbHVlT3JGbihvcGVuSW50ZXJhY3Rpb25UeXBlUmVmLmN1cnJlbnQgfHwgJycpIDogaW5pdGlhbEZvY3VzVmFsdWVPckZuO1xuXG4gICAgICAvLyBgbnVsbGAgc2hvdWxkIGZhbGxiYWNrIHRvIGRlZmF1bHQgYmVoYXZpb3IgaW4gY2FzZSBvZiBhbiBlbXB0eSByZWYuXG4gICAgICBpZiAocmVzb2x2ZWRJbml0aWFsRm9jdXMgPT09IHVuZGVmaW5lZCB8fCByZXNvbHZlZEluaXRpYWxGb2N1cyA9PT0gZmFsc2UpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgZm9jdXNBbHJlYWR5SW5zaWRlRmxvYXRpbmdFbCA9IGNvbnRhaW5zKGZsb2F0aW5nRm9jdXNFbGVtZW50LCBwcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQpO1xuICAgICAgaWYgKGZvY3VzQWxyZWFkeUluc2lkZUZsb2F0aW5nRWwpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbGV0IGZvY3VzYWJsZUVsZW1lbnRzID0gbnVsbDtcbiAgICAgIGNvbnN0IGdldERlZmF1bHRGb2N1c0VsZW1lbnQgPSAoKSA9PiB7XG4gICAgICAgIGlmIChmb2N1c2FibGVFbGVtZW50cyA9PSBudWxsKSB7XG4gICAgICAgICAgZm9jdXNhYmxlRWxlbWVudHMgPSBnZXRUYWJiYWJsZUNvbnRlbnQoZmxvYXRpbmdGb2N1c0VsZW1lbnQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmb2N1c2FibGVFbGVtZW50c1swXSB8fCBmbG9hdGluZ0ZvY3VzRWxlbWVudDtcbiAgICAgIH07XG4gICAgICBsZXQgZWxUb0ZvY3VzO1xuICAgICAgaWYgKHJlc29sdmVkSW5pdGlhbEZvY3VzID09PSB0cnVlIHx8IHJlc29sdmVkSW5pdGlhbEZvY3VzID09PSBudWxsKSB7XG4gICAgICAgIGVsVG9Gb2N1cyA9IGdldERlZmF1bHRGb2N1c0VsZW1lbnQoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGVsVG9Gb2N1cyA9IHJlc29sdmVSZWYocmVzb2x2ZWRJbml0aWFsRm9jdXMpO1xuICAgICAgfVxuICAgICAgZWxUb0ZvY3VzID0gZWxUb0ZvY3VzIHx8IGdldERlZmF1bHRGb2N1c0VsZW1lbnQoKTtcbiAgICAgIGNvbnN0IGhhZEZvY3VzSW5zaWRlID0gY29udGFpbnMoZmxvYXRpbmdGb2N1c0VsZW1lbnQsIGFjdGl2ZUVsZW1lbnQoZG9jKSk7XG5cbiAgICAgIC8vIFNjcmVlbiByZWFkZXJzIHJlLXN5bmMgZm9jdXMgdG8gdGhlaXIgY3Vyc29yIHJpZ2h0IGFmdGVyIGEgc3ludGhlc2l6ZWQgcHJlc3MuIEEgZm9jdXNcbiAgICAgIC8vIHRoYXQgbGFuZHMgYSBmcmFtZSBsYXRlciByZWFkcyBhcyBhIHN0cmF5IG1vdmUgYW5kIGdldHMgcHVsbGVkIGJhY2sgdG8gdGhlIHJlZmVyZW5jZS5cbiAgICAgIGNvbnN0IG9wZW5FdmVudCA9IGRhdGFSZWYuY3VycmVudC5vcGVuRXZlbnQ7XG4gICAgICBjb25zdCBvcGVuZWRCeVZpcnR1YWxQcmVzcyA9IG9wZW5FdmVudD8udHlwZSA9PT0gJ21vdXNlZG93bicgJiYgaXNWaXJ0dWFsQ2xpY2sob3BlbkV2ZW50KTtcblxuICAgICAgLy8gZW5xdWV1ZUZvY3VzIHJldHVybnMgYSByQUYtY2FuY2VsIGZ1bmN0aW9uOyB3ZSBpbnRlbnRpb25hbGx5IGRvbid0IGNhbmNlbCB0aGlzIGZvY3VzLlxuICAgICAgdm9pZCBlbnF1ZXVlRm9jdXMoZWxUb0ZvY3VzLCB7XG4gICAgICAgIHN5bmM6IG9wZW5lZEJ5VmlydHVhbFByZXNzLFxuICAgICAgICBwcmV2ZW50U2Nyb2xsOiBlbFRvRm9jdXMgPT09IGZsb2F0aW5nRm9jdXNFbGVtZW50LFxuICAgICAgICBzaG91bGRGb2N1cygpIHtcbiAgICAgICAgICAvLyBJZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBoYXMgY2xvc2VkIGJlZm9yZSB0aGlzIHJ1bnMg4oCUIGUuZy4gdGFiYmluZyBvdXQgb2YgYVxuICAgICAgICAgIC8vIGtlcHQtbW91bnRlZCBwb3B1cCDigJQgZG9uJ3QgcHVsbCBmb2N1cyBiYWNrIG9udG8gdGhlIGluaXRpYWwgZWxlbWVudCBhZnRlciBpdCBoYXNcbiAgICAgICAgICAvLyBsZWdpdGltYXRlbHkgbW92ZWQgZWxzZXdoZXJlLlxuICAgICAgICAgIGlmICghb3BlblJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChoYWRGb2N1c0luc2lkZSkge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IGN1cnJlbnRBY3RpdmVFbGVtZW50ID0gYWN0aXZlRWxlbWVudChkb2MpO1xuICAgICAgICAgIGNvbnN0IGZvY3VzTW92ZWRJbnNpZGUgPSBjdXJyZW50QWN0aXZlRWxlbWVudCAhPT0gZWxUb0ZvY3VzICYmIGNvbnRhaW5zKGZsb2F0aW5nRm9jdXNFbGVtZW50LCBjdXJyZW50QWN0aXZlRWxlbWVudCk7XG4gICAgICAgICAgcmV0dXJuICFmb2N1c01vdmVkSW5zaWRlO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfSwgW2Rpc2FibGVkLCBvcGVuLCBmbG9hdGluZ0ZvY3VzRWxlbWVudCwgZ2V0VGFiYmFibGVDb250ZW50LCBpbml0aWFsRm9jdXNSZWYsIG9wZW5JbnRlcmFjdGlvblR5cGVSZWYsIG9wZW5SZWYsIGRhdGFSZWZdKTtcblxuICAvLyBBIHJldHVybi1mb2N1cyBxdWV1ZWQgYnkgdGhlIGVmZmVjdCBjbGVhbnVwLiBJZiB0aGUgZWZmZWN0IHJlLWFybXMgaW4gdGhlIHNhbWUgY29tbWl0LCBhXG4gIC8vIGRlcGVuZGVuY3kgY2hhbmdlZCB3aGlsZSB0aGUgcG9wdXAgc3RheWVkIG9wZW4sIHNvIHRoZSBjbGVhbnVwIHdhcyBub3QgYSBjbG9zZS5cbiAgY29uc3QgcGVuZGluZ1JldHVybkZvY3VzUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuXG4gIC8vIFRyYWNrIHJldHVybiBmb2N1cyB0YXJnZXRzIGFuZCByZXN0b3JlIGZvY3VzIG9uIHVubW91bnQvY2xvc2UuXG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGRpc2FibGVkIHx8ICFmbG9hdGluZ0ZvY3VzRWxlbWVudCkge1xuICAgICAgcGVuZGluZ1JldHVybkZvY3VzUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgaWYgKHBlbmRpbmdSZXR1cm5Gb2N1c1JlZi5jdXJyZW50KSB7XG4gICAgICBwZW5kaW5nUmV0dXJuRm9jdXNSZWYuY3VycmVudC5jYW5jZWxsZWQgPSB0cnVlO1xuICAgICAgcGVuZGluZ1JldHVybkZvY3VzUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH1cbiAgICBjb25zdCBkb2MgPSBvd25lckRvY3VtZW50KGZsb2F0aW5nRm9jdXNFbGVtZW50KTtcbiAgICBjb25zdCBlbGVtZW50Rm9jdXNlZEJlZm9yZU9wZW4gPSBhY3RpdmVFbGVtZW50KGRvYyk7XG4gICAgLy8gT25seSBhbiBleHBsaWNpdCBgbnVsbGAgaW50ZXJhY3Rpb24gdHlwZSByZXByZXNlbnRzIGEgcHJvZ3JhbW1hdGljIG9wZW4uXG4gICAgLy8gYHVuZGVmaW5lZGAgaXMgbm9ybWFsaXplZCB0byBgJydgIGJ5IHRoZSBwcm9wIGRlZmF1bHQsIHNvIGl0IG5ldmVyIHJlYWNoZXNcbiAgICAvLyBoZXJlIGFzIG51bGxpc2ggYW5kIGlzIGludGVudGlvbmFsbHkgbm90IHRyZWF0ZWQgYXMgcHJvZ3JhbW1hdGljLlxuICAgIGNvbnN0IHByZWZlclByZXZpb3VzRm9jdXMgPSBvcGVuSW50ZXJhY3Rpb25UeXBlUmVmLmN1cnJlbnQgPT0gbnVsbDtcbiAgICBhZGRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQoZWxlbWVudEZvY3VzZWRCZWZvcmVPcGVuKTtcbiAgICBmdW5jdGlvbiBvbk9wZW5DaGFuZ2VMb2NhbChkZXRhaWxzKSB7XG4gICAgICBpZiAoIWRldGFpbHMub3Blbikge1xuICAgICAgICBjbG9zZVR5cGVSZWYuY3VycmVudCA9IGdldEV2ZW50VHlwZShkZXRhaWxzLm5hdGl2ZUV2ZW50LCBsYXN0SW50ZXJhY3Rpb25UeXBlUmVmLmN1cnJlbnQpO1xuICAgICAgfVxuXG4gICAgICAvLyBGb2N1cyBndWFyZHMgdHJhbnNmZXIgZm9jdXMgdGhlbXNlbHZlczsgb3RoZXIgY2xvc2UgaGFuZGxlcnMgbWF5IHN0aWxsIG5lZWQgcmV0dXJuIGZvY3VzLlxuICAgICAgaWYgKGRldGFpbHMucmVhc29uID09PSBSRUFTT05TLmZvY3VzT3V0ICYmIGRldGFpbHMudHJpZ2dlckVsZW1lbnQ/Lmhhc0F0dHJpYnV0ZShjcmVhdGVBdHRyaWJ1dGUoJ2ZvY3VzLWd1YXJkJykpIHx8IGRldGFpbHMucmVhc29uID09PSBSRUFTT05TLnRyaWdnZXJIb3ZlciAmJiBkZXRhaWxzLm5hdGl2ZUV2ZW50LnR5cGUgPT09ICdtb3VzZWxlYXZlJykge1xuICAgICAgICBwcmV2ZW50UmV0dXJuRm9jdXNSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICB9XG4gICAgICBpZiAoZGV0YWlscy5yZWFzb24gIT09IFJFQVNPTlMub3V0c2lkZVByZXNzKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChkZXRhaWxzLm5lc3RlZCkge1xuICAgICAgICBwcmV2ZW50UmV0dXJuRm9jdXNSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgfSBlbHNlIGlmIChpc1ZpcnR1YWxDbGljayhkZXRhaWxzLm5hdGl2ZUV2ZW50KSB8fCBpc1ZpcnR1YWxQb2ludGVyRXZlbnQoZGV0YWlscy5uYXRpdmVFdmVudCkpIHtcbiAgICAgICAgcHJldmVudFJldHVybkZvY3VzUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIE9uIG91dHNpZGUgcHJlc3MsIG9ubHkgcmV0dXJuIGZvY3VzIHRvIHRoZSByZWZlcmVuY2Ugd2hlbiB0aGUgYnJvd3NlciBzdXBwb3J0cyB0aGVcbiAgICAgICAgLy8gYGZvY3VzKHsgcHJldmVudFNjcm9sbCB9KWAgb3B0aW9uOyB3aXRob3V0IGl0LCByZXN0b3JpbmcgZm9jdXMgc2Nyb2xscyB0aGUgcGFnZS5cbiAgICAgICAgLy8gQ2hyb21lIG9uIEFuZHJvaWQgYW5kIFNhbXN1bmcgSW50ZXJuZXQgc3RpbGwgZG9uJ3Qgc3VwcG9ydCBgcHJldmVudFNjcm9sbGBcbiAgICAgICAgLy8gKGh0dHBzOi8vaXNzdWVzLmNocm9taXVtLm9yZy9pc3N1ZXMvNDE0NTMxMjIpLCBzbyB0aGUgcnVudGltZSBjaGVjayBrZWVwcyByZXR1cm5cbiAgICAgICAgLy8gZm9jdXMgZGlzYWJsZWQgdGhlcmUgdG8gYXZvaWQgdGhlIHNjcm9sbCBqdW1wLlxuICAgICAgICBsZXQgaXNQcmV2ZW50U2Nyb2xsU3VwcG9ydGVkID0gZmFsc2U7XG4gICAgICAgIG93bmVyRG9jdW1lbnQoZmxvYXRpbmdGb2N1c0VsZW1lbnQpLmNyZWF0ZUVsZW1lbnQoJ2RpdicpLmZvY3VzKHtcbiAgICAgICAgICBnZXQgcHJldmVudFNjcm9sbCgpIHtcbiAgICAgICAgICAgIGlzUHJldmVudFNjcm9sbFN1cHBvcnRlZCA9IHRydWU7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKGlzUHJldmVudFNjcm9sbFN1cHBvcnRlZCkge1xuICAgICAgICAgIHByZXZlbnRSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcHJldmVudFJldHVybkZvY3VzUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGV2ZW50cy5vbignb3BlbmNoYW5nZScsIG9uT3BlbkNoYW5nZUxvY2FsKTtcbiAgICBmdW5jdGlvbiBnZXRSZXR1cm5FbGVtZW50KGNsb3NlVHlwZSkge1xuICAgICAgY29uc3QgcmV0dXJuRm9jdXNWYWx1ZU9yRm4gPSByZXR1cm5Gb2N1c1JlZi5jdXJyZW50O1xuICAgICAgbGV0IHJlc29sdmVkUmV0dXJuRm9jdXNWYWx1ZSA9IHR5cGVvZiByZXR1cm5Gb2N1c1ZhbHVlT3JGbiA9PT0gJ2Z1bmN0aW9uJyA/IHJldHVybkZvY3VzVmFsdWVPckZuKGNsb3NlVHlwZSkgOiByZXR1cm5Gb2N1c1ZhbHVlT3JGbjtcblxuICAgICAgLy8gYG51bGxgIHNob3VsZCBmYWxsYmFjayB0byBkZWZhdWx0IGJlaGF2aW9yIGluIGNhc2Ugb2YgYW4gZW1wdHkgcmVmLlxuICAgICAgaWYgKHJlc29sdmVkUmV0dXJuRm9jdXNWYWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHJlc29sdmVkUmV0dXJuRm9jdXNWYWx1ZSA9PT0gZmFsc2UpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgICBpZiAocmVzb2x2ZWRSZXR1cm5Gb2N1c1ZhbHVlID09PSBudWxsKSB7XG4gICAgICAgIHJlc29sdmVkUmV0dXJuRm9jdXNWYWx1ZSA9IHRydWU7XG4gICAgICB9XG4gICAgICBjb25zdCByZWZlcmVuY2VSZXR1cm5FbGVtZW50ID0gZG9tUmVmZXJlbmNlPy5pc0Nvbm5lY3RlZCA/IGRvbVJlZmVyZW5jZSA6IG51bGw7XG4gICAgICBjb25zdCBwcmV2aW91c1JldHVybkVsZW1lbnQgPSBlbGVtZW50Rm9jdXNlZEJlZm9yZU9wZW4/LmlzQ29ubmVjdGVkICYmIGdldE5vZGVOYW1lKGVsZW1lbnRGb2N1c2VkQmVmb3JlT3BlbikgIT09ICdib2R5JyA/IGVsZW1lbnRGb2N1c2VkQmVmb3JlT3BlbiA6IG51bGw7XG4gICAgICBsZXQgZGVmYXVsdFJldHVybkVsZW1lbnQgPSBwcmVmZXJQcmV2aW91c0ZvY3VzID8gcHJldmlvdXNSZXR1cm5FbGVtZW50IHx8IHJlZmVyZW5jZVJldHVybkVsZW1lbnQgOiByZWZlcmVuY2VSZXR1cm5FbGVtZW50IHx8IHByZXZpb3VzUmV0dXJuRWxlbWVudDtcbiAgICAgIGlmICghZGVmYXVsdFJldHVybkVsZW1lbnQpIHtcbiAgICAgICAgZGVmYXVsdFJldHVybkVsZW1lbnQgPSBnZXRQcmV2aW91c2x5Rm9jdXNlZEVsZW1lbnQoKSB8fCBudWxsO1xuICAgICAgfVxuICAgICAgaWYgKHR5cGVvZiByZXNvbHZlZFJldHVybkZvY3VzVmFsdWUgPT09ICdib29sZWFuJykge1xuICAgICAgICByZXR1cm4gZGVmYXVsdFJldHVybkVsZW1lbnQ7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzb2x2ZVJlZihyZXNvbHZlZFJldHVybkZvY3VzVmFsdWUpIHx8IGRlZmF1bHRSZXR1cm5FbGVtZW50IHx8IG51bGw7XG4gICAgfVxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBldmVudHMub2ZmKCdvcGVuY2hhbmdlJywgb25PcGVuQ2hhbmdlTG9jYWwpO1xuICAgICAgY29uc3QgYWN0aXZlRWwgPSBhY3RpdmVFbGVtZW50KGRvYyk7XG4gICAgICBjb25zdCBpbnNpZGVFbGVtZW50cyA9IGdldFJlc29sdmVkSW5zaWRlRWxlbWVudHMoKTtcbiAgICAgIGNvbnN0IGlzRm9jdXNJbnNpZGVGbG9hdGluZ1RyZWUgPSBjb250YWlucyhmbG9hdGluZywgYWN0aXZlRWwpIHx8IGluc2lkZUVsZW1lbnRzLnNvbWUoZWxlbWVudCA9PiBlbGVtZW50ID09PSBhY3RpdmVFbCB8fCBjb250YWlucyhlbGVtZW50LCBhY3RpdmVFbCkpIHx8IHRyZWUgJiYgZ2V0Tm9kZUNoaWxkcmVuKHRyZWUubm9kZXNSZWYuY3VycmVudCwgZ2V0Tm9kZUlkKCksIGZhbHNlKS5zb21lKG5vZGUgPT4gY29udGFpbnMobm9kZS5jb250ZXh0Py5lbGVtZW50cy5mbG9hdGluZywgYWN0aXZlRWwpKTtcblxuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICAgICAgY29uc3QgcmV0dXJuRm9jdXNWYWx1ZU9yRm4gPSByZXR1cm5Gb2N1c1JlZi5jdXJyZW50O1xuICAgICAgY29uc3QgY2xvc2VUeXBlID0gY2xvc2VUeXBlUmVmLmN1cnJlbnQ7XG4gICAgICBjb25zdCByZXR1cm5FbGVtZW50ID0gZ2V0UmV0dXJuRWxlbWVudChjbG9zZVR5cGUpO1xuICAgICAgY29uc3Qgam9iID0ge1xuICAgICAgICBjYW5jZWxsZWQ6IGZhbHNlXG4gICAgICB9O1xuICAgICAgcGVuZGluZ1JldHVybkZvY3VzUmVmLmN1cnJlbnQgPSBqb2I7XG4gICAgICBxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG4gICAgICAgIGlmIChwZW5kaW5nUmV0dXJuRm9jdXNSZWYuY3VycmVudCA9PT0gam9iKSB7XG4gICAgICAgICAgcGVuZGluZ1JldHVybkZvY3VzUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICB9XG4gICAgICAgIC8vIGByZXR1cm5FbGVtZW50YCBpZiBpdCBpcyB0YWJiYWJsZSwgb3RoZXJ3aXNlIGl0cyBmaXJzdCB0YWJiYWJsZSBjaGlsZCxcbiAgICAgICAgLy8gb3RoZXJ3aXNlIGByZXR1cm5FbGVtZW50YCBpdHNlbGYgKHdoaWNoIG1heSBub3QgYmUgdGFiYmFibGUgYXQgYWxsKS5cbiAgICAgICAgY29uc3QgdGFiYmFibGVSZXR1cm5FbGVtZW50ID0gZ2V0Rmlyc3RUYWJiYWJsZUVsZW1lbnQocmV0dXJuRWxlbWVudCk7XG4gICAgICAgIC8vIFJlYWQgaW4gdGhlIGNsZWFudXAgb24gcHVycG9zZTogdGhlIGxhdGVzdCBgZXhwbGljaXRSZXR1cm5Gb2N1c2AgZGVjaWRlcy5cbiAgICAgICAgY29uc3QgaGFzRXhwbGljaXRSZXR1cm5Gb2N1cyA9XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgICAgICAgZXhwbGljaXRSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID8/IHR5cGVvZiByZXR1cm5Gb2N1c1ZhbHVlT3JGbiAhPT0gJ2Jvb2xlYW4nO1xuICAgICAgICBpZiAoIWpvYi5jYW5jZWxsZWQgJiYgcmV0dXJuRm9jdXNWYWx1ZU9yRm4gJiYgIXByZXZlbnRSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ICYmIGlzSFRNTEVsZW1lbnQodGFiYmFibGVSZXR1cm5FbGVtZW50KSAmJiAoXG4gICAgICAgIC8vIElmIHRoZSBmb2N1cyBtb3ZlZCBzb21ld2hlcmUgZWxzZSBhZnRlciBtb3VudCwgYXZvaWQgcmV0dXJuaW5nIGZvY3VzXG4gICAgICAgIC8vIHNpbmNlIGl0IGxpa2VseSBlbnRlcmVkIGEgZGlmZmVyZW50IGVsZW1lbnQgd2hpY2ggc2hvdWxkIGJlXG4gICAgICAgIC8vIHJlc3BlY3RlZDogaHR0cHM6Ly9naXRodWIuY29tL2Zsb2F0aW5nLXVpL2Zsb2F0aW5nLXVpL2lzc3Vlcy8yNjA3XG4gICAgICAgICFoYXNFeHBsaWNpdFJldHVybkZvY3VzICYmIHRhYmJhYmxlUmV0dXJuRWxlbWVudCAhPT0gYWN0aXZlRWwgJiYgYWN0aXZlRWwgIT09IGRvYy5ib2R5ID8gaXNGb2N1c0luc2lkZUZsb2F0aW5nVHJlZSA6IHRydWUpKSB7XG4gICAgICAgICAgY29uc3QgZm9jdXNPcHRpb25zID0ge1xuICAgICAgICAgICAgcHJldmVudFNjcm9sbDogdHJ1ZVxuICAgICAgICAgIH07XG4gICAgICAgICAgaWYgKGNsb3NlVHlwZSA9PT0gJ2tleWJvYXJkJykge1xuICAgICAgICAgICAgZm9jdXNPcHRpb25zLmZvY3VzVmlzaWJsZSA9IHRydWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIHRhYmJhYmxlUmV0dXJuRWxlbWVudC5mb2N1cyhmb2N1c09wdGlvbnMpO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gQSBjYW5jZWxsZWQgcmV0dXJuIG11c3QgYWxzbyBjbGVhciBzdXBwcmVzc2lvbiBiZWZvcmUgdGhlIG5leHQgY2xvc2UuXG4gICAgICAgIHByZXZlbnRSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICB9KTtcbiAgICB9O1xuICB9LCBbZGlzYWJsZWQsIGZsb2F0aW5nLCBmbG9hdGluZ0ZvY3VzRWxlbWVudCwgcmV0dXJuRm9jdXNSZWYsIGV4cGxpY2l0UmV0dXJuRm9jdXNSZWYsIG9wZW5JbnRlcmFjdGlvblR5cGVSZWYsIGV2ZW50cywgdHJlZSwgZG9tUmVmZXJlbmNlLCBnZXROb2RlSWQsIGdldFJlc29sdmVkSW5zaWRlRWxlbWVudHNdKTtcblxuICAvLyBTYWZhcmkgbWF5IHJhbmRvbWx5IHNjcm9sbCB0byB0aGUgYm90dG9tIG9mIHRoZSBwYWdlIGlmIGFuIGlucHV0IGluc2lkZSBhIHBvcHVwIGhhcyBmb2N1c1xuICAvLyB3aGVuIHRoZSBwb3B1cCB1bm1vdW50cyBmcm9tIHRoZSBET00uXG4gIC8vIEJ5IGJsdXJyaW5nIGl0IGJlZm9yZSB0aGUgcG9wdXAgdW5tb3VudHMsIHdlIGNhbiBwcmV2ZW50IHRoaXMgYmVoYXZpb3IuXG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFwbGF0Zm9ybS5lbmdpbmUud2Via2l0IHx8IG9wZW4gfHwgIWZsb2F0aW5nKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGFjdGl2ZUVsID0gYWN0aXZlRWxlbWVudChvd25lckRvY3VtZW50KGZsb2F0aW5nKSk7XG4gICAgaWYgKCFpc0hUTUxFbGVtZW50KGFjdGl2ZUVsKSB8fCAhaXNUeXBlYWJsZUVsZW1lbnQoYWN0aXZlRWwpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChjb250YWlucyhmbG9hdGluZywgYWN0aXZlRWwpKSB7XG4gICAgICBhY3RpdmVFbC5ibHVyKCk7XG4gICAgfVxuICB9LCBbb3BlbiwgZmxvYXRpbmddKTtcblxuICAvLyBTeW5jaHJvbml6ZSB0aGUgZm9jdXMgbWFuYWdlciBzdGF0ZSAobW9kYWwsIGNsb3NlT25Gb2N1c091dCwgb3BlbiwgZXRjLikgdG8gdGhlXG4gIC8vIEZsb2F0aW5nUG9ydGFsIGNvbnRleHQsIHdoaWNoIHVzZXMgaXQgdG8gZGVjaWRlIHdoZXRoZXIgdG8gcmVuZGVyIGl0cyBvd24gZ3VhcmRzLlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChkaXNhYmxlZCB8fCAhcG9ydGFsQ29udGV4dCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgcG9ydGFsQ29udGV4dC5zZXRGb2N1c01hbmFnZXJTdGF0ZSh7XG4gICAgICBtb2RhbCxcbiAgICAgIGNsb3NlT25Gb2N1c091dCxcbiAgICAgIG9wZW4sXG4gICAgICBvbk9wZW5DaGFuZ2U6IHN0b3JlLnNldE9wZW4sXG4gICAgICBkb21SZWZlcmVuY2VcbiAgICB9KTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgcG9ydGFsQ29udGV4dC5zZXRGb2N1c01hbmFnZXJTdGF0ZShudWxsKTtcbiAgICB9O1xuICB9LCBbZGlzYWJsZWQsIHBvcnRhbENvbnRleHQsIG1vZGFsLCBvcGVuLCBzdG9yZSwgY2xvc2VPbkZvY3VzT3V0LCBkb21SZWZlcmVuY2VdKTtcblxuICAvLyBLZWVwIHRoZSBmbG9hdGluZyBlbGVtZW50IHRhYkluZGV4IGluIHN5bmMgYW5kIGNsZWFyIHN0YWxlIGZvY3VzIHJlY29yZHMuXG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGRpc2FibGVkIHx8ICFmbG9hdGluZ0ZvY3VzRWxlbWVudCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgaGFuZGxlVGFiSW5kZXgoZmxvYXRpbmdGb2N1c0VsZW1lbnQpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBxdWV1ZU1pY3JvdGFzayhjbGVhckRpc2Nvbm5lY3RlZFByZXZpb3VzbHlGb2N1c2VkRWxlbWVudHMpO1xuICAgIH07XG4gIH0sIFtkaXNhYmxlZCwgZmxvYXRpbmdGb2N1c0VsZW1lbnRdKTtcbiAgY29uc3Qgc2hvdWxkUmVuZGVyR3VhcmRzID0gIWRpc2FibGVkICYmIChtb2RhbCA/ICFpc1VudHJhcHBlZFR5cGVhYmxlQ29tYm9ib3ggOiB0cnVlKSAmJiAoaXNJbnNpZGVQb3J0YWwgfHwgbW9kYWwpO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3hzKFJlYWN0LkZyYWdtZW50LCB7XG4gICAgY2hpbGRyZW46IFtzaG91bGRSZW5kZXJHdWFyZHMgJiYgLyojX19QVVJFX18qL19qc3goRm9jdXNHdWFyZCwge1xuICAgICAgXCJkYXRhLXR5cGVcIjogXCJpbnNpZGVcIixcbiAgICAgIHJlZjogbWVyZ2VkQmVmb3JlR3VhcmRSZWYsXG4gICAgICBvbkZvY3VzOiBldmVudCA9PiB7XG4gICAgICAgIGlmIChtb2RhbCkge1xuICAgICAgICAgIGNvbnN0IGVscyA9IGdldFRhYmJhYmxlQ29udGVudCgpO1xuICAgICAgICAgIC8vIGVucXVldWVGb2N1cyByZXR1cm5zIGEgckFGLWNhbmNlbCBmdW5jdGlvbiB3ZSBkb24ndCBuZWVkIGhlcmUuXG4gICAgICAgICAgdm9pZCBlbnF1ZXVlRm9jdXMoZWxzW2Vscy5sZW5ndGggLSAxXSk7XG4gICAgICAgIH0gZWxzZSBpZiAocG9ydGFsQ29udGV4dD8ucG9ydGFsTm9kZSkge1xuICAgICAgICAgIHByZXZlbnRSZXR1cm5Gb2N1c1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgICAgaWYgKGlzT3V0c2lkZUV2ZW50KGV2ZW50LCBwb3J0YWxDb250ZXh0LnBvcnRhbE5vZGUpKSB7XG4gICAgICAgICAgICBjb25zdCBuZXh0VGFiYmFibGUgPSBnZXROZXh0VGFiYmFibGUoZG9tUmVmZXJlbmNlKTtcbiAgICAgICAgICAgIG5leHRUYWJiYWJsZT8uZm9jdXMoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVzb2x2ZVJlZihwcmV2aW91c0ZvY3VzYWJsZUVsZW1lbnQgPz8gcG9ydGFsQ29udGV4dC5iZWZvcmVPdXRzaWRlUmVmKT8uZm9jdXMoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KSwgY2hpbGRyZW4sIHNob3VsZFJlbmRlckd1YXJkcyAmJiAvKiNfX1BVUkVfXyovX2pzeChGb2N1c0d1YXJkLCB7XG4gICAgICBcImRhdGEtdHlwZVwiOiBcImluc2lkZVwiLFxuICAgICAgcmVmOiBtZXJnZWRBZnRlckd1YXJkUmVmLFxuICAgICAgb25Gb2N1czogZXZlbnQgPT4ge1xuICAgICAgICBpZiAobW9kYWwpIHtcbiAgICAgICAgICAvLyBlbnF1ZXVlRm9jdXMgcmV0dXJucyBhIHJBRi1jYW5jZWwgZnVuY3Rpb24gd2UgZG9uJ3QgbmVlZCBoZXJlLlxuICAgICAgICAgIHZvaWQgZW5xdWV1ZUZvY3VzKGdldFRhYmJhYmxlQ29udGVudCgpWzBdKTtcbiAgICAgICAgfSBlbHNlIGlmIChwb3J0YWxDb250ZXh0Py5wb3J0YWxOb2RlKSB7XG4gICAgICAgICAgaWYgKGNsb3NlT25Gb2N1c091dCkge1xuICAgICAgICAgICAgcHJldmVudFJldHVybkZvY3VzUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoaXNPdXRzaWRlRXZlbnQoZXZlbnQsIHBvcnRhbENvbnRleHQucG9ydGFsTm9kZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IHByZXZUYWJiYWJsZSA9IGdldFByZXZpb3VzVGFiYmFibGUoZG9tUmVmZXJlbmNlKTtcbiAgICAgICAgICAgIHByZXZUYWJiYWJsZT8uZm9jdXMoKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVzb2x2ZVJlZihuZXh0Rm9jdXNhYmxlRWxlbWVudCA/PyBwb3J0YWxDb250ZXh0LmFmdGVyT3V0c2lkZVJlZik/LmZvY3VzKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSldXG4gIH0pO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlQW5pbWF0aW9uRnJhbWUgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VBbmltYXRpb25GcmFtZSc7XG5pbXBvcnQgeyB1c2VUaW1lb3V0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlVGltZW91dCc7XG5pbXBvcnQgeyBFTVBUWV9PQkpFQ1QgfSBmcm9tICdAYmFzZS11aS91dGlscy9lbXB0eSc7XG5pbXBvcnQgeyBnZXRUYXJnZXQsIGlzVHlwZWFibGVFbGVtZW50IH0gZnJvbSBcIi4uL3V0aWxzL2VsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBpc01vdXNlTGlrZVBvaW50ZXJUeXBlLCBpc1ZpcnR1YWxQb2ludGVyRXZlbnQgfSBmcm9tIFwiLi4vdXRpbHMvZXZlbnQubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG4vKipcbiAqIE9wZW5zIG9yIGNsb3NlcyB0aGUgZmxvYXRpbmcgZWxlbWVudCB3aGVuIGNsaWNraW5nIHRoZSByZWZlcmVuY2UgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy91c2VDbGlja1xuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlQ2xpY2soc3RvcmUsIHByb3BzID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGVuYWJsZWQgPSB0cnVlLFxuICAgIGV2ZW50OiBldmVudE9wdGlvbiA9ICdjbGljaycsXG4gICAgdG9nZ2xlID0gdHJ1ZSxcbiAgICBpZ25vcmVNb3VzZSA9IGZhbHNlLFxuICAgIHN0aWNrSWZPcGVuID0gdHJ1ZSxcbiAgICB0b3VjaE9wZW5EZWxheSA9IDAsXG4gICAgcmVhc29uID0gUkVBU09OUy50cmlnZ2VyUHJlc3NcbiAgfSA9IHByb3BzO1xuICBjb25zdCBkYXRhUmVmID0gc3RvcmUuY29udGV4dC5kYXRhUmVmO1xuICBjb25zdCBwb2ludGVyVHlwZVJlZiA9IFJlYWN0LnVzZVJlZih1bmRlZmluZWQpO1xuICBjb25zdCBmcmFtZSA9IHVzZUFuaW1hdGlvbkZyYW1lKCk7XG4gIGNvbnN0IHRvdWNoT3BlblRpbWVvdXQgPSB1c2VUaW1lb3V0KCk7XG4gIGNvbnN0IHJlZmVyZW5jZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGZ1bmN0aW9uIHNldE9wZW5XaXRoVG91Y2hEZWxheShuZXh0T3BlbiwgbmF0aXZlRXZlbnQsIHRhcmdldCwgcG9pbnRlclR5cGUpIHtcbiAgICAgIGNvbnN0IGRldGFpbHMgPSBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMocmVhc29uLCBuYXRpdmVFdmVudCwgdGFyZ2V0KTtcbiAgICAgIGlmIChuZXh0T3BlbiAmJiBwb2ludGVyVHlwZSA9PT0gJ3RvdWNoJyAmJiB0b3VjaE9wZW5EZWxheSA+IDApIHtcbiAgICAgICAgdG91Y2hPcGVuVGltZW91dC5zdGFydCh0b3VjaE9wZW5EZWxheSwgKCkgPT4ge1xuICAgICAgICAgIHN0b3JlLnNldE9wZW4odHJ1ZSwgZGV0YWlscyk7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3RvcmUuc2V0T3BlbihuZXh0T3BlbiwgZGV0YWlscyk7XG4gICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldE5leHRPcGVuKG9wZW4sIGN1cnJlbnRUYXJnZXQsIGlzQ2xpY2tMaWtlT3BlbkV2ZW50KSB7XG4gICAgICBjb25zdCBvcGVuRXZlbnQgPSBkYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50O1xuICAgICAgY29uc3QgaGFzQ2xpY2tlZE9uSW5hY3RpdmVUcmlnZ2VyID0gc3RvcmUuc2VsZWN0KCdkb21SZWZlcmVuY2VFbGVtZW50JykgIT09IGN1cnJlbnRUYXJnZXQ7XG4gICAgICBpZiAob3BlbiAmJiBoYXNDbGlja2VkT25JbmFjdGl2ZVRyaWdnZXIpIHtcbiAgICAgICAgLy8gTW92aW5nIGJldHdlZW4gdHJpZ2dlcnMgc2hvdWxkIGFsd2F5cyBvcGVuIHRoZSBuZXdseSBhY3RpdmUgb25lLlxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmICghb3Blbikge1xuICAgICAgICAvLyBBIGNsb3NlZCBwb3B1cCBzaG91bGQgb3BlbiBvbiB0aGUgbmV4dCBwcmVzcy5cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBpZiAoIXRvZ2dsZSkge1xuICAgICAgICAvLyBOb24tdG9nZ2xlIG1vZGUgbmV2ZXIgY2xvc2VzIG9uIGEgcmVwZWF0ZWQgdHJpZ2dlciBwcmVzcy5cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBpZiAob3BlbkV2ZW50ICYmICh0eXBlb2Ygc3RpY2tJZk9wZW4gPT09ICdmdW5jdGlvbicgPyBzdGlja0lmT3BlbigpIDogc3RpY2tJZk9wZW4pKSB7XG4gICAgICAgIC8vIFByZXNlcnZlIGhvdmVyL2ZvY3VzLW9wZW5lZCBwb3B1cHMgdW50aWwgdGhlIG1hdGNoaW5nIGNsaWNrLWxpa2UgZXZlbnQgY2xvc2VzIHRoZW0uXG4gICAgICAgIHJldHVybiAhaXNDbGlja0xpa2VPcGVuRXZlbnQob3BlbkV2ZW50LnR5cGUpO1xuICAgICAgfVxuXG4gICAgICAvLyBPdGhlcndpc2UsIGEgcmVwZWF0ZWQgY2xpY2sgdG9nZ2xlcyB0aGUgcG9wdXAgY2xvc2VkLlxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgb25Qb2ludGVyRG93bihldmVudCkge1xuICAgICAgICAvLyBTY3JlZW4gcmVhZGVyIGFjdGl2YXRpb25zIChBbmRyb2lkIFRhbGtCYWNrLCBkZXNrdG9wIHNjcmVlbiByZWFkZXJzKSByZXBvcnQgYVxuICAgICAgICAvLyBtb3VzZS1saWtlIGBwb2ludGVyVHlwZWAsIGJ1dCBgaWdub3JlTW91c2VgIG11c3Qgbm90IGRyb3AgdGhlbTogaG92ZXIgbG9naWMgY2Fubm90XG4gICAgICAgIC8vIG9wZW4gZm9yIGEgdmlydHVhbCBwcmVzcyBzaW5jZSB0aGVyZSBpcyBubyByZWFsIHBvaW50ZXIgbW92ZW1lbnQgdG8gd2FpdCBmb3IuXG4gICAgICAgIC8vIFZpcnR1YWwgYHRvdWNoYCBwcmVzc2VzIChpT1MgVm9pY2VPdmVyKSBrZWVwIHRoZWlyIHR5cGUgc28gYHRvdWNoT3BlbkRlbGF5YCBhcHBsaWVzLlxuICAgICAgICBwb2ludGVyVHlwZVJlZi5jdXJyZW50ID0gaXNNb3VzZUxpa2VQb2ludGVyVHlwZShldmVudC5wb2ludGVyVHlwZSwgdHJ1ZSkgJiYgaXNWaXJ0dWFsUG9pbnRlckV2ZW50KGV2ZW50Lm5hdGl2ZUV2ZW50KSA/ICd2aXJ0dWFsJyA6IGV2ZW50LnBvaW50ZXJUeXBlO1xuICAgICAgfSxcbiAgICAgIG9uTW91c2VEb3duKGV2ZW50KSB7XG4gICAgICAgIGNvbnN0IHBvaW50ZXJUeXBlID0gcG9pbnRlclR5cGVSZWYuY3VycmVudDtcbiAgICAgICAgY29uc3QgbmF0aXZlRXZlbnQgPSBldmVudC5uYXRpdmVFdmVudDtcbiAgICAgICAgY29uc3Qgb3BlbiA9IHN0b3JlLnNlbGVjdCgnb3BlbicpO1xuXG4gICAgICAgIC8vIElnbm9yZSBhbGwgYnV0dG9ucyBleGNlcHQgZm9yIHRoZSBcIm1haW5cIiBidXR0b24uXG4gICAgICAgIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9Nb3VzZUV2ZW50L2J1dHRvblxuICAgICAgICBpZiAoZXZlbnQuYnV0dG9uICE9PSAwIHx8IGV2ZW50T3B0aW9uID09PSAnY2xpY2snIHx8IGlzTW91c2VMaWtlUG9pbnRlclR5cGUocG9pbnRlclR5cGUsIHRydWUpICYmIGlnbm9yZU1vdXNlKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG5leHRPcGVuID0gZ2V0TmV4dE9wZW4ob3BlbiwgZXZlbnQuY3VycmVudFRhcmdldCwgb3BlbkV2ZW50VHlwZSA9PiBvcGVuRXZlbnRUeXBlID09PSAnY2xpY2snIHx8IG9wZW5FdmVudFR5cGUgPT09ICdtb3VzZWRvd24nKTtcblxuICAgICAgICAvLyBBbmltYXRpb25zIHNvbWV0aW1lcyB3b24ndCBydW4gb24gYSB0eXBlYWJsZSBlbGVtZW50IGlmIHVzaW5nIGEgckFGLlxuICAgICAgICAvLyBGb2N1cyBpcyBhbHdheXMgc2V0IG9uIHRoZXNlIGVsZW1lbnRzLiBGb3IgdG91Y2gsIHdlIG1heSBkZWxheSBvcGVuaW5nLlxuICAgICAgICAvLyBBIHNjcmVlbiByZWFkZXIgcHJlc3Mgb3BlbnMgc3luY2hyb25vdXNseSwgc28gdGhlIHBvcHVwJ3MgZm9jdXMgbGFuZHMgYmVmb3JlIHRoZSByZWFkZXJcbiAgICAgICAgLy8gcmUtc3luY3MgZm9jdXMgdG8gaXRzIGN1cnNvciwgd2hpY2ggd291bGQgb3RoZXJ3aXNlIHJlYWQgYXMgYSBzdHJheSBtb3ZlLlxuICAgICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQobmF0aXZlRXZlbnQpO1xuICAgICAgICBjb25zdCBpc1R5cGVhYmxlID0gaXNUeXBlYWJsZUVsZW1lbnQodGFyZ2V0KTtcbiAgICAgICAgaWYgKGlzVHlwZWFibGUgfHwgcG9pbnRlclR5cGUgPT09ICd2aXJ0dWFsJykge1xuICAgICAgICAgIC8vIEEgdmlydHVhbCBwcmVzcyBtYXkgdGFyZ2V0IGEgZGVzY2VuZGFudCBvZiB0aGUgdHJpZ2dlcjsgdGhlIHRyaWdnZXIgaXMgd2hhdCBvcGVuZWQuXG4gICAgICAgICAgc2V0T3BlbldpdGhUb3VjaERlbGF5KG5leHRPcGVuLCBuYXRpdmVFdmVudCwgaXNUeXBlYWJsZSA/IHRhcmdldCA6IGV2ZW50LmN1cnJlbnRUYXJnZXQsIHBvaW50ZXJUeXBlKTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBDYXB0dXJlIHRoZSBjdXJyZW50VGFyZ2V0IGJlZm9yZSB0aGUgckFGLlxuICAgICAgICAvLyBhcyBSZWFjdCBzZXRzIGl0IHRvIG51bGwgYWZ0ZXIgdGhlIGV2ZW50IGhhbmRsZXIgY29tcGxldGVzLlxuICAgICAgICBjb25zdCBldmVudEN1cnJlbnRUYXJnZXQgPSBldmVudC5jdXJyZW50VGFyZ2V0O1xuXG4gICAgICAgIC8vIFdhaXQgdW50aWwgZm9jdXMgaXMgc2V0IG9uIHRoZSBlbGVtZW50LiBUaGlzIGlzIGFuIGFsdGVybmF0aXZlIHRvXG4gICAgICAgIC8vIGBldmVudC5wcmV2ZW50RGVmYXVsdCgpYCB0byBhdm9pZCA6Zm9jdXMtdmlzaWJsZSBmcm9tIGFwcGVhcmluZyB3aGVuIHVzaW5nIGEgcG9pbnRlci5cbiAgICAgICAgZnJhbWUucmVxdWVzdCgoKSA9PiB7XG4gICAgICAgICAgc2V0T3BlbldpdGhUb3VjaERlbGF5KG5leHRPcGVuLCBuYXRpdmVFdmVudCwgZXZlbnRDdXJyZW50VGFyZ2V0LCBwb2ludGVyVHlwZSk7XG4gICAgICAgIH0pO1xuICAgICAgfSxcbiAgICAgIG9uQ2xpY2soZXZlbnQpIHtcbiAgICAgICAgaWYgKGV2ZW50T3B0aW9uID09PSAnbW91c2Vkb3duLW9ubHknKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHBvaW50ZXJUeXBlID0gcG9pbnRlclR5cGVSZWYuY3VycmVudDtcbiAgICAgICAgaWYgKGV2ZW50T3B0aW9uID09PSAnbW91c2Vkb3duJyAmJiBwb2ludGVyVHlwZSkge1xuICAgICAgICAgIHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc01vdXNlTGlrZVBvaW50ZXJUeXBlKHBvaW50ZXJUeXBlLCB0cnVlKSAmJiBpZ25vcmVNb3VzZSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBvcGVuID0gc3RvcmUuc2VsZWN0KCdvcGVuJyk7XG4gICAgICAgIGNvbnN0IG5leHRPcGVuID0gZ2V0TmV4dE9wZW4ob3BlbiwgZXZlbnQuY3VycmVudFRhcmdldCwgb3BlbkV2ZW50VHlwZSA9PiBvcGVuRXZlbnRUeXBlID09PSAnY2xpY2snIHx8IG9wZW5FdmVudFR5cGUgPT09ICdtb3VzZWRvd24nIHx8IG9wZW5FdmVudFR5cGUgPT09ICdrZXlkb3duJyB8fCBvcGVuRXZlbnRUeXBlID09PSAna2V5dXAnKTtcbiAgICAgICAgc2V0T3BlbldpdGhUb3VjaERlbGF5KG5leHRPcGVuLCBldmVudC5uYXRpdmVFdmVudCwgZXZlbnQuY3VycmVudFRhcmdldCwgcG9pbnRlclR5cGUpO1xuICAgICAgfSxcbiAgICAgIG9uS2V5RG93bigpIHtcbiAgICAgICAgcG9pbnRlclR5cGVSZWYuY3VycmVudCA9IHVuZGVmaW5lZDtcbiAgICAgIH1cbiAgICB9O1xuICB9LCBbZGF0YVJlZiwgZXZlbnRPcHRpb24sIGlnbm9yZU1vdXNlLCByZWFzb24sIHN0b3JlLCBzdGlja0lmT3BlbiwgdG9nZ2xlLCBmcmFtZSwgdG91Y2hPcGVuVGltZW91dCwgdG91Y2hPcGVuRGVsYXldKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gZW5hYmxlZCA/IHtcbiAgICByZWZlcmVuY2VcbiAgfSA6IEVNUFRZX09CSkVDVCwgW2VuYWJsZWQsIHJlZmVyZW5jZV0pO1xufSIsImltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcblxuLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCBjb25zdCBJbnRlcm5hbEJhY2tkcm9wID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gSW50ZXJuYWxCYWNrZHJvcChwcm9wcywgcmVmKSB7XG4gIGNvbnN0IHtcbiAgICBjdXRvdXQsXG4gICAgLi4ub3RoZXJQcm9wc1xuICB9ID0gcHJvcHM7XG4gIGxldCBjbGlwUGF0aDtcbiAgaWYgKGN1dG91dCkge1xuICAgIGNvbnN0IHJlY3QgPSBjdXRvdXQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgY2xpcFBhdGggPSBgcG9seWdvbigwJSAwJSwxMDAlIDAlLDEwMCUgMTAwJSwwJSAxMDAlLDAlIDAlLCR7cmVjdC5sZWZ0fXB4ICR7cmVjdC50b3B9cHgsJHtyZWN0LmxlZnR9cHggJHtyZWN0LmJvdHRvbX1weCwke3JlY3QucmlnaHR9cHggJHtyZWN0LmJvdHRvbX1weCwke3JlY3QucmlnaHR9cHggJHtyZWN0LnRvcH1weCwke3JlY3QubGVmdH1weCAke3JlY3QudG9wfXB4KWA7XG4gIH1cbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KFwiZGl2XCIsIHtcbiAgICByZWY6IHJlZixcbiAgICByb2xlOiBcInByZXNlbnRhdGlvblwiXG4gICAgLy8gRW5zdXJlcyBGbG9hdGluZyBVSSdzIG91dHNpZGUgcHJlc3MgZGV0ZWN0aW9uIHJ1bnMsIGFzIGl0IGNvbnNpZGVyc1xuICAgIC8vIGl0IGFuIGVsZW1lbnQgdGhhdCBleGlzdGVkIHdoZW4gdGhlIHBvcHVwIHJlbmRlcmVkLlxuICAgICxcbiAgICBcImRhdGEtYmFzZS11aS1pbmVydFwiOiBcIlwiLFxuICAgIC4uLm90aGVyUHJvcHMsXG4gICAgc3R5bGU6IHtcbiAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxuICAgICAgaW5zZXQ6IDAsXG4gICAgICB1c2VyU2VsZWN0OiAnbm9uZScsXG4gICAgICBXZWJraXRVc2VyU2VsZWN0OiAnbm9uZScsXG4gICAgICBjbGlwUGF0aFxuICAgIH1cbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIEludGVybmFsQmFja2Ryb3AuZGlzcGxheU5hbWUgPSBcIkludGVybmFsQmFja2Ryb3BcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0Jztcbi8qKlxuICogUHJvdmlkZXMgYSBjcm9zcy1icm93c2VyIHdheSB0byBkZXRlcm1pbmUgdGhlIHR5cGUgb2YgdGhlIHBvaW50ZXIgdXNlZCB0byBjbGljay5cbiAqIFNhZmFyaSBhbmQgRmlyZWZveCBkbyBub3QgcHJvdmlkZSB0aGUgUG9pbnRlckV2ZW50IHRvIHRoZSBjbGljayBoYW5kbGVyICh0aGV5IHVzZSBNb3VzZUV2ZW50KSB5ZXQuXG4gKiBBZGRpdGlvbmFsbHksIHRoaXMgaW1wbGVtZW50YXRpb24gZGV0ZWN0cyBpZiB0aGUgY2xpY2sgd2FzIHRyaWdnZXJlZCBieSB0aGUga2V5Ym9hcmQuXG4gKlxuICogQHBhcmFtIGhhbmRsZXIgVGhlIGZ1bmN0aW9uIHRvIGJlIGNhbGxlZCB3aGVuIHRoZSBidXR0b24gaXMgY2xpY2tlZC4gVGhlIGZpcnN0IHBhcmFtZXRlciBpcyB0aGUgb3JpZ2luYWwgZXZlbnQgYW5kIHRoZSBzZWNvbmQgcGFyYW1ldGVyIGlzIHRoZSBwb2ludGVyIHR5cGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VFbmhhbmNlZENsaWNrSGFuZGxlcihoYW5kbGVyKSB7XG4gIGNvbnN0IGxhc3RDbGlja0ludGVyYWN0aW9uVHlwZVJlZiA9IFJlYWN0LnVzZVJlZignJyk7XG4gIGNvbnN0IGhhbmRsZVBvaW50ZXJEb3duID0gUmVhY3QudXNlQ2FsbGJhY2soZXZlbnQgPT4ge1xuICAgIGlmIChldmVudC5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGxhc3RDbGlja0ludGVyYWN0aW9uVHlwZVJlZi5jdXJyZW50ID0gZXZlbnQucG9pbnRlclR5cGU7XG4gICAgaGFuZGxlcihldmVudCwgZXZlbnQucG9pbnRlclR5cGUpO1xuICB9LCBbaGFuZGxlcl0pO1xuICBjb25zdCBoYW5kbGVDbGljayA9IFJlYWN0LnVzZUNhbGxiYWNrKGV2ZW50ID0+IHtcbiAgICAvLyBldmVudC5kZXRhaWwgaGFzIHRoZSBudW1iZXIgb2YgY2xpY2tzIHBlcmZvcm1lZCBvbiB0aGUgZWxlbWVudC4gMCBtZWFucyBpdCB3YXMgdHJpZ2dlcmVkIGJ5IHRoZSBrZXlib2FyZC5cbiAgICBpZiAoZXZlbnQuZGV0YWlsID09PSAwKSB7XG4gICAgICBoYW5kbGVyKGV2ZW50LCAna2V5Ym9hcmQnKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCdwb2ludGVyVHlwZScgaW4gZXZlbnQpIHtcbiAgICAgIC8vIENocm9tZSBhbmQgRWRnZSBjb3JyZWN0bHkgdXNlIFBvaW50ZXJFdmVudFxuICAgICAgaGFuZGxlcihldmVudCwgZXZlbnQucG9pbnRlclR5cGUpO1xuICAgIH0gZWxzZSB7XG4gICAgICBoYW5kbGVyKGV2ZW50LCBsYXN0Q2xpY2tJbnRlcmFjdGlvblR5cGVSZWYuY3VycmVudCk7XG4gICAgfVxuICAgIGxhc3RDbGlja0ludGVyYWN0aW9uVHlwZVJlZi5jdXJyZW50ID0gJyc7XG4gIH0sIFtoYW5kbGVyXSk7XG4gIHJldHVybiB7XG4gICAgb25DbGljazogaGFuZGxlQ2xpY2ssXG4gICAgb25Qb2ludGVyRG93bjogaGFuZGxlUG9pbnRlckRvd25cbiAgfTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuaW1wb3J0IHsgdXNlRW5oYW5jZWRDbGlja0hhbmRsZXIgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VFbmhhbmNlZENsaWNrSGFuZGxlcic7XG5pbXBvcnQgeyBwbGF0Zm9ybSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtJztcbmltcG9ydCB7IHVzZVZhbHVlQ2hhbmdlZCB9IGZyb20gXCIuLi9pbnRlcm5hbHMvdXNlVmFsdWVDaGFuZ2VkLm1qc1wiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZU9wZW5NZXRob2RUcmlnZ2VyUHJvcHMob3Blbiwgc2V0T3Blbk1ldGhvZCkge1xuICBjb25zdCBoYW5kbGVUcmlnZ2VyQ2xpY2sgPSB1c2VTdGFibGVDYWxsYmFjaygoXywgaW50ZXJhY3Rpb25UeXBlKSA9PiB7XG4gICAgY29uc3QgaXNPcGVuID0gdHlwZW9mIG9wZW4gPT09ICdmdW5jdGlvbicgPyBvcGVuKCkgOiBvcGVuO1xuICAgIGlmICghaXNPcGVuKSB7XG4gICAgICBzZXRPcGVuTWV0aG9kKGludGVyYWN0aW9uVHlwZSB8fCAoXG4gICAgICAvLyBPbiBpT1MgU2FmYXJpLCB0aGUgaGl0c2xvcCBhcm91bmQgdG91Y2ggdGFyZ2V0cyBtZWFucyB0YXBwaW5nIG91dHNpZGUgYW4gZWxlbWVudCdzXG4gICAgICAvLyBib3VuZHMgZG9lcyBub3QgZmlyZSBgcG9pbnRlcmRvd25gIGJ1dCBkb2VzIGZpcmUgYG1vdXNlZG93bmAuIFRoZSBgaW50ZXJhY3Rpb25UeXBlYFxuICAgICAgLy8gd2lsbCBiZSBcIlwiIGluIHRoYXQgY2FzZS5cbiAgICAgIHBsYXRmb3JtLm9zLmlvcyA/ICd0b3VjaCcgOiAnJykpO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IHtcbiAgICBvbkNsaWNrLFxuICAgIG9uUG9pbnRlckRvd25cbiAgfSA9IHVzZUVuaGFuY2VkQ2xpY2tIYW5kbGVyKGhhbmRsZVRyaWdnZXJDbGljayk7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgb25DbGljayxcbiAgICBvblBvaW50ZXJEb3duXG4gIH0pLCBbb25DbGljaywgb25Qb2ludGVyRG93bl0pO1xufVxuXG4vKipcbiAqIERldGVybWluZXMgdGhlIGludGVyYWN0aW9uIHR5cGUgKGtleWJvYXJkLCBtb3VzZSwgdG91Y2gsIGV0Yy4pIHRoYXQgb3BlbmVkIHRoZSBjb21wb25lbnQuXG4gKlxuICogQHBhcmFtIG9wZW4gVGhlIG9wZW4gc3RhdGUgb2YgdGhlIGNvbXBvbmVudC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZU9wZW5JbnRlcmFjdGlvblR5cGUob3Blbikge1xuICBjb25zdCBbb3Blbk1ldGhvZCwgc2V0T3Blbk1ldGhvZF0gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgdHJpZ2dlclByb3BzID0gdXNlT3Blbk1ldGhvZFRyaWdnZXJQcm9wcyhvcGVuLCBzZXRPcGVuTWV0aG9kKTtcbiAgdXNlVmFsdWVDaGFuZ2VkKG9wZW4sIHByZXZpb3VzT3BlbiA9PiB7XG4gICAgaWYgKHByZXZpb3VzT3BlbiAmJiAhb3Blbikge1xuICAgICAgc2V0T3Blbk1ldGhvZChudWxsKTtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIG9wZW5NZXRob2QsXG4gICAgdHJpZ2dlclByb3BzXG4gIH0pLCBbb3Blbk1ldGhvZCwgdHJpZ2dlclByb3BzXSk7XG59Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQVNBLElBQUkscUJBQXFCLENBQUM7QUFDMUIsSUFBSSxxQkFBcUIsQ0FBQztBQUMxQixJQUFJLDZCQUE2QjtBQUlqQyxTQUFTLG9CQUFvQixNQUFNLE1BQU07Q0FDdkMsT0FBTyxrQkFBa0IsSUFBSSxJQUFJLE9BQU87QUFDMUM7QUFDQSxTQUFTLG1CQUFtQixLQUFLLE1BQU0sTUFBTTtDQUMzQyxPQUFPLGNBQWMsS0FBSyxJQUFJLGlCQUFpQixvQkFBb0IsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLFNBQVM7QUFDM0Y7QUFDQSxTQUFTLG1CQUFtQixrQkFBa0I7Q0FDNUMsSUFBSSxPQUFPLGFBQWEsYUFDdEIsT0FBTztDQUVULE1BQU0sTUFBTSxjQUFjLGdCQUFnQjtDQUUxQyxPQURZQSxVQUFZLEdBQ2YsQ0FBQyxDQUFDLGFBQWEsSUFBSSxnQkFBZ0IsY0FBYztBQUM1RDtBQUNBLFNBQVMsOEJBQThCLGtCQUFrQjtDQUV2RCxJQUFJLEVBRGMsT0FBTyxRQUFRLGVBQWUsSUFBSSxZQUFZLElBQUksU0FBUyxvQkFBb0IsUUFBUSxNQUN2RixPQUFPLGFBQWEsYUFDcEMsT0FBTztDQUVULE1BQU0sTUFBTSxjQUFjLGdCQUFnQjtDQUMxQyxNQUFNLE9BQU8sSUFBSTtDQUNqQixNQUFNLE9BQU8sSUFBSTtDQUNqQixNQUFNLGtCQUFrQixvQkFBb0IsTUFBTSxJQUFJO0NBQ3RELE1BQU0sbUNBQW1DLGdCQUFnQixNQUFNO0NBQy9ELE1BQU0sMEJBQTBCLEtBQUssTUFBTTtDQUMzQyxLQUFLLE1BQU0sa0JBQWtCO0NBQzdCLGdCQUFnQixNQUFNLFlBQVk7Q0FDbEMsTUFBTSxTQUFTLGdCQUFnQjtDQUMvQixnQkFBZ0IsTUFBTSxZQUFZO0NBQ2xDLE1BQU0sUUFBUSxnQkFBZ0I7Q0FDOUIsZ0JBQWdCLE1BQU0sWUFBWTtDQUNsQyxLQUFLLE1BQU0sa0JBQWtCO0NBQzdCLE9BQU8sV0FBVztBQUNwQjtBQUNBLFNBQVMsK0JBQStCLGtCQUFrQjtDQUN4RCxNQUFNLE1BQU0sY0FBYyxnQkFBZ0I7Q0FDMUMsTUFBTSxPQUFPLElBQUk7Q0FDakIsTUFBTSxPQUFPLElBQUk7Q0FNakIsTUFBTSxnQkFBZ0Isb0JBQW9CLE1BQU0sSUFBSTtDQUNwRCxNQUFNLDhCQUE4QjtFQUNsQyxXQUFXLGNBQWMsTUFBTTtFQUMvQixXQUFXLGNBQWMsTUFBTTtDQUNqQztDQUNBLE9BQU8sT0FBTyxjQUFjLE9BQU87RUFDakMsV0FBVztFQUNYLFdBQVc7Q0FDYixDQUFDO0NBQ0QsYUFBYTtFQUNYLE9BQU8sT0FBTyxjQUFjLE9BQU8sMkJBQTJCO0NBQ2hFO0FBQ0Y7QUFDQSxTQUFTLDZCQUE2QixrQkFBa0I7Q0FDdEQsTUFBTSxNQUFNLGNBQWMsZ0JBQWdCO0NBQzFDLE1BQU0sT0FBTyxJQUFJO0NBQ2pCLE1BQU0sT0FBTyxJQUFJO0NBQ2pCLE1BQU0sTUFBTUEsVUFBWSxJQUFJO0NBQzVCLElBQUksWUFBWTtDQUNoQixJQUFJLGFBQWE7Q0FDakIsSUFBSSxtQkFBbUI7Q0FDdkIsTUFBTSxjQUFjLGVBQWUsT0FBTztDQUcxQyxJQUFJQyxXQUEyQixJQUFJLGdCQUFnQixTQUFTLE9BQU8sR0FDakUsYUFBYSxDQUFDO0NBRWhCLFNBQVMsYUFBYTtFQUdwQixNQUFNLGFBQWEsSUFBSSxpQkFBaUIsSUFBSTtFQUM1QyxNQUFNLGFBQWEsSUFBSSxpQkFBaUIsSUFBSTtFQUc1QyxNQUFNLHdCQUYyQixXQUFXLG1CQUFtQixHQUFBLENBQ2pCLFNBQVMsWUFDZixJQUFJLHNCQUFzQjtFQUNsRSxZQUFZLEtBQUs7RUFDakIsYUFBYSxLQUFLO0VBQ2xCLHFCQUFxQjtHQUNuQixpQkFBaUIsS0FBSyxNQUFNO0dBQzVCLFdBQVcsS0FBSyxNQUFNO0dBQ3RCLFdBQVcsS0FBSyxNQUFNO0VBQ3hCO0VBQ0EsNkJBQTZCLEtBQUssTUFBTTtFQUN4QyxxQkFBcUI7R0FDbkIsVUFBVSxLQUFLLE1BQU07R0FDckIsUUFBUSxLQUFLLE1BQU07R0FDbkIsT0FBTyxLQUFLLE1BQU07R0FDbEIsV0FBVyxLQUFLLE1BQU07R0FDdEIsV0FBVyxLQUFLLE1BQU07R0FDdEIsV0FBVyxLQUFLLE1BQU07R0FDdEIsZ0JBQWdCLEtBQUssTUFBTTtFQUM3QjtFQUNBLE1BQU0sZ0JBQWdCLEtBQUssZUFBZSxLQUFLO0VBQy9DLE1BQU0sZ0JBQWdCLEtBQUssY0FBYyxLQUFLO0VBQzlDLE1BQU0sdUJBQXVCLFdBQVcsY0FBYyxZQUFZLFdBQVcsY0FBYztFQUMzRixNQUFNLHVCQUF1QixXQUFXLGNBQWMsWUFBWSxXQUFXLGNBQWM7RUFHM0YsTUFBTSxpQkFBaUIsS0FBSyxJQUFJLEdBQUcsSUFBSSxhQUFhLEtBQUssV0FBVztFQUNwRSxNQUFNLGtCQUFrQixLQUFLLElBQUksR0FBRyxJQUFJLGNBQWMsS0FBSyxZQUFZO0VBSXZFLE1BQU0sVUFBVSxXQUFXLFdBQVcsU0FBUyxJQUFJLFdBQVcsV0FBVyxZQUFZO0VBQ3JGLE1BQU0sVUFBVSxXQUFXLFdBQVcsVUFBVSxJQUFJLFdBQVcsV0FBVyxXQUFXO0VBQ3JGLE1BQU0sZ0JBQWdCLG9CQUFvQixNQUFNLElBQUk7RUFDcEQsbUJBQW1CLDhCQUE4QixnQkFBZ0I7RUFPakUsSUFBSSxrQkFBa0I7R0FDcEIsS0FBSyxNQUFNLGtCQUFrQjtHQUM3QixjQUFjLE1BQU0sWUFBWTtHQUNoQyxjQUFjLE1BQU0sWUFBWTtHQUNoQztFQUNGO0VBQ0EsT0FBTyxPQUFPLEtBQUssT0FBTztHQUN4QixpQkFBaUI7R0FDakIsV0FBVztHQUNYLFdBQVc7RUFDYixDQUFDO0VBQ0QsSUFBSSxpQkFBaUIsc0JBQ25CLEtBQUssTUFBTSxZQUFZO0VBRXpCLElBQUksaUJBQWlCLHNCQUNuQixLQUFLLE1BQU0sWUFBWTtFQUV6QixPQUFPLE9BQU8sS0FBSyxPQUFPO0dBQ3hCLFVBQVU7R0FDVixRQUFRLFdBQVcsa0JBQWtCLGlCQUFpQixVQUFVLGdCQUFnQixPQUFPO0dBQ3ZGLE9BQU8sV0FBVyxpQkFBaUIsZ0JBQWdCLFVBQVUsZUFBZSxPQUFPO0dBQ25GLFdBQVc7R0FFWCxXQUFXO0dBQ1gsV0FBVztHQUNYLGdCQUFnQjtFQUNsQixDQUFDO0VBQ0QsS0FBSyxZQUFZO0VBQ2pCLEtBQUssYUFBYTtFQUNsQixLQUFLLGFBQWEsOEJBQThCLEVBQUU7RUFDbEQsS0FBSyxNQUFNLGlCQUFpQjtDQUM5QjtDQUNBLFNBQVMsVUFBVTtFQUNqQixPQUFPLE9BQU8sS0FBSyxPQUFPLGtCQUFrQjtFQUM1QyxPQUFPLE9BQU8sS0FBSyxPQUFPLGtCQUFrQjtFQUM1QyxJQUFJLENBQUMsa0JBQWtCO0dBQ3JCLEtBQUssWUFBWTtHQUNqQixLQUFLLGFBQWE7R0FDbEIsS0FBSyxnQkFBZ0IsNEJBQTRCO0dBQ2pELEtBQUssTUFBTSxpQkFBaUI7RUFDOUI7Q0FDRjtDQUNBLFNBQVMsZUFBZTtFQUN0QixRQUFRO0VBQ1IsWUFBWSxRQUFRLFVBQVU7Q0FDaEM7Q0FDQSxXQUFXO0NBQ1gsTUFBTSxvQkFBb0IsaUJBQWlCLEtBQUssVUFBVSxZQUFZO0NBQ3RFLGFBQWE7RUFDWCxZQUFZLE9BQU87RUFDbkIsUUFBUTtFQUlSLElBQUksT0FBTyxJQUFJLHdCQUF3QixZQUNyQyxrQkFBa0I7Q0FFdEI7QUFDRjtBQUNBLElBQU0sZUFBTixNQUFtQjtDQUNqQixZQUFZO0NBQ1osVUFBVTtDQUNWLGNBQWMsUUFBUSxPQUFPO0NBQzdCLGdCQUFnQixRQUFRLE9BQU87Q0FDL0IsUUFBUSxrQkFBa0I7RUFDeEIsS0FBSyxhQUFhO0VBQ2xCLElBQUksS0FBSyxjQUFjLEtBQUssS0FBSyxZQUFZLE1BQzNDLEtBQUssWUFBWSxNQUFNLFNBQVMsS0FBSyxLQUFLLGdCQUFnQixDQUFDO0VBRTdELE9BQU8sS0FBSztDQUNkO0NBQ0EsZ0JBQWdCO0VBQ2QsS0FBSyxhQUFhO0VBQ2xCLElBQUksS0FBSyxjQUFjLEtBQUssS0FBSyxTQUMvQixLQUFLLGNBQWMsTUFBTSxHQUFHLEtBQUssTUFBTTtDQUUzQztDQUNBLGVBQWU7RUFDYixJQUFJLEtBQUssY0FBYyxLQUFLLEtBQUssU0FBUztHQUN4QyxLQUFLLFVBQVU7R0FDZixLQUFLLFVBQVU7RUFDakI7Q0FDRjtDQUNBLEtBQUssa0JBQWtCO0VBQ3JCLElBQUksS0FBSyxjQUFjLEtBQUssS0FBSyxZQUFZLE1BQzNDO0VBRUYsTUFBTSxNQUFNLGNBQWMsZ0JBQWdCO0VBQzFDLE1BQU0sT0FBTyxJQUFJO0VBQ2pCLE1BQU0sT0FBTyxJQUFJO0VBQ2pCLE1BQU0sTUFBTUQsVUFBWSxJQUFJO0VBSzVCLElBQUksbUJBQW1CLEtBQUssTUFBTSxJQUFJLEdBQUc7R0FDdkMsTUFBTSxXQUFXLElBQUksSUFBSSx1QkFBdUI7SUFDOUMsSUFBSSxtQkFBbUIsS0FBSyxNQUFNLElBQUksR0FDcEM7SUFFRixTQUFTLFdBQVc7SUFDcEIsS0FBSyxVQUFVO0lBQ2YsS0FBSyxLQUFLLGdCQUFnQjtHQUM1QixDQUFDO0dBSUQsTUFBTSxVQUFVLEVBQ2QsWUFBWSxLQUNkO0dBQ0EsU0FBUyxRQUFRLE1BQU0sT0FBTztHQUM5QixTQUFTLFFBQVEsTUFBTSxPQUFPO0dBQzlCLEtBQUssZ0JBQWdCLFNBQVMsV0FBVztHQUN6QztFQUNGO0VBQ0EsTUFBTSx1QkFBdUJFLE9BQW1CLENBQUMsbUJBQW1CLGdCQUFnQjtFQVFwRixLQUFLLFVBQVUsdUJBQXVCLCtCQUErQixnQkFBZ0IsSUFBSSw2QkFBNkIsZ0JBQWdCO0NBQ3hJO0FBQ0Y7QUFDQSxJQUFNLGdCQUFnQixJQUFJLGFBQWE7Ozs7Ozs7QUFRdkMsU0FBZ0IsY0FBYyxVQUFVLE1BQU0sbUJBQW1CLE1BQU07Q0FDckUseUJBQXlCO0VBQ3ZCLElBQUksQ0FBQyxTQUNIO0VBRUYsT0FBTyxjQUFjLFFBQVEsZ0JBQWdCO0NBQy9DLEdBQUcsQ0FBQyxTQUFTLGdCQUFnQixDQUFDO0FBQ2hDOzs7QUMvUUEsSUFBSSxRQUFRO0FBQ1osU0FBZ0IsYUFBYSxJQUFJLFVBQVUsQ0FBQyxHQUFHO0NBQzdDLE1BQU0sRUFDSixnQkFBZ0IsT0FDaEIsT0FBTyxPQUNQLGdCQUNFO0NBQ0oscUJBQXFCLEtBQUs7Q0FDMUIsU0FBUyxPQUFPO0VBQ2QsSUFBSSxlQUFlLENBQUMsWUFBWSxHQUM5QjtFQUVGLElBQUksTUFBTSxFQUNSLGNBQ0YsQ0FBQztDQUNIO0NBQ0EsSUFBSSxNQUFNO0VBQ1IsS0FBSztFQUNMLE9BQU87Q0FDVDtDQUNBLE1BQU0sZUFBZSxzQkFBc0IsSUFBSTtDQUMvQyxRQUFRO0NBQ1IsYUFBYTtFQUNYLElBQUksVUFBVSxjQUFjO0dBQzFCLHFCQUFxQixZQUFZO0dBQ2pDLFFBQVE7RUFDVjtDQUNGO0FBQ0Y7O0FDekJBLElBQU0sYUFBYTtBQUNuQixJQUFJLHVDQUF1QixJQUFJLFFBQVE7QUFDdkMsSUFBSSwwQ0FBMEIsSUFBSSxRQUFRO0FBQzFDLElBQUksbUNBQW1CLElBQUksUUFBUTtBQUNuQyxJQUFJLFlBQVk7QUFDaEIsU0FBUyxXQUFXLE1BQU07Q0FDeEIsSUFBSSxDQUFDLE1BQ0gsT0FBTztDQUVULE9BQU8sYUFBYSxJQUFJLElBQUksS0FBSyxPQUFPLFdBQVcsS0FBSyxVQUFVO0FBQ3BFO0FBQ0EsSUFBTSxtQkFBbUIsUUFBUSxZQUFZLFFBQVEsS0FBSSxXQUFVO0NBQ2pFLElBQUksT0FBTyxTQUFTLE1BQU0sR0FDeEIsT0FBTztDQUVULE1BQU0sa0JBQWtCLFdBQVcsTUFBTTtDQUN6QyxJQUFJLE9BQU8sU0FBUyxlQUFlLEdBQ2pDLE9BQU87Q0FFVCxPQUFPO0FBQ1QsQ0FBQyxDQUFDLENBQUMsUUFBTyxNQUFLLEtBQUssSUFBSTtBQUN4QixJQUFNLGdCQUFlLFlBQVc7Q0FDOUIsTUFBTSx1QkFBTyxJQUFJLElBQUk7Q0FDckIsUUFBUSxTQUFRLFdBQVU7RUFDeEIsSUFBSSxPQUFPO0VBQ1gsT0FBTyxRQUFRLENBQUMsS0FBSyxJQUFJLElBQUksR0FBRztHQUM5QixLQUFLLElBQUksSUFBSTtHQUNiLE9BQU8sS0FBSztFQUNkO0NBQ0YsQ0FBQztDQUNELE9BQU87QUFDVDtBQUNBLElBQU0sMEJBQTBCLE1BQU0sY0FBYyxpQkFBaUI7Q0FDbkUsTUFBTSxVQUFVLENBQUM7Q0FDakIsTUFBTSxRQUFPLFdBQVU7RUFDckIsSUFBSSxDQUFDLFVBQVUsYUFBYSxJQUFJLE1BQU0sR0FDcEM7RUFFRixNQUFNLEtBQUssT0FBTyxRQUFRLENBQUMsQ0FBQyxTQUFRLFNBQVE7R0FDMUMsSUFBSSxZQUFZLElBQUksTUFBTSxVQUN4QjtHQUVGLElBQUksYUFBYSxJQUFJLElBQUksR0FDdkIsS0FBSyxJQUFJO1FBRVQsUUFBUSxLQUFLLElBQUk7RUFFckIsQ0FBQztDQUNIO0NBQ0EsS0FBSyxJQUFJO0NBQ1QsT0FBTztBQUNUO0FBQ0EsU0FBUyx1QkFBdUIsMEJBQTBCLE1BQU0sWUFBWSxFQUMxRSxPQUFPLFFBQ047Q0FDRCxNQUFNLGdCQUFnQixnQkFBZ0IsTUFBTSx3QkFBd0I7Q0FDcEUsTUFBTSxnQkFBZ0IsT0FBTyx1QkFBdUIsTUFBTSxhQUFhLGFBQWEsR0FBRyxJQUFJLElBQUksYUFBYSxDQUFDLElBQUksQ0FBQztDQUNsSCxNQUFNLGlCQUFpQixDQUFDO0NBQ3hCLE1BQU0saUJBQWlCLENBQUM7Q0FDeEIsSUFBSSxZQUFZO0VBQ2QsTUFBTSxtQkFBbUIsZ0JBQWdCLE1BQU0sTUFBTSxLQUFLLEtBQUssaUJBQWlCLGFBQWEsQ0FBQyxDQUFDO0VBQy9GLE1BQU0sa0JBQWtCLGNBQWMsT0FBTyxnQkFBZ0I7RUFFN0QsdUJBRDhDLE1BQU0sYUFBYSxlQUFlLEdBQUcsSUFBSSxJQUFJLGVBQWUsQ0FDN0YsQ0FBQyxDQUFDLFNBQVEsU0FBUTtHQUM3QixNQUFNLE9BQU8sS0FBSyxhQUFhLGFBQWE7R0FDNUMsTUFBTSxnQkFBZ0IsU0FBUyxRQUFRLFNBQVM7R0FDaEQsTUFBTSxnQkFBZ0IscUJBQXFCLElBQUksSUFBSSxLQUFLLEtBQUs7R0FDN0QscUJBQXFCLElBQUksTUFBTSxZQUFZO0dBQzNDLGVBQWUsS0FBSyxJQUFJO0dBQ3hCLElBQUksaUJBQWlCLEtBQUssZUFDeEIsd0JBQXdCLElBQUksSUFBSTtHQUVsQyxJQUFJLENBQUMsZUFDSCxLQUFLLGFBQWEsZUFBZSxNQUFNO0VBRTNDLENBQUM7Q0FDSDtDQUNBLElBQUksTUFDRixjQUFjLFNBQVEsU0FBUTtFQUM1QixNQUFNLGVBQWUsaUJBQWlCLElBQUksSUFBSSxLQUFLLEtBQUs7RUFDeEQsaUJBQWlCLElBQUksTUFBTSxXQUFXO0VBQ3RDLGVBQWUsS0FBSyxJQUFJO0VBQ3hCLElBQUksZ0JBQWdCLEdBQ2xCLEtBQUssYUFBYSxZQUFZLEVBQUU7Q0FFcEMsQ0FBQztDQUVILGFBQWE7Q0FDYixhQUFhO0VBQ1gsZUFBZSxTQUFRLFlBQVc7R0FDaEMsTUFBTSxnQkFBZ0IscUJBQXFCLElBQUksT0FBTyxLQUFLLEtBQUs7R0FDaEUscUJBQXFCLElBQUksU0FBUyxZQUFZO0dBQzlDLElBQUksQ0FBQyxjQUFjO0lBQ2pCLElBQUksQ0FBQyx3QkFBd0IsSUFBSSxPQUFPLEdBQ3RDLFFBQVEsZ0JBQWdCLGFBQWE7SUFFdkMsd0JBQXdCLE9BQU8sT0FBTztHQUN4QztFQUNGLENBQUM7RUFDRCxJQUFJLE1BQ0YsZUFBZSxTQUFRLFlBQVc7R0FDaEMsTUFBTSxlQUFlLGlCQUFpQixJQUFJLE9BQU8sS0FBSyxLQUFLO0dBQzNELGlCQUFpQixJQUFJLFNBQVMsV0FBVztHQUN6QyxJQUFJLENBQUMsYUFDSCxRQUFRLGdCQUFnQixVQUFVO0VBRXRDLENBQUM7RUFFSCxhQUFhO0VBQ2IsSUFBSSxDQUFDLFdBQVc7R0FDZCx1Q0FBdUIsSUFBSSxRQUFRO0dBQ25DLDBDQUEwQixJQUFJLFFBQVE7R0FDdEMsbUNBQW1CLElBQUksUUFBUTtFQUNqQztDQUNGO0FBQ0Y7QUFDQSxTQUFnQixXQUFXLGVBQWUsVUFBVSxDQUFDLEdBQUc7Q0FDdEQsTUFBTSxFQUNKLGFBQWEsT0FDYixPQUFPLFNBQ0w7Q0FDSixNQUFNLE9BQU8sY0FBYyxjQUFjLEVBQUUsQ0FBQyxDQUFDO0NBQzdDLE9BQU8sdUJBQXVCLGVBQWUsTUFBTSxZQUFZLEVBQzdELEtBQ0YsQ0FBQztBQUNIOzs7QUNuR0EsU0FBUyxhQUFhLE9BQU8scUJBQXFCO0NBQ2hELE1BQU0sTUFBTUMsVUFBWSxVQUFVLEtBQUssQ0FBQztDQUN4QyxJQUFJLGlCQUFpQixJQUFJLGVBQ3ZCLE9BQU87Q0FFVCxJQUFJLGlCQUFpQixJQUFJLFlBR3ZCLE9BQU8sdUJBQXVCO0NBRWhDLElBQUksaUJBQWlCLE9BR25CLE9BQU8sTUFBTSxnQkFBZ0IsZUFBZSxLQUFLLElBQUksYUFBYSx1QkFBdUI7Q0FFM0YsSUFBSSxhQUFhLE9BQ2YsT0FBTztDQUVULElBQUksaUJBQWlCLElBQUksWUFFdkIsT0FBTyx3QkFBd0IsTUFBTSxXQUFXLElBQUksYUFBYTtDQUVuRSxPQUFPO0FBQ1Q7QUFDQSxJQUFNLGFBQWE7QUFDbkIsSUFBSSw0QkFBNEIsQ0FBQztBQUNqQyxTQUFTLDZDQUE2QztDQUNwRCw0QkFBNEIsMEJBQTBCLFFBQU8sVUFBUztFQUNwRSxPQUFPLE1BQU0sTUFBTSxDQUFDLEVBQUU7Q0FDeEIsQ0FBQztBQUNIO0FBQ0EsU0FBUyw0QkFBNEIsU0FBUztDQUM1QywyQ0FBMkM7Q0FDM0MsSUFBSSxXQUFXLFlBQVksT0FBTyxNQUFNLFFBQVE7RUFDOUMsMEJBQTBCLEtBQUssSUFBSSxRQUFRLE9BQU8sQ0FBQztFQUNuRCxJQUFJLDBCQUEwQixTQUFTLFlBQ3JDLDRCQUE0QiwwQkFBMEIsTUFBTSxHQUFXO0NBRTNFO0FBQ0Y7QUFDQSxTQUFTLDhCQUE4QjtDQUNyQywyQ0FBMkM7Q0FDM0MsT0FBTywwQkFBMEIsMEJBQTBCLFNBQVMsRUFBRSxFQUFFLE1BQU07QUFDaEY7QUFDQSxTQUFTLHdCQUF3QixXQUFXO0NBQzFDLElBQUksQ0FBQyxXQUNILE9BQU87Q0FFVCxJQUFJLFdBQVcsU0FBUyxHQUN0QixPQUFPO0NBRVQsT0FBTyxTQUFTLFNBQVMsQ0FBQyxDQUFDLE1BQU07QUFDbkM7QUFDQSxTQUFTLGVBQWUsc0JBQXNCO0NBQzVDLElBQUkscUJBQXFCLGFBQWEsVUFBVSxLQUFLLENBQUMscUJBQXFCLGFBQWEsZUFBZSxHQUNyRztDQUVGLElBQUksQ0FBQyxxQkFBcUIsYUFBYSxNQUFNLENBQUMsRUFBRSxTQUFTLFFBQVEsR0FDL0Q7Q0FHRixNQUFNLGtCQURvQixVQUFVLG9CQUNJLENBQUMsQ0FBQyxRQUFPLFlBQVc7RUFDMUQsTUFBTSxlQUFlLFFBQVEsYUFBYSxlQUFlLEtBQUs7RUFDOUQsT0FBTyxXQUFXLE9BQU8sS0FBSyxRQUFRLGFBQWEsZUFBZSxLQUFLLENBQUMsYUFBYSxXQUFXLEdBQUc7Q0FDckcsQ0FBQztDQUNELE1BQU0sV0FBVyxxQkFBcUIsYUFBYSxVQUFVO0NBQzdELElBQUksZ0JBQWdCLFdBQVcsR0FDekI7TUFBQSxhQUFhLEtBQUs7R0FDcEIscUJBQXFCLGFBQWEsWUFBWSxHQUFHO0dBR2pELHFCQUFxQixhQUFhLGlCQUFpQixHQUFHO0VBQ3hEO1FBQ0ssSUFBSSxhQUFhLFFBQVEscUJBQXFCLGFBQWEsZUFBZSxLQUFLLHFCQUFxQixhQUFhLGVBQWUsTUFBTSxNQUFNO0VBQ2pKLHFCQUFxQixhQUFhLFlBQVksSUFBSTtFQUNsRCxxQkFBcUIsYUFBYSxpQkFBaUIsSUFBSTtDQUN6RDtBQUNGOzs7Ozs7QUFNQSxTQUFnQixxQkFBcUIsT0FBTztDQUMxQyxNQUFNLEVBQ0osU0FBUyxPQUNULFVBQ0EsV0FBVyxPQUNYLGVBQWUsTUFDZixjQUFjLE1BQ2QscUJBQ0EsZUFBZSxPQUNmLFFBQVEsTUFDUixrQkFBa0IsTUFDbEIsc0JBQXNCLElBQ3RCLHNCQUNBLDBCQUNBLDRCQUNBLGNBQ0Esc0JBQ0U7Q0FDSixNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxlQUFlLE1BQU0sU0FBUyxxQkFBcUI7Q0FDekQsTUFBTSxXQUFXLE1BQU0sU0FBUyxpQkFBaUI7Q0FDakQsTUFBTSxFQUNKLFFBQ0EsWUFDRSxNQUFNO0NBQ1YsTUFBTSxZQUFZLHdCQUF3QixRQUFRLFFBQVEsaUJBQWlCLE1BQU07Q0FDakYsTUFBTSxxQkFBcUIsaUJBQWlCO0NBSzVDLE1BQU0sOEJBQThCLG1CQUFtQixZQUFZLEtBQUs7Q0FDeEUsTUFBTSxrQkFBa0IsY0FBYyxZQUFZO0NBQ2xELE1BQU0saUJBQWlCLGNBQWMsV0FBVztDQUdoRCxNQUFNLHlCQUF5QixjQUFjLG1CQUFtQjtDQUNoRSxNQUFNLHlCQUF5QixjQUFjLG1CQUFtQjtDQUNoRSxNQUFNLFVBQVUsY0FBYyxJQUFJO0NBQ2xDLE1BQU0sT0FBTyxnQkFBZ0IsWUFBWTtDQUN6QyxNQUFNLGdCQUFnQixpQkFBaUI7Q0FDdkMsTUFBTSx3QkFBQSxhQUE4QixPQUFPLEtBQUs7Q0FDaEQsTUFBTSxtQkFBQSxhQUF5QixPQUFPLEtBQUs7Q0FDM0MsTUFBTSx3QkFBQSxhQUE4QixPQUFPLEtBQUs7Q0FDaEQsTUFBTSx5QkFBQSxhQUErQixPQUFPLElBQUk7Q0FDaEQsTUFBTSxlQUFBLGFBQXFCLE9BQU8sRUFBRTtDQUNwQyxNQUFNLHlCQUFBLGFBQStCLE9BQU8sRUFBRTtDQUM5QyxNQUFNLGlCQUFBLGFBQXVCLE9BQU8sSUFBSTtDQUN4QyxNQUFNLGdCQUFBLGFBQXNCLE9BQU8sSUFBSTtDQUN2QyxNQUFNLHVCQUF1QixjQUFjLGdCQUFnQiw0QkFBNEIsZUFBZSxlQUFlO0NBQ3JILE1BQU0sc0JBQXNCLGNBQWMsZUFBZSxlQUFlLGNBQWM7Q0FDdEYsTUFBTSxjQUFjLFdBQVc7Q0FDL0IsTUFBTSxxQkFBcUIsV0FBVztDQUN0QyxNQUFNLG9CQUFvQixrQkFBa0I7Q0FDNUMsTUFBTSxpQkFBaUIsaUJBQWlCO0NBQ3hDLE1BQU0sdUJBQXVCLHdCQUF3QixRQUFRO0NBQzdELE1BQU0scUJBQXFCLG1CQUFtQixZQUFZLHlCQUF5QjtFQUNqRixPQUFPLFlBQVksU0FBUyxTQUFTLElBQUksQ0FBQztDQUM1QyxDQUFDO0NBQ0QsTUFBTSw0QkFBNEIsd0JBQXdCLG9CQUFvQixDQUFDLENBQUMsUUFBTyxZQUFXLFdBQVcsSUFBSSxLQUFLLENBQUMsQ0FBQztDQUd4SCxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLFlBQVksQ0FBQyxPQUNmO0VBRUYsU0FBUyxVQUFVLE9BQU87R0FDeEIsSUFBSSxNQUFNLFFBQVEsT0FFWjtRQUFBLFNBQVMsc0JBQXNCLGNBQWMsY0FBYyxvQkFBb0IsQ0FBQyxDQUFDLEtBQUssbUJBQW1CLENBQUMsQ0FBQyxXQUFXLEtBQUssQ0FBQyw2QkFDOUgsVUFBVSxLQUFLO0dBQUE7RUFHckI7RUFDQSxNQUFNLE1BQU0sY0FBYyxvQkFBb0I7RUFDOUMsT0FBTyxpQkFBaUIsS0FBSyxXQUFXLFNBQVM7Q0FDbkQsR0FBRztFQUFDO0VBQVU7RUFBc0I7RUFBTztFQUE2QjtDQUFrQixDQUFDO0NBRzNGLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksWUFBWSxDQUFDLE1BQ2Y7RUFFRixNQUFNLE1BQU0sY0FBYyxvQkFBb0I7RUFDOUMsU0FBUywwQkFBMEI7R0FDakMsc0JBQXNCLFVBQVU7RUFDbEM7RUFDQSxTQUFTLGNBQWMsT0FBTztHQUM1QixNQUFNLFNBQVMsVUFBVSxLQUFLO0dBQzlCLE1BQU0saUJBQWlCLDBCQUEwQjtHQUNqRCxNQUFNLHNCQUFzQixTQUFTLFVBQVUsTUFBTSxLQUFLLFNBQVMsY0FBYyxNQUFNLEtBQUssU0FBUyxlQUFlLFlBQVksTUFBTSxLQUFLLGVBQWUsTUFBSyxZQUFXLFlBQVksVUFBVSxTQUFTLFNBQVMsTUFBTSxDQUFDO0dBQ3pOLHNCQUFzQixVQUFVLENBQUM7R0FDakMsdUJBQXVCLFVBQVUsTUFBTSxlQUFlO0dBQ3RELElBQUksUUFBUSxRQUFRLDhCQUErQixHQUFHO0lBQ3BELGlCQUFpQixVQUFVO0lBRzNCLG1CQUFtQixNQUFNLFNBQVM7S0FDaEMsaUJBQWlCLFVBQVU7SUFDN0IsQ0FBQztHQUNIO0VBQ0Y7RUFDQSxTQUFTLFlBQVk7R0FDbkIsdUJBQXVCLFVBQVU7RUFDbkM7RUFDQSxPQUFPLGNBQWMsaUJBQWlCLEtBQUssZUFBZSxlQUFlLElBQUksR0FBRyxpQkFBaUIsS0FBSyxhQUFhLHlCQUF5QixJQUFJLEdBQUcsaUJBQWlCLEtBQUssaUJBQWlCLHlCQUF5QixJQUFJLEdBQUcsaUJBQWlCLEtBQUssV0FBVyxXQUFXLElBQUksR0FHMVEsdUJBQXVCO0NBQ3pCLEdBQUc7RUFBQztFQUFVO0VBQVU7RUFBYztFQUFzQjtFQUFNO0VBQWU7RUFBb0I7Q0FBeUIsQ0FBQztDQUcvSCxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLFlBQVksQ0FBQyxpQkFDZjtFQUVGLE1BQU0sTUFBTSxjQUFjLG9CQUFvQjtFQUc5QyxTQUFTLG9CQUFvQjtHQUMzQixpQkFBaUIsVUFBVTtHQUMzQixtQkFBbUIsTUFBTSxTQUFTO0lBQ2hDLGlCQUFpQixVQUFVO0dBQzdCLENBQUM7RUFDSDtFQUNBLFNBQVMsY0FBYyxPQUFPO0dBQzVCLE1BQU0sU0FBUyxVQUFVLEtBQUs7R0FDOUIsSUFBSSxXQUFXLE1BQU0sR0FDbkIsdUJBQXVCLFVBQVU7RUFFckM7RUFDQSxTQUFTLG1CQUFtQixPQUFPO0dBQ2pDLE1BQU0sZ0JBQWdCLE1BQU07R0FDNUIsTUFBTSxnQkFBZ0IsTUFBTTtHQUM1QixNQUFNLFNBQVMsVUFBVSxLQUFLO0dBSzlCLElBQUksU0FBUyxpQkFBaUIsUUFBUSxVQUFVLFFBQVEsU0FBUyxVQUFVLE1BQU0sR0FDL0UsNEJBQTRCLE1BQU07R0FFcEMscUJBQXFCO0lBQ25CLE1BQU0sU0FBUyxVQUFVO0lBQ3pCLE1BQU0sV0FBVyxNQUFNLFFBQVE7SUFDL0IsTUFBTSxpQkFBaUIsMEJBQTBCO0lBQ2pELE1BQU0sc0JBQXNCLGVBQWUsYUFBYSxnQkFBZ0IsYUFBYSxDQUFDLEtBQUs7S0FBQyxlQUFlO0tBQVMsY0FBYztLQUFTLGVBQWUsZ0JBQWdCO0tBQVMsZUFBZSxlQUFlO0tBQVMsZUFBZSxpQkFBaUI7S0FBUyxlQUFlLGdCQUFnQjtLQUFTLFdBQVcsd0JBQXdCO0tBQUcsV0FBVyxvQkFBb0I7SUFBQyxDQUFDLENBQUMsU0FBUyxhQUFhO0lBQ3pZLE1BQU0sdUJBQXVCLEVBQUUsU0FBUyxjQUFjLGFBQWEsS0FBSyxTQUFTLFVBQVUsYUFBYSxLQUFLLFNBQVMsZUFBZSxRQUFRLEtBQUssU0FBUyxlQUFlLFlBQVksYUFBYSxLQUFLLGVBQWUsTUFBSyxZQUFXLFlBQVksaUJBQWlCLFNBQVMsU0FBUyxhQUFhLENBQUMsS0FBSyxTQUFTLG9CQUFtQixZQUFXLFNBQVMsU0FBUyxhQUFhLENBQUMsS0FBSyx1QkFBdUIsU0FBUyxnQkFBZ0IsS0FBSyxTQUFTLFNBQVMsTUFBTSxDQUFDLENBQUMsTUFBSyxTQUFRLFNBQVMsS0FBSyxTQUFTLFNBQVMsVUFBVSxhQUFhLEtBQUssU0FBUyxLQUFLLFNBQVMsU0FBUyxjQUFjLGFBQWEsQ0FBQyxLQUFLLGlCQUFpQixLQUFLLFNBQVMsU0FBUyxNQUFNLENBQUMsQ0FBQyxNQUFLLFNBQVEsQ0FBQyxLQUFLLFNBQVMsU0FBUyxVQUFVLHdCQUF3QixLQUFLLFNBQVMsU0FBUyxRQUFRLENBQUMsQ0FBQyxDQUFDLFNBQVMsYUFBYSxLQUFLLEtBQUssU0FBUyxTQUFTLGlCQUFpQixhQUFhO0lBQ3Z6QixJQUFJLGtCQUFrQixnQkFBZ0Isc0JBQ3BDLGVBQWUsb0JBQW9CO0lBS3JDLElBQUksZ0JBQWdCLGtCQUFrQixnQkFBZ0IsQ0FBQyxpQkFBaUIsTUFBTSxLQUFLLGNBQWMsR0FBRyxNQUFNLElBQUksTUFBTTtLQUdsSCxJQUFJLGNBQWMsb0JBQW9CLEdBQUc7TUFDdkMscUJBQXFCLE1BQU07TUFHM0IsSUFBSSxpQkFBaUIsU0FBUztPQUs1QixrQkFBa0IsY0FBYztRQUM5QixxQkFBcUIsTUFBTTtPQUM3QixDQUFDO09BQ0Q7TUFDRjtLQUNGO0tBQ0EsTUFBTSxrQkFBa0IsbUJBQW1CO0tBQzNDLE1BQU0sZUFBZSx1QkFBdUI7S0FDNUMsTUFBTSxlQUFlLGdCQUFnQixnQkFBZ0IsU0FBUyxZQUFZLElBQUksZUFBZSxTQUFTLGdCQUFnQixnQkFBZ0IsU0FBUyxNQUFNO0tBQ3JKLElBQUksY0FBYyxXQUFXLEdBQzNCLFlBQVksTUFBTTtJQUV0QjtJQUdBLElBQUksUUFBUSxRQUFRLGlCQUFpQjtLQUNuQyxRQUFRLFFBQVEsa0JBQWtCO0tBQ2xDO0lBQ0Y7SUFJQSxLQUFLLDhCQUE4QixPQUFPLENBQUMsVUFBVSxpQkFBaUIsd0JBQXdCLENBQUMsaUJBQWlCLFlBUWhILCtCQUErQixrQkFBa0IsNEJBQTRCLElBQUk7S0FDL0Usc0JBQXNCLFVBQVU7S0FDaEMsTUFBTSxRQUFRLE9BQU8seUJBQXlCQyxVQUFrQixLQUFLLENBQUM7SUFDeEU7R0FDRixDQUFDO0VBQ0g7RUFDQSxTQUFTLHNCQUFzQjtHQUM3QixJQUFJLHNCQUFzQixTQUN4QjtHQUVGLFFBQVEsUUFBUSxrQkFBa0I7R0FDbEMsWUFBWSxNQUFNLFNBQVM7SUFDekIsUUFBUSxRQUFRLGtCQUFrQjtHQUNwQyxDQUFDO0VBQ0g7RUFDQSxNQUFNLHNCQUFzQixjQUFjLFlBQVksSUFBSSxlQUFlO0VBQ3pFLElBQUksQ0FBQyxZQUFZLENBQUMscUJBQ2hCO0VBRUYsT0FBTyxjQUFjLHVCQUF1QixpQkFBaUIscUJBQXFCLFlBQVksa0JBQWtCLEdBQUcsdUJBQXVCLGlCQUFpQixxQkFBcUIsZUFBZSxpQkFBaUIsR0FBRyxZQUFZLGlCQUFpQixVQUFVLFdBQVcsYUFBYSxHQUFHLFlBQVksaUJBQWlCLFVBQVUsWUFBWSxrQkFBa0IsR0FBRyxZQUFZLGlCQUFpQixpQkFBaUIsVUFBVSxZQUFZLHFCQUFxQixJQUFJLENBQUM7Q0FDN2IsR0FBRztFQUFDO0VBQVU7RUFBYztFQUFVO0VBQXNCO0VBQU87RUFBTTtFQUFlO0VBQU87RUFBaUI7RUFBYztFQUFvQjtFQUE2QjtFQUFXO0VBQVM7RUFBYTtFQUFvQjtFQUFtQjtFQUFzQjtFQUEwQjtDQUF5QixDQUFDO0NBR2pVLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksWUFBWSxDQUFDLFlBQVksQ0FBQyxNQUM1QjtFQUlGLE1BQU0sY0FBYyxNQUFNLEtBQUssZUFBZSxZQUFZLGlCQUFpQixJQUFJLGdCQUFnQixRQUFRLEVBQUUsRUFBRSxLQUFLLENBQUMsQ0FBQztFQUVsSCxNQUFNLG9DQURZLE9BQU8saUJBQWlCLEtBQUssU0FBUyxTQUFTLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBQSxDQUM5QixNQUFLLFNBQVEsbUJBQW1CLEtBQUssU0FBUyxTQUFTLGdCQUFnQixJQUFJLENBQUMsQ0FBQyxFQUFFLFNBQVMsU0FBUztFQUdwSixNQUFNLG9CQUFvQixXQURIO0dBQUMsR0FBRztJQURJO0lBQVUsR0FBRztJQUFhLGVBQWU7SUFBUyxjQUFjO0lBQVMsZUFBZSxpQkFBaUI7SUFBUyxlQUFlLGdCQUFnQjtJQUFTLEdBQUcsMEJBQTBCO0dBQ3ZLO0dBQUc7R0FBa0MsV0FBVyx3QkFBd0I7R0FBRyxXQUFXLG9CQUFvQjtHQUFHLDhCQUE4QixlQUFlO0VBQUksQ0FBQyxDQUFDLFFBQU8sTUFBSyxLQUFLLElBQzNMLEdBQWdCO0dBQ25ELFlBQVksU0FBUztHQUNyQixNQUFNO0VBQ1IsQ0FBQztFQUVELE1BQU0sZ0JBQWdCLFdBRE8sQ0FBQyxVQUFVLEdBQUcsV0FBVyxDQUFDLENBQUMsUUFBTyxNQUFLLEtBQUssSUFDeEMsQ0FBb0I7RUFDckQsYUFBYTtHQUNYLGNBQWM7R0FDZCxrQkFBa0I7RUFDcEI7Q0FDRixHQUFHO0VBQUM7RUFBTTtFQUFVO0VBQWM7RUFBVTtFQUFPO0VBQWU7RUFBNkI7RUFBTTtFQUFXO0VBQXNCO0VBQTBCO0NBQXlCLENBQUM7Q0FHMUwseUJBQXlCO0VBQ3ZCLElBQUksQ0FBQyxRQUFRLFlBQVksQ0FBQyxjQUFjLG9CQUFvQixHQUMxRDtFQUVGLGFBQWEsVUFBVTtFQUN2Qix1QkFBdUIsVUFBVTtFQUNqQyxNQUFNLE1BQU0sY0FBYyxvQkFBb0I7RUFDOUMsTUFBTSwyQkFBMkIsY0FBYyxHQUFHO0VBR2xELHFCQUFxQjtHQUNuQixNQUFNLHdCQUF3QixnQkFBZ0I7R0FDOUMsTUFBTSx1QkFBdUIsT0FBTywwQkFBMEIsYUFBYSxzQkFBc0IsdUJBQXVCLFdBQVcsRUFBRSxJQUFJO0dBR3pJLElBQUkseUJBQXlCLEtBQUEsS0FBYSx5QkFBeUIsT0FDakU7R0FHRixJQURxQyxTQUFTLHNCQUFzQix3QkFDckMsR0FDN0I7R0FFRixJQUFJLG9CQUFvQjtHQUN4QixNQUFNLCtCQUErQjtJQUNuQyxJQUFJLHFCQUFxQixNQUN2QixvQkFBb0IsbUJBQW1CLG9CQUFvQjtJQUU3RCxPQUFPLGtCQUFrQixNQUFNO0dBQ2pDO0dBQ0EsSUFBSTtHQUNKLElBQUkseUJBQXlCLFFBQVEseUJBQXlCLE1BQzVELFlBQVksdUJBQXVCO1FBRW5DLFlBQVksV0FBVyxvQkFBb0I7R0FFN0MsWUFBWSxhQUFhLHVCQUF1QjtHQUNoRCxNQUFNLGlCQUFpQixTQUFTLHNCQUFzQixjQUFjLEdBQUcsQ0FBQztHQUl4RSxNQUFNLFlBQVksUUFBUSxRQUFRO0dBQ2xDLE1BQU0sdUJBQXVCLFdBQVcsU0FBUyxlQUFlLGVBQWUsU0FBUztHQUd4RixhQUFrQixXQUFXO0lBQzNCLE1BQU07SUFDTixlQUFlLGNBQWM7SUFDN0IsY0FBYztLQUlaLElBQUksQ0FBQyxRQUFRLFNBQ1gsT0FBTztLQUVULElBQUksZ0JBQ0YsT0FBTztLQUVULE1BQU0sdUJBQXVCLGNBQWMsR0FBRztLQUU5QyxPQUFPLEVBRGtCLHlCQUF5QixhQUFhLFNBQVMsc0JBQXNCLG9CQUFvQjtJQUVwSDtHQUNGLENBQUM7RUFDSCxDQUFDO0NBQ0gsR0FBRztFQUFDO0VBQVU7RUFBTTtFQUFzQjtFQUFvQjtFQUFpQjtFQUF3QjtFQUFTO0NBQU8sQ0FBQztDQUl4SCxNQUFNLHdCQUFBLGFBQThCLE9BQU8sSUFBSTtDQUcvQyx5QkFBeUI7RUFDdkIsSUFBSSxZQUFZLENBQUMsc0JBQXNCO0dBQ3JDLHNCQUFzQixVQUFVO0dBQ2hDO0VBQ0Y7RUFDQSxJQUFJLHNCQUFzQixTQUFTO0dBQ2pDLHNCQUFzQixRQUFRLFlBQVk7R0FDMUMsc0JBQXNCLFVBQVU7RUFDbEM7RUFDQSxNQUFNLE1BQU0sY0FBYyxvQkFBb0I7RUFDOUMsTUFBTSwyQkFBMkIsY0FBYyxHQUFHO0VBSWxELE1BQU0sc0JBQXNCLHVCQUF1QixXQUFXO0VBQzlELDRCQUE0Qix3QkFBd0I7RUFDcEQsU0FBUyxrQkFBa0IsU0FBUztHQUNsQyxJQUFJLENBQUMsUUFBUSxNQUNYLGFBQWEsVUFBVSxhQUFhLFFBQVEsYUFBYSx1QkFBdUIsT0FBTztHQUl6RixJQUFJLFFBQVEsV0FBVyxlQUFvQixRQUFRLGdCQUFnQixhQUFhLGdCQUFnQixhQUFhLENBQUMsS0FBSyxRQUFRLFdBQVcsbUJBQXdCLFFBQVEsWUFBWSxTQUFTLGNBQ3pMLHNCQUFzQixVQUFVO0dBRWxDLElBQUksUUFBUSxXQUFXLGlCQUNyQjtHQUVGLElBQUksUUFBUSxRQUNWLHNCQUFzQixVQUFVO1FBQzNCLElBQUksZUFBZSxRQUFRLFdBQVcsS0FBSyxzQkFBc0IsUUFBUSxXQUFXLEdBQ3pGLHNCQUFzQixVQUFVO1FBQzNCO0lBTUwsSUFBSSwyQkFBMkI7SUFDL0IsY0FBYyxvQkFBb0IsQ0FBQyxDQUFDLGNBQWMsS0FBSyxDQUFDLENBQUMsTUFBTSxFQUM3RCxJQUFJLGdCQUFnQjtLQUNsQiwyQkFBMkI7S0FDM0IsT0FBTztJQUNULEVBQ0YsQ0FBQztJQUNELElBQUksMEJBQ0Ysc0JBQXNCLFVBQVU7U0FFaEMsc0JBQXNCLFVBQVU7R0FFcEM7RUFDRjtFQUNBLE9BQU8sR0FBRyxjQUFjLGlCQUFpQjtFQUN6QyxTQUFTLGlCQUFpQixXQUFXO0dBQ25DLE1BQU0sdUJBQXVCLGVBQWU7R0FDNUMsSUFBSSwyQkFBMkIsT0FBTyx5QkFBeUIsYUFBYSxxQkFBcUIsU0FBUyxJQUFJO0dBRzlHLElBQUksNkJBQTZCLEtBQUEsS0FBYSw2QkFBNkIsT0FDekUsT0FBTztHQUVULElBQUksNkJBQTZCLE1BQy9CLDJCQUEyQjtHQUU3QixNQUFNLHlCQUF5QixjQUFjLGNBQWMsZUFBZTtHQUMxRSxNQUFNLHdCQUF3QiwwQkFBMEIsZUFBZSxZQUFZLHdCQUF3QixNQUFNLFNBQVMsMkJBQTJCO0dBQ3JKLElBQUksdUJBQXVCLHNCQUFzQix5QkFBeUIseUJBQXlCLDBCQUEwQjtHQUM3SCxJQUFJLENBQUMsc0JBQ0gsdUJBQXVCLDRCQUE0QixLQUFLO0dBRTFELElBQUksT0FBTyw2QkFBNkIsV0FDdEMsT0FBTztHQUVULE9BQU8sV0FBVyx3QkFBd0IsS0FBSyx3QkFBd0I7RUFDekU7RUFDQSxhQUFhO0dBQ1gsT0FBTyxJQUFJLGNBQWMsaUJBQWlCO0dBQzFDLE1BQU0sV0FBVyxjQUFjLEdBQUc7R0FDbEMsTUFBTSxpQkFBaUIsMEJBQTBCO0dBQ2pELE1BQU0sNEJBQTRCLFNBQVMsVUFBVSxRQUFRLEtBQUssZUFBZSxNQUFLLFlBQVcsWUFBWSxZQUFZLFNBQVMsU0FBUyxRQUFRLENBQUMsS0FBSyxRQUFRLGdCQUFnQixLQUFLLFNBQVMsU0FBUyxVQUFVLEdBQUcsS0FBSyxDQUFDLENBQUMsTUFBSyxTQUFRLFNBQVMsS0FBSyxTQUFTLFNBQVMsVUFBVSxRQUFRLENBQUM7R0FHNVIsTUFBTSx1QkFBdUIsZUFBZTtHQUM1QyxNQUFNLFlBQVksYUFBYTtHQUMvQixNQUFNLGdCQUFnQixpQkFBaUIsU0FBUztHQUNoRCxNQUFNLE1BQU0sRUFDVixXQUFXLE1BQ2I7R0FDQSxzQkFBc0IsVUFBVTtHQUNoQyxxQkFBcUI7SUFDbkIsSUFBSSxzQkFBc0IsWUFBWSxLQUNwQyxzQkFBc0IsVUFBVTtJQUlsQyxNQUFNLHdCQUF3Qix3QkFBd0IsYUFBYTtJQUVuRSxNQUFNLHlCQUVOLHVCQUF1QixXQUFXLE9BQU8seUJBQXlCO0lBQ2xFLElBQUksQ0FBQyxJQUFJLGFBQWEsd0JBQXdCLENBQUMsc0JBQXNCLFdBQVcsY0FBYyxxQkFBcUIsTUFJbkgsQ0FBQywwQkFBMEIsMEJBQTBCLFlBQVksYUFBYSxJQUFJLE9BQU8sNEJBQTRCLE9BQU87S0FDMUgsTUFBTSxlQUFlLEVBQ25CLGVBQWUsS0FDakI7S0FDQSxJQUFJLGNBQWMsWUFDaEIsYUFBYSxlQUFlO0tBRTlCLHNCQUFzQixNQUFNLFlBQVk7SUFDMUM7SUFHQSxzQkFBc0IsVUFBVTtHQUNsQyxDQUFDO0VBQ0g7Q0FDRixHQUFHO0VBQUM7RUFBVTtFQUFVO0VBQXNCO0VBQWdCO0VBQXdCO0VBQXdCO0VBQVE7RUFBTTtFQUFjO0VBQVc7Q0FBeUIsQ0FBQztDQUsvSyx5QkFBeUI7RUFDdkIsSUFBSSxDQUFDQyxVQUEwQixRQUFRLENBQUMsVUFDdEM7RUFFRixNQUFNLFdBQVcsY0FBYyxjQUFjLFFBQVEsQ0FBQztFQUN0RCxJQUFJLENBQUMsY0FBYyxRQUFRLEtBQUssQ0FBQyxrQkFBa0IsUUFBUSxHQUN6RDtFQUVGLElBQUksU0FBUyxVQUFVLFFBQVEsR0FDN0IsU0FBUyxLQUFLO0NBRWxCLEdBQUcsQ0FBQyxNQUFNLFFBQVEsQ0FBQztDQUluQix5QkFBeUI7RUFDdkIsSUFBSSxZQUFZLENBQUMsZUFDZjtFQUVGLGNBQWMscUJBQXFCO0dBQ2pDO0dBQ0E7R0FDQTtHQUNBLGNBQWMsTUFBTTtHQUNwQjtFQUNGLENBQUM7RUFDRCxhQUFhO0dBQ1gsY0FBYyxxQkFBcUIsSUFBSTtFQUN6QztDQUNGLEdBQUc7RUFBQztFQUFVO0VBQWU7RUFBTztFQUFNO0VBQU87RUFBaUI7Q0FBWSxDQUFDO0NBRy9FLHlCQUF5QjtFQUN2QixJQUFJLFlBQVksQ0FBQyxzQkFDZjtFQUVGLGVBQWUsb0JBQW9CO0VBQ25DLGFBQWE7R0FDWCxlQUFlLDBDQUEwQztFQUMzRDtDQUNGLEdBQUcsQ0FBQyxVQUFVLG9CQUFvQixDQUFDO0NBQ25DLE1BQU0scUJBQXFCLENBQUMsYUFBYSxRQUFRLENBQUMsOEJBQThCLFVBQVUsa0JBQWtCO0NBQzVHLE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUEsYUFBWSxVQUFVLEVBQ3hDLFVBQVU7RUFBQyxzQkFBbUMsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxZQUFZO0dBQzdELGFBQWE7R0FDYixLQUFLO0dBQ0wsVUFBUyxVQUFTO0lBQ2hCLElBQUksT0FBTztLQUNULE1BQU0sTUFBTSxtQkFBbUI7S0FFL0IsYUFBa0IsSUFBSSxJQUFJLFNBQVMsRUFBRTtJQUN2QyxPQUFPLElBQUksZUFBZSxZQUFZO0tBQ3BDLHNCQUFzQixVQUFVO0tBQ2hDLElBQUksZUFBZSxPQUFPLGNBQWMsVUFBVSxHQUVoRCxnQkFEcUMsWUFDMUIsQ0FBQyxFQUFFLE1BQU07VUFFcEIsV0FBVyw0QkFBNEIsY0FBYyxnQkFBZ0IsQ0FBQyxFQUFFLE1BQU07SUFFbEY7R0FDRjtFQUNGLENBQUM7RUFBRztFQUFVLHNCQUFtQyxlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLFlBQVk7R0FDaEUsYUFBYTtHQUNiLEtBQUs7R0FDTCxVQUFTLFVBQVM7SUFDaEIsSUFBSSxPQUVGLGFBQWtCLG1CQUFtQixDQUFDLENBQUMsRUFBRTtTQUNwQyxJQUFJLGVBQWUsWUFBWTtLQUNwQyxJQUFJLGlCQUNGLHNCQUFzQixVQUFVO0tBRWxDLElBQUksZUFBZSxPQUFPLGNBQWMsVUFBVSxHQUVoRCxvQkFEeUMsWUFDOUIsQ0FBQyxFQUFFLE1BQU07VUFFcEIsV0FBVyx3QkFBd0IsY0FBYyxlQUFlLENBQUMsRUFBRSxNQUFNO0lBRTdFO0dBQ0Y7RUFDRixDQUFDO0NBQUMsRUFDSixDQUFDO0FBQ0g7Ozs7OztBQ3ptQkEsU0FBZ0IsU0FBUyxPQUFPLFFBQVEsQ0FBQyxHQUFHO0NBQzFDLE1BQU0sRUFDSixVQUFVLE1BQ1YsT0FBTyxjQUFjLFNBQ3JCLFNBQVMsTUFDVCxjQUFjLE9BQ2QsY0FBYyxNQUNkLGlCQUFpQixHQUNqQixTQUFTQyxpQkFDUDtDQUNKLE1BQU0sVUFBVSxNQUFNLFFBQVE7Q0FDOUIsTUFBTSxpQkFBQSxhQUF1QixPQUFPLEtBQUEsQ0FBUztDQUM3QyxNQUFNLFFBQVEsa0JBQWtCO0NBQ2hDLE1BQU0sbUJBQW1CLFdBQVc7Q0FDcEMsTUFBTSxZQUFBLGFBQWtCLGNBQWM7RUFDcEMsU0FBUyxzQkFBc0IsVUFBVSxhQUFhLFFBQVEsYUFBYTtHQUN6RSxNQUFNLFVBQVUseUJBQXlCLFFBQVEsYUFBYSxNQUFNO0dBQ3BFLElBQUksWUFBWSxnQkFBZ0IsV0FBVyxpQkFBaUIsR0FDMUQsaUJBQWlCLE1BQU0sc0JBQXNCO0lBQzNDLE1BQU0sUUFBUSxNQUFNLE9BQU87R0FDN0IsQ0FBQztRQUVELE1BQU0sUUFBUSxVQUFVLE9BQU87RUFFbkM7RUFDQSxTQUFTLFlBQVksTUFBTSxlQUFlLHNCQUFzQjtHQUM5RCxNQUFNLFlBQVksUUFBUSxRQUFRO0dBQ2xDLE1BQU0sOEJBQThCLE1BQU0sT0FBTyxxQkFBcUIsTUFBTTtHQUM1RSxJQUFJLFFBQVEsNkJBRVYsT0FBTztHQUVULElBQUksQ0FBQyxNQUVILE9BQU87R0FFVCxJQUFJLENBQUMsUUFFSCxPQUFPO0dBRVQsSUFBSSxjQUFjLE9BQU8sZ0JBQWdCLGFBQWEsWUFBWSxJQUFJLGNBRXBFLE9BQU8sQ0FBQyxxQkFBcUIsVUFBVSxJQUFJO0dBSTdDLE9BQU87RUFDVDtFQUNBLE9BQU87R0FDTCxjQUFjLE9BQU87SUFLbkIsZUFBZSxVQUFVLHVCQUF1QixNQUFNLGFBQWEsSUFBSSxLQUFLLHNCQUFzQixNQUFNLFdBQVcsSUFBSSxZQUFZLE1BQU07R0FDM0k7R0FDQSxZQUFZLE9BQU87SUFDakIsTUFBTSxjQUFjLGVBQWU7SUFDbkMsTUFBTSxjQUFjLE1BQU07SUFDMUIsTUFBTSxPQUFPLE1BQU0sT0FBTyxNQUFNO0lBSWhDLElBQUksTUFBTSxXQUFXLEtBQUssZ0JBQWdCLFdBQVcsdUJBQXVCLGFBQWEsSUFBSSxLQUFLLGFBQ2hHO0lBRUYsTUFBTSxXQUFXLFlBQVksTUFBTSxNQUFNLGdCQUFlLGtCQUFpQixrQkFBa0IsV0FBVyxrQkFBa0IsV0FBVztJQU1uSSxNQUFNLFNBQVMsVUFBVSxXQUFXO0lBQ3BDLE1BQU0sYUFBYSxrQkFBa0IsTUFBTTtJQUMzQyxJQUFJLGNBQWMsZ0JBQWdCLFdBQVc7S0FFM0Msc0JBQXNCLFVBQVUsYUFBYSxhQUFhLFNBQVMsTUFBTSxlQUFlLFdBQVc7S0FDbkc7SUFDRjtJQUlBLE1BQU0scUJBQXFCLE1BQU07SUFJakMsTUFBTSxjQUFjO0tBQ2xCLHNCQUFzQixVQUFVLGFBQWEsb0JBQW9CLFdBQVc7SUFDOUUsQ0FBQztHQUNIO0dBQ0EsUUFBUSxPQUFPO0lBQ2IsSUFBSSxnQkFBZ0Isa0JBQ2xCO0lBRUYsTUFBTSxjQUFjLGVBQWU7SUFDbkMsSUFBSSxnQkFBZ0IsZUFBZSxhQUFhO0tBQzlDLGVBQWUsVUFBVSxLQUFBO0tBQ3pCO0lBQ0Y7SUFDQSxJQUFJLHVCQUF1QixhQUFhLElBQUksS0FBSyxhQUMvQztJQUlGLHNCQURpQixZQURKLE1BQU0sT0FBTyxNQUNNLEdBQUcsTUFBTSxnQkFBZSxrQkFBaUIsa0JBQWtCLFdBQVcsa0JBQWtCLGVBQWUsa0JBQWtCLGFBQWEsa0JBQWtCLE9BQzNKLEdBQUcsTUFBTSxhQUFhLE1BQU0sZUFBZSxXQUFXO0dBQ3JGO0dBQ0EsWUFBWTtJQUNWLGVBQWUsVUFBVSxLQUFBO0dBQzNCO0VBQ0Y7Q0FDRixHQUFHO0VBQUM7RUFBUztFQUFhO0VBQWE7RUFBUTtFQUFPO0VBQWE7RUFBUTtFQUFPO0VBQWtCO0NBQWMsQ0FBQztDQUNuSCxPQUFBLGFBQWEsY0FBYyxVQUFVLEVBQ25DLFVBQ0YsSUFBSSxjQUFjLENBQUMsU0FBUyxTQUFTLENBQUM7QUFDeEM7Ozs7O0FDMUhBLElBQWEsbUJBQWdDLDJCQUFNLFdBQVcsU0FBUyxpQkFBaUIsT0FBTyxLQUFLO0NBQ2xHLE1BQU0sRUFDSixRQUNBLEdBQUcsZUFDRDtDQUNKLElBQUk7Q0FDSixJQUFJLFFBQVE7RUFDVixNQUFNLE9BQU8sT0FBTyxzQkFBc0I7RUFDMUMsV0FBVyxpREFBaUQsS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNLEtBQUssS0FBSyxPQUFPLEtBQUssS0FBSyxNQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxJQUFJO0NBQ2xOO0NBQ0EsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxPQUFPO0VBQ3pCO0VBQ0wsTUFBTTtFQUlOLHNCQUFzQjtFQUN0QixHQUFHO0VBQ0gsT0FBTztHQUNMLFVBQVU7R0FDVixPQUFPO0dBQ1AsWUFBWTtHQUNaLGtCQUFrQjtHQUNsQjtFQUNGO0NBQ0YsQ0FBQztBQUNILENBQUM7QUFDMEMsaUJBQWlCLGNBQWM7Ozs7Ozs7OztBQ3ZCMUUsU0FBZ0Isd0JBQXdCLFNBQVM7Q0FDL0MsTUFBTSw4QkFBQSxhQUFvQyxPQUFPLEVBQUU7Q0FDbkQsTUFBTSxvQkFBQSxhQUEwQixhQUFZLFVBQVM7RUFDbkQsSUFBSSxNQUFNLGtCQUNSO0VBRUYsNEJBQTRCLFVBQVUsTUFBTTtFQUM1QyxRQUFRLE9BQU8sTUFBTSxXQUFXO0NBQ2xDLEdBQUcsQ0FBQyxPQUFPLENBQUM7Q0FlWixPQUFPO0VBQ0wsU0FBQSxhQWZ3QixhQUFZLFVBQVM7R0FFN0MsSUFBSSxNQUFNLFdBQVcsR0FBRztJQUN0QixRQUFRLE9BQU8sVUFBVTtJQUN6QjtHQUNGO0dBQ0EsSUFBSSxpQkFBaUIsT0FFbkIsUUFBUSxPQUFPLE1BQU0sV0FBVztRQUVoQyxRQUFRLE9BQU8sNEJBQTRCLE9BQU87R0FFcEQsNEJBQTRCLFVBQVU7RUFDeEMsR0FBRyxDQUFDLE9BQU8sQ0FFVTtFQUNuQixlQUFlO0NBQ2pCO0FBQ0Y7O0FDOUJBLFNBQWdCLDBCQUEwQixNQUFNLGVBQWU7Q0FXN0QsTUFBTSxFQUNKLFNBQ0Esa0JBQ0Usd0JBYnVCLG1CQUFtQixHQUFHLG9CQUFvQjtFQUVuRSxJQUFJLEVBRFcsT0FBTyxTQUFTLGFBQWEsS0FBSyxJQUFJLE9BRW5ELGNBQWMsb0JBSWRDLE1BQWtCLFVBQVUsR0FBRztDQUVuQyxDQUk0QixDQUFrQjtDQUM5QyxPQUFBLGFBQWEsZUFBZTtFQUMxQjtFQUNBO0NBQ0YsSUFBSSxDQUFDLFNBQVMsYUFBYSxDQUFDO0FBQzlCOzs7Ozs7QUFPQSxTQUFnQix1QkFBdUIsTUFBTTtDQUMzQyxNQUFNLENBQUMsWUFBWSxpQkFBQSxhQUF1QixTQUFTLElBQUk7Q0FDdkQsTUFBTSxlQUFlLDBCQUEwQixNQUFNLGFBQWE7Q0FDbEUsZ0JBQWdCLE9BQU0saUJBQWdCO0VBQ3BDLElBQUksZ0JBQWdCLENBQUMsTUFDbkIsY0FBYyxJQUFJO0NBRXRCLENBQUM7Q0FDRCxPQUFBLGFBQWEsZUFBZTtFQUMxQjtFQUNBO0NBQ0YsSUFBSSxDQUFDLFlBQVksWUFBWSxDQUFDO0FBQ2hDIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsN119