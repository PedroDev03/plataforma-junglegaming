import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=e9f94b2e";
// node_modules/react-hook-form/dist/index.esm.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var isCheckBoxInput = (element) => element.type === "checkbox";
var isFileInput = (element) => element.type === "file";
var isDateObject = (value) => value instanceof Date;
var isNullOrUndefined = (value) => value == null;
var isObjectType = (value) => typeof value === "object";
var isObject = (value) => !isNullOrUndefined(value) && !Array.isArray(value) && isObjectType(value) && !isDateObject(value);
var getEventValue = (event) => isObject(event) && event.target ? isCheckBoxInput(event.target) ? event.target.checked : isFileInput(event.target) ? event.target.files : event.target.value : event;
var FIELD_PATH_RE = /[.[\]'"]/;
var stringToPath = (input) => input.split(FIELD_PATH_RE).filter(Boolean);
function getNullAncestorValue(control, name) {
	const segments = stringToPath(name);
	let formValues = control._formValues;
	let defaultValues = control._defaultValues;
	for (let i = 0; i < segments.length - 1; i++) {
		const key = segments[i];
		formValues = formValues == null ? formValues : formValues[key];
		defaultValues = defaultValues == null ? defaultValues : defaultValues[key];
		if (formValues === null || defaultValues === null) return null;
	}
}
var isNameInFieldArray = (names, name) => name.split(".").some((part, index, arr) => !isNaN(Number(part)) && names.has(arr.slice(0, index).join(".")));
var isWeb = typeof window !== "undefined" && typeof window.HTMLElement !== "undefined" && typeof document !== "undefined";
function cloneObject(data) {
	if (data === null || typeof data !== "object") return data;
	if (data instanceof Date) return new Date(data);
	const isBlobInstance = typeof Blob !== "undefined" && data instanceof Blob;
	const isFileListInstance = typeof FileList !== "undefined" && data instanceof FileList;
	if (isWeb && (isBlobInstance || isFileListInstance)) return data;
	const isArray = Array.isArray(data);
	const prototype = Object.getPrototypeOf(data);
	if (!isArray && prototype && data.constructor !== Object) return data;
	const copy = isArray ? new Array(data.length) : Object.create(prototype);
	for (const key in data) if (Object.prototype.hasOwnProperty.call(data, key)) copy[key] = cloneObject(data[key]);
	return copy;
}
var EVENTS = {
	BLUR: "blur",
	FOCUS_OUT: "focusout",
	CHANGE: "change",
	SUBMIT: "submit",
	TRIGGER: "trigger",
	VALID: "valid"
};
var VALIDATION_MODE = {
	onBlur: "onBlur",
	onChange: "onChange",
	onSubmit: "onSubmit",
	onTouched: "onTouched",
	all: "all"
};
var INPUT_VALIDATION_RULES = {
	max: "max",
	min: "min",
	maxLength: "maxLength",
	minLength: "minLength",
	pattern: "pattern",
	required: "required",
	validate: "validate"
};
var REGISTER_VALIDATION_RULES = [
	INPUT_VALIDATION_RULES.required,
	INPUT_VALIDATION_RULES.min,
	INPUT_VALIDATION_RULES.max,
	INPUT_VALIDATION_RULES.minLength,
	INPUT_VALIDATION_RULES.maxLength,
	INPUT_VALIDATION_RULES.pattern,
	INPUT_VALIDATION_RULES.validate
];
var FORM_ERROR_TYPE = "form";
var ROOT_ERROR_TYPE = "root";
var PROTOTYPE_KEYWORDS = [
	"__proto__",
	"constructor",
	"prototype"
];
var IS_KEY_RE = /^\w*$/;
var isKey = (value) => IS_KEY_RE.test(value);
var isUndefined = (val) => val === void 0;
var get = (object, path, defaultValue) => {
	if (!path || !isObject(object)) return defaultValue;
	const paths = isKey(path) ? [path] : stringToPath(path);
	if (paths.some((key) => PROTOTYPE_KEYWORDS.includes(key))) return defaultValue;
	const result = paths.reduce((result, key) => {
		return isNullOrUndefined(result) ? void 0 : result[key];
	}, object);
	return isUndefined(result) || result === object ? isUndefined(object[path]) ? defaultValue : object[path] : result;
};
var isBoolean = (value) => typeof value === "boolean";
var isFunction = (value) => typeof value === "function";
var set = (object, path, value) => {
	let index = -1;
	const tempPath = isKey(path) ? [path] : stringToPath(path);
	const length = tempPath.length;
	const lastIndex = length - 1;
	while (++index < length) {
		const key = tempPath[index];
		let newValue = value;
		if (index !== lastIndex) {
			const objValue = object[key];
			newValue = isObject(objValue) || Array.isArray(objValue) ? objValue : !isNaN(+tempPath[index + 1]) ? [] : {};
		}
		if (PROTOTYPE_KEYWORDS.includes(key)) return;
		object[key] = newValue;
		object = object[key];
	}
};
/**
* Separate context for `control` to prevent unnecessary rerenders.
* Internal hooks that only need control use this instead of full form context.
*/
var HookFormControlContext = import_react.createContext(null);
HookFormControlContext.displayName = "HookFormControlContext";
/**
* @internal Internal hook to access only control from context.
*/
var useFormControlContext = () => import_react.useContext(HookFormControlContext);
var getProxyFormState = (formState, control, localProxyFormState, isRoot = true) => {
	const result = {};
	for (const key in formState) Object.defineProperty(result, key, { get: () => {
		const _key = key;
		if (control._proxyFormState[_key] !== VALIDATION_MODE.all) control._proxyFormState[_key] = !isRoot || VALIDATION_MODE.all;
		localProxyFormState && (localProxyFormState[_key] = true);
		return formState[_key];
	} });
	return result;
};
var useIsomorphicLayoutEffect = isWeb ? import_react.useLayoutEffect : import_react.useEffect;
var isPlainObject = (tempObject) => {
	const prototypeCopy = tempObject.constructor && tempObject.constructor.prototype;
	return isObject(prototypeCopy) && prototypeCopy.hasOwnProperty("isPrototypeOf");
};
var isPrimitive = (value) => isNullOrUndefined(value) || !isObjectType(value);
var isEmptyObjectWithCustomPrototype = (object, keys) => keys.length === 0 && !Array.isArray(object) && !isPlainObject(object);
function deepEqual(object1, object2, isErrorObject = false, visited = /* @__PURE__ */ new WeakMap()) {
	if (object1 === object2) return true;
	if (isPrimitive(object1) || isPrimitive(object2)) return Object.is(object1, object2);
	if (isDateObject(object1) && isDateObject(object2)) return Object.is(object1.getTime(), object2.getTime());
	const keys1 = Object.keys(object1);
	const keys2 = Object.keys(object2);
	if (keys1.length !== keys2.length) return false;
	if (isEmptyObjectWithCustomPrototype(object1, keys1) || isEmptyObjectWithCustomPrototype(object2, keys2)) return Object.is(object1, object2);
	if (!keys1.length && Array.isArray(object1) !== Array.isArray(object2)) return false;
	const visitedPairs = visited.get(object1);
	if (visitedPairs && visitedPairs.has(object2)) return true;
	if (visitedPairs) visitedPairs.add(object2);
	else {
		const ws = /* @__PURE__ */ new WeakSet();
		ws.add(object2);
		visited.set(object1, ws);
	}
	for (const key of keys1) {
		const val1 = object1[key];
		if (!(key in object2)) return false;
		if (!isErrorObject || key !== "ref") {
			const val2 = object2[key];
			if (isDateObject(val1) && isDateObject(val2) || (isObject(val1) || Array.isArray(val1)) && (isObject(val2) || Array.isArray(val2)) ? !deepEqual(val1, val2, isErrorObject, visited) : !Object.is(val1, val2)) return false;
		}
	}
	return true;
}
function useResyncOnReconnect(getInitialValue) {
	const _connected = import_react.useRef(false);
	const _initialized = import_react.useRef(false);
	const _prevValue = import_react.useRef(void 0);
	const _renderCount = import_react.useRef(0);
	_renderCount.current++;
	if (!_initialized.current && getInitialValue) {
		_initialized.current = true;
		_prevValue.current = cloneObject(getInitialValue());
	}
	return {
		resyncIfNeeded: import_react.useCallback((enabled, getCurrentValue, setValue) => {
			if (enabled && (_connected.current || _initialized.current && _renderCount.current > 1)) {
				const currentValue = getCurrentValue();
				if (!deepEqual(_prevValue.current, currentValue)) setValue(currentValue);
			}
			_connected.current = true;
		}, []),
		snapshot: import_react.useCallback((enabled, getCurrentValue) => {
			if (enabled) _prevValue.current = cloneObject(getCurrentValue());
		}, [])
	};
}
/**
* Subscribes to form state with re-renders isolated to this hook.
* Optionally scope to specific field names to minimize re-render surface.
*
* @see [API](https://react-hook-form.com/docs/useformstate)
*
* @example
* ```tsx
* const { errors, isDirty } = useFormState({ control, name: "email" });
* ```
*/
function useFormState(props) {
	const formControl = useFormControlContext();
	const { control = formControl, disabled, name, exact } = props || {};
	const getCurrentFormState = () => ({
		...control._formState,
		defaultValues: control._defaultValues
	});
	const [formState, updateFormState] = import_react.useState(getCurrentFormState);
	const _localProxyFormState = import_react.useRef({
		isDirty: false,
		isLoading: false,
		dirtyFields: false,
		touchedFields: false,
		validatingFields: false,
		isValidating: false,
		isValid: false,
		errors: false
	});
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect(getCurrentFormState);
	useIsomorphicLayoutEffect(() => {
		resyncIfNeeded(!disabled, getCurrentFormState, updateFormState);
		const unsubscribe = control._subscribe({
			name,
			formState: _localProxyFormState.current,
			exact,
			callback: (formState) => {
				!disabled && updateFormState({
					...control._formState,
					...formState,
					defaultValues: control._defaultValues
				});
			}
		});
		return () => {
			unsubscribe();
			snapshot(!disabled, getCurrentFormState);
		};
	}, [
		control,
		name,
		disabled,
		exact,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => {
		_localProxyFormState.current.isValid && control._setValid(true);
	}, [control]);
	return import_react.useMemo(() => getProxyFormState(formState, control, _localProxyFormState.current, false), [formState, control]);
}
var isString = (value) => typeof value === "string";
var generateWatchOutput = (names, _names, formValues, isGlobal, defaultValue) => {
	if (isString(names)) {
		isGlobal && _names.watch.add(names);
		return get(formValues, names, defaultValue);
	}
	if (Array.isArray(names)) return names.map((fieldName) => (isGlobal && _names.watch.add(fieldName), get(formValues, fieldName, get(defaultValue, fieldName))));
	isGlobal && (_names.watchAll = true);
	return formValues;
};
/**
* Subscribes to field value changes and isolates re-renders to the hook level.
*
* @see [API](https://react-hook-form.com/docs/usewatch)
*
* @example
* ```tsx
* const email = useWatch({ control, name: "email" });
* const all   = useWatch({ control });
* const adult = useWatch({ control, name: "age", compute: (v) => v >= 18 });
* ```
*/
function useWatch(props) {
	const formControl = useFormControlContext();
	const { control = formControl, name, defaultValue, disabled, exact, compute } = props || {};
	const _defaultValue = import_react.useRef(defaultValue);
	const _compute = import_react.useRef(compute);
	const _prevControl = import_react.useRef(control);
	const _prevName = import_react.useRef(name);
	_compute.current = compute;
	const getInitialOutput = () => {
		const defaultValue = control._getWatch(name, _defaultValue.current);
		return _compute.current ? _compute.current(defaultValue) : defaultValue;
	};
	const [value, updateValue] = import_react.useState(getInitialOutput);
	const _computeFormValues = import_react.useRef(value);
	const getCurrentOutput = import_react.useCallback((values) => {
		const formValues = generateWatchOutput(name, control._names, values || control._formValues, false, _defaultValue.current);
		return _compute.current ? _compute.current(formValues) : formValues;
	}, [
		control._formValues,
		control._names,
		name
	]);
	const refreshValue = import_react.useCallback((values) => {
		if (!disabled) {
			const formValues = generateWatchOutput(name, control._names, values || control._formValues, false, _defaultValue.current);
			if (_compute.current) {
				const computedFormValues = _compute.current(formValues);
				if (!deepEqual(computedFormValues, _computeFormValues.current)) {
					updateValue(computedFormValues);
					_computeFormValues.current = computedFormValues;
				}
			} else updateValue(formValues);
		}
	}, [
		control._formValues,
		control._names,
		disabled,
		name
	]);
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect(getInitialOutput);
	const _refreshValue = import_react.useRef(refreshValue);
	_refreshValue.current = refreshValue;
	const _getCurrentOutput = import_react.useRef(getCurrentOutput);
	_getCurrentOutput.current = getCurrentOutput;
	useIsomorphicLayoutEffect(() => {
		if (_prevControl.current !== control || !deepEqual(_prevName.current, name)) {
			_prevControl.current = control;
			_prevName.current = name;
			_refreshValue.current();
		} else resyncIfNeeded(!disabled, () => _getCurrentOutput.current(), (currentValue) => {
			const nextValue = cloneObject(currentValue);
			updateValue(nextValue);
			_computeFormValues.current = nextValue;
		});
		const unsubscribe = control._subscribe({
			name,
			formState: { values: true },
			exact,
			callback: (formState) => {
				_refreshValue.current(formState.values);
			}
		});
		return () => {
			unsubscribe();
			snapshot(!disabled, () => _getCurrentOutput.current());
		};
	}, [
		control,
		exact,
		name,
		disabled,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => control._removeUnmounted());
	const controlChanged = _prevControl.current !== control;
	const prevName = _prevName.current;
	return import_react.useMemo(() => {
		if (disabled) return false;
		const nameChanged = !controlChanged && !deepEqual(prevName, name);
		return controlChanged || nameChanged;
	}, [
		disabled,
		controlChanged,
		name,
		prevName
	]) ? getCurrentOutput() : value;
}
/**
* Hook for controlled inputs. Returns `field`, `fieldState`, and `formState`.
* Re-renders are isolated to the hook level.
*
* @see [API](https://react-hook-form.com/docs/usecontroller)
*
* @example
* ```tsx
* const { field, fieldState } = useController({ control, name: "email" });
* return <input {...field} />;
* ```
*/
function useController(props) {
	const formControl = useFormControlContext();
	const { name, disabled, control = formControl, shouldUnregister, defaultValue, exact = true } = props;
	const isArrayField = isNameInFieldArray(control._names.array, name);
	const value = useWatch({
		control,
		name,
		defaultValue: import_react.useMemo(() => {
			const resolved = get(control._formValues, name, get(control._defaultValues, name, defaultValue));
			return isUndefined(resolved) ? getNullAncestorValue(control, name) : resolved;
		}, [
			control,
			name,
			defaultValue
		]),
		exact
	});
	const formState = useFormState({
		control,
		name,
		exact
	});
	const _props = import_react.useRef(props);
	const _proxyRef = import_react.useRef(null);
	const _registerProps = import_react.useRef(control.register(name, {
		...props.rules,
		value,
		...isBoolean(props.disabled) ? { disabled: props.disabled } : {}
	}));
	_props.current = props;
	const fieldState = import_react.useMemo(() => Object.defineProperties({}, {
		invalid: {
			enumerable: true,
			get: () => !!get(formState.errors, name)
		},
		isDirty: {
			enumerable: true,
			get: () => !!get(formState.dirtyFields, name)
		},
		isTouched: {
			enumerable: true,
			get: () => !!get(formState.touchedFields, name)
		},
		isValidating: {
			enumerable: true,
			get: () => !!get(formState.validatingFields, name)
		},
		error: {
			enumerable: true,
			get: () => get(formState.errors, name)
		}
	}), [formState, name]);
	const onChange = import_react.useCallback((event) => {
		const value = getEventValue(event);
		if (!get(control._fields, name)) _registerProps.current = control.register(name, {
			..._props.current.rules,
			value
		});
		return _registerProps.current.onChange({
			target: {
				value: getEventValue(event),
				name
			},
			type: EVENTS.CHANGE
		});
	}, [name, control]);
	const onBlur = import_react.useCallback(() => {
		const value = get(control._formValues, name);
		if (!get(control._fields, name)) _registerProps.current = control.register(name, {
			..._props.current.rules,
			value
		});
		return _registerProps.current.onBlur({
			target: {
				value,
				name
			},
			type: EVENTS.BLUR
		});
	}, [name, control]);
	const ref = import_react.useCallback((elm) => {
		if (elm) _proxyRef.current = {
			focus: () => isFunction(elm.focus) && elm.focus(),
			select: () => isFunction(elm.select) && elm.select(),
			setCustomValidity: (message) => isFunction(elm.setCustomValidity) && elm.setCustomValidity(message),
			reportValidity: () => isFunction(elm.reportValidity) && elm.reportValidity()
		};
		const field = get(control._fields, name);
		if (field && field._f && elm) {
			field._f.ref = _proxyRef.current;
			field._f._c = true;
		}
	}, [control._fields, name]);
	const field = import_react.useMemo(() => ({
		name,
		value,
		...isBoolean(disabled) || formState.disabled ? { disabled: formState.disabled || disabled } : {},
		onChange,
		onBlur,
		ref
	}), [
		name,
		disabled,
		formState.disabled,
		onChange,
		onBlur,
		ref,
		value
	]);
	import_react.useEffect(() => {
		const _shouldUnregisterField = control._options.shouldUnregister || shouldUnregister;
		_registerProps.current = control.register(name, {
			..._props.current.rules,
			...isBoolean(_props.current.disabled) ? { disabled: _props.current.disabled } : {}
		});
		const updateMounted = (name, value) => {
			const field = get(control._fields, name);
			if (field && field._f) {
				field._f.mount = value;
				field._f._c = value;
			}
		};
		updateMounted(name, true);
		if (_shouldUnregisterField) {
			const value = cloneObject(get(shouldUnregister ? control._defaultValues : control._options.values || control._defaultValues, name, get(control._options.defaultValues, name, _props.current.defaultValue)));
			set(control._defaultValues, name, value);
			if (isUndefined(get(control._formValues, name))) set(control._formValues, name, value);
		}
		!isArrayField && control.register(name, {
			..._props.current.rules,
			...isBoolean(_props.current.disabled) ? { disabled: _props.current.disabled } : {}
		});
		if (_proxyRef.current) {
			const field = get(control._fields, name);
			if (field && field._f) field._f.ref = _proxyRef.current;
		}
		return () => {
			(isArrayField ? _shouldUnregisterField && !control._state.action : _shouldUnregisterField) ? control.unregister(name) : updateMounted(name, false);
		};
	}, [
		name,
		control,
		isArrayField,
		shouldUnregister
	]);
	import_react.useEffect(() => {
		control._setDisabledField({
			disabled,
			name
		});
	}, [
		disabled,
		name,
		control
	]);
	return import_react.useMemo(() => ({
		field,
		formState,
		fieldState
	}), [
		field,
		formState,
		fieldState
	]);
}
/**
* Component wrapper around `useController` for controlled inputs.
*
* @see [API](https://react-hook-form.com/docs/usecontroller/controller)
*
* @example
* ```tsx
* <Controller
*   control={control}
*   name="test"
*   render={({ field, fieldState, formState }) => <input {...field} />}
* />
* ```
*/
var Controller = (props) => props.render(useController(props));
/**
* Displays the validation error for a single field.
* Reads from `control` when provided, otherwise from the nearest `FormProvider`.
*
* @see [API](https://react-hook-form.com/docs/useformstate/errormessage)
*
* @example
* ```tsx
* <ErrorMessage control={control} name="email" as="p" />
* <ErrorMessage name="email" as="span" />
* <ErrorMessage control={control} name="email"
*   render={({ message }) => <Alert>{message}</Alert>} />
* ```
*/
var ErrorMessage = ({ as, control, name, render }) => {
	const { errors } = useFormState({
		control,
		name
	});
	const error = get(errors, name);
	if (!error) return null;
	const message = error.message || "";
	if (render) return render({
		message,
		messages: error.types
	});
	return import_react.createElement(as || import_react.Fragment, null, message);
};
var generateId = () => typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
	const r = Math.random() * 16 | 0;
	return (c === "x" ? r : r & 3 | 8).toString(16);
});
var getFocusFieldName = (name, index, options = {}) => options.shouldFocus || isUndefined(options.shouldFocus) ? options.focusName || `${name}.${isUndefined(options.focusIndex) ? index : options.focusIndex}.` : "";
var getValidationModes = (mode) => ({
	isOnSubmit: !mode || mode === VALIDATION_MODE.onSubmit,
	isOnBlur: mode === VALIDATION_MODE.onBlur,
	isOnChange: mode === VALIDATION_MODE.onChange,
	isOnAll: mode === VALIDATION_MODE.all,
	isOnTouch: mode === VALIDATION_MODE.onTouched
});
var isWatched = (name, _names, isBlurEvent) => {
	if (isBlurEvent) return false;
	if (_names.watchAll || _names.watch.has(name)) return true;
	for (const watchName of _names.watch) if (name.startsWith(watchName) && name.charAt(watchName.length) === ".") return true;
	return false;
};
var iterateFieldsByAction = (fields, action, fieldsNames) => {
	for (const key of fieldsNames || Object.keys(fields)) {
		if (key === "_f") continue;
		const field = fieldsNames ? get(fields, key) : fields[key];
		if (field) {
			const { _f } = field;
			if (_f) {
				if (_f.refs && _f.refs[0] && action(_f.refs[0], _f.name)) return true;
				else if (_f.ref && action(_f.ref, _f.name)) return true;
				else if (iterateFieldsByAction(field, action)) return true;
			} else if (isObject(field) || Array.isArray(field)) {
				if (iterateFieldsByAction(field, action)) return true;
			}
		}
	}
};
var updateFieldArrayRootError = (errors, error, name) => {
	const existingErrors = get(errors, name);
	const fieldArrayErrors = Array.isArray(existingErrors) ? existingErrors : [];
	set(fieldArrayErrors, ROOT_ERROR_TYPE, error[name]);
	set(errors, name, fieldArrayErrors);
	return errors;
};
var isEmptyObject = (value) => isObject(value) && !Object.keys(value).length;
var isHTMLElement = (value) => {
	if (!isWeb) return false;
	const owner = value ? value.ownerDocument : 0;
	return value instanceof (owner && owner.defaultView ? owner.defaultView.HTMLElement : HTMLElement);
};
var isRadioInput = (element) => element.type === "radio";
var isRegex = (value) => value instanceof RegExp;
var appendErrors = (name, validateAllFieldCriteria, errors, type, message) => validateAllFieldCriteria ? {
	...errors[name],
	types: {
		...errors[name] && errors[name].types ? errors[name].types : {},
		[type]: message || true
	}
} : {};
var defaultResult = {
	value: false,
	isValid: false
};
var validResult = {
	value: true,
	isValid: true
};
var getCheckboxValue = (options) => {
	if (!Array.isArray(options)) return defaultResult;
	if (options.length > 1) {
		const values = options.filter((option) => option && option.checked && !option.disabled).map((option) => option.value);
		return {
			value: values,
			isValid: !!values.length
		};
	}
	const option = options[0];
	if (!option || !option.checked || option.disabled) return defaultResult;
	if (!option.attributes || !("value" in option.attributes)) return validResult;
	return isUndefined(option.value) || option.value === "" ? validResult : {
		value: option.value,
		isValid: true
	};
};
var defaultReturn = {
	isValid: false,
	value: null
};
var getRadioValue = (options) => Array.isArray(options) ? options.reduce((previous, option) => option && option.checked && !option.disabled ? {
	isValid: true,
	value: option.value
} : previous, defaultReturn) : defaultReturn;
function getValidateError(result, ref, type = "validate") {
	if (isString(result) || Array.isArray(result) && result.every(isString) || isBoolean(result) && !result) return {
		type,
		message: isString(result) ? result : "",
		ref
	};
}
var getValueAndMessage = (validationData) => isObject(validationData) && !isRegex(validationData) ? validationData : {
	value: validationData,
	message: ""
};
var validateField = async (field, disabledFieldNames, formValues, validateAllFieldCriteria, shouldUseNativeValidation, isFieldArray) => {
	const { ref, refs, required, maxLength, minLength, min, max, pattern, validate, name, valueAsNumber, mount, _c } = field._f;
	const inputValue = get(formValues, name);
	if (!mount || disabledFieldNames.has(name)) return {};
	const inputRef = refs ? refs[0] : ref;
	const setCustomValidity = (message) => {
		if (shouldUseNativeValidation && inputRef.reportValidity) {
			const validityMessage = isBoolean(message) ? "" : message || "";
			if (refs) refs.forEach((ref) => isFunction(ref.setCustomValidity) && ref.setCustomValidity(validityMessage));
			else inputRef.setCustomValidity(validityMessage);
			inputRef.reportValidity();
		}
	};
	const error = {};
	const isRadio = isRadioInput(ref);
	const isCheckBox = isCheckBoxInput(ref);
	const isRadioOrCheckbox = isRadio || isCheckBox;
	const isEmpty = (valueAsNumber || isFileInput(ref)) && isUndefined(ref.value) && isUndefined(inputValue) || isHTMLElement(ref) && ref.value === "" && !_c || inputValue === "" || Array.isArray(inputValue) && !inputValue.length;
	const appendErrorsCurry = appendErrors.bind(null, name, validateAllFieldCriteria, error);
	const getMinMaxMessage = (exceedMax, maxLengthMessage, minLengthMessage, maxType = INPUT_VALIDATION_RULES.maxLength, minType = INPUT_VALIDATION_RULES.minLength) => {
		const message = exceedMax ? maxLengthMessage : minLengthMessage;
		error[name] = {
			type: exceedMax ? maxType : minType,
			message,
			ref,
			...appendErrorsCurry(exceedMax ? maxType : minType, message)
		};
	};
	if (isFieldArray ? !Array.isArray(inputValue) || !inputValue.length : required && (!isRadioOrCheckbox && (isEmpty || isNullOrUndefined(inputValue)) || isBoolean(inputValue) && !inputValue || isCheckBox && !getCheckboxValue(refs).isValid || isRadio && !getRadioValue(refs).isValid)) {
		const { value, message } = isString(required) ? {
			value: !!required,
			message: required
		} : getValueAndMessage(required);
		if (value) {
			error[name] = {
				type: INPUT_VALIDATION_RULES.required,
				message,
				ref: inputRef,
				...appendErrorsCurry(INPUT_VALIDATION_RULES.required, message)
			};
			if (!validateAllFieldCriteria) {
				setCustomValidity(message);
				return error;
			}
		}
	}
	if (!isEmpty && (!isNullOrUndefined(min) || !isNullOrUndefined(max))) {
		let exceedMax;
		let exceedMin;
		const maxOutput = getValueAndMessage(max);
		const minOutput = getValueAndMessage(min);
		if (!isNullOrUndefined(inputValue) && !isDateObject(inputValue) && !isNaN(inputValue)) {
			const valueNumber = ref.valueAsNumber || (inputValue ? +inputValue : inputValue);
			if (!isNullOrUndefined(maxOutput.value)) exceedMax = valueNumber > maxOutput.value;
			if (!isNullOrUndefined(minOutput.value)) exceedMin = valueNumber < minOutput.value;
		} else {
			const valueDate = ref.valueAsDate || new Date(inputValue);
			const convertTimeToDate = (time) => /* @__PURE__ */ new Date((/* @__PURE__ */ new Date()).toDateString() + " " + time);
			const isTime = ref.type == "time";
			const isWeek = ref.type == "week";
			if (isString(maxOutput.value) && inputValue) exceedMax = isTime ? convertTimeToDate(inputValue) > convertTimeToDate(maxOutput.value) : isWeek ? inputValue > maxOutput.value : valueDate > new Date(maxOutput.value);
			if (isString(minOutput.value) && inputValue) exceedMin = isTime ? convertTimeToDate(inputValue) < convertTimeToDate(minOutput.value) : isWeek ? inputValue < minOutput.value : valueDate < new Date(minOutput.value);
		}
		if (exceedMax || exceedMin) {
			getMinMaxMessage(!!exceedMax, maxOutput.message, minOutput.message, INPUT_VALIDATION_RULES.max, INPUT_VALIDATION_RULES.min);
			if (!validateAllFieldCriteria) {
				setCustomValidity(error[name].message);
				return error;
			}
		}
	}
	if ((maxLength || minLength) && !isEmpty && (isString(inputValue) || isFieldArray && Array.isArray(inputValue))) {
		const maxLengthOutput = getValueAndMessage(maxLength);
		const minLengthOutput = getValueAndMessage(minLength);
		const exceedMax = !isNullOrUndefined(maxLengthOutput.value) && inputValue.length > +maxLengthOutput.value;
		const exceedMin = !isNullOrUndefined(minLengthOutput.value) && inputValue.length < +minLengthOutput.value;
		if (exceedMax || exceedMin) {
			getMinMaxMessage(exceedMax, maxLengthOutput.message, minLengthOutput.message);
			if (!validateAllFieldCriteria) {
				setCustomValidity(error[name].message);
				return error;
			}
		}
	}
	if (pattern && !isEmpty && isString(inputValue)) {
		const { value: patternValue, message } = getValueAndMessage(pattern);
		if (isRegex(patternValue) && !inputValue.match(patternValue)) {
			error[name] = {
				type: INPUT_VALIDATION_RULES.pattern,
				message,
				ref,
				...appendErrorsCurry(INPUT_VALIDATION_RULES.pattern, message)
			};
			if (!validateAllFieldCriteria) {
				setCustomValidity(message);
				return error;
			}
		}
	}
	if (validate) {
		if (isFunction(validate)) {
			const validateError = getValidateError(await validate(inputValue, formValues), inputRef);
			if (validateError) {
				error[name] = {
					...validateError,
					...appendErrorsCurry(INPUT_VALIDATION_RULES.validate, validateError.message)
				};
				if (!validateAllFieldCriteria) {
					setCustomValidity(validateError.message);
					return error;
				}
			}
		} else if (isObject(validate)) {
			let validationResult = {};
			for (const key in validate) {
				if (!isEmptyObject(validationResult) && !validateAllFieldCriteria) break;
				const validateError = getValidateError(await validate[key](inputValue, formValues), inputRef, key);
				if (validateError) {
					validationResult = {
						...validateError,
						...appendErrorsCurry(key, validateError.message)
					};
					if (!validateAllFieldCriteria) setCustomValidity(validateError.message);
					if (validateAllFieldCriteria) error[name] = validationResult;
				}
			}
			if (!isEmptyObject(validationResult)) {
				error[name] = {
					ref: inputRef,
					...validationResult
				};
				if (!validateAllFieldCriteria) return error;
			}
		}
	}
	const fieldError = error[name];
	setCustomValidity(fieldError ? fieldError.message : true);
	return error;
};
var convertToArrayPayload = (value) => Array.isArray(value) ? value : [value];
var appendAt = (data, value) => [...data, ...convertToArrayPayload(value)];
var fillEmptyArray = (value) => Array.isArray(value) ? value.map(() => void 0) : void 0;
function insert(data, index, value) {
	return [
		...data.slice(0, index),
		...convertToArrayPayload(value),
		...data.slice(index)
	];
}
var moveArrayAt = (data, from, to) => {
	if (!Array.isArray(data)) return [];
	if (isUndefined(data[to])) data[to] = void 0;
	data.splice(to, 0, data.splice(from, 1)[0]);
	return data;
};
var prependAt = (data, value) => [...convertToArrayPayload(value), ...convertToArrayPayload(data)];
var compact = (value) => Array.isArray(value) ? value.filter(Boolean) : [];
function removeAtIndexes(data, indexes) {
	let i = 0;
	const temp = [...data];
	for (const index of indexes) {
		temp.splice(index - i, 1);
		i++;
	}
	return compact(temp).length ? temp : [];
}
var removeArrayAt = (data, index) => isUndefined(index) ? [] : removeAtIndexes(data, [...new Set(convertToArrayPayload(index))].sort((a, b) => a - b));
var swapArrayAt = (data, indexA, indexB) => {
	[data[indexA], data[indexB]] = [data[indexB], data[indexA]];
};
function baseGet(object, updatePath) {
	const length = updatePath.length - 1;
	let index = 0;
	while (index < length) {
		if (isNullOrUndefined(object)) {
			object = void 0;
			break;
		}
		object = object[updatePath[index]];
		index++;
	}
	return object;
}
function isEmptyArray(obj) {
	for (const key in obj) if (obj.hasOwnProperty(key) && !isUndefined(obj[key])) return false;
	return true;
}
function unset(object, path) {
	if (isString(path) && Object.prototype.hasOwnProperty.call(object, path)) {
		delete object[path];
		return object;
	}
	const paths = Array.isArray(path) ? path : isKey(path) ? [path] : stringToPath(path);
	if (paths.some((segment) => PROTOTYPE_KEYWORDS.includes(String(segment)))) return object;
	const childObject = paths.length === 1 ? object : baseGet(object, paths);
	const index = paths.length - 1;
	const key = paths[index];
	if (childObject) delete childObject[key];
	if (index !== 0 && (isObject(childObject) && isEmptyObject(childObject) || Array.isArray(childObject) && isEmptyArray(childObject))) unset(object, paths.slice(0, -1));
	return object;
}
var updateAt = (fieldValues, index, value) => {
	fieldValues[index] = value;
	return fieldValues;
};
/**
* Hook for dynamic field arrays. Provides `fields` and mutation methods:
* `append`, `prepend`, `remove`, `insert`, `swap`, `move`, `update`, `replace`.
*
* @see [API](https://react-hook-form.com/docs/usefieldarray)
*
* @example
* ```tsx
* const { fields, append } = useFieldArray({ control, name: "items" });
* return fields.map((f, i) => <input key={f.id} {...register(`items.${i}.name`)} />);
* ```
*/
function useFieldArray(props) {
	const formControl = useFormControlContext();
	const { control = formControl, name, keyName = "id", disabled, shouldUnregister, rules } = props;
	const getCurrentFieldArray = () => control._getFieldArray(name);
	const [fields, setFields] = import_react.useState(getCurrentFieldArray);
	const ids = import_react.useRef(control._getFieldArray(name).map(generateId));
	const _actioned = import_react.useRef(false);
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect(getCurrentFieldArray);
	const _prevControl = import_react.useRef(control);
	const _prevName = import_react.useRef(name);
	if (!disabled) control._names.array.add(name);
	import_react.useMemo(() => !disabled && rules && fields.length >= 0 && control.register(name, rules), [
		control,
		name,
		fields.length,
		rules,
		disabled
	]);
	useIsomorphicLayoutEffect(() => {
		if (disabled) return;
		if (_prevControl.current === control && _prevName.current === name) resyncIfNeeded(true, getCurrentFieldArray, (fieldValues) => {
			setFields(fieldValues);
			ids.current = fieldValues.map(generateId);
		});
		else {
			_prevControl.current = control;
			_prevName.current = name;
			const fieldValues = getCurrentFieldArray();
			if (!deepEqual(fields, fieldValues)) {
				setFields(fieldValues);
				ids.current = fieldValues.map(generateId);
			}
			snapshot(true, getCurrentFieldArray);
		}
		const unsubscribe = control._subjects.array.subscribe({ next: ({ values, name: fieldArrayName }) => {
			if (fieldArrayName === name || !fieldArrayName) {
				const fieldValues = get(values, name);
				if (Array.isArray(fieldValues)) {
					setFields(fieldValues);
					ids.current = fieldValues.map(generateId);
				} else if (!fieldArrayName) {
					setFields([]);
					ids.current = [];
				}
			}
		} }).unsubscribe;
		return () => {
			unsubscribe();
			snapshot(true, getCurrentFieldArray);
		};
	}, [
		control,
		name,
		disabled,
		resyncIfNeeded,
		snapshot
	]);
	const updateValues = import_react.useCallback((updatedFieldArrayValues) => {
		_actioned.current = true;
		control._setFieldArray(name, updatedFieldArrayValues);
	}, [control, name]);
	const append = (value, options) => {
		if (disabled) return;
		const appendValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = appendAt(control._getFieldArray(name), appendValue);
		control._names.focus = getFocusFieldName(name, updatedFieldArrayValues.length - 1, options);
		ids.current = appendAt(ids.current, appendValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, appendAt, { argA: fillEmptyArray(value) });
	};
	const prepend = (value, options) => {
		if (disabled) return;
		const prependValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = prependAt(control._getFieldArray(name), prependValue);
		control._names.focus = getFocusFieldName(name, 0, options);
		ids.current = prependAt(ids.current, prependValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, prependAt, { argA: fillEmptyArray(value) });
	};
	const remove = (index) => {
		if (disabled) return;
		const updatedFieldArrayValues = removeArrayAt(control._getFieldArray(name), index);
		ids.current = removeArrayAt(ids.current, index);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		!Array.isArray(get(control._fields, name)) && set(control._fields, name, void 0);
		control._setFieldArray(name, updatedFieldArrayValues, removeArrayAt, { argA: index });
	};
	const insert$1 = (index, value, options) => {
		if (disabled) return;
		const insertValue = convertToArrayPayload(cloneObject(value));
		const updatedFieldArrayValues = insert(control._getFieldArray(name), index, insertValue);
		control._names.focus = getFocusFieldName(name, index, options);
		ids.current = insert(ids.current, index, insertValue.map(generateId));
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, insert, {
			argA: index,
			argB: fillEmptyArray(value)
		});
	};
	const swap = (indexA, indexB) => {
		if (disabled) return;
		const updatedFieldArrayValues = control._getFieldArray(name);
		swapArrayAt(updatedFieldArrayValues, indexA, indexB);
		swapArrayAt(ids.current, indexA, indexB);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, swapArrayAt, {
			argA: indexA,
			argB: indexB
		}, false);
	};
	const move = (from, to) => {
		if (disabled) return;
		const updatedFieldArrayValues = control._getFieldArray(name);
		moveArrayAt(updatedFieldArrayValues, from, to);
		moveArrayAt(ids.current, from, to);
		updateValues(updatedFieldArrayValues);
		setFields(updatedFieldArrayValues);
		control._setFieldArray(name, updatedFieldArrayValues, moveArrayAt, {
			argA: from,
			argB: to
		}, false);
	};
	const update = (index, value) => {
		if (disabled) return;
		const updateValue = cloneObject(value);
		const updatedFieldArrayValues = updateAt(control._getFieldArray(name), index, updateValue);
		ids.current = [...updatedFieldArrayValues].map((item, i) => !item || i === index ? generateId() : ids.current[i]);
		updateValues(updatedFieldArrayValues);
		setFields([...updatedFieldArrayValues]);
		control._setFieldArray(name, updatedFieldArrayValues, updateAt, {
			argA: index,
			argB: fillEmptyArray(value)
		});
	};
	const replace = (value) => {
		if (disabled) return;
		const updatedFieldArrayValues = convertToArrayPayload(cloneObject(value));
		ids.current = updatedFieldArrayValues.map(generateId);
		updateValues([...updatedFieldArrayValues]);
		setFields([...updatedFieldArrayValues]);
		control._setFieldArray(name, [...updatedFieldArrayValues], (data) => Array.isArray(data) ? data.slice(0, updatedFieldArrayValues.length) : data, {});
	};
	import_react.useEffect(() => {
		if (disabled) {
			control._state.actionArrayLengths.delete(name);
			return;
		}
		control._state.action = false;
		control._state.actionArrayLengths.delete(name);
		isWatched(name, control._names) && control._subjects.state.next({ ...control._formState });
		const validationModes = getValidationModes(control._options.mode);
		if (_actioned.current && (!validationModes.isOnSubmit || control._formState.isSubmitted) && !getValidationModes(control._options.reValidateMode).isOnSubmit && !validationModes.isOnBlur) {
			if (control._options.resolver) control._runSchema([name]).then((result) => {
				control._updateIsValidating([name]);
				const error = get(result.errors, name);
				const existingError = get(control._formState.errors, name);
				const existingErrorType = existingError && (existingError.type || existingError.root && existingError.root.type);
				const existingErrorMessage = existingError && (existingError.message || existingError.root && existingError.root.message);
				if (existingError ? !error && existingErrorType || error && (existingErrorType !== error.type || existingErrorMessage !== error.message) : error && error.type) {
					if (error) isObject(error) && !Object.keys(error).some((key) => !Number.isNaN(+key)) ? updateFieldArrayRootError(control._formState.errors, { [name]: error }, name) : set(control._formState.errors, name, error);
					else unset(control._formState.errors, name);
					control._formState.errors = { ...control._formState.errors };
					control._subjects.state.next({ errors: control._formState.errors });
				}
			});
			else {
				const field = get(control._fields, name);
				if (field && field._f) validateField(field, control._names.disabled, control._formValues, control._options.criteriaMode === VALIDATION_MODE.all, control._options.shouldUseNativeValidation, true).then((error) => {
					if (!isEmptyObject(error)) {
						updateFieldArrayRootError(control._formState.errors, error, name);
						control._formState.errors = { ...control._formState.errors };
						control._subjects.state.next({ errors: control._formState.errors });
					} else {
						const existingError = get(control._formState.errors, name);
						if (existingError && existingError[ROOT_ERROR_TYPE]) {
							unset(control._formState.errors, `${name}.${ROOT_ERROR_TYPE}`);
							control._formState.errors = { ...control._formState.errors };
							control._subjects.state.next({ errors: control._formState.errors });
						}
					}
				});
			}
		}
		_actioned.current && control._subjects.state.next({
			name,
			values: cloneObject(control._formValues)
		});
		control._names.focus && iterateFieldsByAction(control._fields, (ref, key) => {
			if (control._names.focus && key.startsWith(control._names.focus) && ref.focus) {
				ref.focus();
				return 1;
			}
		});
		control._names.focus = "";
		control._setValid();
		_actioned.current = false;
	}, [
		fields,
		name,
		control,
		disabled
	]);
	import_react.useEffect(() => {
		if (!disabled) isUndefined(get(control._formValues, name)) && control._setFieldArray(name);
		return () => {
			control._state.actionArrayLengths.delete(name);
			if (disabled) return;
			const shouldKeepFieldArrayValues = !(control._options.shouldUnregister || shouldUnregister);
			const updateMounted = (name, value) => {
				const field = get(control._fields, name);
				if (field && field._f) field._f.mount = value;
			};
			if (_actioned.current && shouldKeepFieldArrayValues) control._subjects.state.next({
				name,
				values: cloneObject(control._formValues)
			});
			if (!shouldKeepFieldArrayValues && control._state.action) return;
			shouldKeepFieldArrayValues ? updateMounted(name, false) : control.unregister(name);
		};
	}, [
		name,
		control,
		keyName,
		shouldUnregister,
		disabled
	]);
	return {
		swap: import_react.useCallback(swap, [
			updateValues,
			name,
			control,
			disabled
		]),
		move: import_react.useCallback(move, [
			updateValues,
			name,
			control,
			disabled
		]),
		prepend: import_react.useCallback(prepend, [
			updateValues,
			name,
			control,
			disabled
		]),
		append: import_react.useCallback(append, [
			updateValues,
			name,
			control,
			disabled
		]),
		remove: import_react.useCallback(remove, [
			updateValues,
			name,
			control,
			disabled
		]),
		insert: import_react.useCallback(insert$1, [
			updateValues,
			name,
			control,
			disabled
		]),
		update: import_react.useCallback(update, [
			updateValues,
			name,
			control,
			disabled
		]),
		replace: import_react.useCallback(replace, [
			updateValues,
			name,
			control,
			disabled
		]),
		fields: import_react.useMemo(() => fields.map((field, index) => ({
			...field,
			...isBoolean(disabled) ? { disabled } : {},
			[keyName]: ids.current[index] || generateId()
		})), [
			fields,
			keyName,
			disabled
		])
	};
}
/**
* Component based on `useFieldArray` hook to work with controlled component.
*
* @example
* ```tsx
* function App() {
*   const { control, register } = useForm<FormValues>({
*     defaultValues: {
*       test: [
*         {
*           value: '',
*         },
*       ],
*     },
*   });
*
*   return (
*     <form>
*       <FieldArray
*         control={control}
*         name="test"
*         render={({ fields }) =>
*           fields.map((field, index) => (
*             <input key={field.id} {...register(`test.${index}.value`)} />
*           ))
*         }
*       />
*     </form>
*   );
* }
* ```
*/
var FieldArray = (props) => props.render(useFieldArray(props));
var isFileLike = (value) => typeof Blob !== "undefined" && value instanceof Blob || typeof File !== "undefined" && value instanceof File;
var isFileListLike = (value) => typeof FileList !== "undefined" && value instanceof FileList;
var flatten = (obj) => {
	const output = {};
	for (const key of Object.keys(obj)) if (isObjectType(obj[key]) && obj[key] !== null && !isDateObject(obj[key]) && !isFileLike(obj[key]) && !isFileListLike(obj[key])) {
		const nested = flatten(obj[key]);
		for (const nestedKey of Object.keys(nested)) output[`${key}.${nestedKey}`] = nested[nestedKey];
	} else output[key] = obj[key];
	return output;
};
function jsonToFormData(json) {
	const result = new FormData();
	const flattenFormValues = flatten(json);
	for (const key in flattenFormValues) {
		const value = flattenFormValues[key];
		if (isUndefined(value)) continue;
		if (typeof FileList !== "undefined" && value instanceof FileList) {
			for (let index = 0; index < value.length; index++) {
				const file = value[index];
				file && result.append(key, file);
			}
			continue;
		}
		result.append(key, value);
	}
	return result;
}
function safeJSONStringify(value) {
	try {
		return JSON.stringify(value);
	} catch (_a) {
		return "";
	}
}
function noop() {}
var HookFormContext = import_react.createContext(null);
HookFormContext.displayName = "HookFormContext";
/**
* Retrieves all `useForm` methods from the nearest `FormProvider`.
* Use in deeply nested components to avoid prop-drilling.
*
* @see [API](https://react-hook-form.com/docs/useformcontext)
*
* @example
* ```tsx
* const { register } = useFormContext<FormValues>();
* ```
*/
var useFormContext = () => import_react.useContext(HookFormContext);
/**
* Provides all `useForm` methods to the component tree via React Context.
* Pair with `useFormContext` to consume them in any descendant.
*
* @see [API](https://react-hook-form.com/docs/useformcontext)
*
* @example
* ```tsx
* <FormProvider {...methods}>
*   <form onSubmit={methods.handleSubmit(onSubmit)}>{children}</form>
* </FormProvider>
* ```
*/
var FormProvider = ({ children, watch, getValues, getErrors, getFieldState, setError, clearErrors, setValue, setValues, trigger, formState, resetField, reset, resetDefaultValues, handleSubmit, unregister, control, register, setFocus, subscribe }) => {
	const memoizedValue = import_react.useMemo(() => ({
		watch,
		getValues,
		getErrors,
		getFieldState,
		setError,
		clearErrors,
		setValue,
		setValues,
		trigger,
		formState,
		resetField,
		reset,
		resetDefaultValues,
		handleSubmit,
		unregister,
		control,
		register,
		setFocus,
		subscribe
	}), [
		clearErrors,
		control,
		formState,
		getErrors,
		getFieldState,
		getValues,
		handleSubmit,
		register,
		reset,
		resetDefaultValues,
		resetField,
		setError,
		setFocus,
		setValue,
		setValues,
		subscribe,
		trigger,
		unregister,
		watch
	]);
	return import_react.createElement(HookFormContext.Provider, { value: memoizedValue }, import_react.createElement(HookFormControlContext.Provider, { value: memoizedValue.control }, children));
};
var POST_REQUEST = "post";
function defaultValidateStatus(status) {
	return status >= 200 && status < 300;
}
/**
* Form component that handles submission, including optional `action` fetch and server error wiring.
*
* @see [API](https://react-hook-form.com/docs/useform/form)
*
* @example
* ```tsx
* <Form action="/api" control={control}>
*   <input {...register("name")} />
*   <p>{errors?.root?.server && 'Server error'}</p>
*   <button>Submit</button>
* </Form>
* ```
*/
function Form(props) {
	const methods = useFormContext();
	const [mounted, setMounted] = import_react.useState(false);
	const { control = methods.control, onSubmit = noop, children, action, method = POST_REQUEST, headers, encType, onError = noop, render, onSuccess = noop, validateStatus = defaultValidateStatus, ...rest } = props;
	const handleSubmit = import_react.useMemo(() => {
		return control.handleSubmit(async (data, event) => {
			const formData = jsonToFormData(data);
			const formDataJson = safeJSONStringify(data);
			if (onSubmit) await onSubmit({
				data,
				event,
				method,
				formData,
				formDataJson
			});
			if (isString(action)) try {
				const shouldStringifySubmissionData = headers && headers["Content-Type"] && headers["Content-Type"].includes("json") || encType && encType.includes("json");
				const response = await fetch(action, {
					method,
					headers: {
						...headers,
						...encType && encType !== "multipart/form-data" && { "Content-Type": encType }
					},
					body: shouldStringifySubmissionData ? formDataJson : formData
				});
				if (response && !validateStatus(response.status)) {
					onError({ response });
					return { type: String(response.status) };
				} else onSuccess({ response });
			} catch (error) {
				onError({ error });
				return { type: "" };
			}
			if (isFunction(action)) try {
				await action(formData);
			} catch (error) {
				onError({ error });
				return { type: "" };
			}
		});
	}, [
		control,
		onSubmit,
		method,
		action,
		headers,
		encType,
		validateStatus,
		onError,
		onSuccess
	]);
	const submit = import_react.useCallback(async (event) => {
		const err = await handleSubmit(event);
		if (err && control) {
			control._subjects.state.next({ isSubmitSuccessful: false });
			control.setError("root.server", err);
		}
	}, [handleSubmit, control]);
	import_react.useEffect(() => {
		setMounted(true);
	}, []);
	if (render) return render({ submit });
	return import_react.createElement("form", {
		noValidate: mounted,
		action,
		...!isFunction(action) && {
			method,
			encType
		},
		onSubmit: submit,
		...rest
	}, children);
}
var FormState = ({ control, disabled, exact, name, render }) => render(useFormState({
	control,
	name,
	disabled,
	exact
}));
/** @deprecated Use `FormState` instead. Kept as an alias for backward compatibility. */
var FormStateSubscribe = FormState;
var createSubject = () => {
	let _observers = /* @__PURE__ */ new Set();
	let _iterationCount = 0;
	const next = (value) => {
		const observers = _observers;
		_iterationCount++;
		for (const observer of observers) observer.next && observer.next(value);
		observers === _observers && _iterationCount--;
	};
	const subscribe = (observer) => {
		_observers.add(observer);
		return { unsubscribe: () => {
			if (_iterationCount) {
				_observers = new Set(_observers);
				_iterationCount = 0;
			}
			_observers.delete(observer);
		} };
	};
	const unsubscribe = () => {
		_observers = /* @__PURE__ */ new Set();
		_iterationCount = 0;
	};
	return {
		get observers() {
			return Array.from(_observers);
		},
		next,
		subscribe,
		unsubscribe
	};
};
function extractFormValues(fieldsState, formValues) {
	const values = Array.isArray(fieldsState) ? [] : {};
	for (const key in fieldsState) if (Object.prototype.hasOwnProperty.call(fieldsState, key)) {
		const fieldState = fieldsState[key];
		const fieldValue = formValues[key];
		if (fieldState && (isObject(fieldState) || Array.isArray(fieldState)) && fieldValue) values[key] = extractFormValues(fieldState, fieldValue);
		else if (fieldsState[key]) values[key] = fieldValue;
	}
	return values;
}
var hasOwn = (value, key) => value !== null && isObjectType(value) && Object.prototype.hasOwnProperty.call(value, key);
var has = (object, path) => {
	if (!path) return false;
	let result = object;
	for (const key of isKey(path) ? [path] : stringToPath(path)) {
		if (!hasOwn(result, key)) return hasOwn(object, path);
		result = result[key];
	}
	return true;
};
var isEdited = (ref) => isCheckBoxInput(ref) ? ref.checked !== ref.defaultChecked : !isRadioInput(ref) && "defaultValue" in ref && ref.value !== ref.defaultValue;
var isMultipleSelect = (element) => element.type === `select-multiple`;
var isRadioOrCheckbox = (ref) => isRadioInput(ref) || isCheckBoxInput(ref);
var live = (ref) => isHTMLElement(ref) && ref.isConnected;
function isDirtyContainer(value) {
	return Array.isArray(value) || isObject(value);
}
function collectDirtyFieldNames(dirtyTree, cachedDirtyFields, prefix = "", names = []) {
	for (const key in dirtyTree) {
		const path = prefix ? `${prefix}.${key}` : key;
		const value = dirtyTree[key];
		if (isDirtyContainer(value) && isDirtyContainer(get(cachedDirtyFields, path))) collectDirtyFieldNames(value, cachedDirtyFields, path, names);
		else names.push(path);
	}
	return names;
}
var objectHasFunction = (data) => {
	for (const key in data) if (isFunction(data[key])) return true;
	return false;
};
function isTraversable(value) {
	return Array.isArray(value) || isObject(value) && !objectHasFunction(value);
}
function isRegisteredLeaf(fieldRef) {
	return !!(fieldRef && "_f" in fieldRef);
}
function isEmptyDirtyContainer(value) {
	return Array.isArray(value) ? !value.some((item) => !isUndefined(item)) : !Object.keys(value).length;
}
function clearDirtyField(container, key) {
	if (Array.isArray(container)) container[key] = void 0;
	else delete container[key];
}
function markFieldsDirty(data, fields = {}, fieldRefs) {
	for (const key in data) {
		const value = data[key];
		const fieldRef = fieldRefs && fieldRefs[key];
		if (isTraversable(value) && (!Array.isArray(value) || !isRegisteredLeaf(fieldRef))) {
			fields[key] = Array.isArray(value) ? [] : {};
			markFieldsDirty(value, fields[key], fieldRef);
			if (isEmptyDirtyContainer(fields[key])) clearDirtyField(fields, key);
		} else if (!isUndefined(value)) fields[key] = true;
	}
	return fields;
}
function getDirtyFields(data, formValues, dirtyFieldsFromValues, fieldRefs) {
	if (!dirtyFieldsFromValues) dirtyFieldsFromValues = markFieldsDirty(formValues, Array.isArray(formValues) ? [] : {}, fieldRefs);
	for (const key in data) {
		const value = data[key];
		const fieldRef = fieldRefs && fieldRefs[key];
		if (isTraversable(value) && (!Array.isArray(value) || !isRegisteredLeaf(fieldRef))) {
			if (isUndefined(formValues) || isPrimitive(dirtyFieldsFromValues[key])) dirtyFieldsFromValues[key] = markFieldsDirty(value, Array.isArray(value) ? [] : {}, fieldRef);
			else getDirtyFields(value, isNullOrUndefined(formValues) ? {} : formValues[key], dirtyFieldsFromValues[key], fieldRef);
			if (isEmptyDirtyContainer(dirtyFieldsFromValues[key])) clearDirtyField(dirtyFieldsFromValues, key);
		} else if (deepEqual(value, formValues[key])) clearDirtyField(dirtyFieldsFromValues, key);
		else dirtyFieldsFromValues[key] = true;
	}
	return dirtyFieldsFromValues;
}
var getFieldArrayItemNames = (names, name) => {
	const segments = name.split(".");
	const matches = [];
	let prefix = segments[0];
	for (let i = 1; i < segments.length; prefix += "." + segments[i++]) if (!isNaN(+segments[i]) && names.has(prefix)) matches.push(`${prefix}.${segments[i]}`);
	return matches;
};
var getFieldValueAs = (value, { valueAsNumber, valueAsDate, setValueAs }) => isUndefined(value) ? value : valueAsNumber ? value === "" ? NaN : value ? +value : value : valueAsDate && isString(value) ? new Date(value) : setValueAs ? setValueAs(value) : value;
function getFieldValue(_f) {
	const ref = _f.ref;
	if (isFileInput(ref)) return ref.files;
	if (isRadioInput(ref)) return getRadioValue(_f.refs).value;
	if (isMultipleSelect(ref)) return [...ref.selectedOptions].map(({ value }) => value);
	if (isCheckBoxInput(ref)) return getCheckboxValue(_f.refs).value;
	return getFieldValueAs(ref.value, _f);
}
var getResolverOptions = (fieldsNames, _fields, criteriaMode, shouldUseNativeValidation) => {
	const fields = {};
	for (const name of fieldsNames) {
		const field = get(_fields, name);
		field && set(fields, name, field._f);
	}
	return {
		criteriaMode,
		names: [...fieldsNames],
		fields,
		shouldUseNativeValidation
	};
};
var getRuleValue = (rule) => isUndefined(rule) ? rule : isRegex(rule) ? rule.source : isObject(rule) ? isRegex(rule.value) ? rule.value.source : rule.value : rule;
var ASYNC_FUNCTION = "AsyncFunction";
var hasPromiseValidation = (fieldReference) => {
	if (!fieldReference || !fieldReference.validate) return false;
	if (isFunction(fieldReference.validate)) return fieldReference.validate.constructor.name === ASYNC_FUNCTION;
	if (isObject(fieldReference.validate)) {
		for (const key in fieldReference.validate) if (fieldReference.validate[key].constructor.name === ASYNC_FUNCTION) return true;
	}
	return false;
};
var hasValidation = (options) => options.mount && (options.required || !isUndefined(options.required) && options.required !== false || !isUndefined(options.min) || !isUndefined(options.max) || !isUndefined(options.maxLength) || !isUndefined(options.minLength) || options.pattern || options.validate);
function schemaErrorLookup(errors, _fields, name) {
	const error = get(errors, name);
	if (error && (error.type || error.message) || Array.isArray(error)) return {
		error,
		name
	};
	const names = name.split(".");
	while (names.length) {
		const fieldName = names.join(".");
		const field = get(_fields, fieldName);
		const foundError = get(errors, fieldName);
		if (field && !Array.isArray(field) && name !== fieldName) return { name };
		if (foundError && foundError.type) return {
			name: fieldName,
			error: foundError
		};
		if (foundError && foundError.root && foundError.root.type) return {
			name: `${fieldName}.root`,
			error: foundError.root
		};
		names.pop();
	}
	return { name };
}
var shouldRenderFormState = (formStateData, _proxyFormState, isRoot) => {
	const keys = Object.keys(formStateData).filter((key) => key !== "name");
	return !keys.length || isRoot && keys.length >= Object.keys(_proxyFormState).length || keys.find((key) => _proxyFormState[key] === (!isRoot || VALIDATION_MODE.all));
};
var isNameMatch = (currentName, signalName, exact) => exact ? currentName === signalName || currentName.startsWith(signalName + ".") : currentName.startsWith(signalName) || signalName.startsWith(currentName);
var shouldSubscribeByName = (name, signalName, exact) => {
	if (!name || !signalName || name === signalName) return true;
	if (!Array.isArray(name)) return isNameMatch(name, signalName, exact);
	for (const currentName of name) if (currentName && isNameMatch(currentName, signalName, exact)) return true;
	return false;
};
var skipValidation = (isBlurEvent, isTouched, isSubmitted, reValidateMode, mode) => {
	if (mode.isOnAll) return false;
	else if (!isSubmitted && mode.isOnTouch) return !(isTouched || isBlurEvent);
	else if (isSubmitted ? reValidateMode.isOnBlur : mode.isOnBlur) return !isBlurEvent;
	else if (isSubmitted ? reValidateMode.isOnChange : mode.isOnChange) return isBlurEvent;
	return true;
};
var unsetEmptyArray = (ref, name) => {
	const array = get(ref, name);
	!compact(array).length && !(array && array.root) && unset(ref, name);
};
var defaultOptions = {
	mode: VALIDATION_MODE.onSubmit,
	reValidateMode: VALIDATION_MODE.onChange,
	shouldFocusError: true
};
var replaceDirtyFieldsInPlace = (dirtyFields, nextDirtyFields) => {
	for (const key in dirtyFields) delete dirtyFields[key];
	Object.assign(dirtyFields, nextDirtyFields);
};
var DEFAULT_FORM_STATE = {
	submitCount: 0,
	isDirty: false,
	isReady: false,
	isValidating: false,
	isSubmitted: false,
	isSubmitting: false,
	isSubmitSuccessful: false,
	isValid: false,
	touchedFields: {},
	dirtyFields: {},
	validatingFields: {}
};
function createFormControl(props = {}) {
	let _options = {
		...defaultOptions,
		...props
	};
	let _formState = {
		...cloneObject(DEFAULT_FORM_STATE),
		isLoading: isFunction(_options.defaultValues),
		errors: _options.errors || {},
		disabled: _options.disabled || false
	};
	let _fields = {};
	let _defaultValues = isObject(_options.defaultValues) || isObject(_options.values) ? cloneObject(_options.defaultValues || _options.values) || {} : {};
	let _formValues = _options.shouldUnregister ? {} : cloneObject(_defaultValues);
	let _state = {
		action: false,
		actionArrayLengths: /* @__PURE__ */ new Map(),
		mount: false,
		watch: false,
		keepIsValid: false
	};
	let _dirtyFieldsStale = false;
	let _names = {
		mount: /* @__PURE__ */ new Set(),
		disabled: /* @__PURE__ */ new Set(),
		unMount: /* @__PURE__ */ new Set(),
		array: /* @__PURE__ */ new Set(),
		watch: /* @__PURE__ */ new Set(),
		registerName: /* @__PURE__ */ new Set()
	};
	const delayErrorCallbacks = {};
	const timers = {};
	const _valuesSubscribers = /* @__PURE__ */ new Set();
	let _validationModeBeforeSubmit = getValidationModes(_options.mode);
	let _validationModeAfterSubmit = getValidationModes(_options.reValidateMode);
	const defaultProxyFormState = {
		isDirty: false,
		dirtyFields: false,
		validatingFields: false,
		touchedFields: false,
		isValidating: false,
		isValid: false,
		errors: false
	};
	const _proxyFormState = { ...defaultProxyFormState };
	const _proxySubscribeFormState = {};
	const _isTracked = (...keys) => keys.some((key) => _proxyFormState[key] || _proxySubscribeFormState[key]);
	const _hasValuesSubscriber = (name) => {
		for (const subscriber of _valuesSubscribers) if (shouldSubscribeByName(subscriber.name, name, subscriber.exact)) return true;
		return false;
	};
	const _subjects = {
		array: createSubject(),
		state: createSubject()
	};
	let _setValidCallId = 0;
	let _resetCallId = 0;
	let shouldDisplayAllAssociatedErrors = _options.criteriaMode === VALIDATION_MODE.all;
	const debounce = (name, callback) => (wait) => {
		clearTimeout(timers[name]);
		timers[name] = setTimeout(callback, wait);
	};
	const cancelDelayedError = (name) => {
		clearTimeout(timers[name]);
		delete timers[name];
		delete delayErrorCallbacks[name];
	};
	const cancelDelayedErrorTree = (name) => {
		cancelDelayedError(name);
		const prefix = `${name}.`;
		for (const key of Object.keys(delayErrorCallbacks)) key.startsWith(prefix) && cancelDelayedError(key);
	};
	const _setValid = async (shouldUpdateValid) => {
		if (_state.keepIsValid) return;
		if (!_options.disabled && (_isTracked("isValid") || shouldUpdateValid)) {
			const callId = ++_setValidCallId;
			let isValid;
			if (_options.resolver) {
				isValid = isEmptyObject((await _runSchema()).errors);
				callId === _setValidCallId && _updateIsValidating();
			} else isValid = await executeBuiltInValidation({
				fields: _fields,
				onlyCheckValid: true,
				eventType: EVENTS.VALID
			});
			if (callId === _setValidCallId && isValid !== _formState.isValid) _subjects.state.next({ isValid });
		}
	};
	const _updateIsValidating = (names, isValidating) => {
		if (!_options.disabled && _isTracked("isValidating", "validatingFields")) {
			(names || _names.mount).forEach((name) => {
				if (name) isValidating ? set(_formState.validatingFields, name, isValidating) : unset(_formState.validatingFields, name);
			});
			_subjects.state.next({
				validatingFields: _formState.validatingFields,
				isValidating: !isEmptyObject(_formState.validatingFields)
			});
		}
	};
	const _updateDirtyFields = () => {
		_formState.dirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
	};
	const _setFieldArray = (name, values = [], method, args, shouldSetValues = true, shouldUpdateFieldsAndState = true) => {
		if (args && method && !_options.disabled) {
			_state.action = true;
			const fields = get(_fields, name);
			if (!_state.actionArrayLengths.has(name)) _state.actionArrayLengths.set(name, Array.isArray(fields) ? fields.length : 0);
			if (shouldUpdateFieldsAndState && Array.isArray(fields)) {
				const fieldValues = method(fields, args.argA, args.argB);
				shouldSetValues && set(_fields, name, fieldValues);
			}
			const fieldArrayErrors = get(_formState.errors, name);
			if (shouldUpdateFieldsAndState && Array.isArray(fieldArrayErrors)) {
				const rootError = fieldArrayErrors.root;
				const errors = method(fieldArrayErrors, args.argA, args.argB) || fieldArrayErrors;
				if (rootError) errors.root = rootError;
				shouldSetValues && set(_formState.errors, name, errors);
				unsetEmptyArray(_formState.errors, name);
				_formState.errors = { ..._formState.errors };
			}
			const touchedFieldsArray = get(_formState.touchedFields, name);
			const shouldUpdateTouchedFields = shouldUpdateFieldsAndState && Array.isArray(touchedFieldsArray);
			if (shouldUpdateTouchedFields) {
				const touchedFields = method(touchedFieldsArray, args.argA, args.argB);
				shouldSetValues && set(_formState.touchedFields, name, touchedFields);
			}
			const dirtyFieldsArray = get(_formState.dirtyFields, name);
			if (shouldUpdateFieldsAndState && Array.isArray(dirtyFieldsArray)) {
				const dirtyFields = method(dirtyFieldsArray, args.argA, args.argB) || dirtyFieldsArray;
				shouldSetValues && set(_formState.dirtyFields, name, dirtyFields);
			}
			if (_isTracked("dirtyFields")) _updateDirtyFields();
			else _dirtyFieldsStale = true;
			_subjects.state.next({
				name,
				isDirty: _getDirty(name, values),
				dirtyFields: _formState.dirtyFields,
				...shouldUpdateTouchedFields && { touchedFields: _formState.touchedFields },
				errors: _formState.errors,
				isValid: _formState.isValid
			});
		} else set(_formValues, name, values);
	};
	const updateErrors = (name, error) => {
		set(_formState.errors, name, error);
		_formState.errors = { ..._formState.errors };
		_subjects.state.next({ errors: _formState.errors });
	};
	const _setErrors = (errors) => {
		Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
		const hasErrors = !isEmptyObject(errors);
		_formState.errors = errors;
		_subjects.state.next({
			errors: _formState.errors,
			...hasErrors ? { isValid: false } : {}
		});
		!hasErrors && _state.mount && _setValid();
	};
	const hasExplicitNullIntermediate = (name) => {
		const segments = isKey(name) ? [name] : stringToPath(name);
		let formValues = _formValues;
		let defaultValues = _defaultValues;
		for (let i = 0; i < segments.length - 1; i++) {
			const key = segments[i];
			formValues = isNullOrUndefined(formValues) ? formValues : formValues[key];
			defaultValues = isNullOrUndefined(defaultValues) ? defaultValues : defaultValues[key];
			if (formValues === null && defaultValues !== null) return true;
		}
		return false;
	};
	const isStaleArrayField = (name) => {
		if (!_state.actionArrayLengths.size) return false;
		const segments = isKey(name) ? [name] : stringToPath(name);
		let node = _formValues;
		let path = "";
		let ownerDepth = -1;
		let ownerPreActionLength = 0;
		for (let i = 0; i < segments.length; i++) {
			if (isNullOrUndefined(node)) return false;
			const key = segments[i];
			path = path ? `${path}.${key}` : key;
			if (Array.isArray(node) && +key >= node.length) return ownerDepth === -1 ? false : i === ownerDepth ? +key < ownerPreActionLength : true;
			if (_state.actionArrayLengths.has(path)) {
				ownerDepth = i + 1;
				ownerPreActionLength = _state.actionArrayLengths.get(path);
			}
			node = node[key];
			if (isUndefined(node) && ownerDepth !== -1 && i > ownerDepth && +segments[ownerDepth] < ownerPreActionLength) return true;
		}
		return false;
	};
	const updateValidAndValue = (name, shouldSkipSetValueAs, value, ref) => {
		const field = get(_fields, name);
		if (field) {
			if (hasExplicitNullIntermediate(name) || isStaleArrayField(name)) return;
			const wasUnsetInFormValues = isUndefined(get(_formValues, name));
			const defaultValue = get(_formValues, name, isUndefined(value) ? get(_defaultValues, name) : value);
			const isEditedBeforeReady = !!ref && !_formState.isReady && isEdited(ref);
			if (isUndefined(defaultValue) || ref && ref.defaultChecked || isEditedBeforeReady || shouldSkipSetValueAs) {
				const fieldValue = shouldSkipSetValueAs ? defaultValue : getFieldValue(field._f);
				if (_isTracked("dirtyFields") && !deepEqual(get(_formValues, name), fieldValue)) _dirtyFieldsStale = true;
				set(_formValues, name, fieldValue);
				if (isEditedBeforeReady) updateTouchAndDirty(name, fieldValue);
			} else setFieldValue(name, defaultValue);
			if (_state.mount && !_state.action) {
				if (_options.resolver && _isTracked("isValidating", "validatingFields")) Promise.resolve().then(() => _setValid());
				else _setValid();
				if (wasUnsetInFormValues && _formState.isDirty && _isTracked("isDirty")) {
					if (!_getDirty()) {
						_formState.isDirty = false;
						_subjects.state.next({ ..._formState });
					}
				}
				if (_options.shouldUnregister && wasUnsetInFormValues && !isUndefined(get(_formValues, name)) && isWatched(name, _names)) _state.watch = true;
			}
		}
	};
	const updateTouchAndDirty = (name, fieldValue, isBlurEvent, shouldDirty, shouldRender) => {
		let shouldUpdateField = false;
		let isPreviousDirty = false;
		const output = { name };
		if (!_options.disabled || shouldDirty === true) {
			if (!isBlurEvent || shouldDirty) {
				const isCurrentFieldPristine = deepEqual(get(_defaultValues, name), fieldValue);
				if (_isTracked("isDirty")) {
					isPreviousDirty = _formState.isDirty;
					_formState.isDirty = output.isDirty = !isCurrentFieldPristine || _getDirty();
					shouldUpdateField = isPreviousDirty !== output.isDirty;
				}
				isPreviousDirty = !!get(_formState.dirtyFields, name);
				if (isCurrentFieldPristine) unset(_formState.dirtyFields, name);
				else {
					const defaultFieldValue = get(_defaultValues, name);
					const field = get(_fields, name);
					const dirtyValue = !(field && field._f) && (isObject(defaultFieldValue) || Array.isArray(defaultFieldValue)) ? getDirtyFields(defaultFieldValue, fieldValue, void 0, field) : true;
					set(_formState.dirtyFields, name, dirtyValue);
				}
				let didResyncDirtyFields = false;
				if (_dirtyFieldsStale || isCurrentFieldPristine && (_isTracked("isDirty") ? _formState.isDirty : _getDirty())) {
					_dirtyFieldsStale = false;
					const nextDirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
					if (!deepEqual(_formState.dirtyFields, nextDirtyFields)) {
						didResyncDirtyFields = true;
						replaceDirtyFieldsInPlace(_formState.dirtyFields, nextDirtyFields);
					}
				}
				output.dirtyFields = _formState.dirtyFields;
				shouldUpdateField = shouldUpdateField || _isTracked("dirtyFields") && (didResyncDirtyFields || isPreviousDirty !== !isCurrentFieldPristine);
			}
			if (isBlurEvent) {
				const isPreviousFieldTouched = has(_formState.touchedFields, name) ? get(_formState.touchedFields, name) : void 0;
				if (!isPreviousFieldTouched) {
					set(_formState.touchedFields, name, isBlurEvent);
					output.touchedFields = _formState.touchedFields;
					shouldUpdateField = shouldUpdateField || _isTracked("touchedFields") && isPreviousFieldTouched !== isBlurEvent;
				}
			}
			shouldUpdateField && shouldRender && _subjects.state.next(output);
		}
		return shouldUpdateField ? output : {};
	};
	const shouldRenderByError = (name, isValid, error, fieldState) => {
		const previousFieldError = get(_formState.errors, name);
		const shouldUpdateValid = _isTracked("isValid") && isBoolean(isValid) && _formState.isValid !== isValid;
		if (_options.delayError && error) {
			delayErrorCallbacks[name] = debounce(name, () => updateErrors(name, error));
			delayErrorCallbacks[name](_options.delayError);
		} else {
			cancelDelayedError(name);
			error ? set(_formState.errors, name, error) : unset(_formState.errors, name);
			_formState.errors = { ..._formState.errors };
		}
		if ((error ? !deepEqual(previousFieldError, error, true) : previousFieldError) || !isEmptyObject(fieldState) || shouldUpdateValid) {
			const updatedFormState = {
				...fieldState,
				...shouldUpdateValid && isBoolean(isValid) ? { isValid } : {},
				errors: _formState.errors,
				name
			};
			_subjects.state.next(updatedFormState);
		}
	};
	const _runSchema = async (name) => {
		_updateIsValidating(name, true);
		return await _options.resolver(_formValues, _options.context, getResolverOptions(name || _names.mount, _fields, _options.criteriaMode, _options.shouldUseNativeValidation));
	};
	const executeSchemaAndUpdateState = async (names) => {
		const resetCallId = _resetCallId;
		const { errors } = await _runSchema(names);
		if (resetCallId !== _resetCallId) return errors;
		_updateIsValidating(names);
		if (names) {
			for (const name of names) {
				const error = get(errors, name);
				cancelDelayedErrorTree(name);
				const isFieldArrayRootError = _names.array.has(name) && isObject(error) && !Object.keys(error).some((key) => !Number.isNaN(Number(key)));
				const field = get(_fields, name);
				const hasNestedFields = isObject(field) && Object.keys(field).some((key) => key !== "_f");
				isFieldArrayRootError ? updateFieldArrayRootError(_formState.errors, { [name]: error }, name) : error && (error.type || error.message) || Array.isArray(error) || isObject(error) && hasNestedFields ? set(_formState.errors, name, error) : unset(_formState.errors, name);
			}
			_formState.errors = { ..._formState.errors };
		} else {
			Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
			_formState.errors = errors;
		}
		return errors;
	};
	const validateForm = async ({ name, eventType }) => {
		if (_options.validate) {
			const resetCallId = _resetCallId;
			const result = await _options.validate({
				formValues: _formValues,
				formState: _formState,
				name,
				eventType
			});
			if (resetCallId !== _resetCallId) return true;
			if (isObject(result)) {
				let isValid = true;
				clearErrors(FORM_ERROR_TYPE);
				for (const key in result) {
					const error = result[key];
					if (error) {
						isValid = false;
						setError(`${FORM_ERROR_TYPE}.${key}`, {
							message: isString(error.message) ? error.message : "",
							type: error.type || INPUT_VALIDATION_RULES.validate
						});
					}
				}
				return isValid;
			} else if (isString(result) || !result) {
				setError(FORM_ERROR_TYPE, {
					message: result || "",
					type: INPUT_VALIDATION_RULES.validate
				});
				return false;
			} else {
				clearErrors(FORM_ERROR_TYPE);
				return true;
			}
		}
		return true;
	};
	const executeBuiltInValidation = async ({ fields, onlyCheckValid, name, eventType, context = {
		valid: true,
		runRootValidation: false
	} }) => {
		const resetCallId = _resetCallId;
		if (_options.validate && !context.runRootValidation) {
			context.runRootValidation = true;
			if (!await validateForm({
				name,
				eventType
			})) {
				context.valid = false;
				if (onlyCheckValid) return context.valid;
			}
		}
		for (const name in fields) {
			const field = fields[name];
			if (field) {
				const { _f, ...fieldValue } = field;
				if (_f) {
					const isFieldArrayRoot = _names.array.has(_f.name);
					const isPromiseFunction = field._f && hasPromiseValidation(field._f);
					const shouldTrackIsValidatingState = _isTracked("isValidating", "validatingFields");
					if (isPromiseFunction && shouldTrackIsValidatingState) _updateIsValidating([_f.name], true);
					const fieldError = await validateField(field, _names.disabled, _formValues, shouldDisplayAllAssociatedErrors, _options.shouldUseNativeValidation && !onlyCheckValid, isFieldArrayRoot);
					if (resetCallId !== _resetCallId) return context.valid;
					if (isPromiseFunction && shouldTrackIsValidatingState) _updateIsValidating([_f.name]);
					if (fieldError[_f.name]) {
						context.valid = false;
						if (onlyCheckValid) break;
					}
					if (!onlyCheckValid) {
						cancelDelayedError(_f.name);
						get(fieldError, _f.name) ? isFieldArrayRoot ? updateFieldArrayRootError(_formState.errors, fieldError, _f.name) : set(_formState.errors, _f.name, fieldError[_f.name]) : unset(_formState.errors, _f.name);
					}
					if (_options.shouldUseNativeValidation && fieldError[_f.name]) break;
				}
				!isEmptyObject(fieldValue) && await executeBuiltInValidation({
					context,
					onlyCheckValid,
					fields: fieldValue,
					name,
					eventType
				});
			}
		}
		return context.valid;
	};
	const _removeUnmounted = () => {
		for (const name of _names.unMount) {
			const field = get(_fields, name);
			field && (field._f.refs ? field._f.refs.every((ref) => !live(ref)) : !live(field._f.ref)) && unregister(name);
		}
		_names.unMount = /* @__PURE__ */ new Set();
	};
	const _getDirty = (name, data) => (name && data && set(_formValues, name, data), !deepEqual(_state.mount ? _formValues : _defaultValues, _defaultValues));
	const _getWatch = (names, defaultValue, isGlobal) => {
		const values = _state.mount ? _formValues : isUndefined(defaultValue) || !isUndefined(names) ? _defaultValues : defaultValue;
		return generateWatchOutput(names, _names, isUndefined(names) ? { ...values } : values, isGlobal, defaultValue);
	};
	const _getFieldArray = (name) => compact(get(_state.mount ? _formValues : _defaultValues, name, _options.shouldUnregister ? get(_defaultValues, name, []) : []));
	const setFieldValue = (name, value, options = {}, skipClone = false, skipRender = false, skipValueRender = false) => {
		const field = get(_fields, name);
		let fieldValue = value;
		if (field) {
			const fieldReference = field._f;
			if (fieldReference) {
				!fieldReference.disabled && set(_formValues, name, getFieldValueAs(value, fieldReference));
				fieldValue = isHTMLElement(fieldReference.ref) && isNullOrUndefined(value) ? "" : value;
				if (isMultipleSelect(fieldReference.ref)) [...fieldReference.ref.options].forEach((optionRef) => optionRef.selected = fieldValue.includes(optionRef.value));
				else if (fieldReference.refs) {
					if (isCheckBoxInput(fieldReference.ref)) fieldReference.refs.forEach((checkboxRef) => {
						if (!checkboxRef.defaultChecked || !checkboxRef.disabled) {
							if (Array.isArray(fieldValue)) checkboxRef.checked = !!fieldValue.find((data) => data === checkboxRef.value);
							else checkboxRef.checked = fieldValue === checkboxRef.value || !!fieldValue;
						}
					});
					else fieldReference.refs.forEach((radioRef) => radioRef.checked = radioRef.value === fieldValue);
				} else if (isFileInput(fieldReference.ref)) fieldReference.ref.value = "";
				else {
					fieldReference.ref.value = fieldValue;
					if (!fieldReference.ref.type && !skipRender && !skipValueRender) _subjects.state.next({
						name,
						values: skipClone ? _formValues : _hasValuesSubscriber(name) ? cloneObject(_formValues) : void 0
					});
				}
			}
		}
		(options.shouldDirty || options.shouldTouch) && updateTouchAndDirty(name, field && field._f && !field._f.disabled && (field._f.valueAsNumber || field._f.valueAsDate || field._f.setValueAs) ? getFieldValueAs(value, field._f) : fieldValue, options.shouldTouch, options.shouldDirty, !skipRender);
		options.shouldValidate && trigger(name, { delayError: options.delayError });
		if (options.shouldValidate && field && field._f && field._f.deps && (!Array.isArray(field._f.deps) || field._f.deps.length > 0)) trigger(field._f.deps);
	};
	const setFieldValues = (name, value, options, skipClone = false, skipRender = false, skipValueRender = false) => {
		if (_names.array.has(name)) _subjects.array.next({
			name,
			values: skipClone ? _formValues : cloneObject(_formValues)
		});
		for (const fieldKey in value) {
			if (!value.hasOwnProperty(fieldKey)) continue;
			const fieldValue = value[fieldKey];
			const fieldName = name + "." + fieldKey;
			const field = get(_fields, fieldName);
			(_names.array.has(name) || isObject(fieldValue) || field && !field._f) && !isDateObject(fieldValue) ? setFieldValues(fieldName, fieldValue, options, skipClone, skipRender, skipValueRender) : setFieldValue(fieldName, fieldValue, options, skipClone, skipRender, skipValueRender);
		}
	};
	const _setValue = (name, value, options, skipClone, skipStateEmit = false) => {
		const field = get(_fields, name);
		const isFieldArray = _names.array.has(name);
		const cloneValue = skipClone ? value : cloneObject(value);
		const isValueUnchanged = deepEqual(get(_formValues, name), cloneValue);
		if (!isValueUnchanged) set(_formValues, name, cloneValue);
		if (isFieldArray) {
			_subjects.array.next({
				name,
				values: skipClone ? _formValues : cloneObject(_formValues)
			});
			if (_isTracked("isDirty", "dirtyFields") && options.shouldDirty) {
				_updateDirtyFields();
				if (!skipStateEmit) _subjects.state.next({
					name,
					dirtyFields: _formState.dirtyFields,
					isDirty: _getDirty(name, cloneValue)
				});
			}
			options.shouldValidate && trigger(name, { delayError: options.delayError });
		} else {
			const isEmpty = Array.isArray(cloneValue) && !cloneValue.length || isEmptyObject(cloneValue);
			const skipValueRender = !isValueUnchanged && !skipStateEmit;
			if (!field || field._f || isNullOrUndefined(cloneValue) || isEmpty) setFieldValue(name, cloneValue, options, skipClone, skipStateEmit, skipValueRender);
			else setFieldValues(name, cloneValue, options, skipClone, skipStateEmit, skipValueRender);
		}
		if (!isValueUnchanged && !skipStateEmit) {
			const watched = isWatched(name, _names);
			const emittedName = _state.mount || watched ? name : void 0;
			const fieldArrayItemNames = isFieldArray ? [] : getFieldArrayItemNames(_names.array, name);
			const values = skipClone ? _formValues : _hasValuesSubscriber(emittedName) || fieldArrayItemNames.some(_hasValuesSubscriber) ? cloneObject(_formValues) : void 0;
			_subjects.state.next({
				...watched && _formState,
				name: emittedName,
				values
			});
			for (const itemName of fieldArrayItemNames) _subjects.state.next({
				name: itemName,
				values
			});
		}
	};
	const setValue = (name, value, options = {}) => _setValue(name, value, options, false);
	const setValues = (formValues, options = {}) => {
		const updatedFormValues = isFunction(formValues) ? formValues(_formValues) : formValues;
		if (!deepEqual(_formValues, updatedFormValues)) {
			_formValues = {
				..._formValues,
				...updatedFormValues
			};
			for (const fieldName of _names.mount) if (has(updatedFormValues, fieldName)) _setValue(fieldName, get(updatedFormValues, fieldName), options, true, true);
			_subjects.state.next({
				..._formState,
				name: void 0,
				type: void 0,
				..._valuesSubscribers.size ? { values: _formValues } : {}
			});
			if (options.shouldValidate) _setValid();
		}
	};
	const onChange = async (event) => {
		_state.mount = true;
		const target = event.target;
		let name = target.name;
		let isFieldValueUpdated = true;
		const field = get(_fields, name);
		const _updateIsFieldValueUpdated = (fieldValue) => {
			isFieldValueUpdated = Number.isNaN(fieldValue) || isDateObject(fieldValue) && isNaN(fieldValue.getTime()) || deepEqual(fieldValue, get(_formValues, name, fieldValue));
		};
		if (field) {
			let error;
			let isValid;
			const fieldValue = target.type ? getFieldValue(field._f) : getEventValue(event);
			const isBlurEvent = event.type === EVENTS.BLUR || event.type === EVENTS.FOCUS_OUT;
			const hasNoValidationEffect = !hasValidation(field._f) && !_options.validate && !_options.resolver && !get(_formState.errors, name) && !field._f.deps;
			const shouldSkipValidation = hasNoValidationEffect || skipValidation(isBlurEvent, get(_formState.touchedFields, name), _formState.isSubmitted, _validationModeAfterSubmit, _validationModeBeforeSubmit);
			const watched = isWatched(name, _names, isBlurEvent);
			set(_formValues, name, cloneObject(fieldValue));
			if (isBlurEvent) {
				if (!target || !target.readOnly) {
					field._f.onBlur && field._f.onBlur(event);
					if (Object.prototype.hasOwnProperty.call(delayErrorCallbacks, name)) delayErrorCallbacks[name](0);
				}
			} else if (field._f.onChange) field._f.onChange(event);
			const fieldState = updateTouchAndDirty(name, fieldValue, isBlurEvent);
			const shouldRender = !isEmptyObject(fieldState) || watched;
			!isBlurEvent && _subjects.state.next({
				name,
				type: event.type,
				..._hasValuesSubscriber(name) ? { values: cloneObject(_formValues) } : {}
			});
			if (shouldSkipValidation) {
				if ((!hasNoValidationEffect || !_formState.isValid) && _isTracked("isValid")) {
					if (_options.mode === "onBlur") {
						if (isBlurEvent) _setValid();
					} else if (!isBlurEvent) _setValid();
				}
				return shouldRender && _subjects.state.next({
					name,
					...watched ? {} : fieldState
				});
			}
			if (!_options.resolver && _options.validate) await validateForm({
				name,
				eventType: event.type
			});
			!isBlurEvent && watched && _subjects.state.next({ ..._formState });
			if (_options.resolver) {
				const resetCallId = _resetCallId;
				const { errors } = await _runSchema([name]);
				if (resetCallId !== _resetCallId) return;
				_updateIsValidating([name]);
				_updateIsFieldValueUpdated(fieldValue);
				if (!isFieldValueUpdated) {
					!isEmptyObject(fieldState) && _subjects.state.next(fieldState);
					return;
				}
				const previousErrorLookupResult = schemaErrorLookup(_formState.errors, _fields, name);
				const errorLookupResult = schemaErrorLookup(errors, _fields, previousErrorLookupResult.name || name);
				error = errorLookupResult.error;
				name = errorLookupResult.name;
				isValid = isEmptyObject(errors);
			} else {
				const resetCallId = _resetCallId;
				_updateIsValidating([name], true);
				error = (await validateField(field, _names.disabled, _formValues, shouldDisplayAllAssociatedErrors, _options.shouldUseNativeValidation))[name];
				if (resetCallId !== _resetCallId) return;
				_updateIsValidating([name]);
				_updateIsFieldValueUpdated(fieldValue);
				if (isFieldValueUpdated) {
					if (error) isValid = false;
					else if (_isTracked("isValid")) {
						isValid = await executeBuiltInValidation({
							fields: _fields,
							onlyCheckValid: true,
							name,
							eventType: event.type
						});
						if (resetCallId !== _resetCallId) return;
					}
				}
			}
			if (isFieldValueUpdated) {
				field._f.deps && (!Array.isArray(field._f.deps) || field._f.deps.length > 0) && trigger(field._f.deps);
				shouldRenderByError(name, isValid, error, fieldState);
			}
		}
	};
	const _focusInput = (ref, key) => {
		if (get(_formState.errors, key) && ref.focus) {
			ref.focus();
			return 1;
		}
	};
	const trigger = async (name, options = {}) => {
		let isValid;
		let validationResult;
		const fieldNames = convertToArrayPayload(name);
		if (_options.resolver) {
			const resetCallId = _resetCallId;
			const errors = await executeSchemaAndUpdateState(isUndefined(name) ? name : fieldNames);
			isValid = isEmptyObject(errors);
			validationResult = name ? !fieldNames.some((name) => get(errors, name)) : isValid;
			if (resetCallId !== _resetCallId) return validationResult;
		} else if (name) {
			validationResult = (await Promise.all(fieldNames.map(async (fieldName) => {
				const field = get(_fields, fieldName);
				return await executeBuiltInValidation({
					fields: field && field._f ? { [fieldName]: field } : field,
					eventType: EVENTS.TRIGGER
				});
			}))).every(Boolean);
			(validationResult || _formState.isValid) && _setValid();
		} else validationResult = isValid = await executeBuiltInValidation({
			fields: _fields,
			name,
			eventType: EVENTS.TRIGGER
		});
		if (options.delayError && _options.delayError && isString(name)) {
			const error = get(_formState.errors, name);
			if (error) {
				unset(_formState.errors, name);
				delayErrorCallbacks[name] = debounce(name, () => updateErrors(name, error));
				delayErrorCallbacks[name](_options.delayError);
			} else cancelDelayedError(name);
		}
		if (options.shouldTouch) for (const fieldName of name ? fieldNames : _names.mount) !_names.array.has(fieldName) && set(_formState.touchedFields, fieldName, true);
		_formState.errors = { ..._formState.errors };
		_subjects.state.next({
			...!isString(name) || _isTracked("isValid") && isValid !== _formState.isValid ? {} : { name },
			..._options.resolver || !name ? { isValid } : {},
			...options.shouldTouch && _isTracked("touchedFields") ? { touchedFields: _formState.touchedFields } : {},
			errors: _formState.errors
		});
		options.shouldFocus && !validationResult && iterateFieldsByAction(_fields, _focusInput, name ? fieldNames : _names.mount);
		return validationResult;
	};
	const getValues = (fieldNames, config) => {
		let values = { ..._state.mount ? _formValues : _defaultValues };
		if (config) values = extractFormValues(config.dirtyFields ? _formState.dirtyFields : _formState.touchedFields, values);
		return isUndefined(fieldNames) ? values : isString(fieldNames) ? get(values, fieldNames) : fieldNames.map((name) => get(values, name));
	};
	const getErrors = (fieldNames) => isUndefined(fieldNames) ? { ..._formState.errors } : isString(fieldNames) ? get(_formState.errors, fieldNames) : fieldNames.map((name) => get(_formState.errors, name));
	const getFieldState = (name, formState) => {
		const targetFormState = formState || _formState;
		const error = get(targetFormState.errors, name);
		return {
			invalid: !!error,
			isDirty: !!get(targetFormState.dirtyFields, name),
			error,
			isValidating: !!get(targetFormState.validatingFields, name),
			isTouched: !!get(targetFormState.touchedFields, name)
		};
	};
	const clearErrors = (name) => {
		const names = name ? convertToArrayPayload(name) : void 0;
		if (names) names.forEach((inputName) => {
			cancelDelayedErrorTree(inputName);
			unset(_formState.errors, inputName);
			_formState.errors = { ..._formState.errors };
			_subjects.state.next({
				name: inputName,
				errors: _formState.errors
			});
		});
		else {
			Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
			_formState.errors = {};
			_subjects.state.next({ errors: _formState.errors });
		}
	};
	const setError = (name, error, options) => {
		cancelDelayedErrorTree(name);
		const ref = (get(_fields, name, { _f: {} })._f || {}).ref;
		const { ref: currentRef, message, type, types, ...restOfErrorTree } = get(_formState.errors, name) || {};
		set(_formState.errors, name, {
			...restOfErrorTree,
			...error,
			ref
		});
		_formState.errors = { ..._formState.errors };
		_subjects.state.next({
			name,
			errors: _formState.errors,
			isValid: false
		});
		options && options.shouldFocus && ref && ref.focus && ref.focus();
	};
	const watch = (name, defaultValue) => {
		if (isFunction(name)) {
			const valuesSubscriber = {};
			_valuesSubscribers.add(valuesSubscriber);
			const { unsubscribe } = _subjects.state.subscribe({ next: (payload) => "values" in payload && name(payload.values || _getWatch(void 0, defaultValue), payload) });
			return { unsubscribe: () => {
				_valuesSubscribers.delete(valuesSubscriber);
				unsubscribe();
			} };
		}
		return _getWatch(name, defaultValue, true);
	};
	const _subscribe = (props) => {
		const valuesSubscriber = {
			name: props.name,
			exact: props.exact
		};
		props.formState && props.formState.values && _valuesSubscribers.add(valuesSubscriber);
		const { unsubscribe } = _subjects.state.subscribe({ next: (formState) => {
			if (shouldSubscribeByName(props.name, formState.name, props.exact) && shouldRenderFormState(formState, props.formState || _proxyFormState, props.reRenderRoot)) {
				const values = formState.values || { ..._formValues };
				props.callback({
					..._formState,
					...formState,
					values,
					defaultValues: _defaultValues
				});
			}
		} });
		return () => {
			_valuesSubscribers.delete(valuesSubscriber);
			unsubscribe();
		};
	};
	const subscribe = (props) => {
		_state.mount = true;
		const trackedKeys = Object.keys(props.formState || {}).filter((key) => props.formState && props.formState[key]);
		for (const key of trackedKeys) _proxySubscribeFormState[key] = (_proxySubscribeFormState[key] || 0) + 1;
		const unsubscribe = _subscribe({
			...props,
			formState: {
				...defaultProxyFormState,
				...props.formState
			}
		});
		return () => {
			for (const key of trackedKeys.splice(0)) _proxySubscribeFormState[key]--;
			unsubscribe();
		};
	};
	const unregister = (name, options = {}) => {
		for (const fieldName of name ? convertToArrayPayload(name) : _names.mount) {
			_names.mount.delete(fieldName);
			_names.array.delete(fieldName);
			_names.disabled.delete(fieldName);
			if (!options.keepValue) {
				unset(_fields, fieldName);
				unset(_formValues, fieldName);
			}
			if (!options.keepError) {
				cancelDelayedErrorTree(fieldName);
				unset(_formState.errors, fieldName);
			}
			!options.keepDirty && unset(_formState.dirtyFields, fieldName);
			!options.keepTouched && unset(_formState.touchedFields, fieldName);
			!options.keepIsValidating && unset(_formState.validatingFields, fieldName);
			!_options.shouldUnregister && !options.keepDefaultValue && unset(_defaultValues, fieldName);
		}
		if (!options.keepError) _formState.errors = { ..._formState.errors };
		_valuesSubscribers.size && _subjects.state.next({ values: cloneObject(_formValues) });
		_subjects.state.next({
			..._formState,
			...options.keepDirty ? {} : { isDirty: _getDirty() },
			...options.keepIsValidating ? {} : { isValidating: !isEmptyObject(_formState.validatingFields) }
		});
		!options.keepIsValid && _setValid();
	};
	const _setDisabledField = ({ disabled, name }) => {
		if (isBoolean(disabled) && _state.mount || !!disabled || _names.disabled.has(name)) {
			const disabledStateChanged = _names.disabled.has(name) !== !!disabled;
			disabled ? _names.disabled.add(name) : _names.disabled.delete(name);
			disabledStateChanged && _state.mount && !_state.action && _setValid();
		}
	};
	const register = (name, options = {}) => {
		let field = get(_fields, name);
		const disabledIsDefined = isBoolean(options.disabled) || isBoolean(_options.disabled);
		const shouldRevalidateRemount = !_names.registerName.has(name) && field && field._f && !field._f.mount;
		set(_fields, name, {
			...field || {},
			_f: {
				...field && field._f ? field._f : { ref: { name } },
				name,
				mount: true,
				...options
			}
		});
		_names.mount.add(name);
		if (field && field._f) {
			const nextField = get(_fields, name);
			for (const rule of REGISTER_VALIDATION_RULES) if (!(rule in options)) delete nextField._f[rule];
		}
		if (field && !shouldRevalidateRemount) _setDisabledField({
			disabled: isBoolean(options.disabled) ? options.disabled : _options.disabled,
			name
		});
		else updateValidAndValue(name, true, options.value);
		return {
			...disabledIsDefined ? { disabled: options.disabled || _options.disabled } : {},
			..._options.progressive ? {
				required: !!options.required,
				min: getRuleValue(options.min),
				max: getRuleValue(options.max),
				minLength: getRuleValue(options.minLength),
				maxLength: getRuleValue(options.maxLength),
				pattern: getRuleValue(options.pattern)
			} : {},
			name,
			onChange,
			onBlur: onChange,
			ref: (ref) => {
				if (ref) {
					_names.registerName.add(name);
					register(name, options);
					_names.registerName.delete(name);
					field = get(_fields, name);
					const fieldRef = isUndefined(ref.value) ? ref.querySelectorAll ? ref.querySelectorAll("input,select,textarea")[0] || ref : ref : ref;
					const radioOrCheckbox = isRadioOrCheckbox(fieldRef);
					const refs = field._f.refs || [];
					if (radioOrCheckbox ? refs.find((option) => option === fieldRef) : fieldRef === field._f.ref) return;
					const newField = { ...field._f };
					if (radioOrCheckbox) {
						newField.refs = [
							...refs.filter(live),
							fieldRef,
							...Array.isArray(get(_defaultValues, name)) ? [{}] : []
						];
						newField.ref = {
							type: fieldRef.type,
							name
						};
					} else {
						newField.ref = fieldRef;
						delete newField.refs;
					}
					set(_fields, name, { _f: newField });
					updateValidAndValue(name, false, void 0, fieldRef);
				} else {
					field = get(_fields, name, {});
					if (field._f) field._f.mount = false;
					(_options.shouldUnregister || options.shouldUnregister) && !(isNameInFieldArray(_names.array, name) && _state.action) && _names.unMount.add(name);
				}
			}
		};
	};
	const _focusError = () => _options.shouldFocusError && !_options.shouldUseNativeValidation && iterateFieldsByAction(_fields, _focusInput, _names.mount);
	const _disableForm = (disabled) => {
		if (isBoolean(disabled)) {
			_subjects.state.next({ disabled });
			iterateFieldsByAction(_fields, (ref, name) => {
				const currentField = get(_fields, name);
				if (currentField) {
					ref.disabled = currentField._f.disabled || disabled;
					if (Array.isArray(currentField._f.refs)) currentField._f.refs.forEach((inputRef) => {
						inputRef.disabled = currentField._f.disabled || disabled;
					});
				}
			}, 0);
		}
	};
	const handleSubmit = (onValid, onInvalid) => async (e) => {
		let result = void 0;
		let onValidError = void 0;
		if (e) {
			e.preventDefault && e.preventDefault();
			e.persist && e.persist();
		}
		let fieldValues = cloneObject(_formValues);
		_subjects.state.next({ isSubmitting: true });
		if (_options.resolver) {
			const resetCallId = _resetCallId;
			const { errors, values } = await _runSchema();
			if (resetCallId !== _resetCallId) return;
			_updateIsValidating();
			Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
			_formState.errors = errors;
			fieldValues = cloneObject(values);
		} else {
			const resetCallId = _resetCallId;
			await executeBuiltInValidation({
				fields: _fields,
				eventType: EVENTS.SUBMIT
			});
			if (resetCallId !== _resetCallId) return;
			unset(_formState.errors, ROOT_ERROR_TYPE);
			_formState.errors = { ..._formState.errors };
		}
		if (_names.disabled.size) for (const name of _names.disabled) unset(fieldValues, name);
		if (isEmptyObject(_formState.errors)) {
			_subjects.state.next({ errors: {} });
			try {
				result = await onValid(fieldValues, e);
			} catch (error) {
				onValidError = error;
			}
		} else {
			if (onInvalid) await onInvalid({ ..._formState.errors }, e);
			_focusError();
			setTimeout(_focusError);
		}
		_subjects.state.next({
			isSubmitted: true,
			isSubmitting: false,
			isSubmitSuccessful: isEmptyObject(_formState.errors) && !onValidError,
			submitCount: _formState.submitCount + 1,
			errors: _formState.errors
		});
		if (onValidError) throw onValidError;
		return result;
	};
	const resetField = (name, options = {}) => {
		if (get(_fields, name)) {
			unset(_formState.validatingFields, name);
			if (isUndefined(options.defaultValue)) setValue(name, cloneObject(get(_defaultValues, name)));
			else {
				setValue(name, options.defaultValue);
				set(_defaultValues, name, cloneObject(options.defaultValue));
			}
			if (!options.keepTouched) unset(_formState.touchedFields, name);
			if (!options.keepDirty) {
				unset(_formState.dirtyFields, name);
				_formState.isDirty = options.defaultValue ? _getDirty(name, cloneObject(get(_defaultValues, name))) : _getDirty();
			}
			if (!options.keepError) {
				cancelDelayedErrorTree(name);
				unset(_formState.errors, name);
				_formState.errors = { ..._formState.errors };
				_setValid();
			}
			_subjects.state.next({
				..._formState,
				isValidating: !isEmptyObject(_formState.validatingFields)
			});
		}
	};
	const _reset = (formValues, keepStateOptions = {}) => {
		_resetCallId++;
		const updatedValues = formValues ? cloneObject(formValues) : _defaultValues;
		const cloneUpdatedValues = cloneObject(updatedValues);
		const isEmptyResetValues = isEmptyObject(formValues);
		const values = cloneUpdatedValues;
		const fieldRefs = _fields;
		Object.keys(delayErrorCallbacks).forEach(cancelDelayedError);
		if (!keepStateOptions.keepDefaultValues) _defaultValues = updatedValues;
		if (!keepStateOptions.keepValues) {
			if (keepStateOptions.keepDirtyValues) {
				const fieldsToCheck = /* @__PURE__ */ new Set([..._names.mount, ...collectDirtyFieldNames(getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs), _formState.dirtyFields)]);
				for (const fieldName of fieldsToCheck) {
					const isDirty = get(_formState.dirtyFields, fieldName);
					const existingValue = get(_formValues, fieldName);
					const newValue = get(values, fieldName);
					if (isDirty && !isUndefined(existingValue)) set(values, fieldName, existingValue);
					else if (!isDirty && !isUndefined(newValue)) setValue(fieldName, newValue);
				}
			} else {
				if (isWeb && isUndefined(formValues)) for (const name of _names.mount) {
					const field = get(_fields, name);
					if (field && field._f) {
						const fieldReference = Array.isArray(field._f.refs) ? field._f.refs[0] : field._f.ref;
						if (isHTMLElement(fieldReference)) {
							const form = fieldReference.closest("form");
							if (form) {
								form.reset();
								break;
							}
						}
					}
				}
				if (keepStateOptions.keepFieldsRef) for (const fieldName of _names.mount) setValue(fieldName, get(values, fieldName));
				else _fields = {};
			}
			if (_options.shouldUnregister) {
				_formValues = keepStateOptions.keepDefaultValues ? cloneObject(_defaultValues) : {};
				if (keepStateOptions.keepFieldsRef) for (const fieldName of _names.mount) set(_formValues, fieldName, get(values, fieldName));
			} else _formValues = cloneObject(values);
			_subjects.array.next({ values: { ...values } });
			_subjects.state.next({
				name: void 0,
				type: void 0,
				values: { ...values }
			});
		}
		_names = {
			mount: keepStateOptions.keepDirtyValues ? _names.mount : /* @__PURE__ */ new Set(),
			unMount: /* @__PURE__ */ new Set(),
			array: /* @__PURE__ */ new Set(),
			registerName: /* @__PURE__ */ new Set(),
			disabled: /* @__PURE__ */ new Set(),
			watch: /* @__PURE__ */ new Set(),
			watchAll: false,
			focus: ""
		};
		_state.mount = !_proxyFormState.isValid || !!keepStateOptions.keepIsValid || !!keepStateOptions.keepDirtyValues || !_options.shouldUnregister && !isEmptyObject(values);
		_state.watch = !!_options.shouldUnregister;
		_state.keepIsValid = !!keepStateOptions.keepIsValid;
		_state.action = false;
		_state.actionArrayLengths.clear();
		_dirtyFieldsStale = false;
		if (!keepStateOptions.keepErrors) _formState.errors = {};
		_subjects.state.next({
			submitCount: keepStateOptions.keepSubmitCount ? _formState.submitCount : 0,
			isDirty: isEmptyResetValues ? false : keepStateOptions.keepDirty ? _formState.isDirty : keepStateOptions.keepValues ? _getDirty() : !!(keepStateOptions.keepDefaultValues && formValues && !deepEqual(formValues, _defaultValues)),
			isSubmitted: keepStateOptions.keepIsSubmitted ? _formState.isSubmitted : false,
			dirtyFields: isEmptyResetValues ? {} : keepStateOptions.keepDirtyValues ? keepStateOptions.keepDefaultValues && _formValues ? getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs) : _formState.dirtyFields : keepStateOptions.keepDefaultValues && formValues ? getDirtyFields(_defaultValues, formValues, void 0, fieldRefs) : keepStateOptions.keepDirty ? _formState.dirtyFields : keepStateOptions.keepValues ? getDirtyFields(_defaultValues, _formValues, void 0, fieldRefs) : {},
			touchedFields: keepStateOptions.keepTouched ? _formState.touchedFields : {},
			...!keepStateOptions.keepIsValidating && (_formState.isValidating || !isEmptyObject(_formState.validatingFields)) ? {
				validatingFields: {},
				isValidating: false
			} : null,
			errors: keepStateOptions.keepErrors ? _formState.errors : {},
			isSubmitSuccessful: keepStateOptions.keepIsSubmitSuccessful ? _formState.isSubmitSuccessful : false,
			isSubmitting: false,
			defaultValues: _defaultValues
		});
	};
	const reset = (formValues, keepStateOptions) => _reset(isFunction(formValues) ? formValues(_formValues) : formValues, {
		..._options.resetOptions,
		...keepStateOptions
	});
	const setFocus = (name, options = {}) => {
		const field = get(_fields, name);
		const fieldReference = field && field._f;
		if (fieldReference) {
			const fieldRef = fieldReference.refs ? fieldReference.refs[0] : fieldReference.ref;
			if (fieldRef.focus) setTimeout(() => {
				fieldRef.focus();
				options.shouldSelect && isFunction(fieldRef.select) && fieldRef.select();
			});
		}
	};
	const _setFormState = (updatedFormState) => {
		const { name, type, values, ...formState } = updatedFormState;
		if (Object.keys(formState).length) _formState = {
			..._formState,
			...formState
		};
	};
	_subjects.state.subscribe({ next: _setFormState });
	const _resetDefaultValues = () => isFunction(_options.defaultValues) && _options.defaultValues().then((values) => {
		reset(values, _options.resetOptions);
		_subjects.state.next({ isLoading: false });
	});
	const resetDefaultValues = (values, options = {}) => {
		_defaultValues = cloneObject(values);
		if (!options.keepDirty) {
			const newDirtyFields = getDirtyFields(_defaultValues, _formValues, void 0, _fields);
			_formState.dirtyFields = newDirtyFields;
			_formState.isDirty = !isEmptyObject(newDirtyFields);
		}
		if (!options.keepIsValid) _setValid();
		_subjects.state.next({
			..._formState,
			defaultValues: _defaultValues
		});
	};
	const methods = {
		control: {
			register,
			unregister,
			getFieldState,
			handleSubmit,
			setError,
			_subscribe,
			_runSchema,
			_updateIsValidating,
			_focusError,
			_getWatch,
			_getDirty,
			_setValid,
			_setFieldArray,
			_setDisabledField,
			_setErrors,
			_getFieldArray,
			_reset,
			_resetDefaultValues,
			_removeUnmounted,
			_disableForm,
			_subjects,
			_proxyFormState,
			get _fields() {
				return _fields;
			},
			get _formValues() {
				return _formValues;
			},
			get _state() {
				return _state;
			},
			set _state(value) {
				_state = value;
			},
			get _defaultValues() {
				return _defaultValues;
			},
			get _names() {
				return _names;
			},
			set _names(value) {
				_names = value;
			},
			get _formState() {
				return _formState;
			},
			get _options() {
				return _options;
			},
			set _options(value) {
				_options = {
					..._options,
					...value
				};
				_validationModeBeforeSubmit = getValidationModes(_options.mode);
				_validationModeAfterSubmit = getValidationModes(_options.reValidateMode);
				shouldDisplayAllAssociatedErrors = _options.criteriaMode === VALIDATION_MODE.all;
			}
		},
		subscribe,
		trigger,
		register,
		handleSubmit,
		watch,
		setValue,
		setValues,
		getValues,
		getErrors,
		reset,
		resetField,
		resetDefaultValues,
		clearErrors,
		unregister,
		setError,
		setFocus,
		getFieldState
	};
	return {
		...methods,
		formControl: methods
	};
}
var RESET_OPTIONS = {
	mode: defaultOptions.mode,
	reValidateMode: defaultOptions.reValidateMode,
	shouldFocusError: defaultOptions.shouldFocusError,
	resolver: void 0,
	criteriaMode: void 0,
	delayError: void 0,
	shouldUnregister: void 0,
	shouldUseNativeValidation: void 0,
	context: void 0
};
/**
* Core hook for managing a form. Returns all methods and state for
* registration, validation, and submission.
*
* @see [API](https://react-hook-form.com/docs/useform)
*
* @example
* ```tsx
* const { register, handleSubmit, formState: { errors } } = useForm<FormValues>();
* <form onSubmit={handleSubmit(onSubmit)}>
*   <input {...register("email", { required: true })} />
* </form>
* ```
*/
function useForm(props = {}) {
	const _formControl = import_react.useRef(void 0);
	const _values = import_react.useRef(void 0);
	const _formControlProp = import_react.useRef(props.formControl);
	const _hadValidate = import_react.useRef(!!props.validate);
	const [formState, updateFormState] = import_react.useState(() => ({
		...cloneObject(DEFAULT_FORM_STATE),
		isLoading: isFunction(props.defaultValues),
		errors: props.errors || {},
		disabled: props.disabled || false,
		defaultValues: isFunction(props.defaultValues) ? void 0 : props.defaultValues
	}));
	if (!_formControl.current || props.formControl && _formControlProp.current !== props.formControl) {
		_formControlProp.current = props.formControl;
		if (props.formControl) {
			_formControl.current = {
				...props.formControl,
				formState
			};
			if (props.defaultValues && !isFunction(props.defaultValues)) props.formControl.reset(props.defaultValues, props.resetOptions);
		} else {
			const { formControl, ...rest } = createFormControl(props);
			_formControl.current = {
				...rest,
				formState
			};
		}
	}
	const control = _formControl.current.control;
	const previousOptions = control._options;
	const removedOptions = {};
	for (const key in RESET_OPTIONS) if (key in previousOptions && !(key in props)) removedOptions[key] = RESET_OPTIONS[key];
	control._options = {
		...removedOptions,
		...props,
		validate: props.validate
	};
	const getCurrentFormState = () => ({
		...control._formState,
		defaultValues: control._defaultValues
	});
	const { resyncIfNeeded, snapshot } = useResyncOnReconnect(getCurrentFormState);
	useIsomorphicLayoutEffect(() => {
		resyncIfNeeded(true, getCurrentFormState, updateFormState);
		const unsubscribe = control._subscribe({
			formState: control._proxyFormState,
			callback: () => updateFormState({
				...control._formState,
				defaultValues: control._defaultValues
			}),
			reRenderRoot: true
		});
		updateFormState((data) => ({
			...data,
			isReady: true
		}));
		control._formState.isReady = true;
		return () => {
			unsubscribe();
			snapshot(true, getCurrentFormState);
		};
	}, [
		control,
		resyncIfNeeded,
		snapshot
	]);
	import_react.useEffect(() => control._disableForm(props.disabled), [control, props.disabled]);
	import_react.useEffect(() => {
		if (props.mode) control._options.mode = props.mode;
		if (props.reValidateMode) control._options.reValidateMode = props.reValidateMode;
	}, [
		control,
		props.mode,
		props.reValidateMode
	]);
	import_react.useEffect(() => {
		if (props.errors) {
			control._setErrors(props.errors);
			control._focusError();
		}
	}, [control, props.errors]);
	import_react.useEffect(() => {
		if (_hadValidate.current && !props.validate) _formControl.current && _formControl.current.clearErrors(FORM_ERROR_TYPE);
		_hadValidate.current = !!props.validate;
	}, [props.validate]);
	import_react.useEffect(() => {
		props.shouldUnregister && control._subjects.state.next({ values: control._getWatch() });
	}, [control, props.shouldUnregister]);
	import_react.useEffect(() => {
		if (control._proxyFormState.isDirty) {
			const isDirty = control._getDirty();
			if (isDirty !== formState.isDirty) control._subjects.state.next({ isDirty });
		}
	}, [control, formState.isDirty]);
	import_react.useEffect(() => {
		if (props.values && !deepEqual(props.values, _values.current)) {
			control._reset(props.values, {
				keepFieldsRef: true,
				...control._options.resetOptions
			});
			if (!(control._options.resetOptions && control._options.resetOptions.keepIsValid)) control._setValid();
			_values.current = props.values;
			updateFormState((state) => ({ ...state }));
		} else control._resetDefaultValues();
	}, [control, props.values]);
	import_react.useEffect(() => {
		if (!control._state.mount) {
			control._setValid();
			control._state.mount = true;
		}
		if (control._state.watch) {
			control._state.watch = false;
			control._subjects.state.next({ ...control._formState });
		}
		control._removeUnmounted();
	});
	_formControl.current.formState = import_react.useMemo(() => getProxyFormState(formState, control), [control, formState]);
	return _formControl.current;
}
/**
* Component wrapper around `useWatch`. Re-renders only when watched fields change.
*
* @see [API](https://react-hook-form.com/docs/usewatch)
*
* @example
* ```tsx
* <Watch
*   control={control}
*   names={["foo", "bar"]}
*   render={([foo, bar]) => <span>{foo} {bar}</span>}
* />
* ```
*/
var Watch = (props) => props.render(useWatch({
	name: props.names,
	...props
}));
export { Controller, ErrorMessage, FieldArray, Form, FormProvider, FormState, FormStateSubscribe, Watch, appendErrors, createFormControl, get, set, useController, useFieldArray, useForm, useFormContext, useFormState, useWatch };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVhY3QtaG9vay1mb3JtLmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uL3JlYWN0LWhvb2stZm9ybS9kaXN0L2luZGV4LmVzbS5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcblxudmFyIGlzQ2hlY2tCb3hJbnB1dCA9IChlbGVtZW50KSA9PiBlbGVtZW50LnR5cGUgPT09ICdjaGVja2JveCc7XG5cbnZhciBpc0ZpbGVJbnB1dCA9IChlbGVtZW50KSA9PiBlbGVtZW50LnR5cGUgPT09ICdmaWxlJztcblxudmFyIGlzRGF0ZU9iamVjdCA9ICh2YWx1ZSkgPT4gdmFsdWUgaW5zdGFuY2VvZiBEYXRlO1xuXG52YXIgaXNOdWxsT3JVbmRlZmluZWQgPSAodmFsdWUpID0+IHZhbHVlID09IG51bGw7XG5cbmNvbnN0IGlzT2JqZWN0VHlwZSA9ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JztcbnZhciBpc09iamVjdCA9ICh2YWx1ZSkgPT4gIWlzTnVsbE9yVW5kZWZpbmVkKHZhbHVlKSAmJlxuICAgICFBcnJheS5pc0FycmF5KHZhbHVlKSAmJlxuICAgIGlzT2JqZWN0VHlwZSh2YWx1ZSkgJiZcbiAgICAhaXNEYXRlT2JqZWN0KHZhbHVlKTtcblxudmFyIGdldEV2ZW50VmFsdWUgPSAoZXZlbnQpID0+IGlzT2JqZWN0KGV2ZW50KSAmJiBldmVudC50YXJnZXRcbiAgICA/IGlzQ2hlY2tCb3hJbnB1dChldmVudC50YXJnZXQpXG4gICAgICAgID8gZXZlbnQudGFyZ2V0LmNoZWNrZWRcbiAgICAgICAgOiBpc0ZpbGVJbnB1dChldmVudC50YXJnZXQpXG4gICAgICAgICAgICA/IGV2ZW50LnRhcmdldC5maWxlc1xuICAgICAgICAgICAgOiBldmVudC50YXJnZXQudmFsdWVcbiAgICA6IGV2ZW50O1xuXG5jb25zdCBGSUVMRF9QQVRIX1JFID0gL1suW1xcXSdcIl0vO1xudmFyIHN0cmluZ1RvUGF0aCA9IChpbnB1dCkgPT4gaW5wdXQuc3BsaXQoRklFTERfUEFUSF9SRSkuZmlsdGVyKEJvb2xlYW4pO1xuXG5mdW5jdGlvbiBnZXROdWxsQW5jZXN0b3JWYWx1ZShjb250cm9sLCBuYW1lKSB7XG4gICAgY29uc3Qgc2VnbWVudHMgPSBzdHJpbmdUb1BhdGgobmFtZSk7XG4gICAgbGV0IGZvcm1WYWx1ZXMgPSBjb250cm9sLl9mb3JtVmFsdWVzO1xuICAgIGxldCBkZWZhdWx0VmFsdWVzID0gY29udHJvbC5fZGVmYXVsdFZhbHVlcztcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlZ21lbnRzLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgICBjb25zdCBrZXkgPSBzZWdtZW50c1tpXTtcbiAgICAgICAgZm9ybVZhbHVlcyA9IGZvcm1WYWx1ZXMgPT0gbnVsbCA/IGZvcm1WYWx1ZXMgOiBmb3JtVmFsdWVzW2tleV07XG4gICAgICAgIGRlZmF1bHRWYWx1ZXMgPSBkZWZhdWx0VmFsdWVzID09IG51bGwgPyBkZWZhdWx0VmFsdWVzIDogZGVmYXVsdFZhbHVlc1trZXldO1xuICAgICAgICBpZiAoZm9ybVZhbHVlcyA9PT0gbnVsbCB8fCBkZWZhdWx0VmFsdWVzID09PSBudWxsKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xufVxuXG52YXIgaXNOYW1lSW5GaWVsZEFycmF5ID0gKG5hbWVzLCBuYW1lKSA9PiBuYW1lXG4gICAgLnNwbGl0KCcuJylcbiAgICAuc29tZSgocGFydCwgaW5kZXgsIGFycikgPT4gIWlzTmFOKE51bWJlcihwYXJ0KSkgJiYgbmFtZXMuaGFzKGFyci5zbGljZSgwLCBpbmRleCkuam9pbignLicpKSk7XG5cbnZhciBpc1dlYiA9IHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmXG4gICAgdHlwZW9mIHdpbmRvdy5IVE1MRWxlbWVudCAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnO1xuXG5mdW5jdGlvbiBjbG9uZU9iamVjdChkYXRhKSB7XG4gICAgaWYgKGRhdGEgPT09IG51bGwgfHwgdHlwZW9mIGRhdGEgIT09ICdvYmplY3QnKSB7XG4gICAgICAgIHJldHVybiBkYXRhO1xuICAgIH1cbiAgICBpZiAoZGF0YSBpbnN0YW5jZW9mIERhdGUpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBEYXRlKGRhdGEpO1xuICAgIH1cbiAgICBjb25zdCBpc0Jsb2JJbnN0YW5jZSA9IHR5cGVvZiBCbG9iICE9PSAndW5kZWZpbmVkJyAmJiBkYXRhIGluc3RhbmNlb2YgQmxvYjtcbiAgICBjb25zdCBpc0ZpbGVMaXN0SW5zdGFuY2UgPSB0eXBlb2YgRmlsZUxpc3QgIT09ICd1bmRlZmluZWQnICYmIGRhdGEgaW5zdGFuY2VvZiBGaWxlTGlzdDtcbiAgICBpZiAoaXNXZWIgJiYgKGlzQmxvYkluc3RhbmNlIHx8IGlzRmlsZUxpc3RJbnN0YW5jZSkpIHtcbiAgICAgICAgcmV0dXJuIGRhdGE7XG4gICAgfVxuICAgIGNvbnN0IGlzQXJyYXkgPSBBcnJheS5pc0FycmF5KGRhdGEpO1xuICAgIGNvbnN0IHByb3RvdHlwZSA9IE9iamVjdC5nZXRQcm90b3R5cGVPZihkYXRhKTtcbiAgICBpZiAoIWlzQXJyYXkgJiYgcHJvdG90eXBlICYmIGRhdGEuY29uc3RydWN0b3IgIT09IE9iamVjdCkge1xuICAgICAgICByZXR1cm4gZGF0YTtcbiAgICB9XG4gICAgY29uc3QgY29weSA9IGlzQXJyYXkgPyBuZXcgQXJyYXkoZGF0YS5sZW5ndGgpIDogT2JqZWN0LmNyZWF0ZShwcm90b3R5cGUpO1xuICAgIGZvciAoY29uc3Qga2V5IGluIGRhdGEpIHtcbiAgICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChkYXRhLCBrZXkpKSB7XG4gICAgICAgICAgICBjb3B5W2tleV0gPSBjbG9uZU9iamVjdChkYXRhW2tleV0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBjb3B5O1xufVxuXG5jb25zdCBFVkVOVFMgPSB7XG4gICAgQkxVUjogJ2JsdXInLFxuICAgIEZPQ1VTX09VVDogJ2ZvY3Vzb3V0JyxcbiAgICBDSEFOR0U6ICdjaGFuZ2UnLFxuICAgIFNVQk1JVDogJ3N1Ym1pdCcsXG4gICAgVFJJR0dFUjogJ3RyaWdnZXInLFxuICAgIFZBTElEOiAndmFsaWQnLFxufTtcbmNvbnN0IFZBTElEQVRJT05fTU9ERSA9IHtcbiAgICBvbkJsdXI6ICdvbkJsdXInLFxuICAgIG9uQ2hhbmdlOiAnb25DaGFuZ2UnLFxuICAgIG9uU3VibWl0OiAnb25TdWJtaXQnLFxuICAgIG9uVG91Y2hlZDogJ29uVG91Y2hlZCcsXG4gICAgYWxsOiAnYWxsJyxcbn07XG5jb25zdCBJTlBVVF9WQUxJREFUSU9OX1JVTEVTID0ge1xuICAgIG1heDogJ21heCcsXG4gICAgbWluOiAnbWluJyxcbiAgICBtYXhMZW5ndGg6ICdtYXhMZW5ndGgnLFxuICAgIG1pbkxlbmd0aDogJ21pbkxlbmd0aCcsXG4gICAgcGF0dGVybjogJ3BhdHRlcm4nLFxuICAgIHJlcXVpcmVkOiAncmVxdWlyZWQnLFxuICAgIHZhbGlkYXRlOiAndmFsaWRhdGUnLFxufTtcbmNvbnN0IFJFR0lTVEVSX1ZBTElEQVRJT05fUlVMRVMgPSBbXG4gICAgSU5QVVRfVkFMSURBVElPTl9SVUxFUy5yZXF1aXJlZCxcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1pbixcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1heCxcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1pbkxlbmd0aCxcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1heExlbmd0aCxcbiAgICBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLnBhdHRlcm4sXG4gICAgSU5QVVRfVkFMSURBVElPTl9SVUxFUy52YWxpZGF0ZSxcbl07XG5jb25zdCBGT1JNX0VSUk9SX1RZUEUgPSAnZm9ybSc7XG5jb25zdCBST09UX0VSUk9SX1RZUEUgPSAncm9vdCc7XG5jb25zdCBQUk9UT1RZUEVfS0VZV09SRFMgPSBbJ19fcHJvdG9fXycsICdjb25zdHJ1Y3RvcicsICdwcm90b3R5cGUnXTtcblxuY29uc3QgSVNfS0VZX1JFID0gL15cXHcqJC87XG52YXIgaXNLZXkgPSAodmFsdWUpID0+IElTX0tFWV9SRS50ZXN0KHZhbHVlKTtcblxudmFyIGlzVW5kZWZpbmVkID0gKHZhbCkgPT4gdmFsID09PSB1bmRlZmluZWQ7XG5cbnZhciBnZXQgPSAob2JqZWN0LCBwYXRoLCBkZWZhdWx0VmFsdWUpID0+IHtcbiAgICBpZiAoIXBhdGggfHwgIWlzT2JqZWN0KG9iamVjdCkpIHtcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcbiAgICB9XG4gICAgY29uc3QgcGF0aHMgPSBpc0tleShwYXRoKSA/IFtwYXRoXSA6IHN0cmluZ1RvUGF0aChwYXRoKTtcbiAgICBpZiAocGF0aHMuc29tZSgoa2V5KSA9PiBQUk9UT1RZUEVfS0VZV09SRFMuaW5jbHVkZXMoa2V5KSkpIHtcbiAgICAgICAgcmV0dXJuIGRlZmF1bHRWYWx1ZTtcbiAgICB9XG4gICAgY29uc3QgcmVzdWx0ID0gcGF0aHMucmVkdWNlKChyZXN1bHQsIGtleSkgPT4ge1xuICAgICAgICByZXR1cm4gaXNOdWxsT3JVbmRlZmluZWQocmVzdWx0KSA/IHVuZGVmaW5lZCA6IHJlc3VsdFtrZXldO1xuICAgIH0sIG9iamVjdCk7XG4gICAgcmV0dXJuIGlzVW5kZWZpbmVkKHJlc3VsdCkgfHwgcmVzdWx0ID09PSBvYmplY3RcbiAgICAgICAgPyBpc1VuZGVmaW5lZChvYmplY3RbcGF0aF0pXG4gICAgICAgICAgICA/IGRlZmF1bHRWYWx1ZVxuICAgICAgICAgICAgOiBvYmplY3RbcGF0aF1cbiAgICAgICAgOiByZXN1bHQ7XG59O1xuXG52YXIgaXNCb29sZWFuID0gKHZhbHVlKSA9PiB0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJztcblxudmFyIGlzRnVuY3Rpb24gPSAodmFsdWUpID0+IHR5cGVvZiB2YWx1ZSA9PT0gJ2Z1bmN0aW9uJztcblxudmFyIHNldCA9IChvYmplY3QsIHBhdGgsIHZhbHVlKSA9PiB7XG4gICAgbGV0IGluZGV4ID0gLTE7XG4gICAgY29uc3QgdGVtcFBhdGggPSBpc0tleShwYXRoKSA/IFtwYXRoXSA6IHN0cmluZ1RvUGF0aChwYXRoKTtcbiAgICBjb25zdCBsZW5ndGggPSB0ZW1wUGF0aC5sZW5ndGg7XG4gICAgY29uc3QgbGFzdEluZGV4ID0gbGVuZ3RoIC0gMTtcbiAgICB3aGlsZSAoKytpbmRleCA8IGxlbmd0aCkge1xuICAgICAgICBjb25zdCBrZXkgPSB0ZW1wUGF0aFtpbmRleF07XG4gICAgICAgIGxldCBuZXdWYWx1ZSA9IHZhbHVlO1xuICAgICAgICBpZiAoaW5kZXggIT09IGxhc3RJbmRleCkge1xuICAgICAgICAgICAgY29uc3Qgb2JqVmFsdWUgPSBvYmplY3Rba2V5XTtcbiAgICAgICAgICAgIG5ld1ZhbHVlID1cbiAgICAgICAgICAgICAgICBpc09iamVjdChvYmpWYWx1ZSkgfHwgQXJyYXkuaXNBcnJheShvYmpWYWx1ZSlcbiAgICAgICAgICAgICAgICAgICAgPyBvYmpWYWx1ZVxuICAgICAgICAgICAgICAgICAgICA6ICFpc05hTigrdGVtcFBhdGhbaW5kZXggKyAxXSlcbiAgICAgICAgICAgICAgICAgICAgICAgID8gW11cbiAgICAgICAgICAgICAgICAgICAgICAgIDoge307XG4gICAgICAgIH1cbiAgICAgICAgaWYgKFBST1RPVFlQRV9LRVlXT1JEUy5pbmNsdWRlcyhrZXkpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgb2JqZWN0W2tleV0gPSBuZXdWYWx1ZTtcbiAgICAgICAgb2JqZWN0ID0gb2JqZWN0W2tleV07XG4gICAgfVxufTtcblxuLyoqXG4gKiBTZXBhcmF0ZSBjb250ZXh0IGZvciBgY29udHJvbGAgdG8gcHJldmVudCB1bm5lY2Vzc2FyeSByZXJlbmRlcnMuXG4gKiBJbnRlcm5hbCBob29rcyB0aGF0IG9ubHkgbmVlZCBjb250cm9sIHVzZSB0aGlzIGluc3RlYWQgb2YgZnVsbCBmb3JtIGNvbnRleHQuXG4gKi9cbmNvbnN0IEhvb2tGb3JtQ29udHJvbENvbnRleHQgPSBSZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuSG9va0Zvcm1Db250cm9sQ29udGV4dC5kaXNwbGF5TmFtZSA9ICdIb29rRm9ybUNvbnRyb2xDb250ZXh0Jztcbi8qKlxuICogQGludGVybmFsIEludGVybmFsIGhvb2sgdG8gYWNjZXNzIG9ubHkgY29udHJvbCBmcm9tIGNvbnRleHQuXG4gKi9cbmNvbnN0IHVzZUZvcm1Db250cm9sQ29udGV4dCA9ICgpID0+IFJlYWN0LnVzZUNvbnRleHQoSG9va0Zvcm1Db250cm9sQ29udGV4dCk7XG5cbnZhciBnZXRQcm94eUZvcm1TdGF0ZSA9IChmb3JtU3RhdGUsIGNvbnRyb2wsIGxvY2FsUHJveHlGb3JtU3RhdGUsIGlzUm9vdCA9IHRydWUpID0+IHtcbiAgICBjb25zdCByZXN1bHQgPSB7fTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBmb3JtU3RhdGUpIHtcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHJlc3VsdCwga2V5LCB7XG4gICAgICAgICAgICBnZXQ6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBfa2V5ID0ga2V5O1xuICAgICAgICAgICAgICAgIGlmIChjb250cm9sLl9wcm94eUZvcm1TdGF0ZVtfa2V5XSAhPT0gVkFMSURBVElPTl9NT0RFLmFsbCkge1xuICAgICAgICAgICAgICAgICAgICBjb250cm9sLl9wcm94eUZvcm1TdGF0ZVtfa2V5XSA9ICFpc1Jvb3QgfHwgVkFMSURBVElPTl9NT0RFLmFsbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgbG9jYWxQcm94eUZvcm1TdGF0ZSAmJiAobG9jYWxQcm94eUZvcm1TdGF0ZVtfa2V5XSA9IHRydWUpO1xuICAgICAgICAgICAgICAgIHJldHVybiBmb3JtU3RhdGVbX2tleV07XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbn07XG5cbmNvbnN0IHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QgPSBpc1dlYlxuICAgID8gUmVhY3QudXNlTGF5b3V0RWZmZWN0XG4gICAgOiBSZWFjdC51c2VFZmZlY3Q7XG5cbnZhciBpc1BsYWluT2JqZWN0ID0gKHRlbXBPYmplY3QpID0+IHtcbiAgICBjb25zdCBwcm90b3R5cGVDb3B5ID0gdGVtcE9iamVjdC5jb25zdHJ1Y3RvciAmJiB0ZW1wT2JqZWN0LmNvbnN0cnVjdG9yLnByb3RvdHlwZTtcbiAgICByZXR1cm4gKGlzT2JqZWN0KHByb3RvdHlwZUNvcHkpICYmIHByb3RvdHlwZUNvcHkuaGFzT3duUHJvcGVydHkoJ2lzUHJvdG90eXBlT2YnKSk7XG59O1xuXG52YXIgaXNQcmltaXRpdmUgPSAodmFsdWUpID0+IGlzTnVsbE9yVW5kZWZpbmVkKHZhbHVlKSB8fCAhaXNPYmplY3RUeXBlKHZhbHVlKTtcblxuY29uc3QgaXNFbXB0eU9iamVjdFdpdGhDdXN0b21Qcm90b3R5cGUgPSAob2JqZWN0LCBrZXlzKSA9PiBrZXlzLmxlbmd0aCA9PT0gMCAmJiAhQXJyYXkuaXNBcnJheShvYmplY3QpICYmICFpc1BsYWluT2JqZWN0KG9iamVjdCk7XG5mdW5jdGlvbiBkZWVwRXF1YWwob2JqZWN0MSwgb2JqZWN0MiwgaXNFcnJvck9iamVjdCA9IGZhbHNlLCB2aXNpdGVkID0gbmV3IFdlYWtNYXAoKSkge1xuICAgIGlmIChvYmplY3QxID09PSBvYmplY3QyKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoaXNQcmltaXRpdmUob2JqZWN0MSkgfHwgaXNQcmltaXRpdmUob2JqZWN0MikpIHtcbiAgICAgICAgcmV0dXJuIE9iamVjdC5pcyhvYmplY3QxLCBvYmplY3QyKTtcbiAgICB9XG4gICAgaWYgKGlzRGF0ZU9iamVjdChvYmplY3QxKSAmJiBpc0RhdGVPYmplY3Qob2JqZWN0MikpIHtcbiAgICAgICAgcmV0dXJuIE9iamVjdC5pcyhvYmplY3QxLmdldFRpbWUoKSwgb2JqZWN0Mi5nZXRUaW1lKCkpO1xuICAgIH1cbiAgICBjb25zdCBrZXlzMSA9IE9iamVjdC5rZXlzKG9iamVjdDEpO1xuICAgIGNvbnN0IGtleXMyID0gT2JqZWN0LmtleXMob2JqZWN0Mik7XG4gICAgaWYgKGtleXMxLmxlbmd0aCAhPT0ga2V5czIubGVuZ3RoKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKGlzRW1wdHlPYmplY3RXaXRoQ3VzdG9tUHJvdG90eXBlKG9iamVjdDEsIGtleXMxKSB8fFxuICAgICAgICBpc0VtcHR5T2JqZWN0V2l0aEN1c3RvbVByb3RvdHlwZShvYmplY3QyLCBrZXlzMikpIHtcbiAgICAgICAgcmV0dXJuIE9iamVjdC5pcyhvYmplY3QxLCBvYmplY3QyKTtcbiAgICB9XG4gICAgaWYgKCFrZXlzMS5sZW5ndGggJiYgQXJyYXkuaXNBcnJheShvYmplY3QxKSAhPT0gQXJyYXkuaXNBcnJheShvYmplY3QyKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IHZpc2l0ZWRQYWlycyA9IHZpc2l0ZWQuZ2V0KG9iamVjdDEpO1xuICAgIGlmICh2aXNpdGVkUGFpcnMgJiYgdmlzaXRlZFBhaXJzLmhhcyhvYmplY3QyKSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaWYgKHZpc2l0ZWRQYWlycykge1xuICAgICAgICB2aXNpdGVkUGFpcnMuYWRkKG9iamVjdDIpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY29uc3Qgd3MgPSBuZXcgV2Vha1NldCgpO1xuICAgICAgICB3cy5hZGQob2JqZWN0Mik7XG4gICAgICAgIHZpc2l0ZWQuc2V0KG9iamVjdDEsIHdzKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBrZXkgb2Yga2V5czEpIHtcbiAgICAgICAgY29uc3QgdmFsMSA9IG9iamVjdDFba2V5XTtcbiAgICAgICAgaWYgKCEoa2V5IGluIG9iamVjdDIpKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFpc0Vycm9yT2JqZWN0IHx8IGtleSAhPT0gJ3JlZicpIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbDIgPSBvYmplY3QyW2tleV07XG4gICAgICAgICAgICBpZiAoKGlzRGF0ZU9iamVjdCh2YWwxKSAmJiBpc0RhdGVPYmplY3QodmFsMikpIHx8XG4gICAgICAgICAgICAgICAgKChpc09iamVjdCh2YWwxKSB8fCBBcnJheS5pc0FycmF5KHZhbDEpKSAmJlxuICAgICAgICAgICAgICAgICAgICAoaXNPYmplY3QodmFsMikgfHwgQXJyYXkuaXNBcnJheSh2YWwyKSkpXG4gICAgICAgICAgICAgICAgPyAhZGVlcEVxdWFsKHZhbDEsIHZhbDIsIGlzRXJyb3JPYmplY3QsIHZpc2l0ZWQpXG4gICAgICAgICAgICAgICAgOiAhT2JqZWN0LmlzKHZhbDEsIHZhbDIpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xufVxuXG5mdW5jdGlvbiB1c2VSZXN5bmNPblJlY29ubmVjdChnZXRJbml0aWFsVmFsdWUpIHtcbiAgICBjb25zdCBfY29ubmVjdGVkID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgICBjb25zdCBfaW5pdGlhbGl6ZWQgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICAgIGNvbnN0IF9wcmV2VmFsdWUgPSBSZWFjdC51c2VSZWYodW5kZWZpbmVkKTtcbiAgICBjb25zdCBfcmVuZGVyQ291bnQgPSBSZWFjdC51c2VSZWYoMCk7XG4gICAgX3JlbmRlckNvdW50LmN1cnJlbnQrKztcbiAgICBpZiAoIV9pbml0aWFsaXplZC5jdXJyZW50ICYmIGdldEluaXRpYWxWYWx1ZSkge1xuICAgICAgICBfaW5pdGlhbGl6ZWQuY3VycmVudCA9IHRydWU7XG4gICAgICAgIF9wcmV2VmFsdWUuY3VycmVudCA9IGNsb25lT2JqZWN0KGdldEluaXRpYWxWYWx1ZSgpKTtcbiAgICB9XG4gICAgY29uc3QgcmVzeW5jSWZOZWVkZWQgPSBSZWFjdC51c2VDYWxsYmFjaygoZW5hYmxlZCwgZ2V0Q3VycmVudFZhbHVlLCBzZXRWYWx1ZSkgPT4ge1xuICAgICAgICBpZiAoZW5hYmxlZCAmJlxuICAgICAgICAgICAgKF9jb25uZWN0ZWQuY3VycmVudCB8fFxuICAgICAgICAgICAgICAgIChfaW5pdGlhbGl6ZWQuY3VycmVudCAmJiBfcmVuZGVyQ291bnQuY3VycmVudCA+IDEpKSkge1xuICAgICAgICAgICAgY29uc3QgY3VycmVudFZhbHVlID0gZ2V0Q3VycmVudFZhbHVlKCk7XG4gICAgICAgICAgICBpZiAoIWRlZXBFcXVhbChfcHJldlZhbHVlLmN1cnJlbnQsIGN1cnJlbnRWYWx1ZSkpIHtcbiAgICAgICAgICAgICAgICBzZXRWYWx1ZShjdXJyZW50VmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIF9jb25uZWN0ZWQuY3VycmVudCA9IHRydWU7XG4gICAgfSwgW10pO1xuICAgIGNvbnN0IHNuYXBzaG90ID0gUmVhY3QudXNlQ2FsbGJhY2soKGVuYWJsZWQsIGdldEN1cnJlbnRWYWx1ZSkgPT4ge1xuICAgICAgICBpZiAoZW5hYmxlZCkge1xuICAgICAgICAgICAgX3ByZXZWYWx1ZS5jdXJyZW50ID0gY2xvbmVPYmplY3QoZ2V0Q3VycmVudFZhbHVlKCkpO1xuICAgICAgICB9XG4gICAgfSwgW10pO1xuICAgIHJldHVybiB7IHJlc3luY0lmTmVlZGVkLCBzbmFwc2hvdCB9O1xufVxuXG4vKipcbiAqIFN1YnNjcmliZXMgdG8gZm9ybSBzdGF0ZSB3aXRoIHJlLXJlbmRlcnMgaXNvbGF0ZWQgdG8gdGhpcyBob29rLlxuICogT3B0aW9uYWxseSBzY29wZSB0byBzcGVjaWZpYyBmaWVsZCBuYW1lcyB0byBtaW5pbWl6ZSByZS1yZW5kZXIgc3VyZmFjZS5cbiAqXG4gKiBAc2VlIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZWZvcm1zdGF0ZSlcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBjb25zdCB7IGVycm9ycywgaXNEaXJ0eSB9ID0gdXNlRm9ybVN0YXRlKHsgY29udHJvbCwgbmFtZTogXCJlbWFpbFwiIH0pO1xuICogYGBgXG4gKi9cbmZ1bmN0aW9uIHVzZUZvcm1TdGF0ZShwcm9wcykge1xuICAgIGNvbnN0IGZvcm1Db250cm9sID0gdXNlRm9ybUNvbnRyb2xDb250ZXh0KCk7XG4gICAgY29uc3QgeyBjb250cm9sID0gZm9ybUNvbnRyb2wsIGRpc2FibGVkLCBuYW1lLCBleGFjdCB9ID0gcHJvcHMgfHwge307XG4gICAgY29uc3QgZ2V0Q3VycmVudEZvcm1TdGF0ZSA9ICgpID0+ICh7XG4gICAgICAgIC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZSxcbiAgICAgICAgZGVmYXVsdFZhbHVlczogY29udHJvbC5fZGVmYXVsdFZhbHVlcyxcbiAgICB9KTtcbiAgICBjb25zdCBbZm9ybVN0YXRlLCB1cGRhdGVGb3JtU3RhdGVdID0gUmVhY3QudXNlU3RhdGUoZ2V0Q3VycmVudEZvcm1TdGF0ZSk7XG4gICAgY29uc3QgX2xvY2FsUHJveHlGb3JtU3RhdGUgPSBSZWFjdC51c2VSZWYoe1xuICAgICAgICBpc0RpcnR5OiBmYWxzZSxcbiAgICAgICAgaXNMb2FkaW5nOiBmYWxzZSxcbiAgICAgICAgZGlydHlGaWVsZHM6IGZhbHNlLFxuICAgICAgICB0b3VjaGVkRmllbGRzOiBmYWxzZSxcbiAgICAgICAgdmFsaWRhdGluZ0ZpZWxkczogZmFsc2UsXG4gICAgICAgIGlzVmFsaWRhdGluZzogZmFsc2UsXG4gICAgICAgIGlzVmFsaWQ6IGZhbHNlLFxuICAgICAgICBlcnJvcnM6IGZhbHNlLFxuICAgIH0pO1xuICAgIGNvbnN0IHsgcmVzeW5jSWZOZWVkZWQsIHNuYXBzaG90IH0gPSB1c2VSZXN5bmNPblJlY29ubmVjdChnZXRDdXJyZW50Rm9ybVN0YXRlKTtcbiAgICB1c2VJc29tb3JwaGljTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgICAgcmVzeW5jSWZOZWVkZWQoIWRpc2FibGVkLCBnZXRDdXJyZW50Rm9ybVN0YXRlLCB1cGRhdGVGb3JtU3RhdGUpO1xuICAgICAgICBjb25zdCB1bnN1YnNjcmliZSA9IGNvbnRyb2wuX3N1YnNjcmliZSh7XG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgZm9ybVN0YXRlOiBfbG9jYWxQcm94eUZvcm1TdGF0ZS5jdXJyZW50LFxuICAgICAgICAgICAgZXhhY3QsXG4gICAgICAgICAgICBjYWxsYmFjazogKGZvcm1TdGF0ZSkgPT4ge1xuICAgICAgICAgICAgICAgICFkaXNhYmxlZCAmJlxuICAgICAgICAgICAgICAgICAgICB1cGRhdGVGb3JtU3RhdGUoe1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4uY29udHJvbC5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlczogY29udHJvbC5fZGVmYXVsdFZhbHVlcyxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIHVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICBzbmFwc2hvdCghZGlzYWJsZWQsIGdldEN1cnJlbnRGb3JtU3RhdGUpO1xuICAgICAgICB9O1xuICAgIH0sIFtjb250cm9sLCBuYW1lLCBkaXNhYmxlZCwgZXhhY3QsIHJlc3luY0lmTmVlZGVkLCBzbmFwc2hvdF0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIF9sb2NhbFByb3h5Rm9ybVN0YXRlLmN1cnJlbnQuaXNWYWxpZCAmJiBjb250cm9sLl9zZXRWYWxpZCh0cnVlKTtcbiAgICB9LCBbY29udHJvbF0pO1xuICAgIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+IGdldFByb3h5Rm9ybVN0YXRlKGZvcm1TdGF0ZSwgY29udHJvbCwgX2xvY2FsUHJveHlGb3JtU3RhdGUuY3VycmVudCwgZmFsc2UpLCBbZm9ybVN0YXRlLCBjb250cm9sXSk7XG59XG5cbnZhciBpc1N0cmluZyA9ICh2YWx1ZSkgPT4gdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJztcblxudmFyIGdlbmVyYXRlV2F0Y2hPdXRwdXQgPSAobmFtZXMsIF9uYW1lcywgZm9ybVZhbHVlcywgaXNHbG9iYWwsIGRlZmF1bHRWYWx1ZSkgPT4ge1xuICAgIGlmIChpc1N0cmluZyhuYW1lcykpIHtcbiAgICAgICAgaXNHbG9iYWwgJiYgX25hbWVzLndhdGNoLmFkZChuYW1lcyk7XG4gICAgICAgIHJldHVybiBnZXQoZm9ybVZhbHVlcywgbmFtZXMsIGRlZmF1bHRWYWx1ZSk7XG4gICAgfVxuICAgIGlmIChBcnJheS5pc0FycmF5KG5hbWVzKSkge1xuICAgICAgICByZXR1cm4gbmFtZXMubWFwKChmaWVsZE5hbWUpID0+IChpc0dsb2JhbCAmJiBfbmFtZXMud2F0Y2guYWRkKGZpZWxkTmFtZSksXG4gICAgICAgICAgICBnZXQoZm9ybVZhbHVlcywgZmllbGROYW1lLCBnZXQoZGVmYXVsdFZhbHVlLCBmaWVsZE5hbWUpKSkpO1xuICAgIH1cbiAgICBpc0dsb2JhbCAmJiAoX25hbWVzLndhdGNoQWxsID0gdHJ1ZSk7XG4gICAgcmV0dXJuIGZvcm1WYWx1ZXM7XG59O1xuXG4vKipcbiAqIFN1YnNjcmliZXMgdG8gZmllbGQgdmFsdWUgY2hhbmdlcyBhbmQgaXNvbGF0ZXMgcmUtcmVuZGVycyB0byB0aGUgaG9vayBsZXZlbC5cbiAqXG4gKiBAc2VlIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZXdhdGNoKVxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIGNvbnN0IGVtYWlsID0gdXNlV2F0Y2goeyBjb250cm9sLCBuYW1lOiBcImVtYWlsXCIgfSk7XG4gKiBjb25zdCBhbGwgICA9IHVzZVdhdGNoKHsgY29udHJvbCB9KTtcbiAqIGNvbnN0IGFkdWx0ID0gdXNlV2F0Y2goeyBjb250cm9sLCBuYW1lOiBcImFnZVwiLCBjb21wdXRlOiAodikgPT4gdiA+PSAxOCB9KTtcbiAqIGBgYFxuICovXG5mdW5jdGlvbiB1c2VXYXRjaChwcm9wcykge1xuICAgIGNvbnN0IGZvcm1Db250cm9sID0gdXNlRm9ybUNvbnRyb2xDb250ZXh0KCk7XG4gICAgY29uc3QgeyBjb250cm9sID0gZm9ybUNvbnRyb2wsIG5hbWUsIGRlZmF1bHRWYWx1ZSwgZGlzYWJsZWQsIGV4YWN0LCBjb21wdXRlLCB9ID0gcHJvcHMgfHwge307XG4gICAgY29uc3QgX2RlZmF1bHRWYWx1ZSA9IFJlYWN0LnVzZVJlZihkZWZhdWx0VmFsdWUpO1xuICAgIGNvbnN0IF9jb21wdXRlID0gUmVhY3QudXNlUmVmKGNvbXB1dGUpO1xuICAgIGNvbnN0IF9wcmV2Q29udHJvbCA9IFJlYWN0LnVzZVJlZihjb250cm9sKTtcbiAgICBjb25zdCBfcHJldk5hbWUgPSBSZWFjdC51c2VSZWYobmFtZSk7XG4gICAgX2NvbXB1dGUuY3VycmVudCA9IGNvbXB1dGU7XG4gICAgY29uc3QgZ2V0SW5pdGlhbE91dHB1dCA9ICgpID0+IHtcbiAgICAgICAgY29uc3QgZGVmYXVsdFZhbHVlID0gY29udHJvbC5fZ2V0V2F0Y2gobmFtZSwgX2RlZmF1bHRWYWx1ZS5jdXJyZW50KTtcbiAgICAgICAgcmV0dXJuIF9jb21wdXRlLmN1cnJlbnQgPyBfY29tcHV0ZS5jdXJyZW50KGRlZmF1bHRWYWx1ZSkgOiBkZWZhdWx0VmFsdWU7XG4gICAgfTtcbiAgICBjb25zdCBbdmFsdWUsIHVwZGF0ZVZhbHVlXSA9IFJlYWN0LnVzZVN0YXRlKGdldEluaXRpYWxPdXRwdXQpO1xuICAgIGNvbnN0IF9jb21wdXRlRm9ybVZhbHVlcyA9IFJlYWN0LnVzZVJlZih2YWx1ZSk7XG4gICAgY29uc3QgZ2V0Q3VycmVudE91dHB1dCA9IFJlYWN0LnVzZUNhbGxiYWNrKCh2YWx1ZXMpID0+IHtcbiAgICAgICAgY29uc3QgZm9ybVZhbHVlcyA9IGdlbmVyYXRlV2F0Y2hPdXRwdXQobmFtZSwgY29udHJvbC5fbmFtZXMsIHZhbHVlcyB8fCBjb250cm9sLl9mb3JtVmFsdWVzLCBmYWxzZSwgX2RlZmF1bHRWYWx1ZS5jdXJyZW50KTtcbiAgICAgICAgcmV0dXJuIF9jb21wdXRlLmN1cnJlbnQgPyBfY29tcHV0ZS5jdXJyZW50KGZvcm1WYWx1ZXMpIDogZm9ybVZhbHVlcztcbiAgICB9LCBbY29udHJvbC5fZm9ybVZhbHVlcywgY29udHJvbC5fbmFtZXMsIG5hbWVdKTtcbiAgICBjb25zdCByZWZyZXNoVmFsdWUgPSBSZWFjdC51c2VDYWxsYmFjaygodmFsdWVzKSA9PiB7XG4gICAgICAgIGlmICghZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIGNvbnN0IGZvcm1WYWx1ZXMgPSBnZW5lcmF0ZVdhdGNoT3V0cHV0KG5hbWUsIGNvbnRyb2wuX25hbWVzLCB2YWx1ZXMgfHwgY29udHJvbC5fZm9ybVZhbHVlcywgZmFsc2UsIF9kZWZhdWx0VmFsdWUuY3VycmVudCk7XG4gICAgICAgICAgICBpZiAoX2NvbXB1dGUuY3VycmVudCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNvbXB1dGVkRm9ybVZhbHVlcyA9IF9jb21wdXRlLmN1cnJlbnQoZm9ybVZhbHVlcyk7XG4gICAgICAgICAgICAgICAgaWYgKCFkZWVwRXF1YWwoY29tcHV0ZWRGb3JtVmFsdWVzLCBfY29tcHV0ZUZvcm1WYWx1ZXMuY3VycmVudCkpIHtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlVmFsdWUoY29tcHV0ZWRGb3JtVmFsdWVzKTtcbiAgICAgICAgICAgICAgICAgICAgX2NvbXB1dGVGb3JtVmFsdWVzLmN1cnJlbnQgPSBjb21wdXRlZEZvcm1WYWx1ZXM7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgdXBkYXRlVmFsdWUoZm9ybVZhbHVlcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbY29udHJvbC5fZm9ybVZhbHVlcywgY29udHJvbC5fbmFtZXMsIGRpc2FibGVkLCBuYW1lXSk7XG4gICAgY29uc3QgeyByZXN5bmNJZk5lZWRlZCwgc25hcHNob3QgfSA9IHVzZVJlc3luY09uUmVjb25uZWN0KGdldEluaXRpYWxPdXRwdXQpO1xuICAgIGNvbnN0IF9yZWZyZXNoVmFsdWUgPSBSZWFjdC51c2VSZWYocmVmcmVzaFZhbHVlKTtcbiAgICBfcmVmcmVzaFZhbHVlLmN1cnJlbnQgPSByZWZyZXNoVmFsdWU7XG4gICAgY29uc3QgX2dldEN1cnJlbnRPdXRwdXQgPSBSZWFjdC51c2VSZWYoZ2V0Q3VycmVudE91dHB1dCk7XG4gICAgX2dldEN1cnJlbnRPdXRwdXQuY3VycmVudCA9IGdldEN1cnJlbnRPdXRwdXQ7XG4gICAgdXNlSXNvbW9ycGhpY0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChfcHJldkNvbnRyb2wuY3VycmVudCAhPT0gY29udHJvbCB8fFxuICAgICAgICAgICAgIWRlZXBFcXVhbChfcHJldk5hbWUuY3VycmVudCwgbmFtZSkpIHtcbiAgICAgICAgICAgIF9wcmV2Q29udHJvbC5jdXJyZW50ID0gY29udHJvbDtcbiAgICAgICAgICAgIF9wcmV2TmFtZS5jdXJyZW50ID0gbmFtZTtcbiAgICAgICAgICAgIF9yZWZyZXNoVmFsdWUuY3VycmVudCgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgcmVzeW5jSWZOZWVkZWQoIWRpc2FibGVkLCAoKSA9PiBfZ2V0Q3VycmVudE91dHB1dC5jdXJyZW50KCksIChjdXJyZW50VmFsdWUpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBuZXh0VmFsdWUgPSBjbG9uZU9iamVjdChjdXJyZW50VmFsdWUpO1xuICAgICAgICAgICAgICAgIHVwZGF0ZVZhbHVlKG5leHRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgX2NvbXB1dGVGb3JtVmFsdWVzLmN1cnJlbnQgPSBuZXh0VmFsdWU7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1bnN1YnNjcmliZSA9IGNvbnRyb2wuX3N1YnNjcmliZSh7XG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgZm9ybVN0YXRlOiB7XG4gICAgICAgICAgICAgICAgdmFsdWVzOiB0cnVlLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGV4YWN0LFxuICAgICAgICAgICAgY2FsbGJhY2s6IChmb3JtU3RhdGUpID0+IHtcbiAgICAgICAgICAgICAgICBfcmVmcmVzaFZhbHVlLmN1cnJlbnQoZm9ybVN0YXRlLnZhbHVlcyk7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIHVuc3Vic2NyaWJlKCk7XG4gICAgICAgICAgICBzbmFwc2hvdCghZGlzYWJsZWQsICgpID0+IF9nZXRDdXJyZW50T3V0cHV0LmN1cnJlbnQoKSk7XG4gICAgICAgIH07XG4gICAgfSwgW2NvbnRyb2wsIGV4YWN0LCBuYW1lLCBkaXNhYmxlZCwgcmVzeW5jSWZOZWVkZWQsIHNuYXBzaG90XSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IGNvbnRyb2wuX3JlbW92ZVVubW91bnRlZCgpKTtcbiAgICAvLyBJZiBuYW1lIG9yIGNvbnRyb2wgY2hhbmdlZCBmb3IgdGhpcyByZW5kZXIsIHN5bmNocm9ub3VzbHkgcmVmbGVjdCB0aGVcbiAgICAvLyBsYXRlc3QgdmFsdWUgc28gY2FsbGVycyAobGlrZSB1c2VDb250cm9sbGVyKSBzZWUgdGhlIGNvcnJlY3QgdmFsdWVcbiAgICAvLyBpbW1lZGlhdGVseSBvbiB0aGUgc2FtZSByZW5kZXIuXG4gICAgLy8gT3B0aW1pemU6IENoZWNrIGNvbnRyb2wgcmVmZXJlbmNlIGZpcnN0IGJlZm9yZSBleHBlbnNpdmUgZGVlcEVxdWFsXG4gICAgY29uc3QgY29udHJvbENoYW5nZWQgPSBfcHJldkNvbnRyb2wuY3VycmVudCAhPT0gY29udHJvbDtcbiAgICBjb25zdCBwcmV2TmFtZSA9IF9wcmV2TmFtZS5jdXJyZW50O1xuICAgIC8vIGBudWxsYC9gdW5kZWZpbmVkYCBhcmUgdmFsaWQgd2F0Y2hlZCB2YWx1ZXMsIHNvIGEgYm9vbGVhbiBmbGFnIChyYXRoZXJcbiAgICAvLyB0aGFuIGEgc2VudGluZWwgcmV0dXJuIHZhbHVlKSBkZWNpZGVzIHdoZXRoZXIgdG8gcmV0dXJuIHRoZSBmcmVzaGx5XG4gICAgLy8gY29tcHV0ZWQgb3V0cHV0IGluc3RlYWQgb2YgdGhlIHBvc3NpYmx5LXN0YWxlIHN0YXRlIHZhbHVlLlxuICAgIGNvbnN0IHNob3VsZFJldHVybkltbWVkaWF0ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBuYW1lQ2hhbmdlZCA9ICFjb250cm9sQ2hhbmdlZCAmJiAhZGVlcEVxdWFsKHByZXZOYW1lLCBuYW1lKTtcbiAgICAgICAgcmV0dXJuIGNvbnRyb2xDaGFuZ2VkIHx8IG5hbWVDaGFuZ2VkO1xuICAgIH0sIFtkaXNhYmxlZCwgY29udHJvbENoYW5nZWQsIG5hbWUsIHByZXZOYW1lXSk7XG4gICAgcmV0dXJuIHNob3VsZFJldHVybkltbWVkaWF0ZSA/IGdldEN1cnJlbnRPdXRwdXQoKSA6IHZhbHVlO1xufVxuXG4vKipcbiAqIEhvb2sgZm9yIGNvbnRyb2xsZWQgaW5wdXRzLiBSZXR1cm5zIGBmaWVsZGAsIGBmaWVsZFN0YXRlYCwgYW5kIGBmb3JtU3RhdGVgLlxuICogUmUtcmVuZGVycyBhcmUgaXNvbGF0ZWQgdG8gdGhlIGhvb2sgbGV2ZWwuXG4gKlxuICogQHNlZSBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2Vjb250cm9sbGVyKVxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIGNvbnN0IHsgZmllbGQsIGZpZWxkU3RhdGUgfSA9IHVzZUNvbnRyb2xsZXIoeyBjb250cm9sLCBuYW1lOiBcImVtYWlsXCIgfSk7XG4gKiByZXR1cm4gPGlucHV0IHsuLi5maWVsZH0gLz47XG4gKiBgYGBcbiAqL1xuZnVuY3Rpb24gdXNlQ29udHJvbGxlcihwcm9wcykge1xuICAgIGNvbnN0IGZvcm1Db250cm9sID0gdXNlRm9ybUNvbnRyb2xDb250ZXh0KCk7XG4gICAgY29uc3QgeyBuYW1lLCBkaXNhYmxlZCwgY29udHJvbCA9IGZvcm1Db250cm9sLCBzaG91bGRVbnJlZ2lzdGVyLCBkZWZhdWx0VmFsdWUsIGV4YWN0ID0gdHJ1ZSwgfSA9IHByb3BzO1xuICAgIGNvbnN0IGlzQXJyYXlGaWVsZCA9IGlzTmFtZUluRmllbGRBcnJheShjb250cm9sLl9uYW1lcy5hcnJheSwgbmFtZSk7XG4gICAgY29uc3QgZGVmYXVsdFZhbHVlTWVtbyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgICAgICBjb25zdCByZXNvbHZlZCA9IGdldChjb250cm9sLl9mb3JtVmFsdWVzLCBuYW1lLCBnZXQoY29udHJvbC5fZGVmYXVsdFZhbHVlcywgbmFtZSwgZGVmYXVsdFZhbHVlKSk7XG4gICAgICAgIHJldHVybiBpc1VuZGVmaW5lZChyZXNvbHZlZClcbiAgICAgICAgICAgID8gZ2V0TnVsbEFuY2VzdG9yVmFsdWUoY29udHJvbCwgbmFtZSlcbiAgICAgICAgICAgIDogcmVzb2x2ZWQ7XG4gICAgfSwgW2NvbnRyb2wsIG5hbWUsIGRlZmF1bHRWYWx1ZV0pO1xuICAgIGNvbnN0IHZhbHVlID0gdXNlV2F0Y2goe1xuICAgICAgICBjb250cm9sLFxuICAgICAgICBuYW1lLFxuICAgICAgICBkZWZhdWx0VmFsdWU6IGRlZmF1bHRWYWx1ZU1lbW8sXG4gICAgICAgIGV4YWN0LFxuICAgIH0pO1xuICAgIGNvbnN0IGZvcm1TdGF0ZSA9IHVzZUZvcm1TdGF0ZSh7XG4gICAgICAgIGNvbnRyb2wsXG4gICAgICAgIG5hbWUsXG4gICAgICAgIGV4YWN0LFxuICAgIH0pO1xuICAgIGNvbnN0IF9wcm9wcyA9IFJlYWN0LnVzZVJlZihwcm9wcyk7XG4gICAgY29uc3QgX3Byb3h5UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICAgIGNvbnN0IF9yZWdpc3RlclByb3BzID0gUmVhY3QudXNlUmVmKGNvbnRyb2wucmVnaXN0ZXIobmFtZSwge1xuICAgICAgICAuLi5wcm9wcy5ydWxlcyxcbiAgICAgICAgdmFsdWUsXG4gICAgICAgIC4uLihpc0Jvb2xlYW4ocHJvcHMuZGlzYWJsZWQpID8geyBkaXNhYmxlZDogcHJvcHMuZGlzYWJsZWQgfSA6IHt9KSxcbiAgICB9KSk7XG4gICAgX3Byb3BzLmN1cnJlbnQgPSBwcm9wcztcbiAgICBjb25zdCBmaWVsZFN0YXRlID0gUmVhY3QudXNlTWVtbygoKSA9PiBPYmplY3QuZGVmaW5lUHJvcGVydGllcyh7fSwge1xuICAgICAgICBpbnZhbGlkOiB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgZ2V0OiAoKSA9PiAhIWdldChmb3JtU3RhdGUuZXJyb3JzLCBuYW1lKSxcbiAgICAgICAgfSxcbiAgICAgICAgaXNEaXJ0eToge1xuICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGdldDogKCkgPT4gISFnZXQoZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lKSxcbiAgICAgICAgfSxcbiAgICAgICAgaXNUb3VjaGVkOiB7XG4gICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgZ2V0OiAoKSA9PiAhIWdldChmb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgbmFtZSksXG4gICAgICAgIH0sXG4gICAgICAgIGlzVmFsaWRhdGluZzoge1xuICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGdldDogKCkgPT4gISFnZXQoZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMsIG5hbWUpLFxuICAgICAgICB9LFxuICAgICAgICBlcnJvcjoge1xuICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgIGdldDogKCkgPT4gZ2V0KGZvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpLFxuICAgICAgICB9LFxuICAgIH0pLCBbZm9ybVN0YXRlLCBuYW1lXSk7XG4gICAgY29uc3Qgb25DaGFuZ2UgPSBSZWFjdC51c2VDYWxsYmFjaygoZXZlbnQpID0+IHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBnZXRFdmVudFZhbHVlKGV2ZW50KTtcbiAgICAgICAgaWYgKCFnZXQoY29udHJvbC5fZmllbGRzLCBuYW1lKSkge1xuICAgICAgICAgICAgX3JlZ2lzdGVyUHJvcHMuY3VycmVudCA9IGNvbnRyb2wucmVnaXN0ZXIobmFtZSwge1xuICAgICAgICAgICAgICAgIC4uLl9wcm9wcy5jdXJyZW50LnJ1bGVzLFxuICAgICAgICAgICAgICAgIHZhbHVlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIF9yZWdpc3RlclByb3BzLmN1cnJlbnQub25DaGFuZ2Uoe1xuICAgICAgICAgICAgdGFyZ2V0OiB7XG4gICAgICAgICAgICAgICAgdmFsdWU6IGdldEV2ZW50VmFsdWUoZXZlbnQpLFxuICAgICAgICAgICAgICAgIG5hbWU6IG5hbWUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgdHlwZTogRVZFTlRTLkNIQU5HRSxcbiAgICAgICAgfSk7XG4gICAgfSwgW25hbWUsIGNvbnRyb2xdKTtcbiAgICBjb25zdCBvbkJsdXIgPSBSZWFjdC51c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gZ2V0KGNvbnRyb2wuX2Zvcm1WYWx1ZXMsIG5hbWUpO1xuICAgICAgICBpZiAoIWdldChjb250cm9sLl9maWVsZHMsIG5hbWUpKSB7XG4gICAgICAgICAgICBfcmVnaXN0ZXJQcm9wcy5jdXJyZW50ID0gY29udHJvbC5yZWdpc3RlcihuYW1lLCB7XG4gICAgICAgICAgICAgICAgLi4uX3Byb3BzLmN1cnJlbnQucnVsZXMsXG4gICAgICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gX3JlZ2lzdGVyUHJvcHMuY3VycmVudC5vbkJsdXIoe1xuICAgICAgICAgICAgdGFyZ2V0OiB7XG4gICAgICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICAgICAgbmFtZTogbmFtZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB0eXBlOiBFVkVOVFMuQkxVUixcbiAgICAgICAgfSk7XG4gICAgfSwgW25hbWUsIGNvbnRyb2xdKTtcbiAgICBjb25zdCByZWYgPSBSZWFjdC51c2VDYWxsYmFjaygoZWxtKSA9PiB7XG4gICAgICAgIGlmIChlbG0pIHtcbiAgICAgICAgICAgIF9wcm94eVJlZi5jdXJyZW50ID0ge1xuICAgICAgICAgICAgICAgIGZvY3VzOiAoKSA9PiBpc0Z1bmN0aW9uKGVsbS5mb2N1cykgJiYgZWxtLmZvY3VzKCksXG4gICAgICAgICAgICAgICAgc2VsZWN0OiAoKSA9PiBpc0Z1bmN0aW9uKGVsbS5zZWxlY3QpICYmIGVsbS5zZWxlY3QoKSxcbiAgICAgICAgICAgICAgICBzZXRDdXN0b21WYWxpZGl0eTogKG1lc3NhZ2UpID0+IGlzRnVuY3Rpb24oZWxtLnNldEN1c3RvbVZhbGlkaXR5KSAmJiBlbG0uc2V0Q3VzdG9tVmFsaWRpdHkobWVzc2FnZSksXG4gICAgICAgICAgICAgICAgcmVwb3J0VmFsaWRpdHk6ICgpID0+IGlzRnVuY3Rpb24oZWxtLnJlcG9ydFZhbGlkaXR5KSAmJiBlbG0ucmVwb3J0VmFsaWRpdHkoKSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoY29udHJvbC5fZmllbGRzLCBuYW1lKTtcbiAgICAgICAgaWYgKGZpZWxkICYmIGZpZWxkLl9mICYmIGVsbSkge1xuICAgICAgICAgICAgZmllbGQuX2YucmVmID0gX3Byb3h5UmVmLmN1cnJlbnQ7XG4gICAgICAgICAgICBmaWVsZC5fZi5fYyA9IHRydWU7XG4gICAgICAgIH1cbiAgICB9LCBbY29udHJvbC5fZmllbGRzLCBuYW1lXSk7XG4gICAgY29uc3QgZmllbGQgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgICAgIG5hbWUsXG4gICAgICAgIHZhbHVlLFxuICAgICAgICAuLi4oaXNCb29sZWFuKGRpc2FibGVkKSB8fCBmb3JtU3RhdGUuZGlzYWJsZWRcbiAgICAgICAgICAgID8geyBkaXNhYmxlZDogZm9ybVN0YXRlLmRpc2FibGVkIHx8IGRpc2FibGVkIH1cbiAgICAgICAgICAgIDoge30pLFxuICAgICAgICBvbkNoYW5nZSxcbiAgICAgICAgb25CbHVyLFxuICAgICAgICByZWYsXG4gICAgfSksIFtuYW1lLCBkaXNhYmxlZCwgZm9ybVN0YXRlLmRpc2FibGVkLCBvbkNoYW5nZSwgb25CbHVyLCByZWYsIHZhbHVlXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgY29uc3QgX3Nob3VsZFVucmVnaXN0ZXJGaWVsZCA9IGNvbnRyb2wuX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlciB8fCBzaG91bGRVbnJlZ2lzdGVyO1xuICAgICAgICBfcmVnaXN0ZXJQcm9wcy5jdXJyZW50ID0gY29udHJvbC5yZWdpc3RlcihuYW1lLCB7XG4gICAgICAgICAgICAuLi5fcHJvcHMuY3VycmVudC5ydWxlcyxcbiAgICAgICAgICAgIC4uLihpc0Jvb2xlYW4oX3Byb3BzLmN1cnJlbnQuZGlzYWJsZWQpXG4gICAgICAgICAgICAgICAgPyB7IGRpc2FibGVkOiBfcHJvcHMuY3VycmVudC5kaXNhYmxlZCB9XG4gICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCB1cGRhdGVNb3VudGVkID0gKG5hbWUsIHZhbHVlKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZCA9IGdldChjb250cm9sLl9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgaWYgKGZpZWxkICYmIGZpZWxkLl9mKSB7XG4gICAgICAgICAgICAgICAgZmllbGQuX2YubW91bnQgPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICBmaWVsZC5fZi5fYyA9IHZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICB1cGRhdGVNb3VudGVkKG5hbWUsIHRydWUpO1xuICAgICAgICBpZiAoX3Nob3VsZFVucmVnaXN0ZXJGaWVsZCkge1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBjbG9uZU9iamVjdChnZXQoc2hvdWxkVW5yZWdpc3RlclxuICAgICAgICAgICAgICAgID8gY29udHJvbC5fZGVmYXVsdFZhbHVlc1xuICAgICAgICAgICAgICAgIDogY29udHJvbC5fb3B0aW9ucy52YWx1ZXMgfHwgY29udHJvbC5fZGVmYXVsdFZhbHVlcywgbmFtZSwgZ2V0KGNvbnRyb2wuX29wdGlvbnMuZGVmYXVsdFZhbHVlcywgbmFtZSwgX3Byb3BzLmN1cnJlbnQuZGVmYXVsdFZhbHVlKSkpO1xuICAgICAgICAgICAgc2V0KGNvbnRyb2wuX2RlZmF1bHRWYWx1ZXMsIG5hbWUsIHZhbHVlKTtcbiAgICAgICAgICAgIGlmIChpc1VuZGVmaW5lZChnZXQoY29udHJvbC5fZm9ybVZhbHVlcywgbmFtZSkpKSB7XG4gICAgICAgICAgICAgICAgc2V0KGNvbnRyb2wuX2Zvcm1WYWx1ZXMsIG5hbWUsIHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAhaXNBcnJheUZpZWxkICYmXG4gICAgICAgICAgICBjb250cm9sLnJlZ2lzdGVyKG5hbWUsIHtcbiAgICAgICAgICAgICAgICAuLi5fcHJvcHMuY3VycmVudC5ydWxlcyxcbiAgICAgICAgICAgICAgICAuLi4oaXNCb29sZWFuKF9wcm9wcy5jdXJyZW50LmRpc2FibGVkKVxuICAgICAgICAgICAgICAgICAgICA/IHsgZGlzYWJsZWQ6IF9wcm9wcy5jdXJyZW50LmRpc2FibGVkIH1cbiAgICAgICAgICAgICAgICAgICAgOiB7fSksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgaWYgKF9wcm94eVJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZCA9IGdldChjb250cm9sLl9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgaWYgKGZpZWxkICYmIGZpZWxkLl9mKSB7XG4gICAgICAgICAgICAgICAgZmllbGQuX2YucmVmID0gX3Byb3h5UmVmLmN1cnJlbnQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgICAgIChpc0FycmF5RmllbGRcbiAgICAgICAgICAgICAgICA/IF9zaG91bGRVbnJlZ2lzdGVyRmllbGQgJiYgIWNvbnRyb2wuX3N0YXRlLmFjdGlvblxuICAgICAgICAgICAgICAgIDogX3Nob3VsZFVucmVnaXN0ZXJGaWVsZClcbiAgICAgICAgICAgICAgICA/IGNvbnRyb2wudW5yZWdpc3RlcihuYW1lKVxuICAgICAgICAgICAgICAgIDogdXBkYXRlTW91bnRlZChuYW1lLCBmYWxzZSk7XG4gICAgICAgIH07XG4gICAgfSwgW25hbWUsIGNvbnRyb2wsIGlzQXJyYXlGaWVsZCwgc2hvdWxkVW5yZWdpc3Rlcl0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGNvbnRyb2wuX3NldERpc2FibGVkRmllbGQoe1xuICAgICAgICAgICAgZGlzYWJsZWQsXG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICB9KTtcbiAgICB9LCBbZGlzYWJsZWQsIG5hbWUsIGNvbnRyb2xdKTtcbiAgICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgICAgICBmaWVsZCxcbiAgICAgICAgZm9ybVN0YXRlLFxuICAgICAgICBmaWVsZFN0YXRlLFxuICAgIH0pLCBbZmllbGQsIGZvcm1TdGF0ZSwgZmllbGRTdGF0ZV0pO1xufVxuXG4vKipcbiAqIENvbXBvbmVudCB3cmFwcGVyIGFyb3VuZCBgdXNlQ29udHJvbGxlcmAgZm9yIGNvbnRyb2xsZWQgaW5wdXRzLlxuICpcbiAqIEBzZWUgW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlY29udHJvbGxlci9jb250cm9sbGVyKVxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c3hcbiAqIDxDb250cm9sbGVyXG4gKiAgIGNvbnRyb2w9e2NvbnRyb2x9XG4gKiAgIG5hbWU9XCJ0ZXN0XCJcbiAqICAgcmVuZGVyPXsoeyBmaWVsZCwgZmllbGRTdGF0ZSwgZm9ybVN0YXRlIH0pID0+IDxpbnB1dCB7Li4uZmllbGR9IC8+fVxuICogLz5cbiAqIGBgYFxuICovXG5jb25zdCBDb250cm9sbGVyID0gKHByb3BzKSA9PiBwcm9wcy5yZW5kZXIodXNlQ29udHJvbGxlcihwcm9wcykpO1xuXG4vKipcbiAqIERpc3BsYXlzIHRoZSB2YWxpZGF0aW9uIGVycm9yIGZvciBhIHNpbmdsZSBmaWVsZC5cbiAqIFJlYWRzIGZyb20gYGNvbnRyb2xgIHdoZW4gcHJvdmlkZWQsIG90aGVyd2lzZSBmcm9tIHRoZSBuZWFyZXN0IGBGb3JtUHJvdmlkZXJgLlxuICpcbiAqIEBzZWUgW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlZm9ybXN0YXRlL2Vycm9ybWVzc2FnZSlcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiA8RXJyb3JNZXNzYWdlIGNvbnRyb2w9e2NvbnRyb2x9IG5hbWU9XCJlbWFpbFwiIGFzPVwicFwiIC8+XG4gKiA8RXJyb3JNZXNzYWdlIG5hbWU9XCJlbWFpbFwiIGFzPVwic3BhblwiIC8+XG4gKiA8RXJyb3JNZXNzYWdlIGNvbnRyb2w9e2NvbnRyb2x9IG5hbWU9XCJlbWFpbFwiXG4gKiAgIHJlbmRlcj17KHsgbWVzc2FnZSB9KSA9PiA8QWxlcnQ+e21lc3NhZ2V9PC9BbGVydD59IC8+XG4gKiBgYGBcbiAqL1xuY29uc3QgRXJyb3JNZXNzYWdlID0gKHsgYXMsIGNvbnRyb2wsIG5hbWUsIHJlbmRlciwgfSkgPT4ge1xuICAgIGNvbnN0IHsgZXJyb3JzIH0gPSB1c2VGb3JtU3RhdGUoe1xuICAgICAgICBjb250cm9sLFxuICAgICAgICBuYW1lOiBuYW1lLFxuICAgIH0pO1xuICAgIGNvbnN0IGVycm9yID0gZ2V0KGVycm9ycywgbmFtZSk7XG4gICAgaWYgKCFlcnJvcikge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgY29uc3QgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2UgfHwgJyc7XG4gICAgaWYgKHJlbmRlcikge1xuICAgICAgICByZXR1cm4gcmVuZGVyKHsgbWVzc2FnZSwgbWVzc2FnZXM6IGVycm9yLnR5cGVzIH0pO1xuICAgIH1cbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChhcyB8fCBSZWFjdC5GcmFnbWVudCwgbnVsbCwgbWVzc2FnZSk7XG59O1xuXG52YXIgZ2VuZXJhdGVJZCA9ICgpID0+IHR5cGVvZiBjcnlwdG8gIT09ICd1bmRlZmluZWQnICYmIGNyeXB0by5yYW5kb21VVUlEXG4gICAgPyBjcnlwdG8ucmFuZG9tVVVJRCgpXG4gICAgOiAneHh4eHh4eHgteHh4eC00eHh4LXl4eHgteHh4eHh4eHh4eHh4Jy5yZXBsYWNlKC9beHldL2csIChjKSA9PiB7XG4gICAgICAgIGNvbnN0IHIgPSAoTWF0aC5yYW5kb20oKSAqIDE2KSB8IDA7XG4gICAgICAgIHJldHVybiAoYyA9PT0gJ3gnID8gciA6IChyICYgMHgzKSB8IDB4OCkudG9TdHJpbmcoMTYpO1xuICAgIH0pO1xuXG52YXIgZ2V0Rm9jdXNGaWVsZE5hbWUgPSAobmFtZSwgaW5kZXgsIG9wdGlvbnMgPSB7fSkgPT4gb3B0aW9ucy5zaG91bGRGb2N1cyB8fCBpc1VuZGVmaW5lZChvcHRpb25zLnNob3VsZEZvY3VzKVxuICAgID8gb3B0aW9ucy5mb2N1c05hbWUgfHxcbiAgICAgICAgYCR7bmFtZX0uJHtpc1VuZGVmaW5lZChvcHRpb25zLmZvY3VzSW5kZXgpID8gaW5kZXggOiBvcHRpb25zLmZvY3VzSW5kZXh9LmBcbiAgICA6ICcnO1xuXG52YXIgZ2V0VmFsaWRhdGlvbk1vZGVzID0gKG1vZGUpID0+ICh7XG4gICAgaXNPblN1Ym1pdDogIW1vZGUgfHwgbW9kZSA9PT0gVkFMSURBVElPTl9NT0RFLm9uU3VibWl0LFxuICAgIGlzT25CbHVyOiBtb2RlID09PSBWQUxJREFUSU9OX01PREUub25CbHVyLFxuICAgIGlzT25DaGFuZ2U6IG1vZGUgPT09IFZBTElEQVRJT05fTU9ERS5vbkNoYW5nZSxcbiAgICBpc09uQWxsOiBtb2RlID09PSBWQUxJREFUSU9OX01PREUuYWxsLFxuICAgIGlzT25Ub3VjaDogbW9kZSA9PT0gVkFMSURBVElPTl9NT0RFLm9uVG91Y2hlZCxcbn0pO1xuXG52YXIgaXNXYXRjaGVkID0gKG5hbWUsIF9uYW1lcywgaXNCbHVyRXZlbnQpID0+IHtcbiAgICBpZiAoaXNCbHVyRXZlbnQpXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICBpZiAoX25hbWVzLndhdGNoQWxsIHx8IF9uYW1lcy53YXRjaC5oYXMobmFtZSkpXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIGZvciAoY29uc3Qgd2F0Y2hOYW1lIG9mIF9uYW1lcy53YXRjaCkge1xuICAgICAgICBpZiAobmFtZS5zdGFydHNXaXRoKHdhdGNoTmFtZSkgJiYgbmFtZS5jaGFyQXQod2F0Y2hOYW1lLmxlbmd0aCkgPT09ICcuJylcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG59O1xuXG5jb25zdCBpdGVyYXRlRmllbGRzQnlBY3Rpb24gPSAoZmllbGRzLCBhY3Rpb24sIGZpZWxkc05hbWVzKSA9PiB7XG4gICAgZm9yIChjb25zdCBrZXkgb2YgZmllbGRzTmFtZXMgfHwgT2JqZWN0LmtleXMoZmllbGRzKSkge1xuICAgICAgICBpZiAoa2V5ID09PSAnX2YnKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBmaWVsZCA9IGZpZWxkc05hbWVzID8gZ2V0KGZpZWxkcywga2V5KSA6IGZpZWxkc1trZXldO1xuICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgX2YgfSA9IGZpZWxkO1xuICAgICAgICAgICAgaWYgKF9mKSB7XG4gICAgICAgICAgICAgICAgaWYgKF9mLnJlZnMgJiYgX2YucmVmc1swXSAmJiBhY3Rpb24oX2YucmVmc1swXSwgX2YubmFtZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKF9mLnJlZiAmJiBhY3Rpb24oX2YucmVmLCBfZi5uYW1lKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpdGVyYXRlRmllbGRzQnlBY3Rpb24oZmllbGQsIGFjdGlvbikpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoaXNPYmplY3QoZmllbGQpIHx8IEFycmF5LmlzQXJyYXkoZmllbGQpKSB7XG4gICAgICAgICAgICAgICAgaWYgKGl0ZXJhdGVGaWVsZHNCeUFjdGlvbihmaWVsZCwgYWN0aW9uKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuO1xufTtcblxudmFyIHVwZGF0ZUZpZWxkQXJyYXlSb290RXJyb3IgPSAoZXJyb3JzLCBlcnJvciwgbmFtZSkgPT4ge1xuICAgIGNvbnN0IGV4aXN0aW5nRXJyb3JzID0gZ2V0KGVycm9ycywgbmFtZSk7XG4gICAgY29uc3QgZmllbGRBcnJheUVycm9ycyA9IEFycmF5LmlzQXJyYXkoZXhpc3RpbmdFcnJvcnMpID8gZXhpc3RpbmdFcnJvcnMgOiBbXTtcbiAgICBzZXQoZmllbGRBcnJheUVycm9ycywgUk9PVF9FUlJPUl9UWVBFLCBlcnJvcltuYW1lXSk7XG4gICAgc2V0KGVycm9ycywgbmFtZSwgZmllbGRBcnJheUVycm9ycyk7XG4gICAgcmV0dXJuIGVycm9ycztcbn07XG5cbnZhciBpc0VtcHR5T2JqZWN0ID0gKHZhbHVlKSA9PiBpc09iamVjdCh2YWx1ZSkgJiYgIU9iamVjdC5rZXlzKHZhbHVlKS5sZW5ndGg7XG5cbnZhciBpc0hUTUxFbGVtZW50ID0gKHZhbHVlKSA9PiB7XG4gICAgaWYgKCFpc1dlYikge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IG93bmVyID0gdmFsdWUgPyB2YWx1ZS5vd25lckRvY3VtZW50IDogMDtcbiAgICByZXR1cm4gKHZhbHVlIGluc3RhbmNlb2ZcbiAgICAgICAgKG93bmVyICYmIG93bmVyLmRlZmF1bHRWaWV3ID8gb3duZXIuZGVmYXVsdFZpZXcuSFRNTEVsZW1lbnQgOiBIVE1MRWxlbWVudCkpO1xufTtcblxudmFyIGlzUmFkaW9JbnB1dCA9IChlbGVtZW50KSA9PiBlbGVtZW50LnR5cGUgPT09ICdyYWRpbyc7XG5cbnZhciBpc1JlZ2V4ID0gKHZhbHVlKSA9PiB2YWx1ZSBpbnN0YW5jZW9mIFJlZ0V4cDtcblxudmFyIGFwcGVuZEVycm9ycyA9IChuYW1lLCB2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEsIGVycm9ycywgdHlwZSwgbWVzc2FnZSkgPT4gdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhXG4gICAgPyB7XG4gICAgICAgIC4uLmVycm9yc1tuYW1lXSxcbiAgICAgICAgdHlwZXM6IHtcbiAgICAgICAgICAgIC4uLihlcnJvcnNbbmFtZV0gJiYgZXJyb3JzW25hbWVdLnR5cGVzID8gZXJyb3JzW25hbWVdLnR5cGVzIDoge30pLFxuICAgICAgICAgICAgW3R5cGVdOiBtZXNzYWdlIHx8IHRydWUsXG4gICAgICAgIH0sXG4gICAgfVxuICAgIDoge307XG5cbmNvbnN0IGRlZmF1bHRSZXN1bHQgPSB7XG4gICAgdmFsdWU6IGZhbHNlLFxuICAgIGlzVmFsaWQ6IGZhbHNlLFxufTtcbmNvbnN0IHZhbGlkUmVzdWx0ID0geyB2YWx1ZTogdHJ1ZSwgaXNWYWxpZDogdHJ1ZSB9O1xudmFyIGdldENoZWNrYm94VmFsdWUgPSAob3B0aW9ucykgPT4ge1xuICAgIGlmICghQXJyYXkuaXNBcnJheShvcHRpb25zKSkge1xuICAgICAgICByZXR1cm4gZGVmYXVsdFJlc3VsdDtcbiAgICB9XG4gICAgaWYgKG9wdGlvbnMubGVuZ3RoID4gMSkge1xuICAgICAgICBjb25zdCB2YWx1ZXMgPSBvcHRpb25zXG4gICAgICAgICAgICAuZmlsdGVyKChvcHRpb24pID0+IG9wdGlvbiAmJiBvcHRpb24uY2hlY2tlZCAmJiAhb3B0aW9uLmRpc2FibGVkKVxuICAgICAgICAgICAgLm1hcCgob3B0aW9uKSA9PiBvcHRpb24udmFsdWUpO1xuICAgICAgICByZXR1cm4geyB2YWx1ZTogdmFsdWVzLCBpc1ZhbGlkOiAhIXZhbHVlcy5sZW5ndGggfTtcbiAgICB9XG4gICAgY29uc3Qgb3B0aW9uID0gb3B0aW9uc1swXTtcbiAgICBpZiAoIW9wdGlvbiB8fCAhb3B0aW9uLmNoZWNrZWQgfHwgb3B0aW9uLmRpc2FibGVkKSB7XG4gICAgICAgIHJldHVybiBkZWZhdWx0UmVzdWx0O1xuICAgIH1cbiAgICBpZiAoIW9wdGlvbi5hdHRyaWJ1dGVzIHx8ICEoJ3ZhbHVlJyBpbiBvcHRpb24uYXR0cmlidXRlcykpIHtcbiAgICAgICAgcmV0dXJuIHZhbGlkUmVzdWx0O1xuICAgIH1cbiAgICByZXR1cm4gaXNVbmRlZmluZWQob3B0aW9uLnZhbHVlKSB8fCBvcHRpb24udmFsdWUgPT09ICcnXG4gICAgICAgID8gdmFsaWRSZXN1bHRcbiAgICAgICAgOiB7IHZhbHVlOiBvcHRpb24udmFsdWUsIGlzVmFsaWQ6IHRydWUgfTtcbn07XG5cbmNvbnN0IGRlZmF1bHRSZXR1cm4gPSB7XG4gICAgaXNWYWxpZDogZmFsc2UsXG4gICAgdmFsdWU6IG51bGwsXG59O1xudmFyIGdldFJhZGlvVmFsdWUgPSAob3B0aW9ucykgPT4gQXJyYXkuaXNBcnJheShvcHRpb25zKVxuICAgID8gb3B0aW9ucy5yZWR1Y2UoKHByZXZpb3VzLCBvcHRpb24pID0+IG9wdGlvbiAmJiBvcHRpb24uY2hlY2tlZCAmJiAhb3B0aW9uLmRpc2FibGVkXG4gICAgICAgID8ge1xuICAgICAgICAgICAgaXNWYWxpZDogdHJ1ZSxcbiAgICAgICAgICAgIHZhbHVlOiBvcHRpb24udmFsdWUsXG4gICAgICAgIH1cbiAgICAgICAgOiBwcmV2aW91cywgZGVmYXVsdFJldHVybilcbiAgICA6IGRlZmF1bHRSZXR1cm47XG5cbmZ1bmN0aW9uIGdldFZhbGlkYXRlRXJyb3IocmVzdWx0LCByZWYsIHR5cGUgPSAndmFsaWRhdGUnKSB7XG4gICAgaWYgKGlzU3RyaW5nKHJlc3VsdCkgfHxcbiAgICAgICAgKEFycmF5LmlzQXJyYXkocmVzdWx0KSAmJiByZXN1bHQuZXZlcnkoaXNTdHJpbmcpKSB8fFxuICAgICAgICAoaXNCb29sZWFuKHJlc3VsdCkgJiYgIXJlc3VsdCkpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHR5cGUsXG4gICAgICAgICAgICBtZXNzYWdlOiBpc1N0cmluZyhyZXN1bHQpID8gcmVzdWx0IDogJycsXG4gICAgICAgICAgICByZWYsXG4gICAgICAgIH07XG4gICAgfVxufVxuXG52YXIgZ2V0VmFsdWVBbmRNZXNzYWdlID0gKHZhbGlkYXRpb25EYXRhKSA9PiBpc09iamVjdCh2YWxpZGF0aW9uRGF0YSkgJiYgIWlzUmVnZXgodmFsaWRhdGlvbkRhdGEpXG4gICAgPyB2YWxpZGF0aW9uRGF0YVxuICAgIDoge1xuICAgICAgICB2YWx1ZTogdmFsaWRhdGlvbkRhdGEsXG4gICAgICAgIG1lc3NhZ2U6ICcnLFxuICAgIH07XG5cbnZhciB2YWxpZGF0ZUZpZWxkID0gYXN5bmMgKGZpZWxkLCBkaXNhYmxlZEZpZWxkTmFtZXMsIGZvcm1WYWx1ZXMsIHZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSwgc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbiwgaXNGaWVsZEFycmF5KSA9PiB7XG4gICAgY29uc3QgeyByZWYsIHJlZnMsIHJlcXVpcmVkLCBtYXhMZW5ndGgsIG1pbkxlbmd0aCwgbWluLCBtYXgsIHBhdHRlcm4sIHZhbGlkYXRlLCBuYW1lLCB2YWx1ZUFzTnVtYmVyLCBtb3VudCwgX2MsIH0gPSBmaWVsZC5fZjtcbiAgICBjb25zdCBpbnB1dFZhbHVlID0gZ2V0KGZvcm1WYWx1ZXMsIG5hbWUpO1xuICAgIGlmICghbW91bnQgfHwgZGlzYWJsZWRGaWVsZE5hbWVzLmhhcyhuYW1lKSkge1xuICAgICAgICByZXR1cm4ge307XG4gICAgfVxuICAgIGNvbnN0IGlucHV0UmVmID0gcmVmcyA/IHJlZnNbMF0gOiByZWY7XG4gICAgY29uc3Qgc2V0Q3VzdG9tVmFsaWRpdHkgPSAobWVzc2FnZSkgPT4ge1xuICAgICAgICBpZiAoc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbiAmJiBpbnB1dFJlZi5yZXBvcnRWYWxpZGl0eSkge1xuICAgICAgICAgICAgY29uc3QgdmFsaWRpdHlNZXNzYWdlID0gaXNCb29sZWFuKG1lc3NhZ2UpID8gJycgOiBtZXNzYWdlIHx8ICcnO1xuICAgICAgICAgICAgaWYgKHJlZnMpIHtcbiAgICAgICAgICAgICAgICByZWZzLmZvckVhY2goKHJlZikgPT4gaXNGdW5jdGlvbihyZWYuc2V0Q3VzdG9tVmFsaWRpdHkpICYmXG4gICAgICAgICAgICAgICAgICAgIHJlZi5zZXRDdXN0b21WYWxpZGl0eSh2YWxpZGl0eU1lc3NhZ2UpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGlucHV0UmVmLnNldEN1c3RvbVZhbGlkaXR5KHZhbGlkaXR5TWVzc2FnZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpbnB1dFJlZi5yZXBvcnRWYWxpZGl0eSgpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBlcnJvciA9IHt9O1xuICAgIGNvbnN0IGlzUmFkaW8gPSBpc1JhZGlvSW5wdXQocmVmKTtcbiAgICBjb25zdCBpc0NoZWNrQm94ID0gaXNDaGVja0JveElucHV0KHJlZik7XG4gICAgY29uc3QgaXNSYWRpb09yQ2hlY2tib3ggPSBpc1JhZGlvIHx8IGlzQ2hlY2tCb3g7XG4gICAgY29uc3QgaXNFbXB0eSA9ICgodmFsdWVBc051bWJlciB8fCBpc0ZpbGVJbnB1dChyZWYpKSAmJlxuICAgICAgICBpc1VuZGVmaW5lZChyZWYudmFsdWUpICYmXG4gICAgICAgIGlzVW5kZWZpbmVkKGlucHV0VmFsdWUpKSB8fFxuICAgICAgICAoaXNIVE1MRWxlbWVudChyZWYpICYmIHJlZi52YWx1ZSA9PT0gJycgJiYgIV9jKSB8fFxuICAgICAgICBpbnB1dFZhbHVlID09PSAnJyB8fFxuICAgICAgICAoQXJyYXkuaXNBcnJheShpbnB1dFZhbHVlKSAmJiAhaW5wdXRWYWx1ZS5sZW5ndGgpO1xuICAgIGNvbnN0IGFwcGVuZEVycm9yc0N1cnJ5ID0gYXBwZW5kRXJyb3JzLmJpbmQobnVsbCwgbmFtZSwgdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhLCBlcnJvcik7XG4gICAgY29uc3QgZ2V0TWluTWF4TWVzc2FnZSA9IChleGNlZWRNYXgsIG1heExlbmd0aE1lc3NhZ2UsIG1pbkxlbmd0aE1lc3NhZ2UsIG1heFR5cGUgPSBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1heExlbmd0aCwgbWluVHlwZSA9IElOUFVUX1ZBTElEQVRJT05fUlVMRVMubWluTGVuZ3RoKSA9PiB7XG4gICAgICAgIGNvbnN0IG1lc3NhZ2UgPSBleGNlZWRNYXggPyBtYXhMZW5ndGhNZXNzYWdlIDogbWluTGVuZ3RoTWVzc2FnZTtcbiAgICAgICAgZXJyb3JbbmFtZV0gPSB7XG4gICAgICAgICAgICB0eXBlOiBleGNlZWRNYXggPyBtYXhUeXBlIDogbWluVHlwZSxcbiAgICAgICAgICAgIG1lc3NhZ2UsXG4gICAgICAgICAgICByZWYsXG4gICAgICAgICAgICAuLi5hcHBlbmRFcnJvcnNDdXJyeShleGNlZWRNYXggPyBtYXhUeXBlIDogbWluVHlwZSwgbWVzc2FnZSksXG4gICAgICAgIH07XG4gICAgfTtcbiAgICBpZiAoaXNGaWVsZEFycmF5XG4gICAgICAgID8gIUFycmF5LmlzQXJyYXkoaW5wdXRWYWx1ZSkgfHwgIWlucHV0VmFsdWUubGVuZ3RoXG4gICAgICAgIDogcmVxdWlyZWQgJiZcbiAgICAgICAgICAgICgoIWlzUmFkaW9PckNoZWNrYm94ICYmIChpc0VtcHR5IHx8IGlzTnVsbE9yVW5kZWZpbmVkKGlucHV0VmFsdWUpKSkgfHxcbiAgICAgICAgICAgICAgICAoaXNCb29sZWFuKGlucHV0VmFsdWUpICYmICFpbnB1dFZhbHVlKSB8fFxuICAgICAgICAgICAgICAgIChpc0NoZWNrQm94ICYmICFnZXRDaGVja2JveFZhbHVlKHJlZnMpLmlzVmFsaWQpIHx8XG4gICAgICAgICAgICAgICAgKGlzUmFkaW8gJiYgIWdldFJhZGlvVmFsdWUocmVmcykuaXNWYWxpZCkpKSB7XG4gICAgICAgIGNvbnN0IHsgdmFsdWUsIG1lc3NhZ2UgfSA9IGlzU3RyaW5nKHJlcXVpcmVkKVxuICAgICAgICAgICAgPyB7IHZhbHVlOiAhIXJlcXVpcmVkLCBtZXNzYWdlOiByZXF1aXJlZCB9XG4gICAgICAgICAgICA6IGdldFZhbHVlQW5kTWVzc2FnZShyZXF1aXJlZCk7XG4gICAgICAgIGlmICh2YWx1ZSkge1xuICAgICAgICAgICAgZXJyb3JbbmFtZV0gPSB7XG4gICAgICAgICAgICAgICAgdHlwZTogSU5QVVRfVkFMSURBVElPTl9SVUxFUy5yZXF1aXJlZCxcbiAgICAgICAgICAgICAgICBtZXNzYWdlLFxuICAgICAgICAgICAgICAgIHJlZjogaW5wdXRSZWYsXG4gICAgICAgICAgICAgICAgLi4uYXBwZW5kRXJyb3JzQ3VycnkoSU5QVVRfVkFMSURBVElPTl9SVUxFUy5yZXF1aXJlZCwgbWVzc2FnZSksXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKCF2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICBzZXRDdXN0b21WYWxpZGl0eShtZXNzYWdlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFpc0VtcHR5ICYmICghaXNOdWxsT3JVbmRlZmluZWQobWluKSB8fCAhaXNOdWxsT3JVbmRlZmluZWQobWF4KSkpIHtcbiAgICAgICAgbGV0IGV4Y2VlZE1heDtcbiAgICAgICAgbGV0IGV4Y2VlZE1pbjtcbiAgICAgICAgY29uc3QgbWF4T3V0cHV0ID0gZ2V0VmFsdWVBbmRNZXNzYWdlKG1heCk7XG4gICAgICAgIGNvbnN0IG1pbk91dHB1dCA9IGdldFZhbHVlQW5kTWVzc2FnZShtaW4pO1xuICAgICAgICBpZiAoIWlzTnVsbE9yVW5kZWZpbmVkKGlucHV0VmFsdWUpICYmXG4gICAgICAgICAgICAhaXNEYXRlT2JqZWN0KGlucHV0VmFsdWUpICYmXG4gICAgICAgICAgICAhaXNOYU4oaW5wdXRWYWx1ZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlTnVtYmVyID0gcmVmLnZhbHVlQXNOdW1iZXIgfHxcbiAgICAgICAgICAgICAgICAoaW5wdXRWYWx1ZSA/ICtpbnB1dFZhbHVlIDogaW5wdXRWYWx1ZSk7XG4gICAgICAgICAgICBpZiAoIWlzTnVsbE9yVW5kZWZpbmVkKG1heE91dHB1dC52YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICBleGNlZWRNYXggPSB2YWx1ZU51bWJlciA+IG1heE91dHB1dC52YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghaXNOdWxsT3JVbmRlZmluZWQobWluT3V0cHV0LnZhbHVlKSkge1xuICAgICAgICAgICAgICAgIGV4Y2VlZE1pbiA9IHZhbHVlTnVtYmVyIDwgbWluT3V0cHV0LnZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgdmFsdWVEYXRlID0gcmVmLnZhbHVlQXNEYXRlIHx8IG5ldyBEYXRlKGlucHV0VmFsdWUpO1xuICAgICAgICAgICAgY29uc3QgY29udmVydFRpbWVUb0RhdGUgPSAodGltZSkgPT4gbmV3IERhdGUobmV3IERhdGUoKS50b0RhdGVTdHJpbmcoKSArICcgJyArIHRpbWUpO1xuICAgICAgICAgICAgY29uc3QgaXNUaW1lID0gcmVmLnR5cGUgPT0gJ3RpbWUnO1xuICAgICAgICAgICAgY29uc3QgaXNXZWVrID0gcmVmLnR5cGUgPT0gJ3dlZWsnO1xuICAgICAgICAgICAgaWYgKGlzU3RyaW5nKG1heE91dHB1dC52YWx1ZSkgJiYgaW5wdXRWYWx1ZSkge1xuICAgICAgICAgICAgICAgIGV4Y2VlZE1heCA9IGlzVGltZVxuICAgICAgICAgICAgICAgICAgICA/IGNvbnZlcnRUaW1lVG9EYXRlKGlucHV0VmFsdWUpID4gY29udmVydFRpbWVUb0RhdGUobWF4T3V0cHV0LnZhbHVlKVxuICAgICAgICAgICAgICAgICAgICA6IGlzV2Vla1xuICAgICAgICAgICAgICAgICAgICAgICAgPyBpbnB1dFZhbHVlID4gbWF4T3V0cHV0LnZhbHVlXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHZhbHVlRGF0ZSA+IG5ldyBEYXRlKG1heE91dHB1dC52YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXNTdHJpbmcobWluT3V0cHV0LnZhbHVlKSAmJiBpbnB1dFZhbHVlKSB7XG4gICAgICAgICAgICAgICAgZXhjZWVkTWluID0gaXNUaW1lXG4gICAgICAgICAgICAgICAgICAgID8gY29udmVydFRpbWVUb0RhdGUoaW5wdXRWYWx1ZSkgPCBjb252ZXJ0VGltZVRvRGF0ZShtaW5PdXRwdXQudmFsdWUpXG4gICAgICAgICAgICAgICAgICAgIDogaXNXZWVrXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGlucHV0VmFsdWUgPCBtaW5PdXRwdXQudmFsdWVcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdmFsdWVEYXRlIDwgbmV3IERhdGUobWluT3V0cHV0LnZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoZXhjZWVkTWF4IHx8IGV4Y2VlZE1pbikge1xuICAgICAgICAgICAgZ2V0TWluTWF4TWVzc2FnZSghIWV4Y2VlZE1heCwgbWF4T3V0cHV0Lm1lc3NhZ2UsIG1pbk91dHB1dC5tZXNzYWdlLCBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLm1heCwgSU5QVVRfVkFMSURBVElPTl9SVUxFUy5taW4pO1xuICAgICAgICAgICAgaWYgKCF2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICBzZXRDdXN0b21WYWxpZGl0eShlcnJvcltuYW1lXS5tZXNzYWdlKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKChtYXhMZW5ndGggfHwgbWluTGVuZ3RoKSAmJlxuICAgICAgICAhaXNFbXB0eSAmJlxuICAgICAgICAoaXNTdHJpbmcoaW5wdXRWYWx1ZSkgfHwgKGlzRmllbGRBcnJheSAmJiBBcnJheS5pc0FycmF5KGlucHV0VmFsdWUpKSkpIHtcbiAgICAgICAgY29uc3QgbWF4TGVuZ3RoT3V0cHV0ID0gZ2V0VmFsdWVBbmRNZXNzYWdlKG1heExlbmd0aCk7XG4gICAgICAgIGNvbnN0IG1pbkxlbmd0aE91dHB1dCA9IGdldFZhbHVlQW5kTWVzc2FnZShtaW5MZW5ndGgpO1xuICAgICAgICBjb25zdCBleGNlZWRNYXggPSAhaXNOdWxsT3JVbmRlZmluZWQobWF4TGVuZ3RoT3V0cHV0LnZhbHVlKSAmJlxuICAgICAgICAgICAgaW5wdXRWYWx1ZS5sZW5ndGggPiArbWF4TGVuZ3RoT3V0cHV0LnZhbHVlO1xuICAgICAgICBjb25zdCBleGNlZWRNaW4gPSAhaXNOdWxsT3JVbmRlZmluZWQobWluTGVuZ3RoT3V0cHV0LnZhbHVlKSAmJlxuICAgICAgICAgICAgaW5wdXRWYWx1ZS5sZW5ndGggPCArbWluTGVuZ3RoT3V0cHV0LnZhbHVlO1xuICAgICAgICBpZiAoZXhjZWVkTWF4IHx8IGV4Y2VlZE1pbikge1xuICAgICAgICAgICAgZ2V0TWluTWF4TWVzc2FnZShleGNlZWRNYXgsIG1heExlbmd0aE91dHB1dC5tZXNzYWdlLCBtaW5MZW5ndGhPdXRwdXQubWVzc2FnZSk7XG4gICAgICAgICAgICBpZiAoIXZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSkge1xuICAgICAgICAgICAgICAgIHNldEN1c3RvbVZhbGlkaXR5KGVycm9yW25hbWVdLm1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgIHJldHVybiBlcnJvcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAocGF0dGVybiAmJiAhaXNFbXB0eSAmJiBpc1N0cmluZyhpbnB1dFZhbHVlKSkge1xuICAgICAgICBjb25zdCB7IHZhbHVlOiBwYXR0ZXJuVmFsdWUsIG1lc3NhZ2UgfSA9IGdldFZhbHVlQW5kTWVzc2FnZShwYXR0ZXJuKTtcbiAgICAgICAgaWYgKGlzUmVnZXgocGF0dGVyblZhbHVlKSAmJiAhaW5wdXRWYWx1ZS5tYXRjaChwYXR0ZXJuVmFsdWUpKSB7XG4gICAgICAgICAgICBlcnJvcltuYW1lXSA9IHtcbiAgICAgICAgICAgICAgICB0eXBlOiBJTlBVVF9WQUxJREFUSU9OX1JVTEVTLnBhdHRlcm4sXG4gICAgICAgICAgICAgICAgbWVzc2FnZSxcbiAgICAgICAgICAgICAgICByZWYsXG4gICAgICAgICAgICAgICAgLi4uYXBwZW5kRXJyb3JzQ3VycnkoSU5QVVRfVkFMSURBVElPTl9SVUxFUy5wYXR0ZXJuLCBtZXNzYWdlKSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBpZiAoIXZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSkge1xuICAgICAgICAgICAgICAgIHNldEN1c3RvbVZhbGlkaXR5KG1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgIHJldHVybiBlcnJvcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAodmFsaWRhdGUpIHtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb24odmFsaWRhdGUpKSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB2YWxpZGF0ZShpbnB1dFZhbHVlLCBmb3JtVmFsdWVzKTtcbiAgICAgICAgICAgIGNvbnN0IHZhbGlkYXRlRXJyb3IgPSBnZXRWYWxpZGF0ZUVycm9yKHJlc3VsdCwgaW5wdXRSZWYpO1xuICAgICAgICAgICAgaWYgKHZhbGlkYXRlRXJyb3IpIHtcbiAgICAgICAgICAgICAgICBlcnJvcltuYW1lXSA9IHtcbiAgICAgICAgICAgICAgICAgICAgLi4udmFsaWRhdGVFcnJvcixcbiAgICAgICAgICAgICAgICAgICAgLi4uYXBwZW5kRXJyb3JzQ3VycnkoSU5QVVRfVkFMSURBVElPTl9SVUxFUy52YWxpZGF0ZSwgdmFsaWRhdGVFcnJvci5tZXNzYWdlKSxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIGlmICghdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldEN1c3RvbVZhbGlkaXR5KHZhbGlkYXRlRXJyb3IubWVzc2FnZSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBlcnJvcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoaXNPYmplY3QodmFsaWRhdGUpKSB7XG4gICAgICAgICAgICBsZXQgdmFsaWRhdGlvblJlc3VsdCA9IHt9O1xuICAgICAgICAgICAgZm9yIChjb25zdCBrZXkgaW4gdmFsaWRhdGUpIHtcbiAgICAgICAgICAgICAgICBpZiAoIWlzRW1wdHlPYmplY3QodmFsaWRhdGlvblJlc3VsdCkgJiYgIXZhbGlkYXRlQWxsRmllbGRDcml0ZXJpYSkge1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsaWRhdGVFcnJvciA9IGdldFZhbGlkYXRlRXJyb3IoYXdhaXQgdmFsaWRhdGVba2V5XShpbnB1dFZhbHVlLCBmb3JtVmFsdWVzKSwgaW5wdXRSZWYsIGtleSk7XG4gICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRlRXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgdmFsaWRhdGlvblJlc3VsdCA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnZhbGlkYXRlRXJyb3IsXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5hcHBlbmRFcnJvcnNDdXJyeShrZXksIHZhbGlkYXRlRXJyb3IubWVzc2FnZSksXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIGlmICghdmFsaWRhdGVBbGxGaWVsZENyaXRlcmlhKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRDdXN0b21WYWxpZGl0eSh2YWxpZGF0ZUVycm9yLm1lc3NhZ2UpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVycm9yW25hbWVdID0gdmFsaWRhdGlvblJlc3VsdDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghaXNFbXB0eU9iamVjdCh2YWxpZGF0aW9uUmVzdWx0KSkge1xuICAgICAgICAgICAgICAgIGVycm9yW25hbWVdID0ge1xuICAgICAgICAgICAgICAgICAgICByZWY6IGlucHV0UmVmLFxuICAgICAgICAgICAgICAgICAgICAuLi52YWxpZGF0aW9uUmVzdWx0LFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgaWYgKCF2YWxpZGF0ZUFsbEZpZWxkQ3JpdGVyaWEpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGVycm9yO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBmaWVsZEVycm9yID0gZXJyb3JbbmFtZV07XG4gICAgc2V0Q3VzdG9tVmFsaWRpdHkoZmllbGRFcnJvciA/IGZpZWxkRXJyb3IubWVzc2FnZSA6IHRydWUpO1xuICAgIHJldHVybiBlcnJvcjtcbn07XG5cbnZhciBjb252ZXJ0VG9BcnJheVBheWxvYWQgPSAodmFsdWUpID0+IChBcnJheS5pc0FycmF5KHZhbHVlKSA/IHZhbHVlIDogW3ZhbHVlXSk7XG5cbnZhciBhcHBlbmRBdCA9IChkYXRhLCB2YWx1ZSkgPT4gW1xuICAgIC4uLmRhdGEsXG4gICAgLi4uY29udmVydFRvQXJyYXlQYXlsb2FkKHZhbHVlKSxcbl07XG5cbnZhciBmaWxsRW1wdHlBcnJheSA9ICh2YWx1ZSkgPT4gQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyB2YWx1ZS5tYXAoKCkgPT4gdW5kZWZpbmVkKSA6IHVuZGVmaW5lZDtcblxuZnVuY3Rpb24gaW5zZXJ0KGRhdGEsIGluZGV4LCB2YWx1ZSkge1xuICAgIHJldHVybiBbXG4gICAgICAgIC4uLmRhdGEuc2xpY2UoMCwgaW5kZXgpLFxuICAgICAgICAuLi5jb252ZXJ0VG9BcnJheVBheWxvYWQodmFsdWUpLFxuICAgICAgICAuLi5kYXRhLnNsaWNlKGluZGV4KSxcbiAgICBdO1xufVxuXG52YXIgbW92ZUFycmF5QXQgPSAoZGF0YSwgZnJvbSwgdG8pID0+IHtcbiAgICBpZiAoIUFycmF5LmlzQXJyYXkoZGF0YSkpIHtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICBpZiAoaXNVbmRlZmluZWQoZGF0YVt0b10pKSB7XG4gICAgICAgIGRhdGFbdG9dID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBkYXRhLnNwbGljZSh0bywgMCwgZGF0YS5zcGxpY2UoZnJvbSwgMSlbMF0pO1xuICAgIHJldHVybiBkYXRhO1xufTtcblxudmFyIHByZXBlbmRBdCA9IChkYXRhLCB2YWx1ZSkgPT4gW1xuICAgIC4uLmNvbnZlcnRUb0FycmF5UGF5bG9hZCh2YWx1ZSksXG4gICAgLi4uY29udmVydFRvQXJyYXlQYXlsb2FkKGRhdGEpLFxuXTtcblxudmFyIGNvbXBhY3QgPSAodmFsdWUpID0+IEFycmF5LmlzQXJyYXkodmFsdWUpID8gdmFsdWUuZmlsdGVyKEJvb2xlYW4pIDogW107XG5cbmZ1bmN0aW9uIHJlbW92ZUF0SW5kZXhlcyhkYXRhLCBpbmRleGVzKSB7XG4gICAgbGV0IGkgPSAwO1xuICAgIGNvbnN0IHRlbXAgPSBbLi4uZGF0YV07XG4gICAgZm9yIChjb25zdCBpbmRleCBvZiBpbmRleGVzKSB7XG4gICAgICAgIHRlbXAuc3BsaWNlKGluZGV4IC0gaSwgMSk7XG4gICAgICAgIGkrKztcbiAgICB9XG4gICAgcmV0dXJuIGNvbXBhY3QodGVtcCkubGVuZ3RoID8gdGVtcCA6IFtdO1xufVxudmFyIHJlbW92ZUFycmF5QXQgPSAoZGF0YSwgaW5kZXgpID0+IGlzVW5kZWZpbmVkKGluZGV4KVxuICAgID8gW11cbiAgICA6IHJlbW92ZUF0SW5kZXhlcyhkYXRhLCBbLi4ubmV3IFNldChjb252ZXJ0VG9BcnJheVBheWxvYWQoaW5kZXgpKV0uc29ydCgoYSwgYikgPT4gYSAtIGIpKTtcblxudmFyIHN3YXBBcnJheUF0ID0gKGRhdGEsIGluZGV4QSwgaW5kZXhCKSA9PiB7XG4gICAgW2RhdGFbaW5kZXhBXSwgZGF0YVtpbmRleEJdXSA9IFtkYXRhW2luZGV4Ql0sIGRhdGFbaW5kZXhBXV07XG59O1xuXG5mdW5jdGlvbiBiYXNlR2V0KG9iamVjdCwgdXBkYXRlUGF0aCkge1xuICAgIGNvbnN0IGxlbmd0aCA9IHVwZGF0ZVBhdGgubGVuZ3RoIC0gMTtcbiAgICBsZXQgaW5kZXggPSAwO1xuICAgIHdoaWxlIChpbmRleCA8IGxlbmd0aCkge1xuICAgICAgICBpZiAoaXNOdWxsT3JVbmRlZmluZWQob2JqZWN0KSkge1xuICAgICAgICAgICAgb2JqZWN0ID0gdW5kZWZpbmVkO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgb2JqZWN0ID0gb2JqZWN0W3VwZGF0ZVBhdGhbaW5kZXhdXTtcbiAgICAgICAgaW5kZXgrKztcbiAgICB9XG4gICAgcmV0dXJuIG9iamVjdDtcbn1cbmZ1bmN0aW9uIGlzRW1wdHlBcnJheShvYmopIHtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBvYmopIHtcbiAgICAgICAgaWYgKG9iai5oYXNPd25Qcm9wZXJ0eShrZXkpICYmICFpc1VuZGVmaW5lZChvYmpba2V5XSkpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIHVuc2V0KG9iamVjdCwgcGF0aCkge1xuICAgIGlmIChpc1N0cmluZyhwYXRoKSAmJiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwYXRoKSkge1xuICAgICAgICBkZWxldGUgb2JqZWN0W3BhdGhdO1xuICAgICAgICByZXR1cm4gb2JqZWN0O1xuICAgIH1cbiAgICBjb25zdCBwYXRocyA9IEFycmF5LmlzQXJyYXkocGF0aClcbiAgICAgICAgPyBwYXRoXG4gICAgICAgIDogaXNLZXkocGF0aClcbiAgICAgICAgICAgID8gW3BhdGhdXG4gICAgICAgICAgICA6IHN0cmluZ1RvUGF0aChwYXRoKTtcbiAgICBpZiAocGF0aHMuc29tZSgoc2VnbWVudCkgPT4gUFJPVE9UWVBFX0tFWVdPUkRTLmluY2x1ZGVzKFN0cmluZyhzZWdtZW50KSkpKSB7XG4gICAgICAgIHJldHVybiBvYmplY3Q7XG4gICAgfVxuICAgIGNvbnN0IGNoaWxkT2JqZWN0ID0gcGF0aHMubGVuZ3RoID09PSAxID8gb2JqZWN0IDogYmFzZUdldChvYmplY3QsIHBhdGhzKTtcbiAgICBjb25zdCBpbmRleCA9IHBhdGhzLmxlbmd0aCAtIDE7XG4gICAgY29uc3Qga2V5ID0gcGF0aHNbaW5kZXhdO1xuICAgIGlmIChjaGlsZE9iamVjdCkge1xuICAgICAgICBkZWxldGUgY2hpbGRPYmplY3Rba2V5XTtcbiAgICB9XG4gICAgaWYgKGluZGV4ICE9PSAwICYmXG4gICAgICAgICgoaXNPYmplY3QoY2hpbGRPYmplY3QpICYmIGlzRW1wdHlPYmplY3QoY2hpbGRPYmplY3QpKSB8fFxuICAgICAgICAgICAgKEFycmF5LmlzQXJyYXkoY2hpbGRPYmplY3QpICYmIGlzRW1wdHlBcnJheShjaGlsZE9iamVjdCkpKSkge1xuICAgICAgICB1bnNldChvYmplY3QsIHBhdGhzLnNsaWNlKDAsIC0xKSk7XG4gICAgfVxuICAgIHJldHVybiBvYmplY3Q7XG59XG5cbnZhciB1cGRhdGVBdCA9IChmaWVsZFZhbHVlcywgaW5kZXgsIHZhbHVlKSA9PiB7XG4gICAgZmllbGRWYWx1ZXNbaW5kZXhdID0gdmFsdWU7XG4gICAgcmV0dXJuIGZpZWxkVmFsdWVzO1xufTtcblxuLyoqXG4gKiBIb29rIGZvciBkeW5hbWljIGZpZWxkIGFycmF5cy4gUHJvdmlkZXMgYGZpZWxkc2AgYW5kIG11dGF0aW9uIG1ldGhvZHM6XG4gKiBgYXBwZW5kYCwgYHByZXBlbmRgLCBgcmVtb3ZlYCwgYGluc2VydGAsIGBzd2FwYCwgYG1vdmVgLCBgdXBkYXRlYCwgYHJlcGxhY2VgLlxuICpcbiAqIEBzZWUgW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlZmllbGRhcnJheSlcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBjb25zdCB7IGZpZWxkcywgYXBwZW5kIH0gPSB1c2VGaWVsZEFycmF5KHsgY29udHJvbCwgbmFtZTogXCJpdGVtc1wiIH0pO1xuICogcmV0dXJuIGZpZWxkcy5tYXAoKGYsIGkpID0+IDxpbnB1dCBrZXk9e2YuaWR9IHsuLi5yZWdpc3RlcihgaXRlbXMuJHtpfS5uYW1lYCl9IC8+KTtcbiAqIGBgYFxuICovXG5mdW5jdGlvbiB1c2VGaWVsZEFycmF5KHByb3BzKSB7XG4gICAgY29uc3QgZm9ybUNvbnRyb2wgPSB1c2VGb3JtQ29udHJvbENvbnRleHQoKTtcbiAgICBjb25zdCB7IGNvbnRyb2wgPSBmb3JtQ29udHJvbCwgbmFtZSwga2V5TmFtZSA9ICdpZCcsIGRpc2FibGVkLCBzaG91bGRVbnJlZ2lzdGVyLCBydWxlcywgfSA9IHByb3BzO1xuICAgIGNvbnN0IGdldEN1cnJlbnRGaWVsZEFycmF5ID0gKCkgPT4gY29udHJvbC5fZ2V0RmllbGRBcnJheShuYW1lKTtcbiAgICBjb25zdCBbZmllbGRzLCBzZXRGaWVsZHNdID0gUmVhY3QudXNlU3RhdGUoZ2V0Q3VycmVudEZpZWxkQXJyYXkpO1xuICAgIGNvbnN0IGlkcyA9IFJlYWN0LnVzZVJlZihjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLm1hcChnZW5lcmF0ZUlkKSk7XG4gICAgY29uc3QgX2FjdGlvbmVkID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgICBjb25zdCB7IHJlc3luY0lmTmVlZGVkLCBzbmFwc2hvdCB9ID0gdXNlUmVzeW5jT25SZWNvbm5lY3QoZ2V0Q3VycmVudEZpZWxkQXJyYXkpO1xuICAgIGNvbnN0IF9wcmV2Q29udHJvbCA9IFJlYWN0LnVzZVJlZihjb250cm9sKTtcbiAgICBjb25zdCBfcHJldk5hbWUgPSBSZWFjdC51c2VSZWYobmFtZSk7XG4gICAgaWYgKCFkaXNhYmxlZCkge1xuICAgICAgICBjb250cm9sLl9uYW1lcy5hcnJheS5hZGQobmFtZSk7XG4gICAgfVxuICAgIFJlYWN0LnVzZU1lbW8oKCkgPT4gIWRpc2FibGVkICYmXG4gICAgICAgIHJ1bGVzICYmXG4gICAgICAgIGZpZWxkcy5sZW5ndGggPj0gMCAmJlxuICAgICAgICBjb250cm9sLnJlZ2lzdGVyKG5hbWUsIHJ1bGVzKSwgW2NvbnRyb2wsIG5hbWUsIGZpZWxkcy5sZW5ndGgsIHJ1bGVzLCBkaXNhYmxlZF0pO1xuICAgIHVzZUlzb21vcnBoaWNMYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoX3ByZXZDb250cm9sLmN1cnJlbnQgPT09IGNvbnRyb2wgJiYgX3ByZXZOYW1lLmN1cnJlbnQgPT09IG5hbWUpIHtcbiAgICAgICAgICAgIHJlc3luY0lmTmVlZGVkKHRydWUsIGdldEN1cnJlbnRGaWVsZEFycmF5LCAoZmllbGRWYWx1ZXMpID0+IHtcbiAgICAgICAgICAgICAgICBzZXRGaWVsZHMoZmllbGRWYWx1ZXMpO1xuICAgICAgICAgICAgICAgIGlkcy5jdXJyZW50ID0gZmllbGRWYWx1ZXMubWFwKGdlbmVyYXRlSWQpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBfcHJldkNvbnRyb2wuY3VycmVudCA9IGNvbnRyb2w7XG4gICAgICAgICAgICBfcHJldk5hbWUuY3VycmVudCA9IG5hbWU7XG4gICAgICAgICAgICBjb25zdCBmaWVsZFZhbHVlcyA9IGdldEN1cnJlbnRGaWVsZEFycmF5KCk7XG4gICAgICAgICAgICBpZiAoIWRlZXBFcXVhbChmaWVsZHMsIGZpZWxkVmFsdWVzKSkge1xuICAgICAgICAgICAgICAgIHNldEZpZWxkcyhmaWVsZFZhbHVlcyk7XG4gICAgICAgICAgICAgICAgaWRzLmN1cnJlbnQgPSBmaWVsZFZhbHVlcy5tYXAoZ2VuZXJhdGVJZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzbmFwc2hvdCh0cnVlLCBnZXRDdXJyZW50RmllbGRBcnJheSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdW5zdWJzY3JpYmUgPSBjb250cm9sLl9zdWJqZWN0cy5hcnJheS5zdWJzY3JpYmUoe1xuICAgICAgICAgICAgbmV4dDogKHsgdmFsdWVzLCBuYW1lOiBmaWVsZEFycmF5TmFtZSwgfSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChmaWVsZEFycmF5TmFtZSA9PT0gbmFtZSB8fCAhZmllbGRBcnJheU5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZmllbGRWYWx1ZXMgPSBnZXQodmFsdWVzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoZmllbGRWYWx1ZXMpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGaWVsZHMoZmllbGRWYWx1ZXMpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWRzLmN1cnJlbnQgPSBmaWVsZFZhbHVlcy5tYXAoZ2VuZXJhdGVJZCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoIWZpZWxkQXJyYXlOYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRGaWVsZHMoW10pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWRzLmN1cnJlbnQgPSBbXTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pLnVuc3Vic2NyaWJlO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIHNuYXBzaG90KHRydWUsIGdldEN1cnJlbnRGaWVsZEFycmF5KTtcbiAgICAgICAgfTtcbiAgICB9LCBbY29udHJvbCwgbmFtZSwgZGlzYWJsZWQsIHJlc3luY0lmTmVlZGVkLCBzbmFwc2hvdF0pO1xuICAgIGNvbnN0IHVwZGF0ZVZhbHVlcyA9IFJlYWN0LnVzZUNhbGxiYWNrKCh1cGRhdGVkRmllbGRBcnJheVZhbHVlcykgPT4ge1xuICAgICAgICBfYWN0aW9uZWQuY3VycmVudCA9IHRydWU7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgIH0sIFtjb250cm9sLCBuYW1lXSk7XG4gICAgY29uc3QgYXBwZW5kID0gKHZhbHVlLCBvcHRpb25zKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGFwcGVuZFZhbHVlID0gY29udmVydFRvQXJyYXlQYXlsb2FkKGNsb25lT2JqZWN0KHZhbHVlKSk7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gYXBwZW5kQXQoY29udHJvbC5fZ2V0RmllbGRBcnJheShuYW1lKSwgYXBwZW5kVmFsdWUpO1xuICAgICAgICBjb250cm9sLl9uYW1lcy5mb2N1cyA9IGdldEZvY3VzRmllbGROYW1lKG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLmxlbmd0aCAtIDEsIG9wdGlvbnMpO1xuICAgICAgICBpZHMuY3VycmVudCA9IGFwcGVuZEF0KGlkcy5jdXJyZW50LCBhcHBlbmRWYWx1ZS5tYXAoZ2VuZXJhdGVJZCkpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBhcHBlbmRBdCwge1xuICAgICAgICAgICAgYXJnQTogZmlsbEVtcHR5QXJyYXkodmFsdWUpLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IHByZXBlbmQgPSAodmFsdWUsIG9wdGlvbnMpID0+IHtcbiAgICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcHJlcGVuZFZhbHVlID0gY29udmVydFRvQXJyYXlQYXlsb2FkKGNsb25lT2JqZWN0KHZhbHVlKSk7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gcHJlcGVuZEF0KGNvbnRyb2wuX2dldEZpZWxkQXJyYXkobmFtZSksIHByZXBlbmRWYWx1ZSk7XG4gICAgICAgIGNvbnRyb2wuX25hbWVzLmZvY3VzID0gZ2V0Rm9jdXNGaWVsZE5hbWUobmFtZSwgMCwgb3B0aW9ucyk7XG4gICAgICAgIGlkcy5jdXJyZW50ID0gcHJlcGVuZEF0KGlkcy5jdXJyZW50LCBwcmVwZW5kVmFsdWUubWFwKGdlbmVyYXRlSWQpKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgc2V0RmllbGRzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgY29udHJvbC5fc2V0RmllbGRBcnJheShuYW1lLCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcywgcHJlcGVuZEF0LCB7XG4gICAgICAgICAgICBhcmdBOiBmaWxsRW1wdHlBcnJheSh2YWx1ZSksXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgcmVtb3ZlID0gKGluZGV4KSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gcmVtb3ZlQXJyYXlBdChjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLCBpbmRleCk7XG4gICAgICAgIGlkcy5jdXJyZW50ID0gcmVtb3ZlQXJyYXlBdChpZHMuY3VycmVudCwgaW5kZXgpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICAhQXJyYXkuaXNBcnJheShnZXQoY29udHJvbC5fZmllbGRzLCBuYW1lKSkgJiZcbiAgICAgICAgICAgIHNldChjb250cm9sLl9maWVsZHMsIG5hbWUsIHVuZGVmaW5lZCk7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMsIHJlbW92ZUFycmF5QXQsIHtcbiAgICAgICAgICAgIGFyZ0E6IGluZGV4LFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IGluc2VydCQxID0gKGluZGV4LCB2YWx1ZSwgb3B0aW9ucykgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBpbnNlcnRWYWx1ZSA9IGNvbnZlcnRUb0FycmF5UGF5bG9hZChjbG9uZU9iamVjdCh2YWx1ZSkpO1xuICAgICAgICBjb25zdCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcyA9IGluc2VydChjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLCBpbmRleCwgaW5zZXJ0VmFsdWUpO1xuICAgICAgICBjb250cm9sLl9uYW1lcy5mb2N1cyA9IGdldEZvY3VzRmllbGROYW1lKG5hbWUsIGluZGV4LCBvcHRpb25zKTtcbiAgICAgICAgaWRzLmN1cnJlbnQgPSBpbnNlcnQoaWRzLmN1cnJlbnQsIGluZGV4LCBpbnNlcnRWYWx1ZS5tYXAoZ2VuZXJhdGVJZCkpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBpbnNlcnQsIHtcbiAgICAgICAgICAgIGFyZ0E6IGluZGV4LFxuICAgICAgICAgICAgYXJnQjogZmlsbEVtcHR5QXJyYXkodmFsdWUpLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IHN3YXAgPSAoaW5kZXhBLCBpbmRleEIpID0+IHtcbiAgICAgICAgaWYgKGRpc2FibGVkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMgPSBjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpO1xuICAgICAgICBzd2FwQXJyYXlBdCh1cGRhdGVkRmllbGRBcnJheVZhbHVlcywgaW5kZXhBLCBpbmRleEIpO1xuICAgICAgICBzd2FwQXJyYXlBdChpZHMuY3VycmVudCwgaW5kZXhBLCBpbmRleEIpO1xuICAgICAgICB1cGRhdGVWYWx1ZXModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBzZXRGaWVsZHModXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMpO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCBzd2FwQXJyYXlBdCwge1xuICAgICAgICAgICAgYXJnQTogaW5kZXhBLFxuICAgICAgICAgICAgYXJnQjogaW5kZXhCLFxuICAgICAgICB9LCBmYWxzZSk7XG4gICAgfTtcbiAgICBjb25zdCBtb3ZlID0gKGZyb20sIHRvKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzID0gY29udHJvbC5fZ2V0RmllbGRBcnJheShuYW1lKTtcbiAgICAgICAgbW92ZUFycmF5QXQodXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMsIGZyb20sIHRvKTtcbiAgICAgICAgbW92ZUFycmF5QXQoaWRzLmN1cnJlbnQsIGZyb20sIHRvKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgc2V0RmllbGRzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgY29udHJvbC5fc2V0RmllbGRBcnJheShuYW1lLCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcywgbW92ZUFycmF5QXQsIHtcbiAgICAgICAgICAgIGFyZ0E6IGZyb20sXG4gICAgICAgICAgICBhcmdCOiB0byxcbiAgICAgICAgfSwgZmFsc2UpO1xuICAgIH07XG4gICAgY29uc3QgdXBkYXRlID0gKGluZGV4LCB2YWx1ZSkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1cGRhdGVWYWx1ZSA9IGNsb25lT2JqZWN0KHZhbHVlKTtcbiAgICAgICAgY29uc3QgdXBkYXRlZEZpZWxkQXJyYXlWYWx1ZXMgPSB1cGRhdGVBdChjb250cm9sLl9nZXRGaWVsZEFycmF5KG5hbWUpLCBpbmRleCwgdXBkYXRlVmFsdWUpO1xuICAgICAgICBpZHMuY3VycmVudCA9IFsuLi51cGRhdGVkRmllbGRBcnJheVZhbHVlc10ubWFwKChpdGVtLCBpKSA9PiAhaXRlbSB8fCBpID09PSBpbmRleCA/IGdlbmVyYXRlSWQoKSA6IGlkcy5jdXJyZW50W2ldKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzKTtcbiAgICAgICAgc2V0RmllbGRzKFsuLi51cGRhdGVkRmllbGRBcnJheVZhbHVlc10pO1xuICAgICAgICBjb250cm9sLl9zZXRGaWVsZEFycmF5KG5hbWUsIHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLCB1cGRhdGVBdCwge1xuICAgICAgICAgICAgYXJnQTogaW5kZXgsXG4gICAgICAgICAgICBhcmdCOiBmaWxsRW1wdHlBcnJheSh2YWx1ZSksXG4gICAgICAgIH0pO1xuICAgIH07XG4gICAgY29uc3QgcmVwbGFjZSA9ICh2YWx1ZSkgPT4ge1xuICAgICAgICBpZiAoZGlzYWJsZWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcyA9IGNvbnZlcnRUb0FycmF5UGF5bG9hZChjbG9uZU9iamVjdCh2YWx1ZSkpO1xuICAgICAgICBpZHMuY3VycmVudCA9IHVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzLm1hcChnZW5lcmF0ZUlkKTtcbiAgICAgICAgdXBkYXRlVmFsdWVzKFsuLi51cGRhdGVkRmllbGRBcnJheVZhbHVlc10pO1xuICAgICAgICBzZXRGaWVsZHMoWy4uLnVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzXSk7XG4gICAgICAgIGNvbnRyb2wuX3NldEZpZWxkQXJyYXkobmFtZSwgWy4uLnVwZGF0ZWRGaWVsZEFycmF5VmFsdWVzXSwgKGRhdGEpID0+IEFycmF5LmlzQXJyYXkoZGF0YSlcbiAgICAgICAgICAgID8gZGF0YS5zbGljZSgwLCB1cGRhdGVkRmllbGRBcnJheVZhbHVlcy5sZW5ndGgpXG4gICAgICAgICAgICA6IGRhdGEsIHt9KTtcbiAgICB9O1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgY29udHJvbC5fc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmRlbGV0ZShuYW1lKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb250cm9sLl9zdGF0ZS5hY3Rpb24gPSBmYWxzZTtcbiAgICAgICAgY29udHJvbC5fc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmRlbGV0ZShuYW1lKTtcbiAgICAgICAgaXNXYXRjaGVkKG5hbWUsIGNvbnRyb2wuX25hbWVzKSAmJlxuICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgLi4uY29udHJvbC5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHZhbGlkYXRpb25Nb2RlcyA9IGdldFZhbGlkYXRpb25Nb2Rlcyhjb250cm9sLl9vcHRpb25zLm1vZGUpO1xuICAgICAgICBpZiAoX2FjdGlvbmVkLmN1cnJlbnQgJiZcbiAgICAgICAgICAgICghdmFsaWRhdGlvbk1vZGVzLmlzT25TdWJtaXQgfHwgY29udHJvbC5fZm9ybVN0YXRlLmlzU3VibWl0dGVkKSAmJlxuICAgICAgICAgICAgIWdldFZhbGlkYXRpb25Nb2Rlcyhjb250cm9sLl9vcHRpb25zLnJlVmFsaWRhdGVNb2RlKS5pc09uU3VibWl0ICYmXG4gICAgICAgICAgICAhdmFsaWRhdGlvbk1vZGVzLmlzT25CbHVyKSB7XG4gICAgICAgICAgICBpZiAoY29udHJvbC5fb3B0aW9ucy5yZXNvbHZlcikge1xuICAgICAgICAgICAgICAgIGNvbnRyb2wuX3J1blNjaGVtYShbbmFtZV0pLnRoZW4oKHJlc3VsdCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb250cm9sLl91cGRhdGVJc1ZhbGlkYXRpbmcoW25hbWVdKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXJyb3IgPSBnZXQocmVzdWx0LmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nRXJyb3IgPSBnZXQoY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nRXJyb3JUeXBlID0gZXhpc3RpbmdFcnJvciAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgKGV4aXN0aW5nRXJyb3IudHlwZSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChleGlzdGluZ0Vycm9yLnJvb3QgJiYgZXhpc3RpbmdFcnJvci5yb290LnR5cGUpKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdFcnJvck1lc3NhZ2UgPSBleGlzdGluZ0Vycm9yICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAoZXhpc3RpbmdFcnJvci5tZXNzYWdlIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKGV4aXN0aW5nRXJyb3Iucm9vdCAmJiBleGlzdGluZ0Vycm9yLnJvb3QubWVzc2FnZSkpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmdFcnJvclxuICAgICAgICAgICAgICAgICAgICAgICAgPyAoIWVycm9yICYmIGV4aXN0aW5nRXJyb3JUeXBlKSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIChlcnJvciAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZXhpc3RpbmdFcnJvclR5cGUgIT09IGVycm9yLnR5cGUgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV4aXN0aW5nRXJyb3JNZXNzYWdlICE9PSBlcnJvci5tZXNzYWdlKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIDogZXJyb3IgJiYgZXJyb3IudHlwZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNPYmplY3QoZXJyb3IpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICFPYmplY3Qua2V5cyhlcnJvcikuc29tZSgoa2V5KSA9PiAhTnVtYmVyLmlzTmFOKCtrZXkpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IHVwZGF0ZUZpZWxkQXJyYXlSb290RXJyb3IoY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycywgeyBbbmFtZV06IGVycm9yIH0sIG5hbWUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogc2V0KGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUsIGVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVuc2V0KGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycyB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JzOiBjb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KGNvbnRyb2wuX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgaWYgKGZpZWxkICYmIGZpZWxkLl9mKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhbGlkYXRlRmllbGQoZmllbGQsIGNvbnRyb2wuX25hbWVzLmRpc2FibGVkLCBjb250cm9sLl9mb3JtVmFsdWVzLCBjb250cm9sLl9vcHRpb25zLmNyaXRlcmlhTW9kZSA9PT0gVkFMSURBVElPTl9NT0RFLmFsbCwgY29udHJvbC5fb3B0aW9ucy5zaG91bGRVc2VOYXRpdmVWYWxpZGF0aW9uLCB0cnVlKS50aGVuKChlcnJvcikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFpc0VtcHR5T2JqZWN0KGVycm9yKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVwZGF0ZUZpZWxkQXJyYXlSb290RXJyb3IoY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycywgZXJyb3IsIG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sLl9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JzOiBjb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdFcnJvciA9IGdldChjb250cm9sLl9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZXhpc3RpbmdFcnJvciAmJiBleGlzdGluZ0Vycm9yW1JPT1RfRVJST1JfVFlQRV0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdW5zZXQoY29udHJvbC5fZm9ybVN0YXRlLmVycm9ycywgYCR7bmFtZX0uJHtST09UX0VSUk9SX1RZUEV9YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlcnJvcnM6IGNvbnRyb2wuX2Zvcm1TdGF0ZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC5lcnJvcnMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIEV4dGVybmFsIHVwZGF0ZXMgdGhhdCBjaGFuZ2UgYGZpZWxkc2AgKGUuZy4gcmVzZXQoKSBvciBzZXRWYWx1ZSgpIG9uXG4gICAgICAgIC8vIHRoZSBhcnJheSkgYWxyZWFkeSBub3RpZnkgc3Vic2NyaWJlcnMgd2l0aCB0aGUgdXAtdG8tZGF0ZSB2YWx1ZXNcbiAgICAgICAgLy8gdGhlbXNlbHZlcywgc28gb25seSByZS1icm9hZGNhc3QgaGVyZSBmb3IgZ2VudWluZSBhcnJheSBtZXRob2QgY2FsbHMuXG4gICAgICAgIF9hY3Rpb25lZC5jdXJyZW50ICYmXG4gICAgICAgICAgICBjb250cm9sLl9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIHZhbHVlczogY2xvbmVPYmplY3QoY29udHJvbC5fZm9ybVZhbHVlcyksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgY29udHJvbC5fbmFtZXMuZm9jdXMgJiZcbiAgICAgICAgICAgIGl0ZXJhdGVGaWVsZHNCeUFjdGlvbihjb250cm9sLl9maWVsZHMsIChyZWYsIGtleSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChjb250cm9sLl9uYW1lcy5mb2N1cyAmJlxuICAgICAgICAgICAgICAgICAgICBrZXkuc3RhcnRzV2l0aChjb250cm9sLl9uYW1lcy5mb2N1cykgJiZcbiAgICAgICAgICAgICAgICAgICAgcmVmLmZvY3VzKSB7XG4gICAgICAgICAgICAgICAgICAgIHJlZi5mb2N1cygpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gMTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIGNvbnRyb2wuX25hbWVzLmZvY3VzID0gJyc7XG4gICAgICAgIGNvbnRyb2wuX3NldFZhbGlkKCk7XG4gICAgICAgIF9hY3Rpb25lZC5jdXJyZW50ID0gZmFsc2U7XG4gICAgfSwgW2ZpZWxkcywgbmFtZSwgY29udHJvbCwgZGlzYWJsZWRdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoIWRpc2FibGVkKSB7XG4gICAgICAgICAgICBpc1VuZGVmaW5lZChnZXQoY29udHJvbC5fZm9ybVZhbHVlcywgbmFtZSkpICYmXG4gICAgICAgICAgICAgICAgY29udHJvbC5fc2V0RmllbGRBcnJheShuYW1lKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgY29udHJvbC5fc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmRlbGV0ZShuYW1lKTtcbiAgICAgICAgICAgIGlmIChkaXNhYmxlZCkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHNob3VsZEtlZXBGaWVsZEFycmF5VmFsdWVzID0gIShjb250cm9sLl9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXIgfHwgc2hvdWxkVW5yZWdpc3Rlcik7XG4gICAgICAgICAgICBjb25zdCB1cGRhdGVNb3VudGVkID0gKG5hbWUsIHZhbHVlKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoY29udHJvbC5fZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBpZiAoZmllbGQgJiYgZmllbGQuX2YpIHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGQuX2YubW91bnQgPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgaWYgKF9hY3Rpb25lZC5jdXJyZW50ICYmIHNob3VsZEtlZXBGaWVsZEFycmF5VmFsdWVzKSB7XG4gICAgICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlczogY2xvbmVPYmplY3QoY29udHJvbC5fZm9ybVZhbHVlcyksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIXNob3VsZEtlZXBGaWVsZEFycmF5VmFsdWVzICYmIGNvbnRyb2wuX3N0YXRlLmFjdGlvbikge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHNob3VsZEtlZXBGaWVsZEFycmF5VmFsdWVzXG4gICAgICAgICAgICAgICAgPyB1cGRhdGVNb3VudGVkKG5hbWUsIGZhbHNlKVxuICAgICAgICAgICAgICAgIDogY29udHJvbC51bnJlZ2lzdGVyKG5hbWUpO1xuICAgICAgICB9O1xuICAgIH0sIFtuYW1lLCBjb250cm9sLCBrZXlOYW1lLCBzaG91bGRVbnJlZ2lzdGVyLCBkaXNhYmxlZF0pO1xuICAgIHJldHVybiB7XG4gICAgICAgIHN3YXA6IFJlYWN0LnVzZUNhbGxiYWNrKHN3YXAsIFt1cGRhdGVWYWx1ZXMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSksXG4gICAgICAgIG1vdmU6IFJlYWN0LnVzZUNhbGxiYWNrKG1vdmUsIFt1cGRhdGVWYWx1ZXMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSksXG4gICAgICAgIHByZXBlbmQ6IFJlYWN0LnVzZUNhbGxiYWNrKHByZXBlbmQsIFtcbiAgICAgICAgICAgIHVwZGF0ZVZhbHVlcyxcbiAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICBjb250cm9sLFxuICAgICAgICAgICAgZGlzYWJsZWQsXG4gICAgICAgIF0pLFxuICAgICAgICBhcHBlbmQ6IFJlYWN0LnVzZUNhbGxiYWNrKGFwcGVuZCwgW3VwZGF0ZVZhbHVlcywgbmFtZSwgY29udHJvbCwgZGlzYWJsZWRdKSxcbiAgICAgICAgcmVtb3ZlOiBSZWFjdC51c2VDYWxsYmFjayhyZW1vdmUsIFt1cGRhdGVWYWx1ZXMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSksXG4gICAgICAgIGluc2VydDogUmVhY3QudXNlQ2FsbGJhY2soaW5zZXJ0JDEsIFt1cGRhdGVWYWx1ZXMsIG5hbWUsIGNvbnRyb2wsIGRpc2FibGVkXSksXG4gICAgICAgIHVwZGF0ZTogUmVhY3QudXNlQ2FsbGJhY2sodXBkYXRlLCBbdXBkYXRlVmFsdWVzLCBuYW1lLCBjb250cm9sLCBkaXNhYmxlZF0pLFxuICAgICAgICByZXBsYWNlOiBSZWFjdC51c2VDYWxsYmFjayhyZXBsYWNlLCBbXG4gICAgICAgICAgICB1cGRhdGVWYWx1ZXMsXG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgY29udHJvbCxcbiAgICAgICAgICAgIGRpc2FibGVkLFxuICAgICAgICBdKSxcbiAgICAgICAgZmllbGRzOiBSZWFjdC51c2VNZW1vKCgpID0+IGZpZWxkcy5tYXAoKGZpZWxkLCBpbmRleCkgPT4gKHtcbiAgICAgICAgICAgIC4uLmZpZWxkLFxuICAgICAgICAgICAgLi4uKGlzQm9vbGVhbihkaXNhYmxlZCkgPyB7IGRpc2FibGVkIH0gOiB7fSksXG4gICAgICAgICAgICBba2V5TmFtZV06IGlkcy5jdXJyZW50W2luZGV4XSB8fCBnZW5lcmF0ZUlkKCksXG4gICAgICAgIH0pKSwgW2ZpZWxkcywga2V5TmFtZSwgZGlzYWJsZWRdKSxcbiAgICB9O1xufVxuXG4vKipcbiAqIENvbXBvbmVudCBiYXNlZCBvbiBgdXNlRmllbGRBcnJheWAgaG9vayB0byB3b3JrIHdpdGggY29udHJvbGxlZCBjb21wb25lbnQuXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogZnVuY3Rpb24gQXBwKCkge1xuICogICBjb25zdCB7IGNvbnRyb2wsIHJlZ2lzdGVyIH0gPSB1c2VGb3JtPEZvcm1WYWx1ZXM+KHtcbiAqICAgICBkZWZhdWx0VmFsdWVzOiB7XG4gKiAgICAgICB0ZXN0OiBbXG4gKiAgICAgICAgIHtcbiAqICAgICAgICAgICB2YWx1ZTogJycsXG4gKiAgICAgICAgIH0sXG4gKiAgICAgICBdLFxuICogICAgIH0sXG4gKiAgIH0pO1xuICpcbiAqICAgcmV0dXJuIChcbiAqICAgICA8Zm9ybT5cbiAqICAgICAgIDxGaWVsZEFycmF5XG4gKiAgICAgICAgIGNvbnRyb2w9e2NvbnRyb2x9XG4gKiAgICAgICAgIG5hbWU9XCJ0ZXN0XCJcbiAqICAgICAgICAgcmVuZGVyPXsoeyBmaWVsZHMgfSkgPT5cbiAqICAgICAgICAgICBmaWVsZHMubWFwKChmaWVsZCwgaW5kZXgpID0+IChcbiAqICAgICAgICAgICAgIDxpbnB1dCBrZXk9e2ZpZWxkLmlkfSB7Li4ucmVnaXN0ZXIoYHRlc3QuJHtpbmRleH0udmFsdWVgKX0gLz5cbiAqICAgICAgICAgICApKVxuICogICAgICAgICB9XG4gKiAgICAgICAvPlxuICogICAgIDwvZm9ybT5cbiAqICAgKTtcbiAqIH1cbiAqIGBgYFxuICovXG5jb25zdCBGaWVsZEFycmF5ID0gKHByb3BzKSA9PiBwcm9wcy5yZW5kZXIodXNlRmllbGRBcnJheShwcm9wcykpO1xuXG5jb25zdCBpc0ZpbGVMaWtlID0gKHZhbHVlKSA9PiAodHlwZW9mIEJsb2IgIT09ICd1bmRlZmluZWQnICYmIHZhbHVlIGluc3RhbmNlb2YgQmxvYikgfHxcbiAgICAodHlwZW9mIEZpbGUgIT09ICd1bmRlZmluZWQnICYmIHZhbHVlIGluc3RhbmNlb2YgRmlsZSk7XG5jb25zdCBpc0ZpbGVMaXN0TGlrZSA9ICh2YWx1ZSkgPT4gdHlwZW9mIEZpbGVMaXN0ICE9PSAndW5kZWZpbmVkJyAmJiB2YWx1ZSBpbnN0YW5jZW9mIEZpbGVMaXN0O1xuY29uc3QgZmxhdHRlbiA9IChvYmopID0+IHtcbiAgICBjb25zdCBvdXRwdXQgPSB7fTtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhvYmopKSB7XG4gICAgICAgIGlmIChpc09iamVjdFR5cGUob2JqW2tleV0pICYmXG4gICAgICAgICAgICBvYmpba2V5XSAhPT0gbnVsbCAmJlxuICAgICAgICAgICAgIWlzRGF0ZU9iamVjdChvYmpba2V5XSkgJiZcbiAgICAgICAgICAgICFpc0ZpbGVMaWtlKG9ialtrZXldKSAmJlxuICAgICAgICAgICAgIWlzRmlsZUxpc3RMaWtlKG9ialtrZXldKSkge1xuICAgICAgICAgICAgY29uc3QgbmVzdGVkID0gZmxhdHRlbihvYmpba2V5XSk7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IG5lc3RlZEtleSBvZiBPYmplY3Qua2V5cyhuZXN0ZWQpKSB7XG4gICAgICAgICAgICAgICAgb3V0cHV0W2Ake2tleX0uJHtuZXN0ZWRLZXl9YF0gPSBuZXN0ZWRbbmVzdGVkS2V5XTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIG91dHB1dFtrZXldID0gb2JqW2tleV07XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG91dHB1dDtcbn07XG5cbmZ1bmN0aW9uIGpzb25Ub0Zvcm1EYXRhKGpzb24pIHtcbiAgICBjb25zdCByZXN1bHQgPSBuZXcgRm9ybURhdGEoKTtcbiAgICBjb25zdCBmbGF0dGVuRm9ybVZhbHVlcyA9IGZsYXR0ZW4oanNvbik7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZmxhdHRlbkZvcm1WYWx1ZXMpIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBmbGF0dGVuRm9ybVZhbHVlc1trZXldO1xuICAgICAgICBpZiAoaXNVbmRlZmluZWQodmFsdWUpKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZW9mIEZpbGVMaXN0ICE9PSAndW5kZWZpbmVkJyAmJiB2YWx1ZSBpbnN0YW5jZW9mIEZpbGVMaXN0KSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgdmFsdWUubGVuZ3RoOyBpbmRleCsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmlsZSA9IHZhbHVlW2luZGV4XTtcbiAgICAgICAgICAgICAgICBmaWxlICYmIHJlc3VsdC5hcHBlbmQoa2V5LCBmaWxlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIHJlc3VsdC5hcHBlbmQoa2V5LCB2YWx1ZSk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5cbmZ1bmN0aW9uIHNhZmVKU09OU3RyaW5naWZ5KHZhbHVlKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIEpTT04uc3RyaW5naWZ5KHZhbHVlKTtcbiAgICB9XG4gICAgY2F0Y2ggKF9hKSB7XG4gICAgICAgIHJldHVybiAnJztcbiAgICB9XG59XG5cbmZ1bmN0aW9uIG5vb3AoKSB7IH1cblxuY29uc3QgSG9va0Zvcm1Db250ZXh0ID0gUmVhY3QuY3JlYXRlQ29udGV4dChudWxsKTtcbkhvb2tGb3JtQ29udGV4dC5kaXNwbGF5TmFtZSA9ICdIb29rRm9ybUNvbnRleHQnO1xuLyoqXG4gKiBSZXRyaWV2ZXMgYWxsIGB1c2VGb3JtYCBtZXRob2RzIGZyb20gdGhlIG5lYXJlc3QgYEZvcm1Qcm92aWRlcmAuXG4gKiBVc2UgaW4gZGVlcGx5IG5lc3RlZCBjb21wb25lbnRzIHRvIGF2b2lkIHByb3AtZHJpbGxpbmcuXG4gKlxuICogQHNlZSBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2Vmb3JtY29udGV4dClcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBjb25zdCB7IHJlZ2lzdGVyIH0gPSB1c2VGb3JtQ29udGV4dDxGb3JtVmFsdWVzPigpO1xuICogYGBgXG4gKi9cbmNvbnN0IHVzZUZvcm1Db250ZXh0ID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChIb29rRm9ybUNvbnRleHQpO1xuLyoqXG4gKiBQcm92aWRlcyBhbGwgYHVzZUZvcm1gIG1ldGhvZHMgdG8gdGhlIGNvbXBvbmVudCB0cmVlIHZpYSBSZWFjdCBDb250ZXh0LlxuICogUGFpciB3aXRoIGB1c2VGb3JtQ29udGV4dGAgdG8gY29uc3VtZSB0aGVtIGluIGFueSBkZXNjZW5kYW50LlxuICpcbiAqIEBzZWUgW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlZm9ybWNvbnRleHQpXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogPEZvcm1Qcm92aWRlciB7Li4ubWV0aG9kc30+XG4gKiAgIDxmb3JtIG9uU3VibWl0PXttZXRob2RzLmhhbmRsZVN1Ym1pdChvblN1Ym1pdCl9PntjaGlsZHJlbn08L2Zvcm0+XG4gKiA8L0Zvcm1Qcm92aWRlcj5cbiAqIGBgYFxuICovXG5jb25zdCBGb3JtUHJvdmlkZXIgPSAoeyBjaGlsZHJlbiwgd2F0Y2gsIGdldFZhbHVlcywgZ2V0RXJyb3JzLCBnZXRGaWVsZFN0YXRlLCBzZXRFcnJvciwgY2xlYXJFcnJvcnMsIHNldFZhbHVlLCBzZXRWYWx1ZXMsIHRyaWdnZXIsIGZvcm1TdGF0ZSwgcmVzZXRGaWVsZCwgcmVzZXQsIHJlc2V0RGVmYXVsdFZhbHVlcywgaGFuZGxlU3VibWl0LCB1bnJlZ2lzdGVyLCBjb250cm9sLCByZWdpc3Rlciwgc2V0Rm9jdXMsIHN1YnNjcmliZSwgfSkgPT4ge1xuICAgIGNvbnN0IG1lbW9pemVkVmFsdWUgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgICAgIHdhdGNoLFxuICAgICAgICBnZXRWYWx1ZXMsXG4gICAgICAgIGdldEVycm9ycyxcbiAgICAgICAgZ2V0RmllbGRTdGF0ZSxcbiAgICAgICAgc2V0RXJyb3IsXG4gICAgICAgIGNsZWFyRXJyb3JzLFxuICAgICAgICBzZXRWYWx1ZSxcbiAgICAgICAgc2V0VmFsdWVzLFxuICAgICAgICB0cmlnZ2VyLFxuICAgICAgICBmb3JtU3RhdGUsXG4gICAgICAgIHJlc2V0RmllbGQsXG4gICAgICAgIHJlc2V0LFxuICAgICAgICByZXNldERlZmF1bHRWYWx1ZXMsXG4gICAgICAgIGhhbmRsZVN1Ym1pdCxcbiAgICAgICAgdW5yZWdpc3RlcixcbiAgICAgICAgY29udHJvbCxcbiAgICAgICAgcmVnaXN0ZXIsXG4gICAgICAgIHNldEZvY3VzLFxuICAgICAgICBzdWJzY3JpYmUsXG4gICAgfSksIFtcbiAgICAgICAgY2xlYXJFcnJvcnMsXG4gICAgICAgIGNvbnRyb2wsXG4gICAgICAgIGZvcm1TdGF0ZSxcbiAgICAgICAgZ2V0RXJyb3JzLFxuICAgICAgICBnZXRGaWVsZFN0YXRlLFxuICAgICAgICBnZXRWYWx1ZXMsXG4gICAgICAgIGhhbmRsZVN1Ym1pdCxcbiAgICAgICAgcmVnaXN0ZXIsXG4gICAgICAgIHJlc2V0LFxuICAgICAgICByZXNldERlZmF1bHRWYWx1ZXMsXG4gICAgICAgIHJlc2V0RmllbGQsXG4gICAgICAgIHNldEVycm9yLFxuICAgICAgICBzZXRGb2N1cyxcbiAgICAgICAgc2V0VmFsdWUsXG4gICAgICAgIHNldFZhbHVlcyxcbiAgICAgICAgc3Vic2NyaWJlLFxuICAgICAgICB0cmlnZ2VyLFxuICAgICAgICB1bnJlZ2lzdGVyLFxuICAgICAgICB3YXRjaCxcbiAgICBdKTtcbiAgICByZXR1cm4gKFJlYWN0LmNyZWF0ZUVsZW1lbnQoSG9va0Zvcm1Db250ZXh0LlByb3ZpZGVyLCB7IHZhbHVlOiBtZW1vaXplZFZhbHVlIH0sXG4gICAgICAgIFJlYWN0LmNyZWF0ZUVsZW1lbnQoSG9va0Zvcm1Db250cm9sQ29udGV4dC5Qcm92aWRlciwgeyB2YWx1ZTogbWVtb2l6ZWRWYWx1ZS5jb250cm9sIH0sIGNoaWxkcmVuKSkpO1xufTtcblxuY29uc3QgUE9TVF9SRVFVRVNUID0gJ3Bvc3QnO1xuZnVuY3Rpb24gZGVmYXVsdFZhbGlkYXRlU3RhdHVzKHN0YXR1cykge1xuICAgIHJldHVybiBzdGF0dXMgPj0gMjAwICYmIHN0YXR1cyA8IDMwMDtcbn1cbi8qKlxuICogRm9ybSBjb21wb25lbnQgdGhhdCBoYW5kbGVzIHN1Ym1pc3Npb24sIGluY2x1ZGluZyBvcHRpb25hbCBgYWN0aW9uYCBmZXRjaCBhbmQgc2VydmVyIGVycm9yIHdpcmluZy5cbiAqXG4gKiBAc2VlIFtBUEldKGh0dHBzOi8vcmVhY3QtaG9vay1mb3JtLmNvbS9kb2NzL3VzZWZvcm0vZm9ybSlcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiA8Rm9ybSBhY3Rpb249XCIvYXBpXCIgY29udHJvbD17Y29udHJvbH0+XG4gKiAgIDxpbnB1dCB7Li4ucmVnaXN0ZXIoXCJuYW1lXCIpfSAvPlxuICogICA8cD57ZXJyb3JzPy5yb290Py5zZXJ2ZXIgJiYgJ1NlcnZlciBlcnJvcid9PC9wPlxuICogICA8YnV0dG9uPlN1Ym1pdDwvYnV0dG9uPlxuICogPC9Gb3JtPlxuICogYGBgXG4gKi9cbmZ1bmN0aW9uIEZvcm0ocHJvcHMpIHtcbiAgICBjb25zdCBtZXRob2RzID0gdXNlRm9ybUNvbnRleHQoKTtcbiAgICBjb25zdCBbbW91bnRlZCwgc2V0TW91bnRlZF0gPSBSZWFjdC51c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgeyBjb250cm9sID0gbWV0aG9kcy5jb250cm9sLCBvblN1Ym1pdCA9IG5vb3AsIGNoaWxkcmVuLCBhY3Rpb24sIG1ldGhvZCA9IFBPU1RfUkVRVUVTVCwgaGVhZGVycywgZW5jVHlwZSwgb25FcnJvciA9IG5vb3AsIHJlbmRlciwgb25TdWNjZXNzID0gbm9vcCwgdmFsaWRhdGVTdGF0dXMgPSBkZWZhdWx0VmFsaWRhdGVTdGF0dXMsIC4uLnJlc3QgfSA9IHByb3BzO1xuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgICAgICByZXR1cm4gY29udHJvbC5oYW5kbGVTdWJtaXQoYXN5bmMgKGRhdGEsIGV2ZW50KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBmb3JtRGF0YSA9IGpzb25Ub0Zvcm1EYXRhKGRhdGEpO1xuICAgICAgICAgICAgY29uc3QgZm9ybURhdGFKc29uID0gc2FmZUpTT05TdHJpbmdpZnkoZGF0YSk7XG4gICAgICAgICAgICBpZiAob25TdWJtaXQpIHtcbiAgICAgICAgICAgICAgICBhd2FpdCBvblN1Ym1pdCh7XG4gICAgICAgICAgICAgICAgICAgIGRhdGEsXG4gICAgICAgICAgICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgICAgICAgICAgICBtZXRob2QsXG4gICAgICAgICAgICAgICAgICAgIGZvcm1EYXRhLFxuICAgICAgICAgICAgICAgICAgICBmb3JtRGF0YUpzb24sXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXNTdHJpbmcoYWN0aW9uKSkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNob3VsZFN0cmluZ2lmeVN1Ym1pc3Npb25EYXRhID0gKGhlYWRlcnMgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlYWRlcnNbJ0NvbnRlbnQtVHlwZSddICYmXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWFkZXJzWydDb250ZW50LVR5cGUnXS5pbmNsdWRlcygnanNvbicpKSB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgKGVuY1R5cGUgJiYgZW5jVHlwZS5pbmNsdWRlcygnanNvbicpKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChhY3Rpb24sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1ldGhvZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5oZWFkZXJzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC4uLihlbmNUeXBlICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVuY1R5cGUgIT09ICdtdWx0aXBhcnQvZm9ybS1kYXRhJyAmJiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiBlbmNUeXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIGJvZHk6IHNob3VsZFN0cmluZ2lmeVN1Ym1pc3Npb25EYXRhID8gZm9ybURhdGFKc29uIDogZm9ybURhdGEsXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmVzcG9uc2UgJiYgIXZhbGlkYXRlU3RhdHVzKHJlc3BvbnNlLnN0YXR1cykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uRXJyb3IoeyByZXNwb25zZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiB7IHR5cGU6IFN0cmluZyhyZXNwb25zZS5zdGF0dXMpIH07XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBvblN1Y2Nlc3MoeyByZXNwb25zZSB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgb25FcnJvcih7IGVycm9yIH0pO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4geyB0eXBlOiAnJyB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpc0Z1bmN0aW9uKGFjdGlvbikpIHtcbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBhd2FpdCBhY3Rpb24oZm9ybURhdGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgb25FcnJvcih7IGVycm9yIH0pO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4geyB0eXBlOiAnJyB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIFJldHVybiBub3RoaW5nIHdoZW4gc3VjY2Vzc2Z1bC5cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfSk7XG4gICAgfSwgW1xuICAgICAgICBjb250cm9sLFxuICAgICAgICBvblN1Ym1pdCxcbiAgICAgICAgbWV0aG9kLFxuICAgICAgICBhY3Rpb24sXG4gICAgICAgIGhlYWRlcnMsXG4gICAgICAgIGVuY1R5cGUsXG4gICAgICAgIHZhbGlkYXRlU3RhdHVzLFxuICAgICAgICBvbkVycm9yLFxuICAgICAgICBvblN1Y2Nlc3MsXG4gICAgXSk7XG4gICAgY29uc3Qgc3VibWl0ID0gUmVhY3QudXNlQ2FsbGJhY2soYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgICAgIGNvbnN0IGVyciA9IGF3YWl0IGhhbmRsZVN1Ym1pdChldmVudCk7XG4gICAgICAgIGlmIChlcnIgJiYgY29udHJvbCkge1xuICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7IGlzU3VibWl0U3VjY2Vzc2Z1bDogZmFsc2UgfSk7XG4gICAgICAgICAgICBjb250cm9sLnNldEVycm9yKCdyb290LnNlcnZlcicsIGVycik7XG4gICAgICAgIH1cbiAgICB9LCBbaGFuZGxlU3VibWl0LCBjb250cm9sXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgc2V0TW91bnRlZCh0cnVlKTtcbiAgICB9LCBbXSk7XG4gICAgaWYgKHJlbmRlcikge1xuICAgICAgICByZXR1cm4gcmVuZGVyKHsgc3VibWl0IH0pO1xuICAgIH1cbiAgICAvLyBSZWFjdCBmb3JiaWRzIHBhc3NpbmcgYG1ldGhvZGAvYGVuY1R5cGVgIGFsb25nc2lkZSBhIGZ1bmN0aW9uIGBhY3Rpb25gXG4gICAgLy8gKGEgU2VydmVyLUFjdGlvbi1zdHlsZSBzdWJtaXNzaW9uKSAtLSBpdCBtYW5hZ2VzIHRob3NlIGl0c2VsZiBhbmQgd2FybnNcbiAgICAvLyBpZiB0aGV5J3JlIHByZXNlbnQsIHNvIHRoZXkncmUgb25seSByZW5kZXJlZCBmb3Igc3RyaW5nL1VSTCBhY3Rpb25zLlxuICAgIHJldHVybiAoUmVhY3QuY3JlYXRlRWxlbWVudChcImZvcm1cIiwgeyBub1ZhbGlkYXRlOiBtb3VudGVkLCBhY3Rpb246IGFjdGlvbiwgLi4uKCFpc0Z1bmN0aW9uKGFjdGlvbikgJiYgeyBtZXRob2QsIGVuY1R5cGUgfSksIG9uU3VibWl0OiBzdWJtaXQsIC4uLnJlc3QgfSwgY2hpbGRyZW4pKTtcbn1cblxuY29uc3QgRm9ybVN0YXRlID0gKHsgY29udHJvbCwgZGlzYWJsZWQsIGV4YWN0LCBuYW1lLCByZW5kZXIsIH0pID0+IHJlbmRlcih1c2VGb3JtU3RhdGUoeyBjb250cm9sLCBuYW1lLCBkaXNhYmxlZCwgZXhhY3QgfSkpO1xuLyoqIEBkZXByZWNhdGVkIFVzZSBgRm9ybVN0YXRlYCBpbnN0ZWFkLiBLZXB0IGFzIGFuIGFsaWFzIGZvciBiYWNrd2FyZCBjb21wYXRpYmlsaXR5LiAqL1xuY29uc3QgRm9ybVN0YXRlU3Vic2NyaWJlID0gRm9ybVN0YXRlO1xuXG52YXIgY3JlYXRlU3ViamVjdCA9ICgpID0+IHtcbiAgICBsZXQgX29ic2VydmVycyA9IG5ldyBTZXQoKTtcbiAgICBsZXQgX2l0ZXJhdGlvbkNvdW50ID0gMDtcbiAgICBjb25zdCBuZXh0ID0gKHZhbHVlKSA9PiB7XG4gICAgICAgIGNvbnN0IG9ic2VydmVycyA9IF9vYnNlcnZlcnM7XG4gICAgICAgIF9pdGVyYXRpb25Db3VudCsrO1xuICAgICAgICBmb3IgKGNvbnN0IG9ic2VydmVyIG9mIG9ic2VydmVycykge1xuICAgICAgICAgICAgb2JzZXJ2ZXIubmV4dCAmJiBvYnNlcnZlci5uZXh0KHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICBvYnNlcnZlcnMgPT09IF9vYnNlcnZlcnMgJiYgX2l0ZXJhdGlvbkNvdW50LS07XG4gICAgfTtcbiAgICBjb25zdCBzdWJzY3JpYmUgPSAob2JzZXJ2ZXIpID0+IHtcbiAgICAgICAgX29ic2VydmVycy5hZGQob2JzZXJ2ZXIpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdW5zdWJzY3JpYmU6ICgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAoX2l0ZXJhdGlvbkNvdW50KSB7XG4gICAgICAgICAgICAgICAgICAgIF9vYnNlcnZlcnMgPSBuZXcgU2V0KF9vYnNlcnZlcnMpO1xuICAgICAgICAgICAgICAgICAgICBfaXRlcmF0aW9uQ291bnQgPSAwO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBfb2JzZXJ2ZXJzLmRlbGV0ZShvYnNlcnZlcik7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgIH07XG4gICAgY29uc3QgdW5zdWJzY3JpYmUgPSAoKSA9PiB7XG4gICAgICAgIF9vYnNlcnZlcnMgPSBuZXcgU2V0KCk7XG4gICAgICAgIF9pdGVyYXRpb25Db3VudCA9IDA7XG4gICAgfTtcbiAgICByZXR1cm4ge1xuICAgICAgICBnZXQgb2JzZXJ2ZXJzKCkge1xuICAgICAgICAgICAgcmV0dXJuIEFycmF5LmZyb20oX29ic2VydmVycyk7XG4gICAgICAgIH0sXG4gICAgICAgIG5leHQsXG4gICAgICAgIHN1YnNjcmliZSxcbiAgICAgICAgdW5zdWJzY3JpYmUsXG4gICAgfTtcbn07XG5cbmZ1bmN0aW9uIGV4dHJhY3RGb3JtVmFsdWVzKGZpZWxkc1N0YXRlLCBmb3JtVmFsdWVzKSB7XG4gICAgY29uc3QgdmFsdWVzID0gKEFycmF5LmlzQXJyYXkoZmllbGRzU3RhdGUpID8gW10gOiB7fSk7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZmllbGRzU3RhdGUpIHtcbiAgICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChmaWVsZHNTdGF0ZSwga2V5KSkge1xuICAgICAgICAgICAgY29uc3QgZmllbGRTdGF0ZSA9IGZpZWxkc1N0YXRlW2tleV07XG4gICAgICAgICAgICBjb25zdCBmaWVsZFZhbHVlID0gZm9ybVZhbHVlc1trZXldO1xuICAgICAgICAgICAgaWYgKGZpZWxkU3RhdGUgJiZcbiAgICAgICAgICAgICAgICAoaXNPYmplY3QoZmllbGRTdGF0ZSkgfHwgQXJyYXkuaXNBcnJheShmaWVsZFN0YXRlKSkgJiZcbiAgICAgICAgICAgICAgICBmaWVsZFZhbHVlKSB7XG4gICAgICAgICAgICAgICAgdmFsdWVzW2tleV0gPSBleHRyYWN0Rm9ybVZhbHVlcyhmaWVsZFN0YXRlLCBmaWVsZFZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGZpZWxkc1N0YXRlW2tleV0pIHtcbiAgICAgICAgICAgICAgICB2YWx1ZXNba2V5XSA9IGZpZWxkVmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlcztcbn1cblxuY29uc3QgaGFzT3duID0gKHZhbHVlLCBrZXkpID0+IHZhbHVlICE9PSBudWxsICYmXG4gICAgaXNPYmplY3RUeXBlKHZhbHVlKSAmJlxuICAgIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbCh2YWx1ZSwga2V5KTtcbnZhciBoYXMgPSAob2JqZWN0LCBwYXRoKSA9PiB7XG4gICAgaWYgKCFwYXRoKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgbGV0IHJlc3VsdCA9IG9iamVjdDtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBpc0tleShwYXRoKSA/IFtwYXRoXSA6IHN0cmluZ1RvUGF0aChwYXRoKSkge1xuICAgICAgICBpZiAoIWhhc093bihyZXN1bHQsIGtleSkpIHtcbiAgICAgICAgICAgIC8vIGBnZXRgIGFsc28gcmVzb2x2ZXMgYSBwYXRoIGhlbGQgYXMgYSBzaW5nbGUgbGl0ZXJhbCBrZXksIGVnIGB7ICdhLmInOiAxIH1gXG4gICAgICAgICAgICByZXR1cm4gaGFzT3duKG9iamVjdCwgcGF0aCk7XG4gICAgICAgIH1cbiAgICAgICAgcmVzdWx0ID0gcmVzdWx0W2tleV07XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xufTtcblxudmFyIGlzRWRpdGVkID0gKHJlZikgPT4gaXNDaGVja0JveElucHV0KHJlZilcbiAgICA/IHJlZi5jaGVja2VkICE9PSByZWYuZGVmYXVsdENoZWNrZWRcbiAgICA6ICFpc1JhZGlvSW5wdXQocmVmKSAmJlxuICAgICAgICAnZGVmYXVsdFZhbHVlJyBpbiByZWYgJiZcbiAgICAgICAgcmVmLnZhbHVlICE9PSByZWYuZGVmYXVsdFZhbHVlO1xuXG52YXIgaXNNdWx0aXBsZVNlbGVjdCA9IChlbGVtZW50KSA9PiBlbGVtZW50LnR5cGUgPT09IGBzZWxlY3QtbXVsdGlwbGVgO1xuXG52YXIgaXNSYWRpb09yQ2hlY2tib3ggPSAocmVmKSA9PiBpc1JhZGlvSW5wdXQocmVmKSB8fCBpc0NoZWNrQm94SW5wdXQocmVmKTtcblxudmFyIGxpdmUgPSAocmVmKSA9PiBpc0hUTUxFbGVtZW50KHJlZikgJiYgcmVmLmlzQ29ubmVjdGVkO1xuXG5mdW5jdGlvbiBpc0RpcnR5Q29udGFpbmVyKHZhbHVlKSB7XG4gICAgcmV0dXJuIEFycmF5LmlzQXJyYXkodmFsdWUpIHx8IGlzT2JqZWN0KHZhbHVlKTtcbn1cbmZ1bmN0aW9uIGNvbGxlY3REaXJ0eUZpZWxkTmFtZXMoZGlydHlUcmVlLCBjYWNoZWREaXJ0eUZpZWxkcywgcHJlZml4ID0gJycsIG5hbWVzID0gW10pIHtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBkaXJ0eVRyZWUpIHtcbiAgICAgICAgY29uc3QgcGF0aCA9IHByZWZpeCA/IGAke3ByZWZpeH0uJHtrZXl9YCA6IGtleTtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBkaXJ0eVRyZWVba2V5XTtcbiAgICAgICAgaWYgKGlzRGlydHlDb250YWluZXIodmFsdWUpICYmXG4gICAgICAgICAgICBpc0RpcnR5Q29udGFpbmVyKGdldChjYWNoZWREaXJ0eUZpZWxkcywgcGF0aCkpKSB7XG4gICAgICAgICAgICBjb2xsZWN0RGlydHlGaWVsZE5hbWVzKHZhbHVlLCBjYWNoZWREaXJ0eUZpZWxkcywgcGF0aCwgbmFtZXMpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgbmFtZXMucHVzaChwYXRoKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbmFtZXM7XG59XG5cbnZhciBvYmplY3RIYXNGdW5jdGlvbiA9IChkYXRhKSA9PiB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZGF0YSkge1xuICAgICAgICBpZiAoaXNGdW5jdGlvbihkYXRhW2tleV0pKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG59O1xuXG5mdW5jdGlvbiBpc1RyYXZlcnNhYmxlKHZhbHVlKSB7XG4gICAgcmV0dXJuIEFycmF5LmlzQXJyYXkodmFsdWUpIHx8IChpc09iamVjdCh2YWx1ZSkgJiYgIW9iamVjdEhhc0Z1bmN0aW9uKHZhbHVlKSk7XG59XG5mdW5jdGlvbiBpc1JlZ2lzdGVyZWRMZWFmKGZpZWxkUmVmKSB7XG4gICAgcmV0dXJuICEhKGZpZWxkUmVmICYmICdfZicgaW4gZmllbGRSZWYpO1xufVxuZnVuY3Rpb24gaXNFbXB0eURpcnR5Q29udGFpbmVyKHZhbHVlKSB7XG4gICAgcmV0dXJuIEFycmF5LmlzQXJyYXkodmFsdWUpXG4gICAgICAgID8gIXZhbHVlLnNvbWUoKGl0ZW0pID0+ICFpc1VuZGVmaW5lZChpdGVtKSlcbiAgICAgICAgOiAhT2JqZWN0LmtleXModmFsdWUpLmxlbmd0aDtcbn1cbmZ1bmN0aW9uIGNsZWFyRGlydHlGaWVsZChjb250YWluZXIsIGtleSkge1xuICAgIGlmIChBcnJheS5pc0FycmF5KGNvbnRhaW5lcikpIHtcbiAgICAgICAgY29udGFpbmVyW2tleV0gPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBkZWxldGUgY29udGFpbmVyW2tleV07XG4gICAgfVxufVxuZnVuY3Rpb24gbWFya0ZpZWxkc0RpcnR5KGRhdGEsIGZpZWxkcyA9IHt9LCBmaWVsZFJlZnMpIHtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBkYXRhKSB7XG4gICAgICAgIGNvbnN0IHZhbHVlID0gZGF0YVtrZXldO1xuICAgICAgICBjb25zdCBmaWVsZFJlZiA9IGZpZWxkUmVmcyAmJiBmaWVsZFJlZnNba2V5XTtcbiAgICAgICAgaWYgKGlzVHJhdmVyc2FibGUodmFsdWUpICYmXG4gICAgICAgICAgICAoIUFycmF5LmlzQXJyYXkodmFsdWUpIHx8ICFpc1JlZ2lzdGVyZWRMZWFmKGZpZWxkUmVmKSkpIHtcbiAgICAgICAgICAgIGZpZWxkc1trZXldID0gQXJyYXkuaXNBcnJheSh2YWx1ZSkgPyBbXSA6IHt9O1xuICAgICAgICAgICAgbWFya0ZpZWxkc0RpcnR5KHZhbHVlLCBmaWVsZHNba2V5XSwgZmllbGRSZWYpO1xuICAgICAgICAgICAgaWYgKGlzRW1wdHlEaXJ0eUNvbnRhaW5lcihmaWVsZHNba2V5XSkpIHtcbiAgICAgICAgICAgICAgICBjbGVhckRpcnR5RmllbGQoZmllbGRzLCBrZXkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKCFpc1VuZGVmaW5lZCh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGZpZWxkc1trZXldID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZmllbGRzO1xufVxuZnVuY3Rpb24gZ2V0RGlydHlGaWVsZHMoZGF0YSwgZm9ybVZhbHVlcywgZGlydHlGaWVsZHNGcm9tVmFsdWVzLCBmaWVsZFJlZnMpIHtcbiAgICBpZiAoIWRpcnR5RmllbGRzRnJvbVZhbHVlcykge1xuICAgICAgICBkaXJ0eUZpZWxkc0Zyb21WYWx1ZXMgPSBtYXJrRmllbGRzRGlydHkoZm9ybVZhbHVlcywgQXJyYXkuaXNBcnJheShmb3JtVmFsdWVzKSA/IFtdIDoge30sIGZpZWxkUmVmcyk7XG4gICAgfVxuICAgIGZvciAoY29uc3Qga2V5IGluIGRhdGEpIHtcbiAgICAgICAgY29uc3QgdmFsdWUgPSBkYXRhW2tleV07XG4gICAgICAgIGNvbnN0IGZpZWxkUmVmID0gZmllbGRSZWZzICYmIGZpZWxkUmVmc1trZXldO1xuICAgICAgICBpZiAoaXNUcmF2ZXJzYWJsZSh2YWx1ZSkgJiZcbiAgICAgICAgICAgICghQXJyYXkuaXNBcnJheSh2YWx1ZSkgfHwgIWlzUmVnaXN0ZXJlZExlYWYoZmllbGRSZWYpKSkge1xuICAgICAgICAgICAgaWYgKGlzVW5kZWZpbmVkKGZvcm1WYWx1ZXMpIHx8IGlzUHJpbWl0aXZlKGRpcnR5RmllbGRzRnJvbVZhbHVlc1trZXldKSkge1xuICAgICAgICAgICAgICAgIGRpcnR5RmllbGRzRnJvbVZhbHVlc1trZXldID0gbWFya0ZpZWxkc0RpcnR5KHZhbHVlLCBBcnJheS5pc0FycmF5KHZhbHVlKSA/IFtdIDoge30sIGZpZWxkUmVmKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGdldERpcnR5RmllbGRzKHZhbHVlLCBpc051bGxPclVuZGVmaW5lZChmb3JtVmFsdWVzKSA/IHt9IDogZm9ybVZhbHVlc1trZXldLCBkaXJ0eUZpZWxkc0Zyb21WYWx1ZXNba2V5XSwgZmllbGRSZWYpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGlzRW1wdHlEaXJ0eUNvbnRhaW5lcihkaXJ0eUZpZWxkc0Zyb21WYWx1ZXNba2V5XSkpIHtcbiAgICAgICAgICAgICAgICBjbGVhckRpcnR5RmllbGQoZGlydHlGaWVsZHNGcm9tVmFsdWVzLCBrZXkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGRlZXBFcXVhbCh2YWx1ZSwgZm9ybVZhbHVlc1trZXldKSkge1xuICAgICAgICAgICAgY2xlYXJEaXJ0eUZpZWxkKGRpcnR5RmllbGRzRnJvbVZhbHVlcywga2V5KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGRpcnR5RmllbGRzRnJvbVZhbHVlc1trZXldID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gZGlydHlGaWVsZHNGcm9tVmFsdWVzO1xufVxuXG52YXIgZ2V0RmllbGRBcnJheUl0ZW1OYW1lcyA9IChuYW1lcywgbmFtZSkgPT4ge1xuICAgIGNvbnN0IHNlZ21lbnRzID0gbmFtZS5zcGxpdCgnLicpO1xuICAgIGNvbnN0IG1hdGNoZXMgPSBbXTtcbiAgICBsZXQgcHJlZml4ID0gc2VnbWVudHNbMF07XG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCBzZWdtZW50cy5sZW5ndGg7IHByZWZpeCArPSAnLicgKyBzZWdtZW50c1tpKytdKSB7XG4gICAgICAgIGlmICghaXNOYU4oK3NlZ21lbnRzW2ldKSAmJiBuYW1lcy5oYXMocHJlZml4KSkge1xuICAgICAgICAgICAgbWF0Y2hlcy5wdXNoKGAke3ByZWZpeH0uJHtzZWdtZW50c1tpXX1gKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbWF0Y2hlcztcbn07XG5cbnZhciBnZXRGaWVsZFZhbHVlQXMgPSAodmFsdWUsIHsgdmFsdWVBc051bWJlciwgdmFsdWVBc0RhdGUsIHNldFZhbHVlQXMgfSkgPT4gaXNVbmRlZmluZWQodmFsdWUpXG4gICAgPyB2YWx1ZVxuICAgIDogdmFsdWVBc051bWJlclxuICAgICAgICA/IHZhbHVlID09PSAnJ1xuICAgICAgICAgICAgPyBOYU5cbiAgICAgICAgICAgIDogdmFsdWVcbiAgICAgICAgICAgICAgICA/ICt2YWx1ZVxuICAgICAgICAgICAgICAgIDogdmFsdWVcbiAgICAgICAgOiB2YWx1ZUFzRGF0ZSAmJiBpc1N0cmluZyh2YWx1ZSlcbiAgICAgICAgICAgID8gbmV3IERhdGUodmFsdWUpXG4gICAgICAgICAgICA6IHNldFZhbHVlQXNcbiAgICAgICAgICAgICAgICA/IHNldFZhbHVlQXModmFsdWUpXG4gICAgICAgICAgICAgICAgOiB2YWx1ZTtcblxuZnVuY3Rpb24gZ2V0RmllbGRWYWx1ZShfZikge1xuICAgIGNvbnN0IHJlZiA9IF9mLnJlZjtcbiAgICBpZiAoaXNGaWxlSW5wdXQocmVmKSkge1xuICAgICAgICByZXR1cm4gcmVmLmZpbGVzO1xuICAgIH1cbiAgICBpZiAoaXNSYWRpb0lucHV0KHJlZikpIHtcbiAgICAgICAgcmV0dXJuIGdldFJhZGlvVmFsdWUoX2YucmVmcykudmFsdWU7XG4gICAgfVxuICAgIGlmIChpc011bHRpcGxlU2VsZWN0KHJlZikpIHtcbiAgICAgICAgcmV0dXJuIFsuLi5yZWYuc2VsZWN0ZWRPcHRpb25zXS5tYXAoKHsgdmFsdWUgfSkgPT4gdmFsdWUpO1xuICAgIH1cbiAgICBpZiAoaXNDaGVja0JveElucHV0KHJlZikpIHtcbiAgICAgICAgcmV0dXJuIGdldENoZWNrYm94VmFsdWUoX2YucmVmcykudmFsdWU7XG4gICAgfVxuICAgIHJldHVybiBnZXRGaWVsZFZhbHVlQXMocmVmLnZhbHVlLCBfZik7XG59XG5cbnZhciBnZXRSZXNvbHZlck9wdGlvbnMgPSAoZmllbGRzTmFtZXMsIF9maWVsZHMsIGNyaXRlcmlhTW9kZSwgc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbikgPT4ge1xuICAgIGNvbnN0IGZpZWxkcyA9IHt9O1xuICAgIGZvciAoY29uc3QgbmFtZSBvZiBmaWVsZHNOYW1lcykge1xuICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgZmllbGQgJiYgc2V0KGZpZWxkcywgbmFtZSwgZmllbGQuX2YpO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBjcml0ZXJpYU1vZGUsXG4gICAgICAgIG5hbWVzOiBbLi4uZmllbGRzTmFtZXNdLFxuICAgICAgICBmaWVsZHMsXG4gICAgICAgIHNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24sXG4gICAgfTtcbn07XG5cbnZhciBnZXRSdWxlVmFsdWUgPSAocnVsZSkgPT4gaXNVbmRlZmluZWQocnVsZSlcbiAgICA/IHJ1bGVcbiAgICA6IGlzUmVnZXgocnVsZSlcbiAgICAgICAgPyBydWxlLnNvdXJjZVxuICAgICAgICA6IGlzT2JqZWN0KHJ1bGUpXG4gICAgICAgICAgICA/IGlzUmVnZXgocnVsZS52YWx1ZSlcbiAgICAgICAgICAgICAgICA/IHJ1bGUudmFsdWUuc291cmNlXG4gICAgICAgICAgICAgICAgOiBydWxlLnZhbHVlXG4gICAgICAgICAgICA6IHJ1bGU7XG5cbmNvbnN0IEFTWU5DX0ZVTkNUSU9OID0gJ0FzeW5jRnVuY3Rpb24nO1xudmFyIGhhc1Byb21pc2VWYWxpZGF0aW9uID0gKGZpZWxkUmVmZXJlbmNlKSA9PiB7XG4gICAgaWYgKCFmaWVsZFJlZmVyZW5jZSB8fCAhZmllbGRSZWZlcmVuY2UudmFsaWRhdGUpXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICBpZiAoaXNGdW5jdGlvbihmaWVsZFJlZmVyZW5jZS52YWxpZGF0ZSkpIHtcbiAgICAgICAgcmV0dXJuIGZpZWxkUmVmZXJlbmNlLnZhbGlkYXRlLmNvbnN0cnVjdG9yLm5hbWUgPT09IEFTWU5DX0ZVTkNUSU9OO1xuICAgIH1cbiAgICBpZiAoaXNPYmplY3QoZmllbGRSZWZlcmVuY2UudmFsaWRhdGUpKSB7XG4gICAgICAgIGZvciAoY29uc3Qga2V5IGluIGZpZWxkUmVmZXJlbmNlLnZhbGlkYXRlKSB7XG4gICAgICAgICAgICBpZiAoZmllbGRSZWZlcmVuY2UudmFsaWRhdGVba2V5XS5jb25zdHJ1Y3RvclxuICAgICAgICAgICAgICAgIC5uYW1lID09PSBBU1lOQ19GVU5DVElPTikge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn07XG5cbnZhciBoYXNWYWxpZGF0aW9uID0gKG9wdGlvbnMpID0+IG9wdGlvbnMubW91bnQgJiZcbiAgICAob3B0aW9ucy5yZXF1aXJlZCB8fFxuICAgICAgICAoIWlzVW5kZWZpbmVkKG9wdGlvbnMucmVxdWlyZWQpICYmIG9wdGlvbnMucmVxdWlyZWQgIT09IGZhbHNlKSB8fFxuICAgICAgICAhaXNVbmRlZmluZWQob3B0aW9ucy5taW4pIHx8XG4gICAgICAgICFpc1VuZGVmaW5lZChvcHRpb25zLm1heCkgfHxcbiAgICAgICAgIWlzVW5kZWZpbmVkKG9wdGlvbnMubWF4TGVuZ3RoKSB8fFxuICAgICAgICAhaXNVbmRlZmluZWQob3B0aW9ucy5taW5MZW5ndGgpIHx8XG4gICAgICAgIG9wdGlvbnMucGF0dGVybiB8fFxuICAgICAgICBvcHRpb25zLnZhbGlkYXRlKTtcblxuZnVuY3Rpb24gc2NoZW1hRXJyb3JMb29rdXAoZXJyb3JzLCBfZmllbGRzLCBuYW1lKSB7XG4gICAgY29uc3QgZXJyb3IgPSBnZXQoZXJyb3JzLCBuYW1lKTtcbiAgICBpZiAoKGVycm9yICYmIChlcnJvci50eXBlIHx8IGVycm9yLm1lc3NhZ2UpKSB8fCBBcnJheS5pc0FycmF5KGVycm9yKSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgZXJyb3IsXG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBjb25zdCBuYW1lcyA9IG5hbWUuc3BsaXQoJy4nKTtcbiAgICB3aGlsZSAobmFtZXMubGVuZ3RoKSB7XG4gICAgICAgIGNvbnN0IGZpZWxkTmFtZSA9IG5hbWVzLmpvaW4oJy4nKTtcbiAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgY29uc3QgZm91bmRFcnJvciA9IGdldChlcnJvcnMsIGZpZWxkTmFtZSk7XG4gICAgICAgIGlmIChmaWVsZCAmJiAhQXJyYXkuaXNBcnJheShmaWVsZCkgJiYgbmFtZSAhPT0gZmllbGROYW1lKSB7XG4gICAgICAgICAgICByZXR1cm4geyBuYW1lIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvdW5kRXJyb3IgJiYgZm91bmRFcnJvci50eXBlKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIG5hbWU6IGZpZWxkTmFtZSxcbiAgICAgICAgICAgICAgICBlcnJvcjogZm91bmRFcnJvcixcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGZvdW5kRXJyb3IgJiYgZm91bmRFcnJvci5yb290ICYmIGZvdW5kRXJyb3Iucm9vdC50eXBlKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIG5hbWU6IGAke2ZpZWxkTmFtZX0ucm9vdGAsXG4gICAgICAgICAgICAgICAgZXJyb3I6IGZvdW5kRXJyb3Iucm9vdCxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgbmFtZXMucG9wKCk7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIG5hbWUsXG4gICAgfTtcbn1cblxudmFyIHNob3VsZFJlbmRlckZvcm1TdGF0ZSA9IChmb3JtU3RhdGVEYXRhLCBfcHJveHlGb3JtU3RhdGUsIGlzUm9vdCkgPT4ge1xuICAgIGNvbnN0IGtleXMgPSBPYmplY3Qua2V5cyhmb3JtU3RhdGVEYXRhKS5maWx0ZXIoKGtleSkgPT4ga2V5ICE9PSAnbmFtZScpO1xuICAgIHJldHVybiAoIWtleXMubGVuZ3RoIHx8XG4gICAgICAgIChpc1Jvb3QgJiYga2V5cy5sZW5ndGggPj0gT2JqZWN0LmtleXMoX3Byb3h5Rm9ybVN0YXRlKS5sZW5ndGgpIHx8XG4gICAgICAgIGtleXMuZmluZCgoa2V5KSA9PiBfcHJveHlGb3JtU3RhdGVba2V5XSA9PT1cbiAgICAgICAgICAgICghaXNSb290IHx8IFZBTElEQVRJT05fTU9ERS5hbGwpKSk7XG59O1xuXG5jb25zdCBpc05hbWVNYXRjaCA9IChjdXJyZW50TmFtZSwgc2lnbmFsTmFtZSwgZXhhY3QpID0+IGV4YWN0XG4gICAgPyBjdXJyZW50TmFtZSA9PT0gc2lnbmFsTmFtZSB8fCBjdXJyZW50TmFtZS5zdGFydHNXaXRoKHNpZ25hbE5hbWUgKyAnLicpXG4gICAgOiBjdXJyZW50TmFtZS5zdGFydHNXaXRoKHNpZ25hbE5hbWUpIHx8IHNpZ25hbE5hbWUuc3RhcnRzV2l0aChjdXJyZW50TmFtZSk7XG52YXIgc2hvdWxkU3Vic2NyaWJlQnlOYW1lID0gKG5hbWUsIHNpZ25hbE5hbWUsIGV4YWN0KSA9PiB7XG4gICAgaWYgKCFuYW1lIHx8ICFzaWduYWxOYW1lIHx8IG5hbWUgPT09IHNpZ25hbE5hbWUpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlmICghQXJyYXkuaXNBcnJheShuYW1lKSkge1xuICAgICAgICByZXR1cm4gaXNOYW1lTWF0Y2gobmFtZSwgc2lnbmFsTmFtZSwgZXhhY3QpO1xuICAgIH1cbiAgICBmb3IgKGNvbnN0IGN1cnJlbnROYW1lIG9mIG5hbWUpIHtcbiAgICAgICAgaWYgKGN1cnJlbnROYW1lICYmIGlzTmFtZU1hdGNoKGN1cnJlbnROYW1lLCBzaWduYWxOYW1lLCBleGFjdCkpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn07XG5cbnZhciBza2lwVmFsaWRhdGlvbiA9IChpc0JsdXJFdmVudCwgaXNUb3VjaGVkLCBpc1N1Ym1pdHRlZCwgcmVWYWxpZGF0ZU1vZGUsIG1vZGUpID0+IHtcbiAgICBpZiAobW9kZS5pc09uQWxsKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgZWxzZSBpZiAoIWlzU3VibWl0dGVkICYmIG1vZGUuaXNPblRvdWNoKSB7XG4gICAgICAgIHJldHVybiAhKGlzVG91Y2hlZCB8fCBpc0JsdXJFdmVudCk7XG4gICAgfVxuICAgIGVsc2UgaWYgKGlzU3VibWl0dGVkID8gcmVWYWxpZGF0ZU1vZGUuaXNPbkJsdXIgOiBtb2RlLmlzT25CbHVyKSB7XG4gICAgICAgIHJldHVybiAhaXNCbHVyRXZlbnQ7XG4gICAgfVxuICAgIGVsc2UgaWYgKGlzU3VibWl0dGVkID8gcmVWYWxpZGF0ZU1vZGUuaXNPbkNoYW5nZSA6IG1vZGUuaXNPbkNoYW5nZSkge1xuICAgICAgICByZXR1cm4gaXNCbHVyRXZlbnQ7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xufTtcblxudmFyIHVuc2V0RW1wdHlBcnJheSA9IChyZWYsIG5hbWUpID0+IHtcbiAgICBjb25zdCBhcnJheSA9IGdldChyZWYsIG5hbWUpO1xuICAgICFjb21wYWN0KGFycmF5KS5sZW5ndGggJiZcbiAgICAgICAgIShhcnJheSAmJiBhcnJheS5yb290KSAmJlxuICAgICAgICB1bnNldChyZWYsIG5hbWUpO1xufTtcblxuY29uc3QgZGVmYXVsdE9wdGlvbnMgPSB7XG4gICAgbW9kZTogVkFMSURBVElPTl9NT0RFLm9uU3VibWl0LFxuICAgIHJlVmFsaWRhdGVNb2RlOiBWQUxJREFUSU9OX01PREUub25DaGFuZ2UsXG4gICAgc2hvdWxkRm9jdXNFcnJvcjogdHJ1ZSxcbn07XG5jb25zdCByZXBsYWNlRGlydHlGaWVsZHNJblBsYWNlID0gKGRpcnR5RmllbGRzLCBuZXh0RGlydHlGaWVsZHMpID0+IHtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBkaXJ0eUZpZWxkcykge1xuICAgICAgICBkZWxldGUgZGlydHlGaWVsZHNba2V5XTtcbiAgICB9XG4gICAgT2JqZWN0LmFzc2lnbihkaXJ0eUZpZWxkcywgbmV4dERpcnR5RmllbGRzKTtcbn07XG5jb25zdCBERUZBVUxUX0ZPUk1fU1RBVEUgPSB7XG4gICAgc3VibWl0Q291bnQ6IDAsXG4gICAgaXNEaXJ0eTogZmFsc2UsXG4gICAgaXNSZWFkeTogZmFsc2UsXG4gICAgaXNWYWxpZGF0aW5nOiBmYWxzZSxcbiAgICBpc1N1Ym1pdHRlZDogZmFsc2UsXG4gICAgaXNTdWJtaXR0aW5nOiBmYWxzZSxcbiAgICBpc1N1Ym1pdFN1Y2Nlc3NmdWw6IGZhbHNlLFxuICAgIGlzVmFsaWQ6IGZhbHNlLFxuICAgIHRvdWNoZWRGaWVsZHM6IHt9LFxuICAgIGRpcnR5RmllbGRzOiB7fSxcbiAgICB2YWxpZGF0aW5nRmllbGRzOiB7fSxcbn07XG5mdW5jdGlvbiBjcmVhdGVGb3JtQ29udHJvbChwcm9wcyA9IHt9KSB7XG4gICAgbGV0IF9vcHRpb25zID0ge1xuICAgICAgICAuLi5kZWZhdWx0T3B0aW9ucyxcbiAgICAgICAgLi4ucHJvcHMsXG4gICAgfTtcbiAgICBsZXQgX2Zvcm1TdGF0ZSA9IHtcbiAgICAgICAgLi4uY2xvbmVPYmplY3QoREVGQVVMVF9GT1JNX1NUQVRFKSxcbiAgICAgICAgaXNMb2FkaW5nOiBpc0Z1bmN0aW9uKF9vcHRpb25zLmRlZmF1bHRWYWx1ZXMpLFxuICAgICAgICBlcnJvcnM6IF9vcHRpb25zLmVycm9ycyB8fCB7fSxcbiAgICAgICAgZGlzYWJsZWQ6IF9vcHRpb25zLmRpc2FibGVkIHx8IGZhbHNlLFxuICAgIH07XG4gICAgbGV0IF9maWVsZHMgPSB7fTtcbiAgICBsZXQgX2RlZmF1bHRWYWx1ZXMgPSBpc09iamVjdChfb3B0aW9ucy5kZWZhdWx0VmFsdWVzKSB8fCBpc09iamVjdChfb3B0aW9ucy52YWx1ZXMpXG4gICAgICAgID8gY2xvbmVPYmplY3QoX29wdGlvbnMuZGVmYXVsdFZhbHVlcyB8fCBfb3B0aW9ucy52YWx1ZXMpIHx8IHt9XG4gICAgICAgIDoge307XG4gICAgbGV0IF9mb3JtVmFsdWVzID0gX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlclxuICAgICAgICA/IHt9XG4gICAgICAgIDogY2xvbmVPYmplY3QoX2RlZmF1bHRWYWx1ZXMpO1xuICAgIGxldCBfc3RhdGUgPSB7XG4gICAgICAgIGFjdGlvbjogZmFsc2UsXG4gICAgICAgIGFjdGlvbkFycmF5TGVuZ3RoczogbmV3IE1hcCgpLFxuICAgICAgICBtb3VudDogZmFsc2UsXG4gICAgICAgIHdhdGNoOiBmYWxzZSxcbiAgICAgICAga2VlcElzVmFsaWQ6IGZhbHNlLFxuICAgIH07XG4gICAgbGV0IF9kaXJ0eUZpZWxkc1N0YWxlID0gZmFsc2U7XG4gICAgbGV0IF9uYW1lcyA9IHtcbiAgICAgICAgbW91bnQ6IG5ldyBTZXQoKSxcbiAgICAgICAgZGlzYWJsZWQ6IG5ldyBTZXQoKSxcbiAgICAgICAgdW5Nb3VudDogbmV3IFNldCgpLFxuICAgICAgICBhcnJheTogbmV3IFNldCgpLFxuICAgICAgICB3YXRjaDogbmV3IFNldCgpLFxuICAgICAgICByZWdpc3Rlck5hbWU6IG5ldyBTZXQoKSxcbiAgICB9O1xuICAgIGNvbnN0IGRlbGF5RXJyb3JDYWxsYmFja3MgPSB7fTtcbiAgICBjb25zdCB0aW1lcnMgPSB7fTtcbiAgICBjb25zdCBfdmFsdWVzU3Vic2NyaWJlcnMgPSBuZXcgU2V0KCk7XG4gICAgbGV0IF92YWxpZGF0aW9uTW9kZUJlZm9yZVN1Ym1pdCA9IGdldFZhbGlkYXRpb25Nb2Rlcyhfb3B0aW9ucy5tb2RlKTtcbiAgICBsZXQgX3ZhbGlkYXRpb25Nb2RlQWZ0ZXJTdWJtaXQgPSBnZXRWYWxpZGF0aW9uTW9kZXMoX29wdGlvbnMucmVWYWxpZGF0ZU1vZGUpO1xuICAgIGNvbnN0IGRlZmF1bHRQcm94eUZvcm1TdGF0ZSA9IHtcbiAgICAgICAgaXNEaXJ0eTogZmFsc2UsXG4gICAgICAgIGRpcnR5RmllbGRzOiBmYWxzZSxcbiAgICAgICAgdmFsaWRhdGluZ0ZpZWxkczogZmFsc2UsXG4gICAgICAgIHRvdWNoZWRGaWVsZHM6IGZhbHNlLFxuICAgICAgICBpc1ZhbGlkYXRpbmc6IGZhbHNlLFxuICAgICAgICBpc1ZhbGlkOiBmYWxzZSxcbiAgICAgICAgZXJyb3JzOiBmYWxzZSxcbiAgICB9O1xuICAgIGNvbnN0IF9wcm94eUZvcm1TdGF0ZSA9IHtcbiAgICAgICAgLi4uZGVmYXVsdFByb3h5Rm9ybVN0YXRlLFxuICAgIH07XG4gICAgY29uc3QgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlID0ge307XG4gICAgY29uc3QgX2lzVHJhY2tlZCA9ICguLi5rZXlzKSA9PiBrZXlzLnNvbWUoKGtleSkgPT4gX3Byb3h5Rm9ybVN0YXRlW2tleV0gfHwgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlW2tleV0pO1xuICAgIGNvbnN0IF9oYXNWYWx1ZXNTdWJzY3JpYmVyID0gKG5hbWUpID0+IHtcbiAgICAgICAgZm9yIChjb25zdCBzdWJzY3JpYmVyIG9mIF92YWx1ZXNTdWJzY3JpYmVycykge1xuICAgICAgICAgICAgaWYgKHNob3VsZFN1YnNjcmliZUJ5TmFtZShzdWJzY3JpYmVyLm5hbWUsIG5hbWUsIHN1YnNjcmliZXIuZXhhY3QpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH07XG4gICAgY29uc3QgX3N1YmplY3RzID0ge1xuICAgICAgICBhcnJheTogY3JlYXRlU3ViamVjdCgpLFxuICAgICAgICBzdGF0ZTogY3JlYXRlU3ViamVjdCgpLFxuICAgIH07XG4gICAgbGV0IF9zZXRWYWxpZENhbGxJZCA9IDA7XG4gICAgbGV0IF9yZXNldENhbGxJZCA9IDA7XG4gICAgbGV0IHNob3VsZERpc3BsYXlBbGxBc3NvY2lhdGVkRXJyb3JzID0gX29wdGlvbnMuY3JpdGVyaWFNb2RlID09PSBWQUxJREFUSU9OX01PREUuYWxsO1xuICAgIGNvbnN0IGRlYm91bmNlID0gKG5hbWUsIGNhbGxiYWNrKSA9PiAod2FpdCkgPT4ge1xuICAgICAgICBjbGVhclRpbWVvdXQodGltZXJzW25hbWVdKTtcbiAgICAgICAgdGltZXJzW25hbWVdID0gc2V0VGltZW91dChjYWxsYmFjaywgd2FpdCk7XG4gICAgfTtcbiAgICBjb25zdCBjYW5jZWxEZWxheWVkRXJyb3IgPSAobmFtZSkgPT4ge1xuICAgICAgICBjbGVhclRpbWVvdXQodGltZXJzW25hbWVdKTtcbiAgICAgICAgZGVsZXRlIHRpbWVyc1tuYW1lXTtcbiAgICAgICAgZGVsZXRlIGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV07XG4gICAgfTtcbiAgICBjb25zdCBjYW5jZWxEZWxheWVkRXJyb3JUcmVlID0gKG5hbWUpID0+IHtcbiAgICAgICAgY2FuY2VsRGVsYXllZEVycm9yKG5hbWUpO1xuICAgICAgICBjb25zdCBwcmVmaXggPSBgJHtuYW1lfS5gO1xuICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiBPYmplY3Qua2V5cyhkZWxheUVycm9yQ2FsbGJhY2tzKSkge1xuICAgICAgICAgICAga2V5LnN0YXJ0c1dpdGgocHJlZml4KSAmJiBjYW5jZWxEZWxheWVkRXJyb3Ioa2V5KTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgX3NldFZhbGlkID0gYXN5bmMgKHNob3VsZFVwZGF0ZVZhbGlkKSA9PiB7XG4gICAgICAgIGlmIChfc3RhdGUua2VlcElzVmFsaWQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIV9vcHRpb25zLmRpc2FibGVkICYmIChfaXNUcmFja2VkKCdpc1ZhbGlkJykgfHwgc2hvdWxkVXBkYXRlVmFsaWQpKSB7XG4gICAgICAgICAgICBjb25zdCBjYWxsSWQgPSArK19zZXRWYWxpZENhbGxJZDtcbiAgICAgICAgICAgIGxldCBpc1ZhbGlkO1xuICAgICAgICAgICAgaWYgKF9vcHRpb25zLnJlc29sdmVyKSB7XG4gICAgICAgICAgICAgICAgaXNWYWxpZCA9IGlzRW1wdHlPYmplY3QoKGF3YWl0IF9ydW5TY2hlbWEoKSkuZXJyb3JzKTtcbiAgICAgICAgICAgICAgICBjYWxsSWQgPT09IF9zZXRWYWxpZENhbGxJZCAmJiBfdXBkYXRlSXNWYWxpZGF0aW5nKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBpc1ZhbGlkID0gYXdhaXQgZXhlY3V0ZUJ1aWx0SW5WYWxpZGF0aW9uKHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGRzOiBfZmllbGRzLFxuICAgICAgICAgICAgICAgICAgICBvbmx5Q2hlY2tWYWxpZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgZXZlbnRUeXBlOiBFVkVOVFMuVkFMSUQsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoY2FsbElkID09PSBfc2V0VmFsaWRDYWxsSWQgJiYgaXNWYWxpZCAhPT0gX2Zvcm1TdGF0ZS5pc1ZhbGlkKSB7XG4gICAgICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBfdXBkYXRlSXNWYWxpZGF0aW5nID0gKG5hbWVzLCBpc1ZhbGlkYXRpbmcpID0+IHtcbiAgICAgICAgaWYgKCFfb3B0aW9ucy5kaXNhYmxlZCAmJiBfaXNUcmFja2VkKCdpc1ZhbGlkYXRpbmcnLCAndmFsaWRhdGluZ0ZpZWxkcycpKSB7XG4gICAgICAgICAgICAobmFtZXMgfHwgX25hbWVzLm1vdW50KS5mb3JFYWNoKChuYW1lKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKG5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgaXNWYWxpZGF0aW5nXG4gICAgICAgICAgICAgICAgICAgICAgICA/IHNldChfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMsIG5hbWUsIGlzVmFsaWRhdGluZylcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdW5zZXQoX2Zvcm1TdGF0ZS52YWxpZGF0aW5nRmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICB2YWxpZGF0aW5nRmllbGRzOiBfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMsXG4gICAgICAgICAgICAgICAgaXNWYWxpZGF0aW5nOiAhaXNFbXB0eU9iamVjdChfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IF91cGRhdGVEaXJ0eUZpZWxkcyA9ICgpID0+IHtcbiAgICAgICAgX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcyA9IGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBfZm9ybVZhbHVlcywgdW5kZWZpbmVkLCBfZmllbGRzKTtcbiAgICB9O1xuICAgIGNvbnN0IF9zZXRGaWVsZEFycmF5ID0gKG5hbWUsIHZhbHVlcyA9IFtdLCBtZXRob2QsIGFyZ3MsIHNob3VsZFNldFZhbHVlcyA9IHRydWUsIHNob3VsZFVwZGF0ZUZpZWxkc0FuZFN0YXRlID0gdHJ1ZSkgPT4ge1xuICAgICAgICBpZiAoYXJncyAmJiBtZXRob2QgJiYgIV9vcHRpb25zLmRpc2FibGVkKSB7XG4gICAgICAgICAgICBfc3RhdGUuYWN0aW9uID0gdHJ1ZTtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkcyA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIGlmICghX3N0YXRlLmFjdGlvbkFycmF5TGVuZ3Rocy5oYXMobmFtZSkpIHtcbiAgICAgICAgICAgICAgICBfc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLnNldChuYW1lLCBBcnJheS5pc0FycmF5KGZpZWxkcykgPyBmaWVsZHMubGVuZ3RoIDogMCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoc2hvdWxkVXBkYXRlRmllbGRzQW5kU3RhdGUgJiYgQXJyYXkuaXNBcnJheShmaWVsZHMpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGRWYWx1ZXMgPSBtZXRob2QoZmllbGRzLCBhcmdzLmFyZ0EsIGFyZ3MuYXJnQik7XG4gICAgICAgICAgICAgICAgc2hvdWxkU2V0VmFsdWVzICYmIHNldChfZmllbGRzLCBuYW1lLCBmaWVsZFZhbHVlcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBmaWVsZEFycmF5RXJyb3JzID0gZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgIGlmIChzaG91bGRVcGRhdGVGaWVsZHNBbmRTdGF0ZSAmJiBBcnJheS5pc0FycmF5KGZpZWxkQXJyYXlFcnJvcnMpKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgcm9vdEVycm9yID0gZmllbGRBcnJheUVycm9ycy5yb290O1xuICAgICAgICAgICAgICAgIGNvbnN0IGVycm9ycyA9IG1ldGhvZChmaWVsZEFycmF5RXJyb3JzLCBhcmdzLmFyZ0EsIGFyZ3MuYXJnQikgfHwgZmllbGRBcnJheUVycm9ycztcbiAgICAgICAgICAgICAgICBpZiAocm9vdEVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIGVycm9ycy5yb290ID0gcm9vdEVycm9yO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBzaG91bGRTZXRWYWx1ZXMgJiYgc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lLCBlcnJvcnMpO1xuICAgICAgICAgICAgICAgIHVuc2V0RW1wdHlBcnJheShfZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLl9mb3JtU3RhdGUuZXJyb3JzIH07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCB0b3VjaGVkRmllbGRzQXJyYXkgPSBnZXQoX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIGNvbnN0IHNob3VsZFVwZGF0ZVRvdWNoZWRGaWVsZHMgPSBzaG91bGRVcGRhdGVGaWVsZHNBbmRTdGF0ZSAmJiBBcnJheS5pc0FycmF5KHRvdWNoZWRGaWVsZHNBcnJheSk7XG4gICAgICAgICAgICBpZiAoc2hvdWxkVXBkYXRlVG91Y2hlZEZpZWxkcykge1xuICAgICAgICAgICAgICAgIGNvbnN0IHRvdWNoZWRGaWVsZHMgPSBtZXRob2QodG91Y2hlZEZpZWxkc0FycmF5LCBhcmdzLmFyZ0EsIGFyZ3MuYXJnQik7XG4gICAgICAgICAgICAgICAgc2hvdWxkU2V0VmFsdWVzICYmIHNldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUsIHRvdWNoZWRGaWVsZHMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgZGlydHlGaWVsZHNBcnJheSA9IGdldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIGlmIChzaG91bGRVcGRhdGVGaWVsZHNBbmRTdGF0ZSAmJiBBcnJheS5pc0FycmF5KGRpcnR5RmllbGRzQXJyYXkpKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZGlydHlGaWVsZHMgPSBtZXRob2QoZGlydHlGaWVsZHNBcnJheSwgYXJncy5hcmdBLCBhcmdzLmFyZ0IpIHx8IGRpcnR5RmllbGRzQXJyYXk7XG4gICAgICAgICAgICAgICAgc2hvdWxkU2V0VmFsdWVzICYmIHNldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lLCBkaXJ0eUZpZWxkcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoX2lzVHJhY2tlZCgnZGlydHlGaWVsZHMnKSkge1xuICAgICAgICAgICAgICAgIF91cGRhdGVEaXJ0eUZpZWxkcygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgX2RpcnR5RmllbGRzU3RhbGUgPSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgaXNEaXJ0eTogX2dldERpcnR5KG5hbWUsIHZhbHVlcyksXG4gICAgICAgICAgICAgICAgZGlydHlGaWVsZHM6IF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsXG4gICAgICAgICAgICAgICAgLi4uKHNob3VsZFVwZGF0ZVRvdWNoZWRGaWVsZHMgJiYge1xuICAgICAgICAgICAgICAgICAgICB0b3VjaGVkRmllbGRzOiBfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsXG4gICAgICAgICAgICAgICAgfSksXG4gICAgICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgICAgICBpc1ZhbGlkOiBfZm9ybVN0YXRlLmlzVmFsaWQsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHNldChfZm9ybVZhbHVlcywgbmFtZSwgdmFsdWVzKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgdXBkYXRlRXJyb3JzID0gKG5hbWUsIGVycm9yKSA9PiB7XG4gICAgICAgIHNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSwgZXJyb3IpO1xuICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCBfc2V0RXJyb3JzID0gKGVycm9ycykgPT4ge1xuICAgICAgICBPYmplY3Qua2V5cyhkZWxheUVycm9yQ2FsbGJhY2tzKS5mb3JFYWNoKGNhbmNlbERlbGF5ZWRFcnJvcik7XG4gICAgICAgIGNvbnN0IGhhc0Vycm9ycyA9ICFpc0VtcHR5T2JqZWN0KGVycm9ycyk7XG4gICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0gZXJyb3JzO1xuICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICBlcnJvcnM6IF9mb3JtU3RhdGUuZXJyb3JzLFxuICAgICAgICAgICAgLi4uKGhhc0Vycm9ycyA/IHsgaXNWYWxpZDogZmFsc2UgfSA6IHt9KSxcbiAgICAgICAgfSk7XG4gICAgICAgICFoYXNFcnJvcnMgJiYgX3N0YXRlLm1vdW50ICYmIF9zZXRWYWxpZCgpO1xuICAgIH07XG4gICAgY29uc3QgaGFzRXhwbGljaXROdWxsSW50ZXJtZWRpYXRlID0gKG5hbWUpID0+IHtcbiAgICAgICAgY29uc3Qgc2VnbWVudHMgPSBpc0tleShuYW1lKSA/IFtuYW1lXSA6IHN0cmluZ1RvUGF0aChuYW1lKTtcbiAgICAgICAgbGV0IGZvcm1WYWx1ZXMgPSBfZm9ybVZhbHVlcztcbiAgICAgICAgbGV0IGRlZmF1bHRWYWx1ZXMgPSBfZGVmYXVsdFZhbHVlcztcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzZWdtZW50cy5sZW5ndGggLSAxOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGtleSA9IHNlZ21lbnRzW2ldO1xuICAgICAgICAgICAgZm9ybVZhbHVlcyA9IGlzTnVsbE9yVW5kZWZpbmVkKGZvcm1WYWx1ZXMpID8gZm9ybVZhbHVlcyA6IGZvcm1WYWx1ZXNba2V5XTtcbiAgICAgICAgICAgIGRlZmF1bHRWYWx1ZXMgPSBpc051bGxPclVuZGVmaW5lZChkZWZhdWx0VmFsdWVzKVxuICAgICAgICAgICAgICAgID8gZGVmYXVsdFZhbHVlc1xuICAgICAgICAgICAgICAgIDogZGVmYXVsdFZhbHVlc1trZXldO1xuICAgICAgICAgICAgaWYgKGZvcm1WYWx1ZXMgPT09IG51bGwgJiYgZGVmYXVsdFZhbHVlcyAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9O1xuICAgIGNvbnN0IGlzU3RhbGVBcnJheUZpZWxkID0gKG5hbWUpID0+IHtcbiAgICAgICAgaWYgKCFfc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLnNpemUpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzZWdtZW50cyA9IGlzS2V5KG5hbWUpID8gW25hbWVdIDogc3RyaW5nVG9QYXRoKG5hbWUpO1xuICAgICAgICBsZXQgbm9kZSA9IF9mb3JtVmFsdWVzO1xuICAgICAgICBsZXQgcGF0aCA9ICcnO1xuICAgICAgICBsZXQgb3duZXJEZXB0aCA9IC0xO1xuICAgICAgICBsZXQgb3duZXJQcmVBY3Rpb25MZW5ndGggPSAwO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHNlZ21lbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoaXNOdWxsT3JVbmRlZmluZWQobm9kZSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBrZXkgPSBzZWdtZW50c1tpXTtcbiAgICAgICAgICAgIHBhdGggPSBwYXRoID8gYCR7cGF0aH0uJHtrZXl9YCA6IGtleTtcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KG5vZGUpICYmICtrZXkgPj0gbm9kZS5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gb3duZXJEZXB0aCA9PT0gLTFcbiAgICAgICAgICAgICAgICAgICAgPyBmYWxzZVxuICAgICAgICAgICAgICAgICAgICA6IGkgPT09IG93bmVyRGVwdGhcbiAgICAgICAgICAgICAgICAgICAgICAgID8gK2tleSA8IG93bmVyUHJlQWN0aW9uTGVuZ3RoXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoX3N0YXRlLmFjdGlvbkFycmF5TGVuZ3Rocy5oYXMocGF0aCkpIHtcbiAgICAgICAgICAgICAgICBvd25lckRlcHRoID0gaSArIDE7XG4gICAgICAgICAgICAgICAgb3duZXJQcmVBY3Rpb25MZW5ndGggPSBfc3RhdGUuYWN0aW9uQXJyYXlMZW5ndGhzLmdldChwYXRoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG5vZGUgPSBub2RlW2tleV07XG4gICAgICAgICAgICBpZiAoaXNVbmRlZmluZWQobm9kZSkgJiZcbiAgICAgICAgICAgICAgICBvd25lckRlcHRoICE9PSAtMSAmJlxuICAgICAgICAgICAgICAgIGkgPiBvd25lckRlcHRoICYmXG4gICAgICAgICAgICAgICAgK3NlZ21lbnRzW293bmVyRGVwdGhdIDwgb3duZXJQcmVBY3Rpb25MZW5ndGgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfTtcbiAgICBjb25zdCB1cGRhdGVWYWxpZEFuZFZhbHVlID0gKG5hbWUsIHNob3VsZFNraXBTZXRWYWx1ZUFzLCB2YWx1ZSwgcmVmKSA9PiB7XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgIGlmIChoYXNFeHBsaWNpdE51bGxJbnRlcm1lZGlhdGUobmFtZSkgfHwgaXNTdGFsZUFycmF5RmllbGQobmFtZSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCB3YXNVbnNldEluRm9ybVZhbHVlcyA9IGlzVW5kZWZpbmVkKGdldChfZm9ybVZhbHVlcywgbmFtZSkpO1xuICAgICAgICAgICAgY29uc3QgZGVmYXVsdFZhbHVlID0gZ2V0KF9mb3JtVmFsdWVzLCBuYW1lLCBpc1VuZGVmaW5lZCh2YWx1ZSkgPyBnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUpIDogdmFsdWUpO1xuICAgICAgICAgICAgY29uc3QgaXNFZGl0ZWRCZWZvcmVSZWFkeSA9ICEhcmVmICYmICFfZm9ybVN0YXRlLmlzUmVhZHkgJiYgaXNFZGl0ZWQocmVmKTtcbiAgICAgICAgICAgIGlmIChpc1VuZGVmaW5lZChkZWZhdWx0VmFsdWUpIHx8XG4gICAgICAgICAgICAgICAgKHJlZiAmJiByZWYuZGVmYXVsdENoZWNrZWQpIHx8XG4gICAgICAgICAgICAgICAgaXNFZGl0ZWRCZWZvcmVSZWFkeSB8fFxuICAgICAgICAgICAgICAgIHNob3VsZFNraXBTZXRWYWx1ZUFzKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgZmllbGRWYWx1ZSA9IHNob3VsZFNraXBTZXRWYWx1ZUFzXG4gICAgICAgICAgICAgICAgICAgID8gZGVmYXVsdFZhbHVlXG4gICAgICAgICAgICAgICAgICAgIDogZ2V0RmllbGRWYWx1ZShmaWVsZC5fZik7XG4gICAgICAgICAgICAgICAgaWYgKF9pc1RyYWNrZWQoJ2RpcnR5RmllbGRzJykgJiZcbiAgICAgICAgICAgICAgICAgICAgIWRlZXBFcXVhbChnZXQoX2Zvcm1WYWx1ZXMsIG5hbWUpLCBmaWVsZFZhbHVlKSkge1xuICAgICAgICAgICAgICAgICAgICBfZGlydHlGaWVsZHNTdGFsZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHNldChfZm9ybVZhbHVlcywgbmFtZSwgZmllbGRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKGlzRWRpdGVkQmVmb3JlUmVhZHkpIHtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlVG91Y2hBbmREaXJ0eShuYW1lLCBmaWVsZFZhbHVlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZXRGaWVsZFZhbHVlKG5hbWUsIGRlZmF1bHRWYWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoX3N0YXRlLm1vdW50ICYmICFfc3RhdGUuYWN0aW9uKSB7XG4gICAgICAgICAgICAgICAgaWYgKF9vcHRpb25zLnJlc29sdmVyICYmXG4gICAgICAgICAgICAgICAgICAgIF9pc1RyYWNrZWQoJ2lzVmFsaWRhdGluZycsICd2YWxpZGF0aW5nRmllbGRzJykpIHtcbiAgICAgICAgICAgICAgICAgICAgUHJvbWlzZS5yZXNvbHZlKCkudGhlbigoKSA9PiBfc2V0VmFsaWQoKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBfc2V0VmFsaWQoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHdhc1Vuc2V0SW5Gb3JtVmFsdWVzICYmXG4gICAgICAgICAgICAgICAgICAgIF9mb3JtU3RhdGUuaXNEaXJ0eSAmJlxuICAgICAgICAgICAgICAgICAgICBfaXNUcmFja2VkKCdpc0RpcnR5JykpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNEaXJ0eSA9IF9nZXREaXJ0eSgpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWlzRGlydHkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9mb3JtU3RhdGUuaXNEaXJ0eSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoeyAuLi5fZm9ybVN0YXRlIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChfb3B0aW9ucy5zaG91bGRVbnJlZ2lzdGVyICYmXG4gICAgICAgICAgICAgICAgICAgIHdhc1Vuc2V0SW5Gb3JtVmFsdWVzICYmXG4gICAgICAgICAgICAgICAgICAgICFpc1VuZGVmaW5lZChnZXQoX2Zvcm1WYWx1ZXMsIG5hbWUpKSAmJlxuICAgICAgICAgICAgICAgICAgICBpc1dhdGNoZWQobmFtZSwgX25hbWVzKSkge1xuICAgICAgICAgICAgICAgICAgICBfc3RhdGUud2F0Y2ggPSB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgdXBkYXRlVG91Y2hBbmREaXJ0eSA9IChuYW1lLCBmaWVsZFZhbHVlLCBpc0JsdXJFdmVudCwgc2hvdWxkRGlydHksIHNob3VsZFJlbmRlcikgPT4ge1xuICAgICAgICBsZXQgc2hvdWxkVXBkYXRlRmllbGQgPSBmYWxzZTtcbiAgICAgICAgbGV0IGlzUHJldmlvdXNEaXJ0eSA9IGZhbHNlO1xuICAgICAgICBjb25zdCBvdXRwdXQgPSB7XG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICB9O1xuICAgICAgICAvLyBhbiBleHBsaWNpdCBwcm9ncmFtbWF0aWMgdXBkYXRlIChlLmcuIHNldFZhbHVlIHdpdGggc2hvdWxkRGlydHk6IHRydWUpXG4gICAgICAgIC8vIG9wdHMgaW50byBkaXJ0eSB0cmFja2luZyBldmVuIHdoZW4gdGhlIGZvcm0gaXMgZGlzYWJsZWRcbiAgICAgICAgaWYgKCFfb3B0aW9ucy5kaXNhYmxlZCB8fCBzaG91bGREaXJ0eSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgaWYgKCFpc0JsdXJFdmVudCB8fCBzaG91bGREaXJ0eSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGlzQ3VycmVudEZpZWxkUHJpc3RpbmUgPSBkZWVwRXF1YWwoZ2V0KF9kZWZhdWx0VmFsdWVzLCBuYW1lKSwgZmllbGRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKF9pc1RyYWNrZWQoJ2lzRGlydHknKSkge1xuICAgICAgICAgICAgICAgICAgICBpc1ByZXZpb3VzRGlydHkgPSBfZm9ybVN0YXRlLmlzRGlydHk7XG4gICAgICAgICAgICAgICAgICAgIF9mb3JtU3RhdGUuaXNEaXJ0eSA9IG91dHB1dC5pc0RpcnR5ID1cbiAgICAgICAgICAgICAgICAgICAgICAgICFpc0N1cnJlbnRGaWVsZFByaXN0aW5lIHx8IF9nZXREaXJ0eSgpO1xuICAgICAgICAgICAgICAgICAgICBzaG91bGRVcGRhdGVGaWVsZCA9IGlzUHJldmlvdXNEaXJ0eSAhPT0gb3V0cHV0LmlzRGlydHk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlzUHJldmlvdXNEaXJ0eSA9ICEhZ2V0KF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGlmIChpc0N1cnJlbnRGaWVsZFByaXN0aW5lKSB7XG4gICAgICAgICAgICAgICAgICAgIHVuc2V0KF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZGVmYXVsdEZpZWxkVmFsdWUgPSBnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZGlydHlWYWx1ZSA9ICEoZmllbGQgJiYgZmllbGQuX2YpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAoaXNPYmplY3QoZGVmYXVsdEZpZWxkVmFsdWUpIHx8IEFycmF5LmlzQXJyYXkoZGVmYXVsdEZpZWxkVmFsdWUpKVxuICAgICAgICAgICAgICAgICAgICAgICAgPyBnZXREaXJ0eUZpZWxkcyhkZWZhdWx0RmllbGRWYWx1ZSwgZmllbGRWYWx1ZSwgdW5kZWZpbmVkLCBmaWVsZClcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdHJ1ZTtcbiAgICAgICAgICAgICAgICAgICAgc2V0KF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsIG5hbWUsIGRpcnR5VmFsdWUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBsZXQgZGlkUmVzeW5jRGlydHlGaWVsZHMgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICBpZiAoX2RpcnR5RmllbGRzU3RhbGUgfHxcbiAgICAgICAgICAgICAgICAgICAgKGlzQ3VycmVudEZpZWxkUHJpc3RpbmUgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIChfaXNUcmFja2VkKCdpc0RpcnR5JykgPyBfZm9ybVN0YXRlLmlzRGlydHkgOiBfZ2V0RGlydHkoKSkpKSB7XG4gICAgICAgICAgICAgICAgICAgIF9kaXJ0eUZpZWxkc1N0YWxlID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5leHREaXJ0eUZpZWxkcyA9IGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBfZm9ybVZhbHVlcywgdW5kZWZpbmVkLCBfZmllbGRzKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKCFkZWVwRXF1YWwoX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcywgbmV4dERpcnR5RmllbGRzKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZGlkUmVzeW5jRGlydHlGaWVsZHMgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmVwbGFjZURpcnR5RmllbGRzSW5QbGFjZShfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuZXh0RGlydHlGaWVsZHMpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIG91dHB1dC5kaXJ0eUZpZWxkcyA9IF9mb3JtU3RhdGUuZGlydHlGaWVsZHM7XG4gICAgICAgICAgICAgICAgc2hvdWxkVXBkYXRlRmllbGQgPVxuICAgICAgICAgICAgICAgICAgICBzaG91bGRVcGRhdGVGaWVsZCB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgKF9pc1RyYWNrZWQoJ2RpcnR5RmllbGRzJykgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoZGlkUmVzeW5jRGlydHlGaWVsZHMgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXNQcmV2aW91c0RpcnR5ICE9PSAhaXNDdXJyZW50RmllbGRQcmlzdGluZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGlzQmx1ckV2ZW50KSB7XG4gICAgICAgICAgICAgICAgY29uc3QgaXNQcmV2aW91c0ZpZWxkVG91Y2hlZCA9IGhhcyhfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUpXG4gICAgICAgICAgICAgICAgICAgID8gZ2V0KF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgbmFtZSlcbiAgICAgICAgICAgICAgICAgICAgOiB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgaWYgKCFpc1ByZXZpb3VzRmllbGRUb3VjaGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUsIGlzQmx1ckV2ZW50KTtcbiAgICAgICAgICAgICAgICAgICAgb3V0cHV0LnRvdWNoZWRGaWVsZHMgPSBfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHM7XG4gICAgICAgICAgICAgICAgICAgIHNob3VsZFVwZGF0ZUZpZWxkID1cbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3VsZFVwZGF0ZUZpZWxkIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKF9pc1RyYWNrZWQoJ3RvdWNoZWRGaWVsZHMnKSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpc1ByZXZpb3VzRmllbGRUb3VjaGVkICE9PSBpc0JsdXJFdmVudCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2hvdWxkVXBkYXRlRmllbGQgJiYgc2hvdWxkUmVuZGVyICYmIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KG91dHB1dCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHNob3VsZFVwZGF0ZUZpZWxkID8gb3V0cHV0IDoge307XG4gICAgfTtcbiAgICBjb25zdCBzaG91bGRSZW5kZXJCeUVycm9yID0gKG5hbWUsIGlzVmFsaWQsIGVycm9yLCBmaWVsZFN0YXRlKSA9PiB7XG4gICAgICAgIGNvbnN0IHByZXZpb3VzRmllbGRFcnJvciA9IGdldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgIGNvbnN0IHNob3VsZFVwZGF0ZVZhbGlkID0gX2lzVHJhY2tlZCgnaXNWYWxpZCcpICYmXG4gICAgICAgICAgICBpc0Jvb2xlYW4oaXNWYWxpZCkgJiZcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuaXNWYWxpZCAhPT0gaXNWYWxpZDtcbiAgICAgICAgaWYgKF9vcHRpb25zLmRlbGF5RXJyb3IgJiYgZXJyb3IpIHtcbiAgICAgICAgICAgIGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV0gPSBkZWJvdW5jZShuYW1lLCAoKSA9PiB1cGRhdGVFcnJvcnMobmFtZSwgZXJyb3IpKTtcbiAgICAgICAgICAgIGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV0oX29wdGlvbnMuZGVsYXlFcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjYW5jZWxEZWxheWVkRXJyb3IobmFtZSk7XG4gICAgICAgICAgICBlcnJvclxuICAgICAgICAgICAgICAgID8gc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lLCBlcnJvcilcbiAgICAgICAgICAgICAgICA6IHVuc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0geyAuLi5fZm9ybVN0YXRlLmVycm9ycyB9O1xuICAgICAgICB9XG4gICAgICAgIGlmICgoZXJyb3JcbiAgICAgICAgICAgID8gIWRlZXBFcXVhbChwcmV2aW91c0ZpZWxkRXJyb3IsIGVycm9yLCB0cnVlKVxuICAgICAgICAgICAgOiBwcmV2aW91c0ZpZWxkRXJyb3IpIHx8XG4gICAgICAgICAgICAhaXNFbXB0eU9iamVjdChmaWVsZFN0YXRlKSB8fFxuICAgICAgICAgICAgc2hvdWxkVXBkYXRlVmFsaWQpIHtcbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZWRGb3JtU3RhdGUgPSB7XG4gICAgICAgICAgICAgICAgLi4uZmllbGRTdGF0ZSxcbiAgICAgICAgICAgICAgICAuLi4oc2hvdWxkVXBkYXRlVmFsaWQgJiYgaXNCb29sZWFuKGlzVmFsaWQpID8geyBpc1ZhbGlkIH0gOiB7fSksXG4gICAgICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHVwZGF0ZWRGb3JtU3RhdGUpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBfcnVuU2NoZW1hID0gYXN5bmMgKG5hbWUpID0+IHtcbiAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZyhuYW1lLCB0cnVlKTtcbiAgICAgICAgcmV0dXJuIGF3YWl0IF9vcHRpb25zLnJlc29sdmVyKF9mb3JtVmFsdWVzLCBfb3B0aW9ucy5jb250ZXh0LCBnZXRSZXNvbHZlck9wdGlvbnMobmFtZSB8fCBfbmFtZXMubW91bnQsIF9maWVsZHMsIF9vcHRpb25zLmNyaXRlcmlhTW9kZSwgX29wdGlvbnMuc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbikpO1xuICAgIH07XG4gICAgY29uc3QgZXhlY3V0ZVNjaGVtYUFuZFVwZGF0ZVN0YXRlID0gYXN5bmMgKG5hbWVzKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlc2V0Q2FsbElkID0gX3Jlc2V0Q2FsbElkO1xuICAgICAgICBjb25zdCB7IGVycm9ycyB9ID0gYXdhaXQgX3J1blNjaGVtYShuYW1lcyk7XG4gICAgICAgIGlmIChyZXNldENhbGxJZCAhPT0gX3Jlc2V0Q2FsbElkKSB7XG4gICAgICAgICAgICByZXR1cm4gZXJyb3JzO1xuICAgICAgICB9XG4gICAgICAgIF91cGRhdGVJc1ZhbGlkYXRpbmcobmFtZXMpO1xuICAgICAgICBpZiAobmFtZXMpIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgbmFtZSBvZiBuYW1lcykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGVycm9yID0gZ2V0KGVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICAgICAgY2FuY2VsRGVsYXllZEVycm9yVHJlZShuYW1lKTtcbiAgICAgICAgICAgICAgICBjb25zdCBpc0ZpZWxkQXJyYXlSb290RXJyb3IgPSBfbmFtZXMuYXJyYXkuaGFzKG5hbWUpICYmXG4gICAgICAgICAgICAgICAgICAgIGlzT2JqZWN0KGVycm9yKSAmJlxuICAgICAgICAgICAgICAgICAgICAhT2JqZWN0LmtleXMoZXJyb3IpLnNvbWUoKGtleSkgPT4gIU51bWJlci5pc05hTihOdW1iZXIoa2V5KSkpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgICAgIGNvbnN0IGhhc05lc3RlZEZpZWxkcyA9IGlzT2JqZWN0KGZpZWxkKSAmJiBPYmplY3Qua2V5cyhmaWVsZCkuc29tZSgoa2V5KSA9PiBrZXkgIT09ICdfZicpO1xuICAgICAgICAgICAgICAgIGlzRmllbGRBcnJheVJvb3RFcnJvclxuICAgICAgICAgICAgICAgICAgICA/IHVwZGF0ZUZpZWxkQXJyYXlSb290RXJyb3IoX2Zvcm1TdGF0ZS5lcnJvcnMsIHsgW25hbWVdOiBlcnJvciB9LCBuYW1lKVxuICAgICAgICAgICAgICAgICAgICA6IChlcnJvciAmJiAoZXJyb3IudHlwZSB8fCBlcnJvci5tZXNzYWdlKSkgfHxcbiAgICAgICAgICAgICAgICAgICAgICAgIEFycmF5LmlzQXJyYXkoZXJyb3IpIHx8XG4gICAgICAgICAgICAgICAgICAgICAgICAoaXNPYmplY3QoZXJyb3IpICYmIGhhc05lc3RlZEZpZWxkcylcbiAgICAgICAgICAgICAgICAgICAgICAgID8gc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lLCBlcnJvcilcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdW5zZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLl9mb3JtU3RhdGUuZXJyb3JzIH07XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBPYmplY3Qua2V5cyhkZWxheUVycm9yQ2FsbGJhY2tzKS5mb3JFYWNoKGNhbmNlbERlbGF5ZWRFcnJvcik7XG4gICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IGVycm9ycztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZXJyb3JzO1xuICAgIH07XG4gICAgY29uc3QgdmFsaWRhdGVGb3JtID0gYXN5bmMgKHsgbmFtZSwgZXZlbnRUeXBlLCB9KSA9PiB7XG4gICAgICAgIGlmIChfb3B0aW9ucy52YWxpZGF0ZSkge1xuICAgICAgICAgICAgY29uc3QgcmVzZXRDYWxsSWQgPSBfcmVzZXRDYWxsSWQ7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBfb3B0aW9ucy52YWxpZGF0ZSh7XG4gICAgICAgICAgICAgICAgZm9ybVZhbHVlczogX2Zvcm1WYWx1ZXMsXG4gICAgICAgICAgICAgICAgZm9ybVN0YXRlOiBfZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgZXZlbnRUeXBlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAocmVzZXRDYWxsSWQgIT09IF9yZXNldENhbGxJZCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGlzT2JqZWN0KHJlc3VsdCkpIHtcbiAgICAgICAgICAgICAgICBsZXQgaXNWYWxpZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgY2xlYXJFcnJvcnMoRk9STV9FUlJPUl9UWVBFKTtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGtleSBpbiByZXN1bHQpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXJyb3IgPSByZXN1bHRba2V5XTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBpc1ZhbGlkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRFcnJvcihgJHtGT1JNX0VSUk9SX1RZUEV9LiR7a2V5fWAsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBpc1N0cmluZyhlcnJvci5tZXNzYWdlKSA/IGVycm9yLm1lc3NhZ2UgOiAnJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiBlcnJvci50eXBlIHx8IElOUFVUX1ZBTElEQVRJT05fUlVMRVMudmFsaWRhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gaXNWYWxpZDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGlzU3RyaW5nKHJlc3VsdCkgfHwgIXJlc3VsdCkge1xuICAgICAgICAgICAgICAgIHNldEVycm9yKEZPUk1fRVJST1JfVFlQRSwge1xuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiByZXN1bHQgfHwgJycsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IElOUFVUX1ZBTElEQVRJT05fUlVMRVMudmFsaWRhdGUsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY2xlYXJFcnJvcnMoRk9STV9FUlJPUl9UWVBFKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9O1xuICAgIGNvbnN0IGV4ZWN1dGVCdWlsdEluVmFsaWRhdGlvbiA9IGFzeW5jICh7IGZpZWxkcywgb25seUNoZWNrVmFsaWQsIG5hbWUsIGV2ZW50VHlwZSwgY29udGV4dCA9IHtcbiAgICAgICAgdmFsaWQ6IHRydWUsXG4gICAgICAgIHJ1blJvb3RWYWxpZGF0aW9uOiBmYWxzZSxcbiAgICB9LCB9KSA9PiB7XG4gICAgICAgIGNvbnN0IHJlc2V0Q2FsbElkID0gX3Jlc2V0Q2FsbElkO1xuICAgICAgICBpZiAoX29wdGlvbnMudmFsaWRhdGUgJiYgIWNvbnRleHQucnVuUm9vdFZhbGlkYXRpb24pIHtcbiAgICAgICAgICAgIGNvbnRleHQucnVuUm9vdFZhbGlkYXRpb24gPSB0cnVlO1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdmFsaWRhdGVGb3JtKHtcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIGV2ZW50VHlwZSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKCFyZXN1bHQpIHtcbiAgICAgICAgICAgICAgICBjb250ZXh0LnZhbGlkID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgaWYgKG9ubHlDaGVja1ZhbGlkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjb250ZXh0LnZhbGlkO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBmb3IgKGNvbnN0IG5hbWUgaW4gZmllbGRzKSB7XG4gICAgICAgICAgICBjb25zdCBmaWVsZCA9IGZpZWxkc1tuYW1lXTtcbiAgICAgICAgICAgIGlmIChmaWVsZCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHsgX2YsIC4uLmZpZWxkVmFsdWUgfSA9IGZpZWxkO1xuICAgICAgICAgICAgICAgIGlmIChfZikge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBpc0ZpZWxkQXJyYXlSb290ID0gX25hbWVzLmFycmF5LmhhcyhfZi5uYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgaXNQcm9taXNlRnVuY3Rpb24gPSBmaWVsZC5fZiAmJiBoYXNQcm9taXNlVmFsaWRhdGlvbihmaWVsZC5fZik7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHNob3VsZFRyYWNrSXNWYWxpZGF0aW5nU3RhdGUgPSBfaXNUcmFja2VkKCdpc1ZhbGlkYXRpbmcnLCAndmFsaWRhdGluZ0ZpZWxkcycpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXNQcm9taXNlRnVuY3Rpb24gJiYgc2hvdWxkVHJhY2tJc1ZhbGlkYXRpbmdTdGF0ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZyhbX2YubmFtZV0sIHRydWUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkRXJyb3IgPSBhd2FpdCB2YWxpZGF0ZUZpZWxkKGZpZWxkLCBfbmFtZXMuZGlzYWJsZWQsIF9mb3JtVmFsdWVzLCBzaG91bGREaXNwbGF5QWxsQXNzb2NpYXRlZEVycm9ycywgX29wdGlvbnMuc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbiAmJiAhb25seUNoZWNrVmFsaWQsIGlzRmllbGRBcnJheVJvb3QpO1xuICAgICAgICAgICAgICAgICAgICBpZiAocmVzZXRDYWxsSWQgIT09IF9yZXNldENhbGxJZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbnRleHQudmFsaWQ7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKGlzUHJvbWlzZUZ1bmN0aW9uICYmIHNob3VsZFRyYWNrSXNWYWxpZGF0aW5nU3RhdGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF91cGRhdGVJc1ZhbGlkYXRpbmcoW19mLm5hbWVdKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBpZiAoZmllbGRFcnJvcltfZi5uYW1lXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29udGV4dC52YWxpZCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKG9ubHlDaGVja1ZhbGlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKCFvbmx5Q2hlY2tWYWxpZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FuY2VsRGVsYXllZEVycm9yKF9mLm5hbWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgZ2V0KGZpZWxkRXJyb3IsIF9mLm5hbWUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBpc0ZpZWxkQXJyYXlSb290XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gdXBkYXRlRmllbGRBcnJheVJvb3RFcnJvcihfZm9ybVN0YXRlLmVycm9ycywgZmllbGRFcnJvciwgX2YubmFtZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBzZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIF9mLm5hbWUsIGZpZWxkRXJyb3JbX2YubmFtZV0pXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgOiB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgX2YubmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgaWYgKF9vcHRpb25zLnNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24gJiYgZmllbGRFcnJvcltfZi5uYW1lXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgIWlzRW1wdHlPYmplY3QoZmllbGRWYWx1ZSkgJiZcbiAgICAgICAgICAgICAgICAgICAgKGF3YWl0IGV4ZWN1dGVCdWlsdEluVmFsaWRhdGlvbih7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb250ZXh0LFxuICAgICAgICAgICAgICAgICAgICAgICAgb25seUNoZWNrVmFsaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBmaWVsZHM6IGZpZWxkVmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnRUeXBlLFxuICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNvbnRleHQudmFsaWQ7XG4gICAgfTtcbiAgICBjb25zdCBfcmVtb3ZlVW5tb3VudGVkID0gKCkgPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IG5hbWUgb2YgX25hbWVzLnVuTW91bnQpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICAgICAgZmllbGQgJiZcbiAgICAgICAgICAgICAgICAoZmllbGQuX2YucmVmc1xuICAgICAgICAgICAgICAgICAgICA/IGZpZWxkLl9mLnJlZnMuZXZlcnkoKHJlZikgPT4gIWxpdmUocmVmKSlcbiAgICAgICAgICAgICAgICAgICAgOiAhbGl2ZShmaWVsZC5fZi5yZWYpKSAmJlxuICAgICAgICAgICAgICAgIHVucmVnaXN0ZXIobmFtZSk7XG4gICAgICAgIH1cbiAgICAgICAgX25hbWVzLnVuTW91bnQgPSBuZXcgU2V0KCk7XG4gICAgfTtcbiAgICBjb25zdCBfZ2V0RGlydHkgPSAobmFtZSwgZGF0YSkgPT4gKG5hbWUgJiYgZGF0YSAmJiBzZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIGRhdGEpLFxuICAgICAgICAhZGVlcEVxdWFsKF9zdGF0ZS5tb3VudCA/IF9mb3JtVmFsdWVzIDogX2RlZmF1bHRWYWx1ZXMsIF9kZWZhdWx0VmFsdWVzKSk7XG4gICAgY29uc3QgX2dldFdhdGNoID0gKG5hbWVzLCBkZWZhdWx0VmFsdWUsIGlzR2xvYmFsKSA9PiB7XG4gICAgICAgIGNvbnN0IHZhbHVlcyA9IF9zdGF0ZS5tb3VudFxuICAgICAgICAgICAgPyBfZm9ybVZhbHVlc1xuICAgICAgICAgICAgOiBpc1VuZGVmaW5lZChkZWZhdWx0VmFsdWUpIHx8ICFpc1VuZGVmaW5lZChuYW1lcylcbiAgICAgICAgICAgICAgICA/IF9kZWZhdWx0VmFsdWVzXG4gICAgICAgICAgICAgICAgOiBkZWZhdWx0VmFsdWU7XG4gICAgICAgIHJldHVybiBnZW5lcmF0ZVdhdGNoT3V0cHV0KG5hbWVzLCBfbmFtZXMsIGlzVW5kZWZpbmVkKG5hbWVzKSA/IHsgLi4udmFsdWVzIH0gOiB2YWx1ZXMsIGlzR2xvYmFsLCBkZWZhdWx0VmFsdWUpO1xuICAgIH07XG4gICAgY29uc3QgX2dldEZpZWxkQXJyYXkgPSAobmFtZSkgPT4gY29tcGFjdChnZXQoX3N0YXRlLm1vdW50ID8gX2Zvcm1WYWx1ZXMgOiBfZGVmYXVsdFZhbHVlcywgbmFtZSwgX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlciA/IGdldChfZGVmYXVsdFZhbHVlcywgbmFtZSwgW10pIDogW10pKTtcbiAgICBjb25zdCBzZXRGaWVsZFZhbHVlID0gKG5hbWUsIHZhbHVlLCBvcHRpb25zID0ge30sIHNraXBDbG9uZSA9IGZhbHNlLCBza2lwUmVuZGVyID0gZmFsc2UsIHNraXBWYWx1ZVJlbmRlciA9IGZhbHNlKSA9PiB7XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICBsZXQgZmllbGRWYWx1ZSA9IHZhbHVlO1xuICAgICAgICBpZiAoZmllbGQpIHtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkUmVmZXJlbmNlID0gZmllbGQuX2Y7XG4gICAgICAgICAgICBpZiAoZmllbGRSZWZlcmVuY2UpIHtcbiAgICAgICAgICAgICAgICAhZmllbGRSZWZlcmVuY2UuZGlzYWJsZWQgJiZcbiAgICAgICAgICAgICAgICAgICAgc2V0KF9mb3JtVmFsdWVzLCBuYW1lLCBnZXRGaWVsZFZhbHVlQXModmFsdWUsIGZpZWxkUmVmZXJlbmNlKSk7XG4gICAgICAgICAgICAgICAgZmllbGRWYWx1ZSA9XG4gICAgICAgICAgICAgICAgICAgIGlzSFRNTEVsZW1lbnQoZmllbGRSZWZlcmVuY2UucmVmKSAmJiBpc051bGxPclVuZGVmaW5lZCh2YWx1ZSlcbiAgICAgICAgICAgICAgICAgICAgICAgID8gJydcbiAgICAgICAgICAgICAgICAgICAgICAgIDogdmFsdWU7XG4gICAgICAgICAgICAgICAgaWYgKGlzTXVsdGlwbGVTZWxlY3QoZmllbGRSZWZlcmVuY2UucmVmKSkge1xuICAgICAgICAgICAgICAgICAgICBbLi4uZmllbGRSZWZlcmVuY2UucmVmLm9wdGlvbnNdLmZvckVhY2goKG9wdGlvblJlZikgPT4gKG9wdGlvblJlZi5zZWxlY3RlZCA9IGZpZWxkVmFsdWUuaW5jbHVkZXMob3B0aW9uUmVmLnZhbHVlKSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChmaWVsZFJlZmVyZW5jZS5yZWZzKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc0NoZWNrQm94SW5wdXQoZmllbGRSZWZlcmVuY2UucmVmKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRSZWZlcmVuY2UucmVmcy5mb3JFYWNoKChjaGVja2JveFJlZikgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghY2hlY2tib3hSZWYuZGVmYXVsdENoZWNrZWQgfHwgIWNoZWNrYm94UmVmLmRpc2FibGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGZpZWxkVmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2JveFJlZi5jaGVja2VkID0gISFmaWVsZFZhbHVlLmZpbmQoKGRhdGEpID0+IGRhdGEgPT09IGNoZWNrYm94UmVmLnZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNoZWNrYm94UmVmLmNoZWNrZWQgPVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkVmFsdWUgPT09IGNoZWNrYm94UmVmLnZhbHVlIHx8ICEhZmllbGRWYWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRSZWZlcmVuY2UucmVmcy5mb3JFYWNoKChyYWRpb1JlZikgPT4gKHJhZGlvUmVmLmNoZWNrZWQgPSByYWRpb1JlZi52YWx1ZSA9PT0gZmllbGRWYWx1ZSkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGlzRmlsZUlucHV0KGZpZWxkUmVmZXJlbmNlLnJlZikpIHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGRSZWZlcmVuY2UucmVmLnZhbHVlID0gJyc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBmaWVsZFJlZmVyZW5jZS5yZWYudmFsdWUgPSBmaWVsZFZhbHVlO1xuICAgICAgICAgICAgICAgICAgICBpZiAoIWZpZWxkUmVmZXJlbmNlLnJlZi50eXBlICYmICFza2lwUmVuZGVyICYmICFza2lwVmFsdWVSZW5kZXIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlczogc2tpcENsb25lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gX2Zvcm1WYWx1ZXNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBfaGFzVmFsdWVzU3Vic2NyaWJlcihuYW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBjbG9uZU9iamVjdChfZm9ybVZhbHVlcylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgKG9wdGlvbnMuc2hvdWxkRGlydHkgfHwgb3B0aW9ucy5zaG91bGRUb3VjaCkgJiZcbiAgICAgICAgICAgIHVwZGF0ZVRvdWNoQW5kRGlydHkobmFtZSwgZmllbGQgJiZcbiAgICAgICAgICAgICAgICBmaWVsZC5fZiAmJlxuICAgICAgICAgICAgICAgICFmaWVsZC5fZi5kaXNhYmxlZCAmJlxuICAgICAgICAgICAgICAgIChmaWVsZC5fZi52YWx1ZUFzTnVtYmVyIHx8XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkLl9mLnZhbHVlQXNEYXRlIHx8XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkLl9mLnNldFZhbHVlQXMpXG4gICAgICAgICAgICAgICAgPyBnZXRGaWVsZFZhbHVlQXModmFsdWUsIGZpZWxkLl9mKVxuICAgICAgICAgICAgICAgIDogZmllbGRWYWx1ZSwgb3B0aW9ucy5zaG91bGRUb3VjaCwgb3B0aW9ucy5zaG91bGREaXJ0eSwgIXNraXBSZW5kZXIpO1xuICAgICAgICBvcHRpb25zLnNob3VsZFZhbGlkYXRlICYmXG4gICAgICAgICAgICB0cmlnZ2VyKG5hbWUsIHtcbiAgICAgICAgICAgICAgICBkZWxheUVycm9yOiBvcHRpb25zLmRlbGF5RXJyb3IsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgaWYgKG9wdGlvbnMuc2hvdWxkVmFsaWRhdGUgJiZcbiAgICAgICAgICAgIGZpZWxkICYmXG4gICAgICAgICAgICBmaWVsZC5fZiAmJlxuICAgICAgICAgICAgZmllbGQuX2YuZGVwcyAmJlxuICAgICAgICAgICAgKCFBcnJheS5pc0FycmF5KGZpZWxkLl9mLmRlcHMpIHx8IGZpZWxkLl9mLmRlcHMubGVuZ3RoID4gMCkpIHtcbiAgICAgICAgICAgIHRyaWdnZXIoZmllbGQuX2YuZGVwcyk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHNldEZpZWxkVmFsdWVzID0gKG5hbWUsIHZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUgPSBmYWxzZSwgc2tpcFJlbmRlciA9IGZhbHNlLCBza2lwVmFsdWVSZW5kZXIgPSBmYWxzZSkgPT4ge1xuICAgICAgICBpZiAoX25hbWVzLmFycmF5LmhhcyhuYW1lKSkge1xuICAgICAgICAgICAgX3N1YmplY3RzLmFycmF5Lm5leHQoe1xuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgdmFsdWVzOiBza2lwQ2xvbmUgPyBfZm9ybVZhbHVlcyA6IGNsb25lT2JqZWN0KF9mb3JtVmFsdWVzKSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGZvciAoY29uc3QgZmllbGRLZXkgaW4gdmFsdWUpIHtcbiAgICAgICAgICAgIGlmICghdmFsdWUuaGFzT3duUHJvcGVydHkoZmllbGRLZXkpKSB7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBmaWVsZFZhbHVlID0gdmFsdWVbZmllbGRLZXldO1xuICAgICAgICAgICAgY29uc3QgZmllbGROYW1lID0gbmFtZSArICcuJyArIGZpZWxkS2V5O1xuICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgIChfbmFtZXMuYXJyYXkuaGFzKG5hbWUpIHx8XG4gICAgICAgICAgICAgICAgaXNPYmplY3QoZmllbGRWYWx1ZSkgfHxcbiAgICAgICAgICAgICAgICAoZmllbGQgJiYgIWZpZWxkLl9mKSkgJiZcbiAgICAgICAgICAgICAgICAhaXNEYXRlT2JqZWN0KGZpZWxkVmFsdWUpXG4gICAgICAgICAgICAgICAgPyBzZXRGaWVsZFZhbHVlcyhmaWVsZE5hbWUsIGZpZWxkVmFsdWUsIG9wdGlvbnMsIHNraXBDbG9uZSwgc2tpcFJlbmRlciwgc2tpcFZhbHVlUmVuZGVyKVxuICAgICAgICAgICAgICAgIDogc2V0RmllbGRWYWx1ZShmaWVsZE5hbWUsIGZpZWxkVmFsdWUsIG9wdGlvbnMsIHNraXBDbG9uZSwgc2tpcFJlbmRlciwgc2tpcFZhbHVlUmVuZGVyKTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgX3NldFZhbHVlID0gKG5hbWUsIHZhbHVlLCBvcHRpb25zLCBza2lwQ2xvbmUsIHNraXBTdGF0ZUVtaXQgPSBmYWxzZSkgPT4ge1xuICAgICAgICBjb25zdCBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgY29uc3QgaXNGaWVsZEFycmF5ID0gX25hbWVzLmFycmF5LmhhcyhuYW1lKTtcbiAgICAgICAgY29uc3QgY2xvbmVWYWx1ZSA9IHNraXBDbG9uZSA/IHZhbHVlIDogY2xvbmVPYmplY3QodmFsdWUpO1xuICAgICAgICBjb25zdCBwcmV2aW91c1ZhbHVlID0gZ2V0KF9mb3JtVmFsdWVzLCBuYW1lKTtcbiAgICAgICAgY29uc3QgaXNWYWx1ZVVuY2hhbmdlZCA9IGRlZXBFcXVhbChwcmV2aW91c1ZhbHVlLCBjbG9uZVZhbHVlKTtcbiAgICAgICAgaWYgKCFpc1ZhbHVlVW5jaGFuZ2VkKSB7XG4gICAgICAgICAgICBzZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIGNsb25lVmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0ZpZWxkQXJyYXkpIHtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5hcnJheS5uZXh0KHtcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgIHZhbHVlczogc2tpcENsb25lID8gX2Zvcm1WYWx1ZXMgOiBjbG9uZU9iamVjdChfZm9ybVZhbHVlcyksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmIChfaXNUcmFja2VkKCdpc0RpcnR5JywgJ2RpcnR5RmllbGRzJykgJiYgb3B0aW9ucy5zaG91bGREaXJ0eSkge1xuICAgICAgICAgICAgICAgIF91cGRhdGVEaXJ0eUZpZWxkcygpO1xuICAgICAgICAgICAgICAgIGlmICghc2tpcFN0YXRlRW1pdCkge1xuICAgICAgICAgICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgZGlydHlGaWVsZHM6IF9mb3JtU3RhdGUuZGlydHlGaWVsZHMsXG4gICAgICAgICAgICAgICAgICAgICAgICBpc0RpcnR5OiBfZ2V0RGlydHkobmFtZSwgY2xvbmVWYWx1ZSksXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG9wdGlvbnMuc2hvdWxkVmFsaWRhdGUgJiZcbiAgICAgICAgICAgICAgICB0cmlnZ2VyKG5hbWUsIHtcbiAgICAgICAgICAgICAgICAgICAgZGVsYXlFcnJvcjogb3B0aW9ucy5kZWxheUVycm9yLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgY29uc3QgaXNFbXB0eSA9IChBcnJheS5pc0FycmF5KGNsb25lVmFsdWUpICYmICFjbG9uZVZhbHVlLmxlbmd0aCkgfHxcbiAgICAgICAgICAgICAgICBpc0VtcHR5T2JqZWN0KGNsb25lVmFsdWUpO1xuICAgICAgICAgICAgY29uc3Qgc2tpcFZhbHVlUmVuZGVyID0gIWlzVmFsdWVVbmNoYW5nZWQgJiYgIXNraXBTdGF0ZUVtaXQ7XG4gICAgICAgICAgICBpZiAoIWZpZWxkIHx8IGZpZWxkLl9mIHx8IGlzTnVsbE9yVW5kZWZpbmVkKGNsb25lVmFsdWUpIHx8IGlzRW1wdHkpIHtcbiAgICAgICAgICAgICAgICBzZXRGaWVsZFZhbHVlKG5hbWUsIGNsb25lVmFsdWUsIG9wdGlvbnMsIHNraXBDbG9uZSwgc2tpcFN0YXRlRW1pdCwgc2tpcFZhbHVlUmVuZGVyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHNldEZpZWxkVmFsdWVzKG5hbWUsIGNsb25lVmFsdWUsIG9wdGlvbnMsIHNraXBDbG9uZSwgc2tpcFN0YXRlRW1pdCwgc2tpcFZhbHVlUmVuZGVyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoIWlzVmFsdWVVbmNoYW5nZWQgJiYgIXNraXBTdGF0ZUVtaXQpIHtcbiAgICAgICAgICAgIGNvbnN0IHdhdGNoZWQgPSBpc1dhdGNoZWQobmFtZSwgX25hbWVzKTtcbiAgICAgICAgICAgIGNvbnN0IGVtaXR0ZWROYW1lID0gX3N0YXRlLm1vdW50IHx8IHdhdGNoZWQgPyBuYW1lIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgY29uc3QgZmllbGRBcnJheUl0ZW1OYW1lcyA9IGlzRmllbGRBcnJheVxuICAgICAgICAgICAgICAgID8gW11cbiAgICAgICAgICAgICAgICA6IGdldEZpZWxkQXJyYXlJdGVtTmFtZXMoX25hbWVzLmFycmF5LCBuYW1lKTtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlcyA9IHNraXBDbG9uZVxuICAgICAgICAgICAgICAgID8gX2Zvcm1WYWx1ZXNcbiAgICAgICAgICAgICAgICA6IF9oYXNWYWx1ZXNTdWJzY3JpYmVyKGVtaXR0ZWROYW1lKSB8fFxuICAgICAgICAgICAgICAgICAgICBmaWVsZEFycmF5SXRlbU5hbWVzLnNvbWUoX2hhc1ZhbHVlc1N1YnNjcmliZXIpXG4gICAgICAgICAgICAgICAgICAgID8gY2xvbmVPYmplY3QoX2Zvcm1WYWx1ZXMpXG4gICAgICAgICAgICAgICAgICAgIDogdW5kZWZpbmVkO1xuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIC4uLih3YXRjaGVkICYmIF9mb3JtU3RhdGUpLFxuICAgICAgICAgICAgICAgIG5hbWU6IGVtaXR0ZWROYW1lLFxuICAgICAgICAgICAgICAgIHZhbHVlcyxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgZm9yIChjb25zdCBpdGVtTmFtZSBvZiBmaWVsZEFycmF5SXRlbU5hbWVzKSB7XG4gICAgICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoeyBuYW1lOiBpdGVtTmFtZSwgdmFsdWVzIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBzZXRWYWx1ZSA9IChuYW1lLCB2YWx1ZSwgb3B0aW9ucyA9IHt9KSA9PiBfc2V0VmFsdWUobmFtZSwgdmFsdWUsIG9wdGlvbnMsIGZhbHNlKTtcbiAgICBjb25zdCBzZXRWYWx1ZXMgPSAoZm9ybVZhbHVlcywgb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgICAgIGNvbnN0IHVwZGF0ZWRGb3JtVmFsdWVzID0gaXNGdW5jdGlvbihmb3JtVmFsdWVzKVxuICAgICAgICAgICAgPyBmb3JtVmFsdWVzKF9mb3JtVmFsdWVzKVxuICAgICAgICAgICAgOiBmb3JtVmFsdWVzO1xuICAgICAgICBpZiAoIWRlZXBFcXVhbChfZm9ybVZhbHVlcywgdXBkYXRlZEZvcm1WYWx1ZXMpKSB7XG4gICAgICAgICAgICBfZm9ybVZhbHVlcyA9IHtcbiAgICAgICAgICAgICAgICAuLi5fZm9ybVZhbHVlcyxcbiAgICAgICAgICAgICAgICAuLi51cGRhdGVkRm9ybVZhbHVlcyxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTmFtZSBvZiBfbmFtZXMubW91bnQpIHtcbiAgICAgICAgICAgICAgICBpZiAoaGFzKHVwZGF0ZWRGb3JtVmFsdWVzLCBmaWVsZE5hbWUpKSB7XG4gICAgICAgICAgICAgICAgICAgIF9zZXRWYWx1ZShmaWVsZE5hbWUsIGdldCh1cGRhdGVkRm9ybVZhbHVlcywgZmllbGROYW1lKSwgb3B0aW9ucywgdHJ1ZSwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIC4uLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgbmFtZTogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAuLi4oX3ZhbHVlc1N1YnNjcmliZXJzLnNpemUgPyB7IHZhbHVlczogX2Zvcm1WYWx1ZXMgfSA6IHt9KSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKG9wdGlvbnMuc2hvdWxkVmFsaWRhdGUpIHtcbiAgICAgICAgICAgICAgICBfc2V0VmFsaWQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3Qgb25DaGFuZ2UgPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICAgICAgX3N0YXRlLm1vdW50ID0gdHJ1ZTtcbiAgICAgICAgY29uc3QgdGFyZ2V0ID0gZXZlbnQudGFyZ2V0O1xuICAgICAgICBsZXQgbmFtZSA9IHRhcmdldC5uYW1lO1xuICAgICAgICBsZXQgaXNGaWVsZFZhbHVlVXBkYXRlZCA9IHRydWU7XG4gICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIG5hbWUpO1xuICAgICAgICBjb25zdCBfdXBkYXRlSXNGaWVsZFZhbHVlVXBkYXRlZCA9IChmaWVsZFZhbHVlKSA9PiB7XG4gICAgICAgICAgICBpc0ZpZWxkVmFsdWVVcGRhdGVkID1cbiAgICAgICAgICAgICAgICBOdW1iZXIuaXNOYU4oZmllbGRWYWx1ZSkgfHxcbiAgICAgICAgICAgICAgICAgICAgKGlzRGF0ZU9iamVjdChmaWVsZFZhbHVlKSAmJiBpc05hTihmaWVsZFZhbHVlLmdldFRpbWUoKSkpIHx8XG4gICAgICAgICAgICAgICAgICAgIGRlZXBFcXVhbChmaWVsZFZhbHVlLCBnZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIGZpZWxkVmFsdWUpKTtcbiAgICAgICAgfTtcbiAgICAgICAgaWYgKGZpZWxkKSB7XG4gICAgICAgICAgICBsZXQgZXJyb3I7XG4gICAgICAgICAgICBsZXQgaXNWYWxpZDtcbiAgICAgICAgICAgIGNvbnN0IGZpZWxkVmFsdWUgPSB0YXJnZXQudHlwZVxuICAgICAgICAgICAgICAgID8gZ2V0RmllbGRWYWx1ZShmaWVsZC5fZilcbiAgICAgICAgICAgICAgICA6IGdldEV2ZW50VmFsdWUoZXZlbnQpO1xuICAgICAgICAgICAgY29uc3QgaXNCbHVyRXZlbnQgPSBldmVudC50eXBlID09PSBFVkVOVFMuQkxVUiB8fCBldmVudC50eXBlID09PSBFVkVOVFMuRk9DVVNfT1VUO1xuICAgICAgICAgICAgY29uc3QgaGFzTm9WYWxpZGF0aW9uRWZmZWN0ID0gIWhhc1ZhbGlkYXRpb24oZmllbGQuX2YpICYmXG4gICAgICAgICAgICAgICAgIV9vcHRpb25zLnZhbGlkYXRlICYmXG4gICAgICAgICAgICAgICAgIV9vcHRpb25zLnJlc29sdmVyICYmXG4gICAgICAgICAgICAgICAgIWdldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSkgJiZcbiAgICAgICAgICAgICAgICAhZmllbGQuX2YuZGVwcztcbiAgICAgICAgICAgIGNvbnN0IHNob3VsZFNraXBWYWxpZGF0aW9uID0gaGFzTm9WYWxpZGF0aW9uRWZmZWN0IHx8XG4gICAgICAgICAgICAgICAgc2tpcFZhbGlkYXRpb24oaXNCbHVyRXZlbnQsIGdldChfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHMsIG5hbWUpLCBfZm9ybVN0YXRlLmlzU3VibWl0dGVkLCBfdmFsaWRhdGlvbk1vZGVBZnRlclN1Ym1pdCwgX3ZhbGlkYXRpb25Nb2RlQmVmb3JlU3VibWl0KTtcbiAgICAgICAgICAgIGNvbnN0IHdhdGNoZWQgPSBpc1dhdGNoZWQobmFtZSwgX25hbWVzLCBpc0JsdXJFdmVudCk7XG4gICAgICAgICAgICBzZXQoX2Zvcm1WYWx1ZXMsIG5hbWUsIGNsb25lT2JqZWN0KGZpZWxkVmFsdWUpKTtcbiAgICAgICAgICAgIGlmIChpc0JsdXJFdmVudCkge1xuICAgICAgICAgICAgICAgIGlmICghdGFyZ2V0IHx8ICF0YXJnZXQucmVhZE9ubHkpIHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGQuX2Yub25CbHVyICYmIGZpZWxkLl9mLm9uQmx1cihldmVudCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoZGVsYXlFcnJvckNhbGxiYWNrcywgbmFtZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV0oMCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChmaWVsZC5fZi5vbkNoYW5nZSkge1xuICAgICAgICAgICAgICAgIGZpZWxkLl9mLm9uQ2hhbmdlKGV2ZW50KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IGZpZWxkU3RhdGUgPSB1cGRhdGVUb3VjaEFuZERpcnR5KG5hbWUsIGZpZWxkVmFsdWUsIGlzQmx1ckV2ZW50KTtcbiAgICAgICAgICAgIGNvbnN0IHNob3VsZFJlbmRlciA9ICFpc0VtcHR5T2JqZWN0KGZpZWxkU3RhdGUpIHx8IHdhdGNoZWQ7XG4gICAgICAgICAgICAhaXNCbHVyRXZlbnQgJiZcbiAgICAgICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IGV2ZW50LnR5cGUsXG4gICAgICAgICAgICAgICAgICAgIC4uLihfaGFzVmFsdWVzU3Vic2NyaWJlcihuYW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgPyB7IHZhbHVlczogY2xvbmVPYmplY3QoX2Zvcm1WYWx1ZXMpIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDoge30pLFxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKHNob3VsZFNraXBWYWxpZGF0aW9uKSB7XG4gICAgICAgICAgICAgICAgaWYgKCghaGFzTm9WYWxpZGF0aW9uRWZmZWN0IHx8ICFfZm9ybVN0YXRlLmlzVmFsaWQpICYmXG4gICAgICAgICAgICAgICAgICAgIF9pc1RyYWNrZWQoJ2lzVmFsaWQnKSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoX29wdGlvbnMubW9kZSA9PT0gJ29uQmx1cicpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc0JsdXJFdmVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9zZXRWYWxpZCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKCFpc0JsdXJFdmVudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgX3NldFZhbGlkKCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIChzaG91bGRSZW5kZXIgJiZcbiAgICAgICAgICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoeyBuYW1lLCAuLi4od2F0Y2hlZCA/IHt9IDogZmllbGRTdGF0ZSkgfSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFfb3B0aW9ucy5yZXNvbHZlciAmJiBfb3B0aW9ucy52YWxpZGF0ZSkge1xuICAgICAgICAgICAgICAgIGF3YWl0IHZhbGlkYXRlRm9ybSh7XG4gICAgICAgICAgICAgICAgICAgIG5hbWU6IG5hbWUsXG4gICAgICAgICAgICAgICAgICAgIGV2ZW50VHlwZTogZXZlbnQudHlwZSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgICFpc0JsdXJFdmVudCAmJiB3YXRjaGVkICYmIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHsgLi4uX2Zvcm1TdGF0ZSB9KTtcbiAgICAgICAgICAgIGlmIChfb3B0aW9ucy5yZXNvbHZlcikge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlc2V0Q2FsbElkID0gX3Jlc2V0Q2FsbElkO1xuICAgICAgICAgICAgICAgIGNvbnN0IHsgZXJyb3JzIH0gPSBhd2FpdCBfcnVuU2NoZW1hKFtuYW1lXSk7XG4gICAgICAgICAgICAgICAgaWYgKHJlc2V0Q2FsbElkICE9PSBfcmVzZXRDYWxsSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKFtuYW1lXSk7XG4gICAgICAgICAgICAgICAgX3VwZGF0ZUlzRmllbGRWYWx1ZVVwZGF0ZWQoZmllbGRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgaWYgKCFpc0ZpZWxkVmFsdWVVcGRhdGVkKSB7XG4gICAgICAgICAgICAgICAgICAgICFpc0VtcHR5T2JqZWN0KGZpZWxkU3RhdGUpICYmIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KGZpZWxkU3RhdGUpO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IHByZXZpb3VzRXJyb3JMb29rdXBSZXN1bHQgPSBzY2hlbWFFcnJvckxvb2t1cChfZm9ybVN0YXRlLmVycm9ycywgX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgY29uc3QgZXJyb3JMb29rdXBSZXN1bHQgPSBzY2hlbWFFcnJvckxvb2t1cChlcnJvcnMsIF9maWVsZHMsIHByZXZpb3VzRXJyb3JMb29rdXBSZXN1bHQubmFtZSB8fCBuYW1lKTtcbiAgICAgICAgICAgICAgICBlcnJvciA9IGVycm9yTG9va3VwUmVzdWx0LmVycm9yO1xuICAgICAgICAgICAgICAgIG5hbWUgPSBlcnJvckxvb2t1cFJlc3VsdC5uYW1lO1xuICAgICAgICAgICAgICAgIGlzVmFsaWQgPSBpc0VtcHR5T2JqZWN0KGVycm9ycyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBjb25zdCByZXNldENhbGxJZCA9IF9yZXNldENhbGxJZDtcbiAgICAgICAgICAgICAgICBfdXBkYXRlSXNWYWxpZGF0aW5nKFtuYW1lXSwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgZXJyb3IgPSAoYXdhaXQgdmFsaWRhdGVGaWVsZChmaWVsZCwgX25hbWVzLmRpc2FibGVkLCBfZm9ybVZhbHVlcywgc2hvdWxkRGlzcGxheUFsbEFzc29jaWF0ZWRFcnJvcnMsIF9vcHRpb25zLnNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb24pKVtuYW1lXTtcbiAgICAgICAgICAgICAgICBpZiAocmVzZXRDYWxsSWQgIT09IF9yZXNldENhbGxJZCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIF91cGRhdGVJc1ZhbGlkYXRpbmcoW25hbWVdKTtcbiAgICAgICAgICAgICAgICBfdXBkYXRlSXNGaWVsZFZhbHVlVXBkYXRlZChmaWVsZFZhbHVlKTtcbiAgICAgICAgICAgICAgICBpZiAoaXNGaWVsZFZhbHVlVXBkYXRlZCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzVmFsaWQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIGlmIChfaXNUcmFja2VkKCdpc1ZhbGlkJykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzVmFsaWQgPSBhd2FpdCBleGVjdXRlQnVpbHRJblZhbGlkYXRpb24oe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpZWxkczogX2ZpZWxkcyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbmx5Q2hlY2tWYWxpZDogdHJ1ZSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiBuYW1lLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV2ZW50VHlwZTogZXZlbnQudHlwZSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHJlc2V0Q2FsbElkICE9PSBfcmVzZXRDYWxsSWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaXNGaWVsZFZhbHVlVXBkYXRlZCkge1xuICAgICAgICAgICAgICAgIGZpZWxkLl9mLmRlcHMgJiZcbiAgICAgICAgICAgICAgICAgICAgKCFBcnJheS5pc0FycmF5KGZpZWxkLl9mLmRlcHMpIHx8IGZpZWxkLl9mLmRlcHMubGVuZ3RoID4gMCkgJiZcbiAgICAgICAgICAgICAgICAgICAgdHJpZ2dlcihmaWVsZC5fZi5kZXBzKTtcbiAgICAgICAgICAgICAgICBzaG91bGRSZW5kZXJCeUVycm9yKG5hbWUsIGlzVmFsaWQsIGVycm9yLCBmaWVsZFN0YXRlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgX2ZvY3VzSW5wdXQgPSAocmVmLCBrZXkpID0+IHtcbiAgICAgICAgaWYgKGdldChfZm9ybVN0YXRlLmVycm9ycywga2V5KSAmJiByZWYuZm9jdXMpIHtcbiAgICAgICAgICAgIHJlZi5mb2N1cygpO1xuICAgICAgICAgICAgcmV0dXJuIDE7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgIH07XG4gICAgY29uc3QgdHJpZ2dlciA9IGFzeW5jIChuYW1lLCBvcHRpb25zID0ge30pID0+IHtcbiAgICAgICAgbGV0IGlzVmFsaWQ7XG4gICAgICAgIGxldCB2YWxpZGF0aW9uUmVzdWx0O1xuICAgICAgICBjb25zdCBmaWVsZE5hbWVzID0gY29udmVydFRvQXJyYXlQYXlsb2FkKG5hbWUpO1xuICAgICAgICBpZiAoX29wdGlvbnMucmVzb2x2ZXIpIHtcbiAgICAgICAgICAgIGNvbnN0IHJlc2V0Q2FsbElkID0gX3Jlc2V0Q2FsbElkO1xuICAgICAgICAgICAgY29uc3QgZXJyb3JzID0gYXdhaXQgZXhlY3V0ZVNjaGVtYUFuZFVwZGF0ZVN0YXRlKGlzVW5kZWZpbmVkKG5hbWUpID8gbmFtZSA6IGZpZWxkTmFtZXMpO1xuICAgICAgICAgICAgaXNWYWxpZCA9IGlzRW1wdHlPYmplY3QoZXJyb3JzKTtcbiAgICAgICAgICAgIHZhbGlkYXRpb25SZXN1bHQgPSBuYW1lXG4gICAgICAgICAgICAgICAgPyAhZmllbGROYW1lcy5zb21lKChuYW1lKSA9PiBnZXQoZXJyb3JzLCBuYW1lKSlcbiAgICAgICAgICAgICAgICA6IGlzVmFsaWQ7XG4gICAgICAgICAgICBpZiAocmVzZXRDYWxsSWQgIT09IF9yZXNldENhbGxJZCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB2YWxpZGF0aW9uUmVzdWx0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKG5hbWUpIHtcbiAgICAgICAgICAgIHZhbGlkYXRpb25SZXN1bHQgPSAoYXdhaXQgUHJvbWlzZS5hbGwoZmllbGROYW1lcy5tYXAoYXN5bmMgKGZpZWxkTmFtZSkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkID0gZ2V0KF9maWVsZHMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGF3YWl0IGV4ZWN1dGVCdWlsdEluVmFsaWRhdGlvbih7XG4gICAgICAgICAgICAgICAgICAgIGZpZWxkczogZmllbGQgJiYgZmllbGQuX2YgPyB7IFtmaWVsZE5hbWVdOiBmaWVsZCB9IDogZmllbGQsXG4gICAgICAgICAgICAgICAgICAgIGV2ZW50VHlwZTogRVZFTlRTLlRSSUdHRVIsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KSkpLmV2ZXJ5KEJvb2xlYW4pO1xuICAgICAgICAgICAgISghdmFsaWRhdGlvblJlc3VsdCAmJiAhX2Zvcm1TdGF0ZS5pc1ZhbGlkKSAmJiBfc2V0VmFsaWQoKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHZhbGlkYXRpb25SZXN1bHQgPSBpc1ZhbGlkID0gYXdhaXQgZXhlY3V0ZUJ1aWx0SW5WYWxpZGF0aW9uKHtcbiAgICAgICAgICAgICAgICBmaWVsZHM6IF9maWVsZHMsXG4gICAgICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgICAgICBldmVudFR5cGU6IEVWRU5UUy5UUklHR0VSLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG9wdGlvbnMuZGVsYXlFcnJvciAmJiBfb3B0aW9ucy5kZWxheUVycm9yICYmIGlzU3RyaW5nKG5hbWUpKSB7XG4gICAgICAgICAgICBjb25zdCBlcnJvciA9IGdldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICBpZiAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSk7XG4gICAgICAgICAgICAgICAgZGVsYXlFcnJvckNhbGxiYWNrc1tuYW1lXSA9IGRlYm91bmNlKG5hbWUsICgpID0+IHVwZGF0ZUVycm9ycyhuYW1lLCBlcnJvcikpO1xuICAgICAgICAgICAgICAgIGRlbGF5RXJyb3JDYWxsYmFja3NbbmFtZV0oX29wdGlvbnMuZGVsYXlFcnJvcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBjYW5jZWxEZWxheWVkRXJyb3IobmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG9wdGlvbnMuc2hvdWxkVG91Y2gpIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgZmllbGROYW1lIG9mIG5hbWUgPyBmaWVsZE5hbWVzIDogX25hbWVzLm1vdW50KSB7XG4gICAgICAgICAgICAgICAgIV9uYW1lcy5hcnJheS5oYXMoZmllbGROYW1lKSAmJlxuICAgICAgICAgICAgICAgICAgICBzZXQoX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBmaWVsZE5hbWUsIHRydWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0geyAuLi5fZm9ybVN0YXRlLmVycm9ycyB9O1xuICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAuLi4oIWlzU3RyaW5nKG5hbWUpIHx8XG4gICAgICAgICAgICAgICAgKF9pc1RyYWNrZWQoJ2lzVmFsaWQnKSAmJiBpc1ZhbGlkICE9PSBfZm9ybVN0YXRlLmlzVmFsaWQpXG4gICAgICAgICAgICAgICAgPyB7fVxuICAgICAgICAgICAgICAgIDogeyBuYW1lIH0pLFxuICAgICAgICAgICAgLi4uKF9vcHRpb25zLnJlc29sdmVyIHx8ICFuYW1lID8geyBpc1ZhbGlkIH0gOiB7fSksXG4gICAgICAgICAgICAuLi4ob3B0aW9ucy5zaG91bGRUb3VjaCAmJiBfaXNUcmFja2VkKCd0b3VjaGVkRmllbGRzJylcbiAgICAgICAgICAgICAgICA/IHsgdG91Y2hlZEZpZWxkczogX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzIH1cbiAgICAgICAgICAgICAgICA6IHt9KSxcbiAgICAgICAgICAgIGVycm9yczogX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgIH0pO1xuICAgICAgICBvcHRpb25zLnNob3VsZEZvY3VzICYmXG4gICAgICAgICAgICAhdmFsaWRhdGlvblJlc3VsdCAmJlxuICAgICAgICAgICAgaXRlcmF0ZUZpZWxkc0J5QWN0aW9uKF9maWVsZHMsIF9mb2N1c0lucHV0LCBuYW1lID8gZmllbGROYW1lcyA6IF9uYW1lcy5tb3VudCk7XG4gICAgICAgIHJldHVybiB2YWxpZGF0aW9uUmVzdWx0O1xuICAgIH07XG4gICAgY29uc3QgZ2V0VmFsdWVzID0gKGZpZWxkTmFtZXMsIGNvbmZpZykgPT4ge1xuICAgICAgICBsZXQgdmFsdWVzID0ge1xuICAgICAgICAgICAgLi4uKF9zdGF0ZS5tb3VudCA/IF9mb3JtVmFsdWVzIDogX2RlZmF1bHRWYWx1ZXMpLFxuICAgICAgICB9O1xuICAgICAgICBpZiAoY29uZmlnKSB7XG4gICAgICAgICAgICB2YWx1ZXMgPSBleHRyYWN0Rm9ybVZhbHVlcyhjb25maWcuZGlydHlGaWVsZHMgPyBfZm9ybVN0YXRlLmRpcnR5RmllbGRzIDogX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCB2YWx1ZXMpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBpc1VuZGVmaW5lZChmaWVsZE5hbWVzKVxuICAgICAgICAgICAgPyB2YWx1ZXNcbiAgICAgICAgICAgIDogaXNTdHJpbmcoZmllbGROYW1lcylcbiAgICAgICAgICAgICAgICA/IGdldCh2YWx1ZXMsIGZpZWxkTmFtZXMpXG4gICAgICAgICAgICAgICAgOiBmaWVsZE5hbWVzLm1hcCgobmFtZSkgPT4gZ2V0KHZhbHVlcywgbmFtZSkpO1xuICAgIH07XG4gICAgY29uc3QgZ2V0RXJyb3JzID0gKGZpZWxkTmFtZXMpID0+IGlzVW5kZWZpbmVkKGZpZWxkTmFtZXMpXG4gICAgICAgID8geyAuLi5fZm9ybVN0YXRlLmVycm9ycyB9XG4gICAgICAgIDogaXNTdHJpbmcoZmllbGROYW1lcylcbiAgICAgICAgICAgID8gZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBmaWVsZE5hbWVzKVxuICAgICAgICAgICAgOiBmaWVsZE5hbWVzLm1hcCgobmFtZSkgPT4gZ2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKSk7XG4gICAgY29uc3QgZ2V0RmllbGRTdGF0ZSA9IChuYW1lLCBmb3JtU3RhdGUpID0+IHtcbiAgICAgICAgY29uc3QgdGFyZ2V0Rm9ybVN0YXRlID0gZm9ybVN0YXRlIHx8IF9mb3JtU3RhdGU7XG4gICAgICAgIGNvbnN0IGVycm9yID0gZ2V0KHRhcmdldEZvcm1TdGF0ZS5lcnJvcnMsIG5hbWUpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaW52YWxpZDogISFlcnJvcixcbiAgICAgICAgICAgIGlzRGlydHk6ICEhZ2V0KHRhcmdldEZvcm1TdGF0ZS5kaXJ0eUZpZWxkcywgbmFtZSksXG4gICAgICAgICAgICBlcnJvcixcbiAgICAgICAgICAgIGlzVmFsaWRhdGluZzogISFnZXQodGFyZ2V0Rm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMsIG5hbWUpLFxuICAgICAgICAgICAgaXNUb3VjaGVkOiAhIWdldCh0YXJnZXRGb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgbmFtZSksXG4gICAgICAgIH07XG4gICAgfTtcbiAgICBjb25zdCBjbGVhckVycm9ycyA9IChuYW1lKSA9PiB7XG4gICAgICAgIGNvbnN0IG5hbWVzID0gbmFtZSA/IGNvbnZlcnRUb0FycmF5UGF5bG9hZChuYW1lKSA6IHVuZGVmaW5lZDtcbiAgICAgICAgaWYgKG5hbWVzKSB7XG4gICAgICAgICAgICBuYW1lcy5mb3JFYWNoKChpbnB1dE5hbWUpID0+IHtcbiAgICAgICAgICAgICAgICBjYW5jZWxEZWxheWVkRXJyb3JUcmVlKGlucHV0TmFtZSk7XG4gICAgICAgICAgICAgICAgdW5zZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIGlucHV0TmFtZSk7XG4gICAgICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSB7IC4uLl9mb3JtU3RhdGUuZXJyb3JzIH07XG4gICAgICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiBpbnB1dE5hbWUsXG4gICAgICAgICAgICAgICAgICAgIGVycm9yczogX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIE9iamVjdC5rZXlzKGRlbGF5RXJyb3JDYWxsYmFja3MpLmZvckVhY2goY2FuY2VsRGVsYXllZEVycm9yKTtcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0ge307XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBzZXRFcnJvciA9IChuYW1lLCBlcnJvciwgb3B0aW9ucykgPT4ge1xuICAgICAgICBjYW5jZWxEZWxheWVkRXJyb3JUcmVlKG5hbWUpO1xuICAgICAgICBjb25zdCByZWYgPSAoZ2V0KF9maWVsZHMsIG5hbWUsIHsgX2Y6IHt9IH0pLl9mIHx8IHt9KS5yZWY7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRFcnJvciA9IGdldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSkgfHwge307XG4gICAgICAgIGNvbnN0IHsgcmVmOiBjdXJyZW50UmVmLCBtZXNzYWdlLCB0eXBlLCB0eXBlcywgLi4ucmVzdE9mRXJyb3JUcmVlIH0gPSBjdXJyZW50RXJyb3I7XG4gICAgICAgIHNldChfZm9ybVN0YXRlLmVycm9ycywgbmFtZSwge1xuICAgICAgICAgICAgLi4ucmVzdE9mRXJyb3JUcmVlLFxuICAgICAgICAgICAgLi4uZXJyb3IsXG4gICAgICAgICAgICByZWYsXG4gICAgICAgIH0pO1xuICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgIGVycm9yczogX2Zvcm1TdGF0ZS5lcnJvcnMsXG4gICAgICAgICAgICBpc1ZhbGlkOiBmYWxzZSxcbiAgICAgICAgfSk7XG4gICAgICAgIG9wdGlvbnMgJiYgb3B0aW9ucy5zaG91bGRGb2N1cyAmJiByZWYgJiYgcmVmLmZvY3VzICYmIHJlZi5mb2N1cygpO1xuICAgIH07XG4gICAgY29uc3Qgd2F0Y2ggPSAobmFtZSwgZGVmYXVsdFZhbHVlKSA9PiB7XG4gICAgICAgIGlmIChpc0Z1bmN0aW9uKG5hbWUpKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZXNTdWJzY3JpYmVyID0ge307XG4gICAgICAgICAgICBfdmFsdWVzU3Vic2NyaWJlcnMuYWRkKHZhbHVlc1N1YnNjcmliZXIpO1xuICAgICAgICAgICAgY29uc3QgeyB1bnN1YnNjcmliZSB9ID0gX3N1YmplY3RzLnN0YXRlLnN1YnNjcmliZSh7XG4gICAgICAgICAgICAgICAgbmV4dDogKHBheWxvYWQpID0+ICd2YWx1ZXMnIGluIHBheWxvYWQgJiZcbiAgICAgICAgICAgICAgICAgICAgbmFtZShwYXlsb2FkLnZhbHVlcyB8fCBfZ2V0V2F0Y2godW5kZWZpbmVkLCBkZWZhdWx0VmFsdWUpLCBwYXlsb2FkKSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICB1bnN1YnNjcmliZTogKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBfdmFsdWVzU3Vic2NyaWJlcnMuZGVsZXRlKHZhbHVlc1N1YnNjcmliZXIpO1xuICAgICAgICAgICAgICAgICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBfZ2V0V2F0Y2gobmFtZSwgZGVmYXVsdFZhbHVlLCB0cnVlKTtcbiAgICB9O1xuICAgIGNvbnN0IF9zdWJzY3JpYmUgPSAocHJvcHMpID0+IHtcbiAgICAgICAgY29uc3QgdmFsdWVzU3Vic2NyaWJlciA9IHsgbmFtZTogcHJvcHMubmFtZSwgZXhhY3Q6IHByb3BzLmV4YWN0IH07XG4gICAgICAgIHByb3BzLmZvcm1TdGF0ZSAmJlxuICAgICAgICAgICAgcHJvcHMuZm9ybVN0YXRlLnZhbHVlcyAmJlxuICAgICAgICAgICAgX3ZhbHVlc1N1YnNjcmliZXJzLmFkZCh2YWx1ZXNTdWJzY3JpYmVyKTtcbiAgICAgICAgY29uc3QgeyB1bnN1YnNjcmliZSB9ID0gX3N1YmplY3RzLnN0YXRlLnN1YnNjcmliZSh7XG4gICAgICAgICAgICBuZXh0OiAoZm9ybVN0YXRlKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHNob3VsZFN1YnNjcmliZUJ5TmFtZShwcm9wcy5uYW1lLCBmb3JtU3RhdGUubmFtZSwgcHJvcHMuZXhhY3QpICYmXG4gICAgICAgICAgICAgICAgICAgIHNob3VsZFJlbmRlckZvcm1TdGF0ZShmb3JtU3RhdGUsIHByb3BzLmZvcm1TdGF0ZSB8fCBfcHJveHlGb3JtU3RhdGUsIHByb3BzLnJlUmVuZGVyUm9vdCkpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgdmFsdWVzID0gZm9ybVN0YXRlLnZhbHVlcyB8fCB7IC4uLl9mb3JtVmFsdWVzIH07XG4gICAgICAgICAgICAgICAgICAgIHByb3BzLmNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZXMsXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWZhdWx0VmFsdWVzOiBfZGVmYXVsdFZhbHVlcyxcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiAoKSA9PiB7XG4gICAgICAgICAgICBfdmFsdWVzU3Vic2NyaWJlcnMuZGVsZXRlKHZhbHVlc1N1YnNjcmliZXIpO1xuICAgICAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgfTtcbiAgICB9O1xuICAgIGNvbnN0IHN1YnNjcmliZSA9IChwcm9wcykgPT4ge1xuICAgICAgICBfc3RhdGUubW91bnQgPSB0cnVlO1xuICAgICAgICBjb25zdCB0cmFja2VkS2V5cyA9IE9iamVjdC5rZXlzKHByb3BzLmZvcm1TdGF0ZSB8fCB7fSkuZmlsdGVyKChrZXkpID0+IHByb3BzLmZvcm1TdGF0ZSAmJiBwcm9wcy5mb3JtU3RhdGVba2V5XSk7XG4gICAgICAgIGZvciAoY29uc3Qga2V5IG9mIHRyYWNrZWRLZXlzKSB7XG4gICAgICAgICAgICBfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGVba2V5XSA9IChfcHJveHlTdWJzY3JpYmVGb3JtU3RhdGVba2V5XSB8fCAwKSArIDE7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgdW5zdWJzY3JpYmUgPSBfc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIC4uLnByb3BzLFxuICAgICAgICAgICAgZm9ybVN0YXRlOiB7XG4gICAgICAgICAgICAgICAgLi4uZGVmYXVsdFByb3h5Rm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgIC4uLnByb3BzLmZvcm1TdGF0ZSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgLy8gc3BsaWNlKDApIGVtcHRpZXMgdGhlIGxpc3QsIHNvIGEgcmVwZWF0ZWQgdW5zdWJzY3JpYmUgcmVsZWFzZXMgbm90aGluZ1xuICAgICAgICAgICAgZm9yIChjb25zdCBrZXkgb2YgdHJhY2tlZEtleXMuc3BsaWNlKDApKSB7XG4gICAgICAgICAgICAgICAgX3Byb3h5U3Vic2NyaWJlRm9ybVN0YXRlW2tleV0tLTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHVuc3Vic2NyaWJlKCk7XG4gICAgICAgIH07XG4gICAgfTtcbiAgICBjb25zdCB1bnJlZ2lzdGVyID0gKG5hbWUsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTmFtZSBvZiBuYW1lID8gY29udmVydFRvQXJyYXlQYXlsb2FkKG5hbWUpIDogX25hbWVzLm1vdW50KSB7XG4gICAgICAgICAgICBfbmFtZXMubW91bnQuZGVsZXRlKGZpZWxkTmFtZSk7XG4gICAgICAgICAgICBfbmFtZXMuYXJyYXkuZGVsZXRlKGZpZWxkTmFtZSk7XG4gICAgICAgICAgICBfbmFtZXMuZGlzYWJsZWQuZGVsZXRlKGZpZWxkTmFtZSk7XG4gICAgICAgICAgICBpZiAoIW9wdGlvbnMua2VlcFZhbHVlKSB7XG4gICAgICAgICAgICAgICAgdW5zZXQoX2ZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgICAgICB1bnNldChfZm9ybVZhbHVlcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghb3B0aW9ucy5rZWVwRXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjYW5jZWxEZWxheWVkRXJyb3JUcmVlKGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAgICAgdW5zZXQoX2Zvcm1TdGF0ZS5lcnJvcnMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAhb3B0aW9ucy5rZWVwRGlydHkgJiYgdW5zZXQoX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgICFvcHRpb25zLmtlZXBUb3VjaGVkICYmIHVuc2V0KF9mb3JtU3RhdGUudG91Y2hlZEZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgICFvcHRpb25zLmtlZXBJc1ZhbGlkYXRpbmcgJiZcbiAgICAgICAgICAgICAgICB1bnNldChfZm9ybVN0YXRlLnZhbGlkYXRpbmdGaWVsZHMsIGZpZWxkTmFtZSk7XG4gICAgICAgICAgICAhX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlciAmJlxuICAgICAgICAgICAgICAgICFvcHRpb25zLmtlZXBEZWZhdWx0VmFsdWUgJiZcbiAgICAgICAgICAgICAgICB1bnNldChfZGVmYXVsdFZhbHVlcywgZmllbGROYW1lKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIW9wdGlvbnMua2VlcEVycm9yKSB7XG4gICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgfVxuICAgICAgICBfdmFsdWVzU3Vic2NyaWJlcnMuc2l6ZSAmJlxuICAgICAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIHZhbHVlczogY2xvbmVPYmplY3QoX2Zvcm1WYWx1ZXMpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgIC4uLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICAuLi4ob3B0aW9ucy5rZWVwRGlydHkgPyB7fSA6IHsgaXNEaXJ0eTogX2dldERpcnR5KCkgfSksXG4gICAgICAgICAgICAuLi4ob3B0aW9ucy5rZWVwSXNWYWxpZGF0aW5nXG4gICAgICAgICAgICAgICAgPyB7fVxuICAgICAgICAgICAgICAgIDogeyBpc1ZhbGlkYXRpbmc6ICFpc0VtcHR5T2JqZWN0KF9mb3JtU3RhdGUudmFsaWRhdGluZ0ZpZWxkcykgfSksXG4gICAgICAgIH0pO1xuICAgICAgICAhb3B0aW9ucy5rZWVwSXNWYWxpZCAmJiBfc2V0VmFsaWQoKTtcbiAgICB9O1xuICAgIGNvbnN0IF9zZXREaXNhYmxlZEZpZWxkID0gKHsgZGlzYWJsZWQsIG5hbWUsIH0pID0+IHtcbiAgICAgICAgaWYgKChpc0Jvb2xlYW4oZGlzYWJsZWQpICYmIF9zdGF0ZS5tb3VudCkgfHxcbiAgICAgICAgICAgICEhZGlzYWJsZWQgfHxcbiAgICAgICAgICAgIF9uYW1lcy5kaXNhYmxlZC5oYXMobmFtZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IHdhc0Rpc2FibGVkID0gX25hbWVzLmRpc2FibGVkLmhhcyhuYW1lKTtcbiAgICAgICAgICAgIGNvbnN0IGlzRGlzYWJsZWQgPSAhIWRpc2FibGVkO1xuICAgICAgICAgICAgY29uc3QgZGlzYWJsZWRTdGF0ZUNoYW5nZWQgPSB3YXNEaXNhYmxlZCAhPT0gaXNEaXNhYmxlZDtcbiAgICAgICAgICAgIGRpc2FibGVkID8gX25hbWVzLmRpc2FibGVkLmFkZChuYW1lKSA6IF9uYW1lcy5kaXNhYmxlZC5kZWxldGUobmFtZSk7XG4gICAgICAgICAgICBkaXNhYmxlZFN0YXRlQ2hhbmdlZCAmJiBfc3RhdGUubW91bnQgJiYgIV9zdGF0ZS5hY3Rpb24gJiYgX3NldFZhbGlkKCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHJlZ2lzdGVyID0gKG5hbWUsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBsZXQgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgIGNvbnN0IGRpc2FibGVkSXNEZWZpbmVkID0gaXNCb29sZWFuKG9wdGlvbnMuZGlzYWJsZWQpIHx8IGlzQm9vbGVhbihfb3B0aW9ucy5kaXNhYmxlZCk7XG4gICAgICAgIGNvbnN0IHNob3VsZFJldmFsaWRhdGVSZW1vdW50ID0gIV9uYW1lcy5yZWdpc3Rlck5hbWUuaGFzKG5hbWUpICYmIGZpZWxkICYmIGZpZWxkLl9mICYmICFmaWVsZC5fZi5tb3VudDtcbiAgICAgICAgc2V0KF9maWVsZHMsIG5hbWUsIHtcbiAgICAgICAgICAgIC4uLihmaWVsZCB8fCB7fSksXG4gICAgICAgICAgICBfZjoge1xuICAgICAgICAgICAgICAgIC4uLihmaWVsZCAmJiBmaWVsZC5fZiA/IGZpZWxkLl9mIDogeyByZWY6IHsgbmFtZSB9IH0pLFxuICAgICAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICAgICAgbW91bnQ6IHRydWUsXG4gICAgICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBfbmFtZXMubW91bnQuYWRkKG5hbWUpO1xuICAgICAgICBpZiAoZmllbGQgJiYgZmllbGQuX2YpIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHRGaWVsZCA9IGdldChfZmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIGZvciAoY29uc3QgcnVsZSBvZiBSRUdJU1RFUl9WQUxJREFUSU9OX1JVTEVTKSB7XG4gICAgICAgICAgICAgICAgaWYgKCEocnVsZSBpbiBvcHRpb25zKSkge1xuICAgICAgICAgICAgICAgICAgICBkZWxldGUgbmV4dEZpZWxkLl9mW3J1bGVdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoZmllbGQgJiYgIXNob3VsZFJldmFsaWRhdGVSZW1vdW50KSB7XG4gICAgICAgICAgICBfc2V0RGlzYWJsZWRGaWVsZCh7XG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ6IGlzQm9vbGVhbihvcHRpb25zLmRpc2FibGVkKVxuICAgICAgICAgICAgICAgICAgICA/IG9wdGlvbnMuZGlzYWJsZWRcbiAgICAgICAgICAgICAgICAgICAgOiBfb3B0aW9ucy5kaXNhYmxlZCxcbiAgICAgICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB1cGRhdGVWYWxpZEFuZFZhbHVlKG5hbWUsIHRydWUsIG9wdGlvbnMudmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi4oZGlzYWJsZWRJc0RlZmluZWRcbiAgICAgICAgICAgICAgICA/IHsgZGlzYWJsZWQ6IG9wdGlvbnMuZGlzYWJsZWQgfHwgX29wdGlvbnMuZGlzYWJsZWQgfVxuICAgICAgICAgICAgICAgIDoge30pLFxuICAgICAgICAgICAgLi4uKF9vcHRpb25zLnByb2dyZXNzaXZlXG4gICAgICAgICAgICAgICAgPyB7XG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkOiAhIW9wdGlvbnMucmVxdWlyZWQsXG4gICAgICAgICAgICAgICAgICAgIG1pbjogZ2V0UnVsZVZhbHVlKG9wdGlvbnMubWluKSxcbiAgICAgICAgICAgICAgICAgICAgbWF4OiBnZXRSdWxlVmFsdWUob3B0aW9ucy5tYXgpLFxuICAgICAgICAgICAgICAgICAgICBtaW5MZW5ndGg6IGdldFJ1bGVWYWx1ZShvcHRpb25zLm1pbkxlbmd0aCksXG4gICAgICAgICAgICAgICAgICAgIG1heExlbmd0aDogZ2V0UnVsZVZhbHVlKG9wdGlvbnMubWF4TGVuZ3RoKSxcbiAgICAgICAgICAgICAgICAgICAgcGF0dGVybjogZ2V0UnVsZVZhbHVlKG9wdGlvbnMucGF0dGVybiksXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIDoge30pLFxuICAgICAgICAgICAgbmFtZSxcbiAgICAgICAgICAgIG9uQ2hhbmdlLFxuICAgICAgICAgICAgb25CbHVyOiBvbkNoYW5nZSxcbiAgICAgICAgICAgIHJlZjogKHJlZikgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChyZWYpIHtcbiAgICAgICAgICAgICAgICAgICAgX25hbWVzLnJlZ2lzdGVyTmFtZS5hZGQobmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIHJlZ2lzdGVyKG5hbWUsIG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgICAgICBfbmFtZXMucmVnaXN0ZXJOYW1lLmRlbGV0ZShuYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkUmVmID0gaXNVbmRlZmluZWQocmVmLnZhbHVlKVxuICAgICAgICAgICAgICAgICAgICAgICAgPyByZWYucXVlcnlTZWxlY3RvckFsbFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gcmVmLnF1ZXJ5U2VsZWN0b3JBbGwoJ2lucHV0LHNlbGVjdCx0ZXh0YXJlYScpWzBdIHx8IHJlZlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogcmVmXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHJlZjtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcmFkaW9PckNoZWNrYm94ID0gaXNSYWRpb09yQ2hlY2tib3goZmllbGRSZWYpO1xuICAgICAgICAgICAgICAgICAgICBjb25zdCByZWZzID0gZmllbGQuX2YucmVmcyB8fCBbXTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHJhZGlvT3JDaGVja2JveFxuICAgICAgICAgICAgICAgICAgICAgICAgPyByZWZzLmZpbmQoKG9wdGlvbikgPT4gb3B0aW9uID09PSBmaWVsZFJlZilcbiAgICAgICAgICAgICAgICAgICAgICAgIDogZmllbGRSZWYgPT09IGZpZWxkLl9mLnJlZikge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5ld0ZpZWxkID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgLi4uZmllbGQuX2YsXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIGlmIChyYWRpb09yQ2hlY2tib3gpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5ld0ZpZWxkLnJlZnMgPSBbXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucmVmcy5maWx0ZXIobGl2ZSksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRSZWYsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4uKEFycmF5LmlzQXJyYXkoZ2V0KF9kZWZhdWx0VmFsdWVzLCBuYW1lKSkgPyBbe31dIDogW10pLFxuICAgICAgICAgICAgICAgICAgICAgICAgXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5ld0ZpZWxkLnJlZiA9IHsgdHlwZTogZmllbGRSZWYudHlwZSwgbmFtZSB9O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgbmV3RmllbGQucmVmID0gZmllbGRSZWY7XG4gICAgICAgICAgICAgICAgICAgICAgICBkZWxldGUgbmV3RmllbGQucmVmcztcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBzZXQoX2ZpZWxkcywgbmFtZSwge1xuICAgICAgICAgICAgICAgICAgICAgICAgX2Y6IG5ld0ZpZWxkLFxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlVmFsaWRBbmRWYWx1ZShuYW1lLCBmYWxzZSwgdW5kZWZpbmVkLCBmaWVsZFJlZik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBmaWVsZCA9IGdldChfZmllbGRzLCBuYW1lLCB7fSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChmaWVsZC5fZikge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGQuX2YubW91bnQgPSBmYWxzZTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAoX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlciB8fCBvcHRpb25zLnNob3VsZFVucmVnaXN0ZXIpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAhKGlzTmFtZUluRmllbGRBcnJheShfbmFtZXMuYXJyYXksIG5hbWUpICYmIF9zdGF0ZS5hY3Rpb24pICYmXG4gICAgICAgICAgICAgICAgICAgICAgICBfbmFtZXMudW5Nb3VudC5hZGQobmFtZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICB9O1xuICAgIGNvbnN0IF9mb2N1c0Vycm9yID0gKCkgPT4gX29wdGlvbnMuc2hvdWxkRm9jdXNFcnJvciAmJlxuICAgICAgICAhX29wdGlvbnMuc2hvdWxkVXNlTmF0aXZlVmFsaWRhdGlvbiAmJlxuICAgICAgICBpdGVyYXRlRmllbGRzQnlBY3Rpb24oX2ZpZWxkcywgX2ZvY3VzSW5wdXQsIF9uYW1lcy5tb3VudCk7XG4gICAgY29uc3QgX2Rpc2FibGVGb3JtID0gKGRpc2FibGVkKSA9PiB7XG4gICAgICAgIGlmIChpc0Jvb2xlYW4oZGlzYWJsZWQpKSB7XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7IGRpc2FibGVkIH0pO1xuICAgICAgICAgICAgaXRlcmF0ZUZpZWxkc0J5QWN0aW9uKF9maWVsZHMsIChyZWYsIG5hbWUpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBjdXJyZW50RmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgaWYgKGN1cnJlbnRGaWVsZCkge1xuICAgICAgICAgICAgICAgICAgICByZWYuZGlzYWJsZWQgPSBjdXJyZW50RmllbGQuX2YuZGlzYWJsZWQgfHwgZGlzYWJsZWQ7XG4gICAgICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGN1cnJlbnRGaWVsZC5fZi5yZWZzKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudEZpZWxkLl9mLnJlZnMuZm9yRWFjaCgoaW5wdXRSZWYpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbnB1dFJlZi5kaXNhYmxlZCA9IGN1cnJlbnRGaWVsZC5fZi5kaXNhYmxlZCB8fCBkaXNhYmxlZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSwgMCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGhhbmRsZVN1Ym1pdCA9IChvblZhbGlkLCBvbkludmFsaWQpID0+IGFzeW5jIChlKSA9PiB7XG4gICAgICAgIGxldCByZXN1bHQgPSB1bmRlZmluZWQ7XG4gICAgICAgIGxldCBvblZhbGlkRXJyb3IgPSB1bmRlZmluZWQ7XG4gICAgICAgIGlmIChlKSB7XG4gICAgICAgICAgICBlLnByZXZlbnREZWZhdWx0ICYmIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIGUucGVyc2lzdCAmJlxuICAgICAgICAgICAgICAgIGUucGVyc2lzdCgpO1xuICAgICAgICB9XG4gICAgICAgIGxldCBmaWVsZFZhbHVlcyA9IGNsb25lT2JqZWN0KF9mb3JtVmFsdWVzKTtcbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgaXNTdWJtaXR0aW5nOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKF9vcHRpb25zLnJlc29sdmVyKSB7XG4gICAgICAgICAgICBjb25zdCByZXNldENhbGxJZCA9IF9yZXNldENhbGxJZDtcbiAgICAgICAgICAgIGNvbnN0IHsgZXJyb3JzLCB2YWx1ZXMgfSA9IGF3YWl0IF9ydW5TY2hlbWEoKTtcbiAgICAgICAgICAgIGlmIChyZXNldENhbGxJZCAhPT0gX3Jlc2V0Q2FsbElkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZygpO1xuICAgICAgICAgICAgT2JqZWN0LmtleXMoZGVsYXlFcnJvckNhbGxiYWNrcykuZm9yRWFjaChjYW5jZWxEZWxheWVkRXJyb3IpO1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5lcnJvcnMgPSBlcnJvcnM7XG4gICAgICAgICAgICBmaWVsZFZhbHVlcyA9IGNsb25lT2JqZWN0KHZhbHVlcyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjb25zdCByZXNldENhbGxJZCA9IF9yZXNldENhbGxJZDtcbiAgICAgICAgICAgIGF3YWl0IGV4ZWN1dGVCdWlsdEluVmFsaWRhdGlvbih7XG4gICAgICAgICAgICAgICAgZmllbGRzOiBfZmllbGRzLFxuICAgICAgICAgICAgICAgIGV2ZW50VHlwZTogRVZFTlRTLlNVQk1JVCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKHJlc2V0Q2FsbElkICE9PSBfcmVzZXRDYWxsSWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB1bnNldChfZm9ybVN0YXRlLmVycm9ycywgUk9PVF9FUlJPUl9UWVBFKTtcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0geyAuLi5fZm9ybVN0YXRlLmVycm9ycyB9O1xuICAgICAgICB9XG4gICAgICAgIGlmIChfbmFtZXMuZGlzYWJsZWQuc2l6ZSkge1xuICAgICAgICAgICAgZm9yIChjb25zdCBuYW1lIG9mIF9uYW1lcy5kaXNhYmxlZCkge1xuICAgICAgICAgICAgICAgIHVuc2V0KGZpZWxkVmFsdWVzLCBuYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNFbXB0eU9iamVjdChfZm9ybVN0YXRlLmVycm9ycykpIHtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICBlcnJvcnM6IHt9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHJlc3VsdCA9IGF3YWl0IG9uVmFsaWQoZmllbGRWYWx1ZXMsIGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICAgICAgb25WYWxpZEVycm9yID0gZXJyb3I7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBpZiAob25JbnZhbGlkKSB7XG4gICAgICAgICAgICAgICAgYXdhaXQgb25JbnZhbGlkKHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfSwgZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfZm9jdXNFcnJvcigpO1xuICAgICAgICAgICAgc2V0VGltZW91dChfZm9jdXNFcnJvcik7XG4gICAgICAgIH1cbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgaXNTdWJtaXR0ZWQ6IHRydWUsXG4gICAgICAgICAgICBpc1N1Ym1pdHRpbmc6IGZhbHNlLFxuICAgICAgICAgICAgaXNTdWJtaXRTdWNjZXNzZnVsOiBpc0VtcHR5T2JqZWN0KF9mb3JtU3RhdGUuZXJyb3JzKSAmJiAhb25WYWxpZEVycm9yLFxuICAgICAgICAgICAgc3VibWl0Q291bnQ6IF9mb3JtU3RhdGUuc3VibWl0Q291bnQgKyAxLFxuICAgICAgICAgICAgZXJyb3JzOiBfZm9ybVN0YXRlLmVycm9ycyxcbiAgICAgICAgfSk7XG4gICAgICAgIGlmIChvblZhbGlkRXJyb3IpIHtcbiAgICAgICAgICAgIHRocm93IG9uVmFsaWRFcnJvcjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH07XG4gICAgY29uc3QgcmVzZXRGaWVsZCA9IChuYW1lLCBvcHRpb25zID0ge30pID0+IHtcbiAgICAgICAgaWYgKGdldChfZmllbGRzLCBuYW1lKSkge1xuICAgICAgICAgICAgdW5zZXQoX2Zvcm1TdGF0ZS52YWxpZGF0aW5nRmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIGlmIChpc1VuZGVmaW5lZChvcHRpb25zLmRlZmF1bHRWYWx1ZSkpIHtcbiAgICAgICAgICAgICAgICBzZXRWYWx1ZShuYW1lLCBjbG9uZU9iamVjdChnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUpKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZXRWYWx1ZShuYW1lLCBvcHRpb25zLmRlZmF1bHRWYWx1ZSk7XG4gICAgICAgICAgICAgICAgc2V0KF9kZWZhdWx0VmFsdWVzLCBuYW1lLCBjbG9uZU9iamVjdChvcHRpb25zLmRlZmF1bHRWYWx1ZSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKCFvcHRpb25zLmtlZXBUb3VjaGVkKSB7XG4gICAgICAgICAgICAgICAgdW5zZXQoX2Zvcm1TdGF0ZS50b3VjaGVkRmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghb3B0aW9ucy5rZWVwRGlydHkpIHtcbiAgICAgICAgICAgICAgICB1bnNldChfZm9ybVN0YXRlLmRpcnR5RmllbGRzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBfZm9ybVN0YXRlLmlzRGlydHkgPSBvcHRpb25zLmRlZmF1bHRWYWx1ZVxuICAgICAgICAgICAgICAgICAgICA/IF9nZXREaXJ0eShuYW1lLCBjbG9uZU9iamVjdChnZXQoX2RlZmF1bHRWYWx1ZXMsIG5hbWUpKSlcbiAgICAgICAgICAgICAgICAgICAgOiBfZ2V0RGlydHkoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghb3B0aW9ucy5rZWVwRXJyb3IpIHtcbiAgICAgICAgICAgICAgICBjYW5jZWxEZWxheWVkRXJyb3JUcmVlKG5hbWUpO1xuICAgICAgICAgICAgICAgIHVuc2V0KF9mb3JtU3RhdGUuZXJyb3JzLCBuYW1lKTtcbiAgICAgICAgICAgICAgICBfZm9ybVN0YXRlLmVycm9ycyA9IHsgLi4uX2Zvcm1TdGF0ZS5lcnJvcnMgfTtcbiAgICAgICAgICAgICAgICBfc2V0VmFsaWQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICAuLi5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgIGlzVmFsaWRhdGluZzogIWlzRW1wdHlPYmplY3QoX2Zvcm1TdGF0ZS52YWxpZGF0aW5nRmllbGRzKSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBfcmVzZXQgPSAoZm9ybVZhbHVlcywga2VlcFN0YXRlT3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgICAgIF9yZXNldENhbGxJZCsrO1xuICAgICAgICBjb25zdCB1cGRhdGVkVmFsdWVzID0gZm9ybVZhbHVlcyA/IGNsb25lT2JqZWN0KGZvcm1WYWx1ZXMpIDogX2RlZmF1bHRWYWx1ZXM7XG4gICAgICAgIGNvbnN0IGNsb25lVXBkYXRlZFZhbHVlcyA9IGNsb25lT2JqZWN0KHVwZGF0ZWRWYWx1ZXMpO1xuICAgICAgICBjb25zdCBpc0VtcHR5UmVzZXRWYWx1ZXMgPSBpc0VtcHR5T2JqZWN0KGZvcm1WYWx1ZXMpO1xuICAgICAgICBjb25zdCB2YWx1ZXMgPSBjbG9uZVVwZGF0ZWRWYWx1ZXM7XG4gICAgICAgIGNvbnN0IGZpZWxkUmVmcyA9IF9maWVsZHM7XG4gICAgICAgIE9iamVjdC5rZXlzKGRlbGF5RXJyb3JDYWxsYmFja3MpLmZvckVhY2goY2FuY2VsRGVsYXllZEVycm9yKTtcbiAgICAgICAgaWYgKCFrZWVwU3RhdGVPcHRpb25zLmtlZXBEZWZhdWx0VmFsdWVzKSB7XG4gICAgICAgICAgICBfZGVmYXVsdFZhbHVlcyA9IHVwZGF0ZWRWYWx1ZXM7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFrZWVwU3RhdGVPcHRpb25zLmtlZXBWYWx1ZXMpIHtcbiAgICAgICAgICAgIGlmIChrZWVwU3RhdGVPcHRpb25zLmtlZXBEaXJ0eVZhbHVlcykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGZpZWxkc1RvQ2hlY2sgPSBuZXcgU2V0KFtcbiAgICAgICAgICAgICAgICAgICAgLi4uX25hbWVzLm1vdW50LFxuICAgICAgICAgICAgICAgICAgICAuLi5jb2xsZWN0RGlydHlGaWVsZE5hbWVzKGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBfZm9ybVZhbHVlcywgdW5kZWZpbmVkLCBmaWVsZFJlZnMpLCBfZm9ybVN0YXRlLmRpcnR5RmllbGRzKSxcbiAgICAgICAgICAgICAgICBdKTtcbiAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTmFtZSBvZiBmaWVsZHNUb0NoZWNrKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IGlzRGlydHkgPSBnZXQoX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgZXhpc3RpbmdWYWx1ZSA9IGdldChfZm9ybVZhbHVlcywgZmllbGROYW1lKTtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgbmV3VmFsdWUgPSBnZXQodmFsdWVzLCBmaWVsZE5hbWUpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoaXNEaXJ0eSAmJiAhaXNVbmRlZmluZWQoZXhpc3RpbmdWYWx1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldCh2YWx1ZXMsIGZpZWxkTmFtZSwgZXhpc3RpbmdWYWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoIWlzRGlydHkgJiYgIWlzVW5kZWZpbmVkKG5ld1ZhbHVlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VmFsdWUoZmllbGROYW1lLCBuZXdWYWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBpZiAoaXNXZWIgJiYgaXNVbmRlZmluZWQoZm9ybVZhbHVlcykpIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCBuYW1lIG9mIF9uYW1lcy5tb3VudCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoZmllbGQgJiYgZmllbGQuX2YpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmaWVsZFJlZmVyZW5jZSA9IEFycmF5LmlzQXJyYXkoZmllbGQuX2YucmVmcylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBmaWVsZC5fZi5yZWZzWzBdXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogZmllbGQuX2YucmVmO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpc0hUTUxFbGVtZW50KGZpZWxkUmVmZXJlbmNlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBmb3JtID0gZmllbGRSZWZlcmVuY2UuY2xvc2VzdCgnZm9ybScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZm9ybSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9ybS5yZXNldCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGtlZXBTdGF0ZU9wdGlvbnMua2VlcEZpZWxkc1JlZikge1xuICAgICAgICAgICAgICAgICAgICBmb3IgKGNvbnN0IGZpZWxkTmFtZSBvZiBfbmFtZXMubW91bnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFZhbHVlKGZpZWxkTmFtZSwgZ2V0KHZhbHVlcywgZmllbGROYW1lKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIF9maWVsZHMgPSB7fTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoX29wdGlvbnMuc2hvdWxkVW5yZWdpc3Rlcikge1xuICAgICAgICAgICAgICAgIF9mb3JtVmFsdWVzID0ga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGVmYXVsdFZhbHVlc1xuICAgICAgICAgICAgICAgICAgICA/IGNsb25lT2JqZWN0KF9kZWZhdWx0VmFsdWVzKVxuICAgICAgICAgICAgICAgICAgICA6IHt9O1xuICAgICAgICAgICAgICAgIGlmIChrZWVwU3RhdGVPcHRpb25zLmtlZXBGaWVsZHNSZWYpIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCBmaWVsZE5hbWUgb2YgX25hbWVzLm1vdW50KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXQoX2Zvcm1WYWx1ZXMsIGZpZWxkTmFtZSwgZ2V0KHZhbHVlcywgZmllbGROYW1lKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBfZm9ybVZhbHVlcyA9IGNsb25lT2JqZWN0KHZhbHVlcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfc3ViamVjdHMuYXJyYXkubmV4dCh7XG4gICAgICAgICAgICAgICAgdmFsdWVzOiB7IC4uLnZhbHVlcyB9LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBfc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgbmFtZTogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIHR5cGU6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICB2YWx1ZXM6IHsgLi4udmFsdWVzIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBfbmFtZXMgPSB7XG4gICAgICAgICAgICBtb3VudDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGlydHlWYWx1ZXMgPyBfbmFtZXMubW91bnQgOiBuZXcgU2V0KCksXG4gICAgICAgICAgICB1bk1vdW50OiBuZXcgU2V0KCksXG4gICAgICAgICAgICBhcnJheTogbmV3IFNldCgpLFxuICAgICAgICAgICAgcmVnaXN0ZXJOYW1lOiBuZXcgU2V0KCksXG4gICAgICAgICAgICBkaXNhYmxlZDogbmV3IFNldCgpLFxuICAgICAgICAgICAgd2F0Y2g6IG5ldyBTZXQoKSxcbiAgICAgICAgICAgIHdhdGNoQWxsOiBmYWxzZSxcbiAgICAgICAgICAgIGZvY3VzOiAnJyxcbiAgICAgICAgfTtcbiAgICAgICAgX3N0YXRlLm1vdW50ID1cbiAgICAgICAgICAgICFfcHJveHlGb3JtU3RhdGUuaXNWYWxpZCB8fFxuICAgICAgICAgICAgICAgICEha2VlcFN0YXRlT3B0aW9ucy5rZWVwSXNWYWxpZCB8fFxuICAgICAgICAgICAgICAgICEha2VlcFN0YXRlT3B0aW9ucy5rZWVwRGlydHlWYWx1ZXMgfHxcbiAgICAgICAgICAgICAgICAoIV9vcHRpb25zLnNob3VsZFVucmVnaXN0ZXIgJiYgIWlzRW1wdHlPYmplY3QodmFsdWVzKSk7XG4gICAgICAgIF9zdGF0ZS53YXRjaCA9ICEhX29wdGlvbnMuc2hvdWxkVW5yZWdpc3RlcjtcbiAgICAgICAgX3N0YXRlLmtlZXBJc1ZhbGlkID0gISFrZWVwU3RhdGVPcHRpb25zLmtlZXBJc1ZhbGlkO1xuICAgICAgICBfc3RhdGUuYWN0aW9uID0gZmFsc2U7XG4gICAgICAgIF9zdGF0ZS5hY3Rpb25BcnJheUxlbmd0aHMuY2xlYXIoKTtcbiAgICAgICAgX2RpcnR5RmllbGRzU3RhbGUgPSBmYWxzZTtcbiAgICAgICAgaWYgKCFrZWVwU3RhdGVPcHRpb25zLmtlZXBFcnJvcnMpIHtcbiAgICAgICAgICAgIF9mb3JtU3RhdGUuZXJyb3JzID0ge307XG4gICAgICAgIH1cbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgc3VibWl0Q291bnQ6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcFN1Ym1pdENvdW50XG4gICAgICAgICAgICAgICAgPyBfZm9ybVN0YXRlLnN1Ym1pdENvdW50XG4gICAgICAgICAgICAgICAgOiAwLFxuICAgICAgICAgICAgaXNEaXJ0eTogaXNFbXB0eVJlc2V0VmFsdWVzXG4gICAgICAgICAgICAgICAgPyBmYWxzZVxuICAgICAgICAgICAgICAgIDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGlydHlcbiAgICAgICAgICAgICAgICAgICAgPyBfZm9ybVN0YXRlLmlzRGlydHlcbiAgICAgICAgICAgICAgICAgICAgOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBWYWx1ZXNcbiAgICAgICAgICAgICAgICAgICAgICAgID8gX2dldERpcnR5KClcbiAgICAgICAgICAgICAgICAgICAgICAgIDogISEoa2VlcFN0YXRlT3B0aW9ucy5rZWVwRGVmYXVsdFZhbHVlcyAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvcm1WYWx1ZXMgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAhZGVlcEVxdWFsKGZvcm1WYWx1ZXMsIF9kZWZhdWx0VmFsdWVzKSksXG4gICAgICAgICAgICBpc1N1Ym1pdHRlZDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwSXNTdWJtaXR0ZWRcbiAgICAgICAgICAgICAgICA/IF9mb3JtU3RhdGUuaXNTdWJtaXR0ZWRcbiAgICAgICAgICAgICAgICA6IGZhbHNlLFxuICAgICAgICAgICAgZGlydHlGaWVsZHM6IGlzRW1wdHlSZXNldFZhbHVlc1xuICAgICAgICAgICAgICAgID8ge31cbiAgICAgICAgICAgICAgICA6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcERpcnR5VmFsdWVzXG4gICAgICAgICAgICAgICAgICAgID8ga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGVmYXVsdFZhbHVlcyAmJiBfZm9ybVZhbHVlc1xuICAgICAgICAgICAgICAgICAgICAgICAgPyBnZXREaXJ0eUZpZWxkcyhfZGVmYXVsdFZhbHVlcywgX2Zvcm1WYWx1ZXMsIHVuZGVmaW5lZCwgZmllbGRSZWZzKVxuICAgICAgICAgICAgICAgICAgICAgICAgOiBfZm9ybVN0YXRlLmRpcnR5RmllbGRzXG4gICAgICAgICAgICAgICAgICAgIDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGVmYXVsdFZhbHVlcyAmJiBmb3JtVmFsdWVzXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBmb3JtVmFsdWVzLCB1bmRlZmluZWQsIGZpZWxkUmVmcylcbiAgICAgICAgICAgICAgICAgICAgICAgIDoga2VlcFN0YXRlT3B0aW9ucy5rZWVwRGlydHlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IF9mb3JtU3RhdGUuZGlydHlGaWVsZHNcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcFZhbHVlc1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IGdldERpcnR5RmllbGRzKF9kZWZhdWx0VmFsdWVzLCBfZm9ybVZhbHVlcywgdW5kZWZpbmVkLCBmaWVsZFJlZnMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDoge30sXG4gICAgICAgICAgICB0b3VjaGVkRmllbGRzOiBrZWVwU3RhdGVPcHRpb25zLmtlZXBUb3VjaGVkXG4gICAgICAgICAgICAgICAgPyBfZm9ybVN0YXRlLnRvdWNoZWRGaWVsZHNcbiAgICAgICAgICAgICAgICA6IHt9LFxuICAgICAgICAgICAgLi4uKCFrZWVwU3RhdGVPcHRpb25zLmtlZXBJc1ZhbGlkYXRpbmcgJiZcbiAgICAgICAgICAgICAgICAoX2Zvcm1TdGF0ZS5pc1ZhbGlkYXRpbmcgfHwgIWlzRW1wdHlPYmplY3QoX2Zvcm1TdGF0ZS52YWxpZGF0aW5nRmllbGRzKSlcbiAgICAgICAgICAgICAgICA/IHsgdmFsaWRhdGluZ0ZpZWxkczoge30sIGlzVmFsaWRhdGluZzogZmFsc2UgfVxuICAgICAgICAgICAgICAgIDogbnVsbCksXG4gICAgICAgICAgICBlcnJvcnM6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcEVycm9ycyA/IF9mb3JtU3RhdGUuZXJyb3JzIDoge30sXG4gICAgICAgICAgICBpc1N1Ym1pdFN1Y2Nlc3NmdWw6IGtlZXBTdGF0ZU9wdGlvbnMua2VlcElzU3VibWl0U3VjY2Vzc2Z1bFxuICAgICAgICAgICAgICAgID8gX2Zvcm1TdGF0ZS5pc1N1Ym1pdFN1Y2Nlc3NmdWxcbiAgICAgICAgICAgICAgICA6IGZhbHNlLFxuICAgICAgICAgICAgaXNTdWJtaXR0aW5nOiBmYWxzZSxcbiAgICAgICAgICAgIGRlZmF1bHRWYWx1ZXM6IF9kZWZhdWx0VmFsdWVzLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IHJlc2V0ID0gKGZvcm1WYWx1ZXMsIGtlZXBTdGF0ZU9wdGlvbnMpID0+IF9yZXNldChpc0Z1bmN0aW9uKGZvcm1WYWx1ZXMpXG4gICAgICAgID8gZm9ybVZhbHVlcyhfZm9ybVZhbHVlcylcbiAgICAgICAgOiBmb3JtVmFsdWVzLCB7IC4uLl9vcHRpb25zLnJlc2V0T3B0aW9ucywgLi4ua2VlcFN0YXRlT3B0aW9ucyB9KTtcbiAgICBjb25zdCBzZXRGb2N1cyA9IChuYW1lLCBvcHRpb25zID0ge30pID0+IHtcbiAgICAgICAgY29uc3QgZmllbGQgPSBnZXQoX2ZpZWxkcywgbmFtZSk7XG4gICAgICAgIGNvbnN0IGZpZWxkUmVmZXJlbmNlID0gZmllbGQgJiYgZmllbGQuX2Y7XG4gICAgICAgIGlmIChmaWVsZFJlZmVyZW5jZSkge1xuICAgICAgICAgICAgY29uc3QgZmllbGRSZWYgPSBmaWVsZFJlZmVyZW5jZS5yZWZzXG4gICAgICAgICAgICAgICAgPyBmaWVsZFJlZmVyZW5jZS5yZWZzWzBdXG4gICAgICAgICAgICAgICAgOiBmaWVsZFJlZmVyZW5jZS5yZWY7XG4gICAgICAgICAgICBpZiAoZmllbGRSZWYuZm9jdXMpIHtcbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgZmllbGRSZWYuZm9jdXMoKTtcbiAgICAgICAgICAgICAgICAgICAgb3B0aW9ucy5zaG91bGRTZWxlY3QgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzRnVuY3Rpb24oZmllbGRSZWYuc2VsZWN0KSAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgZmllbGRSZWYuc2VsZWN0KCk7XG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IF9zZXRGb3JtU3RhdGUgPSAodXBkYXRlZEZvcm1TdGF0ZSkgPT4ge1xuICAgICAgICAvLyBgbmFtZWAsIGB0eXBlYCwgYW5kIGB2YWx1ZXNgIGRlc2NyaWJlIHRoZSBldmVudCB0aGF0IHByb2R1Y2VkIHRoaXNcbiAgICAgICAgLy8gdXBkYXRlLCBub3QgdGhlIGZvcm0ncyBwZXJzaXN0ZWQgc3RhdGUgKHRoZXkgYXJlbid0IHBhcnQgb2ZcbiAgICAgICAgLy8gYEZvcm1TdGF0ZWApLiBNZXJnaW5nIHRoZW0gaW4gd291bGQgbGVhayBhIHN0YWxlIGBuYW1lYC9gdHlwZWAgZnJvbVxuICAgICAgICAvLyBvbmUgZXZlbnQgaW50byBhIGxhdGVyLCB1bnJlbGF0ZWQgbm90aWZpY2F0aW9uIHRoYXQgZG9lc24ndCBzcGVjaWZ5XG4gICAgICAgIC8vIGl0cyBvd24uXG4gICAgICAgIGNvbnN0IHsgbmFtZSwgdHlwZSwgdmFsdWVzLCAuLi5mb3JtU3RhdGUgfSA9IHVwZGF0ZWRGb3JtU3RhdGU7XG4gICAgICAgIGlmIChPYmplY3Qua2V5cyhmb3JtU3RhdGUpLmxlbmd0aCkge1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZSA9IHtcbiAgICAgICAgICAgICAgICAuLi5fZm9ybVN0YXRlLFxuICAgICAgICAgICAgICAgIC4uLmZvcm1TdGF0ZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICB9O1xuICAgIF9zdWJqZWN0cy5zdGF0ZS5zdWJzY3JpYmUoeyBuZXh0OiBfc2V0Rm9ybVN0YXRlIH0pO1xuICAgIGNvbnN0IF9yZXNldERlZmF1bHRWYWx1ZXMgPSAoKSA9PiBpc0Z1bmN0aW9uKF9vcHRpb25zLmRlZmF1bHRWYWx1ZXMpICYmXG4gICAgICAgIF9vcHRpb25zLmRlZmF1bHRWYWx1ZXMoKS50aGVuKCh2YWx1ZXMpID0+IHtcbiAgICAgICAgICAgIHJlc2V0KHZhbHVlcywgX29wdGlvbnMucmVzZXRPcHRpb25zKTtcbiAgICAgICAgICAgIF9zdWJqZWN0cy5zdGF0ZS5uZXh0KHtcbiAgICAgICAgICAgICAgICBpc0xvYWRpbmc6IGZhbHNlLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIGNvbnN0IHJlc2V0RGVmYXVsdFZhbHVlcyA9ICh2YWx1ZXMsIG9wdGlvbnMgPSB7fSkgPT4ge1xuICAgICAgICBfZGVmYXVsdFZhbHVlcyA9IGNsb25lT2JqZWN0KHZhbHVlcyk7XG4gICAgICAgIGlmICghb3B0aW9ucy5rZWVwRGlydHkpIHtcbiAgICAgICAgICAgIGNvbnN0IG5ld0RpcnR5RmllbGRzID0gZ2V0RGlydHlGaWVsZHMoX2RlZmF1bHRWYWx1ZXMsIF9mb3JtVmFsdWVzLCB1bmRlZmluZWQsIF9maWVsZHMpO1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5kaXJ0eUZpZWxkcyA9IG5ld0RpcnR5RmllbGRzO1xuICAgICAgICAgICAgX2Zvcm1TdGF0ZS5pc0RpcnR5ID0gIWlzRW1wdHlPYmplY3QobmV3RGlydHlGaWVsZHMpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghb3B0aW9ucy5rZWVwSXNWYWxpZCkge1xuICAgICAgICAgICAgX3NldFZhbGlkKCk7XG4gICAgICAgIH1cbiAgICAgICAgX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgLi4uX2Zvcm1TdGF0ZSxcbiAgICAgICAgICAgIGRlZmF1bHRWYWx1ZXM6IF9kZWZhdWx0VmFsdWVzLFxuICAgICAgICB9KTtcbiAgICB9O1xuICAgIGNvbnN0IG1ldGhvZHMgPSB7XG4gICAgICAgIGNvbnRyb2w6IHtcbiAgICAgICAgICAgIHJlZ2lzdGVyLFxuICAgICAgICAgICAgdW5yZWdpc3RlcixcbiAgICAgICAgICAgIGdldEZpZWxkU3RhdGUsXG4gICAgICAgICAgICBoYW5kbGVTdWJtaXQsXG4gICAgICAgICAgICBzZXRFcnJvcixcbiAgICAgICAgICAgIF9zdWJzY3JpYmUsXG4gICAgICAgICAgICBfcnVuU2NoZW1hLFxuICAgICAgICAgICAgX3VwZGF0ZUlzVmFsaWRhdGluZyxcbiAgICAgICAgICAgIF9mb2N1c0Vycm9yLFxuICAgICAgICAgICAgX2dldFdhdGNoLFxuICAgICAgICAgICAgX2dldERpcnR5LFxuICAgICAgICAgICAgX3NldFZhbGlkLFxuICAgICAgICAgICAgX3NldEZpZWxkQXJyYXksXG4gICAgICAgICAgICBfc2V0RGlzYWJsZWRGaWVsZCxcbiAgICAgICAgICAgIF9zZXRFcnJvcnMsXG4gICAgICAgICAgICBfZ2V0RmllbGRBcnJheSxcbiAgICAgICAgICAgIF9yZXNldCxcbiAgICAgICAgICAgIF9yZXNldERlZmF1bHRWYWx1ZXMsXG4gICAgICAgICAgICBfcmVtb3ZlVW5tb3VudGVkLFxuICAgICAgICAgICAgX2Rpc2FibGVGb3JtLFxuICAgICAgICAgICAgX3N1YmplY3RzLFxuICAgICAgICAgICAgX3Byb3h5Rm9ybVN0YXRlLFxuICAgICAgICAgICAgZ2V0IF9maWVsZHMoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9maWVsZHM7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ2V0IF9mb3JtVmFsdWVzKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBfZm9ybVZhbHVlcztcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnZXQgX3N0YXRlKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBfc3RhdGU7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgc2V0IF9zdGF0ZSh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIF9zdGF0ZSA9IHZhbHVlO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGdldCBfZGVmYXVsdFZhbHVlcygpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX2RlZmF1bHRWYWx1ZXM7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZ2V0IF9uYW1lcygpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX25hbWVzO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNldCBfbmFtZXModmFsdWUpIHtcbiAgICAgICAgICAgICAgICBfbmFtZXMgPSB2YWx1ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnZXQgX2Zvcm1TdGF0ZSgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX2Zvcm1TdGF0ZTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBnZXQgX29wdGlvbnMoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9vcHRpb25zO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNldCBfb3B0aW9ucyh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIF9vcHRpb25zID0ge1xuICAgICAgICAgICAgICAgICAgICAuLi5fb3B0aW9ucyxcbiAgICAgICAgICAgICAgICAgICAgLi4udmFsdWUsXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICBfdmFsaWRhdGlvbk1vZGVCZWZvcmVTdWJtaXQgPSBnZXRWYWxpZGF0aW9uTW9kZXMoX29wdGlvbnMubW9kZSk7XG4gICAgICAgICAgICAgICAgX3ZhbGlkYXRpb25Nb2RlQWZ0ZXJTdWJtaXQgPSBnZXRWYWxpZGF0aW9uTW9kZXMoX29wdGlvbnMucmVWYWxpZGF0ZU1vZGUpO1xuICAgICAgICAgICAgICAgIHNob3VsZERpc3BsYXlBbGxBc3NvY2lhdGVkRXJyb3JzID1cbiAgICAgICAgICAgICAgICAgICAgX29wdGlvbnMuY3JpdGVyaWFNb2RlID09PSBWQUxJREFUSU9OX01PREUuYWxsO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgc3Vic2NyaWJlLFxuICAgICAgICB0cmlnZ2VyLFxuICAgICAgICByZWdpc3RlcixcbiAgICAgICAgaGFuZGxlU3VibWl0LFxuICAgICAgICB3YXRjaCxcbiAgICAgICAgc2V0VmFsdWUsXG4gICAgICAgIHNldFZhbHVlcyxcbiAgICAgICAgZ2V0VmFsdWVzLFxuICAgICAgICBnZXRFcnJvcnMsXG4gICAgICAgIHJlc2V0LFxuICAgICAgICByZXNldEZpZWxkLFxuICAgICAgICByZXNldERlZmF1bHRWYWx1ZXMsXG4gICAgICAgIGNsZWFyRXJyb3JzLFxuICAgICAgICB1bnJlZ2lzdGVyLFxuICAgICAgICBzZXRFcnJvcixcbiAgICAgICAgc2V0Rm9jdXMsXG4gICAgICAgIGdldEZpZWxkU3RhdGUsXG4gICAgfTtcbiAgICByZXR1cm4ge1xuICAgICAgICAuLi5tZXRob2RzLFxuICAgICAgICBmb3JtQ29udHJvbDogbWV0aG9kcyxcbiAgICB9O1xufVxuXG5jb25zdCBSRVNFVF9PUFRJT05TID0ge1xuICAgIG1vZGU6IGRlZmF1bHRPcHRpb25zLm1vZGUsXG4gICAgcmVWYWxpZGF0ZU1vZGU6IGRlZmF1bHRPcHRpb25zLnJlVmFsaWRhdGVNb2RlLFxuICAgIHNob3VsZEZvY3VzRXJyb3I6IGRlZmF1bHRPcHRpb25zLnNob3VsZEZvY3VzRXJyb3IsXG4gICAgcmVzb2x2ZXI6IHVuZGVmaW5lZCxcbiAgICBjcml0ZXJpYU1vZGU6IHVuZGVmaW5lZCxcbiAgICBkZWxheUVycm9yOiB1bmRlZmluZWQsXG4gICAgc2hvdWxkVW5yZWdpc3RlcjogdW5kZWZpbmVkLFxuICAgIHNob3VsZFVzZU5hdGl2ZVZhbGlkYXRpb246IHVuZGVmaW5lZCxcbiAgICBjb250ZXh0OiB1bmRlZmluZWQsXG59O1xuLyoqXG4gKiBDb3JlIGhvb2sgZm9yIG1hbmFnaW5nIGEgZm9ybS4gUmV0dXJucyBhbGwgbWV0aG9kcyBhbmQgc3RhdGUgZm9yXG4gKiByZWdpc3RyYXRpb24sIHZhbGlkYXRpb24sIGFuZCBzdWJtaXNzaW9uLlxuICpcbiAqIEBzZWUgW0FQSV0oaHR0cHM6Ly9yZWFjdC1ob29rLWZvcm0uY29tL2RvY3MvdXNlZm9ybSlcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiBjb25zdCB7IHJlZ2lzdGVyLCBoYW5kbGVTdWJtaXQsIGZvcm1TdGF0ZTogeyBlcnJvcnMgfSB9ID0gdXNlRm9ybTxGb3JtVmFsdWVzPigpO1xuICogPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdChvblN1Ym1pdCl9PlxuICogICA8aW5wdXQgey4uLnJlZ2lzdGVyKFwiZW1haWxcIiwgeyByZXF1aXJlZDogdHJ1ZSB9KX0gLz5cbiAqIDwvZm9ybT5cbiAqIGBgYFxuICovXG5mdW5jdGlvbiB1c2VGb3JtKHByb3BzID0ge30pIHtcbiAgICBjb25zdCBfZm9ybUNvbnRyb2wgPSBSZWFjdC51c2VSZWYodW5kZWZpbmVkKTtcbiAgICBjb25zdCBfdmFsdWVzID0gUmVhY3QudXNlUmVmKHVuZGVmaW5lZCk7XG4gICAgY29uc3QgX2Zvcm1Db250cm9sUHJvcCA9IFJlYWN0LnVzZVJlZihwcm9wcy5mb3JtQ29udHJvbCk7XG4gICAgY29uc3QgX2hhZFZhbGlkYXRlID0gUmVhY3QudXNlUmVmKCEhcHJvcHMudmFsaWRhdGUpO1xuICAgIGNvbnN0IFtmb3JtU3RhdGUsIHVwZGF0ZUZvcm1TdGF0ZV0gPSBSZWFjdC51c2VTdGF0ZSgoKSA9PiAoe1xuICAgICAgICAuLi5jbG9uZU9iamVjdChERUZBVUxUX0ZPUk1fU1RBVEUpLFxuICAgICAgICBpc0xvYWRpbmc6IGlzRnVuY3Rpb24ocHJvcHMuZGVmYXVsdFZhbHVlcyksXG4gICAgICAgIGVycm9yczogcHJvcHMuZXJyb3JzIHx8IHt9LFxuICAgICAgICBkaXNhYmxlZDogcHJvcHMuZGlzYWJsZWQgfHwgZmFsc2UsXG4gICAgICAgIGRlZmF1bHRWYWx1ZXM6IGlzRnVuY3Rpb24ocHJvcHMuZGVmYXVsdFZhbHVlcylcbiAgICAgICAgICAgID8gdW5kZWZpbmVkXG4gICAgICAgICAgICA6IHByb3BzLmRlZmF1bHRWYWx1ZXMsXG4gICAgfSkpO1xuICAgIGlmICghX2Zvcm1Db250cm9sLmN1cnJlbnQgfHxcbiAgICAgICAgKHByb3BzLmZvcm1Db250cm9sICYmIF9mb3JtQ29udHJvbFByb3AuY3VycmVudCAhPT0gcHJvcHMuZm9ybUNvbnRyb2wpKSB7XG4gICAgICAgIF9mb3JtQ29udHJvbFByb3AuY3VycmVudCA9IHByb3BzLmZvcm1Db250cm9sO1xuICAgICAgICBpZiAocHJvcHMuZm9ybUNvbnRyb2wpIHtcbiAgICAgICAgICAgIF9mb3JtQ29udHJvbC5jdXJyZW50ID0ge1xuICAgICAgICAgICAgICAgIC4uLnByb3BzLmZvcm1Db250cm9sLFxuICAgICAgICAgICAgICAgIGZvcm1TdGF0ZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBpZiAocHJvcHMuZGVmYXVsdFZhbHVlcyAmJiAhaXNGdW5jdGlvbihwcm9wcy5kZWZhdWx0VmFsdWVzKSkge1xuICAgICAgICAgICAgICAgIHByb3BzLmZvcm1Db250cm9sLnJlc2V0KHByb3BzLmRlZmF1bHRWYWx1ZXMsIHByb3BzLnJlc2V0T3B0aW9ucyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjb25zdCB7IGZvcm1Db250cm9sLCAuLi5yZXN0IH0gPSBjcmVhdGVGb3JtQ29udHJvbChwcm9wcyk7XG4gICAgICAgICAgICBfZm9ybUNvbnRyb2wuY3VycmVudCA9IHtcbiAgICAgICAgICAgICAgICAuLi5yZXN0LFxuICAgICAgICAgICAgICAgIGZvcm1TdGF0ZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgY29udHJvbCA9IF9mb3JtQ29udHJvbC5jdXJyZW50LmNvbnRyb2w7XG4gICAgY29uc3QgcHJldmlvdXNPcHRpb25zID0gY29udHJvbC5fb3B0aW9ucztcbiAgICBjb25zdCByZW1vdmVkT3B0aW9ucyA9IHt9O1xuICAgIGZvciAoY29uc3Qga2V5IGluIFJFU0VUX09QVElPTlMpIHtcbiAgICAgICAgaWYgKGtleSBpbiBwcmV2aW91c09wdGlvbnMgJiYgIShrZXkgaW4gcHJvcHMpKSB7XG4gICAgICAgICAgICByZW1vdmVkT3B0aW9uc1trZXldID0gUkVTRVRfT1BUSU9OU1trZXldO1xuICAgICAgICB9XG4gICAgfVxuICAgIGNvbnRyb2wuX29wdGlvbnMgPSB7XG4gICAgICAgIC4uLnJlbW92ZWRPcHRpb25zLFxuICAgICAgICAuLi5wcm9wcyxcbiAgICAgICAgdmFsaWRhdGU6IHByb3BzLnZhbGlkYXRlLFxuICAgIH07XG4gICAgY29uc3QgZ2V0Q3VycmVudEZvcm1TdGF0ZSA9ICgpID0+ICh7XG4gICAgICAgIC4uLmNvbnRyb2wuX2Zvcm1TdGF0ZSxcbiAgICAgICAgZGVmYXVsdFZhbHVlczogY29udHJvbC5fZGVmYXVsdFZhbHVlcyxcbiAgICB9KTtcbiAgICBjb25zdCB7IHJlc3luY0lmTmVlZGVkLCBzbmFwc2hvdCB9ID0gdXNlUmVzeW5jT25SZWNvbm5lY3QoZ2V0Q3VycmVudEZvcm1TdGF0ZSk7XG4gICAgdXNlSXNvbW9ycGhpY0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHJlc3luY0lmTmVlZGVkKHRydWUsIGdldEN1cnJlbnRGb3JtU3RhdGUsIHVwZGF0ZUZvcm1TdGF0ZSk7XG4gICAgICAgIGNvbnN0IHVuc3Vic2NyaWJlID0gY29udHJvbC5fc3Vic2NyaWJlKHtcbiAgICAgICAgICAgIGZvcm1TdGF0ZTogY29udHJvbC5fcHJveHlGb3JtU3RhdGUsXG4gICAgICAgICAgICBjYWxsYmFjazogKCkgPT4gdXBkYXRlRm9ybVN0YXRlKHtcbiAgICAgICAgICAgICAgICAuLi5jb250cm9sLl9mb3JtU3RhdGUsXG4gICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlczogY29udHJvbC5fZGVmYXVsdFZhbHVlcyxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICAgcmVSZW5kZXJSb290OiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgdXBkYXRlRm9ybVN0YXRlKChkYXRhKSA9PiAoe1xuICAgICAgICAgICAgLi4uZGF0YSxcbiAgICAgICAgICAgIGlzUmVhZHk6IHRydWUsXG4gICAgICAgIH0pKTtcbiAgICAgICAgY29udHJvbC5fZm9ybVN0YXRlLmlzUmVhZHkgPSB0cnVlO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIHNuYXBzaG90KHRydWUsIGdldEN1cnJlbnRGb3JtU3RhdGUpO1xuICAgICAgICB9O1xuICAgIH0sIFtjb250cm9sLCByZXN5bmNJZk5lZWRlZCwgc25hcHNob3RdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4gY29udHJvbC5fZGlzYWJsZUZvcm0ocHJvcHMuZGlzYWJsZWQpLCBbY29udHJvbCwgcHJvcHMuZGlzYWJsZWRdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAocHJvcHMubW9kZSkge1xuICAgICAgICAgICAgY29udHJvbC5fb3B0aW9ucy5tb2RlID0gcHJvcHMubW9kZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAocHJvcHMucmVWYWxpZGF0ZU1vZGUpIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX29wdGlvbnMucmVWYWxpZGF0ZU1vZGUgPSBwcm9wcy5yZVZhbGlkYXRlTW9kZTtcbiAgICAgICAgfVxuICAgIH0sIFtjb250cm9sLCBwcm9wcy5tb2RlLCBwcm9wcy5yZVZhbGlkYXRlTW9kZV0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChwcm9wcy5lcnJvcnMpIHtcbiAgICAgICAgICAgIGNvbnRyb2wuX3NldEVycm9ycyhwcm9wcy5lcnJvcnMpO1xuICAgICAgICAgICAgY29udHJvbC5fZm9jdXNFcnJvcigpO1xuICAgICAgICB9XG4gICAgfSwgW2NvbnRyb2wsIHByb3BzLmVycm9yc10pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIGlmIChfaGFkVmFsaWRhdGUuY3VycmVudCAmJiAhcHJvcHMudmFsaWRhdGUpIHtcbiAgICAgICAgICAgIF9mb3JtQ29udHJvbC5jdXJyZW50ICYmIF9mb3JtQ29udHJvbC5jdXJyZW50LmNsZWFyRXJyb3JzKEZPUk1fRVJST1JfVFlQRSk7XG4gICAgICAgIH1cbiAgICAgICAgX2hhZFZhbGlkYXRlLmN1cnJlbnQgPSAhIXByb3BzLnZhbGlkYXRlO1xuICAgIH0sIFtwcm9wcy52YWxpZGF0ZV0pO1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICAgIHByb3BzLnNob3VsZFVucmVnaXN0ZXIgJiZcbiAgICAgICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoe1xuICAgICAgICAgICAgICAgIHZhbHVlczogY29udHJvbC5fZ2V0V2F0Y2goKSxcbiAgICAgICAgICAgIH0pO1xuICAgIH0sIFtjb250cm9sLCBwcm9wcy5zaG91bGRVbnJlZ2lzdGVyXSk7XG4gICAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICAgICAgaWYgKGNvbnRyb2wuX3Byb3h5Rm9ybVN0YXRlLmlzRGlydHkpIHtcbiAgICAgICAgICAgIGNvbnN0IGlzRGlydHkgPSBjb250cm9sLl9nZXREaXJ0eSgpO1xuICAgICAgICAgICAgaWYgKGlzRGlydHkgIT09IGZvcm1TdGF0ZS5pc0RpcnR5KSB7XG4gICAgICAgICAgICAgICAgY29udHJvbC5fc3ViamVjdHMuc3RhdGUubmV4dCh7XG4gICAgICAgICAgICAgICAgICAgIGlzRGlydHksXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LCBbY29udHJvbCwgZm9ybVN0YXRlLmlzRGlydHldKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAocHJvcHMudmFsdWVzICYmICFkZWVwRXF1YWwocHJvcHMudmFsdWVzLCBfdmFsdWVzLmN1cnJlbnQpKSB7XG4gICAgICAgICAgICBjb250cm9sLl9yZXNldChwcm9wcy52YWx1ZXMsIHtcbiAgICAgICAgICAgICAgICBrZWVwRmllbGRzUmVmOiB0cnVlLFxuICAgICAgICAgICAgICAgIC4uLmNvbnRyb2wuX29wdGlvbnMucmVzZXRPcHRpb25zLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBpZiAoIShjb250cm9sLl9vcHRpb25zLnJlc2V0T3B0aW9ucyAmJlxuICAgICAgICAgICAgICAgIGNvbnRyb2wuX29wdGlvbnMucmVzZXRPcHRpb25zLmtlZXBJc1ZhbGlkKSkge1xuICAgICAgICAgICAgICAgIGNvbnRyb2wuX3NldFZhbGlkKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBfdmFsdWVzLmN1cnJlbnQgPSBwcm9wcy52YWx1ZXM7XG4gICAgICAgICAgICB1cGRhdGVGb3JtU3RhdGUoKHN0YXRlKSA9PiAoeyAuLi5zdGF0ZSB9KSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBjb250cm9sLl9yZXNldERlZmF1bHRWYWx1ZXMoKTtcbiAgICAgICAgfVxuICAgIH0sIFtjb250cm9sLCBwcm9wcy52YWx1ZXNdKTtcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgICBpZiAoIWNvbnRyb2wuX3N0YXRlLm1vdW50KSB7XG4gICAgICAgICAgICBjb250cm9sLl9zZXRWYWxpZCgpO1xuICAgICAgICAgICAgY29udHJvbC5fc3RhdGUubW91bnQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjb250cm9sLl9zdGF0ZS53YXRjaCkge1xuICAgICAgICAgICAgY29udHJvbC5fc3RhdGUud2F0Y2ggPSBmYWxzZTtcbiAgICAgICAgICAgIGNvbnRyb2wuX3N1YmplY3RzLnN0YXRlLm5leHQoeyAuLi5jb250cm9sLl9mb3JtU3RhdGUgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29udHJvbC5fcmVtb3ZlVW5tb3VudGVkKCk7XG4gICAgfSk7XG4gICAgX2Zvcm1Db250cm9sLmN1cnJlbnQuZm9ybVN0YXRlID0gUmVhY3QudXNlTWVtbygoKSA9PiBnZXRQcm94eUZvcm1TdGF0ZShmb3JtU3RhdGUsIGNvbnRyb2wpLCBbY29udHJvbCwgZm9ybVN0YXRlXSk7XG4gICAgcmV0dXJuIF9mb3JtQ29udHJvbC5jdXJyZW50O1xufVxuXG4vKipcbiAqIENvbXBvbmVudCB3cmFwcGVyIGFyb3VuZCBgdXNlV2F0Y2hgLiBSZS1yZW5kZXJzIG9ubHkgd2hlbiB3YXRjaGVkIGZpZWxkcyBjaGFuZ2UuXG4gKlxuICogQHNlZSBbQVBJXShodHRwczovL3JlYWN0LWhvb2stZm9ybS5jb20vZG9jcy91c2V3YXRjaClcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiA8V2F0Y2hcbiAqICAgY29udHJvbD17Y29udHJvbH1cbiAqICAgbmFtZXM9e1tcImZvb1wiLCBcImJhclwiXX1cbiAqICAgcmVuZGVyPXsoW2ZvbywgYmFyXSkgPT4gPHNwYW4+e2Zvb30ge2Jhcn08L3NwYW4+fVxuICogLz5cbiAqIGBgYFxuICovXG5jb25zdCBXYXRjaCA9IChwcm9wcykgPT4gcHJvcHMucmVuZGVyKHVzZVdhdGNoKHsgbmFtZTogcHJvcHMubmFtZXMsIC4uLnByb3BzIH0pKTtcblxuZXhwb3J0IHsgQ29udHJvbGxlciwgRXJyb3JNZXNzYWdlLCBGaWVsZEFycmF5LCBGb3JtLCBGb3JtUHJvdmlkZXIsIEZvcm1TdGF0ZSwgRm9ybVN0YXRlU3Vic2NyaWJlLCBXYXRjaCwgYXBwZW5kRXJyb3JzLCBjcmVhdGVGb3JtQ29udHJvbCwgZ2V0LCBzZXQsIHVzZUNvbnRyb2xsZXIsIHVzZUZpZWxkQXJyYXksIHVzZUZvcm0sIHVzZUZvcm1Db250ZXh0LCB1c2VGb3JtU3RhdGUsIHVzZVdhdGNoIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5lc20ubWpzLm1hcFxuIl0sIm1hcHBpbmdzIjoiOzs7O0FBRUEsSUFBSSxtQkFBbUIsWUFBWSxRQUFRLFNBQVM7QUFFcEQsSUFBSSxlQUFlLFlBQVksUUFBUSxTQUFTO0FBRWhELElBQUksZ0JBQWdCLFVBQVUsaUJBQWlCO0FBRS9DLElBQUkscUJBQXFCLFVBQVUsU0FBUztBQUU1QyxJQUFNLGdCQUFnQixVQUFVLE9BQU8sVUFBVTtBQUNqRCxJQUFJLFlBQVksVUFBVSxDQUFDLGtCQUFrQixLQUFLLEtBQzlDLENBQUMsTUFBTSxRQUFRLEtBQUssS0FDcEIsYUFBYSxLQUFLLEtBQ2xCLENBQUMsYUFBYSxLQUFLO0FBRXZCLElBQUksaUJBQWlCLFVBQVUsU0FBUyxLQUFLLEtBQUssTUFBTSxTQUNsRCxnQkFBZ0IsTUFBTSxNQUFNLElBQ3hCLE1BQU0sT0FBTyxVQUNiLFlBQVksTUFBTSxNQUFNLElBQ3BCLE1BQU0sT0FBTyxRQUNiLE1BQU0sT0FBTyxRQUNyQjtBQUVOLElBQU0sZ0JBQWdCO0FBQ3RCLElBQUksZ0JBQWdCLFVBQVUsTUFBTSxNQUFNLGFBQWEsQ0FBQyxDQUFDLE9BQU8sT0FBTztBQUV2RSxTQUFTLHFCQUFxQixTQUFTLE1BQU07Q0FDekMsTUFBTSxXQUFXLGFBQWEsSUFBSTtDQUNsQyxJQUFJLGFBQWEsUUFBUTtDQUN6QixJQUFJLGdCQUFnQixRQUFRO0NBQzVCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFNBQVMsR0FBRyxLQUFLO0VBQzFDLE1BQU0sTUFBTSxTQUFTO0VBQ3JCLGFBQWEsY0FBYyxPQUFPLGFBQWEsV0FBVztFQUMxRCxnQkFBZ0IsaUJBQWlCLE9BQU8sZ0JBQWdCLGNBQWM7RUFDdEUsSUFBSSxlQUFlLFFBQVEsa0JBQWtCLE1BQ3pDLE9BQU87Q0FFZjtBQUVKO0FBRUEsSUFBSSxzQkFBc0IsT0FBTyxTQUFTLEtBQ3JDLE1BQU0sR0FBRyxDQUFDLENBQ1YsTUFBTSxNQUFNLE9BQU8sUUFBUSxDQUFDLE1BQU0sT0FBTyxJQUFJLENBQUMsS0FBSyxNQUFNLElBQUksSUFBSSxNQUFNLEdBQUcsS0FBSyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQztBQUVoRyxJQUFJLFFBQVEsT0FBTyxXQUFXLGVBQzFCLE9BQU8sT0FBTyxnQkFBZ0IsZUFDOUIsT0FBTyxhQUFhO0FBRXhCLFNBQVMsWUFBWSxNQUFNO0NBQ3ZCLElBQUksU0FBUyxRQUFRLE9BQU8sU0FBUyxVQUNqQyxPQUFPO0NBRVgsSUFBSSxnQkFBZ0IsTUFDaEIsT0FBTyxJQUFJLEtBQUssSUFBSTtDQUV4QixNQUFNLGlCQUFpQixPQUFPLFNBQVMsZUFBZSxnQkFBZ0I7Q0FDdEUsTUFBTSxxQkFBcUIsT0FBTyxhQUFhLGVBQWUsZ0JBQWdCO0NBQzlFLElBQUksVUFBVSxrQkFBa0IscUJBQzVCLE9BQU87Q0FFWCxNQUFNLFVBQVUsTUFBTSxRQUFRLElBQUk7Q0FDbEMsTUFBTSxZQUFZLE9BQU8sZUFBZSxJQUFJO0NBQzVDLElBQUksQ0FBQyxXQUFXLGFBQWEsS0FBSyxnQkFBZ0IsUUFDOUMsT0FBTztDQUVYLE1BQU0sT0FBTyxVQUFVLElBQUksTUFBTSxLQUFLLE1BQU0sSUFBSSxPQUFPLE9BQU8sU0FBUztDQUN2RSxLQUFLLE1BQU0sT0FBTyxNQUNkLElBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxNQUFNLEdBQUcsR0FDOUMsS0FBSyxPQUFPLFlBQVksS0FBSyxJQUFJO0NBR3pDLE9BQU87QUFDWDtBQUVBLElBQU0sU0FBUztDQUNYLE1BQU07Q0FDTixXQUFXO0NBQ1gsUUFBUTtDQUNSLFFBQVE7Q0FDUixTQUFTO0NBQ1QsT0FBTztBQUNYO0FBQ0EsSUFBTSxrQkFBa0I7Q0FDcEIsUUFBUTtDQUNSLFVBQVU7Q0FDVixVQUFVO0NBQ1YsV0FBVztDQUNYLEtBQUs7QUFDVDtBQUNBLElBQU0seUJBQXlCO0NBQzNCLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsV0FBVztDQUNYLFdBQVc7Q0FDWCxTQUFTO0NBQ1QsVUFBVTtDQUNWLFVBQVU7QUFDZDtBQUNBLElBQU0sNEJBQTRCO0NBQzlCLHVCQUF1QjtDQUN2Qix1QkFBdUI7Q0FDdkIsdUJBQXVCO0NBQ3ZCLHVCQUF1QjtDQUN2Qix1QkFBdUI7Q0FDdkIsdUJBQXVCO0NBQ3ZCLHVCQUF1QjtBQUMzQjtBQUNBLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0sa0JBQWtCO0FBQ3hCLElBQU0scUJBQXFCO0NBQUM7Q0FBYTtDQUFlO0FBQVc7QUFFbkUsSUFBTSxZQUFZO0FBQ2xCLElBQUksU0FBUyxVQUFVLFVBQVUsS0FBSyxLQUFLO0FBRTNDLElBQUksZUFBZSxRQUFRLFFBQVEsS0FBQTtBQUVuQyxJQUFJLE9BQU8sUUFBUSxNQUFNLGlCQUFpQjtDQUN0QyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsTUFBTSxHQUN6QixPQUFPO0NBRVgsTUFBTSxRQUFRLE1BQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLGFBQWEsSUFBSTtDQUN0RCxJQUFJLE1BQU0sTUFBTSxRQUFRLG1CQUFtQixTQUFTLEdBQUcsQ0FBQyxHQUNwRCxPQUFPO0NBRVgsTUFBTSxTQUFTLE1BQU0sUUFBUSxRQUFRLFFBQVE7RUFDekMsT0FBTyxrQkFBa0IsTUFBTSxJQUFJLEtBQUEsSUFBWSxPQUFPO0NBQzFELEdBQUcsTUFBTTtDQUNULE9BQU8sWUFBWSxNQUFNLEtBQUssV0FBVyxTQUNuQyxZQUFZLE9BQU8sS0FBSyxJQUNwQixlQUNBLE9BQU8sUUFDWDtBQUNWO0FBRUEsSUFBSSxhQUFhLFVBQVUsT0FBTyxVQUFVO0FBRTVDLElBQUksY0FBYyxVQUFVLE9BQU8sVUFBVTtBQUU3QyxJQUFJLE9BQU8sUUFBUSxNQUFNLFVBQVU7Q0FDL0IsSUFBSSxRQUFRO0NBQ1osTUFBTSxXQUFXLE1BQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLGFBQWEsSUFBSTtDQUN6RCxNQUFNLFNBQVMsU0FBUztDQUN4QixNQUFNLFlBQVksU0FBUztDQUMzQixPQUFPLEVBQUUsUUFBUSxRQUFRO0VBQ3JCLE1BQU0sTUFBTSxTQUFTO0VBQ3JCLElBQUksV0FBVztFQUNmLElBQUksVUFBVSxXQUFXO0dBQ3JCLE1BQU0sV0FBVyxPQUFPO0dBQ3hCLFdBQ0ksU0FBUyxRQUFRLEtBQUssTUFBTSxRQUFRLFFBQVEsSUFDdEMsV0FDQSxDQUFDLE1BQU0sQ0FBQyxTQUFTLFFBQVEsRUFBRSxJQUN2QixDQUFDLElBQ0QsQ0FBQztFQUNuQjtFQUNBLElBQUksbUJBQW1CLFNBQVMsR0FBRyxHQUMvQjtFQUVKLE9BQU8sT0FBTztFQUNkLFNBQVMsT0FBTztDQUNwQjtBQUNKOzs7OztBQU1BLElBQU0seUJBQUEsYUFBK0IsY0FBYyxJQUFJO0FBQ3ZELHVCQUF1QixjQUFjOzs7O0FBSXJDLElBQU0sOEJBQUEsYUFBb0MsV0FBVyxzQkFBc0I7QUFFM0UsSUFBSSxxQkFBcUIsV0FBVyxTQUFTLHFCQUFxQixTQUFTLFNBQVM7Q0FDaEYsTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxNQUFNLE9BQU8sV0FDZCxPQUFPLGVBQWUsUUFBUSxLQUFLLEVBQy9CLFdBQVc7RUFDUCxNQUFNLE9BQU87RUFDYixJQUFJLFFBQVEsZ0JBQWdCLFVBQVUsZ0JBQWdCLEtBQ2xELFFBQVEsZ0JBQWdCLFFBQVEsQ0FBQyxVQUFVLGdCQUFnQjtFQUUvRCx3QkFBd0Isb0JBQW9CLFFBQVE7RUFDcEQsT0FBTyxVQUFVO0NBQ3JCLEVBQ0osQ0FBQztDQUVMLE9BQU87QUFDWDtBQUVBLElBQU0sNEJBQTRCLFFBQUEsYUFDdEIsa0JBQUEsYUFDQTtBQUVaLElBQUksaUJBQWlCLGVBQWU7Q0FDaEMsTUFBTSxnQkFBZ0IsV0FBVyxlQUFlLFdBQVcsWUFBWTtDQUN2RSxPQUFRLFNBQVMsYUFBYSxLQUFLLGNBQWMsZUFBZSxlQUFlO0FBQ25GO0FBRUEsSUFBSSxlQUFlLFVBQVUsa0JBQWtCLEtBQUssS0FBSyxDQUFDLGFBQWEsS0FBSztBQUU1RSxJQUFNLG9DQUFvQyxRQUFRLFNBQVMsS0FBSyxXQUFXLEtBQUssQ0FBQyxNQUFNLFFBQVEsTUFBTSxLQUFLLENBQUMsY0FBYyxNQUFNO0FBQy9ILFNBQVMsVUFBVSxTQUFTLFNBQVMsZ0JBQWdCLE9BQU8sMEJBQVUsSUFBSSxRQUFRLEdBQUc7Q0FDakYsSUFBSSxZQUFZLFNBQ1osT0FBTztDQUVYLElBQUksWUFBWSxPQUFPLEtBQUssWUFBWSxPQUFPLEdBQzNDLE9BQU8sT0FBTyxHQUFHLFNBQVMsT0FBTztDQUVyQyxJQUFJLGFBQWEsT0FBTyxLQUFLLGFBQWEsT0FBTyxHQUM3QyxPQUFPLE9BQU8sR0FBRyxRQUFRLFFBQVEsR0FBRyxRQUFRLFFBQVEsQ0FBQztDQUV6RCxNQUFNLFFBQVEsT0FBTyxLQUFLLE9BQU87Q0FDakMsTUFBTSxRQUFRLE9BQU8sS0FBSyxPQUFPO0NBQ2pDLElBQUksTUFBTSxXQUFXLE1BQU0sUUFDdkIsT0FBTztDQUVYLElBQUksaUNBQWlDLFNBQVMsS0FBSyxLQUMvQyxpQ0FBaUMsU0FBUyxLQUFLLEdBQy9DLE9BQU8sT0FBTyxHQUFHLFNBQVMsT0FBTztDQUVyQyxJQUFJLENBQUMsTUFBTSxVQUFVLE1BQU0sUUFBUSxPQUFPLE1BQU0sTUFBTSxRQUFRLE9BQU8sR0FDakUsT0FBTztDQUVYLE1BQU0sZUFBZSxRQUFRLElBQUksT0FBTztDQUN4QyxJQUFJLGdCQUFnQixhQUFhLElBQUksT0FBTyxHQUN4QyxPQUFPO0NBRVgsSUFBSSxjQUNBLGFBQWEsSUFBSSxPQUFPO01BRXZCO0VBQ0QsTUFBTSxxQkFBSyxJQUFJLFFBQVE7RUFDdkIsR0FBRyxJQUFJLE9BQU87RUFDZCxRQUFRLElBQUksU0FBUyxFQUFFO0NBQzNCO0NBQ0EsS0FBSyxNQUFNLE9BQU8sT0FBTztFQUNyQixNQUFNLE9BQU8sUUFBUTtFQUNyQixJQUFJLEVBQUUsT0FBTyxVQUNULE9BQU87RUFFWCxJQUFJLENBQUMsaUJBQWlCLFFBQVEsT0FBTztHQUNqQyxNQUFNLE9BQU8sUUFBUTtHQUNyQixJQUFLLGFBQWEsSUFBSSxLQUFLLGFBQWEsSUFBSSxNQUN0QyxTQUFTLElBQUksS0FBSyxNQUFNLFFBQVEsSUFBSSxPQUNqQyxTQUFTLElBQUksS0FBSyxNQUFNLFFBQVEsSUFBSSxLQUN2QyxDQUFDLFVBQVUsTUFBTSxNQUFNLGVBQWUsT0FBTyxJQUM3QyxDQUFDLE9BQU8sR0FBRyxNQUFNLElBQUksR0FDdkIsT0FBTztFQUVmO0NBQ0o7Q0FDQSxPQUFPO0FBQ1g7QUFFQSxTQUFTLHFCQUFxQixpQkFBaUI7Q0FDM0MsTUFBTSxhQUFBLGFBQW1CLE9BQU8sS0FBSztDQUNyQyxNQUFNLGVBQUEsYUFBcUIsT0FBTyxLQUFLO0NBQ3ZDLE1BQU0sYUFBQSxhQUFtQixPQUFPLEtBQUEsQ0FBUztDQUN6QyxNQUFNLGVBQUEsYUFBcUIsT0FBTyxDQUFDO0NBQ25DLGFBQWE7Q0FDYixJQUFJLENBQUMsYUFBYSxXQUFXLGlCQUFpQjtFQUMxQyxhQUFhLFVBQVU7RUFDdkIsV0FBVyxVQUFVLFlBQVksZ0JBQWdCLENBQUM7Q0FDdEQ7Q0FpQkEsT0FBTztFQUFFLGdCQUFBLGFBaEJvQixhQUFhLFNBQVMsaUJBQWlCLGFBQWE7R0FDN0UsSUFBSSxZQUNDLFdBQVcsV0FDUCxhQUFhLFdBQVcsYUFBYSxVQUFVLElBQUs7SUFDekQsTUFBTSxlQUFlLGdCQUFnQjtJQUNyQyxJQUFJLENBQUMsVUFBVSxXQUFXLFNBQVMsWUFBWSxHQUMzQyxTQUFTLFlBQVk7R0FFN0I7R0FDQSxXQUFXLFVBQVU7RUFDekIsR0FBRyxDQUFDLENBTWtCO0VBQUcsVUFBQSxhQUxGLGFBQWEsU0FBUyxvQkFBb0I7R0FDN0QsSUFBSSxTQUNBLFdBQVcsVUFBVSxZQUFZLGdCQUFnQixDQUFDO0VBRTFELEdBQUcsQ0FBQyxDQUM0QjtDQUFFO0FBQ3RDOzs7Ozs7Ozs7Ozs7QUFhQSxTQUFTLGFBQWEsT0FBTztDQUN6QixNQUFNLGNBQWMsc0JBQXNCO0NBQzFDLE1BQU0sRUFBRSxVQUFVLGFBQWEsVUFBVSxNQUFNLFVBQVUsU0FBUyxDQUFDO0NBQ25FLE1BQU0sNkJBQTZCO0VBQy9CLEdBQUcsUUFBUTtFQUNYLGVBQWUsUUFBUTtDQUMzQjtDQUNBLE1BQU0sQ0FBQyxXQUFXLG1CQUFBLGFBQXlCLFNBQVMsbUJBQW1CO0NBQ3ZFLE1BQU0sdUJBQUEsYUFBNkIsT0FBTztFQUN0QyxTQUFTO0VBQ1QsV0FBVztFQUNYLGFBQWE7RUFDYixlQUFlO0VBQ2Ysa0JBQWtCO0VBQ2xCLGNBQWM7RUFDZCxTQUFTO0VBQ1QsUUFBUTtDQUNaLENBQUM7Q0FDRCxNQUFNLEVBQUUsZ0JBQWdCLGFBQWEscUJBQXFCLG1CQUFtQjtDQUM3RSxnQ0FBZ0M7RUFDNUIsZUFBZSxDQUFDLFVBQVUscUJBQXFCLGVBQWU7RUFDOUQsTUFBTSxjQUFjLFFBQVEsV0FBVztHQUNuQztHQUNBLFdBQVcscUJBQXFCO0dBQ2hDO0dBQ0EsV0FBVyxjQUFjO0lBQ3JCLENBQUMsWUFDRyxnQkFBZ0I7S0FDWixHQUFHLFFBQVE7S0FDWCxHQUFHO0tBQ0gsZUFBZSxRQUFRO0lBQzNCLENBQUM7R0FDVDtFQUNKLENBQUM7RUFDRCxhQUFhO0dBQ1QsWUFBWTtHQUNaLFNBQVMsQ0FBQyxVQUFVLG1CQUFtQjtFQUMzQztDQUNKLEdBQUc7RUFBQztFQUFTO0VBQU07RUFBVTtFQUFPO0VBQWdCO0NBQVEsQ0FBQztDQUM3RCxhQUFNLGdCQUFnQjtFQUNsQixxQkFBcUIsUUFBUSxXQUFXLFFBQVEsVUFBVSxJQUFJO0NBQ2xFLEdBQUcsQ0FBQyxPQUFPLENBQUM7Q0FDWixPQUFBLGFBQWEsY0FBYyxrQkFBa0IsV0FBVyxTQUFTLHFCQUFxQixTQUFTLEtBQUssR0FBRyxDQUFDLFdBQVcsT0FBTyxDQUFDO0FBQy9IO0FBRUEsSUFBSSxZQUFZLFVBQVUsT0FBTyxVQUFVO0FBRTNDLElBQUksdUJBQXVCLE9BQU8sUUFBUSxZQUFZLFVBQVUsaUJBQWlCO0NBQzdFLElBQUksU0FBUyxLQUFLLEdBQUc7RUFDakIsWUFBWSxPQUFPLE1BQU0sSUFBSSxLQUFLO0VBQ2xDLE9BQU8sSUFBSSxZQUFZLE9BQU8sWUFBWTtDQUM5QztDQUNBLElBQUksTUFBTSxRQUFRLEtBQUssR0FDbkIsT0FBTyxNQUFNLEtBQUssZUFBZSxZQUFZLE9BQU8sTUFBTSxJQUFJLFNBQVMsR0FDbkUsSUFBSSxZQUFZLFdBQVcsSUFBSSxjQUFjLFNBQVMsQ0FBQyxFQUFFO0NBRWpFLGFBQWEsT0FBTyxXQUFXO0NBQy9CLE9BQU87QUFDWDs7Ozs7Ozs7Ozs7OztBQWNBLFNBQVMsU0FBUyxPQUFPO0NBQ3JCLE1BQU0sY0FBYyxzQkFBc0I7Q0FDMUMsTUFBTSxFQUFFLFVBQVUsYUFBYSxNQUFNLGNBQWMsVUFBVSxPQUFPLFlBQWEsU0FBUyxDQUFDO0NBQzNGLE1BQU0sZ0JBQUEsYUFBc0IsT0FBTyxZQUFZO0NBQy9DLE1BQU0sV0FBQSxhQUFpQixPQUFPLE9BQU87Q0FDckMsTUFBTSxlQUFBLGFBQXFCLE9BQU8sT0FBTztDQUN6QyxNQUFNLFlBQUEsYUFBa0IsT0FBTyxJQUFJO0NBQ25DLFNBQVMsVUFBVTtDQUNuQixNQUFNLHlCQUF5QjtFQUMzQixNQUFNLGVBQWUsUUFBUSxVQUFVLE1BQU0sY0FBYyxPQUFPO0VBQ2xFLE9BQU8sU0FBUyxVQUFVLFNBQVMsUUFBUSxZQUFZLElBQUk7Q0FDL0Q7Q0FDQSxNQUFNLENBQUMsT0FBTyxlQUFBLGFBQXFCLFNBQVMsZ0JBQWdCO0NBQzVELE1BQU0scUJBQUEsYUFBMkIsT0FBTyxLQUFLO0NBQzdDLE1BQU0sbUJBQUEsYUFBeUIsYUFBYSxXQUFXO0VBQ25ELE1BQU0sYUFBYSxvQkFBb0IsTUFBTSxRQUFRLFFBQVEsVUFBVSxRQUFRLGFBQWEsT0FBTyxjQUFjLE9BQU87RUFDeEgsT0FBTyxTQUFTLFVBQVUsU0FBUyxRQUFRLFVBQVUsSUFBSTtDQUM3RCxHQUFHO0VBQUMsUUFBUTtFQUFhLFFBQVE7RUFBUTtDQUFJLENBQUM7Q0FDOUMsTUFBTSxlQUFBLGFBQXFCLGFBQWEsV0FBVztFQUMvQyxJQUFJLENBQUMsVUFBVTtHQUNYLE1BQU0sYUFBYSxvQkFBb0IsTUFBTSxRQUFRLFFBQVEsVUFBVSxRQUFRLGFBQWEsT0FBTyxjQUFjLE9BQU87R0FDeEgsSUFBSSxTQUFTLFNBQVM7SUFDbEIsTUFBTSxxQkFBcUIsU0FBUyxRQUFRLFVBQVU7SUFDdEQsSUFBSSxDQUFDLFVBQVUsb0JBQW9CLG1CQUFtQixPQUFPLEdBQUc7S0FDNUQsWUFBWSxrQkFBa0I7S0FDOUIsbUJBQW1CLFVBQVU7SUFDakM7R0FDSixPQUVJLFlBQVksVUFBVTtFQUU5QjtDQUNKLEdBQUc7RUFBQyxRQUFRO0VBQWEsUUFBUTtFQUFRO0VBQVU7Q0FBSSxDQUFDO0NBQ3hELE1BQU0sRUFBRSxnQkFBZ0IsYUFBYSxxQkFBcUIsZ0JBQWdCO0NBQzFFLE1BQU0sZ0JBQUEsYUFBc0IsT0FBTyxZQUFZO0NBQy9DLGNBQWMsVUFBVTtDQUN4QixNQUFNLG9CQUFBLGFBQTBCLE9BQU8sZ0JBQWdCO0NBQ3ZELGtCQUFrQixVQUFVO0NBQzVCLGdDQUFnQztFQUM1QixJQUFJLGFBQWEsWUFBWSxXQUN6QixDQUFDLFVBQVUsVUFBVSxTQUFTLElBQUksR0FBRztHQUNyQyxhQUFhLFVBQVU7R0FDdkIsVUFBVSxVQUFVO0dBQ3BCLGNBQWMsUUFBUTtFQUMxQixPQUVJLGVBQWUsQ0FBQyxnQkFBZ0Isa0JBQWtCLFFBQVEsSUFBSSxpQkFBaUI7R0FDM0UsTUFBTSxZQUFZLFlBQVksWUFBWTtHQUMxQyxZQUFZLFNBQVM7R0FDckIsbUJBQW1CLFVBQVU7RUFDakMsQ0FBQztFQUVMLE1BQU0sY0FBYyxRQUFRLFdBQVc7R0FDbkM7R0FDQSxXQUFXLEVBQ1AsUUFBUSxLQUNaO0dBQ0E7R0FDQSxXQUFXLGNBQWM7SUFDckIsY0FBYyxRQUFRLFVBQVUsTUFBTTtHQUMxQztFQUNKLENBQUM7RUFDRCxhQUFhO0dBQ1QsWUFBWTtHQUNaLFNBQVMsQ0FBQyxnQkFBZ0Isa0JBQWtCLFFBQVEsQ0FBQztFQUN6RDtDQUNKLEdBQUc7RUFBQztFQUFTO0VBQU87RUFBTTtFQUFVO0VBQWdCO0NBQVEsQ0FBQztDQUM3RCxhQUFNLGdCQUFnQixRQUFRLGlCQUFpQixDQUFDO0NBS2hELE1BQU0saUJBQWlCLGFBQWEsWUFBWTtDQUNoRCxNQUFNLFdBQVcsVUFBVTtDQVczQixPQUFBLGFBUG9DLGNBQWM7RUFDOUMsSUFBSSxVQUNBLE9BQU87RUFFWCxNQUFNLGNBQWMsQ0FBQyxrQkFBa0IsQ0FBQyxVQUFVLFVBQVUsSUFBSTtFQUNoRSxPQUFPLGtCQUFrQjtDQUM3QixHQUFHO0VBQUM7RUFBVTtFQUFnQjtFQUFNO0NBQVEsQ0FDakIsSUFBSSxpQkFBaUIsSUFBSTtBQUN4RDs7Ozs7Ozs7Ozs7OztBQWNBLFNBQVMsY0FBYyxPQUFPO0NBQzFCLE1BQU0sY0FBYyxzQkFBc0I7Q0FDMUMsTUFBTSxFQUFFLE1BQU0sVUFBVSxVQUFVLGFBQWEsa0JBQWtCLGNBQWMsUUFBUSxTQUFVO0NBQ2pHLE1BQU0sZUFBZSxtQkFBbUIsUUFBUSxPQUFPLE9BQU8sSUFBSTtDQU9sRSxNQUFNLFFBQVEsU0FBUztFQUNuQjtFQUNBO0VBQ0EsY0FBQSxhQVQyQixjQUFjO0dBQ3pDLE1BQU0sV0FBVyxJQUFJLFFBQVEsYUFBYSxNQUFNLElBQUksUUFBUSxnQkFBZ0IsTUFBTSxZQUFZLENBQUM7R0FDL0YsT0FBTyxZQUFZLFFBQVEsSUFDckIscUJBQXFCLFNBQVMsSUFBSSxJQUNsQztFQUNWLEdBQUc7R0FBQztHQUFTO0dBQU07RUFBWSxDQUlFO0VBQzdCO0NBQ0osQ0FBQztDQUNELE1BQU0sWUFBWSxhQUFhO0VBQzNCO0VBQ0E7RUFDQTtDQUNKLENBQUM7Q0FDRCxNQUFNLFNBQUEsYUFBZSxPQUFPLEtBQUs7Q0FDakMsTUFBTSxZQUFBLGFBQWtCLE9BQU8sSUFBSTtDQUNuQyxNQUFNLGlCQUFBLGFBQXVCLE9BQU8sUUFBUSxTQUFTLE1BQU07RUFDdkQsR0FBRyxNQUFNO0VBQ1Q7RUFDQSxHQUFJLFVBQVUsTUFBTSxRQUFRLElBQUksRUFBRSxVQUFVLE1BQU0sU0FBUyxJQUFJLENBQUM7Q0FDcEUsQ0FBQyxDQUFDO0NBQ0YsT0FBTyxVQUFVO0NBQ2pCLE1BQU0sYUFBQSxhQUFtQixjQUFjLE9BQU8saUJBQWlCLENBQUMsR0FBRztFQUMvRCxTQUFTO0dBQ0wsWUFBWTtHQUNaLFdBQVcsQ0FBQyxDQUFDLElBQUksVUFBVSxRQUFRLElBQUk7RUFDM0M7RUFDQSxTQUFTO0dBQ0wsWUFBWTtHQUNaLFdBQVcsQ0FBQyxDQUFDLElBQUksVUFBVSxhQUFhLElBQUk7RUFDaEQ7RUFDQSxXQUFXO0dBQ1AsWUFBWTtHQUNaLFdBQVcsQ0FBQyxDQUFDLElBQUksVUFBVSxlQUFlLElBQUk7RUFDbEQ7RUFDQSxjQUFjO0dBQ1YsWUFBWTtHQUNaLFdBQVcsQ0FBQyxDQUFDLElBQUksVUFBVSxrQkFBa0IsSUFBSTtFQUNyRDtFQUNBLE9BQU87R0FDSCxZQUFZO0dBQ1osV0FBVyxJQUFJLFVBQVUsUUFBUSxJQUFJO0VBQ3pDO0NBQ0osQ0FBQyxHQUFHLENBQUMsV0FBVyxJQUFJLENBQUM7Q0FDckIsTUFBTSxXQUFBLGFBQWlCLGFBQWEsVUFBVTtFQUMxQyxNQUFNLFFBQVEsY0FBYyxLQUFLO0VBQ2pDLElBQUksQ0FBQyxJQUFJLFFBQVEsU0FBUyxJQUFJLEdBQzFCLGVBQWUsVUFBVSxRQUFRLFNBQVMsTUFBTTtHQUM1QyxHQUFHLE9BQU8sUUFBUTtHQUNsQjtFQUNKLENBQUM7RUFFTCxPQUFPLGVBQWUsUUFBUSxTQUFTO0dBQ25DLFFBQVE7SUFDSixPQUFPLGNBQWMsS0FBSztJQUNwQjtHQUNWO0dBQ0EsTUFBTSxPQUFPO0VBQ2pCLENBQUM7Q0FDTCxHQUFHLENBQUMsTUFBTSxPQUFPLENBQUM7Q0FDbEIsTUFBTSxTQUFBLGFBQWUsa0JBQWtCO0VBQ25DLE1BQU0sUUFBUSxJQUFJLFFBQVEsYUFBYSxJQUFJO0VBQzNDLElBQUksQ0FBQyxJQUFJLFFBQVEsU0FBUyxJQUFJLEdBQzFCLGVBQWUsVUFBVSxRQUFRLFNBQVMsTUFBTTtHQUM1QyxHQUFHLE9BQU8sUUFBUTtHQUNsQjtFQUNKLENBQUM7RUFFTCxPQUFPLGVBQWUsUUFBUSxPQUFPO0dBQ2pDLFFBQVE7SUFDSjtJQUNNO0dBQ1Y7R0FDQSxNQUFNLE9BQU87RUFDakIsQ0FBQztDQUNMLEdBQUcsQ0FBQyxNQUFNLE9BQU8sQ0FBQztDQUNsQixNQUFNLE1BQUEsYUFBWSxhQUFhLFFBQVE7RUFDbkMsSUFBSSxLQUNBLFVBQVUsVUFBVTtHQUNoQixhQUFhLFdBQVcsSUFBSSxLQUFLLEtBQUssSUFBSSxNQUFNO0dBQ2hELGNBQWMsV0FBVyxJQUFJLE1BQU0sS0FBSyxJQUFJLE9BQU87R0FDbkQsb0JBQW9CLFlBQVksV0FBVyxJQUFJLGlCQUFpQixLQUFLLElBQUksa0JBQWtCLE9BQU87R0FDbEcsc0JBQXNCLFdBQVcsSUFBSSxjQUFjLEtBQUssSUFBSSxlQUFlO0VBQy9FO0VBRUosTUFBTSxRQUFRLElBQUksUUFBUSxTQUFTLElBQUk7RUFDdkMsSUFBSSxTQUFTLE1BQU0sTUFBTSxLQUFLO0dBQzFCLE1BQU0sR0FBRyxNQUFNLFVBQVU7R0FDekIsTUFBTSxHQUFHLEtBQUs7RUFDbEI7Q0FDSixHQUFHLENBQUMsUUFBUSxTQUFTLElBQUksQ0FBQztDQUMxQixNQUFNLFFBQUEsYUFBYyxlQUFlO0VBQy9CO0VBQ0E7RUFDQSxHQUFJLFVBQVUsUUFBUSxLQUFLLFVBQVUsV0FDL0IsRUFBRSxVQUFVLFVBQVUsWUFBWSxTQUFTLElBQzNDLENBQUM7RUFDUDtFQUNBO0VBQ0E7Q0FDSixJQUFJO0VBQUM7RUFBTTtFQUFVLFVBQVU7RUFBVTtFQUFVO0VBQVE7RUFBSztDQUFLLENBQUM7Q0FDdEUsYUFBTSxnQkFBZ0I7RUFDbEIsTUFBTSx5QkFBeUIsUUFBUSxTQUFTLG9CQUFvQjtFQUNwRSxlQUFlLFVBQVUsUUFBUSxTQUFTLE1BQU07R0FDNUMsR0FBRyxPQUFPLFFBQVE7R0FDbEIsR0FBSSxVQUFVLE9BQU8sUUFBUSxRQUFRLElBQy9CLEVBQUUsVUFBVSxPQUFPLFFBQVEsU0FBUyxJQUNwQyxDQUFDO0VBQ1gsQ0FBQztFQUNELE1BQU0saUJBQWlCLE1BQU0sVUFBVTtHQUNuQyxNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSTtHQUN2QyxJQUFJLFNBQVMsTUFBTSxJQUFJO0lBQ25CLE1BQU0sR0FBRyxRQUFRO0lBQ2pCLE1BQU0sR0FBRyxLQUFLO0dBQ2xCO0VBQ0o7RUFDQSxjQUFjLE1BQU0sSUFBSTtFQUN4QixJQUFJLHdCQUF3QjtHQUN4QixNQUFNLFFBQVEsWUFBWSxJQUFJLG1CQUN4QixRQUFRLGlCQUNSLFFBQVEsU0FBUyxVQUFVLFFBQVEsZ0JBQWdCLE1BQU0sSUFBSSxRQUFRLFNBQVMsZUFBZSxNQUFNLE9BQU8sUUFBUSxZQUFZLENBQUMsQ0FBQztHQUN0SSxJQUFJLFFBQVEsZ0JBQWdCLE1BQU0sS0FBSztHQUN2QyxJQUFJLFlBQVksSUFBSSxRQUFRLGFBQWEsSUFBSSxDQUFDLEdBQzFDLElBQUksUUFBUSxhQUFhLE1BQU0sS0FBSztFQUU1QztFQUNBLENBQUMsZ0JBQ0csUUFBUSxTQUFTLE1BQU07R0FDbkIsR0FBRyxPQUFPLFFBQVE7R0FDbEIsR0FBSSxVQUFVLE9BQU8sUUFBUSxRQUFRLElBQy9CLEVBQUUsVUFBVSxPQUFPLFFBQVEsU0FBUyxJQUNwQyxDQUFDO0VBQ1gsQ0FBQztFQUNMLElBQUksVUFBVSxTQUFTO0dBQ25CLE1BQU0sUUFBUSxJQUFJLFFBQVEsU0FBUyxJQUFJO0dBQ3ZDLElBQUksU0FBUyxNQUFNLElBQ2YsTUFBTSxHQUFHLE1BQU0sVUFBVTtFQUVqQztFQUNBLGFBQWE7R0FDVCxDQUFDLGVBQ0ssMEJBQTBCLENBQUMsUUFBUSxPQUFPLFNBQzFDLDBCQUNBLFFBQVEsV0FBVyxJQUFJLElBQ3ZCLGNBQWMsTUFBTSxLQUFLO0VBQ25DO0NBQ0osR0FBRztFQUFDO0VBQU07RUFBUztFQUFjO0NBQWdCLENBQUM7Q0FDbEQsYUFBTSxnQkFBZ0I7RUFDbEIsUUFBUSxrQkFBa0I7R0FDdEI7R0FDQTtFQUNKLENBQUM7Q0FDTCxHQUFHO0VBQUM7RUFBVTtFQUFNO0NBQU8sQ0FBQztDQUM1QixPQUFBLGFBQWEsZUFBZTtFQUN4QjtFQUNBO0VBQ0E7Q0FDSixJQUFJO0VBQUM7RUFBTztFQUFXO0NBQVUsQ0FBQztBQUN0Qzs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JBLElBQU0sY0FBYyxVQUFVLE1BQU0sT0FBTyxjQUFjLEtBQUssQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0FBZ0IvRCxJQUFNLGdCQUFnQixFQUFFLElBQUksU0FBUyxNQUFNLGFBQWM7Q0FDckQsTUFBTSxFQUFFLFdBQVcsYUFBYTtFQUM1QjtFQUNNO0NBQ1YsQ0FBQztDQUNELE1BQU0sUUFBUSxJQUFJLFFBQVEsSUFBSTtDQUM5QixJQUFJLENBQUMsT0FDRCxPQUFPO0NBRVgsTUFBTSxVQUFVLE1BQU0sV0FBVztDQUNqQyxJQUFJLFFBQ0EsT0FBTyxPQUFPO0VBQUU7RUFBUyxVQUFVLE1BQU07Q0FBTSxDQUFDO0NBRXBELE9BQUEsYUFBYSxjQUFjLE1BQUEsYUFBWSxVQUFVLE1BQU0sT0FBTztBQUNsRTtBQUVBLElBQUksbUJBQW1CLE9BQU8sV0FBVyxlQUFlLE9BQU8sYUFDekQsT0FBTyxXQUFXLElBQ2xCLHVDQUF1QyxRQUFRLFVBQVUsTUFBTTtDQUM3RCxNQUFNLElBQUssS0FBSyxPQUFPLElBQUksS0FBTTtDQUNqQyxRQUFRLE1BQU0sTUFBTSxJQUFLLElBQUksSUFBTyxFQUFBLENBQUssU0FBUyxFQUFFO0FBQ3hELENBQUM7QUFFTCxJQUFJLHFCQUFxQixNQUFNLE9BQU8sVUFBVSxDQUFDLE1BQU0sUUFBUSxlQUFlLFlBQVksUUFBUSxXQUFXLElBQ3ZHLFFBQVEsYUFDTixHQUFHLEtBQUssR0FBRyxZQUFZLFFBQVEsVUFBVSxJQUFJLFFBQVEsUUFBUSxXQUFXLEtBQzFFO0FBRU4sSUFBSSxzQkFBc0IsVUFBVTtDQUNoQyxZQUFZLENBQUMsUUFBUSxTQUFTLGdCQUFnQjtDQUM5QyxVQUFVLFNBQVMsZ0JBQWdCO0NBQ25DLFlBQVksU0FBUyxnQkFBZ0I7Q0FDckMsU0FBUyxTQUFTLGdCQUFnQjtDQUNsQyxXQUFXLFNBQVMsZ0JBQWdCO0FBQ3hDO0FBRUEsSUFBSSxhQUFhLE1BQU0sUUFBUSxnQkFBZ0I7Q0FDM0MsSUFBSSxhQUNBLE9BQU87Q0FDWCxJQUFJLE9BQU8sWUFBWSxPQUFPLE1BQU0sSUFBSSxJQUFJLEdBQ3hDLE9BQU87Q0FDWCxLQUFLLE1BQU0sYUFBYSxPQUFPLE9BQzNCLElBQUksS0FBSyxXQUFXLFNBQVMsS0FBSyxLQUFLLE9BQU8sVUFBVSxNQUFNLE1BQU0sS0FDaEUsT0FBTztDQUVmLE9BQU87QUFDWDtBQUVBLElBQU0seUJBQXlCLFFBQVEsUUFBUSxnQkFBZ0I7Q0FDM0QsS0FBSyxNQUFNLE9BQU8sZUFBZSxPQUFPLEtBQUssTUFBTSxHQUFHO0VBQ2xELElBQUksUUFBUSxNQUNSO0VBRUosTUFBTSxRQUFRLGNBQWMsSUFBSSxRQUFRLEdBQUcsSUFBSSxPQUFPO0VBQ3RELElBQUksT0FBTztHQUNQLE1BQU0sRUFBRSxPQUFPO0dBQ2YsSUFBSSxJQUFJO0lBQ0osSUFBSSxHQUFHLFFBQVEsR0FBRyxLQUFLLE1BQU0sT0FBTyxHQUFHLEtBQUssSUFBSSxHQUFHLElBQUksR0FDbkQsT0FBTztTQUVOLElBQUksR0FBRyxPQUFPLE9BQU8sR0FBRyxLQUFLLEdBQUcsSUFBSSxHQUNyQyxPQUFPO1NBR1AsSUFBSSxzQkFBc0IsT0FBTyxNQUFNLEdBQ25DLE9BQU87R0FHbkIsT0FDSyxJQUFJLFNBQVMsS0FBSyxLQUFLLE1BQU0sUUFBUSxLQUFLLEdBQ3ZDO1FBQUEsc0JBQXNCLE9BQU8sTUFBTSxHQUNuQyxPQUFPO0dBQUE7RUFHbkI7Q0FDSjtBQUVKO0FBRUEsSUFBSSw2QkFBNkIsUUFBUSxPQUFPLFNBQVM7Q0FDckQsTUFBTSxpQkFBaUIsSUFBSSxRQUFRLElBQUk7Q0FDdkMsTUFBTSxtQkFBbUIsTUFBTSxRQUFRLGNBQWMsSUFBSSxpQkFBaUIsQ0FBQztDQUMzRSxJQUFJLGtCQUFrQixpQkFBaUIsTUFBTSxLQUFLO0NBQ2xELElBQUksUUFBUSxNQUFNLGdCQUFnQjtDQUNsQyxPQUFPO0FBQ1g7QUFFQSxJQUFJLGlCQUFpQixVQUFVLFNBQVMsS0FBSyxLQUFLLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDO0FBRXRFLElBQUksaUJBQWlCLFVBQVU7Q0FDM0IsSUFBSSxDQUFDLE9BQ0QsT0FBTztDQUVYLE1BQU0sUUFBUSxRQUFRLE1BQU0sZ0JBQWdCO0NBQzVDLE9BQVEsa0JBQ0gsU0FBUyxNQUFNLGNBQWMsTUFBTSxZQUFZLGNBQWM7QUFDdEU7QUFFQSxJQUFJLGdCQUFnQixZQUFZLFFBQVEsU0FBUztBQUVqRCxJQUFJLFdBQVcsVUFBVSxpQkFBaUI7QUFFMUMsSUFBSSxnQkFBZ0IsTUFBTSwwQkFBMEIsUUFBUSxNQUFNLFlBQVksMkJBQ3hFO0NBQ0UsR0FBRyxPQUFPO0NBQ1YsT0FBTztFQUNILEdBQUksT0FBTyxTQUFTLE9BQU8sS0FBSyxDQUFDLFFBQVEsT0FBTyxLQUFLLENBQUMsUUFBUSxDQUFDO0dBQzlELE9BQU8sV0FBVztDQUN2QjtBQUNKLElBQ0UsQ0FBQztBQUVQLElBQU0sZ0JBQWdCO0NBQ2xCLE9BQU87Q0FDUCxTQUFTO0FBQ2I7QUFDQSxJQUFNLGNBQWM7Q0FBRSxPQUFPO0NBQU0sU0FBUztBQUFLO0FBQ2pELElBQUksb0JBQW9CLFlBQVk7Q0FDaEMsSUFBSSxDQUFDLE1BQU0sUUFBUSxPQUFPLEdBQ3RCLE9BQU87Q0FFWCxJQUFJLFFBQVEsU0FBUyxHQUFHO0VBQ3BCLE1BQU0sU0FBUyxRQUNWLFFBQVEsV0FBVyxVQUFVLE9BQU8sV0FBVyxDQUFDLE9BQU8sUUFBUSxDQUFDLENBQ2hFLEtBQUssV0FBVyxPQUFPLEtBQUs7RUFDakMsT0FBTztHQUFFLE9BQU87R0FBUSxTQUFTLENBQUMsQ0FBQyxPQUFPO0VBQU87Q0FDckQ7Q0FDQSxNQUFNLFNBQVMsUUFBUTtDQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sV0FBVyxPQUFPLFVBQ3JDLE9BQU87Q0FFWCxJQUFJLENBQUMsT0FBTyxjQUFjLEVBQUUsV0FBVyxPQUFPLGFBQzFDLE9BQU87Q0FFWCxPQUFPLFlBQVksT0FBTyxLQUFLLEtBQUssT0FBTyxVQUFVLEtBQy9DLGNBQ0E7RUFBRSxPQUFPLE9BQU87RUFBTyxTQUFTO0NBQUs7QUFDL0M7QUFFQSxJQUFNLGdCQUFnQjtDQUNsQixTQUFTO0NBQ1QsT0FBTztBQUNYO0FBQ0EsSUFBSSxpQkFBaUIsWUFBWSxNQUFNLFFBQVEsT0FBTyxJQUNoRCxRQUFRLFFBQVEsVUFBVSxXQUFXLFVBQVUsT0FBTyxXQUFXLENBQUMsT0FBTyxXQUNyRTtDQUNFLFNBQVM7Q0FDVCxPQUFPLE9BQU87QUFDbEIsSUFDRSxVQUFVLGFBQWEsSUFDM0I7QUFFTixTQUFTLGlCQUFpQixRQUFRLEtBQUssT0FBTyxZQUFZO0NBQ3RELElBQUksU0FBUyxNQUFNLEtBQ2QsTUFBTSxRQUFRLE1BQU0sS0FBSyxPQUFPLE1BQU0sUUFBUSxLQUM5QyxVQUFVLE1BQU0sS0FBSyxDQUFDLFFBQ3ZCLE9BQU87RUFDSDtFQUNBLFNBQVMsU0FBUyxNQUFNLElBQUksU0FBUztFQUNyQztDQUNKO0FBRVI7QUFFQSxJQUFJLHNCQUFzQixtQkFBbUIsU0FBUyxjQUFjLEtBQUssQ0FBQyxRQUFRLGNBQWMsSUFDMUYsaUJBQ0E7Q0FDRSxPQUFPO0NBQ1AsU0FBUztBQUNiO0FBRUosSUFBSSxnQkFBZ0IsT0FBTyxPQUFPLG9CQUFvQixZQUFZLDBCQUEwQiwyQkFBMkIsaUJBQWlCO0NBQ3BJLE1BQU0sRUFBRSxLQUFLLE1BQU0sVUFBVSxXQUFXLFdBQVcsS0FBSyxLQUFLLFNBQVMsVUFBVSxNQUFNLGVBQWUsT0FBTyxPQUFRLE1BQU07Q0FDMUgsTUFBTSxhQUFhLElBQUksWUFBWSxJQUFJO0NBQ3ZDLElBQUksQ0FBQyxTQUFTLG1CQUFtQixJQUFJLElBQUksR0FDckMsT0FBTyxDQUFDO0NBRVosTUFBTSxXQUFXLE9BQU8sS0FBSyxLQUFLO0NBQ2xDLE1BQU0scUJBQXFCLFlBQVk7RUFDbkMsSUFBSSw2QkFBNkIsU0FBUyxnQkFBZ0I7R0FDdEQsTUFBTSxrQkFBa0IsVUFBVSxPQUFPLElBQUksS0FBSyxXQUFXO0dBQzdELElBQUksTUFDQSxLQUFLLFNBQVMsUUFBUSxXQUFXLElBQUksaUJBQWlCLEtBQ2xELElBQUksa0JBQWtCLGVBQWUsQ0FBQztRQUcxQyxTQUFTLGtCQUFrQixlQUFlO0dBRTlDLFNBQVMsZUFBZTtFQUM1QjtDQUNKO0NBQ0EsTUFBTSxRQUFRLENBQUM7Q0FDZixNQUFNLFVBQVUsYUFBYSxHQUFHO0NBQ2hDLE1BQU0sYUFBYSxnQkFBZ0IsR0FBRztDQUN0QyxNQUFNLG9CQUFvQixXQUFXO0NBQ3JDLE1BQU0sV0FBWSxpQkFBaUIsWUFBWSxHQUFHLE1BQzlDLFlBQVksSUFBSSxLQUFLLEtBQ3JCLFlBQVksVUFBVSxLQUNyQixjQUFjLEdBQUcsS0FBSyxJQUFJLFVBQVUsTUFBTSxDQUFDLE1BQzVDLGVBQWUsTUFDZCxNQUFNLFFBQVEsVUFBVSxLQUFLLENBQUMsV0FBVztDQUM5QyxNQUFNLG9CQUFvQixhQUFhLEtBQUssTUFBTSxNQUFNLDBCQUEwQixLQUFLO0NBQ3ZGLE1BQU0sb0JBQW9CLFdBQVcsa0JBQWtCLGtCQUFrQixVQUFVLHVCQUF1QixXQUFXLFVBQVUsdUJBQXVCLGNBQWM7RUFDaEssTUFBTSxVQUFVLFlBQVksbUJBQW1CO0VBQy9DLE1BQU0sUUFBUTtHQUNWLE1BQU0sWUFBWSxVQUFVO0dBQzVCO0dBQ0E7R0FDQSxHQUFHLGtCQUFrQixZQUFZLFVBQVUsU0FBUyxPQUFPO0VBQy9EO0NBQ0o7Q0FDQSxJQUFJLGVBQ0UsQ0FBQyxNQUFNLFFBQVEsVUFBVSxLQUFLLENBQUMsV0FBVyxTQUMxQyxhQUNJLENBQUMsc0JBQXNCLFdBQVcsa0JBQWtCLFVBQVUsTUFDM0QsVUFBVSxVQUFVLEtBQUssQ0FBQyxjQUMxQixjQUFjLENBQUMsaUJBQWlCLElBQUksQ0FBQyxDQUFDLFdBQ3RDLFdBQVcsQ0FBQyxjQUFjLElBQUksQ0FBQyxDQUFDLFVBQVc7RUFDcEQsTUFBTSxFQUFFLE9BQU8sWUFBWSxTQUFTLFFBQVEsSUFDdEM7R0FBRSxPQUFPLENBQUMsQ0FBQztHQUFVLFNBQVM7RUFBUyxJQUN2QyxtQkFBbUIsUUFBUTtFQUNqQyxJQUFJLE9BQU87R0FDUCxNQUFNLFFBQVE7SUFDVixNQUFNLHVCQUF1QjtJQUM3QjtJQUNBLEtBQUs7SUFDTCxHQUFHLGtCQUFrQix1QkFBdUIsVUFBVSxPQUFPO0dBQ2pFO0dBQ0EsSUFBSSxDQUFDLDBCQUEwQjtJQUMzQixrQkFBa0IsT0FBTztJQUN6QixPQUFPO0dBQ1g7RUFDSjtDQUNKO0NBQ0EsSUFBSSxDQUFDLFlBQVksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUMsa0JBQWtCLEdBQUcsSUFBSTtFQUNsRSxJQUFJO0VBQ0osSUFBSTtFQUNKLE1BQU0sWUFBWSxtQkFBbUIsR0FBRztFQUN4QyxNQUFNLFlBQVksbUJBQW1CLEdBQUc7RUFDeEMsSUFBSSxDQUFDLGtCQUFrQixVQUFVLEtBQzdCLENBQUMsYUFBYSxVQUFVLEtBQ3hCLENBQUMsTUFBTSxVQUFVLEdBQUc7R0FDcEIsTUFBTSxjQUFjLElBQUksa0JBQ25CLGFBQWEsQ0FBQyxhQUFhO0dBQ2hDLElBQUksQ0FBQyxrQkFBa0IsVUFBVSxLQUFLLEdBQ2xDLFlBQVksY0FBYyxVQUFVO0dBRXhDLElBQUksQ0FBQyxrQkFBa0IsVUFBVSxLQUFLLEdBQ2xDLFlBQVksY0FBYyxVQUFVO0VBRTVDLE9BQ0s7R0FDRCxNQUFNLFlBQVksSUFBSSxlQUFlLElBQUksS0FBSyxVQUFVO0dBQ3hELE1BQU0scUJBQXFCLHlCQUFTLElBQUksc0JBQUssSUFBSSxLQUFLLEVBQUEsQ0FBRSxhQUFhLElBQUksTUFBTSxJQUFJO0dBQ25GLE1BQU0sU0FBUyxJQUFJLFFBQVE7R0FDM0IsTUFBTSxTQUFTLElBQUksUUFBUTtHQUMzQixJQUFJLFNBQVMsVUFBVSxLQUFLLEtBQUssWUFDN0IsWUFBWSxTQUNOLGtCQUFrQixVQUFVLElBQUksa0JBQWtCLFVBQVUsS0FBSyxJQUNqRSxTQUNJLGFBQWEsVUFBVSxRQUN2QixZQUFZLElBQUksS0FBSyxVQUFVLEtBQUs7R0FFbEQsSUFBSSxTQUFTLFVBQVUsS0FBSyxLQUFLLFlBQzdCLFlBQVksU0FDTixrQkFBa0IsVUFBVSxJQUFJLGtCQUFrQixVQUFVLEtBQUssSUFDakUsU0FDSSxhQUFhLFVBQVUsUUFDdkIsWUFBWSxJQUFJLEtBQUssVUFBVSxLQUFLO0VBRXREO0VBQ0EsSUFBSSxhQUFhLFdBQVc7R0FDeEIsaUJBQWlCLENBQUMsQ0FBQyxXQUFXLFVBQVUsU0FBUyxVQUFVLFNBQVMsdUJBQXVCLEtBQUssdUJBQXVCLEdBQUc7R0FDMUgsSUFBSSxDQUFDLDBCQUEwQjtJQUMzQixrQkFBa0IsTUFBTSxLQUFLLENBQUMsT0FBTztJQUNyQyxPQUFPO0dBQ1g7RUFDSjtDQUNKO0NBQ0EsS0FBSyxhQUFhLGNBQ2QsQ0FBQyxZQUNBLFNBQVMsVUFBVSxLQUFNLGdCQUFnQixNQUFNLFFBQVEsVUFBVSxJQUFLO0VBQ3ZFLE1BQU0sa0JBQWtCLG1CQUFtQixTQUFTO0VBQ3BELE1BQU0sa0JBQWtCLG1CQUFtQixTQUFTO0VBQ3BELE1BQU0sWUFBWSxDQUFDLGtCQUFrQixnQkFBZ0IsS0FBSyxLQUN0RCxXQUFXLFNBQVMsQ0FBQyxnQkFBZ0I7RUFDekMsTUFBTSxZQUFZLENBQUMsa0JBQWtCLGdCQUFnQixLQUFLLEtBQ3RELFdBQVcsU0FBUyxDQUFDLGdCQUFnQjtFQUN6QyxJQUFJLGFBQWEsV0FBVztHQUN4QixpQkFBaUIsV0FBVyxnQkFBZ0IsU0FBUyxnQkFBZ0IsT0FBTztHQUM1RSxJQUFJLENBQUMsMEJBQTBCO0lBQzNCLGtCQUFrQixNQUFNLEtBQUssQ0FBQyxPQUFPO0lBQ3JDLE9BQU87R0FDWDtFQUNKO0NBQ0o7Q0FDQSxJQUFJLFdBQVcsQ0FBQyxXQUFXLFNBQVMsVUFBVSxHQUFHO0VBQzdDLE1BQU0sRUFBRSxPQUFPLGNBQWMsWUFBWSxtQkFBbUIsT0FBTztFQUNuRSxJQUFJLFFBQVEsWUFBWSxLQUFLLENBQUMsV0FBVyxNQUFNLFlBQVksR0FBRztHQUMxRCxNQUFNLFFBQVE7SUFDVixNQUFNLHVCQUF1QjtJQUM3QjtJQUNBO0lBQ0EsR0FBRyxrQkFBa0IsdUJBQXVCLFNBQVMsT0FBTztHQUNoRTtHQUNBLElBQUksQ0FBQywwQkFBMEI7SUFDM0Isa0JBQWtCLE9BQU87SUFDekIsT0FBTztHQUNYO0VBQ0o7Q0FDSjtDQUNBLElBQUksVUFBVTtFQUNWLElBQUksV0FBVyxRQUFRLEdBQUc7R0FFdEIsTUFBTSxnQkFBZ0IsaUJBQWlCLE1BRGxCLFNBQVMsWUFBWSxVQUFVLEdBQ0wsUUFBUTtHQUN2RCxJQUFJLGVBQWU7SUFDZixNQUFNLFFBQVE7S0FDVixHQUFHO0tBQ0gsR0FBRyxrQkFBa0IsdUJBQXVCLFVBQVUsY0FBYyxPQUFPO0lBQy9FO0lBQ0EsSUFBSSxDQUFDLDBCQUEwQjtLQUMzQixrQkFBa0IsY0FBYyxPQUFPO0tBQ3ZDLE9BQU87SUFDWDtHQUNKO0VBQ0osT0FDSyxJQUFJLFNBQVMsUUFBUSxHQUFHO0dBQ3pCLElBQUksbUJBQW1CLENBQUM7R0FDeEIsS0FBSyxNQUFNLE9BQU8sVUFBVTtJQUN4QixJQUFJLENBQUMsY0FBYyxnQkFBZ0IsS0FBSyxDQUFDLDBCQUNyQztJQUVKLE1BQU0sZ0JBQWdCLGlCQUFpQixNQUFNLFNBQVMsSUFBSSxDQUFDLFlBQVksVUFBVSxHQUFHLFVBQVUsR0FBRztJQUNqRyxJQUFJLGVBQWU7S0FDZixtQkFBbUI7TUFDZixHQUFHO01BQ0gsR0FBRyxrQkFBa0IsS0FBSyxjQUFjLE9BQU87S0FDbkQ7S0FDQSxJQUFJLENBQUMsMEJBQ0Qsa0JBQWtCLGNBQWMsT0FBTztLQUUzQyxJQUFJLDBCQUNBLE1BQU0sUUFBUTtJQUV0QjtHQUNKO0dBQ0EsSUFBSSxDQUFDLGNBQWMsZ0JBQWdCLEdBQUc7SUFDbEMsTUFBTSxRQUFRO0tBQ1YsS0FBSztLQUNMLEdBQUc7SUFDUDtJQUNBLElBQUksQ0FBQywwQkFDRCxPQUFPO0dBRWY7RUFDSjtDQUNKO0NBQ0EsTUFBTSxhQUFhLE1BQU07Q0FDekIsa0JBQWtCLGFBQWEsV0FBVyxVQUFVLElBQUk7Q0FDeEQsT0FBTztBQUNYO0FBRUEsSUFBSSx5QkFBeUIsVUFBVyxNQUFNLFFBQVEsS0FBSyxJQUFJLFFBQVEsQ0FBQyxLQUFLO0FBRTdFLElBQUksWUFBWSxNQUFNLFVBQVUsQ0FDNUIsR0FBRyxNQUNILEdBQUcsc0JBQXNCLEtBQUssQ0FDbEM7QUFFQSxJQUFJLGtCQUFrQixVQUFVLE1BQU0sUUFBUSxLQUFLLElBQUksTUFBTSxVQUFVLEtBQUEsQ0FBUyxJQUFJLEtBQUE7QUFFcEYsU0FBUyxPQUFPLE1BQU0sT0FBTyxPQUFPO0NBQ2hDLE9BQU87RUFDSCxHQUFHLEtBQUssTUFBTSxHQUFHLEtBQUs7RUFDdEIsR0FBRyxzQkFBc0IsS0FBSztFQUM5QixHQUFHLEtBQUssTUFBTSxLQUFLO0NBQ3ZCO0FBQ0o7QUFFQSxJQUFJLGVBQWUsTUFBTSxNQUFNLE9BQU87Q0FDbEMsSUFBSSxDQUFDLE1BQU0sUUFBUSxJQUFJLEdBQ25CLE9BQU8sQ0FBQztDQUVaLElBQUksWUFBWSxLQUFLLEdBQUcsR0FDcEIsS0FBSyxNQUFNLEtBQUE7Q0FFZixLQUFLLE9BQU8sSUFBSSxHQUFHLEtBQUssT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUU7Q0FDMUMsT0FBTztBQUNYO0FBRUEsSUFBSSxhQUFhLE1BQU0sVUFBVSxDQUM3QixHQUFHLHNCQUFzQixLQUFLLEdBQzlCLEdBQUcsc0JBQXNCLElBQUksQ0FDakM7QUFFQSxJQUFJLFdBQVcsVUFBVSxNQUFNLFFBQVEsS0FBSyxJQUFJLE1BQU0sT0FBTyxPQUFPLElBQUksQ0FBQztBQUV6RSxTQUFTLGdCQUFnQixNQUFNLFNBQVM7Q0FDcEMsSUFBSSxJQUFJO0NBQ1IsTUFBTSxPQUFPLENBQUMsR0FBRyxJQUFJO0NBQ3JCLEtBQUssTUFBTSxTQUFTLFNBQVM7RUFDekIsS0FBSyxPQUFPLFFBQVEsR0FBRyxDQUFDO0VBQ3hCO0NBQ0o7Q0FDQSxPQUFPLFFBQVEsSUFBSSxDQUFDLENBQUMsU0FBUyxPQUFPLENBQUM7QUFDMUM7QUFDQSxJQUFJLGlCQUFpQixNQUFNLFVBQVUsWUFBWSxLQUFLLElBQ2hELENBQUMsSUFDRCxnQkFBZ0IsTUFBTSxDQUFDLEdBQUcsSUFBSSxJQUFJLHNCQUFzQixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLENBQUM7QUFFNUYsSUFBSSxlQUFlLE1BQU0sUUFBUSxXQUFXO0NBQ3hDLENBQUMsS0FBSyxTQUFTLEtBQUssV0FBVyxDQUFDLEtBQUssU0FBUyxLQUFLLE9BQU87QUFDOUQ7QUFFQSxTQUFTLFFBQVEsUUFBUSxZQUFZO0NBQ2pDLE1BQU0sU0FBUyxXQUFXLFNBQVM7Q0FDbkMsSUFBSSxRQUFRO0NBQ1osT0FBTyxRQUFRLFFBQVE7RUFDbkIsSUFBSSxrQkFBa0IsTUFBTSxHQUFHO0dBQzNCLFNBQVMsS0FBQTtHQUNUO0VBQ0o7RUFDQSxTQUFTLE9BQU8sV0FBVztFQUMzQjtDQUNKO0NBQ0EsT0FBTztBQUNYO0FBQ0EsU0FBUyxhQUFhLEtBQUs7Q0FDdkIsS0FBSyxNQUFNLE9BQU8sS0FDZCxJQUFJLElBQUksZUFBZSxHQUFHLEtBQUssQ0FBQyxZQUFZLElBQUksSUFBSSxHQUNoRCxPQUFPO0NBR2YsT0FBTztBQUNYO0FBQ0EsU0FBUyxNQUFNLFFBQVEsTUFBTTtDQUN6QixJQUFJLFNBQVMsSUFBSSxLQUFLLE9BQU8sVUFBVSxlQUFlLEtBQUssUUFBUSxJQUFJLEdBQUc7RUFDdEUsT0FBTyxPQUFPO0VBQ2QsT0FBTztDQUNYO0NBQ0EsTUFBTSxRQUFRLE1BQU0sUUFBUSxJQUFJLElBQzFCLE9BQ0EsTUFBTSxJQUFJLElBQ04sQ0FBQyxJQUFJLElBQ0wsYUFBYSxJQUFJO0NBQzNCLElBQUksTUFBTSxNQUFNLFlBQVksbUJBQW1CLFNBQVMsT0FBTyxPQUFPLENBQUMsQ0FBQyxHQUNwRSxPQUFPO0NBRVgsTUFBTSxjQUFjLE1BQU0sV0FBVyxJQUFJLFNBQVMsUUFBUSxRQUFRLEtBQUs7Q0FDdkUsTUFBTSxRQUFRLE1BQU0sU0FBUztDQUM3QixNQUFNLE1BQU0sTUFBTTtDQUNsQixJQUFJLGFBQ0EsT0FBTyxZQUFZO0NBRXZCLElBQUksVUFBVSxNQUNSLFNBQVMsV0FBVyxLQUFLLGNBQWMsV0FBVyxLQUMvQyxNQUFNLFFBQVEsV0FBVyxLQUFLLGFBQWEsV0FBVyxJQUMzRCxNQUFNLFFBQVEsTUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDO0NBRXBDLE9BQU87QUFDWDtBQUVBLElBQUksWUFBWSxhQUFhLE9BQU8sVUFBVTtDQUMxQyxZQUFZLFNBQVM7Q0FDckIsT0FBTztBQUNYOzs7Ozs7Ozs7Ozs7O0FBY0EsU0FBUyxjQUFjLE9BQU87Q0FDMUIsTUFBTSxjQUFjLHNCQUFzQjtDQUMxQyxNQUFNLEVBQUUsVUFBVSxhQUFhLE1BQU0sVUFBVSxNQUFNLFVBQVUsa0JBQWtCLFVBQVc7Q0FDNUYsTUFBTSw2QkFBNkIsUUFBUSxlQUFlLElBQUk7Q0FDOUQsTUFBTSxDQUFDLFFBQVEsYUFBQSxhQUFtQixTQUFTLG9CQUFvQjtDQUMvRCxNQUFNLE1BQUEsYUFBWSxPQUFPLFFBQVEsZUFBZSxJQUFJLENBQUMsQ0FBQyxJQUFJLFVBQVUsQ0FBQztDQUNyRSxNQUFNLFlBQUEsYUFBa0IsT0FBTyxLQUFLO0NBQ3BDLE1BQU0sRUFBRSxnQkFBZ0IsYUFBYSxxQkFBcUIsb0JBQW9CO0NBQzlFLE1BQU0sZUFBQSxhQUFxQixPQUFPLE9BQU87Q0FDekMsTUFBTSxZQUFBLGFBQWtCLE9BQU8sSUFBSTtDQUNuQyxJQUFJLENBQUMsVUFDRCxRQUFRLE9BQU8sTUFBTSxJQUFJLElBQUk7Q0FFakMsYUFBTSxjQUFjLENBQUMsWUFDakIsU0FDQSxPQUFPLFVBQVUsS0FDakIsUUFBUSxTQUFTLE1BQU0sS0FBSyxHQUFHO0VBQUM7RUFBUztFQUFNLE9BQU87RUFBUTtFQUFPO0NBQVEsQ0FBQztDQUNsRixnQ0FBZ0M7RUFDNUIsSUFBSSxVQUNBO0VBRUosSUFBSSxhQUFhLFlBQVksV0FBVyxVQUFVLFlBQVksTUFDMUQsZUFBZSxNQUFNLHVCQUF1QixnQkFBZ0I7R0FDeEQsVUFBVSxXQUFXO0dBQ3JCLElBQUksVUFBVSxZQUFZLElBQUksVUFBVTtFQUM1QyxDQUFDO09BRUE7R0FDRCxhQUFhLFVBQVU7R0FDdkIsVUFBVSxVQUFVO0dBQ3BCLE1BQU0sY0FBYyxxQkFBcUI7R0FDekMsSUFBSSxDQUFDLFVBQVUsUUFBUSxXQUFXLEdBQUc7SUFDakMsVUFBVSxXQUFXO0lBQ3JCLElBQUksVUFBVSxZQUFZLElBQUksVUFBVTtHQUM1QztHQUNBLFNBQVMsTUFBTSxvQkFBb0I7RUFDdkM7RUFDQSxNQUFNLGNBQWMsUUFBUSxVQUFVLE1BQU0sVUFBVSxFQUNsRCxPQUFPLEVBQUUsUUFBUSxNQUFNLHFCQUFzQjtHQUN6QyxJQUFJLG1CQUFtQixRQUFRLENBQUMsZ0JBQWdCO0lBQzVDLE1BQU0sY0FBYyxJQUFJLFFBQVEsSUFBSTtJQUNwQyxJQUFJLE1BQU0sUUFBUSxXQUFXLEdBQUc7S0FDNUIsVUFBVSxXQUFXO0tBQ3JCLElBQUksVUFBVSxZQUFZLElBQUksVUFBVTtJQUM1QyxPQUNLLElBQUksQ0FBQyxnQkFBZ0I7S0FDdEIsVUFBVSxDQUFDLENBQUM7S0FDWixJQUFJLFVBQVUsQ0FBQztJQUNuQjtHQUNKO0VBQ0osRUFDSixDQUFDLENBQUMsQ0FBQztFQUNILGFBQWE7R0FDVCxZQUFZO0dBQ1osU0FBUyxNQUFNLG9CQUFvQjtFQUN2QztDQUNKLEdBQUc7RUFBQztFQUFTO0VBQU07RUFBVTtFQUFnQjtDQUFRLENBQUM7Q0FDdEQsTUFBTSxlQUFBLGFBQXFCLGFBQWEsNEJBQTRCO0VBQ2hFLFVBQVUsVUFBVTtFQUNwQixRQUFRLGVBQWUsTUFBTSx1QkFBdUI7Q0FDeEQsR0FBRyxDQUFDLFNBQVMsSUFBSSxDQUFDO0NBQ2xCLE1BQU0sVUFBVSxPQUFPLFlBQVk7RUFDL0IsSUFBSSxVQUNBO0VBRUosTUFBTSxjQUFjLHNCQUFzQixZQUFZLEtBQUssQ0FBQztFQUM1RCxNQUFNLDBCQUEwQixTQUFTLFFBQVEsZUFBZSxJQUFJLEdBQUcsV0FBVztFQUNsRixRQUFRLE9BQU8sUUFBUSxrQkFBa0IsTUFBTSx3QkFBd0IsU0FBUyxHQUFHLE9BQU87RUFDMUYsSUFBSSxVQUFVLFNBQVMsSUFBSSxTQUFTLFlBQVksSUFBSSxVQUFVLENBQUM7RUFDL0QsYUFBYSx1QkFBdUI7RUFDcEMsVUFBVSx1QkFBdUI7RUFDakMsUUFBUSxlQUFlLE1BQU0seUJBQXlCLFVBQVUsRUFDNUQsTUFBTSxlQUFlLEtBQUssRUFDOUIsQ0FBQztDQUNMO0NBQ0EsTUFBTSxXQUFXLE9BQU8sWUFBWTtFQUNoQyxJQUFJLFVBQ0E7RUFFSixNQUFNLGVBQWUsc0JBQXNCLFlBQVksS0FBSyxDQUFDO0VBQzdELE1BQU0sMEJBQTBCLFVBQVUsUUFBUSxlQUFlLElBQUksR0FBRyxZQUFZO0VBQ3BGLFFBQVEsT0FBTyxRQUFRLGtCQUFrQixNQUFNLEdBQUcsT0FBTztFQUN6RCxJQUFJLFVBQVUsVUFBVSxJQUFJLFNBQVMsYUFBYSxJQUFJLFVBQVUsQ0FBQztFQUNqRSxhQUFhLHVCQUF1QjtFQUNwQyxVQUFVLHVCQUF1QjtFQUNqQyxRQUFRLGVBQWUsTUFBTSx5QkFBeUIsV0FBVyxFQUM3RCxNQUFNLGVBQWUsS0FBSyxFQUM5QixDQUFDO0NBQ0w7Q0FDQSxNQUFNLFVBQVUsVUFBVTtFQUN0QixJQUFJLFVBQ0E7RUFFSixNQUFNLDBCQUEwQixjQUFjLFFBQVEsZUFBZSxJQUFJLEdBQUcsS0FBSztFQUNqRixJQUFJLFVBQVUsY0FBYyxJQUFJLFNBQVMsS0FBSztFQUM5QyxhQUFhLHVCQUF1QjtFQUNwQyxVQUFVLHVCQUF1QjtFQUNqQyxDQUFDLE1BQU0sUUFBUSxJQUFJLFFBQVEsU0FBUyxJQUFJLENBQUMsS0FDckMsSUFBSSxRQUFRLFNBQVMsTUFBTSxLQUFBLENBQVM7RUFDeEMsUUFBUSxlQUFlLE1BQU0seUJBQXlCLGVBQWUsRUFDakUsTUFBTSxNQUNWLENBQUM7Q0FDTDtDQUNBLE1BQU0sWUFBWSxPQUFPLE9BQU8sWUFBWTtFQUN4QyxJQUFJLFVBQ0E7RUFFSixNQUFNLGNBQWMsc0JBQXNCLFlBQVksS0FBSyxDQUFDO0VBQzVELE1BQU0sMEJBQTBCLE9BQU8sUUFBUSxlQUFlLElBQUksR0FBRyxPQUFPLFdBQVc7RUFDdkYsUUFBUSxPQUFPLFFBQVEsa0JBQWtCLE1BQU0sT0FBTyxPQUFPO0VBQzdELElBQUksVUFBVSxPQUFPLElBQUksU0FBUyxPQUFPLFlBQVksSUFBSSxVQUFVLENBQUM7RUFDcEUsYUFBYSx1QkFBdUI7RUFDcEMsVUFBVSx1QkFBdUI7RUFDakMsUUFBUSxlQUFlLE1BQU0seUJBQXlCLFFBQVE7R0FDMUQsTUFBTTtHQUNOLE1BQU0sZUFBZSxLQUFLO0VBQzlCLENBQUM7Q0FDTDtDQUNBLE1BQU0sUUFBUSxRQUFRLFdBQVc7RUFDN0IsSUFBSSxVQUNBO0VBRUosTUFBTSwwQkFBMEIsUUFBUSxlQUFlLElBQUk7RUFDM0QsWUFBWSx5QkFBeUIsUUFBUSxNQUFNO0VBQ25ELFlBQVksSUFBSSxTQUFTLFFBQVEsTUFBTTtFQUN2QyxhQUFhLHVCQUF1QjtFQUNwQyxVQUFVLHVCQUF1QjtFQUNqQyxRQUFRLGVBQWUsTUFBTSx5QkFBeUIsYUFBYTtHQUMvRCxNQUFNO0dBQ04sTUFBTTtFQUNWLEdBQUcsS0FBSztDQUNaO0NBQ0EsTUFBTSxRQUFRLE1BQU0sT0FBTztFQUN2QixJQUFJLFVBQ0E7RUFFSixNQUFNLDBCQUEwQixRQUFRLGVBQWUsSUFBSTtFQUMzRCxZQUFZLHlCQUF5QixNQUFNLEVBQUU7RUFDN0MsWUFBWSxJQUFJLFNBQVMsTUFBTSxFQUFFO0VBQ2pDLGFBQWEsdUJBQXVCO0VBQ3BDLFVBQVUsdUJBQXVCO0VBQ2pDLFFBQVEsZUFBZSxNQUFNLHlCQUF5QixhQUFhO0dBQy9ELE1BQU07R0FDTixNQUFNO0VBQ1YsR0FBRyxLQUFLO0NBQ1o7Q0FDQSxNQUFNLFVBQVUsT0FBTyxVQUFVO0VBQzdCLElBQUksVUFDQTtFQUVKLE1BQU0sY0FBYyxZQUFZLEtBQUs7RUFDckMsTUFBTSwwQkFBMEIsU0FBUyxRQUFRLGVBQWUsSUFBSSxHQUFHLE9BQU8sV0FBVztFQUN6RixJQUFJLFVBQVUsQ0FBQyxHQUFHLHVCQUF1QixDQUFDLENBQUMsS0FBSyxNQUFNLE1BQU0sQ0FBQyxRQUFRLE1BQU0sUUFBUSxXQUFXLElBQUksSUFBSSxRQUFRLEVBQUU7RUFDaEgsYUFBYSx1QkFBdUI7RUFDcEMsVUFBVSxDQUFDLEdBQUcsdUJBQXVCLENBQUM7RUFDdEMsUUFBUSxlQUFlLE1BQU0seUJBQXlCLFVBQVU7R0FDNUQsTUFBTTtHQUNOLE1BQU0sZUFBZSxLQUFLO0VBQzlCLENBQUM7Q0FDTDtDQUNBLE1BQU0sV0FBVyxVQUFVO0VBQ3ZCLElBQUksVUFDQTtFQUVKLE1BQU0sMEJBQTBCLHNCQUFzQixZQUFZLEtBQUssQ0FBQztFQUN4RSxJQUFJLFVBQVUsd0JBQXdCLElBQUksVUFBVTtFQUNwRCxhQUFhLENBQUMsR0FBRyx1QkFBdUIsQ0FBQztFQUN6QyxVQUFVLENBQUMsR0FBRyx1QkFBdUIsQ0FBQztFQUN0QyxRQUFRLGVBQWUsTUFBTSxDQUFDLEdBQUcsdUJBQXVCLElBQUksU0FBUyxNQUFNLFFBQVEsSUFBSSxJQUNqRixLQUFLLE1BQU0sR0FBRyx3QkFBd0IsTUFBTSxJQUM1QyxNQUFNLENBQUMsQ0FBQztDQUNsQjtDQUNBLGFBQU0sZ0JBQWdCO0VBQ2xCLElBQUksVUFBVTtHQUNWLFFBQVEsT0FBTyxtQkFBbUIsT0FBTyxJQUFJO0dBQzdDO0VBQ0o7RUFDQSxRQUFRLE9BQU8sU0FBUztFQUN4QixRQUFRLE9BQU8sbUJBQW1CLE9BQU8sSUFBSTtFQUM3QyxVQUFVLE1BQU0sUUFBUSxNQUFNLEtBQzFCLFFBQVEsVUFBVSxNQUFNLEtBQUssRUFDekIsR0FBRyxRQUFRLFdBQ2YsQ0FBQztFQUNMLE1BQU0sa0JBQWtCLG1CQUFtQixRQUFRLFNBQVMsSUFBSTtFQUNoRSxJQUFJLFVBQVUsWUFDVCxDQUFDLGdCQUFnQixjQUFjLFFBQVEsV0FBVyxnQkFDbkQsQ0FBQyxtQkFBbUIsUUFBUSxTQUFTLGNBQWMsQ0FBQyxDQUFDLGNBQ3JELENBQUMsZ0JBQWdCLFVBQVU7R0FDM0IsSUFBSSxRQUFRLFNBQVMsVUFDakIsUUFBUSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLFdBQVc7SUFDeEMsUUFBUSxvQkFBb0IsQ0FBQyxJQUFJLENBQUM7SUFDbEMsTUFBTSxRQUFRLElBQUksT0FBTyxRQUFRLElBQUk7SUFDckMsTUFBTSxnQkFBZ0IsSUFBSSxRQUFRLFdBQVcsUUFBUSxJQUFJO0lBQ3pELE1BQU0sb0JBQW9CLGtCQUNyQixjQUFjLFFBQ1YsY0FBYyxRQUFRLGNBQWMsS0FBSztJQUNsRCxNQUFNLHVCQUF1QixrQkFDeEIsY0FBYyxXQUNWLGNBQWMsUUFBUSxjQUFjLEtBQUs7SUFDbEQsSUFBSSxnQkFDRyxDQUFDLFNBQVMscUJBQ1IsVUFDSSxzQkFBc0IsTUFBTSxRQUN6Qix5QkFBeUIsTUFBTSxXQUN6QyxTQUFTLE1BQU0sTUFBTTtLQUN2QixJQUFJLE9BQ0EsU0FBUyxLQUFLLEtBQ1YsQ0FBQyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsTUFBTSxRQUFRLENBQUMsT0FBTyxNQUFNLENBQUMsR0FBRyxDQUFDLElBQ25ELDBCQUEwQixRQUFRLFdBQVcsUUFBUSxHQUFHLE9BQU8sTUFBTSxHQUFHLElBQUksSUFDNUUsSUFBSSxRQUFRLFdBQVcsUUFBUSxNQUFNLEtBQUs7VUFHaEQsTUFBTSxRQUFRLFdBQVcsUUFBUSxJQUFJO0tBRXpDLFFBQVEsV0FBVyxTQUFTLEVBQUUsR0FBRyxRQUFRLFdBQVcsT0FBTztLQUMzRCxRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQ3pCLFFBQVEsUUFBUSxXQUFXLE9BQy9CLENBQUM7SUFDTDtHQUNKLENBQUM7UUFFQTtJQUNELE1BQU0sUUFBUSxJQUFJLFFBQVEsU0FBUyxJQUFJO0lBQ3ZDLElBQUksU0FBUyxNQUFNLElBQ2YsY0FBYyxPQUFPLFFBQVEsT0FBTyxVQUFVLFFBQVEsYUFBYSxRQUFRLFNBQVMsaUJBQWlCLGdCQUFnQixLQUFLLFFBQVEsU0FBUywyQkFBMkIsSUFBSSxDQUFDLENBQUMsTUFBTSxVQUFVO0tBQ3hMLElBQUksQ0FBQyxjQUFjLEtBQUssR0FBRztNQUN2QiwwQkFBMEIsUUFBUSxXQUFXLFFBQVEsT0FBTyxJQUFJO01BQ2hFLFFBQVEsV0FBVyxTQUFTLEVBQUUsR0FBRyxRQUFRLFdBQVcsT0FBTztNQUMzRCxRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQ3pCLFFBQVEsUUFBUSxXQUFXLE9BQy9CLENBQUM7S0FDTCxPQUNLO01BQ0QsTUFBTSxnQkFBZ0IsSUFBSSxRQUFRLFdBQVcsUUFBUSxJQUFJO01BQ3pELElBQUksaUJBQWlCLGNBQWMsa0JBQWtCO09BQ2pELE1BQU0sUUFBUSxXQUFXLFFBQVEsR0FBRyxLQUFLLEdBQUcsaUJBQWlCO09BQzdELFFBQVEsV0FBVyxTQUFTLEVBQUUsR0FBRyxRQUFRLFdBQVcsT0FBTztPQUMzRCxRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQ3pCLFFBQVEsUUFBUSxXQUNYLE9BQ1QsQ0FBQztNQUNMO0tBQ0o7SUFDSixDQUFDO0dBRVQ7RUFDSjtFQUlBLFVBQVUsV0FDTixRQUFRLFVBQVUsTUFBTSxLQUFLO0dBQ3pCO0dBQ0EsUUFBUSxZQUFZLFFBQVEsV0FBVztFQUMzQyxDQUFDO0VBQ0wsUUFBUSxPQUFPLFNBQ1gsc0JBQXNCLFFBQVEsVUFBVSxLQUFLLFFBQVE7R0FDakQsSUFBSSxRQUFRLE9BQU8sU0FDZixJQUFJLFdBQVcsUUFBUSxPQUFPLEtBQUssS0FDbkMsSUFBSSxPQUFPO0lBQ1gsSUFBSSxNQUFNO0lBQ1YsT0FBTztHQUNYO0VBRUosQ0FBQztFQUNMLFFBQVEsT0FBTyxRQUFRO0VBQ3ZCLFFBQVEsVUFBVTtFQUNsQixVQUFVLFVBQVU7Q0FDeEIsR0FBRztFQUFDO0VBQVE7RUFBTTtFQUFTO0NBQVEsQ0FBQztDQUNwQyxhQUFNLGdCQUFnQjtFQUNsQixJQUFJLENBQUMsVUFDRCxZQUFZLElBQUksUUFBUSxhQUFhLElBQUksQ0FBQyxLQUN0QyxRQUFRLGVBQWUsSUFBSTtFQUVuQyxhQUFhO0dBQ1QsUUFBUSxPQUFPLG1CQUFtQixPQUFPLElBQUk7R0FDN0MsSUFBSSxVQUNBO0dBRUosTUFBTSw2QkFBNkIsRUFBRSxRQUFRLFNBQVMsb0JBQW9CO0dBQzFFLE1BQU0saUJBQWlCLE1BQU0sVUFBVTtJQUNuQyxNQUFNLFFBQVEsSUFBSSxRQUFRLFNBQVMsSUFBSTtJQUN2QyxJQUFJLFNBQVMsTUFBTSxJQUNmLE1BQU0sR0FBRyxRQUFRO0dBRXpCO0dBQ0EsSUFBSSxVQUFVLFdBQVcsNEJBQ3JCLFFBQVEsVUFBVSxNQUFNLEtBQUs7SUFDekI7SUFDQSxRQUFRLFlBQVksUUFBUSxXQUFXO0dBQzNDLENBQUM7R0FFTCxJQUFJLENBQUMsOEJBQThCLFFBQVEsT0FBTyxRQUM5QztHQUVKLDZCQUNNLGNBQWMsTUFBTSxLQUFLLElBQ3pCLFFBQVEsV0FBVyxJQUFJO0VBQ2pDO0NBQ0osR0FBRztFQUFDO0VBQU07RUFBUztFQUFTO0VBQWtCO0NBQVEsQ0FBQztDQUN2RCxPQUFPO0VBQ0gsTUFBQSxhQUFZLFlBQVksTUFBTTtHQUFDO0dBQWM7R0FBTTtHQUFTO0VBQVEsQ0FBQztFQUNyRSxNQUFBLGFBQVksWUFBWSxNQUFNO0dBQUM7R0FBYztHQUFNO0dBQVM7RUFBUSxDQUFDO0VBQ3JFLFNBQUEsYUFBZSxZQUFZLFNBQVM7R0FDaEM7R0FDQTtHQUNBO0dBQ0E7RUFDSixDQUFDO0VBQ0QsUUFBQSxhQUFjLFlBQVksUUFBUTtHQUFDO0dBQWM7R0FBTTtHQUFTO0VBQVEsQ0FBQztFQUN6RSxRQUFBLGFBQWMsWUFBWSxRQUFRO0dBQUM7R0FBYztHQUFNO0dBQVM7RUFBUSxDQUFDO0VBQ3pFLFFBQUEsYUFBYyxZQUFZLFVBQVU7R0FBQztHQUFjO0dBQU07R0FBUztFQUFRLENBQUM7RUFDM0UsUUFBQSxhQUFjLFlBQVksUUFBUTtHQUFDO0dBQWM7R0FBTTtHQUFTO0VBQVEsQ0FBQztFQUN6RSxTQUFBLGFBQWUsWUFBWSxTQUFTO0dBQ2hDO0dBQ0E7R0FDQTtHQUNBO0VBQ0osQ0FBQztFQUNELFFBQUEsYUFBYyxjQUFjLE9BQU8sS0FBSyxPQUFPLFdBQVc7R0FDdEQsR0FBRztHQUNILEdBQUksVUFBVSxRQUFRLElBQUksRUFBRSxTQUFTLElBQUksQ0FBQztJQUN6QyxVQUFVLElBQUksUUFBUSxVQUFVLFdBQVc7RUFDaEQsRUFBRSxHQUFHO0dBQUM7R0FBUTtHQUFTO0VBQVEsQ0FBQztDQUNwQztBQUNKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFrQ0EsSUFBTSxjQUFjLFVBQVUsTUFBTSxPQUFPLGNBQWMsS0FBSyxDQUFDO0FBRS9ELElBQU0sY0FBYyxVQUFXLE9BQU8sU0FBUyxlQUFlLGlCQUFpQixRQUMxRSxPQUFPLFNBQVMsZUFBZSxpQkFBaUI7QUFDckQsSUFBTSxrQkFBa0IsVUFBVSxPQUFPLGFBQWEsZUFBZSxpQkFBaUI7QUFDdEYsSUFBTSxXQUFXLFFBQVE7Q0FDckIsTUFBTSxTQUFTLENBQUM7Q0FDaEIsS0FBSyxNQUFNLE9BQU8sT0FBTyxLQUFLLEdBQUcsR0FDN0IsSUFBSSxhQUFhLElBQUksSUFBSSxLQUNyQixJQUFJLFNBQVMsUUFDYixDQUFDLGFBQWEsSUFBSSxJQUFJLEtBQ3RCLENBQUMsV0FBVyxJQUFJLElBQUksS0FDcEIsQ0FBQyxlQUFlLElBQUksSUFBSSxHQUFHO0VBQzNCLE1BQU0sU0FBUyxRQUFRLElBQUksSUFBSTtFQUMvQixLQUFLLE1BQU0sYUFBYSxPQUFPLEtBQUssTUFBTSxHQUN0QyxPQUFPLEdBQUcsSUFBSSxHQUFHLGVBQWUsT0FBTztDQUUvQyxPQUVJLE9BQU8sT0FBTyxJQUFJO0NBRzFCLE9BQU87QUFDWDtBQUVBLFNBQVMsZUFBZSxNQUFNO0NBQzFCLE1BQU0sU0FBUyxJQUFJLFNBQVM7Q0FDNUIsTUFBTSxvQkFBb0IsUUFBUSxJQUFJO0NBQ3RDLEtBQUssTUFBTSxPQUFPLG1CQUFtQjtFQUNqQyxNQUFNLFFBQVEsa0JBQWtCO0VBQ2hDLElBQUksWUFBWSxLQUFLLEdBQ2pCO0VBRUosSUFBSSxPQUFPLGFBQWEsZUFBZSxpQkFBaUIsVUFBVTtHQUM5RCxLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsTUFBTSxRQUFRLFNBQVM7SUFDL0MsTUFBTSxPQUFPLE1BQU07SUFDbkIsUUFBUSxPQUFPLE9BQU8sS0FBSyxJQUFJO0dBQ25DO0dBQ0E7RUFDSjtFQUNBLE9BQU8sT0FBTyxLQUFLLEtBQUs7Q0FDNUI7Q0FDQSxPQUFPO0FBQ1g7QUFFQSxTQUFTLGtCQUFrQixPQUFPO0NBQzlCLElBQUk7RUFDQSxPQUFPLEtBQUssVUFBVSxLQUFLO0NBQy9CLFNBQ08sSUFBSTtFQUNQLE9BQU87Q0FDWDtBQUNKO0FBRUEsU0FBUyxPQUFPLENBQUU7QUFFbEIsSUFBTSxrQkFBQSxhQUF3QixjQUFjLElBQUk7QUFDaEQsZ0JBQWdCLGNBQWM7Ozs7Ozs7Ozs7OztBQVk5QixJQUFNLHVCQUFBLGFBQTZCLFdBQVcsZUFBZTs7Ozs7Ozs7Ozs7Ozs7QUFjN0QsSUFBTSxnQkFBZ0IsRUFBRSxVQUFVLE9BQU8sV0FBVyxXQUFXLGVBQWUsVUFBVSxhQUFhLFVBQVUsV0FBVyxTQUFTLFdBQVcsWUFBWSxPQUFPLG9CQUFvQixjQUFjLFlBQVksU0FBUyxVQUFVLFVBQVUsZ0JBQWlCO0NBQ3pQLE1BQU0sZ0JBQUEsYUFBc0IsZUFBZTtFQUN2QztFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNKLElBQUk7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNKLENBQUM7Q0FDRCxPQUFBLGFBQWMsY0FBYyxnQkFBZ0IsVUFBVSxFQUFFLE9BQU8sY0FBYyxHQUFBLGFBQ25FLGNBQWMsdUJBQXVCLFVBQVUsRUFBRSxPQUFPLGNBQWMsUUFBUSxHQUFHLFFBQVEsQ0FBQztBQUN4RztBQUVBLElBQU0sZUFBZTtBQUNyQixTQUFTLHNCQUFzQixRQUFRO0NBQ25DLE9BQU8sVUFBVSxPQUFPLFNBQVM7QUFDckM7Ozs7Ozs7Ozs7Ozs7OztBQWVBLFNBQVMsS0FBSyxPQUFPO0NBQ2pCLE1BQU0sVUFBVSxlQUFlO0NBQy9CLE1BQU0sQ0FBQyxTQUFTLGNBQUEsYUFBb0IsU0FBUyxLQUFLO0NBQ2xELE1BQU0sRUFBRSxVQUFVLFFBQVEsU0FBUyxXQUFXLE1BQU0sVUFBVSxRQUFRLFNBQVMsY0FBYyxTQUFTLFNBQVMsVUFBVSxNQUFNLFFBQVEsWUFBWSxNQUFNLGlCQUFpQix1QkFBdUIsR0FBRyxTQUFTO0NBQzdNLE1BQU0sZUFBQSxhQUFxQixjQUFjO0VBQ3JDLE9BQU8sUUFBUSxhQUFhLE9BQU8sTUFBTSxVQUFVO0dBQy9DLE1BQU0sV0FBVyxlQUFlLElBQUk7R0FDcEMsTUFBTSxlQUFlLGtCQUFrQixJQUFJO0dBQzNDLElBQUksVUFDQSxNQUFNLFNBQVM7SUFDWDtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0osQ0FBQztHQUVMLElBQUksU0FBUyxNQUFNLEdBQ2YsSUFBSTtJQUNBLE1BQU0sZ0NBQWlDLFdBQ25DLFFBQVEsbUJBQ1IsUUFBUSxlQUFlLENBQUMsU0FBUyxNQUFNLEtBQ3RDLFdBQVcsUUFBUSxTQUFTLE1BQU07SUFDdkMsTUFBTSxXQUFXLE1BQU0sTUFBTSxRQUFRO0tBQ2pDO0tBQ0EsU0FBUztNQUNMLEdBQUc7TUFDSCxHQUFJLFdBQ0EsWUFBWSx5QkFBeUIsRUFDckMsZ0JBQWdCLFFBQ3BCO0tBQ0o7S0FDQSxNQUFNLGdDQUFnQyxlQUFlO0lBQ3pELENBQUM7SUFDRCxJQUFJLFlBQVksQ0FBQyxlQUFlLFNBQVMsTUFBTSxHQUFHO0tBQzlDLFFBQVEsRUFBRSxTQUFTLENBQUM7S0FDcEIsT0FBTyxFQUFFLE1BQU0sT0FBTyxTQUFTLE1BQU0sRUFBRTtJQUMzQyxPQUVJLFVBQVUsRUFBRSxTQUFTLENBQUM7R0FFOUIsU0FDTyxPQUFPO0lBQ1YsUUFBUSxFQUFFLE1BQU0sQ0FBQztJQUNqQixPQUFPLEVBQUUsTUFBTSxHQUFHO0dBQ3RCO0dBRUosSUFBSSxXQUFXLE1BQU0sR0FDakIsSUFBSTtJQUNBLE1BQU0sT0FBTyxRQUFRO0dBQ3pCLFNBQ08sT0FBTztJQUNWLFFBQVEsRUFBRSxNQUFNLENBQUM7SUFDakIsT0FBTyxFQUFFLE1BQU0sR0FBRztHQUN0QjtFQUlSLENBQUM7Q0FDTCxHQUFHO0VBQ0M7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0osQ0FBQztDQUNELE1BQU0sU0FBQSxhQUFlLFlBQVksT0FBTyxVQUFVO0VBQzlDLE1BQU0sTUFBTSxNQUFNLGFBQWEsS0FBSztFQUNwQyxJQUFJLE9BQU8sU0FBUztHQUNoQixRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQUUsb0JBQW9CLE1BQU0sQ0FBQztHQUMxRCxRQUFRLFNBQVMsZUFBZSxHQUFHO0VBQ3ZDO0NBQ0osR0FBRyxDQUFDLGNBQWMsT0FBTyxDQUFDO0NBQzFCLGFBQU0sZ0JBQWdCO0VBQ2xCLFdBQVcsSUFBSTtDQUNuQixHQUFHLENBQUMsQ0FBQztDQUNMLElBQUksUUFDQSxPQUFPLE9BQU8sRUFBRSxPQUFPLENBQUM7Q0FLNUIsT0FBQSxhQUFjLGNBQWMsUUFBUTtFQUFFLFlBQVk7RUFBaUI7RUFBUSxHQUFJLENBQUMsV0FBVyxNQUFNLEtBQUs7R0FBRTtHQUFRO0VBQVE7RUFBSSxVQUFVO0VBQVEsR0FBRztDQUFLLEdBQUcsUUFBUTtBQUNySztBQUVBLElBQU0sYUFBYSxFQUFFLFNBQVMsVUFBVSxPQUFPLE1BQU0sYUFBYyxPQUFPLGFBQWE7Q0FBRTtDQUFTO0NBQU07Q0FBVTtBQUFNLENBQUMsQ0FBQzs7QUFFMUgsSUFBTSxxQkFBcUI7QUFFM0IsSUFBSSxzQkFBc0I7Q0FDdEIsSUFBSSw2QkFBYSxJQUFJLElBQUk7Q0FDekIsSUFBSSxrQkFBa0I7Q0FDdEIsTUFBTSxRQUFRLFVBQVU7RUFDcEIsTUFBTSxZQUFZO0VBQ2xCO0VBQ0EsS0FBSyxNQUFNLFlBQVksV0FDbkIsU0FBUyxRQUFRLFNBQVMsS0FBSyxLQUFLO0VBRXhDLGNBQWMsY0FBYztDQUNoQztDQUNBLE1BQU0sYUFBYSxhQUFhO0VBQzVCLFdBQVcsSUFBSSxRQUFRO0VBQ3ZCLE9BQU8sRUFDSCxtQkFBbUI7R0FDZixJQUFJLGlCQUFpQjtJQUNqQixhQUFhLElBQUksSUFBSSxVQUFVO0lBQy9CLGtCQUFrQjtHQUN0QjtHQUNBLFdBQVcsT0FBTyxRQUFRO0VBQzlCLEVBQ0o7Q0FDSjtDQUNBLE1BQU0sb0JBQW9CO0VBQ3RCLDZCQUFhLElBQUksSUFBSTtFQUNyQixrQkFBa0I7Q0FDdEI7Q0FDQSxPQUFPO0VBQ0gsSUFBSSxZQUFZO0dBQ1osT0FBTyxNQUFNLEtBQUssVUFBVTtFQUNoQztFQUNBO0VBQ0E7RUFDQTtDQUNKO0FBQ0o7QUFFQSxTQUFTLGtCQUFrQixhQUFhLFlBQVk7Q0FDaEQsTUFBTSxTQUFVLE1BQU0sUUFBUSxXQUFXLElBQUksQ0FBQyxJQUFJLENBQUM7Q0FDbkQsS0FBSyxNQUFNLE9BQU8sYUFDZCxJQUFJLE9BQU8sVUFBVSxlQUFlLEtBQUssYUFBYSxHQUFHLEdBQUc7RUFDeEQsTUFBTSxhQUFhLFlBQVk7RUFDL0IsTUFBTSxhQUFhLFdBQVc7RUFDOUIsSUFBSSxlQUNDLFNBQVMsVUFBVSxLQUFLLE1BQU0sUUFBUSxVQUFVLE1BQ2pELFlBQ0EsT0FBTyxPQUFPLGtCQUFrQixZQUFZLFVBQVU7T0FFckQsSUFBSSxZQUFZLE1BQ2pCLE9BQU8sT0FBTztDQUV0QjtDQUVKLE9BQU87QUFDWDtBQUVBLElBQU0sVUFBVSxPQUFPLFFBQVEsVUFBVSxRQUNyQyxhQUFhLEtBQUssS0FDbEIsT0FBTyxVQUFVLGVBQWUsS0FBSyxPQUFPLEdBQUc7QUFDbkQsSUFBSSxPQUFPLFFBQVEsU0FBUztDQUN4QixJQUFJLENBQUMsTUFDRCxPQUFPO0NBRVgsSUFBSSxTQUFTO0NBQ2IsS0FBSyxNQUFNLE9BQU8sTUFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksYUFBYSxJQUFJLEdBQUc7RUFDekQsSUFBSSxDQUFDLE9BQU8sUUFBUSxHQUFHLEdBRW5CLE9BQU8sT0FBTyxRQUFRLElBQUk7RUFFOUIsU0FBUyxPQUFPO0NBQ3BCO0NBQ0EsT0FBTztBQUNYO0FBRUEsSUFBSSxZQUFZLFFBQVEsZ0JBQWdCLEdBQUcsSUFDckMsSUFBSSxZQUFZLElBQUksaUJBQ3BCLENBQUMsYUFBYSxHQUFHLEtBQ2Ysa0JBQWtCLE9BQ2xCLElBQUksVUFBVSxJQUFJO0FBRTFCLElBQUksb0JBQW9CLFlBQVksUUFBUSxTQUFTO0FBRXJELElBQUkscUJBQXFCLFFBQVEsYUFBYSxHQUFHLEtBQUssZ0JBQWdCLEdBQUc7QUFFekUsSUFBSSxRQUFRLFFBQVEsY0FBYyxHQUFHLEtBQUssSUFBSTtBQUU5QyxTQUFTLGlCQUFpQixPQUFPO0NBQzdCLE9BQU8sTUFBTSxRQUFRLEtBQUssS0FBSyxTQUFTLEtBQUs7QUFDakQ7QUFDQSxTQUFTLHVCQUF1QixXQUFXLG1CQUFtQixTQUFTLElBQUksUUFBUSxDQUFDLEdBQUc7Q0FDbkYsS0FBSyxNQUFNLE9BQU8sV0FBVztFQUN6QixNQUFNLE9BQU8sU0FBUyxHQUFHLE9BQU8sR0FBRyxRQUFRO0VBQzNDLE1BQU0sUUFBUSxVQUFVO0VBQ3hCLElBQUksaUJBQWlCLEtBQUssS0FDdEIsaUJBQWlCLElBQUksbUJBQW1CLElBQUksQ0FBQyxHQUM3Qyx1QkFBdUIsT0FBTyxtQkFBbUIsTUFBTSxLQUFLO09BRzVELE1BQU0sS0FBSyxJQUFJO0NBRXZCO0NBQ0EsT0FBTztBQUNYO0FBRUEsSUFBSSxxQkFBcUIsU0FBUztDQUM5QixLQUFLLE1BQU0sT0FBTyxNQUNkLElBQUksV0FBVyxLQUFLLElBQUksR0FDcEIsT0FBTztDQUdmLE9BQU87QUFDWDtBQUVBLFNBQVMsY0FBYyxPQUFPO0NBQzFCLE9BQU8sTUFBTSxRQUFRLEtBQUssS0FBTSxTQUFTLEtBQUssS0FBSyxDQUFDLGtCQUFrQixLQUFLO0FBQy9FO0FBQ0EsU0FBUyxpQkFBaUIsVUFBVTtDQUNoQyxPQUFPLENBQUMsRUFBRSxZQUFZLFFBQVE7QUFDbEM7QUFDQSxTQUFTLHNCQUFzQixPQUFPO0NBQ2xDLE9BQU8sTUFBTSxRQUFRLEtBQUssSUFDcEIsQ0FBQyxNQUFNLE1BQU0sU0FBUyxDQUFDLFlBQVksSUFBSSxDQUFDLElBQ3hDLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDO0FBQzlCO0FBQ0EsU0FBUyxnQkFBZ0IsV0FBVyxLQUFLO0NBQ3JDLElBQUksTUFBTSxRQUFRLFNBQVMsR0FDdkIsVUFBVSxPQUFPLEtBQUE7TUFHakIsT0FBTyxVQUFVO0FBRXpCO0FBQ0EsU0FBUyxnQkFBZ0IsTUFBTSxTQUFTLENBQUMsR0FBRyxXQUFXO0NBQ25ELEtBQUssTUFBTSxPQUFPLE1BQU07RUFDcEIsTUFBTSxRQUFRLEtBQUs7RUFDbkIsTUFBTSxXQUFXLGFBQWEsVUFBVTtFQUN4QyxJQUFJLGNBQWMsS0FBSyxNQUNsQixDQUFDLE1BQU0sUUFBUSxLQUFLLEtBQUssQ0FBQyxpQkFBaUIsUUFBUSxJQUFJO0dBQ3hELE9BQU8sT0FBTyxNQUFNLFFBQVEsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDO0dBQzNDLGdCQUFnQixPQUFPLE9BQU8sTUFBTSxRQUFRO0dBQzVDLElBQUksc0JBQXNCLE9BQU8sSUFBSSxHQUNqQyxnQkFBZ0IsUUFBUSxHQUFHO0VBRW5DLE9BQ0ssSUFBSSxDQUFDLFlBQVksS0FBSyxHQUN2QixPQUFPLE9BQU87Q0FFdEI7Q0FDQSxPQUFPO0FBQ1g7QUFDQSxTQUFTLGVBQWUsTUFBTSxZQUFZLHVCQUF1QixXQUFXO0NBQ3hFLElBQUksQ0FBQyx1QkFDRCx3QkFBd0IsZ0JBQWdCLFlBQVksTUFBTSxRQUFRLFVBQVUsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLFNBQVM7Q0FFdEcsS0FBSyxNQUFNLE9BQU8sTUFBTTtFQUNwQixNQUFNLFFBQVEsS0FBSztFQUNuQixNQUFNLFdBQVcsYUFBYSxVQUFVO0VBQ3hDLElBQUksY0FBYyxLQUFLLE1BQ2xCLENBQUMsTUFBTSxRQUFRLEtBQUssS0FBSyxDQUFDLGlCQUFpQixRQUFRLElBQUk7R0FDeEQsSUFBSSxZQUFZLFVBQVUsS0FBSyxZQUFZLHNCQUFzQixJQUFJLEdBQ2pFLHNCQUFzQixPQUFPLGdCQUFnQixPQUFPLE1BQU0sUUFBUSxLQUFLLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxRQUFRO1FBRzVGLGVBQWUsT0FBTyxrQkFBa0IsVUFBVSxJQUFJLENBQUMsSUFBSSxXQUFXLE1BQU0sc0JBQXNCLE1BQU0sUUFBUTtHQUVwSCxJQUFJLHNCQUFzQixzQkFBc0IsSUFBSSxHQUNoRCxnQkFBZ0IsdUJBQXVCLEdBQUc7RUFFbEQsT0FDSyxJQUFJLFVBQVUsT0FBTyxXQUFXLElBQUksR0FDckMsZ0JBQWdCLHVCQUF1QixHQUFHO09BRzFDLHNCQUFzQixPQUFPO0NBRXJDO0NBQ0EsT0FBTztBQUNYO0FBRUEsSUFBSSwwQkFBMEIsT0FBTyxTQUFTO0NBQzFDLE1BQU0sV0FBVyxLQUFLLE1BQU0sR0FBRztDQUMvQixNQUFNLFVBQVUsQ0FBQztDQUNqQixJQUFJLFNBQVMsU0FBUztDQUN0QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLFVBQVUsTUFBTSxTQUFTLE1BQzFELElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLEtBQUssTUFBTSxJQUFJLE1BQU0sR0FDeEMsUUFBUSxLQUFLLEdBQUcsT0FBTyxHQUFHLFNBQVMsSUFBSTtDQUcvQyxPQUFPO0FBQ1g7QUFFQSxJQUFJLG1CQUFtQixPQUFPLEVBQUUsZUFBZSxhQUFhLGlCQUFpQixZQUFZLEtBQUssSUFDeEYsUUFDQSxnQkFDSSxVQUFVLEtBQ04sTUFDQSxRQUNJLENBQUMsUUFDRCxRQUNSLGVBQWUsU0FBUyxLQUFLLElBQ3pCLElBQUksS0FBSyxLQUFLLElBQ2QsYUFDSSxXQUFXLEtBQUssSUFDaEI7QUFFbEIsU0FBUyxjQUFjLElBQUk7Q0FDdkIsTUFBTSxNQUFNLEdBQUc7Q0FDZixJQUFJLFlBQVksR0FBRyxHQUNmLE9BQU8sSUFBSTtDQUVmLElBQUksYUFBYSxHQUFHLEdBQ2hCLE9BQU8sY0FBYyxHQUFHLElBQUksQ0FBQyxDQUFDO0NBRWxDLElBQUksaUJBQWlCLEdBQUcsR0FDcEIsT0FBTyxDQUFDLEdBQUcsSUFBSSxlQUFlLENBQUMsQ0FBQyxLQUFLLEVBQUUsWUFBWSxLQUFLO0NBRTVELElBQUksZ0JBQWdCLEdBQUcsR0FDbkIsT0FBTyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsQ0FBQztDQUVyQyxPQUFPLGdCQUFnQixJQUFJLE9BQU8sRUFBRTtBQUN4QztBQUVBLElBQUksc0JBQXNCLGFBQWEsU0FBUyxjQUFjLDhCQUE4QjtDQUN4RixNQUFNLFNBQVMsQ0FBQztDQUNoQixLQUFLLE1BQU0sUUFBUSxhQUFhO0VBQzVCLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSTtFQUMvQixTQUFTLElBQUksUUFBUSxNQUFNLE1BQU0sRUFBRTtDQUN2QztDQUNBLE9BQU87RUFDSDtFQUNBLE9BQU8sQ0FBQyxHQUFHLFdBQVc7RUFDdEI7RUFDQTtDQUNKO0FBQ0o7QUFFQSxJQUFJLGdCQUFnQixTQUFTLFlBQVksSUFBSSxJQUN2QyxPQUNBLFFBQVEsSUFBSSxJQUNSLEtBQUssU0FDTCxTQUFTLElBQUksSUFDVCxRQUFRLEtBQUssS0FBSyxJQUNkLEtBQUssTUFBTSxTQUNYLEtBQUssUUFDVDtBQUVkLElBQU0saUJBQWlCO0FBQ3ZCLElBQUksd0JBQXdCLG1CQUFtQjtDQUMzQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsZUFBZSxVQUNuQyxPQUFPO0NBQ1gsSUFBSSxXQUFXLGVBQWUsUUFBUSxHQUNsQyxPQUFPLGVBQWUsU0FBUyxZQUFZLFNBQVM7Q0FFeEQsSUFBSSxTQUFTLGVBQWUsUUFBUSxHQUMzQjtPQUFBLE1BQU0sT0FBTyxlQUFlLFVBQzdCLElBQUksZUFBZSxTQUFTLElBQUksQ0FBQyxZQUM1QixTQUFTLGdCQUNWLE9BQU87Q0FBQTtDQUluQixPQUFPO0FBQ1g7QUFFQSxJQUFJLGlCQUFpQixZQUFZLFFBQVEsVUFDcEMsUUFBUSxZQUNKLENBQUMsWUFBWSxRQUFRLFFBQVEsS0FBSyxRQUFRLGFBQWEsU0FDeEQsQ0FBQyxZQUFZLFFBQVEsR0FBRyxLQUN4QixDQUFDLFlBQVksUUFBUSxHQUFHLEtBQ3hCLENBQUMsWUFBWSxRQUFRLFNBQVMsS0FDOUIsQ0FBQyxZQUFZLFFBQVEsU0FBUyxLQUM5QixRQUFRLFdBQ1IsUUFBUTtBQUVoQixTQUFTLGtCQUFrQixRQUFRLFNBQVMsTUFBTTtDQUM5QyxNQUFNLFFBQVEsSUFBSSxRQUFRLElBQUk7Q0FDOUIsSUFBSyxVQUFVLE1BQU0sUUFBUSxNQUFNLFlBQWEsTUFBTSxRQUFRLEtBQUssR0FDL0QsT0FBTztFQUNIO0VBQ0E7Q0FDSjtDQUVKLE1BQU0sUUFBUSxLQUFLLE1BQU0sR0FBRztDQUM1QixPQUFPLE1BQU0sUUFBUTtFQUNqQixNQUFNLFlBQVksTUFBTSxLQUFLLEdBQUc7RUFDaEMsTUFBTSxRQUFRLElBQUksU0FBUyxTQUFTO0VBQ3BDLE1BQU0sYUFBYSxJQUFJLFFBQVEsU0FBUztFQUN4QyxJQUFJLFNBQVMsQ0FBQyxNQUFNLFFBQVEsS0FBSyxLQUFLLFNBQVMsV0FDM0MsT0FBTyxFQUFFLEtBQUs7RUFFbEIsSUFBSSxjQUFjLFdBQVcsTUFDekIsT0FBTztHQUNILE1BQU07R0FDTixPQUFPO0VBQ1g7RUFFSixJQUFJLGNBQWMsV0FBVyxRQUFRLFdBQVcsS0FBSyxNQUNqRCxPQUFPO0dBQ0gsTUFBTSxHQUFHLFVBQVU7R0FDbkIsT0FBTyxXQUFXO0VBQ3RCO0VBRUosTUFBTSxJQUFJO0NBQ2Q7Q0FDQSxPQUFPLEVBQ0gsS0FDSjtBQUNKO0FBRUEsSUFBSSx5QkFBeUIsZUFBZSxpQkFBaUIsV0FBVztDQUNwRSxNQUFNLE9BQU8sT0FBTyxLQUFLLGFBQWEsQ0FBQyxDQUFDLFFBQVEsUUFBUSxRQUFRLE1BQU07Q0FDdEUsT0FBUSxDQUFDLEtBQUssVUFDVCxVQUFVLEtBQUssVUFBVSxPQUFPLEtBQUssZUFBZSxDQUFDLENBQUMsVUFDdkQsS0FBSyxNQUFNLFFBQVEsZ0JBQWdCLFVBQzlCLENBQUMsVUFBVSxnQkFBZ0IsSUFBSTtBQUM1QztBQUVBLElBQU0sZUFBZSxhQUFhLFlBQVksVUFBVSxRQUNsRCxnQkFBZ0IsY0FBYyxZQUFZLFdBQVcsYUFBYSxHQUFHLElBQ3JFLFlBQVksV0FBVyxVQUFVLEtBQUssV0FBVyxXQUFXLFdBQVc7QUFDN0UsSUFBSSx5QkFBeUIsTUFBTSxZQUFZLFVBQVU7Q0FDckQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUFjLFNBQVMsWUFDakMsT0FBTztDQUVYLElBQUksQ0FBQyxNQUFNLFFBQVEsSUFBSSxHQUNuQixPQUFPLFlBQVksTUFBTSxZQUFZLEtBQUs7Q0FFOUMsS0FBSyxNQUFNLGVBQWUsTUFDdEIsSUFBSSxlQUFlLFlBQVksYUFBYSxZQUFZLEtBQUssR0FDekQsT0FBTztDQUdmLE9BQU87QUFDWDtBQUVBLElBQUksa0JBQWtCLGFBQWEsV0FBVyxhQUFhLGdCQUFnQixTQUFTO0NBQ2hGLElBQUksS0FBSyxTQUNMLE9BQU87TUFFTixJQUFJLENBQUMsZUFBZSxLQUFLLFdBQzFCLE9BQU8sRUFBRSxhQUFhO01BRXJCLElBQUksY0FBYyxlQUFlLFdBQVcsS0FBSyxVQUNsRCxPQUFPLENBQUM7TUFFUCxJQUFJLGNBQWMsZUFBZSxhQUFhLEtBQUssWUFDcEQsT0FBTztDQUVYLE9BQU87QUFDWDtBQUVBLElBQUksbUJBQW1CLEtBQUssU0FBUztDQUNqQyxNQUFNLFFBQVEsSUFBSSxLQUFLLElBQUk7Q0FDM0IsQ0FBQyxRQUFRLEtBQUssQ0FBQyxDQUFDLFVBQ1osRUFBRSxTQUFTLE1BQU0sU0FDakIsTUFBTSxLQUFLLElBQUk7QUFDdkI7QUFFQSxJQUFNLGlCQUFpQjtDQUNuQixNQUFNLGdCQUFnQjtDQUN0QixnQkFBZ0IsZ0JBQWdCO0NBQ2hDLGtCQUFrQjtBQUN0QjtBQUNBLElBQU0sNkJBQTZCLGFBQWEsb0JBQW9CO0NBQ2hFLEtBQUssTUFBTSxPQUFPLGFBQ2QsT0FBTyxZQUFZO0NBRXZCLE9BQU8sT0FBTyxhQUFhLGVBQWU7QUFDOUM7QUFDQSxJQUFNLHFCQUFxQjtDQUN2QixhQUFhO0NBQ2IsU0FBUztDQUNULFNBQVM7Q0FDVCxjQUFjO0NBQ2QsYUFBYTtDQUNiLGNBQWM7Q0FDZCxvQkFBb0I7Q0FDcEIsU0FBUztDQUNULGVBQWUsQ0FBQztDQUNoQixhQUFhLENBQUM7Q0FDZCxrQkFBa0IsQ0FBQztBQUN2QjtBQUNBLFNBQVMsa0JBQWtCLFFBQVEsQ0FBQyxHQUFHO0NBQ25DLElBQUksV0FBVztFQUNYLEdBQUc7RUFDSCxHQUFHO0NBQ1A7Q0FDQSxJQUFJLGFBQWE7RUFDYixHQUFHLFlBQVksa0JBQWtCO0VBQ2pDLFdBQVcsV0FBVyxTQUFTLGFBQWE7RUFDNUMsUUFBUSxTQUFTLFVBQVUsQ0FBQztFQUM1QixVQUFVLFNBQVMsWUFBWTtDQUNuQztDQUNBLElBQUksVUFBVSxDQUFDO0NBQ2YsSUFBSSxpQkFBaUIsU0FBUyxTQUFTLGFBQWEsS0FBSyxTQUFTLFNBQVMsTUFBTSxJQUMzRSxZQUFZLFNBQVMsaUJBQWlCLFNBQVMsTUFBTSxLQUFLLENBQUMsSUFDM0QsQ0FBQztDQUNQLElBQUksY0FBYyxTQUFTLG1CQUNyQixDQUFDLElBQ0QsWUFBWSxjQUFjO0NBQ2hDLElBQUksU0FBUztFQUNULFFBQVE7RUFDUixvQ0FBb0IsSUFBSSxJQUFJO0VBQzVCLE9BQU87RUFDUCxPQUFPO0VBQ1AsYUFBYTtDQUNqQjtDQUNBLElBQUksb0JBQW9CO0NBQ3hCLElBQUksU0FBUztFQUNULHVCQUFPLElBQUksSUFBSTtFQUNmLDBCQUFVLElBQUksSUFBSTtFQUNsQix5QkFBUyxJQUFJLElBQUk7RUFDakIsdUJBQU8sSUFBSSxJQUFJO0VBQ2YsdUJBQU8sSUFBSSxJQUFJO0VBQ2YsOEJBQWMsSUFBSSxJQUFJO0NBQzFCO0NBQ0EsTUFBTSxzQkFBc0IsQ0FBQztDQUM3QixNQUFNLFNBQVMsQ0FBQztDQUNoQixNQUFNLHFDQUFxQixJQUFJLElBQUk7Q0FDbkMsSUFBSSw4QkFBOEIsbUJBQW1CLFNBQVMsSUFBSTtDQUNsRSxJQUFJLDZCQUE2QixtQkFBbUIsU0FBUyxjQUFjO0NBQzNFLE1BQU0sd0JBQXdCO0VBQzFCLFNBQVM7RUFDVCxhQUFhO0VBQ2Isa0JBQWtCO0VBQ2xCLGVBQWU7RUFDZixjQUFjO0VBQ2QsU0FBUztFQUNULFFBQVE7Q0FDWjtDQUNBLE1BQU0sa0JBQWtCLEVBQ3BCLEdBQUcsc0JBQ1A7Q0FDQSxNQUFNLDJCQUEyQixDQUFDO0NBQ2xDLE1BQU0sY0FBYyxHQUFHLFNBQVMsS0FBSyxNQUFNLFFBQVEsZ0JBQWdCLFFBQVEseUJBQXlCLElBQUk7Q0FDeEcsTUFBTSx3QkFBd0IsU0FBUztFQUNuQyxLQUFLLE1BQU0sY0FBYyxvQkFDckIsSUFBSSxzQkFBc0IsV0FBVyxNQUFNLE1BQU0sV0FBVyxLQUFLLEdBQzdELE9BQU87RUFHZixPQUFPO0NBQ1g7Q0FDQSxNQUFNLFlBQVk7RUFDZCxPQUFPLGNBQWM7RUFDckIsT0FBTyxjQUFjO0NBQ3pCO0NBQ0EsSUFBSSxrQkFBa0I7Q0FDdEIsSUFBSSxlQUFlO0NBQ25CLElBQUksbUNBQW1DLFNBQVMsaUJBQWlCLGdCQUFnQjtDQUNqRixNQUFNLFlBQVksTUFBTSxjQUFjLFNBQVM7RUFDM0MsYUFBYSxPQUFPLEtBQUs7RUFDekIsT0FBTyxRQUFRLFdBQVcsVUFBVSxJQUFJO0NBQzVDO0NBQ0EsTUFBTSxzQkFBc0IsU0FBUztFQUNqQyxhQUFhLE9BQU8sS0FBSztFQUN6QixPQUFPLE9BQU87RUFDZCxPQUFPLG9CQUFvQjtDQUMvQjtDQUNBLE1BQU0sMEJBQTBCLFNBQVM7RUFDckMsbUJBQW1CLElBQUk7RUFDdkIsTUFBTSxTQUFTLEdBQUcsS0FBSztFQUN2QixLQUFLLE1BQU0sT0FBTyxPQUFPLEtBQUssbUJBQW1CLEdBQzdDLElBQUksV0FBVyxNQUFNLEtBQUssbUJBQW1CLEdBQUc7Q0FFeEQ7Q0FDQSxNQUFNLFlBQVksT0FBTyxzQkFBc0I7RUFDM0MsSUFBSSxPQUFPLGFBQ1A7RUFFSixJQUFJLENBQUMsU0FBUyxhQUFhLFdBQVcsU0FBUyxLQUFLLG9CQUFvQjtHQUNwRSxNQUFNLFNBQVMsRUFBRTtHQUNqQixJQUFJO0dBQ0osSUFBSSxTQUFTLFVBQVU7SUFDbkIsVUFBVSxlQUFlLE1BQU0sV0FBVyxFQUFBLENBQUcsTUFBTTtJQUNuRCxXQUFXLG1CQUFtQixvQkFBb0I7R0FDdEQsT0FFSSxVQUFVLE1BQU0seUJBQXlCO0lBQ3JDLFFBQVE7SUFDUixnQkFBZ0I7SUFDaEIsV0FBVyxPQUFPO0dBQ3RCLENBQUM7R0FFTCxJQUFJLFdBQVcsbUJBQW1CLFlBQVksV0FBVyxTQUNyRCxVQUFVLE1BQU0sS0FBSyxFQUNqQixRQUNKLENBQUM7RUFFVDtDQUNKO0NBQ0EsTUFBTSx1QkFBdUIsT0FBTyxpQkFBaUI7RUFDakQsSUFBSSxDQUFDLFNBQVMsWUFBWSxXQUFXLGdCQUFnQixrQkFBa0IsR0FBRztHQUN0RSxDQUFDLFNBQVMsT0FBTyxNQUFBLENBQU8sU0FBUyxTQUFTO0lBQ3RDLElBQUksTUFDQSxlQUNNLElBQUksV0FBVyxrQkFBa0IsTUFBTSxZQUFZLElBQ25ELE1BQU0sV0FBVyxrQkFBa0IsSUFBSTtHQUVyRCxDQUFDO0dBQ0QsVUFBVSxNQUFNLEtBQUs7SUFDakIsa0JBQWtCLFdBQVc7SUFDN0IsY0FBYyxDQUFDLGNBQWMsV0FBVyxnQkFBZ0I7R0FDNUQsQ0FBQztFQUNMO0NBQ0o7Q0FDQSxNQUFNLDJCQUEyQjtFQUM3QixXQUFXLGNBQWMsZUFBZSxnQkFBZ0IsYUFBYSxLQUFBLEdBQVcsT0FBTztDQUMzRjtDQUNBLE1BQU0sa0JBQWtCLE1BQU0sU0FBUyxDQUFDLEdBQUcsUUFBUSxNQUFNLGtCQUFrQixNQUFNLDZCQUE2QixTQUFTO0VBQ25ILElBQUksUUFBUSxVQUFVLENBQUMsU0FBUyxVQUFVO0dBQ3RDLE9BQU8sU0FBUztHQUNoQixNQUFNLFNBQVMsSUFBSSxTQUFTLElBQUk7R0FDaEMsSUFBSSxDQUFDLE9BQU8sbUJBQW1CLElBQUksSUFBSSxHQUNuQyxPQUFPLG1CQUFtQixJQUFJLE1BQU0sTUFBTSxRQUFRLE1BQU0sSUFBSSxPQUFPLFNBQVMsQ0FBQztHQUVqRixJQUFJLDhCQUE4QixNQUFNLFFBQVEsTUFBTSxHQUFHO0lBQ3JELE1BQU0sY0FBYyxPQUFPLFFBQVEsS0FBSyxNQUFNLEtBQUssSUFBSTtJQUN2RCxtQkFBbUIsSUFBSSxTQUFTLE1BQU0sV0FBVztHQUNyRDtHQUNBLE1BQU0sbUJBQW1CLElBQUksV0FBVyxRQUFRLElBQUk7R0FDcEQsSUFBSSw4QkFBOEIsTUFBTSxRQUFRLGdCQUFnQixHQUFHO0lBQy9ELE1BQU0sWUFBWSxpQkFBaUI7SUFDbkMsTUFBTSxTQUFTLE9BQU8sa0JBQWtCLEtBQUssTUFBTSxLQUFLLElBQUksS0FBSztJQUNqRSxJQUFJLFdBQ0EsT0FBTyxPQUFPO0lBRWxCLG1CQUFtQixJQUFJLFdBQVcsUUFBUSxNQUFNLE1BQU07SUFDdEQsZ0JBQWdCLFdBQVcsUUFBUSxJQUFJO0lBQ3ZDLFdBQVcsU0FBUyxFQUFFLEdBQUcsV0FBVyxPQUFPO0dBQy9DO0dBQ0EsTUFBTSxxQkFBcUIsSUFBSSxXQUFXLGVBQWUsSUFBSTtHQUM3RCxNQUFNLDRCQUE0Qiw4QkFBOEIsTUFBTSxRQUFRLGtCQUFrQjtHQUNoRyxJQUFJLDJCQUEyQjtJQUMzQixNQUFNLGdCQUFnQixPQUFPLG9CQUFvQixLQUFLLE1BQU0sS0FBSyxJQUFJO0lBQ3JFLG1CQUFtQixJQUFJLFdBQVcsZUFBZSxNQUFNLGFBQWE7R0FDeEU7R0FDQSxNQUFNLG1CQUFtQixJQUFJLFdBQVcsYUFBYSxJQUFJO0dBQ3pELElBQUksOEJBQThCLE1BQU0sUUFBUSxnQkFBZ0IsR0FBRztJQUMvRCxNQUFNLGNBQWMsT0FBTyxrQkFBa0IsS0FBSyxNQUFNLEtBQUssSUFBSSxLQUFLO0lBQ3RFLG1CQUFtQixJQUFJLFdBQVcsYUFBYSxNQUFNLFdBQVc7R0FDcEU7R0FDQSxJQUFJLFdBQVcsYUFBYSxHQUN4QixtQkFBbUI7UUFHbkIsb0JBQW9CO0dBRXhCLFVBQVUsTUFBTSxLQUFLO0lBQ2pCO0lBQ0EsU0FBUyxVQUFVLE1BQU0sTUFBTTtJQUMvQixhQUFhLFdBQVc7SUFDeEIsR0FBSSw2QkFBNkIsRUFDN0IsZUFBZSxXQUFXLGNBQzlCO0lBQ0EsUUFBUSxXQUFXO0lBQ25CLFNBQVMsV0FBVztHQUN4QixDQUFDO0VBQ0wsT0FFSSxJQUFJLGFBQWEsTUFBTSxNQUFNO0NBRXJDO0NBQ0EsTUFBTSxnQkFBZ0IsTUFBTSxVQUFVO0VBQ2xDLElBQUksV0FBVyxRQUFRLE1BQU0sS0FBSztFQUNsQyxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztFQUMzQyxVQUFVLE1BQU0sS0FBSyxFQUNqQixRQUFRLFdBQVcsT0FDdkIsQ0FBQztDQUNMO0NBQ0EsTUFBTSxjQUFjLFdBQVc7RUFDM0IsT0FBTyxLQUFLLG1CQUFtQixDQUFDLENBQUMsUUFBUSxrQkFBa0I7RUFDM0QsTUFBTSxZQUFZLENBQUMsY0FBYyxNQUFNO0VBQ3ZDLFdBQVcsU0FBUztFQUNwQixVQUFVLE1BQU0sS0FBSztHQUNqQixRQUFRLFdBQVc7R0FDbkIsR0FBSSxZQUFZLEVBQUUsU0FBUyxNQUFNLElBQUksQ0FBQztFQUMxQyxDQUFDO0VBQ0QsQ0FBQyxhQUFhLE9BQU8sU0FBUyxVQUFVO0NBQzVDO0NBQ0EsTUFBTSwrQkFBK0IsU0FBUztFQUMxQyxNQUFNLFdBQVcsTUFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksYUFBYSxJQUFJO0VBQ3pELElBQUksYUFBYTtFQUNqQixJQUFJLGdCQUFnQjtFQUNwQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksU0FBUyxTQUFTLEdBQUcsS0FBSztHQUMxQyxNQUFNLE1BQU0sU0FBUztHQUNyQixhQUFhLGtCQUFrQixVQUFVLElBQUksYUFBYSxXQUFXO0dBQ3JFLGdCQUFnQixrQkFBa0IsYUFBYSxJQUN6QyxnQkFDQSxjQUFjO0dBQ3BCLElBQUksZUFBZSxRQUFRLGtCQUFrQixNQUN6QyxPQUFPO0VBRWY7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxNQUFNLHFCQUFxQixTQUFTO0VBQ2hDLElBQUksQ0FBQyxPQUFPLG1CQUFtQixNQUMzQixPQUFPO0VBRVgsTUFBTSxXQUFXLE1BQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLGFBQWEsSUFBSTtFQUN6RCxJQUFJLE9BQU87RUFDWCxJQUFJLE9BQU87RUFDWCxJQUFJLGFBQWE7RUFDakIsSUFBSSx1QkFBdUI7RUFDM0IsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsUUFBUSxLQUFLO0dBQ3RDLElBQUksa0JBQWtCLElBQUksR0FDdEIsT0FBTztHQUVYLE1BQU0sTUFBTSxTQUFTO0dBQ3JCLE9BQU8sT0FBTyxHQUFHLEtBQUssR0FBRyxRQUFRO0dBQ2pDLElBQUksTUFBTSxRQUFRLElBQUksS0FBSyxDQUFDLE9BQU8sS0FBSyxRQUNwQyxPQUFPLGVBQWUsS0FDaEIsUUFDQSxNQUFNLGFBQ0YsQ0FBQyxNQUFNLHVCQUNQO0dBRWQsSUFBSSxPQUFPLG1CQUFtQixJQUFJLElBQUksR0FBRztJQUNyQyxhQUFhLElBQUk7SUFDakIsdUJBQXVCLE9BQU8sbUJBQW1CLElBQUksSUFBSTtHQUM3RDtHQUNBLE9BQU8sS0FBSztHQUNaLElBQUksWUFBWSxJQUFJLEtBQ2hCLGVBQWUsTUFDZixJQUFJLGNBQ0osQ0FBQyxTQUFTLGNBQWMsc0JBQ3hCLE9BQU87RUFFZjtFQUNBLE9BQU87Q0FDWDtDQUNBLE1BQU0sdUJBQXVCLE1BQU0sc0JBQXNCLE9BQU8sUUFBUTtFQUNwRSxNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDL0IsSUFBSSxPQUFPO0dBQ1AsSUFBSSw0QkFBNEIsSUFBSSxLQUFLLGtCQUFrQixJQUFJLEdBQzNEO0dBRUosTUFBTSx1QkFBdUIsWUFBWSxJQUFJLGFBQWEsSUFBSSxDQUFDO0dBQy9ELE1BQU0sZUFBZSxJQUFJLGFBQWEsTUFBTSxZQUFZLEtBQUssSUFBSSxJQUFJLGdCQUFnQixJQUFJLElBQUksS0FBSztHQUNsRyxNQUFNLHNCQUFzQixDQUFDLENBQUMsT0FBTyxDQUFDLFdBQVcsV0FBVyxTQUFTLEdBQUc7R0FDeEUsSUFBSSxZQUFZLFlBQVksS0FDdkIsT0FBTyxJQUFJLGtCQUNaLHVCQUNBLHNCQUFzQjtJQUN0QixNQUFNLGFBQWEsdUJBQ2IsZUFDQSxjQUFjLE1BQU0sRUFBRTtJQUM1QixJQUFJLFdBQVcsYUFBYSxLQUN4QixDQUFDLFVBQVUsSUFBSSxhQUFhLElBQUksR0FBRyxVQUFVLEdBQzdDLG9CQUFvQjtJQUV4QixJQUFJLGFBQWEsTUFBTSxVQUFVO0lBQ2pDLElBQUkscUJBQ0Esb0JBQW9CLE1BQU0sVUFBVTtHQUU1QyxPQUVJLGNBQWMsTUFBTSxZQUFZO0dBRXBDLElBQUksT0FBTyxTQUFTLENBQUMsT0FBTyxRQUFRO0lBQ2hDLElBQUksU0FBUyxZQUNULFdBQVcsZ0JBQWdCLGtCQUFrQixHQUM3QyxRQUFRLFFBQVEsQ0FBQyxDQUFDLFdBQVcsVUFBVSxDQUFDO1NBR3hDLFVBQVU7SUFFZCxJQUFJLHdCQUNBLFdBQVcsV0FDWCxXQUFXLFNBQVMsR0FFaEI7U0FBQSxDQURZLFVBQ0wsR0FBRztNQUNWLFdBQVcsVUFBVTtNQUNyQixVQUFVLE1BQU0sS0FBSyxFQUFFLEdBQUcsV0FBVyxDQUFDO0tBQzFDOztJQUVKLElBQUksU0FBUyxvQkFDVCx3QkFDQSxDQUFDLFlBQVksSUFBSSxhQUFhLElBQUksQ0FBQyxLQUNuQyxVQUFVLE1BQU0sTUFBTSxHQUN0QixPQUFPLFFBQVE7R0FFdkI7RUFDSjtDQUNKO0NBQ0EsTUFBTSx1QkFBdUIsTUFBTSxZQUFZLGFBQWEsYUFBYSxpQkFBaUI7RUFDdEYsSUFBSSxvQkFBb0I7RUFDeEIsSUFBSSxrQkFBa0I7RUFDdEIsTUFBTSxTQUFTLEVBQ1gsS0FDSjtFQUdBLElBQUksQ0FBQyxTQUFTLFlBQVksZ0JBQWdCLE1BQU07R0FDNUMsSUFBSSxDQUFDLGVBQWUsYUFBYTtJQUM3QixNQUFNLHlCQUF5QixVQUFVLElBQUksZ0JBQWdCLElBQUksR0FBRyxVQUFVO0lBQzlFLElBQUksV0FBVyxTQUFTLEdBQUc7S0FDdkIsa0JBQWtCLFdBQVc7S0FDN0IsV0FBVyxVQUFVLE9BQU8sVUFDeEIsQ0FBQywwQkFBMEIsVUFBVTtLQUN6QyxvQkFBb0Isb0JBQW9CLE9BQU87SUFDbkQ7SUFDQSxrQkFBa0IsQ0FBQyxDQUFDLElBQUksV0FBVyxhQUFhLElBQUk7SUFDcEQsSUFBSSx3QkFDQSxNQUFNLFdBQVcsYUFBYSxJQUFJO1NBRWpDO0tBQ0QsTUFBTSxvQkFBb0IsSUFBSSxnQkFBZ0IsSUFBSTtLQUNsRCxNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7S0FDL0IsTUFBTSxhQUFhLEVBQUUsU0FBUyxNQUFNLFFBQy9CLFNBQVMsaUJBQWlCLEtBQUssTUFBTSxRQUFRLGlCQUFpQixLQUM3RCxlQUFlLG1CQUFtQixZQUFZLEtBQUEsR0FBVyxLQUFLLElBQzlEO0tBQ04sSUFBSSxXQUFXLGFBQWEsTUFBTSxVQUFVO0lBQ2hEO0lBQ0EsSUFBSSx1QkFBdUI7SUFDM0IsSUFBSSxxQkFDQywyQkFDSSxXQUFXLFNBQVMsSUFBSSxXQUFXLFVBQVUsVUFBVSxJQUFLO0tBQ2pFLG9CQUFvQjtLQUNwQixNQUFNLGtCQUFrQixlQUFlLGdCQUFnQixhQUFhLEtBQUEsR0FBVyxPQUFPO0tBQ3RGLElBQUksQ0FBQyxVQUFVLFdBQVcsYUFBYSxlQUFlLEdBQUc7TUFDckQsdUJBQXVCO01BQ3ZCLDBCQUEwQixXQUFXLGFBQWEsZUFBZTtLQUNyRTtJQUNKO0lBQ0EsT0FBTyxjQUFjLFdBQVc7SUFDaEMsb0JBQ0kscUJBQ0ssV0FBVyxhQUFhLE1BQ3BCLHdCQUNHLG9CQUFvQixDQUFDO0dBQ3pDO0dBQ0EsSUFBSSxhQUFhO0lBQ2IsTUFBTSx5QkFBeUIsSUFBSSxXQUFXLGVBQWUsSUFBSSxJQUMzRCxJQUFJLFdBQVcsZUFBZSxJQUFJLElBQ2xDLEtBQUE7SUFDTixJQUFJLENBQUMsd0JBQXdCO0tBQ3pCLElBQUksV0FBVyxlQUFlLE1BQU0sV0FBVztLQUMvQyxPQUFPLGdCQUFnQixXQUFXO0tBQ2xDLG9CQUNJLHFCQUNLLFdBQVcsZUFBZSxLQUN2QiwyQkFBMkI7SUFDM0M7R0FDSjtHQUNBLHFCQUFxQixnQkFBZ0IsVUFBVSxNQUFNLEtBQUssTUFBTTtFQUNwRTtFQUNBLE9BQU8sb0JBQW9CLFNBQVMsQ0FBQztDQUN6QztDQUNBLE1BQU0sdUJBQXVCLE1BQU0sU0FBUyxPQUFPLGVBQWU7RUFDOUQsTUFBTSxxQkFBcUIsSUFBSSxXQUFXLFFBQVEsSUFBSTtFQUN0RCxNQUFNLG9CQUFvQixXQUFXLFNBQVMsS0FDMUMsVUFBVSxPQUFPLEtBQ2pCLFdBQVcsWUFBWTtFQUMzQixJQUFJLFNBQVMsY0FBYyxPQUFPO0dBQzlCLG9CQUFvQixRQUFRLFNBQVMsWUFBWSxhQUFhLE1BQU0sS0FBSyxDQUFDO0dBQzFFLG9CQUFvQixLQUFLLENBQUMsU0FBUyxVQUFVO0VBQ2pELE9BQ0s7R0FDRCxtQkFBbUIsSUFBSTtHQUN2QixRQUNNLElBQUksV0FBVyxRQUFRLE1BQU0sS0FBSyxJQUNsQyxNQUFNLFdBQVcsUUFBUSxJQUFJO0dBQ25DLFdBQVcsU0FBUyxFQUFFLEdBQUcsV0FBVyxPQUFPO0VBQy9DO0VBQ0EsS0FBSyxRQUNDLENBQUMsVUFBVSxvQkFBb0IsT0FBTyxJQUFJLElBQzFDLHVCQUNGLENBQUMsY0FBYyxVQUFVLEtBQ3pCLG1CQUFtQjtHQUNuQixNQUFNLG1CQUFtQjtJQUNyQixHQUFHO0lBQ0gsR0FBSSxxQkFBcUIsVUFBVSxPQUFPLElBQUksRUFBRSxRQUFRLElBQUksQ0FBQztJQUM3RCxRQUFRLFdBQVc7SUFDbkI7R0FDSjtHQUNBLFVBQVUsTUFBTSxLQUFLLGdCQUFnQjtFQUN6QztDQUNKO0NBQ0EsTUFBTSxhQUFhLE9BQU8sU0FBUztFQUMvQixvQkFBb0IsTUFBTSxJQUFJO0VBQzlCLE9BQU8sTUFBTSxTQUFTLFNBQVMsYUFBYSxTQUFTLFNBQVMsbUJBQW1CLFFBQVEsT0FBTyxPQUFPLFNBQVMsU0FBUyxjQUFjLFNBQVMseUJBQXlCLENBQUM7Q0FDOUs7Q0FDQSxNQUFNLDhCQUE4QixPQUFPLFVBQVU7RUFDakQsTUFBTSxjQUFjO0VBQ3BCLE1BQU0sRUFBRSxXQUFXLE1BQU0sV0FBVyxLQUFLO0VBQ3pDLElBQUksZ0JBQWdCLGNBQ2hCLE9BQU87RUFFWCxvQkFBb0IsS0FBSztFQUN6QixJQUFJLE9BQU87R0FDUCxLQUFLLE1BQU0sUUFBUSxPQUFPO0lBQ3RCLE1BQU0sUUFBUSxJQUFJLFFBQVEsSUFBSTtJQUM5Qix1QkFBdUIsSUFBSTtJQUMzQixNQUFNLHdCQUF3QixPQUFPLE1BQU0sSUFBSSxJQUFJLEtBQy9DLFNBQVMsS0FBSyxLQUNkLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxDQUFDLE1BQU0sUUFBUSxDQUFDLE9BQU8sTUFBTSxPQUFPLEdBQUcsQ0FBQyxDQUFDO0lBQ2hFLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSTtJQUMvQixNQUFNLGtCQUFrQixTQUFTLEtBQUssS0FBSyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUMsTUFBTSxRQUFRLFFBQVEsSUFBSTtJQUN4Rix3QkFDTSwwQkFBMEIsV0FBVyxRQUFRLEdBQUcsT0FBTyxNQUFNLEdBQUcsSUFBSSxJQUNuRSxVQUFVLE1BQU0sUUFBUSxNQUFNLFlBQzdCLE1BQU0sUUFBUSxLQUFLLEtBQ2xCLFNBQVMsS0FBSyxLQUFLLGtCQUNsQixJQUFJLFdBQVcsUUFBUSxNQUFNLEtBQUssSUFDbEMsTUFBTSxXQUFXLFFBQVEsSUFBSTtHQUMzQztHQUNBLFdBQVcsU0FBUyxFQUFFLEdBQUcsV0FBVyxPQUFPO0VBQy9DLE9BQ0s7R0FDRCxPQUFPLEtBQUssbUJBQW1CLENBQUMsQ0FBQyxRQUFRLGtCQUFrQjtHQUMzRCxXQUFXLFNBQVM7RUFDeEI7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxNQUFNLGVBQWUsT0FBTyxFQUFFLE1BQU0sZ0JBQWlCO0VBQ2pELElBQUksU0FBUyxVQUFVO0dBQ25CLE1BQU0sY0FBYztHQUNwQixNQUFNLFNBQVMsTUFBTSxTQUFTLFNBQVM7SUFDbkMsWUFBWTtJQUNaLFdBQVc7SUFDWDtJQUNBO0dBQ0osQ0FBQztHQUNELElBQUksZ0JBQWdCLGNBQ2hCLE9BQU87R0FFWCxJQUFJLFNBQVMsTUFBTSxHQUFHO0lBQ2xCLElBQUksVUFBVTtJQUNkLFlBQVksZUFBZTtJQUMzQixLQUFLLE1BQU0sT0FBTyxRQUFRO0tBQ3RCLE1BQU0sUUFBUSxPQUFPO0tBQ3JCLElBQUksT0FBTztNQUNQLFVBQVU7TUFDVixTQUFTLEdBQUcsZ0JBQWdCLEdBQUcsT0FBTztPQUNsQyxTQUFTLFNBQVMsTUFBTSxPQUFPLElBQUksTUFBTSxVQUFVO09BQ25ELE1BQU0sTUFBTSxRQUFRLHVCQUF1QjtNQUMvQyxDQUFDO0tBQ0w7SUFDSjtJQUNBLE9BQU87R0FDWCxPQUNLLElBQUksU0FBUyxNQUFNLEtBQUssQ0FBQyxRQUFRO0lBQ2xDLFNBQVMsaUJBQWlCO0tBQ3RCLFNBQVMsVUFBVTtLQUNuQixNQUFNLHVCQUF1QjtJQUNqQyxDQUFDO0lBQ0QsT0FBTztHQUNYLE9BQ0s7SUFDRCxZQUFZLGVBQWU7SUFDM0IsT0FBTztHQUNYO0VBQ0o7RUFDQSxPQUFPO0NBQ1g7Q0FDQSxNQUFNLDJCQUEyQixPQUFPLEVBQUUsUUFBUSxnQkFBZ0IsTUFBTSxXQUFXLFVBQVU7RUFDekYsT0FBTztFQUNQLG1CQUFtQjtDQUN2QixRQUFTO0VBQ0wsTUFBTSxjQUFjO0VBQ3BCLElBQUksU0FBUyxZQUFZLENBQUMsUUFBUSxtQkFBbUI7R0FDakQsUUFBUSxvQkFBb0I7R0FLNUIsSUFBSSxDQUFDLE1BSmdCLGFBQWE7SUFDOUI7SUFDQTtHQUNKLENBQUMsR0FDWTtJQUNULFFBQVEsUUFBUTtJQUNoQixJQUFJLGdCQUNBLE9BQU8sUUFBUTtHQUV2QjtFQUNKO0VBQ0EsS0FBSyxNQUFNLFFBQVEsUUFBUTtHQUN2QixNQUFNLFFBQVEsT0FBTztHQUNyQixJQUFJLE9BQU87SUFDUCxNQUFNLEVBQUUsSUFBSSxHQUFHLGVBQWU7SUFDOUIsSUFBSSxJQUFJO0tBQ0osTUFBTSxtQkFBbUIsT0FBTyxNQUFNLElBQUksR0FBRyxJQUFJO0tBQ2pELE1BQU0sb0JBQW9CLE1BQU0sTUFBTSxxQkFBcUIsTUFBTSxFQUFFO0tBQ25FLE1BQU0sK0JBQStCLFdBQVcsZ0JBQWdCLGtCQUFrQjtLQUNsRixJQUFJLHFCQUFxQiw4QkFDckIsb0JBQW9CLENBQUMsR0FBRyxJQUFJLEdBQUcsSUFBSTtLQUV2QyxNQUFNLGFBQWEsTUFBTSxjQUFjLE9BQU8sT0FBTyxVQUFVLGFBQWEsa0NBQWtDLFNBQVMsNkJBQTZCLENBQUMsZ0JBQWdCLGdCQUFnQjtLQUNyTCxJQUFJLGdCQUFnQixjQUNoQixPQUFPLFFBQVE7S0FFbkIsSUFBSSxxQkFBcUIsOEJBQ3JCLG9CQUFvQixDQUFDLEdBQUcsSUFBSSxDQUFDO0tBRWpDLElBQUksV0FBVyxHQUFHLE9BQU87TUFDckIsUUFBUSxRQUFRO01BQ2hCLElBQUksZ0JBQ0E7S0FFUjtLQUNBLElBQUksQ0FBQyxnQkFBZ0I7TUFDakIsbUJBQW1CLEdBQUcsSUFBSTtNQUMxQixJQUFJLFlBQVksR0FBRyxJQUFJLElBQ2pCLG1CQUNJLDBCQUEwQixXQUFXLFFBQVEsWUFBWSxHQUFHLElBQUksSUFDaEUsSUFBSSxXQUFXLFFBQVEsR0FBRyxNQUFNLFdBQVcsR0FBRyxLQUFLLElBQ3ZELE1BQU0sV0FBVyxRQUFRLEdBQUcsSUFBSTtLQUMxQztLQUNBLElBQUksU0FBUyw2QkFBNkIsV0FBVyxHQUFHLE9BQ3BEO0lBRVI7SUFDQSxDQUFDLGNBQWMsVUFBVSxLQUNwQixNQUFNLHlCQUF5QjtLQUM1QjtLQUNBO0tBQ0EsUUFBUTtLQUNGO0tBQ047SUFDSixDQUFDO0dBQ1Q7RUFDSjtFQUNBLE9BQU8sUUFBUTtDQUNuQjtDQUNBLE1BQU0seUJBQXlCO0VBQzNCLEtBQUssTUFBTSxRQUFRLE9BQU8sU0FBUztHQUMvQixNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7R0FDL0IsVUFDSyxNQUFNLEdBQUcsT0FDSixNQUFNLEdBQUcsS0FBSyxPQUFPLFFBQVEsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUN2QyxDQUFDLEtBQUssTUFBTSxHQUFHLEdBQUcsTUFDeEIsV0FBVyxJQUFJO0VBQ3ZCO0VBQ0EsT0FBTywwQkFBVSxJQUFJLElBQUk7Q0FDN0I7Q0FDQSxNQUFNLGFBQWEsTUFBTSxVQUFVLFFBQVEsUUFBUSxJQUFJLGFBQWEsTUFBTSxJQUFJLEdBQzFFLENBQUMsVUFBVSxPQUFPLFFBQVEsY0FBYyxnQkFBZ0IsY0FBYztDQUMxRSxNQUFNLGFBQWEsT0FBTyxjQUFjLGFBQWE7RUFDakQsTUFBTSxTQUFTLE9BQU8sUUFDaEIsY0FDQSxZQUFZLFlBQVksS0FBSyxDQUFDLFlBQVksS0FBSyxJQUMzQyxpQkFDQTtFQUNWLE9BQU8sb0JBQW9CLE9BQU8sUUFBUSxZQUFZLEtBQUssSUFBSSxFQUFFLEdBQUcsT0FBTyxJQUFJLFFBQVEsVUFBVSxZQUFZO0NBQ2pIO0NBQ0EsTUFBTSxrQkFBa0IsU0FBUyxRQUFRLElBQUksT0FBTyxRQUFRLGNBQWMsZ0JBQWdCLE1BQU0sU0FBUyxtQkFBbUIsSUFBSSxnQkFBZ0IsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztDQUMvSixNQUFNLGlCQUFpQixNQUFNLE9BQU8sVUFBVSxDQUFDLEdBQUcsWUFBWSxPQUFPLGFBQWEsT0FBTyxrQkFBa0IsVUFBVTtFQUNqSCxNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDL0IsSUFBSSxhQUFhO0VBQ2pCLElBQUksT0FBTztHQUNQLE1BQU0saUJBQWlCLE1BQU07R0FDN0IsSUFBSSxnQkFBZ0I7SUFDaEIsQ0FBQyxlQUFlLFlBQ1osSUFBSSxhQUFhLE1BQU0sZ0JBQWdCLE9BQU8sY0FBYyxDQUFDO0lBQ2pFLGFBQ0ksY0FBYyxlQUFlLEdBQUcsS0FBSyxrQkFBa0IsS0FBSyxJQUN0RCxLQUNBO0lBQ1YsSUFBSSxpQkFBaUIsZUFBZSxHQUFHLEdBQ25DLENBQUMsR0FBRyxlQUFlLElBQUksT0FBTyxDQUFDLENBQUMsU0FBUyxjQUFlLFVBQVUsV0FBVyxXQUFXLFNBQVMsVUFBVSxLQUFLLENBQUU7U0FFakgsSUFBSSxlQUFlLE1BQU07S0FDMUIsSUFBSSxnQkFBZ0IsZUFBZSxHQUFHLEdBQ2xDLGVBQWUsS0FBSyxTQUFTLGdCQUFnQjtNQUN6QyxJQUFJLENBQUMsWUFBWSxrQkFBa0IsQ0FBQyxZQUFZLFVBQVU7T0FDdEQsSUFBSSxNQUFNLFFBQVEsVUFBVSxHQUN4QixZQUFZLFVBQVUsQ0FBQyxDQUFDLFdBQVcsTUFBTSxTQUFTLFNBQVMsWUFBWSxLQUFLO1lBRzVFLFlBQVksVUFDUixlQUFlLFlBQVksU0FBUyxDQUFDLENBQUM7TUFFbEQ7S0FDSixDQUFDO1VBR0QsZUFBZSxLQUFLLFNBQVMsYUFBYyxTQUFTLFVBQVUsU0FBUyxVQUFVLFVBQVc7SUFFcEcsT0FDSyxJQUFJLFlBQVksZUFBZSxHQUFHLEdBQ25DLGVBQWUsSUFBSSxRQUFRO1NBRTFCO0tBQ0QsZUFBZSxJQUFJLFFBQVE7S0FDM0IsSUFBSSxDQUFDLGVBQWUsSUFBSSxRQUFRLENBQUMsY0FBYyxDQUFDLGlCQUM1QyxVQUFVLE1BQU0sS0FBSztNQUNqQjtNQUNBLFFBQVEsWUFDRixjQUNBLHFCQUFxQixJQUFJLElBQ3JCLFlBQVksV0FBVyxJQUN2QixLQUFBO0tBQ2QsQ0FBQztJQUVUO0dBQ0o7RUFDSjtFQUNBLENBQUMsUUFBUSxlQUFlLFFBQVEsZ0JBQzVCLG9CQUFvQixNQUFNLFNBQ3RCLE1BQU0sTUFDTixDQUFDLE1BQU0sR0FBRyxhQUNULE1BQU0sR0FBRyxpQkFDTixNQUFNLEdBQUcsZUFDVCxNQUFNLEdBQUcsY0FDWCxnQkFBZ0IsT0FBTyxNQUFNLEVBQUUsSUFDL0IsWUFBWSxRQUFRLGFBQWEsUUFBUSxhQUFhLENBQUMsVUFBVTtFQUMzRSxRQUFRLGtCQUNKLFFBQVEsTUFBTSxFQUNWLFlBQVksUUFBUSxXQUN4QixDQUFDO0VBQ0wsSUFBSSxRQUFRLGtCQUNSLFNBQ0EsTUFBTSxNQUNOLE1BQU0sR0FBRyxTQUNSLENBQUMsTUFBTSxRQUFRLE1BQU0sR0FBRyxJQUFJLEtBQUssTUFBTSxHQUFHLEtBQUssU0FBUyxJQUN6RCxRQUFRLE1BQU0sR0FBRyxJQUFJO0NBRTdCO0NBQ0EsTUFBTSxrQkFBa0IsTUFBTSxPQUFPLFNBQVMsWUFBWSxPQUFPLGFBQWEsT0FBTyxrQkFBa0IsVUFBVTtFQUM3RyxJQUFJLE9BQU8sTUFBTSxJQUFJLElBQUksR0FDckIsVUFBVSxNQUFNLEtBQUs7R0FDakI7R0FDQSxRQUFRLFlBQVksY0FBYyxZQUFZLFdBQVc7RUFDN0QsQ0FBQztFQUVMLEtBQUssTUFBTSxZQUFZLE9BQU87R0FDMUIsSUFBSSxDQUFDLE1BQU0sZUFBZSxRQUFRLEdBQzlCO0dBRUosTUFBTSxhQUFhLE1BQU07R0FDekIsTUFBTSxZQUFZLE9BQU8sTUFBTTtHQUMvQixNQUFNLFFBQVEsSUFBSSxTQUFTLFNBQVM7R0FDcEMsQ0FBQyxPQUFPLE1BQU0sSUFBSSxJQUFJLEtBQ2xCLFNBQVMsVUFBVSxLQUNsQixTQUFTLENBQUMsTUFBTSxPQUNqQixDQUFDLGFBQWEsVUFBVSxJQUN0QixlQUFlLFdBQVcsWUFBWSxTQUFTLFdBQVcsWUFBWSxlQUFlLElBQ3JGLGNBQWMsV0FBVyxZQUFZLFNBQVMsV0FBVyxZQUFZLGVBQWU7RUFDOUY7Q0FDSjtDQUNBLE1BQU0sYUFBYSxNQUFNLE9BQU8sU0FBUyxXQUFXLGdCQUFnQixVQUFVO0VBQzFFLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSTtFQUMvQixNQUFNLGVBQWUsT0FBTyxNQUFNLElBQUksSUFBSTtFQUMxQyxNQUFNLGFBQWEsWUFBWSxRQUFRLFlBQVksS0FBSztFQUV4RCxNQUFNLG1CQUFtQixVQURILElBQUksYUFBYSxJQUNRLEdBQUcsVUFBVTtFQUM1RCxJQUFJLENBQUMsa0JBQ0QsSUFBSSxhQUFhLE1BQU0sVUFBVTtFQUVyQyxJQUFJLGNBQWM7R0FDZCxVQUFVLE1BQU0sS0FBSztJQUNqQjtJQUNBLFFBQVEsWUFBWSxjQUFjLFlBQVksV0FBVztHQUM3RCxDQUFDO0dBQ0QsSUFBSSxXQUFXLFdBQVcsYUFBYSxLQUFLLFFBQVEsYUFBYTtJQUM3RCxtQkFBbUI7SUFDbkIsSUFBSSxDQUFDLGVBQ0QsVUFBVSxNQUFNLEtBQUs7S0FDakI7S0FDQSxhQUFhLFdBQVc7S0FDeEIsU0FBUyxVQUFVLE1BQU0sVUFBVTtJQUN2QyxDQUFDO0dBRVQ7R0FDQSxRQUFRLGtCQUNKLFFBQVEsTUFBTSxFQUNWLFlBQVksUUFBUSxXQUN4QixDQUFDO0VBQ1QsT0FDSztHQUNELE1BQU0sVUFBVyxNQUFNLFFBQVEsVUFBVSxLQUFLLENBQUMsV0FBVyxVQUN0RCxjQUFjLFVBQVU7R0FDNUIsTUFBTSxrQkFBa0IsQ0FBQyxvQkFBb0IsQ0FBQztHQUM5QyxJQUFJLENBQUMsU0FBUyxNQUFNLE1BQU0sa0JBQWtCLFVBQVUsS0FBSyxTQUN2RCxjQUFjLE1BQU0sWUFBWSxTQUFTLFdBQVcsZUFBZSxlQUFlO1FBR2xGLGVBQWUsTUFBTSxZQUFZLFNBQVMsV0FBVyxlQUFlLGVBQWU7RUFFM0Y7RUFDQSxJQUFJLENBQUMsb0JBQW9CLENBQUMsZUFBZTtHQUNyQyxNQUFNLFVBQVUsVUFBVSxNQUFNLE1BQU07R0FDdEMsTUFBTSxjQUFjLE9BQU8sU0FBUyxVQUFVLE9BQU8sS0FBQTtHQUNyRCxNQUFNLHNCQUFzQixlQUN0QixDQUFDLElBQ0QsdUJBQXVCLE9BQU8sT0FBTyxJQUFJO0dBQy9DLE1BQU0sU0FBUyxZQUNULGNBQ0EscUJBQXFCLFdBQVcsS0FDOUIsb0JBQW9CLEtBQUssb0JBQW9CLElBQzNDLFlBQVksV0FBVyxJQUN2QixLQUFBO0dBQ1YsVUFBVSxNQUFNLEtBQUs7SUFDakIsR0FBSSxXQUFXO0lBQ2YsTUFBTTtJQUNOO0dBQ0osQ0FBQztHQUNELEtBQUssTUFBTSxZQUFZLHFCQUNuQixVQUFVLE1BQU0sS0FBSztJQUFFLE1BQU07SUFBVTtHQUFPLENBQUM7RUFFdkQ7Q0FDSjtDQUNBLE1BQU0sWUFBWSxNQUFNLE9BQU8sVUFBVSxDQUFDLE1BQU0sVUFBVSxNQUFNLE9BQU8sU0FBUyxLQUFLO0NBQ3JGLE1BQU0sYUFBYSxZQUFZLFVBQVUsQ0FBQyxNQUFNO0VBQzVDLE1BQU0sb0JBQW9CLFdBQVcsVUFBVSxJQUN6QyxXQUFXLFdBQVcsSUFDdEI7RUFDTixJQUFJLENBQUMsVUFBVSxhQUFhLGlCQUFpQixHQUFHO0dBQzVDLGNBQWM7SUFDVixHQUFHO0lBQ0gsR0FBRztHQUNQO0dBQ0EsS0FBSyxNQUFNLGFBQWEsT0FBTyxPQUMzQixJQUFJLElBQUksbUJBQW1CLFNBQVMsR0FDaEMsVUFBVSxXQUFXLElBQUksbUJBQW1CLFNBQVMsR0FBRyxTQUFTLE1BQU0sSUFBSTtHQUduRixVQUFVLE1BQU0sS0FBSztJQUNqQixHQUFHO0lBQ0gsTUFBTSxLQUFBO0lBQ04sTUFBTSxLQUFBO0lBQ04sR0FBSSxtQkFBbUIsT0FBTyxFQUFFLFFBQVEsWUFBWSxJQUFJLENBQUM7R0FDN0QsQ0FBQztHQUNELElBQUksUUFBUSxnQkFDUixVQUFVO0VBRWxCO0NBQ0o7Q0FDQSxNQUFNLFdBQVcsT0FBTyxVQUFVO0VBQzlCLE9BQU8sUUFBUTtFQUNmLE1BQU0sU0FBUyxNQUFNO0VBQ3JCLElBQUksT0FBTyxPQUFPO0VBQ2xCLElBQUksc0JBQXNCO0VBQzFCLE1BQU0sUUFBUSxJQUFJLFNBQVMsSUFBSTtFQUMvQixNQUFNLDhCQUE4QixlQUFlO0dBQy9DLHNCQUNJLE9BQU8sTUFBTSxVQUFVLEtBQ2xCLGFBQWEsVUFBVSxLQUFLLE1BQU0sV0FBVyxRQUFRLENBQUMsS0FDdkQsVUFBVSxZQUFZLElBQUksYUFBYSxNQUFNLFVBQVUsQ0FBQztFQUNwRTtFQUNBLElBQUksT0FBTztHQUNQLElBQUk7R0FDSixJQUFJO0dBQ0osTUFBTSxhQUFhLE9BQU8sT0FDcEIsY0FBYyxNQUFNLEVBQUUsSUFDdEIsY0FBYyxLQUFLO0dBQ3pCLE1BQU0sY0FBYyxNQUFNLFNBQVMsT0FBTyxRQUFRLE1BQU0sU0FBUyxPQUFPO0dBQ3hFLE1BQU0sd0JBQXdCLENBQUMsY0FBYyxNQUFNLEVBQUUsS0FDakQsQ0FBQyxTQUFTLFlBQ1YsQ0FBQyxTQUFTLFlBQ1YsQ0FBQyxJQUFJLFdBQVcsUUFBUSxJQUFJLEtBQzVCLENBQUMsTUFBTSxHQUFHO0dBQ2QsTUFBTSx1QkFBdUIseUJBQ3pCLGVBQWUsYUFBYSxJQUFJLFdBQVcsZUFBZSxJQUFJLEdBQUcsV0FBVyxhQUFhLDRCQUE0QiwyQkFBMkI7R0FDcEosTUFBTSxVQUFVLFVBQVUsTUFBTSxRQUFRLFdBQVc7R0FDbkQsSUFBSSxhQUFhLE1BQU0sWUFBWSxVQUFVLENBQUM7R0FDOUMsSUFBSSxhQUNJO1FBQUEsQ0FBQyxVQUFVLENBQUMsT0FBTyxVQUFVO0tBQzdCLE1BQU0sR0FBRyxVQUFVLE1BQU0sR0FBRyxPQUFPLEtBQUs7S0FDeEMsSUFBSSxPQUFPLFVBQVUsZUFBZSxLQUFLLHFCQUFxQixJQUFJLEdBQzlELG9CQUFvQixLQUFLLENBQUMsQ0FBQztJQUVuQztVQUVDLElBQUksTUFBTSxHQUFHLFVBQ2QsTUFBTSxHQUFHLFNBQVMsS0FBSztHQUUzQixNQUFNLGFBQWEsb0JBQW9CLE1BQU0sWUFBWSxXQUFXO0dBQ3BFLE1BQU0sZUFBZSxDQUFDLGNBQWMsVUFBVSxLQUFLO0dBQ25ELENBQUMsZUFDRyxVQUFVLE1BQU0sS0FBSztJQUNqQjtJQUNBLE1BQU0sTUFBTTtJQUNaLEdBQUkscUJBQXFCLElBQUksSUFDdkIsRUFBRSxRQUFRLFlBQVksV0FBVyxFQUFFLElBQ25DLENBQUM7R0FDWCxDQUFDO0dBQ0wsSUFBSSxzQkFBc0I7SUFDdEIsS0FBSyxDQUFDLHlCQUF5QixDQUFDLFdBQVcsWUFDdkMsV0FBVyxTQUFTLEdBQUc7S0FDdkIsSUFBSSxTQUFTLFNBQVMsVUFDZDtVQUFBLGFBQ0EsVUFBVTtLQUFBLE9BR2IsSUFBSSxDQUFDLGFBQ04sVUFBVTtJQUVsQjtJQUNBLE9BQVEsZ0JBQ0osVUFBVSxNQUFNLEtBQUs7S0FBRTtLQUFNLEdBQUksVUFBVSxDQUFDLElBQUk7SUFBWSxDQUFDO0dBQ3JFO0dBQ0EsSUFBSSxDQUFDLFNBQVMsWUFBWSxTQUFTLFVBQy9CLE1BQU0sYUFBYTtJQUNUO0lBQ04sV0FBVyxNQUFNO0dBQ3JCLENBQUM7R0FFTCxDQUFDLGVBQWUsV0FBVyxVQUFVLE1BQU0sS0FBSyxFQUFFLEdBQUcsV0FBVyxDQUFDO0dBQ2pFLElBQUksU0FBUyxVQUFVO0lBQ25CLE1BQU0sY0FBYztJQUNwQixNQUFNLEVBQUUsV0FBVyxNQUFNLFdBQVcsQ0FBQyxJQUFJLENBQUM7SUFDMUMsSUFBSSxnQkFBZ0IsY0FDaEI7SUFFSixvQkFBb0IsQ0FBQyxJQUFJLENBQUM7SUFDMUIsMkJBQTJCLFVBQVU7SUFDckMsSUFBSSxDQUFDLHFCQUFxQjtLQUN0QixDQUFDLGNBQWMsVUFBVSxLQUFLLFVBQVUsTUFBTSxLQUFLLFVBQVU7S0FDN0Q7SUFDSjtJQUNBLE1BQU0sNEJBQTRCLGtCQUFrQixXQUFXLFFBQVEsU0FBUyxJQUFJO0lBQ3BGLE1BQU0sb0JBQW9CLGtCQUFrQixRQUFRLFNBQVMsMEJBQTBCLFFBQVEsSUFBSTtJQUNuRyxRQUFRLGtCQUFrQjtJQUMxQixPQUFPLGtCQUFrQjtJQUN6QixVQUFVLGNBQWMsTUFBTTtHQUNsQyxPQUNLO0lBQ0QsTUFBTSxjQUFjO0lBQ3BCLG9CQUFvQixDQUFDLElBQUksR0FBRyxJQUFJO0lBQ2hDLFNBQVMsTUFBTSxjQUFjLE9BQU8sT0FBTyxVQUFVLGFBQWEsa0NBQWtDLFNBQVMseUJBQXlCLEVBQUEsQ0FBRztJQUN6SSxJQUFJLGdCQUFnQixjQUNoQjtJQUVKLG9CQUFvQixDQUFDLElBQUksQ0FBQztJQUMxQiwyQkFBMkIsVUFBVTtJQUNyQyxJQUFJLHFCQUFxQjtLQUNyQixJQUFJLE9BQ0EsVUFBVTtVQUVULElBQUksV0FBVyxTQUFTLEdBQUc7TUFDNUIsVUFBVSxNQUFNLHlCQUF5QjtPQUNyQyxRQUFRO09BQ1IsZ0JBQWdCO09BQ1Y7T0FDTixXQUFXLE1BQU07TUFDckIsQ0FBQztNQUNELElBQUksZ0JBQWdCLGNBQ2hCO0tBRVI7SUFDSjtHQUNKO0dBQ0EsSUFBSSxxQkFBcUI7SUFDckIsTUFBTSxHQUFHLFNBQ0osQ0FBQyxNQUFNLFFBQVEsTUFBTSxHQUFHLElBQUksS0FBSyxNQUFNLEdBQUcsS0FBSyxTQUFTLE1BQ3pELFFBQVEsTUFBTSxHQUFHLElBQUk7SUFDekIsb0JBQW9CLE1BQU0sU0FBUyxPQUFPLFVBQVU7R0FDeEQ7RUFDSjtDQUNKO0NBQ0EsTUFBTSxlQUFlLEtBQUssUUFBUTtFQUM5QixJQUFJLElBQUksV0FBVyxRQUFRLEdBQUcsS0FBSyxJQUFJLE9BQU87R0FDMUMsSUFBSSxNQUFNO0dBQ1YsT0FBTztFQUNYO0NBRUo7Q0FDQSxNQUFNLFVBQVUsT0FBTyxNQUFNLFVBQVUsQ0FBQyxNQUFNO0VBQzFDLElBQUk7RUFDSixJQUFJO0VBQ0osTUFBTSxhQUFhLHNCQUFzQixJQUFJO0VBQzdDLElBQUksU0FBUyxVQUFVO0dBQ25CLE1BQU0sY0FBYztHQUNwQixNQUFNLFNBQVMsTUFBTSw0QkFBNEIsWUFBWSxJQUFJLElBQUksT0FBTyxVQUFVO0dBQ3RGLFVBQVUsY0FBYyxNQUFNO0dBQzlCLG1CQUFtQixPQUNiLENBQUMsV0FBVyxNQUFNLFNBQVMsSUFBSSxRQUFRLElBQUksQ0FBQyxJQUM1QztHQUNOLElBQUksZ0JBQWdCLGNBQ2hCLE9BQU87RUFFZixPQUNLLElBQUksTUFBTTtHQUNYLG9CQUFvQixNQUFNLFFBQVEsSUFBSSxXQUFXLElBQUksT0FBTyxjQUFjO0lBQ3RFLE1BQU0sUUFBUSxJQUFJLFNBQVMsU0FBUztJQUNwQyxPQUFPLE1BQU0seUJBQXlCO0tBQ2xDLFFBQVEsU0FBUyxNQUFNLEtBQUssR0FBRyxZQUFZLE1BQU0sSUFBSTtLQUNyRCxXQUFXLE9BQU87SUFDdEIsQ0FBQztHQUNMLENBQUMsQ0FBQyxFQUFBLENBQUcsTUFBTSxPQUFPO0dBQ2xCLENBQUcsb0JBQXFCLFdBQVcsWUFBWSxVQUFVO0VBQzdELE9BRUksbUJBQW1CLFVBQVUsTUFBTSx5QkFBeUI7R0FDeEQsUUFBUTtHQUNSO0dBQ0EsV0FBVyxPQUFPO0VBQ3RCLENBQUM7RUFFTCxJQUFJLFFBQVEsY0FBYyxTQUFTLGNBQWMsU0FBUyxJQUFJLEdBQUc7R0FDN0QsTUFBTSxRQUFRLElBQUksV0FBVyxRQUFRLElBQUk7R0FDekMsSUFBSSxPQUFPO0lBQ1AsTUFBTSxXQUFXLFFBQVEsSUFBSTtJQUM3QixvQkFBb0IsUUFBUSxTQUFTLFlBQVksYUFBYSxNQUFNLEtBQUssQ0FBQztJQUMxRSxvQkFBb0IsS0FBSyxDQUFDLFNBQVMsVUFBVTtHQUNqRCxPQUVJLG1CQUFtQixJQUFJO0VBRS9CO0VBQ0EsSUFBSSxRQUFRLGFBQ1IsS0FBSyxNQUFNLGFBQWEsT0FBTyxhQUFhLE9BQU8sT0FDL0MsQ0FBQyxPQUFPLE1BQU0sSUFBSSxTQUFTLEtBQ3ZCLElBQUksV0FBVyxlQUFlLFdBQVcsSUFBSTtFQUd6RCxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztFQUMzQyxVQUFVLE1BQU0sS0FBSztHQUNqQixHQUFJLENBQUMsU0FBUyxJQUFJLEtBQ2IsV0FBVyxTQUFTLEtBQUssWUFBWSxXQUFXLFVBQy9DLENBQUMsSUFDRCxFQUFFLEtBQUs7R0FDYixHQUFJLFNBQVMsWUFBWSxDQUFDLE9BQU8sRUFBRSxRQUFRLElBQUksQ0FBQztHQUNoRCxHQUFJLFFBQVEsZUFBZSxXQUFXLGVBQWUsSUFDL0MsRUFBRSxlQUFlLFdBQVcsY0FBYyxJQUMxQyxDQUFDO0dBQ1AsUUFBUSxXQUFXO0VBQ3ZCLENBQUM7RUFDRCxRQUFRLGVBQ0osQ0FBQyxvQkFDRCxzQkFBc0IsU0FBUyxhQUFhLE9BQU8sYUFBYSxPQUFPLEtBQUs7RUFDaEYsT0FBTztDQUNYO0NBQ0EsTUFBTSxhQUFhLFlBQVksV0FBVztFQUN0QyxJQUFJLFNBQVMsRUFDVCxHQUFJLE9BQU8sUUFBUSxjQUFjLGVBQ3JDO0VBQ0EsSUFBSSxRQUNBLFNBQVMsa0JBQWtCLE9BQU8sY0FBYyxXQUFXLGNBQWMsV0FBVyxlQUFlLE1BQU07RUFFN0csT0FBTyxZQUFZLFVBQVUsSUFDdkIsU0FDQSxTQUFTLFVBQVUsSUFDZixJQUFJLFFBQVEsVUFBVSxJQUN0QixXQUFXLEtBQUssU0FBUyxJQUFJLFFBQVEsSUFBSSxDQUFDO0NBQ3hEO0NBQ0EsTUFBTSxhQUFhLGVBQWUsWUFBWSxVQUFVLElBQ2xELEVBQUUsR0FBRyxXQUFXLE9BQU8sSUFDdkIsU0FBUyxVQUFVLElBQ2YsSUFBSSxXQUFXLFFBQVEsVUFBVSxJQUNqQyxXQUFXLEtBQUssU0FBUyxJQUFJLFdBQVcsUUFBUSxJQUFJLENBQUM7Q0FDL0QsTUFBTSxpQkFBaUIsTUFBTSxjQUFjO0VBQ3ZDLE1BQU0sa0JBQWtCLGFBQWE7RUFDckMsTUFBTSxRQUFRLElBQUksZ0JBQWdCLFFBQVEsSUFBSTtFQUM5QyxPQUFPO0dBQ0gsU0FBUyxDQUFDLENBQUM7R0FDWCxTQUFTLENBQUMsQ0FBQyxJQUFJLGdCQUFnQixhQUFhLElBQUk7R0FDaEQ7R0FDQSxjQUFjLENBQUMsQ0FBQyxJQUFJLGdCQUFnQixrQkFBa0IsSUFBSTtHQUMxRCxXQUFXLENBQUMsQ0FBQyxJQUFJLGdCQUFnQixlQUFlLElBQUk7RUFDeEQ7Q0FDSjtDQUNBLE1BQU0sZUFBZSxTQUFTO0VBQzFCLE1BQU0sUUFBUSxPQUFPLHNCQUFzQixJQUFJLElBQUksS0FBQTtFQUNuRCxJQUFJLE9BQ0EsTUFBTSxTQUFTLGNBQWM7R0FDekIsdUJBQXVCLFNBQVM7R0FDaEMsTUFBTSxXQUFXLFFBQVEsU0FBUztHQUNsQyxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztHQUMzQyxVQUFVLE1BQU0sS0FBSztJQUNqQixNQUFNO0lBQ04sUUFBUSxXQUFXO0dBQ3ZCLENBQUM7RUFDTCxDQUFDO09BRUE7R0FDRCxPQUFPLEtBQUssbUJBQW1CLENBQUMsQ0FBQyxRQUFRLGtCQUFrQjtHQUMzRCxXQUFXLFNBQVMsQ0FBQztHQUNyQixVQUFVLE1BQU0sS0FBSyxFQUNqQixRQUFRLFdBQVcsT0FDdkIsQ0FBQztFQUNMO0NBQ0o7Q0FDQSxNQUFNLFlBQVksTUFBTSxPQUFPLFlBQVk7RUFDdkMsdUJBQXVCLElBQUk7RUFDM0IsTUFBTSxPQUFPLElBQUksU0FBUyxNQUFNLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEVBQUEsQ0FBRztFQUV0RCxNQUFNLEVBQUUsS0FBSyxZQUFZLFNBQVMsTUFBTSxPQUFPLEdBQUcsb0JBRDdCLElBQUksV0FBVyxRQUFRLElBQUksS0FBSyxDQUFDO0VBRXRELElBQUksV0FBVyxRQUFRLE1BQU07R0FDekIsR0FBRztHQUNILEdBQUc7R0FDSDtFQUNKLENBQUM7RUFDRCxXQUFXLFNBQVMsRUFBRSxHQUFHLFdBQVcsT0FBTztFQUMzQyxVQUFVLE1BQU0sS0FBSztHQUNqQjtHQUNBLFFBQVEsV0FBVztHQUNuQixTQUFTO0VBQ2IsQ0FBQztFQUNELFdBQVcsUUFBUSxlQUFlLE9BQU8sSUFBSSxTQUFTLElBQUksTUFBTTtDQUNwRTtDQUNBLE1BQU0sU0FBUyxNQUFNLGlCQUFpQjtFQUNsQyxJQUFJLFdBQVcsSUFBSSxHQUFHO0dBQ2xCLE1BQU0sbUJBQW1CLENBQUM7R0FDMUIsbUJBQW1CLElBQUksZ0JBQWdCO0dBQ3ZDLE1BQU0sRUFBRSxnQkFBZ0IsVUFBVSxNQUFNLFVBQVUsRUFDOUMsT0FBTyxZQUFZLFlBQVksV0FDM0IsS0FBSyxRQUFRLFVBQVUsVUFBVSxLQUFBLEdBQVcsWUFBWSxHQUFHLE9BQU8sRUFDMUUsQ0FBQztHQUNELE9BQU8sRUFDSCxtQkFBbUI7SUFDZixtQkFBbUIsT0FBTyxnQkFBZ0I7SUFDMUMsWUFBWTtHQUNoQixFQUNKO0VBQ0o7RUFDQSxPQUFPLFVBQVUsTUFBTSxjQUFjLElBQUk7Q0FDN0M7Q0FDQSxNQUFNLGNBQWMsVUFBVTtFQUMxQixNQUFNLG1CQUFtQjtHQUFFLE1BQU0sTUFBTTtHQUFNLE9BQU8sTUFBTTtFQUFNO0VBQ2hFLE1BQU0sYUFDRixNQUFNLFVBQVUsVUFDaEIsbUJBQW1CLElBQUksZ0JBQWdCO0VBQzNDLE1BQU0sRUFBRSxnQkFBZ0IsVUFBVSxNQUFNLFVBQVUsRUFDOUMsT0FBTyxjQUFjO0dBQ2pCLElBQUksc0JBQXNCLE1BQU0sTUFBTSxVQUFVLE1BQU0sTUFBTSxLQUFLLEtBQzdELHNCQUFzQixXQUFXLE1BQU0sYUFBYSxpQkFBaUIsTUFBTSxZQUFZLEdBQUc7SUFDMUYsTUFBTSxTQUFTLFVBQVUsVUFBVSxFQUFFLEdBQUcsWUFBWTtJQUNwRCxNQUFNLFNBQVM7S0FDWCxHQUFHO0tBQ0gsR0FBRztLQUNIO0tBQ0EsZUFBZTtJQUNuQixDQUFDO0dBQ0w7RUFDSixFQUNKLENBQUM7RUFDRCxhQUFhO0dBQ1QsbUJBQW1CLE9BQU8sZ0JBQWdCO0dBQzFDLFlBQVk7RUFDaEI7Q0FDSjtDQUNBLE1BQU0sYUFBYSxVQUFVO0VBQ3pCLE9BQU8sUUFBUTtFQUNmLE1BQU0sY0FBYyxPQUFPLEtBQUssTUFBTSxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxRQUFRLE1BQU0sYUFBYSxNQUFNLFVBQVUsSUFBSTtFQUM5RyxLQUFLLE1BQU0sT0FBTyxhQUNkLHlCQUF5QixRQUFRLHlCQUF5QixRQUFRLEtBQUs7RUFFM0UsTUFBTSxjQUFjLFdBQVc7R0FDM0IsR0FBRztHQUNILFdBQVc7SUFDUCxHQUFHO0lBQ0gsR0FBRyxNQUFNO0dBQ2I7RUFDSixDQUFDO0VBQ0QsYUFBYTtHQUVULEtBQUssTUFBTSxPQUFPLFlBQVksT0FBTyxDQUFDLEdBQ2xDLHlCQUF5QixJQUFJO0dBRWpDLFlBQVk7RUFDaEI7Q0FDSjtDQUNBLE1BQU0sY0FBYyxNQUFNLFVBQVUsQ0FBQyxNQUFNO0VBQ3ZDLEtBQUssTUFBTSxhQUFhLE9BQU8sc0JBQXNCLElBQUksSUFBSSxPQUFPLE9BQU87R0FDdkUsT0FBTyxNQUFNLE9BQU8sU0FBUztHQUM3QixPQUFPLE1BQU0sT0FBTyxTQUFTO0dBQzdCLE9BQU8sU0FBUyxPQUFPLFNBQVM7R0FDaEMsSUFBSSxDQUFDLFFBQVEsV0FBVztJQUNwQixNQUFNLFNBQVMsU0FBUztJQUN4QixNQUFNLGFBQWEsU0FBUztHQUNoQztHQUNBLElBQUksQ0FBQyxRQUFRLFdBQVc7SUFDcEIsdUJBQXVCLFNBQVM7SUFDaEMsTUFBTSxXQUFXLFFBQVEsU0FBUztHQUN0QztHQUNBLENBQUMsUUFBUSxhQUFhLE1BQU0sV0FBVyxhQUFhLFNBQVM7R0FDN0QsQ0FBQyxRQUFRLGVBQWUsTUFBTSxXQUFXLGVBQWUsU0FBUztHQUNqRSxDQUFDLFFBQVEsb0JBQ0wsTUFBTSxXQUFXLGtCQUFrQixTQUFTO0dBQ2hELENBQUMsU0FBUyxvQkFDTixDQUFDLFFBQVEsb0JBQ1QsTUFBTSxnQkFBZ0IsU0FBUztFQUN2QztFQUNBLElBQUksQ0FBQyxRQUFRLFdBQ1QsV0FBVyxTQUFTLEVBQUUsR0FBRyxXQUFXLE9BQU87RUFFL0MsbUJBQW1CLFFBQ2YsVUFBVSxNQUFNLEtBQUssRUFDakIsUUFBUSxZQUFZLFdBQVcsRUFDbkMsQ0FBQztFQUNMLFVBQVUsTUFBTSxLQUFLO0dBQ2pCLEdBQUc7R0FDSCxHQUFJLFFBQVEsWUFBWSxDQUFDLElBQUksRUFBRSxTQUFTLFVBQVUsRUFBRTtHQUNwRCxHQUFJLFFBQVEsbUJBQ04sQ0FBQyxJQUNELEVBQUUsY0FBYyxDQUFDLGNBQWMsV0FBVyxnQkFBZ0IsRUFBRTtFQUN0RSxDQUFDO0VBQ0QsQ0FBQyxRQUFRLGVBQWUsVUFBVTtDQUN0QztDQUNBLE1BQU0scUJBQXFCLEVBQUUsVUFBVSxXQUFZO0VBQy9DLElBQUssVUFBVSxRQUFRLEtBQUssT0FBTyxTQUMvQixDQUFDLENBQUMsWUFDRixPQUFPLFNBQVMsSUFBSSxJQUFJLEdBQUc7R0FHM0IsTUFBTSx1QkFGYyxPQUFPLFNBQVMsSUFBSSxJQUVELE1BQU0sQ0FEekIsQ0FBQztHQUVyQixXQUFXLE9BQU8sU0FBUyxJQUFJLElBQUksSUFBSSxPQUFPLFNBQVMsT0FBTyxJQUFJO0dBQ2xFLHdCQUF3QixPQUFPLFNBQVMsQ0FBQyxPQUFPLFVBQVUsVUFBVTtFQUN4RTtDQUNKO0NBQ0EsTUFBTSxZQUFZLE1BQU0sVUFBVSxDQUFDLE1BQU07RUFDckMsSUFBSSxRQUFRLElBQUksU0FBUyxJQUFJO0VBQzdCLE1BQU0sb0JBQW9CLFVBQVUsUUFBUSxRQUFRLEtBQUssVUFBVSxTQUFTLFFBQVE7RUFDcEYsTUFBTSwwQkFBMEIsQ0FBQyxPQUFPLGFBQWEsSUFBSSxJQUFJLEtBQUssU0FBUyxNQUFNLE1BQU0sQ0FBQyxNQUFNLEdBQUc7RUFDakcsSUFBSSxTQUFTLE1BQU07R0FDZixHQUFJLFNBQVMsQ0FBQztHQUNkLElBQUk7SUFDQSxHQUFJLFNBQVMsTUFBTSxLQUFLLE1BQU0sS0FBSyxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUU7SUFDbkQ7SUFDQSxPQUFPO0lBQ1AsR0FBRztHQUNQO0VBQ0osQ0FBQztFQUNELE9BQU8sTUFBTSxJQUFJLElBQUk7RUFDckIsSUFBSSxTQUFTLE1BQU0sSUFBSTtHQUNuQixNQUFNLFlBQVksSUFBSSxTQUFTLElBQUk7R0FDbkMsS0FBSyxNQUFNLFFBQVEsMkJBQ2YsSUFBSSxFQUFFLFFBQVEsVUFDVixPQUFPLFVBQVUsR0FBRztFQUdoQztFQUNBLElBQUksU0FBUyxDQUFDLHlCQUNWLGtCQUFrQjtHQUNkLFVBQVUsVUFBVSxRQUFRLFFBQVEsSUFDOUIsUUFBUSxXQUNSLFNBQVM7R0FDZjtFQUNKLENBQUM7T0FHRCxvQkFBb0IsTUFBTSxNQUFNLFFBQVEsS0FBSztFQUVqRCxPQUFPO0dBQ0gsR0FBSSxvQkFDRSxFQUFFLFVBQVUsUUFBUSxZQUFZLFNBQVMsU0FBUyxJQUNsRCxDQUFDO0dBQ1AsR0FBSSxTQUFTLGNBQ1A7SUFDRSxVQUFVLENBQUMsQ0FBQyxRQUFRO0lBQ3BCLEtBQUssYUFBYSxRQUFRLEdBQUc7SUFDN0IsS0FBSyxhQUFhLFFBQVEsR0FBRztJQUM3QixXQUFXLGFBQWEsUUFBUSxTQUFTO0lBQ3pDLFdBQVcsYUFBYSxRQUFRLFNBQVM7SUFDekMsU0FBUyxhQUFhLFFBQVEsT0FBTztHQUN6QyxJQUNFLENBQUM7R0FDUDtHQUNBO0dBQ0EsUUFBUTtHQUNSLE1BQU0sUUFBUTtJQUNWLElBQUksS0FBSztLQUNMLE9BQU8sYUFBYSxJQUFJLElBQUk7S0FDNUIsU0FBUyxNQUFNLE9BQU87S0FDdEIsT0FBTyxhQUFhLE9BQU8sSUFBSTtLQUMvQixRQUFRLElBQUksU0FBUyxJQUFJO0tBQ3pCLE1BQU0sV0FBVyxZQUFZLElBQUksS0FBSyxJQUNoQyxJQUFJLG1CQUNBLElBQUksaUJBQWlCLHVCQUF1QixDQUFDLENBQUMsTUFBTSxNQUNwRCxNQUNKO0tBQ04sTUFBTSxrQkFBa0Isa0JBQWtCLFFBQVE7S0FDbEQsTUFBTSxPQUFPLE1BQU0sR0FBRyxRQUFRLENBQUM7S0FDL0IsSUFBSSxrQkFDRSxLQUFLLE1BQU0sV0FBVyxXQUFXLFFBQVEsSUFDekMsYUFBYSxNQUFNLEdBQUcsS0FDeEI7S0FFSixNQUFNLFdBQVcsRUFDYixHQUFHLE1BQU0sR0FDYjtLQUNBLElBQUksaUJBQWlCO01BQ2pCLFNBQVMsT0FBTztPQUNaLEdBQUcsS0FBSyxPQUFPLElBQUk7T0FDbkI7T0FDQSxHQUFJLE1BQU0sUUFBUSxJQUFJLGdCQUFnQixJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7TUFDM0Q7TUFDQSxTQUFTLE1BQU07T0FBRSxNQUFNLFNBQVM7T0FBTTtNQUFLO0tBQy9DLE9BQ0s7TUFDRCxTQUFTLE1BQU07TUFDZixPQUFPLFNBQVM7S0FDcEI7S0FDQSxJQUFJLFNBQVMsTUFBTSxFQUNmLElBQUksU0FDUixDQUFDO0tBQ0Qsb0JBQW9CLE1BQU0sT0FBTyxLQUFBLEdBQVcsUUFBUTtJQUN4RCxPQUNLO0tBQ0QsUUFBUSxJQUFJLFNBQVMsTUFBTSxDQUFDLENBQUM7S0FDN0IsSUFBSSxNQUFNLElBQ04sTUFBTSxHQUFHLFFBQVE7S0FFckIsQ0FBQyxTQUFTLG9CQUFvQixRQUFRLHFCQUNsQyxFQUFFLG1CQUFtQixPQUFPLE9BQU8sSUFBSSxLQUFLLE9BQU8sV0FDbkQsT0FBTyxRQUFRLElBQUksSUFBSTtJQUMvQjtHQUNKO0VBQ0o7Q0FDSjtDQUNBLE1BQU0sb0JBQW9CLFNBQVMsb0JBQy9CLENBQUMsU0FBUyw2QkFDVixzQkFBc0IsU0FBUyxhQUFhLE9BQU8sS0FBSztDQUM1RCxNQUFNLGdCQUFnQixhQUFhO0VBQy9CLElBQUksVUFBVSxRQUFRLEdBQUc7R0FDckIsVUFBVSxNQUFNLEtBQUssRUFBRSxTQUFTLENBQUM7R0FDakMsc0JBQXNCLFVBQVUsS0FBSyxTQUFTO0lBQzFDLE1BQU0sZUFBZSxJQUFJLFNBQVMsSUFBSTtJQUN0QyxJQUFJLGNBQWM7S0FDZCxJQUFJLFdBQVcsYUFBYSxHQUFHLFlBQVk7S0FDM0MsSUFBSSxNQUFNLFFBQVEsYUFBYSxHQUFHLElBQUksR0FDbEMsYUFBYSxHQUFHLEtBQUssU0FBUyxhQUFhO01BQ3ZDLFNBQVMsV0FBVyxhQUFhLEdBQUcsWUFBWTtLQUNwRCxDQUFDO0lBRVQ7R0FDSixHQUFHLENBQUM7RUFDUjtDQUNKO0NBQ0EsTUFBTSxnQkFBZ0IsU0FBUyxjQUFjLE9BQU8sTUFBTTtFQUN0RCxJQUFJLFNBQVMsS0FBQTtFQUNiLElBQUksZUFBZSxLQUFBO0VBQ25CLElBQUksR0FBRztHQUNILEVBQUUsa0JBQWtCLEVBQUUsZUFBZTtHQUNyQyxFQUFFLFdBQ0UsRUFBRSxRQUFRO0VBQ2xCO0VBQ0EsSUFBSSxjQUFjLFlBQVksV0FBVztFQUN6QyxVQUFVLE1BQU0sS0FBSyxFQUNqQixjQUFjLEtBQ2xCLENBQUM7RUFDRCxJQUFJLFNBQVMsVUFBVTtHQUNuQixNQUFNLGNBQWM7R0FDcEIsTUFBTSxFQUFFLFFBQVEsV0FBVyxNQUFNLFdBQVc7R0FDNUMsSUFBSSxnQkFBZ0IsY0FDaEI7R0FFSixvQkFBb0I7R0FDcEIsT0FBTyxLQUFLLG1CQUFtQixDQUFDLENBQUMsUUFBUSxrQkFBa0I7R0FDM0QsV0FBVyxTQUFTO0dBQ3BCLGNBQWMsWUFBWSxNQUFNO0VBQ3BDLE9BQ0s7R0FDRCxNQUFNLGNBQWM7R0FDcEIsTUFBTSx5QkFBeUI7SUFDM0IsUUFBUTtJQUNSLFdBQVcsT0FBTztHQUN0QixDQUFDO0dBQ0QsSUFBSSxnQkFBZ0IsY0FDaEI7R0FFSixNQUFNLFdBQVcsUUFBUSxlQUFlO0dBQ3hDLFdBQVcsU0FBUyxFQUFFLEdBQUcsV0FBVyxPQUFPO0VBQy9DO0VBQ0EsSUFBSSxPQUFPLFNBQVMsTUFDaEIsS0FBSyxNQUFNLFFBQVEsT0FBTyxVQUN0QixNQUFNLGFBQWEsSUFBSTtFQUcvQixJQUFJLGNBQWMsV0FBVyxNQUFNLEdBQUc7R0FDbEMsVUFBVSxNQUFNLEtBQUssRUFDakIsUUFBUSxDQUFDLEVBQ2IsQ0FBQztHQUNELElBQUk7SUFDQSxTQUFTLE1BQU0sUUFBUSxhQUFhLENBQUM7R0FDekMsU0FDTyxPQUFPO0lBQ1YsZUFBZTtHQUNuQjtFQUNKLE9BQ0s7R0FDRCxJQUFJLFdBQ0EsTUFBTSxVQUFVLEVBQUUsR0FBRyxXQUFXLE9BQU8sR0FBRyxDQUFDO0dBRS9DLFlBQVk7R0FDWixXQUFXLFdBQVc7RUFDMUI7RUFDQSxVQUFVLE1BQU0sS0FBSztHQUNqQixhQUFhO0dBQ2IsY0FBYztHQUNkLG9CQUFvQixjQUFjLFdBQVcsTUFBTSxLQUFLLENBQUM7R0FDekQsYUFBYSxXQUFXLGNBQWM7R0FDdEMsUUFBUSxXQUFXO0VBQ3ZCLENBQUM7RUFDRCxJQUFJLGNBQ0EsTUFBTTtFQUVWLE9BQU87Q0FDWDtDQUNBLE1BQU0sY0FBYyxNQUFNLFVBQVUsQ0FBQyxNQUFNO0VBQ3ZDLElBQUksSUFBSSxTQUFTLElBQUksR0FBRztHQUNwQixNQUFNLFdBQVcsa0JBQWtCLElBQUk7R0FDdkMsSUFBSSxZQUFZLFFBQVEsWUFBWSxHQUNoQyxTQUFTLE1BQU0sWUFBWSxJQUFJLGdCQUFnQixJQUFJLENBQUMsQ0FBQztRQUVwRDtJQUNELFNBQVMsTUFBTSxRQUFRLFlBQVk7SUFDbkMsSUFBSSxnQkFBZ0IsTUFBTSxZQUFZLFFBQVEsWUFBWSxDQUFDO0dBQy9EO0dBQ0EsSUFBSSxDQUFDLFFBQVEsYUFDVCxNQUFNLFdBQVcsZUFBZSxJQUFJO0dBRXhDLElBQUksQ0FBQyxRQUFRLFdBQVc7SUFDcEIsTUFBTSxXQUFXLGFBQWEsSUFBSTtJQUNsQyxXQUFXLFVBQVUsUUFBUSxlQUN2QixVQUFVLE1BQU0sWUFBWSxJQUFJLGdCQUFnQixJQUFJLENBQUMsQ0FBQyxJQUN0RCxVQUFVO0dBQ3BCO0dBQ0EsSUFBSSxDQUFDLFFBQVEsV0FBVztJQUNwQix1QkFBdUIsSUFBSTtJQUMzQixNQUFNLFdBQVcsUUFBUSxJQUFJO0lBQzdCLFdBQVcsU0FBUyxFQUFFLEdBQUcsV0FBVyxPQUFPO0lBQzNDLFVBQVU7R0FDZDtHQUNBLFVBQVUsTUFBTSxLQUFLO0lBQ2pCLEdBQUc7SUFDSCxjQUFjLENBQUMsY0FBYyxXQUFXLGdCQUFnQjtHQUM1RCxDQUFDO0VBQ0w7Q0FDSjtDQUNBLE1BQU0sVUFBVSxZQUFZLG1CQUFtQixDQUFDLE1BQU07RUFDbEQ7RUFDQSxNQUFNLGdCQUFnQixhQUFhLFlBQVksVUFBVSxJQUFJO0VBQzdELE1BQU0scUJBQXFCLFlBQVksYUFBYTtFQUNwRCxNQUFNLHFCQUFxQixjQUFjLFVBQVU7RUFDbkQsTUFBTSxTQUFTO0VBQ2YsTUFBTSxZQUFZO0VBQ2xCLE9BQU8sS0FBSyxtQkFBbUIsQ0FBQyxDQUFDLFFBQVEsa0JBQWtCO0VBQzNELElBQUksQ0FBQyxpQkFBaUIsbUJBQ2xCLGlCQUFpQjtFQUVyQixJQUFJLENBQUMsaUJBQWlCLFlBQVk7R0FDOUIsSUFBSSxpQkFBaUIsaUJBQWlCO0lBQ2xDLE1BQU0sZ0NBQWdCLElBQUksSUFBSSxDQUMxQixHQUFHLE9BQU8sT0FDVixHQUFHLHVCQUF1QixlQUFlLGdCQUFnQixhQUFhLEtBQUEsR0FBVyxTQUFTLEdBQUcsV0FBVyxXQUFXLENBQ3ZILENBQUM7SUFDRCxLQUFLLE1BQU0sYUFBYSxlQUFlO0tBQ25DLE1BQU0sVUFBVSxJQUFJLFdBQVcsYUFBYSxTQUFTO0tBQ3JELE1BQU0sZ0JBQWdCLElBQUksYUFBYSxTQUFTO0tBQ2hELE1BQU0sV0FBVyxJQUFJLFFBQVEsU0FBUztLQUN0QyxJQUFJLFdBQVcsQ0FBQyxZQUFZLGFBQWEsR0FDckMsSUFBSSxRQUFRLFdBQVcsYUFBYTtVQUVuQyxJQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksUUFBUSxHQUN0QyxTQUFTLFdBQVcsUUFBUTtJQUVwQztHQUNKLE9BQ0s7SUFDRCxJQUFJLFNBQVMsWUFBWSxVQUFVLEdBQy9CLEtBQUssTUFBTSxRQUFRLE9BQU8sT0FBTztLQUM3QixNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7S0FDL0IsSUFBSSxTQUFTLE1BQU0sSUFBSTtNQUNuQixNQUFNLGlCQUFpQixNQUFNLFFBQVEsTUFBTSxHQUFHLElBQUksSUFDNUMsTUFBTSxHQUFHLEtBQUssS0FDZCxNQUFNLEdBQUc7TUFDZixJQUFJLGNBQWMsY0FBYyxHQUFHO09BQy9CLE1BQU0sT0FBTyxlQUFlLFFBQVEsTUFBTTtPQUMxQyxJQUFJLE1BQU07UUFDTixLQUFLLE1BQU07UUFDWDtPQUNKO01BQ0o7S0FDSjtJQUNKO0lBRUosSUFBSSxpQkFBaUIsZUFDakIsS0FBSyxNQUFNLGFBQWEsT0FBTyxPQUMzQixTQUFTLFdBQVcsSUFBSSxRQUFRLFNBQVMsQ0FBQztTQUk5QyxVQUFVLENBQUM7R0FFbkI7R0FDQSxJQUFJLFNBQVMsa0JBQWtCO0lBQzNCLGNBQWMsaUJBQWlCLG9CQUN6QixZQUFZLGNBQWMsSUFDMUIsQ0FBQztJQUNQLElBQUksaUJBQWlCLGVBQ2pCLEtBQUssTUFBTSxhQUFhLE9BQU8sT0FDM0IsSUFBSSxhQUFhLFdBQVcsSUFBSSxRQUFRLFNBQVMsQ0FBQztHQUc5RCxPQUVJLGNBQWMsWUFBWSxNQUFNO0dBRXBDLFVBQVUsTUFBTSxLQUFLLEVBQ2pCLFFBQVEsRUFBRSxHQUFHLE9BQU8sRUFDeEIsQ0FBQztHQUNELFVBQVUsTUFBTSxLQUFLO0lBQ2pCLE1BQU0sS0FBQTtJQUNOLE1BQU0sS0FBQTtJQUNOLFFBQVEsRUFBRSxHQUFHLE9BQU87R0FDeEIsQ0FBQztFQUNMO0VBQ0EsU0FBUztHQUNMLE9BQU8saUJBQWlCLGtCQUFrQixPQUFPLHdCQUFRLElBQUksSUFBSTtHQUNqRSx5QkFBUyxJQUFJLElBQUk7R0FDakIsdUJBQU8sSUFBSSxJQUFJO0dBQ2YsOEJBQWMsSUFBSSxJQUFJO0dBQ3RCLDBCQUFVLElBQUksSUFBSTtHQUNsQix1QkFBTyxJQUFJLElBQUk7R0FDZixVQUFVO0dBQ1YsT0FBTztFQUNYO0VBQ0EsT0FBTyxRQUNILENBQUMsZ0JBQWdCLFdBQ2IsQ0FBQyxDQUFDLGlCQUFpQixlQUNuQixDQUFDLENBQUMsaUJBQWlCLG1CQUNsQixDQUFDLFNBQVMsb0JBQW9CLENBQUMsY0FBYyxNQUFNO0VBQzVELE9BQU8sUUFBUSxDQUFDLENBQUMsU0FBUztFQUMxQixPQUFPLGNBQWMsQ0FBQyxDQUFDLGlCQUFpQjtFQUN4QyxPQUFPLFNBQVM7RUFDaEIsT0FBTyxtQkFBbUIsTUFBTTtFQUNoQyxvQkFBb0I7RUFDcEIsSUFBSSxDQUFDLGlCQUFpQixZQUNsQixXQUFXLFNBQVMsQ0FBQztFQUV6QixVQUFVLE1BQU0sS0FBSztHQUNqQixhQUFhLGlCQUFpQixrQkFDeEIsV0FBVyxjQUNYO0dBQ04sU0FBUyxxQkFDSCxRQUNBLGlCQUFpQixZQUNiLFdBQVcsVUFDWCxpQkFBaUIsYUFDYixVQUFVLElBQ1YsQ0FBQyxFQUFFLGlCQUFpQixxQkFDbEIsY0FDQSxDQUFDLFVBQVUsWUFBWSxjQUFjO0dBQ3JELGFBQWEsaUJBQWlCLGtCQUN4QixXQUFXLGNBQ1g7R0FDTixhQUFhLHFCQUNQLENBQUMsSUFDRCxpQkFBaUIsa0JBQ2IsaUJBQWlCLHFCQUFxQixjQUNsQyxlQUFlLGdCQUFnQixhQUFhLEtBQUEsR0FBVyxTQUFTLElBQ2hFLFdBQVcsY0FDZixpQkFBaUIscUJBQXFCLGFBQ2xDLGVBQWUsZ0JBQWdCLFlBQVksS0FBQSxHQUFXLFNBQVMsSUFDL0QsaUJBQWlCLFlBQ2IsV0FBVyxjQUNYLGlCQUFpQixhQUNiLGVBQWUsZ0JBQWdCLGFBQWEsS0FBQSxHQUFXLFNBQVMsSUFDaEUsQ0FBQztHQUN2QixlQUFlLGlCQUFpQixjQUMxQixXQUFXLGdCQUNYLENBQUM7R0FDUCxHQUFJLENBQUMsaUJBQWlCLHFCQUNqQixXQUFXLGdCQUFnQixDQUFDLGNBQWMsV0FBVyxnQkFBZ0IsS0FDcEU7SUFBRSxrQkFBa0IsQ0FBQztJQUFHLGNBQWM7R0FBTSxJQUM1QztHQUNOLFFBQVEsaUJBQWlCLGFBQWEsV0FBVyxTQUFTLENBQUM7R0FDM0Qsb0JBQW9CLGlCQUFpQix5QkFDL0IsV0FBVyxxQkFDWDtHQUNOLGNBQWM7R0FDZCxlQUFlO0VBQ25CLENBQUM7Q0FDTDtDQUNBLE1BQU0sU0FBUyxZQUFZLHFCQUFxQixPQUFPLFdBQVcsVUFBVSxJQUN0RSxXQUFXLFdBQVcsSUFDdEIsWUFBWTtFQUFFLEdBQUcsU0FBUztFQUFjLEdBQUc7Q0FBaUIsQ0FBQztDQUNuRSxNQUFNLFlBQVksTUFBTSxVQUFVLENBQUMsTUFBTTtFQUNyQyxNQUFNLFFBQVEsSUFBSSxTQUFTLElBQUk7RUFDL0IsTUFBTSxpQkFBaUIsU0FBUyxNQUFNO0VBQ3RDLElBQUksZ0JBQWdCO0dBQ2hCLE1BQU0sV0FBVyxlQUFlLE9BQzFCLGVBQWUsS0FBSyxLQUNwQixlQUFlO0dBQ3JCLElBQUksU0FBUyxPQUNULGlCQUFpQjtJQUNiLFNBQVMsTUFBTTtJQUNmLFFBQVEsZ0JBQ0osV0FBVyxTQUFTLE1BQU0sS0FDMUIsU0FBUyxPQUFPO0dBQ3hCLENBQUM7RUFFVDtDQUNKO0NBQ0EsTUFBTSxpQkFBaUIscUJBQXFCO0VBTXhDLE1BQU0sRUFBRSxNQUFNLE1BQU0sUUFBUSxHQUFHLGNBQWM7RUFDN0MsSUFBSSxPQUFPLEtBQUssU0FBUyxDQUFDLENBQUMsUUFDdkIsYUFBYTtHQUNULEdBQUc7R0FDSCxHQUFHO0VBQ1A7Q0FFUjtDQUNBLFVBQVUsTUFBTSxVQUFVLEVBQUUsTUFBTSxjQUFjLENBQUM7Q0FDakQsTUFBTSw0QkFBNEIsV0FBVyxTQUFTLGFBQWEsS0FDL0QsU0FBUyxjQUFjLENBQUMsQ0FBQyxNQUFNLFdBQVc7RUFDdEMsTUFBTSxRQUFRLFNBQVMsWUFBWTtFQUNuQyxVQUFVLE1BQU0sS0FBSyxFQUNqQixXQUFXLE1BQ2YsQ0FBQztDQUNMLENBQUM7Q0FDTCxNQUFNLHNCQUFzQixRQUFRLFVBQVUsQ0FBQyxNQUFNO0VBQ2pELGlCQUFpQixZQUFZLE1BQU07RUFDbkMsSUFBSSxDQUFDLFFBQVEsV0FBVztHQUNwQixNQUFNLGlCQUFpQixlQUFlLGdCQUFnQixhQUFhLEtBQUEsR0FBVyxPQUFPO0dBQ3JGLFdBQVcsY0FBYztHQUN6QixXQUFXLFVBQVUsQ0FBQyxjQUFjLGNBQWM7RUFDdEQ7RUFDQSxJQUFJLENBQUMsUUFBUSxhQUNULFVBQVU7RUFFZCxVQUFVLE1BQU0sS0FBSztHQUNqQixHQUFHO0dBQ0gsZUFBZTtFQUNuQixDQUFDO0NBQ0w7Q0FDQSxNQUFNLFVBQVU7RUFDWixTQUFTO0dBQ0w7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQSxJQUFJLFVBQVU7SUFDVixPQUFPO0dBQ1g7R0FDQSxJQUFJLGNBQWM7SUFDZCxPQUFPO0dBQ1g7R0FDQSxJQUFJLFNBQVM7SUFDVCxPQUFPO0dBQ1g7R0FDQSxJQUFJLE9BQU8sT0FBTztJQUNkLFNBQVM7R0FDYjtHQUNBLElBQUksaUJBQWlCO0lBQ2pCLE9BQU87R0FDWDtHQUNBLElBQUksU0FBUztJQUNULE9BQU87R0FDWDtHQUNBLElBQUksT0FBTyxPQUFPO0lBQ2QsU0FBUztHQUNiO0dBQ0EsSUFBSSxhQUFhO0lBQ2IsT0FBTztHQUNYO0dBQ0EsSUFBSSxXQUFXO0lBQ1gsT0FBTztHQUNYO0dBQ0EsSUFBSSxTQUFTLE9BQU87SUFDaEIsV0FBVztLQUNQLEdBQUc7S0FDSCxHQUFHO0lBQ1A7SUFDQSw4QkFBOEIsbUJBQW1CLFNBQVMsSUFBSTtJQUM5RCw2QkFBNkIsbUJBQW1CLFNBQVMsY0FBYztJQUN2RSxtQ0FDSSxTQUFTLGlCQUFpQixnQkFBZ0I7R0FDbEQ7RUFDSjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDSjtDQUNBLE9BQU87RUFDSCxHQUFHO0VBQ0gsYUFBYTtDQUNqQjtBQUNKO0FBRUEsSUFBTSxnQkFBZ0I7Q0FDbEIsTUFBTSxlQUFlO0NBQ3JCLGdCQUFnQixlQUFlO0NBQy9CLGtCQUFrQixlQUFlO0NBQ2pDLFVBQVUsS0FBQTtDQUNWLGNBQWMsS0FBQTtDQUNkLFlBQVksS0FBQTtDQUNaLGtCQUFrQixLQUFBO0NBQ2xCLDJCQUEyQixLQUFBO0NBQzNCLFNBQVMsS0FBQTtBQUNiOzs7Ozs7Ozs7Ozs7Ozs7QUFlQSxTQUFTLFFBQVEsUUFBUSxDQUFDLEdBQUc7Q0FDekIsTUFBTSxlQUFBLGFBQXFCLE9BQU8sS0FBQSxDQUFTO0NBQzNDLE1BQU0sVUFBQSxhQUFnQixPQUFPLEtBQUEsQ0FBUztDQUN0QyxNQUFNLG1CQUFBLGFBQXlCLE9BQU8sTUFBTSxXQUFXO0NBQ3ZELE1BQU0sZUFBQSxhQUFxQixPQUFPLENBQUMsQ0FBQyxNQUFNLFFBQVE7Q0FDbEQsTUFBTSxDQUFDLFdBQVcsbUJBQUEsYUFBeUIsZ0JBQWdCO0VBQ3ZELEdBQUcsWUFBWSxrQkFBa0I7RUFDakMsV0FBVyxXQUFXLE1BQU0sYUFBYTtFQUN6QyxRQUFRLE1BQU0sVUFBVSxDQUFDO0VBQ3pCLFVBQVUsTUFBTSxZQUFZO0VBQzVCLGVBQWUsV0FBVyxNQUFNLGFBQWEsSUFDdkMsS0FBQSxJQUNBLE1BQU07Q0FDaEIsRUFBRTtDQUNGLElBQUksQ0FBQyxhQUFhLFdBQ2IsTUFBTSxlQUFlLGlCQUFpQixZQUFZLE1BQU0sYUFBYztFQUN2RSxpQkFBaUIsVUFBVSxNQUFNO0VBQ2pDLElBQUksTUFBTSxhQUFhO0dBQ25CLGFBQWEsVUFBVTtJQUNuQixHQUFHLE1BQU07SUFDVDtHQUNKO0dBQ0EsSUFBSSxNQUFNLGlCQUFpQixDQUFDLFdBQVcsTUFBTSxhQUFhLEdBQ3RELE1BQU0sWUFBWSxNQUFNLE1BQU0sZUFBZSxNQUFNLFlBQVk7RUFFdkUsT0FDSztHQUNELE1BQU0sRUFBRSxhQUFhLEdBQUcsU0FBUyxrQkFBa0IsS0FBSztHQUN4RCxhQUFhLFVBQVU7SUFDbkIsR0FBRztJQUNIO0dBQ0o7RUFDSjtDQUNKO0NBQ0EsTUFBTSxVQUFVLGFBQWEsUUFBUTtDQUNyQyxNQUFNLGtCQUFrQixRQUFRO0NBQ2hDLE1BQU0saUJBQWlCLENBQUM7Q0FDeEIsS0FBSyxNQUFNLE9BQU8sZUFDZCxJQUFJLE9BQU8sbUJBQW1CLEVBQUUsT0FBTyxRQUNuQyxlQUFlLE9BQU8sY0FBYztDQUc1QyxRQUFRLFdBQVc7RUFDZixHQUFHO0VBQ0gsR0FBRztFQUNILFVBQVUsTUFBTTtDQUNwQjtDQUNBLE1BQU0sNkJBQTZCO0VBQy9CLEdBQUcsUUFBUTtFQUNYLGVBQWUsUUFBUTtDQUMzQjtDQUNBLE1BQU0sRUFBRSxnQkFBZ0IsYUFBYSxxQkFBcUIsbUJBQW1CO0NBQzdFLGdDQUFnQztFQUM1QixlQUFlLE1BQU0scUJBQXFCLGVBQWU7RUFDekQsTUFBTSxjQUFjLFFBQVEsV0FBVztHQUNuQyxXQUFXLFFBQVE7R0FDbkIsZ0JBQWdCLGdCQUFnQjtJQUM1QixHQUFHLFFBQVE7SUFDWCxlQUFlLFFBQVE7R0FDM0IsQ0FBQztHQUNELGNBQWM7RUFDbEIsQ0FBQztFQUNELGlCQUFpQixVQUFVO0dBQ3ZCLEdBQUc7R0FDSCxTQUFTO0VBQ2IsRUFBRTtFQUNGLFFBQVEsV0FBVyxVQUFVO0VBQzdCLGFBQWE7R0FDVCxZQUFZO0dBQ1osU0FBUyxNQUFNLG1CQUFtQjtFQUN0QztDQUNKLEdBQUc7RUFBQztFQUFTO0VBQWdCO0NBQVEsQ0FBQztDQUN0QyxhQUFNLGdCQUFnQixRQUFRLGFBQWEsTUFBTSxRQUFRLEdBQUcsQ0FBQyxTQUFTLE1BQU0sUUFBUSxDQUFDO0NBQ3JGLGFBQU0sZ0JBQWdCO0VBQ2xCLElBQUksTUFBTSxNQUNOLFFBQVEsU0FBUyxPQUFPLE1BQU07RUFFbEMsSUFBSSxNQUFNLGdCQUNOLFFBQVEsU0FBUyxpQkFBaUIsTUFBTTtDQUVoRCxHQUFHO0VBQUM7RUFBUyxNQUFNO0VBQU0sTUFBTTtDQUFjLENBQUM7Q0FDOUMsYUFBTSxnQkFBZ0I7RUFDbEIsSUFBSSxNQUFNLFFBQVE7R0FDZCxRQUFRLFdBQVcsTUFBTSxNQUFNO0dBQy9CLFFBQVEsWUFBWTtFQUN4QjtDQUNKLEdBQUcsQ0FBQyxTQUFTLE1BQU0sTUFBTSxDQUFDO0NBQzFCLGFBQU0sZ0JBQWdCO0VBQ2xCLElBQUksYUFBYSxXQUFXLENBQUMsTUFBTSxVQUMvQixhQUFhLFdBQVcsYUFBYSxRQUFRLFlBQVksZUFBZTtFQUU1RSxhQUFhLFVBQVUsQ0FBQyxDQUFDLE1BQU07Q0FDbkMsR0FBRyxDQUFDLE1BQU0sUUFBUSxDQUFDO0NBQ25CLGFBQU0sZ0JBQWdCO0VBQ2xCLE1BQU0sb0JBQ0YsUUFBUSxVQUFVLE1BQU0sS0FBSyxFQUN6QixRQUFRLFFBQVEsVUFBVSxFQUM5QixDQUFDO0NBQ1QsR0FBRyxDQUFDLFNBQVMsTUFBTSxnQkFBZ0IsQ0FBQztDQUNwQyxhQUFNLGdCQUFnQjtFQUNsQixJQUFJLFFBQVEsZ0JBQWdCLFNBQVM7R0FDakMsTUFBTSxVQUFVLFFBQVEsVUFBVTtHQUNsQyxJQUFJLFlBQVksVUFBVSxTQUN0QixRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQ3pCLFFBQ0osQ0FBQztFQUVUO0NBQ0osR0FBRyxDQUFDLFNBQVMsVUFBVSxPQUFPLENBQUM7Q0FDL0IsYUFBTSxnQkFBZ0I7RUFDbEIsSUFBSSxNQUFNLFVBQVUsQ0FBQyxVQUFVLE1BQU0sUUFBUSxRQUFRLE9BQU8sR0FBRztHQUMzRCxRQUFRLE9BQU8sTUFBTSxRQUFRO0lBQ3pCLGVBQWU7SUFDZixHQUFHLFFBQVEsU0FBUztHQUN4QixDQUFDO0dBQ0QsSUFBSSxFQUFFLFFBQVEsU0FBUyxnQkFDbkIsUUFBUSxTQUFTLGFBQWEsY0FDOUIsUUFBUSxVQUFVO0dBRXRCLFFBQVEsVUFBVSxNQUFNO0dBQ3hCLGlCQUFpQixXQUFXLEVBQUUsR0FBRyxNQUFNLEVBQUU7RUFDN0MsT0FFSSxRQUFRLG9CQUFvQjtDQUVwQyxHQUFHLENBQUMsU0FBUyxNQUFNLE1BQU0sQ0FBQztDQUMxQixhQUFNLGdCQUFnQjtFQUNsQixJQUFJLENBQUMsUUFBUSxPQUFPLE9BQU87R0FDdkIsUUFBUSxVQUFVO0dBQ2xCLFFBQVEsT0FBTyxRQUFRO0VBQzNCO0VBQ0EsSUFBSSxRQUFRLE9BQU8sT0FBTztHQUN0QixRQUFRLE9BQU8sUUFBUTtHQUN2QixRQUFRLFVBQVUsTUFBTSxLQUFLLEVBQUUsR0FBRyxRQUFRLFdBQVcsQ0FBQztFQUMxRDtFQUNBLFFBQVEsaUJBQWlCO0NBQzdCLENBQUM7Q0FDRCxhQUFhLFFBQVEsWUFBQSxhQUFrQixjQUFjLGtCQUFrQixXQUFXLE9BQU8sR0FBRyxDQUFDLFNBQVMsU0FBUyxDQUFDO0NBQ2hILE9BQU8sYUFBYTtBQUN4Qjs7Ozs7Ozs7Ozs7Ozs7O0FBZ0JBLElBQU0sU0FBUyxVQUFVLE1BQU0sT0FBTyxTQUFTO0NBQUUsTUFBTSxNQUFNO0NBQU8sR0FBRztBQUFNLENBQUMsQ0FBQyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=