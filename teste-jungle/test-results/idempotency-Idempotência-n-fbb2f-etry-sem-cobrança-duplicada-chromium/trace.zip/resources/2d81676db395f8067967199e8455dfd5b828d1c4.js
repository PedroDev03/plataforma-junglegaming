import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/auth-card.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { Separator } from "/src/components/ui/separator.tsx";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/auth/auth-card.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
export function AuthCard(t0) {
	const $ = _c(15);
	if ($[0] !== "157d2721c35224130d75a6a843ebbda2be0ac7216d2463e9e5be43f310da0721") {
		for (let $i = 0; $i < 15; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "157d2721c35224130d75a6a843ebbda2be0ac7216d2463e9e5be43f310da0721";
	}
	const { title, description, children } = t0;
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-2 text-xs font-medium text-muted-foreground",
			children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
				className: "size-3.5 text-primary",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 93
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "JungleNFT Acesso Seguro" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 158
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 10
		}, this);
		$[1] = t1;
	} else {
		t1 = $[1];
	}
	let t2;
	if ($[2] !== title) {
		t2 = /* @__PURE__ */ _jsxDEV(CardTitle, {
			role: "heading",
			"aria-level": 1,
			className: "text-2xl font-bold",
			children: title
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 10
		}, this);
		$[2] = title;
		$[3] = t2;
	} else {
		t2 = $[3];
	}
	let t3;
	if ($[4] !== description) {
		t3 = /* @__PURE__ */ _jsxDEV(CardDescription, { children: description }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 36,
			columnNumber: 10
		}, this);
		$[4] = description;
		$[5] = t3;
	} else {
		t3 = $[5];
	}
	let t4;
	if ($[6] !== t2 || $[7] !== t3) {
		t4 = /* @__PURE__ */ _jsxDEV(CardHeader, {
			className: "gap-1.5",
			children: [
				t1,
				t2,
				t3
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 10
		}, this);
		$[6] = t2;
		$[7] = t3;
		$[8] = t4;
	} else {
		t4 = $[8];
	}
	let t5;
	if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = /* @__PURE__ */ _jsxDEV(Separator, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 53,
			columnNumber: 10
		}, this);
		$[9] = t5;
	} else {
		t5 = $[9];
	}
	let t6;
	if ($[10] !== children) {
		t6 = /* @__PURE__ */ _jsxDEV(CardContent, {
			className: "pt-4",
			children
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 10
		}, this);
		$[10] = children;
		$[11] = t6;
	} else {
		t6 = $[11];
	}
	let t7;
	if ($[12] !== t4 || $[13] !== t6) {
		t7 = /* @__PURE__ */ _jsxDEV("main", {
			id: "main-content",
			tabIndex: -1,
			className: "mx-auto flex w-full max-w-md flex-1 items-center p-4 outline-none sm:py-12",
			children: /* @__PURE__ */ _jsxDEV(Card, {
				className: "w-full",
				children: [
					t4,
					t5,
					t6
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 135
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 68,
			columnNumber: 10
		}, this);
		$[12] = t4;
		$[13] = t6;
		$[14] = t7;
	} else {
		t7 = $[14];
	}
	return t7;
}
_c2 = AuthCard;
var _c2;
$RefreshReg$(_c2, "AuthCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/auth/auth-card.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/auth/auth-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/auth/auth-card.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/auth/auth-card.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUNBLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxNQUFNQyxhQUFhQyxpQkFBaUJDLFlBQVlDLGlCQUFpQjtBQUMxRSxTQUFTQyxpQkFBaUI7OztBQUUxQixPQUFPLFNBQUFDLFNBQUFDLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBa0IsUUFBQUssT0FBQUMsYUFBQUMsYUFBQVI7Q0FReEIsSUFBQVM7Q0FBQSxJQUFBUixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFTU0ksS0FBQTtHQUFlO2FBQWYsQ0FDRSx3QkFBQyxVQUFEO0lBQW9CO0lBQW9DO0dBQU07Ozs7YUFDOUQsNENBQU0sMEJBQThCOzs7O1dBQ2hDOzs7Ozs7RUFBQVIsRUFBQSxLQUFBUTtDQUFBO0VBQUFBLEtBQUFSLEVBQUE7Q0FBQTtDQUFBLElBQUFTO0NBQUEsSUFBQVQsRUFBQSxPQUFBSyxPQUFBO0VBQ05JLEtBQUEsd0JBQUMsV0FBRDtHQUFnQjtHQUFzQjtHQUFhO2FBQ2hESjtFQURPOzs7OztFQUVFTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQVM7Q0FBQTtFQUFBQSxLQUFBVCxFQUFBO0NBQUE7Q0FBQSxJQUFBVTtDQUFBLElBQUFWLEVBQUEsT0FBQU0sYUFBQTtFQUNaSSxLQUFBLHdCQUFDLGlCQUFELFlBQWtCSixZQUFGOzs7OztFQUFnQ04sRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFVO0NBQUE7RUFBQUEsS0FBQVYsRUFBQTtDQUFBO0NBQUEsSUFBQVc7Q0FBQSxJQUFBWCxFQUFBLE9BQUFTLE1BQUFULEVBQUEsT0FBQVUsSUFBQTtFQVJsREMsS0FBQSx3QkFBQyxZQUFEO0dBQXNCO2FBQXRCO0lBQ0VIO0lBSUFDO0lBR0FDO0dBUlM7Ozs7OztFQVNFVixFQUFBLEtBQUFTO0VBQUFULEVBQUEsS0FBQVU7RUFBQVYsRUFBQSxLQUFBVztDQUFBO0VBQUFBLEtBQUFYLEVBQUE7Q0FBQTtDQUFBLElBQUFZO0NBQUEsSUFBQVosRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBQ2JRLEtBQUEsd0JBQUMsV0FBRCxDQUFVOzs7OztFQUFHWixFQUFBLEtBQUFZO0NBQUE7RUFBQUEsS0FBQVosRUFBQTtDQUFBO0NBQUEsSUFBQWE7Q0FBQSxJQUFBYixFQUFBLFFBQUFPLFVBQUE7RUFDYk0sS0FBQSx3QkFBQyxhQUFEO0dBQXVCO0dBQVFOO0VBQW5COzs7OztFQUEwQ1AsRUFBQSxNQUFBTztFQUFBUCxFQUFBLE1BQUFhO0NBQUE7RUFBQUEsS0FBQWIsRUFBQTtDQUFBO0NBQUEsSUFBQWM7Q0FBQSxJQUFBZCxFQUFBLFFBQUFXLE1BQUFYLEVBQUEsUUFBQWEsSUFBQTtFQWpCMURDLEtBQUE7R0FDSztHQUNPO0dBQ0E7YUFFVix3QkFBQyxNQUFEO0lBQWdCO2NBQWhCO0tBQ0VIO0tBVUFDO0tBQ0FDO0lBWkc7Ozs7OztFQWNBOzs7OztFQUFBYixFQUFBLE1BQUFXO0VBQUFYLEVBQUEsTUFBQWE7RUFBQWIsRUFBQSxNQUFBYztDQUFBO0VBQUFBLEtBQUFkLEVBQUE7Q0FBQTtDQUFBLE9BbkJQYztBQW1CTyIsIm5hbWVzIjpbIlNwYXJrbGVzIiwiQ2FyZCIsIkNhcmRDb250ZW50IiwiQ2FyZERlc2NyaXB0aW9uIiwiQ2FyZEhlYWRlciIsIkNhcmRUaXRsZSIsIlNlcGFyYXRvciIsIkF1dGhDYXJkIiwidDAiLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsInRpdGxlIiwiZGVzY3JpcHRpb24iLCJjaGlsZHJlbiIsInQxIiwidDIiLCJ0MyIsInQ0IiwidDUiLCJ0NiIsInQ3Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImF1dGgtY2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHR5cGUgeyBSZWFjdE5vZGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IFNwYXJrbGVzIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgQ2FyZCwgQ2FyZENvbnRlbnQsIENhcmREZXNjcmlwdGlvbiwgQ2FyZEhlYWRlciwgQ2FyZFRpdGxlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnXG5pbXBvcnQgeyBTZXBhcmF0b3IgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc2VwYXJhdG9yJ1xuXG5leHBvcnQgZnVuY3Rpb24gQXV0aENhcmQoe1xuICB0aXRsZSxcbiAgZGVzY3JpcHRpb24sXG4gIGNoaWxkcmVuLFxufToge1xuICB0aXRsZTogc3RyaW5nXG4gIGRlc2NyaXB0aW9uOiBzdHJpbmdcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZVxufSkge1xuICByZXR1cm4gKFxuICAgIDxtYWluXG4gICAgICBpZD1cIm1haW4tY29udGVudFwiXG4gICAgICB0YWJJbmRleD17LTF9XG4gICAgICBjbGFzc05hbWU9XCJteC1hdXRvIGZsZXggdy1mdWxsIG1heC13LW1kIGZsZXgtMSBpdGVtcy1jZW50ZXIgcC00IG91dGxpbmUtbm9uZSBzbTpweS0xMlwiXG4gICAgPlxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwidy1mdWxsXCI+XG4gICAgICAgIDxDYXJkSGVhZGVyIGNsYXNzTmFtZT1cImdhcC0xLjVcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwic2l6ZS0zLjUgdGV4dC1wcmltYXJ5XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPkp1bmdsZU5GVCBBY2Vzc28gU2VndXJvPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxDYXJkVGl0bGUgcm9sZT1cImhlYWRpbmdcIiBhcmlhLWxldmVsPXsxfSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGRcIj5cbiAgICAgICAgICAgIHt0aXRsZX1cbiAgICAgICAgICA8L0NhcmRUaXRsZT5cbiAgICAgICAgICA8Q2FyZERlc2NyaXB0aW9uPntkZXNjcmlwdGlvbn08L0NhcmREZXNjcmlwdGlvbj5cbiAgICAgICAgPC9DYXJkSGVhZGVyPlxuICAgICAgICA8U2VwYXJhdG9yIC8+XG4gICAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9XCJwdC00XCI+e2NoaWxkcmVufTwvQ2FyZENvbnRlbnQ+XG4gICAgICA8L0NhcmQ+XG4gICAgPC9tYWluPlxuICApXG59XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9jb21wb25lbnRzL2F1dGgvYXV0aC1jYXJkLnRzeCJ9