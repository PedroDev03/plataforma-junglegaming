import { n as __exportAll, r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=e9f94b2e";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-cNwuCTLA.js?v=e9f94b2e";
import { r as useIsoLayoutEffect, t as useStableCallback } from "/node_modules/.vite/deps/formatErrorMessage-BEgQI17N.js?v=e9f94b2e";
import { d as isElement, f as isHTMLElement, g as isShadowRoot, l as getWindow } from "/node_modules/.vite/deps/floating-ui.utils.dom-B45hE2lE.js?v=e9f94b2e";
import { At as addEventListener, E as useFloatingParentNodeId, Et as webkit, P as DROPDOWN_COLLISION_AVOIDANCE, S as useDismiss, Y as getFloatingFocusElement, at as pressableTriggerOpenStateMapping, b as useUnmountAfterClose, ct as pressed$1, dt as closed$4, ft as endingStyle$5, ht as startingStyle$5, it as popupTransitionStateMapping, k as FloatingPortal, lt as align$3, mt as side$5, n as ReactStore, o as PopupTriggerMap, ot as triggerOpenStateMapping, pt as open$4, q as useValueAsRef, rt as popupStateMapping, s as FOCUSABLE_POPUP_PROPS, st as popupOpen$2, t as FloatingRootStore, u as attachPreventUnmountOnClose, ut as anchorHidden$1, xt as isVirtualClick } from "/node_modules/.vite/deps/FloatingRootStore-BMBEPfxq.js?v=e9f94b2e";
import { n as ownerDocument, t as inertValue } from "/node_modules/.vite/deps/inertValue-DbKApsSW.js?v=e9f94b2e";
import { c as EMPTY_OBJECT, l as NOOP, n as useRenderElement, o as useMergedRefs, s as EMPTY_ARRAY, u as useRefWithInit } from "/node_modules/.vite/deps/useRenderElement-CvMw8z9e.js?v=e9f94b2e";
import { n as useTimeout } from "/node_modules/.vite/deps/useTimeout-w0MCIDxv.js?v=e9f94b2e";
import { a as transitionStatusMapping, l as useAnimationFrame, o as endingStyle$6, r as useTransitionStatus, s as startingStyle$6, t as useOpenChangeComplete } from "/node_modules/.vite/deps/useOpenChangeComplete-BJDlY1Cs.js?v=e9f94b2e";
import { a as useClick, i as InternalBackdrop, o as FloatingFocusManager, t as useOpenInteractionType } from "/node_modules/.vite/deps/useOpenInteractionType-DACsa5HR.js?v=e9f94b2e";
import { d as getTarget, l as closest, u as contains } from "/node_modules/.vite/deps/composite-DUPI88po.js?v=e9f94b2e";
import { C as windowResize, d as itemPress, h as none, s as imperativeAction, t as cancelOpen, w as createChangeEventDetails } from "/node_modules/.vite/deps/reason-parts-D-IkPsXA.js?v=e9f94b2e";
import { n as visuallyHiddenInput, t as visuallyHidden } from "/node_modules/.vite/deps/visuallyHidden-DjYUaVmG.js?v=e9f94b2e";
import { v as rectToClientRect } from "/node_modules/.vite/deps/floating-ui.utils-BnTHImEf.js?v=e9f94b2e";
import { n as useId, t as useBaseUiId } from "/node_modules/.vite/deps/useBaseUiId-UM7l9pLZ.js?v=e9f94b2e";
import { r as mergeProps } from "/node_modules/.vite/deps/merge-props-v5iSnvoO.js?v=e9f94b2e";
import { a as stringifyAsValue, c as useToolbarRootContext, i as stringifyAsLabel, l as useTypeahead, m as useListNavigation, n as resolveMultipleLabels, o as isMouseWithinBounds, r as resolveSelectedLabel, s as useAnchoredPopupScrollLock, t as hasNullItemLabel } from "/node_modules/.vite/deps/resolveValueLabel-BgZlXZPw.js?v=e9f94b2e";
import { l as getDisabledMountTransitionStyles, n as usePositioner, r as useAnchorPositioning, t as usePreviousValue, u as platform } from "/node_modules/.vite/deps/usePreviousValue-e4KgGpny.js?v=e9f94b2e";
import { t as useButton } from "/node_modules/.vite/deps/useButton-DC28DUmR.js?v=e9f94b2e";
import { a as COMPOSITE_KEYS } from "/node_modules/.vite/deps/composite-BSvBzXai.js?v=e9f94b2e";
import { t as useValueChanged } from "/node_modules/.vite/deps/useValueChanged-DCSKsMx_.js?v=e9f94b2e";
import { t as useControlled } from "/node_modules/.vite/deps/useControlled-BzU0LOuy.js?v=e9f94b2e";
import { i as fieldValidityMapping, n as useFieldRootContext, t as useLabelableContext } from "/node_modules/.vite/deps/LabelableContext-DbTSnt6H.js?v=e9f94b2e";
import { n as useSetFieldFocused, t as useLabelableId } from "/node_modules/.vite/deps/useLabelableId-ZH4XHyqG.js?v=e9f94b2e";
import { n as useRegisterFieldControl, t as useFormContext } from "/node_modules/.vite/deps/FormContext-CZZj3phG.js?v=e9f94b2e";
import { t as useCompositeListItem } from "/node_modules/.vite/deps/useCompositeListItem-YDOAP90w.js?v=e9f94b2e";
import { t as useDirection } from "/node_modules/.vite/deps/DirectionContext-BppzJsM-.js?v=e9f94b2e";
import { n as CompositeList, t as isElementDisabled } from "/node_modules/.vite/deps/isElementDisabled-DqxxBdPv.js?v=e9f94b2e";
import { t as SeparatorDataAttributes_exports } from "/node_modules/.vite/deps/SeparatorDataAttributes-BfHlrb8X.js?v=e9f94b2e";
import { t as useCSPContext } from "/node_modules/.vite/deps/CSPContext-4cn-oTPe.js?v=e9f94b2e";
// node_modules/@base-ui/react/floating-ui-react/hooks/useFloatingRootContext.mjs
function useFloatingRootContext(options) {
	const { open = false, onOpenChange, elements = {} } = options;
	const floatingId = useId();
	const nested = useFloatingParentNodeId() != null;
	{
		const optionDomReference = elements.reference;
		if (optionDomReference && !isElement(optionDomReference)) console.error("Cannot pass a virtual element to the `elements.reference` option,", "as it must be a real DOM element. Use `context.setPositionReference()`", "instead.");
	}
	const store = useRefWithInit(() => new FloatingRootStore({
		open,
		transitionStatus: void 0,
		onOpenChange,
		referenceElement: elements.reference ?? null,
		floatingElement: elements.floating ?? null,
		triggerElements: new PopupTriggerMap(),
		floatingId,
		syncOnly: false,
		nested
	})).current;
	useIsoLayoutEffect(() => {
		const valuesToSync = {
			open,
			floatingId
		};
		if (elements.reference !== void 0) {
			valuesToSync.referenceElement = elements.reference;
			valuesToSync.domReferenceElement = isElement(elements.reference) ? elements.reference : null;
		}
		if (elements.floating !== void 0) valuesToSync.floatingElement = elements.floating;
		store.update(valuesToSync);
	}, [
		open,
		floatingId,
		elements.reference,
		elements.floating,
		store
	]);
	store.context.onOpenChange = onOpenChange;
	store.context.nested = nested;
	return store;
}
// node_modules/@base-ui/react/utils/useRegisteredLabelId.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function useRegisteredLabelId(idProp, setLabelId) {
	const id = useBaseUiId(idProp);
	useIsoLayoutEffect(() => {
		setLabelId(id);
		return () => {
			setLabelId((currentId) => currentId === id ? void 0 : currentId);
		};
	}, [id, setLabelId]);
	return id;
}
// node_modules/@base-ui/react/internals/labelable-provider/useLabel.mjs
function useLabel(params = {}) {
	const { id: idProp, fallbackControlId, native = false, setLabelId: setLabelIdProp, focusControl: focusControlProp } = params;
	const { controlId: contextControlId, setLabelId: setContextLabelId } = useLabelableContext();
	const id = useRegisteredLabelId(idProp, useStableCallback((nextLabelId) => {
		setContextLabelId(nextLabelId);
		setLabelIdProp?.(nextLabelId);
	}));
	const resolvedControlId = contextControlId ?? fallbackControlId;
	function focusControl(event) {
		if (focusControlProp) {
			focusControlProp(event, resolvedControlId);
			return;
		}
		if (!resolvedControlId) return;
		const controlElement = getControlById(event.currentTarget, resolvedControlId);
		if (isHTMLElement(controlElement)) focusElementWithVisible(controlElement);
	}
	function handleInteraction(event) {
		const target = getTarget(event.nativeEvent);
		if (closest(target, "button,input,select,textarea")) return;
		if (!event.defaultPrevented && event.detail > 1) event.preventDefault();
		if (native) return;
		focusControl(event);
	}
	return native ? {
		id,
		htmlFor: resolvedControlId,
		onMouseDown: handleInteraction
	} : {
		id,
		onClick: handleInteraction,
		onPointerDown(event) {
			event.preventDefault();
		}
	};
}
function getControlById(label, id) {
	let root = label.getRootNode();
	while (isShadowRoot(root)) {
		const element = root.getElementById(id);
		if (element) return element;
		root = root.host.getRootNode();
	}
	return ownerDocument(label).getElementById(id);
}
function focusElementWithVisible(element) {
	element.focus({ focusVisible: true });
}
// node_modules/@base-ui/utils/useOnFirstRender.mjs
function useOnFirstRender(fn) {
	const ref = import_react.useRef(true);
	if (ref.current) {
		ref.current = false;
		fn();
	}
}
// node_modules/@base-ui/react/select/root/SelectRootContext.mjs
var SelectRootContext = /*#__PURE__*/ import_react.createContext(void 0);
SelectRootContext.displayName = "SelectRootContext";
var SelectFloatingContext = /*#__PURE__*/ import_react.createContext(void 0);
SelectFloatingContext.displayName = "SelectFloatingContext";
function useSelectRootContext() {
	const store = import_react.useContext(SelectRootContext);
	if (store === void 0) throw new Error("Base UI: SelectRootContext is missing. Select parts must be placed within <Select.Root>.");
	return store;
}
function useSelectFloatingContext() {
	const context = import_react.useContext(SelectFloatingContext);
	if (context === void 0) throw new Error("Base UI: SelectFloatingContext is missing. Select parts must be placed within <Select.Root>.");
	return context;
}
// node_modules/@base-ui/utils/areArraysEqual.mjs
/**
* Compares two arrays element-wise.
*
* The default comparison is `Object.is`, so `NaN` equals `NaN` and `0` does not equal `-0`.
*/
function areArraysEqual(array1, array2, itemComparer = Object.is) {
	const { length } = array1;
	if (length !== array2.length) return false;
	for (let i = 0; i < length; i += 1) if (!itemComparer(array1[i], array2[i])) return false;
	return true;
}
// node_modules/@base-ui/react/internals/itemEquality.mjs
var defaultItemEquality = (itemValue, selectedValue) => Object.is(itemValue, selectedValue);
function compareItemEquality(itemValue, selectedValue, comparer) {
	if (itemValue == null || selectedValue == null) return Object.is(itemValue, selectedValue);
	return comparer(itemValue, selectedValue);
}
function isSelectedValueDirty(currentValue, initialValue, comparer) {
	if (Array.isArray(currentValue) && Array.isArray(initialValue)) return !areArraysEqual(currentValue, initialValue, (itemValue, initialItemValue) => compareItemEquality(itemValue, initialItemValue, comparer));
	return currentValue !== initialValue;
}
function selectedValueIncludes(selectedValues, itemValue, comparer) {
	if (!selectedValues) return false;
	return selectedValues.some((selectedValue) => {
		if (selectedValue === void 0) return false;
		return compareItemEquality(itemValue, selectedValue, comparer);
	});
}
function findItemIndex(itemValues, selectedValue, comparer) {
	if (!itemValues) return -1;
	return itemValues.findIndex((itemValue) => {
		if (itemValue === void 0) return false;
		return compareItemEquality(itemValue, selectedValue, comparer);
	});
}
function createSelectionMatcher(selectedValues, comparer) {
	if (comparer !== defaultItemEquality) return (itemValue) => selectedValueIncludes(selectedValues, itemValue, comparer);
	const index = new Set(selectedValues);
	index.delete(void 0);
	return (itemValue) => index.has(itemValue) && (itemValue !== 0 || selectedValues.some((v) => Object.is(itemValue, v)));
}
function findSelectionIndex(itemValues, selectedValue, comparer, multiple) {
	const index = multiple && Array.isArray(selectedValue) ? itemValues.findIndex(createSelectionMatcher(selectedValue, comparer)) : findItemIndex(itemValues, selectedValue, comparer);
	return index === -1 ? null : index;
}
/** Resolves the first selected index as items register or change. */
function resolveSelectedIndex(index, itemValue, registry, selectedValues, comparer, currentIndex) {
	if (selectedValueIncludes(selectedValues, itemValue, comparer)) return currentIndex != null && index > currentIndex && selectedValueIncludes(selectedValues, registry[currentIndex], comparer) ? currentIndex : index;
	return index === currentIndex ? findSelectionIndex(registry, selectedValues, comparer, true) : currentIndex;
}
function removeItem(selectedValues, itemValue, comparer) {
	return selectedValues.filter((selectedValue) => !compareItemEquality(itemValue, selectedValue, comparer));
}
// node_modules/@base-ui/react/select/store.mjs
/**
* Non-reactive values shared with the select parts. Nothing here is observable through
* `selectors`, so writing to a ref never notifies subscribers.
*/
var selectors = {
	id: (state) => state.id,
	labelId: (state) => state.labelId,
	modal: (state) => state.modal,
	multiple: (state) => state.multiple,
	disabled: (state) => state.disabled,
	readOnly: (state) => state.readOnly,
	required: (state) => state.required,
	highlightItemOnHover: (state) => state.highlightItemOnHover,
	items: (state) => state.items,
	itemToStringLabel: (state) => state.itemToStringLabel,
	isItemEqualToValue: (state) => state.isItemEqualToValue,
	value: (state) => state.value,
	hasSelectedValue: (state) => {
		const { value, multiple, itemToStringValue } = state;
		if (value == null) return false;
		if (multiple && Array.isArray(value)) return value.length > 0;
		return stringifyAsValue(value, itemToStringValue) !== "";
	},
	hasNullItemLabel: (state, enabled) => {
		return enabled ? hasNullItemLabel(state.items) : false;
	},
	open: (state) => state.open,
	mounted: (state) => state.mounted,
	forceMount: (state) => state.forceMount,
	transitionStatus: (state) => state.transitionStatus,
	openMethod: (state) => state.openMethod,
	activeIndex: (state) => state.activeIndex,
	selectedIndex: (state) => state.selectedIndex,
	isActive: (state, index) => state.activeIndex === index,
	isSelected: (state, itemValue) => {
		const comparer = state.isItemEqualToValue;
		const storeValue = state.value;
		if (state.multiple) return Array.isArray(storeValue) && storeValue.some((selectedItem) => compareItemEquality(itemValue, selectedItem, comparer));
		return compareItemEquality(itemValue, storeValue, comparer);
	},
	isSelectedByFocus: (state, index) => {
		return state.selectedIndex === index;
	},
	popupProps: (state) => state.popupProps,
	triggerProps: (state) => state.triggerProps,
	itemRoot: (state) => state.itemRoot,
	triggerElement: (state) => state.triggerElement,
	positionerElement: (state) => state.positionerElement,
	listElement: (state) => state.listElement,
	popupSide: (state) => state.popupSide,
	scrollUpArrowVisible: (state) => state.scrollUpArrowVisible,
	scrollDownArrowVisible: (state) => state.scrollDownArrowVisible,
	hasScrollArrows: (state) => state.hasScrollArrows
};
// node_modules/@base-ui/utils/clamp.mjs
function clamp(val, min = Number.MIN_SAFE_INTEGER, max = Number.MAX_SAFE_INTEGER) {
	return Math.max(min, Math.min(val, max));
}
function getMaxScrollOffset(scrollSize, clientSize) {
	return Math.max(0, scrollSize - clientSize);
}
function normalizeScrollOffset(value, max) {
	if (max <= 0) return 0;
	const clamped = clamp(value, 0, max);
	const startDistance = clamped;
	const endDistance = max - clamped;
	const withinStartTolerance = startDistance <= 1;
	const withinEndTolerance = endDistance <= 1;
	if (withinStartTolerance && withinEndTolerance) return startDistance <= endDistance ? 0 : max;
	if (withinStartTolerance) return 0;
	if (withinEndTolerance) return max;
	return clamped;
}
// node_modules/@base-ui/react/select/root/SelectRoot.mjs
/**
* Groups all parts of the select.
* Doesn't render its own HTML element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
function SelectRoot(props) {
	const { id, value: valueProp, defaultValue = null, onValueChange, open: openProp, defaultOpen = false, onOpenChange, name: nameProp, form, autoComplete, disabled: disabledProp = false, readOnly = false, required = false, modal = true, actionsRef, inputRef, onOpenChangeComplete, items, multiple = false, itemToStringLabel, itemToStringValue, isItemEqualToValue = defaultItemEquality, highlightItemOnHover = true, children } = props;
	const { clearErrors } = useFormContext();
	const { setDirty, setTouched, setFocused, validityData, setFilled, name: fieldName, disabled: fieldDisabled, validation, validationMode } = useFieldRootContext();
	const generatedId = useLabelableId({ id });
	const disabled = fieldDisabled || disabledProp;
	const name = fieldName ?? nameProp;
	const [value, setValueUnwrapped] = useControlled({
		controlled: valueProp,
		default: multiple ? defaultValue ?? EMPTY_ARRAY : defaultValue,
		name: "Select",
		state: "value"
	});
	const [open, setOpenUnwrapped] = useControlled({
		controlled: openProp,
		default: defaultOpen,
		name: "Select",
		state: "open"
	});
	const listRef = import_react.useRef([]);
	const labelsRef = import_react.useRef([]);
	const popupRef = import_react.useRef(null);
	const scrollHandlerRef = import_react.useRef(null);
	const scrollArrowsMountedCountRef = import_react.useRef(0);
	const valueRef = import_react.useRef(null);
	const valuesRef = import_react.useRef([]);
	const typingRef = import_react.useRef(false);
	const firstItemTextRef = import_react.useRef(null);
	const selectedItemTextRef = import_react.useRef(null);
	const selectionRef = import_react.useRef({
		allowSelectedMouseUp: false,
		allowUnselectedMouseUp: false,
		dragY: 0
	});
	const alignItemWithTriggerActiveRef = import_react.useRef(false);
	const initialValueRef = import_react.useRef(value);
	const { openMethod, triggerProps: interactionTypeProps } = useOpenInteractionType(open);
	const store = useRefWithInit(() => new ReactStore({
		id: generatedId,
		labelId: void 0,
		modal,
		multiple,
		disabled,
		readOnly,
		required,
		highlightItemOnHover,
		itemToStringLabel,
		itemToStringValue,
		isItemEqualToValue,
		value,
		open,
		mounted: open,
		transitionStatus: void 0,
		items,
		forceMount: false,
		openMethod: null,
		activeIndex: null,
		selectedIndex: null,
		popupProps: EMPTY_OBJECT,
		triggerProps: EMPTY_OBJECT,
		itemRoot: {
			props: EMPTY_OBJECT,
			multiple,
			disabled,
			readOnly,
			isItemEqualToValue
		},
		triggerElement: null,
		positionerElement: null,
		listElement: null,
		popupSide: null,
		scrollUpArrowVisible: false,
		scrollDownArrowVisible: false,
		hasScrollArrows: false
	}, {
		setValue: NOOP,
		setOpen: NOOP,
		handleScrollArrowVisibility: NOOP,
		onOpenChangeComplete: NOOP,
		listRef,
		popupRef,
		scrollHandlerRef,
		scrollArrowsMountedCountRef,
		valueRef,
		valuesRef,
		labelsRef,
		typingRef,
		selectionRef,
		firstItemTextRef,
		selectedItemTextRef,
		alignItemWithTriggerActiveRef,
		initialValueRef
	}, selectors)).current;
	const [preventUnmountOnClose, setPreventUnmountOnClose] = import_react.useState(false);
	const { mounted, transitionStatus, forceUnmount: handleUnmount } = useUnmountAfterClose({
		open,
		ref: popupRef,
		preventUnmountOnClose,
		setPreventUnmountOnClose,
		onUnmount() {
			store.update({
				activeIndex: null,
				openMethod: null,
				scrollUpArrowVisible: false,
				scrollDownArrowVisible: false
			});
			onOpenChangeComplete?.(false);
		}
	});
	const activeIndex = store.useState("activeIndex");
	const selectedIndex = store.useState("selectedIndex");
	const triggerElement = store.useState("triggerElement");
	const positionerElement = store.useState("positionerElement");
	const previousOpenMethod = usePreviousValue(openMethod);
	const renderedOpenMethod = openMethod ?? previousOpenMethod;
	const serializedValue = import_react.useMemo(() => {
		if (multiple) return "";
		return stringifyAsValue(value, itemToStringValue);
	}, [
		multiple,
		value,
		itemToStringValue
	]);
	const fieldStringValue = import_react.useMemo(() => {
		if (multiple && Array.isArray(value)) return value.map((currentValue) => stringifyAsValue(currentValue, itemToStringValue));
		return stringifyAsValue(value, itemToStringValue);
	}, [
		multiple,
		value,
		itemToStringValue
	]);
	const controlRef = useValueAsRef(triggerElement);
	const getStringifiedValueForForm = useStableCallback(() => fieldStringValue);
	useRegisterFieldControl(controlRef, generatedId, value, getStringifiedValueForForm, !disabled, nameProp);
	const hasSelectedValue = multiple ? Array.isArray(value) && value.length > 0 : value != null && serializedValue !== "";
	useIsoLayoutEffect(() => {
		setFilled(hasSelectedValue);
	}, [hasSelectedValue, setFilled]);
	useIsoLayoutEffect(function syncSelectedIndex() {
		const nextIndex = findSelectionIndex(valuesRef.current, value, isItemEqualToValue, multiple);
		if (nextIndex === null) selectedItemTextRef.current = null;
		if (open) return;
		store.set("selectedIndex", nextIndex);
	}, [
		multiple,
		open,
		value,
		isItemEqualToValue,
		store
	]);
	useValueChanged(value, () => {
		clearErrors(name);
		setDirty(isSelectedValueDirty(value, validityData.initialValue, isItemEqualToValue));
		validation.change(value);
	});
	const setOpen = useStableCallback((nextOpen, eventDetails) => {
		const openEventDetails = eventDetails;
		const shouldPreventUnmountOnClose = attachPreventUnmountOnClose(openEventDetails);
		onOpenChange?.(nextOpen, openEventDetails);
		if (eventDetails.isCanceled) return;
		if (!nextOpen) setPreventUnmountOnClose(shouldPreventUnmountOnClose());
		setOpenUnwrapped(nextOpen);
		if (!nextOpen && (eventDetails.reason === "focus-out" || eventDetails.reason === "outside-press")) {
			setTouched(true);
			setFocused(false);
			if (validationMode === "onBlur") validation.commit(value);
		}
	});
	import_react.useImperativeHandle(actionsRef, () => ({
		unmount: handleUnmount,
		close: () => {
			if (store.state.open) setOpen(false, createChangeEventDetails(imperativeAction));
		}
	}), [
		handleUnmount,
		setOpen,
		store
	]);
	const setValue = useStableCallback((nextValue, eventDetails) => {
		onValueChange?.(nextValue, eventDetails);
		if (eventDetails.isCanceled) return;
		setValueUnwrapped(nextValue);
	});
	const handleScrollArrowVisibility = useStableCallback((scroller) => {
		const maxScrollTop = getMaxScrollOffset(scroller.scrollHeight, scroller.clientHeight);
		const scrollTop = normalizeScrollOffset(scroller.scrollTop, maxScrollTop);
		const shouldShowUp = scrollTop > 0;
		const shouldShowDown = scrollTop < maxScrollTop;
		store.set("scrollUpArrowVisible", shouldShowUp);
		store.set("scrollDownArrowVisible", shouldShowDown);
	});
	const floatingContext = useFloatingRootContext({
		open,
		onOpenChange: setOpen,
		elements: {
			reference: triggerElement,
			floating: positionerElement
		}
	});
	const click = useClick(floatingContext, {
		enabled: !disabled,
		event: "mousedown"
	});
	const dismiss = useDismiss(floatingContext);
	const listNavigation = useListNavigation(floatingContext, {
		enabled: !disabled,
		listRef,
		activeIndex,
		selectedIndex,
		disabledIndices: EMPTY_ARRAY,
		onNavigate(nextActiveIndex) {
			if (nextActiveIndex === null && !open) return;
			store.set("activeIndex", nextActiveIndex);
		},
		focusItemOnHover: highlightItemOnHover
	});
	const typeahead = useTypeahead(floatingContext, {
		enabled: !disabled && (open || !readOnly && !multiple),
		listRef: labelsRef,
		activeIndex,
		selectedIndex,
		disabledIndices: (index) => isElementDisabled(listRef.current[index]),
		onMatch(index) {
			if (open) store.set("activeIndex", index);
			else setValue(valuesRef.current[index], createChangeEventDetails(none));
		},
		onTyping(typing) {
			typingRef.current = typing;
		}
	});
	const mergedTriggerProps = import_react.useMemo(() => mergeProps(typeahead.reference, listNavigation.reference, dismiss.reference, click.reference, interactionTypeProps), [
		click.reference,
		typeahead.reference,
		listNavigation.reference,
		dismiss.reference,
		interactionTypeProps
	]);
	const popupProps = import_react.useMemo(() => mergeProps(FOCUSABLE_POPUP_PROPS, typeahead.floating, listNavigation.floating, dismiss.floating), [
		typeahead.floating,
		listNavigation.floating,
		dismiss.floating
	]);
	const itemProps = listNavigation.item ?? EMPTY_OBJECT;
	const itemRoot = import_react.useMemo(() => ({
		props: itemProps,
		multiple,
		disabled,
		readOnly,
		isItemEqualToValue
	}), [
		itemProps,
		multiple,
		disabled,
		readOnly,
		isItemEqualToValue
	]);
	store.useContextCallback("setValue", setValue);
	store.useContextCallback("setOpen", setOpen);
	store.useContextCallback("handleScrollArrowVisibility", handleScrollArrowVisibility);
	store.useContextCallback("onOpenChangeComplete", onOpenChangeComplete);
	useOnFirstRender(() => {
		store.update({
			popupProps,
			triggerProps: mergedTriggerProps,
			itemRoot
		});
	});
	store.useSyncedValues({
		id: generatedId,
		modal,
		multiple,
		disabled,
		readOnly,
		required,
		highlightItemOnHover,
		value,
		open,
		mounted,
		transitionStatus,
		popupProps,
		triggerProps: mergedTriggerProps,
		itemRoot,
		items,
		itemToStringLabel,
		itemToStringValue,
		isItemEqualToValue,
		openMethod: renderedOpenMethod
	});
	const ref = useMergedRefs(inputRef, validation.inputRef);
	const hiddenInputName = multiple ? void 0 : name;
	const hiddenInputs = import_react.useMemo(() => {
		if (!multiple || !Array.isArray(value) || !name) return null;
		return value.map((v) => {
			const currentSerializedValue = stringifyAsValue(v, itemToStringValue);
			return /*#__PURE__*/ (0, import_jsx_runtime.jsx)("input", {
				type: "hidden",
				form,
				name,
				value: currentSerializedValue,
				disabled
			}, currentSerializedValue);
		});
	}, [
		multiple,
		value,
		form,
		name,
		itemToStringValue,
		disabled
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(SelectRootContext.Provider, {
		value: store,
		children: [
			/*#__PURE__*/ (0, import_jsx_runtime.jsx)(SelectFloatingContext.Provider, {
				value: floatingContext,
				children
			}),
			/*#__PURE__*/ (0, import_jsx_runtime.jsx)("input", {
				...validation.getValidationProps(disabled, {
					onFocus() {
						store.state.triggerElement?.focus({ focusVisible: true });
					},
					onChange(event) {
						if (event.nativeEvent.defaultPrevented || disabled || readOnly) return;
						const nextValue = event.currentTarget.value;
						const details = createChangeEventDetails(none, event.nativeEvent);
						function handleChange() {
							if (multiple) return;
							const nextValueLower = nextValue.toLowerCase();
							let matchingIndex = valuesRef.current.findIndex((candidate) => stringifyAsValue(candidate, itemToStringValue).toLowerCase() === nextValueLower || stringifyAsLabel(candidate, itemToStringLabel).toLowerCase() === nextValueLower);
							if (matchingIndex === -1) matchingIndex = valuesRef.current.findIndex((_, index) => {
								const renderedLabel = labelsRef.current[index];
								return renderedLabel != null && renderedLabel.toLowerCase() === nextValueLower;
							});
							const matchingValue = valuesRef.current[matchingIndex];
							if (matchingValue != null) setValue(matchingValue, details);
						}
						store.set("forceMount", true);
						queueMicrotask(handleChange);
					}
				}),
				id: generatedId && hiddenInputName == null ? `${generatedId}-hidden-input` : void 0,
				form,
				name: hiddenInputName,
				autoComplete,
				value: serializedValue,
				disabled,
				required: required && !(multiple && hasSelectedValue),
				readOnly,
				ref,
				style: name ? visuallyHiddenInput : visuallyHidden,
				tabIndex: -1,
				"aria-hidden": true,
				suppressHydrationWarning: true
			}),
			hiddenInputs
		]
	});
}
// node_modules/@base-ui/react/utils/resolveAriaLabelledBy.mjs
function getDefaultLabelId(id) {
	return id == null ? void 0 : `${id}-label`;
}
function resolveAriaLabelledBy(fieldLabelId, localLabelId) {
	return fieldLabelId ?? localLabelId;
}
// node_modules/@base-ui/react/select/label/SelectLabel.mjs
/**
* An accessible label that is automatically associated with the select trigger.
* Renders a `<div>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectLabel = /*#__PURE__*/ import_react.forwardRef(function SelectLabel(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const elementPropsWithoutId = elementProps;
	delete elementPropsWithoutId.id;
	const fieldRootContext = useFieldRootContext();
	const store = useSelectRootContext();
	const triggerElement = store.useState("triggerElement");
	const rootId = store.useState("id");
	const labelProps = useLabel({
		id: getDefaultLabelId(rootId),
		fallbackControlId: triggerElement?.id ?? rootId,
		setLabelId(nextLabelId) {
			const resolvedLabelId = typeof nextLabelId === "function" ? nextLabelId(store.state.labelId) : nextLabelId;
			store.set("labelId", resolvedLabelId);
		}
	});
	return useRenderElement("div", componentProps, {
		ref: forwardedRef,
		state: fieldRootContext.state,
		props: [labelProps, elementProps],
		stateAttributesMapping: fieldValidityMapping
	});
});
SelectLabel.displayName = "SelectLabel";
// node_modules/@base-ui/react/select/trigger/SelectTriggerDataAttributes.mjs
var SelectTriggerDataAttributes_exports = /* @__PURE__ */ __exportAll({
	dirty: () => dirty,
	disabled: () => disabled$1,
	filled: () => filled,
	focused: () => focused,
	invalid: () => invalid,
	placeholder: () => placeholder$1,
	popupOpen: () => popupOpen$1,
	popupSide: () => popupSide,
	pressed: () => pressed,
	readonly: () => readonly,
	required: () => required,
	touched: () => touched,
	valid: () => valid
});
/**
* Present when the corresponding select is open.
*/
var popupOpen$1 = popupOpen$2;
/**
* Present when the trigger is pressed.
*/
var pressed = pressed$1;
/**
* Present when the select is disabled.
*/
var disabled$1 = "data-disabled";
/**
* Present when the select is readonly.
*/
var readonly = "data-readonly";
/**
* Indicates which side the corresponding popup is positioned relative to its anchor.
* @type {'top' | 'bottom' | 'left' | 'right' | 'inline-end' | 'inline-start' | null}
*/
var popupSide = "data-popup-side";
/**
* Present when the select is required.
*/
var required = "data-required";
/**
* Present when the select is in a valid state (when wrapped in Field.Root).
*/
var valid = "data-valid";
/**
* Present when the select is in an invalid state (when wrapped in Field.Root).
*/
var invalid = "data-invalid";
/**
* Present when the select has been touched (when wrapped in Field.Root).
*/
var touched = "data-touched";
/**
* Present when the select's value has changed (when wrapped in Field.Root).
*/
var dirty = "data-dirty";
/**
* Present when the select has a value (when wrapped in Field.Root).
*/
var filled = "data-filled";
/**
* Present when the select trigger is focused (when wrapped in Field.Root).
*/
var focused = "data-focused";
/**
* Present when the select doesn't have a value.
*/
var placeholder$1 = "data-placeholder";
// node_modules/@base-ui/react/select/trigger/SelectTrigger.mjs
var SELECTED_DELAY = 400;
var stateAttributesMapping$3 = {
	...pressableTriggerOpenStateMapping,
	...fieldValidityMapping,
	popupSide: (side) => side ? { [popupSide]: side } : null,
	value: () => null
};
/**
* A button that opens the select popup.
* Renders a `<button>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectTrigger = /*#__PURE__*/ import_react.forwardRef(function SelectTrigger(componentProps, forwardedRef) {
	const { render, className, id: idProp, disabled: disabledProp = false, nativeButton = true, style, ...elementProps } = componentProps;
	const { setTouched, validationMode, validation, state: fieldState, disabled: fieldDisabled } = useFieldRootContext();
	const { labelId: fieldLabelId } = useLabelableContext();
	const store = useSelectRootContext();
	const readOnly = store.useState("readOnly");
	const required = store.useState("required");
	const selectDisabled = store.useState("disabled");
	const disabled = fieldDisabled || selectDisabled || disabledProp;
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const value = store.useState("value");
	const triggerProps = store.useState("triggerProps");
	const positionerElement = store.useState("positionerElement");
	const listElement = store.useState("listElement");
	const popupSideValue = store.useState("popupSide");
	const rootId = store.useState("id");
	const selectLabelId = store.useState("labelId");
	const hasSelectedValue = store.useState("hasSelectedValue");
	const popupSide = mounted && positionerElement ? popupSideValue : null;
	const id = idProp ?? rootId;
	const ariaLabelledBy = resolveAriaLabelledBy(fieldLabelId, selectLabelId);
	useLabelableId({ id: idProp });
	const positionerRef = useValueAsRef(positionerElement);
	const triggerRef = import_react.useRef(null);
	const setFocused = useSetFieldFocused(disabled, triggerRef);
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	const setTriggerElement = store.useStateSetter("triggerElement");
	const timeoutFocus = useTimeout();
	const timeoutMouseDown = useTimeout();
	const selectedDelayTimeout = useTimeout();
	import_react.useEffect(() => {
		if (open) {
			selectedDelayTimeout.start(SELECTED_DELAY, () => {
				store.context.selectionRef.current.allowUnselectedMouseUp = true;
				store.context.selectionRef.current.allowSelectedMouseUp = true;
			});
			return () => {
				selectedDelayTimeout.clear();
			};
		}
		store.context.selectionRef.current = {
			allowSelectedMouseUp: false,
			allowUnselectedMouseUp: false,
			dragY: 0
		};
		timeoutMouseDown.clear();
	}, [
		open,
		store,
		timeoutMouseDown,
		selectedDelayTimeout
	]);
	const mergedProps = mergeProps(triggerProps, {
		id,
		role: "combobox",
		"aria-expanded": open,
		"aria-haspopup": "listbox",
		"aria-controls": open ? listElement?.id ?? getFloatingFocusElement(positionerElement)?.id : void 0,
		"aria-labelledby": ariaLabelledBy,
		"aria-readonly": readOnly || void 0,
		"aria-required": required || void 0,
		tabIndex: disabled ? -1 : 0,
		onFocus(event) {
			setFocused(true);
			if (open && store.context.alignItemWithTriggerActiveRef.current) store.context.setOpen(false, createChangeEventDetails(none, event.nativeEvent));
			timeoutFocus.start(0, () => {
				store.set("forceMount", true);
			});
		},
		onBlur(event) {
			if (contains(positionerElement, event.relatedTarget)) return;
			setTouched(true);
			setFocused(false);
			if (validationMode === "onBlur") validation.commit(value);
		},
		onMouseDown(event) {
			if (open) return;
			const doc = ownerDocument(event.currentTarget);
			function handleMouseUp(mouseEvent) {
				if (!triggerRef.current) return;
				const mouseUpTarget = mouseEvent.target;
				if (contains(triggerRef.current, mouseUpTarget) || contains(positionerRef.current, mouseUpTarget)) return;
				if (isMouseWithinBounds(mouseEvent, triggerRef.current)) return;
				store.context.setOpen(false, createChangeEventDetails(cancelOpen, mouseEvent));
			}
			timeoutMouseDown.start(0, () => {
				doc.addEventListener("mouseup", handleMouseUp, { once: true });
			});
		}
	}, elementProps, getButtonProps);
	const props = validation.getValidationProps(disabled, mergedProps);
	props.role = "combobox";
	const state = {
		...fieldState,
		open,
		disabled,
		value,
		readOnly,
		popupSide,
		placeholder: !hasSelectedValue
	};
	return useRenderElement("button", componentProps, {
		ref: [
			forwardedRef,
			triggerRef,
			buttonRef,
			setTriggerElement
		],
		state,
		stateAttributesMapping: stateAttributesMapping$3,
		props
	});
});
SelectTrigger.displayName = "SelectTrigger";
// node_modules/@base-ui/react/select/value/SelectValue.mjs
var stateAttributesMapping$2 = { value: () => null };
/**
* A text label of the currently selected item.
* Renders a `<span>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectValue = /*#__PURE__*/ import_react.forwardRef(function SelectValue(componentProps, forwardedRef) {
	const { className, render, children: childrenProp, placeholder, style, ...elementProps } = componentProps;
	const store = useSelectRootContext();
	const value = store.useState("value");
	const items = store.useState("items");
	const itemToStringLabel = store.useState("itemToStringLabel");
	const hasSelectedValue = store.useState("hasSelectedValue");
	const shouldCheckNullItemLabel = !hasSelectedValue && placeholder != null && childrenProp == null;
	const hasNullLabel = store.useState("hasNullItemLabel", shouldCheckNullItemLabel);
	const state = {
		value,
		placeholder: !hasSelectedValue
	};
	let children = null;
	if (typeof childrenProp === "function") children = childrenProp(value);
	else if (childrenProp != null) children = childrenProp;
	else if (shouldCheckNullItemLabel && !hasNullLabel) children = placeholder;
	else if (Array.isArray(value)) children = resolveMultipleLabels(value, items, itemToStringLabel);
	else children = resolveSelectedLabel(value, items, itemToStringLabel);
	return useRenderElement("span", componentProps, {
		state,
		ref: [forwardedRef, store.context.valueRef],
		props: [{ children }, elementProps],
		stateAttributesMapping: stateAttributesMapping$2
	});
});
SelectValue.displayName = "SelectValue";
// node_modules/@base-ui/react/select/icon/SelectIcon.mjs
/**
* An icon that indicates that the trigger button opens a select popup.
* Renders a `<span>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectIcon = /*#__PURE__*/ import_react.forwardRef(function SelectIcon(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const state = { open: useSelectRootContext().useState("open") };
	return useRenderElement("span", componentProps, {
		state,
		ref: forwardedRef,
		props: [{
			"aria-hidden": true,
			children: "▼"
		}, elementProps],
		stateAttributesMapping: triggerOpenStateMapping
	});
});
SelectIcon.displayName = "SelectIcon";
// node_modules/@base-ui/react/select/portal/SelectPortal.mjs
/**
* A portal element that moves the popup to a different part of the DOM.
* By default, the portal element is appended to `<body>`.
* Renders a `<div>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectPortal = /*#__PURE__*/ import_react.forwardRef(function SelectPortal(portalProps, forwardedRef) {
	const store = useSelectRootContext();
	const mounted = store.useState("mounted");
	const forceMount = store.useState("forceMount");
	if (!(mounted || forceMount)) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingPortal, {
		ref: forwardedRef,
		...portalProps
	});
});
SelectPortal.displayName = "SelectPortal";
// node_modules/@base-ui/react/select/backdrop/SelectBackdrop.mjs
var stateAttributesMapping$1 = {
	...popupStateMapping,
	...transitionStatusMapping
};
/**
* An overlay displayed beneath the select popup.
* Renders a `<div>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectBackdrop = /*#__PURE__*/ import_react.forwardRef(function SelectBackdrop(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const store = useSelectRootContext();
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const state = {
		open,
		transitionStatus: store.useState("transitionStatus")
	};
	return useRenderElement("div", componentProps, {
		state,
		ref: forwardedRef,
		props: [{
			role: "presentation",
			hidden: !mounted,
			style: {
				userSelect: "none",
				WebkitUserSelect: "none"
			}
		}, elementProps],
		stateAttributesMapping: stateAttributesMapping$1
	});
});
SelectBackdrop.displayName = "SelectBackdrop";
// node_modules/@base-ui/react/select/positioner/SelectPositionerContext.mjs
var SelectPositionerContext = /*#__PURE__*/ import_react.createContext(void 0);
SelectPositionerContext.displayName = "SelectPositionerContext";
function useSelectPositionerContext() {
	const context = import_react.useContext(SelectPositionerContext);
	if (!context) throw new Error("Base UI: SelectPositionerContext is missing. SelectPositioner parts must be placed within <Select.Positioner>.");
	return context;
}
// node_modules/@base-ui/react/select/popup/utils.mjs
function clearStyles(element, originalStyles) {
	if (element) Object.assign(element.style, originalStyles);
}
var LIST_FUNCTIONAL_STYLES = {
	position: "relative",
	maxHeight: "100%",
	overflowX: "hidden",
	overflowY: "auto"
};
// node_modules/@base-ui/react/select/positioner/SelectPositioner.mjs
var FIXED = { position: "fixed" };
/**
* Positions the select popup.
* Renders a `<div>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectPositioner = /*#__PURE__*/ import_react.forwardRef(function SelectPositioner(componentProps, forwardedRef) {
	const { anchor, className, render, positionMethod, side, align, sideOffset, alignOffset, collisionBoundary = "clipping-ancestors", collisionPadding, arrowPadding, sticky, disableAnchorTracking, alignItemWithTrigger = true, collisionAvoidance = DROPDOWN_COLLISION_AVOIDANCE, style, ...elementProps } = componentProps;
	const store = useSelectRootContext();
	const floatingRootContext = useSelectFloatingContext();
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const modal = store.useState("modal");
	const value = store.useState("value");
	const openMethod = store.useState("openMethod");
	const positionerElement = store.useState("positionerElement");
	const triggerElement = store.useState("triggerElement");
	const isItemEqualToValue = store.useState("isItemEqualToValue");
	const transitionStatus = store.useState("transitionStatus");
	const scrollUpArrowRef = import_react.useRef(null);
	const scrollDownArrowRef = import_react.useRef(null);
	const [controlledAlignItemWithTrigger, setControlledAlignItemWithTrigger] = import_react.useState(alignItemWithTrigger);
	const alignItemWithTriggerActive = mounted && controlledAlignItemWithTrigger && openMethod !== "touch";
	if (!mounted && controlledAlignItemWithTrigger !== alignItemWithTrigger) setControlledAlignItemWithTrigger(alignItemWithTrigger);
	import_react.useImperativeHandle(store.context.alignItemWithTriggerActiveRef, () => alignItemWithTriggerActive);
	useAnchoredPopupScrollLock((alignItemWithTriggerActive || modal) && open, openMethod === "touch", positionerElement, triggerElement);
	const positioning = useAnchorPositioning({
		anchor,
		floatingRootContext,
		positionMethod,
		mounted,
		side,
		sideOffset,
		align,
		alignOffset,
		arrowPadding,
		collisionBoundary,
		collisionPadding,
		sticky,
		disableAnchorTracking: disableAnchorTracking ?? alignItemWithTriggerActive,
		collisionAvoidance,
		keepMounted: true
	});
	const renderedSide = alignItemWithTriggerActive ? "none" : positioning.side;
	const positionerStyles = alignItemWithTriggerActive ? FIXED : positioning.positionerStyles;
	const state = {
		open,
		side: renderedSide,
		align: positioning.align,
		anchorHidden: positioning.anchorHidden
	};
	useIsoLayoutEffect(() => {
		store.set("popupSide", positioning.side);
	}, [store, positioning.side]);
	const setPositionerElement = store.useStateSetter("positionerElement");
	const element = usePositioner(componentProps, state, {
		styles: positionerStyles,
		transitionStatus,
		props: elementProps,
		refs: [forwardedRef, setPositionerElement],
		hidden: !mounted,
		inert: !open
	});
	const prevMapSizeRef = import_react.useRef(0);
	const onMapChange = useStableCallback((map) => {
		if (store.context.valuesRef.current.length === 0) return;
		const prevSize = prevMapSizeRef.current;
		prevMapSizeRef.current = map.size;
		const eventDetails = createChangeEventDetails(none);
		if (prevSize !== 0 && !store.state.multiple && value !== null) {
			if (findItemIndex(store.context.valuesRef.current, value, isItemEqualToValue) === -1) {
				const initialSelectedValue = store.context.initialValueRef.current;
				const nextValue = initialSelectedValue != null && findItemIndex(store.context.valuesRef.current, initialSelectedValue, isItemEqualToValue) !== -1 ? initialSelectedValue : null;
				store.context.setValue(nextValue, eventDetails);
				if (nextValue === null) {
					store.set("selectedIndex", null);
					store.context.selectedItemTextRef.current = null;
				}
			}
		}
		if (prevSize !== 0 && store.state.multiple && Array.isArray(value)) {
			const nextValue = value.filter((selectedItemValue) => findItemIndex(store.context.valuesRef.current, selectedItemValue, isItemEqualToValue) !== -1);
			if (nextValue.length !== value.length) {
				store.context.setValue(nextValue, eventDetails);
				if (nextValue.length === 0) {
					store.set("selectedIndex", null);
					store.context.selectedItemTextRef.current = null;
				}
			}
		}
		if (open && alignItemWithTriggerActive) {
			store.update({
				scrollUpArrowVisible: false,
				scrollDownArrowVisible: false
			});
			const stylesToClear = { height: "" };
			clearStyles(positionerElement, stylesToClear);
			clearStyles(store.context.popupRef.current, stylesToClear);
		}
	});
	const contextValue = import_react.useMemo(() => ({
		...positioning,
		side: renderedSide,
		alignItemWithTriggerActive,
		setControlledAlignItemWithTrigger,
		scrollUpArrowRef,
		scrollDownArrowRef
	}), [
		positioning,
		renderedSide,
		alignItemWithTriggerActive,
		setControlledAlignItemWithTrigger
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeList, {
		elementsRef: store.context.listRef,
		labelsRef: store.context.labelsRef,
		onMapChange,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(SelectPositionerContext.Provider, {
			value: contextValue,
			children: [mounted && modal && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(InternalBackdrop, {
				inert: inertValue(!open),
				cutout: triggerElement
			}), element]
		})
	});
});
SelectPositioner.displayName = "SelectPositioner";
// node_modules/@base-ui/react/utils/styles.mjs
var DISABLE_SCROLLBAR_CLASS_NAME = "base-ui-disable-scrollbar";
var styleDisableScrollbar = {
	className: DISABLE_SCROLLBAR_CLASS_NAME,
	getElement(nonce) {
		return /*#__PURE__*/ (0, import_jsx_runtime.jsx)("style", {
			nonce,
			href: DISABLE_SCROLLBAR_CLASS_NAME,
			precedence: "base-ui:low",
			children: `.${DISABLE_SCROLLBAR_CLASS_NAME}{scrollbar-width:none}.${DISABLE_SCROLLBAR_CLASS_NAME}::-webkit-scrollbar{display:none}`
		});
	}
};
styleDisableScrollbar.getElement.displayName = "styleDisableScrollbar.getElement";
// node_modules/@base-ui/react/select/positioner/SelectPositionerCssVars.mjs
var SelectPositionerCssVars_exports = /* @__PURE__ */ __exportAll({
	anchorHeight: () => anchorHeight,
	anchorWidth: () => anchorWidth,
	availableHeight: () => availableHeight,
	availableWidth: () => availableWidth,
	transformOrigin: () => transformOrigin
});
/**
* The available width between the trigger and the edge of the viewport.
* @type {number}
*/
var availableWidth = "--available-width";
/**
* The available height between the trigger and the edge of the viewport.
* @type {number}
*/
var availableHeight = "--available-height";
/**
* The anchor's width.
* @type {number}
*/
var anchorWidth = "--anchor-width";
/**
* The anchor's height.
* @type {number}
*/
var anchorHeight = "--anchor-height";
/**
* The coordinates that this element is anchored to. Used for animations and transitions.
* @type {string}
*/
var transformOrigin = "--transform-origin";
// node_modules/@base-ui/react/select/popup/SelectPopup.mjs
var stateAttributesMapping = {
	...popupStateMapping,
	...transitionStatusMapping
};
/**
* A container for the select list.
* Renders a `<div>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectPopup = /*#__PURE__*/ import_react.forwardRef(function SelectPopup(componentProps, forwardedRef) {
	const { render, className, style, finalFocus, ...elementProps } = componentProps;
	const store = useSelectRootContext();
	const multiple = store.useState("multiple");
	const readOnly = store.useState("readOnly");
	const highlightItemOnHover = store.useState("highlightItemOnHover");
	const floatingRootContext = useSelectFloatingContext();
	const { side, align, alignItemWithTriggerActive, isPositioned, setControlledAlignItemWithTrigger } = useSelectPositionerContext();
	const insideToolbar = useToolbarRootContext(true) != null;
	const direction = useDirection();
	const { nonce, disableStyleElements } = useCSPContext();
	const id = store.useState("id");
	const open = store.useState("open");
	const openMethod = store.useState("openMethod");
	const mounted = store.useState("mounted");
	const popupProps = store.useState("popupProps");
	const transitionStatus = store.useState("transitionStatus");
	const triggerElement = store.useState("triggerElement");
	const positionerElement = store.useState("positionerElement");
	const listElement = store.useState("listElement");
	const reachedMaxHeightRef = import_react.useRef(false);
	const initialPlacedRef = import_react.useRef(false);
	const originalPositionerStylesRef = import_react.useRef({});
	const scrollArrowFrame = useAnimationFrame();
	const handleScroll = useStableCallback((scroller) => {
		if (!positionerElement || !store.context.popupRef.current || !initialPlacedRef.current) return;
		const isTopPositioned = positionerElement.style.top === "0px";
		const isBottomPositioned = positionerElement.style.bottom === "0px";
		if (reachedMaxHeightRef.current || !alignItemWithTriggerActive || !isTopPositioned && !isBottomPositioned) {
			store.context.handleScrollArrowVisibility(scroller);
			return;
		}
		const scale = getScale(positionerElement);
		const currentHeight = normalizeSize(positionerElement.getBoundingClientRect().height, "y", scale);
		const doc = ownerDocument(positionerElement);
		const win = getWindow(positionerElement);
		const positionerStyles = win.getComputedStyle(positionerElement);
		const marginTop = parseFloat(positionerStyles.marginTop);
		const marginBottom = parseFloat(positionerStyles.marginBottom);
		const maxPopupHeight = getMaxPopupHeight(win.getComputedStyle(store.context.popupRef.current));
		const maxAvailableHeight = Math.min(doc.documentElement.clientHeight - marginTop - marginBottom, maxPopupHeight);
		const scrollTop = scroller.scrollTop;
		const maxScrollTop = getMaxScrollTop(scroller);
		let nextScrollTop = null;
		const setHeight = (height) => {
			positionerElement.style.height = `${height}px`;
		};
		const diff = isTopPositioned ? maxScrollTop - scrollTop : scrollTop;
		const nextHeight = Math.min(currentHeight + diff, maxAvailableHeight);
		if (diff <= 1) {
			const heightDelta = clamp(diff, 0, maxAvailableHeight - currentHeight);
			if (heightDelta > 0) setHeight(currentHeight + heightDelta);
			scroller.scrollTop = isTopPositioned ? maxScrollTop : 0;
			if (maxAvailableHeight - (currentHeight + heightDelta) <= 1) reachedMaxHeightRef.current = true;
			store.context.handleScrollArrowVisibility(scroller);
			return;
		}
		if (maxAvailableHeight - nextHeight > 1) nextScrollTop = isTopPositioned ? Infinity : 0;
		else if (isBottomPositioned && scrollTop < maxScrollTop) nextScrollTop = scrollTop - (diff - (currentHeight + diff - maxAvailableHeight));
		const nextPositionerHeight = Math.ceil(nextHeight);
		if (nextPositionerHeight !== 0) setHeight(nextPositionerHeight);
		if (nextScrollTop != null) {
			const target = clamp(nextScrollTop, 0, getMaxScrollTop(scroller));
			if (Math.abs(scroller.scrollTop - target) > 1) scroller.scrollTop = target;
		}
		if (nextPositionerHeight >= maxAvailableHeight - 1) reachedMaxHeightRef.current = true;
		store.context.handleScrollArrowVisibility(scroller);
	});
	import_react.useImperativeHandle(store.context.scrollHandlerRef, () => handleScroll, [handleScroll]);
	useOpenChangeComplete({
		open,
		ref: store.context.popupRef,
		onComplete() {
			if (open) store.context.onOpenChangeComplete(true);
		}
	});
	const state = {
		open,
		transitionStatus,
		side,
		align
	};
	useIsoLayoutEffect(() => {
		if (!positionerElement || !store.context.popupRef.current || Object.keys(originalPositionerStylesRef.current).length) return;
		originalPositionerStylesRef.current = {
			top: positionerElement.style.top || "0",
			left: positionerElement.style.left || "0",
			right: positionerElement.style.right,
			height: positionerElement.style.height,
			bottom: positionerElement.style.bottom,
			minHeight: positionerElement.style.minHeight,
			maxHeight: positionerElement.style.maxHeight,
			marginTop: positionerElement.style.marginTop,
			marginBottom: positionerElement.style.marginBottom
		};
	}, [store, positionerElement]);
	useIsoLayoutEffect(() => {
		if (open || alignItemWithTriggerActive) return;
		initialPlacedRef.current = false;
		reachedMaxHeightRef.current = false;
		clearStyles(positionerElement, originalPositionerStylesRef.current);
	}, [
		open,
		alignItemWithTriggerActive,
		positionerElement
	]);
	useIsoLayoutEffect(() => {
		const popupElement = store.context.popupRef.current;
		if (!open || !triggerElement || !positionerElement || !popupElement || alignItemWithTriggerActive && !isPositioned || store.state.transitionStatus === "ending") return;
		initialPlacedRef.current = true;
		popupElement.style.removeProperty(transformOrigin);
		if (!alignItemWithTriggerActive) {
			scrollArrowFrame.request(() => store.context.handleScrollArrowVisibility(listElement || popupElement));
			return;
		}
		const restoreTransformStyles = unsetTransformStyles(popupElement);
		try {
			let textElement = store.context.selectedItemTextRef.current;
			if (!textElement?.isConnected) textElement = !store.select("hasSelectedValue") && store.context.firstItemTextRef.current?.isConnected ? store.context.firstItemTextRef.current : null;
			const valueElement = store.context.valueRef.current;
			const win = getWindow(positionerElement);
			const positionerStyles = win.getComputedStyle(positionerElement);
			const popupStyles = win.getComputedStyle(popupElement);
			const doc = ownerDocument(triggerElement);
			const scale = getScale(triggerElement);
			const triggerRect = normalizeRect(triggerElement.getBoundingClientRect(), scale);
			const positionerRect = normalizeRect(positionerElement.getBoundingClientRect(), scale);
			const triggerHeight = triggerRect.height;
			const scroller = listElement || popupElement;
			const scrollHeight = scroller.scrollHeight;
			const borderBottom = parseFloat(popupStyles.borderBottomWidth);
			const marginTop = parseFloat(positionerStyles.marginTop) || 10;
			const marginBottom = parseFloat(positionerStyles.marginBottom) || 10;
			const minHeight = parseFloat(positionerStyles.minHeight) || 100;
			const maxPopupHeight = getMaxPopupHeight(popupStyles);
			const paddingLeft = 5;
			const paddingRight = 5;
			const triggerCollisionThreshold = 20;
			const viewportHeight = doc.documentElement.clientHeight - marginTop - marginBottom;
			const viewportWidth = doc.documentElement.clientWidth;
			const availableSpaceBeneathTrigger = viewportHeight - triggerRect.bottom + triggerHeight;
			let textRect;
			let alignedLeft = direction === "rtl" ? triggerRect.right - positionerRect.width : triggerRect.left;
			let offsetY = 0;
			if (textElement && valueElement) {
				const valueRect = normalizeRect(valueElement.getBoundingClientRect(), scale);
				textRect = normalizeRect(textElement.getBoundingClientRect(), scale);
				alignedLeft = positionerRect.left + (direction === "rtl" ? valueRect.right - textRect.right : valueRect.left - textRect.left);
				const valueCenterFromTriggerTop = valueRect.top - triggerRect.top + valueRect.height / 2;
				offsetY = textRect.top - positionerRect.top + textRect.height / 2 - valueCenterFromTriggerTop;
			}
			const idealHeight = availableSpaceBeneathTrigger + offsetY + marginBottom + borderBottom;
			let height = Math.min(viewportHeight, idealHeight);
			const maxHeight = viewportHeight - marginTop - marginBottom;
			const scrollTop = idealHeight - height;
			const maxRight = viewportWidth - paddingRight;
			positionerElement.style.left = `${clamp(alignedLeft, paddingLeft, maxRight - positionerRect.width)}px`;
			positionerElement.style.height = `${height}px`;
			positionerElement.style.maxHeight = "none";
			positionerElement.style.marginTop = `${marginTop}px`;
			positionerElement.style.marginBottom = `${marginBottom}px`;
			popupElement.style.height = "100%";
			const maxScrollTop = getMaxScrollTop(scroller);
			const isTopPositioned = scrollTop >= maxScrollTop - 1;
			if (isTopPositioned) height = Math.min(viewportHeight, positionerRect.height) - (scrollTop - maxScrollTop);
			const fallbackToAlignPopupToTrigger = triggerRect.top < triggerCollisionThreshold || triggerRect.bottom > viewportHeight - triggerCollisionThreshold || Math.ceil(height) + 1 < Math.min(scrollHeight, minHeight);
			const isPinchZoomed = (win.visualViewport?.scale ?? 1) !== 1 && webkit;
			if (fallbackToAlignPopupToTrigger || isPinchZoomed) {
				clearStyles(positionerElement, originalPositionerStylesRef.current);
				setControlledAlignItemWithTrigger(false);
				return;
			}
			const initialHeight = Math.max(minHeight, height);
			if (isTopPositioned) {
				const topOffset = Math.max(0, viewportHeight - idealHeight);
				positionerElement.style.top = positionerRect.height >= maxHeight ? "0" : `${topOffset}px`;
				positionerElement.style.height = `${height}px`;
				scroller.scrollTop = getMaxScrollTop(scroller);
			} else {
				positionerElement.style.bottom = "0";
				scroller.scrollTop = scrollTop;
			}
			if (textRect) {
				const popupTop = positionerRect.top;
				const popupHeight = positionerRect.height;
				const textCenterY = textRect.top + textRect.height / 2;
				const clampedY = clamp(popupHeight > 0 ? (textCenterY - popupTop) / popupHeight * 100 : 50, 0, 100);
				popupElement.style.setProperty(transformOrigin, `50% ${clampedY}%`);
			}
			if (initialHeight === viewportHeight || height >= maxPopupHeight) reachedMaxHeightRef.current = true;
			store.context.handleScrollArrowVisibility(scroller);
			if (highlightItemOnHover && store.state.selectedIndex === null && store.state.activeIndex === null && store.context.listRef.current[0] != null) store.set("activeIndex", 0);
		} finally {
			restoreTransformStyles();
		}
	}, [
		store,
		open,
		positionerElement,
		triggerElement,
		alignItemWithTriggerActive,
		setControlledAlignItemWithTrigger,
		scrollArrowFrame,
		listElement,
		highlightItemOnHover,
		direction,
		isPositioned
	]);
	import_react.useEffect(() => {
		if (!alignItemWithTriggerActive || !positionerElement || !open) return;
		const win = getWindow(positionerElement);
		function handleResize(event) {
			store.context.setOpen(false, createChangeEventDetails(windowResize, event));
		}
		return addEventListener(win, "resize", handleResize);
	}, [
		store,
		alignItemWithTriggerActive,
		positionerElement,
		open
	]);
	const defaultProps = {
		...listElement ? { role: "presentation" } : {
			role: "listbox",
			"aria-multiselectable": multiple || void 0,
			"aria-readonly": readOnly || void 0,
			id: `${id}-list`
		},
		onKeyDown(event) {
			if (insideToolbar && COMPOSITE_KEYS.has(event.key)) event.stopPropagation();
		},
		onScroll(event) {
			if (listElement) return;
			handleScroll(event.currentTarget);
		},
		...alignItemWithTriggerActive && { style: listElement ? { height: "100%" } : LIST_FUNCTIONAL_STYLES },
		className: !listElement && alignItemWithTriggerActive ? styleDisableScrollbar.className : void 0
	};
	const element = useRenderElement("div", componentProps, {
		ref: [forwardedRef, store.context.popupRef],
		state,
		stateAttributesMapping,
		props: [
			popupProps,
			defaultProps,
			getDisabledMountTransitionStyles(transitionStatus),
			elementProps
		]
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [!disableStyleElements && styleDisableScrollbar.getElement(nonce), /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingFocusManager, {
		context: floatingRootContext,
		modal: false,
		disabled: !mounted,
		openInteractionType: openMethod,
		returnFocus: finalFocus,
		restoreFocus: true,
		children: element
	})] });
});
SelectPopup.displayName = "SelectPopup";
function getMaxPopupHeight(popupStyles) {
	const maxHeightStyle = popupStyles.maxHeight;
	return maxHeightStyle.endsWith("px") ? parseFloat(maxHeightStyle) || Infinity : Infinity;
}
function getMaxScrollTop(scroller) {
	return getMaxScrollOffset(scroller.scrollHeight, scroller.clientHeight);
}
function getScale(element) {
	return platform.getScale(element);
}
function normalizeSize(size, axis, scale) {
	return size / scale[axis];
}
function normalizeRect(rect, scale) {
	return rectToClientRect({
		x: normalizeSize(rect.x, "x", scale),
		y: normalizeSize(rect.y, "y", scale),
		width: normalizeSize(rect.width, "x", scale),
		height: normalizeSize(rect.height, "y", scale)
	});
}
var TRANSFORM_STYLE_RESETS = [
	["transform", "none"],
	["scale", "1"],
	["translate", "0 0"]
];
function unsetTransformStyles(popupElement) {
	const { style } = popupElement;
	const originalStyles = {};
	for (const [property, value] of TRANSFORM_STYLE_RESETS) {
		originalStyles[property] = style.getPropertyValue(property);
		style.setProperty(property, value, "important");
	}
	return () => {
		for (const [property] of TRANSFORM_STYLE_RESETS) {
			const originalValue = originalStyles[property];
			if (originalValue) style.setProperty(property, originalValue);
			else style.removeProperty(property);
		}
	};
}
// node_modules/@base-ui/react/select/list/SelectList.mjs
/**
* A container for the select items.
* Renders a `<div>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectList = /*#__PURE__*/ import_react.forwardRef(function SelectList(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const store = useSelectRootContext();
	const multiple = store.useState("multiple");
	const readOnly = store.useState("readOnly");
	const { alignItemWithTriggerActive } = useSelectPositionerContext();
	const hasScrollArrows = store.useState("hasScrollArrows");
	const openMethod = store.useState("openMethod");
	const defaultProps = {
		id: `${store.useState("id")}-list`,
		role: "listbox",
		"aria-multiselectable": multiple || void 0,
		"aria-readonly": readOnly || void 0,
		onScroll(event) {
			store.context.scrollHandlerRef.current?.(event.currentTarget);
		},
		...alignItemWithTriggerActive && { style: LIST_FUNCTIONAL_STYLES },
		className: hasScrollArrows && openMethod !== "touch" ? styleDisableScrollbar.className : void 0
	};
	const setListElement = store.useStateSetter("listElement");
	return useRenderElement("div", componentProps, {
		ref: [forwardedRef, setListElement],
		props: [defaultProps, elementProps]
	});
});
SelectList.displayName = "SelectList";
// node_modules/@base-ui/react/select/item/SelectItemContext.mjs
var SelectItemContext = /*#__PURE__*/ import_react.createContext(void 0);
SelectItemContext.displayName = "SelectItemContext";
function useSelectItemContext() {
	const context = import_react.useContext(SelectItemContext);
	if (!context) throw new Error("Base UI: SelectItemContext is missing. SelectItem parts must be placed within <Select.Item>.");
	return context;
}
// node_modules/@base-ui/react/select/item/SelectItem.mjs
/**
* An individual option in the select popup.
* Renders a `<div>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectItem = /*#__PURE__*/ import_react.memo(/*#__PURE__*/ import_react.forwardRef(function SelectItem(componentProps, forwardedRef) {
	const { render, className, style, value: itemValue = null, label, disabled: disabledProp = false, nativeButton = false, ...elementProps } = componentProps;
	const textRef = import_react.useRef(null);
	const listItem = useCompositeListItem({
		guess: true,
		label,
		textRef
	});
	const store = useSelectRootContext();
	const { props: itemProps, multiple, disabled: selectDisabled, readOnly, isItemEqualToValue } = store.useState("itemRoot");
	const disabled = selectDisabled || disabledProp;
	const highlighted = store.useState("isActive", listItem.index);
	const open = store.useState("open");
	const selected = store.useState("isSelected", itemValue);
	const selectedByFocus = store.useState("isSelectedByFocus", listItem.index);
	const index = listItem.index;
	const itemRef = import_react.useRef(null);
	useIsoLayoutEffect(() => {
		const values = store.context.valuesRef.current;
		values[index] = itemValue;
		return () => {
			delete values[index];
		};
	}, [
		index,
		itemValue,
		store
	]);
	useIsoLayoutEffect(() => {
		const selectedValue = store.state.value;
		const currentIndex = store.state.selectedIndex;
		let nextIndex = currentIndex;
		let claims;
		if (multiple && Array.isArray(selectedValue)) {
			nextIndex = resolveSelectedIndex(index, itemValue, store.context.valuesRef.current, selectedValue, isItemEqualToValue, currentIndex);
			claims = nextIndex === index;
			if (index === currentIndex && !claims) store.context.selectedItemTextRef.current = null;
		} else {
			claims = selectedValue !== void 0 && compareItemEquality(itemValue, selectedValue, isItemEqualToValue);
			if (claims) nextIndex = index;
		}
		store.set("selectedIndex", nextIndex);
		if (claims && textRef.current) store.context.selectedItemTextRef.current = textRef.current;
	}, [
		index,
		multiple,
		isItemEqualToValue,
		store,
		itemValue
	]);
	const pointerTypeRef = import_react.useRef("mouse");
	const allowMouseSelectionRef = import_react.useRef(false);
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		focusableWhenDisabled: true,
		native: nativeButton,
		composite: true
	});
	const state = {
		disabled,
		selected,
		highlighted
	};
	function commitSelection(event) {
		if (selectDisabled || readOnly) return;
		const selectedValue = store.state.value;
		if (multiple) {
			const currentValue = Array.isArray(selectedValue) ? selectedValue : [];
			const nextValue = selected ? removeItem(currentValue, itemValue, isItemEqualToValue) : [...currentValue, itemValue];
			store.context.setValue(nextValue, createChangeEventDetails(itemPress, event));
		} else {
			store.context.setValue(itemValue, createChangeEventDetails(itemPress, event));
			store.context.setOpen(false, createChangeEventDetails(itemPress, event));
		}
	}
	function resetDragMovement() {
		store.context.selectionRef.current.dragY = 0;
	}
	const defaultProps = {
		role: "option",
		"aria-selected": selected,
		tabIndex: open && highlighted ? 0 : -1,
		onKeyDown(event) {
			store.set("activeIndex", index);
			if (event.key === " " && store.context.typingRef.current) event.preventDefault();
		},
		onClick(event) {
			const isMouseClick = pointerTypeRef.current !== "touch";
			const clickPointerType = event.nativeEvent.pointerType;
			const isVirtualMouseClick = isMouseClick && isVirtualClick(event.nativeEvent) && (clickPointerType !== void 0 || highlighted);
			const isInvalidMouseClick = isMouseClick && !isVirtualMouseClick && !allowMouseSelectionRef.current;
			allowMouseSelectionRef.current = false;
			if (disabled || isInvalidMouseClick) return;
			commitSelection(event.nativeEvent);
		},
		onPointerEnter(event) {
			pointerTypeRef.current = event.pointerType;
		},
		onPointerMove(event) {
			if (event.pointerType === "mouse" && event.buttons === 1) {
				const selection = store.context.selectionRef.current;
				selection.dragY += event.movementY;
				if (selection.dragY ** 2 >= 64) selection.allowUnselectedMouseUp = true;
			}
		},
		onPointerDown(event) {
			pointerTypeRef.current = event.pointerType;
			allowMouseSelectionRef.current = true;
			resetDragMovement();
		},
		onMouseUp() {
			resetDragMovement();
			if (disabled || pointerTypeRef.current === "touch") return;
			if (allowMouseSelectionRef.current) return;
			const disallowSelectedMouseUp = !store.context.selectionRef.current.allowSelectedMouseUp && selected;
			const disallowUnselectedMouseUp = !store.context.selectionRef.current.allowUnselectedMouseUp && !selected;
			if (disallowSelectedMouseUp || disallowUnselectedMouseUp) return;
			allowMouseSelectionRef.current = true;
			itemRef.current?.click();
			allowMouseSelectionRef.current = false;
		}
	};
	const element = useRenderElement("div", componentProps, {
		ref: [
			buttonRef,
			forwardedRef,
			listItem.ref,
			itemRef
		],
		state,
		props: [
			itemProps,
			defaultProps,
			elementProps,
			getButtonProps
		]
	});
	const contextValue = import_react.useMemo(() => ({
		selected,
		index,
		textRef,
		selectedByFocus
	}), [
		selected,
		index,
		textRef,
		selectedByFocus
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(SelectItemContext.Provider, {
		value: contextValue,
		children: element
	});
}));
SelectItem.displayName = "SelectItem";
// node_modules/@base-ui/react/utils/ItemIndicator.mjs
var ItemIndicator = /*#__PURE__*/ import_react.memo(/*#__PURE__*/ import_react.forwardRef(function ItemIndicator(componentProps, forwardedRef) {
	const { render, className, style, keepMounted, selected, ...elementProps } = componentProps;
	const indicatorRef = import_react.useRef(null);
	const { transitionStatus, setMounted } = useTransitionStatus(selected);
	const element = useRenderElement("span", componentProps, {
		ref: [forwardedRef, indicatorRef],
		state: {
			selected,
			transitionStatus
		},
		props: [{
			"aria-hidden": true,
			children: "✔️"
		}, elementProps],
		stateAttributesMapping: transitionStatusMapping
	});
	useOpenChangeComplete({
		batch: true,
		enabled: !selected,
		open: selected,
		ref: indicatorRef,
		onComplete() {
			if (!selected) setMounted(false);
		}
	});
	return element;
}));
ItemIndicator.displayName = "ItemIndicator";
// node_modules/@base-ui/react/select/item-indicator/SelectItemIndicator.mjs
/**
* Indicates whether the select item is selected.
* Renders a `<span>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectItemIndicator = /*#__PURE__*/ import_react.forwardRef(function SelectItemIndicator(componentProps, forwardedRef) {
	const { selected } = useSelectItemContext();
	if (!(componentProps.keepMounted || selected)) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(ItemIndicator, {
		...componentProps,
		selected,
		ref: forwardedRef
	});
});
SelectItemIndicator.displayName = "SelectItemIndicator";
// node_modules/@base-ui/react/select/item-text/SelectItemText.mjs
/**
* A text label of the select item.
* Renders a `<div>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectItemText = /*#__PURE__*/ import_react.memo(/*#__PURE__*/ import_react.forwardRef(function SelectItemText(componentProps, forwardedRef) {
	const { index, textRef, selectedByFocus } = useSelectItemContext();
	const store = useSelectRootContext();
	const { render, className, style, ...elementProps } = componentProps;
	const localRef = import_react.useCallback((node) => {
		if (!node) return;
		if (index === 0) store.context.firstItemTextRef.current = node;
		if (selectedByFocus) store.context.selectedItemTextRef.current = node;
	}, [
		store,
		index,
		selectedByFocus
	]);
	return useRenderElement("div", componentProps, {
		ref: [
			localRef,
			forwardedRef,
			textRef
		],
		props: elementProps
	});
}));
SelectItemText.displayName = "SelectItemText";
// node_modules/@base-ui/react/select/arrow/SelectArrow.mjs
/**
* Displays an element positioned against the select popup anchor.
* Renders a `<div>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectArrow = /*#__PURE__*/ import_react.forwardRef(function SelectArrow(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const store = useSelectRootContext();
	const { side, align, arrowRef, arrowStyles, arrowUncentered, alignItemWithTriggerActive } = useSelectPositionerContext();
	const state = {
		open: store.useState("open"),
		side,
		align,
		uncentered: arrowUncentered
	};
	const element = useRenderElement("div", componentProps, {
		state,
		ref: [arrowRef, forwardedRef],
		props: [{
			style: arrowStyles,
			"aria-hidden": true
		}, elementProps],
		stateAttributesMapping: popupTransitionStateMapping
	});
	if (alignItemWithTriggerActive) return null;
	return element;
});
SelectArrow.displayName = "SelectArrow";
// node_modules/@base-ui/react/select/scroll-arrow/SelectScrollArrow.mjs
/**
* @internal
*/
var SelectScrollArrow = /*#__PURE__*/ import_react.forwardRef(function SelectScrollArrow(componentProps, forwardedRef) {
	const { render, className, style, direction, keepMounted, ...elementProps } = componentProps;
	const isUp = direction === "up";
	const store = useSelectRootContext();
	const { side, scrollDownArrowRef, scrollUpArrowRef } = useSelectPositionerContext();
	const visibleSelector = isUp ? "scrollUpArrowVisible" : "scrollDownArrowVisible";
	const stateVisible = store.useState(visibleSelector);
	const openMethod = store.useState("openMethod");
	const visible = stateVisible && openMethod !== "touch";
	const timeout = useTimeout();
	const scrollArrowRef = isUp ? scrollUpArrowRef : scrollDownArrowRef;
	const { mounted, transitionStatus, setMounted } = useTransitionStatus(visible);
	useIsoLayoutEffect(() => {
		store.context.scrollArrowsMountedCountRef.current += 1;
		store.set("hasScrollArrows", true);
		return () => {
			store.context.scrollArrowsMountedCountRef.current = Math.max(0, store.context.scrollArrowsMountedCountRef.current - 1);
			if (store.context.scrollArrowsMountedCountRef.current === 0) store.set("hasScrollArrows", false);
		};
	}, [store]);
	useOpenChangeComplete({
		open: visible,
		ref: scrollArrowRef,
		onComplete() {
			if (!visible) setMounted(false);
		}
	});
	const element = useRenderElement("div", componentProps, {
		ref: [forwardedRef, scrollArrowRef],
		state: {
			direction,
			visible,
			side,
			transitionStatus
		},
		props: [{
			"aria-hidden": true,
			children: isUp ? "▲" : "▼",
			style: { position: "absolute" },
			onMouseMove(event) {
				if (event.movementX === 0 && event.movementY === 0 || timeout.isStarted()) return;
				store.set("activeIndex", null);
				function scrollNextItem() {
					const scroller = store.state.listElement ?? store.context.popupRef.current;
					if (!scroller) return;
					store.set("activeIndex", null);
					store.context.handleScrollArrowVisibility(scroller);
					const maxScrollTop = getMaxScrollOffset(scroller.scrollHeight, scroller.clientHeight);
					const scrollTop = normalizeScrollOffset(scroller.scrollTop, maxScrollTop);
					const isScrolledToEdge = scrollTop === (isUp ? 0 : maxScrollTop);
					const items = store.context.listRef.current;
					if (scrollTop !== scroller.scrollTop) scroller.scrollTop = scrollTop;
					if (isScrolledToEdge) {
						timeout.clear();
						return;
					}
					if (items.length > 0) {
						const scrollArrowHeight = scrollArrowRef.current?.offsetHeight || 0;
						scroller.scrollTop = getTargetScrollTop(items, isUp, scrollTop, scroller.clientHeight, scrollArrowHeight, maxScrollTop);
					}
					timeout.start(40, scrollNextItem);
				}
				timeout.start(40, scrollNextItem);
			},
			onMouseLeave() {
				timeout.clear();
			}
		}, elementProps],
		stateAttributesMapping: transitionStatusMapping
	});
	if (!(mounted || keepMounted)) return null;
	return element;
});
SelectScrollArrow.displayName = "SelectScrollArrow";
function getTargetScrollTop(items, isUp, scrollTop, clientHeight, scrollArrowHeight, maxScrollTop) {
	if (isUp) {
		let firstVisibleIndex = 0;
		const visibleTop = scrollTop + scrollArrowHeight - 1;
		for (let i = 0; i < items.length; i += 1) {
			const item = items[i];
			if (item && item.offsetTop >= visibleTop) {
				firstVisibleIndex = i;
				break;
			}
		}
		const targetIndex = Math.max(0, firstVisibleIndex - 1);
		const targetItem = items[targetIndex];
		return targetIndex < firstVisibleIndex && targetItem ? normalizeScrollOffset(targetItem.offsetTop - scrollArrowHeight, maxScrollTop) : 0;
	}
	let lastVisibleIndex = items.length - 1;
	const visibleBottom = scrollTop + clientHeight - scrollArrowHeight + 1;
	for (let i = 0; i < items.length; i += 1) {
		const item = items[i];
		if (item && item.offsetTop + item.offsetHeight > visibleBottom) {
			lastVisibleIndex = Math.max(0, i - 1);
			break;
		}
	}
	const targetIndex = Math.min(items.length - 1, lastVisibleIndex + 1);
	const targetItem = items[targetIndex];
	return targetIndex > lastVisibleIndex && targetItem ? normalizeScrollOffset(targetItem.offsetTop + targetItem.offsetHeight - clientHeight + scrollArrowHeight, maxScrollTop) : maxScrollTop;
}
// node_modules/@base-ui/react/select/scroll-down-arrow/SelectScrollDownArrow.mjs
/**
* An element that scrolls the select popup down when hovered. Does not render when using touch input.
* Renders a `<div>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectScrollDownArrow = /*#__PURE__*/ import_react.forwardRef(function SelectScrollDownArrow(props, forwardedRef) {
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(SelectScrollArrow, {
		...props,
		ref: forwardedRef,
		direction: "down"
	});
});
SelectScrollDownArrow.displayName = "SelectScrollDownArrow";
// node_modules/@base-ui/react/select/scroll-up-arrow/SelectScrollUpArrow.mjs
/**
* An element that scrolls the select popup up when hovered. Does not render when using touch input.
* Renders a `<div>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectScrollUpArrow = /*#__PURE__*/ import_react.forwardRef(function SelectScrollUpArrow(props, forwardedRef) {
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(SelectScrollArrow, {
		...props,
		ref: forwardedRef,
		direction: "up"
	});
});
SelectScrollUpArrow.displayName = "SelectScrollUpArrow";
// node_modules/@base-ui/react/select/group/SelectGroupContext.mjs
var SelectGroupContext = /*#__PURE__*/ import_react.createContext(void 0);
SelectGroupContext.displayName = "SelectGroupContext";
function useSelectGroupContext() {
	const context = import_react.useContext(SelectGroupContext);
	if (context === void 0) throw new Error("Base UI: SelectGroupContext is missing. SelectGroup parts must be placed within <Select.Group>.");
	return context;
}
// node_modules/@base-ui/react/select/group/SelectGroup.mjs
/**
* Groups related select items with the corresponding label.
* Renders a `<div>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectGroup = /*#__PURE__*/ import_react.forwardRef(function SelectGroup(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const [labelId, setLabelId] = import_react.useState();
	const contextValue = import_react.useMemo(() => ({
		labelId,
		setLabelId
	}), [labelId, setLabelId]);
	const element = useRenderElement("div", componentProps, {
		ref: forwardedRef,
		props: [{
			role: "group",
			"aria-labelledby": labelId
		}, elementProps]
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(SelectGroupContext.Provider, {
		value: contextValue,
		children: element
	});
});
SelectGroup.displayName = "SelectGroup";
// node_modules/@base-ui/react/select/group-label/SelectGroupLabel.mjs
/**
* An accessible label that is automatically associated with its parent group.
* Renders a `<div>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectGroupLabel = /*#__PURE__*/ import_react.forwardRef(function SelectGroupLabel(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, ...elementProps } = componentProps;
	const { setLabelId } = useSelectGroupContext();
	const id = useBaseUiId(idProp);
	useIsoLayoutEffect(() => {
		setLabelId(id);
		return () => {
			setLabelId((currentId) => currentId === id ? void 0 : currentId);
		};
	}, [id, setLabelId]);
	return useRenderElement("div", componentProps, {
		ref: forwardedRef,
		props: [{
			id,
			"aria-hidden": true
		}, elementProps]
	});
});
SelectGroupLabel.displayName = "SelectGroupLabel";
// node_modules/@base-ui/react/utils/listbox-separator/ListboxSeparator.mjs
/**
* A visual separator between items.
* Renders a `<div>` element.
*
* @internal
*/
var ListboxSeparator = /*#__PURE__*/ import_react.forwardRef(function ListboxSeparator(componentProps, forwardedRef) {
	const { className, render, orientation = "horizontal", style, ...elementProps } = componentProps;
	return useRenderElement("div", componentProps, {
		state: { orientation },
		ref: forwardedRef,
		props: [{ role: "presentation" }, elementProps]
	});
});
ListboxSeparator.displayName = "ListboxSeparator";
// node_modules/@base-ui/react/select/separator/SelectSeparator.mjs
/**
* A visual separator between items or groups.
* Renders a `<div>` element.
*
* Documentation: [Base UI Select](https://base-ui.com/react/components/select)
*/
var SelectSeparator = ListboxSeparator;
// node_modules/@base-ui/react/select/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Arrow: () => SelectArrow,
	Backdrop: () => SelectBackdrop,
	Group: () => SelectGroup,
	GroupLabel: () => SelectGroupLabel,
	Icon: () => SelectIcon,
	Item: () => SelectItem,
	ItemIndicator: () => SelectItemIndicator,
	ItemText: () => SelectItemText,
	Label: () => SelectLabel,
	List: () => SelectList,
	Popup: () => SelectPopup,
	Portal: () => SelectPortal,
	Positioner: () => SelectPositioner,
	Root: () => SelectRoot,
	ScrollDownArrow: () => SelectScrollDownArrow,
	ScrollUpArrow: () => SelectScrollUpArrow,
	Separator: () => SelectSeparator,
	Trigger: () => SelectTrigger,
	Value: () => SelectValue
});
// node_modules/@base-ui/react/select/value/SelectValueDataAttributes.mjs
var SelectValueDataAttributes_exports = /* @__PURE__ */ __exportAll({ placeholder: () => placeholder });
/**
* Present when the select doesn't have a value.
*/
var placeholder = "data-placeholder";
// node_modules/@base-ui/react/select/icon/SelectIconDataAttributes.mjs
var SelectIconDataAttributes_exports = /* @__PURE__ */ __exportAll({ popupOpen: () => popupOpen });
/**
* Present when the corresponding popup is open.
*/
var popupOpen = popupOpen$2;
// node_modules/@base-ui/react/select/backdrop/SelectBackdropDataAttributes.mjs
var SelectBackdropDataAttributes_exports = /* @__PURE__ */ __exportAll({
	closed: () => closed$3,
	endingStyle: () => endingStyle$4,
	open: () => open$3,
	startingStyle: () => startingStyle$4
});
/**
* Present when the select is open.
*/
var open$3 = open$4;
/**
* Present when the select is closed.
*/
var closed$3 = closed$4;
/**
* Present when the select begins animating in.
*/
var startingStyle$4 = startingStyle$5;
/**
* Present when the select is animating out.
*/
var endingStyle$4 = endingStyle$5;
// node_modules/@base-ui/react/select/positioner/SelectPositionerDataAttributes.mjs
var SelectPositionerDataAttributes_exports = /* @__PURE__ */ __exportAll({
	align: () => align$2,
	anchorHidden: () => anchorHidden,
	closed: () => closed$2,
	open: () => open$2,
	side: () => side$4
});
/**
* Present when the select popup is open.
*/
var open$2 = open$4;
/**
* Present when the select popup is closed.
*/
var closed$2 = closed$4;
/**
* Present when the anchor is hidden.
*/
var anchorHidden = anchorHidden$1;
/**
* Indicates which side the popup is positioned relative to the trigger.
* @type {'none' | 'top' | 'bottom' | 'left' | 'right' | 'inline-end' | 'inline-start'}
*/
var side$4 = side$5;
/**
* Indicates how the popup is aligned relative to specified side.
* @type {'start' | 'center' | 'end'}
*/
var align$2 = align$3;
// node_modules/@base-ui/react/select/popup/SelectPopupDataAttributes.mjs
var SelectPopupDataAttributes_exports = /* @__PURE__ */ __exportAll({
	align: () => align$1,
	closed: () => closed$1,
	endingStyle: () => endingStyle$3,
	open: () => open$1,
	side: () => side$3,
	startingStyle: () => startingStyle$3
});
/**
* Present when the select is open.
*/
var open$1 = open$4;
/**
* Present when the select is closed.
*/
var closed$1 = closed$4;
/**
* Present when the select begins animating in.
*/
var startingStyle$3 = startingStyle$5;
/**
* Present when the select is animating out.
*/
var endingStyle$3 = endingStyle$5;
/**
* Indicates which side the popup is positioned relative to the trigger.
* @type {'none' | 'top' | 'bottom' | 'left' | 'right' | 'inline-end' | 'inline-start'}
*/
var side$3 = side$5;
/**
* Indicates how the popup is aligned relative to specified side.
* @type {'start' | 'center' | 'end'}
*/
var align$1 = align$3;
// node_modules/@base-ui/react/select/item/SelectItemDataAttributes.mjs
var SelectItemDataAttributes_exports = /* @__PURE__ */ __exportAll({
	disabled: () => disabled,
	highlighted: () => highlighted,
	selected: () => selected
});
/**
* Present when the select item is selected.
*/
var selected = "data-selected";
/**
* Present when the select item is highlighted.
*/
var highlighted = "data-highlighted";
/**
* Present when the select item is disabled.
*/
var disabled = "data-disabled";
// node_modules/@base-ui/react/select/item-indicator/SelectItemIndicatorDataAttributes.mjs
var SelectItemIndicatorDataAttributes_exports = /* @__PURE__ */ __exportAll({
	endingStyle: () => endingStyle$2,
	startingStyle: () => startingStyle$2
});
/**
* Present when the indicator begins animating in.
*/
var startingStyle$2 = startingStyle$6;
/**
* Present when the indicator is animating out.
*/
var endingStyle$2 = endingStyle$6;
// node_modules/@base-ui/react/select/arrow/SelectArrowDataAttributes.mjs
var SelectArrowDataAttributes_exports = /* @__PURE__ */ __exportAll({
	align: () => align,
	closed: () => closed,
	open: () => open,
	side: () => side$2,
	uncentered: () => uncentered
});
/**
* Present when the select popup is open.
*/
var open = open$4;
/**
* Present when the select popup is closed.
*/
var closed = closed$4;
/**
* Indicates which side the popup is positioned relative to the trigger.
* @type {'none' | 'top' | 'bottom' | 'left' | 'right' | 'inline-end' | 'inline-start'}
*/
var side$2 = side$5;
/**
* Indicates how the popup is aligned relative to specified side.
* @type {'start' | 'center' | 'end'}
*/
var align = align$3;
/**
* Present when the select arrow is uncentered.
*/
var uncentered = "data-uncentered";
// node_modules/@base-ui/react/select/scroll-down-arrow/SelectScrollDownArrowDataAttributes.mjs
var SelectScrollDownArrowDataAttributes_exports = /* @__PURE__ */ __exportAll({
	direction: () => direction$1,
	endingStyle: () => endingStyle$1,
	side: () => side$1,
	startingStyle: () => startingStyle$1,
	visible: () => visible$1
});
/**
* Present when the scroll arrow begins animating in.
*/
var startingStyle$1 = startingStyle$5;
/**
* Present when the scroll arrow is animating out.
*/
var endingStyle$1 = endingStyle$5;
/**
* Indicates the direction of the scroll arrow.
* @type {'down'}
*/
var direction$1 = "data-direction";
/**
* Present when the scroll arrow is visible.
*/
var visible$1 = "data-visible";
/**
* Indicates which side the popup is positioned relative to the trigger.
* @type {'none' | 'top' | 'bottom' | 'left' | 'right' | 'inline-end' | 'inline-start'}
*/
var side$1 = side$5;
// node_modules/@base-ui/react/select/scroll-up-arrow/SelectScrollUpArrowDataAttributes.mjs
var SelectScrollUpArrowDataAttributes_exports = /* @__PURE__ */ __exportAll({
	direction: () => direction,
	endingStyle: () => endingStyle,
	side: () => side,
	startingStyle: () => startingStyle,
	visible: () => visible
});
/**
* Present when the scroll arrow begins animating in.
*/
var startingStyle = startingStyle$5;
/**
* Present when the scroll arrow is animating out.
*/
var endingStyle = endingStyle$5;
/**
* Indicates the direction of the scroll arrow.
* @type {'up'}
*/
var direction = "data-direction";
/**
* Present when the scroll arrow is visible.
*/
var visible = "data-visible";
/**
* Indicates which side the popup is positioned relative to the trigger.
* @type {'none' | 'top' | 'bottom' | 'left' | 'right' | 'inline-end' | 'inline-start'}
*/
var side = side$5;
export { index_parts_exports as Select, SelectArrowDataAttributes_exports as SelectArrowDataAttributes, SelectBackdropDataAttributes_exports as SelectBackdropDataAttributes, SelectIconDataAttributes_exports as SelectIconDataAttributes, SelectItemDataAttributes_exports as SelectItemDataAttributes, SelectItemIndicatorDataAttributes_exports as SelectItemIndicatorDataAttributes, SelectPopupDataAttributes_exports as SelectPopupDataAttributes, SelectPositionerCssVars_exports as SelectPositionerCssVariables, SelectPositionerDataAttributes_exports as SelectPositionerDataAttributes, SelectScrollDownArrowDataAttributes_exports as SelectScrollDownArrowDataAttributes, SelectScrollUpArrowDataAttributes_exports as SelectScrollUpArrowDataAttributes, SeparatorDataAttributes_exports as SelectSeparatorDataAttributes, SelectTriggerDataAttributes_exports as SelectTriggerDataAttributes, SelectValueDataAttributes_exports as SelectValueDataAttributes };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQGJhc2UtdWlfcmVhY3Rfc2VsZWN0LmpzIiwibmFtZXMiOlsiUkVBU09OUy5pbXBlcmF0aXZlQWN0aW9uIiwiUkVBU09OUy5ub25lIiwicG9wdXBPcGVuIiwiQ29tbW9uVHJpZ2dlckRhdGFBdHRyaWJ1dGVzLnBvcHVwT3BlbiIsIkNvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcy5wcmVzc2VkIiwiZGlzYWJsZWQiLCJwbGFjZWhvbGRlciIsInN0YXRlQXR0cmlidXRlc01hcHBpbmciLCJTZWxlY3RUcmlnZ2VyRGF0YUF0dHJpYnV0ZXMucG9wdXBTaWRlIiwiUkVBU09OUy5ub25lIiwiUkVBU09OUy5jYW5jZWxPcGVuIiwic3RhdGVBdHRyaWJ1dGVzTWFwcGluZyIsInN0YXRlQXR0cmlidXRlc01hcHBpbmciLCJSRUFTT05TLm5vbmUiLCJvd25lcldpbmRvdyIsIlNlbGVjdFBvc2l0aW9uZXJDc3NWYXJzLnRyYW5zZm9ybU9yaWdpbiIsInBsYXRmb3JtLmVuZ2luZS53ZWJraXQiLCJSRUFTT05TLndpbmRvd1Jlc2l6ZSIsImZsb2F0aW5nUGxhdGZvcm0iLCJSRUFTT05TLml0ZW1QcmVzcyIsIkNvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcy5wb3B1cE9wZW4iLCJvcGVuIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5vcGVuIiwiY2xvc2VkIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5jbG9zZWQiLCJzdGFydGluZ1N0eWxlIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zdGFydGluZ1N0eWxlIiwiZW5kaW5nU3R5bGUiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmVuZGluZ1N0eWxlIiwib3BlbiIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMub3BlbiIsImNsb3NlZCIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuY2xvc2VkIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5hbmNob3JIaWRkZW4iLCJzaWRlIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zaWRlIiwiYWxpZ24iLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmFsaWduIiwib3BlbiIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMub3BlbiIsImNsb3NlZCIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuY2xvc2VkIiwic3RhcnRpbmdTdHlsZSIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuc3RhcnRpbmdTdHlsZSIsImVuZGluZ1N0eWxlIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5lbmRpbmdTdHlsZSIsInNpZGUiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnNpZGUiLCJhbGlnbiIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuYWxpZ24iLCJzdGFydGluZ1N0eWxlIiwiVHJhbnNpdGlvblN0YXR1c0RhdGFBdHRyaWJ1dGVzLnN0YXJ0aW5nU3R5bGUiLCJlbmRpbmdTdHlsZSIsIlRyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcy5lbmRpbmdTdHlsZSIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMub3BlbiIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuY2xvc2VkIiwic2lkZSIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuc2lkZSIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuYWxpZ24iLCJzdGFydGluZ1N0eWxlIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zdGFydGluZ1N0eWxlIiwiZW5kaW5nU3R5bGUiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmVuZGluZ1N0eWxlIiwiZGlyZWN0aW9uIiwidmlzaWJsZSIsInNpZGUiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnNpZGUiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnN0YXJ0aW5nU3R5bGUiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmVuZGluZ1N0eWxlIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zaWRlIl0sInNvdXJjZXMiOlsiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvaG9va3MvdXNlRmxvYXRpbmdSb290Q29udGV4dC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy91c2VSZWdpc3RlcmVkTGFiZWxJZC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9pbnRlcm5hbHMvbGFiZWxhYmxlLXByb3ZpZGVyL3VzZUxhYmVsLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3VzZU9uRmlyc3RSZW5kZXIubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L3Jvb3QvU2VsZWN0Um9vdENvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvYXJlQXJyYXlzRXF1YWwubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL2l0ZW1FcXVhbGl0eS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9zZWxlY3Qvc3RvcmUubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvY2xhbXAubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvc2Nyb2xsRWRnZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L3Jvb3QvU2VsZWN0Um9vdC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9yZXNvbHZlQXJpYUxhYmVsbGVkQnkubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L2xhYmVsL1NlbGVjdExhYmVsLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3NlbGVjdC90cmlnZ2VyL1NlbGVjdFRyaWdnZXJEYXRhQXR0cmlidXRlcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9zZWxlY3QvdHJpZ2dlci9TZWxlY3RUcmlnZ2VyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3NlbGVjdC92YWx1ZS9TZWxlY3RWYWx1ZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9zZWxlY3QvaWNvbi9TZWxlY3RJY29uLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3NlbGVjdC9wb3J0YWwvU2VsZWN0UG9ydGFsLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3NlbGVjdC9iYWNrZHJvcC9TZWxlY3RCYWNrZHJvcC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9zZWxlY3QvcG9zaXRpb25lci9TZWxlY3RQb3NpdGlvbmVyQ29udGV4dC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9zZWxlY3QvcG9wdXAvdXRpbHMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L3Bvc2l0aW9uZXIvU2VsZWN0UG9zaXRpb25lci5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9zdHlsZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L3Bvc2l0aW9uZXIvU2VsZWN0UG9zaXRpb25lckNzc1ZhcnMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L3BvcHVwL1NlbGVjdFBvcHVwLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3NlbGVjdC9saXN0L1NlbGVjdExpc3QubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L2l0ZW0vU2VsZWN0SXRlbUNvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L2l0ZW0vU2VsZWN0SXRlbS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9JdGVtSW5kaWNhdG9yLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3NlbGVjdC9pdGVtLWluZGljYXRvci9TZWxlY3RJdGVtSW5kaWNhdG9yLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3NlbGVjdC9pdGVtLXRleHQvU2VsZWN0SXRlbVRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L2Fycm93L1NlbGVjdEFycm93Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3NlbGVjdC9zY3JvbGwtYXJyb3cvU2VsZWN0U2Nyb2xsQXJyb3cubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L3Njcm9sbC1kb3duLWFycm93L1NlbGVjdFNjcm9sbERvd25BcnJvdy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9zZWxlY3Qvc2Nyb2xsLXVwLWFycm93L1NlbGVjdFNjcm9sbFVwQXJyb3cubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L2dyb3VwL1NlbGVjdEdyb3VwQ29udGV4dC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9zZWxlY3QvZ3JvdXAvU2VsZWN0R3JvdXAubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L2dyb3VwLWxhYmVsL1NlbGVjdEdyb3VwTGFiZWwubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvbGlzdGJveC1zZXBhcmF0b3IvTGlzdGJveFNlcGFyYXRvci5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9zZWxlY3Qvc2VwYXJhdG9yL1NlbGVjdFNlcGFyYXRvci5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9zZWxlY3QvaW5kZXgucGFydHMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L3ZhbHVlL1NlbGVjdFZhbHVlRGF0YUF0dHJpYnV0ZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L2ljb24vU2VsZWN0SWNvbkRhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3NlbGVjdC9iYWNrZHJvcC9TZWxlY3RCYWNrZHJvcERhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3NlbGVjdC9wb3NpdGlvbmVyL1NlbGVjdFBvc2l0aW9uZXJEYXRhQXR0cmlidXRlcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9zZWxlY3QvcG9wdXAvU2VsZWN0UG9wdXBEYXRhQXR0cmlidXRlcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9zZWxlY3QvaXRlbS9TZWxlY3RJdGVtRGF0YUF0dHJpYnV0ZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L2l0ZW0taW5kaWNhdG9yL1NlbGVjdEl0ZW1JbmRpY2F0b3JEYXRhQXR0cmlidXRlcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9zZWxlY3QvYXJyb3cvU2VsZWN0QXJyb3dEYXRhQXR0cmlidXRlcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9zZWxlY3Qvc2Nyb2xsLWRvd24tYXJyb3cvU2VsZWN0U2Nyb2xsRG93bkFycm93RGF0YUF0dHJpYnV0ZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VsZWN0L3Njcm9sbC11cC1hcnJvdy9TZWxlY3RTY3JvbGxVcEFycm93RGF0YUF0dHJpYnV0ZXMubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2UgY2xpZW50JztcblxuaW1wb3J0IHsgaXNFbGVtZW50IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzL2RvbSc7XG5pbXBvcnQgeyB1c2VJZCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlkJztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVJlZldpdGhJbml0JztcbmltcG9ydCB7IFBvcHVwVHJpZ2dlck1hcCB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cHMvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyB1c2VGbG9hdGluZ1BhcmVudE5vZGVJZCB9IGZyb20gXCIuLi9jb21wb25lbnRzL0Zsb2F0aW5nVHJlZS5tanNcIjtcbmltcG9ydCB7IEZsb2F0aW5nUm9vdFN0b3JlIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvRmxvYXRpbmdSb290U3RvcmUubWpzXCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlRmxvYXRpbmdSb290Q29udGV4dChvcHRpb25zKSB7XG4gIGNvbnN0IHtcbiAgICBvcGVuID0gZmFsc2UsXG4gICAgb25PcGVuQ2hhbmdlLFxuICAgIGVsZW1lbnRzID0ge31cbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGZsb2F0aW5nSWQgPSB1c2VJZCgpO1xuICBjb25zdCBuZXN0ZWQgPSB1c2VGbG9hdGluZ1BhcmVudE5vZGVJZCgpICE9IG51bGw7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgY29uc3Qgb3B0aW9uRG9tUmVmZXJlbmNlID0gZWxlbWVudHMucmVmZXJlbmNlO1xuICAgIGlmIChvcHRpb25Eb21SZWZlcmVuY2UgJiYgIWlzRWxlbWVudChvcHRpb25Eb21SZWZlcmVuY2UpKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdDYW5ub3QgcGFzcyBhIHZpcnR1YWwgZWxlbWVudCB0byB0aGUgYGVsZW1lbnRzLnJlZmVyZW5jZWAgb3B0aW9uLCcsICdhcyBpdCBtdXN0IGJlIGEgcmVhbCBET00gZWxlbWVudC4gVXNlIGBjb250ZXh0LnNldFBvc2l0aW9uUmVmZXJlbmNlKClgJywgJ2luc3RlYWQuJyk7XG4gICAgfVxuICB9XG4gIGNvbnN0IHN0b3JlID0gdXNlUmVmV2l0aEluaXQoKCkgPT4gbmV3IEZsb2F0aW5nUm9vdFN0b3JlKHtcbiAgICBvcGVuLFxuICAgIHRyYW5zaXRpb25TdGF0dXM6IHVuZGVmaW5lZCxcbiAgICBvbk9wZW5DaGFuZ2UsXG4gICAgcmVmZXJlbmNlRWxlbWVudDogZWxlbWVudHMucmVmZXJlbmNlID8/IG51bGwsXG4gICAgZmxvYXRpbmdFbGVtZW50OiBlbGVtZW50cy5mbG9hdGluZyA/PyBudWxsLFxuICAgIHRyaWdnZXJFbGVtZW50czogbmV3IFBvcHVwVHJpZ2dlck1hcCgpLFxuICAgIGZsb2F0aW5nSWQsXG4gICAgc3luY09ubHk6IGZhbHNlLFxuICAgIG5lc3RlZFxuICB9KSkuY3VycmVudDtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCB2YWx1ZXNUb1N5bmMgPSB7XG4gICAgICBvcGVuLFxuICAgICAgZmxvYXRpbmdJZFxuICAgIH07XG4gICAgaWYgKGVsZW1lbnRzLnJlZmVyZW5jZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB2YWx1ZXNUb1N5bmMucmVmZXJlbmNlRWxlbWVudCA9IGVsZW1lbnRzLnJlZmVyZW5jZTtcbiAgICAgIHZhbHVlc1RvU3luYy5kb21SZWZlcmVuY2VFbGVtZW50ID0gaXNFbGVtZW50KGVsZW1lbnRzLnJlZmVyZW5jZSkgPyBlbGVtZW50cy5yZWZlcmVuY2UgOiBudWxsO1xuICAgIH1cbiAgICBpZiAoZWxlbWVudHMuZmxvYXRpbmcgIT09IHVuZGVmaW5lZCkge1xuICAgICAgdmFsdWVzVG9TeW5jLmZsb2F0aW5nRWxlbWVudCA9IGVsZW1lbnRzLmZsb2F0aW5nO1xuICAgIH1cbiAgICBzdG9yZS51cGRhdGUodmFsdWVzVG9TeW5jKTtcbiAgfSwgW29wZW4sIGZsb2F0aW5nSWQsIGVsZW1lbnRzLnJlZmVyZW5jZSwgZWxlbWVudHMuZmxvYXRpbmcsIHN0b3JlXSk7XG4gIHN0b3JlLmNvbnRleHQub25PcGVuQ2hhbmdlID0gb25PcGVuQ2hhbmdlO1xuICBzdG9yZS5jb250ZXh0Lm5lc3RlZCA9IG5lc3RlZDtcbiAgcmV0dXJuIHN0b3JlO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZUJhc2VVaUlkIH0gZnJvbSBcIi4uL2ludGVybmFscy91c2VCYXNlVWlJZC5tanNcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VSZWdpc3RlcmVkTGFiZWxJZChpZFByb3AsIHNldExhYmVsSWQpIHtcbiAgY29uc3QgaWQgPSB1c2VCYXNlVWlJZChpZFByb3ApO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIHNldExhYmVsSWQoaWQpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBzZXRMYWJlbElkKGN1cnJlbnRJZCA9PiBjdXJyZW50SWQgPT09IGlkID8gdW5kZWZpbmVkIDogY3VycmVudElkKTtcbiAgICB9O1xuICB9LCBbaWQsIHNldExhYmVsSWRdKTtcbiAgcmV0dXJuIGlkO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IHsgaXNIVE1MRWxlbWVudCwgaXNTaGFkb3dSb290IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzL2RvbSc7XG5pbXBvcnQgeyBvd25lckRvY3VtZW50IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvb3duZXInO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyBjbG9zZXN0LCBnZXRUYXJnZXQgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvdXRpbHMubWpzXCI7XG5pbXBvcnQgeyB1c2VSZWdpc3RlcmVkTGFiZWxJZCB9IGZyb20gXCIuLi8uLi91dGlscy91c2VSZWdpc3RlcmVkTGFiZWxJZC5tanNcIjtcbmltcG9ydCB7IHVzZUxhYmVsYWJsZUNvbnRleHQgfSBmcm9tIFwiLi9MYWJlbGFibGVDb250ZXh0Lm1qc1wiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUxhYmVsKHBhcmFtcyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBpZDogaWRQcm9wLFxuICAgIGZhbGxiYWNrQ29udHJvbElkLFxuICAgIG5hdGl2ZSA9IGZhbHNlLFxuICAgIHNldExhYmVsSWQ6IHNldExhYmVsSWRQcm9wLFxuICAgIGZvY3VzQ29udHJvbDogZm9jdXNDb250cm9sUHJvcFxuICB9ID0gcGFyYW1zO1xuICBjb25zdCB7XG4gICAgY29udHJvbElkOiBjb250ZXh0Q29udHJvbElkLFxuICAgIHNldExhYmVsSWQ6IHNldENvbnRleHRMYWJlbElkXG4gIH0gPSB1c2VMYWJlbGFibGVDb250ZXh0KCk7XG4gIGNvbnN0IHN5bmNMYWJlbElkID0gdXNlU3RhYmxlQ2FsbGJhY2sobmV4dExhYmVsSWQgPT4ge1xuICAgIHNldENvbnRleHRMYWJlbElkKG5leHRMYWJlbElkKTtcbiAgICBzZXRMYWJlbElkUHJvcD8uKG5leHRMYWJlbElkKTtcbiAgfSk7XG4gIGNvbnN0IGlkID0gdXNlUmVnaXN0ZXJlZExhYmVsSWQoaWRQcm9wLCBzeW5jTGFiZWxJZCk7XG4gIGNvbnN0IHJlc29sdmVkQ29udHJvbElkID0gY29udGV4dENvbnRyb2xJZCA/PyBmYWxsYmFja0NvbnRyb2xJZDtcbiAgZnVuY3Rpb24gZm9jdXNDb250cm9sKGV2ZW50KSB7XG4gICAgaWYgKGZvY3VzQ29udHJvbFByb3ApIHtcbiAgICAgIGZvY3VzQ29udHJvbFByb3AoZXZlbnQsIHJlc29sdmVkQ29udHJvbElkKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCFyZXNvbHZlZENvbnRyb2xJZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjb250cm9sRWxlbWVudCA9IGdldENvbnRyb2xCeUlkKGV2ZW50LmN1cnJlbnRUYXJnZXQsIHJlc29sdmVkQ29udHJvbElkKTtcbiAgICBpZiAoaXNIVE1MRWxlbWVudChjb250cm9sRWxlbWVudCkpIHtcbiAgICAgIGZvY3VzRWxlbWVudFdpdGhWaXNpYmxlKGNvbnRyb2xFbGVtZW50KTtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gaGFuZGxlSW50ZXJhY3Rpb24oZXZlbnQpIHtcbiAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQubmF0aXZlRXZlbnQpO1xuICAgIGlmIChjbG9zZXN0KHRhcmdldCwgJ2J1dHRvbixpbnB1dCxzZWxlY3QsdGV4dGFyZWEnKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIFByZXZlbnQgdGV4dCBzZWxlY3Rpb24gd2hlbiBkb3VibGUgY2xpY2tpbmcgbGFiZWwuXG4gICAgaWYgKCFldmVudC5kZWZhdWx0UHJldmVudGVkICYmIGV2ZW50LmRldGFpbCA+IDEpIHtcbiAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgfVxuICAgIGlmIChuYXRpdmUpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZm9jdXNDb250cm9sKGV2ZW50KTtcbiAgfVxuICByZXR1cm4gbmF0aXZlID8ge1xuICAgIGlkLFxuICAgIGh0bWxGb3I6IHJlc29sdmVkQ29udHJvbElkLFxuICAgIG9uTW91c2VEb3duOiBoYW5kbGVJbnRlcmFjdGlvblxuICB9IDoge1xuICAgIGlkLFxuICAgIG9uQ2xpY2s6IGhhbmRsZUludGVyYWN0aW9uLFxuICAgIG9uUG9pbnRlckRvd24oZXZlbnQpIHtcbiAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgfVxuICB9O1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdldENvbnRyb2xCeUlkKGxhYmVsLCBpZCkge1xuICBsZXQgcm9vdCA9IGxhYmVsLmdldFJvb3ROb2RlKCk7XG4gIHdoaWxlIChpc1NoYWRvd1Jvb3Qocm9vdCkpIHtcbiAgICBjb25zdCBlbGVtZW50ID0gcm9vdC5nZXRFbGVtZW50QnlJZChpZCk7XG4gICAgaWYgKGVsZW1lbnQpIHtcbiAgICAgIHJldHVybiBlbGVtZW50O1xuICAgIH1cbiAgICByb290ID0gcm9vdC5ob3N0LmdldFJvb3ROb2RlKCk7XG4gIH1cbiAgcmV0dXJuIG93bmVyRG9jdW1lbnQobGFiZWwpLmdldEVsZW1lbnRCeUlkKGlkKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBmb2N1c0VsZW1lbnRXaXRoVmlzaWJsZShlbGVtZW50KSB7XG4gIGVsZW1lbnQuZm9jdXMoe1xuICAgIC8vIEF2YWlsYWJsZSBmcm9tIENocm9tZSAxNDQrIChKYW51YXJ5IDIwMjYpLlxuICAgIC8vIFNhZmFyaSBhbmQgRmlyZWZveCBhbHJlYWR5IHN1cHBvcnQgaXQuXG4gICAgZm9jdXNWaXNpYmxlOiB0cnVlXG4gIH0pO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZU9uRmlyc3RSZW5kZXIoZm4pIHtcbiAgY29uc3QgcmVmID0gUmVhY3QudXNlUmVmKHRydWUpO1xuICBpZiAocmVmLmN1cnJlbnQpIHtcbiAgICByZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIGZuKCk7XG4gIH1cbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCBfZm9ybWF0RXJyb3JNZXNzYWdlIGZyb20gXCJAYmFzZS11aS91dGlscy9mb3JtYXRFcnJvck1lc3NhZ2VcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBTZWxlY3RSb290Q29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHVuZGVmaW5lZCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBTZWxlY3RSb290Q29udGV4dC5kaXNwbGF5TmFtZSA9IFwiU2VsZWN0Um9vdENvbnRleHRcIjtcbmV4cG9ydCBjb25zdCBTZWxlY3RGbG9hdGluZ0NvbnRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlQ29udGV4dCh1bmRlZmluZWQpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgU2VsZWN0RmxvYXRpbmdDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJTZWxlY3RGbG9hdGluZ0NvbnRleHRcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VTZWxlY3RSb290Q29udGV4dCgpIHtcbiAgY29uc3Qgc3RvcmUgPSBSZWFjdC51c2VDb250ZXh0KFNlbGVjdFJvb3RDb250ZXh0KTtcbiAgaWYgKHN0b3JlID09PSB1bmRlZmluZWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gJ0Jhc2UgVUk6IFNlbGVjdFJvb3RDb250ZXh0IGlzIG1pc3NpbmcuIFNlbGVjdCBwYXJ0cyBtdXN0IGJlIHBsYWNlZCB3aXRoaW4gPFNlbGVjdC5Sb290Pi4nIDogX2Zvcm1hdEVycm9yTWVzc2FnZSg2MCkpO1xuICB9XG4gIHJldHVybiBzdG9yZTtcbn1cbmV4cG9ydCBmdW5jdGlvbiB1c2VTZWxlY3RGbG9hdGluZ0NvbnRleHQoKSB7XG4gIGNvbnN0IGNvbnRleHQgPSBSZWFjdC51c2VDb250ZXh0KFNlbGVjdEZsb2F0aW5nQ29udGV4dCk7XG4gIGlmIChjb250ZXh0ID09PSB1bmRlZmluZWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gJ0Jhc2UgVUk6IFNlbGVjdEZsb2F0aW5nQ29udGV4dCBpcyBtaXNzaW5nLiBTZWxlY3QgcGFydHMgbXVzdCBiZSBwbGFjZWQgd2l0aGluIDxTZWxlY3QuUm9vdD4uJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoNjEpKTtcbiAgfVxuICByZXR1cm4gY29udGV4dDtcbn0iLCIvLyBodHRwczovL2dpdGh1Yi5jb20vbXVpL211aS14L2Jsb2IvbWFzdGVyL3BhY2thZ2VzL3gtaW50ZXJuYWxzL3NyYy9mYXN0QXJyYXlDb21wYXJlL2Zhc3RBcnJheUNvbXBhcmUudHNcblxuLyoqXG4gKiBDb21wYXJlcyB0d28gYXJyYXlzIGVsZW1lbnQtd2lzZS5cbiAqXG4gKiBUaGUgZGVmYXVsdCBjb21wYXJpc29uIGlzIGBPYmplY3QuaXNgLCBzbyBgTmFOYCBlcXVhbHMgYE5hTmAgYW5kIGAwYCBkb2VzIG5vdCBlcXVhbCBgLTBgLlxuICovXG5leHBvcnQgZnVuY3Rpb24gYXJlQXJyYXlzRXF1YWwoYXJyYXkxLCBhcnJheTIsIGl0ZW1Db21wYXJlciA9IE9iamVjdC5pcykge1xuICBjb25zdCB7XG4gICAgbGVuZ3RoXG4gIH0gPSBhcnJheTE7XG4gIGlmIChsZW5ndGggIT09IGFycmF5Mi5sZW5ndGgpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkgKz0gMSkge1xuICAgIGlmICghaXRlbUNvbXBhcmVyKGFycmF5MVtpXSwgYXJyYXkyW2ldKSkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn0iLCJpbXBvcnQgeyBhcmVBcnJheXNFcXVhbCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2FyZUFycmF5c0VxdWFsJztcbi8vIENvbXBhcmVkIGJ5IGlkZW50aXR5IGluIGBmaW5kU2VsZWN0aW9uSW5kZXhgOyBkb24ndCB3cmFwIGl0LlxuZXhwb3J0IGNvbnN0IGRlZmF1bHRJdGVtRXF1YWxpdHkgPSAoaXRlbVZhbHVlLCBzZWxlY3RlZFZhbHVlKSA9PiBPYmplY3QuaXMoaXRlbVZhbHVlLCBzZWxlY3RlZFZhbHVlKTtcbmV4cG9ydCBmdW5jdGlvbiBjb21wYXJlSXRlbUVxdWFsaXR5KGl0ZW1WYWx1ZSwgc2VsZWN0ZWRWYWx1ZSwgY29tcGFyZXIpIHtcbiAgaWYgKGl0ZW1WYWx1ZSA9PSBudWxsIHx8IHNlbGVjdGVkVmFsdWUgPT0gbnVsbCkge1xuICAgIHJldHVybiBPYmplY3QuaXMoaXRlbVZhbHVlLCBzZWxlY3RlZFZhbHVlKTtcbiAgfVxuICByZXR1cm4gY29tcGFyZXIoaXRlbVZhbHVlLCBzZWxlY3RlZFZhbHVlKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc1NlbGVjdGVkVmFsdWVEaXJ0eShjdXJyZW50VmFsdWUsIGluaXRpYWxWYWx1ZSwgY29tcGFyZXIpIHtcbiAgaWYgKEFycmF5LmlzQXJyYXkoY3VycmVudFZhbHVlKSAmJiBBcnJheS5pc0FycmF5KGluaXRpYWxWYWx1ZSkpIHtcbiAgICByZXR1cm4gIWFyZUFycmF5c0VxdWFsKGN1cnJlbnRWYWx1ZSwgaW5pdGlhbFZhbHVlLCAoaXRlbVZhbHVlLCBpbml0aWFsSXRlbVZhbHVlKSA9PiBjb21wYXJlSXRlbUVxdWFsaXR5KGl0ZW1WYWx1ZSwgaW5pdGlhbEl0ZW1WYWx1ZSwgY29tcGFyZXIpKTtcbiAgfVxuICByZXR1cm4gY3VycmVudFZhbHVlICE9PSBpbml0aWFsVmFsdWU7XG59XG5leHBvcnQgZnVuY3Rpb24gc2VsZWN0ZWRWYWx1ZUluY2x1ZGVzKHNlbGVjdGVkVmFsdWVzLCBpdGVtVmFsdWUsIGNvbXBhcmVyKSB7XG4gIGlmICghc2VsZWN0ZWRWYWx1ZXMpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHNlbGVjdGVkVmFsdWVzLnNvbWUoc2VsZWN0ZWRWYWx1ZSA9PiB7XG4gICAgaWYgKHNlbGVjdGVkVmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gY29tcGFyZUl0ZW1FcXVhbGl0eShpdGVtVmFsdWUsIHNlbGVjdGVkVmFsdWUsIGNvbXBhcmVyKTtcbiAgfSk7XG59XG5leHBvcnQgZnVuY3Rpb24gZmluZEl0ZW1JbmRleChpdGVtVmFsdWVzLCBzZWxlY3RlZFZhbHVlLCBjb21wYXJlcikge1xuICBpZiAoIWl0ZW1WYWx1ZXMpIHtcbiAgICByZXR1cm4gLTE7XG4gIH1cbiAgcmV0dXJuIGl0ZW1WYWx1ZXMuZmluZEluZGV4KGl0ZW1WYWx1ZSA9PiB7XG4gICAgaWYgKGl0ZW1WYWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiBjb21wYXJlSXRlbUVxdWFsaXR5KGl0ZW1WYWx1ZSwgc2VsZWN0ZWRWYWx1ZSwgY29tcGFyZXIpO1xuICB9KTtcbn1cblxuLy8gVGhlIGRlZmF1bHQgY29tcGFyZXIgaXMgYE9iamVjdC5pc2AsIHNvIHRoZSB2YWx1ZXMgY2FuIGJlIGluZGV4ZWQgaW5zdGVhZCBvZiByZXNjYW5uZWRcbi8vIGZvciBldmVyeSBpdGVtLiBBIGN1c3RvbSBjb21wYXJlciBtYXkgbWF0Y2ggdmFsdWVzIHRoYXQgZG9uJ3QgaGFzaCBhbGlrZS5cbmZ1bmN0aW9uIGNyZWF0ZVNlbGVjdGlvbk1hdGNoZXIoc2VsZWN0ZWRWYWx1ZXMsIGNvbXBhcmVyKSB7XG4gIGlmIChjb21wYXJlciAhPT0gZGVmYXVsdEl0ZW1FcXVhbGl0eSkge1xuICAgIHJldHVybiBpdGVtVmFsdWUgPT4gc2VsZWN0ZWRWYWx1ZUluY2x1ZGVzKHNlbGVjdGVkVmFsdWVzLCBpdGVtVmFsdWUsIGNvbXBhcmVyKTtcbiAgfVxuICBjb25zdCBpbmRleCA9IG5ldyBTZXQoc2VsZWN0ZWRWYWx1ZXMpO1xuICBpbmRleC5kZWxldGUodW5kZWZpbmVkKTtcbiAgLy8gYFNldGAgdHJlYXRzICswIGFuZCAtMCBhcyBlcXVhbDsgYE9iamVjdC5pc2AgZG9lcyBub3QuXG4gIHJldHVybiBpdGVtVmFsdWUgPT4gaW5kZXguaGFzKGl0ZW1WYWx1ZSkgJiYgKGl0ZW1WYWx1ZSAhPT0gMCB8fCBzZWxlY3RlZFZhbHVlcy5zb21lKHYgPT4gT2JqZWN0LmlzKGl0ZW1WYWx1ZSwgdikpKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBmaW5kU2VsZWN0aW9uSW5kZXgoaXRlbVZhbHVlcywgc2VsZWN0ZWRWYWx1ZSwgY29tcGFyZXIsIG11bHRpcGxlKSB7XG4gIC8vIE9ubHkgdHJlYXQgdGhlIHZhbHVlIGFzIGEgbGlzdCBpbiBtdWx0aXBsZSBtb2RlOiBhbiBhcnJheSBjYW4gaXRzZWxmIGJlIGEgdmFsaWRcbiAgLy8gc2luZ2xlLXNlbGVjdCB2YWx1ZS5cbiAgY29uc3QgaW5kZXggPSBtdWx0aXBsZSAmJiBBcnJheS5pc0FycmF5KHNlbGVjdGVkVmFsdWUpID9cbiAgLy8gQW5jaG9yIHRvIHRoZSBmaXJzdCBzZWxlY3RlZCBpdGVtIGluIHJlbmRlcmVkIG9yZGVyIHNvIHRoZSBpbmRleCBkb2VzIG5vdCBkZXBlbmRcbiAgLy8gb24gdGhlIG9yZGVyIGluIHdoaWNoIHRoZSB2YWx1ZXMgd2VyZSBhZGRlZCB0byB0aGUgYXJyYXkuXG4gIGl0ZW1WYWx1ZXMuZmluZEluZGV4KGNyZWF0ZVNlbGVjdGlvbk1hdGNoZXIoc2VsZWN0ZWRWYWx1ZSwgY29tcGFyZXIpKSA6IGZpbmRJdGVtSW5kZXgoaXRlbVZhbHVlcywgc2VsZWN0ZWRWYWx1ZSwgY29tcGFyZXIpO1xuICByZXR1cm4gaW5kZXggPT09IC0xID8gbnVsbCA6IGluZGV4O1xufVxuXG4vKiogUmVzb2x2ZXMgdGhlIGZpcnN0IHNlbGVjdGVkIGluZGV4IGFzIGl0ZW1zIHJlZ2lzdGVyIG9yIGNoYW5nZS4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlU2VsZWN0ZWRJbmRleChpbmRleCwgaXRlbVZhbHVlLCByZWdpc3RyeSwgc2VsZWN0ZWRWYWx1ZXMsIGNvbXBhcmVyLCBjdXJyZW50SW5kZXgpIHtcbiAgaWYgKHNlbGVjdGVkVmFsdWVJbmNsdWRlcyhzZWxlY3RlZFZhbHVlcywgaXRlbVZhbHVlLCBjb21wYXJlcikpIHtcbiAgICAvLyBBIGxhdGVyIGl0ZW0gb25seSB0YWtlcyBvdmVyIG9uY2UgdGhlIGN1cnJlbnQgYW5jaG9yIHN0b3BzIGJlaW5nIHNlbGVjdGVkLlxuICAgIHJldHVybiBjdXJyZW50SW5kZXggIT0gbnVsbCAmJiBpbmRleCA+IGN1cnJlbnRJbmRleCAmJiBzZWxlY3RlZFZhbHVlSW5jbHVkZXMoc2VsZWN0ZWRWYWx1ZXMsIHJlZ2lzdHJ5W2N1cnJlbnRJbmRleF0sIGNvbXBhcmVyKSA/IGN1cnJlbnRJbmRleCA6IGluZGV4O1xuICB9XG4gIC8vIFRoZSBob2xkZXIgcmUtZWxlY3RzIHRoZSBhbmNob3Igb25jZSBpdCBzdG9wcyBiZWluZyBzZWxlY3RlZC5cbiAgcmV0dXJuIGluZGV4ID09PSBjdXJyZW50SW5kZXggPyBmaW5kU2VsZWN0aW9uSW5kZXgocmVnaXN0cnksIHNlbGVjdGVkVmFsdWVzLCBjb21wYXJlciwgdHJ1ZSkgOiBjdXJyZW50SW5kZXg7XG59XG5leHBvcnQgZnVuY3Rpb24gcmVtb3ZlSXRlbShzZWxlY3RlZFZhbHVlcywgaXRlbVZhbHVlLCBjb21wYXJlcikge1xuICByZXR1cm4gc2VsZWN0ZWRWYWx1ZXMuZmlsdGVyKHNlbGVjdGVkVmFsdWUgPT4gIWNvbXBhcmVJdGVtRXF1YWxpdHkoaXRlbVZhbHVlLCBzZWxlY3RlZFZhbHVlLCBjb21wYXJlcikpO1xufSIsImltcG9ydCB7IGNvbXBhcmVJdGVtRXF1YWxpdHkgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL2l0ZW1FcXVhbGl0eS5tanNcIjtcbmltcG9ydCB7IGhhc051bGxJdGVtTGFiZWwsIHN0cmluZ2lmeUFzVmFsdWUgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL3Jlc29sdmVWYWx1ZUxhYmVsLm1qc1wiO1xuXG4vKipcbiAqIE5vbi1yZWFjdGl2ZSB2YWx1ZXMgc2hhcmVkIHdpdGggdGhlIHNlbGVjdCBwYXJ0cy4gTm90aGluZyBoZXJlIGlzIG9ic2VydmFibGUgdGhyb3VnaFxuICogYHNlbGVjdG9yc2AsIHNvIHdyaXRpbmcgdG8gYSByZWYgbmV2ZXIgbm90aWZpZXMgc3Vic2NyaWJlcnMuXG4gKi9cblxuZXhwb3J0IGNvbnN0IHNlbGVjdG9ycyA9IHtcbiAgaWQ6IHN0YXRlID0+IHN0YXRlLmlkLFxuICBsYWJlbElkOiBzdGF0ZSA9PiBzdGF0ZS5sYWJlbElkLFxuICBtb2RhbDogc3RhdGUgPT4gc3RhdGUubW9kYWwsXG4gIG11bHRpcGxlOiBzdGF0ZSA9PiBzdGF0ZS5tdWx0aXBsZSxcbiAgZGlzYWJsZWQ6IHN0YXRlID0+IHN0YXRlLmRpc2FibGVkLFxuICByZWFkT25seTogc3RhdGUgPT4gc3RhdGUucmVhZE9ubHksXG4gIHJlcXVpcmVkOiBzdGF0ZSA9PiBzdGF0ZS5yZXF1aXJlZCxcbiAgaGlnaGxpZ2h0SXRlbU9uSG92ZXI6IHN0YXRlID0+IHN0YXRlLmhpZ2hsaWdodEl0ZW1PbkhvdmVyLFxuICBpdGVtczogc3RhdGUgPT4gc3RhdGUuaXRlbXMsXG4gIGl0ZW1Ub1N0cmluZ0xhYmVsOiBzdGF0ZSA9PiBzdGF0ZS5pdGVtVG9TdHJpbmdMYWJlbCxcbiAgaXNJdGVtRXF1YWxUb1ZhbHVlOiBzdGF0ZSA9PiBzdGF0ZS5pc0l0ZW1FcXVhbFRvVmFsdWUsXG4gIHZhbHVlOiBzdGF0ZSA9PiBzdGF0ZS52YWx1ZSxcbiAgaGFzU2VsZWN0ZWRWYWx1ZTogc3RhdGUgPT4ge1xuICAgIGNvbnN0IHtcbiAgICAgIHZhbHVlLFxuICAgICAgbXVsdGlwbGUsXG4gICAgICBpdGVtVG9TdHJpbmdWYWx1ZVxuICAgIH0gPSBzdGF0ZTtcbiAgICBpZiAodmFsdWUgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAobXVsdGlwbGUgJiYgQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgIHJldHVybiB2YWx1ZS5sZW5ndGggPiAwO1xuICAgIH1cbiAgICByZXR1cm4gc3RyaW5naWZ5QXNWYWx1ZSh2YWx1ZSwgaXRlbVRvU3RyaW5nVmFsdWUpICE9PSAnJztcbiAgfSxcbiAgaGFzTnVsbEl0ZW1MYWJlbDogKHN0YXRlLCBlbmFibGVkKSA9PiB7XG4gICAgcmV0dXJuIGVuYWJsZWQgPyBoYXNOdWxsSXRlbUxhYmVsKHN0YXRlLml0ZW1zKSA6IGZhbHNlO1xuICB9LFxuICBvcGVuOiBzdGF0ZSA9PiBzdGF0ZS5vcGVuLFxuICBtb3VudGVkOiBzdGF0ZSA9PiBzdGF0ZS5tb3VudGVkLFxuICBmb3JjZU1vdW50OiBzdGF0ZSA9PiBzdGF0ZS5mb3JjZU1vdW50LFxuICB0cmFuc2l0aW9uU3RhdHVzOiBzdGF0ZSA9PiBzdGF0ZS50cmFuc2l0aW9uU3RhdHVzLFxuICBvcGVuTWV0aG9kOiBzdGF0ZSA9PiBzdGF0ZS5vcGVuTWV0aG9kLFxuICBhY3RpdmVJbmRleDogc3RhdGUgPT4gc3RhdGUuYWN0aXZlSW5kZXgsXG4gIHNlbGVjdGVkSW5kZXg6IHN0YXRlID0+IHN0YXRlLnNlbGVjdGVkSW5kZXgsXG4gIGlzQWN0aXZlOiAoc3RhdGUsIGluZGV4KSA9PiBzdGF0ZS5hY3RpdmVJbmRleCA9PT0gaW5kZXgsXG4gIGlzU2VsZWN0ZWQ6IChzdGF0ZSwgaXRlbVZhbHVlKSA9PiB7XG4gICAgY29uc3QgY29tcGFyZXIgPSBzdGF0ZS5pc0l0ZW1FcXVhbFRvVmFsdWU7XG4gICAgY29uc3Qgc3RvcmVWYWx1ZSA9IHN0YXRlLnZhbHVlO1xuICAgIGlmIChzdGF0ZS5tdWx0aXBsZSkge1xuICAgICAgcmV0dXJuIEFycmF5LmlzQXJyYXkoc3RvcmVWYWx1ZSkgJiYgc3RvcmVWYWx1ZS5zb21lKHNlbGVjdGVkSXRlbSA9PiBjb21wYXJlSXRlbUVxdWFsaXR5KGl0ZW1WYWx1ZSwgc2VsZWN0ZWRJdGVtLCBjb21wYXJlcikpO1xuICAgIH1cblxuICAgIC8vIFRoZSB2YWx1ZSBpcyB0aGUgc291cmNlIG9mIHRydXRoOiBhIHN0YWxlIGBzZWxlY3RlZEluZGV4YCAoZS5nLiB0aGUgY29udHJvbGxlZFxuICAgIC8vIHZhbHVlIGNoYW5nZXMgd2hpbGUgdGhlIHBvcHVwIGlzIG9wZW4sIHdoZXJlIHRoZSBpbmRleCBzeW5jIGlzIGRlZmVycmVkKSBtdXN0IG5vdFxuICAgIC8vIGtlZXAgYSBwcmV2aW91c2x5IHNlbGVjdGVkIGl0ZW0gbWFya2VkIGFzIHNlbGVjdGVkLlxuICAgIHJldHVybiBjb21wYXJlSXRlbUVxdWFsaXR5KGl0ZW1WYWx1ZSwgc3RvcmVWYWx1ZSwgY29tcGFyZXIpO1xuICB9LFxuICBpc1NlbGVjdGVkQnlGb2N1czogKHN0YXRlLCBpbmRleCkgPT4ge1xuICAgIHJldHVybiBzdGF0ZS5zZWxlY3RlZEluZGV4ID09PSBpbmRleDtcbiAgfSxcbiAgcG9wdXBQcm9wczogc3RhdGUgPT4gc3RhdGUucG9wdXBQcm9wcyxcbiAgdHJpZ2dlclByb3BzOiBzdGF0ZSA9PiBzdGF0ZS50cmlnZ2VyUHJvcHMsXG4gIGl0ZW1Sb290OiBzdGF0ZSA9PiBzdGF0ZS5pdGVtUm9vdCxcbiAgdHJpZ2dlckVsZW1lbnQ6IHN0YXRlID0+IHN0YXRlLnRyaWdnZXJFbGVtZW50LFxuICBwb3NpdGlvbmVyRWxlbWVudDogc3RhdGUgPT4gc3RhdGUucG9zaXRpb25lckVsZW1lbnQsXG4gIGxpc3RFbGVtZW50OiBzdGF0ZSA9PiBzdGF0ZS5saXN0RWxlbWVudCxcbiAgcG9wdXBTaWRlOiBzdGF0ZSA9PiBzdGF0ZS5wb3B1cFNpZGUsXG4gIHNjcm9sbFVwQXJyb3dWaXNpYmxlOiBzdGF0ZSA9PiBzdGF0ZS5zY3JvbGxVcEFycm93VmlzaWJsZSxcbiAgc2Nyb2xsRG93bkFycm93VmlzaWJsZTogc3RhdGUgPT4gc3RhdGUuc2Nyb2xsRG93bkFycm93VmlzaWJsZSxcbiAgaGFzU2Nyb2xsQXJyb3dzOiBzdGF0ZSA9PiBzdGF0ZS5oYXNTY3JvbGxBcnJvd3Ncbn07IiwiZXhwb3J0IGZ1bmN0aW9uIGNsYW1wKHZhbCwgbWluID0gTnVtYmVyLk1JTl9TQUZFX0lOVEVHRVIsIG1heCA9IE51bWJlci5NQVhfU0FGRV9JTlRFR0VSKSB7XG4gIHJldHVybiBNYXRoLm1heChtaW4sIE1hdGgubWluKHZhbCwgbWF4KSk7XG59IiwiaW1wb3J0IHsgY2xhbXAgfSBmcm9tICdAYmFzZS11aS91dGlscy9jbGFtcCc7XG5leHBvcnQgY29uc3QgU0NST0xMX0VER0VfVE9MRVJBTkNFX1BYID0gMTtcbmV4cG9ydCBmdW5jdGlvbiBnZXRNYXhTY3JvbGxPZmZzZXQoc2Nyb2xsU2l6ZSwgY2xpZW50U2l6ZSkge1xuICByZXR1cm4gTWF0aC5tYXgoMCwgc2Nyb2xsU2l6ZSAtIGNsaWVudFNpemUpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZVNjcm9sbE9mZnNldCh2YWx1ZSwgbWF4KSB7XG4gIGlmIChtYXggPD0gMCkge1xuICAgIHJldHVybiAwO1xuICB9XG4gIGNvbnN0IGNsYW1wZWQgPSBjbGFtcCh2YWx1ZSwgMCwgbWF4KTtcbiAgY29uc3Qgc3RhcnREaXN0YW5jZSA9IGNsYW1wZWQ7XG4gIGNvbnN0IGVuZERpc3RhbmNlID0gbWF4IC0gY2xhbXBlZDtcbiAgY29uc3Qgd2l0aGluU3RhcnRUb2xlcmFuY2UgPSBzdGFydERpc3RhbmNlIDw9IFNDUk9MTF9FREdFX1RPTEVSQU5DRV9QWDtcbiAgY29uc3Qgd2l0aGluRW5kVG9sZXJhbmNlID0gZW5kRGlzdGFuY2UgPD0gU0NST0xMX0VER0VfVE9MRVJBTkNFX1BYO1xuICBpZiAod2l0aGluU3RhcnRUb2xlcmFuY2UgJiYgd2l0aGluRW5kVG9sZXJhbmNlKSB7XG4gICAgcmV0dXJuIHN0YXJ0RGlzdGFuY2UgPD0gZW5kRGlzdGFuY2UgPyAwIDogbWF4O1xuICB9XG4gIGlmICh3aXRoaW5TdGFydFRvbGVyYW5jZSkge1xuICAgIHJldHVybiAwO1xuICB9XG4gIGlmICh3aXRoaW5FbmRUb2xlcmFuY2UpIHtcbiAgICByZXR1cm4gbWF4O1xuICB9XG4gIHJldHVybiBjbGFtcGVkO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdmlzdWFsbHlIaWRkZW4sIHZpc3VhbGx5SGlkZGVuSW5wdXQgfSBmcm9tICdAYmFzZS11aS91dGlscy92aXN1YWxseUhpZGRlbic7XG5pbXBvcnQgeyB1c2VNZXJnZWRSZWZzIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlTWVyZ2VkUmVmcyc7XG5pbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVJlZldpdGhJbml0JztcbmltcG9ydCB7IHVzZU9uRmlyc3RSZW5kZXIgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VPbkZpcnN0UmVuZGVyJztcbmltcG9ydCB7IHVzZVByZXZpb3VzVmFsdWUgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VQcmV2aW91c1ZhbHVlJztcbmltcG9ydCB7IGlzRWxlbWVudERpc2FibGVkIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvaXNFbGVtZW50RGlzYWJsZWQnO1xuaW1wb3J0IHsgdXNlQ29udHJvbGxlZCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUNvbnRyb2xsZWQnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuaW1wb3J0IHsgdXNlVmFsdWVBc1JlZiB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVZhbHVlQXNSZWYnO1xuaW1wb3J0IHsgUmVhY3RTdG9yZSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3N0b3JlJztcbmltcG9ydCB7IEVNUFRZX0FSUkFZLCBFTVBUWV9PQkpFQ1QgfSBmcm9tICdAYmFzZS11aS91dGlscy9lbXB0eSc7XG5pbXBvcnQgeyB1c2VDbGljaywgdXNlRGlzbWlzcywgdXNlRmxvYXRpbmdSb290Q29udGV4dCwgdXNlTGlzdE5hdmlnYXRpb24sIHVzZVR5cGVhaGVhZCB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9pbmRleC5tanNcIjtcbmltcG9ydCB7IFNlbGVjdEZsb2F0aW5nQ29udGV4dCwgU2VsZWN0Um9vdENvbnRleHQgfSBmcm9tIFwiLi9TZWxlY3RSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZUZpZWxkUm9vdENvbnRleHQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2ZpZWxkLXJvb3QtY29udGV4dC9GaWVsZFJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVnaXN0ZXJGaWVsZENvbnRyb2wgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2ZpZWxkLXJlZ2lzdGVyLWNvbnRyb2wvdXNlUmVnaXN0ZXJGaWVsZENvbnRyb2wubWpzXCI7XG5pbXBvcnQgeyB1c2VMYWJlbGFibGVJZCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvbGFiZWxhYmxlLXByb3ZpZGVyL3VzZUxhYmVsYWJsZUlkLm1qc1wiO1xuaW1wb3J0IHsgdXNlVW5tb3VudEFmdGVyQ2xvc2UgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVVubW91bnRBZnRlckNsb3NlLm1qc1wiO1xuaW1wb3J0IHsgc2VsZWN0b3JzIH0gZnJvbSBcIi4uL3N0b3JlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsgYXR0YWNoUHJldmVudFVubW91bnRPbkNsb3NlIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwcy9wb3B1cFN0b3JlVXRpbHMubWpzXCI7XG5pbXBvcnQgeyB1c2VGb3JtQ29udGV4dCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvZm9ybS1jb250ZXh0L0Zvcm1Db250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgc3RyaW5naWZ5QXNMYWJlbCwgc3RyaW5naWZ5QXNWYWx1ZSB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVzb2x2ZVZhbHVlTGFiZWwubWpzXCI7XG5pbXBvcnQgeyBkZWZhdWx0SXRlbUVxdWFsaXR5LCBmaW5kU2VsZWN0aW9uSW5kZXgsIGlzU2VsZWN0ZWRWYWx1ZURpcnR5IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9pdGVtRXF1YWxpdHkubWpzXCI7XG5pbXBvcnQgeyB1c2VWYWx1ZUNoYW5nZWQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVZhbHVlQ2hhbmdlZC5tanNcIjtcbmltcG9ydCB7IHVzZU9wZW5JbnRlcmFjdGlvblR5cGUgfSBmcm9tIFwiLi4vLi4vdXRpbHMvdXNlT3BlbkludGVyYWN0aW9uVHlwZS5tanNcIjtcbmltcG9ydCB7IGdldE1heFNjcm9sbE9mZnNldCwgbm9ybWFsaXplU2Nyb2xsT2Zmc2V0IH0gZnJvbSBcIi4uLy4uL3V0aWxzL3Njcm9sbEVkZ2VzLm1qc1wiO1xuaW1wb3J0IHsgRk9DVVNBQkxFX1BPUFVQX1BST1BTIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwcy9pbmRleC5tanNcIjtcbmltcG9ydCB7IG1lcmdlUHJvcHMgfSBmcm9tIFwiLi4vLi4vbWVyZ2UtcHJvcHMvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBOT09QIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9ub29wLm1qc1wiO1xuXG4vKipcbiAqIEdyb3VwcyBhbGwgcGFydHMgb2YgdGhlIHNlbGVjdC5cbiAqIERvZXNuJ3QgcmVuZGVyIGl0cyBvd24gSFRNTCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIFNlbGVjdF0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL3NlbGVjdClcbiAqL1xuaW1wb3J0IHsganN4IGFzIF9qc3gsIGpzeHMgYXMgX2pzeHMgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCBmdW5jdGlvbiBTZWxlY3RSb290KHByb3BzKSB7XG4gIGNvbnN0IHtcbiAgICBpZCxcbiAgICB2YWx1ZTogdmFsdWVQcm9wLFxuICAgIGRlZmF1bHRWYWx1ZSA9IG51bGwsXG4gICAgb25WYWx1ZUNoYW5nZSxcbiAgICBvcGVuOiBvcGVuUHJvcCxcbiAgICBkZWZhdWx0T3BlbiA9IGZhbHNlLFxuICAgIG9uT3BlbkNoYW5nZSxcbiAgICBuYW1lOiBuYW1lUHJvcCxcbiAgICBmb3JtLFxuICAgIGF1dG9Db21wbGV0ZSxcbiAgICBkaXNhYmxlZDogZGlzYWJsZWRQcm9wID0gZmFsc2UsXG4gICAgcmVhZE9ubHkgPSBmYWxzZSxcbiAgICByZXF1aXJlZCA9IGZhbHNlLFxuICAgIG1vZGFsID0gdHJ1ZSxcbiAgICBhY3Rpb25zUmVmLFxuICAgIGlucHV0UmVmLFxuICAgIG9uT3BlbkNoYW5nZUNvbXBsZXRlLFxuICAgIGl0ZW1zLFxuICAgIG11bHRpcGxlID0gZmFsc2UsXG4gICAgaXRlbVRvU3RyaW5nTGFiZWwsXG4gICAgaXRlbVRvU3RyaW5nVmFsdWUsXG4gICAgaXNJdGVtRXF1YWxUb1ZhbHVlID0gZGVmYXVsdEl0ZW1FcXVhbGl0eSxcbiAgICBoaWdobGlnaHRJdGVtT25Ib3ZlciA9IHRydWUsXG4gICAgY2hpbGRyZW5cbiAgfSA9IHByb3BzO1xuICBjb25zdCB7XG4gICAgY2xlYXJFcnJvcnNcbiAgfSA9IHVzZUZvcm1Db250ZXh0KCk7XG4gIGNvbnN0IHtcbiAgICBzZXREaXJ0eSxcbiAgICBzZXRUb3VjaGVkLFxuICAgIHNldEZvY3VzZWQsXG4gICAgdmFsaWRpdHlEYXRhLFxuICAgIHNldEZpbGxlZCxcbiAgICBuYW1lOiBmaWVsZE5hbWUsXG4gICAgZGlzYWJsZWQ6IGZpZWxkRGlzYWJsZWQsXG4gICAgdmFsaWRhdGlvbixcbiAgICB2YWxpZGF0aW9uTW9kZVxuICB9ID0gdXNlRmllbGRSb290Q29udGV4dCgpO1xuICBjb25zdCBnZW5lcmF0ZWRJZCA9IHVzZUxhYmVsYWJsZUlkKHtcbiAgICBpZFxuICB9KTtcbiAgY29uc3QgZGlzYWJsZWQgPSBmaWVsZERpc2FibGVkIHx8IGRpc2FibGVkUHJvcDtcbiAgY29uc3QgbmFtZSA9IGZpZWxkTmFtZSA/PyBuYW1lUHJvcDtcbiAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZVVud3JhcHBlZF0gPSB1c2VDb250cm9sbGVkKHtcbiAgICBjb250cm9sbGVkOiB2YWx1ZVByb3AsXG4gICAgZGVmYXVsdDogbXVsdGlwbGUgPyBkZWZhdWx0VmFsdWUgPz8gRU1QVFlfQVJSQVkgOiBkZWZhdWx0VmFsdWUsXG4gICAgbmFtZTogJ1NlbGVjdCcsXG4gICAgc3RhdGU6ICd2YWx1ZSdcbiAgfSk7XG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuVW53cmFwcGVkXSA9IHVzZUNvbnRyb2xsZWQoe1xuICAgIGNvbnRyb2xsZWQ6IG9wZW5Qcm9wLFxuICAgIGRlZmF1bHQ6IGRlZmF1bHRPcGVuLFxuICAgIG5hbWU6ICdTZWxlY3QnLFxuICAgIHN0YXRlOiAnb3BlbidcbiAgfSk7XG4gIGNvbnN0IGxpc3RSZWYgPSBSZWFjdC51c2VSZWYoW10pO1xuICBjb25zdCBsYWJlbHNSZWYgPSBSZWFjdC51c2VSZWYoW10pO1xuICBjb25zdCBwb3B1cFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3Qgc2Nyb2xsSGFuZGxlclJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3Qgc2Nyb2xsQXJyb3dzTW91bnRlZENvdW50UmVmID0gUmVhY3QudXNlUmVmKDApO1xuICBjb25zdCB2YWx1ZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgdmFsdWVzUmVmID0gUmVhY3QudXNlUmVmKFtdKTtcbiAgY29uc3QgdHlwaW5nUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgZmlyc3RJdGVtVGV4dFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3Qgc2VsZWN0ZWRJdGVtVGV4dFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3Qgc2VsZWN0aW9uUmVmID0gUmVhY3QudXNlUmVmKHtcbiAgICBhbGxvd1NlbGVjdGVkTW91c2VVcDogZmFsc2UsXG4gICAgYWxsb3dVbnNlbGVjdGVkTW91c2VVcDogZmFsc2UsXG4gICAgZHJhZ1k6IDBcbiAgfSk7XG4gIGNvbnN0IGFsaWduSXRlbVdpdGhUcmlnZ2VyQWN0aXZlUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgaW5pdGlhbFZhbHVlUmVmID0gUmVhY3QudXNlUmVmKHZhbHVlKTtcbiAgY29uc3Qge1xuICAgIG9wZW5NZXRob2QsXG4gICAgdHJpZ2dlclByb3BzOiBpbnRlcmFjdGlvblR5cGVQcm9wc1xuICB9ID0gdXNlT3BlbkludGVyYWN0aW9uVHlwZShvcGVuKTtcbiAgY29uc3Qgc3RvcmUgPSB1c2VSZWZXaXRoSW5pdCgoKSA9PiBuZXcgUmVhY3RTdG9yZSh7XG4gICAgaWQ6IGdlbmVyYXRlZElkLFxuICAgIGxhYmVsSWQ6IHVuZGVmaW5lZCxcbiAgICBtb2RhbCxcbiAgICBtdWx0aXBsZSxcbiAgICBkaXNhYmxlZCxcbiAgICByZWFkT25seSxcbiAgICByZXF1aXJlZCxcbiAgICBoaWdobGlnaHRJdGVtT25Ib3ZlcixcbiAgICBpdGVtVG9TdHJpbmdMYWJlbCxcbiAgICBpdGVtVG9TdHJpbmdWYWx1ZSxcbiAgICBpc0l0ZW1FcXVhbFRvVmFsdWUsXG4gICAgdmFsdWUsXG4gICAgb3BlbixcbiAgICAvLyBTZWVkZWQgd2l0aCB0aGUgaW5pdGlhbCB2YWx1ZXMgb2YgYHVzZVVubW91bnRBZnRlckNsb3NlYCwgd2hpY2ggaXMgY2FsbGVkIGFmdGVyIHRoZVxuICAgIC8vIHN0b3JlIGJlY2F1c2UgaXRzIHVubW91bnQgY2xlYW51cCB3cml0ZXMgdG8gaXQuIGB1c2VTeW5jZWRWYWx1ZXNgIGtlZXBzIHRoZW0gaW4gc3luYy5cbiAgICBtb3VudGVkOiBvcGVuLFxuICAgIHRyYW5zaXRpb25TdGF0dXM6IHVuZGVmaW5lZCxcbiAgICBpdGVtcyxcbiAgICBmb3JjZU1vdW50OiBmYWxzZSxcbiAgICBvcGVuTWV0aG9kOiBudWxsLFxuICAgIGFjdGl2ZUluZGV4OiBudWxsLFxuICAgIHNlbGVjdGVkSW5kZXg6IG51bGwsXG4gICAgcG9wdXBQcm9wczogRU1QVFlfT0JKRUNULFxuICAgIHRyaWdnZXJQcm9wczogRU1QVFlfT0JKRUNULFxuICAgIGl0ZW1Sb290OiB7XG4gICAgICBwcm9wczogRU1QVFlfT0JKRUNULFxuICAgICAgbXVsdGlwbGUsXG4gICAgICBkaXNhYmxlZCxcbiAgICAgIHJlYWRPbmx5LFxuICAgICAgaXNJdGVtRXF1YWxUb1ZhbHVlXG4gICAgfSxcbiAgICB0cmlnZ2VyRWxlbWVudDogbnVsbCxcbiAgICBwb3NpdGlvbmVyRWxlbWVudDogbnVsbCxcbiAgICBsaXN0RWxlbWVudDogbnVsbCxcbiAgICBwb3B1cFNpZGU6IG51bGwsXG4gICAgc2Nyb2xsVXBBcnJvd1Zpc2libGU6IGZhbHNlLFxuICAgIHNjcm9sbERvd25BcnJvd1Zpc2libGU6IGZhbHNlLFxuICAgIGhhc1Njcm9sbEFycm93czogZmFsc2VcbiAgfSwge1xuICAgIHNldFZhbHVlOiBOT09QLFxuICAgIHNldE9wZW46IE5PT1AsXG4gICAgaGFuZGxlU2Nyb2xsQXJyb3dWaXNpYmlsaXR5OiBOT09QLFxuICAgIG9uT3BlbkNoYW5nZUNvbXBsZXRlOiBOT09QLFxuICAgIGxpc3RSZWYsXG4gICAgcG9wdXBSZWYsXG4gICAgc2Nyb2xsSGFuZGxlclJlZixcbiAgICBzY3JvbGxBcnJvd3NNb3VudGVkQ291bnRSZWYsXG4gICAgdmFsdWVSZWYsXG4gICAgdmFsdWVzUmVmLFxuICAgIGxhYmVsc1JlZixcbiAgICB0eXBpbmdSZWYsXG4gICAgc2VsZWN0aW9uUmVmLFxuICAgIGZpcnN0SXRlbVRleHRSZWYsXG4gICAgc2VsZWN0ZWRJdGVtVGV4dFJlZixcbiAgICBhbGlnbkl0ZW1XaXRoVHJpZ2dlckFjdGl2ZVJlZixcbiAgICBpbml0aWFsVmFsdWVSZWZcbiAgfSwgc2VsZWN0b3JzKSkuY3VycmVudDtcbiAgY29uc3QgW3ByZXZlbnRVbm1vdW50T25DbG9zZSwgc2V0UHJldmVudFVubW91bnRPbkNsb3NlXSA9IFJlYWN0LnVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3Qge1xuICAgIG1vdW50ZWQsXG4gICAgdHJhbnNpdGlvblN0YXR1cyxcbiAgICBmb3JjZVVubW91bnQ6IGhhbmRsZVVubW91bnRcbiAgfSA9IHVzZVVubW91bnRBZnRlckNsb3NlKHtcbiAgICBvcGVuLFxuICAgIHJlZjogcG9wdXBSZWYsXG4gICAgcHJldmVudFVubW91bnRPbkNsb3NlLFxuICAgIHNldFByZXZlbnRVbm1vdW50T25DbG9zZSxcbiAgICBvblVubW91bnQoKSB7XG4gICAgICBzdG9yZS51cGRhdGUoe1xuICAgICAgICBhY3RpdmVJbmRleDogbnVsbCxcbiAgICAgICAgb3Blbk1ldGhvZDogbnVsbCxcbiAgICAgICAgc2Nyb2xsVXBBcnJvd1Zpc2libGU6IGZhbHNlLFxuICAgICAgICBzY3JvbGxEb3duQXJyb3dWaXNpYmxlOiBmYWxzZVxuICAgICAgfSk7XG4gICAgICBvbk9wZW5DaGFuZ2VDb21wbGV0ZT8uKGZhbHNlKTtcbiAgICB9XG4gIH0pO1xuICBjb25zdCBhY3RpdmVJbmRleCA9IHN0b3JlLnVzZVN0YXRlKCdhY3RpdmVJbmRleCcpO1xuICBjb25zdCBzZWxlY3RlZEluZGV4ID0gc3RvcmUudXNlU3RhdGUoJ3NlbGVjdGVkSW5kZXgnKTtcbiAgY29uc3QgdHJpZ2dlckVsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZSgndHJpZ2dlckVsZW1lbnQnKTtcbiAgY29uc3QgcG9zaXRpb25lckVsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZSgncG9zaXRpb25lckVsZW1lbnQnKTtcbiAgY29uc3QgcHJldmlvdXNPcGVuTWV0aG9kID0gdXNlUHJldmlvdXNWYWx1ZShvcGVuTWV0aG9kKTtcbiAgY29uc3QgcmVuZGVyZWRPcGVuTWV0aG9kID0gb3Blbk1ldGhvZCA/PyBwcmV2aW91c09wZW5NZXRob2Q7XG4gIGNvbnN0IHNlcmlhbGl6ZWRWYWx1ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIC8vIEluIG11bHRpcGxlIG1vZGUgdGhlIHNoYXJlZCBpbnB1dCBpcyBuYW1lbGVzczsgcGVyLXZhbHVlIGVudHJpZXMgYXJlIHN1Ym1pdHRlZCB2aWFcbiAgICAvLyBgaGlkZGVuSW5wdXRzYC4gSXRzIHZhbHVlIGlzIHRoZXJlZm9yZSBpcnJlbGV2YW50LCBhbmQgcGFzc2luZyB0aGUgd2hvbGUgYXJyYXkgdG9cbiAgICAvLyBgc3RyaW5naWZ5QXNWYWx1ZWAgd291bGQgaW52b2tlIGEgdXNlciBgaXRlbVRvU3RyaW5nVmFsdWVgIHdpdGggYW4gYXJyYXkgaXQgZG9lc24ndCBleHBlY3QuXG4gICAgaWYgKG11bHRpcGxlKSB7XG4gICAgICByZXR1cm4gJyc7XG4gICAgfVxuICAgIHJldHVybiBzdHJpbmdpZnlBc1ZhbHVlKHZhbHVlLCBpdGVtVG9TdHJpbmdWYWx1ZSk7XG4gIH0sIFttdWx0aXBsZSwgdmFsdWUsIGl0ZW1Ub1N0cmluZ1ZhbHVlXSk7XG4gIGNvbnN0IGZpZWxkU3RyaW5nVmFsdWUgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBpZiAobXVsdGlwbGUgJiYgQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgIHJldHVybiB2YWx1ZS5tYXAoY3VycmVudFZhbHVlID0+IHN0cmluZ2lmeUFzVmFsdWUoY3VycmVudFZhbHVlLCBpdGVtVG9TdHJpbmdWYWx1ZSkpO1xuICAgIH1cbiAgICByZXR1cm4gc3RyaW5naWZ5QXNWYWx1ZSh2YWx1ZSwgaXRlbVRvU3RyaW5nVmFsdWUpO1xuICB9LCBbbXVsdGlwbGUsIHZhbHVlLCBpdGVtVG9TdHJpbmdWYWx1ZV0pO1xuICBjb25zdCBjb250cm9sUmVmID0gdXNlVmFsdWVBc1JlZih0cmlnZ2VyRWxlbWVudCk7XG4gIGNvbnN0IGdldFN0cmluZ2lmaWVkVmFsdWVGb3JGb3JtID0gdXNlU3RhYmxlQ2FsbGJhY2soKCkgPT4gZmllbGRTdHJpbmdWYWx1ZSk7XG4gIHVzZVJlZ2lzdGVyRmllbGRDb250cm9sKGNvbnRyb2xSZWYsIGdlbmVyYXRlZElkLCB2YWx1ZSwgZ2V0U3RyaW5naWZpZWRWYWx1ZUZvckZvcm0sICFkaXNhYmxlZCwgbmFtZVByb3ApO1xuXG4gIC8vIE1pcnJvciB0aGUgYGhhc1NlbGVjdGVkVmFsdWVgIHN0b3JlIHNlbGVjdG9yIHNvIHRoZSBGaWVsZCdzIGZpbGxlZCBzdGF0ZSBhZ3JlZXMgd2l0aCB0aGVcbiAgLy8gdHJpZ2dlci92YWx1ZSBwbGFjZWhvbGRlciBzZW1hbnRpY3MgKGEgdmFsdWUgc2VyaWFsaXppbmcgdG8gYCcnYCBjb3VudHMgYXMgZW1wdHkpLlxuICBjb25zdCBoYXNTZWxlY3RlZFZhbHVlID0gbXVsdGlwbGUgPyBBcnJheS5pc0FycmF5KHZhbHVlKSAmJiB2YWx1ZS5sZW5ndGggPiAwIDogdmFsdWUgIT0gbnVsbCAmJiBzZXJpYWxpemVkVmFsdWUgIT09ICcnO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIHNldEZpbGxlZChoYXNTZWxlY3RlZFZhbHVlKTtcbiAgfSwgW2hhc1NlbGVjdGVkVmFsdWUsIHNldEZpbGxlZF0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoZnVuY3Rpb24gc3luY1NlbGVjdGVkSW5kZXgoKSB7XG4gICAgY29uc3QgbmV4dEluZGV4ID0gZmluZFNlbGVjdGlvbkluZGV4KHZhbHVlc1JlZi5jdXJyZW50LCB2YWx1ZSwgaXNJdGVtRXF1YWxUb1ZhbHVlLCBtdWx0aXBsZSk7XG4gICAgaWYgKG5leHRJbmRleCA9PT0gbnVsbCkge1xuICAgICAgc2VsZWN0ZWRJdGVtVGV4dFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgaWYgKG9wZW4pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc3RvcmUuc2V0KCdzZWxlY3RlZEluZGV4JywgbmV4dEluZGV4KTtcbiAgfSwgW211bHRpcGxlLCBvcGVuLCB2YWx1ZSwgaXNJdGVtRXF1YWxUb1ZhbHVlLCBzdG9yZV0pO1xuICB1c2VWYWx1ZUNoYW5nZWQodmFsdWUsICgpID0+IHtcbiAgICBjbGVhckVycm9ycyhuYW1lKTtcbiAgICBzZXREaXJ0eShpc1NlbGVjdGVkVmFsdWVEaXJ0eSh2YWx1ZSwgdmFsaWRpdHlEYXRhLmluaXRpYWxWYWx1ZSwgaXNJdGVtRXF1YWxUb1ZhbHVlKSk7XG4gICAgdmFsaWRhdGlvbi5jaGFuZ2UodmFsdWUpO1xuICB9KTtcbiAgY29uc3Qgc2V0T3BlbiA9IHVzZVN0YWJsZUNhbGxiYWNrKChuZXh0T3BlbiwgZXZlbnREZXRhaWxzKSA9PiB7XG4gICAgY29uc3Qgb3BlbkV2ZW50RGV0YWlscyA9IGV2ZW50RGV0YWlscztcbiAgICBjb25zdCBzaG91bGRQcmV2ZW50VW5tb3VudE9uQ2xvc2UgPSBhdHRhY2hQcmV2ZW50VW5tb3VudE9uQ2xvc2Uob3BlbkV2ZW50RGV0YWlscyk7XG4gICAgb25PcGVuQ2hhbmdlPy4obmV4dE9wZW4sIG9wZW5FdmVudERldGFpbHMpO1xuICAgIGlmIChldmVudERldGFpbHMuaXNDYW5jZWxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoIW5leHRPcGVuKSB7XG4gICAgICBzZXRQcmV2ZW50VW5tb3VudE9uQ2xvc2Uoc2hvdWxkUHJldmVudFVubW91bnRPbkNsb3NlKCkpO1xuICAgIH1cbiAgICBzZXRPcGVuVW53cmFwcGVkKG5leHRPcGVuKTtcbiAgICBpZiAoIW5leHRPcGVuICYmIChldmVudERldGFpbHMucmVhc29uID09PSBSRUFTT05TLmZvY3VzT3V0IHx8IGV2ZW50RGV0YWlscy5yZWFzb24gPT09IFJFQVNPTlMub3V0c2lkZVByZXNzKSkge1xuICAgICAgc2V0VG91Y2hlZCh0cnVlKTtcbiAgICAgIHNldEZvY3VzZWQoZmFsc2UpO1xuICAgICAgaWYgKHZhbGlkYXRpb25Nb2RlID09PSAnb25CbHVyJykge1xuICAgICAgICB2YWxpZGF0aW9uLmNvbW1pdCh2YWx1ZSk7XG4gICAgICB9XG4gICAgfVxuICB9KTtcbiAgUmVhY3QudXNlSW1wZXJhdGl2ZUhhbmRsZShhY3Rpb25zUmVmLCAoKSA9PiAoe1xuICAgIHVubW91bnQ6IGhhbmRsZVVubW91bnQsXG4gICAgY2xvc2U6ICgpID0+IHtcbiAgICAgIGlmIChzdG9yZS5zdGF0ZS5vcGVuKSB7XG4gICAgICAgIHNldE9wZW4oZmFsc2UsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLmltcGVyYXRpdmVBY3Rpb24pKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pLCBbaGFuZGxlVW5tb3VudCwgc2V0T3Blbiwgc3RvcmVdKTtcbiAgY29uc3Qgc2V0VmFsdWUgPSB1c2VTdGFibGVDYWxsYmFjaygobmV4dFZhbHVlLCBldmVudERldGFpbHMpID0+IHtcbiAgICBvblZhbHVlQ2hhbmdlPy4obmV4dFZhbHVlLCBldmVudERldGFpbHMpO1xuICAgIGlmIChldmVudERldGFpbHMuaXNDYW5jZWxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzZXRWYWx1ZVVud3JhcHBlZChuZXh0VmFsdWUpO1xuICB9KTtcbiAgY29uc3QgaGFuZGxlU2Nyb2xsQXJyb3dWaXNpYmlsaXR5ID0gdXNlU3RhYmxlQ2FsbGJhY2soc2Nyb2xsZXIgPT4ge1xuICAgIGNvbnN0IG1heFNjcm9sbFRvcCA9IGdldE1heFNjcm9sbE9mZnNldChzY3JvbGxlci5zY3JvbGxIZWlnaHQsIHNjcm9sbGVyLmNsaWVudEhlaWdodCk7XG4gICAgY29uc3Qgc2Nyb2xsVG9wID0gbm9ybWFsaXplU2Nyb2xsT2Zmc2V0KHNjcm9sbGVyLnNjcm9sbFRvcCwgbWF4U2Nyb2xsVG9wKTtcbiAgICBjb25zdCBzaG91bGRTaG93VXAgPSBzY3JvbGxUb3AgPiAwO1xuICAgIGNvbnN0IHNob3VsZFNob3dEb3duID0gc2Nyb2xsVG9wIDwgbWF4U2Nyb2xsVG9wO1xuICAgIHN0b3JlLnNldCgnc2Nyb2xsVXBBcnJvd1Zpc2libGUnLCBzaG91bGRTaG93VXApO1xuICAgIHN0b3JlLnNldCgnc2Nyb2xsRG93bkFycm93VmlzaWJsZScsIHNob3VsZFNob3dEb3duKTtcbiAgfSk7XG4gIGNvbnN0IGZsb2F0aW5nQ29udGV4dCA9IHVzZUZsb2F0aW5nUm9vdENvbnRleHQoe1xuICAgIG9wZW4sXG4gICAgb25PcGVuQ2hhbmdlOiBzZXRPcGVuLFxuICAgIGVsZW1lbnRzOiB7XG4gICAgICByZWZlcmVuY2U6IHRyaWdnZXJFbGVtZW50LFxuICAgICAgZmxvYXRpbmc6IHBvc2l0aW9uZXJFbGVtZW50XG4gICAgfVxuICB9KTtcblxuICAvLyBgcmVhZE9ubHlgIGxvY2tzIHRoZSB2YWx1ZSwgbm90IHRoZSBpbnRlcmFjdGlvbjogdGhlIHBvcHVwIGNhbiBiZSBvcGVuZWQgYW5kIGJyb3dzZWQgc28gdGhlXG4gIC8vIHVzZXIgY2FuIHNlZSB0aGUgYXZhaWxhYmxlIG9wdGlvbnMgYW5kIHdoaWNoIG9uZSBpcyBzZWxlY3RlZC4gQ29tbWl0dGluZyBhIHZhbHVlIGlzIGJsb2NrZWRcbiAgLy8gc2VwYXJhdGVseSBpbiBgU2VsZWN0SXRlbWAgYW5kIGluIHRoZSBoaWRkZW4gaW5wdXQncyBhdXRvZmlsbCBoYW5kbGVyLlxuICBjb25zdCBjbGljayA9IHVzZUNsaWNrKGZsb2F0aW5nQ29udGV4dCwge1xuICAgIGVuYWJsZWQ6ICFkaXNhYmxlZCxcbiAgICBldmVudDogJ21vdXNlZG93bidcbiAgfSk7XG4gIGNvbnN0IGRpc21pc3MgPSB1c2VEaXNtaXNzKGZsb2F0aW5nQ29udGV4dCk7XG4gIGNvbnN0IGxpc3ROYXZpZ2F0aW9uID0gdXNlTGlzdE5hdmlnYXRpb24oZmxvYXRpbmdDb250ZXh0LCB7XG4gICAgZW5hYmxlZDogIWRpc2FibGVkLFxuICAgIGxpc3RSZWYsXG4gICAgYWN0aXZlSW5kZXgsXG4gICAgc2VsZWN0ZWRJbmRleCxcbiAgICBkaXNhYmxlZEluZGljZXM6IEVNUFRZX0FSUkFZLFxuICAgIG9uTmF2aWdhdGUobmV4dEFjdGl2ZUluZGV4KSB7XG4gICAgICAvLyBSZXRhaW4gdGhlIGhpZ2hsaWdodCB3aGlsZSB0cmFuc2l0aW9uaW5nIG91dC5cbiAgICAgIGlmIChuZXh0QWN0aXZlSW5kZXggPT09IG51bGwgJiYgIW9wZW4pIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgc3RvcmUuc2V0KCdhY3RpdmVJbmRleCcsIG5leHRBY3RpdmVJbmRleCk7XG4gICAgfSxcbiAgICBmb2N1c0l0ZW1PbkhvdmVyOiBoaWdobGlnaHRJdGVtT25Ib3ZlclxuICB9KTtcbiAgY29uc3QgdHlwZWFoZWFkID0gdXNlVHlwZWFoZWFkKGZsb2F0aW5nQ29udGV4dCwge1xuICAgIC8vIFR5cGVhaGVhZCBvbiBhbiBvcGVuIHBvcHVwIG9ubHkgbW92ZXMgdGhlIGhpZ2hsaWdodCwgc28gaXQgcmVtYWlucyBhdmFpbGFibGUgd2hpbGVcbiAgICAvLyBgcmVhZE9ubHlgLiBUaGUgY2xvc2VkLXRyaWdnZXIgdmFyaWFudCBjb21taXRzIGEgdmFsdWUgaW5zdGVhZCwgc28gaXQgZG9lc24ndC5cbiAgICBlbmFibGVkOiAhZGlzYWJsZWQgJiYgKG9wZW4gfHwgIXJlYWRPbmx5ICYmICFtdWx0aXBsZSksXG4gICAgbGlzdFJlZjogbGFiZWxzUmVmLFxuICAgIGFjdGl2ZUluZGV4LFxuICAgIHNlbGVjdGVkSW5kZXgsXG4gICAgLy8gU2tpcCBkaXNhYmxlZCBpdGVtcyB3aGlsZSBtYXRjaGluZyBzbyB0eXBlYWhlYWQgYWR2YW5jZXMgdG8gdGhlIG5leHQgc2VsZWN0YWJsZSBpdGVtXG4gICAgLy8gKGEgY2xpY2sgY2FuIG5ldmVyIHNlbGVjdCBhIGRpc2FibGVkIGl0ZW0gYW5kIG5hdGl2ZSBgPHNlbGVjdD5gIHNraXBzIHRoZW0gdG9vKS4gUmVzb2x2ZVxuICAgIC8vIHRoZSBkaXNhYmxlZCBzdGF0ZSBmcm9tIHRoZSBlbGVtZW50IHZpYSB0aGUgYXR0cmlidXRlLW9ubHkgYGlzRWxlbWVudERpc2FibGVkYCBzbyB0aGVcbiAgICAvLyBoaWRkZW4sIGZvcmNlLW1vdW50ZWQgaXRlbXMgdXNlZCBmb3IgY2xvc2VkLXRyaWdnZXIgdHlwZWFoZWFkIGFyZW4ndCBkcm9wcGVkIGJ5IHRoZVxuICAgIC8vIGBlbGVtZW50c1JlZmAvdmlzaWJpbGl0eSBmaWx0ZXIgdGhhdCBgZGlzYWJsZWRJbmRpY2VzYCBkZWxpYmVyYXRlbHkgc2lkZXN0ZXBzLlxuICAgIGRpc2FibGVkSW5kaWNlczogaW5kZXggPT4gaXNFbGVtZW50RGlzYWJsZWQobGlzdFJlZi5jdXJyZW50W2luZGV4XSksXG4gICAgb25NYXRjaChpbmRleCkge1xuICAgICAgaWYgKG9wZW4pIHtcbiAgICAgICAgc3RvcmUuc2V0KCdhY3RpdmVJbmRleCcsIGluZGV4KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHNldFZhbHVlKHZhbHVlc1JlZi5jdXJyZW50W2luZGV4XSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMubm9uZSkpO1xuICAgICAgfVxuICAgIH0sXG4gICAgb25UeXBpbmcodHlwaW5nKSB7XG4gICAgICB0eXBpbmdSZWYuY3VycmVudCA9IHR5cGluZztcbiAgICB9XG4gIH0pO1xuXG4gIC8vIGBTZWxlY3QuVHJpZ2dlcmAgYXBwbGllcyB0aGUgaWQgaXRzZWxmIGZyb20gdGhlIHN0b3JlLCBzbyBpdCdzIGRlbGliZXJhdGVseSBub3QgbWVyZ2VkIGhlcmUuXG4gIGNvbnN0IG1lcmdlZFRyaWdnZXJQcm9wcyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gbWVyZ2VQcm9wcyh0eXBlYWhlYWQucmVmZXJlbmNlLCBsaXN0TmF2aWdhdGlvbi5yZWZlcmVuY2UsIGRpc21pc3MucmVmZXJlbmNlLCBjbGljay5yZWZlcmVuY2UsIGludGVyYWN0aW9uVHlwZVByb3BzKSwgW2NsaWNrLnJlZmVyZW5jZSwgdHlwZWFoZWFkLnJlZmVyZW5jZSwgbGlzdE5hdmlnYXRpb24ucmVmZXJlbmNlLCBkaXNtaXNzLnJlZmVyZW5jZSwgaW50ZXJhY3Rpb25UeXBlUHJvcHNdKTtcbiAgY29uc3QgcG9wdXBQcm9wcyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gbWVyZ2VQcm9wcyhGT0NVU0FCTEVfUE9QVVBfUFJPUFMsIHR5cGVhaGVhZC5mbG9hdGluZywgbGlzdE5hdmlnYXRpb24uZmxvYXRpbmcsIGRpc21pc3MuZmxvYXRpbmcpLCBbdHlwZWFoZWFkLmZsb2F0aW5nLCBsaXN0TmF2aWdhdGlvbi5mbG9hdGluZywgZGlzbWlzcy5mbG9hdGluZ10pO1xuICBjb25zdCBpdGVtUHJvcHMgPSBsaXN0TmF2aWdhdGlvbi5pdGVtID8/IEVNUFRZX09CSkVDVDtcbiAgY29uc3QgaXRlbVJvb3QgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgcHJvcHM6IGl0ZW1Qcm9wcyxcbiAgICBtdWx0aXBsZSxcbiAgICBkaXNhYmxlZCxcbiAgICByZWFkT25seSxcbiAgICBpc0l0ZW1FcXVhbFRvVmFsdWVcbiAgfSksIFtpdGVtUHJvcHMsIG11bHRpcGxlLCBkaXNhYmxlZCwgcmVhZE9ubHksIGlzSXRlbUVxdWFsVG9WYWx1ZV0pO1xuICBzdG9yZS51c2VDb250ZXh0Q2FsbGJhY2soJ3NldFZhbHVlJywgc2V0VmFsdWUpO1xuICBzdG9yZS51c2VDb250ZXh0Q2FsbGJhY2soJ3NldE9wZW4nLCBzZXRPcGVuKTtcbiAgc3RvcmUudXNlQ29udGV4dENhbGxiYWNrKCdoYW5kbGVTY3JvbGxBcnJvd1Zpc2liaWxpdHknLCBoYW5kbGVTY3JvbGxBcnJvd1Zpc2liaWxpdHkpO1xuICBzdG9yZS51c2VDb250ZXh0Q2FsbGJhY2soJ29uT3BlbkNoYW5nZUNvbXBsZXRlJywgb25PcGVuQ2hhbmdlQ29tcGxldGUpO1xuXG4gIC8vIFRoZSBwcm9wIGJhZ3MgbXVzdCBiZSBpbiB0aGUgc3RvcmUgYmVmb3JlIHRoZSBwYXJ0cyByZW5kZXIuIGB1c2VTeW5jZWRWYWx1ZXNgIHdyaXRlcyBpbiBhXG4gIC8vIGxheW91dCBlZmZlY3QsIGFmdGVyIGFsbCBkZXNjZW5kYW50cyBoYXZlIHJlbmRlcmVkLlxuICB1c2VPbkZpcnN0UmVuZGVyKCgpID0+IHtcbiAgICBzdG9yZS51cGRhdGUoe1xuICAgICAgcG9wdXBQcm9wcyxcbiAgICAgIHRyaWdnZXJQcm9wczogbWVyZ2VkVHJpZ2dlclByb3BzLFxuICAgICAgaXRlbVJvb3RcbiAgICB9KTtcbiAgfSk7XG4gIHN0b3JlLnVzZVN5bmNlZFZhbHVlcyh7XG4gICAgaWQ6IGdlbmVyYXRlZElkLFxuICAgIG1vZGFsLFxuICAgIG11bHRpcGxlLFxuICAgIGRpc2FibGVkLFxuICAgIHJlYWRPbmx5LFxuICAgIHJlcXVpcmVkLFxuICAgIGhpZ2hsaWdodEl0ZW1PbkhvdmVyLFxuICAgIHZhbHVlLFxuICAgIG9wZW4sXG4gICAgbW91bnRlZCxcbiAgICB0cmFuc2l0aW9uU3RhdHVzLFxuICAgIHBvcHVwUHJvcHMsXG4gICAgdHJpZ2dlclByb3BzOiBtZXJnZWRUcmlnZ2VyUHJvcHMsXG4gICAgaXRlbVJvb3QsXG4gICAgaXRlbXMsXG4gICAgaXRlbVRvU3RyaW5nTGFiZWwsXG4gICAgaXRlbVRvU3RyaW5nVmFsdWUsXG4gICAgaXNJdGVtRXF1YWxUb1ZhbHVlLFxuICAgIG9wZW5NZXRob2Q6IHJlbmRlcmVkT3Blbk1ldGhvZFxuICB9KTtcbiAgY29uc3QgcmVmID0gdXNlTWVyZ2VkUmVmcyhpbnB1dFJlZiwgdmFsaWRhdGlvbi5pbnB1dFJlZik7XG4gIGNvbnN0IGhpZGRlbklucHV0TmFtZSA9IG11bHRpcGxlID8gdW5kZWZpbmVkIDogbmFtZTtcbiAgY29uc3QgaGlkZGVuSW5wdXRzID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgaWYgKCFtdWx0aXBsZSB8fCAhQXJyYXkuaXNBcnJheSh2YWx1ZSkgfHwgIW5hbWUpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWUubWFwKHYgPT4ge1xuICAgICAgY29uc3QgY3VycmVudFNlcmlhbGl6ZWRWYWx1ZSA9IHN0cmluZ2lmeUFzVmFsdWUodiwgaXRlbVRvU3RyaW5nVmFsdWUpO1xuICAgICAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KFwiaW5wdXRcIiwge1xuICAgICAgICB0eXBlOiBcImhpZGRlblwiLFxuICAgICAgICBmb3JtOiBmb3JtLFxuICAgICAgICBuYW1lOiBuYW1lLFxuICAgICAgICB2YWx1ZTogY3VycmVudFNlcmlhbGl6ZWRWYWx1ZSxcbiAgICAgICAgZGlzYWJsZWQ6IGRpc2FibGVkXG4gICAgICB9LCBjdXJyZW50U2VyaWFsaXplZFZhbHVlKTtcbiAgICB9KTtcbiAgfSwgW211bHRpcGxlLCB2YWx1ZSwgZm9ybSwgbmFtZSwgaXRlbVRvU3RyaW5nVmFsdWUsIGRpc2FibGVkXSk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeHMoU2VsZWN0Um9vdENvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogc3RvcmUsXG4gICAgY2hpbGRyZW46IFsvKiNfX1BVUkVfXyovX2pzeChTZWxlY3RGbG9hdGluZ0NvbnRleHQuUHJvdmlkZXIsIHtcbiAgICAgIHZhbHVlOiBmbG9hdGluZ0NvbnRleHQsXG4gICAgICBjaGlsZHJlbjogY2hpbGRyZW5cbiAgICB9KSwgLyojX19QVVJFX18qL19qc3goXCJpbnB1dFwiLCB7XG4gICAgICAuLi52YWxpZGF0aW9uLmdldFZhbGlkYXRpb25Qcm9wcyhkaXNhYmxlZCwge1xuICAgICAgICBvbkZvY3VzKCkge1xuICAgICAgICAgIC8vIE1vdmUgZm9jdXMgdG8gdGhlIHRyaWdnZXIgZWxlbWVudCB3aGVuIHRoZSBoaWRkZW4gaW5wdXQgaXMgZm9jdXNlZC5cbiAgICAgICAgICBzdG9yZS5zdGF0ZS50cmlnZ2VyRWxlbWVudD8uZm9jdXMoe1xuICAgICAgICAgICAgLy8gU3VwcG9ydGVkIGluIENocm9tZSBmcm9tIDE0NCAoSmFudWFyeSAyMDI2KVxuICAgICAgICAgICAgZm9jdXNWaXNpYmxlOiB0cnVlXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgIC8vIEhhbmRsZSBicm93c2VyIGF1dG9maWxsLlxuICAgICAgICBvbkNoYW5nZShldmVudCkge1xuICAgICAgICAgIC8vIFdvcmthcm91bmQgZm9yIGh0dHBzOi8vZ2l0aHViLmNvbS9yZWFjdC9yZWFjdC9pc3N1ZXMvOTAyM1xuICAgICAgICAgIGlmIChldmVudC5uYXRpdmVFdmVudC5kZWZhdWx0UHJldmVudGVkIHx8IGRpc2FibGVkIHx8IHJlYWRPbmx5KSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IG5leHRWYWx1ZSA9IGV2ZW50LmN1cnJlbnRUYXJnZXQudmFsdWU7XG4gICAgICAgICAgY29uc3QgZGV0YWlscyA9IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLm5vbmUsIGV2ZW50Lm5hdGl2ZUV2ZW50KTtcbiAgICAgICAgICBmdW5jdGlvbiBoYW5kbGVDaGFuZ2UoKSB7XG4gICAgICAgICAgICBpZiAobXVsdGlwbGUpIHtcbiAgICAgICAgICAgICAgLy8gQnJvd3NlciBhdXRvZmlsbCBvbmx5IHdyaXRlcyBhIHNpbmdsZSBzY2FsYXIgdmFsdWUuXG4gICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gUHJlc2VydmUgdGhlIG9yaWdpbmFsIHNlcmlhbGl6ZWQgbWF0Y2hpbmcsIHRoZW4gZmFsbCBiYWNrIHRvIHJlbmRlcmVkIHRleHQsXG4gICAgICAgICAgICAvLyB3aGljaCBicm93c2VycyBjYW4gYXV0b2ZpbGwgZm9yIHByaW1pdGl2ZSB2YWx1ZXMgbGlrZVxuICAgICAgICAgICAgLy8gYHZhbHVlPVwiVVNcIj5Vbml0ZWQgU3RhdGVzYC5cbiAgICAgICAgICAgIGNvbnN0IG5leHRWYWx1ZUxvd2VyID0gbmV4dFZhbHVlLnRvTG93ZXJDYXNlKCk7XG4gICAgICAgICAgICBsZXQgbWF0Y2hpbmdJbmRleCA9IHZhbHVlc1JlZi5jdXJyZW50LmZpbmRJbmRleChjYW5kaWRhdGUgPT4gc3RyaW5naWZ5QXNWYWx1ZShjYW5kaWRhdGUsIGl0ZW1Ub1N0cmluZ1ZhbHVlKS50b0xvd2VyQ2FzZSgpID09PSBuZXh0VmFsdWVMb3dlciB8fCBzdHJpbmdpZnlBc0xhYmVsKGNhbmRpZGF0ZSwgaXRlbVRvU3RyaW5nTGFiZWwpLnRvTG93ZXJDYXNlKCkgPT09IG5leHRWYWx1ZUxvd2VyKTtcbiAgICAgICAgICAgIGlmIChtYXRjaGluZ0luZGV4ID09PSAtMSkge1xuICAgICAgICAgICAgICBtYXRjaGluZ0luZGV4ID0gdmFsdWVzUmVmLmN1cnJlbnQuZmluZEluZGV4KChfLCBpbmRleCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IHJlbmRlcmVkTGFiZWwgPSBsYWJlbHNSZWYuY3VycmVudFtpbmRleF07XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlbmRlcmVkTGFiZWwgIT0gbnVsbCAmJiByZW5kZXJlZExhYmVsLnRvTG93ZXJDYXNlKCkgPT09IG5leHRWYWx1ZUxvd2VyO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IG1hdGNoaW5nVmFsdWUgPSB2YWx1ZXNSZWYuY3VycmVudFttYXRjaGluZ0luZGV4XTtcbiAgICAgICAgICAgIGlmIChtYXRjaGluZ1ZhbHVlICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgLy8gYHNldFZhbHVlYCBtYXkgYmUgY2FuY2VsZWQgYnkgYG9uVmFsdWVDaGFuZ2VgOyByZWx5IG9uIGB1c2VWYWx1ZUNoYW5nZWRgIHRvXG4gICAgICAgICAgICAgIC8vIG1hcmsgdGhlIGZpZWxkIGRpcnR5IGFuZCBydW4gdmFsaWRhdGlvbiBvbmx5IHdoZW4gdGhlIHZhbHVlIGFjdHVhbGx5IGNoYW5nZXMuXG4gICAgICAgICAgICAgIHNldFZhbHVlKG1hdGNoaW5nVmFsdWUsIGRldGFpbHMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBzdG9yZS5zZXQoJ2ZvcmNlTW91bnQnLCB0cnVlKTtcbiAgICAgICAgICBxdWV1ZU1pY3JvdGFzayhoYW5kbGVDaGFuZ2UpO1xuICAgICAgICB9XG4gICAgICB9KSxcbiAgICAgIGlkOiBnZW5lcmF0ZWRJZCAmJiBoaWRkZW5JbnB1dE5hbWUgPT0gbnVsbCA/IGAke2dlbmVyYXRlZElkfS1oaWRkZW4taW5wdXRgIDogdW5kZWZpbmVkLFxuICAgICAgZm9ybTogZm9ybSxcbiAgICAgIG5hbWU6IGhpZGRlbklucHV0TmFtZSxcbiAgICAgIGF1dG9Db21wbGV0ZTogYXV0b0NvbXBsZXRlLFxuICAgICAgdmFsdWU6IHNlcmlhbGl6ZWRWYWx1ZSxcbiAgICAgIGRpc2FibGVkOiBkaXNhYmxlZCxcbiAgICAgIHJlcXVpcmVkOiByZXF1aXJlZCAmJiAhKG11bHRpcGxlICYmIGhhc1NlbGVjdGVkVmFsdWUpLFxuICAgICAgcmVhZE9ubHk6IHJlYWRPbmx5LFxuICAgICAgcmVmOiByZWYsXG4gICAgICBzdHlsZTogbmFtZSA/IHZpc3VhbGx5SGlkZGVuSW5wdXQgOiB2aXN1YWxseUhpZGRlbixcbiAgICAgIHRhYkluZGV4OiAtMSxcbiAgICAgIFwiYXJpYS1oaWRkZW5cIjogdHJ1ZSxcbiAgICAgIHN1cHByZXNzSHlkcmF0aW9uV2FybmluZzogdHJ1ZVxuICAgIH0pLCBoaWRkZW5JbnB1dHNdXG4gIH0pO1xufSIsIid1c2UgY2xpZW50JztcblxuZXhwb3J0IGZ1bmN0aW9uIGdldERlZmF1bHRMYWJlbElkKGlkKSB7XG4gIHJldHVybiBpZCA9PSBudWxsID8gdW5kZWZpbmVkIDogYCR7aWR9LWxhYmVsYDtcbn1cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlQXJpYUxhYmVsbGVkQnkoZmllbGRMYWJlbElkLCBsb2NhbExhYmVsSWQpIHtcbiAgcmV0dXJuIGZpZWxkTGFiZWxJZCA/PyBsb2NhbExhYmVsSWQ7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlRmllbGRSb290Q29udGV4dCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvZmllbGQtcm9vdC1jb250ZXh0L0ZpZWxkUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBmaWVsZFZhbGlkaXR5TWFwcGluZyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvZmllbGQtY29uc3RhbnRzL2NvbnN0YW50cy5tanNcIjtcbmltcG9ydCB7IHVzZUxhYmVsIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9sYWJlbGFibGUtcHJvdmlkZXIvdXNlTGFiZWwubWpzXCI7XG5pbXBvcnQgeyBnZXREZWZhdWx0TGFiZWxJZCB9IGZyb20gXCIuLi8uLi91dGlscy9yZXNvbHZlQXJpYUxhYmVsbGVkQnkubWpzXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L1NlbGVjdFJvb3RDb250ZXh0Lm1qc1wiO1xuXG4vKipcbiAqIEFuIGFjY2Vzc2libGUgbGFiZWwgdGhhdCBpcyBhdXRvbWF0aWNhbGx5IGFzc29jaWF0ZWQgd2l0aCB0aGUgc2VsZWN0IHRyaWdnZXIuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIFNlbGVjdF0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL3NlbGVjdClcbiAqL1xuZXhwb3J0IGNvbnN0IFNlbGVjdExhYmVsID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gU2VsZWN0TGFiZWwoY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIGNsYXNzTmFtZSxcbiAgICBzdHlsZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICAvLyBLZWVwIGxhYmVsIGlkIGRlcml2ZWQgZnJvbSB0aGUgcm9vdCBhbmQgaWdub3JlIHJ1bnRpbWUgYGlkYCBvdmVycmlkZXMgZnJvbSB1bnR5cGVkIGNvbnN1bWVycy5cbiAgY29uc3QgZWxlbWVudFByb3BzV2l0aG91dElkID0gZWxlbWVudFByb3BzO1xuICBkZWxldGUgZWxlbWVudFByb3BzV2l0aG91dElkLmlkO1xuICBjb25zdCBmaWVsZFJvb3RDb250ZXh0ID0gdXNlRmllbGRSb290Q29udGV4dCgpO1xuICBjb25zdCBzdG9yZSA9IHVzZVNlbGVjdFJvb3RDb250ZXh0KCk7XG4gIGNvbnN0IHRyaWdnZXJFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ3RyaWdnZXJFbGVtZW50Jyk7XG4gIGNvbnN0IHJvb3RJZCA9IHN0b3JlLnVzZVN0YXRlKCdpZCcpO1xuICBjb25zdCBkZWZhdWx0TGFiZWxJZCA9IGdldERlZmF1bHRMYWJlbElkKHJvb3RJZCk7XG4gIGNvbnN0IGxhYmVsUHJvcHMgPSB1c2VMYWJlbCh7XG4gICAgaWQ6IGRlZmF1bHRMYWJlbElkLFxuICAgIGZhbGxiYWNrQ29udHJvbElkOiB0cmlnZ2VyRWxlbWVudD8uaWQgPz8gcm9vdElkLFxuICAgIHNldExhYmVsSWQobmV4dExhYmVsSWQpIHtcbiAgICAgIGNvbnN0IHJlc29sdmVkTGFiZWxJZCA9IHR5cGVvZiBuZXh0TGFiZWxJZCA9PT0gJ2Z1bmN0aW9uJyA/IG5leHRMYWJlbElkKHN0b3JlLnN0YXRlLmxhYmVsSWQpIDogbmV4dExhYmVsSWQ7XG4gICAgICBzdG9yZS5zZXQoJ2xhYmVsSWQnLCByZXNvbHZlZExhYmVsSWQpO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgIHN0YXRlOiBmaWVsZFJvb3RDb250ZXh0LnN0YXRlLFxuICAgIHByb3BzOiBbbGFiZWxQcm9wcywgZWxlbWVudFByb3BzXSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiBmaWVsZFZhbGlkaXR5TWFwcGluZ1xuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgU2VsZWN0TGFiZWwuZGlzcGxheU5hbWUgPSBcIlNlbGVjdExhYmVsXCI7IiwiaW1wb3J0IHsgQ29tbW9uVHJpZ2dlckRhdGFBdHRyaWJ1dGVzIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwU3RhdGVNYXBwaW5nLm1qc1wiO1xuXG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgY29ycmVzcG9uZGluZyBzZWxlY3QgaXMgb3Blbi5cbiAqL1xuZXhwb3J0IGNvbnN0IHBvcHVwT3BlbiA9IENvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcy5wb3B1cE9wZW47XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgdHJpZ2dlciBpcyBwcmVzc2VkLlxuICovXG5leHBvcnQgY29uc3QgcHJlc3NlZCA9IENvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcy5wcmVzc2VkO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHNlbGVjdCBpcyBkaXNhYmxlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGRpc2FibGVkID0gJ2RhdGEtZGlzYWJsZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHNlbGVjdCBpcyByZWFkb25seS5cbiAqL1xuZXhwb3J0IGNvbnN0IHJlYWRvbmx5ID0gJ2RhdGEtcmVhZG9ubHknO1xuLyoqXG4gKiBJbmRpY2F0ZXMgd2hpY2ggc2lkZSB0aGUgY29ycmVzcG9uZGluZyBwb3B1cCBpcyBwb3NpdGlvbmVkIHJlbGF0aXZlIHRvIGl0cyBhbmNob3IuXG4gKiBAdHlwZSB7J3RvcCcgfCAnYm90dG9tJyB8ICdsZWZ0JyB8ICdyaWdodCcgfCAnaW5saW5lLWVuZCcgfCAnaW5saW5lLXN0YXJ0JyB8IG51bGx9XG4gKi9cbmV4cG9ydCBjb25zdCBwb3B1cFNpZGUgPSAnZGF0YS1wb3B1cC1zaWRlJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzZWxlY3QgaXMgcmVxdWlyZWQuXG4gKi9cbmV4cG9ydCBjb25zdCByZXF1aXJlZCA9ICdkYXRhLXJlcXVpcmVkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzZWxlY3QgaXMgaW4gYSB2YWxpZCBzdGF0ZSAod2hlbiB3cmFwcGVkIGluIEZpZWxkLlJvb3QpLlxuICovXG5leHBvcnQgY29uc3QgdmFsaWQgPSAnZGF0YS12YWxpZCc7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgc2VsZWN0IGlzIGluIGFuIGludmFsaWQgc3RhdGUgKHdoZW4gd3JhcHBlZCBpbiBGaWVsZC5Sb290KS5cbiAqL1xuZXhwb3J0IGNvbnN0IGludmFsaWQgPSAnZGF0YS1pbnZhbGlkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzZWxlY3QgaGFzIGJlZW4gdG91Y2hlZCAod2hlbiB3cmFwcGVkIGluIEZpZWxkLlJvb3QpLlxuICovXG5leHBvcnQgY29uc3QgdG91Y2hlZCA9ICdkYXRhLXRvdWNoZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHNlbGVjdCdzIHZhbHVlIGhhcyBjaGFuZ2VkICh3aGVuIHdyYXBwZWQgaW4gRmllbGQuUm9vdCkuXG4gKi9cbmV4cG9ydCBjb25zdCBkaXJ0eSA9ICdkYXRhLWRpcnR5Jztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzZWxlY3QgaGFzIGEgdmFsdWUgKHdoZW4gd3JhcHBlZCBpbiBGaWVsZC5Sb290KS5cbiAqL1xuZXhwb3J0IGNvbnN0IGZpbGxlZCA9ICdkYXRhLWZpbGxlZCc7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgc2VsZWN0IHRyaWdnZXIgaXMgZm9jdXNlZCAod2hlbiB3cmFwcGVkIGluIEZpZWxkLlJvb3QpLlxuICovXG5leHBvcnQgY29uc3QgZm9jdXNlZCA9ICdkYXRhLWZvY3VzZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHNlbGVjdCBkb2Vzbid0IGhhdmUgYSB2YWx1ZS5cbiAqL1xuZXhwb3J0IGNvbnN0IHBsYWNlaG9sZGVyID0gJ2RhdGEtcGxhY2Vob2xkZXInOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgb3duZXJEb2N1bWVudCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL293bmVyJztcbmltcG9ydCB7IHVzZVRpbWVvdXQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VUaW1lb3V0JztcbmltcG9ydCB7IHVzZVZhbHVlQXNSZWYgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VWYWx1ZUFzUmVmJztcbmltcG9ydCB7IHVzZVNlbGVjdFJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvU2VsZWN0Um9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VGaWVsZFJvb3RDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9maWVsZC1yb290LWNvbnRleHQvRmllbGRSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVNldEZpZWxkRm9jdXNlZCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvZmllbGQtcm9vdC1jb250ZXh0L3VzZVNldEZpZWxkRm9jdXNlZC5tanNcIjtcbmltcG9ydCB7IHVzZUxhYmVsYWJsZUNvbnRleHQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2xhYmVsYWJsZS1wcm92aWRlci9MYWJlbGFibGVDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgcHJlc3NhYmxlVHJpZ2dlck9wZW5TdGF0ZU1hcHBpbmcgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5pbXBvcnQgeyBmaWVsZFZhbGlkaXR5TWFwcGluZyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvZmllbGQtY29uc3RhbnRzL2NvbnN0YW50cy5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBpc01vdXNlV2l0aGluQm91bmRzIH0gZnJvbSBcIi4uLy4uL3V0aWxzL2dldFBzZXVkb0VsZW1lbnRCb3VuZHMubWpzXCI7XG5pbXBvcnQgeyBjb250YWlucywgZ2V0RmxvYXRpbmdGb2N1c0VsZW1lbnQgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvdXRpbHMubWpzXCI7XG5pbXBvcnQgeyBtZXJnZVByb3BzIH0gZnJvbSBcIi4uLy4uL21lcmdlLXByb3BzL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQnV0dG9uIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2UtYnV0dG9uL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsgdXNlTGFiZWxhYmxlSWQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2xhYmVsYWJsZS1wcm92aWRlci91c2VMYWJlbGFibGVJZC5tanNcIjtcbmltcG9ydCB7IHJlc29sdmVBcmlhTGFiZWxsZWRCeSB9IGZyb20gXCIuLi8uLi91dGlscy9yZXNvbHZlQXJpYUxhYmVsbGVkQnkubWpzXCI7XG5pbXBvcnQgKiBhcyBTZWxlY3RUcmlnZ2VyRGF0YUF0dHJpYnV0ZXMgZnJvbSBcIi4vU2VsZWN0VHJpZ2dlckRhdGFBdHRyaWJ1dGVzLm1qc1wiO1xuY29uc3QgU0VMRUNURURfREVMQVkgPSA0MDA7XG5jb25zdCBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nID0ge1xuICAuLi5wcmVzc2FibGVUcmlnZ2VyT3BlblN0YXRlTWFwcGluZyxcbiAgLi4uZmllbGRWYWxpZGl0eU1hcHBpbmcsXG4gIHBvcHVwU2lkZTogc2lkZSA9PiBzaWRlID8ge1xuICAgIFtTZWxlY3RUcmlnZ2VyRGF0YUF0dHJpYnV0ZXMucG9wdXBTaWRlXTogc2lkZVxuICB9IDogbnVsbCxcbiAgdmFsdWU6ICgpID0+IG51bGxcbn07XG5cbi8qKlxuICogQSBidXR0b24gdGhhdCBvcGVucyB0aGUgc2VsZWN0IHBvcHVwLlxuICogUmVuZGVycyBhIGA8YnV0dG9uPmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBTZWxlY3RdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9zZWxlY3QpXG4gKi9cbmV4cG9ydCBjb25zdCBTZWxlY3RUcmlnZ2VyID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gU2VsZWN0VHJpZ2dlcihjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIGlkOiBpZFByb3AsXG4gICAgZGlzYWJsZWQ6IGRpc2FibGVkUHJvcCA9IGZhbHNlLFxuICAgIG5hdGl2ZUJ1dHRvbiA9IHRydWUsXG4gICAgc3R5bGUsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qge1xuICAgIHNldFRvdWNoZWQsXG4gICAgdmFsaWRhdGlvbk1vZGUsXG4gICAgdmFsaWRhdGlvbixcbiAgICBzdGF0ZTogZmllbGRTdGF0ZSxcbiAgICBkaXNhYmxlZDogZmllbGREaXNhYmxlZFxuICB9ID0gdXNlRmllbGRSb290Q29udGV4dCgpO1xuICBjb25zdCB7XG4gICAgbGFiZWxJZDogZmllbGRMYWJlbElkXG4gIH0gPSB1c2VMYWJlbGFibGVDb250ZXh0KCk7XG4gIGNvbnN0IHN0b3JlID0gdXNlU2VsZWN0Um9vdENvbnRleHQoKTtcbiAgY29uc3QgcmVhZE9ubHkgPSBzdG9yZS51c2VTdGF0ZSgncmVhZE9ubHknKTtcbiAgY29uc3QgcmVxdWlyZWQgPSBzdG9yZS51c2VTdGF0ZSgncmVxdWlyZWQnKTtcbiAgY29uc3Qgc2VsZWN0RGlzYWJsZWQgPSBzdG9yZS51c2VTdGF0ZSgnZGlzYWJsZWQnKTtcbiAgY29uc3QgZGlzYWJsZWQgPSBmaWVsZERpc2FibGVkIHx8IHNlbGVjdERpc2FibGVkIHx8IGRpc2FibGVkUHJvcDtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IG1vdW50ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbW91bnRlZCcpO1xuICBjb25zdCB2YWx1ZSA9IHN0b3JlLnVzZVN0YXRlKCd2YWx1ZScpO1xuICBjb25zdCB0cmlnZ2VyUHJvcHMgPSBzdG9yZS51c2VTdGF0ZSgndHJpZ2dlclByb3BzJyk7XG4gIGNvbnN0IHBvc2l0aW9uZXJFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ3Bvc2l0aW9uZXJFbGVtZW50Jyk7XG4gIGNvbnN0IGxpc3RFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ2xpc3RFbGVtZW50Jyk7XG4gIGNvbnN0IHBvcHVwU2lkZVZhbHVlID0gc3RvcmUudXNlU3RhdGUoJ3BvcHVwU2lkZScpO1xuICBjb25zdCByb290SWQgPSBzdG9yZS51c2VTdGF0ZSgnaWQnKTtcbiAgY29uc3Qgc2VsZWN0TGFiZWxJZCA9IHN0b3JlLnVzZVN0YXRlKCdsYWJlbElkJyk7XG4gIGNvbnN0IGhhc1NlbGVjdGVkVmFsdWUgPSBzdG9yZS51c2VTdGF0ZSgnaGFzU2VsZWN0ZWRWYWx1ZScpO1xuICBjb25zdCBwb3B1cFNpZGUgPSBtb3VudGVkICYmIHBvc2l0aW9uZXJFbGVtZW50ID8gcG9wdXBTaWRlVmFsdWUgOiBudWxsO1xuICBjb25zdCBpZCA9IGlkUHJvcCA/PyByb290SWQ7XG4gIGNvbnN0IGFyaWFMYWJlbGxlZEJ5ID0gcmVzb2x2ZUFyaWFMYWJlbGxlZEJ5KGZpZWxkTGFiZWxJZCwgc2VsZWN0TGFiZWxJZCk7XG4gIHVzZUxhYmVsYWJsZUlkKHtcbiAgICBpZDogaWRQcm9wXG4gIH0pO1xuICBjb25zdCBwb3NpdGlvbmVyUmVmID0gdXNlVmFsdWVBc1JlZihwb3NpdGlvbmVyRWxlbWVudCk7XG4gIGNvbnN0IHRyaWdnZXJSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IHNldEZvY3VzZWQgPSB1c2VTZXRGaWVsZEZvY3VzZWQoZGlzYWJsZWQsIHRyaWdnZXJSZWYpO1xuICBjb25zdCB7XG4gICAgZ2V0QnV0dG9uUHJvcHMsXG4gICAgYnV0dG9uUmVmXG4gIH0gPSB1c2VCdXR0b24oe1xuICAgIGRpc2FibGVkLFxuICAgIG5hdGl2ZTogbmF0aXZlQnV0dG9uXG4gIH0pO1xuICBjb25zdCBzZXRUcmlnZ2VyRWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlU2V0dGVyKCd0cmlnZ2VyRWxlbWVudCcpO1xuICBjb25zdCB0aW1lb3V0Rm9jdXMgPSB1c2VUaW1lb3V0KCk7XG4gIGNvbnN0IHRpbWVvdXRNb3VzZURvd24gPSB1c2VUaW1lb3V0KCk7XG4gIGNvbnN0IHNlbGVjdGVkRGVsYXlUaW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChvcGVuKSB7XG4gICAgICAvLyBBIG1vdXNlZG93biBvbiB0aGUgdHJpZ2dlciBjYW4gb3BlbiB0aGUgcG9wdXAgdW5kZXIgdGhlIGN1cnNvci4gS2VlcCBtb3VzZXVwIHNlbGVjdGlvblxuICAgICAgLy8gZGlzYWJsZWQgYnJpZWZseSBzbyByZWxlYXNpbmcgb3ZlciBlaXRoZXIgdGhlIHNlbGVjdGVkIGl0ZW0gb3IgYSBuZWlnaGJvcmluZyBpdGVtIGRvZXNuJ3RcbiAgICAgIC8vIGNvbW1pdCBhbiBhY2NpZGVudGFsIHNlbGVjdGlvbi4gU2VsZWN0SXRlbSBjYW4gc3RpbGwgb3B0IGludG8gdW5zZWxlY3RlZCBtb3VzZXVwIHNvb25lclxuICAgICAgLy8gYWZ0ZXIgYSByZWFsIGRyYWcgb3ZlciB0aGUgaXRlbS5cbiAgICAgIHNlbGVjdGVkRGVsYXlUaW1lb3V0LnN0YXJ0KFNFTEVDVEVEX0RFTEFZLCAoKSA9PiB7XG4gICAgICAgIHN0b3JlLmNvbnRleHQuc2VsZWN0aW9uUmVmLmN1cnJlbnQuYWxsb3dVbnNlbGVjdGVkTW91c2VVcCA9IHRydWU7XG4gICAgICAgIHN0b3JlLmNvbnRleHQuc2VsZWN0aW9uUmVmLmN1cnJlbnQuYWxsb3dTZWxlY3RlZE1vdXNlVXAgPSB0cnVlO1xuICAgICAgfSk7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBzZWxlY3RlZERlbGF5VGltZW91dC5jbGVhcigpO1xuICAgICAgfTtcbiAgICB9XG4gICAgc3RvcmUuY29udGV4dC5zZWxlY3Rpb25SZWYuY3VycmVudCA9IHtcbiAgICAgIGFsbG93U2VsZWN0ZWRNb3VzZVVwOiBmYWxzZSxcbiAgICAgIGFsbG93VW5zZWxlY3RlZE1vdXNlVXA6IGZhbHNlLFxuICAgICAgZHJhZ1k6IDBcbiAgICB9O1xuICAgIHRpbWVvdXRNb3VzZURvd24uY2xlYXIoKTtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9LCBbb3Blbiwgc3RvcmUsIHRpbWVvdXRNb3VzZURvd24sIHNlbGVjdGVkRGVsYXlUaW1lb3V0XSk7XG4gIGNvbnN0IG1lcmdlZFByb3BzID0gbWVyZ2VQcm9wcyh0cmlnZ2VyUHJvcHMsIHtcbiAgICBpZCxcbiAgICByb2xlOiAnY29tYm9ib3gnLFxuICAgICdhcmlhLWV4cGFuZGVkJzogb3BlbixcbiAgICAnYXJpYS1oYXNwb3B1cCc6ICdsaXN0Ym94JyxcbiAgICAnYXJpYS1jb250cm9scyc6IG9wZW4gPyBsaXN0RWxlbWVudD8uaWQgPz8gZ2V0RmxvYXRpbmdGb2N1c0VsZW1lbnQocG9zaXRpb25lckVsZW1lbnQpPy5pZCA6IHVuZGVmaW5lZCxcbiAgICAnYXJpYS1sYWJlbGxlZGJ5JzogYXJpYUxhYmVsbGVkQnksXG4gICAgJ2FyaWEtcmVhZG9ubHknOiByZWFkT25seSB8fCB1bmRlZmluZWQsXG4gICAgJ2FyaWEtcmVxdWlyZWQnOiByZXF1aXJlZCB8fCB1bmRlZmluZWQsXG4gICAgdGFiSW5kZXg6IGRpc2FibGVkID8gLTEgOiAwLFxuICAgIG9uRm9jdXMoZXZlbnQpIHtcbiAgICAgIHNldEZvY3VzZWQodHJ1ZSk7XG5cbiAgICAgIC8vIFRoZSBwb3B1cCBlbGVtZW50IHNob3VsZG4ndCBvYnNjdXJlIHRoZSBmb2N1c2VkIHRyaWdnZXIuXG4gICAgICBpZiAob3BlbiAmJiBzdG9yZS5jb250ZXh0LmFsaWduSXRlbVdpdGhUcmlnZ2VyQWN0aXZlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgc3RvcmUuY29udGV4dC5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5ub25lLCBldmVudC5uYXRpdmVFdmVudCkpO1xuICAgICAgfVxuXG4gICAgICAvLyBTYXZlcyBhIHJlLXJlbmRlciBvbiBpbml0aWFsIGNsaWNrOiBgZm9yY2VNb3VudCA9PT0gdHJ1ZWAgbW91bnRzXG4gICAgICAvLyB0aGUgaXRlbXMgYmVmb3JlIGBvcGVuID09PSB0cnVlYC4gV2UgY291bGQgc3luYyB0aG9zZSBjeWNsZXMgYmV0dGVyXG4gICAgICAvLyB3aXRob3V0IGEgdGltZW91dCwgYnV0IHRoaXMgaXMgZW5vdWdoIGZvciBub3cuXG4gICAgICB0aW1lb3V0Rm9jdXMuc3RhcnQoMCwgKCkgPT4ge1xuICAgICAgICBzdG9yZS5zZXQoJ2ZvcmNlTW91bnQnLCB0cnVlKTtcbiAgICAgIH0pO1xuICAgIH0sXG4gICAgb25CbHVyKGV2ZW50KSB7XG4gICAgICAvLyBJZiBmb2N1cyBpcyBtb3ZpbmcgaW50byB0aGUgcG9wdXAsIGRvbid0IGNvdW50IGl0IGFzIGEgYmx1ci5cbiAgICAgIGlmIChjb250YWlucyhwb3NpdGlvbmVyRWxlbWVudCwgZXZlbnQucmVsYXRlZFRhcmdldCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgc2V0VG91Y2hlZCh0cnVlKTtcbiAgICAgIHNldEZvY3VzZWQoZmFsc2UpO1xuICAgICAgaWYgKHZhbGlkYXRpb25Nb2RlID09PSAnb25CbHVyJykge1xuICAgICAgICB2YWxpZGF0aW9uLmNvbW1pdCh2YWx1ZSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBvbk1vdXNlRG93bihldmVudCkge1xuICAgICAgaWYgKG9wZW4pIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChldmVudC5jdXJyZW50VGFyZ2V0KTtcbiAgICAgIGZ1bmN0aW9uIGhhbmRsZU1vdXNlVXAobW91c2VFdmVudCkge1xuICAgICAgICBpZiAoIXRyaWdnZXJSZWYuY3VycmVudCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBtb3VzZVVwVGFyZ2V0ID0gbW91c2VFdmVudC50YXJnZXQ7XG5cbiAgICAgICAgLy8gRG9uJ3QgdHJlYXQgdGhlIHJlbGVhc2UgYXMgYW4gb3V0c2lkZSBwcmVzcyB3aGVuIGl0IGxhbmRzIG9uIHRoZSB0cmlnZ2VyIG9yIGluc2lkZVxuICAgICAgICAvLyB0aGUgcG9wdXAgcG9zaXRpb25lciAob3IgdGhlaXIgY2hpbGRyZW4pLlxuICAgICAgICBpZiAoY29udGFpbnModHJpZ2dlclJlZi5jdXJyZW50LCBtb3VzZVVwVGFyZ2V0KSB8fCBjb250YWlucyhwb3NpdGlvbmVyUmVmLmN1cnJlbnQsIG1vdXNlVXBUYXJnZXQpKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc01vdXNlV2l0aGluQm91bmRzKG1vdXNlRXZlbnQsIHRyaWdnZXJSZWYuY3VycmVudCkpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgc3RvcmUuY29udGV4dC5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5jYW5jZWxPcGVuLCBtb3VzZUV2ZW50KSk7XG4gICAgICB9XG5cbiAgICAgIC8vIEZpcmVmb3ggY2FuIGZpcmUgdGhpcyB1cG9uIG1vdXNlZG93blxuICAgICAgdGltZW91dE1vdXNlRG93bi5zdGFydCgwLCAoKSA9PiB7XG4gICAgICAgIGRvYy5hZGRFdmVudExpc3RlbmVyKCdtb3VzZXVwJywgaGFuZGxlTW91c2VVcCwge1xuICAgICAgICAgIG9uY2U6IHRydWVcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9XG4gIH0sIGVsZW1lbnRQcm9wcywgZ2V0QnV0dG9uUHJvcHMpO1xuICBjb25zdCBwcm9wcyA9IHZhbGlkYXRpb24uZ2V0VmFsaWRhdGlvblByb3BzKGRpc2FibGVkLCBtZXJnZWRQcm9wcyk7XG5cbiAgLy8gZW5zdXJlIG5lc3RlZCB1c2VCdXR0b24gZG9lcyBub3Qgb3ZlcndyaXRlIHRoZSBjb21ib2JveCByb2xlOlxuICAvLyA8VG9vbGJhci5CdXR0b24gcmVuZGVyPXs8U2VsZWN0LlRyaWdnZXIgLz59IC8+XG4gIHByb3BzLnJvbGUgPSAnY29tYm9ib3gnO1xuICBjb25zdCBzdGF0ZSA9IHtcbiAgICAuLi5maWVsZFN0YXRlLFxuICAgIG9wZW4sXG4gICAgZGlzYWJsZWQsXG4gICAgdmFsdWUsXG4gICAgcmVhZE9ubHksXG4gICAgcG9wdXBTaWRlLFxuICAgIHBsYWNlaG9sZGVyOiAhaGFzU2VsZWN0ZWRWYWx1ZVxuICB9O1xuICByZXR1cm4gdXNlUmVuZGVyRWxlbWVudCgnYnV0dG9uJywgY29tcG9uZW50UHJvcHMsIHtcbiAgICByZWY6IFtmb3J3YXJkZWRSZWYsIHRyaWdnZXJSZWYsIGJ1dHRvblJlZiwgc2V0VHJpZ2dlckVsZW1lbnRdLFxuICAgIHN0YXRlLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmcsXG4gICAgcHJvcHNcbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFNlbGVjdFRyaWdnZXIuZGlzcGxheU5hbWUgPSBcIlNlbGVjdFRyaWdnZXJcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L1NlbGVjdFJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgcmVzb2x2ZU11bHRpcGxlTGFiZWxzLCByZXNvbHZlU2VsZWN0ZWRMYWJlbCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVzb2x2ZVZhbHVlTGFiZWwubWpzXCI7XG5jb25zdCBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nID0ge1xuICB2YWx1ZTogKCkgPT4gbnVsbFxufTtcblxuLyoqXG4gKiBBIHRleHQgbGFiZWwgb2YgdGhlIGN1cnJlbnRseSBzZWxlY3RlZCBpdGVtLlxuICogUmVuZGVycyBhIGA8c3Bhbj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgU2VsZWN0XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvc2VsZWN0KVxuICovXG5leHBvcnQgY29uc3QgU2VsZWN0VmFsdWUgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBTZWxlY3RWYWx1ZShjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICBjbGFzc05hbWUsXG4gICAgcmVuZGVyLFxuICAgIGNoaWxkcmVuOiBjaGlsZHJlblByb3AsXG4gICAgcGxhY2Vob2xkZXIsXG4gICAgc3R5bGUsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qgc3RvcmUgPSB1c2VTZWxlY3RSb290Q29udGV4dCgpO1xuICBjb25zdCB2YWx1ZSA9IHN0b3JlLnVzZVN0YXRlKCd2YWx1ZScpO1xuICBjb25zdCBpdGVtcyA9IHN0b3JlLnVzZVN0YXRlKCdpdGVtcycpO1xuICBjb25zdCBpdGVtVG9TdHJpbmdMYWJlbCA9IHN0b3JlLnVzZVN0YXRlKCdpdGVtVG9TdHJpbmdMYWJlbCcpO1xuICBjb25zdCBoYXNTZWxlY3RlZFZhbHVlID0gc3RvcmUudXNlU3RhdGUoJ2hhc1NlbGVjdGVkVmFsdWUnKTtcbiAgY29uc3Qgc2hvdWxkQ2hlY2tOdWxsSXRlbUxhYmVsID0gIWhhc1NlbGVjdGVkVmFsdWUgJiYgcGxhY2Vob2xkZXIgIT0gbnVsbCAmJiBjaGlsZHJlblByb3AgPT0gbnVsbDtcbiAgY29uc3QgaGFzTnVsbExhYmVsID0gc3RvcmUudXNlU3RhdGUoJ2hhc051bGxJdGVtTGFiZWwnLCBzaG91bGRDaGVja051bGxJdGVtTGFiZWwpO1xuICBjb25zdCBzdGF0ZSA9IHtcbiAgICB2YWx1ZSxcbiAgICBwbGFjZWhvbGRlcjogIWhhc1NlbGVjdGVkVmFsdWVcbiAgfTtcbiAgbGV0IGNoaWxkcmVuID0gbnVsbDtcbiAgaWYgKHR5cGVvZiBjaGlsZHJlblByb3AgPT09ICdmdW5jdGlvbicpIHtcbiAgICBjaGlsZHJlbiA9IGNoaWxkcmVuUHJvcCh2YWx1ZSk7XG4gIH0gZWxzZSBpZiAoY2hpbGRyZW5Qcm9wICE9IG51bGwpIHtcbiAgICBjaGlsZHJlbiA9IGNoaWxkcmVuUHJvcDtcbiAgfSBlbHNlIGlmIChzaG91bGRDaGVja051bGxJdGVtTGFiZWwgJiYgIWhhc051bGxMYWJlbCkge1xuICAgIGNoaWxkcmVuID0gcGxhY2Vob2xkZXI7XG4gIH0gZWxzZSBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICBjaGlsZHJlbiA9IHJlc29sdmVNdWx0aXBsZUxhYmVscyh2YWx1ZSwgaXRlbXMsIGl0ZW1Ub1N0cmluZ0xhYmVsKTtcbiAgfSBlbHNlIHtcbiAgICBjaGlsZHJlbiA9IHJlc29sdmVTZWxlY3RlZExhYmVsKHZhbHVlLCBpdGVtcywgaXRlbVRvU3RyaW5nTGFiZWwpO1xuICB9XG4gIGNvbnN0IGVsZW1lbnQgPSB1c2VSZW5kZXJFbGVtZW50KCdzcGFuJywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICByZWY6IFtmb3J3YXJkZWRSZWYsIHN0b3JlLmNvbnRleHQudmFsdWVSZWZdLFxuICAgIHByb3BzOiBbe1xuICAgICAgY2hpbGRyZW5cbiAgICB9LCBlbGVtZW50UHJvcHNdLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmdcbiAgfSk7XG4gIHJldHVybiBlbGVtZW50O1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBTZWxlY3RWYWx1ZS5kaXNwbGF5TmFtZSA9IFwiU2VsZWN0VmFsdWVcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L1NlbGVjdFJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdHJpZ2dlck9wZW5TdGF0ZU1hcHBpbmcgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogQW4gaWNvbiB0aGF0IGluZGljYXRlcyB0aGF0IHRoZSB0cmlnZ2VyIGJ1dHRvbiBvcGVucyBhIHNlbGVjdCBwb3B1cC5cbiAqIFJlbmRlcnMgYSBgPHNwYW4+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIFNlbGVjdF0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL3NlbGVjdClcbiAqL1xuZXhwb3J0IGNvbnN0IFNlbGVjdEljb24gPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBTZWxlY3RJY29uKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qgc3RvcmUgPSB1c2VTZWxlY3RSb290Q29udGV4dCgpO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgb3BlblxuICB9O1xuICBjb25zdCBlbGVtZW50ID0gdXNlUmVuZGVyRWxlbWVudCgnc3BhbicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgc3RhdGUsXG4gICAgcmVmOiBmb3J3YXJkZWRSZWYsXG4gICAgcHJvcHM6IFt7XG4gICAgICAnYXJpYS1oaWRkZW4nOiB0cnVlLFxuICAgICAgY2hpbGRyZW46ICfilrwnXG4gICAgfSwgZWxlbWVudFByb3BzXSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiB0cmlnZ2VyT3BlblN0YXRlTWFwcGluZ1xuICB9KTtcbiAgcmV0dXJuIGVsZW1lbnQ7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFNlbGVjdEljb24uZGlzcGxheU5hbWUgPSBcIlNlbGVjdEljb25cIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEZsb2F0aW5nUG9ydGFsIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlU2VsZWN0Um9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9TZWxlY3RSb290Q29udGV4dC5tanNcIjtcblxuLyoqXG4gKiBBIHBvcnRhbCBlbGVtZW50IHRoYXQgbW92ZXMgdGhlIHBvcHVwIHRvIGEgZGlmZmVyZW50IHBhcnQgb2YgdGhlIERPTS5cbiAqIEJ5IGRlZmF1bHQsIHRoZSBwb3J0YWwgZWxlbWVudCBpcyBhcHBlbmRlZCB0byBgPGJvZHk+YC5cbiAqIFJlbmRlcnMgYSBgPGRpdj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgU2VsZWN0XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvc2VsZWN0KVxuICovXG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZXhwb3J0IGNvbnN0IFNlbGVjdFBvcnRhbCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIFNlbGVjdFBvcnRhbChwb3J0YWxQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHN0b3JlID0gdXNlU2VsZWN0Um9vdENvbnRleHQoKTtcbiAgY29uc3QgbW91bnRlZCA9IHN0b3JlLnVzZVN0YXRlKCdtb3VudGVkJyk7XG4gIGNvbnN0IGZvcmNlTW91bnQgPSBzdG9yZS51c2VTdGF0ZSgnZm9yY2VNb3VudCcpO1xuICBjb25zdCBzaG91bGRSZW5kZXIgPSBtb3VudGVkIHx8IGZvcmNlTW91bnQ7XG4gIGlmICghc2hvdWxkUmVuZGVyKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KEZsb2F0aW5nUG9ydGFsLCB7XG4gICAgcmVmOiBmb3J3YXJkZWRSZWYsXG4gICAgLi4ucG9ydGFsUHJvcHNcbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFNlbGVjdFBvcnRhbC5kaXNwbGF5TmFtZSA9IFwiU2VsZWN0UG9ydGFsXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VTZWxlY3RSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L1NlbGVjdFJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgcG9wdXBTdGF0ZU1hcHBpbmcgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5pbXBvcnQgeyB0cmFuc2l0aW9uU3RhdHVzTWFwcGluZyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5jb25zdCBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nID0ge1xuICAuLi5wb3B1cFN0YXRlTWFwcGluZyxcbiAgLi4udHJhbnNpdGlvblN0YXR1c01hcHBpbmdcbn07XG5cbi8qKlxuICogQW4gb3ZlcmxheSBkaXNwbGF5ZWQgYmVuZWF0aCB0aGUgc2VsZWN0IHBvcHVwLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBTZWxlY3RdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9zZWxlY3QpXG4gKi9cbmV4cG9ydCBjb25zdCBTZWxlY3RCYWNrZHJvcCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIFNlbGVjdEJhY2tkcm9wKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qgc3RvcmUgPSB1c2VTZWxlY3RSb290Q29udGV4dCgpO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3QgbW91bnRlZCA9IHN0b3JlLnVzZVN0YXRlKCdtb3VudGVkJyk7XG4gIGNvbnN0IHRyYW5zaXRpb25TdGF0dXMgPSBzdG9yZS51c2VTdGF0ZSgndHJhbnNpdGlvblN0YXR1cycpO1xuICBjb25zdCBzdGF0ZSA9IHtcbiAgICBvcGVuLFxuICAgIHRyYW5zaXRpb25TdGF0dXNcbiAgfTtcbiAgY29uc3QgZWxlbWVudCA9IHVzZVJlbmRlckVsZW1lbnQoJ2RpdicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgc3RhdGUsXG4gICAgcmVmOiBmb3J3YXJkZWRSZWYsXG4gICAgcHJvcHM6IFt7XG4gICAgICByb2xlOiAncHJlc2VudGF0aW9uJyxcbiAgICAgIGhpZGRlbjogIW1vdW50ZWQsXG4gICAgICBzdHlsZToge1xuICAgICAgICB1c2VyU2VsZWN0OiAnbm9uZScsXG4gICAgICAgIFdlYmtpdFVzZXJTZWxlY3Q6ICdub25lJ1xuICAgICAgfVxuICAgIH0sIGVsZW1lbnRQcm9wc10sXG4gICAgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZ1xuICB9KTtcbiAgcmV0dXJuIGVsZW1lbnQ7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFNlbGVjdEJhY2tkcm9wLmRpc3BsYXlOYW1lID0gXCJTZWxlY3RCYWNrZHJvcFwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IFNlbGVjdFBvc2l0aW9uZXJDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFNlbGVjdFBvc2l0aW9uZXJDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJTZWxlY3RQb3NpdGlvbmVyQ29udGV4dFwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVNlbGVjdFBvc2l0aW9uZXJDb250ZXh0KCkge1xuICBjb25zdCBjb250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChTZWxlY3RQb3NpdGlvbmVyQ29udGV4dCk7XG4gIGlmICghY29udGV4dCkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAnQmFzZSBVSTogU2VsZWN0UG9zaXRpb25lckNvbnRleHQgaXMgbWlzc2luZy4gU2VsZWN0UG9zaXRpb25lciBwYXJ0cyBtdXN0IGJlIHBsYWNlZCB3aXRoaW4gPFNlbGVjdC5Qb3NpdGlvbmVyPi4nIDogX2Zvcm1hdEVycm9yTWVzc2FnZSg1OSkpO1xuICB9XG4gIHJldHVybiBjb250ZXh0O1xufSIsImV4cG9ydCBmdW5jdGlvbiBjbGVhclN0eWxlcyhlbGVtZW50LCBvcmlnaW5hbFN0eWxlcykge1xuICBpZiAoZWxlbWVudCkge1xuICAgIE9iamVjdC5hc3NpZ24oZWxlbWVudC5zdHlsZSwgb3JpZ2luYWxTdHlsZXMpO1xuICB9XG59XG5leHBvcnQgY29uc3QgTElTVF9GVU5DVElPTkFMX1NUWUxFUyA9IHtcbiAgcG9zaXRpb246ICdyZWxhdGl2ZScsXG4gIG1heEhlaWdodDogJzEwMCUnLFxuICBvdmVyZmxvd1g6ICdoaWRkZW4nLFxuICBvdmVyZmxvd1k6ICdhdXRvJ1xufTsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGluZXJ0VmFsdWUgfSBmcm9tICdAYmFzZS11aS91dGlscy9pbmVydFZhbHVlJztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VTdGFibGVDYWxsYmFjayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrJztcbmltcG9ydCB7IHVzZVNlbGVjdEZsb2F0aW5nQ29udGV4dCwgdXNlU2VsZWN0Um9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9TZWxlY3RSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IENvbXBvc2l0ZUxpc3QgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NvbXBvc2l0ZS9saXN0L0NvbXBvc2l0ZUxpc3QubWpzXCI7XG5pbXBvcnQgeyB1c2VBbmNob3JQb3NpdGlvbmluZyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlQW5jaG9yUG9zaXRpb25pbmcubWpzXCI7XG5pbXBvcnQgeyBTZWxlY3RQb3NpdGlvbmVyQ29udGV4dCB9IGZyb20gXCIuL1NlbGVjdFBvc2l0aW9uZXJDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgSW50ZXJuYWxCYWNrZHJvcCB9IGZyb20gXCIuLi8uLi91dGlscy9JbnRlcm5hbEJhY2tkcm9wLm1qc1wiO1xuaW1wb3J0IHsgRFJPUERPV05fQ09MTElTSU9OX0FWT0lEQU5DRSB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY29uc3RhbnRzLm1qc1wiO1xuaW1wb3J0IHsgY2xlYXJTdHlsZXMgfSBmcm9tIFwiLi4vcG9wdXAvdXRpbHMubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5pbXBvcnQgeyBmaW5kSXRlbUluZGV4IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9pdGVtRXF1YWxpdHkubWpzXCI7XG5pbXBvcnQgeyB1c2VQb3NpdGlvbmVyIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3VzZVBvc2l0aW9uZXIubWpzXCI7XG5pbXBvcnQgeyB1c2VBbmNob3JlZFBvcHVwU2Nyb2xsTG9jayB9IGZyb20gXCIuLi8uLi91dGlscy91c2VBbmNob3JlZFBvcHVwU2Nyb2xsTG9jay5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4LCBqc3hzIGFzIF9qc3hzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5jb25zdCBGSVhFRCA9IHtcbiAgcG9zaXRpb246ICdmaXhlZCdcbn07XG5cbi8qKlxuICogUG9zaXRpb25zIHRoZSBzZWxlY3QgcG9wdXAuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIFNlbGVjdF0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL3NlbGVjdClcbiAqL1xuZXhwb3J0IGNvbnN0IFNlbGVjdFBvc2l0aW9uZXIgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBTZWxlY3RQb3NpdGlvbmVyKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIGFuY2hvcixcbiAgICBjbGFzc05hbWUsXG4gICAgcmVuZGVyLFxuICAgIC8vIGB1c2VBbmNob3JQb3NpdGlvbmluZ2AgYXBwbGllcyB0aGUgc2FtZSBkZWZhdWx0cyB0byB0aGUgdW5kZWZpbmVkIHZhbHVlczsgdGhlIG5hbWVzXG4gICAgLy8gcmVtYWluIGRlc3RydWN0dXJlZCB0byBleGNsdWRlIHRoZSBwcm9wcyBmcm9tIGBlbGVtZW50UHJvcHNgLlxuICAgIHBvc2l0aW9uTWV0aG9kLFxuICAgIHNpZGUsXG4gICAgYWxpZ24sXG4gICAgc2lkZU9mZnNldCxcbiAgICBhbGlnbk9mZnNldCxcbiAgICBjb2xsaXNpb25Cb3VuZGFyeSA9ICdjbGlwcGluZy1hbmNlc3RvcnMnLFxuICAgIGNvbGxpc2lvblBhZGRpbmcsXG4gICAgYXJyb3dQYWRkaW5nLFxuICAgIHN0aWNreSxcbiAgICBkaXNhYmxlQW5jaG9yVHJhY2tpbmcsXG4gICAgYWxpZ25JdGVtV2l0aFRyaWdnZXIgPSB0cnVlLFxuICAgIGNvbGxpc2lvbkF2b2lkYW5jZSA9IERST1BET1dOX0NPTExJU0lPTl9BVk9JREFOQ0UsXG4gICAgc3R5bGUsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qgc3RvcmUgPSB1c2VTZWxlY3RSb290Q29udGV4dCgpO1xuICBjb25zdCBmbG9hdGluZ1Jvb3RDb250ZXh0ID0gdXNlU2VsZWN0RmxvYXRpbmdDb250ZXh0KCk7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCBtb3VudGVkID0gc3RvcmUudXNlU3RhdGUoJ21vdW50ZWQnKTtcbiAgY29uc3QgbW9kYWwgPSBzdG9yZS51c2VTdGF0ZSgnbW9kYWwnKTtcbiAgY29uc3QgdmFsdWUgPSBzdG9yZS51c2VTdGF0ZSgndmFsdWUnKTtcbiAgY29uc3Qgb3Blbk1ldGhvZCA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuTWV0aG9kJyk7XG4gIGNvbnN0IHBvc2l0aW9uZXJFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ3Bvc2l0aW9uZXJFbGVtZW50Jyk7XG4gIGNvbnN0IHRyaWdnZXJFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ3RyaWdnZXJFbGVtZW50Jyk7XG4gIGNvbnN0IGlzSXRlbUVxdWFsVG9WYWx1ZSA9IHN0b3JlLnVzZVN0YXRlKCdpc0l0ZW1FcXVhbFRvVmFsdWUnKTtcbiAgY29uc3QgdHJhbnNpdGlvblN0YXR1cyA9IHN0b3JlLnVzZVN0YXRlKCd0cmFuc2l0aW9uU3RhdHVzJyk7XG4gIGNvbnN0IHNjcm9sbFVwQXJyb3dSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IHNjcm9sbERvd25BcnJvd1JlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgW2NvbnRyb2xsZWRBbGlnbkl0ZW1XaXRoVHJpZ2dlciwgc2V0Q29udHJvbGxlZEFsaWduSXRlbVdpdGhUcmlnZ2VyXSA9IFJlYWN0LnVzZVN0YXRlKGFsaWduSXRlbVdpdGhUcmlnZ2VyKTtcbiAgY29uc3QgYWxpZ25JdGVtV2l0aFRyaWdnZXJBY3RpdmUgPSBtb3VudGVkICYmIGNvbnRyb2xsZWRBbGlnbkl0ZW1XaXRoVHJpZ2dlciAmJiBvcGVuTWV0aG9kICE9PSAndG91Y2gnO1xuICBpZiAoIW1vdW50ZWQgJiYgY29udHJvbGxlZEFsaWduSXRlbVdpdGhUcmlnZ2VyICE9PSBhbGlnbkl0ZW1XaXRoVHJpZ2dlcikge1xuICAgIHNldENvbnRyb2xsZWRBbGlnbkl0ZW1XaXRoVHJpZ2dlcihhbGlnbkl0ZW1XaXRoVHJpZ2dlcik7XG4gIH1cbiAgUmVhY3QudXNlSW1wZXJhdGl2ZUhhbmRsZShzdG9yZS5jb250ZXh0LmFsaWduSXRlbVdpdGhUcmlnZ2VyQWN0aXZlUmVmLCAoKSA9PiBhbGlnbkl0ZW1XaXRoVHJpZ2dlckFjdGl2ZSk7XG4gIHVzZUFuY2hvcmVkUG9wdXBTY3JvbGxMb2NrKChhbGlnbkl0ZW1XaXRoVHJpZ2dlckFjdGl2ZSB8fCBtb2RhbCkgJiYgb3Blbiwgb3Blbk1ldGhvZCA9PT0gJ3RvdWNoJywgcG9zaXRpb25lckVsZW1lbnQsIHRyaWdnZXJFbGVtZW50KTtcbiAgY29uc3QgcG9zaXRpb25pbmcgPSB1c2VBbmNob3JQb3NpdGlvbmluZyh7XG4gICAgYW5jaG9yLFxuICAgIGZsb2F0aW5nUm9vdENvbnRleHQsXG4gICAgcG9zaXRpb25NZXRob2QsXG4gICAgbW91bnRlZCxcbiAgICBzaWRlLFxuICAgIHNpZGVPZmZzZXQsXG4gICAgYWxpZ24sXG4gICAgYWxpZ25PZmZzZXQsXG4gICAgYXJyb3dQYWRkaW5nLFxuICAgIGNvbGxpc2lvbkJvdW5kYXJ5LFxuICAgIGNvbGxpc2lvblBhZGRpbmcsXG4gICAgc3RpY2t5LFxuICAgIGRpc2FibGVBbmNob3JUcmFja2luZzogZGlzYWJsZUFuY2hvclRyYWNraW5nID8/IGFsaWduSXRlbVdpdGhUcmlnZ2VyQWN0aXZlLFxuICAgIGNvbGxpc2lvbkF2b2lkYW5jZSxcbiAgICBrZWVwTW91bnRlZDogdHJ1ZVxuICB9KTtcbiAgY29uc3QgcmVuZGVyZWRTaWRlID0gYWxpZ25JdGVtV2l0aFRyaWdnZXJBY3RpdmUgPyAnbm9uZScgOiBwb3NpdGlvbmluZy5zaWRlO1xuICBjb25zdCBwb3NpdGlvbmVyU3R5bGVzID0gYWxpZ25JdGVtV2l0aFRyaWdnZXJBY3RpdmUgPyBGSVhFRCA6IHBvc2l0aW9uaW5nLnBvc2l0aW9uZXJTdHlsZXM7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIG9wZW4sXG4gICAgc2lkZTogcmVuZGVyZWRTaWRlLFxuICAgIGFsaWduOiBwb3NpdGlvbmluZy5hbGlnbixcbiAgICBhbmNob3JIaWRkZW46IHBvc2l0aW9uaW5nLmFuY2hvckhpZGRlblxuICB9O1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIHN0b3JlLnNldCgncG9wdXBTaWRlJywgcG9zaXRpb25pbmcuc2lkZSk7XG4gIH0sIFtzdG9yZSwgcG9zaXRpb25pbmcuc2lkZV0pO1xuICBjb25zdCBzZXRQb3NpdGlvbmVyRWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlU2V0dGVyKCdwb3NpdGlvbmVyRWxlbWVudCcpO1xuICBjb25zdCBlbGVtZW50ID0gdXNlUG9zaXRpb25lcihjb21wb25lbnRQcm9wcywgc3RhdGUsIHtcbiAgICBzdHlsZXM6IHBvc2l0aW9uZXJTdHlsZXMsXG4gICAgdHJhbnNpdGlvblN0YXR1cyxcbiAgICBwcm9wczogZWxlbWVudFByb3BzLFxuICAgIHJlZnM6IFtmb3J3YXJkZWRSZWYsIHNldFBvc2l0aW9uZXJFbGVtZW50XSxcbiAgICBoaWRkZW46ICFtb3VudGVkLFxuICAgIGluZXJ0OiAhb3BlblxuICB9KTtcbiAgY29uc3QgcHJldk1hcFNpemVSZWYgPSBSZWFjdC51c2VSZWYoMCk7XG4gIGNvbnN0IG9uTWFwQ2hhbmdlID0gdXNlU3RhYmxlQ2FsbGJhY2sobWFwID0+IHtcbiAgICBpZiAoc3RvcmUuY29udGV4dC52YWx1ZXNSZWYuY3VycmVudC5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgcHJldlNpemUgPSBwcmV2TWFwU2l6ZVJlZi5jdXJyZW50O1xuICAgIHByZXZNYXBTaXplUmVmLmN1cnJlbnQgPSBtYXAuc2l6ZTtcbiAgICBjb25zdCBldmVudERldGFpbHMgPSBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5ub25lKTtcbiAgICBpZiAocHJldlNpemUgIT09IDAgJiYgIXN0b3JlLnN0YXRlLm11bHRpcGxlICYmIHZhbHVlICE9PSBudWxsKSB7XG4gICAgICBjb25zdCBzZWxlY3RlZFZhbHVlSW5kZXggPSBmaW5kSXRlbUluZGV4KHN0b3JlLmNvbnRleHQudmFsdWVzUmVmLmN1cnJlbnQsIHZhbHVlLCBpc0l0ZW1FcXVhbFRvVmFsdWUpO1xuICAgICAgaWYgKHNlbGVjdGVkVmFsdWVJbmRleCA9PT0gLTEpIHtcbiAgICAgICAgY29uc3QgaW5pdGlhbFNlbGVjdGVkVmFsdWUgPSBzdG9yZS5jb250ZXh0LmluaXRpYWxWYWx1ZVJlZi5jdXJyZW50O1xuICAgICAgICBjb25zdCBoYXNJbml0aWFsID0gaW5pdGlhbFNlbGVjdGVkVmFsdWUgIT0gbnVsbCAmJiBmaW5kSXRlbUluZGV4KHN0b3JlLmNvbnRleHQudmFsdWVzUmVmLmN1cnJlbnQsIGluaXRpYWxTZWxlY3RlZFZhbHVlLCBpc0l0ZW1FcXVhbFRvVmFsdWUpICE9PSAtMTtcbiAgICAgICAgY29uc3QgbmV4dFZhbHVlID0gaGFzSW5pdGlhbCA/IGluaXRpYWxTZWxlY3RlZFZhbHVlIDogbnVsbDtcbiAgICAgICAgc3RvcmUuY29udGV4dC5zZXRWYWx1ZShuZXh0VmFsdWUsIGV2ZW50RGV0YWlscyk7XG4gICAgICAgIGlmIChuZXh0VmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgICBzdG9yZS5zZXQoJ3NlbGVjdGVkSW5kZXgnLCBudWxsKTtcbiAgICAgICAgICBzdG9yZS5jb250ZXh0LnNlbGVjdGVkSXRlbVRleHRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHByZXZTaXplICE9PSAwICYmIHN0b3JlLnN0YXRlLm11bHRpcGxlICYmIEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICBjb25zdCBuZXh0VmFsdWUgPSB2YWx1ZS5maWx0ZXIoc2VsZWN0ZWRJdGVtVmFsdWUgPT4gZmluZEl0ZW1JbmRleChzdG9yZS5jb250ZXh0LnZhbHVlc1JlZi5jdXJyZW50LCBzZWxlY3RlZEl0ZW1WYWx1ZSwgaXNJdGVtRXF1YWxUb1ZhbHVlKSAhPT0gLTEpO1xuICAgICAgaWYgKG5leHRWYWx1ZS5sZW5ndGggIT09IHZhbHVlLmxlbmd0aCkge1xuICAgICAgICBzdG9yZS5jb250ZXh0LnNldFZhbHVlKG5leHRWYWx1ZSwgZXZlbnREZXRhaWxzKTtcbiAgICAgICAgaWYgKG5leHRWYWx1ZS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICBzdG9yZS5zZXQoJ3NlbGVjdGVkSW5kZXgnLCBudWxsKTtcbiAgICAgICAgICBzdG9yZS5jb250ZXh0LnNlbGVjdGVkSXRlbVRleHRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKG9wZW4gJiYgYWxpZ25JdGVtV2l0aFRyaWdnZXJBY3RpdmUpIHtcbiAgICAgIHN0b3JlLnVwZGF0ZSh7XG4gICAgICAgIHNjcm9sbFVwQXJyb3dWaXNpYmxlOiBmYWxzZSxcbiAgICAgICAgc2Nyb2xsRG93bkFycm93VmlzaWJsZTogZmFsc2VcbiAgICAgIH0pO1xuICAgICAgY29uc3Qgc3R5bGVzVG9DbGVhciA9IHtcbiAgICAgICAgaGVpZ2h0OiAnJ1xuICAgICAgfTtcbiAgICAgIGNsZWFyU3R5bGVzKHBvc2l0aW9uZXJFbGVtZW50LCBzdHlsZXNUb0NsZWFyKTtcbiAgICAgIGNsZWFyU3R5bGVzKHN0b3JlLmNvbnRleHQucG9wdXBSZWYuY3VycmVudCwgc3R5bGVzVG9DbGVhcik7XG4gICAgfVxuICB9KTtcbiAgY29uc3QgY29udGV4dFZhbHVlID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIC4uLnBvc2l0aW9uaW5nLFxuICAgIHNpZGU6IHJlbmRlcmVkU2lkZSxcbiAgICBhbGlnbkl0ZW1XaXRoVHJpZ2dlckFjdGl2ZSxcbiAgICBzZXRDb250cm9sbGVkQWxpZ25JdGVtV2l0aFRyaWdnZXIsXG4gICAgc2Nyb2xsVXBBcnJvd1JlZixcbiAgICBzY3JvbGxEb3duQXJyb3dSZWZcbiAgfSksIFtwb3NpdGlvbmluZywgcmVuZGVyZWRTaWRlLCBhbGlnbkl0ZW1XaXRoVHJpZ2dlckFjdGl2ZSwgc2V0Q29udHJvbGxlZEFsaWduSXRlbVdpdGhUcmlnZ2VyXSk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChDb21wb3NpdGVMaXN0LCB7XG4gICAgZWxlbWVudHNSZWY6IHN0b3JlLmNvbnRleHQubGlzdFJlZixcbiAgICBsYWJlbHNSZWY6IHN0b3JlLmNvbnRleHQubGFiZWxzUmVmLFxuICAgIG9uTWFwQ2hhbmdlOiBvbk1hcENoYW5nZSxcbiAgICBjaGlsZHJlbjogLyojX19QVVJFX18qL19qc3hzKFNlbGVjdFBvc2l0aW9uZXJDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgICB2YWx1ZTogY29udGV4dFZhbHVlLFxuICAgICAgY2hpbGRyZW46IFttb3VudGVkICYmIG1vZGFsICYmIC8qI19fUFVSRV9fKi9fanN4KEludGVybmFsQmFja2Ryb3AsIHtcbiAgICAgICAgaW5lcnQ6IGluZXJ0VmFsdWUoIW9wZW4pLFxuICAgICAgICBjdXRvdXQ6IHRyaWdnZXJFbGVtZW50XG4gICAgICB9KSwgZWxlbWVudF1cbiAgICB9KVxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgU2VsZWN0UG9zaXRpb25lci5kaXNwbGF5TmFtZSA9IFwiU2VsZWN0UG9zaXRpb25lclwiOyIsImltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5jb25zdCBESVNBQkxFX1NDUk9MTEJBUl9DTEFTU19OQU1FID0gJ2Jhc2UtdWktZGlzYWJsZS1zY3JvbGxiYXInO1xuZXhwb3J0IGNvbnN0IHN0eWxlRGlzYWJsZVNjcm9sbGJhciA9IHtcbiAgY2xhc3NOYW1lOiBESVNBQkxFX1NDUk9MTEJBUl9DTEFTU19OQU1FLFxuICBnZXRFbGVtZW50KG5vbmNlKSB7XG4gICAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KFwic3R5bGVcIiwge1xuICAgICAgbm9uY2U6IG5vbmNlLFxuICAgICAgaHJlZjogRElTQUJMRV9TQ1JPTExCQVJfQ0xBU1NfTkFNRSxcbiAgICAgIHByZWNlZGVuY2U6IFwiYmFzZS11aTpsb3dcIixcbiAgICAgIGNoaWxkcmVuOiBgLiR7RElTQUJMRV9TQ1JPTExCQVJfQ0xBU1NfTkFNRX17c2Nyb2xsYmFyLXdpZHRoOm5vbmV9LiR7RElTQUJMRV9TQ1JPTExCQVJfQ0xBU1NfTkFNRX06Oi13ZWJraXQtc2Nyb2xsYmFye2Rpc3BsYXk6bm9uZX1gXG4gICAgfSk7XG4gIH1cbn07XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBzdHlsZURpc2FibGVTY3JvbGxiYXIuZ2V0RWxlbWVudC5kaXNwbGF5TmFtZSA9IFwic3R5bGVEaXNhYmxlU2Nyb2xsYmFyLmdldEVsZW1lbnRcIjsiLCIvKipcbiAqIFRoZSBhdmFpbGFibGUgd2lkdGggYmV0d2VlbiB0aGUgdHJpZ2dlciBhbmQgdGhlIGVkZ2Ugb2YgdGhlIHZpZXdwb3J0LlxuICogQHR5cGUge251bWJlcn1cbiAqL1xuZXhwb3J0IGNvbnN0IGF2YWlsYWJsZVdpZHRoID0gJy0tYXZhaWxhYmxlLXdpZHRoJztcbi8qKlxuICogVGhlIGF2YWlsYWJsZSBoZWlnaHQgYmV0d2VlbiB0aGUgdHJpZ2dlciBhbmQgdGhlIGVkZ2Ugb2YgdGhlIHZpZXdwb3J0LlxuICogQHR5cGUge251bWJlcn1cbiAqL1xuZXhwb3J0IGNvbnN0IGF2YWlsYWJsZUhlaWdodCA9ICctLWF2YWlsYWJsZS1oZWlnaHQnO1xuLyoqXG4gKiBUaGUgYW5jaG9yJ3Mgd2lkdGguXG4gKiBAdHlwZSB7bnVtYmVyfVxuICovXG5leHBvcnQgY29uc3QgYW5jaG9yV2lkdGggPSAnLS1hbmNob3Itd2lkdGgnO1xuLyoqXG4gKiBUaGUgYW5jaG9yJ3MgaGVpZ2h0LlxuICogQHR5cGUge251bWJlcn1cbiAqL1xuZXhwb3J0IGNvbnN0IGFuY2hvckhlaWdodCA9ICctLWFuY2hvci1oZWlnaHQnO1xuLyoqXG4gKiBUaGUgY29vcmRpbmF0ZXMgdGhhdCB0aGlzIGVsZW1lbnQgaXMgYW5jaG9yZWQgdG8uIFVzZWQgZm9yIGFuaW1hdGlvbnMgYW5kIHRyYW5zaXRpb25zLlxuICogQHR5cGUge3N0cmluZ31cbiAqL1xuZXhwb3J0IGNvbnN0IHRyYW5zZm9ybU9yaWdpbiA9ICctLXRyYW5zZm9ybS1vcmlnaW4nOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgcmVjdFRvQ2xpZW50UmVjdCB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscyc7XG5pbXBvcnQgeyBhZGRFdmVudExpc3RlbmVyIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvYWRkRXZlbnRMaXN0ZW5lcic7XG5pbXBvcnQgeyBwbGF0Zm9ybSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtJztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuaW1wb3J0IHsgb3duZXJEb2N1bWVudCwgb3duZXJXaW5kb3cgfSBmcm9tICdAYmFzZS11aS91dGlscy9vd25lcic7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgdXNlQW5pbWF0aW9uRnJhbWUgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VBbmltYXRpb25GcmFtZSc7XG5pbXBvcnQgeyBjbGFtcCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2NsYW1wJztcbmltcG9ydCB7IEZsb2F0aW5nRm9jdXNNYW5hZ2VyLCBwbGF0Zm9ybSBhcyBmbG9hdGluZ1BsYXRmb3JtIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlU2VsZWN0RmxvYXRpbmdDb250ZXh0LCB1c2VTZWxlY3RSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L1NlbGVjdFJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgcG9wdXBTdGF0ZU1hcHBpbmcgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RQb3NpdGlvbmVyQ29udGV4dCB9IGZyb20gXCIuLi9wb3NpdGlvbmVyL1NlbGVjdFBvc2l0aW9uZXJDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgc3R5bGVEaXNhYmxlU2Nyb2xsYmFyIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3N0eWxlcy5tanNcIjtcbmltcG9ydCB7IHRyYW5zaXRpb25TdGF0dXNNYXBwaW5nIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9zdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nLm1qc1wiO1xuaW1wb3J0IHsgdXNlT3BlbkNoYW5nZUNvbXBsZXRlIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VPcGVuQ2hhbmdlQ29tcGxldGUubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgY2xlYXJTdHlsZXMsIExJU1RfRlVOQ1RJT05BTF9TVFlMRVMgfSBmcm9tIFwiLi91dGlscy5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY3JlYXRlQmFzZVVJRXZlbnREZXRhaWxzLm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcbmltcG9ydCB7IHVzZVRvb2xiYXJSb290Q29udGV4dCB9IGZyb20gXCIuLi8uLi90b29sYmFyL3Jvb3QvVG9vbGJhclJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgQ09NUE9TSVRFX0tFWVMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NvbXBvc2l0ZS9jb21wb3NpdGUubWpzXCI7XG5pbXBvcnQgeyBnZXREaXNhYmxlZE1vdW50VHJhbnNpdGlvblN0eWxlcyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvZ2V0RGlzYWJsZWRNb3VudFRyYW5zaXRpb25TdHlsZXMubWpzXCI7XG5pbXBvcnQgeyBnZXRNYXhTY3JvbGxPZmZzZXQsIFNDUk9MTF9FREdFX1RPTEVSQU5DRV9QWCB9IGZyb20gXCIuLi8uLi91dGlscy9zY3JvbGxFZGdlcy5tanNcIjtcbmltcG9ydCB7IHVzZUNTUENvbnRleHQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NzcC1jb250ZXh0L0NTUENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VEaXJlY3Rpb24gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2RpcmVjdGlvbi1jb250ZXh0L0RpcmVjdGlvbkNvbnRleHQubWpzXCI7XG5pbXBvcnQgKiBhcyBTZWxlY3RQb3NpdGlvbmVyQ3NzVmFycyBmcm9tIFwiLi4vcG9zaXRpb25lci9TZWxlY3RQb3NpdGlvbmVyQ3NzVmFycy5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4LCBqc3hzIGFzIF9qc3hzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5jb25zdCBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nID0ge1xuICAuLi5wb3B1cFN0YXRlTWFwcGluZyxcbiAgLi4udHJhbnNpdGlvblN0YXR1c01hcHBpbmdcbn07XG5cbi8qKlxuICogQSBjb250YWluZXIgZm9yIHRoZSBzZWxlY3QgbGlzdC5cbiAqIFJlbmRlcnMgYSBgPGRpdj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgU2VsZWN0XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvc2VsZWN0KVxuICovXG5leHBvcnQgY29uc3QgU2VsZWN0UG9wdXAgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBTZWxlY3RQb3B1cChjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIGZpbmFsRm9jdXMsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qgc3RvcmUgPSB1c2VTZWxlY3RSb290Q29udGV4dCgpO1xuICBjb25zdCBtdWx0aXBsZSA9IHN0b3JlLnVzZVN0YXRlKCdtdWx0aXBsZScpO1xuICBjb25zdCByZWFkT25seSA9IHN0b3JlLnVzZVN0YXRlKCdyZWFkT25seScpO1xuICBjb25zdCBoaWdobGlnaHRJdGVtT25Ib3ZlciA9IHN0b3JlLnVzZVN0YXRlKCdoaWdobGlnaHRJdGVtT25Ib3ZlcicpO1xuICBjb25zdCBmbG9hdGluZ1Jvb3RDb250ZXh0ID0gdXNlU2VsZWN0RmxvYXRpbmdDb250ZXh0KCk7XG4gIGNvbnN0IHtcbiAgICBzaWRlLFxuICAgIGFsaWduLFxuICAgIGFsaWduSXRlbVdpdGhUcmlnZ2VyQWN0aXZlLFxuICAgIGlzUG9zaXRpb25lZCxcbiAgICBzZXRDb250cm9sbGVkQWxpZ25JdGVtV2l0aFRyaWdnZXJcbiAgfSA9IHVzZVNlbGVjdFBvc2l0aW9uZXJDb250ZXh0KCk7XG4gIGNvbnN0IGluc2lkZVRvb2xiYXIgPSB1c2VUb29sYmFyUm9vdENvbnRleHQodHJ1ZSkgIT0gbnVsbDtcbiAgY29uc3QgZGlyZWN0aW9uID0gdXNlRGlyZWN0aW9uKCk7XG4gIGNvbnN0IHtcbiAgICBub25jZSxcbiAgICBkaXNhYmxlU3R5bGVFbGVtZW50c1xuICB9ID0gdXNlQ1NQQ29udGV4dCgpO1xuICBjb25zdCBpZCA9IHN0b3JlLnVzZVN0YXRlKCdpZCcpO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3Qgb3Blbk1ldGhvZCA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuTWV0aG9kJyk7XG4gIGNvbnN0IG1vdW50ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbW91bnRlZCcpO1xuICBjb25zdCBwb3B1cFByb3BzID0gc3RvcmUudXNlU3RhdGUoJ3BvcHVwUHJvcHMnKTtcbiAgY29uc3QgdHJhbnNpdGlvblN0YXR1cyA9IHN0b3JlLnVzZVN0YXRlKCd0cmFuc2l0aW9uU3RhdHVzJyk7XG4gIGNvbnN0IHRyaWdnZXJFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ3RyaWdnZXJFbGVtZW50Jyk7XG4gIGNvbnN0IHBvc2l0aW9uZXJFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ3Bvc2l0aW9uZXJFbGVtZW50Jyk7XG4gIGNvbnN0IGxpc3RFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ2xpc3RFbGVtZW50Jyk7XG4gIGNvbnN0IHJlYWNoZWRNYXhIZWlnaHRSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBjb25zdCBpbml0aWFsUGxhY2VkUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3Qgb3JpZ2luYWxQb3NpdGlvbmVyU3R5bGVzUmVmID0gUmVhY3QudXNlUmVmKHt9KTtcbiAgY29uc3Qgc2Nyb2xsQXJyb3dGcmFtZSA9IHVzZUFuaW1hdGlvbkZyYW1lKCk7XG4gIGNvbnN0IGhhbmRsZVNjcm9sbCA9IHVzZVN0YWJsZUNhbGxiYWNrKHNjcm9sbGVyID0+IHtcbiAgICBpZiAoIXBvc2l0aW9uZXJFbGVtZW50IHx8ICFzdG9yZS5jb250ZXh0LnBvcHVwUmVmLmN1cnJlbnQgfHwgIWluaXRpYWxQbGFjZWRSZWYuY3VycmVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBpc1RvcFBvc2l0aW9uZWQgPSBwb3NpdGlvbmVyRWxlbWVudC5zdHlsZS50b3AgPT09ICcwcHgnO1xuICAgIGNvbnN0IGlzQm90dG9tUG9zaXRpb25lZCA9IHBvc2l0aW9uZXJFbGVtZW50LnN0eWxlLmJvdHRvbSA9PT0gJzBweCc7XG4gICAgaWYgKHJlYWNoZWRNYXhIZWlnaHRSZWYuY3VycmVudCB8fCAhYWxpZ25JdGVtV2l0aFRyaWdnZXJBY3RpdmUgfHwgIWlzVG9wUG9zaXRpb25lZCAmJiAhaXNCb3R0b21Qb3NpdGlvbmVkKSB7XG4gICAgICBzdG9yZS5jb250ZXh0LmhhbmRsZVNjcm9sbEFycm93VmlzaWJpbGl0eShzY3JvbGxlcik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHNjYWxlID0gZ2V0U2NhbGUocG9zaXRpb25lckVsZW1lbnQpO1xuICAgIGNvbnN0IGN1cnJlbnRIZWlnaHQgPSBub3JtYWxpemVTaXplKHBvc2l0aW9uZXJFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodCwgJ3knLCBzY2FsZSk7XG4gICAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChwb3NpdGlvbmVyRWxlbWVudCk7XG4gICAgY29uc3Qgd2luID0gb3duZXJXaW5kb3cocG9zaXRpb25lckVsZW1lbnQpO1xuICAgIGNvbnN0IHBvc2l0aW9uZXJTdHlsZXMgPSB3aW4uZ2V0Q29tcHV0ZWRTdHlsZShwb3NpdGlvbmVyRWxlbWVudCk7XG4gICAgY29uc3QgbWFyZ2luVG9wID0gcGFyc2VGbG9hdChwb3NpdGlvbmVyU3R5bGVzLm1hcmdpblRvcCk7XG4gICAgY29uc3QgbWFyZ2luQm90dG9tID0gcGFyc2VGbG9hdChwb3NpdGlvbmVyU3R5bGVzLm1hcmdpbkJvdHRvbSk7XG4gICAgY29uc3QgbWF4UG9wdXBIZWlnaHQgPSBnZXRNYXhQb3B1cEhlaWdodCh3aW4uZ2V0Q29tcHV0ZWRTdHlsZShzdG9yZS5jb250ZXh0LnBvcHVwUmVmLmN1cnJlbnQpKTtcbiAgICBjb25zdCBtYXhBdmFpbGFibGVIZWlnaHQgPSBNYXRoLm1pbihkb2MuZG9jdW1lbnRFbGVtZW50LmNsaWVudEhlaWdodCAtIG1hcmdpblRvcCAtIG1hcmdpbkJvdHRvbSwgbWF4UG9wdXBIZWlnaHQpO1xuICAgIGNvbnN0IHNjcm9sbFRvcCA9IHNjcm9sbGVyLnNjcm9sbFRvcDtcbiAgICBjb25zdCBtYXhTY3JvbGxUb3AgPSBnZXRNYXhTY3JvbGxUb3Aoc2Nyb2xsZXIpO1xuXG4gICAgLy8gYEluZmluaXR5YCByZXF1ZXN0cyBhIHNjcm9sbCB0byB0aGUgcmVjb21wdXRlZCBtYXhpbXVtIG9mZnNldC5cbiAgICBsZXQgbmV4dFNjcm9sbFRvcCA9IG51bGw7XG4gICAgY29uc3Qgc2V0SGVpZ2h0ID0gaGVpZ2h0ID0+IHtcbiAgICAgIHBvc2l0aW9uZXJFbGVtZW50LnN0eWxlLmhlaWdodCA9IGAke2hlaWdodH1weGA7XG4gICAgfTtcbiAgICBjb25zdCBkaWZmID0gaXNUb3BQb3NpdGlvbmVkID8gbWF4U2Nyb2xsVG9wIC0gc2Nyb2xsVG9wIDogc2Nyb2xsVG9wO1xuICAgIGNvbnN0IG5leHRIZWlnaHQgPSBNYXRoLm1pbihjdXJyZW50SGVpZ2h0ICsgZGlmZiwgbWF4QXZhaWxhYmxlSGVpZ2h0KTtcbiAgICBpZiAoZGlmZiA8PSBTQ1JPTExfRURHRV9UT0xFUkFOQ0VfUFgpIHtcbiAgICAgIGNvbnN0IGhlaWdodERlbHRhID0gY2xhbXAoZGlmZiwgMCwgbWF4QXZhaWxhYmxlSGVpZ2h0IC0gY3VycmVudEhlaWdodCk7XG4gICAgICBpZiAoaGVpZ2h0RGVsdGEgPiAwKSB7XG4gICAgICAgIC8vIENvbnN1bWUgdGhlIHJlbWFpbmluZyBzY3JvbGwgaW4gaGVpZ2h0LlxuICAgICAgICBzZXRIZWlnaHQoY3VycmVudEhlaWdodCArIGhlaWdodERlbHRhKTtcbiAgICAgIH1cbiAgICAgIHNjcm9sbGVyLnNjcm9sbFRvcCA9IGlzVG9wUG9zaXRpb25lZCA/IG1heFNjcm9sbFRvcCA6IDA7XG4gICAgICBpZiAobWF4QXZhaWxhYmxlSGVpZ2h0IC0gKGN1cnJlbnRIZWlnaHQgKyBoZWlnaHREZWx0YSkgPD0gU0NST0xMX0VER0VfVE9MRVJBTkNFX1BYKSB7XG4gICAgICAgIHJlYWNoZWRNYXhIZWlnaHRSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICB9XG4gICAgICBzdG9yZS5jb250ZXh0LmhhbmRsZVNjcm9sbEFycm93VmlzaWJpbGl0eShzY3JvbGxlcik7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChtYXhBdmFpbGFibGVIZWlnaHQgLSBuZXh0SGVpZ2h0ID4gU0NST0xMX0VER0VfVE9MRVJBTkNFX1BYKSB7XG4gICAgICBuZXh0U2Nyb2xsVG9wID0gaXNUb3BQb3NpdGlvbmVkID8gSW5maW5pdHkgOiAwO1xuICAgIH0gZWxzZSBpZiAoaXNCb3R0b21Qb3NpdGlvbmVkICYmIHNjcm9sbFRvcCA8IG1heFNjcm9sbFRvcCkge1xuICAgICAgY29uc3Qgb3ZlcnNob290ID0gY3VycmVudEhlaWdodCArIGRpZmYgLSBtYXhBdmFpbGFibGVIZWlnaHQ7XG4gICAgICBuZXh0U2Nyb2xsVG9wID0gc2Nyb2xsVG9wIC0gKGRpZmYgLSBvdmVyc2hvb3QpO1xuICAgIH1cbiAgICBjb25zdCBuZXh0UG9zaXRpb25lckhlaWdodCA9IE1hdGguY2VpbChuZXh0SGVpZ2h0KTtcbiAgICBpZiAobmV4dFBvc2l0aW9uZXJIZWlnaHQgIT09IDApIHtcbiAgICAgIHNldEhlaWdodChuZXh0UG9zaXRpb25lckhlaWdodCk7XG4gICAgfVxuICAgIGlmIChuZXh0U2Nyb2xsVG9wICE9IG51bGwpIHtcbiAgICAgIC8vIFJlY29tcHV0ZSBib3VuZHMgYWZ0ZXIgcmVzaXppbmcgKGNsaWVudEhlaWdodCBsaWtlbHkgY2hhbmdlZCkuXG4gICAgICBjb25zdCB0YXJnZXQgPSBjbGFtcChuZXh0U2Nyb2xsVG9wLCAwLCBnZXRNYXhTY3JvbGxUb3Aoc2Nyb2xsZXIpKTtcblxuICAgICAgLy8gQXZvaWQgYWRqdXN0bWVudHMgdGhhdCByZS10cmlnZ2VyIHNjcm9sbCBldmVudHMgZm9yZXZlci5cbiAgICAgIGlmIChNYXRoLmFicyhzY3JvbGxlci5zY3JvbGxUb3AgLSB0YXJnZXQpID4gU0NST0xMX0VER0VfVE9MRVJBTkNFX1BYKSB7XG4gICAgICAgIHNjcm9sbGVyLnNjcm9sbFRvcCA9IHRhcmdldDtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKG5leHRQb3NpdGlvbmVySGVpZ2h0ID49IG1heEF2YWlsYWJsZUhlaWdodCAtIFNDUk9MTF9FREdFX1RPTEVSQU5DRV9QWCkge1xuICAgICAgcmVhY2hlZE1heEhlaWdodFJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICB9XG4gICAgc3RvcmUuY29udGV4dC5oYW5kbGVTY3JvbGxBcnJvd1Zpc2liaWxpdHkoc2Nyb2xsZXIpO1xuICB9KTtcbiAgUmVhY3QudXNlSW1wZXJhdGl2ZUhhbmRsZShzdG9yZS5jb250ZXh0LnNjcm9sbEhhbmRsZXJSZWYsICgpID0+IGhhbmRsZVNjcm9sbCwgW2hhbmRsZVNjcm9sbF0pO1xuICB1c2VPcGVuQ2hhbmdlQ29tcGxldGUoe1xuICAgIG9wZW4sXG4gICAgcmVmOiBzdG9yZS5jb250ZXh0LnBvcHVwUmVmLFxuICAgIG9uQ29tcGxldGUoKSB7XG4gICAgICBpZiAob3Blbikge1xuICAgICAgICBzdG9yZS5jb250ZXh0Lm9uT3BlbkNoYW5nZUNvbXBsZXRlKHRydWUpO1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIG9wZW4sXG4gICAgdHJhbnNpdGlvblN0YXR1cyxcbiAgICBzaWRlLFxuICAgIGFsaWduXG4gIH07XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFwb3NpdGlvbmVyRWxlbWVudCB8fCAhc3RvcmUuY29udGV4dC5wb3B1cFJlZi5jdXJyZW50IHx8IE9iamVjdC5rZXlzKG9yaWdpbmFsUG9zaXRpb25lclN0eWxlc1JlZi5jdXJyZW50KS5sZW5ndGgpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgb3JpZ2luYWxQb3NpdGlvbmVyU3R5bGVzUmVmLmN1cnJlbnQgPSB7XG4gICAgICB0b3A6IHBvc2l0aW9uZXJFbGVtZW50LnN0eWxlLnRvcCB8fCAnMCcsXG4gICAgICBsZWZ0OiBwb3NpdGlvbmVyRWxlbWVudC5zdHlsZS5sZWZ0IHx8ICcwJyxcbiAgICAgIHJpZ2h0OiBwb3NpdGlvbmVyRWxlbWVudC5zdHlsZS5yaWdodCxcbiAgICAgIGhlaWdodDogcG9zaXRpb25lckVsZW1lbnQuc3R5bGUuaGVpZ2h0LFxuICAgICAgYm90dG9tOiBwb3NpdGlvbmVyRWxlbWVudC5zdHlsZS5ib3R0b20sXG4gICAgICBtaW5IZWlnaHQ6IHBvc2l0aW9uZXJFbGVtZW50LnN0eWxlLm1pbkhlaWdodCxcbiAgICAgIG1heEhlaWdodDogcG9zaXRpb25lckVsZW1lbnQuc3R5bGUubWF4SGVpZ2h0LFxuICAgICAgbWFyZ2luVG9wOiBwb3NpdGlvbmVyRWxlbWVudC5zdHlsZS5tYXJnaW5Ub3AsXG4gICAgICBtYXJnaW5Cb3R0b206IHBvc2l0aW9uZXJFbGVtZW50LnN0eWxlLm1hcmdpbkJvdHRvbVxuICAgIH07XG4gIH0sIFtzdG9yZSwgcG9zaXRpb25lckVsZW1lbnRdKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAob3BlbiB8fCBhbGlnbkl0ZW1XaXRoVHJpZ2dlckFjdGl2ZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpbml0aWFsUGxhY2VkUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICByZWFjaGVkTWF4SGVpZ2h0UmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICBjbGVhclN0eWxlcyhwb3NpdGlvbmVyRWxlbWVudCwgb3JpZ2luYWxQb3NpdGlvbmVyU3R5bGVzUmVmLmN1cnJlbnQpO1xuICB9LCBbb3BlbiwgYWxpZ25JdGVtV2l0aFRyaWdnZXJBY3RpdmUsIHBvc2l0aW9uZXJFbGVtZW50XSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgcG9wdXBFbGVtZW50ID0gc3RvcmUuY29udGV4dC5wb3B1cFJlZi5jdXJyZW50O1xuXG4gICAgLy8gV2FpdCBmb3IgRmxvYXRpbmcgVUkncyBmaXJzdCBwb3NpdGlvbmluZyBwYXNzIGJlZm9yZSByZWFkaW5nIERPTSBnZW9tZXRyeS5cbiAgICAvLyBXZSByZXBsYWNlIHRoZSBmaW5hbCBjb29yZGluYXRlcyBmb3IgYWxpZ25lZCBzZWxlY3RzLCBidXQgc3RpbGwgbmVlZCBtaWRkbGV3YXJlXG4gICAgLy8gbGlrZSBgc2l6ZSgpYCB0byBzZXQgQ1NTIHZhcmlhYmxlcyBzdWNoIGFzIGAtLWFuY2hvci13aWR0aGAuXG4gICAgaWYgKCFvcGVuIHx8ICF0cmlnZ2VyRWxlbWVudCB8fCAhcG9zaXRpb25lckVsZW1lbnQgfHwgIXBvcHVwRWxlbWVudCB8fCBhbGlnbkl0ZW1XaXRoVHJpZ2dlckFjdGl2ZSAmJiAhaXNQb3NpdGlvbmVkIHx8IHN0b3JlLnN0YXRlLnRyYW5zaXRpb25TdGF0dXMgPT09ICdlbmRpbmcnKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGluaXRpYWxQbGFjZWRSZWYuY3VycmVudCA9IHRydWU7XG4gICAgcG9wdXBFbGVtZW50LnN0eWxlLnJlbW92ZVByb3BlcnR5KFNlbGVjdFBvc2l0aW9uZXJDc3NWYXJzLnRyYW5zZm9ybU9yaWdpbik7XG4gICAgaWYgKCFhbGlnbkl0ZW1XaXRoVHJpZ2dlckFjdGl2ZSkge1xuICAgICAgLy8gVGhlIHdyYXBwZXIgc3VwcGxpZXMgdGhlIHNjcm9sbGVyOiB0aGUgbGlzdCBvd25zIHNjcm9sbGluZyBvbmNlIGl0IGhhcyBtb3VudGVkLCBhbmRcbiAgICAgIC8vIHRoaXMgZWZmZWN0IHJlLXJ1bnMgKGNhbmNlbGxpbmcgdGhlIHN0YWxlIGZyYW1lKSB3aGVuIHRoYXQgaGFwcGVucy5cbiAgICAgIHNjcm9sbEFycm93RnJhbWUucmVxdWVzdCgoKSA9PiBzdG9yZS5jb250ZXh0LmhhbmRsZVNjcm9sbEFycm93VmlzaWJpbGl0eShsaXN0RWxlbWVudCB8fCBwb3B1cEVsZW1lbnQpKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBFbnN1cmUgd2UgcmVtb3ZlIGFueSB0cmFuc2Zvcm1zIHRoYXQgY2FuIGFmZmVjdCB0aGUgbG9jYXRpb24gb2YgdGhlIHBvcHVwXG4gICAgLy8gYW5kIHRoZXJlZm9yZSB0aGUgY2FsY3VsYXRpb25zLlxuICAgIGNvbnN0IHJlc3RvcmVUcmFuc2Zvcm1TdHlsZXMgPSB1bnNldFRyYW5zZm9ybVN0eWxlcyhwb3B1cEVsZW1lbnQpO1xuICAgIHRyeSB7XG4gICAgICBsZXQgdGV4dEVsZW1lbnQgPSBzdG9yZS5jb250ZXh0LnNlbGVjdGVkSXRlbVRleHRSZWYuY3VycmVudDtcbiAgICAgIGlmICghdGV4dEVsZW1lbnQ/LmlzQ29ubmVjdGVkKSB7XG4gICAgICAgIGNvbnN0IGhhc1NlbGVjdGVkVmFsdWUgPSBzdG9yZS5zZWxlY3QoJ2hhc1NlbGVjdGVkVmFsdWUnKTtcbiAgICAgICAgdGV4dEVsZW1lbnQgPSAhaGFzU2VsZWN0ZWRWYWx1ZSAmJiBzdG9yZS5jb250ZXh0LmZpcnN0SXRlbVRleHRSZWYuY3VycmVudD8uaXNDb25uZWN0ZWQgPyBzdG9yZS5jb250ZXh0LmZpcnN0SXRlbVRleHRSZWYuY3VycmVudCA6IG51bGw7XG4gICAgICB9XG4gICAgICBjb25zdCB2YWx1ZUVsZW1lbnQgPSBzdG9yZS5jb250ZXh0LnZhbHVlUmVmLmN1cnJlbnQ7XG4gICAgICBjb25zdCB3aW4gPSBvd25lcldpbmRvdyhwb3NpdGlvbmVyRWxlbWVudCk7XG4gICAgICBjb25zdCBwb3NpdGlvbmVyU3R5bGVzID0gd2luLmdldENvbXB1dGVkU3R5bGUocG9zaXRpb25lckVsZW1lbnQpO1xuICAgICAgY29uc3QgcG9wdXBTdHlsZXMgPSB3aW4uZ2V0Q29tcHV0ZWRTdHlsZShwb3B1cEVsZW1lbnQpO1xuICAgICAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudCh0cmlnZ2VyRWxlbWVudCk7XG4gICAgICBjb25zdCBzY2FsZSA9IGdldFNjYWxlKHRyaWdnZXJFbGVtZW50KTtcbiAgICAgIGNvbnN0IHRyaWdnZXJSZWN0ID0gbm9ybWFsaXplUmVjdCh0cmlnZ2VyRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSwgc2NhbGUpO1xuICAgICAgY29uc3QgcG9zaXRpb25lclJlY3QgPSBub3JtYWxpemVSZWN0KHBvc2l0aW9uZXJFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLCBzY2FsZSk7XG4gICAgICBjb25zdCB0cmlnZ2VySGVpZ2h0ID0gdHJpZ2dlclJlY3QuaGVpZ2h0O1xuICAgICAgY29uc3Qgc2Nyb2xsZXIgPSBsaXN0RWxlbWVudCB8fCBwb3B1cEVsZW1lbnQ7XG4gICAgICBjb25zdCBzY3JvbGxIZWlnaHQgPSBzY3JvbGxlci5zY3JvbGxIZWlnaHQ7XG4gICAgICBjb25zdCBib3JkZXJCb3R0b20gPSBwYXJzZUZsb2F0KHBvcHVwU3R5bGVzLmJvcmRlckJvdHRvbVdpZHRoKTtcbiAgICAgIC8vIFRoZSBgfHwgTmAgZmFsbGJhY2tzIGNvdmVyIGFuIHVuc2V0L2BhdXRvYCB2YWx1ZSAocGFyc2VzIHRvIGBOYU5gKS4gTm90ZSBhIGxpdGVyYWwgYDBgXG4gICAgICAvLyBhbHNvIHJlc29sdmVzIHRvIHRoZSBmYWxsYmFjaywgc28gYW4gZXhwbGljaXQgYG1hcmdpbjogMGAgb3IgYG1pbi1oZWlnaHQ6IDBgIHN0aWxsIHRha2VzXG4gICAgICAvLyB0aGUgZGVmYXVsdCBiZWxvdy5cbiAgICAgIGNvbnN0IG1hcmdpblRvcCA9IHBhcnNlRmxvYXQocG9zaXRpb25lclN0eWxlcy5tYXJnaW5Ub3ApIHx8IDEwO1xuICAgICAgY29uc3QgbWFyZ2luQm90dG9tID0gcGFyc2VGbG9hdChwb3NpdGlvbmVyU3R5bGVzLm1hcmdpbkJvdHRvbSkgfHwgMTA7XG4gICAgICBjb25zdCBtaW5IZWlnaHQgPSBwYXJzZUZsb2F0KHBvc2l0aW9uZXJTdHlsZXMubWluSGVpZ2h0KSB8fCAxMDA7XG4gICAgICBjb25zdCBtYXhQb3B1cEhlaWdodCA9IGdldE1heFBvcHVwSGVpZ2h0KHBvcHVwU3R5bGVzKTtcbiAgICAgIGNvbnN0IHBhZGRpbmdMZWZ0ID0gNTtcbiAgICAgIGNvbnN0IHBhZGRpbmdSaWdodCA9IDU7XG4gICAgICBjb25zdCB0cmlnZ2VyQ29sbGlzaW9uVGhyZXNob2xkID0gMjA7XG4gICAgICBjb25zdCB2aWV3cG9ydEhlaWdodCA9IGRvYy5kb2N1bWVudEVsZW1lbnQuY2xpZW50SGVpZ2h0IC0gbWFyZ2luVG9wIC0gbWFyZ2luQm90dG9tO1xuICAgICAgY29uc3Qgdmlld3BvcnRXaWR0aCA9IGRvYy5kb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGg7XG4gICAgICBjb25zdCBhdmFpbGFibGVTcGFjZUJlbmVhdGhUcmlnZ2VyID0gdmlld3BvcnRIZWlnaHQgLSB0cmlnZ2VyUmVjdC5ib3R0b20gKyB0cmlnZ2VySGVpZ2h0O1xuICAgICAgbGV0IHRleHRSZWN0O1xuICAgICAgbGV0IGFsaWduZWRMZWZ0ID0gZGlyZWN0aW9uID09PSAncnRsJyA/IHRyaWdnZXJSZWN0LnJpZ2h0IC0gcG9zaXRpb25lclJlY3Qud2lkdGggOiB0cmlnZ2VyUmVjdC5sZWZ0O1xuICAgICAgbGV0IG9mZnNldFkgPSAwO1xuICAgICAgaWYgKHRleHRFbGVtZW50ICYmIHZhbHVlRWxlbWVudCkge1xuICAgICAgICBjb25zdCB2YWx1ZVJlY3QgPSBub3JtYWxpemVSZWN0KHZhbHVlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSwgc2NhbGUpO1xuICAgICAgICB0ZXh0UmVjdCA9IG5vcm1hbGl6ZVJlY3QodGV4dEVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCksIHNjYWxlKTtcbiAgICAgICAgYWxpZ25lZExlZnQgPSBwb3NpdGlvbmVyUmVjdC5sZWZ0ICsgKGRpcmVjdGlvbiA9PT0gJ3J0bCcgPyB2YWx1ZVJlY3QucmlnaHQgLSB0ZXh0UmVjdC5yaWdodCA6IHZhbHVlUmVjdC5sZWZ0IC0gdGV4dFJlY3QubGVmdCk7XG4gICAgICAgIGNvbnN0IHZhbHVlQ2VudGVyRnJvbVRyaWdnZXJUb3AgPSB2YWx1ZVJlY3QudG9wIC0gdHJpZ2dlclJlY3QudG9wICsgdmFsdWVSZWN0LmhlaWdodCAvIDI7XG4gICAgICAgIGNvbnN0IHRleHRDZW50ZXJGcm9tUG9zaXRpb25lclRvcCA9IHRleHRSZWN0LnRvcCAtIHBvc2l0aW9uZXJSZWN0LnRvcCArIHRleHRSZWN0LmhlaWdodCAvIDI7XG4gICAgICAgIG9mZnNldFkgPSB0ZXh0Q2VudGVyRnJvbVBvc2l0aW9uZXJUb3AgLSB2YWx1ZUNlbnRlckZyb21UcmlnZ2VyVG9wO1xuICAgICAgfVxuICAgICAgY29uc3QgaWRlYWxIZWlnaHQgPSBhdmFpbGFibGVTcGFjZUJlbmVhdGhUcmlnZ2VyICsgb2Zmc2V0WSArIG1hcmdpbkJvdHRvbSArIGJvcmRlckJvdHRvbTtcbiAgICAgIGxldCBoZWlnaHQgPSBNYXRoLm1pbih2aWV3cG9ydEhlaWdodCwgaWRlYWxIZWlnaHQpO1xuICAgICAgY29uc3QgbWF4SGVpZ2h0ID0gdmlld3BvcnRIZWlnaHQgLSBtYXJnaW5Ub3AgLSBtYXJnaW5Cb3R0b207XG4gICAgICBjb25zdCBzY3JvbGxUb3AgPSBpZGVhbEhlaWdodCAtIGhlaWdodDtcbiAgICAgIGNvbnN0IG1heFJpZ2h0ID0gdmlld3BvcnRXaWR0aCAtIHBhZGRpbmdSaWdodDtcbiAgICAgIHBvc2l0aW9uZXJFbGVtZW50LnN0eWxlLmxlZnQgPSBgJHtjbGFtcChhbGlnbmVkTGVmdCwgcGFkZGluZ0xlZnQsIG1heFJpZ2h0IC0gcG9zaXRpb25lclJlY3Qud2lkdGgpfXB4YDtcbiAgICAgIHBvc2l0aW9uZXJFbGVtZW50LnN0eWxlLmhlaWdodCA9IGAke2hlaWdodH1weGA7XG4gICAgICAvLyBgbm9uZWAgKG5vdCB0aGUgaW52YWxpZCBgYXV0b2ApIHNvIHRoZSBleHBsaWNpdCBoZWlnaHQgZ292ZXJucyBpbiBhbGlnbiBtb2RlIGFuZCBpc24ndFxuICAgICAgLy8gY2xhbXBlZCBieSBhIGBtYXgtaGVpZ2h0YCBmcm9tIHVzZXIgQ1NTLlxuICAgICAgcG9zaXRpb25lckVsZW1lbnQuc3R5bGUubWF4SGVpZ2h0ID0gJ25vbmUnO1xuICAgICAgcG9zaXRpb25lckVsZW1lbnQuc3R5bGUubWFyZ2luVG9wID0gYCR7bWFyZ2luVG9wfXB4YDtcbiAgICAgIHBvc2l0aW9uZXJFbGVtZW50LnN0eWxlLm1hcmdpbkJvdHRvbSA9IGAke21hcmdpbkJvdHRvbX1weGA7XG4gICAgICBwb3B1cEVsZW1lbnQuc3R5bGUuaGVpZ2h0ID0gJzEwMCUnO1xuICAgICAgY29uc3QgbWF4U2Nyb2xsVG9wID0gZ2V0TWF4U2Nyb2xsVG9wKHNjcm9sbGVyKTtcbiAgICAgIGNvbnN0IGlzVG9wUG9zaXRpb25lZCA9IHNjcm9sbFRvcCA+PSBtYXhTY3JvbGxUb3AgLSBTQ1JPTExfRURHRV9UT0xFUkFOQ0VfUFg7XG4gICAgICBpZiAoaXNUb3BQb3NpdGlvbmVkKSB7XG4gICAgICAgIGhlaWdodCA9IE1hdGgubWluKHZpZXdwb3J0SGVpZ2h0LCBwb3NpdGlvbmVyUmVjdC5oZWlnaHQpIC0gKHNjcm9sbFRvcCAtIG1heFNjcm9sbFRvcCk7XG4gICAgICB9XG5cbiAgICAgIC8vIFdoZW4gdGhlIHRyaWdnZXIgaXMgdG9vIGNsb3NlIHRvIHRoZSB0b3Agb3IgYm90dG9tIG9mIHRoZSB2aWV3cG9ydCwgb3IgdGhlIG1pbkhlaWdodCBpc1xuICAgICAgLy8gcmVhY2hlZCwgd2UgZmFsbGJhY2sgdG8gYWxpZ25pbmcgdGhlIHBvcHVwIHRvIHRoZSB0cmlnZ2VyIGFzIHRoZSBVWCBpcyBwb29yIG90aGVyd2lzZS5cbiAgICAgIGNvbnN0IGZhbGxiYWNrVG9BbGlnblBvcHVwVG9UcmlnZ2VyID0gdHJpZ2dlclJlY3QudG9wIDwgdHJpZ2dlckNvbGxpc2lvblRocmVzaG9sZCB8fCB0cmlnZ2VyUmVjdC5ib3R0b20gPiB2aWV3cG9ydEhlaWdodCAtIHRyaWdnZXJDb2xsaXNpb25UaHJlc2hvbGQgfHwgTWF0aC5jZWlsKGhlaWdodCkgKyBTQ1JPTExfRURHRV9UT0xFUkFOQ0VfUFggPCBNYXRoLm1pbihzY3JvbGxIZWlnaHQsIG1pbkhlaWdodCk7XG5cbiAgICAgIC8vIFNhZmFyaSBkb2Vzbid0IHBvc2l0aW9uIHRoZSBwb3B1cCBjb3JyZWN0bHkgd2hlbiBwaW5jaC16b29tZWQuXG4gICAgICBjb25zdCBpc1BpbmNoWm9vbWVkID0gKHdpbi52aXN1YWxWaWV3cG9ydD8uc2NhbGUgPz8gMSkgIT09IDEgJiYgcGxhdGZvcm0uZW5naW5lLndlYmtpdDtcbiAgICAgIGlmIChmYWxsYmFja1RvQWxpZ25Qb3B1cFRvVHJpZ2dlciB8fCBpc1BpbmNoWm9vbWVkKSB7XG4gICAgICAgIGNsZWFyU3R5bGVzKHBvc2l0aW9uZXJFbGVtZW50LCBvcmlnaW5hbFBvc2l0aW9uZXJTdHlsZXNSZWYuY3VycmVudCk7XG4gICAgICAgIHNldENvbnRyb2xsZWRBbGlnbkl0ZW1XaXRoVHJpZ2dlcihmYWxzZSk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGluaXRpYWxIZWlnaHQgPSBNYXRoLm1heChtaW5IZWlnaHQsIGhlaWdodCk7XG4gICAgICBpZiAoaXNUb3BQb3NpdGlvbmVkKSB7XG4gICAgICAgIGNvbnN0IHRvcE9mZnNldCA9IE1hdGgubWF4KDAsIHZpZXdwb3J0SGVpZ2h0IC0gaWRlYWxIZWlnaHQpO1xuICAgICAgICBwb3NpdGlvbmVyRWxlbWVudC5zdHlsZS50b3AgPSBwb3NpdGlvbmVyUmVjdC5oZWlnaHQgPj0gbWF4SGVpZ2h0ID8gJzAnIDogYCR7dG9wT2Zmc2V0fXB4YDtcbiAgICAgICAgcG9zaXRpb25lckVsZW1lbnQuc3R5bGUuaGVpZ2h0ID0gYCR7aGVpZ2h0fXB4YDtcbiAgICAgICAgc2Nyb2xsZXIuc2Nyb2xsVG9wID0gZ2V0TWF4U2Nyb2xsVG9wKHNjcm9sbGVyKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHBvc2l0aW9uZXJFbGVtZW50LnN0eWxlLmJvdHRvbSA9ICcwJztcbiAgICAgICAgc2Nyb2xsZXIuc2Nyb2xsVG9wID0gc2Nyb2xsVG9wO1xuICAgICAgfVxuICAgICAgaWYgKHRleHRSZWN0KSB7XG4gICAgICAgIGNvbnN0IHBvcHVwVG9wID0gcG9zaXRpb25lclJlY3QudG9wO1xuICAgICAgICBjb25zdCBwb3B1cEhlaWdodCA9IHBvc2l0aW9uZXJSZWN0LmhlaWdodDtcbiAgICAgICAgY29uc3QgdGV4dENlbnRlclkgPSB0ZXh0UmVjdC50b3AgKyB0ZXh0UmVjdC5oZWlnaHQgLyAyO1xuICAgICAgICBjb25zdCBjbGFtcGVkWSA9IGNsYW1wKHBvcHVwSGVpZ2h0ID4gMCA/ICh0ZXh0Q2VudGVyWSAtIHBvcHVwVG9wKSAvIHBvcHVwSGVpZ2h0ICogMTAwIDogNTAsIDAsIDEwMCk7XG4gICAgICAgIHBvcHVwRWxlbWVudC5zdHlsZS5zZXRQcm9wZXJ0eShTZWxlY3RQb3NpdGlvbmVyQ3NzVmFycy50cmFuc2Zvcm1PcmlnaW4sIGA1MCUgJHtjbGFtcGVkWX0lYCk7XG4gICAgICB9XG4gICAgICBpZiAoaW5pdGlhbEhlaWdodCA9PT0gdmlld3BvcnRIZWlnaHQgfHwgaGVpZ2h0ID49IG1heFBvcHVwSGVpZ2h0KSB7XG4gICAgICAgIHJlYWNoZWRNYXhIZWlnaHRSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICB9XG4gICAgICBzdG9yZS5jb250ZXh0LmhhbmRsZVNjcm9sbEFycm93VmlzaWJpbGl0eShzY3JvbGxlcik7XG4gICAgICBpZiAoaGlnaGxpZ2h0SXRlbU9uSG92ZXIgJiYgc3RvcmUuc3RhdGUuc2VsZWN0ZWRJbmRleCA9PT0gbnVsbCAmJiBzdG9yZS5zdGF0ZS5hY3RpdmVJbmRleCA9PT0gbnVsbCAmJiBzdG9yZS5jb250ZXh0Lmxpc3RSZWYuY3VycmVudFswXSAhPSBudWxsKSB7XG4gICAgICAgIHN0b3JlLnNldCgnYWN0aXZlSW5kZXgnLCAwKTtcbiAgICAgIH1cbiAgICB9IGZpbmFsbHkge1xuICAgICAgcmVzdG9yZVRyYW5zZm9ybVN0eWxlcygpO1xuICAgIH1cbiAgfSwgW3N0b3JlLCBvcGVuLCBwb3NpdGlvbmVyRWxlbWVudCwgdHJpZ2dlckVsZW1lbnQsIGFsaWduSXRlbVdpdGhUcmlnZ2VyQWN0aXZlLCBzZXRDb250cm9sbGVkQWxpZ25JdGVtV2l0aFRyaWdnZXIsIHNjcm9sbEFycm93RnJhbWUsIGxpc3RFbGVtZW50LCBoaWdobGlnaHRJdGVtT25Ib3ZlciwgZGlyZWN0aW9uLCBpc1Bvc2l0aW9uZWRdKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWFsaWduSXRlbVdpdGhUcmlnZ2VyQWN0aXZlIHx8ICFwb3NpdGlvbmVyRWxlbWVudCB8fCAhb3Blbikge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgY29uc3Qgd2luID0gb3duZXJXaW5kb3cocG9zaXRpb25lckVsZW1lbnQpO1xuICAgIGZ1bmN0aW9uIGhhbmRsZVJlc2l6ZShldmVudCkge1xuICAgICAgc3RvcmUuY29udGV4dC5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy53aW5kb3dSZXNpemUsIGV2ZW50KSk7XG4gICAgfVxuICAgIHJldHVybiBhZGRFdmVudExpc3RlbmVyKHdpbiwgJ3Jlc2l6ZScsIGhhbmRsZVJlc2l6ZSk7XG4gIH0sIFtzdG9yZSwgYWxpZ25JdGVtV2l0aFRyaWdnZXJBY3RpdmUsIHBvc2l0aW9uZXJFbGVtZW50LCBvcGVuXSk7XG4gIGNvbnN0IGRlZmF1bHRQcm9wcyA9IHtcbiAgICAuLi4obGlzdEVsZW1lbnQgPyB7XG4gICAgICByb2xlOiAncHJlc2VudGF0aW9uJ1xuICAgIH0gOiB7XG4gICAgICByb2xlOiAnbGlzdGJveCcsXG4gICAgICAnYXJpYS1tdWx0aXNlbGVjdGFibGUnOiBtdWx0aXBsZSB8fCB1bmRlZmluZWQsXG4gICAgICAnYXJpYS1yZWFkb25seSc6IHJlYWRPbmx5IHx8IHVuZGVmaW5lZCxcbiAgICAgIGlkOiBgJHtpZH0tbGlzdGBcbiAgICB9KSxcbiAgICBvbktleURvd24oZXZlbnQpIHtcbiAgICAgIGlmIChpbnNpZGVUb29sYmFyICYmIENPTVBPU0lURV9LRVlTLmhhcyhldmVudC5rZXkpKSB7XG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgfVxuICAgIH0sXG4gICAgb25TY3JvbGwoZXZlbnQpIHtcbiAgICAgIGlmIChsaXN0RWxlbWVudCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBoYW5kbGVTY3JvbGwoZXZlbnQuY3VycmVudFRhcmdldCk7XG4gICAgfSxcbiAgICAuLi4oYWxpZ25JdGVtV2l0aFRyaWdnZXJBY3RpdmUgJiYge1xuICAgICAgc3R5bGU6IGxpc3RFbGVtZW50ID8ge1xuICAgICAgICBoZWlnaHQ6ICcxMDAlJ1xuICAgICAgfSA6IExJU1RfRlVOQ1RJT05BTF9TVFlMRVNcbiAgICB9KSxcbiAgICBjbGFzc05hbWU6ICFsaXN0RWxlbWVudCAmJiBhbGlnbkl0ZW1XaXRoVHJpZ2dlckFjdGl2ZSA/IHN0eWxlRGlzYWJsZVNjcm9sbGJhci5jbGFzc05hbWUgOiB1bmRlZmluZWRcbiAgfTtcbiAgY29uc3QgZWxlbWVudCA9IHVzZVJlbmRlckVsZW1lbnQoJ2RpdicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgcmVmOiBbZm9yd2FyZGVkUmVmLCBzdG9yZS5jb250ZXh0LnBvcHVwUmVmXSxcbiAgICBzdGF0ZSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nLFxuICAgIHByb3BzOiBbcG9wdXBQcm9wcywgZGVmYXVsdFByb3BzLCBnZXREaXNhYmxlZE1vdW50VHJhbnNpdGlvblN0eWxlcyh0cmFuc2l0aW9uU3RhdHVzKSwgZWxlbWVudFByb3BzXVxuICB9KTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4cyhSZWFjdC5GcmFnbWVudCwge1xuICAgIGNoaWxkcmVuOiBbIWRpc2FibGVTdHlsZUVsZW1lbnRzICYmIHN0eWxlRGlzYWJsZVNjcm9sbGJhci5nZXRFbGVtZW50KG5vbmNlKSwgLyojX19QVVJFX18qL19qc3goRmxvYXRpbmdGb2N1c01hbmFnZXIsIHtcbiAgICAgIGNvbnRleHQ6IGZsb2F0aW5nUm9vdENvbnRleHQsXG4gICAgICBtb2RhbDogZmFsc2UsXG4gICAgICBkaXNhYmxlZDogIW1vdW50ZWQsXG4gICAgICBvcGVuSW50ZXJhY3Rpb25UeXBlOiBvcGVuTWV0aG9kLFxuICAgICAgcmV0dXJuRm9jdXM6IGZpbmFsRm9jdXMsXG4gICAgICByZXN0b3JlRm9jdXM6IHRydWUsXG4gICAgICBjaGlsZHJlbjogZWxlbWVudFxuICAgIH0pXVxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgU2VsZWN0UG9wdXAuZGlzcGxheU5hbWUgPSBcIlNlbGVjdFBvcHVwXCI7XG5mdW5jdGlvbiBnZXRNYXhQb3B1cEhlaWdodChwb3B1cFN0eWxlcykge1xuICBjb25zdCBtYXhIZWlnaHRTdHlsZSA9IHBvcHVwU3R5bGVzLm1heEhlaWdodDtcbiAgcmV0dXJuIG1heEhlaWdodFN0eWxlLmVuZHNXaXRoKCdweCcpID8gcGFyc2VGbG9hdChtYXhIZWlnaHRTdHlsZSkgfHwgSW5maW5pdHkgOiBJbmZpbml0eTtcbn1cbmZ1bmN0aW9uIGdldE1heFNjcm9sbFRvcChzY3JvbGxlcikge1xuICByZXR1cm4gZ2V0TWF4U2Nyb2xsT2Zmc2V0KHNjcm9sbGVyLnNjcm9sbEhlaWdodCwgc2Nyb2xsZXIuY2xpZW50SGVpZ2h0KTtcbn1cbmZ1bmN0aW9uIGdldFNjYWxlKGVsZW1lbnQpIHtcbiAgLy8gVGhlIHBsYXRmb3JtIEFQSSBpcyBhc3luYy1jYXBhYmxlLCBidXQgdGhlIERPTSBwbGF0Zm9ybSByZXR1cm5zIGEgcGxhaW4gc2NhbGUgb2JqZWN0LlxuICByZXR1cm4gZmxvYXRpbmdQbGF0Zm9ybS5nZXRTY2FsZShlbGVtZW50KTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZVNpemUoc2l6ZSwgYXhpcywgc2NhbGUpIHtcbiAgcmV0dXJuIHNpemUgLyBzY2FsZVtheGlzXTtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZVJlY3QocmVjdCwgc2NhbGUpIHtcbiAgcmV0dXJuIHJlY3RUb0NsaWVudFJlY3Qoe1xuICAgIHg6IG5vcm1hbGl6ZVNpemUocmVjdC54LCAneCcsIHNjYWxlKSxcbiAgICB5OiBub3JtYWxpemVTaXplKHJlY3QueSwgJ3knLCBzY2FsZSksXG4gICAgd2lkdGg6IG5vcm1hbGl6ZVNpemUocmVjdC53aWR0aCwgJ3gnLCBzY2FsZSksXG4gICAgaGVpZ2h0OiBub3JtYWxpemVTaXplKHJlY3QuaGVpZ2h0LCAneScsIHNjYWxlKVxuICB9KTtcbn1cbmNvbnN0IFRSQU5TRk9STV9TVFlMRV9SRVNFVFMgPSBbWyd0cmFuc2Zvcm0nLCAnbm9uZSddLCBbJ3NjYWxlJywgJzEnXSwgWyd0cmFuc2xhdGUnLCAnMCAwJ11dO1xuZnVuY3Rpb24gdW5zZXRUcmFuc2Zvcm1TdHlsZXMocG9wdXBFbGVtZW50KSB7XG4gIGNvbnN0IHtcbiAgICBzdHlsZVxuICB9ID0gcG9wdXBFbGVtZW50O1xuICBjb25zdCBvcmlnaW5hbFN0eWxlcyA9IHt9O1xuICBmb3IgKGNvbnN0IFtwcm9wZXJ0eSwgdmFsdWVdIG9mIFRSQU5TRk9STV9TVFlMRV9SRVNFVFMpIHtcbiAgICBvcmlnaW5hbFN0eWxlc1twcm9wZXJ0eV0gPSBzdHlsZS5nZXRQcm9wZXJ0eVZhbHVlKHByb3BlcnR5KTtcbiAgICBzdHlsZS5zZXRQcm9wZXJ0eShwcm9wZXJ0eSwgdmFsdWUsICdpbXBvcnRhbnQnKTtcbiAgfVxuICByZXR1cm4gKCkgPT4ge1xuICAgIGZvciAoY29uc3QgW3Byb3BlcnR5XSBvZiBUUkFOU0ZPUk1fU1RZTEVfUkVTRVRTKSB7XG4gICAgICBjb25zdCBvcmlnaW5hbFZhbHVlID0gb3JpZ2luYWxTdHlsZXNbcHJvcGVydHldO1xuICAgICAgaWYgKG9yaWdpbmFsVmFsdWUpIHtcbiAgICAgICAgc3R5bGUuc2V0UHJvcGVydHkocHJvcGVydHksIG9yaWdpbmFsVmFsdWUpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3R5bGUucmVtb3ZlUHJvcGVydHkocHJvcGVydHkpO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVNlbGVjdFJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvU2VsZWN0Um9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RQb3NpdGlvbmVyQ29udGV4dCB9IGZyb20gXCIuLi9wb3NpdGlvbmVyL1NlbGVjdFBvc2l0aW9uZXJDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVuZGVyRWxlbWVudCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlUmVuZGVyRWxlbWVudC5tanNcIjtcbmltcG9ydCB7IHN0eWxlRGlzYWJsZVNjcm9sbGJhciB9IGZyb20gXCIuLi8uLi91dGlscy9zdHlsZXMubWpzXCI7XG5pbXBvcnQgeyBMSVNUX0ZVTkNUSU9OQUxfU1RZTEVTIH0gZnJvbSBcIi4uL3BvcHVwL3V0aWxzLm1qc1wiO1xuXG4vKipcbiAqIEEgY29udGFpbmVyIGZvciB0aGUgc2VsZWN0IGl0ZW1zLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBTZWxlY3RdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9zZWxlY3QpXG4gKi9cbmV4cG9ydCBjb25zdCBTZWxlY3RMaXN0ID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gU2VsZWN0TGlzdChjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IHN0b3JlID0gdXNlU2VsZWN0Um9vdENvbnRleHQoKTtcbiAgY29uc3QgbXVsdGlwbGUgPSBzdG9yZS51c2VTdGF0ZSgnbXVsdGlwbGUnKTtcbiAgY29uc3QgcmVhZE9ubHkgPSBzdG9yZS51c2VTdGF0ZSgncmVhZE9ubHknKTtcbiAgY29uc3Qge1xuICAgIGFsaWduSXRlbVdpdGhUcmlnZ2VyQWN0aXZlXG4gIH0gPSB1c2VTZWxlY3RQb3NpdGlvbmVyQ29udGV4dCgpO1xuICBjb25zdCBoYXNTY3JvbGxBcnJvd3MgPSBzdG9yZS51c2VTdGF0ZSgnaGFzU2Nyb2xsQXJyb3dzJyk7XG4gIGNvbnN0IG9wZW5NZXRob2QgPSBzdG9yZS51c2VTdGF0ZSgnb3Blbk1ldGhvZCcpO1xuICBjb25zdCBpZCA9IHN0b3JlLnVzZVN0YXRlKCdpZCcpO1xuICBjb25zdCBkZWZhdWx0UHJvcHMgPSB7XG4gICAgaWQ6IGAke2lkfS1saXN0YCxcbiAgICByb2xlOiAnbGlzdGJveCcsXG4gICAgJ2FyaWEtbXVsdGlzZWxlY3RhYmxlJzogbXVsdGlwbGUgfHwgdW5kZWZpbmVkLFxuICAgICdhcmlhLXJlYWRvbmx5JzogcmVhZE9ubHkgfHwgdW5kZWZpbmVkLFxuICAgIG9uU2Nyb2xsKGV2ZW50KSB7XG4gICAgICBzdG9yZS5jb250ZXh0LnNjcm9sbEhhbmRsZXJSZWYuY3VycmVudD8uKGV2ZW50LmN1cnJlbnRUYXJnZXQpO1xuICAgIH0sXG4gICAgLi4uKGFsaWduSXRlbVdpdGhUcmlnZ2VyQWN0aXZlICYmIHtcbiAgICAgIHN0eWxlOiBMSVNUX0ZVTkNUSU9OQUxfU1RZTEVTXG4gICAgfSksXG4gICAgY2xhc3NOYW1lOiBoYXNTY3JvbGxBcnJvd3MgJiYgb3Blbk1ldGhvZCAhPT0gJ3RvdWNoJyA/IHN0eWxlRGlzYWJsZVNjcm9sbGJhci5jbGFzc05hbWUgOiB1bmRlZmluZWRcbiAgfTtcbiAgY29uc3Qgc2V0TGlzdEVsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZVNldHRlcignbGlzdEVsZW1lbnQnKTtcbiAgcmV0dXJuIHVzZVJlbmRlckVsZW1lbnQoJ2RpdicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgcmVmOiBbZm9yd2FyZGVkUmVmLCBzZXRMaXN0RWxlbWVudF0sXG4gICAgcHJvcHM6IFtkZWZhdWx0UHJvcHMsIGVsZW1lbnRQcm9wc11cbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFNlbGVjdExpc3QuZGlzcGxheU5hbWUgPSBcIlNlbGVjdExpc3RcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCBfZm9ybWF0RXJyb3JNZXNzYWdlIGZyb20gXCJAYmFzZS11aS91dGlscy9mb3JtYXRFcnJvck1lc3NhZ2VcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBTZWxlY3RJdGVtQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHVuZGVmaW5lZCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBTZWxlY3RJdGVtQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiU2VsZWN0SXRlbUNvbnRleHRcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VTZWxlY3RJdGVtQ29udGV4dCgpIHtcbiAgY29uc3QgY29udGV4dCA9IFJlYWN0LnVzZUNvbnRleHQoU2VsZWN0SXRlbUNvbnRleHQpO1xuICBpZiAoIWNvbnRleHQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gJ0Jhc2UgVUk6IFNlbGVjdEl0ZW1Db250ZXh0IGlzIG1pc3NpbmcuIFNlbGVjdEl0ZW0gcGFydHMgbXVzdCBiZSBwbGFjZWQgd2l0aGluIDxTZWxlY3QuSXRlbT4uJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoNTcpKTtcbiAgfVxuICByZXR1cm4gY29udGV4dDtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VTZWxlY3RSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L1NlbGVjdFJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQ29tcG9zaXRlTGlzdEl0ZW0gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NvbXBvc2l0ZS9saXN0L3VzZUNvbXBvc2l0ZUxpc3RJdGVtLm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVuZGVyRWxlbWVudCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlUmVuZGVyRWxlbWVudC5tanNcIjtcbmltcG9ydCB7IFNlbGVjdEl0ZW1Db250ZXh0IH0gZnJvbSBcIi4vU2VsZWN0SXRlbUNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VCdXR0b24gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZS1idXR0b24vaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5pbXBvcnQgeyBjb21wYXJlSXRlbUVxdWFsaXR5LCByZW1vdmVJdGVtLCByZXNvbHZlU2VsZWN0ZWRJbmRleCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvaXRlbUVxdWFsaXR5Lm1qc1wiO1xuaW1wb3J0IHsgaXNWaXJ0dWFsQ2xpY2sgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvdXRpbHMvZXZlbnQubWpzXCI7XG5cbi8qKlxuICogQW4gaW5kaXZpZHVhbCBvcHRpb24gaW4gdGhlIHNlbGVjdCBwb3B1cC5cbiAqIFJlbmRlcnMgYSBgPGRpdj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgU2VsZWN0XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvc2VsZWN0KVxuICovXG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZXhwb3J0IGNvbnN0IFNlbGVjdEl0ZW0gPSAvKiNfX1BVUkVfXyovUmVhY3QubWVtbygvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBTZWxlY3RJdGVtKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgdmFsdWU6IGl0ZW1WYWx1ZSA9IG51bGwsXG4gICAgbGFiZWwsXG4gICAgZGlzYWJsZWQ6IGRpc2FibGVkUHJvcCA9IGZhbHNlLFxuICAgIG5hdGl2ZUJ1dHRvbiA9IGZhbHNlLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IHRleHRSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGxpc3RJdGVtID0gdXNlQ29tcG9zaXRlTGlzdEl0ZW0oe1xuICAgIGd1ZXNzOiB0cnVlLFxuICAgIGxhYmVsLFxuICAgIHRleHRSZWZcbiAgfSk7XG4gIGNvbnN0IHN0b3JlID0gdXNlU2VsZWN0Um9vdENvbnRleHQoKTtcbiAgY29uc3Qge1xuICAgIHByb3BzOiBpdGVtUHJvcHMsXG4gICAgbXVsdGlwbGUsXG4gICAgZGlzYWJsZWQ6IHNlbGVjdERpc2FibGVkLFxuICAgIHJlYWRPbmx5LFxuICAgIGlzSXRlbUVxdWFsVG9WYWx1ZVxuICB9ID0gc3RvcmUudXNlU3RhdGUoJ2l0ZW1Sb290Jyk7XG4gIGNvbnN0IGRpc2FibGVkID0gc2VsZWN0RGlzYWJsZWQgfHwgZGlzYWJsZWRQcm9wO1xuICBjb25zdCBoaWdobGlnaHRlZCA9IHN0b3JlLnVzZVN0YXRlKCdpc0FjdGl2ZScsIGxpc3RJdGVtLmluZGV4KTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IHNlbGVjdGVkID0gc3RvcmUudXNlU3RhdGUoJ2lzU2VsZWN0ZWQnLCBpdGVtVmFsdWUpO1xuICBjb25zdCBzZWxlY3RlZEJ5Rm9jdXMgPSBzdG9yZS51c2VTdGF0ZSgnaXNTZWxlY3RlZEJ5Rm9jdXMnLCBsaXN0SXRlbS5pbmRleCk7XG4gIGNvbnN0IGluZGV4ID0gbGlzdEl0ZW0uaW5kZXg7XG4gIGNvbnN0IGl0ZW1SZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgdmFsdWVzID0gc3RvcmUuY29udGV4dC52YWx1ZXNSZWYuY3VycmVudDtcbiAgICB2YWx1ZXNbaW5kZXhdID0gaXRlbVZhbHVlO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBkZWxldGUgdmFsdWVzW2luZGV4XTtcbiAgICB9O1xuICB9LCBbaW5kZXgsIGl0ZW1WYWx1ZSwgc3RvcmVdKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBzZWxlY3RlZFZhbHVlID0gc3RvcmUuc3RhdGUudmFsdWU7XG4gICAgY29uc3QgY3VycmVudEluZGV4ID0gc3RvcmUuc3RhdGUuc2VsZWN0ZWRJbmRleDtcbiAgICBsZXQgbmV4dEluZGV4ID0gY3VycmVudEluZGV4O1xuICAgIGxldCBjbGFpbXM7XG4gICAgaWYgKG11bHRpcGxlICYmIEFycmF5LmlzQXJyYXkoc2VsZWN0ZWRWYWx1ZSkpIHtcbiAgICAgIC8vIFRoZSBjbGFpbWluZyBpdGVtIGFsc28gb3ducyB0aGUgdGV4dCByZWYgdGhhdCBhbGlnbnMgdGhlIHBvcHVwLlxuICAgICAgbmV4dEluZGV4ID0gcmVzb2x2ZVNlbGVjdGVkSW5kZXgoaW5kZXgsIGl0ZW1WYWx1ZSwgc3RvcmUuY29udGV4dC52YWx1ZXNSZWYuY3VycmVudCwgc2VsZWN0ZWRWYWx1ZSwgaXNJdGVtRXF1YWxUb1ZhbHVlLCBjdXJyZW50SW5kZXgpO1xuICAgICAgY2xhaW1zID0gbmV4dEluZGV4ID09PSBpbmRleDtcbiAgICAgIGlmIChpbmRleCA9PT0gY3VycmVudEluZGV4ICYmICFjbGFpbXMpIHtcbiAgICAgICAgc3RvcmUuY29udGV4dC5zZWxlY3RlZEl0ZW1UZXh0UmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICBjbGFpbXMgPSBzZWxlY3RlZFZhbHVlICE9PSB1bmRlZmluZWQgJiYgY29tcGFyZUl0ZW1FcXVhbGl0eShpdGVtVmFsdWUsIHNlbGVjdGVkVmFsdWUsIGlzSXRlbUVxdWFsVG9WYWx1ZSk7XG4gICAgICBpZiAoY2xhaW1zKSB7XG4gICAgICAgIG5leHRJbmRleCA9IGluZGV4O1xuICAgICAgfVxuICAgIH1cbiAgICBzdG9yZS5zZXQoJ3NlbGVjdGVkSW5kZXgnLCBuZXh0SW5kZXgpO1xuXG4gICAgLy8gTWFrZSBzdXJlIFNlbGVjdFBvcHVwIGNhbiBtZWFzdXJlIHRoZSBzZWxlY3RlZCBpdGVtIG9uIGZpcnN0IG9wZW4uXG4gICAgLy8gU2VsZWN0SXRlbVRleHQgY2FuIHN0aWxsIHVwZGF0ZSB0aGlzIHJlZiBsYXRlciB3aGVuIGZvY3VzIG1vdmVzLlxuICAgIGlmIChjbGFpbXMgJiYgdGV4dFJlZi5jdXJyZW50KSB7XG4gICAgICBzdG9yZS5jb250ZXh0LnNlbGVjdGVkSXRlbVRleHRSZWYuY3VycmVudCA9IHRleHRSZWYuY3VycmVudDtcbiAgICB9XG4gIH0sIFtpbmRleCwgbXVsdGlwbGUsIGlzSXRlbUVxdWFsVG9WYWx1ZSwgc3RvcmUsIGl0ZW1WYWx1ZV0pO1xuICBjb25zdCBwb2ludGVyVHlwZVJlZiA9IFJlYWN0LnVzZVJlZignbW91c2UnKTtcbiAgY29uc3QgYWxsb3dNb3VzZVNlbGVjdGlvblJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IHtcbiAgICBnZXRCdXR0b25Qcm9wcyxcbiAgICBidXR0b25SZWZcbiAgfSA9IHVzZUJ1dHRvbih7XG4gICAgZGlzYWJsZWQsXG4gICAgZm9jdXNhYmxlV2hlbkRpc2FibGVkOiB0cnVlLFxuICAgIG5hdGl2ZTogbmF0aXZlQnV0dG9uLFxuICAgIGNvbXBvc2l0ZTogdHJ1ZVxuICB9KTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgZGlzYWJsZWQsXG4gICAgc2VsZWN0ZWQsXG4gICAgaGlnaGxpZ2h0ZWRcbiAgfTtcbiAgZnVuY3Rpb24gY29tbWl0U2VsZWN0aW9uKGV2ZW50KSB7XG4gICAgLy8gQSBmb3JjZWQtb3BlbiBzZWxlY3QgKGBvcGVuYC9gZGVmYXVsdE9wZW5gKSBjYW4gc3RpbGwgcmVjZWl2ZSBpdGVtIGFjdGl2YXRpb25zIGV2ZW5cbiAgICAvLyB3aGVuIHRoZSByb290IGlzIGRpc2FibGVkIG9yIHJlYWQtb25seSwgc28gZ3VhcmQgdGhlIGNvbW1pdCBoZXJlIHRvby5cbiAgICBpZiAoc2VsZWN0RGlzYWJsZWQgfHwgcmVhZE9ubHkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgc2VsZWN0ZWRWYWx1ZSA9IHN0b3JlLnN0YXRlLnZhbHVlO1xuICAgIGlmIChtdWx0aXBsZSkge1xuICAgICAgY29uc3QgY3VycmVudFZhbHVlID0gQXJyYXkuaXNBcnJheShzZWxlY3RlZFZhbHVlKSA/IHNlbGVjdGVkVmFsdWUgOiBbXTtcbiAgICAgIGNvbnN0IG5leHRWYWx1ZSA9IHNlbGVjdGVkID8gcmVtb3ZlSXRlbShjdXJyZW50VmFsdWUsIGl0ZW1WYWx1ZSwgaXNJdGVtRXF1YWxUb1ZhbHVlKSA6IFsuLi5jdXJyZW50VmFsdWUsIGl0ZW1WYWx1ZV07XG4gICAgICBzdG9yZS5jb250ZXh0LnNldFZhbHVlKG5leHRWYWx1ZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuaXRlbVByZXNzLCBldmVudCkpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdG9yZS5jb250ZXh0LnNldFZhbHVlKGl0ZW1WYWx1ZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuaXRlbVByZXNzLCBldmVudCkpO1xuICAgICAgc3RvcmUuY29udGV4dC5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5pdGVtUHJlc3MsIGV2ZW50KSk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIHJlc2V0RHJhZ01vdmVtZW50KCkge1xuICAgIHN0b3JlLmNvbnRleHQuc2VsZWN0aW9uUmVmLmN1cnJlbnQuZHJhZ1kgPSAwO1xuICB9XG4gIGNvbnN0IGRlZmF1bHRQcm9wcyA9IHtcbiAgICByb2xlOiAnb3B0aW9uJyxcbiAgICAnYXJpYS1zZWxlY3RlZCc6IHNlbGVjdGVkLFxuICAgIHRhYkluZGV4OiBvcGVuICYmIGhpZ2hsaWdodGVkID8gMCA6IC0xLFxuICAgIG9uS2V5RG93bihldmVudCkge1xuICAgICAgc3RvcmUuc2V0KCdhY3RpdmVJbmRleCcsIGluZGV4KTtcbiAgICAgIGlmIChldmVudC5rZXkgPT09ICcgJyAmJiBzdG9yZS5jb250ZXh0LnR5cGluZ1JlZi5jdXJyZW50KSB7XG4gICAgICAgIC8vIGB1c2VCdXR0b25gIHNraXBzIFNwYWNlIGFjdGl2YXRpb24gZm9yIGByb2xlPVwib3B0aW9uXCJgIGl0ZW1zIHdoZW4gdGhlIGtleWRvd25cbiAgICAgICAgLy8gaXMgYGRlZmF1bHRQcmV2ZW50ZWRgLCBrZWVwaW5nIHR5cGVhaGVhZCBzcGFjZXMgZnJvbSBjb21taXR0aW5nIGEgc2VsZWN0aW9uLlxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgfVxuICAgIH0sXG4gICAgb25DbGljayhldmVudCkge1xuICAgICAgY29uc3QgaXNNb3VzZUNsaWNrID0gcG9pbnRlclR5cGVSZWYuY3VycmVudCAhPT0gJ3RvdWNoJztcbiAgICAgIGNvbnN0IGNsaWNrUG9pbnRlclR5cGUgPSBldmVudC5uYXRpdmVFdmVudC5wb2ludGVyVHlwZTtcbiAgICAgIGNvbnN0IGlzVmlydHVhbE1vdXNlQ2xpY2sgPSBpc01vdXNlQ2xpY2sgJiYgaXNWaXJ0dWFsQ2xpY2soZXZlbnQubmF0aXZlRXZlbnQpICYmIChcbiAgICAgIC8vIEdlbmVyaWMgbm8tcG9pbnRlciBgZGV0YWlsID09PSAwYCBjbGlja3Mgc3RheSB0aWVkIHRvIGhpZ2hsaWdodCBzdGF0ZS4gVmlydHVhbFxuICAgICAgLy8gY2xpY2tzIHRoYXQgY2FycnkgYnJvd3NlciBwb2ludGVyIGRhdGEsIGluY2x1ZGluZyBhbiBlbXB0eSBzdHJpbmcgZnJvbSBhc3Npc3RpdmVcbiAgICAgIC8vIHRlY2hub2xvZ3ksIGNhbiBhY3RpdmF0ZSB1bmhpZ2hsaWdodGVkIGl0ZW1zLlxuICAgICAgY2xpY2tQb2ludGVyVHlwZSAhPT0gdW5kZWZpbmVkIHx8IGhpZ2hsaWdodGVkKTtcbiAgICAgIC8vIFdpdGggYWxpZ25JdGVtV2l0aFRyaWdnZXIsIG9wZW5pbmcgY2FuIHBsYWNlIGFuIGl0ZW0gdW5kZXIgdGhlIGN1cnNvci4gUmVhbCBtb3VzZVxuICAgICAgLy8gY2xpY2tzIG11c3Qgc3RhcnQgb24gdGhlIGl0ZW0sIHdoaWxlIHZpcnR1YWwgY2xpY2tzIHJlcHJlc2VudCBleHBsaWNpdCBrZXlib2FyZCBvclxuICAgICAgLy8gYXNzaXN0aXZlIHRlY2hub2xvZ3kgYWN0aXZhdGlvbi5cbiAgICAgIGNvbnN0IGlzSW52YWxpZE1vdXNlQ2xpY2sgPSBpc01vdXNlQ2xpY2sgJiYgIWlzVmlydHVhbE1vdXNlQ2xpY2sgJiYgIWFsbG93TW91c2VTZWxlY3Rpb25SZWYuY3VycmVudDtcbiAgICAgIGFsbG93TW91c2VTZWxlY3Rpb25SZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgaWYgKGRpc2FibGVkIHx8IGlzSW52YWxpZE1vdXNlQ2xpY2spIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29tbWl0U2VsZWN0aW9uKGV2ZW50Lm5hdGl2ZUV2ZW50KTtcbiAgICB9LFxuICAgIG9uUG9pbnRlckVudGVyKGV2ZW50KSB7XG4gICAgICBwb2ludGVyVHlwZVJlZi5jdXJyZW50ID0gZXZlbnQucG9pbnRlclR5cGU7XG4gICAgfSxcbiAgICBvblBvaW50ZXJNb3ZlKGV2ZW50KSB7XG4gICAgICBpZiAoZXZlbnQucG9pbnRlclR5cGUgPT09ICdtb3VzZScgJiYgZXZlbnQuYnV0dG9ucyA9PT0gMSkge1xuICAgICAgICBjb25zdCBzZWxlY3Rpb24gPSBzdG9yZS5jb250ZXh0LnNlbGVjdGlvblJlZi5jdXJyZW50O1xuICAgICAgICBzZWxlY3Rpb24uZHJhZ1kgKz0gZXZlbnQubW92ZW1lbnRZO1xuICAgICAgICBpZiAoc2VsZWN0aW9uLmRyYWdZICoqIDIgPj0gNjQpIHtcbiAgICAgICAgICBzZWxlY3Rpb24uYWxsb3dVbnNlbGVjdGVkTW91c2VVcCA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICAgIG9uUG9pbnRlckRvd24oZXZlbnQpIHtcbiAgICAgIHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQgPSBldmVudC5wb2ludGVyVHlwZTtcbiAgICAgIGFsbG93TW91c2VTZWxlY3Rpb25SZWYuY3VycmVudCA9IHRydWU7XG4gICAgICByZXNldERyYWdNb3ZlbWVudCgpO1xuICAgIH0sXG4gICAgb25Nb3VzZVVwKCkge1xuICAgICAgcmVzZXREcmFnTW92ZW1lbnQoKTtcbiAgICAgIGlmIChkaXNhYmxlZCB8fCBwb2ludGVyVHlwZVJlZi5jdXJyZW50ID09PSAndG91Y2gnKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gUmVndWxhciBjbGlja3MgYXJlIGNvbW1pdHRlZCBieSB0aGUgY2xpY2sgZXZlbnQuXG4gICAgICBpZiAoYWxsb3dNb3VzZVNlbGVjdGlvblJlZi5jdXJyZW50KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGRpc2FsbG93U2VsZWN0ZWRNb3VzZVVwID0gIXN0b3JlLmNvbnRleHQuc2VsZWN0aW9uUmVmLmN1cnJlbnQuYWxsb3dTZWxlY3RlZE1vdXNlVXAgJiYgc2VsZWN0ZWQ7XG4gICAgICBjb25zdCBkaXNhbGxvd1Vuc2VsZWN0ZWRNb3VzZVVwID0gIXN0b3JlLmNvbnRleHQuc2VsZWN0aW9uUmVmLmN1cnJlbnQuYWxsb3dVbnNlbGVjdGVkTW91c2VVcCAmJiAhc2VsZWN0ZWQ7XG4gICAgICBpZiAoZGlzYWxsb3dTZWxlY3RlZE1vdXNlVXAgfHwgZGlzYWxsb3dVbnNlbGVjdGVkTW91c2VVcCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBhbGxvd01vdXNlU2VsZWN0aW9uUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgaXRlbVJlZi5jdXJyZW50Py5jbGljaygpO1xuICAgICAgYWxsb3dNb3VzZVNlbGVjdGlvblJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgfVxuICB9O1xuICBjb25zdCBlbGVtZW50ID0gdXNlUmVuZGVyRWxlbWVudCgnZGl2JywgY29tcG9uZW50UHJvcHMsIHtcbiAgICByZWY6IFtidXR0b25SZWYsIGZvcndhcmRlZFJlZiwgbGlzdEl0ZW0ucmVmLCBpdGVtUmVmXSxcbiAgICBzdGF0ZSxcbiAgICBwcm9wczogW2l0ZW1Qcm9wcywgZGVmYXVsdFByb3BzLCBlbGVtZW50UHJvcHMsIGdldEJ1dHRvblByb3BzXVxuICB9KTtcbiAgY29uc3QgY29udGV4dFZhbHVlID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIHNlbGVjdGVkLFxuICAgIGluZGV4LFxuICAgIHRleHRSZWYsXG4gICAgc2VsZWN0ZWRCeUZvY3VzXG4gIH0pLCBbc2VsZWN0ZWQsIGluZGV4LCB0ZXh0UmVmLCBzZWxlY3RlZEJ5Rm9jdXNdKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KFNlbGVjdEl0ZW1Db250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IGNvbnRleHRWYWx1ZSxcbiAgICBjaGlsZHJlbjogZWxlbWVudFxuICB9KTtcbn0pKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFNlbGVjdEl0ZW0uZGlzcGxheU5hbWUgPSBcIlNlbGVjdEl0ZW1cIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVRyYW5zaXRpb25TdGF0dXMgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL3VzZVRyYW5zaXRpb25TdGF0dXMubWpzXCI7XG5pbXBvcnQgeyB1c2VPcGVuQ2hhbmdlQ29tcGxldGUgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL3VzZU9wZW5DaGFuZ2VDb21wbGV0ZS5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB0cmFuc2l0aW9uU3RhdHVzTWFwcGluZyB9IGZyb20gXCIuLi9pbnRlcm5hbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanNcIjtcblxuLy8gVGhlIHB1YmxpYyB3cmFwcGVycyBtb3VudCB0aGlzIGNvbXBvbmVudCBvbmx5IHdoZW4gc2VsZWN0ZWQgb3Iga2VwdCBtb3VudGVkLCBhdm9pZGluZyB0aGVcbi8vIGhvb2sgY29zdHMgZm9yIHVuc2VsZWN0ZWQgaXRlbXMuIFBhc3Mgc2VsZWN0aW9uIGFzIGEgcHJvcCBzbyBtZW1vaXphdGlvbiBvYnNlcnZlcyBjaGFuZ2VzLlxuZXhwb3J0IGNvbnN0IEl0ZW1JbmRpY2F0b3IgPSAvKiNfX1BVUkVfXyovUmVhY3QubWVtbygvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBJdGVtSW5kaWNhdG9yKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAga2VlcE1vdW50ZWQsXG4gICAgc2VsZWN0ZWQsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3QgaW5kaWNhdG9yUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCB7XG4gICAgdHJhbnNpdGlvblN0YXR1cyxcbiAgICBzZXRNb3VudGVkXG4gIH0gPSB1c2VUcmFuc2l0aW9uU3RhdHVzKHNlbGVjdGVkKTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgc2VsZWN0ZWQsXG4gICAgdHJhbnNpdGlvblN0YXR1c1xuICB9O1xuICBjb25zdCBlbGVtZW50ID0gdXNlUmVuZGVyRWxlbWVudCgnc3BhbicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgcmVmOiBbZm9yd2FyZGVkUmVmLCBpbmRpY2F0b3JSZWZdLFxuICAgIHN0YXRlLFxuICAgIHByb3BzOiBbe1xuICAgICAgJ2FyaWEtaGlkZGVuJzogdHJ1ZSxcbiAgICAgIGNoaWxkcmVuOiAn4pyU77iPJ1xuICAgIH0sIGVsZW1lbnRQcm9wc10sXG4gICAgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZzogdHJhbnNpdGlvblN0YXR1c01hcHBpbmdcbiAgfSk7XG4gIHVzZU9wZW5DaGFuZ2VDb21wbGV0ZSh7XG4gICAgYmF0Y2g6IHRydWUsXG4gICAgZW5hYmxlZDogIXNlbGVjdGVkLFxuICAgIG9wZW46IHNlbGVjdGVkLFxuICAgIHJlZjogaW5kaWNhdG9yUmVmLFxuICAgIG9uQ29tcGxldGUoKSB7XG4gICAgICBpZiAoIXNlbGVjdGVkKSB7XG4gICAgICAgIHNldE1vdW50ZWQoZmFsc2UpO1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG4gIHJldHVybiBlbGVtZW50O1xufSkpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgSXRlbUluZGljYXRvci5kaXNwbGF5TmFtZSA9IFwiSXRlbUluZGljYXRvclwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlU2VsZWN0SXRlbUNvbnRleHQgfSBmcm9tIFwiLi4vaXRlbS9TZWxlY3RJdGVtQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IEl0ZW1JbmRpY2F0b3IgfSBmcm9tIFwiLi4vLi4vdXRpbHMvSXRlbUluZGljYXRvci5tanNcIjtcblxuLyoqXG4gKiBJbmRpY2F0ZXMgd2hldGhlciB0aGUgc2VsZWN0IGl0ZW0gaXMgc2VsZWN0ZWQuXG4gKiBSZW5kZXJzIGEgYDxzcGFuPmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBTZWxlY3RdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9zZWxlY3QpXG4gKi9cbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgY29uc3QgU2VsZWN0SXRlbUluZGljYXRvciA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIFNlbGVjdEl0ZW1JbmRpY2F0b3IoY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgc2VsZWN0ZWRcbiAgfSA9IHVzZVNlbGVjdEl0ZW1Db250ZXh0KCk7XG4gIGNvbnN0IHNob3VsZFJlbmRlciA9IGNvbXBvbmVudFByb3BzLmtlZXBNb3VudGVkIHx8IHNlbGVjdGVkO1xuICBpZiAoIXNob3VsZFJlbmRlcikge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChJdGVtSW5kaWNhdG9yLCB7XG4gICAgLi4uY29tcG9uZW50UHJvcHMsXG4gICAgc2VsZWN0ZWQ6IHNlbGVjdGVkLFxuICAgIHJlZjogZm9yd2FyZGVkUmVmXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBTZWxlY3RJdGVtSW5kaWNhdG9yLmRpc3BsYXlOYW1lID0gXCJTZWxlY3RJdGVtSW5kaWNhdG9yXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VTZWxlY3RSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L1NlbGVjdFJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlU2VsZWN0SXRlbUNvbnRleHQgfSBmcm9tIFwiLi4vaXRlbS9TZWxlY3RJdGVtQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5cbi8qKlxuICogQSB0ZXh0IGxhYmVsIG9mIHRoZSBzZWxlY3QgaXRlbS5cbiAqIFJlbmRlcnMgYSBgPGRpdj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgU2VsZWN0XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvc2VsZWN0KVxuICovXG5leHBvcnQgY29uc3QgU2VsZWN0SXRlbVRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QubWVtbygvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBTZWxlY3RJdGVtVGV4dChjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICBpbmRleCxcbiAgICB0ZXh0UmVmLFxuICAgIHNlbGVjdGVkQnlGb2N1c1xuICB9ID0gdXNlU2VsZWN0SXRlbUNvbnRleHQoKTtcbiAgY29uc3Qgc3RvcmUgPSB1c2VTZWxlY3RSb290Q29udGV4dCgpO1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIGNsYXNzTmFtZSxcbiAgICBzdHlsZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCBsb2NhbFJlZiA9IFJlYWN0LnVzZUNhbGxiYWNrKG5vZGUgPT4ge1xuICAgIGlmICghbm9kZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoaW5kZXggPT09IDApIHtcbiAgICAgIHN0b3JlLmNvbnRleHQuZmlyc3RJdGVtVGV4dFJlZi5jdXJyZW50ID0gbm9kZTtcbiAgICB9XG4gICAgaWYgKHNlbGVjdGVkQnlGb2N1cykge1xuICAgICAgc3RvcmUuY29udGV4dC5zZWxlY3RlZEl0ZW1UZXh0UmVmLmN1cnJlbnQgPSBub2RlO1xuICAgIH1cbiAgfSwgW3N0b3JlLCBpbmRleCwgc2VsZWN0ZWRCeUZvY3VzXSk7XG4gIGNvbnN0IGVsZW1lbnQgPSB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHJlZjogW2xvY2FsUmVmLCBmb3J3YXJkZWRSZWYsIHRleHRSZWZdLFxuICAgIHByb3BzOiBlbGVtZW50UHJvcHNcbiAgfSk7XG4gIHJldHVybiBlbGVtZW50O1xufSkpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgU2VsZWN0SXRlbVRleHQuZGlzcGxheU5hbWUgPSBcIlNlbGVjdEl0ZW1UZXh0XCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VTZWxlY3RQb3NpdGlvbmVyQ29udGV4dCB9IGZyb20gXCIuLi9wb3NpdGlvbmVyL1NlbGVjdFBvc2l0aW9uZXJDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlU2VsZWN0Um9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9TZWxlY3RSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHBvcHVwVHJhbnNpdGlvblN0YXRlTWFwcGluZyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5cbi8qKlxuICogRGlzcGxheXMgYW4gZWxlbWVudCBwb3NpdGlvbmVkIGFnYWluc3QgdGhlIHNlbGVjdCBwb3B1cCBhbmNob3IuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIFNlbGVjdF0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL3NlbGVjdClcbiAqL1xuZXhwb3J0IGNvbnN0IFNlbGVjdEFycm93ID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gU2VsZWN0QXJyb3coY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIGNsYXNzTmFtZSxcbiAgICBzdHlsZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCBzdG9yZSA9IHVzZVNlbGVjdFJvb3RDb250ZXh0KCk7XG4gIGNvbnN0IHtcbiAgICBzaWRlLFxuICAgIGFsaWduLFxuICAgIGFycm93UmVmLFxuICAgIGFycm93U3R5bGVzLFxuICAgIGFycm93VW5jZW50ZXJlZCxcbiAgICBhbGlnbkl0ZW1XaXRoVHJpZ2dlckFjdGl2ZVxuICB9ID0gdXNlU2VsZWN0UG9zaXRpb25lckNvbnRleHQoKTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIG9wZW4sXG4gICAgc2lkZSxcbiAgICBhbGlnbixcbiAgICB1bmNlbnRlcmVkOiBhcnJvd1VuY2VudGVyZWRcbiAgfTtcbiAgY29uc3QgZWxlbWVudCA9IHVzZVJlbmRlckVsZW1lbnQoJ2RpdicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgc3RhdGUsXG4gICAgcmVmOiBbYXJyb3dSZWYsIGZvcndhcmRlZFJlZl0sXG4gICAgcHJvcHM6IFt7XG4gICAgICBzdHlsZTogYXJyb3dTdHlsZXMsXG4gICAgICAnYXJpYS1oaWRkZW4nOiB0cnVlXG4gICAgfSwgZWxlbWVudFByb3BzXSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiBwb3B1cFRyYW5zaXRpb25TdGF0ZU1hcHBpbmdcbiAgfSk7XG4gIGlmIChhbGlnbkl0ZW1XaXRoVHJpZ2dlckFjdGl2ZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiBlbGVtZW50O1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBTZWxlY3RBcnJvdy5kaXNwbGF5TmFtZSA9IFwiU2VsZWN0QXJyb3dcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVRpbWVvdXQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VUaW1lb3V0JztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VTZWxlY3RSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L1NlbGVjdFJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlU2VsZWN0UG9zaXRpb25lckNvbnRleHQgfSBmcm9tIFwiLi4vcG9zaXRpb25lci9TZWxlY3RQb3NpdGlvbmVyQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVRyYW5zaXRpb25TdGF0dXMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVRyYW5zaXRpb25TdGF0dXMubWpzXCI7XG5pbXBvcnQgeyB1c2VPcGVuQ2hhbmdlQ29tcGxldGUgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZU9wZW5DaGFuZ2VDb21wbGV0ZS5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB0cmFuc2l0aW9uU3RhdHVzTWFwcGluZyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanNcIjtcbmltcG9ydCB7IGdldE1heFNjcm9sbE9mZnNldCwgbm9ybWFsaXplU2Nyb2xsT2Zmc2V0LCBTQ1JPTExfRURHRV9UT0xFUkFOQ0VfUFggfSBmcm9tIFwiLi4vLi4vdXRpbHMvc2Nyb2xsRWRnZXMubWpzXCI7XG5cbi8qKlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBjb25zdCBTZWxlY3RTY3JvbGxBcnJvdyA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIFNlbGVjdFNjcm9sbEFycm93KGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgZGlyZWN0aW9uLFxuICAgIGtlZXBNb3VudGVkLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IGlzVXAgPSBkaXJlY3Rpb24gPT09ICd1cCc7XG4gIGNvbnN0IHN0b3JlID0gdXNlU2VsZWN0Um9vdENvbnRleHQoKTtcbiAgY29uc3Qge1xuICAgIHNpZGUsXG4gICAgc2Nyb2xsRG93bkFycm93UmVmLFxuICAgIHNjcm9sbFVwQXJyb3dSZWZcbiAgfSA9IHVzZVNlbGVjdFBvc2l0aW9uZXJDb250ZXh0KCk7XG4gIGNvbnN0IHZpc2libGVTZWxlY3RvciA9IGlzVXAgPyAnc2Nyb2xsVXBBcnJvd1Zpc2libGUnIDogJ3Njcm9sbERvd25BcnJvd1Zpc2libGUnO1xuICBjb25zdCBzdGF0ZVZpc2libGUgPSBzdG9yZS51c2VTdGF0ZSh2aXNpYmxlU2VsZWN0b3IpO1xuICBjb25zdCBvcGVuTWV0aG9kID0gc3RvcmUudXNlU3RhdGUoJ29wZW5NZXRob2QnKTtcblxuICAvLyBTY3JvbGwgYXJyb3dzIGFyZSBkaXNhYmxlZCBmb3IgdG91Y2ggbW9kYWxpdHkgYXMgdGhleSBhcmUgYSBob3Zlci1vbmx5IGVsZW1lbnQuXG4gIGNvbnN0IHZpc2libGUgPSBzdGF0ZVZpc2libGUgJiYgb3Blbk1ldGhvZCAhPT0gJ3RvdWNoJztcbiAgY29uc3QgdGltZW91dCA9IHVzZVRpbWVvdXQoKTtcbiAgY29uc3Qgc2Nyb2xsQXJyb3dSZWYgPSBpc1VwID8gc2Nyb2xsVXBBcnJvd1JlZiA6IHNjcm9sbERvd25BcnJvd1JlZjtcbiAgY29uc3Qge1xuICAgIG1vdW50ZWQsXG4gICAgdHJhbnNpdGlvblN0YXR1cyxcbiAgICBzZXRNb3VudGVkXG4gIH0gPSB1c2VUcmFuc2l0aW9uU3RhdHVzKHZpc2libGUpO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIHN0b3JlLmNvbnRleHQuc2Nyb2xsQXJyb3dzTW91bnRlZENvdW50UmVmLmN1cnJlbnQgKz0gMTtcbiAgICBzdG9yZS5zZXQoJ2hhc1Njcm9sbEFycm93cycsIHRydWUpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBzdG9yZS5jb250ZXh0LnNjcm9sbEFycm93c01vdW50ZWRDb3VudFJlZi5jdXJyZW50ID0gTWF0aC5tYXgoMCwgc3RvcmUuY29udGV4dC5zY3JvbGxBcnJvd3NNb3VudGVkQ291bnRSZWYuY3VycmVudCAtIDEpO1xuICAgICAgaWYgKHN0b3JlLmNvbnRleHQuc2Nyb2xsQXJyb3dzTW91bnRlZENvdW50UmVmLmN1cnJlbnQgPT09IDApIHtcbiAgICAgICAgc3RvcmUuc2V0KCdoYXNTY3JvbGxBcnJvd3MnLCBmYWxzZSk7XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW3N0b3JlXSk7XG4gIHVzZU9wZW5DaGFuZ2VDb21wbGV0ZSh7XG4gICAgb3BlbjogdmlzaWJsZSxcbiAgICByZWY6IHNjcm9sbEFycm93UmVmLFxuICAgIG9uQ29tcGxldGUoKSB7XG4gICAgICBpZiAoIXZpc2libGUpIHtcbiAgICAgICAgc2V0TW91bnRlZChmYWxzZSk7XG4gICAgICB9XG4gICAgfVxuICB9KTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgZGlyZWN0aW9uLFxuICAgIHZpc2libGUsXG4gICAgc2lkZSxcbiAgICB0cmFuc2l0aW9uU3RhdHVzXG4gIH07XG4gIGNvbnN0IGRlZmF1bHRQcm9wcyA9IHtcbiAgICAnYXJpYS1oaWRkZW4nOiB0cnVlLFxuICAgIGNoaWxkcmVuOiBpc1VwID8gJ+KWsicgOiAn4pa8JyxcbiAgICBzdHlsZToge1xuICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZSdcbiAgICB9LFxuICAgIG9uTW91c2VNb3ZlKGV2ZW50KSB7XG4gICAgICBpZiAoZXZlbnQubW92ZW1lbnRYID09PSAwICYmIGV2ZW50Lm1vdmVtZW50WSA9PT0gMCB8fCB0aW1lb3V0LmlzU3RhcnRlZCgpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHN0b3JlLnNldCgnYWN0aXZlSW5kZXgnLCBudWxsKTtcbiAgICAgIGZ1bmN0aW9uIHNjcm9sbE5leHRJdGVtKCkge1xuICAgICAgICBjb25zdCBzY3JvbGxlciA9IHN0b3JlLnN0YXRlLmxpc3RFbGVtZW50ID8/IHN0b3JlLmNvbnRleHQucG9wdXBSZWYuY3VycmVudDtcbiAgICAgICAgaWYgKCFzY3JvbGxlcikge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBzdG9yZS5zZXQoJ2FjdGl2ZUluZGV4JywgbnVsbCk7XG4gICAgICAgIHN0b3JlLmNvbnRleHQuaGFuZGxlU2Nyb2xsQXJyb3dWaXNpYmlsaXR5KHNjcm9sbGVyKTtcbiAgICAgICAgY29uc3QgbWF4U2Nyb2xsVG9wID0gZ2V0TWF4U2Nyb2xsT2Zmc2V0KHNjcm9sbGVyLnNjcm9sbEhlaWdodCwgc2Nyb2xsZXIuY2xpZW50SGVpZ2h0KTtcbiAgICAgICAgY29uc3Qgc2Nyb2xsVG9wID0gbm9ybWFsaXplU2Nyb2xsT2Zmc2V0KHNjcm9sbGVyLnNjcm9sbFRvcCwgbWF4U2Nyb2xsVG9wKTtcbiAgICAgICAgY29uc3QgaXNTY3JvbGxlZFRvRWRnZSA9IHNjcm9sbFRvcCA9PT0gKGlzVXAgPyAwIDogbWF4U2Nyb2xsVG9wKTtcbiAgICAgICAgY29uc3QgaXRlbXMgPSBzdG9yZS5jb250ZXh0Lmxpc3RSZWYuY3VycmVudDtcbiAgICAgICAgaWYgKHNjcm9sbFRvcCAhPT0gc2Nyb2xsZXIuc2Nyb2xsVG9wKSB7XG4gICAgICAgICAgc2Nyb2xsZXIuc2Nyb2xsVG9wID0gc2Nyb2xsVG9wO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc1Njcm9sbGVkVG9FZGdlKSB7XG4gICAgICAgICAgdGltZW91dC5jbGVhcigpO1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXRlbXMubGVuZ3RoID4gMCkge1xuICAgICAgICAgIGNvbnN0IHNjcm9sbEFycm93SGVpZ2h0ID0gc2Nyb2xsQXJyb3dSZWYuY3VycmVudD8ub2Zmc2V0SGVpZ2h0IHx8IDA7XG4gICAgICAgICAgc2Nyb2xsZXIuc2Nyb2xsVG9wID0gZ2V0VGFyZ2V0U2Nyb2xsVG9wKGl0ZW1zLCBpc1VwLCBzY3JvbGxUb3AsIHNjcm9sbGVyLmNsaWVudEhlaWdodCwgc2Nyb2xsQXJyb3dIZWlnaHQsIG1heFNjcm9sbFRvcCk7XG4gICAgICAgIH1cbiAgICAgICAgdGltZW91dC5zdGFydCg0MCwgc2Nyb2xsTmV4dEl0ZW0pO1xuICAgICAgfVxuICAgICAgdGltZW91dC5zdGFydCg0MCwgc2Nyb2xsTmV4dEl0ZW0pO1xuICAgIH0sXG4gICAgb25Nb3VzZUxlYXZlKCkge1xuICAgICAgdGltZW91dC5jbGVhcigpO1xuICAgIH1cbiAgfTtcbiAgY29uc3QgZWxlbWVudCA9IHVzZVJlbmRlckVsZW1lbnQoJ2RpdicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgcmVmOiBbZm9yd2FyZGVkUmVmLCBzY3JvbGxBcnJvd1JlZl0sXG4gICAgc3RhdGUsXG4gICAgcHJvcHM6IFtkZWZhdWx0UHJvcHMsIGVsZW1lbnRQcm9wc10sXG4gICAgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZzogdHJhbnNpdGlvblN0YXR1c01hcHBpbmdcbiAgfSk7XG4gIGNvbnN0IHNob3VsZFJlbmRlciA9IG1vdW50ZWQgfHwga2VlcE1vdW50ZWQ7XG4gIGlmICghc2hvdWxkUmVuZGVyKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgcmV0dXJuIGVsZW1lbnQ7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFNlbGVjdFNjcm9sbEFycm93LmRpc3BsYXlOYW1lID0gXCJTZWxlY3RTY3JvbGxBcnJvd1wiO1xuZnVuY3Rpb24gZ2V0VGFyZ2V0U2Nyb2xsVG9wKGl0ZW1zLCBpc1VwLCBzY3JvbGxUb3AsIGNsaWVudEhlaWdodCwgc2Nyb2xsQXJyb3dIZWlnaHQsIG1heFNjcm9sbFRvcCkge1xuICBpZiAoaXNVcCkge1xuICAgIGxldCBmaXJzdFZpc2libGVJbmRleCA9IDA7XG4gICAgY29uc3QgdmlzaWJsZVRvcCA9IHNjcm9sbFRvcCArIHNjcm9sbEFycm93SGVpZ2h0IC0gU0NST0xMX0VER0VfVE9MRVJBTkNFX1BYO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaXRlbXMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgIGNvbnN0IGl0ZW0gPSBpdGVtc1tpXTtcbiAgICAgIGlmIChpdGVtICYmIGl0ZW0ub2Zmc2V0VG9wID49IHZpc2libGVUb3ApIHtcbiAgICAgICAgZmlyc3RWaXNpYmxlSW5kZXggPSBpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG4gICAgY29uc3QgdGFyZ2V0SW5kZXggPSBNYXRoLm1heCgwLCBmaXJzdFZpc2libGVJbmRleCAtIDEpO1xuICAgIGNvbnN0IHRhcmdldEl0ZW0gPSBpdGVtc1t0YXJnZXRJbmRleF07XG4gICAgcmV0dXJuIHRhcmdldEluZGV4IDwgZmlyc3RWaXNpYmxlSW5kZXggJiYgdGFyZ2V0SXRlbSA/IG5vcm1hbGl6ZVNjcm9sbE9mZnNldCh0YXJnZXRJdGVtLm9mZnNldFRvcCAtIHNjcm9sbEFycm93SGVpZ2h0LCBtYXhTY3JvbGxUb3ApIDogMDtcbiAgfVxuICBsZXQgbGFzdFZpc2libGVJbmRleCA9IGl0ZW1zLmxlbmd0aCAtIDE7XG4gIGNvbnN0IHZpc2libGVCb3R0b20gPSBzY3JvbGxUb3AgKyBjbGllbnRIZWlnaHQgLSBzY3JvbGxBcnJvd0hlaWdodCArIFNDUk9MTF9FREdFX1RPTEVSQU5DRV9QWDtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBpdGVtcy5sZW5ndGg7IGkgKz0gMSkge1xuICAgIGNvbnN0IGl0ZW0gPSBpdGVtc1tpXTtcbiAgICBpZiAoaXRlbSAmJiBpdGVtLm9mZnNldFRvcCArIGl0ZW0ub2Zmc2V0SGVpZ2h0ID4gdmlzaWJsZUJvdHRvbSkge1xuICAgICAgbGFzdFZpc2libGVJbmRleCA9IE1hdGgubWF4KDAsIGkgLSAxKTtcbiAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuICBjb25zdCB0YXJnZXRJbmRleCA9IE1hdGgubWluKGl0ZW1zLmxlbmd0aCAtIDEsIGxhc3RWaXNpYmxlSW5kZXggKyAxKTtcbiAgY29uc3QgdGFyZ2V0SXRlbSA9IGl0ZW1zW3RhcmdldEluZGV4XTtcbiAgcmV0dXJuIHRhcmdldEluZGV4ID4gbGFzdFZpc2libGVJbmRleCAmJiB0YXJnZXRJdGVtID8gbm9ybWFsaXplU2Nyb2xsT2Zmc2V0KHRhcmdldEl0ZW0ub2Zmc2V0VG9wICsgdGFyZ2V0SXRlbS5vZmZzZXRIZWlnaHQgLSBjbGllbnRIZWlnaHQgKyBzY3JvbGxBcnJvd0hlaWdodCwgbWF4U2Nyb2xsVG9wKSA6IG1heFNjcm9sbFRvcDtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFNlbGVjdFNjcm9sbEFycm93IH0gZnJvbSBcIi4uL3Njcm9sbC1hcnJvdy9TZWxlY3RTY3JvbGxBcnJvdy5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vKipcbiAqIEFuIGVsZW1lbnQgdGhhdCBzY3JvbGxzIHRoZSBzZWxlY3QgcG9wdXAgZG93biB3aGVuIGhvdmVyZWQuIERvZXMgbm90IHJlbmRlciB3aGVuIHVzaW5nIHRvdWNoIGlucHV0LlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBTZWxlY3RdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9zZWxlY3QpXG4gKi9cbmV4cG9ydCBjb25zdCBTZWxlY3RTY3JvbGxEb3duQXJyb3cgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBTZWxlY3RTY3JvbGxEb3duQXJyb3cocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goU2VsZWN0U2Nyb2xsQXJyb3csIHtcbiAgICAuLi5wcm9wcyxcbiAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICBkaXJlY3Rpb246IFwiZG93blwiXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBTZWxlY3RTY3JvbGxEb3duQXJyb3cuZGlzcGxheU5hbWUgPSBcIlNlbGVjdFNjcm9sbERvd25BcnJvd1wiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgU2VsZWN0U2Nyb2xsQXJyb3cgfSBmcm9tIFwiLi4vc2Nyb2xsLWFycm93L1NlbGVjdFNjcm9sbEFycm93Lm1qc1wiO1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8qKlxuICogQW4gZWxlbWVudCB0aGF0IHNjcm9sbHMgdGhlIHNlbGVjdCBwb3B1cCB1cCB3aGVuIGhvdmVyZWQuIERvZXMgbm90IHJlbmRlciB3aGVuIHVzaW5nIHRvdWNoIGlucHV0LlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBTZWxlY3RdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9zZWxlY3QpXG4gKi9cbmV4cG9ydCBjb25zdCBTZWxlY3RTY3JvbGxVcEFycm93ID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gU2VsZWN0U2Nyb2xsVXBBcnJvdyhwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChTZWxlY3RTY3JvbGxBcnJvdywge1xuICAgIC4uLnByb3BzLFxuICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgIGRpcmVjdGlvbjogXCJ1cFwiXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBTZWxlY3RTY3JvbGxVcEFycm93LmRpc3BsYXlOYW1lID0gXCJTZWxlY3RTY3JvbGxVcEFycm93XCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgX2Zvcm1hdEVycm9yTWVzc2FnZSBmcm9tIFwiQGJhc2UtdWkvdXRpbHMvZm9ybWF0RXJyb3JNZXNzYWdlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgU2VsZWN0R3JvdXBDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFNlbGVjdEdyb3VwQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiU2VsZWN0R3JvdXBDb250ZXh0XCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlU2VsZWN0R3JvdXBDb250ZXh0KCkge1xuICBjb25zdCBjb250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChTZWxlY3RHcm91cENvbnRleHQpO1xuICBpZiAoY29udGV4dCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/ICdCYXNlIFVJOiBTZWxlY3RHcm91cENvbnRleHQgaXMgbWlzc2luZy4gU2VsZWN0R3JvdXAgcGFydHMgbXVzdCBiZSBwbGFjZWQgd2l0aGluIDxTZWxlY3QuR3JvdXA+LicgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDU2KSk7XG4gIH1cbiAgcmV0dXJuIGNvbnRleHQ7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBTZWxlY3RHcm91cENvbnRleHQgfSBmcm9tIFwiLi9TZWxlY3RHcm91cENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuXG4vKipcbiAqIEdyb3VwcyByZWxhdGVkIHNlbGVjdCBpdGVtcyB3aXRoIHRoZSBjb3JyZXNwb25kaW5nIGxhYmVsLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBTZWxlY3RdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9zZWxlY3QpXG4gKi9cbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgY29uc3QgU2VsZWN0R3JvdXAgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBTZWxlY3RHcm91cChjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IFtsYWJlbElkLCBzZXRMYWJlbElkXSA9IFJlYWN0LnVzZVN0YXRlKCk7XG4gIGNvbnN0IGNvbnRleHRWYWx1ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBsYWJlbElkLFxuICAgIHNldExhYmVsSWRcbiAgfSksIFtsYWJlbElkLCBzZXRMYWJlbElkXSk7XG4gIGNvbnN0IGVsZW1lbnQgPSB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgIHByb3BzOiBbe1xuICAgICAgcm9sZTogJ2dyb3VwJyxcbiAgICAgICdhcmlhLWxhYmVsbGVkYnknOiBsYWJlbElkXG4gICAgfSwgZWxlbWVudFByb3BzXVxuICB9KTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KFNlbGVjdEdyb3VwQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBjb250ZXh0VmFsdWUsXG4gICAgY2hpbGRyZW46IGVsZW1lbnRcbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFNlbGVjdEdyb3VwLmRpc3BsYXlOYW1lID0gXCJTZWxlY3RHcm91cFwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZUJhc2VVaUlkIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VCYXNlVWlJZC5tanNcIjtcbmltcG9ydCB7IHVzZVNlbGVjdEdyb3VwQ29udGV4dCB9IGZyb20gXCIuLi9ncm91cC9TZWxlY3RHcm91cENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuXG4vKipcbiAqIEFuIGFjY2Vzc2libGUgbGFiZWwgdGhhdCBpcyBhdXRvbWF0aWNhbGx5IGFzc29jaWF0ZWQgd2l0aCBpdHMgcGFyZW50IGdyb3VwLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBTZWxlY3RdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9zZWxlY3QpXG4gKi9cbmV4cG9ydCBjb25zdCBTZWxlY3RHcm91cExhYmVsID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gU2VsZWN0R3JvdXBMYWJlbChjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIGlkOiBpZFByb3AsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qge1xuICAgIHNldExhYmVsSWRcbiAgfSA9IHVzZVNlbGVjdEdyb3VwQ29udGV4dCgpO1xuICBjb25zdCBpZCA9IHVzZUJhc2VVaUlkKGlkUHJvcCk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgc2V0TGFiZWxJZChpZCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHNldExhYmVsSWQoY3VycmVudElkID0+IGN1cnJlbnRJZCA9PT0gaWQgPyB1bmRlZmluZWQgOiBjdXJyZW50SWQpO1xuICAgIH07XG4gIH0sIFtpZCwgc2V0TGFiZWxJZF0pO1xuICBjb25zdCBlbGVtZW50ID0gdXNlUmVuZGVyRWxlbWVudCgnZGl2JywgY29tcG9uZW50UHJvcHMsIHtcbiAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICBwcm9wczogW3tcbiAgICAgIGlkLFxuICAgICAgJ2FyaWEtaGlkZGVuJzogdHJ1ZVxuICAgIH0sIGVsZW1lbnRQcm9wc11cbiAgfSk7XG4gIHJldHVybiBlbGVtZW50O1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBTZWxlY3RHcm91cExhYmVsLmRpc3BsYXlOYW1lID0gXCJTZWxlY3RHcm91cExhYmVsXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuXG4vKipcbiAqIEEgdmlzdWFsIHNlcGFyYXRvciBiZXR3ZWVuIGl0ZW1zLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGNvbnN0IExpc3Rib3hTZXBhcmF0b3IgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBMaXN0Ym94U2VwYXJhdG9yKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIGNsYXNzTmFtZSxcbiAgICByZW5kZXIsXG4gICAgb3JpZW50YXRpb24gPSAnaG9yaXpvbnRhbCcsXG4gICAgc3R5bGUsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgb3JpZW50YXRpb25cbiAgfTtcbiAgcmV0dXJuIHVzZVJlbmRlckVsZW1lbnQoJ2RpdicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgc3RhdGUsXG4gICAgcmVmOiBmb3J3YXJkZWRSZWYsXG4gICAgcHJvcHM6IFt7XG4gICAgICByb2xlOiAncHJlc2VudGF0aW9uJ1xuICAgIH0sIGVsZW1lbnRQcm9wc11cbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIExpc3Rib3hTZXBhcmF0b3IuZGlzcGxheU5hbWUgPSBcIkxpc3Rib3hTZXBhcmF0b3JcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCB7IExpc3Rib3hTZXBhcmF0b3IgfSBmcm9tIFwiLi4vLi4vdXRpbHMvbGlzdGJveC1zZXBhcmF0b3IvTGlzdGJveFNlcGFyYXRvci5tanNcIjtcbi8qKlxuICogQSB2aXN1YWwgc2VwYXJhdG9yIGJldHdlZW4gaXRlbXMgb3IgZ3JvdXBzLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBTZWxlY3RdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9zZWxlY3QpXG4gKi9cbmV4cG9ydCBjb25zdCBTZWxlY3RTZXBhcmF0b3IgPSBMaXN0Ym94U2VwYXJhdG9yOyIsImV4cG9ydCB7IFNlbGVjdFJvb3QgYXMgUm9vdCB9IGZyb20gXCIuL3Jvb3QvU2VsZWN0Um9vdC5tanNcIjtcbmV4cG9ydCB7IFNlbGVjdExhYmVsIGFzIExhYmVsIH0gZnJvbSBcIi4vbGFiZWwvU2VsZWN0TGFiZWwubWpzXCI7XG5leHBvcnQgeyBTZWxlY3RUcmlnZ2VyIGFzIFRyaWdnZXIgfSBmcm9tIFwiLi90cmlnZ2VyL1NlbGVjdFRyaWdnZXIubWpzXCI7XG5leHBvcnQgeyBTZWxlY3RWYWx1ZSBhcyBWYWx1ZSB9IGZyb20gXCIuL3ZhbHVlL1NlbGVjdFZhbHVlLm1qc1wiO1xuZXhwb3J0IHsgU2VsZWN0SWNvbiBhcyBJY29uIH0gZnJvbSBcIi4vaWNvbi9TZWxlY3RJY29uLm1qc1wiO1xuZXhwb3J0IHsgU2VsZWN0UG9ydGFsIGFzIFBvcnRhbCB9IGZyb20gXCIuL3BvcnRhbC9TZWxlY3RQb3J0YWwubWpzXCI7XG5leHBvcnQgeyBTZWxlY3RCYWNrZHJvcCBhcyBCYWNrZHJvcCB9IGZyb20gXCIuL2JhY2tkcm9wL1NlbGVjdEJhY2tkcm9wLm1qc1wiO1xuZXhwb3J0IHsgU2VsZWN0UG9zaXRpb25lciBhcyBQb3NpdGlvbmVyIH0gZnJvbSBcIi4vcG9zaXRpb25lci9TZWxlY3RQb3NpdGlvbmVyLm1qc1wiO1xuZXhwb3J0IHsgU2VsZWN0UG9wdXAgYXMgUG9wdXAgfSBmcm9tIFwiLi9wb3B1cC9TZWxlY3RQb3B1cC5tanNcIjtcbmV4cG9ydCB7IFNlbGVjdExpc3QgYXMgTGlzdCB9IGZyb20gXCIuL2xpc3QvU2VsZWN0TGlzdC5tanNcIjtcbmV4cG9ydCB7IFNlbGVjdEl0ZW0gYXMgSXRlbSB9IGZyb20gXCIuL2l0ZW0vU2VsZWN0SXRlbS5tanNcIjtcbmV4cG9ydCB7IFNlbGVjdEl0ZW1JbmRpY2F0b3IgYXMgSXRlbUluZGljYXRvciB9IGZyb20gXCIuL2l0ZW0taW5kaWNhdG9yL1NlbGVjdEl0ZW1JbmRpY2F0b3IubWpzXCI7XG5leHBvcnQgeyBTZWxlY3RJdGVtVGV4dCBhcyBJdGVtVGV4dCB9IGZyb20gXCIuL2l0ZW0tdGV4dC9TZWxlY3RJdGVtVGV4dC5tanNcIjtcbmV4cG9ydCB7IFNlbGVjdEFycm93IGFzIEFycm93IH0gZnJvbSBcIi4vYXJyb3cvU2VsZWN0QXJyb3cubWpzXCI7XG5leHBvcnQgeyBTZWxlY3RTY3JvbGxEb3duQXJyb3cgYXMgU2Nyb2xsRG93bkFycm93IH0gZnJvbSBcIi4vc2Nyb2xsLWRvd24tYXJyb3cvU2VsZWN0U2Nyb2xsRG93bkFycm93Lm1qc1wiO1xuZXhwb3J0IHsgU2VsZWN0U2Nyb2xsVXBBcnJvdyBhcyBTY3JvbGxVcEFycm93IH0gZnJvbSBcIi4vc2Nyb2xsLXVwLWFycm93L1NlbGVjdFNjcm9sbFVwQXJyb3cubWpzXCI7XG5leHBvcnQgeyBTZWxlY3RHcm91cCBhcyBHcm91cCB9IGZyb20gXCIuL2dyb3VwL1NlbGVjdEdyb3VwLm1qc1wiO1xuZXhwb3J0IHsgU2VsZWN0R3JvdXBMYWJlbCBhcyBHcm91cExhYmVsIH0gZnJvbSBcIi4vZ3JvdXAtbGFiZWwvU2VsZWN0R3JvdXBMYWJlbC5tanNcIjtcbmV4cG9ydCB7IFNlbGVjdFNlcGFyYXRvciBhcyBTZXBhcmF0b3IgfSBmcm9tIFwiLi9zZXBhcmF0b3IvU2VsZWN0U2VwYXJhdG9yLm1qc1wiOyIsIi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzZWxlY3QgZG9lc24ndCBoYXZlIGEgdmFsdWUuXG4gKi9cbmV4cG9ydCBjb25zdCBwbGFjZWhvbGRlciA9ICdkYXRhLXBsYWNlaG9sZGVyJzsiLCJpbXBvcnQgeyBDb21tb25UcmlnZ2VyRGF0YUF0dHJpYnV0ZXMgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjb3JyZXNwb25kaW5nIHBvcHVwIGlzIG9wZW4uXG4gKi9cbmV4cG9ydCBjb25zdCBwb3B1cE9wZW4gPSBDb21tb25UcmlnZ2VyRGF0YUF0dHJpYnV0ZXMucG9wdXBPcGVuOyIsImltcG9ydCB7IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzZWxlY3QgaXMgb3Blbi5cbiAqL1xuZXhwb3J0IGNvbnN0IG9wZW4gPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW47XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgc2VsZWN0IGlzIGNsb3NlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGNsb3NlZCA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuY2xvc2VkO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHNlbGVjdCBiZWdpbnMgYW5pbWF0aW5nIGluLlxuICovXG5leHBvcnQgY29uc3Qgc3RhcnRpbmdTdHlsZSA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuc3RhcnRpbmdTdHlsZTtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzZWxlY3QgaXMgYW5pbWF0aW5nIG91dC5cbiAqL1xuZXhwb3J0IGNvbnN0IGVuZGluZ1N0eWxlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5lbmRpbmdTdHlsZTsiLCJpbXBvcnQgeyBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwU3RhdGVNYXBwaW5nLm1qc1wiO1xuXG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgc2VsZWN0IHBvcHVwIGlzIG9wZW4uXG4gKi9cbmV4cG9ydCBjb25zdCBvcGVuID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5vcGVuO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHNlbGVjdCBwb3B1cCBpcyBjbG9zZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBjbG9zZWQgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmNsb3NlZDtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBhbmNob3IgaXMgaGlkZGVuLlxuICovXG5leHBvcnQgY29uc3QgYW5jaG9ySGlkZGVuID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5hbmNob3JIaWRkZW47XG4vKipcbiAqIEluZGljYXRlcyB3aGljaCBzaWRlIHRoZSBwb3B1cCBpcyBwb3NpdGlvbmVkIHJlbGF0aXZlIHRvIHRoZSB0cmlnZ2VyLlxuICogQHR5cGUgeydub25lJyB8ICd0b3AnIHwgJ2JvdHRvbScgfCAnbGVmdCcgfCAncmlnaHQnIHwgJ2lubGluZS1lbmQnIHwgJ2lubGluZS1zdGFydCd9XG4gKi9cbmV4cG9ydCBjb25zdCBzaWRlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zaWRlO1xuLyoqXG4gKiBJbmRpY2F0ZXMgaG93IHRoZSBwb3B1cCBpcyBhbGlnbmVkIHJlbGF0aXZlIHRvIHNwZWNpZmllZCBzaWRlLlxuICogQHR5cGUgeydzdGFydCcgfCAnY2VudGVyJyB8ICdlbmQnfVxuICovXG5leHBvcnQgY29uc3QgYWxpZ24gPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmFsaWduOyIsImltcG9ydCB7IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzZWxlY3QgaXMgb3Blbi5cbiAqL1xuZXhwb3J0IGNvbnN0IG9wZW4gPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW47XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgc2VsZWN0IGlzIGNsb3NlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGNsb3NlZCA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuY2xvc2VkO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHNlbGVjdCBiZWdpbnMgYW5pbWF0aW5nIGluLlxuICovXG5leHBvcnQgY29uc3Qgc3RhcnRpbmdTdHlsZSA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuc3RhcnRpbmdTdHlsZTtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzZWxlY3QgaXMgYW5pbWF0aW5nIG91dC5cbiAqL1xuZXhwb3J0IGNvbnN0IGVuZGluZ1N0eWxlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5lbmRpbmdTdHlsZTtcbi8qKlxuICogSW5kaWNhdGVzIHdoaWNoIHNpZGUgdGhlIHBvcHVwIGlzIHBvc2l0aW9uZWQgcmVsYXRpdmUgdG8gdGhlIHRyaWdnZXIuXG4gKiBAdHlwZSB7J25vbmUnIHwgJ3RvcCcgfCAnYm90dG9tJyB8ICdsZWZ0JyB8ICdyaWdodCcgfCAnaW5saW5lLWVuZCcgfCAnaW5saW5lLXN0YXJ0J31cbiAqL1xuZXhwb3J0IGNvbnN0IHNpZGUgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnNpZGU7XG4vKipcbiAqIEluZGljYXRlcyBob3cgdGhlIHBvcHVwIGlzIGFsaWduZWQgcmVsYXRpdmUgdG8gc3BlY2lmaWVkIHNpZGUuXG4gKiBAdHlwZSB7J3N0YXJ0JyB8ICdjZW50ZXInIHwgJ2VuZCd9XG4gKi9cbmV4cG9ydCBjb25zdCBhbGlnbiA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuYWxpZ247IiwiLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHNlbGVjdCBpdGVtIGlzIHNlbGVjdGVkLlxuICovXG5leHBvcnQgY29uc3Qgc2VsZWN0ZWQgPSAnZGF0YS1zZWxlY3RlZCc7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgc2VsZWN0IGl0ZW0gaXMgaGlnaGxpZ2h0ZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBoaWdobGlnaHRlZCA9ICdkYXRhLWhpZ2hsaWdodGVkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzZWxlY3QgaXRlbSBpcyBkaXNhYmxlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGRpc2FibGVkID0gJ2RhdGEtZGlzYWJsZWQnOyIsImltcG9ydCB7IFRyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGluZGljYXRvciBiZWdpbnMgYW5pbWF0aW5nIGluLlxuICovXG5leHBvcnQgY29uc3Qgc3RhcnRpbmdTdHlsZSA9IFRyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcy5zdGFydGluZ1N0eWxlO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGluZGljYXRvciBpcyBhbmltYXRpbmcgb3V0LlxuICovXG5leHBvcnQgY29uc3QgZW5kaW5nU3R5bGUgPSBUcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMuZW5kaW5nU3R5bGU7IiwiaW1wb3J0IHsgQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHNlbGVjdCBwb3B1cCBpcyBvcGVuLlxuICovXG5leHBvcnQgY29uc3Qgb3BlbiA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMub3Blbjtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzZWxlY3QgcG9wdXAgaXMgY2xvc2VkLlxuICovXG5leHBvcnQgY29uc3QgY2xvc2VkID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5jbG9zZWQ7XG4vKipcbiAqIEluZGljYXRlcyB3aGljaCBzaWRlIHRoZSBwb3B1cCBpcyBwb3NpdGlvbmVkIHJlbGF0aXZlIHRvIHRoZSB0cmlnZ2VyLlxuICogQHR5cGUgeydub25lJyB8ICd0b3AnIHwgJ2JvdHRvbScgfCAnbGVmdCcgfCAncmlnaHQnIHwgJ2lubGluZS1lbmQnIHwgJ2lubGluZS1zdGFydCd9XG4gKi9cbmV4cG9ydCBjb25zdCBzaWRlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zaWRlO1xuLyoqXG4gKiBJbmRpY2F0ZXMgaG93IHRoZSBwb3B1cCBpcyBhbGlnbmVkIHJlbGF0aXZlIHRvIHNwZWNpZmllZCBzaWRlLlxuICogQHR5cGUgeydzdGFydCcgfCAnY2VudGVyJyB8ICdlbmQnfVxuICovXG5leHBvcnQgY29uc3QgYWxpZ24gPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmFsaWduO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHNlbGVjdCBhcnJvdyBpcyB1bmNlbnRlcmVkLlxuICovXG5leHBvcnQgY29uc3QgdW5jZW50ZXJlZCA9ICdkYXRhLXVuY2VudGVyZWQnOyIsImltcG9ydCB7IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzY3JvbGwgYXJyb3cgYmVnaW5zIGFuaW1hdGluZyBpbi5cbiAqL1xuZXhwb3J0IGNvbnN0IHN0YXJ0aW5nU3R5bGUgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnN0YXJ0aW5nU3R5bGU7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgc2Nyb2xsIGFycm93IGlzIGFuaW1hdGluZyBvdXQuXG4gKi9cbmV4cG9ydCBjb25zdCBlbmRpbmdTdHlsZSA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuZW5kaW5nU3R5bGU7XG4vKipcbiAqIEluZGljYXRlcyB0aGUgZGlyZWN0aW9uIG9mIHRoZSBzY3JvbGwgYXJyb3cuXG4gKiBAdHlwZSB7J2Rvd24nfVxuICovXG5leHBvcnQgY29uc3QgZGlyZWN0aW9uID0gJ2RhdGEtZGlyZWN0aW9uJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzY3JvbGwgYXJyb3cgaXMgdmlzaWJsZS5cbiAqL1xuZXhwb3J0IGNvbnN0IHZpc2libGUgPSAnZGF0YS12aXNpYmxlJztcbi8qKlxuICogSW5kaWNhdGVzIHdoaWNoIHNpZGUgdGhlIHBvcHVwIGlzIHBvc2l0aW9uZWQgcmVsYXRpdmUgdG8gdGhlIHRyaWdnZXIuXG4gKiBAdHlwZSB7J25vbmUnIHwgJ3RvcCcgfCAnYm90dG9tJyB8ICdsZWZ0JyB8ICdyaWdodCcgfCAnaW5saW5lLWVuZCcgfCAnaW5saW5lLXN0YXJ0J31cbiAqL1xuZXhwb3J0IGNvbnN0IHNpZGUgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnNpZGU7IiwiaW1wb3J0IHsgQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHNjcm9sbCBhcnJvdyBiZWdpbnMgYW5pbWF0aW5nIGluLlxuICovXG5leHBvcnQgY29uc3Qgc3RhcnRpbmdTdHlsZSA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuc3RhcnRpbmdTdHlsZTtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzY3JvbGwgYXJyb3cgaXMgYW5pbWF0aW5nIG91dC5cbiAqL1xuZXhwb3J0IGNvbnN0IGVuZGluZ1N0eWxlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5lbmRpbmdTdHlsZTtcbi8qKlxuICogSW5kaWNhdGVzIHRoZSBkaXJlY3Rpb24gb2YgdGhlIHNjcm9sbCBhcnJvdy5cbiAqIEB0eXBlIHsndXAnfVxuICovXG5leHBvcnQgY29uc3QgZGlyZWN0aW9uID0gJ2RhdGEtZGlyZWN0aW9uJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBzY3JvbGwgYXJyb3cgaXMgdmlzaWJsZS5cbiAqL1xuZXhwb3J0IGNvbnN0IHZpc2libGUgPSAnZGF0YS12aXNpYmxlJztcbi8qKlxuICogSW5kaWNhdGVzIHdoaWNoIHNpZGUgdGhlIHBvcHVwIGlzIHBvc2l0aW9uZWQgcmVsYXRpdmUgdG8gdGhlIHRyaWdnZXIuXG4gKiBAdHlwZSB7J25vbmUnIHwgJ3RvcCcgfCAnYm90dG9tJyB8ICdsZWZ0JyB8ICdyaWdodCcgfCAnaW5saW5lLWVuZCcgfCAnaW5saW5lLXN0YXJ0J31cbiAqL1xuZXhwb3J0IGNvbnN0IHNpZGUgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnNpZGU7Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQVNBLFNBQWdCLHVCQUF1QixTQUFTO0NBQzlDLE1BQU0sRUFDSixPQUFPLE9BQ1AsY0FDQSxXQUFXLENBQUMsTUFDVjtDQUNKLE1BQU0sYUFBYSxNQUFNO0NBQ3pCLE1BQU0sU0FBUyx3QkFBd0IsS0FBSztDQUNEO0VBQ3pDLE1BQU0scUJBQXFCLFNBQVM7RUFDcEMsSUFBSSxzQkFBc0IsQ0FBQyxVQUFVLGtCQUFrQixHQUNyRCxRQUFRLE1BQU0scUVBQXFFLDBFQUEwRSxVQUFVO0NBRTNLO0NBQ0EsTUFBTSxRQUFRLHFCQUFxQixJQUFJLGtCQUFrQjtFQUN2RDtFQUNBLGtCQUFrQixLQUFBO0VBQ2xCO0VBQ0Esa0JBQWtCLFNBQVMsYUFBYTtFQUN4QyxpQkFBaUIsU0FBUyxZQUFZO0VBQ3RDLGlCQUFpQixJQUFJLGdCQUFnQjtFQUNyQztFQUNBLFVBQVU7RUFDVjtDQUNGLENBQUMsQ0FBQyxDQUFDLENBQUM7Q0FDSix5QkFBeUI7RUFDdkIsTUFBTSxlQUFlO0dBQ25CO0dBQ0E7RUFDRjtFQUNBLElBQUksU0FBUyxjQUFjLEtBQUEsR0FBVztHQUNwQyxhQUFhLG1CQUFtQixTQUFTO0dBQ3pDLGFBQWEsc0JBQXNCLFVBQVUsU0FBUyxTQUFTLElBQUksU0FBUyxZQUFZO0VBQzFGO0VBQ0EsSUFBSSxTQUFTLGFBQWEsS0FBQSxHQUN4QixhQUFhLGtCQUFrQixTQUFTO0VBRTFDLE1BQU0sT0FBTyxZQUFZO0NBQzNCLEdBQUc7RUFBQztFQUFNO0VBQVksU0FBUztFQUFXLFNBQVM7RUFBVTtDQUFLLENBQUM7Q0FDbkUsTUFBTSxRQUFRLGVBQWU7Q0FDN0IsTUFBTSxRQUFRLFNBQVM7Q0FDdkIsT0FBTztBQUNUOzs7O0FDL0NBLFNBQWdCLHFCQUFxQixRQUFRLFlBQVk7Q0FDdkQsTUFBTSxLQUFLLFlBQVksTUFBTTtDQUM3Qix5QkFBeUI7RUFDdkIsV0FBVyxFQUFFO0VBQ2IsYUFBYTtHQUNYLFlBQVcsY0FBYSxjQUFjLEtBQUssS0FBQSxJQUFZLFNBQVM7RUFDbEU7Q0FDRixHQUFHLENBQUMsSUFBSSxVQUFVLENBQUM7Q0FDbkIsT0FBTztBQUNUOztBQ0xBLFNBQWdCLFNBQVMsU0FBUyxDQUFDLEdBQUc7Q0FDcEMsTUFBTSxFQUNKLElBQUksUUFDSixtQkFDQSxTQUFTLE9BQ1QsWUFBWSxnQkFDWixjQUFjLHFCQUNaO0NBQ0osTUFBTSxFQUNKLFdBQVcsa0JBQ1gsWUFBWSxzQkFDVixvQkFBb0I7Q0FLeEIsTUFBTSxLQUFLLHFCQUFxQixRQUpaLG1CQUFrQixnQkFBZTtFQUNuRCxrQkFBa0IsV0FBVztFQUM3QixpQkFBaUIsV0FBVztDQUM5QixDQUN3QyxDQUFXO0NBQ25ELE1BQU0sb0JBQW9CLG9CQUFvQjtDQUM5QyxTQUFTLGFBQWEsT0FBTztFQUMzQixJQUFJLGtCQUFrQjtHQUNwQixpQkFBaUIsT0FBTyxpQkFBaUI7R0FDekM7RUFDRjtFQUNBLElBQUksQ0FBQyxtQkFDSDtFQUVGLE1BQU0saUJBQWlCLGVBQWUsTUFBTSxlQUFlLGlCQUFpQjtFQUM1RSxJQUFJLGNBQWMsY0FBYyxHQUM5Qix3QkFBd0IsY0FBYztDQUUxQztDQUNBLFNBQVMsa0JBQWtCLE9BQU87RUFDaEMsTUFBTSxTQUFTLFVBQVUsTUFBTSxXQUFXO0VBQzFDLElBQUksUUFBUSxRQUFRLDhCQUE4QixHQUNoRDtFQUlGLElBQUksQ0FBQyxNQUFNLG9CQUFvQixNQUFNLFNBQVMsR0FDNUMsTUFBTSxlQUFlO0VBRXZCLElBQUksUUFDRjtFQUVGLGFBQWEsS0FBSztDQUNwQjtDQUNBLE9BQU8sU0FBUztFQUNkO0VBQ0EsU0FBUztFQUNULGFBQWE7Q0FDZixJQUFJO0VBQ0Y7RUFDQSxTQUFTO0VBQ1QsY0FBYyxPQUFPO0dBQ25CLE1BQU0sZUFBZTtFQUN2QjtDQUNGO0FBQ0Y7QUFDQSxTQUFnQixlQUFlLE9BQU8sSUFBSTtDQUN4QyxJQUFJLE9BQU8sTUFBTSxZQUFZO0NBQzdCLE9BQU8sYUFBYSxJQUFJLEdBQUc7RUFDekIsTUFBTSxVQUFVLEtBQUssZUFBZSxFQUFFO0VBQ3RDLElBQUksU0FDRixPQUFPO0VBRVQsT0FBTyxLQUFLLEtBQUssWUFBWTtDQUMvQjtDQUNBLE9BQU8sY0FBYyxLQUFLLENBQUMsQ0FBQyxlQUFlLEVBQUU7QUFDL0M7QUFDQSxTQUFnQix3QkFBd0IsU0FBUztDQUMvQyxRQUFRLE1BQU0sRUFHWixjQUFjLEtBQ2hCLENBQUM7QUFDSDs7QUNoRkEsU0FBZ0IsaUJBQWlCLElBQUk7Q0FDbkMsTUFBTSxNQUFBLGFBQVksT0FBTyxJQUFJO0NBQzdCLElBQUksSUFBSSxTQUFTO0VBQ2YsSUFBSSxVQUFVO0VBQ2QsR0FBRztDQUNMO0FBQ0Y7O0FDTEEsSUFBYSxvQkFBaUMsMkJBQU0sY0FBYyxLQUFBLENBQVM7QUFDaEMsa0JBQWtCLGNBQWM7QUFDM0UsSUFBYSx3QkFBcUMsMkJBQU0sY0FBYyxLQUFBLENBQVM7QUFDcEMsc0JBQXNCLGNBQWM7QUFDL0UsU0FBZ0IsdUJBQXVCO0NBQ3JDLE1BQU0sUUFBQSxhQUFjLFdBQVcsaUJBQWlCO0NBQ2hELElBQUksVUFBVSxLQUFBLEdBQ1osTUFBTSxJQUFJLE1BQThDLDBGQUFvSDtDQUU5SyxPQUFPO0FBQ1Q7QUFDQSxTQUFnQiwyQkFBMkI7Q0FDekMsTUFBTSxVQUFBLGFBQWdCLFdBQVcscUJBQXFCO0NBQ3RELElBQUksWUFBWSxLQUFBLEdBQ2QsTUFBTSxJQUFJLE1BQThDLDhGQUF3SDtDQUVsTCxPQUFPO0FBQ1Q7Ozs7Ozs7QUNkQSxTQUFnQixlQUFlLFFBQVEsUUFBUSxlQUFlLE9BQU8sSUFBSTtDQUN2RSxNQUFNLEVBQ0osV0FDRTtDQUNKLElBQUksV0FBVyxPQUFPLFFBQ3BCLE9BQU87Q0FFVCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLLEdBQy9CLElBQUksQ0FBQyxhQUFhLE9BQU8sSUFBSSxPQUFPLEVBQUUsR0FDcEMsT0FBTztDQUdYLE9BQU87QUFDVDs7QUNsQkEsSUFBYSx1QkFBdUIsV0FBVyxrQkFBa0IsT0FBTyxHQUFHLFdBQVcsYUFBYTtBQUNuRyxTQUFnQixvQkFBb0IsV0FBVyxlQUFlLFVBQVU7Q0FDdEUsSUFBSSxhQUFhLFFBQVEsaUJBQWlCLE1BQ3hDLE9BQU8sT0FBTyxHQUFHLFdBQVcsYUFBYTtDQUUzQyxPQUFPLFNBQVMsV0FBVyxhQUFhO0FBQzFDO0FBQ0EsU0FBZ0IscUJBQXFCLGNBQWMsY0FBYyxVQUFVO0NBQ3pFLElBQUksTUFBTSxRQUFRLFlBQVksS0FBSyxNQUFNLFFBQVEsWUFBWSxHQUMzRCxPQUFPLENBQUMsZUFBZSxjQUFjLGVBQWUsV0FBVyxxQkFBcUIsb0JBQW9CLFdBQVcsa0JBQWtCLFFBQVEsQ0FBQztDQUVoSixPQUFPLGlCQUFpQjtBQUMxQjtBQUNBLFNBQWdCLHNCQUFzQixnQkFBZ0IsV0FBVyxVQUFVO0NBQ3pFLElBQUksQ0FBQyxnQkFDSCxPQUFPO0NBRVQsT0FBTyxlQUFlLE1BQUssa0JBQWlCO0VBQzFDLElBQUksa0JBQWtCLEtBQUEsR0FDcEIsT0FBTztFQUVULE9BQU8sb0JBQW9CLFdBQVcsZUFBZSxRQUFRO0NBQy9ELENBQUM7QUFDSDtBQUNBLFNBQWdCLGNBQWMsWUFBWSxlQUFlLFVBQVU7Q0FDakUsSUFBSSxDQUFDLFlBQ0gsT0FBTztDQUVULE9BQU8sV0FBVyxXQUFVLGNBQWE7RUFDdkMsSUFBSSxjQUFjLEtBQUEsR0FDaEIsT0FBTztFQUVULE9BQU8sb0JBQW9CLFdBQVcsZUFBZSxRQUFRO0NBQy9ELENBQUM7QUFDSDtBQUlBLFNBQVMsdUJBQXVCLGdCQUFnQixVQUFVO0NBQ3hELElBQUksYUFBYSxxQkFDZixRQUFPLGNBQWEsc0JBQXNCLGdCQUFnQixXQUFXLFFBQVE7Q0FFL0UsTUFBTSxRQUFRLElBQUksSUFBSSxjQUFjO0NBQ3BDLE1BQU0sT0FBTyxLQUFBLENBQVM7Q0FFdEIsUUFBTyxjQUFhLE1BQU0sSUFBSSxTQUFTLE1BQU0sY0FBYyxLQUFLLGVBQWUsTUFBSyxNQUFLLE9BQU8sR0FBRyxXQUFXLENBQUMsQ0FBQztBQUNsSDtBQUNBLFNBQWdCLG1CQUFtQixZQUFZLGVBQWUsVUFBVSxVQUFVO0NBR2hGLE1BQU0sUUFBUSxZQUFZLE1BQU0sUUFBUSxhQUFhLElBR3JELFdBQVcsVUFBVSx1QkFBdUIsZUFBZSxRQUFRLENBQUMsSUFBSSxjQUFjLFlBQVksZUFBZSxRQUFRO0NBQ3pILE9BQU8sVUFBVSxLQUFLLE9BQU87QUFDL0I7O0FBR0EsU0FBZ0IscUJBQXFCLE9BQU8sV0FBVyxVQUFVLGdCQUFnQixVQUFVLGNBQWM7Q0FDdkcsSUFBSSxzQkFBc0IsZ0JBQWdCLFdBQVcsUUFBUSxHQUUzRCxPQUFPLGdCQUFnQixRQUFRLFFBQVEsZ0JBQWdCLHNCQUFzQixnQkFBZ0IsU0FBUyxlQUFlLFFBQVEsSUFBSSxlQUFlO0NBR2xKLE9BQU8sVUFBVSxlQUFlLG1CQUFtQixVQUFVLGdCQUFnQixVQUFVLElBQUksSUFBSTtBQUNqRztBQUNBLFNBQWdCLFdBQVcsZ0JBQWdCLFdBQVcsVUFBVTtDQUM5RCxPQUFPLGVBQWUsUUFBTyxrQkFBaUIsQ0FBQyxvQkFBb0IsV0FBVyxlQUFlLFFBQVEsQ0FBQztBQUN4Rzs7Ozs7O0FDOURBLElBQWEsWUFBWTtDQUN2QixLQUFJLFVBQVMsTUFBTTtDQUNuQixVQUFTLFVBQVMsTUFBTTtDQUN4QixRQUFPLFVBQVMsTUFBTTtDQUN0QixXQUFVLFVBQVMsTUFBTTtDQUN6QixXQUFVLFVBQVMsTUFBTTtDQUN6QixXQUFVLFVBQVMsTUFBTTtDQUN6QixXQUFVLFVBQVMsTUFBTTtDQUN6Qix1QkFBc0IsVUFBUyxNQUFNO0NBQ3JDLFFBQU8sVUFBUyxNQUFNO0NBQ3RCLG9CQUFtQixVQUFTLE1BQU07Q0FDbEMscUJBQW9CLFVBQVMsTUFBTTtDQUNuQyxRQUFPLFVBQVMsTUFBTTtDQUN0QixtQkFBa0IsVUFBUztFQUN6QixNQUFNLEVBQ0osT0FDQSxVQUNBLHNCQUNFO0VBQ0osSUFBSSxTQUFTLE1BQ1gsT0FBTztFQUVULElBQUksWUFBWSxNQUFNLFFBQVEsS0FBSyxHQUNqQyxPQUFPLE1BQU0sU0FBUztFQUV4QixPQUFPLGlCQUFpQixPQUFPLGlCQUFpQixNQUFNO0NBQ3hEO0NBQ0EsbUJBQW1CLE9BQU8sWUFBWTtFQUNwQyxPQUFPLFVBQVUsaUJBQWlCLE1BQU0sS0FBSyxJQUFJO0NBQ25EO0NBQ0EsT0FBTSxVQUFTLE1BQU07Q0FDckIsVUFBUyxVQUFTLE1BQU07Q0FDeEIsYUFBWSxVQUFTLE1BQU07Q0FDM0IsbUJBQWtCLFVBQVMsTUFBTTtDQUNqQyxhQUFZLFVBQVMsTUFBTTtDQUMzQixjQUFhLFVBQVMsTUFBTTtDQUM1QixnQkFBZSxVQUFTLE1BQU07Q0FDOUIsV0FBVyxPQUFPLFVBQVUsTUFBTSxnQkFBZ0I7Q0FDbEQsYUFBYSxPQUFPLGNBQWM7RUFDaEMsTUFBTSxXQUFXLE1BQU07RUFDdkIsTUFBTSxhQUFhLE1BQU07RUFDekIsSUFBSSxNQUFNLFVBQ1IsT0FBTyxNQUFNLFFBQVEsVUFBVSxLQUFLLFdBQVcsTUFBSyxpQkFBZ0Isb0JBQW9CLFdBQVcsY0FBYyxRQUFRLENBQUM7RUFNNUgsT0FBTyxvQkFBb0IsV0FBVyxZQUFZLFFBQVE7Q0FDNUQ7Q0FDQSxvQkFBb0IsT0FBTyxVQUFVO0VBQ25DLE9BQU8sTUFBTSxrQkFBa0I7Q0FDakM7Q0FDQSxhQUFZLFVBQVMsTUFBTTtDQUMzQixlQUFjLFVBQVMsTUFBTTtDQUM3QixXQUFVLFVBQVMsTUFBTTtDQUN6QixpQkFBZ0IsVUFBUyxNQUFNO0NBQy9CLG9CQUFtQixVQUFTLE1BQU07Q0FDbEMsY0FBYSxVQUFTLE1BQU07Q0FDNUIsWUFBVyxVQUFTLE1BQU07Q0FDMUIsdUJBQXNCLFVBQVMsTUFBTTtDQUNyQyx5QkFBd0IsVUFBUyxNQUFNO0NBQ3ZDLGtCQUFpQixVQUFTLE1BQU07QUFDbEM7O0FDdkVBLFNBQWdCLE1BQU0sS0FBSyxNQUFNLE9BQU8sa0JBQWtCLE1BQU0sT0FBTyxrQkFBa0I7Q0FDdkYsT0FBTyxLQUFLLElBQUksS0FBSyxLQUFLLElBQUksS0FBSyxHQUFHLENBQUM7QUFDekM7QUNBQSxTQUFnQixtQkFBbUIsWUFBWSxZQUFZO0NBQ3pELE9BQU8sS0FBSyxJQUFJLEdBQUcsYUFBYSxVQUFVO0FBQzVDO0FBQ0EsU0FBZ0Isc0JBQXNCLE9BQU8sS0FBSztDQUNoRCxJQUFJLE9BQU8sR0FDVCxPQUFPO0NBRVQsTUFBTSxVQUFVLE1BQU0sT0FBTyxHQUFHLEdBQUc7Q0FDbkMsTUFBTSxnQkFBZ0I7Q0FDdEIsTUFBTSxjQUFjLE1BQU07Q0FDMUIsTUFBTSx1QkFBdUIsaUJBQUE7Q0FDN0IsTUFBTSxxQkFBcUIsZUFBQTtDQUMzQixJQUFJLHdCQUF3QixvQkFDMUIsT0FBTyxpQkFBaUIsY0FBYyxJQUFJO0NBRTVDLElBQUksc0JBQ0YsT0FBTztDQUVULElBQUksb0JBQ0YsT0FBTztDQUVULE9BQU87QUFDVDs7Ozs7Ozs7QUNrQkEsU0FBZ0IsV0FBVyxPQUFPO0NBQ2hDLE1BQU0sRUFDSixJQUNBLE9BQU8sV0FDUCxlQUFlLE1BQ2YsZUFDQSxNQUFNLFVBQ04sY0FBYyxPQUNkLGNBQ0EsTUFBTSxVQUNOLE1BQ0EsY0FDQSxVQUFVLGVBQWUsT0FDekIsV0FBVyxPQUNYLFdBQVcsT0FDWCxRQUFRLE1BQ1IsWUFDQSxVQUNBLHNCQUNBLE9BQ0EsV0FBVyxPQUNYLG1CQUNBLG1CQUNBLHFCQUFxQixxQkFDckIsdUJBQXVCLE1BQ3ZCLGFBQ0U7Q0FDSixNQUFNLEVBQ0osZ0JBQ0UsZUFBZTtDQUNuQixNQUFNLEVBQ0osVUFDQSxZQUNBLFlBQ0EsY0FDQSxXQUNBLE1BQU0sV0FDTixVQUFVLGVBQ1YsWUFDQSxtQkFDRSxvQkFBb0I7Q0FDeEIsTUFBTSxjQUFjLGVBQWUsRUFDakMsR0FDRixDQUFDO0NBQ0QsTUFBTSxXQUFXLGlCQUFpQjtDQUNsQyxNQUFNLE9BQU8sYUFBYTtDQUMxQixNQUFNLENBQUMsT0FBTyxxQkFBcUIsY0FBYztFQUMvQyxZQUFZO0VBQ1osU0FBUyxXQUFXLGdCQUFnQixjQUFjO0VBQ2xELE1BQU07RUFDTixPQUFPO0NBQ1QsQ0FBQztDQUNELE1BQU0sQ0FBQyxNQUFNLG9CQUFvQixjQUFjO0VBQzdDLFlBQVk7RUFDWixTQUFTO0VBQ1QsTUFBTTtFQUNOLE9BQU87Q0FDVCxDQUFDO0NBQ0QsTUFBTSxVQUFBLGFBQWdCLE9BQU8sQ0FBQyxDQUFDO0NBQy9CLE1BQU0sWUFBQSxhQUFrQixPQUFPLENBQUMsQ0FBQztDQUNqQyxNQUFNLFdBQUEsYUFBaUIsT0FBTyxJQUFJO0NBQ2xDLE1BQU0sbUJBQUEsYUFBeUIsT0FBTyxJQUFJO0NBQzFDLE1BQU0sOEJBQUEsYUFBb0MsT0FBTyxDQUFDO0NBQ2xELE1BQU0sV0FBQSxhQUFpQixPQUFPLElBQUk7Q0FDbEMsTUFBTSxZQUFBLGFBQWtCLE9BQU8sQ0FBQyxDQUFDO0NBQ2pDLE1BQU0sWUFBQSxhQUFrQixPQUFPLEtBQUs7Q0FDcEMsTUFBTSxtQkFBQSxhQUF5QixPQUFPLElBQUk7Q0FDMUMsTUFBTSxzQkFBQSxhQUE0QixPQUFPLElBQUk7Q0FDN0MsTUFBTSxlQUFBLGFBQXFCLE9BQU87RUFDaEMsc0JBQXNCO0VBQ3RCLHdCQUF3QjtFQUN4QixPQUFPO0NBQ1QsQ0FBQztDQUNELE1BQU0sZ0NBQUEsYUFBc0MsT0FBTyxLQUFLO0NBQ3hELE1BQU0sa0JBQUEsYUFBd0IsT0FBTyxLQUFLO0NBQzFDLE1BQU0sRUFDSixZQUNBLGNBQWMseUJBQ1osdUJBQXVCLElBQUk7Q0FDL0IsTUFBTSxRQUFRLHFCQUFxQixJQUFJLFdBQVc7RUFDaEQsSUFBSTtFQUNKLFNBQVMsS0FBQTtFQUNUO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFHQSxTQUFTO0VBQ1Qsa0JBQWtCLEtBQUE7RUFDbEI7RUFDQSxZQUFZO0VBQ1osWUFBWTtFQUNaLGFBQWE7RUFDYixlQUFlO0VBQ2YsWUFBWTtFQUNaLGNBQWM7RUFDZCxVQUFVO0dBQ1IsT0FBTztHQUNQO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7RUFDQSxnQkFBZ0I7RUFDaEIsbUJBQW1CO0VBQ25CLGFBQWE7RUFDYixXQUFXO0VBQ1gsc0JBQXNCO0VBQ3RCLHdCQUF3QjtFQUN4QixpQkFBaUI7Q0FDbkIsR0FBRztFQUNELFVBQVU7RUFDVixTQUFTO0VBQ1QsNkJBQTZCO0VBQzdCLHNCQUFzQjtFQUN0QjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQztDQUNmLE1BQU0sQ0FBQyx1QkFBdUIsNEJBQUEsYUFBa0MsU0FBUyxLQUFLO0NBQzlFLE1BQU0sRUFDSixTQUNBLGtCQUNBLGNBQWMsa0JBQ1oscUJBQXFCO0VBQ3ZCO0VBQ0EsS0FBSztFQUNMO0VBQ0E7RUFDQSxZQUFZO0dBQ1YsTUFBTSxPQUFPO0lBQ1gsYUFBYTtJQUNiLFlBQVk7SUFDWixzQkFBc0I7SUFDdEIsd0JBQXdCO0dBQzFCLENBQUM7R0FDRCx1QkFBdUIsS0FBSztFQUM5QjtDQUNGLENBQUM7Q0FDRCxNQUFNLGNBQWMsTUFBTSxTQUFTLGFBQWE7Q0FDaEQsTUFBTSxnQkFBZ0IsTUFBTSxTQUFTLGVBQWU7Q0FDcEQsTUFBTSxpQkFBaUIsTUFBTSxTQUFTLGdCQUFnQjtDQUN0RCxNQUFNLG9CQUFvQixNQUFNLFNBQVMsbUJBQW1CO0NBQzVELE1BQU0scUJBQXFCLGlCQUFpQixVQUFVO0NBQ3RELE1BQU0scUJBQXFCLGNBQWM7Q0FDekMsTUFBTSxrQkFBQSxhQUF3QixjQUFjO0VBSTFDLElBQUksVUFDRixPQUFPO0VBRVQsT0FBTyxpQkFBaUIsT0FBTyxpQkFBaUI7Q0FDbEQsR0FBRztFQUFDO0VBQVU7RUFBTztDQUFpQixDQUFDO0NBQ3ZDLE1BQU0sbUJBQUEsYUFBeUIsY0FBYztFQUMzQyxJQUFJLFlBQVksTUFBTSxRQUFRLEtBQUssR0FDakMsT0FBTyxNQUFNLEtBQUksaUJBQWdCLGlCQUFpQixjQUFjLGlCQUFpQixDQUFDO0VBRXBGLE9BQU8saUJBQWlCLE9BQU8saUJBQWlCO0NBQ2xELEdBQUc7RUFBQztFQUFVO0VBQU87Q0FBaUIsQ0FBQztDQUN2QyxNQUFNLGFBQWEsY0FBYyxjQUFjO0NBQy9DLE1BQU0sNkJBQTZCLHdCQUF3QixnQkFBZ0I7Q0FDM0Usd0JBQXdCLFlBQVksYUFBYSxPQUFPLDRCQUE0QixDQUFDLFVBQVUsUUFBUTtDQUl2RyxNQUFNLG1CQUFtQixXQUFXLE1BQU0sUUFBUSxLQUFLLEtBQUssTUFBTSxTQUFTLElBQUksU0FBUyxRQUFRLG9CQUFvQjtDQUNwSCx5QkFBeUI7RUFDdkIsVUFBVSxnQkFBZ0I7Q0FDNUIsR0FBRyxDQUFDLGtCQUFrQixTQUFTLENBQUM7Q0FDaEMsbUJBQW1CLFNBQVMsb0JBQW9CO0VBQzlDLE1BQU0sWUFBWSxtQkFBbUIsVUFBVSxTQUFTLE9BQU8sb0JBQW9CLFFBQVE7RUFDM0YsSUFBSSxjQUFjLE1BQ2hCLG9CQUFvQixVQUFVO0VBRWhDLElBQUksTUFDRjtFQUVGLE1BQU0sSUFBSSxpQkFBaUIsU0FBUztDQUN0QyxHQUFHO0VBQUM7RUFBVTtFQUFNO0VBQU87RUFBb0I7Q0FBSyxDQUFDO0NBQ3JELGdCQUFnQixhQUFhO0VBQzNCLFlBQVksSUFBSTtFQUNoQixTQUFTLHFCQUFxQixPQUFPLGFBQWEsY0FBYyxrQkFBa0IsQ0FBQztFQUNuRixXQUFXLE9BQU8sS0FBSztDQUN6QixDQUFDO0NBQ0QsTUFBTSxVQUFVLG1CQUFtQixVQUFVLGlCQUFpQjtFQUM1RCxNQUFNLG1CQUFtQjtFQUN6QixNQUFNLDhCQUE4Qiw0QkFBNEIsZ0JBQWdCO0VBQ2hGLGVBQWUsVUFBVSxnQkFBZ0I7RUFDekMsSUFBSSxhQUFhLFlBQ2Y7RUFFRixJQUFJLENBQUMsVUFDSCx5QkFBeUIsNEJBQTRCLENBQUM7RUFFeEQsaUJBQWlCLFFBQVE7RUFDekIsSUFBSSxDQUFDLGFBQWEsYUFBYSxXQUFXLGVBQW9CLGFBQWEsV0FBVyxrQkFBdUI7R0FDM0csV0FBVyxJQUFJO0dBQ2YsV0FBVyxLQUFLO0dBQ2hCLElBQUksbUJBQW1CLFVBQ3JCLFdBQVcsT0FBTyxLQUFLO0VBRTNCO0NBQ0YsQ0FBQztDQUNELGFBQU0sb0JBQW9CLG1CQUFtQjtFQUMzQyxTQUFTO0VBQ1QsYUFBYTtHQUNYLElBQUksTUFBTSxNQUFNLE1BQ2QsUUFBUSxPQUFPLHlCQUF5QkEsZ0JBQXdCLENBQUM7RUFFckU7Q0FDRixJQUFJO0VBQUM7RUFBZTtFQUFTO0NBQUssQ0FBQztDQUNuQyxNQUFNLFdBQVcsbUJBQW1CLFdBQVcsaUJBQWlCO0VBQzlELGdCQUFnQixXQUFXLFlBQVk7RUFDdkMsSUFBSSxhQUFhLFlBQ2Y7RUFFRixrQkFBa0IsU0FBUztDQUM3QixDQUFDO0NBQ0QsTUFBTSw4QkFBOEIsbUJBQWtCLGFBQVk7RUFDaEUsTUFBTSxlQUFlLG1CQUFtQixTQUFTLGNBQWMsU0FBUyxZQUFZO0VBQ3BGLE1BQU0sWUFBWSxzQkFBc0IsU0FBUyxXQUFXLFlBQVk7RUFDeEUsTUFBTSxlQUFlLFlBQVk7RUFDakMsTUFBTSxpQkFBaUIsWUFBWTtFQUNuQyxNQUFNLElBQUksd0JBQXdCLFlBQVk7RUFDOUMsTUFBTSxJQUFJLDBCQUEwQixjQUFjO0NBQ3BELENBQUM7Q0FDRCxNQUFNLGtCQUFrQix1QkFBdUI7RUFDN0M7RUFDQSxjQUFjO0VBQ2QsVUFBVTtHQUNSLFdBQVc7R0FDWCxVQUFVO0VBQ1o7Q0FDRixDQUFDO0NBS0QsTUFBTSxRQUFRLFNBQVMsaUJBQWlCO0VBQ3RDLFNBQVMsQ0FBQztFQUNWLE9BQU87Q0FDVCxDQUFDO0NBQ0QsTUFBTSxVQUFVLFdBQVcsZUFBZTtDQUMxQyxNQUFNLGlCQUFpQixrQkFBa0IsaUJBQWlCO0VBQ3hELFNBQVMsQ0FBQztFQUNWO0VBQ0E7RUFDQTtFQUNBLGlCQUFpQjtFQUNqQixXQUFXLGlCQUFpQjtHQUUxQixJQUFJLG9CQUFvQixRQUFRLENBQUMsTUFDL0I7R0FFRixNQUFNLElBQUksZUFBZSxlQUFlO0VBQzFDO0VBQ0Esa0JBQWtCO0NBQ3BCLENBQUM7Q0FDRCxNQUFNLFlBQVksYUFBYSxpQkFBaUI7RUFHOUMsU0FBUyxDQUFDLGFBQWEsUUFBUSxDQUFDLFlBQVksQ0FBQztFQUM3QyxTQUFTO0VBQ1Q7RUFDQTtFQU1BLGtCQUFpQixVQUFTLGtCQUFrQixRQUFRLFFBQVEsTUFBTTtFQUNsRSxRQUFRLE9BQU87R0FDYixJQUFJLE1BQ0YsTUFBTSxJQUFJLGVBQWUsS0FBSztRQUU5QixTQUFTLFVBQVUsUUFBUSxRQUFRLHlCQUF5QkMsSUFBWSxDQUFDO0VBRTdFO0VBQ0EsU0FBUyxRQUFRO0dBQ2YsVUFBVSxVQUFVO0VBQ3RCO0NBQ0YsQ0FBQztDQUdELE1BQU0scUJBQUEsYUFBMkIsY0FBYyxXQUFXLFVBQVUsV0FBVyxlQUFlLFdBQVcsUUFBUSxXQUFXLE1BQU0sV0FBVyxvQkFBb0IsR0FBRztFQUFDLE1BQU07RUFBVyxVQUFVO0VBQVcsZUFBZTtFQUFXLFFBQVE7RUFBVztDQUFvQixDQUFDO0NBQzdRLE1BQU0sYUFBQSxhQUFtQixjQUFjLFdBQVcsdUJBQXVCLFVBQVUsVUFBVSxlQUFlLFVBQVUsUUFBUSxRQUFRLEdBQUc7RUFBQyxVQUFVO0VBQVUsZUFBZTtFQUFVLFFBQVE7Q0FBUSxDQUFDO0NBQ3hNLE1BQU0sWUFBWSxlQUFlLFFBQVE7Q0FDekMsTUFBTSxXQUFBLGFBQWlCLGVBQWU7RUFDcEMsT0FBTztFQUNQO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsSUFBSTtFQUFDO0VBQVc7RUFBVTtFQUFVO0VBQVU7Q0FBa0IsQ0FBQztDQUNqRSxNQUFNLG1CQUFtQixZQUFZLFFBQVE7Q0FDN0MsTUFBTSxtQkFBbUIsV0FBVyxPQUFPO0NBQzNDLE1BQU0sbUJBQW1CLCtCQUErQiwyQkFBMkI7Q0FDbkYsTUFBTSxtQkFBbUIsd0JBQXdCLG9CQUFvQjtDQUlyRSx1QkFBdUI7RUFDckIsTUFBTSxPQUFPO0dBQ1g7R0FDQSxjQUFjO0dBQ2Q7RUFDRixDQUFDO0NBQ0gsQ0FBQztDQUNELE1BQU0sZ0JBQWdCO0VBQ3BCLElBQUk7RUFDSjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsY0FBYztFQUNkO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxZQUFZO0NBQ2QsQ0FBQztDQUNELE1BQU0sTUFBTSxjQUFjLFVBQVUsV0FBVyxRQUFRO0NBQ3ZELE1BQU0sa0JBQWtCLFdBQVcsS0FBQSxJQUFZO0NBQy9DLE1BQU0sZUFBQSxhQUFxQixjQUFjO0VBQ3ZDLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxRQUFRLEtBQUssS0FBSyxDQUFDLE1BQ3pDLE9BQU87RUFFVCxPQUFPLE1BQU0sS0FBSSxNQUFLO0dBQ3BCLE1BQU0seUJBQXlCLGlCQUFpQixHQUFHLGlCQUFpQjtHQUNwRSxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLFNBQVM7SUFDaEMsTUFBTTtJQUNBO0lBQ0E7SUFDTixPQUFPO0lBQ0c7R0FDWixHQUFHLHNCQUFzQjtFQUMzQixDQUFDO0NBQ0gsR0FBRztFQUFDO0VBQVU7RUFBTztFQUFNO0VBQU07RUFBbUI7Q0FBUSxDQUFDO0NBQzdELE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxLQUFBLENBQU0sa0JBQWtCLFVBQVU7RUFDcEQsT0FBTztFQUNQLFVBQVU7R0FBYyxlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLHNCQUFzQixVQUFVO0lBQzNELE9BQU87SUFDRztHQUNaLENBQUM7R0FBZ0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxTQUFTO0lBQzdCLEdBQUcsV0FBVyxtQkFBbUIsVUFBVTtLQUN6QyxVQUFVO01BRVIsTUFBTSxNQUFNLGdCQUFnQixNQUFNLEVBRWhDLGNBQWMsS0FDaEIsQ0FBQztLQUNIO0tBRUEsU0FBUyxPQUFPO01BRWQsSUFBSSxNQUFNLFlBQVksb0JBQW9CLFlBQVksVUFDcEQ7TUFFRixNQUFNLFlBQVksTUFBTSxjQUFjO01BQ3RDLE1BQU0sVUFBVSx5QkFBeUJBLE1BQWMsTUFBTSxXQUFXO01BQ3hFLFNBQVMsZUFBZTtPQUN0QixJQUFJLFVBRUY7T0FNRixNQUFNLGlCQUFpQixVQUFVLFlBQVk7T0FDN0MsSUFBSSxnQkFBZ0IsVUFBVSxRQUFRLFdBQVUsY0FBYSxpQkFBaUIsV0FBVyxpQkFBaUIsQ0FBQyxDQUFDLFlBQVksTUFBTSxrQkFBa0IsaUJBQWlCLFdBQVcsaUJBQWlCLENBQUMsQ0FBQyxZQUFZLE1BQU0sY0FBYztPQUMvTixJQUFJLGtCQUFrQixJQUNwQixnQkFBZ0IsVUFBVSxRQUFRLFdBQVcsR0FBRyxVQUFVO1FBQ3hELE1BQU0sZ0JBQWdCLFVBQVUsUUFBUTtRQUN4QyxPQUFPLGlCQUFpQixRQUFRLGNBQWMsWUFBWSxNQUFNO09BQ2xFLENBQUM7T0FFSCxNQUFNLGdCQUFnQixVQUFVLFFBQVE7T0FDeEMsSUFBSSxpQkFBaUIsTUFHbkIsU0FBUyxlQUFlLE9BQU87TUFFbkM7TUFDQSxNQUFNLElBQUksY0FBYyxJQUFJO01BQzVCLGVBQWUsWUFBWTtLQUM3QjtJQUNGLENBQUM7SUFDRCxJQUFJLGVBQWUsbUJBQW1CLE9BQU8sR0FBRyxZQUFZLGlCQUFpQixLQUFBO0lBQ3ZFO0lBQ04sTUFBTTtJQUNRO0lBQ2QsT0FBTztJQUNHO0lBQ1YsVUFBVSxZQUFZLEVBQUUsWUFBWTtJQUMxQjtJQUNMO0lBQ0wsT0FBTyxPQUFPLHNCQUFzQjtJQUNwQyxVQUFVO0lBQ1YsZUFBZTtJQUNmLDBCQUEwQjtHQUM1QixDQUFDO0dBQUc7RUFBWTtDQUNsQixDQUFDO0FBQ0g7O0FDdGRBLFNBQWdCLGtCQUFrQixJQUFJO0NBQ3BDLE9BQU8sTUFBTSxPQUFPLEtBQUEsSUFBWSxHQUFHLEdBQUc7QUFDeEM7QUFDQSxTQUFnQixzQkFBc0IsY0FBYyxjQUFjO0NBQ2hFLE9BQU8sZ0JBQWdCO0FBQ3pCOzs7Ozs7OztBQ1NBLElBQWEsY0FBMkIsMkJBQU0sV0FBVyxTQUFTLFlBQVksZ0JBQWdCLGNBQWM7Q0FDMUcsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLEdBQUcsaUJBQ0Q7Q0FFSixNQUFNLHdCQUF3QjtDQUM5QixPQUFPLHNCQUFzQjtDQUM3QixNQUFNLG1CQUFtQixvQkFBb0I7Q0FDN0MsTUFBTSxRQUFRLHFCQUFxQjtDQUNuQyxNQUFNLGlCQUFpQixNQUFNLFNBQVMsZ0JBQWdCO0NBQ3RELE1BQU0sU0FBUyxNQUFNLFNBQVMsSUFBSTtDQUVsQyxNQUFNLGFBQWEsU0FBUztFQUMxQixJQUZxQixrQkFBa0IsTUFFbkM7RUFDSixtQkFBbUIsZ0JBQWdCLE1BQU07RUFDekMsV0FBVyxhQUFhO0dBQ3RCLE1BQU0sa0JBQWtCLE9BQU8sZ0JBQWdCLGFBQWEsWUFBWSxNQUFNLE1BQU0sT0FBTyxJQUFJO0dBQy9GLE1BQU0sSUFBSSxXQUFXLGVBQWU7RUFDdEM7Q0FDRixDQUFDO0NBQ0QsT0FBTyxpQkFBaUIsT0FBTyxnQkFBZ0I7RUFDN0MsS0FBSztFQUNMLE9BQU8saUJBQWlCO0VBQ3hCLE9BQU8sQ0FBQyxZQUFZLFlBQVk7RUFDaEMsd0JBQXdCO0NBQzFCLENBQUM7QUFDSCxDQUFDO0FBQzBDLFlBQVksY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6Q3JFLElBQWFDLGNBQVlDOzs7O0FBSXpCLElBQWEsVUFBVUM7Ozs7QUFJdkIsSUFBYUMsYUFBVzs7OztBQUl4QixJQUFhLFdBQVc7Ozs7O0FBS3hCLElBQWEsWUFBWTs7OztBQUl6QixJQUFhLFdBQVc7Ozs7QUFJeEIsSUFBYSxRQUFROzs7O0FBSXJCLElBQWEsVUFBVTs7OztBQUl2QixJQUFhLFVBQVU7Ozs7QUFJdkIsSUFBYSxRQUFROzs7O0FBSXJCLElBQWEsU0FBUzs7OztBQUl0QixJQUFhLFVBQVU7Ozs7QUFJdkIsSUFBYUMsZ0JBQWM7O0FDaEMzQixJQUFNLGlCQUFpQjtBQUN2QixJQUFNQywyQkFBeUI7Q0FDN0IsR0FBRztDQUNILEdBQUc7Q0FDSCxZQUFXLFNBQVEsT0FBTyxHQUN2QkMsWUFBd0MsS0FDM0MsSUFBSTtDQUNKLGFBQWE7QUFDZjs7Ozs7OztBQVFBLElBQWEsZ0JBQTZCLDJCQUFNLFdBQVcsU0FBUyxjQUFjLGdCQUFnQixjQUFjO0NBQzlHLE1BQU0sRUFDSixRQUNBLFdBQ0EsSUFBSSxRQUNKLFVBQVUsZUFBZSxPQUN6QixlQUFlLE1BQ2YsT0FDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxFQUNKLFlBQ0EsZ0JBQ0EsWUFDQSxPQUFPLFlBQ1AsVUFBVSxrQkFDUixvQkFBb0I7Q0FDeEIsTUFBTSxFQUNKLFNBQVMsaUJBQ1Asb0JBQW9CO0NBQ3hCLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsTUFBTSxXQUFXLE1BQU0sU0FBUyxVQUFVO0NBQzFDLE1BQU0sV0FBVyxNQUFNLFNBQVMsVUFBVTtDQUMxQyxNQUFNLGlCQUFpQixNQUFNLFNBQVMsVUFBVTtDQUNoRCxNQUFNLFdBQVcsaUJBQWlCLGtCQUFrQjtDQUNwRCxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxVQUFVLE1BQU0sU0FBUyxTQUFTO0NBQ3hDLE1BQU0sUUFBUSxNQUFNLFNBQVMsT0FBTztDQUNwQyxNQUFNLGVBQWUsTUFBTSxTQUFTLGNBQWM7Q0FDbEQsTUFBTSxvQkFBb0IsTUFBTSxTQUFTLG1CQUFtQjtDQUM1RCxNQUFNLGNBQWMsTUFBTSxTQUFTLGFBQWE7Q0FDaEQsTUFBTSxpQkFBaUIsTUFBTSxTQUFTLFdBQVc7Q0FDakQsTUFBTSxTQUFTLE1BQU0sU0FBUyxJQUFJO0NBQ2xDLE1BQU0sZ0JBQWdCLE1BQU0sU0FBUyxTQUFTO0NBQzlDLE1BQU0sbUJBQW1CLE1BQU0sU0FBUyxrQkFBa0I7Q0FDMUQsTUFBTSxZQUFZLFdBQVcsb0JBQW9CLGlCQUFpQjtDQUNsRSxNQUFNLEtBQUssVUFBVTtDQUNyQixNQUFNLGlCQUFpQixzQkFBc0IsY0FBYyxhQUFhO0NBQ3hFLGVBQWUsRUFDYixJQUFJLE9BQ04sQ0FBQztDQUNELE1BQU0sZ0JBQWdCLGNBQWMsaUJBQWlCO0NBQ3JELE1BQU0sYUFBQSxhQUFtQixPQUFPLElBQUk7Q0FDcEMsTUFBTSxhQUFhLG1CQUFtQixVQUFVLFVBQVU7Q0FDMUQsTUFBTSxFQUNKLGdCQUNBLGNBQ0UsVUFBVTtFQUNaO0VBQ0EsUUFBUTtDQUNWLENBQUM7Q0FDRCxNQUFNLG9CQUFvQixNQUFNLGVBQWUsZ0JBQWdCO0NBQy9ELE1BQU0sZUFBZSxXQUFXO0NBQ2hDLE1BQU0sbUJBQW1CLFdBQVc7Q0FDcEMsTUFBTSx1QkFBdUIsV0FBVztDQUN4QyxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLE1BQU07R0FLUixxQkFBcUIsTUFBTSxzQkFBc0I7SUFDL0MsTUFBTSxRQUFRLGFBQWEsUUFBUSx5QkFBeUI7SUFDNUQsTUFBTSxRQUFRLGFBQWEsUUFBUSx1QkFBdUI7R0FDNUQsQ0FBQztHQUNELGFBQWE7SUFDWCxxQkFBcUIsTUFBTTtHQUM3QjtFQUNGO0VBQ0EsTUFBTSxRQUFRLGFBQWEsVUFBVTtHQUNuQyxzQkFBc0I7R0FDdEIsd0JBQXdCO0dBQ3hCLE9BQU87RUFDVDtFQUNBLGlCQUFpQixNQUFNO0NBRXpCLEdBQUc7RUFBQztFQUFNO0VBQU87RUFBa0I7Q0FBb0IsQ0FBQztDQUN4RCxNQUFNLGNBQWMsV0FBVyxjQUFjO0VBQzNDO0VBQ0EsTUFBTTtFQUNOLGlCQUFpQjtFQUNqQixpQkFBaUI7RUFDakIsaUJBQWlCLE9BQU8sYUFBYSxNQUFNLHdCQUF3QixpQkFBaUIsQ0FBQyxFQUFFLEtBQUssS0FBQTtFQUM1RixtQkFBbUI7RUFDbkIsaUJBQWlCLFlBQVksS0FBQTtFQUM3QixpQkFBaUIsWUFBWSxLQUFBO0VBQzdCLFVBQVUsV0FBVyxLQUFLO0VBQzFCLFFBQVEsT0FBTztHQUNiLFdBQVcsSUFBSTtHQUdmLElBQUksUUFBUSxNQUFNLFFBQVEsOEJBQThCLFNBQ3RELE1BQU0sUUFBUSxRQUFRLE9BQU8seUJBQXlCQyxNQUFjLE1BQU0sV0FBVyxDQUFDO0dBTXhGLGFBQWEsTUFBTSxTQUFTO0lBQzFCLE1BQU0sSUFBSSxjQUFjLElBQUk7R0FDOUIsQ0FBQztFQUNIO0VBQ0EsT0FBTyxPQUFPO0dBRVosSUFBSSxTQUFTLG1CQUFtQixNQUFNLGFBQWEsR0FDakQ7R0FFRixXQUFXLElBQUk7R0FDZixXQUFXLEtBQUs7R0FDaEIsSUFBSSxtQkFBbUIsVUFDckIsV0FBVyxPQUFPLEtBQUs7RUFFM0I7RUFDQSxZQUFZLE9BQU87R0FDakIsSUFBSSxNQUNGO0dBRUYsTUFBTSxNQUFNLGNBQWMsTUFBTSxhQUFhO0dBQzdDLFNBQVMsY0FBYyxZQUFZO0lBQ2pDLElBQUksQ0FBQyxXQUFXLFNBQ2Q7SUFFRixNQUFNLGdCQUFnQixXQUFXO0lBSWpDLElBQUksU0FBUyxXQUFXLFNBQVMsYUFBYSxLQUFLLFNBQVMsY0FBYyxTQUFTLGFBQWEsR0FDOUY7SUFFRixJQUFJLG9CQUFvQixZQUFZLFdBQVcsT0FBTyxHQUNwRDtJQUVGLE1BQU0sUUFBUSxRQUFRLE9BQU8seUJBQXlCQyxZQUFvQixVQUFVLENBQUM7R0FDdkY7R0FHQSxpQkFBaUIsTUFBTSxTQUFTO0lBQzlCLElBQUksaUJBQWlCLFdBQVcsZUFBZSxFQUM3QyxNQUFNLEtBQ1IsQ0FBQztHQUNILENBQUM7RUFDSDtDQUNGLEdBQUcsY0FBYyxjQUFjO0NBQy9CLE1BQU0sUUFBUSxXQUFXLG1CQUFtQixVQUFVLFdBQVc7Q0FJakUsTUFBTSxPQUFPO0NBQ2IsTUFBTSxRQUFRO0VBQ1osR0FBRztFQUNIO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxhQUFhLENBQUM7Q0FDaEI7Q0FDQSxPQUFPLGlCQUFpQixVQUFVLGdCQUFnQjtFQUNoRCxLQUFLO0dBQUM7R0FBYztHQUFZO0dBQVc7RUFBaUI7RUFDNUQ7RUFDQSx3QkFBQTtFQUNBO0NBQ0YsQ0FBQztBQUNILENBQUM7QUFDMEMsY0FBYyxjQUFjOztBQ3BNdkUsSUFBTUMsMkJBQXlCLEVBQzdCLGFBQWEsS0FDZjs7Ozs7OztBQVFBLElBQWEsY0FBMkIsMkJBQU0sV0FBVyxTQUFTLFlBQVksZ0JBQWdCLGNBQWM7Q0FDMUcsTUFBTSxFQUNKLFdBQ0EsUUFDQSxVQUFVLGNBQ1YsYUFDQSxPQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLFFBQVEscUJBQXFCO0NBQ25DLE1BQU0sUUFBUSxNQUFNLFNBQVMsT0FBTztDQUNwQyxNQUFNLFFBQVEsTUFBTSxTQUFTLE9BQU87Q0FDcEMsTUFBTSxvQkFBb0IsTUFBTSxTQUFTLG1CQUFtQjtDQUM1RCxNQUFNLG1CQUFtQixNQUFNLFNBQVMsa0JBQWtCO0NBQzFELE1BQU0sMkJBQTJCLENBQUMsb0JBQW9CLGVBQWUsUUFBUSxnQkFBZ0I7Q0FDN0YsTUFBTSxlQUFlLE1BQU0sU0FBUyxvQkFBb0Isd0JBQXdCO0NBQ2hGLE1BQU0sUUFBUTtFQUNaO0VBQ0EsYUFBYSxDQUFDO0NBQ2hCO0NBQ0EsSUFBSSxXQUFXO0NBQ2YsSUFBSSxPQUFPLGlCQUFpQixZQUMxQixXQUFXLGFBQWEsS0FBSztNQUN4QixJQUFJLGdCQUFnQixNQUN6QixXQUFXO01BQ04sSUFBSSw0QkFBNEIsQ0FBQyxjQUN0QyxXQUFXO01BQ04sSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUM1QixXQUFXLHNCQUFzQixPQUFPLE9BQU8saUJBQWlCO01BRWhFLFdBQVcscUJBQXFCLE9BQU8sT0FBTyxpQkFBaUI7Q0FVakUsT0FSZ0IsaUJBQWlCLFFBQVEsZ0JBQWdCO0VBQ3ZEO0VBQ0EsS0FBSyxDQUFDLGNBQWMsTUFBTSxRQUFRLFFBQVE7RUFDMUMsT0FBTyxDQUFDLEVBQ04sU0FDRixHQUFHLFlBQVk7RUFDZix3QkFBQTtDQUNGLENBQ2E7QUFDZixDQUFDO0FBQzBDLFlBQVksY0FBYzs7Ozs7Ozs7QUM3Q3JFLElBQWEsYUFBMEIsMkJBQU0sV0FBVyxTQUFTLFdBQVcsZ0JBQWdCLGNBQWM7Q0FDeEcsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLEdBQUcsaUJBQ0Q7Q0FHSixNQUFNLFFBQVEsRUFDWixNQUhZLHFCQUNHLENBQUMsQ0FBQyxTQUFTLE1BRXZCLEVBQ0w7Q0FVQSxPQVRnQixpQkFBaUIsUUFBUSxnQkFBZ0I7RUFDdkQ7RUFDQSxLQUFLO0VBQ0wsT0FBTyxDQUFDO0dBQ04sZUFBZTtHQUNmLFVBQVU7RUFDWixHQUFHLFlBQVk7RUFDZix3QkFBd0I7Q0FDMUIsQ0FDYTtBQUNmLENBQUM7QUFDMEMsV0FBVyxjQUFjOzs7Ozs7Ozs7QUN0QnBFLElBQWEsZUFBNEIsMkJBQU0sV0FBVyxTQUFTLGFBQWEsYUFBYSxjQUFjO0NBQ3pHLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsTUFBTSxVQUFVLE1BQU0sU0FBUyxTQUFTO0NBQ3hDLE1BQU0sYUFBYSxNQUFNLFNBQVMsWUFBWTtDQUU5QyxJQUFJLEVBRGlCLFdBQVcsYUFFOUIsT0FBTztDQUVULE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssZ0JBQWdCO0VBQ3ZDLEtBQUs7RUFDTCxHQUFHO0NBQ0wsQ0FBQztBQUNILENBQUM7QUFDMEMsYUFBYSxjQUFjOztBQ3BCdEUsSUFBTUMsMkJBQXlCO0NBQzdCLEdBQUc7Q0FDSCxHQUFHO0FBQ0w7Ozs7Ozs7QUFRQSxJQUFhLGlCQUE4QiwyQkFBTSxXQUFXLFNBQVMsZUFBZSxnQkFBZ0IsY0FBYztDQUNoSCxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sVUFBVSxNQUFNLFNBQVMsU0FBUztDQUV4QyxNQUFNLFFBQVE7RUFDWjtFQUNBLGtCQUh1QixNQUFNLFNBQVMsa0JBR3ZCO0NBQ2pCO0NBY0EsT0FiZ0IsaUJBQWlCLE9BQU8sZ0JBQWdCO0VBQ3REO0VBQ0EsS0FBSztFQUNMLE9BQU8sQ0FBQztHQUNOLE1BQU07R0FDTixRQUFRLENBQUM7R0FDVCxPQUFPO0lBQ0wsWUFBWTtJQUNaLGtCQUFrQjtHQUNwQjtFQUNGLEdBQUcsWUFBWTtFQUNmLHdCQUFBO0NBQ0YsQ0FDYTtBQUNmLENBQUM7QUFDMEMsZUFBZSxjQUFjOztBQzVDeEUsSUFBYSwwQkFBdUMsMkJBQU0sY0FBYyxLQUFBLENBQVM7QUFDdEMsd0JBQXdCLGNBQWM7QUFDakYsU0FBZ0IsNkJBQTZCO0NBQzNDLE1BQU0sVUFBQSxhQUFnQixXQUFXLHVCQUF1QjtDQUN4RCxJQUFJLENBQUMsU0FDSCxNQUFNLElBQUksTUFBOEMsZ0hBQTBJO0NBRXBNLE9BQU87QUFDVDs7QUNaQSxTQUFnQixZQUFZLFNBQVMsZ0JBQWdCO0NBQ25ELElBQUksU0FDRixPQUFPLE9BQU8sUUFBUSxPQUFPLGNBQWM7QUFFL0M7QUFDQSxJQUFhLHlCQUF5QjtDQUNwQyxVQUFVO0NBQ1YsV0FBVztDQUNYLFdBQVc7Q0FDWCxXQUFXO0FBQ2I7O0FDU0EsSUFBTSxRQUFRLEVBQ1osVUFBVSxRQUNaOzs7Ozs7O0FBUUEsSUFBYSxtQkFBZ0MsMkJBQU0sV0FBVyxTQUFTLGlCQUFpQixnQkFBZ0IsY0FBYztDQUNwSCxNQUFNLEVBQ0osUUFDQSxXQUNBLFFBR0EsZ0JBQ0EsTUFDQSxPQUNBLFlBQ0EsYUFDQSxvQkFBb0Isc0JBQ3BCLGtCQUNBLGNBQ0EsUUFDQSx1QkFDQSx1QkFBdUIsTUFDdkIscUJBQXFCLDhCQUNyQixPQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLFFBQVEscUJBQXFCO0NBQ25DLE1BQU0sc0JBQXNCLHlCQUF5QjtDQUNyRCxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxVQUFVLE1BQU0sU0FBUyxTQUFTO0NBQ3hDLE1BQU0sUUFBUSxNQUFNLFNBQVMsT0FBTztDQUNwQyxNQUFNLFFBQVEsTUFBTSxTQUFTLE9BQU87Q0FDcEMsTUFBTSxhQUFhLE1BQU0sU0FBUyxZQUFZO0NBQzlDLE1BQU0sb0JBQW9CLE1BQU0sU0FBUyxtQkFBbUI7Q0FDNUQsTUFBTSxpQkFBaUIsTUFBTSxTQUFTLGdCQUFnQjtDQUN0RCxNQUFNLHFCQUFxQixNQUFNLFNBQVMsb0JBQW9CO0NBQzlELE1BQU0sbUJBQW1CLE1BQU0sU0FBUyxrQkFBa0I7Q0FDMUQsTUFBTSxtQkFBQSxhQUF5QixPQUFPLElBQUk7Q0FDMUMsTUFBTSxxQkFBQSxhQUEyQixPQUFPLElBQUk7Q0FDNUMsTUFBTSxDQUFDLGdDQUFnQyxxQ0FBQSxhQUEyQyxTQUFTLG9CQUFvQjtDQUMvRyxNQUFNLDZCQUE2QixXQUFXLGtDQUFrQyxlQUFlO0NBQy9GLElBQUksQ0FBQyxXQUFXLG1DQUFtQyxzQkFDakQsa0NBQWtDLG9CQUFvQjtDQUV4RCxhQUFNLG9CQUFvQixNQUFNLFFBQVEscUNBQXFDLDBCQUEwQjtDQUN2Ryw0QkFBNEIsOEJBQThCLFVBQVUsTUFBTSxlQUFlLFNBQVMsbUJBQW1CLGNBQWM7Q0FDbkksTUFBTSxjQUFjLHFCQUFxQjtFQUN2QztFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSx1QkFBdUIseUJBQXlCO0VBQ2hEO0VBQ0EsYUFBYTtDQUNmLENBQUM7Q0FDRCxNQUFNLGVBQWUsNkJBQTZCLFNBQVMsWUFBWTtDQUN2RSxNQUFNLG1CQUFtQiw2QkFBNkIsUUFBUSxZQUFZO0NBQzFFLE1BQU0sUUFBUTtFQUNaO0VBQ0EsTUFBTTtFQUNOLE9BQU8sWUFBWTtFQUNuQixjQUFjLFlBQVk7Q0FDNUI7Q0FDQSx5QkFBeUI7RUFDdkIsTUFBTSxJQUFJLGFBQWEsWUFBWSxJQUFJO0NBQ3pDLEdBQUcsQ0FBQyxPQUFPLFlBQVksSUFBSSxDQUFDO0NBQzVCLE1BQU0sdUJBQXVCLE1BQU0sZUFBZSxtQkFBbUI7Q0FDckUsTUFBTSxVQUFVLGNBQWMsZ0JBQWdCLE9BQU87RUFDbkQsUUFBUTtFQUNSO0VBQ0EsT0FBTztFQUNQLE1BQU0sQ0FBQyxjQUFjLG9CQUFvQjtFQUN6QyxRQUFRLENBQUM7RUFDVCxPQUFPLENBQUM7Q0FDVixDQUFDO0NBQ0QsTUFBTSxpQkFBQSxhQUF1QixPQUFPLENBQUM7Q0FDckMsTUFBTSxjQUFjLG1CQUFrQixRQUFPO0VBQzNDLElBQUksTUFBTSxRQUFRLFVBQVUsUUFBUSxXQUFXLEdBQzdDO0VBRUYsTUFBTSxXQUFXLGVBQWU7RUFDaEMsZUFBZSxVQUFVLElBQUk7RUFDN0IsTUFBTSxlQUFlLHlCQUF5QkMsSUFBWTtFQUMxRCxJQUFJLGFBQWEsS0FBSyxDQUFDLE1BQU0sTUFBTSxZQUFZLFVBQVUsTUFDNUI7T0FBQSxjQUFjLE1BQU0sUUFBUSxVQUFVLFNBQVMsT0FBTyxrQkFDNUQsTUFBTSxJQUFJO0lBQzdCLE1BQU0sdUJBQXVCLE1BQU0sUUFBUSxnQkFBZ0I7SUFFM0QsTUFBTSxZQURhLHdCQUF3QixRQUFRLGNBQWMsTUFBTSxRQUFRLFVBQVUsU0FBUyxzQkFBc0Isa0JBQWtCLE1BQU0sS0FDakgsdUJBQXVCO0lBQ3RELE1BQU0sUUFBUSxTQUFTLFdBQVcsWUFBWTtJQUM5QyxJQUFJLGNBQWMsTUFBTTtLQUN0QixNQUFNLElBQUksaUJBQWlCLElBQUk7S0FDL0IsTUFBTSxRQUFRLG9CQUFvQixVQUFVO0lBQzlDO0dBQ0Y7O0VBRUYsSUFBSSxhQUFhLEtBQUssTUFBTSxNQUFNLFlBQVksTUFBTSxRQUFRLEtBQUssR0FBRztHQUNsRSxNQUFNLFlBQVksTUFBTSxRQUFPLHNCQUFxQixjQUFjLE1BQU0sUUFBUSxVQUFVLFNBQVMsbUJBQW1CLGtCQUFrQixNQUFNLEVBQUU7R0FDaEosSUFBSSxVQUFVLFdBQVcsTUFBTSxRQUFRO0lBQ3JDLE1BQU0sUUFBUSxTQUFTLFdBQVcsWUFBWTtJQUM5QyxJQUFJLFVBQVUsV0FBVyxHQUFHO0tBQzFCLE1BQU0sSUFBSSxpQkFBaUIsSUFBSTtLQUMvQixNQUFNLFFBQVEsb0JBQW9CLFVBQVU7SUFDOUM7R0FDRjtFQUNGO0VBQ0EsSUFBSSxRQUFRLDRCQUE0QjtHQUN0QyxNQUFNLE9BQU87SUFDWCxzQkFBc0I7SUFDdEIsd0JBQXdCO0dBQzFCLENBQUM7R0FDRCxNQUFNLGdCQUFnQixFQUNwQixRQUFRLEdBQ1Y7R0FDQSxZQUFZLG1CQUFtQixhQUFhO0dBQzVDLFlBQVksTUFBTSxRQUFRLFNBQVMsU0FBUyxhQUFhO0VBQzNEO0NBQ0YsQ0FBQztDQUNELE1BQU0sZUFBQSxhQUFxQixlQUFlO0VBQ3hDLEdBQUc7RUFDSCxNQUFNO0VBQ047RUFDQTtFQUNBO0VBQ0E7Q0FDRixJQUFJO0VBQUM7RUFBYTtFQUFjO0VBQTRCO0NBQWlDLENBQUM7Q0FDOUYsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxlQUFlO0VBQ3RDLGFBQWEsTUFBTSxRQUFRO0VBQzNCLFdBQVcsTUFBTSxRQUFRO0VBQ1o7RUFDYixVQUF1QixlQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFNLHdCQUF3QixVQUFVO0dBQzdELE9BQU87R0FDUCxVQUFVLENBQUMsV0FBVyxTQUFzQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGtCQUFrQjtJQUNqRSxPQUFPLFdBQVcsQ0FBQyxJQUFJO0lBQ3ZCLFFBQVE7R0FDVixDQUFDLEdBQUcsT0FBTztFQUNiLENBQUM7Q0FDSCxDQUFDO0FBQ0gsQ0FBQztBQUMwQyxpQkFBaUIsY0FBYzs7QUMzSzFFLElBQU0sK0JBQStCO0FBQ3JDLElBQWEsd0JBQXdCO0NBQ25DLFdBQVc7Q0FDWCxXQUFXLE9BQU87RUFDaEIsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxTQUFTO0dBQ3pCO0dBQ1AsTUFBTTtHQUNOLFlBQVk7R0FDWixVQUFVLElBQUksNkJBQTZCLHlCQUF5Qiw2QkFBNkI7RUFDbkcsQ0FBQztDQUNIO0FBQ0Y7QUFDMkMsc0JBQXNCLFdBQVcsY0FBYzs7Ozs7Ozs7Ozs7OztBQ1QxRixJQUFhLGlCQUFpQjs7Ozs7QUFLOUIsSUFBYSxrQkFBa0I7Ozs7O0FBSy9CLElBQWEsY0FBYzs7Ozs7QUFLM0IsSUFBYSxlQUFlOzs7OztBQUs1QixJQUFhLGtCQUFrQjs7QUNNL0IsSUFBTSx5QkFBeUI7Q0FDN0IsR0FBRztDQUNILEdBQUc7QUFDTDs7Ozs7OztBQVFBLElBQWEsY0FBMkIsMkJBQU0sV0FBVyxTQUFTLFlBQVksZ0JBQWdCLGNBQWM7Q0FDMUcsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLFlBQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsTUFBTSxXQUFXLE1BQU0sU0FBUyxVQUFVO0NBQzFDLE1BQU0sV0FBVyxNQUFNLFNBQVMsVUFBVTtDQUMxQyxNQUFNLHVCQUF1QixNQUFNLFNBQVMsc0JBQXNCO0NBQ2xFLE1BQU0sc0JBQXNCLHlCQUF5QjtDQUNyRCxNQUFNLEVBQ0osTUFDQSxPQUNBLDRCQUNBLGNBQ0Esc0NBQ0UsMkJBQTJCO0NBQy9CLE1BQU0sZ0JBQWdCLHNCQUFzQixJQUFJLEtBQUs7Q0FDckQsTUFBTSxZQUFZLGFBQWE7Q0FDL0IsTUFBTSxFQUNKLE9BQ0EseUJBQ0UsY0FBYztDQUNsQixNQUFNLEtBQUssTUFBTSxTQUFTLElBQUk7Q0FDOUIsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sYUFBYSxNQUFNLFNBQVMsWUFBWTtDQUM5QyxNQUFNLFVBQVUsTUFBTSxTQUFTLFNBQVM7Q0FDeEMsTUFBTSxhQUFhLE1BQU0sU0FBUyxZQUFZO0NBQzlDLE1BQU0sbUJBQW1CLE1BQU0sU0FBUyxrQkFBa0I7Q0FDMUQsTUFBTSxpQkFBaUIsTUFBTSxTQUFTLGdCQUFnQjtDQUN0RCxNQUFNLG9CQUFvQixNQUFNLFNBQVMsbUJBQW1CO0NBQzVELE1BQU0sY0FBYyxNQUFNLFNBQVMsYUFBYTtDQUNoRCxNQUFNLHNCQUFBLGFBQTRCLE9BQU8sS0FBSztDQUM5QyxNQUFNLG1CQUFBLGFBQXlCLE9BQU8sS0FBSztDQUMzQyxNQUFNLDhCQUFBLGFBQW9DLE9BQU8sQ0FBQyxDQUFDO0NBQ25ELE1BQU0sbUJBQW1CLGtCQUFrQjtDQUMzQyxNQUFNLGVBQWUsbUJBQWtCLGFBQVk7RUFDakQsSUFBSSxDQUFDLHFCQUFxQixDQUFDLE1BQU0sUUFBUSxTQUFTLFdBQVcsQ0FBQyxpQkFBaUIsU0FDN0U7RUFFRixNQUFNLGtCQUFrQixrQkFBa0IsTUFBTSxRQUFRO0VBQ3hELE1BQU0scUJBQXFCLGtCQUFrQixNQUFNLFdBQVc7RUFDOUQsSUFBSSxvQkFBb0IsV0FBVyxDQUFDLDhCQUE4QixDQUFDLG1CQUFtQixDQUFDLG9CQUFvQjtHQUN6RyxNQUFNLFFBQVEsNEJBQTRCLFFBQVE7R0FDbEQ7RUFDRjtFQUNBLE1BQU0sUUFBUSxTQUFTLGlCQUFpQjtFQUN4QyxNQUFNLGdCQUFnQixjQUFjLGtCQUFrQixzQkFBc0IsQ0FBQyxDQUFDLFFBQVEsS0FBSyxLQUFLO0VBQ2hHLE1BQU0sTUFBTSxjQUFjLGlCQUFpQjtFQUMzQyxNQUFNLE1BQU1DLFVBQVksaUJBQWlCO0VBQ3pDLE1BQU0sbUJBQW1CLElBQUksaUJBQWlCLGlCQUFpQjtFQUMvRCxNQUFNLFlBQVksV0FBVyxpQkFBaUIsU0FBUztFQUN2RCxNQUFNLGVBQWUsV0FBVyxpQkFBaUIsWUFBWTtFQUM3RCxNQUFNLGlCQUFpQixrQkFBa0IsSUFBSSxpQkFBaUIsTUFBTSxRQUFRLFNBQVMsT0FBTyxDQUFDO0VBQzdGLE1BQU0scUJBQXFCLEtBQUssSUFBSSxJQUFJLGdCQUFnQixlQUFlLFlBQVksY0FBYyxjQUFjO0VBQy9HLE1BQU0sWUFBWSxTQUFTO0VBQzNCLE1BQU0sZUFBZSxnQkFBZ0IsUUFBUTtFQUc3QyxJQUFJLGdCQUFnQjtFQUNwQixNQUFNLGFBQVksV0FBVTtHQUMxQixrQkFBa0IsTUFBTSxTQUFTLEdBQUcsT0FBTztFQUM3QztFQUNBLE1BQU0sT0FBTyxrQkFBa0IsZUFBZSxZQUFZO0VBQzFELE1BQU0sYUFBYSxLQUFLLElBQUksZ0JBQWdCLE1BQU0sa0JBQWtCO0VBQ3BFLElBQUksUUFBQSxHQUFrQztHQUNwQyxNQUFNLGNBQWMsTUFBTSxNQUFNLEdBQUcscUJBQXFCLGFBQWE7R0FDckUsSUFBSSxjQUFjLEdBRWhCLFVBQVUsZ0JBQWdCLFdBQVc7R0FFdkMsU0FBUyxZQUFZLGtCQUFrQixlQUFlO0dBQ3RELElBQUksc0JBQXNCLGdCQUFnQixnQkFBQSxHQUN4QyxvQkFBb0IsVUFBVTtHQUVoQyxNQUFNLFFBQVEsNEJBQTRCLFFBQVE7R0FDbEQ7RUFDRjtFQUNBLElBQUkscUJBQXFCLGFBQUEsR0FDdkIsZ0JBQWdCLGtCQUFrQixXQUFXO09BQ3hDLElBQUksc0JBQXNCLFlBQVksY0FFM0MsZ0JBQWdCLGFBQWEsUUFEWCxnQkFBZ0IsT0FBTztFQUczQyxNQUFNLHVCQUF1QixLQUFLLEtBQUssVUFBVTtFQUNqRCxJQUFJLHlCQUF5QixHQUMzQixVQUFVLG9CQUFvQjtFQUVoQyxJQUFJLGlCQUFpQixNQUFNO0dBRXpCLE1BQU0sU0FBUyxNQUFNLGVBQWUsR0FBRyxnQkFBZ0IsUUFBUSxDQUFDO0dBR2hFLElBQUksS0FBSyxJQUFJLFNBQVMsWUFBWSxNQUFNLElBQUEsR0FDdEMsU0FBUyxZQUFZO0VBRXpCO0VBQ0EsSUFBSSx3QkFBd0IscUJBQUEsR0FDMUIsb0JBQW9CLFVBQVU7RUFFaEMsTUFBTSxRQUFRLDRCQUE0QixRQUFRO0NBQ3BELENBQUM7Q0FDRCxhQUFNLG9CQUFvQixNQUFNLFFBQVEsd0JBQXdCLGNBQWMsQ0FBQyxZQUFZLENBQUM7Q0FDNUYsc0JBQXNCO0VBQ3BCO0VBQ0EsS0FBSyxNQUFNLFFBQVE7RUFDbkIsYUFBYTtHQUNYLElBQUksTUFDRixNQUFNLFFBQVEscUJBQXFCLElBQUk7RUFFM0M7Q0FDRixDQUFDO0NBQ0QsTUFBTSxRQUFRO0VBQ1o7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtDQUNBLHlCQUF5QjtFQUN2QixJQUFJLENBQUMscUJBQXFCLENBQUMsTUFBTSxRQUFRLFNBQVMsV0FBVyxPQUFPLEtBQUssNEJBQTRCLE9BQU8sQ0FBQyxDQUFDLFFBQzVHO0VBRUYsNEJBQTRCLFVBQVU7R0FDcEMsS0FBSyxrQkFBa0IsTUFBTSxPQUFPO0dBQ3BDLE1BQU0sa0JBQWtCLE1BQU0sUUFBUTtHQUN0QyxPQUFPLGtCQUFrQixNQUFNO0dBQy9CLFFBQVEsa0JBQWtCLE1BQU07R0FDaEMsUUFBUSxrQkFBa0IsTUFBTTtHQUNoQyxXQUFXLGtCQUFrQixNQUFNO0dBQ25DLFdBQVcsa0JBQWtCLE1BQU07R0FDbkMsV0FBVyxrQkFBa0IsTUFBTTtHQUNuQyxjQUFjLGtCQUFrQixNQUFNO0VBQ3hDO0NBQ0YsR0FBRyxDQUFDLE9BQU8saUJBQWlCLENBQUM7Q0FDN0IseUJBQXlCO0VBQ3ZCLElBQUksUUFBUSw0QkFDVjtFQUVGLGlCQUFpQixVQUFVO0VBQzNCLG9CQUFvQixVQUFVO0VBQzlCLFlBQVksbUJBQW1CLDRCQUE0QixPQUFPO0NBQ3BFLEdBQUc7RUFBQztFQUFNO0VBQTRCO0NBQWlCLENBQUM7Q0FDeEQseUJBQXlCO0VBQ3ZCLE1BQU0sZUFBZSxNQUFNLFFBQVEsU0FBUztFQUs1QyxJQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLHFCQUFxQixDQUFDLGdCQUFnQiw4QkFBOEIsQ0FBQyxnQkFBZ0IsTUFBTSxNQUFNLHFCQUFxQixVQUNySjtFQUVGLGlCQUFpQixVQUFVO0VBQzNCLGFBQWEsTUFBTSxlQUFlQyxlQUF1QztFQUN6RSxJQUFJLENBQUMsNEJBQTRCO0dBRy9CLGlCQUFpQixjQUFjLE1BQU0sUUFBUSw0QkFBNEIsZUFBZSxZQUFZLENBQUM7R0FDckc7RUFDRjtFQUlBLE1BQU0seUJBQXlCLHFCQUFxQixZQUFZO0VBQ2hFLElBQUk7R0FDRixJQUFJLGNBQWMsTUFBTSxRQUFRLG9CQUFvQjtHQUNwRCxJQUFJLENBQUMsYUFBYSxhQUVoQixjQUFjLENBRFcsTUFBTSxPQUFPLGtCQUNSLEtBQUssTUFBTSxRQUFRLGlCQUFpQixTQUFTLGNBQWMsTUFBTSxRQUFRLGlCQUFpQixVQUFVO0dBRXBJLE1BQU0sZUFBZSxNQUFNLFFBQVEsU0FBUztHQUM1QyxNQUFNLE1BQU1ELFVBQVksaUJBQWlCO0dBQ3pDLE1BQU0sbUJBQW1CLElBQUksaUJBQWlCLGlCQUFpQjtHQUMvRCxNQUFNLGNBQWMsSUFBSSxpQkFBaUIsWUFBWTtHQUNyRCxNQUFNLE1BQU0sY0FBYyxjQUFjO0dBQ3hDLE1BQU0sUUFBUSxTQUFTLGNBQWM7R0FDckMsTUFBTSxjQUFjLGNBQWMsZUFBZSxzQkFBc0IsR0FBRyxLQUFLO0dBQy9FLE1BQU0saUJBQWlCLGNBQWMsa0JBQWtCLHNCQUFzQixHQUFHLEtBQUs7R0FDckYsTUFBTSxnQkFBZ0IsWUFBWTtHQUNsQyxNQUFNLFdBQVcsZUFBZTtHQUNoQyxNQUFNLGVBQWUsU0FBUztHQUM5QixNQUFNLGVBQWUsV0FBVyxZQUFZLGlCQUFpQjtHQUk3RCxNQUFNLFlBQVksV0FBVyxpQkFBaUIsU0FBUyxLQUFLO0dBQzVELE1BQU0sZUFBZSxXQUFXLGlCQUFpQixZQUFZLEtBQUs7R0FDbEUsTUFBTSxZQUFZLFdBQVcsaUJBQWlCLFNBQVMsS0FBSztHQUM1RCxNQUFNLGlCQUFpQixrQkFBa0IsV0FBVztHQUNwRCxNQUFNLGNBQWM7R0FDcEIsTUFBTSxlQUFlO0dBQ3JCLE1BQU0sNEJBQTRCO0dBQ2xDLE1BQU0saUJBQWlCLElBQUksZ0JBQWdCLGVBQWUsWUFBWTtHQUN0RSxNQUFNLGdCQUFnQixJQUFJLGdCQUFnQjtHQUMxQyxNQUFNLCtCQUErQixpQkFBaUIsWUFBWSxTQUFTO0dBQzNFLElBQUk7R0FDSixJQUFJLGNBQWMsY0FBYyxRQUFRLFlBQVksUUFBUSxlQUFlLFFBQVEsWUFBWTtHQUMvRixJQUFJLFVBQVU7R0FDZCxJQUFJLGVBQWUsY0FBYztJQUMvQixNQUFNLFlBQVksY0FBYyxhQUFhLHNCQUFzQixHQUFHLEtBQUs7SUFDM0UsV0FBVyxjQUFjLFlBQVksc0JBQXNCLEdBQUcsS0FBSztJQUNuRSxjQUFjLGVBQWUsUUFBUSxjQUFjLFFBQVEsVUFBVSxRQUFRLFNBQVMsUUFBUSxVQUFVLE9BQU8sU0FBUztJQUN4SCxNQUFNLDRCQUE0QixVQUFVLE1BQU0sWUFBWSxNQUFNLFVBQVUsU0FBUztJQUV2RixVQURvQyxTQUFTLE1BQU0sZUFBZSxNQUFNLFNBQVMsU0FBUyxJQUNsRDtHQUMxQztHQUNBLE1BQU0sY0FBYywrQkFBK0IsVUFBVSxlQUFlO0dBQzVFLElBQUksU0FBUyxLQUFLLElBQUksZ0JBQWdCLFdBQVc7R0FDakQsTUFBTSxZQUFZLGlCQUFpQixZQUFZO0dBQy9DLE1BQU0sWUFBWSxjQUFjO0dBQ2hDLE1BQU0sV0FBVyxnQkFBZ0I7R0FDakMsa0JBQWtCLE1BQU0sT0FBTyxHQUFHLE1BQU0sYUFBYSxhQUFhLFdBQVcsZUFBZSxLQUFLLEVBQUU7R0FDbkcsa0JBQWtCLE1BQU0sU0FBUyxHQUFHLE9BQU87R0FHM0Msa0JBQWtCLE1BQU0sWUFBWTtHQUNwQyxrQkFBa0IsTUFBTSxZQUFZLEdBQUcsVUFBVTtHQUNqRCxrQkFBa0IsTUFBTSxlQUFlLEdBQUcsYUFBYTtHQUN2RCxhQUFhLE1BQU0sU0FBUztHQUM1QixNQUFNLGVBQWUsZ0JBQWdCLFFBQVE7R0FDN0MsTUFBTSxrQkFBa0IsYUFBYSxlQUFBO0dBQ3JDLElBQUksaUJBQ0YsU0FBUyxLQUFLLElBQUksZ0JBQWdCLGVBQWUsTUFBTSxLQUFLLFlBQVk7R0FLMUUsTUFBTSxnQ0FBZ0MsWUFBWSxNQUFNLDZCQUE2QixZQUFZLFNBQVMsaUJBQWlCLDZCQUE2QixLQUFLLEtBQUssTUFBTSxJQUFBLElBQStCLEtBQUssSUFBSSxjQUFjLFNBQVM7R0FHdk8sTUFBTSxpQkFBaUIsSUFBSSxnQkFBZ0IsU0FBUyxPQUFPLEtBQUtFO0dBQ2hFLElBQUksaUNBQWlDLGVBQWU7SUFDbEQsWUFBWSxtQkFBbUIsNEJBQTRCLE9BQU87SUFDbEUsa0NBQWtDLEtBQUs7SUFDdkM7R0FDRjtHQUNBLE1BQU0sZ0JBQWdCLEtBQUssSUFBSSxXQUFXLE1BQU07R0FDaEQsSUFBSSxpQkFBaUI7SUFDbkIsTUFBTSxZQUFZLEtBQUssSUFBSSxHQUFHLGlCQUFpQixXQUFXO0lBQzFELGtCQUFrQixNQUFNLE1BQU0sZUFBZSxVQUFVLFlBQVksTUFBTSxHQUFHLFVBQVU7SUFDdEYsa0JBQWtCLE1BQU0sU0FBUyxHQUFHLE9BQU87SUFDM0MsU0FBUyxZQUFZLGdCQUFnQixRQUFRO0dBQy9DLE9BQU87SUFDTCxrQkFBa0IsTUFBTSxTQUFTO0lBQ2pDLFNBQVMsWUFBWTtHQUN2QjtHQUNBLElBQUksVUFBVTtJQUNaLE1BQU0sV0FBVyxlQUFlO0lBQ2hDLE1BQU0sY0FBYyxlQUFlO0lBQ25DLE1BQU0sY0FBYyxTQUFTLE1BQU0sU0FBUyxTQUFTO0lBQ3JELE1BQU0sV0FBVyxNQUFNLGNBQWMsS0FBSyxjQUFjLFlBQVksY0FBYyxNQUFNLElBQUksR0FBRyxHQUFHO0lBQ2xHLGFBQWEsTUFBTSxZQUFZRCxpQkFBeUMsT0FBTyxTQUFTLEVBQUU7R0FDNUY7R0FDQSxJQUFJLGtCQUFrQixrQkFBa0IsVUFBVSxnQkFDaEQsb0JBQW9CLFVBQVU7R0FFaEMsTUFBTSxRQUFRLDRCQUE0QixRQUFRO0dBQ2xELElBQUksd0JBQXdCLE1BQU0sTUFBTSxrQkFBa0IsUUFBUSxNQUFNLE1BQU0sZ0JBQWdCLFFBQVEsTUFBTSxRQUFRLFFBQVEsUUFBUSxNQUFNLE1BQ3hJLE1BQU0sSUFBSSxlQUFlLENBQUM7RUFFOUIsVUFBVTtHQUNSLHVCQUF1QjtFQUN6QjtDQUNGLEdBQUc7RUFBQztFQUFPO0VBQU07RUFBbUI7RUFBZ0I7RUFBNEI7RUFBbUM7RUFBa0I7RUFBYTtFQUFzQjtFQUFXO0NBQVksQ0FBQztDQUNoTSxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLENBQUMsOEJBQThCLENBQUMscUJBQXFCLENBQUMsTUFDeEQ7RUFFRixNQUFNLE1BQU1ELFVBQVksaUJBQWlCO0VBQ3pDLFNBQVMsYUFBYSxPQUFPO0dBQzNCLE1BQU0sUUFBUSxRQUFRLE9BQU8seUJBQXlCRyxjQUFzQixLQUFLLENBQUM7RUFDcEY7RUFDQSxPQUFPLGlCQUFpQixLQUFLLFVBQVUsWUFBWTtDQUNyRCxHQUFHO0VBQUM7RUFBTztFQUE0QjtFQUFtQjtDQUFJLENBQUM7Q0FDL0QsTUFBTSxlQUFlO0VBQ25CLEdBQUksY0FBYyxFQUNoQixNQUFNLGVBQ1IsSUFBSTtHQUNGLE1BQU07R0FDTix3QkFBd0IsWUFBWSxLQUFBO0dBQ3BDLGlCQUFpQixZQUFZLEtBQUE7R0FDN0IsSUFBSSxHQUFHLEdBQUc7RUFDWjtFQUNBLFVBQVUsT0FBTztHQUNmLElBQUksaUJBQWlCLGVBQWUsSUFBSSxNQUFNLEdBQUcsR0FDL0MsTUFBTSxnQkFBZ0I7RUFFMUI7RUFDQSxTQUFTLE9BQU87R0FDZCxJQUFJLGFBQ0Y7R0FFRixhQUFhLE1BQU0sYUFBYTtFQUNsQztFQUNBLEdBQUksOEJBQThCLEVBQ2hDLE9BQU8sY0FBYyxFQUNuQixRQUFRLE9BQ1YsSUFBSSx1QkFDTjtFQUNBLFdBQVcsQ0FBQyxlQUFlLDZCQUE2QixzQkFBc0IsWUFBWSxLQUFBO0NBQzVGO0NBQ0EsTUFBTSxVQUFVLGlCQUFpQixPQUFPLGdCQUFnQjtFQUN0RCxLQUFLLENBQUMsY0FBYyxNQUFNLFFBQVEsUUFBUTtFQUMxQztFQUNBO0VBQ0EsT0FBTztHQUFDO0dBQVk7R0FBYyxpQ0FBaUMsZ0JBQWdCO0dBQUc7RUFBWTtDQUNwRyxDQUFDO0NBQ0QsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBQSxhQUFZLFVBQVUsRUFDeEMsVUFBVSxDQUFDLENBQUMsd0JBQXdCLHNCQUFzQixXQUFXLEtBQUssR0FBZ0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxzQkFBc0I7RUFDbkgsU0FBUztFQUNULE9BQU87RUFDUCxVQUFVLENBQUM7RUFDWCxxQkFBcUI7RUFDckIsYUFBYTtFQUNiLGNBQWM7RUFDZCxVQUFVO0NBQ1osQ0FBQyxDQUFDLEVBQ0osQ0FBQztBQUNILENBQUM7QUFDMEMsWUFBWSxjQUFjO0FBQ3JFLFNBQVMsa0JBQWtCLGFBQWE7Q0FDdEMsTUFBTSxpQkFBaUIsWUFBWTtDQUNuQyxPQUFPLGVBQWUsU0FBUyxJQUFJLElBQUksV0FBVyxjQUFjLEtBQUssV0FBVztBQUNsRjtBQUNBLFNBQVMsZ0JBQWdCLFVBQVU7Q0FDakMsT0FBTyxtQkFBbUIsU0FBUyxjQUFjLFNBQVMsWUFBWTtBQUN4RTtBQUNBLFNBQVMsU0FBUyxTQUFTO0NBRXpCLE9BQU9DLFNBQWlCLFNBQVMsT0FBTztBQUMxQztBQUNBLFNBQVMsY0FBYyxNQUFNLE1BQU0sT0FBTztDQUN4QyxPQUFPLE9BQU8sTUFBTTtBQUN0QjtBQUNBLFNBQVMsY0FBYyxNQUFNLE9BQU87Q0FDbEMsT0FBTyxpQkFBaUI7RUFDdEIsR0FBRyxjQUFjLEtBQUssR0FBRyxLQUFLLEtBQUs7RUFDbkMsR0FBRyxjQUFjLEtBQUssR0FBRyxLQUFLLEtBQUs7RUFDbkMsT0FBTyxjQUFjLEtBQUssT0FBTyxLQUFLLEtBQUs7RUFDM0MsUUFBUSxjQUFjLEtBQUssUUFBUSxLQUFLLEtBQUs7Q0FDL0MsQ0FBQztBQUNIO0FBQ0EsSUFBTSx5QkFBeUI7Q0FBQyxDQUFDLGFBQWEsTUFBTTtDQUFHLENBQUMsU0FBUyxHQUFHO0NBQUcsQ0FBQyxhQUFhLEtBQUs7QUFBQztBQUMzRixTQUFTLHFCQUFxQixjQUFjO0NBQzFDLE1BQU0sRUFDSixVQUNFO0NBQ0osTUFBTSxpQkFBaUIsQ0FBQztDQUN4QixLQUFLLE1BQU0sQ0FBQyxVQUFVLFVBQVUsd0JBQXdCO0VBQ3RELGVBQWUsWUFBWSxNQUFNLGlCQUFpQixRQUFRO0VBQzFELE1BQU0sWUFBWSxVQUFVLE9BQU8sV0FBVztDQUNoRDtDQUNBLGFBQWE7RUFDWCxLQUFLLE1BQU0sQ0FBQyxhQUFhLHdCQUF3QjtHQUMvQyxNQUFNLGdCQUFnQixlQUFlO0dBQ3JDLElBQUksZUFDRixNQUFNLFlBQVksVUFBVSxhQUFhO1FBRXpDLE1BQU0sZUFBZSxRQUFRO0VBRWpDO0NBQ0Y7QUFDRjs7Ozs7Ozs7QUN0WUEsSUFBYSxhQUEwQiwyQkFBTSxXQUFXLFNBQVMsV0FBVyxnQkFBZ0IsY0FBYztDQUN4RyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsTUFBTSxXQUFXLE1BQU0sU0FBUyxVQUFVO0NBQzFDLE1BQU0sV0FBVyxNQUFNLFNBQVMsVUFBVTtDQUMxQyxNQUFNLEVBQ0osK0JBQ0UsMkJBQTJCO0NBQy9CLE1BQU0sa0JBQWtCLE1BQU0sU0FBUyxpQkFBaUI7Q0FDeEQsTUFBTSxhQUFhLE1BQU0sU0FBUyxZQUFZO0NBRTlDLE1BQU0sZUFBZTtFQUNuQixJQUFJLEdBRkssTUFBTSxTQUFTLElBRWhCLEVBQUU7RUFDVixNQUFNO0VBQ04sd0JBQXdCLFlBQVksS0FBQTtFQUNwQyxpQkFBaUIsWUFBWSxLQUFBO0VBQzdCLFNBQVMsT0FBTztHQUNkLE1BQU0sUUFBUSxpQkFBaUIsVUFBVSxNQUFNLGFBQWE7RUFDOUQ7RUFDQSxHQUFJLDhCQUE4QixFQUNoQyxPQUFPLHVCQUNUO0VBQ0EsV0FBVyxtQkFBbUIsZUFBZSxVQUFVLHNCQUFzQixZQUFZLEtBQUE7Q0FDM0Y7Q0FDQSxNQUFNLGlCQUFpQixNQUFNLGVBQWUsYUFBYTtDQUN6RCxPQUFPLGlCQUFpQixPQUFPLGdCQUFnQjtFQUM3QyxLQUFLLENBQUMsY0FBYyxjQUFjO0VBQ2xDLE9BQU8sQ0FBQyxjQUFjLFlBQVk7Q0FDcEMsQ0FBQztBQUNILENBQUM7QUFDMEMsV0FBVyxjQUFjOztBQzlDcEUsSUFBYSxvQkFBaUMsMkJBQU0sY0FBYyxLQUFBLENBQVM7QUFDaEMsa0JBQWtCLGNBQWM7QUFDM0UsU0FBZ0IsdUJBQXVCO0NBQ3JDLE1BQU0sVUFBQSxhQUFnQixXQUFXLGlCQUFpQjtDQUNsRCxJQUFJLENBQUMsU0FDSCxNQUFNLElBQUksTUFBOEMsOEZBQXdIO0NBRWxMLE9BQU87QUFDVDs7Ozs7Ozs7QUNTQSxJQUFhLGFBQTBCLDJCQUFNLEtBQWtCLDJCQUFNLFdBQVcsU0FBUyxXQUFXLGdCQUFnQixjQUFjO0NBQ2hJLE1BQU0sRUFDSixRQUNBLFdBQ0EsT0FDQSxPQUFPLFlBQVksTUFDbkIsT0FDQSxVQUFVLGVBQWUsT0FDekIsZUFBZSxPQUNmLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLFVBQUEsYUFBZ0IsT0FBTyxJQUFJO0NBQ2pDLE1BQU0sV0FBVyxxQkFBcUI7RUFDcEMsT0FBTztFQUNQO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsTUFBTSxRQUFRLHFCQUFxQjtDQUNuQyxNQUFNLEVBQ0osT0FBTyxXQUNQLFVBQ0EsVUFBVSxnQkFDVixVQUNBLHVCQUNFLE1BQU0sU0FBUyxVQUFVO0NBQzdCLE1BQU0sV0FBVyxrQkFBa0I7Q0FDbkMsTUFBTSxjQUFjLE1BQU0sU0FBUyxZQUFZLFNBQVMsS0FBSztDQUM3RCxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxXQUFXLE1BQU0sU0FBUyxjQUFjLFNBQVM7Q0FDdkQsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLHFCQUFxQixTQUFTLEtBQUs7Q0FDMUUsTUFBTSxRQUFRLFNBQVM7Q0FDdkIsTUFBTSxVQUFBLGFBQWdCLE9BQU8sSUFBSTtDQUNqQyx5QkFBeUI7RUFDdkIsTUFBTSxTQUFTLE1BQU0sUUFBUSxVQUFVO0VBQ3ZDLE9BQU8sU0FBUztFQUNoQixhQUFhO0dBQ1gsT0FBTyxPQUFPO0VBQ2hCO0NBQ0YsR0FBRztFQUFDO0VBQU87RUFBVztDQUFLLENBQUM7Q0FDNUIseUJBQXlCO0VBQ3ZCLE1BQU0sZ0JBQWdCLE1BQU0sTUFBTTtFQUNsQyxNQUFNLGVBQWUsTUFBTSxNQUFNO0VBQ2pDLElBQUksWUFBWTtFQUNoQixJQUFJO0VBQ0osSUFBSSxZQUFZLE1BQU0sUUFBUSxhQUFhLEdBQUc7R0FFNUMsWUFBWSxxQkFBcUIsT0FBTyxXQUFXLE1BQU0sUUFBUSxVQUFVLFNBQVMsZUFBZSxvQkFBb0IsWUFBWTtHQUNuSSxTQUFTLGNBQWM7R0FDdkIsSUFBSSxVQUFVLGdCQUFnQixDQUFDLFFBQzdCLE1BQU0sUUFBUSxvQkFBb0IsVUFBVTtFQUVoRCxPQUFPO0dBQ0wsU0FBUyxrQkFBa0IsS0FBQSxLQUFhLG9CQUFvQixXQUFXLGVBQWUsa0JBQWtCO0dBQ3hHLElBQUksUUFDRixZQUFZO0VBRWhCO0VBQ0EsTUFBTSxJQUFJLGlCQUFpQixTQUFTO0VBSXBDLElBQUksVUFBVSxRQUFRLFNBQ3BCLE1BQU0sUUFBUSxvQkFBb0IsVUFBVSxRQUFRO0NBRXhELEdBQUc7RUFBQztFQUFPO0VBQVU7RUFBb0I7RUFBTztDQUFTLENBQUM7Q0FDMUQsTUFBTSxpQkFBQSxhQUF1QixPQUFPLE9BQU87Q0FDM0MsTUFBTSx5QkFBQSxhQUErQixPQUFPLEtBQUs7Q0FDakQsTUFBTSxFQUNKLGdCQUNBLGNBQ0UsVUFBVTtFQUNaO0VBQ0EsdUJBQXVCO0VBQ3ZCLFFBQVE7RUFDUixXQUFXO0NBQ2IsQ0FBQztDQUNELE1BQU0sUUFBUTtFQUNaO0VBQ0E7RUFDQTtDQUNGO0NBQ0EsU0FBUyxnQkFBZ0IsT0FBTztFQUc5QixJQUFJLGtCQUFrQixVQUNwQjtFQUVGLE1BQU0sZ0JBQWdCLE1BQU0sTUFBTTtFQUNsQyxJQUFJLFVBQVU7R0FDWixNQUFNLGVBQWUsTUFBTSxRQUFRLGFBQWEsSUFBSSxnQkFBZ0IsQ0FBQztHQUNyRSxNQUFNLFlBQVksV0FBVyxXQUFXLGNBQWMsV0FBVyxrQkFBa0IsSUFBSSxDQUFDLEdBQUcsY0FBYyxTQUFTO0dBQ2xILE1BQU0sUUFBUSxTQUFTLFdBQVcseUJBQXlCQyxXQUFtQixLQUFLLENBQUM7RUFDdEYsT0FBTztHQUNMLE1BQU0sUUFBUSxTQUFTLFdBQVcseUJBQXlCQSxXQUFtQixLQUFLLENBQUM7R0FDcEYsTUFBTSxRQUFRLFFBQVEsT0FBTyx5QkFBeUJBLFdBQW1CLEtBQUssQ0FBQztFQUNqRjtDQUNGO0NBQ0EsU0FBUyxvQkFBb0I7RUFDM0IsTUFBTSxRQUFRLGFBQWEsUUFBUSxRQUFRO0NBQzdDO0NBQ0EsTUFBTSxlQUFlO0VBQ25CLE1BQU07RUFDTixpQkFBaUI7RUFDakIsVUFBVSxRQUFRLGNBQWMsSUFBSTtFQUNwQyxVQUFVLE9BQU87R0FDZixNQUFNLElBQUksZUFBZSxLQUFLO0dBQzlCLElBQUksTUFBTSxRQUFRLE9BQU8sTUFBTSxRQUFRLFVBQVUsU0FHL0MsTUFBTSxlQUFlO0VBRXpCO0VBQ0EsUUFBUSxPQUFPO0dBQ2IsTUFBTSxlQUFlLGVBQWUsWUFBWTtHQUNoRCxNQUFNLG1CQUFtQixNQUFNLFlBQVk7R0FDM0MsTUFBTSxzQkFBc0IsZ0JBQWdCLGVBQWUsTUFBTSxXQUFXLE1BSTVFLHFCQUFxQixLQUFBLEtBQWE7R0FJbEMsTUFBTSxzQkFBc0IsZ0JBQWdCLENBQUMsdUJBQXVCLENBQUMsdUJBQXVCO0dBQzVGLHVCQUF1QixVQUFVO0dBQ2pDLElBQUksWUFBWSxxQkFDZDtHQUVGLGdCQUFnQixNQUFNLFdBQVc7RUFDbkM7RUFDQSxlQUFlLE9BQU87R0FDcEIsZUFBZSxVQUFVLE1BQU07RUFDakM7RUFDQSxjQUFjLE9BQU87R0FDbkIsSUFBSSxNQUFNLGdCQUFnQixXQUFXLE1BQU0sWUFBWSxHQUFHO0lBQ3hELE1BQU0sWUFBWSxNQUFNLFFBQVEsYUFBYTtJQUM3QyxVQUFVLFNBQVMsTUFBTTtJQUN6QixJQUFJLFVBQVUsU0FBUyxLQUFLLElBQzFCLFVBQVUseUJBQXlCO0dBRXZDO0VBQ0Y7RUFDQSxjQUFjLE9BQU87R0FDbkIsZUFBZSxVQUFVLE1BQU07R0FDL0IsdUJBQXVCLFVBQVU7R0FDakMsa0JBQWtCO0VBQ3BCO0VBQ0EsWUFBWTtHQUNWLGtCQUFrQjtHQUNsQixJQUFJLFlBQVksZUFBZSxZQUFZLFNBQ3pDO0dBSUYsSUFBSSx1QkFBdUIsU0FDekI7R0FFRixNQUFNLDBCQUEwQixDQUFDLE1BQU0sUUFBUSxhQUFhLFFBQVEsd0JBQXdCO0dBQzVGLE1BQU0sNEJBQTRCLENBQUMsTUFBTSxRQUFRLGFBQWEsUUFBUSwwQkFBMEIsQ0FBQztHQUNqRyxJQUFJLDJCQUEyQiwyQkFDN0I7R0FFRix1QkFBdUIsVUFBVTtHQUNqQyxRQUFRLFNBQVMsTUFBTTtHQUN2Qix1QkFBdUIsVUFBVTtFQUNuQztDQUNGO0NBQ0EsTUFBTSxVQUFVLGlCQUFpQixPQUFPLGdCQUFnQjtFQUN0RCxLQUFLO0dBQUM7R0FBVztHQUFjLFNBQVM7R0FBSztFQUFPO0VBQ3BEO0VBQ0EsT0FBTztHQUFDO0dBQVc7R0FBYztHQUFjO0VBQWM7Q0FDL0QsQ0FBQztDQUNELE1BQU0sZUFBQSxhQUFxQixlQUFlO0VBQ3hDO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsSUFBSTtFQUFDO0VBQVU7RUFBTztFQUFTO0NBQWUsQ0FBQztDQUMvQyxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGtCQUFrQixVQUFVO0VBQ25ELE9BQU87RUFDUCxVQUFVO0NBQ1osQ0FBQztBQUNILENBQUMsQ0FBQztBQUN5QyxXQUFXLGNBQWM7O0FDbE1wRSxJQUFhLGdCQUE2QiwyQkFBTSxLQUFrQiwyQkFBTSxXQUFXLFNBQVMsY0FBYyxnQkFBZ0IsY0FBYztDQUN0SSxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsYUFDQSxVQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLGVBQUEsYUFBcUIsT0FBTyxJQUFJO0NBQ3RDLE1BQU0sRUFDSixrQkFDQSxlQUNFLG9CQUFvQixRQUFRO0NBS2hDLE1BQU0sVUFBVSxpQkFBaUIsUUFBUSxnQkFBZ0I7RUFDdkQsS0FBSyxDQUFDLGNBQWMsWUFBWTtFQUNoQyxPQUFBO0dBTEE7R0FDQTtFQUlJO0VBQ0osT0FBTyxDQUFDO0dBQ04sZUFBZTtHQUNmLFVBQVU7RUFDWixHQUFHLFlBQVk7RUFDZix3QkFBd0I7Q0FDMUIsQ0FBQztDQUNELHNCQUFzQjtFQUNwQixPQUFPO0VBQ1AsU0FBUyxDQUFDO0VBQ1YsTUFBTTtFQUNOLEtBQUs7RUFDTCxhQUFhO0dBQ1gsSUFBSSxDQUFDLFVBQ0gsV0FBVyxLQUFLO0VBRXBCO0NBQ0YsQ0FBQztDQUNELE9BQU87QUFDVCxDQUFDLENBQUM7QUFDeUMsY0FBYyxjQUFjOzs7Ozs7OztBQ3JDdkUsSUFBYSxzQkFBbUMsMkJBQU0sV0FBVyxTQUFTLG9CQUFvQixnQkFBZ0IsY0FBYztDQUMxSCxNQUFNLEVBQ0osYUFDRSxxQkFBcUI7Q0FFekIsSUFBSSxFQURpQixlQUFlLGVBQWUsV0FFakQsT0FBTztDQUVULE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssZUFBZTtFQUN0QyxHQUFHO0VBQ087RUFDVixLQUFLO0NBQ1AsQ0FBQztBQUNILENBQUM7QUFDMEMsb0JBQW9CLGNBQWM7Ozs7Ozs7O0FDZDdFLElBQWEsaUJBQThCLDJCQUFNLEtBQWtCLDJCQUFNLFdBQVcsU0FBUyxlQUFlLGdCQUFnQixjQUFjO0NBQ3hJLE1BQU0sRUFDSixPQUNBLFNBQ0Esb0JBQ0UscUJBQXFCO0NBQ3pCLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLFdBQUEsYUFBaUIsYUFBWSxTQUFRO0VBQ3pDLElBQUksQ0FBQyxNQUNIO0VBRUYsSUFBSSxVQUFVLEdBQ1osTUFBTSxRQUFRLGlCQUFpQixVQUFVO0VBRTNDLElBQUksaUJBQ0YsTUFBTSxRQUFRLG9CQUFvQixVQUFVO0NBRWhELEdBQUc7RUFBQztFQUFPO0VBQU87Q0FBZSxDQUFDO0NBS2xDLE9BSmdCLGlCQUFpQixPQUFPLGdCQUFnQjtFQUN0RCxLQUFLO0dBQUM7R0FBVTtHQUFjO0VBQU87RUFDckMsT0FBTztDQUNULENBQ2E7QUFDZixDQUFDLENBQUM7QUFDeUMsZUFBZSxjQUFjOzs7Ozs7OztBQzdCeEUsSUFBYSxjQUEyQiwyQkFBTSxXQUFXLFNBQVMsWUFBWSxnQkFBZ0IsY0FBYztDQUMxRyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sUUFBUSxxQkFBcUI7Q0FDbkMsTUFBTSxFQUNKLE1BQ0EsT0FDQSxVQUNBLGFBQ0EsaUJBQ0EsK0JBQ0UsMkJBQTJCO0NBRS9CLE1BQU0sUUFBUTtFQUNaLE1BRlcsTUFBTSxTQUFTLE1BRXZCO0VBQ0g7RUFDQTtFQUNBLFlBQVk7Q0FDZDtDQUNBLE1BQU0sVUFBVSxpQkFBaUIsT0FBTyxnQkFBZ0I7RUFDdEQ7RUFDQSxLQUFLLENBQUMsVUFBVSxZQUFZO0VBQzVCLE9BQU8sQ0FBQztHQUNOLE9BQU87R0FDUCxlQUFlO0VBQ2pCLEdBQUcsWUFBWTtFQUNmLHdCQUF3QjtDQUMxQixDQUFDO0NBQ0QsSUFBSSw0QkFDRixPQUFPO0NBRVQsT0FBTztBQUNULENBQUM7QUFDMEMsWUFBWSxjQUFjOzs7OztBQ25DckUsSUFBYSxvQkFBaUMsMkJBQU0sV0FBVyxTQUFTLGtCQUFrQixnQkFBZ0IsY0FBYztDQUN0SCxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsV0FDQSxhQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLE9BQU8sY0FBYztDQUMzQixNQUFNLFFBQVEscUJBQXFCO0NBQ25DLE1BQU0sRUFDSixNQUNBLG9CQUNBLHFCQUNFLDJCQUEyQjtDQUMvQixNQUFNLGtCQUFrQixPQUFPLHlCQUF5QjtDQUN4RCxNQUFNLGVBQWUsTUFBTSxTQUFTLGVBQWU7Q0FDbkQsTUFBTSxhQUFhLE1BQU0sU0FBUyxZQUFZO0NBRzlDLE1BQU0sVUFBVSxnQkFBZ0IsZUFBZTtDQUMvQyxNQUFNLFVBQVUsV0FBVztDQUMzQixNQUFNLGlCQUFpQixPQUFPLG1CQUFtQjtDQUNqRCxNQUFNLEVBQ0osU0FDQSxrQkFDQSxlQUNFLG9CQUFvQixPQUFPO0NBQy9CLHlCQUF5QjtFQUN2QixNQUFNLFFBQVEsNEJBQTRCLFdBQVc7RUFDckQsTUFBTSxJQUFJLG1CQUFtQixJQUFJO0VBQ2pDLGFBQWE7R0FDWCxNQUFNLFFBQVEsNEJBQTRCLFVBQVUsS0FBSyxJQUFJLEdBQUcsTUFBTSxRQUFRLDRCQUE0QixVQUFVLENBQUM7R0FDckgsSUFBSSxNQUFNLFFBQVEsNEJBQTRCLFlBQVksR0FDeEQsTUFBTSxJQUFJLG1CQUFtQixLQUFLO0VBRXRDO0NBQ0YsR0FBRyxDQUFDLEtBQUssQ0FBQztDQUNWLHNCQUFzQjtFQUNwQixNQUFNO0VBQ04sS0FBSztFQUNMLGFBQWE7R0FDWCxJQUFJLENBQUMsU0FDSCxXQUFXLEtBQUs7RUFFcEI7Q0FDRixDQUFDO0NBZ0RELE1BQU0sVUFBVSxpQkFBaUIsT0FBTyxnQkFBZ0I7RUFDdEQsS0FBSyxDQUFDLGNBQWMsY0FBYztFQUNsQyxPQUFBO0dBaERBO0dBQ0E7R0FDQTtHQUNBO0VBNkNJO0VBQ0osT0FBTyxDQUFDO0dBM0NSLGVBQWU7R0FDZixVQUFVLE9BQU8sTUFBTTtHQUN2QixPQUFPLEVBQ0wsVUFBVSxXQUNaO0dBQ0EsWUFBWSxPQUFPO0lBQ2pCLElBQUksTUFBTSxjQUFjLEtBQUssTUFBTSxjQUFjLEtBQUssUUFBUSxVQUFVLEdBQ3RFO0lBRUYsTUFBTSxJQUFJLGVBQWUsSUFBSTtJQUM3QixTQUFTLGlCQUFpQjtLQUN4QixNQUFNLFdBQVcsTUFBTSxNQUFNLGVBQWUsTUFBTSxRQUFRLFNBQVM7S0FDbkUsSUFBSSxDQUFDLFVBQ0g7S0FFRixNQUFNLElBQUksZUFBZSxJQUFJO0tBQzdCLE1BQU0sUUFBUSw0QkFBNEIsUUFBUTtLQUNsRCxNQUFNLGVBQWUsbUJBQW1CLFNBQVMsY0FBYyxTQUFTLFlBQVk7S0FDcEYsTUFBTSxZQUFZLHNCQUFzQixTQUFTLFdBQVcsWUFBWTtLQUN4RSxNQUFNLG1CQUFtQixlQUFlLE9BQU8sSUFBSTtLQUNuRCxNQUFNLFFBQVEsTUFBTSxRQUFRLFFBQVE7S0FDcEMsSUFBSSxjQUFjLFNBQVMsV0FDekIsU0FBUyxZQUFZO0tBRXZCLElBQUksa0JBQWtCO01BQ3BCLFFBQVEsTUFBTTtNQUNkO0tBQ0Y7S0FDQSxJQUFJLE1BQU0sU0FBUyxHQUFHO01BQ3BCLE1BQU0sb0JBQW9CLGVBQWUsU0FBUyxnQkFBZ0I7TUFDbEUsU0FBUyxZQUFZLG1CQUFtQixPQUFPLE1BQU0sV0FBVyxTQUFTLGNBQWMsbUJBQW1CLFlBQVk7S0FDeEg7S0FDQSxRQUFRLE1BQU0sSUFBSSxjQUFjO0lBQ2xDO0lBQ0EsUUFBUSxNQUFNLElBQUksY0FBYztHQUNsQztHQUNBLGVBQWU7SUFDYixRQUFRLE1BQU07R0FDaEI7RUFLbUIsR0FBRyxZQUFZO0VBQ2xDLHdCQUF3QjtDQUMxQixDQUFDO0NBRUQsSUFBSSxFQURpQixXQUFXLGNBRTlCLE9BQU87Q0FFVCxPQUFPO0FBQ1QsQ0FBQztBQUMwQyxrQkFBa0IsY0FBYztBQUMzRSxTQUFTLG1CQUFtQixPQUFPLE1BQU0sV0FBVyxjQUFjLG1CQUFtQixjQUFjO0NBQ2pHLElBQUksTUFBTTtFQUNSLElBQUksb0JBQW9CO0VBQ3hCLE1BQU0sYUFBYSxZQUFZLG9CQUFBO0VBQy9CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFHO0dBQ3hDLE1BQU0sT0FBTyxNQUFNO0dBQ25CLElBQUksUUFBUSxLQUFLLGFBQWEsWUFBWTtJQUN4QyxvQkFBb0I7SUFDcEI7R0FDRjtFQUNGO0VBQ0EsTUFBTSxjQUFjLEtBQUssSUFBSSxHQUFHLG9CQUFvQixDQUFDO0VBQ3JELE1BQU0sYUFBYSxNQUFNO0VBQ3pCLE9BQU8sY0FBYyxxQkFBcUIsYUFBYSxzQkFBc0IsV0FBVyxZQUFZLG1CQUFtQixZQUFZLElBQUk7Q0FDekk7Q0FDQSxJQUFJLG1CQUFtQixNQUFNLFNBQVM7Q0FDdEMsTUFBTSxnQkFBZ0IsWUFBWSxlQUFlLG9CQUFBO0NBQ2pELEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFHO0VBQ3hDLE1BQU0sT0FBTyxNQUFNO0VBQ25CLElBQUksUUFBUSxLQUFLLFlBQVksS0FBSyxlQUFlLGVBQWU7R0FDOUQsbUJBQW1CLEtBQUssSUFBSSxHQUFHLElBQUksQ0FBQztHQUNwQztFQUNGO0NBQ0Y7Q0FDQSxNQUFNLGNBQWMsS0FBSyxJQUFJLE1BQU0sU0FBUyxHQUFHLG1CQUFtQixDQUFDO0NBQ25FLE1BQU0sYUFBYSxNQUFNO0NBQ3pCLE9BQU8sY0FBYyxvQkFBb0IsYUFBYSxzQkFBc0IsV0FBVyxZQUFZLFdBQVcsZUFBZSxlQUFlLG1CQUFtQixZQUFZLElBQUk7QUFDakw7Ozs7Ozs7O0FDNUlBLElBQWEsd0JBQXFDLDJCQUFNLFdBQVcsU0FBUyxzQkFBc0IsT0FBTyxjQUFjO0NBQ3JILE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssbUJBQW1CO0VBQzFDLEdBQUc7RUFDSCxLQUFLO0VBQ0wsV0FBVztDQUNiLENBQUM7QUFDSCxDQUFDO0FBQzBDLHNCQUFzQixjQUFjOzs7Ozs7OztBQ1AvRSxJQUFhLHNCQUFtQywyQkFBTSxXQUFXLFNBQVMsb0JBQW9CLE9BQU8sY0FBYztDQUNqSCxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLG1CQUFtQjtFQUMxQyxHQUFHO0VBQ0gsS0FBSztFQUNMLFdBQVc7Q0FDYixDQUFDO0FBQ0gsQ0FBQztBQUMwQyxvQkFBb0IsY0FBYzs7QUNkN0UsSUFBYSxxQkFBa0MsMkJBQU0sY0FBYyxLQUFBLENBQVM7QUFDakMsbUJBQW1CLGNBQWM7QUFDNUUsU0FBZ0Isd0JBQXdCO0NBQ3RDLE1BQU0sVUFBQSxhQUFnQixXQUFXLGtCQUFrQjtDQUNuRCxJQUFJLFlBQVksS0FBQSxHQUNkLE1BQU0sSUFBSSxNQUE4QyxpR0FBMkg7Q0FFckwsT0FBTztBQUNUOzs7Ozs7OztBQ0NBLElBQWEsY0FBMkIsMkJBQU0sV0FBVyxTQUFTLFlBQVksZ0JBQWdCLGNBQWM7Q0FDMUcsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLENBQUMsU0FBUyxjQUFBLGFBQW9CLFNBQVM7Q0FDN0MsTUFBTSxlQUFBLGFBQXFCLGVBQWU7RUFDeEM7RUFDQTtDQUNGLElBQUksQ0FBQyxTQUFTLFVBQVUsQ0FBQztDQUN6QixNQUFNLFVBQVUsaUJBQWlCLE9BQU8sZ0JBQWdCO0VBQ3RELEtBQUs7RUFDTCxPQUFPLENBQUM7R0FDTixNQUFNO0dBQ04sbUJBQW1CO0VBQ3JCLEdBQUcsWUFBWTtDQUNqQixDQUFDO0NBQ0QsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxtQkFBbUIsVUFBVTtFQUNwRCxPQUFPO0VBQ1AsVUFBVTtDQUNaLENBQUM7QUFDSCxDQUFDO0FBQzBDLFlBQVksY0FBYzs7Ozs7Ozs7QUN2QnJFLElBQWEsbUJBQWdDLDJCQUFNLFdBQVcsU0FBUyxpQkFBaUIsZ0JBQWdCLGNBQWM7Q0FDcEgsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLElBQUksUUFDSixHQUFHLGlCQUNEO0NBQ0osTUFBTSxFQUNKLGVBQ0Usc0JBQXNCO0NBQzFCLE1BQU0sS0FBSyxZQUFZLE1BQU07Q0FDN0IseUJBQXlCO0VBQ3ZCLFdBQVcsRUFBRTtFQUNiLGFBQWE7R0FDWCxZQUFXLGNBQWEsY0FBYyxLQUFLLEtBQUEsSUFBWSxTQUFTO0VBQ2xFO0NBQ0YsR0FBRyxDQUFDLElBQUksVUFBVSxDQUFDO0NBUW5CLE9BUGdCLGlCQUFpQixPQUFPLGdCQUFnQjtFQUN0RCxLQUFLO0VBQ0wsT0FBTyxDQUFDO0dBQ047R0FDQSxlQUFlO0VBQ2pCLEdBQUcsWUFBWTtDQUNqQixDQUNhO0FBQ2YsQ0FBQztBQUMwQyxpQkFBaUIsY0FBYzs7Ozs7Ozs7QUM5QjFFLElBQWEsbUJBQWdDLDJCQUFNLFdBQVcsU0FBUyxpQkFBaUIsZ0JBQWdCLGNBQWM7Q0FDcEgsTUFBTSxFQUNKLFdBQ0EsUUFDQSxjQUFjLGNBQ2QsT0FDQSxHQUFHLGlCQUNEO0NBSUosT0FBTyxpQkFBaUIsT0FBTyxnQkFBZ0I7RUFDN0MsT0FBQSxFQUhBLFlBR0k7RUFDSixLQUFLO0VBQ0wsT0FBTyxDQUFDLEVBQ04sTUFBTSxlQUNSLEdBQUcsWUFBWTtDQUNqQixDQUFDO0FBQ0gsQ0FBQztBQUMwQyxpQkFBaUIsY0FBYzs7Ozs7Ozs7QUNyQjFFLElBQWEsa0JBQWtCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FFTi9CLElBQWEsY0FBYzs7Ozs7O0FDRTNCLElBQWEsWUFBWUM7Ozs7Ozs7Ozs7O0FDQXpCLElBQWFDLFNBQU9DOzs7O0FBSXBCLElBQWFDLFdBQVNDOzs7O0FBSXRCLElBQWFDLGtCQUFnQkM7Ozs7QUFJN0IsSUFBYUMsZ0JBQWNDOzs7Ozs7Ozs7Ozs7QUNaM0IsSUFBYUMsU0FBT0M7Ozs7QUFJcEIsSUFBYUMsV0FBU0M7Ozs7QUFJdEIsSUFBYSxlQUFlQzs7Ozs7QUFLNUIsSUFBYUMsU0FBT0M7Ozs7O0FBS3BCLElBQWFDLFVBQVFDOzs7Ozs7Ozs7Ozs7O0FDbEJyQixJQUFhQyxTQUFPQzs7OztBQUlwQixJQUFhQyxXQUFTQzs7OztBQUl0QixJQUFhQyxrQkFBZ0JDOzs7O0FBSTdCLElBQWFDLGdCQUFjQzs7Ozs7QUFLM0IsSUFBYUMsU0FBT0M7Ozs7O0FBS3BCLElBQWFDLFVBQVFDOzs7Ozs7Ozs7O0FDeEJyQixJQUFhLFdBQVc7Ozs7QUFJeEIsSUFBYSxjQUFjOzs7O0FBSTNCLElBQWEsV0FBVzs7Ozs7Ozs7O0FDTnhCLElBQWFDLGtCQUFnQkM7Ozs7QUFJN0IsSUFBYUMsZ0JBQWNDOzs7Ozs7Ozs7Ozs7QUNKM0IsSUFBYSxPQUFPQzs7OztBQUlwQixJQUFhLFNBQVNDOzs7OztBQUt0QixJQUFhQyxTQUFPQzs7Ozs7QUFLcEIsSUFBYSxRQUFRQzs7OztBQUlyQixJQUFhLGFBQWE7Ozs7Ozs7Ozs7OztBQ2xCMUIsSUFBYUMsa0JBQWdCQzs7OztBQUk3QixJQUFhQyxnQkFBY0M7Ozs7O0FBSzNCLElBQWFDLGNBQVk7Ozs7QUFJekIsSUFBYUMsWUFBVTs7Ozs7QUFLdkIsSUFBYUMsU0FBT0M7Ozs7Ozs7Ozs7OztBQ2xCcEIsSUFBYSxnQkFBZ0JDOzs7O0FBSTdCLElBQWEsY0FBY0M7Ozs7O0FBSzNCLElBQWEsWUFBWTs7OztBQUl6QixJQUFhLFVBQVU7Ozs7O0FBS3ZCLElBQWEsT0FBT0MiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyMywyNCwyNSwyNiwyNywyOCwyOSwzMCwzMSwzMiwzMywzNCwzNSwzNiwzNywzOCwzOSw0MCw0MSw0Miw0Myw0NCw0NSw0Niw0Nyw0OCw0OSw1MF19