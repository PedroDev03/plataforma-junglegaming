import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/footer.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { Separator } from "/src/components/ui/separator.tsx";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/layout/footer.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
export function Footer() {
	const $ = _c(3);
	if ($[0] !== "9972fb037fc849eaedb9f84ec79645a67921dce4c66a5f4e279f438c7a39c4db") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "9972fb037fc849eaedb9f84ec79645a67921dce4c66a5f4e279f438c7a39c4db";
	}
	let t0;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "flex size-7 items-center justify-center rounded-lg bg-primary text-primary-foreground",
				children: /* @__PURE__ */ _jsxDEV(Sparkles, {
					className: "size-3.5",
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 15,
					columnNumber: 155
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 51
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "text-sm font-semibold tracking-tight",
				children: "JungleNFT Marketplace"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 214
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 10
		}, this);
		$[1] = t0;
	} else {
		t0 = $[1];
	}
	let t1;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ _jsxDEV("footer", {
			className: "mt-auto border-t bg-muted/30",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center",
						children: [t0, /* @__PURE__ */ _jsxDEV("nav", {
							"aria-label": "Links institucionais",
							className: "flex flex-wrap items-center gap-4 text-xs text-muted-foreground",
							children: [
								/* @__PURE__ */ _jsxDEV(Link, {
									to: "/",
									className: "rounded-sm hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
									children: "Catálogo"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 22,
									columnNumber: 332
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									to: "/cart",
									className: "rounded-sm hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
									children: "Carrinho"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 22,
									columnNumber: 477
								}, this),
								/* @__PURE__ */ _jsxDEV(Link, {
									to: "/profile",
									className: "rounded-sm hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
									children: "Perfil do Colecionador"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 22,
									columnNumber: 626
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 22,
							columnNumber: 217
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 22,
						columnNumber: 120
					}, this),
					/* @__PURE__ */ _jsxDEV(Separator, { className: "my-4" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 22,
						columnNumber: 804
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-xs text-muted-foreground",
						children: "Valores calculados com precisão decimal em ETH. Ambiente simulado via Mock Service Worker (MSW)."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 22,
						columnNumber: 834
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 22,
				columnNumber: 59
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 10
		}, this);
		$[2] = t1;
	} else {
		t1 = $[2];
	}
	return t1;
}
_c2 = Footer;
var _c2;
$RefreshReg$(_c2, "Footer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/footer.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/layout/footer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/layout/footer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/layout/footer.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLFlBQVk7QUFDckIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGlCQUFpQjs7O0FBRTFCLE9BQU8sU0FBQUMsU0FBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUwsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBS0dDLEtBQUE7R0FBZTthQUFmLENBQ0U7SUFBZ0I7Y0FDZCx3QkFBQyxVQUFEO0tBQW9CO0tBQXVCO0lBQU07Ozs7O0dBQzVDOzs7O2FBQ1A7SUFBZ0I7Y0FBdUM7R0FBNEI7Ozs7V0FDL0U7Ozs7OztFQUFBTCxFQUFBLEtBQUFLO0NBQUE7RUFBQUEsS0FBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFSWkUsS0FBQTtHQUFrQjthQUNoQjtJQUFlO2NBQWY7S0FDRTtNQUFlO2dCQUFmLENBQ0VELElBT0E7T0FBZ0I7T0FBaUM7aUJBQWpEO1FBQ0Usd0JBQUMsTUFBRDtTQUNLO1NBQ087bUJBQ1g7UUFISTs7Ozs7UUFNTCx3QkFBQyxNQUFEO1NBQ0s7U0FDTzttQkFDWDtRQUhJOzs7OztRQU1MLHdCQUFDLE1BQUQ7U0FDSztTQUNPO21CQUNYO1FBSEk7Ozs7O09BTUQ7Ozs7O2NBQ0Y7Ozs7OztLQUVOLHdCQUFDLFdBQUQsRUFBcUIsa0JBQU07Ozs7O0tBRTNCO01BQWE7Z0JBQWdDO0tBRXpDOzs7OztJQUNBOzs7Ozs7RUFDQzs7Ozs7RUFBQUwsRUFBQSxLQUFBTTtDQUFBO0VBQUFBLEtBQUFOLEVBQUE7Q0FBQTtDQUFBLE9BdENUTTtBQXNDUyIsIm5hbWVzIjpbIkxpbmsiLCJTcGFya2xlcyIsIlNlcGFyYXRvciIsIkZvb3RlciIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwidDAiLCJ0MSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJmb290ZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmsgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgU3BhcmtsZXMgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBTZXBhcmF0b3IgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc2VwYXJhdG9yJ1xuXG5leHBvcnQgZnVuY3Rpb24gRm9vdGVyKCkge1xuICByZXR1cm4gKFxuICAgIDxmb290ZXIgY2xhc3NOYW1lPVwibXQtYXV0byBib3JkZXItdCBiZy1tdXRlZC8zMFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTd4bCBweC00IHB5LTggc206cHgtNiBsZzpweC04XCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LWNvbCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBzaXplLTcgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtbGcgYmctcHJpbWFyeSB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwic2l6ZS0zLjVcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LXNlbWlib2xkIHRyYWNraW5nLXRpZ2h0XCI+SnVuZ2xlTkZUIE1hcmtldHBsYWNlPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPG5hdiBhcmlhLWxhYmVsPVwiTGlua3MgaW5zdGl0dWNpb25haXNcIiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTQgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgIHRvPVwiL1wiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtc20gaG92ZXI6dGV4dC1mb3JlZ3JvdW5kIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1yaW5nXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgQ2F0w6Fsb2dvXG4gICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICB0bz1cIi9jYXJ0XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1zbSBob3Zlcjp0ZXh0LWZvcmVncm91bmQgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLXJpbmdcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBDYXJyaW5ob1xuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgdG89XCIvcHJvZmlsZVwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtc20gaG92ZXI6dGV4dC1mb3JlZ3JvdW5kIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1yaW5nXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgUGVyZmlsIGRvIENvbGVjaW9uYWRvclxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDwvbmF2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8U2VwYXJhdG9yIGNsYXNzTmFtZT1cIm15LTRcIiAvPlxuXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgVmFsb3JlcyBjYWxjdWxhZG9zIGNvbSBwcmVjaXPDo28gZGVjaW1hbCBlbSBFVEguIEFtYmllbnRlIHNpbXVsYWRvIHZpYSBNb2NrIFNlcnZpY2UgV29ya2VyIChNU1cpLlxuICAgICAgICA8L3A+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Zvb3Rlcj5cbiAgKVxufVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvY29tcG9uZW50cy9sYXlvdXQvZm9vdGVyLnRzeCJ9