import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/avatar.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport1_react, 1);const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];"use client";
import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=e9f94b2e";
import { Avatar as AvatarPrimitive } from "/node_modules/.vite/deps/@base-ui_react_avatar.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/avatar.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
function Avatar(t0) {
	const $ = _c(11);
	if ($[0] !== "c8559a02f22928247c1f3c75fd3649d74aee896499784df89ea8264aed9f7568") {
		for (let $i = 0; $i < 11; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "c8559a02f22928247c1f3c75fd3649d74aee896499784df89ea8264aed9f7568";
	}
	let className;
	let props;
	let t1;
	if ($[1] !== t0) {
		({className, size: t1, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
		$[4] = t1;
	} else {
		className = $[2];
		props = $[3];
		t1 = $[4];
	}
	const size = t1 === undefined ? "default" : t1;
	let t2;
	if ($[5] !== className) {
		t2 = cn("group/avatar relative flex size-8 shrink-0 rounded-full select-none after:absolute after:inset-0 after:rounded-full after:border after:border-border after:mix-blend-darken data-[size=lg]:size-10 data-[size=sm]:size-6 dark:after:mix-blend-lighten", className);
		$[5] = className;
		$[6] = t2;
	} else {
		t2 = $[6];
	}
	let t3;
	if ($[7] !== props || $[8] !== size || $[9] !== t2) {
		t3 = /* @__PURE__ */ _jsxDEV(AvatarPrimitive.Root, {
			"data-slot": "avatar",
			"data-size": size,
			className: t2,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 10
		}, this);
		$[7] = props;
		$[8] = size;
		$[9] = t2;
		$[10] = t3;
	} else {
		t3 = $[10];
	}
	return t3;
}
_c2 = Avatar;
function AvatarImage(t0) {
	const $ = _c(9);
	if ($[0] !== "c8559a02f22928247c1f3c75fd3649d74aee896499784df89ea8264aed9f7568") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "c8559a02f22928247c1f3c75fd3649d74aee896499784df89ea8264aed9f7568";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("aspect-square size-full rounded-full object-cover", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(AvatarPrimitive.Image, {
			"data-slot": "avatar-image",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c3 = AvatarImage;
function AvatarFallback(t0) {
	const $ = _c(9);
	if ($[0] !== "c8559a02f22928247c1f3c75fd3649d74aee896499784df89ea8264aed9f7568") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "c8559a02f22928247c1f3c75fd3649d74aee896499784df89ea8264aed9f7568";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("flex size-full items-center justify-center rounded-full bg-muted text-sm text-muted-foreground group-data-[size=sm]/avatar:text-xs", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(AvatarPrimitive.Fallback, {
			"data-slot": "avatar-fallback",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 127,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c4 = AvatarFallback;
function AvatarBadge(t0) {
	const $ = _c(9);
	if ($[0] !== "c8559a02f22928247c1f3c75fd3649d74aee896499784df89ea8264aed9f7568") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "c8559a02f22928247c1f3c75fd3649d74aee896499784df89ea8264aed9f7568";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("absolute right-0 bottom-0 z-10 inline-flex items-center justify-center rounded-full bg-primary text-primary-foreground bg-blend-color ring-2 ring-background select-none", "group-data-[size=sm]/avatar:size-2 group-data-[size=sm]/avatar:[&>svg]:hidden", "group-data-[size=default]/avatar:size-2.5 group-data-[size=default]/avatar:[&>svg]:size-2", "group-data-[size=lg]/avatar:size-3 group-data-[size=lg]/avatar:[&>svg]:size-2", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("span", {
			"data-slot": "avatar-badge",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 168,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c5 = AvatarBadge;
function AvatarGroup(t0) {
	const $ = _c(9);
	if ($[0] !== "c8559a02f22928247c1f3c75fd3649d74aee896499784df89ea8264aed9f7568") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "c8559a02f22928247c1f3c75fd3649d74aee896499784df89ea8264aed9f7568";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("group/avatar-group flex -space-x-2 *:data-[slot=avatar]:ring-2 *:data-[slot=avatar]:ring-background", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "avatar-group",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 209,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c6 = AvatarGroup;
function AvatarGroupCount(t0) {
	const $ = _c(9);
	if ($[0] !== "c8559a02f22928247c1f3c75fd3649d74aee896499784df89ea8264aed9f7568") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "c8559a02f22928247c1f3c75fd3649d74aee896499784df89ea8264aed9f7568";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("relative flex size-8 shrink-0 items-center justify-center rounded-full bg-muted text-sm text-muted-foreground ring-2 ring-background group-has-data-[size=lg]/avatar-group:size-10 group-has-data-[size=sm]/avatar-group:size-6 [&>svg]:size-4 group-has-data-[size=lg]/avatar-group:[&>svg]:size-5 group-has-data-[size=sm]/avatar-group:[&>svg]:size-3", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "avatar-group-count",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 250,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c7 = AvatarGroupCount;
export { Avatar, AvatarImage, AvatarFallback, AvatarGroup, AvatarGroupCount, AvatarBadge };
var _c2, _c3, _c4, _c5, _c6, _c7;
$RefreshReg$(_c2, "Avatar");
$RefreshReg$(_c3, "AvatarImage");
$RefreshReg$(_c4, "AvatarFallback");
$RefreshReg$(_c5, "AvatarBadge");
$RefreshReg$(_c6, "AvatarGroup");
$RefreshReg$(_c7, "AvatarGroupCount");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/avatar.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/avatar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/avatar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/avatar.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFBWSxTQUFBQSxLQUFBQyxVQUFBO0FBRVosWUFBWUMsV0FBVztBQUN2QixTQUFTQyxVQUFVQyx1QkFBdUI7QUFDMUMsU0FBU0MsVUFBVTs7O0FBRW5CLFNBQUFGLE9BQUFHLElBQUE7Q0FBQSxNQUFBQyxJQUFBTixHQUFBO0NBQUEsSUFBQU0sRUFBQTtFQUFBLFNBQUFDLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFELEVBQUFDLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSCxFQUFBO0NBQUE7Q0FBQSxJQUFBSTtDQUFBLElBQUFDO0NBQUEsSUFBQUM7Q0FBQSxJQUFBTixFQUFBLE9BQUFELElBQUE7RUFBZ0IsRUFBQUssV0FBQUcsTUFBQUQsSUFBQSxHQUFBRCxTQUFBTjtFQU1mQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQUk7RUFBQUosRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0NBQUE7RUFBQUYsWUFBQUosRUFBQTtFQUFBSyxRQUFBTCxFQUFBO0VBQUFNLEtBQUFOLEVBQUE7Q0FBQTtDQUpDLE1BQUFPLE9BQUFELE9BQUFFLFlBQUEsWUFBQUY7Q0FBZ0IsSUFBQUc7Q0FBQSxJQUFBVCxFQUFBLE9BQUFJLFdBQUE7RUFTREssS0FBQVgsR0FDVCx5UEFDQU0sU0FDRjtFQUFDSixFQUFBLEtBQUFJO0VBQUFKLEVBQUEsS0FBQVM7Q0FBQTtFQUFBQSxLQUFBVCxFQUFBO0NBQUE7Q0FBQSxJQUFBVTtDQUFBLElBQUFWLEVBQUEsT0FBQUssU0FBQUwsRUFBQSxPQUFBTyxRQUFBUCxFQUFBLE9BQUFTLElBQUE7RUFOSEMsS0FBQTtHQUNZO0dBQ0NIO0dBQ0EsV0FBQUU7R0FHVixHQUNHSjtFQUFLOzs7OztFQUNUTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBUztFQUFBVCxFQUFBLE1BQUFVO0NBQUE7RUFBQUEsS0FBQVYsRUFBQTtDQUFBO0NBQUEsT0FSRlU7QUFRRTs7QUFJTixTQUFBQyxZQUFBWixJQUFBO0NBQUEsTUFBQUMsSUFBQU4sR0FBQTtDQUFBLElBQUFNLEVBQUE7RUFBQSxTQUFBQyxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRCxFQUFBQyxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUgsRUFBQTtDQUFBO0NBQUEsSUFBQUk7Q0FBQSxJQUFBQztDQUFBLElBQUFMLEVBQUEsT0FBQUQsSUFBQTtFQUFxQixFQUFBSyxXQUFBLEdBQUFDLFNBQUFOO0VBQW9EQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQUk7RUFBQUosRUFBQSxLQUFBSztDQUFBO0VBQUFELFlBQUFKLEVBQUE7RUFBQUssUUFBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFJLFdBQUE7RUFJeERFLEtBQUFSLEdBQ1QscURBQ0FNLFNBQ0Y7RUFBQ0osRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFNO0NBQUE7RUFBQUEsS0FBQU4sRUFBQTtDQUFBO0NBQUEsSUFBQVM7Q0FBQSxJQUFBVCxFQUFBLE9BQUFLLFNBQUFMLEVBQUEsT0FBQU0sSUFBQTtFQUxIRyxLQUFBO0dBQ1k7R0FDQyxXQUFBSDtHQUdWLEdBQ0dEO0VBQUs7Ozs7O0VBQ1RMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFTO0NBQUE7RUFBQUEsS0FBQVQsRUFBQTtDQUFBO0NBQUEsT0FQRlM7QUFPRTs7QUFJTixTQUFBRyxlQUFBYixJQUFBO0NBQUEsTUFBQUMsSUFBQU4sR0FBQTtDQUFBLElBQUFNLEVBQUE7RUFBQSxTQUFBQyxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRCxFQUFBQyxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUgsRUFBQTtDQUFBO0NBQUEsSUFBQUk7Q0FBQSxJQUFBQztDQUFBLElBQUFMLEVBQUEsT0FBQUQsSUFBQTtFQUF3QixFQUFBSyxXQUFBLEdBQUFDLFNBQUFOO0VBR1NDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFLO0NBQUE7RUFBQUQsWUFBQUosRUFBQTtFQUFBSyxRQUFBTCxFQUFBO0NBQUE7Q0FBQSxJQUFBTTtDQUFBLElBQUFOLEVBQUEsT0FBQUksV0FBQTtFQUloQkUsS0FBQVIsR0FDVCxzSUFDQU0sU0FDRjtFQUFDSixFQUFBLEtBQUFJO0VBQUFKLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxJQUFBUztDQUFBLElBQUFULEVBQUEsT0FBQUssU0FBQUwsRUFBQSxPQUFBTSxJQUFBO0VBTEhHLEtBQUE7R0FDWTtHQUNDLFdBQUFIO0dBR1YsR0FDR0Q7RUFBSzs7Ozs7RUFDVEwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQVM7Q0FBQTtFQUFBQSxLQUFBVCxFQUFBO0NBQUE7Q0FBQSxPQVBGUztBQU9FOztBQUlOLFNBQUFJLFlBQUFkLElBQUE7Q0FBQSxNQUFBQyxJQUFBTixHQUFBO0NBQUEsSUFBQU0sRUFBQTtFQUFBLFNBQUFDLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFELEVBQUFDLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSCxFQUFBO0NBQUE7Q0FBQSxJQUFBSTtDQUFBLElBQUFDO0NBQUEsSUFBQUwsRUFBQSxPQUFBRCxJQUFBO0VBQXFCLEVBQUFLLFdBQUEsR0FBQUMsU0FBQU47RUFBcURDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFLO0NBQUE7RUFBQUQsWUFBQUosRUFBQTtFQUFBSyxRQUFBTCxFQUFBO0NBQUE7Q0FBQSxJQUFBTTtDQUFBLElBQUFOLEVBQUEsT0FBQUksV0FBQTtFQUl6REUsS0FBQVIsR0FDVCw0S0FDQSxpRkFDQSw2RkFDQSxpRkFDQU0sU0FDRjtFQUFDSixFQUFBLEtBQUFJO0VBQUFKLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxJQUFBUztDQUFBLElBQUFULEVBQUEsT0FBQUssU0FBQUwsRUFBQSxPQUFBTSxJQUFBO0VBUkhHLEtBQUE7R0FDWTtHQUNDLFdBQUFIO0dBTVYsR0FDR0Q7RUFBSzs7Ozs7RUFDVEwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQVM7Q0FBQTtFQUFBQSxLQUFBVCxFQUFBO0NBQUE7Q0FBQSxPQVZGUztBQVVFOztBQUlOLFNBQUFLLFlBQUFmLElBQUE7Q0FBQSxNQUFBQyxJQUFBTixHQUFBO0NBQUEsSUFBQU0sRUFBQTtFQUFBLFNBQUFDLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFELEVBQUFDLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSCxFQUFBO0NBQUE7Q0FBQSxJQUFBSTtDQUFBLElBQUFDO0NBQUEsSUFBQUwsRUFBQSxPQUFBRCxJQUFBO0VBQXFCLEVBQUFLLFdBQUEsR0FBQUMsU0FBQU47RUFBb0RDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFLO0NBQUE7RUFBQUQsWUFBQUosRUFBQTtFQUFBSyxRQUFBTCxFQUFBO0NBQUE7Q0FBQSxJQUFBTTtDQUFBLElBQUFOLEVBQUEsT0FBQUksV0FBQTtFQUl4REUsS0FBQVIsR0FDVCx1R0FDQU0sU0FDRjtFQUFDSixFQUFBLEtBQUFJO0VBQUFKLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxJQUFBUztDQUFBLElBQUFULEVBQUEsT0FBQUssU0FBQUwsRUFBQSxPQUFBTSxJQUFBO0VBTEhHLEtBQUE7R0FDWTtHQUNDLFdBQUFIO0dBR1YsR0FDR0Q7RUFBSzs7Ozs7RUFDVEwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQVM7Q0FBQTtFQUFBQSxLQUFBVCxFQUFBO0NBQUE7Q0FBQSxPQVBGUztBQU9FOztBQUlOLFNBQUFNLGlCQUFBaEIsSUFBQTtDQUFBLE1BQUFDLElBQUFOLEdBQUE7Q0FBQSxJQUFBTSxFQUFBO0VBQUEsU0FBQUMsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUQsRUFBQUMsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFILEVBQUE7Q0FBQTtDQUFBLElBQUFJO0NBQUEsSUFBQUM7Q0FBQSxJQUFBTCxFQUFBLE9BQUFELElBQUE7RUFBMEIsRUFBQUssV0FBQSxHQUFBQyxTQUFBTjtFQUdJQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQUk7RUFBQUosRUFBQSxLQUFBSztDQUFBO0VBQUFELFlBQUFKLEVBQUE7RUFBQUssUUFBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFJLFdBQUE7RUFJYkUsS0FBQVIsR0FDVCw0VkFDQU0sU0FDRjtFQUFDSixFQUFBLEtBQUFJO0VBQUFKLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxJQUFBUztDQUFBLElBQUFULEVBQUEsT0FBQUssU0FBQUwsRUFBQSxPQUFBTSxJQUFBO0VBTEhHLEtBQUE7R0FDWTtHQUNDLFdBQUFIO0dBR1YsR0FDR0Q7RUFBSzs7Ozs7RUFDVEwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQVM7Q0FBQTtFQUFBQSxLQUFBVCxFQUFBO0NBQUE7Q0FBQSxPQVBGUztBQU9FOztBQUlOLFNBQ0ViLFFBQ0FlLGFBQ0FDLGdCQUNBRSxhQUNBQyxrQkFDQUYiLCJuYW1lcyI6WyJjIiwiX2MiLCJSZWFjdCIsIkF2YXRhciIsIkF2YXRhclByaW1pdGl2ZSIsImNuIiwidDAiLCIkIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJjbGFzc05hbWUiLCJwcm9wcyIsInQxIiwic2l6ZSIsInVuZGVmaW5lZCIsInQyIiwidDMiLCJBdmF0YXJJbWFnZSIsIkF2YXRhckZhbGxiYWNrIiwiQXZhdGFyQmFkZ2UiLCJBdmF0YXJHcm91cCIsIkF2YXRhckdyb3VwQ291bnQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiYXZhdGFyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBjbGllbnRcIlxuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIlxuaW1wb3J0IHsgQXZhdGFyIGFzIEF2YXRhclByaW1pdGl2ZSB9IGZyb20gXCJAYmFzZS11aS9yZWFjdC9hdmF0YXJcIlxuaW1wb3J0IHsgY24gfSBmcm9tIFwiY25cIlxuXG5mdW5jdGlvbiBBdmF0YXIoe1xuICBjbGFzc05hbWUsXG4gIHNpemUgPSBcImRlZmF1bHRcIixcbiAgLi4ucHJvcHNcbn06IEF2YXRhclByaW1pdGl2ZS5Sb290LlByb3BzICYge1xuICBzaXplPzogXCJkZWZhdWx0XCIgfCBcInNtXCIgfCBcImxnXCJcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8QXZhdGFyUHJpbWl0aXZlLlJvb3RcbiAgICAgIGRhdGEtc2xvdD1cImF2YXRhclwiXG4gICAgICBkYXRhLXNpemU9e3NpemV9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImdyb3VwL2F2YXRhciByZWxhdGl2ZSBmbGV4IHNpemUtOCBzaHJpbmstMCByb3VuZGVkLWZ1bGwgc2VsZWN0LW5vbmUgYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6aW5zZXQtMCBhZnRlcjpyb3VuZGVkLWZ1bGwgYWZ0ZXI6Ym9yZGVyIGFmdGVyOmJvcmRlci1ib3JkZXIgYWZ0ZXI6bWl4LWJsZW5kLWRhcmtlbiBkYXRhLVtzaXplPWxnXTpzaXplLTEwIGRhdGEtW3NpemU9c21dOnNpemUtNiBkYXJrOmFmdGVyOm1peC1ibGVuZC1saWdodGVuXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIEF2YXRhckltYWdlKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9OiBBdmF0YXJQcmltaXRpdmUuSW1hZ2UuUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8QXZhdGFyUHJpbWl0aXZlLkltYWdlXG4gICAgICBkYXRhLXNsb3Q9XCJhdmF0YXItaW1hZ2VcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJhc3BlY3Qtc3F1YXJlIHNpemUtZnVsbCByb3VuZGVkLWZ1bGwgb2JqZWN0LWNvdmVyXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIEF2YXRhckZhbGxiYWNrKHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogQXZhdGFyUHJpbWl0aXZlLkZhbGxiYWNrLlByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPEF2YXRhclByaW1pdGl2ZS5GYWxsYmFja1xuICAgICAgZGF0YS1zbG90PVwiYXZhdGFyLWZhbGxiYWNrXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiZmxleCBzaXplLWZ1bGwgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1tdXRlZCB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBncm91cC1kYXRhLVtzaXplPXNtXS9hdmF0YXI6dGV4dC14c1wiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBBdmF0YXJCYWRnZSh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfTogUmVhY3QuQ29tcG9uZW50UHJvcHM8XCJzcGFuXCI+KSB7XG4gIHJldHVybiAoXG4gICAgPHNwYW5cbiAgICAgIGRhdGEtc2xvdD1cImF2YXRhci1iYWRnZVwiXG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImFic29sdXRlIHJpZ2h0LTAgYm90dG9tLTAgei0xMCBpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgcm91bmRlZC1mdWxsIGJnLXByaW1hcnkgdGV4dC1wcmltYXJ5LWZvcmVncm91bmQgYmctYmxlbmQtY29sb3IgcmluZy0yIHJpbmctYmFja2dyb3VuZCBzZWxlY3Qtbm9uZVwiLFxuICAgICAgICBcImdyb3VwLWRhdGEtW3NpemU9c21dL2F2YXRhcjpzaXplLTIgZ3JvdXAtZGF0YS1bc2l6ZT1zbV0vYXZhdGFyOlsmPnN2Z106aGlkZGVuXCIsXG4gICAgICAgIFwiZ3JvdXAtZGF0YS1bc2l6ZT1kZWZhdWx0XS9hdmF0YXI6c2l6ZS0yLjUgZ3JvdXAtZGF0YS1bc2l6ZT1kZWZhdWx0XS9hdmF0YXI6WyY+c3ZnXTpzaXplLTJcIixcbiAgICAgICAgXCJncm91cC1kYXRhLVtzaXplPWxnXS9hdmF0YXI6c2l6ZS0zIGdyb3VwLWRhdGEtW3NpemU9bGddL2F2YXRhcjpbJj5zdmddOnNpemUtMlwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBBdmF0YXJHcm91cCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfTogUmVhY3QuQ29tcG9uZW50UHJvcHM8XCJkaXZcIj4pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBkYXRhLXNsb3Q9XCJhdmF0YXItZ3JvdXBcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJncm91cC9hdmF0YXItZ3JvdXAgZmxleCAtc3BhY2UteC0yICo6ZGF0YS1bc2xvdD1hdmF0YXJdOnJpbmctMiAqOmRhdGEtW3Nsb3Q9YXZhdGFyXTpyaW5nLWJhY2tncm91bmRcIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZnVuY3Rpb24gQXZhdGFyR3JvdXBDb3VudCh7XG4gIGNsYXNzTmFtZSxcbiAgLi4ucHJvcHNcbn06IFJlYWN0LkNvbXBvbmVudFByb3BzPFwiZGl2XCI+KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgZGF0YS1zbG90PVwiYXZhdGFyLWdyb3VwLWNvdW50XCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwicmVsYXRpdmUgZmxleCBzaXplLTggc2hyaW5rLTAgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIHJvdW5kZWQtZnVsbCBiZy1tdXRlZCB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCByaW5nLTIgcmluZy1iYWNrZ3JvdW5kIGdyb3VwLWhhcy1kYXRhLVtzaXplPWxnXS9hdmF0YXItZ3JvdXA6c2l6ZS0xMCBncm91cC1oYXMtZGF0YS1bc2l6ZT1zbV0vYXZhdGFyLWdyb3VwOnNpemUtNiBbJj5zdmddOnNpemUtNCBncm91cC1oYXMtZGF0YS1bc2l6ZT1sZ10vYXZhdGFyLWdyb3VwOlsmPnN2Z106c2l6ZS01IGdyb3VwLWhhcy1kYXRhLVtzaXplPXNtXS9hdmF0YXItZ3JvdXA6WyY+c3ZnXTpzaXplLTNcIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZXhwb3J0IHtcbiAgQXZhdGFyLFxuICBBdmF0YXJJbWFnZSxcbiAgQXZhdGFyRmFsbGJhY2ssXG4gIEF2YXRhckdyb3VwLFxuICBBdmF0YXJHcm91cENvdW50LFxuICBBdmF0YXJCYWRnZSxcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL2NvbXBvbmVudHMvdWkvYXZhdGFyLnRzeCJ9