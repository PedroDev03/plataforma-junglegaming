import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/checkbox.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Checkbox as CheckboxPrimitive } from "/node_modules/.vite/deps/@base-ui_react_checkbox.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
import { CheckIcon } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/checkbox.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
function Checkbox(t0) {
	const $ = _c(10);
	if ($[0] !== "2b1917ec3e313c1c942065003243f661c269b5390a747ea7afdd749d7f777013") {
		for (let $i = 0; $i < 10; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "2b1917ec3e313c1c942065003243f661c269b5390a747ea7afdd749d7f777013";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("peer relative flex size-4 shrink-0 items-center justify-center rounded-[4px] border border-input transition-colors outline-none group-has-disabled/field:opacity-50 group-has-[:focus-visible]/field-label:ring-0 group-has-[:focus-visible]/field-label:not-data-checked:border-input after:absolute after:-inset-x-3 after:-inset-y-2 focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 aria-invalid:aria-checked:border-primary dark:bg-input/30 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 data-checked:border-primary data-checked:bg-primary data-checked:text-primary-foreground group-has-[:focus-visible]/field-label:data-checked:border-primary dark:data-checked:bg-primary", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV(CheckboxPrimitive.Indicator, {
			"data-slot": "checkbox-indicator",
			className: "grid place-content-center text-current transition-none [&>svg]:size-3.5",
			children: /* @__PURE__ */ _jsxDEV(CheckIcon, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 37,
				columnNumber: 154
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 10
		}, this);
		$[6] = t2;
	} else {
		t2 = $[6];
	}
	let t3;
	if ($[7] !== props || $[8] !== t1) {
		t3 = /* @__PURE__ */ _jsxDEV(CheckboxPrimitive.Root, {
			"data-slot": "checkbox",
			className: t1,
			...props,
			children: t2
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 10
		}, this);
		$[7] = props;
		$[8] = t1;
		$[9] = t3;
	} else {
		t3 = $[9];
	}
	return t3;
}
_c2 = Checkbox;
export { Checkbox };
var _c2;
$RefreshReg$(_c2, "Checkbox");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/checkbox.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/checkbox.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/checkbox.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/checkbox.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLFlBQVlDLHlCQUF5QjtBQUM5QyxTQUFTQyxVQUFVO0FBQ25CLFNBQVNDLGlCQUFpQjs7O0FBRTFCLFNBQUFILFNBQUFJLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBSztDQUFBLElBQUFDO0NBQUEsSUFBQU4sRUFBQSxPQUFBRCxJQUFBO0VBQWtCLEVBQUFNLFdBQUEsR0FBQUMsU0FBQVA7RUFBcURDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0NBQUE7RUFBQUQsWUFBQUwsRUFBQTtFQUFBTSxRQUFBTixFQUFBO0NBQUE7Q0FBQSxJQUFBTztDQUFBLElBQUFQLEVBQUEsT0FBQUssV0FBQTtFQUl0REUsS0FBQVYsR0FDVCwyMUJBQ0FRLFNBQ0Y7RUFBQ0wsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFPO0NBQUE7RUFBQUEsS0FBQVAsRUFBQTtDQUFBO0NBQUEsSUFBQVE7Q0FBQSxJQUFBUixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFHREksS0FBQTtHQUNZO0dBQ0E7YUFFVix3QkFBQyxXQUFELENBQVU7Ozs7O0VBRVo7Ozs7O0VBQThCUixFQUFBLEtBQUFRO0NBQUE7RUFBQUEsS0FBQVIsRUFBQTtDQUFBO0NBQUEsSUFBQVM7Q0FBQSxJQUFBVCxFQUFBLE9BQUFNLFNBQUFOLEVBQUEsT0FBQU8sSUFBQTtFQWRoQ0UsS0FBQTtHQUNZO0dBQ0MsV0FBQUY7R0FHVixHQUNHRDthQUVKRTtFQU9GOzs7OztFQUF5QlIsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFPO0VBQUFQLEVBQUEsS0FBQVM7Q0FBQTtFQUFBQSxLQUFBVCxFQUFBO0NBQUE7Q0FBQSxPQWZ6QlM7QUFleUI7O0FBSTdCLFNBQVNkIiwibmFtZXMiOlsiQ2hlY2tib3giLCJDaGVja2JveFByaW1pdGl2ZSIsImNuIiwiQ2hlY2tJY29uIiwidDAiLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsImNsYXNzTmFtZSIsInByb3BzIiwidDEiLCJ0MiIsInQzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImNoZWNrYm94LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDaGVja2JveCBhcyBDaGVja2JveFByaW1pdGl2ZSB9IGZyb20gXCJAYmFzZS11aS9yZWFjdC9jaGVja2JveFwiXG5pbXBvcnQgeyBjbiB9IGZyb20gXCJjblwiXG5pbXBvcnQgeyBDaGVja0ljb24gfSBmcm9tIFwibHVjaWRlLXJlYWN0XCJcblxuZnVuY3Rpb24gQ2hlY2tib3goeyBjbGFzc05hbWUsIC4uLnByb3BzIH06IENoZWNrYm94UHJpbWl0aXZlLlJvb3QuUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8Q2hlY2tib3hQcmltaXRpdmUuUm9vdFxuICAgICAgZGF0YS1zbG90PVwiY2hlY2tib3hcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJwZWVyIHJlbGF0aXZlIGZsZXggc2l6ZS00IHNocmluay0wIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLVs0cHhdIGJvcmRlciBib3JkZXItaW5wdXQgdHJhbnNpdGlvbi1jb2xvcnMgb3V0bGluZS1ub25lIGdyb3VwLWhhcy1kaXNhYmxlZC9maWVsZDpvcGFjaXR5LTUwIGdyb3VwLWhhcy1bOmZvY3VzLXZpc2libGVdL2ZpZWxkLWxhYmVsOnJpbmctMCBncm91cC1oYXMtWzpmb2N1cy12aXNpYmxlXS9maWVsZC1sYWJlbDpub3QtZGF0YS1jaGVja2VkOmJvcmRlci1pbnB1dCBhZnRlcjphYnNvbHV0ZSBhZnRlcjotaW5zZXQteC0zIGFmdGVyOi1pbnNldC15LTIgZm9jdXMtdmlzaWJsZTpib3JkZXItcmluZyBmb2N1cy12aXNpYmxlOnJpbmctMyBmb2N1cy12aXNpYmxlOnJpbmctcmluZy81MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGlzYWJsZWQ6b3BhY2l0eS01MCBhcmlhLWludmFsaWQ6Ym9yZGVyLWRlc3RydWN0aXZlIGFyaWEtaW52YWxpZDpyaW5nLTMgYXJpYS1pbnZhbGlkOnJpbmctZGVzdHJ1Y3RpdmUvMjAgYXJpYS1pbnZhbGlkOmFyaWEtY2hlY2tlZDpib3JkZXItcHJpbWFyeSBkYXJrOmJnLWlucHV0LzMwIGRhcms6YXJpYS1pbnZhbGlkOmJvcmRlci1kZXN0cnVjdGl2ZS81MCBkYXJrOmFyaWEtaW52YWxpZDpyaW5nLWRlc3RydWN0aXZlLzQwIGRhdGEtY2hlY2tlZDpib3JkZXItcHJpbWFyeSBkYXRhLWNoZWNrZWQ6YmctcHJpbWFyeSBkYXRhLWNoZWNrZWQ6dGV4dC1wcmltYXJ5LWZvcmVncm91bmQgZ3JvdXAtaGFzLVs6Zm9jdXMtdmlzaWJsZV0vZmllbGQtbGFiZWw6ZGF0YS1jaGVja2VkOmJvcmRlci1wcmltYXJ5IGRhcms6ZGF0YS1jaGVja2VkOmJnLXByaW1hcnlcIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIDxDaGVja2JveFByaW1pdGl2ZS5JbmRpY2F0b3JcbiAgICAgICAgZGF0YS1zbG90PVwiY2hlY2tib3gtaW5kaWNhdG9yXCJcbiAgICAgICAgY2xhc3NOYW1lPVwiZ3JpZCBwbGFjZS1jb250ZW50LWNlbnRlciB0ZXh0LWN1cnJlbnQgdHJhbnNpdGlvbi1ub25lIFsmPnN2Z106c2l6ZS0zLjVcIlxuICAgICAgPlxuICAgICAgICA8Q2hlY2tJY29uXG4gICAgICAgIC8+XG4gICAgICA8L0NoZWNrYm94UHJpbWl0aXZlLkluZGljYXRvcj5cbiAgICA8L0NoZWNrYm94UHJpbWl0aXZlLlJvb3Q+XG4gIClcbn1cblxuZXhwb3J0IHsgQ2hlY2tib3ggfVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvY29tcG9uZW50cy91aS9jaGVja2JveC50c3gifQ==