import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/form/form-error.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Alert, AlertDescription } from "/src/components/ui/alert.tsx";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/form/form-error.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
export function FormError(t0) {
	const $ = _c(3);
	if ($[0] !== "6fc449ee2f3fa74e3b6129fb0b2a0d80b83fcffd79a7a8a2319d3dbeafada014") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "6fc449ee2f3fa74e3b6129fb0b2a0d80b83fcffd79a7a8a2319d3dbeafada014";
	}
	const { message } = t0;
	if (!message) {
		return null;
	}
	let t1;
	if ($[1] !== message) {
		t1 = /* @__PURE__ */ _jsxDEV(Alert, {
			variant: "destructive",
			role: "alert",
			children: /* @__PURE__ */ _jsxDEV(AlertDescription, { children: message }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 52
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 10
		}, this);
		$[1] = message;
		$[2] = t1;
	} else {
		t1 = $[2];
	}
	return t1;
}
_c2 = FormError;
var _c2;
$RefreshReg$(_c2, "FormError");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/form/form-error.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/form/form-error.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/form/form-error.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/form/form-error.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLE9BQU9DLHdCQUF3Qjs7O0FBRXhDLE9BQU8sU0FBQUMsVUFBQUMsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFtQixRQUFBSyxZQUFBTjtDQUN4QixJQUFJLENBQUNNLFNBQU87RUFBQSxPQUFTO0NBQUk7Q0FBQSxJQUFBQztDQUFBLElBQUFOLEVBQUEsT0FBQUssU0FBQTtFQUV2QkMsS0FBQSx3QkFBQyxPQUFEO0dBQWU7R0FBbUI7YUFDaEMsd0JBQUMsa0JBQUQsWUFBbUJELFFBQUY7Ozs7O0VBRGI7Ozs7O0VBRUVMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtDQUFBO0VBQUFBLEtBQUFOLEVBQUE7Q0FBQTtDQUFBLE9BRlJNO0FBRVEiLCJuYW1lcyI6WyJBbGVydCIsIkFsZXJ0RGVzY3JpcHRpb24iLCJGb3JtRXJyb3IiLCJ0MCIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwibWVzc2FnZSIsInQxIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImZvcm0tZXJyb3IudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFsZXJ0LCBBbGVydERlc2NyaXB0aW9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2FsZXJ0J1xuXG5leHBvcnQgZnVuY3Rpb24gRm9ybUVycm9yKHsgbWVzc2FnZSB9OiB7IG1lc3NhZ2U/OiBzdHJpbmcgfSkge1xuICBpZiAoIW1lc3NhZ2UpIHJldHVybiBudWxsXG4gIHJldHVybiAoXG4gICAgPEFsZXJ0IHZhcmlhbnQ9XCJkZXN0cnVjdGl2ZVwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgPEFsZXJ0RGVzY3JpcHRpb24+e21lc3NhZ2V9PC9BbGVydERlc2NyaXB0aW9uPlxuICAgIDwvQWxlcnQ+XG4gIClcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL2NvbXBvbmVudHMvZm9ybS9mb3JtLWVycm9yLnRzeCJ9