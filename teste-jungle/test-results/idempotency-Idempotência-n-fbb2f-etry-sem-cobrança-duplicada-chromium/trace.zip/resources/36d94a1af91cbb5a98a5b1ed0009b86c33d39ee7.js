import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/cart/add-to-cart-button.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport7_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { useLocation, useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { Loader2, ShoppingBag } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=e9f94b2e";
import { Button } from "/src/components/ui/button.tsx";
import { useAddToCart } from "/src/hooks/use-cart.ts";
import { session } from "/src/lib/session.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/cart/add-to-cart-button.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
export function AddToCartButton(t0) {
	_s();
	const $ = _c(24);
	if ($[0] !== "f37c73ce3d2714bca32e4e7746140f82c4f117791719c30ccc53783e14cc00b2") {
		for (let $i = 0; $i < 24; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "f37c73ce3d2714bca32e4e7746140f82c4f117791719c30ccc53783e14cc00b2";
	}
	let disabled;
	let nft;
	let props;
	let t1;
	let t2;
	if ($[1] !== t0) {
		({nft, quantity: t1, label: t2, disabled, ...props} = t0);
		$[1] = t0;
		$[2] = disabled;
		$[3] = nft;
		$[4] = props;
		$[5] = t1;
		$[6] = t2;
	} else {
		disabled = $[2];
		nft = $[3];
		props = $[4];
		t1 = $[5];
		t2 = $[6];
	}
	const quantity = t1 === undefined ? 1 : t1;
	const label = t2 === undefined ? "Adicionar ao carrinho" : t2;
	const addToCart = useAddToCart();
	const router = useRouter();
	const location = useLocation();
	let t3;
	if ($[7] !== addToCart || $[8] !== location || $[9] !== nft || $[10] !== quantity || $[11] !== router) {
		t3 = () => {
			if (!session.isAuthenticated()) {
				toast.info("Faça login para adicionar NFTs ao seu carrinho.");
				router.navigate({
					to: "/login",
					search: { redirect: location.href }
				});
				return;
			}
			addToCart.mutate({
				nft,
				quantity
			});
		};
		$[7] = addToCart;
		$[8] = location;
		$[9] = nft;
		$[10] = quantity;
		$[11] = router;
		$[12] = t3;
	} else {
		t3 = $[12];
	}
	const handleClick = t3;
	if (!nft.available) {
		let t4;
		if ($[13] !== props) {
			t4 = /* @__PURE__ */ _jsxDEV(Button, {
				type: "button",
				variant: "secondary",
				disabled: true,
				...props,
				children: "Indisponível (Vendido)"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 85,
				columnNumber: 12
			}, this);
			$[13] = props;
			$[14] = t4;
		} else {
			t4 = $[14];
		}
		return t4;
	}
	const t4 = addToCart.isPending || disabled;
	let t5;
	if ($[15] !== addToCart.isPending || $[16] !== label) {
		t5 = addToCart.isPending ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, {
			className: "size-4 animate-spin motion-reduce:animate-none",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 34
		}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Adicionando..." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 123
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 32
		}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(ShoppingBag, {
			className: "size-4",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 158
		}, this), /* @__PURE__ */ _jsxDEV("span", { children: label }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 211
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 156
		}, this);
		$[15] = addToCart.isPending;
		$[16] = label;
		$[17] = t5;
	} else {
		t5 = $[17];
	}
	let t6;
	if ($[18] !== addToCart.isPending || $[19] !== handleClick || $[20] !== props || $[21] !== t4 || $[22] !== t5) {
		t6 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			disabled: t4,
			"aria-busy": addToCart.isPending,
			onClick: handleClick,
			...props,
			children: t5
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 105,
			columnNumber: 10
		}, this);
		$[18] = addToCart.isPending;
		$[19] = handleClick;
		$[20] = props;
		$[21] = t4;
		$[22] = t5;
		$[23] = t6;
	} else {
		t6 = $[23];
	}
	return t6;
}
_s(AddToCartButton, "qBDqHFBXpy5To2Wm40Srw9nKurA=", false, function() {
	return [
		useAddToCart,
		useRouter,
		useLocation
	];
});
_c2 = AddToCartButton;
var _c2;
$RefreshReg$(_c2, "AddToCartButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/cart/add-to-cart-button.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/cart/add-to-cart-button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/cart/add-to-cart-button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/cart/add-to-cart-button.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUNBLFNBQVNBLGFBQWFDLGlCQUFpQjtBQUN2QyxTQUFTQyxTQUFTQyxtQkFBbUI7QUFDckMsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxlQUFlOzs7O0FBU3hCLE9BQU8sU0FBQUMsZ0JBQUFDLElBQUE7O0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBQztDQUFBLElBQUFDO0NBQUEsSUFBQUM7Q0FBQSxJQUFBQztDQUFBLElBQUFULEVBQUEsT0FBQUQsSUFBQTtFQUF5QixFQUFBTyxLQUFBSSxVQUFBRixJQUFBRyxPQUFBRixJQUFBSixVQUFBLEdBQUFFLFNBQUFSO0VBTVRDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBUTtFQUFBUixFQUFBLEtBQUFTO0NBQUE7RUFBQUosV0FBQUwsRUFBQTtFQUFBTSxNQUFBTixFQUFBO0VBQUFPLFFBQUFQLEVBQUE7RUFBQVEsS0FBQVIsRUFBQTtFQUFBUyxLQUFBVCxFQUFBO0NBQUE7Q0FKckIsTUFBQVUsV0FBQUYsT0FBQUksWUFBQSxJQUFBSjtDQUNBLE1BQUFHLFFBQUFGLE9BQUFHLFlBQUEsMEJBQUFIO0NBSUEsTUFBQUksWUFBa0JqQixhQUFhO0NBQy9CLE1BQUFrQixTQUFldkIsVUFBVTtDQUN6QixNQUFBd0IsV0FBaUJ6QixZQUFZO0NBQUMsSUFBQTBCO0NBQUEsSUFBQWhCLEVBQUEsT0FBQWEsYUFBQWIsRUFBQSxPQUFBZSxZQUFBZixFQUFBLE9BQUFNLE9BQUFOLEVBQUEsUUFBQVUsWUFBQVYsRUFBQSxRQUFBYyxRQUFBO0VBRVZFLFdBQUE7R0FDbEIsSUFBSSxDQUFDbkIsUUFBT29CLGdCQUFpQixHQUFDO0lBQzVCdkIsTUFBS3dCLEtBQU0saURBQWlEO0lBQ3ZESixPQUFNSyxTQUFVO0tBQUFDLElBQ2Y7S0FBUUMsUUFDSixFQUFBQyxVQUFZUCxTQUFRUSxLQUFNO0lBQ3BDLENBQUM7SUFBQztHQUFBO0dBR0pWLFVBQVNXLE9BQVE7SUFBQWxCO0lBQUFJO0dBQWdCLENBQUM7RUFBQztFQUNwQ1YsRUFBQSxLQUFBYTtFQUFBYixFQUFBLEtBQUFlO0VBQUFmLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxNQUFBVTtFQUFBVixFQUFBLE1BQUFjO0VBQUFkLEVBQUEsTUFBQWdCO0NBQUE7RUFBQUEsS0FBQWhCLEVBQUE7Q0FBQTtDQVZELE1BQUF5QixjQUFvQlQ7Q0FZcEIsSUFBSSxDQUFDVixJQUFHb0IsV0FBVTtFQUFBLElBQUFDO0VBQUEsSUFBQTNCLEVBQUEsUUFBQU8sT0FBQTtHQUVkb0IsS0FBQSx3QkFBQyxRQUFEO0lBQWE7SUFBaUI7SUFBWTtJQUFRLEdBQUtwQjtjQUFPO0dBQXZEOzs7OztHQUVFUCxFQUFBLE1BQUFPO0dBQUFQLEVBQUEsTUFBQTJCO0VBQUE7R0FBQUEsS0FBQTNCLEVBQUE7RUFBQTtFQUFBLE9BRlQyQjtDQUVTO0NBT0MsTUFBQUEsS0FBQWQsVUFBU2UsYUFBVHZCO0NBQStCLElBQUF3QjtDQUFBLElBQUE3QixFQUFBLFFBQUFhLFVBQUFlLGFBQUE1QixFQUFBLFFBQUFXLE9BQUE7RUFLeENrQixLQUFBaEIsVUFBU2UsWUFBVCxnREFFRyx3QkFBQyxTQUFEO0dBQW1CO0dBQTZEO0VBQU07Ozs7WUFDdEYsNENBQU0saUJBQXFCOzs7O1VBQUE7Ozs7YUFIOUIsZ0RBT0csd0JBQUMsYUFBRDtHQUF1QjtHQUFxQjtFQUFNOzs7O1lBQ2xELDRDQUFPakIsTUFBYTs7OztVQUFBOzs7OztFQUV2QlgsRUFBQSxNQUFBYSxVQUFBZTtFQUFBNUIsRUFBQSxNQUFBVztFQUFBWCxFQUFBLE1BQUE2QjtDQUFBO0VBQUFBLEtBQUE3QixFQUFBO0NBQUE7Q0FBQSxJQUFBOEI7Q0FBQSxJQUFBOUIsRUFBQSxRQUFBYSxVQUFBZSxhQUFBNUIsRUFBQSxRQUFBeUIsZUFBQXpCLEVBQUEsUUFBQU8sU0FBQVAsRUFBQSxRQUFBMkIsTUFBQTNCLEVBQUEsUUFBQTZCLElBQUE7RUFqQkhDLEtBQUEsd0JBQUMsUUFBRDtHQUNPO0dBQ0ssVUFBQUg7R0FDQyxhQUFBZCxVQUFTZTtHQUNYSDtHQUFXLEdBQ2hCbEI7YUFFSHNCO0VBUEk7Ozs7O0VBa0JFN0IsRUFBQSxNQUFBYSxVQUFBZTtFQUFBNUIsRUFBQSxNQUFBeUI7RUFBQXpCLEVBQUEsTUFBQU87RUFBQVAsRUFBQSxNQUFBMkI7RUFBQTNCLEVBQUEsTUFBQTZCO0VBQUE3QixFQUFBLE1BQUE4QjtDQUFBO0VBQUFBLEtBQUE5QixFQUFBO0NBQUE7Q0FBQSxPQWxCVDhCO0FBa0JTIiwibmFtZXMiOlsidXNlTG9jYXRpb24iLCJ1c2VSb3V0ZXIiLCJMb2FkZXIyIiwiU2hvcHBpbmdCYWciLCJ0b2FzdCIsIkJ1dHRvbiIsInVzZUFkZFRvQ2FydCIsInNlc3Npb24iLCJBZGRUb0NhcnRCdXR0b24iLCJ0MCIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwiZGlzYWJsZWQiLCJuZnQiLCJwcm9wcyIsInQxIiwidDIiLCJxdWFudGl0eSIsImxhYmVsIiwidW5kZWZpbmVkIiwiYWRkVG9DYXJ0Iiwicm91dGVyIiwibG9jYXRpb24iLCJ0MyIsImlzQXV0aGVudGljYXRlZCIsImluZm8iLCJuYXZpZ2F0ZSIsInRvIiwic2VhcmNoIiwicmVkaXJlY3QiLCJocmVmIiwibXV0YXRlIiwiaGFuZGxlQ2xpY2siLCJhdmFpbGFibGUiLCJ0NCIsImlzUGVuZGluZyIsInQ1IiwidDYiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiYWRkLXRvLWNhcnQtYnV0dG9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IENvbXBvbmVudFByb3BzIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VMb2NhdGlvbiwgdXNlUm91dGVyIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IExvYWRlcjIsIFNob3BwaW5nQmFnIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdzb25uZXInXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHsgdXNlQWRkVG9DYXJ0IH0gZnJvbSAnQC9ob29rcy91c2UtY2FydCdcbmltcG9ydCB7IHNlc3Npb24gfSBmcm9tICdAL2xpYi9zZXNzaW9uJ1xuaW1wb3J0IHR5cGUgeyBORlQgfSBmcm9tICdAL3R5cGVzL21vZGVscydcblxuaW50ZXJmYWNlIEFkZFRvQ2FydEJ1dHRvblByb3BzIGV4dGVuZHMgT21pdDxDb21wb25lbnRQcm9wczx0eXBlb2YgQnV0dG9uPiwgJ29uQ2xpY2snPiB7XG4gIG5mdDogTkZUXG4gIHF1YW50aXR5PzogbnVtYmVyXG4gIGxhYmVsPzogc3RyaW5nXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBBZGRUb0NhcnRCdXR0b24oe1xuICBuZnQsXG4gIHF1YW50aXR5ID0gMSxcbiAgbGFiZWwgPSAnQWRpY2lvbmFyIGFvIGNhcnJpbmhvJyxcbiAgZGlzYWJsZWQsXG4gIC4uLnByb3BzXG59OiBBZGRUb0NhcnRCdXR0b25Qcm9wcykge1xuICBjb25zdCBhZGRUb0NhcnQgPSB1c2VBZGRUb0NhcnQoKVxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxuICBjb25zdCBsb2NhdGlvbiA9IHVzZUxvY2F0aW9uKClcblxuICBjb25zdCBoYW5kbGVDbGljayA9ICgpID0+IHtcbiAgICBpZiAoIXNlc3Npb24uaXNBdXRoZW50aWNhdGVkKCkpIHtcbiAgICAgIHRvYXN0LmluZm8oJ0Zhw6dhIGxvZ2luIHBhcmEgYWRpY2lvbmFyIE5GVHMgYW8gc2V1IGNhcnJpbmhvLicpXG4gICAgICB2b2lkIHJvdXRlci5uYXZpZ2F0ZSh7XG4gICAgICAgIHRvOiAnL2xvZ2luJyxcbiAgICAgICAgc2VhcmNoOiB7IHJlZGlyZWN0OiBsb2NhdGlvbi5ocmVmIH0sXG4gICAgICB9KVxuICAgICAgcmV0dXJuXG4gICAgfVxuICAgIGFkZFRvQ2FydC5tdXRhdGUoeyBuZnQsIHF1YW50aXR5IH0pXG4gIH1cblxuICBpZiAoIW5mdC5hdmFpbGFibGUpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgdmFyaWFudD1cInNlY29uZGFyeVwiIGRpc2FibGVkIHsuLi5wcm9wc30+XG4gICAgICAgIEluZGlzcG9uw612ZWwgKFZlbmRpZG8pXG4gICAgICA8L0J1dHRvbj5cbiAgICApXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxCdXR0b25cbiAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgZGlzYWJsZWQ9e2FkZFRvQ2FydC5pc1BlbmRpbmcgfHwgZGlzYWJsZWR9XG4gICAgICBhcmlhLWJ1c3k9e2FkZFRvQ2FydC5pc1BlbmRpbmd9XG4gICAgICBvbkNsaWNrPXtoYW5kbGVDbGlja31cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICB7YWRkVG9DYXJ0LmlzUGVuZGluZyA/IChcbiAgICAgICAgPD5cbiAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJzaXplLTQgYW5pbWF0ZS1zcGluIG1vdGlvbi1yZWR1Y2U6YW5pbWF0ZS1ub25lXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICA8c3Bhbj5BZGljaW9uYW5kby4uLjwvc3Bhbj5cbiAgICAgICAgPC8+XG4gICAgICApIDogKFxuICAgICAgICA8PlxuICAgICAgICAgIDxTaG9wcGluZ0JhZyBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgIDxzcGFuPntsYWJlbH08L3NwYW4+XG4gICAgICAgIDwvPlxuICAgICAgKX1cbiAgICA8L0J1dHRvbj5cbiAgKVxufVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvY29tcG9uZW50cy9jYXJ0L2FkZC10by1jYXJ0LWJ1dHRvbi50c3gifQ==