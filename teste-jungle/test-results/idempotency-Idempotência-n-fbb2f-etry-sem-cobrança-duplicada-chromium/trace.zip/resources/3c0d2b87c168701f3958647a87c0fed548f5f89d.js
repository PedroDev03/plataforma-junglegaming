import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/_authenticated/orders.$orderId.tsx?tsr-split=component");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport11_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { ArrowLeft, CheckCircle2, Fingerprint, Hash, ShoppingBag, Sparkles, Wallet } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { Badge } from "/src/components/ui/badge.tsx";
import { buttonVariants } from "/src/components/ui/button.tsx";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { Separator } from "/src/components/ui/separator.tsx";
import { useSuspenseOrder } from "/src/hooks/use-orders.ts";
import { formatEth } from "/src/lib/eth.ts";
import { cn } from "/src/lib/utils.ts";
import { Route } from "/src/routes/_authenticated/orders.$orderId.tsx";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated/orders.$orderId.tsx?tsr-split=component";
import __vite__cjsImport11_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
function OrderReceiptPage() {
	_s();
	const $ = _c(84);
	if ($[0] !== "197e5e064a0cca8878753d18b11740085fe3e473d7e044ae4f5aa017e483eae8") {
		for (let $i = 0; $i < 84; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "197e5e064a0cca8878753d18b11740085fe3e473d7e044ae4f5aa017e483eae8";
	}
	const { orderId } = Route.useParams();
	const { data: order } = useSuspenseOrder(orderId);
	let t0;
	if ($[1] !== order.createdAt) {
		t0 = new Intl.DateTimeFormat("pt-BR", {
			dateStyle: "medium",
			timeStyle: "short"
		}).format(new Date(order.createdAt));
		$[1] = order.createdAt;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	const formattedDate = t0;
	let t1;
	if ($[3] !== order.items) {
		t1 = order.items.reduce(_temp, 0);
		$[3] = order.items;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	const totalUnits = t1;
	let t2;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV(Badge, {
			variant: "secondary",
			className: "gap-1.5",
			children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
				className: "size-3.5 text-primary",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 57
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Transação Confirmada (Snapshot Estático)" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 126
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 10
		}, this);
		$[5] = t2;
	} else {
		t2 = $[5];
	}
	let t3;
	if ($[6] !== formattedDate) {
		t3 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-wrap items-center justify-between gap-2",
			children: [t2, /* @__PURE__ */ _jsxDEV("span", {
				className: "font-mono text-xs text-muted-foreground",
				children: formattedDate
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 81
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 10
		}, this);
		$[6] = formattedDate;
		$[7] = t3;
	} else {
		t3 = $[7];
	}
	let t4;
	if ($[8] !== order.id) {
		t4 = /* @__PURE__ */ _jsxDEV(CardTitle, {
			role: "heading",
			"aria-level": 1,
			className: "text-2xl font-bold",
			children: ["Recibo do Pedido #", order.id]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 10
		}, this);
		$[8] = order.id;
		$[9] = t4;
	} else {
		t4 = $[9];
	}
	let t5;
	if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = /* @__PURE__ */ _jsxDEV(CardDescription, { children: "Seus colecionáveis digitais foram transferidos. Este recibo preserva os valores exatos no momento da compra." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 72,
			columnNumber: 10
		}, this);
		$[10] = t5;
	} else {
		t5 = $[10];
	}
	let t6;
	if ($[11] !== t3 || $[12] !== t4) {
		t6 = /* @__PURE__ */ _jsxDEV(CardHeader, {
			className: "gap-2",
			children: [
				t3,
				t4,
				t5
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 79,
			columnNumber: 10
		}, this);
		$[11] = t3;
		$[12] = t4;
		$[13] = t6;
	} else {
		t6 = $[13];
	}
	let t7;
	if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = /* @__PURE__ */ _jsxDEV(Separator, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 88,
			columnNumber: 10
		}, this);
		$[14] = t7;
	} else {
		t7 = $[14];
	}
	let t8;
	if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
		t8 = /* @__PURE__ */ _jsxDEV("dt", {
			className: "flex items-center gap-1.5 text-muted-foreground",
			children: [/* @__PURE__ */ _jsxDEV(Wallet, {
				className: "size-3.5",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 74
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Carteira Pagadora" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 124
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 10
		}, this);
		$[15] = t8;
	} else {
		t8 = $[15];
	}
	let t9;
	if ($[16] !== order.walletAddress) {
		t9 = /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-1",
			children: [t8, /* @__PURE__ */ _jsxDEV("dd", {
				className: "truncate font-mono font-medium",
				children: order.walletAddress
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 42
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 102,
			columnNumber: 10
		}, this);
		$[16] = order.walletAddress;
		$[17] = t9;
	} else {
		t9 = $[17];
	}
	let t10;
	if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
		t10 = /* @__PURE__ */ _jsxDEV("dt", {
			className: "flex items-center gap-1.5 text-muted-foreground",
			children: [/* @__PURE__ */ _jsxDEV(Fingerprint, {
				className: "size-3.5",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 110,
				columnNumber: 75
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Chave de Idempotência (x-idempotency-key)" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 110,
				columnNumber: 130
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 110,
			columnNumber: 11
		}, this);
		$[18] = t10;
	} else {
		t10 = $[18];
	}
	let t11;
	if ($[19] !== order.idempotencyKey) {
		t11 = /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-1",
			children: [t10, /* @__PURE__ */ _jsxDEV("dd", {
				className: "truncate font-mono font-medium",
				children: order.idempotencyKey
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 44
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 117,
			columnNumber: 11
		}, this);
		$[19] = order.idempotencyKey;
		$[20] = t11;
	} else {
		t11 = $[20];
	}
	let t12;
	if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
		t12 = /* @__PURE__ */ _jsxDEV("dt", {
			className: "flex items-center gap-1.5 text-muted-foreground",
			children: [/* @__PURE__ */ _jsxDEV(Hash, {
				className: "size-3.5",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 125,
				columnNumber: 75
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Hash da Transação (TxHash)" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 125,
				columnNumber: 123
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 125,
			columnNumber: 11
		}, this);
		$[21] = t12;
	} else {
		t12 = $[21];
	}
	let t13;
	if ($[22] !== order.txHash) {
		t13 = /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-1 sm:col-span-2",
			children: [t12, /* @__PURE__ */ _jsxDEV("dd", {
				className: "break-all font-mono text-muted-foreground",
				children: order.txHash
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 132,
				columnNumber: 58
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 132,
			columnNumber: 11
		}, this);
		$[22] = order.txHash;
		$[23] = t13;
	} else {
		t13 = $[23];
	}
	let t14;
	if ($[24] !== t11 || $[25] !== t13 || $[26] !== t9) {
		t14 = /* @__PURE__ */ _jsxDEV("dl", {
			className: "grid gap-3 rounded-xl border bg-muted/35 p-4 text-xs sm:grid-cols-2",
			children: [
				t9,
				t11,
				t13
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 140,
			columnNumber: 11
		}, this);
		$[24] = t11;
		$[25] = t13;
		$[26] = t9;
		$[27] = t14;
	} else {
		t14 = $[27];
	}
	const t15 = totalUnits === 1 ? "edição" : "edições";
	let t16;
	if ($[28] !== t15 || $[29] !== totalUnits) {
		t16 = /* @__PURE__ */ _jsxDEV("h2", {
			className: "text-sm font-semibold",
			children: [
				"Itens adquiridos (",
				totalUnits,
				" ",
				t15,
				")"
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 151,
			columnNumber: 11
		}, this);
		$[28] = t15;
		$[29] = totalUnits;
		$[30] = t16;
	} else {
		t16 = $[30];
	}
	let t17;
	if ($[31] !== order.items) {
		t17 = order.items.map(_temp2);
		$[31] = order.items;
		$[32] = t17;
	} else {
		t17 = $[32];
	}
	let t18;
	if ($[33] !== t17) {
		t18 = /* @__PURE__ */ _jsxDEV("ul", {
			className: "grid gap-2.5",
			children: t17
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 168,
			columnNumber: 11
		}, this);
		$[33] = t17;
		$[34] = t18;
	} else {
		t18 = $[34];
	}
	let t19;
	if ($[35] !== t16 || $[36] !== t18) {
		t19 = /* @__PURE__ */ _jsxDEV("section", {
			"aria-label": "Itens adquiridos",
			className: "grid gap-3",
			children: [t16, t18]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 176,
			columnNumber: 11
		}, this);
		$[35] = t16;
		$[36] = t18;
		$[37] = t19;
	} else {
		t19 = $[37];
	}
	let t20;
	if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
		t20 = /* @__PURE__ */ _jsxDEV(Separator, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 185,
			columnNumber: 11
		}, this);
		$[38] = t20;
	} else {
		t20 = $[38];
	}
	let t21;
	if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
		t21 = /* @__PURE__ */ _jsxDEV("dt", {
			className: "text-muted-foreground",
			children: "Subtotal"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 192,
			columnNumber: 11
		}, this);
		$[39] = t21;
	} else {
		t21 = $[39];
	}
	let t22;
	if ($[40] !== order.subtotalEth) {
		t22 = formatEth(order.subtotalEth);
		$[40] = order.subtotalEth;
		$[41] = t22;
	} else {
		t22 = $[41];
	}
	let t23;
	if ($[42] !== t22) {
		t23 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between gap-2",
			children: [t21, /* @__PURE__ */ _jsxDEV("dd", {
				className: "font-mono tabular-nums",
				children: [t22, " ETH"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 207,
				columnNumber: 73
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 207,
			columnNumber: 11
		}, this);
		$[42] = t22;
		$[43] = t23;
	} else {
		t23 = $[43];
	}
	let t24;
	if ($[44] === Symbol.for("react.memo_cache_sentinel")) {
		t24 = /* @__PURE__ */ _jsxDEV("span", { children: "Desconto" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 215,
			columnNumber: 11
		}, this);
		$[44] = t24;
	} else {
		t24 = $[44];
	}
	let t25;
	if ($[45] !== order.couponCode || $[46] !== order.discountPercent) {
		t25 = order.couponCode && /* @__PURE__ */ _jsxDEV(Badge, {
			variant: "secondary",
			className: "font-mono",
			children: [
				order.couponCode,
				" (-",
				order.discountPercent,
				"%)"
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 222,
			columnNumber: 31
		}, this);
		$[45] = order.couponCode;
		$[46] = order.discountPercent;
		$[47] = t25;
	} else {
		t25 = $[47];
	}
	let t26;
	if ($[48] !== t25) {
		t26 = /* @__PURE__ */ _jsxDEV("dt", {
			className: "flex items-center gap-1.5 text-muted-foreground",
			children: [t24, t25]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 231,
			columnNumber: 11
		}, this);
		$[48] = t25;
		$[49] = t26;
	} else {
		t26 = $[49];
	}
	let t27;
	if ($[50] !== order.discountEth) {
		t27 = formatEth(order.discountEth);
		$[50] = order.discountEth;
		$[51] = t27;
	} else {
		t27 = $[51];
	}
	let t28;
	if ($[52] !== t27) {
		t28 = /* @__PURE__ */ _jsxDEV("dd", {
			className: "font-mono tabular-nums",
			children: [
				"- ",
				t27,
				" ETH"
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 247,
			columnNumber: 11
		}, this);
		$[52] = t27;
		$[53] = t28;
	} else {
		t28 = $[53];
	}
	let t29;
	if ($[54] !== t26 || $[55] !== t28) {
		t29 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between gap-2",
			children: [t26, t28]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 255,
			columnNumber: 11
		}, this);
		$[54] = t26;
		$[55] = t28;
		$[56] = t29;
	} else {
		t29 = $[56];
	}
	let t30;
	if ($[57] === Symbol.for("react.memo_cache_sentinel")) {
		t30 = /* @__PURE__ */ _jsxDEV("dt", {
			className: "text-muted-foreground",
			children: "Taxa fixa (Gas & Protocolo)"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 264,
			columnNumber: 11
		}, this);
		$[57] = t30;
	} else {
		t30 = $[57];
	}
	let t31;
	if ($[58] !== order.feeEth) {
		t31 = formatEth(order.feeEth);
		$[58] = order.feeEth;
		$[59] = t31;
	} else {
		t31 = $[59];
	}
	let t32;
	if ($[60] !== t31) {
		t32 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between gap-2",
			children: [t30, /* @__PURE__ */ _jsxDEV("dd", {
				className: "font-mono tabular-nums",
				children: [t31, " ETH"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 279,
				columnNumber: 73
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 279,
			columnNumber: 11
		}, this);
		$[60] = t31;
		$[61] = t32;
	} else {
		t32 = $[61];
	}
	let t33;
	if ($[62] === Symbol.for("react.memo_cache_sentinel")) {
		t33 = /* @__PURE__ */ _jsxDEV(Separator, { className: "my-1" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 287,
			columnNumber: 11
		}, this);
		$[62] = t33;
	} else {
		t33 = $[62];
	}
	let t34;
	if ($[63] === Symbol.for("react.memo_cache_sentinel")) {
		t34 = /* @__PURE__ */ _jsxDEV("dt", { children: "Total Pago" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 294,
			columnNumber: 11
		}, this);
		$[63] = t34;
	} else {
		t34 = $[63];
	}
	let t35;
	if ($[64] === Symbol.for("react.memo_cache_sentinel")) {
		t35 = /* @__PURE__ */ _jsxDEV(Sparkles, {
			className: "size-4 text-primary",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 301,
			columnNumber: 11
		}, this);
		$[64] = t35;
	} else {
		t35 = $[64];
	}
	let t36;
	if ($[65] !== order.totalEth) {
		t36 = formatEth(order.totalEth);
		$[65] = order.totalEth;
		$[66] = t36;
	} else {
		t36 = $[66];
	}
	let t37;
	if ($[67] !== t36) {
		t37 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-baseline justify-between gap-2 text-base font-bold",
			children: [t34, /* @__PURE__ */ _jsxDEV("dd", {
				className: "flex items-center gap-1 font-mono text-lg tabular-nums",
				children: [t35, /* @__PURE__ */ _jsxDEV("span", { children: [t36, " ETH"] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 316,
					columnNumber: 171
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 316,
				columnNumber: 95
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 316,
			columnNumber: 11
		}, this);
		$[67] = t36;
		$[68] = t37;
	} else {
		t37 = $[68];
	}
	let t38;
	if ($[69] !== t23 || $[70] !== t29 || $[71] !== t32 || $[72] !== t37) {
		t38 = /* @__PURE__ */ _jsxDEV("dl", {
			className: "grid gap-2 text-sm",
			children: [
				t23,
				t29,
				t32,
				t33,
				t37
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 324,
			columnNumber: 11
		}, this);
		$[69] = t23;
		$[70] = t29;
		$[71] = t32;
		$[72] = t37;
		$[73] = t38;
	} else {
		t38 = $[73];
	}
	let t39;
	if ($[74] !== t14 || $[75] !== t19 || $[76] !== t38) {
		t39 = /* @__PURE__ */ _jsxDEV(CardContent, {
			className: "grid gap-6 pt-6",
			children: [
				t14,
				t19,
				t20,
				t38
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 335,
			columnNumber: 11
		}, this);
		$[74] = t14;
		$[75] = t19;
		$[76] = t38;
		$[77] = t39;
	} else {
		t39 = $[77];
	}
	let t40;
	if ($[78] === Symbol.for("react.memo_cache_sentinel")) {
		t40 = /* @__PURE__ */ _jsxDEV(Separator, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 345,
			columnNumber: 11
		}, this);
		$[78] = t40;
	} else {
		t40 = $[78];
	}
	let t41;
	if ($[79] === Symbol.for("react.memo_cache_sentinel")) {
		t41 = /* @__PURE__ */ _jsxDEV(Link, {
			to: "/",
			className: cn(buttonVariants({ variant: "outline" })),
			children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, {
				className: "size-4",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 354,
				columnNumber: 10
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Continuar explorando" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 354,
				columnNumber: 61
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 352,
			columnNumber: 11
		}, this);
		$[79] = t41;
	} else {
		t41 = $[79];
	}
	let t42;
	if ($[80] === Symbol.for("react.memo_cache_sentinel")) {
		t42 = /* @__PURE__ */ _jsxDEV(CardFooter, {
			className: "flex flex-wrap justify-between gap-3 pt-4",
			children: [t41, /* @__PURE__ */ _jsxDEV(Link, {
				to: "/cart",
				className: cn(buttonVariants({ variant: "default" })),
				children: [/* @__PURE__ */ _jsxDEV(ShoppingBag, {
					className: "size-4",
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 363,
					columnNumber: 12
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Ver carrinho restante" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 363,
					columnNumber: 65
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 361,
				columnNumber: 82
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 361,
			columnNumber: 11
		}, this);
		$[80] = t42;
	} else {
		t42 = $[80];
	}
	let t43;
	if ($[81] !== t39 || $[82] !== t6) {
		t43 = /* @__PURE__ */ _jsxDEV("main", {
			id: "main-content",
			tabIndex: -1,
			className: "mx-auto grid w-full max-w-3xl gap-6 px-4 py-6 outline-none sm:px-6 md:py-10",
			children: /* @__PURE__ */ _jsxDEV(Card, { children: [
				t6,
				t7,
				t39,
				t40,
				t42
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 370,
				columnNumber: 137
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 370,
			columnNumber: 11
		}, this);
		$[81] = t39;
		$[82] = t6;
		$[83] = t43;
	} else {
		t43 = $[83];
	}
	return t43;
}
_s(OrderReceiptPage, "5fn5/JsxU2WO+IISomOWMdMAkXg=", false, function() {
	return [Route.useParams, useSuspenseOrder];
});
_c2 = OrderReceiptPage;
function _temp2(item) {
	return /* @__PURE__ */ _jsxDEV("li", {
		className: "flex items-center justify-between gap-3 rounded-xl border p-3",
		children: [/* @__PURE__ */ _jsxDEV("div", {
			className: "flex min-w-0 items-center gap-3",
			children: [/* @__PURE__ */ _jsxDEV("img", {
				src: item.imageUrl,
				alt: `Obra NFT ${item.name} da coleção ${item.collection}`,
				loading: "lazy",
				decoding: "async",
				className: "size-14 shrink-0 rounded-lg bg-muted object-cover"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 380,
				columnNumber: 154
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "min-w-0",
				children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "truncate text-xs text-muted-foreground",
						children: item.collection
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 380,
						columnNumber: 360
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "truncate text-sm font-semibold",
						children: item.name
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 380,
						columnNumber: 435
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "font-mono text-xs text-muted-foreground tabular-nums",
						children: [
							item.quantity,
							"x ",
							formatEth(item.priceEth),
							" ETH"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 380,
						columnNumber: 496
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 380,
				columnNumber: 335
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 380,
			columnNumber: 105
		}, this), /* @__PURE__ */ _jsxDEV("span", {
			className: "shrink-0 font-mono text-sm font-semibold tabular-nums",
			children: [formatEth(item.lineTotalEth), " ETH"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 380,
			columnNumber: 627
		}, this)]
	}, item.nftId, true, {
		fileName: _jsxFileName,
		lineNumber: 380,
		columnNumber: 10
	}, this);
}
function _temp(acc, i) {
	return acc + i.quantity;
}
export { OrderReceiptPage as component };
var _c2;
$RefreshReg$(_c2, "OrderReceiptPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/_authenticated/orders.$orderId.tsx?tsr-split=component";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated/orders.$orderId.tsx?tsr-split=component", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated/orders.$orderId.tsx?tsr-split=component", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated/orders.$orderId.tsx?tsr-split=component" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBRUVBLFlBR0s7QUFFUCxTQUVFQyxXQUNBQyxjQUNBQyxhQUNBQyxNQUVBQyxhQUNBQyxVQUNBQyxjQUNLO0FBRVAsU0FBU0MsYUFBYTtBQUN0QixTQUFpQkMsc0JBQXNCO0FBQ3ZDLFNBQ0VDLE1BQ0FDLGFBQ0FDLGlCQUNBQyxZQUNBQyxZQUNBQyxpQkFDSztBQUNQLFNBQVNDLGlCQUFpQjtBQUUxQixTQUFrQ0Msd0JBQXdCO0FBRTFELFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxVQUFVO0FBQWEsU0FBQUMsYUFBQTs7OztBQVVoQyxTQUFBQyxtQkFBQTs7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FDRSxRQUFBSyxZQUFvQlAsTUFBS1EsVUFBVztDQUNwQyxRQUFBQyxNQUFBQyxVQUF3QmIsaUJBQWlCVSxPQUFPO0NBQUMsSUFBQUk7Q0FBQSxJQUFBVCxFQUFBLE9BQUFRLE1BQUFFLFdBQUE7RUFFM0JELEtBQUEsSUFBSUUsS0FBSUMsZUFBZ0IsU0FBUztHQUFBQyxXQUMxQztHQUFRQyxXQUNSO0VBQ2IsQ0FBQyxDQUFDLENBQUFDLE9BQVEsSUFBSUMsS0FBS1IsTUFBS0UsU0FBVSxDQUFDO0VBQUNWLEVBQUEsS0FBQVEsTUFBQUU7RUFBQVYsRUFBQSxLQUFBUztDQUFBO0VBQUFBLEtBQUFULEVBQUE7Q0FBQTtDQUhwQyxNQUFBaUIsZ0JBQXNCUjtDQUdjLElBQUFTO0NBQUEsSUFBQWxCLEVBQUEsT0FBQVEsTUFBQVcsT0FBQTtFQUVqQlgsV0FBS1csTUFBTUMsT0FBUUMsT0FBOEIsQ0FBQztFQUFDckIsRUFBQSxLQUFBUSxNQUFBVztFQUFBbkIsRUFBQSxLQUFBa0I7Q0FBQTtFQUFBQSxLQUFBbEIsRUFBQTtDQUFBO0NBQXRFLE1BQUFzQixhQUFtQmQ7Q0FBbUQsSUFBQWU7Q0FBQSxJQUFBdkIsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBVzVEbUIsS0FBQSx3QkFBQyxPQUFEO0dBQWU7R0FBc0I7YUFBckMsQ0FDRSx3QkFBQyxjQUFEO0lBQXdCO0lBQW9DO0dBQU07Ozs7YUFDbEUsNENBQU0sMkNBQThDOzs7O1dBRmhEOzs7Ozs7RUFHQ3ZCLEVBQUEsS0FBQXVCO0NBQUE7RUFBQUEsS0FBQXZCLEVBQUE7Q0FBQTtDQUFBLElBQUF3QjtDQUFBLElBQUF4QixFQUFBLE9BQUFpQixlQUFBO0VBSlRPLEtBQUE7R0FBZTthQUFmLENBQ0VELElBSUE7SUFBZ0I7Y0FBMkNOO0dBQW9COzs7O1dBQzVFOzs7Ozs7RUFBQWpCLEVBQUEsS0FBQWlCO0VBQUFqQixFQUFBLEtBQUF3QjtDQUFBO0VBQUFBLEtBQUF4QixFQUFBO0NBQUE7Q0FBQSxJQUFBeUI7Q0FBQSxJQUFBekIsRUFBQSxPQUFBUSxNQUFBa0IsSUFBQTtFQUVMRCxLQUFBLHdCQUFDLFdBQUQ7R0FBZ0I7R0FBc0I7R0FBYTthQUFuRCxDQUF1RSxzQkFDbERqQixNQUFLa0IsRUFEaEI7Ozs7OztFQUVDMUIsRUFBQSxLQUFBUSxNQUFBa0I7RUFBQTFCLEVBQUEsS0FBQXlCO0NBQUE7RUFBQUEsS0FBQXpCLEVBQUE7Q0FBQTtDQUFBLElBQUEyQjtDQUFBLElBQUEzQixFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFDWHVCLEtBQUEsd0JBQUMsaUJBQUQsWUFBZ0I7Ozs7O0VBR0MzQixFQUFBLE1BQUEyQjtDQUFBO0VBQUFBLEtBQUEzQixFQUFBO0NBQUE7Q0FBQSxJQUFBNEI7Q0FBQSxJQUFBNUIsRUFBQSxRQUFBd0IsTUFBQXhCLEVBQUEsUUFBQXlCLElBQUE7RUFmbkJHLEtBQUEsd0JBQUMsWUFBRDtHQUFzQjthQUF0QjtJQUNFSjtJQVFBQztJQUdBRTtHQVpTOzs7Ozs7RUFnQkMzQixFQUFBLE1BQUF3QjtFQUFBeEIsRUFBQSxNQUFBeUI7RUFBQXpCLEVBQUEsTUFBQTRCO0NBQUE7RUFBQUEsS0FBQTVCLEVBQUE7Q0FBQTtDQUFBLElBQUE2QjtDQUFBLElBQUE3QixFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFFWnlCLEtBQUEsd0JBQUMsV0FBRCxDQUFVOzs7OztFQUFBN0IsRUFBQSxNQUFBNkI7Q0FBQTtFQUFBQSxLQUFBN0IsRUFBQTtDQUFBO0NBQUEsSUFBQThCO0NBQUEsSUFBQTlCLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQU1KMEIsS0FBQTtHQUFjO2FBQWQsQ0FDRSx3QkFBQyxRQUFEO0lBQWtCO0lBQXVCO0dBQU07Ozs7YUFDL0MsNENBQU0sb0JBQXVCOzs7O1dBQzNCOzs7Ozs7RUFBQTlCLEVBQUEsTUFBQThCO0NBQUE7RUFBQUEsS0FBQTlCLEVBQUE7Q0FBQTtDQUFBLElBQUErQjtDQUFBLElBQUEvQixFQUFBLFFBQUFRLE1BQUF3QixlQUFBO0VBSk5ELEtBQUE7R0FBZTthQUFmLENBQ0VELElBSUE7SUFBYztjQUFrQ3RCLE1BQUt3QjtHQUFtQjs7OztXQUNyRTs7Ozs7O0VBQUFoQyxFQUFBLE1BQUFRLE1BQUF3QjtFQUFBaEMsRUFBQSxNQUFBK0I7Q0FBQTtFQUFBQSxLQUFBL0IsRUFBQTtDQUFBO0NBQUEsSUFBQWlDO0NBQUEsSUFBQWpDLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUdINkIsTUFBQTtHQUFjO2FBQWQsQ0FDRSx3QkFBQyxhQUFEO0lBQXVCO0lBQXVCO0dBQU07Ozs7YUFDcEQsNENBQU0sNENBQStDOzs7O1dBQ25EOzs7Ozs7RUFBQWpDLEVBQUEsTUFBQWlDO0NBQUE7RUFBQUEsTUFBQWpDLEVBQUE7Q0FBQTtDQUFBLElBQUFrQztDQUFBLElBQUFsQyxFQUFBLFFBQUFRLE1BQUEyQixnQkFBQTtFQUpORCxNQUFBO0dBQWU7YUFBZixDQUNFRCxLQUlBO0lBQWM7Y0FBa0N6QixNQUFLMkI7R0FBb0I7Ozs7V0FDdEU7Ozs7OztFQUFBbkMsRUFBQSxNQUFBUSxNQUFBMkI7RUFBQW5DLEVBQUEsTUFBQWtDO0NBQUE7RUFBQUEsTUFBQWxDLEVBQUE7Q0FBQTtDQUFBLElBQUFvQztDQUFBLElBQUFwQyxFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFHSGdDLE1BQUE7R0FBYzthQUFkLENBQ0Usd0JBQUMsTUFBRDtJQUFnQjtJQUF1QjtHQUFNOzs7O2FBQzdDLDRDQUFNLDZCQUFnQzs7OztXQUNwQzs7Ozs7O0VBQUFwQyxFQUFBLE1BQUFvQztDQUFBO0VBQUFBLE1BQUFwQyxFQUFBO0NBQUE7Q0FBQSxJQUFBcUM7Q0FBQSxJQUFBckMsRUFBQSxRQUFBUSxNQUFBOEIsUUFBQTtFQUpORCxNQUFBO0dBQWU7YUFBZixDQUNFRCxLQUlBO0lBQWM7Y0FBNkM1QixNQUFLOEI7R0FBWTs7OztXQUN6RTs7Ozs7O0VBQUF0QyxFQUFBLE1BQUFRLE1BQUE4QjtFQUFBdEMsRUFBQSxNQUFBcUM7Q0FBQTtFQUFBQSxNQUFBckMsRUFBQTtDQUFBO0NBQUEsSUFBQXVDO0NBQUEsSUFBQXZDLEVBQUEsUUFBQWtDLE9BQUFsQyxFQUFBLFFBQUFxQyxPQUFBckMsRUFBQSxRQUFBK0IsSUFBQTtFQXZCUFEsTUFBQTtHQUFjO2FBQWQ7SUFDRVI7SUFRQUc7SUFRQUc7R0FPRTs7Ozs7O0VBQUFyQyxFQUFBLE1BQUFrQztFQUFBbEMsRUFBQSxNQUFBcUM7RUFBQXJDLEVBQUEsTUFBQStCO0VBQUEvQixFQUFBLE1BQUF1QztDQUFBO0VBQUFBLE1BQUF2QyxFQUFBO0NBQUE7Q0FLZ0NzQiwyQkFBZSxJQUFmQTtDQUF1QyxJQUFBa0I7Q0FBQSxJQUFBeEMsRUFBQSxRQUFBeUMsT0FBQXpDLEVBQUEsUUFBQXNCLFlBQUE7RUFEekVrQixNQUFBO0dBQWM7YUFBZDtJQUFxQztJQUNoQmxCO0lBQVc7SUFBRUE7SUFBd0M7R0FDdEU7Ozs7OztFQUFBdEIsRUFBQSxNQUFBeUM7RUFBQXpDLEVBQUEsTUFBQXNCO0VBQUF0QixFQUFBLE1BQUF3QztDQUFBO0VBQUFBLE1BQUF4QyxFQUFBO0NBQUE7Q0FBQSxJQUFBMEM7Q0FBQSxJQUFBMUMsRUFBQSxRQUFBUSxNQUFBVyxPQUFBO0VBRURYLFlBQUtXLE1BQU13QixJQUFNQyxNQTBCakI7RUFBQzVDLEVBQUEsTUFBQVEsTUFBQVc7RUFBQW5CLEVBQUEsTUFBQTBDO0NBQUE7RUFBQUEsTUFBQTFDLEVBQUE7Q0FBQTtDQUFBLElBQUE2QztDQUFBLElBQUE3QyxFQUFBLFFBQUEwQyxLQUFBO0VBM0JKRyxNQUFBO0dBQWM7YUFDWHJDO0VBMkJDOzs7OztFQUFBUixFQUFBLE1BQUEwQztFQUFBMUMsRUFBQSxNQUFBNkM7Q0FBQTtFQUFBQSxNQUFBN0MsRUFBQTtDQUFBO0NBQUEsSUFBQThDO0NBQUEsSUFBQTlDLEVBQUEsUUFBQXdDLE9BQUF4QyxFQUFBLFFBQUE2QyxLQUFBO0VBaENOQyxNQUFBO0dBQW9CO0dBQTZCO2FBQWpELENBQ0VOLEtBR0FLLEdBNkJPOzs7Ozs7RUFBQTdDLEVBQUEsTUFBQXdDO0VBQUF4QyxFQUFBLE1BQUE2QztFQUFBN0MsRUFBQSxNQUFBOEM7Q0FBQTtFQUFBQSxNQUFBOUMsRUFBQTtDQUFBO0NBQUEsSUFBQStDO0NBQUEsSUFBQS9DLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUVUMkMsTUFBQSx3QkFBQyxXQUFELENBQVU7Ozs7O0VBQUEvQyxFQUFBLE1BQUErQztDQUFBO0VBQUFBLE1BQUEvQyxFQUFBO0NBQUE7Q0FBQSxJQUFBZ0Q7Q0FBQSxJQUFBaEQsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBS040QyxNQUFBO0dBQWM7YUFBd0I7RUFBWTs7Ozs7RUFBQWhELEVBQUEsTUFBQWdEO0NBQUE7RUFBQUEsTUFBQWhELEVBQUE7Q0FBQTtDQUFBLElBQUFpRDtDQUFBLElBQUFqRCxFQUFBLFFBQUFRLE1BQUEwQyxhQUFBO0VBQ1Z0RCxnQkFBVVksTUFBSzBDLFdBQVk7RUFBQ2xELEVBQUEsTUFBQVEsTUFBQTBDO0VBQUFsRCxFQUFBLE1BQUFpRDtDQUFBO0VBQUFBLE1BQUFqRCxFQUFBO0NBQUE7Q0FBQSxJQUFBbUQ7Q0FBQSxJQUFBbkQsRUFBQSxRQUFBaUQsS0FBQTtFQUZ0RUUsTUFBQTtHQUFlO2FBQWYsQ0FDRUgsS0FDQTtJQUFjO2NBQWQsQ0FBd0NwRCxLQUE2QixNQUFROzs7OztXQUMxRTs7Ozs7O0VBQUFJLEVBQUEsTUFBQWlEO0VBQUFqRCxFQUFBLE1BQUFtRDtDQUFBO0VBQUFBLE1BQUFuRCxFQUFBO0NBQUE7Q0FBQSxJQUFBb0Q7Q0FBQSxJQUFBcEQsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBSURnRCxNQUFBLDRDQUFNLFdBQWM7Ozs7O0VBQUFwRCxFQUFBLE1BQUFvRDtDQUFBO0VBQUFBLE1BQUFwRCxFQUFBO0NBQUE7Q0FBQSxJQUFBcUQ7Q0FBQSxJQUFBckQsRUFBQSxRQUFBUSxNQUFBOEMsY0FBQXRELEVBQUEsUUFBQVEsTUFBQStDLGlCQUFBO0VBQ25CL0MsWUFBSzhDLGNBQ0osd0JBQUMsT0FBRDtHQUFlO0dBQXNCO2FBQXJDO0lBQ0c5QyxNQUFLOEM7SUFBWTtJQUFJOUMsTUFBSytDO0lBQWlCO0dBRHhDOzs7Ozs7RUFHUHZELEVBQUEsTUFBQVEsTUFBQThDO0VBQUF0RCxFQUFBLE1BQUFRLE1BQUErQztFQUFBdkQsRUFBQSxNQUFBcUQ7Q0FBQTtFQUFBQSxNQUFBckQsRUFBQTtDQUFBO0NBQUEsSUFBQXdEO0NBQUEsSUFBQXhELEVBQUEsUUFBQXFELEtBQUE7RUFOSEcsTUFBQTtHQUFjO2FBQWQsQ0FDRUosS0FDQzVDLEdBS0M7Ozs7OztFQUFBUixFQUFBLE1BQUFxRDtFQUFBckQsRUFBQSxNQUFBd0Q7Q0FBQTtFQUFBQSxNQUFBeEQsRUFBQTtDQUFBO0NBQUEsSUFBQXlEO0NBQUEsSUFBQXpELEVBQUEsUUFBQVEsTUFBQWtELGFBQUE7RUFDc0M5RCxnQkFBVVksTUFBS2tELFdBQVk7RUFBQzFELEVBQUEsTUFBQVEsTUFBQWtEO0VBQUExRCxFQUFBLE1BQUF5RDtDQUFBO0VBQUFBLE1BQUF6RCxFQUFBO0NBQUE7Q0FBQSxJQUFBMkQ7Q0FBQSxJQUFBM0QsRUFBQSxRQUFBeUQsS0FBQTtFQUF0RUUsTUFBQTtHQUFjO2FBQWQ7SUFBdUM7SUFBRy9EO0lBQTZCO0dBQVE7Ozs7OztFQUFBSSxFQUFBLE1BQUF5RDtFQUFBekQsRUFBQSxNQUFBMkQ7Q0FBQTtFQUFBQSxNQUFBM0QsRUFBQTtDQUFBO0NBQUEsSUFBQTREO0NBQUEsSUFBQTVELEVBQUEsUUFBQXdELE9BQUF4RCxFQUFBLFFBQUEyRCxLQUFBO0VBVGpGQyxNQUFBO0dBQWU7YUFBZixDQUNFSixLQVFBRyxHQUNHOzs7Ozs7RUFBQTNELEVBQUEsTUFBQXdEO0VBQUF4RCxFQUFBLE1BQUEyRDtFQUFBM0QsRUFBQSxNQUFBNEQ7Q0FBQTtFQUFBQSxNQUFBNUQsRUFBQTtDQUFBO0NBQUEsSUFBQTZEO0NBQUEsSUFBQTdELEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUdIeUQsTUFBQTtHQUFjO2FBQXdCO0VBQStCOzs7OztFQUFBN0QsRUFBQSxNQUFBNkQ7Q0FBQTtFQUFBQSxNQUFBN0QsRUFBQTtDQUFBO0NBQUEsSUFBQThEO0NBQUEsSUFBQTlELEVBQUEsUUFBQVEsTUFBQXVELFFBQUE7RUFDN0JuRSxnQkFBVVksTUFBS3VELE1BQU87RUFBQy9ELEVBQUEsTUFBQVEsTUFBQXVEO0VBQUEvRCxFQUFBLE1BQUE4RDtDQUFBO0VBQUFBLE1BQUE5RCxFQUFBO0NBQUE7Q0FBQSxJQUFBZ0U7Q0FBQSxJQUFBaEUsRUFBQSxRQUFBOEQsS0FBQTtFQUZqRUUsTUFBQTtHQUFlO2FBQWYsQ0FDRUgsS0FDQTtJQUFjO2NBQWQsQ0FBd0NqRSxLQUF3QixNQUFROzs7OztXQUNyRTs7Ozs7O0VBQUFJLEVBQUEsTUFBQThEO0VBQUE5RCxFQUFBLE1BQUFnRTtDQUFBO0VBQUFBLE1BQUFoRSxFQUFBO0NBQUE7Q0FBQSxJQUFBaUU7Q0FBQSxJQUFBakUsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBRUw2RCxNQUFBLHdCQUFDLFdBQUQsRUFBcUIsa0JBQU07Ozs7O0VBQUFqRSxFQUFBLE1BQUFpRTtDQUFBO0VBQUFBLE1BQUFqRSxFQUFBO0NBQUE7Q0FBQSxJQUFBa0U7Q0FBQSxJQUFBbEUsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBR3pCOEQsTUFBQSwwQ0FBSSxhQUFjOzs7OztFQUFBbEUsRUFBQSxNQUFBa0U7Q0FBQTtFQUFBQSxNQUFBbEUsRUFBQTtDQUFBO0NBQUEsSUFBQW1FO0NBQUEsSUFBQW5FLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUVoQitELE1BQUEsd0JBQUMsVUFBRDtHQUFvQjtHQUFrQztFQUFNOzs7OztFQUFBbkUsRUFBQSxNQUFBbUU7Q0FBQTtFQUFBQSxNQUFBbkUsRUFBQTtDQUFBO0NBQUEsSUFBQW9FO0NBQUEsSUFBQXBFLEVBQUEsUUFBQVEsTUFBQTZELFVBQUE7RUFDckR6RSxnQkFBVVksTUFBSzZELFFBQVM7RUFBQ3JFLEVBQUEsTUFBQVEsTUFBQTZEO0VBQUFyRSxFQUFBLE1BQUFvRTtDQUFBO0VBQUFBLE1BQUFwRSxFQUFBO0NBQUE7Q0FBQSxJQUFBc0U7Q0FBQSxJQUFBdEUsRUFBQSxRQUFBb0UsS0FBQTtFQUpwQ0UsTUFBQTtHQUFlO2FBQWYsQ0FDRUosS0FDQTtJQUFjO2NBQWQsQ0FDRUMsS0FDQSw2Q0FBT3ZFLEtBQTBCLE1BQVU7Ozs7WUFDekM7Ozs7O1dBQ0Q7Ozs7OztFQUFBSSxFQUFBLE1BQUFvRTtFQUFBcEUsRUFBQSxNQUFBc0U7Q0FBQTtFQUFBQSxNQUFBdEUsRUFBQTtDQUFBO0NBQUEsSUFBQXVFO0NBQUEsSUFBQXZFLEVBQUEsUUFBQW1ELE9BQUFuRCxFQUFBLFFBQUE0RCxPQUFBNUQsRUFBQSxRQUFBZ0UsT0FBQWhFLEVBQUEsUUFBQXNFLEtBQUE7RUEvQlBDLE1BQUE7R0FBYzthQUFkO0lBQ0VwQjtJQUtBUztJQVlBSTtJQUtBQztJQUVBSztHQU9FOzs7Ozs7RUFBQXRFLEVBQUEsTUFBQW1EO0VBQUFuRCxFQUFBLE1BQUE0RDtFQUFBNUQsRUFBQSxNQUFBZ0U7RUFBQWhFLEVBQUEsTUFBQXNFO0VBQUF0RSxFQUFBLE1BQUF1RTtDQUFBO0VBQUFBLE1BQUF2RSxFQUFBO0NBQUE7Q0FBQSxJQUFBd0U7Q0FBQSxJQUFBeEUsRUFBQSxRQUFBdUMsT0FBQXZDLEVBQUEsUUFBQThDLE9BQUE5QyxFQUFBLFFBQUF1RSxLQUFBO0VBbkdOQyxNQUFBLHdCQUFDLGFBQUQ7R0FBdUI7YUFBdkI7SUFFRWpDO0lBMkJBTztJQW1DQUM7SUFHQXdCO0dBbkVVOzs7Ozs7RUFvR0N2RSxFQUFBLE1BQUF1QztFQUFBdkMsRUFBQSxNQUFBOEM7RUFBQTlDLEVBQUEsTUFBQXVFO0VBQUF2RSxFQUFBLE1BQUF3RTtDQUFBO0VBQUFBLE1BQUF4RSxFQUFBO0NBQUE7Q0FBQSxJQUFBeUU7Q0FBQSxJQUFBekUsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBRWJxRSxNQUFBLHdCQUFDLFdBQUQsQ0FBVTs7Ozs7RUFBQXpFLEVBQUEsTUFBQXlFO0NBQUE7RUFBQUEsTUFBQXpFLEVBQUE7Q0FBQTtDQUFBLElBQUEwRTtDQUFBLElBQUExRSxFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFHUnNFLE1BQUEsd0JBQUMsTUFBRDtHQUFTO0dBQWU3RSxjQUFHVixlQUFlLEVBQUF3RixTQUFXLFVBQVUsQ0FBQyxDQUFDO2FBQWpFLENBQ0Usd0JBQUMsV0FBRDtJQUFxQjtJQUFxQjtHQUFNOzs7O2FBQ2hELDRDQUFNLHVCQUEwQjs7OztXQUY3Qjs7Ozs7O0VBR0MzRSxFQUFBLE1BQUEwRTtDQUFBO0VBQUFBLE1BQUExRSxFQUFBO0NBQUE7Q0FBQSxJQUFBNEU7Q0FBQSxJQUFBNUUsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBSlJ3RSxNQUFBLHdCQUFDLFlBQUQ7R0FBc0I7YUFBdEIsQ0FDRUYsS0FLQSx3QkFBQyxNQUFEO0lBQVM7SUFBbUI3RSxjQUFHVixlQUFlLEVBQUF3RixTQUFXLFVBQVUsQ0FBQyxDQUFDO2NBQXJFLENBQ0Usd0JBQUMsYUFBRDtLQUF1QjtLQUFxQjtJQUFNOzs7O2NBQ2xELDRDQUFNLHdCQUEyQjs7OztZQUY5Qjs7Ozs7V0FOSTs7Ozs7O0VBVUMzRSxFQUFBLE1BQUE0RTtDQUFBO0VBQUFBLE1BQUE1RSxFQUFBO0NBQUE7Q0FBQSxJQUFBNkU7Q0FBQSxJQUFBN0UsRUFBQSxRQUFBd0UsT0FBQXhFLEVBQUEsUUFBQTRCLElBQUE7RUE1SWhCaUQsTUFBQTtHQUNLO0dBQ087R0FDQTthQUVWLHdCQUFDLE1BQUQ7SUFDRWpEO0lBa0JBQztJQUVBMkM7SUFzR0FDO0lBRUFHO0dBN0hHOzs7OztFQXlJQTs7Ozs7RUFBQTVFLEVBQUEsTUFBQXdFO0VBQUF4RSxFQUFBLE1BQUE0QjtFQUFBNUIsRUFBQSxNQUFBNkU7Q0FBQTtFQUFBQSxNQUFBN0UsRUFBQTtDQUFBO0NBQUEsT0E5SVA2RTtBQThJTzs7Ozs7QUExSlgsU0FBQUMsT0FBQWxDLE1BQUE7Q0FBQSxPQXlFZ0I7RUFFWTtZQUZaLENBSUU7R0FBZTthQUFmLENBQ0U7SUFDT0EsVUFBSW1DO0lBQ0osaUJBQVluQyxLQUFJb0MsS0FBSyxjQUFlcEMsS0FBSXFDO0lBQ3JDO0lBQ0M7SUFDQztHQUFtRDs7OzthQUUvRDtJQUFlO2NBQWY7S0FDRTtNQUFhO2dCQUEwQ3JDLEtBQUlxQztLQUFlOzs7OztLQUMxRTtNQUFhO2dCQUFrQ3JDLEtBQUlvQztLQUFTOzs7OztLQUM1RDtNQUFhO2dCQUFiO09BQ0dwQyxLQUFJc0M7T0FBVTtPQUFHdEYsVUFBVWdELEtBQUl1QyxRQUFTO09BQUU7TUFDMUM7Ozs7OztJQUNBOzs7OztXQUNGOzs7OztZQUVMO0dBQWdCO2FBQWhCLENBQ0d2RixVQUFVZ0QsS0FBSXdDLFlBQWEsR0FBRSxNQUMxQjs7Ozs7VUFFVDtJQXhCUXhDLEtBQUl5Qzs7OztRQXdCWjtBQUFBO0FBbEdmLFNBQUFoRSxNQUFBaUUsS0FBQUMsR0FBQTtDQUFBLE9BU29ERCxNQUFNQyxFQUFDTDtBQUFTO0FBbUpuRSxTQUFBbkYsb0JBQUF5RiIsIm5hbWVzIjpbIkxpbmsiLCJBcnJvd0xlZnQiLCJDaGVja0NpcmNsZTIiLCJGaW5nZXJwcmludCIsIkhhc2giLCJTaG9wcGluZ0JhZyIsIlNwYXJrbGVzIiwiV2FsbGV0IiwiQmFkZ2UiLCJidXR0b25WYXJpYW50cyIsIkNhcmQiLCJDYXJkQ29udGVudCIsIkNhcmREZXNjcmlwdGlvbiIsIkNhcmRGb290ZXIiLCJDYXJkSGVhZGVyIiwiQ2FyZFRpdGxlIiwiU2VwYXJhdG9yIiwidXNlU3VzcGVuc2VPcmRlciIsImZvcm1hdEV0aCIsImNuIiwiUm91dGUiLCJPcmRlclJlY2VpcHRQYWdlIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJvcmRlcklkIiwidXNlUGFyYW1zIiwiZGF0YSIsIm9yZGVyIiwidDAiLCJjcmVhdGVkQXQiLCJJbnRsIiwiRGF0ZVRpbWVGb3JtYXQiLCJkYXRlU3R5bGUiLCJ0aW1lU3R5bGUiLCJmb3JtYXQiLCJEYXRlIiwiZm9ybWF0dGVkRGF0ZSIsInQxIiwiaXRlbXMiLCJyZWR1Y2UiLCJfdGVtcCIsInRvdGFsVW5pdHMiLCJ0MiIsInQzIiwidDQiLCJpZCIsInQ1IiwidDYiLCJ0NyIsInQ4IiwidDkiLCJ3YWxsZXRBZGRyZXNzIiwidDEwIiwidDExIiwiaWRlbXBvdGVuY3lLZXkiLCJ0MTIiLCJ0MTMiLCJ0eEhhc2giLCJ0MTQiLCJ0MTYiLCJ0MTUiLCJ0MTciLCJtYXAiLCJpdGVtIiwidDE4IiwidDE5IiwidDIwIiwidDIxIiwidDIyIiwic3VidG90YWxFdGgiLCJ0MjMiLCJ0MjQiLCJ0MjUiLCJjb3Vwb25Db2RlIiwiZGlzY291bnRQZXJjZW50IiwidDI2IiwidDI3IiwiZGlzY291bnRFdGgiLCJ0MjgiLCJ0MjkiLCJ0MzAiLCJ0MzEiLCJmZWVFdGgiLCJ0MzIiLCJ0MzMiLCJ0MzQiLCJ0MzUiLCJ0MzYiLCJ0b3RhbEV0aCIsInQzNyIsInQzOCIsInQzOSIsInQ0MCIsInQ0MSIsInZhcmlhbnQiLCJ0NDIiLCJ0NDMiLCJfdGVtcDIiLCJpbWFnZVVybCIsIm5hbWUiLCJjb2xsZWN0aW9uIiwicXVhbnRpdHkiLCJwcmljZUV0aCIsImxpbmVUb3RhbEV0aCIsIm5mdElkIiwiYWNjIiwiaSIsImNvbXBvbmVudCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJvcmRlcnMuJG9yZGVySWQudHN4P3Rzci1zcGxpdD1jb21wb25lbnQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgY3JlYXRlRmlsZVJvdXRlLFxuICBMaW5rLFxuICB1c2VSb3V0ZXIsXG4gIHR5cGUgRXJyb3JDb21wb25lbnRQcm9wcyxcbn0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IGlzQXhpb3NFcnJvciB9IGZyb20gJ2F4aW9zJ1xuaW1wb3J0IHtcbiAgQWxlcnRDaXJjbGUsXG4gIEFycm93TGVmdCxcbiAgQ2hlY2tDaXJjbGUyLFxuICBGaW5nZXJwcmludCxcbiAgSGFzaCxcbiAgUmVmcmVzaEN3LFxuICBTaG9wcGluZ0JhZyxcbiAgU3BhcmtsZXMsXG4gIFdhbGxldCxcbn0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgQWxlcnQsIEFsZXJ0RGVzY3JpcHRpb24sIEFsZXJ0VGl0bGUgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYWxlcnQnXG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9iYWRnZSdcbmltcG9ydCB7IEJ1dHRvbiwgYnV0dG9uVmFyaWFudHMgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHtcbiAgQ2FyZCxcbiAgQ2FyZENvbnRlbnQsXG4gIENhcmREZXNjcmlwdGlvbixcbiAgQ2FyZEZvb3RlcixcbiAgQ2FyZEhlYWRlcixcbiAgQ2FyZFRpdGxlLFxufSBmcm9tICdAL2NvbXBvbmVudHMvdWkvY2FyZCdcbmltcG9ydCB7IFNlcGFyYXRvciB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9zZXBhcmF0b3InXG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9za2VsZXRvbidcbmltcG9ydCB7IG9yZGVyRGV0YWlsUXVlcnlPcHRpb25zLCB1c2VTdXNwZW5zZU9yZGVyIH0gZnJvbSAnQC9ob29rcy91c2Utb3JkZXJzJ1xuaW1wb3J0IHsgZ2V0RXJyb3JNZXNzYWdlIH0gZnJvbSAnQC9saWIvYXBpJ1xuaW1wb3J0IHsgZm9ybWF0RXRoIH0gZnJvbSAnQC9saWIvZXRoJ1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcblxuZXhwb3J0IGNvbnN0IFJvdXRlID0gY3JlYXRlRmlsZVJvdXRlKCcvX2F1dGhlbnRpY2F0ZWQvb3JkZXJzLyRvcmRlcklkJykoe1xuICBsb2FkZXI6ICh7IGNvbnRleHQsIHBhcmFtcyB9KSA9PlxuICAgIGNvbnRleHQucXVlcnlDbGllbnQuZW5zdXJlUXVlcnlEYXRhKG9yZGVyRGV0YWlsUXVlcnlPcHRpb25zKHBhcmFtcy5vcmRlcklkKSksXG4gIHBlbmRpbmdDb21wb25lbnQ6IE9yZGVyUmVjZWlwdFNrZWxldG9uLFxuICBlcnJvckNvbXBvbmVudDogT3JkZXJSZWNlaXB0RXJyb3IsXG4gIGNvbXBvbmVudDogT3JkZXJSZWNlaXB0UGFnZSxcbn0pXG5cbmZ1bmN0aW9uIE9yZGVyUmVjZWlwdFBhZ2UoKSB7XG4gIGNvbnN0IHsgb3JkZXJJZCB9ID0gUm91dGUudXNlUGFyYW1zKClcbiAgY29uc3QgeyBkYXRhOiBvcmRlciB9ID0gdXNlU3VzcGVuc2VPcmRlcihvcmRlcklkKVxuXG4gIGNvbnN0IGZvcm1hdHRlZERhdGUgPSBuZXcgSW50bC5EYXRlVGltZUZvcm1hdCgncHQtQlInLCB7XG4gICAgZGF0ZVN0eWxlOiAnbWVkaXVtJyxcbiAgICB0aW1lU3R5bGU6ICdzaG9ydCcsXG4gIH0pLmZvcm1hdChuZXcgRGF0ZShvcmRlci5jcmVhdGVkQXQpKVxuXG4gIGNvbnN0IHRvdGFsVW5pdHMgPSBvcmRlci5pdGVtcy5yZWR1Y2UoKGFjYywgaSkgPT4gYWNjICsgaS5xdWFudGl0eSwgMClcblxuICByZXR1cm4gKFxuICAgIDxtYWluXG4gICAgICBpZD1cIm1haW4tY29udGVudFwiXG4gICAgICB0YWJJbmRleD17LTF9XG4gICAgICBjbGFzc05hbWU9XCJteC1hdXRvIGdyaWQgdy1mdWxsIG1heC13LTN4bCBnYXAtNiBweC00IHB5LTYgb3V0bGluZS1ub25lIHNtOnB4LTYgbWQ6cHktMTBcIlxuICAgID5cbiAgICAgIDxDYXJkPlxuICAgICAgICA8Q2FyZEhlYWRlciBjbGFzc05hbWU9XCJnYXAtMlwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJnYXAtMS41XCI+XG4gICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwic2l6ZS0zLjUgdGV4dC1wcmltYXJ5XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+VHJhbnNhw6fDo28gQ29uZmlybWFkYSAoU25hcHNob3QgRXN0w6F0aWNvKTwvc3Bhbj5cbiAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57Zm9ybWF0dGVkRGF0ZX08L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8Q2FyZFRpdGxlIHJvbGU9XCJoZWFkaW5nXCIgYXJpYS1sZXZlbD17MX0gY2xhc3NOYW1lPVwidGV4dC0yeGwgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICBSZWNpYm8gZG8gUGVkaWRvICN7b3JkZXIuaWR9XG4gICAgICAgICAgPC9DYXJkVGl0bGU+XG4gICAgICAgICAgPENhcmREZXNjcmlwdGlvbj5cbiAgICAgICAgICAgIFNldXMgY29sZWNpb27DoXZlaXMgZGlnaXRhaXMgZm9yYW0gdHJhbnNmZXJpZG9zLiBFc3RlIHJlY2libyBwcmVzZXJ2YSBvcyB2YWxvcmVzIGV4YXRvc1xuICAgICAgICAgICAgbm8gbW9tZW50byBkYSBjb21wcmEuXG4gICAgICAgICAgPC9DYXJkRGVzY3JpcHRpb24+XG4gICAgICAgIDwvQ2FyZEhlYWRlcj5cblxuICAgICAgICA8U2VwYXJhdG9yIC8+XG5cbiAgICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTYgcHQtNlwiPlxuICAgICAgICAgIHsvKiBNZXRhZGFkb3MgT24tQ2hhaW4gZSBJZGVtcG90w6puY2lhICovfVxuICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJncmlkIGdhcC0zIHJvdW5kZWQteGwgYm9yZGVyIGJnLW11dGVkLzM1IHAtNCB0ZXh0LXhzIHNtOmdyaWQtY29scy0yXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTFcIj5cbiAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgPFdhbGxldCBjbGFzc05hbWU9XCJzaXplLTMuNVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+Q2FydGVpcmEgUGFnYWRvcmE8L3NwYW4+XG4gICAgICAgICAgICAgIDwvZHQ+XG4gICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJ0cnVuY2F0ZSBmb250LW1vbm8gZm9udC1tZWRpdW1cIj57b3JkZXIud2FsbGV0QWRkcmVzc308L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtMVwiPlxuICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICA8RmluZ2VycHJpbnQgY2xhc3NOYW1lPVwic2l6ZS0zLjVcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkNoYXZlIGRlIElkZW1wb3TDqm5jaWEgKHgtaWRlbXBvdGVuY3kta2V5KTwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kdD5cbiAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cInRydW5jYXRlIGZvbnQtbW9ubyBmb250LW1lZGl1bVwiPntvcmRlci5pZGVtcG90ZW5jeUtleX08L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtMSBzbTpjb2wtc3Bhbi0yXCI+XG4gICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgIDxIYXNoIGNsYXNzTmFtZT1cInNpemUtMy41XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5IYXNoIGRhIFRyYW5zYcOnw6NvIChUeEhhc2gpPC9zcGFuPlxuICAgICAgICAgICAgICA8L2R0PlxuICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwiYnJlYWstYWxsIGZvbnQtbW9ubyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57b3JkZXIudHhIYXNofTwvZGQ+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2RsPlxuXG4gICAgICAgICAgey8qIExpc3RhIGRlIEl0ZW5zIGRvIFNuYXBzaG90ICovfVxuICAgICAgICAgIDxzZWN0aW9uIGFyaWEtbGFiZWw9XCJJdGVucyBhZHF1aXJpZG9zXCIgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtM1wiPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgICBJdGVucyBhZHF1aXJpZG9zICh7dG90YWxVbml0c30ge3RvdGFsVW5pdHMgPT09IDEgPyAnZWRpw6fDo28nIDogJ2VkacOnw7Vlcyd9KVxuICAgICAgICAgICAgPC9oMj5cbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJncmlkIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAge29yZGVyLml0ZW1zLm1hcCgoaXRlbSkgPT4gKFxuICAgICAgICAgICAgICAgIDxsaVxuICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLm5mdElkfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHJvdW5kZWQteGwgYm9yZGVyIHAtM1wiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG1pbi13LTAgaXRlbXMtY2VudGVyIGdhcC0zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgICAgICAgICAgICBzcmM9e2l0ZW0uaW1hZ2VVcmx9XG4gICAgICAgICAgICAgICAgICAgICAgYWx0PXtgT2JyYSBORlQgJHtpdGVtLm5hbWV9IGRhIGNvbGXDp8OjbyAke2l0ZW0uY29sbGVjdGlvbn1gfVxuICAgICAgICAgICAgICAgICAgICAgIGxvYWRpbmc9XCJsYXp5XCJcbiAgICAgICAgICAgICAgICAgICAgICBkZWNvZGluZz1cImFzeW5jXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzaXplLTE0IHNocmluay0wIHJvdW5kZWQtbGcgYmctbXV0ZWQgb2JqZWN0LWNvdmVyXCJcbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtaW4tdy0wXCI+XG4gICAgICAgICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidHJ1bmNhdGUgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj57aXRlbS5jb2xsZWN0aW9ufTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0cnVuY2F0ZSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj57aXRlbS5uYW1lfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmQgdGFidWxhci1udW1zXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5xdWFudGl0eX14IHtmb3JtYXRFdGgoaXRlbS5wcmljZUV0aCl9IEVUSFxuICAgICAgICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwic2hyaW5rLTAgZm9udC1tb25vIHRleHQtc20gZm9udC1zZW1pYm9sZCB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEV0aChpdGVtLmxpbmVUb3RhbEV0aCl9IEVUSFxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvbGk+XG4gICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgPC91bD5cbiAgICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgICA8U2VwYXJhdG9yIC8+XG5cbiAgICAgICAgICB7LyogUmVzdW1vIEZpbmFuY2Vpcm8gRXN0w6F0aWNvICovfVxuICAgICAgICAgIDxkbCBjbGFzc05hbWU9XCJncmlkIGdhcC0yIHRleHQtc21cIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5TdWJ0b3RhbDwvZHQ+XG4gICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJmb250LW1vbm8gdGFidWxhci1udW1zXCI+e2Zvcm1hdEV0aChvcmRlci5zdWJ0b3RhbEV0aCl9IEVUSDwvZGQ+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgPHNwYW4+RGVzY29udG88L3NwYW4+XG4gICAgICAgICAgICAgICAge29yZGVyLmNvdXBvbkNvZGUgJiYgKFxuICAgICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAge29yZGVyLmNvdXBvbkNvZGV9ICgte29yZGVyLmRpc2NvdW50UGVyY2VudH0lKVxuICAgICAgICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2R0PlxuICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRhYnVsYXItbnVtc1wiPi0ge2Zvcm1hdEV0aChvcmRlci5kaXNjb3VudEV0aCl9IEVUSDwvZGQ+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cbiAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlRheGEgZml4YSAoR2FzICYgUHJvdG9jb2xvKTwvZHQ+XG4gICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJmb250LW1vbm8gdGFidWxhci1udW1zXCI+e2Zvcm1hdEV0aChvcmRlci5mZWVFdGgpfSBFVEg8L2RkPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxTZXBhcmF0b3IgY2xhc3NOYW1lPVwibXktMVwiIC8+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1iYXNlbGluZSBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgdGV4dC1iYXNlIGZvbnQtYm9sZFwiPlxuICAgICAgICAgICAgICA8ZHQ+VG90YWwgUGFnbzwvZHQ+XG4gICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMSBmb250LW1vbm8gdGV4dC1sZyB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwic2l6ZS00IHRleHQtcHJpbWFyeVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4+e2Zvcm1hdEV0aChvcmRlci50b3RhbEV0aCl9IEVUSDwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGw+XG4gICAgICAgIDwvQ2FyZENvbnRlbnQ+XG5cbiAgICAgICAgPFNlcGFyYXRvciAvPlxuXG4gICAgICAgIDxDYXJkRm9vdGVyIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGp1c3RpZnktYmV0d2VlbiBnYXAtMyBwdC00XCI+XG4gICAgICAgICAgPExpbmsgdG89XCIvXCIgY2xhc3NOYW1lPXtjbihidXR0b25WYXJpYW50cyh7IHZhcmlhbnQ6ICdvdXRsaW5lJyB9KSl9PlxuICAgICAgICAgICAgPEFycm93TGVmdCBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgPHNwYW4+Q29udGludWFyIGV4cGxvcmFuZG88L3NwYW4+XG4gICAgICAgICAgPC9MaW5rPlxuXG4gICAgICAgICAgPExpbmsgdG89XCIvY2FydFwiIGNsYXNzTmFtZT17Y24oYnV0dG9uVmFyaWFudHMoeyB2YXJpYW50OiAnZGVmYXVsdCcgfSkpfT5cbiAgICAgICAgICAgIDxTaG9wcGluZ0JhZyBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgPHNwYW4+VmVyIGNhcnJpbmhvIHJlc3RhbnRlPC9zcGFuPlxuICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgPC9DYXJkRm9vdGVyPlxuICAgICAgPC9DYXJkPlxuICAgIDwvbWFpbj5cbiAgKVxufVxuXG5mdW5jdGlvbiBPcmRlclJlY2VpcHRTa2VsZXRvbigpIHtcbiAgcmV0dXJuIChcbiAgICA8bWFpblxuICAgICAgaWQ9XCJtYWluLWNvbnRlbnRcIlxuICAgICAgYXJpYS1idXN5PVwidHJ1ZVwiXG4gICAgICBhcmlhLWxhYmVsPVwiQ2FycmVnYW5kbyByZWNpYm8gZG8gcGVkaWRvXCJcbiAgICAgIGNsYXNzTmFtZT1cIm14LWF1dG8gZ3JpZCB3LWZ1bGwgbWF4LXctM3hsIGdhcC02IHB4LTQgcHktNiBzbTpweC02IG1kOnB5LTEwXCJcbiAgICA+XG4gICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC05NiB3LWZ1bGwgcm91bmRlZC14bFwiIC8+XG4gICAgPC9tYWluPlxuICApXG59XG5cbmZ1bmN0aW9uIE9yZGVyUmVjZWlwdEVycm9yKHsgZXJyb3IsIHJlc2V0IH06IEVycm9yQ29tcG9uZW50UHJvcHMpIHtcbiAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcbiAgY29uc3QgaXNOb3RGb3VuZCA9IGlzQXhpb3NFcnJvcihlcnJvcikgJiYgZXJyb3IucmVzcG9uc2U/LnN0YXR1cyA9PT0gNDA0XG5cbiAgaWYgKGlzTm90Rm91bmQpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPG1haW4gaWQ9XCJtYWluLWNvbnRlbnRcIiBjbGFzc05hbWU9XCJteC1hdXRvIGZsZXggdy1mdWxsIG1heC13LW1kIGZsZXgtMSBpdGVtcy1jZW50ZXIgcC00XCI+XG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT1cInctZnVsbCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxDYXJkSGVhZGVyPlxuICAgICAgICAgICAgPENhcmRUaXRsZSByb2xlPVwiaGVhZGluZ1wiIGFyaWEtbGV2ZWw9ezF9IGNsYXNzTmFtZT1cInRleHQteGxcIj5cbiAgICAgICAgICAgICAgUmVjaWJvIG7Do28gZW5jb250cmFkbyAoNDA0KVxuICAgICAgICAgICAgPC9DYXJkVGl0bGU+XG4gICAgICAgICAgICA8Q2FyZERlc2NyaXB0aW9uPkVzdGUgcGVkaWRvIG7Do28gZXhpc3RlIG91IHBlcnRlbmNlIGEgb3V0cmEgY29udGEuPC9DYXJkRGVzY3JpcHRpb24+XG4gICAgICAgICAgPC9DYXJkSGVhZGVyPlxuICAgICAgICAgIDxDYXJkQ29udGVudD5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL1wiIGNsYXNzTmFtZT17Y24oYnV0dG9uVmFyaWFudHMoeyB2YXJpYW50OiAnZGVmYXVsdCcgfSksICd3LWZ1bGwnKX0+XG4gICAgICAgICAgICAgIFZvbHRhciBhbyBjYXTDoWxvZ29cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICA8L0NhcmRDb250ZW50PlxuICAgICAgICA8L0NhcmQ+XG4gICAgICA8L21haW4+XG4gICAgKVxuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8bWFpbiBpZD1cIm1haW4tY29udGVudFwiIGNsYXNzTmFtZT1cIm14LWF1dG8gZ3JpZCB3LWZ1bGwgbWF4LXctMnhsIGdhcC00IHAtNCBtZDpweS0xMlwiPlxuICAgICAgPEFsZXJ0IHZhcmlhbnQ9XCJkZXN0cnVjdGl2ZVwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwic2l6ZS00XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgPEFsZXJ0VGl0bGU+RmFsaGEgYW8gY2FycmVnYXIgbyByZWNpYm88L0FsZXJ0VGl0bGU+XG4gICAgICAgIDxBbGVydERlc2NyaXB0aW9uIGNsYXNzTmFtZT1cIm10LTIgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgIDxzcGFuPntnZXRFcnJvck1lc3NhZ2UoZXJyb3IpfTwvc3Bhbj5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgIHJlc2V0KClcbiAgICAgICAgICAgICAgdm9pZCByb3V0ZXIuaW52YWxpZGF0ZSgpXG4gICAgICAgICAgICB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxSZWZyZXNoQ3cgY2xhc3NOYW1lPVwic2l6ZS0zLjVcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgPHNwYW4+VGVudGFyIG5vdmFtZW50ZTwvc3Bhbj5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9BbGVydERlc2NyaXB0aW9uPlxuICAgICAgPC9BbGVydD5cbiAgICA8L21haW4+XG4gIClcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL3JvdXRlcy9fYXV0aGVudGljYXRlZC9vcmRlcnMuJG9yZGVySWQudHN4In0=