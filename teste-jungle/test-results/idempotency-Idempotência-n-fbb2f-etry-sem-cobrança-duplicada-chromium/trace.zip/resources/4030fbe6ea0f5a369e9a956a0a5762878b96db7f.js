import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=e9f94b2e";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-cNwuCTLA.js?v=e9f94b2e";
import { r as useIsoLayoutEffect, t as useStableCallback } from "/node_modules/.vite/deps/formatErrorMessage-BEgQI17N.js?v=e9f94b2e";
import { f as isHTMLElement, l as getWindow } from "/node_modules/.vite/deps/floating-ui.utils.dom-B45hE2lE.js?v=e9f94b2e";
import { $ as isTypeableElement, Ct as stopEvent, D as useFloatingTree, E as useFloatingParentNodeId, Et as webkit, Q as isTypeableCombobox, St as isVirtualPointerEvent, Y as getFloatingFocusElement, _t as ARROW_LEFT, gt as ARROW_DOWN, q as useValueAsRef, vt as ARROW_RIGHT, wt as jsdom, xt as isVirtualClick, yt as ARROW_UP } from "/node_modules/.vite/deps/FloatingRootStore-BMBEPfxq.js?v=e9f94b2e";
import { n as ownerDocument } from "/node_modules/.vite/deps/inertValue-DbKApsSW.js?v=e9f94b2e";
import { s as EMPTY_ARRAY } from "/node_modules/.vite/deps/useRenderElement-CvMw8z9e.js?v=e9f94b2e";
import { n as useTimeout } from "/node_modules/.vite/deps/useTimeout-w0MCIDxv.js?v=e9f94b2e";
import { l as useAnimationFrame } from "/node_modules/.vite/deps/useOpenChangeComplete-BJDlY1Cs.js?v=e9f94b2e";
import { c as useScrollLock, s as enqueueFocus } from "/node_modules/.vite/deps/useOpenInteractionType-DACsa5HR.js?v=e9f94b2e";
import { a as isElementVisible, c as activeElement, d as getTarget, i as getNextListIndex, n as getMaxListIndex, o as isIndexOutOfListBounds, r as getMinListIndex, s as isListIndexDisabled, u as contains } from "/node_modules/.vite/deps/composite-DUPI88po.js?v=e9f94b2e";
import { o as focusOut, p as listNavigation, w as createChangeEventDetails } from "/node_modules/.vite/deps/reason-parts-D-IkPsXA.js?v=e9f94b2e";
import { t as serializeValue } from "/node_modules/.vite/deps/serializeValue-DMnWa3MD.js?v=e9f94b2e";
// node_modules/@base-ui/react/floating-ui-react/hooks/useListNavigation.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function isStationaryWebKitPointer(event) {
	return webkit && event.movementX === 0 && event.movementY === 0;
}
function doSwitch(orientation, vertical, horizontal) {
	switch (orientation) {
		case "vertical": return vertical;
		case "horizontal": return horizontal;
		default: return vertical || horizontal;
	}
}
function isMainOrientationKey(key, orientation) {
	return doSwitch(orientation, key === "ArrowUp" || key === "ArrowDown", key === "ArrowLeft" || key === "ArrowRight");
}
function isMainOrientationToEndKey(key, orientation, rtl) {
	return doSwitch(orientation, key === "ArrowDown", rtl ? key === "ArrowLeft" : key === "ArrowRight") || key === "Enter" || key === " " || key === "";
}
function isCrossOrientationOpenKey(key, orientation, rtl) {
	return doSwitch(orientation, rtl ? key === ARROW_LEFT : key === ARROW_RIGHT, key === ARROW_DOWN);
}
function isCrossOrientationCloseKey(key, orientation, rtl, grid) {
	const vertical = rtl ? key === ARROW_RIGHT : key === ARROW_LEFT;
	const horizontal = key === ARROW_UP;
	if (orientation === "both" || orientation === "horizontal" && grid) return key === "Escape";
	return doSwitch(orientation, vertical, horizontal);
}
/**
* Adds arrow key-based navigation of a list of items, either using real DOM
* focus or virtual focus.
* @see https://floating-ui.com/docs/useListNavigation
*/
function useListNavigation(store, props) {
	const { listRef, activeIndex, onNavigate: onNavigateProp = () => {}, enabled = true, selectedIndex = null, allowEscape = false, loopFocus = false, nested = false, rtl = false, virtual = false, focusItemOnOpen = "auto", focusItemOnHover = true, openOnArrowKeyDown = true, disabledIndices = void 0, orientation = "vertical", triggerOrientation = orientation, parentOrientation, id, resetOnPointerLeave = true, externalTree, nestedReturnFocusRef, grid: navigateGrid } = props;
	const isGrid = navigateGrid != null;
	if (allowEscape) {
		if (!loopFocus) console.warn("`useListNavigation` looping must be enabled to allow escaping.");
		if (!virtual) console.warn("`useListNavigation` must be virtual to allow escaping.");
	}
	if (orientation === "vertical" && isGrid) console.warn("In grid list navigation mode, the `orientation` should", "be either \"horizontal\" or \"both\".");
	const open = store.useState("open");
	const floatingElement = store.useState("floatingElement");
	const domReferenceElement = store.useState("domReferenceElement");
	const dataRef = store.context.dataRef;
	const floatingFocusElement = getFloatingFocusElement(floatingElement);
	const typeableComboboxReference = isTypeableCombobox(domReferenceElement);
	const floatingFocusElementRef = useValueAsRef(floatingFocusElement);
	const parentId = useFloatingParentNodeId();
	const tree = useFloatingTree(externalTree);
	const focusItemOnOpenRef = import_react.useRef(focusItemOnOpen);
	const indexRef = import_react.useRef(selectedIndex ?? -1);
	const keyRef = import_react.useRef(null);
	const isPointerModalityRef = import_react.useRef(true);
	const onNavigate = useStableCallback((event) => {
		onNavigateProp(indexRef.current === -1 ? null : indexRef.current, event);
	});
	const previousMountedRef = import_react.useRef(!!floatingElement);
	const previousOpenRef = import_react.useRef(open);
	const forceSyncFocusRef = import_react.useRef(false);
	const forceScrollIntoViewRef = import_react.useRef(false);
	const cancelQueuedFocusRef = import_react.useRef(null);
	const disabledIndicesRef = useValueAsRef(disabledIndices);
	const latestOpenRef = useValueAsRef(open);
	const selectedIndexRef = useValueAsRef(selectedIndex);
	const resetOnPointerLeaveRef = useValueAsRef(resetOnPointerLeave);
	const focusFrame = useAnimationFrame();
	const waitForListPopulatedFrame = useAnimationFrame();
	const focusItem = useStableCallback(() => {
		focusFrame.cancel();
		function runFocus(item) {
			if (!virtual) cancelQueuedFocusRef.current = enqueueFocus(item, {
				sync: forceSyncFocusRef.current,
				preventScroll: true
			});
		}
		const initialItem = listRef.current[indexRef.current];
		const forceScrollIntoView = forceScrollIntoViewRef.current;
		if (initialItem) runFocus(initialItem);
		(forceSyncFocusRef.current ? (callback) => callback() : (callback) => focusFrame.request(callback))(() => {
			const waitedItem = listRef.current[indexRef.current] || initialItem;
			if (!waitedItem) return;
			if (!initialItem) runFocus(waitedItem);
			if (item && (forceScrollIntoView || !isPointerModalityRef.current)) waitedItem.scrollIntoView?.({
				block: "nearest",
				inline: "nearest"
			});
		});
	});
	useIsoLayoutEffect(() => {
		dataRef.current.orientation = orientation;
	}, [dataRef, orientation]);
	useIsoLayoutEffect(() => {
		if (!open) keyRef.current = null;
		if (!open || focusItemOnOpen !== "auto") focusItemOnOpenRef.current = focusItemOnOpen;
	}, [open, focusItemOnOpen]);
	useIsoLayoutEffect(() => {
		if (!enabled) return;
		if (open && floatingElement) {
			indexRef.current = selectedIndex ?? -1;
			if (focusItemOnOpenRef.current && selectedIndex != null) {
				forceScrollIntoViewRef.current = true;
				onNavigate();
			}
		} else if (previousMountedRef.current) {
			indexRef.current = -1;
			onNavigate();
		}
	}, [
		enabled,
		open,
		floatingElement,
		selectedIndex,
		onNavigate
	]);
	useIsoLayoutEffect(() => {
		if (!enabled) return;
		if (!open) {
			forceSyncFocusRef.current = false;
			return;
		}
		if (!floatingElement) return;
		if (activeIndex == null) {
			forceSyncFocusRef.current = false;
			if (selectedIndexRef.current != null) return;
			if (previousMountedRef.current) {
				indexRef.current = -1;
				focusItem();
			}
			if ((!previousOpenRef.current || !previousMountedRef.current) && focusItemOnOpenRef.current && (keyRef.current != null || focusItemOnOpenRef.current === true && keyRef.current == null)) {
				let runs = 0;
				const waitForListPopulated = () => {
					if (listRef.current[0] == null) {
						if (runs < 2) (runs ? (callback) => waitForListPopulatedFrame.request(callback) : queueMicrotask)(waitForListPopulated);
						runs += 1;
					} else {
						indexRef.current = keyRef.current == null || isMainOrientationToEndKey(keyRef.current, triggerOrientation, rtl) || nested ? getMinListIndex(listRef) : getMaxListIndex(listRef);
						keyRef.current = null;
						onNavigate();
					}
				};
				waitForListPopulated();
			}
		} else if (!isIndexOutOfListBounds(listRef.current, activeIndex)) {
			indexRef.current = activeIndex;
			focusItem();
			forceScrollIntoViewRef.current = false;
		}
	}, [
		enabled,
		open,
		floatingElement,
		activeIndex,
		selectedIndexRef,
		nested,
		listRef,
		triggerOrientation,
		rtl,
		onNavigate,
		focusItem,
		waitForListPopulatedFrame
	]);
	useIsoLayoutEffect(() => {
		if (!enabled || floatingElement || !tree || virtual || !previousMountedRef.current) return;
		const nodes = tree.nodesRef.current;
		const parent = nodes.find((node) => node.id === parentId)?.context?.elements.floating;
		const activeEl = activeElement(ownerDocument(domReferenceElement ?? parent ?? null));
		const treeContainsActiveEl = nodes.some((node) => node.context && contains(node.context.elements.floating, activeEl));
		if (parent && !treeContainsActiveEl && isPointerModalityRef.current) parent.focus({ preventScroll: true });
	}, [
		enabled,
		floatingElement,
		domReferenceElement,
		tree,
		parentId,
		virtual
	]);
	useIsoLayoutEffect(() => {
		previousOpenRef.current = open;
		previousMountedRef.current = !!floatingElement;
	});
	const hasActiveIndex = activeIndex != null;
	const syncCurrentTarget = useStableCallback((event) => {
		if (!latestOpenRef.current) return;
		const index = listRef.current.indexOf(event.currentTarget);
		if (index !== -1 && (indexRef.current !== index || activeIndex !== index)) {
			indexRef.current = index;
			onNavigate(event);
		}
	});
	const getParentOrientation = useStableCallback(() => {
		return parentOrientation ?? tree?.nodesRef.current.find((node) => node.id === parentId)?.context?.dataRef?.current.orientation;
	});
	const getMinEnabledIndex = useStableCallback(() => {
		return getMinListIndex(listRef, disabledIndicesRef.current);
	});
	const commonOnKeyDown = useStableCallback((event) => {
		isPointerModalityRef.current = false;
		forceSyncFocusRef.current = true;
		if (event.which === 229) return;
		if (!latestOpenRef.current && event.currentTarget === floatingFocusElementRef.current) return;
		if (nested && isCrossOrientationCloseKey(event.key, orientation, rtl, isGrid)) {
			if (!isMainOrientationKey(event.key, getParentOrientation())) stopEvent(event);
			store.setOpen(false, createChangeEventDetails(listNavigation, event.nativeEvent));
			const returnElement = nestedReturnFocusRef?.current ?? domReferenceElement;
			if (isHTMLElement(returnElement)) returnElement.focus();
			return;
		}
		if (activeIndex != null && activeIndex !== indexRef.current && !isIndexOutOfListBounds(listRef.current, activeIndex)) indexRef.current = activeIndex;
		const currentIndex = indexRef.current;
		const minIndex = getMinListIndex(listRef, disabledIndices);
		const maxIndex = getMaxListIndex(listRef, disabledIndices);
		if (!typeableComboboxReference) {
			if (event.key === "Home") {
				stopEvent(event);
				indexRef.current = minIndex;
				onNavigate(event);
			}
			if (event.key === "End") {
				stopEvent(event);
				indexRef.current = maxIndex;
				onNavigate(event);
			}
		}
		if (navigateGrid != null) {
			const index = navigateGrid(event, indexRef.current, listRef, orientation, loopFocus, rtl, disabledIndices, minIndex, maxIndex);
			if (index != null && index !== indexRef.current) {
				indexRef.current = index;
				onNavigate(event);
			}
			if (orientation === "both") return;
		}
		if (isMainOrientationKey(event.key, orientation)) {
			stopEvent(event);
			const focusedElement = activeElement(event.currentTarget.ownerDocument);
			if (open && !virtual && contains(event.currentTarget, focusedElement) && !listRef.current.some((item) => item != null && contains(item, focusedElement))) {
				indexRef.current = isMainOrientationToEndKey(event.key, orientation, rtl) ? minIndex : maxIndex;
				onNavigate(event);
				if (activeIndex === indexRef.current) focusItem();
				return;
			}
			const { index, wrapped } = getNextListIndex(listRef.current, currentIndex, {
				decrement: !isMainOrientationToEndKey(event.key, orientation, rtl),
				loopFocus,
				allowEscape,
				disabledIndices,
				minIndex,
				maxIndex
			});
			if (wrapped) forceSyncFocusRef.current = false;
			indexRef.current = index;
			onNavigate(event);
		}
	});
	const item = import_react.useMemo(() => {
		return {
			onFocus(event) {
				forceSyncFocusRef.current = true;
				syncCurrentTarget(event);
			},
			onClick({ currentTarget }) {
				if (!virtual) currentTarget.focus({ preventScroll: true });
			},
			onMouseMove(event) {
				if (isStationaryWebKitPointer(event)) return;
				forceSyncFocusRef.current = true;
				forceScrollIntoViewRef.current = false;
				if (focusItemOnHover) syncCurrentTarget(event);
			},
			onPointerLeave(event) {
				if (!latestOpenRef.current || !isPointerModalityRef.current || event.pointerType === "touch") return;
				forceSyncFocusRef.current = true;
				const relatedTarget = event.relatedTarget;
				if (!focusItemOnHover || listRef.current.includes(relatedTarget)) return;
				if (!resetOnPointerLeaveRef.current) return;
				cancelQueuedFocusRef.current?.();
				cancelQueuedFocusRef.current = null;
				indexRef.current = -1;
				onNavigate(event);
				if (!virtual) {
					const floatingFocusEl = floatingFocusElementRef.current;
					const activeEl = activeElement(ownerDocument(floatingFocusEl));
					if (floatingFocusEl && contains(floatingFocusEl, activeEl)) floatingFocusEl.focus({ preventScroll: true });
				}
			}
		};
	}, [
		syncCurrentTarget,
		latestOpenRef,
		floatingFocusElementRef,
		focusItemOnHover,
		listRef,
		onNavigate,
		resetOnPointerLeaveRef,
		virtual
	]);
	const ariaActiveDescendantProp = import_react.useMemo(() => {
		return virtual && open && hasActiveIndex && { "aria-activedescendant": `${id}-${activeIndex}` };
	}, [
		virtual,
		open,
		hasActiveIndex,
		id,
		activeIndex
	]);
	const floating = import_react.useMemo(() => {
		return {
			...!typeableComboboxReference ? ariaActiveDescendantProp : {},
			onKeyDown(event) {
				if (event.key === "Tab" && event.shiftKey && open && !virtual) {
					const target = getTarget(event.nativeEvent);
					if (target && !contains(floatingFocusElementRef.current, target)) return;
					stopEvent(event);
					const details = createChangeEventDetails(focusOut, event.nativeEvent);
					store.setOpen(false, details);
					const returnElement = nestedReturnFocusRef?.current ?? domReferenceElement;
					if (!details.isCanceled && isHTMLElement(returnElement)) returnElement.focus();
					return;
				}
				commonOnKeyDown(event);
			},
			onPointerMove(event) {
				if (isStationaryWebKitPointer(event)) return;
				isPointerModalityRef.current = true;
			}
		};
	}, [
		ariaActiveDescendantProp,
		commonOnKeyDown,
		floatingFocusElementRef,
		typeableComboboxReference,
		store,
		open,
		virtual,
		domReferenceElement,
		nestedReturnFocusRef
	]);
	const trigger = import_react.useMemo(() => {
		function openOnNavigationKeyDown(event) {
			store.setOpen(true, createChangeEventDetails(listNavigation, event.nativeEvent, event.currentTarget));
		}
		function checkVirtualMouse(event) {
			if (focusItemOnOpen === "auto" && isVirtualClick(event.nativeEvent)) focusItemOnOpenRef.current = !virtual;
		}
		function checkVirtualPointer(event) {
			focusItemOnOpenRef.current = focusItemOnOpen;
			if (focusItemOnOpen === "auto" && isVirtualPointerEvent(event.nativeEvent)) focusItemOnOpenRef.current = true;
		}
		return {
			onKeyDown(event) {
				const currentOpen = store.select("open");
				isPointerModalityRef.current = false;
				const isArrowKey = event.key.startsWith("Arrow");
				const isParentCrossOpenKey = isCrossOrientationOpenKey(event.key, getParentOrientation(), rtl);
				const isMainKey = isMainOrientationKey(event.key, currentOpen ? orientation : triggerOrientation);
				const isNavigationKey = (nested ? isParentCrossOpenKey : isMainKey) || event.key === "Enter" || event.key.trim() === "";
				if (virtual && currentOpen && (!nested || isTypeableElement(event.currentTarget))) return commonOnKeyDown(event);
				if (!currentOpen && !openOnArrowKeyDown && isArrowKey) return;
				if (isNavigationKey) {
					const isParentMainKey = isMainOrientationKey(event.key, getParentOrientation());
					keyRef.current = nested && isParentMainKey ? null : event.key;
				}
				if (nested) {
					if (isParentCrossOpenKey) {
						stopEvent(event);
						if (currentOpen) {
							indexRef.current = getMinEnabledIndex();
							onNavigate(event);
							if (virtual) floatingFocusElementRef.current?.focus();
						} else openOnNavigationKeyDown(event);
					}
					return;
				}
				if (isMainKey) {
					if (selectedIndexRef.current != null) indexRef.current = selectedIndexRef.current;
					stopEvent(event);
					if (!currentOpen && openOnArrowKeyDown) openOnNavigationKeyDown(event);
					else commonOnKeyDown(event);
					if (currentOpen) onNavigate(event);
				}
			},
			onFocus(event) {
				if (event.target !== event.currentTarget) return;
				if (store.select("open") && !virtual) {
					indexRef.current = -1;
					onNavigate(event);
				}
			},
			onPointerDown: checkVirtualPointer,
			onPointerEnter: checkVirtualPointer,
			onMouseDown: checkVirtualMouse,
			onClick: checkVirtualMouse
		};
	}, [
		commonOnKeyDown,
		focusItemOnOpen,
		getMinEnabledIndex,
		nested,
		onNavigate,
		store,
		openOnArrowKeyDown,
		orientation,
		triggerOrientation,
		getParentOrientation,
		rtl,
		selectedIndexRef,
		virtual,
		floatingFocusElementRef
	]);
	const reference = import_react.useMemo(() => {
		return {
			...ariaActiveDescendantProp,
			...trigger
		};
	}, [ariaActiveDescendantProp, trigger]);
	return import_react.useMemo(() => enabled ? {
		reference,
		floating,
		item,
		trigger
	} : {}, [
		enabled,
		reference,
		floating,
		trigger,
		item
	]);
}
// node_modules/@base-ui/react/floating-ui-react/hooks/useTypeahead.mjs
/**
* Provides a matching callback that can be used to focus an item as the user
* types, often used in tandem with `useListNavigation()`.
* @see https://floating-ui.com/docs/useTypeahead
*/
function useTypeahead(store, props) {
	const { listRef, elementsRef, activeIndex, onMatch: onMatchProp, disabledIndices, onTyping: onTypingProp, enabled = true, resetMs = 750, selectedIndex = null } = props;
	const onTyping = useStableCallback(onTypingProp);
	const open = store.useState("open");
	const timeout = useTimeout();
	const stringRef = import_react.useRef("");
	const prevIndexRef = import_react.useRef(selectedIndex ?? activeIndex ?? -1);
	const matchIndexRef = import_react.useRef(null);
	const onKeyDown = useStableCallback((event) => {
		function getElement(index) {
			return elementsRef?.current[index];
		}
		function isItemAvailable(index) {
			const element = getElement(index);
			if (element && !isElementVisible(element) || element?.matches(":disabled")) return false;
			return disabledIndices == null || !isListIndexDisabled(EMPTY_ARRAY, index, disabledIndices);
		}
		function getMatchingIndex(list, string, startIndex = 0) {
			if (list.length === 0) return -1;
			const normalizedStartIndex = (startIndex % list.length + list.length) % list.length;
			const lowerString = string.toLowerCase();
			for (let offset = 0; offset < list.length; offset += 1) {
				const index = (normalizedStartIndex + offset) % list.length;
				if (!list[index]?.toLowerCase().startsWith(lowerString) || !isItemAvailable(index)) continue;
				return index;
			}
			return -1;
		}
		const listContent = listRef.current;
		if (stringRef.current.length > 0 && event.key === " ") {
			stopEvent(event);
			onTyping?.(true);
		}
		if (stringRef.current.length > 0 && stringRef.current[0] !== " ") {
			if (getMatchingIndex(listContent, stringRef.current) === -1 && event.key !== " ") onTyping?.(false);
		}
		if (listContent == null || event.key.length !== 1 || event.ctrlKey || event.metaKey || event.altKey) return;
		if (open && event.key !== " ") {
			stopEvent(event);
			onTyping?.(true);
		}
		const isNewSession = stringRef.current === "";
		if (isNewSession) prevIndexRef.current = selectedIndex ?? activeIndex ?? -1;
		if (listContent.every((text, index) => text && isItemAvailable(index) ? text[0]?.toLowerCase() !== text[1]?.toLowerCase() : true) && stringRef.current === event.key) {
			stringRef.current = "";
			prevIndexRef.current = matchIndexRef.current;
		}
		stringRef.current += event.key;
		timeout.start(resetMs, () => {
			stringRef.current = "";
			prevIndexRef.current = matchIndexRef.current;
			onTyping?.(false);
		});
		const startIndex = ((isNewSession ? selectedIndex ?? activeIndex ?? -1 : prevIndexRef.current) ?? 0) + 1;
		const index = getMatchingIndex(listContent, stringRef.current, startIndex);
		if (index !== -1) {
			onMatchProp?.(index, event);
			matchIndexRef.current = index;
		} else if (event.key !== " ") {
			stringRef.current = "";
			onTyping?.(false);
		}
	});
	const onBlur = useStableCallback((event) => {
		const next = event.relatedTarget;
		const currentDomReferenceElement = store.select("domReferenceElement");
		const currentFloatingElement = store.select("floatingElement");
		if (contains(currentDomReferenceElement, next) || contains(currentFloatingElement, next)) return;
		timeout.clear();
		stringRef.current = "";
		prevIndexRef.current = matchIndexRef.current;
		onTyping?.(false);
	});
	useIsoLayoutEffect(() => {
		if (!open && selectedIndex !== null) return;
		timeout.clear();
		matchIndexRef.current = null;
		if (stringRef.current !== "") {
			stringRef.current = "";
			onTyping?.(false);
		}
	}, [
		open,
		selectedIndex,
		timeout,
		onTyping
	]);
	const sharedProps = import_react.useMemo(() => ({
		onKeyDown,
		onBlur
	}), [onKeyDown, onBlur]);
	return import_react.useMemo(() => enabled ? {
		reference: sharedProps,
		floating: sharedProps
	} : {}, [enabled, sharedProps]);
}
// node_modules/@base-ui/react/toolbar/root/ToolbarRootContext.mjs
var ToolbarRootContext = /*#__PURE__*/ import_react.createContext(void 0);
ToolbarRootContext.displayName = "ToolbarRootContext";
function useToolbarRootContext(optional) {
	const context = import_react.useContext(ToolbarRootContext);
	if (context === void 0 && !optional) throw new Error("Base UI: ToolbarRootContext is missing. Toolbar parts must be placed within <Toolbar.Root>.");
	return context;
}
// node_modules/@base-ui/react/utils/useAnchoredPopupScrollLock.mjs
var VIEWPORT_WIDTH_TOLERANCE_PX = 20;
/**
* Manages scroll lock for anchored popups. For non-touch opens, scroll lock is applied when
* enabled. For touch opens, scroll lock is applied only when the positioner width is effectively
* viewport-sized.
*/
function useAnchoredPopupScrollLock(enabled, touchOpen, positionerElement, referenceElement) {
	const [touchOpenShouldLockScroll, setTouchOpenShouldLockScroll] = import_react.useState(false);
	useIsoLayoutEffect(() => {
		if (!enabled || !touchOpen || positionerElement == null) {
			setTouchOpenShouldLockScroll(false);
			return;
		}
		const viewportWidth = ownerDocument(positionerElement).documentElement.clientWidth;
		const popupWidth = positionerElement.offsetWidth;
		setTouchOpenShouldLockScroll(viewportWidth > 0 && popupWidth > 0 && popupWidth >= viewportWidth - VIEWPORT_WIDTH_TOLERANCE_PX);
	}, [
		enabled,
		touchOpen,
		positionerElement
	]);
	useScrollLock(enabled && (!touchOpen || touchOpenShouldLockScroll), referenceElement);
}
// node_modules/@base-ui/react/utils/getPseudoElementBounds.mjs
var BOUNDARY_OFFSET = 5;
/**
* Determines if a mouse event occurred within the bounds of an element
* (including its pseudo-elements), with a small tolerance for pointer drift.
*/
function isMouseWithinBounds(event, element) {
	const bounds = getPseudoElementBounds(element);
	return event.clientX >= bounds.left - BOUNDARY_OFFSET && event.clientX <= bounds.right + BOUNDARY_OFFSET && event.clientY >= bounds.top - BOUNDARY_OFFSET && event.clientY <= bounds.bottom + BOUNDARY_OFFSET;
}
function getPseudoElementBounds(element) {
	const elementRect = element.getBoundingClientRect();
	const win = getWindow(element);
	if (jsdom) return elementRect;
	const beforeStyles = win.getComputedStyle(element, "::before");
	const afterStyles = win.getComputedStyle(element, "::after");
	if (!(beforeStyles.content !== "none" || afterStyles.content !== "none")) return elementRect;
	const beforeWidth = parseFloat(beforeStyles.width) || 0;
	const beforeHeight = parseFloat(beforeStyles.height) || 0;
	const afterWidth = parseFloat(afterStyles.width) || 0;
	const afterHeight = parseFloat(afterStyles.height) || 0;
	const totalWidth = Math.max(elementRect.width, beforeWidth, afterWidth);
	const totalHeight = Math.max(elementRect.height, beforeHeight, afterHeight);
	const widthDiff = totalWidth - elementRect.width;
	const heightDiff = totalHeight - elementRect.height;
	return {
		left: elementRect.left - widthDiff / 2,
		right: elementRect.right + widthDiff / 2,
		top: elementRect.top - heightDiff / 2,
		bottom: elementRect.bottom + heightDiff / 2
	};
}
// node_modules/@base-ui/react/internals/resolveValueLabel.mjs
var import_jsx_runtime = require_jsx_runtime();
function isGroup(item) {
	return typeof item === "object" && item != null && Array.isArray(item.items);
}
function isGroupedItems(items) {
	return isGroup(items?.[0]);
}
function flattenLeafItems(items) {
	return isGroupedItems(items) ? items.flatMap((group) => group.items) : items;
}
/**
* Checks if the items array contains an item with a null value that has a non-null label.
*/
function hasNullItemLabel(items) {
	if (!Array.isArray(items)) return items != null && "null" in items;
	const arrayItems = items;
	if (isGroupedItems(arrayItems)) {
		for (const group of arrayItems) for (const item of group.items) if (item && item.value == null && item.label != null) return true;
		return false;
	}
	for (const item of arrayItems) if (item && item.value == null && item.label != null) return true;
	return false;
}
function stringifyAsLabel(item, itemToStringLabel) {
	if (itemToStringLabel && item != null) return itemToStringLabel(item) ?? "";
	if (item && typeof item === "object") {
		if ("label" in item && item.label != null) return String(item.label);
		if ("value" in item) return String(item.value);
	}
	return serializeValue(item);
}
function stringifyAsValue(item, itemToStringValue) {
	if (itemToStringValue && item != null) return itemToStringValue(item) ?? "";
	if (item && typeof item === "object" && "value" in item && "label" in item) return serializeValue(item.value);
	return serializeValue(item);
}
function resolveSelectedLabel(value, items, itemToStringLabel) {
	function fallback() {
		return stringifyAsLabel(value, itemToStringLabel);
	}
	if (itemToStringLabel && value != null) return itemToStringLabel(value);
	if (value && typeof value === "object" && "label" in value && value.label != null) return value.label;
	if (items && !Array.isArray(items)) return (Object.hasOwn(items, value) ? items[value] : void 0) ?? fallback();
	if (Array.isArray(items)) {
		const flatItems = flattenLeafItems(items);
		if (value == null || typeof value !== "object") {
			const match = flatItems.find((item) => item.value === value);
			if (match && match.label != null) return match.label;
			return fallback();
		}
		if ("value" in value) {
			const match = flatItems.find((item) => item && item.value === value.value);
			if (match && match.label != null) return match.label;
		}
	}
	return fallback();
}
function resolveMultipleLabels(values, items, itemToStringLabel) {
	return values.reduce((acc, value, index) => {
		if (index > 0) acc.push(", ");
		acc.push(/*#__PURE__*/ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: resolveSelectedLabel(value, items, itemToStringLabel) }, index));
		return acc;
	}, []);
}
export { stringifyAsValue as a, useToolbarRootContext as c, isCrossOrientationOpenKey as d, isMainOrientationKey as f, stringifyAsLabel as i, useTypeahead as l, useListNavigation as m, resolveMultipleLabels as n, isMouseWithinBounds as o, isMainOrientationToEndKey as p, resolveSelectedLabel as r, useAnchoredPopupScrollLock as s, hasNullItemLabel as t, isCrossOrientationCloseKey as u };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVzb2x2ZVZhbHVlTGFiZWwtQmdabFhaUHcuanMiLCJuYW1lcyI6WyJwbGF0Zm9ybS5lbmdpbmUud2Via2l0IiwiUkVBU09OUy5saXN0TmF2aWdhdGlvbiIsIlJFQVNPTlMuZm9jdXNPdXQiLCJvd25lcldpbmRvdyIsInBsYXRmb3JtLmVudi5qc2RvbSIsImFycmF5SXRlbXMiXSwic291cmNlcyI6WyIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC9ob29rcy91c2VMaXN0TmF2aWdhdGlvbi5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC9ob29rcy91c2VUeXBlYWhlYWQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdG9vbGJhci9yb290L1Rvb2xiYXJSb290Q29udGV4dC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy91c2VBbmNob3JlZFBvcHVwU2Nyb2xsTG9jay5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9nZXRQc2V1ZG9FbGVtZW50Qm91bmRzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2ludGVybmFscy9yZXNvbHZlVmFsdWVMYWJlbC5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VBbmltYXRpb25GcmFtZSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUFuaW1hdGlvbkZyYW1lJztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyBvd25lckRvY3VtZW50IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvb3duZXInO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyB1c2VWYWx1ZUFzUmVmIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlVmFsdWVBc1JlZic7XG5pbXBvcnQgeyBwbGF0Zm9ybSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtJztcbmltcG9ydCB7IGlzSFRNTEVsZW1lbnQgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY3JlYXRlQmFzZVVJRXZlbnREZXRhaWxzLm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcbmltcG9ydCB7IHVzZUZsb2F0aW5nUGFyZW50Tm9kZUlkLCB1c2VGbG9hdGluZ1RyZWUgfSBmcm9tIFwiLi4vY29tcG9uZW50cy9GbG9hdGluZ1RyZWUubWpzXCI7XG5pbXBvcnQgeyBnZXRNYXhMaXN0SW5kZXgsIGdldE1pbkxpc3RJbmRleCwgZ2V0TmV4dExpc3RJbmRleCwgaXNJbmRleE91dE9mTGlzdEJvdW5kcyB9IGZyb20gXCIuLi91dGlscy9jb21wb3NpdGUubWpzXCI7XG5pbXBvcnQgeyBBUlJPV19ET1dOLCBBUlJPV19MRUZULCBBUlJPV19SSUdIVCwgQVJST1dfVVAgfSBmcm9tIFwiLi4vdXRpbHMvY29uc3RhbnRzLm1qc1wiO1xuaW1wb3J0IHsgYWN0aXZlRWxlbWVudCwgY29udGFpbnMsIGdldEZsb2F0aW5nRm9jdXNFbGVtZW50LCBnZXRUYXJnZXQsIGlzVHlwZWFibGVDb21ib2JveCwgaXNUeXBlYWJsZUVsZW1lbnQgfSBmcm9tIFwiLi4vdXRpbHMvZWxlbWVudC5tanNcIjtcbmltcG9ydCB7IGVucXVldWVGb2N1cyB9IGZyb20gXCIuLi91dGlscy9lbnF1ZXVlRm9jdXMubWpzXCI7XG5pbXBvcnQgeyBpc1ZpcnR1YWxDbGljaywgaXNWaXJ0dWFsUG9pbnRlckV2ZW50LCBzdG9wRXZlbnQgfSBmcm9tIFwiLi4vdXRpbHMvZXZlbnQubWpzXCI7XG5cbi8vIFdlYktpdCBmaXJlcyB6ZXJvLWRlbHRhIGBtb3VzZW1vdmVgL2Bwb2ludGVybW92ZWAgZXZlbnRzIHdoZW4gdGhlIGxpc3Qgc2Nyb2xsc1xuLy8gYmVuZWF0aCBhIHN0YXRpb25hcnkgcG9pbnRlciwgbW92aW5nIHRoZSBoaWdobGlnaHQgZHVyaW5nIGtleWJvYXJkIG5hdmlnYXRpb24uXG4vLyBodHRwczovL2dpdGh1Yi5jb20vbXVpL2Jhc2UtdWkvaXNzdWVzLzQwMDJcbmZ1bmN0aW9uIGlzU3RhdGlvbmFyeVdlYktpdFBvaW50ZXIoZXZlbnQpIHtcbiAgcmV0dXJuIHBsYXRmb3JtLmVuZ2luZS53ZWJraXQgJiYgZXZlbnQubW92ZW1lbnRYID09PSAwICYmIGV2ZW50Lm1vdmVtZW50WSA9PT0gMDtcbn1cbmZ1bmN0aW9uIGRvU3dpdGNoKG9yaWVudGF0aW9uLCB2ZXJ0aWNhbCwgaG9yaXpvbnRhbCkge1xuICBzd2l0Y2ggKG9yaWVudGF0aW9uKSB7XG4gICAgY2FzZSAndmVydGljYWwnOlxuICAgICAgcmV0dXJuIHZlcnRpY2FsO1xuICAgIGNhc2UgJ2hvcml6b250YWwnOlxuICAgICAgcmV0dXJuIGhvcml6b250YWw7XG4gICAgZGVmYXVsdDpcbiAgICAgIHJldHVybiB2ZXJ0aWNhbCB8fCBob3Jpem9udGFsO1xuICB9XG59XG5leHBvcnQgZnVuY3Rpb24gaXNNYWluT3JpZW50YXRpb25LZXkoa2V5LCBvcmllbnRhdGlvbikge1xuICBjb25zdCB2ZXJ0aWNhbCA9IGtleSA9PT0gQVJST1dfVVAgfHwga2V5ID09PSBBUlJPV19ET1dOO1xuICBjb25zdCBob3Jpem9udGFsID0ga2V5ID09PSBBUlJPV19MRUZUIHx8IGtleSA9PT0gQVJST1dfUklHSFQ7XG4gIHJldHVybiBkb1N3aXRjaChvcmllbnRhdGlvbiwgdmVydGljYWwsIGhvcml6b250YWwpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzTWFpbk9yaWVudGF0aW9uVG9FbmRLZXkoa2V5LCBvcmllbnRhdGlvbiwgcnRsKSB7XG4gIGNvbnN0IHZlcnRpY2FsID0ga2V5ID09PSBBUlJPV19ET1dOO1xuICBjb25zdCBob3Jpem9udGFsID0gcnRsID8ga2V5ID09PSBBUlJPV19MRUZUIDoga2V5ID09PSBBUlJPV19SSUdIVDtcbiAgcmV0dXJuIGRvU3dpdGNoKG9yaWVudGF0aW9uLCB2ZXJ0aWNhbCwgaG9yaXpvbnRhbCkgfHwga2V5ID09PSAnRW50ZXInIHx8IGtleSA9PT0gJyAnIHx8IGtleSA9PT0gJyc7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNDcm9zc09yaWVudGF0aW9uT3BlbktleShrZXksIG9yaWVudGF0aW9uLCBydGwpIHtcbiAgY29uc3QgdmVydGljYWwgPSBydGwgPyBrZXkgPT09IEFSUk9XX0xFRlQgOiBrZXkgPT09IEFSUk9XX1JJR0hUO1xuICBjb25zdCBob3Jpem9udGFsID0ga2V5ID09PSBBUlJPV19ET1dOO1xuICByZXR1cm4gZG9Td2l0Y2gob3JpZW50YXRpb24sIHZlcnRpY2FsLCBob3Jpem9udGFsKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0Nyb3NzT3JpZW50YXRpb25DbG9zZUtleShrZXksIG9yaWVudGF0aW9uLCBydGwsIGdyaWQpIHtcbiAgY29uc3QgdmVydGljYWwgPSBydGwgPyBrZXkgPT09IEFSUk9XX1JJR0hUIDoga2V5ID09PSBBUlJPV19MRUZUO1xuICBjb25zdCBob3Jpem9udGFsID0ga2V5ID09PSBBUlJPV19VUDtcbiAgaWYgKG9yaWVudGF0aW9uID09PSAnYm90aCcgfHwgb3JpZW50YXRpb24gPT09ICdob3Jpem9udGFsJyAmJiBncmlkKSB7XG4gICAgcmV0dXJuIGtleSA9PT0gJ0VzY2FwZSc7XG4gIH1cbiAgcmV0dXJuIGRvU3dpdGNoKG9yaWVudGF0aW9uLCB2ZXJ0aWNhbCwgaG9yaXpvbnRhbCk7XG59XG4vKipcbiAqIEFkZHMgYXJyb3cga2V5LWJhc2VkIG5hdmlnYXRpb24gb2YgYSBsaXN0IG9mIGl0ZW1zLCBlaXRoZXIgdXNpbmcgcmVhbCBET01cbiAqIGZvY3VzIG9yIHZpcnR1YWwgZm9jdXMuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlTGlzdE5hdmlnYXRpb25cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUxpc3ROYXZpZ2F0aW9uKHN0b3JlLCBwcm9wcykge1xuICBjb25zdCB7XG4gICAgbGlzdFJlZixcbiAgICBhY3RpdmVJbmRleCxcbiAgICBvbk5hdmlnYXRlOiBvbk5hdmlnYXRlUHJvcCA9ICgpID0+IHt9LFxuICAgIGVuYWJsZWQgPSB0cnVlLFxuICAgIHNlbGVjdGVkSW5kZXggPSBudWxsLFxuICAgIGFsbG93RXNjYXBlID0gZmFsc2UsXG4gICAgbG9vcEZvY3VzID0gZmFsc2UsXG4gICAgbmVzdGVkID0gZmFsc2UsXG4gICAgcnRsID0gZmFsc2UsXG4gICAgdmlydHVhbCA9IGZhbHNlLFxuICAgIGZvY3VzSXRlbU9uT3BlbiA9ICdhdXRvJyxcbiAgICBmb2N1c0l0ZW1PbkhvdmVyID0gdHJ1ZSxcbiAgICBvcGVuT25BcnJvd0tleURvd24gPSB0cnVlLFxuICAgIGRpc2FibGVkSW5kaWNlcyA9IHVuZGVmaW5lZCxcbiAgICBvcmllbnRhdGlvbiA9ICd2ZXJ0aWNhbCcsXG4gICAgdHJpZ2dlck9yaWVudGF0aW9uID0gb3JpZW50YXRpb24sXG4gICAgcGFyZW50T3JpZW50YXRpb24sXG4gICAgaWQsXG4gICAgcmVzZXRPblBvaW50ZXJMZWF2ZSA9IHRydWUsXG4gICAgZXh0ZXJuYWxUcmVlLFxuICAgIG5lc3RlZFJldHVybkZvY3VzUmVmLFxuICAgIGdyaWQ6IG5hdmlnYXRlR3JpZFxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IGlzR3JpZCA9IG5hdmlnYXRlR3JpZCAhPSBudWxsO1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIGlmIChhbGxvd0VzY2FwZSkge1xuICAgICAgaWYgKCFsb29wRm9jdXMpIHtcbiAgICAgICAgY29uc29sZS53YXJuKCdgdXNlTGlzdE5hdmlnYXRpb25gIGxvb3BpbmcgbXVzdCBiZSBlbmFibGVkIHRvIGFsbG93IGVzY2FwaW5nLicpO1xuICAgICAgfVxuICAgICAgaWYgKCF2aXJ0dWFsKSB7XG4gICAgICAgIGNvbnNvbGUud2FybignYHVzZUxpc3ROYXZpZ2F0aW9uYCBtdXN0IGJlIHZpcnR1YWwgdG8gYWxsb3cgZXNjYXBpbmcuJyk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChvcmllbnRhdGlvbiA9PT0gJ3ZlcnRpY2FsJyAmJiBpc0dyaWQpIHtcbiAgICAgIGNvbnNvbGUud2FybignSW4gZ3JpZCBsaXN0IG5hdmlnYXRpb24gbW9kZSwgdGhlIGBvcmllbnRhdGlvbmAgc2hvdWxkJywgJ2JlIGVpdGhlciBcImhvcml6b250YWxcIiBvciBcImJvdGhcIi4nKTtcbiAgICB9XG4gIH1cbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IGZsb2F0aW5nRWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlKCdmbG9hdGluZ0VsZW1lbnQnKTtcbiAgY29uc3QgZG9tUmVmZXJlbmNlRWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlKCdkb21SZWZlcmVuY2VFbGVtZW50Jyk7XG4gIGNvbnN0IGRhdGFSZWYgPSBzdG9yZS5jb250ZXh0LmRhdGFSZWY7XG4gIGNvbnN0IGZsb2F0aW5nRm9jdXNFbGVtZW50ID0gZ2V0RmxvYXRpbmdGb2N1c0VsZW1lbnQoZmxvYXRpbmdFbGVtZW50KTtcbiAgY29uc3QgdHlwZWFibGVDb21ib2JveFJlZmVyZW5jZSA9IGlzVHlwZWFibGVDb21ib2JveChkb21SZWZlcmVuY2VFbGVtZW50KTtcbiAgY29uc3QgZmxvYXRpbmdGb2N1c0VsZW1lbnRSZWYgPSB1c2VWYWx1ZUFzUmVmKGZsb2F0aW5nRm9jdXNFbGVtZW50KTtcbiAgY29uc3QgcGFyZW50SWQgPSB1c2VGbG9hdGluZ1BhcmVudE5vZGVJZCgpO1xuICBjb25zdCB0cmVlID0gdXNlRmxvYXRpbmdUcmVlKGV4dGVybmFsVHJlZSk7XG4gIGNvbnN0IGZvY3VzSXRlbU9uT3BlblJlZiA9IFJlYWN0LnVzZVJlZihmb2N1c0l0ZW1Pbk9wZW4pO1xuICBjb25zdCBpbmRleFJlZiA9IFJlYWN0LnVzZVJlZihzZWxlY3RlZEluZGV4ID8/IC0xKTtcbiAgY29uc3Qga2V5UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBpc1BvaW50ZXJNb2RhbGl0eVJlZiA9IFJlYWN0LnVzZVJlZih0cnVlKTtcbiAgY29uc3Qgb25OYXZpZ2F0ZSA9IHVzZVN0YWJsZUNhbGxiYWNrKGV2ZW50ID0+IHtcbiAgICBvbk5hdmlnYXRlUHJvcChpbmRleFJlZi5jdXJyZW50ID09PSAtMSA/IG51bGwgOiBpbmRleFJlZi5jdXJyZW50LCBldmVudCk7XG4gIH0pO1xuICBjb25zdCBwcmV2aW91c01vdW50ZWRSZWYgPSBSZWFjdC51c2VSZWYoISFmbG9hdGluZ0VsZW1lbnQpO1xuICBjb25zdCBwcmV2aW91c09wZW5SZWYgPSBSZWFjdC51c2VSZWYob3Blbik7XG4gIGNvbnN0IGZvcmNlU3luY0ZvY3VzUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgZm9yY2VTY3JvbGxJbnRvVmlld1JlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IGNhbmNlbFF1ZXVlZEZvY3VzUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBkaXNhYmxlZEluZGljZXNSZWYgPSB1c2VWYWx1ZUFzUmVmKGRpc2FibGVkSW5kaWNlcyk7XG4gIGNvbnN0IGxhdGVzdE9wZW5SZWYgPSB1c2VWYWx1ZUFzUmVmKG9wZW4pO1xuICBjb25zdCBzZWxlY3RlZEluZGV4UmVmID0gdXNlVmFsdWVBc1JlZihzZWxlY3RlZEluZGV4KTtcbiAgY29uc3QgcmVzZXRPblBvaW50ZXJMZWF2ZVJlZiA9IHVzZVZhbHVlQXNSZWYocmVzZXRPblBvaW50ZXJMZWF2ZSk7XG4gIGNvbnN0IGZvY3VzRnJhbWUgPSB1c2VBbmltYXRpb25GcmFtZSgpO1xuICBjb25zdCB3YWl0Rm9yTGlzdFBvcHVsYXRlZEZyYW1lID0gdXNlQW5pbWF0aW9uRnJhbWUoKTtcbiAgY29uc3QgZm9jdXNJdGVtID0gdXNlU3RhYmxlQ2FsbGJhY2soKCkgPT4ge1xuICAgIC8vIFN5bmNocm9ub3VzIG5hdmlnYXRpb24gbXVzdCBhbHNvIHN1cGVyc2VkZSBhbnkgZGVmZXJyZWQgZm9jdXMgZnJvbSBhbiBlYXJsaWVyIHVwZGF0ZS5cbiAgICBmb2N1c0ZyYW1lLmNhbmNlbCgpO1xuICAgIGZ1bmN0aW9uIHJ1bkZvY3VzKGl0ZW0pIHtcbiAgICAgIGlmICghdmlydHVhbCkge1xuICAgICAgICBjYW5jZWxRdWV1ZWRGb2N1c1JlZi5jdXJyZW50ID0gZW5xdWV1ZUZvY3VzKGl0ZW0sIHtcbiAgICAgICAgICBzeW5jOiBmb3JjZVN5bmNGb2N1c1JlZi5jdXJyZW50LFxuICAgICAgICAgIHByZXZlbnRTY3JvbGw6IHRydWVcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGluaXRpYWxJdGVtID0gbGlzdFJlZi5jdXJyZW50W2luZGV4UmVmLmN1cnJlbnRdO1xuICAgIGNvbnN0IGZvcmNlU2Nyb2xsSW50b1ZpZXcgPSBmb3JjZVNjcm9sbEludG9WaWV3UmVmLmN1cnJlbnQ7XG4gICAgaWYgKGluaXRpYWxJdGVtKSB7XG4gICAgICBydW5Gb2N1cyhpbml0aWFsSXRlbSk7XG4gICAgfVxuICAgIGNvbnN0IHNjaGVkdWxlciA9IGZvcmNlU3luY0ZvY3VzUmVmLmN1cnJlbnQgPyBjYWxsYmFjayA9PiBjYWxsYmFjaygpIDogY2FsbGJhY2sgPT4gZm9jdXNGcmFtZS5yZXF1ZXN0KGNhbGxiYWNrKTtcbiAgICBzY2hlZHVsZXIoKCkgPT4ge1xuICAgICAgY29uc3Qgd2FpdGVkSXRlbSA9IGxpc3RSZWYuY3VycmVudFtpbmRleFJlZi5jdXJyZW50XSB8fCBpbml0aWFsSXRlbTtcbiAgICAgIGlmICghd2FpdGVkSXRlbSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoIWluaXRpYWxJdGVtKSB7XG4gICAgICAgIHJ1bkZvY3VzKHdhaXRlZEl0ZW0pO1xuICAgICAgfVxuICAgICAgY29uc3Qgc2hvdWxkU2Nyb2xsSW50b1ZpZXcgPVxuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11c2UtYmVmb3JlLWRlZmluZVxuICAgICAgaXRlbSAmJiAoZm9yY2VTY3JvbGxJbnRvVmlldyB8fCAhaXNQb2ludGVyTW9kYWxpdHlSZWYuY3VycmVudCk7XG4gICAgICBpZiAoc2hvdWxkU2Nyb2xsSW50b1ZpZXcpIHtcbiAgICAgICAgLy8gSlNET00gZG9lc24ndCBzdXBwb3J0IGAuc2Nyb2xsSW50b1ZpZXcoKWAgYnV0IGl0J3Mgd2lkZWx5IHN1cHBvcnRlZFxuICAgICAgICAvLyBieSBhbGwgYnJvd3NlcnMuXG4gICAgICAgIHdhaXRlZEl0ZW0uc2Nyb2xsSW50b1ZpZXc/Lih7XG4gICAgICAgICAgYmxvY2s6ICduZWFyZXN0JyxcbiAgICAgICAgICBpbmxpbmU6ICduZWFyZXN0J1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgZGF0YVJlZi5jdXJyZW50Lm9yaWVudGF0aW9uID0gb3JpZW50YXRpb247XG4gIH0sIFtkYXRhUmVmLCBvcmllbnRhdGlvbl0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghb3Blbikge1xuICAgICAga2V5UmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH1cbiAgICAvLyBFeHBsaWNpdCB2YWx1ZXMgY2FuIGNoYW5nZSB3aXRoIHRoZSBvcGVuaW5nIGludGVyYWN0aW9uLiBLZWVwIGFuIGluZmVycmVkICdhdXRvJyB2YWx1ZVxuICAgIC8vIGZyb20gdGhlIHRyaWdnZXIgZXZlbnQsIGJ1dCBhcHBseSBhIGJvb2xlYW4gYmVmb3JlIHRoZSBpbml0aWFsIGhpZ2hsaWdodCBpcyBzeW5jaHJvbml6ZWQuXG4gICAgaWYgKCFvcGVuIHx8IGZvY3VzSXRlbU9uT3BlbiAhPT0gJ2F1dG8nKSB7XG4gICAgICBmb2N1c0l0ZW1Pbk9wZW5SZWYuY3VycmVudCA9IGZvY3VzSXRlbU9uT3BlbjtcbiAgICB9XG4gIH0sIFtvcGVuLCBmb2N1c0l0ZW1Pbk9wZW5dKTtcblxuICAvLyBTeW5jIGBzZWxlY3RlZEluZGV4YCB0byBiZSB0aGUgYGFjdGl2ZUluZGV4YCB1cG9uIG9wZW5pbmcgdGhlIGZsb2F0aW5nXG4gIC8vIGVsZW1lbnQuIEFsc28sIHJlc2V0IGBhY3RpdmVJbmRleGAgdXBvbiBjbG9zaW5nIHRoZSBmbG9hdGluZyBlbGVtZW50LlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAob3BlbiAmJiBmbG9hdGluZ0VsZW1lbnQpIHtcbiAgICAgIGluZGV4UmVmLmN1cnJlbnQgPSBzZWxlY3RlZEluZGV4ID8/IC0xO1xuICAgICAgaWYgKGZvY3VzSXRlbU9uT3BlblJlZi5jdXJyZW50ICYmIHNlbGVjdGVkSW5kZXggIT0gbnVsbCkge1xuICAgICAgICAvLyBSZWdhcmRsZXNzIG9mIHRoZSBwb2ludGVyIG1vZGFsaXR5LCB3ZSB3YW50IHRvIGVuc3VyZSB0aGUgc2VsZWN0ZWRcbiAgICAgICAgLy8gaXRlbSBjb21lcyBpbnRvIHZpZXcgd2hlbiB0aGUgZmxvYXRpbmcgZWxlbWVudCBpcyBvcGVuZWQuXG4gICAgICAgIGZvcmNlU2Nyb2xsSW50b1ZpZXdSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICAgIG9uTmF2aWdhdGUoKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKHByZXZpb3VzTW91bnRlZFJlZi5jdXJyZW50KSB7XG4gICAgICAvLyBSZXNldCB0aGUgYWN0aXZlIGluZGV4IHdoZW4gdGhlIGxpc3QgaXMgbm8gbG9uZ2VyIG9wZW4gYW5kIG1vdW50ZWQgKGNsb3Npbmcgb3JcbiAgICAgIC8vIHVubW91bnRpbmcpLiBgb25OYXZpZ2F0ZWAgaXMgYSBzdGFibGUgY2FsbGJhY2sgdGhhdCBhbHdheXMgZm9yd2FyZHMgdG8gdGhlIGxhdGVzdFxuICAgICAgLy8gYG9uTmF2aWdhdGVgIHByb3AuXG4gICAgICBpbmRleFJlZi5jdXJyZW50ID0gLTE7XG4gICAgICBvbk5hdmlnYXRlKCk7XG4gICAgfVxuICB9LCBbZW5hYmxlZCwgb3BlbiwgZmxvYXRpbmdFbGVtZW50LCBzZWxlY3RlZEluZGV4LCBvbk5hdmlnYXRlXSk7XG5cbiAgLy8gU3luYyBgYWN0aXZlSW5kZXhgIHRvIGJlIHRoZSBmb2N1c2VkIGl0ZW0gd2hpbGUgdGhlIGZsb2F0aW5nIGVsZW1lbnQgaXNcbiAgLy8gb3Blbi5cbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWVuYWJsZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCFvcGVuKSB7XG4gICAgICBmb3JjZVN5bmNGb2N1c1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghZmxvYXRpbmdFbGVtZW50KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChhY3RpdmVJbmRleCA9PSBudWxsKSB7XG4gICAgICBmb3JjZVN5bmNGb2N1c1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICBpZiAoc2VsZWN0ZWRJbmRleFJlZi5jdXJyZW50ICE9IG51bGwpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBSZXNldCB3aGlsZSB0aGUgZmxvYXRpbmcgZWxlbWVudCB3YXMgb3BlbiAoZS5nLiB0aGUgbGlzdCBjaGFuZ2VkKS5cbiAgICAgIGlmIChwcmV2aW91c01vdW50ZWRSZWYuY3VycmVudCkge1xuICAgICAgICBpbmRleFJlZi5jdXJyZW50ID0gLTE7XG4gICAgICAgIGZvY3VzSXRlbSgpO1xuICAgICAgfVxuXG4gICAgICAvLyBJbml0aWFsIHN5bmMuXG4gICAgICBpZiAoKCFwcmV2aW91c09wZW5SZWYuY3VycmVudCB8fCAhcHJldmlvdXNNb3VudGVkUmVmLmN1cnJlbnQpICYmIGZvY3VzSXRlbU9uT3BlblJlZi5jdXJyZW50ICYmIChrZXlSZWYuY3VycmVudCAhPSBudWxsIHx8IGZvY3VzSXRlbU9uT3BlblJlZi5jdXJyZW50ID09PSB0cnVlICYmIGtleVJlZi5jdXJyZW50ID09IG51bGwpKSB7XG4gICAgICAgIGxldCBydW5zID0gMDtcbiAgICAgICAgY29uc3Qgd2FpdEZvckxpc3RQb3B1bGF0ZWQgPSAoKSA9PiB7XG4gICAgICAgICAgaWYgKGxpc3RSZWYuY3VycmVudFswXSA9PSBudWxsKSB7XG4gICAgICAgICAgICAvLyBBdm9pZCBsZXR0aW5nIHRoZSBicm93c2VyIHBhaW50IGlmIHBvc3NpYmxlIG9uIHRoZSBmaXJzdCB0cnksXG4gICAgICAgICAgICAvLyBvdGhlcndpc2UgdXNlIHJBRi4gRG9uJ3QgdHJ5IG1vcmUgdGhhbiB0d2ljZSwgc2luY2Ugc29tZXRoaW5nXG4gICAgICAgICAgICAvLyBpcyB3cm9uZyBvdGhlcndpc2UuXG4gICAgICAgICAgICBpZiAocnVucyA8IDIpIHtcbiAgICAgICAgICAgICAgY29uc3Qgc2NoZWR1bGVyID0gcnVucyA/IGNhbGxiYWNrID0+IHdhaXRGb3JMaXN0UG9wdWxhdGVkRnJhbWUucmVxdWVzdChjYWxsYmFjaykgOiBxdWV1ZU1pY3JvdGFzaztcbiAgICAgICAgICAgICAgc2NoZWR1bGVyKHdhaXRGb3JMaXN0UG9wdWxhdGVkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJ1bnMgKz0gMTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gSW5pdGlhbGx5IGZvY3VzIHRoZSBmaXJzdCBub24tZGlzYWJsZWQgaXRlbS4gYGRpc2FibGVkSW5kaWNlc2AgaXMgZGVsaWJlcmF0ZWx5XG4gICAgICAgICAgICAvLyBvbWl0dGVkIGhlcmUgc28gYXR0cmlidXRlLWRpc2FibGVkIGl0ZW1zIChgZGlzYWJsZWRgL2BhcmlhLWRpc2FibGVkYCkgYXJlIHNraXBwZWRcbiAgICAgICAgICAgIC8vIG9uIG9wZW4gZXZlbiB3aGVuIHRoZSBjb25zdW1lciBwYXNzZXMgYW4gZW1wdHkgYGRpc2FibGVkSW5kaWNlc2AgYXJyYXkuIFBhc3NpbmcgaXRcbiAgICAgICAgICAgIC8vIHdvdWxkIHJlZ3Jlc3MgdGhhdCBiZWhhdmlvciAoc2VlIG11aS9iYXNlLXVpIzI2MDQpLlxuICAgICAgICAgICAgLy8gVGhlIGtleSBjYW1lIGZyb20gdGhlIHRyaWdnZXIsIHNvIGl0IGlzIHJlYWQgb24gdGhlIHRyaWdnZXIncyBvcmllbnRhdGlvbi5cbiAgICAgICAgICAgIGluZGV4UmVmLmN1cnJlbnQgPSBrZXlSZWYuY3VycmVudCA9PSBudWxsIHx8IGlzTWFpbk9yaWVudGF0aW9uVG9FbmRLZXkoa2V5UmVmLmN1cnJlbnQsIHRyaWdnZXJPcmllbnRhdGlvbiwgcnRsKSB8fCBuZXN0ZWQgPyBnZXRNaW5MaXN0SW5kZXgobGlzdFJlZikgOiBnZXRNYXhMaXN0SW5kZXgobGlzdFJlZik7XG4gICAgICAgICAgICBrZXlSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgICAgICBvbk5hdmlnYXRlKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICB3YWl0Rm9yTGlzdFBvcHVsYXRlZCgpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoIWlzSW5kZXhPdXRPZkxpc3RCb3VuZHMobGlzdFJlZi5jdXJyZW50LCBhY3RpdmVJbmRleCkpIHtcbiAgICAgIGluZGV4UmVmLmN1cnJlbnQgPSBhY3RpdmVJbmRleDtcbiAgICAgIGZvY3VzSXRlbSgpO1xuICAgICAgZm9yY2VTY3JvbGxJbnRvVmlld1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgfVxuICB9LCBbZW5hYmxlZCwgb3BlbiwgZmxvYXRpbmdFbGVtZW50LCBhY3RpdmVJbmRleCwgc2VsZWN0ZWRJbmRleFJlZiwgbmVzdGVkLCBsaXN0UmVmLCB0cmlnZ2VyT3JpZW50YXRpb24sIHJ0bCwgb25OYXZpZ2F0ZSwgZm9jdXNJdGVtLCB3YWl0Rm9yTGlzdFBvcHVsYXRlZEZyYW1lXSk7XG5cbiAgLy8gRW5zdXJlIHRoZSBwYXJlbnQgZmxvYXRpbmcgZWxlbWVudCBoYXMgZm9jdXMgd2hlbiBhIG5lc3RlZCBjaGlsZCBjbG9zZXNcbiAgLy8gdG8gYWxsb3cgYXJyb3cga2V5IG5hdmlnYXRpb24gdG8gd29yayBhZnRlciB0aGUgcG9pbnRlciBsZWF2ZXMgdGhlIGNoaWxkLlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCB8fCBmbG9hdGluZ0VsZW1lbnQgfHwgIXRyZWUgfHwgdmlydHVhbCB8fCAhcHJldmlvdXNNb3VudGVkUmVmLmN1cnJlbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgbm9kZXMgPSB0cmVlLm5vZGVzUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgcGFyZW50ID0gbm9kZXMuZmluZChub2RlID0+IG5vZGUuaWQgPT09IHBhcmVudElkKT8uY29udGV4dD8uZWxlbWVudHMuZmxvYXRpbmc7XG4gICAgLy8gYGZsb2F0aW5nRWxlbWVudGAgaXMgbnVsbCBoZXJlIChzZWUgdGhlIGd1YXJkIGFib3ZlKSwgc28gcmVzb2x2ZSB0aGUgb3duZXIgZG9jdW1lbnQgZnJvbSBhblxuICAgIC8vIGluLURPTSBlbGVtZW50IGZvciByZWFsbS1zYWZldHkgKHNoYWRvdyBET00vaWZyYW1lcyk6IHRoZSByZWZlcmVuY2UgZWxlbWVudCwgZmFsbGluZyBiYWNrIHRvXG4gICAgLy8gdGhlIHBhcmVudCBmbG9hdGluZyBlbGVtZW50IHdoZW4gdGhlIHJlZmVyZW5jZSBpcyB2aXJ0dWFsIChgZG9tUmVmZXJlbmNlRWxlbWVudGAgaXMgbnVsbCkuXG4gICAgY29uc3QgYWN0aXZlRWwgPSBhY3RpdmVFbGVtZW50KG93bmVyRG9jdW1lbnQoZG9tUmVmZXJlbmNlRWxlbWVudCA/PyBwYXJlbnQgPz8gbnVsbCkpO1xuICAgIGNvbnN0IHRyZWVDb250YWluc0FjdGl2ZUVsID0gbm9kZXMuc29tZShub2RlID0+IG5vZGUuY29udGV4dCAmJiBjb250YWlucyhub2RlLmNvbnRleHQuZWxlbWVudHMuZmxvYXRpbmcsIGFjdGl2ZUVsKSk7XG4gICAgaWYgKHBhcmVudCAmJiAhdHJlZUNvbnRhaW5zQWN0aXZlRWwgJiYgaXNQb2ludGVyTW9kYWxpdHlSZWYuY3VycmVudCkge1xuICAgICAgcGFyZW50LmZvY3VzKHtcbiAgICAgICAgcHJldmVudFNjcm9sbDogdHJ1ZVxuICAgICAgfSk7XG4gICAgfVxuICB9LCBbZW5hYmxlZCwgZmxvYXRpbmdFbGVtZW50LCBkb21SZWZlcmVuY2VFbGVtZW50LCB0cmVlLCBwYXJlbnRJZCwgdmlydHVhbF0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIHByZXZpb3VzT3BlblJlZi5jdXJyZW50ID0gb3BlbjtcbiAgICBwcmV2aW91c01vdW50ZWRSZWYuY3VycmVudCA9ICEhZmxvYXRpbmdFbGVtZW50O1xuICB9KTtcbiAgY29uc3QgaGFzQWN0aXZlSW5kZXggPSBhY3RpdmVJbmRleCAhPSBudWxsO1xuICBjb25zdCBzeW5jQ3VycmVudFRhcmdldCA9IHVzZVN0YWJsZUNhbGxiYWNrKGV2ZW50ID0+IHtcbiAgICBpZiAoIWxhdGVzdE9wZW5SZWYuY3VycmVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBpbmRleCA9IGxpc3RSZWYuY3VycmVudC5pbmRleE9mKGV2ZW50LmN1cnJlbnRUYXJnZXQpO1xuICAgIGlmIChpbmRleCAhPT0gLTEgJiYgKGluZGV4UmVmLmN1cnJlbnQgIT09IGluZGV4IHx8IGFjdGl2ZUluZGV4ICE9PSBpbmRleCkpIHtcbiAgICAgIGluZGV4UmVmLmN1cnJlbnQgPSBpbmRleDtcbiAgICAgIG9uTmF2aWdhdGUoZXZlbnQpO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IGdldFBhcmVudE9yaWVudGF0aW9uID0gdXNlU3RhYmxlQ2FsbGJhY2soKCkgPT4ge1xuICAgIHJldHVybiBwYXJlbnRPcmllbnRhdGlvbiA/PyB0cmVlPy5ub2Rlc1JlZi5jdXJyZW50LmZpbmQobm9kZSA9PiBub2RlLmlkID09PSBwYXJlbnRJZCk/LmNvbnRleHQ/LmRhdGFSZWY/LmN1cnJlbnQub3JpZW50YXRpb247XG4gIH0pO1xuICBjb25zdCBnZXRNaW5FbmFibGVkSW5kZXggPSB1c2VTdGFibGVDYWxsYmFjaygoKSA9PiB7XG4gICAgcmV0dXJuIGdldE1pbkxpc3RJbmRleChsaXN0UmVmLCBkaXNhYmxlZEluZGljZXNSZWYuY3VycmVudCk7XG4gIH0pO1xuICBjb25zdCBjb21tb25PbktleURvd24gPSB1c2VTdGFibGVDYWxsYmFjayhldmVudCA9PiB7XG4gICAgaXNQb2ludGVyTW9kYWxpdHlSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIGZvcmNlU3luY0ZvY3VzUmVmLmN1cnJlbnQgPSB0cnVlO1xuXG4gICAgLy8gV2hlbiBjb21wb3NpbmcgYSBjaGFyYWN0ZXIsIENocm9tZSBmaXJlcyBBcnJvd0Rvd24gdHdpY2UuIEZpcmVmb3gvU2FmYXJpXG4gICAgLy8gZG9uJ3QgYXBwZWFyIHRvIHN1ZmZlciBmcm9tIHRoaXMuIGBldmVudC5pc0NvbXBvc2luZ2AgaXMgYXZvaWRlZCBkdWUgdG9cbiAgICAvLyBTYWZhcmkgbm90IHN1cHBvcnRpbmcgaXQgcHJvcGVybHkgKGFsdGhvdWdoIGl0J3Mgbm90IG5lZWRlZCBpbiB0aGUgZmlyc3RcbiAgICAvLyBwbGFjZSBmb3IgU2FmYXJpLCBqdXN0IGF2b2lkaW5nIGFueSBwb3NzaWJsZSBpc3N1ZXMpLlxuICAgIGlmIChldmVudC53aGljaCA9PT0gMjI5KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gSWYgdGhlIGZsb2F0aW5nIGVsZW1lbnQgaXMgYW5pbWF0aW5nIG91dCwgaWdub3JlIG5hdmlnYXRpb24uIE90aGVyd2lzZSxcbiAgICAvLyB0aGUgYGFjdGl2ZUluZGV4YCBnZXRzIHNldCB0byAwIGRlc3BpdGUgbm90IGJlaW5nIG9wZW4gc28gdGhlIG5leHQgdGltZVxuICAgIC8vIHRoZSB1c2VyIEFycm93RG93bnMsIHRoZSBmaXJzdCBpdGVtIHdvbid0IGJlIGZvY3VzZWQuXG4gICAgaWYgKCFsYXRlc3RPcGVuUmVmLmN1cnJlbnQgJiYgZXZlbnQuY3VycmVudFRhcmdldCA9PT0gZmxvYXRpbmdGb2N1c0VsZW1lbnRSZWYuY3VycmVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAobmVzdGVkICYmIGlzQ3Jvc3NPcmllbnRhdGlvbkNsb3NlS2V5KGV2ZW50LmtleSwgb3JpZW50YXRpb24sIHJ0bCwgaXNHcmlkKSkge1xuICAgICAgLy8gSWYgdGhlIG5lc3RlZCBsaXN0J3MgY2xvc2Uga2V5IGlzIGFsc28gdGhlIHBhcmVudCBuYXZpZ2F0aW9uIGtleSxcbiAgICAgIC8vIGxldCB0aGUgcGFyZW50IG5hdmlnYXRlLiBPdGhlcndpc2UsIHN0b3AgcHJvcGFnYXRpbmcgdGhlIGV2ZW50LlxuICAgICAgaWYgKCFpc01haW5PcmllbnRhdGlvbktleShldmVudC5rZXksIGdldFBhcmVudE9yaWVudGF0aW9uKCkpKSB7XG4gICAgICAgIHN0b3BFdmVudChldmVudCk7XG4gICAgICB9XG4gICAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5saXN0TmF2aWdhdGlvbiwgZXZlbnQubmF0aXZlRXZlbnQpKTtcbiAgICAgIGNvbnN0IHJldHVybkVsZW1lbnQgPSBuZXN0ZWRSZXR1cm5Gb2N1c1JlZj8uY3VycmVudCA/PyBkb21SZWZlcmVuY2VFbGVtZW50O1xuICAgICAgaWYgKGlzSFRNTEVsZW1lbnQocmV0dXJuRWxlbWVudCkpIHtcbiAgICAgICAgcmV0dXJuRWxlbWVudC5mb2N1cygpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIFRoZSBjb25zdW1lciBvd25zIGBhY3RpdmVJbmRleGAgYW5kIG1heSBkZWNsaW5lIGEgbmF2aWdhdGlvbiB0aGlzIGhvb2sgcHJvcG9zZWQsIHN1Y2ggYXMgYVxuICAgIC8vIHZpcnR1YWwgbGlzdCBrZWVwaW5nIGl0cyBoaWdobGlnaHQgd2hlbiB0aGUgcmVmZXJlbmNlIGlzIHJlZm9jdXNlZC4gRGVjbGluaW5nIHByb2R1Y2VzIG5vXG4gICAgLy8gcmUtcmVuZGVyLCBzbyByZWNvbmNpbGUgaGVyZTogb3RoZXJ3aXNlIHRoZSBjdXJzb3IgZHJpZnRzIGZyb20gdGhlIHJlbmRlcmVkIGhpZ2hsaWdodCBhbmRcbiAgICAvLyB0aGlzIGtleSBtb3ZlcyBmcm9tIHRoZSB3cm9uZyBwb3NpdGlvbi5cbiAgICBpZiAoYWN0aXZlSW5kZXggIT0gbnVsbCAmJiBhY3RpdmVJbmRleCAhPT0gaW5kZXhSZWYuY3VycmVudCAmJiAhaXNJbmRleE91dE9mTGlzdEJvdW5kcyhsaXN0UmVmLmN1cnJlbnQsIGFjdGl2ZUluZGV4KSkge1xuICAgICAgaW5kZXhSZWYuY3VycmVudCA9IGFjdGl2ZUluZGV4O1xuICAgIH1cbiAgICBjb25zdCBjdXJyZW50SW5kZXggPSBpbmRleFJlZi5jdXJyZW50O1xuICAgIGNvbnN0IG1pbkluZGV4ID0gZ2V0TWluTGlzdEluZGV4KGxpc3RSZWYsIGRpc2FibGVkSW5kaWNlcyk7XG4gICAgY29uc3QgbWF4SW5kZXggPSBnZXRNYXhMaXN0SW5kZXgobGlzdFJlZiwgZGlzYWJsZWRJbmRpY2VzKTtcbiAgICBpZiAoIXR5cGVhYmxlQ29tYm9ib3hSZWZlcmVuY2UpIHtcbiAgICAgIGlmIChldmVudC5rZXkgPT09ICdIb21lJykge1xuICAgICAgICBzdG9wRXZlbnQoZXZlbnQpO1xuICAgICAgICBpbmRleFJlZi5jdXJyZW50ID0gbWluSW5kZXg7XG4gICAgICAgIG9uTmF2aWdhdGUoZXZlbnQpO1xuICAgICAgfVxuICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ0VuZCcpIHtcbiAgICAgICAgc3RvcEV2ZW50KGV2ZW50KTtcbiAgICAgICAgaW5kZXhSZWYuY3VycmVudCA9IG1heEluZGV4O1xuICAgICAgICBvbk5hdmlnYXRlKGV2ZW50KTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBHcmlkIG5hdmlnYXRpb24gaXMgaW5qZWN0ZWQgYnkgZ3JpZC1jYXBhYmxlIGNvbnN1bWVycyBzbyBub24tZ3JpZFxuICAgIC8vIGNvbnN1bWVycyAobWVudSwgc2VsZWN0KSB0cmVlLXNoYWtlIHRoZSBncmlkIGhlbHBlcnMgb3V0LlxuICAgIGlmIChuYXZpZ2F0ZUdyaWQgIT0gbnVsbCkge1xuICAgICAgY29uc3QgaW5kZXggPSBuYXZpZ2F0ZUdyaWQoZXZlbnQsIGluZGV4UmVmLmN1cnJlbnQsIGxpc3RSZWYsIG9yaWVudGF0aW9uLCBsb29wRm9jdXMsIHJ0bCwgZGlzYWJsZWRJbmRpY2VzLCBtaW5JbmRleCwgbWF4SW5kZXgpO1xuXG4gICAgICAvLyBUaGUgZ3JpZCBuYXZpZ2F0b3IgcmV0dXJucyB0aGUgdW5jaGFuZ2VkIGluZGV4IGZvciBrZXlzIGl0IGRvZXMgbm90IGhhbmRsZSwgYW5kXG4gICAgICAvLyByZXBvcnRpbmcgdGhhdCBhcyBhIG5hdmlnYXRpb24gd291bGQgcmUtZW1pdCB0aGUgY3VycmVudCBoaWdobGlnaHQgb24gZXZlcnkga2V5ZG93bi5cbiAgICAgIGlmIChpbmRleCAhPSBudWxsICYmIGluZGV4ICE9PSBpbmRleFJlZi5jdXJyZW50KSB7XG4gICAgICAgIGluZGV4UmVmLmN1cnJlbnQgPSBpbmRleDtcbiAgICAgICAgb25OYXZpZ2F0ZShldmVudCk7XG4gICAgICB9XG4gICAgICBpZiAob3JpZW50YXRpb24gPT09ICdib3RoJykge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChpc01haW5PcmllbnRhdGlvbktleShldmVudC5rZXksIG9yaWVudGF0aW9uKSkge1xuICAgICAgc3RvcEV2ZW50KGV2ZW50KTtcblxuICAgICAgLy8gUmVzZXQgdGhlIGluZGV4IGlmIG5vIGl0ZW0gaXMgZm9jdXNlZC4gRm9jdXMgY2FuIGFsc28gcmVzdCBvbiBhIGNvbnRhaW5lciBpbnNpZGUgdGhlXG4gICAgICAvLyBwb3B1cCwgc3VjaCBhcyBhIGxpc3QgdGhhdCBob2xkcyB0aGUgYG1lbnVgIHJvbGUuIEtleXMgYnViYmxpbmcgZnJvbSBhIHBvcnRhbGVkIG5lc3RlZFxuICAgICAgLy8gcG9wdXAgYXJlIG5vdCBpbiB0aGlzIHBvcHVwJ3MgRE9NLCBzbyB0aGV5IG5hdmlnYXRlIGZyb20gdGhlIGN1cnJlbnQgaW5kZXguXG4gICAgICBjb25zdCBmb2N1c2VkRWxlbWVudCA9IGFjdGl2ZUVsZW1lbnQoZXZlbnQuY3VycmVudFRhcmdldC5vd25lckRvY3VtZW50KTtcbiAgICAgIGlmIChvcGVuICYmICF2aXJ0dWFsICYmIGNvbnRhaW5zKGV2ZW50LmN1cnJlbnRUYXJnZXQsIGZvY3VzZWRFbGVtZW50KSAmJiAhbGlzdFJlZi5jdXJyZW50LnNvbWUoaXRlbSA9PiBpdGVtICE9IG51bGwgJiYgY29udGFpbnMoaXRlbSwgZm9jdXNlZEVsZW1lbnQpKSkge1xuICAgICAgICBpbmRleFJlZi5jdXJyZW50ID0gaXNNYWluT3JpZW50YXRpb25Ub0VuZEtleShldmVudC5rZXksIG9yaWVudGF0aW9uLCBydGwpID8gbWluSW5kZXggOiBtYXhJbmRleDtcbiAgICAgICAgb25OYXZpZ2F0ZShldmVudCk7XG4gICAgICAgIC8vIFRoZSBib3VuZGFyeSBpdGVtIG1heSBhbHJlYWR5IGJlIGhpZ2hsaWdodGVkLCBzbyBgYWN0aXZlSW5kZXhgIHdvbid0IGNoYW5nZSBhbmQgdGhlXG4gICAgICAgIC8vIGVmZmVjdCB0aGF0IG1vdmVzIGZvY3VzIHRvIHRoZSBoaWdobGlnaHRlZCBpdGVtIHdvbid0IHJ1bi5cbiAgICAgICAgaWYgKGFjdGl2ZUluZGV4ID09PSBpbmRleFJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgZm9jdXNJdGVtKCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3Qge1xuICAgICAgICBpbmRleCxcbiAgICAgICAgd3JhcHBlZFxuICAgICAgfSA9IGdldE5leHRMaXN0SW5kZXgobGlzdFJlZi5jdXJyZW50LCBjdXJyZW50SW5kZXgsIHtcbiAgICAgICAgZGVjcmVtZW50OiAhaXNNYWluT3JpZW50YXRpb25Ub0VuZEtleShldmVudC5rZXksIG9yaWVudGF0aW9uLCBydGwpLFxuICAgICAgICBsb29wRm9jdXMsXG4gICAgICAgIGFsbG93RXNjYXBlLFxuICAgICAgICBkaXNhYmxlZEluZGljZXMsXG4gICAgICAgIG1pbkluZGV4LFxuICAgICAgICBtYXhJbmRleFxuICAgICAgfSk7XG4gICAgICBpZiAod3JhcHBlZCkge1xuICAgICAgICAvLyBHaXZlIHRpbWUgZm9yIHZpcnR1YWxpemVycyB0byB1cGRhdGUgdGhlIGxpc3RSZWYuXG4gICAgICAgIGZvcmNlU3luY0ZvY3VzUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGluZGV4UmVmLmN1cnJlbnQgPSBpbmRleDtcbiAgICAgIG9uTmF2aWdhdGUoZXZlbnQpO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IGl0ZW0gPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBpdGVtUHJvcHMgPSB7XG4gICAgICBvbkZvY3VzKGV2ZW50KSB7XG4gICAgICAgIGZvcmNlU3luY0ZvY3VzUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICBzeW5jQ3VycmVudFRhcmdldChldmVudCk7XG4gICAgICB9LFxuICAgICAgb25DbGljayh7XG4gICAgICAgIGN1cnJlbnRUYXJnZXRcbiAgICAgIH0pIHtcbiAgICAgICAgLy8gU2FmYXJpLiBTa2lwcGVkIHVuZGVyIHZpcnR1YWwgZm9jdXMsIHdoaWNoIG11c3Qga2VlcCByZWFsIGZvY3VzIG9uIHRoZSByZWZlcmVuY2UuXG4gICAgICAgIGlmICghdmlydHVhbCkge1xuICAgICAgICAgIGN1cnJlbnRUYXJnZXQuZm9jdXMoe1xuICAgICAgICAgICAgcHJldmVudFNjcm9sbDogdHJ1ZVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgb25Nb3VzZU1vdmUoZXZlbnQpIHtcbiAgICAgICAgaWYgKGlzU3RhdGlvbmFyeVdlYktpdFBvaW50ZXIoZXZlbnQpKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGZvcmNlU3luY0ZvY3VzUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICBmb3JjZVNjcm9sbEludG9WaWV3UmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgaWYgKGZvY3VzSXRlbU9uSG92ZXIpIHtcbiAgICAgICAgICBzeW5jQ3VycmVudFRhcmdldChldmVudCk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBvblBvaW50ZXJMZWF2ZShldmVudCkge1xuICAgICAgICBpZiAoIWxhdGVzdE9wZW5SZWYuY3VycmVudCB8fCAhaXNQb2ludGVyTW9kYWxpdHlSZWYuY3VycmVudCB8fCBldmVudC5wb2ludGVyVHlwZSA9PT0gJ3RvdWNoJykge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBmb3JjZVN5bmNGb2N1c1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgY29uc3QgcmVsYXRlZFRhcmdldCA9IGV2ZW50LnJlbGF0ZWRUYXJnZXQ7XG4gICAgICAgIGlmICghZm9jdXNJdGVtT25Ib3ZlciB8fCBsaXN0UmVmLmN1cnJlbnQuaW5jbHVkZXMocmVsYXRlZFRhcmdldCkpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFyZXNldE9uUG9pbnRlckxlYXZlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY2FuY2VsUXVldWVkRm9jdXNSZWYuY3VycmVudD8uKCk7XG4gICAgICAgIGNhbmNlbFF1ZXVlZEZvY3VzUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICBpbmRleFJlZi5jdXJyZW50ID0gLTE7XG4gICAgICAgIG9uTmF2aWdhdGUoZXZlbnQpO1xuICAgICAgICBpZiAoIXZpcnR1YWwpIHtcbiAgICAgICAgICBjb25zdCBmbG9hdGluZ0ZvY3VzRWwgPSBmbG9hdGluZ0ZvY3VzRWxlbWVudFJlZi5jdXJyZW50O1xuICAgICAgICAgIGNvbnN0IGFjdGl2ZUVsID0gYWN0aXZlRWxlbWVudChvd25lckRvY3VtZW50KGZsb2F0aW5nRm9jdXNFbCkpO1xuICAgICAgICAgIGlmIChmbG9hdGluZ0ZvY3VzRWwgJiYgY29udGFpbnMoZmxvYXRpbmdGb2N1c0VsLCBhY3RpdmVFbCkpIHtcbiAgICAgICAgICAgIGZsb2F0aW5nRm9jdXNFbC5mb2N1cyh7XG4gICAgICAgICAgICAgIHByZXZlbnRTY3JvbGw6IHRydWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH07XG4gICAgcmV0dXJuIGl0ZW1Qcm9wcztcbiAgfSwgW3N5bmNDdXJyZW50VGFyZ2V0LCBsYXRlc3RPcGVuUmVmLCBmbG9hdGluZ0ZvY3VzRWxlbWVudFJlZiwgZm9jdXNJdGVtT25Ib3ZlciwgbGlzdFJlZiwgb25OYXZpZ2F0ZSwgcmVzZXRPblBvaW50ZXJMZWF2ZVJlZiwgdmlydHVhbF0pO1xuICBjb25zdCBhcmlhQWN0aXZlRGVzY2VuZGFudFByb3AgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gdmlydHVhbCAmJiBvcGVuICYmIGhhc0FjdGl2ZUluZGV4ICYmIHtcbiAgICAgICdhcmlhLWFjdGl2ZWRlc2NlbmRhbnQnOiBgJHtpZH0tJHthY3RpdmVJbmRleH1gXG4gICAgfTtcbiAgfSwgW3ZpcnR1YWwsIG9wZW4sIGhhc0FjdGl2ZUluZGV4LCBpZCwgYWN0aXZlSW5kZXhdKTtcbiAgY29uc3QgZmxvYXRpbmcgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4ge1xuICAgICAgLi4uKCF0eXBlYWJsZUNvbWJvYm94UmVmZXJlbmNlID8gYXJpYUFjdGl2ZURlc2NlbmRhbnRQcm9wIDoge30pLFxuICAgICAgb25LZXlEb3duKGV2ZW50KSB7XG4gICAgICAgIC8vIENsb3NlIHN1Ym1lbnUgb24gU2hpZnQrVGFiXG4gICAgICAgIGlmIChldmVudC5rZXkgPT09ICdUYWInICYmIGV2ZW50LnNoaWZ0S2V5ICYmIG9wZW4gJiYgIXZpcnR1YWwpIHtcbiAgICAgICAgICAvLyBJZiB0aGUgZXZlbnQgb3JpZ2luYXRlZCBmcm9tIHdpdGhpbiBhIG5lc3RlZCBlbGVtZW50IChlLmcuLCBhIERpYWxvZyBvcGVuZWQgZnJvbVxuICAgICAgICAgIC8vIHdpdGhpbiB0aGUgbWVudSksIGRvbid0IGNsb3NlIHRoZSBtZW51LiBUaGUgbmVzdGVkIGVsZW1lbnQgaGFzIGl0cyBvd24gZm9jdXNcbiAgICAgICAgICAvLyBtYW5hZ2VtZW50IGFuZCBzaG91bGQgaGFuZGxlIHRoZSBUYWIga2V5LlxuICAgICAgICAgIGNvbnN0IHRhcmdldCA9IGdldFRhcmdldChldmVudC5uYXRpdmVFdmVudCk7XG4gICAgICAgICAgaWYgKHRhcmdldCAmJiAhY29udGFpbnMoZmxvYXRpbmdGb2N1c0VsZW1lbnRSZWYuY3VycmVudCwgdGFyZ2V0KSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBzdG9wRXZlbnQoZXZlbnQpO1xuICAgICAgICAgIGNvbnN0IGRldGFpbHMgPSBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5mb2N1c091dCwgZXZlbnQubmF0aXZlRXZlbnQpO1xuICAgICAgICAgIHN0b3JlLnNldE9wZW4oZmFsc2UsIGRldGFpbHMpO1xuICAgICAgICAgIGNvbnN0IHJldHVybkVsZW1lbnQgPSBuZXN0ZWRSZXR1cm5Gb2N1c1JlZj8uY3VycmVudCA/PyBkb21SZWZlcmVuY2VFbGVtZW50O1xuICAgICAgICAgIGlmICghZGV0YWlscy5pc0NhbmNlbGVkICYmIGlzSFRNTEVsZW1lbnQocmV0dXJuRWxlbWVudCkpIHtcbiAgICAgICAgICAgIHJldHVybkVsZW1lbnQuZm9jdXMoKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbW1vbk9uS2V5RG93bihldmVudCk7XG4gICAgICB9LFxuICAgICAgb25Qb2ludGVyTW92ZShldmVudCkge1xuICAgICAgICBpZiAoaXNTdGF0aW9uYXJ5V2ViS2l0UG9pbnRlcihldmVudCkpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaXNQb2ludGVyTW9kYWxpdHlSZWYuY3VycmVudCA9IHRydWU7XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW2FyaWFBY3RpdmVEZXNjZW5kYW50UHJvcCwgY29tbW9uT25LZXlEb3duLCBmbG9hdGluZ0ZvY3VzRWxlbWVudFJlZiwgdHlwZWFibGVDb21ib2JveFJlZmVyZW5jZSwgc3RvcmUsIG9wZW4sIHZpcnR1YWwsIGRvbVJlZmVyZW5jZUVsZW1lbnQsIG5lc3RlZFJldHVybkZvY3VzUmVmXSk7XG4gIGNvbnN0IHRyaWdnZXIgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBmdW5jdGlvbiBvcGVuT25OYXZpZ2F0aW9uS2V5RG93bihldmVudCkge1xuICAgICAgc3RvcmUuc2V0T3Blbih0cnVlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5saXN0TmF2aWdhdGlvbiwgZXZlbnQubmF0aXZlRXZlbnQsIGV2ZW50LmN1cnJlbnRUYXJnZXQpKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gY2hlY2tWaXJ0dWFsTW91c2UoZXZlbnQpIHtcbiAgICAgIGlmIChmb2N1c0l0ZW1Pbk9wZW4gPT09ICdhdXRvJyAmJiBpc1ZpcnR1YWxDbGljayhldmVudC5uYXRpdmVFdmVudCkpIHtcbiAgICAgICAgZm9jdXNJdGVtT25PcGVuUmVmLmN1cnJlbnQgPSAhdmlydHVhbDtcbiAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gY2hlY2tWaXJ0dWFsUG9pbnRlcihldmVudCkge1xuICAgICAgLy8gYHBvaW50ZXJkb3duYCBmaXJlcyBmaXJzdCwgcmVzZXQgdGhlIHN0YXRlIHRoZW4gcGVyZm9ybSB0aGUgY2hlY2tzLlxuICAgICAgZm9jdXNJdGVtT25PcGVuUmVmLmN1cnJlbnQgPSBmb2N1c0l0ZW1Pbk9wZW47XG4gICAgICBpZiAoZm9jdXNJdGVtT25PcGVuID09PSAnYXV0bycgJiYgaXNWaXJ0dWFsUG9pbnRlckV2ZW50KGV2ZW50Lm5hdGl2ZUV2ZW50KSkge1xuICAgICAgICBmb2N1c0l0ZW1Pbk9wZW5SZWYuY3VycmVudCA9IHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICBvbktleURvd24oZXZlbnQpIHtcbiAgICAgICAgLy8gbm9uLXJlYWN0aXZlIG9wZW4gc3RhdGUgKHRvIHByZXZlbnQgcmUtY3JlYXRpb24gb2YgdGhlIGhhbmRsZXIpXG4gICAgICAgIGNvbnN0IGN1cnJlbnRPcGVuID0gc3RvcmUuc2VsZWN0KCdvcGVuJyk7XG4gICAgICAgIGlzUG9pbnRlck1vZGFsaXR5UmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgY29uc3QgaXNBcnJvd0tleSA9IGV2ZW50LmtleS5zdGFydHNXaXRoKCdBcnJvdycpO1xuICAgICAgICBjb25zdCBpc1BhcmVudENyb3NzT3BlbktleSA9IGlzQ3Jvc3NPcmllbnRhdGlvbk9wZW5LZXkoZXZlbnQua2V5LCBnZXRQYXJlbnRPcmllbnRhdGlvbigpLCBydGwpO1xuICAgICAgICBjb25zdCBpc01haW5LZXkgPSBpc01haW5PcmllbnRhdGlvbktleShldmVudC5rZXksIGN1cnJlbnRPcGVuID8gb3JpZW50YXRpb24gOiB0cmlnZ2VyT3JpZW50YXRpb24pO1xuICAgICAgICBjb25zdCBpc05hdmlnYXRpb25LZXkgPSAobmVzdGVkID8gaXNQYXJlbnRDcm9zc09wZW5LZXkgOiBpc01haW5LZXkpIHx8IGV2ZW50LmtleSA9PT0gJ0VudGVyJyB8fCBldmVudC5rZXkudHJpbSgpID09PSAnJztcbiAgICAgICAgaWYgKHZpcnR1YWwgJiYgY3VycmVudE9wZW4gJiYgKCFuZXN0ZWQgfHwgaXNUeXBlYWJsZUVsZW1lbnQoZXZlbnQuY3VycmVudFRhcmdldCkpKSB7XG4gICAgICAgICAgcmV0dXJuIGNvbW1vbk9uS2V5RG93bihldmVudCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBJZiBhIGZsb2F0aW5nIGVsZW1lbnQgc2hvdWxkIG5vdCBvcGVuIG9uIGFycm93IGtleSBkb3duLCBhdm9pZFxuICAgICAgICAvLyBzZXR0aW5nIGBhY3RpdmVJbmRleGAgd2hpbGUgaXQncyBjbG9zZWQuXG4gICAgICAgIGlmICghY3VycmVudE9wZW4gJiYgIW9wZW5PbkFycm93S2V5RG93biAmJiBpc0Fycm93S2V5KSB7XG4gICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNOYXZpZ2F0aW9uS2V5KSB7XG4gICAgICAgICAgY29uc3QgaXNQYXJlbnRNYWluS2V5ID0gaXNNYWluT3JpZW50YXRpb25LZXkoZXZlbnQua2V5LCBnZXRQYXJlbnRPcmllbnRhdGlvbigpKTtcbiAgICAgICAgICBrZXlSZWYuY3VycmVudCA9IG5lc3RlZCAmJiBpc1BhcmVudE1haW5LZXkgPyBudWxsIDogZXZlbnQua2V5O1xuICAgICAgICB9XG4gICAgICAgIGlmIChuZXN0ZWQpIHtcbiAgICAgICAgICBpZiAoaXNQYXJlbnRDcm9zc09wZW5LZXkpIHtcbiAgICAgICAgICAgIHN0b3BFdmVudChldmVudCk7XG4gICAgICAgICAgICBpZiAoY3VycmVudE9wZW4pIHtcbiAgICAgICAgICAgICAgaW5kZXhSZWYuY3VycmVudCA9IGdldE1pbkVuYWJsZWRJbmRleCgpO1xuICAgICAgICAgICAgICBvbk5hdmlnYXRlKGV2ZW50KTtcbiAgICAgICAgICAgICAgaWYgKHZpcnR1YWwpIHtcbiAgICAgICAgICAgICAgICBmbG9hdGluZ0ZvY3VzRWxlbWVudFJlZi5jdXJyZW50Py5mb2N1cygpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICBvcGVuT25OYXZpZ2F0aW9uS2V5RG93bihldmVudCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzTWFpbktleSkge1xuICAgICAgICAgIGlmIChzZWxlY3RlZEluZGV4UmVmLmN1cnJlbnQgIT0gbnVsbCkge1xuICAgICAgICAgICAgaW5kZXhSZWYuY3VycmVudCA9IHNlbGVjdGVkSW5kZXhSZWYuY3VycmVudDtcbiAgICAgICAgICB9XG4gICAgICAgICAgc3RvcEV2ZW50KGV2ZW50KTtcbiAgICAgICAgICBpZiAoIWN1cnJlbnRPcGVuICYmIG9wZW5PbkFycm93S2V5RG93bikge1xuICAgICAgICAgICAgb3Blbk9uTmF2aWdhdGlvbktleURvd24oZXZlbnQpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBjb21tb25PbktleURvd24oZXZlbnQpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoY3VycmVudE9wZW4pIHtcbiAgICAgICAgICAgIG9uTmF2aWdhdGUoZXZlbnQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgfSxcbiAgICAgIG9uRm9jdXMoZXZlbnQpIHtcbiAgICAgICAgaWYgKGV2ZW50LnRhcmdldCAhPT0gZXZlbnQuY3VycmVudFRhcmdldCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpZiAoc3RvcmUuc2VsZWN0KCdvcGVuJykgJiYgIXZpcnR1YWwpIHtcbiAgICAgICAgICBpbmRleFJlZi5jdXJyZW50ID0gLTE7XG4gICAgICAgICAgb25OYXZpZ2F0ZShldmVudCk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBvblBvaW50ZXJEb3duOiBjaGVja1ZpcnR1YWxQb2ludGVyLFxuICAgICAgb25Qb2ludGVyRW50ZXI6IGNoZWNrVmlydHVhbFBvaW50ZXIsXG4gICAgICBvbk1vdXNlRG93bjogY2hlY2tWaXJ0dWFsTW91c2UsXG4gICAgICBvbkNsaWNrOiBjaGVja1ZpcnR1YWxNb3VzZVxuICAgIH07XG4gIH0sIFtjb21tb25PbktleURvd24sIGZvY3VzSXRlbU9uT3BlbiwgZ2V0TWluRW5hYmxlZEluZGV4LCBuZXN0ZWQsIG9uTmF2aWdhdGUsIHN0b3JlLCBvcGVuT25BcnJvd0tleURvd24sIG9yaWVudGF0aW9uLCB0cmlnZ2VyT3JpZW50YXRpb24sIGdldFBhcmVudE9yaWVudGF0aW9uLCBydGwsIHNlbGVjdGVkSW5kZXhSZWYsIHZpcnR1YWwsIGZsb2F0aW5nRm9jdXNFbGVtZW50UmVmXSk7XG4gIGNvbnN0IHJlZmVyZW5jZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5hcmlhQWN0aXZlRGVzY2VuZGFudFByb3AsXG4gICAgICAuLi50cmlnZ2VyXG4gICAgfTtcbiAgfSwgW2FyaWFBY3RpdmVEZXNjZW5kYW50UHJvcCwgdHJpZ2dlcl0pO1xuICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiBlbmFibGVkID8ge1xuICAgIHJlZmVyZW5jZSxcbiAgICBmbG9hdGluZyxcbiAgICBpdGVtLFxuICAgIHRyaWdnZXJcbiAgfSA6IHt9LCBbZW5hYmxlZCwgcmVmZXJlbmNlLCBmbG9hdGluZywgdHJpZ2dlciwgaXRlbV0pO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuaW1wb3J0IHsgdXNlVGltZW91dCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVRpbWVvdXQnO1xuaW1wb3J0IHsgRU1QVFlfQVJSQVkgfSBmcm9tICdAYmFzZS11aS91dGlscy9lbXB0eSc7XG5pbXBvcnQgeyBpc0VsZW1lbnRWaXNpYmxlLCBpc0xpc3RJbmRleERpc2FibGVkIH0gZnJvbSBcIi4uL3V0aWxzL2NvbXBvc2l0ZS5tanNcIjtcbmltcG9ydCB7IGNvbnRhaW5zIH0gZnJvbSBcIi4uL3V0aWxzL2VsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBzdG9wRXZlbnQgfSBmcm9tIFwiLi4vdXRpbHMvZXZlbnQubWpzXCI7XG4vKipcbiAqIFByb3ZpZGVzIGEgbWF0Y2hpbmcgY2FsbGJhY2sgdGhhdCBjYW4gYmUgdXNlZCB0byBmb2N1cyBhbiBpdGVtIGFzIHRoZSB1c2VyXG4gKiB0eXBlcywgb2Z0ZW4gdXNlZCBpbiB0YW5kZW0gd2l0aCBgdXNlTGlzdE5hdmlnYXRpb24oKWAuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlVHlwZWFoZWFkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VUeXBlYWhlYWQoc3RvcmUsIHByb3BzKSB7XG4gIGNvbnN0IHtcbiAgICBsaXN0UmVmLFxuICAgIGVsZW1lbnRzUmVmLFxuICAgIGFjdGl2ZUluZGV4LFxuICAgIG9uTWF0Y2g6IG9uTWF0Y2hQcm9wLFxuICAgIGRpc2FibGVkSW5kaWNlcyxcbiAgICBvblR5cGluZzogb25UeXBpbmdQcm9wLFxuICAgIGVuYWJsZWQgPSB0cnVlLFxuICAgIHJlc2V0TXMgPSA3NTAsXG4gICAgc2VsZWN0ZWRJbmRleCA9IG51bGxcbiAgfSA9IHByb3BzO1xuICBjb25zdCBvblR5cGluZyA9IHVzZVN0YWJsZUNhbGxiYWNrKG9uVHlwaW5nUHJvcCk7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCB0aW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICBjb25zdCBzdHJpbmdSZWYgPSBSZWFjdC51c2VSZWYoJycpO1xuICBjb25zdCBwcmV2SW5kZXhSZWYgPSBSZWFjdC51c2VSZWYoc2VsZWN0ZWRJbmRleCA/PyBhY3RpdmVJbmRleCA/PyAtMSk7XG4gIGNvbnN0IG1hdGNoSW5kZXhSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IG9uS2V5RG93biA9IHVzZVN0YWJsZUNhbGxiYWNrKGV2ZW50ID0+IHtcbiAgICBmdW5jdGlvbiBnZXRFbGVtZW50KGluZGV4KSB7XG4gICAgICByZXR1cm4gZWxlbWVudHNSZWY/LmN1cnJlbnRbaW5kZXhdO1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc0l0ZW1BdmFpbGFibGUoaW5kZXgpIHtcbiAgICAgIGNvbnN0IGVsZW1lbnQgPSBnZXRFbGVtZW50KGluZGV4KTtcbiAgICAgIGlmIChlbGVtZW50ICYmICFpc0VsZW1lbnRWaXNpYmxlKGVsZW1lbnQpIHx8IGVsZW1lbnQ/Lm1hdGNoZXMoJzpkaXNhYmxlZCcpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIC8vIFZpc2liaWxpdHkgYW5kIG5hdGl2ZSBkaXNhYmxlZCBzdGF0ZSBhcmUgaGFuZGxlZCBhYm92ZTsgcGFzcyBhbiBlbXB0eVxuICAgICAgLy8gZWxlbWVudCBsaXN0IHNvIGBpc0xpc3RJbmRleERpc2FibGVkYCByZXNvbHZlcyBvbmx5IHRoZSBleHBsaWNpdFxuICAgICAgLy8gYGRpc2FibGVkSW5kaWNlc2AgKGFycmF5L3ByZWRpY2F0ZSkgYW5kIHNraXBzIGl0cyBvd24gZmFsbGJhY2tzLlxuICAgICAgLy8gQ29uc3VtZXJzIHRoYXQgZG9uJ3QgcGFzcyBgZGlzYWJsZWRJbmRpY2VzYCBrZWVwIG1hdGNoaW5nIGV2ZXJ5IHZpc2libGVcbiAgICAgIC8vIGl0ZW0gZXhjZXB0IG5hdGl2ZSBkaXNhYmxlZCBlbGVtZW50cyBwcm92aWRlZCB0aHJvdWdoIGBlbGVtZW50c1JlZmAuXG4gICAgICByZXR1cm4gZGlzYWJsZWRJbmRpY2VzID09IG51bGwgfHwgIWlzTGlzdEluZGV4RGlzYWJsZWQoRU1QVFlfQVJSQVksIGluZGV4LCBkaXNhYmxlZEluZGljZXMpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBnZXRNYXRjaGluZ0luZGV4KGxpc3QsIHN0cmluZywgc3RhcnRJbmRleCA9IDApIHtcbiAgICAgIGlmIChsaXN0Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gLTE7XG4gICAgICB9XG4gICAgICBjb25zdCBub3JtYWxpemVkU3RhcnRJbmRleCA9IChzdGFydEluZGV4ICUgbGlzdC5sZW5ndGggKyBsaXN0Lmxlbmd0aCkgJSBsaXN0Lmxlbmd0aDtcbiAgICAgIGNvbnN0IGxvd2VyU3RyaW5nID0gc3RyaW5nLnRvTG93ZXJDYXNlKCk7XG4gICAgICBmb3IgKGxldCBvZmZzZXQgPSAwOyBvZmZzZXQgPCBsaXN0Lmxlbmd0aDsgb2Zmc2V0ICs9IDEpIHtcbiAgICAgICAgY29uc3QgaW5kZXggPSAobm9ybWFsaXplZFN0YXJ0SW5kZXggKyBvZmZzZXQpICUgbGlzdC5sZW5ndGg7XG4gICAgICAgIGNvbnN0IHRleHQgPSBsaXN0W2luZGV4XTtcbiAgICAgICAgaWYgKCF0ZXh0Py50b0xvd2VyQ2FzZSgpLnN0YXJ0c1dpdGgobG93ZXJTdHJpbmcpIHx8ICFpc0l0ZW1BdmFpbGFibGUoaW5kZXgpKSB7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGluZGV4O1xuICAgICAgfVxuICAgICAgcmV0dXJuIC0xO1xuICAgIH1cbiAgICBjb25zdCBsaXN0Q29udGVudCA9IGxpc3RSZWYuY3VycmVudDtcbiAgICBpZiAoc3RyaW5nUmVmLmN1cnJlbnQubGVuZ3RoID4gMCAmJiBldmVudC5rZXkgPT09ICcgJykge1xuICAgICAgLy8gU3BhY2Ugc2hvdWxkIGNvbnRpbnVlIHRoZSBpbi1wcm9ncmVzcyB0eXBlYWhlYWQgc2Vzc2lvbi5cbiAgICAgIHN0b3BFdmVudChldmVudCk7XG4gICAgICBvblR5cGluZz8uKHRydWUpO1xuICAgIH1cbiAgICBpZiAoc3RyaW5nUmVmLmN1cnJlbnQubGVuZ3RoID4gMCAmJiBzdHJpbmdSZWYuY3VycmVudFswXSAhPT0gJyAnKSB7XG4gICAgICBpZiAoZ2V0TWF0Y2hpbmdJbmRleChsaXN0Q29udGVudCwgc3RyaW5nUmVmLmN1cnJlbnQpID09PSAtMSAmJiBldmVudC5rZXkgIT09ICcgJykge1xuICAgICAgICBvblR5cGluZz8uKGZhbHNlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKGxpc3RDb250ZW50ID09IG51bGwgfHxcbiAgICAvLyBDaGFyYWN0ZXIga2V5LlxuICAgIGV2ZW50LmtleS5sZW5ndGggIT09IDEgfHxcbiAgICAvLyBNb2RpZmllciBrZXkuXG4gICAgZXZlbnQuY3RybEtleSB8fCBldmVudC5tZXRhS2V5IHx8IGV2ZW50LmFsdEtleSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAob3BlbiAmJiBldmVudC5rZXkgIT09ICcgJykge1xuICAgICAgc3RvcEV2ZW50KGV2ZW50KTtcbiAgICAgIG9uVHlwaW5nPy4odHJ1ZSk7XG4gICAgfVxuXG4gICAgLy8gQ2FwdHVyZSB3aGV0aGVyIHRoaXMgaXMgYSBuZXcgdHlwaW5nIHNlc3Npb24gYmVmb3JlIG11dGF0aW5nIHRoZSBzdHJpbmcuXG4gICAgY29uc3QgaXNOZXdTZXNzaW9uID0gc3RyaW5nUmVmLmN1cnJlbnQgPT09ICcnO1xuICAgIGlmIChpc05ld1Nlc3Npb24pIHtcbiAgICAgIHByZXZJbmRleFJlZi5jdXJyZW50ID0gc2VsZWN0ZWRJbmRleCA/PyBhY3RpdmVJbmRleCA/PyAtMTtcbiAgICB9XG5cbiAgICAvLyBCYWlsIG91dCBpZiB0aGUgbGlzdCBjb250YWlucyBhIHdvcmQgbGlrZSBcImxsYW1hXCIgb3IgXCJhYXJvblwiLiBUT0RPOlxuICAgIC8vIGFsbG93IGl0IGluIHRoaXMgY2FzZSwgdG9vLiBVbmF2YWlsYWJsZSBpdGVtcyBhcmUgc2tpcHBlZCB3aGlsZSBtYXRjaGluZywgc29cbiAgICAvLyB0aGV5IG11c3QgYmUgaWdub3JlZCBoZXJlIGFzIHdlbGwg4oCUIG90aGVyd2lzZSBhIGhpZGRlbiBvciBkaXNhYmxlZCBkb3VibGUtbGV0dGVyXG4gICAgLy8gbGFiZWwgd291bGQgYmxvY2sgcmFwaWQgY3ljbGluZyB0aHJvdWdoIHRoZSBhdmFpbGFibGUgaXRlbXMuXG4gICAgY29uc3QgYWxsb3dSYXBpZFN1Y2Nlc3Npb25PZkZpcnN0TGV0dGVyID0gbGlzdENvbnRlbnQuZXZlcnkoKHRleHQsIGluZGV4KSA9PiB0ZXh0ICYmIGlzSXRlbUF2YWlsYWJsZShpbmRleCkgPyB0ZXh0WzBdPy50b0xvd2VyQ2FzZSgpICE9PSB0ZXh0WzFdPy50b0xvd2VyQ2FzZSgpIDogdHJ1ZSk7XG5cbiAgICAvLyBBbGxvd3MgdGhlIHVzZXIgdG8gY3ljbGUgdGhyb3VnaCBpdGVtcyB0aGF0IHN0YXJ0IHdpdGggdGhlIHNhbWUgbGV0dGVyXG4gICAgLy8gaW4gcmFwaWQgc3VjY2Vzc2lvbi5cbiAgICBpZiAoYWxsb3dSYXBpZFN1Y2Nlc3Npb25PZkZpcnN0TGV0dGVyICYmIHN0cmluZ1JlZi5jdXJyZW50ID09PSBldmVudC5rZXkpIHtcbiAgICAgIHN0cmluZ1JlZi5jdXJyZW50ID0gJyc7XG4gICAgICBwcmV2SW5kZXhSZWYuY3VycmVudCA9IG1hdGNoSW5kZXhSZWYuY3VycmVudDtcbiAgICB9XG4gICAgc3RyaW5nUmVmLmN1cnJlbnQgKz0gZXZlbnQua2V5O1xuICAgIHRpbWVvdXQuc3RhcnQocmVzZXRNcywgKCkgPT4ge1xuICAgICAgc3RyaW5nUmVmLmN1cnJlbnQgPSAnJztcbiAgICAgIHByZXZJbmRleFJlZi5jdXJyZW50ID0gbWF0Y2hJbmRleFJlZi5jdXJyZW50O1xuICAgICAgb25UeXBpbmc/LihmYWxzZSk7XG4gICAgfSk7XG5cbiAgICAvLyBDb21wdXRlIHRoZSBzdGFydGluZyBpbmRleCBmb3IgdGhpcyBzZWFyY2guXG4gICAgLy8gSWYgdGhpcyBpcyBhIG5ldyB0eXBpbmcgc2Vzc2lvbiAoc3RyaW5nIGlzIGVtcHR5KSwgYmFzZSBpdCBvbiB0aGUgY3VycmVudFxuICAgIC8vIHNlbGVjdGlvbi9hY3RpdmUgaXRlbTsgb3RoZXJ3aXNlIGNvbnRpbnVlIGZyb20gdGhlIGxhc3QgbWF0Y2hlZCBpbmRleC5cbiAgICBjb25zdCBwcmV2SW5kZXggPSBpc05ld1Nlc3Npb24gPyBzZWxlY3RlZEluZGV4ID8/IGFjdGl2ZUluZGV4ID8/IC0xIDogcHJldkluZGV4UmVmLmN1cnJlbnQ7XG4gICAgY29uc3Qgc3RhcnRJbmRleCA9IChwcmV2SW5kZXggPz8gMCkgKyAxO1xuICAgIGNvbnN0IGluZGV4ID0gZ2V0TWF0Y2hpbmdJbmRleChsaXN0Q29udGVudCwgc3RyaW5nUmVmLmN1cnJlbnQsIHN0YXJ0SW5kZXgpO1xuICAgIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICAgIG9uTWF0Y2hQcm9wPy4oaW5kZXgsIGV2ZW50KTtcbiAgICAgIG1hdGNoSW5kZXhSZWYuY3VycmVudCA9IGluZGV4O1xuICAgIH0gZWxzZSBpZiAoZXZlbnQua2V5ICE9PSAnICcpIHtcbiAgICAgIHN0cmluZ1JlZi5jdXJyZW50ID0gJyc7XG4gICAgICBvblR5cGluZz8uKGZhbHNlKTtcbiAgICB9XG4gIH0pO1xuICBjb25zdCBvbkJsdXIgPSB1c2VTdGFibGVDYWxsYmFjayhldmVudCA9PiB7XG4gICAgY29uc3QgbmV4dCA9IGV2ZW50LnJlbGF0ZWRUYXJnZXQ7XG4gICAgY29uc3QgY3VycmVudERvbVJlZmVyZW5jZUVsZW1lbnQgPSBzdG9yZS5zZWxlY3QoJ2RvbVJlZmVyZW5jZUVsZW1lbnQnKTtcbiAgICBjb25zdCBjdXJyZW50RmxvYXRpbmdFbGVtZW50ID0gc3RvcmUuc2VsZWN0KCdmbG9hdGluZ0VsZW1lbnQnKTtcbiAgICBjb25zdCB3aXRoaW5Db21wb3NpdGUgPSBjb250YWlucyhjdXJyZW50RG9tUmVmZXJlbmNlRWxlbWVudCwgbmV4dCkgfHwgY29udGFpbnMoY3VycmVudEZsb2F0aW5nRWxlbWVudCwgbmV4dCk7XG5cbiAgICAvLyBLZWVwIHRoZSBzZXNzaW9uIGlmIGZvY3VzIG1vdmVzIHdpdGhpbiB0aGUgY29tcG9zaXRlIChyZWZlcmVuY2UgPC0+IGZsb2F0aW5nKS5cbiAgICBpZiAod2l0aGluQ29tcG9zaXRlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gRW5kIHRoZSBjdXJyZW50IHR5cGluZyBzZXNzaW9uIHdoZW4gZm9jdXMgbGVhdmVzIHRoZSBjb21wb3NpdGUgZW50aXJlbHkuXG4gICAgdGltZW91dC5jbGVhcigpO1xuICAgIHN0cmluZ1JlZi5jdXJyZW50ID0gJyc7XG4gICAgcHJldkluZGV4UmVmLmN1cnJlbnQgPSBtYXRjaEluZGV4UmVmLmN1cnJlbnQ7XG4gICAgb25UeXBpbmc/LihmYWxzZSk7XG4gIH0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghb3BlbiAmJiBzZWxlY3RlZEluZGV4ICE9PSBudWxsKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRpbWVvdXQuY2xlYXIoKTtcbiAgICBtYXRjaEluZGV4UmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIGlmIChzdHJpbmdSZWYuY3VycmVudCAhPT0gJycpIHtcbiAgICAgIHN0cmluZ1JlZi5jdXJyZW50ID0gJyc7XG4gICAgICBvblR5cGluZz8uKGZhbHNlKTtcbiAgICB9XG4gIH0sIFtvcGVuLCBzZWxlY3RlZEluZGV4LCB0aW1lb3V0LCBvblR5cGluZ10pO1xuICBjb25zdCBzaGFyZWRQcm9wcyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBvbktleURvd24sXG4gICAgb25CbHVyXG4gIH0pLCBbb25LZXlEb3duLCBvbkJsdXJdKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gZW5hYmxlZCA/IHtcbiAgICByZWZlcmVuY2U6IHNoYXJlZFByb3BzLFxuICAgIGZsb2F0aW5nOiBzaGFyZWRQcm9wc1xuICB9IDoge30sIFtlbmFibGVkLCBzaGFyZWRQcm9wc10pO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IFRvb2xiYXJSb290Q29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHVuZGVmaW5lZCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBUb29sYmFyUm9vdENvbnRleHQuZGlzcGxheU5hbWUgPSBcIlRvb2xiYXJSb290Q29udGV4dFwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVRvb2xiYXJSb290Q29udGV4dChvcHRpb25hbCkge1xuICBjb25zdCBjb250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChUb29sYmFyUm9vdENvbnRleHQpO1xuICBpZiAoY29udGV4dCA9PT0gdW5kZWZpbmVkICYmICFvcHRpb25hbCkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAnQmFzZSBVSTogVG9vbGJhclJvb3RDb250ZXh0IGlzIG1pc3NpbmcuIFRvb2xiYXIgcGFydHMgbXVzdCBiZSBwbGFjZWQgd2l0aGluIDxUb29sYmFyLlJvb3Q+LicgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDY5KSk7XG4gIH1cbiAgcmV0dXJuIGNvbnRleHQ7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBvd25lckRvY3VtZW50IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvb3duZXInO1xuaW1wb3J0IHsgdXNlU2Nyb2xsTG9jayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVNjcm9sbExvY2snO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcblxuLy8gVG91Y2gtb3BlbmVkIHBvcHVwcyBub3JtYWxseSBhdm9pZCBzY3JvbGwgbG9ja2luZyBzbyB1c2VycyBjYW4gc3RpbGwgc3dpcGUgb3V0c2lkZSB0byBkaXNtaXNzLlxuLy8gVGhpcyBob29rIHJlLWVuYWJsZXMgc2Nyb2xsIGxvY2sgb25seSB3aGVuIHRoZSBwb3B1cCBpcyBlZmZlY3RpdmVseSBmdWxsLXdpZHRoLlxuLy8gVHJlYXQgcG9wdXBzIHdpdGggdXAgdG8gMjBweCBvZiB0b3RhbCBob3Jpem9udGFsIGd1dHRlciBhcyBmdWxsLXdpZHRoIHNvIGNvbW1vbiB+MTBweCBzaWRlXG4vLyBwYWRkaW5nIHN0aWxsIGxvY2tzIHNjcm9sbCwgc2luY2UgdGhhdCBsZWF2ZXMgdG9vIGxpdHRsZSBvdXRzaWRlIHNwYWNlIGZvciBhIHJlbGlhYmxlIHN3aXBlLlxuY29uc3QgVklFV1BPUlRfV0lEVEhfVE9MRVJBTkNFX1BYID0gMjA7XG5cbi8qKlxuICogTWFuYWdlcyBzY3JvbGwgbG9jayBmb3IgYW5jaG9yZWQgcG9wdXBzLiBGb3Igbm9uLXRvdWNoIG9wZW5zLCBzY3JvbGwgbG9jayBpcyBhcHBsaWVkIHdoZW5cbiAqIGVuYWJsZWQuIEZvciB0b3VjaCBvcGVucywgc2Nyb2xsIGxvY2sgaXMgYXBwbGllZCBvbmx5IHdoZW4gdGhlIHBvc2l0aW9uZXIgd2lkdGggaXMgZWZmZWN0aXZlbHlcbiAqIHZpZXdwb3J0LXNpemVkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlQW5jaG9yZWRQb3B1cFNjcm9sbExvY2soZW5hYmxlZCwgdG91Y2hPcGVuLCBwb3NpdGlvbmVyRWxlbWVudCwgcmVmZXJlbmNlRWxlbWVudCkge1xuICBjb25zdCBbdG91Y2hPcGVuU2hvdWxkTG9ja1Njcm9sbCwgc2V0VG91Y2hPcGVuU2hvdWxkTG9ja1Njcm9sbF0gPSBSZWFjdC51c2VTdGF0ZShmYWxzZSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFlbmFibGVkIHx8ICF0b3VjaE9wZW4gfHwgcG9zaXRpb25lckVsZW1lbnQgPT0gbnVsbCkge1xuICAgICAgc2V0VG91Y2hPcGVuU2hvdWxkTG9ja1Njcm9sbChmYWxzZSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHZpZXdwb3J0V2lkdGggPSBvd25lckRvY3VtZW50KHBvc2l0aW9uZXJFbGVtZW50KS5kb2N1bWVudEVsZW1lbnQuY2xpZW50V2lkdGg7XG4gICAgY29uc3QgcG9wdXBXaWR0aCA9IHBvc2l0aW9uZXJFbGVtZW50Lm9mZnNldFdpZHRoO1xuICAgIHNldFRvdWNoT3BlblNob3VsZExvY2tTY3JvbGwodmlld3BvcnRXaWR0aCA+IDAgJiYgcG9wdXBXaWR0aCA+IDAgJiYgcG9wdXBXaWR0aCA+PSB2aWV3cG9ydFdpZHRoIC0gVklFV1BPUlRfV0lEVEhfVE9MRVJBTkNFX1BYKTtcbiAgfSwgW2VuYWJsZWQsIHRvdWNoT3BlbiwgcG9zaXRpb25lckVsZW1lbnRdKTtcbiAgdXNlU2Nyb2xsTG9jayhlbmFibGVkICYmICghdG91Y2hPcGVuIHx8IHRvdWNoT3BlblNob3VsZExvY2tTY3JvbGwpLCByZWZlcmVuY2VFbGVtZW50KTtcbn0iLCJpbXBvcnQgeyBvd25lcldpbmRvdyB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL293bmVyJztcbmltcG9ydCB7IHBsYXRmb3JtIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvcGxhdGZvcm0nO1xuLy8gVG9sZXJhbmNlIGFyb3VuZCB0aGUgZWxlbWVudCBib3VuZHMgc28gYSBmYXN0IGNsaWNrIHdob3NlIHBvaW50ZXIgZHJpZnRzIHNsaWdodGx5XG4vLyBkdXJpbmcgcHJlc3MtcmVsZWFzZSBpc24ndCBtaXN0YWtlbiBmb3IgYSBkcmFnLW9mZi1hbmQtcmVsZWFzZSBjYW5jZWxsYXRpb24uXG4vLyBNYXRjaGVzIHR5cGljYWwgT1MvYnJvd3NlciBkcmFnLWluaXRpYXRpb24gdGhyZXNob2xkcy5cbmNvbnN0IEJPVU5EQVJZX09GRlNFVCA9IDU7XG5cbi8qKlxuICogRGV0ZXJtaW5lcyBpZiBhIG1vdXNlIGV2ZW50IG9jY3VycmVkIHdpdGhpbiB0aGUgYm91bmRzIG9mIGFuIGVsZW1lbnRcbiAqIChpbmNsdWRpbmcgaXRzIHBzZXVkby1lbGVtZW50cyksIHdpdGggYSBzbWFsbCB0b2xlcmFuY2UgZm9yIHBvaW50ZXIgZHJpZnQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc01vdXNlV2l0aGluQm91bmRzKGV2ZW50LCBlbGVtZW50KSB7XG4gIGNvbnN0IGJvdW5kcyA9IGdldFBzZXVkb0VsZW1lbnRCb3VuZHMoZWxlbWVudCk7XG4gIHJldHVybiBldmVudC5jbGllbnRYID49IGJvdW5kcy5sZWZ0IC0gQk9VTkRBUllfT0ZGU0VUICYmIGV2ZW50LmNsaWVudFggPD0gYm91bmRzLnJpZ2h0ICsgQk9VTkRBUllfT0ZGU0VUICYmIGV2ZW50LmNsaWVudFkgPj0gYm91bmRzLnRvcCAtIEJPVU5EQVJZX09GRlNFVCAmJiBldmVudC5jbGllbnRZIDw9IGJvdW5kcy5ib3R0b20gKyBCT1VOREFSWV9PRkZTRVQ7XG59XG5leHBvcnQgZnVuY3Rpb24gZ2V0UHNldWRvRWxlbWVudEJvdW5kcyhlbGVtZW50KSB7XG4gIGNvbnN0IGVsZW1lbnRSZWN0ID0gZWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgY29uc3Qgd2luID0gb3duZXJXaW5kb3coZWxlbWVudCk7XG5cbiAgLy8gQXZvaWQgXCJOb3QgaW1wbGVtZW50ZWQ6IHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlKGVsdCwgcHNldWRvRWx0KVwiIGluIGpzZG9tLlxuICBpZiAocGxhdGZvcm0uZW52LmpzZG9tKSB7XG4gICAgcmV0dXJuIGVsZW1lbnRSZWN0O1xuICB9XG4gIGNvbnN0IGJlZm9yZVN0eWxlcyA9IHdpbi5nZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQsICc6OmJlZm9yZScpO1xuICBjb25zdCBhZnRlclN0eWxlcyA9IHdpbi5nZXRDb21wdXRlZFN0eWxlKGVsZW1lbnQsICc6OmFmdGVyJyk7XG4gIGNvbnN0IGhhc1BzZXVkb0VsZW1lbnRzID0gYmVmb3JlU3R5bGVzLmNvbnRlbnQgIT09ICdub25lJyB8fCBhZnRlclN0eWxlcy5jb250ZW50ICE9PSAnbm9uZSc7XG4gIGlmICghaGFzUHNldWRvRWxlbWVudHMpIHtcbiAgICByZXR1cm4gZWxlbWVudFJlY3Q7XG4gIH1cblxuICAvLyBHZXQgZGltZW5zaW9ucyBvZiBwc2V1ZG8tZWxlbWVudHNcbiAgY29uc3QgYmVmb3JlV2lkdGggPSBwYXJzZUZsb2F0KGJlZm9yZVN0eWxlcy53aWR0aCkgfHwgMDtcbiAgY29uc3QgYmVmb3JlSGVpZ2h0ID0gcGFyc2VGbG9hdChiZWZvcmVTdHlsZXMuaGVpZ2h0KSB8fCAwO1xuICBjb25zdCBhZnRlcldpZHRoID0gcGFyc2VGbG9hdChhZnRlclN0eWxlcy53aWR0aCkgfHwgMDtcbiAgY29uc3QgYWZ0ZXJIZWlnaHQgPSBwYXJzZUZsb2F0KGFmdGVyU3R5bGVzLmhlaWdodCkgfHwgMDtcblxuICAvLyBDYWxjdWxhdGUgbWF4IGRpbWVuc2lvbnMgaW5jbHVkaW5nIHBzZXVkby1lbGVtZW50c1xuICBjb25zdCB0b3RhbFdpZHRoID0gTWF0aC5tYXgoZWxlbWVudFJlY3Qud2lkdGgsIGJlZm9yZVdpZHRoLCBhZnRlcldpZHRoKTtcbiAgY29uc3QgdG90YWxIZWlnaHQgPSBNYXRoLm1heChlbGVtZW50UmVjdC5oZWlnaHQsIGJlZm9yZUhlaWdodCwgYWZ0ZXJIZWlnaHQpO1xuXG4gIC8vIENhbGN1bGF0ZSB0aGUgZGlmZmVyZW5jZXMgdG8gZXh0ZW5kIHRoZSBib3VuZHNcbiAgY29uc3Qgd2lkdGhEaWZmID0gdG90YWxXaWR0aCAtIGVsZW1lbnRSZWN0LndpZHRoO1xuICBjb25zdCBoZWlnaHREaWZmID0gdG90YWxIZWlnaHQgLSBlbGVtZW50UmVjdC5oZWlnaHQ7XG4gIHJldHVybiB7XG4gICAgbGVmdDogZWxlbWVudFJlY3QubGVmdCAtIHdpZHRoRGlmZiAvIDIsXG4gICAgcmlnaHQ6IGVsZW1lbnRSZWN0LnJpZ2h0ICsgd2lkdGhEaWZmIC8gMixcbiAgICB0b3A6IGVsZW1lbnRSZWN0LnRvcCAtIGhlaWdodERpZmYgLyAyLFxuICAgIGJvdHRvbTogZWxlbWVudFJlY3QuYm90dG9tICsgaGVpZ2h0RGlmZiAvIDJcbiAgfTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHNlcmlhbGl6ZVZhbHVlIH0gZnJvbSBcIi4vc2VyaWFsaXplVmFsdWUubWpzXCI7XG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZnVuY3Rpb24gaXNHcm91cChpdGVtKSB7XG4gIHJldHVybiB0eXBlb2YgaXRlbSA9PT0gJ29iamVjdCcgJiYgaXRlbSAhPSBudWxsICYmIEFycmF5LmlzQXJyYXkoaXRlbS5pdGVtcyk7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNHcm91cGVkSXRlbXMoaXRlbXMpIHtcbiAgLy8gQSBncm91cCBtdXN0IGNhcnJ5IGFuIGFjdHVhbCBgaXRlbXNgIGFycmF5OiBrZXkgcHJlc2VuY2UgYWxvbmUgd291bGQgbWlzY2xhc3NpZnkgYW4gaXRlbVxuICAvLyB3aXRoIGFuIHVucmVsYXRlZCBvciBvcHRpb25hbCBgaXRlbXNgIGZpZWxkLlxuICByZXR1cm4gaXNHcm91cChpdGVtcz8uWzBdKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBmbGF0dGVuTGVhZkl0ZW1zKGl0ZW1zKSB7XG4gIHJldHVybiBpc0dyb3VwZWRJdGVtcyhpdGVtcykgPyBpdGVtcy5mbGF0TWFwKGdyb3VwID0+IGdyb3VwLml0ZW1zKSA6IGl0ZW1zO1xufVxuXG4vKipcbiAqIENoZWNrcyBpZiB0aGUgaXRlbXMgYXJyYXkgY29udGFpbnMgYW4gaXRlbSB3aXRoIGEgbnVsbCB2YWx1ZSB0aGF0IGhhcyBhIG5vbi1udWxsIGxhYmVsLlxuICovXG5leHBvcnQgZnVuY3Rpb24gaGFzTnVsbEl0ZW1MYWJlbChpdGVtcykge1xuICBpZiAoIUFycmF5LmlzQXJyYXkoaXRlbXMpKSB7XG4gICAgcmV0dXJuIGl0ZW1zICE9IG51bGwgJiYgJ251bGwnIGluIGl0ZW1zO1xuICB9XG4gIGNvbnN0IGFycmF5SXRlbXMgPSBpdGVtcztcbiAgaWYgKGlzR3JvdXBlZEl0ZW1zKGFycmF5SXRlbXMpKSB7XG4gICAgZm9yIChjb25zdCBncm91cCBvZiBhcnJheUl0ZW1zKSB7XG4gICAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgZ3JvdXAuaXRlbXMpIHtcbiAgICAgICAgaWYgKGl0ZW0gJiYgaXRlbS52YWx1ZSA9PSBudWxsICYmIGl0ZW0ubGFiZWwgIT0gbnVsbCkge1xuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBmb3IgKGNvbnN0IGl0ZW0gb2YgYXJyYXlJdGVtcykge1xuICAgIGlmIChpdGVtICYmIGl0ZW0udmFsdWUgPT0gbnVsbCAmJiBpdGVtLmxhYmVsICE9IG51bGwpIHtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gZmFsc2U7XG59XG5leHBvcnQgZnVuY3Rpb24gc3RyaW5naWZ5QXNMYWJlbChpdGVtLCBpdGVtVG9TdHJpbmdMYWJlbCkge1xuICBpZiAoaXRlbVRvU3RyaW5nTGFiZWwgJiYgaXRlbSAhPSBudWxsKSB7XG4gICAgcmV0dXJuIGl0ZW1Ub1N0cmluZ0xhYmVsKGl0ZW0pID8/ICcnO1xuICB9XG4gIGlmIChpdGVtICYmIHR5cGVvZiBpdGVtID09PSAnb2JqZWN0Jykge1xuICAgIGlmICgnbGFiZWwnIGluIGl0ZW0gJiYgaXRlbS5sYWJlbCAhPSBudWxsKSB7XG4gICAgICByZXR1cm4gU3RyaW5nKGl0ZW0ubGFiZWwpO1xuICAgIH1cbiAgICBpZiAoJ3ZhbHVlJyBpbiBpdGVtKSB7XG4gICAgICByZXR1cm4gU3RyaW5nKGl0ZW0udmFsdWUpO1xuICAgIH1cbiAgfVxuICByZXR1cm4gc2VyaWFsaXplVmFsdWUoaXRlbSk7XG59XG5leHBvcnQgZnVuY3Rpb24gc3RyaW5naWZ5QXNWYWx1ZShpdGVtLCBpdGVtVG9TdHJpbmdWYWx1ZSkge1xuICBpZiAoaXRlbVRvU3RyaW5nVmFsdWUgJiYgaXRlbSAhPSBudWxsKSB7XG4gICAgcmV0dXJuIGl0ZW1Ub1N0cmluZ1ZhbHVlKGl0ZW0pID8/ICcnO1xuICB9XG4gIGlmIChpdGVtICYmIHR5cGVvZiBpdGVtID09PSAnb2JqZWN0JyAmJiAndmFsdWUnIGluIGl0ZW0gJiYgJ2xhYmVsJyBpbiBpdGVtKSB7XG4gICAgcmV0dXJuIHNlcmlhbGl6ZVZhbHVlKGl0ZW0udmFsdWUpO1xuICB9XG4gIHJldHVybiBzZXJpYWxpemVWYWx1ZShpdGVtKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlU2VsZWN0ZWRMYWJlbCh2YWx1ZSwgaXRlbXMsIGl0ZW1Ub1N0cmluZ0xhYmVsKSB7XG4gIGZ1bmN0aW9uIGZhbGxiYWNrKCkge1xuICAgIHJldHVybiBzdHJpbmdpZnlBc0xhYmVsKHZhbHVlLCBpdGVtVG9TdHJpbmdMYWJlbCk7XG4gIH1cbiAgaWYgKGl0ZW1Ub1N0cmluZ0xhYmVsICYmIHZhbHVlICE9IG51bGwpIHtcbiAgICByZXR1cm4gaXRlbVRvU3RyaW5nTGFiZWwodmFsdWUpO1xuICB9XG5cbiAgLy8gQ3VzdG9tIG9iamVjdCB3aXRoIGV4cGxpY2l0IGxhYmVsIHRha2VzIHByZWNlZGVuY2VcbiAgaWYgKHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgJ2xhYmVsJyBpbiB2YWx1ZSAmJiB2YWx1ZS5sYWJlbCAhPSBudWxsKSB7XG4gICAgcmV0dXJuIHZhbHVlLmxhYmVsO1xuICB9XG5cbiAgLy8gSXRlbXMgcHJvdmlkZWQgYXMgcGxhaW4gcmVjb3JkIG1hcFxuICBpZiAoaXRlbXMgJiYgIUFycmF5LmlzQXJyYXkoaXRlbXMpKSB7XG4gICAgY29uc3QgbGFiZWwgPSBPYmplY3QuaGFzT3duKGl0ZW1zLCB2YWx1ZSkgPyBpdGVtc1t2YWx1ZV0gOiB1bmRlZmluZWQ7XG4gICAgcmV0dXJuIGxhYmVsID8/IGZhbGxiYWNrKCk7XG4gIH1cblxuICAvLyBJdGVtcyBwcm92aWRlZCBhcyBhcnJheSAoZmxhdCBvciBncm91cGVkKVxuICBpZiAoQXJyYXkuaXNBcnJheShpdGVtcykpIHtcbiAgICBjb25zdCBhcnJheUl0ZW1zID0gaXRlbXM7XG4gICAgY29uc3QgZmxhdEl0ZW1zID0gZmxhdHRlbkxlYWZJdGVtcyhhcnJheUl0ZW1zKTtcbiAgICBpZiAodmFsdWUgPT0gbnVsbCB8fCB0eXBlb2YgdmFsdWUgIT09ICdvYmplY3QnKSB7XG4gICAgICBjb25zdCBtYXRjaCA9IGZsYXRJdGVtcy5maW5kKGl0ZW0gPT4gaXRlbS52YWx1ZSA9PT0gdmFsdWUpO1xuICAgICAgaWYgKG1hdGNoICYmIG1hdGNoLmxhYmVsICE9IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIG1hdGNoLmxhYmVsO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbGxiYWNrKCk7XG4gICAgfVxuXG4gICAgLy8gT2JqZWN0IHdpdGhvdXQgZXhwbGljaXQgbGFiZWw6IHRyeSBtYXRjaGluZyBieSBpdHMgYHZhbHVlYCBwcm9wZXJ0eVxuICAgIGlmICgndmFsdWUnIGluIHZhbHVlKSB7XG4gICAgICBjb25zdCBtYXRjaCA9IGZsYXRJdGVtcy5maW5kKGl0ZW0gPT4gaXRlbSAmJiBpdGVtLnZhbHVlID09PSB2YWx1ZS52YWx1ZSk7XG4gICAgICBpZiAobWF0Y2ggJiYgbWF0Y2gubGFiZWwgIT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gbWF0Y2gubGFiZWw7XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBmYWxsYmFjaygpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHJlc29sdmVNdWx0aXBsZUxhYmVscyh2YWx1ZXMsIGl0ZW1zLCBpdGVtVG9TdHJpbmdMYWJlbCkge1xuICByZXR1cm4gdmFsdWVzLnJlZHVjZSgoYWNjLCB2YWx1ZSwgaW5kZXgpID0+IHtcbiAgICBpZiAoaW5kZXggPiAwKSB7XG4gICAgICBhY2MucHVzaCgnLCAnKTtcbiAgICB9XG4gICAgYWNjLnB1c2goLyojX19QVVJFX18qL19qc3goUmVhY3QuRnJhZ21lbnQsIHtcbiAgICAgIGNoaWxkcmVuOiByZXNvbHZlU2VsZWN0ZWRMYWJlbCh2YWx1ZSwgaXRlbXMsIGl0ZW1Ub1N0cmluZ0xhYmVsKVxuICAgIH0sIGluZGV4KSk7XG4gICAgcmV0dXJuIGFjYztcbiAgfSwgW10pO1xufSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQXNCQSxTQUFTLDBCQUEwQixPQUFPO0NBQ3hDLE9BQU9BLFVBQTBCLE1BQU0sY0FBYyxLQUFLLE1BQU0sY0FBYztBQUNoRjtBQUNBLFNBQVMsU0FBUyxhQUFhLFVBQVUsWUFBWTtDQUNuRCxRQUFRLGFBQVI7RUFDRSxLQUFLLFlBQ0gsT0FBTztFQUNULEtBQUssY0FDSCxPQUFPO0VBQ1QsU0FDRSxPQUFPLFlBQVk7Q0FDdkI7QUFDRjtBQUNBLFNBQWdCLHFCQUFxQixLQUFLLGFBQWE7Q0FHckQsT0FBTyxTQUFTLGFBRkMsUUFBQSxhQUFvQixRQUFBLGFBQ2xCLFFBQUEsZUFBc0IsUUFBQSxZQUNRO0FBQ25EO0FBQ0EsU0FBZ0IsMEJBQTBCLEtBQUssYUFBYSxLQUFLO0NBRy9ELE9BQU8sU0FBUyxhQUZDLFFBQUEsYUFDRSxNQUFNLFFBQUEsY0FBcUIsUUFBQSxZQUNHLEtBQUssUUFBUSxXQUFXLFFBQVEsT0FBTyxRQUFRO0FBQ2xHO0FBQ0EsU0FBZ0IsMEJBQTBCLEtBQUssYUFBYSxLQUFLO0NBRy9ELE9BQU8sU0FBUyxhQUZDLE1BQU0sUUFBUSxhQUFhLFFBQVEsYUFDakMsUUFBUSxVQUNzQjtBQUNuRDtBQUNBLFNBQWdCLDJCQUEyQixLQUFLLGFBQWEsS0FBSyxNQUFNO0NBQ3RFLE1BQU0sV0FBVyxNQUFNLFFBQVEsY0FBYyxRQUFRO0NBQ3JELE1BQU0sYUFBYSxRQUFRO0NBQzNCLElBQUksZ0JBQWdCLFVBQVUsZ0JBQWdCLGdCQUFnQixNQUM1RCxPQUFPLFFBQVE7Q0FFakIsT0FBTyxTQUFTLGFBQWEsVUFBVSxVQUFVO0FBQ25EOzs7Ozs7QUFNQSxTQUFnQixrQkFBa0IsT0FBTyxPQUFPO0NBQzlDLE1BQU0sRUFDSixTQUNBLGFBQ0EsWUFBWSx1QkFBdUIsQ0FBQyxHQUNwQyxVQUFVLE1BQ1YsZ0JBQWdCLE1BQ2hCLGNBQWMsT0FDZCxZQUFZLE9BQ1osU0FBUyxPQUNULE1BQU0sT0FDTixVQUFVLE9BQ1Ysa0JBQWtCLFFBQ2xCLG1CQUFtQixNQUNuQixxQkFBcUIsTUFDckIsa0JBQWtCLEtBQUEsR0FDbEIsY0FBYyxZQUNkLHFCQUFxQixhQUNyQixtQkFDQSxJQUNBLHNCQUFzQixNQUN0QixjQUNBLHNCQUNBLE1BQU0saUJBQ0o7Q0FDSixNQUFNLFNBQVMsZ0JBQWdCO0NBRTdCLElBQUksYUFBYTtFQUNmLElBQUksQ0FBQyxXQUNILFFBQVEsS0FBSyxnRUFBZ0U7RUFFL0UsSUFBSSxDQUFDLFNBQ0gsUUFBUSxLQUFLLHdEQUF3RDtDQUV6RTtDQUNBLElBQUksZ0JBQWdCLGNBQWMsUUFDaEMsUUFBUSxLQUFLLDBEQUEwRCx1Q0FBbUM7Q0FHOUcsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sa0JBQWtCLE1BQU0sU0FBUyxpQkFBaUI7Q0FDeEQsTUFBTSxzQkFBc0IsTUFBTSxTQUFTLHFCQUFxQjtDQUNoRSxNQUFNLFVBQVUsTUFBTSxRQUFRO0NBQzlCLE1BQU0sdUJBQXVCLHdCQUF3QixlQUFlO0NBQ3BFLE1BQU0sNEJBQTRCLG1CQUFtQixtQkFBbUI7Q0FDeEUsTUFBTSwwQkFBMEIsY0FBYyxvQkFBb0I7Q0FDbEUsTUFBTSxXQUFXLHdCQUF3QjtDQUN6QyxNQUFNLE9BQU8sZ0JBQWdCLFlBQVk7Q0FDekMsTUFBTSxxQkFBQSxhQUEyQixPQUFPLGVBQWU7Q0FDdkQsTUFBTSxXQUFBLGFBQWlCLE9BQU8saUJBQWlCLEVBQUU7Q0FDakQsTUFBTSxTQUFBLGFBQWUsT0FBTyxJQUFJO0NBQ2hDLE1BQU0sdUJBQUEsYUFBNkIsT0FBTyxJQUFJO0NBQzlDLE1BQU0sYUFBYSxtQkFBa0IsVUFBUztFQUM1QyxlQUFlLFNBQVMsWUFBWSxLQUFLLE9BQU8sU0FBUyxTQUFTLEtBQUs7Q0FDekUsQ0FBQztDQUNELE1BQU0scUJBQUEsYUFBMkIsT0FBTyxDQUFDLENBQUMsZUFBZTtDQUN6RCxNQUFNLGtCQUFBLGFBQXdCLE9BQU8sSUFBSTtDQUN6QyxNQUFNLG9CQUFBLGFBQTBCLE9BQU8sS0FBSztDQUM1QyxNQUFNLHlCQUFBLGFBQStCLE9BQU8sS0FBSztDQUNqRCxNQUFNLHVCQUFBLGFBQTZCLE9BQU8sSUFBSTtDQUM5QyxNQUFNLHFCQUFxQixjQUFjLGVBQWU7Q0FDeEQsTUFBTSxnQkFBZ0IsY0FBYyxJQUFJO0NBQ3hDLE1BQU0sbUJBQW1CLGNBQWMsYUFBYTtDQUNwRCxNQUFNLHlCQUF5QixjQUFjLG1CQUFtQjtDQUNoRSxNQUFNLGFBQWEsa0JBQWtCO0NBQ3JDLE1BQU0sNEJBQTRCLGtCQUFrQjtDQUNwRCxNQUFNLFlBQVksd0JBQXdCO0VBRXhDLFdBQVcsT0FBTztFQUNsQixTQUFTLFNBQVMsTUFBTTtHQUN0QixJQUFJLENBQUMsU0FDSCxxQkFBcUIsVUFBVSxhQUFhLE1BQU07SUFDaEQsTUFBTSxrQkFBa0I7SUFDeEIsZUFBZTtHQUNqQixDQUFDO0VBRUw7RUFDQSxNQUFNLGNBQWMsUUFBUSxRQUFRLFNBQVM7RUFDN0MsTUFBTSxzQkFBc0IsdUJBQXVCO0VBQ25ELElBQUksYUFDRixTQUFTLFdBQVc7RUFHdEIsQ0FEa0Isa0JBQWtCLFdBQVUsYUFBWSxTQUFTLEtBQUksYUFBWSxXQUFXLFFBQVEsUUFBUSxFQUFBLE9BQzlGO0dBQ2QsTUFBTSxhQUFhLFFBQVEsUUFBUSxTQUFTLFlBQVk7R0FDeEQsSUFBSSxDQUFDLFlBQ0g7R0FFRixJQUFJLENBQUMsYUFDSCxTQUFTLFVBQVU7R0FLckIsSUFEQSxTQUFTLHVCQUF1QixDQUFDLHFCQUFxQixVQUlwRCxXQUFXLGlCQUFpQjtJQUMxQixPQUFPO0lBQ1AsUUFBUTtHQUNWLENBQUM7RUFFTCxDQUFDO0NBQ0gsQ0FBQztDQUNELHlCQUF5QjtFQUN2QixRQUFRLFFBQVEsY0FBYztDQUNoQyxHQUFHLENBQUMsU0FBUyxXQUFXLENBQUM7Q0FDekIseUJBQXlCO0VBQ3ZCLElBQUksQ0FBQyxNQUNILE9BQU8sVUFBVTtFQUluQixJQUFJLENBQUMsUUFBUSxvQkFBb0IsUUFDL0IsbUJBQW1CLFVBQVU7Q0FFakMsR0FBRyxDQUFDLE1BQU0sZUFBZSxDQUFDO0NBSTFCLHlCQUF5QjtFQUN2QixJQUFJLENBQUMsU0FDSDtFQUVGLElBQUksUUFBUSxpQkFBaUI7R0FDM0IsU0FBUyxVQUFVLGlCQUFpQjtHQUNwQyxJQUFJLG1CQUFtQixXQUFXLGlCQUFpQixNQUFNO0lBR3ZELHVCQUF1QixVQUFVO0lBQ2pDLFdBQVc7R0FDYjtFQUNGLE9BQU8sSUFBSSxtQkFBbUIsU0FBUztHQUlyQyxTQUFTLFVBQVU7R0FDbkIsV0FBVztFQUNiO0NBQ0YsR0FBRztFQUFDO0VBQVM7RUFBTTtFQUFpQjtFQUFlO0NBQVUsQ0FBQztDQUk5RCx5QkFBeUI7RUFDdkIsSUFBSSxDQUFDLFNBQ0g7RUFFRixJQUFJLENBQUMsTUFBTTtHQUNULGtCQUFrQixVQUFVO0dBQzVCO0VBQ0Y7RUFDQSxJQUFJLENBQUMsaUJBQ0g7RUFFRixJQUFJLGVBQWUsTUFBTTtHQUN2QixrQkFBa0IsVUFBVTtHQUM1QixJQUFJLGlCQUFpQixXQUFXLE1BQzlCO0dBSUYsSUFBSSxtQkFBbUIsU0FBUztJQUM5QixTQUFTLFVBQVU7SUFDbkIsVUFBVTtHQUNaO0dBR0EsS0FBSyxDQUFDLGdCQUFnQixXQUFXLENBQUMsbUJBQW1CLFlBQVksbUJBQW1CLFlBQVksT0FBTyxXQUFXLFFBQVEsbUJBQW1CLFlBQVksUUFBUSxPQUFPLFdBQVcsT0FBTztJQUN4TCxJQUFJLE9BQU87SUFDWCxNQUFNLDZCQUE2QjtLQUNqQyxJQUFJLFFBQVEsUUFBUSxNQUFNLE1BQU07TUFJOUIsSUFBSSxPQUFPLEdBRVQsQ0FEa0IsUUFBTyxhQUFZLDBCQUEwQixRQUFRLFFBQVEsSUFBSSxlQUFBLENBQ3pFLG9CQUFvQjtNQUVoQyxRQUFRO0tBQ1YsT0FBTztNQU1MLFNBQVMsVUFBVSxPQUFPLFdBQVcsUUFBUSwwQkFBMEIsT0FBTyxTQUFTLG9CQUFvQixHQUFHLEtBQUssU0FBUyxnQkFBZ0IsT0FBTyxJQUFJLGdCQUFnQixPQUFPO01BQzlLLE9BQU8sVUFBVTtNQUNqQixXQUFXO0tBQ2I7SUFDRjtJQUNBLHFCQUFxQjtHQUN2QjtFQUNGLE9BQU8sSUFBSSxDQUFDLHVCQUF1QixRQUFRLFNBQVMsV0FBVyxHQUFHO0dBQ2hFLFNBQVMsVUFBVTtHQUNuQixVQUFVO0dBQ1YsdUJBQXVCLFVBQVU7RUFDbkM7Q0FDRixHQUFHO0VBQUM7RUFBUztFQUFNO0VBQWlCO0VBQWE7RUFBa0I7RUFBUTtFQUFTO0VBQW9CO0VBQUs7RUFBWTtFQUFXO0NBQXlCLENBQUM7Q0FJOUoseUJBQXlCO0VBQ3ZCLElBQUksQ0FBQyxXQUFXLG1CQUFtQixDQUFDLFFBQVEsV0FBVyxDQUFDLG1CQUFtQixTQUN6RTtFQUVGLE1BQU0sUUFBUSxLQUFLLFNBQVM7RUFDNUIsTUFBTSxTQUFTLE1BQU0sTUFBSyxTQUFRLEtBQUssT0FBTyxRQUFRLENBQUMsRUFBRSxTQUFTLFNBQVM7RUFJM0UsTUFBTSxXQUFXLGNBQWMsY0FBYyx1QkFBdUIsVUFBVSxJQUFJLENBQUM7RUFDbkYsTUFBTSx1QkFBdUIsTUFBTSxNQUFLLFNBQVEsS0FBSyxXQUFXLFNBQVMsS0FBSyxRQUFRLFNBQVMsVUFBVSxRQUFRLENBQUM7RUFDbEgsSUFBSSxVQUFVLENBQUMsd0JBQXdCLHFCQUFxQixTQUMxRCxPQUFPLE1BQU0sRUFDWCxlQUFlLEtBQ2pCLENBQUM7Q0FFTCxHQUFHO0VBQUM7RUFBUztFQUFpQjtFQUFxQjtFQUFNO0VBQVU7Q0FBTyxDQUFDO0NBQzNFLHlCQUF5QjtFQUN2QixnQkFBZ0IsVUFBVTtFQUMxQixtQkFBbUIsVUFBVSxDQUFDLENBQUM7Q0FDakMsQ0FBQztDQUNELE1BQU0saUJBQWlCLGVBQWU7Q0FDdEMsTUFBTSxvQkFBb0IsbUJBQWtCLFVBQVM7RUFDbkQsSUFBSSxDQUFDLGNBQWMsU0FDakI7RUFFRixNQUFNLFFBQVEsUUFBUSxRQUFRLFFBQVEsTUFBTSxhQUFhO0VBQ3pELElBQUksVUFBVSxPQUFPLFNBQVMsWUFBWSxTQUFTLGdCQUFnQixRQUFRO0dBQ3pFLFNBQVMsVUFBVTtHQUNuQixXQUFXLEtBQUs7RUFDbEI7Q0FDRixDQUFDO0NBQ0QsTUFBTSx1QkFBdUIsd0JBQXdCO0VBQ25ELE9BQU8scUJBQXFCLE1BQU0sU0FBUyxRQUFRLE1BQUssU0FBUSxLQUFLLE9BQU8sUUFBUSxDQUFDLEVBQUUsU0FBUyxTQUFTLFFBQVE7Q0FDbkgsQ0FBQztDQUNELE1BQU0scUJBQXFCLHdCQUF3QjtFQUNqRCxPQUFPLGdCQUFnQixTQUFTLG1CQUFtQixPQUFPO0NBQzVELENBQUM7Q0FDRCxNQUFNLGtCQUFrQixtQkFBa0IsVUFBUztFQUNqRCxxQkFBcUIsVUFBVTtFQUMvQixrQkFBa0IsVUFBVTtFQU01QixJQUFJLE1BQU0sVUFBVSxLQUNsQjtFQU1GLElBQUksQ0FBQyxjQUFjLFdBQVcsTUFBTSxrQkFBa0Isd0JBQXdCLFNBQzVFO0VBRUYsSUFBSSxVQUFVLDJCQUEyQixNQUFNLEtBQUssYUFBYSxLQUFLLE1BQU0sR0FBRztHQUc3RSxJQUFJLENBQUMscUJBQXFCLE1BQU0sS0FBSyxxQkFBcUIsQ0FBQyxHQUN6RCxVQUFVLEtBQUs7R0FFakIsTUFBTSxRQUFRLE9BQU8seUJBQXlCQyxnQkFBd0IsTUFBTSxXQUFXLENBQUM7R0FDeEYsTUFBTSxnQkFBZ0Isc0JBQXNCLFdBQVc7R0FDdkQsSUFBSSxjQUFjLGFBQWEsR0FDN0IsY0FBYyxNQUFNO0dBRXRCO0VBQ0Y7RUFNQSxJQUFJLGVBQWUsUUFBUSxnQkFBZ0IsU0FBUyxXQUFXLENBQUMsdUJBQXVCLFFBQVEsU0FBUyxXQUFXLEdBQ2pILFNBQVMsVUFBVTtFQUVyQixNQUFNLGVBQWUsU0FBUztFQUM5QixNQUFNLFdBQVcsZ0JBQWdCLFNBQVMsZUFBZTtFQUN6RCxNQUFNLFdBQVcsZ0JBQWdCLFNBQVMsZUFBZTtFQUN6RCxJQUFJLENBQUMsMkJBQTJCO0dBQzlCLElBQUksTUFBTSxRQUFRLFFBQVE7SUFDeEIsVUFBVSxLQUFLO0lBQ2YsU0FBUyxVQUFVO0lBQ25CLFdBQVcsS0FBSztHQUNsQjtHQUNBLElBQUksTUFBTSxRQUFRLE9BQU87SUFDdkIsVUFBVSxLQUFLO0lBQ2YsU0FBUyxVQUFVO0lBQ25CLFdBQVcsS0FBSztHQUNsQjtFQUNGO0VBSUEsSUFBSSxnQkFBZ0IsTUFBTTtHQUN4QixNQUFNLFFBQVEsYUFBYSxPQUFPLFNBQVMsU0FBUyxTQUFTLGFBQWEsV0FBVyxLQUFLLGlCQUFpQixVQUFVLFFBQVE7R0FJN0gsSUFBSSxTQUFTLFFBQVEsVUFBVSxTQUFTLFNBQVM7SUFDL0MsU0FBUyxVQUFVO0lBQ25CLFdBQVcsS0FBSztHQUNsQjtHQUNBLElBQUksZ0JBQWdCLFFBQ2xCO0VBRUo7RUFDQSxJQUFJLHFCQUFxQixNQUFNLEtBQUssV0FBVyxHQUFHO0dBQ2hELFVBQVUsS0FBSztHQUtmLE1BQU0saUJBQWlCLGNBQWMsTUFBTSxjQUFjLGFBQWE7R0FDdEUsSUFBSSxRQUFRLENBQUMsV0FBVyxTQUFTLE1BQU0sZUFBZSxjQUFjLEtBQUssQ0FBQyxRQUFRLFFBQVEsTUFBSyxTQUFRLFFBQVEsUUFBUSxTQUFTLE1BQU0sY0FBYyxDQUFDLEdBQUc7SUFDdEosU0FBUyxVQUFVLDBCQUEwQixNQUFNLEtBQUssYUFBYSxHQUFHLElBQUksV0FBVztJQUN2RixXQUFXLEtBQUs7SUFHaEIsSUFBSSxnQkFBZ0IsU0FBUyxTQUMzQixVQUFVO0lBRVo7R0FDRjtHQUNBLE1BQU0sRUFDSixPQUNBLFlBQ0UsaUJBQWlCLFFBQVEsU0FBUyxjQUFjO0lBQ2xELFdBQVcsQ0FBQywwQkFBMEIsTUFBTSxLQUFLLGFBQWEsR0FBRztJQUNqRTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0YsQ0FBQztHQUNELElBQUksU0FFRixrQkFBa0IsVUFBVTtHQUU5QixTQUFTLFVBQVU7R0FDbkIsV0FBVyxLQUFLO0VBQ2xCO0NBQ0YsQ0FBQztDQUNELE1BQU0sT0FBQSxhQUFhLGNBQWM7RUFxRC9CLE9BQU87R0FuREwsUUFBUSxPQUFPO0lBQ2Isa0JBQWtCLFVBQVU7SUFDNUIsa0JBQWtCLEtBQUs7R0FDekI7R0FDQSxRQUFRLEVBQ04saUJBQ0M7SUFFRCxJQUFJLENBQUMsU0FDSCxjQUFjLE1BQU0sRUFDbEIsZUFBZSxLQUNqQixDQUFDO0dBRUw7R0FDQSxZQUFZLE9BQU87SUFDakIsSUFBSSwwQkFBMEIsS0FBSyxHQUNqQztJQUVGLGtCQUFrQixVQUFVO0lBQzVCLHVCQUF1QixVQUFVO0lBQ2pDLElBQUksa0JBQ0Ysa0JBQWtCLEtBQUs7R0FFM0I7R0FDQSxlQUFlLE9BQU87SUFDcEIsSUFBSSxDQUFDLGNBQWMsV0FBVyxDQUFDLHFCQUFxQixXQUFXLE1BQU0sZ0JBQWdCLFNBQ25GO0lBRUYsa0JBQWtCLFVBQVU7SUFDNUIsTUFBTSxnQkFBZ0IsTUFBTTtJQUM1QixJQUFJLENBQUMsb0JBQW9CLFFBQVEsUUFBUSxTQUFTLGFBQWEsR0FDN0Q7SUFFRixJQUFJLENBQUMsdUJBQXVCLFNBQzFCO0lBRUYscUJBQXFCLFVBQVU7SUFDL0IscUJBQXFCLFVBQVU7SUFDL0IsU0FBUyxVQUFVO0lBQ25CLFdBQVcsS0FBSztJQUNoQixJQUFJLENBQUMsU0FBUztLQUNaLE1BQU0sa0JBQWtCLHdCQUF3QjtLQUNoRCxNQUFNLFdBQVcsY0FBYyxjQUFjLGVBQWUsQ0FBQztLQUM3RCxJQUFJLG1CQUFtQixTQUFTLGlCQUFpQixRQUFRLEdBQ3ZELGdCQUFnQixNQUFNLEVBQ3BCLGVBQWUsS0FDakIsQ0FBQztJQUVMO0dBQ0Y7RUFFYTtDQUNqQixHQUFHO0VBQUM7RUFBbUI7RUFBZTtFQUF5QjtFQUFrQjtFQUFTO0VBQVk7RUFBd0I7Q0FBTyxDQUFDO0NBQ3RJLE1BQU0sMkJBQUEsYUFBaUMsY0FBYztFQUNuRCxPQUFPLFdBQVcsUUFBUSxrQkFBa0IsRUFDMUMseUJBQXlCLEdBQUcsR0FBRyxHQUFHLGNBQ3BDO0NBQ0YsR0FBRztFQUFDO0VBQVM7RUFBTTtFQUFnQjtFQUFJO0NBQVcsQ0FBQztDQUNuRCxNQUFNLFdBQUEsYUFBaUIsY0FBYztFQUNuQyxPQUFPO0dBQ0wsR0FBSSxDQUFDLDRCQUE0QiwyQkFBMkIsQ0FBQztHQUM3RCxVQUFVLE9BQU87SUFFZixJQUFJLE1BQU0sUUFBUSxTQUFTLE1BQU0sWUFBWSxRQUFRLENBQUMsU0FBUztLQUk3RCxNQUFNLFNBQVMsVUFBVSxNQUFNLFdBQVc7S0FDMUMsSUFBSSxVQUFVLENBQUMsU0FBUyx3QkFBd0IsU0FBUyxNQUFNLEdBQzdEO0tBRUYsVUFBVSxLQUFLO0tBQ2YsTUFBTSxVQUFVLHlCQUF5QkMsVUFBa0IsTUFBTSxXQUFXO0tBQzVFLE1BQU0sUUFBUSxPQUFPLE9BQU87S0FDNUIsTUFBTSxnQkFBZ0Isc0JBQXNCLFdBQVc7S0FDdkQsSUFBSSxDQUFDLFFBQVEsY0FBYyxjQUFjLGFBQWEsR0FDcEQsY0FBYyxNQUFNO0tBRXRCO0lBQ0Y7SUFDQSxnQkFBZ0IsS0FBSztHQUN2QjtHQUNBLGNBQWMsT0FBTztJQUNuQixJQUFJLDBCQUEwQixLQUFLLEdBQ2pDO0lBRUYscUJBQXFCLFVBQVU7R0FDakM7RUFDRjtDQUNGLEdBQUc7RUFBQztFQUEwQjtFQUFpQjtFQUF5QjtFQUEyQjtFQUFPO0VBQU07RUFBUztFQUFxQjtDQUFvQixDQUFDO0NBQ25LLE1BQU0sVUFBQSxhQUFnQixjQUFjO0VBQ2xDLFNBQVMsd0JBQXdCLE9BQU87R0FDdEMsTUFBTSxRQUFRLE1BQU0seUJBQXlCRCxnQkFBd0IsTUFBTSxhQUFhLE1BQU0sYUFBYSxDQUFDO0VBQzlHO0VBQ0EsU0FBUyxrQkFBa0IsT0FBTztHQUNoQyxJQUFJLG9CQUFvQixVQUFVLGVBQWUsTUFBTSxXQUFXLEdBQ2hFLG1CQUFtQixVQUFVLENBQUM7RUFFbEM7RUFDQSxTQUFTLG9CQUFvQixPQUFPO0dBRWxDLG1CQUFtQixVQUFVO0dBQzdCLElBQUksb0JBQW9CLFVBQVUsc0JBQXNCLE1BQU0sV0FBVyxHQUN2RSxtQkFBbUIsVUFBVTtFQUVqQztFQUNBLE9BQU87R0FDTCxVQUFVLE9BQU87SUFFZixNQUFNLGNBQWMsTUFBTSxPQUFPLE1BQU07SUFDdkMscUJBQXFCLFVBQVU7SUFDL0IsTUFBTSxhQUFhLE1BQU0sSUFBSSxXQUFXLE9BQU87SUFDL0MsTUFBTSx1QkFBdUIsMEJBQTBCLE1BQU0sS0FBSyxxQkFBcUIsR0FBRyxHQUFHO0lBQzdGLE1BQU0sWUFBWSxxQkFBcUIsTUFBTSxLQUFLLGNBQWMsY0FBYyxrQkFBa0I7SUFDaEcsTUFBTSxtQkFBbUIsU0FBUyx1QkFBdUIsY0FBYyxNQUFNLFFBQVEsV0FBVyxNQUFNLElBQUksS0FBSyxNQUFNO0lBQ3JILElBQUksV0FBVyxnQkFBZ0IsQ0FBQyxVQUFVLGtCQUFrQixNQUFNLGFBQWEsSUFDN0UsT0FBTyxnQkFBZ0IsS0FBSztJQUs5QixJQUFJLENBQUMsZUFBZSxDQUFDLHNCQUFzQixZQUN6QztJQUVGLElBQUksaUJBQWlCO0tBQ25CLE1BQU0sa0JBQWtCLHFCQUFxQixNQUFNLEtBQUsscUJBQXFCLENBQUM7S0FDOUUsT0FBTyxVQUFVLFVBQVUsa0JBQWtCLE9BQU8sTUFBTTtJQUM1RDtJQUNBLElBQUksUUFBUTtLQUNWLElBQUksc0JBQXNCO01BQ3hCLFVBQVUsS0FBSztNQUNmLElBQUksYUFBYTtPQUNmLFNBQVMsVUFBVSxtQkFBbUI7T0FDdEMsV0FBVyxLQUFLO09BQ2hCLElBQUksU0FDRix3QkFBd0IsU0FBUyxNQUFNO01BRTNDLE9BQ0Usd0JBQXdCLEtBQUs7S0FFakM7S0FDQTtJQUNGO0lBQ0EsSUFBSSxXQUFXO0tBQ2IsSUFBSSxpQkFBaUIsV0FBVyxNQUM5QixTQUFTLFVBQVUsaUJBQWlCO0tBRXRDLFVBQVUsS0FBSztLQUNmLElBQUksQ0FBQyxlQUFlLG9CQUNsQix3QkFBd0IsS0FBSztVQUU3QixnQkFBZ0IsS0FBSztLQUV2QixJQUFJLGFBQ0YsV0FBVyxLQUFLO0lBRXBCO0dBRUY7R0FDQSxRQUFRLE9BQU87SUFDYixJQUFJLE1BQU0sV0FBVyxNQUFNLGVBQ3pCO0lBRUYsSUFBSSxNQUFNLE9BQU8sTUFBTSxLQUFLLENBQUMsU0FBUztLQUNwQyxTQUFTLFVBQVU7S0FDbkIsV0FBVyxLQUFLO0lBQ2xCO0dBQ0Y7R0FDQSxlQUFlO0dBQ2YsZ0JBQWdCO0dBQ2hCLGFBQWE7R0FDYixTQUFTO0VBQ1g7Q0FDRixHQUFHO0VBQUM7RUFBaUI7RUFBaUI7RUFBb0I7RUFBUTtFQUFZO0VBQU87RUFBb0I7RUFBYTtFQUFvQjtFQUFzQjtFQUFLO0VBQWtCO0VBQVM7Q0FBdUIsQ0FBQztDQUN4TixNQUFNLFlBQUEsYUFBa0IsY0FBYztFQUNwQyxPQUFPO0dBQ0wsR0FBRztHQUNILEdBQUc7RUFDTDtDQUNGLEdBQUcsQ0FBQywwQkFBMEIsT0FBTyxDQUFDO0NBQ3RDLE9BQUEsYUFBYSxjQUFjLFVBQVU7RUFDbkM7RUFDQTtFQUNBO0VBQ0E7Q0FDRixJQUFJLENBQUMsR0FBRztFQUFDO0VBQVM7RUFBVztFQUFVO0VBQVM7Q0FBSSxDQUFDO0FBQ3ZEOzs7Ozs7O0FDcmtCQSxTQUFnQixhQUFhLE9BQU8sT0FBTztDQUN6QyxNQUFNLEVBQ0osU0FDQSxhQUNBLGFBQ0EsU0FBUyxhQUNULGlCQUNBLFVBQVUsY0FDVixVQUFVLE1BQ1YsVUFBVSxLQUNWLGdCQUFnQixTQUNkO0NBQ0osTUFBTSxXQUFXLGtCQUFrQixZQUFZO0NBQy9DLE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLFVBQVUsV0FBVztDQUMzQixNQUFNLFlBQUEsYUFBa0IsT0FBTyxFQUFFO0NBQ2pDLE1BQU0sZUFBQSxhQUFxQixPQUFPLGlCQUFpQixlQUFlLEVBQUU7Q0FDcEUsTUFBTSxnQkFBQSxhQUFzQixPQUFPLElBQUk7Q0FDdkMsTUFBTSxZQUFZLG1CQUFrQixVQUFTO0VBQzNDLFNBQVMsV0FBVyxPQUFPO0dBQ3pCLE9BQU8sYUFBYSxRQUFRO0VBQzlCO0VBQ0EsU0FBUyxnQkFBZ0IsT0FBTztHQUM5QixNQUFNLFVBQVUsV0FBVyxLQUFLO0dBQ2hDLElBQUksV0FBVyxDQUFDLGlCQUFpQixPQUFPLEtBQUssU0FBUyxRQUFRLFdBQVcsR0FDdkUsT0FBTztHQU9ULE9BQU8sbUJBQW1CLFFBQVEsQ0FBQyxvQkFBb0IsYUFBYSxPQUFPLGVBQWU7RUFDNUY7RUFDQSxTQUFTLGlCQUFpQixNQUFNLFFBQVEsYUFBYSxHQUFHO0dBQ3RELElBQUksS0FBSyxXQUFXLEdBQ2xCLE9BQU87R0FFVCxNQUFNLHdCQUF3QixhQUFhLEtBQUssU0FBUyxLQUFLLFVBQVUsS0FBSztHQUM3RSxNQUFNLGNBQWMsT0FBTyxZQUFZO0dBQ3ZDLEtBQUssSUFBSSxTQUFTLEdBQUcsU0FBUyxLQUFLLFFBQVEsVUFBVSxHQUFHO0lBQ3RELE1BQU0sU0FBUyx1QkFBdUIsVUFBVSxLQUFLO0lBRXJELElBQUksQ0FEUyxLQUFLLE1BQ1QsRUFBRSxZQUFZLENBQUMsQ0FBQyxXQUFXLFdBQVcsS0FBSyxDQUFDLGdCQUFnQixLQUFLLEdBQ3hFO0lBRUYsT0FBTztHQUNUO0dBQ0EsT0FBTztFQUNUO0VBQ0EsTUFBTSxjQUFjLFFBQVE7RUFDNUIsSUFBSSxVQUFVLFFBQVEsU0FBUyxLQUFLLE1BQU0sUUFBUSxLQUFLO0dBRXJELFVBQVUsS0FBSztHQUNmLFdBQVcsSUFBSTtFQUNqQjtFQUNBLElBQUksVUFBVSxRQUFRLFNBQVMsS0FBSyxVQUFVLFFBQVEsT0FBTyxLQUN2RDtPQUFBLGlCQUFpQixhQUFhLFVBQVUsT0FBTyxNQUFNLE1BQU0sTUFBTSxRQUFRLEtBQzNFLFdBQVcsS0FBSztFQUFBO0VBR3BCLElBQUksZUFBZSxRQUVuQixNQUFNLElBQUksV0FBVyxLQUVyQixNQUFNLFdBQVcsTUFBTSxXQUFXLE1BQU0sUUFDdEM7RUFFRixJQUFJLFFBQVEsTUFBTSxRQUFRLEtBQUs7R0FDN0IsVUFBVSxLQUFLO0dBQ2YsV0FBVyxJQUFJO0VBQ2pCO0VBR0EsTUFBTSxlQUFlLFVBQVUsWUFBWTtFQUMzQyxJQUFJLGNBQ0YsYUFBYSxVQUFVLGlCQUFpQixlQUFlO0VBV3pELElBSjBDLFlBQVksT0FBTyxNQUFNLFVBQVUsUUFBUSxnQkFBZ0IsS0FBSyxJQUFJLEtBQUssRUFBRSxFQUFFLFlBQVksTUFBTSxLQUFLLEVBQUUsRUFBRSxZQUFZLElBQUksSUFJOUgsS0FBSyxVQUFVLFlBQVksTUFBTSxLQUFLO0dBQ3hFLFVBQVUsVUFBVTtHQUNwQixhQUFhLFVBQVUsY0FBYztFQUN2QztFQUNBLFVBQVUsV0FBVyxNQUFNO0VBQzNCLFFBQVEsTUFBTSxlQUFlO0dBQzNCLFVBQVUsVUFBVTtHQUNwQixhQUFhLFVBQVUsY0FBYztHQUNyQyxXQUFXLEtBQUs7RUFDbEIsQ0FBQztFQU1ELE1BQU0sZUFEWSxlQUFlLGlCQUFpQixlQUFlLEtBQUssYUFBYSxZQUNsRCxLQUFLO0VBQ3RDLE1BQU0sUUFBUSxpQkFBaUIsYUFBYSxVQUFVLFNBQVMsVUFBVTtFQUN6RSxJQUFJLFVBQVUsSUFBSTtHQUNoQixjQUFjLE9BQU8sS0FBSztHQUMxQixjQUFjLFVBQVU7RUFDMUIsT0FBTyxJQUFJLE1BQU0sUUFBUSxLQUFLO0dBQzVCLFVBQVUsVUFBVTtHQUNwQixXQUFXLEtBQUs7RUFDbEI7Q0FDRixDQUFDO0NBQ0QsTUFBTSxTQUFTLG1CQUFrQixVQUFTO0VBQ3hDLE1BQU0sT0FBTyxNQUFNO0VBQ25CLE1BQU0sNkJBQTZCLE1BQU0sT0FBTyxxQkFBcUI7RUFDckUsTUFBTSx5QkFBeUIsTUFBTSxPQUFPLGlCQUFpQjtFQUk3RCxJQUh3QixTQUFTLDRCQUE0QixJQUFJLEtBQUssU0FBUyx3QkFBd0IsSUFBSSxHQUl6RztFQUlGLFFBQVEsTUFBTTtFQUNkLFVBQVUsVUFBVTtFQUNwQixhQUFhLFVBQVUsY0FBYztFQUNyQyxXQUFXLEtBQUs7Q0FDbEIsQ0FBQztDQUNELHlCQUF5QjtFQUN2QixJQUFJLENBQUMsUUFBUSxrQkFBa0IsTUFDN0I7RUFFRixRQUFRLE1BQU07RUFDZCxjQUFjLFVBQVU7RUFDeEIsSUFBSSxVQUFVLFlBQVksSUFBSTtHQUM1QixVQUFVLFVBQVU7R0FDcEIsV0FBVyxLQUFLO0VBQ2xCO0NBQ0YsR0FBRztFQUFDO0VBQU07RUFBZTtFQUFTO0NBQVEsQ0FBQztDQUMzQyxNQUFNLGNBQUEsYUFBb0IsZUFBZTtFQUN2QztFQUNBO0NBQ0YsSUFBSSxDQUFDLFdBQVcsTUFBTSxDQUFDO0NBQ3ZCLE9BQUEsYUFBYSxjQUFjLFVBQVU7RUFDbkMsV0FBVztFQUNYLFVBQVU7Q0FDWixJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsV0FBVyxDQUFDO0FBQ2hDOztBQy9KQSxJQUFhLHFCQUFrQywyQkFBTSxjQUFjLEtBQUEsQ0FBUztBQUNqQyxtQkFBbUIsY0FBYztBQUM1RSxTQUFnQixzQkFBc0IsVUFBVTtDQUM5QyxNQUFNLFVBQUEsYUFBZ0IsV0FBVyxrQkFBa0I7Q0FDbkQsSUFBSSxZQUFZLEtBQUEsS0FBYSxDQUFDLFVBQzVCLE1BQU0sSUFBSSxNQUE4Qyw2RkFBdUg7Q0FFakwsT0FBTztBQUNUOztBQ0RBLElBQU0sOEJBQThCOzs7Ozs7QUFPcEMsU0FBZ0IsMkJBQTJCLFNBQVMsV0FBVyxtQkFBbUIsa0JBQWtCO0NBQ2xHLE1BQU0sQ0FBQywyQkFBMkIsZ0NBQUEsYUFBc0MsU0FBUyxLQUFLO0NBQ3RGLHlCQUF5QjtFQUN2QixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEscUJBQXFCLE1BQU07R0FDdkQsNkJBQTZCLEtBQUs7R0FDbEM7RUFDRjtFQUNBLE1BQU0sZ0JBQWdCLGNBQWMsaUJBQWlCLENBQUMsQ0FBQyxnQkFBZ0I7RUFDdkUsTUFBTSxhQUFhLGtCQUFrQjtFQUNyQyw2QkFBNkIsZ0JBQWdCLEtBQUssYUFBYSxLQUFLLGNBQWMsZ0JBQWdCLDJCQUEyQjtDQUMvSCxHQUFHO0VBQUM7RUFBUztFQUFXO0NBQWlCLENBQUM7Q0FDMUMsY0FBYyxZQUFZLENBQUMsYUFBYSw0QkFBNEIsZ0JBQWdCO0FBQ3RGOztBQ3pCQSxJQUFNLGtCQUFrQjs7Ozs7QUFNeEIsU0FBZ0Isb0JBQW9CLE9BQU8sU0FBUztDQUNsRCxNQUFNLFNBQVMsdUJBQXVCLE9BQU87Q0FDN0MsT0FBTyxNQUFNLFdBQVcsT0FBTyxPQUFPLG1CQUFtQixNQUFNLFdBQVcsT0FBTyxRQUFRLG1CQUFtQixNQUFNLFdBQVcsT0FBTyxNQUFNLG1CQUFtQixNQUFNLFdBQVcsT0FBTyxTQUFTO0FBQ2hNO0FBQ0EsU0FBZ0IsdUJBQXVCLFNBQVM7Q0FDOUMsTUFBTSxjQUFjLFFBQVEsc0JBQXNCO0NBQ2xELE1BQU0sTUFBTUUsVUFBWSxPQUFPO0NBRy9CLElBQUlDLE9BQ0YsT0FBTztDQUVULE1BQU0sZUFBZSxJQUFJLGlCQUFpQixTQUFTLFVBQVU7Q0FDN0QsTUFBTSxjQUFjLElBQUksaUJBQWlCLFNBQVMsU0FBUztDQUUzRCxJQUFJLEVBRHNCLGFBQWEsWUFBWSxVQUFVLFlBQVksWUFBWSxTQUVuRixPQUFPO0NBSVQsTUFBTSxjQUFjLFdBQVcsYUFBYSxLQUFLLEtBQUs7Q0FDdEQsTUFBTSxlQUFlLFdBQVcsYUFBYSxNQUFNLEtBQUs7Q0FDeEQsTUFBTSxhQUFhLFdBQVcsWUFBWSxLQUFLLEtBQUs7Q0FDcEQsTUFBTSxjQUFjLFdBQVcsWUFBWSxNQUFNLEtBQUs7Q0FHdEQsTUFBTSxhQUFhLEtBQUssSUFBSSxZQUFZLE9BQU8sYUFBYSxVQUFVO0NBQ3RFLE1BQU0sY0FBYyxLQUFLLElBQUksWUFBWSxRQUFRLGNBQWMsV0FBVztDQUcxRSxNQUFNLFlBQVksYUFBYSxZQUFZO0NBQzNDLE1BQU0sYUFBYSxjQUFjLFlBQVk7Q0FDN0MsT0FBTztFQUNMLE1BQU0sWUFBWSxPQUFPLFlBQVk7RUFDckMsT0FBTyxZQUFZLFFBQVEsWUFBWTtFQUN2QyxLQUFLLFlBQVksTUFBTSxhQUFhO0VBQ3BDLFFBQVEsWUFBWSxTQUFTLGFBQWE7Q0FDNUM7QUFDRjs7O0FDNUNBLFNBQVMsUUFBUSxNQUFNO0NBQ3JCLE9BQU8sT0FBTyxTQUFTLFlBQVksUUFBUSxRQUFRLE1BQU0sUUFBUSxLQUFLLEtBQUs7QUFDN0U7QUFDQSxTQUFnQixlQUFlLE9BQU87Q0FHcEMsT0FBTyxRQUFRLFFBQVEsRUFBRTtBQUMzQjtBQUNBLFNBQWdCLGlCQUFpQixPQUFPO0NBQ3RDLE9BQU8sZUFBZSxLQUFLLElBQUksTUFBTSxTQUFRLFVBQVMsTUFBTSxLQUFLLElBQUk7QUFDdkU7Ozs7QUFLQSxTQUFnQixpQkFBaUIsT0FBTztDQUN0QyxJQUFJLENBQUMsTUFBTSxRQUFRLEtBQUssR0FDdEIsT0FBTyxTQUFTLFFBQVEsVUFBVTtDQUVwQyxNQUFNLGFBQWE7Q0FDbkIsSUFBSSxlQUFlLFVBQVUsR0FBRztFQUM5QixLQUFLLE1BQU0sU0FBUyxZQUNsQixLQUFLLE1BQU0sUUFBUSxNQUFNLE9BQ3ZCLElBQUksUUFBUSxLQUFLLFNBQVMsUUFBUSxLQUFLLFNBQVMsTUFDOUMsT0FBTztFQUliLE9BQU87Q0FDVDtDQUNBLEtBQUssTUFBTSxRQUFRLFlBQ2pCLElBQUksUUFBUSxLQUFLLFNBQVMsUUFBUSxLQUFLLFNBQVMsTUFDOUMsT0FBTztDQUdYLE9BQU87QUFDVDtBQUNBLFNBQWdCLGlCQUFpQixNQUFNLG1CQUFtQjtDQUN4RCxJQUFJLHFCQUFxQixRQUFRLE1BQy9CLE9BQU8sa0JBQWtCLElBQUksS0FBSztDQUVwQyxJQUFJLFFBQVEsT0FBTyxTQUFTLFVBQVU7RUFDcEMsSUFBSSxXQUFXLFFBQVEsS0FBSyxTQUFTLE1BQ25DLE9BQU8sT0FBTyxLQUFLLEtBQUs7RUFFMUIsSUFBSSxXQUFXLE1BQ2IsT0FBTyxPQUFPLEtBQUssS0FBSztDQUU1QjtDQUNBLE9BQU8sZUFBZSxJQUFJO0FBQzVCO0FBQ0EsU0FBZ0IsaUJBQWlCLE1BQU0sbUJBQW1CO0NBQ3hELElBQUkscUJBQXFCLFFBQVEsTUFDL0IsT0FBTyxrQkFBa0IsSUFBSSxLQUFLO0NBRXBDLElBQUksUUFBUSxPQUFPLFNBQVMsWUFBWSxXQUFXLFFBQVEsV0FBVyxNQUNwRSxPQUFPLGVBQWUsS0FBSyxLQUFLO0NBRWxDLE9BQU8sZUFBZSxJQUFJO0FBQzVCO0FBQ0EsU0FBZ0IscUJBQXFCLE9BQU8sT0FBTyxtQkFBbUI7Q0FDcEUsU0FBUyxXQUFXO0VBQ2xCLE9BQU8saUJBQWlCLE9BQU8saUJBQWlCO0NBQ2xEO0NBQ0EsSUFBSSxxQkFBcUIsU0FBUyxNQUNoQyxPQUFPLGtCQUFrQixLQUFLO0NBSWhDLElBQUksU0FBUyxPQUFPLFVBQVUsWUFBWSxXQUFXLFNBQVMsTUFBTSxTQUFTLE1BQzNFLE9BQU8sTUFBTTtDQUlmLElBQUksU0FBUyxDQUFDLE1BQU0sUUFBUSxLQUFLLEdBRS9CLFFBRGMsT0FBTyxPQUFPLE9BQU8sS0FBSyxJQUFJLE1BQU0sU0FBUyxLQUFBLE1BQzNDLFNBQVM7Q0FJM0IsSUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFHO0VBRXhCLE1BQU0sWUFBWSxpQkFBaUJDLEtBQVU7RUFDN0MsSUFBSSxTQUFTLFFBQVEsT0FBTyxVQUFVLFVBQVU7R0FDOUMsTUFBTSxRQUFRLFVBQVUsTUFBSyxTQUFRLEtBQUssVUFBVSxLQUFLO0dBQ3pELElBQUksU0FBUyxNQUFNLFNBQVMsTUFDMUIsT0FBTyxNQUFNO0dBRWYsT0FBTyxTQUFTO0VBQ2xCO0VBR0EsSUFBSSxXQUFXLE9BQU87R0FDcEIsTUFBTSxRQUFRLFVBQVUsTUFBSyxTQUFRLFFBQVEsS0FBSyxVQUFVLE1BQU0sS0FBSztHQUN2RSxJQUFJLFNBQVMsTUFBTSxTQUFTLE1BQzFCLE9BQU8sTUFBTTtFQUVqQjtDQUNGO0NBQ0EsT0FBTyxTQUFTO0FBQ2xCO0FBQ0EsU0FBZ0Isc0JBQXNCLFFBQVEsT0FBTyxtQkFBbUI7Q0FDdEUsT0FBTyxPQUFPLFFBQVEsS0FBSyxPQUFPLFVBQVU7RUFDMUMsSUFBSSxRQUFRLEdBQ1YsSUFBSSxLQUFLLElBQUk7RUFFZixJQUFJLEtBQWtCLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUEsYUFBVyxVQUFVLEVBQ3pDLFVBQVUscUJBQXFCLE9BQU8sT0FBTyxpQkFBaUIsRUFDaEUsR0FBRyxLQUFLLENBQUM7RUFDVCxPQUFPO0NBQ1QsR0FBRyxDQUFDLENBQUM7QUFDUCIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNV19