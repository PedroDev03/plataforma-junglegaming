import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/index.tsx");const $$splitComponentImporter = () => import("/src/routes/index.tsx?tsr-split=component");
import { lazyRouteComponent } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { createFileRoute } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { nftsListQueryOptions } from "/src/hooks/use-nfts.ts";
import { nftCatalogSearchSchema } from "/src/schemas/nft-search.ts";
const TSRSplitComponent = (() => {
	const hot = import.meta.hot;
	const hotData = hot ? hot.data ??= {} : undefined;
	return hotData?.["tsr-split-component:component"] ?? lazyRouteComponent($$splitComponentImporter, "component");
})();
if (import.meta.hot) {
	(import.meta.hot.data ??= {})["tsr-split-component:component"] = TSRSplitComponent;
}
export const Route = createFileRoute("/")({
	validateSearch: nftCatalogSearchSchema,
	loaderDeps: ({ search }) => search,
	loader: ({ context, deps }) => {
		void context.queryClient.prefetchQuery(nftsListQueryOptions(deps));
	},
	component: TSRSplitComponent
});
const hot = import.meta.hot;
if (hot && typeof window !== "undefined") {
	hot.data ??= {};
	const tsrReactRefresh = window.__TSR_REACT_REFRESH__ ??= (() => {
		const ignoredExportsById = new Map();
		const previousGetIgnoredExports = window.__getReactRefreshIgnoredExports;
		window.__getReactRefreshIgnoredExports = (ctx) => {
			const ignoredExports = previousGetIgnoredExports?.(ctx) ?? [];
			const moduleIgnored = ignoredExportsById.get(ctx.id) ?? [];
			return [...ignoredExports, ...moduleIgnored];
		};
		return { ignoredExportsById };
	})();
	tsrReactRefresh.ignoredExportsById.set("E:/Downloads/teste-jungle/teste-jungle/src/routes/index.tsx", ["Route"]);
}
export function TSRFastRefreshAnchor() {
	return null;
}
_c = TSRFastRefreshAnchor;
if (import.meta.hot) {
	const hot = import.meta.hot;
	const hotData = hot.data ??= {};
	const handleRouteUpdate = function handleRouteUpdate(routeId, newRoute) {
		const router = window.__TSR_ROUTER__;
		const oldRoute = router.routesById[routeId];
		if (!oldRoute) return;
		const generatedRouteOptionKeys = new Set([
			"id",
			"path",
			"getParentRoute"
		]);
		const generatedRouteOptions = {};
		generatedRouteOptionKeys.forEach((key) => {
			if (key in oldRoute.options) generatedRouteOptions[key] = oldRoute.options[key];
		});
		const preserveComponentIdentity = "shellComponent" in oldRoute.options === "shellComponent" in newRoute.options;
		const componentKeys = [
			"component",
			"shellComponent",
			"pendingComponent",
			"errorComponent",
			"notFoundComponent"
		];
		if (preserveComponentIdentity) componentKeys.forEach((key) => {
			if (key in oldRoute.options && key in newRoute.options) newRoute.options[key] = oldRoute.options[key];
		});
		const nextOptions = {
			...newRoute.options,
			...generatedRouteOptions
		};
		oldRoute.options = nextOptions;
		oldRoute.update(nextOptions);
		router._replaceRouteChunk(oldRoute, newRoute.lazyFn);
		router.setRoutes(router.buildRouteTree());
		syncHotRouteExport(oldRoute);
		router.resolvePathCache.clear();
		router._refreshRoute?.();
		function syncHotRouteExport(liveRoute) {
			newRoute.options = liveRoute.options;
			newRoute.parentRoute = liveRoute.parentRoute;
			newRoute._path = liveRoute._path;
			newRoute._id = liveRoute._id;
			newRoute._fullPath = liveRoute._fullPath;
			newRoute._to = liveRoute._to;
		}
	};
	const initialRouteId = "/" ?? hotData["tsr-route-id"];
	if (initialRouteId) {
		hotData["tsr-route-id"] = initialRouteId;
	}
	const existingRoute = typeof window !== "undefined" && initialRouteId ? window.__TSR_ROUTER__?.routesById?.[initialRouteId] : undefined;
	if (initialRouteId && existingRoute && existingRoute !== Route) {
		handleRouteUpdate(initialRouteId, Route);
		hotData["tsr-route-update-handled"] = Route;
	}
	hot.accept((newModule) => {
		if (Route && newModule && newModule.Route) {
			const routeId = hotData["tsr-route-id"] ?? "/";
			if (routeId) {
				hotData["tsr-route-id"] = routeId;
			}
			if (hotData["tsr-route-update-handled"] === newModule.Route) {
				delete hotData["tsr-route-update-handled"];
				return;
			}
			handleRouteUpdate(routeId, newModule.Route);
		}
	});
}
var _c;
$RefreshReg$(_c, "TSRFastRefreshAnchor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/index.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/routes/index.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/routes/index.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/routes/index.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7QUFBQSxTQUFTQSx1QkFBdUI7QUFFaEMsU0FBU0MsNEJBQTRCO0FBQ3JDLFNBQTRCQyw4QkFBcUQ7QUFBc0IsTUFBQUMsMkJBQUE7Q0FBQSxNQUFBQyxNQUFBQyxZQUFBRDtDQUFBLE1BQUFFLFVBQUFGLFVBQUFHLFNBQUEsS0FBQUM7Q0FBQSxPQUFBRixVQUFBLG9DQUFBRyxtQkFBQUMsMEJBQUE7QUFBQTtBQUFBLElBQUFMLFlBQUFELEtBQUE7Q0FBQSxDQUFBQyxZQUFBRCxJQUFBRyxTQUFBLHVDQUFBSjtBQUFBO0FBRXZHLE9BQU8sTUFBTVEsUUFBUVgsZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDO0NBQ3hDWSxnQkFBZ0JWO0NBQ2hCVyxhQUFhLEVBQUVDLGFBQWFBO0NBQzVCQyxTQUFTLEVBQUVDLFNBQVNDLFdBQVc7RUFDN0IsS0FBS0QsUUFBUUUsWUFBWUMsY0FBY2xCLHFCQUFxQmdCLElBQUksQ0FBQztDQUNuRTtDQUNBRyxXQUFTakI7QUFDWCxDQUFDO0FBQUMsTUFBQUMsTUFBQUMsWUFBQUQ7QUFBQSxJQUFBQSxPQUFBLE9BQUFpQixXQUFBO0NBQUFqQixJQUFBRyxTQUFBO0NBQUEsTUFBQWUsa0JBQUFELE9BQUFFLGlDQUFBO0VBQUEsTUFBQUMscUJBQUEsSUFBQUMsSUFBQTtFQUFBLE1BQUFDLDRCQUFBTCxPQUFBTTtFQUFBTixPQUFBTSxtQ0FBQUMsUUFBQTtHQUFBLE1BQUFDLGlCQUFBSCw0QkFBQUUsR0FBQTtHQUFBLE1BQUFFLGdCQUFBTixtQkFBQU8sSUFBQUgsSUFBQUksRUFBQTtHQUFBLFdBQUFILGdCQUFBLEdBQUFDLGFBQUE7RUFBQTtFQUFBLFNBQUFOLG1CQUFBO0NBQUE7Q0FBQUYsZ0JBQUFFLG1CQUFBUyxJQUFBO0FBQUE7QUFBQSxnQkFBQUMsdUJBQUE7Q0FBQTtBQUFBOztBQUFBLElBQUE3QixZQUFBRCxLQUFBO0NBQUEsTUFBQUEsTUFBQUMsWUFBQUQ7Q0FBQSxNQUFBRSxVQUFBRixJQUFBRyxTQUFBO0NBQUEsTUFBQTRCLG9CQUFBLFNBQUFBLGtCQUFBQyxTQUFBQyxVQUFBO0VBQUEsTUFBQUMsU0FBQWpCLE9BQUFrQjtFQUFBLE1BQUFDLFdBQUFGLE9BQUFHLFdBQUFMO0VBQUEsS0FBQUksVUFBQTtFQUFBLE1BQUFFLDJCQUFBLElBQUFDLElBQUE7R0FBQTtHQUFBO0dBQUE7RUFBQTtFQUFBLE1BQUFDLHdCQUFBO0VBQUFGLHlCQUFBRyxTQUFBQyxRQUFBO0dBQUEsSUFBQUEsT0FBQU4sU0FBQU8sU0FBQUgsc0JBQUFFLE9BQUFOLFNBQUFPLFFBQUFEO0VBQUE7RUFBQSxNQUFBRSw0QkFBQSxvQkFBQVIsU0FBQU8sWUFBQSxvQkFBQVYsU0FBQVU7RUFBQSxNQUFBRSxnQkFBQTtHQUFBO0dBQUE7R0FBQTtHQUFBO0dBQUE7RUFBQTtFQUFBLElBQUFELDJCQUFBQyxjQUFBSixTQUFBQyxRQUFBO0dBQUEsSUFBQUEsT0FBQU4sU0FBQU8sV0FBQUQsT0FBQVQsU0FBQVUsU0FBQVYsU0FBQVUsUUFBQUQsT0FBQU4sU0FBQU8sUUFBQUQ7RUFBQTtFQUFBLE1BQUFJLGNBQUE7R0FBQSxHQUFBYixTQUFBVTtHQUFBLEdBQUFIO0VBQUE7RUFBQUosU0FBQU8sVUFBQUc7RUFBQVYsU0FBQVcsT0FBQUQsV0FBQTtFQUFBWixPQUFBYyxtQkFBQVosVUFBQUgsU0FBQWdCLE1BQUE7RUFBQWYsT0FBQWdCLFVBQUFoQixPQUFBaUIsZUFBQTtFQUFBQyxtQkFBQWhCLFFBQUE7RUFBQUYsT0FBQW1CLGlCQUFBQyxNQUFBO0VBQUFwQixPQUFBcUIsZ0JBQUE7RUFBQSxTQUFBSCxtQkFBQUksV0FBQTtHQUFBdkIsU0FBQVUsVUFBQWEsVUFBQWI7R0FBQVYsU0FBQXdCLGNBQUFELFVBQUFDO0dBQUF4QixTQUFBeUIsUUFBQUYsVUFBQUU7R0FBQXpCLFNBQUEwQixNQUFBSCxVQUFBRztHQUFBMUIsU0FBQTJCLFlBQUFKLFVBQUFJO0dBQUEzQixTQUFBNEIsTUFBQUwsVUFBQUs7RUFBQTtDQUFBO0NBQUEsTUFBQUMsaUJBQUEsT0FBQTVELFFBQUE7Q0FBQSxJQUFBNEQsZ0JBQUE7RUFBQTVELFFBQUEsa0JBQUE0RDtDQUFBO0NBQUEsTUFBQUMsZ0JBQUEsT0FBQTlDLFdBQUEsZUFBQTZDLGlCQUFBN0MsT0FBQWtCLGdCQUFBRSxhQUFBeUIsa0JBQUExRDtDQUFBLElBQUEwRCxrQkFBQUMsbUNBQUF4RCxPQUFBO0VBQUF3QixrQkFBQStCLGdCQUFBdkQsS0FBQTtFQUFBTCxRQUFBLDhCQUFBSztDQUFBO0NBQUFQLElBQUFnRSxRQUFBQyxjQUFBO0VBQUEsSUFBQTFELFNBQUEwRCx1QkFBQTFELE9BQUE7R0FBQSxNQUFBeUIsVUFBQTlCLFFBQUE7R0FBQSxJQUFBOEIsU0FBQTtJQUFBOUIsUUFBQSxrQkFBQThCO0dBQUE7R0FBQSxJQUFBOUIsUUFBQSxnQ0FBQStELFVBQUExRCxPQUFBO0lBQUEsT0FBQUwsUUFBQTtJQUFBO0dBQUE7R0FBQTZCLGtCQUFBQyxTQUFBaUMsVUFBQTFELEtBQUE7RUFBQTtDQUFBO0FBQUEiLCJuYW1lcyI6WyJjcmVhdGVGaWxlUm91dGUiLCJuZnRzTGlzdFF1ZXJ5T3B0aW9ucyIsIm5mdENhdGFsb2dTZWFyY2hTY2hlbWEiLCJUU1JTcGxpdENvbXBvbmVudCIsImhvdCIsImltcG9ydCIsImhvdERhdGEiLCJkYXRhIiwidW5kZWZpbmVkIiwibGF6eVJvdXRlQ29tcG9uZW50IiwiJCRzcGxpdENvbXBvbmVudEltcG9ydGVyIiwiUm91dGUiLCJ2YWxpZGF0ZVNlYXJjaCIsImxvYWRlckRlcHMiLCJzZWFyY2giLCJsb2FkZXIiLCJjb250ZXh0IiwiZGVwcyIsInF1ZXJ5Q2xpZW50IiwicHJlZmV0Y2hRdWVyeSIsImNvbXBvbmVudCIsIndpbmRvdyIsInRzclJlYWN0UmVmcmVzaCIsIl9fVFNSX1JFQUNUX1JFRlJFU0hfXyIsImlnbm9yZWRFeHBvcnRzQnlJZCIsIk1hcCIsInByZXZpb3VzR2V0SWdub3JlZEV4cG9ydHMiLCJfX2dldFJlYWN0UmVmcmVzaElnbm9yZWRFeHBvcnRzIiwiY3R4IiwiaWdub3JlZEV4cG9ydHMiLCJtb2R1bGVJZ25vcmVkIiwiZ2V0IiwiaWQiLCJzZXQiLCJUU1JGYXN0UmVmcmVzaEFuY2hvciIsImhhbmRsZVJvdXRlVXBkYXRlIiwicm91dGVJZCIsIm5ld1JvdXRlIiwicm91dGVyIiwiX19UU1JfUk9VVEVSX18iLCJvbGRSb3V0ZSIsInJvdXRlc0J5SWQiLCJnZW5lcmF0ZWRSb3V0ZU9wdGlvbktleXMiLCJTZXQiLCJnZW5lcmF0ZWRSb3V0ZU9wdGlvbnMiLCJmb3JFYWNoIiwia2V5Iiwib3B0aW9ucyIsInByZXNlcnZlQ29tcG9uZW50SWRlbnRpdHkiLCJjb21wb25lbnRLZXlzIiwibmV4dE9wdGlvbnMiLCJ1cGRhdGUiLCJfcmVwbGFjZVJvdXRlQ2h1bmsiLCJsYXp5Rm4iLCJzZXRSb3V0ZXMiLCJidWlsZFJvdXRlVHJlZSIsInN5bmNIb3RSb3V0ZUV4cG9ydCIsInJlc29sdmVQYXRoQ2FjaGUiLCJjbGVhciIsIl9yZWZyZXNoUm91dGUiLCJsaXZlUm91dGUiLCJwYXJlbnRSb3V0ZSIsIl9wYXRoIiwiX2lkIiwiX2Z1bGxQYXRoIiwiX3RvIiwiaW5pdGlhbFJvdXRlSWQiLCJleGlzdGluZ1JvdXRlIiwiYWNjZXB0IiwibmV3TW9kdWxlIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjcmVhdGVGaWxlUm91dGUgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgTmZ0Q2F0YWxvZyB9IGZyb20gJ0AvY29tcG9uZW50cy9uZnQvbmZ0LWNhdGFsb2cnXG5pbXBvcnQgeyBuZnRzTGlzdFF1ZXJ5T3B0aW9ucyB9IGZyb20gJ0AvaG9va3MvdXNlLW5mdHMnXG5pbXBvcnQgeyBERUZBVUxUX1BBR0VfU0laRSwgbmZ0Q2F0YWxvZ1NlYXJjaFNjaGVtYSwgdHlwZSBOZnRDYXRhbG9nU2VhcmNoIH0gZnJvbSAnQC9zY2hlbWFzL25mdC1zZWFyY2gnXG5cbmV4cG9ydCBjb25zdCBSb3V0ZSA9IGNyZWF0ZUZpbGVSb3V0ZSgnLycpKHtcbiAgdmFsaWRhdGVTZWFyY2g6IG5mdENhdGFsb2dTZWFyY2hTY2hlbWEsXG4gIGxvYWRlckRlcHM6ICh7IHNlYXJjaCB9KSA9PiBzZWFyY2gsXG4gIGxvYWRlcjogKHsgY29udGV4dCwgZGVwcyB9KSA9PiB7XG4gICAgdm9pZCBjb250ZXh0LnF1ZXJ5Q2xpZW50LnByZWZldGNoUXVlcnkobmZ0c0xpc3RRdWVyeU9wdGlvbnMoZGVwcykpXG4gIH0sXG4gIGNvbXBvbmVudDogSG9tZUNhdGFsb2dQYWdlLFxufSlcblxuZnVuY3Rpb24gSG9tZUNhdGFsb2dQYWdlKCkge1xuICBjb25zdCBzZWFyY2ggPSBSb3V0ZS51c2VTZWFyY2goKVxuICBjb25zdCBuYXZpZ2F0ZSA9IFJvdXRlLnVzZU5hdmlnYXRlKClcblxuICBjb25zdCBoYW5kbGVGaWx0ZXJDaGFuZ2UgPSAodXBkYXRlczogUGFydGlhbDxPbWl0PE5mdENhdGFsb2dTZWFyY2gsICdwYWdlJz4+KSA9PiB7XG4gICAgdm9pZCBuYXZpZ2F0ZSh7XG4gICAgICBzZWFyY2g6IChwcmV2KSA9PiAoe1xuICAgICAgICAuLi5wcmV2LFxuICAgICAgICAuLi51cGRhdGVzLFxuICAgICAgICAvLyBSZWdyYSBlc3RyaXRhOiB0b2RhIG11ZGFuw6dhIGRlIGZpbHRybyByZWluaWNpYSBhIHBhZ2luYcOnw6NvIHBhcmEgMVxuICAgICAgICBwYWdlOiAxLFxuICAgICAgfSksXG4gICAgfSlcbiAgfVxuXG4gIGNvbnN0IGhhbmRsZVBhZ2VDaGFuZ2UgPSAobmV4dFBhZ2U6IG51bWJlcikgPT4ge1xuICAgIHZvaWQgbmF2aWdhdGUoe1xuICAgICAgc2VhcmNoOiAocHJldikgPT4gKHtcbiAgICAgICAgLi4ucHJldixcbiAgICAgICAgcGFnZTogbmV4dFBhZ2UsXG4gICAgICB9KSxcbiAgICB9KVxuICB9XG5cbiAgY29uc3QgaGFuZGxlUmVzZXRGaWx0ZXJzID0gKCkgPT4ge1xuICAgIHZvaWQgbmF2aWdhdGUoe1xuICAgICAgc2VhcmNoOiB7XG4gICAgICAgIHNvcnQ6ICdyZWNlbnQnLFxuICAgICAgICBwYWdlOiAxLFxuICAgICAgICBwYWdlU2l6ZTogREVGQVVMVF9QQUdFX1NJWkUsXG4gICAgICB9LFxuICAgIH0pXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxOZnRDYXRhbG9nXG4gICAgICBzZWFyY2g9e3NlYXJjaH1cbiAgICAgIG9uRmlsdGVyQ2hhbmdlPXtoYW5kbGVGaWx0ZXJDaGFuZ2V9XG4gICAgICBvblBhZ2VDaGFuZ2U9e2hhbmRsZVBhZ2VDaGFuZ2V9XG4gICAgICBvblJlc2V0RmlsdGVycz17aGFuZGxlUmVzZXRGaWx0ZXJzfVxuICAgIC8+XG4gIClcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL3JvdXRlcy9pbmRleC50c3gifQ==