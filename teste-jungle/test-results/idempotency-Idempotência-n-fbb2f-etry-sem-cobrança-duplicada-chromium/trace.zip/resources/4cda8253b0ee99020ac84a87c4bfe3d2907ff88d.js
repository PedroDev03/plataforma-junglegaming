import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/nft/nft-catalog.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport12_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport12_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { AlertCircle, Loader2, RefreshCw, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { NftCard } from "/src/components/nft/nft-card.tsx";
import { NftCardSkeleton } from "/src/components/nft/nft-card-skeleton.tsx";
import { NftFilters } from "/src/components/nft/nft-filters.tsx";
import { NftPagination } from "/src/components/nft/nft-pagination.tsx";
import { Alert, AlertDescription, AlertTitle } from "/src/components/ui/alert.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Card, CardContent } from "/src/components/ui/card.tsx";
import { useGetNFTs } from "/src/hooks/use-nfts.ts";
import { getErrorMessage } from "/src/lib/api.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-catalog.tsx";
import __vite__cjsImport12_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
export function NftCatalog(t0) {
	_s();
	const $ = _c(35);
	if ($[0] !== "169fe401a0d6e8e6da656a73403c93b98fde395f7d77ded71a33b8d045a366d1") {
		for (let $i = 0; $i < 35; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "169fe401a0d6e8e6da656a73403c93b98fde395f7d77ded71a33b8d045a366d1";
	}
	const { search, onFilterChange, onPageChange, onResetFilters } = t0;
	const { data, isLoading, isError, isSuccess, isFetching, error, refetch } = useGetNFTs(search);
	const lcpImageUrl = data?.items[0]?.imageUrl;
	let t1;
	if ($[1] !== lcpImageUrl) {
		t1 = lcpImageUrl && /* @__PURE__ */ _jsxDEV("link", {
			rel: "preload",
			as: "image",
			href: lcpImageUrl,
			fetchPriority: "high"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 46,
			columnNumber: 25
		}, this);
		$[1] = lcpImageUrl;
		$[2] = t1;
	} else {
		t1 = $[2];
	}
	let t2;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			className: "grid max-w-2xl gap-2",
			children: [
				/* @__PURE__ */ _jsxDEV(Badge, {
					variant: "outline",
					className: "w-fit gap-1.5 bg-background",
					children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
						className: "size-3.5 text-primary",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 113
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Curadoria Web3 Verificada" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 178
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 48
				}, this),
				/* @__PURE__ */ _jsxDEV("h1", {
					className: "text-2xl font-bold tracking-tight sm:text-3xl md:text-4xl",
					children: "Explore Colecionáveis Digitais Raros"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 224
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "text-sm text-muted-foreground sm:text-base",
					children: "Descubra, favorite e colecione obras exclusivas em ETH com precisão decimal garantida."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 339
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 54,
			columnNumber: 10
		}, this);
		$[3] = t2;
	} else {
		t2 = $[3];
	}
	let t3;
	if ($[4] !== isFetching || $[5] !== isLoading) {
		t3 = isFetching && !isLoading && /* @__PURE__ */ _jsxDEV(Badge, {
			variant: "secondary",
			role: "status",
			"aria-live": "polite",
			className: "gap-2 self-start px-3 py-1.5 sm:self-center",
			children: [/* @__PURE__ */ _jsxDEV(Loader2, {
				className: "size-3.5 animate-spin motion-reduce:animate-none",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 154
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Sincronizando..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 61,
				columnNumber: 245
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 38
		}, this);
		$[4] = isFetching;
		$[5] = isLoading;
		$[6] = t3;
	} else {
		t3 = $[6];
	}
	let t4;
	if ($[7] !== t3) {
		t4 = /* @__PURE__ */ _jsxDEV(Card, {
			className: "bg-muted/35",
			children: /* @__PURE__ */ _jsxDEV(CardContent, {
				className: "flex flex-col justify-between gap-4 py-2 sm:flex-row sm:items-center",
				children: [t2, t3]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 40
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 70,
			columnNumber: 10
		}, this);
		$[7] = t3;
		$[8] = t4;
	} else {
		t4 = $[8];
	}
	let t5;
	if ($[9] !== data?.collections) {
		t5 = data?.collections ?? [];
		$[9] = data?.collections;
		$[10] = t5;
	} else {
		t5 = $[10];
	}
	let t6;
	if ($[11] !== onFilterChange || $[12] !== onResetFilters || $[13] !== search || $[14] !== t5) {
		t6 = /* @__PURE__ */ _jsxDEV(NftFilters, {
			search,
			collections: t5,
			onFilterChange,
			onResetFilters
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 10
		}, this);
		$[11] = onFilterChange;
		$[12] = onResetFilters;
		$[13] = search;
		$[14] = t5;
		$[15] = t6;
	} else {
		t6 = $[15];
	}
	let t7;
	if ($[16] !== isLoading || $[17] !== search) {
		t7 = isLoading && /* @__PURE__ */ _jsxDEV("section", {
			"aria-busy": "true",
			"aria-label": "Carregando catálogo de NFTs",
			className: "grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
			children: Array.from({ length: search.pageSize }, _temp)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 97,
			columnNumber: 23
		}, this);
		$[16] = isLoading;
		$[17] = search;
		$[18] = t7;
	} else {
		t7 = $[18];
	}
	let t8;
	if ($[19] !== error || $[20] !== isError || $[21] !== refetch) {
		t8 = isError && /* @__PURE__ */ _jsxDEV(Alert, {
			variant: "destructive",
			role: "alert",
			children: [
				/* @__PURE__ */ _jsxDEV(AlertCircle, {
					className: "size-4",
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 63
				}, this),
				/* @__PURE__ */ _jsxDEV(AlertTitle, { children: "Falha ao carregar o catálogo" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 116
				}, this),
				/* @__PURE__ */ _jsxDEV(AlertDescription, {
					className: "mt-2 flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: getErrorMessage(error) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 254
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						onClick: () => void refetch(),
						children: [/* @__PURE__ */ _jsxDEV(RefreshCw, {
							className: "size-3.5",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 108,
							columnNumber: 372
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Tentar novamente" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 108,
							columnNumber: 425
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 291
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 169
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 108,
			columnNumber: 21
		}, this);
		$[19] = error;
		$[20] = isError;
		$[21] = refetch;
		$[22] = t8;
	} else {
		t8 = $[22];
	}
	let t9;
	if ($[23] !== data || $[24] !== isSuccess || $[25] !== onPageChange || $[26] !== onResetFilters) {
		t9 = isSuccess && data && /* @__PURE__ */ _jsxDEV(_Fragment, { children: data.items.length === 0 ? /* @__PURE__ */ _jsxDEV(Card, {
			className: "border-dashed",
			children: /* @__PURE__ */ _jsxDEV(CardContent, {
				"aria-live": "polite",
				className: "flex flex-col items-center justify-center gap-3 py-12 text-center",
				children: [
					/* @__PURE__ */ _jsxDEV("p", {
						className: "text-base font-medium",
						children: "Nenhum NFT encontrado para estes filtros."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 202
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "max-w-md text-xs text-muted-foreground",
						children: "Experimente ajustar os intervalos de preço em ETH, trocar a categoria ou limpar a busca."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 284
					}, this),
					/* @__PURE__ */ _jsxDEV(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						onClick: onResetFilters,
						children: "Limpar filtros"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 430
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 118,
				columnNumber: 92
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 118,
			columnNumber: 60
		}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("section", {
			"aria-label": "Lista de NFTs",
			className: "grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
			children: data.items.map(_temp2)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 118,
			columnNumber: 554
		}, this), /* @__PURE__ */ _jsxDEV(NftPagination, {
			page: data.page,
			totalPages: data.totalPages,
			totalItems: data.total,
			onPageChange
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 118,
			columnNumber: 704
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 118,
			columnNumber: 552
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 118,
			columnNumber: 31
		}, this);
		$[23] = data;
		$[24] = isSuccess;
		$[25] = onPageChange;
		$[26] = onResetFilters;
		$[27] = t9;
	} else {
		t9 = $[27];
	}
	let t10;
	if ($[28] !== t1 || $[29] !== t4 || $[30] !== t6 || $[31] !== t7 || $[32] !== t8 || $[33] !== t9) {
		t10 = /* @__PURE__ */ _jsxDEV("main", {
			id: "main-content",
			tabIndex: -1,
			className: "mx-auto grid w-full max-w-7xl gap-6 px-4 py-6 outline-none sm:px-6 md:py-10 lg:px-8",
			children: [
				t1,
				t4,
				t6,
				t7,
				t8,
				t9
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 129,
			columnNumber: 11
		}, this);
		$[28] = t1;
		$[29] = t4;
		$[30] = t6;
		$[31] = t7;
		$[32] = t8;
		$[33] = t9;
		$[34] = t10;
	} else {
		t10 = $[34];
	}
	return t10;
}
_s(NftCatalog, "Jdlhh+0ER5YPlSAzlOhRb1F63no=", false, function() {
	return [useGetNFTs];
});
_c2 = NftCatalog;
function _temp2(nft, index) {
	return /* @__PURE__ */ _jsxDEV(NftCard, {
		nft,
		priority: index < 2
	}, nft.id, false, {
		fileName: _jsxFileName,
		lineNumber: 143,
		columnNumber: 10
	}, this);
}
function _temp(_, idx) {
	return /* @__PURE__ */ _jsxDEV(NftCardSkeleton, {}, idx, false, {
		fileName: _jsxFileName,
		lineNumber: 146,
		columnNumber: 10
	}, this);
}
var _c2;
$RefreshReg$(_c2, "NftCatalog");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/nft/nft-catalog.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-catalog.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-catalog.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-catalog.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGFBQWFDLFNBQVNDLFdBQVdDLGdCQUFnQjtBQUMxRCxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MscUJBQXFCO0FBQzlCLFNBQVNDLE9BQU9DLGtCQUFrQkMsa0JBQWtCO0FBQ3BELFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxNQUFNQyxtQkFBbUI7QUFDbEMsU0FBU0Msa0JBQWtCO0FBQzNCLFNBQVNDLHVCQUF1Qjs7OztBQVVoQyxPQUFPLFNBQUFDLFdBQUFDLElBQUE7O0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQW9CLFFBQUFLLFFBQUFDLGdCQUFBQyxjQUFBQyxtQkFBQVQ7Q0FNekIsUUFBQVUsTUFBQUMsV0FBQUMsU0FBQUMsV0FBQUMsWUFBQUMsT0FBQUMsWUFBNEVuQixXQUFXUyxNQUFNO0NBQzdGLE1BQUFXLGNBQW9CUCxNQUFJUSxNQUFVLEVBQVUsRUFBQUM7Q0FBQSxJQUFBQztDQUFBLElBQUFuQixFQUFBLE9BQUFnQixhQUFBO0VBU3ZDRyxLQUFBSCxlQUFlO0dBQVU7R0FBYTtHQUFjQTtHQUEyQjtFQUFNOzs7OztFQUFHaEIsRUFBQSxLQUFBZ0I7RUFBQWhCLEVBQUEsS0FBQW1CO0NBQUE7RUFBQUEsS0FBQW5CLEVBQUE7Q0FBQTtDQUFBLElBQUFvQjtDQUFBLElBQUFwQixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFLckZnQixLQUFBO0dBQWU7YUFBZjtJQUNFLHdCQUFDLE9BQUQ7S0FBZTtLQUFvQjtlQUFuQyxDQUNFLHdCQUFDLFVBQUQ7TUFBb0I7TUFBb0M7S0FBTTs7OztlQUM5RCw0Q0FBTSw0QkFBZ0M7Ozs7YUFGbEM7Ozs7OztJQUlOO0tBQWM7ZUFBNEQ7SUFFckU7Ozs7O0lBQ0w7S0FBYTtlQUE2QztJQUV0RDs7Ozs7R0FDQTs7Ozs7O0VBQUFwQixFQUFBLEtBQUFvQjtDQUFBO0VBQUFBLEtBQUFwQixFQUFBO0NBQUE7Q0FBQSxJQUFBcUI7Q0FBQSxJQUFBckIsRUFBQSxPQUFBYSxjQUFBYixFQUFBLE9BQUFVLFdBQUE7RUFFTFcsS0FBQVIsY0FBQSxDQUFlSCxhQUNkLHdCQUFDLE9BQUQ7R0FDVTtHQUNIO0dBQ0s7R0FDQTthQUpaLENBTUUsd0JBQUMsU0FBRDtJQUNZO0lBQ0U7R0FBTTs7OzthQUVwQiw0Q0FBTSxtQkFBdUI7Ozs7V0FWekI7Ozs7OztFQVlQVixFQUFBLEtBQUFhO0VBQUFiLEVBQUEsS0FBQVU7RUFBQVYsRUFBQSxLQUFBcUI7Q0FBQTtFQUFBQSxLQUFBckIsRUFBQTtDQUFBO0NBQUEsSUFBQXNCO0NBQUEsSUFBQXRCLEVBQUEsT0FBQXFCLElBQUE7RUE1QkxDLEtBQUEsd0JBQUMsTUFBRDtHQUFnQjthQUNkLHdCQUFDLGFBQUQ7SUFBdUI7Y0FBdkIsQ0FDRUYsSUFhQ0MsRUFkUzs7Ozs7O0VBRFQ7Ozs7O0VBOEJFckIsRUFBQSxLQUFBcUI7RUFBQXJCLEVBQUEsS0FBQXNCO0NBQUE7RUFBQUEsS0FBQXRCLEVBQUE7Q0FBQTtDQUFBLElBQUF1QjtDQUFBLElBQUF2QixFQUFBLE9BQUFTLE1BQUFlLGFBQUE7RUFLUUQsS0FBQWQsTUFBSWUsZUFBSjtFQUF1QnhCLEVBQUEsS0FBQVMsTUFBQWU7RUFBQXhCLEVBQUEsTUFBQXVCO0NBQUE7RUFBQUEsS0FBQXZCLEVBQUE7Q0FBQTtDQUFBLElBQUF5QjtDQUFBLElBQUF6QixFQUFBLFFBQUFNLGtCQUFBTixFQUFBLFFBQUFRLGtCQUFBUixFQUFBLFFBQUFLLFVBQUFMLEVBQUEsUUFBQXVCLElBQUE7RUFGdENFLEtBQUEsd0JBQUMsWUFBRDtHQUNVcEI7R0FDSyxhQUFBa0I7R0FDR2pCO0dBQ0FFO0VBQWM7Ozs7O0VBQzlCUixFQUFBLE1BQUFNO0VBQUFOLEVBQUEsTUFBQVE7RUFBQVIsRUFBQSxNQUFBSztFQUFBTCxFQUFBLE1BQUF1QjtFQUFBdkIsRUFBQSxNQUFBeUI7Q0FBQTtFQUFBQSxLQUFBekIsRUFBQTtDQUFBO0NBQUEsSUFBQTBCO0NBQUEsSUFBQTFCLEVBQUEsUUFBQVUsYUFBQVYsRUFBQSxRQUFBSyxRQUFBO0VBR0RxQixLQUFBaEIsYUFDQztHQUNZO0dBQ0M7R0FDRDthQUVUaUIsTUFBS0MsS0FBTSxFQUFBQyxRQUFVeEIsT0FBTXlCLFNBQVUsR0FBR0MsS0FFeEM7RUFDTzs7Ozs7RUFDWC9CLEVBQUEsTUFBQVU7RUFBQVYsRUFBQSxNQUFBSztFQUFBTCxFQUFBLE1BQUEwQjtDQUFBO0VBQUFBLEtBQUExQixFQUFBO0NBQUE7Q0FBQSxJQUFBZ0M7Q0FBQSxJQUFBaEMsRUFBQSxRQUFBYyxTQUFBZCxFQUFBLFFBQUFXLFdBQUFYLEVBQUEsUUFBQWUsU0FBQTtFQUdBaUIsS0FBQXJCLFdBQ0Msd0JBQUMsT0FBRDtHQUFlO0dBQW1CO2FBQWxDO0lBQ0Usd0JBQUMsYUFBRDtLQUF1QjtLQUFxQjtJQUFNOzs7OztJQUNsRCx3QkFBQyxZQUFELFlBQVksK0JBQUQ7Ozs7O0lBQ1gsd0JBQUMsa0JBQUQ7S0FBNEI7ZUFBNUIsQ0FDRSw0Q0FBT2QsZ0JBQWdCaUIsS0FBSyxFQUFTOzs7O2VBQ3JDLHdCQUFDLFFBQUQ7TUFBYTtNQUFpQjtNQUFlO01BQWMsZUFBTSxLQUFLQyxRQUFRO2dCQUE5RSxDQUNFLHdCQUFDLFdBQUQ7T0FBcUI7T0FBdUI7TUFBTTs7OztnQkFDbEQsNENBQU0sbUJBQXVCOzs7O2NBRnhCOzs7OzthQUZROzs7Ozs7R0FIYjs7Ozs7O0VBV1BmLEVBQUEsTUFBQWM7RUFBQWQsRUFBQSxNQUFBVztFQUFBWCxFQUFBLE1BQUFlO0VBQUFmLEVBQUEsTUFBQWdDO0NBQUE7RUFBQUEsS0FBQWhDLEVBQUE7Q0FBQTtDQUFBLElBQUFpQztDQUFBLElBQUFqQyxFQUFBLFFBQUFTLFFBQUFULEVBQUEsUUFBQVksYUFBQVosRUFBQSxRQUFBTyxnQkFBQVAsRUFBQSxRQUFBUSxnQkFBQTtFQUdBeUIsS0FBQXJCLGFBQUFILFFBQUEsK0NBRUlBLEtBQUlRLE1BQU1ZLFdBQVksSUFDckIsd0JBQUMsTUFBRDtHQUFnQjthQUNkLHdCQUFDLGFBQUQ7SUFDWTtJQUNBO2NBRlo7S0FJRTtNQUFhO2dCQUF3QjtLQUE2Qzs7Ozs7S0FDbEY7TUFBYTtnQkFBeUM7S0FHbEQ7Ozs7O0tBQ0osd0JBQUMsUUFBRDtNQUFhO01BQWlCO01BQWU7TUFBY3JCO2dCQUFnQjtLQUFwRTs7Ozs7SUFURzs7Ozs7O0VBRFQ7Ozs7YUFETixnREFrQkc7R0FDYTtHQUNEO2FBRVRDLEtBQUlRLE1BQU1pQixJQUFLQyxNQUVmO0VBQ087Ozs7WUFFVix3QkFBQyxlQUFEO0dBQ1EsTUFBQTFCLEtBQUkyQjtHQUNFLFlBQUEzQixLQUFJNEI7R0FDSixZQUFBNUIsS0FBSTZCO0dBQ0YvQjtFQUFZOzs7O1VBQzFCOzs7O1dBRUw7Ozs7O0VBRUpQLEVBQUEsTUFBQVM7RUFBQVQsRUFBQSxNQUFBWTtFQUFBWixFQUFBLE1BQUFPO0VBQUFQLEVBQUEsTUFBQVE7RUFBQVIsRUFBQSxNQUFBaUM7Q0FBQTtFQUFBQSxLQUFBakMsRUFBQTtDQUFBO0NBQUEsSUFBQXVDO0NBQUEsSUFBQXZDLEVBQUEsUUFBQW1CLE1BQUFuQixFQUFBLFFBQUFzQixNQUFBdEIsRUFBQSxRQUFBeUIsTUFBQXpCLEVBQUEsUUFBQTBCLE1BQUExQixFQUFBLFFBQUFnQyxNQUFBaEMsRUFBQSxRQUFBaUMsSUFBQTtFQXBISE0sTUFBQTtHQUNLO0dBQ087R0FDQTthQUhaO0lBTUdwQjtJQUdERztJQWlDQUc7SUFRQ0M7SUFhQU07SUFlQUM7R0F1Q0k7Ozs7OztFQUFBakMsRUFBQSxNQUFBbUI7RUFBQW5CLEVBQUEsTUFBQXNCO0VBQUF0QixFQUFBLE1BQUF5QjtFQUFBekIsRUFBQSxNQUFBMEI7RUFBQTFCLEVBQUEsTUFBQWdDO0VBQUFoQyxFQUFBLE1BQUFpQztFQUFBakMsRUFBQSxNQUFBdUM7Q0FBQTtFQUFBQSxNQUFBdkMsRUFBQTtDQUFBO0NBQUEsT0FySFB1QztBQXFITzs7Ozs7QUEvSEosU0FBQUosT0FBQUssS0FBQUMsT0FBQTtDQUFBLE9BaUhXLHdCQUFDLFNBQUQ7RUFBMkJEO0VBQWUsVUFBQUMsUUFBUTtDQUFDLEdBQXJDRCxJQUFHRTs7OztRQUFrQztBQUFJO0FBakhsRSxTQUFBWCxNQUFBWSxHQUFBQyxLQUFBO0NBQUEsT0FtRUssd0JBQUMsaUJBQUQsQ0FBeUIsR0FBSEE7Ozs7UUFBRztBQUFJIiwibmFtZXMiOlsiQWxlcnRDaXJjbGUiLCJMb2FkZXIyIiwiUmVmcmVzaEN3IiwiU3BhcmtsZXMiLCJOZnRDYXJkIiwiTmZ0Q2FyZFNrZWxldG9uIiwiTmZ0RmlsdGVycyIsIk5mdFBhZ2luYXRpb24iLCJBbGVydCIsIkFsZXJ0RGVzY3JpcHRpb24iLCJBbGVydFRpdGxlIiwiQmFkZ2UiLCJCdXR0b24iLCJDYXJkIiwiQ2FyZENvbnRlbnQiLCJ1c2VHZXRORlRzIiwiZ2V0RXJyb3JNZXNzYWdlIiwiTmZ0Q2F0YWxvZyIsInQwIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJzZWFyY2giLCJvbkZpbHRlckNoYW5nZSIsIm9uUGFnZUNoYW5nZSIsIm9uUmVzZXRGaWx0ZXJzIiwiZGF0YSIsImlzTG9hZGluZyIsImlzRXJyb3IiLCJpc1N1Y2Nlc3MiLCJpc0ZldGNoaW5nIiwiZXJyb3IiLCJyZWZldGNoIiwibGNwSW1hZ2VVcmwiLCJpdGVtcyIsImltYWdlVXJsIiwidDEiLCJ0MiIsInQzIiwidDQiLCJ0NSIsImNvbGxlY3Rpb25zIiwidDYiLCJ0NyIsIkFycmF5IiwiZnJvbSIsImxlbmd0aCIsInBhZ2VTaXplIiwiX3RlbXAiLCJ0OCIsInQ5IiwibWFwIiwiX3RlbXAyIiwicGFnZSIsInRvdGFsUGFnZXMiLCJ0b3RhbCIsInQxMCIsIm5mdCIsImluZGV4IiwiaWQiLCJfIiwiaWR4Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIm5mdC1jYXRhbG9nLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBbGVydENpcmNsZSwgTG9hZGVyMiwgUmVmcmVzaEN3LCBTcGFya2xlcyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IE5mdENhcmQgfSBmcm9tICdAL2NvbXBvbmVudHMvbmZ0L25mdC1jYXJkJ1xuaW1wb3J0IHsgTmZ0Q2FyZFNrZWxldG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL25mdC9uZnQtY2FyZC1za2VsZXRvbidcbmltcG9ydCB7IE5mdEZpbHRlcnMgfSBmcm9tICdAL2NvbXBvbmVudHMvbmZ0L25mdC1maWx0ZXJzJ1xuaW1wb3J0IHsgTmZ0UGFnaW5hdGlvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9uZnQvbmZ0LXBhZ2luYXRpb24nXG5pbXBvcnQgeyBBbGVydCwgQWxlcnREZXNjcmlwdGlvbiwgQWxlcnRUaXRsZSB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9hbGVydCdcbmltcG9ydCB7IEJhZGdlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2JhZGdlJ1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcbmltcG9ydCB7IENhcmQsIENhcmRDb250ZW50IH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnXG5pbXBvcnQgeyB1c2VHZXRORlRzIH0gZnJvbSAnQC9ob29rcy91c2UtbmZ0cydcbmltcG9ydCB7IGdldEVycm9yTWVzc2FnZSB9IGZyb20gJ0AvbGliL2FwaSdcbmltcG9ydCB0eXBlIHsgTmZ0Q2F0YWxvZ1NlYXJjaCB9IGZyb20gJ0Avc2NoZW1hcy9uZnQtc2VhcmNoJ1xuXG5pbnRlcmZhY2UgTmZ0Q2F0YWxvZ1Byb3BzIHtcbiAgc2VhcmNoOiBOZnRDYXRhbG9nU2VhcmNoXG4gIG9uRmlsdGVyQ2hhbmdlOiAodXBkYXRlczogUGFydGlhbDxPbWl0PE5mdENhdGFsb2dTZWFyY2gsICdwYWdlJz4+KSA9PiB2b2lkXG4gIG9uUGFnZUNoYW5nZTogKG5leHRQYWdlOiBudW1iZXIpID0+IHZvaWRcbiAgb25SZXNldEZpbHRlcnM6ICgpID0+IHZvaWRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIE5mdENhdGFsb2coe1xuICBzZWFyY2gsXG4gIG9uRmlsdGVyQ2hhbmdlLFxuICBvblBhZ2VDaGFuZ2UsXG4gIG9uUmVzZXRGaWx0ZXJzLFxufTogTmZ0Q2F0YWxvZ1Byb3BzKSB7XG4gIGNvbnN0IHsgZGF0YSwgaXNMb2FkaW5nLCBpc0Vycm9yLCBpc1N1Y2Nlc3MsIGlzRmV0Y2hpbmcsIGVycm9yLCByZWZldGNoIH0gPSB1c2VHZXRORlRzKHNlYXJjaClcbiAgY29uc3QgbGNwSW1hZ2VVcmwgPSBkYXRhPy5pdGVtc1swXT8uaW1hZ2VVcmxcblxuICByZXR1cm4gKFxuICAgIDxtYWluXG4gICAgICBpZD1cIm1haW4tY29udGVudFwiXG4gICAgICB0YWJJbmRleD17LTF9XG4gICAgICBjbGFzc05hbWU9XCJteC1hdXRvIGdyaWQgdy1mdWxsIG1heC13LTd4bCBnYXAtNiBweC00IHB5LTYgb3V0bGluZS1ub25lIHNtOnB4LTYgbWQ6cHktMTAgbGc6cHgtOFwiXG4gICAgPlxuICAgICAgey8qIFByZWxvYWQgbmF0aXZvIGRhIGltYWdlbSBMQ1AgZG8gY2F0w6Fsb2dvIChSZWFjdCAxOSBob2lzdHMgcGFyYSA8aGVhZD4pICovfVxuICAgICAge2xjcEltYWdlVXJsICYmIDxsaW5rIHJlbD1cInByZWxvYWRcIiBhcz1cImltYWdlXCIgaHJlZj17bGNwSW1hZ2VVcmx9IGZldGNoUHJpb3JpdHk9XCJoaWdoXCIgLz59XG5cbiAgICAgIHsvKiBIZXJvIFNlY3Rpb24gTW9iaWxlLUZpcnN0ICovfVxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwiYmctbXV0ZWQvMzVcIj5cbiAgICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wganVzdGlmeS1iZXR3ZWVuIGdhcC00IHB5LTIgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIG1heC13LTJ4bCBnYXAtMlwiPlxuICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCIgY2xhc3NOYW1lPVwidy1maXQgZ2FwLTEuNSBiZy1iYWNrZ3JvdW5kXCI+XG4gICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJzaXplLTMuNSB0ZXh0LXByaW1hcnlcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5DdXJhZG9yaWEgV2ViMyBWZXJpZmljYWRhPC9zcGFuPlxuICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgc206dGV4dC0zeGwgbWQ6dGV4dC00eGxcIj5cbiAgICAgICAgICAgICAgRXhwbG9yZSBDb2xlY2lvbsOhdmVpcyBEaWdpdGFpcyBSYXJvc1xuICAgICAgICAgICAgPC9oMT5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIHNtOnRleHQtYmFzZVwiPlxuICAgICAgICAgICAgICBEZXNjdWJyYSwgZmF2b3JpdGUgZSBjb2xlY2lvbmUgb2JyYXMgZXhjbHVzaXZhcyBlbSBFVEggY29tIHByZWNpc8OjbyBkZWNpbWFsIGdhcmFudGlkYS5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHtpc0ZldGNoaW5nICYmICFpc0xvYWRpbmcgJiYgKFxuICAgICAgICAgICAgPEJhZGdlXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIlxuICAgICAgICAgICAgICByb2xlPVwic3RhdHVzXCJcbiAgICAgICAgICAgICAgYXJpYS1saXZlPVwicG9saXRlXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2FwLTIgc2VsZi1zdGFydCBweC0zIHB5LTEuNSBzbTpzZWxmLWNlbnRlclwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxMb2FkZXIyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2l6ZS0zLjUgYW5pbWF0ZS1zcGluIG1vdGlvbi1yZWR1Y2U6YW5pbWF0ZS1ub25lXCJcbiAgICAgICAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8c3Bhbj5TaW5jcm9uaXphbmRvLi4uPC9zcGFuPlxuICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICApfVxuICAgICAgICA8L0NhcmRDb250ZW50PlxuICAgICAgPC9DYXJkPlxuXG4gICAgICB7LyogRmlsdHJvcyBzaW5jcm9uaXphZG9zIGNvbSBhIFVSTCAqL31cbiAgICAgIDxOZnRGaWx0ZXJzXG4gICAgICAgIHNlYXJjaD17c2VhcmNofVxuICAgICAgICBjb2xsZWN0aW9ucz17ZGF0YT8uY29sbGVjdGlvbnMgPz8gW119XG4gICAgICAgIG9uRmlsdGVyQ2hhbmdlPXtvbkZpbHRlckNoYW5nZX1cbiAgICAgICAgb25SZXNldEZpbHRlcnM9e29uUmVzZXRGaWx0ZXJzfVxuICAgICAgLz5cblxuICAgICAgey8qIEVzdGFkbyBkZSBDYXJyZWdhbWVudG8gSW5pY2lhbDogR3JpZCBkZSBTa2VsZXRvbnMgY29tIFNoaW1tZXIgKi99XG4gICAgICB7aXNMb2FkaW5nICYmIChcbiAgICAgICAgPHNlY3Rpb25cbiAgICAgICAgICBhcmlhLWJ1c3k9XCJ0cnVlXCJcbiAgICAgICAgICBhcmlhLWxhYmVsPVwiQ2FycmVnYW5kbyBjYXTDoWxvZ28gZGUgTkZUc1wiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMSBnYXAtNiBzbTpncmlkLWNvbHMtMiBsZzpncmlkLWNvbHMtMyB4bDpncmlkLWNvbHMtNFwiXG4gICAgICAgID5cbiAgICAgICAgICB7QXJyYXkuZnJvbSh7IGxlbmd0aDogc2VhcmNoLnBhZ2VTaXplIH0sIChfLCBpZHgpID0+IChcbiAgICAgICAgICAgIDxOZnRDYXJkU2tlbGV0b24ga2V5PXtpZHh9IC8+XG4gICAgICAgICAgKSl9XG4gICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBFc3RhZG8gZGUgRXJybyBjb20gUmV0cnkgKi99XG4gICAgICB7aXNFcnJvciAmJiAoXG4gICAgICAgIDxBbGVydCB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwic2l6ZS00XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICA8QWxlcnRUaXRsZT5GYWxoYSBhbyBjYXJyZWdhciBvIGNhdMOhbG9nbzwvQWxlcnRUaXRsZT5cbiAgICAgICAgICA8QWxlcnREZXNjcmlwdGlvbiBjbGFzc05hbWU9XCJtdC0yIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgIDxzcGFuPntnZXRFcnJvck1lc3NhZ2UoZXJyb3IpfTwvc3Bhbj5cbiAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiIHZhcmlhbnQ9XCJvdXRsaW5lXCIgc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gdm9pZCByZWZldGNoKCl9PlxuICAgICAgICAgICAgICA8UmVmcmVzaEN3IGNsYXNzTmFtZT1cInNpemUtMy41XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+VGVudGFyIG5vdmFtZW50ZTwvc3Bhbj5cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvQWxlcnREZXNjcmlwdGlvbj5cbiAgICAgICAgPC9BbGVydD5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBFc3RhZG8gZGUgU3VjZXNzbyAqL31cbiAgICAgIHtpc1N1Y2Nlc3MgJiYgZGF0YSAmJiAoXG4gICAgICAgIDw+XG4gICAgICAgICAge2RhdGEuaXRlbXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwiYm9yZGVyLWRhc2hlZFwiPlxuICAgICAgICAgICAgICA8Q2FyZENvbnRlbnRcbiAgICAgICAgICAgICAgICBhcmlhLWxpdmU9XCJwb2xpdGVcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0zIHB5LTEyIHRleHQtY2VudGVyXCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtYmFzZSBmb250LW1lZGl1bVwiPk5lbmh1bSBORlQgZW5jb250cmFkbyBwYXJhIGVzdGVzIGZpbHRyb3MuPC9wPlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1heC13LW1kIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICBFeHBlcmltZW50ZSBhanVzdGFyIG9zIGludGVydmFsb3MgZGUgcHJlw6dvIGVtIEVUSCwgdHJvY2FyIGEgY2F0ZWdvcmlhIG91IGxpbXBhciBhXG4gICAgICAgICAgICAgICAgICBidXNjYS5cbiAgICAgICAgICAgICAgICA8L3A+XG4gICAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgdmFyaWFudD1cIm91dGxpbmVcIiBzaXplPVwic21cIiBvbkNsaWNrPXtvblJlc2V0RmlsdGVyc30+XG4gICAgICAgICAgICAgICAgICBMaW1wYXIgZmlsdHJvc1xuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICA8L0NhcmRDb250ZW50PlxuICAgICAgICAgICAgPC9DYXJkPlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8c2VjdGlvblxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJMaXN0YSBkZSBORlRzXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIGdhcC02IHNtOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIHhsOmdyaWQtY29scy00XCJcbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtkYXRhLml0ZW1zLm1hcCgobmZ0LCBpbmRleCkgPT4gKFxuICAgICAgICAgICAgICAgICAgPE5mdENhcmQga2V5PXtuZnQuaWR9IG5mdD17bmZ0fSBwcmlvcml0eT17aW5kZXggPCAyfSAvPlxuICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgICAgICAgPE5mdFBhZ2luYXRpb25cbiAgICAgICAgICAgICAgICBwYWdlPXtkYXRhLnBhZ2V9XG4gICAgICAgICAgICAgICAgdG90YWxQYWdlcz17ZGF0YS50b3RhbFBhZ2VzfVxuICAgICAgICAgICAgICAgIHRvdGFsSXRlbXM9e2RhdGEudG90YWx9XG4gICAgICAgICAgICAgICAgb25QYWdlQ2hhbmdlPXtvblBhZ2VDaGFuZ2V9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApfVxuICAgICAgICA8Lz5cbiAgICAgICl9XG4gICAgPC9tYWluPlxuICApXG59XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9jb21wb25lbnRzL25mdC9uZnQtY2F0YWxvZy50c3gifQ==