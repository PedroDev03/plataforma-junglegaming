import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/navbar.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport15_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport15_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Link, useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { Compass, Heart, LogIn, LogOut, Menu, ShoppingBag, Sparkles, User as UserIcon, UserPlus } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { CartDrawer } from "/src/components/cart/cart-drawer.tsx";
import { SocketStatusMenu } from "/src/components/layout/socket-status-menu.tsx";
import { Avatar, AvatarFallback } from "/src/components/ui/avatar.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button, buttonVariants } from "/src/components/ui/button.tsx";
import { DropdownMenu, DropdownMenuContent, DropdownMenuGroup, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "/src/components/ui/dropdown-menu.tsx";
import { Separator } from "/src/components/ui/separator.tsx";
import { Sheet, SheetClose, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "/src/components/ui/sheet.tsx";
import { useLogout, useMe } from "/src/hooks/use-auth.ts";
import { formatEth } from "/src/lib/eth.ts";
import { useIsAuthenticated } from "/src/lib/session.ts";
import { cn, getInitials } from "/src/lib/utils.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/layout/navbar.tsx";
import __vite__cjsImport15_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
export function Navbar() {
	_s();
	const $ = _c(29);
	if ($[0] !== "c19ed687db3126baef5b03138506cf1873dc126549a2926ebdf4d9c45c876996") {
		for (let $i = 0; $i < 29; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "c19ed687db3126baef5b03138506cf1873dc126549a2926ebdf4d9c45c876996";
	}
	const isAuthenticated = useIsAuthenticated();
	const { data: user } = useMe();
	const logout = useLogout();
	const router = useRouter();
	let t0;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ _jsxDEV(Link, {
			to: "/",
			className: "flex items-center gap-2.5 rounded-md font-bold tracking-tight text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
			children: [/* @__PURE__ */ _jsxDEV("span", {
				className: "flex size-8 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-xs",
				children: /* @__PURE__ */ _jsxDEV(Sparkles, {
					className: "size-4",
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 299
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 185
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "text-base sm:text-lg",
				children: "JungleNFT"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 32,
				columnNumber: 356
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 10
		}, this);
		$[1] = t0;
	} else {
		t0 = $[1];
	}
	let t1;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ _jsxDEV(Link, {
			to: "/",
			className: cn(buttonVariants({
				variant: "ghost",
				size: "sm"
			})),
			activeProps: { className: "bg-accent text-accent-foreground" },
			children: [/* @__PURE__ */ _jsxDEV(Compass, {
				className: "size-4",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 8
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Explorar" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 44,
				columnNumber: 57
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 10
		}, this);
		$[2] = t1;
	} else {
		t1 = $[2];
	}
	let t2;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV(Link, {
			to: "/",
			search: { onlyFavorites: true },
			className: cn(buttonVariants({
				variant: "ghost",
				size: "sm"
			})),
			children: [/* @__PURE__ */ _jsxDEV(Heart, {
				className: "size-4",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 10
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Favoritos" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 57
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 10
		}, this);
		$[3] = t2;
	} else {
		t2 = $[3];
	}
	let t3;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-6",
			children: [t0, /* @__PURE__ */ _jsxDEV("nav", {
				"aria-label": "Navegação principal",
				className: "hidden items-center gap-1 md:flex",
				children: [
					t1,
					t2,
					/* @__PURE__ */ _jsxDEV(Link, {
						to: "/cart",
						className: cn(buttonVariants({
							variant: "ghost",
							size: "sm"
						})),
						activeProps: { className: "bg-accent text-accent-foreground" },
						children: [/* @__PURE__ */ _jsxDEV(ShoppingBag, {
							className: "size-4",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 12
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Carrinho" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 68,
							columnNumber: 65
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 155
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 55
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 10
		}, this);
		$[4] = t3;
	} else {
		t3 = $[4];
	}
	let t4;
	let t5;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = /* @__PURE__ */ _jsxDEV(SocketStatusMenu, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 76,
			columnNumber: 10
		}, this);
		t5 = /* @__PURE__ */ _jsxDEV(CartDrawer, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 77,
			columnNumber: 10
		}, this);
		$[5] = t4;
		$[6] = t5;
	} else {
		t4 = $[5];
		t5 = $[6];
	}
	let t6;
	if ($[7] !== isAuthenticated || $[8] !== user) {
		t6 = isAuthenticated && user && /* @__PURE__ */ _jsxDEV(Badge, {
			variant: "secondary",
			className: "hidden font-mono tabular-nums sm:inline-flex",
			children: [formatEth(user.balanceEth, 2), " ETH"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 86,
			columnNumber: 37
		}, this);
		$[7] = isAuthenticated;
		$[8] = user;
		$[9] = t6;
	} else {
		t6 = $[9];
	}
	let t7;
	if ($[10] !== isAuthenticated || $[11] !== logout || $[12] !== router || $[13] !== user?.email || $[14] !== user?.name) {
		t7 = isAuthenticated ? /* @__PURE__ */ _jsxDEV(DropdownMenu, { children: [/* @__PURE__ */ _jsxDEV(DropdownMenuTrigger, {
			render: /* @__PURE__ */ _jsxDEV(Button, {
				variant: "outline",
				size: "sm",
				className: "gap-2 pl-1.5",
				"aria-label": "Abrir menu da conta"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 71
			}, this),
			children: [/* @__PURE__ */ _jsxDEV(Avatar, {
				size: "sm",
				children: /* @__PURE__ */ _jsxDEV(AvatarFallback, { children: getInitials(user?.name ?? "Colecionador") }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 187
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 169
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "hidden max-w-28 truncate sm:inline",
				children: user?.name ?? "Minha Conta"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 95,
				columnNumber: 272
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 42
		}, this), /* @__PURE__ */ _jsxDEV(DropdownMenuContent, {
			align: "end",
			className: "w-56",
			children: [
				/* @__PURE__ */ _jsxDEV(DropdownMenuGroup, { children: /* @__PURE__ */ _jsxDEV(DropdownMenuLabel, {
					className: "truncate",
					children: user?.email ?? "Colecionador autenticado"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 452
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 433
				}, this),
				/* @__PURE__ */ _jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 575
				}, this),
				/* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
					onClick: () => void router.navigate({ to: "/profile" }),
					children: [/* @__PURE__ */ _jsxDEV(UserIcon, {
						className: "size-4",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Perfil do Colecionador" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 63
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 600
				}, this),
				/* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
					onClick: () => void router.navigate({ to: "/cart" }),
					children: [/* @__PURE__ */ _jsxDEV(ShoppingBag, {
						className: "size-4",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Meu Carrinho" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 66
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 117
				}, this),
				/* @__PURE__ */ _jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 99,
					columnNumber: 110
				}, this),
				/* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
					variant: "destructive",
					onClick: logout,
					children: [/* @__PURE__ */ _jsxDEV(LogOut, {
						className: "size-4",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 192
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Sair da conta" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 240
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 99,
					columnNumber: 135
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 383
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 95,
			columnNumber: 28
		}, this) : /* @__PURE__ */ _jsxDEV("div", {
			className: "hidden items-center gap-2 sm:flex",
			children: [/* @__PURE__ */ _jsxDEV(Link, {
				to: "/login",
				search: {},
				className: cn(buttonVariants({
					variant: "ghost",
					size: "sm"
				})),
				children: [/* @__PURE__ */ _jsxDEV(LogIn, {
					className: "size-4",
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 12
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Entrar" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 59
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 99,
				columnNumber: 376
			}, this), /* @__PURE__ */ _jsxDEV(Link, {
				to: "/register",
				className: cn(buttonVariants({
					variant: "default",
					size: "sm"
				})),
				children: [/* @__PURE__ */ _jsxDEV(UserPlus, {
					className: "size-4",
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 105,
					columnNumber: 12
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Criar conta" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 105,
					columnNumber: 62
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 85
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 99,
			columnNumber: 325
		}, this);
		$[10] = isAuthenticated;
		$[11] = logout;
		$[12] = router;
		$[13] = user?.email;
		$[14] = user?.name;
		$[15] = t7;
	} else {
		t7 = $[15];
	}
	let t8;
	if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
		t8 = /* @__PURE__ */ _jsxDEV(SheetTrigger, {
			render: /* @__PURE__ */ _jsxDEV(Button, {
				variant: "ghost",
				size: "icon",
				className: "md:hidden",
				"aria-label": "Abrir menu de navegação"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 32
			}, this),
			children: /* @__PURE__ */ _jsxDEV(Menu, {
				className: "size-5",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 139
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 117,
			columnNumber: 10
		}, this);
		$[16] = t8;
	} else {
		t8 = $[16];
	}
	let t10;
	let t9;
	if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
		t9 = /* @__PURE__ */ _jsxDEV(SheetHeader, { children: [/* @__PURE__ */ _jsxDEV(SheetTitle, { children: "JungleNFT" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 125,
			columnNumber: 23
		}, this), /* @__PURE__ */ _jsxDEV(SheetDescription, { children: "Navegue pelo marketplace Web3." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 125,
			columnNumber: 57
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 125,
			columnNumber: 10
		}, this);
		t10 = /* @__PURE__ */ _jsxDEV(Separator, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 126,
			columnNumber: 11
		}, this);
		$[17] = t10;
		$[18] = t9;
	} else {
		t10 = $[17];
		t9 = $[18];
	}
	let t11;
	if ($[19] === Symbol.for("react.memo_cache_sentinel")) {
		t11 = /* @__PURE__ */ _jsxDEV(SheetClose, {
			render: /* @__PURE__ */ _jsxDEV(Link, {
				to: "/",
				className: cn(buttonVariants({
					variant: "ghost",
					size: "default"
				}), "justify-start")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 135,
				columnNumber: 31
			}, this),
			children: [/* @__PURE__ */ _jsxDEV(Compass, {
				className: "size-4",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 138,
				columnNumber: 31
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Explorar Catálogo" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 138,
				columnNumber: 80
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 135,
			columnNumber: 11
		}, this);
		$[19] = t11;
	} else {
		t11 = $[19];
	}
	let t12;
	if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
		t12 = /* @__PURE__ */ _jsxDEV(SheetClose, {
			render: /* @__PURE__ */ _jsxDEV(Link, {
				to: "/",
				search: { onlyFavorites: true },
				className: cn(buttonVariants({
					variant: "ghost",
					size: "default"
				}), "justify-start")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 145,
				columnNumber: 31
			}, this),
			children: [/* @__PURE__ */ _jsxDEV(Heart, {
				className: "size-4",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 150,
				columnNumber: 31
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Meus Favoritos" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 150,
				columnNumber: 78
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 145,
			columnNumber: 11
		}, this);
		$[20] = t12;
	} else {
		t12 = $[20];
	}
	let t13;
	if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
		t13 = /* @__PURE__ */ _jsxDEV(SheetClose, {
			render: /* @__PURE__ */ _jsxDEV(Link, {
				to: "/cart",
				className: cn(buttonVariants({
					variant: "ghost",
					size: "default"
				}), "justify-start")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 157,
				columnNumber: 31
			}, this),
			children: [/* @__PURE__ */ _jsxDEV(ShoppingBag, {
				className: "size-4",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 160,
				columnNumber: 31
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Carrinho" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 160,
				columnNumber: 84
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 157,
			columnNumber: 11
		}, this);
		$[21] = t13;
	} else {
		t13 = $[21];
	}
	let t14;
	if ($[22] !== isAuthenticated || $[23] !== logout) {
		t14 = /* @__PURE__ */ _jsxDEV(Sheet, {
			modal: true,
			children: [t8, /* @__PURE__ */ _jsxDEV(SheetContent, {
				side: "right",
				className: "flex flex-col",
				children: [
					t9,
					t10,
					/* @__PURE__ */ _jsxDEV("nav", {
						"aria-label": "Menu mobile",
						className: "grid gap-1 px-4",
						children: [
							t11,
							t12,
							t13,
							isAuthenticated ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV(SheetClose, {
									render: /* @__PURE__ */ _jsxDEV(Link, {
										to: "/profile",
										className: cn(buttonVariants({
											variant: "ghost",
											size: "default"
										}), "justify-start")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 167,
										columnNumber: 211
									}, this),
									children: [/* @__PURE__ */ _jsxDEV(UserIcon, {
										className: "size-4",
										"aria-hidden": "true"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 170,
										columnNumber: 39
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Perfil do Colecionador" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 170,
										columnNumber: 89
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 167,
									columnNumber: 191
								}, this),
								/* @__PURE__ */ _jsxDEV(Separator, { className: "my-2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 170,
									columnNumber: 137
								}, this),
								/* @__PURE__ */ _jsxDEV(Button, {
									type: "button",
									variant: "destructive",
									className: "justify-start",
									onClick: logout,
									children: [/* @__PURE__ */ _jsxDEV(LogOut, {
										className: "size-4",
										"aria-hidden": "true"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 170,
										columnNumber: 254
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Sair da conta" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 170,
										columnNumber: 302
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 170,
									columnNumber: 167
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 167,
								columnNumber: 189
							}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
								/* @__PURE__ */ _jsxDEV(Separator, { className: "my-2" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 170,
									columnNumber: 345
								}, this),
								/* @__PURE__ */ _jsxDEV(SheetClose, {
									render: /* @__PURE__ */ _jsxDEV(Link, {
										to: "/login",
										search: {},
										className: cn(buttonVariants({
											variant: "outline",
											size: "default"
										}), "w-full")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 170,
										columnNumber: 395
									}, this),
									children: [/* @__PURE__ */ _jsxDEV(LogIn, {
										className: "size-4",
										"aria-hidden": "true"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 173,
										columnNumber: 32
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Entrar" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 173,
										columnNumber: 79
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 170,
									columnNumber: 375
								}, this),
								/* @__PURE__ */ _jsxDEV(SheetClose, {
									render: /* @__PURE__ */ _jsxDEV(Link, {
										to: "/register",
										className: cn(buttonVariants({
											variant: "default",
											size: "default"
										}), "w-full")
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 173,
										columnNumber: 131
									}, this),
									children: [/* @__PURE__ */ _jsxDEV(UserPlus, {
										className: "size-4",
										"aria-hidden": "true"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 176,
										columnNumber: 32
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Criar conta" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 176,
										columnNumber: 82
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 173,
									columnNumber: 111
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 170,
								columnNumber: 343
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 167,
						columnNumber: 97
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 167,
				columnNumber: 35
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 167,
			columnNumber: 11
		}, this);
		$[22] = isAuthenticated;
		$[23] = logout;
		$[24] = t14;
	} else {
		t14 = $[24];
	}
	let t15;
	if ($[25] !== t14 || $[26] !== t6 || $[27] !== t7) {
		t15 = /* @__PURE__ */ _jsxDEV("header", {
			className: "sticky top-0 z-40 border-b bg-background/85 backdrop-blur-md",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "mx-auto flex h-16 max-w-7xl items-center justify-between gap-3 px-4 sm:px-6 lg:px-8",
				children: [t3, /* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [
						t4,
						t5,
						t6,
						t7,
						t14
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 185,
					columnNumber: 197
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 185,
				columnNumber: 92
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 185,
			columnNumber: 11
		}, this);
		$[25] = t14;
		$[26] = t6;
		$[27] = t7;
		$[28] = t15;
	} else {
		t15 = $[28];
	}
	return t15;
}
_s(Navbar, "kdoU5lyN1pcxN92omuvZBJ9EGNc=", false, function() {
	return [
		useIsAuthenticated,
		useMe,
		useLogout,
		useRouter
	];
});
_c2 = Navbar;
var _c2;
$RefreshReg$(_c2, "Navbar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/navbar.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/layout/navbar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/layout/navbar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/layout/navbar.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLE1BQU1DLGlCQUFpQjtBQUNoQyxTQUNFQyxTQUNBQyxPQUNBQyxPQUNBQyxRQUNBQyxNQUNBQyxhQUNBQyxVQUNBQyxRQUFRQyxVQUNSQyxnQkFDSztBQUNQLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyx3QkFBd0I7QUFDakMsU0FBU0MsUUFBUUMsc0JBQXNCO0FBQ3ZDLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsUUFBUUMsc0JBQXNCO0FBQ3ZDLFNBQ0VDLGNBQ0FDLHFCQUNBQyxtQkFDQUMsa0JBQ0FDLG1CQUNBQyx1QkFDQUMsMkJBQ0s7QUFDUCxTQUFTQyxpQkFBaUI7QUFDMUIsU0FDRUMsT0FDQUMsWUFDQUMsY0FDQUMsa0JBQ0FDLGFBQ0FDLFlBQ0FDLG9CQUNLO0FBQ1AsU0FBU0MsV0FBV0MsYUFBYTtBQUNqQyxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsMEJBQTBCO0FBQ25DLFNBQVNDLElBQUlDLG1CQUFtQjs7OztBQUVoQyxPQUFPLFNBQUFDLFNBQUE7O0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQ0wsTUFBQUssa0JBQXdCVCxtQkFBbUI7Q0FDM0MsUUFBQVUsTUFBQUMsU0FBdUJiLE1BQU07Q0FDN0IsTUFBQWMsU0FBZWYsVUFBVTtDQUN6QixNQUFBZ0IsU0FBZWpELFVBQVU7Q0FBQyxJQUFBa0Q7Q0FBQSxJQUFBVixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFNbEJNLEtBQUEsd0JBQUMsTUFBRDtHQUNLO0dBQ087YUFGWixDQUlFO0lBQWdCO2NBQ2Qsd0JBQUMsVUFBRDtLQUFvQjtLQUFxQjtJQUFNOzs7OztHQUMxQzs7OzthQUNQO0lBQWdCO2NBQXVCO0dBQWdCOzs7O1dBUHBEOzs7Ozs7RUFRRVYsRUFBQSxLQUFBVTtDQUFBO0VBQUFBLEtBQUFWLEVBQUE7Q0FBQTtDQUFBLElBQUFXO0NBQUEsSUFBQVgsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBR0xPLEtBQUEsd0JBQUMsTUFBRDtHQUNLO0dBQ1EsV0FBQWQsR0FBR3BCLGVBQWU7SUFBQW1DLFNBQVc7SUFBT0MsTUFBUTtHQUFLLENBQUMsQ0FBQztHQUNqRCxlQUFBQyxXQUFhLG1DQUFtQzthQUgvRCxDQUtFLHdCQUFDLFNBQUQ7SUFBbUI7SUFBcUI7R0FBTTs7OzthQUM5Qyw0Q0FBTSxXQUFlOzs7O1dBTmxCOzs7Ozs7RUFPRWQsRUFBQSxLQUFBVztDQUFBO0VBQUFBLEtBQUFYLEVBQUE7Q0FBQTtDQUFBLElBQUFlO0NBQUEsSUFBQWYsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBRVBXLEtBQUEsd0JBQUMsTUFBRDtHQUNLO0dBQ0ssVUFBQUMsZUFBaUIsS0FBSztHQUNuQixXQUFBbkIsR0FBR3BCLGVBQWU7SUFBQW1DLFNBQVc7SUFBT0MsTUFBUTtHQUFLLENBQUMsQ0FBQzthQUhoRSxDQUtFLHdCQUFDLE9BQUQ7SUFBaUI7SUFBcUI7R0FBTTs7OzthQUM1Qyw0Q0FBTSxZQUFnQjs7OztXQU5uQjs7Ozs7O0VBT0ViLEVBQUEsS0FBQWU7Q0FBQTtFQUFBQSxLQUFBZixFQUFBO0NBQUE7Q0FBQSxJQUFBaUI7Q0FBQSxJQUFBakIsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBNUJYYSxLQUFBO0dBQWU7YUFBZixDQUNFUCxJQVVBO0lBQWdCO0lBQWdDO2NBQWhEO0tBQ0VDO0tBU0FJO0tBU0Esd0JBQUMsTUFBRDtNQUNLO01BQ1EsV0FBQWxCLEdBQUdwQixlQUFlO09BQUFtQyxTQUFXO09BQU9DLE1BQVE7TUFBSyxDQUFDLENBQUM7TUFDakQsZUFBQUMsV0FBYSxtQ0FBbUM7Z0JBSC9ELENBS0Usd0JBQUMsYUFBRDtPQUF1QjtPQUFxQjtNQUFNOzs7O2dCQUNsRCw0Q0FBTSxXQUFlOzs7O2NBTmxCOzs7Ozs7SUFRRDs7Ozs7V0FDRjs7Ozs7O0VBQUFkLEVBQUEsS0FBQWlCO0NBQUE7RUFBQUEsS0FBQWpCLEVBQUE7Q0FBQTtDQUFBLElBQUFrQjtDQUFBLElBQUFDO0NBQUEsSUFBQW5CLEVBQUEsT0FBQUcsT0FBQUMsSUFBQTtFQUlKYyxLQUFBLHdCQUFDLGtCQUFELENBQWlCOzs7OztFQUNqQkMsS0FBQSx3QkFBQyxZQUFELENBQVc7Ozs7O0VBQUduQixFQUFBLEtBQUFrQjtFQUFBbEIsRUFBQSxLQUFBbUI7Q0FBQTtFQUFBRCxLQUFBbEIsRUFBQTtFQUFBbUIsS0FBQW5CLEVBQUE7Q0FBQTtDQUFBLElBQUFvQjtDQUFBLElBQUFwQixFQUFBLE9BQUFLLG1CQUFBTCxFQUFBLE9BQUFPLE1BQUE7RUFFYmEsS0FBQWYsbUJBQUFFLFFBQ0Msd0JBQUMsT0FBRDtHQUFlO0dBQXNCO2FBQXJDLENBQ0daLFVBQVVZLEtBQUljLFlBQWEsQ0FBQyxHQUFFLE1BRDNCOzs7Ozs7RUFHUHJCLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTztFQUFBUCxFQUFBLEtBQUFvQjtDQUFBO0VBQUFBLEtBQUFwQixFQUFBO0NBQUE7Q0FBQSxJQUFBc0I7Q0FBQSxJQUFBdEIsRUFBQSxRQUFBSyxtQkFBQUwsRUFBQSxRQUFBUSxVQUFBUixFQUFBLFFBQUFTLFVBQUFULEVBQUEsUUFBQU8sTUFBQWdCLFNBQUF2QixFQUFBLFFBQUFPLE1BQUFpQixNQUFBO0VBRUFGLEtBQUFqQixrQkFDQyx3QkFBQyxjQUFELGFBQ0Usd0JBQUMscUJBQUQ7R0FFSSxnQ0FBQyxRQUFEO0lBQ1U7SUFDSDtJQUNLO0lBQ0M7R0FBcUI7Ozs7O2FBTnRDLENBVUUsd0JBQUMsUUFBRDtJQUFhO2NBQ1gsd0JBQUMsZ0JBQUQsWUFBaUJQLFlBQVlTLE1BQUlpQixRQUFKLGNBQTRCLEVBQTFDOzs7OztHQURWOzs7O2FBR1A7SUFBZ0I7Y0FDYmpCLE1BQUlpQixRQUFKO0dBQ0k7Ozs7V0FmVzs7Ozs7WUFrQnBCLHdCQUFDLHFCQUFEO0dBQTJCO0dBQWdCO2FBQTNDO0lBQ0Usd0JBQUMsbUJBQUQsWUFDRSx3QkFBQyxtQkFBRDtLQUE2QjtlQUMxQmpCLE1BQUlnQixTQUFKO0lBRGU7Ozs7YUFERjs7Ozs7SUFLbEIsd0JBQUMsdUJBQUQsQ0FBc0I7Ozs7O0lBQ3RCLHdCQUFDLGtCQUFEO0tBQTJCLGVBQU0sS0FBS2QsT0FBTWdCLFNBQVUsRUFBQUMsSUFBTSxXQUFXLENBQUM7ZUFBeEUsQ0FDRSx3QkFBQyxVQUFEO01BQW9CO01BQXFCO0tBQU07Ozs7ZUFDL0MsNENBQU0seUJBQTZCOzs7O2FBRnBCOzs7Ozs7SUFJakIsd0JBQUMsa0JBQUQ7S0FBMkIsZUFBTSxLQUFLakIsT0FBTWdCLFNBQVUsRUFBQUMsSUFBTSxRQUFRLENBQUM7ZUFBckUsQ0FDRSx3QkFBQyxhQUFEO01BQXVCO01BQXFCO0tBQU07Ozs7ZUFDbEQsNENBQU0sZUFBbUI7Ozs7YUFGVjs7Ozs7O0lBSWpCLHdCQUFDLHVCQUFELENBQXNCOzs7OztJQUN0Qix3QkFBQyxrQkFBRDtLQUEwQjtLQUF1QmxCO2VBQWpELENBQ0Usd0JBQUMsUUFBRDtNQUFrQjtNQUFxQjtLQUFNOzs7O2VBQzdDLDRDQUFNLGdCQUFvQjs7OzthQUZYOzs7Ozs7R0FoQkM7Ozs7O1VBbkJUOzs7O2FBMENiO0dBQWU7YUFBZixDQUNFLHdCQUFDLE1BQUQ7SUFDSztJQUNLLFNBQUM7SUFDRSxXQUFBWCxHQUFHcEIsZUFBZTtLQUFBbUMsU0FBVztLQUFPQyxNQUFRO0lBQUssQ0FBQyxDQUFDO2NBSGhFLENBS0Usd0JBQUMsT0FBRDtLQUFpQjtLQUFxQjtJQUFNOzs7O2NBQzVDLDRDQUFNLFNBQWE7Ozs7WUFOaEI7Ozs7O2FBUUwsd0JBQUMsTUFBRDtJQUNLO0lBQ1EsV0FBQWhCLEdBQUdwQixlQUFlO0tBQUFtQyxTQUFXO0tBQVNDLE1BQVE7SUFBSyxDQUFDLENBQUM7Y0FGbEUsQ0FJRSx3QkFBQyxVQUFEO0tBQW9CO0tBQXFCO0lBQU07Ozs7Y0FDL0MsNENBQU0sY0FBa0I7Ozs7WUFMckI7Ozs7O1dBT0Q7Ozs7OztFQUNQYixFQUFBLE1BQUFLO0VBQUFMLEVBQUEsTUFBQVE7RUFBQVIsRUFBQSxNQUFBUztFQUFBVCxFQUFBLE1BQUFPLE1BQUFnQjtFQUFBdkIsRUFBQSxNQUFBTyxNQUFBaUI7RUFBQXhCLEVBQUEsTUFBQXNCO0NBQUE7RUFBQUEsS0FBQXRCLEVBQUE7Q0FBQTtDQUFBLElBQUEyQjtDQUFBLElBQUEzQixFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFJQ3VCLEtBQUEsd0JBQUMsY0FBRDtHQUVJLGdDQUFDLFFBQUQ7SUFDVTtJQUNIO0lBQ0s7SUFDQztHQUF5Qjs7Ozs7YUFJeEMsd0JBQUMsTUFBRDtJQUFnQjtJQUFxQjtHQUFNOzs7OztFQVZoQzs7Ozs7RUFXRTNCLEVBQUEsTUFBQTJCO0NBQUE7RUFBQUEsS0FBQTNCLEVBQUE7Q0FBQTtDQUFBLElBQUE0QjtDQUFBLElBQUFDO0NBQUEsSUFBQTdCLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUdieUIsS0FBQSx3QkFBQyxhQUFELGFBQ0Usd0JBQUMsWUFBRCxZQUFZLFlBQUQ7Ozs7WUFDWCx3QkFBQyxrQkFBRCxZQUFrQixpQ0FBRDs7OztVQUZQOzs7OztFQUtaRCxNQUFBLHdCQUFDLFdBQUQsQ0FBVTs7Ozs7RUFBRzVCLEVBQUEsTUFBQTRCO0VBQUE1QixFQUFBLE1BQUE2QjtDQUFBO0VBQUFELE1BQUE1QixFQUFBO0VBQUE2QixLQUFBN0IsRUFBQTtDQUFBO0NBQUEsSUFBQThCO0NBQUEsSUFBQTlCLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUdYMEIsTUFBQSx3QkFBQyxZQUFEO0dBRUksZ0NBQUMsTUFBRDtJQUNLO0lBQ1EsV0FBQWpDLEdBQUdwQixlQUFlO0tBQUFtQyxTQUFXO0tBQU9DLE1BQVE7SUFBVSxDQUFDLEdBQUcsZUFBZTtHQUFDOzs7OzthQUozRixDQVFFLHdCQUFDLFNBQUQ7SUFBbUI7SUFBcUI7R0FBTTs7OzthQUM5Qyw0Q0FBTSxvQkFBd0I7Ozs7V0FUckI7Ozs7OztFQVVFYixFQUFBLE1BQUE4QjtDQUFBO0VBQUFBLE1BQUE5QixFQUFBO0NBQUE7Q0FBQSxJQUFBK0I7Q0FBQSxJQUFBL0IsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBRWIyQixNQUFBLHdCQUFDLFlBQUQ7R0FFSSxnQ0FBQyxNQUFEO0lBQ0s7SUFDSyxVQUFBZixlQUFpQixLQUFLO0lBQ25CLFdBQUFuQixHQUFHcEIsZUFBZTtLQUFBbUMsU0FBVztLQUFPQyxNQUFRO0lBQVUsQ0FBQyxHQUFHLGVBQWU7R0FBQzs7Ozs7YUFMM0YsQ0FTRSx3QkFBQyxPQUFEO0lBQWlCO0lBQXFCO0dBQU07Ozs7YUFDNUMsNENBQU0saUJBQXFCOzs7O1dBVmxCOzs7Ozs7RUFXRWIsRUFBQSxNQUFBK0I7Q0FBQTtFQUFBQSxNQUFBL0IsRUFBQTtDQUFBO0NBQUEsSUFBQWdDO0NBQUEsSUFBQWhDLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUViNEIsTUFBQSx3QkFBQyxZQUFEO0dBRUksZ0NBQUMsTUFBRDtJQUNLO0lBQ1EsV0FBQW5DLEdBQUdwQixlQUFlO0tBQUFtQyxTQUFXO0tBQU9DLE1BQVE7SUFBVSxDQUFDLEdBQUcsZUFBZTtHQUFDOzs7OzthQUozRixDQVFFLHdCQUFDLGFBQUQ7SUFBdUI7SUFBcUI7R0FBTTs7OzthQUNsRCw0Q0FBTSxXQUFlOzs7O1dBVFo7Ozs7OztFQVVFYixFQUFBLE1BQUFnQztDQUFBO0VBQUFBLE1BQUFoQyxFQUFBO0NBQUE7Q0FBQSxJQUFBaUM7Q0FBQSxJQUFBakMsRUFBQSxRQUFBSyxtQkFBQUwsRUFBQSxRQUFBUSxRQUFBO0VBMURuQnlCLE1BQUEsd0JBQUMsT0FBRDtHQUFPO2FBQVAsQ0FDRU4sSUFhQSx3QkFBQyxjQUFEO0lBQW1CO0lBQWtCO2NBQXJDO0tBQ0VFO0tBS0FEO0tBRUE7TUFBZ0I7TUFBd0I7Z0JBQXhDO09BQ0VFO09BWUFDO09BYUFDO09BWUMzQixrQkFBQTtRQUVHLHdCQUFDLFlBQUQ7U0FFSSxnQ0FBQyxNQUFEO1VBQ0s7VUFDUSxXQUFBUixHQUNUcEIsZUFBZTtXQUFBbUMsU0FBVztXQUFPQyxNQUFRO1VBQVUsQ0FBQyxHQUNwRCxlQUNGO1NBQUM7Ozs7O21CQVBQLENBV0Usd0JBQUMsVUFBRDtVQUFvQjtVQUFxQjtTQUFNOzs7O21CQUMvQyw0Q0FBTSx5QkFBNkI7Ozs7aUJBWjFCOzs7Ozs7UUFjWCx3QkFBQyxXQUFELEVBQXFCLGtCQUFNOzs7OztRQUMzQix3QkFBQyxRQUFEO1NBQ087U0FDRztTQUNFO1NBQ0RMO21CQUpYLENBTUUsd0JBQUMsUUFBRDtVQUFrQjtVQUFxQjtTQUFNOzs7O21CQUM3Qyw0Q0FBTSxnQkFBb0I7Ozs7aUJBUHJCOzs7Ozs7T0FRRTs7OztrQkF6Qlo7UUE2Qkcsd0JBQUMsV0FBRCxFQUFxQixrQkFBTTs7Ozs7UUFDM0Isd0JBQUMsWUFBRDtTQUVJLGdDQUFDLE1BQUQ7VUFDSztVQUNLLFNBQUM7VUFDRSxXQUFBWCxHQUFHcEIsZUFBZTtXQUFBbUMsU0FBVztXQUFTQyxNQUFRO1VBQVUsQ0FBQyxHQUFHLFFBQVE7U0FBQzs7Ozs7bUJBTHRGLENBU0Usd0JBQUMsT0FBRDtVQUFpQjtVQUFxQjtTQUFNOzs7O21CQUM1Qyw0Q0FBTSxTQUFhOzs7O2lCQVZWOzs7Ozs7UUFZWCx3QkFBQyxZQUFEO1NBRUksZ0NBQUMsTUFBRDtVQUNLO1VBQ1EsV0FBQWhCLEdBQUdwQixlQUFlO1dBQUFtQyxTQUFXO1dBQVNDLE1BQVE7VUFBVSxDQUFDLEdBQUcsUUFBUTtTQUFDOzs7OzttQkFKdEYsQ0FRRSx3QkFBQyxVQUFEO1VBQW9CO1VBQXFCO1NBQU07Ozs7bUJBQy9DLDRDQUFNLGNBQWtCOzs7O2lCQVRmOzs7Ozs7T0FVRTs7Ozs7TUFHYjs7Ozs7O0lBckdLOzs7OztXQWRUOzs7Ozs7RUFxSEViLEVBQUEsTUFBQUs7RUFBQUwsRUFBQSxNQUFBUTtFQUFBUixFQUFBLE1BQUFpQztDQUFBO0VBQUFBLE1BQUFqQyxFQUFBO0NBQUE7Q0FBQSxJQUFBa0M7Q0FBQSxJQUFBbEMsRUFBQSxRQUFBaUMsT0FBQWpDLEVBQUEsUUFBQW9CLE1BQUFwQixFQUFBLFFBQUFzQixJQUFBO0VBMU9kWSxNQUFBO0dBQWtCO2FBQ2hCO0lBQWU7Y0FBZixDQUNFakIsSUEwQ0E7S0FBZTtlQUFmO01BQ0VDO01BQ0FDO01BRUNDO01BTUFFO01BK0REVztLQXNISTs7Ozs7WUFDRjs7Ozs7O0VBQ0M7Ozs7O0VBQUFqQyxFQUFBLE1BQUFpQztFQUFBakMsRUFBQSxNQUFBb0I7RUFBQXBCLEVBQUEsTUFBQXNCO0VBQUF0QixFQUFBLE1BQUFrQztDQUFBO0VBQUFBLE1BQUFsQyxFQUFBO0NBQUE7Q0FBQSxPQTdPVGtDO0FBNk9TIiwibmFtZXMiOlsiTGluayIsInVzZVJvdXRlciIsIkNvbXBhc3MiLCJIZWFydCIsIkxvZ0luIiwiTG9nT3V0IiwiTWVudSIsIlNob3BwaW5nQmFnIiwiU3BhcmtsZXMiLCJVc2VyIiwiVXNlckljb24iLCJVc2VyUGx1cyIsIkNhcnREcmF3ZXIiLCJTb2NrZXRTdGF0dXNNZW51IiwiQXZhdGFyIiwiQXZhdGFyRmFsbGJhY2siLCJCYWRnZSIsIkJ1dHRvbiIsImJ1dHRvblZhcmlhbnRzIiwiRHJvcGRvd25NZW51IiwiRHJvcGRvd25NZW51Q29udGVudCIsIkRyb3Bkb3duTWVudUdyb3VwIiwiRHJvcGRvd25NZW51SXRlbSIsIkRyb3Bkb3duTWVudUxhYmVsIiwiRHJvcGRvd25NZW51U2VwYXJhdG9yIiwiRHJvcGRvd25NZW51VHJpZ2dlciIsIlNlcGFyYXRvciIsIlNoZWV0IiwiU2hlZXRDbG9zZSIsIlNoZWV0Q29udGVudCIsIlNoZWV0RGVzY3JpcHRpb24iLCJTaGVldEhlYWRlciIsIlNoZWV0VGl0bGUiLCJTaGVldFRyaWdnZXIiLCJ1c2VMb2dvdXQiLCJ1c2VNZSIsImZvcm1hdEV0aCIsInVzZUlzQXV0aGVudGljYXRlZCIsImNuIiwiZ2V0SW5pdGlhbHMiLCJOYXZiYXIiLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsImlzQXV0aGVudGljYXRlZCIsImRhdGEiLCJ1c2VyIiwibG9nb3V0Iiwicm91dGVyIiwidDAiLCJ0MSIsInZhcmlhbnQiLCJzaXplIiwiY2xhc3NOYW1lIiwidDIiLCJvbmx5RmF2b3JpdGVzIiwidDMiLCJ0NCIsInQ1IiwidDYiLCJiYWxhbmNlRXRoIiwidDciLCJlbWFpbCIsIm5hbWUiLCJuYXZpZ2F0ZSIsInRvIiwidDgiLCJ0MTAiLCJ0OSIsInQxMSIsInQxMiIsInQxMyIsInQxNCIsInQxNSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJuYXZiYXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmssIHVzZVJvdXRlciB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQge1xuICBDb21wYXNzLFxuICBIZWFydCxcbiAgTG9nSW4sXG4gIExvZ091dCxcbiAgTWVudSxcbiAgU2hvcHBpbmdCYWcsXG4gIFNwYXJrbGVzLFxuICBVc2VyIGFzIFVzZXJJY29uLFxuICBVc2VyUGx1cyxcbn0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgQ2FydERyYXdlciB9IGZyb20gJ0AvY29tcG9uZW50cy9jYXJ0L2NhcnQtZHJhd2VyJ1xuaW1wb3J0IHsgU29ja2V0U3RhdHVzTWVudSB9IGZyb20gJ0AvY29tcG9uZW50cy9sYXlvdXQvc29ja2V0LXN0YXR1cy1tZW51J1xuaW1wb3J0IHsgQXZhdGFyLCBBdmF0YXJGYWxsYmFjayB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9hdmF0YXInXG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9iYWRnZSdcbmltcG9ydCB7IEJ1dHRvbiwgYnV0dG9uVmFyaWFudHMgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHtcbiAgRHJvcGRvd25NZW51LFxuICBEcm9wZG93bk1lbnVDb250ZW50LFxuICBEcm9wZG93bk1lbnVHcm91cCxcbiAgRHJvcGRvd25NZW51SXRlbSxcbiAgRHJvcGRvd25NZW51TGFiZWwsXG4gIERyb3Bkb3duTWVudVNlcGFyYXRvcixcbiAgRHJvcGRvd25NZW51VHJpZ2dlcixcbn0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2Ryb3Bkb3duLW1lbnUnXG5pbXBvcnQgeyBTZXBhcmF0b3IgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc2VwYXJhdG9yJ1xuaW1wb3J0IHtcbiAgU2hlZXQsXG4gIFNoZWV0Q2xvc2UsXG4gIFNoZWV0Q29udGVudCxcbiAgU2hlZXREZXNjcmlwdGlvbixcbiAgU2hlZXRIZWFkZXIsXG4gIFNoZWV0VGl0bGUsXG4gIFNoZWV0VHJpZ2dlcixcbn0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NoZWV0J1xuaW1wb3J0IHsgdXNlTG9nb3V0LCB1c2VNZSB9IGZyb20gJ0AvaG9va3MvdXNlLWF1dGgnXG5pbXBvcnQgeyBmb3JtYXRFdGggfSBmcm9tICdAL2xpYi9ldGgnXG5pbXBvcnQgeyB1c2VJc0F1dGhlbnRpY2F0ZWQgfSBmcm9tICdAL2xpYi9zZXNzaW9uJ1xuaW1wb3J0IHsgY24sIGdldEluaXRpYWxzIH0gZnJvbSAnQC9saWIvdXRpbHMnXG5cbmV4cG9ydCBmdW5jdGlvbiBOYXZiYXIoKSB7XG4gIGNvbnN0IGlzQXV0aGVudGljYXRlZCA9IHVzZUlzQXV0aGVudGljYXRlZCgpXG4gIGNvbnN0IHsgZGF0YTogdXNlciB9ID0gdXNlTWUoKVxuICBjb25zdCBsb2dvdXQgPSB1c2VMb2dvdXQoKVxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxuXG4gIHJldHVybiAoXG4gICAgPGhlYWRlciBjbGFzc05hbWU9XCJzdGlja3kgdG9wLTAgei00MCBib3JkZXItYiBiZy1iYWNrZ3JvdW5kLzg1IGJhY2tkcm9wLWJsdXItbWRcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXgtYXV0byBmbGV4IGgtMTYgbWF4LXctN3hsIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcHgtNCBzbTpweC02IGxnOnB4LThcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNlwiPlxuICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICB0bz1cIi9cIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIuNSByb3VuZGVkLW1kIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCB0ZXh0LWZvcmVncm91bmQgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLXJpbmdcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggc2l6ZS04IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciByb3VuZGVkLWxnIGJnLXByaW1hcnkgdGV4dC1wcmltYXJ5LWZvcmVncm91bmQgc2hhZG93LXhzXCI+XG4gICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1iYXNlIHNtOnRleHQtbGdcIj5KdW5nbGVORlQ8L3NwYW4+XG4gICAgICAgICAgPC9MaW5rPlxuXG4gICAgICAgICAgPG5hdiBhcmlhLWxhYmVsPVwiTmF2ZWdhw6fDo28gcHJpbmNpcGFsXCIgY2xhc3NOYW1lPVwiaGlkZGVuIGl0ZW1zLWNlbnRlciBnYXAtMSBtZDpmbGV4XCI+XG4gICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICB0bz1cIi9cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKGJ1dHRvblZhcmlhbnRzKHsgdmFyaWFudDogJ2dob3N0Jywgc2l6ZTogJ3NtJyB9KSl9XG4gICAgICAgICAgICAgIGFjdGl2ZVByb3BzPXt7IGNsYXNzTmFtZTogJ2JnLWFjY2VudCB0ZXh0LWFjY2VudC1mb3JlZ3JvdW5kJyB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8Q29tcGFzcyBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5FeHBsb3Jhcjwvc3Bhbj5cbiAgICAgICAgICAgIDwvTGluaz5cblxuICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgdG89XCIvXCJcbiAgICAgICAgICAgICAgc2VhcmNoPXt7IG9ubHlGYXZvcml0ZXM6IHRydWUgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihidXR0b25WYXJpYW50cyh7IHZhcmlhbnQ6ICdnaG9zdCcsIHNpemU6ICdzbScgfSkpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8SGVhcnQgY2xhc3NOYW1lPVwic2l6ZS00XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+RmF2b3JpdG9zPC9zcGFuPlxuICAgICAgICAgICAgPC9MaW5rPlxuXG4gICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICB0bz1cIi9jYXJ0XCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihidXR0b25WYXJpYW50cyh7IHZhcmlhbnQ6ICdnaG9zdCcsIHNpemU6ICdzbScgfSkpfVxuICAgICAgICAgICAgICBhY3RpdmVQcm9wcz17eyBjbGFzc05hbWU6ICdiZy1hY2NlbnQgdGV4dC1hY2NlbnQtZm9yZWdyb3VuZCcgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPFNob3BwaW5nQmFnIGNsYXNzTmFtZT1cInNpemUtNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgIDxzcGFuPkNhcnJpbmhvPC9zcGFuPlxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDwvbmF2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQcOnw7VlcyBEZXNrdG9wICsgTW9iaWxlICovfVxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgPFNvY2tldFN0YXR1c01lbnUgLz5cbiAgICAgICAgICA8Q2FydERyYXdlciAvPlxuXG4gICAgICAgICAge2lzQXV0aGVudGljYXRlZCAmJiB1c2VyICYmIChcbiAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwic2Vjb25kYXJ5XCIgY2xhc3NOYW1lPVwiaGlkZGVuIGZvbnQtbW9ubyB0YWJ1bGFyLW51bXMgc206aW5saW5lLWZsZXhcIj5cbiAgICAgICAgICAgICAge2Zvcm1hdEV0aCh1c2VyLmJhbGFuY2VFdGgsIDIpfSBFVEhcbiAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHtpc0F1dGhlbnRpY2F0ZWQgPyAoXG4gICAgICAgICAgICA8RHJvcGRvd25NZW51PlxuICAgICAgICAgICAgICA8RHJvcGRvd25NZW51VHJpZ2dlclxuICAgICAgICAgICAgICAgIHJlbmRlcj17XG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ2FwLTIgcGwtMS41XCJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkFicmlyIG1lbnUgZGEgY29udGFcIlxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8QXZhdGFyIHNpemU9XCJzbVwiPlxuICAgICAgICAgICAgICAgICAgPEF2YXRhckZhbGxiYWNrPntnZXRJbml0aWFscyh1c2VyPy5uYW1lID8/ICdDb2xlY2lvbmFkb3InKX08L0F2YXRhckZhbGxiYWNrPlxuICAgICAgICAgICAgICAgIDwvQXZhdGFyPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBtYXgtdy0yOCB0cnVuY2F0ZSBzbTppbmxpbmVcIj5cbiAgICAgICAgICAgICAgICAgIHt1c2VyPy5uYW1lID8/ICdNaW5oYSBDb250YSd9XG4gICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICA8L0Ryb3Bkb3duTWVudVRyaWdnZXI+XG5cbiAgICAgICAgICAgICAgPERyb3Bkb3duTWVudUNvbnRlbnQgYWxpZ249XCJlbmRcIiBjbGFzc05hbWU9XCJ3LTU2XCI+XG4gICAgICAgICAgICAgICAgPERyb3Bkb3duTWVudUdyb3VwPlxuICAgICAgICAgICAgICAgICAgPERyb3Bkb3duTWVudUxhYmVsIGNsYXNzTmFtZT1cInRydW5jYXRlXCI+XG4gICAgICAgICAgICAgICAgICAgIHt1c2VyPy5lbWFpbCA/PyAnQ29sZWNpb25hZG9yIGF1dGVudGljYWRvJ31cbiAgICAgICAgICAgICAgICAgIDwvRHJvcGRvd25NZW51TGFiZWw+XG4gICAgICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVHcm91cD5cbiAgICAgICAgICAgICAgICA8RHJvcGRvd25NZW51U2VwYXJhdG9yIC8+XG4gICAgICAgICAgICAgICAgPERyb3Bkb3duTWVudUl0ZW0gb25DbGljaz17KCkgPT4gdm9pZCByb3V0ZXIubmF2aWdhdGUoeyB0bzogJy9wcm9maWxlJyB9KX0+XG4gICAgICAgICAgICAgICAgICA8VXNlckljb24gY2xhc3NOYW1lPVwic2l6ZS00XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPlBlcmZpbCBkbyBDb2xlY2lvbmFkb3I8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxuICAgICAgICAgICAgICAgIDxEcm9wZG93bk1lbnVJdGVtIG9uQ2xpY2s9eygpID0+IHZvaWQgcm91dGVyLm5hdmlnYXRlKHsgdG86ICcvY2FydCcgfSl9PlxuICAgICAgICAgICAgICAgICAgPFNob3BwaW5nQmFnIGNsYXNzTmFtZT1cInNpemUtNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5NZXUgQ2FycmluaG88L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxuICAgICAgICAgICAgICAgIDxEcm9wZG93bk1lbnVTZXBhcmF0b3IgLz5cbiAgICAgICAgICAgICAgICA8RHJvcGRvd25NZW51SXRlbSB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIiBvbkNsaWNrPXtsb2dvdXR9PlxuICAgICAgICAgICAgICAgICAgPExvZ091dCBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+U2FpciBkYSBjb250YTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L0Ryb3Bkb3duTWVudUl0ZW0+XG4gICAgICAgICAgICAgIDwvRHJvcGRvd25NZW51Q29udGVudD5cbiAgICAgICAgICAgIDwvRHJvcGRvd25NZW51PlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhpZGRlbiBpdGVtcy1jZW50ZXIgZ2FwLTIgc206ZmxleFwiPlxuICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgIHRvPVwiL2xvZ2luXCJcbiAgICAgICAgICAgICAgICBzZWFyY2g9e3t9fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oYnV0dG9uVmFyaWFudHMoeyB2YXJpYW50OiAnZ2hvc3QnLCBzaXplOiAnc20nIH0pKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxMb2dJbiBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkVudHJhcjwvc3Bhbj5cbiAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICAgIHRvPVwiL3JlZ2lzdGVyXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKGJ1dHRvblZhcmlhbnRzKHsgdmFyaWFudDogJ2RlZmF1bHQnLCBzaXplOiAnc20nIH0pKX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxVc2VyUGx1cyBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgIDxzcGFuPkNyaWFyIGNvbnRhPC9zcGFuPlxuICAgICAgICAgICAgICA8L0xpbms+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAgey8qIE1lbnUgR2F2ZXRhIE1vYmlsZSAoPCBtZCkgKi99XG4gICAgICAgICAgPFNoZWV0IG1vZGFsPlxuICAgICAgICAgICAgPFNoZWV0VHJpZ2dlclxuICAgICAgICAgICAgICByZW5kZXI9e1xuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICAgICAgICBzaXplPVwiaWNvblwiXG4gICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtZDpoaWRkZW5cIlxuICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIkFicmlyIG1lbnUgZGUgbmF2ZWdhw6fDo29cIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPE1lbnUgY2xhc3NOYW1lPVwic2l6ZS01XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgIDwvU2hlZXRUcmlnZ2VyPlxuXG4gICAgICAgICAgICA8U2hlZXRDb250ZW50IHNpZGU9XCJyaWdodFwiIGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICAgICAgPFNoZWV0SGVhZGVyPlxuICAgICAgICAgICAgICAgIDxTaGVldFRpdGxlPkp1bmdsZU5GVDwvU2hlZXRUaXRsZT5cbiAgICAgICAgICAgICAgICA8U2hlZXREZXNjcmlwdGlvbj5OYXZlZ3VlIHBlbG8gbWFya2V0cGxhY2UgV2ViMy48L1NoZWV0RGVzY3JpcHRpb24+XG4gICAgICAgICAgICAgIDwvU2hlZXRIZWFkZXI+XG5cbiAgICAgICAgICAgICAgPFNlcGFyYXRvciAvPlxuXG4gICAgICAgICAgICAgIDxuYXYgYXJpYS1sYWJlbD1cIk1lbnUgbW9iaWxlXCIgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtMSBweC00XCI+XG4gICAgICAgICAgICAgICAgPFNoZWV0Q2xvc2VcbiAgICAgICAgICAgICAgICAgIHJlbmRlcj17XG4gICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgdG89XCIvXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKGJ1dHRvblZhcmlhbnRzKHsgdmFyaWFudDogJ2dob3N0Jywgc2l6ZTogJ2RlZmF1bHQnIH0pLCAnanVzdGlmeS1zdGFydCcpfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxDb21wYXNzIGNsYXNzTmFtZT1cInNpemUtNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5FeHBsb3JhciBDYXTDoWxvZ288L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9TaGVldENsb3NlPlxuXG4gICAgICAgICAgICAgICAgPFNoZWV0Q2xvc2VcbiAgICAgICAgICAgICAgICAgIHJlbmRlcj17XG4gICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgdG89XCIvXCJcbiAgICAgICAgICAgICAgICAgICAgICBzZWFyY2g9e3sgb25seUZhdm9yaXRlczogdHJ1ZSB9fVxuICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oYnV0dG9uVmFyaWFudHMoeyB2YXJpYW50OiAnZ2hvc3QnLCBzaXplOiAnZGVmYXVsdCcgfSksICdqdXN0aWZ5LXN0YXJ0Jyl9XG4gICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPEhlYXJ0IGNsYXNzTmFtZT1cInNpemUtNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5NZXVzIEZhdm9yaXRvczwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L1NoZWV0Q2xvc2U+XG5cbiAgICAgICAgICAgICAgICA8U2hlZXRDbG9zZVxuICAgICAgICAgICAgICAgICAgcmVuZGVyPXtcbiAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICB0bz1cIi9jYXJ0XCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKGJ1dHRvblZhcmlhbnRzKHsgdmFyaWFudDogJ2dob3N0Jywgc2l6ZTogJ2RlZmF1bHQnIH0pLCAnanVzdGlmeS1zdGFydCcpfVxuICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxTaG9wcGluZ0JhZyBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+Q2FycmluaG88L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9TaGVldENsb3NlPlxuXG4gICAgICAgICAgICAgICAge2lzQXV0aGVudGljYXRlZCA/IChcbiAgICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICAgIDxTaGVldENsb3NlXG4gICAgICAgICAgICAgICAgICAgICAgcmVuZGVyPXtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL3Byb2ZpbGVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJ1dHRvblZhcmlhbnRzKHsgdmFyaWFudDogJ2dob3N0Jywgc2l6ZTogJ2RlZmF1bHQnIH0pLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICdqdXN0aWZ5LXN0YXJ0JyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPFVzZXJJY29uIGNsYXNzTmFtZT1cInNpemUtNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+UGVyZmlsIGRvIENvbGVjaW9uYWRvcjwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9TaGVldENsb3NlPlxuICAgICAgICAgICAgICAgICAgICA8U2VwYXJhdG9yIGNsYXNzTmFtZT1cIm15LTJcIiAvPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImRlc3RydWN0aXZlXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJqdXN0aWZ5LXN0YXJ0XCJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtsb2dvdXR9XG4gICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICA8TG9nT3V0IGNsYXNzTmFtZT1cInNpemUtNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2FpciBkYSBjb250YTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgPFNlcGFyYXRvciBjbGFzc05hbWU9XCJteS0yXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPFNoZWV0Q2xvc2VcbiAgICAgICAgICAgICAgICAgICAgICByZW5kZXI9e1xuICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdG89XCIvbG9naW5cIlxuICAgICAgICAgICAgICAgICAgICAgICAgICBzZWFyY2g9e3t9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKGJ1dHRvblZhcmlhbnRzKHsgdmFyaWFudDogJ291dGxpbmUnLCBzaXplOiAnZGVmYXVsdCcgfSksICd3LWZ1bGwnKX1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgICAgPExvZ0luIGNsYXNzTmFtZT1cInNpemUtNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+RW50cmFyPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L1NoZWV0Q2xvc2U+XG4gICAgICAgICAgICAgICAgICAgIDxTaGVldENsb3NlXG4gICAgICAgICAgICAgICAgICAgICAgcmVuZGVyPXtcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHRvPVwiL3JlZ2lzdGVyXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihidXR0b25WYXJpYW50cyh7IHZhcmlhbnQ6ICdkZWZhdWx0Jywgc2l6ZTogJ2RlZmF1bHQnIH0pLCAndy1mdWxsJyl9XG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxVc2VyUGx1cyBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuPkNyaWFyIGNvbnRhPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICA8L1NoZWV0Q2xvc2U+XG4gICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L25hdj5cbiAgICAgICAgICAgIDwvU2hlZXRDb250ZW50PlxuICAgICAgICAgIDwvU2hlZXQ+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9oZWFkZXI+XG4gIClcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL2NvbXBvbmVudHMvbGF5b3V0L25hdmJhci50c3gifQ==