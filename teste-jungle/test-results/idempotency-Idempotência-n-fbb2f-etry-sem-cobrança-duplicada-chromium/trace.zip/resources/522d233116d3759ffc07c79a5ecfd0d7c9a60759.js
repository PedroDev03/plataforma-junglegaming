import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/form/text-field.tsx");const useId = __vite__cjsImport0_react["useId"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=e9f94b2e";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/form/text-field.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
/** Campo acessível: `<Label htmlFor>`, `aria-invalid` explícito e erro/dica ligados via `aria-describedby`. */
export function TextField({ label, error, hint, id, ...props }) {
	_s();
	const generatedId = useId();
	const inputId = id ?? generatedId;
	const errorId = `${inputId}-error`;
	const hintId = `${inputId}-hint`;
	const isInvalid = Boolean(error);
	const describedBy = [isInvalid ? errorId : null, hint ? hintId : null].filter(Boolean).join(" ") || undefined;
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "grid gap-2",
		children: [
			/* @__PURE__ */ _jsxDEV(Label, {
				htmlFor: inputId,
				children: label
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(Input, {
				id: inputId,
				"aria-invalid": isInvalid,
				"aria-describedby": describedBy,
				...props
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 26,
				columnNumber: 7
			}, this),
			hint && !isInvalid && /* @__PURE__ */ _jsxDEV("p", {
				id: hintId,
				className: "text-xs text-muted-foreground",
				children: hint
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 27,
				columnNumber: 30
			}, this),
			isInvalid && /* @__PURE__ */ _jsxDEV("p", {
				id: errorId,
				role: "alert",
				className: "text-xs font-medium text-destructive",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 30,
				columnNumber: 21
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 24,
		columnNumber: 10
	}, this);
}
_s(TextField, "P3bvVUypbBAHy0F8g4TFKgtieUM=");
_c = TextField;
var _c;
$RefreshReg$(_c, "TextField");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/form/text-field.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/form/text-field.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/form/text-field.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/form/text-field.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsU0FBU0EsYUFBa0M7QUFDM0MsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxhQUFhOzs7OztBQVN0QixPQUFPLFNBQVNDLFVBQVUsRUFBRUMsT0FBT0MsT0FBT0MsTUFBTUMsSUFBSSxHQUFHQyxTQUF5Qjs7Q0FDOUUsTUFBTUMsY0FBY1QsTUFBTTtDQUMxQixNQUFNVSxVQUFVSCxNQUFNRTtDQUN0QixNQUFNRSxVQUFVLEdBQUdELFFBQU87Q0FDMUIsTUFBTUUsU0FBUyxHQUFHRixRQUFPO0NBQ3pCLE1BQU1HLFlBQVlDLFFBQVFULEtBQUs7Q0FDL0IsTUFBTVUsY0FDSixDQUFDRixZQUFZRixVQUFVLE1BQU1MLE9BQU9NLFNBQVMsSUFBSSxDQUFDLENBQUNJLE9BQU9GLE9BQU8sQ0FBQyxDQUFDRyxLQUFLLEdBQUcsS0FBS0M7Q0FFbEYsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsT0FBRDtJQUFPLFNBQVNSO2NBQVVOO0dBQWE7Ozs7O0dBQ3ZDLHdCQUFDLE9BQUQ7SUFDRSxJQUFJTTtJQUNKLGdCQUFjRztJQUNkLG9CQUFrQkU7SUFDbEIsR0FBSVA7R0FBTTs7Ozs7R0FFWEYsUUFBUSxDQUFDTyxhQUNSLHdCQUFDLEtBQUQ7SUFBRyxJQUFJRDtJQUFRLFdBQVU7Y0FDdEJOO0dBQ0E7Ozs7O0dBRUpPLGFBQ0Msd0JBQUMsS0FBRDtJQUFHLElBQUlGO0lBQVMsTUFBSztJQUFRLFdBQVU7Y0FDcENOO0dBQ0E7Ozs7O0VBRUY7Ozs7OztBQUVUIiwibmFtZXMiOlsidXNlSWQiLCJJbnB1dCIsIkxhYmVsIiwiVGV4dEZpZWxkIiwibGFiZWwiLCJlcnJvciIsImhpbnQiLCJpZCIsInByb3BzIiwiZ2VuZXJhdGVkSWQiLCJpbnB1dElkIiwiZXJyb3JJZCIsImhpbnRJZCIsImlzSW52YWxpZCIsIkJvb2xlYW4iLCJkZXNjcmliZWRCeSIsImZpbHRlciIsImpvaW4iLCJ1bmRlZmluZWQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsidGV4dC1maWVsZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlSWQsIHR5cGUgQ29tcG9uZW50UHJvcHMgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IElucHV0IH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2lucHV0J1xuaW1wb3J0IHsgTGFiZWwgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvbGFiZWwnXG5cbmludGVyZmFjZSBUZXh0RmllbGRQcm9wcyBleHRlbmRzIENvbXBvbmVudFByb3BzPCdpbnB1dCc+IHtcbiAgbGFiZWw6IHN0cmluZ1xuICBlcnJvcj86IHN0cmluZ1xuICBoaW50Pzogc3RyaW5nXG59XG5cbi8qKiBDYW1wbyBhY2Vzc8OtdmVsOiBgPExhYmVsIGh0bWxGb3I+YCwgYGFyaWEtaW52YWxpZGAgZXhwbMOtY2l0byBlIGVycm8vZGljYSBsaWdhZG9zIHZpYSBgYXJpYS1kZXNjcmliZWRieWAuICovXG5leHBvcnQgZnVuY3Rpb24gVGV4dEZpZWxkKHsgbGFiZWwsIGVycm9yLCBoaW50LCBpZCwgLi4ucHJvcHMgfTogVGV4dEZpZWxkUHJvcHMpIHtcbiAgY29uc3QgZ2VuZXJhdGVkSWQgPSB1c2VJZCgpXG4gIGNvbnN0IGlucHV0SWQgPSBpZCA/PyBnZW5lcmF0ZWRJZFxuICBjb25zdCBlcnJvcklkID0gYCR7aW5wdXRJZH0tZXJyb3JgXG4gIGNvbnN0IGhpbnRJZCA9IGAke2lucHV0SWR9LWhpbnRgXG4gIGNvbnN0IGlzSW52YWxpZCA9IEJvb2xlYW4oZXJyb3IpXG4gIGNvbnN0IGRlc2NyaWJlZEJ5ID1cbiAgICBbaXNJbnZhbGlkID8gZXJyb3JJZCA6IG51bGwsIGhpbnQgPyBoaW50SWQgOiBudWxsXS5maWx0ZXIoQm9vbGVhbikuam9pbignICcpIHx8IHVuZGVmaW5lZFxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0yXCI+XG4gICAgICA8TGFiZWwgaHRtbEZvcj17aW5wdXRJZH0+e2xhYmVsfTwvTGFiZWw+XG4gICAgICA8SW5wdXRcbiAgICAgICAgaWQ9e2lucHV0SWR9XG4gICAgICAgIGFyaWEtaW52YWxpZD17aXNJbnZhbGlkfVxuICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PXtkZXNjcmliZWRCeX1cbiAgICAgICAgey4uLnByb3BzfVxuICAgICAgLz5cbiAgICAgIHtoaW50ICYmICFpc0ludmFsaWQgJiYgKFxuICAgICAgICA8cCBpZD17aGludElkfSBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgIHtoaW50fVxuICAgICAgICA8L3A+XG4gICAgICApfVxuICAgICAge2lzSW52YWxpZCAmJiAoXG4gICAgICAgIDxwIGlkPXtlcnJvcklkfSByb2xlPVwiYWxlcnRcIiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZGVzdHJ1Y3RpdmVcIj5cbiAgICAgICAgICB7ZXJyb3J9XG4gICAgICAgIDwvcD5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL2NvbXBvbmVudHMvZm9ybS90ZXh0LWZpZWxkLnRzeCJ9