import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/sheet.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport1_react, 1);const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=e9f94b2e";
import { Dialog as SheetPrimitive } from "/node_modules/.vite/deps/@base-ui_react_dialog.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
import { Button } from "/src/components/ui/button.tsx";
import { XIcon } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/sheet.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
function Sheet(t0) {
	const $ = _c(5);
	if ($[0] !== "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(SheetPrimitive.Root, {
			"data-slot": "sheet",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c2 = Sheet;
function SheetTrigger(t0) {
	const $ = _c(5);
	if ($[0] !== "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(SheetPrimitive.Trigger, {
			"data-slot": "sheet-trigger",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c3 = SheetTrigger;
function SheetClose(t0) {
	const $ = _c(5);
	if ($[0] !== "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(SheetPrimitive.Close, {
			"data-slot": "sheet-close",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 83,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c4 = SheetClose;
function SheetPortal(t0) {
	const $ = _c(5);
	if ($[0] !== "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(SheetPrimitive.Portal, {
			"data-slot": "sheet-portal",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 111,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c5 = SheetPortal;
function SheetOverlay(t0) {
	const $ = _c(9);
	if ($[0] !== "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("fixed inset-0 z-50 bg-black/10 transition-opacity duration-150 data-ending-style:opacity-0 data-starting-style:opacity-0 supports-backdrop-filter:backdrop-blur-xs", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(SheetPrimitive.Backdrop, {
			"data-slot": "sheet-overlay",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 151,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c6 = SheetOverlay;
function SheetContent(t0) {
	const $ = _c(18);
	if ($[0] !== "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3") {
		for (let $i = 0; $i < 18; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3";
	}
	let children;
	let className;
	let props;
	let t1;
	let t2;
	if ($[1] !== t0) {
		({className, children, side: t1, showCloseButton: t2, ...props} = t0);
		$[1] = t0;
		$[2] = children;
		$[3] = className;
		$[4] = props;
		$[5] = t1;
		$[6] = t2;
	} else {
		children = $[2];
		className = $[3];
		props = $[4];
		t1 = $[5];
		t2 = $[6];
	}
	const side = t1 === undefined ? "right" : t1;
	const showCloseButton = t2 === undefined ? true : t2;
	let t3;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = /* @__PURE__ */ _jsxDEV(SheetOverlay, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 198,
			columnNumber: 10
		}, this);
		$[7] = t3;
	} else {
		t3 = $[7];
	}
	let t4;
	if ($[8] !== className) {
		t4 = cn("fixed z-50 flex flex-col gap-4 bg-popover bg-clip-padding text-sm text-popover-foreground shadow-lg transition duration-200 ease-in-out data-ending-style:opacity-0 data-starting-style:opacity-0 data-[side=bottom]:inset-x-0 data-[side=bottom]:bottom-0 data-[side=bottom]:h-auto data-[side=bottom]:border-t data-[side=bottom]:data-ending-style:translate-y-[2.5rem] data-[side=bottom]:data-starting-style:translate-y-[2.5rem] data-[side=left]:inset-y-0 data-[side=left]:left-0 data-[side=left]:h-full data-[side=left]:w-3/4 data-[side=left]:border-r data-[side=left]:data-ending-style:translate-x-[-2.5rem] data-[side=left]:data-starting-style:translate-x-[-2.5rem] data-[side=right]:inset-y-0 data-[side=right]:right-0 data-[side=right]:h-full data-[side=right]:w-3/4 data-[side=right]:border-l data-[side=right]:data-ending-style:translate-x-[2.5rem] data-[side=right]:data-starting-style:translate-x-[2.5rem] data-[side=top]:inset-x-0 data-[side=top]:top-0 data-[side=top]:h-auto data-[side=top]:border-b data-[side=top]:data-ending-style:translate-y-[-2.5rem] data-[side=top]:data-starting-style:translate-y-[-2.5rem] data-[side=left]:sm:max-w-sm data-[side=right]:sm:max-w-sm", className);
		$[8] = className;
		$[9] = t4;
	} else {
		t4 = $[9];
	}
	let t5;
	if ($[10] !== showCloseButton) {
		t5 = showCloseButton && /* @__PURE__ */ _jsxDEV(SheetPrimitive.Close, {
			"data-slot": "sheet-close",
			render: /* @__PURE__ */ _jsxDEV(Button, {
				variant: "ghost",
				className: "absolute top-3 right-3",
				size: "icon-sm"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 213,
				columnNumber: 83
			}, this),
			children: [/* @__PURE__ */ _jsxDEV(XIcon, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 213,
				columnNumber: 161
			}, this), /* @__PURE__ */ _jsxDEV("span", {
				className: "sr-only",
				children: "Close"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 213,
				columnNumber: 170
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 213,
			columnNumber: 29
		}, this);
		$[10] = showCloseButton;
		$[11] = t5;
	} else {
		t5 = $[11];
	}
	let t6;
	if ($[12] !== children || $[13] !== props || $[14] !== side || $[15] !== t4 || $[16] !== t5) {
		t6 = /* @__PURE__ */ _jsxDEV(SheetPortal, { children: [t3, /* @__PURE__ */ _jsxDEV(SheetPrimitive.Popup, {
			"data-slot": "sheet-content",
			"data-side": side,
			className: t4,
			...props,
			children: [children, t5]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 221,
			columnNumber: 27
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 221,
			columnNumber: 10
		}, this);
		$[12] = children;
		$[13] = props;
		$[14] = side;
		$[15] = t4;
		$[16] = t5;
		$[17] = t6;
	} else {
		t6 = $[17];
	}
	return t6;
}
_c7 = SheetContent;
function SheetHeader(t0) {
	const $ = _c(9);
	if ($[0] !== "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("flex flex-col gap-0.5 p-4", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "sheet-header",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 265,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c8 = SheetHeader;
function SheetFooter(t0) {
	const $ = _c(9);
	if ($[0] !== "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("mt-auto flex flex-col gap-2 p-4", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "sheet-footer",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 306,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c9 = SheetFooter;
function SheetTitle(t0) {
	const $ = _c(9);
	if ($[0] !== "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("font-heading text-base font-medium text-foreground", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(SheetPrimitive.Title, {
			"data-slot": "sheet-title",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 347,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c10 = SheetTitle;
function SheetDescription(t0) {
	const $ = _c(9);
	if ($[0] !== "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3d2fd9dd65a60cf13865b6b8b52fec865cf14ab853dd09296471d8999c060ac3";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("text-sm text-muted-foreground", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(SheetPrimitive.Description, {
			"data-slot": "sheet-description",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 388,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c11 = SheetDescription;
export { Sheet, SheetTrigger, SheetClose, SheetContent, SheetHeader, SheetFooter, SheetTitle, SheetDescription };
var _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11;
$RefreshReg$(_c2, "Sheet");
$RefreshReg$(_c3, "SheetTrigger");
$RefreshReg$(_c4, "SheetClose");
$RefreshReg$(_c5, "SheetPortal");
$RefreshReg$(_c6, "SheetOverlay");
$RefreshReg$(_c7, "SheetContent");
$RefreshReg$(_c8, "SheetHeader");
$RefreshReg$(_c9, "SheetFooter");
$RefreshReg$(_c10, "SheetTitle");
$RefreshReg$(_c11, "SheetDescription");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/sheet.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/sheet.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/sheet.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/sheet.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFlBQVlBLFdBQVc7QUFDdkIsU0FBU0MsVUFBVUMsc0JBQXNCO0FBQ3pDLFNBQVNDLFVBQVU7QUFFbkIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxhQUFhOzs7QUFFdEIsU0FBQUMsTUFBQUMsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUwsRUFBQSxPQUFBRCxJQUFBO0VBQWUsS0FBQU0sU0FBQU47RUFBdUNDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztDQUFBO0VBQUFBLFFBQUFMLEVBQUE7Q0FBQTtDQUFBLElBQUFNO0NBQUEsSUFBQU4sRUFBQSxPQUFBSyxPQUFBO0VBQzdDQyxLQUFBO0dBQStCO0dBQU8sR0FBS0Q7RUFBSzs7Ozs7RUFBSUwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0NBQUE7RUFBQUEsS0FBQU4sRUFBQTtDQUFBO0NBQUEsT0FBcERNO0FBQW9EOztBQUc3RCxTQUFBQyxhQUFBUixJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFELElBQUE7RUFBc0IsS0FBQU0sU0FBQU47RUFBMENDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztDQUFBO0VBQUFBLFFBQUFMLEVBQUE7Q0FBQTtDQUFBLElBQUFNO0NBQUEsSUFBQU4sRUFBQSxPQUFBSyxPQUFBO0VBQ3ZEQyxLQUFBO0dBQWtDO0dBQWUsR0FBS0Q7RUFBSzs7Ozs7RUFBSUwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0NBQUE7RUFBQUEsS0FBQU4sRUFBQTtDQUFBO0NBQUEsT0FBL0RNO0FBQStEOztBQUd4RSxTQUFBRSxXQUFBVCxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFELElBQUE7RUFBb0IsS0FBQU0sU0FBQU47RUFBd0NDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztDQUFBO0VBQUFBLFFBQUFMLEVBQUE7Q0FBQTtDQUFBLElBQUFNO0NBQUEsSUFBQU4sRUFBQSxPQUFBSyxPQUFBO0VBQ25EQyxLQUFBO0dBQWdDO0dBQWEsR0FBS0Q7RUFBSzs7Ozs7RUFBSUwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0NBQUE7RUFBQUEsS0FBQU4sRUFBQTtDQUFBO0NBQUEsT0FBM0RNO0FBQTJEOztBQUdwRSxTQUFBRyxZQUFBVixJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFELElBQUE7RUFBcUIsS0FBQU0sU0FBQU47RUFBeUNDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztDQUFBO0VBQUFBLFFBQUFMLEVBQUE7Q0FBQTtDQUFBLElBQUFNO0NBQUEsSUFBQU4sRUFBQSxPQUFBSyxPQUFBO0VBQ3JEQyxLQUFBO0dBQWlDO0dBQWMsR0FBS0Q7RUFBSzs7Ozs7RUFBSUwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0NBQUE7RUFBQUEsS0FBQU4sRUFBQTtDQUFBO0NBQUEsT0FBN0RNO0FBQTZEOztBQUd0RSxTQUFBSSxhQUFBWCxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQVc7Q0FBQSxJQUFBTjtDQUFBLElBQUFMLEVBQUEsT0FBQUQsSUFBQTtFQUFzQixFQUFBWSxXQUFBLEdBQUFOLFNBQUFOO0VBQXNEQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQVc7RUFBQVgsRUFBQSxLQUFBSztDQUFBO0VBQUFNLFlBQUFYLEVBQUE7RUFBQUssUUFBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFXLFdBQUE7RUFJM0RMLEtBQUFYLEdBQ1Qsc0tBQ0FnQixTQUNGO0VBQUNYLEVBQUEsS0FBQVc7RUFBQVgsRUFBQSxLQUFBTTtDQUFBO0VBQUFBLEtBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFZO0NBQUEsSUFBQVosRUFBQSxPQUFBSyxTQUFBTCxFQUFBLE9BQUFNLElBQUE7RUFMSE0sS0FBQTtHQUNZO0dBQ0MsV0FBQU47R0FHVixHQUNHRDtFQUFLOzs7OztFQUNUTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBWTtDQUFBO0VBQUFBLEtBQUFaLEVBQUE7Q0FBQTtDQUFBLE9BUEZZO0FBT0U7O0FBSU4sU0FBQUMsYUFBQWQsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLElBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFjO0NBQUEsSUFBQUg7Q0FBQSxJQUFBTjtDQUFBLElBQUFDO0NBQUEsSUFBQU07Q0FBQSxJQUFBWixFQUFBLE9BQUFELElBQUE7RUFBc0IsRUFBQVksV0FBQUcsVUFBQUMsTUFBQVQsSUFBQVUsaUJBQUFKLElBQUEsR0FBQVAsU0FBQU47RUFTckJDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBYztFQUFBZCxFQUFBLEtBQUFXO0VBQUFYLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFZO0NBQUE7RUFBQUUsV0FBQWQsRUFBQTtFQUFBVyxZQUFBWCxFQUFBO0VBQUFLLFFBQUFMLEVBQUE7RUFBQU0sS0FBQU4sRUFBQTtFQUFBWSxLQUFBWixFQUFBO0NBQUE7Q0FOQyxNQUFBZSxPQUFBVCxPQUFBVyxZQUFBLFVBQUFYO0NBQ0EsTUFBQVUsa0JBQUFKLE9BQUFLLFlBQUEsT0FBQUw7Q0FBc0IsSUFBQU07Q0FBQSxJQUFBbEIsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBUWxCYyxLQUFBLHdCQUFDLGNBQUQsQ0FBYTs7Ozs7RUFBR2xCLEVBQUEsS0FBQWtCO0NBQUE7RUFBQUEsS0FBQWxCLEVBQUE7Q0FBQTtDQUFBLElBQUFtQjtDQUFBLElBQUFuQixFQUFBLE9BQUFXLFdBQUE7RUFJSFEsS0FBQXhCLEdBQ1QsNnBDQUNBZ0IsU0FDRjtFQUFDWCxFQUFBLEtBQUFXO0VBQUFYLEVBQUEsS0FBQW1CO0NBQUE7RUFBQUEsS0FBQW5CLEVBQUE7Q0FBQTtDQUFBLElBQUFvQjtDQUFBLElBQUFwQixFQUFBLFFBQUFnQixpQkFBQTtFQUlBSSxLQUFBSixtQkFDQztHQUNZO0dBRVIsZ0NBQUMsUUFBRDtJQUNVO0lBQ0U7SUFDTDtHQUFTOzs7OzthQU5wQixDQVVFLHdCQUFDLE9BQUQsQ0FBTTs7OzthQUVOO0lBQWdCO2NBQVU7R0FBWTs7OztXQUN4Qzs7Ozs7O0VBQ0RoQixFQUFBLE1BQUFnQjtFQUFBaEIsRUFBQSxNQUFBb0I7Q0FBQTtFQUFBQSxLQUFBcEIsRUFBQTtDQUFBO0NBQUEsSUFBQXFCO0NBQUEsSUFBQXJCLEVBQUEsUUFBQWMsWUFBQWQsRUFBQSxRQUFBSyxTQUFBTCxFQUFBLFFBQUFlLFFBQUFmLEVBQUEsUUFBQW1CLE1BQUFuQixFQUFBLFFBQUFvQixJQUFBO0VBM0JMQyxLQUFBLHdCQUFDLGFBQUQsYUFDRUgsSUFDQTtHQUNZO0dBQ0NIO0dBQ0EsV0FBQUk7R0FHVixHQUNHZDthQVBOLENBU0dTLFVBQ0FNLEVBZ0JIOzs7OztVQTVCVTs7Ozs7RUE2QkVwQixFQUFBLE1BQUFjO0VBQUFkLEVBQUEsTUFBQUs7RUFBQUwsRUFBQSxNQUFBZTtFQUFBZixFQUFBLE1BQUFtQjtFQUFBbkIsRUFBQSxNQUFBb0I7RUFBQXBCLEVBQUEsTUFBQXFCO0NBQUE7RUFBQUEsS0FBQXJCLEVBQUE7Q0FBQTtDQUFBLE9BN0JkcUI7QUE2QmM7O0FBSWxCLFNBQUFDLFlBQUF2QixJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQVc7Q0FBQSxJQUFBTjtDQUFBLElBQUFMLEVBQUEsT0FBQUQsSUFBQTtFQUFxQixFQUFBWSxXQUFBLEdBQUFOLFNBQUFOO0VBQW9EQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQVc7RUFBQVgsRUFBQSxLQUFBSztDQUFBO0VBQUFNLFlBQUFYLEVBQUE7RUFBQUssUUFBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFXLFdBQUE7RUFJeERMLEtBQUFYLEdBQUcsNkJBQTZCZ0IsU0FBUztFQUFDWCxFQUFBLEtBQUFXO0VBQUFYLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxJQUFBWTtDQUFBLElBQUFaLEVBQUEsT0FBQUssU0FBQUwsRUFBQSxPQUFBTSxJQUFBO0VBRnZETSxLQUFBO0dBQ1k7R0FDQyxXQUFBTjtHQUEwQyxHQUNqREQ7RUFBSzs7Ozs7RUFDVEwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQVk7Q0FBQTtFQUFBQSxLQUFBWixFQUFBO0NBQUE7Q0FBQSxPQUpGWTtBQUlFOztBQUlOLFNBQUFXLFlBQUF4QixJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQVc7Q0FBQSxJQUFBTjtDQUFBLElBQUFMLEVBQUEsT0FBQUQsSUFBQTtFQUFxQixFQUFBWSxXQUFBLEdBQUFOLFNBQUFOO0VBQW9EQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQVc7RUFBQVgsRUFBQSxLQUFBSztDQUFBO0VBQUFNLFlBQUFYLEVBQUE7RUFBQUssUUFBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFXLFdBQUE7RUFJeERMLEtBQUFYLEdBQUcsbUNBQW1DZ0IsU0FBUztFQUFDWCxFQUFBLEtBQUFXO0VBQUFYLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxJQUFBWTtDQUFBLElBQUFaLEVBQUEsT0FBQUssU0FBQUwsRUFBQSxPQUFBTSxJQUFBO0VBRjdETSxLQUFBO0dBQ1k7R0FDQyxXQUFBTjtHQUFnRCxHQUN2REQ7RUFBSzs7Ozs7RUFDVEwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQVk7Q0FBQTtFQUFBQSxLQUFBWixFQUFBO0NBQUE7Q0FBQSxPQUpGWTtBQUlFOztBQUlOLFNBQUFZLFdBQUF6QixJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQVc7Q0FBQSxJQUFBTjtDQUFBLElBQUFMLEVBQUEsT0FBQUQsSUFBQTtFQUFvQixFQUFBWSxXQUFBLEdBQUFOLFNBQUFOO0VBQW1EQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQVc7RUFBQVgsRUFBQSxLQUFBSztDQUFBO0VBQUFNLFlBQUFYLEVBQUE7RUFBQUssUUFBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFXLFdBQUE7RUFJdERMLEtBQUFYLEdBQ1Qsc0RBQ0FnQixTQUNGO0VBQUNYLEVBQUEsS0FBQVc7RUFBQVgsRUFBQSxLQUFBTTtDQUFBO0VBQUFBLEtBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFZO0NBQUEsSUFBQVosRUFBQSxPQUFBSyxTQUFBTCxFQUFBLE9BQUFNLElBQUE7RUFMSE0sS0FBQTtHQUNZO0dBQ0MsV0FBQU47R0FHVixHQUNHRDtFQUFLOzs7OztFQUNUTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBWTtDQUFBO0VBQUFBLEtBQUFaLEVBQUE7Q0FBQTtDQUFBLE9BUEZZO0FBT0U7O0FBSU4sU0FBQWEsaUJBQUExQixJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQVc7Q0FBQSxJQUFBTjtDQUFBLElBQUFMLEVBQUEsT0FBQUQsSUFBQTtFQUEwQixFQUFBWSxXQUFBLEdBQUFOLFNBQUFOO0VBR1NDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBVztFQUFBWCxFQUFBLEtBQUFLO0NBQUE7RUFBQU0sWUFBQVgsRUFBQTtFQUFBSyxRQUFBTCxFQUFBO0NBQUE7Q0FBQSxJQUFBTTtDQUFBLElBQUFOLEVBQUEsT0FBQVcsV0FBQTtFQUlsQkwsS0FBQVgsR0FBRyxpQ0FBaUNnQixTQUFTO0VBQUNYLEVBQUEsS0FBQVc7RUFBQVgsRUFBQSxLQUFBTTtDQUFBO0VBQUFBLEtBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFZO0NBQUEsSUFBQVosRUFBQSxPQUFBSyxTQUFBTCxFQUFBLE9BQUFNLElBQUE7RUFGM0RNLEtBQUE7R0FDWTtHQUNDLFdBQUFOO0dBQThDLEdBQ3JERDtFQUFLOzs7OztFQUNUTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBWTtDQUFBO0VBQUFBLEtBQUFaLEVBQUE7Q0FBQTtDQUFBLE9BSkZZO0FBSUU7O0FBSU4sU0FDRWQsT0FDQVMsY0FDQUMsWUFDQUssY0FDQVMsYUFDQUMsYUFDQUMsWUFDQUMiLCJuYW1lcyI6WyJSZWFjdCIsIkRpYWxvZyIsIlNoZWV0UHJpbWl0aXZlIiwiY24iLCJCdXR0b24iLCJYSWNvbiIsIlNoZWV0IiwidDAiLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsInByb3BzIiwidDEiLCJTaGVldFRyaWdnZXIiLCJTaGVldENsb3NlIiwiU2hlZXRQb3J0YWwiLCJTaGVldE92ZXJsYXkiLCJjbGFzc05hbWUiLCJ0MiIsIlNoZWV0Q29udGVudCIsImNoaWxkcmVuIiwic2lkZSIsInNob3dDbG9zZUJ1dHRvbiIsInVuZGVmaW5lZCIsInQzIiwidDQiLCJ0NSIsInQ2IiwiU2hlZXRIZWFkZXIiLCJTaGVldEZvb3RlciIsIlNoZWV0VGl0bGUiLCJTaGVldERlc2NyaXB0aW9uIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInNoZWV0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIlxuaW1wb3J0IHsgRGlhbG9nIGFzIFNoZWV0UHJpbWl0aXZlIH0gZnJvbSBcIkBiYXNlLXVpL3JlYWN0L2RpYWxvZ1wiXG5pbXBvcnQgeyBjbiB9IGZyb20gXCJjblwiXG5cbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gXCJAL2NvbXBvbmVudHMvdWkvYnV0dG9uXCJcbmltcG9ydCB7IFhJY29uIH0gZnJvbSBcImx1Y2lkZS1yZWFjdFwiXG5cbmZ1bmN0aW9uIFNoZWV0KHsgLi4ucHJvcHMgfTogU2hlZXRQcmltaXRpdmUuUm9vdC5Qcm9wcykge1xuICByZXR1cm4gPFNoZWV0UHJpbWl0aXZlLlJvb3QgZGF0YS1zbG90PVwic2hlZXRcIiB7Li4ucHJvcHN9IC8+XG59XG5cbmZ1bmN0aW9uIFNoZWV0VHJpZ2dlcih7IC4uLnByb3BzIH06IFNoZWV0UHJpbWl0aXZlLlRyaWdnZXIuUHJvcHMpIHtcbiAgcmV0dXJuIDxTaGVldFByaW1pdGl2ZS5UcmlnZ2VyIGRhdGEtc2xvdD1cInNoZWV0LXRyaWdnZXJcIiB7Li4ucHJvcHN9IC8+XG59XG5cbmZ1bmN0aW9uIFNoZWV0Q2xvc2UoeyAuLi5wcm9wcyB9OiBTaGVldFByaW1pdGl2ZS5DbG9zZS5Qcm9wcykge1xuICByZXR1cm4gPFNoZWV0UHJpbWl0aXZlLkNsb3NlIGRhdGEtc2xvdD1cInNoZWV0LWNsb3NlXCIgey4uLnByb3BzfSAvPlxufVxuXG5mdW5jdGlvbiBTaGVldFBvcnRhbCh7IC4uLnByb3BzIH06IFNoZWV0UHJpbWl0aXZlLlBvcnRhbC5Qcm9wcykge1xuICByZXR1cm4gPFNoZWV0UHJpbWl0aXZlLlBvcnRhbCBkYXRhLXNsb3Q9XCJzaGVldC1wb3J0YWxcIiB7Li4ucHJvcHN9IC8+XG59XG5cbmZ1bmN0aW9uIFNoZWV0T3ZlcmxheSh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfTogU2hlZXRQcmltaXRpdmUuQmFja2Ryb3AuUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8U2hlZXRQcmltaXRpdmUuQmFja2Ryb3BcbiAgICAgIGRhdGEtc2xvdD1cInNoZWV0LW92ZXJsYXlcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJmaXhlZCBpbnNldC0wIHotNTAgYmctYmxhY2svMTAgdHJhbnNpdGlvbi1vcGFjaXR5IGR1cmF0aW9uLTE1MCBkYXRhLWVuZGluZy1zdHlsZTpvcGFjaXR5LTAgZGF0YS1zdGFydGluZy1zdHlsZTpvcGFjaXR5LTAgc3VwcG9ydHMtYmFja2Ryb3AtZmlsdGVyOmJhY2tkcm9wLWJsdXIteHNcIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZnVuY3Rpb24gU2hlZXRDb250ZW50KHtcbiAgY2xhc3NOYW1lLFxuICBjaGlsZHJlbixcbiAgc2lkZSA9IFwicmlnaHRcIixcbiAgc2hvd0Nsb3NlQnV0dG9uID0gdHJ1ZSxcbiAgLi4ucHJvcHNcbn06IFNoZWV0UHJpbWl0aXZlLlBvcHVwLlByb3BzICYge1xuICBzaWRlPzogXCJ0b3BcIiB8IFwicmlnaHRcIiB8IFwiYm90dG9tXCIgfCBcImxlZnRcIlxuICBzaG93Q2xvc2VCdXR0b24/OiBib29sZWFuXG59KSB7XG4gIHJldHVybiAoXG4gICAgPFNoZWV0UG9ydGFsPlxuICAgICAgPFNoZWV0T3ZlcmxheSAvPlxuICAgICAgPFNoZWV0UHJpbWl0aXZlLlBvcHVwXG4gICAgICAgIGRhdGEtc2xvdD1cInNoZWV0LWNvbnRlbnRcIlxuICAgICAgICBkYXRhLXNpZGU9e3NpZGV9XG4gICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgXCJmaXhlZCB6LTUwIGZsZXggZmxleC1jb2wgZ2FwLTQgYmctcG9wb3ZlciBiZy1jbGlwLXBhZGRpbmcgdGV4dC1zbSB0ZXh0LXBvcG92ZXItZm9yZWdyb3VuZCBzaGFkb3ctbGcgdHJhbnNpdGlvbiBkdXJhdGlvbi0yMDAgZWFzZS1pbi1vdXQgZGF0YS1lbmRpbmctc3R5bGU6b3BhY2l0eS0wIGRhdGEtc3RhcnRpbmctc3R5bGU6b3BhY2l0eS0wIGRhdGEtW3NpZGU9Ym90dG9tXTppbnNldC14LTAgZGF0YS1bc2lkZT1ib3R0b21dOmJvdHRvbS0wIGRhdGEtW3NpZGU9Ym90dG9tXTpoLWF1dG8gZGF0YS1bc2lkZT1ib3R0b21dOmJvcmRlci10IGRhdGEtW3NpZGU9Ym90dG9tXTpkYXRhLWVuZGluZy1zdHlsZTp0cmFuc2xhdGUteS1bMi41cmVtXSBkYXRhLVtzaWRlPWJvdHRvbV06ZGF0YS1zdGFydGluZy1zdHlsZTp0cmFuc2xhdGUteS1bMi41cmVtXSBkYXRhLVtzaWRlPWxlZnRdOmluc2V0LXktMCBkYXRhLVtzaWRlPWxlZnRdOmxlZnQtMCBkYXRhLVtzaWRlPWxlZnRdOmgtZnVsbCBkYXRhLVtzaWRlPWxlZnRdOnctMy80IGRhdGEtW3NpZGU9bGVmdF06Ym9yZGVyLXIgZGF0YS1bc2lkZT1sZWZ0XTpkYXRhLWVuZGluZy1zdHlsZTp0cmFuc2xhdGUteC1bLTIuNXJlbV0gZGF0YS1bc2lkZT1sZWZ0XTpkYXRhLXN0YXJ0aW5nLXN0eWxlOnRyYW5zbGF0ZS14LVstMi41cmVtXSBkYXRhLVtzaWRlPXJpZ2h0XTppbnNldC15LTAgZGF0YS1bc2lkZT1yaWdodF06cmlnaHQtMCBkYXRhLVtzaWRlPXJpZ2h0XTpoLWZ1bGwgZGF0YS1bc2lkZT1yaWdodF06dy0zLzQgZGF0YS1bc2lkZT1yaWdodF06Ym9yZGVyLWwgZGF0YS1bc2lkZT1yaWdodF06ZGF0YS1lbmRpbmctc3R5bGU6dHJhbnNsYXRlLXgtWzIuNXJlbV0gZGF0YS1bc2lkZT1yaWdodF06ZGF0YS1zdGFydGluZy1zdHlsZTp0cmFuc2xhdGUteC1bMi41cmVtXSBkYXRhLVtzaWRlPXRvcF06aW5zZXQteC0wIGRhdGEtW3NpZGU9dG9wXTp0b3AtMCBkYXRhLVtzaWRlPXRvcF06aC1hdXRvIGRhdGEtW3NpZGU9dG9wXTpib3JkZXItYiBkYXRhLVtzaWRlPXRvcF06ZGF0YS1lbmRpbmctc3R5bGU6dHJhbnNsYXRlLXktWy0yLjVyZW1dIGRhdGEtW3NpZGU9dG9wXTpkYXRhLXN0YXJ0aW5nLXN0eWxlOnRyYW5zbGF0ZS15LVstMi41cmVtXSBkYXRhLVtzaWRlPWxlZnRdOnNtOm1heC13LXNtIGRhdGEtW3NpZGU9cmlnaHRdOnNtOm1heC13LXNtXCIsXG4gICAgICAgICAgY2xhc3NOYW1lXG4gICAgICAgICl9XG4gICAgICAgIHsuLi5wcm9wc31cbiAgICAgID5cbiAgICAgICAge2NoaWxkcmVufVxuICAgICAgICB7c2hvd0Nsb3NlQnV0dG9uICYmIChcbiAgICAgICAgICA8U2hlZXRQcmltaXRpdmUuQ2xvc2VcbiAgICAgICAgICAgIGRhdGEtc2xvdD1cInNoZWV0LWNsb3NlXCJcbiAgICAgICAgICAgIHJlbmRlcj17XG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIHRvcC0zIHJpZ2h0LTNcIlxuICAgICAgICAgICAgICAgIHNpemU9XCJpY29uLXNtXCJcbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8WEljb25cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzci1vbmx5XCI+Q2xvc2U8L3NwYW4+XG4gICAgICAgICAgPC9TaGVldFByaW1pdGl2ZS5DbG9zZT5cbiAgICAgICAgKX1cbiAgICAgIDwvU2hlZXRQcmltaXRpdmUuUG9wdXA+XG4gICAgPC9TaGVldFBvcnRhbD5cbiAgKVxufVxuXG5mdW5jdGlvbiBTaGVldEhlYWRlcih7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfTogUmVhY3QuQ29tcG9uZW50UHJvcHM8XCJkaXZcIj4pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBkYXRhLXNsb3Q9XCJzaGVldC1oZWFkZXJcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcImZsZXggZmxleC1jb2wgZ2FwLTAuNSBwLTRcIiwgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIFNoZWV0Rm9vdGVyKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9OiBSZWFjdC5Db21wb25lbnRQcm9wczxcImRpdlwiPikge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGRhdGEtc2xvdD1cInNoZWV0LWZvb3RlclwiXG4gICAgICBjbGFzc05hbWU9e2NuKFwibXQtYXV0byBmbGV4IGZsZXgtY29sIGdhcC0yIHAtNFwiLCBjbGFzc05hbWUpfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZnVuY3Rpb24gU2hlZXRUaXRsZSh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfTogU2hlZXRQcmltaXRpdmUuVGl0bGUuUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8U2hlZXRQcmltaXRpdmUuVGl0bGVcbiAgICAgIGRhdGEtc2xvdD1cInNoZWV0LXRpdGxlXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiZm9udC1oZWFkaW5nIHRleHQtYmFzZSBmb250LW1lZGl1bSB0ZXh0LWZvcmVncm91bmRcIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZnVuY3Rpb24gU2hlZXREZXNjcmlwdGlvbih7XG4gIGNsYXNzTmFtZSxcbiAgLi4ucHJvcHNcbn06IFNoZWV0UHJpbWl0aXZlLkRlc2NyaXB0aW9uLlByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPFNoZWV0UHJpbWl0aXZlLkRlc2NyaXB0aW9uXG4gICAgICBkYXRhLXNsb3Q9XCJzaGVldC1kZXNjcmlwdGlvblwiXG4gICAgICBjbGFzc05hbWU9e2NuKFwidGV4dC1zbSB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiwgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmV4cG9ydCB7XG4gIFNoZWV0LFxuICBTaGVldFRyaWdnZXIsXG4gIFNoZWV0Q2xvc2UsXG4gIFNoZWV0Q29udGVudCxcbiAgU2hlZXRIZWFkZXIsXG4gIFNoZWV0Rm9vdGVyLFxuICBTaGVldFRpdGxlLFxuICBTaGVldERlc2NyaXB0aW9uLFxufVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvY29tcG9uZW50cy91aS9zaGVldC50c3gifQ==