const _c = __vite__cjsImport0_react_compilerRuntime["c"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { queryOptions, useMutation, useQuery, useQueryClient, useSuspenseQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=e9f94b2e";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=e9f94b2e";
import { getErrorMessage } from "/src/lib/api.ts";
import { queryKeys } from "/src/lib/query-keys.ts";
import { nftService } from "/src/services/nft.service.ts";
export const nftsListQueryOptions = (params) => queryOptions({
	queryKey: queryKeys.nfts.list(params),
	queryFn: () => nftService.list(params),
	staleTime: 3e4
});
export const nftDetailQueryOptions = (nftId) => queryOptions({
	queryKey: queryKeys.nfts.detail(nftId),
	queryFn: () => nftService.getById(nftId),
	staleTime: 3e4
});
export function useGetNFTs(params) {
	const $ = _c(3);
	if ($[0] !== "40ed3698d6a6f6b1b5d5e693cc9a3a442ddefac22d0ec382e7c3a4ac1366abfe") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "40ed3698d6a6f6b1b5d5e693cc9a3a442ddefac22d0ec382e7c3a4ac1366abfe";
	}
	let t0;
	if ($[1] !== params) {
		t0 = nftsListQueryOptions(params);
		$[1] = params;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return useQuery(t0);
}
export function useGetNFT(nftId) {
	const $ = _c(3);
	if ($[0] !== "40ed3698d6a6f6b1b5d5e693cc9a3a442ddefac22d0ec382e7c3a4ac1366abfe") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "40ed3698d6a6f6b1b5d5e693cc9a3a442ddefac22d0ec382e7c3a4ac1366abfe";
	}
	let t0;
	if ($[1] !== nftId) {
		t0 = nftDetailQueryOptions(nftId);
		$[1] = nftId;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return useQuery(t0);
}
export function useSuspenseNFT(nftId) {
	const $ = _c(3);
	if ($[0] !== "40ed3698d6a6f6b1b5d5e693cc9a3a442ddefac22d0ec382e7c3a4ac1366abfe") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "40ed3698d6a6f6b1b5d5e693cc9a3a442ddefac22d0ec382e7c3a4ac1366abfe";
	}
	let t0;
	if ($[1] !== nftId) {
		t0 = nftDetailQueryOptions(nftId);
		$[1] = nftId;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return useSuspenseQuery(t0);
}
function toggleNftItem(nft) {
	const nextFavorited = !nft.isFavorited;
	return {
		...nft,
		isFavorited: nextFavorited,
		likes: Math.max(0, nft.likes + (nextFavorited ? 1 : -1))
	};
}
/**
* Mutação para favoritar/desfavoritar um NFT com Optimistic Update completo:
* - onMutate: cancela queries, salva snapshot de listas e detalhe, injeta estado otimista
* - onError: restaura snapshots (rollback) e notifica via Toast
* - onSettled: invalida queries para ressincronizar com o MSW
*/
export function useToggleFavoriteNFT() {
	const $ = _c(3);
	if ($[0] !== "40ed3698d6a6f6b1b5d5e693cc9a3a442ddefac22d0ec382e7c3a4ac1366abfe") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "40ed3698d6a6f6b1b5d5e693cc9a3a442ddefac22d0ec382e7c3a4ac1366abfe";
	}
	const queryClient = useQueryClient();
	let t0;
	if ($[1] !== queryClient) {
		t0 = {
			mutationFn: _temp,
			onMutate: async (nftId_0) => {
				await queryClient.cancelQueries({ queryKey: queryKeys.nfts.all });
				const previousLists = queryClient.getQueriesData({ queryKey: queryKeys.nfts.lists() });
				const detailKey = queryKeys.nfts.detail(nftId_0);
				const previousDetail = queryClient.getQueryData(detailKey);
				queryClient.setQueriesData({ queryKey: queryKeys.nfts.lists() }, (old) => {
					if (!old) {
						return old;
					}
					return {
						...old,
						items: old.items.map((item) => item.id === nftId_0 ? toggleNftItem(item) : item)
					};
				});
				if (previousDetail) {
					queryClient.setQueryData(detailKey, toggleNftItem(previousDetail));
				}
				return {
					previousLists,
					previousDetail
				};
			},
			onError: (error, nftId_1, context) => {
				if (context?.previousLists) {
					for (const [key, data] of context.previousLists) {
						queryClient.setQueryData(key, data);
					}
				}
				if (context?.previousDetail) {
					queryClient.setQueryData(queryKeys.nfts.detail(nftId_1), context.previousDetail);
				}
				toast.error(getErrorMessage(error));
			},
			onSettled: () => {
				queryClient.invalidateQueries({ queryKey: queryKeys.nfts.all });
			}
		};
		$[1] = queryClient;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return useMutation(t0);
}
function _temp(nftId) {
	return nftService.toggleFavorite(nftId);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQ0VBLGNBQ0FDLGFBQ0FDLFVBQ0FDLGdCQUNBQyx3QkFFSztBQUNQLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxrQkFBa0I7QUFJM0IsT0FBTyxNQUFNQyx3QkFBd0JDLFdBQ25DVixhQUFhO0NBQ1hXLFVBQVVKLFVBQVVLLEtBQUtDLEtBQUtILE1BQU07Q0FDcENJLGVBQWVOLFdBQVdLLEtBQUtILE1BQU07Q0FDckNLLFdBQVc7QUFDYixDQUFDO0FBRUgsT0FBTyxNQUFNQyx5QkFBeUJDLFVBQ3BDakIsYUFBYTtDQUNYVyxVQUFVSixVQUFVSyxLQUFLTSxPQUFPRCxLQUFLO0NBQ3JDSCxlQUFlTixXQUFXVyxRQUFRRixLQUFLO0NBQ3ZDRixXQUFXO0FBQ2IsQ0FBQztBQUVILE9BQU8sU0FBQUssV0FBQVYsUUFBQTtDQUFBLE1BQUFXLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUwsRUFBQSxPQUFBWCxRQUFBO0VBQ1dnQixLQUFBakIscUJBQXFCQyxNQUFNO0VBQUNXLEVBQUEsS0FBQVg7RUFBQVcsRUFBQSxLQUFBSztDQUFBO0VBQUFBLEtBQUFMLEVBQUE7Q0FBQTtDQUFBLE9BQXJDbkIsU0FBU3dCLEVBQTRCO0FBQUM7QUFHL0MsT0FBTyxTQUFBQyxVQUFBVixPQUFBO0NBQUEsTUFBQUksSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFKLE9BQUE7RUFDV1MsS0FBQVYsc0JBQXNCQyxLQUFLO0VBQUNJLEVBQUEsS0FBQUo7RUFBQUksRUFBQSxLQUFBSztDQUFBO0VBQUFBLEtBQUFMLEVBQUE7Q0FBQTtDQUFBLE9BQXJDbkIsU0FBU3dCLEVBQTRCO0FBQUM7QUFHL0MsT0FBTyxTQUFBRSxlQUFBWCxPQUFBO0NBQUEsTUFBQUksSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFKLE9BQUE7RUFDbUJTLEtBQUFWLHNCQUFzQkMsS0FBSztFQUFDSSxFQUFBLEtBQUFKO0VBQUFJLEVBQUEsS0FBQUs7Q0FBQTtFQUFBQSxLQUFBTCxFQUFBO0NBQUE7Q0FBQSxPQUE3Q2pCLGlCQUFpQnNCLEVBQTRCO0FBQUM7QUFRdkQsU0FBU0csY0FBY0MsS0FBZTtDQUNwQyxNQUFNQyxnQkFBZ0IsQ0FBQ0QsSUFBSUU7Q0FDM0IsT0FBTztFQUNMLEdBQUdGO0VBQ0hFLGFBQWFEO0VBQ2JFLE9BQU9DLEtBQUtDLElBQUksR0FBR0wsSUFBSUcsU0FBU0YsZ0JBQWdCLElBQUksQ0FBQyxFQUFFO0NBQ3pEO0FBQ0Y7Ozs7Ozs7QUFRQSxPQUFPLFNBQUFLLHVCQUFBO0NBQUEsTUFBQWYsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQ0wsTUFBQWdCLGNBQW9CbEMsZUFBZTtDQUFDLElBQUF1QjtDQUFBLElBQUFMLEVBQUEsT0FBQWdCLGFBQUE7RUFFakJYLEtBQUE7R0FBQVksWUFDTEM7R0FBbURDLFVBQ3JELE9BQUFDLFlBQUE7SUFDUixNQUFNSixZQUFXSyxjQUFlLEVBQUEvQixVQUFZSixVQUFTSyxLQUFLK0IsSUFBSyxDQUFDO0lBRWhFLE1BQUFDLGdCQUFzQlAsWUFBV1EsZUFBdUMsRUFBQWxDLFVBQzVESixVQUFTSyxLQUFLa0MsTUFBTyxFQUNqQyxDQUFDO0lBQ0QsTUFBQUMsWUFBa0J4QyxVQUFTSyxLQUFLTSxPQUFRRCxPQUFLO0lBQzdDLE1BQUErQixpQkFBdUJYLFlBQVdZLGFBQW1CRixTQUFTO0lBRTlEVixZQUFXYSxlQUNULEVBQUF2QyxVQUFZSixVQUFTSyxLQUFLa0MsTUFBTyxFQUFFLElBQ25DSyxRQUFBO0tBQ0UsSUFBSSxDQUFDQSxLQUFHO01BQUEsT0FBU0E7S0FBRztLQUFBLE9BQ2I7TUFBQSxHQUNGQTtNQUFHQyxPQUNDRCxJQUFHQyxNQUFNQyxLQUFLQyxTQUFXQSxLQUFJQyxPQUFRdEMsVUFBUVksY0FBY3lCLElBQVcsSUFBN0NBLElBQStDO0tBQ2pGO0lBQUMsQ0FFTDtJQUVBLElBQUlOLGdCQUFjO0tBQ2hCWCxZQUFXbUIsYUFBbUJULFdBQVdsQixjQUFjbUIsY0FBYyxDQUFDO0lBQUM7SUFDeEUsT0FFTTtLQUFBSjtLQUFBSTtJQUFnQztHQUFDO0dBQ3pDUyxVQUNRQyxPQUFBQyxTQUFBQyxZQUFBO0lBQ1AsSUFBSUEsU0FBT2hCLGVBQWU7S0FDeEIsS0FBSyxPQUFBaUIsS0FBQUMsU0FBcUJGLFFBQU9oQixlQUFjO01BQzdDUCxZQUFXbUIsYUFBY0ssS0FBS0MsSUFBSTtLQUFDO0lBQ3BDO0lBRUgsSUFBSUYsU0FBT1osZ0JBQWdCO0tBQ3pCWCxZQUFXbUIsYUFBY2pELFVBQVNLLEtBQUtNLE9BQVFELE9BQUssR0FBRzJDLFFBQU9aLGNBQWU7SUFBQztJQUVoRjNDLE1BQUtxRCxNQUFPcEQsZ0JBQWdCb0QsS0FBSyxDQUFDO0dBQUM7R0FDcENLLGlCQUNVO0lBQ0oxQixZQUFXMkIsa0JBQW1CLEVBQUFyRCxVQUFZSixVQUFTSyxLQUFLK0IsSUFBSyxDQUFDO0dBQUM7RUFFeEU7RUFBQ3RCLEVBQUEsS0FBQWdCO0VBQUFoQixFQUFBLEtBQUFLO0NBQUE7RUFBQUEsS0FBQUwsRUFBQTtDQUFBO0NBQUEsT0ExQ01wQixZQUFZeUIsRUEwQ2xCO0FBQUM7QUE3Q0csU0FBQWEsTUFBQXRCLE9BQUE7Q0FBQSxPQUk0QlQsV0FBVXlELGVBQWdCaEQsS0FBSztBQUFDIiwibmFtZXMiOlsicXVlcnlPcHRpb25zIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwidXNlU3VzcGVuc2VRdWVyeSIsInRvYXN0IiwiZ2V0RXJyb3JNZXNzYWdlIiwicXVlcnlLZXlzIiwibmZ0U2VydmljZSIsIm5mdHNMaXN0UXVlcnlPcHRpb25zIiwicGFyYW1zIiwicXVlcnlLZXkiLCJuZnRzIiwibGlzdCIsInF1ZXJ5Rm4iLCJzdGFsZVRpbWUiLCJuZnREZXRhaWxRdWVyeU9wdGlvbnMiLCJuZnRJZCIsImRldGFpbCIsImdldEJ5SWQiLCJ1c2VHZXRORlRzIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJ0MCIsInVzZUdldE5GVCIsInVzZVN1c3BlbnNlTkZUIiwidG9nZ2xlTmZ0SXRlbSIsIm5mdCIsIm5leHRGYXZvcml0ZWQiLCJpc0Zhdm9yaXRlZCIsImxpa2VzIiwiTWF0aCIsIm1heCIsInVzZVRvZ2dsZUZhdm9yaXRlTkZUIiwicXVlcnlDbGllbnQiLCJtdXRhdGlvbkZuIiwiX3RlbXAiLCJvbk11dGF0ZSIsIm5mdElkXzAiLCJjYW5jZWxRdWVyaWVzIiwiYWxsIiwicHJldmlvdXNMaXN0cyIsImdldFF1ZXJpZXNEYXRhIiwibGlzdHMiLCJkZXRhaWxLZXkiLCJwcmV2aW91c0RldGFpbCIsImdldFF1ZXJ5RGF0YSIsInNldFF1ZXJpZXNEYXRhIiwib2xkIiwiaXRlbXMiLCJtYXAiLCJpdGVtIiwiaWQiLCJzZXRRdWVyeURhdGEiLCJvbkVycm9yIiwiZXJyb3IiLCJuZnRJZF8xIiwiY29udGV4dCIsImtleSIsImRhdGEiLCJvblNldHRsZWQiLCJpbnZhbGlkYXRlUXVlcmllcyIsInRvZ2dsZUZhdm9yaXRlIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInVzZS1uZnRzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIHF1ZXJ5T3B0aW9ucyxcbiAgdXNlTXV0YXRpb24sXG4gIHVzZVF1ZXJ5LFxuICB1c2VRdWVyeUNsaWVudCxcbiAgdXNlU3VzcGVuc2VRdWVyeSxcbiAgdHlwZSBRdWVyeUtleSxcbn0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdzb25uZXInXG5pbXBvcnQgeyBnZXRFcnJvck1lc3NhZ2UgfSBmcm9tICdAL2xpYi9hcGknXG5pbXBvcnQgeyBxdWVyeUtleXMgfSBmcm9tICdAL2xpYi9xdWVyeS1rZXlzJ1xuaW1wb3J0IHsgbmZ0U2VydmljZSB9IGZyb20gJ0Avc2VydmljZXMvbmZ0LnNlcnZpY2UnXG5pbXBvcnQgdHlwZSB7IE5mdExpc3RQYXJhbXMsIFBhZ2luYXRlZE5mdHNSZXNwb25zZSB9IGZyb20gJ0AvdHlwZXMvYXBpJ1xuaW1wb3J0IHR5cGUgeyBORlQgfSBmcm9tICdAL3R5cGVzL21vZGVscydcblxuZXhwb3J0IGNvbnN0IG5mdHNMaXN0UXVlcnlPcHRpb25zID0gKHBhcmFtczogTmZ0TGlzdFBhcmFtcykgPT5cbiAgcXVlcnlPcHRpb25zKHtcbiAgICBxdWVyeUtleTogcXVlcnlLZXlzLm5mdHMubGlzdChwYXJhbXMpLFxuICAgIHF1ZXJ5Rm46ICgpID0+IG5mdFNlcnZpY2UubGlzdChwYXJhbXMpLFxuICAgIHN0YWxlVGltZTogMzBfMDAwLFxuICB9KVxuXG5leHBvcnQgY29uc3QgbmZ0RGV0YWlsUXVlcnlPcHRpb25zID0gKG5mdElkOiBzdHJpbmcpID0+XG4gIHF1ZXJ5T3B0aW9ucyh7XG4gICAgcXVlcnlLZXk6IHF1ZXJ5S2V5cy5uZnRzLmRldGFpbChuZnRJZCksXG4gICAgcXVlcnlGbjogKCkgPT4gbmZ0U2VydmljZS5nZXRCeUlkKG5mdElkKSxcbiAgICBzdGFsZVRpbWU6IDMwXzAwMCxcbiAgfSlcblxuZXhwb3J0IGZ1bmN0aW9uIHVzZUdldE5GVHMocGFyYW1zOiBOZnRMaXN0UGFyYW1zKSB7XG4gIHJldHVybiB1c2VRdWVyeShuZnRzTGlzdFF1ZXJ5T3B0aW9ucyhwYXJhbXMpKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlR2V0TkZUKG5mdElkOiBzdHJpbmcpIHtcbiAgcmV0dXJuIHVzZVF1ZXJ5KG5mdERldGFpbFF1ZXJ5T3B0aW9ucyhuZnRJZCkpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VTdXNwZW5zZU5GVChuZnRJZDogc3RyaW5nKSB7XG4gIHJldHVybiB1c2VTdXNwZW5zZVF1ZXJ5KG5mdERldGFpbFF1ZXJ5T3B0aW9ucyhuZnRJZCkpXG59XG5cbmludGVyZmFjZSBGYXZvcml0ZU11dGF0aW9uQ29udGV4dCB7XG4gIHByZXZpb3VzTGlzdHM6IEFycmF5PFtRdWVyeUtleSwgUGFnaW5hdGVkTmZ0c1Jlc3BvbnNlIHwgdW5kZWZpbmVkXT5cbiAgcHJldmlvdXNEZXRhaWw6IE5GVCB8IHVuZGVmaW5lZFxufVxuXG5mdW5jdGlvbiB0b2dnbGVOZnRJdGVtKG5mdDogTkZUKTogTkZUIHtcbiAgY29uc3QgbmV4dEZhdm9yaXRlZCA9ICFuZnQuaXNGYXZvcml0ZWRcbiAgcmV0dXJuIHtcbiAgICAuLi5uZnQsXG4gICAgaXNGYXZvcml0ZWQ6IG5leHRGYXZvcml0ZWQsXG4gICAgbGlrZXM6IE1hdGgubWF4KDAsIG5mdC5saWtlcyArIChuZXh0RmF2b3JpdGVkID8gMSA6IC0xKSksXG4gIH1cbn1cblxuLyoqXG4gKiBNdXRhw6fDo28gcGFyYSBmYXZvcml0YXIvZGVzZmF2b3JpdGFyIHVtIE5GVCBjb20gT3B0aW1pc3RpYyBVcGRhdGUgY29tcGxldG86XG4gKiAtIG9uTXV0YXRlOiBjYW5jZWxhIHF1ZXJpZXMsIHNhbHZhIHNuYXBzaG90IGRlIGxpc3RhcyBlIGRldGFsaGUsIGluamV0YSBlc3RhZG8gb3RpbWlzdGFcbiAqIC0gb25FcnJvcjogcmVzdGF1cmEgc25hcHNob3RzIChyb2xsYmFjaykgZSBub3RpZmljYSB2aWEgVG9hc3RcbiAqIC0gb25TZXR0bGVkOiBpbnZhbGlkYSBxdWVyaWVzIHBhcmEgcmVzc2luY3Jvbml6YXIgY29tIG8gTVNXXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VUb2dnbGVGYXZvcml0ZU5GVCgpIHtcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG5cbiAgcmV0dXJuIHVzZU11dGF0aW9uKHtcbiAgICBtdXRhdGlvbkZuOiAobmZ0SWQ6IHN0cmluZykgPT4gbmZ0U2VydmljZS50b2dnbGVGYXZvcml0ZShuZnRJZCksXG4gICAgb25NdXRhdGU6IGFzeW5jIChuZnRJZDogc3RyaW5nKTogUHJvbWlzZTxGYXZvcml0ZU11dGF0aW9uQ29udGV4dD4gPT4ge1xuICAgICAgYXdhaXQgcXVlcnlDbGllbnQuY2FuY2VsUXVlcmllcyh7IHF1ZXJ5S2V5OiBxdWVyeUtleXMubmZ0cy5hbGwgfSlcblxuICAgICAgY29uc3QgcHJldmlvdXNMaXN0cyA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJpZXNEYXRhPFBhZ2luYXRlZE5mdHNSZXNwb25zZT4oe1xuICAgICAgICBxdWVyeUtleTogcXVlcnlLZXlzLm5mdHMubGlzdHMoKSxcbiAgICAgIH0pXG4gICAgICBjb25zdCBkZXRhaWxLZXkgPSBxdWVyeUtleXMubmZ0cy5kZXRhaWwobmZ0SWQpXG4gICAgICBjb25zdCBwcmV2aW91c0RldGFpbCA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5RGF0YTxORlQ+KGRldGFpbEtleSlcblxuICAgICAgcXVlcnlDbGllbnQuc2V0UXVlcmllc0RhdGE8UGFnaW5hdGVkTmZ0c1Jlc3BvbnNlPihcbiAgICAgICAgeyBxdWVyeUtleTogcXVlcnlLZXlzLm5mdHMubGlzdHMoKSB9LFxuICAgICAgICAob2xkKSA9PiB7XG4gICAgICAgICAgaWYgKCFvbGQpIHJldHVybiBvbGRcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4ub2xkLFxuICAgICAgICAgICAgaXRlbXM6IG9sZC5pdGVtcy5tYXAoKGl0ZW0pID0+IChpdGVtLmlkID09PSBuZnRJZCA/IHRvZ2dsZU5mdEl0ZW0oaXRlbSkgOiBpdGVtKSksXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgKVxuXG4gICAgICBpZiAocHJldmlvdXNEZXRhaWwpIHtcbiAgICAgICAgcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhPE5GVD4oZGV0YWlsS2V5LCB0b2dnbGVOZnRJdGVtKHByZXZpb3VzRGV0YWlsKSlcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHsgcHJldmlvdXNMaXN0cywgcHJldmlvdXNEZXRhaWwgfVxuICAgIH0sXG4gICAgb25FcnJvcjogKGVycm9yLCBuZnRJZCwgY29udGV4dCkgPT4ge1xuICAgICAgaWYgKGNvbnRleHQ/LnByZXZpb3VzTGlzdHMpIHtcbiAgICAgICAgZm9yIChjb25zdCBba2V5LCBkYXRhXSBvZiBjb250ZXh0LnByZXZpb3VzTGlzdHMpIHtcbiAgICAgICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGEoa2V5LCBkYXRhKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoY29udGV4dD8ucHJldmlvdXNEZXRhaWwpIHtcbiAgICAgICAgcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhKHF1ZXJ5S2V5cy5uZnRzLmRldGFpbChuZnRJZCksIGNvbnRleHQucHJldmlvdXNEZXRhaWwpXG4gICAgICB9XG4gICAgICB0b2FzdC5lcnJvcihnZXRFcnJvck1lc3NhZ2UoZXJyb3IpKVxuICAgIH0sXG4gICAgb25TZXR0bGVkOiAoKSA9PiB7XG4gICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IHF1ZXJ5S2V5cy5uZnRzLmFsbCB9KVxuICAgIH0sXG4gIH0pXG59XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9ob29rcy91c2UtbmZ0cy50cyJ9