import { n as __exportAll, r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=e9f94b2e";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom-CRx58tZq.js?v=e9f94b2e";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-cNwuCTLA.js?v=e9f94b2e";
import { r as useIsoLayoutEffect, t as useStableCallback } from "/node_modules/.vite/deps/formatErrorMessage-BEgQI17N.js?v=e9f94b2e";
import { d as isElement, l as getWindow } from "/node_modules/.vite/deps/floating-ui.utils.dom-B45hE2lE.js?v=e9f94b2e";
import { A as useFloatingPortalNode, At as addEventListener, F as POPUP_COLLISION_AVOIDANCE, S as useDismiss, a as fastComponentRef, bt as isMouseLikePointerType, c as PopupHandleAttachment, dt as closed$3, ft as endingStyle$1, g as usePopupRootStore, h as usePopupInteractionProps, ht as startingStyle$1, i as fastComponent, it as popupTransitionStateMapping, l as applyPopupOpenChange, lt as align$3, m as useOpenStateTransitions, mt as side$3, n as ReactStore, nt as triggerDisabled, o as PopupTriggerMap, ot as triggerOpenStateMapping, p as useImplicitActiveTrigger, pt as open$3, q as useValueAsRef, rt as popupStateMapping, s as FOCUSABLE_POPUP_PROPS, tt as TooltipTriggerDataAttributes_exports, ut as anchorHidden$1, v as useTriggerDataForwarding } from "/node_modules/.vite/deps/FloatingRootStore-BMBEPfxq.js?v=e9f94b2e";
import { c as EMPTY_OBJECT, l as NOOP, n as useRenderElement } from "/node_modules/.vite/deps/useRenderElement-CvMw8z9e.js?v=e9f94b2e";
import { n as useTimeout, t as Timeout } from "/node_modules/.vite/deps/useTimeout-w0MCIDxv.js?v=e9f94b2e";
import { t as useOpenChangeComplete } from "/node_modules/.vite/deps/useOpenChangeComplete-BJDlY1Cs.js?v=e9f94b2e";
import { d as getTarget, l as closest, u as contains } from "/node_modules/.vite/deps/composite-DUPI88po.js?v=e9f94b2e";
import { a as useHoverFloatingInteraction, c as getDelay, i as useHoverReferenceInteraction, n as usePopupViewport, o as useHoverInteractionSharedState, r as safePolygon, s as useFocus, t as popupViewportStateMapping } from "/node_modules/.vite/deps/usePopupViewport-BbNw_O59.js?v=e9f94b2e";
import { S as triggerPress, h as none, i as disabled, s as imperativeAction, w as createChangeEventDetails, x as triggerHover } from "/node_modules/.vite/deps/reason-parts-D-IkPsXA.js?v=e9f94b2e";
import { t as useBaseUiId } from "/node_modules/.vite/deps/useBaseUiId-UM7l9pLZ.js?v=e9f94b2e";
import { r as mergeProps } from "/node_modules/.vite/deps/merge-props-v5iSnvoO.js?v=e9f94b2e";
import { a as BasePopupHandle, i as popupStoreSelectors, n as usePopupHandleStore, r as createInitialPopupStoreState, t as NullStore } from "/node_modules/.vite/deps/NullStore-CE4rtHXf.js?v=e9f94b2e";
import { l as getDisabledMountTransitionStyles, n as usePositioner, r as useAnchorPositioning } from "/node_modules/.vite/deps/usePreviousValue-e4KgGpny.js?v=e9f94b2e";
// node_modules/@base-ui/react/floating-ui-react/components/FloatingDelayGroup.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var FloatingDelayGroupContext = /*#__PURE__*/ import_react.createContext({
	hasProvider: false,
	timeoutMs: 0,
	delayRef: { current: 0 },
	initialDelayRef: { current: 0 },
	timeout: new Timeout(),
	currentIdRef: { current: null },
	currentContextRef: { current: null }
});
FloatingDelayGroupContext.displayName = "FloatingDelayGroupContext";
function resetDelayRef(delayRef, initialDelayRef) {
	delayRef.current = initialDelayRef.current;
}
/**
* Experimental next version of `FloatingDelayGroup` to become the default
* in the future. This component is not yet stable.
* Provides context for a group of floating elements that should share a
* `delay`. Unlike `FloatingDelayGroup`, `useDelayGroup` with this
* component does not cause a re-render of unrelated consumers of the
* context when the delay changes.
* @see https://floating-ui.com/docs/FloatingDelayGroup
* @internal
*/
function FloatingDelayGroup(props) {
	const { children, delay, timeoutMs = 0 } = props;
	const delayRef = import_react.useRef(delay);
	const initialDelayRef = import_react.useRef(delay);
	const currentIdRef = import_react.useRef(null);
	const currentContextRef = import_react.useRef(null);
	const timeout = useTimeout();
	useIsoLayoutEffect(() => {
		initialDelayRef.current = delay;
		if (!currentIdRef.current) {
			delayRef.current = delay;
			return;
		}
		delayRef.current = {
			open: getDelay(delayRef.current, "open"),
			close: getDelay(delay, "close")
		};
	}, [
		delay,
		currentIdRef,
		delayRef,
		initialDelayRef
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingDelayGroupContext.Provider, {
		value: import_react.useMemo(() => ({
			hasProvider: true,
			delayRef,
			initialDelayRef,
			currentIdRef,
			timeoutMs,
			currentContextRef,
			timeout
		}), [timeoutMs, timeout]),
		children
	});
}
/**
* Enables grouping when called inside a component that's a child of a
* `FloatingDelayGroup`.
* @see https://floating-ui.com/docs/FloatingDelayGroup
* @internal
*/
function useDelayGroup(store, options = { open: false }) {
	const { open } = options;
	const floatingId = store.useState("floatingId");
	const { currentIdRef, delayRef, timeoutMs, initialDelayRef, currentContextRef, hasProvider, timeout } = import_react.useContext(FloatingDelayGroupContext);
	const [isInstantPhase, setIsInstantPhase] = import_react.useState(false);
	const openRef = import_react.useRef(open);
	useIsoLayoutEffect(() => {
		openRef.current = open;
	}, [open]);
	useIsoLayoutEffect(() => {
		function unset() {
			currentContextRef.current?.setIsInstantPhase(false);
			currentIdRef.current = null;
			currentContextRef.current = null;
			delayRef.current = initialDelayRef.current;
			timeout.clear();
		}
		if (!currentIdRef.current) return;
		if (!open && currentIdRef.current === floatingId) {
			setIsInstantPhase(false);
			if (timeoutMs) {
				const closingId = floatingId;
				timeout.start(timeoutMs, () => {
					if (store.select("open") || currentIdRef.current && currentIdRef.current !== closingId) return;
					unset();
				});
				return () => {
					if (openRef.current || currentIdRef.current !== closingId) timeout.clear();
				};
			}
			unset();
		}
	}, [
		open,
		floatingId,
		currentIdRef,
		delayRef,
		timeoutMs,
		initialDelayRef,
		currentContextRef,
		timeout,
		store
	]);
	useIsoLayoutEffect(() => {
		if (!open) return;
		const prevContext = currentContextRef.current;
		const prevId = currentIdRef.current;
		timeout.clear();
		currentContextRef.current = {
			onOpenChange: store.setOpen,
			setIsInstantPhase
		};
		currentIdRef.current = floatingId;
		delayRef.current = {
			open: 0,
			close: getDelay(initialDelayRef.current, "close")
		};
		if (prevId !== null && prevId !== floatingId) {
			setIsInstantPhase(true);
			prevContext?.setIsInstantPhase(true);
			prevContext?.onOpenChange(false, createChangeEventDetails(none));
		} else {
			setIsInstantPhase(false);
			prevContext?.setIsInstantPhase(false);
		}
	}, [
		open,
		floatingId,
		store,
		currentIdRef,
		delayRef,
		initialDelayRef,
		currentContextRef,
		timeout
	]);
	useIsoLayoutEffect(() => {
		return () => {
			if (currentIdRef.current === floatingId) {
				currentContextRef.current = null;
				if (!openRef.current) return;
				currentIdRef.current = null;
				resetDelayRef(delayRef, initialDelayRef);
				timeout.clear();
			}
		};
	}, [
		currentContextRef,
		currentIdRef,
		delayRef,
		floatingId,
		initialDelayRef,
		timeout
	]);
	return import_react.useMemo(() => ({
		activeIdRef: currentIdRef,
		hasProvider,
		delayRef,
		isInstantPhase
	}), [
		currentIdRef,
		hasProvider,
		delayRef,
		isInstantPhase
	]);
}
// node_modules/@base-ui/react/floating-ui-react/hooks/useClientPoint.mjs
function createVirtualElement(domElement, data) {
	let offsetX = null;
	let offsetY = null;
	let isAutoUpdateEvent = false;
	return {
		contextElement: domElement || void 0,
		getBoundingClientRect() {
			const domRect = domElement?.getBoundingClientRect() || {
				width: 0,
				height: 0,
				x: 0,
				y: 0
			};
			const isXAxis = data.axis === "x" || data.axis === "both";
			const isYAxis = data.axis === "y" || data.axis === "both";
			const canTrackCursorOnAutoUpdate = ["mouseenter", "mousemove"].includes(data.dataRef.current.openEvent?.type || "") && data.pointerType !== "touch";
			const width = data.axis === "y" ? domRect.width : 0;
			const height = data.axis === "x" ? domRect.height : 0;
			let x = domRect.x;
			let y = domRect.y;
			if (offsetX == null && data.x && isXAxis) offsetX = domRect.x - data.x;
			if (offsetY == null && data.y && isYAxis) offsetY = domRect.y - data.y;
			x -= offsetX || 0;
			y -= offsetY || 0;
			if (!isAutoUpdateEvent || canTrackCursorOnAutoUpdate) {
				x = isXAxis && data.x != null ? data.x : x;
				y = isYAxis && data.y != null ? data.y : y;
			}
			isAutoUpdateEvent = true;
			return {
				width,
				height,
				x,
				y,
				top: y,
				right: x + width,
				bottom: y + height,
				left: x
			};
		}
	};
}
function isMouseBasedEvent(event) {
	return event != null && event.clientX != null;
}
/**
* Positions the floating element relative to a client point (in the viewport),
* such as the mouse position. By default, it follows the mouse cursor.
* @see https://floating-ui.com/docs/useClientPoint
*/
function useClientPoint(store, props = {}) {
	const { enabled = true, axis = "both" } = props;
	const open = store.useState("open");
	const floating = store.useState("floatingElement");
	const domReference = store.useState("domReferenceElement");
	const dataRef = store.context.dataRef;
	const initialRef = import_react.useRef(false);
	const cleanupListenerRef = import_react.useRef(null);
	const [pointerType, setPointerType] = import_react.useState();
	const [reactive, setReactive] = import_react.useState([]);
	const resetReference = useStableCallback((reference) => {
		store.set("positionReference", reference);
	});
	const setReference = useStableCallback((newX, newY, referenceElement) => {
		if (initialRef.current) return;
		if (dataRef.current.openEvent && !isMouseBasedEvent(dataRef.current.openEvent)) return;
		store.set("positionReference", createVirtualElement(referenceElement ?? domReference, {
			x: newX,
			y: newY,
			axis,
			dataRef,
			pointerType
		}));
	});
	const handleReferenceEnterOrMove = useStableCallback((event) => {
		if (!open) setReference(event.clientX, event.clientY, event.currentTarget);
		else if (!cleanupListenerRef.current) {
			setReference(event.clientX, event.clientY, event.currentTarget);
			setReactive([]);
		}
	});
	const openCheck = isMouseLikePointerType(pointerType) ? floating : open;
	import_react.useEffect(() => {
		if (!enabled) {
			resetReference(domReference);
			return;
		}
		if (!openCheck) return;
		function cleanupListener() {
			cleanupListenerRef.current?.();
			cleanupListenerRef.current = null;
		}
		const win = getWindow(floating);
		function handleMouseMove(event) {
			const target = getTarget(event);
			if (!contains(floating, target)) setReference(event.clientX, event.clientY);
			else cleanupListener();
		}
		if (!dataRef.current.openEvent || isMouseBasedEvent(dataRef.current.openEvent)) cleanupListenerRef.current = addEventListener(win, "mousemove", handleMouseMove);
		else resetReference(domReference);
		return cleanupListener;
	}, [
		openCheck,
		enabled,
		floating,
		dataRef,
		domReference,
		store,
		setReference,
		resetReference,
		reactive
	]);
	import_react.useEffect(() => () => {
		store.set("positionReference", null);
	}, [store]);
	import_react.useEffect(() => {
		if (enabled && !floating) initialRef.current = false;
	}, [enabled, floating]);
	import_react.useEffect(() => {
		if (!enabled && open) initialRef.current = true;
	}, [enabled, open]);
	const reference = import_react.useMemo(() => {
		function setPointerTypeRef(event) {
			setPointerType(event.pointerType);
		}
		return {
			onPointerDown: setPointerTypeRef,
			onPointerEnter: setPointerTypeRef,
			onMouseMove: handleReferenceEnterOrMove,
			onMouseEnter: handleReferenceEnterOrMove
		};
	}, [handleReferenceEnterOrMove]);
	return import_react.useMemo(() => enabled ? {
		reference,
		trigger: reference
	} : {}, [enabled, reference]);
}
// node_modules/@base-ui/react/tooltip/root/TooltipRootContext.mjs
var TooltipRootContext = /*#__PURE__*/ import_react.createContext(void 0);
TooltipRootContext.displayName = "TooltipRootContext";
function useTooltipRootContext(optional) {
	const context = import_react.useContext(TooltipRootContext);
	if (context === void 0 && !optional) throw new Error("Base UI: TooltipRootContext is missing. Tooltip parts must be placed within <Tooltip.Root>.");
	return context;
}
// node_modules/@base-ui/react/tooltip/store/TooltipStore.mjs
var selectors = {
	...popupStoreSelectors,
	disabled: (state) => state.disabled,
	instantType: (state) => state.instantType,
	isInstantPhase: (state) => state.isInstantPhase,
	trackCursorAxis: (state) => state.trackCursorAxis,
	disableHoverablePopup: (state) => state.disableHoverablePopup,
	lastOpenChangeReason: (state) => state.openChangeReason,
	closeOnClick: (state) => state.closeOnClick,
	appliedTriggerProps: (state, apply) => apply ? state.activeTriggerProps : void 0,
	closeDelay: (state) => state.closeDelay,
	adaptiveOrigin: (state) => state.adaptiveOrigin
};
/**
* The store view that detached handle-backed triggers read from. Both the real `TooltipStore` and
* the inert fallback store satisfy it, so a trigger can read from whichever store the handle
* currently exposes. Narrowed to the members a trigger actually uses — the trigger-data members plus
* `setOpen`/`cancelPendingOpen` (called directly by the trigger) and `useSyncedValue` — so the
* exposed surface can't bypass the open-change pipeline; on the detached fallback store every one of
* these mutations is a no-op.
*/
var TooltipStore = class extends ReactStore {
	constructor(initialState, floatingId, nested) {
		const triggerElements = new PopupTriggerMap();
		super(createInitialState(initialState, triggerElements, floatingId, nested), createInitialContext(triggerElements), selectors);
	}
	setOpen = (nextOpen, eventDetails) => {
		applyPopupOpenChange(this, nextOpen, eventDetails, { extraState: { openChangeReason: eventDetails.reason } });
	};
	cancelPendingOpen(event) {
		this.state.floatingRootContext.dispatchOpenChange(false, createChangeEventDetails(triggerPress, event));
	}
};
/**
* Creates the inert fallback store used by detached handle-backed triggers while no `Tooltip.Root`
* is attached. It preserves a tooltip-specific trigger registry in context so detached triggers can
* register before migrating to the live root store. `setOpen`/`cancelPendingOpen` are no-ops
* (matching the inert reads/writes of `NullStore`), so a trigger can call them from hover/click
* handlers while detached without any effect.
*/
function createNullTooltipStore() {
	const triggerElements = new PopupTriggerMap();
	const store = new NullStore(Object.freeze(createInitialState(void 0, triggerElements)), Object.freeze(createInitialContext(triggerElements)), selectors);
	return Object.assign(store, {
		setOpen: NOOP,
		cancelPendingOpen: NOOP
	});
}
function createInitialState(initialState, triggerElements, floatingId, nested = false) {
	return {
		...createInitialPopupStoreState(triggerElements, floatingId, nested),
		disabled: false,
		instantType: void 0,
		isInstantPhase: false,
		trackCursorAxis: "none",
		disableHoverablePopup: false,
		openChangeReason: null,
		closeOnClick: true,
		closeDelay: 0,
		adaptiveOrigin: void 0,
		...initialState
	};
}
function createInitialContext(triggerElements) {
	return {
		popupRef: /*#__PURE__*/ import_react.createRef(),
		onOpenChange: void 0,
		onOpenChangeComplete: void 0,
		triggerElements
	};
}
// node_modules/@base-ui/react/tooltip/root/TooltipRoot.mjs
/**
* Groups all parts of the tooltip.
* Doesn't render its own HTML element.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipRoot = fastComponent(function TooltipRoot(props) {
	const { disabled: disabled$1 = false, defaultOpen = false, open: openProp, disableHoverablePopup = false, trackCursorAxis = "none", actionsRef, onOpenChange, onOpenChangeComplete, handle, triggerId: triggerIdProp, defaultTriggerId: defaultTriggerIdProp = null, children } = props;
	const store = usePopupRootStore((floatingId, nested) => new TooltipStore({
		open: defaultOpen,
		openProp,
		activeTriggerId: defaultTriggerIdProp,
		triggerIdProp
	}, floatingId, nested));
	store.useControlledProp("openProp", openProp);
	store.useControlledProp("triggerIdProp", triggerIdProp);
	store.useContextCallback("onOpenChange", onOpenChange);
	store.useContextCallback("onOpenChangeComplete", onOpenChangeComplete);
	const openState = store.useState("open");
	const open = !disabled$1 && openState;
	const activeTriggerId = store.useState("activeTriggerId");
	const mounted = store.useState("mounted");
	const payload = store.useState("payload");
	store.useSyncedValues({
		trackCursorAxis,
		disableHoverablePopup,
		disabled: disabled$1
	});
	useImplicitActiveTrigger(store, { closeOnActiveTriggerUnmount: true });
	const { forceUnmount, transitionStatus } = useOpenStateTransitions(open, store);
	const isInstantPhase = store.useState("isInstantPhase");
	const instantType = store.useState("instantType");
	const lastOpenChangeReason = store.useState("lastOpenChangeReason");
	const previousInstantTypeRef = import_react.useRef(null);
	useIsoLayoutEffect(() => {
		if (openState && disabled$1) store.setOpen(false, createChangeEventDetails(disabled));
	}, [
		openState,
		disabled$1,
		store
	]);
	useIsoLayoutEffect(() => {
		if (transitionStatus === "ending" && lastOpenChangeReason === "none" || transitionStatus !== "ending" && isInstantPhase) {
			if (instantType !== "delay") previousInstantTypeRef.current = instantType;
			store.set("instantType", "delay");
		} else if (previousInstantTypeRef.current !== null) {
			store.set("instantType", previousInstantTypeRef.current);
			previousInstantTypeRef.current = null;
		}
	}, [
		transitionStatus,
		isInstantPhase,
		lastOpenChangeReason,
		instantType,
		store
	]);
	useIsoLayoutEffect(() => {
		if (open) {
			if (activeTriggerId == null) store.set("payload", void 0);
		}
	}, [
		store,
		activeTriggerId,
		open
	]);
	import_react.useImperativeHandle(actionsRef, () => ({
		unmount: forceUnmount,
		close: () => store.setOpen(false, createChangeEventDetails(imperativeAction))
	}), [forceUnmount, store]);
	const shouldRenderInteractions = open || mounted || !disabled$1 && trackCursorAxis !== "none";
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(TooltipRootContext.Provider, {
		value: store,
		children: [
			handle && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PopupHandleAttachment, {
				handle,
				store
			}),
			shouldRenderInteractions && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(TooltipInteractions, {
				store,
				disabled: disabled$1,
				trackCursorAxis
			}),
			typeof children === "function" ? children({ payload }) : children
		]
	});
});
TooltipRoot.displayName = "TooltipRoot";
function TooltipInteractions({ store, disabled, trackCursorAxis }) {
	const floatingRootContext = store.useState("floatingRootContext");
	const dismiss = useDismiss(floatingRootContext, {
		enabled: !disabled,
		referencePress: () => store.select("closeOnClick")
	});
	const clientPoint = useClientPoint(floatingRootContext, {
		enabled: !disabled && trackCursorAxis !== "none",
		axis: trackCursorAxis === "none" ? void 0 : trackCursorAxis
	});
	const triggerProps = import_react.useMemo(() => mergeProps(clientPoint.reference, dismiss.reference), [clientPoint.reference, dismiss.reference]);
	usePopupInteractionProps(store, {
		activeTriggerProps: triggerProps,
		inactiveTriggerProps: triggerProps,
		popupProps: dismiss.floating ?? EMPTY_OBJECT
	});
	return null;
}
// node_modules/@base-ui/react/tooltip/provider/TooltipProviderContext.mjs
/**
* Holds the provider's `delay` value. `closeDelay` is handled by the delay group.
*/
var TooltipProviderContext = /*#__PURE__*/ import_react.createContext(void 0);
TooltipProviderContext.displayName = "TooltipProviderContext";
function useTooltipProviderContext() {
	return import_react.useContext(TooltipProviderContext);
}
// node_modules/@base-ui/react/tooltip/trigger/TooltipTrigger.mjs
var TOOLTIP_TRIGGER_IDENTIFIER = "data-base-ui-tooltip-trigger";
function getTargetElement(event) {
	const target = getTarget(event);
	return isElement(target) ? target : null;
}
/**
* An element to attach the tooltip to.
* Renders a `<button>` element.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipTrigger = fastComponentRef(function TooltipTrigger(componentProps, forwardedRef) {
	const { render, className, style, handle, payload, disabled: disabledProp, delay, closeOnClick = true, closeDelay, id: idProp, ...elementProps } = componentProps;
	const rootContext = useTooltipRootContext(true);
	const store = usePopupHandleStore(handle) ?? rootContext;
	if (!store) throw new Error("Base UI: <Tooltip.Trigger> must be either used within a <Tooltip.Root> component or provided with a handle.");
	const thisTriggerId = useBaseUiId(idProp);
	const isTriggerActive = store.useState("isTriggerActive", thisTriggerId);
	const isOpenedByThisTrigger = store.useState("isOpenedByTrigger", thisTriggerId);
	const floatingRootContext = store.useState("floatingRootContext");
	const triggerElementRef = import_react.useRef(null);
	const closeDelayWithDefault = closeDelay ?? 0;
	const { registerTrigger, isMountedByThisTrigger } = useTriggerDataForwarding(thisTriggerId, triggerElementRef, store, {
		payload,
		closeOnClick,
		closeDelay: closeDelayWithDefault
	});
	const providerDelay = useTooltipProviderContext();
	const { activeIdRef, delayRef, isInstantPhase, hasProvider } = useDelayGroup(floatingRootContext, { open: isOpenedByThisTrigger });
	const hoverInteraction = useHoverInteractionSharedState(floatingRootContext);
	store.useSyncedValue("isInstantPhase", isInstantPhase);
	const rootDisabled = store.useState("disabled");
	const disabled = disabledProp ?? rootDisabled;
	const disabledRef = useValueAsRef(disabled);
	const trackCursorAxis = store.useState("trackCursorAxis");
	const disableHoverablePopup = store.useState("disableHoverablePopup");
	const isNestedTriggerHoveredRef = import_react.useRef(false);
	const nestedTriggerOpenTimeout = useTimeout();
	const pointerTypeRef = import_react.useRef(void 0);
	function getOpenDelay() {
		if (hasProvider && activeIdRef.current != null) return 0;
		return delay ?? providerDelay ?? 600;
	}
	function isEnabledNestedTriggerTarget(target) {
		const triggerEl = triggerElementRef.current;
		if (!triggerEl || !target) return false;
		const nearestTrigger = closest(target, `[${TOOLTIP_TRIGGER_IDENTIFIER}]`);
		return nearestTrigger !== null && nearestTrigger !== triggerEl && contains(triggerEl, nearestTrigger);
	}
	function detectNestedTriggerHover(target) {
		const nestedTriggerHovered = isEnabledNestedTriggerTarget(target);
		isNestedTriggerHoveredRef.current = nestedTriggerHovered;
		if (nestedTriggerHovered) {
			hoverInteraction.openChangeTimeout.clear();
			hoverInteraction.restTimeout.clear();
			hoverInteraction.restTimeoutPending = false;
			nestedTriggerOpenTimeout.clear();
		}
		return nestedTriggerHovered;
	}
	const hoverProps = useHoverReferenceInteraction(floatingRootContext, {
		enabled: !disabled,
		mouseOnly: true,
		move: false,
		handleClose: !disableHoverablePopup && trackCursorAxis !== "both" ? safePolygon() : null,
		restMs: getOpenDelay,
		delay() {
			if (closeDelay == null && hasProvider) return { close: getDelay(delayRef.current, "close") };
			return { close: closeDelayWithDefault };
		},
		triggerElementRef,
		isActiveTrigger: isTriggerActive,
		isClosing: () => store.select("transitionStatus") === "ending",
		shouldOpen() {
			return !isNestedTriggerHoveredRef.current;
		}
	});
	const focusProps = useFocus(floatingRootContext, { enabled: !disabled }).reference;
	const handleNestedTriggerHover = (event) => {
		const wasNestedTriggerHovered = isNestedTriggerHoveredRef.current;
		const target = getTargetElement(event);
		const nestedTriggerHovered = detectNestedTriggerHover(target);
		const triggerEl = triggerElementRef.current;
		const targetInsideTrigger = triggerEl && target && contains(triggerEl, target);
		if (nestedTriggerHovered && store.select("open") && store.select("lastOpenChangeReason") === "trigger-hover") {
			store.setOpen(false, createChangeEventDetails(triggerHover, event));
			return;
		}
		if (wasNestedTriggerHovered && !nestedTriggerHovered && targetInsideTrigger && !disabledRef.current && !store.select("open") && triggerEl && isMouseLikePointerType(pointerTypeRef.current)) {
			const open = () => {
				if (!isNestedTriggerHoveredRef.current && !disabledRef.current && !store.select("open")) store.setOpen(true, createChangeEventDetails(triggerHover, event, triggerEl));
			};
			const openDelay = getOpenDelay();
			if (openDelay === 0) {
				nestedTriggerOpenTimeout.clear();
				open();
			} else nestedTriggerOpenTimeout.start(openDelay, open);
		}
	};
	const rootTriggerProps = store.useState("appliedTriggerProps", isMountedByThisTrigger || trackCursorAxis !== "none");
	return useRenderElement("button", componentProps, {
		state: { open: isOpenedByThisTrigger },
		ref: [
			forwardedRef,
			registerTrigger,
			triggerElementRef
		],
		props: [
			hoverProps,
			focusProps,
			rootTriggerProps,
			{
				onMouseOver(event) {
					handleNestedTriggerHover(event.nativeEvent);
				},
				onFocus(event) {
					if (isEnabledNestedTriggerTarget(getTargetElement(event.nativeEvent))) event.preventBaseUIHandler();
				},
				onMouseLeave() {
					isNestedTriggerHoveredRef.current = false;
					nestedTriggerOpenTimeout.clear();
					pointerTypeRef.current = void 0;
				},
				onPointerEnter(event) {
					pointerTypeRef.current = event.pointerType;
				},
				onPointerDown(event) {
					pointerTypeRef.current = event.pointerType;
					store.set("closeOnClick", closeOnClick);
					if (closeOnClick && !store.select("open")) store.cancelPendingOpen(event.nativeEvent);
				},
				onClick(event) {
					if (closeOnClick && !store.select("open")) store.cancelPendingOpen(event.nativeEvent);
				},
				id: thisTriggerId,
				[triggerDisabled]: disabled ? "" : void 0,
				[TOOLTIP_TRIGGER_IDENTIFIER]: disabled ? void 0 : ""
			},
			elementProps
		],
		stateAttributesMapping: triggerOpenStateMapping
	});
});
TooltipTrigger.displayName = "TooltipTrigger";
// node_modules/@base-ui/react/tooltip/portal/TooltipPortalContext.mjs
var TooltipPortalContext = /*#__PURE__*/ import_react.createContext(void 0);
TooltipPortalContext.displayName = "TooltipPortalContext";
function useTooltipPortalContext() {
	const value = import_react.useContext(TooltipPortalContext);
	if (value === void 0) throw new Error("Base UI: <Tooltip.Portal> is missing.");
	return value;
}
// node_modules/@base-ui/react/utils/FloatingPortalLite.mjs
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
/**
* `FloatingPortal` includes tabbable logic handling for focus management.
* For components that don't need tabbable logic, use `FloatingPortalLite`.
* @internal
*/
var FloatingPortalLite = /*#__PURE__*/ import_react.forwardRef(function FloatingPortalLite(componentProps, forwardedRef) {
	const { children, container, className, render, style, ...elementProps } = componentProps;
	const { node: portalNode, subtree: portalSubtree } = useFloatingPortalNode({
		container,
		ref: forwardedRef,
		componentProps,
		elementProps
	});
	if (!portalSubtree && !portalNode) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [portalSubtree, portalNode && /*#__PURE__*/ import_react_dom.createPortal(children, portalNode)] });
});
FloatingPortalLite.displayName = "FloatingPortalLite";
// node_modules/@base-ui/react/tooltip/portal/TooltipPortal.mjs
/**
* A portal element that moves the popup to a different part of the DOM.
* By default, the portal element is appended to `<body>`.
* Renders a `<div>` element.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipPortal = /*#__PURE__*/ import_react.forwardRef(function TooltipPortal(props, forwardedRef) {
	const { keepMounted = false, ...portalProps } = props;
	if (!(useTooltipRootContext().useState("mounted") || keepMounted)) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(TooltipPortalContext.Provider, {
		value: keepMounted,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingPortalLite, {
			ref: forwardedRef,
			...portalProps
		})
	});
});
TooltipPortal.displayName = "TooltipPortal";
// node_modules/@base-ui/react/tooltip/positioner/TooltipPositionerContext.mjs
var TooltipPositionerContext = /*#__PURE__*/ import_react.createContext(void 0);
TooltipPositionerContext.displayName = "TooltipPositionerContext";
function useTooltipPositionerContext() {
	const context = import_react.useContext(TooltipPositionerContext);
	if (context === void 0) throw new Error("Base UI: TooltipPositionerContext is missing. TooltipPositioner parts must be placed within <Tooltip.Positioner>.");
	return context;
}
// node_modules/@base-ui/react/tooltip/positioner/TooltipPositioner.mjs
/**
* Positions the tooltip against the trigger.
* Renders a `<div>` element.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipPositioner = /*#__PURE__*/ import_react.forwardRef(function TooltipPositioner(componentProps, forwardedRef) {
	const { render, className, anchor, positionMethod = "absolute", side = "top", align = "center", sideOffset = 0, alignOffset = 0, collisionBoundary = "clipping-ancestors", collisionPadding = 5, arrowPadding = 5, sticky = false, disableAnchorTracking = false, collisionAvoidance = POPUP_COLLISION_AVOIDANCE, style, ...elementProps } = componentProps;
	const store = useTooltipRootContext();
	const keepMounted = useTooltipPortalContext();
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const trackCursorAxis = store.useState("trackCursorAxis");
	const disableHoverablePopup = store.useState("disableHoverablePopup");
	const floatingRootContext = store.useState("floatingRootContext");
	const instantType = store.useState("instantType");
	const transitionStatus = store.useState("transitionStatus");
	const adaptiveOrigin = store.useState("adaptiveOrigin");
	const positioning = useAnchorPositioning({
		anchor,
		positionMethod,
		floatingRootContext,
		mounted,
		side,
		sideOffset,
		align,
		alignOffset,
		collisionBoundary,
		collisionPadding,
		sticky,
		arrowPadding,
		disableAnchorTracking,
		keepMounted,
		collisionAvoidance,
		adaptiveOrigin
	});
	const state = import_react.useMemo(() => ({
		open,
		side: positioning.side,
		align: positioning.align,
		anchorHidden: positioning.anchorHidden,
		instant: trackCursorAxis !== "none" ? "tracking-cursor" : instantType
	}), [
		open,
		positioning.side,
		positioning.align,
		positioning.anchorHidden,
		trackCursorAxis,
		instantType
	]);
	const element = usePositioner(componentProps, state, {
		styles: positioning.positionerStyles,
		transitionStatus,
		props: elementProps,
		refs: [forwardedRef, store.useStateSetter("positionerElement")],
		hidden: !mounted,
		inert: !open || trackCursorAxis === "both" || disableHoverablePopup
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(TooltipPositionerContext.Provider, {
		value: positioning,
		children: element
	});
});
TooltipPositioner.displayName = "TooltipPositioner";
// node_modules/@base-ui/react/tooltip/popup/TooltipPopup.mjs
/**
* A container for the tooltip contents.
* Renders a `<div>` element.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipPopup = /*#__PURE__*/ import_react.forwardRef(function TooltipPopup(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const store = useTooltipRootContext();
	const { side, align } = useTooltipPositionerContext();
	const open = store.useState("open");
	const instantType = store.useState("instantType");
	const transitionStatus = store.useState("transitionStatus");
	const popupProps = store.useState("popupProps");
	const floatingContext = store.useState("floatingRootContext");
	const disabled = store.useState("disabled");
	const closeDelay = store.useState("closeDelay");
	useOpenChangeComplete({
		open,
		ref: store.context.popupRef,
		onComplete() {
			if (open) store.context.onOpenChangeComplete?.(true);
		}
	});
	useHoverFloatingInteraction(floatingContext, {
		enabled: !disabled,
		closeDelay
	});
	const setPopupElement = store.useStateSetter("popupElement");
	return useRenderElement("div", componentProps, {
		state: {
			open,
			side,
			align,
			instant: instantType,
			transitionStatus
		},
		ref: [
			forwardedRef,
			store.context.popupRef,
			setPopupElement
		],
		props: [
			FOCUSABLE_POPUP_PROPS,
			popupProps,
			getDisabledMountTransitionStyles(transitionStatus),
			elementProps
		],
		stateAttributesMapping: popupTransitionStateMapping
	});
});
TooltipPopup.displayName = "TooltipPopup";
// node_modules/@base-ui/react/tooltip/arrow/TooltipArrow.mjs
/**
* Displays an element positioned against the tooltip anchor.
* Renders a `<div>` element.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipArrow = /*#__PURE__*/ import_react.forwardRef(function TooltipArrow(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const store = useTooltipRootContext();
	const { arrowRef, side, align, arrowUncentered, arrowStyles } = useTooltipPositionerContext();
	const state = {
		open: store.useState("open"),
		side,
		align,
		uncentered: arrowUncentered,
		instant: store.useState("instantType")
	};
	return useRenderElement("div", componentProps, {
		state,
		ref: [forwardedRef, arrowRef],
		props: [{
			style: arrowStyles,
			"aria-hidden": true
		}, elementProps],
		stateAttributesMapping: popupStateMapping
	});
});
TooltipArrow.displayName = "TooltipArrow";
// node_modules/@base-ui/react/tooltip/provider/TooltipProvider.mjs
/**
* Provides a shared delay for multiple tooltips. The grouping logic ensures that
* once a tooltip becomes visible, the adjacent tooltips will be shown instantly.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipProvider = function TooltipProvider(props) {
	const { delay, closeDelay, timeout = 400 } = props;
	const delayValue = import_react.useMemo(() => ({
		open: delay,
		close: closeDelay
	}), [delay, closeDelay]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(TooltipProviderContext.Provider, {
		value: delay,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingDelayGroup, {
			delay: delayValue,
			timeoutMs: timeout,
			children: props.children
		})
	});
};
TooltipProvider.displayName = "TooltipProvider";
// node_modules/@base-ui/react/tooltip/viewport/TooltipViewport.mjs
/**
* A viewport for displaying content transitions.
* This component is only required if one popup can be opened by multiple triggers, its content
* changes based on the trigger, and switching between them is animated.
* Renders a `<div>` element.
*
* Documentation: [Base UI Tooltip](https://base-ui.com/react/components/tooltip)
*/
var TooltipViewport = /*#__PURE__*/ import_react.forwardRef(function TooltipViewport(componentProps, forwardedRef) {
	const { render, className, style, children, ...elementProps } = componentProps;
	const store = useTooltipRootContext();
	const positioner = useTooltipPositionerContext();
	const instantType = store.useState("instantType");
	const { children: childrenToRender, state: viewportState } = usePopupViewport({
		store,
		side: positioner.side,
		children
	});
	const state = {
		activationDirection: viewportState.activationDirection,
		transitioning: viewportState.transitioning,
		instant: instantType
	};
	return useRenderElement("div", componentProps, {
		state,
		ref: forwardedRef,
		props: [elementProps, { children: childrenToRender }],
		stateAttributesMapping: popupViewportStateMapping
	});
});
TooltipViewport.displayName = "TooltipViewport";
// node_modules/@base-ui/react/tooltip/store/TooltipHandle.mjs
/**
* Controls a Tooltip imperatively and associates detached `Tooltip.Trigger` components with a
* `Tooltip.Root`. Create one with `Tooltip.createHandle()` and pass it to the `handle` prop of the
* root and of any triggers rendered outside of it.
*
* The imperative methods take effect only while a root using this handle is mounted; calls made
* before a root attaches (or after it unmounts) are ignored.
*/
var TooltipHandle = class extends BasePopupHandle {
	constructor() {
		super(createNullTooltipStore(), "Tooltip");
	}
	/**
	* Opens the tooltip and associates it with the trigger with the given id.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*
	* @param triggerId ID of the trigger to associate with the tooltip. The trigger must be a matching
	* `Tooltip.Trigger` with this handle passed as a prop.
	*/
	open(triggerId) {
		this.openByTrigger(triggerId);
	}
	/**
	* Closes the tooltip.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*/
	close() {
		this.closePopup();
	}
	/**
	* Whether the tooltip is currently open. Returns `false` while no root is attached to the handle.
	*/
	get isOpen() {
		return this.attachedStore?.select("open") ?? false;
	}
};
/**
* Creates a new handle to connect a Tooltip.Root with detached Tooltip.Trigger components.
*/
function createTooltipHandle() {
	return new TooltipHandle();
}
// node_modules/@base-ui/react/tooltip/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Arrow: () => TooltipArrow,
	Handle: () => TooltipHandle,
	Popup: () => TooltipPopup,
	Portal: () => TooltipPortal,
	Positioner: () => TooltipPositioner,
	Provider: () => TooltipProvider,
	Root: () => TooltipRoot,
	Trigger: () => TooltipTrigger,
	Viewport: () => TooltipViewport,
	createHandle: () => createTooltipHandle
});
// node_modules/@base-ui/react/tooltip/positioner/TooltipPositionerCssVars.mjs
var TooltipPositionerCssVars_exports = /* @__PURE__ */ __exportAll({
	anchorHeight: () => anchorHeight,
	anchorWidth: () => anchorWidth,
	availableHeight: () => availableHeight,
	availableWidth: () => availableWidth,
	positionerHeight: () => positionerHeight,
	positionerWidth: () => positionerWidth,
	transformOrigin: () => transformOrigin
});
/**
* The available width between the trigger and the edge of the viewport.
* @type {number}
*/
var availableWidth = "--available-width";
/**
* The available height between the trigger and the edge of the viewport.
* @type {number}
*/
var availableHeight = "--available-height";
/**
* The anchor's width.
* @type {number}
*/
var anchorWidth = "--anchor-width";
/**
* The anchor's height.
* @type {number}
*/
var anchorHeight = "--anchor-height";
/**
* The coordinates that this element is anchored to. Used for animations and transitions.
* @type {string}
*/
var transformOrigin = "--transform-origin";
/**
* The width of the tooltip's positioner.
* It is important to set `width` to this value when using CSS to animate size changes.
* @type {number}
*/
var positionerWidth = "--positioner-width";
/**
* The height of the tooltip's positioner.
* It is important to set `height` to this value when using CSS to animate size changes.
* @type {number}
*/
var positionerHeight = "--positioner-height";
// node_modules/@base-ui/react/tooltip/positioner/TooltipPositionerDataAttributes.mjs
var TooltipPositionerDataAttributes_exports = /* @__PURE__ */ __exportAll({
	align: () => align$2,
	anchorHidden: () => anchorHidden,
	closed: () => closed$2,
	open: () => open$2,
	side: () => side$2
});
/**
* Present when the tooltip is open.
*/
var open$2 = open$3;
/**
* Present when the tooltip is closed.
*/
var closed$2 = closed$3;
/**
* Present when the anchor is hidden.
*/
var anchorHidden = anchorHidden$1;
/**
* Indicates which side the popup is positioned relative to the trigger.
* @type {'top' | 'bottom' | 'left' | 'right' | 'inline-end' | 'inline-start'}
*/
var side$2 = side$3;
/**
* Indicates how the popup is aligned relative to specified side.
* @type {'start' | 'center' | 'end'}
*/
var align$2 = align$3;
// node_modules/@base-ui/react/tooltip/popup/TooltipPopupDataAttributes.mjs
var TooltipPopupDataAttributes_exports = /* @__PURE__ */ __exportAll({
	align: () => align$1,
	closed: () => closed$1,
	endingStyle: () => endingStyle,
	instant: () => instant$2,
	open: () => open$1,
	side: () => side$1,
	startingStyle: () => startingStyle
});
/**
* Present when the tooltip is open.
*/
var open$1 = open$3;
/**
* Present when the tooltip is closed.
*/
var closed$1 = closed$3;
/**
* Present when the tooltip begins animating in.
*/
var startingStyle = startingStyle$1;
/**
* Present when the tooltip is animating out.
*/
var endingStyle = endingStyle$1;
/**
* Indicates which side the popup is positioned relative to the trigger.
* @type {'top' | 'bottom' | 'left' | 'right' | 'inline-end' | 'inline-start'}
*/
var side$1 = side$3;
/**
* Indicates how the popup is aligned relative to specified side.
* @type {'start' | 'center' | 'end'}
*/
var align$1 = align$3;
/**
* Present if animations should be instant.
* @type {'delay' | 'dismiss' | 'focus'}
*/
var instant$2 = "data-instant";
// node_modules/@base-ui/react/tooltip/arrow/TooltipArrowDataAttributes.mjs
var TooltipArrowDataAttributes_exports = /* @__PURE__ */ __exportAll({
	align: () => align,
	closed: () => closed,
	instant: () => instant$1,
	open: () => open,
	side: () => side,
	uncentered: () => uncentered
});
/**
* Present when the tooltip is open.
*/
var open = open$3;
/**
* Present when the tooltip is closed.
*/
var closed = closed$3;
/**
* Indicates which side the popup is positioned relative to the trigger.
* @type {'top' | 'bottom' | 'left' | 'right' | 'inline-end' | 'inline-start'}
*/
var side = side$3;
/**
* Indicates how the popup is aligned relative to specified side.
* @type {'start' | 'center' | 'end'}
*/
var align = align$3;
/**
* Present when the tooltip arrow is uncentered.
*/
var uncentered = "data-uncentered";
/**
* Present if animations should be instant.
* @type {'delay' | 'dismiss' | 'focus'}
*/
var instant$1 = "data-instant";
// node_modules/@base-ui/react/tooltip/viewport/TooltipViewportCssVars.mjs
var TooltipViewportCssVars_exports = /* @__PURE__ */ __exportAll({
	popupHeight: () => popupHeight,
	popupWidth: () => popupWidth
});
/**
* The width of the parent popup.
* This variable is placed on the 'previous' container and stores the width of the popup when the previous content was rendered.
* It can be used to freeze the dimensions of the popup when animating between different content.
*/
var popupWidth = "--popup-width";
/**
* The height of the parent popup.
* This variable is placed on the 'previous' container and stores the height of the popup when the previous content was rendered.
* It can be used to freeze the dimensions of the popup when animating between different content.
*/
var popupHeight = "--popup-height";
// node_modules/@base-ui/react/tooltip/viewport/TooltipViewportDataAttributes.mjs
var TooltipViewportDataAttributes_exports = /* @__PURE__ */ __exportAll({
	activationDirection: () => activationDirection,
	current: () => current,
	instant: () => instant,
	previous: () => previous,
	transitioning: () => transitioning
});
/**
* Applied to the direct child of the viewport when no transitions are present or the new content when it's entering.
*/
var current = "data-current";
/**
* Applied to the direct child of the viewport that contains the exiting content when transitions are present.
*/
var previous = "data-previous";
/**
* Indicates the direction from which the popup was activated.
* This can be used to create directional animations based on how the popup was triggered.
* Contains space-separated values for both horizontal and vertical axes.
* @type {`${'left' | 'right' | ''} ${'down' | 'up' | ''}`}
*/
var activationDirection = "data-activation-direction";
/**
* Indicates that the viewport is currently transitioning between old and new content.
*/
var transitioning = "data-transitioning";
/**
* Present if animations should be instant.
* @type {'delay' | 'dismiss' | 'focus'}
*/
var instant = "data-instant";
export { index_parts_exports as Tooltip, TooltipArrowDataAttributes_exports as TooltipArrowDataAttributes, TooltipPopupDataAttributes_exports as TooltipPopupDataAttributes, TooltipPositionerCssVars_exports as TooltipPositionerCssVariables, TooltipPositionerDataAttributes_exports as TooltipPositionerDataAttributes, TooltipTriggerDataAttributes_exports as TooltipTriggerDataAttributes, TooltipViewportCssVars_exports as TooltipViewportCssVariables, TooltipViewportDataAttributes_exports as TooltipViewportDataAttributes };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQGJhc2UtdWlfcmVhY3RfdG9vbHRpcC5qcyIsIm5hbWVzIjpbIlJFQVNPTlMubm9uZSIsIlJFQVNPTlMudHJpZ2dlclByZXNzIiwiZGlzYWJsZWQiLCJSRUFTT05TLmRpc2FibGVkIiwiUkVBU09OUy5pbXBlcmF0aXZlQWN0aW9uIiwiUkVBU09OUy50cmlnZ2VySG92ZXIiLCJUb29sdGlwVHJpZ2dlckRhdGFBdHRyaWJ1dGVzLnRyaWdnZXJEaXNhYmxlZCIsIm9wZW4iLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW4iLCJjbG9zZWQiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmNsb3NlZCIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuYW5jaG9ySGlkZGVuIiwic2lkZSIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuc2lkZSIsImFsaWduIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5hbGlnbiIsIm9wZW4iLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW4iLCJjbG9zZWQiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmNsb3NlZCIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuc3RhcnRpbmdTdHlsZSIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuZW5kaW5nU3R5bGUiLCJzaWRlIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zaWRlIiwiYWxpZ24iLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmFsaWduIiwiaW5zdGFudCIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMub3BlbiIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuY2xvc2VkIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zaWRlIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5hbGlnbiIsImluc3RhbnQiXSwic291cmNlcyI6WyIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC9jb21wb25lbnRzL0Zsb2F0aW5nRGVsYXlHcm91cC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC9ob29rcy91c2VDbGllbnRQb2ludC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC90b29sdGlwL3Jvb3QvVG9vbHRpcFJvb3RDb250ZXh0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3Rvb2x0aXAvc3RvcmUvVG9vbHRpcFN0b3JlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3Rvb2x0aXAvcm9vdC9Ub29sdGlwUm9vdC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC90b29sdGlwL3Byb3ZpZGVyL1Rvb2x0aXBQcm92aWRlckNvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdG9vbHRpcC90cmlnZ2VyL1Rvb2x0aXBUcmlnZ2VyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3Rvb2x0aXAvcG9ydGFsL1Rvb2x0aXBQb3J0YWxDb250ZXh0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3V0aWxzL0Zsb2F0aW5nUG9ydGFsTGl0ZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC90b29sdGlwL3BvcnRhbC9Ub29sdGlwUG9ydGFsLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3Rvb2x0aXAvcG9zaXRpb25lci9Ub29sdGlwUG9zaXRpb25lckNvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdG9vbHRpcC9wb3NpdGlvbmVyL1Rvb2x0aXBQb3NpdGlvbmVyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3Rvb2x0aXAvcG9wdXAvVG9vbHRpcFBvcHVwLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3Rvb2x0aXAvYXJyb3cvVG9vbHRpcEFycm93Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3Rvb2x0aXAvcHJvdmlkZXIvVG9vbHRpcFByb3ZpZGVyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3Rvb2x0aXAvdmlld3BvcnQvVG9vbHRpcFZpZXdwb3J0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3Rvb2x0aXAvc3RvcmUvVG9vbHRpcEhhbmRsZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC90b29sdGlwL2luZGV4LnBhcnRzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3Rvb2x0aXAvcG9zaXRpb25lci9Ub29sdGlwUG9zaXRpb25lckNzc1ZhcnMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdG9vbHRpcC9wb3NpdGlvbmVyL1Rvb2x0aXBQb3NpdGlvbmVyRGF0YUF0dHJpYnV0ZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdG9vbHRpcC9wb3B1cC9Ub29sdGlwUG9wdXBEYXRhQXR0cmlidXRlcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC90b29sdGlwL2Fycm93L1Rvb2x0aXBBcnJvd0RhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3Rvb2x0aXAvdmlld3BvcnQvVG9vbHRpcFZpZXdwb3J0Q3NzVmFycy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC90b29sdGlwL3ZpZXdwb3J0L1Rvb2x0aXBWaWV3cG9ydERhdGFBdHRyaWJ1dGVzLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVRpbWVvdXQsIFRpbWVvdXQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VUaW1lb3V0JztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyBnZXREZWxheSB9IGZyb20gXCIuLi9ob29rcy91c2VIb3ZlclNoYXJlZC5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY3JlYXRlQmFzZVVJRXZlbnREZXRhaWxzLm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5jb25zdCBGbG9hdGluZ0RlbGF5R3JvdXBDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQoe1xuICBoYXNQcm92aWRlcjogZmFsc2UsXG4gIHRpbWVvdXRNczogMCxcbiAgZGVsYXlSZWY6IHtcbiAgICBjdXJyZW50OiAwXG4gIH0sXG4gIGluaXRpYWxEZWxheVJlZjoge1xuICAgIGN1cnJlbnQ6IDBcbiAgfSxcbiAgdGltZW91dDogbmV3IFRpbWVvdXQoKSxcbiAgY3VycmVudElkUmVmOiB7XG4gICAgY3VycmVudDogbnVsbFxuICB9LFxuICBjdXJyZW50Q29udGV4dFJlZjoge1xuICAgIGN1cnJlbnQ6IG51bGxcbiAgfVxufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBGbG9hdGluZ0RlbGF5R3JvdXBDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJGbG9hdGluZ0RlbGF5R3JvdXBDb250ZXh0XCI7XG5mdW5jdGlvbiByZXNldERlbGF5UmVmKGRlbGF5UmVmLCBpbml0aWFsRGVsYXlSZWYpIHtcbiAgZGVsYXlSZWYuY3VycmVudCA9IGluaXRpYWxEZWxheVJlZi5jdXJyZW50O1xufVxuLyoqXG4gKiBFeHBlcmltZW50YWwgbmV4dCB2ZXJzaW9uIG9mIGBGbG9hdGluZ0RlbGF5R3JvdXBgIHRvIGJlY29tZSB0aGUgZGVmYXVsdFxuICogaW4gdGhlIGZ1dHVyZS4gVGhpcyBjb21wb25lbnQgaXMgbm90IHlldCBzdGFibGUuXG4gKiBQcm92aWRlcyBjb250ZXh0IGZvciBhIGdyb3VwIG9mIGZsb2F0aW5nIGVsZW1lbnRzIHRoYXQgc2hvdWxkIHNoYXJlIGFcbiAqIGBkZWxheWAuIFVubGlrZSBgRmxvYXRpbmdEZWxheUdyb3VwYCwgYHVzZURlbGF5R3JvdXBgIHdpdGggdGhpc1xuICogY29tcG9uZW50IGRvZXMgbm90IGNhdXNlIGEgcmUtcmVuZGVyIG9mIHVucmVsYXRlZCBjb25zdW1lcnMgb2YgdGhlXG4gKiBjb250ZXh0IHdoZW4gdGhlIGRlbGF5IGNoYW5nZXMuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvRmxvYXRpbmdEZWxheUdyb3VwXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEZsb2F0aW5nRGVsYXlHcm91cChwcm9wcykge1xuICBjb25zdCB7XG4gICAgY2hpbGRyZW4sXG4gICAgZGVsYXksXG4gICAgdGltZW91dE1zID0gMFxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IGRlbGF5UmVmID0gUmVhY3QudXNlUmVmKGRlbGF5KTtcbiAgY29uc3QgaW5pdGlhbERlbGF5UmVmID0gUmVhY3QudXNlUmVmKGRlbGF5KTtcbiAgY29uc3QgY3VycmVudElkUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBjdXJyZW50Q29udGV4dFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgdGltZW91dCA9IHVzZVRpbWVvdXQoKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpbml0aWFsRGVsYXlSZWYuY3VycmVudCA9IGRlbGF5O1xuICAgIGlmICghY3VycmVudElkUmVmLmN1cnJlbnQpIHtcbiAgICAgIGRlbGF5UmVmLmN1cnJlbnQgPSBkZWxheTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgZGVsYXlSZWYuY3VycmVudCA9IHtcbiAgICAgIG9wZW46IGdldERlbGF5KGRlbGF5UmVmLmN1cnJlbnQsICdvcGVuJyksXG4gICAgICBjbG9zZTogZ2V0RGVsYXkoZGVsYXksICdjbG9zZScpXG4gICAgfTtcbiAgfSwgW2RlbGF5LCBjdXJyZW50SWRSZWYsIGRlbGF5UmVmLCBpbml0aWFsRGVsYXlSZWZdKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KEZsb2F0aW5nRGVsYXlHcm91cENvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgICAgaGFzUHJvdmlkZXI6IHRydWUsXG4gICAgICBkZWxheVJlZixcbiAgICAgIGluaXRpYWxEZWxheVJlZixcbiAgICAgIGN1cnJlbnRJZFJlZixcbiAgICAgIHRpbWVvdXRNcyxcbiAgICAgIGN1cnJlbnRDb250ZXh0UmVmLFxuICAgICAgdGltZW91dFxuICAgIH0pLCBbdGltZW91dE1zLCB0aW1lb3V0XSksXG4gICAgY2hpbGRyZW46IGNoaWxkcmVuXG4gIH0pO1xufVxuLyoqXG4gKiBFbmFibGVzIGdyb3VwaW5nIHdoZW4gY2FsbGVkIGluc2lkZSBhIGNvbXBvbmVudCB0aGF0J3MgYSBjaGlsZCBvZiBhXG4gKiBgRmxvYXRpbmdEZWxheUdyb3VwYC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9GbG9hdGluZ0RlbGF5R3JvdXBcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlRGVsYXlHcm91cChzdG9yZSwgb3B0aW9ucyA9IHtcbiAgb3BlbjogZmFsc2Vcbn0pIHtcbiAgY29uc3Qge1xuICAgIG9wZW5cbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGZsb2F0aW5nSWQgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdJZCcpO1xuICBjb25zdCBncm91cENvbnRleHQgPSBSZWFjdC51c2VDb250ZXh0KEZsb2F0aW5nRGVsYXlHcm91cENvbnRleHQpO1xuICBjb25zdCB7XG4gICAgY3VycmVudElkUmVmLFxuICAgIGRlbGF5UmVmLFxuICAgIHRpbWVvdXRNcyxcbiAgICBpbml0aWFsRGVsYXlSZWYsXG4gICAgY3VycmVudENvbnRleHRSZWYsXG4gICAgaGFzUHJvdmlkZXIsXG4gICAgdGltZW91dFxuICB9ID0gZ3JvdXBDb250ZXh0O1xuICBjb25zdCBbaXNJbnN0YW50UGhhc2UsIHNldElzSW5zdGFudFBoYXNlXSA9IFJlYWN0LnVzZVN0YXRlKGZhbHNlKTtcbiAgY29uc3Qgb3BlblJlZiA9IFJlYWN0LnVzZVJlZihvcGVuKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBvcGVuUmVmLmN1cnJlbnQgPSBvcGVuO1xuICB9LCBbb3Blbl0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGZ1bmN0aW9uIHVuc2V0KCkge1xuICAgICAgY3VycmVudENvbnRleHRSZWYuY3VycmVudD8uc2V0SXNJbnN0YW50UGhhc2UoZmFsc2UpO1xuICAgICAgY3VycmVudElkUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgY3VycmVudENvbnRleHRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICBkZWxheVJlZi5jdXJyZW50ID0gaW5pdGlhbERlbGF5UmVmLmN1cnJlbnQ7XG4gICAgICB0aW1lb3V0LmNsZWFyKCk7XG4gICAgfVxuICAgIGlmICghY3VycmVudElkUmVmLmN1cnJlbnQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGlmICghb3BlbiAmJiBjdXJyZW50SWRSZWYuY3VycmVudCA9PT0gZmxvYXRpbmdJZCkge1xuICAgICAgc2V0SXNJbnN0YW50UGhhc2UoZmFsc2UpO1xuICAgICAgaWYgKHRpbWVvdXRNcykge1xuICAgICAgICBjb25zdCBjbG9zaW5nSWQgPSBmbG9hdGluZ0lkO1xuICAgICAgICB0aW1lb3V0LnN0YXJ0KHRpbWVvdXRNcywgKCkgPT4ge1xuICAgICAgICAgIC8vIElmIGFub3RoZXIgdG9vbHRpcCBoYXMgdGFrZW4gb3ZlciB0aGUgZ3JvdXAsIHNraXAgcmVzZXR0aW5nLlxuICAgICAgICAgIGlmIChzdG9yZS5zZWxlY3QoJ29wZW4nKSB8fCBjdXJyZW50SWRSZWYuY3VycmVudCAmJiBjdXJyZW50SWRSZWYuY3VycmVudCAhPT0gY2xvc2luZ0lkKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgfVxuICAgICAgICAgIHVuc2V0KCk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgIGlmIChvcGVuUmVmLmN1cnJlbnQgfHwgY3VycmVudElkUmVmLmN1cnJlbnQgIT09IGNsb3NpbmdJZCkge1xuICAgICAgICAgICAgdGltZW91dC5jbGVhcigpO1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHVuc2V0KCk7XG4gICAgfVxuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH0sIFtvcGVuLCBmbG9hdGluZ0lkLCBjdXJyZW50SWRSZWYsIGRlbGF5UmVmLCB0aW1lb3V0TXMsIGluaXRpYWxEZWxheVJlZiwgY3VycmVudENvbnRleHRSZWYsIHRpbWVvdXQsIHN0b3JlXSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHByZXZDb250ZXh0ID0gY3VycmVudENvbnRleHRSZWYuY3VycmVudDtcbiAgICBjb25zdCBwcmV2SWQgPSBjdXJyZW50SWRSZWYuY3VycmVudDtcblxuICAgIC8vIEEgbmV3IHRvb2x0aXAgaXMgb3BlbmluZywgc28gY2FuY2VsIGFueSBwZW5kaW5nIHRpbWVvdXQgdGhhdCB3b3VsZCByZXNldFxuICAgIC8vIHRoZSBncm91cCdzIGRlbGF5IGJhY2sgdG8gdGhlIGluaXRpYWwgdmFsdWUuXG4gICAgdGltZW91dC5jbGVhcigpO1xuICAgIGN1cnJlbnRDb250ZXh0UmVmLmN1cnJlbnQgPSB7XG4gICAgICBvbk9wZW5DaGFuZ2U6IHN0b3JlLnNldE9wZW4sXG4gICAgICBzZXRJc0luc3RhbnRQaGFzZVxuICAgIH07XG4gICAgY3VycmVudElkUmVmLmN1cnJlbnQgPSBmbG9hdGluZ0lkO1xuICAgIGRlbGF5UmVmLmN1cnJlbnQgPSB7XG4gICAgICBvcGVuOiAwLFxuICAgICAgY2xvc2U6IGdldERlbGF5KGluaXRpYWxEZWxheVJlZi5jdXJyZW50LCAnY2xvc2UnKVxuICAgIH07XG4gICAgaWYgKHByZXZJZCAhPT0gbnVsbCAmJiBwcmV2SWQgIT09IGZsb2F0aW5nSWQpIHtcbiAgICAgIHNldElzSW5zdGFudFBoYXNlKHRydWUpO1xuICAgICAgcHJldkNvbnRleHQ/LnNldElzSW5zdGFudFBoYXNlKHRydWUpO1xuICAgICAgcHJldkNvbnRleHQ/Lm9uT3BlbkNoYW5nZShmYWxzZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMubm9uZSkpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRJc0luc3RhbnRQaGFzZShmYWxzZSk7XG4gICAgICBwcmV2Q29udGV4dD8uc2V0SXNJbnN0YW50UGhhc2UoZmFsc2UpO1xuICAgIH1cbiAgfSwgW29wZW4sIGZsb2F0aW5nSWQsIHN0b3JlLCBjdXJyZW50SWRSZWYsIGRlbGF5UmVmLCBpbml0aWFsRGVsYXlSZWYsIGN1cnJlbnRDb250ZXh0UmVmLCB0aW1lb3V0XSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGlmIChjdXJyZW50SWRSZWYuY3VycmVudCA9PT0gZmxvYXRpbmdJZCkge1xuICAgICAgICBjdXJyZW50Q29udGV4dFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgaWYgKCFvcGVuUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY3VycmVudElkUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgICByZXNldERlbGF5UmVmKGRlbGF5UmVmLCBpbml0aWFsRGVsYXlSZWYpO1xuICAgICAgICB0aW1lb3V0LmNsZWFyKCk7XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW2N1cnJlbnRDb250ZXh0UmVmLCBjdXJyZW50SWRSZWYsIGRlbGF5UmVmLCBmbG9hdGluZ0lkLCBpbml0aWFsRGVsYXlSZWYsIHRpbWVvdXRdKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBhY3RpdmVJZFJlZjogY3VycmVudElkUmVmLFxuICAgIGhhc1Byb3ZpZGVyLFxuICAgIGRlbGF5UmVmLFxuICAgIGlzSW5zdGFudFBoYXNlXG4gIH0pLCBbY3VycmVudElkUmVmLCBoYXNQcm92aWRlciwgZGVsYXlSZWYsIGlzSW5zdGFudFBoYXNlXSk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBhZGRFdmVudExpc3RlbmVyIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvYWRkRXZlbnRMaXN0ZW5lcic7XG5pbXBvcnQgeyB1c2VTdGFibGVDYWxsYmFjayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrJztcbmltcG9ydCB7IGdldFdpbmRvdyB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuaW1wb3J0IHsgY29udGFpbnMsIGdldFRhcmdldCB9IGZyb20gXCIuLi91dGlscy9lbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgaXNNb3VzZUxpa2VQb2ludGVyVHlwZSB9IGZyb20gXCIuLi91dGlscy9ldmVudC5tanNcIjtcbmZ1bmN0aW9uIGNyZWF0ZVZpcnR1YWxFbGVtZW50KGRvbUVsZW1lbnQsIGRhdGEpIHtcbiAgbGV0IG9mZnNldFggPSBudWxsO1xuICBsZXQgb2Zmc2V0WSA9IG51bGw7XG4gIGxldCBpc0F1dG9VcGRhdGVFdmVudCA9IGZhbHNlO1xuICByZXR1cm4ge1xuICAgIGNvbnRleHRFbGVtZW50OiBkb21FbGVtZW50IHx8IHVuZGVmaW5lZCxcbiAgICBnZXRCb3VuZGluZ0NsaWVudFJlY3QoKSB7XG4gICAgICBjb25zdCBkb21SZWN0ID0gZG9tRWxlbWVudD8uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkgfHwge1xuICAgICAgICB3aWR0aDogMCxcbiAgICAgICAgaGVpZ2h0OiAwLFxuICAgICAgICB4OiAwLFxuICAgICAgICB5OiAwXG4gICAgICB9O1xuICAgICAgY29uc3QgaXNYQXhpcyA9IGRhdGEuYXhpcyA9PT0gJ3gnIHx8IGRhdGEuYXhpcyA9PT0gJ2JvdGgnO1xuICAgICAgY29uc3QgaXNZQXhpcyA9IGRhdGEuYXhpcyA9PT0gJ3knIHx8IGRhdGEuYXhpcyA9PT0gJ2JvdGgnO1xuICAgICAgY29uc3QgY2FuVHJhY2tDdXJzb3JPbkF1dG9VcGRhdGUgPSBbJ21vdXNlZW50ZXInLCAnbW91c2Vtb3ZlJ10uaW5jbHVkZXMoZGF0YS5kYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50Py50eXBlIHx8ICcnKSAmJiBkYXRhLnBvaW50ZXJUeXBlICE9PSAndG91Y2gnO1xuICAgICAgY29uc3Qgd2lkdGggPSBkYXRhLmF4aXMgPT09ICd5JyA/IGRvbVJlY3Qud2lkdGggOiAwO1xuICAgICAgY29uc3QgaGVpZ2h0ID0gZGF0YS5heGlzID09PSAneCcgPyBkb21SZWN0LmhlaWdodCA6IDA7XG4gICAgICBsZXQgeCA9IGRvbVJlY3QueDtcbiAgICAgIGxldCB5ID0gZG9tUmVjdC55O1xuICAgICAgaWYgKG9mZnNldFggPT0gbnVsbCAmJiBkYXRhLnggJiYgaXNYQXhpcykge1xuICAgICAgICBvZmZzZXRYID0gZG9tUmVjdC54IC0gZGF0YS54O1xuICAgICAgfVxuICAgICAgaWYgKG9mZnNldFkgPT0gbnVsbCAmJiBkYXRhLnkgJiYgaXNZQXhpcykge1xuICAgICAgICBvZmZzZXRZID0gZG9tUmVjdC55IC0gZGF0YS55O1xuICAgICAgfVxuICAgICAgeCAtPSBvZmZzZXRYIHx8IDA7XG4gICAgICB5IC09IG9mZnNldFkgfHwgMDtcbiAgICAgIGlmICghaXNBdXRvVXBkYXRlRXZlbnQgfHwgY2FuVHJhY2tDdXJzb3JPbkF1dG9VcGRhdGUpIHtcbiAgICAgICAgeCA9IGlzWEF4aXMgJiYgZGF0YS54ICE9IG51bGwgPyBkYXRhLnggOiB4O1xuICAgICAgICB5ID0gaXNZQXhpcyAmJiBkYXRhLnkgIT0gbnVsbCA/IGRhdGEueSA6IHk7XG4gICAgICB9XG4gICAgICBpc0F1dG9VcGRhdGVFdmVudCA9IHRydWU7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB3aWR0aCxcbiAgICAgICAgaGVpZ2h0LFxuICAgICAgICB4LFxuICAgICAgICB5LFxuICAgICAgICB0b3A6IHksXG4gICAgICAgIHJpZ2h0OiB4ICsgd2lkdGgsXG4gICAgICAgIGJvdHRvbTogeSArIGhlaWdodCxcbiAgICAgICAgbGVmdDogeFxuICAgICAgfTtcbiAgICB9XG4gIH07XG59XG5mdW5jdGlvbiBpc01vdXNlQmFzZWRFdmVudChldmVudCkge1xuICByZXR1cm4gZXZlbnQgIT0gbnVsbCAmJiBldmVudC5jbGllbnRYICE9IG51bGw7XG59XG4vKipcbiAqIFBvc2l0aW9ucyB0aGUgZmxvYXRpbmcgZWxlbWVudCByZWxhdGl2ZSB0byBhIGNsaWVudCBwb2ludCAoaW4gdGhlIHZpZXdwb3J0KSxcbiAqIHN1Y2ggYXMgdGhlIG1vdXNlIHBvc2l0aW9uLiBCeSBkZWZhdWx0LCBpdCBmb2xsb3dzIHRoZSBtb3VzZSBjdXJzb3IuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlQ2xpZW50UG9pbnRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUNsaWVudFBvaW50KHN0b3JlLCBwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBlbmFibGVkID0gdHJ1ZSxcbiAgICBheGlzID0gJ2JvdGgnXG4gIH0gPSBwcm9wcztcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IGZsb2F0aW5nID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nRWxlbWVudCcpO1xuICBjb25zdCBkb21SZWZlcmVuY2UgPSBzdG9yZS51c2VTdGF0ZSgnZG9tUmVmZXJlbmNlRWxlbWVudCcpO1xuICBjb25zdCBkYXRhUmVmID0gc3RvcmUuY29udGV4dC5kYXRhUmVmO1xuICBjb25zdCBpbml0aWFsUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgY2xlYW51cExpc3RlbmVyUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBbcG9pbnRlclR5cGUsIHNldFBvaW50ZXJUeXBlXSA9IFJlYWN0LnVzZVN0YXRlKCk7XG4gIGNvbnN0IFtyZWFjdGl2ZSwgc2V0UmVhY3RpdmVdID0gUmVhY3QudXNlU3RhdGUoW10pO1xuICBjb25zdCByZXNldFJlZmVyZW5jZSA9IHVzZVN0YWJsZUNhbGxiYWNrKHJlZmVyZW5jZSA9PiB7XG4gICAgc3RvcmUuc2V0KCdwb3NpdGlvblJlZmVyZW5jZScsIHJlZmVyZW5jZSk7XG4gIH0pO1xuICBjb25zdCBzZXRSZWZlcmVuY2UgPSB1c2VTdGFibGVDYWxsYmFjaygobmV3WCwgbmV3WSwgcmVmZXJlbmNlRWxlbWVudCkgPT4ge1xuICAgIGlmIChpbml0aWFsUmVmLmN1cnJlbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBQcmV2ZW50IHNldHRpbmcgaWYgdGhlIG9wZW4gZXZlbnQgd2FzIG5vdCBhIG1vdXNlLWxpa2Ugb25lXG4gICAgLy8gKGUuZy4gZm9jdXMgdG8gb3BlbiwgdGhlbiBob3ZlciBvdmVyIHRoZSByZWZlcmVuY2UgZWxlbWVudCkuXG4gICAgLy8gT25seSBhcHBseSBpZiB0aGUgZXZlbnQgZXhpc3RzLlxuICAgIGlmIChkYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50ICYmICFpc01vdXNlQmFzZWRFdmVudChkYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50KSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzdG9yZS5zZXQoJ3Bvc2l0aW9uUmVmZXJlbmNlJywgY3JlYXRlVmlydHVhbEVsZW1lbnQocmVmZXJlbmNlRWxlbWVudCA/PyBkb21SZWZlcmVuY2UsIHtcbiAgICAgIHg6IG5ld1gsXG4gICAgICB5OiBuZXdZLFxuICAgICAgYXhpcyxcbiAgICAgIGRhdGFSZWYsXG4gICAgICBwb2ludGVyVHlwZVxuICAgIH0pKTtcbiAgfSk7XG4gIGNvbnN0IGhhbmRsZVJlZmVyZW5jZUVudGVyT3JNb3ZlID0gdXNlU3RhYmxlQ2FsbGJhY2soZXZlbnQgPT4ge1xuICAgIGlmICghb3Blbikge1xuICAgICAgc2V0UmVmZXJlbmNlKGV2ZW50LmNsaWVudFgsIGV2ZW50LmNsaWVudFksIGV2ZW50LmN1cnJlbnRUYXJnZXQpO1xuICAgIH0gZWxzZSBpZiAoIWNsZWFudXBMaXN0ZW5lclJlZi5jdXJyZW50KSB7XG4gICAgICAvLyBJZiB0aGVyZSdzIG5vIGNsZWFudXAsIHRoZXJlJ3Mgbm8gbGlzdGVuZXIsIGJ1dCB3ZSB3YW50IHRvIGVuc3VyZVxuICAgICAgLy8gd2UgYWRkIHRoZSBsaXN0ZW5lciBpZiB0aGUgY3Vyc29yIGxhbmRlZCBvbiB0aGUgZmxvYXRpbmcgZWxlbWVudCBhbmRcbiAgICAgIC8vIHRoZW4gYmFjayBvbiB0aGUgcmVmZXJlbmNlIChpLmUuIGl0J3MgaW50ZXJhY3RpdmUpLlxuICAgICAgc2V0UmVmZXJlbmNlKGV2ZW50LmNsaWVudFgsIGV2ZW50LmNsaWVudFksIGV2ZW50LmN1cnJlbnRUYXJnZXQpO1xuICAgICAgc2V0UmVhY3RpdmUoW10pO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gSWYgdGhlIHBvaW50ZXIgaXMgYSBtb3VzZS1saWtlIHBvaW50ZXIsIHdlIHdhbnQgdG8gY29udGludWUgZm9sbG93aW5nIHRoZVxuICAvLyBtb3VzZSBldmVuIGlmIHRoZSBmbG9hdGluZyBlbGVtZW50IGlzIHRyYW5zaXRpb25pbmcgb3V0LiBPbiB0b3VjaFxuICAvLyBkZXZpY2VzLCB0aGlzIGlzIHVuZGVzaXJhYmxlIGJlY2F1c2UgdGhlIGZsb2F0aW5nIGVsZW1lbnQgd2lsbCBtb3ZlIHRvXG4gIC8vIHRoZSBkaXNtaXNzYWwgdG91Y2ggcG9pbnQuXG4gIGNvbnN0IG9wZW5DaGVjayA9IGlzTW91c2VMaWtlUG9pbnRlclR5cGUocG9pbnRlclR5cGUpID8gZmxvYXRpbmcgOiBvcGVuO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCkge1xuICAgICAgcmVzZXRSZWZlcmVuY2UoZG9tUmVmZXJlbmNlKTtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGlmICghb3BlbkNoZWNrKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBmdW5jdGlvbiBjbGVhbnVwTGlzdGVuZXIoKSB7XG4gICAgICBjbGVhbnVwTGlzdGVuZXJSZWYuY3VycmVudD8uKCk7XG4gICAgICBjbGVhbnVwTGlzdGVuZXJSZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICAgIGNvbnN0IHdpbiA9IGdldFdpbmRvdyhmbG9hdGluZyk7XG4gICAgZnVuY3Rpb24gaGFuZGxlTW91c2VNb3ZlKGV2ZW50KSB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQpO1xuICAgICAgaWYgKCFjb250YWlucyhmbG9hdGluZywgdGFyZ2V0KSkge1xuICAgICAgICBzZXRSZWZlcmVuY2UoZXZlbnQuY2xpZW50WCwgZXZlbnQuY2xpZW50WSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjbGVhbnVwTGlzdGVuZXIoKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFkYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50IHx8IGlzTW91c2VCYXNlZEV2ZW50KGRhdGFSZWYuY3VycmVudC5vcGVuRXZlbnQpKSB7XG4gICAgICBjbGVhbnVwTGlzdGVuZXJSZWYuY3VycmVudCA9IGFkZEV2ZW50TGlzdGVuZXIod2luLCAnbW91c2Vtb3ZlJywgaGFuZGxlTW91c2VNb3ZlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmVzZXRSZWZlcmVuY2UoZG9tUmVmZXJlbmNlKTtcbiAgICB9XG4gICAgcmV0dXJuIGNsZWFudXBMaXN0ZW5lcjtcbiAgfSwgW29wZW5DaGVjaywgZW5hYmxlZCwgZmxvYXRpbmcsIGRhdGFSZWYsIGRvbVJlZmVyZW5jZSwgc3RvcmUsIHNldFJlZmVyZW5jZSwgcmVzZXRSZWZlcmVuY2UsIHJlYWN0aXZlXSk7XG5cbiAgLy8gQ2xlYXIgdmlydHVhbCBjdXJzb3IgcmVmZXJlbmNlcyB3aGVuIHRoZSBob29rIHVubW91bnRzLiBFbmFibGVkIGZsaXBzIGFyZSBoYW5kbGVkIGFib3ZlLlxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4gKCkgPT4ge1xuICAgIHN0b3JlLnNldCgncG9zaXRpb25SZWZlcmVuY2UnLCBudWxsKTtcbiAgfSwgW3N0b3JlXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGVuYWJsZWQgJiYgIWZsb2F0aW5nKSB7XG4gICAgICBpbml0aWFsUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICB9XG4gIH0sIFtlbmFibGVkLCBmbG9hdGluZ10pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCAmJiBvcGVuKSB7XG4gICAgICBpbml0aWFsUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIH1cbiAgfSwgW2VuYWJsZWQsIG9wZW5dKTtcbiAgY29uc3QgcmVmZXJlbmNlID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgZnVuY3Rpb24gc2V0UG9pbnRlclR5cGVSZWYoZXZlbnQpIHtcbiAgICAgIHNldFBvaW50ZXJUeXBlKGV2ZW50LnBvaW50ZXJUeXBlKTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIG9uUG9pbnRlckRvd246IHNldFBvaW50ZXJUeXBlUmVmLFxuICAgICAgb25Qb2ludGVyRW50ZXI6IHNldFBvaW50ZXJUeXBlUmVmLFxuICAgICAgb25Nb3VzZU1vdmU6IGhhbmRsZVJlZmVyZW5jZUVudGVyT3JNb3ZlLFxuICAgICAgb25Nb3VzZUVudGVyOiBoYW5kbGVSZWZlcmVuY2VFbnRlck9yTW92ZVxuICAgIH07XG4gIH0sIFtoYW5kbGVSZWZlcmVuY2VFbnRlck9yTW92ZV0pO1xuICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiBlbmFibGVkID8ge1xuICAgIHJlZmVyZW5jZSxcbiAgICB0cmlnZ2VyOiByZWZlcmVuY2VcbiAgfSA6IHt9LCBbZW5hYmxlZCwgcmVmZXJlbmNlXSk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgX2Zvcm1hdEVycm9yTWVzc2FnZSBmcm9tIFwiQGJhc2UtdWkvdXRpbHMvZm9ybWF0RXJyb3JNZXNzYWdlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgVG9vbHRpcFJvb3RDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFRvb2x0aXBSb290Q29udGV4dC5kaXNwbGF5TmFtZSA9IFwiVG9vbHRpcFJvb3RDb250ZXh0XCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlVG9vbHRpcFJvb3RDb250ZXh0KG9wdGlvbmFsKSB7XG4gIGNvbnN0IGNvbnRleHQgPSBSZWFjdC51c2VDb250ZXh0KFRvb2x0aXBSb290Q29udGV4dCk7XG4gIGlmIChjb250ZXh0ID09PSB1bmRlZmluZWQgJiYgIW9wdGlvbmFsKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/ICdCYXNlIFVJOiBUb29sdGlwUm9vdENvbnRleHQgaXMgbWlzc2luZy4gVG9vbHRpcCBwYXJ0cyBtdXN0IGJlIHBsYWNlZCB3aXRoaW4gPFRvb2x0aXAuUm9vdD4uJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoNzIpKTtcbiAgfVxuICByZXR1cm4gY29udGV4dDtcbn0iLCJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBSZWFjdFN0b3JlIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvc3RvcmUnO1xuaW1wb3J0IHsgTk9PUCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2VtcHR5JztcbmltcG9ydCB7IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY3JlYXRlQmFzZVVJRXZlbnREZXRhaWxzLm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcbmltcG9ydCB7IE51bGxTdG9yZSB9IGZyb20gXCIuLi8uLi91dGlscy9OdWxsU3RvcmUubWpzXCI7XG5pbXBvcnQgeyBhcHBseVBvcHVwT3BlbkNoYW5nZSwgY3JlYXRlSW5pdGlhbFBvcHVwU3RvcmVTdGF0ZSwgcG9wdXBTdG9yZVNlbGVjdG9ycywgUG9wdXBUcmlnZ2VyTWFwIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwcy9pbmRleC5tanNcIjtcbmNvbnN0IHNlbGVjdG9ycyA9IHtcbiAgLi4ucG9wdXBTdG9yZVNlbGVjdG9ycyxcbiAgZGlzYWJsZWQ6IHN0YXRlID0+IHN0YXRlLmRpc2FibGVkLFxuICBpbnN0YW50VHlwZTogc3RhdGUgPT4gc3RhdGUuaW5zdGFudFR5cGUsXG4gIGlzSW5zdGFudFBoYXNlOiBzdGF0ZSA9PiBzdGF0ZS5pc0luc3RhbnRQaGFzZSxcbiAgdHJhY2tDdXJzb3JBeGlzOiBzdGF0ZSA9PiBzdGF0ZS50cmFja0N1cnNvckF4aXMsXG4gIGRpc2FibGVIb3ZlcmFibGVQb3B1cDogc3RhdGUgPT4gc3RhdGUuZGlzYWJsZUhvdmVyYWJsZVBvcHVwLFxuICBsYXN0T3BlbkNoYW5nZVJlYXNvbjogc3RhdGUgPT4gc3RhdGUub3BlbkNoYW5nZVJlYXNvbixcbiAgY2xvc2VPbkNsaWNrOiBzdGF0ZSA9PiBzdGF0ZS5jbG9zZU9uQ2xpY2ssXG4gIC8vIEFjdGl2ZSBhbmQgaW5hY3RpdmUgdHJpZ2dlciBwcm9wcyBhcmUgdGhlIHNhbWUgb2JqZWN0LCBzbyBhIGNvbnN0YW50IGZvciB0cmlnZ2VycyB0aGF0IGRpc2NhcmRcbiAgLy8gdGhlbSBrZWVwcyB0aG9zZSB0cmlnZ2VycyBmcm9tIHJlLXJlbmRlcmluZyB3aGVuIHRoZSBwcm9wcyBjaGFuZ2UuXG4gIGFwcGxpZWRUcmlnZ2VyUHJvcHM6IChzdGF0ZSwgYXBwbHkpID0+IGFwcGx5ID8gc3RhdGUuYWN0aXZlVHJpZ2dlclByb3BzIDogdW5kZWZpbmVkLFxuICBjbG9zZURlbGF5OiBzdGF0ZSA9PiBzdGF0ZS5jbG9zZURlbGF5LFxuICBhZGFwdGl2ZU9yaWdpbjogc3RhdGUgPT4gc3RhdGUuYWRhcHRpdmVPcmlnaW5cbn07XG5cbi8qKlxuICogVGhlIHN0b3JlIHZpZXcgdGhhdCBkZXRhY2hlZCBoYW5kbGUtYmFja2VkIHRyaWdnZXJzIHJlYWQgZnJvbS4gQm90aCB0aGUgcmVhbCBgVG9vbHRpcFN0b3JlYCBhbmRcbiAqIHRoZSBpbmVydCBmYWxsYmFjayBzdG9yZSBzYXRpc2Z5IGl0LCBzbyBhIHRyaWdnZXIgY2FuIHJlYWQgZnJvbSB3aGljaGV2ZXIgc3RvcmUgdGhlIGhhbmRsZVxuICogY3VycmVudGx5IGV4cG9zZXMuIE5hcnJvd2VkIHRvIHRoZSBtZW1iZXJzIGEgdHJpZ2dlciBhY3R1YWxseSB1c2VzIOKAlCB0aGUgdHJpZ2dlci1kYXRhIG1lbWJlcnMgcGx1c1xuICogYHNldE9wZW5gL2BjYW5jZWxQZW5kaW5nT3BlbmAgKGNhbGxlZCBkaXJlY3RseSBieSB0aGUgdHJpZ2dlcikgYW5kIGB1c2VTeW5jZWRWYWx1ZWAg4oCUIHNvIHRoZVxuICogZXhwb3NlZCBzdXJmYWNlIGNhbid0IGJ5cGFzcyB0aGUgb3Blbi1jaGFuZ2UgcGlwZWxpbmU7IG9uIHRoZSBkZXRhY2hlZCBmYWxsYmFjayBzdG9yZSBldmVyeSBvbmUgb2ZcbiAqIHRoZXNlIG11dGF0aW9ucyBpcyBhIG5vLW9wLlxuICovXG5cbmV4cG9ydCBjbGFzcyBUb29sdGlwU3RvcmUgZXh0ZW5kcyBSZWFjdFN0b3JlIHtcbiAgY29uc3RydWN0b3IoaW5pdGlhbFN0YXRlLCBmbG9hdGluZ0lkLCBuZXN0ZWQpIHtcbiAgICBjb25zdCB0cmlnZ2VyRWxlbWVudHMgPSBuZXcgUG9wdXBUcmlnZ2VyTWFwKCk7XG4gICAgc3VwZXIoY3JlYXRlSW5pdGlhbFN0YXRlKGluaXRpYWxTdGF0ZSwgdHJpZ2dlckVsZW1lbnRzLCBmbG9hdGluZ0lkLCBuZXN0ZWQpLCBjcmVhdGVJbml0aWFsQ29udGV4dCh0cmlnZ2VyRWxlbWVudHMpLCBzZWxlY3RvcnMpO1xuICB9XG4gIHNldE9wZW4gPSAobmV4dE9wZW4sIGV2ZW50RGV0YWlscykgPT4ge1xuICAgIGFwcGx5UG9wdXBPcGVuQ2hhbmdlKHRoaXMsIG5leHRPcGVuLCBldmVudERldGFpbHMsIHtcbiAgICAgIGV4dHJhU3RhdGU6IHtcbiAgICAgICAgb3BlbkNoYW5nZVJlYXNvbjogZXZlbnREZXRhaWxzLnJlYXNvblxuICAgICAgfVxuICAgIH0pO1xuICB9O1xuXG4gIC8vIFVzZWQgYnkgdHJpZ2dlciBjbGlja3MgdG8gY2xlYXIgYSBkZWxheWVkIGhvdmVyIG9wZW4gd2l0aG91dCByZXBvcnRpbmcgYSBwdWJsaWMgb3Blbi1zdGF0ZSBjaGFuZ2UuXG4gIGNhbmNlbFBlbmRpbmdPcGVuKGV2ZW50KSB7XG4gICAgdGhpcy5zdGF0ZS5mbG9hdGluZ1Jvb3RDb250ZXh0LmRpc3BhdGNoT3BlbkNoYW5nZShmYWxzZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMudHJpZ2dlclByZXNzLCBldmVudCkpO1xuICB9XG59XG5cbi8qKlxuICogQ3JlYXRlcyB0aGUgaW5lcnQgZmFsbGJhY2sgc3RvcmUgdXNlZCBieSBkZXRhY2hlZCBoYW5kbGUtYmFja2VkIHRyaWdnZXJzIHdoaWxlIG5vIGBUb29sdGlwLlJvb3RgXG4gKiBpcyBhdHRhY2hlZC4gSXQgcHJlc2VydmVzIGEgdG9vbHRpcC1zcGVjaWZpYyB0cmlnZ2VyIHJlZ2lzdHJ5IGluIGNvbnRleHQgc28gZGV0YWNoZWQgdHJpZ2dlcnMgY2FuXG4gKiByZWdpc3RlciBiZWZvcmUgbWlncmF0aW5nIHRvIHRoZSBsaXZlIHJvb3Qgc3RvcmUuIGBzZXRPcGVuYC9gY2FuY2VsUGVuZGluZ09wZW5gIGFyZSBuby1vcHNcbiAqIChtYXRjaGluZyB0aGUgaW5lcnQgcmVhZHMvd3JpdGVzIG9mIGBOdWxsU3RvcmVgKSwgc28gYSB0cmlnZ2VyIGNhbiBjYWxsIHRoZW0gZnJvbSBob3Zlci9jbGlja1xuICogaGFuZGxlcnMgd2hpbGUgZGV0YWNoZWQgd2l0aG91dCBhbnkgZWZmZWN0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlTnVsbFRvb2x0aXBTdG9yZSgpIHtcbiAgY29uc3QgdHJpZ2dlckVsZW1lbnRzID0gbmV3IFBvcHVwVHJpZ2dlck1hcCgpO1xuICBjb25zdCBzdG9yZSA9IG5ldyBOdWxsU3RvcmUoT2JqZWN0LmZyZWV6ZShjcmVhdGVJbml0aWFsU3RhdGUodW5kZWZpbmVkLCB0cmlnZ2VyRWxlbWVudHMpKSwgT2JqZWN0LmZyZWV6ZShjcmVhdGVJbml0aWFsQ29udGV4dCh0cmlnZ2VyRWxlbWVudHMpKSwgc2VsZWN0b3JzKTtcbiAgcmV0dXJuIE9iamVjdC5hc3NpZ24oc3RvcmUsIHtcbiAgICBzZXRPcGVuOiBOT09QLFxuICAgIGNhbmNlbFBlbmRpbmdPcGVuOiBOT09QXG4gIH0pO1xufVxuZnVuY3Rpb24gY3JlYXRlSW5pdGlhbFN0YXRlKGluaXRpYWxTdGF0ZSwgdHJpZ2dlckVsZW1lbnRzLCBmbG9hdGluZ0lkLCBuZXN0ZWQgPSBmYWxzZSkge1xuICBjb25zdCBzdGF0ZSA9IHtcbiAgICAuLi5jcmVhdGVJbml0aWFsUG9wdXBTdG9yZVN0YXRlKHRyaWdnZXJFbGVtZW50cywgZmxvYXRpbmdJZCwgbmVzdGVkKSxcbiAgICBkaXNhYmxlZDogZmFsc2UsXG4gICAgaW5zdGFudFR5cGU6IHVuZGVmaW5lZCxcbiAgICBpc0luc3RhbnRQaGFzZTogZmFsc2UsXG4gICAgdHJhY2tDdXJzb3JBeGlzOiAnbm9uZScsXG4gICAgZGlzYWJsZUhvdmVyYWJsZVBvcHVwOiBmYWxzZSxcbiAgICBvcGVuQ2hhbmdlUmVhc29uOiBudWxsLFxuICAgIGNsb3NlT25DbGljazogdHJ1ZSxcbiAgICBjbG9zZURlbGF5OiAwLFxuICAgIGFkYXB0aXZlT3JpZ2luOiB1bmRlZmluZWQsXG4gICAgLi4uaW5pdGlhbFN0YXRlXG4gIH07XG4gIHJldHVybiBzdGF0ZTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUluaXRpYWxDb250ZXh0KHRyaWdnZXJFbGVtZW50cykge1xuICByZXR1cm4ge1xuICAgIHBvcHVwUmVmOiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlUmVmKCksXG4gICAgb25PcGVuQ2hhbmdlOiB1bmRlZmluZWQsXG4gICAgb25PcGVuQ2hhbmdlQ29tcGxldGU6IHVuZGVmaW5lZCxcbiAgICB0cmlnZ2VyRWxlbWVudHNcbiAgfTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGZhc3RDb21wb25lbnQgfSBmcm9tICdAYmFzZS11aS91dGlscy9mYXN0SG9va3MnO1xuaW1wb3J0IHsgRU1QVFlfT0JKRUNUIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IFRvb2x0aXBSb290Q29udGV4dCB9IGZyb20gXCIuL1Rvb2x0aXBSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZUNsaWVudFBvaW50LCB1c2VEaXNtaXNzIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBQb3B1cEhhbmRsZUF0dGFjaG1lbnQsIHVzZUltcGxpY2l0QWN0aXZlVHJpZ2dlciwgdXNlUG9wdXBSb290U3RvcmUsIHVzZU9wZW5TdGF0ZVRyYW5zaXRpb25zLCB1c2VQb3B1cEludGVyYWN0aW9uUHJvcHMgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBzL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgbWVyZ2VQcm9wcyB9IGZyb20gXCIuLi8uLi9tZXJnZS1wcm9wcy9pbmRleC5tanNcIjtcbmltcG9ydCB7IFRvb2x0aXBTdG9yZSB9IGZyb20gXCIuLi9zdG9yZS9Ub29sdGlwU3RvcmUubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuXG4vKipcbiAqIEdyb3VwcyBhbGwgcGFydHMgb2YgdGhlIHRvb2x0aXAuXG4gKiBEb2Vzbid0IHJlbmRlciBpdHMgb3duIEhUTUwgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBUb29sdGlwXShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvdG9vbHRpcClcbiAqL1xuaW1wb3J0IHsganN4IGFzIF9qc3gsIGpzeHMgYXMgX2pzeHMgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCBjb25zdCBUb29sdGlwUm9vdCA9IGZhc3RDb21wb25lbnQoZnVuY3Rpb24gVG9vbHRpcFJvb3QocHJvcHMpIHtcbiAgY29uc3Qge1xuICAgIGRpc2FibGVkID0gZmFsc2UsXG4gICAgZGVmYXVsdE9wZW4gPSBmYWxzZSxcbiAgICBvcGVuOiBvcGVuUHJvcCxcbiAgICBkaXNhYmxlSG92ZXJhYmxlUG9wdXAgPSBmYWxzZSxcbiAgICB0cmFja0N1cnNvckF4aXMgPSAnbm9uZScsXG4gICAgYWN0aW9uc1JlZixcbiAgICBvbk9wZW5DaGFuZ2UsXG4gICAgb25PcGVuQ2hhbmdlQ29tcGxldGUsXG4gICAgaGFuZGxlLFxuICAgIHRyaWdnZXJJZDogdHJpZ2dlcklkUHJvcCxcbiAgICBkZWZhdWx0VHJpZ2dlcklkOiBkZWZhdWx0VHJpZ2dlcklkUHJvcCA9IG51bGwsXG4gICAgY2hpbGRyZW5cbiAgfSA9IHByb3BzO1xuICBjb25zdCBzdG9yZSA9IHVzZVBvcHVwUm9vdFN0b3JlKChmbG9hdGluZ0lkLCBuZXN0ZWQpID0+IG5ldyBUb29sdGlwU3RvcmUoe1xuICAgIG9wZW46IGRlZmF1bHRPcGVuLFxuICAgIG9wZW5Qcm9wLFxuICAgIGFjdGl2ZVRyaWdnZXJJZDogZGVmYXVsdFRyaWdnZXJJZFByb3AsXG4gICAgdHJpZ2dlcklkUHJvcFxuICB9LCBmbG9hdGluZ0lkLCBuZXN0ZWQpKTtcbiAgc3RvcmUudXNlQ29udHJvbGxlZFByb3AoJ29wZW5Qcm9wJywgb3BlblByb3ApO1xuICBzdG9yZS51c2VDb250cm9sbGVkUHJvcCgndHJpZ2dlcklkUHJvcCcsIHRyaWdnZXJJZFByb3ApO1xuICBzdG9yZS51c2VDb250ZXh0Q2FsbGJhY2soJ29uT3BlbkNoYW5nZScsIG9uT3BlbkNoYW5nZSk7XG4gIHN0b3JlLnVzZUNvbnRleHRDYWxsYmFjaygnb25PcGVuQ2hhbmdlQ29tcGxldGUnLCBvbk9wZW5DaGFuZ2VDb21wbGV0ZSk7XG4gIGNvbnN0IG9wZW5TdGF0ZSA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IG9wZW4gPSAhZGlzYWJsZWQgJiYgb3BlblN0YXRlO1xuICBjb25zdCBhY3RpdmVUcmlnZ2VySWQgPSBzdG9yZS51c2VTdGF0ZSgnYWN0aXZlVHJpZ2dlcklkJyk7XG4gIGNvbnN0IG1vdW50ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbW91bnRlZCcpO1xuICBjb25zdCBwYXlsb2FkID0gc3RvcmUudXNlU3RhdGUoJ3BheWxvYWQnKTtcbiAgc3RvcmUudXNlU3luY2VkVmFsdWVzKHtcbiAgICB0cmFja0N1cnNvckF4aXMsXG4gICAgZGlzYWJsZUhvdmVyYWJsZVBvcHVwLFxuICAgIGRpc2FibGVkXG4gIH0pO1xuICB1c2VJbXBsaWNpdEFjdGl2ZVRyaWdnZXIoc3RvcmUsIHtcbiAgICBjbG9zZU9uQWN0aXZlVHJpZ2dlclVubW91bnQ6IHRydWVcbiAgfSk7XG4gIGNvbnN0IHtcbiAgICBmb3JjZVVubW91bnQsXG4gICAgdHJhbnNpdGlvblN0YXR1c1xuICB9ID0gdXNlT3BlblN0YXRlVHJhbnNpdGlvbnMob3Blbiwgc3RvcmUpO1xuICBjb25zdCBpc0luc3RhbnRQaGFzZSA9IHN0b3JlLnVzZVN0YXRlKCdpc0luc3RhbnRQaGFzZScpO1xuICBjb25zdCBpbnN0YW50VHlwZSA9IHN0b3JlLnVzZVN0YXRlKCdpbnN0YW50VHlwZScpO1xuICBjb25zdCBsYXN0T3BlbkNoYW5nZVJlYXNvbiA9IHN0b3JlLnVzZVN0YXRlKCdsYXN0T3BlbkNoYW5nZVJlYXNvbicpO1xuXG4gIC8vIEFuaW1hdGlvbnMgc2hvdWxkIGJlIGluc3RhbnQgaW4gdHdvIGNhc2VzOlxuICAvLyAxKSBPcGVuaW5nIGR1cmluZyB0aGUgcHJvdmlkZXIncyBpbnN0YW50IHBoYXNlIChhZGphY2VudCB0b29sdGlwIG9wZW5zIGluc3RhbnRseSlcbiAgLy8gMikgQ2xvc2luZyBiZWNhdXNlIGFub3RoZXIgdG9vbHRpcCBvcGVuZWQgKHJlYXNvbiA9PT0gJ25vbmUnKVxuICAvLyBPdGhlcndpc2UsIGFsbG93IHRoZSBhbmltYXRpb24gdG8gcGxheS4gSW4gcGFydGljdWxhciwgZG8gbm90IGRpc2FibGUgYW5pbWF0aW9uc1xuICAvLyBkdXJpbmcgdGhlICdlbmRpbmcnIHBoYXNlIHVubGVzcyBpdCdzIGR1ZSB0byBhIHNpYmxpbmcgb3BlbmluZy5cbiAgY29uc3QgcHJldmlvdXNJbnN0YW50VHlwZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAob3BlblN0YXRlICYmIGRpc2FibGVkKSB7XG4gICAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5kaXNhYmxlZCkpO1xuICAgIH1cbiAgfSwgW29wZW5TdGF0ZSwgZGlzYWJsZWQsIHN0b3JlXSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHRyYW5zaXRpb25TdGF0dXMgPT09ICdlbmRpbmcnICYmIGxhc3RPcGVuQ2hhbmdlUmVhc29uID09PSBSRUFTT05TLm5vbmUgfHwgdHJhbnNpdGlvblN0YXR1cyAhPT0gJ2VuZGluZycgJiYgaXNJbnN0YW50UGhhc2UpIHtcbiAgICAgIC8vIENhcHR1cmUgdGhlIGN1cnJlbnQgaW5zdGFudCB0eXBlIHNvIHdlIGNhbiByZXN0b3JlIGl0IGxhdGVyXG4gICAgICAvLyBhbmQgc2V0IHRvICdkZWxheScgdG8gZGlzYWJsZSBhbmltYXRpb25zIHdoaWxlIG1vdmluZyBmcm9tIG9uZSB0cmlnZ2VyIHRvIGFub3RoZXJcbiAgICAgIC8vIHdpdGhpbiBhIGRlbGF5IGdyb3VwLlxuICAgICAgaWYgKGluc3RhbnRUeXBlICE9PSAnZGVsYXknKSB7XG4gICAgICAgIHByZXZpb3VzSW5zdGFudFR5cGVSZWYuY3VycmVudCA9IGluc3RhbnRUeXBlO1xuICAgICAgfVxuICAgICAgc3RvcmUuc2V0KCdpbnN0YW50VHlwZScsICdkZWxheScpO1xuICAgIH0gZWxzZSBpZiAocHJldmlvdXNJbnN0YW50VHlwZVJlZi5jdXJyZW50ICE9PSBudWxsKSB7XG4gICAgICBzdG9yZS5zZXQoJ2luc3RhbnRUeXBlJywgcHJldmlvdXNJbnN0YW50VHlwZVJlZi5jdXJyZW50KTtcbiAgICAgIHByZXZpb3VzSW5zdGFudFR5cGVSZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICB9LCBbdHJhbnNpdGlvblN0YXR1cywgaXNJbnN0YW50UGhhc2UsIGxhc3RPcGVuQ2hhbmdlUmVhc29uLCBpbnN0YW50VHlwZSwgc3RvcmVdKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAob3Blbikge1xuICAgICAgaWYgKGFjdGl2ZVRyaWdnZXJJZCA9PSBudWxsKSB7XG4gICAgICAgIHN0b3JlLnNldCgncGF5bG9hZCcsIHVuZGVmaW5lZCk7XG4gICAgICB9XG4gICAgfVxuICB9LCBbc3RvcmUsIGFjdGl2ZVRyaWdnZXJJZCwgb3Blbl0pO1xuICBSZWFjdC51c2VJbXBlcmF0aXZlSGFuZGxlKGFjdGlvbnNSZWYsICgpID0+ICh7XG4gICAgdW5tb3VudDogZm9yY2VVbm1vdW50LFxuICAgIGNsb3NlOiAoKSA9PiBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5pbXBlcmF0aXZlQWN0aW9uKSlcbiAgfSksIFtmb3JjZVVubW91bnQsIHN0b3JlXSk7XG4gIGNvbnN0IHNob3VsZFJlbmRlckludGVyYWN0aW9ucyA9IG9wZW4gfHwgbW91bnRlZCB8fCAhZGlzYWJsZWQgJiYgdHJhY2tDdXJzb3JBeGlzICE9PSAnbm9uZSc7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeHMoVG9vbHRpcFJvb3RDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IHN0b3JlLFxuICAgIGNoaWxkcmVuOiBbaGFuZGxlICYmIC8qI19fUFVSRV9fKi9fanN4KFBvcHVwSGFuZGxlQXR0YWNobWVudCwge1xuICAgICAgaGFuZGxlOiBoYW5kbGUsXG4gICAgICBzdG9yZTogc3RvcmVcbiAgICB9KSwgc2hvdWxkUmVuZGVySW50ZXJhY3Rpb25zICYmIC8qI19fUFVSRV9fKi9fanN4KFRvb2x0aXBJbnRlcmFjdGlvbnMsIHtcbiAgICAgIHN0b3JlOiBzdG9yZSxcbiAgICAgIGRpc2FibGVkOiBkaXNhYmxlZCxcbiAgICAgIHRyYWNrQ3Vyc29yQXhpczogdHJhY2tDdXJzb3JBeGlzXG4gICAgfSksIHR5cGVvZiBjaGlsZHJlbiA9PT0gJ2Z1bmN0aW9uJyA/IGNoaWxkcmVuKHtcbiAgICAgIHBheWxvYWRcbiAgICB9KSA6IGNoaWxkcmVuXVxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgVG9vbHRpcFJvb3QuZGlzcGxheU5hbWUgPSBcIlRvb2x0aXBSb290XCI7XG5mdW5jdGlvbiBUb29sdGlwSW50ZXJhY3Rpb25zKHtcbiAgc3RvcmUsXG4gIGRpc2FibGVkLFxuICB0cmFja0N1cnNvckF4aXNcbn0pIHtcbiAgY29uc3QgZmxvYXRpbmdSb290Q29udGV4dCA9IHN0b3JlLnVzZVN0YXRlKCdmbG9hdGluZ1Jvb3RDb250ZXh0Jyk7XG4gIGNvbnN0IGRpc21pc3MgPSB1c2VEaXNtaXNzKGZsb2F0aW5nUm9vdENvbnRleHQsIHtcbiAgICBlbmFibGVkOiAhZGlzYWJsZWQsXG4gICAgcmVmZXJlbmNlUHJlc3M6ICgpID0+IHN0b3JlLnNlbGVjdCgnY2xvc2VPbkNsaWNrJylcbiAgfSk7XG4gIGNvbnN0IGNsaWVudFBvaW50ID0gdXNlQ2xpZW50UG9pbnQoZmxvYXRpbmdSb290Q29udGV4dCwge1xuICAgIGVuYWJsZWQ6ICFkaXNhYmxlZCAmJiB0cmFja0N1cnNvckF4aXMgIT09ICdub25lJyxcbiAgICBheGlzOiB0cmFja0N1cnNvckF4aXMgPT09ICdub25lJyA/IHVuZGVmaW5lZCA6IHRyYWNrQ3Vyc29yQXhpc1xuICB9KTtcblxuICAvLyBCb3RoIGhvb2tzIHJldHVybiBgdHJpZ2dlcjogcmVmZXJlbmNlYCAoc2FtZSBvYmplY3QgaWRlbnRpdHkpLCBzbyB0aGUgYWN0aXZlIGFuZFxuICAvLyBpbmFjdGl2ZSB0cmlnZ2VyIHByb3BzIGNhbiBuZXZlciBkaWZmZXIuIGB1c2VDbGllbnRQb2ludGAgaGFzIG5vIGZsb2F0aW5nLXNpZGUgcHJvcHMuXG4gIGNvbnN0IHRyaWdnZXJQcm9wcyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gbWVyZ2VQcm9wcyhjbGllbnRQb2ludC5yZWZlcmVuY2UsIGRpc21pc3MucmVmZXJlbmNlKSwgW2NsaWVudFBvaW50LnJlZmVyZW5jZSwgZGlzbWlzcy5yZWZlcmVuY2VdKTtcbiAgdXNlUG9wdXBJbnRlcmFjdGlvblByb3BzKHN0b3JlLCB7XG4gICAgYWN0aXZlVHJpZ2dlclByb3BzOiB0cmlnZ2VyUHJvcHMsXG4gICAgaW5hY3RpdmVUcmlnZ2VyUHJvcHM6IHRyaWdnZXJQcm9wcyxcbiAgICBwb3B1cFByb3BzOiBkaXNtaXNzLmZsb2F0aW5nID8/IEVNUFRZX09CSkVDVFxuICB9KTtcbiAgcmV0dXJuIG51bGw7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbi8qKlxuICogSG9sZHMgdGhlIHByb3ZpZGVyJ3MgYGRlbGF5YCB2YWx1ZS4gYGNsb3NlRGVsYXlgIGlzIGhhbmRsZWQgYnkgdGhlIGRlbGF5IGdyb3VwLlxuICovXG5leHBvcnQgY29uc3QgVG9vbHRpcFByb3ZpZGVyQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHVuZGVmaW5lZCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBUb29sdGlwUHJvdmlkZXJDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJUb29sdGlwUHJvdmlkZXJDb250ZXh0XCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlVG9vbHRpcFByb3ZpZGVyQ29udGV4dCgpIHtcbiAgcmV0dXJuIFJlYWN0LnVzZUNvbnRleHQoVG9vbHRpcFByb3ZpZGVyQ29udGV4dCk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgX2Zvcm1hdEVycm9yTWVzc2FnZSBmcm9tIFwiQGJhc2UtdWkvdXRpbHMvZm9ybWF0RXJyb3JNZXNzYWdlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBpc0VsZW1lbnQgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IGZhc3RDb21wb25lbnRSZWYgfSBmcm9tICdAYmFzZS11aS91dGlscy9mYXN0SG9va3MnO1xuaW1wb3J0IHsgdXNlVGltZW91dCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVRpbWVvdXQnO1xuaW1wb3J0IHsgdXNlVmFsdWVBc1JlZiB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVZhbHVlQXNSZWYnO1xuaW1wb3J0IHsgdXNlVG9vbHRpcFJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvVG9vbHRpcFJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdHJpZ2dlck9wZW5TdGF0ZU1hcHBpbmcgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlUG9wdXBIYW5kbGVTdG9yZSwgdXNlVHJpZ2dlckRhdGFGb3J3YXJkaW5nIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwcy9pbmRleC5tanNcIjtcbmltcG9ydCB7IHVzZUJhc2VVaUlkIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VCYXNlVWlJZC5tanNcIjtcbmltcG9ydCB7IHVzZVRvb2x0aXBQcm92aWRlckNvbnRleHQgfSBmcm9tIFwiLi4vcHJvdmlkZXIvVG9vbHRpcFByb3ZpZGVyQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHNhZmVQb2x5Z29uLCB1c2VEZWxheUdyb3VwLCB1c2VGb2N1cywgdXNlSG92ZXJSZWZlcmVuY2VJbnRlcmFjdGlvbiB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9pbmRleC5tanNcIjtcbmltcG9ydCB7IGNsb3Nlc3QsIGNvbnRhaW5zLCBnZXRUYXJnZXQgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvdXRpbHMvZWxlbWVudC5tanNcIjtcbmltcG9ydCB7IGlzTW91c2VMaWtlUG9pbnRlclR5cGUgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvdXRpbHMvZXZlbnQubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5pbXBvcnQgeyB1c2VIb3ZlckludGVyYWN0aW9uU2hhcmVkU3RhdGUgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvaG9va3MvdXNlSG92ZXJJbnRlcmFjdGlvblNoYXJlZFN0YXRlLm1qc1wiO1xuaW1wb3J0IHsgZ2V0RGVsYXkgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvaG9va3MvdXNlSG92ZXJTaGFyZWQubWpzXCI7XG5pbXBvcnQgKiBhcyBUb29sdGlwVHJpZ2dlckRhdGFBdHRyaWJ1dGVzIGZyb20gXCIuL1Rvb2x0aXBUcmlnZ2VyRGF0YUF0dHJpYnV0ZXMubWpzXCI7XG5pbXBvcnQgeyBPUEVOX0RFTEFZIH0gZnJvbSBcIi4uL3V0aWxzL2NvbnN0YW50cy5tanNcIjtcbmNvbnN0IFRPT0xUSVBfVFJJR0dFUl9JREVOVElGSUVSID0gJ2RhdGEtYmFzZS11aS10b29sdGlwLXRyaWdnZXInO1xuZnVuY3Rpb24gZ2V0VGFyZ2V0RWxlbWVudChldmVudCkge1xuICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQpO1xuICByZXR1cm4gaXNFbGVtZW50KHRhcmdldCkgPyB0YXJnZXQgOiBudWxsO1xufVxuXG4vKipcbiAqIEFuIGVsZW1lbnQgdG8gYXR0YWNoIHRoZSB0b29sdGlwIHRvLlxuICogUmVuZGVycyBhIGA8YnV0dG9uPmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBUb29sdGlwXShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvdG9vbHRpcClcbiAqL1xuZXhwb3J0IGNvbnN0IFRvb2x0aXBUcmlnZ2VyID0gZmFzdENvbXBvbmVudFJlZihmdW5jdGlvbiBUb29sdGlwVHJpZ2dlcihjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIGhhbmRsZSxcbiAgICBwYXlsb2FkLFxuICAgIGRpc2FibGVkOiBkaXNhYmxlZFByb3AsXG4gICAgZGVsYXksXG4gICAgY2xvc2VPbkNsaWNrID0gdHJ1ZSxcbiAgICBjbG9zZURlbGF5LFxuICAgIGlkOiBpZFByb3AsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qgcm9vdENvbnRleHQgPSB1c2VUb29sdGlwUm9vdENvbnRleHQodHJ1ZSk7XG4gIGNvbnN0IGhhbmRsZVN0b3JlID0gdXNlUG9wdXBIYW5kbGVTdG9yZShoYW5kbGUpO1xuICBjb25zdCBzdG9yZSA9IGhhbmRsZVN0b3JlID8/IHJvb3RDb250ZXh0O1xuICBpZiAoIXN0b3JlKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/ICdCYXNlIFVJOiA8VG9vbHRpcC5UcmlnZ2VyPiBtdXN0IGJlIGVpdGhlciB1c2VkIHdpdGhpbiBhIDxUb29sdGlwLlJvb3Q+IGNvbXBvbmVudCBvciBwcm92aWRlZCB3aXRoIGEgaGFuZGxlLicgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDgyKSk7XG4gIH1cbiAgY29uc3QgdGhpc1RyaWdnZXJJZCA9IHVzZUJhc2VVaUlkKGlkUHJvcCk7XG4gIGNvbnN0IGlzVHJpZ2dlckFjdGl2ZSA9IHN0b3JlLnVzZVN0YXRlKCdpc1RyaWdnZXJBY3RpdmUnLCB0aGlzVHJpZ2dlcklkKTtcbiAgY29uc3QgaXNPcGVuZWRCeVRoaXNUcmlnZ2VyID0gc3RvcmUudXNlU3RhdGUoJ2lzT3BlbmVkQnlUcmlnZ2VyJywgdGhpc1RyaWdnZXJJZCk7XG4gIGNvbnN0IGZsb2F0aW5nUm9vdENvbnRleHQgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdSb290Q29udGV4dCcpO1xuICBjb25zdCB0cmlnZ2VyRWxlbWVudFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgY2xvc2VEZWxheVdpdGhEZWZhdWx0ID0gY2xvc2VEZWxheSA/PyAwO1xuICBjb25zdCB7XG4gICAgcmVnaXN0ZXJUcmlnZ2VyLFxuICAgIGlzTW91bnRlZEJ5VGhpc1RyaWdnZXJcbiAgfSA9IHVzZVRyaWdnZXJEYXRhRm9yd2FyZGluZyh0aGlzVHJpZ2dlcklkLCB0cmlnZ2VyRWxlbWVudFJlZiwgc3RvcmUsIHtcbiAgICBwYXlsb2FkLFxuICAgIGNsb3NlT25DbGljayxcbiAgICBjbG9zZURlbGF5OiBjbG9zZURlbGF5V2l0aERlZmF1bHRcbiAgfSk7XG4gIGNvbnN0IHByb3ZpZGVyRGVsYXkgPSB1c2VUb29sdGlwUHJvdmlkZXJDb250ZXh0KCk7XG4gIGNvbnN0IHtcbiAgICBhY3RpdmVJZFJlZixcbiAgICBkZWxheVJlZixcbiAgICBpc0luc3RhbnRQaGFzZSxcbiAgICBoYXNQcm92aWRlclxuICB9ID0gdXNlRGVsYXlHcm91cChmbG9hdGluZ1Jvb3RDb250ZXh0LCB7XG4gICAgb3BlbjogaXNPcGVuZWRCeVRoaXNUcmlnZ2VyXG4gIH0pO1xuICBjb25zdCBob3ZlckludGVyYWN0aW9uID0gdXNlSG92ZXJJbnRlcmFjdGlvblNoYXJlZFN0YXRlKGZsb2F0aW5nUm9vdENvbnRleHQpO1xuICBzdG9yZS51c2VTeW5jZWRWYWx1ZSgnaXNJbnN0YW50UGhhc2UnLCBpc0luc3RhbnRQaGFzZSk7XG4gIGNvbnN0IHJvb3REaXNhYmxlZCA9IHN0b3JlLnVzZVN0YXRlKCdkaXNhYmxlZCcpO1xuICBjb25zdCBkaXNhYmxlZCA9IGRpc2FibGVkUHJvcCA/PyByb290RGlzYWJsZWQ7XG4gIGNvbnN0IGRpc2FibGVkUmVmID0gdXNlVmFsdWVBc1JlZihkaXNhYmxlZCk7XG4gIGNvbnN0IHRyYWNrQ3Vyc29yQXhpcyA9IHN0b3JlLnVzZVN0YXRlKCd0cmFja0N1cnNvckF4aXMnKTtcbiAgY29uc3QgZGlzYWJsZUhvdmVyYWJsZVBvcHVwID0gc3RvcmUudXNlU3RhdGUoJ2Rpc2FibGVIb3ZlcmFibGVQb3B1cCcpO1xuICBjb25zdCBpc05lc3RlZFRyaWdnZXJIb3ZlcmVkUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgbmVzdGVkVHJpZ2dlck9wZW5UaW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICAvLyBMb2NhbCBjb3B5IHNvIGl0IGNhbiBiZSBjbGVhcmVkIG9uIG1vdXNlTGVhdmUgd2l0aG91dCByZXNldHRpbmcgdGhlIGhvdmVyIGhvb2sncyBvd24gcG9pbnRlclR5cGUuXG4gIGNvbnN0IHBvaW50ZXJUeXBlUmVmID0gUmVhY3QudXNlUmVmKHVuZGVmaW5lZCk7XG4gIGZ1bmN0aW9uIGdldE9wZW5EZWxheSgpIHtcbiAgICAvLyBBZGphY2VudCB0b29sdGlwcyBvcGVuIGluc3RhbnRseSB3aGlsZSB0aGUgZ3JvdXAgaXMgYWN0aXZlLlxuICAgIGlmIChoYXNQcm92aWRlciAmJiBhY3RpdmVJZFJlZi5jdXJyZW50ICE9IG51bGwpIHtcbiAgICAgIHJldHVybiAwO1xuICAgIH1cbiAgICByZXR1cm4gZGVsYXkgPz8gcHJvdmlkZXJEZWxheSA/PyBPUEVOX0RFTEFZO1xuICB9XG4gIGZ1bmN0aW9uIGlzRW5hYmxlZE5lc3RlZFRyaWdnZXJUYXJnZXQodGFyZ2V0KSB7XG4gICAgY29uc3QgdHJpZ2dlckVsID0gdHJpZ2dlckVsZW1lbnRSZWYuY3VycmVudDtcbiAgICBpZiAoIXRyaWdnZXJFbCB8fCAhdGFyZ2V0KSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IG5lYXJlc3RUcmlnZ2VyID0gY2xvc2VzdCh0YXJnZXQsIGBbJHtUT09MVElQX1RSSUdHRVJfSURFTlRJRklFUn1dYCk7XG4gICAgcmV0dXJuIG5lYXJlc3RUcmlnZ2VyICE9PSBudWxsICYmIG5lYXJlc3RUcmlnZ2VyICE9PSB0cmlnZ2VyRWwgJiYgY29udGFpbnModHJpZ2dlckVsLCBuZWFyZXN0VHJpZ2dlcik7XG4gIH1cbiAgZnVuY3Rpb24gZGV0ZWN0TmVzdGVkVHJpZ2dlckhvdmVyKHRhcmdldCkge1xuICAgIGNvbnN0IG5lc3RlZFRyaWdnZXJIb3ZlcmVkID0gaXNFbmFibGVkTmVzdGVkVHJpZ2dlclRhcmdldCh0YXJnZXQpO1xuICAgIGlzTmVzdGVkVHJpZ2dlckhvdmVyZWRSZWYuY3VycmVudCA9IG5lc3RlZFRyaWdnZXJIb3ZlcmVkO1xuICAgIGlmIChuZXN0ZWRUcmlnZ2VySG92ZXJlZCkge1xuICAgICAgaG92ZXJJbnRlcmFjdGlvbi5vcGVuQ2hhbmdlVGltZW91dC5jbGVhcigpO1xuICAgICAgaG92ZXJJbnRlcmFjdGlvbi5yZXN0VGltZW91dC5jbGVhcigpO1xuICAgICAgaG92ZXJJbnRlcmFjdGlvbi5yZXN0VGltZW91dFBlbmRpbmcgPSBmYWxzZTtcbiAgICAgIG5lc3RlZFRyaWdnZXJPcGVuVGltZW91dC5jbGVhcigpO1xuICAgIH1cbiAgICByZXR1cm4gbmVzdGVkVHJpZ2dlckhvdmVyZWQ7XG4gIH1cbiAgY29uc3QgaG92ZXJQcm9wcyA9IHVzZUhvdmVyUmVmZXJlbmNlSW50ZXJhY3Rpb24oZmxvYXRpbmdSb290Q29udGV4dCwge1xuICAgIGVuYWJsZWQ6ICFkaXNhYmxlZCxcbiAgICBtb3VzZU9ubHk6IHRydWUsXG4gICAgbW92ZTogZmFsc2UsXG4gICAgaGFuZGxlQ2xvc2U6ICFkaXNhYmxlSG92ZXJhYmxlUG9wdXAgJiYgdHJhY2tDdXJzb3JBeGlzICE9PSAnYm90aCcgPyBzYWZlUG9seWdvbigpIDogbnVsbCxcbiAgICByZXN0TXM6IGdldE9wZW5EZWxheSxcbiAgICBkZWxheSgpIHtcbiAgICAgIGlmIChjbG9zZURlbGF5ID09IG51bGwgJiYgaGFzUHJvdmlkZXIpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBjbG9zZTogZ2V0RGVsYXkoZGVsYXlSZWYuY3VycmVudCwgJ2Nsb3NlJylcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIGNsb3NlOiBjbG9zZURlbGF5V2l0aERlZmF1bHRcbiAgICAgIH07XG4gICAgfSxcbiAgICB0cmlnZ2VyRWxlbWVudFJlZixcbiAgICBpc0FjdGl2ZVRyaWdnZXI6IGlzVHJpZ2dlckFjdGl2ZSxcbiAgICBpc0Nsb3Npbmc6ICgpID0+IHN0b3JlLnNlbGVjdCgndHJhbnNpdGlvblN0YXR1cycpID09PSAnZW5kaW5nJyxcbiAgICBzaG91bGRPcGVuKCkge1xuICAgICAgcmV0dXJuICFpc05lc3RlZFRyaWdnZXJIb3ZlcmVkUmVmLmN1cnJlbnQ7XG4gICAgfVxuICB9KTtcbiAgY29uc3QgZm9jdXNQcm9wcyA9IHVzZUZvY3VzKGZsb2F0aW5nUm9vdENvbnRleHQsIHtcbiAgICBlbmFibGVkOiAhZGlzYWJsZWRcbiAgfSkucmVmZXJlbmNlO1xuICBjb25zdCBoYW5kbGVOZXN0ZWRUcmlnZ2VySG92ZXIgPSBldmVudCA9PiB7XG4gICAgY29uc3Qgd2FzTmVzdGVkVHJpZ2dlckhvdmVyZWQgPSBpc05lc3RlZFRyaWdnZXJIb3ZlcmVkUmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgdGFyZ2V0ID0gZ2V0VGFyZ2V0RWxlbWVudChldmVudCk7XG4gICAgY29uc3QgbmVzdGVkVHJpZ2dlckhvdmVyZWQgPSBkZXRlY3ROZXN0ZWRUcmlnZ2VySG92ZXIodGFyZ2V0KTtcbiAgICBjb25zdCB0cmlnZ2VyRWwgPSB0cmlnZ2VyRWxlbWVudFJlZi5jdXJyZW50O1xuICAgIGNvbnN0IHRhcmdldEluc2lkZVRyaWdnZXIgPSB0cmlnZ2VyRWwgJiYgdGFyZ2V0ICYmIGNvbnRhaW5zKHRyaWdnZXJFbCwgdGFyZ2V0KTtcblxuICAgIC8vIE9ubHkgY2xvc2UgaG92ZXItb3BlbmVkIHBhcmVudHMuIEZvY3VzL2NsaWNrLWxpa2Ugb3BlbnMgcmVtYWluIG93bmVkIGJ5XG4gICAgLy8gdGhlaXIgb3JpZ2luYWwgaW50ZXJhY3Rpb24gYW5kIHNob3VsZCBub3QgYmUgY2xvYmJlcmVkIGJ5IG5lc3RlZCBob3Zlci5cbiAgICBpZiAobmVzdGVkVHJpZ2dlckhvdmVyZWQgJiYgc3RvcmUuc2VsZWN0KCdvcGVuJykgJiYgc3RvcmUuc2VsZWN0KCdsYXN0T3BlbkNoYW5nZVJlYXNvbicpID09PSBSRUFTT05TLnRyaWdnZXJIb3Zlcikge1xuICAgICAgc3RvcmUuc2V0T3BlbihmYWxzZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMudHJpZ2dlckhvdmVyLCBldmVudCkpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAod2FzTmVzdGVkVHJpZ2dlckhvdmVyZWQgJiYgIW5lc3RlZFRyaWdnZXJIb3ZlcmVkICYmIHRhcmdldEluc2lkZVRyaWdnZXIgJiYgIWRpc2FibGVkUmVmLmN1cnJlbnQgJiYgIXN0b3JlLnNlbGVjdCgnb3BlbicpICYmIHRyaWdnZXJFbCAmJlxuICAgIC8vIE1hdGNoIHRoZSBob3ZlciBob29rJ3Mgbm9uLXN0cmljdCBtb3VzZSBmYWxsYmFjayBmb3IgbW91c2Utb25seSBldmVudCBzZXF1ZW5jZXMuXG4gICAgaXNNb3VzZUxpa2VQb2ludGVyVHlwZShwb2ludGVyVHlwZVJlZi5jdXJyZW50KSkge1xuICAgICAgY29uc3Qgb3BlbiA9ICgpID0+IHtcbiAgICAgICAgaWYgKCFpc05lc3RlZFRyaWdnZXJIb3ZlcmVkUmVmLmN1cnJlbnQgJiYgIWRpc2FibGVkUmVmLmN1cnJlbnQgJiYgIXN0b3JlLnNlbGVjdCgnb3BlbicpKSB7XG4gICAgICAgICAgc3RvcmUuc2V0T3Blbih0cnVlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy50cmlnZ2VySG92ZXIsIGV2ZW50LCB0cmlnZ2VyRWwpKTtcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGNvbnN0IG9wZW5EZWxheSA9IGdldE9wZW5EZWxheSgpO1xuXG4gICAgICAvLyBXaXRoIGBtb3ZlOiBmYWxzZWAsIHRoZSBob3ZlciBob29rIG9ubHkgbGlzdGVucyB0byBtb3VzZWVudGVyL21vdXNlbGVhdmVcbiAgICAgIC8vIG9uIHRoZSBwYXJlbnQgdHJpZ2dlci4gTGVhdmluZyBhIG5lc3RlZCBjaGlsZCBmb3IgdGhlIHBhcmVudCBhcmVhIGZpcmVzXG4gICAgICAvLyBubyBldmVudCB0aGUgaG9vayBjYW4gcmVhY3QgdG8sIHNvIHJlb3BlbiBsb2NhbGx5LlxuICAgICAgaWYgKG9wZW5EZWxheSA9PT0gMCkge1xuICAgICAgICBuZXN0ZWRUcmlnZ2VyT3BlblRpbWVvdXQuY2xlYXIoKTtcbiAgICAgICAgb3BlbigpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbmVzdGVkVHJpZ2dlck9wZW5UaW1lb3V0LnN0YXJ0KG9wZW5EZWxheSwgb3Blbik7XG4gICAgICB9XG4gICAgfVxuICB9O1xuICBjb25zdCByb290VHJpZ2dlclByb3BzID0gc3RvcmUudXNlU3RhdGUoJ2FwcGxpZWRUcmlnZ2VyUHJvcHMnLCBpc01vdW50ZWRCeVRoaXNUcmlnZ2VyIHx8IHRyYWNrQ3Vyc29yQXhpcyAhPT0gJ25vbmUnKTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgb3BlbjogaXNPcGVuZWRCeVRoaXNUcmlnZ2VyXG4gIH07XG4gIGNvbnN0IGVsZW1lbnQgPSB1c2VSZW5kZXJFbGVtZW50KCdidXR0b24nLCBjb21wb25lbnRQcm9wcywge1xuICAgIHN0YXRlLFxuICAgIHJlZjogW2ZvcndhcmRlZFJlZiwgcmVnaXN0ZXJUcmlnZ2VyLCB0cmlnZ2VyRWxlbWVudFJlZl0sXG4gICAgcHJvcHM6IFtob3ZlclByb3BzLCBmb2N1c1Byb3BzLCByb290VHJpZ2dlclByb3BzLCB7XG4gICAgICBvbk1vdXNlT3ZlcihldmVudCkge1xuICAgICAgICBoYW5kbGVOZXN0ZWRUcmlnZ2VySG92ZXIoZXZlbnQubmF0aXZlRXZlbnQpO1xuICAgICAgfSxcbiAgICAgIG9uRm9jdXMoZXZlbnQpIHtcbiAgICAgICAgaWYgKGlzRW5hYmxlZE5lc3RlZFRyaWdnZXJUYXJnZXQoZ2V0VGFyZ2V0RWxlbWVudChldmVudC5uYXRpdmVFdmVudCkpKSB7XG4gICAgICAgICAgZXZlbnQucHJldmVudEJhc2VVSUhhbmRsZXIoKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIG9uTW91c2VMZWF2ZSgpIHtcbiAgICAgICAgaXNOZXN0ZWRUcmlnZ2VySG92ZXJlZFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIG5lc3RlZFRyaWdnZXJPcGVuVGltZW91dC5jbGVhcigpO1xuICAgICAgICBwb2ludGVyVHlwZVJlZi5jdXJyZW50ID0gdW5kZWZpbmVkO1xuICAgICAgfSxcbiAgICAgIG9uUG9pbnRlckVudGVyKGV2ZW50KSB7XG4gICAgICAgIHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQgPSBldmVudC5wb2ludGVyVHlwZTtcbiAgICAgIH0sXG4gICAgICBvblBvaW50ZXJEb3duKGV2ZW50KSB7XG4gICAgICAgIHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQgPSBldmVudC5wb2ludGVyVHlwZTtcbiAgICAgICAgc3RvcmUuc2V0KCdjbG9zZU9uQ2xpY2snLCBjbG9zZU9uQ2xpY2spO1xuICAgICAgICBpZiAoY2xvc2VPbkNsaWNrICYmICFzdG9yZS5zZWxlY3QoJ29wZW4nKSkge1xuICAgICAgICAgIHN0b3JlLmNhbmNlbFBlbmRpbmdPcGVuKGV2ZW50Lm5hdGl2ZUV2ZW50KTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIG9uQ2xpY2soZXZlbnQpIHtcbiAgICAgICAgaWYgKGNsb3NlT25DbGljayAmJiAhc3RvcmUuc2VsZWN0KCdvcGVuJykpIHtcbiAgICAgICAgICBzdG9yZS5jYW5jZWxQZW5kaW5nT3BlbihldmVudC5uYXRpdmVFdmVudCk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBpZDogdGhpc1RyaWdnZXJJZCxcbiAgICAgIFtUb29sdGlwVHJpZ2dlckRhdGFBdHRyaWJ1dGVzLnRyaWdnZXJEaXNhYmxlZF06IGRpc2FibGVkID8gJycgOiB1bmRlZmluZWQsXG4gICAgICBbVE9PTFRJUF9UUklHR0VSX0lERU5USUZJRVJdOiBkaXNhYmxlZCA/IHVuZGVmaW5lZCA6ICcnXG4gICAgfSwgZWxlbWVudFByb3BzXSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiB0cmlnZ2VyT3BlblN0YXRlTWFwcGluZ1xuICB9KTtcbiAgcmV0dXJuIGVsZW1lbnQ7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFRvb2x0aXBUcmlnZ2VyLmRpc3BsYXlOYW1lID0gXCJUb29sdGlwVHJpZ2dlclwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IFRvb2x0aXBQb3J0YWxDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFRvb2x0aXBQb3J0YWxDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJUb29sdGlwUG9ydGFsQ29udGV4dFwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVRvb2x0aXBQb3J0YWxDb250ZXh0KCkge1xuICBjb25zdCB2YWx1ZSA9IFJlYWN0LnVzZUNvbnRleHQoVG9vbHRpcFBvcnRhbENvbnRleHQpO1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAnQmFzZSBVSTogPFRvb2x0aXAuUG9ydGFsPiBpcyBtaXNzaW5nLicgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDcwKSk7XG4gIH1cbiAgcmV0dXJuIHZhbHVlO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0ICogYXMgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tJztcbmltcG9ydCB7IHVzZUZsb2F0aW5nUG9ydGFsTm9kZSB9IGZyb20gXCIuLi9mbG9hdGluZy11aS1yZWFjdC9jb21wb25lbnRzL0Zsb2F0aW5nUG9ydGFsLm1qc1wiO1xuaW1wb3J0IHsganN4cyBhcyBfanN4cyB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLyoqXG4gKiBgRmxvYXRpbmdQb3J0YWxgIGluY2x1ZGVzIHRhYmJhYmxlIGxvZ2ljIGhhbmRsaW5nIGZvciBmb2N1cyBtYW5hZ2VtZW50LlxuICogRm9yIGNvbXBvbmVudHMgdGhhdCBkb24ndCBuZWVkIHRhYmJhYmxlIGxvZ2ljLCB1c2UgYEZsb2F0aW5nUG9ydGFsTGl0ZWAuXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGNvbnN0IEZsb2F0aW5nUG9ydGFsTGl0ZSA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIEZsb2F0aW5nUG9ydGFsTGl0ZShjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICBjaGlsZHJlbixcbiAgICBjb250YWluZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHJlbmRlcixcbiAgICBzdHlsZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCB7XG4gICAgbm9kZTogcG9ydGFsTm9kZSxcbiAgICBzdWJ0cmVlOiBwb3J0YWxTdWJ0cmVlXG4gIH0gPSB1c2VGbG9hdGluZ1BvcnRhbE5vZGUoe1xuICAgIGNvbnRhaW5lcixcbiAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICBjb21wb25lbnRQcm9wcyxcbiAgICBlbGVtZW50UHJvcHNcbiAgfSk7XG4gIGlmICghcG9ydGFsU3VidHJlZSAmJiAhcG9ydGFsTm9kZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeHMoUmVhY3QuRnJhZ21lbnQsIHtcbiAgICBjaGlsZHJlbjogW3BvcnRhbFN1YnRyZWUsIHBvcnRhbE5vZGUgJiYgLyojX19QVVJFX18qL1JlYWN0RE9NLmNyZWF0ZVBvcnRhbChjaGlsZHJlbiwgcG9ydGFsTm9kZSldXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBGbG9hdGluZ1BvcnRhbExpdGUuZGlzcGxheU5hbWUgPSBcIkZsb2F0aW5nUG9ydGFsTGl0ZVwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlVG9vbHRpcFJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvVG9vbHRpcFJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgVG9vbHRpcFBvcnRhbENvbnRleHQgfSBmcm9tIFwiLi9Ub29sdGlwUG9ydGFsQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IEZsb2F0aW5nUG9ydGFsTGl0ZSB9IGZyb20gXCIuLi8uLi91dGlscy9GbG9hdGluZ1BvcnRhbExpdGUubWpzXCI7XG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLyoqXG4gKiBBIHBvcnRhbCBlbGVtZW50IHRoYXQgbW92ZXMgdGhlIHBvcHVwIHRvIGEgZGlmZmVyZW50IHBhcnQgb2YgdGhlIERPTS5cbiAqIEJ5IGRlZmF1bHQsIHRoZSBwb3J0YWwgZWxlbWVudCBpcyBhcHBlbmRlZCB0byBgPGJvZHk+YC5cbiAqIFJlbmRlcnMgYSBgPGRpdj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgVG9vbHRpcF0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL3Rvb2x0aXApXG4gKi9cbmV4cG9ydCBjb25zdCBUb29sdGlwUG9ydGFsID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gVG9vbHRpcFBvcnRhbChwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICBrZWVwTW91bnRlZCA9IGZhbHNlLFxuICAgIC4uLnBvcnRhbFByb3BzXG4gIH0gPSBwcm9wcztcbiAgY29uc3Qgc3RvcmUgPSB1c2VUb29sdGlwUm9vdENvbnRleHQoKTtcbiAgY29uc3QgbW91bnRlZCA9IHN0b3JlLnVzZVN0YXRlKCdtb3VudGVkJyk7XG4gIGNvbnN0IHNob3VsZFJlbmRlciA9IG1vdW50ZWQgfHwga2VlcE1vdW50ZWQ7XG4gIGlmICghc2hvdWxkUmVuZGVyKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KFRvb2x0aXBQb3J0YWxDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IGtlZXBNb3VudGVkLFxuICAgIGNoaWxkcmVuOiAvKiNfX1BVUkVfXyovX2pzeChGbG9hdGluZ1BvcnRhbExpdGUsIHtcbiAgICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgICAgLi4ucG9ydGFsUHJvcHNcbiAgICB9KVxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgVG9vbHRpcFBvcnRhbC5kaXNwbGF5TmFtZSA9IFwiVG9vbHRpcFBvcnRhbFwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IFRvb2x0aXBQb3NpdGlvbmVyQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHVuZGVmaW5lZCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBUb29sdGlwUG9zaXRpb25lckNvbnRleHQuZGlzcGxheU5hbWUgPSBcIlRvb2x0aXBQb3NpdGlvbmVyQ29udGV4dFwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVRvb2x0aXBQb3NpdGlvbmVyQ29udGV4dCgpIHtcbiAgY29uc3QgY29udGV4dCA9IFJlYWN0LnVzZUNvbnRleHQoVG9vbHRpcFBvc2l0aW9uZXJDb250ZXh0KTtcbiAgaWYgKGNvbnRleHQgPT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAnQmFzZSBVSTogVG9vbHRpcFBvc2l0aW9uZXJDb250ZXh0IGlzIG1pc3NpbmcuIFRvb2x0aXBQb3NpdGlvbmVyIHBhcnRzIG11c3QgYmUgcGxhY2VkIHdpdGhpbiA8VG9vbHRpcC5Qb3NpdGlvbmVyPi4nIDogX2Zvcm1hdEVycm9yTWVzc2FnZSg3MSkpO1xuICB9XG4gIHJldHVybiBjb250ZXh0O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlVG9vbHRpcFJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvVG9vbHRpcFJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgVG9vbHRpcFBvc2l0aW9uZXJDb250ZXh0IH0gZnJvbSBcIi4vVG9vbHRpcFBvc2l0aW9uZXJDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQW5jaG9yUG9zaXRpb25pbmcgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZUFuY2hvclBvc2l0aW9uaW5nLm1qc1wiO1xuaW1wb3J0IHsgdXNlVG9vbHRpcFBvcnRhbENvbnRleHQgfSBmcm9tIFwiLi4vcG9ydGFsL1Rvb2x0aXBQb3J0YWxDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgUE9QVVBfQ09MTElTSU9OX0FWT0lEQU5DRSB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY29uc3RhbnRzLm1qc1wiO1xuaW1wb3J0IHsgdXNlUG9zaXRpb25lciB9IGZyb20gXCIuLi8uLi91dGlscy91c2VQb3NpdGlvbmVyLm1qc1wiO1xuXG4vKipcbiAqIFBvc2l0aW9ucyB0aGUgdG9vbHRpcCBhZ2FpbnN0IHRoZSB0cmlnZ2VyLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBUb29sdGlwXShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvdG9vbHRpcClcbiAqL1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCBjb25zdCBUb29sdGlwUG9zaXRpb25lciA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIFRvb2x0aXBQb3NpdGlvbmVyKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgYW5jaG9yLFxuICAgIHBvc2l0aW9uTWV0aG9kID0gJ2Fic29sdXRlJyxcbiAgICBzaWRlID0gJ3RvcCcsXG4gICAgYWxpZ24gPSAnY2VudGVyJyxcbiAgICBzaWRlT2Zmc2V0ID0gMCxcbiAgICBhbGlnbk9mZnNldCA9IDAsXG4gICAgY29sbGlzaW9uQm91bmRhcnkgPSAnY2xpcHBpbmctYW5jZXN0b3JzJyxcbiAgICBjb2xsaXNpb25QYWRkaW5nID0gNSxcbiAgICBhcnJvd1BhZGRpbmcgPSA1LFxuICAgIHN0aWNreSA9IGZhbHNlLFxuICAgIGRpc2FibGVBbmNob3JUcmFja2luZyA9IGZhbHNlLFxuICAgIGNvbGxpc2lvbkF2b2lkYW5jZSA9IFBPUFVQX0NPTExJU0lPTl9BVk9JREFOQ0UsXG4gICAgc3R5bGUsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qgc3RvcmUgPSB1c2VUb29sdGlwUm9vdENvbnRleHQoKTtcbiAgY29uc3Qga2VlcE1vdW50ZWQgPSB1c2VUb29sdGlwUG9ydGFsQ29udGV4dCgpO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3QgbW91bnRlZCA9IHN0b3JlLnVzZVN0YXRlKCdtb3VudGVkJyk7XG4gIGNvbnN0IHRyYWNrQ3Vyc29yQXhpcyA9IHN0b3JlLnVzZVN0YXRlKCd0cmFja0N1cnNvckF4aXMnKTtcbiAgY29uc3QgZGlzYWJsZUhvdmVyYWJsZVBvcHVwID0gc3RvcmUudXNlU3RhdGUoJ2Rpc2FibGVIb3ZlcmFibGVQb3B1cCcpO1xuICBjb25zdCBmbG9hdGluZ1Jvb3RDb250ZXh0ID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nUm9vdENvbnRleHQnKTtcbiAgY29uc3QgaW5zdGFudFR5cGUgPSBzdG9yZS51c2VTdGF0ZSgnaW5zdGFudFR5cGUnKTtcbiAgY29uc3QgdHJhbnNpdGlvblN0YXR1cyA9IHN0b3JlLnVzZVN0YXRlKCd0cmFuc2l0aW9uU3RhdHVzJyk7XG4gIGNvbnN0IGFkYXB0aXZlT3JpZ2luID0gc3RvcmUudXNlU3RhdGUoJ2FkYXB0aXZlT3JpZ2luJyk7XG4gIGNvbnN0IHBvc2l0aW9uaW5nID0gdXNlQW5jaG9yUG9zaXRpb25pbmcoe1xuICAgIGFuY2hvcixcbiAgICBwb3NpdGlvbk1ldGhvZCxcbiAgICBmbG9hdGluZ1Jvb3RDb250ZXh0LFxuICAgIG1vdW50ZWQsXG4gICAgc2lkZSxcbiAgICBzaWRlT2Zmc2V0LFxuICAgIGFsaWduLFxuICAgIGFsaWduT2Zmc2V0LFxuICAgIGNvbGxpc2lvbkJvdW5kYXJ5LFxuICAgIGNvbGxpc2lvblBhZGRpbmcsXG4gICAgc3RpY2t5LFxuICAgIGFycm93UGFkZGluZyxcbiAgICBkaXNhYmxlQW5jaG9yVHJhY2tpbmcsXG4gICAga2VlcE1vdW50ZWQsXG4gICAgY29sbGlzaW9uQXZvaWRhbmNlLFxuICAgIGFkYXB0aXZlT3JpZ2luXG4gIH0pO1xuICBjb25zdCBzdGF0ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBvcGVuLFxuICAgIHNpZGU6IHBvc2l0aW9uaW5nLnNpZGUsXG4gICAgYWxpZ246IHBvc2l0aW9uaW5nLmFsaWduLFxuICAgIGFuY2hvckhpZGRlbjogcG9zaXRpb25pbmcuYW5jaG9ySGlkZGVuLFxuICAgIGluc3RhbnQ6IHRyYWNrQ3Vyc29yQXhpcyAhPT0gJ25vbmUnID8gJ3RyYWNraW5nLWN1cnNvcicgOiBpbnN0YW50VHlwZVxuICB9KSwgW29wZW4sIHBvc2l0aW9uaW5nLnNpZGUsIHBvc2l0aW9uaW5nLmFsaWduLCBwb3NpdGlvbmluZy5hbmNob3JIaWRkZW4sIHRyYWNrQ3Vyc29yQXhpcywgaW5zdGFudFR5cGVdKTtcbiAgY29uc3QgZWxlbWVudCA9IHVzZVBvc2l0aW9uZXIoY29tcG9uZW50UHJvcHMsIHN0YXRlLCB7XG4gICAgc3R5bGVzOiBwb3NpdGlvbmluZy5wb3NpdGlvbmVyU3R5bGVzLFxuICAgIHRyYW5zaXRpb25TdGF0dXMsXG4gICAgcHJvcHM6IGVsZW1lbnRQcm9wcyxcbiAgICByZWZzOiBbZm9yd2FyZGVkUmVmLCBzdG9yZS51c2VTdGF0ZVNldHRlcigncG9zaXRpb25lckVsZW1lbnQnKV0sXG4gICAgaGlkZGVuOiAhbW91bnRlZCxcbiAgICBpbmVydDogIW9wZW4gfHwgdHJhY2tDdXJzb3JBeGlzID09PSAnYm90aCcgfHwgZGlzYWJsZUhvdmVyYWJsZVBvcHVwXG4gIH0pO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goVG9vbHRpcFBvc2l0aW9uZXJDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IHBvc2l0aW9uaW5nLFxuICAgIGNoaWxkcmVuOiBlbGVtZW50XG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBUb29sdGlwUG9zaXRpb25lci5kaXNwbGF5TmFtZSA9IFwiVG9vbHRpcFBvc2l0aW9uZXJcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVRvb2x0aXBSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L1Rvb2x0aXBSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVRvb2x0aXBQb3NpdGlvbmVyQ29udGV4dCB9IGZyb20gXCIuLi9wb3NpdGlvbmVyL1Rvb2x0aXBQb3NpdGlvbmVyQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHBvcHVwVHJhbnNpdGlvblN0YXRlTWFwcGluZyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcbmltcG9ydCB7IHVzZU9wZW5DaGFuZ2VDb21wbGV0ZSB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlT3BlbkNoYW5nZUNvbXBsZXRlLm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVuZGVyRWxlbWVudCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlUmVuZGVyRWxlbWVudC5tanNcIjtcbmltcG9ydCB7IGdldERpc2FibGVkTW91bnRUcmFuc2l0aW9uU3R5bGVzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9nZXREaXNhYmxlZE1vdW50VHJhbnNpdGlvblN0eWxlcy5tanNcIjtcbmltcG9ydCB7IHVzZUhvdmVyRmxvYXRpbmdJbnRlcmFjdGlvbiB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9pbmRleC5tanNcIjtcbmltcG9ydCB7IEZPQ1VTQUJMRV9QT1BVUF9QUk9QUyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cHMvaW5kZXgubWpzXCI7XG5cbi8qKlxuICogQSBjb250YWluZXIgZm9yIHRoZSB0b29sdGlwIGNvbnRlbnRzLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBUb29sdGlwXShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvdG9vbHRpcClcbiAqL1xuZXhwb3J0IGNvbnN0IFRvb2x0aXBQb3B1cCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIFRvb2x0aXBQb3B1cChjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IHN0b3JlID0gdXNlVG9vbHRpcFJvb3RDb250ZXh0KCk7XG4gIGNvbnN0IHtcbiAgICBzaWRlLFxuICAgIGFsaWduXG4gIH0gPSB1c2VUb29sdGlwUG9zaXRpb25lckNvbnRleHQoKTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IGluc3RhbnRUeXBlID0gc3RvcmUudXNlU3RhdGUoJ2luc3RhbnRUeXBlJyk7XG4gIGNvbnN0IHRyYW5zaXRpb25TdGF0dXMgPSBzdG9yZS51c2VTdGF0ZSgndHJhbnNpdGlvblN0YXR1cycpO1xuICBjb25zdCBwb3B1cFByb3BzID0gc3RvcmUudXNlU3RhdGUoJ3BvcHVwUHJvcHMnKTtcbiAgY29uc3QgZmxvYXRpbmdDb250ZXh0ID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nUm9vdENvbnRleHQnKTtcbiAgY29uc3QgZGlzYWJsZWQgPSBzdG9yZS51c2VTdGF0ZSgnZGlzYWJsZWQnKTtcbiAgY29uc3QgY2xvc2VEZWxheSA9IHN0b3JlLnVzZVN0YXRlKCdjbG9zZURlbGF5Jyk7XG4gIHVzZU9wZW5DaGFuZ2VDb21wbGV0ZSh7XG4gICAgb3BlbixcbiAgICByZWY6IHN0b3JlLmNvbnRleHQucG9wdXBSZWYsXG4gICAgb25Db21wbGV0ZSgpIHtcbiAgICAgIGlmIChvcGVuKSB7XG4gICAgICAgIHN0b3JlLmNvbnRleHQub25PcGVuQ2hhbmdlQ29tcGxldGU/Lih0cnVlKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuICB1c2VIb3ZlckZsb2F0aW5nSW50ZXJhY3Rpb24oZmxvYXRpbmdDb250ZXh0LCB7XG4gICAgZW5hYmxlZDogIWRpc2FibGVkLFxuICAgIGNsb3NlRGVsYXlcbiAgfSk7XG4gIGNvbnN0IHNldFBvcHVwRWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlU2V0dGVyKCdwb3B1cEVsZW1lbnQnKTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgb3BlbixcbiAgICBzaWRlLFxuICAgIGFsaWduLFxuICAgIGluc3RhbnQ6IGluc3RhbnRUeXBlLFxuICAgIHRyYW5zaXRpb25TdGF0dXNcbiAgfTtcbiAgY29uc3QgZWxlbWVudCA9IHVzZVJlbmRlckVsZW1lbnQoJ2RpdicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgc3RhdGUsXG4gICAgcmVmOiBbZm9yd2FyZGVkUmVmLCBzdG9yZS5jb250ZXh0LnBvcHVwUmVmLCBzZXRQb3B1cEVsZW1lbnRdLFxuICAgIHByb3BzOiBbRk9DVVNBQkxFX1BPUFVQX1BST1BTLCBwb3B1cFByb3BzLCBnZXREaXNhYmxlZE1vdW50VHJhbnNpdGlvblN0eWxlcyh0cmFuc2l0aW9uU3RhdHVzKSwgZWxlbWVudFByb3BzXSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiBwb3B1cFRyYW5zaXRpb25TdGF0ZU1hcHBpbmdcbiAgfSk7XG4gIHJldHVybiBlbGVtZW50O1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBUb29sdGlwUG9wdXAuZGlzcGxheU5hbWUgPSBcIlRvb2x0aXBQb3B1cFwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlVG9vbHRpcFBvc2l0aW9uZXJDb250ZXh0IH0gZnJvbSBcIi4uL3Bvc2l0aW9uZXIvVG9vbHRpcFBvc2l0aW9uZXJDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgcG9wdXBTdGF0ZU1hcHBpbmcgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlVG9vbHRpcFJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvVG9vbHRpcFJvb3RDb250ZXh0Lm1qc1wiO1xuXG4vKipcbiAqIERpc3BsYXlzIGFuIGVsZW1lbnQgcG9zaXRpb25lZCBhZ2FpbnN0IHRoZSB0b29sdGlwIGFuY2hvci5cbiAqIFJlbmRlcnMgYSBgPGRpdj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgVG9vbHRpcF0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL3Rvb2x0aXApXG4gKi9cbmV4cG9ydCBjb25zdCBUb29sdGlwQXJyb3cgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBUb29sdGlwQXJyb3coY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIGNsYXNzTmFtZSxcbiAgICBzdHlsZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCBzdG9yZSA9IHVzZVRvb2x0aXBSb290Q29udGV4dCgpO1xuICBjb25zdCB7XG4gICAgYXJyb3dSZWYsXG4gICAgc2lkZSxcbiAgICBhbGlnbixcbiAgICBhcnJvd1VuY2VudGVyZWQsXG4gICAgYXJyb3dTdHlsZXNcbiAgfSA9IHVzZVRvb2x0aXBQb3NpdGlvbmVyQ29udGV4dCgpO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3QgaW5zdGFudFR5cGUgPSBzdG9yZS51c2VTdGF0ZSgnaW5zdGFudFR5cGUnKTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgb3BlbixcbiAgICBzaWRlLFxuICAgIGFsaWduLFxuICAgIHVuY2VudGVyZWQ6IGFycm93VW5jZW50ZXJlZCxcbiAgICBpbnN0YW50OiBpbnN0YW50VHlwZVxuICB9O1xuICBjb25zdCBlbGVtZW50ID0gdXNlUmVuZGVyRWxlbWVudCgnZGl2JywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICByZWY6IFtmb3J3YXJkZWRSZWYsIGFycm93UmVmXSxcbiAgICBwcm9wczogW3tcbiAgICAgIHN0eWxlOiBhcnJvd1N0eWxlcyxcbiAgICAgICdhcmlhLWhpZGRlbic6IHRydWVcbiAgICB9LCBlbGVtZW50UHJvcHNdLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmc6IHBvcHVwU3RhdGVNYXBwaW5nXG4gIH0pO1xuICByZXR1cm4gZWxlbWVudDtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgVG9vbHRpcEFycm93LmRpc3BsYXlOYW1lID0gXCJUb29sdGlwQXJyb3dcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEZsb2F0aW5nRGVsYXlHcm91cCB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9pbmRleC5tanNcIjtcbmltcG9ydCB7IFRvb2x0aXBQcm92aWRlckNvbnRleHQgfSBmcm9tIFwiLi9Ub29sdGlwUHJvdmlkZXJDb250ZXh0Lm1qc1wiO1xuXG4vKipcbiAqIFByb3ZpZGVzIGEgc2hhcmVkIGRlbGF5IGZvciBtdWx0aXBsZSB0b29sdGlwcy4gVGhlIGdyb3VwaW5nIGxvZ2ljIGVuc3VyZXMgdGhhdFxuICogb25jZSBhIHRvb2x0aXAgYmVjb21lcyB2aXNpYmxlLCB0aGUgYWRqYWNlbnQgdG9vbHRpcHMgd2lsbCBiZSBzaG93biBpbnN0YW50bHkuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgVG9vbHRpcF0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL3Rvb2x0aXApXG4gKi9cbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgY29uc3QgVG9vbHRpcFByb3ZpZGVyID0gZnVuY3Rpb24gVG9vbHRpcFByb3ZpZGVyKHByb3BzKSB7XG4gIGNvbnN0IHtcbiAgICBkZWxheSxcbiAgICBjbG9zZURlbGF5LFxuICAgIHRpbWVvdXQgPSA0MDBcbiAgfSA9IHByb3BzO1xuICBjb25zdCBkZWxheVZhbHVlID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIG9wZW46IGRlbGF5LFxuICAgIGNsb3NlOiBjbG9zZURlbGF5XG4gIH0pLCBbZGVsYXksIGNsb3NlRGVsYXldKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KFRvb2x0aXBQcm92aWRlckNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogZGVsYXksXG4gICAgY2hpbGRyZW46IC8qI19fUFVSRV9fKi9fanN4KEZsb2F0aW5nRGVsYXlHcm91cCwge1xuICAgICAgZGVsYXk6IGRlbGF5VmFsdWUsXG4gICAgICB0aW1lb3V0TXM6IHRpbWVvdXQsXG4gICAgICBjaGlsZHJlbjogcHJvcHMuY2hpbGRyZW5cbiAgICB9KVxuICB9KTtcbn07XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBUb29sdGlwUHJvdmlkZXIuZGlzcGxheU5hbWUgPSBcIlRvb2x0aXBQcm92aWRlclwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlVG9vbHRpcFJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvVG9vbHRpcFJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlVG9vbHRpcFBvc2l0aW9uZXJDb250ZXh0IH0gZnJvbSBcIi4uL3Bvc2l0aW9uZXIvVG9vbHRpcFBvc2l0aW9uZXJDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVuZGVyRWxlbWVudCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlUmVuZGVyRWxlbWVudC5tanNcIjtcbmltcG9ydCB7IHBvcHVwVmlld3BvcnRTdGF0ZU1hcHBpbmcsIHVzZVBvcHVwVmlld3BvcnQgfSBmcm9tIFwiLi4vLi4vdXRpbHMvdXNlUG9wdXBWaWV3cG9ydC5tanNcIjtcblxuLyoqXG4gKiBBIHZpZXdwb3J0IGZvciBkaXNwbGF5aW5nIGNvbnRlbnQgdHJhbnNpdGlvbnMuXG4gKiBUaGlzIGNvbXBvbmVudCBpcyBvbmx5IHJlcXVpcmVkIGlmIG9uZSBwb3B1cCBjYW4gYmUgb3BlbmVkIGJ5IG11bHRpcGxlIHRyaWdnZXJzLCBpdHMgY29udGVudFxuICogY2hhbmdlcyBiYXNlZCBvbiB0aGUgdHJpZ2dlciwgYW5kIHN3aXRjaGluZyBiZXR3ZWVuIHRoZW0gaXMgYW5pbWF0ZWQuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIFRvb2x0aXBdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy90b29sdGlwKVxuICovXG5leHBvcnQgY29uc3QgVG9vbHRpcFZpZXdwb3J0ID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gVG9vbHRpcFZpZXdwb3J0KGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgY2hpbGRyZW4sXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qgc3RvcmUgPSB1c2VUb29sdGlwUm9vdENvbnRleHQoKTtcbiAgY29uc3QgcG9zaXRpb25lciA9IHVzZVRvb2x0aXBQb3NpdGlvbmVyQ29udGV4dCgpO1xuICBjb25zdCBpbnN0YW50VHlwZSA9IHN0b3JlLnVzZVN0YXRlKCdpbnN0YW50VHlwZScpO1xuICBjb25zdCB7XG4gICAgY2hpbGRyZW46IGNoaWxkcmVuVG9SZW5kZXIsXG4gICAgc3RhdGU6IHZpZXdwb3J0U3RhdGVcbiAgfSA9IHVzZVBvcHVwVmlld3BvcnQoe1xuICAgIHN0b3JlLFxuICAgIHNpZGU6IHBvc2l0aW9uZXIuc2lkZSxcbiAgICBjaGlsZHJlblxuICB9KTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgYWN0aXZhdGlvbkRpcmVjdGlvbjogdmlld3BvcnRTdGF0ZS5hY3RpdmF0aW9uRGlyZWN0aW9uLFxuICAgIHRyYW5zaXRpb25pbmc6IHZpZXdwb3J0U3RhdGUudHJhbnNpdGlvbmluZyxcbiAgICBpbnN0YW50OiBpbnN0YW50VHlwZVxuICB9O1xuICByZXR1cm4gdXNlUmVuZGVyRWxlbWVudCgnZGl2JywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICBwcm9wczogW2VsZW1lbnRQcm9wcywge1xuICAgICAgY2hpbGRyZW46IGNoaWxkcmVuVG9SZW5kZXJcbiAgICB9XSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiBwb3B1cFZpZXdwb3J0U3RhdGVNYXBwaW5nXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBUb29sdGlwVmlld3BvcnQuZGlzcGxheU5hbWUgPSBcIlRvb2x0aXBWaWV3cG9ydFwiOyIsImltcG9ydCB7IGNyZWF0ZU51bGxUb29sdGlwU3RvcmUgfSBmcm9tIFwiLi9Ub29sdGlwU3RvcmUubWpzXCI7XG5pbXBvcnQgeyBCYXNlUG9wdXBIYW5kbGUgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBzL3BvcHVwSGFuZGxlLm1qc1wiO1xuXG4vKipcbiAqIENvbnRyb2xzIGEgVG9vbHRpcCBpbXBlcmF0aXZlbHkgYW5kIGFzc29jaWF0ZXMgZGV0YWNoZWQgYFRvb2x0aXAuVHJpZ2dlcmAgY29tcG9uZW50cyB3aXRoIGFcbiAqIGBUb29sdGlwLlJvb3RgLiBDcmVhdGUgb25lIHdpdGggYFRvb2x0aXAuY3JlYXRlSGFuZGxlKClgIGFuZCBwYXNzIGl0IHRvIHRoZSBgaGFuZGxlYCBwcm9wIG9mIHRoZVxuICogcm9vdCBhbmQgb2YgYW55IHRyaWdnZXJzIHJlbmRlcmVkIG91dHNpZGUgb2YgaXQuXG4gKlxuICogVGhlIGltcGVyYXRpdmUgbWV0aG9kcyB0YWtlIGVmZmVjdCBvbmx5IHdoaWxlIGEgcm9vdCB1c2luZyB0aGlzIGhhbmRsZSBpcyBtb3VudGVkOyBjYWxscyBtYWRlXG4gKiBiZWZvcmUgYSByb290IGF0dGFjaGVzIChvciBhZnRlciBpdCB1bm1vdW50cykgYXJlIGlnbm9yZWQuXG4gKi9cbmV4cG9ydCBjbGFzcyBUb29sdGlwSGFuZGxlIGV4dGVuZHMgQmFzZVBvcHVwSGFuZGxlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoY3JlYXRlTnVsbFRvb2x0aXBTdG9yZSgpLCAnVG9vbHRpcCcpO1xuICB9XG5cbiAgLyoqXG4gICAqIE9wZW5zIHRoZSB0b29sdGlwIGFuZCBhc3NvY2lhdGVzIGl0IHdpdGggdGhlIHRyaWdnZXIgd2l0aCB0aGUgZ2l2ZW4gaWQuXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBpbiBhbiBldmVudCBoYW5kbGVyIG9yIGFuIGVmZmVjdCAobm90IGR1cmluZyByZW5kZXJpbmcpLlxuICAgKlxuICAgKiBAcGFyYW0gdHJpZ2dlcklkIElEIG9mIHRoZSB0cmlnZ2VyIHRvIGFzc29jaWF0ZSB3aXRoIHRoZSB0b29sdGlwLiBUaGUgdHJpZ2dlciBtdXN0IGJlIGEgbWF0Y2hpbmdcbiAgICogYFRvb2x0aXAuVHJpZ2dlcmAgd2l0aCB0aGlzIGhhbmRsZSBwYXNzZWQgYXMgYSBwcm9wLlxuICAgKi9cbiAgb3Blbih0cmlnZ2VySWQpIHtcbiAgICB0aGlzLm9wZW5CeVRyaWdnZXIodHJpZ2dlcklkKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDbG9zZXMgdGhlIHRvb2x0aXAuXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBpbiBhbiBldmVudCBoYW5kbGVyIG9yIGFuIGVmZmVjdCAobm90IGR1cmluZyByZW5kZXJpbmcpLlxuICAgKi9cbiAgY2xvc2UoKSB7XG4gICAgdGhpcy5jbG9zZVBvcHVwKCk7XG4gIH1cblxuICAvKipcbiAgICogV2hldGhlciB0aGUgdG9vbHRpcCBpcyBjdXJyZW50bHkgb3Blbi4gUmV0dXJucyBgZmFsc2VgIHdoaWxlIG5vIHJvb3QgaXMgYXR0YWNoZWQgdG8gdGhlIGhhbmRsZS5cbiAgICovXG4gIGdldCBpc09wZW4oKSB7XG4gICAgcmV0dXJuIHRoaXMuYXR0YWNoZWRTdG9yZT8uc2VsZWN0KCdvcGVuJykgPz8gZmFsc2U7XG4gIH1cbn1cblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IGhhbmRsZSB0byBjb25uZWN0IGEgVG9vbHRpcC5Sb290IHdpdGggZGV0YWNoZWQgVG9vbHRpcC5UcmlnZ2VyIGNvbXBvbmVudHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVUb29sdGlwSGFuZGxlKCkge1xuICByZXR1cm4gbmV3IFRvb2x0aXBIYW5kbGUoKTtcbn0iLCJleHBvcnQgeyBUb29sdGlwUm9vdCBhcyBSb290IH0gZnJvbSBcIi4vcm9vdC9Ub29sdGlwUm9vdC5tanNcIjtcbmV4cG9ydCB7IFRvb2x0aXBUcmlnZ2VyIGFzIFRyaWdnZXIgfSBmcm9tIFwiLi90cmlnZ2VyL1Rvb2x0aXBUcmlnZ2VyLm1qc1wiO1xuZXhwb3J0IHsgVG9vbHRpcFBvcnRhbCBhcyBQb3J0YWwgfSBmcm9tIFwiLi9wb3J0YWwvVG9vbHRpcFBvcnRhbC5tanNcIjtcbmV4cG9ydCB7IFRvb2x0aXBQb3NpdGlvbmVyIGFzIFBvc2l0aW9uZXIgfSBmcm9tIFwiLi9wb3NpdGlvbmVyL1Rvb2x0aXBQb3NpdGlvbmVyLm1qc1wiO1xuZXhwb3J0IHsgVG9vbHRpcFBvcHVwIGFzIFBvcHVwIH0gZnJvbSBcIi4vcG9wdXAvVG9vbHRpcFBvcHVwLm1qc1wiO1xuZXhwb3J0IHsgVG9vbHRpcEFycm93IGFzIEFycm93IH0gZnJvbSBcIi4vYXJyb3cvVG9vbHRpcEFycm93Lm1qc1wiO1xuZXhwb3J0IHsgVG9vbHRpcFByb3ZpZGVyIGFzIFByb3ZpZGVyIH0gZnJvbSBcIi4vcHJvdmlkZXIvVG9vbHRpcFByb3ZpZGVyLm1qc1wiO1xuZXhwb3J0IHsgVG9vbHRpcFZpZXdwb3J0IGFzIFZpZXdwb3J0IH0gZnJvbSBcIi4vdmlld3BvcnQvVG9vbHRpcFZpZXdwb3J0Lm1qc1wiO1xuZXhwb3J0IHsgY3JlYXRlVG9vbHRpcEhhbmRsZSBhcyBjcmVhdGVIYW5kbGUsIFRvb2x0aXBIYW5kbGUgYXMgSGFuZGxlIH0gZnJvbSBcIi4vc3RvcmUvVG9vbHRpcEhhbmRsZS5tanNcIjsiLCIvKipcbiAqIFRoZSBhdmFpbGFibGUgd2lkdGggYmV0d2VlbiB0aGUgdHJpZ2dlciBhbmQgdGhlIGVkZ2Ugb2YgdGhlIHZpZXdwb3J0LlxuICogQHR5cGUge251bWJlcn1cbiAqL1xuZXhwb3J0IGNvbnN0IGF2YWlsYWJsZVdpZHRoID0gJy0tYXZhaWxhYmxlLXdpZHRoJztcbi8qKlxuICogVGhlIGF2YWlsYWJsZSBoZWlnaHQgYmV0d2VlbiB0aGUgdHJpZ2dlciBhbmQgdGhlIGVkZ2Ugb2YgdGhlIHZpZXdwb3J0LlxuICogQHR5cGUge251bWJlcn1cbiAqL1xuZXhwb3J0IGNvbnN0IGF2YWlsYWJsZUhlaWdodCA9ICctLWF2YWlsYWJsZS1oZWlnaHQnO1xuLyoqXG4gKiBUaGUgYW5jaG9yJ3Mgd2lkdGguXG4gKiBAdHlwZSB7bnVtYmVyfVxuICovXG5leHBvcnQgY29uc3QgYW5jaG9yV2lkdGggPSAnLS1hbmNob3Itd2lkdGgnO1xuLyoqXG4gKiBUaGUgYW5jaG9yJ3MgaGVpZ2h0LlxuICogQHR5cGUge251bWJlcn1cbiAqL1xuZXhwb3J0IGNvbnN0IGFuY2hvckhlaWdodCA9ICctLWFuY2hvci1oZWlnaHQnO1xuLyoqXG4gKiBUaGUgY29vcmRpbmF0ZXMgdGhhdCB0aGlzIGVsZW1lbnQgaXMgYW5jaG9yZWQgdG8uIFVzZWQgZm9yIGFuaW1hdGlvbnMgYW5kIHRyYW5zaXRpb25zLlxuICogQHR5cGUge3N0cmluZ31cbiAqL1xuZXhwb3J0IGNvbnN0IHRyYW5zZm9ybU9yaWdpbiA9ICctLXRyYW5zZm9ybS1vcmlnaW4nO1xuLyoqXG4gKiBUaGUgd2lkdGggb2YgdGhlIHRvb2x0aXAncyBwb3NpdGlvbmVyLlxuICogSXQgaXMgaW1wb3J0YW50IHRvIHNldCBgd2lkdGhgIHRvIHRoaXMgdmFsdWUgd2hlbiB1c2luZyBDU1MgdG8gYW5pbWF0ZSBzaXplIGNoYW5nZXMuXG4gKiBAdHlwZSB7bnVtYmVyfVxuICovXG5leHBvcnQgY29uc3QgcG9zaXRpb25lcldpZHRoID0gJy0tcG9zaXRpb25lci13aWR0aCc7XG4vKipcbiAqIFRoZSBoZWlnaHQgb2YgdGhlIHRvb2x0aXAncyBwb3NpdGlvbmVyLlxuICogSXQgaXMgaW1wb3J0YW50IHRvIHNldCBgaGVpZ2h0YCB0byB0aGlzIHZhbHVlIHdoZW4gdXNpbmcgQ1NTIHRvIGFuaW1hdGUgc2l6ZSBjaGFuZ2VzLlxuICogQHR5cGUge251bWJlcn1cbiAqL1xuZXhwb3J0IGNvbnN0IHBvc2l0aW9uZXJIZWlnaHQgPSAnLS1wb3NpdGlvbmVyLWhlaWdodCc7IiwiaW1wb3J0IHsgQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHRvb2x0aXAgaXMgb3Blbi5cbiAqL1xuZXhwb3J0IGNvbnN0IG9wZW4gPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW47XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgdG9vbHRpcCBpcyBjbG9zZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBjbG9zZWQgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmNsb3NlZDtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBhbmNob3IgaXMgaGlkZGVuLlxuICovXG5leHBvcnQgY29uc3QgYW5jaG9ySGlkZGVuID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5hbmNob3JIaWRkZW47XG4vKipcbiAqIEluZGljYXRlcyB3aGljaCBzaWRlIHRoZSBwb3B1cCBpcyBwb3NpdGlvbmVkIHJlbGF0aXZlIHRvIHRoZSB0cmlnZ2VyLlxuICogQHR5cGUgeyd0b3AnIHwgJ2JvdHRvbScgfCAnbGVmdCcgfCAncmlnaHQnIHwgJ2lubGluZS1lbmQnIHwgJ2lubGluZS1zdGFydCd9XG4gKi9cbmV4cG9ydCBjb25zdCBzaWRlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zaWRlO1xuLyoqXG4gKiBJbmRpY2F0ZXMgaG93IHRoZSBwb3B1cCBpcyBhbGlnbmVkIHJlbGF0aXZlIHRvIHNwZWNpZmllZCBzaWRlLlxuICogQHR5cGUgeydzdGFydCcgfCAnY2VudGVyJyB8ICdlbmQnfVxuICovXG5leHBvcnQgY29uc3QgYWxpZ24gPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmFsaWduOyIsImltcG9ydCB7IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSB0b29sdGlwIGlzIG9wZW4uXG4gKi9cbmV4cG9ydCBjb25zdCBvcGVuID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5vcGVuO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHRvb2x0aXAgaXMgY2xvc2VkLlxuICovXG5leHBvcnQgY29uc3QgY2xvc2VkID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5jbG9zZWQ7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgdG9vbHRpcCBiZWdpbnMgYW5pbWF0aW5nIGluLlxuICovXG5leHBvcnQgY29uc3Qgc3RhcnRpbmdTdHlsZSA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuc3RhcnRpbmdTdHlsZTtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSB0b29sdGlwIGlzIGFuaW1hdGluZyBvdXQuXG4gKi9cbmV4cG9ydCBjb25zdCBlbmRpbmdTdHlsZSA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuZW5kaW5nU3R5bGU7XG4vKipcbiAqIEluZGljYXRlcyB3aGljaCBzaWRlIHRoZSBwb3B1cCBpcyBwb3NpdGlvbmVkIHJlbGF0aXZlIHRvIHRoZSB0cmlnZ2VyLlxuICogQHR5cGUgeyd0b3AnIHwgJ2JvdHRvbScgfCAnbGVmdCcgfCAncmlnaHQnIHwgJ2lubGluZS1lbmQnIHwgJ2lubGluZS1zdGFydCd9XG4gKi9cbmV4cG9ydCBjb25zdCBzaWRlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zaWRlO1xuLyoqXG4gKiBJbmRpY2F0ZXMgaG93IHRoZSBwb3B1cCBpcyBhbGlnbmVkIHJlbGF0aXZlIHRvIHNwZWNpZmllZCBzaWRlLlxuICogQHR5cGUgeydzdGFydCcgfCAnY2VudGVyJyB8ICdlbmQnfVxuICovXG5leHBvcnQgY29uc3QgYWxpZ24gPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmFsaWduO1xuLyoqXG4gKiBQcmVzZW50IGlmIGFuaW1hdGlvbnMgc2hvdWxkIGJlIGluc3RhbnQuXG4gKiBAdHlwZSB7J2RlbGF5JyB8ICdkaXNtaXNzJyB8ICdmb2N1cyd9XG4gKi9cbmV4cG9ydCBjb25zdCBpbnN0YW50ID0gJ2RhdGEtaW5zdGFudCc7IiwiaW1wb3J0IHsgQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHRvb2x0aXAgaXMgb3Blbi5cbiAqL1xuZXhwb3J0IGNvbnN0IG9wZW4gPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW47XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgdG9vbHRpcCBpcyBjbG9zZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBjbG9zZWQgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmNsb3NlZDtcbi8qKlxuICogSW5kaWNhdGVzIHdoaWNoIHNpZGUgdGhlIHBvcHVwIGlzIHBvc2l0aW9uZWQgcmVsYXRpdmUgdG8gdGhlIHRyaWdnZXIuXG4gKiBAdHlwZSB7J3RvcCcgfCAnYm90dG9tJyB8ICdsZWZ0JyB8ICdyaWdodCcgfCAnaW5saW5lLWVuZCcgfCAnaW5saW5lLXN0YXJ0J31cbiAqL1xuZXhwb3J0IGNvbnN0IHNpZGUgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnNpZGU7XG4vKipcbiAqIEluZGljYXRlcyBob3cgdGhlIHBvcHVwIGlzIGFsaWduZWQgcmVsYXRpdmUgdG8gc3BlY2lmaWVkIHNpZGUuXG4gKiBAdHlwZSB7J3N0YXJ0JyB8ICdjZW50ZXInIHwgJ2VuZCd9XG4gKi9cbmV4cG9ydCBjb25zdCBhbGlnbiA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuYWxpZ247XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgdG9vbHRpcCBhcnJvdyBpcyB1bmNlbnRlcmVkLlxuICovXG5leHBvcnQgY29uc3QgdW5jZW50ZXJlZCA9ICdkYXRhLXVuY2VudGVyZWQnO1xuLyoqXG4gKiBQcmVzZW50IGlmIGFuaW1hdGlvbnMgc2hvdWxkIGJlIGluc3RhbnQuXG4gKiBAdHlwZSB7J2RlbGF5JyB8ICdkaXNtaXNzJyB8ICdmb2N1cyd9XG4gKi9cbmV4cG9ydCBjb25zdCBpbnN0YW50ID0gJ2RhdGEtaW5zdGFudCc7IiwiLyoqXG4gKiBUaGUgd2lkdGggb2YgdGhlIHBhcmVudCBwb3B1cC5cbiAqIFRoaXMgdmFyaWFibGUgaXMgcGxhY2VkIG9uIHRoZSAncHJldmlvdXMnIGNvbnRhaW5lciBhbmQgc3RvcmVzIHRoZSB3aWR0aCBvZiB0aGUgcG9wdXAgd2hlbiB0aGUgcHJldmlvdXMgY29udGVudCB3YXMgcmVuZGVyZWQuXG4gKiBJdCBjYW4gYmUgdXNlZCB0byBmcmVlemUgdGhlIGRpbWVuc2lvbnMgb2YgdGhlIHBvcHVwIHdoZW4gYW5pbWF0aW5nIGJldHdlZW4gZGlmZmVyZW50IGNvbnRlbnQuXG4gKi9cbmV4cG9ydCBjb25zdCBwb3B1cFdpZHRoID0gJy0tcG9wdXAtd2lkdGgnO1xuLyoqXG4gKiBUaGUgaGVpZ2h0IG9mIHRoZSBwYXJlbnQgcG9wdXAuXG4gKiBUaGlzIHZhcmlhYmxlIGlzIHBsYWNlZCBvbiB0aGUgJ3ByZXZpb3VzJyBjb250YWluZXIgYW5kIHN0b3JlcyB0aGUgaGVpZ2h0IG9mIHRoZSBwb3B1cCB3aGVuIHRoZSBwcmV2aW91cyBjb250ZW50IHdhcyByZW5kZXJlZC5cbiAqIEl0IGNhbiBiZSB1c2VkIHRvIGZyZWV6ZSB0aGUgZGltZW5zaW9ucyBvZiB0aGUgcG9wdXAgd2hlbiBhbmltYXRpbmcgYmV0d2VlbiBkaWZmZXJlbnQgY29udGVudC5cbiAqL1xuZXhwb3J0IGNvbnN0IHBvcHVwSGVpZ2h0ID0gJy0tcG9wdXAtaGVpZ2h0JzsiLCIvKipcbiAqIEFwcGxpZWQgdG8gdGhlIGRpcmVjdCBjaGlsZCBvZiB0aGUgdmlld3BvcnQgd2hlbiBubyB0cmFuc2l0aW9ucyBhcmUgcHJlc2VudCBvciB0aGUgbmV3IGNvbnRlbnQgd2hlbiBpdCdzIGVudGVyaW5nLlxuICovXG5leHBvcnQgY29uc3QgY3VycmVudCA9ICdkYXRhLWN1cnJlbnQnO1xuLyoqXG4gKiBBcHBsaWVkIHRvIHRoZSBkaXJlY3QgY2hpbGQgb2YgdGhlIHZpZXdwb3J0IHRoYXQgY29udGFpbnMgdGhlIGV4aXRpbmcgY29udGVudCB3aGVuIHRyYW5zaXRpb25zIGFyZSBwcmVzZW50LlxuICovXG5leHBvcnQgY29uc3QgcHJldmlvdXMgPSAnZGF0YS1wcmV2aW91cyc7XG4vKipcbiAqIEluZGljYXRlcyB0aGUgZGlyZWN0aW9uIGZyb20gd2hpY2ggdGhlIHBvcHVwIHdhcyBhY3RpdmF0ZWQuXG4gKiBUaGlzIGNhbiBiZSB1c2VkIHRvIGNyZWF0ZSBkaXJlY3Rpb25hbCBhbmltYXRpb25zIGJhc2VkIG9uIGhvdyB0aGUgcG9wdXAgd2FzIHRyaWdnZXJlZC5cbiAqIENvbnRhaW5zIHNwYWNlLXNlcGFyYXRlZCB2YWx1ZXMgZm9yIGJvdGggaG9yaXpvbnRhbCBhbmQgdmVydGljYWwgYXhlcy5cbiAqIEB0eXBlIHtgJHsnbGVmdCcgfCAncmlnaHQnIHwgJyd9ICR7J2Rvd24nIHwgJ3VwJyB8ICcnfWB9XG4gKi9cbmV4cG9ydCBjb25zdCBhY3RpdmF0aW9uRGlyZWN0aW9uID0gJ2RhdGEtYWN0aXZhdGlvbi1kaXJlY3Rpb24nO1xuLyoqXG4gKiBJbmRpY2F0ZXMgdGhhdCB0aGUgdmlld3BvcnQgaXMgY3VycmVudGx5IHRyYW5zaXRpb25pbmcgYmV0d2VlbiBvbGQgYW5kIG5ldyBjb250ZW50LlxuICovXG5leHBvcnQgY29uc3QgdHJhbnNpdGlvbmluZyA9ICdkYXRhLXRyYW5zaXRpb25pbmcnO1xuLyoqXG4gKiBQcmVzZW50IGlmIGFuaW1hdGlvbnMgc2hvdWxkIGJlIGluc3RhbnQuXG4gKiBAdHlwZSB7J2RlbGF5JyB8ICdkaXNtaXNzJyB8ICdmb2N1cyd9XG4gKi9cbmV4cG9ydCBjb25zdCBpbnN0YW50ID0gJ2RhdGEtaW5zdGFudCc7Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQVNBLElBQU0sNEJBQXlDLDJCQUFNLGNBQWM7Q0FDakUsYUFBYTtDQUNiLFdBQVc7Q0FDWCxVQUFVLEVBQ1IsU0FBUyxFQUNYO0NBQ0EsaUJBQWlCLEVBQ2YsU0FBUyxFQUNYO0NBQ0EsU0FBUyxJQUFJLFFBQVE7Q0FDckIsY0FBYyxFQUNaLFNBQVMsS0FDWDtDQUNBLG1CQUFtQixFQUNqQixTQUFTLEtBQ1g7QUFDRixDQUFDO0FBQzBDLDBCQUEwQixjQUFjO0FBQ25GLFNBQVMsY0FBYyxVQUFVLGlCQUFpQjtDQUNoRCxTQUFTLFVBQVUsZ0JBQWdCO0FBQ3JDOzs7Ozs7Ozs7OztBQVdBLFNBQWdCLG1CQUFtQixPQUFPO0NBQ3hDLE1BQU0sRUFDSixVQUNBLE9BQ0EsWUFBWSxNQUNWO0NBQ0osTUFBTSxXQUFBLGFBQWlCLE9BQU8sS0FBSztDQUNuQyxNQUFNLGtCQUFBLGFBQXdCLE9BQU8sS0FBSztDQUMxQyxNQUFNLGVBQUEsYUFBcUIsT0FBTyxJQUFJO0NBQ3RDLE1BQU0sb0JBQUEsYUFBMEIsT0FBTyxJQUFJO0NBQzNDLE1BQU0sVUFBVSxXQUFXO0NBQzNCLHlCQUF5QjtFQUN2QixnQkFBZ0IsVUFBVTtFQUMxQixJQUFJLENBQUMsYUFBYSxTQUFTO0dBQ3pCLFNBQVMsVUFBVTtHQUNuQjtFQUNGO0VBQ0EsU0FBUyxVQUFVO0dBQ2pCLE1BQU0sU0FBUyxTQUFTLFNBQVMsTUFBTTtHQUN2QyxPQUFPLFNBQVMsT0FBTyxPQUFPO0VBQ2hDO0NBQ0YsR0FBRztFQUFDO0VBQU87RUFBYztFQUFVO0NBQWUsQ0FBQztDQUNuRCxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLDBCQUEwQixVQUFVO0VBQzNELE9BQUEsYUFBYSxlQUFlO0dBQzFCLGFBQWE7R0FDYjtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7RUFDRixJQUFJLENBQUMsV0FBVyxPQUFPLENBQUM7RUFDZDtDQUNaLENBQUM7QUFDSDs7Ozs7OztBQU9BLFNBQWdCLGNBQWMsT0FBTyxVQUFVLEVBQzdDLE1BQU0sTUFDUixHQUFHO0NBQ0QsTUFBTSxFQUNKLFNBQ0U7Q0FDSixNQUFNLGFBQWEsTUFBTSxTQUFTLFlBQVk7Q0FFOUMsTUFBTSxFQUNKLGNBQ0EsVUFDQSxXQUNBLGlCQUNBLG1CQUNBLGFBQ0EsWUFBQSxhQVJ5QixXQUFXLHlCQVN2QjtDQUNmLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQUEsYUFBMkIsU0FBUyxLQUFLO0NBQ2hFLE1BQU0sVUFBQSxhQUFnQixPQUFPLElBQUk7Q0FDakMseUJBQXlCO0VBQ3ZCLFFBQVEsVUFBVTtDQUNwQixHQUFHLENBQUMsSUFBSSxDQUFDO0NBQ1QseUJBQXlCO0VBQ3ZCLFNBQVMsUUFBUTtHQUNmLGtCQUFrQixTQUFTLGtCQUFrQixLQUFLO0dBQ2xELGFBQWEsVUFBVTtHQUN2QixrQkFBa0IsVUFBVTtHQUM1QixTQUFTLFVBQVUsZ0JBQWdCO0dBQ25DLFFBQVEsTUFBTTtFQUNoQjtFQUNBLElBQUksQ0FBQyxhQUFhLFNBQ2hCO0VBRUYsSUFBSSxDQUFDLFFBQVEsYUFBYSxZQUFZLFlBQVk7R0FDaEQsa0JBQWtCLEtBQUs7R0FDdkIsSUFBSSxXQUFXO0lBQ2IsTUFBTSxZQUFZO0lBQ2xCLFFBQVEsTUFBTSxpQkFBaUI7S0FFN0IsSUFBSSxNQUFNLE9BQU8sTUFBTSxLQUFLLGFBQWEsV0FBVyxhQUFhLFlBQVksV0FDM0U7S0FFRixNQUFNO0lBQ1IsQ0FBQztJQUNELGFBQWE7S0FDWCxJQUFJLFFBQVEsV0FBVyxhQUFhLFlBQVksV0FDOUMsUUFBUSxNQUFNO0lBRWxCO0dBQ0Y7R0FDQSxNQUFNO0VBQ1I7Q0FFRixHQUFHO0VBQUM7RUFBTTtFQUFZO0VBQWM7RUFBVTtFQUFXO0VBQWlCO0VBQW1CO0VBQVM7Q0FBSyxDQUFDO0NBQzVHLHlCQUF5QjtFQUN2QixJQUFJLENBQUMsTUFDSDtFQUVGLE1BQU0sY0FBYyxrQkFBa0I7RUFDdEMsTUFBTSxTQUFTLGFBQWE7RUFJNUIsUUFBUSxNQUFNO0VBQ2Qsa0JBQWtCLFVBQVU7R0FDMUIsY0FBYyxNQUFNO0dBQ3BCO0VBQ0Y7RUFDQSxhQUFhLFVBQVU7RUFDdkIsU0FBUyxVQUFVO0dBQ2pCLE1BQU07R0FDTixPQUFPLFNBQVMsZ0JBQWdCLFNBQVMsT0FBTztFQUNsRDtFQUNBLElBQUksV0FBVyxRQUFRLFdBQVcsWUFBWTtHQUM1QyxrQkFBa0IsSUFBSTtHQUN0QixhQUFhLGtCQUFrQixJQUFJO0dBQ25DLGFBQWEsYUFBYSxPQUFPLHlCQUF5QkEsSUFBWSxDQUFDO0VBQ3pFLE9BQU87R0FDTCxrQkFBa0IsS0FBSztHQUN2QixhQUFhLGtCQUFrQixLQUFLO0VBQ3RDO0NBQ0YsR0FBRztFQUFDO0VBQU07RUFBWTtFQUFPO0VBQWM7RUFBVTtFQUFpQjtFQUFtQjtDQUFPLENBQUM7Q0FDakcseUJBQXlCO0VBQ3ZCLGFBQWE7R0FDWCxJQUFJLGFBQWEsWUFBWSxZQUFZO0lBQ3ZDLGtCQUFrQixVQUFVO0lBQzVCLElBQUksQ0FBQyxRQUFRLFNBQ1g7SUFFRixhQUFhLFVBQVU7SUFDdkIsY0FBYyxVQUFVLGVBQWU7SUFDdkMsUUFBUSxNQUFNO0dBQ2hCO0VBQ0Y7Q0FDRixHQUFHO0VBQUM7RUFBbUI7RUFBYztFQUFVO0VBQVk7RUFBaUI7Q0FBTyxDQUFDO0NBQ3BGLE9BQUEsYUFBYSxlQUFlO0VBQzFCLGFBQWE7RUFDYjtFQUNBO0VBQ0E7Q0FDRixJQUFJO0VBQUM7RUFBYztFQUFhO0VBQVU7Q0FBYyxDQUFDO0FBQzNEOztBQzlLQSxTQUFTLHFCQUFxQixZQUFZLE1BQU07Q0FDOUMsSUFBSSxVQUFVO0NBQ2QsSUFBSSxVQUFVO0NBQ2QsSUFBSSxvQkFBb0I7Q0FDeEIsT0FBTztFQUNMLGdCQUFnQixjQUFjLEtBQUE7RUFDOUIsd0JBQXdCO0dBQ3RCLE1BQU0sVUFBVSxZQUFZLHNCQUFzQixLQUFLO0lBQ3JELE9BQU87SUFDUCxRQUFRO0lBQ1IsR0FBRztJQUNILEdBQUc7R0FDTDtHQUNBLE1BQU0sVUFBVSxLQUFLLFNBQVMsT0FBTyxLQUFLLFNBQVM7R0FDbkQsTUFBTSxVQUFVLEtBQUssU0FBUyxPQUFPLEtBQUssU0FBUztHQUNuRCxNQUFNLDZCQUE2QixDQUFDLGNBQWMsV0FBVyxDQUFDLENBQUMsU0FBUyxLQUFLLFFBQVEsUUFBUSxXQUFXLFFBQVEsRUFBRSxLQUFLLEtBQUssZ0JBQWdCO0dBQzVJLE1BQU0sUUFBUSxLQUFLLFNBQVMsTUFBTSxRQUFRLFFBQVE7R0FDbEQsTUFBTSxTQUFTLEtBQUssU0FBUyxNQUFNLFFBQVEsU0FBUztHQUNwRCxJQUFJLElBQUksUUFBUTtHQUNoQixJQUFJLElBQUksUUFBUTtHQUNoQixJQUFJLFdBQVcsUUFBUSxLQUFLLEtBQUssU0FDL0IsVUFBVSxRQUFRLElBQUksS0FBSztHQUU3QixJQUFJLFdBQVcsUUFBUSxLQUFLLEtBQUssU0FDL0IsVUFBVSxRQUFRLElBQUksS0FBSztHQUU3QixLQUFLLFdBQVc7R0FDaEIsS0FBSyxXQUFXO0dBQ2hCLElBQUksQ0FBQyxxQkFBcUIsNEJBQTRCO0lBQ3BELElBQUksV0FBVyxLQUFLLEtBQUssT0FBTyxLQUFLLElBQUk7SUFDekMsSUFBSSxXQUFXLEtBQUssS0FBSyxPQUFPLEtBQUssSUFBSTtHQUMzQztHQUNBLG9CQUFvQjtHQUNwQixPQUFPO0lBQ0w7SUFDQTtJQUNBO0lBQ0E7SUFDQSxLQUFLO0lBQ0wsT0FBTyxJQUFJO0lBQ1gsUUFBUSxJQUFJO0lBQ1osTUFBTTtHQUNSO0VBQ0Y7Q0FDRjtBQUNGO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTztDQUNoQyxPQUFPLFNBQVMsUUFBUSxNQUFNLFdBQVc7QUFDM0M7Ozs7OztBQU1BLFNBQWdCLGVBQWUsT0FBTyxRQUFRLENBQUMsR0FBRztDQUNoRCxNQUFNLEVBQ0osVUFBVSxNQUNWLE9BQU8sV0FDTDtDQUNKLE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLFdBQVcsTUFBTSxTQUFTLGlCQUFpQjtDQUNqRCxNQUFNLGVBQWUsTUFBTSxTQUFTLHFCQUFxQjtDQUN6RCxNQUFNLFVBQVUsTUFBTSxRQUFRO0NBQzlCLE1BQU0sYUFBQSxhQUFtQixPQUFPLEtBQUs7Q0FDckMsTUFBTSxxQkFBQSxhQUEyQixPQUFPLElBQUk7Q0FDNUMsTUFBTSxDQUFDLGFBQWEsa0JBQUEsYUFBd0IsU0FBUztDQUNyRCxNQUFNLENBQUMsVUFBVSxlQUFBLGFBQXFCLFNBQVMsQ0FBQyxDQUFDO0NBQ2pELE1BQU0saUJBQWlCLG1CQUFrQixjQUFhO0VBQ3BELE1BQU0sSUFBSSxxQkFBcUIsU0FBUztDQUMxQyxDQUFDO0NBQ0QsTUFBTSxlQUFlLG1CQUFtQixNQUFNLE1BQU0scUJBQXFCO0VBQ3ZFLElBQUksV0FBVyxTQUNiO0VBTUYsSUFBSSxRQUFRLFFBQVEsYUFBYSxDQUFDLGtCQUFrQixRQUFRLFFBQVEsU0FBUyxHQUMzRTtFQUVGLE1BQU0sSUFBSSxxQkFBcUIscUJBQXFCLG9CQUFvQixjQUFjO0dBQ3BGLEdBQUc7R0FDSCxHQUFHO0dBQ0g7R0FDQTtHQUNBO0VBQ0YsQ0FBQyxDQUFDO0NBQ0osQ0FBQztDQUNELE1BQU0sNkJBQTZCLG1CQUFrQixVQUFTO0VBQzVELElBQUksQ0FBQyxNQUNILGFBQWEsTUFBTSxTQUFTLE1BQU0sU0FBUyxNQUFNLGFBQWE7T0FDekQsSUFBSSxDQUFDLG1CQUFtQixTQUFTO0dBSXRDLGFBQWEsTUFBTSxTQUFTLE1BQU0sU0FBUyxNQUFNLGFBQWE7R0FDOUQsWUFBWSxDQUFDLENBQUM7RUFDaEI7Q0FDRixDQUFDO0NBTUQsTUFBTSxZQUFZLHVCQUF1QixXQUFXLElBQUksV0FBVztDQUNuRSxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLENBQUMsU0FBUztHQUNaLGVBQWUsWUFBWTtHQUMzQjtFQUNGO0VBQ0EsSUFBSSxDQUFDLFdBQ0g7RUFFRixTQUFTLGtCQUFrQjtHQUN6QixtQkFBbUIsVUFBVTtHQUM3QixtQkFBbUIsVUFBVTtFQUMvQjtFQUNBLE1BQU0sTUFBTSxVQUFVLFFBQVE7RUFDOUIsU0FBUyxnQkFBZ0IsT0FBTztHQUM5QixNQUFNLFNBQVMsVUFBVSxLQUFLO0dBQzlCLElBQUksQ0FBQyxTQUFTLFVBQVUsTUFBTSxHQUM1QixhQUFhLE1BQU0sU0FBUyxNQUFNLE9BQU87UUFFekMsZ0JBQWdCO0VBRXBCO0VBQ0EsSUFBSSxDQUFDLFFBQVEsUUFBUSxhQUFhLGtCQUFrQixRQUFRLFFBQVEsU0FBUyxHQUMzRSxtQkFBbUIsVUFBVSxpQkFBaUIsS0FBSyxhQUFhLGVBQWU7T0FFL0UsZUFBZSxZQUFZO0VBRTdCLE9BQU87Q0FDVCxHQUFHO0VBQUM7RUFBVztFQUFTO0VBQVU7RUFBUztFQUFjO0VBQU87RUFBYztFQUFnQjtDQUFRLENBQUM7Q0FHdkcsYUFBTSxzQkFBc0I7RUFDMUIsTUFBTSxJQUFJLHFCQUFxQixJQUFJO0NBQ3JDLEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FDVixhQUFNLGdCQUFnQjtFQUNwQixJQUFJLFdBQVcsQ0FBQyxVQUNkLFdBQVcsVUFBVTtDQUV6QixHQUFHLENBQUMsU0FBUyxRQUFRLENBQUM7Q0FDdEIsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxDQUFDLFdBQVcsTUFDZCxXQUFXLFVBQVU7Q0FFekIsR0FBRyxDQUFDLFNBQVMsSUFBSSxDQUFDO0NBQ2xCLE1BQU0sWUFBQSxhQUFrQixjQUFjO0VBQ3BDLFNBQVMsa0JBQWtCLE9BQU87R0FDaEMsZUFBZSxNQUFNLFdBQVc7RUFDbEM7RUFDQSxPQUFPO0dBQ0wsZUFBZTtHQUNmLGdCQUFnQjtHQUNoQixhQUFhO0dBQ2IsY0FBYztFQUNoQjtDQUNGLEdBQUcsQ0FBQywwQkFBMEIsQ0FBQztDQUMvQixPQUFBLGFBQWEsY0FBYyxVQUFVO0VBQ25DO0VBQ0EsU0FBUztDQUNYLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxTQUFTLENBQUM7QUFDOUI7O0FDeEtBLElBQWEscUJBQWtDLDJCQUFNLGNBQWMsS0FBQSxDQUFTO0FBQ2pDLG1CQUFtQixjQUFjO0FBQzVFLFNBQWdCLHNCQUFzQixVQUFVO0NBQzlDLE1BQU0sVUFBQSxhQUFnQixXQUFXLGtCQUFrQjtDQUNuRCxJQUFJLFlBQVksS0FBQSxLQUFhLENBQUMsVUFDNUIsTUFBTSxJQUFJLE1BQThDLDZGQUF1SDtDQUVqTCxPQUFPO0FBQ1Q7O0FDTEEsSUFBTSxZQUFZO0NBQ2hCLEdBQUc7Q0FDSCxXQUFVLFVBQVMsTUFBTTtDQUN6QixjQUFhLFVBQVMsTUFBTTtDQUM1QixpQkFBZ0IsVUFBUyxNQUFNO0NBQy9CLGtCQUFpQixVQUFTLE1BQU07Q0FDaEMsd0JBQXVCLFVBQVMsTUFBTTtDQUN0Qyx1QkFBc0IsVUFBUyxNQUFNO0NBQ3JDLGVBQWMsVUFBUyxNQUFNO0NBRzdCLHNCQUFzQixPQUFPLFVBQVUsUUFBUSxNQUFNLHFCQUFxQixLQUFBO0NBQzFFLGFBQVksVUFBUyxNQUFNO0NBQzNCLGlCQUFnQixVQUFTLE1BQU07QUFDakM7Ozs7Ozs7OztBQVdBLElBQWEsZUFBYixjQUFrQyxXQUFXO0NBQzNDLFlBQVksY0FBYyxZQUFZLFFBQVE7RUFDNUMsTUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0I7RUFDNUMsTUFBTSxtQkFBbUIsY0FBYyxpQkFBaUIsWUFBWSxNQUFNLEdBQUcscUJBQXFCLGVBQWUsR0FBRyxTQUFTO0NBQy9IO0NBQ0EsV0FBVyxVQUFVLGlCQUFpQjtFQUNwQyxxQkFBcUIsTUFBTSxVQUFVLGNBQWMsRUFDakQsWUFBWSxFQUNWLGtCQUFrQixhQUFhLE9BQ2pDLEVBQ0YsQ0FBQztDQUNIO0NBR0Esa0JBQWtCLE9BQU87RUFDdkIsS0FBSyxNQUFNLG9CQUFvQixtQkFBbUIsT0FBTyx5QkFBeUJDLGNBQXNCLEtBQUssQ0FBQztDQUNoSDtBQUNGOzs7Ozs7OztBQVNBLFNBQWdCLHlCQUF5QjtDQUN2QyxNQUFNLGtCQUFrQixJQUFJLGdCQUFnQjtDQUM1QyxNQUFNLFFBQVEsSUFBSSxVQUFVLE9BQU8sT0FBTyxtQkFBbUIsS0FBQSxHQUFXLGVBQWUsQ0FBQyxHQUFHLE9BQU8sT0FBTyxxQkFBcUIsZUFBZSxDQUFDLEdBQUcsU0FBUztDQUMxSixPQUFPLE9BQU8sT0FBTyxPQUFPO0VBQzFCLFNBQVM7RUFDVCxtQkFBbUI7Q0FDckIsQ0FBQztBQUNIO0FBQ0EsU0FBUyxtQkFBbUIsY0FBYyxpQkFBaUIsWUFBWSxTQUFTLE9BQU87Q0FjckYsT0FBTztFQVpMLEdBQUcsNkJBQTZCLGlCQUFpQixZQUFZLE1BQU07RUFDbkUsVUFBVTtFQUNWLGFBQWEsS0FBQTtFQUNiLGdCQUFnQjtFQUNoQixpQkFBaUI7RUFDakIsdUJBQXVCO0VBQ3ZCLGtCQUFrQjtFQUNsQixjQUFjO0VBQ2QsWUFBWTtFQUNaLGdCQUFnQixLQUFBO0VBQ2hCLEdBQUc7Q0FFTTtBQUNiO0FBQ0EsU0FBUyxxQkFBcUIsaUJBQWlCO0NBQzdDLE9BQU87RUFDTCxVQUF1QiwyQkFBTSxVQUFVO0VBQ3ZDLGNBQWMsS0FBQTtFQUNkLHNCQUFzQixLQUFBO0VBQ3RCO0NBQ0Y7QUFDRjs7Ozs7Ozs7QUNwRUEsSUFBYSxjQUFjLGNBQWMsU0FBUyxZQUFZLE9BQU87Q0FDbkUsTUFBTSxFQUNKLFVBQUEsYUFBVyxPQUNYLGNBQWMsT0FDZCxNQUFNLFVBQ04sd0JBQXdCLE9BQ3hCLGtCQUFrQixRQUNsQixZQUNBLGNBQ0Esc0JBQ0EsUUFDQSxXQUFXLGVBQ1gsa0JBQWtCLHVCQUF1QixNQUN6QyxhQUNFO0NBQ0osTUFBTSxRQUFRLG1CQUFtQixZQUFZLFdBQVcsSUFBSSxhQUFhO0VBQ3ZFLE1BQU07RUFDTjtFQUNBLGlCQUFpQjtFQUNqQjtDQUNGLEdBQUcsWUFBWSxNQUFNLENBQUM7Q0FDdEIsTUFBTSxrQkFBa0IsWUFBWSxRQUFRO0NBQzVDLE1BQU0sa0JBQWtCLGlCQUFpQixhQUFhO0NBQ3RELE1BQU0sbUJBQW1CLGdCQUFnQixZQUFZO0NBQ3JELE1BQU0sbUJBQW1CLHdCQUF3QixvQkFBb0I7Q0FDckUsTUFBTSxZQUFZLE1BQU0sU0FBUyxNQUFNO0NBQ3ZDLE1BQU0sT0FBTyxDQUFDQyxjQUFZO0NBQzFCLE1BQU0sa0JBQWtCLE1BQU0sU0FBUyxpQkFBaUI7Q0FDeEQsTUFBTSxVQUFVLE1BQU0sU0FBUyxTQUFTO0NBQ3hDLE1BQU0sVUFBVSxNQUFNLFNBQVMsU0FBUztDQUN4QyxNQUFNLGdCQUFnQjtFQUNwQjtFQUNBO0VBQ0EsVUFBQTtDQUNGLENBQUM7Q0FDRCx5QkFBeUIsT0FBTyxFQUM5Qiw2QkFBNkIsS0FDL0IsQ0FBQztDQUNELE1BQU0sRUFDSixjQUNBLHFCQUNFLHdCQUF3QixNQUFNLEtBQUs7Q0FDdkMsTUFBTSxpQkFBaUIsTUFBTSxTQUFTLGdCQUFnQjtDQUN0RCxNQUFNLGNBQWMsTUFBTSxTQUFTLGFBQWE7Q0FDaEQsTUFBTSx1QkFBdUIsTUFBTSxTQUFTLHNCQUFzQjtDQU9sRSxNQUFNLHlCQUFBLGFBQStCLE9BQU8sSUFBSTtDQUNoRCx5QkFBeUI7RUFDdkIsSUFBSSxhQUFhQSxZQUNmLE1BQU0sUUFBUSxPQUFPLHlCQUF5QkMsUUFBZ0IsQ0FBQztDQUVuRSxHQUFHO0VBQUM7RUFBV0Q7RUFBVTtDQUFLLENBQUM7Q0FDL0IseUJBQXlCO0VBQ3ZCLElBQUkscUJBQXFCLFlBQVkseUJBQXlCLFVBQWdCLHFCQUFxQixZQUFZLGdCQUFnQjtHQUk3SCxJQUFJLGdCQUFnQixTQUNsQix1QkFBdUIsVUFBVTtHQUVuQyxNQUFNLElBQUksZUFBZSxPQUFPO0VBQ2xDLE9BQU8sSUFBSSx1QkFBdUIsWUFBWSxNQUFNO0dBQ2xELE1BQU0sSUFBSSxlQUFlLHVCQUF1QixPQUFPO0dBQ3ZELHVCQUF1QixVQUFVO0VBQ25DO0NBQ0YsR0FBRztFQUFDO0VBQWtCO0VBQWdCO0VBQXNCO0VBQWE7Q0FBSyxDQUFDO0NBQy9FLHlCQUF5QjtFQUN2QixJQUFJLE1BQ0U7T0FBQSxtQkFBbUIsTUFDckIsTUFBTSxJQUFJLFdBQVcsS0FBQSxDQUFTO0VBQUE7Q0FHcEMsR0FBRztFQUFDO0VBQU87RUFBaUI7Q0FBSSxDQUFDO0NBQ2pDLGFBQU0sb0JBQW9CLG1CQUFtQjtFQUMzQyxTQUFTO0VBQ1QsYUFBYSxNQUFNLFFBQVEsT0FBTyx5QkFBeUJFLGdCQUF3QixDQUFDO0NBQ3RGLElBQUksQ0FBQyxjQUFjLEtBQUssQ0FBQztDQUN6QixNQUFNLDJCQUEyQixRQUFRLFdBQVcsQ0FBQ0YsY0FBWSxvQkFBb0I7Q0FDckYsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBTSxtQkFBbUIsVUFBVTtFQUNyRCxPQUFPO0VBQ1AsVUFBVTtHQUFDLFVBQXVCLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssdUJBQXVCO0lBQ3BEO0lBQ0Q7R0FDVCxDQUFDO0dBQUcsNEJBQXlDLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUsscUJBQXFCO0lBQzlEO0lBQ1AsVUFBVUE7SUFDTztHQUNuQixDQUFDO0dBQUcsT0FBTyxhQUFhLGFBQWEsU0FBUyxFQUM1QyxRQUNGLENBQUMsSUFBSTtFQUFRO0NBQ2YsQ0FBQztBQUNILENBQUM7QUFDMEMsWUFBWSxjQUFjO0FBQ3JFLFNBQVMsb0JBQW9CLEVBQzNCLE9BQ0EsVUFDQSxtQkFDQztDQUNELE1BQU0sc0JBQXNCLE1BQU0sU0FBUyxxQkFBcUI7Q0FDaEUsTUFBTSxVQUFVLFdBQVcscUJBQXFCO0VBQzlDLFNBQVMsQ0FBQztFQUNWLHNCQUFzQixNQUFNLE9BQU8sY0FBYztDQUNuRCxDQUFDO0NBQ0QsTUFBTSxjQUFjLGVBQWUscUJBQXFCO0VBQ3RELFNBQVMsQ0FBQyxZQUFZLG9CQUFvQjtFQUMxQyxNQUFNLG9CQUFvQixTQUFTLEtBQUEsSUFBWTtDQUNqRCxDQUFDO0NBSUQsTUFBTSxlQUFBLGFBQXFCLGNBQWMsV0FBVyxZQUFZLFdBQVcsUUFBUSxTQUFTLEdBQUcsQ0FBQyxZQUFZLFdBQVcsUUFBUSxTQUFTLENBQUM7Q0FDekkseUJBQXlCLE9BQU87RUFDOUIsb0JBQW9CO0VBQ3BCLHNCQUFzQjtFQUN0QixZQUFZLFFBQVEsWUFBWTtDQUNsQyxDQUFDO0NBQ0QsT0FBTztBQUNUOzs7OztBQ3hJQSxJQUFhLHlCQUFzQywyQkFBTSxjQUFjLEtBQUEsQ0FBUztBQUNyQyx1QkFBdUIsY0FBYztBQUNoRixTQUFnQiw0QkFBNEI7Q0FDMUMsT0FBQSxhQUFhLFdBQVcsc0JBQXNCO0FBQ2hEOztBQ1lBLElBQU0sNkJBQTZCO0FBQ25DLFNBQVMsaUJBQWlCLE9BQU87Q0FDL0IsTUFBTSxTQUFTLFVBQVUsS0FBSztDQUM5QixPQUFPLFVBQVUsTUFBTSxJQUFJLFNBQVM7QUFDdEM7Ozs7Ozs7QUFRQSxJQUFhLGlCQUFpQixpQkFBaUIsU0FBUyxlQUFlLGdCQUFnQixjQUFjO0NBQ25HLE1BQU0sRUFDSixRQUNBLFdBQ0EsT0FDQSxRQUNBLFNBQ0EsVUFBVSxjQUNWLE9BQ0EsZUFBZSxNQUNmLFlBQ0EsSUFBSSxRQUNKLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLGNBQWMsc0JBQXNCLElBQUk7Q0FFOUMsTUFBTSxRQURjLG9CQUFvQixNQUNoQixLQUFLO0NBQzdCLElBQUksQ0FBQyxPQUNILE1BQU0sSUFBSSxNQUE4Qyw2R0FBdUk7Q0FFak0sTUFBTSxnQkFBZ0IsWUFBWSxNQUFNO0NBQ3hDLE1BQU0sa0JBQWtCLE1BQU0sU0FBUyxtQkFBbUIsYUFBYTtDQUN2RSxNQUFNLHdCQUF3QixNQUFNLFNBQVMscUJBQXFCLGFBQWE7Q0FDL0UsTUFBTSxzQkFBc0IsTUFBTSxTQUFTLHFCQUFxQjtDQUNoRSxNQUFNLG9CQUFBLGFBQTBCLE9BQU8sSUFBSTtDQUMzQyxNQUFNLHdCQUF3QixjQUFjO0NBQzVDLE1BQU0sRUFDSixpQkFDQSwyQkFDRSx5QkFBeUIsZUFBZSxtQkFBbUIsT0FBTztFQUNwRTtFQUNBO0VBQ0EsWUFBWTtDQUNkLENBQUM7Q0FDRCxNQUFNLGdCQUFnQiwwQkFBMEI7Q0FDaEQsTUFBTSxFQUNKLGFBQ0EsVUFDQSxnQkFDQSxnQkFDRSxjQUFjLHFCQUFxQixFQUNyQyxNQUFNLHNCQUNSLENBQUM7Q0FDRCxNQUFNLG1CQUFtQiwrQkFBK0IsbUJBQW1CO0NBQzNFLE1BQU0sZUFBZSxrQkFBa0IsY0FBYztDQUNyRCxNQUFNLGVBQWUsTUFBTSxTQUFTLFVBQVU7Q0FDOUMsTUFBTSxXQUFXLGdCQUFnQjtDQUNqQyxNQUFNLGNBQWMsY0FBYyxRQUFRO0NBQzFDLE1BQU0sa0JBQWtCLE1BQU0sU0FBUyxpQkFBaUI7Q0FDeEQsTUFBTSx3QkFBd0IsTUFBTSxTQUFTLHVCQUF1QjtDQUNwRSxNQUFNLDRCQUFBLGFBQWtDLE9BQU8sS0FBSztDQUNwRCxNQUFNLDJCQUEyQixXQUFXO0NBRTVDLE1BQU0saUJBQUEsYUFBdUIsT0FBTyxLQUFBLENBQVM7Q0FDN0MsU0FBUyxlQUFlO0VBRXRCLElBQUksZUFBZSxZQUFZLFdBQVcsTUFDeEMsT0FBTztFQUVULE9BQU8sU0FBUyxpQkFBQTtDQUNsQjtDQUNBLFNBQVMsNkJBQTZCLFFBQVE7RUFDNUMsTUFBTSxZQUFZLGtCQUFrQjtFQUNwQyxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQ2pCLE9BQU87RUFFVCxNQUFNLGlCQUFpQixRQUFRLFFBQVEsSUFBSSwyQkFBMkIsRUFBRTtFQUN4RSxPQUFPLG1CQUFtQixRQUFRLG1CQUFtQixhQUFhLFNBQVMsV0FBVyxjQUFjO0NBQ3RHO0NBQ0EsU0FBUyx5QkFBeUIsUUFBUTtFQUN4QyxNQUFNLHVCQUF1Qiw2QkFBNkIsTUFBTTtFQUNoRSwwQkFBMEIsVUFBVTtFQUNwQyxJQUFJLHNCQUFzQjtHQUN4QixpQkFBaUIsa0JBQWtCLE1BQU07R0FDekMsaUJBQWlCLFlBQVksTUFBTTtHQUNuQyxpQkFBaUIscUJBQXFCO0dBQ3RDLHlCQUF5QixNQUFNO0VBQ2pDO0VBQ0EsT0FBTztDQUNUO0NBQ0EsTUFBTSxhQUFhLDZCQUE2QixxQkFBcUI7RUFDbkUsU0FBUyxDQUFDO0VBQ1YsV0FBVztFQUNYLE1BQU07RUFDTixhQUFhLENBQUMseUJBQXlCLG9CQUFvQixTQUFTLFlBQVksSUFBSTtFQUNwRixRQUFRO0VBQ1IsUUFBUTtHQUNOLElBQUksY0FBYyxRQUFRLGFBQ3hCLE9BQU8sRUFDTCxPQUFPLFNBQVMsU0FBUyxTQUFTLE9BQU8sRUFDM0M7R0FFRixPQUFPLEVBQ0wsT0FBTyxzQkFDVDtFQUNGO0VBQ0E7RUFDQSxpQkFBaUI7RUFDakIsaUJBQWlCLE1BQU0sT0FBTyxrQkFBa0IsTUFBTTtFQUN0RCxhQUFhO0dBQ1gsT0FBTyxDQUFDLDBCQUEwQjtFQUNwQztDQUNGLENBQUM7Q0FDRCxNQUFNLGFBQWEsU0FBUyxxQkFBcUIsRUFDL0MsU0FBUyxDQUFDLFNBQ1osQ0FBQyxDQUFDLENBQUM7Q0FDSCxNQUFNLDRCQUEyQixVQUFTO0VBQ3hDLE1BQU0sMEJBQTBCLDBCQUEwQjtFQUMxRCxNQUFNLFNBQVMsaUJBQWlCLEtBQUs7RUFDckMsTUFBTSx1QkFBdUIseUJBQXlCLE1BQU07RUFDNUQsTUFBTSxZQUFZLGtCQUFrQjtFQUNwQyxNQUFNLHNCQUFzQixhQUFhLFVBQVUsU0FBUyxXQUFXLE1BQU07RUFJN0UsSUFBSSx3QkFBd0IsTUFBTSxPQUFPLE1BQU0sS0FBSyxNQUFNLE9BQU8sc0JBQXNCLE1BQU0saUJBQXNCO0dBQ2pILE1BQU0sUUFBUSxPQUFPLHlCQUF5QkcsY0FBc0IsS0FBSyxDQUFDO0dBQzFFO0VBQ0Y7RUFDQSxJQUFJLDJCQUEyQixDQUFDLHdCQUF3Qix1QkFBdUIsQ0FBQyxZQUFZLFdBQVcsQ0FBQyxNQUFNLE9BQU8sTUFBTSxLQUFLLGFBRWhJLHVCQUF1QixlQUFlLE9BQU8sR0FBRztHQUM5QyxNQUFNLGFBQWE7SUFDakIsSUFBSSxDQUFDLDBCQUEwQixXQUFXLENBQUMsWUFBWSxXQUFXLENBQUMsTUFBTSxPQUFPLE1BQU0sR0FDcEYsTUFBTSxRQUFRLE1BQU0seUJBQXlCQSxjQUFzQixPQUFPLFNBQVMsQ0FBQztHQUV4RjtHQUNBLE1BQU0sWUFBWSxhQUFhO0dBSy9CLElBQUksY0FBYyxHQUFHO0lBQ25CLHlCQUF5QixNQUFNO0lBQy9CLEtBQUs7R0FDUCxPQUNFLHlCQUF5QixNQUFNLFdBQVcsSUFBSTtFQUVsRDtDQUNGO0NBQ0EsTUFBTSxtQkFBbUIsTUFBTSxTQUFTLHVCQUF1QiwwQkFBMEIsb0JBQW9CLE1BQU07Q0EwQ25ILE9BdENnQixpQkFBaUIsVUFBVSxnQkFBZ0I7RUFDekQsT0FBQSxFQUhBLE1BQU0sc0JBR0Y7RUFDSixLQUFLO0dBQUM7R0FBYztHQUFpQjtFQUFpQjtFQUN0RCxPQUFPO0dBQUM7R0FBWTtHQUFZO0dBQWtCO0lBQ2hELFlBQVksT0FBTztLQUNqQix5QkFBeUIsTUFBTSxXQUFXO0lBQzVDO0lBQ0EsUUFBUSxPQUFPO0tBQ2IsSUFBSSw2QkFBNkIsaUJBQWlCLE1BQU0sV0FBVyxDQUFDLEdBQ2xFLE1BQU0scUJBQXFCO0lBRS9CO0lBQ0EsZUFBZTtLQUNiLDBCQUEwQixVQUFVO0tBQ3BDLHlCQUF5QixNQUFNO0tBQy9CLGVBQWUsVUFBVSxLQUFBO0lBQzNCO0lBQ0EsZUFBZSxPQUFPO0tBQ3BCLGVBQWUsVUFBVSxNQUFNO0lBQ2pDO0lBQ0EsY0FBYyxPQUFPO0tBQ25CLGVBQWUsVUFBVSxNQUFNO0tBQy9CLE1BQU0sSUFBSSxnQkFBZ0IsWUFBWTtLQUN0QyxJQUFJLGdCQUFnQixDQUFDLE1BQU0sT0FBTyxNQUFNLEdBQ3RDLE1BQU0sa0JBQWtCLE1BQU0sV0FBVztJQUU3QztJQUNBLFFBQVEsT0FBTztLQUNiLElBQUksZ0JBQWdCLENBQUMsTUFBTSxPQUFPLE1BQU0sR0FDdEMsTUFBTSxrQkFBa0IsTUFBTSxXQUFXO0lBRTdDO0lBQ0EsSUFBSTtLQUNIQyxrQkFBK0MsV0FBVyxLQUFLLEtBQUE7S0FDL0QsNkJBQTZCLFdBQVcsS0FBQSxJQUFZO0dBQ3ZEO0dBQUc7RUFBWTtFQUNmLHdCQUF3QjtDQUMxQixDQUNhO0FBQ2YsQ0FBQztBQUMwQyxlQUFlLGNBQWM7O0FDdk54RSxJQUFhLHVCQUFvQywyQkFBTSxjQUFjLEtBQUEsQ0FBUztBQUNuQyxxQkFBcUIsY0FBYztBQUM5RSxTQUFnQiwwQkFBMEI7Q0FDeEMsTUFBTSxRQUFBLGFBQWMsV0FBVyxvQkFBb0I7Q0FDbkQsSUFBSSxVQUFVLEtBQUEsR0FDWixNQUFNLElBQUksTUFBOEMsdUNBQWlFO0NBRTNILE9BQU87QUFDVDs7Ozs7Ozs7QUNEQSxJQUFhLHFCQUFrQywyQkFBTSxXQUFXLFNBQVMsbUJBQW1CLGdCQUFnQixjQUFjO0NBQ3hILE1BQU0sRUFDSixVQUNBLFdBQ0EsV0FDQSxRQUNBLE9BQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sRUFDSixNQUFNLFlBQ04sU0FBUyxrQkFDUCxzQkFBc0I7RUFDeEI7RUFDQSxLQUFLO0VBQ0w7RUFDQTtDQUNGLENBQUM7Q0FDRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFDckIsT0FBTztDQUVULE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUEsYUFBWSxVQUFVLEVBQ3hDLFVBQVUsQ0FBQyxlQUFlLGNBQTJCLCtCQUFTLGFBQWEsVUFBVSxVQUFVLENBQUMsRUFDbEcsQ0FBQztBQUNILENBQUM7QUFDMEMsbUJBQW1CLGNBQWM7Ozs7Ozs7OztBQ3RCNUUsSUFBYSxnQkFBNkIsMkJBQU0sV0FBVyxTQUFTLGNBQWMsT0FBTyxjQUFjO0NBQ3JHLE1BQU0sRUFDSixjQUFjLE9BQ2QsR0FBRyxnQkFDRDtDQUlKLElBQUksRUFIVSxzQkFDTSxDQUFDLENBQUMsU0FBUyxTQUNKLEtBQUssY0FFOUIsT0FBTztDQUVULE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUsscUJBQXFCLFVBQVU7RUFDdEQsT0FBTztFQUNQLFVBQXVCLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssb0JBQW9CO0dBQzlDLEtBQUs7R0FDTCxHQUFHO0VBQ0wsQ0FBQztDQUNILENBQUM7QUFDSCxDQUFDO0FBQzBDLGNBQWMsY0FBYzs7QUM3QnZFLElBQWEsMkJBQXdDLDJCQUFNLGNBQWMsS0FBQSxDQUFTO0FBQ3ZDLHlCQUF5QixjQUFjO0FBQ2xGLFNBQWdCLDhCQUE4QjtDQUM1QyxNQUFNLFVBQUEsYUFBZ0IsV0FBVyx3QkFBd0I7Q0FDekQsSUFBSSxZQUFZLEtBQUEsR0FDZCxNQUFNLElBQUksTUFBOEMsbUhBQTZJO0NBRXZNLE9BQU87QUFDVDs7Ozs7Ozs7QUNLQSxJQUFhLG9CQUFpQywyQkFBTSxXQUFXLFNBQVMsa0JBQWtCLGdCQUFnQixjQUFjO0NBQ3RILE1BQU0sRUFDSixRQUNBLFdBQ0EsUUFDQSxpQkFBaUIsWUFDakIsT0FBTyxPQUNQLFFBQVEsVUFDUixhQUFhLEdBQ2IsY0FBYyxHQUNkLG9CQUFvQixzQkFDcEIsbUJBQW1CLEdBQ25CLGVBQWUsR0FDZixTQUFTLE9BQ1Qsd0JBQXdCLE9BQ3hCLHFCQUFxQiwyQkFDckIsT0FDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxRQUFRLHNCQUFzQjtDQUNwQyxNQUFNLGNBQWMsd0JBQXdCO0NBQzVDLE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLFVBQVUsTUFBTSxTQUFTLFNBQVM7Q0FDeEMsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLGlCQUFpQjtDQUN4RCxNQUFNLHdCQUF3QixNQUFNLFNBQVMsdUJBQXVCO0NBQ3BFLE1BQU0sc0JBQXNCLE1BQU0sU0FBUyxxQkFBcUI7Q0FDaEUsTUFBTSxjQUFjLE1BQU0sU0FBUyxhQUFhO0NBQ2hELE1BQU0sbUJBQW1CLE1BQU0sU0FBUyxrQkFBa0I7Q0FDMUQsTUFBTSxpQkFBaUIsTUFBTSxTQUFTLGdCQUFnQjtDQUN0RCxNQUFNLGNBQWMscUJBQXFCO0VBQ3ZDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsQ0FBQztDQUNELE1BQU0sUUFBQSxhQUFjLGVBQWU7RUFDakM7RUFDQSxNQUFNLFlBQVk7RUFDbEIsT0FBTyxZQUFZO0VBQ25CLGNBQWMsWUFBWTtFQUMxQixTQUFTLG9CQUFvQixTQUFTLG9CQUFvQjtDQUM1RCxJQUFJO0VBQUM7RUFBTSxZQUFZO0VBQU0sWUFBWTtFQUFPLFlBQVk7RUFBYztFQUFpQjtDQUFXLENBQUM7Q0FDdkcsTUFBTSxVQUFVLGNBQWMsZ0JBQWdCLE9BQU87RUFDbkQsUUFBUSxZQUFZO0VBQ3BCO0VBQ0EsT0FBTztFQUNQLE1BQU0sQ0FBQyxjQUFjLE1BQU0sZUFBZSxtQkFBbUIsQ0FBQztFQUM5RCxRQUFRLENBQUM7RUFDVCxPQUFPLENBQUMsUUFBUSxvQkFBb0IsVUFBVTtDQUNoRCxDQUFDO0NBQ0QsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyx5QkFBeUIsVUFBVTtFQUMxRCxPQUFPO0VBQ1AsVUFBVTtDQUNaLENBQUM7QUFDSCxDQUFDO0FBQzBDLGtCQUFrQixjQUFjOzs7Ozs7OztBQ2xFM0UsSUFBYSxlQUE0QiwyQkFBTSxXQUFXLFNBQVMsYUFBYSxnQkFBZ0IsY0FBYztDQUM1RyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sUUFBUSxzQkFBc0I7Q0FDcEMsTUFBTSxFQUNKLE1BQ0EsVUFDRSw0QkFBNEI7Q0FDaEMsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sY0FBYyxNQUFNLFNBQVMsYUFBYTtDQUNoRCxNQUFNLG1CQUFtQixNQUFNLFNBQVMsa0JBQWtCO0NBQzFELE1BQU0sYUFBYSxNQUFNLFNBQVMsWUFBWTtDQUM5QyxNQUFNLGtCQUFrQixNQUFNLFNBQVMscUJBQXFCO0NBQzVELE1BQU0sV0FBVyxNQUFNLFNBQVMsVUFBVTtDQUMxQyxNQUFNLGFBQWEsTUFBTSxTQUFTLFlBQVk7Q0FDOUMsc0JBQXNCO0VBQ3BCO0VBQ0EsS0FBSyxNQUFNLFFBQVE7RUFDbkIsYUFBYTtHQUNYLElBQUksTUFDRixNQUFNLFFBQVEsdUJBQXVCLElBQUk7RUFFN0M7Q0FDRixDQUFDO0NBQ0QsNEJBQTRCLGlCQUFpQjtFQUMzQyxTQUFTLENBQUM7RUFDVjtDQUNGLENBQUM7Q0FDRCxNQUFNLGtCQUFrQixNQUFNLGVBQWUsY0FBYztDQWMzRCxPQU5nQixpQkFBaUIsT0FBTyxnQkFBZ0I7RUFDdEQsT0FBQTtHQVBBO0dBQ0E7R0FDQTtHQUNBLFNBQVM7R0FDVDtFQUdJO0VBQ0osS0FBSztHQUFDO0dBQWMsTUFBTSxRQUFRO0dBQVU7RUFBZTtFQUMzRCxPQUFPO0dBQUM7R0FBdUI7R0FBWSxpQ0FBaUMsZ0JBQWdCO0dBQUc7RUFBWTtFQUMzRyx3QkFBd0I7Q0FDMUIsQ0FDYTtBQUNmLENBQUM7QUFDMEMsYUFBYSxjQUFjOzs7Ozs7OztBQ3BEdEUsSUFBYSxlQUE0QiwyQkFBTSxXQUFXLFNBQVMsYUFBYSxnQkFBZ0IsY0FBYztDQUM1RyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sUUFBUSxzQkFBc0I7Q0FDcEMsTUFBTSxFQUNKLFVBQ0EsTUFDQSxPQUNBLGlCQUNBLGdCQUNFLDRCQUE0QjtDQUdoQyxNQUFNLFFBQVE7RUFDWixNQUhXLE1BQU0sU0FBUyxNQUd2QjtFQUNIO0VBQ0E7RUFDQSxZQUFZO0VBQ1osU0FOa0IsTUFBTSxTQUFTLGFBTWQ7Q0FDckI7Q0FVQSxPQVRnQixpQkFBaUIsT0FBTyxnQkFBZ0I7RUFDdEQ7RUFDQSxLQUFLLENBQUMsY0FBYyxRQUFRO0VBQzVCLE9BQU8sQ0FBQztHQUNOLE9BQU87R0FDUCxlQUFlO0VBQ2pCLEdBQUcsWUFBWTtFQUNmLHdCQUF3QjtDQUMxQixDQUNhO0FBQ2YsQ0FBQztBQUMwQyxhQUFhLGNBQWM7Ozs7Ozs7O0FDcEN0RSxJQUFhLGtCQUFrQixTQUFTLGdCQUFnQixPQUFPO0NBQzdELE1BQU0sRUFDSixPQUNBLFlBQ0EsVUFBVSxRQUNSO0NBQ0osTUFBTSxhQUFBLGFBQW1CLGVBQWU7RUFDdEMsTUFBTTtFQUNOLE9BQU87Q0FDVCxJQUFJLENBQUMsT0FBTyxVQUFVLENBQUM7Q0FDdkIsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyx1QkFBdUIsVUFBVTtFQUN4RCxPQUFPO0VBQ1AsVUFBdUIsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxvQkFBb0I7R0FDOUMsT0FBTztHQUNQLFdBQVc7R0FDWCxVQUFVLE1BQU07RUFDbEIsQ0FBQztDQUNILENBQUM7QUFDSDtBQUMyQyxnQkFBZ0IsY0FBYzs7Ozs7Ozs7OztBQ2hCekUsSUFBYSxrQkFBK0IsMkJBQU0sV0FBVyxTQUFTLGdCQUFnQixnQkFBZ0IsY0FBYztDQUNsSCxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsVUFDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxRQUFRLHNCQUFzQjtDQUNwQyxNQUFNLGFBQWEsNEJBQTRCO0NBQy9DLE1BQU0sY0FBYyxNQUFNLFNBQVMsYUFBYTtDQUNoRCxNQUFNLEVBQ0osVUFBVSxrQkFDVixPQUFPLGtCQUNMLGlCQUFpQjtFQUNuQjtFQUNBLE1BQU0sV0FBVztFQUNqQjtDQUNGLENBQUM7Q0FDRCxNQUFNLFFBQVE7RUFDWixxQkFBcUIsY0FBYztFQUNuQyxlQUFlLGNBQWM7RUFDN0IsU0FBUztDQUNYO0NBQ0EsT0FBTyxpQkFBaUIsT0FBTyxnQkFBZ0I7RUFDN0M7RUFDQSxLQUFLO0VBQ0wsT0FBTyxDQUFDLGNBQWMsRUFDcEIsVUFBVSxpQkFDWixDQUFDO0VBQ0Qsd0JBQXdCO0NBQzFCLENBQUM7QUFDSCxDQUFDO0FBQzBDLGdCQUFnQixjQUFjOzs7Ozs7Ozs7O0FDdEN6RSxJQUFhLGdCQUFiLGNBQW1DLGdCQUFnQjtDQUNqRCxjQUFjO0VBQ1osTUFBTSx1QkFBdUIsR0FBRyxTQUFTO0NBQzNDOzs7Ozs7Ozs7Q0FVQSxLQUFLLFdBQVc7RUFDZCxLQUFLLGNBQWMsU0FBUztDQUM5Qjs7Ozs7O0NBT0EsUUFBUTtFQUNOLEtBQUssV0FBVztDQUNsQjs7OztDQUtBLElBQUksU0FBUztFQUNYLE9BQU8sS0FBSyxlQUFlLE9BQU8sTUFBTSxLQUFLO0NBQy9DO0FBQ0Y7Ozs7QUFLQSxTQUFnQixzQkFBc0I7Q0FDcEMsT0FBTyxJQUFJLGNBQWM7QUFDM0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUU5Q0EsSUFBYSxpQkFBaUI7Ozs7O0FBSzlCLElBQWEsa0JBQWtCOzs7OztBQUsvQixJQUFhLGNBQWM7Ozs7O0FBSzNCLElBQWEsZUFBZTs7Ozs7QUFLNUIsSUFBYSxrQkFBa0I7Ozs7OztBQU0vQixJQUFhLGtCQUFrQjs7Ozs7O0FBTS9CLElBQWEsbUJBQW1COzs7Ozs7Ozs7Ozs7QUMvQmhDLElBQWFDLFNBQU9DOzs7O0FBSXBCLElBQWFDLFdBQVNDOzs7O0FBSXRCLElBQWEsZUFBZUM7Ozs7O0FBSzVCLElBQWFDLFNBQU9DOzs7OztBQUtwQixJQUFhQyxVQUFRQzs7Ozs7Ozs7Ozs7Ozs7QUNsQnJCLElBQWFDLFNBQU9DOzs7O0FBSXBCLElBQWFDLFdBQVNDOzs7O0FBSXRCLElBQWEsZ0JBQWdCQzs7OztBQUk3QixJQUFhLGNBQWNDOzs7OztBQUszQixJQUFhQyxTQUFPQzs7Ozs7QUFLcEIsSUFBYUMsVUFBUUM7Ozs7O0FBS3JCLElBQWFDLFlBQVU7Ozs7Ozs7Ozs7Ozs7QUMzQnZCLElBQWEsT0FBT0M7Ozs7QUFJcEIsSUFBYSxTQUFTQzs7Ozs7QUFLdEIsSUFBYSxPQUFPQzs7Ozs7QUFLcEIsSUFBYSxRQUFRQzs7OztBQUlyQixJQUFhLGFBQWE7Ozs7O0FBSzFCLElBQWFDLFlBQVU7Ozs7Ozs7Ozs7O0FDdkJ2QixJQUFhLGFBQWE7Ozs7OztBQU0xQixJQUFhLGNBQWM7Ozs7Ozs7Ozs7OztBQ1IzQixJQUFhLFVBQVU7Ozs7QUFJdkIsSUFBYSxXQUFXOzs7Ozs7O0FBT3hCLElBQWEsc0JBQXNCOzs7O0FBSW5DLElBQWEsZ0JBQWdCOzs7OztBQUs3QixJQUFhLFVBQVUiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDgsOSwxMCwxMSwxMiwxMywxNCwxNSwxNiwxNywxOCwxOSwyMCwyMSwyMiwyM119