import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/cart/cart-drawer.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport16_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport16_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=e9f94b2e";
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { AlertCircle, RefreshCw, ShoppingBag } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { CartItemRow } from "/src/components/cart/cart-item-row.tsx";
import { CartSummary } from "/src/components/cart/cart-summary.tsx";
import { Alert, AlertDescription, AlertTitle } from "/src/components/ui/alert.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button, buttonVariants } from "/src/components/ui/button.tsx";
import { Separator } from "/src/components/ui/separator.tsx";
import { Sheet, SheetClose, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "/src/components/ui/sheet.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
import { useCart } from "/src/hooks/use-cart.ts";
import { getErrorMessage } from "/src/lib/api.ts";
import { useIsAuthenticated } from "/src/lib/session.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/cart/cart-drawer.tsx";
import __vite__cjsImport16_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
/**
* Drawer lateral acessível (`<Sheet>` com Focus Trap automático) para o Carrinho de Compras.
*/
export function CartDrawer() {
	_s();
	const $ = _c(24);
	if ($[0] !== "c6d731ca27deee657d8ae2f5f2b15784e3ea7bf18744a445f95a990a75bd0bac") {
		for (let $i = 0; $i < 24; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "c6d731ca27deee657d8ae2f5f2b15784e3ea7bf18744a445f95a990a75bd0bac";
	}
	const [open, setOpen] = useState(false);
	const isAuthenticated = useIsAuthenticated();
	const { data: cart, isLoading, isError, error, refetch } = useCart();
	const totalItems = cart?.totalItems ?? 0;
	const t0 = totalItems > 0 ? `Abrir carrinho (${totalItems} itens)` : "Abrir carrinho de compras";
	let t1;
	if ($[1] !== t0) {
		t1 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			variant: "outline",
			size: "sm",
			"aria-label": t0,
			className: "gap-1.5"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 10
		}, this);
		$[1] = t0;
		$[2] = t1;
	} else {
		t1 = $[2];
	}
	let t2;
	let t3;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV(ShoppingBag, {
			className: "size-4",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 10
		}, this);
		t3 = /* @__PURE__ */ _jsxDEV("span", {
			className: "hidden sm:inline",
			children: "Carrinho"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 10
		}, this);
		$[3] = t2;
		$[4] = t3;
	} else {
		t2 = $[3];
		t3 = $[4];
	}
	let t4;
	if ($[5] !== isAuthenticated || $[6] !== totalItems) {
		t4 = isAuthenticated && totalItems > 0 && /* @__PURE__ */ _jsxDEV(Badge, {
			variant: "default",
			className: "px-1.5 font-mono text-xs tabular-nums",
			children: totalItems
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 47
		}, this);
		$[5] = isAuthenticated;
		$[6] = totalItems;
		$[7] = t4;
	} else {
		t4 = $[7];
	}
	let t5;
	if ($[8] !== t1 || $[9] !== t4) {
		t5 = /* @__PURE__ */ _jsxDEV(SheetTrigger, {
			render: t1,
			children: [
				t2,
				t3,
				t4
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 70,
			columnNumber: 10
		}, this);
		$[8] = t1;
		$[9] = t4;
		$[10] = t5;
	} else {
		t5 = $[10];
	}
	let t6;
	let t7;
	if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = /* @__PURE__ */ _jsxDEV(SheetHeader, { children: [/* @__PURE__ */ _jsxDEV(SheetTitle, {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ _jsxDEV(ShoppingBag, {
				className: "size-4 text-primary",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 71
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Meu Carrinho" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 137
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 23
		}, this), /* @__PURE__ */ _jsxDEV(SheetDescription, { children: "Gerencie quantidades, aplique cupons e confira o total em ETH." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 175
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 10
		}, this);
		t7 = /* @__PURE__ */ _jsxDEV(Separator, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 81,
			columnNumber: 10
		}, this);
		$[11] = t6;
		$[12] = t7;
	} else {
		t6 = $[11];
		t7 = $[12];
	}
	let t8;
	if ($[13] !== cart || $[14] !== error || $[15] !== isAuthenticated || $[16] !== isError || $[17] !== isLoading || $[18] !== refetch) {
		t8 = /* @__PURE__ */ _jsxDEV(SheetContent, {
			side: "right",
			className: "flex w-full flex-col sm:max-w-md",
			children: [
				t6,
				t7,
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-1 flex-col gap-4 overflow-y-auto px-4 pb-6",
					children: !isAuthenticated ? /* @__PURE__ */ _jsxDEV("div", {
						className: "my-auto flex flex-col items-center gap-3 py-12 text-center",
						children: [
							/* @__PURE__ */ _jsxDEV(ShoppingBag, {
								className: "size-8 text-muted-foreground",
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 256
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm font-medium",
								children: "Sua sessão não está autenticada."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 331
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-muted-foreground",
								children: "Entre na sua conta para sincronizar e gerenciar seu carrinho de NFTs."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 402
							}, this),
							/* @__PURE__ */ _jsxDEV(SheetClose, {
								render: /* @__PURE__ */ _jsxDEV(Link, {
									to: "/login",
									search: { redirect: "/cart" },
									className: cn(buttonVariants({
										variant: "default",
										size: "sm"
									}))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 90,
									columnNumber: 540
								}, this),
								children: "Entrar na conta"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 520
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 180
					}, this) : isLoading ? /* @__PURE__ */ _jsxDEV("div", {
						className: "grid gap-3",
						"aria-busy": "true",
						"aria-label": "Carregando carrinho",
						children: [
							/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-24 w-full rounded-xl" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 147
							}, this),
							/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-24 w-full rounded-xl" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 194
							}, this),
							/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-56 w-full rounded-xl" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 241
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 69
					}, this) : isError ? /* @__PURE__ */ _jsxDEV(Alert, {
						variant: "destructive",
						role: "alert",
						children: [
							/* @__PURE__ */ _jsxDEV(AlertCircle, {
								className: "size-4",
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 349
							}, this),
							/* @__PURE__ */ _jsxDEV(AlertTitle, { children: "Erro ao carregar o carrinho" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 402
							}, this),
							/* @__PURE__ */ _jsxDEV(AlertDescription, {
								className: "mt-2 flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ _jsxDEV("span", { children: getErrorMessage(error) }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 95,
									columnNumber: 529
								}, this), /* @__PURE__ */ _jsxDEV(Button, {
									type: "button",
									variant: "outline",
									size: "xs",
									onClick: () => void refetch(),
									children: [/* @__PURE__ */ _jsxDEV(RefreshCw, {
										className: "size-3",
										"aria-hidden": "true"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 95,
										columnNumber: 647
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Tentar" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 95,
										columnNumber: 698
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 95,
									columnNumber: 566
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 454
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 307
					}, this) : !cart || cart.items.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
						className: "my-auto flex flex-col items-center gap-3 py-12 text-center",
						children: [
							/* @__PURE__ */ _jsxDEV(ShoppingBag, {
								className: "size-8 text-muted-foreground",
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 867
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-sm font-medium",
								children: "Seu carrinho está vazio."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 942
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "text-xs text-muted-foreground",
								children: "Explore o catálogo e adicione NFTs raros à sua coleção."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 1005
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "flex flex-wrap justify-center gap-2",
								children: /* @__PURE__ */ _jsxDEV(SheetClose, {
									render: /* @__PURE__ */ _jsxDEV(Link, {
										to: "/",
										className: cn(buttonVariants({
											variant: "outline",
											size: "sm"
										}))
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 95,
										columnNumber: 1182
									}, this),
									children: "Explorar NFTs"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 95,
									columnNumber: 1162
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 95,
								columnNumber: 1109
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 791
					}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						/* @__PURE__ */ _jsxDEV("section", {
							"aria-label": "Itens no carrinho",
							className: "grid gap-2.5",
							children: cart.items.map(_temp)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 65
						}, this),
						/* @__PURE__ */ _jsxDEV(CartSummary, {
							cart,
							onNavigateCheckout: () => setOpen(false)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 163
						}, this),
						/* @__PURE__ */ _jsxDEV(SheetClose, {
							render: /* @__PURE__ */ _jsxDEV(Link, {
								to: "/cart",
								className: cn(buttonVariants({
									variant: "ghost",
									size: "sm"
								}), "w-full")
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 98,
								columnNumber: 252
							}, this),
							children: "Abrir página completa do carrinho"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 98,
							columnNumber: 232
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 63
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 90,
					columnNumber: 90
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 10
		}, this);
		$[13] = cart;
		$[14] = error;
		$[15] = isAuthenticated;
		$[16] = isError;
		$[17] = isLoading;
		$[18] = refetch;
		$[19] = t8;
	} else {
		t8 = $[19];
	}
	let t9;
	if ($[20] !== open || $[21] !== t5 || $[22] !== t8) {
		t9 = /* @__PURE__ */ _jsxDEV(Sheet, {
			modal: true,
			open,
			onOpenChange: setOpen,
			children: [t5, t8]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 114,
			columnNumber: 10
		}, this);
		$[20] = open;
		$[21] = t5;
		$[22] = t8;
		$[23] = t9;
	} else {
		t9 = $[23];
	}
	return t9;
}
_s(CartDrawer, "4Y8kzL1g4ah8MCxLokGGTbqh3VM=", false, function() {
	return [useIsAuthenticated, useCart];
});
_c2 = CartDrawer;
function _temp(item) {
	return /* @__PURE__ */ _jsxDEV(CartItemRow, {
		item,
		compact: true
	}, item.id, false, {
		fileName: _jsxFileName,
		lineNumber: 125,
		columnNumber: 10
	}, this);
}
var _c2;
$RefreshReg$(_c2, "CartDrawer");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/cart/cart-drawer.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/cart/cart-drawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/cart/cart-drawer.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/cart/cart-drawer.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLGFBQWFDLFdBQVdDLG1CQUFtQjtBQUNwRCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLE9BQU9DLGtCQUFrQkMsa0JBQWtCO0FBQ3BELFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsUUFBUUMsc0JBQXNCO0FBQ3ZDLFNBQVNDLGlCQUFpQjtBQUMxQixTQUNFQyxPQUNBQyxZQUNBQyxjQUNBQyxrQkFDQUMsYUFDQUMsWUFDQUMsb0JBQ0s7QUFDUCxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsZUFBZTtBQUN4QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0MsMEJBQTBCO0FBQ25DLFNBQVNDLFVBQVU7Ozs7Ozs7QUFLbkIsT0FBTyxTQUFBQyxhQUFBOztDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLElBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUNMLE9BQUFLLE1BQUFDLFdBQXdCakMsU0FBUyxLQUFLO0NBQ3RDLE1BQUFrQyxrQkFBd0JWLG1CQUFtQjtDQUMzQyxRQUFBVyxNQUFBQyxNQUFBQyxXQUFBQyxTQUFBQyxPQUFBQyxZQUEyRGxCLFFBQVE7Q0FFbkUsTUFBQW1CLGFBQW1CTCxNQUFJSyxjQUFKO0NBV1AsTUFBQUMsS0FBQUQsYUFBYSxJQUFiLG1CQUFvQ0EsV0FBVSxXQUE5QztDQUFxRixJQUFBRTtDQUFBLElBQUFoQixFQUFBLE9BQUFlLElBQUE7RUFMekZDLEtBQUEsd0JBQUMsUUFBRDtHQUNPO0dBQ0c7R0FDSDtHQUVILGNBQUFEO0dBRVE7RUFBUzs7Ozs7RUFDbkJmLEVBQUEsS0FBQWU7RUFBQWYsRUFBQSxLQUFBZ0I7Q0FBQTtFQUFBQSxLQUFBaEIsRUFBQTtDQUFBO0NBQUEsSUFBQWlCO0NBQUEsSUFBQUM7Q0FBQSxJQUFBbEIsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBR0phLEtBQUEsd0JBQUMsYUFBRDtHQUF1QjtHQUFxQjtFQUFNOzs7OztFQUNsREMsS0FBQTtHQUFnQjthQUFtQjtFQUFlOzs7OztFQUFBbEIsRUFBQSxLQUFBaUI7RUFBQWpCLEVBQUEsS0FBQWtCO0NBQUE7RUFBQUQsS0FBQWpCLEVBQUE7RUFBQWtCLEtBQUFsQixFQUFBO0NBQUE7Q0FBQSxJQUFBbUI7Q0FBQSxJQUFBbkIsRUFBQSxPQUFBTyxtQkFBQVAsRUFBQSxPQUFBYyxZQUFBO0VBQ2pESyxLQUFBWixtQkFBbUJPLGFBQWEsS0FDL0Isd0JBQUMsT0FBRDtHQUFlO0dBQW9CO2FBQ2hDQTtFQURHOzs7OztFQUdQZCxFQUFBLEtBQUFPO0VBQUFQLEVBQUEsS0FBQWM7RUFBQWQsRUFBQSxLQUFBbUI7Q0FBQTtFQUFBQSxLQUFBbkIsRUFBQTtDQUFBO0NBQUEsSUFBQW9CO0NBQUEsSUFBQXBCLEVBQUEsT0FBQWdCLE1BQUFoQixFQUFBLE9BQUFtQixJQUFBO0VBbkJIQyxLQUFBLHdCQUFDLGNBQUQ7R0FFSSxRQUFBSjthQUZKO0lBYUVDO0lBQ0FDO0lBQ0NDO0dBZlU7Ozs7OztFQW9CRW5CLEVBQUEsS0FBQWdCO0VBQUFoQixFQUFBLEtBQUFtQjtFQUFBbkIsRUFBQSxNQUFBb0I7Q0FBQTtFQUFBQSxLQUFBcEIsRUFBQTtDQUFBO0NBQUEsSUFBQXFCO0NBQUEsSUFBQUM7Q0FBQSxJQUFBdEIsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBR2JpQixLQUFBLHdCQUFDLGFBQUQsYUFDRSx3QkFBQyxZQUFEO0dBQXNCO2FBQXRCLENBQ0Usd0JBQUMsYUFBRDtJQUF1QjtJQUFrQztHQUFNOzs7O2FBQy9ELDRDQUFNLGVBQW1COzs7O1dBRmhCOzs7OztZQUlYLHdCQUFDLGtCQUFELFlBQWtCLGlFQUFEOzs7O1VBTFA7Ozs7O0VBVVpDLEtBQUEsd0JBQUMsV0FBRCxDQUFVOzs7OztFQUFHdEIsRUFBQSxNQUFBcUI7RUFBQXJCLEVBQUEsTUFBQXNCO0NBQUE7RUFBQUQsS0FBQXJCLEVBQUE7RUFBQXNCLEtBQUF0QixFQUFBO0NBQUE7Q0FBQSxJQUFBdUI7Q0FBQSxJQUFBdkIsRUFBQSxRQUFBUyxRQUFBVCxFQUFBLFFBQUFZLFNBQUFaLEVBQUEsUUFBQU8sbUJBQUFQLEVBQUEsUUFBQVcsV0FBQVgsRUFBQSxRQUFBVSxhQUFBVixFQUFBLFFBQUFhLFNBQUE7RUFYZlUsS0FBQSx3QkFBQyxjQUFEO0dBQW1CO0dBQWtCO2FBQXJDO0lBQ0VGO0lBVUFDO0lBRUE7S0FBZTtlQUNaLENBQUNmLGtCQUNBO01BQWU7Z0JBQWY7T0FDRSx3QkFBQyxhQUFEO1FBQXVCO1FBQTJDO09BQU07Ozs7O09BQ3hFO1FBQWE7a0JBQXNCO09BQW9DOzs7OztPQUN2RTtRQUFhO2tCQUFnQztPQUV6Qzs7Ozs7T0FDSix3QkFBQyxZQUFEO1FBRUksZ0NBQUMsTUFBRDtTQUNLO1NBQ0ssVUFBQWlCLFVBQVksUUFBUTtTQUNqQixXQUFBMUIsR0FBR2IsZUFBZTtVQUFBd0MsU0FBVztVQUFTQyxNQUFRO1NBQUssQ0FBQyxDQUFDO1FBQUM7Ozs7O2tCQUd0RTtPQVJVOzs7OztNQVdQOzs7OztnQkFDSmhCLFlBQ0Y7TUFBZTtNQUF1QjtNQUFrQjtnQkFBeEQ7T0FDRSx3QkFBQyxVQUFELEVBQW9CLG9DQUF3Qjs7Ozs7T0FDNUMsd0JBQUMsVUFBRCxFQUFvQixvQ0FBd0I7Ozs7O09BQzVDLHdCQUFDLFVBQUQsRUFBb0Isb0NBQXdCOzs7OztNQUN4Qzs7Ozs7Z0JBQ0pDLFVBQ0Ysd0JBQUMsT0FBRDtNQUFlO01BQW1CO2dCQUFsQztPQUNFLHdCQUFDLGFBQUQ7UUFBdUI7UUFBcUI7T0FBTTs7Ozs7T0FDbEQsd0JBQUMsWUFBRCxZQUFZLDhCQUFEOzs7OztPQUNYLHdCQUFDLGtCQUFEO1FBQTRCO2tCQUE1QixDQUNFLDRDQUFPZixnQkFBZ0JnQixLQUFLLEVBQVM7Ozs7a0JBQ3JDLHdCQUFDLFFBQUQ7U0FBYTtTQUFpQjtTQUFlO1NBQWMsZUFBTSxLQUFLQyxRQUFRO21CQUE5RSxDQUNFLHdCQUFDLFdBQUQ7VUFBcUI7VUFBcUI7U0FBTTs7OzttQkFDaEQsNENBQU0sU0FBYTs7OztpQkFGZDs7Ozs7Z0JBRlE7Ozs7OztNQUhiOzs7OztnQkFXSixDQUFDSixRQUFRQSxLQUFJa0IsTUFBTUMsV0FBWSxJQUNqQztNQUFlO2dCQUFmO09BQ0Usd0JBQUMsYUFBRDtRQUF1QjtRQUEyQztPQUFNOzs7OztPQUN4RTtRQUFhO2tCQUFzQjtPQUE0Qjs7Ozs7T0FDL0Q7UUFBYTtrQkFBZ0M7T0FFekM7Ozs7O09BQ0o7UUFBZTtrQkFDYix3QkFBQyxZQUFEO1NBRUksZ0NBQUMsTUFBRDtVQUNLO1VBQ1EsV0FBQTlCLEdBQUdiLGVBQWU7V0FBQXdDLFNBQVc7V0FBU0MsTUFBUTtVQUFLLENBQUMsQ0FBQztTQUFDOzs7OzttQkFHdEU7UUFQVTs7Ozs7T0FVUDs7Ozs7TUFDRjs7Ozs7Z0JBbkJKO01Bc0JBO09BQW9CO09BQThCO2lCQUMvQ2pCLEtBQUlrQixNQUFNRSxJQUFLQyxLQUVmO01BQ087Ozs7O01BRVYsd0JBQUMsYUFBRDtPQUFtQnJCO09BQTBCLDBCQUFNSCxRQUFRLEtBQUs7TUFBQzs7Ozs7TUFFakUsd0JBQUMsWUFBRDtPQUVJLGdDQUFDLE1BQUQ7UUFDSztRQUNRLFdBQUFSLEdBQUdiLGVBQWU7U0FBQXdDLFNBQVc7U0FBT0MsTUFBUTtRQUFLLENBQUMsR0FBRyxRQUFRO09BQUM7Ozs7O2lCQUc5RTtNQVBVOzs7OztLQVNFOzs7OztJQUdiOzs7OztHQTdGSzs7Ozs7O0VBOEZFMUIsRUFBQSxNQUFBUztFQUFBVCxFQUFBLE1BQUFZO0VBQUFaLEVBQUEsTUFBQU87RUFBQVAsRUFBQSxNQUFBVztFQUFBWCxFQUFBLE1BQUFVO0VBQUFWLEVBQUEsTUFBQWE7RUFBQWIsRUFBQSxNQUFBdUI7Q0FBQTtFQUFBQSxLQUFBdkIsRUFBQTtDQUFBO0NBQUEsSUFBQStCO0NBQUEsSUFBQS9CLEVBQUEsUUFBQUssUUFBQUwsRUFBQSxRQUFBb0IsTUFBQXBCLEVBQUEsUUFBQXVCLElBQUE7RUFySGpCUSxLQUFBLHdCQUFDLE9BQUQ7R0FBTztHQUFZMUI7R0FBb0JDO2FBQXZDLENBQ0VjLElBc0JBRyxFQXZCSTs7Ozs7O0VBc0hFdkIsRUFBQSxNQUFBSztFQUFBTCxFQUFBLE1BQUFvQjtFQUFBcEIsRUFBQSxNQUFBdUI7RUFBQXZCLEVBQUEsTUFBQStCO0NBQUE7RUFBQUEsS0FBQS9CLEVBQUE7Q0FBQTtDQUFBLE9BdEhSK0I7QUFzSFE7Ozs7O0FBOUhMLFNBQUFELE1BQUFFLE1BQUE7Q0FBQSxPQTBHVyx3QkFBQyxhQUFEO0VBQWlDQTtFQUFNO0NBQU8sR0FBNUJBLEtBQUlDOzs7O1FBQXdCO0FBQUciLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkxpbmsiLCJBbGVydENpcmNsZSIsIlJlZnJlc2hDdyIsIlNob3BwaW5nQmFnIiwiQ2FydEl0ZW1Sb3ciLCJDYXJ0U3VtbWFyeSIsIkFsZXJ0IiwiQWxlcnREZXNjcmlwdGlvbiIsIkFsZXJ0VGl0bGUiLCJCYWRnZSIsIkJ1dHRvbiIsImJ1dHRvblZhcmlhbnRzIiwiU2VwYXJhdG9yIiwiU2hlZXQiLCJTaGVldENsb3NlIiwiU2hlZXRDb250ZW50IiwiU2hlZXREZXNjcmlwdGlvbiIsIlNoZWV0SGVhZGVyIiwiU2hlZXRUaXRsZSIsIlNoZWV0VHJpZ2dlciIsIlNrZWxldG9uIiwidXNlQ2FydCIsImdldEVycm9yTWVzc2FnZSIsInVzZUlzQXV0aGVudGljYXRlZCIsImNuIiwiQ2FydERyYXdlciIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwib3BlbiIsInNldE9wZW4iLCJpc0F1dGhlbnRpY2F0ZWQiLCJkYXRhIiwiY2FydCIsImlzTG9hZGluZyIsImlzRXJyb3IiLCJlcnJvciIsInJlZmV0Y2giLCJ0b3RhbEl0ZW1zIiwidDAiLCJ0MSIsInQyIiwidDMiLCJ0NCIsInQ1IiwidDYiLCJ0NyIsInQ4IiwicmVkaXJlY3QiLCJ2YXJpYW50Iiwic2l6ZSIsIml0ZW1zIiwibGVuZ3RoIiwibWFwIiwiX3RlbXAiLCJ0OSIsIml0ZW0iLCJpZCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJjYXJ0LWRyYXdlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IExpbmsgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgQWxlcnRDaXJjbGUsIFJlZnJlc2hDdywgU2hvcHBpbmdCYWcgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBDYXJ0SXRlbVJvdyB9IGZyb20gJ0AvY29tcG9uZW50cy9jYXJ0L2NhcnQtaXRlbS1yb3cnXG5pbXBvcnQgeyBDYXJ0U3VtbWFyeSB9IGZyb20gJ0AvY29tcG9uZW50cy9jYXJ0L2NhcnQtc3VtbWFyeSdcbmltcG9ydCB7IEFsZXJ0LCBBbGVydERlc2NyaXB0aW9uLCBBbGVydFRpdGxlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2FsZXJ0J1xuaW1wb3J0IHsgQmFkZ2UgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYmFkZ2UnXG5pbXBvcnQgeyBCdXR0b24sIGJ1dHRvblZhcmlhbnRzIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcbmltcG9ydCB7IFNlcGFyYXRvciB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9zZXBhcmF0b3InXG5pbXBvcnQge1xuICBTaGVldCxcbiAgU2hlZXRDbG9zZSxcbiAgU2hlZXRDb250ZW50LFxuICBTaGVldERlc2NyaXB0aW9uLFxuICBTaGVldEhlYWRlcixcbiAgU2hlZXRUaXRsZSxcbiAgU2hlZXRUcmlnZ2VyLFxufSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc2hlZXQnXG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9za2VsZXRvbidcbmltcG9ydCB7IHVzZUNhcnQgfSBmcm9tICdAL2hvb2tzL3VzZS1jYXJ0J1xuaW1wb3J0IHsgZ2V0RXJyb3JNZXNzYWdlIH0gZnJvbSAnQC9saWIvYXBpJ1xuaW1wb3J0IHsgdXNlSXNBdXRoZW50aWNhdGVkIH0gZnJvbSAnQC9saWIvc2Vzc2lvbidcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvdXRpbHMnXG5cbi8qKlxuICogRHJhd2VyIGxhdGVyYWwgYWNlc3PDrXZlbCAoYDxTaGVldD5gIGNvbSBGb2N1cyBUcmFwIGF1dG9tw6F0aWNvKSBwYXJhIG8gQ2FycmluaG8gZGUgQ29tcHJhcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIENhcnREcmF3ZXIoKSB7XG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBpc0F1dGhlbnRpY2F0ZWQgPSB1c2VJc0F1dGhlbnRpY2F0ZWQoKVxuICBjb25zdCB7IGRhdGE6IGNhcnQsIGlzTG9hZGluZywgaXNFcnJvciwgZXJyb3IsIHJlZmV0Y2ggfSA9IHVzZUNhcnQoKVxuXG4gIGNvbnN0IHRvdGFsSXRlbXMgPSBjYXJ0Py50b3RhbEl0ZW1zID8/IDBcblxuICByZXR1cm4gKFxuICAgIDxTaGVldCBtb2RhbCBvcGVuPXtvcGVufSBvbk9wZW5DaGFuZ2U9e3NldE9wZW59PlxuICAgICAgPFNoZWV0VHJpZ2dlclxuICAgICAgICByZW5kZXI9e1xuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e1xuICAgICAgICAgICAgICB0b3RhbEl0ZW1zID4gMCA/IGBBYnJpciBjYXJyaW5obyAoJHt0b3RhbEl0ZW1zfSBpdGVucylgIDogJ0FicmlyIGNhcnJpbmhvIGRlIGNvbXByYXMnXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJnYXAtMS41XCJcbiAgICAgICAgICAvPlxuICAgICAgICB9XG4gICAgICA+XG4gICAgICAgIDxTaG9wcGluZ0JhZyBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+Q2FycmluaG88L3NwYW4+XG4gICAgICAgIHtpc0F1dGhlbnRpY2F0ZWQgJiYgdG90YWxJdGVtcyA+IDAgJiYgKFxuICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwiZGVmYXVsdFwiIGNsYXNzTmFtZT1cInB4LTEuNSBmb250LW1vbm8gdGV4dC14cyB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgIHt0b3RhbEl0ZW1zfVxuICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICl9XG4gICAgICA8L1NoZWV0VHJpZ2dlcj5cblxuICAgICAgPFNoZWV0Q29udGVudCBzaWRlPVwicmlnaHRcIiBjbGFzc05hbWU9XCJmbGV4IHctZnVsbCBmbGV4LWNvbCBzbTptYXgtdy1tZFwiPlxuICAgICAgICA8U2hlZXRIZWFkZXI+XG4gICAgICAgICAgPFNoZWV0VGl0bGUgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxTaG9wcGluZ0JhZyBjbGFzc05hbWU9XCJzaXplLTQgdGV4dC1wcmltYXJ5XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPk1ldSBDYXJyaW5obzwvc3Bhbj5cbiAgICAgICAgICA8L1NoZWV0VGl0bGU+XG4gICAgICAgICAgPFNoZWV0RGVzY3JpcHRpb24+XG4gICAgICAgICAgICBHZXJlbmNpZSBxdWFudGlkYWRlcywgYXBsaXF1ZSBjdXBvbnMgZSBjb25maXJhIG8gdG90YWwgZW0gRVRILlxuICAgICAgICAgIDwvU2hlZXREZXNjcmlwdGlvbj5cbiAgICAgICAgPC9TaGVldEhlYWRlcj5cblxuICAgICAgICA8U2VwYXJhdG9yIC8+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtMSBmbGV4LWNvbCBnYXAtNCBvdmVyZmxvdy15LWF1dG8gcHgtNCBwYi02XCI+XG4gICAgICAgICAgeyFpc0F1dGhlbnRpY2F0ZWQgPyAoXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm15LWF1dG8gZmxleCBmbGV4LWNvbCBpdGVtcy1jZW50ZXIgZ2FwLTMgcHktMTIgdGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgICAgPFNob3BwaW5nQmFnIGNsYXNzTmFtZT1cInNpemUtOCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtXCI+U3VhIHNlc3PDo28gbsOjbyBlc3TDoSBhdXRlbnRpY2FkYS48L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgRW50cmUgbmEgc3VhIGNvbnRhIHBhcmEgc2luY3Jvbml6YXIgZSBnZXJlbmNpYXIgc2V1IGNhcnJpbmhvIGRlIE5GVHMuXG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgPFNoZWV0Q2xvc2VcbiAgICAgICAgICAgICAgICByZW5kZXI9e1xuICAgICAgICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgICAgICAgdG89XCIvbG9naW5cIlxuICAgICAgICAgICAgICAgICAgICBzZWFyY2g9e3sgcmVkaXJlY3Q6ICcvY2FydCcgfX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihidXR0b25WYXJpYW50cyh7IHZhcmlhbnQ6ICdkZWZhdWx0Jywgc2l6ZTogJ3NtJyB9KSl9XG4gICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIEVudHJhciBuYSBjb250YVxuICAgICAgICAgICAgICA8L1NoZWV0Q2xvc2U+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogaXNMb2FkaW5nID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0zXCIgYXJpYS1idXN5PVwidHJ1ZVwiIGFyaWEtbGFiZWw9XCJDYXJyZWdhbmRvIGNhcnJpbmhvXCI+XG4gICAgICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTI0IHctZnVsbCByb3VuZGVkLXhsXCIgLz5cbiAgICAgICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtMjQgdy1mdWxsIHJvdW5kZWQteGxcIiAvPlxuICAgICAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC01NiB3LWZ1bGwgcm91bmRlZC14bFwiIC8+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApIDogaXNFcnJvciA/IChcbiAgICAgICAgICAgIDxBbGVydCB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cInNpemUtNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgIDxBbGVydFRpdGxlPkVycm8gYW8gY2FycmVnYXIgbyBjYXJyaW5obzwvQWxlcnRUaXRsZT5cbiAgICAgICAgICAgICAgPEFsZXJ0RGVzY3JpcHRpb24gY2xhc3NOYW1lPVwibXQtMiBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3Bhbj57Z2V0RXJyb3JNZXNzYWdlKGVycm9yKX08L3NwYW4+XG4gICAgICAgICAgICAgICAgPEJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgdmFyaWFudD1cIm91dGxpbmVcIiBzaXplPVwieHNcIiBvbkNsaWNrPXsoKSA9PiB2b2lkIHJlZmV0Y2goKX0+XG4gICAgICAgICAgICAgICAgICA8UmVmcmVzaEN3IGNsYXNzTmFtZT1cInNpemUtM1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5UZW50YXI8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgIDwvQWxlcnREZXNjcmlwdGlvbj5cbiAgICAgICAgICAgIDwvQWxlcnQ+XG4gICAgICAgICAgKSA6ICFjYXJ0IHx8IGNhcnQuaXRlbXMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJteS1hdXRvIGZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGdhcC0zIHB5LTEyIHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICAgIDxTaG9wcGluZ0JhZyBjbGFzc05hbWU9XCJzaXplLTggdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPlNldSBjYXJyaW5obyBlc3TDoSB2YXppby48L3A+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgRXhwbG9yZSBvIGNhdMOhbG9nbyBlIGFkaWNpb25lIE5GVHMgcmFyb3Mgw6Agc3VhIGNvbGXDp8Ojby5cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGp1c3RpZnktY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgPFNoZWV0Q2xvc2VcbiAgICAgICAgICAgICAgICAgIHJlbmRlcj17XG4gICAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgICAgdG89XCIvXCJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKGJ1dHRvblZhcmlhbnRzKHsgdmFyaWFudDogJ291dGxpbmUnLCBzaXplOiAnc20nIH0pKX1cbiAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBFeHBsb3JhciBORlRzXG4gICAgICAgICAgICAgICAgPC9TaGVldENsb3NlPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICA8PlxuICAgICAgICAgICAgICA8c2VjdGlvbiBhcmlhLWxhYmVsPVwiSXRlbnMgbm8gY2FycmluaG9cIiBjbGFzc05hbWU9XCJncmlkIGdhcC0yLjVcIj5cbiAgICAgICAgICAgICAgICB7Y2FydC5pdGVtcy5tYXAoKGl0ZW0pID0+IChcbiAgICAgICAgICAgICAgICAgIDxDYXJ0SXRlbVJvdyBrZXk9e2l0ZW0uaWR9IGl0ZW09e2l0ZW19IGNvbXBhY3QgLz5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9zZWN0aW9uPlxuXG4gICAgICAgICAgICAgIDxDYXJ0U3VtbWFyeSBjYXJ0PXtjYXJ0fSBvbk5hdmlnYXRlQ2hlY2tvdXQ9eygpID0+IHNldE9wZW4oZmFsc2UpfSAvPlxuXG4gICAgICAgICAgICAgIDxTaGVldENsb3NlXG4gICAgICAgICAgICAgICAgcmVuZGVyPXtcbiAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgIHRvPVwiL2NhcnRcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKGJ1dHRvblZhcmlhbnRzKHsgdmFyaWFudDogJ2dob3N0Jywgc2l6ZTogJ3NtJyB9KSwgJ3ctZnVsbCcpfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBBYnJpciBww6FnaW5hIGNvbXBsZXRhIGRvIGNhcnJpbmhvXG4gICAgICAgICAgICAgIDwvU2hlZXRDbG9zZT5cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9TaGVldENvbnRlbnQ+XG4gICAgPC9TaGVldD5cbiAgKVxufVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvY29tcG9uZW50cy9jYXJ0L2NhcnQtZHJhd2VyLnRzeCJ9