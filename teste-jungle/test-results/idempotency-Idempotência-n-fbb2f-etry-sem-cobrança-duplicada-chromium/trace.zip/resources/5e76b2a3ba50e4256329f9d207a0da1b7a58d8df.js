import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/nft/nft-card.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport14_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=e9f94b2e";
import { Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { AddToCartButton } from "/src/components/cart/add-to-cart-button.tsx";
import { FavoriteButton } from "/src/components/nft/favorite-button.tsx";
import { Avatar, AvatarFallback } from "/src/components/ui/avatar.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { buttonVariants } from "/src/components/ui/button.tsx";
import { Card, CardContent, CardFooter, CardHeader } from "/src/components/ui/card.tsx";
import { Separator } from "/src/components/ui/separator.tsx";
import { formatEth } from "/src/lib/eth.ts";
import { cn, getInitials } from "/src/lib/utils.ts";
import { CATEGORY_LABELS } from "/src/schemas/nft-search.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-card.tsx";
import __vite__cjsImport14_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
const categoryBadgeVariants = cva("bg-background/90 backdrop-blur-sm", {
	variants: { category: {
		art: "text-foreground",
		music: "text-foreground",
		photography: "text-foreground",
		game: "text-foreground",
		collectible: "text-foreground"
	} },
	defaultVariants: { category: "art" }
});
export function NftCard(t0) {
	const $ = _c(73);
	if ($[0] !== "6c3048ce7cbdd3a29becae6278e8495d7d28e0669c4d06085ba129abedc2900d") {
		for (let $i = 0; $i < 73; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "6c3048ce7cbdd3a29becae6278e8495d7d28e0669c4d06085ba129abedc2900d";
	}
	const { nft, priority: t1, className } = t0;
	const priority = t1 === undefined ? false : t1;
	let t2;
	if ($[1] !== className) {
		t2 = cn("h-full", className);
		$[1] = className;
		$[2] = t2;
	} else {
		t2 = $[2];
	}
	const t3 = `Obra NFT ${nft.name} da coleção ${nft.collection}, criada por ${nft.creatorName}`;
	const t4 = priority ? "eager" : "lazy";
	const t5 = priority ? "high" : "auto";
	const t6 = priority ? "sync" : "async";
	let t7;
	if ($[3] !== nft.imageUrl || $[4] !== t3 || $[5] !== t4 || $[6] !== t5 || $[7] !== t6) {
		t7 = /* @__PURE__ */ _jsxDEV("img", {
			src: nft.imageUrl,
			alt: t3,
			loading: t4,
			fetchPriority: t5,
			decoding: t6,
			className: "size-full object-cover transition-transform duration-300 group-hover:scale-105 motion-reduce:transition-none motion-reduce:group-hover:scale-100"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 10
		}, this);
		$[3] = nft.imageUrl;
		$[4] = t3;
		$[5] = t4;
		$[6] = t5;
		$[7] = t6;
		$[8] = t7;
	} else {
		t7 = $[8];
	}
	let t8;
	if ($[9] !== nft.category) {
		t8 = categoryBadgeVariants({ category: nft.category });
		$[9] = nft.category;
		$[10] = t8;
	} else {
		t8 = $[10];
	}
	const t9 = CATEGORY_LABELS[nft.category];
	let t10;
	if ($[11] !== t8 || $[12] !== t9) {
		t10 = /* @__PURE__ */ _jsxDEV(Badge, {
			variant: "secondary",
			className: t8,
			children: t9
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 87,
			columnNumber: 11
		}, this);
		$[11] = t8;
		$[12] = t9;
		$[13] = t10;
	} else {
		t10 = $[13];
	}
	let t11;
	if ($[14] !== nft.id || $[15] !== nft.isFavorited || $[16] !== nft.likes || $[17] !== nft.name) {
		t11 = /* @__PURE__ */ _jsxDEV(FavoriteButton, {
			nftId: nft.id,
			nftName: nft.name,
			isFavorited: nft.isFavorited,
			likes: nft.likes
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 11
		}, this);
		$[14] = nft.id;
		$[15] = nft.isFavorited;
		$[16] = nft.likes;
		$[17] = nft.name;
		$[18] = t11;
	} else {
		t11 = $[18];
	}
	let t12;
	if ($[19] !== t10 || $[20] !== t11) {
		t12 = /* @__PURE__ */ _jsxDEV("div", {
			className: "absolute inset-x-3 top-3 flex items-center justify-between gap-2",
			children: [t10, t11]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 107,
			columnNumber: 11
		}, this);
		$[19] = t10;
		$[20] = t11;
		$[21] = t12;
	} else {
		t12 = $[21];
	}
	let t13;
	if ($[22] !== nft.available) {
		t13 = !nft.available && /* @__PURE__ */ _jsxDEV("div", {
			className: "absolute bottom-3 left-3",
			children: /* @__PURE__ */ _jsxDEV(Badge, {
				variant: "destructive",
				children: "Vendido"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 116,
				columnNumber: 71
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 116,
			columnNumber: 29
		}, this);
		$[22] = nft.available;
		$[23] = t13;
	} else {
		t13 = $[23];
	}
	let t14;
	if ($[24] !== t12 || $[25] !== t13 || $[26] !== t7) {
		t14 = /* @__PURE__ */ _jsxDEV("div", {
			className: "relative aspect-square w-full overflow-hidden bg-muted",
			children: [
				t7,
				t12,
				t13
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 124,
			columnNumber: 11
		}, this);
		$[24] = t12;
		$[25] = t13;
		$[26] = t7;
		$[27] = t14;
	} else {
		t14 = $[27];
	}
	let t15;
	if ($[28] !== nft.collection) {
		t15 = /* @__PURE__ */ _jsxDEV("p", {
			className: "truncate text-xs font-medium text-muted-foreground",
			children: nft.collection
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 134,
			columnNumber: 11
		}, this);
		$[28] = nft.collection;
		$[29] = t15;
	} else {
		t15 = $[29];
	}
	let t16;
	if ($[30] !== nft.id) {
		t16 = { nftId: nft.id };
		$[30] = nft.id;
		$[31] = t16;
	} else {
		t16 = $[31];
	}
	let t17;
	if ($[32] !== nft.name || $[33] !== t16) {
		t17 = /* @__PURE__ */ _jsxDEV("h2", {
			className: "truncate text-base font-semibold leading-snug",
			children: /* @__PURE__ */ _jsxDEV(Link, {
				to: "/nfts/$nftId",
				params: t16,
				className: "rounded-sm hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
				children: nft.name
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 152,
				columnNumber: 73
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 152,
			columnNumber: 11
		}, this);
		$[32] = nft.name;
		$[33] = t16;
		$[34] = t17;
	} else {
		t17 = $[34];
	}
	let t18;
	if ($[35] !== nft.creatorName) {
		t18 = getInitials(nft.creatorName);
		$[35] = nft.creatorName;
		$[36] = t18;
	} else {
		t18 = $[36];
	}
	let t19;
	if ($[37] !== t18) {
		t19 = /* @__PURE__ */ _jsxDEV(Avatar, {
			size: "sm",
			children: /* @__PURE__ */ _jsxDEV(AvatarFallback, { children: t18 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 169,
				columnNumber: 29
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 169,
			columnNumber: 11
		}, this);
		$[37] = t18;
		$[38] = t19;
	} else {
		t19 = $[38];
	}
	let t20;
	if ($[39] !== nft.creatorName) {
		t20 = /* @__PURE__ */ _jsxDEV("span", {
			className: "truncate text-xs text-muted-foreground",
			children: nft.creatorName
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 177,
			columnNumber: 11
		}, this);
		$[39] = nft.creatorName;
		$[40] = t20;
	} else {
		t20 = $[40];
	}
	let t21;
	if ($[41] !== t19 || $[42] !== t20) {
		t21 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-2 pt-0.5",
			children: [t19, t20]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 185,
			columnNumber: 11
		}, this);
		$[41] = t19;
		$[42] = t20;
		$[43] = t21;
	} else {
		t21 = $[43];
	}
	let t22;
	if ($[44] !== t15 || $[45] !== t17 || $[46] !== t21) {
		t22 = /* @__PURE__ */ _jsxDEV(CardHeader, {
			className: "gap-1.5 pb-2",
			children: [
				t15,
				t17,
				t21
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 194,
			columnNumber: 11
		}, this);
		$[44] = t15;
		$[45] = t17;
		$[46] = t21;
		$[47] = t22;
	} else {
		t22 = $[47];
	}
	let t23;
	if ($[48] === Symbol.for("react.memo_cache_sentinel")) {
		t23 = /* @__PURE__ */ _jsxDEV("span", {
			className: "text-xs text-muted-foreground",
			children: "Preço atual"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 204,
			columnNumber: 11
		}, this);
		$[48] = t23;
	} else {
		t23 = $[48];
	}
	let t24;
	if ($[49] === Symbol.for("react.memo_cache_sentinel")) {
		t24 = /* @__PURE__ */ _jsxDEV(Sparkles, {
			className: "size-3.5 text-primary",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 211,
			columnNumber: 11
		}, this);
		$[49] = t24;
	} else {
		t24 = $[49];
	}
	let t25;
	if ($[50] !== nft.priceEth) {
		t25 = formatEth(nft.priceEth);
		$[50] = nft.priceEth;
		$[51] = t25;
	} else {
		t25 = $[51];
	}
	let t26;
	if ($[52] !== t25) {
		t26 = /* @__PURE__ */ _jsxDEV(CardContent, {
			className: "mt-auto pt-0",
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "flex items-baseline justify-between rounded-lg bg-muted/60 px-3 py-2",
				children: [t23, /* @__PURE__ */ _jsxDEV("span", {
					className: "flex items-center gap-1 font-mono text-sm font-semibold tabular-nums",
					children: [
						t24,
						t25,
						" ETH"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 226,
					columnNumber: 140
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 226,
				columnNumber: 49
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 226,
			columnNumber: 11
		}, this);
		$[52] = t25;
		$[53] = t26;
	} else {
		t26 = $[53];
	}
	let t27;
	if ($[54] === Symbol.for("react.memo_cache_sentinel")) {
		t27 = /* @__PURE__ */ _jsxDEV(Separator, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 234,
			columnNumber: 11
		}, this);
		$[54] = t27;
	} else {
		t27 = $[54];
	}
	let t28;
	if ($[55] !== nft.id) {
		t28 = { nftId: nft.id };
		$[55] = nft.id;
		$[56] = t28;
	} else {
		t28 = $[56];
	}
	let t29;
	if ($[57] === Symbol.for("react.memo_cache_sentinel")) {
		t29 = cn(buttonVariants({
			variant: "outline",
			size: "sm"
		}), "w-full");
		$[57] = t29;
	} else {
		t29 = $[57];
	}
	let t30;
	if ($[58] !== t28) {
		t30 = /* @__PURE__ */ _jsxDEV(Link, {
			to: "/nfts/$nftId",
			params: t28,
			className: t29,
			children: "Detalhes"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 261,
			columnNumber: 11
		}, this);
		$[58] = t28;
		$[59] = t30;
	} else {
		t30 = $[59];
	}
	let t31;
	if ($[60] !== nft) {
		t31 = /* @__PURE__ */ _jsxDEV(AddToCartButton, {
			nft,
			label: "Adicionar",
			size: "sm",
			className: "w-full"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 269,
			columnNumber: 11
		}, this);
		$[60] = nft;
		$[61] = t31;
	} else {
		t31 = $[61];
	}
	let t32;
	if ($[62] !== t30 || $[63] !== t31) {
		t32 = /* @__PURE__ */ _jsxDEV(CardFooter, {
			className: "grid grid-cols-2 gap-2 pt-3",
			children: [t30, t31]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 277,
			columnNumber: 11
		}, this);
		$[62] = t30;
		$[63] = t31;
		$[64] = t32;
	} else {
		t32 = $[64];
	}
	let t33;
	if ($[65] !== t14 || $[66] !== t22 || $[67] !== t26 || $[68] !== t32) {
		t33 = /* @__PURE__ */ _jsxDEV(Card, {
			className: "group flex h-full flex-col overflow-hidden pt-0 transition-shadow hover:shadow-md",
			children: [
				t14,
				t22,
				t26,
				t27,
				t32
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 286,
			columnNumber: 11
		}, this);
		$[65] = t14;
		$[66] = t22;
		$[67] = t26;
		$[68] = t32;
		$[69] = t33;
	} else {
		t33 = $[69];
	}
	let t34;
	if ($[70] !== t2 || $[71] !== t33) {
		t34 = /* @__PURE__ */ _jsxDEV("article", {
			className: t2,
			children: t33
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 297,
			columnNumber: 11
		}, this);
		$[70] = t2;
		$[71] = t33;
		$[72] = t34;
	} else {
		t34 = $[72];
	}
	return t34;
}
_c2 = NftCard;
var _c2;
$RefreshReg$(_c2, "NftCard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/nft/nft-card.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-card.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-card.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLFlBQVk7QUFDckIsU0FBU0MsV0FBVztBQUNwQixTQUFTQyxnQkFBZ0I7QUFDekIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxRQUFRQyxzQkFBc0I7QUFDdkMsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsTUFBTUMsYUFBYUMsWUFBWUMsa0JBQWtCO0FBQzFELFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsSUFBSUMsbUJBQW1CO0FBQ2hDLFNBQVNDLHVCQUF1Qjs7O0FBR2hDLE1BQU1DLHdCQUF3QmpCLElBQUkscUNBQXFDO0NBQ3JFa0IsVUFBVSxFQUNSQyxVQUFVO0VBQ1JDLEtBQUs7RUFDTEMsT0FBTztFQUNQQyxhQUFhO0VBQ2JDLE1BQU07RUFDTkMsYUFBYTtDQUNmLEVBQ0Y7Q0FDQUMsaUJBQWlCLEVBQ2ZOLFVBQVUsTUFDWjtBQUNGLENBQUM7QUFTRCxPQUFPLFNBQUFPLFFBQUFDLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBaUIsUUFBQUssS0FBQUMsVUFBQUMsSUFBQUMsY0FBQVQ7Q0FBTyxNQUFBTyxXQUFBQyxPQUFBRSxZQUFBLFFBQUFGO0NBQWdCLElBQUFHO0NBQUEsSUFBQVYsRUFBQSxPQUFBUSxXQUFBO0VBRXZCRSxLQUFBeEIsR0FBRyxVQUFVc0IsU0FBUztFQUFDUixFQUFBLEtBQUFRO0VBQUFSLEVBQUEsS0FBQVU7Q0FBQTtFQUFBQSxLQUFBVixFQUFBO0NBQUE7Q0FLOUIsTUFBQVcsS0FBQSxZQUFZTixJQUFHTyxLQUFLLGNBQWVQLElBQUdRLFdBQVcsZUFBZ0JSLElBQUdTO0NBQ2hFLE1BQUFDLEtBQUFULFdBQUE7Q0FDTSxNQUFBVSxLQUFBVixXQUFBO0NBQ0wsTUFBQVcsS0FBQVgsV0FBQTtDQUEyQixJQUFBWTtDQUFBLElBQUFsQixFQUFBLE9BQUFLLElBQUFjLFlBQUFuQixFQUFBLE9BQUFXLE1BQUFYLEVBQUEsT0FBQWUsTUFBQWYsRUFBQSxPQUFBZ0IsTUFBQWhCLEVBQUEsT0FBQWlCLElBQUE7RUFMdkNDLEtBQUE7R0FDTyxLQUFBYixJQUFHYztHQUNILEtBQUFSO0dBQ0ksU0FBQUk7R0FDTSxlQUFBQztHQUNMLFVBQUFDO0dBQ0E7RUFBa0o7Ozs7O0VBQzVKakIsRUFBQSxLQUFBSyxJQUFBYztFQUFBbkIsRUFBQSxLQUFBVztFQUFBWCxFQUFBLEtBQUFlO0VBQUFmLEVBQUEsS0FBQWdCO0VBQUFoQixFQUFBLEtBQUFpQjtFQUFBakIsRUFBQSxLQUFBa0I7Q0FBQTtFQUFBQSxLQUFBbEIsRUFBQTtDQUFBO0NBQUEsSUFBQW9CO0NBQUEsSUFBQXBCLEVBQUEsT0FBQUssSUFBQWQsVUFBQTtFQUVzQzZCLEtBQUEvQixzQkFBc0IsRUFBQUUsVUFBWWMsSUFBR2QsU0FBVSxDQUFDO0VBQUNTLEVBQUEsS0FBQUssSUFBQWQ7RUFBQVMsRUFBQSxNQUFBb0I7Q0FBQTtFQUFBQSxLQUFBcEIsRUFBQTtDQUFBO0NBQ3BGLE1BQUFxQixLQUFBakMsZ0JBQWdCaUIsSUFBR2Q7Q0FBVSxJQUFBK0I7Q0FBQSxJQUFBdEIsRUFBQSxRQUFBb0IsTUFBQXBCLEVBQUEsUUFBQXFCLElBQUE7RUFEaENDLE1BQUEsd0JBQUMsT0FBRDtHQUFlO0dBQXVCLFdBQUFGO2FBQ25DQztFQURHOzs7OztFQUVFckIsRUFBQSxNQUFBb0I7RUFBQXBCLEVBQUEsTUFBQXFCO0VBQUFyQixFQUFBLE1BQUFzQjtDQUFBO0VBQUFBLE1BQUF0QixFQUFBO0NBQUE7Q0FBQSxJQUFBdUI7Q0FBQSxJQUFBdkIsRUFBQSxRQUFBSyxJQUFBbUIsTUFBQXhCLEVBQUEsUUFBQUssSUFBQW9CLGVBQUF6QixFQUFBLFFBQUFLLElBQUFxQixTQUFBMUIsRUFBQSxRQUFBSyxJQUFBTyxNQUFBO0VBQ1JXLE1BQUEsd0JBQUMsZ0JBQUQ7R0FDUyxPQUFBbEIsSUFBR21CO0dBQ0QsU0FBQW5CLElBQUdPO0dBQ0MsYUFBQVAsSUFBR29CO0dBQ1QsT0FBQXBCLElBQUdxQjtFQUFNOzs7OztFQUNoQjFCLEVBQUEsTUFBQUssSUFBQW1CO0VBQUF4QixFQUFBLE1BQUFLLElBQUFvQjtFQUFBekIsRUFBQSxNQUFBSyxJQUFBcUI7RUFBQTFCLEVBQUEsTUFBQUssSUFBQU87RUFBQVosRUFBQSxNQUFBdUI7Q0FBQTtFQUFBQSxNQUFBdkIsRUFBQTtDQUFBO0NBQUEsSUFBQTJCO0NBQUEsSUFBQTNCLEVBQUEsUUFBQXNCLE9BQUF0QixFQUFBLFFBQUF1QixLQUFBO0VBVEpJLE1BQUE7R0FBZTthQUFmLENBQ0VMLEtBR0FDLEdBTUk7Ozs7OztFQUFBdkIsRUFBQSxNQUFBc0I7RUFBQXRCLEVBQUEsTUFBQXVCO0VBQUF2QixFQUFBLE1BQUEyQjtDQUFBO0VBQUFBLE1BQUEzQixFQUFBO0NBQUE7Q0FBQSxJQUFBNEI7Q0FBQSxJQUFBNUIsRUFBQSxRQUFBSyxJQUFBd0IsV0FBQTtFQUNMRCxNQUFBLENBQUN2QixJQUFHd0IsYUFDSDtHQUFlO2FBQ2Isd0JBQUMsT0FBRDtJQUFlO2NBQWM7R0FBdkI7Ozs7O0VBQ0Y7Ozs7O0VBQ1A3QixFQUFBLE1BQUFLLElBQUF3QjtFQUFBN0IsRUFBQSxNQUFBNEI7Q0FBQTtFQUFBQSxNQUFBNUIsRUFBQTtDQUFBO0NBQUEsSUFBQThCO0NBQUEsSUFBQTlCLEVBQUEsUUFBQTJCLE9BQUEzQixFQUFBLFFBQUE0QixPQUFBNUIsRUFBQSxRQUFBa0IsSUFBQTtFQXhCSFksTUFBQTtHQUFlO2FBQWY7SUFDRVo7SUFRQVM7SUFXQ0M7R0FLRzs7Ozs7O0VBQUE1QixFQUFBLE1BQUEyQjtFQUFBM0IsRUFBQSxNQUFBNEI7RUFBQTVCLEVBQUEsTUFBQWtCO0VBQUFsQixFQUFBLE1BQUE4QjtDQUFBO0VBQUFBLE1BQUE5QixFQUFBO0NBQUE7Q0FBQSxJQUFBK0I7Q0FBQSxJQUFBL0IsRUFBQSxRQUFBSyxJQUFBUSxZQUFBO0VBR0prQixNQUFBO0dBQWE7YUFBc0QxQixJQUFHUTtFQUFnQjs7Ozs7RUFBQWIsRUFBQSxNQUFBSyxJQUFBUTtFQUFBYixFQUFBLE1BQUErQjtDQUFBO0VBQUFBLE1BQUEvQixFQUFBO0NBQUE7Q0FBQSxJQUFBZ0M7Q0FBQSxJQUFBaEMsRUFBQSxRQUFBSyxJQUFBbUIsSUFBQTtFQUkxRVEsTUFBQSxFQUFBQyxPQUFTNUIsSUFBR21CLEdBQUk7RUFBQ3hCLEVBQUEsTUFBQUssSUFBQW1CO0VBQUF4QixFQUFBLE1BQUFnQztDQUFBO0VBQUFBLE1BQUFoQyxFQUFBO0NBQUE7Q0FBQSxJQUFBa0M7Q0FBQSxJQUFBbEMsRUFBQSxRQUFBSyxJQUFBTyxRQUFBWixFQUFBLFFBQUFnQyxLQUFBO0VBSDdCRSxNQUFBO0dBQWM7YUFDWix3QkFBQyxNQUFEO0lBQ0s7SUFDSyxRQUFBRjtJQUNFO2NBRVQzQixJQUFHTztHQUxEOzs7OztFQU9GOzs7OztFQUFBWixFQUFBLE1BQUFLLElBQUFPO0VBQUFaLEVBQUEsTUFBQWdDO0VBQUFoQyxFQUFBLE1BQUFrQztDQUFBO0VBQUFBLE1BQUFsQyxFQUFBO0NBQUE7Q0FBQSxJQUFBbUM7Q0FBQSxJQUFBbkMsRUFBQSxRQUFBSyxJQUFBUyxhQUFBO0VBR2dCcUIsTUFBQWhELFlBQVlrQixJQUFHUyxXQUFZO0VBQUNkLEVBQUEsTUFBQUssSUFBQVM7RUFBQWQsRUFBQSxNQUFBbUM7Q0FBQTtFQUFBQSxNQUFBbkMsRUFBQTtDQUFBO0NBQUEsSUFBQW9DO0NBQUEsSUFBQXBDLEVBQUEsUUFBQW1DLEtBQUE7RUFEL0NDLE1BQUEsd0JBQUMsUUFBRDtHQUFhO2FBQ1gsd0JBQUMsZ0JBQUQsWUFBaUJELElBQUY7Ozs7O0VBRFY7Ozs7O0VBRUVuQyxFQUFBLE1BQUFtQztFQUFBbkMsRUFBQSxNQUFBb0M7Q0FBQTtFQUFBQSxNQUFBcEMsRUFBQTtDQUFBO0NBQUEsSUFBQXFDO0NBQUEsSUFBQXJDLEVBQUEsUUFBQUssSUFBQVMsYUFBQTtFQUNUdUIsTUFBQTtHQUFnQjthQUEwQ2hDLElBQUdTO0VBQW9COzs7OztFQUFBZCxFQUFBLE1BQUFLLElBQUFTO0VBQUFkLEVBQUEsTUFBQXFDO0NBQUE7RUFBQUEsTUFBQXJDLEVBQUE7Q0FBQTtDQUFBLElBQUFzQztDQUFBLElBQUF0QyxFQUFBLFFBQUFvQyxPQUFBcEMsRUFBQSxRQUFBcUMsS0FBQTtFQUpuRkMsTUFBQTtHQUFlO2FBQWYsQ0FDRUYsS0FHQUMsR0FDSTs7Ozs7O0VBQUFyQyxFQUFBLE1BQUFvQztFQUFBcEMsRUFBQSxNQUFBcUM7RUFBQXJDLEVBQUEsTUFBQXNDO0NBQUE7RUFBQUEsTUFBQXRDLEVBQUE7Q0FBQTtDQUFBLElBQUF1QztDQUFBLElBQUF2QyxFQUFBLFFBQUErQixPQUFBL0IsRUFBQSxRQUFBa0MsT0FBQWxDLEVBQUEsUUFBQXNDLEtBQUE7RUFoQlJDLE1BQUEsd0JBQUMsWUFBRDtHQUFzQjthQUF0QjtJQUNFUjtJQUNBRztJQVNBSTtHQVhTOzs7Ozs7RUFpQkV0QyxFQUFBLE1BQUErQjtFQUFBL0IsRUFBQSxNQUFBa0M7RUFBQWxDLEVBQUEsTUFBQXNDO0VBQUF0QyxFQUFBLE1BQUF1QztDQUFBO0VBQUFBLE1BQUF2QyxFQUFBO0NBQUE7Q0FBQSxJQUFBd0M7Q0FBQSxJQUFBeEMsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBSVRvQyxNQUFBO0dBQWdCO2FBQWdDO0VBQWtCOzs7OztFQUFBeEMsRUFBQSxNQUFBd0M7Q0FBQTtFQUFBQSxNQUFBeEMsRUFBQTtDQUFBO0NBQUEsSUFBQXlDO0NBQUEsSUFBQXpDLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUVoRXFDLE1BQUEsd0JBQUMsVUFBRDtHQUFvQjtHQUFvQztFQUFNOzs7OztFQUFHekMsRUFBQSxNQUFBeUM7Q0FBQTtFQUFBQSxNQUFBekMsRUFBQTtDQUFBO0NBQUEsSUFBQTBDO0NBQUEsSUFBQTFDLEVBQUEsUUFBQUssSUFBQXNDLFVBQUE7RUFDaEVELE1BQUF6RCxVQUFVb0IsSUFBR3NDLFFBQVM7RUFBQzNDLEVBQUEsTUFBQUssSUFBQXNDO0VBQUEzQyxFQUFBLE1BQUEwQztDQUFBO0VBQUFBLE1BQUExQyxFQUFBO0NBQUE7Q0FBQSxJQUFBNEM7Q0FBQSxJQUFBNUMsRUFBQSxRQUFBMEMsS0FBQTtFQUw5QkUsTUFBQSx3QkFBQyxhQUFEO0dBQXVCO2FBQ3JCO0lBQWU7Y0FBZixDQUNFSixLQUNBO0tBQWdCO2VBQWhCO01BQ0VDO01BQ0NDO01BQXdCO0tBQ3BCOzs7OztZQUNIOzs7Ozs7RUFQSTs7Ozs7RUFRRTFDLEVBQUEsTUFBQTBDO0VBQUExQyxFQUFBLE1BQUE0QztDQUFBO0VBQUFBLE1BQUE1QyxFQUFBO0NBQUE7Q0FBQSxJQUFBNkM7Q0FBQSxJQUFBN0MsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBRWR5QyxNQUFBLHdCQUFDLFdBQUQsQ0FBVTs7Ozs7RUFBRzdDLEVBQUEsTUFBQTZDO0NBQUE7RUFBQUEsTUFBQTdDLEVBQUE7Q0FBQTtDQUFBLElBQUE4QztDQUFBLElBQUE5QyxFQUFBLFFBQUFLLElBQUFtQixJQUFBO0VBS0RzQixNQUFBLEVBQUFiLE9BQVM1QixJQUFHbUIsR0FBSTtFQUFDeEIsRUFBQSxNQUFBSyxJQUFBbUI7RUFBQXhCLEVBQUEsTUFBQThDO0NBQUE7RUFBQUEsTUFBQTlDLEVBQUE7Q0FBQTtDQUFBLElBQUErQztDQUFBLElBQUEvQyxFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFDZDJDLE1BQUE3RCxHQUFHUCxlQUFlO0dBQUFxRSxTQUFXO0dBQVNDLE1BQVE7RUFBSyxDQUFDLEdBQUcsUUFBUTtFQUFDakQsRUFBQSxNQUFBK0M7Q0FBQTtFQUFBQSxNQUFBL0MsRUFBQTtDQUFBO0NBQUEsSUFBQWtEO0NBQUEsSUFBQWxELEVBQUEsUUFBQThDLEtBQUE7RUFIN0VJLE1BQUEsd0JBQUMsTUFBRDtHQUNLO0dBQ0ssUUFBQUo7R0FDRyxXQUFBQzthQUNaO0VBSkk7Ozs7O0VBTUUvQyxFQUFBLE1BQUE4QztFQUFBOUMsRUFBQSxNQUFBa0Q7Q0FBQTtFQUFBQSxNQUFBbEQsRUFBQTtDQUFBO0NBQUEsSUFBQW1EO0NBQUEsSUFBQW5ELEVBQUEsUUFBQUssS0FBQTtFQUNQOEMsTUFBQSx3QkFBQyxpQkFBRDtHQUFzQjlDO0dBQVc7R0FBaUI7R0FBZTtFQUFROzs7OztFQUFHTCxFQUFBLE1BQUFLO0VBQUFMLEVBQUEsTUFBQW1EO0NBQUE7RUFBQUEsTUFBQW5ELEVBQUE7Q0FBQTtDQUFBLElBQUFvRDtDQUFBLElBQUFwRCxFQUFBLFFBQUFrRCxPQUFBbEQsRUFBQSxRQUFBbUQsS0FBQTtFQVI5RUMsTUFBQSx3QkFBQyxZQUFEO0dBQXNCO2FBQXRCLENBQ0VGLEtBT0FDLEdBUlM7Ozs7OztFQVNFbkQsRUFBQSxNQUFBa0Q7RUFBQWxELEVBQUEsTUFBQW1EO0VBQUFuRCxFQUFBLE1BQUFvRDtDQUFBO0VBQUFBLE1BQUFwRCxFQUFBO0NBQUE7Q0FBQSxJQUFBcUQ7Q0FBQSxJQUFBckQsRUFBQSxRQUFBOEIsT0FBQTlCLEVBQUEsUUFBQXVDLE9BQUF2QyxFQUFBLFFBQUE0QyxPQUFBNUMsRUFBQSxRQUFBb0QsS0FBQTtFQXBFZkMsTUFBQSx3QkFBQyxNQUFEO0dBQWdCO2FBQWhCO0lBQ0V2QjtJQTJCQVM7SUFtQkFLO0lBVUFDO0lBRUFPO0dBM0RHOzs7Ozs7RUFxRUVwRCxFQUFBLE1BQUE4QjtFQUFBOUIsRUFBQSxNQUFBdUM7RUFBQXZDLEVBQUEsTUFBQTRDO0VBQUE1QyxFQUFBLE1BQUFvRDtFQUFBcEQsRUFBQSxNQUFBcUQ7Q0FBQTtFQUFBQSxNQUFBckQsRUFBQTtDQUFBO0NBQUEsSUFBQXNEO0NBQUEsSUFBQXRELEVBQUEsUUFBQVUsTUFBQVYsRUFBQSxRQUFBcUQsS0FBQTtFQXRFVEMsTUFBQTtHQUFvQixXQUFBNUM7YUFDbEIyQztFQXNFUTs7Ozs7RUFBQXJELEVBQUEsTUFBQVU7RUFBQVYsRUFBQSxNQUFBcUQ7RUFBQXJELEVBQUEsTUFBQXNEO0NBQUE7RUFBQUEsTUFBQXRELEVBQUE7Q0FBQTtDQUFBLE9BdkVWc0Q7QUF1RVUiLCJuYW1lcyI6WyJMaW5rIiwiY3ZhIiwiU3BhcmtsZXMiLCJBZGRUb0NhcnRCdXR0b24iLCJGYXZvcml0ZUJ1dHRvbiIsIkF2YXRhciIsIkF2YXRhckZhbGxiYWNrIiwiQmFkZ2UiLCJidXR0b25WYXJpYW50cyIsIkNhcmQiLCJDYXJkQ29udGVudCIsIkNhcmRGb290ZXIiLCJDYXJkSGVhZGVyIiwiU2VwYXJhdG9yIiwiZm9ybWF0RXRoIiwiY24iLCJnZXRJbml0aWFscyIsIkNBVEVHT1JZX0xBQkVMUyIsImNhdGVnb3J5QmFkZ2VWYXJpYW50cyIsInZhcmlhbnRzIiwiY2F0ZWdvcnkiLCJhcnQiLCJtdXNpYyIsInBob3RvZ3JhcGh5IiwiZ2FtZSIsImNvbGxlY3RpYmxlIiwiZGVmYXVsdFZhcmlhbnRzIiwiTmZ0Q2FyZCIsInQwIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJuZnQiLCJwcmlvcml0eSIsInQxIiwiY2xhc3NOYW1lIiwidW5kZWZpbmVkIiwidDIiLCJ0MyIsIm5hbWUiLCJjb2xsZWN0aW9uIiwiY3JlYXRvck5hbWUiLCJ0NCIsInQ1IiwidDYiLCJ0NyIsImltYWdlVXJsIiwidDgiLCJ0OSIsInQxMCIsInQxMSIsImlkIiwiaXNGYXZvcml0ZWQiLCJsaWtlcyIsInQxMiIsInQxMyIsImF2YWlsYWJsZSIsInQxNCIsInQxNSIsInQxNiIsIm5mdElkIiwidDE3IiwidDE4IiwidDE5IiwidDIwIiwidDIxIiwidDIyIiwidDIzIiwidDI0IiwidDI1IiwicHJpY2VFdGgiLCJ0MjYiLCJ0MjciLCJ0MjgiLCJ0MjkiLCJ2YXJpYW50Iiwic2l6ZSIsInQzMCIsInQzMSIsInQzMiIsInQzMyIsInQzNCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJuZnQtY2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyBjdmEgfSBmcm9tICdjbGFzcy12YXJpYW5jZS1hdXRob3JpdHknXG5pbXBvcnQgeyBTcGFya2xlcyB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IEFkZFRvQ2FydEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9jYXJ0L2FkZC10by1jYXJ0LWJ1dHRvbidcbmltcG9ydCB7IEZhdm9yaXRlQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL25mdC9mYXZvcml0ZS1idXR0b24nXG5pbXBvcnQgeyBBdmF0YXIsIEF2YXRhckZhbGxiYWNrIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2F2YXRhcidcbmltcG9ydCB7IEJhZGdlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2JhZGdlJ1xuaW1wb3J0IHsgYnV0dG9uVmFyaWFudHMgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHsgQ2FyZCwgQ2FyZENvbnRlbnQsIENhcmRGb290ZXIsIENhcmRIZWFkZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvY2FyZCdcbmltcG9ydCB7IFNlcGFyYXRvciB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9zZXBhcmF0b3InXG5pbXBvcnQgeyBmb3JtYXRFdGggfSBmcm9tICdAL2xpYi9ldGgnXG5pbXBvcnQgeyBjbiwgZ2V0SW5pdGlhbHMgfSBmcm9tICdAL2xpYi91dGlscydcbmltcG9ydCB7IENBVEVHT1JZX0xBQkVMUyB9IGZyb20gJ0Avc2NoZW1hcy9uZnQtc2VhcmNoJ1xuaW1wb3J0IHR5cGUgeyBORlQgfSBmcm9tICdAL3R5cGVzL21vZGVscydcblxuY29uc3QgY2F0ZWdvcnlCYWRnZVZhcmlhbnRzID0gY3ZhKCdiZy1iYWNrZ3JvdW5kLzkwIGJhY2tkcm9wLWJsdXItc20nLCB7XG4gIHZhcmlhbnRzOiB7XG4gICAgY2F0ZWdvcnk6IHtcbiAgICAgIGFydDogJ3RleHQtZm9yZWdyb3VuZCcsXG4gICAgICBtdXNpYzogJ3RleHQtZm9yZWdyb3VuZCcsXG4gICAgICBwaG90b2dyYXBoeTogJ3RleHQtZm9yZWdyb3VuZCcsXG4gICAgICBnYW1lOiAndGV4dC1mb3JlZ3JvdW5kJyxcbiAgICAgIGNvbGxlY3RpYmxlOiAndGV4dC1mb3JlZ3JvdW5kJyxcbiAgICB9LFxuICB9LFxuICBkZWZhdWx0VmFyaWFudHM6IHtcbiAgICBjYXRlZ29yeTogJ2FydCcsXG4gIH0sXG59KVxuXG5pbnRlcmZhY2UgTmZ0Q2FyZFByb3BzIHtcbiAgbmZ0OiBORlRcbiAgLyoqIEF0aXZhIGNhcnJlZ2FtZW50byBwcmlvcml0w6FyaW8gKExDUCkgcGFyYSBvcyBwcmltZWlyb3MgY2FyZHMgYWNpbWEgZGEgZG9icmEgKi9cbiAgcHJpb3JpdHk/OiBib29sZWFuXG4gIGNsYXNzTmFtZT86IHN0cmluZ1xufVxuXG5leHBvcnQgZnVuY3Rpb24gTmZ0Q2FyZCh7IG5mdCwgcHJpb3JpdHkgPSBmYWxzZSwgY2xhc3NOYW1lIH06IE5mdENhcmRQcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxhcnRpY2xlIGNsYXNzTmFtZT17Y24oJ2gtZnVsbCcsIGNsYXNzTmFtZSl9PlxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwiZ3JvdXAgZmxleCBoLWZ1bGwgZmxleC1jb2wgb3ZlcmZsb3ctaGlkZGVuIHB0LTAgdHJhbnNpdGlvbi1zaGFkb3cgaG92ZXI6c2hhZG93LW1kXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgYXNwZWN0LXNxdWFyZSB3LWZ1bGwgb3ZlcmZsb3ctaGlkZGVuIGJnLW11dGVkXCI+XG4gICAgICAgICAgPGltZ1xuICAgICAgICAgICAgc3JjPXtuZnQuaW1hZ2VVcmx9XG4gICAgICAgICAgICBhbHQ9e2BPYnJhIE5GVCAke25mdC5uYW1lfSBkYSBjb2xlw6fDo28gJHtuZnQuY29sbGVjdGlvbn0sIGNyaWFkYSBwb3IgJHtuZnQuY3JlYXRvck5hbWV9YH1cbiAgICAgICAgICAgIGxvYWRpbmc9e3ByaW9yaXR5ID8gJ2VhZ2VyJyA6ICdsYXp5J31cbiAgICAgICAgICAgIGZldGNoUHJpb3JpdHk9e3ByaW9yaXR5ID8gJ2hpZ2gnIDogJ2F1dG8nfVxuICAgICAgICAgICAgZGVjb2Rpbmc9e3ByaW9yaXR5ID8gJ3N5bmMnIDogJ2FzeW5jJ31cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInNpemUtZnVsbCBvYmplY3QtY292ZXIgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMzAwIGdyb3VwLWhvdmVyOnNjYWxlLTEwNSBtb3Rpb24tcmVkdWNlOnRyYW5zaXRpb24tbm9uZSBtb3Rpb24tcmVkdWNlOmdyb3VwLWhvdmVyOnNjYWxlLTEwMFwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImFic29sdXRlIGluc2V0LXgtMyB0b3AtMyBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cbiAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwic2Vjb25kYXJ5XCIgY2xhc3NOYW1lPXtjYXRlZ29yeUJhZGdlVmFyaWFudHMoeyBjYXRlZ29yeTogbmZ0LmNhdGVnb3J5IH0pfT5cbiAgICAgICAgICAgICAge0NBVEVHT1JZX0xBQkVMU1tuZnQuY2F0ZWdvcnldfVxuICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICAgIDxGYXZvcml0ZUJ1dHRvblxuICAgICAgICAgICAgICBuZnRJZD17bmZ0LmlkfVxuICAgICAgICAgICAgICBuZnROYW1lPXtuZnQubmFtZX1cbiAgICAgICAgICAgICAgaXNGYXZvcml0ZWQ9e25mdC5pc0Zhdm9yaXRlZH1cbiAgICAgICAgICAgICAgbGlrZXM9e25mdC5saWtlc31cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgeyFuZnQuYXZhaWxhYmxlICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTMgbGVmdC0zXCI+XG4gICAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIj5WZW5kaWRvPC9CYWRnZT5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxDYXJkSGVhZGVyIGNsYXNzTmFtZT1cImdhcC0xLjUgcGItMlwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRydW5jYXRlIHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e25mdC5jb2xsZWN0aW9ufTwvcD5cbiAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidHJ1bmNhdGUgdGV4dC1iYXNlIGZvbnQtc2VtaWJvbGQgbGVhZGluZy1zbnVnXCI+XG4gICAgICAgICAgICA8TGlua1xuICAgICAgICAgICAgICB0bz1cIi9uZnRzLyRuZnRJZFwiXG4gICAgICAgICAgICAgIHBhcmFtcz17eyBuZnRJZDogbmZ0LmlkIH19XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtc20gaG92ZXI6dW5kZXJsaW5lIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1yaW5nXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge25mdC5uYW1lfVxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDwvaDI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBwdC0wLjVcIj5cbiAgICAgICAgICAgIDxBdmF0YXIgc2l6ZT1cInNtXCI+XG4gICAgICAgICAgICAgIDxBdmF0YXJGYWxsYmFjaz57Z2V0SW5pdGlhbHMobmZ0LmNyZWF0b3JOYW1lKX08L0F2YXRhckZhbGxiYWNrPlxuICAgICAgICAgICAgPC9BdmF0YXI+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPntuZnQuY3JlYXRvck5hbWV9PC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L0NhcmRIZWFkZXI+XG5cbiAgICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT1cIm10LWF1dG8gcHQtMFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1iYXNlbGluZSBqdXN0aWZ5LWJldHdlZW4gcm91bmRlZC1sZyBiZy1tdXRlZC82MCBweC0zIHB5LTJcIj5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+UHJlw6dvIGF0dWFsPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgZm9udC1tb25vIHRleHQtc20gZm9udC1zZW1pYm9sZCB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInNpemUtMy41IHRleHQtcHJpbWFyeVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgIHtmb3JtYXRFdGgobmZ0LnByaWNlRXRoKX0gRVRIXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvQ2FyZENvbnRlbnQ+XG5cbiAgICAgICAgPFNlcGFyYXRvciAvPlxuXG4gICAgICAgIDxDYXJkRm9vdGVyIGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTIgcHQtM1wiPlxuICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICB0bz1cIi9uZnRzLyRuZnRJZFwiXG4gICAgICAgICAgICBwYXJhbXM9e3sgbmZ0SWQ6IG5mdC5pZCB9fVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihidXR0b25WYXJpYW50cyh7IHZhcmlhbnQ6ICdvdXRsaW5lJywgc2l6ZTogJ3NtJyB9KSwgJ3ctZnVsbCcpfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIERldGFsaGVzXG4gICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDxBZGRUb0NhcnRCdXR0b24gbmZ0PXtuZnR9IGxhYmVsPVwiQWRpY2lvbmFyXCIgc2l6ZT1cInNtXCIgY2xhc3NOYW1lPVwidy1mdWxsXCIgLz5cbiAgICAgICAgPC9DYXJkRm9vdGVyPlxuICAgICAgPC9DYXJkPlxuICAgIDwvYXJ0aWNsZT5cbiAgKVxufVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvY29tcG9uZW50cy9uZnQvbmZ0LWNhcmQudHN4In0=