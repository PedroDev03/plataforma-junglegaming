import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/providers/socket-provider.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const useCallback = __vite__cjsImport1_react["useCallback"]; const useEffect = __vite__cjsImport1_react["useEffect"]; const useRef = __vite__cjsImport1_react["useRef"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=e9f94b2e";
import { useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=e9f94b2e";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=e9f94b2e";
import { SocketContext } from "/src/hooks/use-socket.ts";
import { formatEth } from "/src/lib/eth.ts";
import { queryKeys } from "/src/lib/query-keys.ts";
import { socket } from "/src/lib/socket.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/providers/socket-provider.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
export function SocketProvider(t0) {
	_s();
	const $ = _c(11);
	if ($[0] !== "537bd934428a920b192122e5e1d4fdac4b3cec5c269a4ee3628e2fafe9417df9") {
		for (let $i = 0; $i < 11; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "537bd934428a920b192122e5e1d4fdac4b3cec5c269a4ee3628e2fafe9417df9";
	}
	const { children } = t0;
	const queryClient = useQueryClient();
	const [status, setStatus] = useState("connecting");
	const [latestNftUpdate, setLatestNftUpdate] = useState(null);
	const wasDisconnectedRef = useRef(false);
	let t1;
	let t2;
	if ($[1] !== queryClient) {
		t1 = () => {
			const handleConnect = () => {
				setStatus("connected");
				if (wasDisconnectedRef.current) {
					wasDisconnectedRef.current = false;
					queryClient.invalidateQueries({ refetchType: "active" });
					toast.success("Conexão em tempo real restabelecida. Consultas ativas atualizadas.");
				}
			};
			const handleDisconnect = () => {
				wasDisconnectedRef.current = true;
				setStatus("disconnected");
				toast.warning("Conexão em tempo real interrompida. Tentando reconectar...");
			};
			const handleReconnect = () => {
				wasDisconnectedRef.current = false;
				setStatus("connected");
				queryClient.invalidateQueries({ refetchType: "active" });
			};
			const handleNftUpdated = (payload) => {
				setLatestNftUpdate(payload);
				queryClient.invalidateQueries({ queryKey: queryKeys.nfts.all });
				toast.info(`Preço atualizado em tempo real: "${payload.name}" passou de ${formatEth(payload.oldPriceEth)} ETH para ${formatEth(payload.newPriceEth)} ETH.`);
			};
			const handleOrderUpdated = (payload_0) => {
				queryClient.invalidateQueries({ queryKey: queryKeys.orders.all });
			};
			socket.on("connect", handleConnect);
			socket.on("disconnect", handleDisconnect);
			socket.io.on("reconnect", handleReconnect);
			socket.on("nft.updated", handleNftUpdated);
			socket.on("order.updated", handleOrderUpdated);
			if (!socket.connected) {
				socket.connect();
			}
			return () => {
				socket.off("connect", handleConnect);
				socket.off("disconnect", handleDisconnect);
				socket.io.off("reconnect", handleReconnect);
				socket.off("nft.updated", handleNftUpdated);
				socket.off("order.updated", handleOrderUpdated);
			};
		};
		t2 = [queryClient];
		$[1] = queryClient;
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	useEffect(t1, t2);
	let t3;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = () => {
			setLatestNftUpdate(null);
		};
		$[4] = t3;
	} else {
		t3 = $[4];
	}
	const clearLatestNftUpdate = t3;
	const triggerSimulatedNftUpdate = _temp;
	const simulateSocketDrop = _temp3;
	let t4;
	if ($[5] !== latestNftUpdate || $[6] !== status) {
		t4 = {
			status,
			latestNftUpdate,
			clearLatestNftUpdate,
			triggerSimulatedNftUpdate,
			simulateSocketDrop
		};
		$[5] = latestNftUpdate;
		$[6] = status;
		$[7] = t4;
	} else {
		t4 = $[7];
	}
	let t5;
	if ($[8] !== children || $[9] !== t4) {
		t5 = /* @__PURE__ */ _jsxDEV(SocketContext.Provider, {
			value: t4,
			children
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 117,
			columnNumber: 10
		}, this);
		$[8] = children;
		$[9] = t4;
		$[10] = t5;
	} else {
		t5 = $[10];
	}
	return t5;
}
_s(SocketProvider, "K/SoMCty8k83PfyOXa9plQrcq+8=", false, function() {
	return [useQueryClient];
});
_c2 = SocketProvider;
function _temp3() {
	if (socket.connected) {
		socket.emit("simulation:drop_connection");
		setTimeout(_temp2, 1200);
	} else {
		socket.connect();
	}
}
function _temp2() {
	if (!socket.connected) {
		socket.connect();
	}
}
function _temp(nftId) {
	if (!socket.connected) {
		socket.connect();
	}
	socket.emit("simulation:trigger_nft_update", { nftId });
}
var _c2;
$RefreshReg$(_c2, "SocketProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/providers/socket-provider.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/providers/socket-provider.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/providers/socket-provider.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/providers/socket-provider.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGFBQWFDLFdBQVdDLFFBQVFDLGdCQUFnQztBQUN6RSxTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxxQkFBa0Q7QUFDM0QsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxjQUFjOzs7O0FBR3ZCLE9BQU8sU0FBQUMsZUFBQUMsSUFBQTs7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBd0IsUUFBQUssYUFBQU47Q0FDN0IsTUFBQU8sY0FBb0JkLGVBQWU7Q0FDbkMsT0FBQWUsUUFBQUMsYUFBNEJqQixTQUFpQyxZQUFZO0NBQ3pFLE9BQUFrQixpQkFBQUMsc0JBQThDbkIsU0FBaUMsSUFBSTtDQUNuRixNQUFBb0IscUJBQTJCckIsT0FBTyxLQUFLO0NBQUMsSUFBQXNCO0NBQUEsSUFBQUM7Q0FBQSxJQUFBYixFQUFBLE9BQUFNLGFBQUE7RUFFOUJNLFdBQUE7R0FDUixNQUFBRSxzQkFBc0I7SUFDcEJOLFVBQVUsV0FBVztJQUVyQixJQUFJRyxtQkFBa0JJLFNBQVE7S0FDNUJKLG1CQUFrQkksVUFBVztLQUN4QlQsWUFBV1Usa0JBQW1CLEVBQUFDLGFBQWUsU0FBUyxDQUFDO0tBQzVEeEIsTUFBS3lCLFFBQVMsb0VBQW9FO0lBQUM7R0FDcEY7R0FHSCxNQUFBQyx5QkFBeUI7SUFDdkJSLG1CQUFrQkksVUFBVztJQUM3QlAsVUFBVSxjQUFjO0lBQ3hCZixNQUFLMkIsUUFBUyw0REFBNEQ7R0FBQztHQUc3RSxNQUFBQyx3QkFBd0I7SUFDdEJWLG1CQUFrQkksVUFBVztJQUM3QlAsVUFBVSxXQUFXO0lBQ2hCRixZQUFXVSxrQkFBbUIsRUFBQUMsYUFBZSxTQUFTLENBQUM7R0FBQztHQU8vRCxNQUFBSyxvQkFBeUJDLFlBQUE7SUFDdkJiLG1CQUFtQmEsT0FBTztJQUNyQmpCLFlBQVdVLGtCQUFtQixFQUFBUSxVQUFZNUIsVUFBUzZCLEtBQUtDLElBQUssQ0FBQztJQUVuRWpDLE1BQUtrQyxLQUNILG9DQUFvQ0osUUFBT0ssS0FBSyxjQUFlakMsVUFBVTRCLFFBQU9NLFdBQVksRUFBQyxZQUFhbEMsVUFBVTRCLFFBQU9PLFdBQVksRUFBQyxNQUMxSTtHQUFDO0dBR0gsTUFBQUMsc0JBQTJCQyxjQUFBO0lBRXBCMUIsWUFBV1Usa0JBQW1CLEVBQUFRLFVBQVk1QixVQUFTcUMsT0FBT1AsSUFBSyxDQUFDO0dBQUM7R0FHeEU3QixPQUFNcUMsR0FBSSxXQUFXcEIsYUFBYTtHQUNsQ2pCLE9BQU1xQyxHQUFJLGNBQWNmLGdCQUFnQjtHQUN4Q3RCLE9BQU1zQyxHQUFHRCxHQUFJLGFBQWFiLGVBQWU7R0FDekN4QixPQUFNcUMsR0FBSSxlQUFlWixnQkFBZ0I7R0FDekN6QixPQUFNcUMsR0FBSSxpQkFBaUJILGtCQUFrQjtHQUU3QyxJQUFJLENBQUNsQyxPQUFNdUMsV0FBVTtJQUNuQnZDLE9BQU13QyxRQUFTO0dBQUM7R0FDakIsYUFFTTtJQUNMeEMsT0FBTXlDLElBQUssV0FBV3hCLGFBQWE7SUFDbkNqQixPQUFNeUMsSUFBSyxjQUFjbkIsZ0JBQWdCO0lBQ3pDdEIsT0FBTXNDLEdBQUdHLElBQUssYUFBYWpCLGVBQWU7SUFDMUN4QixPQUFNeUMsSUFBSyxlQUFlaEIsZ0JBQWdCO0lBQzFDekIsT0FBTXlDLElBQUssaUJBQWlCUCxrQkFBa0I7R0FBQztFQUNoRDtFQUNBbEIsS0FBQSxDQUFDUCxXQUFXO0VBQUNOLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBWTtFQUFBWixFQUFBLEtBQUFhO0NBQUE7RUFBQUQsS0FBQVosRUFBQTtFQUFBYSxLQUFBYixFQUFBO0NBQUE7Q0ExRGhCWCxVQUFVdUIsSUEwRFBDLEVBQWE7Q0FBQyxJQUFBMEI7Q0FBQSxJQUFBdkMsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBRXdCbUMsV0FBQTtHQUN2QzdCLG1CQUFtQixJQUFJO0VBQUM7RUFDekJWLEVBQUEsS0FBQXVDO0NBQUE7RUFBQUEsS0FBQXZDLEVBQUE7Q0FBQTtDQUZELE1BQUF3Qyx1QkFBNkJEO0NBSTdCLE1BQUFFLDRCQUFrQ0M7Q0FPbEMsTUFBQUMscUJBQTJCQztDQVVyQixJQUFBQztDQUFBLElBQUE3QyxFQUFBLE9BQUFTLG1CQUFBVCxFQUFBLE9BQUFPLFFBQUE7RUFJS3NDLEtBQUE7R0FBQXRDO0dBQUFFO0dBQUErQjtHQUFBQztHQUFBRTtFQU1QO0VBQUMzQyxFQUFBLEtBQUFTO0VBQUFULEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBNkM7Q0FBQTtFQUFBQSxLQUFBN0MsRUFBQTtDQUFBO0NBQUEsSUFBQThDO0NBQUEsSUFBQTlDLEVBQUEsT0FBQUssWUFBQUwsRUFBQSxPQUFBNkMsSUFBQTtFQVBIQyxLQUFBO0dBQ1MsT0FBQUQ7R0FRTnhDO0VBQ0g7Ozs7O0VBQXlCTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQTZDO0VBQUE3QyxFQUFBLE1BQUE4QztDQUFBO0VBQUFBLEtBQUE5QyxFQUFBO0NBQUE7Q0FBQSxPQVZ6QjhDO0FBVXlCOzs7OztBQXBHdEIsU0FBQUYsU0FBQTtDQThFSCxJQUFJL0MsT0FBTXVDLFdBQVU7RUFDbEJ2QyxPQUFNa0QsS0FBTSw0QkFBNEI7RUFFeENDLFdBQVdDLFFBRVIsSUFBSTtDQUFDO0VBRVJwRCxPQUFNd0MsUUFBUztDQUFDO0FBQ2pCO0FBdEZFLFNBQUFZLFNBQUE7Q0FrRkMsSUFBSSxDQUFDcEQsT0FBTXVDLFdBQVU7RUFBRXZDLE9BQU13QyxRQUFTO0NBQUM7QUFBQTtBQWxGeEMsU0FBQUssTUFBQVEsT0FBQTtDQXVFSCxJQUFJLENBQUNyRCxPQUFNdUMsV0FBVTtFQUNuQnZDLE9BQU13QyxRQUFTO0NBQUM7Q0FFbEJ4QyxPQUFNa0QsS0FBTSxpQ0FBaUMsRUFBQUcsTUFBUSxDQUFDO0FBQUMiLCJuYW1lcyI6WyJ1c2VDYWxsYmFjayIsInVzZUVmZmVjdCIsInVzZVJlZiIsInVzZVN0YXRlIiwidXNlUXVlcnlDbGllbnQiLCJ0b2FzdCIsIlNvY2tldENvbnRleHQiLCJmb3JtYXRFdGgiLCJxdWVyeUtleXMiLCJzb2NrZXQiLCJTb2NrZXRQcm92aWRlciIsInQwIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJjaGlsZHJlbiIsInF1ZXJ5Q2xpZW50Iiwic3RhdHVzIiwic2V0U3RhdHVzIiwibGF0ZXN0TmZ0VXBkYXRlIiwic2V0TGF0ZXN0TmZ0VXBkYXRlIiwid2FzRGlzY29ubmVjdGVkUmVmIiwidDEiLCJ0MiIsImhhbmRsZUNvbm5lY3QiLCJjdXJyZW50IiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJyZWZldGNoVHlwZSIsInN1Y2Nlc3MiLCJoYW5kbGVEaXNjb25uZWN0Iiwid2FybmluZyIsImhhbmRsZVJlY29ubmVjdCIsImhhbmRsZU5mdFVwZGF0ZWQiLCJwYXlsb2FkIiwicXVlcnlLZXkiLCJuZnRzIiwiYWxsIiwiaW5mbyIsIm5hbWUiLCJvbGRQcmljZUV0aCIsIm5ld1ByaWNlRXRoIiwiaGFuZGxlT3JkZXJVcGRhdGVkIiwicGF5bG9hZF8wIiwib3JkZXJzIiwib24iLCJpbyIsImNvbm5lY3RlZCIsImNvbm5lY3QiLCJvZmYiLCJ0MyIsImNsZWFyTGF0ZXN0TmZ0VXBkYXRlIiwidHJpZ2dlclNpbXVsYXRlZE5mdFVwZGF0ZSIsIl90ZW1wIiwic2ltdWxhdGVTb2NrZXREcm9wIiwiX3RlbXAzIiwidDQiLCJ0NSIsImVtaXQiLCJzZXRUaW1lb3V0IiwiX3RlbXAyIiwibmZ0SWQiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsic29ja2V0LXByb3ZpZGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlLCB0eXBlIFJlYWN0Tm9kZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgdXNlUXVlcnlDbGllbnQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyB0b2FzdCB9IGZyb20gJ3Nvbm5lcidcbmltcG9ydCB7IFNvY2tldENvbnRleHQsIHR5cGUgU29ja2V0Q29ubmVjdGlvblN0YXR1cyB9IGZyb20gJ0AvaG9va3MvdXNlLXNvY2tldCdcbmltcG9ydCB7IGZvcm1hdEV0aCB9IGZyb20gJ0AvbGliL2V0aCdcbmltcG9ydCB7IHF1ZXJ5S2V5cyB9IGZyb20gJ0AvbGliL3F1ZXJ5LWtleXMnXG5pbXBvcnQgeyBzb2NrZXQgfSBmcm9tICdAL2xpYi9zb2NrZXQnXG5pbXBvcnQgdHlwZSB7IE5mdFVwZGF0ZWRFdmVudCwgT3JkZXJVcGRhdGVkRXZlbnQgfSBmcm9tICdAL3R5cGVzL21vZGVscydcblxuZXhwb3J0IGZ1bmN0aW9uIFNvY2tldFByb3ZpZGVyKHsgY2hpbGRyZW4gfTogeyBjaGlsZHJlbjogUmVhY3ROb2RlIH0pIHtcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG4gIGNvbnN0IFtzdGF0dXMsIHNldFN0YXR1c10gPSB1c2VTdGF0ZTxTb2NrZXRDb25uZWN0aW9uU3RhdHVzPignY29ubmVjdGluZycpXG4gIGNvbnN0IFtsYXRlc3ROZnRVcGRhdGUsIHNldExhdGVzdE5mdFVwZGF0ZV0gPSB1c2VTdGF0ZTxOZnRVcGRhdGVkRXZlbnQgfCBudWxsPihudWxsKVxuICBjb25zdCB3YXNEaXNjb25uZWN0ZWRSZWYgPSB1c2VSZWYoZmFsc2UpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBoYW5kbGVDb25uZWN0ID0gKCkgPT4ge1xuICAgICAgc2V0U3RhdHVzKCdjb25uZWN0ZWQnKVxuICAgICAgLy8gUmVncmEgNDogU2UgbyBzb2NrZXQgY2FpciBlIHZvbHRhciwgaW52YWxpZGEgdG9kYXMgYXMgY29uc3VsdGFzIGF0aXZhcyBhdXRvbWF0aWNhbWVudGVcbiAgICAgIGlmICh3YXNEaXNjb25uZWN0ZWRSZWYuY3VycmVudCkge1xuICAgICAgICB3YXNEaXNjb25uZWN0ZWRSZWYuY3VycmVudCA9IGZhbHNlXG4gICAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyByZWZldGNoVHlwZTogJ2FjdGl2ZScgfSlcbiAgICAgICAgdG9hc3Quc3VjY2VzcygnQ29uZXjDo28gZW0gdGVtcG8gcmVhbCByZXN0YWJlbGVjaWRhLiBDb25zdWx0YXMgYXRpdmFzIGF0dWFsaXphZGFzLicpXG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgaGFuZGxlRGlzY29ubmVjdCA9ICgpID0+IHtcbiAgICAgIHdhc0Rpc2Nvbm5lY3RlZFJlZi5jdXJyZW50ID0gdHJ1ZVxuICAgICAgc2V0U3RhdHVzKCdkaXNjb25uZWN0ZWQnKVxuICAgICAgdG9hc3Qud2FybmluZygnQ29uZXjDo28gZW0gdGVtcG8gcmVhbCBpbnRlcnJvbXBpZGEuIFRlbnRhbmRvIHJlY29uZWN0YXIuLi4nKVxuICAgIH1cblxuICAgIGNvbnN0IGhhbmRsZVJlY29ubmVjdCA9ICgpID0+IHtcbiAgICAgIHdhc0Rpc2Nvbm5lY3RlZFJlZi5jdXJyZW50ID0gZmFsc2VcbiAgICAgIHNldFN0YXR1cygnY29ubmVjdGVkJylcbiAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyByZWZldGNoVHlwZTogJ2FjdGl2ZScgfSlcbiAgICB9XG5cbiAgICAvKipcbiAgICAgKiBSZWdyYSAzIChTaW5jcm9uaXphw6fDo28gZW0gVGVtcG8gUmVhbCk6XG4gICAgICogTsODTyBhbHRlcmEgbyBjYWNoZSBkaXJldGFtZW50ZS4gRGlzcGFyYSBgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogWyduZnRzJ10gfSlgLlxuICAgICAqL1xuICAgIGNvbnN0IGhhbmRsZU5mdFVwZGF0ZWQgPSAocGF5bG9hZDogTmZ0VXBkYXRlZEV2ZW50KSA9PiB7XG4gICAgICBzZXRMYXRlc3ROZnRVcGRhdGUocGF5bG9hZClcbiAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogcXVlcnlLZXlzLm5mdHMuYWxsIH0pXG5cbiAgICAgIHRvYXN0LmluZm8oXG4gICAgICAgIGBQcmXDp28gYXR1YWxpemFkbyBlbSB0ZW1wbyByZWFsOiBcIiR7cGF5bG9hZC5uYW1lfVwiIHBhc3NvdSBkZSAke2Zvcm1hdEV0aChwYXlsb2FkLm9sZFByaWNlRXRoKX0gRVRIIHBhcmEgJHtmb3JtYXRFdGgocGF5bG9hZC5uZXdQcmljZUV0aCl9IEVUSC5gLFxuICAgICAgKVxuICAgIH1cblxuICAgIGNvbnN0IGhhbmRsZU9yZGVyVXBkYXRlZCA9IChwYXlsb2FkOiBPcmRlclVwZGF0ZWRFdmVudCkgPT4ge1xuICAgICAgdm9pZCBwYXlsb2FkXG4gICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IHF1ZXJ5S2V5cy5vcmRlcnMuYWxsIH0pXG4gICAgfVxuXG4gICAgc29ja2V0Lm9uKCdjb25uZWN0JywgaGFuZGxlQ29ubmVjdClcbiAgICBzb2NrZXQub24oJ2Rpc2Nvbm5lY3QnLCBoYW5kbGVEaXNjb25uZWN0KVxuICAgIHNvY2tldC5pby5vbigncmVjb25uZWN0JywgaGFuZGxlUmVjb25uZWN0KVxuICAgIHNvY2tldC5vbignbmZ0LnVwZGF0ZWQnLCBoYW5kbGVOZnRVcGRhdGVkKVxuICAgIHNvY2tldC5vbignb3JkZXIudXBkYXRlZCcsIGhhbmRsZU9yZGVyVXBkYXRlZClcblxuICAgIGlmICghc29ja2V0LmNvbm5lY3RlZCkge1xuICAgICAgc29ja2V0LmNvbm5lY3QoKVxuICAgIH1cblxuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBzb2NrZXQub2ZmKCdjb25uZWN0JywgaGFuZGxlQ29ubmVjdClcbiAgICAgIHNvY2tldC5vZmYoJ2Rpc2Nvbm5lY3QnLCBoYW5kbGVEaXNjb25uZWN0KVxuICAgICAgc29ja2V0LmlvLm9mZigncmVjb25uZWN0JywgaGFuZGxlUmVjb25uZWN0KVxuICAgICAgc29ja2V0Lm9mZignbmZ0LnVwZGF0ZWQnLCBoYW5kbGVOZnRVcGRhdGVkKVxuICAgICAgc29ja2V0Lm9mZignb3JkZXIudXBkYXRlZCcsIGhhbmRsZU9yZGVyVXBkYXRlZClcbiAgICB9XG4gIH0sIFtxdWVyeUNsaWVudF0pXG5cbiAgY29uc3QgY2xlYXJMYXRlc3ROZnRVcGRhdGUgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgc2V0TGF0ZXN0TmZ0VXBkYXRlKG51bGwpXG4gIH0sIFtdKVxuXG4gIGNvbnN0IHRyaWdnZXJTaW11bGF0ZWROZnRVcGRhdGUgPSB1c2VDYWxsYmFjaygobmZ0SWQ/OiBzdHJpbmcpID0+IHtcbiAgICBpZiAoIXNvY2tldC5jb25uZWN0ZWQpIHtcbiAgICAgIHNvY2tldC5jb25uZWN0KClcbiAgICB9XG4gICAgc29ja2V0LmVtaXQoJ3NpbXVsYXRpb246dHJpZ2dlcl9uZnRfdXBkYXRlJywgeyBuZnRJZCB9KVxuICB9LCBbXSlcblxuICBjb25zdCBzaW11bGF0ZVNvY2tldERyb3AgPSB1c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKHNvY2tldC5jb25uZWN0ZWQpIHtcbiAgICAgIHNvY2tldC5lbWl0KCdzaW11bGF0aW9uOmRyb3BfY29ubmVjdGlvbicpXG4gICAgICAvLyBSZWNvbmVjdGEgYXDDs3MgMS4ycyBjYXNvIG8gZmVjaGFtZW50byB2ZW5oYSBkbyBtb2NrIHNlcnZlclxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGlmICghc29ja2V0LmNvbm5lY3RlZCkgc29ja2V0LmNvbm5lY3QoKVxuICAgICAgfSwgMTIwMClcbiAgICB9IGVsc2Uge1xuICAgICAgc29ja2V0LmNvbm5lY3QoKVxuICAgIH1cbiAgfSwgW10pXG5cbiAgcmV0dXJuIChcbiAgICA8U29ja2V0Q29udGV4dC5Qcm92aWRlclxuICAgICAgdmFsdWU9e3tcbiAgICAgICAgc3RhdHVzLFxuICAgICAgICBsYXRlc3ROZnRVcGRhdGUsXG4gICAgICAgIGNsZWFyTGF0ZXN0TmZ0VXBkYXRlLFxuICAgICAgICB0cmlnZ2VyU2ltdWxhdGVkTmZ0VXBkYXRlLFxuICAgICAgICBzaW11bGF0ZVNvY2tldERyb3AsXG4gICAgICB9fVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L1NvY2tldENvbnRleHQuUHJvdmlkZXI+XG4gIClcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL3Byb3ZpZGVycy9zb2NrZXQtcHJvdmlkZXIudHN4In0=