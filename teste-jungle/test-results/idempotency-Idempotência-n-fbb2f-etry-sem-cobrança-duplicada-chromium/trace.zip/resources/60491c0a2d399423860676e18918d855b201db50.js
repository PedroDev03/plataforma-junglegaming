import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/label.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport1_react, 1);const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];"use client";
import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/label.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
function Label(t0) {
	const $ = _c(9);
	if ($[0] !== "2ff601f061c11d0842cfe6013f1452a890b5656feeb74e23d14fffbf0b5516ba") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "2ff601f061c11d0842cfe6013f1452a890b5656feeb74e23d14fffbf0b5516ba";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("label", {
			"data-slot": "label",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c2 = Label;
export { Label };
var _c2;
$RefreshReg$(_c2, "Label");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/label.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/label.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/label.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/label.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFBWSxTQUFBQSxLQUFBQyxVQUFBO0FBRVosWUFBWUMsV0FBVztBQUN2QixTQUFTQyxVQUFVOzs7QUFFbkIsU0FBQUMsTUFBQUMsSUFBQTtDQUFBLE1BQUFDLElBQUFMLEdBQUE7Q0FBQSxJQUFBSyxFQUFBO0VBQUEsU0FBQUMsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUQsRUFBQUMsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFILEVBQUE7Q0FBQTtDQUFBLElBQUFJO0NBQUEsSUFBQUM7Q0FBQSxJQUFBTCxFQUFBLE9BQUFELElBQUE7RUFBZSxFQUFBSyxXQUFBLEdBQUFDLFNBQUFOO0VBQXNEQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQUk7RUFBQUosRUFBQSxLQUFBSztDQUFBO0VBQUFELFlBQUFKLEVBQUE7RUFBQUssUUFBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFJLFdBQUE7RUFJcERFLEtBQUFULEdBQ1QsdU5BQ0FPLFNBQ0Y7RUFBQ0osRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFNO0NBQUE7RUFBQUEsS0FBQU4sRUFBQTtDQUFBO0NBQUEsSUFBQU87Q0FBQSxJQUFBUCxFQUFBLE9BQUFLLFNBQUFMLEVBQUEsT0FBQU0sSUFBQTtFQUxIQyxLQUFBO0dBQ1k7R0FDQyxXQUFBRDtHQUdWLEdBQ0dEO0VBQUs7Ozs7O0VBQ1RMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFPO0NBQUE7RUFBQUEsS0FBQVAsRUFBQTtDQUFBO0NBQUEsT0FQRk87QUFPRTs7QUFJTixTQUFTVCIsIm5hbWVzIjpbImMiLCJfYyIsIlJlYWN0IiwiY24iLCJMYWJlbCIsInQwIiwiJCIsIiRpIiwiU3ltYm9sIiwiZm9yIiwiY2xhc3NOYW1lIiwicHJvcHMiLCJ0MSIsInQyIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImxhYmVsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBjbGllbnRcIlxuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIlxuaW1wb3J0IHsgY24gfSBmcm9tIFwiY25cIlxuXG5mdW5jdGlvbiBMYWJlbCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfTogUmVhY3QuQ29tcG9uZW50UHJvcHM8XCJsYWJlbFwiPikge1xuICByZXR1cm4gKFxuICAgIDxsYWJlbFxuICAgICAgZGF0YS1zbG90PVwibGFiZWxcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiB0ZXh0LXNtIGxlYWRpbmctbm9uZSBmb250LW1lZGl1bSBzZWxlY3Qtbm9uZSBncm91cC1kYXRhLVtkaXNhYmxlZD10cnVlXTpwb2ludGVyLWV2ZW50cy1ub25lIGdyb3VwLWRhdGEtW2Rpc2FibGVkPXRydWVdOm9wYWNpdHktNTAgcGVlci1kaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgcGVlci1kaXNhYmxlZDpvcGFjaXR5LTUwXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmV4cG9ydCB7IExhYmVsIH1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL2NvbXBvbmVudHMvdWkvbGFiZWwudHN4In0=