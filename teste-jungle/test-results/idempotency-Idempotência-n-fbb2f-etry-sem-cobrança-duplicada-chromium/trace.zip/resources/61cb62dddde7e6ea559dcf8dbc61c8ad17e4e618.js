import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/skeleton.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/skeleton.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
function Skeleton(t0) {
	const $ = _c(9);
	if ($[0] !== "dd0188b275051efc540e5863065f3727b50cb587a70677517df291909045c8e8") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "dd0188b275051efc540e5863065f3727b50cb587a70677517df291909045c8e8";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("animate-pulse rounded-md bg-muted", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "skeleton",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 35,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c2 = Skeleton;
export { Skeleton };
var _c2;
$RefreshReg$(_c2, "Skeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/skeleton.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/skeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/skeleton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/skeleton.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLFVBQVU7OztBQUVuQixTQUFBQyxTQUFBQyxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBQztDQUFBLElBQUFOLEVBQUEsT0FBQUQsSUFBQTtFQUFrQixFQUFBTSxXQUFBLEdBQUFDLFNBQUFQO0VBQW9EQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtDQUFBO0VBQUFELFlBQUFMLEVBQUE7RUFBQU0sUUFBQU4sRUFBQTtDQUFBO0NBQUEsSUFBQU87Q0FBQSxJQUFBUCxFQUFBLE9BQUFLLFdBQUE7RUFJckRFLEtBQUFWLEdBQUcscUNBQXFDUSxTQUFTO0VBQUNMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTztDQUFBO0VBQUFBLEtBQUFQLEVBQUE7Q0FBQTtDQUFBLElBQUFRO0NBQUEsSUFBQVIsRUFBQSxPQUFBTSxTQUFBTixFQUFBLE9BQUFPLElBQUE7RUFGL0RDLEtBQUE7R0FDWTtHQUNDLFdBQUFEO0dBQWtELEdBQ3pERDtFQUFLOzs7OztFQUNUTixFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBUTtDQUFBO0VBQUFBLEtBQUFSLEVBQUE7Q0FBQTtDQUFBLE9BSkZRO0FBSUU7O0FBSU4sU0FBU1YiLCJuYW1lcyI6WyJjbiIsIlNrZWxldG9uIiwidDAiLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsImNsYXNzTmFtZSIsInByb3BzIiwidDEiLCJ0MiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJza2VsZXRvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY24gfSBmcm9tIFwiY25cIlxuXG5mdW5jdGlvbiBTa2VsZXRvbih7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfTogUmVhY3QuQ29tcG9uZW50UHJvcHM8XCJkaXZcIj4pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBkYXRhLXNsb3Q9XCJza2VsZXRvblwiXG4gICAgICBjbGFzc05hbWU9e2NuKFwiYW5pbWF0ZS1wdWxzZSByb3VuZGVkLW1kIGJnLW11dGVkXCIsIGNsYXNzTmFtZSl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5leHBvcnQgeyBTa2VsZXRvbiB9XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9jb21wb25lbnRzL3VpL3NrZWxldG9uLnRzeCJ9