import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/socket-status-menu.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Activity, Radio, Unplug, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { Button } from "/src/components/ui/button.tsx";
import { DropdownMenu, DropdownMenuContent, DropdownMenuGroup, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "/src/components/ui/dropdown-menu.tsx";
import { useSocket } from "/src/hooks/use-socket.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/layout/socket-status-menu.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
export function SocketStatusMenu() {
	_s();
	const $ = _c(35);
	if ($[0] !== "07ae2635fe620c7a01c0e9a57e3d15c93ea80d783166c68cc63cb0ca067310d8") {
		for (let $i = 0; $i < 35; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "07ae2635fe620c7a01c0e9a57e3d15c93ea80d783166c68cc63cb0ca067310d8";
	}
	const { status, triggerSimulatedNftUpdate, simulateSocketDrop } = useSocket();
	const isConnected = status === "connected";
	const t0 = `Status do Socket.IO: ${isConnected ? "Conectado" : "Reconectando"}`;
	let t1;
	if ($[1] !== t0) {
		t1 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			variant: "ghost",
			size: "sm",
			"aria-label": t0,
			className: "gap-1.5 px-2"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 24,
			columnNumber: 10
		}, this);
		$[1] = t0;
		$[2] = t1;
	} else {
		t1 = $[2];
	}
	const t2 = isConnected ? "bg-primary" : "animate-pulse bg-destructive motion-reduce:animate-none";
	let t3;
	if ($[3] !== t2) {
		t3 = cn("size-2 rounded-full", t2);
		$[3] = t2;
		$[4] = t3;
	} else {
		t3 = $[4];
	}
	let t4;
	if ($[5] !== t3) {
		t4 = /* @__PURE__ */ _jsxDEV("span", {
			className: t3,
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 41,
			columnNumber: 10
		}, this);
		$[5] = t3;
		$[6] = t4;
	} else {
		t4 = $[6];
	}
	let t5;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = /* @__PURE__ */ _jsxDEV(Radio, {
			className: "size-3.5 text-muted-foreground",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 10
		}, this);
		$[7] = t5;
	} else {
		t5 = $[7];
	}
	const t6 = isConnected ? "Tempo Real" : "Reconectando...";
	let t7;
	if ($[8] !== t6) {
		t7 = /* @__PURE__ */ _jsxDEV("span", {
			className: "hidden text-xs text-muted-foreground lg:inline",
			children: t6
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 10
		}, this);
		$[8] = t6;
		$[9] = t7;
	} else {
		t7 = $[9];
	}
	let t8;
	if ($[10] !== t1 || $[11] !== t4 || $[12] !== t7) {
		t8 = /* @__PURE__ */ _jsxDEV(DropdownMenuTrigger, {
			render: t1,
			children: [
				t4,
				t5,
				t7
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 65,
			columnNumber: 10
		}, this);
		$[10] = t1;
		$[11] = t4;
		$[12] = t7;
		$[13] = t8;
	} else {
		t8 = $[13];
	}
	let t9;
	if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
		t9 = /* @__PURE__ */ _jsxDEV(Activity, {
			className: "size-3.5 text-primary",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 75,
			columnNumber: 10
		}, this);
		$[14] = t9;
	} else {
		t9 = $[14];
	}
	const t10 = isConnected ? "Online" : "Offline";
	let t11;
	if ($[15] !== t10) {
		t11 = /* @__PURE__ */ _jsxDEV(DropdownMenuGroup, { children: /* @__PURE__ */ _jsxDEV(DropdownMenuLabel, {
			className: "flex items-center gap-2",
			children: [t9, /* @__PURE__ */ _jsxDEV("span", { children: [
				"Socket.IO (",
				t10,
				")"
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 89
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 83,
			columnNumber: 30
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 83,
			columnNumber: 11
		}, this);
		$[15] = t10;
		$[16] = t11;
	} else {
		t11 = $[16];
	}
	let t12;
	if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
		t12 = /* @__PURE__ */ _jsxDEV(DropdownMenuSeparator, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 91,
			columnNumber: 11
		}, this);
		$[17] = t12;
	} else {
		t12 = $[17];
	}
	let t13;
	if ($[18] !== triggerSimulatedNftUpdate) {
		t13 = () => triggerSimulatedNftUpdate();
		$[18] = triggerSimulatedNftUpdate;
		$[19] = t13;
	} else {
		t13 = $[19];
	}
	let t14;
	let t15;
	if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
		t14 = /* @__PURE__ */ _jsxDEV(Zap, {
			className: "size-4 text-primary",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 107,
			columnNumber: 11
		}, this);
		t15 = /* @__PURE__ */ _jsxDEV("span", { children: "Emitir nft.updated aleatório" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 108,
			columnNumber: 11
		}, this);
		$[20] = t14;
		$[21] = t15;
	} else {
		t14 = $[20];
		t15 = $[21];
	}
	let t16;
	if ($[22] !== t13) {
		t16 = /* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
			onClick: t13,
			children: [t14, t15]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 117,
			columnNumber: 11
		}, this);
		$[22] = t13;
		$[23] = t16;
	} else {
		t16 = $[23];
	}
	let t17;
	let t18;
	if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
		t17 = /* @__PURE__ */ _jsxDEV(Unplug, {
			className: "size-4 text-destructive",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 126,
			columnNumber: 11
		}, this);
		t18 = /* @__PURE__ */ _jsxDEV("span", { children: "Simular queda e reconexão" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 127,
			columnNumber: 11
		}, this);
		$[24] = t17;
		$[25] = t18;
	} else {
		t17 = $[24];
		t18 = $[25];
	}
	let t19;
	if ($[26] !== simulateSocketDrop) {
		t19 = /* @__PURE__ */ _jsxDEV(DropdownMenuItem, {
			onClick: simulateSocketDrop,
			children: [t17, t18]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 136,
			columnNumber: 11
		}, this);
		$[26] = simulateSocketDrop;
		$[27] = t19;
	} else {
		t19 = $[27];
	}
	let t20;
	if ($[28] !== t11 || $[29] !== t16 || $[30] !== t19) {
		t20 = /* @__PURE__ */ _jsxDEV(DropdownMenuContent, {
			align: "end",
			className: "w-64",
			children: [
				t11,
				t12,
				t16,
				t19
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 144,
			columnNumber: 11
		}, this);
		$[28] = t11;
		$[29] = t16;
		$[30] = t19;
		$[31] = t20;
	} else {
		t20 = $[31];
	}
	let t21;
	if ($[32] !== t20 || $[33] !== t8) {
		t21 = /* @__PURE__ */ _jsxDEV(DropdownMenu, { children: [t8, t20] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 154,
			columnNumber: 11
		}, this);
		$[32] = t20;
		$[33] = t8;
		$[34] = t21;
	} else {
		t21 = $[34];
	}
	return t21;
}
_s(SocketStatusMenu, "TEfquTNwmqJeK0qqcbCx1dvpPuU=", false, function() {
	return [useSocket];
});
_c2 = SocketStatusMenu;
var _c2;
$RefreshReg$(_c2, "SocketStatusMenu");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/socket-status-menu.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/layout/socket-status-menu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/layout/socket-status-menu.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/layout/socket-status-menu.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLFVBQVVDLE9BQU9DLFFBQVFDLFdBQVc7QUFDN0MsU0FBU0MsY0FBYztBQUN2QixTQUNFQyxjQUNBQyxxQkFDQUMsbUJBQ0FDLGtCQUNBQyxtQkFDQUMsdUJBQ0FDLDJCQUNLO0FBQ1AsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLFVBQVU7Ozs7QUFFbkIsT0FBTyxTQUFBQyxtQkFBQTs7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FDTCxRQUFBSyxRQUFBQywyQkFBQUMsdUJBQWtFVixVQUFVO0NBRTVFLE1BQUFXLGNBQW9CSCxXQUFXO0NBVVQsTUFBQUksS0FBQSx3QkFBd0JELGNBQUE7Q0FBNEMsSUFBQUU7Q0FBQSxJQUFBVixFQUFBLE9BQUFTLElBQUE7RUFKbEZDLEtBQUEsd0JBQUMsUUFBRDtHQUNPO0dBQ0c7R0FDSDtHQUNPLGNBQUFEO0dBQ0Y7RUFBYzs7Ozs7RUFDeEJULEVBQUEsS0FBQVM7RUFBQVQsRUFBQSxLQUFBVTtDQUFBO0VBQUFBLEtBQUFWLEVBQUE7Q0FBQTtDQU1BLE1BQUFXLEtBQUFILGNBQUE7Q0FBc0YsSUFBQUk7Q0FBQSxJQUFBWixFQUFBLE9BQUFXLElBQUE7RUFGN0VDLEtBQUFkLEdBQ1QsdUJBQ0FhLEVBQ0Y7RUFBQ1gsRUFBQSxLQUFBVztFQUFBWCxFQUFBLEtBQUFZO0NBQUE7RUFBQUEsS0FBQVosRUFBQTtDQUFBO0NBQUEsSUFBQWE7Q0FBQSxJQUFBYixFQUFBLE9BQUFZLElBQUE7RUFKSEMsS0FBQTtHQUNhLFdBQUFEO0dBSUM7RUFBTTs7Ozs7RUFDbEJaLEVBQUEsS0FBQVk7RUFBQVosRUFBQSxLQUFBYTtDQUFBO0VBQUFBLEtBQUFiLEVBQUE7Q0FBQTtDQUFBLElBQUFjO0NBQUEsSUFBQWQsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBQ0ZVLEtBQUEsd0JBQUMsT0FBRDtHQUFpQjtHQUE2QztFQUFNOzs7OztFQUFHZCxFQUFBLEtBQUFjO0NBQUE7RUFBQUEsS0FBQWQsRUFBQTtDQUFBO0NBRXBFLE1BQUFlLEtBQUFQLGNBQUE7Q0FBOEMsSUFBQVE7Q0FBQSxJQUFBaEIsRUFBQSxPQUFBZSxJQUFBO0VBRGpEQyxLQUFBO0dBQWdCO2FBQ2JEO0VBQ0k7Ozs7O0VBQUFmLEVBQUEsS0FBQWU7RUFBQWYsRUFBQSxLQUFBZ0I7Q0FBQTtFQUFBQSxLQUFBaEIsRUFBQTtDQUFBO0NBQUEsSUFBQWlCO0NBQUEsSUFBQWpCLEVBQUEsUUFBQVUsTUFBQVYsRUFBQSxRQUFBYSxNQUFBYixFQUFBLFFBQUFnQixJQUFBO0VBckJUQyxLQUFBLHdCQUFDLHFCQUFEO0dBRUksUUFBQVA7YUFGSjtJQVdFRztJQU9BQztJQUNBRTtHQW5Ca0I7Ozs7OztFQXNCRWhCLEVBQUEsTUFBQVU7RUFBQVYsRUFBQSxNQUFBYTtFQUFBYixFQUFBLE1BQUFnQjtFQUFBaEIsRUFBQSxNQUFBaUI7Q0FBQTtFQUFBQSxLQUFBakIsRUFBQTtDQUFBO0NBQUEsSUFBQWtCO0NBQUEsSUFBQWxCLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUtoQmMsS0FBQSx3QkFBQyxVQUFEO0dBQW9CO0dBQW9DO0VBQU07Ozs7O0VBQUdsQixFQUFBLE1BQUFrQjtDQUFBO0VBQUFBLEtBQUFsQixFQUFBO0NBQUE7Q0FDL0MsTUFBQW1CLE1BQUFYLGNBQUE7Q0FBa0MsSUFBQVk7Q0FBQSxJQUFBcEIsRUFBQSxRQUFBbUIsS0FBQTtFQUh4REMsTUFBQSx3QkFBQyxtQkFBRCxZQUNFLHdCQUFDLG1CQUFEO0dBQTZCO2FBQTdCLENBQ0VGLElBQ0E7SUFBTTtJQUFZQztJQUFtQztHQUFROzs7O1dBRjdDOzs7OztXQURGOzs7OztFQUtFbkIsRUFBQSxNQUFBbUI7RUFBQW5CLEVBQUEsTUFBQW9CO0NBQUE7RUFBQUEsTUFBQXBCLEVBQUE7Q0FBQTtDQUFBLElBQUFxQjtDQUFBLElBQUFyQixFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFDcEJpQixNQUFBLHdCQUFDLHVCQUFELENBQXNCOzs7OztFQUFHckIsRUFBQSxNQUFBcUI7Q0FBQTtFQUFBQSxNQUFBckIsRUFBQTtDQUFBO0NBQUEsSUFBQXNCO0NBQUEsSUFBQXRCLEVBQUEsUUFBQU0sMkJBQUE7RUFDRWdCLFlBQU1oQiwwQkFBMEI7RUFBQ04sRUFBQSxNQUFBTTtFQUFBTixFQUFBLE1BQUFzQjtDQUFBO0VBQUFBLE1BQUF0QixFQUFBO0NBQUE7Q0FBQSxJQUFBdUI7Q0FBQSxJQUFBQztDQUFBLElBQUF4QixFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFDMURtQixNQUFBLHdCQUFDLEtBQUQ7R0FBZTtHQUFrQztFQUFNOzs7OztFQUN2REMsTUFBQSw0Q0FBTSwrQkFBbUM7Ozs7O0VBQUF4QixFQUFBLE1BQUF1QjtFQUFBdkIsRUFBQSxNQUFBd0I7Q0FBQTtFQUFBRCxNQUFBdkIsRUFBQTtFQUFBd0IsTUFBQXhCLEVBQUE7Q0FBQTtDQUFBLElBQUF5QjtDQUFBLElBQUF6QixFQUFBLFFBQUFzQixLQUFBO0VBRjNDRyxNQUFBLHdCQUFDLGtCQUFEO0dBQTJCLFNBQUFIO2FBQTNCLENBQ0VDLEtBQ0FDLEdBRmU7Ozs7OztFQUdFeEIsRUFBQSxNQUFBc0I7RUFBQXRCLEVBQUEsTUFBQXlCO0NBQUE7RUFBQUEsTUFBQXpCLEVBQUE7Q0FBQTtDQUFBLElBQUEwQjtDQUFBLElBQUFDO0NBQUEsSUFBQTNCLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUVqQnNCLE1BQUEsd0JBQUMsUUFBRDtHQUFrQjtHQUFzQztFQUFNOzs7OztFQUM5REMsTUFBQSw0Q0FBTSw0QkFBZ0M7Ozs7O0VBQUEzQixFQUFBLE1BQUEwQjtFQUFBMUIsRUFBQSxNQUFBMkI7Q0FBQTtFQUFBRCxNQUFBMUIsRUFBQTtFQUFBMkIsTUFBQTNCLEVBQUE7Q0FBQTtDQUFBLElBQUE0QjtDQUFBLElBQUE1QixFQUFBLFFBQUFPLG9CQUFBO0VBRnhDcUIsTUFBQSx3QkFBQyxrQkFBRDtHQUEyQnJCO2FBQTNCLENBQ0VtQixLQUNBQyxHQUZlOzs7Ozs7RUFHRTNCLEVBQUEsTUFBQU87RUFBQVAsRUFBQSxNQUFBNEI7Q0FBQTtFQUFBQSxNQUFBNUIsRUFBQTtDQUFBO0NBQUEsSUFBQTZCO0NBQUEsSUFBQTdCLEVBQUEsUUFBQW9CLE9BQUFwQixFQUFBLFFBQUF5QixPQUFBekIsRUFBQSxRQUFBNEIsS0FBQTtFQWZyQkMsTUFBQSx3QkFBQyxxQkFBRDtHQUEyQjtHQUFnQjthQUEzQztJQUNFVDtJQU1BQztJQUNBSTtJQUlBRztHQVprQjs7Ozs7O0VBZ0JFNUIsRUFBQSxNQUFBb0I7RUFBQXBCLEVBQUEsTUFBQXlCO0VBQUF6QixFQUFBLE1BQUE0QjtFQUFBNUIsRUFBQSxNQUFBNkI7Q0FBQTtFQUFBQSxNQUFBN0IsRUFBQTtDQUFBO0NBQUEsSUFBQThCO0NBQUEsSUFBQTlCLEVBQUEsUUFBQTZCLE9BQUE3QixFQUFBLFFBQUFpQixJQUFBO0VBekN4QmEsTUFBQSx3QkFBQyxjQUFELGFBQ0ViLElBd0JBWSxHQXpCVzs7Ozs7RUEwQ0U3QixFQUFBLE1BQUE2QjtFQUFBN0IsRUFBQSxNQUFBaUI7RUFBQWpCLEVBQUEsTUFBQThCO0NBQUE7RUFBQUEsTUFBQTlCLEVBQUE7Q0FBQTtDQUFBLE9BMUNmOEI7QUEwQ2UiLCJuYW1lcyI6WyJBY3Rpdml0eSIsIlJhZGlvIiwiVW5wbHVnIiwiWmFwIiwiQnV0dG9uIiwiRHJvcGRvd25NZW51IiwiRHJvcGRvd25NZW51Q29udGVudCIsIkRyb3Bkb3duTWVudUdyb3VwIiwiRHJvcGRvd25NZW51SXRlbSIsIkRyb3Bkb3duTWVudUxhYmVsIiwiRHJvcGRvd25NZW51U2VwYXJhdG9yIiwiRHJvcGRvd25NZW51VHJpZ2dlciIsInVzZVNvY2tldCIsImNuIiwiU29ja2V0U3RhdHVzTWVudSIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwic3RhdHVzIiwidHJpZ2dlclNpbXVsYXRlZE5mdFVwZGF0ZSIsInNpbXVsYXRlU29ja2V0RHJvcCIsImlzQ29ubmVjdGVkIiwidDAiLCJ0MSIsInQyIiwidDMiLCJ0NCIsInQ1IiwidDYiLCJ0NyIsInQ4IiwidDkiLCJ0MTAiLCJ0MTEiLCJ0MTIiLCJ0MTMiLCJ0MTQiLCJ0MTUiLCJ0MTYiLCJ0MTciLCJ0MTgiLCJ0MTkiLCJ0MjAiLCJ0MjEiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsic29ja2V0LXN0YXR1cy1tZW51LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBY3Rpdml0eSwgUmFkaW8sIFVucGx1ZywgWmFwIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcbmltcG9ydCB7XG4gIERyb3Bkb3duTWVudSxcbiAgRHJvcGRvd25NZW51Q29udGVudCxcbiAgRHJvcGRvd25NZW51R3JvdXAsXG4gIERyb3Bkb3duTWVudUl0ZW0sXG4gIERyb3Bkb3duTWVudUxhYmVsLFxuICBEcm9wZG93bk1lbnVTZXBhcmF0b3IsXG4gIERyb3Bkb3duTWVudVRyaWdnZXIsXG59IGZyb20gJ0AvY29tcG9uZW50cy91aS9kcm9wZG93bi1tZW51J1xuaW1wb3J0IHsgdXNlU29ja2V0IH0gZnJvbSAnQC9ob29rcy91c2Utc29ja2V0J1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcblxuZXhwb3J0IGZ1bmN0aW9uIFNvY2tldFN0YXR1c01lbnUoKSB7XG4gIGNvbnN0IHsgc3RhdHVzLCB0cmlnZ2VyU2ltdWxhdGVkTmZ0VXBkYXRlLCBzaW11bGF0ZVNvY2tldERyb3AgfSA9IHVzZVNvY2tldCgpXG5cbiAgY29uc3QgaXNDb25uZWN0ZWQgPSBzdGF0dXMgPT09ICdjb25uZWN0ZWQnXG5cbiAgcmV0dXJuIChcbiAgICA8RHJvcGRvd25NZW51PlxuICAgICAgPERyb3Bkb3duTWVudVRyaWdnZXJcbiAgICAgICAgcmVuZGVyPXtcbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgYXJpYS1sYWJlbD17YFN0YXR1cyBkbyBTb2NrZXQuSU86ICR7aXNDb25uZWN0ZWQgPyAnQ29uZWN0YWRvJyA6ICdSZWNvbmVjdGFuZG8nfWB9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJnYXAtMS41IHB4LTJcIlxuICAgICAgICAgIC8+XG4gICAgICAgIH1cbiAgICAgID5cbiAgICAgICAgPHNwYW5cbiAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgJ3NpemUtMiByb3VuZGVkLWZ1bGwnLFxuICAgICAgICAgICAgaXNDb25uZWN0ZWQgPyAnYmctcHJpbWFyeScgOiAnYW5pbWF0ZS1wdWxzZSBiZy1kZXN0cnVjdGl2ZSBtb3Rpb24tcmVkdWNlOmFuaW1hdGUtbm9uZScsXG4gICAgICAgICAgKX1cbiAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICAvPlxuICAgICAgICA8UmFkaW8gY2xhc3NOYW1lPVwic2l6ZS0zLjUgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiaGlkZGVuIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGxnOmlubGluZVwiPlxuICAgICAgICAgIHtpc0Nvbm5lY3RlZCA/ICdUZW1wbyBSZWFsJyA6ICdSZWNvbmVjdGFuZG8uLi4nfVxuICAgICAgICA8L3NwYW4+XG4gICAgICA8L0Ryb3Bkb3duTWVudVRyaWdnZXI+XG5cbiAgICAgIDxEcm9wZG93bk1lbnVDb250ZW50IGFsaWduPVwiZW5kXCIgY2xhc3NOYW1lPVwidy02NFwiPlxuICAgICAgICA8RHJvcGRvd25NZW51R3JvdXA+XG4gICAgICAgICAgPERyb3Bkb3duTWVudUxhYmVsIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICA8QWN0aXZpdHkgY2xhc3NOYW1lPVwic2l6ZS0zLjUgdGV4dC1wcmltYXJ5XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPlNvY2tldC5JTyAoe2lzQ29ubmVjdGVkID8gJ09ubGluZScgOiAnT2ZmbGluZSd9KTwvc3Bhbj5cbiAgICAgICAgICA8L0Ryb3Bkb3duTWVudUxhYmVsPlxuICAgICAgICA8L0Ryb3Bkb3duTWVudUdyb3VwPlxuICAgICAgICA8RHJvcGRvd25NZW51U2VwYXJhdG9yIC8+XG4gICAgICAgIDxEcm9wZG93bk1lbnVJdGVtIG9uQ2xpY2s9eygpID0+IHRyaWdnZXJTaW11bGF0ZWROZnRVcGRhdGUoKX0+XG4gICAgICAgICAgPFphcCBjbGFzc05hbWU9XCJzaXplLTQgdGV4dC1wcmltYXJ5XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICA8c3Bhbj5FbWl0aXIgbmZ0LnVwZGF0ZWQgYWxlYXTDs3Jpbzwvc3Bhbj5cbiAgICAgICAgPC9Ecm9wZG93bk1lbnVJdGVtPlxuICAgICAgICA8RHJvcGRvd25NZW51SXRlbSBvbkNsaWNrPXtzaW11bGF0ZVNvY2tldERyb3B9PlxuICAgICAgICAgIDxVbnBsdWcgY2xhc3NOYW1lPVwic2l6ZS00IHRleHQtZGVzdHJ1Y3RpdmVcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgIDxzcGFuPlNpbXVsYXIgcXVlZGEgZSByZWNvbmV4w6NvPC9zcGFuPlxuICAgICAgICA8L0Ryb3Bkb3duTWVudUl0ZW0+XG4gICAgICA8L0Ryb3Bkb3duTWVudUNvbnRlbnQ+XG4gICAgPC9Ecm9wZG93bk1lbnU+XG4gIClcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL2NvbXBvbmVudHMvbGF5b3V0L3NvY2tldC1zdGF0dXMtbWVudS50c3gifQ==