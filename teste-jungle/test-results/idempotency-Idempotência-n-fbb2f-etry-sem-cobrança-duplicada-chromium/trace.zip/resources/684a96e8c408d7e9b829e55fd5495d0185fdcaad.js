import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/separator.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Separator as SeparatorPrimitive } from "/node_modules/.vite/deps/@base-ui_react_separator.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/separator.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
function Separator(t0) {
	const $ = _c(11);
	if ($[0] !== "823c815593d896b0686964e1e17bf6c6fd89d0ff2f47c29f417a146cede979e1") {
		for (let $i = 0; $i < 11; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "823c815593d896b0686964e1e17bf6c6fd89d0ff2f47c29f417a146cede979e1";
	}
	let className;
	let props;
	let t1;
	if ($[1] !== t0) {
		({className, orientation: t1, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
		$[4] = t1;
	} else {
		className = $[2];
		props = $[3];
		t1 = $[4];
	}
	const orientation = t1 === undefined ? "horizontal" : t1;
	let t2;
	if ($[5] !== className) {
		t2 = cn("shrink-0 bg-border data-horizontal:h-px data-horizontal:w-full data-vertical:w-px data-vertical:self-stretch", className);
		$[5] = className;
		$[6] = t2;
	} else {
		t2 = $[6];
	}
	let t3;
	if ($[7] !== orientation || $[8] !== props || $[9] !== t2) {
		t3 = /* @__PURE__ */ _jsxDEV(SeparatorPrimitive, {
			"data-slot": "separator",
			orientation,
			className: t2,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 41,
			columnNumber: 10
		}, this);
		$[7] = orientation;
		$[8] = props;
		$[9] = t2;
		$[10] = t3;
	} else {
		t3 = $[10];
	}
	return t3;
}
_c2 = Separator;
export { Separator };
var _c2;
$RefreshReg$(_c2, "Separator");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/separator.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/separator.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/separator.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/separator.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGFBQWFDLDBCQUEwQjtBQUNoRCxTQUFTQyxVQUFVOzs7QUFFbkIsU0FBQUYsVUFBQUcsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLElBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUM7Q0FBQSxJQUFBQztDQUFBLElBQUFQLEVBQUEsT0FBQUQsSUFBQTtFQUFtQixFQUFBTSxXQUFBRyxhQUFBRCxJQUFBLEdBQUFELFNBQUFQO0VBSVFDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQU87Q0FBQTtFQUFBRixZQUFBTCxFQUFBO0VBQUFNLFFBQUFOLEVBQUE7RUFBQU8sS0FBQVAsRUFBQTtDQUFBO0NBRnpCLE1BQUFRLGNBQUFELE9BQUFFLFlBQUEsZUFBQUY7Q0FBMEIsSUFBQUc7Q0FBQSxJQUFBVixFQUFBLE9BQUFLLFdBQUE7RUFPWEssS0FBQVosR0FDVCxnSEFDQU8sU0FDRjtFQUFDTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQVU7Q0FBQTtFQUFBQSxLQUFBVixFQUFBO0NBQUE7Q0FBQSxJQUFBVztDQUFBLElBQUFYLEVBQUEsT0FBQVEsZUFBQVIsRUFBQSxPQUFBTSxTQUFBTixFQUFBLE9BQUFVLElBQUE7RUFOSEMsS0FBQSx3QkFBQyxvQkFBRDtHQUNZO0dBQ0dIO0dBQ0YsV0FBQUU7R0FHVixHQUNHSjtFQUFLOzs7OztFQUNUTixFQUFBLEtBQUFRO0VBQUFSLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBVTtFQUFBVixFQUFBLE1BQUFXO0NBQUE7RUFBQUEsS0FBQVgsRUFBQTtDQUFBO0NBQUEsT0FSRlc7QUFRRTs7QUFJTixTQUFTZiIsIm5hbWVzIjpbIlNlcGFyYXRvciIsIlNlcGFyYXRvclByaW1pdGl2ZSIsImNuIiwidDAiLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsImNsYXNzTmFtZSIsInByb3BzIiwidDEiLCJvcmllbnRhdGlvbiIsInVuZGVmaW5lZCIsInQyIiwidDMiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsic2VwYXJhdG9yLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTZXBhcmF0b3IgYXMgU2VwYXJhdG9yUHJpbWl0aXZlIH0gZnJvbSBcIkBiYXNlLXVpL3JlYWN0L3NlcGFyYXRvclwiXG5pbXBvcnQgeyBjbiB9IGZyb20gXCJjblwiXG5cbmZ1bmN0aW9uIFNlcGFyYXRvcih7XG4gIGNsYXNzTmFtZSxcbiAgb3JpZW50YXRpb24gPSBcImhvcml6b250YWxcIixcbiAgLi4ucHJvcHNcbn06IFNlcGFyYXRvclByaW1pdGl2ZS5Qcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxTZXBhcmF0b3JQcmltaXRpdmVcbiAgICAgIGRhdGEtc2xvdD1cInNlcGFyYXRvclwiXG4gICAgICBvcmllbnRhdGlvbj17b3JpZW50YXRpb259XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcInNocmluay0wIGJnLWJvcmRlciBkYXRhLWhvcml6b250YWw6aC1weCBkYXRhLWhvcml6b250YWw6dy1mdWxsIGRhdGEtdmVydGljYWw6dy1weCBkYXRhLXZlcnRpY2FsOnNlbGYtc3RyZXRjaFwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5leHBvcnQgeyBTZXBhcmF0b3IgfVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvY29tcG9uZW50cy91aS9zZXBhcmF0b3IudHN4In0=