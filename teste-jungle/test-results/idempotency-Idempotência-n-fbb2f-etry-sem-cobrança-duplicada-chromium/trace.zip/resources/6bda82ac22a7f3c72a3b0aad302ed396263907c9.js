import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/login-form.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport12_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=e9f94b2e";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=e9f94b2e";
import { Link, useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=e9f94b2e";
import { FormError } from "/src/components/form/form-error.tsx";
import { SubmitButton } from "/src/components/form/submit-button.tsx";
import { TextField } from "/src/components/form/text-field.tsx";
import { useLogin } from "/src/hooks/use-auth.ts";
import { getErrorMessage } from "/src/lib/api.ts";
import { safeRedirect } from "/src/lib/redirect.ts";
import { loginSchema } from "/src/schemas/auth.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/auth/login-form.tsx";
import __vite__cjsImport12_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
export function LoginForm(t0) {
	_s();
	const $ = _c(31);
	if ($[0] !== "70dcc09dbd7cf56bee70a38d0f19b96c6bd2b23cf2e4886e740b95b0596a4518") {
		for (let $i = 0; $i < 31; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "70dcc09dbd7cf56bee70a38d0f19b96c6bd2b23cf2e4886e740b95b0596a4518";
	}
	const { redirect } = t0;
	const router = useRouter();
	const login = useLogin();
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = {
			resolver: zodResolver(loginSchema),
			defaultValues: {
				email: "",
				password: ""
			}
		};
		$[1] = t1;
	} else {
		t1 = $[1];
	}
	const { register, handleSubmit, setError, formState: t2 } = useForm(t1);
	const { errors } = t2;
	let t3;
	if ($[2] !== login || $[3] !== redirect || $[4] !== router || $[5] !== setError) {
		t3 = (values) => login.mutate(values, {
			onSuccess: (t4) => {
				const { user } = t4;
				toast.success(`Bem-vindo, ${user.name}!`);
				router.history.push(safeRedirect(redirect));
			},
			onError: (error) => {
				const message = getErrorMessage(error);
				setError("root", { message });
				toast.error(message);
			}
		});
		$[2] = login;
		$[3] = redirect;
		$[4] = router;
		$[5] = setError;
		$[6] = t3;
	} else {
		t3 = $[6];
	}
	const onSubmit = t3;
	let t4;
	if ($[7] !== handleSubmit || $[8] !== onSubmit) {
		t4 = handleSubmit(onSubmit);
		$[7] = handleSubmit;
		$[8] = onSubmit;
		$[9] = t4;
	} else {
		t4 = $[9];
	}
	const t5 = errors.root?.message;
	let t6;
	if ($[10] !== t5) {
		t6 = /* @__PURE__ */ _jsxDEV(FormError, { message: t5 }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 87,
			columnNumber: 10
		}, this);
		$[10] = t5;
		$[11] = t6;
	} else {
		t6 = $[11];
	}
	const t7 = errors.email?.message;
	let t8;
	if ($[12] !== register) {
		t8 = register("email");
		$[12] = register;
		$[13] = t8;
	} else {
		t8 = $[13];
	}
	let t9;
	if ($[14] !== t7 || $[15] !== t8) {
		t9 = /* @__PURE__ */ _jsxDEV(TextField, {
			label: "E-mail",
			type: "email",
			autoComplete: "email",
			error: t7,
			...t8
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 104,
			columnNumber: 10
		}, this);
		$[14] = t7;
		$[15] = t8;
		$[16] = t9;
	} else {
		t9 = $[16];
	}
	const t10 = errors.password?.message;
	let t11;
	if ($[17] !== register) {
		t11 = register("password");
		$[17] = register;
		$[18] = t11;
	} else {
		t11 = $[18];
	}
	let t12;
	if ($[19] !== t10 || $[20] !== t11) {
		t12 = /* @__PURE__ */ _jsxDEV(TextField, {
			label: "Senha",
			type: "password",
			autoComplete: "current-password",
			error: t10,
			...t11
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 122,
			columnNumber: 11
		}, this);
		$[19] = t10;
		$[20] = t11;
		$[21] = t12;
	} else {
		t12 = $[21];
	}
	let t13;
	if ($[22] !== login.isPending) {
		t13 = /* @__PURE__ */ _jsxDEV(SubmitButton, {
			isPending: login.isPending,
			pendingText: "Entrando...",
			children: "Entrar"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 131,
			columnNumber: 11
		}, this);
		$[22] = login.isPending;
		$[23] = t13;
	} else {
		t13 = $[23];
	}
	let t14;
	if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
		t14 = /* @__PURE__ */ _jsxDEV("p", {
			className: "text-center text-sm text-muted-foreground",
			children: [
				"Não tem conta?",
				" ",
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/register",
					className: "font-medium text-foreground underline focus-visible:ring-2 focus-visible:ring-ring",
					children: "Cadastre-se"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 139,
					columnNumber: 87
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 139,
			columnNumber: 11
		}, this);
		$[24] = t14;
	} else {
		t14 = $[24];
	}
	let t15;
	if ($[25] !== t12 || $[26] !== t13 || $[27] !== t4 || $[28] !== t6 || $[29] !== t9) {
		t15 = /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: t4,
			noValidate: true,
			className: "grid gap-4",
			children: [
				t6,
				t9,
				t12,
				t13,
				t14
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 146,
			columnNumber: 11
		}, this);
		$[25] = t12;
		$[26] = t13;
		$[27] = t4;
		$[28] = t6;
		$[29] = t9;
		$[30] = t15;
	} else {
		t15 = $[30];
	}
	return t15;
}
_s(LoginForm, "BBw+nM0OpvAnYLoFFTdq7nUI+oo=", false, function() {
	return [
		useRouter,
		useLogin,
		useForm
	];
});
_c2 = LoginForm;
var _c2;
$RefreshReg$(_c2, "LoginForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/auth/login-form.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/auth/login-form.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/auth/login-form.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/auth/login-form.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGVBQWU7QUFDeEIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLE1BQU1DLGlCQUFpQjtBQUNoQyxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLG1CQUF5Qzs7OztBQUVsRCxPQUFPLFNBQUFDLFVBQUFDLElBQUE7O0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQW1CLFFBQUFLLGFBQUFOO0NBQ3hCLE1BQUFPLFNBQWVqQixVQUFVO0NBQ3pCLE1BQUFrQixRQUFjYixTQUFTO0NBQUMsSUFBQWM7Q0FBQSxJQUFBUixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFNS0ksS0FBQTtHQUFBQyxVQUFZdEIsWUFBWVUsV0FBVztHQUFDYSxlQUFpQjtJQUFBQyxPQUFTO0lBQUVDLFVBQVk7R0FBRztFQUFFO0VBQUNaLEVBQUEsS0FBQVE7Q0FBQTtFQUFBQSxLQUFBUixFQUFBO0NBQUE7Q0FML0csUUFBQWEsVUFBQUMsY0FBQUMsVUFBQUMsV0FBQUMsT0FLSS9CLFFBQXlCc0IsRUFBa0Y7Q0FEbEcsUUFBQVUsV0FBQUQ7Q0FBVSxJQUFBRTtDQUFBLElBQUFuQixFQUFBLE9BQUFPLFNBQUFQLEVBQUEsT0FBQUssWUFBQUwsRUFBQSxPQUFBTSxVQUFBTixFQUFBLE9BQUFlLFVBQUE7RUFHTkksTUFBQUMsV0FDZmIsTUFBS2MsT0FBUUQsUUFBUTtHQUFBRSxZQUNSQyxPQUFBO0lBQUMsUUFBQUMsU0FBQUQ7SUFDVmpDLE1BQUttQyxRQUFTLGNBQWNELEtBQUlFLEtBQUssRUFBRztJQUN4Q3BCLE9BQU1xQixRQUFRQyxLQUFNaEMsYUFBYVMsUUFBUSxDQUFDO0dBQUM7R0FDNUN3QixVQUNRQyxVQUFBO0lBQ1AsTUFBQUMsVUFBZ0JwQyxnQkFBZ0JtQyxLQUFLO0lBQ3JDZixTQUFTLFFBQVEsRUFBQWdCLFFBQVUsQ0FBQztJQUM1QnpDLE1BQUt3QyxNQUFPQyxPQUFPO0dBQUM7RUFFeEIsQ0FBQztFQUFDL0IsRUFBQSxLQUFBTztFQUFBUCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBZTtFQUFBZixFQUFBLEtBQUFtQjtDQUFBO0VBQUFBLEtBQUFuQixFQUFBO0NBQUE7Q0FYSixNQUFBZ0MsV0FBaUJiO0NBV2IsSUFBQUk7Q0FBQSxJQUFBdkIsRUFBQSxPQUFBYyxnQkFBQWQsRUFBQSxPQUFBZ0MsVUFBQTtFQUdjVCxLQUFBVCxhQUFha0IsUUFBUTtFQUFDaEMsRUFBQSxLQUFBYztFQUFBZCxFQUFBLEtBQUFnQztFQUFBaEMsRUFBQSxLQUFBdUI7Q0FBQTtFQUFBQSxLQUFBdkIsRUFBQTtDQUFBO0NBQ2hCLE1BQUFpQyxLQUFBZixPQUFNZ0IsTUFBY0g7Q0FBQSxJQUFBSTtDQUFBLElBQUFuQyxFQUFBLFFBQUFpQyxJQUFBO0VBQXhDRSxLQUFBLHdCQUFDLFdBQUQsRUFBb0IsU0FBQUYsR0FBb0I7Ozs7O0VBQUlqQyxFQUFBLE1BQUFpQztFQUFBakMsRUFBQSxNQUFBbUM7Q0FBQTtFQUFBQSxLQUFBbkMsRUFBQTtDQUFBO0NBS25DLE1BQUFvQyxLQUFBbEIsT0FBTVAsT0FBZW9CO0NBQUEsSUFBQU07Q0FBQSxJQUFBckMsRUFBQSxRQUFBYSxVQUFBO0VBQ3hCd0IsS0FBQXhCLFNBQVMsT0FBTztFQUFDYixFQUFBLE1BQUFhO0VBQUFiLEVBQUEsTUFBQXFDO0NBQUE7RUFBQUEsS0FBQXJDLEVBQUE7Q0FBQTtDQUFBLElBQUFzQztDQUFBLElBQUF0QyxFQUFBLFFBQUFvQyxNQUFBcEMsRUFBQSxRQUFBcUMsSUFBQTtFQUx2QkMsS0FBQSx3QkFBQyxXQUFEO0dBQ1E7R0FDRDtHQUNRO0dBQ04sT0FBQUY7R0FBcUIsR0FDeEJDO0VBQWlCOzs7OztFQUNyQnJDLEVBQUEsTUFBQW9DO0VBQUFwQyxFQUFBLE1BQUFxQztFQUFBckMsRUFBQSxNQUFBc0M7Q0FBQTtFQUFBQSxLQUFBdEMsRUFBQTtDQUFBO0NBS08sTUFBQXVDLE1BQUFyQixPQUFNTixVQUFrQm1CO0NBQUEsSUFBQVM7Q0FBQSxJQUFBeEMsRUFBQSxRQUFBYSxVQUFBO0VBQzNCMkIsTUFBQTNCLFNBQVMsVUFBVTtFQUFDYixFQUFBLE1BQUFhO0VBQUFiLEVBQUEsTUFBQXdDO0NBQUE7RUFBQUEsTUFBQXhDLEVBQUE7Q0FBQTtDQUFBLElBQUF5QztDQUFBLElBQUF6QyxFQUFBLFFBQUF1QyxPQUFBdkMsRUFBQSxRQUFBd0MsS0FBQTtFQUwxQkMsTUFBQSx3QkFBQyxXQUFEO0dBQ1E7R0FDRDtHQUNRO0dBQ04sT0FBQUY7R0FBd0IsR0FDM0JDO0VBQW9COzs7OztFQUN4QnhDLEVBQUEsTUFBQXVDO0VBQUF2QyxFQUFBLE1BQUF3QztFQUFBeEMsRUFBQSxNQUFBeUM7Q0FBQTtFQUFBQSxNQUFBekMsRUFBQTtDQUFBO0NBQUEsSUFBQTBDO0NBQUEsSUFBQTFDLEVBQUEsUUFBQU8sTUFBQW9DLFdBQUE7RUFDRkQsTUFBQSx3QkFBQyxjQUFEO0dBQXlCLFdBQUFuQyxNQUFLb0M7R0FBd0I7YUFBYztFQUF2RDs7Ozs7RUFFRTNDLEVBQUEsTUFBQU8sTUFBQW9DO0VBQUEzQyxFQUFBLE1BQUEwQztDQUFBO0VBQUFBLE1BQUExQyxFQUFBO0NBQUE7Q0FBQSxJQUFBNEM7Q0FBQSxJQUFBNUMsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBQ2Z3QyxNQUFBO0dBQWE7YUFBYjtJQUF5RDtJQUN4QztJQUNmLHdCQUFDLE1BQUQ7S0FBUztLQUFzQjtlQUFxRjtJQUEvRzs7Ozs7R0FHSDs7Ozs7O0VBQUE1QyxFQUFBLE1BQUE0QztDQUFBO0VBQUFBLE1BQUE1QyxFQUFBO0NBQUE7Q0FBQSxJQUFBNkM7Q0FBQSxJQUFBN0MsRUFBQSxRQUFBeUMsT0FBQXpDLEVBQUEsUUFBQTBDLE9BQUExQyxFQUFBLFFBQUF1QixNQUFBdkIsRUFBQSxRQUFBbUMsTUFBQW5DLEVBQUEsUUFBQXNDLElBQUE7RUF4Qk5PLE1BQUE7R0FBZ0IsVUFBQXRCO0dBQXdCO0dBQXFCO2FBQTdEO0lBQ0VZO0lBQ0FHO0lBT0FHO0lBT0FDO0lBR0FFO0dBTUs7Ozs7OztFQUFBNUMsRUFBQSxNQUFBeUM7RUFBQXpDLEVBQUEsTUFBQTBDO0VBQUExQyxFQUFBLE1BQUF1QjtFQUFBdkIsRUFBQSxNQUFBbUM7RUFBQW5DLEVBQUEsTUFBQXNDO0VBQUF0QyxFQUFBLE1BQUE2QztDQUFBO0VBQUFBLE1BQUE3QyxFQUFBO0NBQUE7Q0FBQSxPQXpCUDZDO0FBeUJPIiwibmFtZXMiOlsidXNlRm9ybSIsInpvZFJlc29sdmVyIiwiTGluayIsInVzZVJvdXRlciIsInRvYXN0IiwiRm9ybUVycm9yIiwiU3VibWl0QnV0dG9uIiwiVGV4dEZpZWxkIiwidXNlTG9naW4iLCJnZXRFcnJvck1lc3NhZ2UiLCJzYWZlUmVkaXJlY3QiLCJsb2dpblNjaGVtYSIsIkxvZ2luRm9ybSIsInQwIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJyZWRpcmVjdCIsInJvdXRlciIsImxvZ2luIiwidDEiLCJyZXNvbHZlciIsImRlZmF1bHRWYWx1ZXMiLCJlbWFpbCIsInBhc3N3b3JkIiwicmVnaXN0ZXIiLCJoYW5kbGVTdWJtaXQiLCJzZXRFcnJvciIsImZvcm1TdGF0ZSIsInQyIiwiZXJyb3JzIiwidDMiLCJ2YWx1ZXMiLCJtdXRhdGUiLCJvblN1Y2Nlc3MiLCJ0NCIsInVzZXIiLCJzdWNjZXNzIiwibmFtZSIsImhpc3RvcnkiLCJwdXNoIiwib25FcnJvciIsImVycm9yIiwibWVzc2FnZSIsIm9uU3VibWl0IiwidDUiLCJyb290IiwidDYiLCJ0NyIsInQ4IiwidDkiLCJ0MTAiLCJ0MTEiLCJ0MTIiLCJ0MTMiLCJpc1BlbmRpbmciLCJ0MTQiLCJ0MTUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibG9naW4tZm9ybS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRm9ybSB9IGZyb20gJ3JlYWN0LWhvb2stZm9ybSdcbmltcG9ydCB7IHpvZFJlc29sdmVyIH0gZnJvbSAnQGhvb2tmb3JtL3Jlc29sdmVycy96b2QnXG5pbXBvcnQgeyBMaW5rLCB1c2VSb3V0ZXIgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdzb25uZXInXG5pbXBvcnQgeyBGb3JtRXJyb3IgfSBmcm9tICdAL2NvbXBvbmVudHMvZm9ybS9mb3JtLWVycm9yJ1xuaW1wb3J0IHsgU3VibWl0QnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL2Zvcm0vc3VibWl0LWJ1dHRvbidcbmltcG9ydCB7IFRleHRGaWVsZCB9IGZyb20gJ0AvY29tcG9uZW50cy9mb3JtL3RleHQtZmllbGQnXG5pbXBvcnQgeyB1c2VMb2dpbiB9IGZyb20gJ0AvaG9va3MvdXNlLWF1dGgnXG5pbXBvcnQgeyBnZXRFcnJvck1lc3NhZ2UgfSBmcm9tICdAL2xpYi9hcGknXG5pbXBvcnQgeyBzYWZlUmVkaXJlY3QgfSBmcm9tICdAL2xpYi9yZWRpcmVjdCdcbmltcG9ydCB7IGxvZ2luU2NoZW1hLCB0eXBlIExvZ2luRm9ybVZhbHVlcyB9IGZyb20gJ0Avc2NoZW1hcy9hdXRoJ1xuXG5leHBvcnQgZnVuY3Rpb24gTG9naW5Gb3JtKHsgcmVkaXJlY3QgfTogeyByZWRpcmVjdD86IHN0cmluZyB9KSB7XG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG4gIGNvbnN0IGxvZ2luID0gdXNlTG9naW4oKVxuICBjb25zdCB7XG4gICAgcmVnaXN0ZXIsXG4gICAgaGFuZGxlU3VibWl0LFxuICAgIHNldEVycm9yLFxuICAgIGZvcm1TdGF0ZTogeyBlcnJvcnMgfSxcbiAgfSA9IHVzZUZvcm08TG9naW5Gb3JtVmFsdWVzPih7IHJlc29sdmVyOiB6b2RSZXNvbHZlcihsb2dpblNjaGVtYSksIGRlZmF1bHRWYWx1ZXM6IHsgZW1haWw6ICcnLCBwYXNzd29yZDogJycgfSB9KVxuXG4gIGNvbnN0IG9uU3VibWl0ID0gKHZhbHVlczogTG9naW5Gb3JtVmFsdWVzKSA9PlxuICAgIGxvZ2luLm11dGF0ZSh2YWx1ZXMsIHtcbiAgICAgIG9uU3VjY2VzczogKHsgdXNlciB9KSA9PiB7XG4gICAgICAgIHRvYXN0LnN1Y2Nlc3MoYEJlbS12aW5kbywgJHt1c2VyLm5hbWV9IWApXG4gICAgICAgIHJvdXRlci5oaXN0b3J5LnB1c2goc2FmZVJlZGlyZWN0KHJlZGlyZWN0KSlcbiAgICAgIH0sXG4gICAgICBvbkVycm9yOiAoZXJyb3IpID0+IHtcbiAgICAgICAgY29uc3QgbWVzc2FnZSA9IGdldEVycm9yTWVzc2FnZShlcnJvcilcbiAgICAgICAgc2V0RXJyb3IoJ3Jvb3QnLCB7IG1lc3NhZ2UgfSlcbiAgICAgICAgdG9hc3QuZXJyb3IobWVzc2FnZSlcbiAgICAgIH0sXG4gICAgfSlcblxuICByZXR1cm4gKFxuICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQob25TdWJtaXQpfSBub1ZhbGlkYXRlIGNsYXNzTmFtZT1cImdyaWQgZ2FwLTRcIj5cbiAgICAgIDxGb3JtRXJyb3IgbWVzc2FnZT17ZXJyb3JzLnJvb3Q/Lm1lc3NhZ2V9IC8+XG4gICAgICA8VGV4dEZpZWxkXG4gICAgICAgIGxhYmVsPVwiRS1tYWlsXCJcbiAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgYXV0b0NvbXBsZXRlPVwiZW1haWxcIlxuICAgICAgICBlcnJvcj17ZXJyb3JzLmVtYWlsPy5tZXNzYWdlfVxuICAgICAgICB7Li4ucmVnaXN0ZXIoJ2VtYWlsJyl9XG4gICAgICAvPlxuICAgICAgPFRleHRGaWVsZFxuICAgICAgICBsYWJlbD1cIlNlbmhhXCJcbiAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcbiAgICAgICAgYXV0b0NvbXBsZXRlPVwiY3VycmVudC1wYXNzd29yZFwiXG4gICAgICAgIGVycm9yPXtlcnJvcnMucGFzc3dvcmQ/Lm1lc3NhZ2V9XG4gICAgICAgIHsuLi5yZWdpc3RlcigncGFzc3dvcmQnKX1cbiAgICAgIC8+XG4gICAgICA8U3VibWl0QnV0dG9uIGlzUGVuZGluZz17bG9naW4uaXNQZW5kaW5nfSBwZW5kaW5nVGV4dD1cIkVudHJhbmRvLi4uXCI+XG4gICAgICAgIEVudHJhclxuICAgICAgPC9TdWJtaXRCdXR0b24+XG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciB0ZXh0LXNtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICBOw6NvIHRlbSBjb250YT97JyAnfVxuICAgICAgICA8TGluayB0bz1cIi9yZWdpc3RlclwiIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtIHRleHQtZm9yZWdyb3VuZCB1bmRlcmxpbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLXJpbmdcIj5cbiAgICAgICAgICBDYWRhc3RyZS1zZVxuICAgICAgICA8L0xpbms+XG4gICAgICA8L3A+XG4gICAgPC9mb3JtPlxuICApXG59XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9jb21wb25lbnRzL2F1dGgvbG9naW4tZm9ybS50c3gifQ==