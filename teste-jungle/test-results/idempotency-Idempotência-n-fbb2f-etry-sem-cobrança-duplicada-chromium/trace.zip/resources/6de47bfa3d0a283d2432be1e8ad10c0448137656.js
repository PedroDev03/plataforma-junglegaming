import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/__root.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { createRootRouteWithContext, Link, Outlet } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { Footer } from "/src/components/layout/footer.tsx";
import { Navbar } from "/src/components/layout/navbar.tsx";
import { buttonVariants } from "/src/components/ui/button.tsx";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { Toaster } from "/src/components/ui/sonner.tsx";
import { TooltipProvider } from "/src/components/ui/tooltip.tsx";
import { SocketProvider } from "/src/providers/socket-provider.tsx";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/routes/__root.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
const TSRNotFoundComponent = () => {
	const $ = _c(3);
	if ($[0] !== "2effbe59e4dda863c469d04322c3ef286c3f75a8a32659a5dd46d39599c3bf16") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "2effbe59e4dda863c469d04322c3ef286c3f75a8a32659a5dd46d39599c3bf16";
	}
	let t0;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ _jsxDEV(CardHeader, { children: [/* @__PURE__ */ _jsxDEV(CardTitle, {
			role: "heading",
			"aria-level": 1,
			className: "text-xl",
			children: "Página não encontrada"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 22
		}, this), /* @__PURE__ */ _jsxDEV(CardDescription, { children: "O endereço acessado não existe ou foi movido." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 116
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 21,
			columnNumber: 10
		}, this);
		$[1] = t0;
	} else {
		t0 = $[1];
	}
	let t1;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ _jsxDEV("main", {
			id: "main-content",
			className: "mx-auto flex w-full max-w-md flex-1 items-center p-4",
			children: /* @__PURE__ */ _jsxDEV(Card, {
				className: "w-full text-center",
				children: [t0, /* @__PURE__ */ _jsxDEV(CardContent, { children: /* @__PURE__ */ _jsxDEV(Link, {
					to: "/",
					className: cn(buttonVariants({ variant: "default" }), "w-full"),
					children: "Voltar ao catálogo"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 153
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 140
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 99
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 10
		}, this);
		$[2] = t1;
	} else {
		t1 = $[2];
	}
	return t1;
};
_c2 = TSRNotFoundComponent;
export const Route = createRootRouteWithContext()({
	component: RootLayout,
	notFoundComponent: TSRNotFoundComponent
});
function RootLayout() {
	const $ = _c(4);
	if ($[0] !== "2effbe59e4dda863c469d04322c3ef286c3f75a8a32659a5dd46d39599c3bf16") {
		for (let $i = 0; $i < 4; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "2effbe59e4dda863c469d04322c3ef286c3f75a8a32659a5dd46d39599c3bf16";
	}
	let t0;
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ _jsxDEV("a", {
			href: "#main-content",
			className: "sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:rounded-md focus:bg-primary focus:px-4 focus:py-2 focus:text-sm focus:font-medium focus:text-primary-foreground focus:ring-2 focus:ring-ring",
			children: "Pular para o conteúdo principal"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 10
		}, this);
		t1 = /* @__PURE__ */ _jsxDEV(Navbar, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 53,
			columnNumber: 10
		}, this);
		$[1] = t0;
		$[2] = t1;
	} else {
		t0 = $[1];
		t1 = $[2];
	}
	let t2;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV(SocketProvider, { children: /* @__PURE__ */ _jsxDEV(TooltipProvider, {
			delay: 200,
			children: /* @__PURE__ */ _jsxDEV("div", {
				className: "flex min-h-screen flex-col overflow-x-hidden bg-background text-foreground",
				children: [
					t0,
					t1,
					/* @__PURE__ */ _jsxDEV("div", {
						className: "flex flex-1 flex-col",
						children: /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 62,
							columnNumber: 193
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 155
					}, this),
					/* @__PURE__ */ _jsxDEV(Footer, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 209
					}, this),
					/* @__PURE__ */ _jsxDEV(Toaster, { richColors: true }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 219
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 62,
				columnNumber: 55
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 62,
			columnNumber: 26
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 62,
			columnNumber: 10
		}, this);
		$[3] = t2;
	} else {
		t2 = $[3];
	}
	return t2;
}
_c3 = RootLayout;
const hot = import.meta.hot;
if (hot && typeof window !== "undefined") {
	hot.data ??= {};
	const tsrReactRefresh = window.__TSR_REACT_REFRESH__ ??= (() => {
		const ignoredExportsById = new Map();
		const previousGetIgnoredExports = window.__getReactRefreshIgnoredExports;
		window.__getReactRefreshIgnoredExports = (ctx) => {
			const ignoredExports = previousGetIgnoredExports?.(ctx) ?? [];
			const moduleIgnored = ignoredExportsById.get(ctx.id) ?? [];
			return [...ignoredExports, ...moduleIgnored];
		};
		return { ignoredExportsById };
	})();
	tsrReactRefresh.ignoredExportsById.set("E:/Downloads/teste-jungle/teste-jungle/src/routes/__root.tsx", ["Route"]);
}
export function TSRFastRefreshAnchor() {
	return null;
}
_c4 = TSRFastRefreshAnchor;
if (import.meta.hot) {
	const hot = import.meta.hot;
	const hotData = hot.data ??= {};
	const handleRouteUpdate = function handleRouteUpdate(routeId, newRoute) {
		const router = window.__TSR_ROUTER__;
		const oldRoute = router.routesById[routeId];
		if (!oldRoute) return;
		const generatedRouteOptionKeys = new Set([
			"id",
			"path",
			"getParentRoute"
		]);
		const generatedRouteOptions = {};
		generatedRouteOptionKeys.forEach((key) => {
			if (key in oldRoute.options) generatedRouteOptions[key] = oldRoute.options[key];
		});
		const preserveComponentIdentity = "shellComponent" in oldRoute.options === "shellComponent" in newRoute.options;
		const componentKeys = [
			"component",
			"shellComponent",
			"pendingComponent",
			"errorComponent",
			"notFoundComponent"
		];
		if (preserveComponentIdentity) componentKeys.forEach((key) => {
			if (key in oldRoute.options && key in newRoute.options) newRoute.options[key] = oldRoute.options[key];
		});
		const nextOptions = {
			...newRoute.options,
			...generatedRouteOptions
		};
		oldRoute.options = nextOptions;
		oldRoute.update(nextOptions);
		router._replaceRouteChunk(oldRoute, newRoute.lazyFn);
		router.setRoutes(router.buildRouteTree());
		syncHotRouteExport(oldRoute);
		router.resolvePathCache.clear();
		router._refreshRoute?.();
		function syncHotRouteExport(liveRoute) {
			newRoute.options = liveRoute.options;
			newRoute.parentRoute = liveRoute.parentRoute;
			newRoute._path = liveRoute._path;
			newRoute._id = liveRoute._id;
			newRoute._fullPath = liveRoute._fullPath;
			newRoute._to = liveRoute._to;
		}
	};
	const initialRouteId = "__root__" ?? hotData["tsr-route-id"];
	if (initialRouteId) {
		hotData["tsr-route-id"] = initialRouteId;
	}
	const existingRoute = typeof window !== "undefined" && initialRouteId ? window.__TSR_ROUTER__?.routesById?.[initialRouteId] : undefined;
	if (initialRouteId && existingRoute && existingRoute !== Route) {
		handleRouteUpdate(initialRouteId, Route);
		hotData["tsr-route-update-handled"] = Route;
	}
	hot.accept((newModule) => {
		if (Route && newModule && newModule.Route) {
			const routeId = hotData["tsr-route-id"] ?? "__root__";
			if (routeId) {
				hotData["tsr-route-id"] = routeId;
			}
			if (hotData["tsr-route-update-handled"] === newModule.Route) {
				delete hotData["tsr-route-update-handled"];
				return;
			}
			handleRouteUpdate(routeId, newModule.Route);
		}
	});
}
var _c2, _c3, _c4;
$RefreshReg$(_c2, "TSRNotFoundComponent");
$RefreshReg$(_c3, "RootLayout");
$RefreshReg$(_c4, "TSRFastRefreshAnchor");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/__root.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/routes/__root.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/routes/__root.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/routes/__root.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLDRCQUE0QkMsTUFBTUMsY0FBYztBQUV6RCxTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLE1BQU1DLGFBQWFDLGlCQUFpQkMsWUFBWUMsaUJBQWlCO0FBQzFFLFNBQVNDLGVBQWU7QUFDeEIsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxVQUFVOzs7QUFBYSxNQUFBQyw2QkFRWEE7Q0FBQUE7Q0FBQUE7RUFBQUE7R0FBQUE7RUFBQUE7RUFBQUE7Q0FBQUE7Q0FBQUE7Q0FBQUE7RUFHYkMsS0FBQSx3QkFBQyxZQUFELGFBQ0Usd0JBQUMsV0FBRDtHQUFnQjtHQUFzQjtHQUFhO2FBQVM7RUFBbEQ7Ozs7WUFHVix3QkFBQyxpQkFBRCxZQUFpQixnREFBRDs7OztVQUpQOzs7OztFQUtDQyxFQUFBLEtBQUFEO0NBQUE7RUFBQUEsS0FBQUMsRUFBQTtDQUFBO0NBQUEsSUFBQUM7Q0FBQSxJQUFBRCxFQUFBLE9BQUFFLE9BQUFDLElBQUE7RUFQaEJGLEtBQUE7R0FBUztHQUF5QjthQUNoQyx3QkFBQyxNQUFEO0lBQWdCO2NBQWhCLENBQ0VGLElBTUEsd0JBQUMsYUFBRCxZQUNFLHdCQUFDLE1BQUQ7S0FBUztLQUFlRixjQUFHVCxlQUFlLEVBQUFnQixTQUFXLFVBQVUsQ0FBQyxHQUFHLFFBQVE7ZUFBRTtJQUF4RTs7OzthQURLOzs7O1lBUFQ7Ozs7OztFQWNSOzs7OztFQUFBSixFQUFBLEtBQUFDO0NBQUE7RUFBQUEsS0FBQUQsRUFBQTtDQUFBO0NBQUEsT0FmQ0M7QUFlRDs7QUFsQkgsT0FBTyxNQUFNSSxRQUFRdEIsMkJBQTBDLENBQUMsQ0FBQztDQUMvRHVCLFdBQVdDO0NBQ1hDLG1CQUFpQlY7QUFpQm5CLENBQUM7QUFFRCxTQUFBUyxhQUFBO0NBQUEsTUFBQVAsSUFBQVMsR0FBQTtDQUFBLElBQUFULEVBQUE7RUFBQSxTQUFBVSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBVixFQUFBVSxNQUFBUixPQUFBQyxJQUFBO0VBQUE7RUFBQUgsRUFBQTtDQUFBO0NBQUEsSUFBQUQ7Q0FBQSxJQUFBRTtDQUFBLElBQUFELEVBQUEsT0FBQUUsT0FBQUMsSUFBQTtFQUtVSixLQUFBO0dBQ087R0FDSzthQUE4TjtFQUd2Tzs7Ozs7RUFDSEUsS0FBQSx3QkFBQyxRQUFELENBQU87Ozs7O0VBQUFELEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBQztDQUFBO0VBQUFGLEtBQUFDLEVBQUE7RUFBQUMsS0FBQUQsRUFBQTtDQUFBO0NBQUEsSUFBQVc7Q0FBQSxJQUFBWCxFQUFBLE9BQUFFLE9BQUFDLElBQUE7RUFUYlEsS0FBQSx3QkFBQyxnQkFBRCxZQUNFLHdCQUFDLGlCQUFEO0dBQXdCO2FBQ3RCO0lBQWU7Y0FBZjtLQUNFWjtLQU1BRTtLQUNBO01BQWU7Z0JBQ2Isd0JBQUMsUUFBRCxDQUFPOzs7OztLQUNKOzs7OztLQUNMLHdCQUFDLFFBQUQsQ0FBTzs7Ozs7S0FDUCx3QkFBQyxTQUFELEVBQVMsaUJBQVU7Ozs7O0lBQ2hCOzs7Ozs7RUFkUzs7OztXQURIOzs7OztFQWlCRUQsRUFBQSxLQUFBVztDQUFBO0VBQUFBLEtBQUFYLEVBQUE7Q0FBQTtDQUFBLE9BakJqQlc7QUFpQmlCOztBQUVwQixNQUFBQyxNQUFBQyxZQUFBRDtBQUFBLElBQUFBLE9BQUEsT0FBQUUsV0FBQTtDQUFBRixJQUFBRyxTQUFBO0NBQUEsTUFBQUMsa0JBQUFGLE9BQUFHLGlDQUFBO0VBQUEsTUFBQUMscUJBQUEsSUFBQUMsSUFBQTtFQUFBLE1BQUFDLDRCQUFBTixPQUFBTztFQUFBUCxPQUFBTyxtQ0FBQUMsUUFBQTtHQUFBLE1BQUFDLGlCQUFBSCw0QkFBQUUsR0FBQTtHQUFBLE1BQUFFLGdCQUFBTixtQkFBQU8sSUFBQUgsSUFBQUksRUFBQTtHQUFBLFdBQUFILGdCQUFBLEdBQUFDLGFBQUE7RUFBQTtFQUFBLFNBQUFOLG1CQUFBO0NBQUE7Q0FBQUYsZ0JBQUFFLG1CQUFBUyxJQUFBO0FBQUE7QUFBQSxnQkFBQUMsdUJBQUE7Q0FBQTtBQUFBOztBQUFBLElBQUFmLFlBQUFELEtBQUE7Q0FBQSxNQUFBQSxNQUFBQyxZQUFBRDtDQUFBLE1BQUFpQixVQUFBakIsSUFBQUcsU0FBQTtDQUFBLE1BQUFlLG9CQUFBLFNBQUFBLGtCQUFBQyxTQUFBQyxVQUFBO0VBQUEsTUFBQUMsU0FBQW5CLE9BQUFvQjtFQUFBLE1BQUFDLFdBQUFGLE9BQUFHLFdBQUFMO0VBQUEsS0FBQUksVUFBQTtFQUFBLE1BQUFFLDJCQUFBLElBQUFDLElBQUE7R0FBQTtHQUFBO0dBQUE7RUFBQTtFQUFBLE1BQUFDLHdCQUFBO0VBQUFGLHlCQUFBRyxTQUFBQyxRQUFBO0dBQUEsSUFBQUEsT0FBQU4sU0FBQU8sU0FBQUgsc0JBQUFFLE9BQUFOLFNBQUFPLFFBQUFEO0VBQUE7RUFBQSxNQUFBRSw0QkFBQSxvQkFBQVIsU0FBQU8sWUFBQSxvQkFBQVYsU0FBQVU7RUFBQSxNQUFBRSxnQkFBQTtHQUFBO0dBQUE7R0FBQTtHQUFBO0dBQUE7RUFBQTtFQUFBLElBQUFELDJCQUFBQyxjQUFBSixTQUFBQyxRQUFBO0dBQUEsSUFBQUEsT0FBQU4sU0FBQU8sV0FBQUQsT0FBQVQsU0FBQVUsU0FBQVYsU0FBQVUsUUFBQUQsT0FBQU4sU0FBQU8sUUFBQUQ7RUFBQTtFQUFBLE1BQUFJLGNBQUE7R0FBQSxHQUFBYixTQUFBVTtHQUFBLEdBQUFIO0VBQUE7RUFBQUosU0FBQU8sVUFBQUc7RUFBQVYsU0FBQVcsT0FBQUQsV0FBQTtFQUFBWixPQUFBYyxtQkFBQVosVUFBQUgsU0FBQWdCLE1BQUE7RUFBQWYsT0FBQWdCLFVBQUFoQixPQUFBaUIsZUFBQTtFQUFBQyxtQkFBQWhCLFFBQUE7RUFBQUYsT0FBQW1CLGlCQUFBQyxNQUFBO0VBQUFwQixPQUFBcUIsZ0JBQUE7RUFBQSxTQUFBSCxtQkFBQUksV0FBQTtHQUFBdkIsU0FBQVUsVUFBQWEsVUFBQWI7R0FBQVYsU0FBQXdCLGNBQUFELFVBQUFDO0dBQUF4QixTQUFBeUIsUUFBQUYsVUFBQUU7R0FBQXpCLFNBQUEwQixNQUFBSCxVQUFBRztHQUFBMUIsU0FBQTJCLFlBQUFKLFVBQUFJO0dBQUEzQixTQUFBNEIsTUFBQUwsVUFBQUs7RUFBQTtDQUFBO0NBQUEsTUFBQUMsaUJBQUEsY0FBQWhDLFFBQUE7Q0FBQSxJQUFBZ0MsZ0JBQUE7RUFBQWhDLFFBQUEsa0JBQUFnQztDQUFBO0NBQUEsTUFBQUMsZ0JBQUEsT0FBQWhELFdBQUEsZUFBQStDLGlCQUFBL0MsT0FBQW9CLGdCQUFBRSxhQUFBeUIsa0JBQUFFO0NBQUEsSUFBQUYsa0JBQUFDLG1DQUFBekQsT0FBQTtFQUFBeUIsa0JBQUErQixnQkFBQXhELEtBQUE7RUFBQXdCLFFBQUEsOEJBQUF4QjtDQUFBO0NBQUFPLElBQUFvRCxRQUFBQyxjQUFBO0VBQUEsSUFBQTVELFNBQUE0RCx1QkFBQTVELE9BQUE7R0FBQSxNQUFBMEIsVUFBQUYsUUFBQTtHQUFBLElBQUFFLFNBQUE7SUFBQUYsUUFBQSxrQkFBQUU7R0FBQTtHQUFBLElBQUFGLFFBQUEsZ0NBQUFvQyxVQUFBNUQsT0FBQTtJQUFBLE9BQUF3QixRQUFBO0lBQUE7R0FBQTtHQUFBQyxrQkFBQUMsU0FBQWtDLFVBQUE1RCxLQUFBO0VBQUE7Q0FBQTtBQUFBIiwibmFtZXMiOlsiY3JlYXRlUm9vdFJvdXRlV2l0aENvbnRleHQiLCJMaW5rIiwiT3V0bGV0IiwiRm9vdGVyIiwiTmF2YmFyIiwiYnV0dG9uVmFyaWFudHMiLCJDYXJkIiwiQ2FyZENvbnRlbnQiLCJDYXJkRGVzY3JpcHRpb24iLCJDYXJkSGVhZGVyIiwiQ2FyZFRpdGxlIiwiVG9hc3RlciIsIlRvb2x0aXBQcm92aWRlciIsIlNvY2tldFByb3ZpZGVyIiwiY24iLCJUU1JOb3RGb3VuZENvbXBvbmVudCIsInQwIiwiJCIsInQxIiwiU3ltYm9sIiwiZm9yIiwidmFyaWFudCIsIlJvdXRlIiwiY29tcG9uZW50IiwiUm9vdExheW91dCIsIm5vdEZvdW5kQ29tcG9uZW50IiwiX2MiLCIkaSIsInQyIiwiaG90IiwiaW1wb3J0Iiwid2luZG93IiwiZGF0YSIsInRzclJlYWN0UmVmcmVzaCIsIl9fVFNSX1JFQUNUX1JFRlJFU0hfXyIsImlnbm9yZWRFeHBvcnRzQnlJZCIsIk1hcCIsInByZXZpb3VzR2V0SWdub3JlZEV4cG9ydHMiLCJfX2dldFJlYWN0UmVmcmVzaElnbm9yZWRFeHBvcnRzIiwiY3R4IiwiaWdub3JlZEV4cG9ydHMiLCJtb2R1bGVJZ25vcmVkIiwiZ2V0IiwiaWQiLCJzZXQiLCJUU1JGYXN0UmVmcmVzaEFuY2hvciIsImhvdERhdGEiLCJoYW5kbGVSb3V0ZVVwZGF0ZSIsInJvdXRlSWQiLCJuZXdSb3V0ZSIsInJvdXRlciIsIl9fVFNSX1JPVVRFUl9fIiwib2xkUm91dGUiLCJyb3V0ZXNCeUlkIiwiZ2VuZXJhdGVkUm91dGVPcHRpb25LZXlzIiwiU2V0IiwiZ2VuZXJhdGVkUm91dGVPcHRpb25zIiwiZm9yRWFjaCIsImtleSIsIm9wdGlvbnMiLCJwcmVzZXJ2ZUNvbXBvbmVudElkZW50aXR5IiwiY29tcG9uZW50S2V5cyIsIm5leHRPcHRpb25zIiwidXBkYXRlIiwiX3JlcGxhY2VSb3V0ZUNodW5rIiwibGF6eUZuIiwic2V0Um91dGVzIiwiYnVpbGRSb3V0ZVRyZWUiLCJzeW5jSG90Um91dGVFeHBvcnQiLCJyZXNvbHZlUGF0aENhY2hlIiwiY2xlYXIiLCJfcmVmcmVzaFJvdXRlIiwibGl2ZVJvdXRlIiwicGFyZW50Um91dGUiLCJfcGF0aCIsIl9pZCIsIl9mdWxsUGF0aCIsIl90byIsImluaXRpYWxSb3V0ZUlkIiwiZXhpc3RpbmdSb3V0ZSIsInVuZGVmaW5lZCIsImFjY2VwdCIsIm5ld01vZHVsZSJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJfX3Jvb3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZVJvb3RSb3V0ZVdpdGhDb250ZXh0LCBMaW5rLCBPdXRsZXQgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHR5cGUgeyBRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IEZvb3RlciB9IGZyb20gJ0AvY29tcG9uZW50cy9sYXlvdXQvZm9vdGVyJ1xuaW1wb3J0IHsgTmF2YmFyIH0gZnJvbSAnQC9jb21wb25lbnRzL2xheW91dC9uYXZiYXInXG5pbXBvcnQgeyBidXR0b25WYXJpYW50cyB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCwgQ2FyZERlc2NyaXB0aW9uLCBDYXJkSGVhZGVyLCBDYXJkVGl0bGUgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvY2FyZCdcbmltcG9ydCB7IFRvYXN0ZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc29ubmVyJ1xuaW1wb3J0IHsgVG9vbHRpcFByb3ZpZGVyIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3Rvb2x0aXAnXG5pbXBvcnQgeyBTb2NrZXRQcm92aWRlciB9IGZyb20gJ0AvcHJvdmlkZXJzL3NvY2tldC1wcm92aWRlcidcbmltcG9ydCB7IGNuIH0gZnJvbSAnQC9saWIvdXRpbHMnXG5cbmV4cG9ydCBpbnRlcmZhY2UgUm91dGVyQ29udGV4dCB7XG4gIHF1ZXJ5Q2xpZW50OiBRdWVyeUNsaWVudFxufVxuXG5leHBvcnQgY29uc3QgUm91dGUgPSBjcmVhdGVSb290Um91dGVXaXRoQ29udGV4dDxSb3V0ZXJDb250ZXh0PigpKHtcbiAgY29tcG9uZW50OiBSb290TGF5b3V0LFxuICBub3RGb3VuZENvbXBvbmVudDogKCkgPT4gKFxuICAgIDxtYWluIGlkPVwibWFpbi1jb250ZW50XCIgY2xhc3NOYW1lPVwibXgtYXV0byBmbGV4IHctZnVsbCBtYXgtdy1tZCBmbGV4LTEgaXRlbXMtY2VudGVyIHAtNFwiPlxuICAgICAgPENhcmQgY2xhc3NOYW1lPVwidy1mdWxsIHRleHQtY2VudGVyXCI+XG4gICAgICAgIDxDYXJkSGVhZGVyPlxuICAgICAgICAgIDxDYXJkVGl0bGUgcm9sZT1cImhlYWRpbmdcIiBhcmlhLWxldmVsPXsxfSBjbGFzc05hbWU9XCJ0ZXh0LXhsXCI+XG4gICAgICAgICAgICBQw6FnaW5hIG7Do28gZW5jb250cmFkYVxuICAgICAgICAgIDwvQ2FyZFRpdGxlPlxuICAgICAgICAgIDxDYXJkRGVzY3JpcHRpb24+TyBlbmRlcmXDp28gYWNlc3NhZG8gbsOjbyBleGlzdGUgb3UgZm9pIG1vdmlkby48L0NhcmREZXNjcmlwdGlvbj5cbiAgICAgICAgPC9DYXJkSGVhZGVyPlxuICAgICAgICA8Q2FyZENvbnRlbnQ+XG4gICAgICAgICAgPExpbmsgdG89XCIvXCIgY2xhc3NOYW1lPXtjbihidXR0b25WYXJpYW50cyh7IHZhcmlhbnQ6ICdkZWZhdWx0JyB9KSwgJ3ctZnVsbCcpfT5cbiAgICAgICAgICAgIFZvbHRhciBhbyBjYXTDoWxvZ29cbiAgICAgICAgICA8L0xpbms+XG4gICAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgICA8L0NhcmQ+XG4gICAgPC9tYWluPlxuICApLFxufSlcblxuZnVuY3Rpb24gUm9vdExheW91dCgpIHtcbiAgcmV0dXJuIChcbiAgICA8U29ja2V0UHJvdmlkZXI+XG4gICAgICA8VG9vbHRpcFByb3ZpZGVyIGRlbGF5PXsyMDB9PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLWgtc2NyZWVuIGZsZXgtY29sIG92ZXJmbG93LXgtaGlkZGVuIGJnLWJhY2tncm91bmQgdGV4dC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgPGFcbiAgICAgICAgICAgIGhyZWY9XCIjbWFpbi1jb250ZW50XCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInNyLW9ubHkgZm9jdXM6bm90LXNyLW9ubHkgZm9jdXM6Zml4ZWQgZm9jdXM6dG9wLTMgZm9jdXM6bGVmdC0zIGZvY3VzOnotNTAgZm9jdXM6cm91bmRlZC1tZCBmb2N1czpiZy1wcmltYXJ5IGZvY3VzOnB4LTQgZm9jdXM6cHktMiBmb2N1czp0ZXh0LXNtIGZvY3VzOmZvbnQtbWVkaXVtIGZvY3VzOnRleHQtcHJpbWFyeS1mb3JlZ3JvdW5kIGZvY3VzOnJpbmctMiBmb2N1czpyaW5nLXJpbmdcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIFB1bGFyIHBhcmEgbyBjb250ZcO6ZG8gcHJpbmNpcGFsXG4gICAgICAgICAgPC9hPlxuICAgICAgICAgIDxOYXZiYXIgLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC0xIGZsZXgtY29sXCI+XG4gICAgICAgICAgICA8T3V0bGV0IC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPEZvb3RlciAvPlxuICAgICAgICAgIDxUb2FzdGVyIHJpY2hDb2xvcnMgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L1Rvb2x0aXBQcm92aWRlcj5cbiAgICA8L1NvY2tldFByb3ZpZGVyPlxuICApXG59XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9yb3V0ZXMvX19yb290LnRzeCJ9