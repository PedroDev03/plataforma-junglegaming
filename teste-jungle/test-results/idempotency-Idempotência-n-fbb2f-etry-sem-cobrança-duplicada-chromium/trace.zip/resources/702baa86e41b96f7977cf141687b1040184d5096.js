import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/cart/cart-summary.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { ArrowRight, ShieldCheck, Sparkles } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { CouponForm } from "/src/components/cart/coupon-form.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { buttonVariants } from "/src/components/ui/button.tsx";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { Separator } from "/src/components/ui/separator.tsx";
import { formatEth } from "/src/lib/eth.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/cart/cart-summary.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
export function CartSummary(t0) {
	const $ = _c(63);
	if ($[0] !== "b01a7cac845145c8d5c8698d985e30cca061728fef6bf09660c9a91db6e4fe61") {
		for (let $i = 0; $i < 63; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "b01a7cac845145c8d5c8698d985e30cca061728fef6bf09660c9a91db6e4fe61";
	}
	const { cart, onNavigateCheckout } = t0;
	const hasDiscount = cart.discountPercent > 0;
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ _jsxDEV(CardHeader, {
			className: "pb-2",
			children: /* @__PURE__ */ _jsxDEV(CardTitle, {
				role: "heading",
				"aria-level": 2,
				className: "text-base",
				children: "Resumo do Pedido"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 31,
				columnNumber: 39
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 10
		}, this);
		$[1] = t1;
	} else {
		t1 = $[1];
	}
	let t2;
	if ($[2] !== cart.couponCode || $[3] !== cart.discountPercent) {
		t2 = /* @__PURE__ */ _jsxDEV(CouponForm, {
			activeCoupon: cart.couponCode,
			discountPercent: cart.discountPercent
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 10
		}, this);
		$[2] = cart.couponCode;
		$[3] = cart.discountPercent;
		$[4] = t2;
	} else {
		t2 = $[4];
	}
	let t3;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = /* @__PURE__ */ _jsxDEV(Separator, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 10
		}, this);
		$[5] = t3;
	} else {
		t3 = $[5];
	}
	const t4 = cart.totalItems === 1 ? "item" : "itens";
	let t5;
	if ($[6] !== cart.totalItems || $[7] !== t4) {
		t5 = /* @__PURE__ */ _jsxDEV("dt", {
			className: "text-muted-foreground",
			children: [
				"Subtotal (",
				cart.totalItems,
				" ",
				t4,
				")"
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 10
		}, this);
		$[6] = cart.totalItems;
		$[7] = t4;
		$[8] = t5;
	} else {
		t5 = $[8];
	}
	let t6;
	if ($[9] !== cart.subtotalEth) {
		t6 = formatEth(cart.subtotalEth);
		$[9] = cart.subtotalEth;
		$[10] = t6;
	} else {
		t6 = $[10];
	}
	let t7;
	if ($[11] !== t6) {
		t7 = /* @__PURE__ */ _jsxDEV("dd", {
			className: "font-mono tabular-nums",
			children: [t6, " ETH"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 72,
			columnNumber: 10
		}, this);
		$[11] = t6;
		$[12] = t7;
	} else {
		t7 = $[12];
	}
	let t8;
	if ($[13] !== t5 || $[14] !== t7) {
		t8 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between gap-2",
			children: [t5, t7]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 10
		}, this);
		$[13] = t5;
		$[14] = t7;
		$[15] = t8;
	} else {
		t8 = $[15];
	}
	let t9;
	if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
		t9 = /* @__PURE__ */ _jsxDEV("span", { children: "Desconto" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 89,
			columnNumber: 10
		}, this);
		$[16] = t9;
	} else {
		t9 = $[16];
	}
	let t10;
	if ($[17] !== cart.discountPercent || $[18] !== hasDiscount) {
		t10 = hasDiscount && /* @__PURE__ */ _jsxDEV(Badge, {
			variant: "secondary",
			children: [
				"-",
				cart.discountPercent,
				"%"
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 26
		}, this);
		$[17] = cart.discountPercent;
		$[18] = hasDiscount;
		$[19] = t10;
	} else {
		t10 = $[19];
	}
	let t11;
	if ($[20] !== t10) {
		t11 = /* @__PURE__ */ _jsxDEV("dt", {
			className: "flex items-center gap-1.5 text-muted-foreground",
			children: [t9, t10]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 105,
			columnNumber: 11
		}, this);
		$[20] = t10;
		$[21] = t11;
	} else {
		t11 = $[21];
	}
	const t12 = hasDiscount && "font-medium text-primary";
	let t13;
	if ($[22] !== t12) {
		t13 = cn("font-mono tabular-nums", t12);
		$[22] = t12;
		$[23] = t13;
	} else {
		t13 = $[23];
	}
	let t14;
	if ($[24] !== cart.discountEth) {
		t14 = formatEth(cart.discountEth);
		$[24] = cart.discountEth;
		$[25] = t14;
	} else {
		t14 = $[25];
	}
	let t15;
	if ($[26] !== t13 || $[27] !== t14) {
		t15 = /* @__PURE__ */ _jsxDEV("dd", {
			className: t13,
			children: [
				"- ",
				t14,
				" ETH"
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 130,
			columnNumber: 11
		}, this);
		$[26] = t13;
		$[27] = t14;
		$[28] = t15;
	} else {
		t15 = $[28];
	}
	let t16;
	if ($[29] !== t11 || $[30] !== t15) {
		t16 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between gap-2",
			children: [t11, t15]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 139,
			columnNumber: 11
		}, this);
		$[29] = t11;
		$[30] = t15;
		$[31] = t16;
	} else {
		t16 = $[31];
	}
	let t17;
	if ($[32] === Symbol.for("react.memo_cache_sentinel")) {
		t17 = /* @__PURE__ */ _jsxDEV("dt", {
			className: "text-muted-foreground",
			children: "Taxa fixa (Gas & Protocolo)"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 148,
			columnNumber: 11
		}, this);
		$[32] = t17;
	} else {
		t17 = $[32];
	}
	let t18;
	if ($[33] !== cart.feeEth) {
		t18 = formatEth(cart.feeEth);
		$[33] = cart.feeEth;
		$[34] = t18;
	} else {
		t18 = $[34];
	}
	let t19;
	if ($[35] !== t18) {
		t19 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center justify-between gap-2",
			children: [t17, /* @__PURE__ */ _jsxDEV("dd", {
				className: "font-mono tabular-nums",
				children: [t18, " ETH"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 163,
				columnNumber: 73
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 163,
			columnNumber: 11
		}, this);
		$[35] = t18;
		$[36] = t19;
	} else {
		t19 = $[36];
	}
	let t20;
	if ($[37] === Symbol.for("react.memo_cache_sentinel")) {
		t20 = /* @__PURE__ */ _jsxDEV(Separator, { className: "my-1" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 171,
			columnNumber: 11
		}, this);
		$[37] = t20;
	} else {
		t20 = $[37];
	}
	let t21;
	if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
		t21 = /* @__PURE__ */ _jsxDEV("dt", { children: "Total estimado" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 178,
			columnNumber: 11
		}, this);
		$[38] = t21;
	} else {
		t21 = $[38];
	}
	let t22;
	if ($[39] === Symbol.for("react.memo_cache_sentinel")) {
		t22 = /* @__PURE__ */ _jsxDEV(Sparkles, {
			className: "size-4 text-primary",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 185,
			columnNumber: 11
		}, this);
		$[39] = t22;
	} else {
		t22 = $[39];
	}
	let t23;
	if ($[40] !== cart.totalEth) {
		t23 = formatEth(cart.totalEth);
		$[40] = cart.totalEth;
		$[41] = t23;
	} else {
		t23 = $[41];
	}
	let t24;
	if ($[42] !== t23) {
		t24 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-baseline justify-between gap-2 text-base font-bold",
			children: [t21, /* @__PURE__ */ _jsxDEV("dd", {
				className: "flex items-center gap-1 font-mono tabular-nums",
				children: [t22, /* @__PURE__ */ _jsxDEV("span", { children: [t23, " ETH"] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 200,
					columnNumber: 163
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 200,
				columnNumber: 95
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 200,
			columnNumber: 11
		}, this);
		$[42] = t23;
		$[43] = t24;
	} else {
		t24 = $[43];
	}
	let t25;
	if ($[44] !== t16 || $[45] !== t19 || $[46] !== t24 || $[47] !== t8) {
		t25 = /* @__PURE__ */ _jsxDEV("dl", {
			className: "grid gap-2 text-sm",
			"aria-live": "polite",
			children: [
				t8,
				t16,
				t19,
				t20,
				t24
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 208,
			columnNumber: 11
		}, this);
		$[44] = t16;
		$[45] = t19;
		$[46] = t24;
		$[47] = t8;
		$[48] = t25;
	} else {
		t25 = $[48];
	}
	let t26;
	if ($[49] !== t2 || $[50] !== t25) {
		t26 = /* @__PURE__ */ _jsxDEV(CardContent, {
			className: "grid gap-4",
			children: [
				t2,
				t3,
				t25
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 219,
			columnNumber: 11
		}, this);
		$[49] = t2;
		$[50] = t25;
		$[51] = t26;
	} else {
		t26 = $[51];
	}
	let t27;
	let t28;
	let t29;
	if ($[52] === Symbol.for("react.memo_cache_sentinel")) {
		t27 = cn(buttonVariants({
			variant: "default",
			size: "lg"
		}), "w-full");
		t28 = /* @__PURE__ */ _jsxDEV("span", { children: "Ir para o Checkout" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 234,
			columnNumber: 11
		}, this);
		t29 = /* @__PURE__ */ _jsxDEV(ArrowRight, {
			className: "size-4",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 235,
			columnNumber: 11
		}, this);
		$[52] = t27;
		$[53] = t28;
		$[54] = t29;
	} else {
		t27 = $[52];
		t28 = $[53];
		t29 = $[54];
	}
	let t30;
	if ($[55] !== onNavigateCheckout) {
		t30 = /* @__PURE__ */ _jsxDEV(Link, {
			to: "/checkout",
			onClick: onNavigateCheckout,
			className: t27,
			children: [t28, t29]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 246,
			columnNumber: 11
		}, this);
		$[55] = onNavigateCheckout;
		$[56] = t30;
	} else {
		t30 = $[56];
	}
	let t31;
	if ($[57] === Symbol.for("react.memo_cache_sentinel")) {
		t31 = /* @__PURE__ */ _jsxDEV("p", {
			className: "flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground",
			children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, {
				className: "size-3.5 text-primary",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 254,
				columnNumber: 109
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Cálculo decimal de 18 casas (Wei/ETH) verificado." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 254,
				columnNumber: 177
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 254,
			columnNumber: 11
		}, this);
		$[57] = t31;
	} else {
		t31 = $[57];
	}
	let t32;
	if ($[58] !== t30) {
		t32 = /* @__PURE__ */ _jsxDEV(CardFooter, {
			className: "flex-col gap-2.5 pt-0",
			children: [t30, t31]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 261,
			columnNumber: 11
		}, this);
		$[58] = t30;
		$[59] = t32;
	} else {
		t32 = $[59];
	}
	let t33;
	if ($[60] !== t26 || $[61] !== t32) {
		t33 = /* @__PURE__ */ _jsxDEV(Card, { children: [
			t1,
			t26,
			t32
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 269,
			columnNumber: 11
		}, this);
		$[60] = t26;
		$[61] = t32;
		$[62] = t33;
	} else {
		t33 = $[62];
	}
	return t33;
}
_c2 = CartSummary;
var _c2;
$RefreshReg$(_c2, "CartSummary");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/cart/cart-summary.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/cart/cart-summary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/cart/cart-summary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/cart/cart-summary.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLFlBQVk7QUFDckIsU0FBU0MsWUFBWUMsYUFBYUMsZ0JBQWdCO0FBQ2xELFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLHNCQUFzQjtBQUMvQixTQUFTQyxNQUFNQyxhQUFhQyxZQUFZQyxZQUFZQyxpQkFBaUI7QUFDckUsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxVQUFVOzs7QUFRbkIsT0FBTyxTQUFBQyxZQUFBQyxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQXFCLFFBQUFLLE1BQUFDLHVCQUFBUDtDQUMxQixNQUFBUSxjQUFvQkYsS0FBSUcsa0JBQW1CO0NBQUMsSUFBQUM7Q0FBQSxJQUFBVCxFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFJeENLLEtBQUEsd0JBQUMsWUFBRDtHQUFzQjthQUNwQix3QkFBQyxXQUFEO0lBQWdCO0lBQXNCO0lBQWE7Y0FBWTtHQUFyRDs7Ozs7RUFERDs7Ozs7RUFJRVQsRUFBQSxLQUFBUztDQUFBO0VBQUFBLEtBQUFULEVBQUE7Q0FBQTtDQUFBLElBQUFVO0NBQUEsSUFBQVYsRUFBQSxPQUFBSyxLQUFBTSxjQUFBWCxFQUFBLE9BQUFLLEtBQUFHLGlCQUFBO0VBR1hFLEtBQUEsd0JBQUMsWUFBRDtHQUEwQixjQUFBTCxLQUFJTTtHQUE4QixpQkFBQU4sS0FBSUc7RUFBZ0I7Ozs7O0VBQUlSLEVBQUEsS0FBQUssS0FBQU07RUFBQVgsRUFBQSxLQUFBSyxLQUFBRztFQUFBUixFQUFBLEtBQUFVO0NBQUE7RUFBQUEsS0FBQVYsRUFBQTtDQUFBO0NBQUEsSUFBQVk7Q0FBQSxJQUFBWixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFFcEZRLEtBQUEsd0JBQUMsV0FBRCxDQUFVOzs7OztFQUFHWixFQUFBLEtBQUFZO0NBQUE7RUFBQUEsS0FBQVosRUFBQTtDQUFBO0NBS3NCLE1BQUFhLEtBQUFSLEtBQUlTLGVBQWdCLElBQXBCO0NBQXdDLElBQUFDO0NBQUEsSUFBQWYsRUFBQSxPQUFBSyxLQUFBUyxjQUFBZCxFQUFBLE9BQUFhLElBQUE7RUFEdkVFLEtBQUE7R0FBYzthQUFkO0lBQXNDO0lBQ3pCVixLQUFJUztJQUFZO0lBQUVEO0lBQXlDO0dBQ25FOzs7Ozs7RUFBQWIsRUFBQSxLQUFBSyxLQUFBUztFQUFBZCxFQUFBLEtBQUFhO0VBQUFiLEVBQUEsS0FBQWU7Q0FBQTtFQUFBQSxLQUFBZixFQUFBO0NBQUE7Q0FBQSxJQUFBZ0I7Q0FBQSxJQUFBaEIsRUFBQSxPQUFBSyxLQUFBWSxhQUFBO0VBQ21DRCxLQUFBcEIsVUFBVVMsS0FBSVksV0FBWTtFQUFDakIsRUFBQSxLQUFBSyxLQUFBWTtFQUFBakIsRUFBQSxNQUFBZ0I7Q0FBQTtFQUFBQSxLQUFBaEIsRUFBQTtDQUFBO0NBQUEsSUFBQWtCO0NBQUEsSUFBQWxCLEVBQUEsUUFBQWdCLElBQUE7RUFBbkVFLEtBQUE7R0FBYzthQUFkLENBQXdDRixJQUE0QixNQUFTOzs7Ozs7RUFBQWhCLEVBQUEsTUFBQWdCO0VBQUFoQixFQUFBLE1BQUFrQjtDQUFBO0VBQUFBLEtBQUFsQixFQUFBO0NBQUE7Q0FBQSxJQUFBbUI7Q0FBQSxJQUFBbkIsRUFBQSxRQUFBZSxNQUFBZixFQUFBLFFBQUFrQixJQUFBO0VBSi9FQyxLQUFBO0dBQWU7YUFBZixDQUNFSixJQUdBRyxFQUNJOzs7Ozs7RUFBQWxCLEVBQUEsTUFBQWU7RUFBQWYsRUFBQSxNQUFBa0I7RUFBQWxCLEVBQUEsTUFBQW1CO0NBQUE7RUFBQUEsS0FBQW5CLEVBQUE7Q0FBQTtDQUFBLElBQUFvQjtDQUFBLElBQUFwQixFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFJRmdCLEtBQUEsNENBQU0sV0FBZTs7Ozs7RUFBQXBCLEVBQUEsTUFBQW9CO0NBQUE7RUFBQUEsS0FBQXBCLEVBQUE7Q0FBQTtDQUFBLElBQUFxQjtDQUFBLElBQUFyQixFQUFBLFFBQUFLLEtBQUFHLG1CQUFBUixFQUFBLFFBQUFPLGFBQUE7RUFDcEJjLE1BQUFkLGVBQWUsd0JBQUMsT0FBRDtHQUFlO2FBQWY7SUFBMkI7SUFBRUYsS0FBSUc7SUFBaUI7R0FBNUM7Ozs7OztFQUFxRFIsRUFBQSxNQUFBSyxLQUFBRztFQUFBUixFQUFBLE1BQUFPO0VBQUFQLEVBQUEsTUFBQXFCO0NBQUE7RUFBQUEsTUFBQXJCLEVBQUE7Q0FBQTtDQUFBLElBQUFzQjtDQUFBLElBQUF0QixFQUFBLFFBQUFxQixLQUFBO0VBRjdFQyxNQUFBO0dBQWM7YUFBZCxDQUNFRixJQUNDQyxHQUNFOzs7Ozs7RUFBQXJCLEVBQUEsTUFBQXFCO0VBQUFyQixFQUFBLE1BQUFzQjtDQUFBO0VBQUFBLE1BQUF0QixFQUFBO0NBQUE7Q0FDdUMsTUFBQXVCLE1BQUFoQixlQUFBO0NBQXlDLElBQUFpQjtDQUFBLElBQUF4QixFQUFBLFFBQUF1QixLQUFBO0VBQXRFQyxNQUFBM0IsR0FBRywwQkFBMEIwQixHQUF5QztFQUFDdkIsRUFBQSxNQUFBdUI7RUFBQXZCLEVBQUEsTUFBQXdCO0NBQUE7RUFBQUEsTUFBQXhCLEVBQUE7Q0FBQTtDQUFBLElBQUF5QjtDQUFBLElBQUF6QixFQUFBLFFBQUFLLEtBQUFxQixhQUFBO0VBQ2pGRCxNQUFBN0IsVUFBVVMsS0FBSXFCLFdBQVk7RUFBQzFCLEVBQUEsTUFBQUssS0FBQXFCO0VBQUExQixFQUFBLE1BQUF5QjtDQUFBO0VBQUFBLE1BQUF6QixFQUFBO0NBQUE7Q0FBQSxJQUFBMkI7Q0FBQSxJQUFBM0IsRUFBQSxRQUFBd0IsT0FBQXhCLEVBQUEsUUFBQXlCLEtBQUE7RUFEaENFLE1BQUE7R0FBZSxXQUFBSDthQUFmO0lBQXdGO0lBQ25GQztJQUE0QjtHQUM1Qjs7Ozs7O0VBQUF6QixFQUFBLE1BQUF3QjtFQUFBeEIsRUFBQSxNQUFBeUI7RUFBQXpCLEVBQUEsTUFBQTJCO0NBQUE7RUFBQUEsTUFBQTNCLEVBQUE7Q0FBQTtDQUFBLElBQUE0QjtDQUFBLElBQUE1QixFQUFBLFFBQUFzQixPQUFBdEIsRUFBQSxRQUFBMkIsS0FBQTtFQVBQQyxNQUFBO0dBQWU7YUFBZixDQUNFTixLQUlBSyxHQUdJOzs7Ozs7RUFBQTNCLEVBQUEsTUFBQXNCO0VBQUF0QixFQUFBLE1BQUEyQjtFQUFBM0IsRUFBQSxNQUFBNEI7Q0FBQTtFQUFBQSxNQUFBNUIsRUFBQTtDQUFBO0NBQUEsSUFBQTZCO0NBQUEsSUFBQTdCLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUdKeUIsTUFBQTtHQUFjO2FBQXdCO0VBQWdDOzs7OztFQUFBN0IsRUFBQSxNQUFBNkI7Q0FBQTtFQUFBQSxNQUFBN0IsRUFBQTtDQUFBO0NBQUEsSUFBQThCO0NBQUEsSUFBQTlCLEVBQUEsUUFBQUssS0FBQTBCLFFBQUE7RUFDOUJELE1BQUFsQyxVQUFVUyxLQUFJMEIsTUFBTztFQUFDL0IsRUFBQSxNQUFBSyxLQUFBMEI7RUFBQS9CLEVBQUEsTUFBQThCO0NBQUE7RUFBQUEsTUFBQTlCLEVBQUE7Q0FBQTtDQUFBLElBQUFnQztDQUFBLElBQUFoQyxFQUFBLFFBQUE4QixLQUFBO0VBRmhFRSxNQUFBO0dBQWU7YUFBZixDQUNFSCxLQUNBO0lBQWM7Y0FBZCxDQUF3Q0MsS0FBdUIsTUFBUzs7Ozs7V0FDcEU7Ozs7OztFQUFBOUIsRUFBQSxNQUFBOEI7RUFBQTlCLEVBQUEsTUFBQWdDO0NBQUE7RUFBQUEsTUFBQWhDLEVBQUE7Q0FBQTtDQUFBLElBQUFpQztDQUFBLElBQUFqQyxFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFFTjZCLE1BQUEsd0JBQUMsV0FBRCxFQUFxQixrQkFBTTs7Ozs7RUFBR2pDLEVBQUEsTUFBQWlDO0NBQUE7RUFBQUEsTUFBQWpDLEVBQUE7Q0FBQTtDQUFBLElBQUFrQztDQUFBLElBQUFsQyxFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFHNUI4QixNQUFBLDBDQUFJLGlCQUFtQjs7Ozs7RUFBQWxDLEVBQUEsTUFBQWtDO0NBQUE7RUFBQUEsTUFBQWxDLEVBQUE7Q0FBQTtDQUFBLElBQUFtQztDQUFBLElBQUFuQyxFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFFckIrQixNQUFBLHdCQUFDLFVBQUQ7R0FBb0I7R0FBa0M7RUFBTTs7Ozs7RUFBR25DLEVBQUEsTUFBQW1DO0NBQUE7RUFBQUEsTUFBQW5DLEVBQUE7Q0FBQTtDQUFBLElBQUFvQztDQUFBLElBQUFwQyxFQUFBLFFBQUFLLEtBQUFnQyxVQUFBO0VBQ3hERCxNQUFBeEMsVUFBVVMsS0FBSWdDLFFBQVM7RUFBQ3JDLEVBQUEsTUFBQUssS0FBQWdDO0VBQUFyQyxFQUFBLE1BQUFvQztDQUFBO0VBQUFBLE1BQUFwQyxFQUFBO0NBQUE7Q0FBQSxJQUFBc0M7Q0FBQSxJQUFBdEMsRUFBQSxRQUFBb0MsS0FBQTtFQUpuQ0UsTUFBQTtHQUFlO2FBQWYsQ0FDRUosS0FDQTtJQUFjO2NBQWQsQ0FDRUMsS0FDQSw2Q0FBT0MsS0FBeUIsTUFBVzs7OztZQUN4Qzs7Ozs7V0FDRDs7Ozs7O0VBQUFwQyxFQUFBLE1BQUFvQztFQUFBcEMsRUFBQSxNQUFBc0M7Q0FBQTtFQUFBQSxNQUFBdEMsRUFBQTtDQUFBO0NBQUEsSUFBQXVDO0NBQUEsSUFBQXZDLEVBQUEsUUFBQTRCLE9BQUE1QixFQUFBLFFBQUFnQyxPQUFBaEMsRUFBQSxRQUFBc0MsT0FBQXRDLEVBQUEsUUFBQW1CLElBQUE7RUEvQlJvQixNQUFBO0dBQWM7R0FBK0I7YUFBN0M7SUFDRXBCO0lBT0FTO0lBVUFJO0lBS0FDO0lBRUFLO0dBT0c7Ozs7OztFQUFBdEMsRUFBQSxNQUFBNEI7RUFBQTVCLEVBQUEsTUFBQWdDO0VBQUFoQyxFQUFBLE1BQUFzQztFQUFBdEMsRUFBQSxNQUFBbUI7RUFBQW5CLEVBQUEsTUFBQXVDO0NBQUE7RUFBQUEsTUFBQXZDLEVBQUE7Q0FBQTtDQUFBLElBQUF3QztDQUFBLElBQUF4QyxFQUFBLFFBQUFVLE1BQUFWLEVBQUEsUUFBQXVDLEtBQUE7RUFyQ1BDLE1BQUEsd0JBQUMsYUFBRDtHQUF1QjthQUF2QjtJQUNFOUI7SUFFQUU7SUFFQTJCO0dBTFU7Ozs7OztFQXNDRXZDLEVBQUEsTUFBQVU7RUFBQVYsRUFBQSxNQUFBdUM7RUFBQXZDLEVBQUEsTUFBQXdDO0NBQUE7RUFBQUEsTUFBQXhDLEVBQUE7Q0FBQTtDQUFBLElBQUF5QztDQUFBLElBQUFDO0NBQUEsSUFBQUM7Q0FBQSxJQUFBM0MsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBTUNxQyxNQUFBNUMsR0FBR1IsZUFBZTtHQUFBdUQsU0FBVztHQUFTQyxNQUFRO0VBQUssQ0FBQyxHQUFHLFFBQVE7RUFFMUVILE1BQUEsNENBQU0scUJBQXlCOzs7OztFQUMvQkMsTUFBQSx3QkFBQyxZQUFEO0dBQXNCO0dBQXFCO0VBQU07Ozs7O0VBQUczQyxFQUFBLE1BQUF5QztFQUFBekMsRUFBQSxNQUFBMEM7RUFBQTFDLEVBQUEsTUFBQTJDO0NBQUE7RUFBQUYsTUFBQXpDLEVBQUE7RUFBQTBDLE1BQUExQyxFQUFBO0VBQUEyQyxNQUFBM0MsRUFBQTtDQUFBO0NBQUEsSUFBQThDO0NBQUEsSUFBQTlDLEVBQUEsUUFBQU0sb0JBQUE7RUFOdER3QyxNQUFBLHdCQUFDLE1BQUQ7R0FDSztHQUNNeEM7R0FDRSxXQUFBbUM7YUFIYixDQUtFQyxLQUNBQyxHQU5HOzs7Ozs7RUFPRTNDLEVBQUEsTUFBQU07RUFBQU4sRUFBQSxNQUFBOEM7Q0FBQTtFQUFBQSxNQUFBOUMsRUFBQTtDQUFBO0NBQUEsSUFBQStDO0NBQUEsSUFBQS9DLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUNQMkMsTUFBQTtHQUFhO2FBQWIsQ0FDRSx3QkFBQyxhQUFEO0lBQXVCO0lBQW9DO0dBQU07Ozs7YUFDakUsNENBQU0sb0RBQXdEOzs7O1dBQzVEOzs7Ozs7RUFBQS9DLEVBQUEsTUFBQStDO0NBQUE7RUFBQUEsTUFBQS9DLEVBQUE7Q0FBQTtDQUFBLElBQUFnRDtDQUFBLElBQUFoRCxFQUFBLFFBQUE4QyxLQUFBO0VBWk5FLE1BQUEsd0JBQUMsWUFBRDtHQUFzQjthQUF0QixDQUNFRixLQVFBQyxHQVRTOzs7Ozs7RUFhRS9DLEVBQUEsTUFBQThDO0VBQUE5QyxFQUFBLE1BQUFnRDtDQUFBO0VBQUFBLE1BQUFoRCxFQUFBO0NBQUE7Q0FBQSxJQUFBaUQ7Q0FBQSxJQUFBakQsRUFBQSxRQUFBd0MsT0FBQXhDLEVBQUEsUUFBQWdELEtBQUE7RUE1RGZDLE1BQUEsd0JBQUMsTUFBRDtHQUNFeEM7R0FNQStCO0dBd0NBUTtFQS9DRzs7Ozs7RUE2REVoRCxFQUFBLE1BQUF3QztFQUFBeEMsRUFBQSxNQUFBZ0Q7RUFBQWhELEVBQUEsTUFBQWlEO0NBQUE7RUFBQUEsTUFBQWpELEVBQUE7Q0FBQTtDQUFBLE9BN0RQaUQ7QUE2RE8iLCJuYW1lcyI6WyJMaW5rIiwiQXJyb3dSaWdodCIsIlNoaWVsZENoZWNrIiwiU3BhcmtsZXMiLCJDb3Vwb25Gb3JtIiwiQmFkZ2UiLCJidXR0b25WYXJpYW50cyIsIkNhcmQiLCJDYXJkQ29udGVudCIsIkNhcmRGb290ZXIiLCJDYXJkSGVhZGVyIiwiQ2FyZFRpdGxlIiwiU2VwYXJhdG9yIiwiZm9ybWF0RXRoIiwiY24iLCJDYXJ0U3VtbWFyeSIsInQwIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJjYXJ0Iiwib25OYXZpZ2F0ZUNoZWNrb3V0IiwiaGFzRGlzY291bnQiLCJkaXNjb3VudFBlcmNlbnQiLCJ0MSIsInQyIiwiY291cG9uQ29kZSIsInQzIiwidDQiLCJ0b3RhbEl0ZW1zIiwidDUiLCJ0NiIsInN1YnRvdGFsRXRoIiwidDciLCJ0OCIsInQ5IiwidDEwIiwidDExIiwidDEyIiwidDEzIiwidDE0IiwiZGlzY291bnRFdGgiLCJ0MTUiLCJ0MTYiLCJ0MTciLCJ0MTgiLCJmZWVFdGgiLCJ0MTkiLCJ0MjAiLCJ0MjEiLCJ0MjIiLCJ0MjMiLCJ0b3RhbEV0aCIsInQyNCIsInQyNSIsInQyNiIsInQyNyIsInQyOCIsInQyOSIsInZhcmlhbnQiLCJzaXplIiwidDMwIiwidDMxIiwidDMyIiwidDMzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImNhcnQtc3VtbWFyeS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyBBcnJvd1JpZ2h0LCBTaGllbGRDaGVjaywgU3BhcmtsZXMgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBDb3Vwb25Gb3JtIH0gZnJvbSAnQC9jb21wb25lbnRzL2NhcnQvY291cG9uLWZvcm0nXG5pbXBvcnQgeyBCYWRnZSB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9iYWRnZSdcbmltcG9ydCB7IGJ1dHRvblZhcmlhbnRzIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcbmltcG9ydCB7IENhcmQsIENhcmRDb250ZW50LCBDYXJkRm9vdGVyLCBDYXJkSGVhZGVyLCBDYXJkVGl0bGUgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvY2FyZCdcbmltcG9ydCB7IFNlcGFyYXRvciB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9zZXBhcmF0b3InXG5pbXBvcnQgeyBmb3JtYXRFdGggfSBmcm9tICdAL2xpYi9ldGgnXG5pbXBvcnQgeyBjbiB9IGZyb20gJ0AvbGliL3V0aWxzJ1xuaW1wb3J0IHR5cGUgeyBDYXJ0UmVzcG9uc2UgfSBmcm9tICdAL3R5cGVzL2FwaSdcblxuaW50ZXJmYWNlIENhcnRTdW1tYXJ5UHJvcHMge1xuICBjYXJ0OiBDYXJ0UmVzcG9uc2VcbiAgb25OYXZpZ2F0ZUNoZWNrb3V0PzogKCkgPT4gdm9pZFxufVxuXG5leHBvcnQgZnVuY3Rpb24gQ2FydFN1bW1hcnkoeyBjYXJ0LCBvbk5hdmlnYXRlQ2hlY2tvdXQgfTogQ2FydFN1bW1hcnlQcm9wcykge1xuICBjb25zdCBoYXNEaXNjb3VudCA9IGNhcnQuZGlzY291bnRQZXJjZW50ID4gMFxuXG4gIHJldHVybiAoXG4gICAgPENhcmQ+XG4gICAgICA8Q2FyZEhlYWRlciBjbGFzc05hbWU9XCJwYi0yXCI+XG4gICAgICAgIDxDYXJkVGl0bGUgcm9sZT1cImhlYWRpbmdcIiBhcmlhLWxldmVsPXsyfSBjbGFzc05hbWU9XCJ0ZXh0LWJhc2VcIj5cbiAgICAgICAgICBSZXN1bW8gZG8gUGVkaWRvXG4gICAgICAgIDwvQ2FyZFRpdGxlPlxuICAgICAgPC9DYXJkSGVhZGVyPlxuXG4gICAgICA8Q2FyZENvbnRlbnQgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNFwiPlxuICAgICAgICA8Q291cG9uRm9ybSBhY3RpdmVDb3Vwb249e2NhcnQuY291cG9uQ29kZX0gZGlzY291bnRQZXJjZW50PXtjYXJ0LmRpc2NvdW50UGVyY2VudH0gLz5cblxuICAgICAgICA8U2VwYXJhdG9yIC8+XG5cbiAgICAgICAgPGRsIGNsYXNzTmFtZT1cImdyaWQgZ2FwLTIgdGV4dC1zbVwiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgIFN1YnRvdGFsICh7Y2FydC50b3RhbEl0ZW1zfSB7Y2FydC50b3RhbEl0ZW1zID09PSAxID8gJ2l0ZW0nIDogJ2l0ZW5zJ30pXG4gICAgICAgICAgICA8L2R0PlxuICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0YWJ1bGFyLW51bXNcIj57Zm9ybWF0RXRoKGNhcnQuc3VidG90YWxFdGgpfSBFVEg8L2RkPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cbiAgICAgICAgICAgIDxkdCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICA8c3Bhbj5EZXNjb250bzwvc3Bhbj5cbiAgICAgICAgICAgICAge2hhc0Rpc2NvdW50ICYmIDxCYWRnZSB2YXJpYW50PVwic2Vjb25kYXJ5XCI+LXtjYXJ0LmRpc2NvdW50UGVyY2VudH0lPC9CYWRnZT59XG4gICAgICAgICAgICA8L2R0PlxuICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT17Y24oJ2ZvbnQtbW9ubyB0YWJ1bGFyLW51bXMnLCBoYXNEaXNjb3VudCAmJiAnZm9udC1tZWRpdW0gdGV4dC1wcmltYXJ5Jyl9PlxuICAgICAgICAgICAgICAtIHtmb3JtYXRFdGgoY2FydC5kaXNjb3VudEV0aCl9IEVUSFxuICAgICAgICAgICAgPC9kZD5cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+VGF4YSBmaXhhIChHYXMgJiBQcm90b2NvbG8pPC9kdD5cbiAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJmb250LW1vbm8gdGFidWxhci1udW1zXCI+e2Zvcm1hdEV0aChjYXJ0LmZlZUV0aCl9IEVUSDwvZGQ+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8U2VwYXJhdG9yIGNsYXNzTmFtZT1cIm15LTFcIiAvPlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWJhc2VsaW5lIGp1c3RpZnktYmV0d2VlbiBnYXAtMiB0ZXh0LWJhc2UgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICA8ZHQ+VG90YWwgZXN0aW1hZG88L2R0PlxuICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGZvbnQtbW9ubyB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgPFNwYXJrbGVzIGNsYXNzTmFtZT1cInNpemUtNCB0ZXh0LXByaW1hcnlcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj57Zm9ybWF0RXRoKGNhcnQudG90YWxFdGgpfSBFVEg8L3NwYW4+XG4gICAgICAgICAgICA8L2RkPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2RsPlxuICAgICAgPC9DYXJkQ29udGVudD5cblxuICAgICAgPENhcmRGb290ZXIgY2xhc3NOYW1lPVwiZmxleC1jb2wgZ2FwLTIuNSBwdC0wXCI+XG4gICAgICAgIDxMaW5rXG4gICAgICAgICAgdG89XCIvY2hlY2tvdXRcIlxuICAgICAgICAgIG9uQ2xpY2s9e29uTmF2aWdhdGVDaGVja291dH1cbiAgICAgICAgICBjbGFzc05hbWU9e2NuKGJ1dHRvblZhcmlhbnRzKHsgdmFyaWFudDogJ2RlZmF1bHQnLCBzaXplOiAnbGcnIH0pLCAndy1mdWxsJyl9XG4gICAgICAgID5cbiAgICAgICAgICA8c3Bhbj5JciBwYXJhIG8gQ2hlY2tvdXQ8L3NwYW4+XG4gICAgICAgICAgPEFycm93UmlnaHQgY2xhc3NOYW1lPVwic2l6ZS00XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgPC9MaW5rPlxuICAgICAgICA8cCBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBnYXAtMS41IHRleHQtY2VudGVyIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgPFNoaWVsZENoZWNrIGNsYXNzTmFtZT1cInNpemUtMy41IHRleHQtcHJpbWFyeVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgPHNwYW4+Q8OhbGN1bG8gZGVjaW1hbCBkZSAxOCBjYXNhcyAoV2VpL0VUSCkgdmVyaWZpY2Fkby48L3NwYW4+XG4gICAgICAgIDwvcD5cbiAgICAgIDwvQ2FyZEZvb3Rlcj5cbiAgICA8L0NhcmQ+XG4gIClcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL2NvbXBvbmVudHMvY2FydC9jYXJ0LXN1bW1hcnkudHN4In0=