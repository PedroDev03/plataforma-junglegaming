import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/index.tsx?tsr-split=component");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { NftCatalog } from "/src/components/nft/nft-catalog.tsx";
import { DEFAULT_PAGE_SIZE } from "/src/schemas/nft-search.ts";
import { Route } from "/src/routes/index.tsx";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/routes/index.tsx?tsr-split=component";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
function HomeCatalogPage() {
	_s();
	const $ = _c(12);
	if ($[0] !== "237661a7eed2d66a3eb250c7bd5440c96549f0b23f5f91ab0ff3ab07098728dc") {
		for (let $i = 0; $i < 12; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "237661a7eed2d66a3eb250c7bd5440c96549f0b23f5f91ab0ff3ab07098728dc";
	}
	const search = Route.useSearch();
	const navigate = Route.useNavigate();
	let t0;
	if ($[1] !== navigate) {
		t0 = (updates) => {
			navigate({ search: (prev) => ({
				...prev,
				...updates,
				page: 1
			}) });
		};
		$[1] = navigate;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	const handleFilterChange = t0;
	let t1;
	if ($[3] !== navigate) {
		t1 = (nextPage) => {
			navigate({ search: (prev_0) => ({
				...prev_0,
				page: nextPage
			}) });
		};
		$[3] = navigate;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	const handlePageChange = t1;
	let t2;
	if ($[5] !== navigate) {
		t2 = () => {
			navigate({ search: {
				sort: "recent",
				page: 1,
				pageSize: DEFAULT_PAGE_SIZE
			} });
		};
		$[5] = navigate;
		$[6] = t2;
	} else {
		t2 = $[6];
	}
	const handleResetFilters = t2;
	let t3;
	if ($[7] !== handleFilterChange || $[8] !== handlePageChange || $[9] !== handleResetFilters || $[10] !== search) {
		t3 = /* @__PURE__ */ _jsxDEV(NftCatalog, {
			search,
			onFilterChange: handleFilterChange,
			onPageChange: handlePageChange,
			onResetFilters: handleResetFilters
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 67,
			columnNumber: 10
		}, this);
		$[7] = handleFilterChange;
		$[8] = handlePageChange;
		$[9] = handleResetFilters;
		$[10] = search;
		$[11] = t3;
	} else {
		t3 = $[11];
	}
	return t3;
}
_s(HomeCatalogPage, "wK//LUO0BqTgE+ImXbhmx1jtWow=", false, function() {
	return [Route.useSearch, Route.useNavigate];
});
_c2 = HomeCatalogPage;
export { HomeCatalogPage as component };
var _c2;
$RefreshReg$(_c2, "HomeCatalogPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/index.tsx?tsr-split=component";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/routes/index.tsx?tsr-split=component", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/routes/index.tsx?tsr-split=component", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/routes/index.tsx?tsr-split=component" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUNBLFNBQVNBLGtCQUFrQjtBQUUzQixTQUFTQyx5QkFBd0U7QUFBc0IsU0FBQUMsYUFBQTs7OztBQVd2RyxTQUFBQyxrQkFBQTs7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FDRSxNQUFBSyxTQUFlUCxNQUFLUSxVQUFXO0NBQy9CLE1BQUFDLFdBQWlCVCxNQUFLVSxZQUFhO0NBQUMsSUFBQUM7Q0FBQSxJQUFBVCxFQUFBLE9BQUFPLFVBQUE7RUFFVEc7R0FDcEJILFNBQVMsRUFBQUYsU0FDSE0sVUFBVTtJQUFBLEdBQ2RBO0lBQUksR0FDSkM7SUFBT0MsTUFFSjtHQUNSLEdBQ0YsQ0FBQztFQUFDO0VBQ0hiLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBUztDQUFBO0VBQUFBLEtBQUFULEVBQUE7Q0FBQTtDQVRELE1BQUFVLHFCQUEyQkE7Q0FTMUIsSUFBQUk7Q0FBQSxJQUFBZCxFQUFBLE9BQUFPLFVBQUE7RUFFd0JRO0dBQ2xCUixTQUFTLEVBQUFGLFNBQ0hNLFlBQVU7SUFBQSxHQUNkQTtJQUFJRSxNQUNERztHQUNSLEdBQ0YsQ0FBQztFQUFDO0VBQ0hoQixFQUFBLEtBQUFPO0VBQUFQLEVBQUEsS0FBQWM7Q0FBQTtFQUFBQSxLQUFBZCxFQUFBO0NBQUE7Q0FQRCxNQUFBZSxtQkFBeUJBO0NBT3hCLElBQUFFO0NBQUEsSUFBQWpCLEVBQUEsT0FBQU8sVUFBQTtFQUUwQlc7R0FDcEJYLFNBQVMsRUFBQUYsUUFDSjtJQUFBYyxNQUNBO0lBQVFOLE1BQ1I7SUFBQ08sVUFDR3ZCO0dBQ1osRUFDRixDQUFDO0VBQUM7RUFDSEcsRUFBQSxLQUFBTztFQUFBUCxFQUFBLEtBQUFpQjtDQUFBO0VBQUFBLEtBQUFqQixFQUFBO0NBQUE7Q0FSRCxNQUFBa0IscUJBQTJCQTtDQVExQixJQUFBRztDQUFBLElBQUFyQixFQUFBLE9BQUFVLHNCQUFBVixFQUFBLE9BQUFlLG9CQUFBZixFQUFBLE9BQUFrQixzQkFBQWxCLEVBQUEsUUFBQUssUUFBQTtFQUdDZ0IsS0FBQSx3QkFBQyxZQUFEO0dBQ1VoQjtHQUNRSztHQUNGSztHQUNFRztFQUFrQjs7Ozs7RUFDbENsQixFQUFBLEtBQUFVO0VBQUFWLEVBQUEsS0FBQWU7RUFBQWYsRUFBQSxLQUFBa0I7RUFBQWxCLEVBQUEsTUFBQUs7RUFBQUwsRUFBQSxNQUFBcUI7Q0FBQTtFQUFBQSxLQUFBckIsRUFBQTtDQUFBO0NBQUEsT0FMRnFCO0FBS0U7Ozs7O0FBRUwsU0FBQXRCLG1CQUFBdUIiLCJuYW1lcyI6WyJOZnRDYXRhbG9nIiwiREVGQVVMVF9QQUdFX1NJWkUiLCJSb3V0ZSIsIkhvbWVDYXRhbG9nUGFnZSIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwic2VhcmNoIiwidXNlU2VhcmNoIiwibmF2aWdhdGUiLCJ1c2VOYXZpZ2F0ZSIsInQwIiwiaGFuZGxlRmlsdGVyQ2hhbmdlIiwicHJldiIsInVwZGF0ZXMiLCJwYWdlIiwidDEiLCJoYW5kbGVQYWdlQ2hhbmdlIiwibmV4dFBhZ2UiLCJ0MiIsImhhbmRsZVJlc2V0RmlsdGVycyIsInNvcnQiLCJwYWdlU2l6ZSIsInQzIiwiY29tcG9uZW50Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImluZGV4LnRzeD90c3Itc3BsaXQ9Y29tcG9uZW50Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUZpbGVSb3V0ZSB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyBOZnRDYXRhbG9nIH0gZnJvbSAnQC9jb21wb25lbnRzL25mdC9uZnQtY2F0YWxvZydcbmltcG9ydCB7IG5mdHNMaXN0UXVlcnlPcHRpb25zIH0gZnJvbSAnQC9ob29rcy91c2UtbmZ0cydcbmltcG9ydCB7IERFRkFVTFRfUEFHRV9TSVpFLCBuZnRDYXRhbG9nU2VhcmNoU2NoZW1hLCB0eXBlIE5mdENhdGFsb2dTZWFyY2ggfSBmcm9tICdAL3NjaGVtYXMvbmZ0LXNlYXJjaCdcblxuZXhwb3J0IGNvbnN0IFJvdXRlID0gY3JlYXRlRmlsZVJvdXRlKCcvJykoe1xuICB2YWxpZGF0ZVNlYXJjaDogbmZ0Q2F0YWxvZ1NlYXJjaFNjaGVtYSxcbiAgbG9hZGVyRGVwczogKHsgc2VhcmNoIH0pID0+IHNlYXJjaCxcbiAgbG9hZGVyOiAoeyBjb250ZXh0LCBkZXBzIH0pID0+IHtcbiAgICB2b2lkIGNvbnRleHQucXVlcnlDbGllbnQucHJlZmV0Y2hRdWVyeShuZnRzTGlzdFF1ZXJ5T3B0aW9ucyhkZXBzKSlcbiAgfSxcbiAgY29tcG9uZW50OiBIb21lQ2F0YWxvZ1BhZ2UsXG59KVxuXG5mdW5jdGlvbiBIb21lQ2F0YWxvZ1BhZ2UoKSB7XG4gIGNvbnN0IHNlYXJjaCA9IFJvdXRlLnVzZVNlYXJjaCgpXG4gIGNvbnN0IG5hdmlnYXRlID0gUm91dGUudXNlTmF2aWdhdGUoKVxuXG4gIGNvbnN0IGhhbmRsZUZpbHRlckNoYW5nZSA9ICh1cGRhdGVzOiBQYXJ0aWFsPE9taXQ8TmZ0Q2F0YWxvZ1NlYXJjaCwgJ3BhZ2UnPj4pID0+IHtcbiAgICB2b2lkIG5hdmlnYXRlKHtcbiAgICAgIHNlYXJjaDogKHByZXYpID0+ICh7XG4gICAgICAgIC4uLnByZXYsXG4gICAgICAgIC4uLnVwZGF0ZXMsXG4gICAgICAgIC8vIFJlZ3JhIGVzdHJpdGE6IHRvZGEgbXVkYW7Dp2EgZGUgZmlsdHJvIHJlaW5pY2lhIGEgcGFnaW5hw6fDo28gcGFyYSAxXG4gICAgICAgIHBhZ2U6IDEsXG4gICAgICB9KSxcbiAgICB9KVxuICB9XG5cbiAgY29uc3QgaGFuZGxlUGFnZUNoYW5nZSA9IChuZXh0UGFnZTogbnVtYmVyKSA9PiB7XG4gICAgdm9pZCBuYXZpZ2F0ZSh7XG4gICAgICBzZWFyY2g6IChwcmV2KSA9PiAoe1xuICAgICAgICAuLi5wcmV2LFxuICAgICAgICBwYWdlOiBuZXh0UGFnZSxcbiAgICAgIH0pLFxuICAgIH0pXG4gIH1cblxuICBjb25zdCBoYW5kbGVSZXNldEZpbHRlcnMgPSAoKSA9PiB7XG4gICAgdm9pZCBuYXZpZ2F0ZSh7XG4gICAgICBzZWFyY2g6IHtcbiAgICAgICAgc29ydDogJ3JlY2VudCcsXG4gICAgICAgIHBhZ2U6IDEsXG4gICAgICAgIHBhZ2VTaXplOiBERUZBVUxUX1BBR0VfU0laRSxcbiAgICAgIH0sXG4gICAgfSlcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPE5mdENhdGFsb2dcbiAgICAgIHNlYXJjaD17c2VhcmNofVxuICAgICAgb25GaWx0ZXJDaGFuZ2U9e2hhbmRsZUZpbHRlckNoYW5nZX1cbiAgICAgIG9uUGFnZUNoYW5nZT17aGFuZGxlUGFnZUNoYW5nZX1cbiAgICAgIG9uUmVzZXRGaWx0ZXJzPXtoYW5kbGVSZXNldEZpbHRlcnN9XG4gICAgLz5cbiAgKVxufVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvcm91dGVzL2luZGV4LnRzeCJ9