import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/nft/nft-card-skeleton.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Card, CardContent, CardFooter, CardHeader } from "/src/components/ui/card.tsx";
import { Separator } from "/src/components/ui/separator.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-card-skeleton.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
/**
* Skeleton com exatamente as mesmas proporções do `<NftCard />` (aspect-square,
* cabeçalho com avatar do criador, bloco de preço, separador e rodapé) para evitar CLS.
*/
export function NftCardSkeleton() {
	const $ = _c(8);
	if ($[0] !== "70aa5bfce5112dec0940be0ca349902238c24e8ce84e426866c5967cdbb58563") {
		for (let $i = 0; $i < 8; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "70aa5bfce5112dec0940be0ca349902238c24e8ce84e426866c5967cdbb58563";
	}
	let t0;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ _jsxDEV("div", {
			className: "relative aspect-square w-full",
			children: /* @__PURE__ */ _jsxDEV(Skeleton, { className: "size-full rounded-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 57
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 10
		}, this);
		$[1] = t0;
	} else {
		t0 = $[1];
	}
	let t1;
	let t2;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-3.5 w-24" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 28,
			columnNumber: 10
		}, this);
		t2 = /* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-5 w-3/4" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 29,
			columnNumber: 10
		}, this);
		$[2] = t1;
		$[3] = t2;
	} else {
		t1 = $[2];
		t2 = $[3];
	}
	let t3;
	if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = /* @__PURE__ */ _jsxDEV(CardHeader, {
			className: "gap-1.5 pb-2",
			children: [
				t1,
				t2,
				/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2 pt-0.5",
					children: [/* @__PURE__ */ _jsxDEV(Skeleton, { className: "size-6 rounded-full" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 103
					}, this), /* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-3.5 w-28" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 38,
						columnNumber: 147
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 55
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 10
		}, this);
		$[4] = t3;
	} else {
		t3 = $[4];
	}
	let t4;
	let t5;
	if ($[5] === Symbol.for("react.memo_cache_sentinel")) {
		t4 = /* @__PURE__ */ _jsxDEV(CardContent, {
			className: "mt-auto pt-0",
			children: /* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-9 w-full rounded-lg" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 46,
				columnNumber: 48
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 46,
			columnNumber: 10
		}, this);
		t5 = /* @__PURE__ */ _jsxDEV(Separator, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 10
		}, this);
		$[5] = t4;
		$[6] = t5;
	} else {
		t4 = $[5];
		t5 = $[6];
	}
	let t6;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = /* @__PURE__ */ _jsxDEV(Card, {
			className: "flex h-full flex-col overflow-hidden pt-0",
			"aria-hidden": "true",
			children: [
				t0,
				t3,
				t4,
				t5,
				/* @__PURE__ */ _jsxDEV(CardFooter, {
					className: "grid grid-cols-2 gap-2 pt-3",
					children: [/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-7 w-full rounded-lg" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 157
					}, this), /* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-7 w-full rounded-lg" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 203
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 56,
					columnNumber: 105
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 10
		}, this);
		$[7] = t6;
	} else {
		t6 = $[7];
	}
	return t6;
}
_c2 = NftCardSkeleton;
var _c2;
$RefreshReg$(_c2, "NftCardSkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/nft/nft-card-skeleton.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-card-skeleton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-card-skeleton.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-card-skeleton.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLE1BQU1DLGFBQWFDLFlBQVlDLGtCQUFrQjtBQUMxRCxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsZ0JBQWdCOzs7Ozs7O0FBTXpCLE9BQU8sU0FBQUMsa0JBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBSztDQUFBLElBQUFMLEVBQUEsT0FBQUcsT0FBQUMsSUFBQTtFQUdEQyxLQUFBO0dBQWU7YUFDYix3QkFBQyxVQUFELEVBQW9CLG9DQUF3Qjs7Ozs7RUFDeEM7Ozs7O0VBQUFMLEVBQUEsS0FBQUs7Q0FBQTtFQUFBQSxLQUFBTCxFQUFBO0NBQUE7Q0FBQSxJQUFBTTtDQUFBLElBQUFDO0NBQUEsSUFBQVAsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBR0pFLEtBQUEsd0JBQUMsVUFBRCxFQUFvQix3QkFBWTs7Ozs7RUFDaENDLEtBQUEsd0JBQUMsVUFBRCxFQUFvQix1QkFBVzs7Ozs7RUFBR1AsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFPO0NBQUE7RUFBQUQsS0FBQU4sRUFBQTtFQUFBTyxLQUFBUCxFQUFBO0NBQUE7Q0FBQSxJQUFBUTtDQUFBLElBQUFSLEVBQUEsT0FBQUcsT0FBQUMsSUFBQTtFQUZwQ0ksS0FBQSx3QkFBQyxZQUFEO0dBQXNCO2FBQXRCO0lBQ0VGO0lBQ0FDO0lBQ0E7S0FBZTtlQUFmLENBQ0Usd0JBQUMsVUFBRCxFQUFvQixpQ0FBcUI7Ozs7ZUFDekMsd0JBQUMsVUFBRCxFQUFvQix3QkFBWTs7OzthQUM1Qjs7Ozs7O0dBTkc7Ozs7OztFQU9FUCxFQUFBLEtBQUFRO0NBQUE7RUFBQUEsS0FBQVIsRUFBQTtDQUFBO0NBQUEsSUFBQVM7Q0FBQSxJQUFBQztDQUFBLElBQUFWLEVBQUEsT0FBQUcsT0FBQUMsSUFBQTtFQUViSyxLQUFBLHdCQUFDLGFBQUQ7R0FBdUI7YUFDckIsd0JBQUMsVUFBRCxFQUFvQixtQ0FBdUI7Ozs7O0VBRGpDOzs7OztFQUlaQyxLQUFBLHdCQUFDLFdBQUQsQ0FBVTs7Ozs7RUFBR1YsRUFBQSxLQUFBUztFQUFBVCxFQUFBLEtBQUFVO0NBQUE7RUFBQUQsS0FBQVQsRUFBQTtFQUFBVSxLQUFBVixFQUFBO0NBQUE7Q0FBQSxJQUFBVztDQUFBLElBQUFYLEVBQUEsT0FBQUcsT0FBQUMsSUFBQTtFQWxCZk8sS0FBQSx3QkFBQyxNQUFEO0dBQWdCO0dBQXdEO2FBQXhFO0lBQ0VOO0lBSUFHO0lBU0FDO0lBSUFDO0lBRUEsd0JBQUMsWUFBRDtLQUFzQjtlQUF0QixDQUNFLHdCQUFDLFVBQUQsRUFBb0IsbUNBQXVCOzs7O2VBQzNDLHdCQUFDLFVBQUQsRUFBb0IsbUNBQXVCOzs7O2FBRmxDOzs7Ozs7R0FwQlI7Ozs7OztFQXdCRVYsRUFBQSxLQUFBVztDQUFBO0VBQUFBLEtBQUFYLEVBQUE7Q0FBQTtDQUFBLE9BeEJQVztBQXdCTyIsIm5hbWVzIjpbIkNhcmQiLCJDYXJkQ29udGVudCIsIkNhcmRGb290ZXIiLCJDYXJkSGVhZGVyIiwiU2VwYXJhdG9yIiwiU2tlbGV0b24iLCJOZnRDYXJkU2tlbGV0b24iLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsInQwIiwidDEiLCJ0MiIsInQzIiwidDQiLCJ0NSIsInQ2Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIm5mdC1jYXJkLXNrZWxldG9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDYXJkLCBDYXJkQ29udGVudCwgQ2FyZEZvb3RlciwgQ2FyZEhlYWRlciB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9jYXJkJ1xuaW1wb3J0IHsgU2VwYXJhdG9yIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NlcGFyYXRvcidcbmltcG9ydCB7IFNrZWxldG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NrZWxldG9uJ1xuXG4vKipcbiAqIFNrZWxldG9uIGNvbSBleGF0YW1lbnRlIGFzIG1lc21hcyBwcm9wb3LDp8O1ZXMgZG8gYDxOZnRDYXJkIC8+YCAoYXNwZWN0LXNxdWFyZSxcbiAqIGNhYmXDp2FsaG8gY29tIGF2YXRhciBkbyBjcmlhZG9yLCBibG9jbyBkZSBwcmXDp28sIHNlcGFyYWRvciBlIHJvZGFww6kpIHBhcmEgZXZpdGFyIENMUy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIE5mdENhcmRTa2VsZXRvbigpIHtcbiAgcmV0dXJuIChcbiAgICA8Q2FyZCBjbGFzc05hbWU9XCJmbGV4IGgtZnVsbCBmbGV4LWNvbCBvdmVyZmxvdy1oaWRkZW4gcHQtMFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBhc3BlY3Qtc3F1YXJlIHctZnVsbFwiPlxuICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwic2l6ZS1mdWxsIHJvdW5kZWQtbm9uZVwiIC8+XG4gICAgICA8L2Rpdj5cblxuICAgICAgPENhcmRIZWFkZXIgY2xhc3NOYW1lPVwiZ2FwLTEuNSBwYi0yXCI+XG4gICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTMuNSB3LTI0XCIgLz5cbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNSB3LTMvNFwiIC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHQtMC41XCI+XG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cInNpemUtNiByb3VuZGVkLWZ1bGxcIiAvPlxuICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTMuNSB3LTI4XCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L0NhcmRIZWFkZXI+XG5cbiAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9XCJtdC1hdXRvIHB0LTBcIj5cbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtOSB3LWZ1bGwgcm91bmRlZC1sZ1wiIC8+XG4gICAgICA8L0NhcmRDb250ZW50PlxuXG4gICAgICA8U2VwYXJhdG9yIC8+XG5cbiAgICAgIDxDYXJkRm9vdGVyIGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTIgZ2FwLTIgcHQtM1wiPlxuICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC03IHctZnVsbCByb3VuZGVkLWxnXCIgLz5cbiAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNyB3LWZ1bGwgcm91bmRlZC1sZ1wiIC8+XG4gICAgICA8L0NhcmRGb290ZXI+XG4gICAgPC9DYXJkPlxuICApXG59XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9jb21wb25lbnRzL25mdC9uZnQtY2FyZC1za2VsZXRvbi50c3gifQ==