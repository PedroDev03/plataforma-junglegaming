import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/_authenticated/checkout.tsx?tsr-split=component");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const useEffect = __vite__cjsImport1_react["useEffect"]; const useId = __vite__cjsImport1_react["useId"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport24_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport24_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=e9f94b2e";
import { Link, useRouter } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { AlertCircle, ArrowLeft, CheckCircle2, Clock, Fingerprint, RefreshCw, ShieldCheck, ShoppingBag, Sparkles, Wallet as WalletIcon, Zap } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=e9f94b2e";
import { SubmitButton } from "/src/components/form/submit-button.tsx";
import { Alert, AlertDescription, AlertTitle } from "/src/components/ui/alert.tsx";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "/src/components/ui/alert-dialog.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button, buttonVariants } from "/src/components/ui/button.tsx";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "/src/components/ui/card.tsx";
import { Checkbox } from "/src/components/ui/checkbox.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { RadioGroup, RadioGroupItem } from "/src/components/ui/radio-group.tsx";
import { Separator } from "/src/components/ui/separator.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
import { Switch } from "/src/components/ui/switch.tsx";
import { useMe } from "/src/hooks/use-auth.ts";
import { useCart } from "/src/hooks/use-cart.ts";
import { useCreateOrder, useValidateCheckout } from "/src/hooks/use-orders.ts";
import { useSocket } from "/src/hooks/use-socket.ts";
import { getErrorMessage, isTimeoutError } from "/src/lib/api.ts";
import { calculateCartTotals, compareEth, formatEth, multiplyEth, subtractEth } from "/src/lib/eth.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated/checkout.tsx?tsr-split=component";
import __vite__cjsImport24_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
function CheckoutPage() {
	_s();
	const router = useRouter();
	const { data: cart, isLoading: isCartLoading, isError: isCartError, error: cartError } = useCart();
	const { data: user, isLoading: isUserLoading } = useMe();
	const validateCheckout = useValidateCheckout();
	const createOrder = useCreateOrder();
	const { latestNftUpdate, clearLatestNftUpdate, triggerSimulatedNftUpdate } = useSocket();
	// Chave de idempotência estável por intenção de compra (preservada em caso de timeout!)
	const [idempotencyKey, setIdempotencyKey] = useState(() => crypto.randomUUID());
	const [excludedItemIds, setExcludedItemIds] = useState([]);
	const [selectedWallet, setSelectedWallet] = useState("");
	const [simulateFirstTimeout, setSimulateFirstTimeout] = useState(false);
	const [timedOutOnce, setTimedOutOnce] = useState(false);
	const timeoutSwitchId = useId();
	const timeoutHintId = useId();
	// Valida automaticamente preço, cupom e disponibilidade no MSW ao abrir o checkout
	useEffect(() => {
		validateCheckout.mutate();
		// eslint-disable-next-line react-hooks/exhaustive-deps
	}, []);
	if (isCartLoading || isUserLoading) {
		return /* @__PURE__ */ _jsxDEV(CheckoutSkeleton, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 12
		}, this);
	}
	if (isCartError || !cart || !user) {
		return /* @__PURE__ */ _jsxDEV("main", {
			id: "main-content",
			className: "mx-auto grid w-full max-w-3xl gap-4 p-4 md:py-10",
			children: /* @__PURE__ */ _jsxDEV(Alert, {
				variant: "destructive",
				role: "alert",
				children: [
					/* @__PURE__ */ _jsxDEV(AlertCircle, {
						className: "size-4",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 65,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(AlertTitle, { children: "Erro ao carregar dados do checkout" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 66,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(AlertDescription, { children: getErrorMessage(cartError) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 67,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 12
		}, this);
	}
	if (cart.items.length === 0 && !timedOutOnce) {
		return /* @__PURE__ */ _jsxDEV("main", {
			id: "main-content",
			className: "mx-auto grid w-full max-w-2xl gap-6 px-4 py-10",
			children: /* @__PURE__ */ _jsxDEV(Card, {
				className: "border-dashed text-center",
				children: /* @__PURE__ */ _jsxDEV(CardContent, {
					className: "flex flex-col items-center gap-3 py-12",
					children: [
						/* @__PURE__ */ _jsxDEV(ShoppingBag, {
							className: "size-10 text-muted-foreground",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 75,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("h1", {
							className: "text-lg font-semibold",
							children: "Nenhum item no carrinho para checkout"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV("p", {
							className: "text-xs text-muted-foreground sm:text-sm",
							children: "Adicione NFTs ao carrinho antes de iniciar o pagamento."
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 77,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Link, {
							to: "/",
							className: cn(buttonVariants({ variant: "default" })),
							children: "Explorar Catálogo"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 73,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 72,
			columnNumber: 12
		}, this);
	}
	// Regra 5 (Fase 6): detecta se algum NFT presente no carrinho sofreu alteração de preço via Socket.IO
	const interruptedBySocketEvent = latestNftUpdate && cart.items.some((item) => item.nftId === latestNftUpdate.nftId) ? latestNftUpdate : null;
	const activeWalletAddress = selectedWallet || user.wallets[0]?.address || "";
	const selectedItems = cart.items.filter((item) => !excludedItemIds.includes(item.id));
	const totals = calculateCartTotals(selectedItems, cart.discountPercent);
	const hasSufficientBalance = compareEth(user.balanceEth, totals.totalEth) >= 0;
	const remainingBalanceEth = hasSufficientBalance ? subtractEth(user.balanceEth, totals.totalEth) : user.balanceEth;
	const handleAcknowledgeSocketPriceChange = () => {
		clearLatestNftUpdate();
		setTimedOutOnce(false);
		setIdempotencyKey(crypto.randomUUID());
		validateCheckout.mutate();
	};
	const toggleItemSelection = (itemId, checked) => {
		setExcludedItemIds((prev) => checked ? prev.filter((id) => id !== itemId) : [...prev, itemId]);
		if (!timedOutOnce) {
			setIdempotencyKey(crypto.randomUUID());
		}
	};
	const handleConfirmOrder = (isRetry = false) => {
		if (interruptedBySocketEvent) {
			toast.error("Fluxo interrompido: sincronize o novo preço atualizado em tempo real antes de continuar.");
			return;
		}
		if (selectedItems.length === 0 && !timedOutOnce) {
			toast.error("Selecione ao menos um item para finalizar a compra.");
			return;
		}
		const shouldForceShortTimeout = simulateFirstTimeout && !timedOutOnce && !isRetry;
		createOrder.mutate({
			payload: {
				itemIds: selectedItems.map((i) => i.id),
				walletAddress: activeWalletAddress,
				couponCode: cart.couponCode,
				idempotencyKey
			},
			timeoutMs: shouldForceShortTimeout ? 1200 : 15e3
		}, {
			onSuccess: (order) => {
				toast.success(timedOutOnce ? `Pedido #${order.id} recuperado com idempotência sem cobrança duplicada!` : `Pagamento confirmado! Pedido #${order.id} concluído.`);
				void router.navigate({
					to: "/orders/$orderId",
					params: { orderId: order.id }
				});
			},
			onError: (error) => {
				if (isTimeoutError(error)) {
					setTimedOutOnce(true);
					toast.warning("Tempo limite excedido! Reenvie com a mesma chave de idempotência para recuperar seu recibo.");
				} else {
					toast.error(getErrorMessage(error));
					validateCheckout.mutate();
				}
			}
		});
	};
	const validationIssues = validateCheckout.data?.issues ?? [];
	const targetCartNftId = selectedItems[0]?.nftId ?? cart.items[0]?.nftId;
	return /* @__PURE__ */ _jsxDEV("main", {
		id: "main-content",
		tabIndex: -1,
		className: "mx-auto grid w-full max-w-6xl gap-6 px-4 py-6 outline-none sm:px-6 md:py-10 lg:px-8",
		children: [
			/* @__PURE__ */ _jsxDEV(AlertDialog, {
				open: Boolean(interruptedBySocketEvent),
				onOpenChange: (open) => {
					if (!open) handleAcknowledgeSocketPriceChange();
				},
				children: /* @__PURE__ */ _jsxDEV(AlertDialogContent, { children: [/* @__PURE__ */ _jsxDEV(AlertDialogHeader, { children: [/* @__PURE__ */ _jsxDEV(AlertDialogTitle, { children: "Checkout Interrompido: Preço Atualizado" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 157,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV(AlertDialogDescription, { children: interruptedBySocketEvent && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
					"O NFT ",
					/* @__PURE__ */ _jsxDEV("strong", { children: interruptedBySocketEvent.name }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 160,
						columnNumber: 25
					}, this),
					" no seu carrinho teve o preço alterado em tempo real via Socket.IO de",
					" ",
					/* @__PURE__ */ _jsxDEV("strong", {
						className: "font-mono",
						children: [formatEth(interruptedBySocketEvent.oldPriceEth), " ETH"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 162,
						columnNumber: 19
					}, this),
					" ",
					"para",
					" ",
					/* @__PURE__ */ _jsxDEV("strong", {
						className: "font-mono",
						children: [formatEth(interruptedBySocketEvent.newPriceEth), " ETH"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 19
					}, this),
					". Revise os novos valores antes de prosseguir."
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 159,
					columnNumber: 44
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 158,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 156,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV(AlertDialogFooter, { children: [/* @__PURE__ */ _jsxDEV(AlertDialogCancel, {
					onClick: () => {
						clearLatestNftUpdate();
						void router.navigate({ to: "/cart" });
					},
					children: "Voltar ao carrinho"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 174,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV(AlertDialogAction, {
					onClick: handleAcknowledgeSocketPriceChange,
					children: "Atualizar preço e revisar"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 182,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 173,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 155,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 152,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("header", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", {
					className: "text-2xl font-bold tracking-tight sm:text-3xl",
					children: "Checkout Web3"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", {
					className: "text-xs text-muted-foreground sm:text-sm",
					children: "Revise a validação on-chain, selecione os itens e assine sua transação com idempotência."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 192,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 190,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						disabled: validateCheckout.isPending || createOrder.isPending,
						onClick: () => validateCheckout.mutate(),
						children: [/* @__PURE__ */ _jsxDEV(RefreshCw, {
							className: cn("size-3.5", validateCheckout.isPending && "animate-spin motion-reduce:animate-none"),
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 199,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Revalidar Preços e Estoque" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 200,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 198,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Link, {
						to: "/cart",
						className: cn(buttonVariants({
							variant: "ghost",
							size: "sm"
						})),
						children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, {
							className: "size-4",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 206,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Voltar ao carrinho" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 207,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 202,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 197,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 189,
				columnNumber: 7
			}, this),
			interruptedBySocketEvent && /* @__PURE__ */ _jsxDEV(Alert, {
				variant: "destructive",
				role: "alert",
				children: [
					/* @__PURE__ */ _jsxDEV(AlertCircle, {
						className: "size-4",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 214,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(AlertTitle, { children: "Fluxo de Checkout Interrompido (Evento Socket.IO: nft.updated)" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 215,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(AlertDescription, {
						className: "mt-2 flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("span", { children: [
							"A cotação de ",
							/* @__PURE__ */ _jsxDEV("strong", { children: interruptedBySocketEvent.name }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 218,
								columnNumber: 28
							}, this),
							" mudou de",
							" ",
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono",
								children: [formatEth(interruptedBySocketEvent.oldPriceEth), " ETH"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 219,
								columnNumber: 15
							}, this),
							" ",
							"para",
							" ",
							/* @__PURE__ */ _jsxDEV("span", {
								className: "font-mono",
								children: [formatEth(interruptedBySocketEvent.newPriceEth), " ETH"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 221,
								columnNumber: 15
							}, this),
							". Sincronize os valores para liberar o pagamento."
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 217,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(Button, {
							type: "button",
							variant: "outline",
							size: "sm",
							onClick: handleAcknowledgeSocketPriceChange,
							children: "Sincronizar novo preço"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 224,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 216,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 213,
				columnNumber: 36
			}, this),
			validationIssues.length > 0 && /* @__PURE__ */ _jsxDEV(Alert, {
				variant: "destructive",
				role: "alert",
				children: [
					/* @__PURE__ */ _jsxDEV(AlertCircle, {
						className: "size-4",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 232,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(AlertTitle, { children: "Alterações detectadas na validação com o servidor (MSW)" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 233,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(AlertDescription, { children: /* @__PURE__ */ _jsxDEV("ul", {
						className: "mt-1 list-disc pl-4 text-xs",
						children: validationIssues.map((issue, idx) => /* @__PURE__ */ _jsxDEV("li", { children: issue }, idx, false, {
							fileName: _jsxFileName,
							lineNumber: 236,
							columnNumber: 53
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 235,
						columnNumber: 13
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 234,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 231,
				columnNumber: 39
			}, this),
			timedOutOnce && /* @__PURE__ */ _jsxDEV(Alert, {
				role: "alert",
				className: "border-primary/50 bg-primary/5",
				children: [
					/* @__PURE__ */ _jsxDEV(Clock, {
						className: "size-4 text-primary",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 243,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(AlertTitle, { children: "Timeout detectado — Proteção de Idempotência Ativa" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 244,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV(AlertDescription, {
						className: "mt-2 flex flex-wrap items-center justify-between gap-3",
						children: [/* @__PURE__ */ _jsxDEV("span", {
							className: "text-xs",
							children: [
								"A 1ª requisição excedeu o tempo limite, mas a chave",
								" ",
								/* @__PURE__ */ _jsxDEV("code", {
									className: "font-mono font-semibold",
									children: idempotencyKey
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 248,
									columnNumber: 15
								}, this),
								" foi mantida. Ao reenviar, o MSW devolverá o pedido processado sem cobrar seu saldo novamente."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 246,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV(Button, {
							type: "button",
							size: "sm",
							disabled: createOrder.isPending || Boolean(interruptedBySocketEvent),
							onClick: () => handleConfirmOrder(true),
							children: [/* @__PURE__ */ _jsxDEV(RefreshCw, {
								className: "size-3.5",
								"aria-hidden": "true"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 252,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Reenviar com a mesma chave" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 253,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 251,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 245,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 242,
				columnNumber: 24
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grid items-start gap-6 lg:grid-cols-12",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "grid gap-6 lg:col-span-7",
					children: [/* @__PURE__ */ _jsxDEV(Card, { children: [/* @__PURE__ */ _jsxDEV(CardHeader, { children: [/* @__PURE__ */ _jsxDEV(CardTitle, {
						role: "heading",
						"aria-level": 2,
						className: "text-base",
						children: [
							"1. Itens para esta transação (",
							selectedItems.length,
							" de ",
							cart.items.length,
							")"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 263,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV(CardDescription, { children: "Apenas os itens marcados abaixo serão comprados e removidos do carrinho após a confirmação." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 266,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 262,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(CardContent, {
						className: "grid gap-3",
						children: cart.items.map((item) => {
							const isChecked = !excludedItemIds.includes(item.id);
							const checkboxId = `checkout-item-${item.id}`;
							const lineTotalEth = multiplyEth(item.priceEth, item.quantity);
							return /* @__PURE__ */ _jsxDEV("div", {
								className: cn("flex items-center justify-between gap-3 rounded-xl border p-3 transition-colors", isChecked ? "bg-card" : "bg-muted/30 opacity-60"),
								children: [/* @__PURE__ */ _jsxDEV("div", {
									className: "flex min-w-0 items-center gap-3",
									children: [
										/* @__PURE__ */ _jsxDEV(Checkbox, {
											id: checkboxId,
											checked: isChecked,
											disabled: createOrder.isPending || timedOutOnce,
											onCheckedChange: (checked) => toggleItemSelection(item.id, Boolean(checked))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 278,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV("img", {
											src: item.imageUrl,
											alt: `Obra NFT ${item.name} da coleção ${item.collection}`,
											loading: "lazy",
											decoding: "async",
											className: "size-12 shrink-0 rounded-lg bg-muted object-cover"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 279,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ _jsxDEV(Label, {
											htmlFor: checkboxId,
											className: "grid min-w-0 cursor-pointer gap-0.5",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "truncate text-sm font-semibold",
												children: item.name
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 281,
												columnNumber: 25
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "font-mono text-xs text-muted-foreground tabular-nums",
												children: [
													item.quantity,
													"x ",
													formatEth(item.priceEth),
													" ETH"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 282,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 280,
											columnNumber: 23
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 277,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "shrink-0 font-mono text-sm font-semibold tabular-nums",
									children: [formatEth(lineTotalEth), " ETH"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 288,
									columnNumber: 21
								}, this)]
							}, item.id, true, {
								fileName: _jsxFileName,
								lineNumber: 276,
								columnNumber: 22
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 271,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 261,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV(Card, { children: [/* @__PURE__ */ _jsxDEV(CardHeader, { children: [/* @__PURE__ */ _jsxDEV(CardTitle, {
						role: "heading",
						"aria-level": 2,
						className: "text-base",
						children: "2. Carteira Pagadora (Assinatura Web3)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 299,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV(CardDescription, { children: "Escolha qual carteira vinculada assinará o pagamento em ETH." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 302,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 298,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV(CardContent, {
						className: "grid gap-4",
						children: user.wallets.length === 0 ? /* @__PURE__ */ _jsxDEV("div", {
							className: "flex flex-wrap items-center justify-between gap-2 rounded-lg border border-dashed p-3",
							children: [/* @__PURE__ */ _jsxDEV("span", {
								className: "text-xs text-muted-foreground",
								children: "Você ainda não possui carteiras cadastradas."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 308,
								columnNumber: 19
							}, this), /* @__PURE__ */ _jsxDEV(Link, {
								to: "/profile",
								className: cn(buttonVariants({
									variant: "outline",
									size: "xs"
								})),
								children: "Adicionar no Perfil"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 311,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 307,
							columnNumber: 44
						}, this) : /* @__PURE__ */ _jsxDEV(RadioGroup, {
							value: activeWalletAddress,
							onValueChange: (val) => {
								if (val) setSelectedWallet(val);
							},
							children: user.wallets.map((w) => {
								const radioId = `wallet-${w.id}`;
								return /* @__PURE__ */ _jsxDEV("div", {
									className: "flex items-center justify-between gap-3 rounded-lg border p-3",
									children: /* @__PURE__ */ _jsxDEV("div", {
										className: "flex min-w-0 items-center gap-3",
										children: [/* @__PURE__ */ _jsxDEV(RadioGroupItem, {
											value: w.address,
											id: radioId
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 324,
											columnNumber: 27
										}, this), /* @__PURE__ */ _jsxDEV(Label, {
											htmlFor: radioId,
											className: "grid min-w-0 cursor-pointer gap-0.5",
											children: [/* @__PURE__ */ _jsxDEV("span", {
												className: "flex items-center gap-2 text-sm font-medium",
												children: [/* @__PURE__ */ _jsxDEV(WalletIcon, {
													className: "size-3.5 text-primary",
													"aria-hidden": "true"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 327,
													columnNumber: 31
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: w.label }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 328,
													columnNumber: 31
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 326,
												columnNumber: 29
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												className: "break-all font-mono text-xs text-muted-foreground",
												children: w.address
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 330,
												columnNumber: 29
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 325,
											columnNumber: 27
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 323,
										columnNumber: 25
									}, this)
								}, w.id, false, {
									fileName: _jsxFileName,
									lineNumber: 322,
									columnNumber: 24
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 317,
							columnNumber: 26
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 306,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 297,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 259,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("aside", {
					"aria-label": "Confirmação e pagamento",
					className: "grid gap-4 lg:col-span-5",
					children: /* @__PURE__ */ _jsxDEV(Card, { children: [
						/* @__PURE__ */ _jsxDEV(CardHeader, {
							className: "pb-2",
							children: /* @__PURE__ */ _jsxDEV("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ _jsxDEV(CardTitle, {
									role: "heading",
									"aria-level": 2,
									className: "text-base",
									children: "3. Liquidação em ETH"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 347,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV(Badge, {
									variant: "outline",
									className: "gap-1 font-mono text-xs",
									children: [/* @__PURE__ */ _jsxDEV(CheckCircle2, {
										className: "size-3 text-primary",
										"aria-hidden": "true"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 351,
										columnNumber: 19
									}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Idempotente" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 352,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 350,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 346,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 345,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(CardContent, {
							className: "grid gap-4",
							children: [
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid gap-1.5 rounded-lg border bg-muted/40 p-3 text-xs",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center gap-1.5 font-medium text-muted-foreground",
										children: [/* @__PURE__ */ _jsxDEV(Fingerprint, {
											className: "size-3.5 text-primary",
											"aria-hidden": "true"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 361,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Header x-idempotency-key" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 362,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 360,
										columnNumber: 17
									}, this), /* @__PURE__ */ _jsxDEV("code", {
										className: "break-all font-mono text-foreground",
										children: idempotencyKey
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 364,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 359,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("div", {
									className: "grid gap-2.5 rounded-lg border p-3",
									children: [/* @__PURE__ */ _jsxDEV("div", {
										className: "flex items-center justify-between gap-3",
										children: [/* @__PURE__ */ _jsxDEV("div", {
											className: "grid gap-0.5 text-xs",
											children: [/* @__PURE__ */ _jsxDEV(Label, {
												htmlFor: timeoutSwitchId,
												className: "cursor-pointer font-medium",
												children: "Simular Timeout na 1ª tentativa"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 371,
												columnNumber: 21
											}, this), /* @__PURE__ */ _jsxDEV("span", {
												id: timeoutHintId,
												className: "text-muted-foreground",
												children: "Testa reenvio idempotente sem cobrança dupla."
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 374,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 370,
											columnNumber: 19
										}, this), /* @__PURE__ */ _jsxDEV(Switch, {
											id: timeoutSwitchId,
											"aria-describedby": timeoutHintId,
											"aria-invalid": false,
											checked: simulateFirstTimeout,
											disabled: createOrder.isPending || timedOutOnce,
											onCheckedChange: (checked) => setSimulateFirstTimeout(Boolean(checked))
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 378,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 369,
										columnNumber: 17
									}, this), targetCartNftId && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Separator, {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 382,
										columnNumber: 21
									}, this), /* @__PURE__ */ _jsxDEV(Button, {
										type: "button",
										variant: "outline",
										size: "xs",
										disabled: createOrder.isPending,
										onClick: () => triggerSimulatedNftUpdate(targetCartNftId),
										className: "w-full",
										children: [/* @__PURE__ */ _jsxDEV(Zap, {
											className: "size-3 text-primary",
											"aria-hidden": "true"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 384,
											columnNumber: 23
										}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Simular alteração de preço via Socket.IO" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 385,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 383,
										columnNumber: 21
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 381,
										columnNumber: 37
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 368,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV(Separator, {}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 390,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ _jsxDEV("dl", {
									className: "grid gap-2 text-sm",
									"aria-live": "polite",
									children: [
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between gap-2",
											children: [/* @__PURE__ */ _jsxDEV("dt", {
												className: "text-muted-foreground",
												children: "Seu saldo atual"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 394,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("dd", {
												className: "font-mono font-medium tabular-nums",
												children: [formatEth(user.balanceEth), " ETH"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 395,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 393,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV(Separator, { className: "my-1" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 400,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between gap-2",
											children: [/* @__PURE__ */ _jsxDEV("dt", {
												className: "text-muted-foreground",
												children: "Subtotal selecionado"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 403,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("dd", {
												className: "font-mono tabular-nums",
												children: [formatEth(totals.subtotalEth), " ETH"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 404,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 402,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between gap-2",
											children: [/* @__PURE__ */ _jsxDEV("dt", {
												className: "flex items-center gap-1.5 text-muted-foreground",
												children: [/* @__PURE__ */ _jsxDEV("span", { children: "Desconto" }, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 409,
													columnNumber: 21
												}, this), cart.couponCode && /* @__PURE__ */ _jsxDEV(Badge, {
													variant: "secondary",
													className: "font-mono",
													children: [
														cart.couponCode,
														" (-",
														cart.discountPercent,
														"%)"
													]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 410,
													columnNumber: 41
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 408,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("dd", {
												className: "font-mono tabular-nums",
												children: [
													"- ",
													formatEth(totals.discountEth),
													" ETH"
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 414,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 407,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between gap-2",
											children: [/* @__PURE__ */ _jsxDEV("dt", {
												className: "text-muted-foreground",
												children: "Taxa fixa (Gas & Protocolo)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 418,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("dd", {
												className: "font-mono tabular-nums",
												children: [formatEth(totals.feeEth), " ETH"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 419,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 417,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV(Separator, { className: "my-1" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 422,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-baseline justify-between gap-2 text-base font-bold",
											children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Total a pagar" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 425,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("dd", {
												className: "flex items-center gap-1 font-mono text-lg tabular-nums",
												children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
													className: "size-4 text-primary",
													"aria-hidden": "true"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 427,
													columnNumber: 21
												}, this), /* @__PURE__ */ _jsxDEV("span", { children: [formatEth(totals.totalEth), " ETH"] }, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 428,
													columnNumber: 21
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 426,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 424,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ _jsxDEV("div", {
											className: "flex items-center justify-between gap-2 text-xs text-muted-foreground",
											children: [/* @__PURE__ */ _jsxDEV("dt", { children: "Saldo estimado após a compra" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 433,
												columnNumber: 19
											}, this), /* @__PURE__ */ _jsxDEV("dd", {
												className: "font-mono tabular-nums",
												children: [formatEth(remainingBalanceEth), " ETH"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 434,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 432,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 392,
									columnNumber: 15
								}, this),
								!hasSufficientBalance && !timedOutOnce && /* @__PURE__ */ _jsxDEV(Alert, {
									variant: "destructive",
									role: "alert",
									children: [
										/* @__PURE__ */ _jsxDEV(AlertCircle, {
											className: "size-4",
											"aria-hidden": "true"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 439,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV(AlertTitle, { children: "Saldo insuficiente" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 440,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ _jsxDEV(AlertDescription, { children: [
											"Seu saldo em ETH (",
											formatEth(user.balanceEth),
											" ETH) é menor que o total do pedido (",
											formatEth(totals.totalEth),
											" ETH)."
										] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 441,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 438,
									columnNumber: 58
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 357,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(CardFooter, {
							className: "flex-col gap-2.5 pt-0",
							children: [/* @__PURE__ */ _jsxDEV(SubmitButton, {
								type: "button",
								size: "lg",
								className: "w-full",
								isPending: createOrder.isPending,
								pendingText: "Confirmando transação na rede (aguarde)...",
								disabled: Boolean(interruptedBySocketEvent) || !hasSufficientBalance && !timedOutOnce || selectedItems.length === 0 && !timedOutOnce,
								onClick: () => handleConfirmOrder(timedOutOnce),
								children: timedOutOnce ? "Reenviar Pedido (Mesma Chave de Idempotência)" : "Confirmar e Pagar em ETH"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 449,
								columnNumber: 15
							}, this), /* @__PURE__ */ _jsxDEV("p", {
								className: "flex items-center justify-center gap-1.5 text-center text-xs text-muted-foreground",
								children: [/* @__PURE__ */ _jsxDEV(ShieldCheck, {
									className: "size-3.5 text-primary",
									"aria-hidden": "true"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 454,
									columnNumber: 17
								}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Protegido contra cliques duplos e cobrança duplicada." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 455,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 453,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 448,
							columnNumber: 13
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 344,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 343,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 258,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 150,
		columnNumber: 10
	}, this);
}
_s(CheckoutPage, "B2LoxBamGI+DJHQJdIIKo0NV6mY=", false, function() {
	return [
		useRouter,
		useCart,
		useMe,
		useValidateCheckout,
		useCreateOrder,
		useSocket
	];
});
_c2 = CheckoutPage;
function CheckoutSkeleton() {
	const $ = _c(4);
	if ($[0] !== "e8f9fddb72ef2a0000b5facfd3e8c39a3f39d14a8d7ae85bce44e45211852bc3") {
		for (let $i = 0; $i < 4; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "e8f9fddb72ef2a0000b5facfd3e8c39a3f39d14a8d7ae85bce44e45211852bc3";
	}
	let t0;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-12 w-full rounded-xl" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 473,
			columnNumber: 10
		}, this);
		$[1] = t0;
	} else {
		t0 = $[1];
	}
	let t1;
	if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-6 lg:col-span-7",
			children: [/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-64 w-full rounded-xl" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 480,
				columnNumber: 52
			}, this), /* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-44 w-full rounded-xl" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 480,
				columnNumber: 99
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 480,
			columnNumber: 10
		}, this);
		$[2] = t1;
	} else {
		t1 = $[2];
	}
	let t2;
	if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV("main", {
			id: "main-content",
			"aria-busy": "true",
			"aria-label": "Carregando checkout",
			className: "mx-auto grid w-full max-w-6xl gap-6 px-4 py-6 sm:px-6 md:py-10 lg:px-8",
			children: [t0, /* @__PURE__ */ _jsxDEV("div", {
				className: "grid gap-6 lg:grid-cols-12",
				children: [t1, /* @__PURE__ */ _jsxDEV("div", {
					className: "lg:col-span-5",
					children: /* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-96 w-full rounded-xl" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 487,
						columnNumber: 250
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 487,
					columnNumber: 219
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 487,
				columnNumber: 171
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 487,
			columnNumber: 10
		}, this);
		$[3] = t2;
	} else {
		t2 = $[3];
	}
	return t2;
}
_c3 = CheckoutSkeleton;
export { CheckoutPage as component };
var _c2, _c3;
$RefreshReg$(_c2, "CheckoutPage");
$RefreshReg$(_c3, "CheckoutSkeleton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/_authenticated/checkout.tsx?tsr-split=component";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated/checkout.tsx?tsr-split=component", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated/checkout.tsx?tsr-split=component", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated/checkout.tsx?tsr-split=component" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLFdBQVdDLE9BQU9DLGdCQUFnQjtBQUMzQyxTQUEwQkMsTUFBTUMsaUJBQWlCO0FBQ2pELFNBQ0VDLGFBQ0FDLFdBQ0FDLGNBQ0FDLE9BQ0FDLGFBQ0FDLFdBQ0FDLGFBQ0FDLGFBQ0FDLFVBQ0FDLFVBQVVDLFlBQ1ZDLFdBQ0s7QUFDUCxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLG9CQUFvQjtBQUM3QixTQUFTQyxPQUFPQyxrQkFBa0JDLGtCQUFrQjtBQUNwRCxTQUNFQyxhQUNBQyxtQkFDQUMsbUJBQ0FDLG9CQUNBQyx3QkFDQUMsbUJBQ0FDLG1CQUNBQyx3QkFDSztBQUNQLFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsUUFBUUMsc0JBQXNCO0FBQ3ZDLFNBQ0VDLE1BQ0FDLGFBQ0FDLGlCQUNBQyxZQUNBQyxZQUNBQyxpQkFDSztBQUNQLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLFlBQVlDLHNCQUFzQjtBQUMzQyxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGNBQWM7QUFDdkIsU0FBeUJDLGFBQWE7QUFDdEMsU0FBMkJDLGVBQWU7QUFDMUMsU0FBU0MsZ0JBQWdCQywyQkFBMkI7QUFDcEQsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLGlCQUFpQkMsc0JBQXNCO0FBQ2hELFNBQVNDLHFCQUFxQkMsWUFBWUMsV0FBV0MsYUFBYUMsbUJBQW1CO0FBQ3JGLFNBQVNDLFVBQVU7Ozs7QUFVbkIsU0FBU0MsZUFBZTs7Q0FDdEIsTUFBTUMsU0FBU3hELFVBQVU7Q0FDekIsTUFBTSxFQUFFeUQsTUFBTUMsTUFBTUMsV0FBV0MsZUFBZUMsU0FBU0MsYUFBYUMsT0FBT0MsY0FBY3JCLFFBQVE7Q0FDakcsTUFBTSxFQUFFYyxNQUFNUSxNQUFNTixXQUFXTyxrQkFBa0J4QixNQUFNO0NBQ3ZELE1BQU15QixtQkFBbUJ0QixvQkFBb0I7Q0FDN0MsTUFBTXVCLGNBQWN4QixlQUFlO0NBQ25DLE1BQU0sRUFBRXlCLGlCQUFpQkMsc0JBQXNCQyw4QkFBOEJ6QixVQUFVOztDQUd2RixNQUFNLENBQUMwQixnQkFBZ0JDLHFCQUFxQjNFLGVBQXVCNEUsT0FBT0MsV0FBVyxDQUFDO0NBQ3RGLE1BQU0sQ0FBQ0MsaUJBQWlCQyxzQkFBc0IvRSxTQUFtQixFQUFFO0NBQ25FLE1BQU0sQ0FBQ2dGLGdCQUFnQkMscUJBQXFCakYsU0FBaUIsRUFBRTtDQUMvRCxNQUFNLENBQUNrRixzQkFBc0JDLDJCQUEyQm5GLFNBQVMsS0FBSztDQUN0RSxNQUFNLENBQUNvRixjQUFjQyxtQkFBbUJyRixTQUFTLEtBQUs7Q0FDdEQsTUFBTXNGLGtCQUFrQnZGLE1BQU07Q0FDOUIsTUFBTXdGLGdCQUFnQnhGLE1BQU07O0NBRzVCRCxnQkFBZ0I7RUFDZHVFLGlCQUFpQm1CLE9BQU87O0NBRTFCLEdBQUcsRUFBRTtDQUVMLElBQUkxQixpQkFBaUJNLGVBQWU7RUFDbEMsT0FBTyx3QkFBQyxrQkFBRCxDQUFpQjs7Ozs7Q0FDMUI7Q0FFQSxJQUFJSixlQUFlLENBQUNKLFFBQVEsQ0FBQ08sTUFBTTtFQUNqQyxPQUNFLHdCQUFDLFFBQUQ7R0FBTSxJQUFHO0dBQWUsV0FBVTthQUNoQyx3QkFBQyxPQUFEO0lBQU8sU0FBUTtJQUFjLE1BQUs7Y0FBbEM7S0FDRSx3QkFBQyxhQUFEO01BQWEsV0FBVTtNQUFTLGVBQVk7S0FBTTs7Ozs7S0FDbEQsd0JBQUMsWUFBRCxZQUFZLHFDQUE4Qzs7Ozs7S0FDMUQsd0JBQUMsa0JBQUQsWUFBbUJsQixnQkFBZ0JpQixTQUFTLEVBQW9COzs7OztJQUMzRDs7Ozs7O0VBQ0g7Ozs7O0NBRVY7Q0FFQSxJQUFJTixLQUFLNkIsTUFBTUMsV0FBVyxLQUFLLENBQUNOLGNBQWM7RUFDNUMsT0FDRSx3QkFBQyxRQUFEO0dBQU0sSUFBRztHQUFlLFdBQVU7YUFDaEMsd0JBQUMsTUFBRDtJQUFNLFdBQVU7Y0FDZCx3QkFBQyxhQUFEO0tBQWEsV0FBVTtlQUF2QjtNQUNFLHdCQUFDLGFBQUQ7T0FBYSxXQUFVO09BQWdDLGVBQVk7TUFBTTs7Ozs7TUFDekUsd0JBQUMsTUFBRDtPQUFJLFdBQVU7aUJBQXdCO01BQXlDOzs7OztNQUMvRSx3QkFBQyxLQUFEO09BQUcsV0FBVTtpQkFBMEM7TUFFcEQ7Ozs7O01BQ0gsd0JBQUMsTUFBRDtPQUFNLElBQUc7T0FBSSxXQUFXNUIsR0FBRzFCLGVBQWUsRUFBRTZELFNBQVMsVUFBVSxDQUFDLENBQUM7aUJBQUU7TUFFN0Q7Ozs7O0tBQ0s7Ozs7OztHQUNUOzs7OztFQUNGOzs7OztDQUVWOztDQUdBLE1BQU1DLDJCQUNKckIsbUJBQW1CWCxLQUFLNkIsTUFBTUksTUFBTUMsU0FBU0EsS0FBS0MsVUFBVXhCLGdCQUFnQndCLEtBQUssSUFDN0V4QixrQkFDQTtDQUVOLE1BQU15QixzQkFBc0JoQixrQkFBa0JiLEtBQUs4QixRQUFRLEVBQUUsRUFBRUMsV0FBVztDQUMxRSxNQUFNQyxnQkFBZ0J2QyxLQUFLNkIsTUFBTVcsUUFBUU4sU0FBUyxDQUFDaEIsZ0JBQWdCdUIsU0FBU1AsS0FBS1EsRUFBRSxDQUFDO0NBQ3BGLE1BQU1DLFNBQVNwRCxvQkFBb0JnRCxlQUFldkMsS0FBSzRDLGVBQWU7Q0FDdEUsTUFBTUMsdUJBQXVCckQsV0FBV2UsS0FBS3VDLFlBQVlILE9BQU9JLFFBQVEsS0FBSztDQUM3RSxNQUFNQyxzQkFBc0JILHVCQUN4QmxELFlBQVlZLEtBQUt1QyxZQUFZSCxPQUFPSSxRQUFRLElBQzVDeEMsS0FBS3VDO0NBRVQsTUFBTUcsMkNBQTJDO0VBQy9DckMscUJBQXFCO0VBQ3JCYSxnQkFBZ0IsS0FBSztFQUNyQlYsa0JBQWtCQyxPQUFPQyxXQUFXLENBQUM7RUFDckNSLGlCQUFpQm1CLE9BQU87Q0FDMUI7Q0FFQSxNQUFNc0IsdUJBQXVCQyxRQUFnQkMsWUFBcUI7RUFDaEVqQyxvQkFBb0JrQyxTQUNsQkQsVUFBVUMsS0FBS2IsUUFBUUUsT0FBT0EsT0FBT1MsTUFBTSxJQUFJLENBQUMsR0FBR0UsTUFBTUYsTUFBTSxDQUNqRTtFQUNBLElBQUksQ0FBQzNCLGNBQWM7R0FDakJULGtCQUFrQkMsT0FBT0MsV0FBVyxDQUFDO0VBQ3ZDO0NBQ0Y7Q0FFQSxNQUFNcUMsc0JBQXNCQyxVQUFVLFVBQVU7RUFDOUMsSUFBSXZCLDBCQUEwQjtHQUM1QjdFLE1BQU1rRCxNQUNKLDBGQUNGO0dBQ0E7RUFDRjtFQUVBLElBQUlrQyxjQUFjVCxXQUFXLEtBQUssQ0FBQ04sY0FBYztHQUMvQ3JFLE1BQU1rRCxNQUFNLHFEQUFxRDtHQUNqRTtFQUNGO0VBRUEsTUFBTW1ELDBCQUEwQmxDLHdCQUF3QixDQUFDRSxnQkFBZ0IsQ0FBQytCO0VBRTFFN0MsWUFBWWtCLE9BQ1Y7R0FDRTZCLFNBQVM7SUFDUEMsU0FBU25CLGNBQWNvQixLQUFLQyxNQUFNQSxFQUFFbEIsRUFBRTtJQUN0Q21CLGVBQWV6QjtJQUNmMEIsWUFBWTlELEtBQUs4RDtJQUNqQmhEO0dBQ0Y7R0FDQWlELFdBQVdQLDBCQUEwQixPQUFPO0VBQzlDLEdBQ0E7R0FDRVEsWUFBWUMsVUFBVTtJQUNwQjlHLE1BQU0rRyxRQUNKMUMsZUFDSSxXQUFXeUMsTUFBTXZCLEdBQUUsd0RBQ25CLGlDQUFpQ3VCLE1BQU12QixHQUFFLFlBQy9DO0lBQ0EsS0FBSzVDLE9BQU9xRSxTQUFTO0tBQ25CQyxJQUFJO0tBQ0pDLFFBQVEsRUFBRUMsU0FBU0wsTUFBTXZCLEdBQUc7SUFDOUIsQ0FBQztHQUNIO0dBQ0E2QixVQUFVbEUsVUFBVTtJQUNsQixJQUFJZixlQUFlZSxLQUFLLEdBQUc7S0FDekJvQixnQkFBZ0IsSUFBSTtLQUNwQnRFLE1BQU1xSCxRQUNKLDZGQUNGO0lBQ0YsT0FBTztLQUNMckgsTUFBTWtELE1BQU1oQixnQkFBZ0JnQixLQUFLLENBQUM7S0FDbENJLGlCQUFpQm1CLE9BQU87SUFDMUI7R0FDRjtFQUNGLENBQ0Y7Q0FDRjtDQUVBLE1BQU02QyxtQkFBbUJoRSxpQkFBaUJWLE1BQU0yRSxVQUFVO0NBQzFELE1BQU1DLGtCQUFrQnBDLGNBQWMsRUFBRSxFQUFFSixTQUFTbkMsS0FBSzZCLE1BQU0sRUFBRSxFQUFFTTtDQUVsRSxPQUNFLHdCQUFDLFFBQUQ7RUFDRSxJQUFHO0VBQ0gsVUFBVSxDQUFDO0VBQ1gsV0FBVTtZQUhaO0dBTUUsd0JBQUMsYUFBRDtJQUNFLE1BQU15QyxRQUFRNUMsd0JBQXdCO0lBQ3RDLGVBQWU2QyxTQUFTO0tBQ3RCLElBQUksQ0FBQ0EsTUFBTTVCLG1DQUFtQztJQUNoRDtjQUVBLHdCQUFDLG9CQUFELGFBQ0Usd0JBQUMsbUJBQUQsYUFDRSx3QkFBQyxrQkFBRCxZQUFrQiwwQ0FBeUQ7Ozs7Y0FDM0Usd0JBQUMsd0JBQUQsWUFDR2pCLDRCQUNDO0tBQUE7S0FDUSx3QkFBQyxVQUFELFlBQVNBLHlCQUF5QjhDLEtBQWE7Ozs7O0tBQUM7S0FDUjtLQUM5Qyx3QkFBQyxVQUFEO01BQVEsV0FBVTtnQkFBbEIsQ0FDR3JGLFVBQVV1Qyx5QkFBeUIrQyxXQUFXLEdBQUUsTUFDM0M7Ozs7OztLQUFFO0tBQUc7S0FDUjtLQUNMLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO2dCQUFsQixDQUNHdEYsVUFBVXVDLHlCQUF5QmdELFdBQVcsR0FBRSxNQUMzQzs7Ozs7O0tBQUE7SUFFVjs7OzthQUVvQjs7OztZQUNQOzs7O2NBQ25CLHdCQUFDLG1CQUFELGFBQ0Usd0JBQUMsbUJBQUQ7S0FDRSxlQUFlO01BQ2JwRSxxQkFBcUI7TUFDckIsS0FBS2QsT0FBT3FFLFNBQVMsRUFBRUMsSUFBSSxRQUFRLENBQUM7S0FDdEM7ZUFBRTtJQUdlOzs7O2NBQ25CLHdCQUFDLG1CQUFEO0tBQW1CLFNBQVNuQjtlQUFtQztJQUU1Qzs7OztZQUNGOzs7O1lBQ0Q7Ozs7O0dBQ1Q7Ozs7O0dBRWIsd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsTUFBRDtLQUFJLFdBQVU7ZUFBZ0Q7SUFBaUI7Ozs7Y0FDL0Usd0JBQUMsS0FBRDtLQUFHLFdBQVU7ZUFBMEM7SUFFcEQ7Ozs7WUFDQTs7OztjQUVMLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxRQUFEO01BQ0UsTUFBSztNQUNMLFNBQVE7TUFDUixNQUFLO01BQ0wsVUFBVXhDLGlCQUFpQndFLGFBQWF2RSxZQUFZdUU7TUFDcEQsZUFBZXhFLGlCQUFpQm1CLE9BQU87Z0JBTHpDLENBT0Usd0JBQUMsV0FBRDtPQUNFLFdBQVdoQyxHQUNULFlBQ0FhLGlCQUFpQndFLGFBQWEseUNBQ2hDO09BQ0EsZUFBWTtNQUFNOzs7O2dCQUVwQix3QkFBQyxRQUFELFlBQU0sNkJBQWdDOzs7O2NBQ2hDOzs7OztlQUNSLHdCQUFDLE1BQUQ7TUFBTSxJQUFHO01BQVEsV0FBV3JGLEdBQUcxQixlQUFlO09BQUU2RCxTQUFTO09BQVNtRCxNQUFNO01BQUssQ0FBQyxDQUFDO2dCQUEvRSxDQUNFLHdCQUFDLFdBQUQ7T0FBVyxXQUFVO09BQVMsZUFBWTtNQUFNOzs7O2dCQUNoRCx3QkFBQyxRQUFELFlBQU0scUJBQXdCOzs7O2NBQzFCOzs7OzthQUNIOzs7OztZQUNDOzs7Ozs7R0FHUGxELDRCQUNDLHdCQUFDLE9BQUQ7SUFBTyxTQUFRO0lBQWMsTUFBSztjQUFsQztLQUNFLHdCQUFDLGFBQUQ7TUFBYSxXQUFVO01BQVMsZUFBWTtLQUFNOzs7OztLQUNsRCx3QkFBQyxZQUFELFlBQVksaUVBQTBFOzs7OztLQUN0Rix3QkFBQyxrQkFBRDtNQUFrQixXQUFVO2dCQUE1QixDQUNFLHdCQUFDLFFBQUQ7T0FBSztPQUNVLHdCQUFDLFVBQUQsWUFBU0EseUJBQXlCOEMsS0FBYTs7Ozs7T0FBQztPQUFVO09BQ3ZFLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUE2QnJGLFVBQVV1Qyx5QkFBeUIrQyxXQUFXLEdBQUUsTUFBVTs7Ozs7O09BQUU7T0FBRztPQUN2RjtPQUNMLHdCQUFDLFFBQUQ7UUFBTSxXQUFVO2tCQUFoQixDQUE2QnRGLFVBQVV1Qyx5QkFBeUJnRCxXQUFXLEdBQUUsTUFBVTs7Ozs7O09BQUM7TUFFcEY7Ozs7Z0JBQ04sd0JBQUMsUUFBRDtPQUNFLE1BQUs7T0FDTCxTQUFRO09BQ1IsTUFBSztPQUNMLFNBQVMvQjtpQkFBbUM7TUFHdEM7Ozs7Y0FDUTs7Ozs7O0lBQ2I7Ozs7OztHQUlSd0IsaUJBQWlCM0MsU0FBUyxLQUN6Qix3QkFBQyxPQUFEO0lBQU8sU0FBUTtJQUFjLE1BQUs7Y0FBbEM7S0FDRSx3QkFBQyxhQUFEO01BQWEsV0FBVTtNQUFTLGVBQVk7S0FBTTs7Ozs7S0FDbEQsd0JBQUMsWUFBRCxZQUFZLDBEQUFtRTs7Ozs7S0FDL0Usd0JBQUMsa0JBQUQsWUFDRSx3QkFBQyxNQUFEO01BQUksV0FBVTtnQkFDWDJDLGlCQUFpQmQsS0FBS3dCLE9BQU9DLFFBQzVCLHdCQUFDLE1BQUQsWUFBZUQsTUFBVSxHQUFoQkM7Ozs7YUFBZ0IsQ0FDMUI7S0FDQzs7OztjQUNZOzs7OztJQUNiOzs7Ozs7R0FJUjVELGdCQUNDLHdCQUFDLE9BQUQ7SUFBTyxNQUFLO0lBQVEsV0FBVTtjQUE5QjtLQUNFLHdCQUFDLE9BQUQ7TUFBTyxXQUFVO01BQXNCLGVBQVk7S0FBTTs7Ozs7S0FDekQsd0JBQUMsWUFBRCxZQUFZLHFEQUE4RDs7Ozs7S0FDMUUsd0JBQUMsa0JBQUQ7TUFBa0IsV0FBVTtnQkFBNUIsQ0FDRSx3QkFBQyxRQUFEO09BQU0sV0FBVTtpQkFBaEI7UUFBeUI7UUFDNkI7UUFDcEQsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQTJCVjtRQUFxQjs7Ozs7UUFBQztPQUU3RDs7Ozs7Z0JBQ04sd0JBQUMsUUFBRDtPQUNFLE1BQUs7T0FDTCxNQUFLO09BQ0wsVUFBVUosWUFBWXVFLGFBQWFMLFFBQVE1Qyx3QkFBd0I7T0FDbkUsZUFBZXNCLG1CQUFtQixJQUFJO2lCQUp4QyxDQU1FLHdCQUFDLFdBQUQ7UUFBVyxXQUFVO1FBQVcsZUFBWTtPQUFNOzs7O2lCQUNsRCx3QkFBQyxRQUFELFlBQU0sNkJBQWdDOzs7O2VBQ2hDOzs7OztjQUNROzs7Ozs7SUFDYjs7Ozs7O0dBR1Qsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FFRSx3QkFBQyxNQUFELGFBQ0Usd0JBQUMsWUFBRCxhQUNFLHdCQUFDLFdBQUQ7TUFBVyxNQUFLO01BQVUsY0FBWTtNQUFHLFdBQVU7Z0JBQW5EO09BQThEO09BQzdCZixjQUFjVDtPQUFPO09BQUs5QixLQUFLNkIsTUFBTUM7T0FBTztNQUNsRTs7Ozs7ZUFDWCx3QkFBQyxpQkFBRCxZQUFnQiw4RkFHQzs7OzthQUNQOzs7O2VBQ1osd0JBQUMsYUFBRDtNQUFhLFdBQVU7Z0JBQ3BCOUIsS0FBSzZCLE1BQU04QixLQUFLekIsU0FBUztPQUN4QixNQUFNbUQsWUFBWSxDQUFDbkUsZ0JBQWdCdUIsU0FBU1AsS0FBS1EsRUFBRTtPQUNuRCxNQUFNNEMsYUFBYSxpQkFBaUJwRCxLQUFLUTtPQUN6QyxNQUFNNkMsZUFBZTdGLFlBQVl3QyxLQUFLc0QsVUFBVXRELEtBQUt1RCxRQUFRO09BRTdELE9BQ0Usd0JBQUMsT0FBRDtRQUVFLFdBQVc3RixHQUNULG1GQUNBeUYsWUFBWSxZQUFZLHdCQUMxQjtrQkFMRixDQU9FLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmO1VBQ0Usd0JBQUMsVUFBRDtXQUNFLElBQUlDO1dBQ0osU0FBU0Q7V0FDVCxVQUFVM0UsWUFBWXVFLGFBQWF6RDtXQUNuQyxrQkFBa0I0QixZQUNoQkYsb0JBQW9CaEIsS0FBS1EsSUFBSWtDLFFBQVF4QixPQUFPLENBQUM7VUFDOUM7Ozs7O1VBRUgsd0JBQUMsT0FBRDtXQUNFLEtBQUtsQixLQUFLd0Q7V0FDVixLQUFLLFlBQVl4RCxLQUFLNEMsS0FBSSxjQUFlNUMsS0FBS3lEO1dBQzlDLFNBQVE7V0FDUixVQUFTO1dBQ1QsV0FBVTtVQUFtRDs7Ozs7VUFFL0Qsd0JBQUMsT0FBRDtXQUFPLFNBQVNMO1dBQVksV0FBVTtxQkFBdEMsQ0FDRSx3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFBa0NwRCxLQUFLNEM7V0FBVzs7OztxQkFDbEUsd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWhCO2FBQ0c1QyxLQUFLdUQ7YUFBUzthQUFHaEcsVUFBVXlDLEtBQUtzRCxRQUFRO2FBQUU7WUFDdkM7Ozs7O21CQUNEOzs7Ozs7U0FDSjs7Ozs7a0JBRUwsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQ0cvRixVQUFVOEYsWUFBWSxHQUFFLE1BQ3JCOzs7OztnQkFDSDtVQWpDRXJELEtBQUtROzs7O2NBaUNQO01BRVQsQ0FBQztLQUNVOzs7O2FBQ1Q7Ozs7ZUFHTix3QkFBQyxNQUFELGFBQ0Usd0JBQUMsWUFBRCxhQUNFLHdCQUFDLFdBQUQ7TUFBVyxNQUFLO01BQVUsY0FBWTtNQUFHLFdBQVU7Z0JBQVc7S0FFbkQ7Ozs7ZUFDWCx3QkFBQyxpQkFBRCxZQUFnQiwrREFFQzs7OzthQUNQOzs7O2VBQ1osd0JBQUMsYUFBRDtNQUFhLFdBQVU7Z0JBQ3BCbkMsS0FBSzhCLFFBQVFQLFdBQVcsSUFDdkIsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQWYsQ0FDRSx3QkFBQyxRQUFEO1FBQU0sV0FBVTtrQkFBK0I7T0FFekM7Ozs7aUJBQ04sd0JBQUMsTUFBRDtRQUNFLElBQUc7UUFDSCxXQUFXbEMsR0FBRzFCLGVBQWU7U0FBRTZELFNBQVM7U0FBV21ELE1BQU07UUFBSyxDQUFDLENBQUM7a0JBQUU7T0FHOUQ7Ozs7ZUFDSDs7Ozs7aUJBRUwsd0JBQUMsWUFBRDtPQUNFLE9BQU85QztPQUNQLGdCQUFnQndELFFBQVE7UUFDdEIsSUFBSUEsS0FBS3ZFLGtCQUFrQnVFLEdBQUc7T0FDaEM7aUJBRUNyRixLQUFLOEIsUUFBUXNCLEtBQUtrQyxNQUFNO1FBQ3ZCLE1BQU1DLFVBQVUsVUFBVUQsRUFBRW5EO1FBQzVCLE9BQ0Usd0JBQUMsT0FBRDtTQUVFLFdBQVU7bUJBRVYsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxnQkFBRDtXQUFnQixPQUFPbUQsRUFBRXZEO1dBQVMsSUFBSXdEO1VBQVE7Ozs7b0JBQzlDLHdCQUFDLE9BQUQ7V0FBTyxTQUFTQTtXQUFTLFdBQVU7cUJBQW5DLENBQ0Usd0JBQUMsUUFBRDtZQUFNLFdBQVU7c0JBQWhCLENBQ0Usd0JBQUMsWUFBRDthQUFZLFdBQVU7YUFBd0IsZUFBWTtZQUFNOzs7O3NCQUNoRSx3QkFBQyxRQUFELFlBQU9ELEVBQUVFLE1BQVk7Ozs7b0JBQ2pCOzs7OztxQkFDTix3QkFBQyxRQUFEO1lBQU0sV0FBVTtzQkFDYkYsRUFBRXZEO1dBQ0M7Ozs7bUJBQ0Q7Ozs7O2tCQUNKOzs7Ozs7UUFDRixHQWZFdUQsRUFBRW5EOzs7O2VBZUo7T0FFVCxDQUFDO01BQ1M7Ozs7O0tBRUg7Ozs7YUFDVDs7OzthQUNIOzs7OztjQUdMLHdCQUFDLFNBQUQ7S0FBTyxjQUFXO0tBQTBCLFdBQVU7ZUFDcEQsd0JBQUMsTUFBRDtNQUNFLHdCQUFDLFlBQUQ7T0FBWSxXQUFVO2lCQUNwQix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFdBQUQ7U0FBVyxNQUFLO1NBQVUsY0FBWTtTQUFHLFdBQVU7bUJBQVc7UUFFbkQ7Ozs7a0JBQ1gsd0JBQUMsT0FBRDtTQUFPLFNBQVE7U0FBVSxXQUFVO21CQUFuQyxDQUNFLHdCQUFDLGNBQUQ7VUFBYyxXQUFVO1VBQXNCLGVBQVk7U0FBTTs7OzttQkFDaEUsd0JBQUMsUUFBRCxZQUFNLGNBQWlCOzs7O2lCQUNsQjs7Ozs7Z0JBQ0o7Ozs7OztNQUNLOzs7OztNQUVaLHdCQUFDLGFBQUQ7T0FBYSxXQUFVO2lCQUF2QjtRQUVFLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxhQUFEO1dBQWEsV0FBVTtXQUF3QixlQUFZO1VBQU07Ozs7b0JBQ2pFLHdCQUFDLFFBQUQsWUFBTSwyQkFBOEI7Ozs7a0JBQ2pDOzs7OzttQkFDTCx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBdUM1QjtTQUFxQjs7OztpQkFDekU7Ozs7OztRQUdMLHdCQUFDLE9BQUQ7U0FBSyxXQUFVO21CQUFmLENBQ0Usd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQWYsQ0FDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE9BQUQ7WUFBTyxTQUFTWTtZQUFpQixXQUFVO3NCQUE0QjtXQUVoRTs7OztxQkFDUCx3QkFBQyxRQUFEO1lBQU0sSUFBSUM7WUFBZSxXQUFVO3NCQUF1QjtXQUVwRDs7OzttQkFDSDs7Ozs7b0JBQ0wsd0JBQUMsUUFBRDtXQUNFLElBQUlEO1dBQ0osb0JBQWtCQztXQUNsQixnQkFBYztXQUNkLFNBQVNMO1dBQ1QsVUFBVVosWUFBWXVFLGFBQWF6RDtXQUNuQyxrQkFBa0I0QixZQUFZN0Isd0JBQXdCcUQsUUFBUXhCLE9BQU8sQ0FBQztVQUFFOzs7O2tCQUV2RTs7Ozs7bUJBRUp1QixtQkFDQyxnREFDRSx3QkFBQyxXQUFELENBQVU7Ozs7bUJBQ1Ysd0JBQUMsUUFBRDtVQUNFLE1BQUs7VUFDTCxTQUFRO1VBQ1IsTUFBSztVQUNMLFVBQVVqRSxZQUFZdUU7VUFDdEIsZUFBZXBFLDBCQUEwQjhELGVBQWU7VUFDeEQsV0FBVTtvQkFOWixDQVFFLHdCQUFDLEtBQUQ7V0FBSyxXQUFVO1dBQXNCLGVBQVk7VUFBTTs7OztvQkFDdkQsd0JBQUMsUUFBRCxZQUFNLDJDQUE4Qzs7OztrQkFDOUM7Ozs7O2lCQUNWOzs7O2lCQUVDOzs7Ozs7UUFFTCx3QkFBQyxXQUFELENBQVU7Ozs7O1FBRVYsd0JBQUMsTUFBRDtTQUFJLFdBQVU7U0FBcUIsYUFBVTttQkFBN0M7VUFDRSx3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF3QjtXQUFtQjs7OztxQkFDekQsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQsQ0FDR2xGLFVBQVVjLEtBQUt1QyxVQUFVLEdBQUUsTUFDMUI7Ozs7O21CQUNEOzs7Ozs7VUFFTCx3QkFBQyxXQUFELEVBQVcsV0FBVSxPQUFNOzs7OztVQUUzQix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUF3QjtXQUF3Qjs7OztxQkFDOUQsd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQsQ0FBd0NyRCxVQUFVa0QsT0FBT3FELFdBQVcsR0FBRSxNQUFROzs7OzttQkFDM0U7Ozs7OztVQUVMLHdCQUFDLE9BQUQ7V0FBSyxXQUFVO3FCQUFmLENBQ0Usd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQsQ0FDRSx3QkFBQyxRQUFELFlBQU0sV0FBYzs7OztzQkFDbkJoRyxLQUFLOEQsY0FDSix3QkFBQyxPQUFEO2FBQU8sU0FBUTthQUFZLFdBQVU7dUJBQXJDO2NBQ0c5RCxLQUFLOEQ7Y0FBVztjQUFJOUQsS0FBSzRDO2NBQWdCO2FBQ3JDOzs7OztvQkFFUDs7Ozs7cUJBQ0osd0JBQUMsTUFBRDtZQUFJLFdBQVU7c0JBQWQ7YUFBdUM7YUFBR25ELFVBQVVrRCxPQUFPc0QsV0FBVzthQUFFO1lBQVE7Ozs7O21CQUM3RTs7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBd0I7V0FBK0I7Ozs7cUJBQ3JFLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFkLENBQXdDeEcsVUFBVWtELE9BQU91RCxNQUFNLEdBQUUsTUFBUTs7Ozs7bUJBQ3RFOzs7Ozs7VUFFTCx3QkFBQyxXQUFELEVBQVcsV0FBVSxPQUFNOzs7OztVQUUzQix3QkFBQyxPQUFEO1dBQUssV0FBVTtxQkFBZixDQUNFLHdCQUFDLE1BQUQsWUFBSSxnQkFBaUI7Ozs7cUJBQ3JCLHdCQUFDLE1BQUQ7WUFBSSxXQUFVO3NCQUFkLENBQ0Usd0JBQUMsVUFBRDthQUFVLFdBQVU7YUFBc0IsZUFBWTtZQUFNOzs7O3NCQUM1RCx3QkFBQyxRQUFELGFBQU96RyxVQUFVa0QsT0FBT0ksUUFBUSxHQUFFLE1BQVU7Ozs7b0JBQzFDOzs7OzttQkFDRDs7Ozs7O1VBRUwsd0JBQUMsT0FBRDtXQUFLLFdBQVU7cUJBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUksK0JBQWdDOzs7O3FCQUNwQyx3QkFBQyxNQUFEO1lBQUksV0FBVTtzQkFBZCxDQUF3Q3RELFVBQVV1RCxtQkFBbUIsR0FBRSxNQUFROzs7OzttQkFDNUU7Ozs7OztTQUNIOzs7Ozs7UUFFSCxDQUFDSCx3QkFBd0IsQ0FBQ3JCLGdCQUN6Qix3QkFBQyxPQUFEO1NBQU8sU0FBUTtTQUFjLE1BQUs7bUJBQWxDO1VBQ0Usd0JBQUMsYUFBRDtXQUFhLFdBQVU7V0FBUyxlQUFZO1VBQU07Ozs7O1VBQ2xELHdCQUFDLFlBQUQsWUFBWSxxQkFBOEI7Ozs7O1VBQzFDLHdCQUFDLGtCQUFEO1dBQWlCO1dBQ0kvQixVQUFVYyxLQUFLdUMsVUFBVTtXQUFFO1dBQ3JDckQsVUFBVWtELE9BQU9JLFFBQVE7V0FBRTtVQUNwQjs7Ozs7U0FDYjs7Ozs7O09BRUU7Ozs7OztNQUViLHdCQUFDLFlBQUQ7T0FBWSxXQUFVO2lCQUF0QixDQUNFLHdCQUFDLGNBQUQ7UUFDRSxNQUFLO1FBQ0wsTUFBSztRQUNMLFdBQVU7UUFDVixXQUFXckMsWUFBWXVFO1FBQ3ZCLGFBQVk7UUFDWixVQUNFTCxRQUFRNUMsd0JBQXdCLEtBQy9CLENBQUNhLHdCQUF3QixDQUFDckIsZ0JBQzFCZSxjQUFjVCxXQUFXLEtBQUssQ0FBQ047UUFFbEMsZUFBZThCLG1CQUFtQjlCLFlBQVk7a0JBRTdDQSxlQUNHLGtEQUNBO09BQ1E7Ozs7aUJBRWQsd0JBQUMsS0FBRDtRQUFHLFdBQVU7a0JBQWIsQ0FDRSx3QkFBQyxhQUFEO1NBQWEsV0FBVTtTQUF3QixlQUFZO1FBQU07Ozs7a0JBQ2pFLHdCQUFDLFFBQUQsWUFBTSx3REFBMkQ7Ozs7Z0JBQ2hFOzs7OztlQUNPOzs7Ozs7S0FDUjs7Ozs7SUFDRDs7OztZQUNKOzs7Ozs7RUFDRDs7Ozs7O0FBRVY7Ozs7Ozs7Ozs7OztBQUVBLFNBQUEyRSxtQkFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUwsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBUU1DLEtBQUEsd0JBQUMsVUFBRCxFQUFvQixvQ0FBd0I7Ozs7O0VBQUFMLEVBQUEsS0FBQUs7Q0FBQTtFQUFBQSxLQUFBTCxFQUFBO0NBQUE7Q0FBQSxJQUFBTTtDQUFBLElBQUFOLEVBQUEsT0FBQUcsT0FBQUMsSUFBQTtFQUUxQ0UsS0FBQTtHQUFlO2FBQWYsQ0FDRSx3QkFBQyxVQUFELEVBQW9CLG9DQUF3Qjs7OzthQUM1Qyx3QkFBQyxVQUFELEVBQW9CLG9DQUF3Qjs7OztXQUN6Qzs7Ozs7O0VBQUFOLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxJQUFBTztDQUFBLElBQUFQLEVBQUEsT0FBQUcsT0FBQUMsSUFBQTtFQVhURyxLQUFBO0dBQ0s7R0FDTztHQUNDO0dBQ0Q7YUFKWixDQU1FRixJQUNBO0lBQWU7Y0FBZixDQUNFQyxJQUlBO0tBQWU7ZUFDYix3QkFBQyxVQUFELEVBQW9CLG9DQUF3Qjs7Ozs7SUFDekM7Ozs7WUFDRjs7Ozs7V0FDQTs7Ozs7O0VBQUFOLEVBQUEsS0FBQU87Q0FBQTtFQUFBQSxLQUFBUCxFQUFBO0NBQUE7Q0FBQSxPQWhCUE87QUFnQk87O0FBRVYsU0FBQTlHLGdCQUFBK0ciLCJuYW1lcyI6WyJ1c2VFZmZlY3QiLCJ1c2VJZCIsInVzZVN0YXRlIiwiTGluayIsInVzZVJvdXRlciIsIkFsZXJ0Q2lyY2xlIiwiQXJyb3dMZWZ0IiwiQ2hlY2tDaXJjbGUyIiwiQ2xvY2siLCJGaW5nZXJwcmludCIsIlJlZnJlc2hDdyIsIlNoaWVsZENoZWNrIiwiU2hvcHBpbmdCYWciLCJTcGFya2xlcyIsIldhbGxldCIsIldhbGxldEljb24iLCJaYXAiLCJ0b2FzdCIsIlN1Ym1pdEJ1dHRvbiIsIkFsZXJ0IiwiQWxlcnREZXNjcmlwdGlvbiIsIkFsZXJ0VGl0bGUiLCJBbGVydERpYWxvZyIsIkFsZXJ0RGlhbG9nQWN0aW9uIiwiQWxlcnREaWFsb2dDYW5jZWwiLCJBbGVydERpYWxvZ0NvbnRlbnQiLCJBbGVydERpYWxvZ0Rlc2NyaXB0aW9uIiwiQWxlcnREaWFsb2dGb290ZXIiLCJBbGVydERpYWxvZ0hlYWRlciIsIkFsZXJ0RGlhbG9nVGl0bGUiLCJCYWRnZSIsIkJ1dHRvbiIsImJ1dHRvblZhcmlhbnRzIiwiQ2FyZCIsIkNhcmRDb250ZW50IiwiQ2FyZERlc2NyaXB0aW9uIiwiQ2FyZEZvb3RlciIsIkNhcmRIZWFkZXIiLCJDYXJkVGl0bGUiLCJDaGVja2JveCIsIkxhYmVsIiwiUmFkaW9Hcm91cCIsIlJhZGlvR3JvdXBJdGVtIiwiU2VwYXJhdG9yIiwiU2tlbGV0b24iLCJTd2l0Y2giLCJ1c2VNZSIsInVzZUNhcnQiLCJ1c2VDcmVhdGVPcmRlciIsInVzZVZhbGlkYXRlQ2hlY2tvdXQiLCJ1c2VTb2NrZXQiLCJnZXRFcnJvck1lc3NhZ2UiLCJpc1RpbWVvdXRFcnJvciIsImNhbGN1bGF0ZUNhcnRUb3RhbHMiLCJjb21wYXJlRXRoIiwiZm9ybWF0RXRoIiwibXVsdGlwbHlFdGgiLCJzdWJ0cmFjdEV0aCIsImNuIiwiQ2hlY2tvdXRQYWdlIiwicm91dGVyIiwiZGF0YSIsImNhcnQiLCJpc0xvYWRpbmciLCJpc0NhcnRMb2FkaW5nIiwiaXNFcnJvciIsImlzQ2FydEVycm9yIiwiZXJyb3IiLCJjYXJ0RXJyb3IiLCJ1c2VyIiwiaXNVc2VyTG9hZGluZyIsInZhbGlkYXRlQ2hlY2tvdXQiLCJjcmVhdGVPcmRlciIsImxhdGVzdE5mdFVwZGF0ZSIsImNsZWFyTGF0ZXN0TmZ0VXBkYXRlIiwidHJpZ2dlclNpbXVsYXRlZE5mdFVwZGF0ZSIsImlkZW1wb3RlbmN5S2V5Iiwic2V0SWRlbXBvdGVuY3lLZXkiLCJjcnlwdG8iLCJyYW5kb21VVUlEIiwiZXhjbHVkZWRJdGVtSWRzIiwic2V0RXhjbHVkZWRJdGVtSWRzIiwic2VsZWN0ZWRXYWxsZXQiLCJzZXRTZWxlY3RlZFdhbGxldCIsInNpbXVsYXRlRmlyc3RUaW1lb3V0Iiwic2V0U2ltdWxhdGVGaXJzdFRpbWVvdXQiLCJ0aW1lZE91dE9uY2UiLCJzZXRUaW1lZE91dE9uY2UiLCJ0aW1lb3V0U3dpdGNoSWQiLCJ0aW1lb3V0SGludElkIiwibXV0YXRlIiwiaXRlbXMiLCJsZW5ndGgiLCJ2YXJpYW50IiwiaW50ZXJydXB0ZWRCeVNvY2tldEV2ZW50Iiwic29tZSIsIml0ZW0iLCJuZnRJZCIsImFjdGl2ZVdhbGxldEFkZHJlc3MiLCJ3YWxsZXRzIiwiYWRkcmVzcyIsInNlbGVjdGVkSXRlbXMiLCJmaWx0ZXIiLCJpbmNsdWRlcyIsImlkIiwidG90YWxzIiwiZGlzY291bnRQZXJjZW50IiwiaGFzU3VmZmljaWVudEJhbGFuY2UiLCJiYWxhbmNlRXRoIiwidG90YWxFdGgiLCJyZW1haW5pbmdCYWxhbmNlRXRoIiwiaGFuZGxlQWNrbm93bGVkZ2VTb2NrZXRQcmljZUNoYW5nZSIsInRvZ2dsZUl0ZW1TZWxlY3Rpb24iLCJpdGVtSWQiLCJjaGVja2VkIiwicHJldiIsImhhbmRsZUNvbmZpcm1PcmRlciIsImlzUmV0cnkiLCJzaG91bGRGb3JjZVNob3J0VGltZW91dCIsInBheWxvYWQiLCJpdGVtSWRzIiwibWFwIiwiaSIsIndhbGxldEFkZHJlc3MiLCJjb3Vwb25Db2RlIiwidGltZW91dE1zIiwib25TdWNjZXNzIiwib3JkZXIiLCJzdWNjZXNzIiwibmF2aWdhdGUiLCJ0byIsInBhcmFtcyIsIm9yZGVySWQiLCJvbkVycm9yIiwid2FybmluZyIsInZhbGlkYXRpb25Jc3N1ZXMiLCJpc3N1ZXMiLCJ0YXJnZXRDYXJ0TmZ0SWQiLCJCb29sZWFuIiwib3BlbiIsIm5hbWUiLCJvbGRQcmljZUV0aCIsIm5ld1ByaWNlRXRoIiwiaXNQZW5kaW5nIiwic2l6ZSIsImlzc3VlIiwiaWR4IiwiaXNDaGVja2VkIiwiY2hlY2tib3hJZCIsImxpbmVUb3RhbEV0aCIsInByaWNlRXRoIiwicXVhbnRpdHkiLCJpbWFnZVVybCIsImNvbGxlY3Rpb24iLCJ2YWwiLCJ3IiwicmFkaW9JZCIsImxhYmVsIiwic3VidG90YWxFdGgiLCJkaXNjb3VudEV0aCIsImZlZUV0aCIsIkNoZWNrb3V0U2tlbGV0b24iLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsInQwIiwidDEiLCJ0MiIsImNvbXBvbmVudCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJjaGVja291dC50c3g/dHNyLXNwbGl0PWNvbXBvbmVudCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZUlkLCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgY3JlYXRlRmlsZVJvdXRlLCBMaW5rLCB1c2VSb3V0ZXIgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHtcbiAgQWxlcnRDaXJjbGUsXG4gIEFycm93TGVmdCxcbiAgQ2hlY2tDaXJjbGUyLFxuICBDbG9jayxcbiAgRmluZ2VycHJpbnQsXG4gIFJlZnJlc2hDdyxcbiAgU2hpZWxkQ2hlY2ssXG4gIFNob3BwaW5nQmFnLFxuICBTcGFya2xlcyxcbiAgV2FsbGV0IGFzIFdhbGxldEljb24sXG4gIFphcCxcbn0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdzb25uZXInXG5pbXBvcnQgeyBTdWJtaXRCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvZm9ybS9zdWJtaXQtYnV0dG9uJ1xuaW1wb3J0IHsgQWxlcnQsIEFsZXJ0RGVzY3JpcHRpb24sIEFsZXJ0VGl0bGUgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYWxlcnQnXG5pbXBvcnQge1xuICBBbGVydERpYWxvZyxcbiAgQWxlcnREaWFsb2dBY3Rpb24sXG4gIEFsZXJ0RGlhbG9nQ2FuY2VsLFxuICBBbGVydERpYWxvZ0NvbnRlbnQsXG4gIEFsZXJ0RGlhbG9nRGVzY3JpcHRpb24sXG4gIEFsZXJ0RGlhbG9nRm9vdGVyLFxuICBBbGVydERpYWxvZ0hlYWRlcixcbiAgQWxlcnREaWFsb2dUaXRsZSxcbn0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2FsZXJ0LWRpYWxvZydcbmltcG9ydCB7IEJhZGdlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2JhZGdlJ1xuaW1wb3J0IHsgQnV0dG9uLCBidXR0b25WYXJpYW50cyB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQge1xuICBDYXJkLFxuICBDYXJkQ29udGVudCxcbiAgQ2FyZERlc2NyaXB0aW9uLFxuICBDYXJkRm9vdGVyLFxuICBDYXJkSGVhZGVyLFxuICBDYXJkVGl0bGUsXG59IGZyb20gJ0AvY29tcG9uZW50cy91aS9jYXJkJ1xuaW1wb3J0IHsgQ2hlY2tib3ggfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvY2hlY2tib3gnXG5pbXBvcnQgeyBMYWJlbCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9sYWJlbCdcbmltcG9ydCB7IFJhZGlvR3JvdXAsIFJhZGlvR3JvdXBJdGVtIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3JhZGlvLWdyb3VwJ1xuaW1wb3J0IHsgU2VwYXJhdG9yIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NlcGFyYXRvcidcbmltcG9ydCB7IFNrZWxldG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NrZWxldG9uJ1xuaW1wb3J0IHsgU3dpdGNoIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3N3aXRjaCdcbmltcG9ydCB7IG1lUXVlcnlPcHRpb25zLCB1c2VNZSB9IGZyb20gJ0AvaG9va3MvdXNlLWF1dGgnXG5pbXBvcnQgeyBjYXJ0UXVlcnlPcHRpb25zLCB1c2VDYXJ0IH0gZnJvbSAnQC9ob29rcy91c2UtY2FydCdcbmltcG9ydCB7IHVzZUNyZWF0ZU9yZGVyLCB1c2VWYWxpZGF0ZUNoZWNrb3V0IH0gZnJvbSAnQC9ob29rcy91c2Utb3JkZXJzJ1xuaW1wb3J0IHsgdXNlU29ja2V0IH0gZnJvbSAnQC9ob29rcy91c2Utc29ja2V0J1xuaW1wb3J0IHsgZ2V0RXJyb3JNZXNzYWdlLCBpc1RpbWVvdXRFcnJvciB9IGZyb20gJ0AvbGliL2FwaSdcbmltcG9ydCB7IGNhbGN1bGF0ZUNhcnRUb3RhbHMsIGNvbXBhcmVFdGgsIGZvcm1hdEV0aCwgbXVsdGlwbHlFdGgsIHN1YnRyYWN0RXRoIH0gZnJvbSAnQC9saWIvZXRoJ1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcblxuZXhwb3J0IGNvbnN0IFJvdXRlID0gY3JlYXRlRmlsZVJvdXRlKCcvX2F1dGhlbnRpY2F0ZWQvY2hlY2tvdXQnKSh7XG4gIGxvYWRlcjogKHsgY29udGV4dCB9KSA9PiB7XG4gICAgdm9pZCBjb250ZXh0LnF1ZXJ5Q2xpZW50LnByZWZldGNoUXVlcnkoY2FydFF1ZXJ5T3B0aW9ucylcbiAgICB2b2lkIGNvbnRleHQucXVlcnlDbGllbnQucHJlZmV0Y2hRdWVyeShtZVF1ZXJ5T3B0aW9ucylcbiAgfSxcbiAgY29tcG9uZW50OiBDaGVja291dFBhZ2UsXG59KVxuXG5mdW5jdGlvbiBDaGVja291dFBhZ2UoKSB7XG4gIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG4gIGNvbnN0IHsgZGF0YTogY2FydCwgaXNMb2FkaW5nOiBpc0NhcnRMb2FkaW5nLCBpc0Vycm9yOiBpc0NhcnRFcnJvciwgZXJyb3I6IGNhcnRFcnJvciB9ID0gdXNlQ2FydCgpXG4gIGNvbnN0IHsgZGF0YTogdXNlciwgaXNMb2FkaW5nOiBpc1VzZXJMb2FkaW5nIH0gPSB1c2VNZSgpXG4gIGNvbnN0IHZhbGlkYXRlQ2hlY2tvdXQgPSB1c2VWYWxpZGF0ZUNoZWNrb3V0KClcbiAgY29uc3QgY3JlYXRlT3JkZXIgPSB1c2VDcmVhdGVPcmRlcigpXG4gIGNvbnN0IHsgbGF0ZXN0TmZ0VXBkYXRlLCBjbGVhckxhdGVzdE5mdFVwZGF0ZSwgdHJpZ2dlclNpbXVsYXRlZE5mdFVwZGF0ZSB9ID0gdXNlU29ja2V0KClcblxuICAvLyBDaGF2ZSBkZSBpZGVtcG90w6puY2lhIGVzdMOhdmVsIHBvciBpbnRlbsOnw6NvIGRlIGNvbXByYSAocHJlc2VydmFkYSBlbSBjYXNvIGRlIHRpbWVvdXQhKVxuICBjb25zdCBbaWRlbXBvdGVuY3lLZXksIHNldElkZW1wb3RlbmN5S2V5XSA9IHVzZVN0YXRlPHN0cmluZz4oKCkgPT4gY3J5cHRvLnJhbmRvbVVVSUQoKSlcbiAgY29uc3QgW2V4Y2x1ZGVkSXRlbUlkcywgc2V0RXhjbHVkZWRJdGVtSWRzXSA9IHVzZVN0YXRlPHN0cmluZ1tdPihbXSlcbiAgY29uc3QgW3NlbGVjdGVkV2FsbGV0LCBzZXRTZWxlY3RlZFdhbGxldF0gPSB1c2VTdGF0ZTxzdHJpbmc+KCcnKVxuICBjb25zdCBbc2ltdWxhdGVGaXJzdFRpbWVvdXQsIHNldFNpbXVsYXRlRmlyc3RUaW1lb3V0XSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbdGltZWRPdXRPbmNlLCBzZXRUaW1lZE91dE9uY2VdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IHRpbWVvdXRTd2l0Y2hJZCA9IHVzZUlkKClcbiAgY29uc3QgdGltZW91dEhpbnRJZCA9IHVzZUlkKClcblxuICAvLyBWYWxpZGEgYXV0b21hdGljYW1lbnRlIHByZcOnbywgY3Vwb20gZSBkaXNwb25pYmlsaWRhZGUgbm8gTVNXIGFvIGFicmlyIG8gY2hlY2tvdXRcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICB2YWxpZGF0ZUNoZWNrb3V0Lm11dGF0ZSgpXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICB9LCBbXSlcblxuICBpZiAoaXNDYXJ0TG9hZGluZyB8fCBpc1VzZXJMb2FkaW5nKSB7XG4gICAgcmV0dXJuIDxDaGVja291dFNrZWxldG9uIC8+XG4gIH1cblxuICBpZiAoaXNDYXJ0RXJyb3IgfHwgIWNhcnQgfHwgIXVzZXIpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPG1haW4gaWQ9XCJtYWluLWNvbnRlbnRcIiBjbGFzc05hbWU9XCJteC1hdXRvIGdyaWQgdy1mdWxsIG1heC13LTN4bCBnYXAtNCBwLTQgbWQ6cHktMTBcIj5cbiAgICAgICAgPEFsZXJ0IHZhcmlhbnQ9XCJkZXN0cnVjdGl2ZVwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgIDxBbGVydFRpdGxlPkVycm8gYW8gY2FycmVnYXIgZGFkb3MgZG8gY2hlY2tvdXQ8L0FsZXJ0VGl0bGU+XG4gICAgICAgICAgPEFsZXJ0RGVzY3JpcHRpb24+e2dldEVycm9yTWVzc2FnZShjYXJ0RXJyb3IpfTwvQWxlcnREZXNjcmlwdGlvbj5cbiAgICAgICAgPC9BbGVydD5cbiAgICAgIDwvbWFpbj5cbiAgICApXG4gIH1cblxuICBpZiAoY2FydC5pdGVtcy5sZW5ndGggPT09IDAgJiYgIXRpbWVkT3V0T25jZSkge1xuICAgIHJldHVybiAoXG4gICAgICA8bWFpbiBpZD1cIm1haW4tY29udGVudFwiIGNsYXNzTmFtZT1cIm14LWF1dG8gZ3JpZCB3LWZ1bGwgbWF4LXctMnhsIGdhcC02IHB4LTQgcHktMTBcIj5cbiAgICAgICAgPENhcmQgY2xhc3NOYW1lPVwiYm9yZGVyLWRhc2hlZCB0ZXh0LWNlbnRlclwiPlxuICAgICAgICAgIDxDYXJkQ29udGVudCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGl0ZW1zLWNlbnRlciBnYXAtMyBweS0xMlwiPlxuICAgICAgICAgICAgPFNob3BwaW5nQmFnIGNsYXNzTmFtZT1cInNpemUtMTAgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtc2VtaWJvbGRcIj5OZW5odW0gaXRlbSBubyBjYXJyaW5obyBwYXJhIGNoZWNrb3V0PC9oMT5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIHNtOnRleHQtc21cIj5cbiAgICAgICAgICAgICAgQWRpY2lvbmUgTkZUcyBhbyBjYXJyaW5obyBhbnRlcyBkZSBpbmljaWFyIG8gcGFnYW1lbnRvLlxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgPExpbmsgdG89XCIvXCIgY2xhc3NOYW1lPXtjbihidXR0b25WYXJpYW50cyh7IHZhcmlhbnQ6ICdkZWZhdWx0JyB9KSl9PlxuICAgICAgICAgICAgICBFeHBsb3JhciBDYXTDoWxvZ29cbiAgICAgICAgICAgIDwvTGluaz5cbiAgICAgICAgICA8L0NhcmRDb250ZW50PlxuICAgICAgICA8L0NhcmQ+XG4gICAgICA8L21haW4+XG4gICAgKVxuICB9XG5cbiAgLy8gUmVncmEgNSAoRmFzZSA2KTogZGV0ZWN0YSBzZSBhbGd1bSBORlQgcHJlc2VudGUgbm8gY2FycmluaG8gc29mcmV1IGFsdGVyYcOnw6NvIGRlIHByZcOnbyB2aWEgU29ja2V0LklPXG4gIGNvbnN0IGludGVycnVwdGVkQnlTb2NrZXRFdmVudCA9XG4gICAgbGF0ZXN0TmZ0VXBkYXRlICYmIGNhcnQuaXRlbXMuc29tZSgoaXRlbSkgPT4gaXRlbS5uZnRJZCA9PT0gbGF0ZXN0TmZ0VXBkYXRlLm5mdElkKVxuICAgICAgPyBsYXRlc3ROZnRVcGRhdGVcbiAgICAgIDogbnVsbFxuXG4gIGNvbnN0IGFjdGl2ZVdhbGxldEFkZHJlc3MgPSBzZWxlY3RlZFdhbGxldCB8fCB1c2VyLndhbGxldHNbMF0/LmFkZHJlc3MgfHwgJydcbiAgY29uc3Qgc2VsZWN0ZWRJdGVtcyA9IGNhcnQuaXRlbXMuZmlsdGVyKChpdGVtKSA9PiAhZXhjbHVkZWRJdGVtSWRzLmluY2x1ZGVzKGl0ZW0uaWQpKVxuICBjb25zdCB0b3RhbHMgPSBjYWxjdWxhdGVDYXJ0VG90YWxzKHNlbGVjdGVkSXRlbXMsIGNhcnQuZGlzY291bnRQZXJjZW50KVxuICBjb25zdCBoYXNTdWZmaWNpZW50QmFsYW5jZSA9IGNvbXBhcmVFdGgodXNlci5iYWxhbmNlRXRoLCB0b3RhbHMudG90YWxFdGgpID49IDBcbiAgY29uc3QgcmVtYWluaW5nQmFsYW5jZUV0aCA9IGhhc1N1ZmZpY2llbnRCYWxhbmNlXG4gICAgPyBzdWJ0cmFjdEV0aCh1c2VyLmJhbGFuY2VFdGgsIHRvdGFscy50b3RhbEV0aClcbiAgICA6IHVzZXIuYmFsYW5jZUV0aFxuXG4gIGNvbnN0IGhhbmRsZUFja25vd2xlZGdlU29ja2V0UHJpY2VDaGFuZ2UgPSAoKSA9PiB7XG4gICAgY2xlYXJMYXRlc3ROZnRVcGRhdGUoKVxuICAgIHNldFRpbWVkT3V0T25jZShmYWxzZSlcbiAgICBzZXRJZGVtcG90ZW5jeUtleShjcnlwdG8ucmFuZG9tVVVJRCgpKVxuICAgIHZhbGlkYXRlQ2hlY2tvdXQubXV0YXRlKClcbiAgfVxuXG4gIGNvbnN0IHRvZ2dsZUl0ZW1TZWxlY3Rpb24gPSAoaXRlbUlkOiBzdHJpbmcsIGNoZWNrZWQ6IGJvb2xlYW4pID0+IHtcbiAgICBzZXRFeGNsdWRlZEl0ZW1JZHMoKHByZXYpID0+XG4gICAgICBjaGVja2VkID8gcHJldi5maWx0ZXIoKGlkKSA9PiBpZCAhPT0gaXRlbUlkKSA6IFsuLi5wcmV2LCBpdGVtSWRdLFxuICAgIClcbiAgICBpZiAoIXRpbWVkT3V0T25jZSkge1xuICAgICAgc2V0SWRlbXBvdGVuY3lLZXkoY3J5cHRvLnJhbmRvbVVVSUQoKSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVDb25maXJtT3JkZXIgPSAoaXNSZXRyeSA9IGZhbHNlKSA9PiB7XG4gICAgaWYgKGludGVycnVwdGVkQnlTb2NrZXRFdmVudCkge1xuICAgICAgdG9hc3QuZXJyb3IoXG4gICAgICAgICdGbHV4byBpbnRlcnJvbXBpZG86IHNpbmNyb25pemUgbyBub3ZvIHByZcOnbyBhdHVhbGl6YWRvIGVtIHRlbXBvIHJlYWwgYW50ZXMgZGUgY29udGludWFyLicsXG4gICAgICApXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBpZiAoc2VsZWN0ZWRJdGVtcy5sZW5ndGggPT09IDAgJiYgIXRpbWVkT3V0T25jZSkge1xuICAgICAgdG9hc3QuZXJyb3IoJ1NlbGVjaW9uZSBhbyBtZW5vcyB1bSBpdGVtIHBhcmEgZmluYWxpemFyIGEgY29tcHJhLicpXG4gICAgICByZXR1cm5cbiAgICB9XG5cbiAgICBjb25zdCBzaG91bGRGb3JjZVNob3J0VGltZW91dCA9IHNpbXVsYXRlRmlyc3RUaW1lb3V0ICYmICF0aW1lZE91dE9uY2UgJiYgIWlzUmV0cnlcblxuICAgIGNyZWF0ZU9yZGVyLm11dGF0ZShcbiAgICAgIHtcbiAgICAgICAgcGF5bG9hZDoge1xuICAgICAgICAgIGl0ZW1JZHM6IHNlbGVjdGVkSXRlbXMubWFwKChpKSA9PiBpLmlkKSxcbiAgICAgICAgICB3YWxsZXRBZGRyZXNzOiBhY3RpdmVXYWxsZXRBZGRyZXNzLFxuICAgICAgICAgIGNvdXBvbkNvZGU6IGNhcnQuY291cG9uQ29kZSxcbiAgICAgICAgICBpZGVtcG90ZW5jeUtleSxcbiAgICAgICAgfSxcbiAgICAgICAgdGltZW91dE1zOiBzaG91bGRGb3JjZVNob3J0VGltZW91dCA/IDEyMDAgOiAxNV8wMDAsXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBvblN1Y2Nlc3M6IChvcmRlcikgPT4ge1xuICAgICAgICAgIHRvYXN0LnN1Y2Nlc3MoXG4gICAgICAgICAgICB0aW1lZE91dE9uY2VcbiAgICAgICAgICAgICAgPyBgUGVkaWRvICMke29yZGVyLmlkfSByZWN1cGVyYWRvIGNvbSBpZGVtcG90w6puY2lhIHNlbSBjb2JyYW7Dp2EgZHVwbGljYWRhIWBcbiAgICAgICAgICAgICAgOiBgUGFnYW1lbnRvIGNvbmZpcm1hZG8hIFBlZGlkbyAjJHtvcmRlci5pZH0gY29uY2x1w61kby5gLFxuICAgICAgICAgIClcbiAgICAgICAgICB2b2lkIHJvdXRlci5uYXZpZ2F0ZSh7XG4gICAgICAgICAgICB0bzogJy9vcmRlcnMvJG9yZGVySWQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7IG9yZGVySWQ6IG9yZGVyLmlkIH0sXG4gICAgICAgICAgfSlcbiAgICAgICAgfSxcbiAgICAgICAgb25FcnJvcjogKGVycm9yKSA9PiB7XG4gICAgICAgICAgaWYgKGlzVGltZW91dEVycm9yKGVycm9yKSkge1xuICAgICAgICAgICAgc2V0VGltZWRPdXRPbmNlKHRydWUpXG4gICAgICAgICAgICB0b2FzdC53YXJuaW5nKFxuICAgICAgICAgICAgICAnVGVtcG8gbGltaXRlIGV4Y2VkaWRvISBSZWVudmllIGNvbSBhIG1lc21hIGNoYXZlIGRlIGlkZW1wb3TDqm5jaWEgcGFyYSByZWN1cGVyYXIgc2V1IHJlY2liby4nLFxuICAgICAgICAgICAgKVxuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0b2FzdC5lcnJvcihnZXRFcnJvck1lc3NhZ2UoZXJyb3IpKVxuICAgICAgICAgICAgdmFsaWRhdGVDaGVja291dC5tdXRhdGUoKVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgKVxuICB9XG5cbiAgY29uc3QgdmFsaWRhdGlvbklzc3VlcyA9IHZhbGlkYXRlQ2hlY2tvdXQuZGF0YT8uaXNzdWVzID8/IFtdXG4gIGNvbnN0IHRhcmdldENhcnROZnRJZCA9IHNlbGVjdGVkSXRlbXNbMF0/Lm5mdElkID8/IGNhcnQuaXRlbXNbMF0/Lm5mdElkXG5cbiAgcmV0dXJuIChcbiAgICA8bWFpblxuICAgICAgaWQ9XCJtYWluLWNvbnRlbnRcIlxuICAgICAgdGFiSW5kZXg9ey0xfVxuICAgICAgY2xhc3NOYW1lPVwibXgtYXV0byBncmlkIHctZnVsbCBtYXgtdy02eGwgZ2FwLTYgcHgtNCBweS02IG91dGxpbmUtbm9uZSBzbTpweC02IG1kOnB5LTEwIGxnOnB4LThcIlxuICAgID5cbiAgICAgIHsvKiBNb2RhbCBjb20gRm9jdXMgVHJhcCBpbnRlcnJvbXBlbmRvIG8gY2hlY2tvdXQgcXVhbmRvIG8gcHJlw6dvIGRlIHVtIE5GVCBkbyBjYXJyaW5obyBtdWRhIHZpYSBTb2NrZXQgKi99XG4gICAgICA8QWxlcnREaWFsb2dcbiAgICAgICAgb3Blbj17Qm9vbGVhbihpbnRlcnJ1cHRlZEJ5U29ja2V0RXZlbnQpfVxuICAgICAgICBvbk9wZW5DaGFuZ2U9eyhvcGVuKSA9PiB7XG4gICAgICAgICAgaWYgKCFvcGVuKSBoYW5kbGVBY2tub3dsZWRnZVNvY2tldFByaWNlQ2hhbmdlKClcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgPEFsZXJ0RGlhbG9nQ29udGVudD5cbiAgICAgICAgICA8QWxlcnREaWFsb2dIZWFkZXI+XG4gICAgICAgICAgICA8QWxlcnREaWFsb2dUaXRsZT5DaGVja291dCBJbnRlcnJvbXBpZG86IFByZcOnbyBBdHVhbGl6YWRvPC9BbGVydERpYWxvZ1RpdGxlPlxuICAgICAgICAgICAgPEFsZXJ0RGlhbG9nRGVzY3JpcHRpb24+XG4gICAgICAgICAgICAgIHtpbnRlcnJ1cHRlZEJ5U29ja2V0RXZlbnQgJiYgKFxuICAgICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgICBPIE5GVCA8c3Ryb25nPntpbnRlcnJ1cHRlZEJ5U29ja2V0RXZlbnQubmFtZX08L3N0cm9uZz4gbm8gc2V1IGNhcnJpbmhvIHRldmUgb1xuICAgICAgICAgICAgICAgICAgcHJlw6dvIGFsdGVyYWRvIGVtIHRlbXBvIHJlYWwgdmlhIFNvY2tldC5JTyBkZXsnICd9XG4gICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cImZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0RXRoKGludGVycnVwdGVkQnlTb2NrZXRFdmVudC5vbGRQcmljZUV0aCl9IEVUSFxuICAgICAgICAgICAgICAgICAgPC9zdHJvbmc+eycgJ31cbiAgICAgICAgICAgICAgICAgIHBhcmF7JyAnfVxuICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgICAge2Zvcm1hdEV0aChpbnRlcnJ1cHRlZEJ5U29ja2V0RXZlbnQubmV3UHJpY2VFdGgpfSBFVEhcbiAgICAgICAgICAgICAgICAgIDwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgLiBSZXZpc2Ugb3Mgbm92b3MgdmFsb3JlcyBhbnRlcyBkZSBwcm9zc2VndWlyLlxuICAgICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9BbGVydERpYWxvZ0Rlc2NyaXB0aW9uPlxuICAgICAgICAgIDwvQWxlcnREaWFsb2dIZWFkZXI+XG4gICAgICAgICAgPEFsZXJ0RGlhbG9nRm9vdGVyPlxuICAgICAgICAgICAgPEFsZXJ0RGlhbG9nQ2FuY2VsXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICBjbGVhckxhdGVzdE5mdFVwZGF0ZSgpXG4gICAgICAgICAgICAgICAgdm9pZCByb3V0ZXIubmF2aWdhdGUoeyB0bzogJy9jYXJ0JyB9KVxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBWb2x0YXIgYW8gY2FycmluaG9cbiAgICAgICAgICAgIDwvQWxlcnREaWFsb2dDYW5jZWw+XG4gICAgICAgICAgICA8QWxlcnREaWFsb2dBY3Rpb24gb25DbGljaz17aGFuZGxlQWNrbm93bGVkZ2VTb2NrZXRQcmljZUNoYW5nZX0+XG4gICAgICAgICAgICAgIEF0dWFsaXphciBwcmXDp28gZSByZXZpc2FyXG4gICAgICAgICAgICA8L0FsZXJ0RGlhbG9nQWN0aW9uPlxuICAgICAgICAgIDwvQWxlcnREaWFsb2dGb290ZXI+XG4gICAgICAgIDwvQWxlcnREaWFsb2dDb250ZW50PlxuICAgICAgPC9BbGVydERpYWxvZz5cblxuICAgICAgPGhlYWRlciBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtMnhsIGZvbnQtYm9sZCB0cmFja2luZy10aWdodCBzbTp0ZXh0LTN4bFwiPkNoZWNrb3V0IFdlYjM8L2gxPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIHNtOnRleHQtc21cIj5cbiAgICAgICAgICAgIFJldmlzZSBhIHZhbGlkYcOnw6NvIG9uLWNoYWluLCBzZWxlY2lvbmUgb3MgaXRlbnMgZSBhc3NpbmUgc3VhIHRyYW5zYcOnw6NvIGNvbSBpZGVtcG90w6puY2lhLlxuICAgICAgICAgIDwvcD5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICBkaXNhYmxlZD17dmFsaWRhdGVDaGVja291dC5pc1BlbmRpbmcgfHwgY3JlYXRlT3JkZXIuaXNQZW5kaW5nfVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdmFsaWRhdGVDaGVja291dC5tdXRhdGUoKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8UmVmcmVzaEN3XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAgICAgJ3NpemUtMy41JyxcbiAgICAgICAgICAgICAgICB2YWxpZGF0ZUNoZWNrb3V0LmlzUGVuZGluZyAmJiAnYW5pbWF0ZS1zcGluIG1vdGlvbi1yZWR1Y2U6YW5pbWF0ZS1ub25lJyxcbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8c3Bhbj5SZXZhbGlkYXIgUHJlw6dvcyBlIEVzdG9xdWU8L3NwYW4+XG4gICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgPExpbmsgdG89XCIvY2FydFwiIGNsYXNzTmFtZT17Y24oYnV0dG9uVmFyaWFudHMoeyB2YXJpYW50OiAnZ2hvc3QnLCBzaXplOiAnc20nIH0pKX0+XG4gICAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInNpemUtNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICA8c3Bhbj5Wb2x0YXIgYW8gY2FycmluaG88L3NwYW4+XG4gICAgICAgICAgPC9MaW5rPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICB7LyogQmFubmVyIGRlIEludGVycnVww6fDo28gcG9yIEV2ZW50byBTb2NrZXQuSU8gKi99XG4gICAgICB7aW50ZXJydXB0ZWRCeVNvY2tldEV2ZW50ICYmIChcbiAgICAgICAgPEFsZXJ0IHZhcmlhbnQ9XCJkZXN0cnVjdGl2ZVwiIHJvbGU9XCJhbGVydFwiPlxuICAgICAgICAgIDxBbGVydENpcmNsZSBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgIDxBbGVydFRpdGxlPkZsdXhvIGRlIENoZWNrb3V0IEludGVycm9tcGlkbyAoRXZlbnRvIFNvY2tldC5JTzogbmZ0LnVwZGF0ZWQpPC9BbGVydFRpdGxlPlxuICAgICAgICAgIDxBbGVydERlc2NyaXB0aW9uIGNsYXNzTmFtZT1cIm10LTIgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgPHNwYW4+XG4gICAgICAgICAgICAgIEEgY290YcOnw6NvIGRlIDxzdHJvbmc+e2ludGVycnVwdGVkQnlTb2NrZXRFdmVudC5uYW1lfTwvc3Ryb25nPiBtdWRvdSBkZXsnICd9XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ub1wiPntmb3JtYXRFdGgoaW50ZXJydXB0ZWRCeVNvY2tldEV2ZW50Lm9sZFByaWNlRXRoKX0gRVRIPC9zcGFuPnsnICd9XG4gICAgICAgICAgICAgIHBhcmF7JyAnfVxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW1vbm9cIj57Zm9ybWF0RXRoKGludGVycnVwdGVkQnlTb2NrZXRFdmVudC5uZXdQcmljZUV0aCl9IEVUSDwvc3Bhbj4uXG4gICAgICAgICAgICAgIFNpbmNyb25pemUgb3MgdmFsb3JlcyBwYXJhIGxpYmVyYXIgbyBwYWdhbWVudG8uXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9e2hhbmRsZUFja25vd2xlZGdlU29ja2V0UHJpY2VDaGFuZ2V9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIFNpbmNyb25pemFyIG5vdm8gcHJlw6dvXG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICA8L0FsZXJ0RGVzY3JpcHRpb24+XG4gICAgICAgIDwvQWxlcnQ+XG4gICAgICApfVxuXG4gICAgICB7LyogQWxlcnRhcyBkZSBWYWxpZGHDp8OjbyBkZSBQcmXDp28sIEN1cG9tIGUgRGlzcG9uaWJpbGlkYWRlICovfVxuICAgICAge3ZhbGlkYXRpb25Jc3N1ZXMubGVuZ3RoID4gMCAmJiAoXG4gICAgICAgIDxBbGVydCB2YXJpYW50PVwiZGVzdHJ1Y3RpdmVcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwic2l6ZS00XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICA8QWxlcnRUaXRsZT5BbHRlcmHDp8O1ZXMgZGV0ZWN0YWRhcyBuYSB2YWxpZGHDp8OjbyBjb20gbyBzZXJ2aWRvciAoTVNXKTwvQWxlcnRUaXRsZT5cbiAgICAgICAgICA8QWxlcnREZXNjcmlwdGlvbj5cbiAgICAgICAgICAgIDx1bCBjbGFzc05hbWU9XCJtdC0xIGxpc3QtZGlzYyBwbC00IHRleHQteHNcIj5cbiAgICAgICAgICAgICAge3ZhbGlkYXRpb25Jc3N1ZXMubWFwKChpc3N1ZSwgaWR4KSA9PiAoXG4gICAgICAgICAgICAgICAgPGxpIGtleT17aWR4fT57aXNzdWV9PC9saT5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICAgIDwvQWxlcnREZXNjcmlwdGlvbj5cbiAgICAgICAgPC9BbGVydD5cbiAgICAgICl9XG5cbiAgICAgIHsvKiBBbGVydGEgZGUgVGltZW91dCBlIFJlZW52aW8gSWRlbXBvdGVudGUgKi99XG4gICAgICB7dGltZWRPdXRPbmNlICYmIChcbiAgICAgICAgPEFsZXJ0IHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cImJvcmRlci1wcmltYXJ5LzUwIGJnLXByaW1hcnkvNVwiPlxuICAgICAgICAgIDxDbG9jayBjbGFzc05hbWU9XCJzaXplLTQgdGV4dC1wcmltYXJ5XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICA8QWxlcnRUaXRsZT5UaW1lb3V0IGRldGVjdGFkbyDigJQgUHJvdGXDp8OjbyBkZSBJZGVtcG90w6puY2lhIEF0aXZhPC9BbGVydFRpdGxlPlxuICAgICAgICAgIDxBbGVydERlc2NyaXB0aW9uIGNsYXNzTmFtZT1cIm10LTIgZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14c1wiPlxuICAgICAgICAgICAgICBBIDHCqiByZXF1aXNpw6fDo28gZXhjZWRldSBvIHRlbXBvIGxpbWl0ZSwgbWFzIGEgY2hhdmV7JyAnfVxuICAgICAgICAgICAgICA8Y29kZSBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1zZW1pYm9sZFwiPntpZGVtcG90ZW5jeUtleX08L2NvZGU+IGZvaSBtYW50aWRhLiBBb1xuICAgICAgICAgICAgICByZWVudmlhciwgbyBNU1cgZGV2b2x2ZXLDoSBvIHBlZGlkbyBwcm9jZXNzYWRvIHNlbSBjb2JyYXIgc2V1IHNhbGRvIG5vdmFtZW50ZS5cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtjcmVhdGVPcmRlci5pc1BlbmRpbmcgfHwgQm9vbGVhbihpbnRlcnJ1cHRlZEJ5U29ja2V0RXZlbnQpfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVDb25maXJtT3JkZXIodHJ1ZSl9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxSZWZyZXNoQ3cgY2xhc3NOYW1lPVwic2l6ZS0zLjVcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICA8c3Bhbj5SZWVudmlhciBjb20gYSBtZXNtYSBjaGF2ZTwvc3Bhbj5cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvQWxlcnREZXNjcmlwdGlvbj5cbiAgICAgICAgPC9BbGVydD5cbiAgICAgICl9XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBpdGVtcy1zdGFydCBnYXAtNiBsZzpncmlkLWNvbHMtMTJcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC02IGxnOmNvbC1zcGFuLTdcIj5cbiAgICAgICAgICB7LyogU2VsZcOnw6NvIGRvcyBJdGVucyBkbyBDYXJyaW5obyAqL31cbiAgICAgICAgICA8Q2FyZD5cbiAgICAgICAgICAgIDxDYXJkSGVhZGVyPlxuICAgICAgICAgICAgICA8Q2FyZFRpdGxlIHJvbGU9XCJoZWFkaW5nXCIgYXJpYS1sZXZlbD17Mn0gY2xhc3NOYW1lPVwidGV4dC1iYXNlXCI+XG4gICAgICAgICAgICAgICAgMS4gSXRlbnMgcGFyYSBlc3RhIHRyYW5zYcOnw6NvICh7c2VsZWN0ZWRJdGVtcy5sZW5ndGh9IGRlIHtjYXJ0Lml0ZW1zLmxlbmd0aH0pXG4gICAgICAgICAgICAgIDwvQ2FyZFRpdGxlPlxuICAgICAgICAgICAgICA8Q2FyZERlc2NyaXB0aW9uPlxuICAgICAgICAgICAgICAgIEFwZW5hcyBvcyBpdGVucyBtYXJjYWRvcyBhYmFpeG8gc2Vyw6NvIGNvbXByYWRvcyBlIHJlbW92aWRvcyBkbyBjYXJyaW5obyBhcMOzcyBhXG4gICAgICAgICAgICAgICAgY29uZmlybWHDp8Ojby5cbiAgICAgICAgICAgICAgPC9DYXJkRGVzY3JpcHRpb24+XG4gICAgICAgICAgICA8L0NhcmRIZWFkZXI+XG4gICAgICAgICAgICA8Q2FyZENvbnRlbnQgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtM1wiPlxuICAgICAgICAgICAgICB7Y2FydC5pdGVtcy5tYXAoKGl0ZW0pID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBpc0NoZWNrZWQgPSAhZXhjbHVkZWRJdGVtSWRzLmluY2x1ZGVzKGl0ZW0uaWQpXG4gICAgICAgICAgICAgICAgY29uc3QgY2hlY2tib3hJZCA9IGBjaGVja291dC1pdGVtLSR7aXRlbS5pZH1gXG4gICAgICAgICAgICAgICAgY29uc3QgbGluZVRvdGFsRXRoID0gbXVsdGlwbHlFdGgoaXRlbS5wcmljZUV0aCwgaXRlbS5xdWFudGl0eSlcblxuICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5pZH1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgICAgICAgICAgICAnZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0zIHJvdW5kZWQteGwgYm9yZGVyIHAtMyB0cmFuc2l0aW9uLWNvbG9ycycsXG4gICAgICAgICAgICAgICAgICAgICAgaXNDaGVja2VkID8gJ2JnLWNhcmQnIDogJ2JnLW11dGVkLzMwIG9wYWNpdHktNjAnLFxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLXctMCBpdGVtcy1jZW50ZXIgZ2FwLTNcIj5cbiAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tib3hcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkPXtjaGVja2JveElkfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2hlY2tlZD17aXNDaGVja2VkfVxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2NyZWF0ZU9yZGVyLmlzUGVuZGluZyB8fCB0aW1lZE91dE9uY2V9XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNoZWNrZWRDaGFuZ2U9eyhjaGVja2VkKSA9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICB0b2dnbGVJdGVtU2VsZWN0aW9uKGl0ZW0uaWQsIEJvb2xlYW4oY2hlY2tlZCkpXG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgICAgICAgICBzcmM9e2l0ZW0uaW1hZ2VVcmx9XG4gICAgICAgICAgICAgICAgICAgICAgICBhbHQ9e2BPYnJhIE5GVCAke2l0ZW0ubmFtZX0gZGEgY29sZcOnw6NvICR7aXRlbS5jb2xsZWN0aW9ufWB9XG4gICAgICAgICAgICAgICAgICAgICAgICBsb2FkaW5nPVwibGF6eVwiXG4gICAgICAgICAgICAgICAgICAgICAgICBkZWNvZGluZz1cImFzeW5jXCJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNpemUtMTIgc2hyaW5rLTAgcm91bmRlZC1sZyBiZy1tdXRlZCBvYmplY3QtY292ZXJcIlxuICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9e2NoZWNrYm94SWR9IGNsYXNzTmFtZT1cImdyaWQgbWluLXctMCBjdXJzb3ItcG9pbnRlciBnYXAtMC41XCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0cnVuY2F0ZSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGRcIj57aXRlbS5uYW1lfTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ucXVhbnRpdHl9eCB7Zm9ybWF0RXRoKGl0ZW0ucHJpY2VFdGgpfSBFVEhcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L0xhYmVsPlxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJzaHJpbmstMCBmb250LW1vbm8gdGV4dC1zbSBmb250LXNlbWlib2xkIHRhYnVsYXItbnVtc1wiPlxuICAgICAgICAgICAgICAgICAgICAgIHtmb3JtYXRFdGgobGluZVRvdGFsRXRoKX0gRVRIXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L0NhcmRDb250ZW50PlxuICAgICAgICAgIDwvQ2FyZD5cblxuICAgICAgICAgIHsvKiBTZWxlw6fDo28gZGEgQ2FydGVpcmEgRXRoZXJldW0gKi99XG4gICAgICAgICAgPENhcmQ+XG4gICAgICAgICAgICA8Q2FyZEhlYWRlcj5cbiAgICAgICAgICAgICAgPENhcmRUaXRsZSByb2xlPVwiaGVhZGluZ1wiIGFyaWEtbGV2ZWw9ezJ9IGNsYXNzTmFtZT1cInRleHQtYmFzZVwiPlxuICAgICAgICAgICAgICAgIDIuIENhcnRlaXJhIFBhZ2Fkb3JhIChBc3NpbmF0dXJhIFdlYjMpXG4gICAgICAgICAgICAgIDwvQ2FyZFRpdGxlPlxuICAgICAgICAgICAgICA8Q2FyZERlc2NyaXB0aW9uPlxuICAgICAgICAgICAgICAgIEVzY29saGEgcXVhbCBjYXJ0ZWlyYSB2aW5jdWxhZGEgYXNzaW5hcsOhIG8gcGFnYW1lbnRvIGVtIEVUSC5cbiAgICAgICAgICAgICAgPC9DYXJkRGVzY3JpcHRpb24+XG4gICAgICAgICAgICA8L0NhcmRIZWFkZXI+XG4gICAgICAgICAgICA8Q2FyZENvbnRlbnQgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNFwiPlxuICAgICAgICAgICAgICB7dXNlci53YWxsZXRzLmxlbmd0aCA9PT0gMCA/IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWRhc2hlZCBwLTNcIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgIFZvY8OqIGFpbmRhIG7Do28gcG9zc3VpIGNhcnRlaXJhcyBjYWRhc3RyYWRhcy5cbiAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDxMaW5rXG4gICAgICAgICAgICAgICAgICAgIHRvPVwiL3Byb2ZpbGVcIlxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NuKGJ1dHRvblZhcmlhbnRzKHsgdmFyaWFudDogJ291dGxpbmUnLCBzaXplOiAneHMnIH0pKX1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgQWRpY2lvbmFyIG5vIFBlcmZpbFxuICAgICAgICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxSYWRpb0dyb3VwXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17YWN0aXZlV2FsbGV0QWRkcmVzc31cbiAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWwpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHZhbCkgc2V0U2VsZWN0ZWRXYWxsZXQodmFsKVxuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7dXNlci53YWxsZXRzLm1hcCgodykgPT4ge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCByYWRpb0lkID0gYHdhbGxldC0ke3cuaWR9YFxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17dy5pZH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMyByb3VuZGVkLWxnIGJvcmRlciBwLTNcIlxuICAgICAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtaW4tdy0wIGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8UmFkaW9Hcm91cEl0ZW0gdmFsdWU9e3cuYWRkcmVzc30gaWQ9e3JhZGlvSWR9IC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPXtyYWRpb0lkfSBjbGFzc05hbWU9XCJncmlkIG1pbi13LTAgY3Vyc29yLXBvaW50ZXIgZ2FwLTAuNVwiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0yIHRleHQtc20gZm9udC1tZWRpdW1cIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxXYWxsZXRJY29uIGNsYXNzTmFtZT1cInNpemUtMy41IHRleHQtcHJpbWFyeVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Bhbj57dy5sYWJlbH08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJyZWFrLWFsbCBmb250LW1vbm8gdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHt3LmFkZHJlc3N9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIClcbiAgICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgICAgIDwvUmFkaW9Hcm91cD5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgICAgICAgPC9DYXJkPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7LyogQ29sdW5hIERpcmVpdGE6IElkZW1wb3TDqm5jaWEsIFNpbXVsYcOnw7VlcyBlIENvbmZpcm1hw6fDo28gZGUgUGFnYW1lbnRvICovfVxuICAgICAgICA8YXNpZGUgYXJpYS1sYWJlbD1cIkNvbmZpcm1hw6fDo28gZSBwYWdhbWVudG9cIiBjbGFzc05hbWU9XCJncmlkIGdhcC00IGxnOmNvbC1zcGFuLTVcIj5cbiAgICAgICAgICA8Q2FyZD5cbiAgICAgICAgICAgIDxDYXJkSGVhZGVyIGNsYXNzTmFtZT1cInBiLTJcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8Q2FyZFRpdGxlIHJvbGU9XCJoZWFkaW5nXCIgYXJpYS1sZXZlbD17Mn0gY2xhc3NOYW1lPVwidGV4dC1iYXNlXCI+XG4gICAgICAgICAgICAgICAgICAzLiBMaXF1aWRhw6fDo28gZW0gRVRIXG4gICAgICAgICAgICAgICAgPC9DYXJkVGl0bGU+XG4gICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJvdXRsaW5lXCIgY2xhc3NOYW1lPVwiZ2FwLTEgZm9udC1tb25vIHRleHQteHNcIj5cbiAgICAgICAgICAgICAgICAgIDxDaGVja0NpcmNsZTIgY2xhc3NOYW1lPVwic2l6ZS0zIHRleHQtcHJpbWFyeVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5JZGVtcG90ZW50ZTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvQ2FyZEhlYWRlcj5cblxuICAgICAgICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTRcIj5cbiAgICAgICAgICAgICAgey8qIEJsb2NvIGRlIENoYXZlIGRlIElkZW1wb3TDqm5jaWEgKi99XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtMS41IHJvdW5kZWQtbGcgYm9yZGVyIGJnLW11dGVkLzQwIHAtMyB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMS41IGZvbnQtbWVkaXVtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICAgICAgICAgICAgPEZpbmdlcnByaW50IGNsYXNzTmFtZT1cInNpemUtMy41IHRleHQtcHJpbWFyeVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj5IZWFkZXIgeC1pZGVtcG90ZW5jeS1rZXk8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGNvZGUgY2xhc3NOYW1lPVwiYnJlYWstYWxsIGZvbnQtbW9ubyB0ZXh0LWZvcmVncm91bmRcIj57aWRlbXBvdGVuY3lLZXl9PC9jb2RlPlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7LyogU2ltdWxhZG9yZXMgcGFyYSBBdmFsaWHDp8OjbyBUw6ljbmljYSAoVGltZW91dCArIFNvY2tldC5JTyBQcmljZSBDaGFuZ2UpICovfVxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTIuNSByb3VuZGVkLWxnIGJvcmRlciBwLTNcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtM1wiPlxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0wLjUgdGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj17dGltZW91dFN3aXRjaElkfSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciBmb250LW1lZGl1bVwiPlxuICAgICAgICAgICAgICAgICAgICAgIFNpbXVsYXIgVGltZW91dCBuYSAxwqogdGVudGF0aXZhXG4gICAgICAgICAgICAgICAgICAgIDwvTGFiZWw+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGlkPXt0aW1lb3V0SGludElkfSBjbGFzc05hbWU9XCJ0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgICAgICBUZXN0YSByZWVudmlvIGlkZW1wb3RlbnRlIHNlbSBjb2JyYW7Dp2EgZHVwbGEuXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPFN3aXRjaFxuICAgICAgICAgICAgICAgICAgICBpZD17dGltZW91dFN3aXRjaElkfVxuICAgICAgICAgICAgICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PXt0aW1lb3V0SGludElkfVxuICAgICAgICAgICAgICAgICAgICBhcmlhLWludmFsaWQ9e2ZhbHNlfVxuICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzaW11bGF0ZUZpcnN0VGltZW91dH1cbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2NyZWF0ZU9yZGVyLmlzUGVuZGluZyB8fCB0aW1lZE91dE9uY2V9XG4gICAgICAgICAgICAgICAgICAgIG9uQ2hlY2tlZENoYW5nZT17KGNoZWNrZWQpID0+IHNldFNpbXVsYXRlRmlyc3RUaW1lb3V0KEJvb2xlYW4oY2hlY2tlZCkpfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIHt0YXJnZXRDYXJ0TmZ0SWQgJiYgKFxuICAgICAgICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgICAgICAgPFNlcGFyYXRvciAvPlxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJ4c1wiXG4gICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2NyZWF0ZU9yZGVyLmlzUGVuZGluZ31cbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0cmlnZ2VyU2ltdWxhdGVkTmZ0VXBkYXRlKHRhcmdldENhcnROZnRJZCl9XG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidy1mdWxsXCJcbiAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgIDxaYXAgY2xhc3NOYW1lPVwic2l6ZS0zIHRleHQtcHJpbWFyeVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgPHNwYW4+U2ltdWxhciBhbHRlcmHDp8OjbyBkZSBwcmXDp28gdmlhIFNvY2tldC5JTzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8U2VwYXJhdG9yIC8+XG5cbiAgICAgICAgICAgICAgPGRsIGNsYXNzTmFtZT1cImdyaWQgZ2FwLTIgdGV4dC1zbVwiIGFyaWEtbGl2ZT1cInBvbGl0ZVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+U2V1IHNhbGRvIGF0dWFsPC9kdD5cbiAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJmb250LW1vbm8gZm9udC1tZWRpdW0gdGFidWxhci1udW1zXCI+XG4gICAgICAgICAgICAgICAgICAgIHtmb3JtYXRFdGgodXNlci5iYWxhbmNlRXRoKX0gRVRIXG4gICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPFNlcGFyYXRvciBjbGFzc05hbWU9XCJteS0xXCIgLz5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgICAgICAgICAgICA8ZHQgY2xhc3NOYW1lPVwidGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+U3VidG90YWwgc2VsZWNpb25hZG88L2R0PlxuICAgICAgICAgICAgICAgICAgPGRkIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0YWJ1bGFyLW51bXNcIj57Zm9ybWF0RXRoKHRvdGFscy5zdWJ0b3RhbEV0aCl9IEVUSDwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xLjUgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPkRlc2NvbnRvPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB7Y2FydC5jb3Vwb25Db2RlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cInNlY29uZGFyeVwiIGNsYXNzTmFtZT1cImZvbnQtbW9ub1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAge2NhcnQuY291cG9uQ29kZX0gKC17Y2FydC5kaXNjb3VudFBlcmNlbnR9JSlcbiAgICAgICAgICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kdD5cbiAgICAgICAgICAgICAgICAgIDxkZCBjbGFzc05hbWU9XCJmb250LW1vbm8gdGFidWxhci1udW1zXCI+LSB7Zm9ybWF0RXRoKHRvdGFscy5kaXNjb3VudEV0aCl9IEVUSDwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMlwiPlxuICAgICAgICAgICAgICAgICAgPGR0IGNsYXNzTmFtZT1cInRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlRheGEgZml4YSAoR2FzICYgUHJvdG9jb2xvKTwvZHQ+XG4gICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRhYnVsYXItbnVtc1wiPntmb3JtYXRFdGgodG90YWxzLmZlZUV0aCl9IEVUSDwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8U2VwYXJhdG9yIGNsYXNzTmFtZT1cIm15LTFcIiAvPlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWJhc2VsaW5lIGp1c3RpZnktYmV0d2VlbiBnYXAtMiB0ZXh0LWJhc2UgZm9udC1ib2xkXCI+XG4gICAgICAgICAgICAgICAgICA8ZHQ+VG90YWwgYSBwYWdhcjwvZHQ+XG4gICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEgZm9udC1tb25vIHRleHQtbGcgdGFidWxhci1udW1zXCI+XG4gICAgICAgICAgICAgICAgICAgIDxTcGFya2xlcyBjbGFzc05hbWU9XCJzaXplLTQgdGV4dC1wcmltYXJ5XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+e2Zvcm1hdEV0aCh0b3RhbHMudG90YWxFdGgpfSBFVEg8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8L2RkPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICAgIDxkdD5TYWxkbyBlc3RpbWFkbyBhcMOzcyBhIGNvbXByYTwvZHQ+XG4gICAgICAgICAgICAgICAgICA8ZGQgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRhYnVsYXItbnVtc1wiPntmb3JtYXRFdGgocmVtYWluaW5nQmFsYW5jZUV0aCl9IEVUSDwvZGQ+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGw+XG5cbiAgICAgICAgICAgICAgeyFoYXNTdWZmaWNpZW50QmFsYW5jZSAmJiAhdGltZWRPdXRPbmNlICYmIChcbiAgICAgICAgICAgICAgICA8QWxlcnQgdmFyaWFudD1cImRlc3RydWN0aXZlXCIgcm9sZT1cImFsZXJ0XCI+XG4gICAgICAgICAgICAgICAgICA8QWxlcnRDaXJjbGUgY2xhc3NOYW1lPVwic2l6ZS00XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxBbGVydFRpdGxlPlNhbGRvIGluc3VmaWNpZW50ZTwvQWxlcnRUaXRsZT5cbiAgICAgICAgICAgICAgICAgIDxBbGVydERlc2NyaXB0aW9uPlxuICAgICAgICAgICAgICAgICAgICBTZXUgc2FsZG8gZW0gRVRIICh7Zm9ybWF0RXRoKHVzZXIuYmFsYW5jZUV0aCl9IEVUSCkgw6kgbWVub3IgcXVlIG8gdG90YWwgZG9cbiAgICAgICAgICAgICAgICAgICAgcGVkaWRvICh7Zm9ybWF0RXRoKHRvdGFscy50b3RhbEV0aCl9IEVUSCkuXG4gICAgICAgICAgICAgICAgICA8L0FsZXJ0RGVzY3JpcHRpb24+XG4gICAgICAgICAgICAgICAgPC9BbGVydD5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvQ2FyZENvbnRlbnQ+XG5cbiAgICAgICAgICAgIDxDYXJkRm9vdGVyIGNsYXNzTmFtZT1cImZsZXgtY29sIGdhcC0yLjUgcHQtMFwiPlxuICAgICAgICAgICAgICA8U3VibWl0QnV0dG9uXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgc2l6ZT1cImxnXCJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxuICAgICAgICAgICAgICAgIGlzUGVuZGluZz17Y3JlYXRlT3JkZXIuaXNQZW5kaW5nfVxuICAgICAgICAgICAgICAgIHBlbmRpbmdUZXh0PVwiQ29uZmlybWFuZG8gdHJhbnNhw6fDo28gbmEgcmVkZSAoYWd1YXJkZSkuLi5cIlxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXtcbiAgICAgICAgICAgICAgICAgIEJvb2xlYW4oaW50ZXJydXB0ZWRCeVNvY2tldEV2ZW50KSB8fFxuICAgICAgICAgICAgICAgICAgKCFoYXNTdWZmaWNpZW50QmFsYW5jZSAmJiAhdGltZWRPdXRPbmNlKSB8fFxuICAgICAgICAgICAgICAgICAgKHNlbGVjdGVkSXRlbXMubGVuZ3RoID09PSAwICYmICF0aW1lZE91dE9uY2UpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZUNvbmZpcm1PcmRlcih0aW1lZE91dE9uY2UpfVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge3RpbWVkT3V0T25jZVxuICAgICAgICAgICAgICAgICAgPyAnUmVlbnZpYXIgUGVkaWRvIChNZXNtYSBDaGF2ZSBkZSBJZGVtcG90w6puY2lhKSdcbiAgICAgICAgICAgICAgICAgIDogJ0NvbmZpcm1hciBlIFBhZ2FyIGVtIEVUSCd9XG4gICAgICAgICAgICAgIDwvU3VibWl0QnV0dG9uPlxuXG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0xLjUgdGV4dC1jZW50ZXIgdGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5cbiAgICAgICAgICAgICAgICA8U2hpZWxkQ2hlY2sgY2xhc3NOYW1lPVwic2l6ZS0zLjUgdGV4dC1wcmltYXJ5XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5Qcm90ZWdpZG8gY29udHJhIGNsaXF1ZXMgZHVwbG9zIGUgY29icmFuw6dhIGR1cGxpY2FkYS48L3NwYW4+XG4gICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDwvQ2FyZEZvb3Rlcj5cbiAgICAgICAgICA8L0NhcmQ+XG4gICAgICAgIDwvYXNpZGU+XG4gICAgICA8L2Rpdj5cbiAgICA8L21haW4+XG4gIClcbn1cblxuZnVuY3Rpb24gQ2hlY2tvdXRTa2VsZXRvbigpIHtcbiAgcmV0dXJuIChcbiAgICA8bWFpblxuICAgICAgaWQ9XCJtYWluLWNvbnRlbnRcIlxuICAgICAgYXJpYS1idXN5PVwidHJ1ZVwiXG4gICAgICBhcmlhLWxhYmVsPVwiQ2FycmVnYW5kbyBjaGVja291dFwiXG4gICAgICBjbGFzc05hbWU9XCJteC1hdXRvIGdyaWQgdy1mdWxsIG1heC13LTZ4bCBnYXAtNiBweC00IHB5LTYgc206cHgtNiBtZDpweS0xMCBsZzpweC04XCJcbiAgICA+XG4gICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC0xMiB3LWZ1bGwgcm91bmRlZC14bFwiIC8+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTYgbGc6Z3JpZC1jb2xzLTEyXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtNiBsZzpjb2wtc3Bhbi03XCI+XG4gICAgICAgICAgPFNrZWxldG9uIGNsYXNzTmFtZT1cImgtNjQgdy1mdWxsIHJvdW5kZWQteGxcIiAvPlxuICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTQ0IHctZnVsbCByb3VuZGVkLXhsXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNVwiPlxuICAgICAgICAgIDxTa2VsZXRvbiBjbGFzc05hbWU9XCJoLTk2IHctZnVsbCByb3VuZGVkLXhsXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L21haW4+XG4gIClcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL3JvdXRlcy9fYXV0aGVudGljYXRlZC9jaGVja291dC50c3gifQ==