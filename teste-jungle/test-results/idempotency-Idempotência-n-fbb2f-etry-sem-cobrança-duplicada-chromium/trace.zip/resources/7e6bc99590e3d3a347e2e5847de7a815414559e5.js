import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/card.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport1_react, 1);const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/card.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
function Card(t0) {
	const $ = _c(11);
	if ($[0] !== "f360b73b6197c99a85c8b63b9704685a818ff126bd590d2356aa8e87c96bac5a") {
		for (let $i = 0; $i < 11; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "f360b73b6197c99a85c8b63b9704685a818ff126bd590d2356aa8e87c96bac5a";
	}
	let className;
	let props;
	let t1;
	if ($[1] !== t0) {
		({className, size: t1, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
		$[4] = t1;
	} else {
		className = $[2];
		props = $[3];
		t1 = $[4];
	}
	const size = t1 === undefined ? "default" : t1;
	let t2;
	if ($[5] !== className) {
		t2 = cn("group/card flex flex-col gap-(--card-spacing) overflow-hidden rounded-xl bg-card py-(--card-spacing) text-sm text-card-foreground ring-1 ring-foreground/10 [--card-spacing:--spacing(4)] has-data-[slot=card-footer]:pb-0 has-[>img:first-child]:pt-0 data-[size=sm]:[--card-spacing:--spacing(3)] data-[size=sm]:has-data-[slot=card-footer]:pb-0 *:[img:first-child]:rounded-t-xl *:[img:last-child]:rounded-b-xl", className);
		$[5] = className;
		$[6] = t2;
	} else {
		t2 = $[6];
	}
	let t3;
	if ($[7] !== props || $[8] !== size || $[9] !== t2) {
		t3 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "card",
			"data-size": size,
			className: t2,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 41,
			columnNumber: 10
		}, this);
		$[7] = props;
		$[8] = size;
		$[9] = t2;
		$[10] = t3;
	} else {
		t3 = $[10];
	}
	return t3;
}
_c2 = Card;
function CardHeader(t0) {
	const $ = _c(9);
	if ($[0] !== "f360b73b6197c99a85c8b63b9704685a818ff126bd590d2356aa8e87c96bac5a") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "f360b73b6197c99a85c8b63b9704685a818ff126bd590d2356aa8e87c96bac5a";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("group/card-header @container/card-header grid auto-rows-min items-start gap-1 rounded-t-xl px-(--card-spacing) has-data-[slot=card-action]:grid-cols-[1fr_auto] has-data-[slot=card-description]:grid-rows-[auto_auto] [.border-b]:pb-(--card-spacing)", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "card-header",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 83,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c3 = CardHeader;
function CardTitle(t0) {
	const $ = _c(9);
	if ($[0] !== "f360b73b6197c99a85c8b63b9704685a818ff126bd590d2356aa8e87c96bac5a") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "f360b73b6197c99a85c8b63b9704685a818ff126bd590d2356aa8e87c96bac5a";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("font-heading text-base leading-snug font-medium group-data-[size=sm]/card:text-sm", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "card-title",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 124,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c4 = CardTitle;
function CardDescription(t0) {
	const $ = _c(9);
	if ($[0] !== "f360b73b6197c99a85c8b63b9704685a818ff126bd590d2356aa8e87c96bac5a") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "f360b73b6197c99a85c8b63b9704685a818ff126bd590d2356aa8e87c96bac5a";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("text-sm text-muted-foreground", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "card-description",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 165,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c5 = CardDescription;
function CardAction(t0) {
	const $ = _c(9);
	if ($[0] !== "f360b73b6197c99a85c8b63b9704685a818ff126bd590d2356aa8e87c96bac5a") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "f360b73b6197c99a85c8b63b9704685a818ff126bd590d2356aa8e87c96bac5a";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("col-start-2 row-span-2 row-start-1 self-start justify-self-end", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "card-action",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 206,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c6 = CardAction;
function CardContent(t0) {
	const $ = _c(9);
	if ($[0] !== "f360b73b6197c99a85c8b63b9704685a818ff126bd590d2356aa8e87c96bac5a") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "f360b73b6197c99a85c8b63b9704685a818ff126bd590d2356aa8e87c96bac5a";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("px-(--card-spacing)", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "card-content",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 247,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c7 = CardContent;
function CardFooter(t0) {
	const $ = _c(9);
	if ($[0] !== "f360b73b6197c99a85c8b63b9704685a818ff126bd590d2356aa8e87c96bac5a") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "f360b73b6197c99a85c8b63b9704685a818ff126bd590d2356aa8e87c96bac5a";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("flex items-center rounded-b-xl border-t bg-muted/50 p-(--card-spacing)", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "card-footer",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 288,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c8 = CardFooter;
export { Card, CardHeader, CardFooter, CardTitle, CardAction, CardDescription, CardContent };
var _c2, _c3, _c4, _c5, _c6, _c7, _c8;
$RefreshReg$(_c2, "Card");
$RefreshReg$(_c3, "CardHeader");
$RefreshReg$(_c4, "CardTitle");
$RefreshReg$(_c5, "CardDescription");
$RefreshReg$(_c6, "CardAction");
$RefreshReg$(_c7, "CardContent");
$RefreshReg$(_c8, "CardFooter");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/card.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/card.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/card.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/card.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFlBQVlBLFdBQVc7QUFDdkIsU0FBU0MsVUFBVTs7O0FBRW5CLFNBQUFDLEtBQUFDLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBSztDQUFBLElBQUFDO0NBQUEsSUFBQUM7Q0FBQSxJQUFBUCxFQUFBLE9BQUFELElBQUE7RUFBYyxFQUFBTSxXQUFBRyxNQUFBRCxJQUFBLEdBQUFELFNBQUFQO0VBSThDQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFPO0NBQUE7RUFBQUYsWUFBQUwsRUFBQTtFQUFBTSxRQUFBTixFQUFBO0VBQUFPLEtBQUFQLEVBQUE7Q0FBQTtDQUYxRCxNQUFBUSxPQUFBRCxPQUFBRSxZQUFBLFlBQUFGO0NBQWdCLElBQUFHO0NBQUEsSUFBQVYsRUFBQSxPQUFBSyxXQUFBO0VBT0RLLEtBQUFiLEdBQ1Qsd1pBQ0FRLFNBQ0Y7RUFBQ0wsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFVO0NBQUE7RUFBQUEsS0FBQVYsRUFBQTtDQUFBO0NBQUEsSUFBQVc7Q0FBQSxJQUFBWCxFQUFBLE9BQUFNLFNBQUFOLEVBQUEsT0FBQVEsUUFBQVIsRUFBQSxPQUFBVSxJQUFBO0VBTkhDLEtBQUE7R0FDWTtHQUNDSDtHQUNBLFdBQUFFO0dBR1YsR0FDR0o7RUFBSzs7Ozs7RUFDVE4sRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFRO0VBQUFSLEVBQUEsS0FBQVU7RUFBQVYsRUFBQSxNQUFBVztDQUFBO0VBQUFBLEtBQUFYLEVBQUE7Q0FBQTtDQUFBLE9BUkZXO0FBUUU7O0FBSU4sU0FBQUMsV0FBQWIsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUM7Q0FBQSxJQUFBTixFQUFBLE9BQUFELElBQUE7RUFBb0IsRUFBQU0sV0FBQSxHQUFBQyxTQUFBUDtFQUFvREMsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07Q0FBQTtFQUFBRCxZQUFBTCxFQUFBO0VBQUFNLFFBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFPO0NBQUEsSUFBQVAsRUFBQSxPQUFBSyxXQUFBO0VBSXZERSxLQUFBVixHQUNULDBQQUNBUSxTQUNGO0VBQUNMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTztDQUFBO0VBQUFBLEtBQUFQLEVBQUE7Q0FBQTtDQUFBLElBQUFVO0NBQUEsSUFBQVYsRUFBQSxPQUFBTSxTQUFBTixFQUFBLE9BQUFPLElBQUE7RUFMSEcsS0FBQTtHQUNZO0dBQ0MsV0FBQUg7R0FHVixHQUNHRDtFQUFLOzs7OztFQUNUTixFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBVTtDQUFBO0VBQUFBLEtBQUFWLEVBQUE7Q0FBQTtDQUFBLE9BUEZVO0FBT0U7O0FBSU4sU0FBQUcsVUFBQWQsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUM7Q0FBQSxJQUFBTixFQUFBLE9BQUFELElBQUE7RUFBbUIsRUFBQU0sV0FBQSxHQUFBQyxTQUFBUDtFQUFvREMsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07Q0FBQTtFQUFBRCxZQUFBTCxFQUFBO0VBQUFNLFFBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFPO0NBQUEsSUFBQVAsRUFBQSxPQUFBSyxXQUFBO0VBSXRERSxLQUFBVixHQUNULHFGQUNBUSxTQUNGO0VBQUNMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTztDQUFBO0VBQUFBLEtBQUFQLEVBQUE7Q0FBQTtDQUFBLElBQUFVO0NBQUEsSUFBQVYsRUFBQSxPQUFBTSxTQUFBTixFQUFBLE9BQUFPLElBQUE7RUFMSEcsS0FBQTtHQUNZO0dBQ0MsV0FBQUg7R0FHVixHQUNHRDtFQUFLOzs7OztFQUNUTixFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBVTtDQUFBO0VBQUFBLEtBQUFWLEVBQUE7Q0FBQTtDQUFBLE9BUEZVO0FBT0U7O0FBSU4sU0FBQUksZ0JBQUFmLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBSztDQUFBLElBQUFDO0NBQUEsSUFBQU4sRUFBQSxPQUFBRCxJQUFBO0VBQXlCLEVBQUFNLFdBQUEsR0FBQUMsU0FBQVA7RUFBb0RDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0NBQUE7RUFBQUQsWUFBQUwsRUFBQTtFQUFBTSxRQUFBTixFQUFBO0NBQUE7Q0FBQSxJQUFBTztDQUFBLElBQUFQLEVBQUEsT0FBQUssV0FBQTtFQUk1REUsS0FBQVYsR0FBRyxpQ0FBaUNRLFNBQVM7RUFBQ0wsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFPO0NBQUE7RUFBQUEsS0FBQVAsRUFBQTtDQUFBO0NBQUEsSUFBQVU7Q0FBQSxJQUFBVixFQUFBLE9BQUFNLFNBQUFOLEVBQUEsT0FBQU8sSUFBQTtFQUYzREcsS0FBQTtHQUNZO0dBQ0MsV0FBQUg7R0FBOEMsR0FDckREO0VBQUs7Ozs7O0VBQ1ROLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBTztFQUFBUCxFQUFBLEtBQUFVO0NBQUE7RUFBQUEsS0FBQVYsRUFBQTtDQUFBO0NBQUEsT0FKRlU7QUFJRTs7QUFJTixTQUFBSyxXQUFBaEIsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUM7Q0FBQSxJQUFBTixFQUFBLE9BQUFELElBQUE7RUFBb0IsRUFBQU0sV0FBQSxHQUFBQyxTQUFBUDtFQUFvREMsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07Q0FBQTtFQUFBRCxZQUFBTCxFQUFBO0VBQUFNLFFBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFPO0NBQUEsSUFBQVAsRUFBQSxPQUFBSyxXQUFBO0VBSXZERSxLQUFBVixHQUNULGtFQUNBUSxTQUNGO0VBQUNMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTztDQUFBO0VBQUFBLEtBQUFQLEVBQUE7Q0FBQTtDQUFBLElBQUFVO0NBQUEsSUFBQVYsRUFBQSxPQUFBTSxTQUFBTixFQUFBLE9BQUFPLElBQUE7RUFMSEcsS0FBQTtHQUNZO0dBQ0MsV0FBQUg7R0FHVixHQUNHRDtFQUFLOzs7OztFQUNUTixFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBVTtDQUFBO0VBQUFBLEtBQUFWLEVBQUE7Q0FBQTtDQUFBLE9BUEZVO0FBT0U7O0FBSU4sU0FBQU0sWUFBQWpCLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBSztDQUFBLElBQUFDO0NBQUEsSUFBQU4sRUFBQSxPQUFBRCxJQUFBO0VBQXFCLEVBQUFNLFdBQUEsR0FBQUMsU0FBQVA7RUFBb0RDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0NBQUE7RUFBQUQsWUFBQUwsRUFBQTtFQUFBTSxRQUFBTixFQUFBO0NBQUE7Q0FBQSxJQUFBTztDQUFBLElBQUFQLEVBQUEsT0FBQUssV0FBQTtFQUl4REUsS0FBQVYsR0FBRyx1QkFBdUJRLFNBQVM7RUFBQ0wsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFPO0NBQUE7RUFBQUEsS0FBQVAsRUFBQTtDQUFBO0NBQUEsSUFBQVU7Q0FBQSxJQUFBVixFQUFBLE9BQUFNLFNBQUFOLEVBQUEsT0FBQU8sSUFBQTtFQUZqREcsS0FBQTtHQUNZO0dBQ0MsV0FBQUg7R0FBb0MsR0FDM0NEO0VBQUs7Ozs7O0VBQ1ROLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBTztFQUFBUCxFQUFBLEtBQUFVO0NBQUE7RUFBQUEsS0FBQVYsRUFBQTtDQUFBO0NBQUEsT0FKRlU7QUFJRTs7QUFJTixTQUFBTyxXQUFBbEIsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUM7Q0FBQSxJQUFBTixFQUFBLE9BQUFELElBQUE7RUFBb0IsRUFBQU0sV0FBQSxHQUFBQyxTQUFBUDtFQUFvREMsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07Q0FBQTtFQUFBRCxZQUFBTCxFQUFBO0VBQUFNLFFBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFPO0NBQUEsSUFBQVAsRUFBQSxPQUFBSyxXQUFBO0VBSXZERSxLQUFBVixHQUNULDBFQUNBUSxTQUNGO0VBQUNMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTztDQUFBO0VBQUFBLEtBQUFQLEVBQUE7Q0FBQTtDQUFBLElBQUFVO0NBQUEsSUFBQVYsRUFBQSxPQUFBTSxTQUFBTixFQUFBLE9BQUFPLElBQUE7RUFMSEcsS0FBQTtHQUNZO0dBQ0MsV0FBQUg7R0FHVixHQUNHRDtFQUFLOzs7OztFQUNUTixFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBVTtDQUFBO0VBQUFBLEtBQUFWLEVBQUE7Q0FBQTtDQUFBLE9BUEZVO0FBT0U7O0FBSU4sU0FDRVosTUFDQWMsWUFDQUssWUFDQUosV0FDQUUsWUFDQUQsaUJBQ0FFIiwibmFtZXMiOlsiUmVhY3QiLCJjbiIsIkNhcmQiLCJ0MCIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwiY2xhc3NOYW1lIiwicHJvcHMiLCJ0MSIsInNpemUiLCJ1bmRlZmluZWQiLCJ0MiIsInQzIiwiQ2FyZEhlYWRlciIsIkNhcmRUaXRsZSIsIkNhcmREZXNjcmlwdGlvbiIsIkNhcmRBY3Rpb24iLCJDYXJkQ29udGVudCIsIkNhcmRGb290ZXIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiY2FyZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCJcbmltcG9ydCB7IGNuIH0gZnJvbSBcImNuXCJcblxuZnVuY3Rpb24gQ2FyZCh7XG4gIGNsYXNzTmFtZSxcbiAgc2l6ZSA9IFwiZGVmYXVsdFwiLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8XCJkaXZcIj4gJiB7IHNpemU/OiBcImRlZmF1bHRcIiB8IFwic21cIiB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgZGF0YS1zbG90PVwiY2FyZFwiXG4gICAgICBkYXRhLXNpemU9e3NpemV9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImdyb3VwL2NhcmQgZmxleCBmbGV4LWNvbCBnYXAtKC0tY2FyZC1zcGFjaW5nKSBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC14bCBiZy1jYXJkIHB5LSgtLWNhcmQtc3BhY2luZykgdGV4dC1zbSB0ZXh0LWNhcmQtZm9yZWdyb3VuZCByaW5nLTEgcmluZy1mb3JlZ3JvdW5kLzEwIFstLWNhcmQtc3BhY2luZzotLXNwYWNpbmcoNCldIGhhcy1kYXRhLVtzbG90PWNhcmQtZm9vdGVyXTpwYi0wIGhhcy1bPmltZzpmaXJzdC1jaGlsZF06cHQtMCBkYXRhLVtzaXplPXNtXTpbLS1jYXJkLXNwYWNpbmc6LS1zcGFjaW5nKDMpXSBkYXRhLVtzaXplPXNtXTpoYXMtZGF0YS1bc2xvdD1jYXJkLWZvb3Rlcl06cGItMCAqOltpbWc6Zmlyc3QtY2hpbGRdOnJvdW5kZWQtdC14bCAqOltpbWc6bGFzdC1jaGlsZF06cm91bmRlZC1iLXhsXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIENhcmRIZWFkZXIoeyBjbGFzc05hbWUsIC4uLnByb3BzIH06IFJlYWN0LkNvbXBvbmVudFByb3BzPFwiZGl2XCI+KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgZGF0YS1zbG90PVwiY2FyZC1oZWFkZXJcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJncm91cC9jYXJkLWhlYWRlciBAY29udGFpbmVyL2NhcmQtaGVhZGVyIGdyaWQgYXV0by1yb3dzLW1pbiBpdGVtcy1zdGFydCBnYXAtMSByb3VuZGVkLXQteGwgcHgtKC0tY2FyZC1zcGFjaW5nKSBoYXMtZGF0YS1bc2xvdD1jYXJkLWFjdGlvbl06Z3JpZC1jb2xzLVsxZnJfYXV0b10gaGFzLWRhdGEtW3Nsb3Q9Y2FyZC1kZXNjcmlwdGlvbl06Z3JpZC1yb3dzLVthdXRvX2F1dG9dIFsuYm9yZGVyLWJdOnBiLSgtLWNhcmQtc3BhY2luZylcIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZnVuY3Rpb24gQ2FyZFRpdGxlKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9OiBSZWFjdC5Db21wb25lbnRQcm9wczxcImRpdlwiPikge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGRhdGEtc2xvdD1cImNhcmQtdGl0bGVcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJmb250LWhlYWRpbmcgdGV4dC1iYXNlIGxlYWRpbmctc251ZyBmb250LW1lZGl1bSBncm91cC1kYXRhLVtzaXplPXNtXS9jYXJkOnRleHQtc21cIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZnVuY3Rpb24gQ2FyZERlc2NyaXB0aW9uKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9OiBSZWFjdC5Db21wb25lbnRQcm9wczxcImRpdlwiPikge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGRhdGEtc2xvdD1cImNhcmQtZGVzY3JpcHRpb25cIlxuICAgICAgY2xhc3NOYW1lPXtjbihcInRleHQtc20gdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIsIGNsYXNzTmFtZSl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBDYXJkQWN0aW9uKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9OiBSZWFjdC5Db21wb25lbnRQcm9wczxcImRpdlwiPikge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGRhdGEtc2xvdD1cImNhcmQtYWN0aW9uXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiY29sLXN0YXJ0LTIgcm93LXNwYW4tMiByb3ctc3RhcnQtMSBzZWxmLXN0YXJ0IGp1c3RpZnktc2VsZi1lbmRcIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZnVuY3Rpb24gQ2FyZENvbnRlbnQoeyBjbGFzc05hbWUsIC4uLnByb3BzIH06IFJlYWN0LkNvbXBvbmVudFByb3BzPFwiZGl2XCI+KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgZGF0YS1zbG90PVwiY2FyZC1jb250ZW50XCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXCJweC0oLS1jYXJkLXNwYWNpbmcpXCIsIGNsYXNzTmFtZSl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBDYXJkRm9vdGVyKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9OiBSZWFjdC5Db21wb25lbnRQcm9wczxcImRpdlwiPikge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGRhdGEtc2xvdD1cImNhcmQtZm9vdGVyXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiZmxleCBpdGVtcy1jZW50ZXIgcm91bmRlZC1iLXhsIGJvcmRlci10IGJnLW11dGVkLzUwIHAtKC0tY2FyZC1zcGFjaW5nKVwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5leHBvcnQge1xuICBDYXJkLFxuICBDYXJkSGVhZGVyLFxuICBDYXJkRm9vdGVyLFxuICBDYXJkVGl0bGUsXG4gIENhcmRBY3Rpb24sXG4gIENhcmREZXNjcmlwdGlvbixcbiAgQ2FyZENvbnRlbnQsXG59XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9jb21wb25lbnRzL3VpL2NhcmQudHN4In0=