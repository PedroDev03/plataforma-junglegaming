import { n as __exportAll, r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=e9f94b2e";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-cNwuCTLA.js?v=e9f94b2e";
import { r as useIsoLayoutEffect } from "/node_modules/.vite/deps/formatErrorMessage-BEgQI17N.js?v=e9f94b2e";
import { l as getWindow } from "/node_modules/.vite/deps/floating-ui.utils.dom-B45hE2lE.js?v=e9f94b2e";
import { c as EMPTY_OBJECT, n as useRenderElement, o as useMergedRefs } from "/node_modules/.vite/deps/useRenderElement-CvMw8z9e.js?v=e9f94b2e";
import { a as transitionStatusMapping, o as endingStyle$1, r as useTransitionStatus, s as startingStyle$1, t as useOpenChangeComplete } from "/node_modules/.vite/deps/useOpenChangeComplete-BJDlY1Cs.js?v=e9f94b2e";
import { h as none, w as createChangeEventDetails } from "/node_modules/.vite/deps/reason-parts-D-IkPsXA.js?v=e9f94b2e";
import { n as visuallyHiddenInput, t as visuallyHidden } from "/node_modules/.vite/deps/visuallyHidden-DjYUaVmG.js?v=e9f94b2e";
import { t as useBaseUiId } from "/node_modules/.vite/deps/useBaseUiId-UM7l9pLZ.js?v=e9f94b2e";
import { r as mergeProps } from "/node_modules/.vite/deps/merge-props-v5iSnvoO.js?v=e9f94b2e";
import { n as dispatchClickWithModifiers, t as useButton } from "/node_modules/.vite/deps/useButton-DC28DUmR.js?v=e9f94b2e";
import { t as useValueChanged } from "/node_modules/.vite/deps/useValueChanged-DCSKsMx_.js?v=e9f94b2e";
import { t as useControlled } from "/node_modules/.vite/deps/useControlled-BzU0LOuy.js?v=e9f94b2e";
import { i as fieldValidityMapping, n as useFieldRootContext, t as useLabelableContext } from "/node_modules/.vite/deps/LabelableContext-DbTSnt6H.js?v=e9f94b2e";
import { n as useSetFieldFocused, t as useLabelableId } from "/node_modules/.vite/deps/useLabelableId-ZH4XHyqG.js?v=e9f94b2e";
import { n as useRegisterFieldControl, t as useFormContext } from "/node_modules/.vite/deps/FormContext-CZZj3phG.js?v=e9f94b2e";
import { t as useFieldItemContext } from "/node_modules/.vite/deps/FieldItemContext-Cb6W874G.js?v=e9f94b2e";
import { t as useAriaLabelledBy } from "/node_modules/.vite/deps/useAriaLabelledBy-Cz-0E6Ky.js?v=e9f94b2e";
// node_modules/@base-ui/utils/getDefaultFormSubmitter.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* Returns the default button a browser uses for implicit form submission.
*
* This is useful for custom form controls that need to mirror native Enter key behavior.
* Clicking the returned submitter preserves browser semantics such as the submitter's click
* event, `SubmitEvent.submitter`, and submitter-specific attributes.
*
* The function follows the controls exposed by `form.elements`, which includes controls associated
* through the `form` attribute. Disabled submitters can be returned because the default button is
* determined before disabled state is considered; clicking a disabled submitter is a no-op.
*/
function getDefaultFormSubmitter(form) {
	if (!form) return null;
	for (const candidate of form.elements) {
		const tagName = candidate.tagName;
		if (tagName === "BUTTON" || tagName === "INPUT") {
			const button = candidate;
			if (button.type === "submit") return button;
		}
	}
	return null;
}
// node_modules/@base-ui/react/checkbox/root/CheckboxRootDataAttributes.mjs
var CheckboxRootDataAttributes_exports = /* @__PURE__ */ __exportAll({
	checked: () => checked$1,
	dirty: () => dirty$1,
	disabled: () => disabled$1,
	filled: () => filled$1,
	focused: () => focused$1,
	indeterminate: () => indeterminate$1,
	invalid: () => invalid$1,
	readonly: () => readonly$1,
	required: () => required$1,
	touched: () => touched$1,
	unchecked: () => unchecked$1,
	valid: () => valid$1
});
/**
* Present when the checkbox is checked.
*/
var checked$1 = "data-checked";
/**
* Present when the checkbox is not checked.
*/
var unchecked$1 = "data-unchecked";
/**
* Present when the checkbox is in an indeterminate state.
*/
var indeterminate$1 = "data-indeterminate";
/**
* Present when the checkbox is disabled.
*/
var disabled$1 = "data-disabled";
/**
* Present when the checkbox is readonly.
*/
var readonly$1 = "data-readonly";
/**
* Present when the checkbox is required.
*/
var required$1 = "data-required";
/**
* Present when the checkbox is in a valid state (when wrapped in Field.Root).
*/
var valid$1 = "data-valid";
/**
* Present when the checkbox is in an invalid state (when wrapped in Field.Root).
*/
var invalid$1 = "data-invalid";
/**
* Present when the checkbox has been touched (when wrapped in Field.Root).
*/
var touched$1 = "data-touched";
/**
* Present when the checkbox's value has changed (when wrapped in Field.Root).
*/
var dirty$1 = "data-dirty";
/**
* Present when the checkbox is checked (when wrapped in Field.Root).
*/
var filled$1 = "data-filled";
/**
* Present when the checkbox is focused (when wrapped in Field.Root).
*/
var focused$1 = "data-focused";
// node_modules/@base-ui/react/checkbox/utils/getCheckboxStateAttributesMapping.mjs
function getCheckboxStateAttributesMapping(state) {
	return {
		checked(value) {
			if (state.indeterminate) return {};
			if (value) return { [checked$1]: "" };
			return { [unchecked$1]: "" };
		},
		...fieldValidityMapping
	};
}
// node_modules/@base-ui/react/checkbox-group/CheckboxGroupContext.mjs
var CheckboxGroupContext = /*#__PURE__*/ import_react.createContext(void 0);
CheckboxGroupContext.displayName = "CheckboxGroupContext";
function useCheckboxGroupContext() {
	return import_react.useContext(CheckboxGroupContext);
}
// node_modules/@base-ui/react/checkbox/root/CheckboxRootContext.mjs
var CheckboxRootContext = /*#__PURE__*/ import_react.createContext(void 0);
CheckboxRootContext.displayName = "CheckboxRootContext";
function useCheckboxRootContext() {
	const context = import_react.useContext(CheckboxRootContext);
	if (context === void 0) throw new Error("Base UI: CheckboxRootContext is missing. Checkbox parts must be placed within <Checkbox.Root>.");
	return context;
}
// node_modules/@base-ui/react/checkbox/root/CheckboxRoot.mjs
var import_jsx_runtime = require_jsx_runtime();
var PARENT_CHECKBOX = "data-parent";
/**
* Represents the checkbox itself.
* Renders a `<span>` element and a hidden `<input>` beside.
*
* Documentation: [Base UI Checkbox](https://base-ui.com/react/components/checkbox)
*/
var CheckboxRoot = /*#__PURE__*/ import_react.forwardRef(function CheckboxRoot(componentProps, forwardedRef) {
	const { checked: checkedProp, className, defaultChecked = false, "aria-labelledby": ariaLabelledByProp, disabled: disabledProp = false, form, id: idProp, indeterminate = false, inputRef: inputRefProp, name: nameProp, onCheckedChange, parent = false, readOnly = false, render, required = false, uncheckedValue, value: valueProp, nativeButton = false, style, ...elementProps } = componentProps;
	const { clearErrors } = useFormContext();
	const { disabled: rootDisabled, name: fieldName, setDirty, setFilled, setTouched, state: fieldState, validationMode, validityData, validation: localValidation } = useFieldRootContext();
	const fieldItemContext = useFieldItemContext();
	const { labelId, registerControlId, getDescriptionProps } = useLabelableContext();
	const groupContext = useCheckboxGroupContext();
	const parentContext = groupContext?.allValues === void 0 ? void 0 : groupContext.parent;
	const isGroupedWithParent = parentContext !== void 0;
	const disabled = rootDisabled || fieldItemContext.disabled || groupContext?.disabled || disabledProp;
	const name = fieldName ?? nameProp;
	const value = valueProp ?? name;
	const id = useBaseUiId();
	const ownsControlId = groupContext?.registerControlId !== registerControlId;
	const controlId = useLabelableId({
		id: idProp || void 0,
		enabled: ownsControlId
	});
	const rootId = nativeButton ? controlId : id;
	let groupProps = {};
	if (isGroupedWithParent) {
		if (parent) groupProps = parentContext.getParentProps();
		else if (value !== void 0) groupProps = parentContext.getChildProps(value);
	}
	const { checked: groupChecked = checkedProp, indeterminate: groupIndeterminate = indeterminate, onCheckedChange: groupOnChange, ...otherGroupProps } = groupProps;
	const groupValue = groupContext?.value;
	const controlRef = import_react.useRef(null);
	const setFocused = useSetFieldFocused(disabled, controlRef);
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	const validation = groupContext?.validation ?? localValidation;
	const [checked, setCheckedState] = useControlled({
		controlled: value !== void 0 && groupValue !== void 0 && !parent ? groupValue.includes(value) : groupChecked,
		default: defaultChecked,
		name: "Checkbox",
		state: "checked"
	});
	const computedChecked = isGroupedWithParent ? Boolean(groupChecked) : checked;
	const computedIndeterminate = isGroupedWithParent ? groupIndeterminate || indeterminate : indeterminate;
	useRegisterFieldControl(controlRef, id, checked, void 0, !groupContext && !disabled, nameProp);
	const registerChildId = parentContext?.registerChildId;
	const inputRef = import_react.useRef(null);
	const registerFieldInput = validation.registerInput;
	const registeredInputValue = groupContext ? value : void 0;
	const registerInput = import_react.useCallback((element) => registerFieldInput(element, {
		controlRef,
		value: registeredInputValue
	}), [registerFieldInput, registeredInputValue]);
	const mergedInputRef = useMergedRefs(inputRefProp, inputRef, parent ? void 0 : registerInput);
	const ariaLabelledBy = useAriaLabelledBy(ariaLabelledByProp, labelId, inputRef, !nativeButton, controlId, elementProps["aria-label"]);
	useIsoLayoutEffect(() => {
		if (inputRef.current) inputRef.current.indeterminate = computedIndeterminate;
		if (!groupContext) setFilled(checked);
	}, [
		checked,
		computedIndeterminate,
		groupContext,
		setFilled
	]);
	useValueChanged(checked, () => {
		if (groupContext) return;
		clearErrors(name);
		setDirty(checked !== validityData.initialValue);
		validation.change(checked);
	});
	const inputProps = mergeProps({
		checked,
		disabled,
		form,
		name: parent ? void 0 : name,
		id: nativeButton ? void 0 : controlId,
		required,
		ref: mergedInputRef,
		style: name ? visuallyHiddenInput : visuallyHidden,
		tabIndex: -1,
		type: "checkbox",
		"aria-hidden": true,
		onChange(event) {
			if (event.nativeEvent.defaultPrevented) return;
			if (readOnly) {
				event.preventDefault();
				return;
			}
			const nextChecked = event.currentTarget.checked;
			const details = createChangeEventDetails(none, event.nativeEvent);
			onCheckedChange?.(nextChecked, details);
			if (details.isCanceled) return;
			groupOnChange?.(nextChecked, details);
			if (details.isCanceled) return;
			setCheckedState(nextChecked);
			if (value !== void 0 && groupContext !== void 0 && !parent && !isGroupedWithParent) {
				const nextGroupValue = nextChecked ? [...groupContext.value, value] : groupContext.value.filter((item) => item !== value);
				groupContext.setValue(nextGroupValue, details);
			}
		},
		onClick(event) {
			event.stopPropagation();
		},
		onFocus() {
			controlRef.current?.focus();
		}
	}, valueProp !== void 0 ? { value: (groupContext ? checked && valueProp : valueProp) || "" } : EMPTY_OBJECT, getDescriptionProps, (props) => validation.getValidationProps(disabled, props));
	import_react.useEffect(() => {
		if (!parentContext || value === void 0) return;
		const disabledStates = parentContext.disabledStatesRef.current;
		disabledStates.set(value, disabled);
		return () => {
			disabledStates.delete(value);
		};
	}, [
		parentContext,
		disabled,
		value
	]);
	const state = import_react.useMemo(() => ({
		...fieldState,
		checked: computedChecked,
		disabled,
		readOnly,
		required,
		indeterminate: computedIndeterminate
	}), [
		fieldState,
		computedChecked,
		disabled,
		readOnly,
		required,
		computedIndeterminate
	]);
	const stateAttributesMapping = getCheckboxStateAttributesMapping(state);
	const element = useRenderElement("span", componentProps, {
		state,
		ref: [
			buttonRef,
			controlRef,
			forwardedRef
		],
		props: [
			{
				id: rootId,
				role: "checkbox",
				"aria-checked": computedIndeterminate ? "mixed" : computedChecked,
				"aria-readonly": readOnly || void 0,
				"aria-required": required || void 0,
				"aria-labelledby": ariaLabelledBy,
				[PARENT_CHECKBOX]: parent ? "" : void 0,
				onFocus() {
					setFocused(true);
				},
				onBlur() {
					const inputEl = inputRef.current;
					if (!inputEl) return;
					setTouched(true);
					setFocused(false);
					if (validationMode === "onBlur") validation.commit(groupContext ? groupValue : inputEl.checked);
				},
				onKeyDown(event) {
					if (event.key !== "Enter") return;
					event.preventBaseUIHandler();
					if (event.defaultPrevented) return;
					const formToSubmit = inputRef.current?.form ?? null;
					const currentTarget = event.currentTarget;
					const nativeEvent = event.nativeEvent;
					const originalPreventDefault = event.preventDefault;
					const originalNativePreventDefault = nativeEvent.preventDefault;
					let preventDefaultCalledAfterPropagation = false;
					event.preventDefault = () => {
						preventDefaultCalledAfterPropagation = true;
						originalPreventDefault.call(event);
					};
					nativeEvent.preventDefault = () => {
						preventDefaultCalledAfterPropagation = true;
						originalNativePreventDefault.call(nativeEvent);
					};
					originalNativePreventDefault.call(nativeEvent);
					getWindow(currentTarget).queueMicrotask(() => {
						event.preventDefault = originalPreventDefault;
						nativeEvent.preventDefault = originalNativePreventDefault;
						if (!preventDefaultCalledAfterPropagation) getDefaultFormSubmitter(formToSubmit)?.click();
					});
				},
				onClick(event) {
					if (readOnly || disabled) return;
					event.preventDefault();
					const input = inputRef.current;
					if (!input) return;
					dispatchClickWithModifiers(input, event);
				}
			},
			elementProps,
			otherGroupProps,
			getButtonProps,
			getDescriptionProps,
			(props) => validation.getValidationProps(disabled, props)
		],
		stateAttributesMapping
	});
	const renderedId = element.props.id;
	useIsoLayoutEffect(() => {
		if (!registerChildId || parent || value === void 0 || renderedId === void 0) return;
		return registerChildId(value, renderedId);
	}, [
		registerChildId,
		parent,
		value,
		renderedId
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(CheckboxRootContext.Provider, {
		value: state,
		children: [
			element,
			!checked && !groupContext && name && !parent && uncheckedValue !== void 0 && /*#__PURE__*/ (0, import_jsx_runtime.jsx)("input", {
				type: "hidden",
				form,
				name,
				value: uncheckedValue,
				disabled
			}),
			/*#__PURE__*/ (0, import_jsx_runtime.jsx)("input", {
				...inputProps,
				suppressHydrationWarning: true
			})
		]
	});
});
CheckboxRoot.displayName = "CheckboxRoot";
// node_modules/@base-ui/react/checkbox/indicator/CheckboxIndicator.mjs
/**
* Indicates whether the checkbox is ticked.
* Renders a `<span>` element.
*
* Documentation: [Base UI Checkbox](https://base-ui.com/react/components/checkbox)
*/
var CheckboxIndicator = /*#__PURE__*/ import_react.forwardRef(function CheckboxIndicator(componentProps, forwardedRef) {
	const { render, className, style, keepMounted = false, ...elementProps } = componentProps;
	const rootState = useCheckboxRootContext();
	const rendered = rootState.checked || rootState.indeterminate;
	const { mounted, transitionStatus, setMounted } = useTransitionStatus(rendered);
	const indicatorRef = import_react.useRef(null);
	const state = {
		...rootState,
		transitionStatus
	};
	useOpenChangeComplete({
		batch: true,
		enabled: !rendered,
		open: rendered,
		ref: indicatorRef,
		onComplete() {
			if (!rendered) setMounted(false);
		}
	});
	const stateAttributesMapping = {
		...getCheckboxStateAttributesMapping(rootState),
		...transitionStatusMapping
	};
	const shouldRender = keepMounted || mounted;
	const element = useRenderElement("span", componentProps, {
		ref: [forwardedRef, indicatorRef],
		state,
		stateAttributesMapping,
		props: elementProps
	});
	if (!shouldRender) return null;
	return element;
});
CheckboxIndicator.displayName = "CheckboxIndicator";
// node_modules/@base-ui/react/checkbox/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Indicator: () => CheckboxIndicator,
	Root: () => CheckboxRoot
});
// node_modules/@base-ui/react/checkbox/indicator/CheckboxIndicatorDataAttributes.mjs
var CheckboxIndicatorDataAttributes_exports = /* @__PURE__ */ __exportAll({
	checked: () => checked,
	dirty: () => dirty,
	disabled: () => disabled,
	endingStyle: () => endingStyle,
	filled: () => filled,
	focused: () => focused,
	indeterminate: () => indeterminate,
	invalid: () => invalid,
	readonly: () => readonly,
	required: () => required,
	startingStyle: () => startingStyle,
	touched: () => touched,
	unchecked: () => unchecked,
	valid: () => valid
});
/**
* Present when the checkbox is checked.
*/
var checked = "data-checked";
/**
* Present when the checkbox is not checked.
*/
var unchecked = "data-unchecked";
/**
* Present when the checkbox is in an indeterminate state.
*/
var indeterminate = "data-indeterminate";
/**
* Present when the checkbox is disabled.
*/
var disabled = "data-disabled";
/**
* Present when the checkbox is readonly.
*/
var readonly = "data-readonly";
/**
* Present when the checkbox is required.
*/
var required = "data-required";
/**
* Present when the checkbox indicator begins animating in.
*/
var startingStyle = startingStyle$1;
/**
* Present when the checkbox indicator is animating out.
*/
var endingStyle = endingStyle$1;
/**
* Present when the checkbox is in a valid state (when wrapped in Field.Root).
*/
var valid = "data-valid";
/**
* Present when the checkbox is in an invalid state (when wrapped in Field.Root).
*/
var invalid = "data-invalid";
/**
* Present when the checkbox has been touched (when wrapped in Field.Root).
*/
var touched = "data-touched";
/**
* Present when the checkbox's value has changed (when wrapped in Field.Root).
*/
var dirty = "data-dirty";
/**
* Present when the checkbox is checked (when wrapped in Field.Root).
*/
var filled = "data-filled";
/**
* Present when the checkbox is focused (when wrapped in Field.Root).
*/
var focused = "data-focused";
export { index_parts_exports as Checkbox, CheckboxIndicatorDataAttributes_exports as CheckboxIndicatorDataAttributes, CheckboxRootDataAttributes_exports as CheckboxRootDataAttributes };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQGJhc2UtdWlfcmVhY3RfY2hlY2tib3guanMiLCJuYW1lcyI6WyJjaGVja2VkIiwidW5jaGVja2VkIiwiaW5kZXRlcm1pbmF0ZSIsImRpc2FibGVkIiwicmVhZG9ubHkiLCJyZXF1aXJlZCIsInZhbGlkIiwiaW52YWxpZCIsInRvdWNoZWQiLCJkaXJ0eSIsImZpbGxlZCIsImZvY3VzZWQiLCJDaGVja2JveFJvb3REYXRhQXR0cmlidXRlcy5jaGVja2VkIiwiQ2hlY2tib3hSb290RGF0YUF0dHJpYnV0ZXMudW5jaGVja2VkIiwiUkVBU09OUy5ub25lIiwiVHJhbnNpdGlvblN0YXR1c0RhdGFBdHRyaWJ1dGVzLnN0YXJ0aW5nU3R5bGUiLCJUcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMuZW5kaW5nU3R5bGUiXSwic291cmNlcyI6WyIuLi8uLi9AYmFzZS11aS91dGlscy9nZXREZWZhdWx0Rm9ybVN1Ym1pdHRlci5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9jaGVja2JveC9yb290L0NoZWNrYm94Um9vdERhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2NoZWNrYm94L3V0aWxzL2dldENoZWNrYm94U3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9jaGVja2JveC1ncm91cC9DaGVja2JveEdyb3VwQ29udGV4dC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9jaGVja2JveC9yb290L0NoZWNrYm94Um9vdENvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvY2hlY2tib3gvcm9vdC9DaGVja2JveFJvb3QubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvY2hlY2tib3gvaW5kaWNhdG9yL0NoZWNrYm94SW5kaWNhdG9yLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2NoZWNrYm94L2luZGV4LnBhcnRzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2NoZWNrYm94L2luZGljYXRvci9DaGVja2JveEluZGljYXRvckRhdGFBdHRyaWJ1dGVzLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIFJldHVybnMgdGhlIGRlZmF1bHQgYnV0dG9uIGEgYnJvd3NlciB1c2VzIGZvciBpbXBsaWNpdCBmb3JtIHN1Ym1pc3Npb24uXG4gKlxuICogVGhpcyBpcyB1c2VmdWwgZm9yIGN1c3RvbSBmb3JtIGNvbnRyb2xzIHRoYXQgbmVlZCB0byBtaXJyb3IgbmF0aXZlIEVudGVyIGtleSBiZWhhdmlvci5cbiAqIENsaWNraW5nIHRoZSByZXR1cm5lZCBzdWJtaXR0ZXIgcHJlc2VydmVzIGJyb3dzZXIgc2VtYW50aWNzIHN1Y2ggYXMgdGhlIHN1Ym1pdHRlcidzIGNsaWNrXG4gKiBldmVudCwgYFN1Ym1pdEV2ZW50LnN1Ym1pdHRlcmAsIGFuZCBzdWJtaXR0ZXItc3BlY2lmaWMgYXR0cmlidXRlcy5cbiAqXG4gKiBUaGUgZnVuY3Rpb24gZm9sbG93cyB0aGUgY29udHJvbHMgZXhwb3NlZCBieSBgZm9ybS5lbGVtZW50c2AsIHdoaWNoIGluY2x1ZGVzIGNvbnRyb2xzIGFzc29jaWF0ZWRcbiAqIHRocm91Z2ggdGhlIGBmb3JtYCBhdHRyaWJ1dGUuIERpc2FibGVkIHN1Ym1pdHRlcnMgY2FuIGJlIHJldHVybmVkIGJlY2F1c2UgdGhlIGRlZmF1bHQgYnV0dG9uIGlzXG4gKiBkZXRlcm1pbmVkIGJlZm9yZSBkaXNhYmxlZCBzdGF0ZSBpcyBjb25zaWRlcmVkOyBjbGlja2luZyBhIGRpc2FibGVkIHN1Ym1pdHRlciBpcyBhIG5vLW9wLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0RGVmYXVsdEZvcm1TdWJtaXR0ZXIoZm9ybSkge1xuICBpZiAoIWZvcm0pIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBmb3IgKGNvbnN0IGNhbmRpZGF0ZSBvZiBmb3JtLmVsZW1lbnRzKSB7XG4gICAgY29uc3QgdGFnTmFtZSA9IGNhbmRpZGF0ZS50YWdOYW1lO1xuICAgIGlmICh0YWdOYW1lID09PSAnQlVUVE9OJyB8fCB0YWdOYW1lID09PSAnSU5QVVQnKSB7XG4gICAgICBjb25zdCBidXR0b24gPSBjYW5kaWRhdGU7XG5cbiAgICAgIC8vIEludGVudGlvbmFsbHkgZXhjbHVkZXMgaW5wdXRbdHlwZT1cImltYWdlXCJdOiBDaHJvbWl1bSBvbWl0cyBpdCBmcm9tIGZvcm0uZWxlbWVudHMsXG4gICAgICAvLyBzbyBzdXBwb3J0aW5nIGl0IHdvdWxkIHJlcXVpcmUgc2VwYXJhdGUgdHJhdmVyc2FsIGZvciBhbiBleG90aWMgc3VibWl0dGVyIHR5cGUuXG4gICAgICBpZiAoYnV0dG9uLnR5cGUgPT09ICdzdWJtaXQnKSB7XG4gICAgICAgIHJldHVybiBidXR0b247XG4gICAgICB9XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufSIsIi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjaGVja2JveCBpcyBjaGVja2VkLlxuICovXG5leHBvcnQgY29uc3QgY2hlY2tlZCA9ICdkYXRhLWNoZWNrZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGNoZWNrYm94IGlzIG5vdCBjaGVja2VkLlxuICovXG5leHBvcnQgY29uc3QgdW5jaGVja2VkID0gJ2RhdGEtdW5jaGVja2VkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjaGVja2JveCBpcyBpbiBhbiBpbmRldGVybWluYXRlIHN0YXRlLlxuICovXG5leHBvcnQgY29uc3QgaW5kZXRlcm1pbmF0ZSA9ICdkYXRhLWluZGV0ZXJtaW5hdGUnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGNoZWNrYm94IGlzIGRpc2FibGVkLlxuICovXG5leHBvcnQgY29uc3QgZGlzYWJsZWQgPSAnZGF0YS1kaXNhYmxlZCc7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgY2hlY2tib3ggaXMgcmVhZG9ubHkuXG4gKi9cbmV4cG9ydCBjb25zdCByZWFkb25seSA9ICdkYXRhLXJlYWRvbmx5Jztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjaGVja2JveCBpcyByZXF1aXJlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IHJlcXVpcmVkID0gJ2RhdGEtcmVxdWlyZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGNoZWNrYm94IGlzIGluIGEgdmFsaWQgc3RhdGUgKHdoZW4gd3JhcHBlZCBpbiBGaWVsZC5Sb290KS5cbiAqL1xuZXhwb3J0IGNvbnN0IHZhbGlkID0gJ2RhdGEtdmFsaWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGNoZWNrYm94IGlzIGluIGFuIGludmFsaWQgc3RhdGUgKHdoZW4gd3JhcHBlZCBpbiBGaWVsZC5Sb290KS5cbiAqL1xuZXhwb3J0IGNvbnN0IGludmFsaWQgPSAnZGF0YS1pbnZhbGlkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjaGVja2JveCBoYXMgYmVlbiB0b3VjaGVkICh3aGVuIHdyYXBwZWQgaW4gRmllbGQuUm9vdCkuXG4gKi9cbmV4cG9ydCBjb25zdCB0b3VjaGVkID0gJ2RhdGEtdG91Y2hlZCc7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgY2hlY2tib3gncyB2YWx1ZSBoYXMgY2hhbmdlZCAod2hlbiB3cmFwcGVkIGluIEZpZWxkLlJvb3QpLlxuICovXG5leHBvcnQgY29uc3QgZGlydHkgPSAnZGF0YS1kaXJ0eSc7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgY2hlY2tib3ggaXMgY2hlY2tlZCAod2hlbiB3cmFwcGVkIGluIEZpZWxkLlJvb3QpLlxuICovXG5leHBvcnQgY29uc3QgZmlsbGVkID0gJ2RhdGEtZmlsbGVkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjaGVja2JveCBpcyBmb2N1c2VkICh3aGVuIHdyYXBwZWQgaW4gRmllbGQuUm9vdCkuXG4gKi9cbmV4cG9ydCBjb25zdCBmb2N1c2VkID0gJ2RhdGEtZm9jdXNlZCc7IiwiaW1wb3J0IHsgZmllbGRWYWxpZGl0eU1hcHBpbmcgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2ZpZWxkLWNvbnN0YW50cy9jb25zdGFudHMubWpzXCI7XG5pbXBvcnQgKiBhcyBDaGVja2JveFJvb3REYXRhQXR0cmlidXRlcyBmcm9tIFwiLi4vcm9vdC9DaGVja2JveFJvb3REYXRhQXR0cmlidXRlcy5tanNcIjtcbmV4cG9ydCBmdW5jdGlvbiBnZXRDaGVja2JveFN0YXRlQXR0cmlidXRlc01hcHBpbmcoc3RhdGUpIHtcbiAgcmV0dXJuIHtcbiAgICBjaGVja2VkKHZhbHVlKSB7XG4gICAgICBpZiAoc3RhdGUuaW5kZXRlcm1pbmF0ZSkge1xuICAgICAgICAvLyBgZGF0YS1pbmRldGVybWluYXRlYCBpcyBhbHJlYWR5IGhhbmRsZWQgYnkgdGhlIGBpbmRldGVybWluYXRlYCBwcm9wLlxuICAgICAgICByZXR1cm4ge307XG4gICAgICB9XG4gICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBbQ2hlY2tib3hSb290RGF0YUF0dHJpYnV0ZXMuY2hlY2tlZF06ICcnXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICByZXR1cm4ge1xuICAgICAgICBbQ2hlY2tib3hSb290RGF0YUF0dHJpYnV0ZXMudW5jaGVja2VkXTogJydcbiAgICAgIH07XG4gICAgfSxcbiAgICAuLi5maWVsZFZhbGlkaXR5TWFwcGluZ1xuICB9O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IENoZWNrYm94R3JvdXBDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIENoZWNrYm94R3JvdXBDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJDaGVja2JveEdyb3VwQ29udGV4dFwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUNoZWNrYm94R3JvdXBDb250ZXh0KCkge1xuICByZXR1cm4gUmVhY3QudXNlQ29udGV4dChDaGVja2JveEdyb3VwQ29udGV4dCk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgX2Zvcm1hdEVycm9yTWVzc2FnZSBmcm9tIFwiQGJhc2UtdWkvdXRpbHMvZm9ybWF0RXJyb3JNZXNzYWdlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgQ2hlY2tib3hSb290Q29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHVuZGVmaW5lZCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBDaGVja2JveFJvb3RDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJDaGVja2JveFJvb3RDb250ZXh0XCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlQ2hlY2tib3hSb290Q29udGV4dCgpIHtcbiAgY29uc3QgY29udGV4dCA9IFJlYWN0LnVzZUNvbnRleHQoQ2hlY2tib3hSb290Q29udGV4dCk7XG4gIGlmIChjb250ZXh0ID09PSB1bmRlZmluZWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gJ0Jhc2UgVUk6IENoZWNrYm94Um9vdENvbnRleHQgaXMgbWlzc2luZy4gQ2hlY2tib3ggcGFydHMgbXVzdCBiZSBwbGFjZWQgd2l0aGluIDxDaGVja2JveC5Sb290Pi4nIDogX2Zvcm1hdEVycm9yTWVzc2FnZSgxNCkpO1xuICB9XG4gIHJldHVybiBjb250ZXh0O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgRU1QVFlfT0JKRUNUIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuaW1wb3J0IHsgdXNlQ29udHJvbGxlZCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUNvbnRyb2xsZWQnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZU1lcmdlZFJlZnMgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VNZXJnZWRSZWZzJztcbmltcG9ydCB7IHZpc3VhbGx5SGlkZGVuLCB2aXN1YWxseUhpZGRlbklucHV0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdmlzdWFsbHlIaWRkZW4nO1xuaW1wb3J0IHsgb3duZXJXaW5kb3cgfSBmcm9tICdAYmFzZS11aS91dGlscy9vd25lcic7XG5pbXBvcnQgeyBnZXREZWZhdWx0Rm9ybVN1Ym1pdHRlciB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2dldERlZmF1bHRGb3JtU3VibWl0dGVyJztcbmltcG9ydCB7IGdldENoZWNrYm94U3RhdGVBdHRyaWJ1dGVzTWFwcGluZyB9IGZyb20gXCIuLi91dGlscy9nZXRDaGVja2JveFN0YXRlQXR0cmlidXRlc01hcHBpbmcubWpzXCI7XG5pbXBvcnQgeyBkaXNwYXRjaENsaWNrV2l0aE1vZGlmaWVycyB9IGZyb20gXCIuLi8uLi91dGlscy9kaXNwYXRjaENsaWNrV2l0aE1vZGlmaWVycy5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VCYXNlVWlJZCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlQmFzZVVpSWQubWpzXCI7XG5pbXBvcnQgeyBtZXJnZVByb3BzIH0gZnJvbSBcIi4uLy4uL21lcmdlLXByb3BzL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQnV0dG9uIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2UtYnV0dG9uL3VzZUJ1dHRvbi5tanNcIjtcbmltcG9ydCB7IHVzZUZpZWxkUm9vdENvbnRleHQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2ZpZWxkLXJvb3QtY29udGV4dC9GaWVsZFJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlU2V0RmllbGRGb2N1c2VkIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9maWVsZC1yb290LWNvbnRleHQvdXNlU2V0RmllbGRGb2N1c2VkLm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVnaXN0ZXJGaWVsZENvbnRyb2wgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2ZpZWxkLXJlZ2lzdGVyLWNvbnRyb2wvdXNlUmVnaXN0ZXJGaWVsZENvbnRyb2wubWpzXCI7XG5pbXBvcnQgeyB1c2VGaWVsZEl0ZW1Db250ZXh0IH0gZnJvbSBcIi4uLy4uL2ZpZWxkL2l0ZW0vRmllbGRJdGVtQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZUZvcm1Db250ZXh0IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9mb3JtLWNvbnRleHQvRm9ybUNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VMYWJlbGFibGVDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9sYWJlbGFibGUtcHJvdmlkZXIvTGFiZWxhYmxlQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZUFyaWFMYWJlbGxlZEJ5IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9sYWJlbGFibGUtcHJvdmlkZXIvdXNlQXJpYUxhYmVsbGVkQnkubWpzXCI7XG5pbXBvcnQgeyB1c2VMYWJlbGFibGVJZCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvbGFiZWxhYmxlLXByb3ZpZGVyL3VzZUxhYmVsYWJsZUlkLm1qc1wiO1xuaW1wb3J0IHsgdXNlQ2hlY2tib3hHcm91cENvbnRleHQgfSBmcm9tIFwiLi4vLi4vY2hlY2tib3gtZ3JvdXAvQ2hlY2tib3hHcm91cENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBDaGVja2JveFJvb3RDb250ZXh0IH0gZnJvbSBcIi4vQ2hlY2tib3hSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY3JlYXRlQmFzZVVJRXZlbnREZXRhaWxzLm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcbmltcG9ydCB7IHVzZVZhbHVlQ2hhbmdlZCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlVmFsdWVDaGFuZ2VkLm1qc1wiO1xuaW1wb3J0IHsganN4IGFzIF9qc3gsIGpzeHMgYXMgX2pzeHMgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCBjb25zdCBQQVJFTlRfQ0hFQ0tCT1ggPSAnZGF0YS1wYXJlbnQnO1xuXG4vKipcbiAqIFJlcHJlc2VudHMgdGhlIGNoZWNrYm94IGl0c2VsZi5cbiAqIFJlbmRlcnMgYSBgPHNwYW4+YCBlbGVtZW50IGFuZCBhIGhpZGRlbiBgPGlucHV0PmAgYmVzaWRlLlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIENoZWNrYm94XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvY2hlY2tib3gpXG4gKi9cbmV4cG9ydCBjb25zdCBDaGVja2JveFJvb3QgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBDaGVja2JveFJvb3QoY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgY2hlY2tlZDogY2hlY2tlZFByb3AsXG4gICAgY2xhc3NOYW1lLFxuICAgIGRlZmF1bHRDaGVja2VkID0gZmFsc2UsXG4gICAgJ2FyaWEtbGFiZWxsZWRieSc6IGFyaWFMYWJlbGxlZEJ5UHJvcCxcbiAgICBkaXNhYmxlZDogZGlzYWJsZWRQcm9wID0gZmFsc2UsXG4gICAgZm9ybSxcbiAgICBpZDogaWRQcm9wLFxuICAgIGluZGV0ZXJtaW5hdGUgPSBmYWxzZSxcbiAgICBpbnB1dFJlZjogaW5wdXRSZWZQcm9wLFxuICAgIG5hbWU6IG5hbWVQcm9wLFxuICAgIG9uQ2hlY2tlZENoYW5nZSxcbiAgICBwYXJlbnQgPSBmYWxzZSxcbiAgICByZWFkT25seSA9IGZhbHNlLFxuICAgIHJlbmRlcixcbiAgICByZXF1aXJlZCA9IGZhbHNlLFxuICAgIHVuY2hlY2tlZFZhbHVlLFxuICAgIHZhbHVlOiB2YWx1ZVByb3AsXG4gICAgbmF0aXZlQnV0dG9uID0gZmFsc2UsXG4gICAgc3R5bGUsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qge1xuICAgIGNsZWFyRXJyb3JzXG4gIH0gPSB1c2VGb3JtQ29udGV4dCgpO1xuICBjb25zdCB7XG4gICAgZGlzYWJsZWQ6IHJvb3REaXNhYmxlZCxcbiAgICBuYW1lOiBmaWVsZE5hbWUsXG4gICAgc2V0RGlydHksXG4gICAgc2V0RmlsbGVkLFxuICAgIHNldFRvdWNoZWQsXG4gICAgc3RhdGU6IGZpZWxkU3RhdGUsXG4gICAgdmFsaWRhdGlvbk1vZGUsXG4gICAgdmFsaWRpdHlEYXRhLFxuICAgIHZhbGlkYXRpb246IGxvY2FsVmFsaWRhdGlvblxuICB9ID0gdXNlRmllbGRSb290Q29udGV4dCgpO1xuICBjb25zdCBmaWVsZEl0ZW1Db250ZXh0ID0gdXNlRmllbGRJdGVtQ29udGV4dCgpO1xuICBjb25zdCB7XG4gICAgbGFiZWxJZCxcbiAgICByZWdpc3RlckNvbnRyb2xJZCxcbiAgICBnZXREZXNjcmlwdGlvblByb3BzXG4gIH0gPSB1c2VMYWJlbGFibGVDb250ZXh0KCk7XG4gIGNvbnN0IGdyb3VwQ29udGV4dCA9IHVzZUNoZWNrYm94R3JvdXBDb250ZXh0KCk7XG4gIGNvbnN0IHBhcmVudENvbnRleHQgPSBncm91cENvbnRleHQ/LmFsbFZhbHVlcyA9PT0gdW5kZWZpbmVkID8gdW5kZWZpbmVkIDogZ3JvdXBDb250ZXh0LnBhcmVudDtcbiAgY29uc3QgaXNHcm91cGVkV2l0aFBhcmVudCA9IHBhcmVudENvbnRleHQgIT09IHVuZGVmaW5lZDtcbiAgY29uc3QgZGlzYWJsZWQgPSByb290RGlzYWJsZWQgfHwgZmllbGRJdGVtQ29udGV4dC5kaXNhYmxlZCB8fCBncm91cENvbnRleHQ/LmRpc2FibGVkIHx8IGRpc2FibGVkUHJvcDtcbiAgY29uc3QgbmFtZSA9IGZpZWxkTmFtZSA/PyBuYW1lUHJvcDtcbiAgY29uc3QgdmFsdWUgPSB2YWx1ZVByb3AgPz8gbmFtZTtcbiAgY29uc3QgaWQgPSB1c2VCYXNlVWlJZCgpO1xuXG4gIC8vIEEgYENoZWNrYm94R3JvdXBgIGlzIHRoZSBmaWVsZCdzIGNvbnRyb2wgYW5kIHRha2VzIGl0cyBuYW1lIGZyb20gYGFyaWEtbGFiZWxsZWRieWAsIHNvIHRoZVxuICAvLyBjaGVja2JveGVzIHNoYXJpbmcgaXRzIGxhYmVsYWJsZSBzY29wZSBtdXN0IG5vdCBjbGFpbSB0aGUgZmllbGQncyBjb250cm9sIGlkOiB0aGV5IHdvdWxkIGFsbFxuICAvLyByZW5kZXIgdGhhdCBvbmUgaWQgYW5kIGNvbGxpZGUuIEEgYEZpZWxkLkl0ZW1gIG9wZW5zIGEgc2NvcGUgdGhlIGNoZWNrYm94IGRvZXMgb3duLlxuICBjb25zdCBvd25zQ29udHJvbElkID0gZ3JvdXBDb250ZXh0Py5yZWdpc3RlckNvbnRyb2xJZCAhPT0gcmVnaXN0ZXJDb250cm9sSWQ7XG5cbiAgLy8gYHx8IHVuZGVmaW5lZGAgcmF0aGVyIHRoYW4gYD8/YDogYW4gZW1wdHkgYGlkYCBmYWxscyBiYWNrIHRvIHRoZSBzY29wZSdzIGNvbnRyb2wgaWQuXG4gIGNvbnN0IGNvbnRyb2xJZCA9IHVzZUxhYmVsYWJsZUlkKHtcbiAgICBpZDogaWRQcm9wIHx8IHVuZGVmaW5lZCxcbiAgICBlbmFibGVkOiBvd25zQ29udHJvbElkXG4gIH0pO1xuICBjb25zdCByb290SWQgPSBuYXRpdmVCdXR0b24gPyBjb250cm9sSWQgOiBpZDtcbiAgbGV0IGdyb3VwUHJvcHMgPSB7fTtcbiAgaWYgKGlzR3JvdXBlZFdpdGhQYXJlbnQpIHtcbiAgICBpZiAocGFyZW50KSB7XG4gICAgICBncm91cFByb3BzID0gcGFyZW50Q29udGV4dC5nZXRQYXJlbnRQcm9wcygpO1xuICAgIH0gZWxzZSBpZiAodmFsdWUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgZ3JvdXBQcm9wcyA9IHBhcmVudENvbnRleHQuZ2V0Q2hpbGRQcm9wcyh2YWx1ZSk7XG4gICAgfVxuICB9XG4gIGNvbnN0IHtcbiAgICBjaGVja2VkOiBncm91cENoZWNrZWQgPSBjaGVja2VkUHJvcCxcbiAgICBpbmRldGVybWluYXRlOiBncm91cEluZGV0ZXJtaW5hdGUgPSBpbmRldGVybWluYXRlLFxuICAgIG9uQ2hlY2tlZENoYW5nZTogZ3JvdXBPbkNoYW5nZSxcbiAgICAuLi5vdGhlckdyb3VwUHJvcHNcbiAgfSA9IGdyb3VwUHJvcHM7XG4gIGNvbnN0IGdyb3VwVmFsdWUgPSBncm91cENvbnRleHQ/LnZhbHVlO1xuICBjb25zdCBjb250cm9sUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBzZXRGb2N1c2VkID0gdXNlU2V0RmllbGRGb2N1c2VkKGRpc2FibGVkLCBjb250cm9sUmVmKTtcbiAgY29uc3Qge1xuICAgIGdldEJ1dHRvblByb3BzLFxuICAgIGJ1dHRvblJlZlxuICB9ID0gdXNlQnV0dG9uKHtcbiAgICBkaXNhYmxlZCxcbiAgICBuYXRpdmU6IG5hdGl2ZUJ1dHRvblxuICB9KTtcbiAgY29uc3QgdmFsaWRhdGlvbiA9IGdyb3VwQ29udGV4dD8udmFsaWRhdGlvbiA/PyBsb2NhbFZhbGlkYXRpb247XG4gIGNvbnN0IFtjaGVja2VkLCBzZXRDaGVja2VkU3RhdGVdID0gdXNlQ29udHJvbGxlZCh7XG4gICAgY29udHJvbGxlZDogdmFsdWUgIT09IHVuZGVmaW5lZCAmJiBncm91cFZhbHVlICE9PSB1bmRlZmluZWQgJiYgIXBhcmVudCA/IGdyb3VwVmFsdWUuaW5jbHVkZXModmFsdWUpIDogZ3JvdXBDaGVja2VkLFxuICAgIGRlZmF1bHQ6IGRlZmF1bHRDaGVja2VkLFxuICAgIG5hbWU6ICdDaGVja2JveCcsXG4gICAgc3RhdGU6ICdjaGVja2VkJ1xuICB9KTtcbiAgY29uc3QgY29tcHV0ZWRDaGVja2VkID0gaXNHcm91cGVkV2l0aFBhcmVudCA/IEJvb2xlYW4oZ3JvdXBDaGVja2VkKSA6IGNoZWNrZWQ7XG4gIGNvbnN0IGNvbXB1dGVkSW5kZXRlcm1pbmF0ZSA9IGlzR3JvdXBlZFdpdGhQYXJlbnQgPyBncm91cEluZGV0ZXJtaW5hdGUgfHwgaW5kZXRlcm1pbmF0ZSA6IGluZGV0ZXJtaW5hdGU7XG4gIHVzZVJlZ2lzdGVyRmllbGRDb250cm9sKGNvbnRyb2xSZWYsIGlkLCBjaGVja2VkLCB1bmRlZmluZWQsICFncm91cENvbnRleHQgJiYgIWRpc2FibGVkLCBuYW1lUHJvcCk7XG4gIGNvbnN0IHJlZ2lzdGVyQ2hpbGRJZCA9IHBhcmVudENvbnRleHQ/LnJlZ2lzdGVyQ2hpbGRJZDtcbiAgY29uc3QgaW5wdXRSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IHJlZ2lzdGVyRmllbGRJbnB1dCA9IHZhbGlkYXRpb24ucmVnaXN0ZXJJbnB1dDtcbiAgY29uc3QgcmVnaXN0ZXJlZElucHV0VmFsdWUgPSBncm91cENvbnRleHQgPyB2YWx1ZSA6IHVuZGVmaW5lZDtcbiAgY29uc3QgcmVnaXN0ZXJJbnB1dCA9IFJlYWN0LnVzZUNhbGxiYWNrKGVsZW1lbnQgPT4gcmVnaXN0ZXJGaWVsZElucHV0KGVsZW1lbnQsIHtcbiAgICBjb250cm9sUmVmLFxuICAgIHZhbHVlOiByZWdpc3RlcmVkSW5wdXRWYWx1ZVxuICB9KSwgW3JlZ2lzdGVyRmllbGRJbnB1dCwgcmVnaXN0ZXJlZElucHV0VmFsdWVdKTtcbiAgY29uc3QgbWVyZ2VkSW5wdXRSZWYgPSB1c2VNZXJnZWRSZWZzKGlucHV0UmVmUHJvcCwgaW5wdXRSZWYsIHBhcmVudCA/IHVuZGVmaW5lZCA6IHJlZ2lzdGVySW5wdXQpO1xuICBjb25zdCBhcmlhTGFiZWxsZWRCeSA9IHVzZUFyaWFMYWJlbGxlZEJ5KGFyaWFMYWJlbGxlZEJ5UHJvcCwgbGFiZWxJZCwgaW5wdXRSZWYsICFuYXRpdmVCdXR0b24sIGNvbnRyb2xJZCwgZWxlbWVudFByb3BzWydhcmlhLWxhYmVsJ10pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpbnB1dFJlZi5jdXJyZW50KSB7XG4gICAgICAvLyBSZS1hc3NlcnQgb24gYGNoZWNrZWRgIGNoYW5nZXMgdG9vOiBjbGlja2luZyB0aGUgaW5wdXQgbmF0aXZlbHkgcmVzZXRzIGBpbmRldGVybWluYXRlYC5cbiAgICAgIGlucHV0UmVmLmN1cnJlbnQuaW5kZXRlcm1pbmF0ZSA9IGNvbXB1dGVkSW5kZXRlcm1pbmF0ZTtcbiAgICB9XG4gICAgLy8gSW5zaWRlIGEgZ3JvdXAsIHRoZSBncm91cCBkZXJpdmVzIHRoZSBmaWxsZWQgc3RhdGUgZnJvbSBpdHMgdmFsdWUuXG4gICAgaWYgKCFncm91cENvbnRleHQpIHtcbiAgICAgIHNldEZpbGxlZChjaGVja2VkKTtcbiAgICB9XG4gIH0sIFtjaGVja2VkLCBjb21wdXRlZEluZGV0ZXJtaW5hdGUsIGdyb3VwQ29udGV4dCwgc2V0RmlsbGVkXSk7XG4gIHVzZVZhbHVlQ2hhbmdlZChjaGVja2VkLCAoKSA9PiB7XG4gICAgaWYgKGdyb3VwQ29udGV4dCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjbGVhckVycm9ycyhuYW1lKTtcbiAgICBzZXREaXJ0eShjaGVja2VkICE9PSB2YWxpZGl0eURhdGEuaW5pdGlhbFZhbHVlKTtcbiAgICB2YWxpZGF0aW9uLmNoYW5nZShjaGVja2VkKTtcbiAgfSk7XG4gIGNvbnN0IGlucHV0UHJvcHMgPSBtZXJnZVByb3BzKHtcbiAgICBjaGVja2VkLFxuICAgIGRpc2FibGVkLFxuICAgIGZvcm0sXG4gICAgLy8gcGFyZW50IGNoZWNrYm94ZXMgdW5zZXQgYG5hbWVgIHRvIGJlIGV4Y2x1ZGVkIGZyb20gZm9ybSBzdWJtaXNzaW9uXG4gICAgbmFtZTogcGFyZW50ID8gdW5kZWZpbmVkIDogbmFtZSxcbiAgICAvLyBTZXQgYGlkYCB0byBzdG9wIENocm9tZSB3YXJuaW5nIGFib3V0IGFuIHVuYXNzb2NpYXRlZCBpbnB1dC5cbiAgICAvLyBXaGVuIHVzaW5nIGEgbmF0aXZlIGJ1dHRvbiwgdGhlIGBpZGAgaXMgYXBwbGllZCB0byB0aGUgYnV0dG9uIGluc3RlYWQuXG4gICAgaWQ6IG5hdGl2ZUJ1dHRvbiA/IHVuZGVmaW5lZCA6IGNvbnRyb2xJZCxcbiAgICByZXF1aXJlZCxcbiAgICByZWY6IG1lcmdlZElucHV0UmVmLFxuICAgIHN0eWxlOiBuYW1lID8gdmlzdWFsbHlIaWRkZW5JbnB1dCA6IHZpc3VhbGx5SGlkZGVuLFxuICAgIHRhYkluZGV4OiAtMSxcbiAgICB0eXBlOiAnY2hlY2tib3gnLFxuICAgICdhcmlhLWhpZGRlbic6IHRydWUsXG4gICAgb25DaGFuZ2UoZXZlbnQpIHtcbiAgICAgIC8vIFdvcmthcm91bmQgZm9yIGh0dHBzOi8vZ2l0aHViLmNvbS9yZWFjdC9yZWFjdC9pc3N1ZXMvOTAyM1xuICAgICAgaWYgKGV2ZW50Lm5hdGl2ZUV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKHJlYWRPbmx5KSB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG5leHRDaGVja2VkID0gZXZlbnQuY3VycmVudFRhcmdldC5jaGVja2VkO1xuICAgICAgY29uc3QgZGV0YWlscyA9IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLm5vbmUsIGV2ZW50Lm5hdGl2ZUV2ZW50KTtcbiAgICAgIG9uQ2hlY2tlZENoYW5nZT8uKG5leHRDaGVja2VkLCBkZXRhaWxzKTtcbiAgICAgIGlmIChkZXRhaWxzLmlzQ2FuY2VsZWQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgZ3JvdXBPbkNoYW5nZT8uKG5leHRDaGVja2VkLCBkZXRhaWxzKTtcbiAgICAgIGlmIChkZXRhaWxzLmlzQ2FuY2VsZWQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgc2V0Q2hlY2tlZFN0YXRlKG5leHRDaGVja2VkKTtcbiAgICAgIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkICYmIGdyb3VwQ29udGV4dCAhPT0gdW5kZWZpbmVkICYmICFwYXJlbnQgJiYgIWlzR3JvdXBlZFdpdGhQYXJlbnQpIHtcbiAgICAgICAgY29uc3QgbmV4dEdyb3VwVmFsdWUgPSBuZXh0Q2hlY2tlZCA/IFsuLi5ncm91cENvbnRleHQudmFsdWUsIHZhbHVlXSA6IGdyb3VwQ29udGV4dC52YWx1ZS5maWx0ZXIoaXRlbSA9PiBpdGVtICE9PSB2YWx1ZSk7XG4gICAgICAgIGdyb3VwQ29udGV4dC5zZXRWYWx1ZShuZXh0R3JvdXBWYWx1ZSwgZGV0YWlscyk7XG4gICAgICB9XG4gICAgfSxcbiAgICBvbkNsaWNrKGV2ZW50KSB7XG4gICAgICAvLyBUaGUgY2xpY2sgZGlzcGF0Y2hlZCBmcm9tIHRoZSByb290J3MgYG9uQ2xpY2tgIGlzIGFuIGltcGxlbWVudGF0aW9uIGRldGFpbFxuICAgICAgLy8gYW5kIG11c3Qgbm90IHJlYWNoIGFuY2VzdG9ycywgd2hpY2ggYWxyZWFkeSByZWNlaXZlIHRoZSBvcmlnaW5hbCBjbGljay5cbiAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgIH0sXG4gICAgb25Gb2N1cygpIHtcbiAgICAgIGNvbnRyb2xSZWYuY3VycmVudD8uZm9jdXMoKTtcbiAgICB9XG4gIH0sXG4gIC8vIFJlYWN0IDwxOSBzZXRzIGFuIGVtcHR5IHZhbHVlIGlmIGB1bmRlZmluZWRgIGlzIHBhc3NlZCBleHBsaWNpdGx5XG4gIC8vIFRvIGF2b2lkIHRoaXMsIHdlIG9ubHkgc2V0IHRoZSB2YWx1ZSBpZiBpdCdzIGRlZmluZWRcbiAgdmFsdWVQcm9wICE9PSB1bmRlZmluZWQgPyB7XG4gICAgdmFsdWU6IChncm91cENvbnRleHQgPyBjaGVja2VkICYmIHZhbHVlUHJvcCA6IHZhbHVlUHJvcCkgfHwgJydcbiAgfSA6IEVNUFRZX09CSkVDVCwgZ2V0RGVzY3JpcHRpb25Qcm9wcywgcHJvcHMgPT4gdmFsaWRhdGlvbi5nZXRWYWxpZGF0aW9uUHJvcHMoZGlzYWJsZWQsIHByb3BzKSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFwYXJlbnRDb250ZXh0IHx8IHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGNvbnN0IGRpc2FibGVkU3RhdGVzID0gcGFyZW50Q29udGV4dC5kaXNhYmxlZFN0YXRlc1JlZi5jdXJyZW50O1xuICAgIGRpc2FibGVkU3RhdGVzLnNldCh2YWx1ZSwgZGlzYWJsZWQpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBkaXNhYmxlZFN0YXRlcy5kZWxldGUodmFsdWUpO1xuICAgIH07XG4gIH0sIFtwYXJlbnRDb250ZXh0LCBkaXNhYmxlZCwgdmFsdWVdKTtcbiAgY29uc3Qgc3RhdGUgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgLi4uZmllbGRTdGF0ZSxcbiAgICBjaGVja2VkOiBjb21wdXRlZENoZWNrZWQsXG4gICAgZGlzYWJsZWQsXG4gICAgcmVhZE9ubHksXG4gICAgcmVxdWlyZWQsXG4gICAgaW5kZXRlcm1pbmF0ZTogY29tcHV0ZWRJbmRldGVybWluYXRlXG4gIH0pLCBbZmllbGRTdGF0ZSwgY29tcHV0ZWRDaGVja2VkLCBkaXNhYmxlZCwgcmVhZE9ubHksIHJlcXVpcmVkLCBjb21wdXRlZEluZGV0ZXJtaW5hdGVdKTtcbiAgY29uc3Qgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZyA9IGdldENoZWNrYm94U3RhdGVBdHRyaWJ1dGVzTWFwcGluZyhzdGF0ZSk7XG4gIGNvbnN0IGVsZW1lbnQgPSB1c2VSZW5kZXJFbGVtZW50KCdzcGFuJywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICByZWY6IFtidXR0b25SZWYsIGNvbnRyb2xSZWYsIGZvcndhcmRlZFJlZl0sXG4gICAgcHJvcHM6IFt7XG4gICAgICBpZDogcm9vdElkLFxuICAgICAgcm9sZTogJ2NoZWNrYm94JyxcbiAgICAgICdhcmlhLWNoZWNrZWQnOiBjb21wdXRlZEluZGV0ZXJtaW5hdGUgPyAnbWl4ZWQnIDogY29tcHV0ZWRDaGVja2VkLFxuICAgICAgJ2FyaWEtcmVhZG9ubHknOiByZWFkT25seSB8fCB1bmRlZmluZWQsXG4gICAgICAnYXJpYS1yZXF1aXJlZCc6IHJlcXVpcmVkIHx8IHVuZGVmaW5lZCxcbiAgICAgICdhcmlhLWxhYmVsbGVkYnknOiBhcmlhTGFiZWxsZWRCeSxcbiAgICAgIFtQQVJFTlRfQ0hFQ0tCT1hdOiBwYXJlbnQgPyAnJyA6IHVuZGVmaW5lZCxcbiAgICAgIG9uRm9jdXMoKSB7XG4gICAgICAgIHNldEZvY3VzZWQodHJ1ZSk7XG4gICAgICB9LFxuICAgICAgb25CbHVyKCkge1xuICAgICAgICBjb25zdCBpbnB1dEVsID0gaW5wdXRSZWYuY3VycmVudDtcbiAgICAgICAgaWYgKCFpbnB1dEVsKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHNldFRvdWNoZWQodHJ1ZSk7XG4gICAgICAgIHNldEZvY3VzZWQoZmFsc2UpO1xuICAgICAgICBpZiAodmFsaWRhdGlvbk1vZGUgPT09ICdvbkJsdXInKSB7XG4gICAgICAgICAgdmFsaWRhdGlvbi5jb21taXQoZ3JvdXBDb250ZXh0ID8gZ3JvdXBWYWx1ZSA6IGlucHV0RWwuY2hlY2tlZCk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBvbktleURvd24oZXZlbnQpIHtcbiAgICAgICAgaWYgKGV2ZW50LmtleSAhPT0gJ0VudGVyJykge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIExldCBjb25zdW1lciBgcHJldmVudERlZmF1bHQoKWAgaGFuZGxlcnMgb3B0IG91dCB3aGlsZSBkZWZlbnNpdmVseSBzdG9wcGluZ1xuICAgICAgICAvLyBhbnkgcmVtYWluaW5nIEJhc2UgVUkgRW50ZXIgaGFuZGxpbmcgZnJvbSB0cmVhdGluZyB0aGUgY2hlY2tib3ggYXMgYSBidXR0b24uXG4gICAgICAgIGV2ZW50LnByZXZlbnRCYXNlVUlIYW5kbGVyKCk7XG4gICAgICAgIGlmIChldmVudC5kZWZhdWx0UHJldmVudGVkKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZvcm1Ub1N1Ym1pdCA9IGlucHV0UmVmLmN1cnJlbnQ/LmZvcm0gPz8gbnVsbDtcbiAgICAgICAgY29uc3QgY3VycmVudFRhcmdldCA9IGV2ZW50LmN1cnJlbnRUYXJnZXQ7XG4gICAgICAgIGNvbnN0IG5hdGl2ZUV2ZW50ID0gZXZlbnQubmF0aXZlRXZlbnQ7XG4gICAgICAgIGNvbnN0IG9yaWdpbmFsUHJldmVudERlZmF1bHQgPSBldmVudC5wcmV2ZW50RGVmYXVsdDtcbiAgICAgICAgY29uc3Qgb3JpZ2luYWxOYXRpdmVQcmV2ZW50RGVmYXVsdCA9IG5hdGl2ZUV2ZW50LnByZXZlbnREZWZhdWx0O1xuICAgICAgICBsZXQgcHJldmVudERlZmF1bHRDYWxsZWRBZnRlclByb3BhZ2F0aW9uID0gZmFsc2U7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0ID0gKCkgPT4ge1xuICAgICAgICAgIHByZXZlbnREZWZhdWx0Q2FsbGVkQWZ0ZXJQcm9wYWdhdGlvbiA9IHRydWU7XG4gICAgICAgICAgb3JpZ2luYWxQcmV2ZW50RGVmYXVsdC5jYWxsKGV2ZW50KTtcbiAgICAgICAgfTtcbiAgICAgICAgbmF0aXZlRXZlbnQucHJldmVudERlZmF1bHQgPSAoKSA9PiB7XG4gICAgICAgICAgcHJldmVudERlZmF1bHRDYWxsZWRBZnRlclByb3BhZ2F0aW9uID0gdHJ1ZTtcbiAgICAgICAgICBvcmlnaW5hbE5hdGl2ZVByZXZlbnREZWZhdWx0LmNhbGwobmF0aXZlRXZlbnQpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8vIEVudGVyIHNob3VsZCBub3QgYWN0aXZhdGUvdG9nZ2xlIHRoZSBjaGVja2JveC4gQ2FuY2VsIHRoZSBuYXRpdmUgYnV0dG9uIGJlaGF2aW9yXG4gICAgICAgIC8vIHdpdGhvdXQgc2V0dGluZyBSZWFjdCdzIHN5bnRoZXRpYyBgZGVmYXVsdFByZXZlbnRlZGAsIHNvIGFuY2VzdG9yIFJlYWN0IGhhbmRsZXJzXG4gICAgICAgIC8vIGNhbiBzdGlsbCBvcHQgb3V0IGJ5IGNhbGxpbmcgYHByZXZlbnREZWZhdWx0KClgIGR1cmluZyBwcm9wYWdhdGlvbi5cbiAgICAgICAgb3JpZ2luYWxOYXRpdmVQcmV2ZW50RGVmYXVsdC5jYWxsKG5hdGl2ZUV2ZW50KTtcbiAgICAgICAgb3duZXJXaW5kb3coY3VycmVudFRhcmdldCkucXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0ID0gb3JpZ2luYWxQcmV2ZW50RGVmYXVsdDtcbiAgICAgICAgICBuYXRpdmVFdmVudC5wcmV2ZW50RGVmYXVsdCA9IG9yaWdpbmFsTmF0aXZlUHJldmVudERlZmF1bHQ7XG4gICAgICAgICAgaWYgKCFwcmV2ZW50RGVmYXVsdENhbGxlZEFmdGVyUHJvcGFnYXRpb24pIHtcbiAgICAgICAgICAgIGdldERlZmF1bHRGb3JtU3VibWl0dGVyKGZvcm1Ub1N1Ym1pdCk/LmNsaWNrKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0sXG4gICAgICBvbkNsaWNrKGV2ZW50KSB7XG4gICAgICAgIGlmIChyZWFkT25seSB8fCBkaXNhYmxlZCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICBjb25zdCBpbnB1dCA9IGlucHV0UmVmLmN1cnJlbnQ7XG4gICAgICAgIGlmICghaW5wdXQpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgZGlzcGF0Y2hDbGlja1dpdGhNb2RpZmllcnMoaW5wdXQsIGV2ZW50KTtcbiAgICAgIH1cbiAgICB9LCBlbGVtZW50UHJvcHMsIG90aGVyR3JvdXBQcm9wcywgZ2V0QnV0dG9uUHJvcHMsIGdldERlc2NyaXB0aW9uUHJvcHMsIHByb3BzID0+IHZhbGlkYXRpb24uZ2V0VmFsaWRhdGlvblByb3BzKGRpc2FibGVkLCBwcm9wcyldLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmdcbiAgfSk7XG5cbiAgLy8gYHVzZVJlbmRlckVsZW1lbnRgIGFsd2F5cyByZXR1cm5zIGFuIGVsZW1lbnQgaGVyZSwgc28gdGhlIGNhc3Qgb25seSBuYXJyb3dzIGBwcm9wc2AuXG4gIGNvbnN0IHJlbmRlcmVkSWQgPSBlbGVtZW50LnByb3BzLmlkO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghcmVnaXN0ZXJDaGlsZElkIHx8IHBhcmVudCB8fCB2YWx1ZSA9PT0gdW5kZWZpbmVkIHx8IHJlbmRlcmVkSWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgcmV0dXJuIHJlZ2lzdGVyQ2hpbGRJZCh2YWx1ZSwgcmVuZGVyZWRJZCk7XG4gIH0sIFtyZWdpc3RlckNoaWxkSWQsIHBhcmVudCwgdmFsdWUsIHJlbmRlcmVkSWRdKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4cyhDaGVja2JveFJvb3RDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IHN0YXRlLFxuICAgIGNoaWxkcmVuOiBbZWxlbWVudCwgIWNoZWNrZWQgJiYgIWdyb3VwQ29udGV4dCAmJiBuYW1lICYmICFwYXJlbnQgJiYgdW5jaGVja2VkVmFsdWUgIT09IHVuZGVmaW5lZCAmJiAvKiNfX1BVUkVfXyovX2pzeChcImlucHV0XCIsIHtcbiAgICAgIHR5cGU6IFwiaGlkZGVuXCIsXG4gICAgICBmb3JtOiBmb3JtLFxuICAgICAgbmFtZTogbmFtZSxcbiAgICAgIHZhbHVlOiB1bmNoZWNrZWRWYWx1ZSxcbiAgICAgIGRpc2FibGVkOiBkaXNhYmxlZFxuICAgIH0pLCAvKiNfX1BVUkVfXyovX2pzeChcImlucHV0XCIsIHtcbiAgICAgIC4uLmlucHV0UHJvcHMsXG4gICAgICBzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWVcbiAgICB9KV1cbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIENoZWNrYm94Um9vdC5kaXNwbGF5TmFtZSA9IFwiQ2hlY2tib3hSb290XCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VDaGVja2JveFJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvQ2hlY2tib3hSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBnZXRDaGVja2JveFN0YXRlQXR0cmlidXRlc01hcHBpbmcgfSBmcm9tIFwiLi4vdXRpbHMvZ2V0Q2hlY2tib3hTdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nLm1qc1wiO1xuaW1wb3J0IHsgdXNlT3BlbkNoYW5nZUNvbXBsZXRlIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VPcGVuQ2hhbmdlQ29tcGxldGUubWpzXCI7XG5pbXBvcnQgeyB1c2VUcmFuc2l0aW9uU3RhdHVzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VUcmFuc2l0aW9uU3RhdHVzLm1qc1wiO1xuaW1wb3J0IHsgdHJhbnNpdGlvblN0YXR1c01hcHBpbmcgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3N0YXRlQXR0cmlidXRlc01hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogSW5kaWNhdGVzIHdoZXRoZXIgdGhlIGNoZWNrYm94IGlzIHRpY2tlZC5cbiAqIFJlbmRlcnMgYSBgPHNwYW4+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIENoZWNrYm94XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvY2hlY2tib3gpXG4gKi9cbmV4cG9ydCBjb25zdCBDaGVja2JveEluZGljYXRvciA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIENoZWNrYm94SW5kaWNhdG9yKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAga2VlcE1vdW50ZWQgPSBmYWxzZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCByb290U3RhdGUgPSB1c2VDaGVja2JveFJvb3RDb250ZXh0KCk7XG4gIGNvbnN0IHJlbmRlcmVkID0gcm9vdFN0YXRlLmNoZWNrZWQgfHwgcm9vdFN0YXRlLmluZGV0ZXJtaW5hdGU7XG4gIGNvbnN0IHtcbiAgICBtb3VudGVkLFxuICAgIHRyYW5zaXRpb25TdGF0dXMsXG4gICAgc2V0TW91bnRlZFxuICB9ID0gdXNlVHJhbnNpdGlvblN0YXR1cyhyZW5kZXJlZCk7XG4gIGNvbnN0IGluZGljYXRvclJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgLi4ucm9vdFN0YXRlLFxuICAgIHRyYW5zaXRpb25TdGF0dXNcbiAgfTtcbiAgdXNlT3BlbkNoYW5nZUNvbXBsZXRlKHtcbiAgICBiYXRjaDogdHJ1ZSxcbiAgICBlbmFibGVkOiAhcmVuZGVyZWQsXG4gICAgb3BlbjogcmVuZGVyZWQsXG4gICAgcmVmOiBpbmRpY2F0b3JSZWYsXG4gICAgb25Db21wbGV0ZSgpIHtcbiAgICAgIGlmICghcmVuZGVyZWQpIHtcbiAgICAgICAgc2V0TW91bnRlZChmYWxzZSk7XG4gICAgICB9XG4gICAgfVxuICB9KTtcbiAgY29uc3QgYmFzZVN0YXRlQXR0cmlidXRlc01hcHBpbmcgPSBnZXRDaGVja2JveFN0YXRlQXR0cmlidXRlc01hcHBpbmcocm9vdFN0YXRlKTtcbiAgY29uc3Qgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZyA9IHtcbiAgICAuLi5iYXNlU3RhdGVBdHRyaWJ1dGVzTWFwcGluZyxcbiAgICAuLi50cmFuc2l0aW9uU3RhdHVzTWFwcGluZ1xuICB9O1xuICBjb25zdCBzaG91bGRSZW5kZXIgPSBrZWVwTW91bnRlZCB8fCBtb3VudGVkO1xuICBjb25zdCBlbGVtZW50ID0gdXNlUmVuZGVyRWxlbWVudCgnc3BhbicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgcmVmOiBbZm9yd2FyZGVkUmVmLCBpbmRpY2F0b3JSZWZdLFxuICAgIHN0YXRlLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmcsXG4gICAgcHJvcHM6IGVsZW1lbnRQcm9wc1xuICB9KTtcbiAgaWYgKCFzaG91bGRSZW5kZXIpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICByZXR1cm4gZWxlbWVudDtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgQ2hlY2tib3hJbmRpY2F0b3IuZGlzcGxheU5hbWUgPSBcIkNoZWNrYm94SW5kaWNhdG9yXCI7IiwiZXhwb3J0IHsgQ2hlY2tib3hSb290IGFzIFJvb3QgfSBmcm9tIFwiLi9yb290L0NoZWNrYm94Um9vdC5tanNcIjtcbmV4cG9ydCB7IENoZWNrYm94SW5kaWNhdG9yIGFzIEluZGljYXRvciB9IGZyb20gXCIuL2luZGljYXRvci9DaGVja2JveEluZGljYXRvci5tanNcIjsiLCJpbXBvcnQgeyBUcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3N0YXRlQXR0cmlidXRlc01hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjaGVja2JveCBpcyBjaGVja2VkLlxuICovXG5leHBvcnQgY29uc3QgY2hlY2tlZCA9ICdkYXRhLWNoZWNrZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGNoZWNrYm94IGlzIG5vdCBjaGVja2VkLlxuICovXG5leHBvcnQgY29uc3QgdW5jaGVja2VkID0gJ2RhdGEtdW5jaGVja2VkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjaGVja2JveCBpcyBpbiBhbiBpbmRldGVybWluYXRlIHN0YXRlLlxuICovXG5leHBvcnQgY29uc3QgaW5kZXRlcm1pbmF0ZSA9ICdkYXRhLWluZGV0ZXJtaW5hdGUnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGNoZWNrYm94IGlzIGRpc2FibGVkLlxuICovXG5leHBvcnQgY29uc3QgZGlzYWJsZWQgPSAnZGF0YS1kaXNhYmxlZCc7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgY2hlY2tib3ggaXMgcmVhZG9ubHkuXG4gKi9cbmV4cG9ydCBjb25zdCByZWFkb25seSA9ICdkYXRhLXJlYWRvbmx5Jztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjaGVja2JveCBpcyByZXF1aXJlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IHJlcXVpcmVkID0gJ2RhdGEtcmVxdWlyZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGNoZWNrYm94IGluZGljYXRvciBiZWdpbnMgYW5pbWF0aW5nIGluLlxuICovXG5leHBvcnQgY29uc3Qgc3RhcnRpbmdTdHlsZSA9IFRyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcy5zdGFydGluZ1N0eWxlO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGNoZWNrYm94IGluZGljYXRvciBpcyBhbmltYXRpbmcgb3V0LlxuICovXG5leHBvcnQgY29uc3QgZW5kaW5nU3R5bGUgPSBUcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMuZW5kaW5nU3R5bGU7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgY2hlY2tib3ggaXMgaW4gYSB2YWxpZCBzdGF0ZSAod2hlbiB3cmFwcGVkIGluIEZpZWxkLlJvb3QpLlxuICovXG5leHBvcnQgY29uc3QgdmFsaWQgPSAnZGF0YS12YWxpZCc7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgY2hlY2tib3ggaXMgaW4gYW4gaW52YWxpZCBzdGF0ZSAod2hlbiB3cmFwcGVkIGluIEZpZWxkLlJvb3QpLlxuICovXG5leHBvcnQgY29uc3QgaW52YWxpZCA9ICdkYXRhLWludmFsaWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGNoZWNrYm94IGhhcyBiZWVuIHRvdWNoZWQgKHdoZW4gd3JhcHBlZCBpbiBGaWVsZC5Sb290KS5cbiAqL1xuZXhwb3J0IGNvbnN0IHRvdWNoZWQgPSAnZGF0YS10b3VjaGVkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjaGVja2JveCdzIHZhbHVlIGhhcyBjaGFuZ2VkICh3aGVuIHdyYXBwZWQgaW4gRmllbGQuUm9vdCkuXG4gKi9cbmV4cG9ydCBjb25zdCBkaXJ0eSA9ICdkYXRhLWRpcnR5Jztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjaGVja2JveCBpcyBjaGVja2VkICh3aGVuIHdyYXBwZWQgaW4gRmllbGQuUm9vdCkuXG4gKi9cbmV4cG9ydCBjb25zdCBmaWxsZWQgPSAnZGF0YS1maWxsZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGNoZWNrYm94IGlzIGZvY3VzZWQgKHdoZW4gd3JhcHBlZCBpbiBGaWVsZC5Sb290KS5cbiAqL1xuZXhwb3J0IGNvbnN0IGZvY3VzZWQgPSAnZGF0YS1mb2N1c2VkJzsiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBV0EsU0FBZ0Isd0JBQXdCLE1BQU07Q0FDNUMsSUFBSSxDQUFDLE1BQ0gsT0FBTztDQUVULEtBQUssTUFBTSxhQUFhLEtBQUssVUFBVTtFQUNyQyxNQUFNLFVBQVUsVUFBVTtFQUMxQixJQUFJLFlBQVksWUFBWSxZQUFZLFNBQVM7R0FDL0MsTUFBTSxTQUFTO0dBSWYsSUFBSSxPQUFPLFNBQVMsVUFDbEIsT0FBTztFQUVYO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6QkEsSUFBYUEsWUFBVTs7OztBQUl2QixJQUFhQyxjQUFZOzs7O0FBSXpCLElBQWFDLGtCQUFnQjs7OztBQUk3QixJQUFhQyxhQUFXOzs7O0FBSXhCLElBQWFDLGFBQVc7Ozs7QUFJeEIsSUFBYUMsYUFBVzs7OztBQUl4QixJQUFhQyxVQUFROzs7O0FBSXJCLElBQWFDLFlBQVU7Ozs7QUFJdkIsSUFBYUMsWUFBVTs7OztBQUl2QixJQUFhQyxVQUFROzs7O0FBSXJCLElBQWFDLFdBQVM7Ozs7QUFJdEIsSUFBYUMsWUFBVTs7QUM3Q3ZCLFNBQWdCLGtDQUFrQyxPQUFPO0NBQ3ZELE9BQU87RUFDTCxRQUFRLE9BQU87R0FDYixJQUFJLE1BQU0sZUFFUixPQUFPLENBQUM7R0FFVixJQUFJLE9BQ0YsT0FBTyxHQUNKQyxZQUFxQyxHQUN4QztHQUVGLE9BQU8sR0FDSkMsY0FBdUMsR0FDMUM7RUFDRjtFQUNBLEdBQUc7Q0FDTDtBQUNGOztBQ2pCQSxJQUFhLHVCQUFvQywyQkFBTSxjQUFjLEtBQUEsQ0FBUztBQUNuQyxxQkFBcUIsY0FBYztBQUM5RSxTQUFnQiwwQkFBMEI7Q0FDeEMsT0FBQSxhQUFhLFdBQVcsb0JBQW9CO0FBQzlDOztBQ0hBLElBQWEsc0JBQW1DLDJCQUFNLGNBQWMsS0FBQSxDQUFTO0FBQ2xDLG9CQUFvQixjQUFjO0FBQzdFLFNBQWdCLHlCQUF5QjtDQUN2QyxNQUFNLFVBQUEsYUFBZ0IsV0FBVyxtQkFBbUI7Q0FDcEQsSUFBSSxZQUFZLEtBQUEsR0FDZCxNQUFNLElBQUksTUFBOEMsZ0dBQTBIO0NBRXBMLE9BQU87QUFDVDs7O0FDa0JBLElBQWEsa0JBQWtCOzs7Ozs7O0FBUS9CLElBQWEsZUFBNEIsMkJBQU0sV0FBVyxTQUFTLGFBQWEsZ0JBQWdCLGNBQWM7Q0FDNUcsTUFBTSxFQUNKLFNBQVMsYUFDVCxXQUNBLGlCQUFpQixPQUNqQixtQkFBbUIsb0JBQ25CLFVBQVUsZUFBZSxPQUN6QixNQUNBLElBQUksUUFDSixnQkFBZ0IsT0FDaEIsVUFBVSxjQUNWLE1BQU0sVUFDTixpQkFDQSxTQUFTLE9BQ1QsV0FBVyxPQUNYLFFBQ0EsV0FBVyxPQUNYLGdCQUNBLE9BQU8sV0FDUCxlQUFlLE9BQ2YsT0FDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxFQUNKLGdCQUNFLGVBQWU7Q0FDbkIsTUFBTSxFQUNKLFVBQVUsY0FDVixNQUFNLFdBQ04sVUFDQSxXQUNBLFlBQ0EsT0FBTyxZQUNQLGdCQUNBLGNBQ0EsWUFBWSxvQkFDVixvQkFBb0I7Q0FDeEIsTUFBTSxtQkFBbUIsb0JBQW9CO0NBQzdDLE1BQU0sRUFDSixTQUNBLG1CQUNBLHdCQUNFLG9CQUFvQjtDQUN4QixNQUFNLGVBQWUsd0JBQXdCO0NBQzdDLE1BQU0sZ0JBQWdCLGNBQWMsY0FBYyxLQUFBLElBQVksS0FBQSxJQUFZLGFBQWE7Q0FDdkYsTUFBTSxzQkFBc0Isa0JBQWtCLEtBQUE7Q0FDOUMsTUFBTSxXQUFXLGdCQUFnQixpQkFBaUIsWUFBWSxjQUFjLFlBQVk7Q0FDeEYsTUFBTSxPQUFPLGFBQWE7Q0FDMUIsTUFBTSxRQUFRLGFBQWE7Q0FDM0IsTUFBTSxLQUFLLFlBQVk7Q0FLdkIsTUFBTSxnQkFBZ0IsY0FBYyxzQkFBc0I7Q0FHMUQsTUFBTSxZQUFZLGVBQWU7RUFDL0IsSUFBSSxVQUFVLEtBQUE7RUFDZCxTQUFTO0NBQ1gsQ0FBQztDQUNELE1BQU0sU0FBUyxlQUFlLFlBQVk7Q0FDMUMsSUFBSSxhQUFhLENBQUM7Q0FDbEIsSUFBSSxxQkFBcUI7RUFDdkIsSUFBSSxRQUNGLGFBQWEsY0FBYyxlQUFlO09BQ3JDLElBQUksVUFBVSxLQUFBLEdBQ25CLGFBQWEsY0FBYyxjQUFjLEtBQUs7Q0FFbEQ7Q0FDQSxNQUFNLEVBQ0osU0FBUyxlQUFlLGFBQ3hCLGVBQWUscUJBQXFCLGVBQ3BDLGlCQUFpQixlQUNqQixHQUFHLG9CQUNEO0NBQ0osTUFBTSxhQUFhLGNBQWM7Q0FDakMsTUFBTSxhQUFBLGFBQW1CLE9BQU8sSUFBSTtDQUNwQyxNQUFNLGFBQWEsbUJBQW1CLFVBQVUsVUFBVTtDQUMxRCxNQUFNLEVBQ0osZ0JBQ0EsY0FDRSxVQUFVO0VBQ1o7RUFDQSxRQUFRO0NBQ1YsQ0FBQztDQUNELE1BQU0sYUFBYSxjQUFjLGNBQWM7Q0FDL0MsTUFBTSxDQUFDLFNBQVMsbUJBQW1CLGNBQWM7RUFDL0MsWUFBWSxVQUFVLEtBQUEsS0FBYSxlQUFlLEtBQUEsS0FBYSxDQUFDLFNBQVMsV0FBVyxTQUFTLEtBQUssSUFBSTtFQUN0RyxTQUFTO0VBQ1QsTUFBTTtFQUNOLE9BQU87Q0FDVCxDQUFDO0NBQ0QsTUFBTSxrQkFBa0Isc0JBQXNCLFFBQVEsWUFBWSxJQUFJO0NBQ3RFLE1BQU0sd0JBQXdCLHNCQUFzQixzQkFBc0IsZ0JBQWdCO0NBQzFGLHdCQUF3QixZQUFZLElBQUksU0FBUyxLQUFBLEdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLFFBQVE7Q0FDaEcsTUFBTSxrQkFBa0IsZUFBZTtDQUN2QyxNQUFNLFdBQUEsYUFBaUIsT0FBTyxJQUFJO0NBQ2xDLE1BQU0scUJBQXFCLFdBQVc7Q0FDdEMsTUFBTSx1QkFBdUIsZUFBZSxRQUFRLEtBQUE7Q0FDcEQsTUFBTSxnQkFBQSxhQUFzQixhQUFZLFlBQVcsbUJBQW1CLFNBQVM7RUFDN0U7RUFDQSxPQUFPO0NBQ1QsQ0FBQyxHQUFHLENBQUMsb0JBQW9CLG9CQUFvQixDQUFDO0NBQzlDLE1BQU0saUJBQWlCLGNBQWMsY0FBYyxVQUFVLFNBQVMsS0FBQSxJQUFZLGFBQWE7Q0FDL0YsTUFBTSxpQkFBaUIsa0JBQWtCLG9CQUFvQixTQUFTLFVBQVUsQ0FBQyxjQUFjLFdBQVcsYUFBYSxhQUFhO0NBQ3BJLHlCQUF5QjtFQUN2QixJQUFJLFNBQVMsU0FFWCxTQUFTLFFBQVEsZ0JBQWdCO0VBR25DLElBQUksQ0FBQyxjQUNILFVBQVUsT0FBTztDQUVyQixHQUFHO0VBQUM7RUFBUztFQUF1QjtFQUFjO0NBQVMsQ0FBQztDQUM1RCxnQkFBZ0IsZUFBZTtFQUM3QixJQUFJLGNBQ0Y7RUFFRixZQUFZLElBQUk7RUFDaEIsU0FBUyxZQUFZLGFBQWEsWUFBWTtFQUM5QyxXQUFXLE9BQU8sT0FBTztDQUMzQixDQUFDO0NBQ0QsTUFBTSxhQUFhLFdBQVc7RUFDNUI7RUFDQTtFQUNBO0VBRUEsTUFBTSxTQUFTLEtBQUEsSUFBWTtFQUczQixJQUFJLGVBQWUsS0FBQSxJQUFZO0VBQy9CO0VBQ0EsS0FBSztFQUNMLE9BQU8sT0FBTyxzQkFBc0I7RUFDcEMsVUFBVTtFQUNWLE1BQU07RUFDTixlQUFlO0VBQ2YsU0FBUyxPQUFPO0dBRWQsSUFBSSxNQUFNLFlBQVksa0JBQ3BCO0dBRUYsSUFBSSxVQUFVO0lBQ1osTUFBTSxlQUFlO0lBQ3JCO0dBQ0Y7R0FDQSxNQUFNLGNBQWMsTUFBTSxjQUFjO0dBQ3hDLE1BQU0sVUFBVSx5QkFBeUJDLE1BQWMsTUFBTSxXQUFXO0dBQ3hFLGtCQUFrQixhQUFhLE9BQU87R0FDdEMsSUFBSSxRQUFRLFlBQ1Y7R0FFRixnQkFBZ0IsYUFBYSxPQUFPO0dBQ3BDLElBQUksUUFBUSxZQUNWO0dBRUYsZ0JBQWdCLFdBQVc7R0FDM0IsSUFBSSxVQUFVLEtBQUEsS0FBYSxpQkFBaUIsS0FBQSxLQUFhLENBQUMsVUFBVSxDQUFDLHFCQUFxQjtJQUN4RixNQUFNLGlCQUFpQixjQUFjLENBQUMsR0FBRyxhQUFhLE9BQU8sS0FBSyxJQUFJLGFBQWEsTUFBTSxRQUFPLFNBQVEsU0FBUyxLQUFLO0lBQ3RILGFBQWEsU0FBUyxnQkFBZ0IsT0FBTztHQUMvQztFQUNGO0VBQ0EsUUFBUSxPQUFPO0dBR2IsTUFBTSxnQkFBZ0I7RUFDeEI7RUFDQSxVQUFVO0dBQ1IsV0FBVyxTQUFTLE1BQU07RUFDNUI7Q0FDRixHQUdBLGNBQWMsS0FBQSxJQUFZLEVBQ3hCLFFBQVEsZUFBZSxXQUFXLFlBQVksY0FBYyxHQUM5RCxJQUFJLGNBQWMsc0JBQXFCLFVBQVMsV0FBVyxtQkFBbUIsVUFBVSxLQUFLLENBQUM7Q0FDOUYsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxDQUFDLGlCQUFpQixVQUFVLEtBQUEsR0FDOUI7RUFFRixNQUFNLGlCQUFpQixjQUFjLGtCQUFrQjtFQUN2RCxlQUFlLElBQUksT0FBTyxRQUFRO0VBQ2xDLGFBQWE7R0FDWCxlQUFlLE9BQU8sS0FBSztFQUM3QjtDQUNGLEdBQUc7RUFBQztFQUFlO0VBQVU7Q0FBSyxDQUFDO0NBQ25DLE1BQU0sUUFBQSxhQUFjLGVBQWU7RUFDakMsR0FBRztFQUNILFNBQVM7RUFDVDtFQUNBO0VBQ0E7RUFDQSxlQUFlO0NBQ2pCLElBQUk7RUFBQztFQUFZO0VBQWlCO0VBQVU7RUFBVTtFQUFVO0NBQXFCLENBQUM7Q0FDdEYsTUFBTSx5QkFBeUIsa0NBQWtDLEtBQUs7Q0FDdEUsTUFBTSxVQUFVLGlCQUFpQixRQUFRLGdCQUFnQjtFQUN2RDtFQUNBLEtBQUs7R0FBQztHQUFXO0dBQVk7RUFBWTtFQUN6QyxPQUFPO0dBQUM7SUFDTixJQUFJO0lBQ0osTUFBTTtJQUNOLGdCQUFnQix3QkFBd0IsVUFBVTtJQUNsRCxpQkFBaUIsWUFBWSxLQUFBO0lBQzdCLGlCQUFpQixZQUFZLEtBQUE7SUFDN0IsbUJBQW1CO0tBQ2xCLGtCQUFrQixTQUFTLEtBQUssS0FBQTtJQUNqQyxVQUFVO0tBQ1IsV0FBVyxJQUFJO0lBQ2pCO0lBQ0EsU0FBUztLQUNQLE1BQU0sVUFBVSxTQUFTO0tBQ3pCLElBQUksQ0FBQyxTQUNIO0tBRUYsV0FBVyxJQUFJO0tBQ2YsV0FBVyxLQUFLO0tBQ2hCLElBQUksbUJBQW1CLFVBQ3JCLFdBQVcsT0FBTyxlQUFlLGFBQWEsUUFBUSxPQUFPO0lBRWpFO0lBQ0EsVUFBVSxPQUFPO0tBQ2YsSUFBSSxNQUFNLFFBQVEsU0FDaEI7S0FLRixNQUFNLHFCQUFxQjtLQUMzQixJQUFJLE1BQU0sa0JBQ1I7S0FFRixNQUFNLGVBQWUsU0FBUyxTQUFTLFFBQVE7S0FDL0MsTUFBTSxnQkFBZ0IsTUFBTTtLQUM1QixNQUFNLGNBQWMsTUFBTTtLQUMxQixNQUFNLHlCQUF5QixNQUFNO0tBQ3JDLE1BQU0sK0JBQStCLFlBQVk7S0FDakQsSUFBSSx1Q0FBdUM7S0FDM0MsTUFBTSx1QkFBdUI7TUFDM0IsdUNBQXVDO01BQ3ZDLHVCQUF1QixLQUFLLEtBQUs7S0FDbkM7S0FDQSxZQUFZLHVCQUF1QjtNQUNqQyx1Q0FBdUM7TUFDdkMsNkJBQTZCLEtBQUssV0FBVztLQUMvQztLQUtBLDZCQUE2QixLQUFLLFdBQVc7S0FDN0MsVUFBWSxhQUFhLENBQUMsQ0FBQyxxQkFBcUI7TUFDOUMsTUFBTSxpQkFBaUI7TUFDdkIsWUFBWSxpQkFBaUI7TUFDN0IsSUFBSSxDQUFDLHNDQUNILHdCQUF3QixZQUFZLENBQUMsRUFBRSxNQUFNO0tBRWpELENBQUM7SUFDSDtJQUNBLFFBQVEsT0FBTztLQUNiLElBQUksWUFBWSxVQUNkO0tBRUYsTUFBTSxlQUFlO0tBQ3JCLE1BQU0sUUFBUSxTQUFTO0tBQ3ZCLElBQUksQ0FBQyxPQUNIO0tBRUYsMkJBQTJCLE9BQU8sS0FBSztJQUN6QztHQUNGO0dBQUc7R0FBYztHQUFpQjtHQUFnQjtJQUFxQixVQUFTLFdBQVcsbUJBQW1CLFVBQVUsS0FBSztFQUFDO0VBQzlIO0NBQ0YsQ0FBQztDQUdELE1BQU0sYUFBYSxRQUFRLE1BQU07Q0FDakMseUJBQXlCO0VBQ3ZCLElBQUksQ0FBQyxtQkFBbUIsVUFBVSxVQUFVLEtBQUEsS0FBYSxlQUFlLEtBQUEsR0FDdEU7RUFFRixPQUFPLGdCQUFnQixPQUFPLFVBQVU7Q0FDMUMsR0FBRztFQUFDO0VBQWlCO0VBQVE7RUFBTztDQUFVLENBQUM7Q0FDL0MsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBTSxvQkFBb0IsVUFBVTtFQUN0RCxPQUFPO0VBQ1AsVUFBVTtHQUFDO0dBQVMsQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLFFBQVEsQ0FBQyxVQUFVLG1CQUFtQixLQUFBLEtBQTBCLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssU0FBUztJQUM3SCxNQUFNO0lBQ0E7SUFDQTtJQUNOLE9BQU87SUFDRztHQUNaLENBQUM7R0FBZ0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxTQUFTO0lBQzdCLEdBQUc7SUFDSCwwQkFBMEI7R0FDNUIsQ0FBQztFQUFDO0NBQ0osQ0FBQztBQUNILENBQUM7QUFDMEMsYUFBYSxjQUFjOzs7Ozs7OztBQy9UdEUsSUFBYSxvQkFBaUMsMkJBQU0sV0FBVyxTQUFTLGtCQUFrQixnQkFBZ0IsY0FBYztDQUN0SCxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsY0FBYyxPQUNkLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLFlBQVksdUJBQXVCO0NBQ3pDLE1BQU0sV0FBVyxVQUFVLFdBQVcsVUFBVTtDQUNoRCxNQUFNLEVBQ0osU0FDQSxrQkFDQSxlQUNFLG9CQUFvQixRQUFRO0NBQ2hDLE1BQU0sZUFBQSxhQUFxQixPQUFPLElBQUk7Q0FDdEMsTUFBTSxRQUFRO0VBQ1osR0FBRztFQUNIO0NBQ0Y7Q0FDQSxzQkFBc0I7RUFDcEIsT0FBTztFQUNQLFNBQVMsQ0FBQztFQUNWLE1BQU07RUFDTixLQUFLO0VBQ0wsYUFBYTtHQUNYLElBQUksQ0FBQyxVQUNILFdBQVcsS0FBSztFQUVwQjtDQUNGLENBQUM7Q0FFRCxNQUFNLHlCQUF5QjtFQUM3QixHQUZpQyxrQ0FBa0MsU0FFdkM7RUFDNUIsR0FBRztDQUNMO0NBQ0EsTUFBTSxlQUFlLGVBQWU7Q0FDcEMsTUFBTSxVQUFVLGlCQUFpQixRQUFRLGdCQUFnQjtFQUN2RCxLQUFLLENBQUMsY0FBYyxZQUFZO0VBQ2hDO0VBQ0E7RUFDQSxPQUFPO0NBQ1QsQ0FBQztDQUNELElBQUksQ0FBQyxjQUNILE9BQU87Q0FFVCxPQUFPO0FBQ1QsQ0FBQztBQUMwQyxrQkFBa0IsY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUUzRDNFLElBQWEsVUFBVTs7OztBQUl2QixJQUFhLFlBQVk7Ozs7QUFJekIsSUFBYSxnQkFBZ0I7Ozs7QUFJN0IsSUFBYSxXQUFXOzs7O0FBSXhCLElBQWEsV0FBVzs7OztBQUl4QixJQUFhLFdBQVc7Ozs7QUFJeEIsSUFBYSxnQkFBZ0JDOzs7O0FBSTdCLElBQWEsY0FBY0M7Ozs7QUFJM0IsSUFBYSxRQUFROzs7O0FBSXJCLElBQWEsVUFBVTs7OztBQUl2QixJQUFhLFVBQVU7Ozs7QUFJdkIsSUFBYSxRQUFROzs7O0FBSXJCLElBQWEsU0FBUzs7OztBQUl0QixJQUFhLFVBQVUiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxLDIsMyw0LDUsNiw3LDhdfQ==