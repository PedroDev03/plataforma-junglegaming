import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/badge.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { mergeProps } from "/node_modules/.vite/deps/@base-ui_react_merge-props.js?v=e9f94b2e";
import { useRender } from "/node_modules/.vite/deps/@base-ui_react_use-render.js?v=e9f94b2e";
import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
const badgeVariants = cva("group/badge inline-flex h-5 w-fit shrink-0 items-center justify-center gap-1 overflow-hidden rounded-4xl border border-transparent px-2 py-0.5 text-xs font-medium whitespace-nowrap transition-all focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 has-data-[icon=inline-end]:pr-1.5 has-data-[icon=inline-start]:pl-1.5 aria-invalid:border-destructive aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 [&>svg]:pointer-events-none [&>svg]:size-3!", {
	variants: { variant: {
		default: "bg-primary text-primary-foreground [a]:hover:bg-primary/80",
		secondary: "bg-secondary text-secondary-foreground [a]:hover:bg-secondary/80",
		destructive: "bg-destructive/10 text-destructive focus-visible:ring-destructive/20 dark:bg-destructive/20 dark:focus-visible:ring-destructive/40 [a]:hover:bg-destructive/20",
		outline: "border-border text-foreground [a]:hover:bg-muted [a]:hover:text-muted-foreground",
		ghost: "hover:bg-muted hover:text-muted-foreground dark:hover:bg-muted/50",
		link: "text-primary underline-offset-4 hover:underline"
	} },
	defaultVariants: { variant: "default" }
});
function Badge(t0) {
	const $ = _c(14);
	if ($[0] !== "068bfb367fd21639a5102c95fa7a5dc60b752e5ae531e6554074702da57193b3") {
		for (let $i = 0; $i < 14; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "068bfb367fd21639a5102c95fa7a5dc60b752e5ae531e6554074702da57193b3";
	}
	let render;
	let t1;
	let t2;
	let t3;
	let variant;
	if ($[1] !== t0) {
		const { className, variant: t4, render: t5, ...props } = t0;
		render = t5;
		variant = t4 === undefined ? "default" : t4;
		t3 = useRender;
		t1 = "span";
		t2 = mergeProps({ className: cn(badgeVariants({ variant }), className) }, props);
		$[1] = t0;
		$[2] = render;
		$[3] = t1;
		$[4] = t2;
		$[5] = t3;
		$[6] = variant;
	} else {
		render = $[2];
		t1 = $[3];
		t2 = $[4];
		t3 = $[5];
		variant = $[6];
	}
	let t4;
	if ($[7] !== variant) {
		t4 = {
			slot: "badge",
			variant
		};
		$[7] = variant;
		$[8] = t4;
	} else {
		t4 = $[8];
	}
	let t5;
	if ($[9] !== render || $[10] !== t1 || $[11] !== t2 || $[12] !== t4) {
		t5 = {
			defaultTagName: t1,
			props: t2,
			render,
			state: t4
		};
		$[9] = render;
		$[10] = t1;
		$[11] = t2;
		$[12] = t4;
		$[13] = t5;
	} else {
		t5 = $[13];
	}
	return t3(t5);
}
_c2 = Badge;
export { Badge, badgeVariants };
var _c2;
$RefreshReg$(_c2, "Badge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/badge.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/badge.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/badge.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/badge.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGtCQUFrQjtBQUMzQixTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsV0FBOEI7QUFDdkMsU0FBU0MsVUFBVTtBQUVuQixNQUFNQyxnQkFBZ0JGLElBQ3BCLDhlQUNBO0NBQ0VHLFVBQVUsRUFDUkMsU0FBUztFQUNQQyxTQUFTO0VBQ1RDLFdBQ0U7RUFDRkMsYUFDRTtFQUNGQyxTQUNFO0VBQ0ZDLE9BQ0U7RUFDRkMsTUFBTTtDQUNSLEVBQ0Y7Q0FDQUMsaUJBQWlCLEVBQ2ZQLFNBQVMsVUFDWDtBQUNGLENBQ0Y7QUFFQSxTQUFBUSxNQUFBQyxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBQztDQUFBLElBQUFDO0NBQUEsSUFBQUM7Q0FBQSxJQUFBbEI7Q0FBQSxJQUFBVSxFQUFBLE9BQUFELElBQUE7RUFBZSxRQUFBVSxXQUFBbkIsU0FBQW9CLElBQUFMLFFBQUFNLElBQUEsR0FBQUMsVUFBQWI7RUFBQU0sU0FBQU07RUFFYnJCLFVBQUFvQixPQUFBRyxZQUFBLFlBQUFIO0VBSU96QjtFQUNXcUIsS0FBQTtFQUNUQyxLQUFBdkIsV0FDTCxFQUFBeUIsV0FDYXRCLEdBQUdDLGNBQWMsRUFBQUUsUUFBVSxDQUFDLEdBQUdtQixTQUFTLEVBQ3JELEdBQ0FHLEtBQ0Y7RUFBQ1osRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBTztFQUFBUCxFQUFBLEtBQUFRO0VBQUFSLEVBQUEsS0FBQVY7Q0FBQTtFQUFBZSxTQUFBTCxFQUFBO0VBQUFNLEtBQUFOLEVBQUE7RUFBQU8sS0FBQVAsRUFBQTtFQUFBUSxLQUFBUixFQUFBO0VBQUFWLFVBQUFVLEVBQUE7Q0FBQTtDQUFBLElBQUFVO0NBQUEsSUFBQVYsRUFBQSxPQUFBVixTQUFBO0VBRU1vQixLQUFBO0dBQUFJLE1BQ0M7R0FBT3hCO0VBRWY7RUFBQ1UsRUFBQSxLQUFBVjtFQUFBVSxFQUFBLEtBQUFVO0NBQUE7RUFBQUEsS0FBQVYsRUFBQTtDQUFBO0NBQUEsSUFBQVc7Q0FBQSxJQUFBWCxFQUFBLE9BQUFLLFVBQUFMLEVBQUEsUUFBQU0sTUFBQU4sRUFBQSxRQUFBTyxNQUFBUCxFQUFBLFFBQUFVLElBQUE7RUFaY0MsS0FBQTtHQUFBSSxnQkFDQ1Q7R0FBTU0sT0FDZkw7R0FLTkY7R0FBQVcsT0FFTU47RUFJVDtFQUFDVixFQUFBLEtBQUFLO0VBQUFMLEVBQUEsTUFBQU07RUFBQU4sRUFBQSxNQUFBTztFQUFBUCxFQUFBLE1BQUFVO0VBQUFWLEVBQUEsTUFBQVc7Q0FBQTtFQUFBQSxLQUFBWCxFQUFBO0NBQUE7Q0FBQSxPQWJNZixHQUFVMEIsRUFhaEI7QUFBQzs7QUFHSixTQUFTYixPQUFPViIsIm5hbWVzIjpbIm1lcmdlUHJvcHMiLCJ1c2VSZW5kZXIiLCJjdmEiLCJjbiIsImJhZGdlVmFyaWFudHMiLCJ2YXJpYW50cyIsInZhcmlhbnQiLCJkZWZhdWx0Iiwic2Vjb25kYXJ5IiwiZGVzdHJ1Y3RpdmUiLCJvdXRsaW5lIiwiZ2hvc3QiLCJsaW5rIiwiZGVmYXVsdFZhcmlhbnRzIiwiQmFkZ2UiLCJ0MCIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwicmVuZGVyIiwidDEiLCJ0MiIsInQzIiwiY2xhc3NOYW1lIiwidDQiLCJ0NSIsInByb3BzIiwidW5kZWZpbmVkIiwic2xvdCIsImRlZmF1bHRUYWdOYW1lIiwic3RhdGUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiYmFkZ2UudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IG1lcmdlUHJvcHMgfSBmcm9tIFwiQGJhc2UtdWkvcmVhY3QvbWVyZ2UtcHJvcHNcIlxuaW1wb3J0IHsgdXNlUmVuZGVyIH0gZnJvbSBcIkBiYXNlLXVpL3JlYWN0L3VzZS1yZW5kZXJcIlxuaW1wb3J0IHsgY3ZhLCB0eXBlIFZhcmlhbnRQcm9wcyB9IGZyb20gXCJjbGFzcy12YXJpYW5jZS1hdXRob3JpdHlcIlxuaW1wb3J0IHsgY24gfSBmcm9tIFwiY25cIlxuXG5jb25zdCBiYWRnZVZhcmlhbnRzID0gY3ZhKFxuICBcImdyb3VwL2JhZGdlIGlubGluZS1mbGV4IGgtNSB3LWZpdCBzaHJpbmstMCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXIgZ2FwLTEgb3ZlcmZsb3ctaGlkZGVuIHJvdW5kZWQtNHhsIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgcHgtMiBweS0wLjUgdGV4dC14cyBmb250LW1lZGl1bSB3aGl0ZXNwYWNlLW5vd3JhcCB0cmFuc2l0aW9uLWFsbCBmb2N1cy12aXNpYmxlOmJvcmRlci1yaW5nIGZvY3VzLXZpc2libGU6cmluZy1bM3B4XSBmb2N1cy12aXNpYmxlOnJpbmctcmluZy81MCBoYXMtZGF0YS1baWNvbj1pbmxpbmUtZW5kXTpwci0xLjUgaGFzLWRhdGEtW2ljb249aW5saW5lLXN0YXJ0XTpwbC0xLjUgYXJpYS1pbnZhbGlkOmJvcmRlci1kZXN0cnVjdGl2ZSBhcmlhLWludmFsaWQ6cmluZy1kZXN0cnVjdGl2ZS8yMCBkYXJrOmFyaWEtaW52YWxpZDpyaW5nLWRlc3RydWN0aXZlLzQwIFsmPnN2Z106cG9pbnRlci1ldmVudHMtbm9uZSBbJj5zdmddOnNpemUtMyFcIixcbiAge1xuICAgIHZhcmlhbnRzOiB7XG4gICAgICB2YXJpYW50OiB7XG4gICAgICAgIGRlZmF1bHQ6IFwiYmctcHJpbWFyeSB0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCBbYV06aG92ZXI6YmctcHJpbWFyeS84MFwiLFxuICAgICAgICBzZWNvbmRhcnk6XG4gICAgICAgICAgXCJiZy1zZWNvbmRhcnkgdGV4dC1zZWNvbmRhcnktZm9yZWdyb3VuZCBbYV06aG92ZXI6Ymctc2Vjb25kYXJ5LzgwXCIsXG4gICAgICAgIGRlc3RydWN0aXZlOlxuICAgICAgICAgIFwiYmctZGVzdHJ1Y3RpdmUvMTAgdGV4dC1kZXN0cnVjdGl2ZSBmb2N1cy12aXNpYmxlOnJpbmctZGVzdHJ1Y3RpdmUvMjAgZGFyazpiZy1kZXN0cnVjdGl2ZS8yMCBkYXJrOmZvY3VzLXZpc2libGU6cmluZy1kZXN0cnVjdGl2ZS80MCBbYV06aG92ZXI6YmctZGVzdHJ1Y3RpdmUvMjBcIixcbiAgICAgICAgb3V0bGluZTpcbiAgICAgICAgICBcImJvcmRlci1ib3JkZXIgdGV4dC1mb3JlZ3JvdW5kIFthXTpob3ZlcjpiZy1tdXRlZCBbYV06aG92ZXI6dGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCIsXG4gICAgICAgIGdob3N0OlxuICAgICAgICAgIFwiaG92ZXI6YmctbXV0ZWQgaG92ZXI6dGV4dC1tdXRlZC1mb3JlZ3JvdW5kIGRhcms6aG92ZXI6YmctbXV0ZWQvNTBcIixcbiAgICAgICAgbGluazogXCJ0ZXh0LXByaW1hcnkgdW5kZXJsaW5lLW9mZnNldC00IGhvdmVyOnVuZGVybGluZVwiLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGRlZmF1bHRWYXJpYW50czoge1xuICAgICAgdmFyaWFudDogXCJkZWZhdWx0XCIsXG4gICAgfSxcbiAgfVxuKVxuXG5mdW5jdGlvbiBCYWRnZSh7XG4gIGNsYXNzTmFtZSxcbiAgdmFyaWFudCA9IFwiZGVmYXVsdFwiLFxuICByZW5kZXIsXG4gIC4uLnByb3BzXG59OiB1c2VSZW5kZXIuQ29tcG9uZW50UHJvcHM8XCJzcGFuXCI+ICYgVmFyaWFudFByb3BzPHR5cGVvZiBiYWRnZVZhcmlhbnRzPikge1xuICByZXR1cm4gdXNlUmVuZGVyKHtcbiAgICBkZWZhdWx0VGFnTmFtZTogXCJzcGFuXCIsXG4gICAgcHJvcHM6IG1lcmdlUHJvcHM8XCJzcGFuXCI+KFxuICAgICAge1xuICAgICAgICBjbGFzc05hbWU6IGNuKGJhZGdlVmFyaWFudHMoeyB2YXJpYW50IH0pLCBjbGFzc05hbWUpLFxuICAgICAgfSxcbiAgICAgIHByb3BzXG4gICAgKSxcbiAgICByZW5kZXIsXG4gICAgc3RhdGU6IHtcbiAgICAgIHNsb3Q6IFwiYmFkZ2VcIixcbiAgICAgIHZhcmlhbnQsXG4gICAgfSxcbiAgfSlcbn1cblxuZXhwb3J0IHsgQmFkZ2UsIGJhZGdlVmFyaWFudHMgfVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvY29tcG9uZW50cy91aS9iYWRnZS50c3gifQ==