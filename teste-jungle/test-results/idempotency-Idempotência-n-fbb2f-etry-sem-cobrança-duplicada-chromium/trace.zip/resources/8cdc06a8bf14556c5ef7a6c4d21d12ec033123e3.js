import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/nft/nft-filters.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const useId = __vite__cjsImport1_react["useId"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=e9f94b2e";
import { RotateCcw, Search, SlidersHorizontal, X } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { Card, CardContent } from "/src/components/ui/card.tsx";
import { Input } from "/src/components/ui/input.tsx";
import { Label } from "/src/components/ui/label.tsx";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "/src/components/ui/select.tsx";
import { Separator } from "/src/components/ui/separator.tsx";
import { Switch } from "/src/components/ui/switch.tsx";
import { isValidEthString } from "/src/lib/eth.ts";
import { CATEGORY_LABELS, NFT_CATEGORIES, NFT_SORT_OPTIONS, SORT_LABELS } from "/src/schemas/nft-search.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-filters.tsx";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
const ALL_COLLECTIONS_VALUE = "__all__";
/**
* Painel semântico (`<aside>`) de busca, filtros combináveis e ordenação.
* O estado de filtros reside 100% na URL (`search`). Apenas erros de formato de input local usam estado de validação A11y.
*/
export function NftFilters(t0) {
	_s();
	const $ = _c(140);
	if ($[0] !== "1a143649695f194aefe42cb153e55879ce2d66b3f0e7990926543a2e120b6698") {
		for (let $i = 0; $i < 140; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "1a143649695f194aefe42cb153e55879ce2d66b3f0e7990926543a2e120b6698";
	}
	const { search, collections, onFilterChange, onResetFilters } = t0;
	const searchInputId = useId();
	const searchHintId = `${searchInputId}-hint`;
	const minPriceId = useId();
	const minPriceDescId = `${minPriceId}-desc`;
	const maxPriceId = useId();
	const maxPriceDescId = `${maxPriceId}-desc`;
	const availableSwitchId = useId();
	const favoritesSwitchId = useId();
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = {};
		$[1] = t1;
	} else {
		t1 = $[1];
	}
	const [priceErrors, setPriceErrors] = useState(t1);
	const hasActiveFilters = Boolean(search.q || search.category || search.collection || search.minPrice || search.maxPrice || search.onlyAvailable || search.onlyFavorites || search.sort !== "recent");
	let t2;
	if ($[2] !== onFilterChange) {
		t2 = (e) => {
			e.preventDefault();
			const formData = new FormData(e.currentTarget);
			const q = formData.get("q")?.trim() || undefined;
			const minPrice = formData.get("minPrice")?.trim() || undefined;
			const maxPrice = formData.get("maxPrice")?.trim() || undefined;
			const nextErrors = {};
			if (minPrice && !isValidEthString(minPrice)) {
				nextErrors.min = "Informe um valor decimal em ETH válido (ex: 0.5).";
			}
			if (maxPrice && !isValidEthString(maxPrice)) {
				nextErrors.max = "Informe um valor decimal em ETH válido (ex: 3.0).";
			}
			setPriceErrors(nextErrors);
			if (nextErrors.min || nextErrors.max) {
				return;
			}
			onFilterChange({
				q,
				minPrice,
				maxPrice
			});
		};
		$[2] = onFilterChange;
		$[3] = t2;
	} else {
		t2 = $[3];
	}
	const handleSearchFormSubmit = t2;
	const t3 = `${search.q ?? ""}|${search.minPrice ?? ""}|${search.maxPrice ?? ""}`;
	let t4;
	if ($[4] !== searchInputId) {
		t4 = /* @__PURE__ */ _jsxDEV(Label, {
			htmlFor: searchInputId,
			className: "text-xs",
			children: "Buscar no catálogo"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 92,
			columnNumber: 10
		}, this);
		$[4] = searchInputId;
		$[5] = t4;
	} else {
		t4 = $[5];
	}
	let t5;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t5 = /* @__PURE__ */ _jsxDEV(Search, {
			className: "pointer-events-none absolute top-1/2 left-2.5 size-4 -translate-y-1/2 text-muted-foreground",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 100,
			columnNumber: 10
		}, this);
		$[6] = t5;
	} else {
		t5 = $[6];
	}
	const t6 = search.q ?? "";
	let t7;
	if ($[7] !== searchHintId || $[8] !== searchInputId || $[9] !== t6) {
		t7 = /* @__PURE__ */ _jsxDEV("div", {
			className: "relative",
			children: [t5, /* @__PURE__ */ _jsxDEV(Input, {
				id: searchInputId,
				name: "q",
				type: "search",
				defaultValue: t6,
				placeholder: "Nome, coleção ou criador...",
				"aria-invalid": false,
				"aria-describedby": searchHintId,
				className: "pl-8"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 108,
				columnNumber: 40
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 108,
			columnNumber: 10
		}, this);
		$[7] = searchHintId;
		$[8] = searchInputId;
		$[9] = t6;
		$[10] = t7;
	} else {
		t7 = $[10];
	}
	let t8;
	if ($[11] !== searchHintId) {
		t8 = /* @__PURE__ */ _jsxDEV("span", {
			id: searchHintId,
			className: "sr-only",
			children: "Filtra NFTs por título, descrição, coleção ou nome do artista."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 118,
			columnNumber: 10
		}, this);
		$[11] = searchHintId;
		$[12] = t8;
	} else {
		t8 = $[12];
	}
	let t9;
	if ($[13] !== t4 || $[14] !== t7 || $[15] !== t8) {
		t9 = /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-1.5 md:col-span-5",
			children: [
				t4,
				t7,
				t8
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 126,
			columnNumber: 10
		}, this);
		$[13] = t4;
		$[14] = t7;
		$[15] = t8;
		$[16] = t9;
	} else {
		t9 = $[16];
	}
	let t10;
	if ($[17] !== minPriceId) {
		t10 = /* @__PURE__ */ _jsxDEV(Label, {
			htmlFor: minPriceId,
			className: "text-xs",
			children: "Preço mín. (ETH)"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 136,
			columnNumber: 11
		}, this);
		$[17] = minPriceId;
		$[18] = t10;
	} else {
		t10 = $[18];
	}
	const t11 = search.minPrice ?? "";
	const t12 = Boolean(priceErrors.min);
	let t13;
	if ($[19] !== minPriceDescId || $[20] !== minPriceId || $[21] !== t11 || $[22] !== t12) {
		t13 = /* @__PURE__ */ _jsxDEV(Input, {
			id: minPriceId,
			name: "minPrice",
			inputMode: "decimal",
			defaultValue: t11,
			placeholder: "Ex: 0.5",
			"aria-invalid": t12,
			"aria-describedby": minPriceDescId
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 146,
			columnNumber: 11
		}, this);
		$[19] = minPriceDescId;
		$[20] = minPriceId;
		$[21] = t11;
		$[22] = t12;
		$[23] = t13;
	} else {
		t13 = $[23];
	}
	let t14;
	if ($[24] !== minPriceDescId || $[25] !== priceErrors.min) {
		t14 = priceErrors.min ? /* @__PURE__ */ _jsxDEV("p", {
			id: minPriceDescId,
			role: "alert",
			className: "text-xs text-destructive",
			children: priceErrors.min
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 157,
			columnNumber: 29
		}, this) : /* @__PURE__ */ _jsxDEV("span", {
			id: minPriceDescId,
			className: "sr-only",
			children: "Valor mínimo em ETH usando ponto decimal."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 157,
			columnNumber: 126
		}, this);
		$[24] = minPriceDescId;
		$[25] = priceErrors.min;
		$[26] = t14;
	} else {
		t14 = $[26];
	}
	let t15;
	if ($[27] !== t10 || $[28] !== t13 || $[29] !== t14) {
		t15 = /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-1.5",
			children: [
				t10,
				t13,
				t14
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 166,
			columnNumber: 11
		}, this);
		$[27] = t10;
		$[28] = t13;
		$[29] = t14;
		$[30] = t15;
	} else {
		t15 = $[30];
	}
	let t16;
	if ($[31] !== maxPriceId) {
		t16 = /* @__PURE__ */ _jsxDEV(Label, {
			htmlFor: maxPriceId,
			className: "text-xs",
			children: "Preço máx. (ETH)"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 176,
			columnNumber: 11
		}, this);
		$[31] = maxPriceId;
		$[32] = t16;
	} else {
		t16 = $[32];
	}
	const t17 = search.maxPrice ?? "";
	const t18 = Boolean(priceErrors.max);
	let t19;
	if ($[33] !== maxPriceDescId || $[34] !== maxPriceId || $[35] !== t17 || $[36] !== t18) {
		t19 = /* @__PURE__ */ _jsxDEV(Input, {
			id: maxPriceId,
			name: "maxPrice",
			inputMode: "decimal",
			defaultValue: t17,
			placeholder: "Ex: 3.0",
			"aria-invalid": t18,
			"aria-describedby": maxPriceDescId
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 186,
			columnNumber: 11
		}, this);
		$[33] = maxPriceDescId;
		$[34] = maxPriceId;
		$[35] = t17;
		$[36] = t18;
		$[37] = t19;
	} else {
		t19 = $[37];
	}
	let t20;
	if ($[38] !== maxPriceDescId || $[39] !== priceErrors.max) {
		t20 = priceErrors.max ? /* @__PURE__ */ _jsxDEV("p", {
			id: maxPriceDescId,
			role: "alert",
			className: "text-xs text-destructive",
			children: priceErrors.max
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 197,
			columnNumber: 29
		}, this) : /* @__PURE__ */ _jsxDEV("span", {
			id: maxPriceDescId,
			className: "sr-only",
			children: "Valor máximo em ETH usando ponto decimal."
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 197,
			columnNumber: 126
		}, this);
		$[38] = maxPriceDescId;
		$[39] = priceErrors.max;
		$[40] = t20;
	} else {
		t20 = $[40];
	}
	let t21;
	if ($[41] !== t16 || $[42] !== t19 || $[43] !== t20) {
		t21 = /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-1.5",
			children: [
				t16,
				t19,
				t20
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 206,
			columnNumber: 11
		}, this);
		$[41] = t16;
		$[42] = t19;
		$[43] = t20;
		$[44] = t21;
	} else {
		t21 = $[44];
	}
	let t22;
	if ($[45] !== t15 || $[46] !== t21) {
		t22 = /* @__PURE__ */ _jsxDEV("div", {
			className: "grid grid-cols-2 gap-2 md:col-span-5",
			children: [t15, t21]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 216,
			columnNumber: 11
		}, this);
		$[45] = t15;
		$[46] = t21;
		$[47] = t22;
	} else {
		t22 = $[47];
	}
	let t23;
	if ($[48] === Symbol.for("react.memo_cache_sentinel")) {
		t23 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex gap-2 md:col-span-2 md:pt-5",
			children: /* @__PURE__ */ _jsxDEV(Button, {
				type: "submit",
				className: "w-full",
				children: [/* @__PURE__ */ _jsxDEV(SlidersHorizontal, {
					className: "size-4",
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 225,
					columnNumber: 102
				}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Aplicar" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 225,
					columnNumber: 161
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 225,
				columnNumber: 61
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 225,
			columnNumber: 11
		}, this);
		$[48] = t23;
	} else {
		t23 = $[48];
	}
	let t24;
	if ($[49] !== handleSearchFormSubmit || $[50] !== t22 || $[51] !== t3 || $[52] !== t9) {
		t24 = /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSearchFormSubmit,
			noValidate: true,
			className: "grid items-start gap-3 md:grid-cols-12",
			children: [
				t9,
				t22,
				t23
			]
		}, t3, true, {
			fileName: _jsxFileName,
			lineNumber: 232,
			columnNumber: 11
		}, this);
		$[49] = handleSearchFormSubmit;
		$[50] = t22;
		$[51] = t3;
		$[52] = t9;
		$[53] = t24;
	} else {
		t24 = $[53];
	}
	const t25 = search.category === undefined ? "default" : "outline";
	const t26 = search.category === undefined;
	let t27;
	if ($[54] !== onFilterChange) {
		t27 = () => onFilterChange({ category: undefined });
		$[54] = onFilterChange;
		$[55] = t27;
	} else {
		t27 = $[55];
	}
	let t28;
	if ($[56] !== t25 || $[57] !== t26 || $[58] !== t27) {
		t28 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			size: "xs",
			variant: t25,
			"aria-pressed": t26,
			onClick: t27,
			children: "Todas"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 255,
			columnNumber: 11
		}, this);
		$[56] = t25;
		$[57] = t26;
		$[58] = t27;
		$[59] = t28;
	} else {
		t28 = $[59];
	}
	let t29;
	if ($[60] !== onFilterChange || $[61] !== search.category) {
		t29 = NFT_CATEGORIES.map((cat) => {
			const isSelected = search.category === cat;
			return /* @__PURE__ */ _jsxDEV(Button, {
				type: "button",
				size: "xs",
				variant: isSelected ? "default" : "outline",
				"aria-pressed": isSelected,
				onClick: () => onFilterChange({ category: isSelected ? undefined : cat }),
				children: CATEGORY_LABELS[cat]
			}, cat, false, {
				fileName: _jsxFileName,
				lineNumber: 267,
				columnNumber: 14
			}, this);
		});
		$[60] = onFilterChange;
		$[61] = search.category;
		$[62] = t29;
	} else {
		t29 = $[62];
	}
	let t30;
	if ($[63] !== t28 || $[64] !== t29) {
		t30 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-wrap items-center gap-1.5",
			role: "group",
			"aria-label": "Filtrar por categoria",
			children: [t28, t29]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 279,
			columnNumber: 11
		}, this);
		$[63] = t28;
		$[64] = t29;
		$[65] = t30;
	} else {
		t30 = $[65];
	}
	let t31;
	if ($[66] === Symbol.for("react.memo_cache_sentinel")) {
		t31 = /* @__PURE__ */ _jsxDEV(Separator, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 288,
			columnNumber: 11
		}, this);
		$[66] = t31;
	} else {
		t31 = $[66];
	}
	let t32;
	if ($[67] === Symbol.for("react.memo_cache_sentinel")) {
		t32 = /* @__PURE__ */ _jsxDEV("span", {
			className: "text-xs font-medium text-muted-foreground",
			children: "Coleção:"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 295,
			columnNumber: 11
		}, this);
		$[67] = t32;
	} else {
		t32 = $[67];
	}
	const t33 = search.collection ?? ALL_COLLECTIONS_VALUE;
	let t34;
	if ($[68] !== onFilterChange) {
		t34 = (value) => onFilterChange({ collection: !value || value === ALL_COLLECTIONS_VALUE ? undefined : value });
		$[68] = onFilterChange;
		$[69] = t34;
	} else {
		t34 = $[69];
	}
	const t35 = search.collection ?? "Todas as coleções";
	let t36;
	if ($[70] !== t35) {
		t36 = /* @__PURE__ */ _jsxDEV(SelectTrigger, {
			"aria-label": "Filtrar por coleção",
			className: "min-w-44",
			children: /* @__PURE__ */ _jsxDEV(SelectValue, {
				placeholder: "Todas as coleções",
				children: t35
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 314,
				columnNumber: 88
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 314,
			columnNumber: 11
		}, this);
		$[70] = t35;
		$[71] = t36;
	} else {
		t36 = $[71];
	}
	let t37;
	if ($[72] === Symbol.for("react.memo_cache_sentinel")) {
		t37 = /* @__PURE__ */ _jsxDEV(SelectItem, {
			value: ALL_COLLECTIONS_VALUE,
			children: "Todas as coleções"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 322,
			columnNumber: 11
		}, this);
		$[72] = t37;
	} else {
		t37 = $[72];
	}
	let t38;
	if ($[73] !== collections) {
		t38 = collections.map(_temp);
		$[73] = collections;
		$[74] = t38;
	} else {
		t38 = $[74];
	}
	let t39;
	if ($[75] !== t38) {
		t39 = /* @__PURE__ */ _jsxDEV(SelectContent, { children: [t37, t38] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 337,
			columnNumber: 11
		}, this);
		$[75] = t38;
		$[76] = t39;
	} else {
		t39 = $[76];
	}
	let t40;
	if ($[77] !== t33 || $[78] !== t34 || $[79] !== t36 || $[80] !== t39) {
		t40 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-2",
			children: [t32, /* @__PURE__ */ _jsxDEV(Select, {
				value: t33,
				onValueChange: t34,
				children: [t36, t39]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 345,
				columnNumber: 57
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 345,
			columnNumber: 11
		}, this);
		$[77] = t33;
		$[78] = t34;
		$[79] = t36;
		$[80] = t39;
		$[81] = t40;
	} else {
		t40 = $[81];
	}
	const t41 = Boolean(search.onlyAvailable);
	let t42;
	if ($[82] !== onFilterChange) {
		t42 = (checked) => onFilterChange({ onlyAvailable: checked ? true : undefined });
		$[82] = onFilterChange;
		$[83] = t42;
	} else {
		t42 = $[83];
	}
	let t43;
	if ($[84] !== availableSwitchId || $[85] !== t41 || $[86] !== t42) {
		t43 = /* @__PURE__ */ _jsxDEV(Switch, {
			id: availableSwitchId,
			checked: t41,
			onCheckedChange: t42
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 367,
			columnNumber: 11
		}, this);
		$[84] = availableSwitchId;
		$[85] = t41;
		$[86] = t42;
		$[87] = t43;
	} else {
		t43 = $[87];
	}
	let t44;
	if ($[88] !== availableSwitchId) {
		t44 = /* @__PURE__ */ _jsxDEV(Label, {
			htmlFor: availableSwitchId,
			className: "cursor-pointer text-xs",
			children: "Apenas disponíveis"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 377,
			columnNumber: 11
		}, this);
		$[88] = availableSwitchId;
		$[89] = t44;
	} else {
		t44 = $[89];
	}
	let t45;
	if ($[90] !== t43 || $[91] !== t44) {
		t45 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-2",
			children: [t43, t44]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 385,
			columnNumber: 11
		}, this);
		$[90] = t43;
		$[91] = t44;
		$[92] = t45;
	} else {
		t45 = $[92];
	}
	const t46 = Boolean(search.onlyFavorites);
	let t47;
	if ($[93] !== onFilterChange) {
		t47 = (checked_0) => onFilterChange({ onlyFavorites: checked_0 ? true : undefined });
		$[93] = onFilterChange;
		$[94] = t47;
	} else {
		t47 = $[94];
	}
	let t48;
	if ($[95] !== favoritesSwitchId || $[96] !== t46 || $[97] !== t47) {
		t48 = /* @__PURE__ */ _jsxDEV(Switch, {
			id: favoritesSwitchId,
			checked: t46,
			onCheckedChange: t47
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 405,
			columnNumber: 11
		}, this);
		$[95] = favoritesSwitchId;
		$[96] = t46;
		$[97] = t47;
		$[98] = t48;
	} else {
		t48 = $[98];
	}
	let t49;
	if ($[99] !== favoritesSwitchId) {
		t49 = /* @__PURE__ */ _jsxDEV(Label, {
			htmlFor: favoritesSwitchId,
			className: "cursor-pointer text-xs",
			children: "Meus favoritos"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 415,
			columnNumber: 11
		}, this);
		$[99] = favoritesSwitchId;
		$[100] = t49;
	} else {
		t49 = $[100];
	}
	let t50;
	if ($[101] !== t48 || $[102] !== t49) {
		t50 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-2",
			children: [t48, t49]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 423,
			columnNumber: 11
		}, this);
		$[101] = t48;
		$[102] = t49;
		$[103] = t50;
	} else {
		t50 = $[103];
	}
	let t51;
	if ($[104] !== t40 || $[105] !== t45 || $[106] !== t50) {
		t51 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-wrap items-center gap-4",
			children: [
				t40,
				t45,
				t50
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 432,
			columnNumber: 11
		}, this);
		$[104] = t40;
		$[105] = t45;
		$[106] = t50;
		$[107] = t51;
	} else {
		t51 = $[107];
	}
	let t52;
	if ($[108] === Symbol.for("react.memo_cache_sentinel")) {
		t52 = /* @__PURE__ */ _jsxDEV("span", {
			className: "text-xs font-medium text-muted-foreground",
			children: "Ordenar:"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 442,
			columnNumber: 11
		}, this);
		$[108] = t52;
	} else {
		t52 = $[108];
	}
	let t53;
	if ($[109] !== onFilterChange) {
		t53 = (value_0) => {
			if (value_0) {
				onFilterChange({ sort: value_0 });
			}
		};
		$[109] = onFilterChange;
		$[110] = t53;
	} else {
		t53 = $[110];
	}
	const t54 = SORT_LABELS[search.sort];
	let t55;
	if ($[111] !== t54) {
		t55 = /* @__PURE__ */ _jsxDEV(SelectTrigger, {
			"aria-label": "Ordenar catálogo",
			className: "min-w-44",
			children: /* @__PURE__ */ _jsxDEV(SelectValue, { children: t54 }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 464,
				columnNumber: 82
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 464,
			columnNumber: 11
		}, this);
		$[111] = t54;
		$[112] = t55;
	} else {
		t55 = $[112];
	}
	let t56;
	if ($[113] === Symbol.for("react.memo_cache_sentinel")) {
		t56 = /* @__PURE__ */ _jsxDEV(SelectContent, { children: NFT_SORT_OPTIONS.map(_temp2) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 472,
			columnNumber: 11
		}, this);
		$[113] = t56;
	} else {
		t56 = $[113];
	}
	let t57;
	if ($[114] !== search.sort || $[115] !== t53 || $[116] !== t55) {
		t57 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-2",
			children: [t52, /* @__PURE__ */ _jsxDEV(Select, {
				value: search.sort,
				onValueChange: t53,
				children: [t55, t56]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 479,
				columnNumber: 57
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 479,
			columnNumber: 11
		}, this);
		$[114] = search.sort;
		$[115] = t53;
		$[116] = t55;
		$[117] = t57;
	} else {
		t57 = $[117];
	}
	let t58;
	if ($[118] !== hasActiveFilters || $[119] !== onResetFilters) {
		t58 = hasActiveFilters && /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			variant: "ghost",
			size: "sm",
			onClick: () => {
				setPriceErrors({});
				onResetFilters();
			},
			"aria-label": "Limpar todos os filtros",
			children: [/* @__PURE__ */ _jsxDEV(RotateCcw, {
				className: "size-3.5",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 492,
				columnNumber: 45
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Limpar" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 492,
				columnNumber: 98
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 489,
			columnNumber: 31
		}, this);
		$[118] = hasActiveFilters;
		$[119] = onResetFilters;
		$[120] = t58;
	} else {
		t58 = $[120];
	}
	let t59;
	if ($[121] !== t57 || $[122] !== t58) {
		t59 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [t57, t58]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 501,
			columnNumber: 11
		}, this);
		$[121] = t57;
		$[122] = t58;
		$[123] = t59;
	} else {
		t59 = $[123];
	}
	let t60;
	if ($[124] !== t51 || $[125] !== t59) {
		t60 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-col justify-between gap-4 lg:flex-row lg:items-center",
			children: [t51, t59]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 510,
			columnNumber: 11
		}, this);
		$[124] = t51;
		$[125] = t59;
		$[126] = t60;
	} else {
		t60 = $[126];
	}
	let t61;
	if ($[127] !== hasActiveFilters || $[128] !== onFilterChange || $[129] !== search.category || $[130] !== search.collection || $[131] !== search.maxPrice || $[132] !== search.minPrice || $[133] !== search.q) {
		t61 = hasActiveFilters && /* @__PURE__ */ _jsxDEV("div", {
			className: "flex flex-wrap items-center gap-2 pt-1",
			"aria-label": "Filtros ativos",
			children: [
				/* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs text-muted-foreground",
					children: "Ativos:"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 519,
					columnNumber: 115
				}, this),
				search.q && /* @__PURE__ */ _jsxDEV(Badge, {
					variant: "secondary",
					className: "gap-1",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "max-w-36 truncate",
						children: [
							"Busca: “",
							search.q,
							"”"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 519,
						columnNumber: 235
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						"aria-label": "Remover filtro de busca",
						onClick: () => onFilterChange({ q: undefined }),
						className: "rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
						children: /* @__PURE__ */ _jsxDEV(X, {
							className: "size-3",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 521,
							columnNumber: 110
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 519,
						columnNumber: 297
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 519,
					columnNumber: 190
				}, this),
				search.category && /* @__PURE__ */ _jsxDEV(Badge, {
					variant: "secondary",
					className: "gap-1",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: CATEGORY_LABELS[search.category] }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 521,
						columnNumber: 236
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						"aria-label": "Remover filtro de categoria",
						onClick: () => onFilterChange({ category: undefined }),
						className: "rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
						children: /* @__PURE__ */ _jsxDEV(X, {
							className: "size-3",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 523,
							columnNumber: 110
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 521,
						columnNumber: 283
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 521,
					columnNumber: 191
				}, this),
				search.collection && /* @__PURE__ */ _jsxDEV(Badge, {
					variant: "secondary",
					className: "gap-1",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						className: "max-w-36 truncate",
						children: search.collection
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 523,
						columnNumber: 238
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						"aria-label": "Remover filtro de coleção",
						onClick: () => onFilterChange({ collection: undefined }),
						className: "rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
						children: /* @__PURE__ */ _jsxDEV(X, {
							className: "size-3",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 525,
							columnNumber: 110
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 523,
						columnNumber: 300
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 523,
					columnNumber: 193
				}, this),
				(search.minPrice || search.maxPrice) && /* @__PURE__ */ _jsxDEV(Badge, {
					variant: "secondary",
					className: "gap-1 font-mono",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: [
						search.minPrice ?? "0",
						" – ",
						search.maxPrice ?? "∞",
						" ETH"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 525,
						columnNumber: 267
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						"aria-label": "Remover filtro de faixa de preço",
						onClick: () => onFilterChange({
							minPrice: undefined,
							maxPrice: undefined
						}),
						className: "rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
						children: /* @__PURE__ */ _jsxDEV(X, {
							className: "size-3",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 528,
							columnNumber: 110
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 525,
						columnNumber: 340
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 525,
					columnNumber: 212
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 519,
			columnNumber: 31
		}, this);
		$[127] = hasActiveFilters;
		$[128] = onFilterChange;
		$[129] = search.category;
		$[130] = search.collection;
		$[131] = search.maxPrice;
		$[132] = search.minPrice;
		$[133] = search.q;
		$[134] = t61;
	} else {
		t61 = $[134];
	}
	let t62;
	if ($[135] !== t24 || $[136] !== t30 || $[137] !== t60 || $[138] !== t61) {
		t62 = /* @__PURE__ */ _jsxDEV("aside", {
			"aria-label": "Filtros e ordenação do catálogo",
			children: /* @__PURE__ */ _jsxDEV(Card, { children: /* @__PURE__ */ _jsxDEV(CardContent, {
				className: "grid gap-4",
				children: [
					t24,
					t30,
					t31,
					t60,
					t61
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 542,
				columnNumber: 80
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 542,
				columnNumber: 74
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 542,
			columnNumber: 11
		}, this);
		$[135] = t24;
		$[136] = t30;
		$[137] = t60;
		$[138] = t61;
		$[139] = t62;
	} else {
		t62 = $[139];
	}
	return t62;
}
_s(NftFilters, "GBlGBPIkoE79KlIUB7awRTnTnus=");
_c2 = NftFilters;
function _temp2(opt) {
	return /* @__PURE__ */ _jsxDEV(SelectItem, {
		value: opt,
		children: SORT_LABELS[opt]
	}, opt, false, {
		fileName: _jsxFileName,
		lineNumber: 554,
		columnNumber: 10
	}, this);
}
function _temp(col) {
	return /* @__PURE__ */ _jsxDEV(SelectItem, {
		value: col,
		children: col
	}, col, false, {
		fileName: _jsxFileName,
		lineNumber: 557,
		columnNumber: 10
	}, this);
}
var _c2;
$RefreshReg$(_c2, "NftFilters");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/nft/nft-filters.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-filters.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-filters.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-filters.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLE9BQU9DLGdCQUFnQztBQUNoRCxTQUFTQyxXQUFXQyxRQUFRQyxtQkFBbUJDLFNBQVM7QUFDeEQsU0FBU0MsYUFBYTtBQUN0QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLE1BQU1DLG1CQUFtQjtBQUNsQyxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLGFBQWE7QUFDdEIsU0FDRUMsUUFDQUMsZUFDQUMsWUFDQUMsZUFDQUMsbUJBQ0s7QUFDUCxTQUFTQyxpQkFBaUI7QUFDMUIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyx3QkFBd0I7QUFDakMsU0FDRUMsaUJBQ0FDLGdCQUNBQyxrQkFDQUMsbUJBRUs7Ozs7QUFHUCxNQUFNQyx3QkFBd0I7Ozs7O0FBYTlCLE9BQU8sU0FBQUMsV0FBQUMsSUFBQTs7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxLQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBb0IsUUFBQUssUUFBQUMsYUFBQUMsZ0JBQUFDLG1CQUFBVDtDQU16QixNQUFBVSxnQkFBc0JwQyxNQUFNO0NBQzVCLE1BQUFxQyxlQUFxQixHQUFHRCxjQUFhO0NBQ3JDLE1BQUFFLGFBQW1CdEMsTUFBTTtDQUN6QixNQUFBdUMsaUJBQXVCLEdBQUdELFdBQVU7Q0FDcEMsTUFBQUUsYUFBbUJ4QyxNQUFNO0NBQ3pCLE1BQUF5QyxpQkFBdUIsR0FBR0QsV0FBVTtDQUNwQyxNQUFBRSxvQkFBMEIxQyxNQUFNO0NBQ2hDLE1BQUEyQyxvQkFBMEIzQyxNQUFNO0NBQUMsSUFBQTRDO0NBQUEsSUFBQWpCLEVBQUEsT0FBQUcsT0FBQUMsSUFBQTtFQUU4Q2EsS0FBQSxDQUFDO0VBQUNqQixFQUFBLEtBQUFpQjtDQUFBO0VBQUFBLEtBQUFqQixFQUFBO0NBQUE7Q0FBakYsT0FBQWtCLGFBQUFDLGtCQUFzQzdDLFNBQXlDMkMsRUFBRTtDQUVqRixNQUFBRyxtQkFBeUJDLFFBQ3ZCaEIsT0FBTWlCLEtBQ0pqQixPQUFNa0IsWUFDTmxCLE9BQU1tQixjQUNObkIsT0FBTW9CLFlBQ05wQixPQUFNcUIsWUFDTnJCLE9BQU1zQixpQkFDTnRCLE9BQU11QixpQkFDTnZCLE9BQU13QixTQUFVLFFBQ3BCO0NBQUMsSUFBQUM7Q0FBQSxJQUFBOUIsRUFBQSxPQUFBTyxnQkFBQTtFQUU4QnVCLE1BQUFDLE1BQUE7R0FDN0JBLEVBQUNDLGVBQWdCO0dBQ2pCLE1BQUFDLFdBQWlCLElBQUlDLFNBQVNILEVBQUNJLGFBQWM7R0FDN0MsTUFBQWIsSUFBV1csU0FBUUcsSUFBSyxHQUFHLENBQUMsRUFBd0JDLEtBQWMsS0FBeERDO0dBQ1YsTUFBQWIsV0FBa0JRLFNBQVFHLElBQUssVUFBVSxDQUFDLEVBQXdCQyxLQUFjLEtBQS9EQztHQUNqQixNQUFBWixXQUFrQk8sU0FBUUcsSUFBSyxVQUFVLENBQUMsRUFBd0JDLEtBQWMsS0FBL0RDO0dBRWpCLE1BQUFDLGFBQW1ELENBQUM7R0FDcEQsSUFBSWQsWUFBQSxDQUFhakMsaUJBQWlCaUMsUUFBUSxHQUFDO0lBQ3pDYyxXQUFVQyxNQUFPO0dBQUg7R0FFaEIsSUFBSWQsWUFBQSxDQUFhbEMsaUJBQWlCa0MsUUFBUSxHQUFDO0lBQ3pDYSxXQUFVRSxNQUFPO0dBQUg7R0FHaEJ0QixlQUFlb0IsVUFBVTtHQUN6QixJQUFJQSxXQUFVQyxPQUFRRCxXQUFVRSxLQUFJO0lBQUE7R0FBQTtHQUVwQ2xDLGVBQWU7SUFBQWU7SUFBQUc7SUFBQUM7R0FBd0IsQ0FBQztFQUFDO0VBQzFDMUIsRUFBQSxLQUFBTztFQUFBUCxFQUFBLEtBQUE4QjtDQUFBO0VBQUFBLEtBQUE5QixFQUFBO0NBQUE7Q0FuQkQsTUFBQTBDLHlCQUErQlo7Q0EwQmhCLE1BQUFhLEtBQUEsR0FBR3RDLE9BQU1pQixLQUFOLEdBQWMsR0FBSWpCLE9BQU1vQixZQUFOLEdBQXFCLEdBQUlwQixPQUFNcUIsWUFBTjtDQUF1QixJQUFBa0I7Q0FBQSxJQUFBNUMsRUFBQSxPQUFBUyxlQUFBO0VBTXhFbUMsS0FBQSx3QkFBQyxPQUFEO0dBQWdCbkM7R0FBeUI7YUFBVTtFQUE3Qzs7Ozs7RUFFRVQsRUFBQSxLQUFBUztFQUFBVCxFQUFBLEtBQUE0QztDQUFBO0VBQUFBLEtBQUE1QyxFQUFBO0NBQUE7Q0FBQSxJQUFBNkM7Q0FBQSxJQUFBN0MsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBRU55QyxLQUFBLHdCQUFDLFFBQUQ7R0FDWTtHQUNFO0VBQU07Ozs7O0VBQ2xCN0MsRUFBQSxLQUFBNkM7Q0FBQTtFQUFBQSxLQUFBN0MsRUFBQTtDQUFBO0NBS2MsTUFBQThDLEtBQUF6QyxPQUFNaUIsS0FBTjtDQUFjLElBQUF5QjtDQUFBLElBQUEvQyxFQUFBLE9BQUFVLGdCQUFBVixFQUFBLE9BQUFTLGlCQUFBVCxFQUFBLE9BQUE4QyxJQUFBO0VBVGhDQyxLQUFBO0dBQWU7YUFBZixDQUNFRixJQUlBLHdCQUFDLE9BQUQ7SUFDTXBDO0lBQ0M7SUFDQTtJQUNTLGNBQUFxQztJQUNGO0lBQ0U7SUFDSXBDO0lBQ1I7R0FBTTs7OztXQUVkOzs7Ozs7RUFBQVYsRUFBQSxLQUFBVTtFQUFBVixFQUFBLEtBQUFTO0VBQUFULEVBQUEsS0FBQThDO0VBQUE5QyxFQUFBLE1BQUErQztDQUFBO0VBQUFBLEtBQUEvQyxFQUFBO0NBQUE7Q0FBQSxJQUFBZ0Q7Q0FBQSxJQUFBaEQsRUFBQSxRQUFBVSxjQUFBO0VBQ05zQyxLQUFBO0dBQVV0QztHQUF3QjthQUFVO0VBRXJDOzs7OztFQUFBVixFQUFBLE1BQUFVO0VBQUFWLEVBQUEsTUFBQWdEO0NBQUE7RUFBQUEsS0FBQWhELEVBQUE7Q0FBQTtDQUFBLElBQUFpRDtDQUFBLElBQUFqRCxFQUFBLFFBQUE0QyxNQUFBNUMsRUFBQSxRQUFBK0MsTUFBQS9DLEVBQUEsUUFBQWdELElBQUE7RUF0QlRDLEtBQUE7R0FBZTthQUFmO0lBQ0VMO0lBR0FHO0lBZ0JBQztHQUdJOzs7Ozs7RUFBQWhELEVBQUEsTUFBQTRDO0VBQUE1QyxFQUFBLE1BQUErQztFQUFBL0MsRUFBQSxNQUFBZ0Q7RUFBQWhELEVBQUEsTUFBQWlEO0NBQUE7RUFBQUEsS0FBQWpELEVBQUE7Q0FBQTtDQUFBLElBQUFrRDtDQUFBLElBQUFsRCxFQUFBLFFBQUFXLFlBQUE7RUFJRnVDLE1BQUEsd0JBQUMsT0FBRDtHQUFnQnZDO0dBQXNCO2FBQVU7RUFBMUM7Ozs7O0VBRUVYLEVBQUEsTUFBQVc7RUFBQVgsRUFBQSxNQUFBa0Q7Q0FBQTtFQUFBQSxNQUFBbEQsRUFBQTtDQUFBO0NBS1EsTUFBQW1ELE1BQUE5QyxPQUFNb0IsWUFBTjtDQUVBLE1BQUEyQixNQUFBL0IsUUFBUUgsWUFBV3NCLEdBQUk7Q0FBQyxJQUFBYTtDQUFBLElBQUFyRCxFQUFBLFFBQUFZLGtCQUFBWixFQUFBLFFBQUFXLGNBQUFYLEVBQUEsUUFBQW1ELE9BQUFuRCxFQUFBLFFBQUFvRCxLQUFBO0VBTnhDQyxNQUFBLHdCQUFDLE9BQUQ7R0FDTTFDO0dBQ0M7R0FDSztHQUNJLGNBQUF3QztHQUNGO0dBQ0UsZ0JBQUFDO0dBQ0l4QztFQUFjOzs7OztFQUNoQ1osRUFBQSxNQUFBWTtFQUFBWixFQUFBLE1BQUFXO0VBQUFYLEVBQUEsTUFBQW1EO0VBQUFuRCxFQUFBLE1BQUFvRDtFQUFBcEQsRUFBQSxNQUFBcUQ7Q0FBQTtFQUFBQSxNQUFBckQsRUFBQTtDQUFBO0NBQUEsSUFBQXNEO0NBQUEsSUFBQXRELEVBQUEsUUFBQVksa0JBQUFaLEVBQUEsUUFBQWtCLFlBQUFzQixLQUFBO0VBQ0RjLE1BQUFwQyxZQUFXc0IsTUFDVjtHQUFPNUI7R0FBcUI7R0FBa0I7YUFDM0NNLFlBQVdzQjtFQUNWOzs7O2FBRUo7R0FBVTVCO0dBQTBCO2FBQVU7RUFFdkM7Ozs7O0VBQ1JaLEVBQUEsTUFBQVk7RUFBQVosRUFBQSxNQUFBa0IsWUFBQXNCO0VBQUF4QyxFQUFBLE1BQUFzRDtDQUFBO0VBQUFBLE1BQUF0RCxFQUFBO0NBQUE7Q0FBQSxJQUFBdUQ7Q0FBQSxJQUFBdkQsRUFBQSxRQUFBa0QsT0FBQWxELEVBQUEsUUFBQXFELE9BQUFyRCxFQUFBLFFBQUFzRCxLQUFBO0VBckJIQyxNQUFBO0dBQWU7YUFBZjtJQUNFTDtJQUdBRztJQVNDQztHQVNHOzs7Ozs7RUFBQXRELEVBQUEsTUFBQWtEO0VBQUFsRCxFQUFBLE1BQUFxRDtFQUFBckQsRUFBQSxNQUFBc0Q7RUFBQXRELEVBQUEsTUFBQXVEO0NBQUE7RUFBQUEsTUFBQXZELEVBQUE7Q0FBQTtDQUFBLElBQUF3RDtDQUFBLElBQUF4RCxFQUFBLFFBQUFhLFlBQUE7RUFHSjJDLE1BQUEsd0JBQUMsT0FBRDtHQUFnQjNDO0dBQXNCO2FBQVU7RUFBMUM7Ozs7O0VBRUViLEVBQUEsTUFBQWE7RUFBQWIsRUFBQSxNQUFBd0Q7Q0FBQTtFQUFBQSxNQUFBeEQsRUFBQTtDQUFBO0NBS1EsTUFBQXlELE1BQUFwRCxPQUFNcUIsWUFBTjtDQUVBLE1BQUFnQyxNQUFBckMsUUFBUUgsWUFBV3VCLEdBQUk7Q0FBQyxJQUFBa0I7Q0FBQSxJQUFBM0QsRUFBQSxRQUFBYyxrQkFBQWQsRUFBQSxRQUFBYSxjQUFBYixFQUFBLFFBQUF5RCxPQUFBekQsRUFBQSxRQUFBMEQsS0FBQTtFQU54Q0MsTUFBQSx3QkFBQyxPQUFEO0dBQ005QztHQUNDO0dBQ0s7R0FDSSxjQUFBNEM7R0FDRjtHQUNFLGdCQUFBQztHQUNJNUM7RUFBYzs7Ozs7RUFDaENkLEVBQUEsTUFBQWM7RUFBQWQsRUFBQSxNQUFBYTtFQUFBYixFQUFBLE1BQUF5RDtFQUFBekQsRUFBQSxNQUFBMEQ7RUFBQTFELEVBQUEsTUFBQTJEO0NBQUE7RUFBQUEsTUFBQTNELEVBQUE7Q0FBQTtDQUFBLElBQUE0RDtDQUFBLElBQUE1RCxFQUFBLFFBQUFjLGtCQUFBZCxFQUFBLFFBQUFrQixZQUFBdUIsS0FBQTtFQUNEbUIsTUFBQTFDLFlBQVd1QixNQUNWO0dBQU8zQjtHQUFxQjtHQUFrQjthQUMzQ0ksWUFBV3VCO0VBQ1Y7Ozs7YUFFSjtHQUFVM0I7R0FBMEI7YUFBVTtFQUV2Qzs7Ozs7RUFDUmQsRUFBQSxNQUFBYztFQUFBZCxFQUFBLE1BQUFrQixZQUFBdUI7RUFBQXpDLEVBQUEsTUFBQTREO0NBQUE7RUFBQUEsTUFBQTVELEVBQUE7Q0FBQTtDQUFBLElBQUE2RDtDQUFBLElBQUE3RCxFQUFBLFFBQUF3RCxPQUFBeEQsRUFBQSxRQUFBMkQsT0FBQTNELEVBQUEsUUFBQTRELEtBQUE7RUFyQkhDLE1BQUE7R0FBZTthQUFmO0lBQ0VMO0lBR0FHO0lBU0NDO0dBU0c7Ozs7OztFQUFBNUQsRUFBQSxNQUFBd0Q7RUFBQXhELEVBQUEsTUFBQTJEO0VBQUEzRCxFQUFBLE1BQUE0RDtFQUFBNUQsRUFBQSxNQUFBNkQ7Q0FBQTtFQUFBQSxNQUFBN0QsRUFBQTtDQUFBO0NBQUEsSUFBQThEO0NBQUEsSUFBQTlELEVBQUEsUUFBQXVELE9BQUF2RCxFQUFBLFFBQUE2RCxLQUFBO0VBL0NSQyxNQUFBO0dBQWU7YUFBZixDQUNFUCxLQXdCQU0sR0F1Qkk7Ozs7OztFQUFBN0QsRUFBQSxNQUFBdUQ7RUFBQXZELEVBQUEsTUFBQTZEO0VBQUE3RCxFQUFBLE1BQUE4RDtDQUFBO0VBQUFBLE1BQUE5RCxFQUFBO0NBQUE7Q0FBQSxJQUFBK0Q7Q0FBQSxJQUFBL0QsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBRU4yRCxNQUFBO0dBQWU7YUFDYix3QkFBQyxRQUFEO0lBQWE7SUFBbUI7Y0FBaEMsQ0FDRSx3QkFBQyxtQkFBRDtLQUE2QjtLQUFxQjtJQUFNOzs7O2NBQ3hELDRDQUFNLFVBQWM7Ozs7WUFGZjs7Ozs7O0VBSUg7Ozs7O0VBQUEvRCxFQUFBLE1BQUErRDtDQUFBO0VBQUFBLE1BQUEvRCxFQUFBO0NBQUE7Q0FBQSxJQUFBZ0U7Q0FBQSxJQUFBaEUsRUFBQSxRQUFBMEMsMEJBQUExQyxFQUFBLFFBQUE4RCxPQUFBOUQsRUFBQSxRQUFBMkMsTUFBQTNDLEVBQUEsUUFBQWlELElBQUE7RUF0RlJlLE1BQUE7R0FFWXRCO0dBQ1Y7R0FDVTthQUpaO0lBTUVPO0lBeUJBYTtJQWtEQUM7R0FNSztLQXRGQXBCOzs7O1NBc0ZBO0VBQUEzQyxFQUFBLE1BQUEwQztFQUFBMUMsRUFBQSxNQUFBOEQ7RUFBQTlELEVBQUEsTUFBQTJDO0VBQUEzQyxFQUFBLE1BQUFpRDtFQUFBakQsRUFBQSxNQUFBZ0U7Q0FBQTtFQUFBQSxNQUFBaEUsRUFBQTtDQUFBO0NBV00sTUFBQWlFLE1BQUE1RCxPQUFNa0IsYUFBY2UsWUFBcEI7Q0FDSyxNQUFBNEIsTUFBQTdELE9BQU1rQixhQUFjZTtDQUFTLElBQUE2QjtDQUFBLElBQUFuRSxFQUFBLFFBQUFPLGdCQUFBO0VBQ2xDNEQsWUFBTTVELGVBQWUsRUFBQWdCLFVBQVllLFVBQVUsQ0FBQztFQUFDdEMsRUFBQSxNQUFBTztFQUFBUCxFQUFBLE1BQUFtRTtDQUFBO0VBQUFBLE1BQUFuRSxFQUFBO0NBQUE7Q0FBQSxJQUFBb0U7Q0FBQSxJQUFBcEUsRUFBQSxRQUFBaUUsT0FBQWpFLEVBQUEsUUFBQWtFLE9BQUFsRSxFQUFBLFFBQUFtRSxLQUFBO0VBTHhEQyxNQUFBLHdCQUFDLFFBQUQ7R0FDTztHQUNBO0dBQ0ksU0FBQUg7R0FDSyxnQkFBQUM7R0FDTCxTQUFBQzthQUNWO0VBTk07Ozs7O0VBUUVuRSxFQUFBLE1BQUFpRTtFQUFBakUsRUFBQSxNQUFBa0U7RUFBQWxFLEVBQUEsTUFBQW1FO0VBQUFuRSxFQUFBLE1BQUFvRTtDQUFBO0VBQUFBLE1BQUFwRSxFQUFBO0NBQUE7Q0FBQSxJQUFBcUU7Q0FBQSxJQUFBckUsRUFBQSxRQUFBTyxrQkFBQVAsRUFBQSxRQUFBSyxPQUFBa0IsVUFBQTtFQUNSOEMsTUFBQTNFLGVBQWM0RSxLQUFLQyxRQUFBO0dBQ2xCLE1BQUFDLGFBQW1CbkUsT0FBTWtCLGFBQWNnRDtHQUFHLE9BRXhDLHdCQUFDLFFBQUQ7SUFFTztJQUNBO0lBQ0ksU0FBQUMsYUFBQTtJQUNLQTtJQUNMLGVBQU1qRSxlQUFlLEVBQUFnQixVQUFZaUQsYUFBQWxDLFlBQUFpQyxJQUE2QixDQUFDO2NBRXZFOUUsZ0JBQWdCOEU7R0FSWixHQUNBQTs7OztVQURBO0VBU0UsQ0FFWjtFQUFDdkUsRUFBQSxNQUFBTztFQUFBUCxFQUFBLE1BQUFLLE9BQUFrQjtFQUFBdkIsRUFBQSxNQUFBcUU7Q0FBQTtFQUFBQSxNQUFBckUsRUFBQTtDQUFBO0NBQUEsSUFBQXlFO0NBQUEsSUFBQXpFLEVBQUEsUUFBQW9FLE9BQUFwRSxFQUFBLFFBQUFxRSxLQUFBO0VBNUJKSSxNQUFBO0dBQ1k7R0FDTDtHQUNNO2FBSGIsQ0FLRUwsS0FTQ0MsR0FlRzs7Ozs7O0VBQUFyRSxFQUFBLE1BQUFvRTtFQUFBcEUsRUFBQSxNQUFBcUU7RUFBQXJFLEVBQUEsTUFBQXlFO0NBQUE7RUFBQUEsTUFBQXpFLEVBQUE7Q0FBQTtDQUFBLElBQUEwRTtDQUFBLElBQUExRSxFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFFTnNFLE1BQUEsd0JBQUMsV0FBRCxDQUFVOzs7OztFQUFHMUUsRUFBQSxNQUFBMEU7Q0FBQTtFQUFBQSxNQUFBMUUsRUFBQTtDQUFBO0NBQUEsSUFBQTJFO0NBQUEsSUFBQTNFLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQU1QdUUsTUFBQTtHQUFnQjthQUE0QztFQUFlOzs7OztFQUFBM0UsRUFBQSxNQUFBMkU7Q0FBQTtFQUFBQSxNQUFBM0UsRUFBQTtDQUFBO0NBRWxFLE1BQUE0RSxNQUFBdkUsT0FBTW1CLGNBQU4zQjtDQUEwQyxJQUFBZ0Y7Q0FBQSxJQUFBN0UsRUFBQSxRQUFBTyxnQkFBQTtFQUNsQ3NFLE9BQUFDLFVBQ2J2RSxlQUFlLEVBQUFpQixZQUNELENBQUNzRCxTQUFTQSxVQUFVakYsd0JBQXBCeUMsWUFBQXdDLE1BQ2QsQ0FBQztFQUFDOUUsRUFBQSxNQUFBTztFQUFBUCxFQUFBLE1BQUE2RTtDQUFBO0VBQUFBLE1BQUE3RSxFQUFBO0NBQUE7Q0FLQyxNQUFBK0UsTUFBQTFFLE9BQU1tQixjQUFOO0NBQXdDLElBQUF3RDtDQUFBLElBQUFoRixFQUFBLFFBQUErRSxLQUFBO0VBRjdDQyxNQUFBLHdCQUFDLGVBQUQ7R0FBMEI7R0FBZ0M7YUFDeEQsd0JBQUMsYUFBRDtJQUF5QjtjQUN0QkQ7R0FEUzs7Ozs7RUFEQTs7Ozs7RUFJRS9FLEVBQUEsTUFBQStFO0VBQUEvRSxFQUFBLE1BQUFnRjtDQUFBO0VBQUFBLE1BQUFoRixFQUFBO0NBQUE7Q0FBQSxJQUFBaUY7Q0FBQSxJQUFBakYsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBRWQ2RSxNQUFBLHdCQUFDLFlBQUQ7R0FBbUJwRjthQUF1QjtFQUEvQjs7Ozs7RUFBNkRHLEVBQUEsTUFBQWlGO0NBQUE7RUFBQUEsTUFBQWpGLEVBQUE7Q0FBQTtDQUFBLElBQUFrRjtDQUFBLElBQUFsRixFQUFBLFFBQUFNLGFBQUE7RUFDdkU0RSxNQUFBNUUsWUFBV2dFLElBQUthLEtBSWhCO0VBQUNuRixFQUFBLE1BQUFNO0VBQUFOLEVBQUEsTUFBQWtGO0NBQUE7RUFBQUEsTUFBQWxGLEVBQUE7Q0FBQTtDQUFBLElBQUFvRjtDQUFBLElBQUFwRixFQUFBLFFBQUFrRixLQUFBO0VBTkpFLE1BQUEsd0JBQUMsZUFBRCxhQUNFSCxLQUNDQyxHQUZXOzs7OztFQU9FbEYsRUFBQSxNQUFBa0Y7RUFBQWxGLEVBQUEsTUFBQW9GO0NBQUE7RUFBQUEsTUFBQXBGLEVBQUE7Q0FBQTtDQUFBLElBQUFxRjtDQUFBLElBQUFyRixFQUFBLFFBQUE0RSxPQUFBNUUsRUFBQSxRQUFBNkUsT0FBQTdFLEVBQUEsUUFBQWdGLE9BQUFoRixFQUFBLFFBQUFvRixLQUFBO0VBdEJwQkMsTUFBQTtHQUFlO2FBQWYsQ0FDRVYsS0FDQSx3QkFBQyxRQUFEO0lBQ1MsT0FBQUM7SUFDUSxlQUFBQztjQUZqQixDQVFFRyxLQUtBSSxHQWJLOzs7OztXQXNCSDs7Ozs7O0VBQUFwRixFQUFBLE1BQUE0RTtFQUFBNUUsRUFBQSxNQUFBNkU7RUFBQTdFLEVBQUEsTUFBQWdGO0VBQUFoRixFQUFBLE1BQUFvRjtFQUFBcEYsRUFBQSxNQUFBcUY7Q0FBQTtFQUFBQSxNQUFBckYsRUFBQTtDQUFBO0NBS08sTUFBQXNGLE1BQUFqRSxRQUFRaEIsT0FBTXNCLGFBQWM7Q0FBQyxJQUFBNEQ7Q0FBQSxJQUFBdkYsRUFBQSxRQUFBTyxnQkFBQTtFQUNyQmdGLE9BQUFDLFlBQ2ZqRixlQUFlLEVBQUFvQixlQUFpQjZELFVBQUEsT0FBQWxELFVBQTJCLENBQUM7RUFBQ3RDLEVBQUEsTUFBQU87RUFBQVAsRUFBQSxNQUFBdUY7Q0FBQTtFQUFBQSxNQUFBdkYsRUFBQTtDQUFBO0NBQUEsSUFBQXlGO0NBQUEsSUFBQXpGLEVBQUEsUUFBQWUscUJBQUFmLEVBQUEsUUFBQXNGLE9BQUF0RixFQUFBLFFBQUF1RixLQUFBO0VBSmpFRSxNQUFBLHdCQUFDLFFBQUQ7R0FDTTFFO0dBQ0ssU0FBQXVFO0dBQ1EsaUJBQUFDO0VBQzhDOzs7OztFQUUvRHZGLEVBQUEsTUFBQWU7RUFBQWYsRUFBQSxNQUFBc0Y7RUFBQXRGLEVBQUEsTUFBQXVGO0VBQUF2RixFQUFBLE1BQUF5RjtDQUFBO0VBQUFBLE1BQUF6RixFQUFBO0NBQUE7Q0FBQSxJQUFBMEY7Q0FBQSxJQUFBMUYsRUFBQSxRQUFBZSxtQkFBQTtFQUNGMkUsTUFBQSx3QkFBQyxPQUFEO0dBQWdCM0U7R0FBNkI7YUFBeUI7RUFBaEU7Ozs7O0VBRUVmLEVBQUEsTUFBQWU7RUFBQWYsRUFBQSxNQUFBMEY7Q0FBQTtFQUFBQSxNQUFBMUYsRUFBQTtDQUFBO0NBQUEsSUFBQTJGO0NBQUEsSUFBQTNGLEVBQUEsUUFBQXlGLE9BQUF6RixFQUFBLFFBQUEwRixLQUFBO0VBVlZDLE1BQUE7R0FBZTthQUFmLENBQ0VGLEtBT0FDLEdBR0k7Ozs7OztFQUFBMUYsRUFBQSxNQUFBeUY7RUFBQXpGLEVBQUEsTUFBQTBGO0VBQUExRixFQUFBLE1BQUEyRjtDQUFBO0VBQUFBLE1BQUEzRixFQUFBO0NBQUE7Q0FLTyxNQUFBNEYsTUFBQXZFLFFBQVFoQixPQUFNdUIsYUFBYztDQUFDLElBQUFpRTtDQUFBLElBQUE3RixFQUFBLFFBQUFPLGdCQUFBO0VBQ3JCc0YsT0FBQUMsY0FDZnZGLGVBQWUsRUFBQXFCLGVBQWlCNEQsWUFBQSxPQUFBbEQsVUFBMkIsQ0FBQztFQUFDdEMsRUFBQSxNQUFBTztFQUFBUCxFQUFBLE1BQUE2RjtDQUFBO0VBQUFBLE1BQUE3RixFQUFBO0NBQUE7Q0FBQSxJQUFBK0Y7Q0FBQSxJQUFBL0YsRUFBQSxRQUFBZ0IscUJBQUFoQixFQUFBLFFBQUE0RixPQUFBNUYsRUFBQSxRQUFBNkYsS0FBQTtFQUpqRUUsTUFBQSx3QkFBQyxRQUFEO0dBQ00vRTtHQUNLLFNBQUE0RTtHQUNRLGlCQUFBQztFQUM4Qzs7Ozs7RUFFL0Q3RixFQUFBLE1BQUFnQjtFQUFBaEIsRUFBQSxNQUFBNEY7RUFBQTVGLEVBQUEsTUFBQTZGO0VBQUE3RixFQUFBLE1BQUErRjtDQUFBO0VBQUFBLE1BQUEvRixFQUFBO0NBQUE7Q0FBQSxJQUFBZ0c7Q0FBQSxJQUFBaEcsRUFBQSxRQUFBZ0IsbUJBQUE7RUFDRmdGLE1BQUEsd0JBQUMsT0FBRDtHQUFnQmhGO0dBQTZCO2FBQXlCO0VBQWhFOzs7OztFQUVFaEIsRUFBQSxNQUFBZ0I7RUFBQWhCLEVBQUEsT0FBQWdHO0NBQUE7RUFBQUEsTUFBQWhHLEVBQUE7Q0FBQTtDQUFBLElBQUFpRztDQUFBLElBQUFqRyxFQUFBLFNBQUErRixPQUFBL0YsRUFBQSxTQUFBZ0csS0FBQTtFQVZWQyxNQUFBO0dBQWU7YUFBZixDQUNFRixLQU9BQyxHQUdJOzs7Ozs7RUFBQWhHLEVBQUEsT0FBQStGO0VBQUEvRixFQUFBLE9BQUFnRztFQUFBaEcsRUFBQSxPQUFBaUc7Q0FBQTtFQUFBQSxNQUFBakcsRUFBQTtDQUFBO0NBQUEsSUFBQWtHO0NBQUEsSUFBQWxHLEVBQUEsU0FBQXFGLE9BQUFyRixFQUFBLFNBQUEyRixPQUFBM0YsRUFBQSxTQUFBaUcsS0FBQTtFQW5EUkMsTUFBQTtHQUFlO2FBQWY7SUFDRWI7SUEwQkFNO0lBYUFNO0dBWUk7Ozs7OztFQUFBakcsRUFBQSxPQUFBcUY7RUFBQXJGLEVBQUEsT0FBQTJGO0VBQUEzRixFQUFBLE9BQUFpRztFQUFBakcsRUFBQSxPQUFBa0c7Q0FBQTtFQUFBQSxNQUFBbEcsRUFBQTtDQUFBO0NBQUEsSUFBQW1HO0NBQUEsSUFBQW5HLEVBQUEsU0FBQUcsT0FBQUMsSUFBQTtFQUlGK0YsTUFBQTtHQUFnQjthQUE0QztFQUFlOzs7OztFQUFBbkcsRUFBQSxPQUFBbUc7Q0FBQTtFQUFBQSxNQUFBbkcsRUFBQTtDQUFBO0NBQUEsSUFBQW9HO0NBQUEsSUFBQXBHLEVBQUEsU0FBQU8sZ0JBQUE7RUFHMUQ2RixPQUFBQyxZQUFBO0dBQ2IsSUFBSXZCLFNBQUs7SUFBRXZFLGVBQWUsRUFBQXNCLE1BQVFpRCxRQUFtQixDQUFDO0dBQUM7RUFBQTtFQUN4RDlFLEVBQUEsT0FBQU87RUFBQVAsRUFBQSxPQUFBb0c7Q0FBQTtFQUFBQSxNQUFBcEcsRUFBQTtDQUFBO0NBR2UsTUFBQXNHLE1BQUExRyxZQUFZUyxPQUFNd0I7Q0FBTSxJQUFBMEU7Q0FBQSxJQUFBdkcsRUFBQSxTQUFBc0csS0FBQTtFQUR4Q0MsTUFBQSx3QkFBQyxlQUFEO0dBQTBCO0dBQTZCO2FBQ3JELHdCQUFDLGFBQUQsWUFBY0QsSUFBRjs7Ozs7RUFEQTs7Ozs7RUFFRXRHLEVBQUEsT0FBQXNHO0VBQUF0RyxFQUFBLE9BQUF1RztDQUFBO0VBQUFBLE1BQUF2RyxFQUFBO0NBQUE7Q0FBQSxJQUFBd0c7Q0FBQSxJQUFBeEcsRUFBQSxTQUFBRyxPQUFBQyxJQUFBO0VBQ2hCb0csTUFBQSx3QkFBQyxlQUFELFlBQ0c3RyxpQkFBZ0IyRSxJQUFLbUMsTUFJckIsRUFMVzs7Ozs7RUFNRXpHLEVBQUEsT0FBQXdHO0NBQUE7RUFBQUEsTUFBQXhHLEVBQUE7Q0FBQTtDQUFBLElBQUEwRztDQUFBLElBQUExRyxFQUFBLFNBQUFLLE9BQUF3QixRQUFBN0IsRUFBQSxTQUFBb0csT0FBQXBHLEVBQUEsU0FBQXVHLEtBQUE7RUFqQnBCRyxNQUFBO0dBQWU7YUFBZixDQUNFUCxLQUNBLHdCQUFDLFFBQUQ7SUFDUyxPQUFBOUYsT0FBTXdCO0lBQ0UsZUFBQXVFO2NBRmpCLENBTUVHLEtBR0FDLEdBVEs7Ozs7O1dBaUJIOzs7Ozs7RUFBQXhHLEVBQUEsT0FBQUssT0FBQXdCO0VBQUE3QixFQUFBLE9BQUFvRztFQUFBcEcsRUFBQSxPQUFBdUc7RUFBQXZHLEVBQUEsT0FBQTBHO0NBQUE7RUFBQUEsTUFBQTFHLEVBQUE7Q0FBQTtDQUFBLElBQUEyRztDQUFBLElBQUEzRyxFQUFBLFNBQUFvQixvQkFBQXBCLEVBQUEsU0FBQVEsZ0JBQUE7RUFFTG1HLE1BQUF2RixvQkFDQyx3QkFBQyxRQUFEO0dBQ087R0FDRztHQUNIO0dBQ0k7SUFDUEQsZUFBZSxDQUFDLENBQUM7SUFDakJYLGVBQWU7R0FBQztHQUVQO2FBUmIsQ0FVRSx3QkFBQyxXQUFEO0lBQXFCO0lBQXVCO0dBQU07Ozs7YUFDbEQsNENBQU0sU0FBYTs7OztXQVhkOzs7Ozs7RUFhUlIsRUFBQSxPQUFBb0I7RUFBQXBCLEVBQUEsT0FBQVE7RUFBQVIsRUFBQSxPQUFBMkc7Q0FBQTtFQUFBQSxNQUFBM0csRUFBQTtDQUFBO0NBQUEsSUFBQTRHO0NBQUEsSUFBQTVHLEVBQUEsU0FBQTBHLE9BQUExRyxFQUFBLFNBQUEyRyxLQUFBO0VBcENIQyxNQUFBO0dBQWU7YUFBZixDQUNFRixLQXFCQ0MsR0FlRzs7Ozs7O0VBQUEzRyxFQUFBLE9BQUEwRztFQUFBMUcsRUFBQSxPQUFBMkc7RUFBQTNHLEVBQUEsT0FBQTRHO0NBQUE7RUFBQUEsTUFBQTVHLEVBQUE7Q0FBQTtDQUFBLElBQUE2RztDQUFBLElBQUE3RyxFQUFBLFNBQUFrRyxPQUFBbEcsRUFBQSxTQUFBNEcsS0FBQTtFQTVGUkMsTUFBQTtHQUFlO2FBQWYsQ0FDRVgsS0FzREFVLEdBc0NJOzs7Ozs7RUFBQTVHLEVBQUEsT0FBQWtHO0VBQUFsRyxFQUFBLE9BQUE0RztFQUFBNUcsRUFBQSxPQUFBNkc7Q0FBQTtFQUFBQSxNQUFBN0csRUFBQTtDQUFBO0NBQUEsSUFBQThHO0NBQUEsSUFBQTlHLEVBQUEsU0FBQW9CLG9CQUFBcEIsRUFBQSxTQUFBTyxrQkFBQVAsRUFBQSxTQUFBSyxPQUFBa0IsWUFBQXZCLEVBQUEsU0FBQUssT0FBQW1CLGNBQUF4QixFQUFBLFNBQUFLLE9BQUFxQixZQUFBMUIsRUFBQSxTQUFBSyxPQUFBb0IsWUFBQXpCLEVBQUEsU0FBQUssT0FBQWlCLEdBQUE7RUFHTHdGLE1BQUExRixvQkFDQztHQUFlO0dBQW9EO2FBQW5FO0lBQ0U7S0FBZ0I7ZUFBZ0M7SUFBYzs7Ozs7SUFDN0RmLE9BQU1pQixLQUNMLHdCQUFDLE9BQUQ7S0FBZTtLQUFzQjtlQUFyQyxDQUNFO01BQWdCO2dCQUFoQjtPQUFvQztPQUFlakIsT0FBTWlCO09BQUc7TUFBYzs7Ozs7ZUFDMUU7TUFDTztNQUNNO01BQ0YsZUFBTWYsZUFBZSxFQUFBZSxHQUFLZ0IsVUFBVSxDQUFDO01BQ3BDO2dCQUVWLHdCQUFDLEdBQUQ7T0FBYTtPQUFxQjtNQUFNOzs7OztLQUNqQzs7OzthQVRMOzs7Ozs7SUFZUGpDLE9BQU1rQixZQUNMLHdCQUFDLE9BQUQ7S0FBZTtLQUFzQjtlQUFyQyxDQUNFLDRDQUFPOUIsZ0JBQWdCWSxPQUFNa0IsVUFBa0I7Ozs7ZUFDL0M7TUFDTztNQUNNO01BQ0YsZUFBTWhCLGVBQWUsRUFBQWdCLFVBQVllLFVBQVUsQ0FBQztNQUMzQztnQkFFVix3QkFBQyxHQUFEO09BQWE7T0FBcUI7TUFBTTs7Ozs7S0FDakM7Ozs7YUFUTDs7Ozs7O0lBWVBqQyxPQUFNbUIsY0FDTCx3QkFBQyxPQUFEO0tBQWU7S0FBc0I7ZUFBckMsQ0FDRTtNQUFnQjtnQkFBcUJuQixPQUFNbUI7S0FBbUI7Ozs7ZUFDOUQ7TUFDTztNQUNNO01BQ0YsZUFBTWpCLGVBQWUsRUFBQWlCLFlBQWNjLFVBQVUsQ0FBQztNQUM3QztnQkFFVix3QkFBQyxHQUFEO09BQWE7T0FBcUI7TUFBTTs7Ozs7S0FDakM7Ozs7YUFUTDs7Ozs7O0tBWU5qQyxPQUFNb0IsWUFBYXBCLE9BQU1xQixhQUN6Qix3QkFBQyxPQUFEO0tBQWU7S0FBc0I7ZUFBckMsQ0FDRTtNQUNHckIsT0FBTW9CLFlBQU47TUFBdUI7TUFBSXBCLE9BQU1xQixZQUFOO01BQXVCO0tBQzlDOzs7O2VBQ1A7TUFDTztNQUNNO01BQ0YsZUFBTW5CLGVBQWU7T0FBQWtCLFVBQVlhO09BQVNaLFVBQVlZO01BQVUsQ0FBQztNQUNoRTtnQkFFVix3QkFBQyxHQUFEO09BQWE7T0FBcUI7TUFBTTs7Ozs7S0FDakM7Ozs7YUFYTDs7Ozs7O0dBY0o7Ozs7OztFQUNQdEMsRUFBQSxPQUFBb0I7RUFBQXBCLEVBQUEsT0FBQU87RUFBQVAsRUFBQSxPQUFBSyxPQUFBa0I7RUFBQXZCLEVBQUEsT0FBQUssT0FBQW1CO0VBQUF4QixFQUFBLE9BQUFLLE9BQUFxQjtFQUFBMUIsRUFBQSxPQUFBSyxPQUFBb0I7RUFBQXpCLEVBQUEsT0FBQUssT0FBQWlCO0VBQUF0QixFQUFBLE9BQUE4RztDQUFBO0VBQUFBLE1BQUE5RyxFQUFBO0NBQUE7Q0FBQSxJQUFBK0c7Q0FBQSxJQUFBL0csRUFBQSxTQUFBZ0UsT0FBQWhFLEVBQUEsU0FBQXlFLE9BQUF6RSxFQUFBLFNBQUE2RyxPQUFBN0csRUFBQSxTQUFBOEcsS0FBQTtFQXpSUEMsTUFBQTtHQUFrQjthQUNoQix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsYUFBRDtJQUF1QjtjQUF2QjtLQUNFL0M7S0EwRkFTO0tBK0JBQztLQUdBbUM7S0FnR0NDO0lBN05TOzs7OztZQURUOzs7OztFQTJSQzs7Ozs7RUFBQTlHLEVBQUEsT0FBQWdFO0VBQUFoRSxFQUFBLE9BQUF5RTtFQUFBekUsRUFBQSxPQUFBNkc7RUFBQTdHLEVBQUEsT0FBQThHO0VBQUE5RyxFQUFBLE9BQUErRztDQUFBO0VBQUFBLE1BQUEvRyxFQUFBO0NBQUE7Q0FBQSxPQTVSUitHO0FBNFJROzs7QUE5VUwsU0FBQU4sT0FBQU8sS0FBQTtDQUFBLE9Bc1BlLHdCQUFDLFlBQUQ7RUFBNkJBO1lBQzFCcEgsWUFBWW9IO0NBREosR0FBTUE7Ozs7UUFBTjtBQUVFO0FBeFA1QixTQUFBN0IsTUFBQThCLEtBQUE7Q0FBQSxPQXFNZSx3QkFBQyxZQUFEO0VBQTZCQTtZQUMxQkE7Q0FEUSxHQUFNQTs7OztRQUFOO0FBRUUiLCJuYW1lcyI6WyJ1c2VJZCIsInVzZVN0YXRlIiwiUm90YXRlQ2N3IiwiU2VhcmNoIiwiU2xpZGVyc0hvcml6b250YWwiLCJYIiwiQmFkZ2UiLCJCdXR0b24iLCJDYXJkIiwiQ2FyZENvbnRlbnQiLCJJbnB1dCIsIkxhYmVsIiwiU2VsZWN0IiwiU2VsZWN0Q29udGVudCIsIlNlbGVjdEl0ZW0iLCJTZWxlY3RUcmlnZ2VyIiwiU2VsZWN0VmFsdWUiLCJTZXBhcmF0b3IiLCJTd2l0Y2giLCJpc1ZhbGlkRXRoU3RyaW5nIiwiQ0FURUdPUllfTEFCRUxTIiwiTkZUX0NBVEVHT1JJRVMiLCJORlRfU09SVF9PUFRJT05TIiwiU09SVF9MQUJFTFMiLCJBTExfQ09MTEVDVElPTlNfVkFMVUUiLCJOZnRGaWx0ZXJzIiwidDAiLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsInNlYXJjaCIsImNvbGxlY3Rpb25zIiwib25GaWx0ZXJDaGFuZ2UiLCJvblJlc2V0RmlsdGVycyIsInNlYXJjaElucHV0SWQiLCJzZWFyY2hIaW50SWQiLCJtaW5QcmljZUlkIiwibWluUHJpY2VEZXNjSWQiLCJtYXhQcmljZUlkIiwibWF4UHJpY2VEZXNjSWQiLCJhdmFpbGFibGVTd2l0Y2hJZCIsImZhdm9yaXRlc1N3aXRjaElkIiwidDEiLCJwcmljZUVycm9ycyIsInNldFByaWNlRXJyb3JzIiwiaGFzQWN0aXZlRmlsdGVycyIsIkJvb2xlYW4iLCJxIiwiY2F0ZWdvcnkiLCJjb2xsZWN0aW9uIiwibWluUHJpY2UiLCJtYXhQcmljZSIsIm9ubHlBdmFpbGFibGUiLCJvbmx5RmF2b3JpdGVzIiwic29ydCIsInQyIiwiZSIsInByZXZlbnREZWZhdWx0IiwiZm9ybURhdGEiLCJGb3JtRGF0YSIsImN1cnJlbnRUYXJnZXQiLCJnZXQiLCJ0cmltIiwidW5kZWZpbmVkIiwibmV4dEVycm9ycyIsIm1pbiIsIm1heCIsImhhbmRsZVNlYXJjaEZvcm1TdWJtaXQiLCJ0MyIsInQ0IiwidDUiLCJ0NiIsInQ3IiwidDgiLCJ0OSIsInQxMCIsInQxMSIsInQxMiIsInQxMyIsInQxNCIsInQxNSIsInQxNiIsInQxNyIsInQxOCIsInQxOSIsInQyMCIsInQyMSIsInQyMiIsInQyMyIsInQyNCIsInQyNSIsInQyNiIsInQyNyIsInQyOCIsInQyOSIsIm1hcCIsImNhdCIsImlzU2VsZWN0ZWQiLCJ0MzAiLCJ0MzEiLCJ0MzIiLCJ0MzMiLCJ0MzQiLCJ2YWx1ZSIsInQzNSIsInQzNiIsInQzNyIsInQzOCIsIl90ZW1wIiwidDM5IiwidDQwIiwidDQxIiwidDQyIiwiY2hlY2tlZCIsInQ0MyIsInQ0NCIsInQ0NSIsInQ0NiIsInQ0NyIsImNoZWNrZWRfMCIsInQ0OCIsInQ0OSIsInQ1MCIsInQ1MSIsInQ1MiIsInQ1MyIsInZhbHVlXzAiLCJ0NTQiLCJ0NTUiLCJ0NTYiLCJfdGVtcDIiLCJ0NTciLCJ0NTgiLCJ0NTkiLCJ0NjAiLCJ0NjEiLCJ0NjIiLCJvcHQiLCJjb2wiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibmZ0LWZpbHRlcnMudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUlkLCB1c2VTdGF0ZSwgdHlwZSBGb3JtRXZlbnQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IFJvdGF0ZUNjdywgU2VhcmNoLCBTbGlkZXJzSG9yaXpvbnRhbCwgWCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IEJhZGdlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2JhZGdlJ1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcbmltcG9ydCB7IENhcmQsIENhcmRDb250ZW50IH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnXG5pbXBvcnQgeyBJbnB1dCB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9pbnB1dCdcbmltcG9ydCB7IExhYmVsIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2xhYmVsJ1xuaW1wb3J0IHtcbiAgU2VsZWN0LFxuICBTZWxlY3RDb250ZW50LFxuICBTZWxlY3RJdGVtLFxuICBTZWxlY3RUcmlnZ2VyLFxuICBTZWxlY3RWYWx1ZSxcbn0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3NlbGVjdCdcbmltcG9ydCB7IFNlcGFyYXRvciB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9zZXBhcmF0b3InXG5pbXBvcnQgeyBTd2l0Y2ggfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvc3dpdGNoJ1xuaW1wb3J0IHsgaXNWYWxpZEV0aFN0cmluZyB9IGZyb20gJ0AvbGliL2V0aCdcbmltcG9ydCB7XG4gIENBVEVHT1JZX0xBQkVMUyxcbiAgTkZUX0NBVEVHT1JJRVMsXG4gIE5GVF9TT1JUX09QVElPTlMsXG4gIFNPUlRfTEFCRUxTLFxuICB0eXBlIE5mdENhdGFsb2dTZWFyY2gsXG59IGZyb20gJ0Avc2NoZW1hcy9uZnQtc2VhcmNoJ1xuaW1wb3J0IHR5cGUgeyBOZnRDYXRlZ29yeSwgTmZ0U29ydEJ5IH0gZnJvbSAnQC90eXBlcy9tb2RlbHMnXG5cbmNvbnN0IEFMTF9DT0xMRUNUSU9OU19WQUxVRSA9ICdfX2FsbF9fJ1xuXG5pbnRlcmZhY2UgTmZ0RmlsdGVyc1Byb3BzIHtcbiAgc2VhcmNoOiBOZnRDYXRhbG9nU2VhcmNoXG4gIGNvbGxlY3Rpb25zOiBzdHJpbmdbXVxuICBvbkZpbHRlckNoYW5nZTogKHVwZGF0ZXM6IFBhcnRpYWw8T21pdDxOZnRDYXRhbG9nU2VhcmNoLCAncGFnZSc+PikgPT4gdm9pZFxuICBvblJlc2V0RmlsdGVyczogKCkgPT4gdm9pZFxufVxuXG4vKipcbiAqIFBhaW5lbCBzZW3Dom50aWNvIChgPGFzaWRlPmApIGRlIGJ1c2NhLCBmaWx0cm9zIGNvbWJpbsOhdmVpcyBlIG9yZGVuYcOnw6NvLlxuICogTyBlc3RhZG8gZGUgZmlsdHJvcyByZXNpZGUgMTAwJSBuYSBVUkwgKGBzZWFyY2hgKS4gQXBlbmFzIGVycm9zIGRlIGZvcm1hdG8gZGUgaW5wdXQgbG9jYWwgdXNhbSBlc3RhZG8gZGUgdmFsaWRhw6fDo28gQTExeS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIE5mdEZpbHRlcnMoe1xuICBzZWFyY2gsXG4gIGNvbGxlY3Rpb25zLFxuICBvbkZpbHRlckNoYW5nZSxcbiAgb25SZXNldEZpbHRlcnMsXG59OiBOZnRGaWx0ZXJzUHJvcHMpIHtcbiAgY29uc3Qgc2VhcmNoSW5wdXRJZCA9IHVzZUlkKClcbiAgY29uc3Qgc2VhcmNoSGludElkID0gYCR7c2VhcmNoSW5wdXRJZH0taGludGBcbiAgY29uc3QgbWluUHJpY2VJZCA9IHVzZUlkKClcbiAgY29uc3QgbWluUHJpY2VEZXNjSWQgPSBgJHttaW5QcmljZUlkfS1kZXNjYFxuICBjb25zdCBtYXhQcmljZUlkID0gdXNlSWQoKVxuICBjb25zdCBtYXhQcmljZURlc2NJZCA9IGAke21heFByaWNlSWR9LWRlc2NgXG4gIGNvbnN0IGF2YWlsYWJsZVN3aXRjaElkID0gdXNlSWQoKVxuICBjb25zdCBmYXZvcml0ZXNTd2l0Y2hJZCA9IHVzZUlkKClcblxuICBjb25zdCBbcHJpY2VFcnJvcnMsIHNldFByaWNlRXJyb3JzXSA9IHVzZVN0YXRlPHsgbWluPzogc3RyaW5nOyBtYXg/OiBzdHJpbmcgfT4oe30pXG5cbiAgY29uc3QgaGFzQWN0aXZlRmlsdGVycyA9IEJvb2xlYW4oXG4gICAgc2VhcmNoLnEgfHxcbiAgICAgIHNlYXJjaC5jYXRlZ29yeSB8fFxuICAgICAgc2VhcmNoLmNvbGxlY3Rpb24gfHxcbiAgICAgIHNlYXJjaC5taW5QcmljZSB8fFxuICAgICAgc2VhcmNoLm1heFByaWNlIHx8XG4gICAgICBzZWFyY2gub25seUF2YWlsYWJsZSB8fFxuICAgICAgc2VhcmNoLm9ubHlGYXZvcml0ZXMgfHxcbiAgICAgIHNlYXJjaC5zb3J0ICE9PSAncmVjZW50JyxcbiAgKVxuXG4gIGNvbnN0IGhhbmRsZVNlYXJjaEZvcm1TdWJtaXQgPSAoZTogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pID0+IHtcbiAgICBlLnByZXZlbnREZWZhdWx0KClcbiAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YShlLmN1cnJlbnRUYXJnZXQpXG4gICAgY29uc3QgcSA9IChmb3JtRGF0YS5nZXQoJ3EnKSBhcyBzdHJpbmcgfCBudWxsKT8udHJpbSgpIHx8IHVuZGVmaW5lZFxuICAgIGNvbnN0IG1pblByaWNlID0gKGZvcm1EYXRhLmdldCgnbWluUHJpY2UnKSBhcyBzdHJpbmcgfCBudWxsKT8udHJpbSgpIHx8IHVuZGVmaW5lZFxuICAgIGNvbnN0IG1heFByaWNlID0gKGZvcm1EYXRhLmdldCgnbWF4UHJpY2UnKSBhcyBzdHJpbmcgfCBudWxsKT8udHJpbSgpIHx8IHVuZGVmaW5lZFxuXG4gICAgY29uc3QgbmV4dEVycm9yczogeyBtaW4/OiBzdHJpbmc7IG1heD86IHN0cmluZyB9ID0ge31cbiAgICBpZiAobWluUHJpY2UgJiYgIWlzVmFsaWRFdGhTdHJpbmcobWluUHJpY2UpKSB7XG4gICAgICBuZXh0RXJyb3JzLm1pbiA9ICdJbmZvcm1lIHVtIHZhbG9yIGRlY2ltYWwgZW0gRVRIIHbDoWxpZG8gKGV4OiAwLjUpLidcbiAgICB9XG4gICAgaWYgKG1heFByaWNlICYmICFpc1ZhbGlkRXRoU3RyaW5nKG1heFByaWNlKSkge1xuICAgICAgbmV4dEVycm9ycy5tYXggPSAnSW5mb3JtZSB1bSB2YWxvciBkZWNpbWFsIGVtIEVUSCB2w6FsaWRvIChleDogMy4wKS4nXG4gICAgfVxuXG4gICAgc2V0UHJpY2VFcnJvcnMobmV4dEVycm9ycylcbiAgICBpZiAobmV4dEVycm9ycy5taW4gfHwgbmV4dEVycm9ycy5tYXgpIHJldHVyblxuXG4gICAgb25GaWx0ZXJDaGFuZ2UoeyBxLCBtaW5QcmljZSwgbWF4UHJpY2UgfSlcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGFzaWRlIGFyaWEtbGFiZWw9XCJGaWx0cm9zIGUgb3JkZW5hw6fDo28gZG8gY2F0w6Fsb2dvXCI+XG4gICAgICA8Q2FyZD5cbiAgICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTRcIj5cbiAgICAgICAgICA8Zm9ybVxuICAgICAgICAgICAga2V5PXtgJHtzZWFyY2gucSA/PyAnJ318JHtzZWFyY2gubWluUHJpY2UgPz8gJyd9fCR7c2VhcmNoLm1heFByaWNlID8/ICcnfWB9XG4gICAgICAgICAgICBvblN1Ym1pdD17aGFuZGxlU2VhcmNoRm9ybVN1Ym1pdH1cbiAgICAgICAgICAgIG5vVmFsaWRhdGVcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImdyaWQgaXRlbXMtc3RhcnQgZ2FwLTMgbWQ6Z3JpZC1jb2xzLTEyXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ2FwLTEuNSBtZDpjb2wtc3Bhbi01XCI+XG4gICAgICAgICAgICAgIDxMYWJlbCBodG1sRm9yPXtzZWFyY2hJbnB1dElkfSBjbGFzc05hbWU9XCJ0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgQnVzY2FyIG5vIGNhdMOhbG9nb1xuICAgICAgICAgICAgICA8L0xhYmVsPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgPFNlYXJjaFxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSB0b3AtMS8yIGxlZnQtMi41IHNpemUtNCAtdHJhbnNsYXRlLXktMS8yIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiXG4gICAgICAgICAgICAgICAgICBhcmlhLWhpZGRlbj1cInRydWVcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPElucHV0XG4gICAgICAgICAgICAgICAgICBpZD17c2VhcmNoSW5wdXRJZH1cbiAgICAgICAgICAgICAgICAgIG5hbWU9XCJxXCJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJzZWFyY2hcIlxuICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXtzZWFyY2gucSA/PyAnJ31cbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm9tZSwgY29sZcOnw6NvIG91IGNyaWFkb3IuLi5cIlxuICAgICAgICAgICAgICAgICAgYXJpYS1pbnZhbGlkPXtmYWxzZX1cbiAgICAgICAgICAgICAgICAgIGFyaWEtZGVzY3JpYmVkYnk9e3NlYXJjaEhpbnRJZH1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBsLThcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8c3BhbiBpZD17c2VhcmNoSGludElkfSBjbGFzc05hbWU9XCJzci1vbmx5XCI+XG4gICAgICAgICAgICAgICAgRmlsdHJhIE5GVHMgcG9yIHTDrXR1bG8sIGRlc2NyacOnw6NvLCBjb2xlw6fDo28gb3Ugbm9tZSBkbyBhcnRpc3RhLlxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0yIGdhcC0yIG1kOmNvbC1zcGFuLTVcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj17bWluUHJpY2VJZH0gY2xhc3NOYW1lPVwidGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgUHJlw6dvIG3DrW4uIChFVEgpXG4gICAgICAgICAgICAgICAgPC9MYWJlbD5cbiAgICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICAgIGlkPXttaW5QcmljZUlkfVxuICAgICAgICAgICAgICAgICAgbmFtZT1cIm1pblByaWNlXCJcbiAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cImRlY2ltYWxcIlxuICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXtzZWFyY2gubWluUHJpY2UgPz8gJyd9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiAwLjVcIlxuICAgICAgICAgICAgICAgICAgYXJpYS1pbnZhbGlkPXtCb29sZWFuKHByaWNlRXJyb3JzLm1pbil9XG4gICAgICAgICAgICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PXttaW5QcmljZURlc2NJZH1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIHtwcmljZUVycm9ycy5taW4gPyAoXG4gICAgICAgICAgICAgICAgICA8cCBpZD17bWluUHJpY2VEZXNjSWR9IHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1kZXN0cnVjdGl2ZVwiPlxuICAgICAgICAgICAgICAgICAgICB7cHJpY2VFcnJvcnMubWlufVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBpZD17bWluUHJpY2VEZXNjSWR9IGNsYXNzTmFtZT1cInNyLW9ubHlcIj5cbiAgICAgICAgICAgICAgICAgICAgVmFsb3IgbcOtbmltbyBlbSBFVEggdXNhbmRvIHBvbnRvIGRlY2ltYWwuXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0xLjVcIj5cbiAgICAgICAgICAgICAgICA8TGFiZWwgaHRtbEZvcj17bWF4UHJpY2VJZH0gY2xhc3NOYW1lPVwidGV4dC14c1wiPlxuICAgICAgICAgICAgICAgICAgUHJlw6dvIG3DoXguIChFVEgpXG4gICAgICAgICAgICAgICAgPC9MYWJlbD5cbiAgICAgICAgICAgICAgICA8SW5wdXRcbiAgICAgICAgICAgICAgICAgIGlkPXttYXhQcmljZUlkfVxuICAgICAgICAgICAgICAgICAgbmFtZT1cIm1heFByaWNlXCJcbiAgICAgICAgICAgICAgICAgIGlucHV0TW9kZT1cImRlY2ltYWxcIlxuICAgICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXtzZWFyY2gubWF4UHJpY2UgPz8gJyd9XG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkV4OiAzLjBcIlxuICAgICAgICAgICAgICAgICAgYXJpYS1pbnZhbGlkPXtCb29sZWFuKHByaWNlRXJyb3JzLm1heCl9XG4gICAgICAgICAgICAgICAgICBhcmlhLWRlc2NyaWJlZGJ5PXttYXhQcmljZURlc2NJZH1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgIHtwcmljZUVycm9ycy5tYXggPyAoXG4gICAgICAgICAgICAgICAgICA8cCBpZD17bWF4UHJpY2VEZXNjSWR9IHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cInRleHQteHMgdGV4dC1kZXN0cnVjdGl2ZVwiPlxuICAgICAgICAgICAgICAgICAgICB7cHJpY2VFcnJvcnMubWF4fVxuICAgICAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgICAgICA8c3BhbiBpZD17bWF4UHJpY2VEZXNjSWR9IGNsYXNzTmFtZT1cInNyLW9ubHlcIj5cbiAgICAgICAgICAgICAgICAgICAgVmFsb3IgbcOheGltbyBlbSBFVEggdXNhbmRvIHBvbnRvIGRlY2ltYWwuXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGdhcC0yIG1kOmNvbC1zcGFuLTIgbWQ6cHQtNVwiPlxuICAgICAgICAgICAgICA8QnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBjbGFzc05hbWU9XCJ3LWZ1bGxcIj5cbiAgICAgICAgICAgICAgICA8U2xpZGVyc0hvcml6b250YWwgY2xhc3NOYW1lPVwic2l6ZS00XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICA8c3Bhbj5BcGxpY2FyPC9zcGFuPlxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZm9ybT5cblxuICAgICAgICAgIHsvKiBGaWx0cm8gcsOhcGlkbyBkZSBDYXRlZ29yaWFzICovfVxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMS41XCJcbiAgICAgICAgICAgIHJvbGU9XCJncm91cFwiXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiRmlsdHJhciBwb3IgY2F0ZWdvcmlhXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICBzaXplPVwieHNcIlxuICAgICAgICAgICAgICB2YXJpYW50PXtzZWFyY2guY2F0ZWdvcnkgPT09IHVuZGVmaW5lZCA/ICdkZWZhdWx0JyA6ICdvdXRsaW5lJ31cbiAgICAgICAgICAgICAgYXJpYS1wcmVzc2VkPXtzZWFyY2guY2F0ZWdvcnkgPT09IHVuZGVmaW5lZH1cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25GaWx0ZXJDaGFuZ2UoeyBjYXRlZ29yeTogdW5kZWZpbmVkIH0pfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBUb2Rhc1xuICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICB7TkZUX0NBVEVHT1JJRVMubWFwKChjYXQ6IE5mdENhdGVnb3J5KSA9PiB7XG4gICAgICAgICAgICAgIGNvbnN0IGlzU2VsZWN0ZWQgPSBzZWFyY2guY2F0ZWdvcnkgPT09IGNhdFxuICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICAgIGtleT17Y2F0fVxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICBzaXplPVwieHNcIlxuICAgICAgICAgICAgICAgICAgdmFyaWFudD17aXNTZWxlY3RlZCA/ICdkZWZhdWx0JyA6ICdvdXRsaW5lJ31cbiAgICAgICAgICAgICAgICAgIGFyaWEtcHJlc3NlZD17aXNTZWxlY3RlZH1cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uRmlsdGVyQ2hhbmdlKHsgY2F0ZWdvcnk6IGlzU2VsZWN0ZWQgPyB1bmRlZmluZWQgOiBjYXQgfSl9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAge0NBVEVHT1JZX0xBQkVMU1tjYXRdfVxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICApXG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIDxTZXBhcmF0b3IgLz5cblxuICAgICAgICAgIHsvKiBMaW5oYSBkZSBDb2xlw6fDo28sIFN3aXRjaGVzIGUgT3JkZW5hw6fDo28gKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBsZzpmbGV4LXJvdyBsZzppdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC00XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPkNvbGXDp8Ojbzo8L3NwYW4+XG4gICAgICAgICAgICAgICAgPFNlbGVjdFxuICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlYXJjaC5jb2xsZWN0aW9uID8/IEFMTF9DT0xMRUNUSU9OU19WQUxVRX1cbiAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWx1ZSkgPT5cbiAgICAgICAgICAgICAgICAgICAgb25GaWx0ZXJDaGFuZ2Uoe1xuICAgICAgICAgICAgICAgICAgICAgIGNvbGxlY3Rpb246ICF2YWx1ZSB8fCB2YWx1ZSA9PT0gQUxMX0NPTExFQ1RJT05TX1ZBTFVFID8gdW5kZWZpbmVkIDogdmFsdWUsXG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdFRyaWdnZXIgYXJpYS1sYWJlbD1cIkZpbHRyYXIgcG9yIGNvbGXDp8Ojb1wiIGNsYXNzTmFtZT1cIm1pbi13LTQ0XCI+XG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZSBwbGFjZWhvbGRlcj1cIlRvZGFzIGFzIGNvbGXDp8O1ZXNcIj5cbiAgICAgICAgICAgICAgICAgICAgICB7c2VhcmNoLmNvbGxlY3Rpb24gPz8gJ1RvZGFzIGFzIGNvbGXDp8O1ZXMnfVxuICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdFZhbHVlPlxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RUcmlnZ2VyPlxuICAgICAgICAgICAgICAgICAgPFNlbGVjdENvbnRlbnQ+XG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIHZhbHVlPXtBTExfQ09MTEVDVElPTlNfVkFMVUV9PlRvZGFzIGFzIGNvbGXDp8O1ZXM8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICAgIHtjb2xsZWN0aW9ucy5tYXAoKGNvbCkgPT4gKFxuICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RJdGVtIGtleT17Y29sfSB2YWx1ZT17Y29sfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIHtjb2x9XG4gICAgICAgICAgICAgICAgICAgICAgPC9TZWxlY3RJdGVtPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvU2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICA8L1NlbGVjdD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxTd2l0Y2hcbiAgICAgICAgICAgICAgICAgIGlkPXthdmFpbGFibGVTd2l0Y2hJZH1cbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e0Jvb2xlYW4oc2VhcmNoLm9ubHlBdmFpbGFibGUpfVxuICAgICAgICAgICAgICAgICAgb25DaGVja2VkQ2hhbmdlPXsoY2hlY2tlZCkgPT5cbiAgICAgICAgICAgICAgICAgICAgb25GaWx0ZXJDaGFuZ2UoeyBvbmx5QXZhaWxhYmxlOiBjaGVja2VkID8gdHJ1ZSA6IHVuZGVmaW5lZCB9KVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9e2F2YWlsYWJsZVN3aXRjaElkfSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICBBcGVuYXMgZGlzcG9uw612ZWlzXG4gICAgICAgICAgICAgICAgPC9MYWJlbD5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgICAgIDxTd2l0Y2hcbiAgICAgICAgICAgICAgICAgIGlkPXtmYXZvcml0ZXNTd2l0Y2hJZH1cbiAgICAgICAgICAgICAgICAgIGNoZWNrZWQ9e0Jvb2xlYW4oc2VhcmNoLm9ubHlGYXZvcml0ZXMpfVxuICAgICAgICAgICAgICAgICAgb25DaGVja2VkQ2hhbmdlPXsoY2hlY2tlZCkgPT5cbiAgICAgICAgICAgICAgICAgICAgb25GaWx0ZXJDaGFuZ2UoeyBvbmx5RmF2b3JpdGVzOiBjaGVja2VkID8gdHJ1ZSA6IHVuZGVmaW5lZCB9KVxuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPExhYmVsIGh0bWxGb3I9e2Zhdm9yaXRlc1N3aXRjaElkfSBjbGFzc05hbWU9XCJjdXJzb3ItcG9pbnRlciB0ZXh0LXhzXCI+XG4gICAgICAgICAgICAgICAgICBNZXVzIGZhdm9yaXRvc1xuICAgICAgICAgICAgICAgIDwvTGFiZWw+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGdhcC0yXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPk9yZGVuYXI6PC9zcGFuPlxuICAgICAgICAgICAgICAgIDxTZWxlY3RcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2guc29ydH1cbiAgICAgICAgICAgICAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBpZiAodmFsdWUpIG9uRmlsdGVyQ2hhbmdlKHsgc29ydDogdmFsdWUgYXMgTmZ0U29ydEJ5IH0pXG4gICAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxTZWxlY3RUcmlnZ2VyIGFyaWEtbGFiZWw9XCJPcmRlbmFyIGNhdMOhbG9nb1wiIGNsYXNzTmFtZT1cIm1pbi13LTQ0XCI+XG4gICAgICAgICAgICAgICAgICAgIDxTZWxlY3RWYWx1ZT57U09SVF9MQUJFTFNbc2VhcmNoLnNvcnRdfTwvU2VsZWN0VmFsdWU+XG4gICAgICAgICAgICAgICAgICA8L1NlbGVjdFRyaWdnZXI+XG4gICAgICAgICAgICAgICAgICA8U2VsZWN0Q29udGVudD5cbiAgICAgICAgICAgICAgICAgICAge05GVF9TT1JUX09QVElPTlMubWFwKChvcHQpID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8U2VsZWN0SXRlbSBrZXk9e29wdH0gdmFsdWU9e29wdH0+XG4gICAgICAgICAgICAgICAgICAgICAgICB7U09SVF9MQUJFTFNbb3B0XX1cbiAgICAgICAgICAgICAgICAgICAgICA8L1NlbGVjdEl0ZW0+XG4gICAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgICAgPC9TZWxlY3RDb250ZW50PlxuICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICB7aGFzQWN0aXZlRmlsdGVycyAmJiAoXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2V0UHJpY2VFcnJvcnMoe30pXG4gICAgICAgICAgICAgICAgICAgIG9uUmVzZXRGaWx0ZXJzKClcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiTGltcGFyIHRvZG9zIG9zIGZpbHRyb3NcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgIDxSb3RhdGVDY3cgY2xhc3NOYW1lPVwic2l6ZS0zLjVcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgICAgPHNwYW4+TGltcGFyPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICB7LyogQ2hpcHMgZGUgZmlsdHJvcyBhdGl2b3MgcGFyYSBmZWVkYmFjayB0cmFuc3BhcmVudGUgKi99XG4gICAgICAgICAge2hhc0FjdGl2ZUZpbHRlcnMgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTIgcHQtMVwiIGFyaWEtbGFiZWw9XCJGaWx0cm9zIGF0aXZvc1wiPlxuICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPkF0aXZvczo8L3NwYW4+XG4gICAgICAgICAgICAgIHtzZWFyY2gucSAmJiAoXG4gICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF4LXctMzYgdHJ1bmNhdGVcIj5CdXNjYTogJmxkcXVvO3tzZWFyY2gucX0mcmRxdW87PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlJlbW92ZXIgZmlsdHJvIGRlIGJ1c2NhXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gb25GaWx0ZXJDaGFuZ2UoeyBxOiB1bmRlZmluZWQgfSl9XG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcmluZ1wiXG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInNpemUtM1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L0JhZGdlPlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICB7c2VhcmNoLmNhdGVnb3J5ICYmIChcbiAgICAgICAgICAgICAgICA8QmFkZ2UgdmFyaWFudD1cInNlY29uZGFyeVwiIGNsYXNzTmFtZT1cImdhcC0xXCI+XG4gICAgICAgICAgICAgICAgICA8c3Bhbj57Q0FURUdPUllfTEFCRUxTW3NlYXJjaC5jYXRlZ29yeV19PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlJlbW92ZXIgZmlsdHJvIGRlIGNhdGVnb3JpYVwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uRmlsdGVyQ2hhbmdlKHsgY2F0ZWdvcnk6IHVuZGVmaW5lZCB9KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1yaW5nXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwic2l6ZS0zXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIHtzZWFyY2guY29sbGVjdGlvbiAmJiAoXG4gICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJnYXAtMVwiPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWF4LXctMzYgdHJ1bmNhdGVcIj57c2VhcmNoLmNvbGxlY3Rpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlJlbW92ZXIgZmlsdHJvIGRlIGNvbGXDp8Ojb1wiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uRmlsdGVyQ2hhbmdlKHsgY29sbGVjdGlvbjogdW5kZWZpbmVkIH0pfVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLXJpbmdcIlxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8WCBjbGFzc05hbWU9XCJzaXplLTNcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC9CYWRnZT5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgeyhzZWFyY2gubWluUHJpY2UgfHwgc2VhcmNoLm1heFByaWNlKSAmJiAoXG4gICAgICAgICAgICAgICAgPEJhZGdlIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIiBjbGFzc05hbWU9XCJnYXAtMSBmb250LW1vbm9cIj5cbiAgICAgICAgICAgICAgICAgIDxzcGFuPlxuICAgICAgICAgICAgICAgICAgICB7c2VhcmNoLm1pblByaWNlID8/ICcwJ30g4oCTIHtzZWFyY2gubWF4UHJpY2UgPz8gJ+KInid9IEVUSFxuICAgICAgICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlJlbW92ZXIgZmlsdHJvIGRlIGZhaXhhIGRlIHByZcOnb1wiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uRmlsdGVyQ2hhbmdlKHsgbWluUHJpY2U6IHVuZGVmaW5lZCwgbWF4UHJpY2U6IHVuZGVmaW5lZCB9KX1cbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1mdWxsIGZvY3VzLXZpc2libGU6b3V0bGluZS1ub25lIGZvY3VzLXZpc2libGU6cmluZy0yIGZvY3VzLXZpc2libGU6cmluZy1yaW5nXCJcbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgPFggY2xhc3NOYW1lPVwic2l6ZS0zXCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuICAgICAgICA8L0NhcmRDb250ZW50PlxuICAgICAgPC9DYXJkPlxuICAgIDwvYXNpZGU+XG4gIClcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL2NvbXBvbmVudHMvbmZ0L25mdC1maWx0ZXJzLnRzeCJ9