import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=e9f94b2e";
// node_modules/@base-ui/react/internals/composite/list/CompositeListContext.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var CompositeListContext = /*#__PURE__*/ import_react.createContext({
	register: () => {},
	unregister: () => {},
	subscribeMapChange: () => () => {},
	nextIndexRef: { current: 0 }
});
CompositeListContext.displayName = "CompositeListContext";
function useCompositeListContext() {
	return import_react.useContext(CompositeListContext);
}
export { useCompositeListContext as n, CompositeListContext as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQ29tcG9zaXRlTGlzdENvbnRleHQtQ1VvaU94ek0uanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL2NvbXBvc2l0ZS9saXN0L0NvbXBvc2l0ZUxpc3RDb250ZXh0Lm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBDb21wb3NpdGVMaXN0Q29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHtcbiAgcmVnaXN0ZXI6ICgpID0+IHt9LFxuICB1bnJlZ2lzdGVyOiAoKSA9PiB7fSxcbiAgc3Vic2NyaWJlTWFwQ2hhbmdlOiAoKSA9PiAoKSA9PiB7fSxcbiAgbmV4dEluZGV4UmVmOiB7XG4gICAgY3VycmVudDogMFxuICB9XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIENvbXBvc2l0ZUxpc3RDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJDb21wb3NpdGVMaXN0Q29udGV4dFwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUNvbXBvc2l0ZUxpc3RDb250ZXh0KCkge1xuICByZXR1cm4gUmVhY3QudXNlQ29udGV4dChDb21wb3NpdGVMaXN0Q29udGV4dCk7XG59Il0sIm1hcHBpbmdzIjoiOzs7O0FBR0EsSUFBYSx1QkFBb0MsMkJBQU0sY0FBYztDQUNuRSxnQkFBZ0IsQ0FBQztDQUNqQixrQkFBa0IsQ0FBQztDQUNuQixnQ0FBZ0MsQ0FBQztDQUNqQyxjQUFjLEVBQ1osU0FBUyxFQUNYO0FBQ0YsQ0FBQztBQUMwQyxxQkFBcUIsY0FBYztBQUM5RSxTQUFnQiwwQkFBMEI7Q0FDeEMsT0FBQSxhQUFhLFdBQVcsb0JBQW9CO0FBQzlDIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==