import { u as useRefWithInit } from "/node_modules/.vite/deps/useRenderElement-CvMw8z9e.js?v=e9f94b2e";
import { t as useOnMount } from "/node_modules/.vite/deps/useOnMount-BYrs6Ouk.js?v=e9f94b2e";
// node_modules/@base-ui/utils/useTimeout.mjs
var EMPTY = 0;
var Timeout = class Timeout {
	static create() {
		return new Timeout();
	}
	currentId = EMPTY;
	/**
	* Executes `fn` after `delay`, clearing any previously scheduled call.
	*/
	start(delay, fn) {
		this.clear();
		this.currentId = setTimeout(() => {
			this.currentId = EMPTY;
			fn();
		}, delay);
	}
	isStarted() {
		return this.currentId !== EMPTY;
	}
	clear = () => {
		if (this.currentId !== EMPTY) {
			clearTimeout(this.currentId);
			this.currentId = EMPTY;
		}
	};
	disposeEffect = () => {
		return this.clear;
	};
};
/**
* A `setTimeout` with automatic cleanup and guard.
*/
function useTimeout() {
	const timeout = useRefWithInit(Timeout.create).current;
	useOnMount(timeout.disposeEffect);
	return timeout;
}
export { useTimeout as n, Timeout as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlVGltZW91dC13ME1DSUR4di5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi9AYmFzZS11aS91dGlscy91c2VUaW1lb3V0Lm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIGNsaWVudCc7XG5cbmltcG9ydCB7IHVzZVJlZldpdGhJbml0IH0gZnJvbSBcIi4vdXNlUmVmV2l0aEluaXQubWpzXCI7XG5pbXBvcnQgeyB1c2VPbk1vdW50IH0gZnJvbSBcIi4vdXNlT25Nb3VudC5tanNcIjtcbmNvbnN0IEVNUFRZID0gMDtcbmV4cG9ydCBjbGFzcyBUaW1lb3V0IHtcbiAgc3RhdGljIGNyZWF0ZSgpIHtcbiAgICByZXR1cm4gbmV3IFRpbWVvdXQoKTtcbiAgfVxuICBjdXJyZW50SWQgPSBFTVBUWTtcblxuICAvKipcbiAgICogRXhlY3V0ZXMgYGZuYCBhZnRlciBgZGVsYXlgLCBjbGVhcmluZyBhbnkgcHJldmlvdXNseSBzY2hlZHVsZWQgY2FsbC5cbiAgICovXG4gIHN0YXJ0KGRlbGF5LCBmbikge1xuICAgIHRoaXMuY2xlYXIoKTtcbiAgICB0aGlzLmN1cnJlbnRJZCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGhpcy5jdXJyZW50SWQgPSBFTVBUWTtcbiAgICAgIGZuKCk7XG4gICAgfSwgZGVsYXkpOyAvKiBOb2RlLmpzIHR5cGVzIGFyZSBlbmFibGVkIGluIGRldmVsb3BtZW50ICovXG4gIH1cbiAgaXNTdGFydGVkKCkge1xuICAgIHJldHVybiB0aGlzLmN1cnJlbnRJZCAhPT0gRU1QVFk7XG4gIH1cbiAgY2xlYXIgPSAoKSA9PiB7XG4gICAgaWYgKHRoaXMuY3VycmVudElkICE9PSBFTVBUWSkge1xuICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuY3VycmVudElkKTtcbiAgICAgIHRoaXMuY3VycmVudElkID0gRU1QVFk7XG4gICAgfVxuICB9O1xuICBkaXNwb3NlRWZmZWN0ID0gKCkgPT4ge1xuICAgIHJldHVybiB0aGlzLmNsZWFyO1xuICB9O1xufVxuXG4vKipcbiAqIEEgYHNldFRpbWVvdXRgIHdpdGggYXV0b21hdGljIGNsZWFudXAgYW5kIGd1YXJkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlVGltZW91dCgpIHtcbiAgY29uc3QgdGltZW91dCA9IHVzZVJlZldpdGhJbml0KFRpbWVvdXQuY3JlYXRlKS5jdXJyZW50O1xuICB1c2VPbk1vdW50KHRpbWVvdXQuZGlzcG9zZUVmZmVjdCk7XG4gIHJldHVybiB0aW1lb3V0O1xufSJdLCJtYXBwaW5ncyI6Ijs7O0FBSUEsSUFBTSxRQUFRO0FBQ2QsSUFBYSxVQUFiLE1BQWEsUUFBUTtDQUNuQixPQUFPLFNBQVM7RUFDZCxPQUFPLElBQUksUUFBUTtDQUNyQjtDQUNBLFlBQVk7Ozs7Q0FLWixNQUFNLE9BQU8sSUFBSTtFQUNmLEtBQUssTUFBTTtFQUNYLEtBQUssWUFBWSxpQkFBaUI7R0FDaEMsS0FBSyxZQUFZO0dBQ2pCLEdBQUc7RUFDTCxHQUFHLEtBQUs7Q0FDVjtDQUNBLFlBQVk7RUFDVixPQUFPLEtBQUssY0FBYztDQUM1QjtDQUNBLGNBQWM7RUFDWixJQUFJLEtBQUssY0FBYyxPQUFPO0dBQzVCLGFBQWEsS0FBSyxTQUFTO0dBQzNCLEtBQUssWUFBWTtFQUNuQjtDQUNGO0NBQ0Esc0JBQXNCO0VBQ3BCLE9BQU8sS0FBSztDQUNkO0FBQ0Y7Ozs7QUFLQSxTQUFnQixhQUFhO0NBQzNCLE1BQU0sVUFBVSxlQUFlLFFBQVEsTUFBTSxDQUFDLENBQUM7Q0FDL0MsV0FBVyxRQUFRLGFBQWE7Q0FDaEMsT0FBTztBQUNUIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==