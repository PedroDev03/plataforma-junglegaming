import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/cart/cart-item-row.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { Minus, Plus, Sparkles, Trash2 } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { Button } from "/src/components/ui/button.tsx";
import { Tooltip, TooltipContent, TooltipTrigger } from "/src/components/ui/tooltip.tsx";
import { useRemoveCartItem, useUpdateCartItemQuantity } from "/src/hooks/use-cart.ts";
import { formatEth, multiplyEth } from "/src/lib/eth.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/cart/cart-item-row.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
export function CartItemRow(t0) {
	_s();
	const $ = _c(90);
	if ($[0] !== "cc2fda4f357f5cd9b137ccba1d4c3039b02b21a1d39634df0bb536e7f503f17f") {
		for (let $i = 0; $i < 90; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "cc2fda4f357f5cd9b137ccba1d4c3039b02b21a1d39634df0bb536e7f503f17f";
	}
	const { item, compact: t1 } = t0;
	const compact = t1 === undefined ? false : t1;
	const updateQuantity = useUpdateCartItemQuantity();
	const removeItem = useRemoveCartItem();
	let t2;
	let t3;
	let t4;
	let t5;
	let t6;
	if ($[1] !== compact || $[2] !== item.collection || $[3] !== item.id || $[4] !== item.imageUrl || $[5] !== item.name || $[6] !== item.nftId || $[7] !== item.priceEth || $[8] !== item.quantity || $[9] !== updateQuantity) {
		const lineTotalEth = multiplyEth(item.priceEth, item.quantity);
		t4 = `Item do carrinho: ${item.name}`;
		t5 = "flex items-start justify-between gap-3 rounded-xl border bg-card p-3 shadow-xs transition-colors";
		let t7;
		if ($[15] !== item.nftId) {
			t7 = { nftId: item.nftId };
			$[15] = item.nftId;
			$[16] = t7;
		} else {
			t7 = $[16];
		}
		const t8 = `Obra NFT ${item.name} da coleção ${item.collection}`;
		let t9;
		if ($[17] !== item.imageUrl || $[18] !== t8) {
			t9 = /* @__PURE__ */ _jsxDEV("img", {
				src: item.imageUrl,
				alt: t8,
				loading: "lazy",
				decoding: "async",
				className: "size-full object-cover"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 50,
				columnNumber: 12
			}, this);
			$[17] = item.imageUrl;
			$[18] = t8;
			$[19] = t9;
		} else {
			t9 = $[19];
		}
		let t10;
		if ($[20] !== t7 || $[21] !== t9) {
			t10 = /* @__PURE__ */ _jsxDEV(Link, {
				to: "/nfts/$nftId",
				params: t7,
				className: "size-16 shrink-0 overflow-hidden rounded-lg bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:size-20",
				children: t9
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 13
			}, this);
			$[20] = t7;
			$[21] = t9;
			$[22] = t10;
		} else {
			t10 = $[22];
		}
		let t11;
		if ($[23] !== item.collection) {
			t11 = /* @__PURE__ */ _jsxDEV("p", {
				className: "truncate text-xs text-muted-foreground",
				children: item.collection
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 13
			}, this);
			$[23] = item.collection;
			$[24] = t11;
		} else {
			t11 = $[24];
		}
		let t12;
		if ($[25] !== item.nftId) {
			t12 = { nftId: item.nftId };
			$[25] = item.nftId;
			$[26] = t12;
		} else {
			t12 = $[26];
		}
		let t13;
		if ($[27] !== item.name || $[28] !== t12) {
			t13 = /* @__PURE__ */ _jsxDEV("h3", {
				className: "truncate text-sm font-semibold",
				children: /* @__PURE__ */ _jsxDEV(Link, {
					to: "/nfts/$nftId",
					params: t12,
					className: "rounded-sm hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
					children: item.name
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 86,
					columnNumber: 60
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 13
			}, this);
			$[27] = item.name;
			$[28] = t12;
			$[29] = t13;
		} else {
			t13 = $[29];
		}
		let t14;
		if ($[30] !== item.priceEth) {
			t14 = formatEth(item.priceEth);
			$[30] = item.priceEth;
			$[31] = t14;
		} else {
			t14 = $[31];
		}
		let t15;
		if ($[32] !== t14) {
			t15 = /* @__PURE__ */ _jsxDEV("p", {
				className: "font-mono text-xs text-muted-foreground tabular-nums",
				children: [
					"Unitário: ",
					t14,
					" ETH"
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 103,
				columnNumber: 13
			}, this);
			$[32] = t14;
			$[33] = t15;
		} else {
			t15 = $[33];
		}
		const t16 = `Quantidade de ${item.name}`;
		const t17 = `Diminuir quantidade de ${item.name}`;
		let t18;
		if ($[34] !== item.id || $[35] !== item.quantity || $[36] !== updateQuantity) {
			t18 = () => updateQuantity.mutate({
				itemId: item.id,
				quantity: item.quantity - 1
			});
			$[34] = item.id;
			$[35] = item.quantity;
			$[36] = updateQuantity;
			$[37] = t18;
		} else {
			t18 = $[37];
		}
		let t19;
		if ($[38] === Symbol.for("react.memo_cache_sentinel")) {
			t19 = /* @__PURE__ */ _jsxDEV(Minus, {
				className: "size-3",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 126,
				columnNumber: 13
			}, this);
			$[38] = t19;
		} else {
			t19 = $[38];
		}
		let t20;
		if ($[39] !== t17 || $[40] !== t18) {
			t20 = /* @__PURE__ */ _jsxDEV(Button, {
				type: "button",
				variant: "ghost",
				size: "icon-xs",
				"aria-label": t17,
				onClick: t18,
				children: t19
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 133,
				columnNumber: 13
			}, this);
			$[39] = t17;
			$[40] = t18;
			$[41] = t20;
		} else {
			t20 = $[41];
		}
		let t21;
		if ($[42] !== item.quantity) {
			t21 = /* @__PURE__ */ _jsxDEV("span", {
				"aria-live": "polite",
				className: "min-w-7 text-center font-mono text-xs font-semibold tabular-nums",
				children: item.quantity
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 142,
				columnNumber: 13
			}, this);
			$[42] = item.quantity;
			$[43] = t21;
		} else {
			t21 = $[43];
		}
		const t22 = item.quantity >= 10;
		const t23 = `Aumentar quantidade de ${item.name}`;
		let t24;
		if ($[44] !== item.id || $[45] !== item.quantity || $[46] !== updateQuantity) {
			t24 = () => updateQuantity.mutate({
				itemId: item.id,
				quantity: item.quantity + 1
			});
			$[44] = item.id;
			$[45] = item.quantity;
			$[46] = updateQuantity;
			$[47] = t24;
		} else {
			t24 = $[47];
		}
		let t25;
		if ($[48] === Symbol.for("react.memo_cache_sentinel")) {
			t25 = /* @__PURE__ */ _jsxDEV(Plus, {
				className: "size-3",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 165,
				columnNumber: 13
			}, this);
			$[48] = t25;
		} else {
			t25 = $[48];
		}
		let t26;
		if ($[49] !== t22 || $[50] !== t23 || $[51] !== t24) {
			t26 = /* @__PURE__ */ _jsxDEV(Button, {
				type: "button",
				variant: "ghost",
				size: "icon-xs",
				disabled: t22,
				"aria-label": t23,
				onClick: t24,
				children: t25
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 172,
				columnNumber: 13
			}, this);
			$[49] = t22;
			$[50] = t23;
			$[51] = t24;
			$[52] = t26;
		} else {
			t26 = $[52];
		}
		let t27;
		if ($[53] !== t16 || $[54] !== t20 || $[55] !== t21 || $[56] !== t26) {
			t27 = /* @__PURE__ */ _jsxDEV("div", {
				role: "group",
				"aria-label": t16,
				className: "inline-flex items-center rounded-lg border bg-background",
				children: [
					t20,
					t21,
					t26
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 182,
				columnNumber: 13
			}, this);
			$[53] = t16;
			$[54] = t20;
			$[55] = t21;
			$[56] = t26;
			$[57] = t27;
		} else {
			t27 = $[57];
		}
		const t28 = compact && /* @__PURE__ */ _jsxDEV("span", {
			className: "font-mono text-xs font-semibold tabular-nums",
			children: [formatEth(lineTotalEth), " ETH"]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 191,
			columnNumber: 28
		}, this);
		let t29;
		if ($[58] !== t27 || $[59] !== t28) {
			t29 = /* @__PURE__ */ _jsxDEV("div", {
				className: "mt-1 flex flex-wrap items-center gap-2",
				children: [t27, t28]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 194,
				columnNumber: 13
			}, this);
			$[58] = t27;
			$[59] = t28;
			$[60] = t29;
		} else {
			t29 = $[60];
		}
		let t30;
		if ($[61] !== t11 || $[62] !== t13 || $[63] !== t15 || $[64] !== t29) {
			t30 = /* @__PURE__ */ _jsxDEV("div", {
				className: "grid min-w-0 flex-1 gap-1",
				children: [
					t11,
					t13,
					t15,
					t29
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 203,
				columnNumber: 13
			}, this);
			$[61] = t11;
			$[62] = t13;
			$[63] = t15;
			$[64] = t29;
			$[65] = t30;
		} else {
			t30 = $[65];
		}
		if ($[66] !== t10 || $[67] !== t30) {
			t6 = /* @__PURE__ */ _jsxDEV("div", {
				className: "flex min-w-0 flex-1 items-start gap-3",
				children: [t10, t30]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 213,
				columnNumber: 12
			}, this);
			$[66] = t10;
			$[67] = t30;
			$[68] = t6;
		} else {
			t6 = $[68];
		}
		t2 = "flex flex-col items-end justify-between gap-2 self-stretch";
		t3 = !compact && /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-1 font-mono text-sm font-semibold tabular-nums",
			children: [/* @__PURE__ */ _jsxDEV(Sparkles, {
				className: "size-3.5 text-primary",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 221,
				columnNumber: 108
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: [formatEth(lineTotalEth), " ETH"] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 221,
				columnNumber: 173
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 221,
			columnNumber: 22
		}, this);
		$[1] = compact;
		$[2] = item.collection;
		$[3] = item.id;
		$[4] = item.imageUrl;
		$[5] = item.name;
		$[6] = item.nftId;
		$[7] = item.priceEth;
		$[8] = item.quantity;
		$[9] = updateQuantity;
		$[10] = t2;
		$[11] = t3;
		$[12] = t4;
		$[13] = t5;
		$[14] = t6;
	} else {
		t2 = $[10];
		t3 = $[11];
		t4 = $[12];
		t5 = $[13];
		t6 = $[14];
	}
	const t7 = `Remover ${item.name} do carrinho`;
	let t8;
	if ($[69] !== item.id || $[70] !== removeItem) {
		t8 = () => removeItem.mutate(item.id);
		$[69] = item.id;
		$[70] = removeItem;
		$[71] = t8;
	} else {
		t8 = $[71];
	}
	let t9;
	if ($[72] !== t7 || $[73] !== t8) {
		t9 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			variant: "ghost",
			size: "icon-sm",
			"aria-label": t7,
			onClick: t8
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 255,
			columnNumber: 10
		}, this);
		$[72] = t7;
		$[73] = t8;
		$[74] = t9;
	} else {
		t9 = $[74];
	}
	let t10;
	if ($[75] === Symbol.for("react.memo_cache_sentinel")) {
		t10 = /* @__PURE__ */ _jsxDEV(Trash2, {
			className: "size-4 text-destructive",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 264,
			columnNumber: 11
		}, this);
		$[75] = t10;
	} else {
		t10 = $[75];
	}
	let t11;
	if ($[76] !== t9) {
		t11 = /* @__PURE__ */ _jsxDEV(TooltipTrigger, {
			render: t9,
			children: t10
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 271,
			columnNumber: 11
		}, this);
		$[76] = t9;
		$[77] = t11;
	} else {
		t11 = $[77];
	}
	let t12;
	if ($[78] === Symbol.for("react.memo_cache_sentinel")) {
		t12 = /* @__PURE__ */ _jsxDEV(TooltipContent, { children: "Remover item" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 279,
			columnNumber: 11
		}, this);
		$[78] = t12;
	} else {
		t12 = $[78];
	}
	let t13;
	if ($[79] !== t11) {
		t13 = /* @__PURE__ */ _jsxDEV(Tooltip, { children: [t11, t12] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 286,
			columnNumber: 11
		}, this);
		$[79] = t11;
		$[80] = t13;
	} else {
		t13 = $[80];
	}
	let t14;
	if ($[81] !== t13 || $[82] !== t2 || $[83] !== t3) {
		t14 = /* @__PURE__ */ _jsxDEV("div", {
			className: t2,
			children: [t3, t13]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 294,
			columnNumber: 11
		}, this);
		$[81] = t13;
		$[82] = t2;
		$[83] = t3;
		$[84] = t14;
	} else {
		t14 = $[84];
	}
	let t15;
	if ($[85] !== t14 || $[86] !== t4 || $[87] !== t5 || $[88] !== t6) {
		t15 = /* @__PURE__ */ _jsxDEV("article", {
			"aria-label": t4,
			className: t5,
			children: [t6, t14]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 304,
			columnNumber: 11
		}, this);
		$[85] = t14;
		$[86] = t4;
		$[87] = t5;
		$[88] = t6;
		$[89] = t15;
	} else {
		t15 = $[89];
	}
	return t15;
}
_s(CartItemRow, "JqugDHXSsh3XxqqiXhOMNvJArIU=", false, function() {
	return [useUpdateCartItemQuantity, useRemoveCartItem];
});
_c2 = CartItemRow;
var _c2;
$RefreshReg$(_c2, "CartItemRow");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/cart/cart-item-row.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/cart/cart-item-row.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/cart/cart-item-row.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/cart/cart-item-row.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLFlBQVk7QUFDckIsU0FBU0MsT0FBT0MsTUFBTUMsVUFBVUMsY0FBYztBQUM5QyxTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLFNBQVNDLGdCQUFnQkMsc0JBQXNCO0FBQ3hELFNBQVNDLG1CQUFtQkMsaUNBQWlDO0FBQzdELFNBQVNDLFdBQVdDLG1CQUFtQjs7OztBQVF2QyxPQUFPLFNBQUFDLFlBQUFDLElBQUE7O0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQXFCLFFBQUFLLE1BQUFDLFNBQUFDLE9BQUFSO0NBQVEsTUFBQU8sVUFBQUMsT0FBQUMsWUFBQSxRQUFBRDtDQUNsQyxNQUFBRSxpQkFBdUJkLDBCQUEwQjtDQUNqRCxNQUFBZSxhQUFtQmhCLGtCQUFrQjtDQUFDLElBQUFpQjtDQUFBLElBQUFDO0NBQUEsSUFBQUM7Q0FBQSxJQUFBQztDQUFBLElBQUFDO0NBQUEsSUFBQWYsRUFBQSxPQUFBTSxXQUFBTixFQUFBLE9BQUFLLEtBQUFXLGNBQUFoQixFQUFBLE9BQUFLLEtBQUFZLE1BQUFqQixFQUFBLE9BQUFLLEtBQUFhLFlBQUFsQixFQUFBLE9BQUFLLEtBQUFjLFFBQUFuQixFQUFBLE9BQUFLLEtBQUFlLFNBQUFwQixFQUFBLE9BQUFLLEtBQUFnQixZQUFBckIsRUFBQSxPQUFBSyxLQUFBaUIsWUFBQXRCLEVBQUEsT0FBQVMsZ0JBQUE7RUFFdEMsTUFBQWMsZUFBcUIxQixZQUFZUSxLQUFJZ0IsVUFBV2hCLEtBQUlpQixRQUFTO0VBSTdDVCxLQUFBLHFCQUFxQlIsS0FBSWM7RUFDM0JMLEtBQUE7RUFBa0csSUFBQVU7RUFBQSxJQUFBeEIsRUFBQSxRQUFBSyxLQUFBZSxPQUFBO0dBS2hHSSxLQUFBLEVBQUFKLE9BQVNmLEtBQUllLE1BQU87R0FBQ3BCLEVBQUEsTUFBQUssS0FBQWU7R0FBQXBCLEVBQUEsTUFBQXdCO0VBQUE7R0FBQUEsS0FBQXhCLEVBQUE7RUFBQTtFQUt0QixNQUFBeUIsS0FBQSxZQUFZcEIsS0FBSWMsS0FBSyxjQUFlZCxLQUFJVztFQUFhLElBQUFVO0VBQUEsSUFBQTFCLEVBQUEsUUFBQUssS0FBQWEsWUFBQWxCLEVBQUEsUUFBQXlCLElBQUE7R0FGNURDLEtBQUE7SUFDTyxLQUFBckIsS0FBSWE7SUFDSixLQUFBTztJQUNHO0lBQ0M7SUFDQztHQUF3Qjs7Ozs7R0FDbEN6QixFQUFBLE1BQUFLLEtBQUFhO0dBQUFsQixFQUFBLE1BQUF5QjtHQUFBekIsRUFBQSxNQUFBMEI7RUFBQTtHQUFBQSxLQUFBMUIsRUFBQTtFQUFBO0VBQUEsSUFBQTJCO0VBQUEsSUFBQTNCLEVBQUEsUUFBQXdCLE1BQUF4QixFQUFBLFFBQUEwQixJQUFBO0dBWEpDLE1BQUEsd0JBQUMsTUFBRDtJQUNLO0lBQ0ssUUFBQUg7SUFDRTtjQUVWRTtHQUxHOzs7OztHQVlFMUIsRUFBQSxNQUFBd0I7R0FBQXhCLEVBQUEsTUFBQTBCO0dBQUExQixFQUFBLE1BQUEyQjtFQUFBO0dBQUFBLE1BQUEzQixFQUFBO0VBQUE7RUFBQSxJQUFBNEI7RUFBQSxJQUFBNUIsRUFBQSxRQUFBSyxLQUFBVyxZQUFBO0dBR0xZLE1BQUE7SUFBYTtjQUEwQ3ZCLEtBQUlXO0dBQWdCOzs7OztHQUFBaEIsRUFBQSxNQUFBSyxLQUFBVztHQUFBaEIsRUFBQSxNQUFBNEI7RUFBQTtHQUFBQSxNQUFBNUIsRUFBQTtFQUFBO0VBQUEsSUFBQTZCO0VBQUEsSUFBQTdCLEVBQUEsUUFBQUssS0FBQWUsT0FBQTtHQUkvRFMsTUFBQSxFQUFBVCxPQUFTZixLQUFJZSxNQUFPO0dBQUNwQixFQUFBLE1BQUFLLEtBQUFlO0dBQUFwQixFQUFBLE1BQUE2QjtFQUFBO0dBQUFBLE1BQUE3QixFQUFBO0VBQUE7RUFBQSxJQUFBOEI7RUFBQSxJQUFBOUIsRUFBQSxRQUFBSyxLQUFBYyxRQUFBbkIsRUFBQSxRQUFBNkIsS0FBQTtHQUhqQ0MsTUFBQTtJQUFjO2NBQ1osd0JBQUMsTUFBRDtLQUNLO0tBQ0ssUUFBQUQ7S0FDRTtlQUVUeEIsS0FBSWM7SUFMRjs7Ozs7R0FPRjs7Ozs7R0FBQW5CLEVBQUEsTUFBQUssS0FBQWM7R0FBQW5CLEVBQUEsTUFBQTZCO0dBQUE3QixFQUFBLE1BQUE4QjtFQUFBO0dBQUFBLE1BQUE5QixFQUFBO0VBQUE7RUFBQSxJQUFBK0I7RUFBQSxJQUFBL0IsRUFBQSxRQUFBSyxLQUFBZ0IsVUFBQTtHQUVRVSxNQUFBbkMsVUFBVVMsS0FBSWdCLFFBQVM7R0FBQ3JCLEVBQUEsTUFBQUssS0FBQWdCO0dBQUFyQixFQUFBLE1BQUErQjtFQUFBO0dBQUFBLE1BQUEvQixFQUFBO0VBQUE7RUFBQSxJQUFBZ0M7RUFBQSxJQUFBaEMsRUFBQSxRQUFBK0IsS0FBQTtHQURyQ0MsTUFBQTtJQUFhO2NBQWI7S0FBb0U7S0FDdkREO0tBQXlCO0lBQ2xDOzs7Ozs7R0FBQS9CLEVBQUEsTUFBQStCO0dBQUEvQixFQUFBLE1BQUFnQztFQUFBO0dBQUFBLE1BQUFoQyxFQUFBO0VBQUE7RUFNWSxNQUFBaUMsTUFBQSxpQkFBaUI1QixLQUFJYztFQU9uQixNQUFBZSxNQUFBLDBCQUEwQjdCLEtBQUljO0VBQU8sSUFBQWdCO0VBQUEsSUFBQW5DLEVBQUEsUUFBQUssS0FBQVksTUFBQWpCLEVBQUEsUUFBQUssS0FBQWlCLFlBQUF0QixFQUFBLFFBQUFTLGdCQUFBO0dBQ3hDMEIsWUFDUDFCLGVBQWMyQixPQUFRO0lBQUFDLFFBQVVoQyxLQUFJWTtJQUFHSyxVQUFZakIsS0FBSWlCLFdBQVk7R0FBRSxDQUFDO0dBQUN0QixFQUFBLE1BQUFLLEtBQUFZO0dBQUFqQixFQUFBLE1BQUFLLEtBQUFpQjtHQUFBdEIsRUFBQSxNQUFBUztHQUFBVCxFQUFBLE1BQUFtQztFQUFBO0dBQUFBLE1BQUFuQyxFQUFBO0VBQUE7RUFBQSxJQUFBc0M7RUFBQSxJQUFBdEMsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0dBR3pFa0MsTUFBQSx3QkFBQyxPQUFEO0lBQWlCO0lBQXFCO0dBQU07Ozs7O0dBQUd0QyxFQUFBLE1BQUFzQztFQUFBO0dBQUFBLE1BQUF0QyxFQUFBO0VBQUE7RUFBQSxJQUFBdUM7RUFBQSxJQUFBdkMsRUFBQSxRQUFBa0MsT0FBQWxDLEVBQUEsUUFBQW1DLEtBQUE7R0FUakRJLE1BQUEsd0JBQUMsUUFBRDtJQUNPO0lBQ0c7SUFDSDtJQUNPLGNBQUFMO0lBQ0gsU0FBQUM7Y0FJVEc7R0FUSzs7Ozs7R0FVRXRDLEVBQUEsTUFBQWtDO0dBQUFsQyxFQUFBLE1BQUFtQztHQUFBbkMsRUFBQSxNQUFBdUM7RUFBQTtHQUFBQSxNQUFBdkMsRUFBQTtFQUFBO0VBQUEsSUFBQXdDO0VBQUEsSUFBQXhDLEVBQUEsUUFBQUssS0FBQWlCLFVBQUE7R0FFVGtCLE1BQUE7SUFDWTtJQUNBO2NBRVRuQyxLQUFJaUI7R0FDQTs7Ozs7R0FBQXRCLEVBQUEsTUFBQUssS0FBQWlCO0dBQUF0QixFQUFBLE1BQUF3QztFQUFBO0dBQUFBLE1BQUF4QyxFQUFBO0VBQUE7RUFNSyxNQUFBeUMsTUFBQXBDLEtBQUlpQixZQUFhO0VBQ2YsTUFBQW9CLE1BQUEsMEJBQTBCckMsS0FBSWM7RUFBTyxJQUFBd0I7RUFBQSxJQUFBM0MsRUFBQSxRQUFBSyxLQUFBWSxNQUFBakIsRUFBQSxRQUFBSyxLQUFBaUIsWUFBQXRCLEVBQUEsUUFBQVMsZ0JBQUE7R0FDeENrQyxZQUNQbEMsZUFBYzJCLE9BQVE7SUFBQUMsUUFBVWhDLEtBQUlZO0lBQUdLLFVBQVlqQixLQUFJaUIsV0FBWTtHQUFFLENBQUM7R0FBQ3RCLEVBQUEsTUFBQUssS0FBQVk7R0FBQWpCLEVBQUEsTUFBQUssS0FBQWlCO0dBQUF0QixFQUFBLE1BQUFTO0dBQUFULEVBQUEsTUFBQTJDO0VBQUE7R0FBQUEsTUFBQTNDLEVBQUE7RUFBQTtFQUFBLElBQUE0QztFQUFBLElBQUE1QyxFQUFBLFFBQUFHLE9BQUFDLElBQUE7R0FHekV3QyxNQUFBLHdCQUFDLE1BQUQ7SUFBZ0I7SUFBcUI7R0FBTTs7Ozs7R0FBRzVDLEVBQUEsTUFBQTRDO0VBQUE7R0FBQUEsTUFBQTVDLEVBQUE7RUFBQTtFQUFBLElBQUE2QztFQUFBLElBQUE3QyxFQUFBLFFBQUF5QyxPQUFBekMsRUFBQSxRQUFBMEMsT0FBQTFDLEVBQUEsUUFBQTJDLEtBQUE7R0FWaERFLE1BQUEsd0JBQUMsUUFBRDtJQUNPO0lBQ0c7SUFDSDtJQUNLLFVBQUFKO0lBQ0UsY0FBQUM7SUFDSCxTQUFBQztjQUlUQztHQVZLOzs7OztHQVdFNUMsRUFBQSxNQUFBeUM7R0FBQXpDLEVBQUEsTUFBQTBDO0dBQUExQyxFQUFBLE1BQUEyQztHQUFBM0MsRUFBQSxNQUFBNkM7RUFBQTtHQUFBQSxNQUFBN0MsRUFBQTtFQUFBO0VBQUEsSUFBQThDO0VBQUEsSUFBQTlDLEVBQUEsUUFBQWlDLE9BQUFqQyxFQUFBLFFBQUF1QyxPQUFBdkMsRUFBQSxRQUFBd0MsT0FBQXhDLEVBQUEsUUFBQTZDLEtBQUE7R0FuQ1hDLE1BQUE7SUFDTztJQUNPLGNBQUFiO0lBQ0Y7Y0FIWjtLQUtFTTtLQVlBQztLQU9BSztJQVlJOzs7Ozs7R0FBQTdDLEVBQUEsTUFBQWlDO0dBQUFqQyxFQUFBLE1BQUF1QztHQUFBdkMsRUFBQSxNQUFBd0M7R0FBQXhDLEVBQUEsTUFBQTZDO0dBQUE3QyxFQUFBLE1BQUE4QztFQUFBO0dBQUFBLE1BQUE5QyxFQUFBO0VBQUE7RUFFTCxNQUFBK0MsTUFBQXpDLFdBQ0M7R0FBZ0I7YUFBaEIsQ0FDR1YsVUFBVTJCLFlBQVksR0FBRSxNQUNwQjs7Ozs7O0VBQ1IsSUFBQXlCO0VBQUEsSUFBQWhELEVBQUEsUUFBQThDLE9BQUE5QyxFQUFBLFFBQUErQyxLQUFBO0dBM0NIQyxNQUFBO0lBQWU7Y0FBZixDQUNFRixLQXNDQ0MsR0FLRzs7Ozs7O0dBQUEvQyxFQUFBLE1BQUE4QztHQUFBOUMsRUFBQSxNQUFBK0M7R0FBQS9DLEVBQUEsTUFBQWdEO0VBQUE7R0FBQUEsTUFBQWhELEVBQUE7RUFBQTtFQUFBLElBQUFpRDtFQUFBLElBQUFqRCxFQUFBLFFBQUE0QixPQUFBNUIsRUFBQSxRQUFBOEIsT0FBQTlCLEVBQUEsUUFBQWdDLE9BQUFoQyxFQUFBLFFBQUFnRCxLQUFBO0dBNURSQyxNQUFBO0lBQWU7Y0FBZjtLQUNFckI7S0FDQUU7S0FTQUU7S0FLQWdCO0lBNkNJOzs7Ozs7R0FBQWhELEVBQUEsTUFBQTRCO0dBQUE1QixFQUFBLE1BQUE4QjtHQUFBOUIsRUFBQSxNQUFBZ0M7R0FBQWhDLEVBQUEsTUFBQWdEO0dBQUFoRCxFQUFBLE1BQUFpRDtFQUFBO0dBQUFBLE1BQUFqRCxFQUFBO0VBQUE7RUFBQSxJQUFBQSxFQUFBLFFBQUEyQixPQUFBM0IsRUFBQSxRQUFBaUQsS0FBQTtHQTVFUmxDLEtBQUE7SUFBZTtjQUFmLENBQ0VZLEtBY0FzQixHQThESTs7Ozs7O0dBQUFqRCxFQUFBLE1BQUEyQjtHQUFBM0IsRUFBQSxNQUFBaUQ7R0FBQWpELEVBQUEsTUFBQWU7RUFBQTtHQUFBQSxLQUFBZixFQUFBO0VBQUE7RUFFU1csS0FBQTtFQUNaQyxLQUFBLENBQUNOLFdBQ0E7R0FBZTthQUFmLENBQ0Usd0JBQUMsVUFBRDtJQUFvQjtJQUFvQztHQUFNOzs7O2FBQzlELDZDQUFPVixVQUFVMkIsWUFBWSxHQUFFLE1BQVc7Ozs7V0FDdEM7Ozs7OztFQUNQdkIsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFLLEtBQUFXO0VBQUFoQixFQUFBLEtBQUFLLEtBQUFZO0VBQUFqQixFQUFBLEtBQUFLLEtBQUFhO0VBQUFsQixFQUFBLEtBQUFLLEtBQUFjO0VBQUFuQixFQUFBLEtBQUFLLEtBQUFlO0VBQUFwQixFQUFBLEtBQUFLLEtBQUFnQjtFQUFBckIsRUFBQSxLQUFBSyxLQUFBaUI7RUFBQXRCLEVBQUEsS0FBQVM7RUFBQVQsRUFBQSxNQUFBVztFQUFBWCxFQUFBLE1BQUFZO0VBQUFaLEVBQUEsTUFBQWE7RUFBQWIsRUFBQSxNQUFBYztFQUFBZCxFQUFBLE1BQUFlO0NBQUE7RUFBQUosS0FBQVgsRUFBQTtFQUFBWSxLQUFBWixFQUFBO0VBQUFhLEtBQUFiLEVBQUE7RUFBQWMsS0FBQWQsRUFBQTtFQUFBZSxLQUFBZixFQUFBO0NBQUE7Q0FTbUIsTUFBQXdCLEtBQUEsV0FBV25CLEtBQUljLEtBQUs7Q0FBYyxJQUFBTTtDQUFBLElBQUF6QixFQUFBLFFBQUFLLEtBQUFZLE1BQUFqQixFQUFBLFFBQUFVLFlBQUE7RUFDckNlLFdBQU1mLFdBQVUwQixPQUFRL0IsS0FBSVksRUFBRztFQUFDakIsRUFBQSxNQUFBSyxLQUFBWTtFQUFBakIsRUFBQSxNQUFBVTtFQUFBVixFQUFBLE1BQUF5QjtDQUFBO0VBQUFBLEtBQUF6QixFQUFBO0NBQUE7Q0FBQSxJQUFBMEI7Q0FBQSxJQUFBMUIsRUFBQSxRQUFBd0IsTUFBQXhCLEVBQUEsUUFBQXlCLElBQUE7RUFMM0NDLEtBQUEsd0JBQUMsUUFBRDtHQUNPO0dBQ0c7R0FDSDtHQUNPLGNBQUFGO0dBQ0gsU0FBQUM7RUFBZ0M7Ozs7O0VBQ3pDekIsRUFBQSxNQUFBd0I7RUFBQXhCLEVBQUEsTUFBQXlCO0VBQUF6QixFQUFBLE1BQUEwQjtDQUFBO0VBQUFBLEtBQUExQixFQUFBO0NBQUE7Q0FBQSxJQUFBMkI7Q0FBQSxJQUFBM0IsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBR0p1QixNQUFBLHdCQUFDLFFBQUQ7R0FBa0I7R0FBc0M7RUFBTTs7Ozs7RUFBRzNCLEVBQUEsTUFBQTJCO0NBQUE7RUFBQUEsTUFBQTNCLEVBQUE7Q0FBQTtDQUFBLElBQUE0QjtDQUFBLElBQUE1QixFQUFBLFFBQUEwQixJQUFBO0VBWG5FRSxNQUFBLHdCQUFDLGdCQUFEO0dBRUksUUFBQUY7YUFTRkM7RUFYYTs7Ozs7RUFZRTNCLEVBQUEsTUFBQTBCO0VBQUExQixFQUFBLE1BQUE0QjtDQUFBO0VBQUFBLE1BQUE1QixFQUFBO0NBQUE7Q0FBQSxJQUFBNkI7Q0FBQSxJQUFBN0IsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBQ2pCeUIsTUFBQSx3QkFBQyxnQkFBRCxZQUFnQixlQUFEOzs7OztFQUE4QjdCLEVBQUEsTUFBQTZCO0NBQUE7RUFBQUEsTUFBQTdCLEVBQUE7Q0FBQTtDQUFBLElBQUE4QjtDQUFBLElBQUE5QixFQUFBLFFBQUE0QixLQUFBO0VBZC9DRSxNQUFBLHdCQUFDLFNBQUQsYUFDRUYsS0FhQUMsR0FkTTs7Ozs7RUFlRTdCLEVBQUEsTUFBQTRCO0VBQUE1QixFQUFBLE1BQUE4QjtDQUFBO0VBQUFBLE1BQUE5QixFQUFBO0NBQUE7Q0FBQSxJQUFBK0I7Q0FBQSxJQUFBL0IsRUFBQSxRQUFBOEIsT0FBQTlCLEVBQUEsUUFBQVcsTUFBQVgsRUFBQSxRQUFBWSxJQUFBO0VBdkJabUIsTUFBQTtHQUFlLFdBQUFwQjthQUFmLENBQ0dDLElBT0RrQixHQWdCSTs7Ozs7O0VBQUE5QixFQUFBLE1BQUE4QjtFQUFBOUIsRUFBQSxNQUFBVztFQUFBWCxFQUFBLE1BQUFZO0VBQUFaLEVBQUEsTUFBQStCO0NBQUE7RUFBQUEsTUFBQS9CLEVBQUE7Q0FBQTtDQUFBLElBQUFnQztDQUFBLElBQUFoQyxFQUFBLFFBQUErQixPQUFBL0IsRUFBQSxRQUFBYSxNQUFBYixFQUFBLFFBQUFjLE1BQUFkLEVBQUEsUUFBQWUsSUFBQTtFQTNHUmlCLE1BQUE7R0FDYyxjQUFBbkI7R0FDRixXQUFBQzthQUZaLENBSUVDLElBK0VBZ0IsR0F5QlE7Ozs7OztFQUFBL0IsRUFBQSxNQUFBK0I7RUFBQS9CLEVBQUEsTUFBQWE7RUFBQWIsRUFBQSxNQUFBYztFQUFBZCxFQUFBLE1BQUFlO0VBQUFmLEVBQUEsTUFBQWdDO0NBQUE7RUFBQUEsTUFBQWhDLEVBQUE7Q0FBQTtDQUFBLE9BNUdWZ0M7QUE0R1UiLCJuYW1lcyI6WyJMaW5rIiwiTWludXMiLCJQbHVzIiwiU3BhcmtsZXMiLCJUcmFzaDIiLCJCdXR0b24iLCJUb29sdGlwIiwiVG9vbHRpcENvbnRlbnQiLCJUb29sdGlwVHJpZ2dlciIsInVzZVJlbW92ZUNhcnRJdGVtIiwidXNlVXBkYXRlQ2FydEl0ZW1RdWFudGl0eSIsImZvcm1hdEV0aCIsIm11bHRpcGx5RXRoIiwiQ2FydEl0ZW1Sb3ciLCJ0MCIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwiaXRlbSIsImNvbXBhY3QiLCJ0MSIsInVuZGVmaW5lZCIsInVwZGF0ZVF1YW50aXR5IiwicmVtb3ZlSXRlbSIsInQyIiwidDMiLCJ0NCIsInQ1IiwidDYiLCJjb2xsZWN0aW9uIiwiaWQiLCJpbWFnZVVybCIsIm5hbWUiLCJuZnRJZCIsInByaWNlRXRoIiwicXVhbnRpdHkiLCJsaW5lVG90YWxFdGgiLCJ0NyIsInQ4IiwidDkiLCJ0MTAiLCJ0MTEiLCJ0MTIiLCJ0MTMiLCJ0MTQiLCJ0MTUiLCJ0MTYiLCJ0MTciLCJ0MTgiLCJtdXRhdGUiLCJpdGVtSWQiLCJ0MTkiLCJ0MjAiLCJ0MjEiLCJ0MjIiLCJ0MjMiLCJ0MjQiLCJ0MjUiLCJ0MjYiLCJ0MjciLCJ0MjgiLCJ0MjkiLCJ0MzAiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiY2FydC1pdGVtLXJvdy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyBNaW51cywgUGx1cywgU3BhcmtsZXMsIFRyYXNoMiB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9idXR0b24nXG5pbXBvcnQgeyBUb29sdGlwLCBUb29sdGlwQ29udGVudCwgVG9vbHRpcFRyaWdnZXIgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvdG9vbHRpcCdcbmltcG9ydCB7IHVzZVJlbW92ZUNhcnRJdGVtLCB1c2VVcGRhdGVDYXJ0SXRlbVF1YW50aXR5IH0gZnJvbSAnQC9ob29rcy91c2UtY2FydCdcbmltcG9ydCB7IGZvcm1hdEV0aCwgbXVsdGlwbHlFdGggfSBmcm9tICdAL2xpYi9ldGgnXG5pbXBvcnQgdHlwZSB7IENhcnRJdGVtIH0gZnJvbSAnQC90eXBlcy9tb2RlbHMnXG5cbmludGVyZmFjZSBDYXJ0SXRlbVJvd1Byb3BzIHtcbiAgaXRlbTogQ2FydEl0ZW1cbiAgY29tcGFjdD86IGJvb2xlYW5cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIENhcnRJdGVtUm93KHsgaXRlbSwgY29tcGFjdCA9IGZhbHNlIH06IENhcnRJdGVtUm93UHJvcHMpIHtcbiAgY29uc3QgdXBkYXRlUXVhbnRpdHkgPSB1c2VVcGRhdGVDYXJ0SXRlbVF1YW50aXR5KClcbiAgY29uc3QgcmVtb3ZlSXRlbSA9IHVzZVJlbW92ZUNhcnRJdGVtKClcblxuICBjb25zdCBsaW5lVG90YWxFdGggPSBtdWx0aXBseUV0aChpdGVtLnByaWNlRXRoLCBpdGVtLnF1YW50aXR5KVxuXG4gIHJldHVybiAoXG4gICAgPGFydGljbGVcbiAgICAgIGFyaWEtbGFiZWw9e2BJdGVtIGRvIGNhcnJpbmhvOiAke2l0ZW0ubmFtZX1gfVxuICAgICAgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gZ2FwLTMgcm91bmRlZC14bCBib3JkZXIgYmctY2FyZCBwLTMgc2hhZG93LXhzIHRyYW5zaXRpb24tY29sb3JzXCJcbiAgICA+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggbWluLXctMCBmbGV4LTEgaXRlbXMtc3RhcnQgZ2FwLTNcIj5cbiAgICAgICAgPExpbmtcbiAgICAgICAgICB0bz1cIi9uZnRzLyRuZnRJZFwiXG4gICAgICAgICAgcGFyYW1zPXt7IG5mdElkOiBpdGVtLm5mdElkIH19XG4gICAgICAgICAgY2xhc3NOYW1lPVwic2l6ZS0xNiBzaHJpbmstMCBvdmVyZmxvdy1oaWRkZW4gcm91bmRlZC1sZyBiZy1tdXRlZCBmb2N1cy12aXNpYmxlOm91dGxpbmUtbm9uZSBmb2N1cy12aXNpYmxlOnJpbmctMiBmb2N1cy12aXNpYmxlOnJpbmctcmluZyBzbTpzaXplLTIwXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxpbWdcbiAgICAgICAgICAgIHNyYz17aXRlbS5pbWFnZVVybH1cbiAgICAgICAgICAgIGFsdD17YE9icmEgTkZUICR7aXRlbS5uYW1lfSBkYSBjb2xlw6fDo28gJHtpdGVtLmNvbGxlY3Rpb259YH1cbiAgICAgICAgICAgIGxvYWRpbmc9XCJsYXp5XCJcbiAgICAgICAgICAgIGRlY29kaW5nPVwiYXN5bmNcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwic2l6ZS1mdWxsIG9iamVjdC1jb3ZlclwiXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9MaW5rPlxuXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBtaW4tdy0wIGZsZXgtMSBnYXAtMVwiPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRydW5jYXRlIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kXCI+e2l0ZW0uY29sbGVjdGlvbn08L3A+XG4gICAgICAgICAgPGgzIGNsYXNzTmFtZT1cInRydW5jYXRlIHRleHQtc20gZm9udC1zZW1pYm9sZFwiPlxuICAgICAgICAgICAgPExpbmtcbiAgICAgICAgICAgICAgdG89XCIvbmZ0cy8kbmZ0SWRcIlxuICAgICAgICAgICAgICBwYXJhbXM9e3sgbmZ0SWQ6IGl0ZW0ubmZ0SWQgfX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwicm91bmRlZC1zbSBob3Zlcjp1bmRlcmxpbmUgZm9jdXMtdmlzaWJsZTpvdXRsaW5lLW5vbmUgZm9jdXMtdmlzaWJsZTpyaW5nLTIgZm9jdXMtdmlzaWJsZTpyaW5nLXJpbmdcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7aXRlbS5uYW1lfVxuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDwvaDM+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIHRhYnVsYXItbnVtc1wiPlxuICAgICAgICAgICAgVW5pdMOhcmlvOiB7Zm9ybWF0RXRoKGl0ZW0ucHJpY2VFdGgpfSBFVEhcbiAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICB7LyogQ29udHJvbGVzIGRlIHF1YW50aWRhZGUgYWNlc3PDrXZlaXMgKi99XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBnYXAtMlwiPlxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICByb2xlPVwiZ3JvdXBcIlxuICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgUXVhbnRpZGFkZSBkZSAke2l0ZW0ubmFtZX1gfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJpbmxpbmUtZmxleCBpdGVtcy1jZW50ZXIgcm91bmRlZC1sZyBib3JkZXIgYmctYmFja2dyb3VuZFwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgICAgIHNpemU9XCJpY29uLXhzXCJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgRGltaW51aXIgcXVhbnRpZGFkZSBkZSAke2l0ZW0ubmFtZX1gfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgICB1cGRhdGVRdWFudGl0eS5tdXRhdGUoeyBpdGVtSWQ6IGl0ZW0uaWQsIHF1YW50aXR5OiBpdGVtLnF1YW50aXR5IC0gMSB9KVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxNaW51cyBjbGFzc05hbWU9XCJzaXplLTNcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgICA8L0J1dHRvbj5cblxuICAgICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICAgIGFyaWEtbGl2ZT1cInBvbGl0ZVwiXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWluLXctNyB0ZXh0LWNlbnRlciBmb250LW1vbm8gdGV4dC14cyBmb250LXNlbWlib2xkIHRhYnVsYXItbnVtc1wiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7aXRlbS5xdWFudGl0eX1cbiAgICAgICAgICAgICAgPC9zcGFuPlxuXG4gICAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgICAgIHNpemU9XCJpY29uLXhzXCJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17aXRlbS5xdWFudGl0eSA+PSAxMH1cbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgQXVtZW50YXIgcXVhbnRpZGFkZSBkZSAke2l0ZW0ubmFtZX1gfVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XG4gICAgICAgICAgICAgICAgICB1cGRhdGVRdWFudGl0eS5tdXRhdGUoeyBpdGVtSWQ6IGl0ZW0uaWQsIHF1YW50aXR5OiBpdGVtLnF1YW50aXR5ICsgMSB9KVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxQbHVzIGNsYXNzTmFtZT1cInNpemUtM1wiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIHtjb21wYWN0ICYmIChcbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgZm9udC1zZW1pYm9sZCB0YWJ1bGFyLW51bXNcIj5cbiAgICAgICAgICAgICAgICB7Zm9ybWF0RXRoKGxpbmVUb3RhbEV0aCl9IEVUSFxuICAgICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgICApfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtZW5kIGp1c3RpZnktYmV0d2VlbiBnYXAtMiBzZWxmLXN0cmV0Y2hcIj5cbiAgICAgICAgeyFjb21wYWN0ICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGdhcC0xIGZvbnQtbW9ubyB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdGFidWxhci1udW1zXCI+XG4gICAgICAgICAgICA8U3BhcmtsZXMgY2xhc3NOYW1lPVwic2l6ZS0zLjUgdGV4dC1wcmltYXJ5XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgIDxzcGFuPntmb3JtYXRFdGgobGluZVRvdGFsRXRoKX0gRVRIPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApfVxuXG4gICAgICAgIDxUb29sdGlwPlxuICAgICAgICAgIDxUb29sdGlwVHJpZ2dlclxuICAgICAgICAgICAgcmVuZGVyPXtcbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJnaG9zdFwiXG4gICAgICAgICAgICAgICAgc2l6ZT1cImljb24tc21cIlxuICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BSZW1vdmVyICR7aXRlbS5uYW1lfSBkbyBjYXJyaW5ob2B9XG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVtb3ZlSXRlbS5tdXRhdGUoaXRlbS5pZCl9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPFRyYXNoMiBjbGFzc05hbWU9XCJzaXplLTQgdGV4dC1kZXN0cnVjdGl2ZVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgPC9Ub29sdGlwVHJpZ2dlcj5cbiAgICAgICAgICA8VG9vbHRpcENvbnRlbnQ+UmVtb3ZlciBpdGVtPC9Ub29sdGlwQ29udGVudD5cbiAgICAgICAgPC9Ub29sdGlwPlxuICAgICAgPC9kaXY+XG4gICAgPC9hcnRpY2xlPlxuICApXG59XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9jb21wb25lbnRzL2NhcnQvY2FydC1pdGVtLXJvdy50c3gifQ==