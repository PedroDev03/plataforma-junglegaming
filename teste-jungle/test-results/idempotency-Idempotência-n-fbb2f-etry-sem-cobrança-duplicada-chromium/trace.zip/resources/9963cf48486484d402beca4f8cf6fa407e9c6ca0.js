import { n as __exportAll, r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=e9f94b2e";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom-CRx58tZq.js?v=e9f94b2e";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-cNwuCTLA.js?v=e9f94b2e";
import { r as useIsoLayoutEffect, t as useStableCallback } from "/node_modules/.vite/deps/formatErrorMessage-BEgQI17N.js?v=e9f94b2e";
import { a as getNodeName, c as getParentNode, d as isElement, f as isHTMLElement, g as isShadowRoot, m as isNode, p as isLastTraversableNode, t as getComputedStyle } from "/node_modules/.vite/deps/floating-ui.utils.dom-B45hE2lE.js?v=e9f94b2e";
import { n as ownerDocument } from "/node_modules/.vite/deps/inertValue-DbKApsSW.js?v=e9f94b2e";
import { a as isReactVersionAtLeast, c as EMPTY_OBJECT, l as NOOP, n as useRenderElement, u as useRefWithInit } from "/node_modules/.vite/deps/useRenderElement-CvMw8z9e.js?v=e9f94b2e";
import { n as useTimeout, t as Timeout } from "/node_modules/.vite/deps/useTimeout-w0MCIDxv.js?v=e9f94b2e";
import { a as transitionStatusMapping, o as endingStyle$1, r as useTransitionStatus, s as startingStyle$1, t as useOpenChangeComplete } from "/node_modules/.vite/deps/useOpenChangeComplete-BJDlY1Cs.js?v=e9f94b2e";
import { a as isElementVisible, c as activeElement, d as getTarget, l as closest, u as contains } from "/node_modules/.vite/deps/composite-DUPI88po.js?v=e9f94b2e";
import { S as triggerPress, a as escapeKey, g as outsidePress, h as none, w as createChangeEventDetails, x as triggerHover } from "/node_modules/.vite/deps/reason-parts-D-IkPsXA.js?v=e9f94b2e";
import { t as visuallyHidden } from "/node_modules/.vite/deps/visuallyHidden-DjYUaVmG.js?v=e9f94b2e";
import { n as useId, r as useForcedRerendering } from "/node_modules/.vite/deps/useBaseUiId-UM7l9pLZ.js?v=e9f94b2e";
import { t as require_shim } from "/node_modules/.vite/deps/shim-DoFbYQL4.js?v=e9f94b2e";
import { t as require_with_selector } from "/node_modules/.vite/deps/with-selector-QKyvNQmu.js?v=e9f94b2e";
// node_modules/@base-ui/utils/addEventListener.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
/**
* Adds an event listener and returns a cleanup function to remove it.
*/
function addEventListener(target, type, listener, options) {
	target.addEventListener(type, listener, options);
	return () => {
		target.removeEventListener(type, listener, options);
	};
}
// node_modules/@base-ui/utils/platform/shared.mjs
/**
* Reads `navigator.userAgent` / `navigator.platform` (legacy but universally
* supported) into a normalized shape. In development, prefers the modern
* `navigator.userAgentData` API on Chromium to avoid DevTools warnings about
* the deprecated reads; that branch is dead-code-eliminated in production
* builds to keep the bundle small.
*
* Returns empty/zero values when `navigator` is undefined (SSR), so every
* derived flag safely evaluates to `false`.
*/
function readRawData() {
	if (typeof navigator === "undefined") return {
		userAgent: "",
		platform: "",
		maxTouchPoints: 0
	};
	{
		const uaData = navigator.userAgentData;
		if (uaData && Array.isArray(uaData.brands)) return {
			userAgent: uaData.brands.map(({ brand, version }) => `${brand}/${version}`).join(" "),
			platform: uaData.platform ?? navigator.platform ?? "",
			maxTouchPoints: navigator.maxTouchPoints ?? 0
		};
	}
	return {
		userAgent: navigator.userAgent,
		platform: navigator.platform ?? "",
		maxTouchPoints: navigator.maxTouchPoints ?? 0
	};
}
var { userAgent, platform, maxTouchPoints } = readRawData();
var lowerUserAgent = userAgent.toLowerCase();
var lowerPlatform = platform.toLowerCase();
// node_modules/@base-ui/utils/platform/os.mjs
/** iPhone, iPad (including iPadOS 13+ reporting as macOS), iPod. */
var ios = /^i(os$|p)/.test(lowerPlatform) || lowerPlatform === "macintel" && maxTouchPoints > 1;
/** Android phones, tablets, and embedded Android browsers. */
var ANDROID_STRING = "android";
var android = lowerPlatform === ANDROID_STRING || lowerUserAgent.includes(ANDROID_STRING);
/** macOS desktop. Excludes iPadOS, which reports as `MacIntel`. */
var mac = !ios && lowerPlatform.startsWith("mac");
lowerPlatform.startsWith("win");
!android && /^(linux|chrome os)/.test(lowerPlatform);
/** Any Apple OS (`mac || ios`). */
var apple = mac || ios;
// node_modules/@base-ui/utils/platform/engine.mjs
/** WebKit: Safari, all iOS browsers, GNOME Web. Excludes Blink. */
var webkit = typeof CSS !== "undefined" && !!CSS.supports?.("-webkit-backdrop-filter:none");
!webkit && lowerUserAgent.includes("firefox");
!webkit && lowerUserAgent.includes("chrom");
// node_modules/@base-ui/utils/platform/screen-reader.mjs
/**
* The user *may* be using VoiceOver — actual activation is not detectable.
* True on any Apple platform (macOS, iOS, iPadOS).
*/
var voiceOver = apple;
// node_modules/@base-ui/utils/platform/env.mjs
/** Running in jsdom or HappyDOM (used by unit tests). */
var jsdom = /jsdom|happydom/.test(lowerUserAgent);
// node_modules/@base-ui/react/floating-ui-react/utils/event.mjs
var import_jsx_runtime = require_jsx_runtime();
function stopEvent(event) {
	event.preventDefault();
	event.stopPropagation();
}
function isReactEvent(event) {
	return "nativeEvent" in event;
}
function isVirtualClick(event) {
	if (event.pointerType === "" && event.isTrusted) return true;
	if (android && event.pointerType) return event.type === "click" && event.buttons === 1;
	return event.detail === 0 && !event.pointerType;
}
function isVirtualPointerEvent(event) {
	if (jsdom) return false;
	return !android && event.width === 0 && event.height === 0 || event.type === "pointerdown" && event.width === 1 && event.height === 1 && event.pressure === 0 && event.detail === 0 && event.pointerType === "mouse" && (android || event.buttons === 0) || event.width < 1 && event.height < 1 && event.pressure === 0 && event.detail === 0 && event.pointerType === "touch";
}
function isMouseLikePointerType(pointerType, strict) {
	const values = ["mouse", "pen"];
	if (!strict) values.push("", void 0);
	return values.includes(pointerType);
}
function isClickLikeEvent(event) {
	const type = event.type;
	return type === "click" || type === "mousedown" || type === "keydown" || type === "keyup";
}
// node_modules/@base-ui/react/floating-ui-react/utils/constants.mjs
var FOCUSABLE_ATTRIBUTE = "data-base-ui-focusable";
var TYPEABLE_SELECTOR = "input:not([type='hidden']):not([disabled]),[contenteditable]:not([contenteditable='false']),textarea:not([disabled])";
var ARROW_LEFT = "ArrowLeft";
var ARROW_RIGHT = "ArrowRight";
var ARROW_UP = "ArrowUp";
var ARROW_DOWN = "ArrowDown";
// node_modules/@base-ui/react/utils/CommonPopupDataAttributes.mjs
/**
* Present when the popup is open.
*/
var open = "data-open";
/**
* Present when the popup is closed.
*/
var closed = "data-closed";
/**
* Present when the popup begins animating in.
*/
var startingStyle = startingStyle$1;
/**
* Present when the popup is animating out.
*/
var endingStyle = endingStyle$1;
/**
* Present when the anchor is hidden.
*/
var anchorHidden = "data-anchor-hidden";
/**
* Indicates which side the popup is positioned relative to the trigger.
* @type { 'top' | 'bottom' | 'left' | 'right' | 'inline-end' | 'inline-start'}
*/
var side = "data-side";
/**
* Indicates how the popup is aligned relative to specified side.
* @type {'start' | 'center' | 'end'}
*/
var align = "data-align";
// node_modules/@base-ui/react/utils/CommonTriggerDataAttributes.mjs
/**
* Present when the popup is open.
*/
var popupOpen$1 = "data-popup-open";
/**
* Present when a pressable trigger is pressed.
*/
var pressed = "data-pressed";
// node_modules/@base-ui/react/utils/popupStateMapping.mjs
var TRIGGER_HOOK = { [popupOpen$1]: "" };
var PRESSABLE_TRIGGER_HOOK = {
	[popupOpen$1]: "",
	[pressed]: ""
};
var POPUP_OPEN_HOOK = { [open]: "" };
var POPUP_CLOSED_HOOK = { [closed]: "" };
var ANCHOR_HIDDEN_HOOK = { [anchorHidden]: "" };
var triggerOpenStateMapping = { open(value) {
	if (value) return TRIGGER_HOOK;
	return null;
} };
var pressableTriggerOpenStateMapping = { open(value) {
	if (value) return PRESSABLE_TRIGGER_HOOK;
	return null;
} };
var popupStateMapping = {
	open(value) {
		if (value) return POPUP_OPEN_HOOK;
		return POPUP_CLOSED_HOOK;
	},
	anchorHidden(value) {
		if (value) return ANCHOR_HIDDEN_HOOK;
		return null;
	}
};
var popupTransitionStateMapping = {
	...popupStateMapping,
	...transitionStatusMapping
};
// node_modules/@base-ui/react/tooltip/trigger/TooltipTriggerDataAttributes.mjs
var TooltipTriggerDataAttributes_exports = /* @__PURE__ */ __exportAll({
	popupOpen: () => popupOpen,
	triggerDisabled: () => triggerDisabled
});
/**
* Present when the corresponding tooltip is open.
*/
var popupOpen = popupOpen$1;
/**
* Present when the trigger is disabled, either by the `disabled` prop or by a parent `<Tooltip.Root>` component.
*/
var triggerDisabled = "data-trigger-disabled";
// node_modules/@base-ui/react/floating-ui-react/utils/element.mjs
function isTargetInsideEnabledTrigger(target, triggerElements) {
	if (!isElement(target)) return false;
	const targetElement = target;
	if (triggerElements.hasElement(targetElement)) return !targetElement.hasAttribute(triggerDisabled);
	for (const [, trigger] of triggerElements.entries()) if (contains(trigger, targetElement)) return !trigger.hasAttribute(triggerDisabled);
	return false;
}
function isEventTargetWithin(event, node) {
	if (node == null) return false;
	if ("composedPath" in event) return event.composedPath().includes(node);
	const eventAgain = event;
	return eventAgain.target != null && node.contains(eventAgain.target);
}
function isRootElement(element) {
	return element.matches("html,body");
}
function isTypeableElement(element) {
	return isHTMLElement(element) && element.matches("input:not([type='hidden']):not([disabled]),[contenteditable]:not([contenteditable='false']),textarea:not([disabled])");
}
function isInteractiveElement(element) {
	return closest(element, `button,a[href],[role="button"],select,[tabindex]:not([tabindex="-1"]),${TYPEABLE_SELECTOR}`) != null;
}
function isTypeableCombobox(element) {
	if (!element) return false;
	return element.getAttribute("role") === "combobox" && isTypeableElement(element);
}
function matchesFocusVisible(element) {
	if (!element || jsdom) return true;
	try {
		return element.matches(":focus-visible");
	} catch (_e) {
		return true;
	}
}
function getFloatingFocusElement(floatingElement) {
	if (!floatingElement) return null;
	return floatingElement.hasAttribute("data-base-ui-focusable") ? floatingElement : floatingElement.querySelector(`[data-base-ui-focusable]`) || floatingElement;
}
// node_modules/@base-ui/utils/mergeCleanups.mjs
/**
* Combines multiple cleanup functions into a single cleanup function.
*/
function mergeCleanups(...cleanups) {
	return () => {
		for (let i = 0; i < cleanups.length; i += 1) {
			const cleanup = cleanups[i];
			if (cleanup) cleanup();
		}
	};
}
// node_modules/@base-ui/utils/useValueAsRef.mjs
/**
* Untracks the provided value by turning it into a ref to remove its reactivity.
*
* Used to access the passed value inside `React.useEffect` without causing the effect to re-run when the value changes.
*/
function useValueAsRef(value) {
	const latest = useRefWithInit(createLatestRef, value).current;
	latest.next = value;
	useIsoLayoutEffect(latest.effect);
	return latest;
}
function createLatestRef(value) {
	const latest = {
		current: value,
		next: value,
		effect: () => {
			latest.current = latest.next;
		}
	};
	return latest;
}
// node_modules/@base-ui/react/utils/FocusGuard.mjs
/**
* @internal
*/
var FocusGuard = /*#__PURE__*/ import_react.forwardRef(function FocusGuard(props, ref) {
	const [role, setRole] = import_react.useState();
	useIsoLayoutEffect(() => {
		if (voiceOver && webkit) setRole("button");
	}, []);
	const restProps = {
		tabIndex: 0,
		role
	};
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)("span", {
		...props,
		ref,
		style: visuallyHidden,
		"aria-hidden": role ? void 0 : true,
		...restProps,
		"data-base-ui-focus-guard": ""
	});
});
FocusGuard.displayName = "FocusGuard";
// node_modules/@base-ui/react/floating-ui-react/utils/tabbable.mjs
var CANDIDATE_SELECTOR = "a[href],button,input,select,textarea,summary,details,iframe,object,embed,[tabindex],[contenteditable]:not([contenteditable=\"false\"]),audio[controls],video[controls]";
function getParentElement(element) {
	const assignedSlot = element.assignedSlot;
	if (assignedSlot) return assignedSlot;
	if (element.parentElement) return element.parentElement;
	const rootNode = element.getRootNode();
	return isShadowRoot(rootNode) ? rootNode.host : null;
}
function getDetailsSummary(details) {
	for (const child of Array.from(details.children)) if (getNodeName(child) === "summary") return child;
	return null;
}
function isWithinOpenDetailsSummary(element, details) {
	const summary = getDetailsSummary(details);
	return !!summary && (element === summary || contains(summary, element));
}
function isFocusableCandidate(element) {
	const nodeName = element ? getNodeName(element) : "";
	return element != null && element.matches(CANDIDATE_SELECTOR) && (nodeName !== "summary" || element.parentElement != null && getNodeName(element.parentElement) === "details" && getDetailsSummary(element.parentElement) === element) && (nodeName !== "details" || getDetailsSummary(element) == null) && (nodeName !== "input" || element.type !== "hidden");
}
function isFocusableElement(element) {
	if (!isFocusableCandidate(element) || !element.isConnected || element.matches(":disabled")) return false;
	for (let current = element; current; current = getParentElement(current)) {
		const isAncestor = current !== element;
		const isSlot = getNodeName(current) === "slot";
		if (current.hasAttribute("inert")) return false;
		if (isAncestor && getNodeName(current) === "details" && !current.open && !isWithinOpenDetailsSummary(element, current) || current.hasAttribute("hidden") || !isSlot && !isVisibleInTabbableTree(current, isAncestor)) return false;
	}
	return true;
}
function isVisibleInTabbableTree(element, isAncestor) {
	const styles = getComputedStyle(element);
	if (!isAncestor) return isElementVisible(element, styles);
	return styles.display !== "none";
}
function getTabIndex(element) {
	const tabIndex = element.tabIndex;
	if (tabIndex < 0) {
		const nodeName = getNodeName(element);
		if (nodeName === "details" || nodeName === "audio" || nodeName === "video" || isHTMLElement(element) && element.isContentEditable) return 0;
	}
	return tabIndex;
}
function getNamedRadioInput(element) {
	if (getNodeName(element) !== "input") return null;
	const input = element;
	return input.type === "radio" && input.name !== "" ? input : null;
}
function isTabbableRadio(element, candidates) {
	const input = getNamedRadioInput(element);
	if (!input) return true;
	const checkedRadio = candidates.find((candidate) => {
		const radio = getNamedRadioInput(candidate);
		return radio?.name === input.name && radio.form === input.form && radio.checked;
	});
	if (checkedRadio) return checkedRadio === input;
	return candidates.find((candidate) => {
		const radio = getNamedRadioInput(candidate);
		return radio?.name === input.name && radio.form === input.form;
	}) === input;
}
function getComposedChildren(container) {
	if (isHTMLElement(container) && getNodeName(container) === "slot") {
		const assignedElements = container.assignedElements({ flatten: true });
		if (assignedElements.length > 0) return assignedElements;
	}
	if (isHTMLElement(container) && container.shadowRoot) return Array.from(container.shadowRoot.children);
	return Array.from(container.children);
}
function appendCandidates(container, list) {
	getComposedChildren(container).forEach((child) => {
		if (isFocusableCandidate(child)) list.push(child);
		appendCandidates(child, list);
	});
}
function appendMatchingElements(container, selector, list) {
	getComposedChildren(container).forEach((child) => {
		if (isHTMLElement(child) && child.matches(selector)) list.push(child);
		appendMatchingElements(child, selector, list);
	});
}
function isTabbable(element) {
	return isFocusableElement(element) && getTabIndex(element) >= 0;
}
function focusable(container) {
	const candidates = [];
	appendCandidates(container, candidates);
	return candidates.filter(isFocusableElement);
}
function tabbable(container) {
	const candidates = focusable(container);
	return candidates.filter((element) => getTabIndex(element) >= 0 && isTabbableRadio(element, candidates));
}
function getTabbableIn(container, dir) {
	const list = tabbable(container);
	const len = list.length;
	if (len === 0) return;
	const active = activeElement(ownerDocument(container));
	const index = list.indexOf(active);
	return list[index === -1 ? dir === 1 ? 0 : len - 1 : index + dir];
}
function getNextTabbable(referenceElement) {
	return getTabbableIn(ownerDocument(referenceElement).body, 1) || referenceElement;
}
function getPreviousTabbable(referenceElement) {
	return getTabbableIn(ownerDocument(referenceElement).body, -1) || referenceElement;
}
function getTabbableNearElement(referenceElement, direction, exclude) {
	if (!referenceElement) return null;
	const list = [];
	appendCandidates(ownerDocument(referenceElement).body, list);
	const index = list.indexOf(referenceElement);
	if (index === -1) return null;
	const candidates = list.filter(isFocusableElement);
	for (let offset = 1; offset < list.length; offset += 1) {
		const element = list[(index + direction * offset + list.length) % list.length];
		if (!contains(exclude, element) && isTabbable(element) && isTabbableRadio(element, candidates)) return element;
	}
	return list[index];
}
function isOutsideEvent(event, container) {
	const containerElement = container || event.currentTarget;
	const relatedTarget = event.relatedTarget;
	return !relatedTarget || !contains(containerElement, relatedTarget);
}
function disableFocusInside(container) {
	tabbable(container).forEach((element) => {
		element.dataset.tabindex = element.getAttribute("tabindex") || "";
		element.setAttribute("tabindex", "-1");
	});
}
function enableFocusInside(container) {
	const elements = [];
	appendMatchingElements(container, "[data-tabindex]", elements);
	elements.forEach((element) => {
		const tabindex = element.dataset.tabindex;
		delete element.dataset.tabindex;
		if (tabindex) element.setAttribute("tabindex", tabindex);
		else element.removeAttribute("tabindex");
	});
}
// node_modules/@base-ui/react/floating-ui-react/utils/nodes.mjs
function getNodeChildren(nodes, id, onlyOpenChildren = true) {
	return nodes.filter((node) => node.parentId === id).flatMap((child) => [...!onlyOpenChildren || child.context?.open ? [child] : [], ...getNodeChildren(nodes, child.id, onlyOpenChildren)]);
}
function getNodeAncestors(nodes, id) {
	let allAncestors = [];
	let currentParentId = nodes.find((node) => node.id === id)?.parentId;
	while (currentParentId) {
		const currentNode = nodes.find((node) => node.id === currentParentId);
		currentParentId = currentNode?.parentId;
		if (currentNode) allAncestors = allAncestors.concat(currentNode);
	}
	return allAncestors;
}
// node_modules/@base-ui/react/floating-ui-react/utils/createAttribute.mjs
function createAttribute(name) {
	return `data-base-ui-${name}`;
}
// node_modules/@base-ui/react/internals/constants.mjs
var DISABLED_TRANSITIONS_STYLE = { style: { transition: "none" } };
var CLICK_TRIGGER_IDENTIFIER = "data-base-ui-click-trigger";
/**
* Used for dropdowns that usually strictly prefer top/bottom placements and
* use `var(--available-height)` to limit their height.
*/
var DROPDOWN_COLLISION_AVOIDANCE = { fallbackAxisSide: "none" };
/**
* Used by regular popups that usually aren't scrollable and are allowed to
* freely flip to any axis of placement.
*/
var POPUP_COLLISION_AVOIDANCE = { fallbackAxisSide: "end" };
/**
* Special visually hidden styles for the aria-owns owner element to ensure owned element
* accessibility in iOS/Safari/VoiceControl.
* The owner element is an empty span, so most of the common visually hidden styles are not needed.
* @see https://github.com/floating-ui/floating-ui/issues/3403
*/
var ownerVisuallyHidden = {
	clipPath: "inset(50%)",
	position: "fixed",
	top: 0,
	left: 0
};
// node_modules/@base-ui/react/floating-ui-react/components/FloatingPortal.mjs
var PortalContext = /*#__PURE__*/ import_react.createContext(null);
PortalContext.displayName = "PortalContext";
var usePortalContext = () => import_react.useContext(PortalContext);
var attr = createAttribute("portal");
function useFloatingPortalNode(props = {}) {
	const { ref, container: containerProp, componentProps = EMPTY_OBJECT, elementProps } = props;
	const uniqueId = useId();
	const parentPortalNode = usePortalContext()?.portalNode;
	const [containerElement, setContainerElement] = import_react.useState(null);
	const [portalNode, setPortalNode] = import_react.useState(null);
	const setPortalNodeRef = useStableCallback((node) => {
		if (node !== null) setPortalNode(node);
	});
	const containerRef = import_react.useRef(null);
	useIsoLayoutEffect(() => {
		if (containerProp === null) {
			if (containerRef.current) {
				containerRef.current = null;
				setPortalNode(null);
				setContainerElement(null);
			}
			return;
		}
		const resolvedContainer = (containerProp && (isNode(containerProp) ? containerProp : containerProp.current)) ?? parentPortalNode ?? document.body;
		if (resolvedContainer == null) {
			if (containerRef.current) {
				containerRef.current = null;
				setPortalNode(null);
				setContainerElement(null);
			}
			return;
		}
		if (containerRef.current !== resolvedContainer) {
			containerRef.current = resolvedContainer;
			setPortalNode(null);
			setContainerElement(resolvedContainer);
		}
	}, [containerProp, parentPortalNode]);
	const portalElement = useRenderElement("div", componentProps, {
		ref: [ref, setPortalNodeRef],
		props: [{
			id: uniqueId,
			[attr]: ""
		}, elementProps]
	});
	const portalSubtree = containerElement && portalElement ? /*#__PURE__*/ import_react_dom.createPortal(portalElement, containerElement) : null;
	return {
		node: portalNode,
		nodeId: /*#__PURE__*/ import_react.isValidElement(portalElement) ? portalElement.props.id : void 0,
		subtree: portalSubtree
	};
}
/**
* Portals the floating element into a given container element — by default,
* outside of the app root and into the body.
* This is necessary to ensure the floating element can appear outside any
* potential parent containers that cause clipping (such as `overflow: hidden`),
* while retaining its location in the React tree.
* @see https://floating-ui.com/docs/FloatingPortal
* @internal
*/
var FloatingPortal = /*#__PURE__*/ import_react.forwardRef(function FloatingPortal(componentProps, forwardedRef) {
	const { render, className, style, children, container, portalOwnerRole, ...elementProps } = componentProps;
	const { node: portalNode, nodeId: portalNodeId, subtree: portalSubtree } = useFloatingPortalNode({
		container,
		ref: forwardedRef,
		componentProps,
		elementProps
	});
	const beforeOutsideRef = import_react.useRef(null);
	const afterOutsideRef = import_react.useRef(null);
	const beforeInsideRef = import_react.useRef(null);
	const afterInsideRef = import_react.useRef(null);
	const [focusManagerState, setFocusManagerState] = import_react.useState(null);
	const focusInsideDisabledRef = import_react.useRef(false);
	const modal = focusManagerState?.modal;
	const open = focusManagerState?.open;
	const shouldRenderGuards = !!focusManagerState && !focusManagerState.modal && focusManagerState.open && !!portalNode;
	import_react.useEffect(() => {
		if (!portalNode || modal) return;
		function onFocus(event) {
			if (portalNode && event.relatedTarget && isOutsideEvent(event)) {
				if (event.type === "focusin") {
					if (focusInsideDisabledRef.current) {
						enableFocusInside(portalNode);
						focusInsideDisabledRef.current = false;
					}
				} else {
					disableFocusInside(portalNode);
					focusInsideDisabledRef.current = true;
				}
			}
		}
		return mergeCleanups(addEventListener(portalNode, "focusin", onFocus, true), addEventListener(portalNode, "focusout", onFocus, true));
	}, [portalNode, modal]);
	useIsoLayoutEffect(() => {
		if (!portalNode || open !== true || !focusInsideDisabledRef.current) return;
		enableFocusInside(portalNode);
		focusInsideDisabledRef.current = false;
	}, [open, portalNode]);
	const portalContextValue = import_react.useMemo(() => ({
		beforeOutsideRef,
		afterOutsideRef,
		beforeInsideRef,
		afterInsideRef,
		portalNode,
		setFocusManagerState
	}), [portalNode]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [portalSubtree, /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(PortalContext.Provider, {
		value: portalContextValue,
		children: [
			shouldRenderGuards && portalNode && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
				"data-type": "outside",
				ref: beforeOutsideRef,
				onFocus: (event) => {
					if (isOutsideEvent(event, portalNode)) beforeInsideRef.current?.focus();
					else getPreviousTabbable(focusManagerState ? focusManagerState.domReference : null)?.focus();
				}
			}),
			shouldRenderGuards && portalNode && /*#__PURE__*/ (0, import_jsx_runtime.jsx)("span", {
				role: portalOwnerRole,
				"aria-owns": portalNodeId,
				style: ownerVisuallyHidden
			}),
			portalNode && /*#__PURE__*/ import_react_dom.createPortal(children, portalNode),
			shouldRenderGuards && portalNode && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
				"data-type": "outside",
				ref: afterOutsideRef,
				onFocus: (event) => {
					if (isOutsideEvent(event, portalNode)) afterInsideRef.current?.focus();
					else {
						getNextTabbable(focusManagerState ? focusManagerState.domReference : null)?.focus();
						if (focusManagerState?.closeOnFocusOut) focusManagerState?.onOpenChange(false, createChangeEventDetails("focus-out", event.nativeEvent));
					}
				}
			})
		]
	})] });
});
FloatingPortal.displayName = "FloatingPortal";
// node_modules/@base-ui/react/floating-ui-react/utils/createEventEmitter.mjs
function createEventEmitter() {
	const map = /* @__PURE__ */ new Map();
	return {
		emit(event, data) {
			map.get(event)?.forEach((listener) => listener(data));
		},
		on(event, listener) {
			if (!map.has(event)) map.set(event, /* @__PURE__ */ new Set());
			map.get(event).add(listener);
		},
		off(event, listener) {
			map.get(event)?.delete(listener);
		}
	};
}
// node_modules/@base-ui/react/floating-ui-react/components/FloatingTreeStore.mjs
/**
* Stores and manages floating elements in a tree structure.
* This is a backing store for the `FloatingTree` component.
*/
var FloatingTreeStore = class {
	nodesRef = { current: [] };
	events = createEventEmitter();
	addNode(node) {
		this.nodesRef.current.push(node);
	}
	removeNode(node) {
		const index = this.nodesRef.current.findIndex((n) => n === node);
		if (index !== -1) this.nodesRef.current.splice(index, 1);
	}
};
// node_modules/@base-ui/react/floating-ui-react/components/FloatingTree.mjs
var FloatingNodeContext = /*#__PURE__*/ import_react.createContext(null);
FloatingNodeContext.displayName = "FloatingNodeContext";
var FloatingTreeContext = /*#__PURE__*/ import_react.createContext(null);
FloatingTreeContext.displayName = "FloatingTreeContext";
var useFloatingParentNodeId = () => import_react.useContext(FloatingNodeContext)?.id || null;
/**
* Returns the nearest floating tree context, if available.
*/
var useFloatingTree = (externalTree) => {
	const contextTree = import_react.useContext(FloatingTreeContext);
	return externalTree ?? contextTree;
};
/**
* Registers a node into the `FloatingTree`, returning its id.
* @see https://floating-ui.com/docs/FloatingTree
*/
function useFloatingNodeId(externalTree) {
	const id = useId();
	const tree = useFloatingTree(externalTree);
	const parentId = useFloatingParentNodeId();
	useIsoLayoutEffect(() => {
		if (!id) return;
		const node = {
			id,
			parentId
		};
		tree?.addNode(node);
		return () => {
			tree?.removeNode(node);
		};
	}, [
		tree,
		id,
		parentId
	]);
	return id;
}
/**
* Provides parent node context for nested floating elements.
* @see https://floating-ui.com/docs/FloatingTree
* @internal
*/
function FloatingNode(props) {
	const { children, id } = props;
	const parentId = useFloatingParentNodeId();
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingNodeContext.Provider, {
		value: import_react.useMemo(() => ({
			id,
			parentId
		}), [id, parentId]),
		children
	});
}
/**
* Provides context for nested floating elements when they are not children of
* each other on the DOM.
* This is not necessary in all cases, except when there must be explicit communication between parent and child floating elements. It is necessary for:
* - The `bubbles` option in the `useDismiss()` Hook
* - Nested virtual list navigation
* - Nested floating elements that each open on hover
* - Custom communication between parent and child floating elements
* @see https://floating-ui.com/docs/FloatingTree
* @internal
*/
function FloatingTree(props) {
	const { children, externalTree } = props;
	const tree = useRefWithInit(() => externalTree ?? new FloatingTreeStore()).current;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingTreeContext.Provider, {
		value: tree,
		children
	});
}
// node_modules/@base-ui/react/floating-ui-react/hooks/useDismiss.mjs
function alwaysFalse() {
	return false;
}
function normalizeProp(normalizable) {
	return {
		escapeKey: typeof normalizable === "boolean" ? normalizable : normalizable?.escapeKey ?? false,
		outsidePress: typeof normalizable === "boolean" ? normalizable : normalizable?.outsidePress ?? true
	};
}
/**
* Closes the floating element when a dismissal is requested — by default, when
* the user presses the `escape` key or outside of the floating element.
* @see https://floating-ui.com/docs/useDismiss
*/
function useDismiss(store, props = {}) {
	const { enabled = true, escapeKey: escapeKey$1 = true, outsidePress: outsidePressProp = true, outsidePressEvent = "sloppy", referencePress = alwaysFalse, bubbles, externalTree } = props;
	const open = store.useState("open");
	const floatingElement = store.useState("floatingElement");
	const { dataRef, events } = store.context;
	const tree = useFloatingTree(externalTree);
	const outsidePressFn = useStableCallback(typeof outsidePressProp === "function" ? outsidePressProp : () => false);
	const outsidePress$1 = typeof outsidePressProp === "function" ? outsidePressFn : outsidePressProp;
	const outsidePressEnabled = outsidePress$1 !== false;
	const getOutsidePressEventProp = useStableCallback(() => outsidePressEvent);
	const { escapeKey: escapeKeyBubbles, outsidePress: outsidePressBubbles } = normalizeProp(bubbles);
	const pressStartedInsideRef = import_react.useRef(false);
	const pressStartPreventedRef = import_react.useRef(false);
	const suppressNextOutsideClickRef = import_react.useRef(false);
	const sawPressWhileOpenRef = import_react.useRef(false);
	const isComposingRef = import_react.useRef(false);
	const currentPointerTypeRef = import_react.useRef("");
	const touchStateRef = import_react.useRef(null);
	const cancelDismissOnEndTimeout = useTimeout();
	const clearInsideReactTreeTimeout = useTimeout();
	const compositionTimeout = useTimeout();
	const clearInsideReactTree = useStableCallback(() => {
		clearInsideReactTreeTimeout.clear();
		dataRef.current.insideReactTree = false;
	});
	const hasBlockingChild = useStableCallback((bubbleKey) => {
		const nodeId = dataRef.current.floatingContext?.nodeId;
		return (tree ? getNodeChildren(tree.nodesRef.current, nodeId) : []).some((child) => child.context?.open && !child.context.dataRef.current[bubbleKey]);
	});
	const isEventWithinOwnElements = useStableCallback((event) => {
		return isEventTargetWithin(event, store.select("floatingElement")) || isEventTargetWithin(event, store.select("domReferenceElement"));
	});
	const closeOnReferencePress = useStableCallback((event) => {
		if (!referencePress()) return;
		store.setOpen(false, createChangeEventDetails(triggerPress, event.nativeEvent));
	});
	const closeOnEscapeKeyDown = useStableCallback((event) => {
		if (!open || !enabled || !escapeKey$1 || event.key !== "Escape") return;
		const native = isReactEvent(event) ? event.nativeEvent : event;
		if (isComposingRef.current || native.isComposing) return;
		if (!escapeKeyBubbles && hasBlockingChild("__escapeKeyBubbles")) return;
		const eventDetails = createChangeEventDetails(escapeKey, native);
		store.setOpen(false, eventDetails);
		if (!eventDetails.isCanceled) event.preventDefault();
		if (!escapeKeyBubbles && !eventDetails.isPropagationAllowed) event.stopPropagation();
	});
	const markInsideReactTree = useStableCallback(() => {
		dataRef.current.insideReactTree = true;
		clearInsideReactTreeTimeout.start(0, clearInsideReactTree);
	});
	const markPressStartedInsideReactTree = useStableCallback((event) => {
		if (!open || !enabled || event.button !== 0) return;
		const target = getTarget(event.nativeEvent);
		if (!contains(store.select("floatingElement"), target)) return;
		if (!pressStartedInsideRef.current) {
			pressStartedInsideRef.current = true;
			pressStartPreventedRef.current = false;
		}
	});
	const markInsidePressStartPrevented = useStableCallback((event) => {
		if (!open || !enabled) return;
		if (!(event.defaultPrevented || event.nativeEvent.defaultPrevented)) return;
		if (pressStartedInsideRef.current) pressStartPreventedRef.current = true;
	});
	import_react.useEffect(() => {
		function handleOpenChange(details) {
			if (!details.open) sawPressWhileOpenRef.current = false;
		}
		events.on("openchange", handleOpenChange);
		return () => {
			events.off("openchange", handleOpenChange);
		};
	}, [events]);
	import_react.useEffect(() => clearInsideReactTree, [clearInsideReactTree]);
	import_react.useEffect(() => {
		if (!open || !enabled) {
			if (!open) {
				sawPressWhileOpenRef.current = false;
				isComposingRef.current = false;
				currentPointerTypeRef.current = "";
				touchStateRef.current = null;
			}
			return clearInsideReactTree;
		}
		dataRef.current.__escapeKeyBubbles = escapeKeyBubbles;
		dataRef.current.__outsidePressBubbles = outsidePressBubbles;
		const preventedPressSuppressionTimeout = new Timeout();
		const doc = ownerDocument(floatingElement);
		function handleCompositionStart() {
			compositionTimeout.clear();
			isComposingRef.current = true;
		}
		function handleCompositionEnd() {
			isComposingRef.current = true;
			compositionTimeout.start(webkit ? 5 : 0, () => {
				isComposingRef.current = false;
			});
		}
		function suppressImmediateOutsideClickAfterPreventedStart() {
			suppressNextOutsideClickRef.current = true;
			preventedPressSuppressionTimeout.start(0, () => {
				suppressNextOutsideClickRef.current = false;
			});
		}
		function resetPressStartState() {
			pressStartedInsideRef.current = false;
			pressStartPreventedRef.current = false;
		}
		function getOutsidePressEvent() {
			const type = currentPointerTypeRef.current;
			const computedType = type === "pen" || !type ? "mouse" : type;
			const outsidePressEventValue = getOutsidePressEventProp();
			const resolved = typeof outsidePressEventValue === "function" ? outsidePressEventValue() : outsidePressEventValue;
			if (typeof resolved === "string") return resolved;
			return resolved[computedType];
		}
		function shouldIgnoreEvent(event) {
			const computedOutsidePressEvent = getOutsidePressEvent();
			return computedOutsidePressEvent === "intentional" && event.type !== "click" || computedOutsidePressEvent === "sloppy" && event.type === "click";
		}
		function isEventWithinFloatingTree(event) {
			const nodeId = dataRef.current.floatingContext?.nodeId;
			const targetIsInsideChildren = tree && getNodeChildren(tree.nodesRef.current, nodeId).some((node) => isEventTargetWithin(event, node.context?.elements.floating));
			return isEventWithinOwnElements(event) || targetIsInsideChildren;
		}
		function closeOnPressOutside(event) {
			if (shouldIgnoreEvent(event)) {
				if (event.type !== "click" && !isEventWithinOwnElements(event)) {
					preventedPressSuppressionTimeout.clear();
					suppressNextOutsideClickRef.current = false;
				}
				clearInsideReactTree();
				return;
			}
			if (dataRef.current.insideReactTree) {
				clearInsideReactTree();
				return;
			}
			const target = getTarget(event);
			const inertSelector = `[${createAttribute("inert")}]`;
			const targetRoot = isElement(target) ? target.getRootNode() : null;
			const markers = Array.from((isShadowRoot(targetRoot) ? targetRoot : ownerDocument(store.select("floatingElement"))).querySelectorAll(inertSelector));
			const triggers = store.context.triggerElements;
			if (target && (triggers.hasElement(target) || triggers.hasMatchingElement((trigger) => contains(trigger, target)))) return;
			let targetRootAncestor = isElement(target) ? target : null;
			while (targetRootAncestor && !isLastTraversableNode(targetRootAncestor)) {
				const nextParent = getParentNode(targetRootAncestor);
				if (isLastTraversableNode(nextParent) || !isElement(nextParent)) break;
				targetRootAncestor = nextParent;
			}
			if (markers.length && isElement(target) && !isRootElement(target) && !contains(target, store.select("floatingElement")) && markers.every((marker) => !contains(targetRootAncestor, marker))) return;
			if (isHTMLElement(target) && !("touches" in event)) {
				const lastTraversableNode = isLastTraversableNode(target);
				const style = getComputedStyle(target);
				const scrollRe = /auto|scroll/;
				const isScrollableX = lastTraversableNode || scrollRe.test(style.overflowX);
				const isScrollableY = lastTraversableNode || scrollRe.test(style.overflowY);
				const canScrollX = isScrollableX && target.clientWidth > 0 && target.scrollWidth > target.clientWidth;
				const canScrollY = isScrollableY && target.clientHeight > 0 && target.scrollHeight > target.clientHeight;
				const isRTL = style.direction === "rtl";
				const pressedVerticalScrollbar = canScrollY && (isRTL ? event.offsetX <= target.offsetWidth - target.clientWidth : event.offsetX > target.clientWidth);
				const pressedHorizontalScrollbar = canScrollX && event.offsetY > target.clientHeight;
				if (pressedVerticalScrollbar || pressedHorizontalScrollbar) return;
			}
			if (isEventWithinFloatingTree(event)) return;
			if (getOutsidePressEvent() === "intentional") {
				if (event.detail !== 0 && !isVirtualClick(event) && !sawPressWhileOpenRef.current) return;
				if (suppressNextOutsideClickRef.current) {
					preventedPressSuppressionTimeout.clear();
					suppressNextOutsideClickRef.current = false;
					return;
				}
			}
			if (typeof outsidePress$1 === "function" && !outsidePress$1(event)) return;
			if (hasBlockingChild("__outsidePressBubbles")) return;
			store.setOpen(false, createChangeEventDetails(outsidePress, event));
			clearInsideReactTree();
		}
		function handlePointerDown(event) {
			if (getOutsidePressEvent() !== "sloppy" || event.pointerType === "touch" || !store.select("open") || !enabled || isEventWithinOwnElements(event)) return;
			closeOnPressOutside(event);
		}
		function handleTouchStart(event) {
			if (getOutsidePressEvent() !== "sloppy" || !store.select("open") || !enabled || isEventWithinOwnElements(event)) return;
			const touch = event.touches[0];
			if (touch) {
				touchStateRef.current = {
					startTime: Date.now(),
					startX: touch.clientX,
					startY: touch.clientY,
					dismissOnTouchEnd: false,
					dismissOnMouseDown: true
				};
				cancelDismissOnEndTimeout.start(1e3, () => {
					if (touchStateRef.current) {
						touchStateRef.current.dismissOnTouchEnd = false;
						touchStateRef.current.dismissOnMouseDown = false;
					}
				});
			}
		}
		function addTargetEventListenerOnce(event, listener) {
			const target = getTarget(event);
			if (!target) return;
			const unsubscribe = addEventListener(target, event.type, () => {
				listener(event);
				unsubscribe();
			});
		}
		function handleTouchStartCapture(event) {
			currentPointerTypeRef.current = "touch";
			addTargetEventListenerOnce(event, handleTouchStart);
		}
		function closeOnPressOutsideCapture(event) {
			cancelDismissOnEndTimeout.clear();
			if (event.type === "pointerdown") {
				if (event.button === 0) sawPressWhileOpenRef.current = true;
				currentPointerTypeRef.current = event.pointerType;
			}
			if (event.type === "mousedown" && touchStateRef.current && !touchStateRef.current.dismissOnMouseDown) return;
			addTargetEventListenerOnce(event, (targetEvent) => {
				if (targetEvent.type === "pointerdown") handlePointerDown(targetEvent);
				else closeOnPressOutside(targetEvent);
			});
		}
		function handlePressEndCapture(event) {
			if (event.type === "pointercancel") sawPressWhileOpenRef.current = false;
			if (!pressStartedInsideRef.current) return;
			const pressStartedInsideDefaultPrevented = pressStartPreventedRef.current;
			resetPressStartState();
			if (getOutsidePressEvent() !== "intentional") return;
			if (event.type === "pointercancel") {
				if (pressStartedInsideDefaultPrevented) suppressImmediateOutsideClickAfterPreventedStart();
				return;
			}
			if (isEventWithinFloatingTree(event)) return;
			if (pressStartedInsideDefaultPrevented) {
				suppressImmediateOutsideClickAfterPreventedStart();
				return;
			}
			if (typeof outsidePress$1 === "function" && !outsidePress$1(event)) return;
			preventedPressSuppressionTimeout.clear();
			suppressNextOutsideClickRef.current = true;
			clearInsideReactTree();
		}
		function handleTouchMove(event) {
			if (getOutsidePressEvent() !== "sloppy" || !touchStateRef.current || isEventWithinOwnElements(event)) return;
			const touch = event.touches[0];
			if (!touch) return;
			const deltaX = Math.abs(touch.clientX - touchStateRef.current.startX);
			const deltaY = Math.abs(touch.clientY - touchStateRef.current.startY);
			const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
			if (distance > 5) touchStateRef.current.dismissOnTouchEnd = true;
			if (distance > 10) {
				closeOnPressOutside(event);
				cancelDismissOnEndTimeout.clear();
				touchStateRef.current = null;
			}
		}
		function handleTouchMoveCapture(event) {
			addTargetEventListenerOnce(event, handleTouchMove);
		}
		function handleTouchEnd(event) {
			if (getOutsidePressEvent() !== "sloppy" || !touchStateRef.current || isEventWithinOwnElements(event)) return;
			if (touchStateRef.current.dismissOnTouchEnd) closeOnPressOutside(event);
			cancelDismissOnEndTimeout.clear();
			touchStateRef.current = null;
		}
		function handleTouchEndCapture(event) {
			addTargetEventListenerOnce(event, handleTouchEnd);
		}
		const unsubscribe = mergeCleanups(escapeKey$1 && mergeCleanups(addEventListener(doc, "keydown", closeOnEscapeKeyDown), addEventListener(doc, "compositionstart", handleCompositionStart), addEventListener(doc, "compositionend", handleCompositionEnd)), outsidePressEnabled && mergeCleanups(addEventListener(doc, "click", closeOnPressOutsideCapture, true), addEventListener(doc, "pointerdown", closeOnPressOutsideCapture, true), addEventListener(doc, "pointerup", handlePressEndCapture, true), addEventListener(doc, "pointercancel", handlePressEndCapture, true), addEventListener(doc, "mousedown", closeOnPressOutsideCapture, true), addEventListener(doc, "mouseup", handlePressEndCapture, true), addEventListener(doc, "touchstart", handleTouchStartCapture, {
			capture: true,
			passive: true
		}), addEventListener(doc, "touchmove", handleTouchMoveCapture, {
			capture: true,
			passive: true
		}), addEventListener(doc, "touchend", handleTouchEndCapture, {
			capture: true,
			passive: true
		})));
		return () => {
			unsubscribe();
			preventedPressSuppressionTimeout.clear();
			resetPressStartState();
			suppressNextOutsideClickRef.current = false;
		};
	}, [
		dataRef,
		floatingElement,
		escapeKey$1,
		outsidePressEnabled,
		outsidePress$1,
		open,
		enabled,
		escapeKeyBubbles,
		outsidePressBubbles,
		closeOnEscapeKeyDown,
		clearInsideReactTree,
		getOutsidePressEventProp,
		hasBlockingChild,
		isEventWithinOwnElements,
		tree,
		store,
		cancelDismissOnEndTimeout,
		compositionTimeout
	]);
	const reference = import_react.useMemo(() => ({
		onKeyDown: closeOnEscapeKeyDown,
		onPointerDown: closeOnReferencePress,
		onClick: closeOnReferencePress
	}), [closeOnEscapeKeyDown, closeOnReferencePress]);
	const floating = import_react.useMemo(() => ({
		onKeyDown: closeOnEscapeKeyDown,
		onPointerDown: markInsidePressStartPrevented,
		onMouseDown: markInsidePressStartPrevented,
		onClickCapture: markInsideReactTree,
		onMouseDownCapture(event) {
			markInsideReactTree();
			markPressStartedInsideReactTree(event);
		},
		onPointerDownCapture(event) {
			markInsideReactTree();
			markPressStartedInsideReactTree(event);
		},
		onMouseUpCapture: markInsideReactTree,
		onTouchEndCapture: markInsideReactTree,
		onTouchMoveCapture: markInsideReactTree
	}), [
		closeOnEscapeKeyDown,
		markInsideReactTree,
		markPressStartedInsideReactTree,
		markInsidePressStartPrevented
	]);
	return import_react.useMemo(() => enabled ? {
		reference,
		floating,
		trigger: reference
	} : {}, [
		enabled,
		reference,
		floating
	]);
}
// node_modules/@base-ui/react/floating-ui-react/hooks/useSyncedFloatingRootContext.mjs
/**
* Narrowed to the store members this hook uses so consumers do not need to provide
* unrelated store capabilities.
*/
/**
* Keeps the provided FloatingRootStore in sync with the provided PopupStore.
*/
function useSyncedFloatingRootContext(options) {
	const { popupStore, treatPopupAsFloatingElement = false, floatingRootContext: store, floatingId, nested, onOpenChange } = options;
	const open = popupStore.useState("open");
	const referenceElement = popupStore.useState("activeTriggerElement");
	const floatingElement = popupStore.useState(treatPopupAsFloatingElement ? "popupElement" : "positionerElement");
	const handleOpenChange = onOpenChange;
	popupStore.useSyncedValue("floatingId", floatingId);
	useIsoLayoutEffect(() => {
		const valuesToSync = {
			open,
			floatingId,
			referenceElement,
			floatingElement
		};
		if (isElement(referenceElement)) valuesToSync.domReferenceElement = referenceElement;
		if (store.state.positionReference === store.state.referenceElement) valuesToSync.positionReference = referenceElement;
		store.update(valuesToSync);
	}, [
		open,
		floatingId,
		referenceElement,
		floatingElement,
		store
	]);
	store.context.onOpenChange = handleOpenChange;
	store.context.nested = nested;
	return store;
}
// node_modules/@base-ui/react/internals/useUnmountAfterClose.mjs
/**
* Keeps a popup mounted through its closing animation and unmounts it once the animation
* finishes, unless the close cycle opted out through `preventUnmountOnClose`.
* Store-agnostic: hosts sync `mounted` and `transitionStatus` wherever they need them.
*
* @returns `forceUnmount` unmounts the popup immediately. It is a no-op once the popup is already
*   unmounted, so calling it after the automatic unmount doesn't repeat the completion callback,
*   and a call while the popup is open only takes effect if a close commits in the same batch.
*/
function useUnmountAfterClose(parameters) {
	const { open, ref, preventUnmountOnClose, setPreventUnmountOnClose: setPreventUnmountOnCloseParam, onUnmount, animateInitialOpen } = parameters;
	const setPreventUnmountOnClose = useStableCallback(setPreventUnmountOnCloseParam);
	const { mounted, setMounted, transitionStatus } = useTransitionStatus(open, false, false, animateInitialOpen);
	const preventUnmountingOnClose = open ? false : preventUnmountOnClose;
	useIsoLayoutEffect(() => {
		if (open) setPreventUnmountOnClose(false);
	}, [open, setPreventUnmountOnClose]);
	const mountedRef = import_react.useRef(mounted);
	const pendingUnmountRef = import_react.useRef(false);
	const rerender = useForcedRerendering();
	const unmount = () => {
		mountedRef.current = false;
		setMounted(false);
		onUnmount();
	};
	useIsoLayoutEffect(() => {
		mountedRef.current = mounted;
		if (pendingUnmountRef.current) {
			pendingUnmountRef.current = false;
			if (!open && mounted) unmount();
		}
	});
	const forceUnmount = useStableCallback(() => {
		if (!mountedRef.current) return;
		if (open) {
			pendingUnmountRef.current = true;
			rerender();
			return;
		}
		unmount();
	});
	useOpenChangeComplete({
		enabled: mounted && !open && !preventUnmountingOnClose,
		open,
		ref,
		onComplete() {
			if (!open) forceUnmount();
		}
	});
	return {
		mounted,
		transitionStatus,
		preventUnmountingOnClose,
		forceUnmount
	};
}
// node_modules/@base-ui/react/utils/popups/popupStoreUtils.mjs
var FOCUSABLE_POPUP_PROPS = {
	tabIndex: -1,
	[FOCUSABLE_ATTRIBUTE]: ""
};
/**
* Returns the default `initialFocus` resolver for a popup. When opened by touch it focuses the
* popup element itself to prevent the virtual keyboard from opening (required for Android
* specifically; iOS handles this automatically). Otherwise it falls back to the default behavior.
*/
function createDefaultInitialFocus(popupRef) {
	return (interactionType) => interactionType === "touch" ? popupRef.current : true;
}
/**
* The subset of a popup handle that a Root needs to bind its store to. Both the real handle classes
* and any test double satisfy it.
*/
/**
* Creates and owns a popup store on behalf of a Root part. The store is created exactly once, with
* controlled props and root state synced separately after creation. Sets up the synced floating
* root context and returns the store.
*
* @param createStore Factory that builds the store. Called exactly once, receiving the floating id
* and whether the popup is nested inside another floating element, both resolved on the first render.
* @param treatPopupAsFloatingElement Whether the popup element is passed to Floating UI as the
* floating element instead of the default positioner.
*/
function usePopupRootStore(createStore, treatPopupAsFloatingElement = false) {
	const floatingId = useId();
	const nested = useFloatingParentNodeId() != null;
	const store = useRefWithInit(() => createStore(floatingId, nested)).current;
	useSyncedFloatingRootContext({
		popupStore: store,
		treatPopupAsFloatingElement,
		floatingRootContext: store.state.floatingRootContext,
		floatingId,
		nested,
		onOpenChange: store.setOpen
	});
	return store;
}
/**
* Attaches a Root's store to a handle for this component's committed lifetime. Popup Roots render
* it before their interactions and user children so its layout effect runs before descendant layout
* effects. This lets descendants call the handle during the Root's initial commit without attaching
* during render, which would leak suspended or abandoned stores. Store subscribers are notified by
* `attachStore` in this ordinary layout phase, where React permits synchronous updates.
*
* Popup Roots must render this component only when a handle is present so handle-less Roots avoid
* mounting an extra fiber and layout effect.
*/
function PopupHandleAttachment({ handle, store }) {
	useIsoLayoutEffect(() => {
		return handle.attachStore(store);
	}, [handle, store]);
	return null;
}
function syncTriggerCount(store) {
	const triggerCount = store.context.triggerElements.size;
	if (store.select("open") && store.state.triggerCount !== triggerCount) store.set("triggerCount", triggerCount);
}
/**
* Returns a stable callback ref that registers/unregisters the trigger element in the store.
*
* Stable so a downstream ref merger that retains the callback it was first given still reaches the
* trigger's current store. The registration is tracked as a `(store, id, element)` triple, so
* unregistering targets the store the element was actually registered in.
*
* Since the callback never changes, the caller must re-run it from a layout effect keyed on
* `[store, id]` to migrate an already-registered element. That effect is also what registers the
* element in the first place when `id` only resolves after the first commit (React 17's `useId`
* fallback), because the register call made while the id is still `undefined` does nothing.
*
* @param id Id of the trigger.
* @param store The Store instance where the trigger should be registered.
*/
function useTriggerRegistration(id, store) {
	const registrationRef = import_react.useRef(null);
	return useStableCallback((element) => {
		const registration = registrationRef.current;
		if (registration !== null) {
			if (registration.element === element && registration.store === store && registration.id === id) return;
			registrationRef.current = null;
			const registeredStore = registration.store;
			if (registeredStore.context.triggerElements.getById(registration.id) === registration.element) {
				registeredStore.context.triggerElements.delete(registration.id);
				syncTriggerCount(registeredStore);
			}
		}
		if (element !== null && id !== void 0) {
			registrationRef.current = {
				store,
				id,
				element
			};
			store.context.triggerElements.add(id, element);
			syncTriggerCount(store);
		}
	});
}
function createPopupOpenState(state, open, trigger, preventUnmountOnClose = false) {
	let preventUnmountingOnClose = state.preventUnmountingOnClose;
	if (open) preventUnmountingOnClose = false;
	else if (preventUnmountOnClose) preventUnmountingOnClose = true;
	const triggerId = trigger?.id ?? null;
	let activeTriggerId = state.activeTriggerId;
	let activeTriggerElement = state.activeTriggerElement;
	if (triggerId || open) {
		activeTriggerId = triggerId;
		activeTriggerElement = trigger ?? null;
	}
	return {
		open,
		preventUnmountingOnClose,
		activeTriggerId,
		activeTriggerElement,
		openedWithoutTrigger: open ? trigger == null : state.openedWithoutTrigger
	};
}
function attachPreventUnmountOnClose(eventDetails) {
	let preventUnmountOnClose = false;
	eventDetails.preventUnmountOnClose = () => {
		preventUnmountOnClose = true;
	};
	return () => preventUnmountOnClose;
}
/**
* Runs the shared open-change sequence for a popup store: notifies `onOpenChange`,
* honors cancellation, dispatches the floating root change, maps the reason to an
* `instantType`, and commits the state update (synchronously for hover so
* `getAnimations()` observes it). Stores supply their own differences via
* `extraState` (e.g. the last change reason) and `onBeforeDispatch` (e.g. updating
* inline-rect coordinates).
*/
function applyPopupOpenChange(store, nextOpen, eventDetails, options = {}) {
	const reason = eventDetails.reason;
	const isHover = reason === triggerHover;
	const isFocusOpen = nextOpen && reason === "trigger-focus";
	const isDismissClose = !nextOpen && (reason === "trigger-press" || reason === "escape-key");
	const shouldPreventUnmountOnClose = attachPreventUnmountOnClose(eventDetails);
	store.context.onOpenChange?.(nextOpen, eventDetails);
	if (eventDetails.isCanceled) return;
	options.onBeforeDispatch?.();
	store.state.floatingRootContext.dispatchOpenChange(nextOpen, eventDetails);
	const changeState = () => {
		const popupOpenState = createPopupOpenState(store.state, nextOpen, eventDetails.trigger, shouldPreventUnmountOnClose());
		const updatedState = {
			...options.extraState,
			...popupOpenState
		};
		if (isFocusOpen) updatedState.instantType = "focus";
		else if (isDismissClose) updatedState.instantType = "dismiss";
		else if (isHover) updatedState.instantType = void 0;
		store.update(updatedState);
	};
	if (isHover) import_react_dom.flushSync(changeState);
	else changeState();
}
/**
* Sets up trigger data forwarding to the store.
*
* @param triggerId Id of the trigger.
* @param triggerElementRef Ref for the trigger DOM element.
* @param store The Store instance managing the popup state.
* @param stateUpdates An object with state updates to apply when the trigger is active.
*/
function useTriggerDataForwarding(triggerId, triggerElementRef, store, stateUpdates) {
	const isMountedByThisTrigger = store.useState("isMountedByTrigger", triggerId);
	const baseRegisterTrigger = useTriggerRegistration(triggerId, store);
	const applyTriggerData = useStableCallback((element) => {
		const open = store.select("open");
		const activeTriggerId = store.select("activeTriggerId");
		if (activeTriggerId === triggerId) {
			const changes = {
				activeTriggerElement: element,
				...open ? stateUpdates : null
			};
			store.update(changes);
			return;
		}
		if (activeTriggerId == null && open && !store.state.openedWithoutTrigger) {
			const changes = {
				activeTriggerId: triggerId ?? null,
				activeTriggerElement: element,
				...stateUpdates
			};
			store.update(changes);
		}
	});
	const registerTrigger = useStableCallback((element) => {
		baseRegisterTrigger(element);
		if (element) applyTriggerData(element);
	});
	useIsoLayoutEffect(() => {
		registerTrigger(triggerElementRef.current);
		return () => registerTrigger(null);
	}, [
		registerTrigger,
		triggerElementRef,
		store,
		triggerId
	]);
	useIsoLayoutEffect(() => {
		if (isMountedByThisTrigger) {
			const changes = {
				activeTriggerElement: triggerElementRef.current,
				...stateUpdates
			};
			store.update(changes);
		}
	}, [
		isMountedByThisTrigger,
		store,
		triggerElementRef,
		...Object.values(stateUpdates)
	]);
	return {
		registerTrigger,
		isMountedByThisTrigger
	};
}
/**
* Keeps trigger registration state synchronized while the popup is open.
*
* When a popup opens without an explicit trigger id and exactly one trigger is registered, that
* trigger is claimed as the active trigger, unless the open request deliberately carried no trigger
* (`openedWithoutTrigger`). When the active trigger id is still registered but its
* element changed, the active element is refreshed. When the active trigger id is missing from the
* registry but the same element is still registered under a different id (e.g. the rendered trigger
* carries its own DOM `id` that differs from Base UI's internal trigger id), the active id is
* reassociated to the registered id instead of being treated as lost. When the active trigger
* unregisters, the default path preserves existing ownership so non-closing popup families do not
* silently claim a different trigger while staying open.
*
* If `closeOnActiveTriggerUnmount` is enabled, unregistering a previously resolved active trigger
* requests a close after a microtask so a same-tick replacement trigger with the same id can
* register first. An active trigger id that has not matched a registered trigger yet is treated as
* pending and does not request a close.
*
* This should be called on the Root part.
*
* @param store The Store instance managing the popup state.
* @param options Options for active trigger unmount behavior.
*/
function useImplicitActiveTrigger(store, options = {}) {
	const { closeOnActiveTriggerUnmount = false } = options;
	const resolvedActiveTriggerIdRef = import_react.useRef(null);
	const open = store.useState("open");
	const reactiveTriggerCount = store.useState("triggerCount");
	const activeTriggerId = store.useState("activeTriggerId");
	const reactiveActiveTriggerElement = store.useState("activeTriggerElement");
	useIsoLayoutEffect(() => {
		if (!open) {
			resolvedActiveTriggerIdRef.current = null;
			if (store.state.triggerCount !== 0) store.set("triggerCount", 0);
			if (store.state.openedWithoutTrigger) store.set("openedWithoutTrigger", false);
			return;
		}
		const triggerCount = store.context.triggerElements.size;
		const stateUpdates = {};
		if (store.state.triggerCount !== triggerCount) stateUpdates.triggerCount = triggerCount;
		const currentActiveTriggerId = store.select("activeTriggerId");
		let lostActiveTriggerId = null;
		if (currentActiveTriggerId) {
			const activeTriggerElement = store.context.triggerElements.getById(currentActiveTriggerId);
			if (!activeTriggerElement) {
				for (const [triggerId, triggerElement] of store.context.triggerElements.entries()) if (triggerElement === store.state.activeTriggerElement) {
					stateUpdates.activeTriggerId = triggerId;
					stateUpdates.activeTriggerElement = triggerElement;
					resolvedActiveTriggerIdRef.current = triggerId;
					break;
				}
				if (stateUpdates.activeTriggerId === void 0) {
					if (resolvedActiveTriggerIdRef.current === currentActiveTriggerId) lostActiveTriggerId = currentActiveTriggerId;
					else resolvedActiveTriggerIdRef.current = null;
				}
			} else {
				resolvedActiveTriggerIdRef.current = currentActiveTriggerId;
				if (activeTriggerElement !== store.state.activeTriggerElement) stateUpdates.activeTriggerElement = activeTriggerElement;
			}
		} else resolvedActiveTriggerIdRef.current = null;
		if (!lostActiveTriggerId && !currentActiveTriggerId && !store.state.openedWithoutTrigger && triggerCount === 1) {
			const iteratorResult = store.context.triggerElements.entries().next();
			if (!iteratorResult.done) {
				const [implicitTriggerId, implicitTriggerElement] = iteratorResult.value;
				stateUpdates.activeTriggerId = implicitTriggerId;
				stateUpdates.activeTriggerElement = implicitTriggerElement;
				resolvedActiveTriggerIdRef.current = implicitTriggerId;
			}
		}
		if (stateUpdates.triggerCount !== void 0 || stateUpdates.activeTriggerId !== void 0 || stateUpdates.activeTriggerElement !== void 0) store.update(stateUpdates);
		if (lostActiveTriggerId) {
			if (closeOnActiveTriggerUnmount) queueMicrotask(() => {
				if (store.select("open") && store.select("activeTriggerId") === lostActiveTriggerId && !store.context.triggerElements.getById(lostActiveTriggerId)) {
					const eventDetails = createChangeEventDetails(none);
					store.setOpen(false, eventDetails);
					if (!eventDetails.isCanceled) store.update({
						activeTriggerId: null,
						activeTriggerElement: null
					});
				}
			});
		}
	}, [
		open,
		store,
		reactiveTriggerCount,
		activeTriggerId,
		reactiveActiveTriggerElement,
		closeOnActiveTriggerUnmount
	]);
}
/**
* Manages the mounted state of the popup.
* Sets up the transition status listeners and handles unmounting when needed.
* Updates the `mounted`, `transitionStatus`, and `preventUnmountingOnClose` states in the store.
*
* @param open Whether the popup is open.
* @param store The Store instance managing the popup state.
* @param onUnmount Optional callback to be called when the popup is unmounted.
* @param animateInitialOpen Whether a popup that mounts already open should still play its enter
*   transition. Defaults to `false`, so content that was open on the first render (a `defaultOpen`
*   popup on page load, SSR'd markup) appears without animating. Opt in for popups whose subtree
*   only mounts in response to something the user did, such as a submenu inside a menu popup.
*
* @returns A function to forcibly unmount the popup. It is a no-op once the popup is already
*   unmounted, so calling it after the automatic unmount doesn't repeat the completion callback.
*/
function useOpenStateTransitions(open, store, onUnmount, animateInitialOpen) {
	const { mounted, transitionStatus, forceUnmount } = useUnmountAfterClose({
		open,
		ref: store.context.popupRef,
		preventUnmountOnClose: store.useState("preventUnmountingOnClose"),
		setPreventUnmountOnClose: (preventUnmountOnClose) => store.set("preventUnmountingOnClose", preventUnmountOnClose),
		animateInitialOpen,
		onUnmount() {
			store.update({
				activeTriggerId: null,
				activeTriggerElement: null,
				mounted: false,
				preventUnmountingOnClose: false
			});
			onUnmount?.();
			store.context.onOpenChangeComplete?.(false);
		}
	});
	useRefWithInit(() => {
		store.set("mounted", mounted);
		return null;
	});
	store.useSyncedValues({
		mounted,
		transitionStatus
	});
	return {
		forceUnmount,
		transitionStatus
	};
}
function usePopupInteractionProps(store, statePart) {
	store.useSyncedValues(statePart);
	useIsoLayoutEffect(() => () => {
		store.update({
			activeTriggerProps: EMPTY_OBJECT,
			inactiveTriggerProps: EMPTY_OBJECT,
			popupProps: EMPTY_OBJECT
		});
	}, [store]);
}
function usePopupRootSync(store, open) {
	useIsoLayoutEffect(() => {
		if (!open && store.state.openMethod !== null) store.set("openMethod", null);
	}, [open, store]);
	useIsoLayoutEffect(() => () => {
		if (store.state.openMethod !== null) store.set("openMethod", null);
	}, [store]);
}
// node_modules/@base-ui/react/utils/popups/popupTriggerMap.mjs
/**
* Development-only reverse index of element to registered id, keyed by the owning map.
*
* Registration would otherwise have to scan every entry to detect an element claimed by two ids,
* making the mount of many triggers sharing one handle quadratic. Kept module-scoped, lazily
* initialized, and read only from `process.env.NODE_ENV` guards so production builds drop it along
* with the checks.
*/
var devElementIdsByMap;
function getDevElementIds(map) {
	devElementIdsByMap ??= /* @__PURE__ */ new WeakMap();
	let elementIds = devElementIdsByMap.get(map);
	if (!elementIds) {
		elementIds = /* @__PURE__ */ new WeakMap();
		devElementIdsByMap.set(map, elementIds);
	}
	return elementIds;
}
/**
* Data structure to keep track of popup trigger elements by their IDs.
*
* Element lookups iterate the id map rather than maintaining a parallel Set. Registration is O(1),
* while `hasElement` and `hasMatchingElement` are linear in the number of triggers.
*/
var PopupTriggerMap = class {
	idMap = /* @__PURE__ */ new Map();
	/**
	* Adds a trigger element with the given ID.
	*
	* Note: The provided element is assumed to not be registered under multiple IDs.
	*/
	add(id, element) {
		{
			const elementIds = getDevElementIds(this);
			const existingId = elementIds.get(element);
			if (existingId !== void 0 && existingId !== id) throw new Error("Base UI: A trigger element cannot be registered under multiple IDs in PopupTriggerMap.");
			const previousElement = this.idMap.get(id);
			if (previousElement !== void 0 && previousElement !== element) elementIds.delete(previousElement);
			elementIds.set(element, id);
		}
		this.idMap.set(id, element);
	}
	/**
	* Removes the trigger element with the given ID.
	*/
	delete(id) {
		{
			const element = this.idMap.get(id);
			if (element !== void 0) devElementIdsByMap?.get(this)?.delete(element);
		}
		this.idMap.delete(id);
	}
	/**
	* Whether the given element is registered as a trigger.
	*/
	hasElement(element) {
		for (const registered of this.idMap.values()) if (registered === element) return true;
		return false;
	}
	/**
	* Whether there is a registered trigger element matching the given predicate.
	*/
	hasMatchingElement(predicate) {
		for (const element of this.idMap.values()) if (predicate(element)) return true;
		return false;
	}
	/**
	* Returns the trigger element associated with the given ID, or undefined if no such element exists.
	*/
	getById(id) {
		return this.idMap.get(id);
	}
	/**
	* Returns an iterable of all registered trigger entries, where each entry is a tuple of [id, element].
	*/
	entries() {
		return this.idMap.entries();
	}
	/**
	* Returns an iterable of all registered trigger elements.
	*/
	elements() {
		return this.idMap.values();
	}
	/**
	* Returns the number of registered trigger elements.
	*/
	get size() {
		return this.idMap.size;
	}
};
// node_modules/@base-ui/utils/fastHooks.mjs
var import_shim = require_shim();
var import_with_selector = require_with_selector();
var hooks = [];
var currentInstance = void 0;
function getInstance() {
	return currentInstance;
}
function register(hook) {
	hooks.push(hook);
}
/**
* Wraps a component function to enable performance optimizations for internal hooks.
*
* **Performance Optimization:**
* Components wrapped with `fastComponent` have access to a shared "instance" context that enables
* specialized hook implementations to batch operations and reduce overhead. The wrapper creates a
* stable instance object that persists across renders, sets it as the current context, calls
* registered hooks before and after rendering, then clears the context. The primary benefit is
* with `useStore`, where multiple store subscriptions within the same component are collapsed into
* a single `useSyncExternalStore` subscription per store, significantly reducing re-render overhead.
* This optimization is only active on React 19+; on earlier versions `useStore` falls back to a
* separate subscription per call.
*
* **Requirements:**
* - The component function should follow standard React component patterns
* - `useStore` calls must keep a stable order and count across renders, as batched hooks are
*   matched by call index
* - Do not rely on the instance context outside of specialized hooks
*
* @param fn - The component function to wrap
* @returns A wrapped component with the same signature as the input function
*
* @example
* ```tsx
* // Wrapping a component to enable optimized useStore batching
* export const TooltipRoot = fastComponent(function TooltipRoot(props) {
*   // These useStore calls share a single subscription
*   const open = useStore(store, (state) => state.open);
*   const disabled = useStore(store, (state) => state.disabled);
*   const value = useStore(store, (state) => state.value);
*   // ...
* });
* ```
*/
function fastComponent(fn) {
	const FastComponent = (props, forwardedRef) => {
		const instance = useRefWithInit(createInstance).current;
		let result;
		try {
			currentInstance = instance;
			for (const hook of hooks) hook.before(instance);
			result = fn(props, forwardedRef);
			for (const hook of hooks) hook.after(instance);
			instance.didInitialize = true;
		} finally {
			currentInstance = void 0;
		}
		return result;
	};
	FastComponent.displayName = fn.displayName || fn.name;
	return FastComponent;
}
/**
* Wraps a component function with ref forwarding to enable performance optimizations for internal hooks.
*
* This is a convenience wrapper that combines `fastComponent` with `React.forwardRef`, enabling
* both performance optimizations and proper ref forwarding. See `fastComponent` for details on
* the performance benefits.
*
* @param fn - The component function that accepts props and a forwarded ref
* @returns A wrapped component with ref forwarding enabled
*
* @example
* ```tsx
* // Wrapping a component with ref forwarding and optimized hooks
* export const TooltipTrigger = fastComponentRef(function TooltipTrigger(
*   props,
*   forwardedRef
* ) {
*   const store = useContext(TooltipContext);
*   const open = useStore(store, (state) => state.open);
*   // ... component logic with ref
*   return <button ref={forwardedRef} {...props} />;
* });
* ```
*/
function fastComponentRef(fn) {
	return /*#__PURE__*/ import_react.forwardRef(fastComponent(fn));
}
function createInstance() {
	return { didInitialize: false };
}
// node_modules/@base-ui/utils/store/useStore.mjs
var useStoreImplementation = isReactVersionAtLeast(19) ? useStoreFast : useStoreLegacy;
function useStore(store, selector, a1, a2, a3) {
	return useStoreImplementation(store, selector, a1, a2, a3);
}
function useStoreR19(store, selector, a1, a2, a3) {
	const getSelection = import_react.useCallback(() => selector(store.getSnapshot(), a1, a2, a3), [
		store,
		selector,
		a1,
		a2,
		a3
	]);
	return (0, import_shim.useSyncExternalStore)(store.subscribe, getSelection, getSelection);
}
register({
	before(instance) {
		instance.syncIndex = 0;
		if (!instance.didInitialize) {
			instance.syncTick = 1;
			instance.syncHooks = [];
			instance.didChangeStore = true;
			instance.getSnapshot = () => {
				let didChange = false;
				for (let i = 0; i < instance.syncHooks.length; i += 1) {
					const hook = instance.syncHooks[i];
					const value = hook.selector(hook.store.state, hook.a1, hook.a2, hook.a3);
					if (!Object.is(hook.value, value)) {
						didChange = true;
						hook.value = value;
					}
				}
				if (didChange) instance.syncTick += 1;
				return instance.syncTick;
			};
		}
	},
	after(instance) {
		if (instance.syncHooks.length > 0) {
			if (instance.didChangeStore) {
				instance.didChangeStore = false;
				instance.subscribe = (onStoreChange) => {
					const stores = /* @__PURE__ */ new Set();
					for (const hook of instance.syncHooks) stores.add(hook.store);
					const unsubscribes = [];
					for (const store of stores) unsubscribes.push(store.subscribe(onStoreChange));
					return () => {
						for (const unsubscribe of unsubscribes) unsubscribe();
					};
				};
			}
			(0, import_shim.useSyncExternalStore)(instance.subscribe, instance.getSnapshot, instance.getSnapshot);
		}
	}
});
function useStoreFast(store, selector, a1, a2, a3) {
	const instance = getInstance();
	if (!instance) return useStoreR19(store, selector, a1, a2, a3);
	const index = instance.syncIndex;
	instance.syncIndex += 1;
	let hook;
	if (!instance.didInitialize) {
		hook = {
			store,
			selector,
			a1,
			a2,
			a3,
			value: selector(store.getSnapshot(), a1, a2, a3)
		};
		instance.syncHooks.push(hook);
	} else {
		hook = instance.syncHooks[index];
		if (hook.store !== store || hook.selector !== selector || !Object.is(hook.a1, a1) || !Object.is(hook.a2, a2) || !Object.is(hook.a3, a3)) {
			if (hook.store !== store) instance.didChangeStore = true;
			hook.store = store;
			hook.selector = selector;
			hook.a1 = a1;
			hook.a2 = a2;
			hook.a3 = a3;
			hook.value = selector(store.getSnapshot(), a1, a2, a3);
		}
	}
	return hook.value;
}
function useStoreLegacy(store, selector, a1, a2, a3) {
	return (0, import_with_selector.useSyncExternalStoreWithSelector)(store.subscribe, store.getSnapshot, store.getSnapshot, (state) => selector(state, a1, a2, a3));
}
// node_modules/@base-ui/utils/store/Store.mjs
/**
* A data store implementation that allows subscribing to state changes and updating the state.
* It uses an observer pattern to notify subscribers when the state changes.
*/
var Store = class {
	/**
	* Creates a store with the given initial state, constructing the class it is called on.
	* Calling it on a generic base class (e.g. `ReactStore.create(...)`) constructs that
	* class but degrades the inferred instance type to `Store`; use `new` there instead.
	*/
	static create(state) {
		return new this(state);
	}
	/**
	* The current state of the store.
	* This property is updated immediately when the state changes as a result of calling {@link setState}, {@link update}, or {@link set}.
	* To subscribe to state changes, use the {@link useState} method. The value returned by {@link useState} is updated after the component renders (similarly to React's useState).
	* The values can be used directly (to avoid subscribing to the store) in effects or event handlers.
	*
	* Do not modify properties in state directly. Instead, use the provided methods to ensure proper state management and listener notification.
	*/
	constructor(state) {
		this.state = state;
		this.listeners = /* @__PURE__ */ new Set();
		this.updateTick = 0;
	}
	/**
	* Registers a listener that will be called whenever the store's state changes.
	*
	* @param fn The listener function to be called on state changes.
	* @returns A function to unsubscribe the listener.
	*/
	subscribe = (fn) => {
		this.listeners.add(fn);
		return () => {
			this.listeners.delete(fn);
		};
	};
	/**
	* Returns the current state of the store.
	*/
	getSnapshot = () => {
		return this.state;
	};
	/**
	* Updates the entire store's state and notifies all registered listeners.
	*
	* @param newState The new state to set for the store.
	*/
	setState(newState) {
		if (this.state === newState) return;
		this.state = newState;
		this.updateTick += 1;
		const currentTick = this.updateTick;
		for (const listener of this.listeners) {
			if (currentTick !== this.updateTick) return;
			listener(newState);
		}
	}
	/**
	* Merges the provided changes into the current state and notifies listeners if there are changes.
	* Each value must match its state key. Pass an exact known subset rather than a broad
	* `Partial<State>`, which may contain `undefined` for required state fields.
	*
	* @param changes An object containing the changes to apply to the current state.
	*/
	update(changes) {
		for (const key in changes) if (!Object.is(this.state[key], changes[key])) {
			this.setState({
				...this.state,
				...changes
			});
			return;
		}
	}
	/**
	* Sets a specific key in the store's state to a new value and notifies listeners if the value has changed.
	*
	* @param key The key in the store's state to update.
	* @param value The new value to set for the specified key.
	*/
	set(key, value) {
		if (!Object.is(this.state[key], value)) this.setState({
			...this.state,
			[key]: value
		});
	}
	/**
	* Gives the state a new reference and updates all registered listeners.
	*/
	notifyAll() {
		const newState = { ...this.state };
		this.setState(newState);
	}
	use(selector, a1, a2, a3) {
		return useStore(this, selector, a1, a2, a3);
	}
};
// node_modules/@base-ui/utils/store/ReactStore.mjs
/**
* A Store that supports controlled state keys, non-reactive values and provides utility methods for React.
*/
var ReactStore = class extends Store {
	/**
	* Creates a new ReactStore instance.
	*
	* @param state Initial state of the store.
	* @param context Non-reactive context values.
	* @param selectors Optional selectors for use with `useState`.
	*/
	constructor(state, context = {}, selectors) {
		super(state);
		this.context = context;
		this.selectors = selectors;
	}
	/**
	* Non-reactive values such as refs, callbacks, etc.
	*/
	/**
	* Synchronizes a single external value into the store.
	*
	* Note that the while the value in `state` is updated immediately, the value returned
	* by `useState` is updated before the next render (similarly to React's `useState`).
	*/
	useSyncedValue(key, value) {
		import_react.useDebugValue(key);
		const store = this;
		useIsoLayoutEffect(() => {
			if (store.state[key] !== value) store.set(key, value);
		}, [
			store,
			key,
			value
		]);
	}
	/**
	* Synchronizes a single external value into the store and
	* cleans it up (sets to `undefined`) on unmount.
	*
	* Note that the while the value in `state` is updated immediately, the value returned
	* by `useState` is updated before the next render (similarly to React's `useState`).
	*/
	useSyncedValueWithCleanup(key, value) {
		const store = this;
		useIsoLayoutEffect(() => {
			if (store.state[key] !== value) store.set(key, value);
			return () => {
				store.set(key, void 0);
			};
		}, [
			store,
			key,
			value
		]);
	}
	/**
	* Synchronizes multiple external values into the store.
	* Each value must match its state key. Pass an exact known subset rather than a broad
	* `Partial<State>`, which may contain `undefined` for required state fields.
	*
	* Note that the while the values in `state` are updated immediately, the values returned
	* by `useState` are updated before the next render (similarly to React's `useState`).
	*
	* @param statePart An exact subset of state fields to synchronize. Unknown keys are not accepted.
	*/
	useSyncedValues(statePart) {
		const store = this;
		{
			import_react.useDebugValue(statePart, (p) => Object.keys(p));
			const keys = import_react.useRef(Object.keys(statePart)).current;
			const nextKeys = Object.keys(statePart);
			if (keys.length !== nextKeys.length || keys.some((key, index) => key !== nextKeys[index])) console.error("ReactStore.useSyncedValues expects the same prop keys on every render. Keys should be stable.");
		}
		const dependencies = Object.values(statePart);
		useIsoLayoutEffect(() => {
			store.update(statePart);
		}, [store, ...dependencies]);
	}
	/**
	* Registers a controllable prop pair (`controlled`, `defaultValue`) for a specific key. If `controlled`
	* is non-undefined, the store's state at `key` is updated to match `controlled`.
	*/
	useControlledProp(key, controlled) {
		import_react.useDebugValue(key);
		const store = this;
		const isControlled = controlled !== void 0;
		useIsoLayoutEffect(() => {
			if (isControlled && !Object.is(store.state[key], controlled)) store.setState({
				...store.state,
				[key]: controlled
			});
		}, [
			store,
			key,
			controlled,
			isControlled
		]);
		{
			const cache = this.controlledValues ??= /* @__PURE__ */ new Map();
			if (!cache.has(key)) cache.set(key, isControlled);
			const previouslyControlled = cache.get(key);
			if (previouslyControlled !== void 0 && previouslyControlled !== isControlled) console.error(`A component is changing the ${previouslyControlled ? "" : "un"}controlled state of ${key.toString()} to be ${previouslyControlled ? "un" : ""}controlled. Elements should not switch from uncontrolled to controlled (or vice versa).`);
		}
	}
	/** Gets the current value from the store using a selector with the provided key.
	*
	* @param key Key of the selector to use.
	*/
	select(key, a1, a2, a3) {
		const selector = this.selectors[key];
		return selector(this.state, a1, a2, a3);
	}
	/**
	* Returns a value from the store's state using a selector function.
	* Used to subscribe to specific parts of the state.
	* This methods causes a rerender whenever the selected state changes.
	*
	* @param key Key of the selector to use.
	*/
	useState(key, a1, a2, a3) {
		import_react.useDebugValue(key);
		return useStore(this, this.selectors[key], a1, a2, a3);
	}
	/**
	* Wraps a function with `useStableCallback` to ensure it has a stable reference
	* and assigns it to the context.
	*
	* @param key Key of the event callback. Must be a function in the context.
	* @param fn Function to assign.
	*/
	useContextCallback(key, fn) {
		import_react.useDebugValue(key);
		const stableFunction = useStableCallback(fn ?? NOOP);
		this.context[key] = stableFunction;
	}
	/**
	* Returns a stable setter function for a specific key in the store's state.
	* It's commonly used to pass as a ref callback to React elements.
	*
	* @param key Key of the state to set.
	*/
	useStateSetter(key) {
		const ref = import_react.useRef(void 0);
		if (ref.current === void 0) ref.current = (value) => {
			this.set(key, value);
		};
		return ref.current;
	}
	/**
	* Observes changes derived from the store's selectors and calls the listener when the selected value changes.
	*
	* @param key Key of the selector to observe.
	* @param listener Listener function called when the selector result changes.
	*/
	observe(selector, listener) {
		let selectFn;
		if (typeof selector === "function") selectFn = selector;
		else selectFn = this.selectors[selector];
		let prevValue = selectFn(this.state);
		listener(prevValue, prevValue, this);
		return this.subscribe((nextState) => {
			const nextValue = selectFn(nextState);
			if (!Object.is(prevValue, nextValue)) {
				const oldValue = prevValue;
				prevValue = nextValue;
				listener(nextValue, oldValue, this);
			}
		});
	}
};
// node_modules/@base-ui/react/floating-ui-react/components/FloatingRootStore.mjs
var selectors = {
	open: (state) => state.open,
	transitionStatus: (state) => state.transitionStatus,
	domReferenceElement: (state) => state.domReferenceElement,
	referenceElement: (state) => state.positionReference ?? state.referenceElement,
	floatingElement: (state) => state.floatingElement,
	floatingId: (state) => state.floatingId
};
var FloatingRootStore = class extends ReactStore {
	constructor(options) {
		const { syncOnly, nested, onOpenChange, triggerElements, ...initialState } = options;
		super({
			...initialState,
			positionReference: initialState.referenceElement,
			domReferenceElement: initialState.referenceElement
		}, {
			onOpenChange,
			dataRef: { current: {} },
			events: createEventEmitter(),
			nested,
			triggerElements
		}, selectors);
		this.syncOnly = syncOnly;
	}
	/**
	* Syncs the event used by hover logic to distinguish hover-open from click-like interaction.
	*/
	syncOpenEvent = (newOpen, event) => {
		if (!newOpen || !this.state.open || event != null && isClickLikeEvent(event)) this.context.dataRef.current.openEvent = newOpen ? event : void 0;
	};
	/**
	* Runs the root-owned side effects for an open state change.
	*/
	dispatchOpenChange = (newOpen, eventDetails) => {
		this.syncOpenEvent(newOpen, eventDetails.event);
		const details = {
			open: newOpen,
			reason: eventDetails.reason,
			nativeEvent: eventDetails.event,
			nested: this.context.nested,
			triggerElement: eventDetails.trigger
		};
		this.context.events.emit("openchange", details);
	};
	/**
	* Emits the `openchange` event through the internal event emitter and calls the `onOpenChange` handler with the provided arguments.
	*
	* @param newOpen The new open state.
	* @param eventDetails Details about the event that triggered the open state change.
	*/
	setOpen = (newOpen, eventDetails) => {
		if (this.syncOnly) {
			this.context.onOpenChange?.(newOpen, eventDetails);
			return;
		}
		this.dispatchOpenChange(newOpen, eventDetails);
		this.context.onOpenChange?.(newOpen, eventDetails);
	};
};
export { isTypeableElement as $, useFloatingPortalNode as A, addEventListener as At, getNextTabbable as B, FloatingNode as C, stopEvent as Ct, useFloatingTree as D, android as Dt, useFloatingParentNodeId as E, webkit as Et, POPUP_COLLISION_AVOIDANCE as F, tabbable as G, getTabbableNearElement as H, createAttribute as I, mergeCleanups as J, FocusGuard as K, getNodeAncestors as L, CLICK_TRIGGER_IDENTIFIER as M, DISABLED_TRANSITIONS_STYLE as N, FloatingTreeStore as O, ios as Ot, DROPDOWN_COLLISION_AVOIDANCE as P, isTypeableCombobox as Q, getNodeChildren as R, useDismiss as S, isVirtualPointerEvent as St, useFloatingNodeId as T, voiceOver as Tt, isOutsideEvent as U, getPreviousTabbable as V, isTabbable as W, isInteractiveElement as X, getFloatingFocusElement as Y, isTargetInsideEnabledTrigger as Z, usePopupRootSync as _, ARROW_LEFT as _t, fastComponentRef as a, pressableTriggerOpenStateMapping as at, useUnmountAfterClose as b, isMouseLikePointerType as bt, PopupHandleAttachment as c, pressed as ct, createDefaultInitialFocus as d, closed as dt, matchesFocusVisible as et, createPopupOpenState as f, endingStyle as ft, usePopupRootStore as g, ARROW_DOWN as gt, usePopupInteractionProps as h, startingStyle as ht, fastComponent as i, popupTransitionStateMapping as it, usePortalContext as j, FloatingPortal as k, mac as kt, applyPopupOpenChange as l, align as lt, useOpenStateTransitions as m, side as mt, ReactStore as n, triggerDisabled as nt, PopupTriggerMap as o, triggerOpenStateMapping as ot, useImplicitActiveTrigger as p, open as pt, useValueAsRef as q, useStore as r, popupStateMapping as rt, FOCUSABLE_POPUP_PROPS as s, popupOpen$1 as st, FloatingRootStore as t, TooltipTriggerDataAttributes_exports as tt, attachPreventUnmountOnClose as u, anchorHidden as ut, useTriggerDataForwarding as v, ARROW_RIGHT as vt, FloatingTree as w, jsdom as wt, useSyncedFloatingRootContext as x, isVirtualClick as xt, useTriggerRegistration as y, ARROW_UP as yt, focusable as z };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUlBLFNBQWdCLGlCQUFpQixRQUFRLE1BQU0sVUFBVSxTQUFTO0NBQ2hFLE9BQU8saUJBQWlCLE1BQU0sVUFBVSxPQUFPO0NBQy9DLGFBQWE7RUFDWCxPQUFPLG9CQUFvQixNQUFNLFVBQVUsT0FBTztDQUNwRDtBQUNGOzs7Ozs7Ozs7Ozs7QUNDQSxTQUFTLGNBQWM7Q0FDckIsSUFBSSxPQUFPLGNBQWMsYUFDdkIsT0FBTztFQUNMLFdBQVc7RUFDWCxVQUFVO0VBQ1YsZ0JBQWdCO0NBQ2xCO0NBRXlDO0VBQ3pDLE1BQU0sU0FBUyxVQUFVO0VBQ3pCLElBQUksVUFBVSxNQUFNLFFBQVEsT0FBTyxNQUFNLEdBQ3ZDLE9BQU87R0FDTCxXQUFXLE9BQU8sT0FBTyxLQUFLLEVBQzVCLE9BQ0EsY0FDSSxHQUFHLE1BQU0sR0FBRyxTQUFTLENBQUMsQ0FBQyxLQUFLLEdBQUc7R0FDckMsVUFBVSxPQUFPLFlBQVksVUFBVSxZQUFZO0dBQ25ELGdCQUFnQixVQUFVLGtCQUFrQjtFQUM5QztDQUVKO0NBQ0EsT0FBTztFQUNMLFdBQVcsVUFBVTtFQUNyQixVQUFVLFVBQVUsWUFBWTtFQUNoQyxnQkFBZ0IsVUFBVSxrQkFBa0I7Q0FDOUM7QUFDRjtBQUNBLElBQU0sRUFDSixXQUNBLFVBQ0EsbUJBQ0UsWUFBWTtBQUNoQixJQUFhLGlCQUFpQixVQUFVLFlBQVk7QUFDcEQsSUFBYSxnQkFBZ0IsU0FBUyxZQUFZOzs7QUNyQ2xELElBQWEsTUFBTSxZQUFZLEtBQUssYUFBYSxLQUFLLGtCQUFrQixjQUFjLGlCQUFpQjs7QUFHdkcsSUFBTSxpQkFBaUI7QUFDdkIsSUFBYSxVQUFVLGtCQUFrQixrQkFBa0IsZUFBZSxTQUFTLGNBQWM7O0FBR2pHLElBQWEsTUFBTSxDQUFDLE9BQU8sY0FBYyxXQUFXLEtBQUs7QUFHbEMsY0FBYyxXQUFXLEtBQUs7QUFHaEMsQ0FBQyxXQUFXLHFCQUFxQixLQUFLLGFBQWE7O0FBR3hFLElBQWEsUUFBUSxPQUFPOzs7QUNoQjVCLElBQWEsU0FBUyxPQUFPLFFBQVEsZUFBZSxDQUFDLENBQUMsSUFBSSxXQUFXLDhCQUE4QjtBQU85RSxDQUFDLFVBQVUsZUFBZSxTQUFTLFNBQVM7QUFPNUMsQ0FBQyxVQUFVLGVBQWUsU0FBUyxPQUFPOzs7Ozs7QUNUL0QsSUFBYSxZQUFZOzs7QUNSekIsSUFBYSxRQUFRLGlCQUFpQixLQUFLLGNBQWM7OztBQ0Z6RCxTQUFnQixVQUFVLE9BQU87Q0FDL0IsTUFBTSxlQUFlO0NBQ3JCLE1BQU0sZ0JBQWdCO0FBQ3hCO0FBQ0EsU0FBZ0IsYUFBYSxPQUFPO0NBQ2xDLE9BQU8saUJBQWlCO0FBQzFCO0FBR0EsU0FBZ0IsZUFBZSxPQUFPO0NBQ3BDLElBQUksTUFBTSxnQkFBZ0IsTUFBTSxNQUFNLFdBQ3BDLE9BQU87Q0FFVCxJQUFJQSxXQUF1QixNQUFNLGFBQy9CLE9BQU8sTUFBTSxTQUFTLFdBQVcsTUFBTSxZQUFZO0NBRXJELE9BQU8sTUFBTSxXQUFXLEtBQUssQ0FBQyxNQUFNO0FBQ3RDO0FBQ0EsU0FBZ0Isc0JBQXNCLE9BQU87Q0FDM0MsSUFBSUMsT0FDRixPQUFPO0NBRVQsT0FBTyxDQUFDRCxXQUF1QixNQUFNLFVBQVUsS0FBSyxNQUFNLFdBQVcsS0FJckUsTUFBTSxTQUFTLGlCQUFpQixNQUFNLFVBQVUsS0FBSyxNQUFNLFdBQVcsS0FBSyxNQUFNLGFBQWEsS0FBSyxNQUFNLFdBQVcsS0FBSyxNQUFNLGdCQUFnQixZQUFZQSxXQUF1QixNQUFNLFlBQVksTUFFcE0sTUFBTSxRQUFRLEtBQUssTUFBTSxTQUFTLEtBQUssTUFBTSxhQUFhLEtBQUssTUFBTSxXQUFXLEtBQUssTUFBTSxnQkFBZ0I7QUFDN0c7QUFDQSxTQUFnQix1QkFBdUIsYUFBYSxRQUFRO0NBRzFELE1BQU0sU0FBUyxDQUFDLFNBQVMsS0FBSztDQUM5QixJQUFJLENBQUMsUUFDSCxPQUFPLEtBQUssSUFBSSxNQUFTO0NBRTNCLE9BQU8sT0FBTyxTQUFTLFdBQVc7QUFDcEM7QUFDQSxTQUFnQixpQkFBaUIsT0FBTztDQUN0QyxNQUFNLE9BQU8sTUFBTTtDQUNuQixPQUFPLFNBQVMsV0FBVyxTQUFTLGVBQWUsU0FBUyxhQUFhLFNBQVM7QUFDcEY7O0FDM0NBLElBQWEsc0JBQXNCO0FBR25DLElBQWEsb0JBQW9CO0FBQ2pDLElBQWEsYUFBYTtBQUMxQixJQUFhLGNBQWM7QUFDM0IsSUFBYSxXQUFXO0FBQ3hCLElBQWEsYUFBYTs7Ozs7QUNGMUIsSUFBYSxPQUFPOzs7O0FBS3BCLElBQWEsU0FBUzs7OztBQUt0QixJQUFhLGdCQUFnQkU7Ozs7QUFLN0IsSUFBYSxjQUFjQzs7OztBQUszQixJQUFhLGVBQWU7Ozs7O0FBTTVCLElBQWEsT0FBTzs7Ozs7QUFNcEIsSUFBYSxRQUFROzs7OztBQ2xDckIsSUFBYUMsY0FBWTs7OztBQUt6QixJQUFhLFVBQVU7O0FDSnZCLElBQU0sZUFBZSxHQUNsQkMsY0FBd0MsR0FDM0M7QUFDQSxJQUFNLHlCQUF5QjtFQUM1QkEsY0FBd0M7RUFDeENDLFVBQXNDO0FBQ3pDO0FBQ0EsSUFBTSxrQkFBa0IsR0FDckJDLE9BQWlDLEdBQ3BDO0FBQ0EsSUFBTSxvQkFBb0IsR0FDdkJDLFNBQW1DLEdBQ3RDO0FBQ0EsSUFBTSxxQkFBcUIsR0FDeEJDLGVBQXlDLEdBQzVDO0FBQ0EsSUFBYSwwQkFBMEIsRUFDckMsS0FBSyxPQUFPO0NBQ1YsSUFBSSxPQUNGLE9BQU87Q0FFVCxPQUFPO0FBQ1QsRUFDRjtBQUNBLElBQWEsbUNBQW1DLEVBQzlDLEtBQUssT0FBTztDQUNWLElBQUksT0FDRixPQUFPO0NBRVQsT0FBTztBQUNULEVBQ0Y7QUFDQSxJQUFhLG9CQUFvQjtDQUMvQixLQUFLLE9BQU87RUFDVixJQUFJLE9BQ0YsT0FBTztFQUVULE9BQU87Q0FDVDtDQUNBLGFBQWEsT0FBTztFQUNsQixJQUFJLE9BQ0YsT0FBTztFQUVULE9BQU87Q0FDVDtBQUNGO0FBQ0EsSUFBYSw4QkFBOEI7Q0FDekMsR0FBRztDQUNILEdBQUc7QUFDTDs7Ozs7Ozs7O0FDaERBLElBQWEsWUFBWUo7Ozs7QUFJekIsSUFBYSxrQkFBa0I7O0FDSC9CLFNBQWdCLDZCQUE2QixRQUFRLGlCQUFpQjtDQUNwRSxJQUFJLENBQUMsVUFBVSxNQUFNLEdBQ25CLE9BQU87Q0FFVCxNQUFNLGdCQUFnQjtDQUN0QixJQUFJLGdCQUFnQixXQUFXLGFBQWEsR0FDMUMsT0FBTyxDQUFDLGNBQWMsYUFBYUssZUFBNEM7Q0FFakYsS0FBSyxNQUFNLEdBQUcsWUFBWSxnQkFBZ0IsUUFBUSxHQUNoRCxJQUFJLFNBQVMsU0FBUyxhQUFhLEdBQ2pDLE9BQU8sQ0FBQyxRQUFRLGFBQWFBLGVBQTRDO0NBRzdFLE9BQU87QUFDVDtBQUNBLFNBQWdCLG9CQUFvQixPQUFPLE1BQU07Q0FDL0MsSUFBSSxRQUFRLE1BQ1YsT0FBTztDQUVULElBQUksa0JBQWtCLE9BQ3BCLE9BQU8sTUFBTSxhQUFhLENBQUMsQ0FBQyxTQUFTLElBQUk7Q0FJM0MsTUFBTSxhQUFhO0NBQ25CLE9BQU8sV0FBVyxVQUFVLFFBQVEsS0FBSyxTQUFTLFdBQVcsTUFBTTtBQUNyRTtBQUNBLFNBQWdCLGNBQWMsU0FBUztDQUNyQyxPQUFPLFFBQVEsUUFBUSxXQUFXO0FBQ3BDO0FBQ0EsU0FBZ0Isa0JBQWtCLFNBQVM7Q0FDekMsT0FBTyxjQUFjLE9BQU8sS0FBSyxRQUFRLDhIQUF5QjtBQUNwRTtBQUNBLFNBQWdCLHFCQUFxQixTQUFTO0NBQzVDLE9BQU8sUUFBUSxTQUFTLHlFQUF5RSxtQkFBbUIsS0FBSztBQUMzSDtBQUNBLFNBQWdCLG1CQUFtQixTQUFTO0NBQzFDLElBQUksQ0FBQyxTQUNILE9BQU87Q0FFVCxPQUFPLFFBQVEsYUFBYSxNQUFNLE1BQU0sY0FBYyxrQkFBa0IsT0FBTztBQUNqRjtBQUNBLFNBQWdCLG9CQUFvQixTQUFTO0NBRzNDLElBQUksQ0FBQyxXQUFXVCxPQUNkLE9BQU87Q0FFVCxJQUFJO0VBQ0YsT0FBTyxRQUFRLFFBQVEsZ0JBQWdCO0NBQ3pDLFNBQVMsSUFBSTtFQUNYLE9BQU87Q0FDVDtBQUNGO0FBQ0EsU0FBZ0Isd0JBQXdCLGlCQUFpQjtDQUN2RCxJQUFJLENBQUMsaUJBQ0gsT0FBTztDQU1ULE9BQU8sZ0JBQWdCLHFDQUFnQyxJQUFJLGtCQUFrQixnQkFBZ0IsY0FBYywwQkFBMEIsS0FBSztBQUM1STs7Ozs7QUNsRUEsU0FBZ0IsY0FBYyxHQUFHLFVBQVU7Q0FDekMsYUFBYTtFQUNYLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxTQUFTLFFBQVEsS0FBSyxHQUFHO0dBQzNDLE1BQU0sVUFBVSxTQUFTO0dBQ3pCLElBQUksU0FDRixRQUFRO0VBRVo7Q0FDRjtBQUNGOzs7Ozs7O0FDRkEsU0FBZ0IsY0FBYyxPQUFPO0NBQ25DLE1BQU0sU0FBUyxlQUFlLGlCQUFpQixLQUFLLENBQUMsQ0FBQztDQUN0RCxPQUFPLE9BQU87Q0FHZCxtQkFBbUIsT0FBTyxNQUFNO0NBQ2hDLE9BQU87QUFDVDtBQUNBLFNBQVMsZ0JBQWdCLE9BQU87Q0FDOUIsTUFBTSxTQUFTO0VBQ2IsU0FBUztFQUNULE1BQU07RUFDTixjQUFjO0dBQ1osT0FBTyxVQUFVLE9BQU87RUFDMUI7Q0FDRjtDQUNBLE9BQU87QUFDVDs7Ozs7QUNoQkEsSUFBYSxhQUEwQiwyQkFBTSxXQUFXLFNBQVMsV0FBVyxPQUFPLEtBQUs7Q0FDdEYsTUFBTSxDQUFDLE1BQU0sd0JBQWlCLFNBQVM7Q0FDdkMseUJBQXlCO0VBS3ZCLElBQUlVLGFBQW1DQyxRQUNyQyxRQUFRLFFBQVE7Q0FFcEIsR0FBRyxDQUFDLENBQUM7Q0FDTCxNQUFNLFlBQVk7RUFDaEIsVUFBVTtFQUVWO0NBQ0Y7Q0FDQSxPQUFvQiwwQ0FBSyxRQUFRO0VBQy9CLEdBQUc7RUFDRTtFQUNMLE9BQU87RUFDUCxlQUFlLE9BQU8sU0FBWTtFQUNsQyxHQUFHO0VBQ0gsNEJBQTRCO0NBQzlCLENBQUM7QUFDSCxDQUFDO0FBQzBDLFdBQVcsY0FBYzs7QUNoQ3BFLElBQU0scUJBQXFCO0FBQzNCLFNBQVMsaUJBQWlCLFNBQVM7Q0FDakMsTUFBTSxlQUFlLFFBQVE7Q0FDN0IsSUFBSSxjQUNGLE9BQU87Q0FFVCxJQUFJLFFBQVEsZUFDVixPQUFPLFFBQVE7Q0FFakIsTUFBTSxXQUFXLFFBQVEsWUFBWTtDQUNyQyxPQUFPLGFBQWEsUUFBUSxJQUFJLFNBQVMsT0FBTztBQUNsRDtBQUNBLFNBQVMsa0JBQWtCLFNBQVM7Q0FDbEMsS0FBSyxNQUFNLFNBQVMsTUFBTSxLQUFLLFFBQVEsUUFBUSxHQUM3QyxJQUFJLFlBQVksS0FBSyxNQUFNLFdBQ3pCLE9BQU87Q0FHWCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLDJCQUEyQixTQUFTLFNBQVM7Q0FDcEQsTUFBTSxVQUFVLGtCQUFrQixPQUFPO0NBQ3pDLE9BQU8sQ0FBQyxDQUFDLFlBQVksWUFBWSxXQUFXLFNBQVMsU0FBUyxPQUFPO0FBQ3ZFO0FBQ0EsU0FBUyxxQkFBcUIsU0FBUztDQUNyQyxNQUFNLFdBQVcsVUFBVSxZQUFZLE9BQU8sSUFBSTtDQUNsRCxPQUFPLFdBQVcsUUFBUSxRQUFRLFFBQVEsa0JBQWtCLE1BQU0sYUFBYSxhQUFhLFFBQVEsaUJBQWlCLFFBQVEsWUFBWSxRQUFRLGFBQWEsTUFBTSxhQUFhLGtCQUFrQixRQUFRLGFBQWEsTUFBTSxhQUFhLGFBQWEsYUFBYSxrQkFBa0IsT0FBTyxLQUFLLFVBQVUsYUFBYSxXQUFXLFFBQVEsU0FBUztBQUN4VjtBQUNBLFNBQVMsbUJBQW1CLFNBQVM7Q0FDbkMsSUFBSSxDQUFDLHFCQUFxQixPQUFPLEtBQUssQ0FBQyxRQUFRLGVBQWUsUUFBUSxRQUFRLFdBQVcsR0FDdkYsT0FBTztDQUVULEtBQUssSUFBSSxVQUFVLFNBQVMsU0FBUyxVQUFVLGlCQUFpQixPQUFPLEdBQUc7RUFDeEUsTUFBTSxhQUFhLFlBQVk7RUFDL0IsTUFBTSxTQUFTLFlBQVksT0FBTyxNQUFNO0VBQ3hDLElBQUksUUFBUSxhQUFhLE9BQU8sR0FDOUIsT0FBTztFQUVULElBQUksY0FBYyxZQUFZLE9BQU8sTUFBTSxhQUFhLENBQUMsUUFBUSxRQUFRLENBQUMsMkJBQTJCLFNBQVMsT0FBTyxLQUFLLFFBQVEsYUFBYSxRQUFRLEtBQUssQ0FBQyxVQUFVLENBQUMsd0JBQXdCLFNBQVMsVUFBVSxHQUNqTixPQUFPO0NBRVg7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLHdCQUF3QixTQUFTLFlBQVk7Q0FDcEQsTUFBTSxTQUFTLGlCQUFpQixPQUFPO0NBQ3ZDLElBQUksQ0FBQyxZQUNILE9BQU8saUJBQWlCLFNBQVMsTUFBTTtDQUV6QyxPQUFPLE9BQU8sWUFBWTtBQUM1QjtBQUNBLFNBQVMsWUFBWSxTQUFTO0NBQzVCLE1BQU0sV0FBVyxRQUFRO0NBQ3pCLElBQUksV0FBVyxHQUFHO0VBQ2hCLE1BQU0sV0FBVyxZQUFZLE9BQU87RUFDcEMsSUFBSSxhQUFhLGFBQWEsYUFBYSxXQUFXLGFBQWEsV0FBVyxjQUFjLE9BQU8sS0FBSyxRQUFRLG1CQUM5RyxPQUFPO0NBRVg7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxTQUFTLG1CQUFtQixTQUFTO0NBQ25DLElBQUksWUFBWSxPQUFPLE1BQU0sU0FDM0IsT0FBTztDQUVULE1BQU0sUUFBUTtDQUNkLE9BQU8sTUFBTSxTQUFTLFdBQVcsTUFBTSxTQUFTLEtBQUssUUFBUTtBQUMvRDtBQUNBLFNBQVMsZ0JBQWdCLFNBQVMsWUFBWTtDQUM1QyxNQUFNLFFBQVEsbUJBQW1CLE9BQU87Q0FDeEMsSUFBSSxDQUFDLE9BQ0gsT0FBTztDQUVULE1BQU0sZUFBZSxXQUFXLE1BQUssY0FBYTtFQUNoRCxNQUFNLFFBQVEsbUJBQW1CLFNBQVM7RUFDMUMsT0FBTyxPQUFPLFNBQVMsTUFBTSxRQUFRLE1BQU0sU0FBUyxNQUFNLFFBQVEsTUFBTTtDQUMxRSxDQUFDO0NBQ0QsSUFBSSxjQUNGLE9BQU8saUJBQWlCO0NBRTFCLE9BQU8sV0FBVyxNQUFLLGNBQWE7RUFDbEMsTUFBTSxRQUFRLG1CQUFtQixTQUFTO0VBQzFDLE9BQU8sT0FBTyxTQUFTLE1BQU0sUUFBUSxNQUFNLFNBQVMsTUFBTTtDQUM1RCxDQUFDLE1BQU07QUFDVDtBQUNBLFNBQVMsb0JBQW9CLFdBQVc7Q0FDdEMsSUFBSSxjQUFjLFNBQVMsS0FBSyxZQUFZLFNBQVMsTUFBTSxRQUFRO0VBQ2pFLE1BQU0sbUJBQW1CLFVBQVUsaUJBQWlCLEVBQ2xELFNBQVMsS0FDWCxDQUFDO0VBQ0QsSUFBSSxpQkFBaUIsU0FBUyxHQUM1QixPQUFPO0NBRVg7Q0FDQSxJQUFJLGNBQWMsU0FBUyxLQUFLLFVBQVUsWUFDeEMsT0FBTyxNQUFNLEtBQUssVUFBVSxXQUFXLFFBQVE7Q0FFakQsT0FBTyxNQUFNLEtBQUssVUFBVSxRQUFRO0FBQ3RDO0FBQ0EsU0FBUyxpQkFBaUIsV0FBVyxNQUFNO0NBQ3pDLG9CQUFvQixTQUFTLENBQUMsQ0FBQyxTQUFRLFVBQVM7RUFDOUMsSUFBSSxxQkFBcUIsS0FBSyxHQUM1QixLQUFLLEtBQUssS0FBSztFQUVqQixpQkFBaUIsT0FBTyxJQUFJO0NBQzlCLENBQUM7QUFDSDtBQUNBLFNBQVMsdUJBQXVCLFdBQVcsVUFBVSxNQUFNO0NBQ3pELG9CQUFvQixTQUFTLENBQUMsQ0FBQyxTQUFRLFVBQVM7RUFDOUMsSUFBSSxjQUFjLEtBQUssS0FBSyxNQUFNLFFBQVEsUUFBUSxHQUNoRCxLQUFLLEtBQUssS0FBSztFQUVqQix1QkFBdUIsT0FBTyxVQUFVLElBQUk7Q0FDOUMsQ0FBQztBQUNIO0FBQ0EsU0FBZ0IsV0FBVyxTQUFTO0NBQ2xDLE9BQU8sbUJBQW1CLE9BQU8sS0FBSyxZQUFZLE9BQU8sS0FBSztBQUNoRTtBQUNBLFNBQWdCLFVBQVUsV0FBVztDQUNuQyxNQUFNLGFBQWEsQ0FBQztDQUNwQixpQkFBaUIsV0FBVyxVQUFVO0NBQ3RDLE9BQU8sV0FBVyxPQUFPLGtCQUFrQjtBQUM3QztBQUNBLFNBQWdCLFNBQVMsV0FBVztDQUNsQyxNQUFNLGFBQWEsVUFBVSxTQUFTO0NBQ3RDLE9BQU8sV0FBVyxRQUFPLFlBQVcsWUFBWSxPQUFPLEtBQUssS0FBSyxnQkFBZ0IsU0FBUyxVQUFVLENBQUM7QUFDdkc7QUFDQSxTQUFTLGNBQWMsV0FBVyxLQUFLO0NBQ3JDLE1BQU0sT0FBTyxTQUFTLFNBQVM7Q0FDL0IsTUFBTSxNQUFNLEtBQUs7Q0FDakIsSUFBSSxRQUFRLEdBQ1Y7Q0FFRixNQUFNLFNBQVMsY0FBYyxjQUFjLFNBQVMsQ0FBQztDQUNyRCxNQUFNLFFBQVEsS0FBSyxRQUFRLE1BQU07Q0FHakMsT0FBTyxLQURXLFVBQVUsS0FBSyxRQUFRLElBQUksSUFBSSxNQUFNLElBQUksUUFBUTtBQUVyRTtBQUNBLFNBQWdCLGdCQUFnQixrQkFBa0I7Q0FDaEQsT0FBTyxjQUFjLGNBQWMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSztBQUNuRTtBQUNBLFNBQWdCLG9CQUFvQixrQkFBa0I7Q0FDcEQsT0FBTyxjQUFjLGNBQWMsZ0JBQWdCLENBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSztBQUNwRTtBQUNBLFNBQWdCLHVCQUF1QixrQkFBa0IsV0FBVyxTQUFTO0NBQzNFLElBQUksQ0FBQyxrQkFDSCxPQUFPO0NBSVQsTUFBTSxPQUFPLENBQUM7Q0FDZCxpQkFBaUIsY0FBYyxnQkFBZ0IsQ0FBQyxDQUFDLE1BQU0sSUFBSTtDQUMzRCxNQUFNLFFBQVEsS0FBSyxRQUFRLGdCQUFnQjtDQUMzQyxJQUFJLFVBQVUsSUFDWixPQUFPO0NBRVQsTUFBTSxhQUFhLEtBQUssT0FBTyxrQkFBa0I7Q0FDakQsS0FBSyxJQUFJLFNBQVMsR0FBRyxTQUFTLEtBQUssUUFBUSxVQUFVLEdBQUc7RUFDdEQsTUFBTSxVQUFVLE1BQU0sUUFBUSxZQUFZLFNBQVMsS0FBSyxVQUFVLEtBQUs7RUFDdkUsSUFBSSxDQUFDLFNBQVMsU0FBUyxPQUFPLEtBQUssV0FBVyxPQUFPLEtBQUssZ0JBQWdCLFNBQVMsVUFBVSxHQUMzRixPQUFPO0NBRVg7Q0FDQSxPQUFPLEtBQUs7QUFDZDtBQUNBLFNBQWdCLGVBQWUsT0FBTyxXQUFXO0NBQy9DLE1BQU0sbUJBQW1CLGFBQWEsTUFBTTtDQUM1QyxNQUFNLGdCQUFnQixNQUFNO0NBQzVCLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLGtCQUFrQixhQUFhO0FBQ3BFO0FBQ0EsU0FBZ0IsbUJBQW1CLFdBQVc7Q0FFNUMsU0FEa0MsU0FDbkIsQ0FBQyxDQUFDLFNBQVEsWUFBVztFQUNsQyxRQUFRLFFBQVEsV0FBVyxRQUFRLGFBQWEsVUFBVSxLQUFLO0VBQy9ELFFBQVEsYUFBYSxZQUFZLElBQUk7Q0FDdkMsQ0FBQztBQUNIO0FBQ0EsU0FBZ0Isa0JBQWtCLFdBQVc7Q0FDM0MsTUFBTSxXQUFXLENBQUM7Q0FDbEIsdUJBQXVCLFdBQVcsbUJBQW1CLFFBQVE7Q0FDN0QsU0FBUyxTQUFRLFlBQVc7RUFDMUIsTUFBTSxXQUFXLFFBQVEsUUFBUTtFQUNqQyxPQUFPLFFBQVEsUUFBUTtFQUN2QixJQUFJLFVBQ0YsUUFBUSxhQUFhLFlBQVksUUFBUTtPQUV6QyxRQUFRLGdCQUFnQixVQUFVO0NBRXRDLENBQUM7QUFDSDs7QUNoTUEsU0FBZ0IsZ0JBQWdCLE9BQU8sSUFBSSxtQkFBbUIsTUFBTTtDQUVsRSxPQUR1QixNQUFNLFFBQU8sU0FBUSxLQUFLLGFBQWEsRUFDMUMsQ0FBQyxDQUFDLFNBQVEsVUFBUyxDQUFDLEdBQUksQ0FBQyxvQkFBb0IsTUFBTSxTQUFTLE9BQU8sQ0FBQyxLQUFLLElBQUksQ0FBQyxHQUFJLEdBQUcsZ0JBQWdCLE9BQU8sTUFBTSxJQUFJLGdCQUFnQixDQUFDLENBQUM7QUFDOUo7QUFDQSxTQUFnQixpQkFBaUIsT0FBTyxJQUFJO0NBQzFDLElBQUksZUFBZSxDQUFDO0NBQ3BCLElBQUksa0JBQWtCLE1BQU0sTUFBSyxTQUFRLEtBQUssT0FBTyxFQUFFLENBQUMsRUFBRTtDQUMxRCxPQUFPLGlCQUFpQjtFQUN0QixNQUFNLGNBQWMsTUFBTSxNQUFLLFNBQVEsS0FBSyxPQUFPLGVBQWU7RUFDbEUsa0JBQWtCLGFBQWE7RUFDL0IsSUFBSSxhQUNGLGVBQWUsYUFBYSxPQUFPLFdBQVc7Q0FFbEQ7Q0FDQSxPQUFPO0FBQ1Q7O0FDakJBLFNBQWdCLGdCQUFnQixNQUFNO0NBQ3BDLE9BQU8sZ0JBQWdCO0FBQ3pCOztBQ0FBLElBQWEsNkJBQTZCLEVBQ3hDLE9BQU8sRUFDTCxZQUFZLE9BQ2QsRUFDRjtBQUNBLElBQWEsMkJBQTJCOzs7OztBQVV4QyxJQUFhLCtCQUErQixFQUMxQyxrQkFBa0IsT0FDcEI7Ozs7O0FBTUEsSUFBYSw0QkFBNEIsRUFDdkMsa0JBQWtCLE1BQ3BCOzs7Ozs7O0FBUUEsSUFBYSxzQkFBc0I7Q0FDakMsVUFBVTtDQUNWLFVBQVU7Q0FDVixLQUFLO0NBQ0wsTUFBTTtBQUNSOztBQ3JCQSxJQUFNLGdCQUE2QiwyQkFBTSxjQUFjLElBQUk7QUFDaEIsY0FBYyxjQUFjO0FBQ3ZFLElBQWEsc0NBQStCLFdBQVcsYUFBYTtBQUNwRSxJQUFNLE9BQU8sZ0JBQWdCLFFBQVE7QUFDckMsU0FBZ0Isc0JBQXNCLFFBQVEsQ0FBQyxHQUFHO0NBQ2hELE1BQU0sRUFDSixLQUNBLFdBQVcsZUFDWCxpQkFBaUIsY0FDakIsaUJBQ0U7Q0FDSixNQUFNLFdBQVcsTUFBTTtDQUV2QixNQUFNLG1CQURnQixpQkFDZSxDQUFDLEVBQUU7Q0FDeEMsTUFBTSxDQUFDLGtCQUFrQixvQ0FBNkIsU0FBUyxJQUFJO0NBQ25FLE1BQU0sQ0FBQyxZQUFZLDhCQUF1QixTQUFTLElBQUk7Q0FDdkQsTUFBTSxtQkFBbUIsbUJBQWtCLFNBQVE7RUFDakQsSUFBSSxTQUFTLE1BSVgsY0FBYyxJQUFJO0NBRXRCLENBQUM7Q0FDRCxNQUFNLDRCQUFxQixPQUFPLElBQUk7Q0FDdEMseUJBQXlCO0VBRXZCLElBQUksa0JBQWtCLE1BQU07R0FDMUIsSUFBSSxhQUFhLFNBQVM7SUFDeEIsYUFBYSxVQUFVO0lBQ3ZCLGNBQWMsSUFBSTtJQUNsQixvQkFBb0IsSUFBSTtHQUMxQjtHQUNBO0VBQ0Y7RUFDQSxNQUFNLHFCQUFxQixrQkFBa0IsT0FBTyxhQUFhLElBQUksZ0JBQWdCLGNBQWMsYUFBYSxvQkFBb0IsU0FBUztFQUM3SSxJQUFJLHFCQUFxQixNQUFNO0dBQzdCLElBQUksYUFBYSxTQUFTO0lBQ3hCLGFBQWEsVUFBVTtJQUN2QixjQUFjLElBQUk7SUFDbEIsb0JBQW9CLElBQUk7R0FDMUI7R0FDQTtFQUNGO0VBQ0EsSUFBSSxhQUFhLFlBQVksbUJBQW1CO0dBQzlDLGFBQWEsVUFBVTtHQUN2QixjQUFjLElBQUk7R0FDbEIsb0JBQW9CLGlCQUFpQjtFQUN2QztDQUNGLEdBQUcsQ0FBQyxlQUFlLGdCQUFnQixDQUFDO0NBQ3BDLE1BQU0sZ0JBQWdCLGlCQUFpQixPQUFPLGdCQUFnQjtFQUM1RCxLQUFLLENBQUMsS0FBSyxnQkFBZ0I7RUFDM0IsT0FBTyxDQUFDO0dBQ04sSUFBSTtJQUNILE9BQU87RUFDVixHQUFHLFlBQVk7Q0FDakIsQ0FBQztDQUlELE1BQU0sZ0JBQWdCLG9CQUFvQixnQkFBNkIsK0JBQVMsYUFBYSxlQUFlLGdCQUFnQixJQUFJO0NBQ2hJLE9BQU87RUFDTCxNQUFNO0VBR04sUUFBcUIsMkJBQU0sZUFBZSxhQUFhLElBQUksY0FBYyxNQUFNLEtBQUs7RUFDcEYsU0FBUztDQUNYO0FBQ0Y7Ozs7Ozs7Ozs7QUFXQSxJQUFhLGlCQUE4QiwyQkFBTSxXQUFXLFNBQVMsZUFBZSxnQkFBZ0IsY0FBYztDQUNoSCxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsVUFDQSxXQUNBLGlCQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLEVBQ0osTUFBTSxZQUNOLFFBQVEsY0FDUixTQUFTLGtCQUNQLHNCQUFzQjtFQUN4QjtFQUNBLEtBQUs7RUFDTDtFQUNBO0NBQ0YsQ0FBQztDQUNELE1BQU0sZ0NBQXlCLE9BQU8sSUFBSTtDQUMxQyxNQUFNLCtCQUF3QixPQUFPLElBQUk7Q0FDekMsTUFBTSwrQkFBd0IsT0FBTyxJQUFJO0NBQ3pDLE1BQU0sOEJBQXVCLE9BQU8sSUFBSTtDQUN4QyxNQUFNLENBQUMsbUJBQW1CLHFDQUE4QixTQUFTLElBQUk7Q0FDckUsTUFBTSxzQ0FBK0IsT0FBTyxLQUFLO0NBQ2pELE1BQU0sUUFBUSxtQkFBbUI7Q0FDakMsTUFBTSxPQUFPLG1CQUFtQjtDQUNoQyxNQUFNLHFCQUFxQixDQUFDLENBQUMscUJBQXFCLENBQUMsa0JBQWtCLFNBQVMsa0JBQWtCLFFBQVEsQ0FBQyxDQUFDO0NBRzFHLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksQ0FBQyxjQUFjLE9BQ2pCO0VBTUYsU0FBUyxRQUFRLE9BQU87R0FDdEIsSUFBSSxjQUFjLE1BQU0saUJBQWlCLGVBQWUsS0FBSyxHQUFHO0lBQzlELElBQUksTUFBTSxTQUFTLFdBQ2I7U0FBQSx1QkFBdUIsU0FBUztNQUNsQyxrQkFBa0IsVUFBVTtNQUM1Qix1QkFBdUIsVUFBVTtLQUNuQztXQUNLO0tBQ0wsbUJBQW1CLFVBQVU7S0FDN0IsdUJBQXVCLFVBQVU7SUFDbkM7R0FDRjtFQUNGO0VBSUEsT0FBTyxjQUFjLGlCQUFpQixZQUFZLFdBQVcsU0FBUyxJQUFJLEdBQUcsaUJBQWlCLFlBQVksWUFBWSxTQUFTLElBQUksQ0FBQztDQUN0SSxHQUFHLENBQUMsWUFBWSxLQUFLLENBQUM7Q0FDdEIseUJBQXlCO0VBQ3ZCLElBQUksQ0FBQyxjQUFjLFNBQVMsUUFBUSxDQUFDLHVCQUF1QixTQUMxRDtFQUlGLGtCQUFrQixVQUFVO0VBQzVCLHVCQUF1QixVQUFVO0NBQ25DLEdBQUcsQ0FBQyxNQUFNLFVBQVUsQ0FBQztDQUNyQixNQUFNLGtDQUEyQixlQUFlO0VBQzlDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNGLElBQUksQ0FBQyxVQUFVLENBQUM7Q0FDaEIsT0FBb0Isd0RBQVksVUFBVSxFQUN4QyxVQUFVLENBQUMsZUFBNEIsMkNBQU0sY0FBYyxVQUFVO0VBQ25FLE9BQU87RUFDUCxVQUFVO0dBQUMsc0JBQXNCLGNBQTJCLDBDQUFLLFlBQVk7SUFDM0UsYUFBYTtJQUNiLEtBQUs7SUFDTCxVQUFTLFVBQVM7S0FDaEIsSUFBSSxlQUFlLE9BQU8sVUFBVSxHQUNsQyxnQkFBZ0IsU0FBUyxNQUFNO1VBSS9CLG9CQUZxQixvQkFBb0Isa0JBQWtCLGVBQWUsSUFFL0QsQ0FBQyxFQUFFLE1BQU07SUFFeEI7R0FDRixDQUFDO0dBQUcsc0JBQXNCLGNBQTJCLDBDQUFLLFFBQVE7SUFDaEUsTUFBTTtJQUNOLGFBQWE7SUFDYixPQUFPO0dBQ1QsQ0FBQztHQUFHLGNBQTJCLCtCQUFTLGFBQWEsVUFBVSxVQUFVO0dBQUcsc0JBQXNCLGNBQTJCLDBDQUFLLFlBQVk7SUFDNUksYUFBYTtJQUNiLEtBQUs7SUFDTCxVQUFTLFVBQVM7S0FDaEIsSUFBSSxlQUFlLE9BQU8sVUFBVSxHQUNsQyxlQUFlLFNBQVMsTUFBTTtVQUN6QjtNQUdMLGdCQUZxQixvQkFBb0Isa0JBQWtCLGVBQWUsSUFFL0QsQ0FBQyxFQUFFLE1BQU07TUFDcEIsSUFBSSxtQkFBbUIsaUJBQ3JCLG1CQUFtQixhQUFhLE9BQU8seUJBQXlCLGFBQWtCLE1BQU0sV0FBVyxDQUFDO0tBRXhHO0lBQ0Y7R0FDRixDQUFDO0VBQUM7Q0FDSixDQUFDLENBQUMsRUFDSixDQUFDO0FBQ0gsQ0FBQztBQUMwQyxlQUFlLGNBQWM7O0FDbE54RSxTQUFnQixxQkFBcUI7Q0FDbkMsTUFBTSxzQkFBTSxJQUFJLElBQUk7Q0FDcEIsT0FBTztFQUNMLEtBQUssT0FBTyxNQUFNO0dBQ2hCLElBQUksSUFBSSxLQUFLLENBQUMsRUFBRSxTQUFRLGFBQVksU0FBUyxJQUFJLENBQUM7RUFDcEQ7RUFDQSxHQUFHLE9BQU8sVUFBVTtHQUNsQixJQUFJLENBQUMsSUFBSSxJQUFJLEtBQUssR0FDaEIsSUFBSSxJQUFJLHVCQUFPLElBQUksSUFBSSxDQUFDO0dBRTFCLElBQUksSUFBSSxLQUFLLENBQUMsQ0FBQyxJQUFJLFFBQVE7RUFDN0I7RUFDQSxJQUFJLE9BQU8sVUFBVTtHQUNuQixJQUFJLElBQUksS0FBSyxDQUFDLEVBQUUsT0FBTyxRQUFRO0VBQ2pDO0NBQ0Y7QUFDRjs7Ozs7O0FDVkEsSUFBYSxvQkFBYixNQUErQjtDQUM3QixXQUFXLEVBQ1QsU0FBUyxDQUFDLEVBQ1o7Q0FDQSxTQUFTLG1CQUFtQjtDQUM1QixRQUFRLE1BQU07RUFDWixLQUFLLFNBQVMsUUFBUSxLQUFLLElBQUk7Q0FDakM7Q0FDQSxXQUFXLE1BQU07RUFDZixNQUFNLFFBQVEsS0FBSyxTQUFTLFFBQVEsV0FBVSxNQUFLLE1BQU0sSUFBSTtFQUM3RCxJQUFJLFVBQVUsSUFDWixLQUFLLFNBQVMsUUFBUSxPQUFPLE9BQU8sQ0FBQztDQUV6QztBQUNGOztBQ1pBLElBQU0sc0JBQW1DLDJCQUFNLGNBQWMsSUFBSTtBQUN0QixvQkFBb0IsY0FBYztBQUM3RSxJQUFNLHNCQUFtQywyQkFBTSxjQUFjLElBQUk7QUFNdEIsb0JBQW9CLGNBQWM7QUFDN0UsSUFBYSw2Q0FBc0MsV0FBVyxtQkFBbUIsQ0FBQyxFQUFFLE1BQU07Ozs7QUFLMUYsSUFBYSxtQkFBa0IsaUJBQWdCO0NBQzdDLE1BQU0sMkJBQW9CLFdBQVcsbUJBQW1CO0NBQ3hELE9BQU8sZ0JBQWdCO0FBQ3pCOzs7OztBQU1BLFNBQWdCLGtCQUFrQixjQUFjO0NBQzlDLE1BQU0sS0FBSyxNQUFNO0NBQ2pCLE1BQU0sT0FBTyxnQkFBZ0IsWUFBWTtDQUN6QyxNQUFNLFdBQVcsd0JBQXdCO0NBQ3pDLHlCQUF5QjtFQUN2QixJQUFJLENBQUMsSUFDSDtFQUVGLE1BQU0sT0FBTztHQUNYO0dBQ0E7RUFDRjtFQUNBLE1BQU0sUUFBUSxJQUFJO0VBQ2xCLGFBQWE7R0FDWCxNQUFNLFdBQVcsSUFBSTtFQUN2QjtDQUNGLEdBQUc7RUFBQztFQUFNO0VBQUk7Q0FBUSxDQUFDO0NBQ3ZCLE9BQU87QUFDVDs7Ozs7O0FBTUEsU0FBZ0IsYUFBYSxPQUFPO0NBQ2xDLE1BQU0sRUFDSixVQUNBLE9BQ0U7Q0FDSixNQUFNLFdBQVcsd0JBQXdCO0NBQ3pDLE9BQW9CLDBDQUFLLG9CQUFvQixVQUFVO0VBQ3JELG9CQUFhLGVBQWU7R0FDMUI7R0FDQTtFQUNGLElBQUksQ0FBQyxJQUFJLFFBQVEsQ0FBQztFQUNSO0NBQ1osQ0FBQztBQUNIOzs7Ozs7Ozs7Ozs7QUFZQSxTQUFnQixhQUFhLE9BQU87Q0FDbEMsTUFBTSxFQUNKLFVBQ0EsaUJBQ0U7Q0FDSixNQUFNLE9BQU8scUJBQXFCLGdCQUFnQixJQUFJLGtCQUFrQixDQUFDLENBQUMsQ0FBQztDQUMzRSxPQUFvQiwwQ0FBSyxvQkFBb0IsVUFBVTtFQUNyRCxPQUFPO0VBQ0c7Q0FDWixDQUFDO0FBQ0g7O0FDeEVBLFNBQVMsY0FBYztDQUNyQixPQUFPO0FBQ1Q7QUFDQSxTQUFnQixjQUFjLGNBQWM7Q0FDMUMsT0FBTztFQUNMLFdBQVcsT0FBTyxpQkFBaUIsWUFBWSxlQUFlLGNBQWMsYUFBYTtFQUN6RixjQUFjLE9BQU8saUJBQWlCLFlBQVksZUFBZSxjQUFjLGdCQUFnQjtDQUNqRztBQUNGOzs7Ozs7QUFNQSxTQUFnQixXQUFXLE9BQU8sUUFBUSxDQUFDLEdBQUc7Q0FDNUMsTUFBTSxFQUNKLFVBQVUsTUFDVix5QkFBWSxNQUNaLGNBQWMsbUJBQW1CLE1BQ2pDLG9CQUFvQixVQUNwQixpQkFBaUIsYUFDakIsU0FDQSxpQkFDRTtDQUNKLE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLGtCQUFrQixNQUFNLFNBQVMsaUJBQWlCO0NBQ3hELE1BQU0sRUFDSixTQUNBLFdBQ0UsTUFBTTtDQUNWLE1BQU0sT0FBTyxnQkFBZ0IsWUFBWTtDQUN6QyxNQUFNLGlCQUFpQixrQkFBa0IsT0FBTyxxQkFBcUIsYUFBYSx5QkFBeUIsS0FBSztDQUNoSCxNQUFNQyxpQkFBZSxPQUFPLHFCQUFxQixhQUFhLGlCQUFpQjtDQUMvRSxNQUFNLHNCQUFzQkEsbUJBQWlCO0NBQzdDLE1BQU0sMkJBQTJCLHdCQUF3QixpQkFBaUI7Q0FDMUUsTUFBTSxFQUNKLFdBQVcsa0JBQ1gsY0FBYyx3QkFDWixjQUFjLE9BQU87Q0FDekIsTUFBTSxxQ0FBOEIsT0FBTyxLQUFLO0NBQ2hELE1BQU0sc0NBQStCLE9BQU8sS0FBSztDQUVqRCxNQUFNLDJDQUFvQyxPQUFPLEtBQUs7Q0FHdEQsTUFBTSxvQ0FBNkIsT0FBTyxLQUFLO0NBQy9DLE1BQU0sOEJBQXVCLE9BQU8sS0FBSztDQUN6QyxNQUFNLHFDQUE4QixPQUFPLEVBQUU7Q0FDN0MsTUFBTSw2QkFBc0IsT0FBTyxJQUFJO0NBQ3ZDLE1BQU0sNEJBQTRCLFdBQVc7Q0FDN0MsTUFBTSw4QkFBOEIsV0FBVztDQUUvQyxNQUFNLHFCQUFxQixXQUFXO0NBQ3RDLE1BQU0sdUJBQXVCLHdCQUF3QjtFQUNuRCw0QkFBNEIsTUFBTTtFQUNsQyxRQUFRLFFBQVEsa0JBQWtCO0NBQ3BDLENBQUM7Q0FDRCxNQUFNLG1CQUFtQixtQkFBa0IsY0FBYTtFQUN0RCxNQUFNLFNBQVMsUUFBUSxRQUFRLGlCQUFpQjtFQUVoRCxRQURpQixPQUFPLGdCQUFnQixLQUFLLFNBQVMsU0FBUyxNQUFNLElBQUksQ0FBQyxHQUMxRCxNQUFLLFVBQVMsTUFBTSxTQUFTLFFBQVEsQ0FBQyxNQUFNLFFBQVEsUUFBUSxRQUFRLFVBQVU7Q0FDaEcsQ0FBQztDQUNELE1BQU0sMkJBQTJCLG1CQUFrQixVQUFTO0VBQzFELE9BQU8sb0JBQW9CLE9BQU8sTUFBTSxPQUFPLGlCQUFpQixDQUFDLEtBQUssb0JBQW9CLE9BQU8sTUFBTSxPQUFPLHFCQUFxQixDQUFDO0NBQ3RJLENBQUM7Q0FDRCxNQUFNLHdCQUF3QixtQkFBa0IsVUFBUztFQUN2RCxJQUFJLENBQUMsZUFBZSxHQUNsQjtFQUVGLE1BQU0sUUFBUSxPQUFPLHlCQUF5QkMsY0FBc0IsTUFBTSxXQUFXLENBQUM7Q0FDeEYsQ0FBQztDQUNELE1BQU0sdUJBQXVCLG1CQUFrQixVQUFTO0VBQ3RELElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDQyxlQUFhLE1BQU0sUUFBUSxVQUNuRDtFQUVGLE1BQU0sU0FBUyxhQUFhLEtBQUssSUFBSSxNQUFNLGNBQWM7RUFLekQsSUFBSSxlQUFlLFdBQVcsT0FBTyxhQUNuQztFQUVGLElBQUksQ0FBQyxvQkFBb0IsaUJBQWlCLG9CQUFvQixHQUM1RDtFQUVGLE1BQU0sZUFBZSx5QkFBeUJDLFdBQW1CLE1BQU07RUFDdkUsTUFBTSxRQUFRLE9BQU8sWUFBWTtFQUNqQyxJQUFJLENBQUMsYUFBYSxZQUNoQixNQUFNLGVBQWU7RUFFdkIsSUFBSSxDQUFDLG9CQUFvQixDQUFDLGFBQWEsc0JBQ3JDLE1BQU0sZ0JBQWdCO0NBRTFCLENBQUM7Q0FDRCxNQUFNLHNCQUFzQix3QkFBd0I7RUFDbEQsUUFBUSxRQUFRLGtCQUFrQjtFQUNsQyw0QkFBNEIsTUFBTSxHQUFHLG9CQUFvQjtDQUMzRCxDQUFDO0NBQ0QsTUFBTSxrQ0FBa0MsbUJBQWtCLFVBQVM7RUFDakUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLE1BQU0sV0FBVyxHQUN4QztFQUVGLE1BQU0sU0FBUyxVQUFVLE1BQU0sV0FBVztFQUkxQyxJQUFJLENBQUMsU0FBUyxNQUFNLE9BQU8saUJBQWlCLEdBQUcsTUFBTSxHQUNuRDtFQUVGLElBQUksQ0FBQyxzQkFBc0IsU0FBUztHQUNsQyxzQkFBc0IsVUFBVTtHQUNoQyx1QkFBdUIsVUFBVTtFQUNuQztDQUNGLENBQUM7Q0FDRCxNQUFNLGdDQUFnQyxtQkFBa0IsVUFBUztFQUMvRCxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQ1o7RUFFRixJQUFJLEVBQUUsTUFBTSxvQkFBb0IsTUFBTSxZQUFZLG1CQUNoRDtFQUVGLElBQUksc0JBQXNCLFNBQ3hCLHVCQUF1QixVQUFVO0NBRXJDLENBQUM7Q0FJRCxhQUFNLGdCQUFnQjtFQUNwQixTQUFTLGlCQUFpQixTQUFTO0dBR2pDLElBQUksQ0FBQyxRQUFRLE1BQ1gscUJBQXFCLFVBQVU7RUFFbkM7RUFDQSxPQUFPLEdBQUcsY0FBYyxnQkFBZ0I7RUFDeEMsYUFBYTtHQUNYLE9BQU8sSUFBSSxjQUFjLGdCQUFnQjtFQUMzQztDQUNGLEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FJWCxhQUFNLGdCQUFnQixzQkFBc0IsQ0FBQyxvQkFBb0IsQ0FBQztDQUNsRSxhQUFNLGdCQUFnQjtFQUNwQixJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVM7R0FHckIsSUFBSSxDQUFDLE1BQU07SUFDVCxxQkFBcUIsVUFBVTtJQUMvQixlQUFlLFVBQVU7SUFDekIsc0JBQXNCLFVBQVU7SUFDaEMsY0FBYyxVQUFVO0dBQzFCO0dBQ0EsT0FBTztFQUNUO0VBQ0EsUUFBUSxRQUFRLHFCQUFxQjtFQUNyQyxRQUFRLFFBQVEsd0JBQXdCO0VBQ3hDLE1BQU0sbUNBQW1DLElBQUksUUFBUTtFQUNyRCxNQUFNLE1BQU0sY0FBYyxlQUFlO0VBQ3pDLFNBQVMseUJBQXlCO0dBQ2hDLG1CQUFtQixNQUFNO0dBQ3pCLGVBQWUsVUFBVTtFQUMzQjtFQUNBLFNBQVMsdUJBQXVCO0dBSzlCLGVBQWUsVUFBVTtHQUN6QixtQkFBbUIsTUFHbkJKLFNBQXlCLElBQUksU0FBUztJQUNwQyxlQUFlLFVBQVU7R0FDM0IsQ0FBQztFQUNIO0VBQ0EsU0FBUyxtREFBbUQ7R0FDMUQsNEJBQTRCLFVBQVU7R0FHdEMsaUNBQWlDLE1BQU0sU0FBUztJQUM5Qyw0QkFBNEIsVUFBVTtHQUN4QyxDQUFDO0VBQ0g7RUFDQSxTQUFTLHVCQUF1QjtHQUM5QixzQkFBc0IsVUFBVTtHQUNoQyx1QkFBdUIsVUFBVTtFQUNuQztFQUNBLFNBQVMsdUJBQXVCO0dBQzlCLE1BQU0sT0FBTyxzQkFBc0I7R0FDbkMsTUFBTSxlQUFlLFNBQVMsU0FBUyxDQUFDLE9BQU8sVUFBVTtHQUN6RCxNQUFNLHlCQUF5Qix5QkFBeUI7R0FDeEQsTUFBTSxXQUFXLE9BQU8sMkJBQTJCLGFBQWEsdUJBQXVCLElBQUk7R0FDM0YsSUFBSSxPQUFPLGFBQWEsVUFDdEIsT0FBTztHQUVULE9BQU8sU0FBUztFQUNsQjtFQUNBLFNBQVMsa0JBQWtCLE9BQU87R0FDaEMsTUFBTSw0QkFBNEIscUJBQXFCO0dBQ3ZELE9BQU8sOEJBQThCLGlCQUFpQixNQUFNLFNBQVMsV0FBVyw4QkFBOEIsWUFBWSxNQUFNLFNBQVM7RUFDM0k7RUFDQSxTQUFTLDBCQUEwQixPQUFPO0dBQ3hDLE1BQU0sU0FBUyxRQUFRLFFBQVEsaUJBQWlCO0dBQ2hELE1BQU0seUJBQXlCLFFBQVEsZ0JBQWdCLEtBQUssU0FBUyxTQUFTLE1BQU0sQ0FBQyxDQUFDLE1BQUssU0FBUSxvQkFBb0IsT0FBTyxLQUFLLFNBQVMsU0FBUyxRQUFRLENBQUM7R0FDOUosT0FBTyx5QkFBeUIsS0FBSyxLQUFLO0VBQzVDO0VBQ0EsU0FBUyxvQkFBb0IsT0FBTztHQUNsQyxJQUFJLGtCQUFrQixLQUFLLEdBQUc7SUFHNUIsSUFBSSxNQUFNLFNBQVMsV0FBVyxDQUFDLHlCQUF5QixLQUFLLEdBQUc7S0FDOUQsaUNBQWlDLE1BQU07S0FDdkMsNEJBQTRCLFVBQVU7SUFDeEM7SUFDQSxxQkFBcUI7SUFDckI7R0FDRjtHQUNBLElBQUksUUFBUSxRQUFRLGlCQUFpQjtJQUNuQyxxQkFBcUI7SUFDckI7R0FDRjtHQUNBLE1BQU0sU0FBUyxVQUFVLEtBQUs7R0FDOUIsTUFBTSxnQkFBZ0IsSUFBSSxnQkFBZ0IsT0FBTyxFQUFFO0dBQ25ELE1BQU0sYUFBYSxVQUFVLE1BQU0sSUFBSSxPQUFPLFlBQVksSUFBSTtHQUM5RCxNQUFNLFVBQVUsTUFBTSxNQUFNLGFBQWEsVUFBVSxJQUFJLGFBQWEsY0FBYyxNQUFNLE9BQU8saUJBQWlCLENBQUMsR0FBRyxpQkFBaUIsYUFBYSxDQUFDO0dBQ25KLE1BQU0sV0FBVyxNQUFNLFFBQVE7R0FHL0IsSUFBSSxXQUFXLFNBQVMsV0FBVyxNQUFNLEtBQUssU0FBUyxvQkFBbUIsWUFBVyxTQUFTLFNBQVMsTUFBTSxDQUFDLElBQzVHO0dBRUYsSUFBSSxxQkFBcUIsVUFBVSxNQUFNLElBQUksU0FBUztHQUN0RCxPQUFPLHNCQUFzQixDQUFDLHNCQUFzQixrQkFBa0IsR0FBRztJQUN2RSxNQUFNLGFBQWEsY0FBYyxrQkFBa0I7SUFDbkQsSUFBSSxzQkFBc0IsVUFBVSxLQUFLLENBQUMsVUFBVSxVQUFVLEdBQzVEO0lBRUYscUJBQXFCO0dBQ3ZCO0dBSUEsSUFBSSxRQUFRLFVBQVUsVUFBVSxNQUFNLEtBQUssQ0FBQyxjQUFjLE1BQU0sS0FFaEUsQ0FBQyxTQUFTLFFBQVEsTUFBTSxPQUFPLGlCQUFpQixDQUFDLEtBR2pELFFBQVEsT0FBTSxXQUFVLENBQUMsU0FBUyxvQkFBb0IsTUFBTSxDQUFDLEdBQzNEO0dBS0YsSUFBSSxjQUFjLE1BQU0sS0FBSyxFQUFFLGFBQWEsUUFBUTtJQUNsRCxNQUFNLHNCQUFzQixzQkFBc0IsTUFBTTtJQUN4RCxNQUFNLFFBQVEsaUJBQWlCLE1BQU07SUFDckMsTUFBTSxXQUFXO0lBQ2pCLE1BQU0sZ0JBQWdCLHVCQUF1QixTQUFTLEtBQUssTUFBTSxTQUFTO0lBQzFFLE1BQU0sZ0JBQWdCLHVCQUF1QixTQUFTLEtBQUssTUFBTSxTQUFTO0lBQzFFLE1BQU0sYUFBYSxpQkFBaUIsT0FBTyxjQUFjLEtBQUssT0FBTyxjQUFjLE9BQU87SUFDMUYsTUFBTSxhQUFhLGlCQUFpQixPQUFPLGVBQWUsS0FBSyxPQUFPLGVBQWUsT0FBTztJQUM1RixNQUFNLFFBQVEsTUFBTSxjQUFjO0lBT2xDLE1BQU0sMkJBQTJCLGVBQWUsUUFBUSxNQUFNLFdBQVcsT0FBTyxjQUFjLE9BQU8sY0FBYyxNQUFNLFVBQVUsT0FBTztJQUMxSSxNQUFNLDZCQUE2QixjQUFjLE1BQU0sVUFBVSxPQUFPO0lBQ3hFLElBQUksNEJBQTRCLDRCQUM5QjtHQUVKO0dBQ0EsSUFBSSwwQkFBMEIsS0FBSyxHQUNqQztHQUlGLElBQUkscUJBQXFCLE1BQU0sZUFBZTtJQUc1QyxJQUFJLE1BQU0sV0FBVyxLQUFLLENBQUMsZUFBZSxLQUFLLEtBQUssQ0FBQyxxQkFBcUIsU0FDeEU7SUFNRixJQUFJLDRCQUE0QixTQUFTO0tBQ3ZDLGlDQUFpQyxNQUFNO0tBQ3ZDLDRCQUE0QixVQUFVO0tBQ3RDO0lBQ0Y7R0FDRjtHQUNBLElBQUksT0FBT0MsbUJBQWlCLGNBQWMsQ0FBQ0EsZUFBYSxLQUFLLEdBQzNEO0dBRUYsSUFBSSxpQkFBaUIsdUJBQXVCLEdBQzFDO0dBRUYsTUFBTSxRQUFRLE9BQU8seUJBQXlCSSxjQUFzQixLQUFLLENBQUM7R0FDMUUscUJBQXFCO0VBQ3ZCO0VBQ0EsU0FBUyxrQkFBa0IsT0FBTztHQUNoQyxJQUFJLHFCQUFxQixNQUFNLFlBQVksTUFBTSxnQkFBZ0IsV0FBVyxDQUFDLE1BQU0sT0FBTyxNQUFNLEtBQUssQ0FBQyxXQUFXLHlCQUF5QixLQUFLLEdBQzdJO0dBRUYsb0JBQW9CLEtBQUs7RUFDM0I7RUFDQSxTQUFTLGlCQUFpQixPQUFPO0dBQy9CLElBQUkscUJBQXFCLE1BQU0sWUFBWSxDQUFDLE1BQU0sT0FBTyxNQUFNLEtBQUssQ0FBQyxXQUFXLHlCQUF5QixLQUFLLEdBQzVHO0dBRUYsTUFBTSxRQUFRLE1BQU0sUUFBUTtHQUM1QixJQUFJLE9BQU87SUFDVCxjQUFjLFVBQVU7S0FDdEIsV0FBVyxLQUFLLElBQUk7S0FDcEIsUUFBUSxNQUFNO0tBQ2QsUUFBUSxNQUFNO0tBQ2QsbUJBQW1CO0tBQ25CLG9CQUFvQjtJQUN0QjtJQUNBLDBCQUEwQixNQUFNLFdBQVk7S0FDMUMsSUFBSSxjQUFjLFNBQVM7TUFDekIsY0FBYyxRQUFRLG9CQUFvQjtNQUMxQyxjQUFjLFFBQVEscUJBQXFCO0tBQzdDO0lBQ0YsQ0FBQztHQUNIO0VBQ0Y7RUFDQSxTQUFTLDJCQUEyQixPQUFPLFVBQVU7R0FDbkQsTUFBTSxTQUFTLFVBQVUsS0FBSztHQUM5QixJQUFJLENBQUMsUUFDSDtHQUVGLE1BQU0sY0FBYyxpQkFBaUIsUUFBUSxNQUFNLFlBQVk7SUFDN0QsU0FBUyxLQUFLO0lBQ2QsWUFBWTtHQUNkLENBQUM7RUFDSDtFQUNBLFNBQVMsd0JBQXdCLE9BQU87R0FDdEMsc0JBQXNCLFVBQVU7R0FDaEMsMkJBQTJCLE9BQU8sZ0JBQWdCO0VBQ3BEO0VBQ0EsU0FBUywyQkFBMkIsT0FBTztHQUN6QywwQkFBMEIsTUFBTTtHQUloQyxJQUFJLE1BQU0sU0FBUyxlQUFlO0lBRWhDLElBQUksTUFBTSxXQUFXLEdBQ25CLHFCQUFxQixVQUFVO0lBRWpDLHNCQUFzQixVQUFVLE1BQU07R0FDeEM7R0FDQSxJQUFJLE1BQU0sU0FBUyxlQUFlLGNBQWMsV0FBVyxDQUFDLGNBQWMsUUFBUSxvQkFDaEY7R0FFRiwyQkFBMkIsUUFBTyxnQkFBZTtJQUMvQyxJQUFJLFlBQVksU0FBUyxlQUN2QixrQkFBa0IsV0FBVztTQUU3QixvQkFBb0IsV0FBVztHQUVuQyxDQUFDO0VBQ0g7RUFDQSxTQUFTLHNCQUFzQixPQUFPO0dBR3BDLElBQUksTUFBTSxTQUFTLGlCQUNqQixxQkFBcUIsVUFBVTtHQUVqQyxJQUFJLENBQUMsc0JBQXNCLFNBQ3pCO0dBRUYsTUFBTSxxQ0FBcUMsdUJBQXVCO0dBQ2xFLHFCQUFxQjtHQUNyQixJQUFJLHFCQUFxQixNQUFNLGVBQzdCO0dBRUYsSUFBSSxNQUFNLFNBQVMsaUJBQWlCO0lBQ2xDLElBQUksb0NBQ0YsaURBQWlEO0lBRW5EO0dBQ0Y7R0FDQSxJQUFJLDBCQUEwQixLQUFLLEdBQ2pDO0dBT0YsSUFBSSxvQ0FBb0M7SUFDdEMsaURBQWlEO0lBQ2pEO0dBQ0Y7R0FHQSxJQUFJLE9BQU9KLG1CQUFpQixjQUFjLENBQUNBLGVBQWEsS0FBSyxHQUMzRDtHQUVGLGlDQUFpQyxNQUFNO0dBQ3ZDLDRCQUE0QixVQUFVO0dBQ3RDLHFCQUFxQjtFQUN2QjtFQUNBLFNBQVMsZ0JBQWdCLE9BQU87R0FDOUIsSUFBSSxxQkFBcUIsTUFBTSxZQUFZLENBQUMsY0FBYyxXQUFXLHlCQUF5QixLQUFLLEdBQ2pHO0dBRUYsTUFBTSxRQUFRLE1BQU0sUUFBUTtHQUM1QixJQUFJLENBQUMsT0FDSDtHQUVGLE1BQU0sU0FBUyxLQUFLLElBQUksTUFBTSxVQUFVLGNBQWMsUUFBUSxNQUFNO0dBQ3BFLE1BQU0sU0FBUyxLQUFLLElBQUksTUFBTSxVQUFVLGNBQWMsUUFBUSxNQUFNO0dBQ3BFLE1BQU0sV0FBVyxLQUFLLEtBQUssU0FBUyxTQUFTLFNBQVMsTUFBTTtHQUM1RCxJQUFJLFdBQVcsR0FDYixjQUFjLFFBQVEsb0JBQW9CO0dBRTVDLElBQUksV0FBVyxJQUFJO0lBQ2pCLG9CQUFvQixLQUFLO0lBQ3pCLDBCQUEwQixNQUFNO0lBQ2hDLGNBQWMsVUFBVTtHQUMxQjtFQUNGO0VBQ0EsU0FBUyx1QkFBdUIsT0FBTztHQUNyQywyQkFBMkIsT0FBTyxlQUFlO0VBQ25EO0VBQ0EsU0FBUyxlQUFlLE9BQU87R0FDN0IsSUFBSSxxQkFBcUIsTUFBTSxZQUFZLENBQUMsY0FBYyxXQUFXLHlCQUF5QixLQUFLLEdBQ2pHO0dBRUYsSUFBSSxjQUFjLFFBQVEsbUJBQ3hCLG9CQUFvQixLQUFLO0dBRTNCLDBCQUEwQixNQUFNO0dBQ2hDLGNBQWMsVUFBVTtFQUMxQjtFQUNBLFNBQVMsc0JBQXNCLE9BQU87R0FDcEMsMkJBQTJCLE9BQU8sY0FBYztFQUNsRDtFQUNBLE1BQU0sY0FBYyxjQUFjRSxlQUFhLGNBQWMsaUJBQWlCLEtBQUssV0FBVyxvQkFBb0IsR0FBRyxpQkFBaUIsS0FBSyxvQkFBb0Isc0JBQXNCLEdBQUcsaUJBQWlCLEtBQUssa0JBQWtCLG9CQUFvQixDQUFDLEdBQUcsdUJBQXVCLGNBQWMsaUJBQWlCLEtBQUssU0FBUyw0QkFBNEIsSUFBSSxHQUFHLGlCQUFpQixLQUFLLGVBQWUsNEJBQTRCLElBQUksR0FBRyxpQkFBaUIsS0FBSyxhQUFhLHVCQUF1QixJQUFJLEdBQUcsaUJBQWlCLEtBQUssaUJBQWlCLHVCQUF1QixJQUFJLEdBQUcsaUJBQWlCLEtBQUssYUFBYSw0QkFBNEIsSUFBSSxHQUFHLGlCQUFpQixLQUFLLFdBQVcsdUJBQXVCLElBQUksR0FBRyxpQkFBaUIsS0FBSyxjQUFjLHlCQUF5QjtHQUM3dUIsU0FBUztHQUNULFNBQVM7RUFDWCxDQUFDLEdBQUcsaUJBQWlCLEtBQUssYUFBYSx3QkFBd0I7R0FDN0QsU0FBUztHQUNULFNBQVM7RUFDWCxDQUFDLEdBQUcsaUJBQWlCLEtBQUssWUFBWSx1QkFBdUI7R0FDM0QsU0FBUztHQUNULFNBQVM7RUFDWCxDQUFDLENBQUMsQ0FBQztFQUNILGFBQWE7R0FDWCxZQUFZO0dBQ1osaUNBQWlDLE1BQU07R0FDdkMscUJBQXFCO0dBQ3JCLDRCQUE0QixVQUFVO0VBQ3hDO0NBQ0YsR0FBRztFQUFDO0VBQVM7RUFBaUJBO0VBQVc7RUFBcUJGO0VBQWM7RUFBTTtFQUFTO0VBQWtCO0VBQXFCO0VBQXNCO0VBQXNCO0VBQTBCO0VBQWtCO0VBQTBCO0VBQU07RUFBTztFQUEyQjtDQUFrQixDQUFDO0NBQy9TLE1BQU0seUJBQWtCLGVBQWU7RUFDckMsV0FBVztFQUNYLGVBQWU7RUFDZixTQUFTO0NBQ1gsSUFBSSxDQUFDLHNCQUFzQixxQkFBcUIsQ0FBQztDQUNqRCxNQUFNLHdCQUFpQixlQUFlO0VBQ3BDLFdBQVc7RUFJWCxlQUFlO0VBQ2YsYUFBYTtFQUNiLGdCQUFnQjtFQUNoQixtQkFBbUIsT0FBTztHQUN4QixvQkFBb0I7R0FDcEIsZ0NBQWdDLEtBQUs7RUFDdkM7RUFDQSxxQkFBcUIsT0FBTztHQUMxQixvQkFBb0I7R0FDcEIsZ0NBQWdDLEtBQUs7RUFDdkM7RUFDQSxrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLG9CQUFvQjtDQUN0QixJQUFJO0VBQUM7RUFBc0I7RUFBcUI7RUFBaUM7Q0FBNkIsQ0FBQztDQUMvRyxvQkFBYSxjQUFjLFVBQVU7RUFDbkM7RUFDQTtFQUNBLFNBQVM7Q0FDWCxJQUFJLENBQUMsR0FBRztFQUFDO0VBQVM7RUFBVztDQUFRLENBQUM7QUFDeEM7Ozs7Ozs7OztBQ3JmQSxTQUFnQiw2QkFBNkIsU0FBUztDQUNwRCxNQUFNLEVBQ0osWUFDQSw4QkFBOEIsT0FDOUIscUJBQXFCLE9BQ3JCLFlBQ0EsUUFDQSxpQkFDRTtDQUNKLE1BQU0sT0FBTyxXQUFXLFNBQVMsTUFBTTtDQUN2QyxNQUFNLG1CQUFtQixXQUFXLFNBQVMsc0JBQXNCO0NBQ25FLE1BQU0sa0JBQWtCLFdBQVcsU0FBUyw4QkFBOEIsaUJBQWlCLG1CQUFtQjtDQUM5RyxNQUFNLG1CQUFtQjtDQUN6QixXQUFXLGVBQWUsY0FBYyxVQUFVO0NBQ2xELHlCQUF5QjtFQUN2QixNQUFNLGVBQWU7R0FDbkI7R0FDQTtHQUNBO0dBQ0E7RUFDRjtFQUNBLElBQUksVUFBVSxnQkFBZ0IsR0FDNUIsYUFBYSxzQkFBc0I7RUFFckMsSUFBSSxNQUFNLE1BQU0sc0JBQXNCLE1BQU0sTUFBTSxrQkFDaEQsYUFBYSxvQkFBb0I7RUFFbkMsTUFBTSxPQUFPLFlBQVk7Q0FDM0IsR0FBRztFQUFDO0VBQU07RUFBWTtFQUFrQjtFQUFpQjtDQUFLLENBQUM7Q0FHL0QsTUFBTSxRQUFRLGVBQWU7Q0FDN0IsTUFBTSxRQUFRLFNBQVM7Q0FDdkIsT0FBTztBQUNUOzs7Ozs7Ozs7OztBQzlCQSxTQUFnQixxQkFBcUIsWUFBWTtDQUMvQyxNQUFNLEVBQ0osTUFDQSxLQUNBLHVCQUNBLDBCQUEwQiwrQkFDMUIsV0FDQSx1QkFDRTtDQUNKLE1BQU0sMkJBQTJCLGtCQUFrQiw2QkFBNkI7Q0FDaEYsTUFBTSxFQUNKLFNBQ0EsWUFDQSxxQkFDRSxvQkFBb0IsTUFBTSxPQUFPLE9BQU8sa0JBQWtCO0NBTzlELE1BQU0sMkJBQTJCLE9BQU8sUUFBUTtDQUNoRCx5QkFBeUI7RUFDdkIsSUFBSSxNQUNGLHlCQUF5QixLQUFLO0NBRWxDLEdBQUcsQ0FBQyxNQUFNLHdCQUF3QixDQUFDO0NBTW5DLE1BQU0sMEJBQW1CLE9BQU8sT0FBTztDQUN2QyxNQUFNLGlDQUEwQixPQUFPLEtBQUs7Q0FDNUMsTUFBTSxXQUFXLHFCQUFxQjtDQUN0QyxNQUFNLGdCQUFnQjtFQUNwQixXQUFXLFVBQVU7RUFDckIsV0FBVyxLQUFLO0VBQ2hCLFVBQVU7Q0FDWjtDQUNBLHlCQUF5QjtFQUN2QixXQUFXLFVBQVU7RUFDckIsSUFBSSxrQkFBa0IsU0FBUztHQUM3QixrQkFBa0IsVUFBVTtHQUM1QixJQUFJLENBQUMsUUFBUSxTQUNYLFFBQVE7RUFFWjtDQUNGLENBQUM7Q0FDRCxNQUFNLGVBQWUsd0JBQXdCO0VBQzNDLElBQUksQ0FBQyxXQUFXLFNBQ2Q7RUFFRixJQUFJLE1BQU07R0FLUixrQkFBa0IsVUFBVTtHQUM1QixTQUFTO0dBQ1Q7RUFDRjtFQUNBLFFBQVE7Q0FDVixDQUFDO0NBQ0Qsc0JBQXNCO0VBQ3BCLFNBQVMsV0FBVyxDQUFDLFFBQVEsQ0FBQztFQUM5QjtFQUNBO0VBQ0EsYUFBYTtHQUNYLElBQUksQ0FBQyxNQUNILGFBQWE7RUFFakI7Q0FDRixDQUFDO0NBQ0QsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0NBQ0Y7QUFDRjs7QUNsRkEsSUFBYSx3QkFBd0I7Q0FDbkMsVUFBVTtFQUNULHNCQUFzQjtBQUN6Qjs7Ozs7O0FBT0EsU0FBZ0IsMEJBQTBCLFVBQVU7Q0FDbEQsUUFBTyxvQkFBbUIsb0JBQW9CLFVBQVUsU0FBUyxVQUFVO0FBQzdFOzs7Ozs7Ozs7Ozs7Ozs7QUFpQkEsU0FBZ0Isa0JBQWtCLGFBQWEsOEJBQThCLE9BQU87Q0FDbEYsTUFBTSxhQUFhLE1BQU07Q0FDekIsTUFBTSxTQUFTLHdCQUF3QixLQUFLO0NBQzVDLE1BQU0sUUFBUSxxQkFBcUIsWUFBWSxZQUFZLE1BQU0sQ0FBQyxDQUFDLENBQUM7Q0FDcEUsNkJBQTZCO0VBQzNCLFlBQVk7RUFDWjtFQUNBLHFCQUFxQixNQUFNLE1BQU07RUFDakM7RUFDQTtFQUNBLGNBQWMsTUFBTTtDQUN0QixDQUFDO0NBQ0QsT0FBTztBQUNUOzs7Ozs7Ozs7OztBQVlBLFNBQWdCLHNCQUFzQixFQUNwQyxRQUNBLFNBQ0M7Q0FDRCx5QkFBeUI7RUFDdkIsT0FBTyxPQUFPLFlBQVksS0FBSztDQUNqQyxHQUFHLENBQUMsUUFBUSxLQUFLLENBQUM7Q0FDbEIsT0FBTztBQUNUO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTztDQUMvQixNQUFNLGVBQWUsTUFBTSxRQUFRLGdCQUFnQjtDQUNuRCxJQUFJLE1BQU0sT0FBTyxNQUFNLEtBQUssTUFBTSxNQUFNLGlCQUFpQixjQUN2RCxNQUFNLElBQUksZ0JBQWdCLFlBQVk7QUFFMUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQkEsU0FBZ0IsdUJBQXVCLElBQUksT0FBTztDQUNoRCxNQUFNLCtCQUF3QixPQUFPLElBQUk7Q0FDekMsT0FBTyxtQkFBa0IsWUFBVztFQUNsQyxNQUFNLGVBQWUsZ0JBQWdCO0VBQ3JDLElBQUksaUJBQWlCLE1BQU07R0FDekIsSUFBSSxhQUFhLFlBQVksV0FBVyxhQUFhLFVBQVUsU0FBUyxhQUFhLE9BQU8sSUFFMUY7R0FFRixnQkFBZ0IsVUFBVTtHQUMxQixNQUFNLGtCQUFrQixhQUFhO0dBQ3JDLElBQUksZ0JBQWdCLFFBQVEsZ0JBQWdCLFFBQVEsYUFBYSxFQUFFLE1BQU0sYUFBYSxTQUFTO0lBQzdGLGdCQUFnQixRQUFRLGdCQUFnQixPQUFPLGFBQWEsRUFBRTtJQUM5RCxpQkFBaUIsZUFBZTtHQUNsQztFQUNGO0VBQ0EsSUFBSSxZQUFZLFFBQVEsT0FBTyxRQUFXO0dBQ3hDLGdCQUFnQixVQUFVO0lBQ3hCO0lBQ0E7SUFDQTtHQUNGO0dBQ0EsTUFBTSxRQUFRLGdCQUFnQixJQUFJLElBQUksT0FBTztHQUM3QyxpQkFBaUIsS0FBSztFQUN4QjtDQUNGLENBQUM7QUFDSDtBQUNBLFNBQWdCLHFCQUFxQixPQUFPLE1BQU0sU0FBUyx3QkFBd0IsT0FBTztDQUN4RixJQUFJLDJCQUEyQixNQUFNO0NBQ3JDLElBQUksTUFFRiwyQkFBMkI7TUFDdEIsSUFBSSx1QkFDVCwyQkFBMkI7Q0FFN0IsTUFBTSxZQUFZLFNBQVMsTUFBTTtDQUNqQyxJQUFJLGtCQUFrQixNQUFNO0NBQzVCLElBQUksdUJBQXVCLE1BQU07Q0FJakMsSUFBSSxhQUFhLE1BQU07RUFDckIsa0JBQWtCO0VBQ2xCLHVCQUF1QixXQUFXO0NBQ3BDO0NBQ0EsT0FBTztFQUNMO0VBQ0E7RUFDQTtFQUNBO0VBTUEsc0JBQXNCLE9BQU8sV0FBVyxPQUFPLE1BQU07Q0FDdkQ7QUFDRjtBQUNBLFNBQWdCLDRCQUE0QixjQUFjO0NBQ3hELElBQUksd0JBQXdCO0NBQzVCLGFBQWEsOEJBQThCO0VBQ3pDLHdCQUF3QjtDQUMxQjtDQUNBLGFBQWE7QUFDZjs7Ozs7Ozs7O0FBVUEsU0FBZ0IscUJBQXFCLE9BQU8sVUFBVSxjQUFjLFVBQVUsQ0FBQyxHQUFHO0NBQ2hGLE1BQU0sU0FBUyxhQUFhO0NBQzVCLE1BQU0sVUFBVSxXQUFXSztDQUMzQixNQUFNLGNBQWMsWUFBWSxXQUFXO0NBQzNDLE1BQU0saUJBQWlCLENBQUMsYUFBYSxXQUFXLG1CQUF3QixXQUFXO0NBQ25GLE1BQU0sOEJBQThCLDRCQUE0QixZQUFZO0NBQzVFLE1BQU0sUUFBUSxlQUFlLFVBQVUsWUFBWTtDQUNuRCxJQUFJLGFBQWEsWUFDZjtDQUVGLFFBQVEsbUJBQW1CO0NBQzNCLE1BQU0sTUFBTSxvQkFBb0IsbUJBQW1CLFVBQVUsWUFBWTtDQUN6RSxNQUFNLG9CQUFvQjtFQUN4QixNQUFNLGlCQUFpQixxQkFBcUIsTUFBTSxPQUFPLFVBQVUsYUFBYSxTQUFTLDRCQUE0QixDQUFDO0VBQ3RILE1BQU0sZUFBZTtHQUNuQixHQUFHLFFBQVE7R0FDWCxHQUFHO0VBQ0w7RUFDQSxJQUFJLGFBQ0YsYUFBYSxjQUFjO09BQ3RCLElBQUksZ0JBQ1QsYUFBYSxjQUFjO09BQ3RCLElBQUksU0FDVCxhQUFhLGNBQWM7RUFFN0IsTUFBTSxPQUFPLFlBQVk7Q0FDM0I7Q0FDQSxJQUFJLFNBRUYsaUJBQVMsVUFBVSxXQUFXO01BRTlCLFlBQVk7QUFFaEI7Ozs7Ozs7OztBQVVBLFNBQWdCLHlCQUF5QixXQUFXLG1CQUFtQixPQUFPLGNBQWM7Q0FDMUYsTUFBTSx5QkFBeUIsTUFBTSxTQUFTLHNCQUFzQixTQUFTO0NBQzdFLE1BQU0sc0JBQXNCLHVCQUF1QixXQUFXLEtBQUs7Q0FLbkUsTUFBTSxtQkFBbUIsbUJBQWtCLFlBQVc7RUFDcEQsTUFBTSxPQUFPLE1BQU0sT0FBTyxNQUFNO0VBQ2hDLE1BQU0sa0JBQWtCLE1BQU0sT0FBTyxpQkFBaUI7RUFDdEQsSUFBSSxvQkFBb0IsV0FBVztHQUNqQyxNQUFNLFVBQVU7SUFDZCxzQkFBc0I7SUFDdEIsR0FBSSxPQUFPLGVBQWU7R0FDNUI7R0FDQSxNQUFNLE9BQU8sT0FBTztHQUNwQjtFQUNGO0VBQ0EsSUFBSSxtQkFBbUIsUUFBUSxRQUFRLENBQUMsTUFBTSxNQUFNLHNCQUFzQjtHQUt4RSxNQUFNLFVBQVU7SUFDZCxpQkFBaUIsYUFBYTtJQUM5QixzQkFBc0I7SUFDdEIsR0FBRztHQUNMO0dBQ0EsTUFBTSxPQUFPLE9BQU87RUFDdEI7Q0FDRixDQUFDO0NBSUQsTUFBTSxrQkFBa0IsbUJBQWtCLFlBQVc7RUFDbkQsb0JBQW9CLE9BQU87RUFDM0IsSUFBSSxTQUNGLGlCQUFpQixPQUFPO0NBRTVCLENBQUM7Q0FJRCx5QkFBeUI7RUFDdkIsZ0JBQWdCLGtCQUFrQixPQUFPO0VBQ3pDLGFBQWEsZ0JBQWdCLElBQUk7Q0FDbkMsR0FBRztFQUFDO0VBQWlCO0VBQW1CO0VBQU87Q0FBUyxDQUFDO0NBQ3pELHlCQUF5QjtFQUN2QixJQUFJLHdCQUF3QjtHQUMxQixNQUFNLFVBQVU7SUFDZCxzQkFBc0Isa0JBQWtCO0lBQ3hDLEdBQUc7R0FDTDtHQUNBLE1BQU0sT0FBTyxPQUFPO0VBQ3RCO0NBRUYsR0FBRztFQUFDO0VBQXdCO0VBQU87RUFBbUIsR0FBRyxPQUFPLE9BQU8sWUFBWTtDQUFDLENBQUM7Q0FDckYsT0FBTztFQUNMO0VBQ0E7Q0FDRjtBQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF3QkEsU0FBZ0IseUJBQXlCLE9BQU8sVUFBVSxDQUFDLEdBQUc7Q0FDNUQsTUFBTSxFQUNKLDhCQUE4QixVQUM1QjtDQUVKLE1BQU0sMENBQW1DLE9BQU8sSUFBSTtDQUNwRCxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSx1QkFBdUIsTUFBTSxTQUFTLGNBQWM7Q0FHMUQsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLGlCQUFpQjtDQU14RCxNQUFNLCtCQUErQixNQUFNLFNBQVMsc0JBQXNCO0NBQzFFLHlCQUF5QjtFQUN2QixJQUFJLENBQUMsTUFBTTtHQUNULDJCQUEyQixVQUFVO0dBQ3JDLElBQUksTUFBTSxNQUFNLGlCQUFpQixHQUMvQixNQUFNLElBQUksZ0JBQWdCLENBQUM7R0FLN0IsSUFBSSxNQUFNLE1BQU0sc0JBQ2QsTUFBTSxJQUFJLHdCQUF3QixLQUFLO0dBRXpDO0VBQ0Y7RUFDQSxNQUFNLGVBQWUsTUFBTSxRQUFRLGdCQUFnQjtFQUNuRCxNQUFNLGVBQWUsQ0FBQztFQUN0QixJQUFJLE1BQU0sTUFBTSxpQkFBaUIsY0FDL0IsYUFBYSxlQUFlO0VBRTlCLE1BQU0seUJBQXlCLE1BQU0sT0FBTyxpQkFBaUI7RUFDN0QsSUFBSSxzQkFBc0I7RUFDMUIsSUFBSSx3QkFBd0I7R0FDMUIsTUFBTSx1QkFBdUIsTUFBTSxRQUFRLGdCQUFnQixRQUFRLHNCQUFzQjtHQUN6RixJQUFJLENBQUMsc0JBQXNCO0lBQ3pCLEtBQUssTUFBTSxDQUFDLFdBQVcsbUJBQW1CLE1BQU0sUUFBUSxnQkFBZ0IsUUFBUSxHQUM5RSxJQUFJLG1CQUFtQixNQUFNLE1BQU0sc0JBQXNCO0tBQ3ZELGFBQWEsa0JBQWtCO0tBQy9CLGFBQWEsdUJBQXVCO0tBQ3BDLDJCQUEyQixVQUFVO0tBQ3JDO0lBQ0Y7SUFFRixJQUFJLGFBQWEsb0JBQW9CLFFBQVc7S0FDOUMsSUFBSSwyQkFBMkIsWUFBWSx3QkFDekMsc0JBQXNCO1VBRXRCLDJCQUEyQixVQUFVO0lBRXpDO0dBQ0YsT0FBTztJQUNMLDJCQUEyQixVQUFVO0lBQ3JDLElBQUkseUJBQXlCLE1BQU0sTUFBTSxzQkFDdkMsYUFBYSx1QkFBdUI7R0FFeEM7RUFDRixPQUNFLDJCQUEyQixVQUFVO0VBRXZDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQywwQkFBMEIsQ0FBQyxNQUFNLE1BQU0sd0JBQXdCLGlCQUFpQixHQUFHO0dBQzlHLE1BQU0saUJBQWlCLE1BQU0sUUFBUSxnQkFBZ0IsUUFBUSxDQUFDLENBQUMsS0FBSztHQUNwRSxJQUFJLENBQUMsZUFBZSxNQUFNO0lBQ3hCLE1BQU0sQ0FBQyxtQkFBbUIsMEJBQTBCLGVBQWU7SUFDbkUsYUFBYSxrQkFBa0I7SUFDL0IsYUFBYSx1QkFBdUI7SUFDcEMsMkJBQTJCLFVBQVU7R0FDdkM7RUFDRjtFQUNBLElBQUksYUFBYSxpQkFBaUIsVUFBYSxhQUFhLG9CQUFvQixVQUFhLGFBQWEseUJBQXlCLFFBQ2pJLE1BQU0sT0FBTyxZQUFZO0VBRTNCLElBQUkscUJBQ0U7T0FBQSw2QkFFRixxQkFBcUI7SUFDbkIsSUFBSSxNQUFNLE9BQU8sTUFBTSxLQUFLLE1BQU0sT0FBTyxpQkFBaUIsTUFBTSx1QkFBdUIsQ0FBQyxNQUFNLFFBQVEsZ0JBQWdCLFFBQVEsbUJBQW1CLEdBQUc7S0FDbEosTUFBTSxlQUFlLHlCQUF5QkMsSUFBWTtLQUMxRCxNQUFNLFFBQVEsT0FBTyxZQUFZO0tBR2pDLElBQUksQ0FBQyxhQUFhLFlBQ2hCLE1BQU0sT0FBTztNQUNYLGlCQUFpQjtNQUNqQixzQkFBc0I7S0FDeEIsQ0FBQztJQUVMO0dBQ0YsQ0FBQztFQUFBO0NBR1AsR0FBRztFQUFDO0VBQU07RUFBTztFQUFzQjtFQUFpQjtFQUE4QjtDQUEyQixDQUFDO0FBQ3BIOzs7Ozs7Ozs7Ozs7Ozs7OztBQWtCQSxTQUFnQix3QkFBd0IsTUFBTSxPQUFPLFdBQVcsb0JBQW9CO0NBQ2xGLE1BQU0sRUFDSixTQUNBLGtCQUNBLGlCQUNFLHFCQUFxQjtFQUN2QjtFQUNBLEtBQUssTUFBTSxRQUFRO0VBQ25CLHVCQUF1QixNQUFNLFNBQVMsMEJBQTBCO0VBQ2hFLDJCQUEwQiwwQkFBeUIsTUFBTSxJQUFJLDRCQUE0QixxQkFBcUI7RUFDOUc7RUFDQSxZQUFZO0dBQ1YsTUFBTSxPQUFPO0lBQ1gsaUJBQWlCO0lBQ2pCLHNCQUFzQjtJQUN0QixTQUFTO0lBQ1QsMEJBQTBCO0dBQzVCLENBQUM7R0FDRCxZQUFZO0dBQ1osTUFBTSxRQUFRLHVCQUF1QixLQUFLO0VBQzVDO0NBQ0YsQ0FBQztDQUlELHFCQUFxQjtFQUNuQixNQUFNLElBQUksV0FBVyxPQUFPO0VBQzVCLE9BQU87Q0FDVCxDQUFDO0NBQ0QsTUFBTSxnQkFBZ0I7RUFDcEI7RUFDQTtDQUNGLENBQUM7Q0FDRCxPQUFPO0VBQ0w7RUFDQTtDQUNGO0FBQ0Y7QUFDQSxTQUFnQix5QkFBeUIsT0FBTyxXQUFXO0NBQ3pELE1BQU0sZ0JBQWdCLFNBQVM7Q0FDL0IsK0JBQStCO0VBQzdCLE1BQU0sT0FBTztHQUNYLG9CQUFvQjtHQUNwQixzQkFBc0I7R0FDdEIsWUFBWTtFQUNkLENBQUM7Q0FDSCxHQUFHLENBQUMsS0FBSyxDQUFDO0FBQ1o7QUFDQSxTQUFnQixpQkFBaUIsT0FBTyxNQUFNO0NBQzVDLHlCQUF5QjtFQUN2QixJQUFJLENBQUMsUUFBUSxNQUFNLE1BQU0sZUFBZSxNQUN0QyxNQUFNLElBQUksY0FBYyxJQUFJO0NBRWhDLEdBQUcsQ0FBQyxNQUFNLEtBQUssQ0FBQztDQUNoQiwrQkFBK0I7RUFDN0IsSUFBSSxNQUFNLE1BQU0sZUFBZSxNQUM3QixNQUFNLElBQUksY0FBYyxJQUFJO0NBRWhDLEdBQUcsQ0FBQyxLQUFLLENBQUM7QUFDWjs7Ozs7Ozs7OztBQ3BkQSxJQUFJO0FBQ0osU0FBUyxpQkFBaUIsS0FBSztDQUM3Qix1Q0FBdUIsSUFBSSxRQUFRO0NBQ25DLElBQUksYUFBYSxtQkFBbUIsSUFBSSxHQUFHO0NBQzNDLElBQUksQ0FBQyxZQUFZO0VBQ2YsNkJBQWEsSUFBSSxRQUFRO0VBQ3pCLG1CQUFtQixJQUFJLEtBQUssVUFBVTtDQUN4QztDQUNBLE9BQU87QUFDVDs7Ozs7OztBQVFBLElBQWEsa0JBQWIsTUFBNkI7Q0FDM0Isd0JBQVEsSUFBSSxJQUFJOzs7Ozs7Q0FPaEIsSUFBSSxJQUFJLFNBQVM7RUFDNEI7R0FDekMsTUFBTSxhQUFhLGlCQUFpQixJQUFJO0dBQ3hDLE1BQU0sYUFBYSxXQUFXLElBQUksT0FBTztHQUN6QyxJQUFJLGVBQWUsVUFBYSxlQUFlLElBRzdDLE1BQU0sSUFBSSxNQUFNLHdGQUF3RjtHQUsxRyxNQUFNLGtCQUFrQixLQUFLLE1BQU0sSUFBSSxFQUFFO0dBQ3pDLElBQUksb0JBQW9CLFVBQWEsb0JBQW9CLFNBQ3ZELFdBQVcsT0FBTyxlQUFlO0dBRW5DLFdBQVcsSUFBSSxTQUFTLEVBQUU7RUFDNUI7RUFDQSxLQUFLLE1BQU0sSUFBSSxJQUFJLE9BQU87Q0FDNUI7Ozs7Q0FLQSxPQUFPLElBQUk7RUFDa0M7R0FDekMsTUFBTSxVQUFVLEtBQUssTUFBTSxJQUFJLEVBQUU7R0FDakMsSUFBSSxZQUFZLFFBQ2Qsb0JBQW9CLElBQUksSUFBSSxDQUFDLEVBQUUsT0FBTyxPQUFPO0VBRWpEO0VBQ0EsS0FBSyxNQUFNLE9BQU8sRUFBRTtDQUN0Qjs7OztDQUtBLFdBQVcsU0FBUztFQUNsQixLQUFLLE1BQU0sY0FBYyxLQUFLLE1BQU0sT0FBTyxHQUN6QyxJQUFJLGVBQWUsU0FDakIsT0FBTztFQUdYLE9BQU87Q0FDVDs7OztDQUtBLG1CQUFtQixXQUFXO0VBQzVCLEtBQUssTUFBTSxXQUFXLEtBQUssTUFBTSxPQUFPLEdBQ3RDLElBQUksVUFBVSxPQUFPLEdBQ25CLE9BQU87RUFHWCxPQUFPO0NBQ1Q7Ozs7Q0FLQSxRQUFRLElBQUk7RUFDVixPQUFPLEtBQUssTUFBTSxJQUFJLEVBQUU7Q0FDMUI7Ozs7Q0FLQSxVQUFVO0VBQ1IsT0FBTyxLQUFLLE1BQU0sUUFBUTtDQUM1Qjs7OztDQUtBLFdBQVc7RUFDVCxPQUFPLEtBQUssTUFBTSxPQUFPO0NBQzNCOzs7O0NBS0EsSUFBSSxPQUFPO0VBQ1QsT0FBTyxLQUFLLE1BQU07Q0FDcEI7QUFDRjs7OztBQ3BIQSxJQUFNLFFBQVEsQ0FBQztBQUNmLElBQUksa0JBQWtCO0FBQ3RCLFNBQWdCLGNBQWM7Q0FDNUIsT0FBTztBQUNUO0FBSUEsU0FBZ0IsU0FBUyxNQUFNO0NBQzdCLE1BQU0sS0FBSyxJQUFJO0FBQ2pCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW9DQSxTQUFnQixjQUFjLElBQUk7Q0FDaEMsTUFBTSxpQkFBaUIsT0FBTyxpQkFBaUI7RUFDN0MsTUFBTSxXQUFXLGVBQWUsY0FBYyxDQUFDLENBQUM7RUFDaEQsSUFBSTtFQUNKLElBQUk7R0FDRixrQkFBa0I7R0FDbEIsS0FBSyxNQUFNLFFBQVEsT0FDakIsS0FBSyxPQUFPLFFBQVE7R0FFdEIsU0FBUyxHQUFHLE9BQU8sWUFBWTtHQUMvQixLQUFLLE1BQU0sUUFBUSxPQUNqQixLQUFLLE1BQU0sUUFBUTtHQUVyQixTQUFTLGdCQUFnQjtFQUMzQixVQUFVO0dBQ1Isa0JBQWtCO0VBQ3BCO0VBQ0EsT0FBTztDQUNUO0NBQ0EsY0FBYyxjQUFjLEdBQUcsZUFBZSxHQUFHO0NBQ2pELE9BQU87QUFDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQTBCQSxTQUFnQixpQkFBaUIsSUFBSTtDQUNuQyxPQUFvQiwyQkFBTSxXQUFXLGNBQWMsRUFBRSxDQUFDO0FBQ3hEO0FBQ0EsU0FBUyxpQkFBaUI7Q0FDeEIsT0FBTyxFQUNMLGVBQWUsTUFDakI7QUFDRjs7QUM1RkEsSUFBTSx5QkFEZ0Msc0JBQXNCLEVBQ0QsSUFBSSxlQUFlO0FBQzlFLFNBQWdCLFNBQVMsT0FBTyxVQUFVLElBQUksSUFBSSxJQUFJO0NBQ3BELE9BQU8sdUJBQXVCLE9BQU8sVUFBVSxJQUFJLElBQUksRUFBRTtBQUMzRDtBQUNBLFNBQVMsWUFBWSxPQUFPLFVBQVUsSUFBSSxJQUFJLElBQUk7Q0FDaEQsTUFBTSw0QkFBcUIsa0JBQWtCLFNBQVMsTUFBTSxZQUFZLEdBQUcsSUFBSSxJQUFJLEVBQUUsR0FBRztFQUFDO0VBQU87RUFBVTtFQUFJO0VBQUk7Q0FBRSxDQUFDO0NBQ3JILFdBQU9DLGtDQUFxQixNQUFNLFdBQVcsY0FBYyxZQUFZO0FBQ3pFO0FBQ0EsU0FBUztDQUNQLE9BQU8sVUFBVTtFQUNmLFNBQVMsWUFBWTtFQUNyQixJQUFJLENBQUMsU0FBUyxlQUFlO0dBQzNCLFNBQVMsV0FBVztHQUNwQixTQUFTLFlBQVksQ0FBQztHQUN0QixTQUFTLGlCQUFpQjtHQUMxQixTQUFTLG9CQUFvQjtJQUMzQixJQUFJLFlBQVk7SUFDaEIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFNBQVMsVUFBVSxRQUFRLEtBQUssR0FBRztLQUNyRCxNQUFNLE9BQU8sU0FBUyxVQUFVO0tBQ2hDLE1BQU0sUUFBUSxLQUFLLFNBQVMsS0FBSyxNQUFNLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLEVBQUU7S0FDdkUsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLE9BQU8sS0FBSyxHQUFHO01BQ2pDLFlBQVk7TUFDWixLQUFLLFFBQVE7S0FDZjtJQUNGO0lBQ0EsSUFBSSxXQUNGLFNBQVMsWUFBWTtJQUV2QixPQUFPLFNBQVM7R0FDbEI7RUFDRjtDQUNGO0NBQ0EsTUFBTSxVQUFVO0VBQ2QsSUFBSSxTQUFTLFVBQVUsU0FBUyxHQUFHO0dBQ2pDLElBQUksU0FBUyxnQkFBZ0I7SUFDM0IsU0FBUyxpQkFBaUI7SUFDMUIsU0FBUyxhQUFZLGtCQUFpQjtLQUNwQyxNQUFNLHlCQUFTLElBQUksSUFBSTtLQUN2QixLQUFLLE1BQU0sUUFBUSxTQUFTLFdBQzFCLE9BQU8sSUFBSSxLQUFLLEtBQUs7S0FFdkIsTUFBTSxlQUFlLENBQUM7S0FDdEIsS0FBSyxNQUFNLFNBQVMsUUFDbEIsYUFBYSxLQUFLLE1BQU0sVUFBVSxhQUFhLENBQUM7S0FFbEQsYUFBYTtNQUNYLEtBQUssTUFBTSxlQUFlLGNBQ3hCLFlBQVk7S0FFaEI7SUFDRjtHQUNGO0dBRUEsc0NBQXFCLFNBQVMsV0FBVyxTQUFTLGFBQWEsU0FBUyxXQUFXO0VBQ3JGO0NBQ0Y7QUFDRixDQUFDO0FBQ0QsU0FBUyxhQUFhLE9BQU8sVUFBVSxJQUFJLElBQUksSUFBSTtDQUNqRCxNQUFNLFdBQVcsWUFBWTtDQUM3QixJQUFJLENBQUMsVUFFSCxPQUFPLFlBQVksT0FBTyxVQUFVLElBQUksSUFBSSxFQUFFO0NBRWhELE1BQU0sUUFBUSxTQUFTO0NBQ3ZCLFNBQVMsYUFBYTtDQUN0QixJQUFJO0NBQ0osSUFBSSxDQUFDLFNBQVMsZUFBZTtFQUMzQixPQUFPO0dBQ0w7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBLE9BQU8sU0FBUyxNQUFNLFlBQVksR0FBRyxJQUFJLElBQUksRUFBRTtFQUNqRDtFQUNBLFNBQVMsVUFBVSxLQUFLLElBQUk7Q0FDOUIsT0FBTztFQUNMLE9BQU8sU0FBUyxVQUFVO0VBQzFCLElBQUksS0FBSyxVQUFVLFNBQVMsS0FBSyxhQUFhLFlBQVksQ0FBQyxPQUFPLEdBQUcsS0FBSyxJQUFJLEVBQUUsS0FBSyxDQUFDLE9BQU8sR0FBRyxLQUFLLElBQUksRUFBRSxLQUFLLENBQUMsT0FBTyxHQUFHLEtBQUssSUFBSSxFQUFFLEdBQUc7R0FDdkksSUFBSSxLQUFLLFVBQVUsT0FDakIsU0FBUyxpQkFBaUI7R0FFNUIsS0FBSyxRQUFRO0dBQ2IsS0FBSyxXQUFXO0dBQ2hCLEtBQUssS0FBSztHQUNWLEtBQUssS0FBSztHQUNWLEtBQUssS0FBSztHQUNWLEtBQUssUUFBUSxTQUFTLE1BQU0sWUFBWSxHQUFHLElBQUksSUFBSSxFQUFFO0VBQ3ZEO0NBQ0Y7Q0FDQSxPQUFPLEtBQUs7QUFDZDtBQUNBLFNBQVMsZUFBZSxPQUFPLFVBQVUsSUFBSSxJQUFJLElBQUk7Q0FDbkQsV0FBT0MsdURBQWlDLE1BQU0sV0FBVyxNQUFNLGFBQWEsTUFBTSxjQUFhLFVBQVMsU0FBUyxPQUFPLElBQUksSUFBSSxFQUFFLENBQUM7QUFDckk7Ozs7OztBQ25HQSxJQUFhLFFBQWIsTUFBbUI7Ozs7OztDQU1qQixPQUFPLE9BQU8sT0FBTztFQUNuQixPQUFPLElBQUksS0FBSyxLQUFLO0NBQ3ZCOzs7Ozs7Ozs7Q0FhQSxZQUFZLE9BQU87RUFDakIsS0FBSyxRQUFRO0VBQ2IsS0FBSyw0QkFBWSxJQUFJLElBQUk7RUFDekIsS0FBSyxhQUFhO0NBQ3BCOzs7Ozs7O0NBUUEsYUFBWSxPQUFNO0VBQ2hCLEtBQUssVUFBVSxJQUFJLEVBQUU7RUFDckIsYUFBYTtHQUNYLEtBQUssVUFBVSxPQUFPLEVBQUU7RUFDMUI7Q0FDRjs7OztDQUtBLG9CQUFvQjtFQUNsQixPQUFPLEtBQUs7Q0FDZDs7Ozs7O0NBT0EsU0FBUyxVQUFVO0VBQ2pCLElBQUksS0FBSyxVQUFVLFVBQ2pCO0VBRUYsS0FBSyxRQUFRO0VBQ2IsS0FBSyxjQUFjO0VBQ25CLE1BQU0sY0FBYyxLQUFLO0VBQ3pCLEtBQUssTUFBTSxZQUFZLEtBQUssV0FBVztHQUNyQyxJQUFJLGdCQUFnQixLQUFLLFlBR3ZCO0dBRUYsU0FBUyxRQUFRO0VBQ25CO0NBQ0Y7Ozs7Ozs7O0NBU0EsT0FBTyxTQUFTO0VBQ2QsS0FBSyxNQUFNLE9BQU8sU0FDaEIsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLE1BQU0sTUFBTSxRQUFRLElBQUksR0FBRztHQUM3QyxLQUFLLFNBQVM7SUFDWixHQUFHLEtBQUs7SUFDUixHQUFHO0dBQ0wsQ0FBQztHQUNEO0VBQ0Y7Q0FFSjs7Ozs7OztDQVFBLElBQUksS0FBSyxPQUFPO0VBQ2QsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLE1BQU0sTUFBTSxLQUFLLEdBQ25DLEtBQUssU0FBUztHQUNaLEdBQUcsS0FBSztJQUNQLE1BQU07RUFDVCxDQUFDO0NBRUw7Ozs7Q0FLQSxZQUFZO0VBQ1YsTUFBTSxXQUFXLEVBQ2YsR0FBRyxLQUFLLE1BQ1Y7RUFDQSxLQUFLLFNBQVMsUUFBUTtDQUN4QjtDQUNBLElBQUksVUFBVSxJQUFJLElBQUksSUFBSTtFQUV4QixPQUFPLFNBQVMsTUFBTSxVQUFVLElBQUksSUFBSSxFQUFFO0NBQzVDO0FBQ0Y7Ozs7O0FDM0dBLElBQWEsYUFBYixjQUFnQyxNQUFNOzs7Ozs7OztDQVFwQyxZQUFZLE9BQU8sVUFBVSxDQUFDLEdBQUcsV0FBVztFQUMxQyxNQUFNLEtBQUs7RUFDWCxLQUFLLFVBQVU7RUFDZixLQUFLLFlBQVk7Q0FDbkI7Ozs7Ozs7Ozs7Q0FZQSxlQUFlLEtBQUssT0FBTztFQUN6QixhQUFNLGNBQWMsR0FBRztFQUV2QixNQUFNLFFBQVE7RUFDZCx5QkFBeUI7R0FDdkIsSUFBSSxNQUFNLE1BQU0sU0FBUyxPQUN2QixNQUFNLElBQUksS0FBSyxLQUFLO0VBRXhCLEdBQUc7R0FBQztHQUFPO0dBQUs7RUFBSyxDQUFDO0NBQ3hCOzs7Ozs7OztDQVNBLDBCQUEwQixLQUFLLE9BQU87RUFFcEMsTUFBTSxRQUFRO0VBQ2QseUJBQXlCO0dBQ3ZCLElBQUksTUFBTSxNQUFNLFNBQVMsT0FDdkIsTUFBTSxJQUFJLEtBQUssS0FBSztHQUV0QixhQUFhO0lBQ1gsTUFBTSxJQUFJLEtBQUssTUFBUztHQUMxQjtFQUNGLEdBQUc7R0FBQztHQUFPO0dBQUs7RUFBSyxDQUFDO0NBQ3hCOzs7Ozs7Ozs7OztDQVlBLGdCQUFnQixXQUFXO0VBRXpCLE1BQU0sUUFBUTtFQUM2QjtHQUV6QyxhQUFNLGNBQWMsWUFBVyxNQUFLLE9BQU8sS0FBSyxDQUFDLENBQUM7R0FDbEQsTUFBTSxvQkFBYSxPQUFPLE9BQU8sS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO0dBQ2xELE1BQU0sV0FBVyxPQUFPLEtBQUssU0FBUztHQUN0QyxJQUFJLEtBQUssV0FBVyxTQUFTLFVBQVUsS0FBSyxNQUFNLEtBQUssVUFBVSxRQUFRLFNBQVMsTUFBTSxHQUN0RixRQUFRLE1BQU0sK0ZBQStGO0VBRWpIO0VBQ0EsTUFBTSxlQUFlLE9BQU8sT0FBTyxTQUFTO0VBQzVDLHlCQUF5QjtHQUN2QixNQUFNLE9BQU8sU0FBUztFQUV4QixHQUFHLENBQUMsT0FBTyxHQUFHLFlBQVksQ0FBQztDQUM3Qjs7Ozs7Q0FNQSxrQkFBa0IsS0FBSyxZQUFZO0VBQ2pDLGFBQU0sY0FBYyxHQUFHO0VBRXZCLE1BQU0sUUFBUTtFQUNkLE1BQU0sZUFBZSxlQUFlO0VBQ3BDLHlCQUF5QjtHQUN2QixJQUFJLGdCQUFnQixDQUFDLE9BQU8sR0FBRyxNQUFNLE1BQU0sTUFBTSxVQUFVLEdBRXpELE1BQU0sU0FBUztJQUNiLEdBQUcsTUFBTTtLQUNSLE1BQU07R0FDVCxDQUFDO0VBRUwsR0FBRztHQUFDO0dBQU87R0FBSztHQUFZO0VBQVksQ0FBQztFQUNFO0dBRXpDLE1BQU0sUUFBUSxLQUFLLHFDQUFxQixJQUFJLElBQUk7R0FDaEQsSUFBSSxDQUFDLE1BQU0sSUFBSSxHQUFHLEdBQ2hCLE1BQU0sSUFBSSxLQUFLLFlBQVk7R0FFN0IsTUFBTSx1QkFBdUIsTUFBTSxJQUFJLEdBQUc7R0FDMUMsSUFBSSx5QkFBeUIsVUFBYSx5QkFBeUIsY0FDakUsUUFBUSxNQUFNLCtCQUErQix1QkFBdUIsS0FBSyxLQUFLLHNCQUFzQixJQUFJLFNBQVMsRUFBRSxTQUFTLHVCQUF1QixPQUFPLEdBQUcsd0ZBQXdGO0VBRXpQO0NBQ0Y7Ozs7O0NBT0EsT0FBTyxLQUFLLElBQUksSUFBSSxJQUFJO0VBQ3RCLE1BQU0sV0FBVyxLQUFLLFVBQVU7RUFDaEMsT0FBTyxTQUFTLEtBQUssT0FBTyxJQUFJLElBQUksRUFBRTtDQUN4Qzs7Ozs7Ozs7Q0FVQSxTQUFTLEtBQUssSUFBSSxJQUFJLElBQUk7RUFDeEIsYUFBTSxjQUFjLEdBQUc7RUFDdkIsT0FBTyxTQUFTLE1BQU0sS0FBSyxVQUFVLE1BQU0sSUFBSSxJQUFJLEVBQUU7Q0FDdkQ7Ozs7Ozs7O0NBU0EsbUJBQW1CLEtBQUssSUFBSTtFQUMxQixhQUFNLGNBQWMsR0FBRztFQUN2QixNQUFNLGlCQUFpQixrQkFBa0IsTUFBTSxJQUFJO0VBQ25ELEtBQUssUUFBUSxPQUFPO0NBQ3RCOzs7Ozs7O0NBUUEsZUFBZSxLQUFLO0VBQ2xCLE1BQU0sbUJBQVksT0FBTyxNQUFTO0VBQ2xDLElBQUksSUFBSSxZQUFZLFFBQ2xCLElBQUksV0FBVSxVQUFTO0dBQ3JCLEtBQUssSUFBSSxLQUFLLEtBQUs7RUFDckI7RUFFRixPQUFPLElBQUk7Q0FDYjs7Ozs7OztDQVNBLFFBQVEsVUFBVSxVQUFVO0VBQzFCLElBQUk7RUFDSixJQUFJLE9BQU8sYUFBYSxZQUN0QixXQUFXO09BRVgsV0FBVyxLQUFLLFVBQVU7RUFFNUIsSUFBSSxZQUFZLFNBQVMsS0FBSyxLQUFLO0VBQ25DLFNBQVMsV0FBVyxXQUFXLElBQUk7RUFDbkMsT0FBTyxLQUFLLFdBQVUsY0FBYTtHQUNqQyxNQUFNLFlBQVksU0FBUyxTQUFTO0dBQ3BDLElBQUksQ0FBQyxPQUFPLEdBQUcsV0FBVyxTQUFTLEdBQUc7SUFDcEMsTUFBTSxXQUFXO0lBQ2pCLFlBQVk7SUFDWixTQUFTLFdBQVcsVUFBVSxJQUFJO0dBQ3BDO0VBQ0YsQ0FBQztDQUNIO0FBQ0Y7O0FDM01BLElBQU0sWUFBWTtDQUNoQixPQUFNLFVBQVMsTUFBTTtDQUNyQixtQkFBa0IsVUFBUyxNQUFNO0NBQ2pDLHNCQUFxQixVQUFTLE1BQU07Q0FDcEMsbUJBQWtCLFVBQVMsTUFBTSxxQkFBcUIsTUFBTTtDQUM1RCxrQkFBaUIsVUFBUyxNQUFNO0NBQ2hDLGFBQVksVUFBUyxNQUFNO0FBQzdCO0FBQ0EsSUFBYSxvQkFBYixjQUF1QyxXQUFXO0NBQ2hELFlBQVksU0FBUztFQUNuQixNQUFNLEVBQ0osVUFDQSxRQUNBLGNBQ0EsaUJBQ0EsR0FBRyxpQkFDRDtFQUNKLE1BQU07R0FDSixHQUFHO0dBQ0gsbUJBQW1CLGFBQWE7R0FDaEMscUJBQXFCLGFBQWE7RUFDcEMsR0FBRztHQUNEO0dBQ0EsU0FBUyxFQUNQLFNBQVMsQ0FBQyxFQUNaO0dBQ0EsUUFBUSxtQkFBbUI7R0FDM0I7R0FDQTtFQUNGLEdBQUcsU0FBUztFQUNaLEtBQUssV0FBVztDQUNsQjs7OztDQUtBLGlCQUFpQixTQUFTLFVBQVU7RUFDbEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLE1BQU0sUUFHNUIsU0FBUyxRQUFRLGlCQUFpQixLQUFLLEdBQ3JDLEtBQUssUUFBUSxRQUFRLFFBQVEsWUFBWSxVQUFVLFFBQVE7Q0FFL0Q7Ozs7Q0FLQSxzQkFBc0IsU0FBUyxpQkFBaUI7RUFDOUMsS0FBSyxjQUFjLFNBQVMsYUFBYSxLQUFLO0VBQzlDLE1BQU0sVUFBVTtHQUNkLE1BQU07R0FDTixRQUFRLGFBQWE7R0FDckIsYUFBYSxhQUFhO0dBQzFCLFFBQVEsS0FBSyxRQUFRO0dBQ3JCLGdCQUFnQixhQUFhO0VBQy9CO0VBQ0EsS0FBSyxRQUFRLE9BQU8sS0FBSyxjQUFjLE9BQU87Q0FDaEQ7Ozs7Ozs7Q0FRQSxXQUFXLFNBQVMsaUJBQWlCO0VBQ25DLElBQUksS0FBSyxVQUFVO0dBQ2pCLEtBQUssUUFBUSxlQUFlLFNBQVMsWUFBWTtHQUNqRDtFQUNGO0VBQ0EsS0FBSyxtQkFBbUIsU0FBUyxZQUFZO0VBQzdDLEtBQUssUUFBUSxlQUFlLFNBQVMsWUFBWTtDQUNuRDtBQUNGIiwibmFtZXMiOlsicGxhdGZvcm0ub3MuYW5kcm9pZCIsInBsYXRmb3JtLmVudi5qc2RvbSIsIlRyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcy5zdGFydGluZ1N0eWxlIiwiVHJhbnNpdGlvblN0YXR1c0RhdGFBdHRyaWJ1dGVzLmVuZGluZ1N0eWxlIiwicG9wdXBPcGVuIiwiQ29tbW9uVHJpZ2dlckRhdGFBdHRyaWJ1dGVzLnBvcHVwT3BlbiIsIkNvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcy5wcmVzc2VkIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5vcGVuIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5jbG9zZWQiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmFuY2hvckhpZGRlbiIsIlRvb2x0aXBUcmlnZ2VyRGF0YUF0dHJpYnV0ZXMudHJpZ2dlckRpc2FibGVkIiwicGxhdGZvcm0uc2NyZWVuUmVhZGVyLnZvaWNlT3ZlciIsInBsYXRmb3JtLmVuZ2luZS53ZWJraXQiLCJvdXRzaWRlUHJlc3MiLCJSRUFTT05TLnRyaWdnZXJQcmVzcyIsImVzY2FwZUtleSIsIlJFQVNPTlMuZXNjYXBlS2V5IiwiUkVBU09OUy5vdXRzaWRlUHJlc3MiLCJSRUFTT05TLnRyaWdnZXJIb3ZlciIsIlJFQVNPTlMubm9uZSIsInVzZVN5bmNFeHRlcm5hbFN0b3JlIiwidXNlU3luY0V4dGVybmFsU3RvcmVXaXRoU2VsZWN0b3IiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsiLi4vLi4vQGJhc2UtdWkvdXRpbHMvYWRkRXZlbnRMaXN0ZW5lci5tanMiLCIuLi8uLi9AYmFzZS11aS91dGlscy9wbGF0Zm9ybS9zaGFyZWQubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvcGxhdGZvcm0vb3MubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvcGxhdGZvcm0vZW5naW5lLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtL3NjcmVlbi1yZWFkZXIubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvcGxhdGZvcm0vZW52Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL2V2ZW50Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL2NvbnN0YW50cy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9Db21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3V0aWxzL0NvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC90b29sdGlwL3RyaWdnZXIvVG9vbHRpcFRyaWdnZXJEYXRhQXR0cmlidXRlcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC91dGlscy9lbGVtZW50Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL21lcmdlQ2xlYW51cHMubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvdXNlVmFsdWVBc1JlZi5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9Gb2N1c0d1YXJkLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL3RhYmJhYmxlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL25vZGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL2NyZWF0ZUF0dHJpYnV0ZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9pbnRlcm5hbHMvY29uc3RhbnRzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L2NvbXBvbmVudHMvRmxvYXRpbmdQb3J0YWwubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvdXRpbHMvY3JlYXRlRXZlbnRFbWl0dGVyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2Zsb2F0aW5nLXVpLXJlYWN0L2NvbXBvbmVudHMvRmxvYXRpbmdUcmVlU3RvcmUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvY29tcG9uZW50cy9GbG9hdGluZ1RyZWUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvaG9va3MvdXNlRGlzbWlzcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9mbG9hdGluZy11aS1yZWFjdC9ob29rcy91c2VTeW5jZWRGbG9hdGluZ1Jvb3RDb250ZXh0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2ludGVybmFscy91c2VVbm1vdW50QWZ0ZXJDbG9zZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9wb3B1cHMvcG9wdXBTdG9yZVV0aWxzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3V0aWxzL3BvcHVwcy9wb3B1cFRyaWdnZXJNYXAubWpzIiwiLi4vLi4vQGJhc2UtdWkvdXRpbHMvZmFzdEhvb2tzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3N0b3JlL3VzZVN0b3JlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3N0b3JlL1N0b3JlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3N0b3JlL1JlYWN0U3RvcmUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvY29tcG9uZW50cy9GbG9hdGluZ1Jvb3RTdG9yZS5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBBZGRzIGFuIGV2ZW50IGxpc3RlbmVyIGFuZCByZXR1cm5zIGEgY2xlYW51cCBmdW5jdGlvbiB0byByZW1vdmUgaXQuXG4gKi9cblxuZXhwb3J0IGZ1bmN0aW9uIGFkZEV2ZW50TGlzdGVuZXIodGFyZ2V0LCB0eXBlLCBsaXN0ZW5lciwgb3B0aW9ucykge1xuICB0YXJnZXQuYWRkRXZlbnRMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lciwgb3B0aW9ucyk7XG4gIHJldHVybiAoKSA9PiB7XG4gICAgdGFyZ2V0LnJlbW92ZUV2ZW50TGlzdGVuZXIodHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpO1xuICB9O1xufSIsIi8qKlxuICogUmVhZHMgYG5hdmlnYXRvci51c2VyQWdlbnRgIC8gYG5hdmlnYXRvci5wbGF0Zm9ybWAgKGxlZ2FjeSBidXQgdW5pdmVyc2FsbHlcbiAqIHN1cHBvcnRlZCkgaW50byBhIG5vcm1hbGl6ZWQgc2hhcGUuIEluIGRldmVsb3BtZW50LCBwcmVmZXJzIHRoZSBtb2Rlcm5cbiAqIGBuYXZpZ2F0b3IudXNlckFnZW50RGF0YWAgQVBJIG9uIENocm9taXVtIHRvIGF2b2lkIERldlRvb2xzIHdhcm5pbmdzIGFib3V0XG4gKiB0aGUgZGVwcmVjYXRlZCByZWFkczsgdGhhdCBicmFuY2ggaXMgZGVhZC1jb2RlLWVsaW1pbmF0ZWQgaW4gcHJvZHVjdGlvblxuICogYnVpbGRzIHRvIGtlZXAgdGhlIGJ1bmRsZSBzbWFsbC5cbiAqXG4gKiBSZXR1cm5zIGVtcHR5L3plcm8gdmFsdWVzIHdoZW4gYG5hdmlnYXRvcmAgaXMgdW5kZWZpbmVkIChTU1IpLCBzbyBldmVyeVxuICogZGVyaXZlZCBmbGFnIHNhZmVseSBldmFsdWF0ZXMgdG8gYGZhbHNlYC5cbiAqL1xuZnVuY3Rpb24gcmVhZFJhd0RhdGEoKSB7XG4gIGlmICh0eXBlb2YgbmF2aWdhdG9yID09PSAndW5kZWZpbmVkJykge1xuICAgIHJldHVybiB7XG4gICAgICB1c2VyQWdlbnQ6ICcnLFxuICAgICAgcGxhdGZvcm06ICcnLFxuICAgICAgbWF4VG91Y2hQb2ludHM6IDBcbiAgICB9O1xuICB9XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgY29uc3QgdWFEYXRhID0gbmF2aWdhdG9yLnVzZXJBZ2VudERhdGE7XG4gICAgaWYgKHVhRGF0YSAmJiBBcnJheS5pc0FycmF5KHVhRGF0YS5icmFuZHMpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB1c2VyQWdlbnQ6IHVhRGF0YS5icmFuZHMubWFwKCh7XG4gICAgICAgICAgYnJhbmQsXG4gICAgICAgICAgdmVyc2lvblxuICAgICAgICB9KSA9PiBgJHticmFuZH0vJHt2ZXJzaW9ufWApLmpvaW4oJyAnKSxcbiAgICAgICAgcGxhdGZvcm06IHVhRGF0YS5wbGF0Zm9ybSA/PyBuYXZpZ2F0b3IucGxhdGZvcm0gPz8gJycsXG4gICAgICAgIG1heFRvdWNoUG9pbnRzOiBuYXZpZ2F0b3IubWF4VG91Y2hQb2ludHMgPz8gMFxuICAgICAgfTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB1c2VyQWdlbnQ6IG5hdmlnYXRvci51c2VyQWdlbnQsXG4gICAgcGxhdGZvcm06IG5hdmlnYXRvci5wbGF0Zm9ybSA/PyAnJyxcbiAgICBtYXhUb3VjaFBvaW50czogbmF2aWdhdG9yLm1heFRvdWNoUG9pbnRzID8/IDBcbiAgfTtcbn1cbmNvbnN0IHtcbiAgdXNlckFnZW50LFxuICBwbGF0Zm9ybSxcbiAgbWF4VG91Y2hQb2ludHNcbn0gPSByZWFkUmF3RGF0YSgpO1xuZXhwb3J0IGNvbnN0IGxvd2VyVXNlckFnZW50ID0gdXNlckFnZW50LnRvTG93ZXJDYXNlKCk7XG5leHBvcnQgY29uc3QgbG93ZXJQbGF0Zm9ybSA9IHBsYXRmb3JtLnRvTG93ZXJDYXNlKCk7XG5leHBvcnQgeyBtYXhUb3VjaFBvaW50cyB9OyIsImltcG9ydCB7IGxvd2VyVXNlckFnZW50LCBsb3dlclBsYXRmb3JtLCBtYXhUb3VjaFBvaW50cyB9IGZyb20gXCIuL3NoYXJlZC5tanNcIjtcblxuLy8gaVBhZE9TIDEzKyByZXBvcnRzIGBNYWNJbnRlbGAgZm9yIGBuYXZpZ2F0b3IucGxhdGZvcm1gOyBkaXNhbWJpZ3VhdGVkIHZpYVxuLy8gYG1heFRvdWNoUG9pbnRzYCBzbyBpUGFkIGlzIGNsYXNzaWZpZWQgYXMgaU9TLCBub3QgbWFjT1MuXG4vLyBodHRwczovL2dpdGh1Yi5jb20vbXVpL2Jhc2UtdWkvaXNzdWVzLzEzMDlcbi8qKiBpUGhvbmUsIGlQYWQgKGluY2x1ZGluZyBpUGFkT1MgMTMrIHJlcG9ydGluZyBhcyBtYWNPUyksIGlQb2QuICovXG5leHBvcnQgY29uc3QgaW9zID0gL15pKG9zJHxwKS8udGVzdChsb3dlclBsYXRmb3JtKSB8fCBsb3dlclBsYXRmb3JtID09PSAnbWFjaW50ZWwnICYmIG1heFRvdWNoUG9pbnRzID4gMTtcblxuLyoqIEFuZHJvaWQgcGhvbmVzLCB0YWJsZXRzLCBhbmQgZW1iZWRkZWQgQW5kcm9pZCBicm93c2Vycy4gKi9cbmNvbnN0IEFORFJPSURfU1RSSU5HID0gJ2FuZHJvaWQnO1xuZXhwb3J0IGNvbnN0IGFuZHJvaWQgPSBsb3dlclBsYXRmb3JtID09PSBBTkRST0lEX1NUUklORyB8fCBsb3dlclVzZXJBZ2VudC5pbmNsdWRlcyhBTkRST0lEX1NUUklORyk7XG5cbi8qKiBtYWNPUyBkZXNrdG9wLiBFeGNsdWRlcyBpUGFkT1MsIHdoaWNoIHJlcG9ydHMgYXMgYE1hY0ludGVsYC4gKi9cbmV4cG9ydCBjb25zdCBtYWMgPSAhaW9zICYmIGxvd2VyUGxhdGZvcm0uc3RhcnRzV2l0aCgnbWFjJyk7XG5cbi8qKiBXaW5kb3dzIGRlc2t0b3AuICovXG5leHBvcnQgY29uc3Qgd2luZG93cyA9IGxvd2VyUGxhdGZvcm0uc3RhcnRzV2l0aCgnd2luJyk7XG5cbi8qKiBMaW51eCBkZXNrdG9wIChpbmNsdWRpbmcgQ2hyb21lIE9TKS4gKi9cbmV4cG9ydCBjb25zdCBsaW51eCA9ICFhbmRyb2lkICYmIC9eKGxpbnV4fGNocm9tZSBvcykvLnRlc3QobG93ZXJQbGF0Zm9ybSk7XG5cbi8qKiBBbnkgQXBwbGUgT1MgKGBtYWMgfHwgaW9zYCkuICovXG5leHBvcnQgY29uc3QgYXBwbGUgPSBtYWMgfHwgaW9zOyIsImltcG9ydCB7IGxvd2VyVXNlckFnZW50IH0gZnJvbSBcIi4vc2hhcmVkLm1qc1wiO1xuXG4vLyBXZWJLaXQgKFNhZmFyaSwgYWxsIGlPUyBicm93c2VycywgR05PTUUgV2ViKS4gRGlzdGluZ3Vpc2hlZCBmcm9tIEJsaW5rIGJ5XG4vLyB0aGUgbGVnYWN5IGAtd2Via2l0LWJhY2tkcm9wLWZpbHRlcmAgbmFtZSDigJQgQmxpbmsgZm9ya2VkIGZyb20gV2ViS2l0IGluIDIwMTNcbi8vIGFuZCBvbmx5IHNoaXBzIHRoZSB1bnByZWZpeGVkIGBiYWNrZHJvcC1maWx0ZXJgLlxuLyoqIFdlYktpdDogU2FmYXJpLCBhbGwgaU9TIGJyb3dzZXJzLCBHTk9NRSBXZWIuIEV4Y2x1ZGVzIEJsaW5rLiAqL1xuZXhwb3J0IGNvbnN0IHdlYmtpdCA9IHR5cGVvZiBDU1MgIT09ICd1bmRlZmluZWQnICYmICEhQ1NTLnN1cHBvcnRzPy4oJy13ZWJraXQtYmFja2Ryb3AtZmlsdGVyOm5vbmUnKTtcblxuLy8gQW5jaG9yZWQgdG8gYCF3ZWJraXRgIHNvIGVuZ2luZXMgYXJlIG11dHVhbGx5IGV4Y2x1c2l2ZSBieSBjb25zdHJ1Y3Rpb24uXG4vLyBGaXJlZm94LW9uLWlPUyB1c2VzIFdlYktpdCAoaXRzIFVBIG1hcmtlciBpcyBgRnhpT1MvYCwgbm90IGBGaXJlZm94L2ApOyB0aGVcbi8vIGAhd2Via2l0YCBwcmVmaXggYWxzbyBkZWZlbmRzIGFnYWluc3QgZnV0dXJlIGlPUy1icm93c2VyIFVBIGNoYW5nZXMgdGhhdFxuLy8gbWlnaHQgaW5qZWN0IGBGaXJlZm94YCBpbnRvIGEgV2ViS2l0LWJhc2VkIFVBLlxuLyoqIEdlY2tvOiBGaXJlZm94LiAqL1xuZXhwb3J0IGNvbnN0IGdlY2tvID0gIXdlYmtpdCAmJiBsb3dlclVzZXJBZ2VudC5pbmNsdWRlcygnZmlyZWZveCcpO1xuXG4vLyBBbGwgQ2hyb21pdW0tYmFzZWQgYnJvd3NlcnMgc2hpcCBgQ2hyb21lL2Agb3IgYENocm9taXVtL2AgaW4gdGhlaXIgVUEg4oCUIGJvdGhcbi8vIHNoYXJlIHRoZSBgY2hyb21gIHByZWZpeCwgc28gYSBzaW5nbGUgc3Vic3RyaW5nIGNoZWNrIGNvdmVycyBDaHJvbWUsIEVkZ2UsXG4vLyBPcGVyYSwgQnJhdmUsIGV0Yy4gQ2hyb21lLW9uLWlPUyB1c2VzIGBDcmlPUy9gIGFuZCBzdGF5cyBXZWJLaXQuIFRoZSBwb3NpdGl2ZVxuLy8gVUEgY2hlY2sgYWxzbyBtYWtlcyB0aGlzIFNTUi1zYWZlIOKAlCBhbiBlbXB0eSBVQSBtYXRjaGVzIG5vdGhpbmcuXG4vKiogQmxpbms6IENocm9tZSwgRWRnZSwgT3BlcmEsIEJyYXZlLCBhbmQgb3RoZXIgQ2hyb21pdW0tYmFzZWQgYnJvd3NlcnMuICovXG5leHBvcnQgY29uc3QgYmxpbmsgPSAhd2Via2l0ICYmIGxvd2VyVXNlckFnZW50LmluY2x1ZGVzKCdjaHJvbScpOyIsImltcG9ydCB7IGFwcGxlIH0gZnJvbSBcIi4vb3MubWpzXCI7XG5cbi8vIFdoZXRoZXIgYSBzY3JlZW4gcmVhZGVyIGlzICphY3R1YWxseSogcnVubmluZyBjYW5ub3QgYmUgZGV0ZWN0ZWQuIFRoZXNlIGZsYWdzXG4vLyBpZGVudGlmeSBwbGF0Zm9ybXMgd2hlcmUgYSBzcGVjaWZpYyBzY3JlZW4gcmVhZGVyIGNvdWxkIGJlIGFjdGl2ZS4gVm9pY2VPdmVyXG4vLyBpcyB0aGUgc3lzdGVtIHNjcmVlbiByZWFkZXIgb24gQXBwbGUgcGxhdGZvcm1zIGFuZCB3b3JrcyB3aXRoIGV2ZXJ5IGJyb3dzZXJcbi8vIHRoZXJlLCBzbyB0aGUgZmxhZyBpcyBwdXJlbHkgYW4gT1MgY2hlY2s7IGVuZ2luZS1zcGVjaWZpYyBxdWlya3MgKGUuZy4gdGhlXG4vLyBOU0FjY2Vzc2liaWxpdHkgdmlydHVhbC1jdXJzb3IgZm9jdXMgcGF0aCkgc2hvdWxkIGJlIGdhdGVkIGF0IHRoZSBjYWxsIHNpdGUuXG4vKipcbiAqIFRoZSB1c2VyICptYXkqIGJlIHVzaW5nIFZvaWNlT3ZlciDigJQgYWN0dWFsIGFjdGl2YXRpb24gaXMgbm90IGRldGVjdGFibGUuXG4gKiBUcnVlIG9uIGFueSBBcHBsZSBwbGF0Zm9ybSAobWFjT1MsIGlPUywgaVBhZE9TKS5cbiAqL1xuZXhwb3J0IGNvbnN0IHZvaWNlT3ZlciA9IGFwcGxlOyIsImltcG9ydCB7IGxvd2VyVXNlckFnZW50IH0gZnJvbSBcIi4vc2hhcmVkLm1qc1wiO1xuXG4vKiogUnVubmluZyBpbiBqc2RvbSBvciBIYXBweURPTSAodXNlZCBieSB1bml0IHRlc3RzKS4gKi9cbmV4cG9ydCBjb25zdCBqc2RvbSA9IC9qc2RvbXxoYXBweWRvbS8udGVzdChsb3dlclVzZXJBZ2VudCk7IiwiaW1wb3J0IHsgcGxhdGZvcm0gfSBmcm9tICdAYmFzZS11aS91dGlscy9wbGF0Zm9ybSc7XG5leHBvcnQgZnVuY3Rpb24gc3RvcEV2ZW50KGV2ZW50KSB7XG4gIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzUmVhY3RFdmVudChldmVudCkge1xuICByZXR1cm4gJ25hdGl2ZUV2ZW50JyBpbiBldmVudDtcbn1cblxuLy8gTGljZW5zZTogaHR0cHM6Ly9naXRodWIuY29tL2Fkb2JlL3JlYWN0LXNwZWN0cnVtL2Jsb2IvbWFpbi9wYWNrYWdlcy9AcmVhY3QtYXJpYS91dGlscy9zcmMvaXNWaXJ0dWFsRXZlbnQudHNcbmV4cG9ydCBmdW5jdGlvbiBpc1ZpcnR1YWxDbGljayhldmVudCkge1xuICBpZiAoZXZlbnQucG9pbnRlclR5cGUgPT09ICcnICYmIGV2ZW50LmlzVHJ1c3RlZCkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGlmIChwbGF0Zm9ybS5vcy5hbmRyb2lkICYmIGV2ZW50LnBvaW50ZXJUeXBlKSB7XG4gICAgcmV0dXJuIGV2ZW50LnR5cGUgPT09ICdjbGljaycgJiYgZXZlbnQuYnV0dG9ucyA9PT0gMTtcbiAgfVxuICByZXR1cm4gZXZlbnQuZGV0YWlsID09PSAwICYmICFldmVudC5wb2ludGVyVHlwZTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc1ZpcnR1YWxQb2ludGVyRXZlbnQoZXZlbnQpIHtcbiAgaWYgKHBsYXRmb3JtLmVudi5qc2RvbSkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICByZXR1cm4gIXBsYXRmb3JtLm9zLmFuZHJvaWQgJiYgZXZlbnQud2lkdGggPT09IDAgJiYgZXZlbnQuaGVpZ2h0ID09PSAwIHx8XG4gIC8vIENocm9tZSBzeW50aGVzaXplcyBhIHNjcmVlbiByZWFkZXIgcHJlc3MgKFRhbGtCYWNrLCBWb2ljZU92ZXIsIE5WREEpIGFzIGEgMXgxIG1vdXNlXG4gIC8vIGBwb2ludGVyZG93bmAgd2l0aCBubyBwcmVzc3VyZS4gVGFsa0JhY2sgY2FuIHJlcG9ydCBhIHByZXNzZWQgYnV0dG9uLCB3aGlsZSBkZXNrdG9wXG4gIC8vIG1vdXNlIHByZXNzZXMgY2FuIHJlcG9ydCBubyBwcmVzc3VyZSwgc28gb25seSByZXF1aXJlIG5vIHByZXNzZWQgYnV0dG9uIG9mZiBBbmRyb2lkLlxuICBldmVudC50eXBlID09PSAncG9pbnRlcmRvd24nICYmIGV2ZW50LndpZHRoID09PSAxICYmIGV2ZW50LmhlaWdodCA9PT0gMSAmJiBldmVudC5wcmVzc3VyZSA9PT0gMCAmJiBldmVudC5kZXRhaWwgPT09IDAgJiYgZXZlbnQucG9pbnRlclR5cGUgPT09ICdtb3VzZScgJiYgKHBsYXRmb3JtLm9zLmFuZHJvaWQgfHwgZXZlbnQuYnV0dG9ucyA9PT0gMCkgfHxcbiAgLy8gaU9TIFZvaWNlT3ZlciByZXR1cm5zIDAuMzMz4oCiIGZvciB3aWR0aC9oZWlnaHQuXG4gIGV2ZW50LndpZHRoIDwgMSAmJiBldmVudC5oZWlnaHQgPCAxICYmIGV2ZW50LnByZXNzdXJlID09PSAwICYmIGV2ZW50LmRldGFpbCA9PT0gMCAmJiBldmVudC5wb2ludGVyVHlwZSA9PT0gJ3RvdWNoJztcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc01vdXNlTGlrZVBvaW50ZXJUeXBlKHBvaW50ZXJUeXBlLCBzdHJpY3QpIHtcbiAgLy8gT24gc29tZSBMaW51eCBtYWNoaW5lcyB3aXRoIENocm9taXVtLCBtb3VzZSBpbnB1dHMgcmV0dXJuIGEgYHBvaW50ZXJUeXBlYFxuICAvLyBvZiBcInBlblwiOiBodHRwczovL2dpdGh1Yi5jb20vZmxvYXRpbmctdWkvZmxvYXRpbmctdWkvaXNzdWVzLzIwMTVcbiAgY29uc3QgdmFsdWVzID0gWydtb3VzZScsICdwZW4nXTtcbiAgaWYgKCFzdHJpY3QpIHtcbiAgICB2YWx1ZXMucHVzaCgnJywgdW5kZWZpbmVkKTtcbiAgfVxuICByZXR1cm4gdmFsdWVzLmluY2x1ZGVzKHBvaW50ZXJUeXBlKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0NsaWNrTGlrZUV2ZW50KGV2ZW50KSB7XG4gIGNvbnN0IHR5cGUgPSBldmVudC50eXBlO1xuICByZXR1cm4gdHlwZSA9PT0gJ2NsaWNrJyB8fCB0eXBlID09PSAnbW91c2Vkb3duJyB8fCB0eXBlID09PSAna2V5ZG93bicgfHwgdHlwZSA9PT0gJ2tleXVwJztcbn0iLCJleHBvcnQgY29uc3QgRk9DVVNBQkxFX0FUVFJJQlVURSA9ICdkYXRhLWJhc2UtdWktZm9jdXNhYmxlJztcbmV4cG9ydCBjb25zdCBBQ1RJVkVfS0VZID0gJ2FjdGl2ZSc7XG5leHBvcnQgY29uc3QgU0VMRUNURURfS0VZID0gJ3NlbGVjdGVkJztcbmV4cG9ydCBjb25zdCBUWVBFQUJMRV9TRUxFQ1RPUiA9IFwiaW5wdXQ6bm90KFt0eXBlPSdoaWRkZW4nXSk6bm90KFtkaXNhYmxlZF0pLFwiICsgXCJbY29udGVudGVkaXRhYmxlXTpub3QoW2NvbnRlbnRlZGl0YWJsZT0nZmFsc2UnXSksdGV4dGFyZWE6bm90KFtkaXNhYmxlZF0pXCI7XG5leHBvcnQgY29uc3QgQVJST1dfTEVGVCA9ICdBcnJvd0xlZnQnO1xuZXhwb3J0IGNvbnN0IEFSUk9XX1JJR0hUID0gJ0Fycm93UmlnaHQnO1xuZXhwb3J0IGNvbnN0IEFSUk9XX1VQID0gJ0Fycm93VXAnO1xuZXhwb3J0IGNvbnN0IEFSUk9XX0RPV04gPSAnQXJyb3dEb3duJzsiLCJpbXBvcnQgKiBhcyBUcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMgZnJvbSBcIi4uL2ludGVybmFscy9UcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMubWpzXCI7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBwb3B1cCBpcyBvcGVuLlxuICovXG5leHBvcnQgY29uc3Qgb3BlbiA9ICdkYXRhLW9wZW4nO1xuXG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgcG9wdXAgaXMgY2xvc2VkLlxuICovXG5leHBvcnQgY29uc3QgY2xvc2VkID0gJ2RhdGEtY2xvc2VkJztcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHBvcHVwIGJlZ2lucyBhbmltYXRpbmcgaW4uXG4gKi9cbmV4cG9ydCBjb25zdCBzdGFydGluZ1N0eWxlID0gVHJhbnNpdGlvblN0YXR1c0RhdGFBdHRyaWJ1dGVzLnN0YXJ0aW5nU3R5bGU7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBwb3B1cCBpcyBhbmltYXRpbmcgb3V0LlxuICovXG5leHBvcnQgY29uc3QgZW5kaW5nU3R5bGUgPSBUcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMuZW5kaW5nU3R5bGU7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBhbmNob3IgaXMgaGlkZGVuLlxuICovXG5leHBvcnQgY29uc3QgYW5jaG9ySGlkZGVuID0gJ2RhdGEtYW5jaG9yLWhpZGRlbic7XG5cbi8qKlxuICogSW5kaWNhdGVzIHdoaWNoIHNpZGUgdGhlIHBvcHVwIGlzIHBvc2l0aW9uZWQgcmVsYXRpdmUgdG8gdGhlIHRyaWdnZXIuXG4gKiBAdHlwZSB7ICd0b3AnIHwgJ2JvdHRvbScgfCAnbGVmdCcgfCAncmlnaHQnIHwgJ2lubGluZS1lbmQnIHwgJ2lubGluZS1zdGFydCd9XG4gKi9cbmV4cG9ydCBjb25zdCBzaWRlID0gJ2RhdGEtc2lkZSc7XG5cbi8qKlxuICogSW5kaWNhdGVzIGhvdyB0aGUgcG9wdXAgaXMgYWxpZ25lZCByZWxhdGl2ZSB0byBzcGVjaWZpZWQgc2lkZS5cbiAqIEB0eXBlIHsnc3RhcnQnIHwgJ2NlbnRlcicgfCAnZW5kJ31cbiAqL1xuZXhwb3J0IGNvbnN0IGFsaWduID0gJ2RhdGEtYWxpZ24nOyIsIi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBwb3B1cCBpcyBvcGVuLlxuICovXG5leHBvcnQgY29uc3QgcG9wdXBPcGVuID0gJ2RhdGEtcG9wdXAtb3Blbic7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIGEgcHJlc3NhYmxlIHRyaWdnZXIgaXMgcHJlc3NlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IHByZXNzZWQgPSAnZGF0YS1wcmVzc2VkJzsiLCJpbXBvcnQgeyB0cmFuc2l0aW9uU3RhdHVzTWFwcGluZyB9IGZyb20gXCIuLi9pbnRlcm5hbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanNcIjtcbmltcG9ydCAqIGFzIENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMgZnJvbSBcIi4vQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5tanNcIjtcbmltcG9ydCAqIGFzIENvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcyBmcm9tIFwiLi9Db21tb25UcmlnZ2VyRGF0YUF0dHJpYnV0ZXMubWpzXCI7XG5leHBvcnQgeyBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLCBDb21tb25UcmlnZ2VyRGF0YUF0dHJpYnV0ZXMgfTtcbmNvbnN0IFRSSUdHRVJfSE9PSyA9IHtcbiAgW0NvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcy5wb3B1cE9wZW5dOiAnJ1xufTtcbmNvbnN0IFBSRVNTQUJMRV9UUklHR0VSX0hPT0sgPSB7XG4gIFtDb21tb25UcmlnZ2VyRGF0YUF0dHJpYnV0ZXMucG9wdXBPcGVuXTogJycsXG4gIFtDb21tb25UcmlnZ2VyRGF0YUF0dHJpYnV0ZXMucHJlc3NlZF06ICcnXG59O1xuY29uc3QgUE9QVVBfT1BFTl9IT09LID0ge1xuICBbQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5vcGVuXTogJydcbn07XG5jb25zdCBQT1BVUF9DTE9TRURfSE9PSyA9IHtcbiAgW0NvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuY2xvc2VkXTogJydcbn07XG5jb25zdCBBTkNIT1JfSElEREVOX0hPT0sgPSB7XG4gIFtDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmFuY2hvckhpZGRlbl06ICcnXG59O1xuZXhwb3J0IGNvbnN0IHRyaWdnZXJPcGVuU3RhdGVNYXBwaW5nID0ge1xuICBvcGVuKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlKSB7XG4gICAgICByZXR1cm4gVFJJR0dFUl9IT09LO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufTtcbmV4cG9ydCBjb25zdCBwcmVzc2FibGVUcmlnZ2VyT3BlblN0YXRlTWFwcGluZyA9IHtcbiAgb3Blbih2YWx1ZSkge1xuICAgIGlmICh2YWx1ZSkge1xuICAgICAgcmV0dXJuIFBSRVNTQUJMRV9UUklHR0VSX0hPT0s7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG59O1xuZXhwb3J0IGNvbnN0IHBvcHVwU3RhdGVNYXBwaW5nID0ge1xuICBvcGVuKHZhbHVlKSB7XG4gICAgaWYgKHZhbHVlKSB7XG4gICAgICByZXR1cm4gUE9QVVBfT1BFTl9IT09LO1xuICAgIH1cbiAgICByZXR1cm4gUE9QVVBfQ0xPU0VEX0hPT0s7XG4gIH0sXG4gIGFuY2hvckhpZGRlbih2YWx1ZSkge1xuICAgIGlmICh2YWx1ZSkge1xuICAgICAgcmV0dXJuIEFOQ0hPUl9ISURERU5fSE9PSztcbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn07XG5leHBvcnQgY29uc3QgcG9wdXBUcmFuc2l0aW9uU3RhdGVNYXBwaW5nID0ge1xuICAuLi5wb3B1cFN0YXRlTWFwcGluZyxcbiAgLi4udHJhbnNpdGlvblN0YXR1c01hcHBpbmdcbn07IiwiaW1wb3J0IHsgQ29tbW9uVHJpZ2dlckRhdGFBdHRyaWJ1dGVzIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwU3RhdGVNYXBwaW5nLm1qc1wiO1xuXG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgY29ycmVzcG9uZGluZyB0b29sdGlwIGlzIG9wZW4uXG4gKi9cbmV4cG9ydCBjb25zdCBwb3B1cE9wZW4gPSBDb21tb25UcmlnZ2VyRGF0YUF0dHJpYnV0ZXMucG9wdXBPcGVuO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIHRyaWdnZXIgaXMgZGlzYWJsZWQsIGVpdGhlciBieSB0aGUgYGRpc2FibGVkYCBwcm9wIG9yIGJ5IGEgcGFyZW50IGA8VG9vbHRpcC5Sb290PmAgY29tcG9uZW50LlxuICovXG5leHBvcnQgY29uc3QgdHJpZ2dlckRpc2FibGVkID0gJ2RhdGEtdHJpZ2dlci1kaXNhYmxlZCc7IiwiaW1wb3J0IHsgaXNFbGVtZW50LCBpc0hUTUxFbGVtZW50IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzL2RvbSc7XG5pbXBvcnQgeyBwbGF0Zm9ybSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtJztcbmltcG9ydCB7IGFjdGl2ZUVsZW1lbnQsIGNsb3Nlc3QsIGNvbnRhaW5zLCBnZXRUYXJnZXQgfSBmcm9tICdAYmFzZS11aS91dGlscy9zaGFkb3dEb20nO1xuaW1wb3J0IHsgRk9DVVNBQkxFX0FUVFJJQlVURSwgVFlQRUFCTEVfU0VMRUNUT1IgfSBmcm9tIFwiLi9jb25zdGFudHMubWpzXCI7XG5pbXBvcnQgKiBhcyBUb29sdGlwVHJpZ2dlckRhdGFBdHRyaWJ1dGVzIGZyb20gXCIuLi8uLi90b29sdGlwL3RyaWdnZXIvVG9vbHRpcFRyaWdnZXJEYXRhQXR0cmlidXRlcy5tanNcIjtcbmV4cG9ydCB7IGFjdGl2ZUVsZW1lbnQsIGNsb3Nlc3QsIGNvbnRhaW5zLCBnZXRUYXJnZXQgfTtcbmV4cG9ydCBmdW5jdGlvbiBpc1RhcmdldEluc2lkZUVuYWJsZWRUcmlnZ2VyKHRhcmdldCwgdHJpZ2dlckVsZW1lbnRzKSB7XG4gIGlmICghaXNFbGVtZW50KHRhcmdldCkpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgY29uc3QgdGFyZ2V0RWxlbWVudCA9IHRhcmdldDtcbiAgaWYgKHRyaWdnZXJFbGVtZW50cy5oYXNFbGVtZW50KHRhcmdldEVsZW1lbnQpKSB7XG4gICAgcmV0dXJuICF0YXJnZXRFbGVtZW50Lmhhc0F0dHJpYnV0ZShUb29sdGlwVHJpZ2dlckRhdGFBdHRyaWJ1dGVzLnRyaWdnZXJEaXNhYmxlZCk7XG4gIH1cbiAgZm9yIChjb25zdCBbLCB0cmlnZ2VyXSBvZiB0cmlnZ2VyRWxlbWVudHMuZW50cmllcygpKSB7XG4gICAgaWYgKGNvbnRhaW5zKHRyaWdnZXIsIHRhcmdldEVsZW1lbnQpKSB7XG4gICAgICByZXR1cm4gIXRyaWdnZXIuaGFzQXR0cmlidXRlKFRvb2x0aXBUcmlnZ2VyRGF0YUF0dHJpYnV0ZXMudHJpZ2dlckRpc2FibGVkKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzRXZlbnRUYXJnZXRXaXRoaW4oZXZlbnQsIG5vZGUpIHtcbiAgaWYgKG5vZGUgPT0gbnVsbCkge1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBpZiAoJ2NvbXBvc2VkUGF0aCcgaW4gZXZlbnQpIHtcbiAgICByZXR1cm4gZXZlbnQuY29tcG9zZWRQYXRoKCkuaW5jbHVkZXMobm9kZSk7XG4gIH1cblxuICAvLyBUUyB0aGlua3MgYGV2ZW50YCBpcyBvZiB0eXBlIG5ldmVyIGFzIGl0IGFzc3VtZXMgYWxsIGJyb3dzZXJzIHN1cHBvcnQgY29tcG9zZWRQYXRoLCBidXQgYnJvd3NlcnMgd2l0aG91dCBzaGFkb3cgZG9tIGRvbid0XG4gIGNvbnN0IGV2ZW50QWdhaW4gPSBldmVudDtcbiAgcmV0dXJuIGV2ZW50QWdhaW4udGFyZ2V0ICE9IG51bGwgJiYgbm9kZS5jb250YWlucyhldmVudEFnYWluLnRhcmdldCk7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNSb290RWxlbWVudChlbGVtZW50KSB7XG4gIHJldHVybiBlbGVtZW50Lm1hdGNoZXMoJ2h0bWwsYm9keScpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzVHlwZWFibGVFbGVtZW50KGVsZW1lbnQpIHtcbiAgcmV0dXJuIGlzSFRNTEVsZW1lbnQoZWxlbWVudCkgJiYgZWxlbWVudC5tYXRjaGVzKFRZUEVBQkxFX1NFTEVDVE9SKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0ludGVyYWN0aXZlRWxlbWVudChlbGVtZW50KSB7XG4gIHJldHVybiBjbG9zZXN0KGVsZW1lbnQsIGBidXR0b24sYVtocmVmXSxbcm9sZT1cImJ1dHRvblwiXSxzZWxlY3QsW3RhYmluZGV4XTpub3QoW3RhYmluZGV4PVwiLTFcIl0pLCR7VFlQRUFCTEVfU0VMRUNUT1J9YCkgIT0gbnVsbDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc1R5cGVhYmxlQ29tYm9ib3goZWxlbWVudCkge1xuICBpZiAoIWVsZW1lbnQpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIGVsZW1lbnQuZ2V0QXR0cmlidXRlKCdyb2xlJykgPT09ICdjb21ib2JveCcgJiYgaXNUeXBlYWJsZUVsZW1lbnQoZWxlbWVudCk7XG59XG5leHBvcnQgZnVuY3Rpb24gbWF0Y2hlc0ZvY3VzVmlzaWJsZShlbGVtZW50KSB7XG4gIC8vIFdlIGRvbid0IHdhbnQgdG8gYmxvY2sgZm9jdXMgZnJvbSB3b3JraW5nIHdpdGggYHZpc2libGVPbmx5YFxuICAvLyAoSlNET00gZG9lc24ndCBtYXRjaCBgOmZvY3VzLXZpc2libGVgIHdoZW4gdGhlIGVsZW1lbnQgaGFzIGA6Zm9jdXNgKVxuICBpZiAoIWVsZW1lbnQgfHwgcGxhdGZvcm0uZW52LmpzZG9tKSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgdHJ5IHtcbiAgICByZXR1cm4gZWxlbWVudC5tYXRjaGVzKCc6Zm9jdXMtdmlzaWJsZScpO1xuICB9IGNhdGNoIChfZSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG59XG5leHBvcnQgZnVuY3Rpb24gZ2V0RmxvYXRpbmdGb2N1c0VsZW1lbnQoZmxvYXRpbmdFbGVtZW50KSB7XG4gIGlmICghZmxvYXRpbmdFbGVtZW50KSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgLy8gVHJ5IHRvIGZpbmQgdGhlIGVsZW1lbnQgdGhhdCBoYXMgYHsuLi5nZXRGbG9hdGluZ1Byb3BzKCl9YCBzcHJlYWQgb24gaXQuXG4gIC8vIFRoaXMgaW5kaWNhdGVzIHRoZSBmbG9hdGluZyBlbGVtZW50IGlzIGFjdGluZyBhcyBhIHBvc2l0aW9uaW5nIHdyYXBwZXIsIGFuZFxuICAvLyBzbyBmb2N1cyBzaG91bGQgYmUgbWFuYWdlZCBvbiB0aGUgY2hpbGQgZWxlbWVudCB3aXRoIHRoZSBldmVudCBoYW5kbGVycyBhbmRcbiAgLy8gYXJpYSBwcm9wcy5cbiAgcmV0dXJuIGZsb2F0aW5nRWxlbWVudC5oYXNBdHRyaWJ1dGUoRk9DVVNBQkxFX0FUVFJJQlVURSkgPyBmbG9hdGluZ0VsZW1lbnQgOiBmbG9hdGluZ0VsZW1lbnQucXVlcnlTZWxlY3RvcihgWyR7Rk9DVVNBQkxFX0FUVFJJQlVURX1dYCkgfHwgZmxvYXRpbmdFbGVtZW50O1xufSIsIi8qKlxuICogQ29tYmluZXMgbXVsdGlwbGUgY2xlYW51cCBmdW5jdGlvbnMgaW50byBhIHNpbmdsZSBjbGVhbnVwIGZ1bmN0aW9uLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbWVyZ2VDbGVhbnVwcyguLi5jbGVhbnVwcykge1xuICByZXR1cm4gKCkgPT4ge1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY2xlYW51cHMubGVuZ3RoOyBpICs9IDEpIHtcbiAgICAgIGNvbnN0IGNsZWFudXAgPSBjbGVhbnVwc1tpXTtcbiAgICAgIGlmIChjbGVhbnVwKSB7XG4gICAgICAgIGNsZWFudXAoKTtcbiAgICAgIH1cbiAgICB9XG4gIH07XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tIFwiLi91c2VJc29MYXlvdXRFZmZlY3QubWpzXCI7XG5pbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gXCIuL3VzZVJlZldpdGhJbml0Lm1qc1wiO1xuXG4vKipcbiAqIFVudHJhY2tzIHRoZSBwcm92aWRlZCB2YWx1ZSBieSB0dXJuaW5nIGl0IGludG8gYSByZWYgdG8gcmVtb3ZlIGl0cyByZWFjdGl2aXR5LlxuICpcbiAqIFVzZWQgdG8gYWNjZXNzIHRoZSBwYXNzZWQgdmFsdWUgaW5zaWRlIGBSZWFjdC51c2VFZmZlY3RgIHdpdGhvdXQgY2F1c2luZyB0aGUgZWZmZWN0IHRvIHJlLXJ1biB3aGVuIHRoZSB2YWx1ZSBjaGFuZ2VzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlVmFsdWVBc1JlZih2YWx1ZSkge1xuICBjb25zdCBsYXRlc3QgPSB1c2VSZWZXaXRoSW5pdChjcmVhdGVMYXRlc3RSZWYsIHZhbHVlKS5jdXJyZW50O1xuICBsYXRlc3QubmV4dCA9IHZhbHVlO1xuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KGxhdGVzdC5lZmZlY3QpO1xuICByZXR1cm4gbGF0ZXN0O1xufVxuZnVuY3Rpb24gY3JlYXRlTGF0ZXN0UmVmKHZhbHVlKSB7XG4gIGNvbnN0IGxhdGVzdCA9IHtcbiAgICBjdXJyZW50OiB2YWx1ZSxcbiAgICBuZXh0OiB2YWx1ZSxcbiAgICBlZmZlY3Q6ICgpID0+IHtcbiAgICAgIGxhdGVzdC5jdXJyZW50ID0gbGF0ZXN0Lm5leHQ7XG4gICAgfVxuICB9O1xuICByZXR1cm4gbGF0ZXN0O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHBsYXRmb3JtIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvcGxhdGZvcm0nO1xuaW1wb3J0IHsgdmlzdWFsbHlIaWRkZW4gfSBmcm9tICdAYmFzZS11aS91dGlscy92aXN1YWxseUhpZGRlbic7XG5cbi8qKlxuICogQGludGVybmFsXG4gKi9cbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgY29uc3QgRm9jdXNHdWFyZCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIEZvY3VzR3VhcmQocHJvcHMsIHJlZikge1xuICBjb25zdCBbcm9sZSwgc2V0Um9sZV0gPSBSZWFjdC51c2VTdGF0ZSgpO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIC8vIFVubGlrZSBOVkRBIGFuZCBKQVdTLCBWb2ljZU92ZXIncyB2aXJ0dWFsIGN1cnNvciB0cmlnZ2VycyBgb25Gb2N1c2AgYXNcbiAgICAvLyBpdCBtb3ZlcyDigJQgYnV0IG9ubHkgb24gZm9jdXNhYmxlL3JvbGUtYnV0dG9uIGVsZW1lbnRzIHRocm91Z2ggV2ViS2l0J3NcbiAgICAvLyBOU0FjY2Vzc2liaWxpdHkgcGF0aC4gU2V0dGluZyBgcm9sZT1cImJ1dHRvblwiYCBsZXRzIHRoZSBmb2N1cyB0cmFwIGNhdGNoXG4gICAgLy8gdGhlIGN1cnNvci5cbiAgICBpZiAocGxhdGZvcm0uc2NyZWVuUmVhZGVyLnZvaWNlT3ZlciAmJiBwbGF0Zm9ybS5lbmdpbmUud2Via2l0KSB7XG4gICAgICBzZXRSb2xlKCdidXR0b24nKTtcbiAgICB9XG4gIH0sIFtdKTtcbiAgY29uc3QgcmVzdFByb3BzID0ge1xuICAgIHRhYkluZGV4OiAwLFxuICAgIC8vIFJvbGUgaXMgb25seSBmb3IgVm9pY2VPdmVyXG4gICAgcm9sZVxuICB9O1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goXCJzcGFuXCIsIHtcbiAgICAuLi5wcm9wcyxcbiAgICByZWY6IHJlZixcbiAgICBzdHlsZTogdmlzdWFsbHlIaWRkZW4sXG4gICAgXCJhcmlhLWhpZGRlblwiOiByb2xlID8gdW5kZWZpbmVkIDogdHJ1ZSxcbiAgICAuLi5yZXN0UHJvcHMsXG4gICAgXCJkYXRhLWJhc2UtdWktZm9jdXMtZ3VhcmRcIjogXCJcIlxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRm9jdXNHdWFyZC5kaXNwbGF5TmFtZSA9IFwiRm9jdXNHdWFyZFwiOyIsImltcG9ydCB7IGdldENvbXB1dGVkU3R5bGUsIGdldE5vZGVOYW1lLCBpc0hUTUxFbGVtZW50LCBpc1NoYWRvd1Jvb3QgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IG93bmVyRG9jdW1lbnQgfSBmcm9tICdAYmFzZS11aS91dGlscy9vd25lcic7XG5pbXBvcnQgeyBhY3RpdmVFbGVtZW50LCBjb250YWlucyB9IGZyb20gXCIuL2VsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBpc0VsZW1lbnRWaXNpYmxlIH0gZnJvbSBcIi4vY29tcG9zaXRlLm1qc1wiO1xuY29uc3QgQ0FORElEQVRFX1NFTEVDVE9SID0gJ2FbaHJlZl0sYnV0dG9uLGlucHV0LHNlbGVjdCx0ZXh0YXJlYSxzdW1tYXJ5LGRldGFpbHMsaWZyYW1lLG9iamVjdCxlbWJlZCxbdGFiaW5kZXhdLFtjb250ZW50ZWRpdGFibGVdOm5vdChbY29udGVudGVkaXRhYmxlPVwiZmFsc2VcIl0pLGF1ZGlvW2NvbnRyb2xzXSx2aWRlb1tjb250cm9sc10nO1xuZnVuY3Rpb24gZ2V0UGFyZW50RWxlbWVudChlbGVtZW50KSB7XG4gIGNvbnN0IGFzc2lnbmVkU2xvdCA9IGVsZW1lbnQuYXNzaWduZWRTbG90O1xuICBpZiAoYXNzaWduZWRTbG90KSB7XG4gICAgcmV0dXJuIGFzc2lnbmVkU2xvdDtcbiAgfVxuICBpZiAoZWxlbWVudC5wYXJlbnRFbGVtZW50KSB7XG4gICAgcmV0dXJuIGVsZW1lbnQucGFyZW50RWxlbWVudDtcbiAgfVxuICBjb25zdCByb290Tm9kZSA9IGVsZW1lbnQuZ2V0Um9vdE5vZGUoKTtcbiAgcmV0dXJuIGlzU2hhZG93Um9vdChyb290Tm9kZSkgPyByb290Tm9kZS5ob3N0IDogbnVsbDtcbn1cbmZ1bmN0aW9uIGdldERldGFpbHNTdW1tYXJ5KGRldGFpbHMpIHtcbiAgZm9yIChjb25zdCBjaGlsZCBvZiBBcnJheS5mcm9tKGRldGFpbHMuY2hpbGRyZW4pKSB7XG4gICAgaWYgKGdldE5vZGVOYW1lKGNoaWxkKSA9PT0gJ3N1bW1hcnknKSB7XG4gICAgICByZXR1cm4gY2hpbGQ7XG4gICAgfVxuICB9XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gaXNXaXRoaW5PcGVuRGV0YWlsc1N1bW1hcnkoZWxlbWVudCwgZGV0YWlscykge1xuICBjb25zdCBzdW1tYXJ5ID0gZ2V0RGV0YWlsc1N1bW1hcnkoZGV0YWlscyk7XG4gIHJldHVybiAhIXN1bW1hcnkgJiYgKGVsZW1lbnQgPT09IHN1bW1hcnkgfHwgY29udGFpbnMoc3VtbWFyeSwgZWxlbWVudCkpO1xufVxuZnVuY3Rpb24gaXNGb2N1c2FibGVDYW5kaWRhdGUoZWxlbWVudCkge1xuICBjb25zdCBub2RlTmFtZSA9IGVsZW1lbnQgPyBnZXROb2RlTmFtZShlbGVtZW50KSA6ICcnO1xuICByZXR1cm4gZWxlbWVudCAhPSBudWxsICYmIGVsZW1lbnQubWF0Y2hlcyhDQU5ESURBVEVfU0VMRUNUT1IpICYmIChub2RlTmFtZSAhPT0gJ3N1bW1hcnknIHx8IGVsZW1lbnQucGFyZW50RWxlbWVudCAhPSBudWxsICYmIGdldE5vZGVOYW1lKGVsZW1lbnQucGFyZW50RWxlbWVudCkgPT09ICdkZXRhaWxzJyAmJiBnZXREZXRhaWxzU3VtbWFyeShlbGVtZW50LnBhcmVudEVsZW1lbnQpID09PSBlbGVtZW50KSAmJiAobm9kZU5hbWUgIT09ICdkZXRhaWxzJyB8fCBnZXREZXRhaWxzU3VtbWFyeShlbGVtZW50KSA9PSBudWxsKSAmJiAobm9kZU5hbWUgIT09ICdpbnB1dCcgfHwgZWxlbWVudC50eXBlICE9PSAnaGlkZGVuJyk7XG59XG5mdW5jdGlvbiBpc0ZvY3VzYWJsZUVsZW1lbnQoZWxlbWVudCkge1xuICBpZiAoIWlzRm9jdXNhYmxlQ2FuZGlkYXRlKGVsZW1lbnQpIHx8ICFlbGVtZW50LmlzQ29ubmVjdGVkIHx8IGVsZW1lbnQubWF0Y2hlcygnOmRpc2FibGVkJykpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZm9yIChsZXQgY3VycmVudCA9IGVsZW1lbnQ7IGN1cnJlbnQ7IGN1cnJlbnQgPSBnZXRQYXJlbnRFbGVtZW50KGN1cnJlbnQpKSB7XG4gICAgY29uc3QgaXNBbmNlc3RvciA9IGN1cnJlbnQgIT09IGVsZW1lbnQ7XG4gICAgY29uc3QgaXNTbG90ID0gZ2V0Tm9kZU5hbWUoY3VycmVudCkgPT09ICdzbG90JztcbiAgICBpZiAoY3VycmVudC5oYXNBdHRyaWJ1dGUoJ2luZXJ0JykpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKGlzQW5jZXN0b3IgJiYgZ2V0Tm9kZU5hbWUoY3VycmVudCkgPT09ICdkZXRhaWxzJyAmJiAhY3VycmVudC5vcGVuICYmICFpc1dpdGhpbk9wZW5EZXRhaWxzU3VtbWFyeShlbGVtZW50LCBjdXJyZW50KSB8fCBjdXJyZW50Lmhhc0F0dHJpYnV0ZSgnaGlkZGVuJykgfHwgIWlzU2xvdCAmJiAhaXNWaXNpYmxlSW5UYWJiYWJsZVRyZWUoY3VycmVudCwgaXNBbmNlc3RvcikpIHtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBpc1Zpc2libGVJblRhYmJhYmxlVHJlZShlbGVtZW50LCBpc0FuY2VzdG9yKSB7XG4gIGNvbnN0IHN0eWxlcyA9IGdldENvbXB1dGVkU3R5bGUoZWxlbWVudCk7XG4gIGlmICghaXNBbmNlc3Rvcikge1xuICAgIHJldHVybiBpc0VsZW1lbnRWaXNpYmxlKGVsZW1lbnQsIHN0eWxlcyk7XG4gIH1cbiAgcmV0dXJuIHN0eWxlcy5kaXNwbGF5ICE9PSAnbm9uZSc7XG59XG5mdW5jdGlvbiBnZXRUYWJJbmRleChlbGVtZW50KSB7XG4gIGNvbnN0IHRhYkluZGV4ID0gZWxlbWVudC50YWJJbmRleDtcbiAgaWYgKHRhYkluZGV4IDwgMCkge1xuICAgIGNvbnN0IG5vZGVOYW1lID0gZ2V0Tm9kZU5hbWUoZWxlbWVudCk7XG4gICAgaWYgKG5vZGVOYW1lID09PSAnZGV0YWlscycgfHwgbm9kZU5hbWUgPT09ICdhdWRpbycgfHwgbm9kZU5hbWUgPT09ICd2aWRlbycgfHwgaXNIVE1MRWxlbWVudChlbGVtZW50KSAmJiBlbGVtZW50LmlzQ29udGVudEVkaXRhYmxlKSB7XG4gICAgICByZXR1cm4gMDtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHRhYkluZGV4O1xufVxuZnVuY3Rpb24gZ2V0TmFtZWRSYWRpb0lucHV0KGVsZW1lbnQpIHtcbiAgaWYgKGdldE5vZGVOYW1lKGVsZW1lbnQpICE9PSAnaW5wdXQnKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgaW5wdXQgPSBlbGVtZW50O1xuICByZXR1cm4gaW5wdXQudHlwZSA9PT0gJ3JhZGlvJyAmJiBpbnB1dC5uYW1lICE9PSAnJyA/IGlucHV0IDogbnVsbDtcbn1cbmZ1bmN0aW9uIGlzVGFiYmFibGVSYWRpbyhlbGVtZW50LCBjYW5kaWRhdGVzKSB7XG4gIGNvbnN0IGlucHV0ID0gZ2V0TmFtZWRSYWRpb0lucHV0KGVsZW1lbnQpO1xuICBpZiAoIWlucHV0KSB7XG4gICAgcmV0dXJuIHRydWU7XG4gIH1cbiAgY29uc3QgY2hlY2tlZFJhZGlvID0gY2FuZGlkYXRlcy5maW5kKGNhbmRpZGF0ZSA9PiB7XG4gICAgY29uc3QgcmFkaW8gPSBnZXROYW1lZFJhZGlvSW5wdXQoY2FuZGlkYXRlKTtcbiAgICByZXR1cm4gcmFkaW8/Lm5hbWUgPT09IGlucHV0Lm5hbWUgJiYgcmFkaW8uZm9ybSA9PT0gaW5wdXQuZm9ybSAmJiByYWRpby5jaGVja2VkO1xuICB9KTtcbiAgaWYgKGNoZWNrZWRSYWRpbykge1xuICAgIHJldHVybiBjaGVja2VkUmFkaW8gPT09IGlucHV0O1xuICB9XG4gIHJldHVybiBjYW5kaWRhdGVzLmZpbmQoY2FuZGlkYXRlID0+IHtcbiAgICBjb25zdCByYWRpbyA9IGdldE5hbWVkUmFkaW9JbnB1dChjYW5kaWRhdGUpO1xuICAgIHJldHVybiByYWRpbz8ubmFtZSA9PT0gaW5wdXQubmFtZSAmJiByYWRpby5mb3JtID09PSBpbnB1dC5mb3JtO1xuICB9KSA9PT0gaW5wdXQ7XG59XG5mdW5jdGlvbiBnZXRDb21wb3NlZENoaWxkcmVuKGNvbnRhaW5lcikge1xuICBpZiAoaXNIVE1MRWxlbWVudChjb250YWluZXIpICYmIGdldE5vZGVOYW1lKGNvbnRhaW5lcikgPT09ICdzbG90Jykge1xuICAgIGNvbnN0IGFzc2lnbmVkRWxlbWVudHMgPSBjb250YWluZXIuYXNzaWduZWRFbGVtZW50cyh7XG4gICAgICBmbGF0dGVuOiB0cnVlXG4gICAgfSk7XG4gICAgaWYgKGFzc2lnbmVkRWxlbWVudHMubGVuZ3RoID4gMCkge1xuICAgICAgcmV0dXJuIGFzc2lnbmVkRWxlbWVudHM7XG4gICAgfVxuICB9XG4gIGlmIChpc0hUTUxFbGVtZW50KGNvbnRhaW5lcikgJiYgY29udGFpbmVyLnNoYWRvd1Jvb3QpIHtcbiAgICByZXR1cm4gQXJyYXkuZnJvbShjb250YWluZXIuc2hhZG93Um9vdC5jaGlsZHJlbik7XG4gIH1cbiAgcmV0dXJuIEFycmF5LmZyb20oY29udGFpbmVyLmNoaWxkcmVuKTtcbn1cbmZ1bmN0aW9uIGFwcGVuZENhbmRpZGF0ZXMoY29udGFpbmVyLCBsaXN0KSB7XG4gIGdldENvbXBvc2VkQ2hpbGRyZW4oY29udGFpbmVyKS5mb3JFYWNoKGNoaWxkID0+IHtcbiAgICBpZiAoaXNGb2N1c2FibGVDYW5kaWRhdGUoY2hpbGQpKSB7XG4gICAgICBsaXN0LnB1c2goY2hpbGQpO1xuICAgIH1cbiAgICBhcHBlbmRDYW5kaWRhdGVzKGNoaWxkLCBsaXN0KTtcbiAgfSk7XG59XG5mdW5jdGlvbiBhcHBlbmRNYXRjaGluZ0VsZW1lbnRzKGNvbnRhaW5lciwgc2VsZWN0b3IsIGxpc3QpIHtcbiAgZ2V0Q29tcG9zZWRDaGlsZHJlbihjb250YWluZXIpLmZvckVhY2goY2hpbGQgPT4ge1xuICAgIGlmIChpc0hUTUxFbGVtZW50KGNoaWxkKSAmJiBjaGlsZC5tYXRjaGVzKHNlbGVjdG9yKSkge1xuICAgICAgbGlzdC5wdXNoKGNoaWxkKTtcbiAgICB9XG4gICAgYXBwZW5kTWF0Y2hpbmdFbGVtZW50cyhjaGlsZCwgc2VsZWN0b3IsIGxpc3QpO1xuICB9KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc1RhYmJhYmxlKGVsZW1lbnQpIHtcbiAgcmV0dXJuIGlzRm9jdXNhYmxlRWxlbWVudChlbGVtZW50KSAmJiBnZXRUYWJJbmRleChlbGVtZW50KSA+PSAwO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZvY3VzYWJsZShjb250YWluZXIpIHtcbiAgY29uc3QgY2FuZGlkYXRlcyA9IFtdO1xuICBhcHBlbmRDYW5kaWRhdGVzKGNvbnRhaW5lciwgY2FuZGlkYXRlcyk7XG4gIHJldHVybiBjYW5kaWRhdGVzLmZpbHRlcihpc0ZvY3VzYWJsZUVsZW1lbnQpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHRhYmJhYmxlKGNvbnRhaW5lcikge1xuICBjb25zdCBjYW5kaWRhdGVzID0gZm9jdXNhYmxlKGNvbnRhaW5lcik7XG4gIHJldHVybiBjYW5kaWRhdGVzLmZpbHRlcihlbGVtZW50ID0+IGdldFRhYkluZGV4KGVsZW1lbnQpID49IDAgJiYgaXNUYWJiYWJsZVJhZGlvKGVsZW1lbnQsIGNhbmRpZGF0ZXMpKTtcbn1cbmZ1bmN0aW9uIGdldFRhYmJhYmxlSW4oY29udGFpbmVyLCBkaXIpIHtcbiAgY29uc3QgbGlzdCA9IHRhYmJhYmxlKGNvbnRhaW5lcik7XG4gIGNvbnN0IGxlbiA9IGxpc3QubGVuZ3RoO1xuICBpZiAobGVuID09PSAwKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICBjb25zdCBhY3RpdmUgPSBhY3RpdmVFbGVtZW50KG93bmVyRG9jdW1lbnQoY29udGFpbmVyKSk7XG4gIGNvbnN0IGluZGV4ID0gbGlzdC5pbmRleE9mKGFjdGl2ZSk7XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1uZXN0ZWQtdGVybmFyeVxuICBjb25zdCBuZXh0SW5kZXggPSBpbmRleCA9PT0gLTEgPyBkaXIgPT09IDEgPyAwIDogbGVuIC0gMSA6IGluZGV4ICsgZGlyO1xuICByZXR1cm4gbGlzdFtuZXh0SW5kZXhdO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdldE5leHRUYWJiYWJsZShyZWZlcmVuY2VFbGVtZW50KSB7XG4gIHJldHVybiBnZXRUYWJiYWJsZUluKG93bmVyRG9jdW1lbnQocmVmZXJlbmNlRWxlbWVudCkuYm9keSwgMSkgfHwgcmVmZXJlbmNlRWxlbWVudDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRQcmV2aW91c1RhYmJhYmxlKHJlZmVyZW5jZUVsZW1lbnQpIHtcbiAgcmV0dXJuIGdldFRhYmJhYmxlSW4ob3duZXJEb2N1bWVudChyZWZlcmVuY2VFbGVtZW50KS5ib2R5LCAtMSkgfHwgcmVmZXJlbmNlRWxlbWVudDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRUYWJiYWJsZU5lYXJFbGVtZW50KHJlZmVyZW5jZUVsZW1lbnQsIGRpcmVjdGlvbiwgZXhjbHVkZSkge1xuICBpZiAoIXJlZmVyZW5jZUVsZW1lbnQpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIC8vIEtlZXAgdGhlIGFuY2hvcidzIGNvbXBvc2VkLXRyZWUgcG9zaXRpb24gc2VwYXJhdGUgZnJvbSB0aGUgZm9jdXNhYmxlIHJhZGlvIGNhbmRpZGF0ZXMuXG4gIGNvbnN0IGxpc3QgPSBbXTtcbiAgYXBwZW5kQ2FuZGlkYXRlcyhvd25lckRvY3VtZW50KHJlZmVyZW5jZUVsZW1lbnQpLmJvZHksIGxpc3QpO1xuICBjb25zdCBpbmRleCA9IGxpc3QuaW5kZXhPZihyZWZlcmVuY2VFbGVtZW50KTtcbiAgaWYgKGluZGV4ID09PSAtMSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGNvbnN0IGNhbmRpZGF0ZXMgPSBsaXN0LmZpbHRlcihpc0ZvY3VzYWJsZUVsZW1lbnQpO1xuICBmb3IgKGxldCBvZmZzZXQgPSAxOyBvZmZzZXQgPCBsaXN0Lmxlbmd0aDsgb2Zmc2V0ICs9IDEpIHtcbiAgICBjb25zdCBlbGVtZW50ID0gbGlzdFsoaW5kZXggKyBkaXJlY3Rpb24gKiBvZmZzZXQgKyBsaXN0Lmxlbmd0aCkgJSBsaXN0Lmxlbmd0aF07XG4gICAgaWYgKCFjb250YWlucyhleGNsdWRlLCBlbGVtZW50KSAmJiBpc1RhYmJhYmxlKGVsZW1lbnQpICYmIGlzVGFiYmFibGVSYWRpbyhlbGVtZW50LCBjYW5kaWRhdGVzKSkge1xuICAgICAgcmV0dXJuIGVsZW1lbnQ7XG4gICAgfVxuICB9XG4gIHJldHVybiBsaXN0W2luZGV4XTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc091dHNpZGVFdmVudChldmVudCwgY29udGFpbmVyKSB7XG4gIGNvbnN0IGNvbnRhaW5lckVsZW1lbnQgPSBjb250YWluZXIgfHwgZXZlbnQuY3VycmVudFRhcmdldDtcbiAgY29uc3QgcmVsYXRlZFRhcmdldCA9IGV2ZW50LnJlbGF0ZWRUYXJnZXQ7XG4gIHJldHVybiAhcmVsYXRlZFRhcmdldCB8fCAhY29udGFpbnMoY29udGFpbmVyRWxlbWVudCwgcmVsYXRlZFRhcmdldCk7XG59XG5leHBvcnQgZnVuY3Rpb24gZGlzYWJsZUZvY3VzSW5zaWRlKGNvbnRhaW5lcikge1xuICBjb25zdCB0YWJiYWJsZUVsZW1lbnRzID0gdGFiYmFibGUoY29udGFpbmVyKTtcbiAgdGFiYmFibGVFbGVtZW50cy5mb3JFYWNoKGVsZW1lbnQgPT4ge1xuICAgIGVsZW1lbnQuZGF0YXNldC50YWJpbmRleCA9IGVsZW1lbnQuZ2V0QXR0cmlidXRlKCd0YWJpbmRleCcpIHx8ICcnO1xuICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlKCd0YWJpbmRleCcsICctMScpO1xuICB9KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBlbmFibGVGb2N1c0luc2lkZShjb250YWluZXIpIHtcbiAgY29uc3QgZWxlbWVudHMgPSBbXTtcbiAgYXBwZW5kTWF0Y2hpbmdFbGVtZW50cyhjb250YWluZXIsICdbZGF0YS10YWJpbmRleF0nLCBlbGVtZW50cyk7XG4gIGVsZW1lbnRzLmZvckVhY2goZWxlbWVudCA9PiB7XG4gICAgY29uc3QgdGFiaW5kZXggPSBlbGVtZW50LmRhdGFzZXQudGFiaW5kZXg7XG4gICAgZGVsZXRlIGVsZW1lbnQuZGF0YXNldC50YWJpbmRleDtcbiAgICBpZiAodGFiaW5kZXgpIHtcbiAgICAgIGVsZW1lbnQuc2V0QXR0cmlidXRlKCd0YWJpbmRleCcsIHRhYmluZGV4KTtcbiAgICB9IGVsc2Uge1xuICAgICAgZWxlbWVudC5yZW1vdmVBdHRyaWJ1dGUoJ3RhYmluZGV4Jyk7XG4gICAgfVxuICB9KTtcbn0iLCIvKiBlc2xpbnQtZGlzYWJsZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tbG9vcC1mdW5jICovXG5cbmV4cG9ydCBmdW5jdGlvbiBnZXROb2RlQ2hpbGRyZW4obm9kZXMsIGlkLCBvbmx5T3BlbkNoaWxkcmVuID0gdHJ1ZSkge1xuICBjb25zdCBkaXJlY3RDaGlsZHJlbiA9IG5vZGVzLmZpbHRlcihub2RlID0+IG5vZGUucGFyZW50SWQgPT09IGlkKTtcbiAgcmV0dXJuIGRpcmVjdENoaWxkcmVuLmZsYXRNYXAoY2hpbGQgPT4gWy4uLighb25seU9wZW5DaGlsZHJlbiB8fCBjaGlsZC5jb250ZXh0Py5vcGVuID8gW2NoaWxkXSA6IFtdKSwgLi4uZ2V0Tm9kZUNoaWxkcmVuKG5vZGVzLCBjaGlsZC5pZCwgb25seU9wZW5DaGlsZHJlbildKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXROb2RlQW5jZXN0b3JzKG5vZGVzLCBpZCkge1xuICBsZXQgYWxsQW5jZXN0b3JzID0gW107XG4gIGxldCBjdXJyZW50UGFyZW50SWQgPSBub2Rlcy5maW5kKG5vZGUgPT4gbm9kZS5pZCA9PT0gaWQpPy5wYXJlbnRJZDtcbiAgd2hpbGUgKGN1cnJlbnRQYXJlbnRJZCkge1xuICAgIGNvbnN0IGN1cnJlbnROb2RlID0gbm9kZXMuZmluZChub2RlID0+IG5vZGUuaWQgPT09IGN1cnJlbnRQYXJlbnRJZCk7XG4gICAgY3VycmVudFBhcmVudElkID0gY3VycmVudE5vZGU/LnBhcmVudElkO1xuICAgIGlmIChjdXJyZW50Tm9kZSkge1xuICAgICAgYWxsQW5jZXN0b3JzID0gYWxsQW5jZXN0b3JzLmNvbmNhdChjdXJyZW50Tm9kZSk7XG4gICAgfVxuICB9XG4gIHJldHVybiBhbGxBbmNlc3RvcnM7XG59IiwiZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUF0dHJpYnV0ZShuYW1lKSB7XG4gIHJldHVybiBgZGF0YS1iYXNlLXVpLSR7bmFtZX1gO1xufSIsImV4cG9ydCBjb25zdCBUWVBFQUhFQURfUkVTRVRfTVMgPSA1MDA7XG5leHBvcnQgY29uc3QgUEFUSUVOVF9DTElDS19USFJFU0hPTEQgPSA1MDA7XG5leHBvcnQgY29uc3QgRElTQUJMRURfVFJBTlNJVElPTlNfU1RZTEUgPSB7XG4gIHN0eWxlOiB7XG4gICAgdHJhbnNpdGlvbjogJ25vbmUnXG4gIH1cbn07XG5leHBvcnQgY29uc3QgQ0xJQ0tfVFJJR0dFUl9JREVOVElGSUVSID0gJ2RhdGEtYmFzZS11aS1jbGljay10cmlnZ2VyJztcbmV4cG9ydCBjb25zdCBCQVNFX1VJX1NXSVBFX0lHTk9SRV9BVFRSSUJVVEUgPSAnZGF0YS1iYXNlLXVpLXN3aXBlLWlnbm9yZSc7XG5leHBvcnQgY29uc3QgTEVHQUNZX1NXSVBFX0lHTk9SRV9BVFRSSUJVVEUgPSAnZGF0YS1zd2lwZS1pZ25vcmUnO1xuZXhwb3J0IGNvbnN0IEJBU0VfVUlfU1dJUEVfSUdOT1JFX1NFTEVDVE9SID0gYFske0JBU0VfVUlfU1dJUEVfSUdOT1JFX0FUVFJJQlVURX1dYDtcbmV4cG9ydCBjb25zdCBMRUdBQ1lfU1dJUEVfSUdOT1JFX1NFTEVDVE9SID0gYFske0xFR0FDWV9TV0lQRV9JR05PUkVfQVRUUklCVVRFfV1gO1xuXG4vKipcbiAqIFVzZWQgZm9yIGRyb3Bkb3ducyB0aGF0IHVzdWFsbHkgc3RyaWN0bHkgcHJlZmVyIHRvcC9ib3R0b20gcGxhY2VtZW50cyBhbmRcbiAqIHVzZSBgdmFyKC0tYXZhaWxhYmxlLWhlaWdodClgIHRvIGxpbWl0IHRoZWlyIGhlaWdodC5cbiAqL1xuZXhwb3J0IGNvbnN0IERST1BET1dOX0NPTExJU0lPTl9BVk9JREFOQ0UgPSB7XG4gIGZhbGxiYWNrQXhpc1NpZGU6ICdub25lJ1xufTtcblxuLyoqXG4gKiBVc2VkIGJ5IHJlZ3VsYXIgcG9wdXBzIHRoYXQgdXN1YWxseSBhcmVuJ3Qgc2Nyb2xsYWJsZSBhbmQgYXJlIGFsbG93ZWQgdG9cbiAqIGZyZWVseSBmbGlwIHRvIGFueSBheGlzIG9mIHBsYWNlbWVudC5cbiAqL1xuZXhwb3J0IGNvbnN0IFBPUFVQX0NPTExJU0lPTl9BVk9JREFOQ0UgPSB7XG4gIGZhbGxiYWNrQXhpc1NpZGU6ICdlbmQnXG59O1xuXG4vKipcbiAqIFNwZWNpYWwgdmlzdWFsbHkgaGlkZGVuIHN0eWxlcyBmb3IgdGhlIGFyaWEtb3ducyBvd25lciBlbGVtZW50IHRvIGVuc3VyZSBvd25lZCBlbGVtZW50XG4gKiBhY2Nlc3NpYmlsaXR5IGluIGlPUy9TYWZhcmkvVm9pY2VDb250cm9sLlxuICogVGhlIG93bmVyIGVsZW1lbnQgaXMgYW4gZW1wdHkgc3Bhbiwgc28gbW9zdCBvZiB0aGUgY29tbW9uIHZpc3VhbGx5IGhpZGRlbiBzdHlsZXMgYXJlIG5vdCBuZWVkZWQuXG4gKiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9mbG9hdGluZy11aS9mbG9hdGluZy11aS9pc3N1ZXMvMzQwM1xuICovXG5leHBvcnQgY29uc3Qgb3duZXJWaXN1YWxseUhpZGRlbiA9IHtcbiAgY2xpcFBhdGg6ICdpbnNldCg1MCUpJyxcbiAgcG9zaXRpb246ICdmaXhlZCcsXG4gIHRvcDogMCxcbiAgbGVmdDogMFxufTsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCAqIGFzIFJlYWN0RE9NIGZyb20gJ3JlYWN0LWRvbSc7XG5pbXBvcnQgeyBpc05vZGUgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IGFkZEV2ZW50TGlzdGVuZXIgfSBmcm9tICdAYmFzZS11aS91dGlscy9hZGRFdmVudExpc3RlbmVyJztcbmltcG9ydCB7IG1lcmdlQ2xlYW51cHMgfSBmcm9tICdAYmFzZS11aS91dGlscy9tZXJnZUNsZWFudXBzJztcbmltcG9ydCB7IHVzZUlkIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSWQnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuaW1wb3J0IHsgRU1QVFlfT0JKRUNUIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuaW1wb3J0IHsgRm9jdXNHdWFyZCB9IGZyb20gXCIuLi8uLi91dGlscy9Gb2N1c0d1YXJkLm1qc1wiO1xuaW1wb3J0IHsgZW5hYmxlRm9jdXNJbnNpZGUsIGRpc2FibGVGb2N1c0luc2lkZSwgZ2V0UHJldmlvdXNUYWJiYWJsZSwgZ2V0TmV4dFRhYmJhYmxlLCBpc091dHNpZGVFdmVudCB9IGZyb20gXCIuLi91dGlscy90YWJiYWJsZS5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY3JlYXRlQmFzZVVJRXZlbnREZXRhaWxzLm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUF0dHJpYnV0ZSB9IGZyb20gXCIuLi91dGlscy9jcmVhdGVBdHRyaWJ1dGUubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgb3duZXJWaXN1YWxseUhpZGRlbiB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY29uc3RhbnRzLm1qc1wiO1xuaW1wb3J0IHsganN4IGFzIF9qc3gsIGpzeHMgYXMgX2pzeHMgfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmNvbnN0IFBvcnRhbENvbnRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlQ29udGV4dChudWxsKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIFBvcnRhbENvbnRleHQuZGlzcGxheU5hbWUgPSBcIlBvcnRhbENvbnRleHRcIjtcbmV4cG9ydCBjb25zdCB1c2VQb3J0YWxDb250ZXh0ID0gKCkgPT4gUmVhY3QudXNlQ29udGV4dChQb3J0YWxDb250ZXh0KTtcbmNvbnN0IGF0dHIgPSBjcmVhdGVBdHRyaWJ1dGUoJ3BvcnRhbCcpO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUZsb2F0aW5nUG9ydGFsTm9kZShwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICByZWYsXG4gICAgY29udGFpbmVyOiBjb250YWluZXJQcm9wLFxuICAgIGNvbXBvbmVudFByb3BzID0gRU1QVFlfT0JKRUNULFxuICAgIGVsZW1lbnRQcm9wc1xuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHVuaXF1ZUlkID0gdXNlSWQoKTtcbiAgY29uc3QgcG9ydGFsQ29udGV4dCA9IHVzZVBvcnRhbENvbnRleHQoKTtcbiAgY29uc3QgcGFyZW50UG9ydGFsTm9kZSA9IHBvcnRhbENvbnRleHQ/LnBvcnRhbE5vZGU7XG4gIGNvbnN0IFtjb250YWluZXJFbGVtZW50LCBzZXRDb250YWluZXJFbGVtZW50XSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbcG9ydGFsTm9kZSwgc2V0UG9ydGFsTm9kZV0gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcbiAgY29uc3Qgc2V0UG9ydGFsTm9kZVJlZiA9IHVzZVN0YWJsZUNhbGxiYWNrKG5vZGUgPT4ge1xuICAgIGlmIChub2RlICE9PSBudWxsKSB7XG4gICAgICAvLyB0aGUgdXNlSXNvTGF5b3V0RWZmZWN0IGJlbG93IHdhdGNoaW5nIGNvbnRhaW5lclByb3AgLyBwYXJlbnRQb3J0YWxOb2RlXG4gICAgICAvLyBzZXRzIHNldFBvcnRhbE5vZGUobnVsbCkgd2hlbiB0aGUgY29udGFpbmVyIGJlY29tZXMgbnVsbCBvciBjaGFuZ2VzLlxuICAgICAgLy8gU28gZXZlbiB0aG91Z2ggdGhlIHJlZiBjYWxsYmFjayBub3cgaWdub3JlcyBudWxsLCB0aGUgcG9ydGFsIG5vZGUgc3RpbGwgZ2V0cyBjbGVhcmVkLlxuICAgICAgc2V0UG9ydGFsTm9kZShub2RlKTtcbiAgICB9XG4gIH0pO1xuICBjb25zdCBjb250YWluZXJSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgLy8gV2FpdCBmb3IgdGhlIGNvbnRhaW5lciB0byBiZSByZXNvbHZlZCBpZiBleHBsaWNpdGx5IGBudWxsYC5cbiAgICBpZiAoY29udGFpbmVyUHJvcCA9PT0gbnVsbCkge1xuICAgICAgaWYgKGNvbnRhaW5lclJlZi5jdXJyZW50KSB7XG4gICAgICAgIGNvbnRhaW5lclJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgc2V0UG9ydGFsTm9kZShudWxsKTtcbiAgICAgICAgc2V0Q29udGFpbmVyRWxlbWVudChudWxsKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgcmVzb2x2ZWRDb250YWluZXIgPSAoY29udGFpbmVyUHJvcCAmJiAoaXNOb2RlKGNvbnRhaW5lclByb3ApID8gY29udGFpbmVyUHJvcCA6IGNvbnRhaW5lclByb3AuY3VycmVudCkpID8/IHBhcmVudFBvcnRhbE5vZGUgPz8gZG9jdW1lbnQuYm9keTtcbiAgICBpZiAocmVzb2x2ZWRDb250YWluZXIgPT0gbnVsbCkge1xuICAgICAgaWYgKGNvbnRhaW5lclJlZi5jdXJyZW50KSB7XG4gICAgICAgIGNvbnRhaW5lclJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgc2V0UG9ydGFsTm9kZShudWxsKTtcbiAgICAgICAgc2V0Q29udGFpbmVyRWxlbWVudChudWxsKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGNvbnRhaW5lclJlZi5jdXJyZW50ICE9PSByZXNvbHZlZENvbnRhaW5lcikge1xuICAgICAgY29udGFpbmVyUmVmLmN1cnJlbnQgPSByZXNvbHZlZENvbnRhaW5lcjtcbiAgICAgIHNldFBvcnRhbE5vZGUobnVsbCk7XG4gICAgICBzZXRDb250YWluZXJFbGVtZW50KHJlc29sdmVkQ29udGFpbmVyKTtcbiAgICB9XG4gIH0sIFtjb250YWluZXJQcm9wLCBwYXJlbnRQb3J0YWxOb2RlXSk7XG4gIGNvbnN0IHBvcnRhbEVsZW1lbnQgPSB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHJlZjogW3JlZiwgc2V0UG9ydGFsTm9kZVJlZl0sXG4gICAgcHJvcHM6IFt7XG4gICAgICBpZDogdW5pcXVlSWQsXG4gICAgICBbYXR0cl06ICcnXG4gICAgfSwgZWxlbWVudFByb3BzXVxuICB9KTtcblxuICAvLyBUaGlzIGBjcmVhdGVQb3J0YWxgIGNhbGwgaW5qZWN0cyBgcG9ydGFsRWxlbWVudGAgaW50byB0aGUgYGNvbnRhaW5lcmAuXG4gIC8vIEFub3RoZXIgY2FsbCBpbnNpZGUgYEZsb2F0aW5nUG9ydGFsYC9gRmxvYXRpbmdQb3J0YWxMaXRlYCB0aGVuIGluamVjdHMgdGhlIGNoaWxkcmVuIGludG8gYHBvcnRhbEVsZW1lbnRgLlxuICBjb25zdCBwb3J0YWxTdWJ0cmVlID0gY29udGFpbmVyRWxlbWVudCAmJiBwb3J0YWxFbGVtZW50ID8gLyojX19QVVJFX18qL1JlYWN0RE9NLmNyZWF0ZVBvcnRhbChwb3J0YWxFbGVtZW50LCBjb250YWluZXJFbGVtZW50KSA6IG51bGw7XG4gIHJldHVybiB7XG4gICAgbm9kZTogcG9ydGFsTm9kZSxcbiAgICAvLyBgaWRgIGFuZCBgcmVuZGVyYCBwcm9wcyBjYW4gb3ZlcnJpZGUgb3IgcmVtb3ZlIHRoZSBnZW5lcmF0ZWQgSUQuIFVzZSB0aGUgZXhhY3RcbiAgICAvLyByZW5kZXJlZCB2YWx1ZSBzbyBgYXJpYS1vd25zYCBuZXZlciBwb2ludHMgYXQgYW4gSUQgYWJzZW50IGZyb20gdGhlIERPTS5cbiAgICBub2RlSWQ6IC8qI19fUFVSRV9fKi9SZWFjdC5pc1ZhbGlkRWxlbWVudChwb3J0YWxFbGVtZW50KSA/IHBvcnRhbEVsZW1lbnQucHJvcHMuaWQgOiB1bmRlZmluZWQsXG4gICAgc3VidHJlZTogcG9ydGFsU3VidHJlZVxuICB9O1xufVxuXG4vKipcbiAqIFBvcnRhbHMgdGhlIGZsb2F0aW5nIGVsZW1lbnQgaW50byBhIGdpdmVuIGNvbnRhaW5lciBlbGVtZW50IOKAlCBieSBkZWZhdWx0LFxuICogb3V0c2lkZSBvZiB0aGUgYXBwIHJvb3QgYW5kIGludG8gdGhlIGJvZHkuXG4gKiBUaGlzIGlzIG5lY2Vzc2FyeSB0byBlbnN1cmUgdGhlIGZsb2F0aW5nIGVsZW1lbnQgY2FuIGFwcGVhciBvdXRzaWRlIGFueVxuICogcG90ZW50aWFsIHBhcmVudCBjb250YWluZXJzIHRoYXQgY2F1c2UgY2xpcHBpbmcgKHN1Y2ggYXMgYG92ZXJmbG93OiBoaWRkZW5gKSxcbiAqIHdoaWxlIHJldGFpbmluZyBpdHMgbG9jYXRpb24gaW4gdGhlIFJlYWN0IHRyZWUuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvRmxvYXRpbmdQb3J0YWxcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgY29uc3QgRmxvYXRpbmdQb3J0YWwgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBGbG9hdGluZ1BvcnRhbChjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIGNoaWxkcmVuLFxuICAgIGNvbnRhaW5lcixcbiAgICBwb3J0YWxPd25lclJvbGUsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qge1xuICAgIG5vZGU6IHBvcnRhbE5vZGUsXG4gICAgbm9kZUlkOiBwb3J0YWxOb2RlSWQsXG4gICAgc3VidHJlZTogcG9ydGFsU3VidHJlZVxuICB9ID0gdXNlRmxvYXRpbmdQb3J0YWxOb2RlKHtcbiAgICBjb250YWluZXIsXG4gICAgcmVmOiBmb3J3YXJkZWRSZWYsXG4gICAgY29tcG9uZW50UHJvcHMsXG4gICAgZWxlbWVudFByb3BzXG4gIH0pO1xuICBjb25zdCBiZWZvcmVPdXRzaWRlUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBhZnRlck91dHNpZGVSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGJlZm9yZUluc2lkZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgYWZ0ZXJJbnNpZGVSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IFtmb2N1c01hbmFnZXJTdGF0ZSwgc2V0Rm9jdXNNYW5hZ2VyU3RhdGVdID0gUmVhY3QudXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IGZvY3VzSW5zaWRlRGlzYWJsZWRSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBjb25zdCBtb2RhbCA9IGZvY3VzTWFuYWdlclN0YXRlPy5tb2RhbDtcbiAgY29uc3Qgb3BlbiA9IGZvY3VzTWFuYWdlclN0YXRlPy5vcGVuO1xuICBjb25zdCBzaG91bGRSZW5kZXJHdWFyZHMgPSAhIWZvY3VzTWFuYWdlclN0YXRlICYmICFmb2N1c01hbmFnZXJTdGF0ZS5tb2RhbCAmJiBmb2N1c01hbmFnZXJTdGF0ZS5vcGVuICYmICEhcG9ydGFsTm9kZTtcblxuICAvLyBodHRwczovL2NvZGVzYW5kYm94LmlvL3MvdGFiYmFibGUtcG9ydGFsLWY0dG5nP2ZpbGU9L3NyYy9UYWJiYWJsZVBvcnRhbC50c3hcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXBvcnRhbE5vZGUgfHwgbW9kYWwpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgLy8gTWFrZSBzdXJlIGVsZW1lbnRzIGluc2lkZSB0aGUgcG9ydGFsIGVsZW1lbnQgYXJlIHRhYmJhYmxlIG9ubHkgd2hlbiB0aGVcbiAgICAvLyBwb3J0YWwgaGFzIGFscmVhZHkgYmVlbiBmb2N1c2VkLCBlaXRoZXIgYnkgdGFiYmluZyBpbnRvIGEgZm9jdXMgdHJhcFxuICAgIC8vIGVsZW1lbnQgb3V0c2lkZSBvciB1c2luZyB0aGUgbW91c2UuXG4gICAgZnVuY3Rpb24gb25Gb2N1cyhldmVudCkge1xuICAgICAgaWYgKHBvcnRhbE5vZGUgJiYgZXZlbnQucmVsYXRlZFRhcmdldCAmJiBpc091dHNpZGVFdmVudChldmVudCkpIHtcbiAgICAgICAgaWYgKGV2ZW50LnR5cGUgPT09ICdmb2N1c2luJykge1xuICAgICAgICAgIGlmIChmb2N1c0luc2lkZURpc2FibGVkUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIGVuYWJsZUZvY3VzSW5zaWRlKHBvcnRhbE5vZGUpO1xuICAgICAgICAgICAgZm9jdXNJbnNpZGVEaXNhYmxlZFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGRpc2FibGVGb2N1c0luc2lkZShwb3J0YWxOb2RlKTtcbiAgICAgICAgICBmb2N1c0luc2lkZURpc2FibGVkUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gTGlzdGVuIHRvIHRoZSBldmVudCBvbiB0aGUgY2FwdHVyZSBwaGFzZSBzbyB0aGV5IHJ1biBiZWZvcmUgdGhlIGZvY3VzXG4gICAgLy8gdHJhcCBlbGVtZW50cyBvbkZvY3VzIHByb3AgaXMgY2FsbGVkLlxuICAgIHJldHVybiBtZXJnZUNsZWFudXBzKGFkZEV2ZW50TGlzdGVuZXIocG9ydGFsTm9kZSwgJ2ZvY3VzaW4nLCBvbkZvY3VzLCB0cnVlKSwgYWRkRXZlbnRMaXN0ZW5lcihwb3J0YWxOb2RlLCAnZm9jdXNvdXQnLCBvbkZvY3VzLCB0cnVlKSk7XG4gIH0sIFtwb3J0YWxOb2RlLCBtb2RhbF0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghcG9ydGFsTm9kZSB8fCBvcGVuICE9PSB0cnVlIHx8ICFmb2N1c0luc2lkZURpc2FibGVkUmVmLmN1cnJlbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBSZXN0b3JlIHRhYmJhYmlsaXR5IGJlZm9yZSB0aGUgZm9jdXMgbWFuYWdlcidzIHF1ZXVlZCBmb2N1cy1vbi1vcGVuIHN0ZXAgcnVucy5cbiAgICBlbmFibGVGb2N1c0luc2lkZShwb3J0YWxOb2RlKTtcbiAgICBmb2N1c0luc2lkZURpc2FibGVkUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgfSwgW29wZW4sIHBvcnRhbE5vZGVdKTtcbiAgY29uc3QgcG9ydGFsQ29udGV4dFZhbHVlID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIGJlZm9yZU91dHNpZGVSZWYsXG4gICAgYWZ0ZXJPdXRzaWRlUmVmLFxuICAgIGJlZm9yZUluc2lkZVJlZixcbiAgICBhZnRlckluc2lkZVJlZixcbiAgICBwb3J0YWxOb2RlLFxuICAgIHNldEZvY3VzTWFuYWdlclN0YXRlXG4gIH0pLCBbcG9ydGFsTm9kZV0pO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3hzKFJlYWN0LkZyYWdtZW50LCB7XG4gICAgY2hpbGRyZW46IFtwb3J0YWxTdWJ0cmVlLCAvKiNfX1BVUkVfXyovX2pzeHMoUG9ydGFsQ29udGV4dC5Qcm92aWRlciwge1xuICAgICAgdmFsdWU6IHBvcnRhbENvbnRleHRWYWx1ZSxcbiAgICAgIGNoaWxkcmVuOiBbc2hvdWxkUmVuZGVyR3VhcmRzICYmIHBvcnRhbE5vZGUgJiYgLyojX19QVVJFX18qL19qc3goRm9jdXNHdWFyZCwge1xuICAgICAgICBcImRhdGEtdHlwZVwiOiBcIm91dHNpZGVcIixcbiAgICAgICAgcmVmOiBiZWZvcmVPdXRzaWRlUmVmLFxuICAgICAgICBvbkZvY3VzOiBldmVudCA9PiB7XG4gICAgICAgICAgaWYgKGlzT3V0c2lkZUV2ZW50KGV2ZW50LCBwb3J0YWxOb2RlKSkge1xuICAgICAgICAgICAgYmVmb3JlSW5zaWRlUmVmLmN1cnJlbnQ/LmZvY3VzKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGRvbVJlZmVyZW5jZSA9IGZvY3VzTWFuYWdlclN0YXRlID8gZm9jdXNNYW5hZ2VyU3RhdGUuZG9tUmVmZXJlbmNlIDogbnVsbDtcbiAgICAgICAgICAgIGNvbnN0IHByZXZUYWJiYWJsZSA9IGdldFByZXZpb3VzVGFiYmFibGUoZG9tUmVmZXJlbmNlKTtcbiAgICAgICAgICAgIHByZXZUYWJiYWJsZT8uZm9jdXMoKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pLCBzaG91bGRSZW5kZXJHdWFyZHMgJiYgcG9ydGFsTm9kZSAmJiAvKiNfX1BVUkVfXyovX2pzeChcInNwYW5cIiwge1xuICAgICAgICByb2xlOiBwb3J0YWxPd25lclJvbGUsXG4gICAgICAgIFwiYXJpYS1vd25zXCI6IHBvcnRhbE5vZGVJZCxcbiAgICAgICAgc3R5bGU6IG93bmVyVmlzdWFsbHlIaWRkZW5cbiAgICAgIH0pLCBwb3J0YWxOb2RlICYmIC8qI19fUFVSRV9fKi9SZWFjdERPTS5jcmVhdGVQb3J0YWwoY2hpbGRyZW4sIHBvcnRhbE5vZGUpLCBzaG91bGRSZW5kZXJHdWFyZHMgJiYgcG9ydGFsTm9kZSAmJiAvKiNfX1BVUkVfXyovX2pzeChGb2N1c0d1YXJkLCB7XG4gICAgICAgIFwiZGF0YS10eXBlXCI6IFwib3V0c2lkZVwiLFxuICAgICAgICByZWY6IGFmdGVyT3V0c2lkZVJlZixcbiAgICAgICAgb25Gb2N1czogZXZlbnQgPT4ge1xuICAgICAgICAgIGlmIChpc091dHNpZGVFdmVudChldmVudCwgcG9ydGFsTm9kZSkpIHtcbiAgICAgICAgICAgIGFmdGVySW5zaWRlUmVmLmN1cnJlbnQ/LmZvY3VzKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IGRvbVJlZmVyZW5jZSA9IGZvY3VzTWFuYWdlclN0YXRlID8gZm9jdXNNYW5hZ2VyU3RhdGUuZG9tUmVmZXJlbmNlIDogbnVsbDtcbiAgICAgICAgICAgIGNvbnN0IG5leHRUYWJiYWJsZSA9IGdldE5leHRUYWJiYWJsZShkb21SZWZlcmVuY2UpO1xuICAgICAgICAgICAgbmV4dFRhYmJhYmxlPy5mb2N1cygpO1xuICAgICAgICAgICAgaWYgKGZvY3VzTWFuYWdlclN0YXRlPy5jbG9zZU9uRm9jdXNPdXQpIHtcbiAgICAgICAgICAgICAgZm9jdXNNYW5hZ2VyU3RhdGU/Lm9uT3BlbkNoYW5nZShmYWxzZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuZm9jdXNPdXQsIGV2ZW50Lm5hdGl2ZUV2ZW50KSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KV1cbiAgICB9KV1cbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIEZsb2F0aW5nUG9ydGFsLmRpc3BsYXlOYW1lID0gXCJGbG9hdGluZ1BvcnRhbFwiOyIsImV4cG9ydCBmdW5jdGlvbiBjcmVhdGVFdmVudEVtaXR0ZXIoKSB7XG4gIGNvbnN0IG1hcCA9IG5ldyBNYXAoKTtcbiAgcmV0dXJuIHtcbiAgICBlbWl0KGV2ZW50LCBkYXRhKSB7XG4gICAgICBtYXAuZ2V0KGV2ZW50KT8uZm9yRWFjaChsaXN0ZW5lciA9PiBsaXN0ZW5lcihkYXRhKSk7XG4gICAgfSxcbiAgICBvbihldmVudCwgbGlzdGVuZXIpIHtcbiAgICAgIGlmICghbWFwLmhhcyhldmVudCkpIHtcbiAgICAgICAgbWFwLnNldChldmVudCwgbmV3IFNldCgpKTtcbiAgICAgIH1cbiAgICAgIG1hcC5nZXQoZXZlbnQpLmFkZChsaXN0ZW5lcik7XG4gICAgfSxcbiAgICBvZmYoZXZlbnQsIGxpc3RlbmVyKSB7XG4gICAgICBtYXAuZ2V0KGV2ZW50KT8uZGVsZXRlKGxpc3RlbmVyKTtcbiAgICB9XG4gIH07XG59IiwiaW1wb3J0IHsgY3JlYXRlRXZlbnRFbWl0dGVyIH0gZnJvbSBcIi4uL3V0aWxzL2NyZWF0ZUV2ZW50RW1pdHRlci5tanNcIjtcblxuLyoqXG4gKiBTdG9yZXMgYW5kIG1hbmFnZXMgZmxvYXRpbmcgZWxlbWVudHMgaW4gYSB0cmVlIHN0cnVjdHVyZS5cbiAqIFRoaXMgaXMgYSBiYWNraW5nIHN0b3JlIGZvciB0aGUgYEZsb2F0aW5nVHJlZWAgY29tcG9uZW50LlxuICovXG5leHBvcnQgY2xhc3MgRmxvYXRpbmdUcmVlU3RvcmUge1xuICBub2Rlc1JlZiA9IHtcbiAgICBjdXJyZW50OiBbXVxuICB9O1xuICBldmVudHMgPSBjcmVhdGVFdmVudEVtaXR0ZXIoKTtcbiAgYWRkTm9kZShub2RlKSB7XG4gICAgdGhpcy5ub2Rlc1JlZi5jdXJyZW50LnB1c2gobm9kZSk7XG4gIH1cbiAgcmVtb3ZlTm9kZShub2RlKSB7XG4gICAgY29uc3QgaW5kZXggPSB0aGlzLm5vZGVzUmVmLmN1cnJlbnQuZmluZEluZGV4KG4gPT4gbiA9PT0gbm9kZSk7XG4gICAgaWYgKGluZGV4ICE9PSAtMSkge1xuICAgICAgdGhpcy5ub2Rlc1JlZi5jdXJyZW50LnNwbGljZShpbmRleCwgMSk7XG4gICAgfVxuICB9XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VJZCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlkJztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVJlZldpdGhJbml0JztcbmltcG9ydCB7IEZsb2F0aW5nVHJlZVN0b3JlIH0gZnJvbSBcIi4vRmxvYXRpbmdUcmVlU3RvcmUubWpzXCI7XG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuY29uc3QgRmxvYXRpbmdOb2RlQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRmxvYXRpbmdOb2RlQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiRmxvYXRpbmdOb2RlQ29udGV4dFwiO1xuY29uc3QgRmxvYXRpbmdUcmVlQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuXG4vKipcbiAqIFJldHVybnMgdGhlIHBhcmVudCBub2RlIGlkIGZvciBuZXN0ZWQgZmxvYXRpbmcgZWxlbWVudHMsIGlmIGF2YWlsYWJsZS5cbiAqIFJldHVybnMgYG51bGxgIGZvciB0b3AtbGV2ZWwgZmxvYXRpbmcgZWxlbWVudHMuXG4gKi9cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIEZsb2F0aW5nVHJlZUNvbnRleHQuZGlzcGxheU5hbWUgPSBcIkZsb2F0aW5nVHJlZUNvbnRleHRcIjtcbmV4cG9ydCBjb25zdCB1c2VGbG9hdGluZ1BhcmVudE5vZGVJZCA9ICgpID0+IFJlYWN0LnVzZUNvbnRleHQoRmxvYXRpbmdOb2RlQ29udGV4dCk/LmlkIHx8IG51bGw7XG5cbi8qKlxuICogUmV0dXJucyB0aGUgbmVhcmVzdCBmbG9hdGluZyB0cmVlIGNvbnRleHQsIGlmIGF2YWlsYWJsZS5cbiAqL1xuZXhwb3J0IGNvbnN0IHVzZUZsb2F0aW5nVHJlZSA9IGV4dGVybmFsVHJlZSA9PiB7XG4gIGNvbnN0IGNvbnRleHRUcmVlID0gUmVhY3QudXNlQ29udGV4dChGbG9hdGluZ1RyZWVDb250ZXh0KTtcbiAgcmV0dXJuIGV4dGVybmFsVHJlZSA/PyBjb250ZXh0VHJlZTtcbn07XG5cbi8qKlxuICogUmVnaXN0ZXJzIGEgbm9kZSBpbnRvIHRoZSBgRmxvYXRpbmdUcmVlYCwgcmV0dXJuaW5nIGl0cyBpZC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9GbG9hdGluZ1RyZWVcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUZsb2F0aW5nTm9kZUlkKGV4dGVybmFsVHJlZSkge1xuICBjb25zdCBpZCA9IHVzZUlkKCk7XG4gIGNvbnN0IHRyZWUgPSB1c2VGbG9hdGluZ1RyZWUoZXh0ZXJuYWxUcmVlKTtcbiAgY29uc3QgcGFyZW50SWQgPSB1c2VGbG9hdGluZ1BhcmVudE5vZGVJZCgpO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghaWQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGNvbnN0IG5vZGUgPSB7XG4gICAgICBpZCxcbiAgICAgIHBhcmVudElkXG4gICAgfTtcbiAgICB0cmVlPy5hZGROb2RlKG5vZGUpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICB0cmVlPy5yZW1vdmVOb2RlKG5vZGUpO1xuICAgIH07XG4gIH0sIFt0cmVlLCBpZCwgcGFyZW50SWRdKTtcbiAgcmV0dXJuIGlkO1xufVxuLyoqXG4gKiBQcm92aWRlcyBwYXJlbnQgbm9kZSBjb250ZXh0IGZvciBuZXN0ZWQgZmxvYXRpbmcgZWxlbWVudHMuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvRmxvYXRpbmdUcmVlXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIEZsb2F0aW5nTm9kZShwcm9wcykge1xuICBjb25zdCB7XG4gICAgY2hpbGRyZW4sXG4gICAgaWRcbiAgfSA9IHByb3BzO1xuICBjb25zdCBwYXJlbnRJZCA9IHVzZUZsb2F0aW5nUGFyZW50Tm9kZUlkKCk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChGbG9hdGluZ05vZGVDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICAgIGlkLFxuICAgICAgcGFyZW50SWRcbiAgICB9KSwgW2lkLCBwYXJlbnRJZF0pLFxuICAgIGNoaWxkcmVuOiBjaGlsZHJlblxuICB9KTtcbn1cbi8qKlxuICogUHJvdmlkZXMgY29udGV4dCBmb3IgbmVzdGVkIGZsb2F0aW5nIGVsZW1lbnRzIHdoZW4gdGhleSBhcmUgbm90IGNoaWxkcmVuIG9mXG4gKiBlYWNoIG90aGVyIG9uIHRoZSBET00uXG4gKiBUaGlzIGlzIG5vdCBuZWNlc3NhcnkgaW4gYWxsIGNhc2VzLCBleGNlcHQgd2hlbiB0aGVyZSBtdXN0IGJlIGV4cGxpY2l0IGNvbW11bmljYXRpb24gYmV0d2VlbiBwYXJlbnQgYW5kIGNoaWxkIGZsb2F0aW5nIGVsZW1lbnRzLiBJdCBpcyBuZWNlc3NhcnkgZm9yOlxuICogLSBUaGUgYGJ1YmJsZXNgIG9wdGlvbiBpbiB0aGUgYHVzZURpc21pc3MoKWAgSG9va1xuICogLSBOZXN0ZWQgdmlydHVhbCBsaXN0IG5hdmlnYXRpb25cbiAqIC0gTmVzdGVkIGZsb2F0aW5nIGVsZW1lbnRzIHRoYXQgZWFjaCBvcGVuIG9uIGhvdmVyXG4gKiAtIEN1c3RvbSBjb21tdW5pY2F0aW9uIGJldHdlZW4gcGFyZW50IGFuZCBjaGlsZCBmbG9hdGluZyBlbGVtZW50c1xuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL0Zsb2F0aW5nVHJlZVxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBGbG9hdGluZ1RyZWUocHJvcHMpIHtcbiAgY29uc3Qge1xuICAgIGNoaWxkcmVuLFxuICAgIGV4dGVybmFsVHJlZVxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHRyZWUgPSB1c2VSZWZXaXRoSW5pdCgoKSA9PiBleHRlcm5hbFRyZWUgPz8gbmV3IEZsb2F0aW5nVHJlZVN0b3JlKCkpLmN1cnJlbnQ7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChGbG9hdGluZ1RyZWVDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IHRyZWUsXG4gICAgY2hpbGRyZW46IGNoaWxkcmVuXG4gIH0pO1xufSIsIid1c2UgY2xpZW50JztcblxuLyogZXNsaW50LWRpc2FibGUgbm8tdW5kZXJzY29yZS1kYW5nbGUgKi9cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IGFkZEV2ZW50TGlzdGVuZXIgfSBmcm9tICdAYmFzZS11aS91dGlscy9hZGRFdmVudExpc3RlbmVyJztcbmltcG9ydCB7IG1lcmdlQ2xlYW51cHMgfSBmcm9tICdAYmFzZS11aS91dGlscy9tZXJnZUNsZWFudXBzJztcbmltcG9ydCB7IG93bmVyRG9jdW1lbnQgfSBmcm9tICdAYmFzZS11aS91dGlscy9vd25lcic7XG5pbXBvcnQgeyB1c2VTdGFibGVDYWxsYmFjayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrJztcbmltcG9ydCB7IFRpbWVvdXQsIHVzZVRpbWVvdXQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VUaW1lb3V0JztcbmltcG9ydCB7IGdldENvbXB1dGVkU3R5bGUsIGdldFBhcmVudE5vZGUsIGlzRWxlbWVudCwgaXNIVE1MRWxlbWVudCwgaXNMYXN0VHJhdmVyc2FibGVOb2RlLCBpc1NoYWRvd1Jvb3QgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IHBsYXRmb3JtIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvcGxhdGZvcm0nO1xuaW1wb3J0IHsgdXNlRmxvYXRpbmdUcmVlIH0gZnJvbSBcIi4uL2NvbXBvbmVudHMvRmxvYXRpbmdUcmVlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQXR0cmlidXRlIH0gZnJvbSBcIi4uL3V0aWxzL2NyZWF0ZUF0dHJpYnV0ZS5tanNcIjtcbmltcG9ydCB7IGNvbnRhaW5zLCBnZXRUYXJnZXQsIGlzRXZlbnRUYXJnZXRXaXRoaW4sIGlzUm9vdEVsZW1lbnQgfSBmcm9tIFwiLi4vdXRpbHMvZWxlbWVudC5tanNcIjtcbmltcG9ydCB7IGlzUmVhY3RFdmVudCwgaXNWaXJ0dWFsQ2xpY2sgfSBmcm9tIFwiLi4vdXRpbHMvZXZlbnQubWpzXCI7XG5pbXBvcnQgeyBnZXROb2RlQ2hpbGRyZW4gfSBmcm9tIFwiLi4vdXRpbHMvbm9kZXMubWpzXCI7XG5mdW5jdGlvbiBhbHdheXNGYWxzZSgpIHtcbiAgcmV0dXJuIGZhbHNlO1xufVxuZXhwb3J0IGZ1bmN0aW9uIG5vcm1hbGl6ZVByb3Aobm9ybWFsaXphYmxlKSB7XG4gIHJldHVybiB7XG4gICAgZXNjYXBlS2V5OiB0eXBlb2Ygbm9ybWFsaXphYmxlID09PSAnYm9vbGVhbicgPyBub3JtYWxpemFibGUgOiBub3JtYWxpemFibGU/LmVzY2FwZUtleSA/PyBmYWxzZSxcbiAgICBvdXRzaWRlUHJlc3M6IHR5cGVvZiBub3JtYWxpemFibGUgPT09ICdib29sZWFuJyA/IG5vcm1hbGl6YWJsZSA6IG5vcm1hbGl6YWJsZT8ub3V0c2lkZVByZXNzID8/IHRydWVcbiAgfTtcbn1cbi8qKlxuICogQ2xvc2VzIHRoZSBmbG9hdGluZyBlbGVtZW50IHdoZW4gYSBkaXNtaXNzYWwgaXMgcmVxdWVzdGVkIOKAlCBieSBkZWZhdWx0LCB3aGVuXG4gKiB0aGUgdXNlciBwcmVzc2VzIHRoZSBgZXNjYXBlYCBrZXkgb3Igb3V0c2lkZSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy91c2VEaXNtaXNzXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VEaXNtaXNzKHN0b3JlLCBwcm9wcyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBlbmFibGVkID0gdHJ1ZSxcbiAgICBlc2NhcGVLZXkgPSB0cnVlLFxuICAgIG91dHNpZGVQcmVzczogb3V0c2lkZVByZXNzUHJvcCA9IHRydWUsXG4gICAgb3V0c2lkZVByZXNzRXZlbnQgPSAnc2xvcHB5JyxcbiAgICByZWZlcmVuY2VQcmVzcyA9IGFsd2F5c0ZhbHNlLFxuICAgIGJ1YmJsZXMsXG4gICAgZXh0ZXJuYWxUcmVlXG4gIH0gPSBwcm9wcztcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IGZsb2F0aW5nRWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlKCdmbG9hdGluZ0VsZW1lbnQnKTtcbiAgY29uc3Qge1xuICAgIGRhdGFSZWYsXG4gICAgZXZlbnRzXG4gIH0gPSBzdG9yZS5jb250ZXh0O1xuICBjb25zdCB0cmVlID0gdXNlRmxvYXRpbmdUcmVlKGV4dGVybmFsVHJlZSk7XG4gIGNvbnN0IG91dHNpZGVQcmVzc0ZuID0gdXNlU3RhYmxlQ2FsbGJhY2sodHlwZW9mIG91dHNpZGVQcmVzc1Byb3AgPT09ICdmdW5jdGlvbicgPyBvdXRzaWRlUHJlc3NQcm9wIDogKCkgPT4gZmFsc2UpO1xuICBjb25zdCBvdXRzaWRlUHJlc3MgPSB0eXBlb2Ygb3V0c2lkZVByZXNzUHJvcCA9PT0gJ2Z1bmN0aW9uJyA/IG91dHNpZGVQcmVzc0ZuIDogb3V0c2lkZVByZXNzUHJvcDtcbiAgY29uc3Qgb3V0c2lkZVByZXNzRW5hYmxlZCA9IG91dHNpZGVQcmVzcyAhPT0gZmFsc2U7XG4gIGNvbnN0IGdldE91dHNpZGVQcmVzc0V2ZW50UHJvcCA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IG91dHNpZGVQcmVzc0V2ZW50KTtcbiAgY29uc3Qge1xuICAgIGVzY2FwZUtleTogZXNjYXBlS2V5QnViYmxlcyxcbiAgICBvdXRzaWRlUHJlc3M6IG91dHNpZGVQcmVzc0J1YmJsZXNcbiAgfSA9IG5vcm1hbGl6ZVByb3AoYnViYmxlcyk7XG4gIGNvbnN0IHByZXNzU3RhcnRlZEluc2lkZVJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IHByZXNzU3RhcnRQcmV2ZW50ZWRSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICAvLyBJZ25vcmUgb25seSB0aGUgdmVyeSBuZXh0IG91dHNpZGUgY2xpY2sgYWZ0ZXIgZHJhZ2dpbmcgZnJvbSBpbnNpZGUgdG8gb3V0c2lkZS5cbiAgY29uc3Qgc3VwcHJlc3NOZXh0T3V0c2lkZUNsaWNrUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgLy8gQSBjbGljayB3aG9zZSBwcmVzcyBiZWdhbiBiZWZvcmUgdGhlIGZsb2F0aW5nIGVsZW1lbnQgb3BlbmVkIGlzIHRoZSB0YWlsIG9mIHRoYXRcbiAgLy8gZ2VzdHVyZSAoZS5nLiB0aGUgZHJhZy1yZWxlYXNlIHRoYXQgb3BlbmVkIGl0KSwgbm90IGEgbmV3IG91dHNpZGUgcHJlc3MuXG4gIGNvbnN0IHNhd1ByZXNzV2hpbGVPcGVuUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgaXNDb21wb3NpbmdSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBjb25zdCBjdXJyZW50UG9pbnRlclR5cGVSZWYgPSBSZWFjdC51c2VSZWYoJycpO1xuICBjb25zdCB0b3VjaFN0YXRlUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBjYW5jZWxEaXNtaXNzT25FbmRUaW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICBjb25zdCBjbGVhckluc2lkZVJlYWN0VHJlZVRpbWVvdXQgPSB1c2VUaW1lb3V0KCk7XG4gIC8vIE91dGxpdmVzIGVmZmVjdCByZS1ydW5zIHNvIGEgcGVuZGluZyByZXNldCBjYW4ndCBsZWF2ZSBgaXNDb21wb3NpbmdSZWZgIHN0dWNrLlxuICBjb25zdCBjb21wb3NpdGlvblRpbWVvdXQgPSB1c2VUaW1lb3V0KCk7XG4gIGNvbnN0IGNsZWFySW5zaWRlUmVhY3RUcmVlID0gdXNlU3RhYmxlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNsZWFySW5zaWRlUmVhY3RUcmVlVGltZW91dC5jbGVhcigpO1xuICAgIGRhdGFSZWYuY3VycmVudC5pbnNpZGVSZWFjdFRyZWUgPSBmYWxzZTtcbiAgfSk7XG4gIGNvbnN0IGhhc0Jsb2NraW5nQ2hpbGQgPSB1c2VTdGFibGVDYWxsYmFjayhidWJibGVLZXkgPT4ge1xuICAgIGNvbnN0IG5vZGVJZCA9IGRhdGFSZWYuY3VycmVudC5mbG9hdGluZ0NvbnRleHQ/Lm5vZGVJZDtcbiAgICBjb25zdCBjaGlsZHJlbiA9IHRyZWUgPyBnZXROb2RlQ2hpbGRyZW4odHJlZS5ub2Rlc1JlZi5jdXJyZW50LCBub2RlSWQpIDogW107XG4gICAgcmV0dXJuIGNoaWxkcmVuLnNvbWUoY2hpbGQgPT4gY2hpbGQuY29udGV4dD8ub3BlbiAmJiAhY2hpbGQuY29udGV4dC5kYXRhUmVmLmN1cnJlbnRbYnViYmxlS2V5XSk7XG4gIH0pO1xuICBjb25zdCBpc0V2ZW50V2l0aGluT3duRWxlbWVudHMgPSB1c2VTdGFibGVDYWxsYmFjayhldmVudCA9PiB7XG4gICAgcmV0dXJuIGlzRXZlbnRUYXJnZXRXaXRoaW4oZXZlbnQsIHN0b3JlLnNlbGVjdCgnZmxvYXRpbmdFbGVtZW50JykpIHx8IGlzRXZlbnRUYXJnZXRXaXRoaW4oZXZlbnQsIHN0b3JlLnNlbGVjdCgnZG9tUmVmZXJlbmNlRWxlbWVudCcpKTtcbiAgfSk7XG4gIGNvbnN0IGNsb3NlT25SZWZlcmVuY2VQcmVzcyA9IHVzZVN0YWJsZUNhbGxiYWNrKGV2ZW50ID0+IHtcbiAgICBpZiAoIXJlZmVyZW5jZVByZXNzKCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc3RvcmUuc2V0T3BlbihmYWxzZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMudHJpZ2dlclByZXNzLCBldmVudC5uYXRpdmVFdmVudCkpO1xuICB9KTtcbiAgY29uc3QgY2xvc2VPbkVzY2FwZUtleURvd24gPSB1c2VTdGFibGVDYWxsYmFjayhldmVudCA9PiB7XG4gICAgaWYgKCFvcGVuIHx8ICFlbmFibGVkIHx8ICFlc2NhcGVLZXkgfHwgZXZlbnQua2V5ICE9PSAnRXNjYXBlJykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBuYXRpdmUgPSBpc1JlYWN0RXZlbnQoZXZlbnQpID8gZXZlbnQubmF0aXZlRXZlbnQgOiBldmVudDtcblxuICAgIC8vIFdhaXQgdW50aWwgSU1FIGlzIHNldHRsZWQuIFByZXNzaW5nIGBFc2NhcGVgIHdoaWxlIGNvbXBvc2luZyBzaG91bGRcbiAgICAvLyBjbG9zZSB0aGUgY29tcG9zZSBtZW51LCBidXQgbm90IHRoZSBmbG9hdGluZyBlbGVtZW50LiBUaGUgcmVmIGNvdmVycyBTYWZhcmksIHdoaWNoIGZpcmVzXG4gICAgLy8gYGNvbXBvc2l0aW9uZW5kYCBiZWZvcmUgYGtleWRvd25gOyBgaXNDb21wb3NpbmdgIGNvdmVycyBjb21wb3NpdGlvbnMgdGhhdCBiZWdhbiB3aGlsZSBjbG9zZWQuXG4gICAgaWYgKGlzQ29tcG9zaW5nUmVmLmN1cnJlbnQgfHwgbmF0aXZlLmlzQ29tcG9zaW5nKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghZXNjYXBlS2V5QnViYmxlcyAmJiBoYXNCbG9ja2luZ0NoaWxkKCdfX2VzY2FwZUtleUJ1YmJsZXMnKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBldmVudERldGFpbHMgPSBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5lc2NhcGVLZXksIG5hdGl2ZSk7XG4gICAgc3RvcmUuc2V0T3BlbihmYWxzZSwgZXZlbnREZXRhaWxzKTtcbiAgICBpZiAoIWV2ZW50RGV0YWlscy5pc0NhbmNlbGVkKSB7XG4gICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgIH1cbiAgICBpZiAoIWVzY2FwZUtleUJ1YmJsZXMgJiYgIWV2ZW50RGV0YWlscy5pc1Byb3BhZ2F0aW9uQWxsb3dlZCkge1xuICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgfVxuICB9KTtcbiAgY29uc3QgbWFya0luc2lkZVJlYWN0VHJlZSA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IHtcbiAgICBkYXRhUmVmLmN1cnJlbnQuaW5zaWRlUmVhY3RUcmVlID0gdHJ1ZTtcbiAgICBjbGVhckluc2lkZVJlYWN0VHJlZVRpbWVvdXQuc3RhcnQoMCwgY2xlYXJJbnNpZGVSZWFjdFRyZWUpO1xuICB9KTtcbiAgY29uc3QgbWFya1ByZXNzU3RhcnRlZEluc2lkZVJlYWN0VHJlZSA9IHVzZVN0YWJsZUNhbGxiYWNrKGV2ZW50ID0+IHtcbiAgICBpZiAoIW9wZW4gfHwgIWVuYWJsZWQgfHwgZXZlbnQuYnV0dG9uICE9PSAwKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHRhcmdldCA9IGdldFRhcmdldChldmVudC5uYXRpdmVFdmVudCk7XG5cbiAgICAvLyBPbmx5IHRyZWF0IHByZXNzZXMgdGhhdCBzdGFydCB3aXRoaW4gdGhlIGZsb2F0aW5nIERPTSBzdWJ0cmVlIGFzIGluc2lkZS5cbiAgICAvLyBUaGlzIGF2b2lkcyBzdXBwcmVzc2luZyBwYXJlbnQgZGlzbWlzc2FsIHdoZW4gaW50ZXJhY3Rpbmcgd2l0aCBuZXN0ZWQgcG9ydGFscy5cbiAgICBpZiAoIWNvbnRhaW5zKHN0b3JlLnNlbGVjdCgnZmxvYXRpbmdFbGVtZW50JyksIHRhcmdldCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCFwcmVzc1N0YXJ0ZWRJbnNpZGVSZWYuY3VycmVudCkge1xuICAgICAgcHJlc3NTdGFydGVkSW5zaWRlUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgcHJlc3NTdGFydFByZXZlbnRlZFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgfVxuICB9KTtcbiAgY29uc3QgbWFya0luc2lkZVByZXNzU3RhcnRQcmV2ZW50ZWQgPSB1c2VTdGFibGVDYWxsYmFjayhldmVudCA9PiB7XG4gICAgaWYgKCFvcGVuIHx8ICFlbmFibGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghKGV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQgfHwgZXZlbnQubmF0aXZlRXZlbnQuZGVmYXVsdFByZXZlbnRlZCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHByZXNzU3RhcnRlZEluc2lkZVJlZi5jdXJyZW50KSB7XG4gICAgICBwcmVzc1N0YXJ0UHJldmVudGVkUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gQSBzYW1lLWJhdGNoIGNsb3NlK3Jlb3BlbiBuZXZlciByZW5kZXJzIGBvcGVuID09PSBmYWxzZWAsIHNvIG9ubHkgYG9wZW5jaGFuZ2VgIGNhblxuICAvLyBvYnNlcnZlIHRoYXQgc2Vzc2lvbiBib3VuZGFyeS4gVGhlIGVmZmVjdCBiZWxvdyBjb3ZlcnMgY29udHJvbGxlZCBmbGlwcy5cbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBmdW5jdGlvbiBoYW5kbGVPcGVuQ2hhbmdlKGRldGFpbHMpIHtcbiAgICAgIC8vIE9ubHkgdGhlIGNsb3NpbmcgaGFsZiBlbmRzIHRoZSBzZXNzaW9uOiBgc2V0T3Blbih0cnVlKWAgb24gYW4gYWxyZWFkeS1vcGVuXG4gICAgICAvLyBlbGVtZW50IChob3ZlcmluZyBhbiBpbmFjdGl2ZSB0cmlnZ2VyKSBtdXN0IG5vdCBkcm9wIGEgcHJlc3MgbWlkLWdlc3R1cmUuXG4gICAgICBpZiAoIWRldGFpbHMub3Blbikge1xuICAgICAgICBzYXdQcmVzc1doaWxlT3BlblJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICAgIGV2ZW50cy5vbignb3BlbmNoYW5nZScsIGhhbmRsZU9wZW5DaGFuZ2UpO1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICBldmVudHMub2ZmKCdvcGVuY2hhbmdlJywgaGFuZGxlT3BlbkNoYW5nZSk7XG4gICAgfTtcbiAgfSwgW2V2ZW50c10pO1xuXG4gIC8vIE5vdCBjbGVhcmVkIGluIHRoZSBsaXN0ZW5lciBlZmZlY3QncyBjbGVhbnVwLCB3aGljaCBjYW4gcnVuIG1pZC1wcmVzcyB3aGVuIGEgZGVwZW5kZW5jeVxuICAvLyBjaGFuZ2VzLiBJbiBhIGNsb3NlZCBzaGFkb3cgcm9vdCwgdGhlIG1hcmtlciBpcyB0aGUgb25seSBpbnNpZGUtcHJlc3Mgc2lnbmFsLlxuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4gY2xlYXJJbnNpZGVSZWFjdFRyZWUsIFtjbGVhckluc2lkZVJlYWN0VHJlZV0pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghb3BlbiB8fCAhZW5hYmxlZCkge1xuICAgICAgLy8gUmVzZXQgaW4gdGhlIGVmZmVjdCBib2R5LCBub3QgdGhlIGNsZWFudXAsIHdoaWNoIGFsc28gcnVucyB3aGVuIGEgZGVwZW5kZW5jeVxuICAgICAgLy8gY2hhbmdlcyBtaWQtZ2VzdHVyZS5cbiAgICAgIGlmICghb3Blbikge1xuICAgICAgICBzYXdQcmVzc1doaWxlT3BlblJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgIGlzQ29tcG9zaW5nUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgY3VycmVudFBvaW50ZXJUeXBlUmVmLmN1cnJlbnQgPSAnJztcbiAgICAgICAgdG91Y2hTdGF0ZVJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBjbGVhckluc2lkZVJlYWN0VHJlZTtcbiAgICB9XG4gICAgZGF0YVJlZi5jdXJyZW50Ll9fZXNjYXBlS2V5QnViYmxlcyA9IGVzY2FwZUtleUJ1YmJsZXM7XG4gICAgZGF0YVJlZi5jdXJyZW50Ll9fb3V0c2lkZVByZXNzQnViYmxlcyA9IG91dHNpZGVQcmVzc0J1YmJsZXM7XG4gICAgY29uc3QgcHJldmVudGVkUHJlc3NTdXBwcmVzc2lvblRpbWVvdXQgPSBuZXcgVGltZW91dCgpO1xuICAgIGNvbnN0IGRvYyA9IG93bmVyRG9jdW1lbnQoZmxvYXRpbmdFbGVtZW50KTtcbiAgICBmdW5jdGlvbiBoYW5kbGVDb21wb3NpdGlvblN0YXJ0KCkge1xuICAgICAgY29tcG9zaXRpb25UaW1lb3V0LmNsZWFyKCk7XG4gICAgICBpc0NvbXBvc2luZ1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaGFuZGxlQ29tcG9zaXRpb25FbmQoKSB7XG4gICAgICAvLyBTYWZhcmkgZmlyZXMgYGNvbXBvc2l0aW9uZW5kYCBiZWZvcmUgYGtleWRvd25gLCBzbyB3ZSBuZWVkIHRvIHdhaXRcbiAgICAgIC8vIHVudGlsIHRoZSBuZXh0IHRpY2sgdG8gc2V0IGBpc0NvbXBvc2luZ2AgdG8gYGZhbHNlYC4gU2V0IGl0IGhlcmUgdG9vLCBzaW5jZSBjbG9zaW5nXG4gICAgICAvLyByZXNldHMgaXQgd2hpbGUgYSBjb21wb3NpdGlvbiBjYW4gY29udGludWUgaW50byB0aGUgbmV4dCBvcGVuIHNlc3Npb24uXG4gICAgICAvLyBodHRwczovL2J1Z3Mud2Via2l0Lm9yZy9zaG93X2J1Zy5jZ2k/aWQ9MTY1MDA0XG4gICAgICBpc0NvbXBvc2luZ1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIGNvbXBvc2l0aW9uVGltZW91dC5zdGFydChcbiAgICAgIC8vIDBtcyBvciAxbXMgZG9uJ3Qgd29yayBpbiBTYWZhcmkuIDVtcyBhcHBlYXJzIHRvIGNvbnNpc3RlbnRseSB3b3JrLlxuICAgICAgLy8gT25seSBhcHBseSB0byBXZWJLaXQgZm9yIHRoZSB0ZXN0IHRvIHJlbWFpbiAwbXMuXG4gICAgICBwbGF0Zm9ybS5lbmdpbmUud2Via2l0ID8gNSA6IDAsICgpID0+IHtcbiAgICAgICAgaXNDb21wb3NpbmdSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHN1cHByZXNzSW1tZWRpYXRlT3V0c2lkZUNsaWNrQWZ0ZXJQcmV2ZW50ZWRTdGFydCgpIHtcbiAgICAgIHN1cHByZXNzTmV4dE91dHNpZGVDbGlja1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIC8vIEZpcmVmb3ggY2FuIGVtaXQgdGhlIHN5bnRoZXRpYyBvdXRzaWRlIGNsaWNrIGluIGEgbGF0ZXIgdGFzayBhZnRlclxuICAgICAgLy8gcG9pbnRlciBsb2NrIGV4aXQsIHNvIG1pY3JvdGFzayBjbGVhcmluZyBpcyB0b28gZWFybHkgaGVyZS5cbiAgICAgIHByZXZlbnRlZFByZXNzU3VwcHJlc3Npb25UaW1lb3V0LnN0YXJ0KDAsICgpID0+IHtcbiAgICAgICAgc3VwcHJlc3NOZXh0T3V0c2lkZUNsaWNrUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBmdW5jdGlvbiByZXNldFByZXNzU3RhcnRTdGF0ZSgpIHtcbiAgICAgIHByZXNzU3RhcnRlZEluc2lkZVJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICBwcmVzc1N0YXJ0UHJldmVudGVkUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICB9XG4gICAgZnVuY3Rpb24gZ2V0T3V0c2lkZVByZXNzRXZlbnQoKSB7XG4gICAgICBjb25zdCB0eXBlID0gY3VycmVudFBvaW50ZXJUeXBlUmVmLmN1cnJlbnQ7XG4gICAgICBjb25zdCBjb21wdXRlZFR5cGUgPSB0eXBlID09PSAncGVuJyB8fCAhdHlwZSA/ICdtb3VzZScgOiB0eXBlO1xuICAgICAgY29uc3Qgb3V0c2lkZVByZXNzRXZlbnRWYWx1ZSA9IGdldE91dHNpZGVQcmVzc0V2ZW50UHJvcCgpO1xuICAgICAgY29uc3QgcmVzb2x2ZWQgPSB0eXBlb2Ygb3V0c2lkZVByZXNzRXZlbnRWYWx1ZSA9PT0gJ2Z1bmN0aW9uJyA/IG91dHNpZGVQcmVzc0V2ZW50VmFsdWUoKSA6IG91dHNpZGVQcmVzc0V2ZW50VmFsdWU7XG4gICAgICBpZiAodHlwZW9mIHJlc29sdmVkID09PSAnc3RyaW5nJykge1xuICAgICAgICByZXR1cm4gcmVzb2x2ZWQ7XG4gICAgICB9XG4gICAgICByZXR1cm4gcmVzb2x2ZWRbY29tcHV0ZWRUeXBlXTtcbiAgICB9XG4gICAgZnVuY3Rpb24gc2hvdWxkSWdub3JlRXZlbnQoZXZlbnQpIHtcbiAgICAgIGNvbnN0IGNvbXB1dGVkT3V0c2lkZVByZXNzRXZlbnQgPSBnZXRPdXRzaWRlUHJlc3NFdmVudCgpO1xuICAgICAgcmV0dXJuIGNvbXB1dGVkT3V0c2lkZVByZXNzRXZlbnQgPT09ICdpbnRlbnRpb25hbCcgJiYgZXZlbnQudHlwZSAhPT0gJ2NsaWNrJyB8fCBjb21wdXRlZE91dHNpZGVQcmVzc0V2ZW50ID09PSAnc2xvcHB5JyAmJiBldmVudC50eXBlID09PSAnY2xpY2snO1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc0V2ZW50V2l0aGluRmxvYXRpbmdUcmVlKGV2ZW50KSB7XG4gICAgICBjb25zdCBub2RlSWQgPSBkYXRhUmVmLmN1cnJlbnQuZmxvYXRpbmdDb250ZXh0Py5ub2RlSWQ7XG4gICAgICBjb25zdCB0YXJnZXRJc0luc2lkZUNoaWxkcmVuID0gdHJlZSAmJiBnZXROb2RlQ2hpbGRyZW4odHJlZS5ub2Rlc1JlZi5jdXJyZW50LCBub2RlSWQpLnNvbWUobm9kZSA9PiBpc0V2ZW50VGFyZ2V0V2l0aGluKGV2ZW50LCBub2RlLmNvbnRleHQ/LmVsZW1lbnRzLmZsb2F0aW5nKSk7XG4gICAgICByZXR1cm4gaXNFdmVudFdpdGhpbk93bkVsZW1lbnRzKGV2ZW50KSB8fCB0YXJnZXRJc0luc2lkZUNoaWxkcmVuO1xuICAgIH1cbiAgICBmdW5jdGlvbiBjbG9zZU9uUHJlc3NPdXRzaWRlKGV2ZW50KSB7XG4gICAgICBpZiAoc2hvdWxkSWdub3JlRXZlbnQoZXZlbnQpKSB7XG4gICAgICAgIC8vIEEgbmV3IHByZXNzIGJlZ2FuIG91dHNpZGUgdGhlIGZsb2F0aW5nIGVsZW1lbnQgYW5kIGl0cyB0cmlnZ2VyLiBDbGVhciBhbnlcbiAgICAgICAgLy8gbGVmdG92ZXIgZHJhZy1vdXQgc3VwcHJlc3Npb24gc28gdGhpcyBwcmVzcydzIGV2ZW50dWFsIGNsaWNrIGNhbiBkaXNtaXNzLlxuICAgICAgICBpZiAoZXZlbnQudHlwZSAhPT0gJ2NsaWNrJyAmJiAhaXNFdmVudFdpdGhpbk93bkVsZW1lbnRzKGV2ZW50KSkge1xuICAgICAgICAgIHByZXZlbnRlZFByZXNzU3VwcHJlc3Npb25UaW1lb3V0LmNsZWFyKCk7XG4gICAgICAgICAgc3VwcHJlc3NOZXh0T3V0c2lkZUNsaWNrUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBjbGVhckluc2lkZVJlYWN0VHJlZSgpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoZGF0YVJlZi5jdXJyZW50Lmluc2lkZVJlYWN0VHJlZSkge1xuICAgICAgICBjbGVhckluc2lkZVJlYWN0VHJlZSgpO1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQpO1xuICAgICAgY29uc3QgaW5lcnRTZWxlY3RvciA9IGBbJHtjcmVhdGVBdHRyaWJ1dGUoJ2luZXJ0Jyl9XWA7XG4gICAgICBjb25zdCB0YXJnZXRSb290ID0gaXNFbGVtZW50KHRhcmdldCkgPyB0YXJnZXQuZ2V0Um9vdE5vZGUoKSA6IG51bGw7XG4gICAgICBjb25zdCBtYXJrZXJzID0gQXJyYXkuZnJvbSgoaXNTaGFkb3dSb290KHRhcmdldFJvb3QpID8gdGFyZ2V0Um9vdCA6IG93bmVyRG9jdW1lbnQoc3RvcmUuc2VsZWN0KCdmbG9hdGluZ0VsZW1lbnQnKSkpLnF1ZXJ5U2VsZWN0b3JBbGwoaW5lcnRTZWxlY3RvcikpO1xuICAgICAgY29uc3QgdHJpZ2dlcnMgPSBzdG9yZS5jb250ZXh0LnRyaWdnZXJFbGVtZW50cztcblxuICAgICAgLy8gSWYgYW5vdGhlciB0cmlnZ2VyIGlzIGNsaWNrZWQsIGRvbid0IGNsb3NlIHRoZSBmbG9hdGluZyBlbGVtZW50LlxuICAgICAgaWYgKHRhcmdldCAmJiAodHJpZ2dlcnMuaGFzRWxlbWVudCh0YXJnZXQpIHx8IHRyaWdnZXJzLmhhc01hdGNoaW5nRWxlbWVudCh0cmlnZ2VyID0+IGNvbnRhaW5zKHRyaWdnZXIsIHRhcmdldCkpKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBsZXQgdGFyZ2V0Um9vdEFuY2VzdG9yID0gaXNFbGVtZW50KHRhcmdldCkgPyB0YXJnZXQgOiBudWxsO1xuICAgICAgd2hpbGUgKHRhcmdldFJvb3RBbmNlc3RvciAmJiAhaXNMYXN0VHJhdmVyc2FibGVOb2RlKHRhcmdldFJvb3RBbmNlc3RvcikpIHtcbiAgICAgICAgY29uc3QgbmV4dFBhcmVudCA9IGdldFBhcmVudE5vZGUodGFyZ2V0Um9vdEFuY2VzdG9yKTtcbiAgICAgICAgaWYgKGlzTGFzdFRyYXZlcnNhYmxlTm9kZShuZXh0UGFyZW50KSB8fCAhaXNFbGVtZW50KG5leHRQYXJlbnQpKSB7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgdGFyZ2V0Um9vdEFuY2VzdG9yID0gbmV4dFBhcmVudDtcbiAgICAgIH1cblxuICAgICAgLy8gQ2hlY2sgaWYgdGhlIGNsaWNrIG9jY3VycmVkIG9uIGEgdGhpcmQtcGFydHkgZWxlbWVudCBpbmplY3RlZCBhZnRlciB0aGVcbiAgICAgIC8vIGZsb2F0aW5nIGVsZW1lbnQgcmVuZGVyZWQuXG4gICAgICBpZiAobWFya2Vycy5sZW5ndGggJiYgaXNFbGVtZW50KHRhcmdldCkgJiYgIWlzUm9vdEVsZW1lbnQodGFyZ2V0KSAmJlxuICAgICAgLy8gQ2xpY2tlZCBvbiBhIGRpcmVjdCBhbmNlc3RvciAoZS5nLiBGbG9hdGluZ092ZXJsYXkpLlxuICAgICAgIWNvbnRhaW5zKHRhcmdldCwgc3RvcmUuc2VsZWN0KCdmbG9hdGluZ0VsZW1lbnQnKSkgJiZcbiAgICAgIC8vIElmIHRoZSB0YXJnZXQgcm9vdCBlbGVtZW50IGNvbnRhaW5zIG5vbmUgb2YgdGhlIG1hcmtlcnMsIHRoZW4gdGhlXG4gICAgICAvLyBlbGVtZW50IHdhcyBpbmplY3RlZCBhZnRlciB0aGUgZmxvYXRpbmcgZWxlbWVudCByZW5kZXJlZC5cbiAgICAgIG1hcmtlcnMuZXZlcnkobWFya2VyID0+ICFjb250YWlucyh0YXJnZXRSb290QW5jZXN0b3IsIG1hcmtlcikpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gQ2hlY2sgaWYgdGhlIGNsaWNrIG9jY3VycmVkIG9uIHRoZSBzY3JvbGxiYXJcbiAgICAgIC8vIFNraXAgZm9yIHRvdWNoIGV2ZW50czogc2Nyb2xsYmFycyBkb24ndCByZWNlaXZlIHRvdWNoIGV2ZW50cyBvbiBtb3N0IHBsYXRmb3Jtc1xuICAgICAgaWYgKGlzSFRNTEVsZW1lbnQodGFyZ2V0KSAmJiAhKCd0b3VjaGVzJyBpbiBldmVudCkpIHtcbiAgICAgICAgY29uc3QgbGFzdFRyYXZlcnNhYmxlTm9kZSA9IGlzTGFzdFRyYXZlcnNhYmxlTm9kZSh0YXJnZXQpO1xuICAgICAgICBjb25zdCBzdHlsZSA9IGdldENvbXB1dGVkU3R5bGUodGFyZ2V0KTtcbiAgICAgICAgY29uc3Qgc2Nyb2xsUmUgPSAvYXV0b3xzY3JvbGwvO1xuICAgICAgICBjb25zdCBpc1Njcm9sbGFibGVYID0gbGFzdFRyYXZlcnNhYmxlTm9kZSB8fCBzY3JvbGxSZS50ZXN0KHN0eWxlLm92ZXJmbG93WCk7XG4gICAgICAgIGNvbnN0IGlzU2Nyb2xsYWJsZVkgPSBsYXN0VHJhdmVyc2FibGVOb2RlIHx8IHNjcm9sbFJlLnRlc3Qoc3R5bGUub3ZlcmZsb3dZKTtcbiAgICAgICAgY29uc3QgY2FuU2Nyb2xsWCA9IGlzU2Nyb2xsYWJsZVggJiYgdGFyZ2V0LmNsaWVudFdpZHRoID4gMCAmJiB0YXJnZXQuc2Nyb2xsV2lkdGggPiB0YXJnZXQuY2xpZW50V2lkdGg7XG4gICAgICAgIGNvbnN0IGNhblNjcm9sbFkgPSBpc1Njcm9sbGFibGVZICYmIHRhcmdldC5jbGllbnRIZWlnaHQgPiAwICYmIHRhcmdldC5zY3JvbGxIZWlnaHQgPiB0YXJnZXQuY2xpZW50SGVpZ2h0O1xuICAgICAgICBjb25zdCBpc1JUTCA9IHN0eWxlLmRpcmVjdGlvbiA9PT0gJ3J0bCc7XG5cbiAgICAgICAgLy8gQ2hlY2sgY2xpY2sgcG9zaXRpb24gcmVsYXRpdmUgdG8gc2Nyb2xsYmFyLlxuICAgICAgICAvLyBJbiBzb21lIGJyb3dzZXJzIGl0IGlzIHBvc3NpYmxlIHRvIGNoYW5nZSB0aGUgPGJvZHk+IChvciB3aW5kb3cpXG4gICAgICAgIC8vIHNjcm9sbGJhciB0byB0aGUgbGVmdCBzaWRlLCBidXQgaXMgdmVyeSByYXJlIGFuZCBpcyBkaWZmaWN1bHQgdG9cbiAgICAgICAgLy8gY2hlY2sgZm9yLiBQbHVzLCBmb3IgbW9kYWwgZGlhbG9ncyB3aXRoIGJhY2tkcm9wcywgaXQgaXMgbW9yZVxuICAgICAgICAvLyBpbXBvcnRhbnQgdGhhdCB0aGUgYmFja2Ryb3AgaXMgY2hlY2tlZCBidXQgbm90IHNvIG11Y2ggdGhlIHdpbmRvdy5cbiAgICAgICAgY29uc3QgcHJlc3NlZFZlcnRpY2FsU2Nyb2xsYmFyID0gY2FuU2Nyb2xsWSAmJiAoaXNSVEwgPyBldmVudC5vZmZzZXRYIDw9IHRhcmdldC5vZmZzZXRXaWR0aCAtIHRhcmdldC5jbGllbnRXaWR0aCA6IGV2ZW50Lm9mZnNldFggPiB0YXJnZXQuY2xpZW50V2lkdGgpO1xuICAgICAgICBjb25zdCBwcmVzc2VkSG9yaXpvbnRhbFNjcm9sbGJhciA9IGNhblNjcm9sbFggJiYgZXZlbnQub2Zmc2V0WSA+IHRhcmdldC5jbGllbnRIZWlnaHQ7XG4gICAgICAgIGlmIChwcmVzc2VkVmVydGljYWxTY3JvbGxiYXIgfHwgcHJlc3NlZEhvcml6b250YWxTY3JvbGxiYXIpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChpc0V2ZW50V2l0aGluRmxvYXRpbmdUcmVlKGV2ZW50KSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIC8vIE9ubHkgYGNsaWNrYCBldmVudHMgcmVhY2ggdGhpcyBwb2ludCBpbiBpbnRlbnRpb25hbCBtb2RlLlxuICAgICAgaWYgKGdldE91dHNpZGVQcmVzc0V2ZW50KCkgPT09ICdpbnRlbnRpb25hbCcpIHtcbiAgICAgICAgLy8gUHJlc3MtbGVzcyBjbGlja3MgKGtleWJvYXJkLCBhc3Npc3RpdmUgdGVjaG5vbG9neSwgYGVsZW1lbnQuY2xpY2soKWApIHJlcG9ydCBub1xuICAgICAgICAvLyBjbGljayBjb3VudDsgYGlzVmlydHVhbENsaWNrYCBhbHNvIGNhdGNoZXMgdGhlIG9uZXMgdGhhdCBkby5cbiAgICAgICAgaWYgKGV2ZW50LmRldGFpbCAhPT0gMCAmJiAhaXNWaXJ0dWFsQ2xpY2soZXZlbnQpICYmICFzYXdQcmVzc1doaWxlT3BlblJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gQSBwcmVzcyB0aGF0IHN0YXJ0cyBpbnNpZGUgYW5kIGVuZHMgb3V0c2lkZSBnZXRzIG9uZSBzdXBwcmVzc2VkXG4gICAgICAgIC8vIG91dHNpZGUgY2xpY2suIFJ1biB0aGlzIGFmdGVyIGluc2lkZS10YXJnZXQgY2hlY2tzIHNvIGluc2lkZSBjbGlja3NcbiAgICAgICAgLy8gZG9uJ3QgY29uc3VtZSB0aGUgb25lLXNob3Qgc3VwcHJlc3Npb24uXG4gICAgICAgIGlmIChzdXBwcmVzc05leHRPdXRzaWRlQ2xpY2tSZWYuY3VycmVudCkge1xuICAgICAgICAgIHByZXZlbnRlZFByZXNzU3VwcHJlc3Npb25UaW1lb3V0LmNsZWFyKCk7XG4gICAgICAgICAgc3VwcHJlc3NOZXh0T3V0c2lkZUNsaWNrUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmICh0eXBlb2Ygb3V0c2lkZVByZXNzID09PSAnZnVuY3Rpb24nICYmICFvdXRzaWRlUHJlc3MoZXZlbnQpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChoYXNCbG9ja2luZ0NoaWxkKCdfX291dHNpZGVQcmVzc0J1YmJsZXMnKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5vdXRzaWRlUHJlc3MsIGV2ZW50KSk7XG4gICAgICBjbGVhckluc2lkZVJlYWN0VHJlZSgpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVQb2ludGVyRG93bihldmVudCkge1xuICAgICAgaWYgKGdldE91dHNpZGVQcmVzc0V2ZW50KCkgIT09ICdzbG9wcHknIHx8IGV2ZW50LnBvaW50ZXJUeXBlID09PSAndG91Y2gnIHx8ICFzdG9yZS5zZWxlY3QoJ29wZW4nKSB8fCAhZW5hYmxlZCB8fCBpc0V2ZW50V2l0aGluT3duRWxlbWVudHMoZXZlbnQpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNsb3NlT25QcmVzc091dHNpZGUoZXZlbnQpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVUb3VjaFN0YXJ0KGV2ZW50KSB7XG4gICAgICBpZiAoZ2V0T3V0c2lkZVByZXNzRXZlbnQoKSAhPT0gJ3Nsb3BweScgfHwgIXN0b3JlLnNlbGVjdCgnb3BlbicpIHx8ICFlbmFibGVkIHx8IGlzRXZlbnRXaXRoaW5Pd25FbGVtZW50cyhldmVudCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgdG91Y2ggPSBldmVudC50b3VjaGVzWzBdO1xuICAgICAgaWYgKHRvdWNoKSB7XG4gICAgICAgIHRvdWNoU3RhdGVSZWYuY3VycmVudCA9IHtcbiAgICAgICAgICBzdGFydFRpbWU6IERhdGUubm93KCksXG4gICAgICAgICAgc3RhcnRYOiB0b3VjaC5jbGllbnRYLFxuICAgICAgICAgIHN0YXJ0WTogdG91Y2guY2xpZW50WSxcbiAgICAgICAgICBkaXNtaXNzT25Ub3VjaEVuZDogZmFsc2UsXG4gICAgICAgICAgZGlzbWlzc09uTW91c2VEb3duOiB0cnVlXG4gICAgICAgIH07XG4gICAgICAgIGNhbmNlbERpc21pc3NPbkVuZFRpbWVvdXQuc3RhcnQoMTAwMCwgKCkgPT4ge1xuICAgICAgICAgIGlmICh0b3VjaFN0YXRlUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICAgIHRvdWNoU3RhdGVSZWYuY3VycmVudC5kaXNtaXNzT25Ub3VjaEVuZCA9IGZhbHNlO1xuICAgICAgICAgICAgdG91Y2hTdGF0ZVJlZi5jdXJyZW50LmRpc21pc3NPbk1vdXNlRG93biA9IGZhbHNlO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIGFkZFRhcmdldEV2ZW50TGlzdGVuZXJPbmNlKGV2ZW50LCBsaXN0ZW5lcikge1xuICAgICAgY29uc3QgdGFyZ2V0ID0gZ2V0VGFyZ2V0KGV2ZW50KTtcbiAgICAgIGlmICghdGFyZ2V0KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHVuc3Vic2NyaWJlID0gYWRkRXZlbnRMaXN0ZW5lcih0YXJnZXQsIGV2ZW50LnR5cGUsICgpID0+IHtcbiAgICAgICAgbGlzdGVuZXIoZXZlbnQpO1xuICAgICAgICB1bnN1YnNjcmliZSgpO1xuICAgICAgfSk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGhhbmRsZVRvdWNoU3RhcnRDYXB0dXJlKGV2ZW50KSB7XG4gICAgICBjdXJyZW50UG9pbnRlclR5cGVSZWYuY3VycmVudCA9ICd0b3VjaCc7XG4gICAgICBhZGRUYXJnZXRFdmVudExpc3RlbmVyT25jZShldmVudCwgaGFuZGxlVG91Y2hTdGFydCk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNsb3NlT25QcmVzc091dHNpZGVDYXB0dXJlKGV2ZW50KSB7XG4gICAgICBjYW5jZWxEaXNtaXNzT25FbmRUaW1lb3V0LmNsZWFyKCk7XG5cbiAgICAgIC8vIE9ubHkgYHBvaW50ZXJkb3duYCBtYXJrcyBhIHByZXNzOyBgbW91c2Vkb3duYCBpcyBpdHMgY29tcGF0aWJpbGl0eSBldmVudCwgYW5kXG4gICAgICAvLyBjb3VudGluZyBpdCB3b3VsZCBtaXNhdHRyaWJ1dGUgYSBnZXN0dXJlIHRoYXQgc3RhcnRlZCBiZWZvcmUgb3Blbi5cbiAgICAgIGlmIChldmVudC50eXBlID09PSAncG9pbnRlcmRvd24nKSB7XG4gICAgICAgIC8vIE9ubHkgYSBwcmltYXJ5IHByZXNzIGNhbiBwcm9kdWNlIGEgYGNsaWNrYC5cbiAgICAgICAgaWYgKGV2ZW50LmJ1dHRvbiA9PT0gMCkge1xuICAgICAgICAgIHNhd1ByZXNzV2hpbGVPcGVuUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGN1cnJlbnRQb2ludGVyVHlwZVJlZi5jdXJyZW50ID0gZXZlbnQucG9pbnRlclR5cGU7XG4gICAgICB9XG4gICAgICBpZiAoZXZlbnQudHlwZSA9PT0gJ21vdXNlZG93bicgJiYgdG91Y2hTdGF0ZVJlZi5jdXJyZW50ICYmICF0b3VjaFN0YXRlUmVmLmN1cnJlbnQuZGlzbWlzc09uTW91c2VEb3duKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGFkZFRhcmdldEV2ZW50TGlzdGVuZXJPbmNlKGV2ZW50LCB0YXJnZXRFdmVudCA9PiB7XG4gICAgICAgIGlmICh0YXJnZXRFdmVudC50eXBlID09PSAncG9pbnRlcmRvd24nKSB7XG4gICAgICAgICAgaGFuZGxlUG9pbnRlckRvd24odGFyZ2V0RXZlbnQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNsb3NlT25QcmVzc091dHNpZGUodGFyZ2V0RXZlbnQpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaGFuZGxlUHJlc3NFbmRDYXB0dXJlKGV2ZW50KSB7XG4gICAgICAvLyBBIGNhbmNlbGxlZCBnZXN0dXJlIHByb2R1Y2VzIG5vIGNsaWNrLiBOb3QgY2xlYXJlZCBvbiBgcG9pbnRlcnVwYDogdGhlIGNsaWNrXG4gICAgICAvLyBmaXJlcyBhZnRlciBpdCBhbmQgbXVzdCBzdGlsbCBmaW5kIHRoZSBwcmVzcy5cbiAgICAgIGlmIChldmVudC50eXBlID09PSAncG9pbnRlcmNhbmNlbCcpIHtcbiAgICAgICAgc2F3UHJlc3NXaGlsZU9wZW5SZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgfVxuICAgICAgaWYgKCFwcmVzc1N0YXJ0ZWRJbnNpZGVSZWYuY3VycmVudCkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBjb25zdCBwcmVzc1N0YXJ0ZWRJbnNpZGVEZWZhdWx0UHJldmVudGVkID0gcHJlc3NTdGFydFByZXZlbnRlZFJlZi5jdXJyZW50O1xuICAgICAgcmVzZXRQcmVzc1N0YXJ0U3RhdGUoKTtcbiAgICAgIGlmIChnZXRPdXRzaWRlUHJlc3NFdmVudCgpICE9PSAnaW50ZW50aW9uYWwnKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChldmVudC50eXBlID09PSAncG9pbnRlcmNhbmNlbCcpIHtcbiAgICAgICAgaWYgKHByZXNzU3RhcnRlZEluc2lkZURlZmF1bHRQcmV2ZW50ZWQpIHtcbiAgICAgICAgICBzdXBwcmVzc0ltbWVkaWF0ZU91dHNpZGVDbGlja0FmdGVyUHJldmVudGVkU3RhcnQoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoaXNFdmVudFdpdGhpbkZsb2F0aW5nVHJlZShldmVudCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBJZiBwb2ludGVyZG93biB3YXMgcHJldmVudGVkLCBubyBjbGljayBtYXkgYmUgZ2VuZXJhdGVkIGZvciB0aGF0XG4gICAgICAvLyBpbnRlcmFjdGlvbi4gSG93ZXZlciwgRmlyZWZveCBtYXkgc3RpbGwgZW1pdCBhbiBpbW1lZGlhdGUgY2xpY2sgYWZ0ZXJcbiAgICAgIC8vIHBvaW50ZXJ1cCAoZS5nLiBOdW1iZXJGaWVsZCBzY3J1YiB3aXRoIHBvaW50ZXIgbG9jayksIHNvIHN1cHByZXNzIGZvclxuICAgICAgLy8gb25lIHRpY2sgdG8gYWJzb3JiIHRoYXQgc3ludGhldGljIGNsaWNrIG9ubHkuXG4gICAgICBpZiAocHJlc3NTdGFydGVkSW5zaWRlRGVmYXVsdFByZXZlbnRlZCkge1xuICAgICAgICBzdXBwcmVzc0ltbWVkaWF0ZU91dHNpZGVDbGlja0FmdGVyUHJldmVudGVkU3RhcnQoKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICAvLyBBdm9pZCBzdXBwcmVzc2luZyB3aGVuIG91dHNpZGVQcmVzcyBleHBsaWNpdGx5IGlnbm9yZXMgdGhpcyB0YXJnZXQuXG4gICAgICBpZiAodHlwZW9mIG91dHNpZGVQcmVzcyA9PT0gJ2Z1bmN0aW9uJyAmJiAhb3V0c2lkZVByZXNzKGV2ZW50KSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBwcmV2ZW50ZWRQcmVzc1N1cHByZXNzaW9uVGltZW91dC5jbGVhcigpO1xuICAgICAgc3VwcHJlc3NOZXh0T3V0c2lkZUNsaWNrUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgY2xlYXJJbnNpZGVSZWFjdFRyZWUoKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gaGFuZGxlVG91Y2hNb3ZlKGV2ZW50KSB7XG4gICAgICBpZiAoZ2V0T3V0c2lkZVByZXNzRXZlbnQoKSAhPT0gJ3Nsb3BweScgfHwgIXRvdWNoU3RhdGVSZWYuY3VycmVudCB8fCBpc0V2ZW50V2l0aGluT3duRWxlbWVudHMoZXZlbnQpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHRvdWNoID0gZXZlbnQudG91Y2hlc1swXTtcbiAgICAgIGlmICghdG91Y2gpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgZGVsdGFYID0gTWF0aC5hYnModG91Y2guY2xpZW50WCAtIHRvdWNoU3RhdGVSZWYuY3VycmVudC5zdGFydFgpO1xuICAgICAgY29uc3QgZGVsdGFZID0gTWF0aC5hYnModG91Y2guY2xpZW50WSAtIHRvdWNoU3RhdGVSZWYuY3VycmVudC5zdGFydFkpO1xuICAgICAgY29uc3QgZGlzdGFuY2UgPSBNYXRoLnNxcnQoZGVsdGFYICogZGVsdGFYICsgZGVsdGFZICogZGVsdGFZKTtcbiAgICAgIGlmIChkaXN0YW5jZSA+IDUpIHtcbiAgICAgICAgdG91Y2hTdGF0ZVJlZi5jdXJyZW50LmRpc21pc3NPblRvdWNoRW5kID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGlmIChkaXN0YW5jZSA+IDEwKSB7XG4gICAgICAgIGNsb3NlT25QcmVzc091dHNpZGUoZXZlbnQpO1xuICAgICAgICBjYW5jZWxEaXNtaXNzT25FbmRUaW1lb3V0LmNsZWFyKCk7XG4gICAgICAgIHRvdWNoU3RhdGVSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIGhhbmRsZVRvdWNoTW92ZUNhcHR1cmUoZXZlbnQpIHtcbiAgICAgIGFkZFRhcmdldEV2ZW50TGlzdGVuZXJPbmNlKGV2ZW50LCBoYW5kbGVUb3VjaE1vdmUpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVUb3VjaEVuZChldmVudCkge1xuICAgICAgaWYgKGdldE91dHNpZGVQcmVzc0V2ZW50KCkgIT09ICdzbG9wcHknIHx8ICF0b3VjaFN0YXRlUmVmLmN1cnJlbnQgfHwgaXNFdmVudFdpdGhpbk93bkVsZW1lbnRzKGV2ZW50KSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAodG91Y2hTdGF0ZVJlZi5jdXJyZW50LmRpc21pc3NPblRvdWNoRW5kKSB7XG4gICAgICAgIGNsb3NlT25QcmVzc091dHNpZGUoZXZlbnQpO1xuICAgICAgfVxuICAgICAgY2FuY2VsRGlzbWlzc09uRW5kVGltZW91dC5jbGVhcigpO1xuICAgICAgdG91Y2hTdGF0ZVJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICB9XG4gICAgZnVuY3Rpb24gaGFuZGxlVG91Y2hFbmRDYXB0dXJlKGV2ZW50KSB7XG4gICAgICBhZGRUYXJnZXRFdmVudExpc3RlbmVyT25jZShldmVudCwgaGFuZGxlVG91Y2hFbmQpO1xuICAgIH1cbiAgICBjb25zdCB1bnN1YnNjcmliZSA9IG1lcmdlQ2xlYW51cHMoZXNjYXBlS2V5ICYmIG1lcmdlQ2xlYW51cHMoYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdrZXlkb3duJywgY2xvc2VPbkVzY2FwZUtleURvd24pLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ2NvbXBvc2l0aW9uc3RhcnQnLCBoYW5kbGVDb21wb3NpdGlvblN0YXJ0KSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICdjb21wb3NpdGlvbmVuZCcsIGhhbmRsZUNvbXBvc2l0aW9uRW5kKSksIG91dHNpZGVQcmVzc0VuYWJsZWQgJiYgbWVyZ2VDbGVhbnVwcyhhZGRFdmVudExpc3RlbmVyKGRvYywgJ2NsaWNrJywgY2xvc2VPblByZXNzT3V0c2lkZUNhcHR1cmUsIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ3BvaW50ZXJkb3duJywgY2xvc2VPblByZXNzT3V0c2lkZUNhcHR1cmUsIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ3BvaW50ZXJ1cCcsIGhhbmRsZVByZXNzRW5kQ2FwdHVyZSwgdHJ1ZSksIGFkZEV2ZW50TGlzdGVuZXIoZG9jLCAncG9pbnRlcmNhbmNlbCcsIGhhbmRsZVByZXNzRW5kQ2FwdHVyZSwgdHJ1ZSksIGFkZEV2ZW50TGlzdGVuZXIoZG9jLCAnbW91c2Vkb3duJywgY2xvc2VPblByZXNzT3V0c2lkZUNhcHR1cmUsIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ21vdXNldXAnLCBoYW5kbGVQcmVzc0VuZENhcHR1cmUsIHRydWUpLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ3RvdWNoc3RhcnQnLCBoYW5kbGVUb3VjaFN0YXJ0Q2FwdHVyZSwge1xuICAgICAgY2FwdHVyZTogdHJ1ZSxcbiAgICAgIHBhc3NpdmU6IHRydWVcbiAgICB9KSwgYWRkRXZlbnRMaXN0ZW5lcihkb2MsICd0b3VjaG1vdmUnLCBoYW5kbGVUb3VjaE1vdmVDYXB0dXJlLCB7XG4gICAgICBjYXB0dXJlOiB0cnVlLFxuICAgICAgcGFzc2l2ZTogdHJ1ZVxuICAgIH0pLCBhZGRFdmVudExpc3RlbmVyKGRvYywgJ3RvdWNoZW5kJywgaGFuZGxlVG91Y2hFbmRDYXB0dXJlLCB7XG4gICAgICBjYXB0dXJlOiB0cnVlLFxuICAgICAgcGFzc2l2ZTogdHJ1ZVxuICAgIH0pKSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHVuc3Vic2NyaWJlKCk7XG4gICAgICBwcmV2ZW50ZWRQcmVzc1N1cHByZXNzaW9uVGltZW91dC5jbGVhcigpO1xuICAgICAgcmVzZXRQcmVzc1N0YXJ0U3RhdGUoKTtcbiAgICAgIHN1cHByZXNzTmV4dE91dHNpZGVDbGlja1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgfTtcbiAgfSwgW2RhdGFSZWYsIGZsb2F0aW5nRWxlbWVudCwgZXNjYXBlS2V5LCBvdXRzaWRlUHJlc3NFbmFibGVkLCBvdXRzaWRlUHJlc3MsIG9wZW4sIGVuYWJsZWQsIGVzY2FwZUtleUJ1YmJsZXMsIG91dHNpZGVQcmVzc0J1YmJsZXMsIGNsb3NlT25Fc2NhcGVLZXlEb3duLCBjbGVhckluc2lkZVJlYWN0VHJlZSwgZ2V0T3V0c2lkZVByZXNzRXZlbnRQcm9wLCBoYXNCbG9ja2luZ0NoaWxkLCBpc0V2ZW50V2l0aGluT3duRWxlbWVudHMsIHRyZWUsIHN0b3JlLCBjYW5jZWxEaXNtaXNzT25FbmRUaW1lb3V0LCBjb21wb3NpdGlvblRpbWVvdXRdKTtcbiAgY29uc3QgcmVmZXJlbmNlID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIG9uS2V5RG93bjogY2xvc2VPbkVzY2FwZUtleURvd24sXG4gICAgb25Qb2ludGVyRG93bjogY2xvc2VPblJlZmVyZW5jZVByZXNzLFxuICAgIG9uQ2xpY2s6IGNsb3NlT25SZWZlcmVuY2VQcmVzc1xuICB9KSwgW2Nsb3NlT25Fc2NhcGVLZXlEb3duLCBjbG9zZU9uUmVmZXJlbmNlUHJlc3NdKTtcbiAgY29uc3QgZmxvYXRpbmcgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgb25LZXlEb3duOiBjbG9zZU9uRXNjYXBlS2V5RG93bixcbiAgICAvLyBgb25Nb3VzZURvd25gIG1heSBiZSBibG9ja2VkIGlmIGBldmVudC5wcmV2ZW50RGVmYXVsdCgpYCBpcyBjYWxsZWQgaW5cbiAgICAvLyBgb25Qb2ludGVyRG93bmAsIHN1Y2ggYXMgd2l0aCA8TnVtYmVyRmllbGQuU2NydWJBcmVhPi5cbiAgICAvLyBTZWUgaHR0cHM6Ly9naXRodWIuY29tL211aS9iYXNlLXVpL3B1bGwvMzM3OVxuICAgIG9uUG9pbnRlckRvd246IG1hcmtJbnNpZGVQcmVzc1N0YXJ0UHJldmVudGVkLFxuICAgIG9uTW91c2VEb3duOiBtYXJrSW5zaWRlUHJlc3NTdGFydFByZXZlbnRlZCxcbiAgICBvbkNsaWNrQ2FwdHVyZTogbWFya0luc2lkZVJlYWN0VHJlZSxcbiAgICBvbk1vdXNlRG93bkNhcHR1cmUoZXZlbnQpIHtcbiAgICAgIG1hcmtJbnNpZGVSZWFjdFRyZWUoKTtcbiAgICAgIG1hcmtQcmVzc1N0YXJ0ZWRJbnNpZGVSZWFjdFRyZWUoZXZlbnQpO1xuICAgIH0sXG4gICAgb25Qb2ludGVyRG93bkNhcHR1cmUoZXZlbnQpIHtcbiAgICAgIG1hcmtJbnNpZGVSZWFjdFRyZWUoKTtcbiAgICAgIG1hcmtQcmVzc1N0YXJ0ZWRJbnNpZGVSZWFjdFRyZWUoZXZlbnQpO1xuICAgIH0sXG4gICAgb25Nb3VzZVVwQ2FwdHVyZTogbWFya0luc2lkZVJlYWN0VHJlZSxcbiAgICBvblRvdWNoRW5kQ2FwdHVyZTogbWFya0luc2lkZVJlYWN0VHJlZSxcbiAgICBvblRvdWNoTW92ZUNhcHR1cmU6IG1hcmtJbnNpZGVSZWFjdFRyZWVcbiAgfSksIFtjbG9zZU9uRXNjYXBlS2V5RG93biwgbWFya0luc2lkZVJlYWN0VHJlZSwgbWFya1ByZXNzU3RhcnRlZEluc2lkZVJlYWN0VHJlZSwgbWFya0luc2lkZVByZXNzU3RhcnRQcmV2ZW50ZWRdKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gZW5hYmxlZCA/IHtcbiAgICByZWZlcmVuY2UsXG4gICAgZmxvYXRpbmcsXG4gICAgdHJpZ2dlcjogcmVmZXJlbmNlXG4gIH0gOiB7fSwgW2VuYWJsZWQsIHJlZmVyZW5jZSwgZmxvYXRpbmddKTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyBpc0VsZW1lbnQgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcblxuLyoqXG4gKiBOYXJyb3dlZCB0byB0aGUgc3RvcmUgbWVtYmVycyB0aGlzIGhvb2sgdXNlcyBzbyBjb25zdW1lcnMgZG8gbm90IG5lZWQgdG8gcHJvdmlkZVxuICogdW5yZWxhdGVkIHN0b3JlIGNhcGFiaWxpdGllcy5cbiAqL1xuXG4vKipcbiAqIEtlZXBzIHRoZSBwcm92aWRlZCBGbG9hdGluZ1Jvb3RTdG9yZSBpbiBzeW5jIHdpdGggdGhlIHByb3ZpZGVkIFBvcHVwU3RvcmUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VTeW5jZWRGbG9hdGluZ1Jvb3RDb250ZXh0KG9wdGlvbnMpIHtcbiAgY29uc3Qge1xuICAgIHBvcHVwU3RvcmUsXG4gICAgdHJlYXRQb3B1cEFzRmxvYXRpbmdFbGVtZW50ID0gZmFsc2UsXG4gICAgZmxvYXRpbmdSb290Q29udGV4dDogc3RvcmUsXG4gICAgZmxvYXRpbmdJZCxcbiAgICBuZXN0ZWQsXG4gICAgb25PcGVuQ2hhbmdlXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCBvcGVuID0gcG9wdXBTdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCByZWZlcmVuY2VFbGVtZW50ID0gcG9wdXBTdG9yZS51c2VTdGF0ZSgnYWN0aXZlVHJpZ2dlckVsZW1lbnQnKTtcbiAgY29uc3QgZmxvYXRpbmdFbGVtZW50ID0gcG9wdXBTdG9yZS51c2VTdGF0ZSh0cmVhdFBvcHVwQXNGbG9hdGluZ0VsZW1lbnQgPyAncG9wdXBFbGVtZW50JyA6ICdwb3NpdGlvbmVyRWxlbWVudCcpO1xuICBjb25zdCBoYW5kbGVPcGVuQ2hhbmdlID0gb25PcGVuQ2hhbmdlO1xuICBwb3B1cFN0b3JlLnVzZVN5bmNlZFZhbHVlKCdmbG9hdGluZ0lkJywgZmxvYXRpbmdJZCk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgdmFsdWVzVG9TeW5jID0ge1xuICAgICAgb3BlbixcbiAgICAgIGZsb2F0aW5nSWQsXG4gICAgICByZWZlcmVuY2VFbGVtZW50LFxuICAgICAgZmxvYXRpbmdFbGVtZW50XG4gICAgfTtcbiAgICBpZiAoaXNFbGVtZW50KHJlZmVyZW5jZUVsZW1lbnQpKSB7XG4gICAgICB2YWx1ZXNUb1N5bmMuZG9tUmVmZXJlbmNlRWxlbWVudCA9IHJlZmVyZW5jZUVsZW1lbnQ7XG4gICAgfVxuICAgIGlmIChzdG9yZS5zdGF0ZS5wb3NpdGlvblJlZmVyZW5jZSA9PT0gc3RvcmUuc3RhdGUucmVmZXJlbmNlRWxlbWVudCkge1xuICAgICAgdmFsdWVzVG9TeW5jLnBvc2l0aW9uUmVmZXJlbmNlID0gcmVmZXJlbmNlRWxlbWVudDtcbiAgICB9XG4gICAgc3RvcmUudXBkYXRlKHZhbHVlc1RvU3luYyk7XG4gIH0sIFtvcGVuLCBmbG9hdGluZ0lkLCByZWZlcmVuY2VFbGVtZW50LCBmbG9hdGluZ0VsZW1lbnQsIHN0b3JlXSk7XG5cbiAgLy8gS2VlcCBub24tcmVhY3RpdmUgY29udGV4dCB2YWx1ZXMgZnJlc2ggZm9yIGludGVyYWN0aW9ucyB0aGF0IGNhbGwgYHN0b3JlLnNldE9wZW5gLlxuICBzdG9yZS5jb250ZXh0Lm9uT3BlbkNoYW5nZSA9IGhhbmRsZU9wZW5DaGFuZ2U7XG4gIHN0b3JlLmNvbnRleHQubmVzdGVkID0gbmVzdGVkO1xuICByZXR1cm4gc3RvcmU7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VTdGFibGVDYWxsYmFjayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrJztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VGb3JjZWRSZXJlbmRlcmluZyB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUZvcmNlZFJlcmVuZGVyaW5nJztcbmltcG9ydCB7IHVzZVRyYW5zaXRpb25TdGF0dXMgfSBmcm9tIFwiLi91c2VUcmFuc2l0aW9uU3RhdHVzLm1qc1wiO1xuaW1wb3J0IHsgdXNlT3BlbkNoYW5nZUNvbXBsZXRlIH0gZnJvbSBcIi4vdXNlT3BlbkNoYW5nZUNvbXBsZXRlLm1qc1wiO1xuLyoqXG4gKiBLZWVwcyBhIHBvcHVwIG1vdW50ZWQgdGhyb3VnaCBpdHMgY2xvc2luZyBhbmltYXRpb24gYW5kIHVubW91bnRzIGl0IG9uY2UgdGhlIGFuaW1hdGlvblxuICogZmluaXNoZXMsIHVubGVzcyB0aGUgY2xvc2UgY3ljbGUgb3B0ZWQgb3V0IHRocm91Z2ggYHByZXZlbnRVbm1vdW50T25DbG9zZWAuXG4gKiBTdG9yZS1hZ25vc3RpYzogaG9zdHMgc3luYyBgbW91bnRlZGAgYW5kIGB0cmFuc2l0aW9uU3RhdHVzYCB3aGVyZXZlciB0aGV5IG5lZWQgdGhlbS5cbiAqXG4gKiBAcmV0dXJucyBgZm9yY2VVbm1vdW50YCB1bm1vdW50cyB0aGUgcG9wdXAgaW1tZWRpYXRlbHkuIEl0IGlzIGEgbm8tb3Agb25jZSB0aGUgcG9wdXAgaXMgYWxyZWFkeVxuICogICB1bm1vdW50ZWQsIHNvIGNhbGxpbmcgaXQgYWZ0ZXIgdGhlIGF1dG9tYXRpYyB1bm1vdW50IGRvZXNuJ3QgcmVwZWF0IHRoZSBjb21wbGV0aW9uIGNhbGxiYWNrLFxuICogICBhbmQgYSBjYWxsIHdoaWxlIHRoZSBwb3B1cCBpcyBvcGVuIG9ubHkgdGFrZXMgZWZmZWN0IGlmIGEgY2xvc2UgY29tbWl0cyBpbiB0aGUgc2FtZSBiYXRjaC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVVubW91bnRBZnRlckNsb3NlKHBhcmFtZXRlcnMpIHtcbiAgY29uc3Qge1xuICAgIG9wZW4sXG4gICAgcmVmLFxuICAgIHByZXZlbnRVbm1vdW50T25DbG9zZSxcbiAgICBzZXRQcmV2ZW50VW5tb3VudE9uQ2xvc2U6IHNldFByZXZlbnRVbm1vdW50T25DbG9zZVBhcmFtLFxuICAgIG9uVW5tb3VudCxcbiAgICBhbmltYXRlSW5pdGlhbE9wZW5cbiAgfSA9IHBhcmFtZXRlcnM7XG4gIGNvbnN0IHNldFByZXZlbnRVbm1vdW50T25DbG9zZSA9IHVzZVN0YWJsZUNhbGxiYWNrKHNldFByZXZlbnRVbm1vdW50T25DbG9zZVBhcmFtKTtcbiAgY29uc3Qge1xuICAgIG1vdW50ZWQsXG4gICAgc2V0TW91bnRlZCxcbiAgICB0cmFuc2l0aW9uU3RhdHVzXG4gIH0gPSB1c2VUcmFuc2l0aW9uU3RhdHVzKG9wZW4sIGZhbHNlLCBmYWxzZSwgYW5pbWF0ZUluaXRpYWxPcGVuKTtcblxuICAvLyBPcGVuaW5nIHN0YXJ0cyBhIG5ldyBjbG9zZSBjeWNsZS4gRGVyaXZlIGR1cmluZyByZW5kZXIgc28gdGhlIGNsb3NlLWNvbXBsZXRpb24gaG9vayBiZWxvd1xuICAvLyByZWFkcyB0aGUgdmFsdWUgb24gdGhlIHNhbWUgcGFzcywgYW5kIGNsZWFyIHRoZSBzdG9yZWQgdmFsdWUgc28gaXQgZG9lc24ndCBsZWFrIGludG8gdGhlIG5leHRcbiAgLy8gY2xvc2UuIFRoZSBlZmZlY3Qgb25seSBydW5zIHdoZW4gYG9wZW5gIGNoYW5nZXMsIHNvIGFuIG9wdC1vdXQgcmVjb3JkZWQgd2hpbGUgYSBjb250cm9sbGVkXG4gIC8vIGNsb3NlIGlzIHN0aWxsIHBlbmRpbmcgKGZvciBleGFtcGxlIGluIGEgdHJhbnNpdGlvbikgaXMgbm90IGNsZWFyZWQgYnkgdGhlIHJlbmRlciB0aGF0IHN0aWxsXG4gIC8vIHNlZXMgYG9wZW5gLlxuICBjb25zdCBwcmV2ZW50VW5tb3VudGluZ09uQ2xvc2UgPSBvcGVuID8gZmFsc2UgOiBwcmV2ZW50VW5tb3VudE9uQ2xvc2U7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKG9wZW4pIHtcbiAgICAgIHNldFByZXZlbnRVbm1vdW50T25DbG9zZShmYWxzZSk7XG4gICAgfVxuICB9LCBbb3Blbiwgc2V0UHJldmVudFVubW91bnRPbkNsb3NlXSk7XG5cbiAgLy8gTWlycm9ycyBgbW91bnRlZGAgc3luY2hyb25vdXNseSBzbyByZXBlYXRlZCBgZm9yY2VVbm1vdW50KClgIGNhbGxzIGluIG9uZSBiYXRjaCBjb21wbGV0ZVxuICAvLyBjbG9zaW5nIG9uY2UuIFJlc3luY2VkIG9uIGV2ZXJ5IGNvbW1pdDogYHNldE1vdW50ZWQoZmFsc2UpYCB3aGlsZSBvcGVuIHJlLW1vdW50cyBvbiB0aGUgbmV4dFxuICAvLyByZW5kZXIgd2l0aG91dCBjaGFuZ2luZyB0aGUgY29tbWl0dGVkIGBtb3VudGVkYCwgc28gYSBgW21vdW50ZWRdYCBkZXBlbmRlbmN5IHdvdWxkIGxlYXZlIHRoZVxuICAvLyBtaXJyb3Igc3RhbGUgYW5kIGJsb2NrIGV2ZXJ5IGxhdGVyIHVubW91bnQuXG4gIGNvbnN0IG1vdW50ZWRSZWYgPSBSZWFjdC51c2VSZWYobW91bnRlZCk7XG4gIGNvbnN0IHBlbmRpbmdVbm1vdW50UmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgY29uc3QgcmVyZW5kZXIgPSB1c2VGb3JjZWRSZXJlbmRlcmluZygpO1xuICBjb25zdCB1bm1vdW50ID0gKCkgPT4ge1xuICAgIG1vdW50ZWRSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgIHNldE1vdW50ZWQoZmFsc2UpO1xuICAgIG9uVW5tb3VudCgpO1xuICB9O1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIG1vdW50ZWRSZWYuY3VycmVudCA9IG1vdW50ZWQ7XG4gICAgaWYgKHBlbmRpbmdVbm1vdW50UmVmLmN1cnJlbnQpIHtcbiAgICAgIHBlbmRpbmdVbm1vdW50UmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgIGlmICghb3BlbiAmJiBtb3VudGVkKSB7XG4gICAgICAgIHVubW91bnQoKTtcbiAgICAgIH1cbiAgICB9XG4gIH0pO1xuICBjb25zdCBmb3JjZVVubW91bnQgPSB1c2VTdGFibGVDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKCFtb3VudGVkUmVmLmN1cnJlbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKG9wZW4pIHtcbiAgICAgIC8vIFRoZSByZW5kZXJlZCBgb3BlbmAgY2FuJ3QgdGVsbCBhIHN0YWxlIGV4aXQtYW5pbWF0aW9uIGNhbGxiYWNrIGFmdGVyIGEgcXVpY2sgcmVvcGVuIGZyb20gYVxuICAgICAgLy8gY2xvc2UgYmF0Y2hlZCB3aXRoIHRoaXMgY2FsbCAoYGNsb3NlKCk7IHVubW91bnQoKWApLiBEZWNpZGUgb25jZSB0aGUgYmF0Y2ggY29tbWl0czogdW5tb3VudFxuICAgICAgLy8gaWYgdGhlIHBvcHVwIGNsb3NlZCwgb3RoZXJ3aXNlIGRyb3AgdGhlIGNhbGwgcmF0aGVyIHRoYW4gcnVuIHRoZSBob3N0J3MgdW5tb3VudCBjbGVhbnVwIGFuZFxuICAgICAgLy8gdGhlIGNsb3NlIGNvbXBsZXRpb24gYWdhaW5zdCBhIGxpdmUgcG9wdXAuXG4gICAgICBwZW5kaW5nVW5tb3VudFJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIHJlcmVuZGVyKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHVubW91bnQoKTtcbiAgfSk7XG4gIHVzZU9wZW5DaGFuZ2VDb21wbGV0ZSh7XG4gICAgZW5hYmxlZDogbW91bnRlZCAmJiAhb3BlbiAmJiAhcHJldmVudFVubW91bnRpbmdPbkNsb3NlLFxuICAgIG9wZW4sXG4gICAgcmVmLFxuICAgIG9uQ29tcGxldGUoKSB7XG4gICAgICBpZiAoIW9wZW4pIHtcbiAgICAgICAgZm9yY2VVbm1vdW50KCk7XG4gICAgICB9XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBtb3VudGVkLFxuICAgIHRyYW5zaXRpb25TdGF0dXMsXG4gICAgcHJldmVudFVubW91bnRpbmdPbkNsb3NlLFxuICAgIGZvcmNlVW5tb3VudFxuICB9O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0ICogYXMgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tJztcbmltcG9ydCB7IEVNUFRZX09CSkVDVCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2VtcHR5JztcbmltcG9ydCB7IHVzZUlkIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSWQnO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgdXNlUmVmV2l0aEluaXQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VSZWZXaXRoSW5pdCc7XG5pbXBvcnQgeyBGT0NVU0FCTEVfQVRUUklCVVRFIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL2NvbnN0YW50cy5tanNcIjtcbmltcG9ydCB7IHVzZUZsb2F0aW5nUGFyZW50Tm9kZUlkIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2NvbXBvbmVudHMvRmxvYXRpbmdUcmVlLm1qc1wiO1xuaW1wb3J0IHsgdXNlU3luY2VkRmxvYXRpbmdSb290Q29udGV4dCB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9ob29rcy91c2VTeW5jZWRGbG9hdGluZ1Jvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlVW5tb3VudEFmdGVyQ2xvc2UgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVVubW91bnRBZnRlckNsb3NlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuZXhwb3J0IGNvbnN0IEZPQ1VTQUJMRV9QT1BVUF9QUk9QUyA9IHtcbiAgdGFiSW5kZXg6IC0xLFxuICBbRk9DVVNBQkxFX0FUVFJJQlVURV06ICcnXG59O1xuXG4vKipcbiAqIFJldHVybnMgdGhlIGRlZmF1bHQgYGluaXRpYWxGb2N1c2AgcmVzb2x2ZXIgZm9yIGEgcG9wdXAuIFdoZW4gb3BlbmVkIGJ5IHRvdWNoIGl0IGZvY3VzZXMgdGhlXG4gKiBwb3B1cCBlbGVtZW50IGl0c2VsZiB0byBwcmV2ZW50IHRoZSB2aXJ0dWFsIGtleWJvYXJkIGZyb20gb3BlbmluZyAocmVxdWlyZWQgZm9yIEFuZHJvaWRcbiAqIHNwZWNpZmljYWxseTsgaU9TIGhhbmRsZXMgdGhpcyBhdXRvbWF0aWNhbGx5KS4gT3RoZXJ3aXNlIGl0IGZhbGxzIGJhY2sgdG8gdGhlIGRlZmF1bHQgYmVoYXZpb3IuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVEZWZhdWx0SW5pdGlhbEZvY3VzKHBvcHVwUmVmKSB7XG4gIHJldHVybiBpbnRlcmFjdGlvblR5cGUgPT4gaW50ZXJhY3Rpb25UeXBlID09PSAndG91Y2gnID8gcG9wdXBSZWYuY3VycmVudCA6IHRydWU7XG59XG5cbi8qKlxuICogVGhlIHN1YnNldCBvZiBhIHBvcHVwIGhhbmRsZSB0aGF0IGEgUm9vdCBuZWVkcyB0byBiaW5kIGl0cyBzdG9yZSB0by4gQm90aCB0aGUgcmVhbCBoYW5kbGUgY2xhc3Nlc1xuICogYW5kIGFueSB0ZXN0IGRvdWJsZSBzYXRpc2Z5IGl0LlxuICovXG5cbi8qKlxuICogQ3JlYXRlcyBhbmQgb3ducyBhIHBvcHVwIHN0b3JlIG9uIGJlaGFsZiBvZiBhIFJvb3QgcGFydC4gVGhlIHN0b3JlIGlzIGNyZWF0ZWQgZXhhY3RseSBvbmNlLCB3aXRoXG4gKiBjb250cm9sbGVkIHByb3BzIGFuZCByb290IHN0YXRlIHN5bmNlZCBzZXBhcmF0ZWx5IGFmdGVyIGNyZWF0aW9uLiBTZXRzIHVwIHRoZSBzeW5jZWQgZmxvYXRpbmdcbiAqIHJvb3QgY29udGV4dCBhbmQgcmV0dXJucyB0aGUgc3RvcmUuXG4gKlxuICogQHBhcmFtIGNyZWF0ZVN0b3JlIEZhY3RvcnkgdGhhdCBidWlsZHMgdGhlIHN0b3JlLiBDYWxsZWQgZXhhY3RseSBvbmNlLCByZWNlaXZpbmcgdGhlIGZsb2F0aW5nIGlkXG4gKiBhbmQgd2hldGhlciB0aGUgcG9wdXAgaXMgbmVzdGVkIGluc2lkZSBhbm90aGVyIGZsb2F0aW5nIGVsZW1lbnQsIGJvdGggcmVzb2x2ZWQgb24gdGhlIGZpcnN0IHJlbmRlci5cbiAqIEBwYXJhbSB0cmVhdFBvcHVwQXNGbG9hdGluZ0VsZW1lbnQgV2hldGhlciB0aGUgcG9wdXAgZWxlbWVudCBpcyBwYXNzZWQgdG8gRmxvYXRpbmcgVUkgYXMgdGhlXG4gKiBmbG9hdGluZyBlbGVtZW50IGluc3RlYWQgb2YgdGhlIGRlZmF1bHQgcG9zaXRpb25lci5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVBvcHVwUm9vdFN0b3JlKGNyZWF0ZVN0b3JlLCB0cmVhdFBvcHVwQXNGbG9hdGluZ0VsZW1lbnQgPSBmYWxzZSkge1xuICBjb25zdCBmbG9hdGluZ0lkID0gdXNlSWQoKTtcbiAgY29uc3QgbmVzdGVkID0gdXNlRmxvYXRpbmdQYXJlbnROb2RlSWQoKSAhPSBudWxsO1xuICBjb25zdCBzdG9yZSA9IHVzZVJlZldpdGhJbml0KCgpID0+IGNyZWF0ZVN0b3JlKGZsb2F0aW5nSWQsIG5lc3RlZCkpLmN1cnJlbnQ7XG4gIHVzZVN5bmNlZEZsb2F0aW5nUm9vdENvbnRleHQoe1xuICAgIHBvcHVwU3RvcmU6IHN0b3JlLFxuICAgIHRyZWF0UG9wdXBBc0Zsb2F0aW5nRWxlbWVudCxcbiAgICBmbG9hdGluZ1Jvb3RDb250ZXh0OiBzdG9yZS5zdGF0ZS5mbG9hdGluZ1Jvb3RDb250ZXh0LFxuICAgIGZsb2F0aW5nSWQsXG4gICAgbmVzdGVkLFxuICAgIG9uT3BlbkNoYW5nZTogc3RvcmUuc2V0T3BlblxuICB9KTtcbiAgcmV0dXJuIHN0b3JlO1xufVxuXG4vKipcbiAqIEF0dGFjaGVzIGEgUm9vdCdzIHN0b3JlIHRvIGEgaGFuZGxlIGZvciB0aGlzIGNvbXBvbmVudCdzIGNvbW1pdHRlZCBsaWZldGltZS4gUG9wdXAgUm9vdHMgcmVuZGVyXG4gKiBpdCBiZWZvcmUgdGhlaXIgaW50ZXJhY3Rpb25zIGFuZCB1c2VyIGNoaWxkcmVuIHNvIGl0cyBsYXlvdXQgZWZmZWN0IHJ1bnMgYmVmb3JlIGRlc2NlbmRhbnQgbGF5b3V0XG4gKiBlZmZlY3RzLiBUaGlzIGxldHMgZGVzY2VuZGFudHMgY2FsbCB0aGUgaGFuZGxlIGR1cmluZyB0aGUgUm9vdCdzIGluaXRpYWwgY29tbWl0IHdpdGhvdXQgYXR0YWNoaW5nXG4gKiBkdXJpbmcgcmVuZGVyLCB3aGljaCB3b3VsZCBsZWFrIHN1c3BlbmRlZCBvciBhYmFuZG9uZWQgc3RvcmVzLiBTdG9yZSBzdWJzY3JpYmVycyBhcmUgbm90aWZpZWQgYnlcbiAqIGBhdHRhY2hTdG9yZWAgaW4gdGhpcyBvcmRpbmFyeSBsYXlvdXQgcGhhc2UsIHdoZXJlIFJlYWN0IHBlcm1pdHMgc3luY2hyb25vdXMgdXBkYXRlcy5cbiAqXG4gKiBQb3B1cCBSb290cyBtdXN0IHJlbmRlciB0aGlzIGNvbXBvbmVudCBvbmx5IHdoZW4gYSBoYW5kbGUgaXMgcHJlc2VudCBzbyBoYW5kbGUtbGVzcyBSb290cyBhdm9pZFxuICogbW91bnRpbmcgYW4gZXh0cmEgZmliZXIgYW5kIGxheW91dCBlZmZlY3QuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBQb3B1cEhhbmRsZUF0dGFjaG1lbnQoe1xuICBoYW5kbGUsXG4gIHN0b3JlXG59KSB7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgcmV0dXJuIGhhbmRsZS5hdHRhY2hTdG9yZShzdG9yZSk7XG4gIH0sIFtoYW5kbGUsIHN0b3JlXSk7XG4gIHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gc3luY1RyaWdnZXJDb3VudChzdG9yZSkge1xuICBjb25zdCB0cmlnZ2VyQ291bnQgPSBzdG9yZS5jb250ZXh0LnRyaWdnZXJFbGVtZW50cy5zaXplO1xuICBpZiAoc3RvcmUuc2VsZWN0KCdvcGVuJykgJiYgc3RvcmUuc3RhdGUudHJpZ2dlckNvdW50ICE9PSB0cmlnZ2VyQ291bnQpIHtcbiAgICBzdG9yZS5zZXQoJ3RyaWdnZXJDb3VudCcsIHRyaWdnZXJDb3VudCk7XG4gIH1cbn1cblxuLyoqXG4gKiBSZXR1cm5zIGEgc3RhYmxlIGNhbGxiYWNrIHJlZiB0aGF0IHJlZ2lzdGVycy91bnJlZ2lzdGVycyB0aGUgdHJpZ2dlciBlbGVtZW50IGluIHRoZSBzdG9yZS5cbiAqXG4gKiBTdGFibGUgc28gYSBkb3duc3RyZWFtIHJlZiBtZXJnZXIgdGhhdCByZXRhaW5zIHRoZSBjYWxsYmFjayBpdCB3YXMgZmlyc3QgZ2l2ZW4gc3RpbGwgcmVhY2hlcyB0aGVcbiAqIHRyaWdnZXIncyBjdXJyZW50IHN0b3JlLiBUaGUgcmVnaXN0cmF0aW9uIGlzIHRyYWNrZWQgYXMgYSBgKHN0b3JlLCBpZCwgZWxlbWVudClgIHRyaXBsZSwgc29cbiAqIHVucmVnaXN0ZXJpbmcgdGFyZ2V0cyB0aGUgc3RvcmUgdGhlIGVsZW1lbnQgd2FzIGFjdHVhbGx5IHJlZ2lzdGVyZWQgaW4uXG4gKlxuICogU2luY2UgdGhlIGNhbGxiYWNrIG5ldmVyIGNoYW5nZXMsIHRoZSBjYWxsZXIgbXVzdCByZS1ydW4gaXQgZnJvbSBhIGxheW91dCBlZmZlY3Qga2V5ZWQgb25cbiAqIGBbc3RvcmUsIGlkXWAgdG8gbWlncmF0ZSBhbiBhbHJlYWR5LXJlZ2lzdGVyZWQgZWxlbWVudC4gVGhhdCBlZmZlY3QgaXMgYWxzbyB3aGF0IHJlZ2lzdGVycyB0aGVcbiAqIGVsZW1lbnQgaW4gdGhlIGZpcnN0IHBsYWNlIHdoZW4gYGlkYCBvbmx5IHJlc29sdmVzIGFmdGVyIHRoZSBmaXJzdCBjb21taXQgKFJlYWN0IDE3J3MgYHVzZUlkYFxuICogZmFsbGJhY2spLCBiZWNhdXNlIHRoZSByZWdpc3RlciBjYWxsIG1hZGUgd2hpbGUgdGhlIGlkIGlzIHN0aWxsIGB1bmRlZmluZWRgIGRvZXMgbm90aGluZy5cbiAqXG4gKiBAcGFyYW0gaWQgSWQgb2YgdGhlIHRyaWdnZXIuXG4gKiBAcGFyYW0gc3RvcmUgVGhlIFN0b3JlIGluc3RhbmNlIHdoZXJlIHRoZSB0cmlnZ2VyIHNob3VsZCBiZSByZWdpc3RlcmVkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlVHJpZ2dlclJlZ2lzdHJhdGlvbihpZCwgc3RvcmUpIHtcbiAgY29uc3QgcmVnaXN0cmF0aW9uUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICByZXR1cm4gdXNlU3RhYmxlQ2FsbGJhY2soZWxlbWVudCA9PiB7XG4gICAgY29uc3QgcmVnaXN0cmF0aW9uID0gcmVnaXN0cmF0aW9uUmVmLmN1cnJlbnQ7XG4gICAgaWYgKHJlZ2lzdHJhdGlvbiAhPT0gbnVsbCkge1xuICAgICAgaWYgKHJlZ2lzdHJhdGlvbi5lbGVtZW50ID09PSBlbGVtZW50ICYmIHJlZ2lzdHJhdGlvbi5zdG9yZSA9PT0gc3RvcmUgJiYgcmVnaXN0cmF0aW9uLmlkID09PSBpZCkge1xuICAgICAgICAvLyBBbHJlYWR5IHJlZ2lzdGVyZWQgd2hlcmUgaXQgYmVsb25ncywgc28gdGhlIGNhbGxlcidzIG1pZ3JhdGlvbiBlZmZlY3QgaXMgZnJlZSBvbiBtb3VudC5cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgcmVnaXN0cmF0aW9uUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgY29uc3QgcmVnaXN0ZXJlZFN0b3JlID0gcmVnaXN0cmF0aW9uLnN0b3JlO1xuICAgICAgaWYgKHJlZ2lzdGVyZWRTdG9yZS5jb250ZXh0LnRyaWdnZXJFbGVtZW50cy5nZXRCeUlkKHJlZ2lzdHJhdGlvbi5pZCkgPT09IHJlZ2lzdHJhdGlvbi5lbGVtZW50KSB7XG4gICAgICAgIHJlZ2lzdGVyZWRTdG9yZS5jb250ZXh0LnRyaWdnZXJFbGVtZW50cy5kZWxldGUocmVnaXN0cmF0aW9uLmlkKTtcbiAgICAgICAgc3luY1RyaWdnZXJDb3VudChyZWdpc3RlcmVkU3RvcmUpO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoZWxlbWVudCAhPT0gbnVsbCAmJiBpZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICByZWdpc3RyYXRpb25SZWYuY3VycmVudCA9IHtcbiAgICAgICAgc3RvcmUsXG4gICAgICAgIGlkLFxuICAgICAgICBlbGVtZW50XG4gICAgICB9O1xuICAgICAgc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuYWRkKGlkLCBlbGVtZW50KTtcbiAgICAgIHN5bmNUcmlnZ2VyQ291bnQoc3RvcmUpO1xuICAgIH1cbiAgfSk7XG59XG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlUG9wdXBPcGVuU3RhdGUoc3RhdGUsIG9wZW4sIHRyaWdnZXIsIHByZXZlbnRVbm1vdW50T25DbG9zZSA9IGZhbHNlKSB7XG4gIGxldCBwcmV2ZW50VW5tb3VudGluZ09uQ2xvc2UgPSBzdGF0ZS5wcmV2ZW50VW5tb3VudGluZ09uQ2xvc2U7XG4gIGlmIChvcGVuKSB7XG4gICAgLy8gT3BlbmluZyBzdGFydHMgYSBuZXcgY2xvc2UgY3ljbGUsIHNvIGNsZWFyIGFueSBwcmV2aW91cyByZXF1ZXN0IHRvIGtlZXAgdGhlIHBvcHVwIG1vdW50ZWQuXG4gICAgcHJldmVudFVubW91bnRpbmdPbkNsb3NlID0gZmFsc2U7XG4gIH0gZWxzZSBpZiAocHJldmVudFVubW91bnRPbkNsb3NlKSB7XG4gICAgcHJldmVudFVubW91bnRpbmdPbkNsb3NlID0gdHJ1ZTtcbiAgfVxuICBjb25zdCB0cmlnZ2VySWQgPSB0cmlnZ2VyPy5pZCA/PyBudWxsO1xuICBsZXQgYWN0aXZlVHJpZ2dlcklkID0gc3RhdGUuYWN0aXZlVHJpZ2dlcklkO1xuICBsZXQgYWN0aXZlVHJpZ2dlckVsZW1lbnQgPSBzdGF0ZS5hY3RpdmVUcmlnZ2VyRWxlbWVudDtcblxuICAvLyBJZiBhIHBvcHVwIGlzIGNsb3NpbmcsIHRoZSBgdHJpZ2dlcmAgbWF5IGJlIHVuZGVmaW5lZC5cbiAgLy8gV2Ugd2FudCB0byBrZWVwIHRoZSBwcmV2aW91cyB2YWx1ZSBzbyB0aGF0IGV4aXQgYW5pbWF0aW9ucyBhcmUgcGxheWVkIGFuZCBmb2N1cyBpcyByZXR1cm5lZCBjb3JyZWN0bHkuXG4gIGlmICh0cmlnZ2VySWQgfHwgb3Blbikge1xuICAgIGFjdGl2ZVRyaWdnZXJJZCA9IHRyaWdnZXJJZDtcbiAgICBhY3RpdmVUcmlnZ2VyRWxlbWVudCA9IHRyaWdnZXIgPz8gbnVsbDtcbiAgfVxuICByZXR1cm4ge1xuICAgIG9wZW4sXG4gICAgcHJldmVudFVubW91bnRpbmdPbkNsb3NlLFxuICAgIGFjdGl2ZVRyaWdnZXJJZCxcbiAgICBhY3RpdmVUcmlnZ2VyRWxlbWVudCxcbiAgICAvLyBBbiBvcGVuIHJlcXVlc3Qgd2l0aG91dCBhIHRyaWdnZXIgKGEgaGFuZGxlJ3MgYG9wZW4obnVsbClgIG9yIGBvcGVuV2l0aFBheWxvYWQoKWApIG11c3Qgbm90XG4gICAgLy8gYmUgcmVhc3NvY2lhdGVkIHdpdGggYSBsb25lIHJlZ2lzdGVyZWQgdHJpZ2dlciBsYXRlciBvbi4gQ29udHJvbGxlZCBhbmQgZGVmYXVsdCBvcGVucyBuZXZlclxuICAgIC8vIHBhc3MgdGhyb3VnaCBoZXJlLCBzbyB0aGV5IGtlZXAgY2xhaW1pbmcgYSBsb25lIHRyaWdnZXIuIEEgY2xvc2UgcmVxdWVzdCBrZWVwcyB0aGUgZmxhZzogYVxuICAgIC8vIGNvbnRyb2xsZWQgcm9vdCBtYXkgZGVjbGluZSBpdCBhbmQgc3RheSBvcGVuLCBzbyB0aGUgUm9vdCBjbGVhcnMgdGhlIGZsYWcgb25seSBvbmNlIHRoZVxuICAgIC8vIHBvcHVwIGlzIGVmZmVjdGl2ZWx5IGNsb3NlZC5cbiAgICBvcGVuZWRXaXRob3V0VHJpZ2dlcjogb3BlbiA/IHRyaWdnZXIgPT0gbnVsbCA6IHN0YXRlLm9wZW5lZFdpdGhvdXRUcmlnZ2VyXG4gIH07XG59XG5leHBvcnQgZnVuY3Rpb24gYXR0YWNoUHJldmVudFVubW91bnRPbkNsb3NlKGV2ZW50RGV0YWlscykge1xuICBsZXQgcHJldmVudFVubW91bnRPbkNsb3NlID0gZmFsc2U7XG4gIGV2ZW50RGV0YWlscy5wcmV2ZW50VW5tb3VudE9uQ2xvc2UgPSAoKSA9PiB7XG4gICAgcHJldmVudFVubW91bnRPbkNsb3NlID0gdHJ1ZTtcbiAgfTtcbiAgcmV0dXJuICgpID0+IHByZXZlbnRVbm1vdW50T25DbG9zZTtcbn1cblxuLyoqXG4gKiBSdW5zIHRoZSBzaGFyZWQgb3Blbi1jaGFuZ2Ugc2VxdWVuY2UgZm9yIGEgcG9wdXAgc3RvcmU6IG5vdGlmaWVzIGBvbk9wZW5DaGFuZ2VgLFxuICogaG9ub3JzIGNhbmNlbGxhdGlvbiwgZGlzcGF0Y2hlcyB0aGUgZmxvYXRpbmcgcm9vdCBjaGFuZ2UsIG1hcHMgdGhlIHJlYXNvbiB0byBhblxuICogYGluc3RhbnRUeXBlYCwgYW5kIGNvbW1pdHMgdGhlIHN0YXRlIHVwZGF0ZSAoc3luY2hyb25vdXNseSBmb3IgaG92ZXIgc29cbiAqIGBnZXRBbmltYXRpb25zKClgIG9ic2VydmVzIGl0KS4gU3RvcmVzIHN1cHBseSB0aGVpciBvd24gZGlmZmVyZW5jZXMgdmlhXG4gKiBgZXh0cmFTdGF0ZWAgKGUuZy4gdGhlIGxhc3QgY2hhbmdlIHJlYXNvbikgYW5kIGBvbkJlZm9yZURpc3BhdGNoYCAoZS5nLiB1cGRhdGluZ1xuICogaW5saW5lLXJlY3QgY29vcmRpbmF0ZXMpLlxuICovXG5leHBvcnQgZnVuY3Rpb24gYXBwbHlQb3B1cE9wZW5DaGFuZ2Uoc3RvcmUsIG5leHRPcGVuLCBldmVudERldGFpbHMsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCByZWFzb24gPSBldmVudERldGFpbHMucmVhc29uO1xuICBjb25zdCBpc0hvdmVyID0gcmVhc29uID09PSBSRUFTT05TLnRyaWdnZXJIb3ZlcjtcbiAgY29uc3QgaXNGb2N1c09wZW4gPSBuZXh0T3BlbiAmJiByZWFzb24gPT09IFJFQVNPTlMudHJpZ2dlckZvY3VzO1xuICBjb25zdCBpc0Rpc21pc3NDbG9zZSA9ICFuZXh0T3BlbiAmJiAocmVhc29uID09PSBSRUFTT05TLnRyaWdnZXJQcmVzcyB8fCByZWFzb24gPT09IFJFQVNPTlMuZXNjYXBlS2V5KTtcbiAgY29uc3Qgc2hvdWxkUHJldmVudFVubW91bnRPbkNsb3NlID0gYXR0YWNoUHJldmVudFVubW91bnRPbkNsb3NlKGV2ZW50RGV0YWlscyk7XG4gIHN0b3JlLmNvbnRleHQub25PcGVuQ2hhbmdlPy4obmV4dE9wZW4sIGV2ZW50RGV0YWlscyk7XG4gIGlmIChldmVudERldGFpbHMuaXNDYW5jZWxlZCkge1xuICAgIHJldHVybjtcbiAgfVxuICBvcHRpb25zLm9uQmVmb3JlRGlzcGF0Y2g/LigpO1xuICBzdG9yZS5zdGF0ZS5mbG9hdGluZ1Jvb3RDb250ZXh0LmRpc3BhdGNoT3BlbkNoYW5nZShuZXh0T3BlbiwgZXZlbnREZXRhaWxzKTtcbiAgY29uc3QgY2hhbmdlU3RhdGUgPSAoKSA9PiB7XG4gICAgY29uc3QgcG9wdXBPcGVuU3RhdGUgPSBjcmVhdGVQb3B1cE9wZW5TdGF0ZShzdG9yZS5zdGF0ZSwgbmV4dE9wZW4sIGV2ZW50RGV0YWlscy50cmlnZ2VyLCBzaG91bGRQcmV2ZW50VW5tb3VudE9uQ2xvc2UoKSk7XG4gICAgY29uc3QgdXBkYXRlZFN0YXRlID0ge1xuICAgICAgLi4ub3B0aW9ucy5leHRyYVN0YXRlLFxuICAgICAgLi4ucG9wdXBPcGVuU3RhdGVcbiAgICB9O1xuICAgIGlmIChpc0ZvY3VzT3Blbikge1xuICAgICAgdXBkYXRlZFN0YXRlLmluc3RhbnRUeXBlID0gJ2ZvY3VzJztcbiAgICB9IGVsc2UgaWYgKGlzRGlzbWlzc0Nsb3NlKSB7XG4gICAgICB1cGRhdGVkU3RhdGUuaW5zdGFudFR5cGUgPSAnZGlzbWlzcyc7XG4gICAgfSBlbHNlIGlmIChpc0hvdmVyKSB7XG4gICAgICB1cGRhdGVkU3RhdGUuaW5zdGFudFR5cGUgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHN0b3JlLnVwZGF0ZSh1cGRhdGVkU3RhdGUpO1xuICB9O1xuICBpZiAoaXNIb3Zlcikge1xuICAgIC8vIEZsdXNoIHN5bmNocm9ub3VzbHkgZm9yIGhvdmVyIHNvIGBub2RlLmdldEFuaW1hdGlvbnMoKWAgc2VlcyB0aGUgbmV3IHN0YXRlLlxuICAgIFJlYWN0RE9NLmZsdXNoU3luYyhjaGFuZ2VTdGF0ZSk7XG4gIH0gZWxzZSB7XG4gICAgY2hhbmdlU3RhdGUoKTtcbiAgfVxufVxuXG4vKipcbiAqIFNldHMgdXAgdHJpZ2dlciBkYXRhIGZvcndhcmRpbmcgdG8gdGhlIHN0b3JlLlxuICpcbiAqIEBwYXJhbSB0cmlnZ2VySWQgSWQgb2YgdGhlIHRyaWdnZXIuXG4gKiBAcGFyYW0gdHJpZ2dlckVsZW1lbnRSZWYgUmVmIGZvciB0aGUgdHJpZ2dlciBET00gZWxlbWVudC5cbiAqIEBwYXJhbSBzdG9yZSBUaGUgU3RvcmUgaW5zdGFuY2UgbWFuYWdpbmcgdGhlIHBvcHVwIHN0YXRlLlxuICogQHBhcmFtIHN0YXRlVXBkYXRlcyBBbiBvYmplY3Qgd2l0aCBzdGF0ZSB1cGRhdGVzIHRvIGFwcGx5IHdoZW4gdGhlIHRyaWdnZXIgaXMgYWN0aXZlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlVHJpZ2dlckRhdGFGb3J3YXJkaW5nKHRyaWdnZXJJZCwgdHJpZ2dlckVsZW1lbnRSZWYsIHN0b3JlLCBzdGF0ZVVwZGF0ZXMpIHtcbiAgY29uc3QgaXNNb3VudGVkQnlUaGlzVHJpZ2dlciA9IHN0b3JlLnVzZVN0YXRlKCdpc01vdW50ZWRCeVRyaWdnZXInLCB0cmlnZ2VySWQpO1xuICBjb25zdCBiYXNlUmVnaXN0ZXJUcmlnZ2VyID0gdXNlVHJpZ2dlclJlZ2lzdHJhdGlvbih0cmlnZ2VySWQsIHN0b3JlKTtcblxuICAvLyBBcHBsaWVzIHRyaWdnZXItb3duZWQgc3RhdGUgKGFjdGl2ZS10cmlnZ2VyIG93bmVyc2hpcCBhbmQgcGF5bG9hZCkgd2hlbiB0aGUgdHJpZ2dlciByZWdpc3RlcnMuXG4gIC8vIFN0YWJsZSBzbyBwYXlsb2FkL2BzdGF0ZVVwZGF0ZXNgIGNoYW5nZXMgZG8gbm90IGNoYW5nZSB0aGUgcmVmIGlkZW50aXR5ICh3aGljaCB3b3VsZCBuZWVkbGVzc2x5XG4gIC8vIGNodXJuIHJlZ2lzdHJhdGlvbik7IGl0IHJlYWRzIHRoZSBsYXRlc3QgY2xvc3VyZSB2YWx1ZXMgd2hlbiBpbnZva2VkLlxuICBjb25zdCBhcHBseVRyaWdnZXJEYXRhID0gdXNlU3RhYmxlQ2FsbGJhY2soZWxlbWVudCA9PiB7XG4gICAgY29uc3Qgb3BlbiA9IHN0b3JlLnNlbGVjdCgnb3BlbicpO1xuICAgIGNvbnN0IGFjdGl2ZVRyaWdnZXJJZCA9IHN0b3JlLnNlbGVjdCgnYWN0aXZlVHJpZ2dlcklkJyk7XG4gICAgaWYgKGFjdGl2ZVRyaWdnZXJJZCA9PT0gdHJpZ2dlcklkKSB7XG4gICAgICBjb25zdCBjaGFuZ2VzID0ge1xuICAgICAgICBhY3RpdmVUcmlnZ2VyRWxlbWVudDogZWxlbWVudCxcbiAgICAgICAgLi4uKG9wZW4gPyBzdGF0ZVVwZGF0ZXMgOiBudWxsKVxuICAgICAgfTtcbiAgICAgIHN0b3JlLnVwZGF0ZShjaGFuZ2VzKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGFjdGl2ZVRyaWdnZXJJZCA9PSBudWxsICYmIG9wZW4gJiYgIXN0b3JlLnN0YXRlLm9wZW5lZFdpdGhvdXRUcmlnZ2VyKSB7XG4gICAgICAvLyBJZiBhIHBvcHVwIGlzIGFscmVhZHkgb3BlbiwgYSBkZXRhY2hlZCB0cmlnZ2VyIGNhbiBtb3VudCBiZWZvcmUgYW55IGFjdGl2ZSB0cmlnZ2VyXG4gICAgICAvLyBoYXMgYmVlbiBlc3RhYmxpc2hlZC4gQ2xhaW0gdGhlIGZpcnN0IHJlZ2lzdGVyZWQgdHJpZ2dlciBzbyB0cmlnZ2VyLW93bmVkIGZvY3VzXG4gICAgICAvLyBtYW5hZ2VtZW50IGFuZCBBUklBIHJlbGF0aW9uc2hpcHMgd29yay4gQSBwb3B1cCBvcGVuZWQgZGVsaWJlcmF0ZWx5IHdpdGhvdXQgYSB0cmlnZ2VyXG4gICAgICAvLyBzdGF5cyB1bmFzc29jaWF0ZWQgc28gdGhlIHRyaWdnZXIncyBgcGF5bG9hZGAgZG9lcyBub3QgcmVwbGFjZSB0aGUgcHJvZ3JhbW1hdGljIG9uZS5cbiAgICAgIGNvbnN0IGNoYW5nZXMgPSB7XG4gICAgICAgIGFjdGl2ZVRyaWdnZXJJZDogdHJpZ2dlcklkID8/IG51bGwsXG4gICAgICAgIGFjdGl2ZVRyaWdnZXJFbGVtZW50OiBlbGVtZW50LFxuICAgICAgICAuLi5zdGF0ZVVwZGF0ZXNcbiAgICAgIH07XG4gICAgICBzdG9yZS51cGRhdGUoY2hhbmdlcyk7XG4gICAgfVxuICB9KTtcblxuICAvLyBTdGFibGUsIHNvIHRoZSBtZXJnZWQgcmVmIG9uIHRoZSByZW5kZXJlZCBlbGVtZW50IGtlZXBzIGl0cyBpZGVudGl0eSBmb3IgdGhlIHRyaWdnZXIncyB3aG9sZVxuICAvLyBsaWZldGltZS5cbiAgY29uc3QgcmVnaXN0ZXJUcmlnZ2VyID0gdXNlU3RhYmxlQ2FsbGJhY2soZWxlbWVudCA9PiB7XG4gICAgYmFzZVJlZ2lzdGVyVHJpZ2dlcihlbGVtZW50KTtcbiAgICBpZiAoZWxlbWVudCkge1xuICAgICAgYXBwbHlUcmlnZ2VyRGF0YShlbGVtZW50KTtcbiAgICB9XG4gIH0pO1xuXG4gIC8vIEEgc3RhYmxlIHJlZiBkb2VzIG5vdCByZS1maXJlIG9uIGEgc3RvcmUgb3IgaWQgY2hhbmdlLCBzbyBtaWdyYXRlIGhlcmUgaW5zdGVhZDogdW5yZWdpc3RlciBmcm9tXG4gIC8vIHRoZSBwcmV2aW91cyBzdG9yZSwgdGhlbiByZWdpc3RlciB0aGUgZWxlbWVudCB0aGUgdHJpZ2dlciBzdGlsbCByZW5kZXJzIGludG8gdGhlIGN1cnJlbnQgb25lLlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIHJlZ2lzdGVyVHJpZ2dlcih0cmlnZ2VyRWxlbWVudFJlZi5jdXJyZW50KTtcbiAgICByZXR1cm4gKCkgPT4gcmVnaXN0ZXJUcmlnZ2VyKG51bGwpO1xuICB9LCBbcmVnaXN0ZXJUcmlnZ2VyLCB0cmlnZ2VyRWxlbWVudFJlZiwgc3RvcmUsIHRyaWdnZXJJZF0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc01vdW50ZWRCeVRoaXNUcmlnZ2VyKSB7XG4gICAgICBjb25zdCBjaGFuZ2VzID0ge1xuICAgICAgICBhY3RpdmVUcmlnZ2VyRWxlbWVudDogdHJpZ2dlckVsZW1lbnRSZWYuY3VycmVudCxcbiAgICAgICAgLi4uc3RhdGVVcGRhdGVzXG4gICAgICB9O1xuICAgICAgc3RvcmUudXBkYXRlKGNoYW5nZXMpO1xuICAgIH1cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gIH0sIFtpc01vdW50ZWRCeVRoaXNUcmlnZ2VyLCBzdG9yZSwgdHJpZ2dlckVsZW1lbnRSZWYsIC4uLk9iamVjdC52YWx1ZXMoc3RhdGVVcGRhdGVzKV0pO1xuICByZXR1cm4ge1xuICAgIHJlZ2lzdGVyVHJpZ2dlcixcbiAgICBpc01vdW50ZWRCeVRoaXNUcmlnZ2VyXG4gIH07XG59XG4vKipcbiAqIEtlZXBzIHRyaWdnZXIgcmVnaXN0cmF0aW9uIHN0YXRlIHN5bmNocm9uaXplZCB3aGlsZSB0aGUgcG9wdXAgaXMgb3Blbi5cbiAqXG4gKiBXaGVuIGEgcG9wdXAgb3BlbnMgd2l0aG91dCBhbiBleHBsaWNpdCB0cmlnZ2VyIGlkIGFuZCBleGFjdGx5IG9uZSB0cmlnZ2VyIGlzIHJlZ2lzdGVyZWQsIHRoYXRcbiAqIHRyaWdnZXIgaXMgY2xhaW1lZCBhcyB0aGUgYWN0aXZlIHRyaWdnZXIsIHVubGVzcyB0aGUgb3BlbiByZXF1ZXN0IGRlbGliZXJhdGVseSBjYXJyaWVkIG5vIHRyaWdnZXJcbiAqIChgb3BlbmVkV2l0aG91dFRyaWdnZXJgKS4gV2hlbiB0aGUgYWN0aXZlIHRyaWdnZXIgaWQgaXMgc3RpbGwgcmVnaXN0ZXJlZCBidXQgaXRzXG4gKiBlbGVtZW50IGNoYW5nZWQsIHRoZSBhY3RpdmUgZWxlbWVudCBpcyByZWZyZXNoZWQuIFdoZW4gdGhlIGFjdGl2ZSB0cmlnZ2VyIGlkIGlzIG1pc3NpbmcgZnJvbSB0aGVcbiAqIHJlZ2lzdHJ5IGJ1dCB0aGUgc2FtZSBlbGVtZW50IGlzIHN0aWxsIHJlZ2lzdGVyZWQgdW5kZXIgYSBkaWZmZXJlbnQgaWQgKGUuZy4gdGhlIHJlbmRlcmVkIHRyaWdnZXJcbiAqIGNhcnJpZXMgaXRzIG93biBET00gYGlkYCB0aGF0IGRpZmZlcnMgZnJvbSBCYXNlIFVJJ3MgaW50ZXJuYWwgdHJpZ2dlciBpZCksIHRoZSBhY3RpdmUgaWQgaXNcbiAqIHJlYXNzb2NpYXRlZCB0byB0aGUgcmVnaXN0ZXJlZCBpZCBpbnN0ZWFkIG9mIGJlaW5nIHRyZWF0ZWQgYXMgbG9zdC4gV2hlbiB0aGUgYWN0aXZlIHRyaWdnZXJcbiAqIHVucmVnaXN0ZXJzLCB0aGUgZGVmYXVsdCBwYXRoIHByZXNlcnZlcyBleGlzdGluZyBvd25lcnNoaXAgc28gbm9uLWNsb3NpbmcgcG9wdXAgZmFtaWxpZXMgZG8gbm90XG4gKiBzaWxlbnRseSBjbGFpbSBhIGRpZmZlcmVudCB0cmlnZ2VyIHdoaWxlIHN0YXlpbmcgb3Blbi5cbiAqXG4gKiBJZiBgY2xvc2VPbkFjdGl2ZVRyaWdnZXJVbm1vdW50YCBpcyBlbmFibGVkLCB1bnJlZ2lzdGVyaW5nIGEgcHJldmlvdXNseSByZXNvbHZlZCBhY3RpdmUgdHJpZ2dlclxuICogcmVxdWVzdHMgYSBjbG9zZSBhZnRlciBhIG1pY3JvdGFzayBzbyBhIHNhbWUtdGljayByZXBsYWNlbWVudCB0cmlnZ2VyIHdpdGggdGhlIHNhbWUgaWQgY2FuXG4gKiByZWdpc3RlciBmaXJzdC4gQW4gYWN0aXZlIHRyaWdnZXIgaWQgdGhhdCBoYXMgbm90IG1hdGNoZWQgYSByZWdpc3RlcmVkIHRyaWdnZXIgeWV0IGlzIHRyZWF0ZWQgYXNcbiAqIHBlbmRpbmcgYW5kIGRvZXMgbm90IHJlcXVlc3QgYSBjbG9zZS5cbiAqXG4gKiBUaGlzIHNob3VsZCBiZSBjYWxsZWQgb24gdGhlIFJvb3QgcGFydC5cbiAqXG4gKiBAcGFyYW0gc3RvcmUgVGhlIFN0b3JlIGluc3RhbmNlIG1hbmFnaW5nIHRoZSBwb3B1cCBzdGF0ZS5cbiAqIEBwYXJhbSBvcHRpb25zIE9wdGlvbnMgZm9yIGFjdGl2ZSB0cmlnZ2VyIHVubW91bnQgYmVoYXZpb3IuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VJbXBsaWNpdEFjdGl2ZVRyaWdnZXIoc3RvcmUsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7XG4gICAgY2xvc2VPbkFjdGl2ZVRyaWdnZXJVbm1vdW50ID0gZmFsc2VcbiAgfSA9IG9wdGlvbnM7XG4gIC8vIERpc3Rpbmd1aXNoZXMgYSB0cmlnZ2VyIHRoYXQgdW5tb3VudGVkIGZyb20gYSBuZXcgYWN0aXZlIHRyaWdnZXIgdGhhdCBoYXMgbm90IGh5ZHJhdGVkIHlldC5cbiAgY29uc3QgcmVzb2x2ZWRBY3RpdmVUcmlnZ2VySWRSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCByZWFjdGl2ZVRyaWdnZXJDb3VudCA9IHN0b3JlLnVzZVN0YXRlKCd0cmlnZ2VyQ291bnQnKTtcbiAgLy8gU3Vic2NyaWJlIHRvIHRoZSBhY3RpdmUgdHJpZ2dlciBpZCBzbyB0aGUgcmVjb25jaWxpYXRpb24gYmVsb3cgcmVydW5zIHdoZW4gb3duZXJzaGlwIG1vdmVzIHRvXG4gIC8vIGFub3RoZXIgdHJpZ2dlciB3aGlsZSB0aGUgcG9wdXAgc3RheXMgb3BlbiAoZS5nLiBhIGZvY3VzL2hvdmVyIGhhbmRvZmYgYmV0d2VlbiB0cmlnZ2VycykuXG4gIGNvbnN0IGFjdGl2ZVRyaWdnZXJJZCA9IHN0b3JlLnVzZVN0YXRlKCdhY3RpdmVUcmlnZ2VySWQnKTtcbiAgLy8gU3Vic2NyaWJlIHRvIHRoZSBhY3RpdmUgdHJpZ2dlciBlbGVtZW50IHNvIHRoZSByZWNvbmNpbGlhdGlvbiByZXJ1bnMgd2hlbiBhIHBlbmRpbmcgYWN0aXZlXG4gIC8vIHRyaWdnZXIgcmVnaXN0ZXJzIGluIGEgY29tbWl0IHdoZXJlIHRoZSB0cmlnZ2VyIGNvdW50IG5ldHMgb3V0IHVuY2hhbmdlZCAocmVnaXN0cmF0aW9uXG4gIC8vIGZvcndhcmRzIHRoZSBlbGVtZW50IHRvIHRoZSBzdG9yZSB3aGVuIHRoZSByZWdpc3RlcmluZyB0cmlnZ2VyIG1hdGNoZXMgdGhlIGFjdGl2ZSBpZCkuXG4gIC8vIFdpdGhvdXQgdGhpcywgdGhlIGlkIHdvdWxkIG5ldmVyIGJlIG1hcmtlZCByZXNvbHZlZCBhbmQgYSBsYXRlciBnZW51aW5lIHVubW91bnQgd291bGQgYmVcbiAgLy8gbWlzY2xhc3NpZmllZCBhcyBwZW5kaW5nLCBkaXNhYmxpbmcgYGNsb3NlT25BY3RpdmVUcmlnZ2VyVW5tb3VudGAuXG4gIGNvbnN0IHJlYWN0aXZlQWN0aXZlVHJpZ2dlckVsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZSgnYWN0aXZlVHJpZ2dlckVsZW1lbnQnKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW9wZW4pIHtcbiAgICAgIHJlc29sdmVkQWN0aXZlVHJpZ2dlcklkUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgICAgaWYgKHN0b3JlLnN0YXRlLnRyaWdnZXJDb3VudCAhPT0gMCkge1xuICAgICAgICBzdG9yZS5zZXQoJ3RyaWdnZXJDb3VudCcsIDApO1xuICAgICAgfVxuICAgICAgLy8gVGhlIGZsYWcgaXMgY2xlYXJlZCBvbmx5IGhlcmUsIG9uY2UgdGhlIHBvcHVwIGlzIGVmZmVjdGl2ZWx5IGNsb3NlZDogYSBjb250cm9sbGVkIHJvb3QgbWF5XG4gICAgICAvLyBkZWNsaW5lIGEgY2xvc2UgcmVxdWVzdCBhbmQgc3RheSBvcGVuLCBhbmQgYSBjb250cm9sbGVkIGNsb3NlIG5ldmVyIHJlYWNoZXNcbiAgICAgIC8vIGBjcmVhdGVQb3B1cE9wZW5TdGF0ZWAgYXQgYWxsLlxuICAgICAgaWYgKHN0b3JlLnN0YXRlLm9wZW5lZFdpdGhvdXRUcmlnZ2VyKSB7XG4gICAgICAgIHN0b3JlLnNldCgnb3BlbmVkV2l0aG91dFRyaWdnZXInLCBmYWxzZSk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHRyaWdnZXJDb3VudCA9IHN0b3JlLmNvbnRleHQudHJpZ2dlckVsZW1lbnRzLnNpemU7XG4gICAgY29uc3Qgc3RhdGVVcGRhdGVzID0ge307XG4gICAgaWYgKHN0b3JlLnN0YXRlLnRyaWdnZXJDb3VudCAhPT0gdHJpZ2dlckNvdW50KSB7XG4gICAgICBzdGF0ZVVwZGF0ZXMudHJpZ2dlckNvdW50ID0gdHJpZ2dlckNvdW50O1xuICAgIH1cbiAgICBjb25zdCBjdXJyZW50QWN0aXZlVHJpZ2dlcklkID0gc3RvcmUuc2VsZWN0KCdhY3RpdmVUcmlnZ2VySWQnKTtcbiAgICBsZXQgbG9zdEFjdGl2ZVRyaWdnZXJJZCA9IG51bGw7XG4gICAgaWYgKGN1cnJlbnRBY3RpdmVUcmlnZ2VySWQpIHtcbiAgICAgIGNvbnN0IGFjdGl2ZVRyaWdnZXJFbGVtZW50ID0gc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuZ2V0QnlJZChjdXJyZW50QWN0aXZlVHJpZ2dlcklkKTtcbiAgICAgIGlmICghYWN0aXZlVHJpZ2dlckVsZW1lbnQpIHtcbiAgICAgICAgZm9yIChjb25zdCBbdHJpZ2dlcklkLCB0cmlnZ2VyRWxlbWVudF0gb2Ygc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuZW50cmllcygpKSB7XG4gICAgICAgICAgaWYgKHRyaWdnZXJFbGVtZW50ID09PSBzdG9yZS5zdGF0ZS5hY3RpdmVUcmlnZ2VyRWxlbWVudCkge1xuICAgICAgICAgICAgc3RhdGVVcGRhdGVzLmFjdGl2ZVRyaWdnZXJJZCA9IHRyaWdnZXJJZDtcbiAgICAgICAgICAgIHN0YXRlVXBkYXRlcy5hY3RpdmVUcmlnZ2VyRWxlbWVudCA9IHRyaWdnZXJFbGVtZW50O1xuICAgICAgICAgICAgcmVzb2x2ZWRBY3RpdmVUcmlnZ2VySWRSZWYuY3VycmVudCA9IHRyaWdnZXJJZDtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoc3RhdGVVcGRhdGVzLmFjdGl2ZVRyaWdnZXJJZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgaWYgKHJlc29sdmVkQWN0aXZlVHJpZ2dlcklkUmVmLmN1cnJlbnQgPT09IGN1cnJlbnRBY3RpdmVUcmlnZ2VySWQpIHtcbiAgICAgICAgICAgIGxvc3RBY3RpdmVUcmlnZ2VySWQgPSBjdXJyZW50QWN0aXZlVHJpZ2dlcklkO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXNvbHZlZEFjdGl2ZVRyaWdnZXJJZFJlZi5jdXJyZW50ID0gbnVsbDtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJlc29sdmVkQWN0aXZlVHJpZ2dlcklkUmVmLmN1cnJlbnQgPSBjdXJyZW50QWN0aXZlVHJpZ2dlcklkO1xuICAgICAgICBpZiAoYWN0aXZlVHJpZ2dlckVsZW1lbnQgIT09IHN0b3JlLnN0YXRlLmFjdGl2ZVRyaWdnZXJFbGVtZW50KSB7XG4gICAgICAgICAgc3RhdGVVcGRhdGVzLmFjdGl2ZVRyaWdnZXJFbGVtZW50ID0gYWN0aXZlVHJpZ2dlckVsZW1lbnQ7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgcmVzb2x2ZWRBY3RpdmVUcmlnZ2VySWRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgfVxuICAgIGlmICghbG9zdEFjdGl2ZVRyaWdnZXJJZCAmJiAhY3VycmVudEFjdGl2ZVRyaWdnZXJJZCAmJiAhc3RvcmUuc3RhdGUub3BlbmVkV2l0aG91dFRyaWdnZXIgJiYgdHJpZ2dlckNvdW50ID09PSAxKSB7XG4gICAgICBjb25zdCBpdGVyYXRvclJlc3VsdCA9IHN0b3JlLmNvbnRleHQudHJpZ2dlckVsZW1lbnRzLmVudHJpZXMoKS5uZXh0KCk7XG4gICAgICBpZiAoIWl0ZXJhdG9yUmVzdWx0LmRvbmUpIHtcbiAgICAgICAgY29uc3QgW2ltcGxpY2l0VHJpZ2dlcklkLCBpbXBsaWNpdFRyaWdnZXJFbGVtZW50XSA9IGl0ZXJhdG9yUmVzdWx0LnZhbHVlO1xuICAgICAgICBzdGF0ZVVwZGF0ZXMuYWN0aXZlVHJpZ2dlcklkID0gaW1wbGljaXRUcmlnZ2VySWQ7XG4gICAgICAgIHN0YXRlVXBkYXRlcy5hY3RpdmVUcmlnZ2VyRWxlbWVudCA9IGltcGxpY2l0VHJpZ2dlckVsZW1lbnQ7XG4gICAgICAgIHJlc29sdmVkQWN0aXZlVHJpZ2dlcklkUmVmLmN1cnJlbnQgPSBpbXBsaWNpdFRyaWdnZXJJZDtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHN0YXRlVXBkYXRlcy50cmlnZ2VyQ291bnQgIT09IHVuZGVmaW5lZCB8fCBzdGF0ZVVwZGF0ZXMuYWN0aXZlVHJpZ2dlcklkICE9PSB1bmRlZmluZWQgfHwgc3RhdGVVcGRhdGVzLmFjdGl2ZVRyaWdnZXJFbGVtZW50ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHN0b3JlLnVwZGF0ZShzdGF0ZVVwZGF0ZXMpO1xuICAgIH1cbiAgICBpZiAobG9zdEFjdGl2ZVRyaWdnZXJJZCkge1xuICAgICAgaWYgKGNsb3NlT25BY3RpdmVUcmlnZ2VyVW5tb3VudCkge1xuICAgICAgICAvLyBEZWZlciBzbyBhIHNhbWUtdGljayByZXBsYWNlbWVudCB0cmlnZ2VyIHdpdGggdGhlIHNhbWUgaWQgY2FuIHJlZ2lzdGVyIGZpcnN0LlxuICAgICAgICBxdWV1ZU1pY3JvdGFzaygoKSA9PiB7XG4gICAgICAgICAgaWYgKHN0b3JlLnNlbGVjdCgnb3BlbicpICYmIHN0b3JlLnNlbGVjdCgnYWN0aXZlVHJpZ2dlcklkJykgPT09IGxvc3RBY3RpdmVUcmlnZ2VySWQgJiYgIXN0b3JlLmNvbnRleHQudHJpZ2dlckVsZW1lbnRzLmdldEJ5SWQobG9zdEFjdGl2ZVRyaWdnZXJJZCkpIHtcbiAgICAgICAgICAgIGNvbnN0IGV2ZW50RGV0YWlscyA9IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLm5vbmUpO1xuICAgICAgICAgICAgc3RvcmUuc2V0T3BlbihmYWxzZSwgZXZlbnREZXRhaWxzKTtcbiAgICAgICAgICAgIC8vIElmIGNsb3NpbmcgaXMgY2FuY2VsZWQsIGtlZXAgdGhlIHByZXZpb3VzIGFjdGl2ZSB0cmlnZ2VyIG93bmVyc2hpcCBmb3IgdGhlXG4gICAgICAgICAgICAvLyBzdGlsbC1vcGVuIHBvcHVwIGluc3RlYWQgb2YgY2xhaW1pbmcgYW5vdGhlciB0cmlnZ2VyIGltcGxpY2l0bHkuXG4gICAgICAgICAgICBpZiAoIWV2ZW50RGV0YWlscy5pc0NhbmNlbGVkKSB7XG4gICAgICAgICAgICAgIHN0b3JlLnVwZGF0ZSh7XG4gICAgICAgICAgICAgICAgYWN0aXZlVHJpZ2dlcklkOiBudWxsLFxuICAgICAgICAgICAgICAgIGFjdGl2ZVRyaWdnZXJFbGVtZW50OiBudWxsXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9LCBbb3Blbiwgc3RvcmUsIHJlYWN0aXZlVHJpZ2dlckNvdW50LCBhY3RpdmVUcmlnZ2VySWQsIHJlYWN0aXZlQWN0aXZlVHJpZ2dlckVsZW1lbnQsIGNsb3NlT25BY3RpdmVUcmlnZ2VyVW5tb3VudF0pO1xufVxuXG4vKipcbiAqIE1hbmFnZXMgdGhlIG1vdW50ZWQgc3RhdGUgb2YgdGhlIHBvcHVwLlxuICogU2V0cyB1cCB0aGUgdHJhbnNpdGlvbiBzdGF0dXMgbGlzdGVuZXJzIGFuZCBoYW5kbGVzIHVubW91bnRpbmcgd2hlbiBuZWVkZWQuXG4gKiBVcGRhdGVzIHRoZSBgbW91bnRlZGAsIGB0cmFuc2l0aW9uU3RhdHVzYCwgYW5kIGBwcmV2ZW50VW5tb3VudGluZ09uQ2xvc2VgIHN0YXRlcyBpbiB0aGUgc3RvcmUuXG4gKlxuICogQHBhcmFtIG9wZW4gV2hldGhlciB0aGUgcG9wdXAgaXMgb3Blbi5cbiAqIEBwYXJhbSBzdG9yZSBUaGUgU3RvcmUgaW5zdGFuY2UgbWFuYWdpbmcgdGhlIHBvcHVwIHN0YXRlLlxuICogQHBhcmFtIG9uVW5tb3VudCBPcHRpb25hbCBjYWxsYmFjayB0byBiZSBjYWxsZWQgd2hlbiB0aGUgcG9wdXAgaXMgdW5tb3VudGVkLlxuICogQHBhcmFtIGFuaW1hdGVJbml0aWFsT3BlbiBXaGV0aGVyIGEgcG9wdXAgdGhhdCBtb3VudHMgYWxyZWFkeSBvcGVuIHNob3VsZCBzdGlsbCBwbGF5IGl0cyBlbnRlclxuICogICB0cmFuc2l0aW9uLiBEZWZhdWx0cyB0byBgZmFsc2VgLCBzbyBjb250ZW50IHRoYXQgd2FzIG9wZW4gb24gdGhlIGZpcnN0IHJlbmRlciAoYSBgZGVmYXVsdE9wZW5gXG4gKiAgIHBvcHVwIG9uIHBhZ2UgbG9hZCwgU1NSJ2QgbWFya3VwKSBhcHBlYXJzIHdpdGhvdXQgYW5pbWF0aW5nLiBPcHQgaW4gZm9yIHBvcHVwcyB3aG9zZSBzdWJ0cmVlXG4gKiAgIG9ubHkgbW91bnRzIGluIHJlc3BvbnNlIHRvIHNvbWV0aGluZyB0aGUgdXNlciBkaWQsIHN1Y2ggYXMgYSBzdWJtZW51IGluc2lkZSBhIG1lbnUgcG9wdXAuXG4gKlxuICogQHJldHVybnMgQSBmdW5jdGlvbiB0byBmb3JjaWJseSB1bm1vdW50IHRoZSBwb3B1cC4gSXQgaXMgYSBuby1vcCBvbmNlIHRoZSBwb3B1cCBpcyBhbHJlYWR5XG4gKiAgIHVubW91bnRlZCwgc28gY2FsbGluZyBpdCBhZnRlciB0aGUgYXV0b21hdGljIHVubW91bnQgZG9lc24ndCByZXBlYXQgdGhlIGNvbXBsZXRpb24gY2FsbGJhY2suXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VPcGVuU3RhdGVUcmFuc2l0aW9ucyhvcGVuLCBzdG9yZSwgb25Vbm1vdW50LCBhbmltYXRlSW5pdGlhbE9wZW4pIHtcbiAgY29uc3Qge1xuICAgIG1vdW50ZWQsXG4gICAgdHJhbnNpdGlvblN0YXR1cyxcbiAgICBmb3JjZVVubW91bnRcbiAgfSA9IHVzZVVubW91bnRBZnRlckNsb3NlKHtcbiAgICBvcGVuLFxuICAgIHJlZjogc3RvcmUuY29udGV4dC5wb3B1cFJlZixcbiAgICBwcmV2ZW50VW5tb3VudE9uQ2xvc2U6IHN0b3JlLnVzZVN0YXRlKCdwcmV2ZW50VW5tb3VudGluZ09uQ2xvc2UnKSxcbiAgICBzZXRQcmV2ZW50VW5tb3VudE9uQ2xvc2U6IHByZXZlbnRVbm1vdW50T25DbG9zZSA9PiBzdG9yZS5zZXQoJ3ByZXZlbnRVbm1vdW50aW5nT25DbG9zZScsIHByZXZlbnRVbm1vdW50T25DbG9zZSksXG4gICAgYW5pbWF0ZUluaXRpYWxPcGVuLFxuICAgIG9uVW5tb3VudCgpIHtcbiAgICAgIHN0b3JlLnVwZGF0ZSh7XG4gICAgICAgIGFjdGl2ZVRyaWdnZXJJZDogbnVsbCxcbiAgICAgICAgYWN0aXZlVHJpZ2dlckVsZW1lbnQ6IG51bGwsXG4gICAgICAgIG1vdW50ZWQ6IGZhbHNlLFxuICAgICAgICBwcmV2ZW50VW5tb3VudGluZ09uQ2xvc2U6IGZhbHNlXG4gICAgICB9KTtcbiAgICAgIG9uVW5tb3VudD8uKCk7XG4gICAgICBzdG9yZS5jb250ZXh0Lm9uT3BlbkNoYW5nZUNvbXBsZXRlPy4oZmFsc2UpO1xuICAgIH1cbiAgfSk7XG5cbiAgLy8gU2VlZCB0aGUgUm9vdC1vd25lZCBzdG9yZSBiZWZvcmUgcGFydHMgc3Vic2NyaWJlLCBtYXRjaGluZyB0aGUgaG9vaydzIGluaXRpYWwgbW91bnRlZCBzdGF0ZS5cbiAgLy8gT3RoZXJ3aXNlLCBhbiBpbml0aWFsbHkgb3BlbiBSb290IGxvb2tzIGxpa2UgYSByZW9wZW4gdW50aWwgdGhlIGxheW91dCBlZmZlY3Qgc3luY3MgdGhlIHN0b3JlLlxuICB1c2VSZWZXaXRoSW5pdCgoKSA9PiB7XG4gICAgc3RvcmUuc2V0KCdtb3VudGVkJywgbW91bnRlZCk7XG4gICAgcmV0dXJuIG51bGw7XG4gIH0pO1xuICBzdG9yZS51c2VTeW5jZWRWYWx1ZXMoe1xuICAgIG1vdW50ZWQsXG4gICAgdHJhbnNpdGlvblN0YXR1c1xuICB9KTtcbiAgcmV0dXJuIHtcbiAgICBmb3JjZVVubW91bnQsXG4gICAgdHJhbnNpdGlvblN0YXR1c1xuICB9O1xufVxuZXhwb3J0IGZ1bmN0aW9uIHVzZVBvcHVwSW50ZXJhY3Rpb25Qcm9wcyhzdG9yZSwgc3RhdGVQYXJ0KSB7XG4gIHN0b3JlLnVzZVN5bmNlZFZhbHVlcyhzdGF0ZVBhcnQpO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4gKCkgPT4ge1xuICAgIHN0b3JlLnVwZGF0ZSh7XG4gICAgICBhY3RpdmVUcmlnZ2VyUHJvcHM6IEVNUFRZX09CSkVDVCxcbiAgICAgIGluYWN0aXZlVHJpZ2dlclByb3BzOiBFTVBUWV9PQkpFQ1QsXG4gICAgICBwb3B1cFByb3BzOiBFTVBUWV9PQkpFQ1RcbiAgICB9KTtcbiAgfSwgW3N0b3JlXSk7XG59XG5leHBvcnQgZnVuY3Rpb24gdXNlUG9wdXBSb290U3luYyhzdG9yZSwgb3Blbikge1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghb3BlbiAmJiBzdG9yZS5zdGF0ZS5vcGVuTWV0aG9kICE9PSBudWxsKSB7XG4gICAgICBzdG9yZS5zZXQoJ29wZW5NZXRob2QnLCBudWxsKTtcbiAgICB9XG4gIH0sIFtvcGVuLCBzdG9yZV0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4gKCkgPT4ge1xuICAgIGlmIChzdG9yZS5zdGF0ZS5vcGVuTWV0aG9kICE9PSBudWxsKSB7XG4gICAgICBzdG9yZS5zZXQoJ29wZW5NZXRob2QnLCBudWxsKTtcbiAgICB9XG4gIH0sIFtzdG9yZV0pO1xufSIsIi8qKlxuICogRGV2ZWxvcG1lbnQtb25seSByZXZlcnNlIGluZGV4IG9mIGVsZW1lbnQgdG8gcmVnaXN0ZXJlZCBpZCwga2V5ZWQgYnkgdGhlIG93bmluZyBtYXAuXG4gKlxuICogUmVnaXN0cmF0aW9uIHdvdWxkIG90aGVyd2lzZSBoYXZlIHRvIHNjYW4gZXZlcnkgZW50cnkgdG8gZGV0ZWN0IGFuIGVsZW1lbnQgY2xhaW1lZCBieSB0d28gaWRzLFxuICogbWFraW5nIHRoZSBtb3VudCBvZiBtYW55IHRyaWdnZXJzIHNoYXJpbmcgb25lIGhhbmRsZSBxdWFkcmF0aWMuIEtlcHQgbW9kdWxlLXNjb3BlZCwgbGF6aWx5XG4gKiBpbml0aWFsaXplZCwgYW5kIHJlYWQgb25seSBmcm9tIGBwcm9jZXNzLmVudi5OT0RFX0VOVmAgZ3VhcmRzIHNvIHByb2R1Y3Rpb24gYnVpbGRzIGRyb3AgaXQgYWxvbmdcbiAqIHdpdGggdGhlIGNoZWNrcy5cbiAqL1xubGV0IGRldkVsZW1lbnRJZHNCeU1hcDtcbmZ1bmN0aW9uIGdldERldkVsZW1lbnRJZHMobWFwKSB7XG4gIGRldkVsZW1lbnRJZHNCeU1hcCA/Pz0gbmV3IFdlYWtNYXAoKTtcbiAgbGV0IGVsZW1lbnRJZHMgPSBkZXZFbGVtZW50SWRzQnlNYXAuZ2V0KG1hcCk7XG4gIGlmICghZWxlbWVudElkcykge1xuICAgIGVsZW1lbnRJZHMgPSBuZXcgV2Vha01hcCgpO1xuICAgIGRldkVsZW1lbnRJZHNCeU1hcC5zZXQobWFwLCBlbGVtZW50SWRzKTtcbiAgfVxuICByZXR1cm4gZWxlbWVudElkcztcbn1cblxuLyoqXG4gKiBEYXRhIHN0cnVjdHVyZSB0byBrZWVwIHRyYWNrIG9mIHBvcHVwIHRyaWdnZXIgZWxlbWVudHMgYnkgdGhlaXIgSURzLlxuICpcbiAqIEVsZW1lbnQgbG9va3VwcyBpdGVyYXRlIHRoZSBpZCBtYXAgcmF0aGVyIHRoYW4gbWFpbnRhaW5pbmcgYSBwYXJhbGxlbCBTZXQuIFJlZ2lzdHJhdGlvbiBpcyBPKDEpLFxuICogd2hpbGUgYGhhc0VsZW1lbnRgIGFuZCBgaGFzTWF0Y2hpbmdFbGVtZW50YCBhcmUgbGluZWFyIGluIHRoZSBudW1iZXIgb2YgdHJpZ2dlcnMuXG4gKi9cbmV4cG9ydCBjbGFzcyBQb3B1cFRyaWdnZXJNYXAge1xuICBpZE1hcCA9IG5ldyBNYXAoKTtcblxuICAvKipcbiAgICogQWRkcyBhIHRyaWdnZXIgZWxlbWVudCB3aXRoIHRoZSBnaXZlbiBJRC5cbiAgICpcbiAgICogTm90ZTogVGhlIHByb3ZpZGVkIGVsZW1lbnQgaXMgYXNzdW1lZCB0byBub3QgYmUgcmVnaXN0ZXJlZCB1bmRlciBtdWx0aXBsZSBJRHMuXG4gICAqL1xuICBhZGQoaWQsIGVsZW1lbnQpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgY29uc3QgZWxlbWVudElkcyA9IGdldERldkVsZW1lbnRJZHModGhpcyk7XG4gICAgICBjb25zdCBleGlzdGluZ0lkID0gZWxlbWVudElkcy5nZXQoZWxlbWVudCk7XG4gICAgICBpZiAoZXhpc3RpbmdJZCAhPT0gdW5kZWZpbmVkICYmIGV4aXN0aW5nSWQgIT09IGlkKSB7XG4gICAgICAgIC8vIFRPRE86IGZpeCBtdWkvbm8tZ3VhcmRlZC10aHJvd1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbXVpL25vLWd1YXJkZWQtdGhyb3dcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdCYXNlIFVJOiBBIHRyaWdnZXIgZWxlbWVudCBjYW5ub3QgYmUgcmVnaXN0ZXJlZCB1bmRlciBtdWx0aXBsZSBJRHMgaW4gUG9wdXBUcmlnZ2VyTWFwLicpO1xuICAgICAgfVxuXG4gICAgICAvLyBSZXVzaW5nIGFuIGlkIGZvciBhIGRpZmZlcmVudCBlbGVtZW50IGV2aWN0cyB0aGUgcHJldmlvdXMgb25lLCBzbyBpdCBtdXN0IGxvc2UgaXRzIGNsYWltXG4gICAgICAvLyBvbiB0aGUgaWQgb3IgYSBsYXRlciByZWdpc3RyYXRpb24gdW5kZXIgYSBkaWZmZXJlbnQgaWQgd291bGQgYmUgcmVwb3J0ZWQgYXMgYSBkdXBsaWNhdGUuXG4gICAgICBjb25zdCBwcmV2aW91c0VsZW1lbnQgPSB0aGlzLmlkTWFwLmdldChpZCk7XG4gICAgICBpZiAocHJldmlvdXNFbGVtZW50ICE9PSB1bmRlZmluZWQgJiYgcHJldmlvdXNFbGVtZW50ICE9PSBlbGVtZW50KSB7XG4gICAgICAgIGVsZW1lbnRJZHMuZGVsZXRlKHByZXZpb3VzRWxlbWVudCk7XG4gICAgICB9XG4gICAgICBlbGVtZW50SWRzLnNldChlbGVtZW50LCBpZCk7XG4gICAgfVxuICAgIHRoaXMuaWRNYXAuc2V0KGlkLCBlbGVtZW50KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW1vdmVzIHRoZSB0cmlnZ2VyIGVsZW1lbnQgd2l0aCB0aGUgZ2l2ZW4gSUQuXG4gICAqL1xuICBkZWxldGUoaWQpIHtcbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgY29uc3QgZWxlbWVudCA9IHRoaXMuaWRNYXAuZ2V0KGlkKTtcbiAgICAgIGlmIChlbGVtZW50ICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgZGV2RWxlbWVudElkc0J5TWFwPy5nZXQodGhpcyk/LmRlbGV0ZShlbGVtZW50KTtcbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5pZE1hcC5kZWxldGUoaWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdGhlIGdpdmVuIGVsZW1lbnQgaXMgcmVnaXN0ZXJlZCBhcyBhIHRyaWdnZXIuXG4gICAqL1xuICBoYXNFbGVtZW50KGVsZW1lbnQpIHtcbiAgICBmb3IgKGNvbnN0IHJlZ2lzdGVyZWQgb2YgdGhpcy5pZE1hcC52YWx1ZXMoKSkge1xuICAgICAgaWYgKHJlZ2lzdGVyZWQgPT09IGVsZW1lbnQpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRoZXJlIGlzIGEgcmVnaXN0ZXJlZCB0cmlnZ2VyIGVsZW1lbnQgbWF0Y2hpbmcgdGhlIGdpdmVuIHByZWRpY2F0ZS5cbiAgICovXG4gIGhhc01hdGNoaW5nRWxlbWVudChwcmVkaWNhdGUpIHtcbiAgICBmb3IgKGNvbnN0IGVsZW1lbnQgb2YgdGhpcy5pZE1hcC52YWx1ZXMoKSkge1xuICAgICAgaWYgKHByZWRpY2F0ZShlbGVtZW50KSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIHRyaWdnZXIgZWxlbWVudCBhc3NvY2lhdGVkIHdpdGggdGhlIGdpdmVuIElELCBvciB1bmRlZmluZWQgaWYgbm8gc3VjaCBlbGVtZW50IGV4aXN0cy5cbiAgICovXG4gIGdldEJ5SWQoaWQpIHtcbiAgICByZXR1cm4gdGhpcy5pZE1hcC5nZXQoaWQpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gaXRlcmFibGUgb2YgYWxsIHJlZ2lzdGVyZWQgdHJpZ2dlciBlbnRyaWVzLCB3aGVyZSBlYWNoIGVudHJ5IGlzIGEgdHVwbGUgb2YgW2lkLCBlbGVtZW50XS5cbiAgICovXG4gIGVudHJpZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMuaWRNYXAuZW50cmllcygpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYW4gaXRlcmFibGUgb2YgYWxsIHJlZ2lzdGVyZWQgdHJpZ2dlciBlbGVtZW50cy5cbiAgICovXG4gIGVsZW1lbnRzKCkge1xuICAgIHJldHVybiB0aGlzLmlkTWFwLnZhbHVlcygpO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgdGhlIG51bWJlciBvZiByZWdpc3RlcmVkIHRyaWdnZXIgZWxlbWVudHMuXG4gICAqL1xuICBnZXQgc2l6ZSgpIHtcbiAgICByZXR1cm4gdGhpcy5pZE1hcC5zaXplO1xuICB9XG59IiwiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlUmVmV2l0aEluaXQgfSBmcm9tIFwiLi91c2VSZWZXaXRoSW5pdC5tanNcIjtcbmNvbnN0IGhvb2tzID0gW107XG5sZXQgY3VycmVudEluc3RhbmNlID0gdW5kZWZpbmVkO1xuZXhwb3J0IGZ1bmN0aW9uIGdldEluc3RhbmNlKCkge1xuICByZXR1cm4gY3VycmVudEluc3RhbmNlO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHNldEluc3RhbmNlKGluc3RhbmNlKSB7XG4gIGN1cnJlbnRJbnN0YW5jZSA9IGluc3RhbmNlO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHJlZ2lzdGVyKGhvb2spIHtcbiAgaG9va3MucHVzaChob29rKTtcbn1cblxuLyoqXG4gKiBXcmFwcyBhIGNvbXBvbmVudCBmdW5jdGlvbiB0byBlbmFibGUgcGVyZm9ybWFuY2Ugb3B0aW1pemF0aW9ucyBmb3IgaW50ZXJuYWwgaG9va3MuXG4gKlxuICogKipQZXJmb3JtYW5jZSBPcHRpbWl6YXRpb246KipcbiAqIENvbXBvbmVudHMgd3JhcHBlZCB3aXRoIGBmYXN0Q29tcG9uZW50YCBoYXZlIGFjY2VzcyB0byBhIHNoYXJlZCBcImluc3RhbmNlXCIgY29udGV4dCB0aGF0IGVuYWJsZXNcbiAqIHNwZWNpYWxpemVkIGhvb2sgaW1wbGVtZW50YXRpb25zIHRvIGJhdGNoIG9wZXJhdGlvbnMgYW5kIHJlZHVjZSBvdmVyaGVhZC4gVGhlIHdyYXBwZXIgY3JlYXRlcyBhXG4gKiBzdGFibGUgaW5zdGFuY2Ugb2JqZWN0IHRoYXQgcGVyc2lzdHMgYWNyb3NzIHJlbmRlcnMsIHNldHMgaXQgYXMgdGhlIGN1cnJlbnQgY29udGV4dCwgY2FsbHNcbiAqIHJlZ2lzdGVyZWQgaG9va3MgYmVmb3JlIGFuZCBhZnRlciByZW5kZXJpbmcsIHRoZW4gY2xlYXJzIHRoZSBjb250ZXh0LiBUaGUgcHJpbWFyeSBiZW5lZml0IGlzXG4gKiB3aXRoIGB1c2VTdG9yZWAsIHdoZXJlIG11bHRpcGxlIHN0b3JlIHN1YnNjcmlwdGlvbnMgd2l0aGluIHRoZSBzYW1lIGNvbXBvbmVudCBhcmUgY29sbGFwc2VkIGludG9cbiAqIGEgc2luZ2xlIGB1c2VTeW5jRXh0ZXJuYWxTdG9yZWAgc3Vic2NyaXB0aW9uIHBlciBzdG9yZSwgc2lnbmlmaWNhbnRseSByZWR1Y2luZyByZS1yZW5kZXIgb3ZlcmhlYWQuXG4gKiBUaGlzIG9wdGltaXphdGlvbiBpcyBvbmx5IGFjdGl2ZSBvbiBSZWFjdCAxOSs7IG9uIGVhcmxpZXIgdmVyc2lvbnMgYHVzZVN0b3JlYCBmYWxscyBiYWNrIHRvIGFcbiAqIHNlcGFyYXRlIHN1YnNjcmlwdGlvbiBwZXIgY2FsbC5cbiAqXG4gKiAqKlJlcXVpcmVtZW50czoqKlxuICogLSBUaGUgY29tcG9uZW50IGZ1bmN0aW9uIHNob3VsZCBmb2xsb3cgc3RhbmRhcmQgUmVhY3QgY29tcG9uZW50IHBhdHRlcm5zXG4gKiAtIGB1c2VTdG9yZWAgY2FsbHMgbXVzdCBrZWVwIGEgc3RhYmxlIG9yZGVyIGFuZCBjb3VudCBhY3Jvc3MgcmVuZGVycywgYXMgYmF0Y2hlZCBob29rcyBhcmVcbiAqICAgbWF0Y2hlZCBieSBjYWxsIGluZGV4XG4gKiAtIERvIG5vdCByZWx5IG9uIHRoZSBpbnN0YW5jZSBjb250ZXh0IG91dHNpZGUgb2Ygc3BlY2lhbGl6ZWQgaG9va3NcbiAqXG4gKiBAcGFyYW0gZm4gLSBUaGUgY29tcG9uZW50IGZ1bmN0aW9uIHRvIHdyYXBcbiAqIEByZXR1cm5zIEEgd3JhcHBlZCBjb21wb25lbnQgd2l0aCB0aGUgc2FtZSBzaWduYXR1cmUgYXMgdGhlIGlucHV0IGZ1bmN0aW9uXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzeFxuICogLy8gV3JhcHBpbmcgYSBjb21wb25lbnQgdG8gZW5hYmxlIG9wdGltaXplZCB1c2VTdG9yZSBiYXRjaGluZ1xuICogZXhwb3J0IGNvbnN0IFRvb2x0aXBSb290ID0gZmFzdENvbXBvbmVudChmdW5jdGlvbiBUb29sdGlwUm9vdChwcm9wcykge1xuICogICAvLyBUaGVzZSB1c2VTdG9yZSBjYWxscyBzaGFyZSBhIHNpbmdsZSBzdWJzY3JpcHRpb25cbiAqICAgY29uc3Qgb3BlbiA9IHVzZVN0b3JlKHN0b3JlLCAoc3RhdGUpID0+IHN0YXRlLm9wZW4pO1xuICogICBjb25zdCBkaXNhYmxlZCA9IHVzZVN0b3JlKHN0b3JlLCAoc3RhdGUpID0+IHN0YXRlLmRpc2FibGVkKTtcbiAqICAgY29uc3QgdmFsdWUgPSB1c2VTdG9yZShzdG9yZSwgKHN0YXRlKSA9PiBzdGF0ZS52YWx1ZSk7XG4gKiAgIC8vIC4uLlxuICogfSk7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGZhc3RDb21wb25lbnQoZm4pIHtcbiAgY29uc3QgRmFzdENvbXBvbmVudCA9IChwcm9wcywgZm9yd2FyZGVkUmVmKSA9PiB7XG4gICAgY29uc3QgaW5zdGFuY2UgPSB1c2VSZWZXaXRoSW5pdChjcmVhdGVJbnN0YW5jZSkuY3VycmVudDtcbiAgICBsZXQgcmVzdWx0O1xuICAgIHRyeSB7XG4gICAgICBjdXJyZW50SW5zdGFuY2UgPSBpbnN0YW5jZTtcbiAgICAgIGZvciAoY29uc3QgaG9vayBvZiBob29rcykge1xuICAgICAgICBob29rLmJlZm9yZShpbnN0YW5jZSk7XG4gICAgICB9XG4gICAgICByZXN1bHQgPSBmbihwcm9wcywgZm9yd2FyZGVkUmVmKTtcbiAgICAgIGZvciAoY29uc3QgaG9vayBvZiBob29rcykge1xuICAgICAgICBob29rLmFmdGVyKGluc3RhbmNlKTtcbiAgICAgIH1cbiAgICAgIGluc3RhbmNlLmRpZEluaXRpYWxpemUgPSB0cnVlO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBjdXJyZW50SW5zdGFuY2UgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH07XG4gIEZhc3RDb21wb25lbnQuZGlzcGxheU5hbWUgPSBmbi5kaXNwbGF5TmFtZSB8fCBmbi5uYW1lO1xuICByZXR1cm4gRmFzdENvbXBvbmVudDtcbn1cblxuLyoqXG4gKiBXcmFwcyBhIGNvbXBvbmVudCBmdW5jdGlvbiB3aXRoIHJlZiBmb3J3YXJkaW5nIHRvIGVuYWJsZSBwZXJmb3JtYW5jZSBvcHRpbWl6YXRpb25zIGZvciBpbnRlcm5hbCBob29rcy5cbiAqXG4gKiBUaGlzIGlzIGEgY29udmVuaWVuY2Ugd3JhcHBlciB0aGF0IGNvbWJpbmVzIGBmYXN0Q29tcG9uZW50YCB3aXRoIGBSZWFjdC5mb3J3YXJkUmVmYCwgZW5hYmxpbmdcbiAqIGJvdGggcGVyZm9ybWFuY2Ugb3B0aW1pemF0aW9ucyBhbmQgcHJvcGVyIHJlZiBmb3J3YXJkaW5nLiBTZWUgYGZhc3RDb21wb25lbnRgIGZvciBkZXRhaWxzIG9uXG4gKiB0aGUgcGVyZm9ybWFuY2UgYmVuZWZpdHMuXG4gKlxuICogQHBhcmFtIGZuIC0gVGhlIGNvbXBvbmVudCBmdW5jdGlvbiB0aGF0IGFjY2VwdHMgcHJvcHMgYW5kIGEgZm9yd2FyZGVkIHJlZlxuICogQHJldHVybnMgQSB3cmFwcGVkIGNvbXBvbmVudCB3aXRoIHJlZiBmb3J3YXJkaW5nIGVuYWJsZWRcbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHN4XG4gKiAvLyBXcmFwcGluZyBhIGNvbXBvbmVudCB3aXRoIHJlZiBmb3J3YXJkaW5nIGFuZCBvcHRpbWl6ZWQgaG9va3NcbiAqIGV4cG9ydCBjb25zdCBUb29sdGlwVHJpZ2dlciA9IGZhc3RDb21wb25lbnRSZWYoZnVuY3Rpb24gVG9vbHRpcFRyaWdnZXIoXG4gKiAgIHByb3BzLFxuICogICBmb3J3YXJkZWRSZWZcbiAqICkge1xuICogICBjb25zdCBzdG9yZSA9IHVzZUNvbnRleHQoVG9vbHRpcENvbnRleHQpO1xuICogICBjb25zdCBvcGVuID0gdXNlU3RvcmUoc3RvcmUsIChzdGF0ZSkgPT4gc3RhdGUub3Blbik7XG4gKiAgIC8vIC4uLiBjb21wb25lbnQgbG9naWMgd2l0aCByZWZcbiAqICAgcmV0dXJuIDxidXR0b24gcmVmPXtmb3J3YXJkZWRSZWZ9IHsuLi5wcm9wc30gLz47XG4gKiB9KTtcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gZmFzdENvbXBvbmVudFJlZihmbikge1xuICByZXR1cm4gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZmFzdENvbXBvbmVudChmbikpO1xufVxuZnVuY3Rpb24gY3JlYXRlSW5zdGFuY2UoKSB7XG4gIHJldHVybiB7XG4gICAgZGlkSW5pdGlhbGl6ZTogZmFsc2VcbiAgfTtcbn0iLCJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG4vKiBXZSBuZWVkIHRvIGltcG9ydCB0aGUgc2hpbSBiZWNhdXNlIFJlYWN0IDE3IGRvZXMgbm90IHN1cHBvcnQgdGhlIGB1c2VTeW5jRXh0ZXJuYWxTdG9yZWAgQVBJLlxuICogTW9yZSBpbmZvOiBodHRwczovL2dpdGh1Yi5jb20vbXVpL211aS14L2lzc3Vlcy8xODMwMyNpc3N1ZWNvbW1lbnQtMjk1ODM5MjM0MSAqL1xuaW1wb3J0IHsgdXNlU3luY0V4dGVybmFsU3RvcmUgfSBmcm9tICd1c2Utc3luYy1leHRlcm5hbC1zdG9yZS9zaGltJztcbmltcG9ydCB7IHVzZVN5bmNFeHRlcm5hbFN0b3JlV2l0aFNlbGVjdG9yIH0gZnJvbSAndXNlLXN5bmMtZXh0ZXJuYWwtc3RvcmUvc2hpbS93aXRoLXNlbGVjdG9yJztcbmltcG9ydCB7IGlzUmVhY3RWZXJzaW9uQXRMZWFzdCB9IGZyb20gXCIuLi9yZWFjdFZlcnNpb24ubWpzXCI7XG5pbXBvcnQgeyByZWdpc3RlciwgZ2V0SW5zdGFuY2UgfSBmcm9tIFwiLi4vZmFzdEhvb2tzLm1qc1wiO1xuLyogU29tZSB0ZXN0cyBmYWlsIGluIFIxOCB3aXRoIHRoZSByYXcgdXNlU3luY0V4dGVybmFsU3RvcmUuIEl0IG1heSBiZSBwb3NzaWJsZSB0byBtYWtlIGl0IHdvcmtcbiAqIGJ1dCBmb3Igbm93IHdlIG9ubHkgZW5hYmxlIGl0IGZvciBSMTkrLiAqL1xuY29uc3QgY2FuVXNlUmF3VXNlU3luY0V4dGVybmFsU3RvcmUgPSBpc1JlYWN0VmVyc2lvbkF0TGVhc3QoMTkpO1xuY29uc3QgdXNlU3RvcmVJbXBsZW1lbnRhdGlvbiA9IGNhblVzZVJhd1VzZVN5bmNFeHRlcm5hbFN0b3JlID8gdXNlU3RvcmVGYXN0IDogdXNlU3RvcmVMZWdhY3k7XG5leHBvcnQgZnVuY3Rpb24gdXNlU3RvcmUoc3RvcmUsIHNlbGVjdG9yLCBhMSwgYTIsIGEzKSB7XG4gIHJldHVybiB1c2VTdG9yZUltcGxlbWVudGF0aW9uKHN0b3JlLCBzZWxlY3RvciwgYTEsIGEyLCBhMyk7XG59XG5mdW5jdGlvbiB1c2VTdG9yZVIxOShzdG9yZSwgc2VsZWN0b3IsIGExLCBhMiwgYTMpIHtcbiAgY29uc3QgZ2V0U2VsZWN0aW9uID0gUmVhY3QudXNlQ2FsbGJhY2soKCkgPT4gc2VsZWN0b3Ioc3RvcmUuZ2V0U25hcHNob3QoKSwgYTEsIGEyLCBhMyksIFtzdG9yZSwgc2VsZWN0b3IsIGExLCBhMiwgYTNdKTtcbiAgcmV0dXJuIHVzZVN5bmNFeHRlcm5hbFN0b3JlKHN0b3JlLnN1YnNjcmliZSwgZ2V0U2VsZWN0aW9uLCBnZXRTZWxlY3Rpb24pO1xufVxucmVnaXN0ZXIoe1xuICBiZWZvcmUoaW5zdGFuY2UpIHtcbiAgICBpbnN0YW5jZS5zeW5jSW5kZXggPSAwO1xuICAgIGlmICghaW5zdGFuY2UuZGlkSW5pdGlhbGl6ZSkge1xuICAgICAgaW5zdGFuY2Uuc3luY1RpY2sgPSAxO1xuICAgICAgaW5zdGFuY2Uuc3luY0hvb2tzID0gW107XG4gICAgICBpbnN0YW5jZS5kaWRDaGFuZ2VTdG9yZSA9IHRydWU7XG4gICAgICBpbnN0YW5jZS5nZXRTbmFwc2hvdCA9ICgpID0+IHtcbiAgICAgICAgbGV0IGRpZENoYW5nZSA9IGZhbHNlO1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGluc3RhbmNlLnN5bmNIb29rcy5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICAgIGNvbnN0IGhvb2sgPSBpbnN0YW5jZS5zeW5jSG9va3NbaV07XG4gICAgICAgICAgY29uc3QgdmFsdWUgPSBob29rLnNlbGVjdG9yKGhvb2suc3RvcmUuc3RhdGUsIGhvb2suYTEsIGhvb2suYTIsIGhvb2suYTMpO1xuICAgICAgICAgIGlmICghT2JqZWN0LmlzKGhvb2sudmFsdWUsIHZhbHVlKSkge1xuICAgICAgICAgICAgZGlkQ2hhbmdlID0gdHJ1ZTtcbiAgICAgICAgICAgIGhvb2sudmFsdWUgPSB2YWx1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGRpZENoYW5nZSkge1xuICAgICAgICAgIGluc3RhbmNlLnN5bmNUaWNrICs9IDE7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGluc3RhbmNlLnN5bmNUaWNrO1xuICAgICAgfTtcbiAgICB9XG4gIH0sXG4gIGFmdGVyKGluc3RhbmNlKSB7XG4gICAgaWYgKGluc3RhbmNlLnN5bmNIb29rcy5sZW5ndGggPiAwKSB7XG4gICAgICBpZiAoaW5zdGFuY2UuZGlkQ2hhbmdlU3RvcmUpIHtcbiAgICAgICAgaW5zdGFuY2UuZGlkQ2hhbmdlU3RvcmUgPSBmYWxzZTtcbiAgICAgICAgaW5zdGFuY2Uuc3Vic2NyaWJlID0gb25TdG9yZUNoYW5nZSA9PiB7XG4gICAgICAgICAgY29uc3Qgc3RvcmVzID0gbmV3IFNldCgpO1xuICAgICAgICAgIGZvciAoY29uc3QgaG9vayBvZiBpbnN0YW5jZS5zeW5jSG9va3MpIHtcbiAgICAgICAgICAgIHN0b3Jlcy5hZGQoaG9vay5zdG9yZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IHVuc3Vic2NyaWJlcyA9IFtdO1xuICAgICAgICAgIGZvciAoY29uc3Qgc3RvcmUgb2Ygc3RvcmVzKSB7XG4gICAgICAgICAgICB1bnN1YnNjcmliZXMucHVzaChzdG9yZS5zdWJzY3JpYmUob25TdG9yZUNoYW5nZSkpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICAgICAgZm9yIChjb25zdCB1bnN1YnNjcmliZSBvZiB1bnN1YnNjcmliZXMpIHtcbiAgICAgICAgICAgICAgdW5zdWJzY3JpYmUoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG4gICAgICB1c2VTeW5jRXh0ZXJuYWxTdG9yZShpbnN0YW5jZS5zdWJzY3JpYmUsIGluc3RhbmNlLmdldFNuYXBzaG90LCBpbnN0YW5jZS5nZXRTbmFwc2hvdCk7XG4gICAgfVxuICB9XG59KTtcbmZ1bmN0aW9uIHVzZVN0b3JlRmFzdChzdG9yZSwgc2VsZWN0b3IsIGExLCBhMiwgYTMpIHtcbiAgY29uc3QgaW5zdGFuY2UgPSBnZXRJbnN0YW5jZSgpO1xuICBpZiAoIWluc3RhbmNlKSB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG4gICAgcmV0dXJuIHVzZVN0b3JlUjE5KHN0b3JlLCBzZWxlY3RvciwgYTEsIGEyLCBhMyk7XG4gIH1cbiAgY29uc3QgaW5kZXggPSBpbnN0YW5jZS5zeW5jSW5kZXg7XG4gIGluc3RhbmNlLnN5bmNJbmRleCArPSAxO1xuICBsZXQgaG9vaztcbiAgaWYgKCFpbnN0YW5jZS5kaWRJbml0aWFsaXplKSB7XG4gICAgaG9vayA9IHtcbiAgICAgIHN0b3JlLFxuICAgICAgc2VsZWN0b3IsXG4gICAgICBhMSxcbiAgICAgIGEyLFxuICAgICAgYTMsXG4gICAgICB2YWx1ZTogc2VsZWN0b3Ioc3RvcmUuZ2V0U25hcHNob3QoKSwgYTEsIGEyLCBhMylcbiAgICB9O1xuICAgIGluc3RhbmNlLnN5bmNIb29rcy5wdXNoKGhvb2spO1xuICB9IGVsc2Uge1xuICAgIGhvb2sgPSBpbnN0YW5jZS5zeW5jSG9va3NbaW5kZXhdO1xuICAgIGlmIChob29rLnN0b3JlICE9PSBzdG9yZSB8fCBob29rLnNlbGVjdG9yICE9PSBzZWxlY3RvciB8fCAhT2JqZWN0LmlzKGhvb2suYTEsIGExKSB8fCAhT2JqZWN0LmlzKGhvb2suYTIsIGEyKSB8fCAhT2JqZWN0LmlzKGhvb2suYTMsIGEzKSkge1xuICAgICAgaWYgKGhvb2suc3RvcmUgIT09IHN0b3JlKSB7XG4gICAgICAgIGluc3RhbmNlLmRpZENoYW5nZVN0b3JlID0gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGhvb2suc3RvcmUgPSBzdG9yZTtcbiAgICAgIGhvb2suc2VsZWN0b3IgPSBzZWxlY3RvcjtcbiAgICAgIGhvb2suYTEgPSBhMTtcbiAgICAgIGhvb2suYTIgPSBhMjtcbiAgICAgIGhvb2suYTMgPSBhMztcbiAgICAgIGhvb2sudmFsdWUgPSBzZWxlY3RvcihzdG9yZS5nZXRTbmFwc2hvdCgpLCBhMSwgYTIsIGEzKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGhvb2sudmFsdWU7XG59XG5mdW5jdGlvbiB1c2VTdG9yZUxlZ2FjeShzdG9yZSwgc2VsZWN0b3IsIGExLCBhMiwgYTMpIHtcbiAgcmV0dXJuIHVzZVN5bmNFeHRlcm5hbFN0b3JlV2l0aFNlbGVjdG9yKHN0b3JlLnN1YnNjcmliZSwgc3RvcmUuZ2V0U25hcHNob3QsIHN0b3JlLmdldFNuYXBzaG90LCBzdGF0ZSA9PiBzZWxlY3RvcihzdGF0ZSwgYTEsIGEyLCBhMykpO1xufSIsImltcG9ydCB7IHVzZVN0b3JlIH0gZnJvbSBcIi4vdXNlU3RvcmUubWpzXCI7XG4vKipcbiAqIEEgZGF0YSBzdG9yZSBpbXBsZW1lbnRhdGlvbiB0aGF0IGFsbG93cyBzdWJzY3JpYmluZyB0byBzdGF0ZSBjaGFuZ2VzIGFuZCB1cGRhdGluZyB0aGUgc3RhdGUuXG4gKiBJdCB1c2VzIGFuIG9ic2VydmVyIHBhdHRlcm4gdG8gbm90aWZ5IHN1YnNjcmliZXJzIHdoZW4gdGhlIHN0YXRlIGNoYW5nZXMuXG4gKi9cbmV4cG9ydCBjbGFzcyBTdG9yZSB7XG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgc3RvcmUgd2l0aCB0aGUgZ2l2ZW4gaW5pdGlhbCBzdGF0ZSwgY29uc3RydWN0aW5nIHRoZSBjbGFzcyBpdCBpcyBjYWxsZWQgb24uXG4gICAqIENhbGxpbmcgaXQgb24gYSBnZW5lcmljIGJhc2UgY2xhc3MgKGUuZy4gYFJlYWN0U3RvcmUuY3JlYXRlKC4uLilgKSBjb25zdHJ1Y3RzIHRoYXRcbiAgICogY2xhc3MgYnV0IGRlZ3JhZGVzIHRoZSBpbmZlcnJlZCBpbnN0YW5jZSB0eXBlIHRvIGBTdG9yZWA7IHVzZSBgbmV3YCB0aGVyZSBpbnN0ZWFkLlxuICAgKi9cbiAgc3RhdGljIGNyZWF0ZShzdGF0ZSkge1xuICAgIHJldHVybiBuZXcgdGhpcyhzdGF0ZSk7XG4gIH1cblxuICAvKipcbiAgICogVGhlIGN1cnJlbnQgc3RhdGUgb2YgdGhlIHN0b3JlLlxuICAgKiBUaGlzIHByb3BlcnR5IGlzIHVwZGF0ZWQgaW1tZWRpYXRlbHkgd2hlbiB0aGUgc3RhdGUgY2hhbmdlcyBhcyBhIHJlc3VsdCBvZiBjYWxsaW5nIHtAbGluayBzZXRTdGF0ZX0sIHtAbGluayB1cGRhdGV9LCBvciB7QGxpbmsgc2V0fS5cbiAgICogVG8gc3Vic2NyaWJlIHRvIHN0YXRlIGNoYW5nZXMsIHVzZSB0aGUge0BsaW5rIHVzZVN0YXRlfSBtZXRob2QuIFRoZSB2YWx1ZSByZXR1cm5lZCBieSB7QGxpbmsgdXNlU3RhdGV9IGlzIHVwZGF0ZWQgYWZ0ZXIgdGhlIGNvbXBvbmVudCByZW5kZXJzIChzaW1pbGFybHkgdG8gUmVhY3QncyB1c2VTdGF0ZSkuXG4gICAqIFRoZSB2YWx1ZXMgY2FuIGJlIHVzZWQgZGlyZWN0bHkgKHRvIGF2b2lkIHN1YnNjcmliaW5nIHRvIHRoZSBzdG9yZSkgaW4gZWZmZWN0cyBvciBldmVudCBoYW5kbGVycy5cbiAgICpcbiAgICogRG8gbm90IG1vZGlmeSBwcm9wZXJ0aWVzIGluIHN0YXRlIGRpcmVjdGx5LiBJbnN0ZWFkLCB1c2UgdGhlIHByb3ZpZGVkIG1ldGhvZHMgdG8gZW5zdXJlIHByb3BlciBzdGF0ZSBtYW5hZ2VtZW50IGFuZCBsaXN0ZW5lciBub3RpZmljYXRpb24uXG4gICAqL1xuXG4gIC8vIEludGVybmFsIHN0YXRlIHRvIGhhbmRsZSByZWN1cnNpdmUgYHNldFN0YXRlKClgIGNhbGxzXG5cbiAgY29uc3RydWN0b3Ioc3RhdGUpIHtcbiAgICB0aGlzLnN0YXRlID0gc3RhdGU7XG4gICAgdGhpcy5saXN0ZW5lcnMgPSBuZXcgU2V0KCk7XG4gICAgdGhpcy51cGRhdGVUaWNrID0gMDtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZWdpc3RlcnMgYSBsaXN0ZW5lciB0aGF0IHdpbGwgYmUgY2FsbGVkIHdoZW5ldmVyIHRoZSBzdG9yZSdzIHN0YXRlIGNoYW5nZXMuXG4gICAqXG4gICAqIEBwYXJhbSBmbiBUaGUgbGlzdGVuZXIgZnVuY3Rpb24gdG8gYmUgY2FsbGVkIG9uIHN0YXRlIGNoYW5nZXMuXG4gICAqIEByZXR1cm5zIEEgZnVuY3Rpb24gdG8gdW5zdWJzY3JpYmUgdGhlIGxpc3RlbmVyLlxuICAgKi9cbiAgc3Vic2NyaWJlID0gZm4gPT4ge1xuICAgIHRoaXMubGlzdGVuZXJzLmFkZChmbik7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRoaXMubGlzdGVuZXJzLmRlbGV0ZShmbik7XG4gICAgfTtcbiAgfTtcblxuICAvKipcbiAgICogUmV0dXJucyB0aGUgY3VycmVudCBzdGF0ZSBvZiB0aGUgc3RvcmUuXG4gICAqL1xuICBnZXRTbmFwc2hvdCA9ICgpID0+IHtcbiAgICByZXR1cm4gdGhpcy5zdGF0ZTtcbiAgfTtcblxuICAvKipcbiAgICogVXBkYXRlcyB0aGUgZW50aXJlIHN0b3JlJ3Mgc3RhdGUgYW5kIG5vdGlmaWVzIGFsbCByZWdpc3RlcmVkIGxpc3RlbmVycy5cbiAgICpcbiAgICogQHBhcmFtIG5ld1N0YXRlIFRoZSBuZXcgc3RhdGUgdG8gc2V0IGZvciB0aGUgc3RvcmUuXG4gICAqL1xuICBzZXRTdGF0ZShuZXdTdGF0ZSkge1xuICAgIGlmICh0aGlzLnN0YXRlID09PSBuZXdTdGF0ZSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLnN0YXRlID0gbmV3U3RhdGU7XG4gICAgdGhpcy51cGRhdGVUaWNrICs9IDE7XG4gICAgY29uc3QgY3VycmVudFRpY2sgPSB0aGlzLnVwZGF0ZVRpY2s7XG4gICAgZm9yIChjb25zdCBsaXN0ZW5lciBvZiB0aGlzLmxpc3RlbmVycykge1xuICAgICAgaWYgKGN1cnJlbnRUaWNrICE9PSB0aGlzLnVwZGF0ZVRpY2spIHtcbiAgICAgICAgLy8gSWYgdGhlIHRpY2sgaGFzIGNoYW5nZWQsIGEgcmVjdXJzaXZlIGBzZXRTdGF0ZWAgY2FsbCBoYXMgYmVlbiBtYWRlLFxuICAgICAgICAvLyBhbmQgaXQgaGFzIGFscmVhZHkgbm90aWZpZWQgYWxsIGxpc3RlbmVycy5cbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgbGlzdGVuZXIobmV3U3RhdGUpO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBNZXJnZXMgdGhlIHByb3ZpZGVkIGNoYW5nZXMgaW50byB0aGUgY3VycmVudCBzdGF0ZSBhbmQgbm90aWZpZXMgbGlzdGVuZXJzIGlmIHRoZXJlIGFyZSBjaGFuZ2VzLlxuICAgKiBFYWNoIHZhbHVlIG11c3QgbWF0Y2ggaXRzIHN0YXRlIGtleS4gUGFzcyBhbiBleGFjdCBrbm93biBzdWJzZXQgcmF0aGVyIHRoYW4gYSBicm9hZFxuICAgKiBgUGFydGlhbDxTdGF0ZT5gLCB3aGljaCBtYXkgY29udGFpbiBgdW5kZWZpbmVkYCBmb3IgcmVxdWlyZWQgc3RhdGUgZmllbGRzLlxuICAgKlxuICAgKiBAcGFyYW0gY2hhbmdlcyBBbiBvYmplY3QgY29udGFpbmluZyB0aGUgY2hhbmdlcyB0byBhcHBseSB0byB0aGUgY3VycmVudCBzdGF0ZS5cbiAgICovXG4gIHVwZGF0ZShjaGFuZ2VzKSB7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gY2hhbmdlcykge1xuICAgICAgaWYgKCFPYmplY3QuaXModGhpcy5zdGF0ZVtrZXldLCBjaGFuZ2VzW2tleV0pKSB7XG4gICAgICAgIHRoaXMuc2V0U3RhdGUoe1xuICAgICAgICAgIC4uLnRoaXMuc3RhdGUsXG4gICAgICAgICAgLi4uY2hhbmdlc1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBTZXRzIGEgc3BlY2lmaWMga2V5IGluIHRoZSBzdG9yZSdzIHN0YXRlIHRvIGEgbmV3IHZhbHVlIGFuZCBub3RpZmllcyBsaXN0ZW5lcnMgaWYgdGhlIHZhbHVlIGhhcyBjaGFuZ2VkLlxuICAgKlxuICAgKiBAcGFyYW0ga2V5IFRoZSBrZXkgaW4gdGhlIHN0b3JlJ3Mgc3RhdGUgdG8gdXBkYXRlLlxuICAgKiBAcGFyYW0gdmFsdWUgVGhlIG5ldyB2YWx1ZSB0byBzZXQgZm9yIHRoZSBzcGVjaWZpZWQga2V5LlxuICAgKi9cbiAgc2V0KGtleSwgdmFsdWUpIHtcbiAgICBpZiAoIU9iamVjdC5pcyh0aGlzLnN0YXRlW2tleV0sIHZhbHVlKSkge1xuICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgIC4uLnRoaXMuc3RhdGUsXG4gICAgICAgIFtrZXldOiB2YWx1ZVxuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdpdmVzIHRoZSBzdGF0ZSBhIG5ldyByZWZlcmVuY2UgYW5kIHVwZGF0ZXMgYWxsIHJlZ2lzdGVyZWQgbGlzdGVuZXJzLlxuICAgKi9cbiAgbm90aWZ5QWxsKCkge1xuICAgIGNvbnN0IG5ld1N0YXRlID0ge1xuICAgICAgLi4udGhpcy5zdGF0ZVxuICAgIH07XG4gICAgdGhpcy5zZXRTdGF0ZShuZXdTdGF0ZSk7XG4gIH1cbiAgdXNlKHNlbGVjdG9yLCBhMSwgYTIsIGEzKSB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzXG4gICAgcmV0dXJuIHVzZVN0b3JlKHRoaXMsIHNlbGVjdG9yLCBhMSwgYTIsIGEzKTtcbiAgfVxufSIsIi8qIEZhbHNlIHBvc2l0aXZlcyAtIEVTTGludCB0aGlua3Mgd2UncmUgY2FsbGluZyBhIGhvb2sgZnJvbSBhIGNsYXNzIGNvbXBvbmVudC4gKi9cbi8qIGVzbGludC1kaXNhYmxlIHJlYWN0LWhvb2tzL3J1bGVzLW9mLWhvb2tzICovXG4ndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFN0b3JlIH0gZnJvbSBcIi4vU3RvcmUubWpzXCI7XG5pbXBvcnQgeyB1c2VTdG9yZSB9IGZyb20gXCIuL3VzZVN0b3JlLm1qc1wiO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tIFwiLi4vdXNlU3RhYmxlQ2FsbGJhY2subWpzXCI7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tIFwiLi4vdXNlSXNvTGF5b3V0RWZmZWN0Lm1qc1wiO1xuaW1wb3J0IHsgTk9PUCB9IGZyb20gXCIuLi9lbXB0eS5tanNcIjtcblxuLyoqXG4gKiBBIFN0b3JlIHRoYXQgc3VwcG9ydHMgY29udHJvbGxlZCBzdGF0ZSBrZXlzLCBub24tcmVhY3RpdmUgdmFsdWVzIGFuZCBwcm92aWRlcyB1dGlsaXR5IG1ldGhvZHMgZm9yIFJlYWN0LlxuICovXG5leHBvcnQgY2xhc3MgUmVhY3RTdG9yZSBleHRlbmRzIFN0b3JlIHtcbiAgLyoqXG4gICAqIENyZWF0ZXMgYSBuZXcgUmVhY3RTdG9yZSBpbnN0YW5jZS5cbiAgICpcbiAgICogQHBhcmFtIHN0YXRlIEluaXRpYWwgc3RhdGUgb2YgdGhlIHN0b3JlLlxuICAgKiBAcGFyYW0gY29udGV4dCBOb24tcmVhY3RpdmUgY29udGV4dCB2YWx1ZXMuXG4gICAqIEBwYXJhbSBzZWxlY3RvcnMgT3B0aW9uYWwgc2VsZWN0b3JzIGZvciB1c2Ugd2l0aCBgdXNlU3RhdGVgLlxuICAgKi9cbiAgY29uc3RydWN0b3Ioc3RhdGUsIGNvbnRleHQgPSB7fSwgc2VsZWN0b3JzKSB7XG4gICAgc3VwZXIoc3RhdGUpO1xuICAgIHRoaXMuY29udGV4dCA9IGNvbnRleHQ7XG4gICAgdGhpcy5zZWxlY3RvcnMgPSBzZWxlY3RvcnM7XG4gIH1cblxuICAvKipcbiAgICogTm9uLXJlYWN0aXZlIHZhbHVlcyBzdWNoIGFzIHJlZnMsIGNhbGxiYWNrcywgZXRjLlxuICAgKi9cblxuICAvKipcbiAgICogU3luY2hyb25pemVzIGEgc2luZ2xlIGV4dGVybmFsIHZhbHVlIGludG8gdGhlIHN0b3JlLlxuICAgKlxuICAgKiBOb3RlIHRoYXQgdGhlIHdoaWxlIHRoZSB2YWx1ZSBpbiBgc3RhdGVgIGlzIHVwZGF0ZWQgaW1tZWRpYXRlbHksIHRoZSB2YWx1ZSByZXR1cm5lZFxuICAgKiBieSBgdXNlU3RhdGVgIGlzIHVwZGF0ZWQgYmVmb3JlIHRoZSBuZXh0IHJlbmRlciAoc2ltaWxhcmx5IHRvIFJlYWN0J3MgYHVzZVN0YXRlYCkuXG4gICAqL1xuICB1c2VTeW5jZWRWYWx1ZShrZXksIHZhbHVlKSB7XG4gICAgUmVhY3QudXNlRGVidWdWYWx1ZShrZXkpO1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXRoaXNcbiAgICBjb25zdCBzdG9yZSA9IHRoaXM7XG4gICAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgIGlmIChzdG9yZS5zdGF0ZVtrZXldICE9PSB2YWx1ZSkge1xuICAgICAgICBzdG9yZS5zZXQoa2V5LCB2YWx1ZSk7XG4gICAgICB9XG4gICAgfSwgW3N0b3JlLCBrZXksIHZhbHVlXSk7XG4gIH1cblxuICAvKipcbiAgICogU3luY2hyb25pemVzIGEgc2luZ2xlIGV4dGVybmFsIHZhbHVlIGludG8gdGhlIHN0b3JlIGFuZFxuICAgKiBjbGVhbnMgaXQgdXAgKHNldHMgdG8gYHVuZGVmaW5lZGApIG9uIHVubW91bnQuXG4gICAqXG4gICAqIE5vdGUgdGhhdCB0aGUgd2hpbGUgdGhlIHZhbHVlIGluIGBzdGF0ZWAgaXMgdXBkYXRlZCBpbW1lZGlhdGVseSwgdGhlIHZhbHVlIHJldHVybmVkXG4gICAqIGJ5IGB1c2VTdGF0ZWAgaXMgdXBkYXRlZCBiZWZvcmUgdGhlIG5leHQgcmVuZGVyIChzaW1pbGFybHkgdG8gUmVhY3QncyBgdXNlU3RhdGVgKS5cbiAgICovXG4gIHVzZVN5bmNlZFZhbHVlV2l0aENsZWFudXAoa2V5LCB2YWx1ZSkge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXRoaXNcbiAgICBjb25zdCBzdG9yZSA9IHRoaXM7XG4gICAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAgIGlmIChzdG9yZS5zdGF0ZVtrZXldICE9PSB2YWx1ZSkge1xuICAgICAgICBzdG9yZS5zZXQoa2V5LCB2YWx1ZSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBzdG9yZS5zZXQoa2V5LCB1bmRlZmluZWQpO1xuICAgICAgfTtcbiAgICB9LCBbc3RvcmUsIGtleSwgdmFsdWVdKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5jaHJvbml6ZXMgbXVsdGlwbGUgZXh0ZXJuYWwgdmFsdWVzIGludG8gdGhlIHN0b3JlLlxuICAgKiBFYWNoIHZhbHVlIG11c3QgbWF0Y2ggaXRzIHN0YXRlIGtleS4gUGFzcyBhbiBleGFjdCBrbm93biBzdWJzZXQgcmF0aGVyIHRoYW4gYSBicm9hZFxuICAgKiBgUGFydGlhbDxTdGF0ZT5gLCB3aGljaCBtYXkgY29udGFpbiBgdW5kZWZpbmVkYCBmb3IgcmVxdWlyZWQgc3RhdGUgZmllbGRzLlxuICAgKlxuICAgKiBOb3RlIHRoYXQgdGhlIHdoaWxlIHRoZSB2YWx1ZXMgaW4gYHN0YXRlYCBhcmUgdXBkYXRlZCBpbW1lZGlhdGVseSwgdGhlIHZhbHVlcyByZXR1cm5lZFxuICAgKiBieSBgdXNlU3RhdGVgIGFyZSB1cGRhdGVkIGJlZm9yZSB0aGUgbmV4dCByZW5kZXIgKHNpbWlsYXJseSB0byBSZWFjdCdzIGB1c2VTdGF0ZWApLlxuICAgKlxuICAgKiBAcGFyYW0gc3RhdGVQYXJ0IEFuIGV4YWN0IHN1YnNldCBvZiBzdGF0ZSBmaWVsZHMgdG8gc3luY2hyb25pemUuIFVua25vd24ga2V5cyBhcmUgbm90IGFjY2VwdGVkLlxuICAgKi9cbiAgdXNlU3luY2VkVmFsdWVzKHN0YXRlUGFydCkge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBjb25zaXN0ZW50LXRoaXNcbiAgICBjb25zdCBzdG9yZSA9IHRoaXM7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIC8vIENoZWNrIHRoYXQgYW4gb2JqZWN0IHdpdGggdGhlIHNhbWUgc2hhcGUgaXMgcGFzc2VkIG9uIGV2ZXJ5IHJlbmRlclxuICAgICAgUmVhY3QudXNlRGVidWdWYWx1ZShzdGF0ZVBhcnQsIHAgPT4gT2JqZWN0LmtleXMocCkpO1xuICAgICAgY29uc3Qga2V5cyA9IFJlYWN0LnVzZVJlZihPYmplY3Qua2V5cyhzdGF0ZVBhcnQpKS5jdXJyZW50O1xuICAgICAgY29uc3QgbmV4dEtleXMgPSBPYmplY3Qua2V5cyhzdGF0ZVBhcnQpO1xuICAgICAgaWYgKGtleXMubGVuZ3RoICE9PSBuZXh0S2V5cy5sZW5ndGggfHwga2V5cy5zb21lKChrZXksIGluZGV4KSA9PiBrZXkgIT09IG5leHRLZXlzW2luZGV4XSkpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcignUmVhY3RTdG9yZS51c2VTeW5jZWRWYWx1ZXMgZXhwZWN0cyB0aGUgc2FtZSBwcm9wIGtleXMgb24gZXZlcnkgcmVuZGVyLiBLZXlzIHNob3VsZCBiZSBzdGFibGUuJyk7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGRlcGVuZGVuY2llcyA9IE9iamVjdC52YWx1ZXMoc3RhdGVQYXJ0KTtcbiAgICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgc3RvcmUudXBkYXRlKHN0YXRlUGFydCk7XG4gICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gICAgfSwgW3N0b3JlLCAuLi5kZXBlbmRlbmNpZXNdKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBSZWdpc3RlcnMgYSBjb250cm9sbGFibGUgcHJvcCBwYWlyIChgY29udHJvbGxlZGAsIGBkZWZhdWx0VmFsdWVgKSBmb3IgYSBzcGVjaWZpYyBrZXkuIElmIGBjb250cm9sbGVkYFxuICAgKiBpcyBub24tdW5kZWZpbmVkLCB0aGUgc3RvcmUncyBzdGF0ZSBhdCBga2V5YCBpcyB1cGRhdGVkIHRvIG1hdGNoIGBjb250cm9sbGVkYC5cbiAgICovXG4gIHVzZUNvbnRyb2xsZWRQcm9wKGtleSwgY29udHJvbGxlZCkge1xuICAgIFJlYWN0LnVzZURlYnVnVmFsdWUoa2V5KTtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgY29uc2lzdGVudC10aGlzXG4gICAgY29uc3Qgc3RvcmUgPSB0aGlzO1xuICAgIGNvbnN0IGlzQ29udHJvbGxlZCA9IGNvbnRyb2xsZWQgIT09IHVuZGVmaW5lZDtcbiAgICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgICAgaWYgKGlzQ29udHJvbGxlZCAmJiAhT2JqZWN0LmlzKHN0b3JlLnN0YXRlW2tleV0sIGNvbnRyb2xsZWQpKSB7XG4gICAgICAgIC8vIFNldCB0aGUgaW50ZXJuYWwgc3RhdGUgdG8gbWF0Y2ggdGhlIGNvbnRyb2xsZWQgdmFsdWUuXG4gICAgICAgIHN0b3JlLnNldFN0YXRlKHtcbiAgICAgICAgICAuLi5zdG9yZS5zdGF0ZSxcbiAgICAgICAgICBba2V5XTogY29udHJvbGxlZFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LCBbc3RvcmUsIGtleSwgY29udHJvbGxlZCwgaXNDb250cm9sbGVkXSk7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZVxuICAgICAgY29uc3QgY2FjaGUgPSB0aGlzLmNvbnRyb2xsZWRWYWx1ZXMgPz89IG5ldyBNYXAoKTtcbiAgICAgIGlmICghY2FjaGUuaGFzKGtleSkpIHtcbiAgICAgICAgY2FjaGUuc2V0KGtleSwgaXNDb250cm9sbGVkKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHByZXZpb3VzbHlDb250cm9sbGVkID0gY2FjaGUuZ2V0KGtleSk7XG4gICAgICBpZiAocHJldmlvdXNseUNvbnRyb2xsZWQgIT09IHVuZGVmaW5lZCAmJiBwcmV2aW91c2x5Q29udHJvbGxlZCAhPT0gaXNDb250cm9sbGVkKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoYEEgY29tcG9uZW50IGlzIGNoYW5naW5nIHRoZSAke3ByZXZpb3VzbHlDb250cm9sbGVkID8gJycgOiAndW4nfWNvbnRyb2xsZWQgc3RhdGUgb2YgJHtrZXkudG9TdHJpbmcoKX0gdG8gYmUgJHtwcmV2aW91c2x5Q29udHJvbGxlZCA/ICd1bicgOiAnJ31jb250cm9sbGVkLiBFbGVtZW50cyBzaG91bGQgbm90IHN3aXRjaCBmcm9tIHVuY29udHJvbGxlZCB0byBjb250cm9sbGVkIChvciB2aWNlIHZlcnNhKS5gKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKiogR2V0cyB0aGUgY3VycmVudCB2YWx1ZSBmcm9tIHRoZSBzdG9yZSB1c2luZyBhIHNlbGVjdG9yIHdpdGggdGhlIHByb3ZpZGVkIGtleS5cbiAgICpcbiAgICogQHBhcmFtIGtleSBLZXkgb2YgdGhlIHNlbGVjdG9yIHRvIHVzZS5cbiAgICovXG5cbiAgc2VsZWN0KGtleSwgYTEsIGEyLCBhMykge1xuICAgIGNvbnN0IHNlbGVjdG9yID0gdGhpcy5zZWxlY3RvcnNba2V5XTtcbiAgICByZXR1cm4gc2VsZWN0b3IodGhpcy5zdGF0ZSwgYTEsIGEyLCBhMyk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhIHZhbHVlIGZyb20gdGhlIHN0b3JlJ3Mgc3RhdGUgdXNpbmcgYSBzZWxlY3RvciBmdW5jdGlvbi5cbiAgICogVXNlZCB0byBzdWJzY3JpYmUgdG8gc3BlY2lmaWMgcGFydHMgb2YgdGhlIHN0YXRlLlxuICAgKiBUaGlzIG1ldGhvZHMgY2F1c2VzIGEgcmVyZW5kZXIgd2hlbmV2ZXIgdGhlIHNlbGVjdGVkIHN0YXRlIGNoYW5nZXMuXG4gICAqXG4gICAqIEBwYXJhbSBrZXkgS2V5IG9mIHRoZSBzZWxlY3RvciB0byB1c2UuXG4gICAqL1xuXG4gIHVzZVN0YXRlKGtleSwgYTEsIGEyLCBhMykge1xuICAgIFJlYWN0LnVzZURlYnVnVmFsdWUoa2V5KTtcbiAgICByZXR1cm4gdXNlU3RvcmUodGhpcywgdGhpcy5zZWxlY3RvcnNba2V5XSwgYTEsIGEyLCBhMyk7XG4gIH1cblxuICAvKipcbiAgICogV3JhcHMgYSBmdW5jdGlvbiB3aXRoIGB1c2VTdGFibGVDYWxsYmFja2AgdG8gZW5zdXJlIGl0IGhhcyBhIHN0YWJsZSByZWZlcmVuY2VcbiAgICogYW5kIGFzc2lnbnMgaXQgdG8gdGhlIGNvbnRleHQuXG4gICAqXG4gICAqIEBwYXJhbSBrZXkgS2V5IG9mIHRoZSBldmVudCBjYWxsYmFjay4gTXVzdCBiZSBhIGZ1bmN0aW9uIGluIHRoZSBjb250ZXh0LlxuICAgKiBAcGFyYW0gZm4gRnVuY3Rpb24gdG8gYXNzaWduLlxuICAgKi9cbiAgdXNlQ29udGV4dENhbGxiYWNrKGtleSwgZm4pIHtcbiAgICBSZWFjdC51c2VEZWJ1Z1ZhbHVlKGtleSk7XG4gICAgY29uc3Qgc3RhYmxlRnVuY3Rpb24gPSB1c2VTdGFibGVDYWxsYmFjayhmbiA/PyBOT09QKTtcbiAgICB0aGlzLmNvbnRleHRba2V5XSA9IHN0YWJsZUZ1bmN0aW9uO1xuICB9XG5cbiAgLyoqXG4gICAqIFJldHVybnMgYSBzdGFibGUgc2V0dGVyIGZ1bmN0aW9uIGZvciBhIHNwZWNpZmljIGtleSBpbiB0aGUgc3RvcmUncyBzdGF0ZS5cbiAgICogSXQncyBjb21tb25seSB1c2VkIHRvIHBhc3MgYXMgYSByZWYgY2FsbGJhY2sgdG8gUmVhY3QgZWxlbWVudHMuXG4gICAqXG4gICAqIEBwYXJhbSBrZXkgS2V5IG9mIHRoZSBzdGF0ZSB0byBzZXQuXG4gICAqL1xuICB1c2VTdGF0ZVNldHRlcihrZXkpIHtcbiAgICBjb25zdCByZWYgPSBSZWFjdC51c2VSZWYodW5kZWZpbmVkKTtcbiAgICBpZiAocmVmLmN1cnJlbnQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmVmLmN1cnJlbnQgPSB2YWx1ZSA9PiB7XG4gICAgICAgIHRoaXMuc2V0KGtleSwgdmFsdWUpO1xuICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIHJlZi5jdXJyZW50O1xuICB9XG5cbiAgLyoqXG4gICAqIE9ic2VydmVzIGNoYW5nZXMgZGVyaXZlZCBmcm9tIHRoZSBzdG9yZSdzIHNlbGVjdG9ycyBhbmQgY2FsbHMgdGhlIGxpc3RlbmVyIHdoZW4gdGhlIHNlbGVjdGVkIHZhbHVlIGNoYW5nZXMuXG4gICAqXG4gICAqIEBwYXJhbSBrZXkgS2V5IG9mIHRoZSBzZWxlY3RvciB0byBvYnNlcnZlLlxuICAgKiBAcGFyYW0gbGlzdGVuZXIgTGlzdGVuZXIgZnVuY3Rpb24gY2FsbGVkIHdoZW4gdGhlIHNlbGVjdG9yIHJlc3VsdCBjaGFuZ2VzLlxuICAgKi9cblxuICBvYnNlcnZlKHNlbGVjdG9yLCBsaXN0ZW5lcikge1xuICAgIGxldCBzZWxlY3RGbjtcbiAgICBpZiAodHlwZW9mIHNlbGVjdG9yID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBzZWxlY3RGbiA9IHNlbGVjdG9yO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZWxlY3RGbiA9IHRoaXMuc2VsZWN0b3JzW3NlbGVjdG9yXTtcbiAgICB9XG4gICAgbGV0IHByZXZWYWx1ZSA9IHNlbGVjdEZuKHRoaXMuc3RhdGUpO1xuICAgIGxpc3RlbmVyKHByZXZWYWx1ZSwgcHJldlZhbHVlLCB0aGlzKTtcbiAgICByZXR1cm4gdGhpcy5zdWJzY3JpYmUobmV4dFN0YXRlID0+IHtcbiAgICAgIGNvbnN0IG5leHRWYWx1ZSA9IHNlbGVjdEZuKG5leHRTdGF0ZSk7XG4gICAgICBpZiAoIU9iamVjdC5pcyhwcmV2VmFsdWUsIG5leHRWYWx1ZSkpIHtcbiAgICAgICAgY29uc3Qgb2xkVmFsdWUgPSBwcmV2VmFsdWU7XG4gICAgICAgIHByZXZWYWx1ZSA9IG5leHRWYWx1ZTtcbiAgICAgICAgbGlzdGVuZXIobmV4dFZhbHVlLCBvbGRWYWx1ZSwgdGhpcyk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbn0iLCJpbXBvcnQgeyBSZWFjdFN0b3JlIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvc3RvcmUnO1xuaW1wb3J0IHsgY3JlYXRlRXZlbnRFbWl0dGVyIH0gZnJvbSBcIi4uL3V0aWxzL2NyZWF0ZUV2ZW50RW1pdHRlci5tanNcIjtcbmltcG9ydCB7IGlzQ2xpY2tMaWtlRXZlbnQgfSBmcm9tIFwiLi4vdXRpbHMubWpzXCI7XG5jb25zdCBzZWxlY3RvcnMgPSB7XG4gIG9wZW46IHN0YXRlID0+IHN0YXRlLm9wZW4sXG4gIHRyYW5zaXRpb25TdGF0dXM6IHN0YXRlID0+IHN0YXRlLnRyYW5zaXRpb25TdGF0dXMsXG4gIGRvbVJlZmVyZW5jZUVsZW1lbnQ6IHN0YXRlID0+IHN0YXRlLmRvbVJlZmVyZW5jZUVsZW1lbnQsXG4gIHJlZmVyZW5jZUVsZW1lbnQ6IHN0YXRlID0+IHN0YXRlLnBvc2l0aW9uUmVmZXJlbmNlID8/IHN0YXRlLnJlZmVyZW5jZUVsZW1lbnQsXG4gIGZsb2F0aW5nRWxlbWVudDogc3RhdGUgPT4gc3RhdGUuZmxvYXRpbmdFbGVtZW50LFxuICBmbG9hdGluZ0lkOiBzdGF0ZSA9PiBzdGF0ZS5mbG9hdGluZ0lkXG59O1xuZXhwb3J0IGNsYXNzIEZsb2F0aW5nUm9vdFN0b3JlIGV4dGVuZHMgUmVhY3RTdG9yZSB7XG4gIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICBjb25zdCB7XG4gICAgICBzeW5jT25seSxcbiAgICAgIG5lc3RlZCxcbiAgICAgIG9uT3BlbkNoYW5nZSxcbiAgICAgIHRyaWdnZXJFbGVtZW50cyxcbiAgICAgIC4uLmluaXRpYWxTdGF0ZVxuICAgIH0gPSBvcHRpb25zO1xuICAgIHN1cGVyKHtcbiAgICAgIC4uLmluaXRpYWxTdGF0ZSxcbiAgICAgIHBvc2l0aW9uUmVmZXJlbmNlOiBpbml0aWFsU3RhdGUucmVmZXJlbmNlRWxlbWVudCxcbiAgICAgIGRvbVJlZmVyZW5jZUVsZW1lbnQ6IGluaXRpYWxTdGF0ZS5yZWZlcmVuY2VFbGVtZW50XG4gICAgfSwge1xuICAgICAgb25PcGVuQ2hhbmdlLFxuICAgICAgZGF0YVJlZjoge1xuICAgICAgICBjdXJyZW50OiB7fVxuICAgICAgfSxcbiAgICAgIGV2ZW50czogY3JlYXRlRXZlbnRFbWl0dGVyKCksXG4gICAgICBuZXN0ZWQsXG4gICAgICB0cmlnZ2VyRWxlbWVudHNcbiAgICB9LCBzZWxlY3RvcnMpO1xuICAgIHRoaXMuc3luY09ubHkgPSBzeW5jT25seTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTeW5jcyB0aGUgZXZlbnQgdXNlZCBieSBob3ZlciBsb2dpYyB0byBkaXN0aW5ndWlzaCBob3Zlci1vcGVuIGZyb20gY2xpY2stbGlrZSBpbnRlcmFjdGlvbi5cbiAgICovXG4gIHN5bmNPcGVuRXZlbnQgPSAobmV3T3BlbiwgZXZlbnQpID0+IHtcbiAgICBpZiAoIW5ld09wZW4gfHwgIXRoaXMuc3RhdGUub3BlbiB8fFxuICAgIC8vIFByZXZlbnQgYSBwZW5kaW5nIGhvdmVyLW9wZW4gZnJvbSBvdmVyd3JpdGluZyBhIGNsaWNrLW9wZW4gZXZlbnQsIHdoaWxlIGFsbG93aW5nXG4gICAgLy8gY2xpY2sgZXZlbnRzIHRvIHVwZ3JhZGUgYSBob3Zlci1vcGVuLlxuICAgIGV2ZW50ICE9IG51bGwgJiYgaXNDbGlja0xpa2VFdmVudChldmVudCkpIHtcbiAgICAgIHRoaXMuY29udGV4dC5kYXRhUmVmLmN1cnJlbnQub3BlbkV2ZW50ID0gbmV3T3BlbiA/IGV2ZW50IDogdW5kZWZpbmVkO1xuICAgIH1cbiAgfTtcblxuICAvKipcbiAgICogUnVucyB0aGUgcm9vdC1vd25lZCBzaWRlIGVmZmVjdHMgZm9yIGFuIG9wZW4gc3RhdGUgY2hhbmdlLlxuICAgKi9cbiAgZGlzcGF0Y2hPcGVuQ2hhbmdlID0gKG5ld09wZW4sIGV2ZW50RGV0YWlscykgPT4ge1xuICAgIHRoaXMuc3luY09wZW5FdmVudChuZXdPcGVuLCBldmVudERldGFpbHMuZXZlbnQpO1xuICAgIGNvbnN0IGRldGFpbHMgPSB7XG4gICAgICBvcGVuOiBuZXdPcGVuLFxuICAgICAgcmVhc29uOiBldmVudERldGFpbHMucmVhc29uLFxuICAgICAgbmF0aXZlRXZlbnQ6IGV2ZW50RGV0YWlscy5ldmVudCxcbiAgICAgIG5lc3RlZDogdGhpcy5jb250ZXh0Lm5lc3RlZCxcbiAgICAgIHRyaWdnZXJFbGVtZW50OiBldmVudERldGFpbHMudHJpZ2dlclxuICAgIH07XG4gICAgdGhpcy5jb250ZXh0LmV2ZW50cy5lbWl0KCdvcGVuY2hhbmdlJywgZGV0YWlscyk7XG4gIH07XG5cbiAgLyoqXG4gICAqIEVtaXRzIHRoZSBgb3BlbmNoYW5nZWAgZXZlbnQgdGhyb3VnaCB0aGUgaW50ZXJuYWwgZXZlbnQgZW1pdHRlciBhbmQgY2FsbHMgdGhlIGBvbk9wZW5DaGFuZ2VgIGhhbmRsZXIgd2l0aCB0aGUgcHJvdmlkZWQgYXJndW1lbnRzLlxuICAgKlxuICAgKiBAcGFyYW0gbmV3T3BlbiBUaGUgbmV3IG9wZW4gc3RhdGUuXG4gICAqIEBwYXJhbSBldmVudERldGFpbHMgRGV0YWlscyBhYm91dCB0aGUgZXZlbnQgdGhhdCB0cmlnZ2VyZWQgdGhlIG9wZW4gc3RhdGUgY2hhbmdlLlxuICAgKi9cbiAgc2V0T3BlbiA9IChuZXdPcGVuLCBldmVudERldGFpbHMpID0+IHtcbiAgICBpZiAodGhpcy5zeW5jT25seSkge1xuICAgICAgdGhpcy5jb250ZXh0Lm9uT3BlbkNoYW5nZT8uKG5ld09wZW4sIGV2ZW50RGV0YWlscyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuZGlzcGF0Y2hPcGVuQ2hhbmdlKG5ld09wZW4sIGV2ZW50RGV0YWlscyk7XG4gICAgdGhpcy5jb250ZXh0Lm9uT3BlbkNoYW5nZT8uKG5ld09wZW4sIGV2ZW50RGV0YWlscyk7XG4gIH07XG59Il0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9ub2RlX21vZHVsZXMvLnZpdGUvZGVwcy9GbG9hdGluZ1Jvb3RTdG9yZS1CTUJFUGZ4cS5qcyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5LDIwLDIxLDIyLDIzLDI0LDI1LDI2LDI3LDI4LDI5LDMwLDMxLDMyLDMzXX0=