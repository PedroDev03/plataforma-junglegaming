import { n as __exportAll, r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=e9f94b2e";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom-CRx58tZq.js?v=e9f94b2e";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-cNwuCTLA.js?v=e9f94b2e";
import { n as SafeReact, r as useIsoLayoutEffect, t as useStableCallback } from "/node_modules/.vite/deps/formatErrorMessage-BEgQI17N.js?v=e9f94b2e";
import { c as getParentNode, d as isElement, f as isHTMLElement, l as getWindow, p as isLastTraversableNode } from "/node_modules/.vite/deps/floating-ui.utils.dom-B45hE2lE.js?v=e9f94b2e";
import { $ as isTypeableElement, C as FloatingNode, Ct as stopEvent, D as useFloatingTree, Dt as android, E as useFloatingParentNodeId, Et as webkit, F as POPUP_COLLISION_AVOIDANCE, H as getTabbableNearElement, K as FocusGuard, O as FloatingTreeStore, Ot as ios, P as DROPDOWN_COLLISION_AVOIDANCE, S as useDismiss, St as isVirtualPointerEvent, T as useFloatingNodeId, Tt as voiceOver, U as isOutsideEvent, a as fastComponentRef, at as pressableTriggerOpenStateMapping, c as PopupHandleAttachment, ct as pressed$1, dt as closed$4, f as createPopupOpenState, ft as endingStyle$4, h as usePopupInteractionProps, ht as startingStyle$4, i as fastComponent, it as popupTransitionStateMapping, k as FloatingPortal, kt as mac, lt as align$3, m as useOpenStateTransitions, mt as side$3, n as ReactStore, o as PopupTriggerMap, ot as triggerOpenStateMapping, p as useImplicitActiveTrigger, pt as open$4, q as useValueAsRef, r as useStore, rt as popupStateMapping, s as FOCUSABLE_POPUP_PROPS, st as popupOpen$2, u as attachPreventUnmountOnClose, ut as anchorHidden$1, v as useTriggerDataForwarding, w as FloatingTree, x as useSyncedFloatingRootContext, y as useTriggerRegistration } from "/node_modules/.vite/deps/FloatingRootStore-BMBEPfxq.js?v=e9f94b2e";
import { n as ownerDocument, t as inertValue } from "/node_modules/.vite/deps/inertValue-DbKApsSW.js?v=e9f94b2e";
import { c as EMPTY_OBJECT, l as NOOP, n as useRenderElement, o as useMergedRefs, r as warn, s as EMPTY_ARRAY, t as unwrapLazyRenderProp, u as useRefWithInit } from "/node_modules/.vite/deps/useRenderElement-CvMw8z9e.js?v=e9f94b2e";
import { n as useTimeout } from "/node_modules/.vite/deps/useTimeout-w0MCIDxv.js?v=e9f94b2e";
import { a as transitionStatusMapping, n as useAnimationsFinished, o as endingStyle$5, r as useTransitionStatus, s as startingStyle$5, t as useOpenChangeComplete } from "/node_modules/.vite/deps/useOpenChangeComplete-BJDlY1Cs.js?v=e9f94b2e";
import { a as useClick, i as InternalBackdrop, o as FloatingFocusManager, r as useEnhancedClickHandler, t as useOpenInteractionType } from "/node_modules/.vite/deps/useOpenInteractionType-DACsa5HR.js?v=e9f94b2e";
import { c as activeElement, d as getTarget, i as getNextListIndex, n as getMaxListIndex, r as getMinListIndex, u as contains } from "/node_modules/.vite/deps/composite-DUPI88po.js?v=e9f94b2e";
import { a as useHoverFloatingInteraction, i as useHoverReferenceInteraction, n as usePopupViewport, r as safePolygon, s as useFocus, t as popupViewportStateMapping } from "/node_modules/.vite/deps/usePopupViewport-BbNw_O59.js?v=e9f94b2e";
import { T as createGenericEventDetails, _ as pointer, d as itemPress, f as keyboard, h as none, l as inputChange, n as clearPress, o as focusOut, p as listNavigation, s as imperativeAction, t as cancelOpen, u as inputClear, v as popupClose, w as createChangeEventDetails, y as siblingOpen } from "/node_modules/.vite/deps/reason-parts-D-IkPsXA.js?v=e9f94b2e";
import { t as useBaseUiId } from "/node_modules/.vite/deps/useBaseUiId-UM7l9pLZ.js?v=e9f94b2e";
import { r as mergeProps } from "/node_modules/.vite/deps/merge-props-v5iSnvoO.js?v=e9f94b2e";
import { a as BasePopupHandle, i as popupStoreSelectors, n as usePopupHandleStore, r as createInitialPopupStoreState, t as NullStore } from "/node_modules/.vite/deps/NullStore-CE4rtHXf.js?v=e9f94b2e";
import { c as useToolbarRootContext, d as isCrossOrientationOpenKey, f as isMainOrientationKey, i as stringifyAsLabel, l as useTypeahead, m as useListNavigation, o as isMouseWithinBounds, p as isMainOrientationToEndKey, s as useAnchoredPopupScrollLock, u as isCrossOrientationCloseKey } from "/node_modules/.vite/deps/resolveValueLabel-BgZlXZPw.js?v=e9f94b2e";
import { l as getDisabledMountTransitionStyles, n as usePositioner, r as useAnchorPositioning } from "/node_modules/.vite/deps/usePreviousValue-e4KgGpny.js?v=e9f94b2e";
import { n as useCompositeRootContext } from "/node_modules/.vite/deps/CompositeRootContext-CvrVHAWN.js?v=e9f94b2e";
import { n as dispatchClickWithModifiers, t as useButton } from "/node_modules/.vite/deps/useButton-DC28DUmR.js?v=e9f94b2e";
import { a as COMPOSITE_KEYS } from "/node_modules/.vite/deps/composite-BSvBzXai.js?v=e9f94b2e";
import { t as useControlled } from "/node_modules/.vite/deps/useControlled-BzU0LOuy.js?v=e9f94b2e";
import { n as useCompositeListContext } from "/node_modules/.vite/deps/CompositeListContext-CUoiOxzM.js?v=e9f94b2e";
import { t as useCompositeListItem } from "/node_modules/.vite/deps/useCompositeListItem-YDOAP90w.js?v=e9f94b2e";
import { t as useDirection } from "/node_modules/.vite/deps/DirectionContext-BppzJsM-.js?v=e9f94b2e";
import { n as CompositeList, t as isElementDisabled } from "/node_modules/.vite/deps/isElementDisabled-DqxxBdPv.js?v=e9f94b2e";
import { t as CompositeItem } from "/node_modules/.vite/deps/CompositeItem-u_K5hSwC.js?v=e9f94b2e";
import { t as Separator } from "/node_modules/.vite/deps/Separator-sMYPZS-k.js?v=e9f94b2e";
import { t as SeparatorDataAttributes_exports } from "/node_modules/.vite/deps/SeparatorDataAttributes-BfHlrb8X.js?v=e9f94b2e";
// node_modules/@base-ui/react/menu/positioner/MenuPositionerContext.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var MenuPositionerContext = /*#__PURE__*/ import_react.createContext(void 0);
MenuPositionerContext.displayName = "MenuPositionerContext";
function useMenuPositionerContext(optional) {
	const context = import_react.useContext(MenuPositionerContext);
	if (context === void 0 && !optional) throw new Error("Base UI: MenuPositionerContext is missing. MenuPositioner parts must be placed within <Menu.Positioner>.");
	return context;
}
// node_modules/@base-ui/react/menu/root/MenuRootContext.mjs
var MenuRootContext = /*#__PURE__*/ import_react.createContext(void 0);
MenuRootContext.displayName = "MenuRootContext";
function useMenuRootContext(optional) {
	const context = import_react.useContext(MenuRootContext);
	if (context === void 0 && !optional) throw new Error("Base UI: MenuRootContext is missing. Menu parts must be placed within <Menu.Root>.");
	return context;
}
// node_modules/@base-ui/react/menu/arrow/MenuArrow.mjs
/**
* Displays an element positioned against the menu anchor.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuArrow = /*#__PURE__*/ import_react.forwardRef(function MenuArrow(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const { store } = useMenuRootContext();
	const { arrowRef, side, align, arrowUncentered, arrowStyles } = useMenuPositionerContext();
	const state = {
		open: store.useState("open"),
		side,
		align,
		uncentered: arrowUncentered
	};
	return useRenderElement("div", componentProps, {
		ref: [arrowRef, forwardedRef],
		stateAttributesMapping: popupStateMapping,
		state,
		props: {
			style: arrowStyles,
			"aria-hidden": true,
			...elementProps
		}
	});
});
MenuArrow.displayName = "MenuArrow";
// node_modules/@base-ui/react/context-menu/root/ContextMenuRootContext.mjs
var ContextMenuRootContext = /*#__PURE__*/ import_react.createContext(void 0);
ContextMenuRootContext.displayName = "ContextMenuRootContext";
function useContextMenuRootContext(optional = true) {
	const context = import_react.useContext(ContextMenuRootContext);
	if (context === void 0 && !optional) throw new Error("Base UI: ContextMenuRootContext is missing. ContextMenu parts must be placed within <ContextMenu.Root>.");
	return context;
}
// node_modules/@base-ui/react/menu/backdrop/MenuBackdrop.mjs
/**
* An overlay displayed beneath the menu popup.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuBackdrop = /*#__PURE__*/ import_react.forwardRef(function MenuBackdrop(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const { store } = useMenuRootContext();
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const transitionStatus = store.useState("transitionStatus");
	const lastOpenChangeReason = store.useState("lastOpenChangeReason");
	const contextMenuContext = useContextMenuRootContext();
	const state = {
		open,
		transitionStatus
	};
	return useRenderElement("div", componentProps, {
		ref: contextMenuContext?.backdropRef ? [forwardedRef, contextMenuContext.backdropRef] : forwardedRef,
		state,
		stateAttributesMapping: popupTransitionStateMapping,
		props: [{
			role: "presentation",
			hidden: !mounted,
			style: {
				pointerEvents: lastOpenChangeReason === "trigger-hover" ? "none" : void 0,
				userSelect: "none",
				WebkitUserSelect: "none"
			}
		}, elementProps]
	});
});
MenuBackdrop.displayName = "MenuBackdrop";
// node_modules/@base-ui/react/menu/filter-root/MenuFilterContext.mjs
/**
* The filter implementation that a filterable root hands to the parts below it. Only the roots
* `Menu.FilterProvider` renders import it, so a plain menu never bundles it. Parts whose whole
* structure differs are swapped as components; parts that only register with the filter call an
* injected hook, so a menu that never renders them doesn't bundle a second implementation.
*/
/** Static below a filter root: the implementation never changes, so subscribers never re-render. */
var MenuFilterImplContext = /*#__PURE__*/ import_react.createContext(null);
MenuFilterImplContext.displayName = "MenuFilterImplContext";
/**
* The filter implementation when the menu this part belongs to is filterable, otherwise `null`.
* `virtualFocus` marks a filter root; a plain `Menu.Root` never sets it. The result is fixed for
* a mounted part: a filter root can't appear above it without remounting it.
*/
function useMenuFilterImpl(scope = "root") {
	const impl = import_react.useContext(MenuFilterImplContext);
	const root = import_react.useContext(MenuRootContext);
	if (impl === null || root === void 0) return null;
	return (scope === "submenu-trigger" ? root.virtualFocus || root.parentVirtualFocus : root.virtualFocus) ? impl : null;
}
/**
* Throws unless the menu this part renders in is filterable, naming the part and the provider.
*/
function useMenuFilterPart(part) {
	if (useMenuFilterImpl() === null) throw new Error(`Base UI: <Menu.${part}> must be placed in a menu wrapped in <Menu.FilterProvider>. It reads the filter query and the matching items from the provider, which a plain menu does not have. Wrap the <Menu.Root> or <Menu.SubmenuRoot> it belongs to in <Menu.FilterProvider>. See https://base-ui.com/react/components/menu#filtering`);
}
var UNFILTERED = {
	visible: true,
	ref: null
};
function useUnfilteredItem() {
	return UNFILTERED;
}
/**
* Registers an item part with the filter of the menu it belongs to. A plain menu's items are
* always visible.
*/
function useMenuFilterItem(props, forwardedRef, scope = "root") {
	const impl = useMenuFilterImpl(scope);
	const item = ((scope === "submenu-trigger" ? impl?.useSubmenuTrigger : impl?.useItem) ?? useUnfilteredItem)({
		label: props.label,
		children: props.children,
		render: props.render
	});
	const ref = useMergedRefs(forwardedRef, item.ref);
	return {
		visible: item.visible,
		ref,
		props: item.props
	};
}
// node_modules/@base-ui/react/menu/checkbox-item/MenuCheckboxItemContext.mjs
var MenuCheckboxItemContext = /*#__PURE__*/ import_react.createContext(void 0);
MenuCheckboxItemContext.displayName = "MenuCheckboxItemContext";
function useMenuCheckboxItemContext() {
	const context = import_react.useContext(MenuCheckboxItemContext);
	if (context === void 0) throw new Error("Base UI: MenuCheckboxItemContext is missing. MenuCheckboxItem parts must be placed within <Menu.CheckboxItem>.");
	return context;
}
// node_modules/@base-ui/react/menu/item/useMenuItemCommonProps.mjs
function preventMouseDownDefault(event) {
	event.preventDefault();
}
/**
* Returns common props shared by all menu item types.
* This hook extracts the shared logic for id, role, tabIndex, and interaction handlers.
*/
function useMenuItemCommonProps(params) {
	const { closeOnClick, highlighted, id, nodeId, store, typingRef, itemRef, itemMetadata } = params;
	const rootContext = useMenuRootContext();
	const contextMenuContext = useContextMenuRootContext(true);
	const isSubmenuTrigger = itemMetadata.type === "submenu-trigger";
	const virtualFocus = isSubmenuTrigger ? rootContext.parentVirtualFocus : rootContext.virtualFocus;
	const ariaSelected = (isSubmenuTrigger && rootContext.parent.type === "menu" ? rootContext.parent.store : rootContext.store).useState("webkitAriaSelected", highlighted);
	const { events: menuEvents } = store.useState("floatingTreeRoot");
	const open = store.useState("open");
	const isContextMenu = contextMenuContext !== void 0;
	const tabIndex = !virtualFocus && open && highlighted ? 0 : -1;
	return import_react.useMemo(() => ({
		id,
		role: "menuitem",
		tabIndex,
		"aria-selected": ariaSelected,
		onMouseDown: virtualFocus ? preventMouseDownDefault : void 0,
		onKeyDown(event) {
			if (event.key === " " && typingRef?.current) event.preventDefault();
		},
		onMouseMove(event) {
			if (!nodeId) return;
			menuEvents.emit("itemhover", {
				nodeId,
				target: event.currentTarget
			});
		},
		onClick(event) {
			if (closeOnClick) menuEvents.emit("close", {
				domEvent: event.nativeEvent,
				reason: itemPress
			});
		},
		onMouseUp(event) {
			if (contextMenuContext) {
				const initialCursorPoint = contextMenuContext.initialCursorPointRef.current;
				contextMenuContext.initialCursorPointRef.current = null;
				if (isContextMenu && initialCursorPoint && Math.abs(event.clientX - initialCursorPoint.x) <= 1 && Math.abs(event.clientY - initialCursorPoint.y) <= 1) return;
				if (isContextMenu && !mac && event.button === 2) return;
			}
			if (itemRef.current && store.context.allowMouseUpTriggerRef.current && (!isContextMenu || event.button === 2)) {
				if (itemMetadata.type === "regular-item") dispatchClickWithModifiers(itemRef.current, event, {
					detail: 1,
					pointerType: "mouse"
				});
			}
		}
	}), [
		closeOnClick,
		tabIndex,
		id,
		menuEvents,
		nodeId,
		store.context.allowMouseUpTriggerRef,
		typingRef,
		itemRef,
		contextMenuContext,
		isContextMenu,
		itemMetadata.type,
		ariaSelected,
		virtualFocus
	]);
}
// node_modules/@base-ui/react/menu/item/useMenuItem.mjs
var REGULAR_ITEM = { type: "regular-item" };
function useMenuItem(params) {
	const { closeOnClick, disabled, highlighted, id, store, typingRef = store.context.typingRef, nativeButton, itemMetadata, nodeId } = params;
	const itemRef = import_react.useRef(null);
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		focusableWhenDisabled: true,
		native: nativeButton,
		composite: true
	});
	const commonProps = useMenuItemCommonProps({
		closeOnClick,
		highlighted,
		id,
		nodeId,
		store,
		typingRef,
		itemRef,
		itemMetadata
	});
	const getItemProps = import_react.useCallback((externalProps) => {
		return mergeProps(commonProps, { onMouseEnter(event) {
			if (itemMetadata.type !== "submenu-trigger") return;
			itemMetadata.setActive(event.nativeEvent);
		} }, externalProps, getButtonProps);
	}, [
		commonProps,
		getButtonProps,
		itemMetadata
	]);
	const mergedRef = useMergedRefs(itemRef, buttonRef);
	return import_react.useMemo(() => ({
		getItemProps,
		itemRef: mergedRef
	}), [getItemProps, mergedRef]);
}
// node_modules/@base-ui/react/menu/checkbox-item/MenuCheckboxItemDataAttributes.mjs
var MenuCheckboxItemDataAttributes_exports = /* @__PURE__ */ __exportAll({
	checked: () => checked$3,
	disabled: () => disabled$7,
	highlighted: () => highlighted$5,
	unchecked: () => unchecked$3
});
/**
* Present when the menu checkbox item is checked.
*/
var checked$3 = "data-checked";
/**
* Present when the menu checkbox item is not checked.
*/
var unchecked$3 = "data-unchecked";
/**
* Present when the menu checkbox item is disabled.
*/
var disabled$7 = "data-disabled";
/**
* Present when the menu checkbox item is highlighted.
*/
var highlighted$5 = "data-highlighted";
// node_modules/@base-ui/react/menu/utils/stateAttributesMapping.mjs
var itemMapping = {
	checked(value) {
		if (value) return { [checked$3]: "" };
		return { [unchecked$3]: "" };
	},
	...transitionStatusMapping
};
// node_modules/@base-ui/react/menu/checkbox-item/MenuCheckboxItem.mjs
var import_jsx_runtime = require_jsx_runtime();
var MenuCheckboxItemPlain = /*#__PURE__*/ import_react.forwardRef(function MenuCheckboxItemPlain(componentProps, forwardedRef) {
	const { render, className, id: idProp, label, nativeButton = false, disabled: disabledProp = false, closeOnClick = false, checked = false, onCheckedChange, style, ...elementProps } = componentProps;
	const { store } = useMenuRootContext();
	const listItem = useCompositeListItem({
		guess: true,
		label
	});
	const id = useBaseUiId(idProp);
	const rootDisabled = store.useState("disabled");
	const highlighted = store.useState("isActive", listItem.index);
	const nodeId = store.useState("floatingNodeId");
	const itemProps = store.useState("itemProps");
	const disabled = disabledProp || rootDisabled;
	const { getItemProps, itemRef } = useMenuItem({
		closeOnClick,
		disabled,
		highlighted,
		id,
		store,
		nativeButton,
		nodeId,
		itemMetadata: REGULAR_ITEM
	});
	const state = import_react.useMemo(() => ({
		disabled,
		highlighted,
		checked
	}), [
		disabled,
		highlighted,
		checked
	]);
	function handleClick(event) {
		const details = createChangeEventDetails(itemPress, event.nativeEvent, void 0, { preventUnmountOnClose: NOOP });
		onCheckedChange?.(!checked, details);
	}
	const element = useRenderElement("div", componentProps, {
		state,
		stateAttributesMapping: itemMapping,
		props: [
			itemProps,
			{
				role: "menuitemcheckbox",
				"aria-checked": checked,
				onClick: handleClick
			},
			elementProps,
			getItemProps
		],
		ref: [
			itemRef,
			forwardedRef,
			listItem.ref
		]
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuCheckboxItemContext.Provider, {
		value: state,
		children: element
	});
});
MenuCheckboxItemPlain.displayName = "MenuCheckboxItemPlain";
var MenuCheckboxItem = /*#__PURE__*/ import_react.forwardRef(function MenuCheckboxItem(props, forwardedRef) {
	const { checked: checkedProp, defaultChecked, onCheckedChange, ...plainProps } = props;
	const [checked, setChecked] = useControlled({
		controlled: checkedProp,
		default: defaultChecked ?? false,
		name: "MenuCheckboxItem",
		state: "checked"
	});
	const filterItem = useMenuFilterItem(props, forwardedRef);
	function handleCheckedChange(nextChecked, eventDetails) {
		onCheckedChange?.(nextChecked, eventDetails);
		if (!eventDetails.isCanceled) setChecked(nextChecked);
	}
	if (!filterItem.visible) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuCheckboxItemPlain, {
		...plainProps,
		checked,
		onCheckedChange: handleCheckedChange,
		ref: filterItem.ref
	});
});
MenuCheckboxItem.displayName = "MenuCheckboxItem";
// node_modules/@base-ui/react/menu/checkbox-item-indicator/MenuCheckboxItemIndicator.mjs
/**
* Indicates whether the checkbox item is ticked.
* Renders a `<span>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuCheckboxItemIndicator = /*#__PURE__*/ import_react.forwardRef(function MenuCheckboxItemIndicator(componentProps, forwardedRef) {
	const { render, className, style, keepMounted = false, ...elementProps } = componentProps;
	const item = useMenuCheckboxItemContext();
	const indicatorRef = import_react.useRef(null);
	const { transitionStatus, mounted, setMounted } = useTransitionStatus(item.checked);
	useOpenChangeComplete({
		batch: true,
		enabled: !item.checked,
		open: item.checked,
		ref: indicatorRef,
		onComplete() {
			if (!item.checked) setMounted(false);
		}
	});
	const state = {
		checked: item.checked,
		disabled: item.disabled,
		highlighted: item.highlighted,
		transitionStatus
	};
	return useRenderElement("span", componentProps, {
		state,
		ref: [forwardedRef, indicatorRef],
		stateAttributesMapping: itemMapping,
		props: {
			"aria-hidden": true,
			...elementProps
		},
		enabled: keepMounted || mounted
	});
});
MenuCheckboxItemIndicator.displayName = "MenuCheckboxItemIndicator";
// node_modules/@base-ui/react/menu/group/MenuGroupContext.mjs
var MenuGroupContext = /*#__PURE__*/ import_react.createContext(void 0);
MenuGroupContext.displayName = "MenuGroupContext";
function useMenuGroupRootContext() {
	const context = import_react.useContext(MenuGroupContext);
	if (context === void 0) throw new Error("Base UI: MenuGroupContext is missing. Menu group parts must be used within <Menu.Group> or <Menu.RadioGroup>.");
	return context;
}
// node_modules/@base-ui/react/menu/group/MenuGroup.mjs
/**
* @internal
*/
var MenuGroupPlain = /*#__PURE__*/ import_react.forwardRef(function MenuGroupPlain(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const [labelId, setLabelId] = import_react.useState(void 0);
	const element = useRenderElement("div", componentProps, {
		ref: forwardedRef,
		props: {
			role: "group",
			"aria-labelledby": labelId,
			...elementProps
		}
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuGroupContext.Provider, {
		value: setLabelId,
		children: element
	});
});
MenuGroupPlain.displayName = "MenuGroupPlain";
var MenuGroup = /*#__PURE__*/ import_react.forwardRef(function MenuGroup(props, forwardedRef) {
	const Group = useMenuFilterImpl()?.Group ?? MenuGroupPlain;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(Group, {
		...props,
		ref: forwardedRef
	});
});
MenuGroup.displayName = "MenuGroup";
// node_modules/@base-ui/react/menu/group-label/MenuGroupLabel.mjs
/**
* An accessible label that is automatically associated with its parent group.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuGroupLabel = /*#__PURE__*/ import_react.forwardRef(function MenuGroupLabel(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, ...elementProps } = componentProps;
	const id = useBaseUiId(idProp);
	const setLabelId = useMenuGroupRootContext();
	useIsoLayoutEffect(() => {
		setLabelId(id);
		return () => {
			setLabelId((currentId) => currentId === id ? void 0 : currentId);
		};
	}, [setLabelId, id]);
	return useRenderElement("div", componentProps, {
		ref: forwardedRef,
		props: {
			id,
			"aria-hidden": true,
			...elementProps
		}
	});
});
MenuGroupLabel.displayName = "MenuGroupLabel";
// node_modules/@base-ui/react/menu/item/MenuItem.mjs
var MenuItemPlain = /*#__PURE__*/ import_react.forwardRef(function MenuItemPlain(componentProps, forwardedRef) {
	const { render, className, id: idProp, label, nativeButton = false, disabled: disabledProp = false, closeOnClick = true, style, ...elementProps } = componentProps;
	const { store } = useMenuRootContext();
	const listItem = useCompositeListItem({
		guess: true,
		label
	});
	const id = useBaseUiId(idProp);
	const rootDisabled = store.useState("disabled");
	const highlighted = store.useState("isActive", listItem.index);
	const nodeId = store.useState("floatingNodeId");
	const itemProps = store.useState("itemProps");
	const disabled = disabledProp || rootDisabled;
	const { getItemProps, itemRef } = useMenuItem({
		closeOnClick,
		disabled,
		highlighted,
		id,
		store,
		nativeButton,
		nodeId,
		itemMetadata: REGULAR_ITEM
	});
	return useRenderElement("div", componentProps, {
		state: {
			disabled,
			highlighted
		},
		props: [
			itemProps,
			elementProps,
			getItemProps
		],
		ref: [
			itemRef,
			forwardedRef,
			listItem.ref
		]
	});
});
MenuItemPlain.displayName = "MenuItemPlain";
var MenuItem = /*#__PURE__*/ import_react.forwardRef(function MenuItem(props, forwardedRef) {
	const filterItem = useMenuFilterItem(props, forwardedRef);
	if (!filterItem.visible) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuItemPlain, {
		...props,
		ref: filterItem.ref
	});
});
MenuItem.displayName = "MenuItem";
// node_modules/@base-ui/react/menu/link-item/MenuLinkItem.mjs
var MenuLinkItemPlain = /*#__PURE__*/ import_react.forwardRef(function MenuLinkItemPlain(componentProps, forwardedRef) {
	const { render, className, id: idProp, label, closeOnClick = false, style, ...elementProps } = componentProps;
	const { store } = useMenuRootContext();
	const linkRef = import_react.useRef(null);
	const listItem = useCompositeListItem({
		guess: true,
		label
	});
	const id = useBaseUiId(idProp);
	const highlighted = store.useState("isActive", listItem.index);
	const nodeId = store.useState("floatingNodeId");
	const itemProps = store.useState("itemProps");
	const typingRef = store.context.typingRef;
	const { getButtonProps, buttonRef } = useButton({
		native: false,
		composite: true
	});
	const commonProps = useMenuItemCommonProps({
		closeOnClick,
		highlighted,
		id,
		nodeId,
		store,
		typingRef,
		itemRef: linkRef,
		itemMetadata: REGULAR_ITEM
	});
	function getItemProps(externalProps) {
		return mergeProps(commonProps, externalProps, getButtonProps);
	}
	return useRenderElement("a", componentProps, {
		state: { highlighted },
		props: [
			itemProps,
			elementProps,
			getItemProps
		],
		ref: [
			linkRef,
			buttonRef,
			forwardedRef,
			listItem.ref
		]
	});
});
MenuLinkItemPlain.displayName = "MenuLinkItemPlain";
var MenuLinkItem = /*#__PURE__*/ import_react.forwardRef(function MenuLinkItem(props, forwardedRef) {
	const filterItem = useMenuFilterItem(props, forwardedRef);
	if (!filterItem.visible) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuLinkItemPlain, {
		...props,
		ref: filterItem.ref
	});
});
MenuLinkItem.displayName = "MenuLinkItem";
// node_modules/@base-ui/react/menu/submenu-root/MenuSubmenuRootContext.mjs
var MenuSubmenuRootContext = /*#__PURE__*/ import_react.createContext(void 0);
MenuSubmenuRootContext.displayName = "MenuSubmenuRootContext";
function useMenuSubmenuRootContext() {
	return import_react.useContext(MenuSubmenuRootContext);
}
// node_modules/@base-ui/react/internals/resolveRenderedId.mjs
/**
* Resolves an element's id using the same precedence as `useRenderElement`.
* Returns `''` when the element renders with an explicitly empty id, which consumers must treat
* as "no id" rather than falling back to the generated one, so ARIA relationships never reference
* an id no element carries. Render callbacks are opaque and are expected to use the id passed to
* them.
*
* @internal
*/
function resolveRenderedId(props, fallbackId) {
	const render = unwrapLazyRenderProp(props.render);
	if (/*#__PURE__*/ import_react.isValidElement(render)) {
		const renderProps = render.props;
		if (Object.hasOwn(renderProps, "id")) return renderProps.id ?? "";
	}
	return props.id ?? fallbackId;
}
/**
* Resolves the element's id and returns a ref that publishes it to the owner while mounted.
* A generated fallback is never published as an override, so removing an explicit id lets the
* element return to the generated one.
*
* @internal
*/
function useRenderedId(props, defaultId, setId) {
	const id = resolveRenderedId(props, defaultId);
	const registeredId = id === defaultId ? void 0 : id;
	return [id, import_react.useCallback((element) => setId?.(element ? registeredId : void 0), [registeredId, setId])];
}
// node_modules/@base-ui/react/internals/resolvePopupLabel.mjs
function resolvePopupLabel(props, activeTriggerElement, activeTriggerId) {
	const render = unwrapLazyRenderProp(props.render);
	const renderedElementProps = /*#__PURE__*/ import_react.isValidElement(render) ? render.props : void 0;
	const ariaLabel = props["aria-label"] ?? renderedElementProps?.["aria-label"];
	let ariaLabelledBy = props["aria-labelledby"] ?? renderedElementProps?.["aria-labelledby"];
	if (ariaLabelledBy == null && !ariaLabel) ariaLabelledBy = activeTriggerElement ? activeTriggerElement.id || void 0 : activeTriggerId || void 0;
	return ariaLabelledBy;
}
// node_modules/@base-ui/react/menu/popup/MenuPopup.mjs
/**
* @internal
*/
var MenuPopupPlain = /*#__PURE__*/ import_react.forwardRef(function MenuPopupPlain(componentProps, forwardedRef) {
	const { render, className, style, finalFocus, id: idProp, initialFocus: initialFocusProp, ...elementProps } = componentProps;
	const { store, defaultFloatingId, setRenderedFloatingId, virtualFocus, orientation } = useMenuRootContext();
	const inheritedSubmenuRootContext = useMenuSubmenuRootContext();
	const { side, align } = useMenuPositionerContext();
	const insideToolbar = useToolbarRootContext(true) != null;
	const open = store.useState("open");
	const transitionStatus = store.useState("transitionStatus");
	const popupProps = store.useState("popupProps");
	const mounted = store.useState("mounted");
	const instantType = store.useState("instantType");
	const activeTriggerElement = store.useState("activeTriggerElement");
	const parent = store.useState("parent");
	const lastOpenChangeReason = store.useState("lastOpenChangeReason");
	const rootId = store.useState("rootId");
	const floatingContext = store.useState("floatingRootContext");
	const floatingTreeRoot = store.useState("floatingTreeRoot");
	const closeDelay = store.useState("closeDelay");
	const hoverEnabled = store.useState("hoverEnabled");
	const disabled = store.useState("disabled");
	const openMethod = store.useState("openMethod");
	const activeTriggerId = store.useState("activeTriggerId");
	const listElement = store.useState("listElement");
	const [id, registerIdRef] = useRenderedId(componentProps, defaultFloatingId, setRenderedFloatingId);
	const ariaLabelledBy = resolvePopupLabel(componentProps, activeTriggerElement, activeTriggerId);
	const submenuRootContext = parent.type === "menu" ? inheritedSubmenuRootContext : void 0;
	const isContextMenu = parent.type === "context-menu";
	let initialFocus = initialFocusProp ?? parent.type !== "menu";
	if (initialFocusProp === void 0 && listElement && parent.type !== "menu") initialFocus = () => {
		if (store.state.activeIndex !== null) return false;
		return listElement;
	};
	useOpenChangeComplete({
		open,
		ref: store.context.popupRef,
		onComplete() {
			if (open) store.context.onOpenChangeComplete?.(true);
		}
	});
	import_react.useEffect(() => {
		function handleClose(event) {
			store.setOpen(false, createChangeEventDetails(event.reason, event.domEvent));
		}
		floatingTreeRoot.events.on("close", handleClose);
		return () => {
			floatingTreeRoot.events.off("close", handleClose);
		};
	}, [floatingTreeRoot.events, store]);
	useHoverFloatingInteraction(floatingContext, {
		enabled: hoverEnabled && !disabled && !isContextMenu && parent.type !== "menubar",
		closeDelay
	});
	const setPopupElement = store.useStateSetter("popupElement");
	const { parentVirtualFocusRef, handleFocus } = (import_react.useContext(MenuFilterImplContext)?.useParentHandoff ?? useNoParentHandoff)(store, parent, open, virtualFocus);
	const state = {
		transitionStatus,
		side,
		align,
		open,
		nested: parent.type === "menu",
		instant: instantType
	};
	const element = useRenderElement("div", componentProps, {
		state,
		ref: [
			forwardedRef,
			store.context.popupRef,
			setPopupElement,
			registerIdRef
		],
		stateAttributesMapping: popupTransitionStateMapping,
		props: [
			popupProps,
			{
				id,
				...listElement ? { role: "presentation" } : {
					role: "menu",
					"aria-orientation": orientation === "horizontal" ? "horizontal" : void 0,
					"aria-labelledby": ariaLabelledBy
				},
				onKeyDown(event) {
					submenuRootContext?.onPopupKeyDown?.(event);
					if (insideToolbar && COMPOSITE_KEYS.has(event.key)) event.stopPropagation();
				},
				onFocus: handleFocus
			},
			getDisabledMountTransitionStyles(transitionStatus),
			elementProps,
			{ "data-rootownerid": rootId }
		]
	});
	let returnFocus = parent.type === void 0 || isContextMenu;
	if (activeTriggerElement || parent.type === "menubar" && lastOpenChangeReason !== "outside-press") returnFocus = true;
	const dynamicReturnFocus = submenuRootContext?.getReturnElement ?? parentVirtualFocusRef;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingFocusManager, {
		context: floatingContext,
		openInteractionType: openMethod,
		modal: isContextMenu,
		disabled: !mounted,
		returnFocus: finalFocus ?? dynamicReturnFocus ?? returnFocus,
		explicitReturnFocus: finalFocus === void 0 && dynamicReturnFocus ? false : void 0,
		initialFocus,
		restoreFocus: true,
		getInsideElements: parent.type === void 0 ? () => [store.context.beforeTriggerFocusGuardRef.current] : void 0,
		externalTree: parent.type !== "menubar" ? floatingTreeRoot : void 0,
		previousFocusableElement: activeTriggerElement,
		nextFocusableElement: parent.type === void 0 ? store.context.triggerFocusTargetRef : void 0,
		beforeContentFocusGuardRef: store.context.beforeContentFocusGuardRef,
		children: element
	});
});
MenuPopupPlain.displayName = "MenuPopupPlain";
var NO_PARENT_HANDOFF = {
	parentVirtualFocusRef: void 0,
	handleFocus: void 0
};
function useNoParentHandoff() {
	return NO_PARENT_HANDOFF;
}
/**
* A container for the menu items.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuPopup = /*#__PURE__*/ import_react.forwardRef(function MenuPopup(props, forwardedRef) {
	const Popup = useMenuFilterImpl()?.Popup ?? MenuPopupPlain;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(Popup, {
		...props,
		ref: forwardedRef
	});
});
MenuPopup.displayName = "MenuPopup";
// node_modules/@base-ui/react/menu/portal/MenuPortalContext.mjs
var MenuPortalContext = /*#__PURE__*/ import_react.createContext(void 0);
MenuPortalContext.displayName = "MenuPortalContext";
function useMenuPortalContext() {
	const value = import_react.useContext(MenuPortalContext);
	if (value === void 0) throw new Error("Base UI: <Menu.Portal> is missing.");
	return value;
}
// node_modules/@base-ui/react/menu/portal/MenuPortal.mjs
/**
* A portal element that moves the popup to a different part of the DOM.
* By default, the portal element is appended to `<body>`.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuPortal = /*#__PURE__*/ import_react.forwardRef(function MenuPortal(props, forwardedRef) {
	const { keepMounted = false, ...portalProps } = props;
	const { store, parent } = useMenuRootContext();
	if (!(store.useState("mounted") || keepMounted)) return null;
	const portalOwnerRole = parent.type === "menu" || parent.type === "menubar" ? "group" : void 0;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuPortalContext.Provider, {
		value: keepMounted,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingPortal, {
			ref: forwardedRef,
			...portalProps,
			portalOwnerRole
		})
	});
});
MenuPortal.displayName = "MenuPortal";
// node_modules/@base-ui/react/internals/useTriggerSwitchTransition.mjs
/**
* Popover and Menu declare different `instantType` unions, so only the members
* this hook touches are typed.
*/
/**
* Lets the positioner animate while a popup moves between detached triggers.
*
* The positioner is normally marked instant, so a hand-off from one trigger to
* another would teleport. Clearing `instantType` for the duration of the move
* lets it transition, and `trigger-change` is restored once the move finishes.
*
* The restoration is deferred until the move's animations finish, so it can
* outlive the move that scheduled it. The trigger element is retained through
* the exit transition, so a close alone does not change `domReference` and
* nothing would otherwise re-run this effect to abort it — a popup that closes
* and reopens on the same trigger mid-exit would inherit the stale callback and
* lose its own transition. Closing therefore cancels the pending restoration
* explicitly.
*
* Applying `trigger-change` to a closed popup is prevented separately, by the
* stores' `instantType` selector, since a controlled `open={false}` commit
* reaches the popup without passing through `setOpen`.
*/
function useTriggerSwitchTransition(parameters) {
	const { store, domReference, positionerElement, open } = parameters;
	const previousTriggerRef = import_react.useRef(null);
	const pendingSwitchRef = import_react.useRef(null);
	const runOnceAnimationsFinish = useAnimationsFinished(positionerElement);
	useIsoLayoutEffect(() => {
		if (open) return;
		pendingSwitchRef.current?.abort();
		pendingSwitchRef.current = null;
		if (store.state.instantType === "trigger-change") store.set("instantType", void 0);
	}, [open, store]);
	useIsoLayoutEffect(() => {
		const currentTrigger = domReference;
		const previousTrigger = previousTriggerRef.current;
		if (currentTrigger) previousTriggerRef.current = currentTrigger;
		if (!previousTrigger || !currentTrigger || currentTrigger === previousTrigger) return;
		if (!store.select("open")) return;
		store.set("instantType", void 0);
		const abortController = new AbortController();
		pendingSwitchRef.current = abortController;
		runOnceAnimationsFinish(() => {
			if (store.select("open")) store.set("instantType", "trigger-change");
		}, abortController.signal);
		return () => {
			abortController.abort();
		};
	}, [
		domReference,
		runOnceAnimationsFinish,
		store
	]);
}
// node_modules/@base-ui/react/menu/positioner/MenuPositioner.mjs
/**
* Positions the menu popup against the trigger.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuPositioner = /*#__PURE__*/ import_react.forwardRef(function MenuPositioner(componentProps, forwardedRef) {
	const { anchor: anchorProp, positionMethod: positionMethodProp = "absolute", className, render, side, align: alignProp, sideOffset: sideOffsetProp = 0, alignOffset: alignOffsetProp = 0, collisionBoundary = "clipping-ancestors", collisionPadding = 5, arrowPadding = 5, sticky = false, disableAnchorTracking = false, collisionAvoidance: collisionAvoidanceProp = DROPDOWN_COLLISION_AVOIDANCE, style, ...elementProps } = componentProps;
	const { store, virtualFocus, syncHighlightedItem } = useMenuRootContext();
	const keepMounted = useMenuPortalContext();
	const contextMenuContext = useContextMenuRootContext(true);
	const parent = store.useState("parent");
	const floatingRootContext = store.useState("floatingRootContext");
	const floatingTreeRoot = store.useState("floatingTreeRoot");
	const mounted = store.useState("mounted");
	const open = store.useState("open");
	const modal = store.useState("modal");
	const openMethod = store.useState("openMethod");
	const triggerElement = store.useState("activeTriggerElement");
	const transitionStatus = store.useState("transitionStatus");
	const positionerElement = store.useState("positionerElement");
	const instantType = store.useState("instantType");
	const adaptiveOrigin = store.useState("adaptiveOrigin");
	const lastOpenChangeReason = store.useState("lastOpenChangeReason");
	const floatingNodeId = store.useState("floatingNodeId");
	const floatingParentNodeId = store.useState("floatingParentNodeId");
	const domReference = floatingRootContext.useState("domReferenceElement");
	let anchor = anchorProp;
	let sideOffset = sideOffsetProp;
	let alignOffset = alignOffsetProp;
	let align = alignProp;
	let collisionAvoidance = collisionAvoidanceProp;
	if (parent.type === "context-menu") {
		anchor = anchorProp ?? parent.context?.anchor;
		align = align ?? "start";
		if (!side && align !== "center") {
			alignOffset = componentProps.alignOffset ?? 2;
			sideOffset = componentProps.sideOffset ?? -5;
		}
	}
	let computedSide = side;
	let computedAlign = align;
	if (parent.type === "menu") {
		computedSide = computedSide ?? "inline-end";
		computedAlign = computedAlign ?? "start";
		collisionAvoidance = componentProps.collisionAvoidance ?? POPUP_COLLISION_AVOIDANCE;
	} else if (parent.type === "menubar") {
		computedSide = computedSide ?? (parent.context.orientation === "vertical" ? "inline-end" : "bottom");
		computedAlign = computedAlign ?? "start";
	}
	const contextMenu = parent.type === "context-menu";
	const positioner = useAnchorPositioning({
		anchor,
		floatingRootContext,
		positionMethod: contextMenuContext ? "fixed" : positionMethodProp,
		mounted,
		side: computedSide,
		sideOffset,
		align: computedAlign,
		alignOffset,
		arrowPadding: contextMenu ? 0 : arrowPadding,
		collisionBoundary,
		collisionPadding,
		sticky,
		nodeId: floatingNodeId,
		keepMounted,
		disableAnchorTracking,
		collisionAvoidance,
		shift: contextMenu ? {
			crossAxis: !("side" in collisionAvoidance && collisionAvoidance.side === "flip"),
			rootBoundary: "layoutViewport"
		} : void 0,
		externalTree: floatingTreeRoot,
		adaptiveOrigin,
		lazyFlip: virtualFocus ? "placement" : false
	});
	import_react.useEffect(() => {
		function onMenuOpenChange(details) {
			if (details.open) {
				if (details.parentNodeId === floatingNodeId) store.set("hoverEnabled", false);
				if (details.nodeId !== floatingNodeId && details.parentNodeId === store.select("floatingParentNodeId")) store.setOpen(false, createChangeEventDetails(siblingOpen));
			}
		}
		floatingTreeRoot.events.on("menuopenchange", onMenuOpenChange);
		return () => {
			floatingTreeRoot.events.off("menuopenchange", onMenuOpenChange);
		};
	}, [
		store,
		floatingTreeRoot.events,
		floatingNodeId
	]);
	import_react.useEffect(() => {
		if (store.select("floatingParentNodeId") == null) return;
		function onParentClose(details) {
			if (details.open || details.nodeId !== store.select("floatingParentNodeId")) return;
			const reason = details.reason ?? "sibling-open";
			store.setOpen(false, createChangeEventDetails(reason));
		}
		floatingTreeRoot.events.on("menuopenchange", onParentClose);
		return () => {
			floatingTreeRoot.events.off("menuopenchange", onParentClose);
		};
	}, [floatingTreeRoot.events, store]);
	const closeTimeout = useTimeout();
	import_react.useEffect(() => {
		if (!open) closeTimeout.clear();
	}, [open, closeTimeout]);
	import_react.useEffect(() => {
		function onItemHover(event) {
			if (!open || event.nodeId !== store.select("floatingParentNodeId")) return;
			if (event.target && triggerElement && triggerElement !== event.target) {
				const delay = store.select("closeDelay");
				if (delay > 0) {
					if (!closeTimeout.isStarted()) closeTimeout.start(delay, () => {
						store.setOpen(false, createChangeEventDetails(siblingOpen));
					});
				} else store.setOpen(false, createChangeEventDetails(siblingOpen));
			} else closeTimeout.clear();
		}
		floatingTreeRoot.events.on("itemhover", onItemHover);
		return () => {
			floatingTreeRoot.events.off("itemhover", onItemHover);
		};
	}, [
		floatingTreeRoot.events,
		open,
		triggerElement,
		store,
		closeTimeout
	]);
	import_react.useEffect(() => {
		const eventDetails = {
			open,
			nodeId: floatingNodeId,
			parentNodeId: floatingParentNodeId,
			reason: store.select("lastOpenChangeReason")
		};
		floatingTreeRoot.events.emit("menuopenchange", eventDetails);
	}, [
		floatingTreeRoot.events,
		open,
		store,
		floatingNodeId,
		floatingParentNodeId
	]);
	useTriggerSwitchTransition({
		store,
		domReference,
		positionerElement,
		open
	});
	const state = {
		open,
		side: positioner.side,
		align: positioner.align,
		anchorHidden: positioner.anchorHidden,
		nested: parent.type === "menu",
		instant: instantType
	};
	const menubarModal = parent.type === "menubar" && parent.context.modal;
	useAnchoredPopupScrollLock(open && (menubarModal || modal && lastOpenChangeReason !== "trigger-hover"), openMethod === "touch", positionerElement, triggerElement);
	const element = usePositioner(componentProps, state, {
		styles: positioner.positionerStyles,
		transitionStatus,
		props: elementProps,
		refs: [forwardedRef, store.useStateSetter("positionerElement")],
		hidden: !mounted,
		inert: !open
	});
	const shouldRenderBackdrop = mounted && parent.type !== "menu" && (parent.type !== "menubar" && modal && lastOpenChangeReason !== "trigger-hover" || parent.type === "menubar" && parent.context.modal);
	let backdropCutout = null;
	if (parent.type === "menubar") backdropCutout = parent.context.contentElement;
	else if (parent.type === void 0) backdropCutout = triggerElement;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(MenuPositionerContext.Provider, {
		value: positioner,
		children: [shouldRenderBackdrop && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(InternalBackdrop, {
			ref: parent.type === "context-menu" || parent.type === "nested-context-menu" ? parent.context.internalBackdropRef : null,
			inert: inertValue(!open),
			cutout: backdropCutout
		}), /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingNode, {
			id: floatingNodeId,
			children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeList, {
				elementsRef: store.context.itemDomElements,
				labelsRef: store.context.itemLabels,
				onMapChange: syncHighlightedItem,
				children: element
			})
		})]
	});
});
MenuPositioner.displayName = "MenuPositioner";
// node_modules/@base-ui/react/menu/radio-group/MenuRadioGroupContext.mjs
var MenuRadioGroupContext = /*#__PURE__*/ import_react.createContext(void 0);
MenuRadioGroupContext.displayName = "MenuRadioGroupContext";
function useMenuRadioGroupContext() {
	const context = import_react.useContext(MenuRadioGroupContext);
	if (context === void 0) throw new Error("Base UI: MenuRadioGroupContext is missing. MenuRadioGroup parts must be placed within <Menu.RadioGroup>.");
	return context;
}
// node_modules/@base-ui/react/menu/radio-group/MenuRadioGroup.mjs
/**
* @internal
*/
var MenuRadioGroupPlain = /*#__PURE__*/ import_react.forwardRef(function MenuRadioGroupPlain(componentProps, forwardedRef) {
	const { render, className, value: valueProp, defaultValue, onValueChange: onValueChangeProp, disabled = false, style, "aria-labelledby": ariaLabelledByProp, ...elementProps } = componentProps;
	const [labelId, setLabelId] = import_react.useState(void 0);
	const [value, setValueUnwrapped] = useControlled({
		controlled: valueProp,
		default: defaultValue,
		name: "MenuRadioGroup"
	});
	const setValue = useStableCallback((newValue, eventDetails) => {
		onValueChangeProp?.(newValue, eventDetails);
		if (eventDetails.isCanceled) return;
		setValueUnwrapped(newValue);
	});
	const element = useRenderElement("div", componentProps, {
		state: { disabled },
		ref: forwardedRef,
		props: {
			role: "group",
			"aria-labelledby": ariaLabelledByProp ?? labelId,
			"aria-disabled": disabled || void 0,
			...elementProps
		}
	});
	const context = import_react.useMemo(() => ({
		value,
		setValue,
		disabled
	}), [
		value,
		setValue,
		disabled
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuGroupContext.Provider, {
		value: setLabelId,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuRadioGroupContext.Provider, {
			value: context,
			children: element
		})
	});
});
MenuRadioGroupPlain.displayName = "MenuRadioGroupPlain";
var MenuRadioGroup = /*#__PURE__*/ import_react.memo(/*#__PURE__*/ import_react.forwardRef(function MenuRadioGroup(props, forwardedRef) {
	const RadioGroup = useMenuFilterImpl()?.RadioGroup ?? MenuRadioGroupPlain;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(RadioGroup, {
		...props,
		ref: forwardedRef
	});
}));
MenuRadioGroup.displayName = "MenuRadioGroup";
// node_modules/@base-ui/react/menu/radio-item/MenuRadioItemContext.mjs
var MenuRadioItemContext = /*#__PURE__*/ import_react.createContext(void 0);
MenuRadioItemContext.displayName = "MenuRadioItemContext";
function useMenuRadioItemContext() {
	const context = import_react.useContext(MenuRadioItemContext);
	if (context === void 0) throw new Error("Base UI: MenuRadioItemContext is missing. MenuRadioItem parts must be placed within <Menu.RadioItem>.");
	return context;
}
// node_modules/@base-ui/react/menu/radio-item/MenuRadioItem.mjs
var MenuRadioItemPlain = /*#__PURE__*/ import_react.forwardRef(function MenuRadioItemPlain(componentProps, forwardedRef) {
	const { render, className, id: idProp, label, nativeButton = false, disabled: disabledProp = false, closeOnClick = false, value, style, ...elementProps } = componentProps;
	const { store } = useMenuRootContext();
	const { value: selectedValue, setValue: setSelectedValue, disabled: groupDisabled } = useMenuRadioGroupContext();
	const listItem = useCompositeListItem({
		guess: true,
		label
	});
	const id = useBaseUiId(idProp);
	const highlighted = store.useState("isActive", listItem.index);
	const nodeId = store.useState("floatingNodeId");
	const itemProps = store.useState("itemProps");
	const rootDisabled = store.useState("disabled");
	const disabled = disabledProp || groupDisabled || rootDisabled;
	const checked = selectedValue === value;
	const { getItemProps, itemRef } = useMenuItem({
		closeOnClick,
		disabled,
		highlighted,
		id,
		store,
		nativeButton,
		nodeId,
		itemMetadata: REGULAR_ITEM
	});
	const state = import_react.useMemo(() => ({
		disabled,
		highlighted,
		checked
	}), [
		disabled,
		highlighted,
		checked
	]);
	function handleClick(event) {
		const details = createChangeEventDetails(itemPress, event.nativeEvent, void 0, { preventUnmountOnClose: NOOP });
		setSelectedValue(value, details);
	}
	const element = useRenderElement("div", componentProps, {
		state,
		stateAttributesMapping: itemMapping,
		props: [
			itemProps,
			{
				role: "menuitemradio",
				"aria-checked": checked,
				onClick: handleClick
			},
			elementProps,
			getItemProps
		],
		ref: [
			itemRef,
			forwardedRef,
			listItem.ref
		]
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuRadioItemContext.Provider, {
		value: state,
		children: element
	});
});
MenuRadioItemPlain.displayName = "MenuRadioItemPlain";
var MenuRadioItem = /*#__PURE__*/ import_react.forwardRef(function MenuRadioItem(props, forwardedRef) {
	const filterItem = useMenuFilterItem(props, forwardedRef);
	if (!filterItem.visible) return null;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuRadioItemPlain, {
		...props,
		ref: filterItem.ref
	});
});
MenuRadioItem.displayName = "MenuRadioItem";
// node_modules/@base-ui/react/menu/radio-item-indicator/MenuRadioItemIndicator.mjs
/**
* Indicates whether the radio item is selected.
* Renders a `<span>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuRadioItemIndicator = /*#__PURE__*/ import_react.forwardRef(function MenuRadioItemIndicator(componentProps, forwardedRef) {
	const { render, className, style, keepMounted = false, ...elementProps } = componentProps;
	const item = useMenuRadioItemContext();
	const indicatorRef = import_react.useRef(null);
	const { transitionStatus, mounted, setMounted } = useTransitionStatus(item.checked);
	useOpenChangeComplete({
		batch: true,
		enabled: !item.checked,
		open: item.checked,
		ref: indicatorRef,
		onComplete() {
			if (!item.checked) setMounted(false);
		}
	});
	const state = {
		checked: item.checked,
		disabled: item.disabled,
		highlighted: item.highlighted,
		transitionStatus
	};
	return useRenderElement("span", componentProps, {
		state,
		stateAttributesMapping: itemMapping,
		ref: [forwardedRef, indicatorRef],
		props: {
			"aria-hidden": true,
			...elementProps
		},
		enabled: keepMounted || mounted
	});
});
MenuRadioItemIndicator.displayName = "MenuRadioItemIndicator";
// node_modules/@base-ui/react/menubar/MenubarContext.mjs
var MenubarContext = /*#__PURE__*/ import_react.createContext(null);
MenubarContext.displayName = "MenubarContext";
function useMenubarContext(optional) {
	const context = import_react.useContext(MenubarContext);
	if (context === null && !optional) throw new Error("Base UI: MenubarContext is missing. Menubar parts must be placed within <Menubar>.");
	return context;
}
// node_modules/@base-ui/react/utils/getHighlightReason.mjs
/**
* The `onItemHighlighted` reason for a list navigation event, matching the event type that the
* reason promises in its details.
*/
function getHighlightReason(event) {
	if (event == null) return none;
	if (event.type.startsWith("key")) return keyboard;
	if (event.type.startsWith("mouse") || event.type.startsWith("pointer")) return pointer;
	return none;
}
// node_modules/@base-ui/react/menu/store/MenuStore.mjs
var selectors$1 = {
	...popupStoreSelectors,
	disabled: (state) => state.parent.type === "menubar" ? state.parent.context.disabled || state.disabled : state.disabled,
	modal: (state) => (state.parent.type === void 0 || state.parent.type === "context-menu") && (state.modal ?? true),
	openMethod: (state) => state.openMethod,
	keyboardOpen: (state) => state.keyboardOpen,
	allowMouseEnter: (state) => state.allowMouseEnter,
	highlightItemOnHover: (state) => state.highlightItemOnHover,
	parent: (state) => state.parent,
	rootId: (state) => {
		if (state.parent.type === "menu") return state.parent.store.select("rootId");
		return state.parent.type !== void 0 ? state.parent.context.rootId : state.rootId;
	},
	activeIndex: (state) => state.activeIndex,
	listElement: (state) => state.listElement,
	/** The trigger's `aria-controls`: the list when one holds the `menu` role, else the popup. */
	triggerControlsId: (state, triggerId) => {
		const popupId = popupStoreSelectors.triggerPopupId(state, triggerId);
		return popupId ? state.listElement?.id || popupId : void 0;
	},
	filterTriggerProps: (state) => state.filterTriggerProps,
	inputProps: (state) => state.inputProps,
	webkitAriaSelected: (state, highlighted) => webkit && state.inputFocused && highlighted ? true : void 0,
	highlightedItemId: (state) => state.highlightedItem?.id || void 0,
	isActive: (state, itemIndex) => state.activeIndex === itemIndex,
	hoverEnabled: (state) => state.hoverEnabled,
	instantType: (state) => state.instantType === "trigger-change" && !popupStoreSelectors.open(state) ? void 0 : state.instantType,
	lastOpenChangeReason: (state) => state.openChangeReason,
	floatingTreeRoot: (state) => {
		if (state.parent.type === "menu") return state.parent.store.select("floatingTreeRoot");
		return state.floatingTreeRoot;
	},
	floatingNodeId: (state) => state.floatingNodeId,
	floatingParentNodeId: (state) => state.floatingParentNodeId,
	itemProps: (state) => state.itemProps,
	closeDelay: (state) => state.closeDelay,
	adaptiveOrigin: (state) => state.adaptiveOrigin,
	keyboardEventRelay: (state) => {
		if (state.keyboardEventRelay) return state.keyboardEventRelay;
		if (state.parent.type === "menu") return state.parent.store.select("keyboardEventRelay");
	}
};
/**
* The store view that detached handle-backed triggers read from. Both the real `MenuStore` and the
* inert fallback store satisfy it, so a trigger can read from whichever store the handle currently
* exposes. Narrowed to the members a trigger actually uses — the trigger-data members plus `setOpen`
* (called by the focus guards) — so the exposed surface can't bypass the open-change pipeline; on
* the detached fallback store every one of these mutations is a no-op.
*/
var MenuStore = class extends ReactStore {
	constructor(initialState, floatingId, nested = false) {
		const triggerElements = new PopupTriggerMap();
		const state = createInitialState(triggerElements, floatingId, nested, initialState);
		super(state, createInitialContext(triggerElements), selectors$1);
		this.observe("parent", (parent) => {
			if (parent.type === "menu") this.context.allowMouseUpTriggerRef = parent.store.context.allowMouseUpTriggerRef;
			else if (parent.type !== void 0) this.context.allowMouseUpTriggerRef = parent.context.allowMouseUpTriggerRef;
		});
	}
	/**
	* Propagates changes of the parent menu's shared tree state to this store's subscribers.
	* The owning `Menu.Root` calls it from an effect so the parent store subscription is released
	* when the submenu unmounts.
	* @returns A function that removes the parent store subscription.
	*/
	subscribeToParentMenu() {
		const parent = this.state.parent;
		if (parent.type !== "menu") return;
		let rootId = parent.store.select("rootId");
		let floatingTreeRoot = parent.store.select("floatingTreeRoot");
		let keyboardEventRelay = parent.store.select("keyboardEventRelay");
		return parent.store.subscribe(() => {
			const nextRootId = parent.store.select("rootId");
			const nextFloatingTreeRoot = parent.store.select("floatingTreeRoot");
			const nextKeyboardEventRelay = parent.store.select("keyboardEventRelay");
			if (rootId === nextRootId && floatingTreeRoot === nextFloatingTreeRoot && keyboardEventRelay === nextKeyboardEventRelay) return;
			rootId = nextRootId;
			floatingTreeRoot = nextFloatingTreeRoot;
			keyboardEventRelay = nextKeyboardEventRelay;
			this.notifyAll();
		});
	}
	setOpen(open, eventDetails) {
		this.state.floatingRootContext.context.events.emit("setOpen", {
			open,
			eventDetails
		});
	}
	setActiveIndex(activeIndex, reason, event) {
		if (this.state.activeIndex !== activeIndex) {
			const isWriteBack = (activeIndex === null ? void 0 : this.context.itemDomElements.current[activeIndex]) === this.context.reportedItem;
			this.context.highlightReason = isWriteBack ? "none" : reason;
			this.context.highlightEvent = isWriteBack ? void 0 : event;
		}
		this.set("activeIndex", activeIndex);
	}
	highlightItem(element, reason, event) {
		const index = this.context.itemDomElements.current.indexOf(element);
		if (index > -1) this.setActiveIndex(index, reason, event);
	}
};
/**
* Creates the inert fallback store used by detached handle-backed triggers while no `Menu.Root` is
* attached. It preserves a menu-specific trigger registry in context so detached triggers can
* register before migrating to the live root store. `setOpen` is a no-op (matching the inert
* reads/writes of `NullStore`), so a trigger can hand the store to focus-guard helpers that expect
* `setOpen` without it ever taking effect while detached.
*/
function createNullMenuStore() {
	const triggerElements = new PopupTriggerMap();
	const store = new NullStore(Object.freeze(createInitialState(triggerElements)), Object.freeze(createInitialContext(triggerElements)), selectors$1);
	return Object.assign(store, { setOpen: NOOP });
}
function createInitialContext(triggerElements) {
	return {
		positionerRef: /*#__PURE__*/ import_react.createRef(),
		popupRef: /*#__PURE__*/ import_react.createRef(),
		typingRef: { current: false },
		itemDomElements: { current: [] },
		itemLabels: { current: [] },
		highlightReason: "none",
		highlightEvent: void 0,
		reportedItem: void 0,
		allowMouseUpTriggerRef: { current: false },
		virtualFocusRef: void 0,
		triggerFocusTargetRef: /*#__PURE__*/ import_react.createRef(),
		beforeTriggerFocusGuardRef: /*#__PURE__*/ import_react.createRef(),
		beforeContentFocusGuardRef: /*#__PURE__*/ import_react.createRef(),
		onOpenChangeComplete: void 0,
		triggerElements
	};
}
function createInitialState(triggerElements, floatingId, nested = false, initialState) {
	return {
		...createInitialPopupStoreState(triggerElements, floatingId, nested),
		disabled: false,
		modal: true,
		openMethod: null,
		keyboardOpen: false,
		allowMouseEnter: false,
		highlightItemOnHover: true,
		parent: { type: void 0 },
		rootId: void 0,
		activeIndex: null,
		listElement: null,
		filterTriggerProps: EMPTY_OBJECT,
		inputProps: EMPTY_OBJECT,
		inputFocused: false,
		highlightedItem: void 0,
		hoverEnabled: true,
		instantType: void 0,
		openChangeReason: null,
		floatingTreeRoot: new FloatingTreeStore(),
		floatingNodeId: void 0,
		floatingParentNodeId: null,
		itemProps: EMPTY_OBJECT,
		keyboardEventRelay: void 0,
		closeDelay: 0,
		adaptiveOrigin: void 0,
		...initialState
	};
}
// node_modules/@base-ui/react/menu/filter-provider/MenuFilterProviderContext.mjs
/**
* What `Menu.FilterProvider` hands to the root directly inside it: the filterable root
* implementations (the provider is their only importer) and the filter props.
*/
/**
* Non-null only directly below a provider. The root that consumes it resets it, so a plain
* `Menu.SubmenuRoot` inside a filterable menu stays plain.
*/
var MenuFilterProviderContext = /*#__PURE__*/ import_react.createContext(null);
MenuFilterProviderContext.displayName = "MenuFilterProviderContext";
// node_modules/@base-ui/react/menu/utils/isKeyboardOpen.mjs
/**
* Keyboard and assistive-technology activations produce `detail === 0` clicks; mouse-gesture
* clicks (including the synthesized drag-release click from `useMenuItemCommonProps`) carry
* `detail >= 1`.
*/
function isKeyboardClick(reason, event) {
	return (reason === "trigger-press" || reason === "item-press") && event?.detail === 0;
}
/**
* Whether a menu opens from the keyboard, which lands focus in the popup. Arrow keys report
* `list-navigation`; Enter and Space dispatch a click carrying no pointer detail.
*/
function isKeyboardOpen(reason, event) {
	return reason === "list-navigation" || isKeyboardClick(reason, event);
}
// node_modules/@base-ui/react/menu/root/MenuRoot.mjs
/**
* @internal
*/
var MenuRootInternal = fastComponent(function MenuRootInternal(props) {
	const { children, open: openProp, onOpenChange, onOpenChangeComplete, onItemHighlighted: onItemHighlightedProp, defaultOpen = false, disabled: disabledProp = false, modal: modalProp, loopFocus = true, orientation = "vertical", actionsRef, closeParentOnEsc = false, handle, triggerId: triggerIdProp, defaultTriggerId: defaultTriggerIdProp = null, highlightItemOnHover = true, isSubmenu = false, virtualFocus = false, virtualFocusRef, allowEscape = true, resetOnPointerLeave = true } = props;
	const contextMenuContext = useContextMenuRootContext(true);
	const parentMenuRootContext = useMenuRootContext(true);
	const menubarContext = useMenubarContext(true);
	const enclosingMenuStore = parentMenuRootContext?.store;
	const parentVirtualFocus = parentMenuRootContext?.virtualFocus ?? false;
	const parentFromContext = import_react.useMemo(() => {
		if (isSubmenu && enclosingMenuStore) return {
			type: "menu",
			store: enclosingMenuStore
		};
		if (menubarContext) return {
			type: "menubar",
			context: menubarContext
		};
		if (contextMenuContext && !enclosingMenuStore) return {
			type: "context-menu",
			context: contextMenuContext
		};
		return { type: void 0 };
	}, [
		contextMenuContext,
		enclosingMenuStore,
		menubarContext,
		isSubmenu
	]);
	const rootId = useBaseUiId();
	const defaultFloatingId = useBaseUiId();
	const [renderedFloatingId, setRenderedFloatingId] = import_react.useState(void 0);
	const floatingId = (renderedFloatingId ?? defaultFloatingId) || void 0;
	const floatingParentNodeIdFromContext = useFloatingParentNodeId();
	const parentMenuStore = parentFromContext.type === "menu" ? parentFromContext.store : void 0;
	const animateInitialOpen = (openProp ?? defaultOpen) && parentMenuStore?.state.transitionStatus === "starting";
	const seededInstantType = useRefWithInit(() => animateInitialOpen ? parentMenuStore?.state.instantType : void 0).current;
	const store = useRefWithInit(() => {
		const menuStore = new MenuStore({
			open: defaultOpen,
			openProp,
			activeTriggerId: defaultTriggerIdProp,
			triggerIdProp,
			parent: parentFromContext,
			disabled: disabledProp,
			highlightItemOnHover,
			modal: parentFromContext.type === void 0 ? modalProp : void 0,
			rootId,
			instantType: seededInstantType
		}, floatingId, floatingParentNodeIdFromContext != null);
		menuStore.context.virtualFocusRef = virtualFocusRef;
		return menuStore;
	}).current;
	store.useControlledProp("openProp", openProp);
	store.useControlledProp("triggerIdProp", triggerIdProp);
	store.useContextCallback("onOpenChangeComplete", onOpenChangeComplete);
	const floatingTreeRoot = store.useState("floatingTreeRoot");
	const floatingNodeIdFromContext = useFloatingNodeId(floatingTreeRoot);
	const open = store.useState("open");
	const activeTriggerElement = store.useState("activeTriggerElement");
	const positionerElement = store.useState("positionerElement");
	const hoverEnabled = store.useState("hoverEnabled");
	const disabled = store.useState("disabled");
	const lastOpenChangeReason = store.useState("lastOpenChangeReason");
	const parent = store.useState("parent");
	const activeIndex = store.useState("activeIndex");
	const keyboardOpen = store.useState("keyboardOpen");
	const payload = store.useState("payload");
	const floatingParentNodeId = store.useState("floatingParentNodeId");
	const openEventRef = import_react.useRef(null);
	const allowOutsidePressDismissalRef = import_react.useRef(parent.type !== "context-menu");
	const allowOutsidePressDismissalTimeout = useTimeout();
	const allowTouchToCloseRef = import_react.useRef(true);
	const allowTouchToCloseTimeout = useTimeout();
	const nested = floatingParentNodeId != null;
	if (parent.type !== void 0 && modalProp !== void 0) console.warn("Base UI: The `modal` prop is not supported on nested menus. It will be ignored.");
	const { openMethod, triggerProps: interactionTypeProps } = useOpenInteractionType(open);
	store.useSyncedValues({
		disabled: disabledProp,
		highlightItemOnHover,
		modal: parent.type === void 0 ? modalProp : void 0,
		openMethod,
		rootId
	});
	useImplicitActiveTrigger(store);
	const { forceUnmount, transitionStatus } = useOpenStateTransitions(open, store, () => {
		store.set("allowMouseEnter", false);
	}, animateInitialOpen);
	const runOnceAnimationsFinish = useAnimationsFinished(store.context.popupRef);
	import_react.useEffect(() => {
		if (seededInstantType === void 0) return;
		const clearSeededInstantType = () => {
			if (store.state.instantType === seededInstantType) store.set("instantType", void 0);
		};
		if (!open) {
			clearSeededInstantType();
			return;
		}
		if (transitionStatus !== void 0) return;
		if (store.context.popupRef.current == null) {
			clearSeededInstantType();
			return;
		}
		const abortController = new AbortController();
		runOnceAnimationsFinish(clearSeededInstantType, abortController.signal);
		return () => {
			abortController.abort();
		};
	}, [
		seededInstantType,
		open,
		transitionStatus,
		runOnceAnimationsFinish,
		store
	]);
	useIsoLayoutEffect(() => {
		if (contextMenuContext && !parentMenuRootContext) store.update({
			parent: {
				type: "context-menu",
				context: contextMenuContext
			},
			floatingNodeId: floatingNodeIdFromContext,
			floatingParentNodeId: floatingParentNodeIdFromContext
		});
		else if (parentMenuRootContext || !store.select("activeTriggerElement")) store.update({
			floatingNodeId: floatingNodeIdFromContext,
			floatingParentNodeId: floatingParentNodeIdFromContext
		});
	}, [
		contextMenuContext,
		parentMenuRootContext,
		floatingNodeIdFromContext,
		floatingParentNodeIdFromContext,
		activeTriggerElement,
		store
	]);
	import_react.useEffect(() => {
		if (!open) openEventRef.current = null;
		if (parent.type !== "context-menu") return;
		if (!open) {
			allowOutsidePressDismissalTimeout.clear();
			allowOutsidePressDismissalRef.current = false;
			return;
		}
		allowOutsidePressDismissalTimeout.start(500, () => {
			allowOutsidePressDismissalRef.current = true;
		});
	}, [
		allowOutsidePressDismissalTimeout,
		open,
		parent.type
	]);
	useIsoLayoutEffect(() => {
		if (!open && !hoverEnabled) store.set("hoverEnabled", true);
	}, [
		open,
		hoverEnabled,
		store
	]);
	const setOpen = useStableCallback((nextOpen, eventDetails) => {
		const reason = eventDetails.reason;
		if (!nextOpen && !store.select("open")) return;
		if (open === nextOpen && eventDetails.trigger === activeTriggerElement && lastOpenChangeReason === reason) return;
		const shouldPreventUnmountOnClose = attachPreventUnmountOnClose(eventDetails);
		if (!nextOpen && eventDetails.trigger == null) eventDetails.trigger = activeTriggerElement ?? void 0;
		onOpenChange?.(nextOpen, eventDetails);
		if (eventDetails.isCanceled) return;
		store.state.floatingRootContext.dispatchOpenChange(nextOpen, eventDetails);
		const nativeEvent = eventDetails.event;
		if (nextOpen === false && reason !== "item-press" && nativeEvent?.type === "click" && nativeEvent.pointerType === "touch" && !allowTouchToCloseRef.current) return;
		if (nextOpen && reason === "trigger-focus") {
			allowTouchToCloseRef.current = false;
			allowTouchToCloseTimeout.start(300, () => {
				allowTouchToCloseRef.current = true;
			});
		} else {
			allowTouchToCloseRef.current = true;
			allowTouchToCloseTimeout.clear();
		}
		const isDismissClose = !nextOpen && (reason === "escape-key" || reason == null);
		openEventRef.current = eventDetails.event;
		const popupOpenState = createPopupOpenState(store.state, nextOpen, eventDetails.trigger, shouldPreventUnmountOnClose());
		popupOpenState.openChangeReason = reason;
		popupOpenState.keyboardOpen = nextOpen && isKeyboardOpen(reason, nativeEvent);
		if (parent.type === "menubar" && (reason === "trigger-focus" || reason === "focus-out" || reason === "trigger-hover" || reason === "list-navigation" || reason === "sibling-open")) popupOpenState.instantType = "group";
		else if (isKeyboardClick(reason, nativeEvent)) popupOpenState.instantType = "click";
		else if (isDismissClose) popupOpenState.instantType = "dismiss";
		else popupOpenState.instantType = void 0;
		store.update(popupOpenState);
	});
	const floatingRootContext = useSyncedFloatingRootContext({
		popupStore: store,
		floatingRootContext: store.state.floatingRootContext,
		floatingId,
		nested: floatingParentNodeIdFromContext != null,
		onOpenChange: setOpen
	});
	const floatingEvents = floatingRootContext.context.events;
	useIsoLayoutEffect(() => {
		const handleSetOpenEvent = ({ open: nextOpen, eventDetails }) => setOpen(nextOpen, eventDetails);
		floatingEvents.on("setOpen", handleSetOpenEvent);
		return () => {
			floatingEvents?.off("setOpen", handleSetOpenEvent);
		};
	}, [floatingEvents, setOpen]);
	useIsoLayoutEffect(() => store.subscribeToParentMenu(), [store]);
	const handleImperativeClose = import_react.useCallback(() => {
		store.setOpen(false, createChangeEventDetails(imperativeAction));
	}, [store]);
	import_react.useImperativeHandle(actionsRef, () => ({
		unmount: forceUnmount,
		close: handleImperativeClose
	}), [forceUnmount, handleImperativeClose]);
	let ctx;
	if (parent.type === "context-menu") ctx = parent.context;
	import_react.useImperativeHandle(ctx?.positionerRef, () => positionerElement, [positionerElement]);
	import_react.useImperativeHandle(ctx?.actionsRef, () => ({ setOpen }), [setOpen]);
	const dismiss = useDismiss(floatingRootContext, {
		enabled: !disabled,
		bubbles: { escapeKey: closeParentOnEsc && parent.type === "menu" },
		outsidePress() {
			if (parent.type !== "context-menu" || openEventRef.current?.type === "contextmenu") return true;
			return allowOutsidePressDismissalRef.current;
		},
		externalTree: nested ? floatingTreeRoot : void 0
	});
	const direction = useDirection();
	const listNavigation$1 = useListNavigation(floatingRootContext, {
		enabled: !disabled,
		listRef: store.context.itemDomElements,
		activeIndex,
		virtual: virtualFocus,
		nested: parent.type === "menubar" || !virtualFocus && parent.type !== void 0,
		parentOrientation: parent.type === "menubar" ? parent.context.orientation : void 0,
		loopFocus,
		focusItemOnOpen: virtualFocus ? keyboardOpen : void 0,
		allowEscape: virtualFocus && loopFocus && allowEscape,
		orientation,
		triggerOrientation: virtualFocus ? "vertical" : orientation,
		rtl: direction === "rtl",
		disabledIndices: EMPTY_ARRAY,
		onNavigate(nextActiveIndex, event) {
			store.setActiveIndex(nextActiveIndex, getHighlightReason(event), event?.nativeEvent);
		},
		openOnArrowKeyDown: parent.type !== "context-menu" && !(virtualFocus && isSubmenu),
		externalTree: !virtualFocus && nested ? floatingTreeRoot : void 0,
		nestedReturnFocusRef: parentMenuStore?.context.virtualFocusRef,
		focusItemOnHover: highlightItemOnHover,
		resetOnPointerLeave
	});
	const onTyping = import_react.useCallback((nextTyping) => {
		store.context.typingRef.current = nextTyping;
	}, [store]);
	const typeahead = useTypeahead(floatingRootContext, {
		enabled: !disabled && !virtualFocus,
		listRef: store.context.itemLabels,
		elementsRef: store.context.itemDomElements,
		activeIndex,
		resetMs: 500,
		onMatch: (index, event) => {
			if (open && index !== activeIndex) store.setActiveIndex(index, keyboard, event.nativeEvent);
		},
		onTyping
	});
	const onItemHighlighted = useStableCallback(onItemHighlightedProp);
	const lastHighlightIndexRef = import_react.useRef(-1);
	const syncHighlightedItem = useStableCallback(() => {
		const index = store.state.activeIndex;
		const item = index === null ? void 0 : store.context.itemDomElements.current[index] ?? void 0;
		if (item?.isConnected === false) return;
		const itemIndex = item === void 0 ? -1 : index;
		if (lastHighlightIndexRef.current === itemIndex && store.context.reportedItem === item) return;
		lastHighlightIndexRef.current = itemIndex;
		store.context.reportedItem = item;
		if (virtualFocus) store.set("highlightedItem", item);
		const { highlightReason, highlightEvent } = store.context;
		store.context.highlightReason = none;
		store.context.highlightEvent = void 0;
		if (!onItemHighlightedProp) return;
		onItemHighlighted(item, createGenericEventDetails(highlightReason, highlightEvent, { label: item === void 0 ? void 0 : store.context.itemLabels.current[itemIndex] ?? void 0 }));
	});
	useIsoLayoutEffect(() => {
		syncHighlightedItem();
	}, [activeIndex, syncHighlightedItem]);
	const openTriggerProps = import_react.useMemo(() => {
		if (!virtualFocus) return listNavigation$1.reference;
		if (!listNavigation$1.trigger) return EMPTY_OBJECT;
		const { onFocus, ...rest } = listNavigation$1.trigger;
		return rest;
	}, [
		virtualFocus,
		listNavigation$1.reference,
		listNavigation$1.trigger
	]);
	store.useSyncedValue("inputProps", virtualFocus ? listNavigation$1.reference ?? EMPTY_OBJECT : EMPTY_OBJECT);
	const activeTriggerProps = import_react.useMemo(() => {
		const mergedProps = mergeProps(typeahead.reference, openTriggerProps, dismiss.reference, { onMouseMove() {
			store.set("allowMouseEnter", true);
		} }, interactionTypeProps);
		mergedProps["aria-haspopup"] = "menu";
		mergedProps["aria-expanded"] = open;
		return mergedProps;
	}, [
		store,
		typeahead.reference,
		openTriggerProps,
		dismiss.reference,
		interactionTypeProps,
		open
	]);
	const inactiveTriggerProps = import_react.useMemo(() => {
		const mergedProps = mergeProps(listNavigation$1.trigger, dismiss.trigger, interactionTypeProps);
		mergedProps["aria-haspopup"] = "menu";
		mergedProps["aria-expanded"] = false;
		return mergedProps;
	}, [
		listNavigation$1.trigger,
		dismiss.trigger,
		interactionTypeProps
	]);
	useRefWithInit(() => {
		store.update({ inactiveTriggerProps });
		return null;
	});
	const popupProps = import_react.useMemo(() => mergeProps(FOCUSABLE_POPUP_PROPS, {
		onMouseMove() {
			store.set("allowMouseEnter", true);
			if (parent.type === "menu") store.set("hoverEnabled", false);
		},
		onClick() {
			if (store.select("hoverEnabled")) store.set("hoverEnabled", false);
		},
		onKeyDown(event) {
			const relay = store.select("keyboardEventRelay");
			if (relay && !event.isPropagationStopped()) relay(event);
		}
	}, typeahead.floating, listNavigation$1.floating, dismiss.floating), [
		parent.type,
		store,
		typeahead.floating,
		listNavigation$1.floating,
		dismiss.floating
	]);
	const itemProps = listNavigation$1.item ?? EMPTY_OBJECT;
	usePopupInteractionProps(store, {
		floatingRootContext,
		activeTriggerProps,
		inactiveTriggerProps,
		popupProps,
		itemProps
	});
	const context = import_react.useMemo(() => ({
		store,
		parent: parentFromContext,
		orientation,
		loopFocus,
		allowEscape,
		defaultFloatingId,
		setRenderedFloatingId,
		virtualFocus,
		parentVirtualFocus,
		syncHighlightedItem
	}), [
		store,
		parentFromContext,
		orientation,
		loopFocus,
		allowEscape,
		defaultFloatingId,
		virtualFocus,
		parentVirtualFocus,
		syncHighlightedItem
	]);
	const renderedChildren = typeof children === "function" ? children({ payload }) : children;
	let content = /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(MenuRootContext.Provider, {
		value: context,
		children: [handle && /*#__PURE__*/ (0, import_jsx_runtime.jsx)(PopupHandleAttachment, {
			handle,
			store
		}), renderedChildren]
	});
	if (parent.type === void 0 || parent.type === "context-menu") content = /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FloatingTree, {
		externalTree: floatingTreeRoot,
		children: content
	});
	return content;
});
MenuRootInternal.displayName = "MenuRootInternal";
function MenuRoot(props) {
	const filterProvider = import_react.useContext(MenuFilterProviderContext);
	if (filterProvider === null) return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuRootInternal, { ...props });
	const FilterRoot = filterProvider.Root;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuFilterProviderContext.Provider, {
		value: null,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FilterRoot, {
			...filterProvider.options,
			...props
		})
	});
}
// node_modules/@base-ui/react/menu/submenu-root/MenuSubmenuRoot.mjs
var EMPTY_SUBMENU_ROOT_CONTEXT = {};
/**
* Groups all parts of a submenu.
* Doesn't render its own HTML element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
function MenuSubmenuRoot(props) {
	useMenuRootContext();
	const filterProvider = import_react.useContext(MenuFilterProviderContext);
	if (filterProvider !== null) {
		const FilterSubmenuRoot = filterProvider.SubmenuRoot;
		return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuFilterProviderContext.Provider, {
			value: null,
			children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FilterSubmenuRoot, {
				...filterProvider.options,
				...props
			})
		});
	}
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuSubmenuRootContext.Provider, {
		value: EMPTY_SUBMENU_ROOT_CONTEXT,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuRootInternal, {
			...props,
			isSubmenu: true
		})
	});
}
// node_modules/@base-ui/react/menu/utils/findRootOwnerId.mjs
function findRootOwnerId(node) {
	if (isHTMLElement(node) && node.hasAttribute("data-rootownerid")) return node.getAttribute("data-rootownerid");
	if (isLastTraversableNode(node)) return;
	return findRootOwnerId(getParentNode(node));
}
// node_modules/@base-ui/react/utils/popups/useTriggerFocusGuards.mjs
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
/**
* Minimal store interface required by the focus guard hook.
* Both PopoverStore and MenuStore satisfy this interface.
*/
/**
* Provides focus guard handlers for popup triggers (Popover, Menu).
*
* When the popup is open, invisible focus guard elements are placed before and after
* the trigger. These handlers close the popup and move focus to the appropriate
* tabbable element when the guards receive focus (i.e. when the user tabs out).
*/
function useTriggerFocusGuards(store, triggerElementRef) {
	function closeAndFocus(event, direction, positionerElement) {
		const guard = event.currentTarget;
		import_react_dom.flushSync(() => {
			store.setOpen(false, createChangeEventDetails(focusOut, event.nativeEvent, guard));
		});
		getTabbableNearElement(guard.isConnected ? guard : triggerElementRef.current, direction, positionerElement)?.focus();
	}
	function handlePreFocusGuardFocus(event) {
		closeAndFocus(event, -1, store.select("positionerElement"));
	}
	function handleFocusTargetFocus(event) {
		const positionerElement = store.select("positionerElement");
		if (positionerElement && isOutsideEvent(event, positionerElement)) store.context.beforeContentFocusGuardRef.current?.focus();
		else closeAndFocus(event, 1, positionerElement);
	}
	return {
		handlePreFocusGuardFocus,
		handleFocusTargetFocus
	};
}
// node_modules/@base-ui/react/utils/useMixedToggleClickHandler.mjs
/**
* Returns `click` and `mousedown` handlers that fix the behavior of triggers of popups that are toggled by different events.
* For example, a button that opens a popup on mousedown and closes it on click.
* This hook prevents the popup from closing immediately after the mouse button is released.
*/
function useMixedToggleClickHandler(params) {
	const { enabled = true, mouseDownAction, open } = params;
	const ignoreClickRef = import_react.useRef(false);
	return import_react.useMemo(() => {
		if (!enabled) return EMPTY_OBJECT;
		return {
			onMouseDown: (event) => {
				if (mouseDownAction === "open" && !open || mouseDownAction === "close" && open) {
					ignoreClickRef.current = true;
					ownerDocument(event.currentTarget).addEventListener("click", () => {
						ignoreClickRef.current = false;
					}, { once: true });
				}
			},
			onClick: (event) => {
				if (ignoreClickRef.current) {
					ignoreClickRef.current = false;
					event.preventBaseUIHandler();
				}
			}
		};
	}, [
		enabled,
		mouseDownAction,
		open
	]);
}
// node_modules/@base-ui/react/menu/trigger/MenuTrigger.mjs
/**
* A button that opens the menu.
* Renders a `<button>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuTrigger = fastComponentRef(function MenuTrigger(componentProps, forwardedRef) {
	const { render, className, style, disabled: disabledProp = false, nativeButton = true, id: idProp, openOnHover: openOnHoverProp, delay = 100, closeDelay = 0, handle, payload, ...elementProps } = componentProps;
	const rootContext = useMenuRootContext(true);
	const store = usePopupHandleStore(handle) ?? rootContext?.store;
	if (!store) throw new Error("Base UI: <Menu.Trigger> must be either used within a <Menu.Root> component or provided with a handle.");
	const thisTriggerId = useBaseUiId(idProp);
	const isTriggerActive = store.useState("isTriggerActive", thisTriggerId);
	const floatingRootContext = store.useState("floatingRootContext");
	const isOpenedByThisTrigger = store.useState("isOpenedByTrigger", thisTriggerId);
	const controlsId = store.useState("triggerControlsId", thisTriggerId);
	const triggerElementRef = import_react.useRef(null);
	const parent = useMenuParent();
	const compositeRootContext = useCompositeRootContext(true);
	const floatingTreeRootFromContext = useFloatingTree();
	const floatingTreeRoot = import_react.useMemo(() => {
		return floatingTreeRootFromContext ?? new FloatingTreeStore();
	}, [floatingTreeRootFromContext]);
	const floatingNodeId = useFloatingNodeId(floatingTreeRoot);
	const floatingParentNodeId = useFloatingParentNodeId();
	const { registerTrigger, isMountedByThisTrigger } = useTriggerDataForwarding(thisTriggerId, triggerElementRef, store, {
		payload,
		closeDelay,
		parent,
		floatingTreeRoot,
		floatingNodeId,
		floatingParentNodeId,
		keyboardEventRelay: compositeRootContext?.relayKeyboardEvent
	});
	const isInMenubar = parent.type === "menubar";
	const rootDisabled = store.useState("disabled");
	const disabled = disabledProp || rootDisabled || isInMenubar && parent.context.disabled;
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	import_react.useEffect(() => {
		if (!isOpenedByThisTrigger && parent.type === void 0) store.context.allowMouseUpTriggerRef.current = false;
	}, [
		store,
		isOpenedByThisTrigger,
		parent.type
	]);
	const triggerRef = import_react.useRef(null);
	const allowMouseUpTriggerTimeout = useTimeout();
	const handleDocumentMouseUp = useStableCallback((mouseEvent) => {
		if (!triggerRef.current) return;
		allowMouseUpTriggerTimeout.clear();
		store.context.allowMouseUpTriggerRef.current = false;
		const mouseUpTarget = mouseEvent.target;
		if (contains(triggerRef.current, mouseUpTarget) || contains(store.select("positionerElement"), mouseUpTarget) || mouseUpTarget === triggerRef.current) return;
		if (mouseUpTarget != null && findRootOwnerId(mouseUpTarget) === store.select("rootId")) return;
		if (isMouseWithinBounds(mouseEvent, triggerRef.current)) return;
		floatingTreeRoot.events.emit("close", {
			domEvent: mouseEvent,
			reason: cancelOpen
		});
	});
	import_react.useEffect(() => {
		const doc = ownerDocument(triggerRef.current);
		if (isOpenedByThisTrigger && store.select("lastOpenChangeReason") === "trigger-hover") {
			doc.addEventListener("mouseup", handleDocumentMouseUp, { once: true });
			return () => {
				doc.removeEventListener("mouseup", handleDocumentMouseUp);
			};
		}
	}, [
		isOpenedByThisTrigger,
		handleDocumentMouseUp,
		store
	]);
	const parentMenubarHasSubmenuOpen = isInMenubar && parent.context.hasSubmenuOpen;
	const hoverProps = useHoverReferenceInteraction(floatingRootContext, {
		enabled: (openOnHoverProp ?? parentMenubarHasSubmenuOpen) && !disabled && (!isInMenubar || parentMenubarHasSubmenuOpen && !isMountedByThisTrigger),
		handleClose: safePolygon({ blockPointerEvents: !isInMenubar }),
		mouseOnly: true,
		move: false,
		restMs: parent.type === void 0 ? delay : void 0,
		delay: { close: closeDelay },
		triggerElementRef,
		externalTree: floatingTreeRoot,
		isActiveTrigger: isTriggerActive,
		isClosing: () => store.select("transitionStatus") === "ending"
	});
	const stickIfOpen = useStickIfOpen(isOpenedByThisTrigger, store.select("lastOpenChangeReason"));
	const click = useClick(floatingRootContext, {
		enabled: !disabled,
		event: isOpenedByThisTrigger && isInMenubar ? "click" : "mousedown",
		toggle: true,
		ignoreMouse: false,
		stickIfOpen: parent.type === void 0 ? stickIfOpen : false
	});
	const focus = useFocus(floatingRootContext, { enabled: !disabled && parentMenubarHasSubmenuOpen });
	const mixedToggleHandlers = useMixedToggleClickHandler({
		open: isOpenedByThisTrigger,
		enabled: isInMenubar,
		mouseDownAction: "open"
	});
	const localInteractionProps = import_react.useMemo(() => mergeProps(focus.reference, click.reference), [focus.reference, click.reference]);
	const rootTriggerProps = store.useState("triggerProps", isMountedByThisTrigger);
	const filterTriggerProps = store.useState("filterTriggerProps");
	const { handlePreFocusGuardFocus, handleFocusTargetFocus } = useTriggerFocusGuards(store, triggerElementRef);
	const state = {
		disabled,
		open: isOpenedByThisTrigger
	};
	const ref = [
		triggerRef,
		forwardedRef,
		buttonRef,
		registerTrigger,
		triggerElementRef
	];
	const props = [
		localInteractionProps,
		hoverProps ?? EMPTY_OBJECT,
		rootTriggerProps,
		{
			"aria-haspopup": "menu",
			"aria-controls": controlsId,
			id: thisTriggerId,
			onMouseDown: (event) => {
				if (store.select("open")) return;
				allowMouseUpTriggerTimeout.start(200, () => {
					store.context.allowMouseUpTriggerRef.current = true;
				});
				ownerDocument(event.currentTarget).addEventListener("mouseup", handleDocumentMouseUp, { once: true });
			}
		},
		filterTriggerProps,
		isInMenubar ? { role: "menuitem" } : {},
		mixedToggleHandlers,
		elementProps,
		getButtonProps
	];
	const element = useRenderElement("button", componentProps, {
		enabled: !isInMenubar,
		stateAttributesMapping: pressableTriggerOpenStateMapping,
		state,
		ref,
		props
	});
	if (isInMenubar) return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeItem, {
		tag: "button",
		render,
		className,
		style,
		state,
		refs: ref,
		props,
		stateAttributesMapping: pressableTriggerOpenStateMapping
	});
	if (isOpenedByThisTrigger) return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(import_react.Fragment, { children: [
		/*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
			ref: store.context.beforeTriggerFocusGuardRef,
			onFocus: handlePreFocusGuardFocus
		}, `${thisTriggerId}-pre-focus-guard`),
		/*#__PURE__*/ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: element }, thisTriggerId),
		/*#__PURE__*/ (0, import_jsx_runtime.jsx)(FocusGuard, {
			ref: store.context.triggerFocusTargetRef,
			onFocus: handleFocusTargetFocus
		}, `${thisTriggerId}-post-focus-guard`)
	] });
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: element }, thisTriggerId);
});
MenuTrigger.displayName = "MenuTrigger";
/**
* Determines whether to ignore clicks after a hover-open.
*/
function useStickIfOpen(open, openReason) {
	const stickIfOpenTimeout = useTimeout();
	const [stickIfOpen, setStickIfOpen] = import_react.useState(false);
	useIsoLayoutEffect(() => {
		if (open && openReason === "trigger-hover") {
			setStickIfOpen(true);
			stickIfOpenTimeout.start(500, () => {
				setStickIfOpen(false);
			});
		} else if (!open) {
			stickIfOpenTimeout.clear();
			setStickIfOpen(false);
		}
	}, [
		open,
		openReason,
		stickIfOpenTimeout
	]);
	return stickIfOpen;
}
function useMenuParent() {
	const menubarContext = useMenubarContext(true);
	return import_react.useMemo(() => {
		if (menubarContext) return {
			type: "menubar",
			context: menubarContext
		};
		return { type: void 0 };
	}, [menubarContext]);
}
// node_modules/@base-ui/react/menu/viewport/MenuViewport.mjs
/**
* A viewport for displaying content transitions.
* This component is only required if one popup can be opened by multiple triggers, its content
* changes based on the trigger, and switching between them is animated.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuViewport = /*#__PURE__*/ import_react.forwardRef(function MenuViewport(componentProps, forwardedRef) {
	const { render, className, style, children, ...elementProps } = componentProps;
	const { store } = useMenuRootContext();
	const { side } = useMenuPositionerContext();
	const instantType = store.useState("instantType");
	const { children: childrenToRender, state: viewportState } = usePopupViewport({
		store,
		side,
		children
	});
	const state = {
		activationDirection: viewportState.activationDirection,
		transitioning: viewportState.transitioning,
		instant: instantType
	};
	return useRenderElement("div", componentProps, {
		state,
		ref: forwardedRef,
		props: [elementProps, { children: childrenToRender }],
		stateAttributesMapping: popupViewportStateMapping
	});
});
MenuViewport.displayName = "MenuViewport";
// node_modules/@base-ui/react/menu/submenu-trigger/MenuSubmenuTrigger.mjs
var VOICE_OVER_EXPANDED_PROPS = { "aria-expanded": void 0 };
var MenuSubmenuTriggerPlain = /*#__PURE__*/ import_react.forwardRef(function MenuSubmenuTriggerPlain(componentProps, forwardedRef) {
	const { render, className, style, label, id: idProp, nativeButton = false, openOnHover = true, delay = 100, closeDelay = 0, disabled: disabledProp = false, ...elementProps } = componentProps;
	const context = useMenuRootContext(true);
	if (context?.parent.type !== "menu") throw new Error("Base UI: <Menu.SubmenuTrigger> must be placed in <Menu.SubmenuRoot>.");
	const menuPositionerContext = useMenuPositionerContext();
	const submenuRootContext = useMenuSubmenuRootContext();
	const { store, parentVirtualFocus } = context;
	const parentMenuStore = context.parent.store;
	const listItem = useCompositeListItem({
		guess: true,
		label
	});
	const thisTriggerId = useBaseUiId(idProp);
	const open = store.useState("open");
	const focusReturnedThroughGuardRef = import_react.useRef(false);
	const positionerElement = store.useState("positionerElement");
	const floatingRootContext = store.useState("floatingRootContext");
	const floatingTreeRoot = store.useState("floatingTreeRoot");
	const popupId = store.useState("triggerPopupId", thisTriggerId);
	const baseRegisterTrigger = useTriggerRegistration(thisTriggerId, store);
	const registerTrigger = useStableCallback((element) => {
		baseRegisterTrigger(element);
		const activeTriggerElement = store.select("activeTriggerElement");
		if (element !== null && store.select("open") && (activeTriggerElement === element || store.select("activeTriggerId") == null)) store.update({
			activeTriggerId: thisTriggerId ?? null,
			activeTriggerElement: element,
			closeDelay
		});
	});
	const triggerElementRef = import_react.useRef(null);
	const handleTriggerElementRef = import_react.useCallback((el) => {
		triggerElementRef.current = el;
		store.set("activeTriggerElement", el);
	}, [store]);
	useIsoLayoutEffect(() => {
		registerTrigger(triggerElementRef.current);
		return () => registerTrigger(null);
	}, [
		registerTrigger,
		thisTriggerId,
		store
	]);
	useIsoLayoutEffect(() => {
		if (!open || !positionerElement) return;
		function handleGuardFocusOut(event) {
			if (getTarget(event) === store.context.beforeContentFocusGuardRef.current) focusReturnedThroughGuardRef.current = event.relatedTarget === triggerElementRef.current;
		}
		positionerElement.addEventListener("focusout", handleGuardFocusOut, true);
		return () => {
			focusReturnedThroughGuardRef.current = false;
			positionerElement.removeEventListener("focusout", handleGuardFocusOut, true);
		};
	}, [
		open,
		positionerElement,
		store
	]);
	store.useSyncedValue("closeDelay", closeDelay);
	const rootDisabled = store.useState("disabled");
	const parentDisabled = parentMenuStore.useState("disabled");
	const disabled = disabledProp || rootDisabled || parentDisabled;
	import_react.useEffect(() => {
		const element = triggerElementRef.current;
		if (element && isElementDisabled(element) && !disabled) {
			const ownerStackMessage = SafeReact.captureOwnerStack?.() || "";
			warn(`A disabled element was detected on <Menu.SubmenuTrigger>. To properly disable the trigger, use the \`disabled\` prop on the component instead of setting it on the rendered element.${ownerStackMessage}`);
		}
	});
	const itemProps = parentMenuStore.useState("itemProps");
	const highlighted = parentMenuStore.useState("isActive", listItem.index);
	const itemMetadata = import_react.useMemo(() => ({
		type: "submenu-trigger",
		setActive(event) {
			if (parentMenuStore.select("highlightItemOnHover")) parentMenuStore.setActiveIndex(listItem.index, pointer, event);
		}
	}), [parentMenuStore, listItem.index]);
	const { getItemProps, itemRef } = useMenuItem({
		closeOnClick: false,
		disabled,
		highlighted,
		id: thisTriggerId,
		store,
		typingRef: parentMenuStore.context.typingRef,
		nativeButton,
		itemMetadata,
		nodeId: menuPositionerContext?.context.nodeId
	});
	const hoverEnabled = store.useState("hoverEnabled");
	const hoverProps = useHoverReferenceInteraction(floatingRootContext, {
		enabled: hoverEnabled && openOnHover && !disabled,
		handleClose: safePolygon({ blockPointerEvents: true }),
		mouseOnly: true,
		move: true,
		restMs: delay,
		delay: {
			open: delay,
			close: closeDelay
		},
		shouldOpen: delay > 0 ? () => parentMenuStore.select("allowMouseEnter") : void 0,
		triggerElementRef,
		externalTree: floatingTreeRoot,
		isClosing: () => store.select("transitionStatus") === "ending",
		guardStaleOpen: true
	});
	const localInteractionProps = useClick(floatingRootContext, {
		enabled: !disabled,
		event: "mousedown",
		toggle: true,
		ignoreMouse: openOnHover,
		stickIfOpen: openOnHover
	}).reference ?? EMPTY_OBJECT;
	const rootTriggerProps = store.useState("triggerProps", true);
	delete rootTriggerProps.id;
	const state = {
		disabled,
		highlighted,
		open
	};
	const openMethod = store.useState("openMethod");
	const openedByKeyboard = store.useState("lastOpenChangeReason") === "list-navigation" || openMethod === "keyboard";
	const shouldOmitExpanded = open && openedByKeyboard && voiceOver;
	const submenuKeyDownProps = submenuRootContext?.onTriggerKeyDown ? { onKeyDown: submenuRootContext.onTriggerKeyDown } : void 0;
	return useRenderElement("div", componentProps, {
		state,
		stateAttributesMapping: triggerOpenStateMapping,
		props: [
			localInteractionProps,
			hoverProps,
			rootTriggerProps,
			submenuKeyDownProps,
			itemProps,
			shouldOmitExpanded ? VOICE_OVER_EXPANDED_PROPS : void 0,
			{
				"aria-controls": popupId,
				tabIndex: parentVirtualFocus || !(open || highlighted) ? -1 : 0,
				onFocus(event) {
					if (store.select("open") && focusReturnedThroughGuardRef.current) {
						focusReturnedThroughGuardRef.current = false;
						store.setOpen(false, createChangeEventDetails(focusOut, event.nativeEvent));
					}
				},
				onBlur() {
					if (highlighted) parentMenuStore.setActiveIndex(null, none);
				}
			},
			elementProps,
			getItemProps
		],
		ref: [
			forwardedRef,
			listItem.ref,
			itemRef,
			registerTrigger,
			handleTriggerElementRef
		]
	});
});
MenuSubmenuTriggerPlain.displayName = "MenuSubmenuTriggerPlain";
var MenuSubmenuTrigger = /*#__PURE__*/ import_react.forwardRef(function MenuSubmenuTrigger(props, forwardedRef) {
	const filterItem = useMenuFilterItem(props, forwardedRef, "submenu-trigger");
	if (!filterItem.visible) return null;
	const mergedProps = filterItem.props ? mergeProps(filterItem.props, props) : props;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuSubmenuTriggerPlain, {
		...mergedProps,
		ref: filterItem.ref
	});
});
MenuSubmenuTrigger.displayName = "MenuSubmenuTrigger";
// node_modules/@base-ui/react/menu/store/MenuHandle.mjs
/**
* Controls a Menu imperatively and associates detached `Menu.Trigger` components with a `Menu.Root`.
* Create one with `Menu.createHandle()` and pass it to the `handle` prop of the root and of any
* triggers rendered outside of it.
*
* The imperative methods take effect only while a root using this handle is mounted; calls made
* before a root attaches (or after it unmounts) are ignored.
*/
var MenuHandle = class extends BasePopupHandle {
	constructor() {
		super(createNullMenuStore(), "Menu");
	}
	/**
	* Opens the menu and associates it with the trigger with the given id.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*
	* @param triggerId ID of the trigger to associate with the menu. The trigger must be a matching
	* `Menu.Trigger` with this handle passed as a prop.
	*/
	open(triggerId) {
		this.openByTrigger(triggerId);
	}
	/**
	* Closes the menu.
	*
	* This method should only be called in an event handler or an effect (not during rendering).
	*/
	close() {
		this.closePopup();
	}
	/**
	* Whether the menu is currently open. Returns `false` while no root is attached to the handle.
	*/
	get isOpen() {
		return this.attachedStore?.select("open") ?? false;
	}
};
/**
* Creates a new handle to connect a Menu.Root with detached Menu.Trigger components.
*/
function createMenuHandle() {
	return new MenuHandle();
}
// node_modules/@base-ui/utils/stringifyLocale.mjs
function stringifyLocale(locale) {
	if (Array.isArray(locale)) return locale.map((value) => stringifyLocale(value)).join(",");
	if (locale == null) return "";
	return String(locale);
}
// node_modules/@base-ui/react/internals/filter.mjs
var filterCache = /* @__PURE__ */ new Map();
function getFilter(options = {}) {
	const { locale, ...restOptions } = options;
	const collatorOptions = {
		usage: "search",
		sensitivity: "base",
		ignorePunctuation: true,
		...restOptions
	};
	const cacheKey = `${stringifyLocale(locale)}|${JSON.stringify(collatorOptions)}`;
	const cachedFilter = filterCache.get(cacheKey);
	if (cachedFilter) return cachedFilter;
	const collator = new Intl.Collator(locale, collatorOptions);
	const filter = {
		contains(item, query, itemToString) {
			if (!query) return true;
			const itemString = stringifyAsLabel(item, itemToString);
			for (let i = 0; i <= itemString.length - query.length; i += 1) if (collator.compare(itemString.slice(i, i + query.length), query) === 0) return true;
			return false;
		},
		startsWith(item, query, itemToString) {
			if (!query) return true;
			const itemString = stringifyAsLabel(item, itemToString);
			return collator.compare(itemString.slice(0, query.length), query) === 0;
		},
		endsWith(item, query, itemToString) {
			if (!query) return true;
			const itemString = stringifyAsLabel(item, itemToString);
			const queryLength = query.length;
			return itemString.length >= queryLength && collator.compare(itemString.slice(itemString.length - queryLength), query) === 0;
		}
	};
	filterCache.set(cacheKey, filter);
	return filter;
}
// node_modules/@base-ui/react/internals/useItemRegistry.mjs
/**
* Collects item registrations into one immutable snapshot per React commit.
* Also returns the live registry for reads that must include the registrations of the current
* commit before its snapshot is published.
*/
function useItemRegistry() {
	const itemRegistry = useRefWithInit(() => /* @__PURE__ */ new Map()).current;
	const [registryVersion, setRegistryVersion] = import_react.useState(0);
	const isUpdateScheduledRef = import_react.useRef(false);
	const scheduleRegistryUpdate = useStableCallback(() => {
		if (isUpdateScheduledRef.current) return;
		isUpdateScheduledRef.current = true;
		setRegistryVersion((version) => version + 1);
	});
	const registerItem = useStableCallback((key, item) => {
		itemRegistry.set(key, item);
		scheduleRegistryUpdate();
		return () => {
			itemRegistry.delete(key);
			scheduleRegistryUpdate();
		};
	});
	const registeredItems = import_react.useMemo(() => new Map(itemRegistry), [registryVersion]);
	useIsoLayoutEffect(() => {
		isUpdateScheduledRef.current = false;
	}, [registryVersion]);
	return {
		items: registeredItems,
		registerItem,
		liveItems: itemRegistry
	};
}
// node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRootContext.mjs
function throwMissingFilterRoot() {
	throw new Error("Base UI: Filter parts are missing their filter context and cannot access the query or items. Wrap the component root in its filter provider.");
}
var FilterDropdownItemContext = /*#__PURE__*/ import_react.createContext(null);
FilterDropdownItemContext.displayName = "FilterDropdownItemContext";
function useFilterDropdownItemContext(optional = false) {
	const context = import_react.useContext(FilterDropdownItemContext);
	if (context === null && !optional) throwMissingFilterRoot();
	return context;
}
var FilterDropdownRootContext = /*#__PURE__*/ import_react.createContext(null);
FilterDropdownRootContext.displayName = "FilterDropdownRootContext";
function useFilterDropdownRootContext(optional = false) {
	const context = import_react.useContext(FilterDropdownRootContext);
	if (context === null && !optional) throwMissingFilterRoot();
	return context;
}
/**
* Finds the dropdown that owns the given item list, walking out through nested roots.
*/
function useFilterContextForList(listRef) {
	let context = import_react.useContext(FilterDropdownItemContext);
	if (listRef === null) return null;
	while (context !== null && context.listRef !== listRef) context = context.parent;
	return context;
}
var FilterDropdownValueContext = /*#__PURE__*/ import_react.createContext("");
FilterDropdownValueContext.displayName = "FilterDropdownValueContext";
function useFilterDropdownValueContext() {
	return import_react.useContext(FilterDropdownValueContext);
}
// node_modules/@base-ui/react/filter-dropdown/store.mjs
var selectors = {
	isEmpty: (state) => state.visibleItemIds === null ? state.registeredItemCount === 0 : state.visibleItemIds.size === 0,
	isItemVisible: (state, id) => state.visibleItemIds === null || state.visibleItemIds.has(id)
};
var FilterDropdownStore = class extends ReactStore {
	constructor() {
		super({
			visibleItemIds: null,
			registeredItemCount: 0
		}, EMPTY_OBJECT, selectors);
	}
};
/**
* Stand-in for an item whose owning dropdown is absent, such as a filterable submenu's trigger
* inside a plain parent menu. Nothing registers and every item stays visible.
*/
var DETACHED_OWNER = {
	registerItem: () => NOOP,
	store: new FilterDropdownStore()
};
// node_modules/@base-ui/react/filter-dropdown/root/FilterDropdownRoot.mjs
/**
* Holds the filter query, matches it against the registered items, and publishes the result. The
* host owns list navigation; this root moves the highlight through `setActiveIndex`.
*
* @internal
*/
function FilterDropdownRoot(props) {
	const { children, open, disabled = false, openedByKeyboard = false, locale, value, query, onValueChange, filter, autoHighlight = false, triggerId: triggerIdProp, listRef, getActiveIndex, setActiveIndex, focusOwnerRef: focusOwnerRefProp } = props;
	const parentItemContext = import_react.useContext(FilterDropdownItemContext);
	const [renderedListId, setRenderedListId] = import_react.useState(void 0);
	const [inputFocusVisible, setInputFocusVisible] = import_react.useState(openedByKeyboard);
	const [keyboardModality, setKeyboardModality] = import_react.useState(openedByKeyboard);
	const [previousOpenedByKeyboard, setPreviousOpenedByKeyboard] = import_react.useState(openedByKeyboard);
	if (openedByKeyboard !== previousOpenedByKeyboard) {
		setPreviousOpenedByKeyboard(openedByKeyboard);
		setInputFocusVisible(openedByKeyboard);
		setKeyboardModality(openedByKeyboard);
	}
	const { items: registeredItems, registerItem: registerInRegistry, liveItems } = useItemRegistry();
	const defaultId = useBaseUiId();
	const store = useRefWithInit(() => new FilterDropdownStore()).current;
	const registerItem = useStableCallback((id, item) => {
		const unregister = registerInRegistry(id, item);
		store.set("registeredItemCount", liveItems.size);
		return () => {
			unregister();
			store.set("registeredItemCount", liveItems.size);
		};
	});
	const fallbackFocusOwnerRef = import_react.useRef(null);
	const lastFilterQueryRef = import_react.useRef(null);
	const defaultMatchItem = import_react.useMemo(() => getFilter({ locale }).contains, [locale]);
	const focusOwnerRef = focusOwnerRefProp ?? fallbackFocusOwnerRef;
	const filterQuery = (query ?? value).trim();
	const matchItem = filterQuery === "" || filter === null ? null : filter ?? defaultMatchItem;
	const autoHighlightEnabled = open && (autoHighlight === "always" || autoHighlight && filterQuery !== "");
	const defaultListId = defaultId ? `${defaultId}-list` : void 0;
	const listId = (renderedListId ?? defaultListId) || void 0;
	const triggerId = triggerIdProp || void 0;
	const handleValueChange = useStableCallback((nextValue, eventDetails) => {
		onValueChange?.(nextValue, eventDetails);
		if (!eventDetails.isCanceled && !autoHighlight) setActiveIndex(null);
	});
	const handleItemsChange = useStableCallback((previousItems) => {
		const items = listRef.current;
		const activeIndex = getActiveIndex();
		if (activeIndex != null && items[activeIndex] != null && items[activeIndex] === previousItems[activeIndex]) return;
		setActiveIndex(autoHighlightEnabled && items.length > 0 ? 0 : null);
	});
	useIsoLayoutEffect(() => {
		if (!open && query === void 0) return;
		const queryChanged = lastFilterQueryRef.current !== null && lastFilterQueryRef.current !== filterQuery;
		lastFilterQueryRef.current = filterQuery;
		if (matchItem === null) {
			store.set("visibleItemIds", null);
			if (autoHighlightEnabled && liveItems.size > 0) {
				if (queryChanged || getActiveIndex() == null) setActiveIndex(0);
			} else if (filterQuery === "" && queryChanged) setActiveIndex(null);
			return;
		}
		const currentIds = store.state.visibleItemIds;
		if (currentIds === null && liveItems.size === 0) return;
		const nextIds = /* @__PURE__ */ new Set();
		let hasNewMatch = currentIds === null;
		liveItems.forEach(({ getText }, id) => {
			const text = getText();
			if (text != null && matchItem(text, filterQuery)) {
				nextIds.add(id);
				hasNewMatch ||= !currentIds?.has(id);
			}
		});
		if (hasNewMatch || currentIds?.size !== nextIds.size) {
			if (autoHighlightEnabled && nextIds.size > 0) setActiveIndex(0);
			else if (currentIds !== null || queryChanged) setActiveIndex(null);
			store.set("visibleItemIds", nextIds);
		} else if (autoHighlightEnabled && queryChanged && nextIds.size > 0) setActiveIndex(0);
	}, [
		open,
		query,
		filterQuery,
		registeredItems,
		liveItems,
		matchItem,
		autoHighlightEnabled,
		store,
		setActiveIndex,
		getActiveIndex
	]);
	const contextValue = import_react.useMemo(() => ({
		open,
		disabled,
		inputFocusVisible,
		setInputFocusVisible,
		keyboardModality,
		setKeyboardModality,
		autoHighlight,
		triggerId,
		defaultListId,
		listId,
		setRenderedListId,
		focusOwnerRef,
		setActiveIndex,
		onItemsChange: handleItemsChange,
		onValueChange: handleValueChange
	}), [
		open,
		disabled,
		inputFocusVisible,
		keyboardModality,
		autoHighlight,
		triggerId,
		defaultListId,
		listId,
		focusOwnerRef,
		setActiveIndex,
		handleItemsChange,
		handleValueChange
	]);
	const itemContextValue = import_react.useMemo(() => ({
		parent: parentItemContext,
		store,
		registerItem,
		listRef
	}), [
		parentItemContext,
		store,
		registerItem,
		listRef
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FilterDropdownItemContext.Provider, {
		value: itemContextValue,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FilterDropdownRootContext.Provider, {
			value: contextValue,
			children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FilterDropdownValueContext.Provider, {
				value: query ?? value,
				children
			})
		})
	});
}
// node_modules/@base-ui/react/filter-dropdown/root/useFilterDropdownCloseQuery.mjs
/**
* Clears the committed value when a filter popup closes while retaining the displayed query and
* filtered items until the exit transition completes.
*/
function useFilterDropdownCloseQuery(parameters) {
	const { open, mounted, value, onValueChange } = parameters;
	const [closeQuery, setCloseQuery] = import_react.useState(null);
	const previousOpenRef = import_react.useRef(open);
	useIsoLayoutEffect(() => {
		const wasOpen = previousOpenRef.current;
		previousOpenRef.current = open;
		if (wasOpen && !open && value !== "") {
			setCloseQuery(value);
			onValueChange("", createChangeEventDetails(popupClose));
		} else if ((open || !mounted) && closeQuery !== null) setCloseQuery(null);
	}, [
		open,
		mounted,
		value,
		closeQuery,
		onValueChange
	]);
	return !open && closeQuery !== null ? closeQuery : value;
}
// node_modules/@base-ui/react/filter-dropdown/utils/refocusOwner.mjs
var refocusing = false;
/**
* Hands focus back to the input that owns it while the user keeps interacting: the pointer entered
* its popup, or the list replays a key that landed on it. Focus handlers that run during the call
* see `isRefocusingOwner()` and treat the move as a continuation rather than the user leaving.
* A module-level flag suffices because `focus()` dispatches its events synchronously, and it also
* reaches the handlers of enclosing popups that a nested input's focus event bubbles through.
*/
function refocusOwner(owner) {
	refocusing = true;
	try {
		owner.focus({ preventScroll: true });
	} finally {
		refocusing = false;
	}
}
function isRefocusingOwner() {
	return refocusing;
}
// node_modules/@base-ui/react/menu/filter-root/useMenuFilterPopup.mjs
function useMenuFilterPopup(orientation) {
	const context = useFilterDropdownRootContext();
	const direction = useDirection();
	const { focusOwnerRef } = context;
	const nestedFocusRef = import_react.useRef(null);
	const pointerTypeRef = import_react.useRef("mouse");
	function trackPointerType(event) {
		pointerTypeRef.current = event.pointerType || "mouse";
	}
	import_react.useEffect(() => {
		if (context.open && focusOwnerRef.current === null) warn("A filterable menu opened without a <Menu.Input>. Render the input inside <Menu.Popup>, or drop <Menu.FilterProvider> for a menu that does not filter.");
	}, [context.open, focusOwnerRef]);
	function restoreInputFocus(event, enteredTrigger) {
		const focusOwner = focusOwnerRef.current;
		if (!context.open || !focusOwner) return;
		const activeEl = activeElement(ownerDocument(event.currentTarget));
		if (activeEl === focusOwner || contains(event.currentTarget, activeEl)) return;
		let submenuTrigger = null;
		if (event.nativeEvent.composedPath().find((node) => {
			if (!isHTMLElement(node)) return false;
			if (node.getAttribute("role") === "dialog" || node.hasAttribute("data-rootownerid")) return true;
			if (node.hasAttribute("aria-haspopup")) submenuTrigger = node;
			return false;
		}) !== event.currentTarget) return;
		if (nestedFocusRef.current && !(enteredTrigger && submenuTrigger)) return;
		if (enteredTrigger && submenuTrigger && isElement(event.relatedTarget) && contains(submenuTrigger, event.relatedTarget)) return;
		refocusOwner(focusOwner);
	}
	return {
		"aria-activedescendant": void 0,
		"aria-orientation": void 0,
		onMouseDown(event) {
			if (getTarget(event.nativeEvent) === event.currentTarget) event.preventDefault();
		},
		onPointerDown: trackPointerType,
		onPointerOver: trackPointerType,
		onPointerMove: trackPointerType,
		onMouseMove(event) {
			if (pointerTypeRef.current === "mouse") restoreInputFocus(event, false);
		},
		onMouseOver(event) {
			if (pointerTypeRef.current === "mouse" && nestedFocusRef.current) restoreInputFocus(event, true);
		},
		onFocus(event) {
			const target = getTarget(event.nativeEvent);
			if (target === focusOwnerRef.current) nestedFocusRef.current = null;
			else if (isHTMLElement(target) && !contains(event.currentTarget, target) && !isRefocusingOwner()) nestedFocusRef.current = target;
			if (context.open && target === event.currentTarget) focusOwnerRef.current?.focus({ preventScroll: true });
		},
		onKeyDown(event) {
			const target = getTarget(event.nativeEvent);
			if (target === focusOwnerRef.current || isTypeableElement(target)) return;
			if (isCrossOrientationCloseKey(event.key, orientation, direction === "rtl", false)) {
				focusOwnerRef.current?.focus({ preventScroll: true });
				event.stopPropagation();
			}
		}
	};
}
// node_modules/@base-ui/react/menu/filter-root/MenuFilterPopup.mjs
/**
* A container for the filter input and item list.
* Renders a `<div>` element with a `dialog` role.
*/
var MenuFilterPopup = /*#__PURE__*/ import_react.forwardRef(function MenuFilterPopup(props, forwardedRef) {
	const { store, orientation } = useMenuRootContext();
	const open = store.useState("open");
	const parent = store.useState("parent");
	const openMethod = store.useState("openMethod");
	const lastOpenChangeReason = store.useState("lastOpenChangeReason");
	const interactionProps = useMenuFilterPopup(orientation);
	const openedByHover = open && lastOpenChangeReason === "trigger-hover";
	const mayFocusInput = parent.type !== "menu" || open && (openMethod === "keyboard" || lastOpenChangeReason === "list-navigation" || lastOpenChangeReason === "trigger-hover" || lastOpenChangeReason === "trigger-press");
	let initialFocus = false;
	if (mayFocusInput) initialFocus = () => {
		const touchOpen = (openMethod === "touch" || openMethod === "pen") && !store.context.virtualPress;
		if (openedByHover || touchOpen) return false;
		return store.context.virtualFocusRef?.current ?? false;
	};
	const popupProps = mergeProps(interactionProps, props);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuPopupPlain, {
		...popupProps,
		role: "dialog",
		initialFocus,
		ref: forwardedRef
	});
});
MenuFilterPopup.displayName = "MenuFilterPopup";
// node_modules/@base-ui/react/filter-dropdown/group/FilterDropdownGroupContext.mjs
var FilterDropdownGroupContext = /*#__PURE__*/ import_react.createContext(null);
FilterDropdownGroupContext.displayName = "FilterDropdownGroupContext";
function useFilterDropdownGroupContext() {
	return import_react.useContext(FilterDropdownGroupContext);
}
// node_modules/@base-ui/react/filter-dropdown/list/FilterDropdownList.mjs
/**
* @internal
*/
var FilterDropdownList = /*#__PURE__*/ import_react.forwardRef(function FilterDropdownList(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, ...elementProps } = componentProps;
	const context = useFilterDropdownRootContext();
	const [id, registerIdRef] = useRenderedId(componentProps, context.defaultListId, context.setRenderedListId);
	return useRenderElement("div", componentProps, {
		ref: [forwardedRef, registerIdRef],
		props: [
			{
				tabIndex: -1,
				id,
				onFocus(event) {
					const owner = context.focusOwnerRef.current;
					if (owner && event.relatedTarget === owner && getTarget(event.nativeEvent) === event.currentTarget) refocusOwner(owner);
				},
				onPointerMove() {
					context.setKeyboardModality(false);
				},
				onPointerDown() {
					context.setKeyboardModality(false);
				}
			},
			elementProps,
			{ children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FilterDropdownGroupContext.Provider, {
				value: null,
				children: elementProps.children
			}) }
		]
	});
});
FilterDropdownList.displayName = "FilterDropdownList";
// node_modules/@base-ui/react/menu/filter-root/useMenuFilterKeyDown.mjs
/**
* Decides what a key does while the filter input owns the keyboard.
*/
function getMenuFilterKeyAction(event, context) {
	const { orientation, rtl, hasActiveItem, activeItemOpensSubmenu, hasValue } = context;
	const { key } = event;
	if (event.which === 229) return "ignore";
	if (key === "Tab") return event.shiftKey ? "close" : "ignore";
	if (key === "Enter") return hasActiveItem ? "activate" : "navigate";
	const isArrow = key.startsWith("Arrow");
	const isBoundary = key === "Home" || key === "End";
	if (event.shiftKey || event.ctrlKey || event.altKey || event.metaKey) return isArrow || isBoundary || key.length === 1 ? "edit" : "navigate";
	if (key.length === 1) return "edit";
	if (isBoundary) return hasActiveItem && !hasValue ? "navigate" : "edit";
	if (!isArrow) return "navigate";
	if (isMainOrientationKey(key, orientation)) return orientation === "horizontal" && !hasActiveItem && hasValue ? "edit" : "navigate";
	if (activeItemOpensSubmenu && (isCrossOrientationOpenKey(key, orientation, rtl) || isCrossOrientationCloseKey(key, orientation, rtl, false))) return "submenu";
	if (orientation === "horizontal" && !hasActiveItem) return "enter-list";
	return hasValue ? "edit" : "navigate";
}
/**
* Routes keys for a filterable menu's input, which holds real focus while the list is navigated
* with `aria-activedescendant`. Keys reaching the input, and those an item that received real
* focus from assistive technology hands back, go through here; the trigger relays only the
* vertical arrows while the popup is open. Navigation runs the menu's own `useListNavigation`
* handler directly.
*/
function useMenuFilterKeyDown(hasValue) {
	const { orientation, store } = useMenuRootContext();
	const submenuContext = useMenuSubmenuRootContext();
	const direction = useDirection();
	return useStableCallback((event) => {
		if (!store.select("open")) return;
		const activeItem = store.state.highlightedItem;
		switch (getMenuFilterKeyAction(event, {
			orientation,
			rtl: direction === "rtl",
			hasActiveItem: activeItem != null,
			activeItemOpensSubmenu: activeItem?.hasAttribute("aria-haspopup") ?? false,
			hasValue
		})) {
			case "edit":
				event.stopPropagation();
				if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) store.state.inputProps.onKeyDown?.(event);
				break;
			case "navigate":
				if (isMainOrientationKey(event.key, orientation)) event.stopPropagation();
				store.state.inputProps.onKeyDown?.(event);
				break;
			case "enter-list": {
				event.stopPropagation();
				const listRef = store.context.itemDomElements;
				const index = event.key === "ArrowDown" ? getMinListIndex(listRef, EMPTY_ARRAY) : getMaxListIndex(listRef, EMPTY_ARRAY);
				if (listRef.current[index]) {
					event.preventDefault();
					store.setActiveIndex(index, keyboard, event.nativeEvent);
				}
				break;
			}
			case "submenu": {
				stopEvent(event);
				const KeyboardEventConstructor = getWindow(activeItem).KeyboardEvent;
				activeItem.dispatchEvent(new KeyboardEventConstructor(event.type, event.nativeEvent));
				break;
			}
			case "activate":
				event.preventDefault();
				dispatchClickWithModifiers(activeItem, event);
				break;
			case "close": {
				stopEvent(event);
				const returnElement = store.state.parent.type === "menu" && submenuContext?.getReturnElement?.() || store.state.activeTriggerElement;
				const details = createChangeEventDetails(focusOut, event.nativeEvent);
				store.setOpen(false, details);
				if (!details.isCanceled && isHTMLElement(returnElement)) returnElement.focus();
				break;
			}
		}
	});
}
// node_modules/@base-ui/react/menu/filter-root/moveHighlightFrom.mjs
/**
* Moves a menu's highlight from `item` one step in the direction of a main-orientation arrow key,
* with the same step as the menu's own list navigation, and returns the newly highlighted item.
* A step that would leave a menu whose navigation escapes to its input keeps the highlight.
*/
function moveHighlightFrom(store, item, event, options) {
	const { orientation, rtl, loopFocus, allowEscape } = options;
	const listRef = store.context.itemDomElements;
	const items = listRef.current;
	const { index } = getNextListIndex(items, items.indexOf(item), {
		decrement: !isMainOrientationToEndKey(event.key, orientation, rtl),
		loopFocus,
		allowEscape,
		disabledIndices: EMPTY_ARRAY,
		minIndex: getMinListIndex(listRef, EMPTY_ARRAY),
		maxIndex: getMaxListIndex(listRef, EMPTY_ARRAY)
	});
	const next = items[index];
	if (next) {
		store.setActiveIndex(index, keyboard, event.nativeEvent);
		next.scrollIntoView?.({
			block: "nearest",
			inline: "nearest"
		});
	}
	return next ?? void 0;
}
// node_modules/@base-ui/react/menu/filter-root/MenuFilterList.mjs
/**
* The list of a filterable menu: it takes the `menu` role while the popup is a dialog holding
* the input, and it forwards keys that land on it to the input.
*/
var MenuFilterList = /*#__PURE__*/ import_react.forwardRef(function MenuFilterList(componentProps, forwardedRef) {
	const { store, orientation, loopFocus, allowEscape } = useMenuRootContext();
	const direction = useDirection();
	const { onItemsChange, focusOwnerRef, triggerId } = useFilterDropdownRootContext();
	const { listRef } = useFilterDropdownItemContext();
	const { subscribeMapChange } = useCompositeListContext();
	const handleInputKeyDown = useMenuFilterKeyDown(useFilterDropdownValueContext() !== "");
	const handleKeyDown = useStableCallback((event) => {
		const owner = focusOwnerRef.current;
		const target = getTarget(event.nativeEvent);
		const ownerFocused = owner != null && activeElement(ownerDocument(owner)) === owner;
		const fromNestedPopup = !contains(event.currentTarget, target);
		if (owner == null || ownerFocused || fromNestedPopup) {
			if (event.which !== 229 && !event.shiftKey && !event.ctrlKey && !event.metaKey && !event.altKey && isMainOrientationKey(event.key, orientation)) {
				event.stopPropagation();
				const trigger = fromNestedPopup && ownerFocused ? getNestedPopupTrigger(target) : void 0;
				if (trigger) moveHighlightFrom(store, trigger, event, {
					orientation,
					rtl: direction === "rtl",
					loopFocus,
					allowEscape
				});
			}
			return;
		}
		if (event.defaultPrevented) return;
		refocusOwner(owner);
		handleInputKeyDown(event);
	});
	function getNestedPopupTrigger(target) {
		const root = target.getRootNode();
		return listRef.current.find((item) => {
			const popupId = item?.getAttribute("aria-controls");
			return popupId != null && isHTMLElement(item) && contains(root.getElementById(popupId), target);
		});
	}
	const previousItemsRef = import_react.useRef(null);
	const handleItemMapChange = useStableCallback(() => {
		const items = [...listRef.current];
		const previousItems = previousItemsRef.current;
		if ((previousItems === null || previousItems.length !== items.length || items.some((item, index) => item !== previousItems[index])) && previousItems !== null) onItemsChange(previousItems);
		previousItemsRef.current = items;
	});
	useIsoLayoutEffect(() => {
		return subscribeMapChange(handleItemMapChange);
	}, [subscribeMapChange, handleItemMapChange]);
	const ariaLabelledBy = resolvePopupLabel(componentProps, null, triggerId ?? null);
	const listProps = mergeProps({
		role: "menu",
		"aria-labelledby": ariaLabelledBy,
		"aria-orientation": orientation === "horizontal" ? "horizontal" : void 0,
		onKeyDown: handleKeyDown
	}, componentProps);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FilterDropdownList, {
		...listProps,
		ref: forwardedRef
	});
});
MenuFilterList.displayName = "MenuFilterList";
// node_modules/@base-ui/react/filter-dropdown/group/useFilterDropdownGroup.mjs
function isGroupHidden(state, items) {
	if (state.visibleItemIds === null || items.size === 0) return false;
	for (const [id, retained] of items) if (retained || state.visibleItemIds.has(id)) return false;
	return true;
}
/**
* Tracks which items belong to a group and hides the group once none of them match.
*
* @internal
*/
function useFilterDropdownGroup() {
	const { store } = useFilterDropdownItemContext();
	const parentContext = useFilterDropdownGroupContext();
	const { items, registerItem } = useItemRegistry();
	const hidden = useStore(store, isGroupHidden, items);
	const groupId = useRefWithInit(() => Symbol("filter-dropdown-group")).current;
	const registerInParent = parentContext?.registerItem;
	useIsoLayoutEffect(() => registerInParent?.(groupId, !hidden), [
		registerInParent,
		groupId,
		hidden
	]);
	return {
		hidden,
		context: import_react.useMemo(() => ({ registerItem }), [registerItem])
	};
}
// node_modules/@base-ui/react/menu/filter-root/MenuFilterGroup.mjs
/**
* `Menu.Group` in a filterable menu: hidden, label included, once the query filters out all of
* its items.
*
* @internal
*/
var MenuFilterGroup = /*#__PURE__*/ import_react.forwardRef(function MenuFilterGroup(props, forwardedRef) {
	const { hidden, context } = useFilterDropdownGroup();
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FilterDropdownGroupContext.Provider, {
		value: context,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuGroupPlain, {
			...props,
			hidden: hidden || props.hidden || void 0,
			ref: forwardedRef
		})
	});
});
MenuFilterGroup.displayName = "MenuFilterGroup";
var MenuFilterRadioGroup = /*#__PURE__*/ import_react.forwardRef(function MenuFilterRadioGroup(props, forwardedRef) {
	const { hidden, context } = useFilterDropdownGroup();
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FilterDropdownGroupContext.Provider, {
		value: context,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuRadioGroupPlain, {
			...props,
			hidden: hidden || props.hidden || void 0,
			ref: forwardedRef
		})
	});
});
MenuFilterRadioGroup.displayName = "MenuFilterRadioGroup";
// node_modules/@base-ui/react/filter-dropdown/item/useFilterDropdownItem.mjs
/** Text of the rendered children, for when the element is filtered out and has no DOM node. */
function childrenText(children) {
	if (typeof children === "string" || typeof children === "number") return String(children);
	if (Array.isArray(children)) return children.map(childrenText).join("");
	if (/*#__PURE__*/ import_react.isValidElement(children)) return childrenText(children.props.children);
	return "";
}
/**
* Registers an item with the enclosing filter root and reports whether the query keeps it.
*
* The item renders once before it is registered so its rendered text can be read and cached: a
* popup can open with a query that already excludes the item, and a hidden item has no text left
* to match against.
*
* @internal
*/
function useFilterDropdownItem(params) {
	const { label, retainGroup = false, children, render, context } = params;
	const nearestContext = useFilterDropdownItemContext(context !== void 0);
	const groupContext = useFilterDropdownGroupContext();
	const { registerItem, store } = (context === void 0 ? nearestContext : context) ?? DETACHED_OWNER;
	const registerGroupItem = groupContext?.registerItem;
	const itemId = useRefWithInit(() => Symbol("filter-dropdown-item")).current;
	const ref = import_react.useRef(null);
	const registeredTextRef = import_react.useRef(void 0);
	const matched = useStore(store, selectors.isItemVisible, itemId);
	const [registered, setRegistered] = import_react.useState(matched);
	const childrenRef = useValueAsRef(children);
	const renderRef = useValueAsRef(render);
	const childrenTextRef = import_react.useRef(void 0);
	const resolveText = import_react.useCallback(() => {
		if (label != null) return label;
		const fromChildren = childrenText(childrenRef.current ?? unwrapLazyRenderProp(renderRef.current));
		const previousChildrenText = childrenTextRef.current;
		childrenTextRef.current = fromChildren;
		if (ref.current !== null) return ref.current.textContent ?? "";
		if (registeredTextRef.current !== void 0 && fromChildren === previousChildrenText) return registeredTextRef.current;
		return fromChildren;
	}, [
		label,
		childrenRef,
		renderRef
	]);
	const register = import_react.useCallback((resolvedText) => {
		const text = resolvedText ?? resolveText();
		if (text) registeredTextRef.current = text;
		return registerItem(itemId, { getText() {
			if (label == null && ref.current) registeredTextRef.current = ref.current.textContent ?? "";
			return registeredTextRef.current;
		} });
	}, [
		itemId,
		label,
		registerItem,
		resolveText
	]);
	useIsoLayoutEffect(() => {
		const unregister = register();
		setRegistered(true);
		return unregister;
	}, [register]);
	useIsoLayoutEffect(() => registerGroupItem?.(itemId, retainGroup), [
		registerGroupItem,
		itemId,
		retainGroup
	]);
	useIsoLayoutEffect(() => {
		const text = resolveText();
		if (text !== registeredTextRef.current) {
			registeredTextRef.current = text;
			register(text);
		}
	}, [
		register,
		resolveText,
		children,
		render,
		label
	]);
	return {
		visible: !registered || matched,
		ref
	};
}
// node_modules/@base-ui/react/menu/filter-root/useMenuFilterSubmenuTrigger.mjs
/**
* Registers a submenu trigger with the parent menu's filter and adapts it to a filterable
* submenu: the trigger lives inside its own submenu root, but it is an item of the parent list.
*/
function useMenuFilterSubmenuTrigger(params) {
	const { store, virtualFocus } = useMenuRootContext();
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const parent = store.useState("parent");
	const parentContext = useFilterContextForList(parent.type === "menu" ? parent.store.context.itemDomElements : null);
	const { visible, ref } = useFilterDropdownItem({
		...params,
		context: parentContext,
		retainGroup: mounted
	});
	useIsoLayoutEffect(() => {
		if (visible || !open) return;
		store.setOpen(false, createChangeEventDetails(none));
	}, [
		visible,
		open,
		store
	]);
	const clickProps = useEnhancedClickHandler((event, interactionType) => {
		if (event.type === "click" && store.select("open") && (interactionType === "keyboard" || interactionType === "mouse" && store.select("lastOpenChangeReason") === "trigger-press")) store.context.virtualFocusRef?.current?.focus({ preventScroll: true });
	});
	const props = {
		...virtualFocus ? { "aria-haspopup": "dialog" } : void 0,
		...clickProps,
		onPointerDown(event) {
			clickProps.onPointerDown(event);
			store.context.virtualPress = isVirtualPointerEvent(event.nativeEvent);
		},
		onFocus(event) {
			const focusOwner = store.context.virtualFocusRef?.current;
			if (focusOwner && store.select("open") && event.relatedTarget === focusOwner) {
				event.preventBaseUIHandler();
				focusOwner.focus({ preventScroll: true });
			}
		}
	};
	if (parentContext === null) return {
		visible: true,
		ref: null,
		props
	};
	return {
		visible: visible || mounted,
		ref,
		props
	};
}
// node_modules/@base-ui/react/menu/filter-root/useVirtualFocusParentHandoff.mjs
/**
* A plain submenu whose parent is filterable. The parent keeps real focus on its input, so its
* trigger never blurs and its return focus waits for this popup's exit animation. The submenu
* hands focus and the parent's highlight back itself.
*/
function useVirtualFocusParentHandoff(store, parent, open, virtualFocus) {
	const parentStore = parent.type === "menu" ? parent.store : null;
	const parentVirtualFocusRef = parentStore?.context.virtualFocusRef;
	const returnToParent = useStableCallback((trigger, reason) => {
		const focusOwner = parentVirtualFocusRef?.current;
		if (virtualFocus || store.select("open") || !parentStore?.select("open") || !focusOwner) return;
		if (contains(store.context.popupRef.current, activeElement(ownerDocument(focusOwner)))) focusOwner.focus({ preventScroll: true });
		if ((reason === "list-navigation" || reason === "escape-key") && parentStore.state.activeIndex == null) parentStore.highlightItem(trigger, none);
	});
	useIsoLayoutEffect(() => {
		if (!open) {
			const trigger = store.state.activeTriggerElement;
			const reason = store.select("lastOpenChangeReason");
			queueMicrotask(() => returnToParent(trigger, reason));
		}
	}, [
		open,
		store,
		returnToParent
	]);
	function handleFocus() {
		if (!virtualFocus && parentVirtualFocusRef && parentStore?.state.activeIndex != null) parentStore.setActiveIndex(null, none);
	}
	return {
		parentVirtualFocusRef,
		handleFocus
	};
}
// node_modules/@base-ui/react/menu/filter-root/MenuFilterImpl.mjs
var MENU_FILTER_IMPL = {
	Popup: MenuFilterPopup,
	List: MenuFilterList,
	Group: MenuFilterGroup,
	RadioGroup: MenuFilterRadioGroup,
	useItem: useFilterDropdownItem,
	useSubmenuTrigger: useMenuFilterSubmenuTrigger,
	useParentHandoff: useVirtualFocusParentHandoff
};
// node_modules/@base-ui/react/menu/filter-root/MenuFilterDropdown.mjs
/**
* Reads the menu store, which is only available below the menu root, and hands the filter
* engine the list the menu navigates and the command that moves its highlight. The query is
* owned here; the menu root keeps sole ownership of the open state.
*/
function MenuFilterDropdown(props) {
	const { value: valueProp, defaultValue = "", onValueChange, ...dropdownProps } = props;
	const { store } = useMenuRootContext();
	const open = store.useState("open");
	const mounted = store.useState("mounted");
	const keyboardOpen = store.useState("keyboardOpen");
	const activeTriggerId = store.useState("activeTriggerId");
	const activeTriggerElement = store.useState("activeTriggerElement");
	const disabled = store.useState("disabled");
	const [value, setValue] = useControlled({
		controlled: valueProp,
		default: defaultValue,
		name: "MenuFilterProvider",
		state: "value"
	});
	const handleValueChange = useStableCallback((nextValue, eventDetails) => {
		onValueChange?.(nextValue, eventDetails);
		if (!eventDetails.isCanceled) setValue(nextValue);
	});
	const getActiveIndex = useStableCallback(() => store.state.activeIndex);
	const setActiveIndex = useStableCallback((index) => {
		store.setActiveIndex(index, none);
	});
	const query = useFilterDropdownCloseQuery({
		open,
		mounted,
		value,
		onValueChange: handleValueChange
	});
	const filterTriggerProps = useFilterTriggerProps(value !== "");
	useRefWithInit(() => {
		store.set("filterTriggerProps", filterTriggerProps);
		return null;
	});
	store.useSyncedValue("filterTriggerProps", filterTriggerProps);
	useIsoLayoutEffect(() => {
		if (!open) store.set("keyboardOpen", false);
	}, [open, store]);
	const triggerId = activeTriggerElement ? activeTriggerElement.id || null : activeTriggerId;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuFilterImplContext.Provider, {
		value: MENU_FILTER_IMPL,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FilterDropdownRoot, {
			...dropdownProps,
			open,
			openedByKeyboard: keyboardOpen,
			disabled,
			value,
			query,
			onValueChange: handleValueChange,
			triggerId,
			listRef: store.context.itemDomElements,
			getActiveIndex,
			setActiveIndex,
			focusOwnerRef: store.context.virtualFocusRef
		})
	});
}
/**
* The props a filterable menu adds to its triggers: dialog semantics, screen reader press
* tracking, and a relay of list navigation typed on the trigger to the input, since the input
* holds real focus while the popup is open.
*/
function useFilterTriggerProps(hasValue) {
	const { store } = useMenuRootContext();
	const isInMenubar = useMenubarContext(true) != null;
	const handleInputKeyDown = useMenuFilterKeyDown(hasValue);
	return import_react.useMemo(() => ({
		"aria-haspopup": "dialog",
		onPointerDown(event) {
			store.context.virtualPress = isVirtualPointerEvent(event.nativeEvent);
		},
		onKeyDown(event) {
			const focusOwner = store.context.virtualFocusRef?.current;
			if (!store.select("open") || !focusOwner || isInMenubar) return;
			if (event.key === "ArrowUp" || event.key === "ArrowDown") {
				focusOwner.focus({ preventScroll: true });
				handleInputKeyDown(event);
				event.preventDefault();
				event.preventBaseUIHandler();
			} else if (event.key === "ArrowLeft" || event.key === "ArrowRight") event.preventBaseUIHandler();
			else if (isTypeaheadKey(event)) focusOwner.focus({ preventScroll: true });
		}
	}), [
		store,
		isInMenubar,
		handleInputKeyDown
	]);
}
function isTypeaheadKey(event) {
	return event.key.length === 1 && event.key !== " " && !event.ctrlKey && !event.metaKey && !event.altKey;
}
// node_modules/@base-ui/react/menu/filter-root/useMenuFilterRoot.mjs
/** Splits a filterable root's props between the menu root and the filter below it. */
function useMenuFilterRoot(props) {
	const { children, value, defaultValue, onValueChange, filter, autoHighlight = false, locale, ...otherProps } = props;
	const virtualFocusRef = import_react.useRef(null);
	return {
		children,
		rootProps: {
			...otherProps,
			virtualFocus: true,
			virtualFocusRef,
			allowEscape: !autoHighlight,
			resetOnPointerLeave: autoHighlight !== "always"
		},
		dropdownProps: {
			value,
			defaultValue,
			onValueChange,
			filter,
			autoHighlight,
			locale
		}
	};
}
// node_modules/@base-ui/react/menu/filter-root/MenuFilterRoot.mjs
/**
* The filterable implementation of `Menu.Root`, rendered in its place when the root sits inside
* `Menu.FilterProvider`. Reached through the provider only, so a plain menu never bundles it.
*
* @internal
*/
function MenuFilterRoot(props) {
	const { children, rootProps, dropdownProps } = useMenuFilterRoot(props);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuRootInternal, {
		...rootProps,
		children: (payload) => /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuFilterDropdown, {
			...dropdownProps,
			children: typeof children === "function" ? children(payload) : children
		})
	});
}
// node_modules/@base-ui/react/menu/filter-submenu-root/MenuFilterSubmenuRoot.mjs
/**
* The filterable implementation of `Menu.SubmenuRoot`, rendered in its place when the submenu
* root sits inside `Menu.FilterProvider`.
*
* @internal
*/
function MenuFilterSubmenuRoot(props) {
	const parent = useMenuRootContext();
	const parentStore = parent.store;
	const parentDisabled = parentStore.useState("disabled");
	const { rootProps, dropdownProps } = useMenuFilterRoot(props);
	const parentReferenceRef = import_react.useRef(null);
	function handleSubmenuEnter(trigger, event) {
		const focusedElement = parent.virtualFocus ? parentStore.context.virtualFocusRef?.current : activeElement(ownerDocument(trigger));
		if (isHTMLElement(focusedElement)) {
			parentReferenceRef.current = {
				reference: focusedElement,
				trigger
			};
			parentStore.setActiveIndex(null, event ? keyboard : none, event);
		}
	}
	function highlightTrigger(trigger, event) {
		parentStore.highlightItem(trigger, keyboard, event);
	}
	function handleSubmenuExit(event) {
		const parentReference = parentReferenceRef.current;
		if (!parentReference) return;
		parentReference.reference.focus({ preventScroll: true });
		highlightTrigger(parentReference.trigger, event);
	}
	function handleOpenChange(nextOpen, details) {
		rootProps.onOpenChange?.(nextOpen, details);
		if (details.isCanceled) return;
		if (!nextOpen) {
			if (details.reason === "escape-key" && isHTMLElement(details.trigger)) {
				highlightTrigger(details.trigger, details.event);
				parentReferenceRef.current = {
					reference: parent.virtualFocus ? parentStore.context.virtualFocusRef?.current ?? details.trigger : details.trigger,
					trigger: details.trigger
				};
			}
			return;
		}
		parentReferenceRef.current = null;
		if (isHTMLElement(details.trigger) && isKeyboardOpen(details.reason, details.event)) handleSubmenuEnter(details.trigger, details.reason === "list-navigation" ? details.event : void 0);
	}
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuRootInternal, {
		...rootProps,
		isSubmenu: true,
		disabled: parentDisabled || props.disabled,
		onOpenChange: handleOpenChange,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuFilterSubmenuNavigation, {
			parentStore,
			parentVirtualFocus: parent.virtualFocus,
			parentAllowEscape: parent.virtualFocus && parent.allowEscape,
			parentOrientation: parent.orientation,
			parentLoopFocus: parent.loopFocus,
			getReturnElement: () => parentReferenceRef.current?.reference ?? (parent.virtualFocus ? parentStore.context.virtualFocusRef?.current : null) ?? null,
			onSubmenuEnter: handleSubmenuEnter,
			onSubmenuExit: handleSubmenuExit,
			children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuFilterDropdown, {
				...dropdownProps,
				children: props.children
			})
		})
	});
}
function MenuFilterSubmenuNavigation(props) {
	const { children, parentStore, parentVirtualFocus, parentAllowEscape, parentOrientation, parentLoopFocus, onSubmenuEnter, onSubmenuExit, getReturnElement } = props;
	const { store, orientation } = useMenuRootContext();
	const direction = useDirection();
	const mounted = store.useState("mounted");
	const wasMountedRef = import_react.useRef(false);
	const handleReturnFocus = useStableCallback(() => {
		const [ownTrigger] = store.context.triggerElements.elements();
		return getReturnElement() ?? (isHTMLElement(ownTrigger) ? ownTrigger : null);
	});
	useIsoLayoutEffect(() => {
		const wasMounted = wasMountedRef.current;
		wasMountedRef.current = mounted;
		if (mounted || !wasMounted) return;
		const returnElement = handleReturnFocus();
		if (!returnElement || !parentStore.select("open")) return;
		const doc = ownerDocument(returnElement);
		const activeEl = activeElement(doc);
		if (activeEl === doc.body || contains(store.select("popupElement"), activeEl)) returnElement.focus({ preventScroll: true });
	}, [
		mounted,
		store,
		parentStore,
		handleReturnFocus
	]);
	function moveInParent(from, event) {
		const item = moveHighlightFrom(parentStore, from, event, {
			orientation: parentOrientation,
			rtl: direction === "rtl",
			loopFocus: parentLoopFocus,
			allowEscape: parentAllowEscape
		});
		if (!parentVirtualFocus) item?.focus({ preventScroll: true });
	}
	function close(event) {
		if (!store.select("open")) return;
		stopEvent(event);
		const trigger = store.select("activeTriggerElement");
		const eventDetails = createChangeEventDetails(listNavigation, event.nativeEvent);
		store.setOpen(false, eventDetails);
		if (!eventDetails.isCanceled) onSubmenuExit(event.nativeEvent);
		const returnElement = getReturnElement() ?? store.select("activeTriggerElement");
		if (!store.select("open") && isHTMLElement(returnElement) && activeElement(ownerDocument(returnElement)) !== returnElement) returnElement.focus();
		if (!store.select("open") && isHTMLElement(trigger) && isMainOrientationKey(event.key, parentOrientation)) moveInParent(trigger, event);
	}
	const handleTriggerKeyDown = useStableCallback((event) => {
		if (isMainOrientationKey(event.key, parentOrientation)) {
			moveInParent(event.currentTarget, event);
			event.preventBaseUIHandler();
			stopEvent(event);
			return;
		}
		const open = store.select("open");
		const isRtl = direction === "rtl";
		const isCloseKey = isCrossOrientationCloseKey(event.key, orientation, isRtl, false);
		if (open && isCloseKey) {
			close(event);
			return;
		}
		if (!isCrossOrientationOpenKey(event.key, parentOrientation, isRtl)) return;
		stopEvent(event);
		if (open) {
			onSubmenuEnter(event.currentTarget, event.nativeEvent);
			store.context.virtualFocusRef?.current?.focus({ preventScroll: true });
			return;
		}
		store.setOpen(true, createChangeEventDetails(listNavigation, event.nativeEvent, event.currentTarget));
	});
	const handlePopupKeyDown = useStableCallback((event) => {
		if (event.which === 229) return;
		if (isCrossOrientationCloseKey(event.key, orientation, direction === "rtl", false)) close(event);
	});
	const contextValue = import_react.useMemo(() => ({
		getReturnElement: handleReturnFocus,
		onTriggerKeyDown: handleTriggerKeyDown,
		onPopupKeyDown: handlePopupKeyDown
	}), [
		handleReturnFocus,
		handleTriggerKeyDown,
		handlePopupKeyDown
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuSubmenuRootContext.Provider, {
		value: contextValue,
		children
	});
}
// node_modules/@base-ui/react/menu/filter-provider/MenuFilterProvider.mjs
/**
* Enables filtering for the menu or submenu it wraps. Add `Menu.Input` to the popup and place
* its items in `Menu.List`.
* Wrap each searchable submenu in its own provider.
* Doesn't render its own HTML element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
function MenuFilterProvider(props) {
	const { children, filter, value, defaultValue, onValueChange, autoHighlight, locale } = props;
	const contextValue = import_react.useMemo(() => ({
		Root: MenuFilterRoot,
		SubmenuRoot: MenuFilterSubmenuRoot,
		options: {
			filter,
			value,
			defaultValue,
			onValueChange,
			autoHighlight,
			locale
		}
	}), [
		filter,
		value,
		defaultValue,
		onValueChange,
		autoHighlight,
		locale
	]);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(MenuFilterProviderContext.Provider, {
		value: contextValue,
		children
	});
}
// node_modules/@base-ui/react/filter-dropdown/input/FilterDropdownInput.mjs
/**
* @internal
*/
var FilterDropdownInput = /*#__PURE__*/ import_react.forwardRef(function FilterDropdownInput(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, disabled, activeItemId, navigationProps, ...elementProps } = componentProps;
	const id = useBaseUiId(idProp);
	const context = useFilterDropdownRootContext();
	const { listRef } = useFilterDropdownItemContext();
	const value = useFilterDropdownValueContext();
	const [composingValue, setComposingValue] = import_react.useState(null);
	const isComposingRef = import_react.useRef(false);
	function commitValue(nextValue, nativeEvent) {
		if (!context.open) return;
		const reason = nextValue === "" ? inputClear : inputChange;
		context.onValueChange(nextValue, createChangeEventDetails(reason, nativeEvent));
	}
	const state = { highlighted: context.inputFocusVisible && (!context.keyboardModality || activeItemId == null) };
	return useRenderElement("input", componentProps, {
		state,
		ref: [forwardedRef, context.focusOwnerRef],
		props: [
			navigationProps,
			{
				id,
				type: "text",
				disabled: context.disabled || disabled,
				"aria-activedescendant": activeItemId,
				role: "searchbox",
				inputMode: "search",
				autoComplete: "off",
				spellCheck: "false",
				autoCorrect: "off",
				autoCapitalize: "none",
				"aria-autocomplete": void 0,
				"aria-controls": context.listId,
				value: composingValue ?? value,
				onCompositionStart(event) {
					if (android) return;
					isComposingRef.current = true;
					setComposingValue(event.currentTarget.value);
				},
				onCompositionEnd(event) {
					if (!isComposingRef.current) return;
					isComposingRef.current = false;
					setComposingValue(null);
					commitValue(event.currentTarget.value, event.nativeEvent);
				},
				onChange(event) {
					if (isComposingRef.current) {
						setComposingValue(event.currentTarget.value);
						return;
					}
					commitValue(event.currentTarget.value, event.nativeEvent);
				},
				onKeyDown() {
					context.setKeyboardModality(true);
				},
				onPointerDown() {
					context.setKeyboardModality(false);
				},
				onMouseEnter(event) {
					context.setKeyboardModality(false);
					if (context.open) refocusOwner(event.currentTarget);
				},
				onFocus(event) {
					context.setInputFocusVisible(true);
					if (context.autoHighlight === "always" || isRefocusingOwner()) return;
					const from = event.relatedTarget;
					if (from !== null && listRef.current.includes(from)) context.setActiveIndex(null);
				},
				onBlur() {
					context.setInputFocusVisible(false);
				}
			},
			elementProps
		]
	});
});
FilterDropdownInput.displayName = "FilterDropdownInput";
// node_modules/@base-ui/react/menu/input/MenuInput.mjs
/**
* A search field that filters the menu items.
* Requires the menu to be wrapped in `Menu.FilterProvider`.
* Renders an `<input>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuInput = /*#__PURE__*/ import_react.forwardRef(function MenuInput(componentProps, forwardedRef) {
	useMenuFilterPart("Input");
	const { store } = useMenuRootContext();
	const value = useFilterDropdownValueContext();
	const { onKeyDown, ...navigationProps } = store.useState("inputProps");
	const activeItemId = store.useState("highlightedItemId");
	const handleKeyDown = useMenuFilterKeyDown(value !== "");
	const handleInputRef = import_react.useCallback((input) => {
		store.set("inputFocused", input !== null && activeElement(ownerDocument(input)) === input);
	}, [store]);
	const mergedRefs = useMergedRefs(forwardedRef, handleInputRef);
	const inputProps = mergeProps({
		onKeyDown: handleKeyDown,
		onFocus() {
			store.set("inputFocused", true);
		},
		onBlur() {
			store.set("inputFocused", false);
		}
	}, componentProps);
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FilterDropdownInput, {
		...inputProps,
		activeItemId,
		navigationProps,
		ref: mergedRefs
	});
});
MenuInput.displayName = "MenuInput";
// node_modules/@base-ui/react/menu/list/MenuList.mjs
var MenuListPlain = /*#__PURE__*/ import_react.forwardRef(function MenuListPlain(componentProps, forwardedRef) {
	const { render, className, style, id: idProp, ...elementProps } = componentProps;
	const { store, orientation } = useMenuRootContext();
	const activeTriggerId = store.useState("activeTriggerId");
	const activeTriggerElement = store.useState("activeTriggerElement");
	const setListElement = store.useStateSetter("listElement");
	const id = useBaseUiId(idProp);
	const renderedIdRef = import_react.useRef(id);
	useIsoLayoutEffect(() => {
		if (renderedIdRef.current !== id) {
			renderedIdRef.current = id;
			store.notifyAll();
		}
	}, [id, store]);
	const ariaLabelledBy = resolvePopupLabel(componentProps, activeTriggerElement, activeTriggerId);
	return useRenderElement("div", componentProps, {
		ref: [forwardedRef, setListElement],
		props: [{
			id,
			role: "menu",
			tabIndex: -1,
			"aria-orientation": orientation === "horizontal" ? "horizontal" : void 0,
			"aria-labelledby": ariaLabelledBy
		}, elementProps]
	});
});
MenuListPlain.displayName = "MenuListPlain";
var MenuList = /*#__PURE__*/ import_react.forwardRef(function MenuList(props, forwardedRef) {
	const List = useMenuFilterImpl()?.List ?? MenuListPlain;
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(List, {
		...props,
		ref: forwardedRef
	});
});
MenuList.displayName = "MenuList";
// node_modules/@base-ui/react/filter-dropdown/clear/FilterDropdownClear.mjs
/**
* @internal
*/
var FilterDropdownClear = /*#__PURE__*/ import_react.forwardRef(function FilterDropdownClear(componentProps, forwardedRef) {
	const { render, className, style, disabled: disabledProp = false, nativeButton = true, ...elementProps } = componentProps;
	const context = useFilterDropdownRootContext();
	const value = useFilterDropdownValueContext();
	const disabled = context.disabled || disabledProp;
	const visible = value !== "";
	const { buttonRef, getButtonProps } = useButton({
		disabled,
		native: nativeButton
	});
	return useRenderElement("button", componentProps, {
		enabled: visible,
		state: { disabled },
		ref: [forwardedRef, buttonRef],
		props: [
			{
				tabIndex: -1,
				"aria-hidden": true,
				onMouseDown(event) {
					event.preventDefault();
				},
				onClick(event) {
					const eventDetails = createChangeEventDetails(clearPress, event.nativeEvent);
					context.onValueChange("", eventDetails);
					context.focusOwnerRef.current?.focus({ preventScroll: true });
				}
			},
			elementProps,
			getButtonProps
		]
	});
});
FilterDropdownClear.displayName = "FilterDropdownClear";
// node_modules/@base-ui/react/menu/clear/MenuClear.mjs
/**
* A button that clears the input text.
* Requires the menu to be wrapped in `Menu.FilterProvider`.
* Renders a `<button>` element when the input has text.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuClear = /*#__PURE__*/ import_react.forwardRef(function MenuClear(props, forwardedRef) {
	useMenuFilterPart("Clear");
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FilterDropdownClear, {
		...props,
		ref: forwardedRef
	});
});
MenuClear.displayName = "MenuClear";
// node_modules/@base-ui/react/internals/useInitialLiveRegionTextMutation.mjs
var LIVE_REGION_MARKER = "⁠";
function findLastTextNode(root) {
	const walker = root.ownerDocument.createTreeWalker(root, NodeFilter.SHOW_TEXT);
	let lastTextNode = null;
	while (walker.nextNode()) {
		const textNode = walker.currentNode;
		if (textNode.nodeValue !== "") lastTextNode = textNode;
	}
	return lastTextNode;
}
/**
* @param present Whether the live region element is currently rendered. Lets a conditionally
* rendered region re-run the marker each time its element (re)appears with text.
*/
function useInitialLiveRegionTextMutation(present = true) {
	const timeout = useTimeout();
	const rootRef = import_react.useRef(null);
	import_react.useEffect(() => {
		if (!present || ios) return;
		const root = rootRef.current;
		if (root == null) return;
		const textNode = findLastTextNode(root);
		if (textNode == null) return;
		const originalValue = textNode.data;
		const markedValue = `${originalValue}${LIVE_REGION_MARKER}`;
		textNode.nodeValue = markedValue;
		timeout.start(200, () => {
			if (textNode.nodeValue === markedValue) textNode.nodeValue = originalValue;
		});
		return () => {
			timeout.clear();
			if (textNode.nodeValue === markedValue) textNode.nodeValue = originalValue;
		};
	}, [
		present,
		rootRef,
		timeout
	]);
	return rootRef;
}
// node_modules/@base-ui/react/filter-dropdown/empty/FilterDropdownEmpty.mjs
/**
* @internal
*/
var FilterDropdownEmpty = /*#__PURE__*/ import_react.forwardRef(function FilterDropdownEmpty(componentProps, forwardedRef) {
	const { render, className, style, ...elementProps } = componentProps;
	const { store } = useFilterDropdownItemContext();
	const isEmpty = useStore(store, selectors.isEmpty);
	const [ready, setReady] = import_react.useState(false);
	useIsoLayoutEffect(() => {
		setReady(true);
	}, []);
	const visible = ready && isEmpty;
	const emptyRef = useInitialLiveRegionTextMutation(visible);
	return useRenderElement("div", componentProps, {
		enabled: visible,
		ref: [forwardedRef, emptyRef],
		props: [{
			role: "status",
			"aria-live": "polite",
			"aria-atomic": true
		}, elementProps]
	});
});
FilterDropdownEmpty.displayName = "FilterDropdownEmpty";
// node_modules/@base-ui/react/menu/empty/MenuEmpty.mjs
/**
* A message shown when the menu has no matching items.
* Requires the menu to be wrapped in `Menu.FilterProvider`.
* Renders a `<div>` element.
*
* Documentation: [Base UI Menu](https://base-ui.com/react/components/menu)
*/
var MenuEmpty = /*#__PURE__*/ import_react.forwardRef(function MenuEmpty(props, forwardedRef) {
	useMenuFilterPart("Empty");
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(FilterDropdownEmpty, {
		...props,
		ref: forwardedRef
	});
});
MenuEmpty.displayName = "MenuEmpty";
// node_modules/@base-ui/react/menu/index.parts.mjs
var index_parts_exports = /* @__PURE__ */ __exportAll({
	Arrow: () => MenuArrow,
	Backdrop: () => MenuBackdrop,
	CheckboxItem: () => MenuCheckboxItem,
	CheckboxItemIndicator: () => MenuCheckboxItemIndicator,
	Clear: () => MenuClear,
	Empty: () => MenuEmpty,
	FilterProvider: () => MenuFilterProvider,
	Group: () => MenuGroup,
	GroupLabel: () => MenuGroupLabel,
	Handle: () => MenuHandle,
	Input: () => MenuInput,
	Item: () => MenuItem,
	LinkItem: () => MenuLinkItem,
	List: () => MenuList,
	Popup: () => MenuPopup,
	Portal: () => MenuPortal,
	Positioner: () => MenuPositioner,
	RadioGroup: () => MenuRadioGroup,
	RadioItem: () => MenuRadioItem,
	RadioItemIndicator: () => MenuRadioItemIndicator,
	Root: () => MenuRoot,
	Separator: () => Separator,
	SubmenuRoot: () => MenuSubmenuRoot,
	SubmenuTrigger: () => MenuSubmenuTrigger,
	Trigger: () => MenuTrigger,
	Viewport: () => MenuViewport,
	createHandle: () => createMenuHandle,
	useFilter: () => getFilter
});
// node_modules/@base-ui/react/menu/arrow/MenuArrowDataAttributes.mjs
var MenuArrowDataAttributes_exports = /* @__PURE__ */ __exportAll({
	align: () => align$2,
	closed: () => closed$3,
	open: () => open$3,
	side: () => side$2,
	uncentered: () => uncentered
});
/**
* Present when the menu popup is open.
*/
var open$3 = open$4;
/**
* Present when the menu popup is closed.
*/
var closed$3 = closed$4;
/**
* Indicates which side the popup is positioned relative to the anchor.
* @type {'top' | 'bottom' | 'left' | 'right' | 'inline-end' | 'inline-start'}
*/
var side$2 = side$3;
/**
* Indicates how the popup is aligned relative to specified side.
* @type {'start' | 'center' | 'end'}
*/
var align$2 = align$3;
/**
* Present when the menu arrow is uncentered.
*/
var uncentered = "data-uncentered";
// node_modules/@base-ui/react/menu/backdrop/MenuBackdropDataAttributes.mjs
var MenuBackdropDataAttributes_exports = /* @__PURE__ */ __exportAll({
	closed: () => closed$2,
	endingStyle: () => endingStyle$3,
	open: () => open$2,
	startingStyle: () => startingStyle$3
});
/**
* Present when the menu is open.
*/
var open$2 = open$4;
/**
* Present when the menu is closed.
*/
var closed$2 = closed$4;
/**
* Present when the menu begins animating in.
*/
var startingStyle$3 = startingStyle$4;
/**
* Present when the menu is animating out.
*/
var endingStyle$3 = endingStyle$4;
// node_modules/@base-ui/react/menu/checkbox-item-indicator/MenuCheckboxItemIndicatorDataAttributes.mjs
var MenuCheckboxItemIndicatorDataAttributes_exports = /* @__PURE__ */ __exportAll({
	checked: () => checked$2,
	disabled: () => disabled$6,
	endingStyle: () => endingStyle$2,
	startingStyle: () => startingStyle$2,
	unchecked: () => unchecked$2
});
/**
* Present when the menu checkbox item is checked.
*/
var checked$2 = "data-checked";
/**
* Present when the menu checkbox item is not checked.
*/
var unchecked$2 = "data-unchecked";
/**
* Present when the menu checkbox item is disabled.
*/
var disabled$6 = "data-disabled";
/**
* Present when the indicator begins animating in.
*/
var startingStyle$2 = startingStyle$5;
/**
* Present when the indicator is animating out.
*/
var endingStyle$2 = endingStyle$5;
// node_modules/@base-ui/react/menu/item/MenuItemDataAttributes.mjs
var MenuItemDataAttributes_exports = /* @__PURE__ */ __exportAll({
	disabled: () => disabled$5,
	highlighted: () => highlighted$4
});
/**
* Present when the menu item is highlighted.
*/
var highlighted$4 = "data-highlighted";
/**
* Present when the menu item is disabled.
*/
var disabled$5 = "data-disabled";
// node_modules/@base-ui/react/menu/link-item/MenuLinkItemDataAttributes.mjs
var MenuLinkItemDataAttributes_exports = /* @__PURE__ */ __exportAll({ highlighted: () => highlighted$3 });
/**
* Present when the link is highlighted.
*/
var highlighted$3 = "data-highlighted";
// node_modules/@base-ui/react/menu/popup/MenuPopupDataAttributes.mjs
var MenuPopupDataAttributes_exports = /* @__PURE__ */ __exportAll({
	align: () => align$1,
	closed: () => closed$1,
	endingStyle: () => endingStyle$1,
	instant: () => instant$1,
	open: () => open$1,
	side: () => side$1,
	startingStyle: () => startingStyle$1
});
/**
* Present when the menu is open.
*/
var open$1 = open$4;
/**
* Present when the menu is closed.
*/
var closed$1 = closed$4;
/**
* Present when the menu begins animating in.
*/
var startingStyle$1 = startingStyle$4;
/**
* Present when the menu is animating out.
*/
var endingStyle$1 = endingStyle$4;
/**
* Indicates which side the popup is positioned relative to the anchor.
* @type {'top' | 'bottom' | 'left' | 'right' | 'inline-end' | 'inline-start'}
*/
var side$1 = side$3;
/**
* Indicates how the popup is aligned relative to specified side.
* @type {'start' | 'center' | 'end'}
*/
var align$1 = align$3;
/**
* Present if animations should be instant.
* @type {'click' | 'dismiss' | 'group' | 'trigger-change'}
*/
var instant$1 = "data-instant";
// node_modules/@base-ui/react/menu/positioner/MenuPositionerCssVars.mjs
var MenuPositionerCssVars_exports = /* @__PURE__ */ __exportAll({
	anchorHeight: () => anchorHeight,
	anchorWidth: () => anchorWidth,
	availableHeight: () => availableHeight,
	availableWidth: () => availableWidth,
	positionerHeight: () => positionerHeight,
	positionerWidth: () => positionerWidth,
	transformOrigin: () => transformOrigin
});
/**
* The available width between the anchor and the edge of the viewport.
* @type {number}
*/
var availableWidth = "--available-width";
/**
* The available height between the anchor and the edge of the viewport.
* @type {number}
*/
var availableHeight = "--available-height";
/**
* The anchor's width.
* @type {number}
*/
var anchorWidth = "--anchor-width";
/**
* The anchor's height.
* @type {number}
*/
var anchorHeight = "--anchor-height";
/**
* The coordinates that this element is anchored to. Used for animations and transitions.
* @type {string}
*/
var transformOrigin = "--transform-origin";
/**
* The width of the menu's positioner.
* It is important to set `width` to this value when using CSS to animate size changes.
* @type {number}
*/
var positionerWidth = "--positioner-width";
/**
* The height of the menu's positioner.
* It is important to set `height` to this value when using CSS to animate size changes.
* @type {number}
*/
var positionerHeight = "--positioner-height";
// node_modules/@base-ui/react/menu/positioner/MenuPositionerDataAttributes.mjs
var MenuPositionerDataAttributes_exports = /* @__PURE__ */ __exportAll({
	align: () => align,
	anchorHidden: () => anchorHidden,
	closed: () => closed,
	open: () => open,
	side: () => side
});
/**
* Present when the menu popup is open.
*/
var open = open$4;
/**
* Present when the menu popup is closed.
*/
var closed = closed$4;
/**
* Present when the anchor is hidden.
*/
var anchorHidden = anchorHidden$1;
/**
* Indicates which side the popup is positioned relative to the anchor.
* @type {'top' | 'bottom' | 'left' | 'right' | 'inline-end' | 'inline-start'}
*/
var side = side$3;
/**
* Indicates how the popup is aligned relative to the specified side.
* @type {'start' | 'center' | 'end'}
*/
var align = align$3;
// node_modules/@base-ui/react/menu/radio-item/MenuRadioItemDataAttributes.mjs
var MenuRadioItemDataAttributes_exports = /* @__PURE__ */ __exportAll({
	checked: () => checked$1,
	disabled: () => disabled$4,
	highlighted: () => highlighted$2,
	unchecked: () => unchecked$1
});
/**
* Present when the menu radio item is selected.
*/
var checked$1 = "data-checked";
/**
* Present when the menu radio item is not selected.
*/
var unchecked$1 = "data-unchecked";
/**
* Present when the menu radio item is disabled.
*/
var disabled$4 = "data-disabled";
/**
* Present when the menu radio item is highlighted.
*/
var highlighted$2 = "data-highlighted";
// node_modules/@base-ui/react/menu/radio-item-indicator/MenuRadioItemIndicatorDataAttributes.mjs
var MenuRadioItemIndicatorDataAttributes_exports = /* @__PURE__ */ __exportAll({
	checked: () => checked,
	disabled: () => disabled$3,
	endingStyle: () => endingStyle,
	startingStyle: () => startingStyle,
	unchecked: () => unchecked
});
/**
* Present when the menu radio item is selected.
*/
var checked = "data-checked";
/**
* Present when the menu radio item is not selected.
*/
var unchecked = "data-unchecked";
/**
* Present when the menu radio item is disabled.
*/
var disabled$3 = "data-disabled";
/**
* Present when the radio indicator begins animating in.
*/
var startingStyle = startingStyle$5;
/**
* Present when the radio indicator is animating out.
*/
var endingStyle = endingStyle$5;
// node_modules/@base-ui/react/menu/trigger/MenuTriggerDataAttributes.mjs
var MenuTriggerDataAttributes_exports = /* @__PURE__ */ __exportAll({
	disabled: () => disabled$2,
	popupOpen: () => popupOpen$1,
	pressed: () => pressed
});
/**
* Present when the corresponding menu is open.
*/
var popupOpen$1 = popupOpen$2;
/**
* Present when the trigger is pressed.
*/
var pressed = pressed$1;
/**
* Present when the trigger is disabled.
*/
var disabled$2 = "data-disabled";
// node_modules/@base-ui/react/menu/viewport/MenuViewportCssVars.mjs
var MenuViewportCssVars_exports = /* @__PURE__ */ __exportAll({
	popupHeight: () => popupHeight,
	popupWidth: () => popupWidth
});
/**
* The width of the parent popup.
* This variable is placed on the 'previous' container and stores the width of the popup when the previous content was rendered.
* It can be used to freeze the dimensions of the popup when animating between different content.
*/
var popupWidth = "--popup-width";
/**
* The height of the parent popup.
* This variable is placed on the 'previous' container and stores the height of the popup when the previous content was rendered.
* It can be used to freeze the dimensions of the popup when animating between different content.
*/
var popupHeight = "--popup-height";
// node_modules/@base-ui/react/menu/viewport/MenuViewportDataAttributes.mjs
var MenuViewportDataAttributes_exports = /* @__PURE__ */ __exportAll({
	activationDirection: () => activationDirection,
	current: () => current,
	instant: () => instant,
	previous: () => previous,
	transitioning: () => transitioning
});
/**
* Applied to the direct child of the viewport when no transitions are present or the new content when it's entering.
*/
var current = "data-current";
/**
* Applied to the direct child of the viewport that contains the exiting content when transitions are present.
*/
var previous = "data-previous";
/**
* Indicates the direction from which the popup was activated.
* This can be used to create directional animations based on how the popup was triggered.
* Contains space-separated values for both horizontal and vertical axes.
* @type {`${'left' | 'right' | ''} ${'down' | 'up' | ''}`}
*/
var activationDirection = "data-activation-direction";
/**
* Indicates that the viewport is currently transitioning between old and new content.
*/
var transitioning = "data-transitioning";
/**
* Present if animations should be instant.
* @type {'click' | 'dismiss' | 'group' | 'trigger-change'}
*/
var instant = "data-instant";
// node_modules/@base-ui/react/menu/submenu-trigger/MenuSubmenuTriggerDataAttributes.mjs
var MenuSubmenuTriggerDataAttributes_exports = /* @__PURE__ */ __exportAll({
	disabled: () => disabled$1,
	highlighted: () => highlighted$1,
	popupOpen: () => popupOpen
});
/**
* Present when the corresponding submenu is open.
*/
var popupOpen = popupOpen$2;
/**
* Present when the submenu trigger is highlighted.
*/
var highlighted$1 = "data-highlighted";
/**
* Present when the submenu trigger is disabled.
*/
var disabled$1 = "data-disabled";
// node_modules/@base-ui/react/menu/input/MenuInputDataAttributes.mjs
var MenuInputDataAttributes_exports = /* @__PURE__ */ __exportAll({ highlighted: () => highlighted });
/**
* Present while the input shows its focus ring.
* Cleared when keyboard navigation highlights an item.
*/
var highlighted = "data-highlighted";
// node_modules/@base-ui/react/menu/clear/MenuClearDataAttributes.mjs
var MenuClearDataAttributes_exports = /* @__PURE__ */ __exportAll({ disabled: () => disabled });
/**
* Present when the button is disabled.
*/
var disabled = "data-disabled";
export { index_parts_exports as Menu, MenuArrowDataAttributes_exports as MenuArrowDataAttributes, MenuBackdropDataAttributes_exports as MenuBackdropDataAttributes, MenuCheckboxItemDataAttributes_exports as MenuCheckboxItemDataAttributes, MenuCheckboxItemIndicatorDataAttributes_exports as MenuCheckboxItemIndicatorDataAttributes, MenuClearDataAttributes_exports as MenuClearDataAttributes, MenuInputDataAttributes_exports as MenuInputDataAttributes, MenuItemDataAttributes_exports as MenuItemDataAttributes, MenuLinkItemDataAttributes_exports as MenuLinkItemDataAttributes, MenuPopupDataAttributes_exports as MenuPopupDataAttributes, MenuPositionerCssVars_exports as MenuPositionerCssVariables, MenuPositionerDataAttributes_exports as MenuPositionerDataAttributes, MenuRadioItemDataAttributes_exports as MenuRadioItemDataAttributes, MenuRadioItemIndicatorDataAttributes_exports as MenuRadioItemIndicatorDataAttributes, SeparatorDataAttributes_exports as MenuSeparatorDataAttributes, MenuSubmenuTriggerDataAttributes_exports as MenuSubmenuTriggerDataAttributes, MenuTriggerDataAttributes_exports as MenuTriggerDataAttributes, MenuViewportCssVars_exports as MenuViewportCssVariables, MenuViewportDataAttributes_exports as MenuViewportDataAttributes };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQGJhc2UtdWlfcmVhY3RfbWVudS5qcyIsIm5hbWVzIjpbIlJFQVNPTlMuaXRlbVByZXNzIiwicGxhdGZvcm0ub3MubWFjIiwiY2hlY2tlZCIsInVuY2hlY2tlZCIsImRpc2FibGVkIiwiaGlnaGxpZ2h0ZWQiLCJNZW51Q2hlY2tib3hJdGVtRGF0YUF0dHJpYnV0ZXMuY2hlY2tlZCIsIk1lbnVDaGVja2JveEl0ZW1EYXRhQXR0cmlidXRlcy51bmNoZWNrZWQiLCJSRUFTT05TLml0ZW1QcmVzcyIsIlJFQVNPTlMuc2libGluZ09wZW4iLCJSRUFTT05TLml0ZW1QcmVzcyIsIlJFQVNPTlMubm9uZSIsIlJFQVNPTlMua2V5Ym9hcmQiLCJSRUFTT05TLnBvaW50ZXIiLCJzZWxlY3RvcnMiLCJwbGF0Zm9ybS5lbmdpbmUud2Via2l0IiwiUkVBU09OUy5pbXBlcmF0aXZlQWN0aW9uIiwibGlzdE5hdmlnYXRpb24iLCJSRUFTT05TLmtleWJvYXJkIiwiUkVBU09OUy5ub25lIiwiUkVBU09OUy5mb2N1c091dCIsIlJFQVNPTlMuY2FuY2VsT3BlbiIsIlJFQVNPTlMucG9pbnRlciIsInBsYXRmb3JtLnNjcmVlblJlYWRlci52b2ljZU92ZXIiLCJSRUFTT05TLmZvY3VzT3V0IiwiUkVBU09OUy5ub25lIiwiUkVBU09OUy5wb3B1cENsb3NlIiwiUkVBU09OUy5rZXlib2FyZCIsIm93bmVyV2luZG93IiwiUkVBU09OUy5mb2N1c091dCIsIlJFQVNPTlMua2V5Ym9hcmQiLCJSRUFTT05TLm5vbmUiLCJSRUFTT05TLm5vbmUiLCJSRUFTT05TLm5vbmUiLCJSRUFTT05TLmtleWJvYXJkIiwiUkVBU09OUy5ub25lIiwiUkVBU09OUy5saXN0TmF2aWdhdGlvbiIsIlJFQVNPTlMuaW5wdXRDbGVhciIsIlJFQVNPTlMuaW5wdXRDaGFuZ2UiLCJwbGF0Zm9ybS5vcy5hbmRyb2lkIiwiUkVBU09OUy5jbGVhclByZXNzIiwicGxhdGZvcm0ub3MuaW9zIiwib3BlbiIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMub3BlbiIsImNsb3NlZCIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuY2xvc2VkIiwic2lkZSIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuc2lkZSIsImFsaWduIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5hbGlnbiIsIm9wZW4iLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW4iLCJjbG9zZWQiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmNsb3NlZCIsInN0YXJ0aW5nU3R5bGUiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnN0YXJ0aW5nU3R5bGUiLCJlbmRpbmdTdHlsZSIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuZW5kaW5nU3R5bGUiLCJjaGVja2VkIiwidW5jaGVja2VkIiwiZGlzYWJsZWQiLCJzdGFydGluZ1N0eWxlIiwiVHJhbnNpdGlvblN0YXR1c0RhdGFBdHRyaWJ1dGVzLnN0YXJ0aW5nU3R5bGUiLCJlbmRpbmdTdHlsZSIsIlRyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcy5lbmRpbmdTdHlsZSIsImhpZ2hsaWdodGVkIiwiZGlzYWJsZWQiLCJoaWdobGlnaHRlZCIsIm9wZW4iLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW4iLCJjbG9zZWQiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmNsb3NlZCIsInN0YXJ0aW5nU3R5bGUiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnN0YXJ0aW5nU3R5bGUiLCJlbmRpbmdTdHlsZSIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuZW5kaW5nU3R5bGUiLCJzaWRlIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zaWRlIiwiYWxpZ24iLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmFsaWduIiwiaW5zdGFudCIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMub3BlbiIsIkNvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuY2xvc2VkIiwiQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5hbmNob3JIaWRkZW4iLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLnNpZGUiLCJDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmFsaWduIiwiY2hlY2tlZCIsInVuY2hlY2tlZCIsImRpc2FibGVkIiwiaGlnaGxpZ2h0ZWQiLCJkaXNhYmxlZCIsIlRyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcy5zdGFydGluZ1N0eWxlIiwiVHJhbnNpdGlvblN0YXR1c0RhdGFBdHRyaWJ1dGVzLmVuZGluZ1N0eWxlIiwicG9wdXBPcGVuIiwiQ29tbW9uVHJpZ2dlckRhdGFBdHRyaWJ1dGVzLnBvcHVwT3BlbiIsIkNvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcy5wcmVzc2VkIiwiZGlzYWJsZWQiLCJDb21tb25UcmlnZ2VyRGF0YUF0dHJpYnV0ZXMucG9wdXBPcGVuIiwiaGlnaGxpZ2h0ZWQiLCJkaXNhYmxlZCJdLCJzb3VyY2VzIjpbIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvcG9zaXRpb25lci9NZW51UG9zaXRpb25lckNvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9yb290L01lbnVSb290Q29udGV4dC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L2Fycm93L01lbnVBcnJvdy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9jb250ZXh0LW1lbnUvcm9vdC9Db250ZXh0TWVudVJvb3RDb250ZXh0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvYmFja2Ryb3AvTWVudUJhY2tkcm9wLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvZmlsdGVyLXJvb3QvTWVudUZpbHRlckNvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9jaGVja2JveC1pdGVtL01lbnVDaGVja2JveEl0ZW1Db250ZXh0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvaXRlbS91c2VNZW51SXRlbUNvbW1vblByb3BzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvaXRlbS91c2VNZW51SXRlbS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L2NoZWNrYm94LWl0ZW0vTWVudUNoZWNrYm94SXRlbURhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvdXRpbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L2NoZWNrYm94LWl0ZW0vTWVudUNoZWNrYm94SXRlbS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L2NoZWNrYm94LWl0ZW0taW5kaWNhdG9yL01lbnVDaGVja2JveEl0ZW1JbmRpY2F0b3IubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9ncm91cC9NZW51R3JvdXBDb250ZXh0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvZ3JvdXAvTWVudUdyb3VwLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvZ3JvdXAtbGFiZWwvTWVudUdyb3VwTGFiZWwubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9pdGVtL01lbnVJdGVtLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvbGluay1pdGVtL01lbnVMaW5rSXRlbS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L3N1Ym1lbnUtcm9vdC9NZW51U3VibWVudVJvb3RDb250ZXh0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2ludGVybmFscy9yZXNvbHZlUmVuZGVyZWRJZC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9pbnRlcm5hbHMvcmVzb2x2ZVBvcHVwTGFiZWwubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9wb3B1cC9NZW51UG9wdXAubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9wb3J0YWwvTWVudVBvcnRhbENvbnRleHQubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9wb3J0YWwvTWVudVBvcnRhbC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9pbnRlcm5hbHMvdXNlVHJpZ2dlclN3aXRjaFRyYW5zaXRpb24ubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9wb3NpdGlvbmVyL01lbnVQb3NpdGlvbmVyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvcmFkaW8tZ3JvdXAvTWVudVJhZGlvR3JvdXBDb250ZXh0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvcmFkaW8tZ3JvdXAvTWVudVJhZGlvR3JvdXAubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9yYWRpby1pdGVtL01lbnVSYWRpb0l0ZW1Db250ZXh0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvcmFkaW8taXRlbS9NZW51UmFkaW9JdGVtLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvcmFkaW8taXRlbS1pbmRpY2F0b3IvTWVudVJhZGlvSXRlbUluZGljYXRvci5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51YmFyL01lbnViYXJDb250ZXh0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3V0aWxzL2dldEhpZ2hsaWdodFJlYXNvbi5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L3N0b3JlL01lbnVTdG9yZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L2ZpbHRlci1wcm92aWRlci9NZW51RmlsdGVyUHJvdmlkZXJDb250ZXh0Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvdXRpbHMvaXNLZXlib2FyZE9wZW4ubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9yb290L01lbnVSb290Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvc3VibWVudS1yb290L01lbnVTdWJtZW51Um9vdC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L3V0aWxzL2ZpbmRSb290T3duZXJJZC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9wb3B1cHMvdXNlVHJpZ2dlckZvY3VzR3VhcmRzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L3V0aWxzL3VzZU1peGVkVG9nZ2xlQ2xpY2tIYW5kbGVyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvdHJpZ2dlci9NZW51VHJpZ2dlci5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L3ZpZXdwb3J0L01lbnVWaWV3cG9ydC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L3N1Ym1lbnUtdHJpZ2dlci9NZW51U3VibWVudVRyaWdnZXIubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9zdG9yZS9NZW51SGFuZGxlLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3V0aWxzL3N0cmluZ2lmeUxvY2FsZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9pbnRlcm5hbHMvZmlsdGVyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2ludGVybmFscy91c2VJdGVtUmVnaXN0cnkubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmlsdGVyLWRyb3Bkb3duL3Jvb3QvRmlsdGVyRHJvcGRvd25Sb290Q29udGV4dC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9maWx0ZXItZHJvcGRvd24vc3RvcmUubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmlsdGVyLWRyb3Bkb3duL3Jvb3QvRmlsdGVyRHJvcGRvd25Sb290Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2ZpbHRlci1kcm9wZG93bi9yb290L3VzZUZpbHRlckRyb3Bkb3duQ2xvc2VRdWVyeS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9maWx0ZXItZHJvcGRvd24vdXRpbHMvcmVmb2N1c093bmVyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvZmlsdGVyLXJvb3QvdXNlTWVudUZpbHRlclBvcHVwLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvZmlsdGVyLXJvb3QvTWVudUZpbHRlclBvcHVwLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2ZpbHRlci1kcm9wZG93bi9ncm91cC9GaWx0ZXJEcm9wZG93bkdyb3VwQ29udGV4dC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9maWx0ZXItZHJvcGRvd24vbGlzdC9GaWx0ZXJEcm9wZG93bkxpc3QubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9maWx0ZXItcm9vdC91c2VNZW51RmlsdGVyS2V5RG93bi5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L2ZpbHRlci1yb290L21vdmVIaWdobGlnaHRGcm9tLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvZmlsdGVyLXJvb3QvTWVudUZpbHRlckxpc3QubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmlsdGVyLWRyb3Bkb3duL2dyb3VwL3VzZUZpbHRlckRyb3Bkb3duR3JvdXAubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9maWx0ZXItcm9vdC9NZW51RmlsdGVyR3JvdXAubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmlsdGVyLWRyb3Bkb3duL2l0ZW0vdXNlRmlsdGVyRHJvcGRvd25JdGVtLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvZmlsdGVyLXJvb3QvdXNlTWVudUZpbHRlclN1Ym1lbnVUcmlnZ2VyLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvZmlsdGVyLXJvb3QvdXNlVmlydHVhbEZvY3VzUGFyZW50SGFuZG9mZi5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L2ZpbHRlci1yb290L01lbnVGaWx0ZXJJbXBsLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvZmlsdGVyLXJvb3QvTWVudUZpbHRlckRyb3Bkb3duLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvZmlsdGVyLXJvb3QvdXNlTWVudUZpbHRlclJvb3QubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9maWx0ZXItcm9vdC9NZW51RmlsdGVyUm9vdC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L2ZpbHRlci1zdWJtZW51LXJvb3QvTWVudUZpbHRlclN1Ym1lbnVSb290Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvZmlsdGVyLXByb3ZpZGVyL01lbnVGaWx0ZXJQcm92aWRlci5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9maWx0ZXItZHJvcGRvd24vaW5wdXQvRmlsdGVyRHJvcGRvd25JbnB1dC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L2lucHV0L01lbnVJbnB1dC5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L2xpc3QvTWVudUxpc3QubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmlsdGVyLWRyb3Bkb3duL2NsZWFyL0ZpbHRlckRyb3Bkb3duQ2xlYXIubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9jbGVhci9NZW51Q2xlYXIubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvaW50ZXJuYWxzL3VzZUluaXRpYWxMaXZlUmVnaW9uVGV4dE11dGF0aW9uLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2ZpbHRlci1kcm9wZG93bi9lbXB0eS9GaWx0ZXJEcm9wZG93bkVtcHR5Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvZW1wdHkvTWVudUVtcHR5Lm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvaW5kZXgucGFydHMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9hcnJvdy9NZW51QXJyb3dEYXRhQXR0cmlidXRlcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L2JhY2tkcm9wL01lbnVCYWNrZHJvcERhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvY2hlY2tib3gtaXRlbS1pbmRpY2F0b3IvTWVudUNoZWNrYm94SXRlbUluZGljYXRvckRhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvaXRlbS9NZW51SXRlbURhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvbGluay1pdGVtL01lbnVMaW5rSXRlbURhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvcG9wdXAvTWVudVBvcHVwRGF0YUF0dHJpYnV0ZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9wb3NpdGlvbmVyL01lbnVQb3NpdGlvbmVyQ3NzVmFycy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L3Bvc2l0aW9uZXIvTWVudVBvc2l0aW9uZXJEYXRhQXR0cmlidXRlcy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L3JhZGlvLWl0ZW0vTWVudVJhZGlvSXRlbURhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvcmFkaW8taXRlbS1pbmRpY2F0b3IvTWVudVJhZGlvSXRlbUluZGljYXRvckRhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvdHJpZ2dlci9NZW51VHJpZ2dlckRhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvdmlld3BvcnQvTWVudVZpZXdwb3J0Q3NzVmFycy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9tZW51L3ZpZXdwb3J0L01lbnVWaWV3cG9ydERhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvc3VibWVudS10cmlnZ2VyL01lbnVTdWJtZW51VHJpZ2dlckRhdGFBdHRyaWJ1dGVzLm1qcyIsIi4uLy4uL0BiYXNlLXVpL3JlYWN0L21lbnUvaW5wdXQvTWVudUlucHV0RGF0YUF0dHJpYnV0ZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvbWVudS9jbGVhci9NZW51Q2xlYXJEYXRhQXR0cmlidXRlcy5tanMiXSwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgX2Zvcm1hdEVycm9yTWVzc2FnZSBmcm9tIFwiQGJhc2UtdWkvdXRpbHMvZm9ybWF0RXJyb3JNZXNzYWdlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgTWVudVBvc2l0aW9uZXJDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnVQb3NpdGlvbmVyQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiTWVudVBvc2l0aW9uZXJDb250ZXh0XCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlTWVudVBvc2l0aW9uZXJDb250ZXh0KG9wdGlvbmFsKSB7XG4gIGNvbnN0IGNvbnRleHQgPSBSZWFjdC51c2VDb250ZXh0KE1lbnVQb3NpdGlvbmVyQ29udGV4dCk7XG4gIGlmIChjb250ZXh0ID09PSB1bmRlZmluZWQgJiYgIW9wdGlvbmFsKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/ICdCYXNlIFVJOiBNZW51UG9zaXRpb25lckNvbnRleHQgaXMgbWlzc2luZy4gTWVudVBvc2l0aW9uZXIgcGFydHMgbXVzdCBiZSBwbGFjZWQgd2l0aGluIDxNZW51LlBvc2l0aW9uZXI+LicgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDMzKSk7XG4gIH1cbiAgcmV0dXJuIGNvbnRleHQ7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgX2Zvcm1hdEVycm9yTWVzc2FnZSBmcm9tIFwiQGJhc2UtdWkvdXRpbHMvZm9ybWF0RXJyb3JNZXNzYWdlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgTWVudVJvb3RDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnVSb290Q29udGV4dC5kaXNwbGF5TmFtZSA9IFwiTWVudVJvb3RDb250ZXh0XCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlTWVudVJvb3RDb250ZXh0KG9wdGlvbmFsKSB7XG4gIGNvbnN0IGNvbnRleHQgPSBSZWFjdC51c2VDb250ZXh0KE1lbnVSb290Q29udGV4dCk7XG4gIGlmIChjb250ZXh0ID09PSB1bmRlZmluZWQgJiYgIW9wdGlvbmFsKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/ICdCYXNlIFVJOiBNZW51Um9vdENvbnRleHQgaXMgbWlzc2luZy4gTWVudSBwYXJ0cyBtdXN0IGJlIHBsYWNlZCB3aXRoaW4gPE1lbnUuUm9vdD4uJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoMzYpKTtcbiAgfVxuICByZXR1cm4gY29udGV4dDtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU1lbnVQb3NpdGlvbmVyQ29udGV4dCB9IGZyb20gXCIuLi9wb3NpdGlvbmVyL01lbnVQb3NpdGlvbmVyQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZU1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L01lbnVSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBwb3B1cFN0YXRlTWFwcGluZyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBEaXNwbGF5cyBhbiBlbGVtZW50IHBvc2l0aW9uZWQgYWdhaW5zdCB0aGUgbWVudSBhbmNob3IuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIE1lbnVdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9tZW51KVxuICovXG5leHBvcnQgY29uc3QgTWVudUFycm93ID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gTWVudUFycm93KGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qge1xuICAgIHN0b3JlXG4gIH0gPSB1c2VNZW51Um9vdENvbnRleHQoKTtcbiAgY29uc3Qge1xuICAgIGFycm93UmVmLFxuICAgIHNpZGUsXG4gICAgYWxpZ24sXG4gICAgYXJyb3dVbmNlbnRlcmVkLFxuICAgIGFycm93U3R5bGVzXG4gIH0gPSB1c2VNZW51UG9zaXRpb25lckNvbnRleHQoKTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIG9wZW4sXG4gICAgc2lkZSxcbiAgICBhbGlnbixcbiAgICB1bmNlbnRlcmVkOiBhcnJvd1VuY2VudGVyZWRcbiAgfTtcbiAgcmV0dXJuIHVzZVJlbmRlckVsZW1lbnQoJ2RpdicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgcmVmOiBbYXJyb3dSZWYsIGZvcndhcmRlZFJlZl0sXG4gICAgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZzogcG9wdXBTdGF0ZU1hcHBpbmcsXG4gICAgc3RhdGUsXG4gICAgcHJvcHM6IHtcbiAgICAgIHN0eWxlOiBhcnJvd1N0eWxlcyxcbiAgICAgICdhcmlhLWhpZGRlbic6IHRydWUsXG4gICAgICAuLi5lbGVtZW50UHJvcHNcbiAgICB9XG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51QXJyb3cuZGlzcGxheU5hbWUgPSBcIk1lbnVBcnJvd1wiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IENvbnRleHRNZW51Um9vdENvbnRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlQ29udGV4dCh1bmRlZmluZWQpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgQ29udGV4dE1lbnVSb290Q29udGV4dC5kaXNwbGF5TmFtZSA9IFwiQ29udGV4dE1lbnVSb290Q29udGV4dFwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUNvbnRleHRNZW51Um9vdENvbnRleHQob3B0aW9uYWwgPSB0cnVlKSB7XG4gIGNvbnN0IGNvbnRleHQgPSBSZWFjdC51c2VDb250ZXh0KENvbnRleHRNZW51Um9vdENvbnRleHQpO1xuICBpZiAoY29udGV4dCA9PT0gdW5kZWZpbmVkICYmICFvcHRpb25hbCkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAnQmFzZSBVSTogQ29udGV4dE1lbnVSb290Q29udGV4dCBpcyBtaXNzaW5nLiBDb250ZXh0TWVudSBwYXJ0cyBtdXN0IGJlIHBsYWNlZCB3aXRoaW4gPENvbnRleHRNZW51LlJvb3Q+LicgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDI1KSk7XG4gIH1cbiAgcmV0dXJuIGNvbnRleHQ7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VNZW51Um9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9NZW51Um9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgcG9wdXBUcmFuc2l0aW9uU3RhdGVNYXBwaW5nIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwU3RhdGVNYXBwaW5nLm1qc1wiO1xuaW1wb3J0IHsgdXNlQ29udGV4dE1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi8uLi9jb250ZXh0LW1lbnUvcm9vdC9Db250ZXh0TWVudVJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcblxuLyoqXG4gKiBBbiBvdmVybGF5IGRpc3BsYXllZCBiZW5lYXRoIHRoZSBtZW51IHBvcHVwLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBNZW51XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvbWVudSlcbiAqL1xuZXhwb3J0IGNvbnN0IE1lbnVCYWNrZHJvcCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIE1lbnVCYWNrZHJvcChjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IHtcbiAgICBzdG9yZVxuICB9ID0gdXNlTWVudVJvb3RDb250ZXh0KCk7XG4gIGNvbnN0IG9wZW4gPSBzdG9yZS51c2VTdGF0ZSgnb3BlbicpO1xuICBjb25zdCBtb3VudGVkID0gc3RvcmUudXNlU3RhdGUoJ21vdW50ZWQnKTtcbiAgY29uc3QgdHJhbnNpdGlvblN0YXR1cyA9IHN0b3JlLnVzZVN0YXRlKCd0cmFuc2l0aW9uU3RhdHVzJyk7XG4gIGNvbnN0IGxhc3RPcGVuQ2hhbmdlUmVhc29uID0gc3RvcmUudXNlU3RhdGUoJ2xhc3RPcGVuQ2hhbmdlUmVhc29uJyk7XG4gIGNvbnN0IGNvbnRleHRNZW51Q29udGV4dCA9IHVzZUNvbnRleHRNZW51Um9vdENvbnRleHQoKTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgb3BlbixcbiAgICB0cmFuc2l0aW9uU3RhdHVzXG4gIH07XG4gIHJldHVybiB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHJlZjogY29udGV4dE1lbnVDb250ZXh0Py5iYWNrZHJvcFJlZiA/IFtmb3J3YXJkZWRSZWYsIGNvbnRleHRNZW51Q29udGV4dC5iYWNrZHJvcFJlZl0gOiBmb3J3YXJkZWRSZWYsXG4gICAgc3RhdGUsXG4gICAgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZzogcG9wdXBUcmFuc2l0aW9uU3RhdGVNYXBwaW5nLFxuICAgIHByb3BzOiBbe1xuICAgICAgcm9sZTogJ3ByZXNlbnRhdGlvbicsXG4gICAgICBoaWRkZW46ICFtb3VudGVkLFxuICAgICAgc3R5bGU6IHtcbiAgICAgICAgcG9pbnRlckV2ZW50czogbGFzdE9wZW5DaGFuZ2VSZWFzb24gPT09IFJFQVNPTlMudHJpZ2dlckhvdmVyID8gJ25vbmUnIDogdW5kZWZpbmVkLFxuICAgICAgICB1c2VyU2VsZWN0OiAnbm9uZScsXG4gICAgICAgIFdlYmtpdFVzZXJTZWxlY3Q6ICdub25lJ1xuICAgICAgfVxuICAgIH0sIGVsZW1lbnRQcm9wc11cbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnVCYWNrZHJvcC5kaXNwbGF5TmFtZSA9IFwiTWVudUJhY2tkcm9wXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgX2Zvcm1hdEVycm9yTWVzc2FnZSBmcm9tIFwiQGJhc2UtdWkvdXRpbHMvZm9ybWF0RXJyb3JNZXNzYWdlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VNZXJnZWRSZWZzIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlTWVyZ2VkUmVmcyc7XG5pbXBvcnQgeyBNZW51Um9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9NZW51Um9vdENvbnRleHQubWpzXCI7XG5cbi8qKlxuICogVGhlIGZpbHRlciBpbXBsZW1lbnRhdGlvbiB0aGF0IGEgZmlsdGVyYWJsZSByb290IGhhbmRzIHRvIHRoZSBwYXJ0cyBiZWxvdyBpdC4gT25seSB0aGUgcm9vdHNcbiAqIGBNZW51LkZpbHRlclByb3ZpZGVyYCByZW5kZXJzIGltcG9ydCBpdCwgc28gYSBwbGFpbiBtZW51IG5ldmVyIGJ1bmRsZXMgaXQuIFBhcnRzIHdob3NlIHdob2xlXG4gKiBzdHJ1Y3R1cmUgZGlmZmVycyBhcmUgc3dhcHBlZCBhcyBjb21wb25lbnRzOyBwYXJ0cyB0aGF0IG9ubHkgcmVnaXN0ZXIgd2l0aCB0aGUgZmlsdGVyIGNhbGwgYW5cbiAqIGluamVjdGVkIGhvb2ssIHNvIGEgbWVudSB0aGF0IG5ldmVyIHJlbmRlcnMgdGhlbSBkb2Vzbid0IGJ1bmRsZSBhIHNlY29uZCBpbXBsZW1lbnRhdGlvbi5cbiAqL1xuXG4vKiogU3RhdGljIGJlbG93IGEgZmlsdGVyIHJvb3Q6IHRoZSBpbXBsZW1lbnRhdGlvbiBuZXZlciBjaGFuZ2VzLCBzbyBzdWJzY3JpYmVycyBuZXZlciByZS1yZW5kZXIuICovXG5leHBvcnQgY29uc3QgTWVudUZpbHRlckltcGxDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQobnVsbCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51RmlsdGVySW1wbENvbnRleHQuZGlzcGxheU5hbWUgPSBcIk1lbnVGaWx0ZXJJbXBsQ29udGV4dFwiO1xuLyoqXG4gKiBUaGUgZmlsdGVyIGltcGxlbWVudGF0aW9uIHdoZW4gdGhlIG1lbnUgdGhpcyBwYXJ0IGJlbG9uZ3MgdG8gaXMgZmlsdGVyYWJsZSwgb3RoZXJ3aXNlIGBudWxsYC5cbiAqIGB2aXJ0dWFsRm9jdXNgIG1hcmtzIGEgZmlsdGVyIHJvb3Q7IGEgcGxhaW4gYE1lbnUuUm9vdGAgbmV2ZXIgc2V0cyBpdC4gVGhlIHJlc3VsdCBpcyBmaXhlZCBmb3JcbiAqIGEgbW91bnRlZCBwYXJ0OiBhIGZpbHRlciByb290IGNhbid0IGFwcGVhciBhYm92ZSBpdCB3aXRob3V0IHJlbW91bnRpbmcgaXQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VNZW51RmlsdGVySW1wbChzY29wZSA9ICdyb290Jykge1xuICBjb25zdCBpbXBsID0gUmVhY3QudXNlQ29udGV4dChNZW51RmlsdGVySW1wbENvbnRleHQpO1xuICBjb25zdCByb290ID0gUmVhY3QudXNlQ29udGV4dChNZW51Um9vdENvbnRleHQpO1xuICBpZiAoaW1wbCA9PT0gbnVsbCB8fCByb290ID09PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBjb25zdCBmaWx0ZXJhYmxlID0gc2NvcGUgPT09ICdzdWJtZW51LXRyaWdnZXInID8gcm9vdC52aXJ0dWFsRm9jdXMgfHwgcm9vdC5wYXJlbnRWaXJ0dWFsRm9jdXMgOiByb290LnZpcnR1YWxGb2N1cztcbiAgcmV0dXJuIGZpbHRlcmFibGUgPyBpbXBsIDogbnVsbDtcbn1cblxuLyoqXG4gKiBUaHJvd3MgdW5sZXNzIHRoZSBtZW51IHRoaXMgcGFydCByZW5kZXJzIGluIGlzIGZpbHRlcmFibGUsIG5hbWluZyB0aGUgcGFydCBhbmQgdGhlIHByb3ZpZGVyLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlTWVudUZpbHRlclBhcnQocGFydCkge1xuICBpZiAodXNlTWVudUZpbHRlckltcGwoKSA9PT0gbnVsbCkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBgQmFzZSBVSTogPE1lbnUuJHtwYXJ0fT4gbXVzdCBiZSBwbGFjZWQgaW4gYSBtZW51IHdyYXBwZWQgaW4gPE1lbnUuRmlsdGVyUHJvdmlkZXI+LiBgICsgJ0l0IHJlYWRzIHRoZSBmaWx0ZXIgcXVlcnkgYW5kIHRoZSBtYXRjaGluZyBpdGVtcyBmcm9tIHRoZSBwcm92aWRlciwgd2hpY2ggYSBwbGFpbiBtZW51ICcgKyAnZG9lcyBub3QgaGF2ZS4gV3JhcCB0aGUgPE1lbnUuUm9vdD4gb3IgPE1lbnUuU3VibWVudVJvb3Q+IGl0IGJlbG9uZ3MgdG8gaW4gJyArICc8TWVudS5GaWx0ZXJQcm92aWRlcj4uIFNlZSBodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvbWVudSNmaWx0ZXJpbmcnIDogX2Zvcm1hdEVycm9yTWVzc2FnZSgxMDQsIHBhcnQpKTtcbiAgfVxufVxuY29uc3QgVU5GSUxURVJFRCA9IHtcbiAgdmlzaWJsZTogdHJ1ZSxcbiAgcmVmOiBudWxsXG59O1xuZnVuY3Rpb24gdXNlVW5maWx0ZXJlZEl0ZW0oKSB7XG4gIHJldHVybiBVTkZJTFRFUkVEO1xufVxuXG4vKipcbiAqIFJlZ2lzdGVycyBhbiBpdGVtIHBhcnQgd2l0aCB0aGUgZmlsdGVyIG9mIHRoZSBtZW51IGl0IGJlbG9uZ3MgdG8uIEEgcGxhaW4gbWVudSdzIGl0ZW1zIGFyZVxuICogYWx3YXlzIHZpc2libGUuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VNZW51RmlsdGVySXRlbShwcm9wcywgZm9yd2FyZGVkUmVmLCBzY29wZSA9ICdyb290Jykge1xuICBjb25zdCBpbXBsID0gdXNlTWVudUZpbHRlckltcGwoc2NvcGUpO1xuICBjb25zdCB1c2VJdGVtID0gKHNjb3BlID09PSAnc3VibWVudS10cmlnZ2VyJyA/IGltcGw/LnVzZVN1Ym1lbnVUcmlnZ2VyIDogaW1wbD8udXNlSXRlbSkgPz8gdXNlVW5maWx0ZXJlZEl0ZW07XG4gIGNvbnN0IGl0ZW0gPSB1c2VJdGVtKHtcbiAgICBsYWJlbDogcHJvcHMubGFiZWwsXG4gICAgY2hpbGRyZW46IHByb3BzLmNoaWxkcmVuLFxuICAgIHJlbmRlcjogcHJvcHMucmVuZGVyXG4gIH0pO1xuICBjb25zdCByZWYgPSB1c2VNZXJnZWRSZWZzKGZvcndhcmRlZFJlZiwgaXRlbS5yZWYpO1xuICByZXR1cm4ge1xuICAgIHZpc2libGU6IGl0ZW0udmlzaWJsZSxcbiAgICByZWYsXG4gICAgcHJvcHM6IGl0ZW0ucHJvcHNcbiAgfTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCBfZm9ybWF0RXJyb3JNZXNzYWdlIGZyb20gXCJAYmFzZS11aS91dGlscy9mb3JtYXRFcnJvck1lc3NhZ2VcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBNZW51Q2hlY2tib3hJdGVtQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHVuZGVmaW5lZCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51Q2hlY2tib3hJdGVtQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiTWVudUNoZWNrYm94SXRlbUNvbnRleHRcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VNZW51Q2hlY2tib3hJdGVtQ29udGV4dCgpIHtcbiAgY29uc3QgY29udGV4dCA9IFJlYWN0LnVzZUNvbnRleHQoTWVudUNoZWNrYm94SXRlbUNvbnRleHQpO1xuICBpZiAoY29udGV4dCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/ICdCYXNlIFVJOiBNZW51Q2hlY2tib3hJdGVtQ29udGV4dCBpcyBtaXNzaW5nLiBNZW51Q2hlY2tib3hJdGVtIHBhcnRzIG11c3QgYmUgcGxhY2VkIHdpdGhpbiA8TWVudS5DaGVja2JveEl0ZW0+LicgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDMwKSk7XG4gIH1cbiAgcmV0dXJuIGNvbnRleHQ7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBwbGF0Zm9ybSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtJztcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5pbXBvcnQgeyB1c2VDb250ZXh0TWVudVJvb3RDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2NvbnRleHQtbWVudS9yb290L0NvbnRleHRNZW51Um9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51Um9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9NZW51Um9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBkaXNwYXRjaENsaWNrV2l0aE1vZGlmaWVycyB9IGZyb20gXCIuLi8uLi91dGlscy9kaXNwYXRjaENsaWNrV2l0aE1vZGlmaWVycy5tanNcIjtcbmZ1bmN0aW9uIHByZXZlbnRNb3VzZURvd25EZWZhdWx0KGV2ZW50KSB7XG4gIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG59XG4vKipcbiAqIFJldHVybnMgY29tbW9uIHByb3BzIHNoYXJlZCBieSBhbGwgbWVudSBpdGVtIHR5cGVzLlxuICogVGhpcyBob29rIGV4dHJhY3RzIHRoZSBzaGFyZWQgbG9naWMgZm9yIGlkLCByb2xlLCB0YWJJbmRleCwgYW5kIGludGVyYWN0aW9uIGhhbmRsZXJzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlTWVudUl0ZW1Db21tb25Qcm9wcyhwYXJhbXMpIHtcbiAgY29uc3Qge1xuICAgIGNsb3NlT25DbGljayxcbiAgICBoaWdobGlnaHRlZCxcbiAgICBpZCxcbiAgICBub2RlSWQsXG4gICAgc3RvcmUsXG4gICAgdHlwaW5nUmVmLFxuICAgIGl0ZW1SZWYsXG4gICAgaXRlbU1ldGFkYXRhXG4gIH0gPSBwYXJhbXM7XG4gIGNvbnN0IHJvb3RDb250ZXh0ID0gdXNlTWVudVJvb3RDb250ZXh0KCk7XG4gIGNvbnN0IGNvbnRleHRNZW51Q29udGV4dCA9IHVzZUNvbnRleHRNZW51Um9vdENvbnRleHQodHJ1ZSk7XG5cbiAgLy8gQSBzdWJtZW51IHRyaWdnZXIgaXMgYW4gaXRlbSBvZiB0aGUgcGFyZW50IG1lbnUncyBsaXN0LCBzbyBpdCBmb2xsb3dzIHRoYXQgbGlzdCdzIGZvY3VzIG1vZGVsLlxuICBjb25zdCBpc1N1Ym1lbnVUcmlnZ2VyID0gaXRlbU1ldGFkYXRhLnR5cGUgPT09ICdzdWJtZW51LXRyaWdnZXInO1xuICBjb25zdCB2aXJ0dWFsRm9jdXMgPSBpc1N1Ym1lbnVUcmlnZ2VyID8gcm9vdENvbnRleHQucGFyZW50VmlydHVhbEZvY3VzIDogcm9vdENvbnRleHQudmlydHVhbEZvY3VzO1xuICBjb25zdCBzZWxlY3Rpb25TdG9yZSA9IGlzU3VibWVudVRyaWdnZXIgJiYgcm9vdENvbnRleHQucGFyZW50LnR5cGUgPT09ICdtZW51JyA/IHJvb3RDb250ZXh0LnBhcmVudC5zdG9yZSA6IHJvb3RDb250ZXh0LnN0b3JlO1xuICBjb25zdCBhcmlhU2VsZWN0ZWQgPSBzZWxlY3Rpb25TdG9yZS51c2VTdGF0ZSgnd2Via2l0QXJpYVNlbGVjdGVkJywgaGlnaGxpZ2h0ZWQpO1xuICBjb25zdCB7XG4gICAgZXZlbnRzOiBtZW51RXZlbnRzXG4gIH0gPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdUcmVlUm9vdCcpO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3QgaXNDb250ZXh0TWVudSA9IGNvbnRleHRNZW51Q29udGV4dCAhPT0gdW5kZWZpbmVkO1xuICAvLyBgLTFgIHJhdGhlciB0aGFuIG9taXR0aW5nIGl0LCB3aGljaCBsZWF2ZXMgbGlua3MgYW5kIGJ1dHRvbnMgaW4gdGhlIHRhYiBvcmRlci5cbiAgY29uc3QgdGFiSW5kZXggPSAhdmlydHVhbEZvY3VzICYmIG9wZW4gJiYgaGlnaGxpZ2h0ZWQgPyAwIDogLTE7XG4gIHJldHVybiBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgaWQsXG4gICAgcm9sZTogJ21lbnVpdGVtJyxcbiAgICB0YWJJbmRleCxcbiAgICAnYXJpYS1zZWxlY3RlZCc6IGFyaWFTZWxlY3RlZCxcbiAgICAvLyBSZWFsIGZvY3VzIHN0YXlzIG9uIHRoZSBpbnB1dCBvciBsaXN0IHRoYXQgb3ducyB2aXJ0dWFsIG5hdmlnYXRpb24uXG4gICAgb25Nb3VzZURvd246IHZpcnR1YWxGb2N1cyA/IHByZXZlbnRNb3VzZURvd25EZWZhdWx0IDogdW5kZWZpbmVkLFxuICAgIG9uS2V5RG93bihldmVudCkge1xuICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJyAnICYmIHR5cGluZ1JlZj8uY3VycmVudCkge1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgfVxuICAgIH0sXG4gICAgb25Nb3VzZU1vdmUoZXZlbnQpIHtcbiAgICAgIGlmICghbm9kZUlkKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cblxuICAgICAgLy8gSW5mb3JtIHRoZSBmbG9hdGluZyB0cmVlIHRoYXQgYSBtZW51IGl0ZW0gd2l0aGluIHRoaXMgbWVudSB3YXMgaG92ZXJlZC9tb3ZlZCBvdmVyXG4gICAgICAvLyBzbyB1bnJlbGF0ZWQgZGVzY2VuZGFudCBzdWJtZW51cyBjYW4gYmUgY2xvc2VkLlxuICAgICAgbWVudUV2ZW50cy5lbWl0KCdpdGVtaG92ZXInLCB7XG4gICAgICAgIG5vZGVJZCxcbiAgICAgICAgdGFyZ2V0OiBldmVudC5jdXJyZW50VGFyZ2V0XG4gICAgICB9KTtcbiAgICB9LFxuICAgIG9uQ2xpY2soZXZlbnQpIHtcbiAgICAgIGlmIChjbG9zZU9uQ2xpY2spIHtcbiAgICAgICAgbWVudUV2ZW50cy5lbWl0KCdjbG9zZScsIHtcbiAgICAgICAgICBkb21FdmVudDogZXZlbnQubmF0aXZlRXZlbnQsXG4gICAgICAgICAgcmVhc29uOiBSRUFTT05TLml0ZW1QcmVzc1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9LFxuICAgIG9uTW91c2VVcChldmVudCkge1xuICAgICAgaWYgKGNvbnRleHRNZW51Q29udGV4dCkge1xuICAgICAgICBjb25zdCBpbml0aWFsQ3Vyc29yUG9pbnQgPSBjb250ZXh0TWVudUNvbnRleHQuaW5pdGlhbEN1cnNvclBvaW50UmVmLmN1cnJlbnQ7XG4gICAgICAgIGNvbnRleHRNZW51Q29udGV4dC5pbml0aWFsQ3Vyc29yUG9pbnRSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICAgIGlmIChpc0NvbnRleHRNZW51ICYmIGluaXRpYWxDdXJzb3JQb2ludCAmJiBNYXRoLmFicyhldmVudC5jbGllbnRYIC0gaW5pdGlhbEN1cnNvclBvaW50LngpIDw9IDEgJiYgTWF0aC5hYnMoZXZlbnQuY2xpZW50WSAtIGluaXRpYWxDdXJzb3JQb2ludC55KSA8PSAxKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gT24gbm9uLW1hY09TIHBsYXRmb3JtcywgdGhpcyBtb3VzZXVwIGJlbG9uZ3MgdG8gdGhlIHJpZ2h0LWNsaWNrIGdlc3R1cmVcbiAgICAgICAgLy8gdGhhdCBvcGVuZWQgdGhlIGNvbnRleHQgbWVudSwgc28gaXQgbXVzdCBub3QgYWN0aXZhdGUgYW4gaXRlbS5cbiAgICAgICAgaWYgKGlzQ29udGV4dE1lbnUgJiYgIXBsYXRmb3JtLm9zLm1hYyAmJiBldmVudC5idXR0b24gPT09IDIpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmIChpdGVtUmVmLmN1cnJlbnQgJiYgc3RvcmUuY29udGV4dC5hbGxvd01vdXNlVXBUcmlnZ2VyUmVmLmN1cnJlbnQgJiYgKCFpc0NvbnRleHRNZW51IHx8IGV2ZW50LmJ1dHRvbiA9PT0gMikpIHtcbiAgICAgICAgLy8gVGhpcyBmaXJlcyB3aGVuZXZlciB0aGUgdXNlciBjbGlja3Mgb24gdGhlIHRyaWdnZXIsIG1vdmVzIHRoZSBjdXJzb3IsIGFuZCByZWxlYXNlcyBpdCBvdmVyIHRoZSBpdGVtLlxuICAgICAgICAvLyBXZSB0cmlnZ2VyIHRoZSBjbGljayBhbmQgb3ZlcnJpZGUgdGhlIGBjbG9zZU9uQ2xpY2tgIHByZWZlcmVuY2UgdG8gYWx3YXlzIGNsb3NlIHRoZSBtZW51LlxuICAgICAgICBpZiAoaXRlbU1ldGFkYXRhLnR5cGUgPT09ICdyZWd1bGFyLWl0ZW0nKSB7XG4gICAgICAgICAgLy8gYGRldGFpbDogMWAgYW5kIGBwb2ludGVyVHlwZTogJ21vdXNlJ2AgbWFyayB0aGlzIGFzIGEgbW91c2UtZ2VzdHVyZSBjbGljayBzb1xuICAgICAgICAgIC8vIE1lbnVSb290IGFuZCBGbG9hdGluZ0ZvY3VzTWFuYWdlciBkb24ndCB0cmVhdCBpdCBhcyBhIGtleWJvYXJkIGFjdGl2YXRpb24uXG4gICAgICAgICAgZGlzcGF0Y2hDbGlja1dpdGhNb2RpZmllcnMoaXRlbVJlZi5jdXJyZW50LCBldmVudCwge1xuICAgICAgICAgICAgZGV0YWlsOiAxLFxuICAgICAgICAgICAgcG9pbnRlclR5cGU6ICdtb3VzZSdcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgfSksIFtjbG9zZU9uQ2xpY2ssIHRhYkluZGV4LCBpZCwgbWVudUV2ZW50cywgbm9kZUlkLCBzdG9yZS5jb250ZXh0LmFsbG93TW91c2VVcFRyaWdnZXJSZWYsIHR5cGluZ1JlZiwgaXRlbVJlZiwgY29udGV4dE1lbnVDb250ZXh0LCBpc0NvbnRleHRNZW51LCBpdGVtTWV0YWRhdGEudHlwZSwgYXJpYVNlbGVjdGVkLCB2aXJ0dWFsRm9jdXNdKTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU1lcmdlZFJlZnMgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VNZXJnZWRSZWZzJztcbmltcG9ydCB7IHVzZUJ1dHRvbiB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlLWJ1dHRvbi9pbmRleC5tanNcIjtcbmltcG9ydCB7IG1lcmdlUHJvcHMgfSBmcm9tIFwiLi4vLi4vbWVyZ2UtcHJvcHMvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51SXRlbUNvbW1vblByb3BzIH0gZnJvbSBcIi4vdXNlTWVudUl0ZW1Db21tb25Qcm9wcy5tanNcIjtcbmV4cG9ydCBjb25zdCBSRUdVTEFSX0lURU0gPSB7XG4gIHR5cGU6ICdyZWd1bGFyLWl0ZW0nXG59O1xuZXhwb3J0IGZ1bmN0aW9uIHVzZU1lbnVJdGVtKHBhcmFtcykge1xuICBjb25zdCB7XG4gICAgY2xvc2VPbkNsaWNrLFxuICAgIGRpc2FibGVkLFxuICAgIGhpZ2hsaWdodGVkLFxuICAgIGlkLFxuICAgIHN0b3JlLFxuICAgIHR5cGluZ1JlZiA9IHN0b3JlLmNvbnRleHQudHlwaW5nUmVmLFxuICAgIG5hdGl2ZUJ1dHRvbixcbiAgICBpdGVtTWV0YWRhdGEsXG4gICAgbm9kZUlkXG4gIH0gPSBwYXJhbXM7XG4gIGNvbnN0IGl0ZW1SZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IHtcbiAgICBnZXRCdXR0b25Qcm9wcyxcbiAgICBidXR0b25SZWZcbiAgfSA9IHVzZUJ1dHRvbih7XG4gICAgZGlzYWJsZWQsXG4gICAgZm9jdXNhYmxlV2hlbkRpc2FibGVkOiB0cnVlLFxuICAgIG5hdGl2ZTogbmF0aXZlQnV0dG9uLFxuICAgIGNvbXBvc2l0ZTogdHJ1ZVxuICB9KTtcbiAgY29uc3QgY29tbW9uUHJvcHMgPSB1c2VNZW51SXRlbUNvbW1vblByb3BzKHtcbiAgICBjbG9zZU9uQ2xpY2ssXG4gICAgaGlnaGxpZ2h0ZWQsXG4gICAgaWQsXG4gICAgbm9kZUlkLFxuICAgIHN0b3JlLFxuICAgIHR5cGluZ1JlZixcbiAgICBpdGVtUmVmLFxuICAgIGl0ZW1NZXRhZGF0YVxuICB9KTtcbiAgY29uc3QgZ2V0SXRlbVByb3BzID0gUmVhY3QudXNlQ2FsbGJhY2soZXh0ZXJuYWxQcm9wcyA9PiB7XG4gICAgcmV0dXJuIG1lcmdlUHJvcHMoY29tbW9uUHJvcHMsIHtcbiAgICAgIG9uTW91c2VFbnRlcihldmVudCkge1xuICAgICAgICBpZiAoaXRlbU1ldGFkYXRhLnR5cGUgIT09ICdzdWJtZW51LXRyaWdnZXInKSB7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGl0ZW1NZXRhZGF0YS5zZXRBY3RpdmUoZXZlbnQubmF0aXZlRXZlbnQpO1xuICAgICAgfVxuICAgIH0sIGV4dGVybmFsUHJvcHMsIGdldEJ1dHRvblByb3BzKTtcbiAgfSwgW2NvbW1vblByb3BzLCBnZXRCdXR0b25Qcm9wcywgaXRlbU1ldGFkYXRhXSk7XG4gIGNvbnN0IG1lcmdlZFJlZiA9IHVzZU1lcmdlZFJlZnMoaXRlbVJlZiwgYnV0dG9uUmVmKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBnZXRJdGVtUHJvcHMsXG4gICAgaXRlbVJlZjogbWVyZ2VkUmVmXG4gIH0pLCBbZ2V0SXRlbVByb3BzLCBtZXJnZWRSZWZdKTtcbn0iLCIvKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgbWVudSBjaGVja2JveCBpdGVtIGlzIGNoZWNrZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBjaGVja2VkID0gJ2RhdGEtY2hlY2tlZCc7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgbWVudSBjaGVja2JveCBpdGVtIGlzIG5vdCBjaGVja2VkLlxuICovXG5leHBvcnQgY29uc3QgdW5jaGVja2VkID0gJ2RhdGEtdW5jaGVja2VkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBtZW51IGNoZWNrYm94IGl0ZW0gaXMgZGlzYWJsZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBkaXNhYmxlZCA9ICdkYXRhLWRpc2FibGVkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBtZW51IGNoZWNrYm94IGl0ZW0gaXMgaGlnaGxpZ2h0ZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBoaWdobGlnaHRlZCA9ICdkYXRhLWhpZ2hsaWdodGVkJzsiLCJpbXBvcnQgeyB0cmFuc2l0aW9uU3RhdHVzTWFwcGluZyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanNcIjtcbmltcG9ydCAqIGFzIE1lbnVDaGVja2JveEl0ZW1EYXRhQXR0cmlidXRlcyBmcm9tIFwiLi4vY2hlY2tib3gtaXRlbS9NZW51Q2hlY2tib3hJdGVtRGF0YUF0dHJpYnV0ZXMubWpzXCI7XG5leHBvcnQgY29uc3QgaXRlbU1hcHBpbmcgPSB7XG4gIGNoZWNrZWQodmFsdWUpIHtcbiAgICBpZiAodmFsdWUpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIFtNZW51Q2hlY2tib3hJdGVtRGF0YUF0dHJpYnV0ZXMuY2hlY2tlZF06ICcnXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgW01lbnVDaGVja2JveEl0ZW1EYXRhQXR0cmlidXRlcy51bmNoZWNrZWRdOiAnJ1xuICAgIH07XG4gIH0sXG4gIC4uLnRyYW5zaXRpb25TdGF0dXNNYXBwaW5nXG59OyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlQ29udHJvbGxlZCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUNvbnRyb2xsZWQnO1xuaW1wb3J0IHsgTk9PUCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2VtcHR5JztcbmltcG9ydCB7IHVzZU1lbnVGaWx0ZXJJdGVtIH0gZnJvbSBcIi4uL2ZpbHRlci1yb290L01lbnVGaWx0ZXJDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgTWVudUNoZWNrYm94SXRlbUNvbnRleHQgfSBmcm9tIFwiLi9NZW51Q2hlY2tib3hJdGVtQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IFJFR1VMQVJfSVRFTSwgdXNlTWVudUl0ZW0gfSBmcm9tIFwiLi4vaXRlbS91c2VNZW51SXRlbS5tanNcIjtcbmltcG9ydCB7IHVzZUNvbXBvc2l0ZUxpc3RJdGVtIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jb21wb3NpdGUvbGlzdC91c2VDb21wb3NpdGVMaXN0SXRlbS5tanNcIjtcbmltcG9ydCB7IHVzZU1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L01lbnVSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VCYXNlVWlJZCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlQmFzZVVpSWQubWpzXCI7XG5pbXBvcnQgeyBpdGVtTWFwcGluZyB9IGZyb20gXCIuLi91dGlscy9zdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmNvbnN0IE1lbnVDaGVja2JveEl0ZW1QbGFpbiA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIE1lbnVDaGVja2JveEl0ZW1QbGFpbihjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIGlkOiBpZFByb3AsXG4gICAgbGFiZWwsXG4gICAgbmF0aXZlQnV0dG9uID0gZmFsc2UsXG4gICAgZGlzYWJsZWQ6IGRpc2FibGVkUHJvcCA9IGZhbHNlLFxuICAgIGNsb3NlT25DbGljayA9IGZhbHNlLFxuICAgIGNoZWNrZWQgPSBmYWxzZSxcbiAgICBvbkNoZWNrZWRDaGFuZ2UsXG4gICAgc3R5bGUsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qge1xuICAgIHN0b3JlXG4gIH0gPSB1c2VNZW51Um9vdENvbnRleHQoKTtcbiAgY29uc3QgbGlzdEl0ZW0gPSB1c2VDb21wb3NpdGVMaXN0SXRlbSh7XG4gICAgZ3Vlc3M6IHRydWUsXG4gICAgbGFiZWxcbiAgfSk7XG4gIGNvbnN0IGlkID0gdXNlQmFzZVVpSWQoaWRQcm9wKTtcbiAgY29uc3Qgcm9vdERpc2FibGVkID0gc3RvcmUudXNlU3RhdGUoJ2Rpc2FibGVkJyk7XG4gIGNvbnN0IGhpZ2hsaWdodGVkID0gc3RvcmUudXNlU3RhdGUoJ2lzQWN0aXZlJywgbGlzdEl0ZW0uaW5kZXgpO1xuICBjb25zdCBub2RlSWQgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdOb2RlSWQnKTtcbiAgY29uc3QgaXRlbVByb3BzID0gc3RvcmUudXNlU3RhdGUoJ2l0ZW1Qcm9wcycpO1xuICBjb25zdCBkaXNhYmxlZCA9IGRpc2FibGVkUHJvcCB8fCByb290RGlzYWJsZWQ7XG4gIGNvbnN0IHtcbiAgICBnZXRJdGVtUHJvcHMsXG4gICAgaXRlbVJlZlxuICB9ID0gdXNlTWVudUl0ZW0oe1xuICAgIGNsb3NlT25DbGljayxcbiAgICBkaXNhYmxlZCxcbiAgICBoaWdobGlnaHRlZCxcbiAgICBpZCxcbiAgICBzdG9yZSxcbiAgICBuYXRpdmVCdXR0b24sXG4gICAgbm9kZUlkLFxuICAgIGl0ZW1NZXRhZGF0YTogUkVHVUxBUl9JVEVNXG4gIH0pO1xuICBjb25zdCBzdGF0ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBkaXNhYmxlZCxcbiAgICBoaWdobGlnaHRlZCxcbiAgICBjaGVja2VkXG4gIH0pLCBbZGlzYWJsZWQsIGhpZ2hsaWdodGVkLCBjaGVja2VkXSk7XG4gIGZ1bmN0aW9uIGhhbmRsZUNsaWNrKGV2ZW50KSB7XG4gICAgY29uc3QgZGV0YWlscyA9IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLml0ZW1QcmVzcywgZXZlbnQubmF0aXZlRXZlbnQsIHVuZGVmaW5lZCwge1xuICAgICAgcHJldmVudFVubW91bnRPbkNsb3NlOiBOT09QXG4gICAgfSk7XG4gICAgb25DaGVja2VkQ2hhbmdlPy4oIWNoZWNrZWQsIGRldGFpbHMpO1xuICB9XG4gIGNvbnN0IGVsZW1lbnQgPSB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHN0YXRlLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmc6IGl0ZW1NYXBwaW5nLFxuICAgIHByb3BzOiBbaXRlbVByb3BzLCB7XG4gICAgICByb2xlOiAnbWVudWl0ZW1jaGVja2JveCcsXG4gICAgICAnYXJpYS1jaGVja2VkJzogY2hlY2tlZCxcbiAgICAgIG9uQ2xpY2s6IGhhbmRsZUNsaWNrXG4gICAgfSwgZWxlbWVudFByb3BzLCBnZXRJdGVtUHJvcHNdLFxuICAgIHJlZjogW2l0ZW1SZWYsIGZvcndhcmRlZFJlZiwgbGlzdEl0ZW0ucmVmXVxuICB9KTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KE1lbnVDaGVja2JveEl0ZW1Db250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IHN0YXRlLFxuICAgIGNoaWxkcmVuOiBlbGVtZW50XG4gIH0pO1xufSk7XG5cbi8qKlxuICogQSBtZW51IGl0ZW0gdGhhdCB0b2dnbGVzIGEgc2V0dGluZyBvbiBvciBvZmYuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIE1lbnVdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9tZW51KVxuICovXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51Q2hlY2tib3hJdGVtUGxhaW4uZGlzcGxheU5hbWUgPSBcIk1lbnVDaGVja2JveEl0ZW1QbGFpblwiO1xuZXhwb3J0IGNvbnN0IE1lbnVDaGVja2JveEl0ZW0gPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBNZW51Q2hlY2tib3hJdGVtKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIGNoZWNrZWQ6IGNoZWNrZWRQcm9wLFxuICAgIGRlZmF1bHRDaGVja2VkLFxuICAgIG9uQ2hlY2tlZENoYW5nZSxcbiAgICAuLi5wbGFpblByb3BzXG4gIH0gPSBwcm9wcztcblxuICAvLyBPd25lZCBhYm92ZSB0aGUgZWxlbWVudCBzbyBhbiB1bmNvbnRyb2xsZWQgaXRlbSBrZWVwcyBpdHMgc3RhdGUgd2hpbGUgYSBmaWx0ZXIgaGlkZXMgaXQuXG4gIGNvbnN0IFtjaGVja2VkLCBzZXRDaGVja2VkXSA9IHVzZUNvbnRyb2xsZWQoe1xuICAgIGNvbnRyb2xsZWQ6IGNoZWNrZWRQcm9wLFxuICAgIGRlZmF1bHQ6IGRlZmF1bHRDaGVja2VkID8/IGZhbHNlLFxuICAgIG5hbWU6ICdNZW51Q2hlY2tib3hJdGVtJyxcbiAgICBzdGF0ZTogJ2NoZWNrZWQnXG4gIH0pO1xuICBjb25zdCBmaWx0ZXJJdGVtID0gdXNlTWVudUZpbHRlckl0ZW0ocHJvcHMsIGZvcndhcmRlZFJlZik7XG4gIGZ1bmN0aW9uIGhhbmRsZUNoZWNrZWRDaGFuZ2UobmV4dENoZWNrZWQsIGV2ZW50RGV0YWlscykge1xuICAgIG9uQ2hlY2tlZENoYW5nZT8uKG5leHRDaGVja2VkLCBldmVudERldGFpbHMpO1xuICAgIGlmICghZXZlbnREZXRhaWxzLmlzQ2FuY2VsZWQpIHtcbiAgICAgIHNldENoZWNrZWQobmV4dENoZWNrZWQpO1xuICAgIH1cbiAgfVxuICBpZiAoIWZpbHRlckl0ZW0udmlzaWJsZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChNZW51Q2hlY2tib3hJdGVtUGxhaW4sIHtcbiAgICAuLi5wbGFpblByb3BzLFxuICAgIGNoZWNrZWQ6IGNoZWNrZWQsXG4gICAgb25DaGVja2VkQ2hhbmdlOiBoYW5kbGVDaGVja2VkQ2hhbmdlLFxuICAgIHJlZjogZmlsdGVySXRlbS5yZWZcbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnVDaGVja2JveEl0ZW0uZGlzcGxheU5hbWUgPSBcIk1lbnVDaGVja2JveEl0ZW1cIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU1lbnVDaGVja2JveEl0ZW1Db250ZXh0IH0gZnJvbSBcIi4uL2NoZWNrYm94LWl0ZW0vTWVudUNoZWNrYm94SXRlbUNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgaXRlbU1hcHBpbmcgfSBmcm9tIFwiLi4vdXRpbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanNcIjtcbmltcG9ydCB7IHVzZVRyYW5zaXRpb25TdGF0dXMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVRyYW5zaXRpb25TdGF0dXMubWpzXCI7XG5pbXBvcnQgeyB1c2VPcGVuQ2hhbmdlQ29tcGxldGUgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZU9wZW5DaGFuZ2VDb21wbGV0ZS5tanNcIjtcblxuLyoqXG4gKiBJbmRpY2F0ZXMgd2hldGhlciB0aGUgY2hlY2tib3ggaXRlbSBpcyB0aWNrZWQuXG4gKiBSZW5kZXJzIGEgYDxzcGFuPmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBNZW51XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvbWVudSlcbiAqL1xuZXhwb3J0IGNvbnN0IE1lbnVDaGVja2JveEl0ZW1JbmRpY2F0b3IgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBNZW51Q2hlY2tib3hJdGVtSW5kaWNhdG9yKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAga2VlcE1vdW50ZWQgPSBmYWxzZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCBpdGVtID0gdXNlTWVudUNoZWNrYm94SXRlbUNvbnRleHQoKTtcbiAgY29uc3QgaW5kaWNhdG9yUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCB7XG4gICAgdHJhbnNpdGlvblN0YXR1cyxcbiAgICBtb3VudGVkLFxuICAgIHNldE1vdW50ZWRcbiAgfSA9IHVzZVRyYW5zaXRpb25TdGF0dXMoaXRlbS5jaGVja2VkKTtcbiAgdXNlT3BlbkNoYW5nZUNvbXBsZXRlKHtcbiAgICBiYXRjaDogdHJ1ZSxcbiAgICBlbmFibGVkOiAhaXRlbS5jaGVja2VkLFxuICAgIG9wZW46IGl0ZW0uY2hlY2tlZCxcbiAgICByZWY6IGluZGljYXRvclJlZixcbiAgICBvbkNvbXBsZXRlKCkge1xuICAgICAgaWYgKCFpdGVtLmNoZWNrZWQpIHtcbiAgICAgICAgc2V0TW91bnRlZChmYWxzZSk7XG4gICAgICB9XG4gICAgfVxuICB9KTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgY2hlY2tlZDogaXRlbS5jaGVja2VkLFxuICAgIGRpc2FibGVkOiBpdGVtLmRpc2FibGVkLFxuICAgIGhpZ2hsaWdodGVkOiBpdGVtLmhpZ2hsaWdodGVkLFxuICAgIHRyYW5zaXRpb25TdGF0dXNcbiAgfTtcbiAgY29uc3QgZWxlbWVudCA9IHVzZVJlbmRlckVsZW1lbnQoJ3NwYW4nLCBjb21wb25lbnRQcm9wcywge1xuICAgIHN0YXRlLFxuICAgIHJlZjogW2ZvcndhcmRlZFJlZiwgaW5kaWNhdG9yUmVmXSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiBpdGVtTWFwcGluZyxcbiAgICBwcm9wczoge1xuICAgICAgJ2FyaWEtaGlkZGVuJzogdHJ1ZSxcbiAgICAgIC4uLmVsZW1lbnRQcm9wc1xuICAgIH0sXG4gICAgZW5hYmxlZDoga2VlcE1vdW50ZWQgfHwgbW91bnRlZFxuICB9KTtcbiAgcmV0dXJuIGVsZW1lbnQ7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnVDaGVja2JveEl0ZW1JbmRpY2F0b3IuZGlzcGxheU5hbWUgPSBcIk1lbnVDaGVja2JveEl0ZW1JbmRpY2F0b3JcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCBfZm9ybWF0RXJyb3JNZXNzYWdlIGZyb20gXCJAYmFzZS11aS91dGlscy9mb3JtYXRFcnJvck1lc3NhZ2VcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBNZW51R3JvdXBDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQodW5kZWZpbmVkKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnVHcm91cENvbnRleHQuZGlzcGxheU5hbWUgPSBcIk1lbnVHcm91cENvbnRleHRcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VNZW51R3JvdXBSb290Q29udGV4dCgpIHtcbiAgY29uc3QgY29udGV4dCA9IFJlYWN0LnVzZUNvbnRleHQoTWVudUdyb3VwQ29udGV4dCk7XG4gIGlmIChjb250ZXh0ID09PSB1bmRlZmluZWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gJ0Jhc2UgVUk6IE1lbnVHcm91cENvbnRleHQgaXMgbWlzc2luZy4gTWVudSBncm91cCBwYXJ0cyBtdXN0IGJlIHVzZWQgd2l0aGluIDxNZW51Lkdyb3VwPiBvciA8TWVudS5SYWRpb0dyb3VwPi4nIDogX2Zvcm1hdEVycm9yTWVzc2FnZSgzMSkpO1xuICB9XG4gIHJldHVybiBjb250ZXh0O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTWVudUZpbHRlckltcGwgfSBmcm9tIFwiLi4vZmlsdGVyLXJvb3QvTWVudUZpbHRlckNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgTWVudUdyb3VwQ29udGV4dCB9IGZyb20gXCIuL01lbnVHcm91cENvbnRleHQubWpzXCI7XG5cbi8qKlxuICogQGludGVybmFsXG4gKi9cbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgY29uc3QgTWVudUdyb3VwUGxhaW4gPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBNZW51R3JvdXBQbGFpbihjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IFtsYWJlbElkLCBzZXRMYWJlbElkXSA9IFJlYWN0LnVzZVN0YXRlKHVuZGVmaW5lZCk7XG4gIGNvbnN0IGVsZW1lbnQgPSB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgIHByb3BzOiB7XG4gICAgICByb2xlOiAnZ3JvdXAnLFxuICAgICAgJ2FyaWEtbGFiZWxsZWRieSc6IGxhYmVsSWQsXG4gICAgICAuLi5lbGVtZW50UHJvcHNcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goTWVudUdyb3VwQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBzZXRMYWJlbElkLFxuICAgIGNoaWxkcmVuOiBlbGVtZW50XG4gIH0pO1xufSk7XG5cbi8qKlxuICogR3JvdXBzIHJlbGF0ZWQgbWVudSBpdGVtcyB3aXRoIHRoZSBjb3JyZXNwb25kaW5nIGxhYmVsLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBNZW51XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvbWVudSlcbiAqL1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgTWVudUdyb3VwUGxhaW4uZGlzcGxheU5hbWUgPSBcIk1lbnVHcm91cFBsYWluXCI7XG5leHBvcnQgY29uc3QgTWVudUdyb3VwID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gTWVudUdyb3VwKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3QgR3JvdXAgPSB1c2VNZW51RmlsdGVySW1wbCgpPy5Hcm91cCA/PyBNZW51R3JvdXBQbGFpbjtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KEdyb3VwLCB7XG4gICAgLi4ucHJvcHMsXG4gICAgcmVmOiBmb3J3YXJkZWRSZWZcbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnVHcm91cC5kaXNwbGF5TmFtZSA9IFwiTWVudUdyb3VwXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgdXNlUmVuZGVyRWxlbWVudCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlUmVuZGVyRWxlbWVudC5tanNcIjtcbmltcG9ydCB7IHVzZUJhc2VVaUlkIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VCYXNlVWlJZC5tanNcIjtcbmltcG9ydCB7IHVzZU1lbnVHcm91cFJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL2dyb3VwL01lbnVHcm91cENvbnRleHQubWpzXCI7XG5cbi8qKlxuICogQW4gYWNjZXNzaWJsZSBsYWJlbCB0aGF0IGlzIGF1dG9tYXRpY2FsbHkgYXNzb2NpYXRlZCB3aXRoIGl0cyBwYXJlbnQgZ3JvdXAuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIE1lbnVdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9tZW51KVxuICovXG5leHBvcnQgY29uc3QgTWVudUdyb3VwTGFiZWwgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBNZW51R3JvdXBMYWJlbChjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIGlkOiBpZFByb3AsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3QgaWQgPSB1c2VCYXNlVWlJZChpZFByb3ApO1xuICBjb25zdCBzZXRMYWJlbElkID0gdXNlTWVudUdyb3VwUm9vdENvbnRleHQoKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBzZXRMYWJlbElkKGlkKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgc2V0TGFiZWxJZChjdXJyZW50SWQgPT4gY3VycmVudElkID09PSBpZCA/IHVuZGVmaW5lZCA6IGN1cnJlbnRJZCk7XG4gICAgfTtcbiAgfSwgW3NldExhYmVsSWQsIGlkXSk7XG4gIHJldHVybiB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHJlZjogZm9yd2FyZGVkUmVmLFxuICAgIHByb3BzOiB7XG4gICAgICBpZCxcbiAgICAgICdhcmlhLWhpZGRlbic6IHRydWUsXG4gICAgICAuLi5lbGVtZW50UHJvcHNcbiAgICB9XG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51R3JvdXBMYWJlbC5kaXNwbGF5TmFtZSA9IFwiTWVudUdyb3VwTGFiZWxcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZU1lbnVGaWx0ZXJJdGVtIH0gZnJvbSBcIi4uL2ZpbHRlci1yb290L01lbnVGaWx0ZXJDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgUkVHVUxBUl9JVEVNLCB1c2VNZW51SXRlbSB9IGZyb20gXCIuL3VzZU1lbnVJdGVtLm1qc1wiO1xuaW1wb3J0IHsgdXNlTWVudVJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvTWVudVJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVuZGVyRWxlbWVudCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlUmVuZGVyRWxlbWVudC5tanNcIjtcbmltcG9ydCB7IHVzZUJhc2VVaUlkIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VCYXNlVWlJZC5tanNcIjtcbmltcG9ydCB7IHVzZUNvbXBvc2l0ZUxpc3RJdGVtIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jb21wb3NpdGUvbGlzdC91c2VDb21wb3NpdGVMaXN0SXRlbS5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5jb25zdCBNZW51SXRlbVBsYWluID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gTWVudUl0ZW1QbGFpbihjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIGlkOiBpZFByb3AsXG4gICAgbGFiZWwsXG4gICAgbmF0aXZlQnV0dG9uID0gZmFsc2UsXG4gICAgZGlzYWJsZWQ6IGRpc2FibGVkUHJvcCA9IGZhbHNlLFxuICAgIGNsb3NlT25DbGljayA9IHRydWUsXG4gICAgc3R5bGUsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qge1xuICAgIHN0b3JlXG4gIH0gPSB1c2VNZW51Um9vdENvbnRleHQoKTtcbiAgY29uc3QgbGlzdEl0ZW0gPSB1c2VDb21wb3NpdGVMaXN0SXRlbSh7XG4gICAgZ3Vlc3M6IHRydWUsXG4gICAgbGFiZWxcbiAgfSk7XG4gIGNvbnN0IGlkID0gdXNlQmFzZVVpSWQoaWRQcm9wKTtcbiAgY29uc3Qgcm9vdERpc2FibGVkID0gc3RvcmUudXNlU3RhdGUoJ2Rpc2FibGVkJyk7XG4gIGNvbnN0IGhpZ2hsaWdodGVkID0gc3RvcmUudXNlU3RhdGUoJ2lzQWN0aXZlJywgbGlzdEl0ZW0uaW5kZXgpO1xuICBjb25zdCBub2RlSWQgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdOb2RlSWQnKTtcbiAgY29uc3QgaXRlbVByb3BzID0gc3RvcmUudXNlU3RhdGUoJ2l0ZW1Qcm9wcycpO1xuICBjb25zdCBkaXNhYmxlZCA9IGRpc2FibGVkUHJvcCB8fCByb290RGlzYWJsZWQ7XG4gIGNvbnN0IHtcbiAgICBnZXRJdGVtUHJvcHMsXG4gICAgaXRlbVJlZlxuICB9ID0gdXNlTWVudUl0ZW0oe1xuICAgIGNsb3NlT25DbGljayxcbiAgICBkaXNhYmxlZCxcbiAgICBoaWdobGlnaHRlZCxcbiAgICBpZCxcbiAgICBzdG9yZSxcbiAgICBuYXRpdmVCdXR0b24sXG4gICAgbm9kZUlkLFxuICAgIGl0ZW1NZXRhZGF0YTogUkVHVUxBUl9JVEVNXG4gIH0pO1xuICBjb25zdCBzdGF0ZSA9IHtcbiAgICBkaXNhYmxlZCxcbiAgICBoaWdobGlnaHRlZFxuICB9O1xuICByZXR1cm4gdXNlUmVuZGVyRWxlbWVudCgnZGl2JywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICBwcm9wczogW2l0ZW1Qcm9wcywgZWxlbWVudFByb3BzLCBnZXRJdGVtUHJvcHNdLFxuICAgIHJlZjogW2l0ZW1SZWYsIGZvcndhcmRlZFJlZiwgbGlzdEl0ZW0ucmVmXVxuICB9KTtcbn0pO1xuXG4vKipcbiAqIEFuIGluZGl2aWR1YWwgaW50ZXJhY3RpdmUgaXRlbSBpbiB0aGUgbWVudS5cbiAqIFJlbmRlcnMgYSBgPGRpdj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgTWVudV0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL21lbnUpXG4gKi9cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnVJdGVtUGxhaW4uZGlzcGxheU5hbWUgPSBcIk1lbnVJdGVtUGxhaW5cIjtcbmV4cG9ydCBjb25zdCBNZW51SXRlbSA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIE1lbnVJdGVtKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3QgZmlsdGVySXRlbSA9IHVzZU1lbnVGaWx0ZXJJdGVtKHByb3BzLCBmb3J3YXJkZWRSZWYpO1xuICBpZiAoIWZpbHRlckl0ZW0udmlzaWJsZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChNZW51SXRlbVBsYWluLCB7XG4gICAgLi4ucHJvcHMsXG4gICAgcmVmOiBmaWx0ZXJJdGVtLnJlZlxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgTWVudUl0ZW0uZGlzcGxheU5hbWUgPSBcIk1lbnVJdGVtXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VNZW51RmlsdGVySXRlbSB9IGZyb20gXCIuLi9maWx0ZXItcm9vdC9NZW51RmlsdGVyQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZU1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L01lbnVSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VCYXNlVWlJZCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlQmFzZVVpSWQubWpzXCI7XG5pbXBvcnQgeyB1c2VDb21wb3NpdGVMaXN0SXRlbSB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY29tcG9zaXRlL2xpc3QvdXNlQ29tcG9zaXRlTGlzdEl0ZW0ubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51SXRlbUNvbW1vblByb3BzIH0gZnJvbSBcIi4uL2l0ZW0vdXNlTWVudUl0ZW1Db21tb25Qcm9wcy5tanNcIjtcbmltcG9ydCB7IFJFR1VMQVJfSVRFTSB9IGZyb20gXCIuLi9pdGVtL3VzZU1lbnVJdGVtLm1qc1wiO1xuaW1wb3J0IHsgdXNlQnV0dG9uIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2UtYnV0dG9uL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgbWVyZ2VQcm9wcyB9IGZyb20gXCIuLi8uLi9tZXJnZS1wcm9wcy9pbmRleC5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5jb25zdCBNZW51TGlua0l0ZW1QbGFpbiA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIE1lbnVMaW5rSXRlbVBsYWluKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgaWQ6IGlkUHJvcCxcbiAgICBsYWJlbCxcbiAgICBjbG9zZU9uQ2xpY2sgPSBmYWxzZSxcbiAgICBzdHlsZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCB7XG4gICAgc3RvcmVcbiAgfSA9IHVzZU1lbnVSb290Q29udGV4dCgpO1xuICBjb25zdCBsaW5rUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBsaXN0SXRlbSA9IHVzZUNvbXBvc2l0ZUxpc3RJdGVtKHtcbiAgICBndWVzczogdHJ1ZSxcbiAgICBsYWJlbFxuICB9KTtcbiAgY29uc3QgaWQgPSB1c2VCYXNlVWlJZChpZFByb3ApO1xuICBjb25zdCBoaWdobGlnaHRlZCA9IHN0b3JlLnVzZVN0YXRlKCdpc0FjdGl2ZScsIGxpc3RJdGVtLmluZGV4KTtcbiAgY29uc3Qgbm9kZUlkID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nTm9kZUlkJyk7XG4gIGNvbnN0IGl0ZW1Qcm9wcyA9IHN0b3JlLnVzZVN0YXRlKCdpdGVtUHJvcHMnKTtcbiAgY29uc3QgdHlwaW5nUmVmID0gc3RvcmUuY29udGV4dC50eXBpbmdSZWY7XG4gIGNvbnN0IHtcbiAgICBnZXRCdXR0b25Qcm9wcyxcbiAgICBidXR0b25SZWZcbiAgfSA9IHVzZUJ1dHRvbih7XG4gICAgbmF0aXZlOiBmYWxzZSxcbiAgICBjb21wb3NpdGU6IHRydWVcbiAgfSk7XG4gIGNvbnN0IGNvbW1vblByb3BzID0gdXNlTWVudUl0ZW1Db21tb25Qcm9wcyh7XG4gICAgY2xvc2VPbkNsaWNrLFxuICAgIGhpZ2hsaWdodGVkLFxuICAgIGlkLFxuICAgIG5vZGVJZCxcbiAgICBzdG9yZSxcbiAgICB0eXBpbmdSZWYsXG4gICAgaXRlbVJlZjogbGlua1JlZixcbiAgICBpdGVtTWV0YWRhdGE6IFJFR1VMQVJfSVRFTVxuICB9KTtcbiAgZnVuY3Rpb24gZ2V0SXRlbVByb3BzKGV4dGVybmFsUHJvcHMpIHtcbiAgICByZXR1cm4gbWVyZ2VQcm9wcyhjb21tb25Qcm9wcywgZXh0ZXJuYWxQcm9wcywgZ2V0QnV0dG9uUHJvcHMpO1xuICB9XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIGhpZ2hsaWdodGVkXG4gIH07XG4gIHJldHVybiB1c2VSZW5kZXJFbGVtZW50KCdhJywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICBwcm9wczogW2l0ZW1Qcm9wcywgZWxlbWVudFByb3BzLCBnZXRJdGVtUHJvcHNdLFxuICAgIHJlZjogW2xpbmtSZWYsIGJ1dHRvblJlZiwgZm9yd2FyZGVkUmVmLCBsaXN0SXRlbS5yZWZdXG4gIH0pO1xufSk7XG5cbi8qKlxuICogQSBsaW5rIGluIHRoZSBtZW51IHRoYXQgY2FuIGJlIHVzZWQgdG8gbmF2aWdhdGUgdG8gYSBkaWZmZXJlbnQgcGFnZSBvciBzZWN0aW9uLlxuICogUmVuZGVycyBhbiBgPGE+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIE1lbnVdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9tZW51KVxuICovXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51TGlua0l0ZW1QbGFpbi5kaXNwbGF5TmFtZSA9IFwiTWVudUxpbmtJdGVtUGxhaW5cIjtcbmV4cG9ydCBjb25zdCBNZW51TGlua0l0ZW0gPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBNZW51TGlua0l0ZW0ocHJvcHMsIGZvcndhcmRlZFJlZikge1xuICAvLyBUaGUgcHVibGljIHJlZiB0eXBlIHN0YXlzIGBFbGVtZW50YCBhcyBiZWZvcmU7IHRoZSByZW5kZXJlZCBgPGE+YCBpcyBhbHdheXMgYW4gYEhUTUxFbGVtZW50YC5cbiAgY29uc3QgZmlsdGVySXRlbSA9IHVzZU1lbnVGaWx0ZXJJdGVtKHByb3BzLCBmb3J3YXJkZWRSZWYpO1xuICBpZiAoIWZpbHRlckl0ZW0udmlzaWJsZSkge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChNZW51TGlua0l0ZW1QbGFpbiwge1xuICAgIC4uLnByb3BzLFxuICAgIHJlZjogZmlsdGVySXRlbS5yZWZcbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnVMaW5rSXRlbS5kaXNwbGF5TmFtZSA9IFwiTWVudUxpbmtJdGVtXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgTWVudVN1Ym1lbnVSb290Q29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHVuZGVmaW5lZCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51U3VibWVudVJvb3RDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJNZW51U3VibWVudVJvb3RDb250ZXh0XCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlTWVudVN1Ym1lbnVSb290Q29udGV4dCgpIHtcbiAgcmV0dXJuIFJlYWN0LnVzZUNvbnRleHQoTWVudVN1Ym1lbnVSb290Q29udGV4dCk7XG59IiwiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdW53cmFwTGF6eVJlbmRlclByb3AgfSBmcm9tIFwiLi91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuLyoqXG4gKiBSZXNvbHZlcyBhbiBlbGVtZW50J3MgaWQgdXNpbmcgdGhlIHNhbWUgcHJlY2VkZW5jZSBhcyBgdXNlUmVuZGVyRWxlbWVudGAuXG4gKiBSZXR1cm5zIGAnJ2Agd2hlbiB0aGUgZWxlbWVudCByZW5kZXJzIHdpdGggYW4gZXhwbGljaXRseSBlbXB0eSBpZCwgd2hpY2ggY29uc3VtZXJzIG11c3QgdHJlYXRcbiAqIGFzIFwibm8gaWRcIiByYXRoZXIgdGhhbiBmYWxsaW5nIGJhY2sgdG8gdGhlIGdlbmVyYXRlZCBvbmUsIHNvIEFSSUEgcmVsYXRpb25zaGlwcyBuZXZlciByZWZlcmVuY2VcbiAqIGFuIGlkIG5vIGVsZW1lbnQgY2Fycmllcy4gUmVuZGVyIGNhbGxiYWNrcyBhcmUgb3BhcXVlIGFuZCBhcmUgZXhwZWN0ZWQgdG8gdXNlIHRoZSBpZCBwYXNzZWQgdG9cbiAqIHRoZW0uXG4gKlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiByZXNvbHZlUmVuZGVyZWRJZChwcm9wcywgZmFsbGJhY2tJZCkge1xuICBjb25zdCByZW5kZXIgPSB1bndyYXBMYXp5UmVuZGVyUHJvcChwcm9wcy5yZW5kZXIpO1xuICBpZiAoLyojX19QVVJFX18qL1JlYWN0LmlzVmFsaWRFbGVtZW50KHJlbmRlcikpIHtcbiAgICBjb25zdCByZW5kZXJQcm9wcyA9IHJlbmRlci5wcm9wcztcbiAgICBpZiAoT2JqZWN0Lmhhc093bihyZW5kZXJQcm9wcywgJ2lkJykpIHtcbiAgICAgIHJldHVybiByZW5kZXJQcm9wcy5pZCA/PyAnJztcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHByb3BzLmlkID8/IGZhbGxiYWNrSWQ7XG59XG5cbi8qKlxuICogUmVzb2x2ZXMgdGhlIGVsZW1lbnQncyBpZCBhbmQgcmV0dXJucyBhIHJlZiB0aGF0IHB1Ymxpc2hlcyBpdCB0byB0aGUgb3duZXIgd2hpbGUgbW91bnRlZC5cbiAqIEEgZ2VuZXJhdGVkIGZhbGxiYWNrIGlzIG5ldmVyIHB1Ymxpc2hlZCBhcyBhbiBvdmVycmlkZSwgc28gcmVtb3ZpbmcgYW4gZXhwbGljaXQgaWQgbGV0cyB0aGVcbiAqIGVsZW1lbnQgcmV0dXJuIHRvIHRoZSBnZW5lcmF0ZWQgb25lLlxuICpcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlUmVuZGVyZWRJZChwcm9wcywgZGVmYXVsdElkLCBzZXRJZCkge1xuICBjb25zdCBpZCA9IHJlc29sdmVSZW5kZXJlZElkKHByb3BzLCBkZWZhdWx0SWQpO1xuICBjb25zdCByZWdpc3RlcmVkSWQgPSBpZCA9PT0gZGVmYXVsdElkID8gdW5kZWZpbmVkIDogaWQ7XG4gIGNvbnN0IHJlZiA9IFJlYWN0LnVzZUNhbGxiYWNrKGVsZW1lbnQgPT4gc2V0SWQ/LihlbGVtZW50ID8gcmVnaXN0ZXJlZElkIDogdW5kZWZpbmVkKSwgW3JlZ2lzdGVyZWRJZCwgc2V0SWRdKTtcbiAgcmV0dXJuIFtpZCwgcmVmXTtcbn0iLCJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1bndyYXBMYXp5UmVuZGVyUHJvcCB9IGZyb20gXCIuL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZVBvcHVwTGFiZWwocHJvcHMsIGFjdGl2ZVRyaWdnZXJFbGVtZW50LCBhY3RpdmVUcmlnZ2VySWQpIHtcbiAgY29uc3QgcmVuZGVyID0gdW53cmFwTGF6eVJlbmRlclByb3AocHJvcHMucmVuZGVyKTtcbiAgY29uc3QgcmVuZGVyZWRFbGVtZW50UHJvcHMgPSAvKiNfX1BVUkVfXyovUmVhY3QuaXNWYWxpZEVsZW1lbnQocmVuZGVyKSA/IHJlbmRlci5wcm9wcyA6IHVuZGVmaW5lZDtcbiAgY29uc3QgYXJpYUxhYmVsID0gcHJvcHNbJ2FyaWEtbGFiZWwnXSA/PyByZW5kZXJlZEVsZW1lbnRQcm9wcz8uWydhcmlhLWxhYmVsJ107XG4gIGxldCBhcmlhTGFiZWxsZWRCeSA9IHByb3BzWydhcmlhLWxhYmVsbGVkYnknXSA/PyByZW5kZXJlZEVsZW1lbnRQcm9wcz8uWydhcmlhLWxhYmVsbGVkYnknXTtcbiAgaWYgKGFyaWFMYWJlbGxlZEJ5ID09IG51bGwgJiYgIWFyaWFMYWJlbCkge1xuICAgIC8vIFByZWZlciB0aGUgZWxlbWVudCdzIGxpdmUgaWQ6IGEgYHJlbmRlcmAgZWxlbWVudCdzIG93biBpZCB3aW5zIG92ZXIgdGhlIHJlZ2lzdGVyZWQgb25lLlxuICAgIGFyaWFMYWJlbGxlZEJ5ID0gYWN0aXZlVHJpZ2dlckVsZW1lbnQgPyBhY3RpdmVUcmlnZ2VyRWxlbWVudC5pZCB8fCB1bmRlZmluZWQgOiBhY3RpdmVUcmlnZ2VySWQgfHwgdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiBhcmlhTGFiZWxsZWRCeTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IEZsb2F0aW5nRm9jdXNNYW5hZ2VyLCB1c2VIb3ZlckZsb2F0aW5nSW50ZXJhY3Rpb24gfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51Um9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9NZW51Um9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51UG9zaXRpb25lckNvbnRleHQgfSBmcm9tIFwiLi4vcG9zaXRpb25lci9NZW51UG9zaXRpb25lckNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgcG9wdXBUcmFuc2l0aW9uU3RhdGVNYXBwaW5nIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwU3RhdGVNYXBwaW5nLm1qc1wiO1xuaW1wb3J0IHsgdXNlT3BlbkNoYW5nZUNvbXBsZXRlIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VPcGVuQ2hhbmdlQ29tcGxldGUubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5pbXBvcnQgeyB1c2VUb29sYmFyUm9vdENvbnRleHQgfSBmcm9tIFwiLi4vLi4vdG9vbGJhci9yb290L1Rvb2xiYXJSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IENPTVBPU0lURV9LRVlTIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jb21wb3NpdGUvY29tcG9zaXRlLm1qc1wiO1xuaW1wb3J0IHsgZ2V0RGlzYWJsZWRNb3VudFRyYW5zaXRpb25TdHlsZXMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2dldERpc2FibGVkTW91bnRUcmFuc2l0aW9uU3R5bGVzLm1qc1wiO1xuaW1wb3J0IHsgdXNlTWVudVN1Ym1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi9zdWJtZW51LXJvb3QvTWVudVN1Ym1lbnVSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlcmVkSWQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3Jlc29sdmVSZW5kZXJlZElkLm1qc1wiO1xuaW1wb3J0IHsgcmVzb2x2ZVBvcHVwTGFiZWwgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3Jlc29sdmVQb3B1cExhYmVsLm1qc1wiO1xuaW1wb3J0IHsgTWVudUZpbHRlckltcGxDb250ZXh0LCB1c2VNZW51RmlsdGVySW1wbCB9IGZyb20gXCIuLi9maWx0ZXItcm9vdC9NZW51RmlsdGVyQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgY29uc3QgTWVudVBvcHVwUGxhaW4gPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBNZW51UG9wdXBQbGFpbihjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIGZpbmFsRm9jdXMsXG4gICAgaWQ6IGlkUHJvcCxcbiAgICBpbml0aWFsRm9jdXM6IGluaXRpYWxGb2N1c1Byb3AsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3Qge1xuICAgIHN0b3JlLFxuICAgIGRlZmF1bHRGbG9hdGluZ0lkLFxuICAgIHNldFJlbmRlcmVkRmxvYXRpbmdJZCxcbiAgICB2aXJ0dWFsRm9jdXMsXG4gICAgb3JpZW50YXRpb25cbiAgfSA9IHVzZU1lbnVSb290Q29udGV4dCgpO1xuICBjb25zdCBpbmhlcml0ZWRTdWJtZW51Um9vdENvbnRleHQgPSB1c2VNZW51U3VibWVudVJvb3RDb250ZXh0KCk7XG4gIGNvbnN0IHtcbiAgICBzaWRlLFxuICAgIGFsaWduXG4gIH0gPSB1c2VNZW51UG9zaXRpb25lckNvbnRleHQoKTtcbiAgY29uc3QgaW5zaWRlVG9vbGJhciA9IHVzZVRvb2xiYXJSb290Q29udGV4dCh0cnVlKSAhPSBudWxsO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3QgdHJhbnNpdGlvblN0YXR1cyA9IHN0b3JlLnVzZVN0YXRlKCd0cmFuc2l0aW9uU3RhdHVzJyk7XG4gIGNvbnN0IHBvcHVwUHJvcHMgPSBzdG9yZS51c2VTdGF0ZSgncG9wdXBQcm9wcycpO1xuICBjb25zdCBtb3VudGVkID0gc3RvcmUudXNlU3RhdGUoJ21vdW50ZWQnKTtcbiAgY29uc3QgaW5zdGFudFR5cGUgPSBzdG9yZS51c2VTdGF0ZSgnaW5zdGFudFR5cGUnKTtcbiAgY29uc3QgYWN0aXZlVHJpZ2dlckVsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZSgnYWN0aXZlVHJpZ2dlckVsZW1lbnQnKTtcbiAgY29uc3QgcGFyZW50ID0gc3RvcmUudXNlU3RhdGUoJ3BhcmVudCcpO1xuICBjb25zdCBsYXN0T3BlbkNoYW5nZVJlYXNvbiA9IHN0b3JlLnVzZVN0YXRlKCdsYXN0T3BlbkNoYW5nZVJlYXNvbicpO1xuICBjb25zdCByb290SWQgPSBzdG9yZS51c2VTdGF0ZSgncm9vdElkJyk7XG4gIGNvbnN0IGZsb2F0aW5nQ29udGV4dCA9IHN0b3JlLnVzZVN0YXRlKCdmbG9hdGluZ1Jvb3RDb250ZXh0Jyk7XG4gIGNvbnN0IGZsb2F0aW5nVHJlZVJvb3QgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdUcmVlUm9vdCcpO1xuICBjb25zdCBjbG9zZURlbGF5ID0gc3RvcmUudXNlU3RhdGUoJ2Nsb3NlRGVsYXknKTtcbiAgY29uc3QgaG92ZXJFbmFibGVkID0gc3RvcmUudXNlU3RhdGUoJ2hvdmVyRW5hYmxlZCcpO1xuICBjb25zdCBkaXNhYmxlZCA9IHN0b3JlLnVzZVN0YXRlKCdkaXNhYmxlZCcpO1xuICBjb25zdCBvcGVuTWV0aG9kID0gc3RvcmUudXNlU3RhdGUoJ29wZW5NZXRob2QnKTtcbiAgY29uc3QgYWN0aXZlVHJpZ2dlcklkID0gc3RvcmUudXNlU3RhdGUoJ2FjdGl2ZVRyaWdnZXJJZCcpO1xuICBjb25zdCBsaXN0RWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlKCdsaXN0RWxlbWVudCcpO1xuICBjb25zdCBbaWQsIHJlZ2lzdGVySWRSZWZdID0gdXNlUmVuZGVyZWRJZChjb21wb25lbnRQcm9wcywgZGVmYXVsdEZsb2F0aW5nSWQsIHNldFJlbmRlcmVkRmxvYXRpbmdJZCk7XG4gIGNvbnN0IGFyaWFMYWJlbGxlZEJ5ID0gcmVzb2x2ZVBvcHVwTGFiZWwoY29tcG9uZW50UHJvcHMsIGFjdGl2ZVRyaWdnZXJFbGVtZW50LCBhY3RpdmVUcmlnZ2VySWQpO1xuXG4gIC8vIEEgZGlhbG9nJ3MgbWVudSBjYW4gcmVuZGVyIHVuZGVyIGEgc3VibWVudSBwcm92aWRlcjsgb25seSB0aGUgYWN0dWFsIHN1Ym1lbnUgaW5oZXJpdHMgaXQuXG4gIGNvbnN0IHN1Ym1lbnVSb290Q29udGV4dCA9IHBhcmVudC50eXBlID09PSAnbWVudScgPyBpbmhlcml0ZWRTdWJtZW51Um9vdENvbnRleHQgOiB1bmRlZmluZWQ7XG4gIGNvbnN0IGlzQ29udGV4dE1lbnUgPSBwYXJlbnQudHlwZSA9PT0gJ2NvbnRleHQtbWVudSc7XG4gIGxldCBpbml0aWFsRm9jdXMgPSBpbml0aWFsRm9jdXNQcm9wID8/IHBhcmVudC50eXBlICE9PSAnbWVudSc7XG4gIGlmIChpbml0aWFsRm9jdXNQcm9wID09PSB1bmRlZmluZWQgJiYgbGlzdEVsZW1lbnQgJiYgcGFyZW50LnR5cGUgIT09ICdtZW51Jykge1xuICAgIGluaXRpYWxGb2N1cyA9ICgpID0+IHtcbiAgICAgIC8vIEEga2V5Ym9hcmQgb3Igc2NyZWVuIHJlYWRlciBvcGVuIGhpZ2hsaWdodHMgYW4gaXRlbSwgd2hpY2ggbGlzdCBuYXZpZ2F0aW9uIGZvY3VzZXMuXG4gICAgICBpZiAoc3RvcmUuc3RhdGUuYWN0aXZlSW5kZXggIT09IG51bGwpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgLy8gVGhlIGxpc3QgaG9sZHMgdGhlIGBtZW51YCByb2xlLCBzbyBhIHBvaW50ZXIgb3BlbiBsYW5kcyBmb2N1cyBvbiBpdCByYXRoZXIgdGhhbiBvbiB0aGVcbiAgICAgIC8vIHByZXNlbnRhdGlvbmFsIHBvcHVwLlxuICAgICAgcmV0dXJuIGxpc3RFbGVtZW50O1xuICAgIH07XG4gIH1cbiAgdXNlT3BlbkNoYW5nZUNvbXBsZXRlKHtcbiAgICBvcGVuLFxuICAgIHJlZjogc3RvcmUuY29udGV4dC5wb3B1cFJlZixcbiAgICBvbkNvbXBsZXRlKCkge1xuICAgICAgaWYgKG9wZW4pIHtcbiAgICAgICAgc3RvcmUuY29udGV4dC5vbk9wZW5DaGFuZ2VDb21wbGV0ZT8uKHRydWUpO1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgZnVuY3Rpb24gaGFuZGxlQ2xvc2UoZXZlbnQpIHtcbiAgICAgIHN0b3JlLnNldE9wZW4oZmFsc2UsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhldmVudC5yZWFzb24sIGV2ZW50LmRvbUV2ZW50KSk7XG4gICAgfVxuICAgIGZsb2F0aW5nVHJlZVJvb3QuZXZlbnRzLm9uKCdjbG9zZScsIGhhbmRsZUNsb3NlKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZmxvYXRpbmdUcmVlUm9vdC5ldmVudHMub2ZmKCdjbG9zZScsIGhhbmRsZUNsb3NlKTtcbiAgICB9O1xuICB9LCBbZmxvYXRpbmdUcmVlUm9vdC5ldmVudHMsIHN0b3JlXSk7XG4gIHVzZUhvdmVyRmxvYXRpbmdJbnRlcmFjdGlvbihmbG9hdGluZ0NvbnRleHQsIHtcbiAgICBlbmFibGVkOiBob3ZlckVuYWJsZWQgJiYgIWRpc2FibGVkICYmICFpc0NvbnRleHRNZW51ICYmIHBhcmVudC50eXBlICE9PSAnbWVudWJhcicsXG4gICAgY2xvc2VEZWxheVxuICB9KTtcbiAgY29uc3Qgc2V0UG9wdXBFbGVtZW50ID0gc3RvcmUudXNlU3RhdGVTZXR0ZXIoJ3BvcHVwRWxlbWVudCcpO1xuXG4gIC8vIE9ubHkgYSBtZW51IHVuZGVyIGEgZmlsdGVyIHJvb3QgYnVuZGxlcyB0aGUgaGFuZG9mZiB0byBhIGZpbHRlcmFibGUgcGFyZW50LiBXaGV0aGVyIG9uZSBpc1xuICAvLyBhYm92ZSBpcyBmaXhlZCBmb3IgYSBtb3VudGVkIHBvcHVwLCBzbyB0aGUgaG9vayBkb2Vzbid0IGNoYW5nZSBiZXR3ZWVuIHJlbmRlcnMuXG4gIGNvbnN0IHVzZVBhcmVudEhhbmRvZmYgPSBSZWFjdC51c2VDb250ZXh0KE1lbnVGaWx0ZXJJbXBsQ29udGV4dCk/LnVzZVBhcmVudEhhbmRvZmYgPz8gdXNlTm9QYXJlbnRIYW5kb2ZmO1xuICBjb25zdCB7XG4gICAgcGFyZW50VmlydHVhbEZvY3VzUmVmLFxuICAgIGhhbmRsZUZvY3VzXG4gIH0gPSB1c2VQYXJlbnRIYW5kb2ZmKHN0b3JlLCBwYXJlbnQsIG9wZW4sIHZpcnR1YWxGb2N1cyk7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIHRyYW5zaXRpb25TdGF0dXMsXG4gICAgc2lkZSxcbiAgICBhbGlnbixcbiAgICBvcGVuLFxuICAgIG5lc3RlZDogcGFyZW50LnR5cGUgPT09ICdtZW51JyxcbiAgICBpbnN0YW50OiBpbnN0YW50VHlwZVxuICB9O1xuICBjb25zdCBlbGVtZW50ID0gdXNlUmVuZGVyRWxlbWVudCgnZGl2JywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICByZWY6IFtmb3J3YXJkZWRSZWYsIHN0b3JlLmNvbnRleHQucG9wdXBSZWYsIHNldFBvcHVwRWxlbWVudCwgcmVnaXN0ZXJJZFJlZl0sXG4gICAgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZzogcG9wdXBUcmFuc2l0aW9uU3RhdGVNYXBwaW5nLFxuICAgIHByb3BzOiBbcG9wdXBQcm9wcywge1xuICAgICAgaWQsXG4gICAgICAvLyBBIHJlbmRlcmVkIGBNZW51Lkxpc3RgIGNhcnJpZXMgdGhlIGBtZW51YCBzZW1hbnRpY3MgaW5zdGVhZC5cbiAgICAgIC4uLihsaXN0RWxlbWVudCA/IHtcbiAgICAgICAgcm9sZTogJ3ByZXNlbnRhdGlvbidcbiAgICAgIH0gOiB7XG4gICAgICAgIHJvbGU6ICdtZW51JyxcbiAgICAgICAgLy8gYG1lbnVgIGlzIGltcGxpY2l0bHkgdmVydGljYWwsIHNvIG9ubHkgdGhlIG5vbi1kZWZhdWx0IHZhbHVlIG5lZWRzIHRvIGJlXG4gICAgICAgIC8vIHJlbmRlcmVkLlxuICAgICAgICAnYXJpYS1vcmllbnRhdGlvbic6IG9yaWVudGF0aW9uID09PSAnaG9yaXpvbnRhbCcgPyAnaG9yaXpvbnRhbCcgOiB1bmRlZmluZWQsXG4gICAgICAgICdhcmlhLWxhYmVsbGVkYnknOiBhcmlhTGFiZWxsZWRCeVxuICAgICAgfSksXG4gICAgICBvbktleURvd24oZXZlbnQpIHtcbiAgICAgICAgc3VibWVudVJvb3RDb250ZXh0Py5vblBvcHVwS2V5RG93bj8uKGV2ZW50KTtcbiAgICAgICAgaWYgKGluc2lkZVRvb2xiYXIgJiYgQ09NUE9TSVRFX0tFWVMuaGFzKGV2ZW50LmtleSkpIHtcbiAgICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIG9uRm9jdXM6IGhhbmRsZUZvY3VzXG4gICAgfSwgZ2V0RGlzYWJsZWRNb3VudFRyYW5zaXRpb25TdHlsZXModHJhbnNpdGlvblN0YXR1cyksIGVsZW1lbnRQcm9wcywge1xuICAgICAgJ2RhdGEtcm9vdG93bmVyaWQnOiByb290SWRcbiAgICB9XVxuICB9KTtcbiAgbGV0IHJldHVybkZvY3VzID0gcGFyZW50LnR5cGUgPT09IHVuZGVmaW5lZCB8fCBpc0NvbnRleHRNZW51O1xuICBpZiAoYWN0aXZlVHJpZ2dlckVsZW1lbnQgfHwgcGFyZW50LnR5cGUgPT09ICdtZW51YmFyJyAmJiBsYXN0T3BlbkNoYW5nZVJlYXNvbiAhPT0gUkVBU09OUy5vdXRzaWRlUHJlc3MpIHtcbiAgICByZXR1cm5Gb2N1cyA9IHRydWU7XG4gIH1cblxuICAvLyBJbnRlcm5hbCBkZWZhdWx0cyByYXRoZXIgdGhhbiBjb25zdW1lciB0YXJnZXRzLCBzbyBmb2N1cyB0aGF0IGFscmVhZHkgbW92ZWQgaXMgcmVzcGVjdGVkLlxuICBjb25zdCBkeW5hbWljUmV0dXJuRm9jdXMgPSBzdWJtZW51Um9vdENvbnRleHQ/LmdldFJldHVybkVsZW1lbnQgPz8gcGFyZW50VmlydHVhbEZvY3VzUmVmO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goRmxvYXRpbmdGb2N1c01hbmFnZXIsIHtcbiAgICBjb250ZXh0OiBmbG9hdGluZ0NvbnRleHQsXG4gICAgb3BlbkludGVyYWN0aW9uVHlwZTogb3Blbk1ldGhvZCxcbiAgICBtb2RhbDogaXNDb250ZXh0TWVudSxcbiAgICBkaXNhYmxlZDogIW1vdW50ZWQsXG4gICAgcmV0dXJuRm9jdXM6IGZpbmFsRm9jdXMgPz8gZHluYW1pY1JldHVybkZvY3VzID8/IHJldHVybkZvY3VzLFxuICAgIGV4cGxpY2l0UmV0dXJuRm9jdXM6IGZpbmFsRm9jdXMgPT09IHVuZGVmaW5lZCAmJiBkeW5hbWljUmV0dXJuRm9jdXMgPyBmYWxzZSA6IHVuZGVmaW5lZCxcbiAgICBpbml0aWFsRm9jdXM6IGluaXRpYWxGb2N1cyxcbiAgICByZXN0b3JlRm9jdXM6IHRydWUsXG4gICAgZ2V0SW5zaWRlRWxlbWVudHM6IHBhcmVudC50eXBlID09PSB1bmRlZmluZWQgPyAoKSA9PiBbc3RvcmUuY29udGV4dC5iZWZvcmVUcmlnZ2VyRm9jdXNHdWFyZFJlZi5jdXJyZW50XSA6IHVuZGVmaW5lZCxcbiAgICBleHRlcm5hbFRyZWU6IHBhcmVudC50eXBlICE9PSAnbWVudWJhcicgPyBmbG9hdGluZ1RyZWVSb290IDogdW5kZWZpbmVkLFxuICAgIHByZXZpb3VzRm9jdXNhYmxlRWxlbWVudDogYWN0aXZlVHJpZ2dlckVsZW1lbnQsXG4gICAgbmV4dEZvY3VzYWJsZUVsZW1lbnQ6IHBhcmVudC50eXBlID09PSB1bmRlZmluZWQgPyBzdG9yZS5jb250ZXh0LnRyaWdnZXJGb2N1c1RhcmdldFJlZiA6IHVuZGVmaW5lZCxcbiAgICBiZWZvcmVDb250ZW50Rm9jdXNHdWFyZFJlZjogc3RvcmUuY29udGV4dC5iZWZvcmVDb250ZW50Rm9jdXNHdWFyZFJlZixcbiAgICBjaGlsZHJlbjogZWxlbWVudFxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgTWVudVBvcHVwUGxhaW4uZGlzcGxheU5hbWUgPSBcIk1lbnVQb3B1cFBsYWluXCI7XG5jb25zdCBOT19QQVJFTlRfSEFORE9GRiA9IHtcbiAgcGFyZW50VmlydHVhbEZvY3VzUmVmOiB1bmRlZmluZWQsXG4gIGhhbmRsZUZvY3VzOiB1bmRlZmluZWRcbn07XG5mdW5jdGlvbiB1c2VOb1BhcmVudEhhbmRvZmYoKSB7XG4gIHJldHVybiBOT19QQVJFTlRfSEFORE9GRjtcbn1cblxuLyoqXG4gKiBBIGNvbnRhaW5lciBmb3IgdGhlIG1lbnUgaXRlbXMuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIE1lbnVdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9tZW51KVxuICovXG5leHBvcnQgY29uc3QgTWVudVBvcHVwID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gTWVudVBvcHVwKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3QgUG9wdXAgPSB1c2VNZW51RmlsdGVySW1wbCgpPy5Qb3B1cCA/PyBNZW51UG9wdXBQbGFpbjtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KFBvcHVwLCB7XG4gICAgLi4ucHJvcHMsXG4gICAgcmVmOiBmb3J3YXJkZWRSZWZcbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnVQb3B1cC5kaXNwbGF5TmFtZSA9IFwiTWVudVBvcHVwXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgX2Zvcm1hdEVycm9yTWVzc2FnZSBmcm9tIFwiQGJhc2UtdWkvdXRpbHMvZm9ybWF0RXJyb3JNZXNzYWdlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgTWVudVBvcnRhbENvbnRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlQ29udGV4dCh1bmRlZmluZWQpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgTWVudVBvcnRhbENvbnRleHQuZGlzcGxheU5hbWUgPSBcIk1lbnVQb3J0YWxDb250ZXh0XCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlTWVudVBvcnRhbENvbnRleHQoKSB7XG4gIGNvbnN0IHZhbHVlID0gUmVhY3QudXNlQ29udGV4dChNZW51UG9ydGFsQ29udGV4dCk7XG4gIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/ICdCYXNlIFVJOiA8TWVudS5Qb3J0YWw+IGlzIG1pc3NpbmcuJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoMzIpKTtcbiAgfVxuICByZXR1cm4gdmFsdWU7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBGbG9hdGluZ1BvcnRhbCB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9pbmRleC5tanNcIjtcbmltcG9ydCB7IHVzZU1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L01lbnVSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IE1lbnVQb3J0YWxDb250ZXh0IH0gZnJvbSBcIi4vTWVudVBvcnRhbENvbnRleHQubWpzXCI7XG5cbi8qKlxuICogQSBwb3J0YWwgZWxlbWVudCB0aGF0IG1vdmVzIHRoZSBwb3B1cCB0byBhIGRpZmZlcmVudCBwYXJ0IG9mIHRoZSBET00uXG4gKiBCeSBkZWZhdWx0LCB0aGUgcG9ydGFsIGVsZW1lbnQgaXMgYXBwZW5kZWQgdG8gYDxib2R5PmAuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIE1lbnVdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9tZW51KVxuICovXG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZXhwb3J0IGNvbnN0IE1lbnVQb3J0YWwgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBNZW51UG9ydGFsKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIGtlZXBNb3VudGVkID0gZmFsc2UsXG4gICAgLi4ucG9ydGFsUHJvcHNcbiAgfSA9IHByb3BzO1xuICBjb25zdCB7XG4gICAgc3RvcmUsXG4gICAgcGFyZW50XG4gIH0gPSB1c2VNZW51Um9vdENvbnRleHQoKTtcbiAgY29uc3QgbW91bnRlZCA9IHN0b3JlLnVzZVN0YXRlKCdtb3VudGVkJyk7XG4gIGNvbnN0IHNob3VsZFJlbmRlciA9IG1vdW50ZWQgfHwga2VlcE1vdW50ZWQ7XG4gIGlmICghc2hvdWxkUmVuZGVyKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICAvLyBUaGUgaGlkZGVuIGBhcmlhLW93bnNgIG93bmVyIHJlbmRlcnMgaGVyZSwgaW4gdGhlIFJlYWN0IHRyZWUsIHNvIHRoZSByb2xlIG11c3QgYmUgZGVjaWRlZCBieVxuICAvLyB3aGVyZSB0aGlzIHBvcnRhbCBzaXRzLCBub3QgYnkgdGhlIGFjdGl2ZSB0cmlnZ2VyLiBgcGFyZW50YCBjb21lcyBmcm9tIGNvbnRleHQgKHRoZSBgTWVudS5Sb290YFxuICAvLyBwb3NpdGlvbiksIHVubGlrZSB0aGUgc3RvcmUncyBgcGFyZW50YCwgd2hpY2ggYSBkZXRhY2hlZCB0cmlnZ2VyIG92ZXJ3cml0ZXMgd2l0aCBpdHMgb3duLlxuICBjb25zdCBwb3J0YWxPd25lclJvbGUgPSBwYXJlbnQudHlwZSA9PT0gJ21lbnUnIHx8IHBhcmVudC50eXBlID09PSAnbWVudWJhcicgPyAnZ3JvdXAnIDogdW5kZWZpbmVkO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goTWVudVBvcnRhbENvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZToga2VlcE1vdW50ZWQsXG4gICAgY2hpbGRyZW46IC8qI19fUFVSRV9fKi9fanN4KEZsb2F0aW5nUG9ydGFsLCB7XG4gICAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICAgIC4uLnBvcnRhbFByb3BzLFxuICAgICAgcG9ydGFsT3duZXJSb2xlOiBwb3J0YWxPd25lclJvbGVcbiAgICB9KVxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgTWVudVBvcnRhbC5kaXNwbGF5TmFtZSA9IFwiTWVudVBvcnRhbFwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZUFuaW1hdGlvbnNGaW5pc2hlZCB9IGZyb20gXCIuL3VzZUFuaW1hdGlvbnNGaW5pc2hlZC5tanNcIjtcblxuLyoqXG4gKiBQb3BvdmVyIGFuZCBNZW51IGRlY2xhcmUgZGlmZmVyZW50IGBpbnN0YW50VHlwZWAgdW5pb25zLCBzbyBvbmx5IHRoZSBtZW1iZXJzXG4gKiB0aGlzIGhvb2sgdG91Y2hlcyBhcmUgdHlwZWQuXG4gKi9cblxuLyoqXG4gKiBMZXRzIHRoZSBwb3NpdGlvbmVyIGFuaW1hdGUgd2hpbGUgYSBwb3B1cCBtb3ZlcyBiZXR3ZWVuIGRldGFjaGVkIHRyaWdnZXJzLlxuICpcbiAqIFRoZSBwb3NpdGlvbmVyIGlzIG5vcm1hbGx5IG1hcmtlZCBpbnN0YW50LCBzbyBhIGhhbmQtb2ZmIGZyb20gb25lIHRyaWdnZXIgdG9cbiAqIGFub3RoZXIgd291bGQgdGVsZXBvcnQuIENsZWFyaW5nIGBpbnN0YW50VHlwZWAgZm9yIHRoZSBkdXJhdGlvbiBvZiB0aGUgbW92ZVxuICogbGV0cyBpdCB0cmFuc2l0aW9uLCBhbmQgYHRyaWdnZXItY2hhbmdlYCBpcyByZXN0b3JlZCBvbmNlIHRoZSBtb3ZlIGZpbmlzaGVzLlxuICpcbiAqIFRoZSByZXN0b3JhdGlvbiBpcyBkZWZlcnJlZCB1bnRpbCB0aGUgbW92ZSdzIGFuaW1hdGlvbnMgZmluaXNoLCBzbyBpdCBjYW5cbiAqIG91dGxpdmUgdGhlIG1vdmUgdGhhdCBzY2hlZHVsZWQgaXQuIFRoZSB0cmlnZ2VyIGVsZW1lbnQgaXMgcmV0YWluZWQgdGhyb3VnaFxuICogdGhlIGV4aXQgdHJhbnNpdGlvbiwgc28gYSBjbG9zZSBhbG9uZSBkb2VzIG5vdCBjaGFuZ2UgYGRvbVJlZmVyZW5jZWAgYW5kXG4gKiBub3RoaW5nIHdvdWxkIG90aGVyd2lzZSByZS1ydW4gdGhpcyBlZmZlY3QgdG8gYWJvcnQgaXQg4oCUIGEgcG9wdXAgdGhhdCBjbG9zZXNcbiAqIGFuZCByZW9wZW5zIG9uIHRoZSBzYW1lIHRyaWdnZXIgbWlkLWV4aXQgd291bGQgaW5oZXJpdCB0aGUgc3RhbGUgY2FsbGJhY2sgYW5kXG4gKiBsb3NlIGl0cyBvd24gdHJhbnNpdGlvbi4gQ2xvc2luZyB0aGVyZWZvcmUgY2FuY2VscyB0aGUgcGVuZGluZyByZXN0b3JhdGlvblxuICogZXhwbGljaXRseS5cbiAqXG4gKiBBcHBseWluZyBgdHJpZ2dlci1jaGFuZ2VgIHRvIGEgY2xvc2VkIHBvcHVwIGlzIHByZXZlbnRlZCBzZXBhcmF0ZWx5LCBieSB0aGVcbiAqIHN0b3JlcycgYGluc3RhbnRUeXBlYCBzZWxlY3Rvciwgc2luY2UgYSBjb250cm9sbGVkIGBvcGVuPXtmYWxzZX1gIGNvbW1pdFxuICogcmVhY2hlcyB0aGUgcG9wdXAgd2l0aG91dCBwYXNzaW5nIHRocm91Z2ggYHNldE9wZW5gLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlVHJpZ2dlclN3aXRjaFRyYW5zaXRpb24ocGFyYW1ldGVycykge1xuICBjb25zdCB7XG4gICAgc3RvcmUsXG4gICAgZG9tUmVmZXJlbmNlLFxuICAgIHBvc2l0aW9uZXJFbGVtZW50LFxuICAgIG9wZW5cbiAgfSA9IHBhcmFtZXRlcnM7XG4gIGNvbnN0IHByZXZpb3VzVHJpZ2dlclJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgcGVuZGluZ1N3aXRjaFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgcnVuT25jZUFuaW1hdGlvbnNGaW5pc2ggPSB1c2VBbmltYXRpb25zRmluaXNoZWQocG9zaXRpb25lckVsZW1lbnQpO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChvcGVuKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHBlbmRpbmdTd2l0Y2hSZWYuY3VycmVudD8uYWJvcnQoKTtcbiAgICBwZW5kaW5nU3dpdGNoUmVmLmN1cnJlbnQgPSBudWxsO1xuXG4gICAgLy8gYHRyaWdnZXItY2hhbmdlYCBiZWxvbmdzIHRvIHRoZSBvcGVuIGN5Y2xlIHRoYXQgc2NoZWR1bGVkIGl0LiBUaGUgc2VsZWN0b3JcbiAgICAvLyBzdG9wcyBhIGNsb3NlZCBwb3B1cCBmcm9tIHJlbmRlcmluZyBpdCwgYnV0IHRoZSB2YWx1ZSBoYXMgdG8gYmUgZHJvcHBlZFxuICAgIC8vIHRvbzogYSBjb250cm9sbGVkIHJlb3BlbiBjaGFuZ2VzIG9ubHkgYG9wZW5Qcm9wYCwgc28gbmVpdGhlciB0aGlzIGVmZmVjdFxuICAgIC8vIG5vciBgc2V0T3BlbmAgd291bGQgcnVuIGFnYWluIHRvIHJlcGxhY2UgaXQsIGFuZCB0aGUgc2VsZWN0b3Igd291bGQgc3RhcnRcbiAgICAvLyBleHBvc2luZyB0aGUgb2xkIHZhbHVlIGFnYWluc3QgdGhlIG5ldyBjeWNsZS5cbiAgICBpZiAoc3RvcmUuc3RhdGUuaW5zdGFudFR5cGUgPT09ICd0cmlnZ2VyLWNoYW5nZScpIHtcbiAgICAgIHN0b3JlLnNldCgnaW5zdGFudFR5cGUnLCB1bmRlZmluZWQpO1xuICAgIH1cbiAgfSwgW29wZW4sIHN0b3JlXSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgY3VycmVudFRyaWdnZXIgPSBkb21SZWZlcmVuY2U7XG4gICAgY29uc3QgcHJldmlvdXNUcmlnZ2VyID0gcHJldmlvdXNUcmlnZ2VyUmVmLmN1cnJlbnQ7XG4gICAgaWYgKGN1cnJlbnRUcmlnZ2VyKSB7XG4gICAgICBwcmV2aW91c1RyaWdnZXJSZWYuY3VycmVudCA9IGN1cnJlbnRUcmlnZ2VyO1xuICAgIH1cbiAgICBpZiAoIXByZXZpb3VzVHJpZ2dlciB8fCAhY3VycmVudFRyaWdnZXIgfHwgY3VycmVudFRyaWdnZXIgPT09IHByZXZpb3VzVHJpZ2dlcikge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG5cbiAgICAvLyBUaGUgdHJpZ2dlciBlbGVtZW50IGNhbiBhbHNvIGNoYW5nZSB3aGlsZSB0aGUgcG9wdXAgaXMgY2xvc2luZywgd2hlbiBhXG4gICAgLy8gdHJpZ2dlciBpcyByZXBsYWNlZCBieSBhIG5ldyBlbGVtZW50LiBUaGVyZSBpcyBubyBtb3ZlIHRvIGFuaW1hdGUsIGFuZFxuICAgIC8vIHRoZSBjYW5jZWxsYXRpb24gZWZmZWN0IGFib3ZlIGhhcyBhbHJlYWR5IHJ1biBmb3IgdGhpcyBjb21taXQsIHNvIGFcbiAgICAvLyByZXN0b3JhdGlvbiBzY2hlZHVsZWQgaGVyZSB3b3VsZCBzdXJ2aXZlIGludG8gd2hhdGV2ZXIgb3BlbnMgbmV4dC5cbiAgICBpZiAoIXN0b3JlLnNlbGVjdCgnb3BlbicpKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBzdG9yZS5zZXQoJ2luc3RhbnRUeXBlJywgdW5kZWZpbmVkKTtcbiAgICBjb25zdCBhYm9ydENvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgcGVuZGluZ1N3aXRjaFJlZi5jdXJyZW50ID0gYWJvcnRDb250cm9sbGVyO1xuICAgIHJ1bk9uY2VBbmltYXRpb25zRmluaXNoKCgpID0+IHtcbiAgICAgIC8vIFRoZSBhYm9ydCBhYm92ZSBjb3ZlcnMgYSBjb21taXR0ZWQgY2xvc2UsIGJ1dCB0aGUgYW5pbWF0aW9ucyBjYW4gZmluaXNoXG4gICAgICAvLyBpbiB0aGUgc2FtZSBmcmFtZSB0aGUgY2xvc2UgY29tbWl0cy4gV3JpdGluZyBgdHJpZ2dlci1jaGFuZ2VgIHRoZW4gd291bGRcbiAgICAgIC8vIGxlYXZlIHN0YWxlIHN0YXRlIGJlaGluZCBmb3IgdGhlIG5leHQgb3BlbiB0byBpbmhlcml0LlxuICAgICAgaWYgKHN0b3JlLnNlbGVjdCgnb3BlbicpKSB7XG4gICAgICAgIHN0b3JlLnNldCgnaW5zdGFudFR5cGUnLCAndHJpZ2dlci1jaGFuZ2UnKTtcbiAgICAgIH1cbiAgICB9LCBhYm9ydENvbnRyb2xsZXIuc2lnbmFsKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgYWJvcnRDb250cm9sbGVyLmFib3J0KCk7XG4gICAgfTtcbiAgfSwgW2RvbVJlZmVyZW5jZSwgcnVuT25jZUFuaW1hdGlvbnNGaW5pc2gsIHN0b3JlXSk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBpbmVydFZhbHVlIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvaW5lcnRWYWx1ZSc7XG5pbXBvcnQgeyB1c2VUaW1lb3V0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlVGltZW91dCc7XG5pbXBvcnQgeyBGbG9hdGluZ05vZGUgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBNZW51UG9zaXRpb25lckNvbnRleHQgfSBmcm9tIFwiLi9NZW51UG9zaXRpb25lckNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51Um9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9NZW51Um9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VBbmNob3JQb3NpdGlvbmluZyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlQW5jaG9yUG9zaXRpb25pbmcubWpzXCI7XG5pbXBvcnQgeyBDb21wb3NpdGVMaXN0IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jb21wb3NpdGUvbGlzdC9Db21wb3NpdGVMaXN0Lm1qc1wiO1xuaW1wb3J0IHsgSW50ZXJuYWxCYWNrZHJvcCB9IGZyb20gXCIuLi8uLi91dGlscy9JbnRlcm5hbEJhY2tkcm9wLm1qc1wiO1xuaW1wb3J0IHsgdXNlTWVudVBvcnRhbENvbnRleHQgfSBmcm9tIFwiLi4vcG9ydGFsL01lbnVQb3J0YWxDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgRFJPUERPV05fQ09MTElTSU9OX0FWT0lEQU5DRSwgUE9QVVBfQ09MTElTSU9OX0FWT0lEQU5DRSB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY29uc3RhbnRzLm1qc1wiO1xuaW1wb3J0IHsgdXNlQ29udGV4dE1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi8uLi9jb250ZXh0LW1lbnUvcm9vdC9Db250ZXh0TWVudVJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsgdXNlVHJpZ2dlclN3aXRjaFRyYW5zaXRpb24gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVRyaWdnZXJTd2l0Y2hUcmFuc2l0aW9uLm1qc1wiO1xuaW1wb3J0IHsgdXNlUG9zaXRpb25lciB9IGZyb20gXCIuLi8uLi91dGlscy91c2VQb3NpdGlvbmVyLm1qc1wiO1xuaW1wb3J0IHsgdXNlQW5jaG9yZWRQb3B1cFNjcm9sbExvY2sgfSBmcm9tIFwiLi4vLi4vdXRpbHMvdXNlQW5jaG9yZWRQb3B1cFNjcm9sbExvY2subWpzXCI7XG5cbi8qKlxuICogUG9zaXRpb25zIHRoZSBtZW51IHBvcHVwIGFnYWluc3QgdGhlIHRyaWdnZXIuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIE1lbnVdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9tZW51KVxuICovXG5pbXBvcnQgeyBqc3ggYXMgX2pzeCwganN4cyBhcyBfanN4cyB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZXhwb3J0IGNvbnN0IE1lbnVQb3NpdGlvbmVyID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gTWVudVBvc2l0aW9uZXIoY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgYW5jaG9yOiBhbmNob3JQcm9wLFxuICAgIHBvc2l0aW9uTWV0aG9kOiBwb3NpdGlvbk1ldGhvZFByb3AgPSAnYWJzb2x1dGUnLFxuICAgIGNsYXNzTmFtZSxcbiAgICByZW5kZXIsXG4gICAgc2lkZSxcbiAgICBhbGlnbjogYWxpZ25Qcm9wLFxuICAgIHNpZGVPZmZzZXQ6IHNpZGVPZmZzZXRQcm9wID0gMCxcbiAgICBhbGlnbk9mZnNldDogYWxpZ25PZmZzZXRQcm9wID0gMCxcbiAgICBjb2xsaXNpb25Cb3VuZGFyeSA9ICdjbGlwcGluZy1hbmNlc3RvcnMnLFxuICAgIGNvbGxpc2lvblBhZGRpbmcgPSA1LFxuICAgIGFycm93UGFkZGluZyA9IDUsXG4gICAgc3RpY2t5ID0gZmFsc2UsXG4gICAgZGlzYWJsZUFuY2hvclRyYWNraW5nID0gZmFsc2UsXG4gICAgY29sbGlzaW9uQXZvaWRhbmNlOiBjb2xsaXNpb25Bdm9pZGFuY2VQcm9wID0gRFJPUERPV05fQ09MTElTSU9OX0FWT0lEQU5DRSxcbiAgICBzdHlsZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCB7XG4gICAgc3RvcmUsXG4gICAgdmlydHVhbEZvY3VzLFxuICAgIHN5bmNIaWdobGlnaHRlZEl0ZW1cbiAgfSA9IHVzZU1lbnVSb290Q29udGV4dCgpO1xuICBjb25zdCBrZWVwTW91bnRlZCA9IHVzZU1lbnVQb3J0YWxDb250ZXh0KCk7XG4gIGNvbnN0IGNvbnRleHRNZW51Q29udGV4dCA9IHVzZUNvbnRleHRNZW51Um9vdENvbnRleHQodHJ1ZSk7XG4gIGNvbnN0IHBhcmVudCA9IHN0b3JlLnVzZVN0YXRlKCdwYXJlbnQnKTtcbiAgY29uc3QgZmxvYXRpbmdSb290Q29udGV4dCA9IHN0b3JlLnVzZVN0YXRlKCdmbG9hdGluZ1Jvb3RDb250ZXh0Jyk7XG4gIGNvbnN0IGZsb2F0aW5nVHJlZVJvb3QgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdUcmVlUm9vdCcpO1xuICBjb25zdCBtb3VudGVkID0gc3RvcmUudXNlU3RhdGUoJ21vdW50ZWQnKTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IG1vZGFsID0gc3RvcmUudXNlU3RhdGUoJ21vZGFsJyk7XG4gIGNvbnN0IG9wZW5NZXRob2QgPSBzdG9yZS51c2VTdGF0ZSgnb3Blbk1ldGhvZCcpO1xuICBjb25zdCB0cmlnZ2VyRWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlKCdhY3RpdmVUcmlnZ2VyRWxlbWVudCcpO1xuICBjb25zdCB0cmFuc2l0aW9uU3RhdHVzID0gc3RvcmUudXNlU3RhdGUoJ3RyYW5zaXRpb25TdGF0dXMnKTtcbiAgY29uc3QgcG9zaXRpb25lckVsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZSgncG9zaXRpb25lckVsZW1lbnQnKTtcbiAgY29uc3QgaW5zdGFudFR5cGUgPSBzdG9yZS51c2VTdGF0ZSgnaW5zdGFudFR5cGUnKTtcbiAgY29uc3QgYWRhcHRpdmVPcmlnaW4gPSBzdG9yZS51c2VTdGF0ZSgnYWRhcHRpdmVPcmlnaW4nKTtcbiAgY29uc3QgbGFzdE9wZW5DaGFuZ2VSZWFzb24gPSBzdG9yZS51c2VTdGF0ZSgnbGFzdE9wZW5DaGFuZ2VSZWFzb24nKTtcbiAgY29uc3QgZmxvYXRpbmdOb2RlSWQgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdOb2RlSWQnKTtcbiAgY29uc3QgZmxvYXRpbmdQYXJlbnROb2RlSWQgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdQYXJlbnROb2RlSWQnKTtcbiAgY29uc3QgZG9tUmVmZXJlbmNlID0gZmxvYXRpbmdSb290Q29udGV4dC51c2VTdGF0ZSgnZG9tUmVmZXJlbmNlRWxlbWVudCcpO1xuICBsZXQgYW5jaG9yID0gYW5jaG9yUHJvcDtcbiAgbGV0IHNpZGVPZmZzZXQgPSBzaWRlT2Zmc2V0UHJvcDtcbiAgbGV0IGFsaWduT2Zmc2V0ID0gYWxpZ25PZmZzZXRQcm9wO1xuICBsZXQgYWxpZ24gPSBhbGlnblByb3A7XG4gIGxldCBjb2xsaXNpb25Bdm9pZGFuY2UgPSBjb2xsaXNpb25Bdm9pZGFuY2VQcm9wO1xuICBpZiAocGFyZW50LnR5cGUgPT09ICdjb250ZXh0LW1lbnUnKSB7XG4gICAgYW5jaG9yID0gYW5jaG9yUHJvcCA/PyBwYXJlbnQuY29udGV4dD8uYW5jaG9yO1xuICAgIGFsaWduID0gYWxpZ24gPz8gJ3N0YXJ0JztcbiAgICBpZiAoIXNpZGUgJiYgYWxpZ24gIT09ICdjZW50ZXInKSB7XG4gICAgICBhbGlnbk9mZnNldCA9IGNvbXBvbmVudFByb3BzLmFsaWduT2Zmc2V0ID8/IDI7XG4gICAgICBzaWRlT2Zmc2V0ID0gY29tcG9uZW50UHJvcHMuc2lkZU9mZnNldCA/PyAtNTtcbiAgICB9XG4gIH1cbiAgbGV0IGNvbXB1dGVkU2lkZSA9IHNpZGU7XG4gIGxldCBjb21wdXRlZEFsaWduID0gYWxpZ247XG4gIGlmIChwYXJlbnQudHlwZSA9PT0gJ21lbnUnKSB7XG4gICAgY29tcHV0ZWRTaWRlID0gY29tcHV0ZWRTaWRlID8/ICdpbmxpbmUtZW5kJztcbiAgICBjb21wdXRlZEFsaWduID0gY29tcHV0ZWRBbGlnbiA/PyAnc3RhcnQnO1xuICAgIGNvbGxpc2lvbkF2b2lkYW5jZSA9IGNvbXBvbmVudFByb3BzLmNvbGxpc2lvbkF2b2lkYW5jZSA/PyBQT1BVUF9DT0xMSVNJT05fQVZPSURBTkNFO1xuICB9IGVsc2UgaWYgKHBhcmVudC50eXBlID09PSAnbWVudWJhcicpIHtcbiAgICBjb21wdXRlZFNpZGUgPSBjb21wdXRlZFNpZGUgPz8gKHBhcmVudC5jb250ZXh0Lm9yaWVudGF0aW9uID09PSAndmVydGljYWwnID8gJ2lubGluZS1lbmQnIDogJ2JvdHRvbScpO1xuICAgIGNvbXB1dGVkQWxpZ24gPSBjb21wdXRlZEFsaWduID8/ICdzdGFydCc7XG4gIH1cbiAgY29uc3QgY29udGV4dE1lbnUgPSBwYXJlbnQudHlwZSA9PT0gJ2NvbnRleHQtbWVudSc7XG4gIGNvbnN0IHBvc2l0aW9uZXIgPSB1c2VBbmNob3JQb3NpdGlvbmluZyh7XG4gICAgYW5jaG9yLFxuICAgIGZsb2F0aW5nUm9vdENvbnRleHQsXG4gICAgcG9zaXRpb25NZXRob2Q6IGNvbnRleHRNZW51Q29udGV4dCA/ICdmaXhlZCcgOiBwb3NpdGlvbk1ldGhvZFByb3AsXG4gICAgbW91bnRlZCxcbiAgICBzaWRlOiBjb21wdXRlZFNpZGUsXG4gICAgc2lkZU9mZnNldCxcbiAgICBhbGlnbjogY29tcHV0ZWRBbGlnbixcbiAgICBhbGlnbk9mZnNldCxcbiAgICBhcnJvd1BhZGRpbmc6IGNvbnRleHRNZW51ID8gMCA6IGFycm93UGFkZGluZyxcbiAgICBjb2xsaXNpb25Cb3VuZGFyeSxcbiAgICBjb2xsaXNpb25QYWRkaW5nLFxuICAgIHN0aWNreSxcbiAgICBub2RlSWQ6IGZsb2F0aW5nTm9kZUlkLFxuICAgIGtlZXBNb3VudGVkLFxuICAgIGRpc2FibGVBbmNob3JUcmFja2luZyxcbiAgICBjb2xsaXNpb25Bdm9pZGFuY2UsXG4gICAgc2hpZnQ6IGNvbnRleHRNZW51ID8ge1xuICAgICAgY3Jvc3NBeGlzOiAhKCdzaWRlJyBpbiBjb2xsaXNpb25Bdm9pZGFuY2UgJiYgY29sbGlzaW9uQXZvaWRhbmNlLnNpZGUgPT09ICdmbGlwJyksXG4gICAgICByb290Qm91bmRhcnk6ICdsYXlvdXRWaWV3cG9ydCdcbiAgICB9IDogdW5kZWZpbmVkLFxuICAgIGV4dGVybmFsVHJlZTogZmxvYXRpbmdUcmVlUm9vdCxcbiAgICBhZGFwdGl2ZU9yaWdpbixcbiAgICBsYXp5RmxpcDogdmlydHVhbEZvY3VzID8gJ3BsYWNlbWVudCcgOiBmYWxzZVxuICB9KTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBmdW5jdGlvbiBvbk1lbnVPcGVuQ2hhbmdlKGRldGFpbHMpIHtcbiAgICAgIGlmIChkZXRhaWxzLm9wZW4pIHtcbiAgICAgICAgaWYgKGRldGFpbHMucGFyZW50Tm9kZUlkID09PSBmbG9hdGluZ05vZGVJZCkge1xuICAgICAgICAgIHN0b3JlLnNldCgnaG92ZXJFbmFibGVkJywgZmFsc2UpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChkZXRhaWxzLm5vZGVJZCAhPT0gZmxvYXRpbmdOb2RlSWQgJiYgZGV0YWlscy5wYXJlbnROb2RlSWQgPT09IHN0b3JlLnNlbGVjdCgnZmxvYXRpbmdQYXJlbnROb2RlSWQnKSkge1xuICAgICAgICAgIHN0b3JlLnNldE9wZW4oZmFsc2UsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLnNpYmxpbmdPcGVuKSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgZmxvYXRpbmdUcmVlUm9vdC5ldmVudHMub24oJ21lbnVvcGVuY2hhbmdlJywgb25NZW51T3BlbkNoYW5nZSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGZsb2F0aW5nVHJlZVJvb3QuZXZlbnRzLm9mZignbWVudW9wZW5jaGFuZ2UnLCBvbk1lbnVPcGVuQ2hhbmdlKTtcbiAgICB9O1xuICB9LCBbc3RvcmUsIGZsb2F0aW5nVHJlZVJvb3QuZXZlbnRzLCBmbG9hdGluZ05vZGVJZF0pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChzdG9yZS5zZWxlY3QoJ2Zsb2F0aW5nUGFyZW50Tm9kZUlkJykgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgZnVuY3Rpb24gb25QYXJlbnRDbG9zZShkZXRhaWxzKSB7XG4gICAgICBpZiAoZGV0YWlscy5vcGVuIHx8IGRldGFpbHMubm9kZUlkICE9PSBzdG9yZS5zZWxlY3QoJ2Zsb2F0aW5nUGFyZW50Tm9kZUlkJykpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgcmVhc29uID0gZGV0YWlscy5yZWFzb24gPz8gUkVBU09OUy5zaWJsaW5nT3BlbjtcbiAgICAgIHN0b3JlLnNldE9wZW4oZmFsc2UsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhyZWFzb24pKTtcbiAgICB9XG4gICAgZmxvYXRpbmdUcmVlUm9vdC5ldmVudHMub24oJ21lbnVvcGVuY2hhbmdlJywgb25QYXJlbnRDbG9zZSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGZsb2F0aW5nVHJlZVJvb3QuZXZlbnRzLm9mZignbWVudW9wZW5jaGFuZ2UnLCBvblBhcmVudENsb3NlKTtcbiAgICB9O1xuICB9LCBbZmxvYXRpbmdUcmVlUm9vdC5ldmVudHMsIHN0b3JlXSk7XG4gIGNvbnN0IGNsb3NlVGltZW91dCA9IHVzZVRpbWVvdXQoKTtcblxuICAvLyBDbGVhciBwZW5kaW5nIGNsb3NlIHRpbWVvdXQgd2hlbiB0aGUgbWVudSBjbG9zZXMuXG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuKSB7XG4gICAgICBjbG9zZVRpbWVvdXQuY2xlYXIoKTtcbiAgICB9XG4gIH0sIFtvcGVuLCBjbG9zZVRpbWVvdXRdKTtcblxuICAvLyBDbG9zZSB1bnJlbGF0ZWQgY2hpbGQgc3VibWVudXMgd2hlbiBob3ZlcmluZyBhIGRpZmZlcmVudCBpdGVtIGluIHRoZSBwYXJlbnQgbWVudS5cbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBmdW5jdGlvbiBvbkl0ZW1Ib3ZlcihldmVudCkge1xuICAgICAgLy8gSWYgYW4gaXRlbSB3aXRoaW4gb3VyIHBhcmVudCBtZW51IGlzIGhvdmVyZWQsIGFuZCB0aGlzIG1lbnUncyB0cmlnZ2VyIGlzIG5vdCB0aGF0IGl0ZW0sXG4gICAgICAvLyBjbG9zZSB0aGlzIHN1Ym1lbnUuIFRoaXMgZW5zdXJlcyBob3ZlcmluZyBhIGRpZmZlcmVudCBpdGVtIGluIHRoZSBwYXJlbnQgY2xvc2VzIG90aGVyIGJyYW5jaGVzLlxuICAgICAgaWYgKCFvcGVuIHx8IGV2ZW50Lm5vZGVJZCAhPT0gc3RvcmUuc2VsZWN0KCdmbG9hdGluZ1BhcmVudE5vZGVJZCcpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChldmVudC50YXJnZXQgJiYgdHJpZ2dlckVsZW1lbnQgJiYgdHJpZ2dlckVsZW1lbnQgIT09IGV2ZW50LnRhcmdldCkge1xuICAgICAgICBjb25zdCBkZWxheSA9IHN0b3JlLnNlbGVjdCgnY2xvc2VEZWxheScpO1xuICAgICAgICBpZiAoZGVsYXkgPiAwKSB7XG4gICAgICAgICAgaWYgKCFjbG9zZVRpbWVvdXQuaXNTdGFydGVkKCkpIHtcbiAgICAgICAgICAgIGNsb3NlVGltZW91dC5zdGFydChkZWxheSwgKCkgPT4ge1xuICAgICAgICAgICAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5zaWJsaW5nT3BlbikpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHN0b3JlLnNldE9wZW4oZmFsc2UsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLnNpYmxpbmdPcGVuKSk7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIFVzZXIgcmUtaG92ZXJlZCB0aGUgc3VibWVudSB0cmlnZ2VyLCBjYW5jZWwgcGVuZGluZyBjbG9zZS5cbiAgICAgICAgY2xvc2VUaW1lb3V0LmNsZWFyKCk7XG4gICAgICB9XG4gICAgfVxuICAgIGZsb2F0aW5nVHJlZVJvb3QuZXZlbnRzLm9uKCdpdGVtaG92ZXInLCBvbkl0ZW1Ib3Zlcik7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGZsb2F0aW5nVHJlZVJvb3QuZXZlbnRzLm9mZignaXRlbWhvdmVyJywgb25JdGVtSG92ZXIpO1xuICAgIH07XG4gIH0sIFtmbG9hdGluZ1RyZWVSb290LmV2ZW50cywgb3BlbiwgdHJpZ2dlckVsZW1lbnQsIHN0b3JlLCBjbG9zZVRpbWVvdXRdKTtcbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCBldmVudERldGFpbHMgPSB7XG4gICAgICBvcGVuLFxuICAgICAgbm9kZUlkOiBmbG9hdGluZ05vZGVJZCxcbiAgICAgIHBhcmVudE5vZGVJZDogZmxvYXRpbmdQYXJlbnROb2RlSWQsXG4gICAgICByZWFzb246IHN0b3JlLnNlbGVjdCgnbGFzdE9wZW5DaGFuZ2VSZWFzb24nKVxuICAgIH07XG4gICAgZmxvYXRpbmdUcmVlUm9vdC5ldmVudHMuZW1pdCgnbWVudW9wZW5jaGFuZ2UnLCBldmVudERldGFpbHMpO1xuICB9LCBbZmxvYXRpbmdUcmVlUm9vdC5ldmVudHMsIG9wZW4sIHN0b3JlLCBmbG9hdGluZ05vZGVJZCwgZmxvYXRpbmdQYXJlbnROb2RlSWRdKTtcbiAgdXNlVHJpZ2dlclN3aXRjaFRyYW5zaXRpb24oe1xuICAgIHN0b3JlLFxuICAgIGRvbVJlZmVyZW5jZSxcbiAgICBwb3NpdGlvbmVyRWxlbWVudCxcbiAgICBvcGVuXG4gIH0pO1xuICBjb25zdCBzdGF0ZSA9IHtcbiAgICBvcGVuLFxuICAgIHNpZGU6IHBvc2l0aW9uZXIuc2lkZSxcbiAgICBhbGlnbjogcG9zaXRpb25lci5hbGlnbixcbiAgICBhbmNob3JIaWRkZW46IHBvc2l0aW9uZXIuYW5jaG9ySGlkZGVuLFxuICAgIG5lc3RlZDogcGFyZW50LnR5cGUgPT09ICdtZW51JyxcbiAgICBpbnN0YW50OiBpbnN0YW50VHlwZVxuICB9O1xuICBjb25zdCBtZW51YmFyTW9kYWwgPSBwYXJlbnQudHlwZSA9PT0gJ21lbnViYXInICYmIHBhcmVudC5jb250ZXh0Lm1vZGFsO1xuICBjb25zdCBwb3B1cE1vZGFsID0gbW9kYWwgJiYgbGFzdE9wZW5DaGFuZ2VSZWFzb24gIT09IFJFQVNPTlMudHJpZ2dlckhvdmVyO1xuICB1c2VBbmNob3JlZFBvcHVwU2Nyb2xsTG9jayhvcGVuICYmIChtZW51YmFyTW9kYWwgfHwgcG9wdXBNb2RhbCksIG9wZW5NZXRob2QgPT09ICd0b3VjaCcsIHBvc2l0aW9uZXJFbGVtZW50LCB0cmlnZ2VyRWxlbWVudCk7XG4gIGNvbnN0IGVsZW1lbnQgPSB1c2VQb3NpdGlvbmVyKGNvbXBvbmVudFByb3BzLCBzdGF0ZSwge1xuICAgIHN0eWxlczogcG9zaXRpb25lci5wb3NpdGlvbmVyU3R5bGVzLFxuICAgIHRyYW5zaXRpb25TdGF0dXMsXG4gICAgcHJvcHM6IGVsZW1lbnRQcm9wcyxcbiAgICByZWZzOiBbZm9yd2FyZGVkUmVmLCBzdG9yZS51c2VTdGF0ZVNldHRlcigncG9zaXRpb25lckVsZW1lbnQnKV0sXG4gICAgaGlkZGVuOiAhbW91bnRlZCxcbiAgICBpbmVydDogIW9wZW5cbiAgfSk7XG4gIGNvbnN0IHNob3VsZFJlbmRlckJhY2tkcm9wID0gbW91bnRlZCAmJiBwYXJlbnQudHlwZSAhPT0gJ21lbnUnICYmIChwYXJlbnQudHlwZSAhPT0gJ21lbnViYXInICYmIG1vZGFsICYmIGxhc3RPcGVuQ2hhbmdlUmVhc29uICE9PSBSRUFTT05TLnRyaWdnZXJIb3ZlciB8fCBwYXJlbnQudHlwZSA9PT0gJ21lbnViYXInICYmIHBhcmVudC5jb250ZXh0Lm1vZGFsKTtcblxuICAvLyBjdXRzIGEgaG9sZSBpbiB0aGUgYmFja2Ryb3AgdG8gYWxsb3cgcG9pbnRlciBpbnRlcmFjdGlvbiB3aXRoIHRoZSBtZW51YmFyIG9yIGRyb3Bkb3duIG1lbnUgdHJpZ2dlciBlbGVtZW50XG4gIGxldCBiYWNrZHJvcEN1dG91dCA9IG51bGw7XG4gIGlmIChwYXJlbnQudHlwZSA9PT0gJ21lbnViYXInKSB7XG4gICAgYmFja2Ryb3BDdXRvdXQgPSBwYXJlbnQuY29udGV4dC5jb250ZW50RWxlbWVudDtcbiAgfSBlbHNlIGlmIChwYXJlbnQudHlwZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgYmFja2Ryb3BDdXRvdXQgPSB0cmlnZ2VyRWxlbWVudDtcbiAgfVxuICByZXR1cm4gLyojX19QVVJFX18qL19qc3hzKE1lbnVQb3NpdGlvbmVyQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBwb3NpdGlvbmVyLFxuICAgIGNoaWxkcmVuOiBbc2hvdWxkUmVuZGVyQmFja2Ryb3AgJiYgLyojX19QVVJFX18qL19qc3goSW50ZXJuYWxCYWNrZHJvcCwge1xuICAgICAgcmVmOiBwYXJlbnQudHlwZSA9PT0gJ2NvbnRleHQtbWVudScgfHwgcGFyZW50LnR5cGUgPT09ICduZXN0ZWQtY29udGV4dC1tZW51JyA/IHBhcmVudC5jb250ZXh0LmludGVybmFsQmFja2Ryb3BSZWYgOiBudWxsLFxuICAgICAgaW5lcnQ6IGluZXJ0VmFsdWUoIW9wZW4pLFxuICAgICAgY3V0b3V0OiBiYWNrZHJvcEN1dG91dFxuICAgIH0pLCAvKiNfX1BVUkVfXyovX2pzeChGbG9hdGluZ05vZGUsIHtcbiAgICAgIGlkOiBmbG9hdGluZ05vZGVJZCxcbiAgICAgIGNoaWxkcmVuOiAvKiNfX1BVUkVfXyovX2pzeChDb21wb3NpdGVMaXN0LCB7XG4gICAgICAgIGVsZW1lbnRzUmVmOiBzdG9yZS5jb250ZXh0Lml0ZW1Eb21FbGVtZW50cyxcbiAgICAgICAgbGFiZWxzUmVmOiBzdG9yZS5jb250ZXh0Lml0ZW1MYWJlbHMsXG4gICAgICAgIG9uTWFwQ2hhbmdlOiBzeW5jSGlnaGxpZ2h0ZWRJdGVtLFxuICAgICAgICBjaGlsZHJlbjogZWxlbWVudFxuICAgICAgfSlcbiAgICB9KV1cbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnVQb3NpdGlvbmVyLmRpc3BsYXlOYW1lID0gXCJNZW51UG9zaXRpb25lclwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuZXhwb3J0IGNvbnN0IE1lbnVSYWRpb0dyb3VwQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHVuZGVmaW5lZCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51UmFkaW9Hcm91cENvbnRleHQuZGlzcGxheU5hbWUgPSBcIk1lbnVSYWRpb0dyb3VwQ29udGV4dFwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZU1lbnVSYWRpb0dyb3VwQ29udGV4dCgpIHtcbiAgY29uc3QgY29udGV4dCA9IFJlYWN0LnVzZUNvbnRleHQoTWVudVJhZGlvR3JvdXBDb250ZXh0KTtcbiAgaWYgKGNvbnRleHQgPT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAnQmFzZSBVSTogTWVudVJhZGlvR3JvdXBDb250ZXh0IGlzIG1pc3NpbmcuIE1lbnVSYWRpb0dyb3VwIHBhcnRzIG11c3QgYmUgcGxhY2VkIHdpdGhpbiA8TWVudS5SYWRpb0dyb3VwPi4nIDogX2Zvcm1hdEVycm9yTWVzc2FnZSgzNCkpO1xuICB9XG4gIHJldHVybiBjb250ZXh0O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlQ29udHJvbGxlZCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUNvbnRyb2xsZWQnO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyB1c2VNZW51RmlsdGVySW1wbCB9IGZyb20gXCIuLi9maWx0ZXItcm9vdC9NZW51RmlsdGVyQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IE1lbnVSYWRpb0dyb3VwQ29udGV4dCB9IGZyb20gXCIuL01lbnVSYWRpb0dyb3VwQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IE1lbnVHcm91cENvbnRleHQgfSBmcm9tIFwiLi4vZ3JvdXAvTWVudUdyb3VwQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGNvbnN0IE1lbnVSYWRpb0dyb3VwUGxhaW4gPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBNZW51UmFkaW9Hcm91cFBsYWluKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgdmFsdWU6IHZhbHVlUHJvcCxcbiAgICBkZWZhdWx0VmFsdWUsXG4gICAgb25WYWx1ZUNoYW5nZTogb25WYWx1ZUNoYW5nZVByb3AsXG4gICAgZGlzYWJsZWQgPSBmYWxzZSxcbiAgICBzdHlsZSxcbiAgICAnYXJpYS1sYWJlbGxlZGJ5JzogYXJpYUxhYmVsbGVkQnlQcm9wLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IFtsYWJlbElkLCBzZXRMYWJlbElkXSA9IFJlYWN0LnVzZVN0YXRlKHVuZGVmaW5lZCk7XG4gIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVVbndyYXBwZWRdID0gdXNlQ29udHJvbGxlZCh7XG4gICAgY29udHJvbGxlZDogdmFsdWVQcm9wLFxuICAgIGRlZmF1bHQ6IGRlZmF1bHRWYWx1ZSxcbiAgICBuYW1lOiAnTWVudVJhZGlvR3JvdXAnXG4gIH0pO1xuICBjb25zdCBzZXRWYWx1ZSA9IHVzZVN0YWJsZUNhbGxiYWNrKChuZXdWYWx1ZSwgZXZlbnREZXRhaWxzKSA9PiB7XG4gICAgb25WYWx1ZUNoYW5nZVByb3A/LihuZXdWYWx1ZSwgZXZlbnREZXRhaWxzKTtcbiAgICBpZiAoZXZlbnREZXRhaWxzLmlzQ2FuY2VsZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc2V0VmFsdWVVbndyYXBwZWQobmV3VmFsdWUpO1xuICB9KTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgZGlzYWJsZWRcbiAgfTtcbiAgY29uc3QgZWxlbWVudCA9IHVzZVJlbmRlckVsZW1lbnQoJ2RpdicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgc3RhdGUsXG4gICAgcmVmOiBmb3J3YXJkZWRSZWYsXG4gICAgcHJvcHM6IHtcbiAgICAgIHJvbGU6ICdncm91cCcsXG4gICAgICAnYXJpYS1sYWJlbGxlZGJ5JzogYXJpYUxhYmVsbGVkQnlQcm9wID8/IGxhYmVsSWQsXG4gICAgICAnYXJpYS1kaXNhYmxlZCc6IGRpc2FibGVkIHx8IHVuZGVmaW5lZCxcbiAgICAgIC4uLmVsZW1lbnRQcm9wc1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IGNvbnRleHQgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgdmFsdWUsXG4gICAgc2V0VmFsdWUsXG4gICAgZGlzYWJsZWRcbiAgfSksIFt2YWx1ZSwgc2V0VmFsdWUsIGRpc2FibGVkXSk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChNZW51R3JvdXBDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IHNldExhYmVsSWQsXG4gICAgY2hpbGRyZW46IC8qI19fUFVSRV9fKi9fanN4KE1lbnVSYWRpb0dyb3VwQ29udGV4dC5Qcm92aWRlciwge1xuICAgICAgdmFsdWU6IGNvbnRleHQsXG4gICAgICBjaGlsZHJlbjogZWxlbWVudFxuICAgIH0pXG4gIH0pO1xufSk7XG5cbi8qKlxuICogR3JvdXBzIHJlbGF0ZWQgcmFkaW8gaXRlbXMuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIE1lbnVdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9tZW51KVxuICovXG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51UmFkaW9Hcm91cFBsYWluLmRpc3BsYXlOYW1lID0gXCJNZW51UmFkaW9Hcm91cFBsYWluXCI7XG5leHBvcnQgY29uc3QgTWVudVJhZGlvR3JvdXAgPSAvKiNfX1BVUkVfXyovUmVhY3QubWVtbygvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBNZW51UmFkaW9Hcm91cChwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IFJhZGlvR3JvdXAgPSB1c2VNZW51RmlsdGVySW1wbCgpPy5SYWRpb0dyb3VwID8/IE1lbnVSYWRpb0dyb3VwUGxhaW47XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChSYWRpb0dyb3VwLCB7XG4gICAgLi4ucHJvcHMsXG4gICAgcmVmOiBmb3J3YXJkZWRSZWZcbiAgfSk7XG59KSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51UmFkaW9Hcm91cC5kaXNwbGF5TmFtZSA9IFwiTWVudVJhZGlvR3JvdXBcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCBfZm9ybWF0RXJyb3JNZXNzYWdlIGZyb20gXCJAYmFzZS11aS91dGlscy9mb3JtYXRFcnJvck1lc3NhZ2VcIjtcbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBNZW51UmFkaW9JdGVtQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KHVuZGVmaW5lZCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51UmFkaW9JdGVtQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiTWVudVJhZGlvSXRlbUNvbnRleHRcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VNZW51UmFkaW9JdGVtQ29udGV4dCgpIHtcbiAgY29uc3QgY29udGV4dCA9IFJlYWN0LnVzZUNvbnRleHQoTWVudVJhZGlvSXRlbUNvbnRleHQpO1xuICBpZiAoY29udGV4dCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/ICdCYXNlIFVJOiBNZW51UmFkaW9JdGVtQ29udGV4dCBpcyBtaXNzaW5nLiBNZW51UmFkaW9JdGVtIHBhcnRzIG11c3QgYmUgcGxhY2VkIHdpdGhpbiA8TWVudS5SYWRpb0l0ZW0+LicgOiBfZm9ybWF0RXJyb3JNZXNzYWdlKDM1KSk7XG4gIH1cbiAgcmV0dXJuIGNvbnRleHQ7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBOT09QIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuaW1wb3J0IHsgdXNlTWVudUZpbHRlckl0ZW0gfSBmcm9tIFwiLi4vZmlsdGVyLXJvb3QvTWVudUZpbHRlckNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51Um9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9NZW51Um9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQmFzZVVpSWQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZUJhc2VVaUlkLm1qc1wiO1xuaW1wb3J0IHsgdXNlTWVudVJhZGlvR3JvdXBDb250ZXh0IH0gZnJvbSBcIi4uL3JhZGlvLWdyb3VwL01lbnVSYWRpb0dyb3VwQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IE1lbnVSYWRpb0l0ZW1Db250ZXh0IH0gZnJvbSBcIi4vTWVudVJhZGlvSXRlbUNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBpdGVtTWFwcGluZyB9IGZyb20gXCIuLi91dGlscy9zdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nLm1qc1wiO1xuaW1wb3J0IHsgdXNlQ29tcG9zaXRlTGlzdEl0ZW0gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NvbXBvc2l0ZS9saXN0L3VzZUNvbXBvc2l0ZUxpc3RJdGVtLm1qc1wiO1xuaW1wb3J0IHsgUkVHVUxBUl9JVEVNLCB1c2VNZW51SXRlbSB9IGZyb20gXCIuLi9pdGVtL3VzZU1lbnVJdGVtLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmNvbnN0IE1lbnVSYWRpb0l0ZW1QbGFpbiA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIE1lbnVSYWRpb0l0ZW1QbGFpbihjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIGlkOiBpZFByb3AsXG4gICAgbGFiZWwsXG4gICAgbmF0aXZlQnV0dG9uID0gZmFsc2UsXG4gICAgZGlzYWJsZWQ6IGRpc2FibGVkUHJvcCA9IGZhbHNlLFxuICAgIGNsb3NlT25DbGljayA9IGZhbHNlLFxuICAgIHZhbHVlLFxuICAgIHN0eWxlLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IHtcbiAgICBzdG9yZVxuICB9ID0gdXNlTWVudVJvb3RDb250ZXh0KCk7XG4gIGNvbnN0IHtcbiAgICB2YWx1ZTogc2VsZWN0ZWRWYWx1ZSxcbiAgICBzZXRWYWx1ZTogc2V0U2VsZWN0ZWRWYWx1ZSxcbiAgICBkaXNhYmxlZDogZ3JvdXBEaXNhYmxlZFxuICB9ID0gdXNlTWVudVJhZGlvR3JvdXBDb250ZXh0KCk7XG4gIGNvbnN0IGxpc3RJdGVtID0gdXNlQ29tcG9zaXRlTGlzdEl0ZW0oe1xuICAgIGd1ZXNzOiB0cnVlLFxuICAgIGxhYmVsXG4gIH0pO1xuICBjb25zdCBpZCA9IHVzZUJhc2VVaUlkKGlkUHJvcCk7XG4gIGNvbnN0IGhpZ2hsaWdodGVkID0gc3RvcmUudXNlU3RhdGUoJ2lzQWN0aXZlJywgbGlzdEl0ZW0uaW5kZXgpO1xuICBjb25zdCBub2RlSWQgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdOb2RlSWQnKTtcbiAgY29uc3QgaXRlbVByb3BzID0gc3RvcmUudXNlU3RhdGUoJ2l0ZW1Qcm9wcycpO1xuICBjb25zdCByb290RGlzYWJsZWQgPSBzdG9yZS51c2VTdGF0ZSgnZGlzYWJsZWQnKTtcbiAgY29uc3QgZGlzYWJsZWQgPSBkaXNhYmxlZFByb3AgfHwgZ3JvdXBEaXNhYmxlZCB8fCByb290RGlzYWJsZWQ7XG4gIGNvbnN0IGNoZWNrZWQgPSBzZWxlY3RlZFZhbHVlID09PSB2YWx1ZTtcbiAgY29uc3Qge1xuICAgIGdldEl0ZW1Qcm9wcyxcbiAgICBpdGVtUmVmXG4gIH0gPSB1c2VNZW51SXRlbSh7XG4gICAgY2xvc2VPbkNsaWNrLFxuICAgIGRpc2FibGVkLFxuICAgIGhpZ2hsaWdodGVkLFxuICAgIGlkLFxuICAgIHN0b3JlLFxuICAgIG5hdGl2ZUJ1dHRvbixcbiAgICBub2RlSWQsXG4gICAgaXRlbU1ldGFkYXRhOiBSRUdVTEFSX0lURU1cbiAgfSk7XG4gIGNvbnN0IHN0YXRlID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIGRpc2FibGVkLFxuICAgIGhpZ2hsaWdodGVkLFxuICAgIGNoZWNrZWRcbiAgfSksIFtkaXNhYmxlZCwgaGlnaGxpZ2h0ZWQsIGNoZWNrZWRdKTtcbiAgZnVuY3Rpb24gaGFuZGxlQ2xpY2soZXZlbnQpIHtcbiAgICBjb25zdCBkZXRhaWxzID0gY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuaXRlbVByZXNzLCBldmVudC5uYXRpdmVFdmVudCwgdW5kZWZpbmVkLCB7XG4gICAgICBwcmV2ZW50VW5tb3VudE9uQ2xvc2U6IE5PT1BcbiAgICB9KTtcbiAgICBzZXRTZWxlY3RlZFZhbHVlKHZhbHVlLCBkZXRhaWxzKTtcbiAgfVxuICBjb25zdCBlbGVtZW50ID0gdXNlUmVuZGVyRWxlbWVudCgnZGl2JywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiBpdGVtTWFwcGluZyxcbiAgICBwcm9wczogW2l0ZW1Qcm9wcywge1xuICAgICAgcm9sZTogJ21lbnVpdGVtcmFkaW8nLFxuICAgICAgJ2FyaWEtY2hlY2tlZCc6IGNoZWNrZWQsXG4gICAgICBvbkNsaWNrOiBoYW5kbGVDbGlja1xuICAgIH0sIGVsZW1lbnRQcm9wcywgZ2V0SXRlbVByb3BzXSxcbiAgICByZWY6IFtpdGVtUmVmLCBmb3J3YXJkZWRSZWYsIGxpc3RJdGVtLnJlZl1cbiAgfSk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChNZW51UmFkaW9JdGVtQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBzdGF0ZSxcbiAgICBjaGlsZHJlbjogZWxlbWVudFxuICB9KTtcbn0pO1xuXG4vKipcbiAqIEEgbWVudSBpdGVtIHRoYXQgd29ya3MgbGlrZSBhIHJhZGlvIGJ1dHRvbiBpbiBhIGdpdmVuIGdyb3VwLlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBNZW51XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvbWVudSlcbiAqL1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgTWVudVJhZGlvSXRlbVBsYWluLmRpc3BsYXlOYW1lID0gXCJNZW51UmFkaW9JdGVtUGxhaW5cIjtcbmV4cG9ydCBjb25zdCBNZW51UmFkaW9JdGVtID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gTWVudVJhZGlvSXRlbShwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IGZpbHRlckl0ZW0gPSB1c2VNZW51RmlsdGVySXRlbShwcm9wcywgZm9yd2FyZGVkUmVmKTtcbiAgaWYgKCFmaWx0ZXJJdGVtLnZpc2libGUpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goTWVudVJhZGlvSXRlbVBsYWluLCB7XG4gICAgLi4ucHJvcHMsXG4gICAgcmVmOiBmaWx0ZXJJdGVtLnJlZlxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgTWVudVJhZGlvSXRlbS5kaXNwbGF5TmFtZSA9IFwiTWVudVJhZGlvSXRlbVwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTWVudVJhZGlvSXRlbUNvbnRleHQgfSBmcm9tIFwiLi4vcmFkaW8taXRlbS9NZW51UmFkaW9JdGVtQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBpdGVtTWFwcGluZyB9IGZyb20gXCIuLi91dGlscy9zdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nLm1qc1wiO1xuaW1wb3J0IHsgdXNlVHJhbnNpdGlvblN0YXR1cyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlVHJhbnNpdGlvblN0YXR1cy5tanNcIjtcbmltcG9ydCB7IHVzZU9wZW5DaGFuZ2VDb21wbGV0ZSB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlT3BlbkNoYW5nZUNvbXBsZXRlLm1qc1wiO1xuXG4vKipcbiAqIEluZGljYXRlcyB3aGV0aGVyIHRoZSByYWRpbyBpdGVtIGlzIHNlbGVjdGVkLlxuICogUmVuZGVycyBhIGA8c3Bhbj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgTWVudV0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL21lbnUpXG4gKi9cbmV4cG9ydCBjb25zdCBNZW51UmFkaW9JdGVtSW5kaWNhdG9yID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gTWVudVJhZGlvSXRlbUluZGljYXRvcihjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIGtlZXBNb3VudGVkID0gZmFsc2UsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3QgaXRlbSA9IHVzZU1lbnVSYWRpb0l0ZW1Db250ZXh0KCk7XG4gIGNvbnN0IGluZGljYXRvclJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3Qge1xuICAgIHRyYW5zaXRpb25TdGF0dXMsXG4gICAgbW91bnRlZCxcbiAgICBzZXRNb3VudGVkXG4gIH0gPSB1c2VUcmFuc2l0aW9uU3RhdHVzKGl0ZW0uY2hlY2tlZCk7XG4gIHVzZU9wZW5DaGFuZ2VDb21wbGV0ZSh7XG4gICAgYmF0Y2g6IHRydWUsXG4gICAgZW5hYmxlZDogIWl0ZW0uY2hlY2tlZCxcbiAgICBvcGVuOiBpdGVtLmNoZWNrZWQsXG4gICAgcmVmOiBpbmRpY2F0b3JSZWYsXG4gICAgb25Db21wbGV0ZSgpIHtcbiAgICAgIGlmICghaXRlbS5jaGVja2VkKSB7XG4gICAgICAgIHNldE1vdW50ZWQoZmFsc2UpO1xuICAgICAgfVxuICAgIH1cbiAgfSk7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIGNoZWNrZWQ6IGl0ZW0uY2hlY2tlZCxcbiAgICBkaXNhYmxlZDogaXRlbS5kaXNhYmxlZCxcbiAgICBoaWdobGlnaHRlZDogaXRlbS5oaWdobGlnaHRlZCxcbiAgICB0cmFuc2l0aW9uU3RhdHVzXG4gIH07XG4gIGNvbnN0IGVsZW1lbnQgPSB1c2VSZW5kZXJFbGVtZW50KCdzcGFuJywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiBpdGVtTWFwcGluZyxcbiAgICByZWY6IFtmb3J3YXJkZWRSZWYsIGluZGljYXRvclJlZl0sXG4gICAgcHJvcHM6IHtcbiAgICAgICdhcmlhLWhpZGRlbic6IHRydWUsXG4gICAgICAuLi5lbGVtZW50UHJvcHNcbiAgICB9LFxuICAgIGVuYWJsZWQ6IGtlZXBNb3VudGVkIHx8IG1vdW50ZWRcbiAgfSk7XG4gIHJldHVybiBlbGVtZW50O1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51UmFkaW9JdGVtSW5kaWNhdG9yLmRpc3BsYXlOYW1lID0gXCJNZW51UmFkaW9JdGVtSW5kaWNhdG9yXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgX2Zvcm1hdEVycm9yTWVzc2FnZSBmcm9tIFwiQGJhc2UtdWkvdXRpbHMvZm9ybWF0RXJyb3JNZXNzYWdlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5leHBvcnQgY29uc3QgTWVudWJhckNvbnRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlQ29udGV4dChudWxsKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnViYXJDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJNZW51YmFyQ29udGV4dFwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZU1lbnViYXJDb250ZXh0KG9wdGlvbmFsKSB7XG4gIGNvbnN0IGNvbnRleHQgPSBSZWFjdC51c2VDb250ZXh0KE1lbnViYXJDb250ZXh0KTtcbiAgaWYgKGNvbnRleHQgPT09IG51bGwgJiYgIW9wdGlvbmFsKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/ICdCYXNlIFVJOiBNZW51YmFyQ29udGV4dCBpcyBtaXNzaW5nLiBNZW51YmFyIHBhcnRzIG11c3QgYmUgcGxhY2VkIHdpdGhpbiA8TWVudWJhcj4uJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoNSkpO1xuICB9XG4gIHJldHVybiBjb250ZXh0O1xufSIsImltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5cbi8qKlxuICogVGhlIGBvbkl0ZW1IaWdobGlnaHRlZGAgcmVhc29uIGZvciBhIGxpc3QgbmF2aWdhdGlvbiBldmVudCwgbWF0Y2hpbmcgdGhlIGV2ZW50IHR5cGUgdGhhdCB0aGVcbiAqIHJlYXNvbiBwcm9taXNlcyBpbiBpdHMgZGV0YWlscy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEhpZ2hsaWdodFJlYXNvbihldmVudCkge1xuICBpZiAoZXZlbnQgPT0gbnVsbCkge1xuICAgIHJldHVybiBSRUFTT05TLm5vbmU7XG4gIH1cbiAgaWYgKGV2ZW50LnR5cGUuc3RhcnRzV2l0aCgna2V5JykpIHtcbiAgICByZXR1cm4gUkVBU09OUy5rZXlib2FyZDtcbiAgfVxuICBpZiAoZXZlbnQudHlwZS5zdGFydHNXaXRoKCdtb3VzZScpIHx8IGV2ZW50LnR5cGUuc3RhcnRzV2l0aCgncG9pbnRlcicpKSB7XG4gICAgcmV0dXJuIFJFQVNPTlMucG9pbnRlcjtcbiAgfVxuICByZXR1cm4gUkVBU09OUy5ub25lO1xufSIsImltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IFJlYWN0U3RvcmUgfSBmcm9tICdAYmFzZS11aS91dGlscy9zdG9yZSc7XG5pbXBvcnQgeyBFTVBUWV9PQkpFQ1QsIE5PT1AgfSBmcm9tICdAYmFzZS11aS91dGlscy9lbXB0eSc7XG5pbXBvcnQgeyBwbGF0Zm9ybSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtJztcbmltcG9ydCB7IEZsb2F0aW5nVHJlZVN0b3JlIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2NvbXBvbmVudHMvRmxvYXRpbmdUcmVlU3RvcmUubWpzXCI7XG5pbXBvcnQgeyBOdWxsU3RvcmUgfSBmcm9tIFwiLi4vLi4vdXRpbHMvTnVsbFN0b3JlLm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlSW5pdGlhbFBvcHVwU3RvcmVTdGF0ZSwgcG9wdXBTdG9yZVNlbGVjdG9ycywgUG9wdXBUcmlnZ2VyTWFwIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwcy9pbmRleC5tanNcIjtcbmNvbnN0IHNlbGVjdG9ycyA9IHtcbiAgLi4ucG9wdXBTdG9yZVNlbGVjdG9ycyxcbiAgZGlzYWJsZWQ6IHN0YXRlID0+IHN0YXRlLnBhcmVudC50eXBlID09PSAnbWVudWJhcicgPyBzdGF0ZS5wYXJlbnQuY29udGV4dC5kaXNhYmxlZCB8fCBzdGF0ZS5kaXNhYmxlZCA6IHN0YXRlLmRpc2FibGVkLFxuICBtb2RhbDogc3RhdGUgPT4gKHN0YXRlLnBhcmVudC50eXBlID09PSB1bmRlZmluZWQgfHwgc3RhdGUucGFyZW50LnR5cGUgPT09ICdjb250ZXh0LW1lbnUnKSAmJiAoc3RhdGUubW9kYWwgPz8gdHJ1ZSksXG4gIG9wZW5NZXRob2Q6IHN0YXRlID0+IHN0YXRlLm9wZW5NZXRob2QsXG4gIGtleWJvYXJkT3Blbjogc3RhdGUgPT4gc3RhdGUua2V5Ym9hcmRPcGVuLFxuICBhbGxvd01vdXNlRW50ZXI6IHN0YXRlID0+IHN0YXRlLmFsbG93TW91c2VFbnRlcixcbiAgaGlnaGxpZ2h0SXRlbU9uSG92ZXI6IHN0YXRlID0+IHN0YXRlLmhpZ2hsaWdodEl0ZW1PbkhvdmVyLFxuICBwYXJlbnQ6IHN0YXRlID0+IHN0YXRlLnBhcmVudCxcbiAgcm9vdElkOiBzdGF0ZSA9PiB7XG4gICAgaWYgKHN0YXRlLnBhcmVudC50eXBlID09PSAnbWVudScpIHtcbiAgICAgIHJldHVybiBzdGF0ZS5wYXJlbnQuc3RvcmUuc2VsZWN0KCdyb290SWQnKTtcbiAgICB9XG4gICAgcmV0dXJuIHN0YXRlLnBhcmVudC50eXBlICE9PSB1bmRlZmluZWQgPyBzdGF0ZS5wYXJlbnQuY29udGV4dC5yb290SWQgOiBzdGF0ZS5yb290SWQ7XG4gIH0sXG4gIGFjdGl2ZUluZGV4OiBzdGF0ZSA9PiBzdGF0ZS5hY3RpdmVJbmRleCxcbiAgbGlzdEVsZW1lbnQ6IHN0YXRlID0+IHN0YXRlLmxpc3RFbGVtZW50LFxuICAvKiogVGhlIHRyaWdnZXIncyBgYXJpYS1jb250cm9sc2A6IHRoZSBsaXN0IHdoZW4gb25lIGhvbGRzIHRoZSBgbWVudWAgcm9sZSwgZWxzZSB0aGUgcG9wdXAuICovXG4gIHRyaWdnZXJDb250cm9sc0lkOiAoc3RhdGUsIHRyaWdnZXJJZCkgPT4ge1xuICAgIGNvbnN0IHBvcHVwSWQgPSBwb3B1cFN0b3JlU2VsZWN0b3JzLnRyaWdnZXJQb3B1cElkKHN0YXRlLCB0cmlnZ2VySWQpO1xuICAgIHJldHVybiBwb3B1cElkID8gc3RhdGUubGlzdEVsZW1lbnQ/LmlkIHx8IHBvcHVwSWQgOiB1bmRlZmluZWQ7XG4gIH0sXG4gIGZpbHRlclRyaWdnZXJQcm9wczogc3RhdGUgPT4gc3RhdGUuZmlsdGVyVHJpZ2dlclByb3BzLFxuICBpbnB1dFByb3BzOiBzdGF0ZSA9PiBzdGF0ZS5pbnB1dFByb3BzLFxuICAvLyBgYXJpYS1zZWxlY3RlZGAgaXMgaW52YWxpZCBvbiBgbWVudWl0ZW1gLCBidXQgU2FmYXJpIFZvaWNlT3ZlciBuZWVkcyBpdCBmb3IgYXJyb3cta2V5XG4gIC8vIG5hdmlnYXRpb24uIExpbWl0IGl0IHRvIFdlYktpdCB3aGlsZSB0aGUgaW5wdXQgaGFzIGZvY3VzIHNvIG5vcm1hbCBWb2ljZU92ZXIgbmF2aWdhdGlvblxuICAvLyBkb2VzIG5vdCBlbmNvdW50ZXIgdGhlIGludmFsaWQgYXR0cmlidXRlLlxuICB3ZWJraXRBcmlhU2VsZWN0ZWQ6IChzdGF0ZSwgaGlnaGxpZ2h0ZWQpID0+IHBsYXRmb3JtLmVuZ2luZS53ZWJraXQgJiYgc3RhdGUuaW5wdXRGb2N1c2VkICYmIGhpZ2hsaWdodGVkID8gdHJ1ZSA6IHVuZGVmaW5lZCxcbiAgaGlnaGxpZ2h0ZWRJdGVtSWQ6IHN0YXRlID0+IHN0YXRlLmhpZ2hsaWdodGVkSXRlbT8uaWQgfHwgdW5kZWZpbmVkLFxuICBpc0FjdGl2ZTogKHN0YXRlLCBpdGVtSW5kZXgpID0+IHN0YXRlLmFjdGl2ZUluZGV4ID09PSBpdGVtSW5kZXgsXG4gIGhvdmVyRW5hYmxlZDogc3RhdGUgPT4gc3RhdGUuaG92ZXJFbmFibGVkLFxuICAvLyBgdHJpZ2dlci1jaGFuZ2VgIGRlc2NyaWJlcyBhIHBvcHVwIG1vdmluZyBiZXR3ZWVuIHRyaWdnZXJzLCB3aGljaCBvbmx5IGhhc1xuICAvLyBtZWFuaW5nIHdoaWxlIGl0IGlzIG9wZW4uIERyb3BwaW5nIGl0IG9uY2UgY2xvc2VkIGtlZXBzIGEgbGF0ZSBvciBzdGFsZVxuICAvLyByZXN0b3JhdGlvbiBmcm9tIG1hcmtpbmcgYSBjbG9zaW5nIHBvcHVwIGluc3RhbnQgYW5kIHNraXBwaW5nIGl0cyBleGl0XG4gIC8vIHRyYW5zaXRpb24sIGluY2x1ZGluZyBvbiBjbG9zZSBwYXRocyB0aGF0IG5ldmVyIHJlYWNoIGBzZXRPcGVuYCDigJQgYVxuICAvLyBjb250cm9sbGVkIGNvbnN1bWVyIGNvbW1pdHRpbmcgYG9wZW49e2ZhbHNlfWAgZ29lcyBzdHJhaWdodCB0aHJvdWdoIHRoZSBwcm9wLlxuICBpbnN0YW50VHlwZTogc3RhdGUgPT4gc3RhdGUuaW5zdGFudFR5cGUgPT09ICd0cmlnZ2VyLWNoYW5nZScgJiYgIXBvcHVwU3RvcmVTZWxlY3RvcnMub3BlbihzdGF0ZSkgPyB1bmRlZmluZWQgOiBzdGF0ZS5pbnN0YW50VHlwZSxcbiAgbGFzdE9wZW5DaGFuZ2VSZWFzb246IHN0YXRlID0+IHN0YXRlLm9wZW5DaGFuZ2VSZWFzb24sXG4gIGZsb2F0aW5nVHJlZVJvb3Q6IHN0YXRlID0+IHtcbiAgICBpZiAoc3RhdGUucGFyZW50LnR5cGUgPT09ICdtZW51Jykge1xuICAgICAgcmV0dXJuIHN0YXRlLnBhcmVudC5zdG9yZS5zZWxlY3QoJ2Zsb2F0aW5nVHJlZVJvb3QnKTtcbiAgICB9XG4gICAgcmV0dXJuIHN0YXRlLmZsb2F0aW5nVHJlZVJvb3Q7XG4gIH0sXG4gIGZsb2F0aW5nTm9kZUlkOiBzdGF0ZSA9PiBzdGF0ZS5mbG9hdGluZ05vZGVJZCxcbiAgZmxvYXRpbmdQYXJlbnROb2RlSWQ6IHN0YXRlID0+IHN0YXRlLmZsb2F0aW5nUGFyZW50Tm9kZUlkLFxuICBpdGVtUHJvcHM6IHN0YXRlID0+IHN0YXRlLml0ZW1Qcm9wcyxcbiAgY2xvc2VEZWxheTogc3RhdGUgPT4gc3RhdGUuY2xvc2VEZWxheSxcbiAgYWRhcHRpdmVPcmlnaW46IHN0YXRlID0+IHN0YXRlLmFkYXB0aXZlT3JpZ2luLFxuICBrZXlib2FyZEV2ZW50UmVsYXk6IHN0YXRlID0+IHtcbiAgICBpZiAoc3RhdGUua2V5Ym9hcmRFdmVudFJlbGF5KSB7XG4gICAgICByZXR1cm4gc3RhdGUua2V5Ym9hcmRFdmVudFJlbGF5O1xuICAgIH1cbiAgICBpZiAoc3RhdGUucGFyZW50LnR5cGUgPT09ICdtZW51Jykge1xuICAgICAgcmV0dXJuIHN0YXRlLnBhcmVudC5zdG9yZS5zZWxlY3QoJ2tleWJvYXJkRXZlbnRSZWxheScpO1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG59O1xuXG4vKipcbiAqIFRoZSBzdG9yZSB2aWV3IHRoYXQgZGV0YWNoZWQgaGFuZGxlLWJhY2tlZCB0cmlnZ2VycyByZWFkIGZyb20uIEJvdGggdGhlIHJlYWwgYE1lbnVTdG9yZWAgYW5kIHRoZVxuICogaW5lcnQgZmFsbGJhY2sgc3RvcmUgc2F0aXNmeSBpdCwgc28gYSB0cmlnZ2VyIGNhbiByZWFkIGZyb20gd2hpY2hldmVyIHN0b3JlIHRoZSBoYW5kbGUgY3VycmVudGx5XG4gKiBleHBvc2VzLiBOYXJyb3dlZCB0byB0aGUgbWVtYmVycyBhIHRyaWdnZXIgYWN0dWFsbHkgdXNlcyDigJQgdGhlIHRyaWdnZXItZGF0YSBtZW1iZXJzIHBsdXMgYHNldE9wZW5gXG4gKiAoY2FsbGVkIGJ5IHRoZSBmb2N1cyBndWFyZHMpIOKAlCBzbyB0aGUgZXhwb3NlZCBzdXJmYWNlIGNhbid0IGJ5cGFzcyB0aGUgb3Blbi1jaGFuZ2UgcGlwZWxpbmU7IG9uXG4gKiB0aGUgZGV0YWNoZWQgZmFsbGJhY2sgc3RvcmUgZXZlcnkgb25lIG9mIHRoZXNlIG11dGF0aW9ucyBpcyBhIG5vLW9wLlxuICovXG5cbmV4cG9ydCBjbGFzcyBNZW51U3RvcmUgZXh0ZW5kcyBSZWFjdFN0b3JlIHtcbiAgY29uc3RydWN0b3IoaW5pdGlhbFN0YXRlLCBmbG9hdGluZ0lkLCBuZXN0ZWQgPSBmYWxzZSkge1xuICAgIGNvbnN0IHRyaWdnZXJFbGVtZW50cyA9IG5ldyBQb3B1cFRyaWdnZXJNYXAoKTtcbiAgICBjb25zdCBzdGF0ZSA9IGNyZWF0ZUluaXRpYWxTdGF0ZSh0cmlnZ2VyRWxlbWVudHMsIGZsb2F0aW5nSWQsIG5lc3RlZCwgaW5pdGlhbFN0YXRlKTtcbiAgICBzdXBlcihzdGF0ZSwgY3JlYXRlSW5pdGlhbENvbnRleHQodHJpZ2dlckVsZW1lbnRzKSwgc2VsZWN0b3JzKTtcblxuICAgIC8vIFNoYXJlIHRoZSBtb3VzZS11cCB0cmlnZ2VyIHJlZiBvZiB0aGUgcGFyZW50IG1lbnUsIGlmIGFueS4gVGhpcyBvYnNlcnZlcyB0aGUgc3RvcmUncyBvd25cbiAgICAvLyBzdGF0ZSwgc28gdGhlIHN1YnNjcmlwdGlvbiBsaXZlcyBleGFjdGx5IGFzIGxvbmcgYXMgdGhlIHN0b3JlIGFuZCBuZWVkcyBubyBjbGVhbnVwLlxuICAgIHZvaWQgdGhpcy5vYnNlcnZlKCdwYXJlbnQnLCBwYXJlbnQgPT4ge1xuICAgICAgaWYgKHBhcmVudC50eXBlID09PSAnbWVudScpIHtcbiAgICAgICAgdGhpcy5jb250ZXh0LmFsbG93TW91c2VVcFRyaWdnZXJSZWYgPSBwYXJlbnQuc3RvcmUuY29udGV4dC5hbGxvd01vdXNlVXBUcmlnZ2VyUmVmO1xuICAgICAgfSBlbHNlIGlmIChwYXJlbnQudHlwZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHRoaXMuY29udGV4dC5hbGxvd01vdXNlVXBUcmlnZ2VyUmVmID0gcGFyZW50LmNvbnRleHQuYWxsb3dNb3VzZVVwVHJpZ2dlclJlZjtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBQcm9wYWdhdGVzIGNoYW5nZXMgb2YgdGhlIHBhcmVudCBtZW51J3Mgc2hhcmVkIHRyZWUgc3RhdGUgdG8gdGhpcyBzdG9yZSdzIHN1YnNjcmliZXJzLlxuICAgKiBUaGUgb3duaW5nIGBNZW51LlJvb3RgIGNhbGxzIGl0IGZyb20gYW4gZWZmZWN0IHNvIHRoZSBwYXJlbnQgc3RvcmUgc3Vic2NyaXB0aW9uIGlzIHJlbGVhc2VkXG4gICAqIHdoZW4gdGhlIHN1Ym1lbnUgdW5tb3VudHMuXG4gICAqIEByZXR1cm5zIEEgZnVuY3Rpb24gdGhhdCByZW1vdmVzIHRoZSBwYXJlbnQgc3RvcmUgc3Vic2NyaXB0aW9uLlxuICAgKi9cbiAgc3Vic2NyaWJlVG9QYXJlbnRNZW51KCkge1xuICAgIGNvbnN0IHBhcmVudCA9IHRoaXMuc3RhdGUucGFyZW50O1xuICAgIGlmIChwYXJlbnQudHlwZSAhPT0gJ21lbnUnKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBsZXQgcm9vdElkID0gcGFyZW50LnN0b3JlLnNlbGVjdCgncm9vdElkJyk7XG4gICAgbGV0IGZsb2F0aW5nVHJlZVJvb3QgPSBwYXJlbnQuc3RvcmUuc2VsZWN0KCdmbG9hdGluZ1RyZWVSb290Jyk7XG4gICAgbGV0IGtleWJvYXJkRXZlbnRSZWxheSA9IHBhcmVudC5zdG9yZS5zZWxlY3QoJ2tleWJvYXJkRXZlbnRSZWxheScpO1xuICAgIHJldHVybiBwYXJlbnQuc3RvcmUuc3Vic2NyaWJlKCgpID0+IHtcbiAgICAgIGNvbnN0IG5leHRSb290SWQgPSBwYXJlbnQuc3RvcmUuc2VsZWN0KCdyb290SWQnKTtcbiAgICAgIGNvbnN0IG5leHRGbG9hdGluZ1RyZWVSb290ID0gcGFyZW50LnN0b3JlLnNlbGVjdCgnZmxvYXRpbmdUcmVlUm9vdCcpO1xuICAgICAgY29uc3QgbmV4dEtleWJvYXJkRXZlbnRSZWxheSA9IHBhcmVudC5zdG9yZS5zZWxlY3QoJ2tleWJvYXJkRXZlbnRSZWxheScpO1xuICAgICAgaWYgKHJvb3RJZCA9PT0gbmV4dFJvb3RJZCAmJiBmbG9hdGluZ1RyZWVSb290ID09PSBuZXh0RmxvYXRpbmdUcmVlUm9vdCAmJiBrZXlib2FyZEV2ZW50UmVsYXkgPT09IG5leHRLZXlib2FyZEV2ZW50UmVsYXkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgcm9vdElkID0gbmV4dFJvb3RJZDtcbiAgICAgIGZsb2F0aW5nVHJlZVJvb3QgPSBuZXh0RmxvYXRpbmdUcmVlUm9vdDtcbiAgICAgIGtleWJvYXJkRXZlbnRSZWxheSA9IG5leHRLZXlib2FyZEV2ZW50UmVsYXk7XG4gICAgICB0aGlzLm5vdGlmeUFsbCgpO1xuICAgIH0pO1xuICB9XG4gIHNldE9wZW4ob3BlbiwgZXZlbnREZXRhaWxzKSB7XG4gICAgdGhpcy5zdGF0ZS5mbG9hdGluZ1Jvb3RDb250ZXh0LmNvbnRleHQuZXZlbnRzLmVtaXQoJ3NldE9wZW4nLCB7XG4gICAgICBvcGVuLFxuICAgICAgZXZlbnREZXRhaWxzXG4gICAgfSk7XG4gIH1cbiAgc2V0QWN0aXZlSW5kZXgoYWN0aXZlSW5kZXgsIHJlYXNvbiwgZXZlbnQpIHtcbiAgICAvLyBPbmx5IGEgd3JpdGUgdGhhdCBjaGFuZ2VzIHRoZSBpbmRleCBpcyByZXBvcnRlZC4gVGFnZ2luZyBhIG5vLW9wLCBvciBhIHdyaXRlIGJhY2sgdG8gdGhlXG4gICAgLy8gcmVwb3J0ZWQgaXRlbSBiZWZvcmUgdGhlIGNoYW5nZSBjb21taXRzLCB3b3VsZCBsZXQgYSBsYXRlciByZWdpc3RyeS1kcml2ZW4gcmUtZW1pdCByZXBvcnRcbiAgICAvLyB0aGlzIHJlYXNvbiBpbnN0ZWFkIG9mIGBub25lYC5cbiAgICBpZiAodGhpcy5zdGF0ZS5hY3RpdmVJbmRleCAhPT0gYWN0aXZlSW5kZXgpIHtcbiAgICAgIGNvbnN0IGl0ZW0gPSBhY3RpdmVJbmRleCA9PT0gbnVsbCA/IHVuZGVmaW5lZCA6IHRoaXMuY29udGV4dC5pdGVtRG9tRWxlbWVudHMuY3VycmVudFthY3RpdmVJbmRleF07XG4gICAgICBjb25zdCBpc1dyaXRlQmFjayA9IGl0ZW0gPT09IHRoaXMuY29udGV4dC5yZXBvcnRlZEl0ZW07XG4gICAgICB0aGlzLmNvbnRleHQuaGlnaGxpZ2h0UmVhc29uID0gaXNXcml0ZUJhY2sgPyAnbm9uZScgOiByZWFzb247XG4gICAgICB0aGlzLmNvbnRleHQuaGlnaGxpZ2h0RXZlbnQgPSBpc1dyaXRlQmFjayA/IHVuZGVmaW5lZCA6IGV2ZW50O1xuICAgIH1cbiAgICB0aGlzLnNldCgnYWN0aXZlSW5kZXgnLCBhY3RpdmVJbmRleCk7XG4gIH1cbiAgaGlnaGxpZ2h0SXRlbShlbGVtZW50LCByZWFzb24sIGV2ZW50KSB7XG4gICAgY29uc3QgaW5kZXggPSB0aGlzLmNvbnRleHQuaXRlbURvbUVsZW1lbnRzLmN1cnJlbnQuaW5kZXhPZihlbGVtZW50KTtcbiAgICBpZiAoaW5kZXggPiAtMSkge1xuICAgICAgdGhpcy5zZXRBY3RpdmVJbmRleChpbmRleCwgcmVhc29uLCBldmVudCk7XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogQ3JlYXRlcyB0aGUgaW5lcnQgZmFsbGJhY2sgc3RvcmUgdXNlZCBieSBkZXRhY2hlZCBoYW5kbGUtYmFja2VkIHRyaWdnZXJzIHdoaWxlIG5vIGBNZW51LlJvb3RgIGlzXG4gKiBhdHRhY2hlZC4gSXQgcHJlc2VydmVzIGEgbWVudS1zcGVjaWZpYyB0cmlnZ2VyIHJlZ2lzdHJ5IGluIGNvbnRleHQgc28gZGV0YWNoZWQgdHJpZ2dlcnMgY2FuXG4gKiByZWdpc3RlciBiZWZvcmUgbWlncmF0aW5nIHRvIHRoZSBsaXZlIHJvb3Qgc3RvcmUuIGBzZXRPcGVuYCBpcyBhIG5vLW9wIChtYXRjaGluZyB0aGUgaW5lcnRcbiAqIHJlYWRzL3dyaXRlcyBvZiBgTnVsbFN0b3JlYCksIHNvIGEgdHJpZ2dlciBjYW4gaGFuZCB0aGUgc3RvcmUgdG8gZm9jdXMtZ3VhcmQgaGVscGVycyB0aGF0IGV4cGVjdFxuICogYHNldE9wZW5gIHdpdGhvdXQgaXQgZXZlciB0YWtpbmcgZWZmZWN0IHdoaWxlIGRldGFjaGVkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlTnVsbE1lbnVTdG9yZSgpIHtcbiAgY29uc3QgdHJpZ2dlckVsZW1lbnRzID0gbmV3IFBvcHVwVHJpZ2dlck1hcCgpO1xuICBjb25zdCBzdG9yZSA9IG5ldyBOdWxsU3RvcmUoT2JqZWN0LmZyZWV6ZShjcmVhdGVJbml0aWFsU3RhdGUodHJpZ2dlckVsZW1lbnRzKSksIE9iamVjdC5mcmVlemUoY3JlYXRlSW5pdGlhbENvbnRleHQodHJpZ2dlckVsZW1lbnRzKSksIHNlbGVjdG9ycyk7XG4gIHJldHVybiBPYmplY3QuYXNzaWduKHN0b3JlLCB7XG4gICAgc2V0T3BlbjogTk9PUFxuICB9KTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUluaXRpYWxDb250ZXh0KHRyaWdnZXJFbGVtZW50cykge1xuICByZXR1cm4ge1xuICAgIHBvc2l0aW9uZXJSZWY6IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVSZWYoKSxcbiAgICBwb3B1cFJlZjogLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZVJlZigpLFxuICAgIHR5cGluZ1JlZjoge1xuICAgICAgY3VycmVudDogZmFsc2VcbiAgICB9LFxuICAgIGl0ZW1Eb21FbGVtZW50czoge1xuICAgICAgY3VycmVudDogW11cbiAgICB9LFxuICAgIGl0ZW1MYWJlbHM6IHtcbiAgICAgIGN1cnJlbnQ6IFtdXG4gICAgfSxcbiAgICBoaWdobGlnaHRSZWFzb246ICdub25lJyxcbiAgICBoaWdobGlnaHRFdmVudDogdW5kZWZpbmVkLFxuICAgIHJlcG9ydGVkSXRlbTogdW5kZWZpbmVkLFxuICAgIGFsbG93TW91c2VVcFRyaWdnZXJSZWY6IHtcbiAgICAgIGN1cnJlbnQ6IGZhbHNlXG4gICAgfSxcbiAgICB2aXJ0dWFsRm9jdXNSZWY6IHVuZGVmaW5lZCxcbiAgICB0cmlnZ2VyRm9jdXNUYXJnZXRSZWY6IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVSZWYoKSxcbiAgICBiZWZvcmVUcmlnZ2VyRm9jdXNHdWFyZFJlZjogLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZVJlZigpLFxuICAgIGJlZm9yZUNvbnRlbnRGb2N1c0d1YXJkUmVmOiAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlUmVmKCksXG4gICAgb25PcGVuQ2hhbmdlQ29tcGxldGU6IHVuZGVmaW5lZCxcbiAgICB0cmlnZ2VyRWxlbWVudHNcbiAgfTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUluaXRpYWxTdGF0ZSh0cmlnZ2VyRWxlbWVudHMsIGZsb2F0aW5nSWQsIG5lc3RlZCA9IGZhbHNlLCBpbml0aWFsU3RhdGUpIHtcbiAgcmV0dXJuIHtcbiAgICAuLi5jcmVhdGVJbml0aWFsUG9wdXBTdG9yZVN0YXRlKHRyaWdnZXJFbGVtZW50cywgZmxvYXRpbmdJZCwgbmVzdGVkKSxcbiAgICBkaXNhYmxlZDogZmFsc2UsXG4gICAgbW9kYWw6IHRydWUsXG4gICAgb3Blbk1ldGhvZDogbnVsbCxcbiAgICBrZXlib2FyZE9wZW46IGZhbHNlLFxuICAgIGFsbG93TW91c2VFbnRlcjogZmFsc2UsXG4gICAgaGlnaGxpZ2h0SXRlbU9uSG92ZXI6IHRydWUsXG4gICAgcGFyZW50OiB7XG4gICAgICB0eXBlOiB1bmRlZmluZWRcbiAgICB9LFxuICAgIHJvb3RJZDogdW5kZWZpbmVkLFxuICAgIGFjdGl2ZUluZGV4OiBudWxsLFxuICAgIGxpc3RFbGVtZW50OiBudWxsLFxuICAgIGZpbHRlclRyaWdnZXJQcm9wczogRU1QVFlfT0JKRUNULFxuICAgIGlucHV0UHJvcHM6IEVNUFRZX09CSkVDVCxcbiAgICBpbnB1dEZvY3VzZWQ6IGZhbHNlLFxuICAgIGhpZ2hsaWdodGVkSXRlbTogdW5kZWZpbmVkLFxuICAgIGhvdmVyRW5hYmxlZDogdHJ1ZSxcbiAgICBpbnN0YW50VHlwZTogdW5kZWZpbmVkLFxuICAgIG9wZW5DaGFuZ2VSZWFzb246IG51bGwsXG4gICAgZmxvYXRpbmdUcmVlUm9vdDogbmV3IEZsb2F0aW5nVHJlZVN0b3JlKCksXG4gICAgZmxvYXRpbmdOb2RlSWQ6IHVuZGVmaW5lZCxcbiAgICBmbG9hdGluZ1BhcmVudE5vZGVJZDogbnVsbCxcbiAgICBpdGVtUHJvcHM6IEVNUFRZX09CSkVDVCxcbiAgICBrZXlib2FyZEV2ZW50UmVsYXk6IHVuZGVmaW5lZCxcbiAgICBjbG9zZURlbGF5OiAwLFxuICAgIGFkYXB0aXZlT3JpZ2luOiB1bmRlZmluZWQsXG4gICAgLi4uaW5pdGlhbFN0YXRlXG4gIH07XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbi8qKlxuICogV2hhdCBgTWVudS5GaWx0ZXJQcm92aWRlcmAgaGFuZHMgdG8gdGhlIHJvb3QgZGlyZWN0bHkgaW5zaWRlIGl0OiB0aGUgZmlsdGVyYWJsZSByb290XG4gKiBpbXBsZW1lbnRhdGlvbnMgKHRoZSBwcm92aWRlciBpcyB0aGVpciBvbmx5IGltcG9ydGVyKSBhbmQgdGhlIGZpbHRlciBwcm9wcy5cbiAqL1xuXG4vKipcbiAqIE5vbi1udWxsIG9ubHkgZGlyZWN0bHkgYmVsb3cgYSBwcm92aWRlci4gVGhlIHJvb3QgdGhhdCBjb25zdW1lcyBpdCByZXNldHMgaXQsIHNvIGEgcGxhaW5cbiAqIGBNZW51LlN1Ym1lbnVSb290YCBpbnNpZGUgYSBmaWx0ZXJhYmxlIG1lbnUgc3RheXMgcGxhaW4uXG4gKi9cbmV4cG9ydCBjb25zdCBNZW51RmlsdGVyUHJvdmlkZXJDb250ZXh0ID0gLyojX19QVVJFX18qL1JlYWN0LmNyZWF0ZUNvbnRleHQobnVsbCk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51RmlsdGVyUHJvdmlkZXJDb250ZXh0LmRpc3BsYXlOYW1lID0gXCJNZW51RmlsdGVyUHJvdmlkZXJDb250ZXh0XCI7IiwiaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcblxuLyoqXG4gKiBLZXlib2FyZCBhbmQgYXNzaXN0aXZlLXRlY2hub2xvZ3kgYWN0aXZhdGlvbnMgcHJvZHVjZSBgZGV0YWlsID09PSAwYCBjbGlja3M7IG1vdXNlLWdlc3R1cmVcbiAqIGNsaWNrcyAoaW5jbHVkaW5nIHRoZSBzeW50aGVzaXplZCBkcmFnLXJlbGVhc2UgY2xpY2sgZnJvbSBgdXNlTWVudUl0ZW1Db21tb25Qcm9wc2ApIGNhcnJ5XG4gKiBgZGV0YWlsID49IDFgLlxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNLZXlib2FyZENsaWNrKHJlYXNvbiwgZXZlbnQpIHtcbiAgcmV0dXJuIChyZWFzb24gPT09IFJFQVNPTlMudHJpZ2dlclByZXNzIHx8IHJlYXNvbiA9PT0gUkVBU09OUy5pdGVtUHJlc3MpICYmIGV2ZW50Py5kZXRhaWwgPT09IDA7XG59XG5cbi8qKlxuICogV2hldGhlciBhIG1lbnUgb3BlbnMgZnJvbSB0aGUga2V5Ym9hcmQsIHdoaWNoIGxhbmRzIGZvY3VzIGluIHRoZSBwb3B1cC4gQXJyb3cga2V5cyByZXBvcnRcbiAqIGBsaXN0LW5hdmlnYXRpb25gOyBFbnRlciBhbmQgU3BhY2UgZGlzcGF0Y2ggYSBjbGljayBjYXJyeWluZyBubyBwb2ludGVyIGRldGFpbC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzS2V5Ym9hcmRPcGVuKHJlYXNvbiwgZXZlbnQpIHtcbiAgcmV0dXJuIHJlYXNvbiA9PT0gUkVBU09OUy5saXN0TmF2aWdhdGlvbiB8fCBpc0tleWJvYXJkQ2xpY2socmVhc29uLCBldmVudCk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VUaW1lb3V0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlVGltZW91dCc7XG5pbXBvcnQgeyB1c2VTdGFibGVDYWxsYmFjayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrJztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVJlZldpdGhJbml0JztcbmltcG9ydCB7IEVNUFRZX0FSUkFZLCBFTVBUWV9PQkpFQ1QgfSBmcm9tICdAYmFzZS11aS91dGlscy9lbXB0eSc7XG5pbXBvcnQgeyBmYXN0Q29tcG9uZW50IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZmFzdEhvb2tzJztcbmltcG9ydCB7IEZsb2F0aW5nVHJlZSwgdXNlRGlzbWlzcywgdXNlRmxvYXRpbmdOb2RlSWQsIHVzZUZsb2F0aW5nUGFyZW50Tm9kZUlkLCB1c2VMaXN0TmF2aWdhdGlvbiwgdXNlVHlwZWFoZWFkLCB1c2VTeW5jZWRGbG9hdGluZ1Jvb3RDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgTWVudVJvb3RDb250ZXh0LCB1c2VNZW51Um9vdENvbnRleHQgfSBmcm9tIFwiLi9NZW51Um9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51YmFyQ29udGV4dCB9IGZyb20gXCIuLi8uLi9tZW51YmFyL01lbnViYXJDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgVFlQRUFIRUFEX1JFU0VUX01TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jb25zdGFudHMubWpzXCI7XG5pbXBvcnQgeyB1c2VEaXJlY3Rpb24gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2RpcmVjdGlvbi1jb250ZXh0L0RpcmVjdGlvbkNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VPcGVuSW50ZXJhY3Rpb25UeXBlIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3VzZU9wZW5JbnRlcmFjdGlvblR5cGUubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMsIGNyZWF0ZUdlbmVyaWNFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5pbXBvcnQgeyBnZXRIaWdobGlnaHRSZWFzb24gfSBmcm9tIFwiLi4vLi4vdXRpbHMvZ2V0SGlnaGxpZ2h0UmVhc29uLm1qc1wiO1xuaW1wb3J0IHsgdXNlQ29udGV4dE1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi8uLi9jb250ZXh0LW1lbnUvcm9vdC9Db250ZXh0TWVudVJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgbWVyZ2VQcm9wcyB9IGZyb20gXCIuLi8uLi9tZXJnZS1wcm9wcy9pbmRleC5tanNcIjtcbmltcG9ydCB7IHVzZUFuaW1hdGlvbnNGaW5pc2hlZCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlQW5pbWF0aW9uc0ZpbmlzaGVkLm1qc1wiO1xuaW1wb3J0IHsgTWVudVN0b3JlIH0gZnJvbSBcIi4uL3N0b3JlL01lbnVTdG9yZS5tanNcIjtcbmltcG9ydCB7IGF0dGFjaFByZXZlbnRVbm1vdW50T25DbG9zZSwgRk9DVVNBQkxFX1BPUFVQX1BST1BTLCBjcmVhdGVQb3B1cE9wZW5TdGF0ZSwgUG9wdXBIYW5kbGVBdHRhY2htZW50LCB1c2VJbXBsaWNpdEFjdGl2ZVRyaWdnZXIsIHVzZU9wZW5TdGF0ZVRyYW5zaXRpb25zLCB1c2VQb3B1cEludGVyYWN0aW9uUHJvcHMgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBzL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQmFzZVVpSWQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZUJhc2VVaUlkLm1qc1wiO1xuaW1wb3J0IHsgTWVudUZpbHRlclByb3ZpZGVyQ29udGV4dCB9IGZyb20gXCIuLi9maWx0ZXItcHJvdmlkZXIvTWVudUZpbHRlclByb3ZpZGVyQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IGlzS2V5Ym9hcmRDbGljaywgaXNLZXlib2FyZE9wZW4gfSBmcm9tIFwiLi4vdXRpbHMvaXNLZXlib2FyZE9wZW4ubWpzXCI7XG5cbi8qKlxuICogQGludGVybmFsXG4gKi9cbmltcG9ydCB7IGpzeCBhcyBfanN4LCBqc3hzIGFzIF9qc3hzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgY29uc3QgTWVudVJvb3RJbnRlcm5hbCA9IGZhc3RDb21wb25lbnQoZnVuY3Rpb24gTWVudVJvb3RJbnRlcm5hbChwcm9wcykge1xuICBjb25zdCB7XG4gICAgY2hpbGRyZW4sXG4gICAgb3Blbjogb3BlblByb3AsXG4gICAgb25PcGVuQ2hhbmdlLFxuICAgIG9uT3BlbkNoYW5nZUNvbXBsZXRlLFxuICAgIG9uSXRlbUhpZ2hsaWdodGVkOiBvbkl0ZW1IaWdobGlnaHRlZFByb3AsXG4gICAgZGVmYXVsdE9wZW4gPSBmYWxzZSxcbiAgICBkaXNhYmxlZDogZGlzYWJsZWRQcm9wID0gZmFsc2UsXG4gICAgbW9kYWw6IG1vZGFsUHJvcCxcbiAgICBsb29wRm9jdXMgPSB0cnVlLFxuICAgIG9yaWVudGF0aW9uID0gJ3ZlcnRpY2FsJyxcbiAgICBhY3Rpb25zUmVmLFxuICAgIGNsb3NlUGFyZW50T25Fc2MgPSBmYWxzZSxcbiAgICBoYW5kbGUsXG4gICAgdHJpZ2dlcklkOiB0cmlnZ2VySWRQcm9wLFxuICAgIGRlZmF1bHRUcmlnZ2VySWQ6IGRlZmF1bHRUcmlnZ2VySWRQcm9wID0gbnVsbCxcbiAgICBoaWdobGlnaHRJdGVtT25Ib3ZlciA9IHRydWUsXG4gICAgaXNTdWJtZW51ID0gZmFsc2UsXG4gICAgdmlydHVhbEZvY3VzID0gZmFsc2UsXG4gICAgdmlydHVhbEZvY3VzUmVmLFxuICAgIGFsbG93RXNjYXBlID0gdHJ1ZSxcbiAgICByZXNldE9uUG9pbnRlckxlYXZlID0gdHJ1ZVxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IGNvbnRleHRNZW51Q29udGV4dCA9IHVzZUNvbnRleHRNZW51Um9vdENvbnRleHQodHJ1ZSk7XG4gIGNvbnN0IHBhcmVudE1lbnVSb290Q29udGV4dCA9IHVzZU1lbnVSb290Q29udGV4dCh0cnVlKTtcbiAgY29uc3QgbWVudWJhckNvbnRleHQgPSB1c2VNZW51YmFyQ29udGV4dCh0cnVlKTtcblxuICAvLyBEZXBlbmQgb24gdGhlIHN0YWJsZSBwaWVjZXMgcmF0aGVyIHRoYW4gdGhlIHBhcmVudCBjb250ZXh0IG9iamVjdCwgc28gYSBwYXJlbnQgY29udGV4dFxuICAvLyBpbnZhbGlkYXRpb24gZG9lc24ndCBjYXNjYWRlIGludG8gZXZlcnkgZGVzY2VuZGFudCByb290J3MgY29udGV4dC5cbiAgY29uc3QgZW5jbG9zaW5nTWVudVN0b3JlID0gcGFyZW50TWVudVJvb3RDb250ZXh0Py5zdG9yZTtcbiAgY29uc3QgcGFyZW50VmlydHVhbEZvY3VzID0gcGFyZW50TWVudVJvb3RDb250ZXh0Py52aXJ0dWFsRm9jdXMgPz8gZmFsc2U7XG4gIGNvbnN0IHBhcmVudEZyb21Db250ZXh0ID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgaWYgKGlzU3VibWVudSAmJiBlbmNsb3NpbmdNZW51U3RvcmUpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHR5cGU6ICdtZW51JyxcbiAgICAgICAgc3RvcmU6IGVuY2xvc2luZ01lbnVTdG9yZVxuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKG1lbnViYXJDb250ZXh0KSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB0eXBlOiAnbWVudWJhcicsXG4gICAgICAgIGNvbnRleHQ6IG1lbnViYXJDb250ZXh0XG4gICAgICB9O1xuICAgIH1cblxuICAgIC8vIEVuc3VyZSB0aGlzIGlzIG5vdCBhIE1lbnUgbmVzdGVkIGluc2lkZSBDb250ZXh0TWVudS5UcmlnZ2VyLlxuICAgIC8vIENvbnRleHRNZW51IHBhcmVudENvbnRleHQgaXMgYWx3YXlzIHVuZGVmaW5lZCBhcyBDb250ZXh0TWVudS5Sb290IGlzIGluc3RhbnRpYXRlZCB3aXRoXG4gICAgLy8gPE1lbnVSb290Q29udGV4dC5Qcm92aWRlciB2YWx1ZT17dW5kZWZpbmVkfT5cbiAgICBpZiAoY29udGV4dE1lbnVDb250ZXh0ICYmICFlbmNsb3NpbmdNZW51U3RvcmUpIHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHR5cGU6ICdjb250ZXh0LW1lbnUnLFxuICAgICAgICBjb250ZXh0OiBjb250ZXh0TWVudUNvbnRleHRcbiAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICB0eXBlOiB1bmRlZmluZWRcbiAgICB9O1xuICB9LCBbY29udGV4dE1lbnVDb250ZXh0LCBlbmNsb3NpbmdNZW51U3RvcmUsIG1lbnViYXJDb250ZXh0LCBpc1N1Ym1lbnVdKTtcbiAgY29uc3Qgcm9vdElkID0gdXNlQmFzZVVpSWQoKTtcbiAgLy8gUmVhY3QgMTcgcmVzb2x2ZXMgZ2VuZXJhdGVkIGlkcyBpbiBhbiBlZmZlY3QsIHNvIHRoZXkgbXVzdCBiZSByZWFkIGxpdmUgcmF0aGVyIHRoYW4gY2FwdHVyZWRcbiAgLy8gaW4gYSBzdGF0ZSBpbml0aWFsaXplci5cbiAgY29uc3QgZGVmYXVsdEZsb2F0aW5nSWQgPSB1c2VCYXNlVWlJZCgpO1xuICBjb25zdCBbcmVuZGVyZWRGbG9hdGluZ0lkLCBzZXRSZW5kZXJlZEZsb2F0aW5nSWRdID0gUmVhY3QudXNlU3RhdGUodW5kZWZpbmVkKTtcblxuICAvLyBBIHJlZ2lzdGVyZWQgYCcnYCBtZWFucyB0aGUgcG9wdXAgcmVuZGVyZWQgd2l0aCBhbiBleHBsaWNpdGx5IGVtcHR5IGlkLCBzbyBub3RoaW5nIG1heSBwb2ludFxuICAvLyBhdCB0aGUgZ2VuZXJhdGVkIGZhbGxiYWNrLlxuICBjb25zdCBmbG9hdGluZ0lkID0gKHJlbmRlcmVkRmxvYXRpbmdJZCA/PyBkZWZhdWx0RmxvYXRpbmdJZCkgfHwgdW5kZWZpbmVkO1xuICBjb25zdCBmbG9hdGluZ1BhcmVudE5vZGVJZEZyb21Db250ZXh0ID0gdXNlRmxvYXRpbmdQYXJlbnROb2RlSWQoKTtcbiAgY29uc3QgcGFyZW50TWVudVN0b3JlID0gcGFyZW50RnJvbUNvbnRleHQudHlwZSA9PT0gJ21lbnUnID8gcGFyZW50RnJvbUNvbnRleHQuc3RvcmUgOiB1bmRlZmluZWQ7XG4gIC8vIEFuIGluaXRpYWxseSBvcGVuIHN1Ym1lbnUgc2hvdWxkIGFuaW1hdGUgaW4gb25seSB3aGVuIHRoZSB1c2VyIHdhdGNoZXMgaXQgYXBwZWFyLCBpLmUuIHdoZW5cbiAgLy8gaXRzIHN1YnRyZWUgbW91bnRzIGJlY2F1c2UgdGhlIHBhcmVudCBwb3B1cCBpcyBwbGF5aW5nIGl0cyBvd24gZW50ZXIgdHJhbnNpdGlvbi4gQSBwYXJlbnRcbiAgLy8gdGhhdCB3YXMgYGRlZmF1bHRPcGVuYCBhdCBwYWdlIGxvYWQgbmV2ZXIgcGFzc2VzIHRocm91Z2ggYCdzdGFydGluZydgLCBhbmQgdW5kZXIgYVxuICAvLyBga2VlcE1vdW50ZWRgIHBhcmVudCB0aGVzZSBpbml0aWFsaXplcnMgcnVuIGF0IHBhZ2UgbG9hZCB3aGlsZSB0aGUgcGFyZW50J3Mgc3RhdHVzIGlzIHN0aWxsXG4gIC8vIGB1bmRlZmluZWRgIOKAlCBpbiBib3RoIGNhc2VzIHRoZSBzdWJtZW51IGlzIHBhZ2UtbG9hZCBjb250ZW50IHRoYXQgbXVzdCBub3QgYW5pbWF0ZS4gR2F0ZWQgb25cbiAgLy8gYmVpbmcgb3BlbiBhdCBtb3VudCBzbyBhIGNsb3NlZCBzdWJtZW51IGRvZXNuJ3Qgc2VlZCBgaW5zdGFudFR5cGVgIGl0IHdvdWxkIG5ldmVyIGNsZWFyLiBSZWFkXG4gIC8vIGR1cmluZyB0aGUgZmlyc3QgcmVuZGVyIG9ubHkg4oCUIGNvbnN1bWVkIGV4Y2x1c2l2ZWx5IGJ5IGZpcnN0LXJlbmRlciBpbml0aWFsaXplcnMgYmVsb3dcbiAgLy8gKGB1c2VTdGF0ZWAgYW5kIHRoZSBzdG9yZSdzIGluaXRpYWwgc3RhdGUpLlxuICBjb25zdCBhbmltYXRlSW5pdGlhbE9wZW4gPSAob3BlblByb3AgPz8gZGVmYXVsdE9wZW4pICYmIHBhcmVudE1lbnVTdG9yZT8uc3RhdGUudHJhbnNpdGlvblN0YXR1cyA9PT0gJ3N0YXJ0aW5nJztcblxuICAvLyBNaXJyb3IgYW4gaW5zdGFudGx5LW9wZW5lZCBwYXJlbnQgKGUuZy4ga2V5Ym9hcmQgY2xpY2spIHNvIGBbZGF0YS1pbnN0YW50XWAgc3R5bGluZ1xuICAvLyBzdXBwcmVzc2VzIHRoZSBlbnRlciB0cmFuc2l0aW9uIG9uIGJvdGggcG9wdXBzIG9yIG5laXRoZXIuIENhcHR1cmVkIG9uY2Ug4oCUXG4gIC8vIGBhbmltYXRlSW5pdGlhbE9wZW5gIGlzIG9ubHkgbWVhbmluZ2Z1bCBkdXJpbmcgdGhlIGZpcnN0IHJlbmRlci5cbiAgY29uc3Qgc2VlZGVkSW5zdGFudFR5cGUgPSB1c2VSZWZXaXRoSW5pdCgoKSA9PiBhbmltYXRlSW5pdGlhbE9wZW4gPyBwYXJlbnRNZW51U3RvcmU/LnN0YXRlLmluc3RhbnRUeXBlIDogdW5kZWZpbmVkKS5jdXJyZW50O1xuICBjb25zdCBzdG9yZSA9IHVzZVJlZldpdGhJbml0KCgpID0+IHtcbiAgICBjb25zdCBtZW51U3RvcmUgPSBuZXcgTWVudVN0b3JlKHtcbiAgICAgIG9wZW46IGRlZmF1bHRPcGVuLFxuICAgICAgb3BlblByb3AsXG4gICAgICBhY3RpdmVUcmlnZ2VySWQ6IGRlZmF1bHRUcmlnZ2VySWRQcm9wLFxuICAgICAgdHJpZ2dlcklkUHJvcCxcbiAgICAgIHBhcmVudDogcGFyZW50RnJvbUNvbnRleHQsXG4gICAgICBkaXNhYmxlZDogZGlzYWJsZWRQcm9wLFxuICAgICAgaGlnaGxpZ2h0SXRlbU9uSG92ZXIsXG4gICAgICBtb2RhbDogcGFyZW50RnJvbUNvbnRleHQudHlwZSA9PT0gdW5kZWZpbmVkID8gbW9kYWxQcm9wIDogdW5kZWZpbmVkLFxuICAgICAgcm9vdElkLFxuICAgICAgaW5zdGFudFR5cGU6IHNlZWRlZEluc3RhbnRUeXBlXG4gICAgfSwgZmxvYXRpbmdJZCwgZmxvYXRpbmdQYXJlbnROb2RlSWRGcm9tQ29udGV4dCAhPSBudWxsKTtcbiAgICAvLyBBIHN0YWJsZSByZWYgb2JqZWN0LCBzbyBkZXNjZW5kYW50cyBjYW4gcmVhZCBpdCBkdXJpbmcgcmVuZGVyIGZyb20gdGhlIGZpcnN0IGNvbW1pdC5cbiAgICBtZW51U3RvcmUuY29udGV4dC52aXJ0dWFsRm9jdXNSZWYgPSB2aXJ0dWFsRm9jdXNSZWY7XG4gICAgcmV0dXJuIG1lbnVTdG9yZTtcbiAgfSkuY3VycmVudDtcbiAgc3RvcmUudXNlQ29udHJvbGxlZFByb3AoJ29wZW5Qcm9wJywgb3BlblByb3ApO1xuICBzdG9yZS51c2VDb250cm9sbGVkUHJvcCgndHJpZ2dlcklkUHJvcCcsIHRyaWdnZXJJZFByb3ApO1xuICBzdG9yZS51c2VDb250ZXh0Q2FsbGJhY2soJ29uT3BlbkNoYW5nZUNvbXBsZXRlJywgb25PcGVuQ2hhbmdlQ29tcGxldGUpO1xuICBjb25zdCBmbG9hdGluZ1RyZWVSb290ID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nVHJlZVJvb3QnKTtcbiAgY29uc3QgZmxvYXRpbmdOb2RlSWRGcm9tQ29udGV4dCA9IHVzZUZsb2F0aW5nTm9kZUlkKGZsb2F0aW5nVHJlZVJvb3QpO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3QgYWN0aXZlVHJpZ2dlckVsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZSgnYWN0aXZlVHJpZ2dlckVsZW1lbnQnKTtcbiAgY29uc3QgcG9zaXRpb25lckVsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZSgncG9zaXRpb25lckVsZW1lbnQnKTtcbiAgY29uc3QgaG92ZXJFbmFibGVkID0gc3RvcmUudXNlU3RhdGUoJ2hvdmVyRW5hYmxlZCcpO1xuICBjb25zdCBkaXNhYmxlZCA9IHN0b3JlLnVzZVN0YXRlKCdkaXNhYmxlZCcpO1xuICBjb25zdCBsYXN0T3BlbkNoYW5nZVJlYXNvbiA9IHN0b3JlLnVzZVN0YXRlKCdsYXN0T3BlbkNoYW5nZVJlYXNvbicpO1xuICBjb25zdCBwYXJlbnQgPSBzdG9yZS51c2VTdGF0ZSgncGFyZW50Jyk7XG4gIGNvbnN0IGFjdGl2ZUluZGV4ID0gc3RvcmUudXNlU3RhdGUoJ2FjdGl2ZUluZGV4Jyk7XG4gIGNvbnN0IGtleWJvYXJkT3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdrZXlib2FyZE9wZW4nKTtcbiAgY29uc3QgcGF5bG9hZCA9IHN0b3JlLnVzZVN0YXRlKCdwYXlsb2FkJyk7XG4gIGNvbnN0IGZsb2F0aW5nUGFyZW50Tm9kZUlkID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nUGFyZW50Tm9kZUlkJyk7XG4gIGNvbnN0IG9wZW5FdmVudFJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgYWxsb3dPdXRzaWRlUHJlc3NEaXNtaXNzYWxSZWYgPSBSZWFjdC51c2VSZWYocGFyZW50LnR5cGUgIT09ICdjb250ZXh0LW1lbnUnKTtcbiAgY29uc3QgYWxsb3dPdXRzaWRlUHJlc3NEaXNtaXNzYWxUaW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICBjb25zdCBhbGxvd1RvdWNoVG9DbG9zZVJlZiA9IFJlYWN0LnVzZVJlZih0cnVlKTtcbiAgY29uc3QgYWxsb3dUb3VjaFRvQ2xvc2VUaW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICBjb25zdCBuZXN0ZWQgPSBmbG9hdGluZ1BhcmVudE5vZGVJZCAhPSBudWxsO1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIGlmIChwYXJlbnQudHlwZSAhPT0gdW5kZWZpbmVkICYmIG1vZGFsUHJvcCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICBjb25zb2xlLndhcm4oJ0Jhc2UgVUk6IFRoZSBgbW9kYWxgIHByb3AgaXMgbm90IHN1cHBvcnRlZCBvbiBuZXN0ZWQgbWVudXMuIEl0IHdpbGwgYmUgaWdub3JlZC4nKTtcbiAgICB9XG4gIH1cbiAgY29uc3Qge1xuICAgIG9wZW5NZXRob2QsXG4gICAgdHJpZ2dlclByb3BzOiBpbnRlcmFjdGlvblR5cGVQcm9wc1xuICB9ID0gdXNlT3BlbkludGVyYWN0aW9uVHlwZShvcGVuKTtcbiAgc3RvcmUudXNlU3luY2VkVmFsdWVzKHtcbiAgICBkaXNhYmxlZDogZGlzYWJsZWRQcm9wLFxuICAgIGhpZ2hsaWdodEl0ZW1PbkhvdmVyLFxuICAgIG1vZGFsOiBwYXJlbnQudHlwZSA9PT0gdW5kZWZpbmVkID8gbW9kYWxQcm9wIDogdW5kZWZpbmVkLFxuICAgIG9wZW5NZXRob2QsXG4gICAgcm9vdElkXG4gIH0pO1xuICB1c2VJbXBsaWNpdEFjdGl2ZVRyaWdnZXIoc3RvcmUpO1xuICBjb25zdCB7XG4gICAgZm9yY2VVbm1vdW50LFxuICAgIHRyYW5zaXRpb25TdGF0dXNcbiAgfSA9IHVzZU9wZW5TdGF0ZVRyYW5zaXRpb25zKG9wZW4sIHN0b3JlLCAoKSA9PiB7XG4gICAgc3RvcmUuc2V0KCdhbGxvd01vdXNlRW50ZXInLCBmYWxzZSk7XG4gIH0sIGFuaW1hdGVJbml0aWFsT3Blbik7XG4gIGNvbnN0IHJ1bk9uY2VBbmltYXRpb25zRmluaXNoID0gdXNlQW5pbWF0aW9uc0ZpbmlzaGVkKHN0b3JlLmNvbnRleHQucG9wdXBSZWYpO1xuXG4gIC8vIEFuIGluaGVyaXRlZCBgaW5zdGFudFR5cGVgIGlzIG9ubHkgZm9yIHRoZSBpbml0aWFsIHJldmVhbC4gQSBsYXRlciBjb250cm9sbGVkIGBvcGVuYCBmbGlwXG4gIC8vIGJ5cGFzc2VzIGBzZXRPcGVuYCwgc28gbm90aGluZyB3b3VsZCByZXNldCBpdCBhbmQgYFtkYXRhLWluc3RhbnRdYCB3b3VsZCB3cm9uZ2x5IHN1cHByZXNzXG4gIC8vIGV2ZXJ5IHN1YnNlcXVlbnQgdHJhbnNpdGlvbi4gQ2xlYXIgaXQgb25jZSB0aGUgZW50ZXIgcGhhc2Ugc2V0dGxlcywgdW5sZXNzIGFuIGludGVyYWN0aXZlXG4gIC8vIG9wZW4gY2hhbmdlIGFscmVhZHkgcmVwbGFjZWQgaXQuXG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHNlZWRlZEluc3RhbnRUeXBlID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGNvbnN0IGNsZWFyU2VlZGVkSW5zdGFudFR5cGUgPSAoKSA9PiB7XG4gICAgICBpZiAoc3RvcmUuc3RhdGUuaW5zdGFudFR5cGUgPT09IHNlZWRlZEluc3RhbnRUeXBlKSB7XG4gICAgICAgIHN0b3JlLnNldCgnaW5zdGFudFR5cGUnLCB1bmRlZmluZWQpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICAvLyBBIGNvbnRyb2xsZWQgY2xvc2UgY2FuIGludGVycnVwdCB0aGUgaW5pdGlhbCBlbnRlciBiZWZvcmUgdGhlIGFuaW1hdGlvbnMtZmluaXNoZWQgY2xlYW51cFxuICAgIC8vIGJlbG93IGZpcmVzIChpdHMgYWJvcnQgY2FuY2VscyB0aGUgcGVuZGluZyBjYWxsYmFjaywgYW5kIGEgY2xvc2VkIHBvcHVwIHNjaGVkdWxlcyBubyBuZXdcbiAgICAvLyBvbmUpLiBOb3RoaW5nIGlzIGxlZnQgdG8gcHJvdGVjdCBvbmNlIGNsb3Npbmcgc3RhcnRzIOKAlCB0aGUgZXhpdCdzIHN1cHByZXNzaW9uIHdhcyBhbHJlYWR5XG4gICAgLy8gZGVjaWRlZCBhdCBpdHMgdHJpZ2dlciBjb21taXQg4oCUIHNvIGNsZWFyIG5vdyBvciB0aGUgbmV4dCByZW9wZW4gcmVuZGVycyBhIHN0YWxlXG4gICAgLy8gYFtkYXRhLWluc3RhbnRdYC5cbiAgICBpZiAoIW9wZW4pIHtcbiAgICAgIGNsZWFyU2VlZGVkSW5zdGFudFR5cGUoKTtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGlmICh0cmFuc2l0aW9uU3RhdHVzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgLy8gV2l0aCBubyBwb3B1cCBlbGVtZW50IChlLmcuIGl0cyBzdWJ0cmVlIGlzIHN1c3BlbmRlZCBvciB3YWl0aW5nIG9uIGRhdGEpLCB0aGVyZSBpcyBub1xuICAgIC8vIGVudGVyIHRyYW5zaXRpb24gdG8gcHJvdGVjdCwgYW5kIGB1c2VBbmltYXRpb25zRmluaXNoZWRgIHdvdWxkIHJldHVybiB3aXRob3V0IGludm9raW5nIHRoZVxuICAgIC8vIGNhbGxiYWNrIOKAlCBhIHJlZiBhc3NpZ25tZW50IGFsb25lIHdvdWxkIG5ldmVyIHJlcnVuIHRoaXMgZWZmZWN0LCBsZWF2aW5nIHRoZSBzZWVkIHN0dWNrLlxuICAgIC8vIENsZWFyIGltbWVkaWF0ZWx5OiBhIHBvcHVwIHRoYXQgYXBwZWFycyBhZnRlciB0aGUgcmV2ZWFsIHNldHRsZXMgaXMgcGFnZS1sb2FkLWxpa2UgY29udGVudC5cbiAgICBpZiAoc3RvcmUuY29udGV4dC5wb3B1cFJlZi5jdXJyZW50ID09IG51bGwpIHtcbiAgICAgIGNsZWFyU2VlZGVkSW5zdGFudFR5cGUoKTtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcbiAgICBydW5PbmNlQW5pbWF0aW9uc0ZpbmlzaChjbGVhclNlZWRlZEluc3RhbnRUeXBlLCBhYm9ydENvbnRyb2xsZXIuc2lnbmFsKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgYWJvcnRDb250cm9sbGVyLmFib3J0KCk7XG4gICAgfTtcbiAgfSwgW3NlZWRlZEluc3RhbnRUeXBlLCBvcGVuLCB0cmFuc2l0aW9uU3RhdHVzLCBydW5PbmNlQW5pbWF0aW9uc0ZpbmlzaCwgc3RvcmVdKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoY29udGV4dE1lbnVDb250ZXh0ICYmICFwYXJlbnRNZW51Um9vdENvbnRleHQpIHtcbiAgICAgIC8vIFRoaXMgaXMgYSBjb250ZXh0IG1lbnUgcm9vdC5cbiAgICAgIC8vIEl0IGRvZXNuJ3Qgc3VwcG9ydCBkZXRhY2hlZCB0cmlnZ2VycyB5ZXQsIHNvIHdlIGhhdmUgdG8gc3luYyB0aGUgcGFyZW50IGNvbnRleHQgbWFudWFsbHkuXG4gICAgICBzdG9yZS51cGRhdGUoe1xuICAgICAgICBwYXJlbnQ6IHtcbiAgICAgICAgICB0eXBlOiAnY29udGV4dC1tZW51JyxcbiAgICAgICAgICBjb250ZXh0OiBjb250ZXh0TWVudUNvbnRleHRcbiAgICAgICAgfSxcbiAgICAgICAgZmxvYXRpbmdOb2RlSWQ6IGZsb2F0aW5nTm9kZUlkRnJvbUNvbnRleHQsXG4gICAgICAgIGZsb2F0aW5nUGFyZW50Tm9kZUlkOiBmbG9hdGluZ1BhcmVudE5vZGVJZEZyb21Db250ZXh0XG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKHBhcmVudE1lbnVSb290Q29udGV4dCB8fCAhc3RvcmUuc2VsZWN0KCdhY3RpdmVUcmlnZ2VyRWxlbWVudCcpKSB7XG4gICAgICAvLyBXaXRob3V0IGFuIGFjdGl2ZSB0cmlnZ2VyLCB0aGUgcm9vdCBtdXN0IHN1cHBseSBpdHMgb3duIHRyZWUgSURzLlxuICAgICAgLy8gUmVhZCB0aGUgc3RvcmUgaGVyZTogYSB0cmlnZ2VyIGNhbiByZWdpc3RlciBhZnRlciByZW5kZXIsIGJlZm9yZSB0aGlzIGVmZmVjdC5cbiAgICAgIHN0b3JlLnVwZGF0ZSh7XG4gICAgICAgIGZsb2F0aW5nTm9kZUlkOiBmbG9hdGluZ05vZGVJZEZyb21Db250ZXh0LFxuICAgICAgICBmbG9hdGluZ1BhcmVudE5vZGVJZDogZmxvYXRpbmdQYXJlbnROb2RlSWRGcm9tQ29udGV4dFxuICAgICAgfSk7XG4gICAgfVxuICB9LCBbY29udGV4dE1lbnVDb250ZXh0LCBwYXJlbnRNZW51Um9vdENvbnRleHQsIGZsb2F0aW5nTm9kZUlkRnJvbUNvbnRleHQsIGZsb2F0aW5nUGFyZW50Tm9kZUlkRnJvbUNvbnRleHQsIGFjdGl2ZVRyaWdnZXJFbGVtZW50LCBzdG9yZV0pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghb3Blbikge1xuICAgICAgb3BlbkV2ZW50UmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIH1cbiAgICBpZiAocGFyZW50LnR5cGUgIT09ICdjb250ZXh0LW1lbnUnKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICghb3Blbikge1xuICAgICAgYWxsb3dPdXRzaWRlUHJlc3NEaXNtaXNzYWxUaW1lb3V0LmNsZWFyKCk7XG4gICAgICBhbGxvd091dHNpZGVQcmVzc0Rpc21pc3NhbFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gV2l0aCBgbW91c2Vkb3duYCBvdXRzaWRlIHByZXNzIGV2ZW50cyBhbmQgbG9uZyBwcmVzcyB0b3VjaCBpbnB1dCwgdGhlcmVcbiAgICAvLyBuZWVkcyB0byBiZSBhIGdyYWNlIHBlcmlvZCBhZnRlciBvcGVuaW5nIHRvIGVuc3VyZSB0aGUgZGlzbWlzc2FsIGV2ZW50XG4gICAgLy8gZG9lc24ndCBmaXJlIGltbWVkaWF0ZWx5IGFmdGVyIG9wZW4uXG4gICAgYWxsb3dPdXRzaWRlUHJlc3NEaXNtaXNzYWxUaW1lb3V0LnN0YXJ0KDUwMCwgKCkgPT4ge1xuICAgICAgYWxsb3dPdXRzaWRlUHJlc3NEaXNtaXNzYWxSZWYuY3VycmVudCA9IHRydWU7XG4gICAgfSk7XG4gIH0sIFthbGxvd091dHNpZGVQcmVzc0Rpc21pc3NhbFRpbWVvdXQsIG9wZW4sIHBhcmVudC50eXBlXSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuICYmICFob3ZlckVuYWJsZWQpIHtcbiAgICAgIHN0b3JlLnNldCgnaG92ZXJFbmFibGVkJywgdHJ1ZSk7XG4gICAgfVxuICB9LCBbb3BlbiwgaG92ZXJFbmFibGVkLCBzdG9yZV0pO1xuICBjb25zdCBzZXRPcGVuID0gdXNlU3RhYmxlQ2FsbGJhY2soKG5leHRPcGVuLCBldmVudERldGFpbHMpID0+IHtcbiAgICBjb25zdCByZWFzb24gPSBldmVudERldGFpbHMucmVhc29uO1xuXG4gICAgLy8gUmVhZCB0aGUgc3RvcmUgZGlyZWN0bHksIGFzIHJlbGF5ZWQgdHJlZSBldmVudHMgYW5kIHN0YWxlIGhvdmVyIHRpbWVycyBjYW4gcmVxdWVzdFxuICAgIC8vIGEgY2xvc2UgYWZ0ZXIgdGhlIHN0YXRlIGNoYW5nZWQgYnV0IGJlZm9yZSB0aGlzIGNvbXBvbmVudCByZS1yZW5kZXJlZC5cbiAgICBpZiAoIW5leHRPcGVuICYmICFzdG9yZS5zZWxlY3QoJ29wZW4nKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAob3BlbiA9PT0gbmV4dE9wZW4gJiYgZXZlbnREZXRhaWxzLnRyaWdnZXIgPT09IGFjdGl2ZVRyaWdnZXJFbGVtZW50ICYmIGxhc3RPcGVuQ2hhbmdlUmVhc29uID09PSByZWFzb24pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgc2hvdWxkUHJldmVudFVubW91bnRPbkNsb3NlID0gYXR0YWNoUHJldmVudFVubW91bnRPbkNsb3NlKGV2ZW50RGV0YWlscyk7XG5cbiAgICAvLyBEbyBub3QgaW1tZWRpYXRlbHkgcmVzZXQgdGhlIGFjdGl2ZVRyaWdnZXJJZCB0byBhbGxvd1xuICAgIC8vIGV4aXQgYW5pbWF0aW9ucyB0byBwbGF5IGFuZCBmb2N1cyB0byBiZSByZXR1cm5lZCBjb3JyZWN0bHkuXG4gICAgaWYgKCFuZXh0T3BlbiAmJiBldmVudERldGFpbHMudHJpZ2dlciA9PSBudWxsKSB7XG4gICAgICBldmVudERldGFpbHMudHJpZ2dlciA9IGFjdGl2ZVRyaWdnZXJFbGVtZW50ID8/IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgb25PcGVuQ2hhbmdlPy4obmV4dE9wZW4sIGV2ZW50RGV0YWlscyk7XG4gICAgaWYgKGV2ZW50RGV0YWlscy5pc0NhbmNlbGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHN0b3JlLnN0YXRlLmZsb2F0aW5nUm9vdENvbnRleHQuZGlzcGF0Y2hPcGVuQ2hhbmdlKG5leHRPcGVuLCBldmVudERldGFpbHMpO1xuICAgIGNvbnN0IG5hdGl2ZUV2ZW50ID0gZXZlbnREZXRhaWxzLmV2ZW50O1xuICAgIGlmIChuZXh0T3BlbiA9PT0gZmFsc2UgJiYgcmVhc29uICE9PSBSRUFTT05TLml0ZW1QcmVzcyAmJiBuYXRpdmVFdmVudD8udHlwZSA9PT0gJ2NsaWNrJyAmJiBuYXRpdmVFdmVudC5wb2ludGVyVHlwZSA9PT0gJ3RvdWNoJyAmJiAhYWxsb3dUb3VjaFRvQ2xvc2VSZWYuY3VycmVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIFByZXZlbnQgdGhlIG1lbnUgZnJvbSBjbG9zaW5nIG9uIG1vYmlsZSBkZXZpY2VzIHRoYXQgaGF2ZSBhIGRlbGF5ZWQgY2xpY2sgZXZlbnQuXG4gICAgLy8gSW4gc29tZSBjYXNlcyB0aGUgbWVudSwgd2hlbiB0YXBwZWQsIHdpbGwgZmlyZSB0aGUgZm9jdXMgZXZlbnQgZmlyc3QgYW5kIHRoZW4gdGhlIGNsaWNrIGV2ZW50LlxuICAgIC8vIFdpdGhvdXQgdGhpcyBndWFyZCwgdGhlIG1lbnUgd2lsbCBjbG9zZSBpbW1lZGlhdGVseSBhZnRlciBvcGVuaW5nLlxuICAgIGlmIChuZXh0T3BlbiAmJiByZWFzb24gPT09IFJFQVNPTlMudHJpZ2dlckZvY3VzKSB7XG4gICAgICBhbGxvd1RvdWNoVG9DbG9zZVJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICBhbGxvd1RvdWNoVG9DbG9zZVRpbWVvdXQuc3RhcnQoMzAwLCAoKSA9PiB7XG4gICAgICAgIGFsbG93VG91Y2hUb0Nsb3NlUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGFsbG93VG91Y2hUb0Nsb3NlUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgYWxsb3dUb3VjaFRvQ2xvc2VUaW1lb3V0LmNsZWFyKCk7XG4gICAgfVxuICAgIGNvbnN0IGlzRGlzbWlzc0Nsb3NlID0gIW5leHRPcGVuICYmIChyZWFzb24gPT09IFJFQVNPTlMuZXNjYXBlS2V5IHx8IHJlYXNvbiA9PSBudWxsKTtcbiAgICBvcGVuRXZlbnRSZWYuY3VycmVudCA9IGV2ZW50RGV0YWlscy5ldmVudDtcbiAgICBjb25zdCBwb3B1cE9wZW5TdGF0ZSA9IGNyZWF0ZVBvcHVwT3BlblN0YXRlKHN0b3JlLnN0YXRlLCBuZXh0T3BlbiwgZXZlbnREZXRhaWxzLnRyaWdnZXIsIHNob3VsZFByZXZlbnRVbm1vdW50T25DbG9zZSgpKTtcbiAgICBwb3B1cE9wZW5TdGF0ZS5vcGVuQ2hhbmdlUmVhc29uID0gcmVhc29uO1xuICAgIHBvcHVwT3BlblN0YXRlLmtleWJvYXJkT3BlbiA9IG5leHRPcGVuICYmIGlzS2V5Ym9hcmRPcGVuKHJlYXNvbiwgbmF0aXZlRXZlbnQpO1xuICAgIGlmIChwYXJlbnQudHlwZSA9PT0gJ21lbnViYXInICYmIChyZWFzb24gPT09IFJFQVNPTlMudHJpZ2dlckZvY3VzIHx8IHJlYXNvbiA9PT0gUkVBU09OUy5mb2N1c091dCB8fCByZWFzb24gPT09IFJFQVNPTlMudHJpZ2dlckhvdmVyIHx8IHJlYXNvbiA9PT0gUkVBU09OUy5saXN0TmF2aWdhdGlvbiB8fCByZWFzb24gPT09IFJFQVNPTlMuc2libGluZ09wZW4pKSB7XG4gICAgICBwb3B1cE9wZW5TdGF0ZS5pbnN0YW50VHlwZSA9ICdncm91cCc7XG4gICAgfSBlbHNlIGlmIChpc0tleWJvYXJkQ2xpY2socmVhc29uLCBuYXRpdmVFdmVudCkpIHtcbiAgICAgIHBvcHVwT3BlblN0YXRlLmluc3RhbnRUeXBlID0gJ2NsaWNrJztcbiAgICB9IGVsc2UgaWYgKGlzRGlzbWlzc0Nsb3NlKSB7XG4gICAgICBwb3B1cE9wZW5TdGF0ZS5pbnN0YW50VHlwZSA9ICdkaXNtaXNzJztcbiAgICB9IGVsc2Uge1xuICAgICAgcG9wdXBPcGVuU3RhdGUuaW5zdGFudFR5cGUgPSB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgLy8gYGluc3RhbnRUeXBlYCBtdXN0IGxhbmQgaW4gdGhlIHNhbWUgdXBkYXRlIHRoYXQgbW91bnRzIHRoZSBwb3B1cCBzdWJ0cmVlOiBpbiBSZWFjdCAxN1xuICAgIC8vIGxlZ2FjeSBtb2RlIHRoaXMgYHVwZGF0ZWAgY2FuIGZsdXNoIHN5bmNocm9ub3VzbHksIGFuZCBhIHNlcGFyYXRlIGBpbnN0YW50VHlwZWAgd3JpdGVcbiAgICAvLyBhZnRlciBpdCB3b3VsZCBjb21lIHRvbyBsYXRlIGZvciBhbiBpbml0aWFsbHkgb3BlbiBzdWJtZW51IHNlZWRpbmcgaXRzIG93biBzdG9yZSBmcm9tXG4gICAgLy8gdGhpcyBvbmUgZHVyaW5nIHRoYXQgZmx1c2guXG4gICAgc3RvcmUudXBkYXRlKHBvcHVwT3BlblN0YXRlKTtcbiAgfSk7XG4gIGNvbnN0IGZsb2F0aW5nUm9vdENvbnRleHQgPSB1c2VTeW5jZWRGbG9hdGluZ1Jvb3RDb250ZXh0KHtcbiAgICBwb3B1cFN0b3JlOiBzdG9yZSxcbiAgICBmbG9hdGluZ1Jvb3RDb250ZXh0OiBzdG9yZS5zdGF0ZS5mbG9hdGluZ1Jvb3RDb250ZXh0LFxuICAgIGZsb2F0aW5nSWQsXG4gICAgbmVzdGVkOiBmbG9hdGluZ1BhcmVudE5vZGVJZEZyb21Db250ZXh0ICE9IG51bGwsXG4gICAgb25PcGVuQ2hhbmdlOiBzZXRPcGVuXG4gIH0pO1xuICBjb25zdCBmbG9hdGluZ0V2ZW50cyA9IGZsb2F0aW5nUm9vdENvbnRleHQuY29udGV4dC5ldmVudHM7XG5cbiAgLy8gUmVnaXN0ZXJlZCBpbiBhIGxheW91dCBlZmZlY3QgKG5vdCBhIHBhc3NpdmUgb25lKSBzbyBgc2V0T3BlbmAgZW1pdHMgZnJvbSBpbXBlcmF0aXZlXG4gIC8vIGBNZW51SGFuZGxlLm9wZW4oKWAgY2FsbHMgbWFkZSBpbiB0aGUgc2FtZSBjb21taXQgdGhpcyByb290IG1vdW50cyDigJQgZS5nLiBmcm9tIGFub3RoZXIgbGF5b3V0XG4gIC8vIGVmZmVjdCBkdXJpbmcgYSByb3V0ZS10cmFuc2l0aW9uIGhhbmRvZmYg4oCUIGFyZSByZWNlaXZlZCBpbnN0ZWFkIG9mIGJlaW5nIHNpbGVudGx5IGRyb3BwZWQuXG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaGFuZGxlU2V0T3BlbkV2ZW50ID0gKHtcbiAgICAgIG9wZW46IG5leHRPcGVuLFxuICAgICAgZXZlbnREZXRhaWxzXG4gICAgfSkgPT4gc2V0T3BlbihuZXh0T3BlbiwgZXZlbnREZXRhaWxzKTtcbiAgICBmbG9hdGluZ0V2ZW50cy5vbignc2V0T3BlbicsIGhhbmRsZVNldE9wZW5FdmVudCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGZsb2F0aW5nRXZlbnRzPy5vZmYoJ3NldE9wZW4nLCBoYW5kbGVTZXRPcGVuRXZlbnQpO1xuICAgIH07XG4gIH0sIFtmbG9hdGluZ0V2ZW50cywgc2V0T3Blbl0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4gc3RvcmUuc3Vic2NyaWJlVG9QYXJlbnRNZW51KCksIFtzdG9yZV0pO1xuICBjb25zdCBoYW5kbGVJbXBlcmF0aXZlQ2xvc2UgPSBSZWFjdC51c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgc3RvcmUuc2V0T3BlbihmYWxzZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuaW1wZXJhdGl2ZUFjdGlvbikpO1xuICB9LCBbc3RvcmVdKTtcbiAgUmVhY3QudXNlSW1wZXJhdGl2ZUhhbmRsZShhY3Rpb25zUmVmLCAoKSA9PiAoe1xuICAgIHVubW91bnQ6IGZvcmNlVW5tb3VudCxcbiAgICBjbG9zZTogaGFuZGxlSW1wZXJhdGl2ZUNsb3NlXG4gIH0pLCBbZm9yY2VVbm1vdW50LCBoYW5kbGVJbXBlcmF0aXZlQ2xvc2VdKTtcbiAgbGV0IGN0eDtcbiAgaWYgKHBhcmVudC50eXBlID09PSAnY29udGV4dC1tZW51Jykge1xuICAgIGN0eCA9IHBhcmVudC5jb250ZXh0O1xuICB9XG4gIFJlYWN0LnVzZUltcGVyYXRpdmVIYW5kbGUoY3R4Py5wb3NpdGlvbmVyUmVmLCAoKSA9PiBwb3NpdGlvbmVyRWxlbWVudCwgW3Bvc2l0aW9uZXJFbGVtZW50XSk7XG4gIFJlYWN0LnVzZUltcGVyYXRpdmVIYW5kbGUoY3R4Py5hY3Rpb25zUmVmLCAoKSA9PiAoe1xuICAgIHNldE9wZW5cbiAgfSksIFtzZXRPcGVuXSk7XG4gIGNvbnN0IGRpc21pc3MgPSB1c2VEaXNtaXNzKGZsb2F0aW5nUm9vdENvbnRleHQsIHtcbiAgICBlbmFibGVkOiAhZGlzYWJsZWQsXG4gICAgYnViYmxlczoge1xuICAgICAgZXNjYXBlS2V5OiBjbG9zZVBhcmVudE9uRXNjICYmIHBhcmVudC50eXBlID09PSAnbWVudSdcbiAgICB9LFxuICAgIG91dHNpZGVQcmVzcygpIHtcbiAgICAgIGlmIChwYXJlbnQudHlwZSAhPT0gJ2NvbnRleHQtbWVudScgfHwgb3BlbkV2ZW50UmVmLmN1cnJlbnQ/LnR5cGUgPT09ICdjb250ZXh0bWVudScpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICByZXR1cm4gYWxsb3dPdXRzaWRlUHJlc3NEaXNtaXNzYWxSZWYuY3VycmVudDtcbiAgICB9LFxuICAgIGV4dGVybmFsVHJlZTogbmVzdGVkID8gZmxvYXRpbmdUcmVlUm9vdCA6IHVuZGVmaW5lZFxuICB9KTtcbiAgY29uc3QgZGlyZWN0aW9uID0gdXNlRGlyZWN0aW9uKCk7XG4gIGNvbnN0IGxpc3ROYXZpZ2F0aW9uID0gdXNlTGlzdE5hdmlnYXRpb24oZmxvYXRpbmdSb290Q29udGV4dCwge1xuICAgIGVuYWJsZWQ6ICFkaXNhYmxlZCxcbiAgICBsaXN0UmVmOiBzdG9yZS5jb250ZXh0Lml0ZW1Eb21FbGVtZW50cyxcbiAgICBhY3RpdmVJbmRleCxcbiAgICB2aXJ0dWFsOiB2aXJ0dWFsRm9jdXMsXG4gICAgbmVzdGVkOiBwYXJlbnQudHlwZSA9PT0gJ21lbnViYXInIHx8ICF2aXJ0dWFsRm9jdXMgJiYgcGFyZW50LnR5cGUgIT09IHVuZGVmaW5lZCxcbiAgICBwYXJlbnRPcmllbnRhdGlvbjogcGFyZW50LnR5cGUgPT09ICdtZW51YmFyJyA/IHBhcmVudC5jb250ZXh0Lm9yaWVudGF0aW9uIDogdW5kZWZpbmVkLFxuICAgIGxvb3BGb2N1cyxcbiAgICAvLyBGaWx0ZXJlZCBtZW51cyBrZWVwIERPTSBmb2N1cyBvbiB0aGUgaW5wdXQsIHdoaWxlIGtleWJvYXJkIGFuZCB2aXJ0dWFsIG9wZW5zIGluaXRpYWxseVxuICAgIC8vIGhpZ2hsaWdodCBhbiBpdGVtIGFzIG9yZGluYXJ5IG1lbnVzIGRvLiBUaGUgaW5wdXQgc3RheXMgaW4gdGhlIGFycm93LWtleSBsb29wIHVubGVzcyB0aGVcbiAgICAvLyBmaWx0ZXIgaGlnaGxpZ2h0cyBhdXRvbWF0aWNhbGx5LlxuICAgIGZvY3VzSXRlbU9uT3BlbjogdmlydHVhbEZvY3VzID8ga2V5Ym9hcmRPcGVuIDogdW5kZWZpbmVkLFxuICAgIGFsbG93RXNjYXBlOiB2aXJ0dWFsRm9jdXMgJiYgbG9vcEZvY3VzICYmIGFsbG93RXNjYXBlLFxuICAgIG9yaWVudGF0aW9uLFxuICAgIC8vIEEgdmlydHVhbC1mb2N1cyBsaXN0IGNhbiBuYXZpZ2F0ZSBvbiBlaXRoZXIgYXhpcywgYnV0IGl0cyB0cmlnZ2VyIGFsd2F5cyBvcGVucyBvbiB0aGVcbiAgICAvLyB2ZXJ0aWNhbCBvbmUuXG4gICAgdHJpZ2dlck9yaWVudGF0aW9uOiB2aXJ0dWFsRm9jdXMgPyAndmVydGljYWwnIDogb3JpZW50YXRpb24sXG4gICAgcnRsOiBkaXJlY3Rpb24gPT09ICdydGwnLFxuICAgIGRpc2FibGVkSW5kaWNlczogRU1QVFlfQVJSQVksXG4gICAgb25OYXZpZ2F0ZShuZXh0QWN0aXZlSW5kZXgsIGV2ZW50KSB7XG4gICAgICBzdG9yZS5zZXRBY3RpdmVJbmRleChuZXh0QWN0aXZlSW5kZXgsIGdldEhpZ2hsaWdodFJlYXNvbihldmVudCksIGV2ZW50Py5uYXRpdmVFdmVudCk7XG4gICAgfSxcbiAgICAvLyBBIHZpcnR1YWwtZm9jdXMgc3VibWVudSdzIGtleWJvYXJkIG9wZW5pbmcgaXMgb3JjaGVzdHJhdGVkIGJ5IGl0cyBuYXZpZ2F0aW9uIHdyYXBwZXIgYmFzZWRcbiAgICAvLyBvbiBib3RoIG1lbnVzJyBvcmllbnRhdGlvbnM7IHRoZSBnZW5lcmljIGFycm93LWtleSBvcGVuaW5nIHdvdWxkIGFsc28gcmVhY3QgdG8gdGhlIHBhcmVudCdzXG4gICAgLy8gZm9yd2FyZGVkIGNyb3NzLWF4aXMga2V5cyB3aGlsZSBjbG9zZWQuXG4gICAgb3Blbk9uQXJyb3dLZXlEb3duOiBwYXJlbnQudHlwZSAhPT0gJ2NvbnRleHQtbWVudScgJiYgISh2aXJ0dWFsRm9jdXMgJiYgaXNTdWJtZW51KSxcbiAgICBleHRlcm5hbFRyZWU6ICF2aXJ0dWFsRm9jdXMgJiYgbmVzdGVkID8gZmxvYXRpbmdUcmVlUm9vdCA6IHVuZGVmaW5lZCxcbiAgICBuZXN0ZWRSZXR1cm5Gb2N1c1JlZjogcGFyZW50TWVudVN0b3JlPy5jb250ZXh0LnZpcnR1YWxGb2N1c1JlZixcbiAgICBmb2N1c0l0ZW1PbkhvdmVyOiBoaWdobGlnaHRJdGVtT25Ib3ZlcixcbiAgICByZXNldE9uUG9pbnRlckxlYXZlXG4gIH0pO1xuICBjb25zdCBvblR5cGluZyA9IFJlYWN0LnVzZUNhbGxiYWNrKG5leHRUeXBpbmcgPT4ge1xuICAgIHN0b3JlLmNvbnRleHQudHlwaW5nUmVmLmN1cnJlbnQgPSBuZXh0VHlwaW5nO1xuICB9LCBbc3RvcmVdKTtcbiAgY29uc3QgdHlwZWFoZWFkID0gdXNlVHlwZWFoZWFkKGZsb2F0aW5nUm9vdENvbnRleHQsIHtcbiAgICAvLyBVbmRlciB2aXJ0dWFsIGZvY3VzIHRoZSBpbnB1dCBvd25zIHR5cGluZywgc28gdHlwZWFoZWFkIHdvdWxkIHJhY2UgdGhlIGZpbHRlciBxdWVyeS5cbiAgICBlbmFibGVkOiAhZGlzYWJsZWQgJiYgIXZpcnR1YWxGb2N1cyxcbiAgICBsaXN0UmVmOiBzdG9yZS5jb250ZXh0Lml0ZW1MYWJlbHMsXG4gICAgZWxlbWVudHNSZWY6IHN0b3JlLmNvbnRleHQuaXRlbURvbUVsZW1lbnRzLFxuICAgIGFjdGl2ZUluZGV4LFxuICAgIHJlc2V0TXM6IFRZUEVBSEVBRF9SRVNFVF9NUyxcbiAgICBvbk1hdGNoOiAoaW5kZXgsIGV2ZW50KSA9PiB7XG4gICAgICBpZiAob3BlbiAmJiBpbmRleCAhPT0gYWN0aXZlSW5kZXgpIHtcbiAgICAgICAgc3RvcmUuc2V0QWN0aXZlSW5kZXgoaW5kZXgsIFJFQVNPTlMua2V5Ym9hcmQsIGV2ZW50Lm5hdGl2ZUV2ZW50KTtcbiAgICAgIH1cbiAgICB9LFxuICAgIG9uVHlwaW5nXG4gIH0pO1xuICBjb25zdCBvbkl0ZW1IaWdobGlnaHRlZCA9IHVzZVN0YWJsZUNhbGxiYWNrKG9uSXRlbUhpZ2hsaWdodGVkUHJvcCk7XG4gIGNvbnN0IGxhc3RIaWdobGlnaHRJbmRleFJlZiA9IFJlYWN0LnVzZVJlZigtMSk7XG5cbiAgLy8gUnVucyB3aGVuIGBhY3RpdmVJbmRleGAgY29tbWl0cyBhbmQgYWdhaW4gd2hlbiB0aGUgaXRlbSByZWdpc3RyeSBzZXR0bGVzLCBzaW5jZSBhbiBpbmRleFxuICAvLyBjYW4gY29tZSB0byBwb2ludCBhdCBhIGRpZmZlcmVudCBlbGVtZW50IHdoaWxlIGl0cyB2YWx1ZSBzdGF5cyB0aGUgc2FtZS5cbiAgY29uc3Qgc3luY0hpZ2hsaWdodGVkSXRlbSA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IHtcbiAgICBjb25zdCBpbmRleCA9IHN0b3JlLnN0YXRlLmFjdGl2ZUluZGV4O1xuICAgIGNvbnN0IGl0ZW0gPSBpbmRleCA9PT0gbnVsbCA/IHVuZGVmaW5lZCA6IHN0b3JlLmNvbnRleHQuaXRlbURvbUVsZW1lbnRzLmN1cnJlbnRbaW5kZXhdID8/IHVuZGVmaW5lZDtcbiAgICAvLyBBbiBpdGVtIHJlbW92ZWQgaW4gdGhpcyBjb21taXQgc3RheXMgcmVnaXN0ZXJlZCB1bnRpbCB0aGUgbGlzdCBmbHVzaGVzLCB3aGljaCBjYWxscyBiYWNrXG4gICAgLy8gaGVyZSB3aXRoIHRoZSBzZXR0bGVkIHJlZ2lzdHJ5LlxuICAgIGlmIChpdGVtPy5pc0Nvbm5lY3RlZCA9PT0gZmFsc2UpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgaXRlbUluZGV4ID0gaXRlbSA9PT0gdW5kZWZpbmVkID8gLTEgOiBpbmRleDtcbiAgICBpZiAobGFzdEhpZ2hsaWdodEluZGV4UmVmLmN1cnJlbnQgPT09IGl0ZW1JbmRleCAmJiBzdG9yZS5jb250ZXh0LnJlcG9ydGVkSXRlbSA9PT0gaXRlbSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBsYXN0SGlnaGxpZ2h0SW5kZXhSZWYuY3VycmVudCA9IGl0ZW1JbmRleDtcbiAgICBzdG9yZS5jb250ZXh0LnJlcG9ydGVkSXRlbSA9IGl0ZW07XG4gICAgLy8gT25seSB2aXJ0dWFsIGZvY3VzIHJlbmRlcnMgZnJvbSB0aGUgaGlnaGxpZ2h0ZWQgZWxlbWVudC4gUHVibGlzaGluZyBpdCBpbiBldmVyeSBtZW51IHdvdWxkXG4gICAgLy8gbm90aWZ5IGVhY2ggaXRlbSdzIHN1YnNjcmlwdGlvbiBvbiBldmVyeSBoaWdobGlnaHQgY2hhbmdlLlxuICAgIGlmICh2aXJ0dWFsRm9jdXMpIHtcbiAgICAgIHN0b3JlLnNldCgnaGlnaGxpZ2h0ZWRJdGVtJywgaXRlbSk7XG4gICAgfVxuICAgIC8vIFRoZSB0YWcgbGVmdCBieSB0aGUgd3JpdGUgdGhhdCBwcm9kdWNlZCB0aGlzIGNvbW1pdHRlZCB2YWx1ZS5cbiAgICBjb25zdCB7XG4gICAgICBoaWdobGlnaHRSZWFzb24sXG4gICAgICBoaWdobGlnaHRFdmVudFxuICAgIH0gPSBzdG9yZS5jb250ZXh0O1xuICAgIHN0b3JlLmNvbnRleHQuaGlnaGxpZ2h0UmVhc29uID0gUkVBU09OUy5ub25lO1xuICAgIHN0b3JlLmNvbnRleHQuaGlnaGxpZ2h0RXZlbnQgPSB1bmRlZmluZWQ7XG4gICAgaWYgKCFvbkl0ZW1IaWdobGlnaHRlZFByb3ApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgb25JdGVtSGlnaGxpZ2h0ZWQoaXRlbSwgY3JlYXRlR2VuZXJpY0V2ZW50RGV0YWlscyhoaWdobGlnaHRSZWFzb24sIGhpZ2hsaWdodEV2ZW50LCB7XG4gICAgICBsYWJlbDogaXRlbSA9PT0gdW5kZWZpbmVkID8gdW5kZWZpbmVkIDogc3RvcmUuY29udGV4dC5pdGVtTGFiZWxzLmN1cnJlbnRbaXRlbUluZGV4XSA/PyB1bmRlZmluZWRcbiAgICB9KSk7XG4gIH0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIHN5bmNIaWdobGlnaHRlZEl0ZW0oKTtcbiAgfSwgW2FjdGl2ZUluZGV4LCBzeW5jSGlnaGxpZ2h0ZWRJdGVtXSk7XG5cbiAgLy8gVW5kZXIgdmlydHVhbCBmb2N1cyBhbiBlbGVtZW50IGluc2lkZSB0aGUgcG9wdXAgaG9sZHMgcmVhbCBmb2N1cywgc28gaXQgdGFrZXMgdGhlXG4gIC8vIG5hdmlnYXRpb24ncyByZWZlcmVuY2UgcHJvcHMgKGBhcmlhLWFjdGl2ZWRlc2NlbmRhbnRgIGFuZCB0aGUga2V5IGhhbmRsaW5nKSBhbmQgdGhlIHRyaWdnZXJcbiAgLy8ga2VlcHMgb25seSB0aGUgcHJvcHMgdGhhdCBvcGVuIHRoZSBtZW51LlxuICBjb25zdCBvcGVuVHJpZ2dlclByb3BzID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgaWYgKCF2aXJ0dWFsRm9jdXMpIHtcbiAgICAgIHJldHVybiBsaXN0TmF2aWdhdGlvbi5yZWZlcmVuY2U7XG4gICAgfVxuICAgIGlmICghbGlzdE5hdmlnYXRpb24udHJpZ2dlcikge1xuICAgICAgcmV0dXJuIEVNUFRZX09CSkVDVDtcbiAgICB9XG4gICAgLy8gRm9jdXNpbmcgdGhlIHRyaWdnZXIgd2hpbGUgdGhlIG1lbnUgaXMgb3BlbiBtdXN0IG5vdCBzZWVkIHRoZSB2aXJ0dWFsIGhpZ2hsaWdodC4gVGhpcyBjYW5cbiAgICAvLyBoYXBwZW4gYmVmb3JlIGEgcG9pbnRlciBwcmVzcyBjbG9zZXMgdGhlIG1lbnUgaW4gU2FmYXJpLlxuICAgIGNvbnN0IHtcbiAgICAgIG9uRm9jdXMsXG4gICAgICAuLi5yZXN0XG4gICAgfSA9IGxpc3ROYXZpZ2F0aW9uLnRyaWdnZXI7XG4gICAgcmV0dXJuIHJlc3Q7XG4gIH0sIFt2aXJ0dWFsRm9jdXMsIGxpc3ROYXZpZ2F0aW9uLnJlZmVyZW5jZSwgbGlzdE5hdmlnYXRpb24udHJpZ2dlcl0pO1xuICBzdG9yZS51c2VTeW5jZWRWYWx1ZSgnaW5wdXRQcm9wcycsIHZpcnR1YWxGb2N1cyA/IGxpc3ROYXZpZ2F0aW9uLnJlZmVyZW5jZSA/PyBFTVBUWV9PQkpFQ1QgOiBFTVBUWV9PQkpFQ1QpO1xuICBjb25zdCBhY3RpdmVUcmlnZ2VyUHJvcHMgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBtZXJnZWRQcm9wcyA9IG1lcmdlUHJvcHModHlwZWFoZWFkLnJlZmVyZW5jZSwgb3BlblRyaWdnZXJQcm9wcywgZGlzbWlzcy5yZWZlcmVuY2UsIHtcbiAgICAgIG9uTW91c2VNb3ZlKCkge1xuICAgICAgICBzdG9yZS5zZXQoJ2FsbG93TW91c2VFbnRlcicsIHRydWUpO1xuICAgICAgfVxuICAgIH0sIGludGVyYWN0aW9uVHlwZVByb3BzKTtcbiAgICBtZXJnZWRQcm9wc1snYXJpYS1oYXNwb3B1cCddID0gJ21lbnUnO1xuICAgIG1lcmdlZFByb3BzWydhcmlhLWV4cGFuZGVkJ10gPSBvcGVuO1xuICAgIHJldHVybiBtZXJnZWRQcm9wcztcbiAgfSwgW3N0b3JlLCB0eXBlYWhlYWQucmVmZXJlbmNlLCBvcGVuVHJpZ2dlclByb3BzLCBkaXNtaXNzLnJlZmVyZW5jZSwgaW50ZXJhY3Rpb25UeXBlUHJvcHMsIG9wZW5dKTtcbiAgY29uc3QgaW5hY3RpdmVUcmlnZ2VyUHJvcHMgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICBjb25zdCBtZXJnZWRQcm9wcyA9IG1lcmdlUHJvcHMobGlzdE5hdmlnYXRpb24udHJpZ2dlciwgZGlzbWlzcy50cmlnZ2VyLCBpbnRlcmFjdGlvblR5cGVQcm9wcyk7XG4gICAgbWVyZ2VkUHJvcHNbJ2FyaWEtaGFzcG9wdXAnXSA9ICdtZW51JztcbiAgICBtZXJnZWRQcm9wc1snYXJpYS1leHBhbmRlZCddID0gZmFsc2U7XG4gICAgcmV0dXJuIG1lcmdlZFByb3BzO1xuICB9LCBbbGlzdE5hdmlnYXRpb24udHJpZ2dlciwgZGlzbWlzcy50cmlnZ2VyLCBpbnRlcmFjdGlvblR5cGVQcm9wc10pO1xuXG4gIC8vIFRoZSBpbml0aWFsIHJlbmRlciBoYXMgbm8gc3RvcmUgc3Vic2NyaWJlcnMgeWV0LiBTZWVkIHRoZXNlIHByb3BzIGJlZm9yZSB0cmlnZ2VycyByZW5kZXIgc29cbiAgLy8gdGhlIHN5bmNocm9uaXphdGlvbiBlZmZlY3QgYmVsb3cgZG9lc24ndCBtYWtlIGV2ZXJ5IHRyaWdnZXIgcmVuZGVyIHR3aWNlIGluIHRoZSBmaXJzdCBjb21taXQuXG4gIHVzZVJlZldpdGhJbml0KCgpID0+IHtcbiAgICBzdG9yZS51cGRhdGUoe1xuICAgICAgaW5hY3RpdmVUcmlnZ2VyUHJvcHNcbiAgICB9KTtcbiAgICByZXR1cm4gbnVsbDtcbiAgfSk7XG4gIGNvbnN0IHBvcHVwUHJvcHMgPSBSZWFjdC51c2VNZW1vKCgpID0+IG1lcmdlUHJvcHMoRk9DVVNBQkxFX1BPUFVQX1BST1BTLCB7XG4gICAgb25Nb3VzZU1vdmUoKSB7XG4gICAgICBzdG9yZS5zZXQoJ2FsbG93TW91c2VFbnRlcicsIHRydWUpO1xuICAgICAgaWYgKHBhcmVudC50eXBlID09PSAnbWVudScpIHtcbiAgICAgICAgc3RvcmUuc2V0KCdob3ZlckVuYWJsZWQnLCBmYWxzZSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBvbkNsaWNrKCkge1xuICAgICAgaWYgKHN0b3JlLnNlbGVjdCgnaG92ZXJFbmFibGVkJykpIHtcbiAgICAgICAgc3RvcmUuc2V0KCdob3ZlckVuYWJsZWQnLCBmYWxzZSk7XG4gICAgICB9XG4gICAgfSxcbiAgICBvbktleURvd24oZXZlbnQpIHtcbiAgICAgIC8vIFRoZSBNZW51YmFyJ3MgQ29tcG9zaXRlUm9vdCBjYXB0dXJlcyBrZXlib2FyZCBldmVudHMgdmlhXG4gICAgICAvLyBldmVudCBkZWxlZ2F0aW9uLiBUaGlzIHdvcmtzIHdlbGwgd2hlbiBNZW51LlJvb3QgaXMgbmVzdGVkIGluc2lkZSBNZW51YmFyLFxuICAgICAgLy8gYnV0IHdpdGggZGV0YWNoZWQgdHJpZ2dlcnMgd2UgbmVlZCB0byBtYW51YWxseSBmb3J3YXJkIHRoZSBldmVudCB0byB0aGUgQ29tcG9zaXRlUm9vdC5cbiAgICAgIGNvbnN0IHJlbGF5ID0gc3RvcmUuc2VsZWN0KCdrZXlib2FyZEV2ZW50UmVsYXknKTtcbiAgICAgIGlmIChyZWxheSAmJiAhZXZlbnQuaXNQcm9wYWdhdGlvblN0b3BwZWQoKSkge1xuICAgICAgICByZWxheShldmVudCk7XG4gICAgICB9XG4gICAgfVxuICB9LCB0eXBlYWhlYWQuZmxvYXRpbmcsIGxpc3ROYXZpZ2F0aW9uLmZsb2F0aW5nLCBkaXNtaXNzLmZsb2F0aW5nKSwgW3BhcmVudC50eXBlLCBzdG9yZSwgdHlwZWFoZWFkLmZsb2F0aW5nLCBsaXN0TmF2aWdhdGlvbi5mbG9hdGluZywgZGlzbWlzcy5mbG9hdGluZ10pO1xuICBjb25zdCBpdGVtUHJvcHMgPSBsaXN0TmF2aWdhdGlvbi5pdGVtID8/IEVNUFRZX09CSkVDVDtcbiAgdXNlUG9wdXBJbnRlcmFjdGlvblByb3BzKHN0b3JlLCB7XG4gICAgZmxvYXRpbmdSb290Q29udGV4dCxcbiAgICBhY3RpdmVUcmlnZ2VyUHJvcHMsXG4gICAgaW5hY3RpdmVUcmlnZ2VyUHJvcHMsXG4gICAgcG9wdXBQcm9wcyxcbiAgICBpdGVtUHJvcHNcbiAgfSk7XG4gIGNvbnN0IGNvbnRleHQgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgc3RvcmUsXG4gICAgcGFyZW50OiBwYXJlbnRGcm9tQ29udGV4dCxcbiAgICBvcmllbnRhdGlvbixcbiAgICBsb29wRm9jdXMsXG4gICAgYWxsb3dFc2NhcGUsXG4gICAgZGVmYXVsdEZsb2F0aW5nSWQsXG4gICAgc2V0UmVuZGVyZWRGbG9hdGluZ0lkLFxuICAgIHZpcnR1YWxGb2N1cyxcbiAgICBwYXJlbnRWaXJ0dWFsRm9jdXMsXG4gICAgc3luY0hpZ2hsaWdodGVkSXRlbVxuICB9KSwgW3N0b3JlLCBwYXJlbnRGcm9tQ29udGV4dCwgb3JpZW50YXRpb24sIGxvb3BGb2N1cywgYWxsb3dFc2NhcGUsIGRlZmF1bHRGbG9hdGluZ0lkLCB2aXJ0dWFsRm9jdXMsIHBhcmVudFZpcnR1YWxGb2N1cywgc3luY0hpZ2hsaWdodGVkSXRlbV0pO1xuICBjb25zdCByZW5kZXJlZENoaWxkcmVuID0gdHlwZW9mIGNoaWxkcmVuID09PSAnZnVuY3Rpb24nID8gY2hpbGRyZW4oe1xuICAgIHBheWxvYWRcbiAgfSkgOiBjaGlsZHJlbjtcbiAgbGV0IGNvbnRlbnQgPSAvKiNfX1BVUkVfXyovX2pzeHMoTWVudVJvb3RDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IGNvbnRleHQsXG4gICAgY2hpbGRyZW46IFtoYW5kbGUgJiYgLyojX19QVVJFX18qL19qc3goUG9wdXBIYW5kbGVBdHRhY2htZW50LCB7XG4gICAgICBoYW5kbGU6IGhhbmRsZSxcbiAgICAgIHN0b3JlOiBzdG9yZVxuICAgIH0pLCByZW5kZXJlZENoaWxkcmVuXVxuICB9KTtcbiAgaWYgKHBhcmVudC50eXBlID09PSB1bmRlZmluZWQgfHwgcGFyZW50LnR5cGUgPT09ICdjb250ZXh0LW1lbnUnKSB7XG4gICAgLy8gc2V0IHVwIGEgRmxvYXRpbmdUcmVlIHRvIHByb3ZpZGUgdGhlIGNvbnRleHQgdG8gbmVzdGVkIG1lbnVzXG4gICAgY29udGVudCA9IC8qI19fUFVSRV9fKi9fanN4KEZsb2F0aW5nVHJlZSwge1xuICAgICAgZXh0ZXJuYWxUcmVlOiBmbG9hdGluZ1RyZWVSb290LFxuICAgICAgY2hpbGRyZW46IGNvbnRlbnRcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gY29udGVudDtcbn0pO1xuXG4vKipcbiAqIEdyb3VwcyBhbGwgcGFydHMgb2YgdGhlIG1lbnUuXG4gKiBEb2Vzbid0IHJlbmRlciBpdHMgb3duIEhUTUwgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBNZW51XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvbWVudSlcbiAqL1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgTWVudVJvb3RJbnRlcm5hbC5kaXNwbGF5TmFtZSA9IFwiTWVudVJvb3RJbnRlcm5hbFwiO1xuZXhwb3J0IGZ1bmN0aW9uIE1lbnVSb290KHByb3BzKSB7XG4gIGNvbnN0IGZpbHRlclByb3ZpZGVyID0gUmVhY3QudXNlQ29udGV4dChNZW51RmlsdGVyUHJvdmlkZXJDb250ZXh0KTtcbiAgaWYgKGZpbHRlclByb3ZpZGVyID09PSBudWxsKSB7XG4gICAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KE1lbnVSb290SW50ZXJuYWwsIHtcbiAgICAgIC4uLnByb3BzXG4gICAgfSk7XG4gIH1cbiAgY29uc3QgRmlsdGVyUm9vdCA9IGZpbHRlclByb3ZpZGVyLlJvb3Q7XG4gIHJldHVybiAoXG4gICAgLyojX19QVVJFX18qL1xuICAgIC8vIFRoZSByb290IGNvbnN1bWVzIGl0cyBwcm92aWRlciBzbyBhIHBsYWluIHN1Ym1lbnUgaW5zaWRlIGRvZXNuJ3QgaW5oZXJpdCBpdC5cbiAgICBfanN4KE1lbnVGaWx0ZXJQcm92aWRlckNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICAgIHZhbHVlOiBudWxsLFxuICAgICAgY2hpbGRyZW46IC8qI19fUFVSRV9fKi9fanN4KEZpbHRlclJvb3QsIHtcbiAgICAgICAgLi4uZmlsdGVyUHJvdmlkZXIub3B0aW9ucyxcbiAgICAgICAgLi4ucHJvcHNcbiAgICAgIH0pXG4gICAgfSlcbiAgKTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IE1lbnVSb290SW50ZXJuYWwgfSBmcm9tIFwiLi4vcm9vdC9NZW51Um9vdC5tanNcIjtcbmltcG9ydCB7IHVzZU1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L01lbnVSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IE1lbnVTdWJtZW51Um9vdENvbnRleHQgfSBmcm9tIFwiLi9NZW51U3VibWVudVJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgTWVudUZpbHRlclByb3ZpZGVyQ29udGV4dCB9IGZyb20gXCIuLi9maWx0ZXItcHJvdmlkZXIvTWVudUZpbHRlclByb3ZpZGVyQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgeyB1c2VNZW51U3VibWVudVJvb3RDb250ZXh0IH0gZnJvbSBcIi4vTWVudVN1Ym1lbnVSb290Q29udGV4dC5tanNcIjtcbmNvbnN0IEVNUFRZX1NVQk1FTlVfUk9PVF9DT05URVhUID0ge307XG5cbi8qKlxuICogR3JvdXBzIGFsbCBwYXJ0cyBvZiBhIHN1Ym1lbnUuXG4gKiBEb2Vzbid0IHJlbmRlciBpdHMgb3duIEhUTUwgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBNZW51XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvbWVudSlcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIE1lbnVTdWJtZW51Um9vdChwcm9wcykge1xuICAvLyBUaHJvd3Mgd2hlbiB0aGUgc3VibWVudSBpc24ndCBpbnNpZGUgYSBtZW51LlxuICB1c2VNZW51Um9vdENvbnRleHQoKTtcbiAgY29uc3QgZmlsdGVyUHJvdmlkZXIgPSBSZWFjdC51c2VDb250ZXh0KE1lbnVGaWx0ZXJQcm92aWRlckNvbnRleHQpO1xuICBpZiAoZmlsdGVyUHJvdmlkZXIgIT09IG51bGwpIHtcbiAgICBjb25zdCBGaWx0ZXJTdWJtZW51Um9vdCA9IGZpbHRlclByb3ZpZGVyLlN1Ym1lbnVSb290O1xuICAgIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChNZW51RmlsdGVyUHJvdmlkZXJDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgICB2YWx1ZTogbnVsbCxcbiAgICAgIGNoaWxkcmVuOiAvKiNfX1BVUkVfXyovX2pzeChGaWx0ZXJTdWJtZW51Um9vdCwge1xuICAgICAgICAuLi5maWx0ZXJQcm92aWRlci5vcHRpb25zLFxuICAgICAgICAuLi5wcm9wc1xuICAgICAgfSlcbiAgICB9KTtcbiAgfVxuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goTWVudVN1Ym1lbnVSb290Q29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBFTVBUWV9TVUJNRU5VX1JPT1RfQ09OVEVYVCxcbiAgICBjaGlsZHJlbjogLyojX19QVVJFX18qL19qc3goTWVudVJvb3RJbnRlcm5hbCwge1xuICAgICAgLi4ucHJvcHMsXG4gICAgICBpc1N1Ym1lbnU6IHRydWVcbiAgICB9KVxuICB9KTtcbn0iLCJpbXBvcnQgeyBnZXRQYXJlbnROb2RlLCBpc0hUTUxFbGVtZW50LCBpc0xhc3RUcmF2ZXJzYWJsZU5vZGUgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmV4cG9ydCBmdW5jdGlvbiBmaW5kUm9vdE93bmVySWQobm9kZSkge1xuICBpZiAoaXNIVE1MRWxlbWVudChub2RlKSAmJiBub2RlLmhhc0F0dHJpYnV0ZSgnZGF0YS1yb290b3duZXJpZCcpKSB7XG4gICAgcmV0dXJuIG5vZGUuZ2V0QXR0cmlidXRlKCdkYXRhLXJvb3Rvd25lcmlkJyk7XG4gIH1cbiAgaWYgKGlzTGFzdFRyYXZlcnNhYmxlTm9kZShub2RlKSkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIGZpbmRSb290T3duZXJJZChnZXRQYXJlbnROb2RlKG5vZGUpKTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0RE9NIGZyb20gJ3JlYWN0LWRvbSc7XG5pbXBvcnQgeyBnZXRUYWJiYWJsZU5lYXJFbGVtZW50LCBpc091dHNpZGVFdmVudCB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC91dGlscy5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY3JlYXRlQmFzZVVJRXZlbnREZXRhaWxzLm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcblxuLyoqXG4gKiBNaW5pbWFsIHN0b3JlIGludGVyZmFjZSByZXF1aXJlZCBieSB0aGUgZm9jdXMgZ3VhcmQgaG9vay5cbiAqIEJvdGggUG9wb3ZlclN0b3JlIGFuZCBNZW51U3RvcmUgc2F0aXNmeSB0aGlzIGludGVyZmFjZS5cbiAqL1xuXG4vKipcbiAqIFByb3ZpZGVzIGZvY3VzIGd1YXJkIGhhbmRsZXJzIGZvciBwb3B1cCB0cmlnZ2VycyAoUG9wb3ZlciwgTWVudSkuXG4gKlxuICogV2hlbiB0aGUgcG9wdXAgaXMgb3BlbiwgaW52aXNpYmxlIGZvY3VzIGd1YXJkIGVsZW1lbnRzIGFyZSBwbGFjZWQgYmVmb3JlIGFuZCBhZnRlclxuICogdGhlIHRyaWdnZXIuIFRoZXNlIGhhbmRsZXJzIGNsb3NlIHRoZSBwb3B1cCBhbmQgbW92ZSBmb2N1cyB0byB0aGUgYXBwcm9wcmlhdGVcbiAqIHRhYmJhYmxlIGVsZW1lbnQgd2hlbiB0aGUgZ3VhcmRzIHJlY2VpdmUgZm9jdXMgKGkuZS4gd2hlbiB0aGUgdXNlciB0YWJzIG91dCkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VUcmlnZ2VyRm9jdXNHdWFyZHMoc3RvcmUsIHRyaWdnZXJFbGVtZW50UmVmKSB7XG4gIGZ1bmN0aW9uIGNsb3NlQW5kRm9jdXMoZXZlbnQsIGRpcmVjdGlvbiwgcG9zaXRpb25lckVsZW1lbnQpIHtcbiAgICBjb25zdCBndWFyZCA9IGV2ZW50LmN1cnJlbnRUYXJnZXQ7XG4gICAgUmVhY3RET00uZmx1c2hTeW5jKCgpID0+IHtcbiAgICAgIHN0b3JlLnNldE9wZW4oZmFsc2UsIGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLmZvY3VzT3V0LCBldmVudC5uYXRpdmVFdmVudCwgZ3VhcmQpKTtcbiAgICB9KTtcblxuICAgIC8vIFRoZSBjbG9zZSBjYWxsYmFjayBtYXkgY2hhbmdlIHRoZSB0YWIgb3JkZXIuIFJlc29sdmUgaXQgYWZ0ZXIgdGhlIGZsdXNoLCB1c2luZ1xuICAgIC8vIHRoZSB0cmlnZ2VyIGFzIHRoZSBhbmNob3IgaWYgdGhlIGd1YXJkIHVubW91bnRlZCwgZXZlbiB3aGVuIGl0cyB0YWJJbmRleCBpcyAtMS5cbiAgICBnZXRUYWJiYWJsZU5lYXJFbGVtZW50KGd1YXJkLmlzQ29ubmVjdGVkID8gZ3VhcmQgOiB0cmlnZ2VyRWxlbWVudFJlZi5jdXJyZW50LCBkaXJlY3Rpb24sIHBvc2l0aW9uZXJFbGVtZW50KT8uZm9jdXMoKTtcbiAgfVxuICBmdW5jdGlvbiBoYW5kbGVQcmVGb2N1c0d1YXJkRm9jdXMoZXZlbnQpIHtcbiAgICBjbG9zZUFuZEZvY3VzKGV2ZW50LCAtMSwgc3RvcmUuc2VsZWN0KCdwb3NpdGlvbmVyRWxlbWVudCcpKTtcbiAgfVxuICBmdW5jdGlvbiBoYW5kbGVGb2N1c1RhcmdldEZvY3VzKGV2ZW50KSB7XG4gICAgY29uc3QgcG9zaXRpb25lckVsZW1lbnQgPSBzdG9yZS5zZWxlY3QoJ3Bvc2l0aW9uZXJFbGVtZW50Jyk7XG4gICAgaWYgKHBvc2l0aW9uZXJFbGVtZW50ICYmIGlzT3V0c2lkZUV2ZW50KGV2ZW50LCBwb3NpdGlvbmVyRWxlbWVudCkpIHtcbiAgICAgIHN0b3JlLmNvbnRleHQuYmVmb3JlQ29udGVudEZvY3VzR3VhcmRSZWYuY3VycmVudD8uZm9jdXMoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY2xvc2VBbmRGb2N1cyhldmVudCwgMSwgcG9zaXRpb25lckVsZW1lbnQpO1xuICAgIH1cbiAgfVxuICByZXR1cm4ge1xuICAgIGhhbmRsZVByZUZvY3VzR3VhcmRGb2N1cyxcbiAgICBoYW5kbGVGb2N1c1RhcmdldEZvY3VzXG4gIH07XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBvd25lckRvY3VtZW50IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvb3duZXInO1xuaW1wb3J0IHsgRU1QVFlfT0JKRUNUIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuLyoqXG4gKiBSZXR1cm5zIGBjbGlja2AgYW5kIGBtb3VzZWRvd25gIGhhbmRsZXJzIHRoYXQgZml4IHRoZSBiZWhhdmlvciBvZiB0cmlnZ2VycyBvZiBwb3B1cHMgdGhhdCBhcmUgdG9nZ2xlZCBieSBkaWZmZXJlbnQgZXZlbnRzLlxuICogRm9yIGV4YW1wbGUsIGEgYnV0dG9uIHRoYXQgb3BlbnMgYSBwb3B1cCBvbiBtb3VzZWRvd24gYW5kIGNsb3NlcyBpdCBvbiBjbGljay5cbiAqIFRoaXMgaG9vayBwcmV2ZW50cyB0aGUgcG9wdXAgZnJvbSBjbG9zaW5nIGltbWVkaWF0ZWx5IGFmdGVyIHRoZSBtb3VzZSBidXR0b24gaXMgcmVsZWFzZWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VNaXhlZFRvZ2dsZUNsaWNrSGFuZGxlcihwYXJhbXMpIHtcbiAgY29uc3Qge1xuICAgIGVuYWJsZWQgPSB0cnVlLFxuICAgIG1vdXNlRG93bkFjdGlvbixcbiAgICBvcGVuXG4gIH0gPSBwYXJhbXM7XG4gIGNvbnN0IGlnbm9yZUNsaWNrUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGlmICghZW5hYmxlZCkge1xuICAgICAgcmV0dXJuIEVNUFRZX09CSkVDVDtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIG9uTW91c2VEb3duOiBldmVudCA9PiB7XG4gICAgICAgIGlmIChtb3VzZURvd25BY3Rpb24gPT09ICdvcGVuJyAmJiAhb3BlbiB8fCBtb3VzZURvd25BY3Rpb24gPT09ICdjbG9zZScgJiYgb3Blbikge1xuICAgICAgICAgIGlnbm9yZUNsaWNrUmVmLmN1cnJlbnQgPSB0cnVlO1xuICAgICAgICAgIG93bmVyRG9jdW1lbnQoZXZlbnQuY3VycmVudFRhcmdldCkuYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICAgICAgICBpZ25vcmVDbGlja1JlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgICAgfSwge1xuICAgICAgICAgICAgb25jZTogdHJ1ZVxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgb25DbGljazogZXZlbnQgPT4ge1xuICAgICAgICBpZiAoaWdub3JlQ2xpY2tSZWYuY3VycmVudCkge1xuICAgICAgICAgIGlnbm9yZUNsaWNrUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICAgICAgICBldmVudC5wcmV2ZW50QmFzZVVJSGFuZGxlcigpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW2VuYWJsZWQsIG1vdXNlRG93bkFjdGlvbiwgb3Blbl0pO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlVGltZW91dCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVRpbWVvdXQnO1xuaW1wb3J0IHsgb3duZXJEb2N1bWVudCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL293bmVyJztcbmltcG9ydCB7IGZhc3RDb21wb25lbnRSZWYgfSBmcm9tICdAYmFzZS11aS91dGlscy9mYXN0SG9va3MnO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgRU1QVFlfT0JKRUNUIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuaW1wb3J0IHsgc2FmZVBvbHlnb24sIHVzZUNsaWNrLCB1c2VGbG9hdGluZ1RyZWUsIHVzZUZvY3VzLCB1c2VIb3ZlclJlZmVyZW5jZUludGVyYWN0aW9uLCB1c2VGbG9hdGluZ05vZGVJZCwgdXNlRmxvYXRpbmdQYXJlbnROb2RlSWQgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvaW5kZXgubWpzXCI7XG5pbXBvcnQgeyBGbG9hdGluZ1RyZWVTdG9yZSB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9jb21wb25lbnRzL0Zsb2F0aW5nVHJlZVN0b3JlLm1qc1wiO1xuaW1wb3J0IHsgY29udGFpbnMgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvdXRpbHMubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51Um9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9NZW51Um9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBwcmVzc2FibGVUcmlnZ2VyT3BlblN0YXRlTWFwcGluZyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VCdXR0b24gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZS1idXR0b24vdXNlQnV0dG9uLm1qc1wiO1xuaW1wb3J0IHsgaXNNb3VzZVdpdGhpbkJvdW5kcyB9IGZyb20gXCIuLi8uLi91dGlscy9nZXRQc2V1ZG9FbGVtZW50Qm91bmRzLm1qc1wiO1xuaW1wb3J0IHsgQ29tcG9zaXRlSXRlbSB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY29tcG9zaXRlL2l0ZW0vQ29tcG9zaXRlSXRlbS5tanNcIjtcbmltcG9ydCB7IHVzZUNvbXBvc2l0ZVJvb3RDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jb21wb3NpdGUvcm9vdC9Db21wb3NpdGVSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IGZpbmRSb290T3duZXJJZCB9IGZyb20gXCIuLi91dGlscy9maW5kUm9vdE93bmVySWQubWpzXCI7XG5pbXBvcnQgeyB1c2VQb3B1cEhhbmRsZVN0b3JlLCB1c2VUcmlnZ2VyRGF0YUZvcndhcmRpbmcgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBzL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlVHJpZ2dlckZvY3VzR3VhcmRzIH0gZnJvbSBcIi4uLy4uL3V0aWxzL3BvcHVwcy91c2VUcmlnZ2VyRm9jdXNHdWFyZHMubWpzXCI7XG5pbXBvcnQgeyB1c2VCYXNlVWlJZCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlQmFzZVVpSWQubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsgdXNlTWl4ZWRUb2dnbGVDbGlja0hhbmRsZXIgfSBmcm9tIFwiLi4vLi4vdXRpbHMvdXNlTWl4ZWRUb2dnbGVDbGlja0hhbmRsZXIubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51YmFyQ29udGV4dCB9IGZyb20gXCIuLi8uLi9tZW51YmFyL01lbnViYXJDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgUEFUSUVOVF9DTElDS19USFJFU0hPTEQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NvbnN0YW50cy5tanNcIjtcbmltcG9ydCB7IEZvY3VzR3VhcmQgfSBmcm9tIFwiLi4vLi4vdXRpbHMvRm9jdXNHdWFyZC5tanNcIjtcbmltcG9ydCB7IG1lcmdlUHJvcHMgfSBmcm9tIFwiLi4vLi4vbWVyZ2UtcHJvcHMvaW5kZXgubWpzXCI7XG5cbi8qKlxuICogQSBidXR0b24gdGhhdCBvcGVucyB0aGUgbWVudS5cbiAqIFJlbmRlcnMgYSBgPGJ1dHRvbj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgTWVudV0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL21lbnUpXG4gKi9cbmltcG9ydCB7IGpzeCBhcyBfanN4LCBqc3hzIGFzIF9qc3hzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgY29uc3QgTWVudVRyaWdnZXIgPSBmYXN0Q29tcG9uZW50UmVmKGZ1bmN0aW9uIE1lbnVUcmlnZ2VyKGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgZGlzYWJsZWQ6IGRpc2FibGVkUHJvcCA9IGZhbHNlLFxuICAgIG5hdGl2ZUJ1dHRvbiA9IHRydWUsXG4gICAgaWQ6IGlkUHJvcCxcbiAgICBvcGVuT25Ib3Zlcjogb3Blbk9uSG92ZXJQcm9wLFxuICAgIGRlbGF5ID0gMTAwLFxuICAgIGNsb3NlRGVsYXkgPSAwLFxuICAgIGhhbmRsZSxcbiAgICBwYXlsb2FkLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IHJvb3RDb250ZXh0ID0gdXNlTWVudVJvb3RDb250ZXh0KHRydWUpO1xuICBjb25zdCBoYW5kbGVTdG9yZSA9IHVzZVBvcHVwSGFuZGxlU3RvcmUoaGFuZGxlKTtcbiAgY29uc3Qgc3RvcmUgPSBoYW5kbGVTdG9yZSA/PyByb290Q29udGV4dD8uc3RvcmU7XG4gIGlmICghc3RvcmUpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gJ0Jhc2UgVUk6IDxNZW51LlRyaWdnZXI+IG11c3QgYmUgZWl0aGVyIHVzZWQgd2l0aGluIGEgPE1lbnUuUm9vdD4gY29tcG9uZW50IG9yIHByb3ZpZGVkIHdpdGggYSBoYW5kbGUuJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoODUpKTtcbiAgfVxuICBjb25zdCB0aGlzVHJpZ2dlcklkID0gdXNlQmFzZVVpSWQoaWRQcm9wKTtcbiAgY29uc3QgaXNUcmlnZ2VyQWN0aXZlID0gc3RvcmUudXNlU3RhdGUoJ2lzVHJpZ2dlckFjdGl2ZScsIHRoaXNUcmlnZ2VySWQpO1xuICBjb25zdCBmbG9hdGluZ1Jvb3RDb250ZXh0ID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nUm9vdENvbnRleHQnKTtcbiAgY29uc3QgaXNPcGVuZWRCeVRoaXNUcmlnZ2VyID0gc3RvcmUudXNlU3RhdGUoJ2lzT3BlbmVkQnlUcmlnZ2VyJywgdGhpc1RyaWdnZXJJZCk7XG4gIGNvbnN0IGNvbnRyb2xzSWQgPSBzdG9yZS51c2VTdGF0ZSgndHJpZ2dlckNvbnRyb2xzSWQnLCB0aGlzVHJpZ2dlcklkKTtcbiAgY29uc3QgdHJpZ2dlckVsZW1lbnRSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IHBhcmVudCA9IHVzZU1lbnVQYXJlbnQoKTtcbiAgY29uc3QgY29tcG9zaXRlUm9vdENvbnRleHQgPSB1c2VDb21wb3NpdGVSb290Q29udGV4dCh0cnVlKTtcbiAgY29uc3QgZmxvYXRpbmdUcmVlUm9vdEZyb21Db250ZXh0ID0gdXNlRmxvYXRpbmdUcmVlKCk7XG4gIGNvbnN0IGZsb2F0aW5nVHJlZVJvb3QgPSBSZWFjdC51c2VNZW1vKCgpID0+IHtcbiAgICByZXR1cm4gZmxvYXRpbmdUcmVlUm9vdEZyb21Db250ZXh0ID8/IG5ldyBGbG9hdGluZ1RyZWVTdG9yZSgpO1xuICB9LCBbZmxvYXRpbmdUcmVlUm9vdEZyb21Db250ZXh0XSk7XG4gIGNvbnN0IGZsb2F0aW5nTm9kZUlkID0gdXNlRmxvYXRpbmdOb2RlSWQoZmxvYXRpbmdUcmVlUm9vdCk7XG4gIGNvbnN0IGZsb2F0aW5nUGFyZW50Tm9kZUlkID0gdXNlRmxvYXRpbmdQYXJlbnROb2RlSWQoKTtcbiAgY29uc3Qge1xuICAgIHJlZ2lzdGVyVHJpZ2dlcixcbiAgICBpc01vdW50ZWRCeVRoaXNUcmlnZ2VyXG4gIH0gPSB1c2VUcmlnZ2VyRGF0YUZvcndhcmRpbmcodGhpc1RyaWdnZXJJZCwgdHJpZ2dlckVsZW1lbnRSZWYsIHN0b3JlLCB7XG4gICAgcGF5bG9hZCxcbiAgICBjbG9zZURlbGF5LFxuICAgIHBhcmVudCxcbiAgICBmbG9hdGluZ1RyZWVSb290LFxuICAgIGZsb2F0aW5nTm9kZUlkLFxuICAgIGZsb2F0aW5nUGFyZW50Tm9kZUlkLFxuICAgIGtleWJvYXJkRXZlbnRSZWxheTogY29tcG9zaXRlUm9vdENvbnRleHQ/LnJlbGF5S2V5Ym9hcmRFdmVudFxuICB9KTtcbiAgY29uc3QgaXNJbk1lbnViYXIgPSBwYXJlbnQudHlwZSA9PT0gJ21lbnViYXInO1xuICBjb25zdCByb290RGlzYWJsZWQgPSBzdG9yZS51c2VTdGF0ZSgnZGlzYWJsZWQnKTtcbiAgY29uc3QgZGlzYWJsZWQgPSBkaXNhYmxlZFByb3AgfHwgcm9vdERpc2FibGVkIHx8IGlzSW5NZW51YmFyICYmIHBhcmVudC5jb250ZXh0LmRpc2FibGVkO1xuICBjb25zdCB7XG4gICAgZ2V0QnV0dG9uUHJvcHMsXG4gICAgYnV0dG9uUmVmXG4gIH0gPSB1c2VCdXR0b24oe1xuICAgIGRpc2FibGVkLFxuICAgIG5hdGl2ZTogbmF0aXZlQnV0dG9uXG4gIH0pO1xuICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghaXNPcGVuZWRCeVRoaXNUcmlnZ2VyICYmIHBhcmVudC50eXBlID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHN0b3JlLmNvbnRleHQuYWxsb3dNb3VzZVVwVHJpZ2dlclJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgfVxuICB9LCBbc3RvcmUsIGlzT3BlbmVkQnlUaGlzVHJpZ2dlciwgcGFyZW50LnR5cGVdKTtcbiAgY29uc3QgdHJpZ2dlclJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgYWxsb3dNb3VzZVVwVHJpZ2dlclRpbWVvdXQgPSB1c2VUaW1lb3V0KCk7XG4gIGNvbnN0IGhhbmRsZURvY3VtZW50TW91c2VVcCA9IHVzZVN0YWJsZUNhbGxiYWNrKG1vdXNlRXZlbnQgPT4ge1xuICAgIGlmICghdHJpZ2dlclJlZi5jdXJyZW50KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGFsbG93TW91c2VVcFRyaWdnZXJUaW1lb3V0LmNsZWFyKCk7XG4gICAgc3RvcmUuY29udGV4dC5hbGxvd01vdXNlVXBUcmlnZ2VyUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICBjb25zdCBtb3VzZVVwVGFyZ2V0ID0gbW91c2VFdmVudC50YXJnZXQ7XG4gICAgaWYgKGNvbnRhaW5zKHRyaWdnZXJSZWYuY3VycmVudCwgbW91c2VVcFRhcmdldCkgfHwgY29udGFpbnMoc3RvcmUuc2VsZWN0KCdwb3NpdGlvbmVyRWxlbWVudCcpLCBtb3VzZVVwVGFyZ2V0KSB8fCBtb3VzZVVwVGFyZ2V0ID09PSB0cmlnZ2VyUmVmLmN1cnJlbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKG1vdXNlVXBUYXJnZXQgIT0gbnVsbCAmJiBmaW5kUm9vdE93bmVySWQobW91c2VVcFRhcmdldCkgPT09IHN0b3JlLnNlbGVjdCgncm9vdElkJykpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGlzTW91c2VXaXRoaW5Cb3VuZHMobW91c2VFdmVudCwgdHJpZ2dlclJlZi5jdXJyZW50KSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBmbG9hdGluZ1RyZWVSb290LmV2ZW50cy5lbWl0KCdjbG9zZScsIHtcbiAgICAgIGRvbUV2ZW50OiBtb3VzZUV2ZW50LFxuICAgICAgcmVhc29uOiBSRUFTT05TLmNhbmNlbE9wZW5cbiAgICB9KTtcbiAgfSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudCh0cmlnZ2VyUmVmLmN1cnJlbnQpO1xuICAgIGlmIChpc09wZW5lZEJ5VGhpc1RyaWdnZXIgJiYgc3RvcmUuc2VsZWN0KCdsYXN0T3BlbkNoYW5nZVJlYXNvbicpID09PSBSRUFTT05TLnRyaWdnZXJIb3Zlcikge1xuICAgICAgZG9jLmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNldXAnLCBoYW5kbGVEb2N1bWVudE1vdXNlVXAsIHtcbiAgICAgICAgb25jZTogdHJ1ZVxuICAgICAgfSk7XG4gICAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgICBkb2MucmVtb3ZlRXZlbnRMaXN0ZW5lcignbW91c2V1cCcsIGhhbmRsZURvY3VtZW50TW91c2VVcCk7XG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9LCBbaXNPcGVuZWRCeVRoaXNUcmlnZ2VyLCBoYW5kbGVEb2N1bWVudE1vdXNlVXAsIHN0b3JlXSk7XG4gIGNvbnN0IHBhcmVudE1lbnViYXJIYXNTdWJtZW51T3BlbiA9IGlzSW5NZW51YmFyICYmIHBhcmVudC5jb250ZXh0Lmhhc1N1Ym1lbnVPcGVuO1xuICBjb25zdCBvcGVuT25Ib3ZlciA9IG9wZW5PbkhvdmVyUHJvcCA/PyBwYXJlbnRNZW51YmFySGFzU3VibWVudU9wZW47XG4gIGNvbnN0IGhvdmVyUHJvcHMgPSB1c2VIb3ZlclJlZmVyZW5jZUludGVyYWN0aW9uKGZsb2F0aW5nUm9vdENvbnRleHQsIHtcbiAgICBlbmFibGVkOiBvcGVuT25Ib3ZlciAmJiAhZGlzYWJsZWQgJiYgKCFpc0luTWVudWJhciB8fCBwYXJlbnRNZW51YmFySGFzU3VibWVudU9wZW4gJiYgIWlzTW91bnRlZEJ5VGhpc1RyaWdnZXIpLFxuICAgIGhhbmRsZUNsb3NlOiBzYWZlUG9seWdvbih7XG4gICAgICBibG9ja1BvaW50ZXJFdmVudHM6ICFpc0luTWVudWJhclxuICAgIH0pLFxuICAgIG1vdXNlT25seTogdHJ1ZSxcbiAgICBtb3ZlOiBmYWxzZSxcbiAgICByZXN0TXM6IHBhcmVudC50eXBlID09PSB1bmRlZmluZWQgPyBkZWxheSA6IHVuZGVmaW5lZCxcbiAgICBkZWxheToge1xuICAgICAgY2xvc2U6IGNsb3NlRGVsYXlcbiAgICB9LFxuICAgIHRyaWdnZXJFbGVtZW50UmVmLFxuICAgIGV4dGVybmFsVHJlZTogZmxvYXRpbmdUcmVlUm9vdCxcbiAgICBpc0FjdGl2ZVRyaWdnZXI6IGlzVHJpZ2dlckFjdGl2ZSxcbiAgICBpc0Nsb3Npbmc6ICgpID0+IHN0b3JlLnNlbGVjdCgndHJhbnNpdGlvblN0YXR1cycpID09PSAnZW5kaW5nJ1xuICB9KTtcblxuICAvLyBXaGV0aGVyIHRvIGlnbm9yZSBjbGlja3MgdG8gb3BlbiB0aGUgbWVudS5cbiAgLy8gYGxhc3RPcGVuQ2hhbmdlUmVhc29uYCBkb2Vzbid0IG5lZWQgdG8gYmUgcmVhY3RpdmUgaGVyZSwgYXMgd2UgbmVlZCB0byBydW4gdGhpc1xuICAvLyBvbmx5IHdoZW4gYGlzT3BlbmVkQnlUaGlzVHJpZ2dlcmAgY2hhbmdlcy5cbiAgY29uc3Qgc3RpY2tJZk9wZW4gPSB1c2VTdGlja0lmT3Blbihpc09wZW5lZEJ5VGhpc1RyaWdnZXIsIHN0b3JlLnNlbGVjdCgnbGFzdE9wZW5DaGFuZ2VSZWFzb24nKSk7XG4gIGNvbnN0IGNsaWNrID0gdXNlQ2xpY2soZmxvYXRpbmdSb290Q29udGV4dCwge1xuICAgIGVuYWJsZWQ6ICFkaXNhYmxlZCxcbiAgICBldmVudDogaXNPcGVuZWRCeVRoaXNUcmlnZ2VyICYmIGlzSW5NZW51YmFyID8gJ2NsaWNrJyA6ICdtb3VzZWRvd24nLFxuICAgIHRvZ2dsZTogdHJ1ZSxcbiAgICBpZ25vcmVNb3VzZTogZmFsc2UsXG4gICAgc3RpY2tJZk9wZW46IHBhcmVudC50eXBlID09PSB1bmRlZmluZWQgPyBzdGlja0lmT3BlbiA6IGZhbHNlXG4gIH0pO1xuICBjb25zdCBmb2N1cyA9IHVzZUZvY3VzKGZsb2F0aW5nUm9vdENvbnRleHQsIHtcbiAgICBlbmFibGVkOiAhZGlzYWJsZWQgJiYgcGFyZW50TWVudWJhckhhc1N1Ym1lbnVPcGVuXG4gIH0pO1xuICBjb25zdCBtaXhlZFRvZ2dsZUhhbmRsZXJzID0gdXNlTWl4ZWRUb2dnbGVDbGlja0hhbmRsZXIoe1xuICAgIG9wZW46IGlzT3BlbmVkQnlUaGlzVHJpZ2dlcixcbiAgICBlbmFibGVkOiBpc0luTWVudWJhcixcbiAgICBtb3VzZURvd25BY3Rpb246ICdvcGVuJ1xuICB9KTtcbiAgY29uc3QgbG9jYWxJbnRlcmFjdGlvblByb3BzID0gUmVhY3QudXNlTWVtbygoKSA9PiBtZXJnZVByb3BzKGZvY3VzLnJlZmVyZW5jZSwgY2xpY2sucmVmZXJlbmNlKSwgW2ZvY3VzLnJlZmVyZW5jZSwgY2xpY2sucmVmZXJlbmNlXSk7XG4gIGNvbnN0IHJvb3RUcmlnZ2VyUHJvcHMgPSBzdG9yZS51c2VTdGF0ZSgndHJpZ2dlclByb3BzJywgaXNNb3VudGVkQnlUaGlzVHJpZ2dlcik7XG4gIC8vIEEgZmlsdGVyYWJsZSBtZW51IGtlZXBzIHJlYWwgZm9jdXMgaW5zaWRlIGl0cyBwb3B1cCBhbmQgcHVibGlzaGVzIHdoYXQgaXRzIHRyaWdnZXIgbmVlZHMuXG4gIGNvbnN0IGZpbHRlclRyaWdnZXJQcm9wcyA9IHN0b3JlLnVzZVN0YXRlKCdmaWx0ZXJUcmlnZ2VyUHJvcHMnKTtcbiAgY29uc3Qge1xuICAgIGhhbmRsZVByZUZvY3VzR3VhcmRGb2N1cyxcbiAgICBoYW5kbGVGb2N1c1RhcmdldEZvY3VzXG4gIH0gPSB1c2VUcmlnZ2VyRm9jdXNHdWFyZHMoc3RvcmUsIHRyaWdnZXJFbGVtZW50UmVmKTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgZGlzYWJsZWQsXG4gICAgb3BlbjogaXNPcGVuZWRCeVRoaXNUcmlnZ2VyXG4gIH07XG4gIGNvbnN0IHJlZiA9IFt0cmlnZ2VyUmVmLCBmb3J3YXJkZWRSZWYsIGJ1dHRvblJlZiwgcmVnaXN0ZXJUcmlnZ2VyLCB0cmlnZ2VyRWxlbWVudFJlZl07XG4gIGNvbnN0IHByb3BzID0gW2xvY2FsSW50ZXJhY3Rpb25Qcm9wcywgaG92ZXJQcm9wcyA/PyBFTVBUWV9PQkpFQ1QsIHJvb3RUcmlnZ2VyUHJvcHMsIHtcbiAgICAnYXJpYS1oYXNwb3B1cCc6ICdtZW51JyxcbiAgICAnYXJpYS1jb250cm9scyc6IGNvbnRyb2xzSWQsXG4gICAgaWQ6IHRoaXNUcmlnZ2VySWQsXG4gICAgb25Nb3VzZURvd246IGV2ZW50ID0+IHtcbiAgICAgIGlmIChzdG9yZS5zZWxlY3QoJ29wZW4nKSkge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG5cbiAgICAgIC8vIG1vdXNlZG93biAtPiBtb3VzZXVwIG9uIG1lbnUgaXRlbSBzaG91bGQgbm90IHRyaWdnZXIgaXQgd2l0aGluIDIwMG1zLlxuICAgICAgYWxsb3dNb3VzZVVwVHJpZ2dlclRpbWVvdXQuc3RhcnQoMjAwLCAoKSA9PiB7XG4gICAgICAgIHN0b3JlLmNvbnRleHQuYWxsb3dNb3VzZVVwVHJpZ2dlclJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgIH0pO1xuICAgICAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChldmVudC5jdXJyZW50VGFyZ2V0KTtcbiAgICAgIGRvYy5hZGRFdmVudExpc3RlbmVyKCdtb3VzZXVwJywgaGFuZGxlRG9jdW1lbnRNb3VzZVVwLCB7XG4gICAgICAgIG9uY2U6IHRydWVcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwgZmlsdGVyVHJpZ2dlclByb3BzLCBpc0luTWVudWJhciA/IHtcbiAgICByb2xlOiAnbWVudWl0ZW0nXG4gIH0gOiB7fSwgbWl4ZWRUb2dnbGVIYW5kbGVycywgZWxlbWVudFByb3BzLCBnZXRCdXR0b25Qcm9wc107XG4gIGNvbnN0IGVsZW1lbnQgPSB1c2VSZW5kZXJFbGVtZW50KCdidXR0b24nLCBjb21wb25lbnRQcm9wcywge1xuICAgIGVuYWJsZWQ6ICFpc0luTWVudWJhcixcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiBwcmVzc2FibGVUcmlnZ2VyT3BlblN0YXRlTWFwcGluZyxcbiAgICBzdGF0ZSxcbiAgICByZWYsXG4gICAgcHJvcHNcbiAgfSk7XG4gIGlmIChpc0luTWVudWJhcikge1xuICAgIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChDb21wb3NpdGVJdGVtLCB7XG4gICAgICB0YWc6IFwiYnV0dG9uXCIsXG4gICAgICByZW5kZXI6IHJlbmRlcixcbiAgICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lLFxuICAgICAgc3R5bGU6IHN0eWxlLFxuICAgICAgc3RhdGU6IHN0YXRlLFxuICAgICAgcmVmczogcmVmLFxuICAgICAgcHJvcHM6IHByb3BzLFxuICAgICAgc3RhdGVBdHRyaWJ1dGVzTWFwcGluZzogcHJlc3NhYmxlVHJpZ2dlck9wZW5TdGF0ZU1hcHBpbmdcbiAgICB9KTtcbiAgfVxuXG4gIC8vIEEgZnJhZ21lbnQgd2l0aCBrZXkgaXMgcmVxdWlyZWQgdG8gZW5zdXJlIHRoYXQgdGhlIGBlbGVtZW50YCBpcyBtb3VudGVkIHRvIHRoZSBzYW1lIERPTSBub2RlXG4gIC8vIHJlZ2FyZGxlc3Mgb2Ygd2hldGhlciB0aGUgZm9jdXMgZ3VhcmRzIGFyZSByZW5kZXJlZCBvciBub3QuXG5cbiAgaWYgKGlzT3BlbmVkQnlUaGlzVHJpZ2dlcikge1xuICAgIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeHMoUmVhY3QuRnJhZ21lbnQsIHtcbiAgICAgIGNoaWxkcmVuOiBbLyojX19QVVJFX18qL19qc3goRm9jdXNHdWFyZCwge1xuICAgICAgICByZWY6IHN0b3JlLmNvbnRleHQuYmVmb3JlVHJpZ2dlckZvY3VzR3VhcmRSZWYsXG4gICAgICAgIG9uRm9jdXM6IGhhbmRsZVByZUZvY3VzR3VhcmRGb2N1c1xuICAgICAgfSwgYCR7dGhpc1RyaWdnZXJJZH0tcHJlLWZvY3VzLWd1YXJkYCksIC8qI19fUFVSRV9fKi9fanN4KFJlYWN0LkZyYWdtZW50LCB7XG4gICAgICAgIGNoaWxkcmVuOiBlbGVtZW50XG4gICAgICB9LCB0aGlzVHJpZ2dlcklkKSwgLyojX19QVVJFX18qL19qc3goRm9jdXNHdWFyZCwge1xuICAgICAgICByZWY6IHN0b3JlLmNvbnRleHQudHJpZ2dlckZvY3VzVGFyZ2V0UmVmLFxuICAgICAgICBvbkZvY3VzOiBoYW5kbGVGb2N1c1RhcmdldEZvY3VzXG4gICAgICB9LCBgJHt0aGlzVHJpZ2dlcklkfS1wb3N0LWZvY3VzLWd1YXJkYCldXG4gICAgfSk7XG4gIH1cbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KFJlYWN0LkZyYWdtZW50LCB7XG4gICAgY2hpbGRyZW46IGVsZW1lbnRcbiAgfSwgdGhpc1RyaWdnZXJJZCk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnVUcmlnZ2VyLmRpc3BsYXlOYW1lID0gXCJNZW51VHJpZ2dlclwiO1xuLyoqXG4gKiBEZXRlcm1pbmVzIHdoZXRoZXIgdG8gaWdub3JlIGNsaWNrcyBhZnRlciBhIGhvdmVyLW9wZW4uXG4gKi9cbmZ1bmN0aW9uIHVzZVN0aWNrSWZPcGVuKG9wZW4sIG9wZW5SZWFzb24pIHtcbiAgY29uc3Qgc3RpY2tJZk9wZW5UaW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICBjb25zdCBbc3RpY2tJZk9wZW4sIHNldFN0aWNrSWZPcGVuXSA9IFJlYWN0LnVzZVN0YXRlKGZhbHNlKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAob3BlbiAmJiBvcGVuUmVhc29uID09PSBSRUFTT05TLnRyaWdnZXJIb3Zlcikge1xuICAgICAgLy8gT25seSBhbGxvdyBcInBhdGllbnRcIiBjbGlja3MgdG8gY2xvc2UgdGhlIG1lbnUgaWYgaXQncyBvcGVuLlxuICAgICAgLy8gSWYgdGhleSBjbGlja2VkIHdpdGhpbiA1MDBtcyBvZiB0aGUgbWVudSBvcGVuaW5nLCBrZWVwIGl0IG9wZW4uXG4gICAgICBzZXRTdGlja0lmT3Blbih0cnVlKTtcbiAgICAgIHN0aWNrSWZPcGVuVGltZW91dC5zdGFydChQQVRJRU5UX0NMSUNLX1RIUkVTSE9MRCwgKCkgPT4ge1xuICAgICAgICBzZXRTdGlja0lmT3BlbihmYWxzZSk7XG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKCFvcGVuKSB7XG4gICAgICBzdGlja0lmT3BlblRpbWVvdXQuY2xlYXIoKTtcbiAgICAgIHNldFN0aWNrSWZPcGVuKGZhbHNlKTtcbiAgICB9XG4gIH0sIFtvcGVuLCBvcGVuUmVhc29uLCBzdGlja0lmT3BlblRpbWVvdXRdKTtcbiAgcmV0dXJuIHN0aWNrSWZPcGVuO1xufVxuZnVuY3Rpb24gdXNlTWVudVBhcmVudCgpIHtcbiAgY29uc3QgbWVudWJhckNvbnRleHQgPSB1c2VNZW51YmFyQ29udGV4dCh0cnVlKTtcbiAgY29uc3QgcGFyZW50ID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgaWYgKG1lbnViYXJDb250ZXh0KSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB0eXBlOiAnbWVudWJhcicsXG4gICAgICAgIGNvbnRleHQ6IG1lbnViYXJDb250ZXh0XG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgdHlwZTogdW5kZWZpbmVkXG4gICAgfTtcbiAgfSwgW21lbnViYXJDb250ZXh0XSk7XG4gIHJldHVybiBwYXJlbnQ7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VNZW51Um9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9NZW51Um9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51UG9zaXRpb25lckNvbnRleHQgfSBmcm9tIFwiLi4vcG9zaXRpb25lci9NZW51UG9zaXRpb25lckNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgcG9wdXBWaWV3cG9ydFN0YXRlTWFwcGluZywgdXNlUG9wdXBWaWV3cG9ydCB9IGZyb20gXCIuLi8uLi91dGlscy91c2VQb3B1cFZpZXdwb3J0Lm1qc1wiO1xuXG4vKipcbiAqIEEgdmlld3BvcnQgZm9yIGRpc3BsYXlpbmcgY29udGVudCB0cmFuc2l0aW9ucy5cbiAqIFRoaXMgY29tcG9uZW50IGlzIG9ubHkgcmVxdWlyZWQgaWYgb25lIHBvcHVwIGNhbiBiZSBvcGVuZWQgYnkgbXVsdGlwbGUgdHJpZ2dlcnMsIGl0cyBjb250ZW50XG4gKiBjaGFuZ2VzIGJhc2VkIG9uIHRoZSB0cmlnZ2VyLCBhbmQgc3dpdGNoaW5nIGJldHdlZW4gdGhlbSBpcyBhbmltYXRlZC5cbiAqIFJlbmRlcnMgYSBgPGRpdj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgTWVudV0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL21lbnUpXG4gKi9cbmV4cG9ydCBjb25zdCBNZW51Vmlld3BvcnQgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBNZW51Vmlld3BvcnQoY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIGNsYXNzTmFtZSxcbiAgICBzdHlsZSxcbiAgICBjaGlsZHJlbixcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCB7XG4gICAgc3RvcmVcbiAgfSA9IHVzZU1lbnVSb290Q29udGV4dCgpO1xuICBjb25zdCB7XG4gICAgc2lkZVxuICB9ID0gdXNlTWVudVBvc2l0aW9uZXJDb250ZXh0KCk7XG4gIGNvbnN0IGluc3RhbnRUeXBlID0gc3RvcmUudXNlU3RhdGUoJ2luc3RhbnRUeXBlJyk7XG4gIGNvbnN0IHtcbiAgICBjaGlsZHJlbjogY2hpbGRyZW5Ub1JlbmRlcixcbiAgICBzdGF0ZTogdmlld3BvcnRTdGF0ZVxuICB9ID0gdXNlUG9wdXBWaWV3cG9ydCh7XG4gICAgc3RvcmUsXG4gICAgc2lkZSxcbiAgICBjaGlsZHJlblxuICB9KTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgYWN0aXZhdGlvbkRpcmVjdGlvbjogdmlld3BvcnRTdGF0ZS5hY3RpdmF0aW9uRGlyZWN0aW9uLFxuICAgIHRyYW5zaXRpb25pbmc6IHZpZXdwb3J0U3RhdGUudHJhbnNpdGlvbmluZyxcbiAgICBpbnN0YW50OiBpbnN0YW50VHlwZVxuICB9O1xuICByZXR1cm4gdXNlUmVuZGVyRWxlbWVudCgnZGl2JywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICByZWY6IGZvcndhcmRlZFJlZixcbiAgICBwcm9wczogW2VsZW1lbnRQcm9wcywge1xuICAgICAgY2hpbGRyZW46IGNoaWxkcmVuVG9SZW5kZXJcbiAgICB9XSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiBwb3B1cFZpZXdwb3J0U3RhdGVNYXBwaW5nXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51Vmlld3BvcnQuZGlzcGxheU5hbWUgPSBcIk1lbnVWaWV3cG9ydFwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgaXNFbGVtZW50RGlzYWJsZWQgfSBmcm9tICdAYmFzZS11aS91dGlscy9pc0VsZW1lbnREaXNhYmxlZCc7XG5pbXBvcnQgeyB3YXJuIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvd2Fybic7XG5pbXBvcnQgeyBTYWZlUmVhY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy9zYWZlUmVhY3QnO1xuaW1wb3J0IHsgRU1QVFlfT0JKRUNUIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuaW1wb3J0IHsgcGxhdGZvcm0gfSBmcm9tICdAYmFzZS11aS91dGlscy9wbGF0Zm9ybSc7XG5pbXBvcnQgeyB1c2VTdGFibGVDYWxsYmFjayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrJztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyBnZXRUYXJnZXQgfSBmcm9tICdAYmFzZS11aS91dGlscy9zaGFkb3dEb20nO1xuaW1wb3J0IHsgdXNlTWVudUZpbHRlckl0ZW0gfSBmcm9tIFwiLi4vZmlsdGVyLXJvb3QvTWVudUZpbHRlckNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBtZXJnZVByb3BzIH0gZnJvbSBcIi4uLy4uL21lcmdlLXByb3BzL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgc2FmZVBvbHlnb24sIHVzZUNsaWNrLCB1c2VIb3ZlclJlZmVyZW5jZUludGVyYWN0aW9uIH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlTWVudVJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvTWVudVJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQmFzZVVpSWQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZUJhc2VVaUlkLm1qc1wiO1xuaW1wb3J0IHsgdHJpZ2dlck9wZW5TdGF0ZU1hcHBpbmcgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5pbXBvcnQgeyB1c2VDb21wb3NpdGVMaXN0SXRlbSB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY29tcG9zaXRlL2xpc3QvdXNlQ29tcG9zaXRlTGlzdEl0ZW0ubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51SXRlbSB9IGZyb20gXCIuLi9pdGVtL3VzZU1lbnVJdGVtLm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVuZGVyRWxlbWVudCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlUmVuZGVyRWxlbWVudC5tanNcIjtcbmltcG9ydCB7IHVzZU1lbnVQb3NpdGlvbmVyQ29udGV4dCB9IGZyb20gXCIuLi9wb3NpdGlvbmVyL01lbnVQb3NpdGlvbmVyQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVRyaWdnZXJSZWdpc3RyYXRpb24gfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBzL2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlTWVudVN1Ym1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi9zdWJtZW51LXJvb3QvTWVudVN1Ym1lbnVSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5jb25zdCBWT0lDRV9PVkVSX0VYUEFOREVEX1BST1BTID0ge1xuICAnYXJpYS1leHBhbmRlZCc6IHVuZGVmaW5lZFxufTtcbmNvbnN0IE1lbnVTdWJtZW51VHJpZ2dlclBsYWluID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gTWVudVN1Ym1lbnVUcmlnZ2VyUGxhaW4oY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIGNsYXNzTmFtZSxcbiAgICBzdHlsZSxcbiAgICBsYWJlbCxcbiAgICBpZDogaWRQcm9wLFxuICAgIG5hdGl2ZUJ1dHRvbiA9IGZhbHNlLFxuICAgIG9wZW5PbkhvdmVyID0gdHJ1ZSxcbiAgICBkZWxheSA9IDEwMCxcbiAgICBjbG9zZURlbGF5ID0gMCxcbiAgICBkaXNhYmxlZDogZGlzYWJsZWRQcm9wID0gZmFsc2UsXG4gICAgLi4uZWxlbWVudFByb3BzXG4gIH0gPSBjb21wb25lbnRQcm9wcztcbiAgY29uc3QgY29udGV4dCA9IHVzZU1lbnVSb290Q29udGV4dCh0cnVlKTtcbiAgaWYgKGNvbnRleHQ/LnBhcmVudC50eXBlICE9PSAnbWVudScpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gJ0Jhc2UgVUk6IDxNZW51LlN1Ym1lbnVUcmlnZ2VyPiBtdXN0IGJlIHBsYWNlZCBpbiA8TWVudS5TdWJtZW51Um9vdD4uJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoMzcpKTtcbiAgfVxuICBjb25zdCBtZW51UG9zaXRpb25lckNvbnRleHQgPSB1c2VNZW51UG9zaXRpb25lckNvbnRleHQoKTtcbiAgY29uc3Qgc3VibWVudVJvb3RDb250ZXh0ID0gdXNlTWVudVN1Ym1lbnVSb290Q29udGV4dCgpO1xuICBjb25zdCB7XG4gICAgc3RvcmUsXG4gICAgcGFyZW50VmlydHVhbEZvY3VzXG4gIH0gPSBjb250ZXh0O1xuICBjb25zdCBwYXJlbnRNZW51U3RvcmUgPSBjb250ZXh0LnBhcmVudC5zdG9yZTtcbiAgY29uc3QgbGlzdEl0ZW0gPSB1c2VDb21wb3NpdGVMaXN0SXRlbSh7XG4gICAgZ3Vlc3M6IHRydWUsXG4gICAgbGFiZWxcbiAgfSk7XG4gIGNvbnN0IHRoaXNUcmlnZ2VySWQgPSB1c2VCYXNlVWlJZChpZFByb3ApO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3QgZm9jdXNSZXR1cm5lZFRocm91Z2hHdWFyZFJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG4gIGNvbnN0IHBvc2l0aW9uZXJFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ3Bvc2l0aW9uZXJFbGVtZW50Jyk7XG4gIGNvbnN0IGZsb2F0aW5nUm9vdENvbnRleHQgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdSb290Q29udGV4dCcpO1xuICBjb25zdCBmbG9hdGluZ1RyZWVSb290ID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nVHJlZVJvb3QnKTtcbiAgY29uc3QgcG9wdXBJZCA9IHN0b3JlLnVzZVN0YXRlKCd0cmlnZ2VyUG9wdXBJZCcsIHRoaXNUcmlnZ2VySWQpO1xuICBjb25zdCBiYXNlUmVnaXN0ZXJUcmlnZ2VyID0gdXNlVHJpZ2dlclJlZ2lzdHJhdGlvbih0aGlzVHJpZ2dlcklkLCBzdG9yZSk7XG5cbiAgLy8gU3RhYmxlLCBzbyB0aGUgbWVyZ2VkIHJlZiBvbiB0aGUgcmVuZGVyZWQgZWxlbWVudCBrZWVwcyBpdHMgaWRlbnRpdHkgZm9yIHRoZSB0cmlnZ2VyJ3Mgd2hvbGVcbiAgLy8gbGlmZXRpbWU7IHRoZSBsYXRlc3QgYGNsb3NlRGVsYXlgIGlzIHJlYWQgd2hlbiBpdCBydW5zLlxuICBjb25zdCByZWdpc3RlclRyaWdnZXIgPSB1c2VTdGFibGVDYWxsYmFjayhlbGVtZW50ID0+IHtcbiAgICBiYXNlUmVnaXN0ZXJUcmlnZ2VyKGVsZW1lbnQpO1xuICAgIGNvbnN0IGFjdGl2ZVRyaWdnZXJFbGVtZW50ID0gc3RvcmUuc2VsZWN0KCdhY3RpdmVUcmlnZ2VyRWxlbWVudCcpO1xuICAgIGlmIChlbGVtZW50ICE9PSBudWxsICYmIHN0b3JlLnNlbGVjdCgnb3BlbicpICYmIChhY3RpdmVUcmlnZ2VyRWxlbWVudCA9PT0gZWxlbWVudCB8fCBzdG9yZS5zZWxlY3QoJ2FjdGl2ZVRyaWdnZXJJZCcpID09IG51bGwpKSB7XG4gICAgICBzdG9yZS51cGRhdGUoe1xuICAgICAgICBhY3RpdmVUcmlnZ2VySWQ6IHRoaXNUcmlnZ2VySWQgPz8gbnVsbCxcbiAgICAgICAgYWN0aXZlVHJpZ2dlckVsZW1lbnQ6IGVsZW1lbnQsXG4gICAgICAgIGNsb3NlRGVsYXlcbiAgICAgIH0pO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IHRyaWdnZXJFbGVtZW50UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBoYW5kbGVUcmlnZ2VyRWxlbWVudFJlZiA9IFJlYWN0LnVzZUNhbGxiYWNrKGVsID0+IHtcbiAgICB0cmlnZ2VyRWxlbWVudFJlZi5jdXJyZW50ID0gZWw7XG4gICAgc3RvcmUuc2V0KCdhY3RpdmVUcmlnZ2VyRWxlbWVudCcsIGVsKTtcbiAgfSwgW3N0b3JlXSk7XG5cbiAgLy8gQSBzdGFibGUgcmVmIGRvZXMgbm90IHJlLWZpcmUgd2hlbiB0aGUgaWQgY2hhbmdlcywgc28gcmVnaXN0ZXIgdGhlIHJlbmRlcmVkIGVsZW1lbnQgaGVyZVxuICAvLyBpbnN0ZWFkLiBPbiBSZWFjdCAxNyB0aGUgaWQgYWxzbyBzdGFydHMgb3V0IGB1bmRlZmluZWRgLCBzbyB0aGlzIGlzIHdoYXQgcmVnaXN0ZXJzIHRoZSB0cmlnZ2VyXG4gIC8vIGF0IGFsbC5cbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICByZWdpc3RlclRyaWdnZXIodHJpZ2dlckVsZW1lbnRSZWYuY3VycmVudCk7XG4gICAgcmV0dXJuICgpID0+IHJlZ2lzdGVyVHJpZ2dlcihudWxsKTtcbiAgfSwgW3JlZ2lzdGVyVHJpZ2dlciwgdGhpc1RyaWdnZXJJZCwgc3RvcmVdKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW9wZW4gfHwgIXBvc2l0aW9uZXJFbGVtZW50KSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBmdW5jdGlvbiBoYW5kbGVHdWFyZEZvY3VzT3V0KGV2ZW50KSB7XG4gICAgICBpZiAoZ2V0VGFyZ2V0KGV2ZW50KSA9PT0gc3RvcmUuY29udGV4dC5iZWZvcmVDb250ZW50Rm9jdXNHdWFyZFJlZi5jdXJyZW50KSB7XG4gICAgICAgIGZvY3VzUmV0dXJuZWRUaHJvdWdoR3VhcmRSZWYuY3VycmVudCA9IGV2ZW50LnJlbGF0ZWRUYXJnZXQgPT09IHRyaWdnZXJFbGVtZW50UmVmLmN1cnJlbnQ7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gT2JzZXJ2ZSBmb2N1cyBsZWF2aW5nIHRoZSBndWFyZCBpbnNpZGUgaXRzIHBvc2l0aW9uZXIuIFdoZW4gdGhlIHBvcnRhbCBpcyBpbiBhIHNoYWRvdyByb290LFxuICAgIC8vIHRoZSB0cmlnZ2VyJ3MgZm9jdXMgZXZlbnQgY2FuIHJlcG9ydCB0aGUgc2hhZG93IGhvc3QgYXMgYHJlbGF0ZWRUYXJnZXRgLCBub3QgdGhlIGd1YXJkLlxuICAgIHBvc2l0aW9uZXJFbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2ZvY3Vzb3V0JywgaGFuZGxlR3VhcmRGb2N1c091dCwgdHJ1ZSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGZvY3VzUmV0dXJuZWRUaHJvdWdoR3VhcmRSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgcG9zaXRpb25lckVsZW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignZm9jdXNvdXQnLCBoYW5kbGVHdWFyZEZvY3VzT3V0LCB0cnVlKTtcbiAgICB9O1xuICB9LCBbb3BlbiwgcG9zaXRpb25lckVsZW1lbnQsIHN0b3JlXSk7XG4gIHN0b3JlLnVzZVN5bmNlZFZhbHVlKCdjbG9zZURlbGF5JywgY2xvc2VEZWxheSk7XG4gIGNvbnN0IHJvb3REaXNhYmxlZCA9IHN0b3JlLnVzZVN0YXRlKCdkaXNhYmxlZCcpO1xuICBjb25zdCBwYXJlbnREaXNhYmxlZCA9IHBhcmVudE1lbnVTdG9yZS51c2VTdGF0ZSgnZGlzYWJsZWQnKTtcbiAgY29uc3QgZGlzYWJsZWQgPSBkaXNhYmxlZFByb3AgfHwgcm9vdERpc2FibGVkIHx8IHBhcmVudERpc2FibGVkO1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9ydWxlcy1vZi1ob29rc1xuICAgIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgICBjb25zdCBlbGVtZW50ID0gdHJpZ2dlckVsZW1lbnRSZWYuY3VycmVudDtcbiAgICAgIGlmIChlbGVtZW50ICYmIGlzRWxlbWVudERpc2FibGVkKGVsZW1lbnQpICYmICFkaXNhYmxlZCkge1xuICAgICAgICBjb25zdCBvd25lclN0YWNrTWVzc2FnZSA9IFNhZmVSZWFjdC5jYXB0dXJlT3duZXJTdGFjaz8uKCkgfHwgJyc7XG4gICAgICAgIHdhcm4oYEEgZGlzYWJsZWQgZWxlbWVudCB3YXMgZGV0ZWN0ZWQgb24gPE1lbnUuU3VibWVudVRyaWdnZXI+LiBUbyBwcm9wZXJseSBkaXNhYmxlIHRoZSB0cmlnZ2VyLCB1c2UgdGhlIFxcYGRpc2FibGVkXFxgIHByb3Agb24gdGhlIGNvbXBvbmVudCBpbnN0ZWFkIG9mIHNldHRpbmcgaXQgb24gdGhlIHJlbmRlcmVkIGVsZW1lbnQuJHtvd25lclN0YWNrTWVzc2FnZX1gKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBjb25zdCBpdGVtUHJvcHMgPSBwYXJlbnRNZW51U3RvcmUudXNlU3RhdGUoJ2l0ZW1Qcm9wcycpO1xuICBjb25zdCBoaWdobGlnaHRlZCA9IHBhcmVudE1lbnVTdG9yZS51c2VTdGF0ZSgnaXNBY3RpdmUnLCBsaXN0SXRlbS5pbmRleCk7XG4gIGNvbnN0IGl0ZW1NZXRhZGF0YSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICB0eXBlOiAnc3VibWVudS10cmlnZ2VyJyxcbiAgICBzZXRBY3RpdmUoZXZlbnQpIHtcbiAgICAgIGlmIChwYXJlbnRNZW51U3RvcmUuc2VsZWN0KCdoaWdobGlnaHRJdGVtT25Ib3ZlcicpKSB7XG4gICAgICAgIHBhcmVudE1lbnVTdG9yZS5zZXRBY3RpdmVJbmRleChsaXN0SXRlbS5pbmRleCwgUkVBU09OUy5wb2ludGVyLCBldmVudCk7XG4gICAgICB9XG4gICAgfVxuICB9KSwgW3BhcmVudE1lbnVTdG9yZSwgbGlzdEl0ZW0uaW5kZXhdKTtcbiAgY29uc3Qge1xuICAgIGdldEl0ZW1Qcm9wcyxcbiAgICBpdGVtUmVmXG4gIH0gPSB1c2VNZW51SXRlbSh7XG4gICAgY2xvc2VPbkNsaWNrOiBmYWxzZSxcbiAgICBkaXNhYmxlZCxcbiAgICBoaWdobGlnaHRlZCxcbiAgICBpZDogdGhpc1RyaWdnZXJJZCxcbiAgICBzdG9yZSxcbiAgICB0eXBpbmdSZWY6IHBhcmVudE1lbnVTdG9yZS5jb250ZXh0LnR5cGluZ1JlZixcbiAgICBuYXRpdmVCdXR0b24sXG4gICAgaXRlbU1ldGFkYXRhLFxuICAgIG5vZGVJZDogbWVudVBvc2l0aW9uZXJDb250ZXh0Py5jb250ZXh0Lm5vZGVJZFxuICB9KTtcbiAgY29uc3QgaG92ZXJFbmFibGVkID0gc3RvcmUudXNlU3RhdGUoJ2hvdmVyRW5hYmxlZCcpO1xuICBjb25zdCBob3ZlclByb3BzID0gdXNlSG92ZXJSZWZlcmVuY2VJbnRlcmFjdGlvbihmbG9hdGluZ1Jvb3RDb250ZXh0LCB7XG4gICAgZW5hYmxlZDogaG92ZXJFbmFibGVkICYmIG9wZW5PbkhvdmVyICYmICFkaXNhYmxlZCxcbiAgICBoYW5kbGVDbG9zZTogc2FmZVBvbHlnb24oe1xuICAgICAgYmxvY2tQb2ludGVyRXZlbnRzOiB0cnVlXG4gICAgfSksXG4gICAgbW91c2VPbmx5OiB0cnVlLFxuICAgIG1vdmU6IHRydWUsXG4gICAgcmVzdE1zOiBkZWxheSxcbiAgICBkZWxheToge1xuICAgICAgb3BlbjogZGVsYXksXG4gICAgICBjbG9zZTogY2xvc2VEZWxheVxuICAgIH0sXG4gICAgc2hvdWxkT3BlbjogZGVsYXkgPiAwID8gKCkgPT4gcGFyZW50TWVudVN0b3JlLnNlbGVjdCgnYWxsb3dNb3VzZUVudGVyJykgOiB1bmRlZmluZWQsXG4gICAgdHJpZ2dlckVsZW1lbnRSZWYsXG4gICAgZXh0ZXJuYWxUcmVlOiBmbG9hdGluZ1RyZWVSb290LFxuICAgIGlzQ2xvc2luZzogKCkgPT4gc3RvcmUuc2VsZWN0KCd0cmFuc2l0aW9uU3RhdHVzJykgPT09ICdlbmRpbmcnLFxuICAgIC8vIENocm9tZSBjYW4gZHJvcCB0aGUgdHJpZ2dlcidzIGBtb3VzZWxlYXZlYCBkdXJpbmcgYSBmYXN0IHBvaW50ZXIgc3dlZXAsXG4gICAgLy8gbGVhdmluZyBhIHN0YWxlIHN1Ym1lbnUgb3BlbiAoc2VlICM1MTUyKSDigJQgY2FuY2VsIGZyb20gYG1vdXNlb3V0YCB0b28uXG4gICAgZ3VhcmRTdGFsZU9wZW46IHRydWVcbiAgfSk7XG4gIGNvbnN0IGNsaWNrID0gdXNlQ2xpY2soZmxvYXRpbmdSb290Q29udGV4dCwge1xuICAgIGVuYWJsZWQ6ICFkaXNhYmxlZCxcbiAgICBldmVudDogJ21vdXNlZG93bicsXG4gICAgLy8gV2l0aG91dCB0b2dnbGluZywgVGFsa0JhY2sgdXNlcnMgY2Fubm90IGNsb3NlIHRoZSBzdWJtZW51IHRvIHJlYWNoIHRoZSBuZXh0IHBhcmVudCBtZW51XG4gICAgLy8gaXRlbTogbW92aW5nIHRoZSB2aXJ0dWFsIGN1cnNvciBvdXRzaWRlIGRvZXMgbm90IGNsb3NlIGl0LCBhbmQgbW92aW5nIGZvcndhcmQgYWdhaW5cbiAgICAvLyByZS1lbnRlcnMgdGhlIHN0aWxsLW9wZW4gc3VibWVudS4gS2VlcCB0b2dnbGluZyBlbmFibGVkIHNvIGFjdGl2YXRpbmcgaXRzIHRyaWdnZXIgY2xvc2VzIGl0LlxuICAgIC8vIFRvZ2dsaW5nIGFwcGxpZXMgdG8gdG91Y2ggYW5kIGtleWJvYXJkIGFjdGl2YXRpb24uIEluIGhvdmVyIG1vZGUsIG1vdXNlIHByZXNzZXMgYXJlXG4gICAgLy8gaWdub3JlZCBhbmQgdGhlIGZpcnN0IGFjdGl2YXRpb24gYWZ0ZXIgaG92ZXItb3BlbmluZyBrZWVwcyB0aGUgc3VibWVudSBvcGVuLlxuICAgIHRvZ2dsZTogdHJ1ZSxcbiAgICBpZ25vcmVNb3VzZTogb3Blbk9uSG92ZXIsXG4gICAgc3RpY2tJZk9wZW46IG9wZW5PbkhvdmVyXG4gIH0pO1xuICBjb25zdCBsb2NhbEludGVyYWN0aW9uUHJvcHMgPSBjbGljay5yZWZlcmVuY2UgPz8gRU1QVFlfT0JKRUNUO1xuICBjb25zdCByb290VHJpZ2dlclByb3BzID0gc3RvcmUudXNlU3RhdGUoJ3RyaWdnZXJQcm9wcycsIHRydWUpO1xuICBkZWxldGUgcm9vdFRyaWdnZXJQcm9wcy5pZDtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgZGlzYWJsZWQsXG4gICAgaGlnaGxpZ2h0ZWQsXG4gICAgb3BlblxuICB9O1xuICBjb25zdCBvcGVuTWV0aG9kID0gc3RvcmUudXNlU3RhdGUoJ29wZW5NZXRob2QnKTtcbiAgY29uc3QgbGFzdE9wZW5DaGFuZ2VSZWFzb24gPSBzdG9yZS51c2VTdGF0ZSgnbGFzdE9wZW5DaGFuZ2VSZWFzb24nKTtcbiAgLy8gQXJyb3cga2V5cyBvcGVuIHRoZSBzdWJtZW51IHRocm91Z2ggbGlzdCBuYXZpZ2F0aW9uIHdpdGhvdXQgZGlzcGF0Y2hpbmcgYSBjbGljaywgc29cbiAgLy8gYG9wZW5NZXRob2RgIHN0YXlzIG51bGwgdGhlcmU7IEVudGVyIGFuZCBTcGFjZSBkbyBkaXNwYXRjaCBvbmUgYW5kIHJlcG9ydCBga2V5Ym9hcmRgLlxuICBjb25zdCBvcGVuZWRCeUtleWJvYXJkID0gbGFzdE9wZW5DaGFuZ2VSZWFzb24gPT09IFJFQVNPTlMubGlzdE5hdmlnYXRpb24gfHwgb3Blbk1ldGhvZCA9PT0gJ2tleWJvYXJkJztcbiAgY29uc3Qgc2hvdWxkT21pdEV4cGFuZGVkID0gb3BlbiAmJiBvcGVuZWRCeUtleWJvYXJkICYmIHBsYXRmb3JtLnNjcmVlblJlYWRlci52b2ljZU92ZXI7XG4gIGNvbnN0IHN1Ym1lbnVLZXlEb3duUHJvcHMgPSBzdWJtZW51Um9vdENvbnRleHQ/Lm9uVHJpZ2dlcktleURvd24gPyB7XG4gICAgb25LZXlEb3duOiBzdWJtZW51Um9vdENvbnRleHQub25UcmlnZ2VyS2V5RG93blxuICB9IDogdW5kZWZpbmVkO1xuICBjb25zdCBlbGVtZW50ID0gdXNlUmVuZGVyRWxlbWVudCgnZGl2JywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICBzdGF0ZUF0dHJpYnV0ZXNNYXBwaW5nOiB0cmlnZ2VyT3BlblN0YXRlTWFwcGluZyxcbiAgICBwcm9wczogW2xvY2FsSW50ZXJhY3Rpb25Qcm9wcywgaG92ZXJQcm9wcywgcm9vdFRyaWdnZXJQcm9wcyxcbiAgICAvLyBNZW51RmlsdGVyU3VibWVudVJvb3Qgb3ZlcnJpZGVzIHRoZSBnZW5lcmljIHRyaWdnZXIgaGFuZGxlciBiZWNhdXNlIGVudHJ5IGFuZCBleGl0XG4gICAgLy8gZGVwZW5kIG9uIGJvdGggdGhlIHBhcmVudCBhbmQgY2hpbGQgbWVudSBvcmllbnRhdGlvbnMuXG4gICAgc3VibWVudUtleURvd25Qcm9wcywgaXRlbVByb3BzLFxuICAgIC8vIE9wZW5pbmcgYSBzdWJtZW51IGNoYW5nZXMgdGhlIHRyaWdnZXIncyBleHBhbmRlZCBzdGF0ZSB3aGlsZSB0aGUgdHJpZ2dlciBzdGlsbCBob2xkc1xuICAgIC8vIGZvY3VzLCBhbmQgVm9pY2VPdmVyIGFubm91bmNlcyB0aGF0IHN0YXRlIGNoYW5nZSBpbnN0ZWFkIG9mIHRoZSBzdWJtZW51IGl0ZW0gdGhhdCBmb2N1c1xuICAgIC8vIG1vdmVzIHRvIGEgbW9tZW50IGxhdGVyLCBzbyB0aGUgZmlyc3QgaXRlbSBpcyBuZXZlciBhbm5vdW5jZWQuIERyb3BwaW5nIHRoZSBzdGF0ZSB3aGlsZVxuICAgIC8vIHRoZSBzdWJtZW51IGlzIG9wZW4gYXZvaWRzIHRoZSBhbm5vdW5jZW1lbnQgd2l0aG91dCBjbGFpbWluZyB0aGUgc3VibWVudSBpcyBjb2xsYXBzZWQ7XG4gICAgLy8gYGFyaWEtaGFzcG9wdXBgIHN0aWxsIGNvbnZleXMgdGhhdCB0aGUgaXRlbSBvcGVucyBhIHN1Ym1lbnUuXG4gICAgc2hvdWxkT21pdEV4cGFuZGVkID8gVk9JQ0VfT1ZFUl9FWFBBTkRFRF9QUk9QUyA6IHVuZGVmaW5lZCwge1xuICAgICAgJ2FyaWEtY29udHJvbHMnOiBwb3B1cElkLFxuICAgICAgLy8gQSB2aXJ0dWFsbHkgZm9jdXNlZCBwYXJlbnQga2VlcHMgcmVhbCBmb2N1cyBvbiBpdHMgaW5wdXQsIHNvIHRoZSB0cmlnZ2VyIG11c3Qgc3RheSBvdXRcbiAgICAgIC8vIG9mIHRoZSB0YWIgb3JkZXIuXG4gICAgICB0YWJJbmRleDogcGFyZW50VmlydHVhbEZvY3VzIHx8ICEob3BlbiB8fCBoaWdobGlnaHRlZCkgPyAtMSA6IDAsXG4gICAgICBvbkZvY3VzKGV2ZW50KSB7XG4gICAgICAgIC8vIENsb3NlIHdoZW4gZm9jdXMgcmV0dXJucyB0aHJvdWdoIHRoZSBzdWJtZW51J3MgZ3VhcmQgdG8gaXRzIHRyaWdnZXIuIFRoaXMgYWxzbyBsZXRzXG4gICAgICAgIC8vIHNjcmVlbiByZWFkZXIgdXNlcnMgbW92ZSBwYXN0IHRoZSB0cmlnZ2VyIGluIHRoZSBwYXJlbnQgbWVudS4gRGlyZWN0IGZvY3VzIGZyb20gYVxuICAgICAgICAvLyBzdWJtZW51IGl0ZW0sIHN1Y2ggYXMgb24gaG92ZXIsIGxlYXZlcyB0aGUgc3VibWVudSBvcGVuLlxuICAgICAgICBpZiAoc3RvcmUuc2VsZWN0KCdvcGVuJykgJiYgZm9jdXNSZXR1cm5lZFRocm91Z2hHdWFyZFJlZi5jdXJyZW50KSB7XG4gICAgICAgICAgZm9jdXNSZXR1cm5lZFRocm91Z2hHdWFyZFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gICAgICAgICAgc3RvcmUuc2V0T3BlbihmYWxzZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuZm9jdXNPdXQsIGV2ZW50Lm5hdGl2ZUV2ZW50KSk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBvbkJsdXIoKSB7XG4gICAgICAgIGlmIChoaWdobGlnaHRlZCkge1xuICAgICAgICAgIHBhcmVudE1lbnVTdG9yZS5zZXRBY3RpdmVJbmRleChudWxsLCBSRUFTT05TLm5vbmUpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSwgZWxlbWVudFByb3BzLFxuICAgIC8vIGBnZXRJdGVtUHJvcHNgIHN0YXlzIGxhc3Qgc28gYHVzZUJ1dHRvbmAga2VlcHMgZ2F0aW5nIGNvbnN1bWVyIGhhbmRsZXJzIHdoaWxlIGRpc2FibGVkLlxuICAgIGdldEl0ZW1Qcm9wc10sXG4gICAgcmVmOiBbZm9yd2FyZGVkUmVmLCBsaXN0SXRlbS5yZWYsIGl0ZW1SZWYsIHJlZ2lzdGVyVHJpZ2dlciwgaGFuZGxlVHJpZ2dlckVsZW1lbnRSZWZdXG4gIH0pO1xuICByZXR1cm4gZWxlbWVudDtcbn0pO1xuXG4vKipcbiAqIEEgbWVudSBpdGVtIHRoYXQgb3BlbnMgYSBzdWJtZW51LlxuICogUmVuZGVycyBhIGA8ZGl2PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBNZW51XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvbWVudSlcbiAqL1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgTWVudVN1Ym1lbnVUcmlnZ2VyUGxhaW4uZGlzcGxheU5hbWUgPSBcIk1lbnVTdWJtZW51VHJpZ2dlclBsYWluXCI7XG5leHBvcnQgY29uc3QgTWVudVN1Ym1lbnVUcmlnZ2VyID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gTWVudVN1Ym1lbnVUcmlnZ2VyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3QgZmlsdGVySXRlbSA9IHVzZU1lbnVGaWx0ZXJJdGVtKHByb3BzLCBmb3J3YXJkZWRSZWYsICdzdWJtZW51LXRyaWdnZXInKTtcbiAgaWYgKCFmaWx0ZXJJdGVtLnZpc2libGUpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICBjb25zdCBtZXJnZWRQcm9wcyA9IGZpbHRlckl0ZW0ucHJvcHMgPyBtZXJnZVByb3BzKGZpbHRlckl0ZW0ucHJvcHMsIHByb3BzKSA6IHByb3BzO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goTWVudVN1Ym1lbnVUcmlnZ2VyUGxhaW4sIHtcbiAgICAuLi5tZXJnZWRQcm9wcyxcbiAgICByZWY6IGZpbHRlckl0ZW0ucmVmXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51U3VibWVudVRyaWdnZXIuZGlzcGxheU5hbWUgPSBcIk1lbnVTdWJtZW51VHJpZ2dlclwiOyIsImltcG9ydCB7IGNyZWF0ZU51bGxNZW51U3RvcmUgfSBmcm9tIFwiLi9NZW51U3RvcmUubWpzXCI7XG5pbXBvcnQgeyBCYXNlUG9wdXBIYW5kbGUgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBzL3BvcHVwSGFuZGxlLm1qc1wiO1xuXG4vKipcbiAqIENvbnRyb2xzIGEgTWVudSBpbXBlcmF0aXZlbHkgYW5kIGFzc29jaWF0ZXMgZGV0YWNoZWQgYE1lbnUuVHJpZ2dlcmAgY29tcG9uZW50cyB3aXRoIGEgYE1lbnUuUm9vdGAuXG4gKiBDcmVhdGUgb25lIHdpdGggYE1lbnUuY3JlYXRlSGFuZGxlKClgIGFuZCBwYXNzIGl0IHRvIHRoZSBgaGFuZGxlYCBwcm9wIG9mIHRoZSByb290IGFuZCBvZiBhbnlcbiAqIHRyaWdnZXJzIHJlbmRlcmVkIG91dHNpZGUgb2YgaXQuXG4gKlxuICogVGhlIGltcGVyYXRpdmUgbWV0aG9kcyB0YWtlIGVmZmVjdCBvbmx5IHdoaWxlIGEgcm9vdCB1c2luZyB0aGlzIGhhbmRsZSBpcyBtb3VudGVkOyBjYWxscyBtYWRlXG4gKiBiZWZvcmUgYSByb290IGF0dGFjaGVzIChvciBhZnRlciBpdCB1bm1vdW50cykgYXJlIGlnbm9yZWQuXG4gKi9cbmV4cG9ydCBjbGFzcyBNZW51SGFuZGxlIGV4dGVuZHMgQmFzZVBvcHVwSGFuZGxlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoY3JlYXRlTnVsbE1lbnVTdG9yZSgpLCAnTWVudScpO1xuICB9XG5cbiAgLyoqXG4gICAqIE9wZW5zIHRoZSBtZW51IGFuZCBhc3NvY2lhdGVzIGl0IHdpdGggdGhlIHRyaWdnZXIgd2l0aCB0aGUgZ2l2ZW4gaWQuXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBpbiBhbiBldmVudCBoYW5kbGVyIG9yIGFuIGVmZmVjdCAobm90IGR1cmluZyByZW5kZXJpbmcpLlxuICAgKlxuICAgKiBAcGFyYW0gdHJpZ2dlcklkIElEIG9mIHRoZSB0cmlnZ2VyIHRvIGFzc29jaWF0ZSB3aXRoIHRoZSBtZW51LiBUaGUgdHJpZ2dlciBtdXN0IGJlIGEgbWF0Y2hpbmdcbiAgICogYE1lbnUuVHJpZ2dlcmAgd2l0aCB0aGlzIGhhbmRsZSBwYXNzZWQgYXMgYSBwcm9wLlxuICAgKi9cbiAgb3Blbih0cmlnZ2VySWQpIHtcbiAgICB0aGlzLm9wZW5CeVRyaWdnZXIodHJpZ2dlcklkKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDbG9zZXMgdGhlIG1lbnUuXG4gICAqXG4gICAqIFRoaXMgbWV0aG9kIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBpbiBhbiBldmVudCBoYW5kbGVyIG9yIGFuIGVmZmVjdCAobm90IGR1cmluZyByZW5kZXJpbmcpLlxuICAgKi9cbiAgY2xvc2UoKSB7XG4gICAgdGhpcy5jbG9zZVBvcHVwKCk7XG4gIH1cblxuICAvKipcbiAgICogV2hldGhlciB0aGUgbWVudSBpcyBjdXJyZW50bHkgb3Blbi4gUmV0dXJucyBgZmFsc2VgIHdoaWxlIG5vIHJvb3QgaXMgYXR0YWNoZWQgdG8gdGhlIGhhbmRsZS5cbiAgICovXG4gIGdldCBpc09wZW4oKSB7XG4gICAgcmV0dXJuIHRoaXMuYXR0YWNoZWRTdG9yZT8uc2VsZWN0KCdvcGVuJykgPz8gZmFsc2U7XG4gIH1cbn1cblxuLyoqXG4gKiBDcmVhdGVzIGEgbmV3IGhhbmRsZSB0byBjb25uZWN0IGEgTWVudS5Sb290IHdpdGggZGV0YWNoZWQgTWVudS5UcmlnZ2VyIGNvbXBvbmVudHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVNZW51SGFuZGxlKCkge1xuICByZXR1cm4gbmV3IE1lbnVIYW5kbGUoKTtcbn0iLCJleHBvcnQgZnVuY3Rpb24gc3RyaW5naWZ5TG9jYWxlKGxvY2FsZSkge1xuICBpZiAoQXJyYXkuaXNBcnJheShsb2NhbGUpKSB7XG4gICAgcmV0dXJuIGxvY2FsZS5tYXAodmFsdWUgPT4gc3RyaW5naWZ5TG9jYWxlKHZhbHVlKSkuam9pbignLCcpO1xuICB9XG4gIGlmIChsb2NhbGUgPT0gbnVsbCkge1xuICAgIHJldHVybiAnJztcbiAgfVxuICByZXR1cm4gU3RyaW5nKGxvY2FsZSk7XG59IiwiaW1wb3J0IHsgc3RyaW5naWZ5TG9jYWxlIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvc3RyaW5naWZ5TG9jYWxlJztcbmltcG9ydCB7IHN0cmluZ2lmeUFzTGFiZWwgfSBmcm9tIFwiLi9yZXNvbHZlVmFsdWVMYWJlbC5tanNcIjtcbmNvbnN0IGZpbHRlckNhY2hlID0gbmV3IE1hcCgpO1xuZXhwb3J0IGZ1bmN0aW9uIGdldEZpbHRlcihvcHRpb25zID0ge30pIHtcbiAgY29uc3Qge1xuICAgIGxvY2FsZSxcbiAgICAuLi5yZXN0T3B0aW9uc1xuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgY29sbGF0b3JPcHRpb25zID0ge1xuICAgIHVzYWdlOiAnc2VhcmNoJyxcbiAgICBzZW5zaXRpdml0eTogJ2Jhc2UnLFxuICAgIGlnbm9yZVB1bmN0dWF0aW9uOiB0cnVlLFxuICAgIC4uLnJlc3RPcHRpb25zXG4gIH07XG4gIGNvbnN0IGNhY2hlS2V5ID0gYCR7c3RyaW5naWZ5TG9jYWxlKGxvY2FsZSl9fCR7SlNPTi5zdHJpbmdpZnkoY29sbGF0b3JPcHRpb25zKX1gO1xuICBjb25zdCBjYWNoZWRGaWx0ZXIgPSBmaWx0ZXJDYWNoZS5nZXQoY2FjaGVLZXkpO1xuICBpZiAoY2FjaGVkRmlsdGVyKSB7XG4gICAgcmV0dXJuIGNhY2hlZEZpbHRlcjtcbiAgfVxuICBjb25zdCBjb2xsYXRvciA9IG5ldyBJbnRsLkNvbGxhdG9yKGxvY2FsZSwgY29sbGF0b3JPcHRpb25zKTtcbiAgY29uc3QgZmlsdGVyID0ge1xuICAgIGNvbnRhaW5zKGl0ZW0sIHF1ZXJ5LCBpdGVtVG9TdHJpbmcpIHtcbiAgICAgIGlmICghcXVlcnkpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBjb25zdCBpdGVtU3RyaW5nID0gc3RyaW5naWZ5QXNMYWJlbChpdGVtLCBpdGVtVG9TdHJpbmcpO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPD0gaXRlbVN0cmluZy5sZW5ndGggLSBxdWVyeS5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICBpZiAoY29sbGF0b3IuY29tcGFyZShpdGVtU3RyaW5nLnNsaWNlKGksIGkgKyBxdWVyeS5sZW5ndGgpLCBxdWVyeSkgPT09IDApIHtcbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0sXG4gICAgc3RhcnRzV2l0aChpdGVtLCBxdWVyeSwgaXRlbVRvU3RyaW5nKSB7XG4gICAgICBpZiAoIXF1ZXJ5KSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgfVxuICAgICAgY29uc3QgaXRlbVN0cmluZyA9IHN0cmluZ2lmeUFzTGFiZWwoaXRlbSwgaXRlbVRvU3RyaW5nKTtcbiAgICAgIHJldHVybiBjb2xsYXRvci5jb21wYXJlKGl0ZW1TdHJpbmcuc2xpY2UoMCwgcXVlcnkubGVuZ3RoKSwgcXVlcnkpID09PSAwO1xuICAgIH0sXG4gICAgZW5kc1dpdGgoaXRlbSwgcXVlcnksIGl0ZW1Ub1N0cmluZykge1xuICAgICAgaWYgKCFxdWVyeSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGl0ZW1TdHJpbmcgPSBzdHJpbmdpZnlBc0xhYmVsKGl0ZW0sIGl0ZW1Ub1N0cmluZyk7XG4gICAgICBjb25zdCBxdWVyeUxlbmd0aCA9IHF1ZXJ5Lmxlbmd0aDtcbiAgICAgIHJldHVybiBpdGVtU3RyaW5nLmxlbmd0aCA+PSBxdWVyeUxlbmd0aCAmJiBjb2xsYXRvci5jb21wYXJlKGl0ZW1TdHJpbmcuc2xpY2UoaXRlbVN0cmluZy5sZW5ndGggLSBxdWVyeUxlbmd0aCksIHF1ZXJ5KSA9PT0gMDtcbiAgICB9XG4gIH07XG4gIGZpbHRlckNhY2hlLnNldChjYWNoZUtleSwgZmlsdGVyKTtcbiAgcmV0dXJuIGZpbHRlcjtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVJlZldpdGhJbml0JztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuLyoqXG4gKiBDb2xsZWN0cyBpdGVtIHJlZ2lzdHJhdGlvbnMgaW50byBvbmUgaW1tdXRhYmxlIHNuYXBzaG90IHBlciBSZWFjdCBjb21taXQuXG4gKiBBbHNvIHJldHVybnMgdGhlIGxpdmUgcmVnaXN0cnkgZm9yIHJlYWRzIHRoYXQgbXVzdCBpbmNsdWRlIHRoZSByZWdpc3RyYXRpb25zIG9mIHRoZSBjdXJyZW50XG4gKiBjb21taXQgYmVmb3JlIGl0cyBzbmFwc2hvdCBpcyBwdWJsaXNoZWQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VJdGVtUmVnaXN0cnkoKSB7XG4gIGNvbnN0IGl0ZW1SZWdpc3RyeSA9IHVzZVJlZldpdGhJbml0KCgpID0+IG5ldyBNYXAoKSkuY3VycmVudDtcbiAgY29uc3QgW3JlZ2lzdHJ5VmVyc2lvbiwgc2V0UmVnaXN0cnlWZXJzaW9uXSA9IFJlYWN0LnVzZVN0YXRlKDApO1xuICBjb25zdCBpc1VwZGF0ZVNjaGVkdWxlZFJlZiA9IFJlYWN0LnVzZVJlZihmYWxzZSk7XG5cbiAgLy8gSXRlbSBlZmZlY3RzIGNhbiBydW4gd2l0aG91dCB0aGVpciBwYXJlbnQgcmVuZGVyaW5nLiBTY2hlZHVsZSBvbmUgc3luY2hyb25vdXMgcGFyZW50XG4gIC8vIHVwZGF0ZSBmb3IgdGhlIHdob2xlIGNvbW1pdCBzbyBldmVyeSByZWdpc3RyYXRpb24gaXMgaW5jbHVkZWQgaW4gdGhlIG5leHQgc25hcHNob3QuXG4gIGNvbnN0IHNjaGVkdWxlUmVnaXN0cnlVcGRhdGUgPSB1c2VTdGFibGVDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKGlzVXBkYXRlU2NoZWR1bGVkUmVmLmN1cnJlbnQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaXNVcGRhdGVTY2hlZHVsZWRSZWYuY3VycmVudCA9IHRydWU7XG4gICAgc2V0UmVnaXN0cnlWZXJzaW9uKHZlcnNpb24gPT4gdmVyc2lvbiArIDEpO1xuICB9KTtcbiAgY29uc3QgcmVnaXN0ZXJJdGVtID0gdXNlU3RhYmxlQ2FsbGJhY2soKGtleSwgaXRlbSkgPT4ge1xuICAgIGl0ZW1SZWdpc3RyeS5zZXQoa2V5LCBpdGVtKTtcbiAgICBzY2hlZHVsZVJlZ2lzdHJ5VXBkYXRlKCk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIGl0ZW1SZWdpc3RyeS5kZWxldGUoa2V5KTtcbiAgICAgIHNjaGVkdWxlUmVnaXN0cnlVcGRhdGUoKTtcbiAgICB9O1xuICB9KTtcbiAgY29uc3QgcmVnaXN0ZXJlZEl0ZW1zID0gUmVhY3QudXNlTWVtbygoKSA9PiBuZXcgTWFwKGl0ZW1SZWdpc3RyeSksXG4gIC8vIFRoZSBtdXRhYmxlIHJlZ2lzdHJ5IGlzIHN0YWJsZS4gSXRzIHZlcnNpb24gZXhwbGljaXRseSBjb250cm9scyB3aGVuIHRvIHB1Ymxpc2ggYSBjb3B5LlxuICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gIFtyZWdpc3RyeVZlcnNpb25dKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpc1VwZGF0ZVNjaGVkdWxlZFJlZi5jdXJyZW50ID0gZmFsc2U7XG4gIH0sIFtyZWdpc3RyeVZlcnNpb25dKTtcbiAgcmV0dXJuIHtcbiAgICBpdGVtczogcmVnaXN0ZXJlZEl0ZW1zLFxuICAgIHJlZ2lzdGVySXRlbSxcbiAgICBsaXZlSXRlbXM6IGl0ZW1SZWdpc3RyeVxuICB9O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IF9mb3JtYXRFcnJvck1lc3NhZ2UgZnJvbSBcIkBiYXNlLXVpL3V0aWxzL2Zvcm1hdEVycm9yTWVzc2FnZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuZnVuY3Rpb24gdGhyb3dNaXNzaW5nRmlsdGVyUm9vdCgpIHtcbiAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/ICdCYXNlIFVJOiBGaWx0ZXIgcGFydHMgYXJlIG1pc3NpbmcgdGhlaXIgZmlsdGVyIGNvbnRleHQgYW5kIGNhbm5vdCBhY2Nlc3MgdGhlIHF1ZXJ5IG9yIGl0ZW1zLiAnICsgJ1dyYXAgdGhlIGNvbXBvbmVudCByb290IGluIGl0cyBmaWx0ZXIgcHJvdmlkZXIuJyA6IF9mb3JtYXRFcnJvck1lc3NhZ2UoMTAzKSk7XG59XG5leHBvcnQgY29uc3QgRmlsdGVyRHJvcGRvd25JdGVtQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRmlsdGVyRHJvcGRvd25JdGVtQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiRmlsdGVyRHJvcGRvd25JdGVtQ29udGV4dFwiO1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUZpbHRlckRyb3Bkb3duSXRlbUNvbnRleHQob3B0aW9uYWwgPSBmYWxzZSkge1xuICBjb25zdCBjb250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChGaWx0ZXJEcm9wZG93bkl0ZW1Db250ZXh0KTtcbiAgaWYgKGNvbnRleHQgPT09IG51bGwgJiYgIW9wdGlvbmFsKSB7XG4gICAgdGhyb3dNaXNzaW5nRmlsdGVyUm9vdCgpO1xuICB9XG4gIHJldHVybiBjb250ZXh0O1xufVxuZXhwb3J0IGNvbnN0IEZpbHRlckRyb3Bkb3duUm9vdENvbnRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlQ29udGV4dChudWxsKTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIEZpbHRlckRyb3Bkb3duUm9vdENvbnRleHQuZGlzcGxheU5hbWUgPSBcIkZpbHRlckRyb3Bkb3duUm9vdENvbnRleHRcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VGaWx0ZXJEcm9wZG93blJvb3RDb250ZXh0KG9wdGlvbmFsID0gZmFsc2UpIHtcbiAgY29uc3QgY29udGV4dCA9IFJlYWN0LnVzZUNvbnRleHQoRmlsdGVyRHJvcGRvd25Sb290Q29udGV4dCk7XG4gIGlmIChjb250ZXh0ID09PSBudWxsICYmICFvcHRpb25hbCkge1xuICAgIHRocm93TWlzc2luZ0ZpbHRlclJvb3QoKTtcbiAgfVxuICByZXR1cm4gY29udGV4dDtcbn1cblxuLyoqXG4gKiBGaW5kcyB0aGUgZHJvcGRvd24gdGhhdCBvd25zIHRoZSBnaXZlbiBpdGVtIGxpc3QsIHdhbGtpbmcgb3V0IHRocm91Z2ggbmVzdGVkIHJvb3RzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlRmlsdGVyQ29udGV4dEZvckxpc3QobGlzdFJlZikge1xuICBsZXQgY29udGV4dCA9IFJlYWN0LnVzZUNvbnRleHQoRmlsdGVyRHJvcGRvd25JdGVtQ29udGV4dCk7XG4gIGlmIChsaXN0UmVmID09PSBudWxsKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgd2hpbGUgKGNvbnRleHQgIT09IG51bGwgJiYgY29udGV4dC5saXN0UmVmICE9PSBsaXN0UmVmKSB7XG4gICAgY29udGV4dCA9IGNvbnRleHQucGFyZW50O1xuICB9XG4gIHJldHVybiBjb250ZXh0O1xufVxuXG4vLyBgdmFsdWVgIGNvbnRyb2xzIGEgbmF0aXZlIGlucHV0IGFuZCBjYW4ndCBiZSBwbGFjZWQgaW4gdGhlIHN0b3JlIHdpdGhvdXQgYnJlYWtpbmcgdGhlIGNhcmV0XG4vLyBwb3NpdGlvbiB3aGVuIHRoZSBpbnB1dCBpcyBjb250cm9sbGVkLlxuLy8gaHR0cHM6Ly9naXRodWIuY29tL211aS9iYXNlLXVpL2lzc3Vlcy8yNzAzXG5leHBvcnQgY29uc3QgRmlsdGVyRHJvcGRvd25WYWx1ZUNvbnRleHQgPSAvKiNfX1BVUkVfXyovUmVhY3QuY3JlYXRlQ29udGV4dCgnJyk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBGaWx0ZXJEcm9wZG93blZhbHVlQ29udGV4dC5kaXNwbGF5TmFtZSA9IFwiRmlsdGVyRHJvcGRvd25WYWx1ZUNvbnRleHRcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VGaWx0ZXJEcm9wZG93blZhbHVlQ29udGV4dCgpIHtcbiAgcmV0dXJuIFJlYWN0LnVzZUNvbnRleHQoRmlsdGVyRHJvcGRvd25WYWx1ZUNvbnRleHQpO1xufVxuZXhwb3J0IGxldCBGaWx0ZXJEcm9wZG93blJvb3Q7IiwiaW1wb3J0IHsgUmVhY3RTdG9yZSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3N0b3JlJztcbmltcG9ydCB7IEVNUFRZX09CSkVDVCwgTk9PUCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL2VtcHR5JztcbmV4cG9ydCBjb25zdCBzZWxlY3RvcnMgPSB7XG4gIC8vIEEgbnVsbCBgdmlzaWJsZUl0ZW1JZHNgIG1lYW5zIG5vIHF1ZXJ5LCBzbyBmYWxsIGJhY2sgdG8gd2hldGhlciBhbnl0aGluZyByZWdpc3RlcmVkLlxuICBpc0VtcHR5OiBzdGF0ZSA9PiBzdGF0ZS52aXNpYmxlSXRlbUlkcyA9PT0gbnVsbCA/IHN0YXRlLnJlZ2lzdGVyZWRJdGVtQ291bnQgPT09IDAgOiBzdGF0ZS52aXNpYmxlSXRlbUlkcy5zaXplID09PSAwLFxuICBpc0l0ZW1WaXNpYmxlOiAoc3RhdGUsIGlkKSA9PiBzdGF0ZS52aXNpYmxlSXRlbUlkcyA9PT0gbnVsbCB8fCBzdGF0ZS52aXNpYmxlSXRlbUlkcy5oYXMoaWQpXG59O1xuZXhwb3J0IGNsYXNzIEZpbHRlckRyb3Bkb3duU3RvcmUgZXh0ZW5kcyBSZWFjdFN0b3JlIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoe1xuICAgICAgdmlzaWJsZUl0ZW1JZHM6IG51bGwsXG4gICAgICByZWdpc3RlcmVkSXRlbUNvdW50OiAwXG4gICAgfSwgRU1QVFlfT0JKRUNULCBzZWxlY3RvcnMpO1xuICB9XG59XG5cbi8qKlxuICogU3RhbmQtaW4gZm9yIGFuIGl0ZW0gd2hvc2Ugb3duaW5nIGRyb3Bkb3duIGlzIGFic2VudCwgc3VjaCBhcyBhIGZpbHRlcmFibGUgc3VibWVudSdzIHRyaWdnZXJcbiAqIGluc2lkZSBhIHBsYWluIHBhcmVudCBtZW51LiBOb3RoaW5nIHJlZ2lzdGVycyBhbmQgZXZlcnkgaXRlbSBzdGF5cyB2aXNpYmxlLlxuICovXG5leHBvcnQgY29uc3QgREVUQUNIRURfT1dORVIgPSB7XG4gIHJlZ2lzdGVySXRlbTogKCkgPT4gTk9PUCxcbiAgc3RvcmU6IG5ldyBGaWx0ZXJEcm9wZG93blN0b3JlKClcbn07IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVJlZldpdGhJbml0JztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IGdldEZpbHRlciB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvZmlsdGVyLm1qc1wiO1xuaW1wb3J0IHsgdXNlQmFzZVVpSWQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZUJhc2VVaUlkLm1qc1wiO1xuaW1wb3J0IHsgdXNlSXRlbVJlZ2lzdHJ5IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VJdGVtUmVnaXN0cnkubWpzXCI7XG5pbXBvcnQgeyBGaWx0ZXJEcm9wZG93blJvb3RDb250ZXh0LCBGaWx0ZXJEcm9wZG93bkl0ZW1Db250ZXh0LCBGaWx0ZXJEcm9wZG93blZhbHVlQ29udGV4dCB9IGZyb20gXCIuL0ZpbHRlckRyb3Bkb3duUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBGaWx0ZXJEcm9wZG93blN0b3JlIH0gZnJvbSBcIi4uL3N0b3JlLm1qc1wiO1xuXG4vKipcbiAqIEhvbGRzIHRoZSBmaWx0ZXIgcXVlcnksIG1hdGNoZXMgaXQgYWdhaW5zdCB0aGUgcmVnaXN0ZXJlZCBpdGVtcywgYW5kIHB1Ymxpc2hlcyB0aGUgcmVzdWx0LiBUaGVcbiAqIGhvc3Qgb3ducyBsaXN0IG5hdmlnYXRpb247IHRoaXMgcm9vdCBtb3ZlcyB0aGUgaGlnaGxpZ2h0IHRocm91Z2ggYHNldEFjdGl2ZUluZGV4YC5cbiAqXG4gKiBAaW50ZXJuYWxcbiAqL1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCBmdW5jdGlvbiBGaWx0ZXJEcm9wZG93blJvb3QocHJvcHMpIHtcbiAgY29uc3Qge1xuICAgIGNoaWxkcmVuLFxuICAgIG9wZW4sXG4gICAgZGlzYWJsZWQgPSBmYWxzZSxcbiAgICBvcGVuZWRCeUtleWJvYXJkID0gZmFsc2UsXG4gICAgbG9jYWxlLFxuICAgIHZhbHVlLFxuICAgIHF1ZXJ5LFxuICAgIG9uVmFsdWVDaGFuZ2UsXG4gICAgZmlsdGVyLFxuICAgIGF1dG9IaWdobGlnaHQgPSBmYWxzZSxcbiAgICB0cmlnZ2VySWQ6IHRyaWdnZXJJZFByb3AsXG4gICAgbGlzdFJlZixcbiAgICBnZXRBY3RpdmVJbmRleCxcbiAgICBzZXRBY3RpdmVJbmRleCxcbiAgICBmb2N1c093bmVyUmVmOiBmb2N1c093bmVyUmVmUHJvcFxuICB9ID0gcHJvcHM7XG4gIGNvbnN0IHBhcmVudEl0ZW1Db250ZXh0ID0gUmVhY3QudXNlQ29udGV4dChGaWx0ZXJEcm9wZG93bkl0ZW1Db250ZXh0KTtcbiAgY29uc3QgW3JlbmRlcmVkTGlzdElkLCBzZXRSZW5kZXJlZExpc3RJZF0gPSBSZWFjdC51c2VTdGF0ZSh1bmRlZmluZWQpO1xuICBjb25zdCBbaW5wdXRGb2N1c1Zpc2libGUsIHNldElucHV0Rm9jdXNWaXNpYmxlXSA9IFJlYWN0LnVzZVN0YXRlKG9wZW5lZEJ5S2V5Ym9hcmQpO1xuICBjb25zdCBba2V5Ym9hcmRNb2RhbGl0eSwgc2V0S2V5Ym9hcmRNb2RhbGl0eV0gPSBSZWFjdC51c2VTdGF0ZShvcGVuZWRCeUtleWJvYXJkKTtcbiAgY29uc3QgW3ByZXZpb3VzT3BlbmVkQnlLZXlib2FyZCwgc2V0UHJldmlvdXNPcGVuZWRCeUtleWJvYXJkXSA9IFJlYWN0LnVzZVN0YXRlKG9wZW5lZEJ5S2V5Ym9hcmQpO1xuXG4gIC8vIEJvdGggcmVzZXQgd2hlbiB0aGUgaG9zdCByZXBvcnRzIGEgbmV3IHZhbHVlOyBkb2luZyBpdCBkdXJpbmcgcmVuZGVyIHNraXBzIGFuIGV4dHJhIGNvbW1pdC5cbiAgaWYgKG9wZW5lZEJ5S2V5Ym9hcmQgIT09IHByZXZpb3VzT3BlbmVkQnlLZXlib2FyZCkge1xuICAgIHNldFByZXZpb3VzT3BlbmVkQnlLZXlib2FyZChvcGVuZWRCeUtleWJvYXJkKTtcbiAgICBzZXRJbnB1dEZvY3VzVmlzaWJsZShvcGVuZWRCeUtleWJvYXJkKTtcbiAgICBzZXRLZXlib2FyZE1vZGFsaXR5KG9wZW5lZEJ5S2V5Ym9hcmQpO1xuICB9XG4gIGNvbnN0IHtcbiAgICBpdGVtczogcmVnaXN0ZXJlZEl0ZW1zLFxuICAgIHJlZ2lzdGVySXRlbTogcmVnaXN0ZXJJblJlZ2lzdHJ5LFxuICAgIGxpdmVJdGVtc1xuICB9ID0gdXNlSXRlbVJlZ2lzdHJ5KCk7XG4gIGNvbnN0IGRlZmF1bHRJZCA9IHVzZUJhc2VVaUlkKCk7XG4gIGNvbnN0IHN0b3JlID0gdXNlUmVmV2l0aEluaXQoKCkgPT4gbmV3IEZpbHRlckRyb3Bkb3duU3RvcmUoKSkuY3VycmVudDtcblxuICAvLyBUaGUgY291bnQgaXMgcHVibGlzaGVkIGFzIGl0ZW1zIHJlZ2lzdGVyLCBub3Qgd2l0aCB0aGUgbmV4dCByZWdpc3RyeSBzbmFwc2hvdCwgc28gYVxuICAvLyBgTWVudS5FbXB0eWAgbW91bnRpbmcgYWxvbmdzaWRlIHRoZSBpdGVtcyBuZXZlciByZWFkcyBhIHN0YWxlIHplcm8uXG4gIGNvbnN0IHJlZ2lzdGVySXRlbSA9IHVzZVN0YWJsZUNhbGxiYWNrKChpZCwgaXRlbSkgPT4ge1xuICAgIGNvbnN0IHVucmVnaXN0ZXIgPSByZWdpc3RlckluUmVnaXN0cnkoaWQsIGl0ZW0pO1xuICAgIHN0b3JlLnNldCgncmVnaXN0ZXJlZEl0ZW1Db3VudCcsIGxpdmVJdGVtcy5zaXplKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgdW5yZWdpc3RlcigpO1xuICAgICAgc3RvcmUuc2V0KCdyZWdpc3RlcmVkSXRlbUNvdW50JywgbGl2ZUl0ZW1zLnNpemUpO1xuICAgIH07XG4gIH0pO1xuICBjb25zdCBmYWxsYmFja0ZvY3VzT3duZXJSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGxhc3RGaWx0ZXJRdWVyeVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgY29uc3QgZGVmYXVsdE1hdGNoSXRlbSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gZ2V0RmlsdGVyKHtcbiAgICBsb2NhbGVcbiAgfSkuY29udGFpbnMsIFtsb2NhbGVdKTtcbiAgY29uc3QgZm9jdXNPd25lclJlZiA9IGZvY3VzT3duZXJSZWZQcm9wID8/IGZhbGxiYWNrRm9jdXNPd25lclJlZjtcbiAgY29uc3QgZmlsdGVyUXVlcnkgPSAocXVlcnkgPz8gdmFsdWUpLnRyaW0oKTtcbiAgLy8gQW4gdW51c2VkIGlubGluZSBmaWx0ZXIgbXVzdCBub3QgcmUtcnVuIGF1dG8taGlnaGxpZ2h0aW5nIHdoZW4gdGhlIGNvbnN1bWVyIHJlLXJlbmRlcnMuXG4gIGNvbnN0IG1hdGNoSXRlbSA9IGZpbHRlclF1ZXJ5ID09PSAnJyB8fCBmaWx0ZXIgPT09IG51bGwgPyBudWxsIDogZmlsdGVyID8/IGRlZmF1bHRNYXRjaEl0ZW07XG4gIGNvbnN0IGF1dG9IaWdobGlnaHRFbmFibGVkID0gb3BlbiAmJiAoYXV0b0hpZ2hsaWdodCA9PT0gJ2Fsd2F5cycgfHwgYXV0b0hpZ2hsaWdodCAmJiBmaWx0ZXJRdWVyeSAhPT0gJycpO1xuICAvLyBSZWFjdCAxNyByZXNvbHZlcyBnZW5lcmF0ZWQgaWRzIGluIGFuIGVmZmVjdCwgc28gdGhleSBtdXN0IGJlIHJlYWQgbGl2ZSByYXRoZXIgdGhhbiBjYXB0dXJlZFxuICAvLyBpbiBhIHN0YXRlIGluaXRpYWxpemVyLlxuICBjb25zdCBkZWZhdWx0TGlzdElkID0gZGVmYXVsdElkID8gYCR7ZGVmYXVsdElkfS1saXN0YCA6IHVuZGVmaW5lZDtcbiAgY29uc3QgbGlzdElkID0gKHJlbmRlcmVkTGlzdElkID8/IGRlZmF1bHRMaXN0SWQpIHx8IHVuZGVmaW5lZDtcbiAgLy8gVGhlIGhvc3Qgb3ducyB0aGUgdHJpZ2dlci4gYG51bGxgIGFuZCBgJydgIGJvdGggbWVhbiBubyBlbGVtZW50IGNhcnJpZXMgYW4gaWQgdG8gcG9pbnQgYXQuXG4gIGNvbnN0IHRyaWdnZXJJZCA9IHRyaWdnZXJJZFByb3AgfHwgdW5kZWZpbmVkO1xuICBjb25zdCBoYW5kbGVWYWx1ZUNoYW5nZSA9IHVzZVN0YWJsZUNhbGxiYWNrKChuZXh0VmFsdWUsIGV2ZW50RGV0YWlscykgPT4ge1xuICAgIG9uVmFsdWVDaGFuZ2U/LihuZXh0VmFsdWUsIGV2ZW50RGV0YWlscyk7XG4gICAgLy8gSW5kZXhlcyBhcmUgcG9zaXRpb25hbCwgc28gYSBrZXB0IGhpZ2hsaWdodCB3b3VsZCBsYW5kIG9uIHdoYXRldmVyIGZpbGxzIGl0cyBzbG90LlxuICAgIC8vIFdpdGggYGF1dG9IaWdobGlnaHRgLCB0aGUgZmlsdGVyaW5nIGVmZmVjdCBiZWxvdyBwbGFjZXMgdGhlIGhpZ2hsaWdodCBpbnN0ZWFkLlxuICAgIGlmICghZXZlbnREZXRhaWxzLmlzQ2FuY2VsZWQgJiYgIWF1dG9IaWdobGlnaHQpIHtcbiAgICAgIHNldEFjdGl2ZUluZGV4KG51bGwpO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IGhhbmRsZUl0ZW1zQ2hhbmdlID0gdXNlU3RhYmxlQ2FsbGJhY2socHJldmlvdXNJdGVtcyA9PiB7XG4gICAgY29uc3QgaXRlbXMgPSBsaXN0UmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgYWN0aXZlSW5kZXggPSBnZXRBY3RpdmVJbmRleCgpO1xuXG4gICAgLy8gQSBwb3NpdGlvbmFsIGhpZ2hsaWdodCBtdXN0IG5vdCBzaWxlbnRseSBtb3ZlIHRvIGFub3RoZXIgaXRlbS4gQSBjaGFuZ2UgdGhhdCBsZWF2ZXMgdGhlXG4gICAgLy8gaGlnaGxpZ2h0ZWQgaXRlbSBpbiBwbGFjZSBrZWVwcyBpdCwgc3VjaCBhcyBhbiBpdGVtIGFwcGVuZGVkIGFmdGVyIGl0IG9yIG9uZSB0aGF0IHJlbmRlcnNcbiAgICAvLyBvbmNlIGJlZm9yZSB0aGUgcXVlcnkgZmlsdGVycyBpdCBvdXQuIEEgcXVlcnkgY2hhbmdlIGFscmVhZHkgcmVzZXQgdGhlIGhpZ2hsaWdodC5cbiAgICBpZiAoYWN0aXZlSW5kZXggIT0gbnVsbCAmJiBpdGVtc1thY3RpdmVJbmRleF0gIT0gbnVsbCAmJiBpdGVtc1thY3RpdmVJbmRleF0gPT09IHByZXZpb3VzSXRlbXNbYWN0aXZlSW5kZXhdKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldEFjdGl2ZUluZGV4KGF1dG9IaWdobGlnaHRFbmFibGVkICYmIGl0ZW1zLmxlbmd0aCA+IDAgPyAwIDogbnVsbCk7XG4gIH0pO1xuXG4gIC8vIFJlLXJ1bnMgb24gdGhlIHJlZ2lzdHJ5IHNuYXBzaG90IHB1Ymxpc2hlZCBvbmNlIGV2ZXJ5IGl0ZW0gaW4gdGhlIGNvbW1pdCBoYXMgcmVnaXN0ZXJlZCxcbiAgLy8gYW5kIG9uIHRoZSBjb21taXR0ZWQgcXVlcnksIGJlY2F1c2UgYSBjb250cm9sbGVkIGNvbnN1bWVyIGNhbiByZWplY3QgYSBwcm9wb3NlZCBjaGFuZ2UuIEl0XG4gIC8vIHJlYWRzIHRoZSBsaXZlIHJlZ2lzdHJ5IHNvIGl0ZW1zIHJlZ2lzdGVyZWQgaW4gdGhpcyBjb21taXQgY291bnQgYmVmb3JlIHRoZWlyIHNuYXBzaG90LlxuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghb3BlbiAmJiBxdWVyeSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHF1ZXJ5Q2hhbmdlZCA9IGxhc3RGaWx0ZXJRdWVyeVJlZi5jdXJyZW50ICE9PSBudWxsICYmIGxhc3RGaWx0ZXJRdWVyeVJlZi5jdXJyZW50ICE9PSBmaWx0ZXJRdWVyeTtcbiAgICBsYXN0RmlsdGVyUXVlcnlSZWYuY3VycmVudCA9IGZpbHRlclF1ZXJ5O1xuXG4gICAgLy8gV2l0aCBubyBxdWVyeSBvciBleHRlcm5hbCBmaWx0ZXJpbmcsIGV2ZXJ5IHJlZ2lzdGVyZWQgaXRlbSBpcyB2aXNpYmxlLiBFeHRlcm5hbCBmaWx0ZXJpbmdcbiAgICAvLyBzdGlsbCBmb2xsb3dzIGBhdXRvSGlnaGxpZ2h0YDsgb3RoZXJ3aXNlIHRoZSBpdGVtIHNldCBpbnZhbGlkYXRlcyB0aGUgaGlnaGxpZ2h0LlxuICAgIGlmIChtYXRjaEl0ZW0gPT09IG51bGwpIHtcbiAgICAgIHN0b3JlLnNldCgndmlzaWJsZUl0ZW1JZHMnLCBudWxsKTtcbiAgICAgIC8vIFJlZ2lzdHJ5IHVwZGF0ZXMsIHN1Y2ggYXMgYW4gaXRlbSdzIHRleHQgY2hhbmdpbmcsIGtlZXAgdGhlIGN1cnJlbnQgaGlnaGxpZ2h0LlxuICAgICAgaWYgKGF1dG9IaWdobGlnaHRFbmFibGVkICYmIGxpdmVJdGVtcy5zaXplID4gMCkge1xuICAgICAgICBpZiAocXVlcnlDaGFuZ2VkIHx8IGdldEFjdGl2ZUluZGV4KCkgPT0gbnVsbCkge1xuICAgICAgICAgIHNldEFjdGl2ZUluZGV4KDApO1xuICAgICAgICB9XG4gICAgICB9IGVsc2UgaWYgKGZpbHRlclF1ZXJ5ID09PSAnJyAmJiBxdWVyeUNoYW5nZWQpIHtcbiAgICAgICAgc2V0QWN0aXZlSW5kZXgobnVsbCk7XG4gICAgICB9XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGN1cnJlbnRJZHMgPSBzdG9yZS5zdGF0ZS52aXNpYmxlSXRlbUlkcztcbiAgICAvLyBUaGUgcG9wdXAncyBjb250ZW50IG1vdW50cyBhIGNvbW1pdCBhZnRlciB0aGUgcm9vdCBvcGVucy4gUHVibGlzaGluZyBhbiBlbXB0eSByZXN1bHQgYmVmb3JlXG4gICAgLy8gYW55dGhpbmcgcmVnaXN0ZXJlZCB3b3VsZCBoaWRlIGV2ZXJ5IGl0ZW0gYXMgaXQgYXJyaXZlcyBhbmQgcmVtb3VudCB0aGUgbWF0Y2hlcy5cbiAgICBpZiAoY3VycmVudElkcyA9PT0gbnVsbCAmJiBsaXZlSXRlbXMuc2l6ZSA9PT0gMCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBuZXh0SWRzID0gbmV3IFNldCgpO1xuICAgIGxldCBoYXNOZXdNYXRjaCA9IGN1cnJlbnRJZHMgPT09IG51bGw7XG4gICAgbGl2ZUl0ZW1zLmZvckVhY2goKHtcbiAgICAgIGdldFRleHRcbiAgICB9LCBpZCkgPT4ge1xuICAgICAgY29uc3QgdGV4dCA9IGdldFRleHQoKTtcbiAgICAgIGlmICh0ZXh0ICE9IG51bGwgJiYgbWF0Y2hJdGVtKHRleHQsIGZpbHRlclF1ZXJ5KSkge1xuICAgICAgICBuZXh0SWRzLmFkZChpZCk7XG4gICAgICAgIGhhc05ld01hdGNoIHx8PSAhY3VycmVudElkcz8uaGFzKGlkKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIE5ldyBtYXRjaGVzIG9yIGEgc21hbGxlciByZXN1bHQgc2V0IGludmFsaWRhdGUgdGhlIHByZXZpb3VzIGl0ZW0gaWRlbnRpdGllcy5cbiAgICBpZiAoaGFzTmV3TWF0Y2ggfHwgY3VycmVudElkcz8uc2l6ZSAhPT0gbmV4dElkcy5zaXplKSB7XG4gICAgICAvLyBUaGUgZmlyc3QgZmlsdGVyZWQgc25hcHNob3QgY2FuIGxhbmQgYWZ0ZXIgaW5pdGlhbCBrZXlib2FyZCBuYXZpZ2F0aW9uIGluIFJlYWN0IDE4LiBJdFxuICAgICAgLy8gaGFzIG5vIHByaW9yIHJlc3VsdCBpZGVudGl0eSB0byBpbnZhbGlkYXRlLCB1bmxlc3MgdGhlIGNvbnRyb2xsZWQgcXVlcnkgaXRzZWxmIGNoYW5nZWQuXG4gICAgICBpZiAoYXV0b0hpZ2hsaWdodEVuYWJsZWQgJiYgbmV4dElkcy5zaXplID4gMCkge1xuICAgICAgICBzZXRBY3RpdmVJbmRleCgwKTtcbiAgICAgIH0gZWxzZSBpZiAoY3VycmVudElkcyAhPT0gbnVsbCB8fCBxdWVyeUNoYW5nZWQpIHtcbiAgICAgICAgc2V0QWN0aXZlSW5kZXgobnVsbCk7XG4gICAgICB9XG4gICAgICBzdG9yZS5zZXQoJ3Zpc2libGVJdGVtSWRzJywgbmV4dElkcyk7XG4gICAgfSBlbHNlIGlmIChhdXRvSGlnaGxpZ2h0RW5hYmxlZCAmJiBxdWVyeUNoYW5nZWQgJiYgbmV4dElkcy5zaXplID4gMCkge1xuICAgICAgc2V0QWN0aXZlSW5kZXgoMCk7XG4gICAgfVxuICB9LCBbb3BlbiwgcXVlcnksIGZpbHRlclF1ZXJ5LCByZWdpc3RlcmVkSXRlbXMsIGxpdmVJdGVtcywgbWF0Y2hJdGVtLCBhdXRvSGlnaGxpZ2h0RW5hYmxlZCwgc3RvcmUsIHNldEFjdGl2ZUluZGV4LCBnZXRBY3RpdmVJbmRleF0pO1xuICBjb25zdCBjb250ZXh0VmFsdWUgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgb3BlbixcbiAgICBkaXNhYmxlZCxcbiAgICBpbnB1dEZvY3VzVmlzaWJsZSxcbiAgICBzZXRJbnB1dEZvY3VzVmlzaWJsZSxcbiAgICBrZXlib2FyZE1vZGFsaXR5LFxuICAgIHNldEtleWJvYXJkTW9kYWxpdHksXG4gICAgYXV0b0hpZ2hsaWdodCxcbiAgICB0cmlnZ2VySWQsXG4gICAgZGVmYXVsdExpc3RJZCxcbiAgICBsaXN0SWQsXG4gICAgc2V0UmVuZGVyZWRMaXN0SWQsXG4gICAgZm9jdXNPd25lclJlZixcbiAgICBzZXRBY3RpdmVJbmRleCxcbiAgICBvbkl0ZW1zQ2hhbmdlOiBoYW5kbGVJdGVtc0NoYW5nZSxcbiAgICBvblZhbHVlQ2hhbmdlOiBoYW5kbGVWYWx1ZUNoYW5nZVxuICB9KSwgW29wZW4sIGRpc2FibGVkLCBpbnB1dEZvY3VzVmlzaWJsZSwga2V5Ym9hcmRNb2RhbGl0eSwgYXV0b0hpZ2hsaWdodCwgdHJpZ2dlcklkLCBkZWZhdWx0TGlzdElkLCBsaXN0SWQsIGZvY3VzT3duZXJSZWYsIHNldEFjdGl2ZUluZGV4LCBoYW5kbGVJdGVtc0NoYW5nZSwgaGFuZGxlVmFsdWVDaGFuZ2VdKTtcbiAgY29uc3QgaXRlbUNvbnRleHRWYWx1ZSA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBwYXJlbnQ6IHBhcmVudEl0ZW1Db250ZXh0LFxuICAgIHN0b3JlLFxuICAgIHJlZ2lzdGVySXRlbSxcbiAgICBsaXN0UmVmXG4gIH0pLCBbcGFyZW50SXRlbUNvbnRleHQsIHN0b3JlLCByZWdpc3Rlckl0ZW0sIGxpc3RSZWZdKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KEZpbHRlckRyb3Bkb3duSXRlbUNvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogaXRlbUNvbnRleHRWYWx1ZSxcbiAgICBjaGlsZHJlbjogLyojX19QVVJFX18qL19qc3goRmlsdGVyRHJvcGRvd25Sb290Q29udGV4dC5Qcm92aWRlciwge1xuICAgICAgdmFsdWU6IGNvbnRleHRWYWx1ZSxcbiAgICAgIGNoaWxkcmVuOiAvKiNfX1BVUkVfXyovX2pzeChGaWx0ZXJEcm9wZG93blZhbHVlQ29udGV4dC5Qcm92aWRlciwge1xuICAgICAgICB2YWx1ZTogcXVlcnkgPz8gdmFsdWUsXG4gICAgICAgIGNoaWxkcmVuOiBjaGlsZHJlblxuICAgICAgfSlcbiAgICB9KVxuICB9KTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG4vKipcbiAqIENsZWFycyB0aGUgY29tbWl0dGVkIHZhbHVlIHdoZW4gYSBmaWx0ZXIgcG9wdXAgY2xvc2VzIHdoaWxlIHJldGFpbmluZyB0aGUgZGlzcGxheWVkIHF1ZXJ5IGFuZFxuICogZmlsdGVyZWQgaXRlbXMgdW50aWwgdGhlIGV4aXQgdHJhbnNpdGlvbiBjb21wbGV0ZXMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VGaWx0ZXJEcm9wZG93bkNsb3NlUXVlcnkocGFyYW1ldGVycykge1xuICBjb25zdCB7XG4gICAgb3BlbixcbiAgICBtb3VudGVkLFxuICAgIHZhbHVlLFxuICAgIG9uVmFsdWVDaGFuZ2VcbiAgfSA9IHBhcmFtZXRlcnM7XG4gIGNvbnN0IFtjbG9zZVF1ZXJ5LCBzZXRDbG9zZVF1ZXJ5XSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBwcmV2aW91c09wZW5SZWYgPSBSZWFjdC51c2VSZWYob3Blbik7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgd2FzT3BlbiA9IHByZXZpb3VzT3BlblJlZi5jdXJyZW50O1xuICAgIHByZXZpb3VzT3BlblJlZi5jdXJyZW50ID0gb3BlbjtcbiAgICBpZiAod2FzT3BlbiAmJiAhb3BlbiAmJiB2YWx1ZSAhPT0gJycpIHtcbiAgICAgIHNldENsb3NlUXVlcnkodmFsdWUpO1xuICAgICAgb25WYWx1ZUNoYW5nZSgnJywgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMucG9wdXBDbG9zZSkpO1xuICAgIH0gZWxzZSBpZiAoKG9wZW4gfHwgIW1vdW50ZWQpICYmIGNsb3NlUXVlcnkgIT09IG51bGwpIHtcbiAgICAgIHNldENsb3NlUXVlcnkobnVsbCk7XG4gICAgfVxuICB9LCBbb3BlbiwgbW91bnRlZCwgdmFsdWUsIGNsb3NlUXVlcnksIG9uVmFsdWVDaGFuZ2VdKTtcbiAgcmV0dXJuICFvcGVuICYmIGNsb3NlUXVlcnkgIT09IG51bGwgPyBjbG9zZVF1ZXJ5IDogdmFsdWU7XG59IiwibGV0IHJlZm9jdXNpbmcgPSBmYWxzZTtcblxuLyoqXG4gKiBIYW5kcyBmb2N1cyBiYWNrIHRvIHRoZSBpbnB1dCB0aGF0IG93bnMgaXQgd2hpbGUgdGhlIHVzZXIga2VlcHMgaW50ZXJhY3Rpbmc6IHRoZSBwb2ludGVyIGVudGVyZWRcbiAqIGl0cyBwb3B1cCwgb3IgdGhlIGxpc3QgcmVwbGF5cyBhIGtleSB0aGF0IGxhbmRlZCBvbiBpdC4gRm9jdXMgaGFuZGxlcnMgdGhhdCBydW4gZHVyaW5nIHRoZSBjYWxsXG4gKiBzZWUgYGlzUmVmb2N1c2luZ093bmVyKClgIGFuZCB0cmVhdCB0aGUgbW92ZSBhcyBhIGNvbnRpbnVhdGlvbiByYXRoZXIgdGhhbiB0aGUgdXNlciBsZWF2aW5nLlxuICogQSBtb2R1bGUtbGV2ZWwgZmxhZyBzdWZmaWNlcyBiZWNhdXNlIGBmb2N1cygpYCBkaXNwYXRjaGVzIGl0cyBldmVudHMgc3luY2hyb25vdXNseSwgYW5kIGl0IGFsc29cbiAqIHJlYWNoZXMgdGhlIGhhbmRsZXJzIG9mIGVuY2xvc2luZyBwb3B1cHMgdGhhdCBhIG5lc3RlZCBpbnB1dCdzIGZvY3VzIGV2ZW50IGJ1YmJsZXMgdGhyb3VnaC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlZm9jdXNPd25lcihvd25lcikge1xuICByZWZvY3VzaW5nID0gdHJ1ZTtcbiAgdHJ5IHtcbiAgICBvd25lci5mb2N1cyh7XG4gICAgICBwcmV2ZW50U2Nyb2xsOiB0cnVlXG4gICAgfSk7XG4gIH0gZmluYWxseSB7XG4gICAgcmVmb2N1c2luZyA9IGZhbHNlO1xuICB9XG59XG5leHBvcnQgZnVuY3Rpb24gaXNSZWZvY3VzaW5nT3duZXIoKSB7XG4gIHJldHVybiByZWZvY3VzaW5nO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgaXNFbGVtZW50LCBpc0hUTUxFbGVtZW50IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzL2RvbSc7XG5pbXBvcnQgeyBvd25lckRvY3VtZW50IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvb3duZXInO1xuaW1wb3J0IHsgd2FybiB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3dhcm4nO1xuaW1wb3J0IHsgYWN0aXZlRWxlbWVudCwgY29udGFpbnMsIGdldFRhcmdldCwgaXNUeXBlYWJsZUVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvdXRpbHMubWpzXCI7XG5pbXBvcnQgeyB1c2VGaWx0ZXJEcm9wZG93blJvb3RDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2ZpbHRlci1kcm9wZG93bi9yb290L0ZpbHRlckRyb3Bkb3duUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyByZWZvY3VzT3duZXIsIGlzUmVmb2N1c2luZ093bmVyIH0gZnJvbSBcIi4uLy4uL2ZpbHRlci1kcm9wZG93bi91dGlscy9yZWZvY3VzT3duZXIubWpzXCI7XG5pbXBvcnQgeyBpc0Nyb3NzT3JpZW50YXRpb25DbG9zZUtleSB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9ob29rcy91c2VMaXN0TmF2aWdhdGlvbi5tanNcIjtcbmltcG9ydCB7IHVzZURpcmVjdGlvbiB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvZGlyZWN0aW9uLWNvbnRleHQvRGlyZWN0aW9uQ29udGV4dC5tanNcIjtcbmV4cG9ydCBmdW5jdGlvbiB1c2VNZW51RmlsdGVyUG9wdXAob3JpZW50YXRpb24pIHtcbiAgY29uc3QgY29udGV4dCA9IHVzZUZpbHRlckRyb3Bkb3duUm9vdENvbnRleHQoKTtcbiAgY29uc3QgZGlyZWN0aW9uID0gdXNlRGlyZWN0aW9uKCk7XG4gIGNvbnN0IHtcbiAgICBmb2N1c093bmVyUmVmXG4gIH0gPSBjb250ZXh0O1xuXG4gIC8vIEZvY3VzIHRoYXQgZW50ZXJlZCBhIG5lc3RlZCBwb3B1cCBieSBrZXlib2FyZCBvciBjbGljayBzdGF5cyB0aGVyZSB3aGlsZSB0aGVcbiAgLy8gcG9pbnRlciBjcm9zc2VzIHRoZSBwYXJlbnQgcG9wdXAuIFJldHVybmluZyB0byBhIHN1Ym1lbnUgdHJpZ2dlciByZXN0b3JlcyBmb2N1cyB0byB0aGVcbiAgLy8gcGFyZW50IGlucHV0LiBGb2N1cyB0aGF0IG1lcmVseSBmb2xsb3dlZCB0aGUgcG9pbnRlciBpbiBmb2xsb3dzIGl0IGJhY2sgb3V0LlxuICBjb25zdCBuZXN0ZWRGb2N1c1JlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgLy8gQSB0YXAgZmlyZXMgY29tcGF0aWJpbGl0eSBtb3VzZSBldmVudHMsIHdoaWNoIG11c3Qgbm90IGZvY3VzIHRoZSBpbnB1dCBhbmQgcmFpc2UgdGhlXG4gIC8vIG9uLXNjcmVlbiBrZXlib2FyZC5cbiAgY29uc3QgcG9pbnRlclR5cGVSZWYgPSBSZWFjdC51c2VSZWYoJ21vdXNlJyk7XG4gIGZ1bmN0aW9uIHRyYWNrUG9pbnRlclR5cGUoZXZlbnQpIHtcbiAgICBwb2ludGVyVHlwZVJlZi5jdXJyZW50ID0gZXZlbnQucG9pbnRlclR5cGUgfHwgJ21vdXNlJztcbiAgfVxuXG4gIC8qIGlzdGFuYnVsIGlnbm9yZSBlbHNlIC0tIGBwcm9jZXNzLmVudi5OT0RFX0VOVmAgaXMgYSBidWlsZC10aW1lIGNvbnN0YW50IHVuZGVyIHRlc3QgKi9cbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgcmVhY3QtaG9va3MvcnVsZXMtb2YtaG9va3NcbiAgICBSZWFjdC51c2VFZmZlY3QoKCkgPT4ge1xuICAgICAgaWYgKGNvbnRleHQub3BlbiAmJiBmb2N1c093bmVyUmVmLmN1cnJlbnQgPT09IG51bGwpIHtcbiAgICAgICAgd2FybignQSBmaWx0ZXJhYmxlIG1lbnUgb3BlbmVkIHdpdGhvdXQgYSA8TWVudS5JbnB1dD4uIFJlbmRlciB0aGUgaW5wdXQgaW5zaWRlICcgKyAnPE1lbnUuUG9wdXA+LCBvciBkcm9wIDxNZW51LkZpbHRlclByb3ZpZGVyPiBmb3IgYSBtZW51IHRoYXQgZG9lcyBub3QgZmlsdGVyLicpO1xuICAgICAgfVxuICAgIH0sIFtjb250ZXh0Lm9wZW4sIGZvY3VzT3duZXJSZWZdKTtcbiAgfVxuICBmdW5jdGlvbiByZXN0b3JlSW5wdXRGb2N1cyhldmVudCwgZW50ZXJlZFRyaWdnZXIpIHtcbiAgICBjb25zdCBmb2N1c093bmVyID0gZm9jdXNPd25lclJlZi5jdXJyZW50O1xuICAgIGlmICghY29udGV4dC5vcGVuIHx8ICFmb2N1c093bmVyKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGFjdGl2ZUVsID0gYWN0aXZlRWxlbWVudChvd25lckRvY3VtZW50KGV2ZW50LmN1cnJlbnRUYXJnZXQpKTtcbiAgICBpZiAoYWN0aXZlRWwgPT09IGZvY3VzT3duZXIgfHwgY29udGFpbnMoZXZlbnQuY3VycmVudFRhcmdldCwgYWN0aXZlRWwpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gTmVzdGVkIHBvcHVwcyBhcmUgcG9ydGFsbGVkLCBzbyB0aGVpciBldmVudHMgc3RpbGwgYnViYmxlIHRocm91Z2ggdGhpcyBSZWFjdCB0cmVlLlxuICAgIC8vIFRoZSBjb21wb3NlZCBwYXRoIG9ubHkgY29udGFpbnMgdGhpcyBwb3B1cCB3aGVuIHRoZSBwb2ludGVyIGlzIHJlYWxseSBvdmVyIGl0LCBhbmQgYVxuICAgIC8vIGNsb3NpbmcgcG9wdXAgbXVzdCBub3QgcmUtY2FwdHVyZSBmb2N1cyBkdXJpbmcgaXRzIGV4aXQgdHJhbnNpdGlvbi5cbiAgICBsZXQgc3VibWVudVRyaWdnZXIgPSBudWxsO1xuICAgIGNvbnN0IG5lYXJlc3RQb3B1cCA9IGV2ZW50Lm5hdGl2ZUV2ZW50LmNvbXBvc2VkUGF0aCgpLmZpbmQobm9kZSA9PiB7XG4gICAgICBpZiAoIWlzSFRNTEVsZW1lbnQobm9kZSkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgICAgaWYgKG5vZGUuZ2V0QXR0cmlidXRlKCdyb2xlJykgPT09ICdkaWFsb2cnIHx8IG5vZGUuaGFzQXR0cmlidXRlKCdkYXRhLXJvb3Rvd25lcmlkJykpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBpZiAobm9kZS5oYXNBdHRyaWJ1dGUoJ2FyaWEtaGFzcG9wdXAnKSkge1xuICAgICAgICBzdWJtZW51VHJpZ2dlciA9IG5vZGU7XG4gICAgICB9XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfSk7XG4gICAgaWYgKG5lYXJlc3RQb3B1cCAhPT0gZXZlbnQuY3VycmVudFRhcmdldCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIEEgbmVzdGVkIHBvcHVwIHRoYXQgdG9vayBmb2N1cyBrZWVwcyBpdCB3aGlsZSB0aGUgcG9pbnRlciBtb3ZlcyBvdmVyIHRoZSBwYXJlbnQgcG9wdXAuXG4gICAgLy8gRW50ZXJpbmcgYSBzdWJtZW51IHRyaWdnZXIgcmV0dXJucyBmb2N1cyB0byB0aGUgcGFyZW50J3MgaW5wdXQuXG4gICAgaWYgKG5lc3RlZEZvY3VzUmVmLmN1cnJlbnQgJiYgIShlbnRlcmVkVHJpZ2dlciAmJiBzdWJtZW51VHJpZ2dlcikpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGVudGVyZWRUcmlnZ2VyICYmIHN1Ym1lbnVUcmlnZ2VyICYmIGlzRWxlbWVudChldmVudC5yZWxhdGVkVGFyZ2V0KSAmJiBjb250YWlucyhzdWJtZW51VHJpZ2dlciwgZXZlbnQucmVsYXRlZFRhcmdldCkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcmVmb2N1c093bmVyKGZvY3VzT3duZXIpO1xuICB9XG4gIHJldHVybiB7XG4gICAgLy8gVGhlIGlucHV0IG93bnMgdmlydHVhbCBmb2N1cy5cbiAgICAnYXJpYS1hY3RpdmVkZXNjZW5kYW50JzogdW5kZWZpbmVkLFxuICAgIC8vIE5vdCB2YWxpZCBvbiBhIGRpYWxvZzsgdGhlIGxpc3QncyBpbXBsaWNpdCBvcmllbnRhdGlvbiBpcyBhbHJlYWR5IHZlcnRpY2FsLlxuICAgICdhcmlhLW9yaWVudGF0aW9uJzogdW5kZWZpbmVkLFxuICAgIG9uTW91c2VEb3duKGV2ZW50KSB7XG4gICAgICBpZiAoZ2V0VGFyZ2V0KGV2ZW50Lm5hdGl2ZUV2ZW50KSA9PT0gZXZlbnQuY3VycmVudFRhcmdldCkge1xuICAgICAgICAvLyBLZWVwIGZvY3VzIG9uIHRoZSB2aXJ0dWFsIGZvY3VzIG93bmVyIHdoZW4gdGhlIHBvcHVwJ3Mgb3duIGJhY2tncm91bmQgaXMgcHJlc3NlZC5cbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIG9uUG9pbnRlckRvd246IHRyYWNrUG9pbnRlclR5cGUsXG4gICAgLy8gYHBvaW50ZXJvdmVyYCBwcmVjZWRlcyB0aGUgY29tcGF0aWJpbGl0eSBgbW91c2VvdmVyYCwgc28gYSBtb3VzZSBlbnRlcmluZyByaWdodCBhZnRlciBhIHRhcFxuICAgIC8vIGlzIHJlY29nbml6ZWQgYmVmb3JlIHRoZSBoYW5kb2ZmIGJlbG93LlxuICAgIG9uUG9pbnRlck92ZXI6IHRyYWNrUG9pbnRlclR5cGUsXG4gICAgb25Qb2ludGVyTW92ZTogdHJhY2tQb2ludGVyVHlwZSxcbiAgICBvbk1vdXNlTW92ZShldmVudCkge1xuICAgICAgaWYgKHBvaW50ZXJUeXBlUmVmLmN1cnJlbnQgPT09ICdtb3VzZScpIHtcbiAgICAgICAgcmVzdG9yZUlucHV0Rm9jdXMoZXZlbnQsIGZhbHNlKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIG9uTW91c2VPdmVyKGV2ZW50KSB7XG4gICAgICBpZiAocG9pbnRlclR5cGVSZWYuY3VycmVudCA9PT0gJ21vdXNlJyAmJiBuZXN0ZWRGb2N1c1JlZi5jdXJyZW50KSB7XG4gICAgICAgIHJlc3RvcmVJbnB1dEZvY3VzKGV2ZW50LCB0cnVlKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIG9uRm9jdXMoZXZlbnQpIHtcbiAgICAgIC8vIGBmb2N1c2luYCBidWJibGVzLCBzbyB0aGlzIGFsc28gc2VlcyB0aGUgb3duZXIgaXRzZWxmIGJlaW5nIGZvY3VzZWQuXG4gICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQubmF0aXZlRXZlbnQpO1xuXG4gICAgICAvLyBOZXN0ZWQgcG9wdXBzIGFyZSBwb3J0YWxsZWQsIHNvIHRoZWlyIGZvY3VzIGV2ZW50cyBidWJibGUgdGhyb3VnaCB0aGlzIFJlYWN0IHRyZWVcbiAgICAgIC8vIHdoaWxlIHRoZWlyIGVsZW1lbnRzIHNpdCBvdXRzaWRlIHRoaXMgb25lIGluIHRoZSBET00uXG4gICAgICBpZiAodGFyZ2V0ID09PSBmb2N1c093bmVyUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgbmVzdGVkRm9jdXNSZWYuY3VycmVudCA9IG51bGw7XG4gICAgICB9IGVsc2UgaWYgKGlzSFRNTEVsZW1lbnQodGFyZ2V0KSAmJiAhY29udGFpbnMoZXZlbnQuY3VycmVudFRhcmdldCwgdGFyZ2V0KSAmJiAhaXNSZWZvY3VzaW5nT3duZXIoKSkge1xuICAgICAgICBuZXN0ZWRGb2N1c1JlZi5jdXJyZW50ID0gdGFyZ2V0O1xuICAgICAgfVxuXG4gICAgICAvLyBGb2N1cyB0aGF0IGxhbmRzIG9uIHRoZSBwb3B1cCBpdHNlbGYsIHRoZSBmb2N1cyBtYW5hZ2VyJ3MgZmFsbGJhY2sgdGFyZ2V0LCBtb3ZlcyBvbiB0b1xuICAgICAgLy8gdGhlIGlucHV0LCB3aGljaCBvd25zIGZvY3VzIHdoaWxlIHRoZSBtZW51IGZpbHRlcnMuXG4gICAgICBpZiAoY29udGV4dC5vcGVuICYmIHRhcmdldCA9PT0gZXZlbnQuY3VycmVudFRhcmdldCkge1xuICAgICAgICBmb2N1c093bmVyUmVmLmN1cnJlbnQ/LmZvY3VzKHtcbiAgICAgICAgICBwcmV2ZW50U2Nyb2xsOiB0cnVlXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0sXG4gICAgb25LZXlEb3duKGV2ZW50KSB7XG4gICAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQubmF0aXZlRXZlbnQpO1xuICAgICAgaWYgKHRhcmdldCA9PT0gZm9jdXNPd25lclJlZi5jdXJyZW50IHx8IGlzVHlwZWFibGVFbGVtZW50KHRhcmdldCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKGlzQ3Jvc3NPcmllbnRhdGlvbkNsb3NlS2V5KGV2ZW50LmtleSwgb3JpZW50YXRpb24sIGRpcmVjdGlvbiA9PT0gJ3J0bCcsIGZhbHNlKSkge1xuICAgICAgICBmb2N1c093bmVyUmVmLmN1cnJlbnQ/LmZvY3VzKHtcbiAgICAgICAgICBwcmV2ZW50U2Nyb2xsOiB0cnVlXG4gICAgICAgIH0pO1xuICAgICAgICAvLyBOZXN0ZWQgcG9wdXBzIGJ1YmJsZSB0aHJvdWdoIHRoaXMgUmVhY3QgdHJlZSwgc28ga2VlcCB0aGUga2V5IGZyb20gdGhlIHBhcmVudC5cbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICB9XG4gICAgfVxuICB9O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlTWVudUZpbHRlclBvcHVwIH0gZnJvbSBcIi4vdXNlTWVudUZpbHRlclBvcHVwLm1qc1wiO1xuaW1wb3J0IHsgTWVudVBvcHVwUGxhaW4gfSBmcm9tIFwiLi4vcG9wdXAvTWVudVBvcHVwLm1qc1wiO1xuaW1wb3J0IHsgdXNlTWVudVJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvTWVudVJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgbWVyZ2VQcm9wcyB9IGZyb20gXCIuLi8uLi9tZXJnZS1wcm9wcy9pbmRleC5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5cbi8qKlxuICogQSBjb250YWluZXIgZm9yIHRoZSBmaWx0ZXIgaW5wdXQgYW5kIGl0ZW0gbGlzdC5cbiAqIFJlbmRlcnMgYSBgPGRpdj5gIGVsZW1lbnQgd2l0aCBhIGBkaWFsb2dgIHJvbGUuXG4gKi9cbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgY29uc3QgTWVudUZpbHRlclBvcHVwID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gTWVudUZpbHRlclBvcHVwKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHN0b3JlLFxuICAgIG9yaWVudGF0aW9uXG4gIH0gPSB1c2VNZW51Um9vdENvbnRleHQoKTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IHBhcmVudCA9IHN0b3JlLnVzZVN0YXRlKCdwYXJlbnQnKTtcbiAgY29uc3Qgb3Blbk1ldGhvZCA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuTWV0aG9kJyk7XG4gIGNvbnN0IGxhc3RPcGVuQ2hhbmdlUmVhc29uID0gc3RvcmUudXNlU3RhdGUoJ2xhc3RPcGVuQ2hhbmdlUmVhc29uJyk7XG4gIGNvbnN0IGludGVyYWN0aW9uUHJvcHMgPSB1c2VNZW51RmlsdGVyUG9wdXAob3JpZW50YXRpb24pO1xuICBjb25zdCBvcGVuZWRCeUhvdmVyID0gb3BlbiAmJiBsYXN0T3BlbkNoYW5nZVJlYXNvbiA9PT0gUkVBU09OUy50cmlnZ2VySG92ZXI7XG4gIGNvbnN0IG1heUZvY3VzSW5wdXQgPSBwYXJlbnQudHlwZSAhPT0gJ21lbnUnIHx8IG9wZW4gJiYgKG9wZW5NZXRob2QgPT09ICdrZXlib2FyZCcgfHwgbGFzdE9wZW5DaGFuZ2VSZWFzb24gPT09IFJFQVNPTlMubGlzdE5hdmlnYXRpb24gfHwgbGFzdE9wZW5DaGFuZ2VSZWFzb24gPT09IFJFQVNPTlMudHJpZ2dlckhvdmVyIHx8IGxhc3RPcGVuQ2hhbmdlUmVhc29uID09PSBSRUFTT05TLnRyaWdnZXJQcmVzcyk7XG5cbiAgLy8gVGhlIGlucHV0IGhvbGRzIHJlYWwgZm9jdXM7IHRoZSBwb3B1cCBpcyBuZXZlciB0aGUgZm9jdXMgdGFyZ2V0LlxuICBsZXQgaW5pdGlhbEZvY3VzID0gZmFsc2U7XG4gIGlmIChtYXlGb2N1c0lucHV0KSB7XG4gICAgaW5pdGlhbEZvY3VzID0gKCkgPT4ge1xuICAgICAgLy8gQSB0YXAgd291bGQgcmFpc2UgdGhlIG9uLXNjcmVlbiBrZXlib2FyZCwgYnV0IGEgc2NyZWVuIHJlYWRlciBwcmVzcyAoc3VjaCBhcyBhbiBpT1NcbiAgICAgIC8vIFZvaWNlT3ZlciBkb3VibGUtdGFwKSBzdGlsbCByZXBvcnRzIGEgdG91Y2ggYW5kIG5lZWRzIHRoZSBpbnB1dCBmb2N1c2VkLlxuICAgICAgY29uc3QgdG91Y2hPcGVuID0gKG9wZW5NZXRob2QgPT09ICd0b3VjaCcgfHwgb3Blbk1ldGhvZCA9PT0gJ3BlbicpICYmICFzdG9yZS5jb250ZXh0LnZpcnR1YWxQcmVzcztcbiAgICAgIGlmIChvcGVuZWRCeUhvdmVyIHx8IHRvdWNoT3Blbikge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICByZXR1cm4gc3RvcmUuY29udGV4dC52aXJ0dWFsRm9jdXNSZWY/LmN1cnJlbnQgPz8gZmFsc2U7XG4gICAgfTtcbiAgfVxuICBjb25zdCBwb3B1cFByb3BzID0gbWVyZ2VQcm9wcyhpbnRlcmFjdGlvblByb3BzLCBwcm9wcyk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChNZW51UG9wdXBQbGFpbiwge1xuICAgIC4uLnBvcHVwUHJvcHMsXG4gICAgcm9sZTogXCJkaWFsb2dcIixcbiAgICBpbml0aWFsRm9jdXM6IGluaXRpYWxGb2N1cyxcbiAgICByZWY6IGZvcndhcmRlZFJlZlxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgTWVudUZpbHRlclBvcHVwLmRpc3BsYXlOYW1lID0gXCJNZW51RmlsdGVyUG9wdXBcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmV4cG9ydCBjb25zdCBGaWx0ZXJEcm9wZG93bkdyb3VwQ29udGV4dCA9IC8qI19fUFVSRV9fKi9SZWFjdC5jcmVhdGVDb250ZXh0KG51bGwpO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRmlsdGVyRHJvcGRvd25Hcm91cENvbnRleHQuZGlzcGxheU5hbWUgPSBcIkZpbHRlckRyb3Bkb3duR3JvdXBDb250ZXh0XCI7XG5leHBvcnQgZnVuY3Rpb24gdXNlRmlsdGVyRHJvcGRvd25Hcm91cENvbnRleHQoKSB7XG4gIHJldHVybiBSZWFjdC51c2VDb250ZXh0KEZpbHRlckRyb3Bkb3duR3JvdXBDb250ZXh0KTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VGaWx0ZXJEcm9wZG93blJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvRmlsdGVyRHJvcGRvd25Sb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IEZpbHRlckRyb3Bkb3duR3JvdXBDb250ZXh0IH0gZnJvbSBcIi4uL2dyb3VwL0ZpbHRlckRyb3Bkb3duR3JvdXBDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlUmVuZGVyZWRJZCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVzb2x2ZVJlbmRlcmVkSWQubWpzXCI7XG5pbXBvcnQgeyBnZXRUYXJnZXQgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvdXRpbHMubWpzXCI7XG5pbXBvcnQgeyByZWZvY3VzT3duZXIgfSBmcm9tIFwiLi4vdXRpbHMvcmVmb2N1c093bmVyLm1qc1wiO1xuXG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZXhwb3J0IGNvbnN0IEZpbHRlckRyb3Bkb3duTGlzdCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIEZpbHRlckRyb3Bkb3duTGlzdChjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIC8vIGBpZGAgaXMgcmVzb2x2ZWQgYnkgYHVzZVJlbmRlcmVkSWRgLCB3aGljaCBhbHNvIGhvbm9ycyBhbiBpZCBvbiB0aGUgYHJlbmRlcmAgZWxlbWVudC5cbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgaWQ6IGlkUHJvcCxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCBjb250ZXh0ID0gdXNlRmlsdGVyRHJvcGRvd25Sb290Q29udGV4dCgpO1xuICBjb25zdCBbaWQsIHJlZ2lzdGVySWRSZWZdID0gdXNlUmVuZGVyZWRJZChjb21wb25lbnRQcm9wcywgY29udGV4dC5kZWZhdWx0TGlzdElkLCBjb250ZXh0LnNldFJlbmRlcmVkTGlzdElkKTtcbiAgY29uc3QgZGVmYXVsdFByb3BzID0ge1xuICAgIC8vIENocm9taXVtIGluY2x1ZGVzIHNjcm9sbGFibGUgZWxlbWVudHMgaW4gc2VxdWVudGlhbCBmb2N1cyBuYXZpZ2F0aW9uIGJ5IGRlZmF1bHQuXG4gICAgdGFiSW5kZXg6IC0xLFxuICAgIGlkLFxuICAgIG9uRm9jdXMoZXZlbnQpIHtcbiAgICAgIC8vIEEgcHJlc3Mgb24gdGhlIGxpc3QncyBvd24gY29udGVudCwgc3VjaCBhcyBpdHMgYmFja2dyb3VuZCwgYSBncm91cCwgb3IgYSBncm91cCBsYWJlbCxcbiAgICAgIC8vIGZvY3VzZXMgdGhlIGxpc3QuXG4gICAgICBjb25zdCBvd25lciA9IGNvbnRleHQuZm9jdXNPd25lclJlZi5jdXJyZW50O1xuICAgICAgaWYgKG93bmVyICYmIGV2ZW50LnJlbGF0ZWRUYXJnZXQgPT09IG93bmVyICYmIGdldFRhcmdldChldmVudC5uYXRpdmVFdmVudCkgPT09IGV2ZW50LmN1cnJlbnRUYXJnZXQpIHtcbiAgICAgICAgcmVmb2N1c093bmVyKG93bmVyKTtcbiAgICAgIH1cbiAgICB9LFxuICAgIG9uUG9pbnRlck1vdmUoKSB7XG4gICAgICBjb250ZXh0LnNldEtleWJvYXJkTW9kYWxpdHkoZmFsc2UpO1xuICAgIH0sXG4gICAgb25Qb2ludGVyRG93bigpIHtcbiAgICAgIGNvbnRleHQuc2V0S2V5Ym9hcmRNb2RhbGl0eShmYWxzZSk7XG4gICAgfVxuICB9O1xuICByZXR1cm4gdXNlUmVuZGVyRWxlbWVudCgnZGl2JywgY29tcG9uZW50UHJvcHMsIHtcbiAgICByZWY6IFtmb3J3YXJkZWRSZWYsIHJlZ2lzdGVySWRSZWZdLFxuICAgIHByb3BzOiBbZGVmYXVsdFByb3BzLCBlbGVtZW50UHJvcHMsIHtcbiAgICAgIC8vIFRoZSBsaXN0J3MgZ3JvdXBzIGFuZCBpdGVtcyBiZWxvbmcgdG8gdGhpcyByb290J3MgcXVlcnkuIEEgbmVzdGVkIHJvb3QncyBsaXN0IHJlbmRlcnNcbiAgICAgIC8vIGluc2lkZSBhbiBlbmNsb3NpbmcgZ3JvdXAsIHdoaWNoIG11c3Qgbm90IGNvdW50IHRoZW0gYXMgaXRzIG93biBtZW1iZXJzLlxuICAgICAgY2hpbGRyZW46IC8qI19fUFVSRV9fKi9fanN4KEZpbHRlckRyb3Bkb3duR3JvdXBDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgICAgIHZhbHVlOiBudWxsLFxuICAgICAgICBjaGlsZHJlbjogZWxlbWVudFByb3BzLmNoaWxkcmVuXG4gICAgICB9KVxuICAgIH1dXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBGaWx0ZXJEcm9wZG93bkxpc3QuZGlzcGxheU5hbWUgPSBcIkZpbHRlckRyb3Bkb3duTGlzdFwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IHsgb3duZXJXaW5kb3cgfSBmcm9tICdAYmFzZS11aS91dGlscy9vd25lcic7XG5pbXBvcnQgeyB1c2VTdGFibGVDYWxsYmFjayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrJztcbmltcG9ydCB7IEVNUFRZX0FSUkFZIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuaW1wb3J0IHsgaXNIVE1MRWxlbWVudCB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuaW1wb3J0IHsgdXNlTWVudVJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvTWVudVJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlTWVudVN1Ym1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi9zdWJtZW51LXJvb3QvTWVudVN1Ym1lbnVSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZURpcmVjdGlvbiB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvZGlyZWN0aW9uLWNvbnRleHQvRGlyZWN0aW9uQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY3JlYXRlQmFzZVVJRXZlbnREZXRhaWxzLm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcbmltcG9ydCB7IHN0b3BFdmVudCB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC91dGlscy9ldmVudC5tanNcIjtcbmltcG9ydCB7IGdldE1heExpc3RJbmRleCwgZ2V0TWluTGlzdEluZGV4IH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL2NvbXBvc2l0ZS5tanNcIjtcbmltcG9ydCB7IGRpc3BhdGNoQ2xpY2tXaXRoTW9kaWZpZXJzIH0gZnJvbSBcIi4uLy4uL3V0aWxzL2Rpc3BhdGNoQ2xpY2tXaXRoTW9kaWZpZXJzLm1qc1wiO1xuaW1wb3J0IHsgaXNDcm9zc09yaWVudGF0aW9uQ2xvc2VLZXksIGlzQ3Jvc3NPcmllbnRhdGlvbk9wZW5LZXksIGlzTWFpbk9yaWVudGF0aW9uS2V5IH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2hvb2tzL3VzZUxpc3ROYXZpZ2F0aW9uLm1qc1wiO1xuLyoqXG4gKiBEZWNpZGVzIHdoYXQgYSBrZXkgZG9lcyB3aGlsZSB0aGUgZmlsdGVyIGlucHV0IG93bnMgdGhlIGtleWJvYXJkLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0TWVudUZpbHRlcktleUFjdGlvbihldmVudCwgY29udGV4dCkge1xuICBjb25zdCB7XG4gICAgb3JpZW50YXRpb24sXG4gICAgcnRsLFxuICAgIGhhc0FjdGl2ZUl0ZW0sXG4gICAgYWN0aXZlSXRlbU9wZW5zU3VibWVudSxcbiAgICBoYXNWYWx1ZVxuICB9ID0gY29udGV4dDtcbiAgY29uc3Qge1xuICAgIGtleVxuICB9ID0gZXZlbnQ7XG4gIC8vIEVudGVyIHRoYXQgY29tbWl0cyBhbiBJTUUgY29tcG9zaXRpb24gYmVsb25ncyB0byB0aGUgaW5wdXQsIG5vdCB0aGUgbGlzdC5cbiAgaWYgKGV2ZW50LndoaWNoID09PSAyMjkpIHtcbiAgICByZXR1cm4gJ2lnbm9yZSc7XG4gIH1cbiAgaWYgKGtleSA9PT0gJ1RhYicpIHtcbiAgICByZXR1cm4gZXZlbnQuc2hpZnRLZXkgPyAnY2xvc2UnIDogJ2lnbm9yZSc7XG4gIH1cbiAgaWYgKGtleSA9PT0gJ0VudGVyJykge1xuICAgIHJldHVybiBoYXNBY3RpdmVJdGVtID8gJ2FjdGl2YXRlJyA6ICduYXZpZ2F0ZSc7XG4gIH1cbiAgY29uc3QgaXNBcnJvdyA9IGtleS5zdGFydHNXaXRoKCdBcnJvdycpO1xuICBjb25zdCBpc0JvdW5kYXJ5ID0ga2V5ID09PSAnSG9tZScgfHwga2V5ID09PSAnRW5kJztcblxuICAvLyBNb2RpZmllZCBhcnJvd3MgYW5kIGJvdW5kYXJ5IGtleXMgYXJlIHRleHQtZWRpdGluZyBjb21tYW5kcyAoZXh0ZW5kIHRoZSBzZWxlY3Rpb24sIG1vdmUgYnlcbiAgLy8gd29yZCBvciB0byBhIHRleHQgYm91bmRhcnkpLCBsaWtlIGEgbW9kaWZpZWQgY2hhcmFjdGVyLlxuICBpZiAoZXZlbnQuc2hpZnRLZXkgfHwgZXZlbnQuY3RybEtleSB8fCBldmVudC5hbHRLZXkgfHwgZXZlbnQubWV0YUtleSkge1xuICAgIHJldHVybiBpc0Fycm93IHx8IGlzQm91bmRhcnkgfHwga2V5Lmxlbmd0aCA9PT0gMSA/ICdlZGl0JyA6ICduYXZpZ2F0ZSc7XG4gIH1cbiAgLy8gQ2hhcmFjdGVycyBzdGF5IG91dCBvZiBwYXJlbnQgaGFuZGxlcnMgc3VjaCBhcyB0eXBlYWhlYWQuXG4gIGlmIChrZXkubGVuZ3RoID09PSAxKSB7XG4gICAgcmV0dXJuICdlZGl0JztcbiAgfVxuICAvLyBIb21lIGFuZCBFbmQgbW92ZSB0aGUgY2FyZXQgd2hpbGUgdGhlIGlucHV0IGhhcyB0ZXh0LCBhbmQganVtcCB0byB0aGUgZW5kcyBvZiB0aGUgbGlzdFxuICAvLyBvdGhlcndpc2Ugb25jZSBhbiBpdGVtIGlzIGhpZ2hsaWdodGVkLlxuICBpZiAoaXNCb3VuZGFyeSkge1xuICAgIHJldHVybiBoYXNBY3RpdmVJdGVtICYmICFoYXNWYWx1ZSA/ICduYXZpZ2F0ZScgOiAnZWRpdCc7XG4gIH1cbiAgaWYgKCFpc0Fycm93KSB7XG4gICAgcmV0dXJuICduYXZpZ2F0ZSc7XG4gIH1cbiAgaWYgKGlzTWFpbk9yaWVudGF0aW9uS2V5KGtleSwgb3JpZW50YXRpb24pKSB7XG4gICAgLy8gTGVmdCBhbmQgUmlnaHQgbW92ZSB0aGUgY2FyZXQgb2YgYSBub24tZW1wdHkgaW5wdXQgd2hpbGUgbm90aGluZyBpcyBoaWdobGlnaHRlZC5cbiAgICByZXR1cm4gb3JpZW50YXRpb24gPT09ICdob3Jpem9udGFsJyAmJiAhaGFzQWN0aXZlSXRlbSAmJiBoYXNWYWx1ZSA/ICdlZGl0JyA6ICduYXZpZ2F0ZSc7XG4gIH1cblxuICAvLyBBIGhpZ2hsaWdodGVkIHN1Ym1lbnUgdHJpZ2dlciB0YWtlcyB0aGUgY3Jvc3MtYXhpcyBrZXlzIHRvIG9wZW4gb3IgY2xvc2UgaXRzIHN1Ym1lbnUuXG4gIGlmIChhY3RpdmVJdGVtT3BlbnNTdWJtZW51ICYmIChpc0Nyb3NzT3JpZW50YXRpb25PcGVuS2V5KGtleSwgb3JpZW50YXRpb24sIHJ0bCkgfHwgaXNDcm9zc09yaWVudGF0aW9uQ2xvc2VLZXkoa2V5LCBvcmllbnRhdGlvbiwgcnRsLCBmYWxzZSkpKSB7XG4gICAgcmV0dXJuICdzdWJtZW51JztcbiAgfVxuICBpZiAob3JpZW50YXRpb24gPT09ICdob3Jpem9udGFsJyAmJiAhaGFzQWN0aXZlSXRlbSkge1xuICAgIHJldHVybiAnZW50ZXItbGlzdCc7XG4gIH1cbiAgLy8gT3RoZXJ3aXNlIHRoZSBjcm9zcy1heGlzIGtleXMgbW92ZSB0aGUgY2FyZXQuIE9uIGFuIGVtcHR5IGlucHV0IHRoZXkgZmFsbCB0aHJvdWdoIHNvIHRoZXlcbiAgLy8gY2FuIHN0aWxsIGNsb3NlIGEgc3VibWVudS5cbiAgcmV0dXJuIGhhc1ZhbHVlID8gJ2VkaXQnIDogJ25hdmlnYXRlJztcbn1cblxuLyoqXG4gKiBSb3V0ZXMga2V5cyBmb3IgYSBmaWx0ZXJhYmxlIG1lbnUncyBpbnB1dCwgd2hpY2ggaG9sZHMgcmVhbCBmb2N1cyB3aGlsZSB0aGUgbGlzdCBpcyBuYXZpZ2F0ZWRcbiAqIHdpdGggYGFyaWEtYWN0aXZlZGVzY2VuZGFudGAuIEtleXMgcmVhY2hpbmcgdGhlIGlucHV0LCBhbmQgdGhvc2UgYW4gaXRlbSB0aGF0IHJlY2VpdmVkIHJlYWxcbiAqIGZvY3VzIGZyb20gYXNzaXN0aXZlIHRlY2hub2xvZ3kgaGFuZHMgYmFjaywgZ28gdGhyb3VnaCBoZXJlOyB0aGUgdHJpZ2dlciByZWxheXMgb25seSB0aGVcbiAqIHZlcnRpY2FsIGFycm93cyB3aGlsZSB0aGUgcG9wdXAgaXMgb3Blbi4gTmF2aWdhdGlvbiBydW5zIHRoZSBtZW51J3Mgb3duIGB1c2VMaXN0TmF2aWdhdGlvbmBcbiAqIGhhbmRsZXIgZGlyZWN0bHkuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VNZW51RmlsdGVyS2V5RG93bihoYXNWYWx1ZSkge1xuICBjb25zdCB7XG4gICAgb3JpZW50YXRpb24sXG4gICAgc3RvcmVcbiAgfSA9IHVzZU1lbnVSb290Q29udGV4dCgpO1xuICBjb25zdCBzdWJtZW51Q29udGV4dCA9IHVzZU1lbnVTdWJtZW51Um9vdENvbnRleHQoKTtcbiAgY29uc3QgZGlyZWN0aW9uID0gdXNlRGlyZWN0aW9uKCk7XG4gIHJldHVybiB1c2VTdGFibGVDYWxsYmFjayhldmVudCA9PiB7XG4gICAgLy8gTGlrZSBhIHBsYWluIG1lbnUsIGlnbm9yZSBrZXlzIHdoaWxlIHRoZSBwb3B1cCBhbmltYXRlcyBvdXQgd2l0aCB0aGUgaW5wdXQgc3RpbGwgZm9jdXNlZC5cbiAgICBpZiAoIXN0b3JlLnNlbGVjdCgnb3BlbicpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGFjdGl2ZUl0ZW0gPSBzdG9yZS5zdGF0ZS5oaWdobGlnaHRlZEl0ZW07XG4gICAgY29uc3QgYWN0aW9uID0gZ2V0TWVudUZpbHRlcktleUFjdGlvbihldmVudCwge1xuICAgICAgb3JpZW50YXRpb24sXG4gICAgICBydGw6IGRpcmVjdGlvbiA9PT0gJ3J0bCcsXG4gICAgICBoYXNBY3RpdmVJdGVtOiBhY3RpdmVJdGVtICE9IG51bGwsXG4gICAgICBhY3RpdmVJdGVtT3BlbnNTdWJtZW51OiBhY3RpdmVJdGVtPy5oYXNBdHRyaWJ1dGUoJ2FyaWEtaGFzcG9wdXAnKSA/PyBmYWxzZSxcbiAgICAgIGhhc1ZhbHVlXG4gICAgfSk7XG4gICAgc3dpdGNoIChhY3Rpb24pIHtcbiAgICAgIGNhc2UgJ2VkaXQnOlxuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgLy8gVHlwaW5nIGVuZHMgcG9pbnRlciBtb2RhbGl0eSwgYXMgaXQgZG9lcyBpbiBhIGNvbWJvYm94LCBzbyBhIHJlc3VsdCBjaGFuZ2UgdGhhdCBtb3Zlc1xuICAgICAgICAvLyB0aGUgaGlnaGxpZ2h0ZWQgaXRlbSBvdXQgZnJvbSB1bmRlciBhIHJlc3RpbmcgcG9pbnRlciBkb2Vzbid0IGNsZWFyIHRoZSBoaWdobGlnaHQuXG4gICAgICAgIGlmIChldmVudC5rZXkubGVuZ3RoID09PSAxICYmICFldmVudC5jdHJsS2V5ICYmICFldmVudC5tZXRhS2V5ICYmICFldmVudC5hbHRLZXkpIHtcbiAgICAgICAgICBzdG9yZS5zdGF0ZS5pbnB1dFByb3BzLm9uS2V5RG93bj8uKGV2ZW50KTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ25hdmlnYXRlJzpcbiAgICAgICAge1xuICAgICAgICAgIGlmIChpc01haW5PcmllbnRhdGlvbktleShldmVudC5rZXksIG9yaWVudGF0aW9uKSkge1xuICAgICAgICAgICAgLy8gS2VlcCB0aGUgc2FtZSBldmVudCBmcm9tIHJlYWNoaW5nIHRoZSBwb3B1cCdzIGxpc3QgbmF2aWdhdGlvbiBhbmQgbW92aW5nIHRoZSB2aXJ0dWFsXG4gICAgICAgICAgICAvLyBjdXJzb3IgYSBzZWNvbmQgdGltZS5cbiAgICAgICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBzdG9yZS5zdGF0ZS5pbnB1dFByb3BzLm9uS2V5RG93bj8uKGV2ZW50KTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgY2FzZSAnZW50ZXItbGlzdCc6XG4gICAgICAgIHtcbiAgICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICBjb25zdCBsaXN0UmVmID0gc3RvcmUuY29udGV4dC5pdGVtRG9tRWxlbWVudHM7XG4gICAgICAgICAgY29uc3QgaW5kZXggPSBldmVudC5rZXkgPT09ICdBcnJvd0Rvd24nID8gZ2V0TWluTGlzdEluZGV4KGxpc3RSZWYsIEVNUFRZX0FSUkFZKSA6IGdldE1heExpc3RJbmRleChsaXN0UmVmLCBFTVBUWV9BUlJBWSk7XG4gICAgICAgICAgaWYgKGxpc3RSZWYuY3VycmVudFtpbmRleF0pIHtcbiAgICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgICBzdG9yZS5zZXRBY3RpdmVJbmRleChpbmRleCwgUkVBU09OUy5rZXlib2FyZCwgZXZlbnQubmF0aXZlRXZlbnQpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgY2FzZSAnc3VibWVudSc6XG4gICAgICAgIHtcbiAgICAgICAgICAvLyBUaGUgaGlnaGxpZ2h0ZWQgaXRlbSdzIG93biBoYW5kbGVycyBkZWNpZGUsIHNpbmNlIG9wZW5pbmcgZGVwZW5kcyBvbiB0aGUgaXRlbSBhbmQgb25cbiAgICAgICAgICAvLyBib3RoIG1lbnVzJyBvcmllbnRhdGlvbnMsIGFuZCB0aGV5IHJlYWQgYGN1cnJlbnRUYXJnZXRgLCBzbyB0aGUga2V5IGlzIGRpc3BhdGNoZWQgb25cbiAgICAgICAgICAvLyBpdC4gSXRzIHByb3BhZ2F0aW9uIHJlYWNoZXMgdGhlIHBvcHVwLCB3aGljaCBjbG9zZXMgYSBzdWJtZW51LlxuICAgICAgICAgIHN0b3BFdmVudChldmVudCk7XG4gICAgICAgICAgY29uc3QgS2V5Ym9hcmRFdmVudENvbnN0cnVjdG9yID0gb3duZXJXaW5kb3coYWN0aXZlSXRlbSkuS2V5Ym9hcmRFdmVudDtcbiAgICAgICAgICBhY3RpdmVJdGVtLmRpc3BhdGNoRXZlbnQobmV3IEtleWJvYXJkRXZlbnRDb25zdHJ1Y3RvcihldmVudC50eXBlLCBldmVudC5uYXRpdmVFdmVudCkpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICBjYXNlICdhY3RpdmF0ZSc6XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGRpc3BhdGNoQ2xpY2tXaXRoTW9kaWZpZXJzKGFjdGl2ZUl0ZW0sIGV2ZW50KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICdjbG9zZSc6XG4gICAgICAgIHtcbiAgICAgICAgICAvLyBNaXJyb3IgdGhlIHBsYWluIG1lbnU6IFNoaWZ0K1RhYiBjbG9zZXMgdGhlIHBvcHVwIGFuZCByZXR1cm5zIGZvY3VzLiBBIHN1Ym1lbnUgcmV0dXJuc1xuICAgICAgICAgIC8vIHRvIHRoZSBlbGVtZW50IHRoYXQgaGVsZCBmb2N1cyBpbiBpdHMgcGFyZW50LCB3aGljaCBpcyB0aGUgcGFyZW50J3MgaW5wdXQgcmF0aGVyIHRoYW5cbiAgICAgICAgICAvLyBpdHMgdW50YWJiYWJsZSB0cmlnZ2VyIHdoZW4gdGhlIHBhcmVudCBpcyBmaWx0ZXJhYmxlIHRvby5cbiAgICAgICAgICBzdG9wRXZlbnQoZXZlbnQpO1xuICAgICAgICAgIGNvbnN0IHJldHVybkVsZW1lbnQgPSBzdG9yZS5zdGF0ZS5wYXJlbnQudHlwZSA9PT0gJ21lbnUnICYmIHN1Ym1lbnVDb250ZXh0Py5nZXRSZXR1cm5FbGVtZW50Py4oKSB8fCBzdG9yZS5zdGF0ZS5hY3RpdmVUcmlnZ2VyRWxlbWVudDtcbiAgICAgICAgICBjb25zdCBkZXRhaWxzID0gY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMuZm9jdXNPdXQsIGV2ZW50Lm5hdGl2ZUV2ZW50KTtcbiAgICAgICAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBkZXRhaWxzKTtcbiAgICAgICAgICBpZiAoIWRldGFpbHMuaXNDYW5jZWxlZCAmJiBpc0hUTUxFbGVtZW50KHJldHVybkVsZW1lbnQpKSB7XG4gICAgICAgICAgICByZXR1cm5FbGVtZW50LmZvY3VzKCk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICBkZWZhdWx0OlxuICAgICAgICBicmVhaztcbiAgICB9XG4gIH0pO1xufSIsImltcG9ydCB7IEVNUFRZX0FSUkFZIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuaW1wb3J0IHsgZ2V0TWF4TGlzdEluZGV4LCBnZXRNaW5MaXN0SW5kZXgsIGdldE5leHRMaXN0SW5kZXggfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvdXRpbHMvY29tcG9zaXRlLm1qc1wiO1xuaW1wb3J0IHsgaXNNYWluT3JpZW50YXRpb25Ub0VuZEtleSB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9ob29rcy91c2VMaXN0TmF2aWdhdGlvbi5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG4vKipcbiAqIE1vdmVzIGEgbWVudSdzIGhpZ2hsaWdodCBmcm9tIGBpdGVtYCBvbmUgc3RlcCBpbiB0aGUgZGlyZWN0aW9uIG9mIGEgbWFpbi1vcmllbnRhdGlvbiBhcnJvdyBrZXksXG4gKiB3aXRoIHRoZSBzYW1lIHN0ZXAgYXMgdGhlIG1lbnUncyBvd24gbGlzdCBuYXZpZ2F0aW9uLCBhbmQgcmV0dXJucyB0aGUgbmV3bHkgaGlnaGxpZ2h0ZWQgaXRlbS5cbiAqIEEgc3RlcCB0aGF0IHdvdWxkIGxlYXZlIGEgbWVudSB3aG9zZSBuYXZpZ2F0aW9uIGVzY2FwZXMgdG8gaXRzIGlucHV0IGtlZXBzIHRoZSBoaWdobGlnaHQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBtb3ZlSGlnaGxpZ2h0RnJvbShzdG9yZSwgaXRlbSwgZXZlbnQsIG9wdGlvbnMpIHtcbiAgY29uc3Qge1xuICAgIG9yaWVudGF0aW9uLFxuICAgIHJ0bCxcbiAgICBsb29wRm9jdXMsXG4gICAgYWxsb3dFc2NhcGVcbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IGxpc3RSZWYgPSBzdG9yZS5jb250ZXh0Lml0ZW1Eb21FbGVtZW50cztcbiAgY29uc3QgaXRlbXMgPSBsaXN0UmVmLmN1cnJlbnQ7XG4gIGNvbnN0IHtcbiAgICBpbmRleFxuICB9ID0gZ2V0TmV4dExpc3RJbmRleChpdGVtcywgaXRlbXMuaW5kZXhPZihpdGVtKSwge1xuICAgIGRlY3JlbWVudDogIWlzTWFpbk9yaWVudGF0aW9uVG9FbmRLZXkoZXZlbnQua2V5LCBvcmllbnRhdGlvbiwgcnRsKSxcbiAgICBsb29wRm9jdXMsXG4gICAgYWxsb3dFc2NhcGUsXG4gICAgLy8gTWF0Y2ggdGhlIG1lbnUncyBsaXN0IG5hdmlnYXRpb246IGBhcmlhLWRpc2FibGVkYCBpdGVtcyBzdGF5IHJlYWNoYWJsZS5cbiAgICBkaXNhYmxlZEluZGljZXM6IEVNUFRZX0FSUkFZLFxuICAgIG1pbkluZGV4OiBnZXRNaW5MaXN0SW5kZXgobGlzdFJlZiwgRU1QVFlfQVJSQVkpLFxuICAgIG1heEluZGV4OiBnZXRNYXhMaXN0SW5kZXgobGlzdFJlZiwgRU1QVFlfQVJSQVkpXG4gIH0pO1xuICBjb25zdCBuZXh0ID0gaXRlbXNbaW5kZXhdO1xuICBpZiAobmV4dCkge1xuICAgIHN0b3JlLnNldEFjdGl2ZUluZGV4KGluZGV4LCBSRUFTT05TLmtleWJvYXJkLCBldmVudC5uYXRpdmVFdmVudCk7XG4gICAgbmV4dC5zY3JvbGxJbnRvVmlldz8uKHtcbiAgICAgIGJsb2NrOiAnbmVhcmVzdCcsXG4gICAgICBpbmxpbmU6ICduZWFyZXN0J1xuICAgIH0pO1xuICB9XG4gIHJldHVybiBuZXh0ID8/IHVuZGVmaW5lZDtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IG93bmVyRG9jdW1lbnQgfSBmcm9tICdAYmFzZS11aS91dGlscy9vd25lcic7XG5pbXBvcnQgeyBjb250YWlucyB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3NoYWRvd0RvbSc7XG5pbXBvcnQgeyB1c2VTdGFibGVDYWxsYmFjayB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVN0YWJsZUNhbGxiYWNrJztcbmltcG9ydCB7IGlzSFRNTEVsZW1lbnQgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyBhY3RpdmVFbGVtZW50LCBnZXRUYXJnZXQgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvdXRpbHMubWpzXCI7XG5pbXBvcnQgeyBGaWx0ZXJEcm9wZG93bkxpc3QgfSBmcm9tIFwiLi4vLi4vZmlsdGVyLWRyb3Bkb3duL2xpc3QvRmlsdGVyRHJvcGRvd25MaXN0Lm1qc1wiO1xuaW1wb3J0IHsgbWVyZ2VQcm9wcyB9IGZyb20gXCIuLi8uLi9tZXJnZS1wcm9wcy9pbmRleC5tanNcIjtcbmltcG9ydCB7IHVzZU1lbnVGaWx0ZXJLZXlEb3duIH0gZnJvbSBcIi4vdXNlTWVudUZpbHRlcktleURvd24ubWpzXCI7XG5pbXBvcnQgeyBpc01haW5PcmllbnRhdGlvbktleSB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC9ob29rcy91c2VMaXN0TmF2aWdhdGlvbi5tanNcIjtcbmltcG9ydCB7IHVzZU1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L01lbnVSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZUNvbXBvc2l0ZUxpc3RDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jb21wb3NpdGUvbGlzdC9Db21wb3NpdGVMaXN0Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZUZpbHRlckRyb3Bkb3duSXRlbUNvbnRleHQsIHVzZUZpbHRlckRyb3Bkb3duUm9vdENvbnRleHQsIHVzZUZpbHRlckRyb3Bkb3duVmFsdWVDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2ZpbHRlci1kcm9wZG93bi9yb290L0ZpbHRlckRyb3Bkb3duUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyByZXNvbHZlUG9wdXBMYWJlbCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVzb2x2ZVBvcHVwTGFiZWwubWpzXCI7XG5pbXBvcnQgeyB1c2VEaXJlY3Rpb24gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2RpcmVjdGlvbi1jb250ZXh0L0RpcmVjdGlvbkNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBtb3ZlSGlnaGxpZ2h0RnJvbSB9IGZyb20gXCIuL21vdmVIaWdobGlnaHRGcm9tLm1qc1wiO1xuaW1wb3J0IHsgcmVmb2N1c093bmVyIH0gZnJvbSBcIi4uLy4uL2ZpbHRlci1kcm9wZG93bi91dGlscy9yZWZvY3VzT3duZXIubWpzXCI7XG5cbi8qKlxuICogVGhlIGxpc3Qgb2YgYSBmaWx0ZXJhYmxlIG1lbnU6IGl0IHRha2VzIHRoZSBgbWVudWAgcm9sZSB3aGlsZSB0aGUgcG9wdXAgaXMgYSBkaWFsb2cgaG9sZGluZ1xuICogdGhlIGlucHV0LCBhbmQgaXQgZm9yd2FyZHMga2V5cyB0aGF0IGxhbmQgb24gaXQgdG8gdGhlIGlucHV0LlxuICovXG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZXhwb3J0IGNvbnN0IE1lbnVGaWx0ZXJMaXN0ID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gTWVudUZpbHRlckxpc3QoY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgc3RvcmUsXG4gICAgb3JpZW50YXRpb24sXG4gICAgbG9vcEZvY3VzLFxuICAgIGFsbG93RXNjYXBlXG4gIH0gPSB1c2VNZW51Um9vdENvbnRleHQoKTtcbiAgY29uc3QgZGlyZWN0aW9uID0gdXNlRGlyZWN0aW9uKCk7XG4gIGNvbnN0IHtcbiAgICBvbkl0ZW1zQ2hhbmdlLFxuICAgIGZvY3VzT3duZXJSZWYsXG4gICAgdHJpZ2dlcklkXG4gIH0gPSB1c2VGaWx0ZXJEcm9wZG93blJvb3RDb250ZXh0KCk7XG4gIGNvbnN0IHtcbiAgICBsaXN0UmVmXG4gIH0gPSB1c2VGaWx0ZXJEcm9wZG93bkl0ZW1Db250ZXh0KCk7XG4gIGNvbnN0IHtcbiAgICBzdWJzY3JpYmVNYXBDaGFuZ2VcbiAgfSA9IHVzZUNvbXBvc2l0ZUxpc3RDb250ZXh0KCk7XG4gIGNvbnN0IHZhbHVlID0gdXNlRmlsdGVyRHJvcGRvd25WYWx1ZUNvbnRleHQoKTtcbiAgY29uc3QgaGFuZGxlSW5wdXRLZXlEb3duID0gdXNlTWVudUZpbHRlcktleURvd24odmFsdWUgIT09ICcnKTtcbiAgY29uc3QgaGFuZGxlS2V5RG93biA9IHVzZVN0YWJsZUNhbGxiYWNrKGV2ZW50ID0+IHtcbiAgICBjb25zdCBvd25lciA9IGZvY3VzT3duZXJSZWYuY3VycmVudDtcbiAgICBjb25zdCB0YXJnZXQgPSBnZXRUYXJnZXQoZXZlbnQubmF0aXZlRXZlbnQpO1xuICAgIGNvbnN0IG93bmVyRm9jdXNlZCA9IG93bmVyICE9IG51bGwgJiYgYWN0aXZlRWxlbWVudChvd25lckRvY3VtZW50KG93bmVyKSkgPT09IG93bmVyO1xuICAgIGNvbnN0IGZyb21OZXN0ZWRQb3B1cCA9ICFjb250YWlucyhldmVudC5jdXJyZW50VGFyZ2V0LCB0YXJnZXQpO1xuICAgIC8vIEtleXMgdGhlIGlucHV0IGZvcndhcmRzIHRvIGl0cyBoaWdobGlnaHRlZCBpdGVtIGFycml2ZSBoZXJlIHdoaWxlIHRoZSBpbnB1dCBzdGlsbCBob2xkc1xuICAgIC8vIGZvY3VzLCBhbmQgYSBuZXN0ZWQgcG9wdXAncyBrZXlzIGJ1YmJsZSB0aHJvdWdoIHRoaXMgUmVhY3QgdHJlZSBmcm9tIG91dHNpZGUgdGhlIGxpc3QuXG4gICAgaWYgKG93bmVyID09IG51bGwgfHwgb3duZXJGb2N1c2VkIHx8IGZyb21OZXN0ZWRQb3B1cCkge1xuICAgICAgaWYgKGV2ZW50LndoaWNoICE9PSAyMjkgJiYgIWV2ZW50LnNoaWZ0S2V5ICYmICFldmVudC5jdHJsS2V5ICYmICFldmVudC5tZXRhS2V5ICYmICFldmVudC5hbHRLZXkgJiYgaXNNYWluT3JpZW50YXRpb25LZXkoZXZlbnQua2V5LCBvcmllbnRhdGlvbikpIHtcbiAgICAgICAgLy8gS2VlcCBtYWluLWF4aXMga2V5cyBmcm9tIHJlYWNoaW5nIHRoaXMgcG9wdXAncyBvd24gbGlzdCBuYXZpZ2F0aW9uLCB3aGljaCBsb3N0IGl0c1xuICAgICAgICAvLyBwbGFjZSB3aGlsZSB0aGUgbmVzdGVkIHBvcHVwIGhlbGQgZm9jdXMuIEEgcGxhaW4gc3VibWVudSB0aGF0IGNsb3NlcyBvbiB0aGUga2V5IGhhbmRzXG4gICAgICAgIC8vIGZvY3VzIGJhY2sgYW5kIGxldHMgaXQgdGhyb3VnaCwgc28gbW92ZSBvbiBmcm9tIGl0cyB0cmlnZ2VyIGFzIGEgcGxhaW4gcGFyZW50IHdvdWxkLlxuICAgICAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgY29uc3QgdHJpZ2dlciA9IGZyb21OZXN0ZWRQb3B1cCAmJiBvd25lckZvY3VzZWQgPyBnZXROZXN0ZWRQb3B1cFRyaWdnZXIodGFyZ2V0KSA6IHVuZGVmaW5lZDtcbiAgICAgICAgaWYgKHRyaWdnZXIpIHtcbiAgICAgICAgICBtb3ZlSGlnaGxpZ2h0RnJvbShzdG9yZSwgdHJpZ2dlciwgZXZlbnQsIHtcbiAgICAgICAgICAgIG9yaWVudGF0aW9uLFxuICAgICAgICAgICAgcnRsOiBkaXJlY3Rpb24gPT09ICdydGwnLFxuICAgICAgICAgICAgbG9vcEZvY3VzLFxuICAgICAgICAgICAgYWxsb3dFc2NhcGVcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIC8vIEFuIGl0ZW0gdGhhdCBhbHJlYWR5IGFjdGVkIG9uIHRoZSBrZXkgKEVudGVyIGFuZCBTcGFjZSBhY3RpdmF0ZSBpdCkga2VlcHMgaXQuXG4gICAgaWYgKGV2ZW50LmRlZmF1bHRQcmV2ZW50ZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBSZWFsIGZvY3VzIGNhbiBsYW5kIGluc2lkZSB0aGUgbGlzdCB3aGlsZSB0aGUgaW5wdXQgc3RpbGwgb3ducyB0aGUga2V5Ym9hcmQ6IGEgc2Nyb2xsYmFyXG4gICAgLy8gcHJlc3MgZm9jdXNlcyB0aGUgbGlzdCBpdHNlbGYsIGFuZCBhIHNjcmVlbiByZWFkZXIgZm9sbG93aW5nIGBhcmlhLWFjdGl2ZWRlc2NlbmRhbnRgXG4gICAgLy8gZm9jdXNlcyB0aGUgaGlnaGxpZ2h0ZWQgaXRlbS4gSGFuZCBmb2N1cyBiYWNrIGFuZCByb3V0ZSB0aGUga2V5IGFzIHRoZSBpbnB1dCB3b3VsZDsgYVxuICAgIC8vIHR5cGluZyBrZXkncyBkZWZhdWx0IGFjdGlvbiBmb2xsb3dzIHRoZSBtb3ZlZCBmb2N1cyBpbnRvIHRoZSBpbnB1dC5cbiAgICByZWZvY3VzT3duZXIob3duZXIpO1xuICAgIGhhbmRsZUlucHV0S2V5RG93bihldmVudCk7XG4gIH0pO1xuXG4gIC8vIFRoZSBpdGVtIHdob3NlIGBhcmlhLWNvbnRyb2xzYCBwb3B1cCBob2xkcyBgdGFyZ2V0YC4gVGhlIHBvcHVwIHNoYXJlcyB0aGUgdGFyZ2V0J3Mgcm9vdCxcbiAgLy8gd2hpY2ggaXMgYSBzaGFkb3cgcm9vdCB3aGVuIGl0J3MgcG9ydGFsZWQgaW50byBvbmUuXG4gIGZ1bmN0aW9uIGdldE5lc3RlZFBvcHVwVHJpZ2dlcih0YXJnZXQpIHtcbiAgICBjb25zdCByb290ID0gdGFyZ2V0LmdldFJvb3ROb2RlKCk7XG4gICAgcmV0dXJuIGxpc3RSZWYuY3VycmVudC5maW5kKGl0ZW0gPT4ge1xuICAgICAgY29uc3QgcG9wdXBJZCA9IGl0ZW0/LmdldEF0dHJpYnV0ZSgnYXJpYS1jb250cm9scycpO1xuICAgICAgcmV0dXJuIHBvcHVwSWQgIT0gbnVsbCAmJiBpc0hUTUxFbGVtZW50KGl0ZW0pICYmIGNvbnRhaW5zKHJvb3QuZ2V0RWxlbWVudEJ5SWQocG9wdXBJZCksIHRhcmdldCk7XG4gICAgfSk7XG4gIH1cblxuICAvLyBgbnVsbGAgZGlzdGluZ3Vpc2hlcyB0aGUgaW5pdGlhbCByZWdpc3RyYXRpb24gZnJvbSBhIGxpc3QgZW1wdGllZCBieSBmaWx0ZXJpbmcuXG4gIGNvbnN0IHByZXZpb3VzSXRlbXNSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG5cbiAgLy8gQ29tcG9zaXRlTGlzdCBub3RpZmllcyBzdWJzY3JpYmVycyBiZWZvcmUgaXRzIGBvbk1hcENoYW5nZWAsIHNvIHRoZSBwb3NpdGlvbmVyIHJlcG9ydHMgdGhlXG4gIC8vIGhpZ2hsaWdodCBhZ2FpbnN0IHRoZSBzZXR0bGVkIHJlZ2lzdHJ5IG9ubHkgYWZ0ZXIgdGhlIGl0ZW1zIGNoYW5nZSBoYXMgYmVlbiByZXNvbHZlZCBoZXJlLlxuICBjb25zdCBoYW5kbGVJdGVtTWFwQ2hhbmdlID0gdXNlU3RhYmxlQ2FsbGJhY2soKCkgPT4ge1xuICAgIGNvbnN0IGl0ZW1zID0gWy4uLmxpc3RSZWYuY3VycmVudF07XG4gICAgY29uc3QgcHJldmlvdXNJdGVtcyA9IHByZXZpb3VzSXRlbXNSZWYuY3VycmVudDtcbiAgICBjb25zdCBjaGFuZ2VkID0gcHJldmlvdXNJdGVtcyA9PT0gbnVsbCB8fCBwcmV2aW91c0l0ZW1zLmxlbmd0aCAhPT0gaXRlbXMubGVuZ3RoIHx8IGl0ZW1zLnNvbWUoKGl0ZW0sIGluZGV4KSA9PiBpdGVtICE9PSBwcmV2aW91c0l0ZW1zW2luZGV4XSk7XG4gICAgaWYgKGNoYW5nZWQgJiYgcHJldmlvdXNJdGVtcyAhPT0gbnVsbCkge1xuICAgICAgb25JdGVtc0NoYW5nZShwcmV2aW91c0l0ZW1zKTtcbiAgICB9XG4gICAgcHJldmlvdXNJdGVtc1JlZi5jdXJyZW50ID0gaXRlbXM7XG4gIH0pO1xuICB1c2VJc29MYXlvdXRFZmZlY3QoKCkgPT4ge1xuICAgIHJldHVybiBzdWJzY3JpYmVNYXBDaGFuZ2UoaGFuZGxlSXRlbU1hcENoYW5nZSk7XG4gIH0sIFtzdWJzY3JpYmVNYXBDaGFuZ2UsIGhhbmRsZUl0ZW1NYXBDaGFuZ2VdKTtcbiAgY29uc3QgYXJpYUxhYmVsbGVkQnkgPSByZXNvbHZlUG9wdXBMYWJlbChjb21wb25lbnRQcm9wcywgbnVsbCwgdHJpZ2dlcklkID8/IG51bGwpO1xuICBjb25zdCBsaXN0UHJvcHMgPSBtZXJnZVByb3BzKHtcbiAgICByb2xlOiAnbWVudScsXG4gICAgJ2FyaWEtbGFiZWxsZWRieSc6IGFyaWFMYWJlbGxlZEJ5LFxuICAgICdhcmlhLW9yaWVudGF0aW9uJzogb3JpZW50YXRpb24gPT09ICdob3Jpem9udGFsJyA/ICdob3Jpem9udGFsJyA6IHVuZGVmaW5lZCxcbiAgICBvbktleURvd246IGhhbmRsZUtleURvd25cbiAgfSwgY29tcG9uZW50UHJvcHMpO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goRmlsdGVyRHJvcGRvd25MaXN0LCB7XG4gICAgLi4ubGlzdFByb3BzLFxuICAgIHJlZjogZm9yd2FyZGVkUmVmXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51RmlsdGVyTGlzdC5kaXNwbGF5TmFtZSA9IFwiTWVudUZpbHRlckxpc3RcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZVN0b3JlIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvc3RvcmUnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZVJlZldpdGhJbml0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlUmVmV2l0aEluaXQnO1xuaW1wb3J0IHsgdXNlRmlsdGVyRHJvcGRvd25JdGVtQ29udGV4dCB9IGZyb20gXCIuLi9yb290L0ZpbHRlckRyb3Bkb3duUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VGaWx0ZXJEcm9wZG93bkdyb3VwQ29udGV4dCB9IGZyb20gXCIuL0ZpbHRlckRyb3Bkb3duR3JvdXBDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlSXRlbVJlZ2lzdHJ5IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VJdGVtUmVnaXN0cnkubWpzXCI7XG5mdW5jdGlvbiBpc0dyb3VwSGlkZGVuKHN0YXRlLCBpdGVtcykge1xuICAvLyBBIGdyb3VwIHdpdGggbm8gbWVtYmVycyBoYXNuJ3QgYmVlbiBmaWx0ZXJlZCBvdXQsIGl0IGhhc24ndCByZWdpc3RlcmVkIHlldC5cbiAgaWYgKHN0YXRlLnZpc2libGVJdGVtSWRzID09PSBudWxsIHx8IGl0ZW1zLnNpemUgPT09IDApIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgZm9yIChjb25zdCBbaWQsIHJldGFpbmVkXSBvZiBpdGVtcykge1xuICAgIGlmIChyZXRhaW5lZCB8fCBzdGF0ZS52aXNpYmxlSXRlbUlkcy5oYXMoaWQpKSB7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG4gIHJldHVybiB0cnVlO1xufVxuLyoqXG4gKiBUcmFja3Mgd2hpY2ggaXRlbXMgYmVsb25nIHRvIGEgZ3JvdXAgYW5kIGhpZGVzIHRoZSBncm91cCBvbmNlIG5vbmUgb2YgdGhlbSBtYXRjaC5cbiAqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUZpbHRlckRyb3Bkb3duR3JvdXAoKSB7XG4gIGNvbnN0IHtcbiAgICBzdG9yZVxuICB9ID0gdXNlRmlsdGVyRHJvcGRvd25JdGVtQ29udGV4dCgpO1xuICBjb25zdCBwYXJlbnRDb250ZXh0ID0gdXNlRmlsdGVyRHJvcGRvd25Hcm91cENvbnRleHQoKTtcbiAgY29uc3Qge1xuICAgIGl0ZW1zLFxuICAgIHJlZ2lzdGVySXRlbVxuICB9ID0gdXNlSXRlbVJlZ2lzdHJ5KCk7XG4gIGNvbnN0IGhpZGRlbiA9IHVzZVN0b3JlKHN0b3JlLCBpc0dyb3VwSGlkZGVuLCBpdGVtcyk7XG5cbiAgLy8gQSBuZXN0ZWQgY29udGFpbmVyIGNvbGxlY3RzIGl0cyBvd24gaXRlbXMsIHNvIHRoZSBlbmNsb3Npbmcgb25lIG9ubHkgZXZlciBzZWVzIHRoaXNcbiAgLy8gcmVnaXN0cmF0aW9uLiBSZXBvcnQgdmlzaWJpbGl0eSB1cHdhcmQgb3IgYSBncm91cCBvZiBncm91cHMgd291bGQgbG9vayBlbXB0eS5cbiAgY29uc3QgZ3JvdXBJZCA9IHVzZVJlZldpdGhJbml0KCgpID0+IFN5bWJvbCgnZmlsdGVyLWRyb3Bkb3duLWdyb3VwJykpLmN1cnJlbnQ7XG4gIGNvbnN0IHJlZ2lzdGVySW5QYXJlbnQgPSBwYXJlbnRDb250ZXh0Py5yZWdpc3Rlckl0ZW07XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiByZWdpc3RlckluUGFyZW50Py4oZ3JvdXBJZCwgIWhpZGRlbiksIFtyZWdpc3RlckluUGFyZW50LCBncm91cElkLCBoaWRkZW5dKTtcbiAgY29uc3QgY29udGV4dCA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICByZWdpc3Rlckl0ZW1cbiAgfSksIFtyZWdpc3Rlckl0ZW1dKTtcbiAgcmV0dXJuIHtcbiAgICBoaWRkZW4sXG4gICAgY29udGV4dFxuICB9O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlRmlsdGVyRHJvcGRvd25Hcm91cCB9IGZyb20gXCIuLi8uLi9maWx0ZXItZHJvcGRvd24vZ3JvdXAvdXNlRmlsdGVyRHJvcGRvd25Hcm91cC5tanNcIjtcbmltcG9ydCB7IEZpbHRlckRyb3Bkb3duR3JvdXBDb250ZXh0IH0gZnJvbSBcIi4uLy4uL2ZpbHRlci1kcm9wZG93bi9ncm91cC9GaWx0ZXJEcm9wZG93bkdyb3VwQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IE1lbnVHcm91cFBsYWluIH0gZnJvbSBcIi4uL2dyb3VwL01lbnVHcm91cC5tanNcIjtcbmltcG9ydCB7IE1lbnVSYWRpb0dyb3VwUGxhaW4gfSBmcm9tIFwiLi4vcmFkaW8tZ3JvdXAvTWVudVJhZGlvR3JvdXAubWpzXCI7XG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLyoqXG4gKiBgTWVudS5Hcm91cGAgaW4gYSBmaWx0ZXJhYmxlIG1lbnU6IGhpZGRlbiwgbGFiZWwgaW5jbHVkZWQsIG9uY2UgdGhlIHF1ZXJ5IGZpbHRlcnMgb3V0IGFsbCBvZlxuICogaXRzIGl0ZW1zLlxuICpcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgY29uc3QgTWVudUZpbHRlckdyb3VwID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gTWVudUZpbHRlckdyb3VwKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIGhpZGRlbixcbiAgICBjb250ZXh0XG4gIH0gPSB1c2VGaWx0ZXJEcm9wZG93bkdyb3VwKCk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChGaWx0ZXJEcm9wZG93bkdyb3VwQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBjb250ZXh0LFxuICAgIGNoaWxkcmVuOiAvKiNfX1BVUkVfXyovX2pzeChNZW51R3JvdXBQbGFpbiwge1xuICAgICAgLi4ucHJvcHMsXG4gICAgICBoaWRkZW46IGhpZGRlbiB8fCBwcm9wcy5oaWRkZW4gfHwgdW5kZWZpbmVkLFxuICAgICAgcmVmOiBmb3J3YXJkZWRSZWZcbiAgICB9KVxuICB9KTtcbn0pO1xuXG4vKipcbiAqIGBNZW51LlJhZGlvR3JvdXBgIGluIGEgZmlsdGVyYWJsZSBtZW51LCBoaWRkZW4gbGlrZSBgTWVudUZpbHRlckdyb3VwYC5cbiAqXG4gKiBAaW50ZXJuYWxcbiAqL1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgTWVudUZpbHRlckdyb3VwLmRpc3BsYXlOYW1lID0gXCJNZW51RmlsdGVyR3JvdXBcIjtcbmV4cG9ydCBjb25zdCBNZW51RmlsdGVyUmFkaW9Hcm91cCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIE1lbnVGaWx0ZXJSYWRpb0dyb3VwKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIGhpZGRlbixcbiAgICBjb250ZXh0XG4gIH0gPSB1c2VGaWx0ZXJEcm9wZG93bkdyb3VwKCk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChGaWx0ZXJEcm9wZG93bkdyb3VwQ29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBjb250ZXh0LFxuICAgIGNoaWxkcmVuOiAvKiNfX1BVUkVfXyovX2pzeChNZW51UmFkaW9Hcm91cFBsYWluLCB7XG4gICAgICAuLi5wcm9wcyxcbiAgICAgIGhpZGRlbjogaGlkZGVuIHx8IHByb3BzLmhpZGRlbiB8fCB1bmRlZmluZWQsXG4gICAgICByZWY6IGZvcndhcmRlZFJlZlxuICAgIH0pXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51RmlsdGVyUmFkaW9Hcm91cC5kaXNwbGF5TmFtZSA9IFwiTWVudUZpbHRlclJhZGlvR3JvdXBcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VSZWZXaXRoSW5pdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZVJlZldpdGhJbml0JztcbmltcG9ydCB7IHVzZVZhbHVlQXNSZWYgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VWYWx1ZUFzUmVmJztcbmltcG9ydCB7IHVzZVN0b3JlIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvc3RvcmUnO1xuaW1wb3J0IHsgdXNlRmlsdGVyRHJvcGRvd25JdGVtQ29udGV4dCB9IGZyb20gXCIuLi9yb290L0ZpbHRlckRyb3Bkb3duUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VGaWx0ZXJEcm9wZG93bkdyb3VwQ29udGV4dCB9IGZyb20gXCIuLi9ncm91cC9GaWx0ZXJEcm9wZG93bkdyb3VwQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IERFVEFDSEVEX09XTkVSLCBzZWxlY3RvcnMgfSBmcm9tIFwiLi4vc3RvcmUubWpzXCI7XG5pbXBvcnQgeyB1bndyYXBMYXp5UmVuZGVyUHJvcCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlUmVuZGVyRWxlbWVudC5tanNcIjtcblxuLyoqIFRleHQgb2YgdGhlIHJlbmRlcmVkIGNoaWxkcmVuLCBmb3Igd2hlbiB0aGUgZWxlbWVudCBpcyBmaWx0ZXJlZCBvdXQgYW5kIGhhcyBubyBET00gbm9kZS4gKi9cbmZ1bmN0aW9uIGNoaWxkcmVuVGV4dChjaGlsZHJlbikge1xuICBpZiAodHlwZW9mIGNoaWxkcmVuID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgY2hpbGRyZW4gPT09ICdudW1iZXInKSB7XG4gICAgcmV0dXJuIFN0cmluZyhjaGlsZHJlbik7XG4gIH1cbiAgaWYgKEFycmF5LmlzQXJyYXkoY2hpbGRyZW4pKSB7XG4gICAgcmV0dXJuIGNoaWxkcmVuLm1hcChjaGlsZHJlblRleHQpLmpvaW4oJycpO1xuICB9XG4gIGlmICgvKiNfX1BVUkVfXyovUmVhY3QuaXNWYWxpZEVsZW1lbnQoY2hpbGRyZW4pKSB7XG4gICAgcmV0dXJuIGNoaWxkcmVuVGV4dChjaGlsZHJlbi5wcm9wcy5jaGlsZHJlbik7XG4gIH1cbiAgcmV0dXJuICcnO1xufVxuLyoqXG4gKiBSZWdpc3RlcnMgYW4gaXRlbSB3aXRoIHRoZSBlbmNsb3NpbmcgZmlsdGVyIHJvb3QgYW5kIHJlcG9ydHMgd2hldGhlciB0aGUgcXVlcnkga2VlcHMgaXQuXG4gKlxuICogVGhlIGl0ZW0gcmVuZGVycyBvbmNlIGJlZm9yZSBpdCBpcyByZWdpc3RlcmVkIHNvIGl0cyByZW5kZXJlZCB0ZXh0IGNhbiBiZSByZWFkIGFuZCBjYWNoZWQ6IGFcbiAqIHBvcHVwIGNhbiBvcGVuIHdpdGggYSBxdWVyeSB0aGF0IGFscmVhZHkgZXhjbHVkZXMgdGhlIGl0ZW0sIGFuZCBhIGhpZGRlbiBpdGVtIGhhcyBubyB0ZXh0IGxlZnRcbiAqIHRvIG1hdGNoIGFnYWluc3QuXG4gKlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VGaWx0ZXJEcm9wZG93bkl0ZW0ocGFyYW1zKSB7XG4gIGNvbnN0IHtcbiAgICBsYWJlbCxcbiAgICByZXRhaW5Hcm91cCA9IGZhbHNlLFxuICAgIGNoaWxkcmVuLFxuICAgIHJlbmRlcixcbiAgICBjb250ZXh0XG4gIH0gPSBwYXJhbXM7XG4gIGNvbnN0IG5lYXJlc3RDb250ZXh0ID0gdXNlRmlsdGVyRHJvcGRvd25JdGVtQ29udGV4dChjb250ZXh0ICE9PSB1bmRlZmluZWQpO1xuICBjb25zdCBncm91cENvbnRleHQgPSB1c2VGaWx0ZXJEcm9wZG93bkdyb3VwQ29udGV4dCgpO1xuICBjb25zdCBvd25lciA9IGNvbnRleHQgPT09IHVuZGVmaW5lZCA/IG5lYXJlc3RDb250ZXh0IDogY29udGV4dDtcbiAgY29uc3Qge1xuICAgIHJlZ2lzdGVySXRlbSxcbiAgICBzdG9yZVxuICB9ID0gb3duZXIgPz8gREVUQUNIRURfT1dORVI7XG4gIGNvbnN0IHJlZ2lzdGVyR3JvdXBJdGVtID0gZ3JvdXBDb250ZXh0Py5yZWdpc3Rlckl0ZW07XG4gIGNvbnN0IGl0ZW1JZCA9IHVzZVJlZldpdGhJbml0KCgpID0+IFN5bWJvbCgnZmlsdGVyLWRyb3Bkb3duLWl0ZW0nKSkuY3VycmVudDtcbiAgY29uc3QgcmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCByZWdpc3RlcmVkVGV4dFJlZiA9IFJlYWN0LnVzZVJlZih1bmRlZmluZWQpO1xuICBjb25zdCBtYXRjaGVkID0gdXNlU3RvcmUoc3RvcmUsIHNlbGVjdG9ycy5pc0l0ZW1WaXNpYmxlLCBpdGVtSWQpO1xuXG4gIC8vIEFuIGluaXRpYWwgaXRlbSBpcyB2aXNpYmxlIGJlZm9yZSByZWdpc3RyYXRpb24gKGB2aXNpYmxlSXRlbUlkc2AgaXMgbnVsbCksIHNvIHN0YXJ0XG4gIC8vIHJlZ2lzdGVyZWQgYW5kIHNraXAgdGhlIG1vdW50IHJlLXJlbmRlci4gQSBsYXRlIGl0ZW0gdW5kZXIgYW4gYWN0aXZlIGZpbHRlciBzdGFydHNcbiAgLy8gdW5yZWdpc3RlcmVkIGFuZCByZW5kZXJzIG9uY2Ugc28gaXRzIERPTSB0ZXh0IGNhbiBiZSBjYXB0dXJlZC5cbiAgY29uc3QgW3JlZ2lzdGVyZWQsIHNldFJlZ2lzdGVyZWRdID0gUmVhY3QudXNlU3RhdGUobWF0Y2hlZCk7XG5cbiAgLy8gUmVhZCB0aHJvdWdoIHJlZnMgc28gYHJlZ2lzdGVyYCBzdGF5cyBzdGFibGUgd2hpbGUgdGhlIGNoaWxkcmVuIGNoYW5nZSBpZGVudGl0eS5cbiAgY29uc3QgY2hpbGRyZW5SZWYgPSB1c2VWYWx1ZUFzUmVmKGNoaWxkcmVuKTtcbiAgY29uc3QgcmVuZGVyUmVmID0gdXNlVmFsdWVBc1JlZihyZW5kZXIpO1xuXG4gIC8vIFdoYXQgdGhlIGNoaWxkcmVuIGxhc3QgcmVhZCBhcywgdG8gdGVsbCB3aGV0aGVyIHRoZXkgY2hhbmdlZCB3aGlsZSB0aGUgaXRlbSByZW5kZXJlZCBubyB0ZXh0LlxuICBjb25zdCBjaGlsZHJlblRleHRSZWYgPSBSZWFjdC51c2VSZWYodW5kZWZpbmVkKTtcbiAgY29uc3QgcmVzb2x2ZVRleHQgPSBSZWFjdC51c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKGxhYmVsICE9IG51bGwpIHtcbiAgICAgIHJldHVybiBsYWJlbDtcbiAgICB9XG4gICAgLy8gQW4gaXRlbSB3aXRob3V0IGNoaWxkcmVuIGNhbiBjYXJyeSBpdHMgdGV4dCBpbiBpdHMgYHJlbmRlcmAgZWxlbWVudCBpbnN0ZWFkLlxuICAgIGNvbnN0IGZyb21DaGlsZHJlbiA9IGNoaWxkcmVuVGV4dChjaGlsZHJlblJlZi5jdXJyZW50ID8/IHVud3JhcExhenlSZW5kZXJQcm9wKHJlbmRlclJlZi5jdXJyZW50KSk7XG4gICAgY29uc3QgcHJldmlvdXNDaGlsZHJlblRleHQgPSBjaGlsZHJlblRleHRSZWYuY3VycmVudDtcbiAgICBjaGlsZHJlblRleHRSZWYuY3VycmVudCA9IGZyb21DaGlsZHJlbjtcbiAgICBpZiAocmVmLmN1cnJlbnQgIT09IG51bGwpIHtcbiAgICAgIHJldHVybiByZWYuY3VycmVudC50ZXh0Q29udGVudCA/PyAnJztcbiAgICB9XG4gICAgLy8gQSBmaWx0ZXJlZC1vdXQgaXRlbSBoYXMgbm8gRE9NIG5vZGUgbGVmdC4gSXRzIGNoaWxkcmVuIGFyZSBvbmx5IGEgc3RhbmQtaW4gZm9yIHRoZSB0ZXh0IGl0XG4gICAgLy8gcmVuZGVycywgd2hpY2ggY2FuIGRpZmZlciAoYSB0cmFuc2xhdGlvbiBjb21wb25lbnQsIGZvciBleGFtcGxlKSwgc28gdGhlIGNhY2hlZCB0ZXh0IHdpbnNcbiAgICAvLyB1bmxlc3MgdGhlIGNoaWxkcmVuIGNoYW5nZWQuXG4gICAgaWYgKHJlZ2lzdGVyZWRUZXh0UmVmLmN1cnJlbnQgIT09IHVuZGVmaW5lZCAmJiBmcm9tQ2hpbGRyZW4gPT09IHByZXZpb3VzQ2hpbGRyZW5UZXh0KSB7XG4gICAgICByZXR1cm4gcmVnaXN0ZXJlZFRleHRSZWYuY3VycmVudDtcbiAgICB9XG4gICAgcmV0dXJuIGZyb21DaGlsZHJlbjtcbiAgfSwgW2xhYmVsLCBjaGlsZHJlblJlZiwgcmVuZGVyUmVmXSk7XG4gIGNvbnN0IHJlZ2lzdGVyID0gUmVhY3QudXNlQ2FsbGJhY2socmVzb2x2ZWRUZXh0ID0+IHtcbiAgICBjb25zdCB0ZXh0ID0gcmVzb2x2ZWRUZXh0ID8/IHJlc29sdmVUZXh0KCk7XG4gICAgaWYgKHRleHQpIHtcbiAgICAgIHJlZ2lzdGVyZWRUZXh0UmVmLmN1cnJlbnQgPSB0ZXh0O1xuICAgIH1cbiAgICByZXR1cm4gcmVnaXN0ZXJJdGVtKGl0ZW1JZCwge1xuICAgICAgZ2V0VGV4dCgpIHtcbiAgICAgICAgLy8gQSBtb3VudGVkIGl0ZW0gcmVwb3J0cyB3aGF0IGl0IHJlbmRlcnMgbm93LCBldmVuIG5vdGhpbmcsIHNpbmNlIGEgZGVzY2VuZGFudCBjYW4gY2hhbmdlXG4gICAgICAgIC8vIGl0cyB0ZXh0IHdpdGhvdXQgdGhlIGl0ZW0gcmUtcmVuZGVyaW5nLiBBIGZpbHRlcmVkLW91dCBpdGVtIGZhbGxzIGJhY2sgdG8gdGhlIGNhY2hlZFxuICAgICAgICAvLyB0ZXh0LlxuICAgICAgICBpZiAobGFiZWwgPT0gbnVsbCAmJiByZWYuY3VycmVudCkge1xuICAgICAgICAgIHJlZ2lzdGVyZWRUZXh0UmVmLmN1cnJlbnQgPSByZWYuY3VycmVudC50ZXh0Q29udGVudCA/PyAnJztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVnaXN0ZXJlZFRleHRSZWYuY3VycmVudDtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSwgW2l0ZW1JZCwgbGFiZWwsIHJlZ2lzdGVySXRlbSwgcmVzb2x2ZVRleHRdKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCB1bnJlZ2lzdGVyID0gcmVnaXN0ZXIoKTtcbiAgICBzZXRSZWdpc3RlcmVkKHRydWUpO1xuICAgIHJldHVybiB1bnJlZ2lzdGVyO1xuICB9LCBbcmVnaXN0ZXJdKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHJlZ2lzdGVyR3JvdXBJdGVtPy4oaXRlbUlkLCByZXRhaW5Hcm91cCksIFtyZWdpc3Rlckdyb3VwSXRlbSwgaXRlbUlkLCByZXRhaW5Hcm91cF0pO1xuXG4gIC8vIFJlLXJlZ2lzdGVyIHdoZW4gdGhlIGl0ZW0ncyB0ZXh0IGNoYW5nZXMsIHNvIHRoZSBhY3RpdmUgcXVlcnkgcnVucyBhZ2Fpbi5cbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCB0ZXh0ID0gcmVzb2x2ZVRleHQoKTtcbiAgICBpZiAodGV4dCAhPT0gcmVnaXN0ZXJlZFRleHRSZWYuY3VycmVudCkge1xuICAgICAgcmVnaXN0ZXJlZFRleHRSZWYuY3VycmVudCA9IHRleHQ7XG4gICAgICB2b2lkIHJlZ2lzdGVyKHRleHQpO1xuICAgIH1cbiAgfSwgW3JlZ2lzdGVyLCByZXNvbHZlVGV4dCwgY2hpbGRyZW4sIHJlbmRlciwgbGFiZWxdKTtcbiAgcmV0dXJuIHtcbiAgICB2aXNpYmxlOiAhcmVnaXN0ZXJlZCB8fCBtYXRjaGVkLFxuICAgIHJlZlxuICB9O1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZUVuaGFuY2VkQ2xpY2tIYW5kbGVyIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlRW5oYW5jZWRDbGlja0hhbmRsZXInO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsgaXNWaXJ0dWFsUG9pbnRlckV2ZW50IH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL2V2ZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlRmlsdGVyRHJvcGRvd25JdGVtIH0gZnJvbSBcIi4uLy4uL2ZpbHRlci1kcm9wZG93bi9pdGVtL3VzZUZpbHRlckRyb3Bkb3duSXRlbS5tanNcIjtcbmltcG9ydCB7IHVzZUZpbHRlckNvbnRleHRGb3JMaXN0IH0gZnJvbSBcIi4uLy4uL2ZpbHRlci1kcm9wZG93bi9yb290L0ZpbHRlckRyb3Bkb3duUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51Um9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9NZW51Um9vdENvbnRleHQubWpzXCI7XG4vKipcbiAqIFJlZ2lzdGVycyBhIHN1Ym1lbnUgdHJpZ2dlciB3aXRoIHRoZSBwYXJlbnQgbWVudSdzIGZpbHRlciBhbmQgYWRhcHRzIGl0IHRvIGEgZmlsdGVyYWJsZVxuICogc3VibWVudTogdGhlIHRyaWdnZXIgbGl2ZXMgaW5zaWRlIGl0cyBvd24gc3VibWVudSByb290LCBidXQgaXQgaXMgYW4gaXRlbSBvZiB0aGUgcGFyZW50IGxpc3QuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VNZW51RmlsdGVyU3VibWVudVRyaWdnZXIocGFyYW1zKSB7XG4gIC8vIGB2aXJ0dWFsRm9jdXNgIGlzIHNldCBvbmx5IGJ5IGEgZmlsdGVyYWJsZSBzdWJtZW51IHJvb3QsIHNvIGl0IHRlbGxzIHRoaXMgdHJpZ2dlciB3aGV0aGVyIHRoZVxuICAvLyBzdWJtZW51IGl0IG9wZW5zIHJlbmRlcnMgYSBgcm9sZT1cImRpYWxvZ1wiYCBwb3B1cCBvciBhIHBsYWluIGByb2xlPVwibWVudVwiYCBvbmUuIFRoZSBkb2N1bWVudGVkXG4gIC8vIHBsYWluLXN1Ym1lbnUgcmVjaXBlIHJlbGllcyBvbiB0aGUgbGF0dGVyLlxuICBjb25zdCB7XG4gICAgc3RvcmUsXG4gICAgdmlydHVhbEZvY3VzXG4gIH0gPSB1c2VNZW51Um9vdENvbnRleHQoKTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IG1vdW50ZWQgPSBzdG9yZS51c2VTdGF0ZSgnbW91bnRlZCcpO1xuICBjb25zdCBwYXJlbnQgPSBzdG9yZS51c2VTdGF0ZSgncGFyZW50Jyk7XG5cbiAgLy8gVGhlIHN1Ym1lbnUgcm9vdCdzIHByb3ZpZGVyIHNoYWRvd3MgdGhlIGVuY2xvc2luZyBvbmUsIGJ1dCB0aGUgdHJpZ2dlciBiZWxvbmdzIHRvIHRoZSBsaXN0XG4gIC8vIGl0IG9wZW5zIGZyb20sIHdoaWNoIGlzIHRoZSBwYXJlbnQgbWVudSdzLlxuICBjb25zdCBwYXJlbnRMaXN0UmVmID0gcGFyZW50LnR5cGUgPT09ICdtZW51JyA/IHBhcmVudC5zdG9yZS5jb250ZXh0Lml0ZW1Eb21FbGVtZW50cyA6IG51bGw7XG4gIGNvbnN0IHBhcmVudENvbnRleHQgPSB1c2VGaWx0ZXJDb250ZXh0Rm9yTGlzdChwYXJlbnRMaXN0UmVmKTtcbiAgY29uc3Qge1xuICAgIHZpc2libGUsXG4gICAgcmVmXG4gIH0gPSB1c2VGaWx0ZXJEcm9wZG93bkl0ZW0oe1xuICAgIC4uLnBhcmFtcyxcbiAgICBjb250ZXh0OiBwYXJlbnRDb250ZXh0LFxuICAgIHJldGFpbkdyb3VwOiBtb3VudGVkXG4gIH0pO1xuXG4gIC8vIEZpbHRlcmluZyB0aGUgdHJpZ2dlciBvdXQgdW5tb3VudHMgaXQsIGxlYXZpbmcgaXRzIHN1Ym1lbnUgb3BlbiB3aXRoIG5vIGFuY2hvci5cbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAodmlzaWJsZSB8fCAhb3Blbikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzdG9yZS5zZXRPcGVuKGZhbHNlLCBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5ub25lKSk7XG4gIH0sIFt2aXNpYmxlLCBvcGVuLCBzdG9yZV0pO1xuICBjb25zdCBjbGlja1Byb3BzID0gdXNlRW5oYW5jZWRDbGlja0hhbmRsZXIoKGV2ZW50LCBpbnRlcmFjdGlvblR5cGUpID0+IHtcbiAgICBpZiAoZXZlbnQudHlwZSA9PT0gJ2NsaWNrJyAmJiBzdG9yZS5zZWxlY3QoJ29wZW4nKSAmJiAoaW50ZXJhY3Rpb25UeXBlID09PSAna2V5Ym9hcmQnIHx8IGludGVyYWN0aW9uVHlwZSA9PT0gJ21vdXNlJyAmJiBzdG9yZS5zZWxlY3QoJ2xhc3RPcGVuQ2hhbmdlUmVhc29uJykgPT09IFJFQVNPTlMudHJpZ2dlclByZXNzKSkge1xuICAgICAgc3RvcmUuY29udGV4dC52aXJ0dWFsRm9jdXNSZWY/LmN1cnJlbnQ/LmZvY3VzKHtcbiAgICAgICAgcHJldmVudFNjcm9sbDogdHJ1ZVxuICAgICAgfSk7XG4gICAgfVxuICB9KTtcbiAgY29uc3QgcHJvcHMgPSB7XG4gICAgLy8gT21pdHRlZCByYXRoZXIgdGhhbiBgdW5kZWZpbmVkYCwgd2hpY2ggd291bGQgY2xlYXIgdGhlIGAnbWVudSdgIHRoZSByb290IHB1dHMgb24gZXZlcnlcbiAgICAvLyB0cmlnZ2VyLlxuICAgIC4uLih2aXJ0dWFsRm9jdXMgPyB7XG4gICAgICAnYXJpYS1oYXNwb3B1cCc6ICdkaWFsb2cnXG4gICAgfSA6IHVuZGVmaW5lZCksXG4gICAgLi4uY2xpY2tQcm9wcyxcbiAgICBvblBvaW50ZXJEb3duKGV2ZW50KSB7XG4gICAgICBjbGlja1Byb3BzLm9uUG9pbnRlckRvd24oZXZlbnQpO1xuICAgICAgc3RvcmUuY29udGV4dC52aXJ0dWFsUHJlc3MgPSBpc1ZpcnR1YWxQb2ludGVyRXZlbnQoZXZlbnQubmF0aXZlRXZlbnQpO1xuICAgIH0sXG4gICAgb25Gb2N1cyhldmVudCkge1xuICAgICAgLy8gQSBwbGFpbiBwYXJlbnQgbWVudSBtb3ZlcyBET00gZm9jdXMgdG8gd2hpY2hldmVyIGl0ZW0gdGhlIHBvaW50ZXIgY3Jvc3Nlcy4gV2hpbGUgdGhpc1xuICAgICAgLy8gdHJpZ2dlcidzIHN1Ym1lbnUgaXMgb3BlbiBhbmQgaXRzIGlucHV0IGhlbGQgZm9jdXMsIGhhbmQgZm9jdXMgc3RyYWlnaHQgYmFjayBzbyBjcm9zc2luZ1xuICAgICAgLy8gdGhlIHRyaWdnZXIgZG9lc24ndCBpbnRlcnJ1cHQgdHlwaW5nLlxuICAgICAgY29uc3QgZm9jdXNPd25lciA9IHN0b3JlLmNvbnRleHQudmlydHVhbEZvY3VzUmVmPy5jdXJyZW50O1xuICAgICAgaWYgKGZvY3VzT3duZXIgJiYgc3RvcmUuc2VsZWN0KCdvcGVuJykgJiYgZXZlbnQucmVsYXRlZFRhcmdldCA9PT0gZm9jdXNPd25lcikge1xuICAgICAgICBldmVudC5wcmV2ZW50QmFzZVVJSGFuZGxlcigpO1xuICAgICAgICBmb2N1c093bmVyLmZvY3VzKHtcbiAgICAgICAgICBwcmV2ZW50U2Nyb2xsOiB0cnVlXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfTtcbiAgaWYgKHBhcmVudENvbnRleHQgPT09IG51bGwpIHtcbiAgICAvLyBBIHBsYWluIHBhcmVudCBtZW51IHJvdmVzIERPTSBmb2N1cyBhY3Jvc3MgaXRzIGl0ZW1zIGFuZCBuZXZlciBmaWx0ZXJzIHRoZW0uXG4gICAgcmV0dXJuIHtcbiAgICAgIHZpc2libGU6IHRydWUsXG4gICAgICByZWY6IG51bGwsXG4gICAgICBwcm9wc1xuICAgIH07XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB2aXNpYmxlOiB2aXNpYmxlIHx8IG1vdW50ZWQsXG4gICAgcmVmLFxuICAgIHByb3BzXG4gIH07XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgeyBvd25lckRvY3VtZW50IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvb3duZXInO1xuaW1wb3J0IHsgYWN0aXZlRWxlbWVudCwgY29udGFpbnMgfSBmcm9tICdAYmFzZS11aS91dGlscy9zaGFkb3dEb20nO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcbi8qKlxuICogQSBwbGFpbiBzdWJtZW51IHdob3NlIHBhcmVudCBpcyBmaWx0ZXJhYmxlLiBUaGUgcGFyZW50IGtlZXBzIHJlYWwgZm9jdXMgb24gaXRzIGlucHV0LCBzbyBpdHNcbiAqIHRyaWdnZXIgbmV2ZXIgYmx1cnMgYW5kIGl0cyByZXR1cm4gZm9jdXMgd2FpdHMgZm9yIHRoaXMgcG9wdXAncyBleGl0IGFuaW1hdGlvbi4gVGhlIHN1Ym1lbnVcbiAqIGhhbmRzIGZvY3VzIGFuZCB0aGUgcGFyZW50J3MgaGlnaGxpZ2h0IGJhY2sgaXRzZWxmLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlVmlydHVhbEZvY3VzUGFyZW50SGFuZG9mZihzdG9yZSwgcGFyZW50LCBvcGVuLCB2aXJ0dWFsRm9jdXMpIHtcbiAgY29uc3QgcGFyZW50U3RvcmUgPSBwYXJlbnQudHlwZSA9PT0gJ21lbnUnID8gcGFyZW50LnN0b3JlIDogbnVsbDtcbiAgY29uc3QgcGFyZW50VmlydHVhbEZvY3VzUmVmID0gcGFyZW50U3RvcmU/LmNvbnRleHQudmlydHVhbEZvY3VzUmVmO1xuICBjb25zdCByZXR1cm5Ub1BhcmVudCA9IHVzZVN0YWJsZUNhbGxiYWNrKCh0cmlnZ2VyLCByZWFzb24pID0+IHtcbiAgICBjb25zdCBmb2N1c093bmVyID0gcGFyZW50VmlydHVhbEZvY3VzUmVmPy5jdXJyZW50O1xuICAgIGlmICh2aXJ0dWFsRm9jdXMgfHwgc3RvcmUuc2VsZWN0KCdvcGVuJykgfHwgIXBhcmVudFN0b3JlPy5zZWxlY3QoJ29wZW4nKSB8fCAhZm9jdXNPd25lcikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoY29udGFpbnMoc3RvcmUuY29udGV4dC5wb3B1cFJlZi5jdXJyZW50LCBhY3RpdmVFbGVtZW50KG93bmVyRG9jdW1lbnQoZm9jdXNPd25lcikpKSkge1xuICAgICAgZm9jdXNPd25lci5mb2N1cyh7XG4gICAgICAgIHByZXZlbnRTY3JvbGw6IHRydWVcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoKHJlYXNvbiA9PT0gUkVBU09OUy5saXN0TmF2aWdhdGlvbiB8fCByZWFzb24gPT09IFJFQVNPTlMuZXNjYXBlS2V5KSAmJiBwYXJlbnRTdG9yZS5zdGF0ZS5hY3RpdmVJbmRleCA9PSBudWxsKSB7XG4gICAgICAvLyBUaGUgY2xvc2luZyBrZXkgaXMgZ29uZSBieSB0aGlzIG1pY3JvdGFzaywgc28gdGhlcmUgaXMgbm8gZXZlbnQgdG8gcmVwb3J0IGl0IHdpdGguXG4gICAgICBwYXJlbnRTdG9yZS5oaWdobGlnaHRJdGVtKHRyaWdnZXIsIFJFQVNPTlMubm9uZSk7XG4gICAgfVxuICB9KTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW9wZW4pIHtcbiAgICAgIC8vIEEgcGFyZW50IGNsb3NpbmcgaW4gdGhlIHNhbWUgY29tbWl0LCBzdWNoIGFzIG9uIGFuIGl0ZW0gcHJlc3MsIHN5bmNzIGl0cyBjb250cm9sbGVkIGBvcGVuYFxuICAgICAgLy8gaW4gaXRzIG93biBsYXlvdXQgZWZmZWN0LCB3aGljaCBydW5zIGFmdGVyIHRoaXMgb25lLiBBbiB1bm1vdW50IGNhbiBjbGVhciB0aGUgdHJpZ2dlciBieVxuICAgICAgLy8gdGhlbiwgc28gcmVhZCBpdCBub3cuXG4gICAgICBjb25zdCB0cmlnZ2VyID0gc3RvcmUuc3RhdGUuYWN0aXZlVHJpZ2dlckVsZW1lbnQ7XG4gICAgICBjb25zdCByZWFzb24gPSBzdG9yZS5zZWxlY3QoJ2xhc3RPcGVuQ2hhbmdlUmVhc29uJyk7XG4gICAgICBxdWV1ZU1pY3JvdGFzaygoKSA9PiByZXR1cm5Ub1BhcmVudCh0cmlnZ2VyLCByZWFzb24pKTtcbiAgICB9XG4gIH0sIFtvcGVuLCBzdG9yZSwgcmV0dXJuVG9QYXJlbnRdKTtcblxuICAvLyBSZWFsIGZvY3VzIGVudGVyaW5nIHRoaXMgc3VibWVudSBpcyB3aGVuIGEgcGxhaW4gcGFyZW50J3MgdHJpZ2dlciB3b3VsZCBibHVyOiB0aGUgcGFyZW50IGhhc1xuICAvLyBubyBhY3RpdmUgaXRlbSB1bnRpbCBhIGtleWJvYXJkIGNsb3NlIGhhbmRzIHRoZSBjdXJzb3IgYmFjayB0byB0aGUgdHJpZ2dlci5cbiAgZnVuY3Rpb24gaGFuZGxlRm9jdXMoKSB7XG4gICAgaWYgKCF2aXJ0dWFsRm9jdXMgJiYgcGFyZW50VmlydHVhbEZvY3VzUmVmICYmIHBhcmVudFN0b3JlPy5zdGF0ZS5hY3RpdmVJbmRleCAhPSBudWxsKSB7XG4gICAgICBwYXJlbnRTdG9yZS5zZXRBY3RpdmVJbmRleChudWxsLCBSRUFTT05TLm5vbmUpO1xuICAgIH1cbiAgfVxuICByZXR1cm4ge1xuICAgIHBhcmVudFZpcnR1YWxGb2N1c1JlZixcbiAgICBoYW5kbGVGb2N1c1xuICB9O1xufSIsImltcG9ydCB7IE1lbnVGaWx0ZXJQb3B1cCB9IGZyb20gXCIuL01lbnVGaWx0ZXJQb3B1cC5tanNcIjtcbmltcG9ydCB7IE1lbnVGaWx0ZXJMaXN0IH0gZnJvbSBcIi4vTWVudUZpbHRlckxpc3QubWpzXCI7XG5pbXBvcnQgeyBNZW51RmlsdGVyR3JvdXAsIE1lbnVGaWx0ZXJSYWRpb0dyb3VwIH0gZnJvbSBcIi4vTWVudUZpbHRlckdyb3VwLm1qc1wiO1xuaW1wb3J0IHsgdXNlRmlsdGVyRHJvcGRvd25JdGVtIH0gZnJvbSBcIi4uLy4uL2ZpbHRlci1kcm9wZG93bi9pdGVtL3VzZUZpbHRlckRyb3Bkb3duSXRlbS5tanNcIjtcbmltcG9ydCB7IHVzZU1lbnVGaWx0ZXJTdWJtZW51VHJpZ2dlciB9IGZyb20gXCIuL3VzZU1lbnVGaWx0ZXJTdWJtZW51VHJpZ2dlci5tanNcIjtcbmltcG9ydCB7IHVzZVZpcnR1YWxGb2N1c1BhcmVudEhhbmRvZmYgfSBmcm9tIFwiLi91c2VWaXJ0dWFsRm9jdXNQYXJlbnRIYW5kb2ZmLm1qc1wiO1xuZXhwb3J0IGNvbnN0IE1FTlVfRklMVEVSX0lNUEwgPSB7XG4gIFBvcHVwOiBNZW51RmlsdGVyUG9wdXAsXG4gIExpc3Q6IE1lbnVGaWx0ZXJMaXN0LFxuICBHcm91cDogTWVudUZpbHRlckdyb3VwLFxuICBSYWRpb0dyb3VwOiBNZW51RmlsdGVyUmFkaW9Hcm91cCxcbiAgdXNlSXRlbTogdXNlRmlsdGVyRHJvcGRvd25JdGVtLFxuICB1c2VTdWJtZW51VHJpZ2dlcjogdXNlTWVudUZpbHRlclN1Ym1lbnVUcmlnZ2VyLFxuICB1c2VQYXJlbnRIYW5kb2ZmOiB1c2VWaXJ0dWFsRm9jdXNQYXJlbnRIYW5kb2ZmXG59OyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlQ29udHJvbGxlZCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUNvbnRyb2xsZWQnO1xuaW1wb3J0IHsgdXNlU3RhYmxlQ2FsbGJhY2sgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VTdGFibGVDYWxsYmFjayc7XG5pbXBvcnQgeyB1c2VJc29MYXlvdXRFZmZlY3QgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VJc29MYXlvdXRFZmZlY3QnO1xuaW1wb3J0IHsgdXNlUmVmV2l0aEluaXQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VSZWZXaXRoSW5pdCc7XG5pbXBvcnQgeyB1c2VNZW51YmFyQ29udGV4dCB9IGZyb20gXCIuLi8uLi9tZW51YmFyL01lbnViYXJDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgaXNWaXJ0dWFsUG9pbnRlckV2ZW50IH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L3V0aWxzL2V2ZW50Lm1qc1wiO1xuaW1wb3J0IHsgRmlsdGVyRHJvcGRvd25Sb290IH0gZnJvbSBcIi4uLy4uL2ZpbHRlci1kcm9wZG93bi9yb290L0ZpbHRlckRyb3Bkb3duUm9vdC5tanNcIjtcbmltcG9ydCB7IHVzZUZpbHRlckRyb3Bkb3duQ2xvc2VRdWVyeSB9IGZyb20gXCIuLi8uLi9maWx0ZXItZHJvcGRvd24vcm9vdC91c2VGaWx0ZXJEcm9wZG93bkNsb3NlUXVlcnkubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51Um9vdENvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9NZW51Um9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsgTWVudUZpbHRlckltcGxDb250ZXh0IH0gZnJvbSBcIi4vTWVudUZpbHRlckNvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBNRU5VX0ZJTFRFUl9JTVBMIH0gZnJvbSBcIi4vTWVudUZpbHRlckltcGwubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51RmlsdGVyS2V5RG93biB9IGZyb20gXCIuL3VzZU1lbnVGaWx0ZXJLZXlEb3duLm1qc1wiO1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8qKlxuICogUmVhZHMgdGhlIG1lbnUgc3RvcmUsIHdoaWNoIGlzIG9ubHkgYXZhaWxhYmxlIGJlbG93IHRoZSBtZW51IHJvb3QsIGFuZCBoYW5kcyB0aGUgZmlsdGVyXG4gKiBlbmdpbmUgdGhlIGxpc3QgdGhlIG1lbnUgbmF2aWdhdGVzIGFuZCB0aGUgY29tbWFuZCB0aGF0IG1vdmVzIGl0cyBoaWdobGlnaHQuIFRoZSBxdWVyeSBpc1xuICogb3duZWQgaGVyZTsgdGhlIG1lbnUgcm9vdCBrZWVwcyBzb2xlIG93bmVyc2hpcCBvZiB0aGUgb3BlbiBzdGF0ZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIE1lbnVGaWx0ZXJEcm9wZG93bihwcm9wcykge1xuICBjb25zdCB7XG4gICAgdmFsdWU6IHZhbHVlUHJvcCxcbiAgICBkZWZhdWx0VmFsdWUgPSAnJyxcbiAgICBvblZhbHVlQ2hhbmdlLFxuICAgIC4uLmRyb3Bkb3duUHJvcHNcbiAgfSA9IHByb3BzO1xuICBjb25zdCB7XG4gICAgc3RvcmVcbiAgfSA9IHVzZU1lbnVSb290Q29udGV4dCgpO1xuICBjb25zdCBvcGVuID0gc3RvcmUudXNlU3RhdGUoJ29wZW4nKTtcbiAgY29uc3QgbW91bnRlZCA9IHN0b3JlLnVzZVN0YXRlKCdtb3VudGVkJyk7XG4gIGNvbnN0IGtleWJvYXJkT3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdrZXlib2FyZE9wZW4nKTtcbiAgY29uc3QgYWN0aXZlVHJpZ2dlcklkID0gc3RvcmUudXNlU3RhdGUoJ2FjdGl2ZVRyaWdnZXJJZCcpO1xuICBjb25zdCBhY3RpdmVUcmlnZ2VyRWxlbWVudCA9IHN0b3JlLnVzZVN0YXRlKCdhY3RpdmVUcmlnZ2VyRWxlbWVudCcpO1xuICBjb25zdCBkaXNhYmxlZCA9IHN0b3JlLnVzZVN0YXRlKCdkaXNhYmxlZCcpO1xuICBjb25zdCBbdmFsdWUsIHNldFZhbHVlXSA9IHVzZUNvbnRyb2xsZWQoe1xuICAgIGNvbnRyb2xsZWQ6IHZhbHVlUHJvcCxcbiAgICBkZWZhdWx0OiBkZWZhdWx0VmFsdWUsXG4gICAgbmFtZTogJ01lbnVGaWx0ZXJQcm92aWRlcicsXG4gICAgc3RhdGU6ICd2YWx1ZSdcbiAgfSk7XG4gIGNvbnN0IGhhbmRsZVZhbHVlQ2hhbmdlID0gdXNlU3RhYmxlQ2FsbGJhY2soKG5leHRWYWx1ZSwgZXZlbnREZXRhaWxzKSA9PiB7XG4gICAgb25WYWx1ZUNoYW5nZT8uKG5leHRWYWx1ZSwgZXZlbnREZXRhaWxzKTtcbiAgICBpZiAoIWV2ZW50RGV0YWlscy5pc0NhbmNlbGVkKSB7XG4gICAgICBzZXRWYWx1ZShuZXh0VmFsdWUpO1xuICAgIH1cbiAgfSk7XG4gIGNvbnN0IGdldEFjdGl2ZUluZGV4ID0gdXNlU3RhYmxlQ2FsbGJhY2soKCkgPT4gc3RvcmUuc3RhdGUuYWN0aXZlSW5kZXgpO1xuICBjb25zdCBzZXRBY3RpdmVJbmRleCA9IHVzZVN0YWJsZUNhbGxiYWNrKGluZGV4ID0+IHtcbiAgICBzdG9yZS5zZXRBY3RpdmVJbmRleChpbmRleCwgUkVBU09OUy5ub25lKTtcbiAgfSk7XG4gIGNvbnN0IHF1ZXJ5ID0gdXNlRmlsdGVyRHJvcGRvd25DbG9zZVF1ZXJ5KHtcbiAgICBvcGVuLFxuICAgIG1vdW50ZWQsXG4gICAgdmFsdWUsXG4gICAgb25WYWx1ZUNoYW5nZTogaGFuZGxlVmFsdWVDaGFuZ2VcbiAgfSk7XG4gIGNvbnN0IGZpbHRlclRyaWdnZXJQcm9wcyA9IHVzZUZpbHRlclRyaWdnZXJQcm9wcyh2YWx1ZSAhPT0gJycpO1xuICAvLyBTZWVkZWQgYmVmb3JlIHRoZSB0cmlnZ2VycyBiZWxvdyByZW5kZXIsIGxpa2UgdGhlIHJvb3QncyBpbmFjdGl2ZSB0cmlnZ2VyIHByb3BzLCBzbyB0aGUgc3luY1xuICAvLyBlZmZlY3QgZG9lc24ndCByZW5kZXIgZXZlcnkgdHJpZ2dlciB0d2ljZSBpbiB0aGUgZmlyc3QgY29tbWl0LlxuICB1c2VSZWZXaXRoSW5pdCgoKSA9PiB7XG4gICAgc3RvcmUuc2V0KCdmaWx0ZXJUcmlnZ2VyUHJvcHMnLCBmaWx0ZXJUcmlnZ2VyUHJvcHMpO1xuICAgIHJldHVybiBudWxsO1xuICB9KTtcbiAgc3RvcmUudXNlU3luY2VkVmFsdWUoJ2ZpbHRlclRyaWdnZXJQcm9wcycsIGZpbHRlclRyaWdnZXJQcm9wcyk7XG5cbiAgLy8gT25seSBgc2V0T3BlbmAgcmVjb3JkcyBhIGtleWJvYXJkIG9wZW4sIHNvIGEgY29udHJvbGxlZCBjbG9zZSB0aGF0IGJ5cGFzc2VzIGl0IG11c3Qgbm90IGxlYXZlXG4gIC8vIHRoZSBuZXh0IHByb2dyYW1tYXRpYyBvcGVuIGxvb2tpbmcgbGlrZSBvbmUuXG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuKSB7XG4gICAgICBzdG9yZS5zZXQoJ2tleWJvYXJkT3BlbicsIGZhbHNlKTtcbiAgICB9XG4gIH0sIFtvcGVuLCBzdG9yZV0pO1xuXG4gIC8vIFRydXN0IHRoZSByZW5kZXJlZCBlbGVtZW50J3MgaWQgb25jZSBpdCBleGlzdHM6IGFuIGV4cGxpY2l0bHkgZW1wdHkgaWQgbXVzdCBub3QgZmFsbCBiYWNrIHRvIGFcbiAgLy8gcmVnaXN0ZXJlZCBpZCB0aGF0IG5vIGVsZW1lbnQgY2Fycmllcy5cbiAgY29uc3QgdHJpZ2dlcklkID0gYWN0aXZlVHJpZ2dlckVsZW1lbnQgPyBhY3RpdmVUcmlnZ2VyRWxlbWVudC5pZCB8fCBudWxsIDogYWN0aXZlVHJpZ2dlcklkO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goTWVudUZpbHRlckltcGxDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IE1FTlVfRklMVEVSX0lNUEwsXG4gICAgY2hpbGRyZW46IC8qI19fUFVSRV9fKi9fanN4KEZpbHRlckRyb3Bkb3duUm9vdCwge1xuICAgICAgLi4uZHJvcGRvd25Qcm9wcyxcbiAgICAgIG9wZW46IG9wZW4sXG4gICAgICBvcGVuZWRCeUtleWJvYXJkOiBrZXlib2FyZE9wZW4sXG4gICAgICBkaXNhYmxlZDogZGlzYWJsZWQsXG4gICAgICB2YWx1ZTogdmFsdWUsXG4gICAgICBxdWVyeTogcXVlcnksXG4gICAgICBvblZhbHVlQ2hhbmdlOiBoYW5kbGVWYWx1ZUNoYW5nZSxcbiAgICAgIHRyaWdnZXJJZDogdHJpZ2dlcklkLFxuICAgICAgbGlzdFJlZjogc3RvcmUuY29udGV4dC5pdGVtRG9tRWxlbWVudHMsXG4gICAgICBnZXRBY3RpdmVJbmRleDogZ2V0QWN0aXZlSW5kZXgsXG4gICAgICBzZXRBY3RpdmVJbmRleDogc2V0QWN0aXZlSW5kZXgsXG4gICAgICBmb2N1c093bmVyUmVmOiBzdG9yZS5jb250ZXh0LnZpcnR1YWxGb2N1c1JlZlxuICAgIH0pXG4gIH0pO1xufVxuXG4vKipcbiAqIFRoZSBwcm9wcyBhIGZpbHRlcmFibGUgbWVudSBhZGRzIHRvIGl0cyB0cmlnZ2VyczogZGlhbG9nIHNlbWFudGljcywgc2NyZWVuIHJlYWRlciBwcmVzc1xuICogdHJhY2tpbmcsIGFuZCBhIHJlbGF5IG9mIGxpc3QgbmF2aWdhdGlvbiB0eXBlZCBvbiB0aGUgdHJpZ2dlciB0byB0aGUgaW5wdXQsIHNpbmNlIHRoZSBpbnB1dFxuICogaG9sZHMgcmVhbCBmb2N1cyB3aGlsZSB0aGUgcG9wdXAgaXMgb3Blbi5cbiAqL1xuZnVuY3Rpb24gdXNlRmlsdGVyVHJpZ2dlclByb3BzKGhhc1ZhbHVlKSB7XG4gIGNvbnN0IHtcbiAgICBzdG9yZVxuICB9ID0gdXNlTWVudVJvb3RDb250ZXh0KCk7XG4gIGNvbnN0IGlzSW5NZW51YmFyID0gdXNlTWVudWJhckNvbnRleHQodHJ1ZSkgIT0gbnVsbDtcbiAgY29uc3QgaGFuZGxlSW5wdXRLZXlEb3duID0gdXNlTWVudUZpbHRlcktleURvd24oaGFzVmFsdWUpO1xuICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgICdhcmlhLWhhc3BvcHVwJzogJ2RpYWxvZycsXG4gICAgb25Qb2ludGVyRG93bihldmVudCkge1xuICAgICAgc3RvcmUuY29udGV4dC52aXJ0dWFsUHJlc3MgPSBpc1ZpcnR1YWxQb2ludGVyRXZlbnQoZXZlbnQubmF0aXZlRXZlbnQpO1xuICAgIH0sXG4gICAgb25LZXlEb3duKGV2ZW50KSB7XG4gICAgICBjb25zdCBmb2N1c093bmVyID0gc3RvcmUuY29udGV4dC52aXJ0dWFsRm9jdXNSZWY/LmN1cnJlbnQ7XG4gICAgICBpZiAoIXN0b3JlLnNlbGVjdCgnb3BlbicpIHx8ICFmb2N1c093bmVyIHx8IGlzSW5NZW51YmFyKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChldmVudC5rZXkgPT09ICdBcnJvd1VwJyB8fCBldmVudC5rZXkgPT09ICdBcnJvd0Rvd24nKSB7XG4gICAgICAgIGZvY3VzT3duZXIuZm9jdXMoe1xuICAgICAgICAgIHByZXZlbnRTY3JvbGw6IHRydWVcbiAgICAgICAgfSk7XG4gICAgICAgIGhhbmRsZUlucHV0S2V5RG93bihldmVudCk7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGV2ZW50LnByZXZlbnRCYXNlVUlIYW5kbGVyKCk7XG4gICAgICB9IGVsc2UgaWYgKGV2ZW50LmtleSA9PT0gJ0Fycm93TGVmdCcgfHwgZXZlbnQua2V5ID09PSAnQXJyb3dSaWdodCcpIHtcbiAgICAgICAgLy8gQ3Jvc3MtYXhpcyBrZXlzIGRyaXZlIHN1Ym1lbnUgb3Blbi9jbG9zZSwgd2hpY2ggdGhlIHRyaWdnZXIgbXVzdCBub3QgcmVsYXkuXG4gICAgICAgIGV2ZW50LnByZXZlbnRCYXNlVUlIYW5kbGVyKCk7XG4gICAgICB9IGVsc2UgaWYgKGlzVHlwZWFoZWFkS2V5KGV2ZW50KSkge1xuICAgICAgICBmb2N1c093bmVyLmZvY3VzKHtcbiAgICAgICAgICBwcmV2ZW50U2Nyb2xsOiB0cnVlXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfSksIFtzdG9yZSwgaXNJbk1lbnViYXIsIGhhbmRsZUlucHV0S2V5RG93bl0pO1xufVxuZnVuY3Rpb24gaXNUeXBlYWhlYWRLZXkoZXZlbnQpIHtcbiAgcmV0dXJuIGV2ZW50LmtleS5sZW5ndGggPT09IDEgJiYgZXZlbnQua2V5ICE9PSAnICcgJiYgIWV2ZW50LmN0cmxLZXkgJiYgIWV2ZW50Lm1ldGFLZXkgJiYgIWV2ZW50LmFsdEtleTtcbn0iLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0Jztcbi8qKiBTcGxpdHMgYSBmaWx0ZXJhYmxlIHJvb3QncyBwcm9wcyBiZXR3ZWVuIHRoZSBtZW51IHJvb3QgYW5kIHRoZSBmaWx0ZXIgYmVsb3cgaXQuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlTWVudUZpbHRlclJvb3QocHJvcHMpIHtcbiAgY29uc3Qge1xuICAgIGNoaWxkcmVuLFxuICAgIHZhbHVlLFxuICAgIGRlZmF1bHRWYWx1ZSxcbiAgICBvblZhbHVlQ2hhbmdlLFxuICAgIGZpbHRlcixcbiAgICBhdXRvSGlnaGxpZ2h0ID0gZmFsc2UsXG4gICAgbG9jYWxlLFxuICAgIC4uLm90aGVyUHJvcHNcbiAgfSA9IHByb3BzO1xuICBjb25zdCB2aXJ0dWFsRm9jdXNSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIHJldHVybiB7XG4gICAgY2hpbGRyZW4sXG4gICAgcm9vdFByb3BzOiB7XG4gICAgICAuLi5vdGhlclByb3BzLFxuICAgICAgdmlydHVhbEZvY3VzOiB0cnVlLFxuICAgICAgdmlydHVhbEZvY3VzUmVmLFxuICAgICAgYWxsb3dFc2NhcGU6ICFhdXRvSGlnaGxpZ2h0LFxuICAgICAgcmVzZXRPblBvaW50ZXJMZWF2ZTogYXV0b0hpZ2hsaWdodCAhPT0gJ2Fsd2F5cydcbiAgICB9LFxuICAgIGRyb3Bkb3duUHJvcHM6IHtcbiAgICAgIHZhbHVlLFxuICAgICAgZGVmYXVsdFZhbHVlLFxuICAgICAgb25WYWx1ZUNoYW5nZSxcbiAgICAgIGZpbHRlcixcbiAgICAgIGF1dG9IaWdobGlnaHQsXG4gICAgICBsb2NhbGVcbiAgICB9XG4gIH07XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBNZW51Um9vdEludGVybmFsIH0gZnJvbSBcIi4uL3Jvb3QvTWVudVJvb3QubWpzXCI7XG5pbXBvcnQgeyBNZW51RmlsdGVyRHJvcGRvd24gfSBmcm9tIFwiLi9NZW51RmlsdGVyRHJvcGRvd24ubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51RmlsdGVyUm9vdCB9IGZyb20gXCIuL3VzZU1lbnVGaWx0ZXJSb290Lm1qc1wiO1xuXG4vKipcbiAqIFRoZSBmaWx0ZXJhYmxlIGltcGxlbWVudGF0aW9uIG9mIGBNZW51LlJvb3RgLCByZW5kZXJlZCBpbiBpdHMgcGxhY2Ugd2hlbiB0aGUgcm9vdCBzaXRzIGluc2lkZVxuICogYE1lbnUuRmlsdGVyUHJvdmlkZXJgLiBSZWFjaGVkIHRocm91Z2ggdGhlIHByb3ZpZGVyIG9ubHksIHNvIGEgcGxhaW4gbWVudSBuZXZlciBidW5kbGVzIGl0LlxuICpcbiAqIEBpbnRlcm5hbFxuICovXG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZXhwb3J0IGZ1bmN0aW9uIE1lbnVGaWx0ZXJSb290KHByb3BzKSB7XG4gIGNvbnN0IHtcbiAgICBjaGlsZHJlbixcbiAgICByb290UHJvcHMsXG4gICAgZHJvcGRvd25Qcm9wc1xuICB9ID0gdXNlTWVudUZpbHRlclJvb3QocHJvcHMpO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goTWVudVJvb3RJbnRlcm5hbCwge1xuICAgIC4uLnJvb3RQcm9wcyxcbiAgICBjaGlsZHJlbjogcGF5bG9hZCA9PiAvKiNfX1BVUkVfXyovX2pzeChNZW51RmlsdGVyRHJvcGRvd24sIHtcbiAgICAgIC4uLmRyb3Bkb3duUHJvcHMsXG4gICAgICBjaGlsZHJlbjogdHlwZW9mIGNoaWxkcmVuID09PSAnZnVuY3Rpb24nID8gY2hpbGRyZW4ocGF5bG9hZCkgOiBjaGlsZHJlblxuICAgIH0pXG4gIH0pO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgb3duZXJEb2N1bWVudCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL293bmVyJztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IGlzSFRNTEVsZW1lbnQgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IE1lbnVSb290SW50ZXJuYWwgfSBmcm9tIFwiLi4vcm9vdC9NZW51Um9vdC5tanNcIjtcbmltcG9ydCB7IHVzZU1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L01lbnVSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IE1lbnVGaWx0ZXJEcm9wZG93biB9IGZyb20gXCIuLi9maWx0ZXItcm9vdC9NZW51RmlsdGVyRHJvcGRvd24ubWpzXCI7XG5pbXBvcnQgeyBpc0tleWJvYXJkT3BlbiB9IGZyb20gXCIuLi91dGlscy9pc0tleWJvYXJkT3Blbi5tanNcIjtcbmltcG9ydCB7IHVzZU1lbnVGaWx0ZXJSb290IH0gZnJvbSBcIi4uL2ZpbHRlci1yb290L3VzZU1lbnVGaWx0ZXJSb290Lm1qc1wiO1xuaW1wb3J0IHsgdXNlRGlyZWN0aW9uIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9kaXJlY3Rpb24tY29udGV4dC9EaXJlY3Rpb25Db250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgaXNDcm9zc09yaWVudGF0aW9uQ2xvc2VLZXksIGlzQ3Jvc3NPcmllbnRhdGlvbk9wZW5LZXksIGlzTWFpbk9yaWVudGF0aW9uS2V5IH0gZnJvbSBcIi4uLy4uL2Zsb2F0aW5nLXVpLXJlYWN0L2hvb2tzL3VzZUxpc3ROYXZpZ2F0aW9uLm1qc1wiO1xuaW1wb3J0IHsgYWN0aXZlRWxlbWVudCwgY29udGFpbnMsIHN0b3BFdmVudCB9IGZyb20gXCIuLi8uLi9mbG9hdGluZy11aS1yZWFjdC91dGlscy5tanNcIjtcbmltcG9ydCB7IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvY3JlYXRlQmFzZVVJRXZlbnREZXRhaWxzLm1qc1wiO1xuaW1wb3J0IHsgUkVBU09OUyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVhc29ucy5tanNcIjtcbmltcG9ydCB7IG1vdmVIaWdobGlnaHRGcm9tIH0gZnJvbSBcIi4uL2ZpbHRlci1yb290L21vdmVIaWdobGlnaHRGcm9tLm1qc1wiO1xuaW1wb3J0IHsgTWVudVN1Ym1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi9zdWJtZW51LXJvb3QvTWVudVN1Ym1lbnVSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vKipcbiAqIFRoZSBmaWx0ZXJhYmxlIGltcGxlbWVudGF0aW9uIG9mIGBNZW51LlN1Ym1lbnVSb290YCwgcmVuZGVyZWQgaW4gaXRzIHBsYWNlIHdoZW4gdGhlIHN1Ym1lbnVcbiAqIHJvb3Qgc2l0cyBpbnNpZGUgYE1lbnUuRmlsdGVyUHJvdmlkZXJgLlxuICpcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgZnVuY3Rpb24gTWVudUZpbHRlclN1Ym1lbnVSb290KHByb3BzKSB7XG4gIGNvbnN0IHBhcmVudCA9IHVzZU1lbnVSb290Q29udGV4dCgpO1xuICBjb25zdCBwYXJlbnRTdG9yZSA9IHBhcmVudC5zdG9yZTtcbiAgY29uc3QgcGFyZW50RGlzYWJsZWQgPSBwYXJlbnRTdG9yZS51c2VTdGF0ZSgnZGlzYWJsZWQnKTtcbiAgY29uc3Qge1xuICAgIHJvb3RQcm9wcyxcbiAgICBkcm9wZG93blByb3BzXG4gIH0gPSB1c2VNZW51RmlsdGVyUm9vdChwcm9wcyk7XG4gIGNvbnN0IHBhcmVudFJlZmVyZW5jZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgZnVuY3Rpb24gaGFuZGxlU3VibWVudUVudGVyKHRyaWdnZXIsIGV2ZW50KSB7XG4gICAgY29uc3QgZm9jdXNlZEVsZW1lbnQgPSBwYXJlbnQudmlydHVhbEZvY3VzID8gcGFyZW50U3RvcmUuY29udGV4dC52aXJ0dWFsRm9jdXNSZWY/LmN1cnJlbnQgOiBhY3RpdmVFbGVtZW50KG93bmVyRG9jdW1lbnQodHJpZ2dlcikpO1xuICAgIGlmIChpc0hUTUxFbGVtZW50KGZvY3VzZWRFbGVtZW50KSkge1xuICAgICAgcGFyZW50UmVmZXJlbmNlUmVmLmN1cnJlbnQgPSB7XG4gICAgICAgIHJlZmVyZW5jZTogZm9jdXNlZEVsZW1lbnQsXG4gICAgICAgIHRyaWdnZXJcbiAgICAgIH07XG4gICAgICBwYXJlbnRTdG9yZS5zZXRBY3RpdmVJbmRleChudWxsLCBldmVudCA/IFJFQVNPTlMua2V5Ym9hcmQgOiBSRUFTT05TLm5vbmUsIGV2ZW50KTtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gaGlnaGxpZ2h0VHJpZ2dlcih0cmlnZ2VyLCBldmVudCkge1xuICAgIHBhcmVudFN0b3JlLmhpZ2hsaWdodEl0ZW0odHJpZ2dlciwgUkVBU09OUy5rZXlib2FyZCwgZXZlbnQpO1xuICB9XG4gIGZ1bmN0aW9uIGhhbmRsZVN1Ym1lbnVFeGl0KGV2ZW50KSB7XG4gICAgY29uc3QgcGFyZW50UmVmZXJlbmNlID0gcGFyZW50UmVmZXJlbmNlUmVmLmN1cnJlbnQ7XG4gICAgaWYgKCFwYXJlbnRSZWZlcmVuY2UpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcGFyZW50UmVmZXJlbmNlLnJlZmVyZW5jZS5mb2N1cyh7XG4gICAgICBwcmV2ZW50U2Nyb2xsOiB0cnVlXG4gICAgfSk7XG4gICAgaGlnaGxpZ2h0VHJpZ2dlcihwYXJlbnRSZWZlcmVuY2UudHJpZ2dlciwgZXZlbnQpO1xuICB9XG4gIGZ1bmN0aW9uIGhhbmRsZU9wZW5DaGFuZ2UobmV4dE9wZW4sIGRldGFpbHMpIHtcbiAgICByb290UHJvcHMub25PcGVuQ2hhbmdlPy4obmV4dE9wZW4sIGRldGFpbHMpO1xuICAgIGlmIChkZXRhaWxzLmlzQ2FuY2VsZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCFuZXh0T3Blbikge1xuICAgICAgaWYgKGRldGFpbHMucmVhc29uID09PSBSRUFTT05TLmVzY2FwZUtleSAmJiBpc0hUTUxFbGVtZW50KGRldGFpbHMudHJpZ2dlcikpIHtcbiAgICAgICAgaGlnaGxpZ2h0VHJpZ2dlcihkZXRhaWxzLnRyaWdnZXIsIGRldGFpbHMuZXZlbnQpO1xuICAgICAgICAvLyBgTWVudVBvcHVwYCByZXR1cm5zIGZvY3VzIHRocm91Z2ggYGdldFJldHVybkVsZW1lbnRgLCBzbyBwb2ludCBpdCBhdCB0aGUgZWxlbWVudCB0aGF0XG4gICAgICAgIC8vIGNhbiBob2xkIHJlYWwgZm9jdXM6IHRoZSBwYXJlbnQncyBpbnB1dCwgbm90IGl0cyB1bnRhYmJhYmxlIHRyaWdnZXIuXG4gICAgICAgIHBhcmVudFJlZmVyZW5jZVJlZi5jdXJyZW50ID0ge1xuICAgICAgICAgIHJlZmVyZW5jZTogcGFyZW50LnZpcnR1YWxGb2N1cyA/IHBhcmVudFN0b3JlLmNvbnRleHQudmlydHVhbEZvY3VzUmVmPy5jdXJyZW50ID8/IGRldGFpbHMudHJpZ2dlciA6IGRldGFpbHMudHJpZ2dlcixcbiAgICAgICAgICB0cmlnZ2VyOiBkZXRhaWxzLnRyaWdnZXJcbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcGFyZW50UmVmZXJlbmNlUmVmLmN1cnJlbnQgPSBudWxsO1xuICAgIGlmIChpc0hUTUxFbGVtZW50KGRldGFpbHMudHJpZ2dlcikgJiYgaXNLZXlib2FyZE9wZW4oZGV0YWlscy5yZWFzb24sIGRldGFpbHMuZXZlbnQpKSB7XG4gICAgICAvLyBBIGtleWJvYXJkIGNsaWNrIHJlcG9ydHMgaXRzIGNsaWNrLCB3aGljaCBpc24ndCB0aGUga2V5IHRoYXQgb3BlbmVkIHRoZSBzdWJtZW51LlxuICAgICAgaGFuZGxlU3VibWVudUVudGVyKGRldGFpbHMudHJpZ2dlciwgZGV0YWlscy5yZWFzb24gPT09IFJFQVNPTlMubGlzdE5hdmlnYXRpb24gPyBkZXRhaWxzLmV2ZW50IDogdW5kZWZpbmVkKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KE1lbnVSb290SW50ZXJuYWwsIHtcbiAgICAuLi5yb290UHJvcHMsXG4gICAgaXNTdWJtZW51OiB0cnVlLFxuICAgIGRpc2FibGVkOiBwYXJlbnREaXNhYmxlZCB8fCBwcm9wcy5kaXNhYmxlZCxcbiAgICBvbk9wZW5DaGFuZ2U6IGhhbmRsZU9wZW5DaGFuZ2UsXG4gICAgY2hpbGRyZW46IC8qI19fUFVSRV9fKi9fanN4KE1lbnVGaWx0ZXJTdWJtZW51TmF2aWdhdGlvbiwge1xuICAgICAgcGFyZW50U3RvcmU6IHBhcmVudFN0b3JlLFxuICAgICAgcGFyZW50VmlydHVhbEZvY3VzOiBwYXJlbnQudmlydHVhbEZvY3VzLFxuICAgICAgcGFyZW50QWxsb3dFc2NhcGU6IHBhcmVudC52aXJ0dWFsRm9jdXMgJiYgcGFyZW50LmFsbG93RXNjYXBlLFxuICAgICAgcGFyZW50T3JpZW50YXRpb246IHBhcmVudC5vcmllbnRhdGlvbixcbiAgICAgIHBhcmVudExvb3BGb2N1czogcGFyZW50Lmxvb3BGb2N1cyxcbiAgICAgIGdldFJldHVybkVsZW1lbnQ6ICgpID0+IHBhcmVudFJlZmVyZW5jZVJlZi5jdXJyZW50Py5yZWZlcmVuY2UgPz8gKHBhcmVudC52aXJ0dWFsRm9jdXMgPyBwYXJlbnRTdG9yZS5jb250ZXh0LnZpcnR1YWxGb2N1c1JlZj8uY3VycmVudCA6IG51bGwpID8/IG51bGwsXG4gICAgICBvblN1Ym1lbnVFbnRlcjogaGFuZGxlU3VibWVudUVudGVyLFxuICAgICAgb25TdWJtZW51RXhpdDogaGFuZGxlU3VibWVudUV4aXQsXG4gICAgICBjaGlsZHJlbjogLyojX19QVVJFX18qL19qc3goTWVudUZpbHRlckRyb3Bkb3duLCB7XG4gICAgICAgIC4uLmRyb3Bkb3duUHJvcHMsXG4gICAgICAgIGNoaWxkcmVuOiBwcm9wcy5jaGlsZHJlblxuICAgICAgfSlcbiAgICB9KVxuICB9KTtcbn1cbmZ1bmN0aW9uIE1lbnVGaWx0ZXJTdWJtZW51TmF2aWdhdGlvbihwcm9wcykge1xuICBjb25zdCB7XG4gICAgY2hpbGRyZW4sXG4gICAgcGFyZW50U3RvcmUsXG4gICAgcGFyZW50VmlydHVhbEZvY3VzLFxuICAgIHBhcmVudEFsbG93RXNjYXBlLFxuICAgIHBhcmVudE9yaWVudGF0aW9uLFxuICAgIHBhcmVudExvb3BGb2N1cyxcbiAgICBvblN1Ym1lbnVFbnRlcixcbiAgICBvblN1Ym1lbnVFeGl0LFxuICAgIGdldFJldHVybkVsZW1lbnRcbiAgfSA9IHByb3BzO1xuICBjb25zdCB7XG4gICAgc3RvcmUsXG4gICAgb3JpZW50YXRpb25cbiAgfSA9IHVzZU1lbnVSb290Q29udGV4dCgpO1xuICBjb25zdCBkaXJlY3Rpb24gPSB1c2VEaXJlY3Rpb24oKTtcbiAgY29uc3QgbW91bnRlZCA9IHN0b3JlLnVzZVN0YXRlKCdtb3VudGVkJyk7XG4gIGNvbnN0IHdhc01vdW50ZWRSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBjb25zdCBoYW5kbGVSZXR1cm5Gb2N1cyA9IHVzZVN0YWJsZUNhbGxiYWNrKCgpID0+IHtcbiAgICAvLyBBIHBsYWluIHBhcmVudCBoYXMgbm8gaW5wdXQgdG8gcmV0dXJuIHRvLiBGb2N1cyB0aGUgdHJpZ2dlciB0aGlzIHN1Ym1lbnUgb3BlbmVkIGZyb20sIGFzIGFcbiAgICAvLyBwbGFpbiBzdWJtZW51IGRvZXMsIHNvIGEgaG92ZXIgY2xvc2UgZG9lc24ndCBzdHJhbmQgZm9jdXMgb24gdGhlIGJvZHkuXG4gICAgY29uc3QgW293blRyaWdnZXJdID0gc3RvcmUuY29udGV4dC50cmlnZ2VyRWxlbWVudHMuZWxlbWVudHMoKTtcbiAgICByZXR1cm4gZ2V0UmV0dXJuRWxlbWVudCgpID8/IChpc0hUTUxFbGVtZW50KG93blRyaWdnZXIpID8gb3duVHJpZ2dlciA6IG51bGwpO1xuICB9KTtcblxuICAvLyBBIGhvdmVyIGNsb3NlIG1ha2VzIHRoZSBmb2N1cyBtYW5hZ2VyIHNraXAgaXRzIHJldHVybiBmb2N1cywgd2hpY2ggd291bGQgc3RyYW5kIHRoZVxuICAvLyBzdWJtZW51IGlucHV0J3MgZm9jdXMgb24gdGhlIGJvZHkgb25jZSB0aGUgcG9wdXAgdW5tb3VudHMuIFRoaXMgcnVucyBpbiB0aGUgZWZmZWN0IGJvZHlcbiAgLy8gcmF0aGVyIHRoYW4gYSBjbGVhbnVwOiBSZWFjdCBkcm9wcyB0aGUgZm9jdXMgZXZlbnQgd2hlbiBpdCBmaXJlcyBkdXJpbmcgdGhlIG11dGF0aW9uIHBoYXNlLFxuICAvLyBzbyB0aGUgaW5wdXQgd291bGQgbmV2ZXIgbGVhcm4gaXQgaG9sZHMgZm9jdXMuXG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3Qgd2FzTW91bnRlZCA9IHdhc01vdW50ZWRSZWYuY3VycmVudDtcbiAgICB3YXNNb3VudGVkUmVmLmN1cnJlbnQgPSBtb3VudGVkO1xuICAgIGlmIChtb3VudGVkIHx8ICF3YXNNb3VudGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHJldHVybkVsZW1lbnQgPSBoYW5kbGVSZXR1cm5Gb2N1cygpO1xuICAgIGlmICghcmV0dXJuRWxlbWVudCB8fCAhcGFyZW50U3RvcmUuc2VsZWN0KCdvcGVuJykpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgZG9jID0gb3duZXJEb2N1bWVudChyZXR1cm5FbGVtZW50KTtcbiAgICBjb25zdCBhY3RpdmVFbCA9IGFjdGl2ZUVsZW1lbnQoZG9jKTtcbiAgICBpZiAoYWN0aXZlRWwgPT09IGRvYy5ib2R5IHx8IGNvbnRhaW5zKHN0b3JlLnNlbGVjdCgncG9wdXBFbGVtZW50JyksIGFjdGl2ZUVsKSkge1xuICAgICAgcmV0dXJuRWxlbWVudC5mb2N1cyh7XG4gICAgICAgIHByZXZlbnRTY3JvbGw6IHRydWVcbiAgICAgIH0pO1xuICAgIH1cbiAgfSwgW21vdW50ZWQsIHN0b3JlLCBwYXJlbnRTdG9yZSwgaGFuZGxlUmV0dXJuRm9jdXNdKTtcbiAgZnVuY3Rpb24gbW92ZUluUGFyZW50KGZyb20sIGV2ZW50KSB7XG4gICAgY29uc3QgaXRlbSA9IG1vdmVIaWdobGlnaHRGcm9tKHBhcmVudFN0b3JlLCBmcm9tLCBldmVudCwge1xuICAgICAgb3JpZW50YXRpb246IHBhcmVudE9yaWVudGF0aW9uLFxuICAgICAgcnRsOiBkaXJlY3Rpb24gPT09ICdydGwnLFxuICAgICAgbG9vcEZvY3VzOiBwYXJlbnRMb29wRm9jdXMsXG4gICAgICBhbGxvd0VzY2FwZTogcGFyZW50QWxsb3dFc2NhcGVcbiAgICB9KTtcbiAgICBpZiAoIXBhcmVudFZpcnR1YWxGb2N1cykge1xuICAgICAgaXRlbT8uZm9jdXMoe1xuICAgICAgICBwcmV2ZW50U2Nyb2xsOiB0cnVlXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gY2xvc2UoZXZlbnQpIHtcbiAgICBpZiAoIXN0b3JlLnNlbGVjdCgnb3BlbicpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgLy8gVGhlIGtleSBjYW4gcmVhY2ggdGhpcyBwb3B1cCByZS1kaXNwYXRjaGVkIG9uIGl0cyBoaWdobGlnaHRlZCBpdGVtLCBzbyBpdCBjYW4ndCBiZSBsZWZ0IHRvXG4gICAgLy8gYnViYmxlIHRvIHRoZSBwYXJlbnQuIEEgY2xvc2Uga2V5IHRoYXQgYWxzbyBuYXZpZ2F0ZXMgdGhlIHBhcmVudCBtb3ZlcyBpdCBmcm9tIGhlcmUuXG4gICAgc3RvcEV2ZW50KGV2ZW50KTtcbiAgICBjb25zdCB0cmlnZ2VyID0gc3RvcmUuc2VsZWN0KCdhY3RpdmVUcmlnZ2VyRWxlbWVudCcpO1xuICAgIGNvbnN0IGV2ZW50RGV0YWlscyA9IGNyZWF0ZUNoYW5nZUV2ZW50RGV0YWlscyhSRUFTT05TLmxpc3ROYXZpZ2F0aW9uLCBldmVudC5uYXRpdmVFdmVudCk7XG4gICAgc3RvcmUuc2V0T3BlbihmYWxzZSwgZXZlbnREZXRhaWxzKTtcbiAgICBpZiAoIWV2ZW50RGV0YWlscy5pc0NhbmNlbGVkKSB7XG4gICAgICBvblN1Ym1lbnVFeGl0KGV2ZW50Lm5hdGl2ZUV2ZW50KTtcbiAgICB9XG5cbiAgICAvLyBgb25TdWJtZW51RXhpdGAgYmFpbHMgd2hlbiB0aGUgc3VibWVudSB3YXMgb3BlbmVkIGJ5IHBvaW50ZXIsIHNvIHJldHVybiBmb2N1cyBoZXJlLlxuICAgIGNvbnN0IHJldHVybkVsZW1lbnQgPSBnZXRSZXR1cm5FbGVtZW50KCkgPz8gc3RvcmUuc2VsZWN0KCdhY3RpdmVUcmlnZ2VyRWxlbWVudCcpO1xuICAgIGlmICghc3RvcmUuc2VsZWN0KCdvcGVuJykgJiYgaXNIVE1MRWxlbWVudChyZXR1cm5FbGVtZW50KSAmJiBhY3RpdmVFbGVtZW50KG93bmVyRG9jdW1lbnQocmV0dXJuRWxlbWVudCkpICE9PSByZXR1cm5FbGVtZW50KSB7XG4gICAgICByZXR1cm5FbGVtZW50LmZvY3VzKCk7XG4gICAgfVxuICAgIGlmICghc3RvcmUuc2VsZWN0KCdvcGVuJykgJiYgaXNIVE1MRWxlbWVudCh0cmlnZ2VyKSAmJiBpc01haW5PcmllbnRhdGlvbktleShldmVudC5rZXksIHBhcmVudE9yaWVudGF0aW9uKSkge1xuICAgICAgbW92ZUluUGFyZW50KHRyaWdnZXIsIGV2ZW50KTtcbiAgICB9XG4gIH1cbiAgY29uc3QgaGFuZGxlVHJpZ2dlcktleURvd24gPSB1c2VTdGFibGVDYWxsYmFjayhldmVudCA9PiB7XG4gICAgaWYgKGlzTWFpbk9yaWVudGF0aW9uS2V5KGV2ZW50LmtleSwgcGFyZW50T3JpZW50YXRpb24pKSB7XG4gICAgICBtb3ZlSW5QYXJlbnQoZXZlbnQuY3VycmVudFRhcmdldCwgZXZlbnQpO1xuICAgICAgZXZlbnQucHJldmVudEJhc2VVSUhhbmRsZXIoKTtcbiAgICAgIHN0b3BFdmVudChldmVudCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IG9wZW4gPSBzdG9yZS5zZWxlY3QoJ29wZW4nKTtcbiAgICBjb25zdCBpc1J0bCA9IGRpcmVjdGlvbiA9PT0gJ3J0bCc7XG4gICAgY29uc3QgaXNDbG9zZUtleSA9IGlzQ3Jvc3NPcmllbnRhdGlvbkNsb3NlS2V5KGV2ZW50LmtleSwgb3JpZW50YXRpb24sIGlzUnRsLCBmYWxzZSk7XG4gICAgaWYgKG9wZW4gJiYgaXNDbG9zZUtleSkge1xuICAgICAgY2xvc2UoZXZlbnQpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBpc09wZW5LZXkgPSBpc0Nyb3NzT3JpZW50YXRpb25PcGVuS2V5KGV2ZW50LmtleSwgcGFyZW50T3JpZW50YXRpb24sIGlzUnRsKTtcbiAgICBpZiAoIWlzT3BlbktleSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBzdG9wRXZlbnQoZXZlbnQpO1xuICAgIGlmIChvcGVuKSB7XG4gICAgICAvLyBSZS1lbnRlcmluZyBhbiBhbHJlYWR5LW9wZW4gc3VibWVudSBoYW5kcyB0aGUgY3Vyc29yIHRvIGl0cyBvd24gZm9jdXMgb3duZXIuIFRoZSBzdWJtZW51XG4gICAgICAvLyBpcyBhbHdheXMgdmlydHVhbGx5IGZvY3VzZWQsIHNvIHRoZXJlIGlzIG5vIHJvdmluZy1mb2N1cyBicmFuY2ggaGVyZS4gVGhlIGhpZ2hsaWdodCBpc1xuICAgICAgLy8ga2VwdCwgc28gYW4gYXV0b21hdGljIGhpZ2hsaWdodCBvciBhbiBlYXJsaWVyIGtleWJvYXJkIHBvc2l0aW9uIHN1cnZpdmVzIHJlLWVudHJ5LlxuICAgICAgb25TdWJtZW51RW50ZXIoZXZlbnQuY3VycmVudFRhcmdldCwgZXZlbnQubmF0aXZlRXZlbnQpO1xuICAgICAgc3RvcmUuY29udGV4dC52aXJ0dWFsRm9jdXNSZWY/LmN1cnJlbnQ/LmZvY3VzKHtcbiAgICAgICAgcHJldmVudFNjcm9sbDogdHJ1ZVxuICAgICAgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHN0b3JlLnNldE9wZW4odHJ1ZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKFJFQVNPTlMubGlzdE5hdmlnYXRpb24sIGV2ZW50Lm5hdGl2ZUV2ZW50LCBldmVudC5jdXJyZW50VGFyZ2V0KSk7XG4gIH0pO1xuICBjb25zdCBoYW5kbGVQb3B1cEtleURvd24gPSB1c2VTdGFibGVDYWxsYmFjayhldmVudCA9PiB7XG4gICAgLy8gQSBrZXkgdGhhdCBjb21wb3NlcyB0ZXh0IGluIHRoZSBpbnB1dCBtdXN0IG5vdCBjbG9zZSB0aGUgc3VibWVudS5cbiAgICBpZiAoZXZlbnQud2hpY2ggPT09IDIyOSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBpc0Nsb3NlS2V5ID0gaXNDcm9zc09yaWVudGF0aW9uQ2xvc2VLZXkoZXZlbnQua2V5LCBvcmllbnRhdGlvbiwgZGlyZWN0aW9uID09PSAncnRsJywgZmFsc2UpO1xuICAgIGlmIChpc0Nsb3NlS2V5KSB7XG4gICAgICBjbG9zZShldmVudCk7XG4gICAgfVxuICB9KTtcbiAgY29uc3QgY29udGV4dFZhbHVlID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIGdldFJldHVybkVsZW1lbnQ6IGhhbmRsZVJldHVybkZvY3VzLFxuICAgIG9uVHJpZ2dlcktleURvd246IGhhbmRsZVRyaWdnZXJLZXlEb3duLFxuICAgIG9uUG9wdXBLZXlEb3duOiBoYW5kbGVQb3B1cEtleURvd25cbiAgfSksIFtoYW5kbGVSZXR1cm5Gb2N1cywgaGFuZGxlVHJpZ2dlcktleURvd24sIGhhbmRsZVBvcHVwS2V5RG93bl0pO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goTWVudVN1Ym1lbnVSb290Q29udGV4dC5Qcm92aWRlciwge1xuICAgIHZhbHVlOiBjb250ZXh0VmFsdWUsXG4gICAgY2hpbGRyZW46IGNoaWxkcmVuXG4gIH0pO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgTWVudUZpbHRlclJvb3QgfSBmcm9tIFwiLi4vZmlsdGVyLXJvb3QvTWVudUZpbHRlclJvb3QubWpzXCI7XG5pbXBvcnQgeyBNZW51RmlsdGVyU3VibWVudVJvb3QgfSBmcm9tIFwiLi4vZmlsdGVyLXN1Ym1lbnUtcm9vdC9NZW51RmlsdGVyU3VibWVudVJvb3QubWpzXCI7XG5pbXBvcnQgeyBNZW51RmlsdGVyUHJvdmlkZXJDb250ZXh0IH0gZnJvbSBcIi4vTWVudUZpbHRlclByb3ZpZGVyQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vKipcbiAqIEVuYWJsZXMgZmlsdGVyaW5nIGZvciB0aGUgbWVudSBvciBzdWJtZW51IGl0IHdyYXBzLiBBZGQgYE1lbnUuSW5wdXRgIHRvIHRoZSBwb3B1cCBhbmQgcGxhY2VcbiAqIGl0cyBpdGVtcyBpbiBgTWVudS5MaXN0YC5cbiAqIFdyYXAgZWFjaCBzZWFyY2hhYmxlIHN1Ym1lbnUgaW4gaXRzIG93biBwcm92aWRlci5cbiAqIERvZXNuJ3QgcmVuZGVyIGl0cyBvd24gSFRNTCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIE1lbnVdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9tZW51KVxuICovXG5leHBvcnQgZnVuY3Rpb24gTWVudUZpbHRlclByb3ZpZGVyKHByb3BzKSB7XG4gIGNvbnN0IHtcbiAgICBjaGlsZHJlbixcbiAgICBmaWx0ZXIsXG4gICAgdmFsdWUsXG4gICAgZGVmYXVsdFZhbHVlLFxuICAgIG9uVmFsdWVDaGFuZ2UsXG4gICAgYXV0b0hpZ2hsaWdodCxcbiAgICBsb2NhbGVcbiAgfSA9IHByb3BzO1xuICBjb25zdCBjb250ZXh0VmFsdWUgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgUm9vdDogTWVudUZpbHRlclJvb3QsXG4gICAgU3VibWVudVJvb3Q6IE1lbnVGaWx0ZXJTdWJtZW51Um9vdCxcbiAgICBvcHRpb25zOiB7XG4gICAgICBmaWx0ZXIsXG4gICAgICB2YWx1ZSxcbiAgICAgIGRlZmF1bHRWYWx1ZSxcbiAgICAgIG9uVmFsdWVDaGFuZ2UsXG4gICAgICBhdXRvSGlnaGxpZ2h0LFxuICAgICAgbG9jYWxlXG4gICAgfVxuICB9KSwgW2ZpbHRlciwgdmFsdWUsIGRlZmF1bHRWYWx1ZSwgb25WYWx1ZUNoYW5nZSwgYXV0b0hpZ2hsaWdodCwgbG9jYWxlXSk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChNZW51RmlsdGVyUHJvdmlkZXJDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IGNvbnRleHRWYWx1ZSxcbiAgICBjaGlsZHJlbjogY2hpbGRyZW5cbiAgfSk7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBwbGF0Zm9ybSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtJztcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VCYXNlVWlJZCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlQmFzZVVpSWQubWpzXCI7XG5pbXBvcnQgeyBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL2NyZWF0ZUJhc2VVSUV2ZW50RGV0YWlscy5tanNcIjtcbmltcG9ydCB7IFJFQVNPTlMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3JlYXNvbnMubWpzXCI7XG5pbXBvcnQgeyB1c2VGaWx0ZXJEcm9wZG93bkl0ZW1Db250ZXh0LCB1c2VGaWx0ZXJEcm9wZG93blJvb3RDb250ZXh0LCB1c2VGaWx0ZXJEcm9wZG93blZhbHVlQ29udGV4dCB9IGZyb20gXCIuLi9yb290L0ZpbHRlckRyb3Bkb3duUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyByZWZvY3VzT3duZXIsIGlzUmVmb2N1c2luZ093bmVyIH0gZnJvbSBcIi4uL3V0aWxzL3JlZm9jdXNPd25lci5tanNcIjtcblxuLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGNvbnN0IEZpbHRlckRyb3Bkb3duSW5wdXQgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBGaWx0ZXJEcm9wZG93bklucHV0KGNvbXBvbmVudFByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3Qge1xuICAgIHJlbmRlcixcbiAgICBjbGFzc05hbWUsXG4gICAgc3R5bGUsXG4gICAgaWQ6IGlkUHJvcCxcbiAgICBkaXNhYmxlZCxcbiAgICBhY3RpdmVJdGVtSWQsXG4gICAgbmF2aWdhdGlvblByb3BzLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG5cbiAgLy8gQnJvd3NlcnMgZmxhZyBhIGZvcm0gZmllbGQgd2l0aCBuZWl0aGVyIGFuIGlkIG5vciBhIG5hbWUuXG4gIGNvbnN0IGlkID0gdXNlQmFzZVVpSWQoaWRQcm9wKTtcbiAgY29uc3QgY29udGV4dCA9IHVzZUZpbHRlckRyb3Bkb3duUm9vdENvbnRleHQoKTtcbiAgY29uc3Qge1xuICAgIGxpc3RSZWZcbiAgfSA9IHVzZUZpbHRlckRyb3Bkb3duSXRlbUNvbnRleHQoKTtcbiAgY29uc3QgdmFsdWUgPSB1c2VGaWx0ZXJEcm9wZG93blZhbHVlQ29udGV4dCgpO1xuXG4gIC8vIElNRSB0ZXh0IGlzbid0IGNvbW1pdHRlZCB1bnRpbCB0aGUgY29tcG9zaXRpb24gZW5kcywgc28gZmlsdGVyaW5nIHdhaXRzIGZvciBpdC5cbiAgY29uc3QgW2NvbXBvc2luZ1ZhbHVlLCBzZXRDb21wb3NpbmdWYWx1ZV0gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgaXNDb21wb3NpbmdSZWYgPSBSZWFjdC51c2VSZWYoZmFsc2UpO1xuICBmdW5jdGlvbiBjb21taXRWYWx1ZShuZXh0VmFsdWUsIG5hdGl2ZUV2ZW50KSB7XG4gICAgLy8gVGhlIGlucHV0IGtlZXBzIGZvY3VzIHVudGlsIHRoZSBwb3B1cCB1bm1vdW50cy4gQW4gZWRpdCBtYWRlIHdoaWxlIGl0IGFuaW1hdGVzIG91dCB3b3VsZFxuICAgIC8vIGxhbmQgYWZ0ZXIgdGhlIGNsb3NlIHJlc2V0IHRoZSBxdWVyeSBhbmQgY2Fycnkgb3ZlciBpbnRvIHRoZSBuZXh0IG9wZW4uXG4gICAgaWYgKCFjb250ZXh0Lm9wZW4pIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgcmVhc29uID0gbmV4dFZhbHVlID09PSAnJyA/IFJFQVNPTlMuaW5wdXRDbGVhciA6IFJFQVNPTlMuaW5wdXRDaGFuZ2U7XG4gICAgY29udGV4dC5vblZhbHVlQ2hhbmdlKG5leHRWYWx1ZSwgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzKHJlYXNvbiwgbmF0aXZlRXZlbnQpKTtcbiAgfVxuICBjb25zdCBzdGF0ZSA9IHtcbiAgICBoaWdobGlnaHRlZDogY29udGV4dC5pbnB1dEZvY3VzVmlzaWJsZSAmJiAoIWNvbnRleHQua2V5Ym9hcmRNb2RhbGl0eSB8fCBhY3RpdmVJdGVtSWQgPT0gbnVsbClcbiAgfTtcbiAgcmV0dXJuIHVzZVJlbmRlckVsZW1lbnQoJ2lucHV0JywgY29tcG9uZW50UHJvcHMsIHtcbiAgICBzdGF0ZSxcbiAgICByZWY6IFtmb3J3YXJkZWRSZWYsIGNvbnRleHQuZm9jdXNPd25lclJlZl0sXG4gICAgcHJvcHM6IFtuYXZpZ2F0aW9uUHJvcHMsIHtcbiAgICAgIGlkLFxuICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgZGlzYWJsZWQ6IGNvbnRleHQuZGlzYWJsZWQgfHwgZGlzYWJsZWQsXG4gICAgICAnYXJpYS1hY3RpdmVkZXNjZW5kYW50JzogYWN0aXZlSXRlbUlkLFxuICAgICAgcm9sZTogJ3NlYXJjaGJveCcsXG4gICAgICBpbnB1dE1vZGU6ICdzZWFyY2gnLFxuICAgICAgYXV0b0NvbXBsZXRlOiAnb2ZmJyxcbiAgICAgIHNwZWxsQ2hlY2s6ICdmYWxzZScsXG4gICAgICBhdXRvQ29ycmVjdDogJ29mZicsXG4gICAgICBhdXRvQ2FwaXRhbGl6ZTogJ25vbmUnLFxuICAgICAgLy8gVGhlIGFyaWEtYXV0b2NvbXBsZXRlICdsaXN0JyB2YWx1ZSBpcyBvbmx5IHZhbGlkIHdpdGggYGFyaWEtaGFzcG9wdXBgIHNvIHdlIGRlcGVuZFxuICAgICAgLy8gb24gdGhlIHNlYXJjaGJveCByb2xlIHRvIGNvbW11bmljYXRlIGFmZm9yZGFuY2UsIHdpdGggYW4gaW5wdXQgbGFiZWwgYXMgZmFsbGJhY2tcbiAgICAgIC8vIGh0dHBzOi8vdzNjLmdpdGh1Yi5pby9hcmlhLyNhcmlhLWF1dG9jb21wbGV0ZVxuICAgICAgJ2FyaWEtYXV0b2NvbXBsZXRlJzogdW5kZWZpbmVkLFxuICAgICAgJ2FyaWEtY29udHJvbHMnOiBjb250ZXh0Lmxpc3RJZCxcbiAgICAgIHZhbHVlOiBjb21wb3NpbmdWYWx1ZSA/PyB2YWx1ZSxcbiAgICAgIG9uQ29tcG9zaXRpb25TdGFydChldmVudCkge1xuICAgICAgICAvLyBTb21lIEFuZHJvaWQga2V5Ym9hcmRzIHRyZWF0IGFsbCB0eXBpbmcgYXMgb25lIGNvbXBvc2l0aW9uLlxuICAgICAgICBpZiAocGxhdGZvcm0ub3MuYW5kcm9pZCkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBpc0NvbXBvc2luZ1JlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICAgICAgc2V0Q29tcG9zaW5nVmFsdWUoZXZlbnQuY3VycmVudFRhcmdldC52YWx1ZSk7XG4gICAgICB9LFxuICAgICAgb25Db21wb3NpdGlvbkVuZChldmVudCkge1xuICAgICAgICBpZiAoIWlzQ29tcG9zaW5nUmVmLmN1cnJlbnQpIHtcbiAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgaXNDb21wb3NpbmdSZWYuY3VycmVudCA9IGZhbHNlO1xuICAgICAgICBzZXRDb21wb3NpbmdWYWx1ZShudWxsKTtcbiAgICAgICAgY29tbWl0VmFsdWUoZXZlbnQuY3VycmVudFRhcmdldC52YWx1ZSwgZXZlbnQubmF0aXZlRXZlbnQpO1xuICAgICAgfSxcbiAgICAgIG9uQ2hhbmdlKGV2ZW50KSB7XG4gICAgICAgIGlmIChpc0NvbXBvc2luZ1JlZi5jdXJyZW50KSB7XG4gICAgICAgICAgc2V0Q29tcG9zaW5nVmFsdWUoZXZlbnQuY3VycmVudFRhcmdldC52YWx1ZSk7XG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbW1pdFZhbHVlKGV2ZW50LmN1cnJlbnRUYXJnZXQudmFsdWUsIGV2ZW50Lm5hdGl2ZUV2ZW50KTtcbiAgICAgIH0sXG4gICAgICBvbktleURvd24oKSB7XG4gICAgICAgIGNvbnRleHQuc2V0S2V5Ym9hcmRNb2RhbGl0eSh0cnVlKTtcbiAgICAgIH0sXG4gICAgICBvblBvaW50ZXJEb3duKCkge1xuICAgICAgICBjb250ZXh0LnNldEtleWJvYXJkTW9kYWxpdHkoZmFsc2UpO1xuICAgICAgfSxcbiAgICAgIG9uTW91c2VFbnRlcihldmVudCkge1xuICAgICAgICBjb250ZXh0LnNldEtleWJvYXJkTW9kYWxpdHkoZmFsc2UpO1xuICAgICAgICAvLyBUYWtlIGZvY3VzIHNvIHR5cGluZyBmaWx0ZXJzIGltbWVkaWF0ZWx5LlxuICAgICAgICBpZiAoY29udGV4dC5vcGVuKSB7XG4gICAgICAgICAgcmVmb2N1c093bmVyKGV2ZW50LmN1cnJlbnRUYXJnZXQpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgb25Gb2N1cyhldmVudCkge1xuICAgICAgICBjb250ZXh0LnNldElucHV0Rm9jdXNWaXNpYmxlKHRydWUpO1xuXG4gICAgICAgIC8vIEEgc2NyZWVuIHJlYWRlciB0aGF0IGZvbGxvd2VkIGBhcmlhLWFjdGl2ZWRlc2NlbmRhbnRgIHB1dCByZWFsIGZvY3VzIG9uIHRoZSBpdGVtLCBzb1xuICAgICAgICAvLyBmb2N1cyByZXR1cm5pbmcgZnJvbSBhbiBpdGVtIG1lYW5zIHRoZSB1c2VyIG1vdmVkIGJhY2sgdG8gdGhlIGlucHV0IG9uIHB1cnBvc2UgYW5kXG4gICAgICAgIC8vIHRoZSBoaWdobGlnaHQgbm8gbG9uZ2VyIHJlZmxlY3RzIHdoZXJlIHRoZXkgYXJlLiBUaGUgbGlzdCdzIG93biBrZXkgcmVwbGF5IGFuZFxuICAgICAgICAvLyBwb2ludGVyIHJlZm9jdXMgYWxzbyBwYXNzIHRocm91Z2ggaGVyZSBhbmQga2VlcCBpdC5cbiAgICAgICAgaWYgKGNvbnRleHQuYXV0b0hpZ2hsaWdodCA9PT0gJ2Fsd2F5cycgfHwgaXNSZWZvY3VzaW5nT3duZXIoKSkge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBmcm9tID0gZXZlbnQucmVsYXRlZFRhcmdldDtcbiAgICAgICAgaWYgKGZyb20gIT09IG51bGwgJiYgbGlzdFJlZi5jdXJyZW50LmluY2x1ZGVzKGZyb20pKSB7XG4gICAgICAgICAgY29udGV4dC5zZXRBY3RpdmVJbmRleChudWxsKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIG9uQmx1cigpIHtcbiAgICAgICAgY29udGV4dC5zZXRJbnB1dEZvY3VzVmlzaWJsZShmYWxzZSk7XG4gICAgICB9XG4gICAgfSwgZWxlbWVudFByb3BzXVxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgRmlsdGVyRHJvcGRvd25JbnB1dC5kaXNwbGF5TmFtZSA9IFwiRmlsdGVyRHJvcGRvd25JbnB1dFwiOyIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgb3duZXJEb2N1bWVudCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL293bmVyJztcbmltcG9ydCB7IHVzZU1lcmdlZFJlZnMgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VNZXJnZWRSZWZzJztcbmltcG9ydCB7IEZpbHRlckRyb3Bkb3duSW5wdXQgfSBmcm9tIFwiLi4vLi4vZmlsdGVyLWRyb3Bkb3duL2lucHV0L0ZpbHRlckRyb3Bkb3duSW5wdXQubWpzXCI7XG5pbXBvcnQgeyB1c2VGaWx0ZXJEcm9wZG93blZhbHVlQ29udGV4dCB9IGZyb20gXCIuLi8uLi9maWx0ZXItZHJvcGRvd24vcm9vdC9GaWx0ZXJEcm9wZG93blJvb3RDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgbWVyZ2VQcm9wcyB9IGZyb20gXCIuLi8uLi9tZXJnZS1wcm9wcy9pbmRleC5tanNcIjtcbmltcG9ydCB7IGFjdGl2ZUVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vZmxvYXRpbmctdWktcmVhY3QvdXRpbHMubWpzXCI7XG5pbXBvcnQgeyB1c2VNZW51RmlsdGVyS2V5RG93biB9IGZyb20gXCIuLi9maWx0ZXItcm9vdC91c2VNZW51RmlsdGVyS2V5RG93bi5tanNcIjtcbmltcG9ydCB7IHVzZU1lbnVGaWx0ZXJQYXJ0IH0gZnJvbSBcIi4uL2ZpbHRlci1yb290L01lbnVGaWx0ZXJDb250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgdXNlTWVudVJvb3RDb250ZXh0IH0gZnJvbSBcIi4uL3Jvb3QvTWVudVJvb3RDb250ZXh0Lm1qc1wiO1xuXG4vKipcbiAqIEEgc2VhcmNoIGZpZWxkIHRoYXQgZmlsdGVycyB0aGUgbWVudSBpdGVtcy5cbiAqIFJlcXVpcmVzIHRoZSBtZW51IHRvIGJlIHdyYXBwZWQgaW4gYE1lbnUuRmlsdGVyUHJvdmlkZXJgLlxuICogUmVuZGVycyBhbiBgPGlucHV0PmAgZWxlbWVudC5cbiAqXG4gKiBEb2N1bWVudGF0aW9uOiBbQmFzZSBVSSBNZW51XShodHRwczovL2Jhc2UtdWkuY29tL3JlYWN0L2NvbXBvbmVudHMvbWVudSlcbiAqL1xuaW1wb3J0IHsganN4IGFzIF9qc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbmV4cG9ydCBjb25zdCBNZW51SW5wdXQgPSAvKiNfX1BVUkVfXyovUmVhY3QuZm9yd2FyZFJlZihmdW5jdGlvbiBNZW51SW5wdXQoY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICB1c2VNZW51RmlsdGVyUGFydCgnSW5wdXQnKTtcbiAgY29uc3Qge1xuICAgIHN0b3JlXG4gIH0gPSB1c2VNZW51Um9vdENvbnRleHQoKTtcbiAgY29uc3QgdmFsdWUgPSB1c2VGaWx0ZXJEcm9wZG93blZhbHVlQ29udGV4dCgpO1xuICBjb25zdCB7XG4gICAgb25LZXlEb3duLFxuICAgIC4uLm5hdmlnYXRpb25Qcm9wc1xuICB9ID0gc3RvcmUudXNlU3RhdGUoJ2lucHV0UHJvcHMnKTtcbiAgY29uc3QgYWN0aXZlSXRlbUlkID0gc3RvcmUudXNlU3RhdGUoJ2hpZ2hsaWdodGVkSXRlbUlkJyk7XG4gIGNvbnN0IGhhbmRsZUtleURvd24gPSB1c2VNZW51RmlsdGVyS2V5RG93bih2YWx1ZSAhPT0gJycpO1xuICBjb25zdCBoYW5kbGVJbnB1dFJlZiA9IFJlYWN0LnVzZUNhbGxiYWNrKGlucHV0ID0+IHtcbiAgICAvLyBSZWYgY2hhbmdlcyBjb3ZlciBpbnB1dCByZW1vdmFsIHdpdGhvdXQgYmx1ciBhbmQgcmVzdG9yZSBmb2N1cyBhZnRlciBTdHJpY3QgTW9kZSByZXBsYXkuXG4gICAgc3RvcmUuc2V0KCdpbnB1dEZvY3VzZWQnLCBpbnB1dCAhPT0gbnVsbCAmJiBhY3RpdmVFbGVtZW50KG93bmVyRG9jdW1lbnQoaW5wdXQpKSA9PT0gaW5wdXQpO1xuICB9LCBbc3RvcmVdKTtcbiAgY29uc3QgbWVyZ2VkUmVmcyA9IHVzZU1lcmdlZFJlZnMoZm9yd2FyZGVkUmVmLCBoYW5kbGVJbnB1dFJlZik7XG4gIGNvbnN0IGlucHV0UHJvcHMgPSBtZXJnZVByb3BzKHtcbiAgICBvbktleURvd246IGhhbmRsZUtleURvd24sXG4gICAgb25Gb2N1cygpIHtcbiAgICAgIHN0b3JlLnNldCgnaW5wdXRGb2N1c2VkJywgdHJ1ZSk7XG4gICAgfSxcbiAgICBvbkJsdXIoKSB7XG4gICAgICBzdG9yZS5zZXQoJ2lucHV0Rm9jdXNlZCcsIGZhbHNlKTtcbiAgICB9XG4gIH0sIGNvbXBvbmVudFByb3BzKTtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KEZpbHRlckRyb3Bkb3duSW5wdXQsIHtcbiAgICAuLi5pbnB1dFByb3BzLFxuICAgIGFjdGl2ZUl0ZW1JZDogYWN0aXZlSXRlbUlkLFxuICAgIG5hdmlnYXRpb25Qcm9wczogbmF2aWdhdGlvblByb3BzLFxuICAgIHJlZjogbWVyZ2VkUmVmc1xuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgTWVudUlucHV0LmRpc3BsYXlOYW1lID0gXCJNZW51SW5wdXRcIjsiLCIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VNZW51RmlsdGVySW1wbCB9IGZyb20gXCIuLi9maWx0ZXItcm9vdC9NZW51RmlsdGVyQ29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZU1lbnVSb290Q29udGV4dCB9IGZyb20gXCIuLi9yb290L01lbnVSb290Q29udGV4dC5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyB1c2VCYXNlVWlJZCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlQmFzZVVpSWQubWpzXCI7XG5pbXBvcnQgeyByZXNvbHZlUG9wdXBMYWJlbCB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvcmVzb2x2ZVBvcHVwTGFiZWwubWpzXCI7XG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuY29uc3QgTWVudUxpc3RQbGFpbiA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIE1lbnVMaXN0UGxhaW4oY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIGNsYXNzTmFtZSxcbiAgICBzdHlsZSxcbiAgICBpZDogaWRQcm9wLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IHtcbiAgICBzdG9yZSxcbiAgICBvcmllbnRhdGlvblxuICB9ID0gdXNlTWVudVJvb3RDb250ZXh0KCk7XG4gIGNvbnN0IGFjdGl2ZVRyaWdnZXJJZCA9IHN0b3JlLnVzZVN0YXRlKCdhY3RpdmVUcmlnZ2VySWQnKTtcbiAgY29uc3QgYWN0aXZlVHJpZ2dlckVsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZSgnYWN0aXZlVHJpZ2dlckVsZW1lbnQnKTtcbiAgY29uc3Qgc2V0TGlzdEVsZW1lbnQgPSBzdG9yZS51c2VTdGF0ZVNldHRlcignbGlzdEVsZW1lbnQnKTtcbiAgY29uc3QgaWQgPSB1c2VCYXNlVWlJZChpZFByb3ApO1xuXG4gIC8vIFRoZSB0cmlnZ2VyIHJlYWRzIGBhcmlhLWNvbnRyb2xzYCBvZmYgdGhlIHN0b3JlZCBlbGVtZW50LCB3aGljaCBhbiBpZCBjaGFuZ2UgYWxvbmUgbGVhdmVzIGluXG4gIC8vIHBsYWNlLCBzbyBzdWJzY3JpYmVycyBhcmUgdG9sZCB0byByZWFkIGl0IGFnYWluLiBNb3VudGluZyBwdWJsaXNoZXMgdGhlIGVsZW1lbnQgaXRzZWxmLlxuICBjb25zdCByZW5kZXJlZElkUmVmID0gUmVhY3QudXNlUmVmKGlkKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAocmVuZGVyZWRJZFJlZi5jdXJyZW50ICE9PSBpZCkge1xuICAgICAgcmVuZGVyZWRJZFJlZi5jdXJyZW50ID0gaWQ7XG4gICAgICBzdG9yZS5ub3RpZnlBbGwoKTtcbiAgICB9XG4gIH0sIFtpZCwgc3RvcmVdKTtcbiAgY29uc3QgYXJpYUxhYmVsbGVkQnkgPSByZXNvbHZlUG9wdXBMYWJlbChjb21wb25lbnRQcm9wcywgYWN0aXZlVHJpZ2dlckVsZW1lbnQsIGFjdGl2ZVRyaWdnZXJJZCk7XG4gIHJldHVybiB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHJlZjogW2ZvcndhcmRlZFJlZiwgc2V0TGlzdEVsZW1lbnRdLFxuICAgIHByb3BzOiBbe1xuICAgICAgaWQsXG4gICAgICByb2xlOiAnbWVudScsXG4gICAgICAvLyBUaGUgcG9wdXAgZm9jdXNlcyB0aGUgbGlzdCBvbiBhIHBvaW50ZXIgb3BlbiBpbiBwbGFjZSBvZiBpdHNlbGYuXG4gICAgICB0YWJJbmRleDogLTEsXG4gICAgICAvLyBgbWVudWAgaXMgaW1wbGljaXRseSB2ZXJ0aWNhbCwgc28gb25seSB0aGUgbm9uLWRlZmF1bHQgdmFsdWUgbmVlZHMgdG8gYmUgcmVuZGVyZWQuXG4gICAgICAnYXJpYS1vcmllbnRhdGlvbic6IG9yaWVudGF0aW9uID09PSAnaG9yaXpvbnRhbCcgPyAnaG9yaXpvbnRhbCcgOiB1bmRlZmluZWQsXG4gICAgICAnYXJpYS1sYWJlbGxlZGJ5JzogYXJpYUxhYmVsbGVkQnlcbiAgICB9LCBlbGVtZW50UHJvcHNdXG4gIH0pO1xufSk7XG5cbi8qKlxuICogR3JvdXBzIG1lbnUgaXRlbXMgc28gb3RoZXIgY29udGVudCwgc3VjaCBhcyBhIGZpbHRlciBpbnB1dCwgY2FuIHNoYXJlIHRoZSBwb3B1cC5cbiAqIFJlbmRlcnMgYSBgPGRpdj5gIGVsZW1lbnQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgTWVudV0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL21lbnUpXG4gKi9cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnVMaXN0UGxhaW4uZGlzcGxheU5hbWUgPSBcIk1lbnVMaXN0UGxhaW5cIjtcbmV4cG9ydCBjb25zdCBNZW51TGlzdCA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIE1lbnVMaXN0KHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgY29uc3QgTGlzdCA9IHVzZU1lbnVGaWx0ZXJJbXBsKCk/Lkxpc3QgPz8gTWVudUxpc3RQbGFpbjtcbiAgcmV0dXJuIC8qI19fUFVSRV9fKi9fanN4KExpc3QsIHtcbiAgICAuLi5wcm9wcyxcbiAgICByZWY6IGZvcndhcmRlZFJlZlxuICB9KTtcbn0pO1xuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgTWVudUxpc3QuZGlzcGxheU5hbWUgPSBcIk1lbnVMaXN0XCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VCdXR0b24gfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3VzZS1idXR0b24vaW5kZXgubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgY3JlYXRlQ2hhbmdlRXZlbnREZXRhaWxzIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9jcmVhdGVCYXNlVUlFdmVudERldGFpbHMubWpzXCI7XG5pbXBvcnQgeyBSRUFTT05TIH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy9yZWFzb25zLm1qc1wiO1xuaW1wb3J0IHsgdXNlRmlsdGVyRHJvcGRvd25Sb290Q29udGV4dCwgdXNlRmlsdGVyRHJvcGRvd25WYWx1ZUNvbnRleHQgfSBmcm9tIFwiLi4vcm9vdC9GaWx0ZXJEcm9wZG93blJvb3RDb250ZXh0Lm1qc1wiO1xuXG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgY29uc3QgRmlsdGVyRHJvcGRvd25DbGVhciA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIEZpbHRlckRyb3Bkb3duQ2xlYXIoY29tcG9uZW50UHJvcHMsIGZvcndhcmRlZFJlZikge1xuICBjb25zdCB7XG4gICAgcmVuZGVyLFxuICAgIGNsYXNzTmFtZSxcbiAgICBzdHlsZSxcbiAgICBkaXNhYmxlZDogZGlzYWJsZWRQcm9wID0gZmFsc2UsXG4gICAgbmF0aXZlQnV0dG9uID0gdHJ1ZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCBjb250ZXh0ID0gdXNlRmlsdGVyRHJvcGRvd25Sb290Q29udGV4dCgpO1xuICBjb25zdCB2YWx1ZSA9IHVzZUZpbHRlckRyb3Bkb3duVmFsdWVDb250ZXh0KCk7XG4gIGNvbnN0IGRpc2FibGVkID0gY29udGV4dC5kaXNhYmxlZCB8fCBkaXNhYmxlZFByb3A7XG4gIGNvbnN0IHZpc2libGUgPSB2YWx1ZSAhPT0gJyc7XG4gIGNvbnN0IHtcbiAgICBidXR0b25SZWYsXG4gICAgZ2V0QnV0dG9uUHJvcHNcbiAgfSA9IHVzZUJ1dHRvbih7XG4gICAgZGlzYWJsZWQsXG4gICAgbmF0aXZlOiBuYXRpdmVCdXR0b25cbiAgfSk7XG5cbiAgLy8gYHZpc2libGVgIGlzIGRlbGliZXJhdGVseSBhYnNlbnQgZnJvbSB0aGUgc3RhdGU6IHRoZSBjb21wb25lbnQgcmVuZGVycyBub3RoaW5nIHdoZW4gaXQgaXNcbiAgLy8gZmFsc2UsIHNvIGEgYGRhdGEtdmlzaWJsZWAgYXR0cmlidXRlIHdvdWxkIGJlIHByZXNlbnQgb24gZXZlcnkgcmVuZGVyZWQgaW5zdGFuY2UuXG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIGRpc2FibGVkXG4gIH07XG4gIHJldHVybiB1c2VSZW5kZXJFbGVtZW50KCdidXR0b24nLCBjb21wb25lbnRQcm9wcywge1xuICAgIGVuYWJsZWQ6IHZpc2libGUsXG4gICAgc3RhdGUsXG4gICAgcmVmOiBbZm9yd2FyZGVkUmVmLCBidXR0b25SZWZdLFxuICAgIHByb3BzOiBbe1xuICAgICAgdGFiSW5kZXg6IC0xLFxuICAgICAgJ2FyaWEtaGlkZGVuJzogdHJ1ZSxcbiAgICAgIG9uTW91c2VEb3duKGV2ZW50KSB7XG4gICAgICAgIC8vIEF2b2lkIHN0ZWFsaW5nIGZvY3VzIGZyb20gdGhlIGlucHV0IG9uIHBvaW50ZXIgaW50ZXJhY3Rpb24uXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICB9LFxuICAgICAgb25DbGljayhldmVudCkge1xuICAgICAgICBjb25zdCBldmVudERldGFpbHMgPSBjcmVhdGVDaGFuZ2VFdmVudERldGFpbHMoUkVBU09OUy5jbGVhclByZXNzLCBldmVudC5uYXRpdmVFdmVudCk7XG4gICAgICAgIGNvbnRleHQub25WYWx1ZUNoYW5nZSgnJywgZXZlbnREZXRhaWxzKTtcbiAgICAgICAgY29udGV4dC5mb2N1c093bmVyUmVmLmN1cnJlbnQ/LmZvY3VzKHtcbiAgICAgICAgICBwcmV2ZW50U2Nyb2xsOiB0cnVlXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0sIGVsZW1lbnRQcm9wcywgZ2V0QnV0dG9uUHJvcHNdXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBGaWx0ZXJEcm9wZG93bkNsZWFyLmRpc3BsYXlOYW1lID0gXCJGaWx0ZXJEcm9wZG93bkNsZWFyXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBGaWx0ZXJEcm9wZG93bkNsZWFyIH0gZnJvbSBcIi4uLy4uL2ZpbHRlci1kcm9wZG93bi9jbGVhci9GaWx0ZXJEcm9wZG93bkNsZWFyLm1qc1wiO1xuaW1wb3J0IHsgdXNlTWVudUZpbHRlclBhcnQgfSBmcm9tIFwiLi4vZmlsdGVyLXJvb3QvTWVudUZpbHRlckNvbnRleHQubWpzXCI7XG5cbi8qKlxuICogQSBidXR0b24gdGhhdCBjbGVhcnMgdGhlIGlucHV0IHRleHQuXG4gKiBSZXF1aXJlcyB0aGUgbWVudSB0byBiZSB3cmFwcGVkIGluIGBNZW51LkZpbHRlclByb3ZpZGVyYC5cbiAqIFJlbmRlcnMgYSBgPGJ1dHRvbj5gIGVsZW1lbnQgd2hlbiB0aGUgaW5wdXQgaGFzIHRleHQuXG4gKlxuICogRG9jdW1lbnRhdGlvbjogW0Jhc2UgVUkgTWVudV0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL21lbnUpXG4gKi9cbmltcG9ydCB7IGpzeCBhcyBfanN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5leHBvcnQgY29uc3QgTWVudUNsZWFyID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gTWVudUNsZWFyKHByb3BzLCBmb3J3YXJkZWRSZWYpIHtcbiAgdXNlTWVudUZpbHRlclBhcnQoJ0NsZWFyJyk7XG4gIHJldHVybiAvKiNfX1BVUkVfXyovX2pzeChGaWx0ZXJEcm9wZG93bkNsZWFyLCB7XG4gICAgLi4ucHJvcHMsXG4gICAgcmVmOiBmb3J3YXJkZWRSZWZcbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIE1lbnVDbGVhci5kaXNwbGF5TmFtZSA9IFwiTWVudUNsZWFyXCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBwbGF0Zm9ybSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3BsYXRmb3JtJztcbmltcG9ydCB7IHVzZVRpbWVvdXQgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VUaW1lb3V0JztcblxuLy8gV29yZCBKb2luZXIgaXMgaW52aXNpYmxlIGFuZCB6ZXJvLXdpZHRoLCBzbyBpdCBmb3JjZXMgYSB0ZXh0IG11dGF0aW9uIHdpdGhvdXQgc2hpZnRpbmcgbGF5b3V0LlxuY29uc3QgTElWRV9SRUdJT05fTUFSS0VSID0gJ1xcdTIwNjAnO1xuLy8gU2FmYXJpIFZvaWNlT3ZlciBuZWVkZWQgcm91Z2hseSAyMDBtcyB0byByZWxpYWJseSBub3RpY2UgdGhlIGluaXRpYWwgcG9saXRlIGxpdmUtcmVnaW9uIGNoYW5nZS5cbmV4cG9ydCBjb25zdCBJTklUSUFMX0xJVkVfUkVHSU9OX1RFWFRfTVVUQVRJT05fUkVTRVRfREVMQVkgPSAyMDA7XG5mdW5jdGlvbiBmaW5kTGFzdFRleHROb2RlKHJvb3QpIHtcbiAgY29uc3Qgd2Fsa2VyID0gcm9vdC5vd25lckRvY3VtZW50LmNyZWF0ZVRyZWVXYWxrZXIocm9vdCwgTm9kZUZpbHRlci5TSE9XX1RFWFQpO1xuICBsZXQgbGFzdFRleHROb2RlID0gbnVsbDtcbiAgd2hpbGUgKHdhbGtlci5uZXh0Tm9kZSgpKSB7XG4gICAgY29uc3QgdGV4dE5vZGUgPSB3YWxrZXIuY3VycmVudE5vZGU7XG4gICAgaWYgKHRleHROb2RlLm5vZGVWYWx1ZSAhPT0gJycpIHtcbiAgICAgIGxhc3RUZXh0Tm9kZSA9IHRleHROb2RlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gbGFzdFRleHROb2RlO1xufVxuXG4vKipcbiAqIEBwYXJhbSBwcmVzZW50IFdoZXRoZXIgdGhlIGxpdmUgcmVnaW9uIGVsZW1lbnQgaXMgY3VycmVudGx5IHJlbmRlcmVkLiBMZXRzIGEgY29uZGl0aW9uYWxseVxuICogcmVuZGVyZWQgcmVnaW9uIHJlLXJ1biB0aGUgbWFya2VyIGVhY2ggdGltZSBpdHMgZWxlbWVudCAocmUpYXBwZWFycyB3aXRoIHRleHQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VJbml0aWFsTGl2ZVJlZ2lvblRleHRNdXRhdGlvbihwcmVzZW50ID0gdHJ1ZSkge1xuICBjb25zdCB0aW1lb3V0ID0gdXNlVGltZW91dCgpO1xuICBjb25zdCByb290UmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuXG4gIC8vIE9ubHkgdGhlIGluaXRpYWwgbW91bnRlZCBhbm5vdW5jZW1lbnQgbmVlZHMgdGhlIG1hcmtlcjsgbGF0ZXIgdGV4dCB1cGRhdGVzIGFubm91bmNlIG5hdHVyYWxseS5cbiAgUmVhY3QudXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIXByZXNlbnQgfHwgcGxhdGZvcm0ub3MuaW9zKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBjb25zdCByb290ID0gcm9vdFJlZi5jdXJyZW50O1xuICAgIGlmIChyb290ID09IG51bGwpIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGNvbnN0IHRleHROb2RlID0gZmluZExhc3RUZXh0Tm9kZShyb290KTtcbiAgICBpZiAodGV4dE5vZGUgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICB9XG4gICAgY29uc3Qgb3JpZ2luYWxWYWx1ZSA9IHRleHROb2RlLmRhdGE7XG4gICAgY29uc3QgbWFya2VkVmFsdWUgPSBgJHtvcmlnaW5hbFZhbHVlfSR7TElWRV9SRUdJT05fTUFSS0VSfWA7XG4gICAgdGV4dE5vZGUubm9kZVZhbHVlID0gbWFya2VkVmFsdWU7XG4gICAgdGltZW91dC5zdGFydChJTklUSUFMX0xJVkVfUkVHSU9OX1RFWFRfTVVUQVRJT05fUkVTRVRfREVMQVksICgpID0+IHtcbiAgICAgIGlmICh0ZXh0Tm9kZS5ub2RlVmFsdWUgPT09IG1hcmtlZFZhbHVlKSB7XG4gICAgICAgIHRleHROb2RlLm5vZGVWYWx1ZSA9IG9yaWdpbmFsVmFsdWU7XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgIHRpbWVvdXQuY2xlYXIoKTtcbiAgICAgIGlmICh0ZXh0Tm9kZS5ub2RlVmFsdWUgPT09IG1hcmtlZFZhbHVlKSB7XG4gICAgICAgIHRleHROb2RlLm5vZGVWYWx1ZSA9IG9yaWdpbmFsVmFsdWU7XG4gICAgICB9XG4gICAgfTtcbiAgfSwgW3ByZXNlbnQsIHJvb3RSZWYsIHRpbWVvdXRdKTtcbiAgcmV0dXJuIHJvb3RSZWY7XG59IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VTdG9yZSB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3N0b3JlJztcbmltcG9ydCB7IHVzZUlzb0xheW91dEVmZmVjdCB9IGZyb20gJ0BiYXNlLXVpL3V0aWxzL3VzZUlzb0xheW91dEVmZmVjdCc7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uLy4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuaW1wb3J0IHsgdXNlRmlsdGVyRHJvcGRvd25JdGVtQ29udGV4dCB9IGZyb20gXCIuLi9yb290L0ZpbHRlckRyb3Bkb3duUm9vdENvbnRleHQubWpzXCI7XG5pbXBvcnQgeyBzZWxlY3RvcnMgfSBmcm9tIFwiLi4vc3RvcmUubWpzXCI7XG5pbXBvcnQgeyB1c2VJbml0aWFsTGl2ZVJlZ2lvblRleHRNdXRhdGlvbiB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvdXNlSW5pdGlhbExpdmVSZWdpb25UZXh0TXV0YXRpb24ubWpzXCI7XG5cbi8qKlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBjb25zdCBGaWx0ZXJEcm9wZG93bkVtcHR5ID0gLyojX19QVVJFX18qL1JlYWN0LmZvcndhcmRSZWYoZnVuY3Rpb24gRmlsdGVyRHJvcGRvd25FbXB0eShjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIHN0eWxlLFxuICAgIC4uLmVsZW1lbnRQcm9wc1xuICB9ID0gY29tcG9uZW50UHJvcHM7XG4gIGNvbnN0IHtcbiAgICBzdG9yZVxuICB9ID0gdXNlRmlsdGVyRHJvcGRvd25JdGVtQ29udGV4dCgpO1xuICBjb25zdCBpc0VtcHR5ID0gdXNlU3RvcmUoc3RvcmUsIHNlbGVjdG9ycy5pc0VtcHR5KTtcblxuICAvLyBJdGVtcyBtb3VudGluZyBpbiB0aGUgc2FtZSBjb21taXQgcmVnaXN0ZXIgaW4gbGF5b3V0IGVmZmVjdHMsIGFmdGVyIHRoaXMgZmlyc3QgcmVuZGVyLCBhbmRcbiAgLy8gZG9uJ3QgcmVnaXN0ZXIgb24gdGhlIHNlcnZlciBhdCBhbGwuIERlY2lkaW5nIG9uY2UgdGhleSBoYXZlIGtlZXBzIHRoZSBjaGlsZHJlbiBmcm9tXG4gIC8vIG1vdW50aW5nIGZvciBhIGZyYW1lIG9uIGV2ZXJ5IG9wZW4sIGFuZCB0aGUgbWVzc2FnZSBvdXQgb2Ygc2VydmVyIG1hcmt1cC5cbiAgY29uc3QgW3JlYWR5LCBzZXRSZWFkeV0gPSBSZWFjdC51c2VTdGF0ZShmYWxzZSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgc2V0UmVhZHkodHJ1ZSk7XG4gIH0sIFtdKTtcbiAgY29uc3QgdmlzaWJsZSA9IHJlYWR5ICYmIGlzRW1wdHk7XG4gIGNvbnN0IGVtcHR5UmVmID0gdXNlSW5pdGlhbExpdmVSZWdpb25UZXh0TXV0YXRpb24odmlzaWJsZSk7XG4gIHJldHVybiB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIGVuYWJsZWQ6IHZpc2libGUsXG4gICAgcmVmOiBbZm9yd2FyZGVkUmVmLCBlbXB0eVJlZl0sXG4gICAgcHJvcHM6IFt7XG4gICAgICByb2xlOiAnc3RhdHVzJyxcbiAgICAgICdhcmlhLWxpdmUnOiAncG9saXRlJyxcbiAgICAgICdhcmlhLWF0b21pYyc6IHRydWVcbiAgICB9LCBlbGVtZW50UHJvcHNdXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBGaWx0ZXJEcm9wZG93bkVtcHR5LmRpc3BsYXlOYW1lID0gXCJGaWx0ZXJEcm9wZG93bkVtcHR5XCI7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBGaWx0ZXJEcm9wZG93bkVtcHR5IH0gZnJvbSBcIi4uLy4uL2ZpbHRlci1kcm9wZG93bi9lbXB0eS9GaWx0ZXJEcm9wZG93bkVtcHR5Lm1qc1wiO1xuaW1wb3J0IHsgdXNlTWVudUZpbHRlclBhcnQgfSBmcm9tIFwiLi4vZmlsdGVyLXJvb3QvTWVudUZpbHRlckNvbnRleHQubWpzXCI7XG5cbi8qKlxuICogQSBtZXNzYWdlIHNob3duIHdoZW4gdGhlIG1lbnUgaGFzIG5vIG1hdGNoaW5nIGl0ZW1zLlxuICogUmVxdWlyZXMgdGhlIG1lbnUgdG8gYmUgd3JhcHBlZCBpbiBgTWVudS5GaWx0ZXJQcm92aWRlcmAuXG4gKiBSZW5kZXJzIGEgYDxkaXY+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIE1lbnVdKGh0dHBzOi8vYmFzZS11aS5jb20vcmVhY3QvY29tcG9uZW50cy9tZW51KVxuICovXG5pbXBvcnQgeyBqc3ggYXMgX2pzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuZXhwb3J0IGNvbnN0IE1lbnVFbXB0eSA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIE1lbnVFbXB0eShwcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIHVzZU1lbnVGaWx0ZXJQYXJ0KCdFbXB0eScpO1xuICByZXR1cm4gLyojX19QVVJFX18qL19qc3goRmlsdGVyRHJvcGRvd25FbXB0eSwge1xuICAgIC4uLnByb3BzLFxuICAgIHJlZjogZm9yd2FyZGVkUmVmXG4gIH0pO1xufSk7XG5pZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBNZW51RW1wdHkuZGlzcGxheU5hbWUgPSBcIk1lbnVFbXB0eVwiOyIsImV4cG9ydCB7IE1lbnVBcnJvdyBhcyBBcnJvdyB9IGZyb20gXCIuL2Fycm93L01lbnVBcnJvdy5tanNcIjtcbmV4cG9ydCB7IE1lbnVCYWNrZHJvcCBhcyBCYWNrZHJvcCB9IGZyb20gXCIuL2JhY2tkcm9wL01lbnVCYWNrZHJvcC5tanNcIjtcbmV4cG9ydCB7IE1lbnVDaGVja2JveEl0ZW0gYXMgQ2hlY2tib3hJdGVtIH0gZnJvbSBcIi4vY2hlY2tib3gtaXRlbS9NZW51Q2hlY2tib3hJdGVtLm1qc1wiO1xuZXhwb3J0IHsgTWVudUNoZWNrYm94SXRlbUluZGljYXRvciBhcyBDaGVja2JveEl0ZW1JbmRpY2F0b3IgfSBmcm9tIFwiLi9jaGVja2JveC1pdGVtLWluZGljYXRvci9NZW51Q2hlY2tib3hJdGVtSW5kaWNhdG9yLm1qc1wiO1xuZXhwb3J0IHsgTWVudUdyb3VwIGFzIEdyb3VwIH0gZnJvbSBcIi4vZ3JvdXAvTWVudUdyb3VwLm1qc1wiO1xuZXhwb3J0IHsgTWVudUdyb3VwTGFiZWwgYXMgR3JvdXBMYWJlbCB9IGZyb20gXCIuL2dyb3VwLWxhYmVsL01lbnVHcm91cExhYmVsLm1qc1wiO1xuZXhwb3J0IHsgTWVudUl0ZW0gYXMgSXRlbSB9IGZyb20gXCIuL2l0ZW0vTWVudUl0ZW0ubWpzXCI7XG5leHBvcnQgeyBNZW51TGlua0l0ZW0gYXMgTGlua0l0ZW0gfSBmcm9tIFwiLi9saW5rLWl0ZW0vTWVudUxpbmtJdGVtLm1qc1wiO1xuZXhwb3J0IHsgTWVudVBvcHVwIGFzIFBvcHVwIH0gZnJvbSBcIi4vcG9wdXAvTWVudVBvcHVwLm1qc1wiO1xuZXhwb3J0IHsgTWVudVBvcnRhbCBhcyBQb3J0YWwgfSBmcm9tIFwiLi9wb3J0YWwvTWVudVBvcnRhbC5tanNcIjtcbmV4cG9ydCB7IE1lbnVQb3NpdGlvbmVyIGFzIFBvc2l0aW9uZXIgfSBmcm9tIFwiLi9wb3NpdGlvbmVyL01lbnVQb3NpdGlvbmVyLm1qc1wiO1xuZXhwb3J0IHsgTWVudVJhZGlvR3JvdXAgYXMgUmFkaW9Hcm91cCB9IGZyb20gXCIuL3JhZGlvLWdyb3VwL01lbnVSYWRpb0dyb3VwLm1qc1wiO1xuZXhwb3J0IHsgTWVudVJhZGlvSXRlbSBhcyBSYWRpb0l0ZW0gfSBmcm9tIFwiLi9yYWRpby1pdGVtL01lbnVSYWRpb0l0ZW0ubWpzXCI7XG5leHBvcnQgeyBNZW51UmFkaW9JdGVtSW5kaWNhdG9yIGFzIFJhZGlvSXRlbUluZGljYXRvciB9IGZyb20gXCIuL3JhZGlvLWl0ZW0taW5kaWNhdG9yL01lbnVSYWRpb0l0ZW1JbmRpY2F0b3IubWpzXCI7XG5leHBvcnQgeyBNZW51Um9vdCBhcyBSb290IH0gZnJvbSBcIi4vcm9vdC9NZW51Um9vdC5tanNcIjtcbmV4cG9ydCB7IE1lbnVTdWJtZW51Um9vdCBhcyBTdWJtZW51Um9vdCB9IGZyb20gXCIuL3N1Ym1lbnUtcm9vdC9NZW51U3VibWVudVJvb3QubWpzXCI7XG5leHBvcnQgeyBNZW51VHJpZ2dlciBhcyBUcmlnZ2VyIH0gZnJvbSBcIi4vdHJpZ2dlci9NZW51VHJpZ2dlci5tanNcIjtcbmV4cG9ydCB7IE1lbnVWaWV3cG9ydCBhcyBWaWV3cG9ydCB9IGZyb20gXCIuL3ZpZXdwb3J0L01lbnVWaWV3cG9ydC5tanNcIjtcbmV4cG9ydCB7IFNlcGFyYXRvciB9IGZyb20gXCIuLi9zZXBhcmF0b3IvU2VwYXJhdG9yLm1qc1wiO1xuZXhwb3J0IHsgTWVudVN1Ym1lbnVUcmlnZ2VyIGFzIFN1Ym1lbnVUcmlnZ2VyIH0gZnJvbSBcIi4vc3VibWVudS10cmlnZ2VyL01lbnVTdWJtZW51VHJpZ2dlci5tanNcIjtcbmV4cG9ydCB7IE1lbnVIYW5kbGUgYXMgSGFuZGxlLCBjcmVhdGVNZW51SGFuZGxlIGFzIGNyZWF0ZUhhbmRsZSB9IGZyb20gXCIuL3N0b3JlL01lbnVIYW5kbGUubWpzXCI7XG5cbi8vIEZpbHRlcmluZy4gVGhlIHByb3ZpZGVyIGlzIHRoZSBvbmx5IHBhcnQgdGhhdCBidW5kbGVzIHRoZSBmaWx0ZXIgaW1wbGVtZW50YXRpb24uXG5leHBvcnQgeyBNZW51RmlsdGVyUHJvdmlkZXIgYXMgRmlsdGVyUHJvdmlkZXIgfSBmcm9tIFwiLi9maWx0ZXItcHJvdmlkZXIvTWVudUZpbHRlclByb3ZpZGVyLm1qc1wiO1xuZXhwb3J0IHsgTWVudUlucHV0IGFzIElucHV0IH0gZnJvbSBcIi4vaW5wdXQvTWVudUlucHV0Lm1qc1wiO1xuZXhwb3J0IHsgTWVudUxpc3QgYXMgTGlzdCB9IGZyb20gXCIuL2xpc3QvTWVudUxpc3QubWpzXCI7XG5leHBvcnQgeyBNZW51Q2xlYXIgYXMgQ2xlYXIgfSBmcm9tIFwiLi9jbGVhci9NZW51Q2xlYXIubWpzXCI7XG5leHBvcnQgeyBNZW51RW1wdHkgYXMgRW1wdHkgfSBmcm9tIFwiLi9lbXB0eS9NZW51RW1wdHkubWpzXCI7XG5leHBvcnQgeyBnZXRGaWx0ZXIgYXMgdXNlRmlsdGVyIH0gZnJvbSBcIi4uL2ludGVybmFscy9maWx0ZXIubWpzXCI7IiwiaW1wb3J0IHsgQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIG1lbnUgcG9wdXAgaXMgb3Blbi5cbiAqL1xuZXhwb3J0IGNvbnN0IG9wZW4gPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW47XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgbWVudSBwb3B1cCBpcyBjbG9zZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBjbG9zZWQgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmNsb3NlZDtcbi8qKlxuICogSW5kaWNhdGVzIHdoaWNoIHNpZGUgdGhlIHBvcHVwIGlzIHBvc2l0aW9uZWQgcmVsYXRpdmUgdG8gdGhlIGFuY2hvci5cbiAqIEB0eXBlIHsndG9wJyB8ICdib3R0b20nIHwgJ2xlZnQnIHwgJ3JpZ2h0JyB8ICdpbmxpbmUtZW5kJyB8ICdpbmxpbmUtc3RhcnQnfVxuICovXG5leHBvcnQgY29uc3Qgc2lkZSA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuc2lkZTtcbi8qKlxuICogSW5kaWNhdGVzIGhvdyB0aGUgcG9wdXAgaXMgYWxpZ25lZCByZWxhdGl2ZSB0byBzcGVjaWZpZWQgc2lkZS5cbiAqIEB0eXBlIHsnc3RhcnQnIHwgJ2NlbnRlcicgfCAnZW5kJ31cbiAqL1xuZXhwb3J0IGNvbnN0IGFsaWduID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5hbGlnbjtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBtZW51IGFycm93IGlzIHVuY2VudGVyZWQuXG4gKi9cbmV4cG9ydCBjb25zdCB1bmNlbnRlcmVkID0gJ2RhdGEtdW5jZW50ZXJlZCc7IiwiaW1wb3J0IHsgQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIG1lbnUgaXMgb3Blbi5cbiAqL1xuZXhwb3J0IGNvbnN0IG9wZW4gPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW47XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgbWVudSBpcyBjbG9zZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBjbG9zZWQgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmNsb3NlZDtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBtZW51IGJlZ2lucyBhbmltYXRpbmcgaW4uXG4gKi9cbmV4cG9ydCBjb25zdCBzdGFydGluZ1N0eWxlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zdGFydGluZ1N0eWxlO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIG1lbnUgaXMgYW5pbWF0aW5nIG91dC5cbiAqL1xuZXhwb3J0IGNvbnN0IGVuZGluZ1N0eWxlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5lbmRpbmdTdHlsZTsiLCJpbXBvcnQgeyBUcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMgfSBmcm9tIFwiLi4vLi4vaW50ZXJuYWxzL3N0YXRlQXR0cmlidXRlc01hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBtZW51IGNoZWNrYm94IGl0ZW0gaXMgY2hlY2tlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGNoZWNrZWQgPSAnZGF0YS1jaGVja2VkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBtZW51IGNoZWNrYm94IGl0ZW0gaXMgbm90IGNoZWNrZWQuXG4gKi9cbmV4cG9ydCBjb25zdCB1bmNoZWNrZWQgPSAnZGF0YS11bmNoZWNrZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIG1lbnUgY2hlY2tib3ggaXRlbSBpcyBkaXNhYmxlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGRpc2FibGVkID0gJ2RhdGEtZGlzYWJsZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGluZGljYXRvciBiZWdpbnMgYW5pbWF0aW5nIGluLlxuICovXG5leHBvcnQgY29uc3Qgc3RhcnRpbmdTdHlsZSA9IFRyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcy5zdGFydGluZ1N0eWxlO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGluZGljYXRvciBpcyBhbmltYXRpbmcgb3V0LlxuICovXG5leHBvcnQgY29uc3QgZW5kaW5nU3R5bGUgPSBUcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMuZW5kaW5nU3R5bGU7IiwiLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIG1lbnUgaXRlbSBpcyBoaWdobGlnaHRlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGhpZ2hsaWdodGVkID0gJ2RhdGEtaGlnaGxpZ2h0ZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIG1lbnUgaXRlbSBpcyBkaXNhYmxlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGRpc2FibGVkID0gJ2RhdGEtZGlzYWJsZWQnOyIsIi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBsaW5rIGlzIGhpZ2hsaWdodGVkLlxuICovXG5leHBvcnQgY29uc3QgaGlnaGxpZ2h0ZWQgPSAnZGF0YS1oaWdobGlnaHRlZCc7IiwiaW1wb3J0IHsgQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIG1lbnUgaXMgb3Blbi5cbiAqL1xuZXhwb3J0IGNvbnN0IG9wZW4gPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLm9wZW47XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgbWVudSBpcyBjbG9zZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBjbG9zZWQgPSBDb21tb25Qb3B1cERhdGFBdHRyaWJ1dGVzLmNsb3NlZDtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBtZW51IGJlZ2lucyBhbmltYXRpbmcgaW4uXG4gKi9cbmV4cG9ydCBjb25zdCBzdGFydGluZ1N0eWxlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zdGFydGluZ1N0eWxlO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIG1lbnUgaXMgYW5pbWF0aW5nIG91dC5cbiAqL1xuZXhwb3J0IGNvbnN0IGVuZGluZ1N0eWxlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5lbmRpbmdTdHlsZTtcbi8qKlxuICogSW5kaWNhdGVzIHdoaWNoIHNpZGUgdGhlIHBvcHVwIGlzIHBvc2l0aW9uZWQgcmVsYXRpdmUgdG8gdGhlIGFuY2hvci5cbiAqIEB0eXBlIHsndG9wJyB8ICdib3R0b20nIHwgJ2xlZnQnIHwgJ3JpZ2h0JyB8ICdpbmxpbmUtZW5kJyB8ICdpbmxpbmUtc3RhcnQnfVxuICovXG5leHBvcnQgY29uc3Qgc2lkZSA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuc2lkZTtcbi8qKlxuICogSW5kaWNhdGVzIGhvdyB0aGUgcG9wdXAgaXMgYWxpZ25lZCByZWxhdGl2ZSB0byBzcGVjaWZpZWQgc2lkZS5cbiAqIEB0eXBlIHsnc3RhcnQnIHwgJ2NlbnRlcicgfCAnZW5kJ31cbiAqL1xuZXhwb3J0IGNvbnN0IGFsaWduID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5hbGlnbjtcbi8qKlxuICogUHJlc2VudCBpZiBhbmltYXRpb25zIHNob3VsZCBiZSBpbnN0YW50LlxuICogQHR5cGUgeydjbGljaycgfCAnZGlzbWlzcycgfCAnZ3JvdXAnIHwgJ3RyaWdnZXItY2hhbmdlJ31cbiAqL1xuZXhwb3J0IGNvbnN0IGluc3RhbnQgPSAnZGF0YS1pbnN0YW50JzsiLCIvKipcbiAqIFRoZSBhdmFpbGFibGUgd2lkdGggYmV0d2VlbiB0aGUgYW5jaG9yIGFuZCB0aGUgZWRnZSBvZiB0aGUgdmlld3BvcnQuXG4gKiBAdHlwZSB7bnVtYmVyfVxuICovXG5leHBvcnQgY29uc3QgYXZhaWxhYmxlV2lkdGggPSAnLS1hdmFpbGFibGUtd2lkdGgnO1xuLyoqXG4gKiBUaGUgYXZhaWxhYmxlIGhlaWdodCBiZXR3ZWVuIHRoZSBhbmNob3IgYW5kIHRoZSBlZGdlIG9mIHRoZSB2aWV3cG9ydC5cbiAqIEB0eXBlIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBjb25zdCBhdmFpbGFibGVIZWlnaHQgPSAnLS1hdmFpbGFibGUtaGVpZ2h0Jztcbi8qKlxuICogVGhlIGFuY2hvcidzIHdpZHRoLlxuICogQHR5cGUge251bWJlcn1cbiAqL1xuZXhwb3J0IGNvbnN0IGFuY2hvcldpZHRoID0gJy0tYW5jaG9yLXdpZHRoJztcbi8qKlxuICogVGhlIGFuY2hvcidzIGhlaWdodC5cbiAqIEB0eXBlIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBjb25zdCBhbmNob3JIZWlnaHQgPSAnLS1hbmNob3ItaGVpZ2h0Jztcbi8qKlxuICogVGhlIGNvb3JkaW5hdGVzIHRoYXQgdGhpcyBlbGVtZW50IGlzIGFuY2hvcmVkIHRvLiBVc2VkIGZvciBhbmltYXRpb25zIGFuZCB0cmFuc2l0aW9ucy5cbiAqIEB0eXBlIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBjb25zdCB0cmFuc2Zvcm1PcmlnaW4gPSAnLS10cmFuc2Zvcm0tb3JpZ2luJztcbi8qKlxuICogVGhlIHdpZHRoIG9mIHRoZSBtZW51J3MgcG9zaXRpb25lci5cbiAqIEl0IGlzIGltcG9ydGFudCB0byBzZXQgYHdpZHRoYCB0byB0aGlzIHZhbHVlIHdoZW4gdXNpbmcgQ1NTIHRvIGFuaW1hdGUgc2l6ZSBjaGFuZ2VzLlxuICogQHR5cGUge251bWJlcn1cbiAqL1xuZXhwb3J0IGNvbnN0IHBvc2l0aW9uZXJXaWR0aCA9ICctLXBvc2l0aW9uZXItd2lkdGgnO1xuLyoqXG4gKiBUaGUgaGVpZ2h0IG9mIHRoZSBtZW51J3MgcG9zaXRpb25lci5cbiAqIEl0IGlzIGltcG9ydGFudCB0byBzZXQgYGhlaWdodGAgdG8gdGhpcyB2YWx1ZSB3aGVuIHVzaW5nIENTUyB0byBhbmltYXRlIHNpemUgY2hhbmdlcy5cbiAqIEB0eXBlIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBjb25zdCBwb3NpdGlvbmVySGVpZ2h0ID0gJy0tcG9zaXRpb25lci1oZWlnaHQnOyIsImltcG9ydCB7IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBtZW51IHBvcHVwIGlzIG9wZW4uXG4gKi9cbmV4cG9ydCBjb25zdCBvcGVuID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5vcGVuO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIG1lbnUgcG9wdXAgaXMgY2xvc2VkLlxuICovXG5leHBvcnQgY29uc3QgY2xvc2VkID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5jbG9zZWQ7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgYW5jaG9yIGlzIGhpZGRlbi5cbiAqL1xuZXhwb3J0IGNvbnN0IGFuY2hvckhpZGRlbiA9IENvbW1vblBvcHVwRGF0YUF0dHJpYnV0ZXMuYW5jaG9ySGlkZGVuO1xuLyoqXG4gKiBJbmRpY2F0ZXMgd2hpY2ggc2lkZSB0aGUgcG9wdXAgaXMgcG9zaXRpb25lZCByZWxhdGl2ZSB0byB0aGUgYW5jaG9yLlxuICogQHR5cGUgeyd0b3AnIHwgJ2JvdHRvbScgfCAnbGVmdCcgfCAncmlnaHQnIHwgJ2lubGluZS1lbmQnIHwgJ2lubGluZS1zdGFydCd9XG4gKi9cbmV4cG9ydCBjb25zdCBzaWRlID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5zaWRlO1xuLyoqXG4gKiBJbmRpY2F0ZXMgaG93IHRoZSBwb3B1cCBpcyBhbGlnbmVkIHJlbGF0aXZlIHRvIHRoZSBzcGVjaWZpZWQgc2lkZS5cbiAqIEB0eXBlIHsnc3RhcnQnIHwgJ2NlbnRlcicgfCAnZW5kJ31cbiAqL1xuZXhwb3J0IGNvbnN0IGFsaWduID0gQ29tbW9uUG9wdXBEYXRhQXR0cmlidXRlcy5hbGlnbjsiLCIvKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgbWVudSByYWRpbyBpdGVtIGlzIHNlbGVjdGVkLlxuICovXG5leHBvcnQgY29uc3QgY2hlY2tlZCA9ICdkYXRhLWNoZWNrZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIG1lbnUgcmFkaW8gaXRlbSBpcyBub3Qgc2VsZWN0ZWQuXG4gKi9cbmV4cG9ydCBjb25zdCB1bmNoZWNrZWQgPSAnZGF0YS11bmNoZWNrZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIG1lbnUgcmFkaW8gaXRlbSBpcyBkaXNhYmxlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGRpc2FibGVkID0gJ2RhdGEtZGlzYWJsZWQnO1xuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIG1lbnUgcmFkaW8gaXRlbSBpcyBoaWdobGlnaHRlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGhpZ2hsaWdodGVkID0gJ2RhdGEtaGlnaGxpZ2h0ZWQnOyIsImltcG9ydCB7IFRyYW5zaXRpb25TdGF0dXNEYXRhQXR0cmlidXRlcyB9IGZyb20gXCIuLi8uLi9pbnRlcm5hbHMvc3RhdGVBdHRyaWJ1dGVzTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIG1lbnUgcmFkaW8gaXRlbSBpcyBzZWxlY3RlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGNoZWNrZWQgPSAnZGF0YS1jaGVja2VkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBtZW51IHJhZGlvIGl0ZW0gaXMgbm90IHNlbGVjdGVkLlxuICovXG5leHBvcnQgY29uc3QgdW5jaGVja2VkID0gJ2RhdGEtdW5jaGVja2VkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBtZW51IHJhZGlvIGl0ZW0gaXMgZGlzYWJsZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBkaXNhYmxlZCA9ICdkYXRhLWRpc2FibGVkJztcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSByYWRpbyBpbmRpY2F0b3IgYmVnaW5zIGFuaW1hdGluZyBpbi5cbiAqL1xuZXhwb3J0IGNvbnN0IHN0YXJ0aW5nU3R5bGUgPSBUcmFuc2l0aW9uU3RhdHVzRGF0YUF0dHJpYnV0ZXMuc3RhcnRpbmdTdHlsZTtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSByYWRpbyBpbmRpY2F0b3IgaXMgYW5pbWF0aW5nIG91dC5cbiAqL1xuZXhwb3J0IGNvbnN0IGVuZGluZ1N0eWxlID0gVHJhbnNpdGlvblN0YXR1c0RhdGFBdHRyaWJ1dGVzLmVuZGluZ1N0eWxlOyIsImltcG9ydCB7IENvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcyB9IGZyb20gXCIuLi8uLi91dGlscy9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcblxuLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGNvcnJlc3BvbmRpbmcgbWVudSBpcyBvcGVuLlxuICovXG5leHBvcnQgY29uc3QgcG9wdXBPcGVuID0gQ29tbW9uVHJpZ2dlckRhdGFBdHRyaWJ1dGVzLnBvcHVwT3Blbjtcbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSB0cmlnZ2VyIGlzIHByZXNzZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBwcmVzc2VkID0gQ29tbW9uVHJpZ2dlckRhdGFBdHRyaWJ1dGVzLnByZXNzZWQ7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgdHJpZ2dlciBpcyBkaXNhYmxlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGRpc2FibGVkID0gJ2RhdGEtZGlzYWJsZWQnOyIsIi8qKlxuICogVGhlIHdpZHRoIG9mIHRoZSBwYXJlbnQgcG9wdXAuXG4gKiBUaGlzIHZhcmlhYmxlIGlzIHBsYWNlZCBvbiB0aGUgJ3ByZXZpb3VzJyBjb250YWluZXIgYW5kIHN0b3JlcyB0aGUgd2lkdGggb2YgdGhlIHBvcHVwIHdoZW4gdGhlIHByZXZpb3VzIGNvbnRlbnQgd2FzIHJlbmRlcmVkLlxuICogSXQgY2FuIGJlIHVzZWQgdG8gZnJlZXplIHRoZSBkaW1lbnNpb25zIG9mIHRoZSBwb3B1cCB3aGVuIGFuaW1hdGluZyBiZXR3ZWVuIGRpZmZlcmVudCBjb250ZW50LlxuICovXG5leHBvcnQgY29uc3QgcG9wdXBXaWR0aCA9ICctLXBvcHVwLXdpZHRoJztcbi8qKlxuICogVGhlIGhlaWdodCBvZiB0aGUgcGFyZW50IHBvcHVwLlxuICogVGhpcyB2YXJpYWJsZSBpcyBwbGFjZWQgb24gdGhlICdwcmV2aW91cycgY29udGFpbmVyIGFuZCBzdG9yZXMgdGhlIGhlaWdodCBvZiB0aGUgcG9wdXAgd2hlbiB0aGUgcHJldmlvdXMgY29udGVudCB3YXMgcmVuZGVyZWQuXG4gKiBJdCBjYW4gYmUgdXNlZCB0byBmcmVlemUgdGhlIGRpbWVuc2lvbnMgb2YgdGhlIHBvcHVwIHdoZW4gYW5pbWF0aW5nIGJldHdlZW4gZGlmZmVyZW50IGNvbnRlbnQuXG4gKi9cbmV4cG9ydCBjb25zdCBwb3B1cEhlaWdodCA9ICctLXBvcHVwLWhlaWdodCc7IiwiLyoqXG4gKiBBcHBsaWVkIHRvIHRoZSBkaXJlY3QgY2hpbGQgb2YgdGhlIHZpZXdwb3J0IHdoZW4gbm8gdHJhbnNpdGlvbnMgYXJlIHByZXNlbnQgb3IgdGhlIG5ldyBjb250ZW50IHdoZW4gaXQncyBlbnRlcmluZy5cbiAqL1xuZXhwb3J0IGNvbnN0IGN1cnJlbnQgPSAnZGF0YS1jdXJyZW50Jztcbi8qKlxuICogQXBwbGllZCB0byB0aGUgZGlyZWN0IGNoaWxkIG9mIHRoZSB2aWV3cG9ydCB0aGF0IGNvbnRhaW5zIHRoZSBleGl0aW5nIGNvbnRlbnQgd2hlbiB0cmFuc2l0aW9ucyBhcmUgcHJlc2VudC5cbiAqL1xuZXhwb3J0IGNvbnN0IHByZXZpb3VzID0gJ2RhdGEtcHJldmlvdXMnO1xuLyoqXG4gKiBJbmRpY2F0ZXMgdGhlIGRpcmVjdGlvbiBmcm9tIHdoaWNoIHRoZSBwb3B1cCB3YXMgYWN0aXZhdGVkLlxuICogVGhpcyBjYW4gYmUgdXNlZCB0byBjcmVhdGUgZGlyZWN0aW9uYWwgYW5pbWF0aW9ucyBiYXNlZCBvbiBob3cgdGhlIHBvcHVwIHdhcyB0cmlnZ2VyZWQuXG4gKiBDb250YWlucyBzcGFjZS1zZXBhcmF0ZWQgdmFsdWVzIGZvciBib3RoIGhvcml6b250YWwgYW5kIHZlcnRpY2FsIGF4ZXMuXG4gKiBAdHlwZSB7YCR7J2xlZnQnIHwgJ3JpZ2h0JyB8ICcnfSAkeydkb3duJyB8ICd1cCcgfCAnJ31gfVxuICovXG5leHBvcnQgY29uc3QgYWN0aXZhdGlvbkRpcmVjdGlvbiA9ICdkYXRhLWFjdGl2YXRpb24tZGlyZWN0aW9uJztcbi8qKlxuICogSW5kaWNhdGVzIHRoYXQgdGhlIHZpZXdwb3J0IGlzIGN1cnJlbnRseSB0cmFuc2l0aW9uaW5nIGJldHdlZW4gb2xkIGFuZCBuZXcgY29udGVudC5cbiAqL1xuZXhwb3J0IGNvbnN0IHRyYW5zaXRpb25pbmcgPSAnZGF0YS10cmFuc2l0aW9uaW5nJztcbi8qKlxuICogUHJlc2VudCBpZiBhbmltYXRpb25zIHNob3VsZCBiZSBpbnN0YW50LlxuICogQHR5cGUgeydjbGljaycgfCAnZGlzbWlzcycgfCAnZ3JvdXAnIHwgJ3RyaWdnZXItY2hhbmdlJ31cbiAqL1xuZXhwb3J0IGNvbnN0IGluc3RhbnQgPSAnZGF0YS1pbnN0YW50JzsiLCJpbXBvcnQgeyBDb21tb25UcmlnZ2VyRGF0YUF0dHJpYnV0ZXMgfSBmcm9tIFwiLi4vLi4vdXRpbHMvcG9wdXBTdGF0ZU1hcHBpbmcubWpzXCI7XG5cbi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBjb3JyZXNwb25kaW5nIHN1Ym1lbnUgaXMgb3Blbi5cbiAqL1xuZXhwb3J0IGNvbnN0IHBvcHVwT3BlbiA9IENvbW1vblRyaWdnZXJEYXRhQXR0cmlidXRlcy5wb3B1cE9wZW47XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgc3VibWVudSB0cmlnZ2VyIGlzIGhpZ2hsaWdodGVkLlxuICovXG5leHBvcnQgY29uc3QgaGlnaGxpZ2h0ZWQgPSAnZGF0YS1oaWdobGlnaHRlZCc7XG4vKipcbiAqIFByZXNlbnQgd2hlbiB0aGUgc3VibWVudSB0cmlnZ2VyIGlzIGRpc2FibGVkLlxuICovXG5leHBvcnQgY29uc3QgZGlzYWJsZWQgPSAnZGF0YS1kaXNhYmxlZCc7IiwiLyoqXG4gKiBQcmVzZW50IHdoaWxlIHRoZSBpbnB1dCBzaG93cyBpdHMgZm9jdXMgcmluZy5cbiAqIENsZWFyZWQgd2hlbiBrZXlib2FyZCBuYXZpZ2F0aW9uIGhpZ2hsaWdodHMgYW4gaXRlbS5cbiAqL1xuZXhwb3J0IGNvbnN0IGhpZ2hsaWdodGVkID0gJ2RhdGEtaGlnaGxpZ2h0ZWQnOyIsIi8qKlxuICogUHJlc2VudCB3aGVuIHRoZSBidXR0b24gaXMgZGlzYWJsZWQuXG4gKi9cbmV4cG9ydCBjb25zdCBkaXNhYmxlZCA9ICdkYXRhLWRpc2FibGVkJzsiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUlBLElBQWEsd0JBQXFDLDJCQUFNLGNBQWMsS0FBQSxDQUFTO0FBQ3BDLHNCQUFzQixjQUFjO0FBQy9FLFNBQWdCLHlCQUF5QixVQUFVO0NBQ2pELE1BQU0sVUFBQSxhQUFnQixXQUFXLHFCQUFxQjtDQUN0RCxJQUFJLFlBQVksS0FBQSxLQUFhLENBQUMsVUFDNUIsTUFBTSxJQUFJLE1BQThDLDBHQUFvSTtDQUU5TCxPQUFPO0FBQ1Q7O0FDUkEsSUFBYSxrQkFBK0IsMkJBQU0sY0FBYyxLQUFBLENBQVM7QUFDOUIsZ0JBQWdCLGNBQWM7QUFDekUsU0FBZ0IsbUJBQW1CLFVBQVU7Q0FDM0MsTUFBTSxVQUFBLGFBQWdCLFdBQVcsZUFBZTtDQUNoRCxJQUFJLFlBQVksS0FBQSxLQUFhLENBQUMsVUFDNUIsTUFBTSxJQUFJLE1BQThDLG9GQUE4RztDQUV4SyxPQUFPO0FBQ1Q7Ozs7Ozs7O0FDRUEsSUFBYSxZQUF5QiwyQkFBTSxXQUFXLFNBQVMsVUFBVSxnQkFBZ0IsY0FBYztDQUN0RyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sRUFDSixVQUNFLG1CQUFtQjtDQUN2QixNQUFNLEVBQ0osVUFDQSxNQUNBLE9BQ0EsaUJBQ0EsZ0JBQ0UseUJBQXlCO0NBRTdCLE1BQU0sUUFBUTtFQUNaLE1BRlcsTUFBTSxTQUFTLE1BRXZCO0VBQ0g7RUFDQTtFQUNBLFlBQVk7Q0FDZDtDQUNBLE9BQU8saUJBQWlCLE9BQU8sZ0JBQWdCO0VBQzdDLEtBQUssQ0FBQyxVQUFVLFlBQVk7RUFDNUIsd0JBQXdCO0VBQ3hCO0VBQ0EsT0FBTztHQUNMLE9BQU87R0FDUCxlQUFlO0dBQ2YsR0FBRztFQUNMO0NBQ0YsQ0FBQztBQUNILENBQUM7QUFDMEMsVUFBVSxjQUFjOztBQzdDbkUsSUFBYSx5QkFBc0MsMkJBQU0sY0FBYyxLQUFBLENBQVM7QUFDckMsdUJBQXVCLGNBQWM7QUFDaEYsU0FBZ0IsMEJBQTBCLFdBQVcsTUFBTTtDQUN6RCxNQUFNLFVBQUEsYUFBZ0IsV0FBVyxzQkFBc0I7Q0FDdkQsSUFBSSxZQUFZLEtBQUEsS0FBYSxDQUFDLFVBQzVCLE1BQU0sSUFBSSxNQUE4Qyx5R0FBbUk7Q0FFN0wsT0FBTztBQUNUOzs7Ozs7OztBQ0dBLElBQWEsZUFBNEIsMkJBQU0sV0FBVyxTQUFTLGFBQWEsZ0JBQWdCLGNBQWM7Q0FDNUcsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLEVBQ0osVUFDRSxtQkFBbUI7Q0FDdkIsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sVUFBVSxNQUFNLFNBQVMsU0FBUztDQUN4QyxNQUFNLG1CQUFtQixNQUFNLFNBQVMsa0JBQWtCO0NBQzFELE1BQU0sdUJBQXVCLE1BQU0sU0FBUyxzQkFBc0I7Q0FDbEUsTUFBTSxxQkFBcUIsMEJBQTBCO0NBQ3JELE1BQU0sUUFBUTtFQUNaO0VBQ0E7Q0FDRjtDQUNBLE9BQU8saUJBQWlCLE9BQU8sZ0JBQWdCO0VBQzdDLEtBQUssb0JBQW9CLGNBQWMsQ0FBQyxjQUFjLG1CQUFtQixXQUFXLElBQUk7RUFDeEY7RUFDQSx3QkFBd0I7RUFDeEIsT0FBTyxDQUFDO0dBQ04sTUFBTTtHQUNOLFFBQVEsQ0FBQztHQUNULE9BQU87SUFDTCxlQUFlLHlCQUF5QixrQkFBdUIsU0FBUyxLQUFBO0lBQ3hFLFlBQVk7SUFDWixrQkFBa0I7R0FDcEI7RUFDRixHQUFHLFlBQVk7Q0FDakIsQ0FBQztBQUNILENBQUM7QUFDMEMsYUFBYSxjQUFjOzs7Ozs7Ozs7QUNsQ3RFLElBQWEsd0JBQXFDLDJCQUFNLGNBQWMsSUFBSTtBQUMvQixzQkFBc0IsY0FBYzs7Ozs7O0FBTS9FLFNBQWdCLGtCQUFrQixRQUFRLFFBQVE7Q0FDaEQsTUFBTSxPQUFBLGFBQWEsV0FBVyxxQkFBcUI7Q0FDbkQsTUFBTSxPQUFBLGFBQWEsV0FBVyxlQUFlO0NBQzdDLElBQUksU0FBUyxRQUFRLFNBQVMsS0FBQSxHQUM1QixPQUFPO0NBR1QsUUFEbUIsVUFBVSxvQkFBb0IsS0FBSyxnQkFBZ0IsS0FBSyxxQkFBcUIsS0FBSyxnQkFDakYsT0FBTztBQUM3Qjs7OztBQUtBLFNBQWdCLGtCQUFrQixNQUFNO0NBQ3RDLElBQUksa0JBQWtCLE1BQU0sTUFDMUIsTUFBTSxJQUFJLE1BQThDLGtCQUFrQixLQUFLLDhTQUE4VjtBQUVqYjtBQUNBLElBQU0sYUFBYTtDQUNqQixTQUFTO0NBQ1QsS0FBSztBQUNQO0FBQ0EsU0FBUyxvQkFBb0I7Q0FDM0IsT0FBTztBQUNUOzs7OztBQU1BLFNBQWdCLGtCQUFrQixPQUFPLGNBQWMsUUFBUSxRQUFRO0NBQ3JFLE1BQU0sT0FBTyxrQkFBa0IsS0FBSztDQUVwQyxNQUFNLFNBRFcsVUFBVSxvQkFBb0IsTUFBTSxvQkFBb0IsTUFBTSxZQUFZLGtCQUFBLENBQ3RFO0VBQ25CLE9BQU8sTUFBTTtFQUNiLFVBQVUsTUFBTTtFQUNoQixRQUFRLE1BQU07Q0FDaEIsQ0FBQztDQUNELE1BQU0sTUFBTSxjQUFjLGNBQWMsS0FBSyxHQUFHO0NBQ2hELE9BQU87RUFDTCxTQUFTLEtBQUs7RUFDZDtFQUNBLE9BQU8sS0FBSztDQUNkO0FBQ0Y7O0FDOURBLElBQWEsMEJBQXVDLDJCQUFNLGNBQWMsS0FBQSxDQUFTO0FBQ3RDLHdCQUF3QixjQUFjO0FBQ2pGLFNBQWdCLDZCQUE2QjtDQUMzQyxNQUFNLFVBQUEsYUFBZ0IsV0FBVyx1QkFBdUI7Q0FDeEQsSUFBSSxZQUFZLEtBQUEsR0FDZCxNQUFNLElBQUksTUFBOEMsZ0hBQTBJO0NBRXBNLE9BQU87QUFDVDs7QUNKQSxTQUFTLHdCQUF3QixPQUFPO0NBQ3RDLE1BQU0sZUFBZTtBQUN2Qjs7Ozs7QUFLQSxTQUFnQix1QkFBdUIsUUFBUTtDQUM3QyxNQUFNLEVBQ0osY0FDQSxhQUNBLElBQ0EsUUFDQSxPQUNBLFdBQ0EsU0FDQSxpQkFDRTtDQUNKLE1BQU0sY0FBYyxtQkFBbUI7Q0FDdkMsTUFBTSxxQkFBcUIsMEJBQTBCLElBQUk7Q0FHekQsTUFBTSxtQkFBbUIsYUFBYSxTQUFTO0NBQy9DLE1BQU0sZUFBZSxtQkFBbUIsWUFBWSxxQkFBcUIsWUFBWTtDQUVyRixNQUFNLGdCQURpQixvQkFBb0IsWUFBWSxPQUFPLFNBQVMsU0FBUyxZQUFZLE9BQU8sUUFBUSxZQUFZLE1BQUEsQ0FDbkYsU0FBUyxzQkFBc0IsV0FBVztDQUM5RSxNQUFNLEVBQ0osUUFBUSxlQUNOLE1BQU0sU0FBUyxrQkFBa0I7Q0FDckMsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sZ0JBQWdCLHVCQUF1QixLQUFBO0NBRTdDLE1BQU0sV0FBVyxDQUFDLGdCQUFnQixRQUFRLGNBQWMsSUFBSTtDQUM1RCxPQUFBLGFBQWEsZUFBZTtFQUMxQjtFQUNBLE1BQU07RUFDTjtFQUNBLGlCQUFpQjtFQUVqQixhQUFhLGVBQWUsMEJBQTBCLEtBQUE7RUFDdEQsVUFBVSxPQUFPO0dBQ2YsSUFBSSxNQUFNLFFBQVEsT0FBTyxXQUFXLFNBQ2xDLE1BQU0sZUFBZTtFQUV6QjtFQUNBLFlBQVksT0FBTztHQUNqQixJQUFJLENBQUMsUUFDSDtHQUtGLFdBQVcsS0FBSyxhQUFhO0lBQzNCO0lBQ0EsUUFBUSxNQUFNO0dBQ2hCLENBQUM7RUFDSDtFQUNBLFFBQVEsT0FBTztHQUNiLElBQUksY0FDRixXQUFXLEtBQUssU0FBUztJQUN2QixVQUFVLE1BQU07SUFDaEIsUUFBUUE7R0FDVixDQUFDO0VBRUw7RUFDQSxVQUFVLE9BQU87R0FDZixJQUFJLG9CQUFvQjtJQUN0QixNQUFNLHFCQUFxQixtQkFBbUIsc0JBQXNCO0lBQ3BFLG1CQUFtQixzQkFBc0IsVUFBVTtJQUNuRCxJQUFJLGlCQUFpQixzQkFBc0IsS0FBSyxJQUFJLE1BQU0sVUFBVSxtQkFBbUIsQ0FBQyxLQUFLLEtBQUssS0FBSyxJQUFJLE1BQU0sVUFBVSxtQkFBbUIsQ0FBQyxLQUFLLEdBQ2xKO0lBS0YsSUFBSSxpQkFBaUIsQ0FBQ0MsT0FBbUIsTUFBTSxXQUFXLEdBQ3hEO0dBRUo7R0FDQSxJQUFJLFFBQVEsV0FBVyxNQUFNLFFBQVEsdUJBQXVCLFlBQVksQ0FBQyxpQkFBaUIsTUFBTSxXQUFXLElBR3JHO1FBQUEsYUFBYSxTQUFTLGdCQUd4QiwyQkFBMkIsUUFBUSxTQUFTLE9BQU87S0FDakQsUUFBUTtLQUNSLGFBQWE7SUFDZixDQUFDO0dBQUE7RUFHUDtDQUNGLElBQUk7RUFBQztFQUFjO0VBQVU7RUFBSTtFQUFZO0VBQVEsTUFBTSxRQUFRO0VBQXdCO0VBQVc7RUFBUztFQUFvQjtFQUFlLGFBQWE7RUFBTTtFQUFjO0NBQVksQ0FBQztBQUNsTTs7QUM5RkEsSUFBYSxlQUFlLEVBQzFCLE1BQU0sZUFDUjtBQUNBLFNBQWdCLFlBQVksUUFBUTtDQUNsQyxNQUFNLEVBQ0osY0FDQSxVQUNBLGFBQ0EsSUFDQSxPQUNBLFlBQVksTUFBTSxRQUFRLFdBQzFCLGNBQ0EsY0FDQSxXQUNFO0NBQ0osTUFBTSxVQUFBLGFBQWdCLE9BQU8sSUFBSTtDQUNqQyxNQUFNLEVBQ0osZ0JBQ0EsY0FDRSxVQUFVO0VBQ1o7RUFDQSx1QkFBdUI7RUFDdkIsUUFBUTtFQUNSLFdBQVc7Q0FDYixDQUFDO0NBQ0QsTUFBTSxjQUFjLHVCQUF1QjtFQUN6QztFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsQ0FBQztDQUNELE1BQU0sZUFBQSxhQUFxQixhQUFZLGtCQUFpQjtFQUN0RCxPQUFPLFdBQVcsYUFBYSxFQUM3QixhQUFhLE9BQU87R0FDbEIsSUFBSSxhQUFhLFNBQVMsbUJBQ3hCO0dBRUYsYUFBYSxVQUFVLE1BQU0sV0FBVztFQUMxQyxFQUNGLEdBQUcsZUFBZSxjQUFjO0NBQ2xDLEdBQUc7RUFBQztFQUFhO0VBQWdCO0NBQVksQ0FBQztDQUM5QyxNQUFNLFlBQVksY0FBYyxTQUFTLFNBQVM7Q0FDbEQsT0FBQSxhQUFhLGVBQWU7RUFDMUI7RUFDQSxTQUFTO0NBQ1gsSUFBSSxDQUFDLGNBQWMsU0FBUyxDQUFDO0FBQy9COzs7Ozs7Ozs7OztBQ3REQSxJQUFhQyxZQUFVOzs7O0FBSXZCLElBQWFDLGNBQVk7Ozs7QUFJekIsSUFBYUMsYUFBVzs7OztBQUl4QixJQUFhQyxnQkFBYzs7QUNiM0IsSUFBYSxjQUFjO0NBQ3pCLFFBQVEsT0FBTztFQUNiLElBQUksT0FDRixPQUFPLEdBQ0pDLFlBQXlDLEdBQzVDO0VBRUYsT0FBTyxHQUNKQyxjQUEyQyxHQUM5QztDQUNGO0NBQ0EsR0FBRztBQUNMOzs7QUNFQSxJQUFNLHdCQUFxQywyQkFBTSxXQUFXLFNBQVMsc0JBQXNCLGdCQUFnQixjQUFjO0NBQ3ZILE1BQU0sRUFDSixRQUNBLFdBQ0EsSUFBSSxRQUNKLE9BQ0EsZUFBZSxPQUNmLFVBQVUsZUFBZSxPQUN6QixlQUFlLE9BQ2YsVUFBVSxPQUNWLGlCQUNBLE9BQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sRUFDSixVQUNFLG1CQUFtQjtDQUN2QixNQUFNLFdBQVcscUJBQXFCO0VBQ3BDLE9BQU87RUFDUDtDQUNGLENBQUM7Q0FDRCxNQUFNLEtBQUssWUFBWSxNQUFNO0NBQzdCLE1BQU0sZUFBZSxNQUFNLFNBQVMsVUFBVTtDQUM5QyxNQUFNLGNBQWMsTUFBTSxTQUFTLFlBQVksU0FBUyxLQUFLO0NBQzdELE1BQU0sU0FBUyxNQUFNLFNBQVMsZ0JBQWdCO0NBQzlDLE1BQU0sWUFBWSxNQUFNLFNBQVMsV0FBVztDQUM1QyxNQUFNLFdBQVcsZ0JBQWdCO0NBQ2pDLE1BQU0sRUFDSixjQUNBLFlBQ0UsWUFBWTtFQUNkO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsY0FBYztDQUNoQixDQUFDO0NBQ0QsTUFBTSxRQUFBLGFBQWMsZUFBZTtFQUNqQztFQUNBO0VBQ0E7Q0FDRixJQUFJO0VBQUM7RUFBVTtFQUFhO0NBQU8sQ0FBQztDQUNwQyxTQUFTLFlBQVksT0FBTztFQUMxQixNQUFNLFVBQVUseUJBQXlCQyxXQUFtQixNQUFNLGFBQWEsS0FBQSxHQUFXLEVBQ3hGLHVCQUF1QixLQUN6QixDQUFDO0VBQ0Qsa0JBQWtCLENBQUMsU0FBUyxPQUFPO0NBQ3JDO0NBQ0EsTUFBTSxVQUFVLGlCQUFpQixPQUFPLGdCQUFnQjtFQUN0RDtFQUNBLHdCQUF3QjtFQUN4QixPQUFPO0dBQUM7R0FBVztJQUNqQixNQUFNO0lBQ04sZ0JBQWdCO0lBQ2hCLFNBQVM7R0FDWDtHQUFHO0dBQWM7RUFBWTtFQUM3QixLQUFLO0dBQUM7R0FBUztHQUFjLFNBQVM7RUFBRztDQUMzQyxDQUFDO0NBQ0QsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyx3QkFBd0IsVUFBVTtFQUN6RCxPQUFPO0VBQ1AsVUFBVTtDQUNaLENBQUM7QUFDSCxDQUFDO0FBUTBDLHNCQUFzQixjQUFjO0FBQy9FLElBQWEsbUJBQWdDLDJCQUFNLFdBQVcsU0FBUyxpQkFBaUIsT0FBTyxjQUFjO0NBQzNHLE1BQU0sRUFDSixTQUFTLGFBQ1QsZ0JBQ0EsaUJBQ0EsR0FBRyxlQUNEO0NBR0osTUFBTSxDQUFDLFNBQVMsY0FBYyxjQUFjO0VBQzFDLFlBQVk7RUFDWixTQUFTLGtCQUFrQjtFQUMzQixNQUFNO0VBQ04sT0FBTztDQUNULENBQUM7Q0FDRCxNQUFNLGFBQWEsa0JBQWtCLE9BQU8sWUFBWTtDQUN4RCxTQUFTLG9CQUFvQixhQUFhLGNBQWM7RUFDdEQsa0JBQWtCLGFBQWEsWUFBWTtFQUMzQyxJQUFJLENBQUMsYUFBYSxZQUNoQixXQUFXLFdBQVc7Q0FFMUI7Q0FDQSxJQUFJLENBQUMsV0FBVyxTQUNkLE9BQU87Q0FFVCxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLHVCQUF1QjtFQUM5QyxHQUFHO0VBQ007RUFDVCxpQkFBaUI7RUFDakIsS0FBSyxXQUFXO0NBQ2xCLENBQUM7QUFDSCxDQUFDO0FBQzBDLGlCQUFpQixjQUFjOzs7Ozs7OztBQzNHMUUsSUFBYSw0QkFBeUMsMkJBQU0sV0FBVyxTQUFTLDBCQUEwQixnQkFBZ0IsY0FBYztDQUN0SSxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsY0FBYyxPQUNkLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLE9BQU8sMkJBQTJCO0NBQ3hDLE1BQU0sZUFBQSxhQUFxQixPQUFPLElBQUk7Q0FDdEMsTUFBTSxFQUNKLGtCQUNBLFNBQ0EsZUFDRSxvQkFBb0IsS0FBSyxPQUFPO0NBQ3BDLHNCQUFzQjtFQUNwQixPQUFPO0VBQ1AsU0FBUyxDQUFDLEtBQUs7RUFDZixNQUFNLEtBQUs7RUFDWCxLQUFLO0VBQ0wsYUFBYTtHQUNYLElBQUksQ0FBQyxLQUFLLFNBQ1IsV0FBVyxLQUFLO0VBRXBCO0NBQ0YsQ0FBQztDQUNELE1BQU0sUUFBUTtFQUNaLFNBQVMsS0FBSztFQUNkLFVBQVUsS0FBSztFQUNmLGFBQWEsS0FBSztFQUNsQjtDQUNGO0NBV0EsT0FWZ0IsaUJBQWlCLFFBQVEsZ0JBQWdCO0VBQ3ZEO0VBQ0EsS0FBSyxDQUFDLGNBQWMsWUFBWTtFQUNoQyx3QkFBd0I7RUFDeEIsT0FBTztHQUNMLGVBQWU7R0FDZixHQUFHO0VBQ0w7RUFDQSxTQUFTLGVBQWU7Q0FDMUIsQ0FDYTtBQUNmLENBQUM7QUFDMEMsMEJBQTBCLGNBQWM7O0FDdkRuRixJQUFhLG1CQUFnQywyQkFBTSxjQUFjLEtBQUEsQ0FBUztBQUMvQixpQkFBaUIsY0FBYztBQUMxRSxTQUFnQiwwQkFBMEI7Q0FDeEMsTUFBTSxVQUFBLGFBQWdCLFdBQVcsZ0JBQWdCO0NBQ2pELElBQUksWUFBWSxLQUFBLEdBQ2QsTUFBTSxJQUFJLE1BQThDLCtHQUF5STtDQUVuTSxPQUFPO0FBQ1Q7Ozs7O0FDREEsSUFBYSxpQkFBOEIsMkJBQU0sV0FBVyxTQUFTLGVBQWUsZ0JBQWdCLGNBQWM7Q0FDaEgsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLENBQUMsU0FBUyxjQUFBLGFBQW9CLFNBQVMsS0FBQSxDQUFTO0NBQ3RELE1BQU0sVUFBVSxpQkFBaUIsT0FBTyxnQkFBZ0I7RUFDdEQsS0FBSztFQUNMLE9BQU87R0FDTCxNQUFNO0dBQ04sbUJBQW1CO0dBQ25CLEdBQUc7RUFDTDtDQUNGLENBQUM7Q0FDRCxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGlCQUFpQixVQUFVO0VBQ2xELE9BQU87RUFDUCxVQUFVO0NBQ1osQ0FBQztBQUNILENBQUM7QUFRMEMsZUFBZSxjQUFjO0FBQ3hFLElBQWEsWUFBeUIsMkJBQU0sV0FBVyxTQUFTLFVBQVUsT0FBTyxjQUFjO0NBQzdGLE1BQU0sUUFBUSxrQkFBa0IsQ0FBQyxFQUFFLFNBQVM7Q0FDNUMsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxPQUFPO0VBQzlCLEdBQUc7RUFDSCxLQUFLO0NBQ1AsQ0FBQztBQUNILENBQUM7QUFDMEMsVUFBVSxjQUFjOzs7Ozs7OztBQ2pDbkUsSUFBYSxpQkFBOEIsMkJBQU0sV0FBVyxTQUFTLGVBQWUsZ0JBQWdCLGNBQWM7Q0FDaEgsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLElBQUksUUFDSixHQUFHLGlCQUNEO0NBQ0osTUFBTSxLQUFLLFlBQVksTUFBTTtDQUM3QixNQUFNLGFBQWEsd0JBQXdCO0NBQzNDLHlCQUF5QjtFQUN2QixXQUFXLEVBQUU7RUFDYixhQUFhO0dBQ1gsWUFBVyxjQUFhLGNBQWMsS0FBSyxLQUFBLElBQVksU0FBUztFQUNsRTtDQUNGLEdBQUcsQ0FBQyxZQUFZLEVBQUUsQ0FBQztDQUNuQixPQUFPLGlCQUFpQixPQUFPLGdCQUFnQjtFQUM3QyxLQUFLO0VBQ0wsT0FBTztHQUNMO0dBQ0EsZUFBZTtHQUNmLEdBQUc7RUFDTDtDQUNGLENBQUM7QUFDSCxDQUFDO0FBQzBDLGVBQWUsY0FBYzs7QUM3QnhFLElBQU0sZ0JBQTZCLDJCQUFNLFdBQVcsU0FBUyxjQUFjLGdCQUFnQixjQUFjO0NBQ3ZHLE1BQU0sRUFDSixRQUNBLFdBQ0EsSUFBSSxRQUNKLE9BQ0EsZUFBZSxPQUNmLFVBQVUsZUFBZSxPQUN6QixlQUFlLE1BQ2YsT0FDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxFQUNKLFVBQ0UsbUJBQW1CO0NBQ3ZCLE1BQU0sV0FBVyxxQkFBcUI7RUFDcEMsT0FBTztFQUNQO0NBQ0YsQ0FBQztDQUNELE1BQU0sS0FBSyxZQUFZLE1BQU07Q0FDN0IsTUFBTSxlQUFlLE1BQU0sU0FBUyxVQUFVO0NBQzlDLE1BQU0sY0FBYyxNQUFNLFNBQVMsWUFBWSxTQUFTLEtBQUs7Q0FDN0QsTUFBTSxTQUFTLE1BQU0sU0FBUyxnQkFBZ0I7Q0FDOUMsTUFBTSxZQUFZLE1BQU0sU0FBUyxXQUFXO0NBQzVDLE1BQU0sV0FBVyxnQkFBZ0I7Q0FDakMsTUFBTSxFQUNKLGNBQ0EsWUFDRSxZQUFZO0VBQ2Q7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxjQUFjO0NBQ2hCLENBQUM7Q0FLRCxPQUFPLGlCQUFpQixPQUFPLGdCQUFnQjtFQUM3QyxPQUFBO0dBSkE7R0FDQTtFQUdJO0VBQ0osT0FBTztHQUFDO0dBQVc7R0FBYztFQUFZO0VBQzdDLEtBQUs7R0FBQztHQUFTO0dBQWMsU0FBUztFQUFHO0NBQzNDLENBQUM7QUFDSCxDQUFDO0FBUTBDLGNBQWMsY0FBYztBQUN2RSxJQUFhLFdBQXdCLDJCQUFNLFdBQVcsU0FBUyxTQUFTLE9BQU8sY0FBYztDQUMzRixNQUFNLGFBQWEsa0JBQWtCLE9BQU8sWUFBWTtDQUN4RCxJQUFJLENBQUMsV0FBVyxTQUNkLE9BQU87Q0FFVCxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGVBQWU7RUFDdEMsR0FBRztFQUNILEtBQUssV0FBVztDQUNsQixDQUFDO0FBQ0gsQ0FBQztBQUMwQyxTQUFTLGNBQWM7O0FDL0RsRSxJQUFNLG9CQUFpQywyQkFBTSxXQUFXLFNBQVMsa0JBQWtCLGdCQUFnQixjQUFjO0NBQy9HLE1BQU0sRUFDSixRQUNBLFdBQ0EsSUFBSSxRQUNKLE9BQ0EsZUFBZSxPQUNmLE9BQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sRUFDSixVQUNFLG1CQUFtQjtDQUN2QixNQUFNLFVBQUEsYUFBZ0IsT0FBTyxJQUFJO0NBQ2pDLE1BQU0sV0FBVyxxQkFBcUI7RUFDcEMsT0FBTztFQUNQO0NBQ0YsQ0FBQztDQUNELE1BQU0sS0FBSyxZQUFZLE1BQU07Q0FDN0IsTUFBTSxjQUFjLE1BQU0sU0FBUyxZQUFZLFNBQVMsS0FBSztDQUM3RCxNQUFNLFNBQVMsTUFBTSxTQUFTLGdCQUFnQjtDQUM5QyxNQUFNLFlBQVksTUFBTSxTQUFTLFdBQVc7Q0FDNUMsTUFBTSxZQUFZLE1BQU0sUUFBUTtDQUNoQyxNQUFNLEVBQ0osZ0JBQ0EsY0FDRSxVQUFVO0VBQ1osUUFBUTtFQUNSLFdBQVc7Q0FDYixDQUFDO0NBQ0QsTUFBTSxjQUFjLHVCQUF1QjtFQUN6QztFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxTQUFTO0VBQ1QsY0FBYztDQUNoQixDQUFDO0NBQ0QsU0FBUyxhQUFhLGVBQWU7RUFDbkMsT0FBTyxXQUFXLGFBQWEsZUFBZSxjQUFjO0NBQzlEO0NBSUEsT0FBTyxpQkFBaUIsS0FBSyxnQkFBZ0I7RUFDM0MsT0FBQSxFQUhBLFlBR0k7RUFDSixPQUFPO0dBQUM7R0FBVztHQUFjO0VBQVk7RUFDN0MsS0FBSztHQUFDO0dBQVM7R0FBVztHQUFjLFNBQVM7RUFBRztDQUN0RCxDQUFDO0FBQ0gsQ0FBQztBQVEwQyxrQkFBa0IsY0FBYztBQUMzRSxJQUFhLGVBQTRCLDJCQUFNLFdBQVcsU0FBUyxhQUFhLE9BQU8sY0FBYztDQUVuRyxNQUFNLGFBQWEsa0JBQWtCLE9BQU8sWUFBWTtDQUN4RCxJQUFJLENBQUMsV0FBVyxTQUNkLE9BQU87Q0FFVCxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLG1CQUFtQjtFQUMxQyxHQUFHO0VBQ0gsS0FBSyxXQUFXO0NBQ2xCLENBQUM7QUFDSCxDQUFDO0FBQzBDLGFBQWEsY0FBYzs7QUNqRnRFLElBQWEseUJBQXNDLDJCQUFNLGNBQWMsS0FBQSxDQUFTO0FBQ3JDLHVCQUF1QixjQUFjO0FBQ2hGLFNBQWdCLDRCQUE0QjtDQUMxQyxPQUFBLGFBQWEsV0FBVyxzQkFBc0I7QUFDaEQ7Ozs7Ozs7Ozs7O0FDSUEsU0FBZ0Isa0JBQWtCLE9BQU8sWUFBWTtDQUNuRCxNQUFNLFNBQVMscUJBQXFCLE1BQU0sTUFBTTtDQUNoRCxJQUFpQiwyQkFBTSxlQUFlLE1BQU0sR0FBRztFQUM3QyxNQUFNLGNBQWMsT0FBTztFQUMzQixJQUFJLE9BQU8sT0FBTyxhQUFhLElBQUksR0FDakMsT0FBTyxZQUFZLE1BQU07Q0FFN0I7Q0FDQSxPQUFPLE1BQU0sTUFBTTtBQUNyQjs7Ozs7Ozs7QUFTQSxTQUFnQixjQUFjLE9BQU8sV0FBVyxPQUFPO0NBQ3JELE1BQU0sS0FBSyxrQkFBa0IsT0FBTyxTQUFTO0NBQzdDLE1BQU0sZUFBZSxPQUFPLFlBQVksS0FBQSxJQUFZO0NBRXBELE9BQU8sQ0FBQyxJQUFBLGFBRFUsYUFBWSxZQUFXLFFBQVEsVUFBVSxlQUFlLEtBQUEsQ0FBUyxHQUFHLENBQUMsY0FBYyxLQUFLLENBQzVGLENBQUM7QUFDakI7O0FDaENBLFNBQWdCLGtCQUFrQixPQUFPLHNCQUFzQixpQkFBaUI7Q0FDOUUsTUFBTSxTQUFTLHFCQUFxQixNQUFNLE1BQU07Q0FDaEQsTUFBTSx1QkFBb0MsMkJBQU0sZUFBZSxNQUFNLElBQUksT0FBTyxRQUFRLEtBQUE7Q0FDeEYsTUFBTSxZQUFZLE1BQU0saUJBQWlCLHVCQUF1QjtDQUNoRSxJQUFJLGlCQUFpQixNQUFNLHNCQUFzQix1QkFBdUI7Q0FDeEUsSUFBSSxrQkFBa0IsUUFBUSxDQUFDLFdBRTdCLGlCQUFpQix1QkFBdUIscUJBQXFCLE1BQU0sS0FBQSxJQUFZLG1CQUFtQixLQUFBO0NBRXBHLE9BQU87QUFDVDs7Ozs7QUNVQSxJQUFhLGlCQUE4QiwyQkFBTSxXQUFXLFNBQVMsZUFBZSxnQkFBZ0IsY0FBYztDQUNoSCxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsWUFDQSxJQUFJLFFBQ0osY0FBYyxrQkFDZCxHQUFHLGlCQUNEO0NBQ0osTUFBTSxFQUNKLE9BQ0EsbUJBQ0EsdUJBQ0EsY0FDQSxnQkFDRSxtQkFBbUI7Q0FDdkIsTUFBTSw4QkFBOEIsMEJBQTBCO0NBQzlELE1BQU0sRUFDSixNQUNBLFVBQ0UseUJBQXlCO0NBQzdCLE1BQU0sZ0JBQWdCLHNCQUFzQixJQUFJLEtBQUs7Q0FDckQsTUFBTSxPQUFPLE1BQU0sU0FBUyxNQUFNO0NBQ2xDLE1BQU0sbUJBQW1CLE1BQU0sU0FBUyxrQkFBa0I7Q0FDMUQsTUFBTSxhQUFhLE1BQU0sU0FBUyxZQUFZO0NBQzlDLE1BQU0sVUFBVSxNQUFNLFNBQVMsU0FBUztDQUN4QyxNQUFNLGNBQWMsTUFBTSxTQUFTLGFBQWE7Q0FDaEQsTUFBTSx1QkFBdUIsTUFBTSxTQUFTLHNCQUFzQjtDQUNsRSxNQUFNLFNBQVMsTUFBTSxTQUFTLFFBQVE7Q0FDdEMsTUFBTSx1QkFBdUIsTUFBTSxTQUFTLHNCQUFzQjtDQUNsRSxNQUFNLFNBQVMsTUFBTSxTQUFTLFFBQVE7Q0FDdEMsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLHFCQUFxQjtDQUM1RCxNQUFNLG1CQUFtQixNQUFNLFNBQVMsa0JBQWtCO0NBQzFELE1BQU0sYUFBYSxNQUFNLFNBQVMsWUFBWTtDQUM5QyxNQUFNLGVBQWUsTUFBTSxTQUFTLGNBQWM7Q0FDbEQsTUFBTSxXQUFXLE1BQU0sU0FBUyxVQUFVO0NBQzFDLE1BQU0sYUFBYSxNQUFNLFNBQVMsWUFBWTtDQUM5QyxNQUFNLGtCQUFrQixNQUFNLFNBQVMsaUJBQWlCO0NBQ3hELE1BQU0sY0FBYyxNQUFNLFNBQVMsYUFBYTtDQUNoRCxNQUFNLENBQUMsSUFBSSxpQkFBaUIsY0FBYyxnQkFBZ0IsbUJBQW1CLHFCQUFxQjtDQUNsRyxNQUFNLGlCQUFpQixrQkFBa0IsZ0JBQWdCLHNCQUFzQixlQUFlO0NBRzlGLE1BQU0scUJBQXFCLE9BQU8sU0FBUyxTQUFTLDhCQUE4QixLQUFBO0NBQ2xGLE1BQU0sZ0JBQWdCLE9BQU8sU0FBUztDQUN0QyxJQUFJLGVBQWUsb0JBQW9CLE9BQU8sU0FBUztDQUN2RCxJQUFJLHFCQUFxQixLQUFBLEtBQWEsZUFBZSxPQUFPLFNBQVMsUUFDbkUscUJBQXFCO0VBRW5CLElBQUksTUFBTSxNQUFNLGdCQUFnQixNQUM5QixPQUFPO0VBSVQsT0FBTztDQUNUO0NBRUYsc0JBQXNCO0VBQ3BCO0VBQ0EsS0FBSyxNQUFNLFFBQVE7RUFDbkIsYUFBYTtHQUNYLElBQUksTUFDRixNQUFNLFFBQVEsdUJBQXVCLElBQUk7RUFFN0M7Q0FDRixDQUFDO0NBQ0QsYUFBTSxnQkFBZ0I7RUFDcEIsU0FBUyxZQUFZLE9BQU87R0FDMUIsTUFBTSxRQUFRLE9BQU8seUJBQXlCLE1BQU0sUUFBUSxNQUFNLFFBQVEsQ0FBQztFQUM3RTtFQUNBLGlCQUFpQixPQUFPLEdBQUcsU0FBUyxXQUFXO0VBQy9DLGFBQWE7R0FDWCxpQkFBaUIsT0FBTyxJQUFJLFNBQVMsV0FBVztFQUNsRDtDQUNGLEdBQUcsQ0FBQyxpQkFBaUIsUUFBUSxLQUFLLENBQUM7Q0FDbkMsNEJBQTRCLGlCQUFpQjtFQUMzQyxTQUFTLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxpQkFBaUIsT0FBTyxTQUFTO0VBQ3hFO0NBQ0YsQ0FBQztDQUNELE1BQU0sa0JBQWtCLE1BQU0sZUFBZSxjQUFjO0NBSzNELE1BQU0sRUFDSix1QkFDQSxpQkFBQSxhQUg2QixXQUFXLHFCQUFxQixDQUFDLEVBQUUsb0JBQW9CLG1CQUFBLENBSWpFLE9BQU8sUUFBUSxNQUFNLFlBQVk7Q0FDdEQsTUFBTSxRQUFRO0VBQ1o7RUFDQTtFQUNBO0VBQ0E7RUFDQSxRQUFRLE9BQU8sU0FBUztFQUN4QixTQUFTO0NBQ1g7Q0FDQSxNQUFNLFVBQVUsaUJBQWlCLE9BQU8sZ0JBQWdCO0VBQ3REO0VBQ0EsS0FBSztHQUFDO0dBQWMsTUFBTSxRQUFRO0dBQVU7R0FBaUI7RUFBYTtFQUMxRSx3QkFBd0I7RUFDeEIsT0FBTztHQUFDO0dBQVk7SUFDbEI7SUFFQSxHQUFJLGNBQWMsRUFDaEIsTUFBTSxlQUNSLElBQUk7S0FDRixNQUFNO0tBR04sb0JBQW9CLGdCQUFnQixlQUFlLGVBQWUsS0FBQTtLQUNsRSxtQkFBbUI7SUFDckI7SUFDQSxVQUFVLE9BQU87S0FDZixvQkFBb0IsaUJBQWlCLEtBQUs7S0FDMUMsSUFBSSxpQkFBaUIsZUFBZSxJQUFJLE1BQU0sR0FBRyxHQUMvQyxNQUFNLGdCQUFnQjtJQUUxQjtJQUNBLFNBQVM7R0FDWDtHQUFHLGlDQUFpQyxnQkFBZ0I7R0FBRztHQUFjLEVBQ25FLG9CQUFvQixPQUN0QjtFQUFDO0NBQ0gsQ0FBQztDQUNELElBQUksY0FBYyxPQUFPLFNBQVMsS0FBQSxLQUFhO0NBQy9DLElBQUksd0JBQXdCLE9BQU8sU0FBUyxhQUFhLHlCQUF5QixpQkFDaEYsY0FBYztDQUloQixNQUFNLHFCQUFxQixvQkFBb0Isb0JBQW9CO0NBQ25FLE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssc0JBQXNCO0VBQzdDLFNBQVM7RUFDVCxxQkFBcUI7RUFDckIsT0FBTztFQUNQLFVBQVUsQ0FBQztFQUNYLGFBQWEsY0FBYyxzQkFBc0I7RUFDakQscUJBQXFCLGVBQWUsS0FBQSxLQUFhLHFCQUFxQixRQUFRLEtBQUE7RUFDaEU7RUFDZCxjQUFjO0VBQ2QsbUJBQW1CLE9BQU8sU0FBUyxLQUFBLFVBQWtCLENBQUMsTUFBTSxRQUFRLDJCQUEyQixPQUFPLElBQUksS0FBQTtFQUMxRyxjQUFjLE9BQU8sU0FBUyxZQUFZLG1CQUFtQixLQUFBO0VBQzdELDBCQUEwQjtFQUMxQixzQkFBc0IsT0FBTyxTQUFTLEtBQUEsSUFBWSxNQUFNLFFBQVEsd0JBQXdCLEtBQUE7RUFDeEYsNEJBQTRCLE1BQU0sUUFBUTtFQUMxQyxVQUFVO0NBQ1osQ0FBQztBQUNILENBQUM7QUFDMEMsZUFBZSxjQUFjO0FBQ3hFLElBQU0sb0JBQW9CO0NBQ3hCLHVCQUF1QixLQUFBO0NBQ3ZCLGFBQWEsS0FBQTtBQUNmO0FBQ0EsU0FBUyxxQkFBcUI7Q0FDNUIsT0FBTztBQUNUOzs7Ozs7O0FBUUEsSUFBYSxZQUF5QiwyQkFBTSxXQUFXLFNBQVMsVUFBVSxPQUFPLGNBQWM7Q0FDN0YsTUFBTSxRQUFRLGtCQUFrQixDQUFDLEVBQUUsU0FBUztDQUM1QyxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLE9BQU87RUFDOUIsR0FBRztFQUNILEtBQUs7Q0FDUCxDQUFDO0FBQ0gsQ0FBQztBQUMwQyxVQUFVLGNBQWM7O0FDNUxuRSxJQUFhLG9CQUFpQywyQkFBTSxjQUFjLEtBQUEsQ0FBUztBQUNoQyxrQkFBa0IsY0FBYztBQUMzRSxTQUFnQix1QkFBdUI7Q0FDckMsTUFBTSxRQUFBLGFBQWMsV0FBVyxpQkFBaUI7Q0FDaEQsSUFBSSxVQUFVLEtBQUEsR0FDWixNQUFNLElBQUksTUFBOEMsb0NBQThEO0NBRXhILE9BQU87QUFDVDs7Ozs7Ozs7O0FDR0EsSUFBYSxhQUEwQiwyQkFBTSxXQUFXLFNBQVMsV0FBVyxPQUFPLGNBQWM7Q0FDL0YsTUFBTSxFQUNKLGNBQWMsT0FDZCxHQUFHLGdCQUNEO0NBQ0osTUFBTSxFQUNKLE9BQ0EsV0FDRSxtQkFBbUI7Q0FHdkIsSUFBSSxFQUZZLE1BQU0sU0FBUyxTQUNKLEtBQUssY0FFOUIsT0FBTztDQU1ULE1BQU0sa0JBQWtCLE9BQU8sU0FBUyxVQUFVLE9BQU8sU0FBUyxZQUFZLFVBQVUsS0FBQTtDQUN4RixPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGtCQUFrQixVQUFVO0VBQ25ELE9BQU87RUFDUCxVQUF1QixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGdCQUFnQjtHQUMxQyxLQUFLO0dBQ0wsR0FBRztHQUNjO0VBQ25CLENBQUM7Q0FDSCxDQUFDO0FBQ0gsQ0FBQztBQUMwQyxXQUFXLGNBQWM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNicEUsU0FBZ0IsMkJBQTJCLFlBQVk7Q0FDckQsTUFBTSxFQUNKLE9BQ0EsY0FDQSxtQkFDQSxTQUNFO0NBQ0osTUFBTSxxQkFBQSxhQUEyQixPQUFPLElBQUk7Q0FDNUMsTUFBTSxtQkFBQSxhQUF5QixPQUFPLElBQUk7Q0FDMUMsTUFBTSwwQkFBMEIsc0JBQXNCLGlCQUFpQjtDQUN2RSx5QkFBeUI7RUFDdkIsSUFBSSxNQUNGO0VBRUYsaUJBQWlCLFNBQVMsTUFBTTtFQUNoQyxpQkFBaUIsVUFBVTtFQU8zQixJQUFJLE1BQU0sTUFBTSxnQkFBZ0Isa0JBQzlCLE1BQU0sSUFBSSxlQUFlLEtBQUEsQ0FBUztDQUV0QyxHQUFHLENBQUMsTUFBTSxLQUFLLENBQUM7Q0FDaEIseUJBQXlCO0VBQ3ZCLE1BQU0saUJBQWlCO0VBQ3ZCLE1BQU0sa0JBQWtCLG1CQUFtQjtFQUMzQyxJQUFJLGdCQUNGLG1CQUFtQixVQUFVO0VBRS9CLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxrQkFBa0IsbUJBQW1CLGlCQUM1RDtFQU9GLElBQUksQ0FBQyxNQUFNLE9BQU8sTUFBTSxHQUN0QjtFQUVGLE1BQU0sSUFBSSxlQUFlLEtBQUEsQ0FBUztFQUNsQyxNQUFNLGtCQUFrQixJQUFJLGdCQUFnQjtFQUM1QyxpQkFBaUIsVUFBVTtFQUMzQiw4QkFBOEI7R0FJNUIsSUFBSSxNQUFNLE9BQU8sTUFBTSxHQUNyQixNQUFNLElBQUksZUFBZSxnQkFBZ0I7RUFFN0MsR0FBRyxnQkFBZ0IsTUFBTTtFQUN6QixhQUFhO0dBQ1gsZ0JBQWdCLE1BQU07RUFDeEI7Q0FDRixHQUFHO0VBQUM7RUFBYztFQUF5QjtDQUFLLENBQUM7QUFDbkQ7Ozs7Ozs7O0FDN0RBLElBQWEsaUJBQThCLDJCQUFNLFdBQVcsU0FBUyxlQUFlLGdCQUFnQixjQUFjO0NBQ2hILE1BQU0sRUFDSixRQUFRLFlBQ1IsZ0JBQWdCLHFCQUFxQixZQUNyQyxXQUNBLFFBQ0EsTUFDQSxPQUFPLFdBQ1AsWUFBWSxpQkFBaUIsR0FDN0IsYUFBYSxrQkFBa0IsR0FDL0Isb0JBQW9CLHNCQUNwQixtQkFBbUIsR0FDbkIsZUFBZSxHQUNmLFNBQVMsT0FDVCx3QkFBd0IsT0FDeEIsb0JBQW9CLHlCQUF5Qiw4QkFDN0MsT0FDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxFQUNKLE9BQ0EsY0FDQSx3QkFDRSxtQkFBbUI7Q0FDdkIsTUFBTSxjQUFjLHFCQUFxQjtDQUN6QyxNQUFNLHFCQUFxQiwwQkFBMEIsSUFBSTtDQUN6RCxNQUFNLFNBQVMsTUFBTSxTQUFTLFFBQVE7Q0FDdEMsTUFBTSxzQkFBc0IsTUFBTSxTQUFTLHFCQUFxQjtDQUNoRSxNQUFNLG1CQUFtQixNQUFNLFNBQVMsa0JBQWtCO0NBQzFELE1BQU0sVUFBVSxNQUFNLFNBQVMsU0FBUztDQUN4QyxNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxRQUFRLE1BQU0sU0FBUyxPQUFPO0NBQ3BDLE1BQU0sYUFBYSxNQUFNLFNBQVMsWUFBWTtDQUM5QyxNQUFNLGlCQUFpQixNQUFNLFNBQVMsc0JBQXNCO0NBQzVELE1BQU0sbUJBQW1CLE1BQU0sU0FBUyxrQkFBa0I7Q0FDMUQsTUFBTSxvQkFBb0IsTUFBTSxTQUFTLG1CQUFtQjtDQUM1RCxNQUFNLGNBQWMsTUFBTSxTQUFTLGFBQWE7Q0FDaEQsTUFBTSxpQkFBaUIsTUFBTSxTQUFTLGdCQUFnQjtDQUN0RCxNQUFNLHVCQUF1QixNQUFNLFNBQVMsc0JBQXNCO0NBQ2xFLE1BQU0saUJBQWlCLE1BQU0sU0FBUyxnQkFBZ0I7Q0FDdEQsTUFBTSx1QkFBdUIsTUFBTSxTQUFTLHNCQUFzQjtDQUNsRSxNQUFNLGVBQWUsb0JBQW9CLFNBQVMscUJBQXFCO0NBQ3ZFLElBQUksU0FBUztDQUNiLElBQUksYUFBYTtDQUNqQixJQUFJLGNBQWM7Q0FDbEIsSUFBSSxRQUFRO0NBQ1osSUFBSSxxQkFBcUI7Q0FDekIsSUFBSSxPQUFPLFNBQVMsZ0JBQWdCO0VBQ2xDLFNBQVMsY0FBYyxPQUFPLFNBQVM7RUFDdkMsUUFBUSxTQUFTO0VBQ2pCLElBQUksQ0FBQyxRQUFRLFVBQVUsVUFBVTtHQUMvQixjQUFjLGVBQWUsZUFBZTtHQUM1QyxhQUFhLGVBQWUsY0FBYztFQUM1QztDQUNGO0NBQ0EsSUFBSSxlQUFlO0NBQ25CLElBQUksZ0JBQWdCO0NBQ3BCLElBQUksT0FBTyxTQUFTLFFBQVE7RUFDMUIsZUFBZSxnQkFBZ0I7RUFDL0IsZ0JBQWdCLGlCQUFpQjtFQUNqQyxxQkFBcUIsZUFBZSxzQkFBc0I7Q0FDNUQsT0FBTyxJQUFJLE9BQU8sU0FBUyxXQUFXO0VBQ3BDLGVBQWUsaUJBQWlCLE9BQU8sUUFBUSxnQkFBZ0IsYUFBYSxlQUFlO0VBQzNGLGdCQUFnQixpQkFBaUI7Q0FDbkM7Q0FDQSxNQUFNLGNBQWMsT0FBTyxTQUFTO0NBQ3BDLE1BQU0sYUFBYSxxQkFBcUI7RUFDdEM7RUFDQTtFQUNBLGdCQUFnQixxQkFBcUIsVUFBVTtFQUMvQztFQUNBLE1BQU07RUFDTjtFQUNBLE9BQU87RUFDUDtFQUNBLGNBQWMsY0FBYyxJQUFJO0VBQ2hDO0VBQ0E7RUFDQTtFQUNBLFFBQVE7RUFDUjtFQUNBO0VBQ0E7RUFDQSxPQUFPLGNBQWM7R0FDbkIsV0FBVyxFQUFFLFVBQVUsc0JBQXNCLG1CQUFtQixTQUFTO0dBQ3pFLGNBQWM7RUFDaEIsSUFBSSxLQUFBO0VBQ0osY0FBYztFQUNkO0VBQ0EsVUFBVSxlQUFlLGNBQWM7Q0FDekMsQ0FBQztDQUNELGFBQU0sZ0JBQWdCO0VBQ3BCLFNBQVMsaUJBQWlCLFNBQVM7R0FDakMsSUFBSSxRQUFRLE1BQU07SUFDaEIsSUFBSSxRQUFRLGlCQUFpQixnQkFDM0IsTUFBTSxJQUFJLGdCQUFnQixLQUFLO0lBRWpDLElBQUksUUFBUSxXQUFXLGtCQUFrQixRQUFRLGlCQUFpQixNQUFNLE9BQU8sc0JBQXNCLEdBQ25HLE1BQU0sUUFBUSxPQUFPLHlCQUF5QkMsV0FBbUIsQ0FBQztHQUV0RTtFQUNGO0VBQ0EsaUJBQWlCLE9BQU8sR0FBRyxrQkFBa0IsZ0JBQWdCO0VBQzdELGFBQWE7R0FDWCxpQkFBaUIsT0FBTyxJQUFJLGtCQUFrQixnQkFBZ0I7RUFDaEU7Q0FDRixHQUFHO0VBQUM7RUFBTyxpQkFBaUI7RUFBUTtDQUFjLENBQUM7Q0FDbkQsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxNQUFNLE9BQU8sc0JBQXNCLEtBQUssTUFDMUM7RUFFRixTQUFTLGNBQWMsU0FBUztHQUM5QixJQUFJLFFBQVEsUUFBUSxRQUFRLFdBQVcsTUFBTSxPQUFPLHNCQUFzQixHQUN4RTtHQUVGLE1BQU0sU0FBUyxRQUFRLFVBQVU7R0FDakMsTUFBTSxRQUFRLE9BQU8seUJBQXlCLE1BQU0sQ0FBQztFQUN2RDtFQUNBLGlCQUFpQixPQUFPLEdBQUcsa0JBQWtCLGFBQWE7RUFDMUQsYUFBYTtHQUNYLGlCQUFpQixPQUFPLElBQUksa0JBQWtCLGFBQWE7RUFDN0Q7Q0FDRixHQUFHLENBQUMsaUJBQWlCLFFBQVEsS0FBSyxDQUFDO0NBQ25DLE1BQU0sZUFBZSxXQUFXO0NBR2hDLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksQ0FBQyxNQUNILGFBQWEsTUFBTTtDQUV2QixHQUFHLENBQUMsTUFBTSxZQUFZLENBQUM7Q0FHdkIsYUFBTSxnQkFBZ0I7RUFDcEIsU0FBUyxZQUFZLE9BQU87R0FHMUIsSUFBSSxDQUFDLFFBQVEsTUFBTSxXQUFXLE1BQU0sT0FBTyxzQkFBc0IsR0FDL0Q7R0FFRixJQUFJLE1BQU0sVUFBVSxrQkFBa0IsbUJBQW1CLE1BQU0sUUFBUTtJQUNyRSxNQUFNLFFBQVEsTUFBTSxPQUFPLFlBQVk7SUFDdkMsSUFBSSxRQUFRLEdBQ047U0FBQSxDQUFDLGFBQWEsVUFBVSxHQUMxQixhQUFhLE1BQU0sYUFBYTtNQUM5QixNQUFNLFFBQVEsT0FBTyx5QkFBeUJBLFdBQW1CLENBQUM7S0FDcEUsQ0FBQztJQUFBLE9BR0gsTUFBTSxRQUFRLE9BQU8seUJBQXlCQSxXQUFtQixDQUFDO0dBRXRFLE9BRUUsYUFBYSxNQUFNO0VBRXZCO0VBQ0EsaUJBQWlCLE9BQU8sR0FBRyxhQUFhLFdBQVc7RUFDbkQsYUFBYTtHQUNYLGlCQUFpQixPQUFPLElBQUksYUFBYSxXQUFXO0VBQ3REO0NBQ0YsR0FBRztFQUFDLGlCQUFpQjtFQUFRO0VBQU07RUFBZ0I7RUFBTztDQUFZLENBQUM7Q0FDdkUsYUFBTSxnQkFBZ0I7RUFDcEIsTUFBTSxlQUFlO0dBQ25CO0dBQ0EsUUFBUTtHQUNSLGNBQWM7R0FDZCxRQUFRLE1BQU0sT0FBTyxzQkFBc0I7RUFDN0M7RUFDQSxpQkFBaUIsT0FBTyxLQUFLLGtCQUFrQixZQUFZO0NBQzdELEdBQUc7RUFBQyxpQkFBaUI7RUFBUTtFQUFNO0VBQU87RUFBZ0I7Q0FBb0IsQ0FBQztDQUMvRSwyQkFBMkI7RUFDekI7RUFDQTtFQUNBO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsTUFBTSxRQUFRO0VBQ1o7RUFDQSxNQUFNLFdBQVc7RUFDakIsT0FBTyxXQUFXO0VBQ2xCLGNBQWMsV0FBVztFQUN6QixRQUFRLE9BQU8sU0FBUztFQUN4QixTQUFTO0NBQ1g7Q0FDQSxNQUFNLGVBQWUsT0FBTyxTQUFTLGFBQWEsT0FBTyxRQUFRO0NBRWpFLDJCQUEyQixTQUFTLGdCQURqQixTQUFTLHlCQUF5QixrQkFDWSxlQUFlLFNBQVMsbUJBQW1CLGNBQWM7Q0FDMUgsTUFBTSxVQUFVLGNBQWMsZ0JBQWdCLE9BQU87RUFDbkQsUUFBUSxXQUFXO0VBQ25CO0VBQ0EsT0FBTztFQUNQLE1BQU0sQ0FBQyxjQUFjLE1BQU0sZUFBZSxtQkFBbUIsQ0FBQztFQUM5RCxRQUFRLENBQUM7RUFDVCxPQUFPLENBQUM7Q0FDVixDQUFDO0NBQ0QsTUFBTSx1QkFBdUIsV0FBVyxPQUFPLFNBQVMsV0FBVyxPQUFPLFNBQVMsYUFBYSxTQUFTLHlCQUF5QixtQkFBd0IsT0FBTyxTQUFTLGFBQWEsT0FBTyxRQUFRO0NBR3RNLElBQUksaUJBQWlCO0NBQ3JCLElBQUksT0FBTyxTQUFTLFdBQ2xCLGlCQUFpQixPQUFPLFFBQVE7TUFDM0IsSUFBSSxPQUFPLFNBQVMsS0FBQSxHQUN6QixpQkFBaUI7Q0FFbkIsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBTSxzQkFBc0IsVUFBVTtFQUN4RCxPQUFPO0VBQ1AsVUFBVSxDQUFDLHdCQUFxQyxlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGtCQUFrQjtHQUNyRSxLQUFLLE9BQU8sU0FBUyxrQkFBa0IsT0FBTyxTQUFTLHdCQUF3QixPQUFPLFFBQVEsc0JBQXNCO0dBQ3BILE9BQU8sV0FBVyxDQUFDLElBQUk7R0FDdkIsUUFBUTtFQUNWLENBQUMsR0FBZ0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxjQUFjO0dBQ2xDLElBQUk7R0FDSixVQUF1QixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGVBQWU7SUFDekMsYUFBYSxNQUFNLFFBQVE7SUFDM0IsV0FBVyxNQUFNLFFBQVE7SUFDekIsYUFBYTtJQUNiLFVBQVU7R0FDWixDQUFDO0VBQ0gsQ0FBQyxDQUFDO0NBQ0osQ0FBQztBQUNILENBQUM7QUFDMEMsZUFBZSxjQUFjOztBQ3BQeEUsSUFBYSx3QkFBcUMsMkJBQU0sY0FBYyxLQUFBLENBQVM7QUFDcEMsc0JBQXNCLGNBQWM7QUFDL0UsU0FBZ0IsMkJBQTJCO0NBQ3pDLE1BQU0sVUFBQSxhQUFnQixXQUFXLHFCQUFxQjtDQUN0RCxJQUFJLFlBQVksS0FBQSxHQUNkLE1BQU0sSUFBSSxNQUE4QywwR0FBb0k7Q0FFOUwsT0FBTztBQUNUOzs7OztBQ0NBLElBQWEsc0JBQW1DLDJCQUFNLFdBQVcsU0FBUyxvQkFBb0IsZ0JBQWdCLGNBQWM7Q0FDMUgsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUFPLFdBQ1AsY0FDQSxlQUFlLG1CQUNmLFdBQVcsT0FDWCxPQUNBLG1CQUFtQixvQkFDbkIsR0FBRyxpQkFDRDtDQUNKLE1BQU0sQ0FBQyxTQUFTLGNBQUEsYUFBb0IsU0FBUyxLQUFBLENBQVM7Q0FDdEQsTUFBTSxDQUFDLE9BQU8scUJBQXFCLGNBQWM7RUFDL0MsWUFBWTtFQUNaLFNBQVM7RUFDVCxNQUFNO0NBQ1IsQ0FBQztDQUNELE1BQU0sV0FBVyxtQkFBbUIsVUFBVSxpQkFBaUI7RUFDN0Qsb0JBQW9CLFVBQVUsWUFBWTtFQUMxQyxJQUFJLGFBQWEsWUFDZjtFQUVGLGtCQUFrQixRQUFRO0NBQzVCLENBQUM7Q0FJRCxNQUFNLFVBQVUsaUJBQWlCLE9BQU8sZ0JBQWdCO0VBQ3RELE9BQUEsRUFIQSxTQUdJO0VBQ0osS0FBSztFQUNMLE9BQU87R0FDTCxNQUFNO0dBQ04sbUJBQW1CLHNCQUFzQjtHQUN6QyxpQkFBaUIsWUFBWSxLQUFBO0dBQzdCLEdBQUc7RUFDTDtDQUNGLENBQUM7Q0FDRCxNQUFNLFVBQUEsYUFBZ0IsZUFBZTtFQUNuQztFQUNBO0VBQ0E7Q0FDRixJQUFJO0VBQUM7RUFBTztFQUFVO0NBQVEsQ0FBQztDQUMvQixPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGlCQUFpQixVQUFVO0VBQ2xELE9BQU87RUFDUCxVQUF1QixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLHNCQUFzQixVQUFVO0dBQzFELE9BQU87R0FDUCxVQUFVO0VBQ1osQ0FBQztDQUNILENBQUM7QUFDSCxDQUFDO0FBUTBDLG9CQUFvQixjQUFjO0FBQzdFLElBQWEsaUJBQThCLDJCQUFNLEtBQWtCLDJCQUFNLFdBQVcsU0FBUyxlQUFlLE9BQU8sY0FBYztDQUMvSCxNQUFNLGFBQWEsa0JBQWtCLENBQUMsRUFBRSxjQUFjO0NBQ3RELE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssWUFBWTtFQUNuQyxHQUFHO0VBQ0gsS0FBSztDQUNQLENBQUM7QUFDSCxDQUFDLENBQUM7QUFDeUMsZUFBZSxjQUFjOztBQzNFeEUsSUFBYSx1QkFBb0MsMkJBQU0sY0FBYyxLQUFBLENBQVM7QUFDbkMscUJBQXFCLGNBQWM7QUFDOUUsU0FBZ0IsMEJBQTBCO0NBQ3hDLE1BQU0sVUFBQSxhQUFnQixXQUFXLG9CQUFvQjtDQUNyRCxJQUFJLFlBQVksS0FBQSxHQUNkLE1BQU0sSUFBSSxNQUE4Qyx1R0FBaUk7Q0FFM0wsT0FBTztBQUNUOztBQ0lBLElBQU0scUJBQWtDLDJCQUFNLFdBQVcsU0FBUyxtQkFBbUIsZ0JBQWdCLGNBQWM7Q0FDakgsTUFBTSxFQUNKLFFBQ0EsV0FDQSxJQUFJLFFBQ0osT0FDQSxlQUFlLE9BQ2YsVUFBVSxlQUFlLE9BQ3pCLGVBQWUsT0FDZixPQUNBLE9BQ0EsR0FBRyxpQkFDRDtDQUNKLE1BQU0sRUFDSixVQUNFLG1CQUFtQjtDQUN2QixNQUFNLEVBQ0osT0FBTyxlQUNQLFVBQVUsa0JBQ1YsVUFBVSxrQkFDUix5QkFBeUI7Q0FDN0IsTUFBTSxXQUFXLHFCQUFxQjtFQUNwQyxPQUFPO0VBQ1A7Q0FDRixDQUFDO0NBQ0QsTUFBTSxLQUFLLFlBQVksTUFBTTtDQUM3QixNQUFNLGNBQWMsTUFBTSxTQUFTLFlBQVksU0FBUyxLQUFLO0NBQzdELE1BQU0sU0FBUyxNQUFNLFNBQVMsZ0JBQWdCO0NBQzlDLE1BQU0sWUFBWSxNQUFNLFNBQVMsV0FBVztDQUM1QyxNQUFNLGVBQWUsTUFBTSxTQUFTLFVBQVU7Q0FDOUMsTUFBTSxXQUFXLGdCQUFnQixpQkFBaUI7Q0FDbEQsTUFBTSxVQUFVLGtCQUFrQjtDQUNsQyxNQUFNLEVBQ0osY0FDQSxZQUNFLFlBQVk7RUFDZDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLGNBQWM7Q0FDaEIsQ0FBQztDQUNELE1BQU0sUUFBQSxhQUFjLGVBQWU7RUFDakM7RUFDQTtFQUNBO0NBQ0YsSUFBSTtFQUFDO0VBQVU7RUFBYTtDQUFPLENBQUM7Q0FDcEMsU0FBUyxZQUFZLE9BQU87RUFDMUIsTUFBTSxVQUFVLHlCQUF5QkMsV0FBbUIsTUFBTSxhQUFhLEtBQUEsR0FBVyxFQUN4Rix1QkFBdUIsS0FDekIsQ0FBQztFQUNELGlCQUFpQixPQUFPLE9BQU87Q0FDakM7Q0FDQSxNQUFNLFVBQVUsaUJBQWlCLE9BQU8sZ0JBQWdCO0VBQ3REO0VBQ0Esd0JBQXdCO0VBQ3hCLE9BQU87R0FBQztHQUFXO0lBQ2pCLE1BQU07SUFDTixnQkFBZ0I7SUFDaEIsU0FBUztHQUNYO0dBQUc7R0FBYztFQUFZO0VBQzdCLEtBQUs7R0FBQztHQUFTO0dBQWMsU0FBUztFQUFHO0NBQzNDLENBQUM7Q0FDRCxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLHFCQUFxQixVQUFVO0VBQ3RELE9BQU87RUFDUCxVQUFVO0NBQ1osQ0FBQztBQUNILENBQUM7QUFRMEMsbUJBQW1CLGNBQWM7QUFDNUUsSUFBYSxnQkFBNkIsMkJBQU0sV0FBVyxTQUFTLGNBQWMsT0FBTyxjQUFjO0NBQ3JHLE1BQU0sYUFBYSxrQkFBa0IsT0FBTyxZQUFZO0NBQ3hELElBQUksQ0FBQyxXQUFXLFNBQ2QsT0FBTztDQUVULE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssb0JBQW9CO0VBQzNDLEdBQUc7RUFDSCxLQUFLLFdBQVc7Q0FDbEIsQ0FBQztBQUNILENBQUM7QUFDMEMsY0FBYyxjQUFjOzs7Ozs7OztBQzFGdkUsSUFBYSx5QkFBc0MsMkJBQU0sV0FBVyxTQUFTLHVCQUF1QixnQkFBZ0IsY0FBYztDQUNoSSxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsY0FBYyxPQUNkLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLE9BQU8sd0JBQXdCO0NBQ3JDLE1BQU0sZUFBQSxhQUFxQixPQUFPLElBQUk7Q0FDdEMsTUFBTSxFQUNKLGtCQUNBLFNBQ0EsZUFDRSxvQkFBb0IsS0FBSyxPQUFPO0NBQ3BDLHNCQUFzQjtFQUNwQixPQUFPO0VBQ1AsU0FBUyxDQUFDLEtBQUs7RUFDZixNQUFNLEtBQUs7RUFDWCxLQUFLO0VBQ0wsYUFBYTtHQUNYLElBQUksQ0FBQyxLQUFLLFNBQ1IsV0FBVyxLQUFLO0VBRXBCO0NBQ0YsQ0FBQztDQUNELE1BQU0sUUFBUTtFQUNaLFNBQVMsS0FBSztFQUNkLFVBQVUsS0FBSztFQUNmLGFBQWEsS0FBSztFQUNsQjtDQUNGO0NBV0EsT0FWZ0IsaUJBQWlCLFFBQVEsZ0JBQWdCO0VBQ3ZEO0VBQ0Esd0JBQXdCO0VBQ3hCLEtBQUssQ0FBQyxjQUFjLFlBQVk7RUFDaEMsT0FBTztHQUNMLGVBQWU7R0FDZixHQUFHO0VBQ0w7RUFDQSxTQUFTLGVBQWU7Q0FDMUIsQ0FDYTtBQUNmLENBQUM7QUFDMEMsdUJBQXVCLGNBQWM7O0FDdkRoRixJQUFhLGlCQUE4QiwyQkFBTSxjQUFjLElBQUk7QUFDeEIsZUFBZSxjQUFjO0FBQ3hFLFNBQWdCLGtCQUFrQixVQUFVO0NBQzFDLE1BQU0sVUFBQSxhQUFnQixXQUFXLGNBQWM7Q0FDL0MsSUFBSSxZQUFZLFFBQVEsQ0FBQyxVQUN2QixNQUFNLElBQUksTUFBOEMsb0ZBQTZHO0NBRXZLLE9BQU87QUFDVDs7Ozs7O0FDTkEsU0FBZ0IsbUJBQW1CLE9BQU87Q0FDeEMsSUFBSSxTQUFTLE1BQ1gsT0FBT0M7Q0FFVCxJQUFJLE1BQU0sS0FBSyxXQUFXLEtBQUssR0FDN0IsT0FBT0M7Q0FFVCxJQUFJLE1BQU0sS0FBSyxXQUFXLE9BQU8sS0FBSyxNQUFNLEtBQUssV0FBVyxTQUFTLEdBQ25FLE9BQU9DO0NBRVQsT0FBT0Y7QUFDVDs7QUNWQSxJQUFNRyxjQUFZO0NBQ2hCLEdBQUc7Q0FDSCxXQUFVLFVBQVMsTUFBTSxPQUFPLFNBQVMsWUFBWSxNQUFNLE9BQU8sUUFBUSxZQUFZLE1BQU0sV0FBVyxNQUFNO0NBQzdHLFFBQU8sV0FBVSxNQUFNLE9BQU8sU0FBUyxLQUFBLEtBQWEsTUFBTSxPQUFPLFNBQVMsb0JBQW9CLE1BQU0sU0FBUztDQUM3RyxhQUFZLFVBQVMsTUFBTTtDQUMzQixlQUFjLFVBQVMsTUFBTTtDQUM3QixrQkFBaUIsVUFBUyxNQUFNO0NBQ2hDLHVCQUFzQixVQUFTLE1BQU07Q0FDckMsU0FBUSxVQUFTLE1BQU07Q0FDdkIsU0FBUSxVQUFTO0VBQ2YsSUFBSSxNQUFNLE9BQU8sU0FBUyxRQUN4QixPQUFPLE1BQU0sT0FBTyxNQUFNLE9BQU8sUUFBUTtFQUUzQyxPQUFPLE1BQU0sT0FBTyxTQUFTLEtBQUEsSUFBWSxNQUFNLE9BQU8sUUFBUSxTQUFTLE1BQU07Q0FDL0U7Q0FDQSxjQUFhLFVBQVMsTUFBTTtDQUM1QixjQUFhLFVBQVMsTUFBTTs7Q0FFNUIsb0JBQW9CLE9BQU8sY0FBYztFQUN2QyxNQUFNLFVBQVUsb0JBQW9CLGVBQWUsT0FBTyxTQUFTO0VBQ25FLE9BQU8sVUFBVSxNQUFNLGFBQWEsTUFBTSxVQUFVLEtBQUE7Q0FDdEQ7Q0FDQSxxQkFBb0IsVUFBUyxNQUFNO0NBQ25DLGFBQVksVUFBUyxNQUFNO0NBSTNCLHFCQUFxQixPQUFPLGdCQUFnQkMsVUFBMEIsTUFBTSxnQkFBZ0IsY0FBYyxPQUFPLEtBQUE7Q0FDakgsb0JBQW1CLFVBQVMsTUFBTSxpQkFBaUIsTUFBTSxLQUFBO0NBQ3pELFdBQVcsT0FBTyxjQUFjLE1BQU0sZ0JBQWdCO0NBQ3RELGVBQWMsVUFBUyxNQUFNO0NBTTdCLGNBQWEsVUFBUyxNQUFNLGdCQUFnQixvQkFBb0IsQ0FBQyxvQkFBb0IsS0FBSyxLQUFLLElBQUksS0FBQSxJQUFZLE1BQU07Q0FDckgsdUJBQXNCLFVBQVMsTUFBTTtDQUNyQyxtQkFBa0IsVUFBUztFQUN6QixJQUFJLE1BQU0sT0FBTyxTQUFTLFFBQ3hCLE9BQU8sTUFBTSxPQUFPLE1BQU0sT0FBTyxrQkFBa0I7RUFFckQsT0FBTyxNQUFNO0NBQ2Y7Q0FDQSxpQkFBZ0IsVUFBUyxNQUFNO0NBQy9CLHVCQUFzQixVQUFTLE1BQU07Q0FDckMsWUFBVyxVQUFTLE1BQU07Q0FDMUIsYUFBWSxVQUFTLE1BQU07Q0FDM0IsaUJBQWdCLFVBQVMsTUFBTTtDQUMvQixxQkFBb0IsVUFBUztFQUMzQixJQUFJLE1BQU0sb0JBQ1IsT0FBTyxNQUFNO0VBRWYsSUFBSSxNQUFNLE9BQU8sU0FBUyxRQUN4QixPQUFPLE1BQU0sT0FBTyxNQUFNLE9BQU8sb0JBQW9CO0NBR3pEO0FBQ0Y7Ozs7Ozs7O0FBVUEsSUFBYSxZQUFiLGNBQStCLFdBQVc7Q0FDeEMsWUFBWSxjQUFjLFlBQVksU0FBUyxPQUFPO0VBQ3BELE1BQU0sa0JBQWtCLElBQUksZ0JBQWdCO0VBQzVDLE1BQU0sUUFBUSxtQkFBbUIsaUJBQWlCLFlBQVksUUFBUSxZQUFZO0VBQ2xGLE1BQU0sT0FBTyxxQkFBcUIsZUFBZSxHQUFHRCxXQUFTO0VBSTdELEtBQVUsUUFBUSxXQUFVLFdBQVU7R0FDcEMsSUFBSSxPQUFPLFNBQVMsUUFDbEIsS0FBSyxRQUFRLHlCQUF5QixPQUFPLE1BQU0sUUFBUTtRQUN0RCxJQUFJLE9BQU8sU0FBUyxLQUFBLEdBQ3pCLEtBQUssUUFBUSx5QkFBeUIsT0FBTyxRQUFRO0VBRXpELENBQUM7Q0FDSDs7Ozs7OztDQVFBLHdCQUF3QjtFQUN0QixNQUFNLFNBQVMsS0FBSyxNQUFNO0VBQzFCLElBQUksT0FBTyxTQUFTLFFBQ2xCO0VBRUYsSUFBSSxTQUFTLE9BQU8sTUFBTSxPQUFPLFFBQVE7RUFDekMsSUFBSSxtQkFBbUIsT0FBTyxNQUFNLE9BQU8sa0JBQWtCO0VBQzdELElBQUkscUJBQXFCLE9BQU8sTUFBTSxPQUFPLG9CQUFvQjtFQUNqRSxPQUFPLE9BQU8sTUFBTSxnQkFBZ0I7R0FDbEMsTUFBTSxhQUFhLE9BQU8sTUFBTSxPQUFPLFFBQVE7R0FDL0MsTUFBTSx1QkFBdUIsT0FBTyxNQUFNLE9BQU8sa0JBQWtCO0dBQ25FLE1BQU0seUJBQXlCLE9BQU8sTUFBTSxPQUFPLG9CQUFvQjtHQUN2RSxJQUFJLFdBQVcsY0FBYyxxQkFBcUIsd0JBQXdCLHVCQUF1Qix3QkFDL0Y7R0FFRixTQUFTO0dBQ1QsbUJBQW1CO0dBQ25CLHFCQUFxQjtHQUNyQixLQUFLLFVBQVU7RUFDakIsQ0FBQztDQUNIO0NBQ0EsUUFBUSxNQUFNLGNBQWM7RUFDMUIsS0FBSyxNQUFNLG9CQUFvQixRQUFRLE9BQU8sS0FBSyxXQUFXO0dBQzVEO0dBQ0E7RUFDRixDQUFDO0NBQ0g7Q0FDQSxlQUFlLGFBQWEsUUFBUSxPQUFPO0VBSXpDLElBQUksS0FBSyxNQUFNLGdCQUFnQixhQUFhO0dBRTFDLE1BQU0sZUFETyxnQkFBZ0IsT0FBTyxLQUFBLElBQVksS0FBSyxRQUFRLGdCQUFnQixRQUFRLGtCQUN4RCxLQUFLLFFBQVE7R0FDMUMsS0FBSyxRQUFRLGtCQUFrQixjQUFjLFNBQVM7R0FDdEQsS0FBSyxRQUFRLGlCQUFpQixjQUFjLEtBQUEsSUFBWTtFQUMxRDtFQUNBLEtBQUssSUFBSSxlQUFlLFdBQVc7Q0FDckM7Q0FDQSxjQUFjLFNBQVMsUUFBUSxPQUFPO0VBQ3BDLE1BQU0sUUFBUSxLQUFLLFFBQVEsZ0JBQWdCLFFBQVEsUUFBUSxPQUFPO0VBQ2xFLElBQUksUUFBUSxJQUNWLEtBQUssZUFBZSxPQUFPLFFBQVEsS0FBSztDQUU1QztBQUNGOzs7Ozs7OztBQVNBLFNBQWdCLHNCQUFzQjtDQUNwQyxNQUFNLGtCQUFrQixJQUFJLGdCQUFnQjtDQUM1QyxNQUFNLFFBQVEsSUFBSSxVQUFVLE9BQU8sT0FBTyxtQkFBbUIsZUFBZSxDQUFDLEdBQUcsT0FBTyxPQUFPLHFCQUFxQixlQUFlLENBQUMsR0FBR0EsV0FBUztDQUMvSSxPQUFPLE9BQU8sT0FBTyxPQUFPLEVBQzFCLFNBQVMsS0FDWCxDQUFDO0FBQ0g7QUFDQSxTQUFTLHFCQUFxQixpQkFBaUI7Q0FDN0MsT0FBTztFQUNMLGVBQTRCLDJCQUFNLFVBQVU7RUFDNUMsVUFBdUIsMkJBQU0sVUFBVTtFQUN2QyxXQUFXLEVBQ1QsU0FBUyxNQUNYO0VBQ0EsaUJBQWlCLEVBQ2YsU0FBUyxDQUFDLEVBQ1o7RUFDQSxZQUFZLEVBQ1YsU0FBUyxDQUFDLEVBQ1o7RUFDQSxpQkFBaUI7RUFDakIsZ0JBQWdCLEtBQUE7RUFDaEIsY0FBYyxLQUFBO0VBQ2Qsd0JBQXdCLEVBQ3RCLFNBQVMsTUFDWDtFQUNBLGlCQUFpQixLQUFBO0VBQ2pCLHVCQUFvQywyQkFBTSxVQUFVO0VBQ3BELDRCQUF5QywyQkFBTSxVQUFVO0VBQ3pELDRCQUF5QywyQkFBTSxVQUFVO0VBQ3pELHNCQUFzQixLQUFBO0VBQ3RCO0NBQ0Y7QUFDRjtBQUNBLFNBQVMsbUJBQW1CLGlCQUFpQixZQUFZLFNBQVMsT0FBTyxjQUFjO0NBQ3JGLE9BQU87RUFDTCxHQUFHLDZCQUE2QixpQkFBaUIsWUFBWSxNQUFNO0VBQ25FLFVBQVU7RUFDVixPQUFPO0VBQ1AsWUFBWTtFQUNaLGNBQWM7RUFDZCxpQkFBaUI7RUFDakIsc0JBQXNCO0VBQ3RCLFFBQVEsRUFDTixNQUFNLEtBQUEsRUFDUjtFQUNBLFFBQVEsS0FBQTtFQUNSLGFBQWE7RUFDYixhQUFhO0VBQ2Isb0JBQW9CO0VBQ3BCLFlBQVk7RUFDWixjQUFjO0VBQ2QsaUJBQWlCLEtBQUE7RUFDakIsY0FBYztFQUNkLGFBQWEsS0FBQTtFQUNiLGtCQUFrQjtFQUNsQixrQkFBa0IsSUFBSSxrQkFBa0I7RUFDeEMsZ0JBQWdCLEtBQUE7RUFDaEIsc0JBQXNCO0VBQ3RCLFdBQVc7RUFDWCxvQkFBb0IsS0FBQTtFQUNwQixZQUFZO0VBQ1osZ0JBQWdCLEtBQUE7RUFDaEIsR0FBRztDQUNMO0FBQ0Y7Ozs7Ozs7Ozs7QUM1TUEsSUFBYSw0QkFBeUMsMkJBQU0sY0FBYyxJQUFJO0FBQ25DLDBCQUEwQixjQUFjOzs7Ozs7O0FDUG5GLFNBQWdCLGdCQUFnQixRQUFRLE9BQU87Q0FDN0MsUUFBUSxXQUFXLG1CQUF3QixXQUFXLGlCQUFzQixPQUFPLFdBQVc7QUFDaEc7Ozs7O0FBTUEsU0FBZ0IsZUFBZSxRQUFRLE9BQU87Q0FDNUMsT0FBTyxXQUFXLHFCQUEwQixnQkFBZ0IsUUFBUSxLQUFLO0FBQzNFOzs7OztBQ2NBLElBQWEsbUJBQW1CLGNBQWMsU0FBUyxpQkFBaUIsT0FBTztDQUM3RSxNQUFNLEVBQ0osVUFDQSxNQUFNLFVBQ04sY0FDQSxzQkFDQSxtQkFBbUIsdUJBQ25CLGNBQWMsT0FDZCxVQUFVLGVBQWUsT0FDekIsT0FBTyxXQUNQLFlBQVksTUFDWixjQUFjLFlBQ2QsWUFDQSxtQkFBbUIsT0FDbkIsUUFDQSxXQUFXLGVBQ1gsa0JBQWtCLHVCQUF1QixNQUN6Qyx1QkFBdUIsTUFDdkIsWUFBWSxPQUNaLGVBQWUsT0FDZixpQkFDQSxjQUFjLE1BQ2Qsc0JBQXNCLFNBQ3BCO0NBQ0osTUFBTSxxQkFBcUIsMEJBQTBCLElBQUk7Q0FDekQsTUFBTSx3QkFBd0IsbUJBQW1CLElBQUk7Q0FDckQsTUFBTSxpQkFBaUIsa0JBQWtCLElBQUk7Q0FJN0MsTUFBTSxxQkFBcUIsdUJBQXVCO0NBQ2xELE1BQU0scUJBQXFCLHVCQUF1QixnQkFBZ0I7Q0FDbEUsTUFBTSxvQkFBQSxhQUEwQixjQUFjO0VBQzVDLElBQUksYUFBYSxvQkFDZixPQUFPO0dBQ0wsTUFBTTtHQUNOLE9BQU87RUFDVDtFQUVGLElBQUksZ0JBQ0YsT0FBTztHQUNMLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFNRixJQUFJLHNCQUFzQixDQUFDLG9CQUN6QixPQUFPO0dBQ0wsTUFBTTtHQUNOLFNBQVM7RUFDWDtFQUVGLE9BQU8sRUFDTCxNQUFNLEtBQUEsRUFDUjtDQUNGLEdBQUc7RUFBQztFQUFvQjtFQUFvQjtFQUFnQjtDQUFTLENBQUM7Q0FDdEUsTUFBTSxTQUFTLFlBQVk7Q0FHM0IsTUFBTSxvQkFBb0IsWUFBWTtDQUN0QyxNQUFNLENBQUMsb0JBQW9CLHlCQUFBLGFBQStCLFNBQVMsS0FBQSxDQUFTO0NBSTVFLE1BQU0sY0FBYyxzQkFBc0Isc0JBQXNCLEtBQUE7Q0FDaEUsTUFBTSxrQ0FBa0Msd0JBQXdCO0NBQ2hFLE1BQU0sa0JBQWtCLGtCQUFrQixTQUFTLFNBQVMsa0JBQWtCLFFBQVEsS0FBQTtDQVN0RixNQUFNLHNCQUFzQixZQUFZLGdCQUFnQixpQkFBaUIsTUFBTSxxQkFBcUI7Q0FLcEcsTUFBTSxvQkFBb0IscUJBQXFCLHFCQUFxQixpQkFBaUIsTUFBTSxjQUFjLEtBQUEsQ0FBUyxDQUFDLENBQUM7Q0FDcEgsTUFBTSxRQUFRLHFCQUFxQjtFQUNqQyxNQUFNLFlBQVksSUFBSSxVQUFVO0dBQzlCLE1BQU07R0FDTjtHQUNBLGlCQUFpQjtHQUNqQjtHQUNBLFFBQVE7R0FDUixVQUFVO0dBQ1Y7R0FDQSxPQUFPLGtCQUFrQixTQUFTLEtBQUEsSUFBWSxZQUFZLEtBQUE7R0FDMUQ7R0FDQSxhQUFhO0VBQ2YsR0FBRyxZQUFZLG1DQUFtQyxJQUFJO0VBRXRELFVBQVUsUUFBUSxrQkFBa0I7RUFDcEMsT0FBTztDQUNULENBQUMsQ0FBQyxDQUFDO0NBQ0gsTUFBTSxrQkFBa0IsWUFBWSxRQUFRO0NBQzVDLE1BQU0sa0JBQWtCLGlCQUFpQixhQUFhO0NBQ3RELE1BQU0sbUJBQW1CLHdCQUF3QixvQkFBb0I7Q0FDckUsTUFBTSxtQkFBbUIsTUFBTSxTQUFTLGtCQUFrQjtDQUMxRCxNQUFNLDRCQUE0QixrQkFBa0IsZ0JBQWdCO0NBQ3BFLE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLHVCQUF1QixNQUFNLFNBQVMsc0JBQXNCO0NBQ2xFLE1BQU0sb0JBQW9CLE1BQU0sU0FBUyxtQkFBbUI7Q0FDNUQsTUFBTSxlQUFlLE1BQU0sU0FBUyxjQUFjO0NBQ2xELE1BQU0sV0FBVyxNQUFNLFNBQVMsVUFBVTtDQUMxQyxNQUFNLHVCQUF1QixNQUFNLFNBQVMsc0JBQXNCO0NBQ2xFLE1BQU0sU0FBUyxNQUFNLFNBQVMsUUFBUTtDQUN0QyxNQUFNLGNBQWMsTUFBTSxTQUFTLGFBQWE7Q0FDaEQsTUFBTSxlQUFlLE1BQU0sU0FBUyxjQUFjO0NBQ2xELE1BQU0sVUFBVSxNQUFNLFNBQVMsU0FBUztDQUN4QyxNQUFNLHVCQUF1QixNQUFNLFNBQVMsc0JBQXNCO0NBQ2xFLE1BQU0sZUFBQSxhQUFxQixPQUFPLElBQUk7Q0FDdEMsTUFBTSxnQ0FBQSxhQUFzQyxPQUFPLE9BQU8sU0FBUyxjQUFjO0NBQ2pGLE1BQU0sb0NBQW9DLFdBQVc7Q0FDckQsTUFBTSx1QkFBQSxhQUE2QixPQUFPLElBQUk7Q0FDOUMsTUFBTSwyQkFBMkIsV0FBVztDQUM1QyxNQUFNLFNBQVMsd0JBQXdCO0NBRXJDLElBQUksT0FBTyxTQUFTLEtBQUEsS0FBYSxjQUFjLEtBQUEsR0FDN0MsUUFBUSxLQUFLLGlGQUFpRjtDQUdsRyxNQUFNLEVBQ0osWUFDQSxjQUFjLHlCQUNaLHVCQUF1QixJQUFJO0NBQy9CLE1BQU0sZ0JBQWdCO0VBQ3BCLFVBQVU7RUFDVjtFQUNBLE9BQU8sT0FBTyxTQUFTLEtBQUEsSUFBWSxZQUFZLEtBQUE7RUFDL0M7RUFDQTtDQUNGLENBQUM7Q0FDRCx5QkFBeUIsS0FBSztDQUM5QixNQUFNLEVBQ0osY0FDQSxxQkFDRSx3QkFBd0IsTUFBTSxhQUFhO0VBQzdDLE1BQU0sSUFBSSxtQkFBbUIsS0FBSztDQUNwQyxHQUFHLGtCQUFrQjtDQUNyQixNQUFNLDBCQUEwQixzQkFBc0IsTUFBTSxRQUFRLFFBQVE7Q0FNNUUsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxzQkFBc0IsS0FBQSxHQUN4QjtFQUVGLE1BQU0sK0JBQStCO0dBQ25DLElBQUksTUFBTSxNQUFNLGdCQUFnQixtQkFDOUIsTUFBTSxJQUFJLGVBQWUsS0FBQSxDQUFTO0VBRXRDO0VBT0EsSUFBSSxDQUFDLE1BQU07R0FDVCx1QkFBdUI7R0FDdkI7RUFDRjtFQUNBLElBQUkscUJBQXFCLEtBQUEsR0FDdkI7RUFPRixJQUFJLE1BQU0sUUFBUSxTQUFTLFdBQVcsTUFBTTtHQUMxQyx1QkFBdUI7R0FDdkI7RUFDRjtFQUNBLE1BQU0sa0JBQWtCLElBQUksZ0JBQWdCO0VBQzVDLHdCQUF3Qix3QkFBd0IsZ0JBQWdCLE1BQU07RUFDdEUsYUFBYTtHQUNYLGdCQUFnQixNQUFNO0VBQ3hCO0NBQ0YsR0FBRztFQUFDO0VBQW1CO0VBQU07RUFBa0I7RUFBeUI7Q0FBSyxDQUFDO0NBQzlFLHlCQUF5QjtFQUN2QixJQUFJLHNCQUFzQixDQUFDLHVCQUd6QixNQUFNLE9BQU87R0FDWCxRQUFRO0lBQ04sTUFBTTtJQUNOLFNBQVM7R0FDWDtHQUNBLGdCQUFnQjtHQUNoQixzQkFBc0I7RUFDeEIsQ0FBQztPQUNJLElBQUkseUJBQXlCLENBQUMsTUFBTSxPQUFPLHNCQUFzQixHQUd0RSxNQUFNLE9BQU87R0FDWCxnQkFBZ0I7R0FDaEIsc0JBQXNCO0VBQ3hCLENBQUM7Q0FFTCxHQUFHO0VBQUM7RUFBb0I7RUFBdUI7RUFBMkI7RUFBaUM7RUFBc0I7Q0FBSyxDQUFDO0NBQ3ZJLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksQ0FBQyxNQUNILGFBQWEsVUFBVTtFQUV6QixJQUFJLE9BQU8sU0FBUyxnQkFDbEI7RUFFRixJQUFJLENBQUMsTUFBTTtHQUNULGtDQUFrQyxNQUFNO0dBQ3hDLDhCQUE4QixVQUFVO0dBQ3hDO0VBQ0Y7RUFLQSxrQ0FBa0MsTUFBTSxXQUFXO0dBQ2pELDhCQUE4QixVQUFVO0VBQzFDLENBQUM7Q0FDSCxHQUFHO0VBQUM7RUFBbUM7RUFBTSxPQUFPO0NBQUksQ0FBQztDQUN6RCx5QkFBeUI7RUFDdkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxjQUNaLE1BQU0sSUFBSSxnQkFBZ0IsSUFBSTtDQUVsQyxHQUFHO0VBQUM7RUFBTTtFQUFjO0NBQUssQ0FBQztDQUM5QixNQUFNLFVBQVUsbUJBQW1CLFVBQVUsaUJBQWlCO0VBQzVELE1BQU0sU0FBUyxhQUFhO0VBSTVCLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxPQUFPLE1BQU0sR0FDbkM7RUFFRixJQUFJLFNBQVMsWUFBWSxhQUFhLFlBQVksd0JBQXdCLHlCQUF5QixRQUNqRztFQUVGLE1BQU0sOEJBQThCLDRCQUE0QixZQUFZO0VBSTVFLElBQUksQ0FBQyxZQUFZLGFBQWEsV0FBVyxNQUN2QyxhQUFhLFVBQVUsd0JBQXdCLEtBQUE7RUFFakQsZUFBZSxVQUFVLFlBQVk7RUFDckMsSUFBSSxhQUFhLFlBQ2Y7RUFFRixNQUFNLE1BQU0sb0JBQW9CLG1CQUFtQixVQUFVLFlBQVk7RUFDekUsTUFBTSxjQUFjLGFBQWE7RUFDakMsSUFBSSxhQUFhLFNBQVMsV0FBVyxnQkFBcUIsYUFBYSxTQUFTLFdBQVcsWUFBWSxnQkFBZ0IsV0FBVyxDQUFDLHFCQUFxQixTQUN0SjtFQU1GLElBQUksWUFBWSxXQUFXLGlCQUFzQjtHQUMvQyxxQkFBcUIsVUFBVTtHQUMvQix5QkFBeUIsTUFBTSxXQUFXO0lBQ3hDLHFCQUFxQixVQUFVO0dBQ2pDLENBQUM7RUFDSCxPQUFPO0dBQ0wscUJBQXFCLFVBQVU7R0FDL0IseUJBQXlCLE1BQU07RUFDakM7RUFDQSxNQUFNLGlCQUFpQixDQUFDLGFBQWEsV0FBVyxnQkFBcUIsVUFBVTtFQUMvRSxhQUFhLFVBQVUsYUFBYTtFQUNwQyxNQUFNLGlCQUFpQixxQkFBcUIsTUFBTSxPQUFPLFVBQVUsYUFBYSxTQUFTLDRCQUE0QixDQUFDO0VBQ3RILGVBQWUsbUJBQW1CO0VBQ2xDLGVBQWUsZUFBZSxZQUFZLGVBQWUsUUFBUSxXQUFXO0VBQzVFLElBQUksT0FBTyxTQUFTLGNBQWMsV0FBVyxtQkFBd0IsV0FBVyxlQUFvQixXQUFXLG1CQUF3QixXQUFXLHFCQUEwQixXQUFXLGlCQUNyTCxlQUFlLGNBQWM7T0FDeEIsSUFBSSxnQkFBZ0IsUUFBUSxXQUFXLEdBQzVDLGVBQWUsY0FBYztPQUN4QixJQUFJLGdCQUNULGVBQWUsY0FBYztPQUU3QixlQUFlLGNBQWMsS0FBQTtFQU8vQixNQUFNLE9BQU8sY0FBYztDQUM3QixDQUFDO0NBQ0QsTUFBTSxzQkFBc0IsNkJBQTZCO0VBQ3ZELFlBQVk7RUFDWixxQkFBcUIsTUFBTSxNQUFNO0VBQ2pDO0VBQ0EsUUFBUSxtQ0FBbUM7RUFDM0MsY0FBYztDQUNoQixDQUFDO0NBQ0QsTUFBTSxpQkFBaUIsb0JBQW9CLFFBQVE7Q0FLbkQseUJBQXlCO0VBQ3ZCLE1BQU0sc0JBQXNCLEVBQzFCLE1BQU0sVUFDTixtQkFDSSxRQUFRLFVBQVUsWUFBWTtFQUNwQyxlQUFlLEdBQUcsV0FBVyxrQkFBa0I7RUFDL0MsYUFBYTtHQUNYLGdCQUFnQixJQUFJLFdBQVcsa0JBQWtCO0VBQ25EO0NBQ0YsR0FBRyxDQUFDLGdCQUFnQixPQUFPLENBQUM7Q0FDNUIseUJBQXlCLE1BQU0sc0JBQXNCLEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FDL0QsTUFBTSx3QkFBQSxhQUE4QixrQkFBa0I7RUFDcEQsTUFBTSxRQUFRLE9BQU8seUJBQXlCRSxnQkFBd0IsQ0FBQztDQUN6RSxHQUFHLENBQUMsS0FBSyxDQUFDO0NBQ1YsYUFBTSxvQkFBb0IsbUJBQW1CO0VBQzNDLFNBQVM7RUFDVCxPQUFPO0NBQ1QsSUFBSSxDQUFDLGNBQWMscUJBQXFCLENBQUM7Q0FDekMsSUFBSTtDQUNKLElBQUksT0FBTyxTQUFTLGdCQUNsQixNQUFNLE9BQU87Q0FFZixhQUFNLG9CQUFvQixLQUFLLHFCQUFxQixtQkFBbUIsQ0FBQyxpQkFBaUIsQ0FBQztDQUMxRixhQUFNLG9CQUFvQixLQUFLLG1CQUFtQixFQUNoRCxRQUNGLElBQUksQ0FBQyxPQUFPLENBQUM7Q0FDYixNQUFNLFVBQVUsV0FBVyxxQkFBcUI7RUFDOUMsU0FBUyxDQUFDO0VBQ1YsU0FBUyxFQUNQLFdBQVcsb0JBQW9CLE9BQU8sU0FBUyxPQUNqRDtFQUNBLGVBQWU7R0FDYixJQUFJLE9BQU8sU0FBUyxrQkFBa0IsYUFBYSxTQUFTLFNBQVMsZUFDbkUsT0FBTztHQUVULE9BQU8sOEJBQThCO0VBQ3ZDO0VBQ0EsY0FBYyxTQUFTLG1CQUFtQixLQUFBO0NBQzVDLENBQUM7Q0FDRCxNQUFNLFlBQVksYUFBYTtDQUMvQixNQUFNQyxtQkFBaUIsa0JBQWtCLHFCQUFxQjtFQUM1RCxTQUFTLENBQUM7RUFDVixTQUFTLE1BQU0sUUFBUTtFQUN2QjtFQUNBLFNBQVM7RUFDVCxRQUFRLE9BQU8sU0FBUyxhQUFhLENBQUMsZ0JBQWdCLE9BQU8sU0FBUyxLQUFBO0VBQ3RFLG1CQUFtQixPQUFPLFNBQVMsWUFBWSxPQUFPLFFBQVEsY0FBYyxLQUFBO0VBQzVFO0VBSUEsaUJBQWlCLGVBQWUsZUFBZSxLQUFBO0VBQy9DLGFBQWEsZ0JBQWdCLGFBQWE7RUFDMUM7RUFHQSxvQkFBb0IsZUFBZSxhQUFhO0VBQ2hELEtBQUssY0FBYztFQUNuQixpQkFBaUI7RUFDakIsV0FBVyxpQkFBaUIsT0FBTztHQUNqQyxNQUFNLGVBQWUsaUJBQWlCLG1CQUFtQixLQUFLLEdBQUcsT0FBTyxXQUFXO0VBQ3JGO0VBSUEsb0JBQW9CLE9BQU8sU0FBUyxrQkFBa0IsRUFBRSxnQkFBZ0I7RUFDeEUsY0FBYyxDQUFDLGdCQUFnQixTQUFTLG1CQUFtQixLQUFBO0VBQzNELHNCQUFzQixpQkFBaUIsUUFBUTtFQUMvQyxrQkFBa0I7RUFDbEI7Q0FDRixDQUFDO0NBQ0QsTUFBTSxXQUFBLGFBQWlCLGFBQVksZUFBYztFQUMvQyxNQUFNLFFBQVEsVUFBVSxVQUFVO0NBQ3BDLEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FDVixNQUFNLFlBQVksYUFBYSxxQkFBcUI7RUFFbEQsU0FBUyxDQUFDLFlBQVksQ0FBQztFQUN2QixTQUFTLE1BQU0sUUFBUTtFQUN2QixhQUFhLE1BQU0sUUFBUTtFQUMzQjtFQUNBLFNBQUE7RUFDQSxVQUFVLE9BQU8sVUFBVTtHQUN6QixJQUFJLFFBQVEsVUFBVSxhQUNwQixNQUFNLGVBQWUsT0FBT0MsVUFBa0IsTUFBTSxXQUFXO0VBRW5FO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsTUFBTSxvQkFBb0Isa0JBQWtCLHFCQUFxQjtDQUNqRSxNQUFNLHdCQUFBLGFBQThCLE9BQU8sRUFBRTtDQUk3QyxNQUFNLHNCQUFzQix3QkFBd0I7RUFDbEQsTUFBTSxRQUFRLE1BQU0sTUFBTTtFQUMxQixNQUFNLE9BQU8sVUFBVSxPQUFPLEtBQUEsSUFBWSxNQUFNLFFBQVEsZ0JBQWdCLFFBQVEsVUFBVSxLQUFBO0VBRzFGLElBQUksTUFBTSxnQkFBZ0IsT0FDeEI7RUFFRixNQUFNLFlBQVksU0FBUyxLQUFBLElBQVksS0FBSztFQUM1QyxJQUFJLHNCQUFzQixZQUFZLGFBQWEsTUFBTSxRQUFRLGlCQUFpQixNQUNoRjtFQUVGLHNCQUFzQixVQUFVO0VBQ2hDLE1BQU0sUUFBUSxlQUFlO0VBRzdCLElBQUksY0FDRixNQUFNLElBQUksbUJBQW1CLElBQUk7RUFHbkMsTUFBTSxFQUNKLGlCQUNBLG1CQUNFLE1BQU07RUFDVixNQUFNLFFBQVEsa0JBQWtCQztFQUNoQyxNQUFNLFFBQVEsaUJBQWlCLEtBQUE7RUFDL0IsSUFBSSxDQUFDLHVCQUNIO0VBRUYsa0JBQWtCLE1BQU0sMEJBQTBCLGlCQUFpQixnQkFBZ0IsRUFDakYsT0FBTyxTQUFTLEtBQUEsSUFBWSxLQUFBLElBQVksTUFBTSxRQUFRLFdBQVcsUUFBUSxjQUFjLEtBQUEsRUFDekYsQ0FBQyxDQUFDO0NBQ0osQ0FBQztDQUNELHlCQUF5QjtFQUN2QixvQkFBb0I7Q0FDdEIsR0FBRyxDQUFDLGFBQWEsbUJBQW1CLENBQUM7Q0FLckMsTUFBTSxtQkFBQSxhQUF5QixjQUFjO0VBQzNDLElBQUksQ0FBQyxjQUNILE9BQU9GLGlCQUFlO0VBRXhCLElBQUksQ0FBQ0EsaUJBQWUsU0FDbEIsT0FBTztFQUlULE1BQU0sRUFDSixTQUNBLEdBQUcsU0FDREEsaUJBQWU7RUFDbkIsT0FBTztDQUNULEdBQUc7RUFBQztFQUFjQSxpQkFBZTtFQUFXQSxpQkFBZTtDQUFPLENBQUM7Q0FDbkUsTUFBTSxlQUFlLGNBQWMsZUFBZUEsaUJBQWUsYUFBYSxlQUFlLFlBQVk7Q0FDekcsTUFBTSxxQkFBQSxhQUEyQixjQUFjO0VBQzdDLE1BQU0sY0FBYyxXQUFXLFVBQVUsV0FBVyxrQkFBa0IsUUFBUSxXQUFXLEVBQ3ZGLGNBQWM7R0FDWixNQUFNLElBQUksbUJBQW1CLElBQUk7RUFDbkMsRUFDRixHQUFHLG9CQUFvQjtFQUN2QixZQUFZLG1CQUFtQjtFQUMvQixZQUFZLG1CQUFtQjtFQUMvQixPQUFPO0NBQ1QsR0FBRztFQUFDO0VBQU8sVUFBVTtFQUFXO0VBQWtCLFFBQVE7RUFBVztFQUFzQjtDQUFJLENBQUM7Q0FDaEcsTUFBTSx1QkFBQSxhQUE2QixjQUFjO0VBQy9DLE1BQU0sY0FBYyxXQUFXQSxpQkFBZSxTQUFTLFFBQVEsU0FBUyxvQkFBb0I7RUFDNUYsWUFBWSxtQkFBbUI7RUFDL0IsWUFBWSxtQkFBbUI7RUFDL0IsT0FBTztDQUNULEdBQUc7RUFBQ0EsaUJBQWU7RUFBUyxRQUFRO0VBQVM7Q0FBb0IsQ0FBQztDQUlsRSxxQkFBcUI7RUFDbkIsTUFBTSxPQUFPLEVBQ1gscUJBQ0YsQ0FBQztFQUNELE9BQU87Q0FDVCxDQUFDO0NBQ0QsTUFBTSxhQUFBLGFBQW1CLGNBQWMsV0FBVyx1QkFBdUI7RUFDdkUsY0FBYztHQUNaLE1BQU0sSUFBSSxtQkFBbUIsSUFBSTtHQUNqQyxJQUFJLE9BQU8sU0FBUyxRQUNsQixNQUFNLElBQUksZ0JBQWdCLEtBQUs7RUFFbkM7RUFDQSxVQUFVO0dBQ1IsSUFBSSxNQUFNLE9BQU8sY0FBYyxHQUM3QixNQUFNLElBQUksZ0JBQWdCLEtBQUs7RUFFbkM7RUFDQSxVQUFVLE9BQU87R0FJZixNQUFNLFFBQVEsTUFBTSxPQUFPLG9CQUFvQjtHQUMvQyxJQUFJLFNBQVMsQ0FBQyxNQUFNLHFCQUFxQixHQUN2QyxNQUFNLEtBQUs7RUFFZjtDQUNGLEdBQUcsVUFBVSxVQUFVQSxpQkFBZSxVQUFVLFFBQVEsUUFBUSxHQUFHO0VBQUMsT0FBTztFQUFNO0VBQU8sVUFBVTtFQUFVQSxpQkFBZTtFQUFVLFFBQVE7Q0FBUSxDQUFDO0NBQ3RKLE1BQU0sWUFBWUEsaUJBQWUsUUFBUTtDQUN6Qyx5QkFBeUIsT0FBTztFQUM5QjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsQ0FBQztDQUNELE1BQU0sVUFBQSxhQUFnQixlQUFlO0VBQ25DO0VBQ0EsUUFBUTtFQUNSO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRixJQUFJO0VBQUM7RUFBTztFQUFtQjtFQUFhO0VBQVc7RUFBYTtFQUFtQjtFQUFjO0VBQW9CO0NBQW1CLENBQUM7Q0FDN0ksTUFBTSxtQkFBbUIsT0FBTyxhQUFhLGFBQWEsU0FBUyxFQUNqRSxRQUNGLENBQUMsSUFBSTtDQUNMLElBQUksVUFBdUIsZUFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBTSxnQkFBZ0IsVUFBVTtFQUN6RCxPQUFPO0VBQ1AsVUFBVSxDQUFDLFVBQXVCLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssdUJBQXVCO0dBQ3BEO0dBQ0Q7RUFDVCxDQUFDLEdBQUcsZ0JBQWdCO0NBQ3RCLENBQUM7Q0FDRCxJQUFJLE9BQU8sU0FBUyxLQUFBLEtBQWEsT0FBTyxTQUFTLGdCQUUvQyxVQUF1QixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGNBQWM7RUFDeEMsY0FBYztFQUNkLFVBQVU7Q0FDWixDQUFDO0NBRUgsT0FBTztBQUNULENBQUM7QUFRMEMsaUJBQWlCLGNBQWM7QUFDMUUsU0FBZ0IsU0FBUyxPQUFPO0NBQzlCLE1BQU0saUJBQUEsYUFBdUIsV0FBVyx5QkFBeUI7Q0FDakUsSUFBSSxtQkFBbUIsTUFDckIsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxrQkFBa0IsRUFDekMsR0FBRyxNQUNMLENBQUM7Q0FFSCxNQUFNLGFBQWEsZUFBZTtDQUNsQyxPQUdFLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssMEJBQTBCLFVBQVU7RUFDdkMsT0FBTztFQUNQLFVBQXVCLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssWUFBWTtHQUN0QyxHQUFHLGVBQWU7R0FDbEIsR0FBRztFQUNMLENBQUM7Q0FDSCxDQUFDO0FBRUw7O0FDaGxCQSxJQUFNLDZCQUE2QixDQUFDOzs7Ozs7O0FBUXBDLFNBQWdCLGdCQUFnQixPQUFPO0NBRXJDLG1CQUFtQjtDQUNuQixNQUFNLGlCQUFBLGFBQXVCLFdBQVcseUJBQXlCO0NBQ2pFLElBQUksbUJBQW1CLE1BQU07RUFDM0IsTUFBTSxvQkFBb0IsZUFBZTtFQUN6QyxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLDBCQUEwQixVQUFVO0dBQzNELE9BQU87R0FDUCxVQUF1QixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLG1CQUFtQjtJQUM3QyxHQUFHLGVBQWU7SUFDbEIsR0FBRztHQUNMLENBQUM7RUFDSCxDQUFDO0NBQ0g7Q0FDQSxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLHVCQUF1QixVQUFVO0VBQ3hELE9BQU87RUFDUCxVQUF1QixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGtCQUFrQjtHQUM1QyxHQUFHO0dBQ0gsV0FBVztFQUNiLENBQUM7Q0FDSCxDQUFDO0FBQ0g7O0FDckNBLFNBQWdCLGdCQUFnQixNQUFNO0NBQ3BDLElBQUksY0FBYyxJQUFJLEtBQUssS0FBSyxhQUFhLGtCQUFrQixHQUM3RCxPQUFPLEtBQUssYUFBYSxrQkFBa0I7Q0FFN0MsSUFBSSxzQkFBc0IsSUFBSSxHQUM1QjtDQUVGLE9BQU8sZ0JBQWdCLGNBQWMsSUFBSSxDQUFDO0FBQzVDOzs7Ozs7Ozs7Ozs7OztBQ1VBLFNBQWdCLHNCQUFzQixPQUFPLG1CQUFtQjtDQUM5RCxTQUFTLGNBQWMsT0FBTyxXQUFXLG1CQUFtQjtFQUMxRCxNQUFNLFFBQVEsTUFBTTtFQUNwQixpQkFBUyxnQkFBZ0I7R0FDdkIsTUFBTSxRQUFRLE9BQU8seUJBQXlCRyxVQUFrQixNQUFNLGFBQWEsS0FBSyxDQUFDO0VBQzNGLENBQUM7RUFJRCx1QkFBdUIsTUFBTSxjQUFjLFFBQVEsa0JBQWtCLFNBQVMsV0FBVyxpQkFBaUIsQ0FBQyxFQUFFLE1BQU07Q0FDckg7Q0FDQSxTQUFTLHlCQUF5QixPQUFPO0VBQ3ZDLGNBQWMsT0FBTyxJQUFJLE1BQU0sT0FBTyxtQkFBbUIsQ0FBQztDQUM1RDtDQUNBLFNBQVMsdUJBQXVCLE9BQU87RUFDckMsTUFBTSxvQkFBb0IsTUFBTSxPQUFPLG1CQUFtQjtFQUMxRCxJQUFJLHFCQUFxQixlQUFlLE9BQU8saUJBQWlCLEdBQzlELE1BQU0sUUFBUSwyQkFBMkIsU0FBUyxNQUFNO09BRXhELGNBQWMsT0FBTyxHQUFHLGlCQUFpQjtDQUU3QztDQUNBLE9BQU87RUFDTDtFQUNBO0NBQ0Y7QUFDRjs7Ozs7OztBQ25DQSxTQUFnQiwyQkFBMkIsUUFBUTtDQUNqRCxNQUFNLEVBQ0osVUFBVSxNQUNWLGlCQUNBLFNBQ0U7Q0FDSixNQUFNLGlCQUFBLGFBQXVCLE9BQU8sS0FBSztDQUN6QyxPQUFBLGFBQWEsY0FBYztFQUN6QixJQUFJLENBQUMsU0FDSCxPQUFPO0VBRVQsT0FBTztHQUNMLGNBQWEsVUFBUztJQUNwQixJQUFJLG9CQUFvQixVQUFVLENBQUMsUUFBUSxvQkFBb0IsV0FBVyxNQUFNO0tBQzlFLGVBQWUsVUFBVTtLQUN6QixjQUFjLE1BQU0sYUFBYSxDQUFDLENBQUMsaUJBQWlCLGVBQWU7TUFDakUsZUFBZSxVQUFVO0tBQzNCLEdBQUcsRUFDRCxNQUFNLEtBQ1IsQ0FBQztJQUNIO0dBQ0Y7R0FDQSxVQUFTLFVBQVM7SUFDaEIsSUFBSSxlQUFlLFNBQVM7S0FDMUIsZUFBZSxVQUFVO0tBQ3pCLE1BQU0scUJBQXFCO0lBQzdCO0dBQ0Y7RUFDRjtDQUNGLEdBQUc7RUFBQztFQUFTO0VBQWlCO0NBQUksQ0FBQztBQUNyQzs7Ozs7Ozs7QUNGQSxJQUFhLGNBQWMsaUJBQWlCLFNBQVMsWUFBWSxnQkFBZ0IsY0FBYztDQUM3RixNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsVUFBVSxlQUFlLE9BQ3pCLGVBQWUsTUFDZixJQUFJLFFBQ0osYUFBYSxpQkFDYixRQUFRLEtBQ1IsYUFBYSxHQUNiLFFBQ0EsU0FDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxjQUFjLG1CQUFtQixJQUFJO0NBRTNDLE1BQU0sUUFEYyxvQkFBb0IsTUFDaEIsS0FBSyxhQUFhO0NBQzFDLElBQUksQ0FBQyxPQUNILE1BQU0sSUFBSSxNQUE4Qyx1R0FBaUk7Q0FFM0wsTUFBTSxnQkFBZ0IsWUFBWSxNQUFNO0NBQ3hDLE1BQU0sa0JBQWtCLE1BQU0sU0FBUyxtQkFBbUIsYUFBYTtDQUN2RSxNQUFNLHNCQUFzQixNQUFNLFNBQVMscUJBQXFCO0NBQ2hFLE1BQU0sd0JBQXdCLE1BQU0sU0FBUyxxQkFBcUIsYUFBYTtDQUMvRSxNQUFNLGFBQWEsTUFBTSxTQUFTLHFCQUFxQixhQUFhO0NBQ3BFLE1BQU0sb0JBQUEsYUFBMEIsT0FBTyxJQUFJO0NBQzNDLE1BQU0sU0FBUyxjQUFjO0NBQzdCLE1BQU0sdUJBQXVCLHdCQUF3QixJQUFJO0NBQ3pELE1BQU0sOEJBQThCLGdCQUFnQjtDQUNwRCxNQUFNLG1CQUFBLGFBQXlCLGNBQWM7RUFDM0MsT0FBTywrQkFBK0IsSUFBSSxrQkFBa0I7Q0FDOUQsR0FBRyxDQUFDLDJCQUEyQixDQUFDO0NBQ2hDLE1BQU0saUJBQWlCLGtCQUFrQixnQkFBZ0I7Q0FDekQsTUFBTSx1QkFBdUIsd0JBQXdCO0NBQ3JELE1BQU0sRUFDSixpQkFDQSwyQkFDRSx5QkFBeUIsZUFBZSxtQkFBbUIsT0FBTztFQUNwRTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxvQkFBb0Isc0JBQXNCO0NBQzVDLENBQUM7Q0FDRCxNQUFNLGNBQWMsT0FBTyxTQUFTO0NBQ3BDLE1BQU0sZUFBZSxNQUFNLFNBQVMsVUFBVTtDQUM5QyxNQUFNLFdBQVcsZ0JBQWdCLGdCQUFnQixlQUFlLE9BQU8sUUFBUTtDQUMvRSxNQUFNLEVBQ0osZ0JBQ0EsY0FDRSxVQUFVO0VBQ1o7RUFDQSxRQUFRO0NBQ1YsQ0FBQztDQUNELGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksQ0FBQyx5QkFBeUIsT0FBTyxTQUFTLEtBQUEsR0FDNUMsTUFBTSxRQUFRLHVCQUF1QixVQUFVO0NBRW5ELEdBQUc7RUFBQztFQUFPO0VBQXVCLE9BQU87Q0FBSSxDQUFDO0NBQzlDLE1BQU0sYUFBQSxhQUFtQixPQUFPLElBQUk7Q0FDcEMsTUFBTSw2QkFBNkIsV0FBVztDQUM5QyxNQUFNLHdCQUF3QixtQkFBa0IsZUFBYztFQUM1RCxJQUFJLENBQUMsV0FBVyxTQUNkO0VBRUYsMkJBQTJCLE1BQU07RUFDakMsTUFBTSxRQUFRLHVCQUF1QixVQUFVO0VBQy9DLE1BQU0sZ0JBQWdCLFdBQVc7RUFDakMsSUFBSSxTQUFTLFdBQVcsU0FBUyxhQUFhLEtBQUssU0FBUyxNQUFNLE9BQU8sbUJBQW1CLEdBQUcsYUFBYSxLQUFLLGtCQUFrQixXQUFXLFNBQzVJO0VBRUYsSUFBSSxpQkFBaUIsUUFBUSxnQkFBZ0IsYUFBYSxNQUFNLE1BQU0sT0FBTyxRQUFRLEdBQ25GO0VBRUYsSUFBSSxvQkFBb0IsWUFBWSxXQUFXLE9BQU8sR0FDcEQ7RUFFRixpQkFBaUIsT0FBTyxLQUFLLFNBQVM7R0FDcEMsVUFBVTtHQUNWLFFBQVFDO0VBQ1YsQ0FBQztDQUNILENBQUM7Q0FDRCxhQUFNLGdCQUFnQjtFQUNwQixNQUFNLE1BQU0sY0FBYyxXQUFXLE9BQU87RUFDNUMsSUFBSSx5QkFBeUIsTUFBTSxPQUFPLHNCQUFzQixNQUFNLGlCQUFzQjtHQUMxRixJQUFJLGlCQUFpQixXQUFXLHVCQUF1QixFQUNyRCxNQUFNLEtBQ1IsQ0FBQztHQUNELGFBQWE7SUFDWCxJQUFJLG9CQUFvQixXQUFXLHFCQUFxQjtHQUMxRDtFQUNGO0NBRUYsR0FBRztFQUFDO0VBQXVCO0VBQXVCO0NBQUssQ0FBQztDQUN4RCxNQUFNLDhCQUE4QixlQUFlLE9BQU8sUUFBUTtDQUVsRSxNQUFNLGFBQWEsNkJBQTZCLHFCQUFxQjtFQUNuRSxVQUZrQixtQkFBbUIsZ0NBRWIsQ0FBQyxhQUFhLENBQUMsZUFBZSwrQkFBK0IsQ0FBQztFQUN0RixhQUFhLFlBQVksRUFDdkIsb0JBQW9CLENBQUMsWUFDdkIsQ0FBQztFQUNELFdBQVc7RUFDWCxNQUFNO0VBQ04sUUFBUSxPQUFPLFNBQVMsS0FBQSxJQUFZLFFBQVEsS0FBQTtFQUM1QyxPQUFPLEVBQ0wsT0FBTyxXQUNUO0VBQ0E7RUFDQSxjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLGlCQUFpQixNQUFNLE9BQU8sa0JBQWtCLE1BQU07Q0FDeEQsQ0FBQztDQUtELE1BQU0sY0FBYyxlQUFlLHVCQUF1QixNQUFNLE9BQU8sc0JBQXNCLENBQUM7Q0FDOUYsTUFBTSxRQUFRLFNBQVMscUJBQXFCO0VBQzFDLFNBQVMsQ0FBQztFQUNWLE9BQU8seUJBQXlCLGNBQWMsVUFBVTtFQUN4RCxRQUFRO0VBQ1IsYUFBYTtFQUNiLGFBQWEsT0FBTyxTQUFTLEtBQUEsSUFBWSxjQUFjO0NBQ3pELENBQUM7Q0FDRCxNQUFNLFFBQVEsU0FBUyxxQkFBcUIsRUFDMUMsU0FBUyxDQUFDLFlBQVksNEJBQ3hCLENBQUM7Q0FDRCxNQUFNLHNCQUFzQiwyQkFBMkI7RUFDckQsTUFBTTtFQUNOLFNBQVM7RUFDVCxpQkFBaUI7Q0FDbkIsQ0FBQztDQUNELE1BQU0sd0JBQUEsYUFBOEIsY0FBYyxXQUFXLE1BQU0sV0FBVyxNQUFNLFNBQVMsR0FBRyxDQUFDLE1BQU0sV0FBVyxNQUFNLFNBQVMsQ0FBQztDQUNsSSxNQUFNLG1CQUFtQixNQUFNLFNBQVMsZ0JBQWdCLHNCQUFzQjtDQUU5RSxNQUFNLHFCQUFxQixNQUFNLFNBQVMsb0JBQW9CO0NBQzlELE1BQU0sRUFDSiwwQkFDQSwyQkFDRSxzQkFBc0IsT0FBTyxpQkFBaUI7Q0FDbEQsTUFBTSxRQUFRO0VBQ1o7RUFDQSxNQUFNO0NBQ1I7Q0FDQSxNQUFNLE1BQU07RUFBQztFQUFZO0VBQWM7RUFBVztFQUFpQjtDQUFpQjtDQUNwRixNQUFNLFFBQVE7RUFBQztFQUF1QixjQUFjO0VBQWM7RUFBa0I7R0FDbEYsaUJBQWlCO0dBQ2pCLGlCQUFpQjtHQUNqQixJQUFJO0dBQ0osY0FBYSxVQUFTO0lBQ3BCLElBQUksTUFBTSxPQUFPLE1BQU0sR0FDckI7SUFJRiwyQkFBMkIsTUFBTSxXQUFXO0tBQzFDLE1BQU0sUUFBUSx1QkFBdUIsVUFBVTtJQUNqRCxDQUFDO0lBRUQsY0FEMEIsTUFBTSxhQUM5QixDQUFDLENBQUMsaUJBQWlCLFdBQVcsdUJBQXVCLEVBQ3JELE1BQU0sS0FDUixDQUFDO0dBQ0g7RUFDRjtFQUFHO0VBQW9CLGNBQWMsRUFDbkMsTUFBTSxXQUNSLElBQUksQ0FBQztFQUFHO0VBQXFCO0VBQWM7Q0FBYztDQUN6RCxNQUFNLFVBQVUsaUJBQWlCLFVBQVUsZ0JBQWdCO0VBQ3pELFNBQVMsQ0FBQztFQUNWLHdCQUF3QjtFQUN4QjtFQUNBO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsSUFBSSxhQUNGLE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssZUFBZTtFQUN0QyxLQUFLO0VBQ0c7RUFDRztFQUNKO0VBQ0E7RUFDUCxNQUFNO0VBQ0M7RUFDUCx3QkFBd0I7Q0FDMUIsQ0FBQztDQU1ILElBQUksdUJBQ0YsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBQSxhQUFZLFVBQVUsRUFDeEMsVUFBVTtFQUFjLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssWUFBWTtHQUN2QyxLQUFLLE1BQU0sUUFBUTtHQUNuQixTQUFTO0VBQ1gsR0FBRyxHQUFHLGNBQWMsaUJBQWlCO0VBQWdCLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUEsYUFBVyxVQUFVLEVBQ3hFLFVBQVUsUUFDWixHQUFHLGFBQWE7RUFBZ0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxZQUFZO0dBQy9DLEtBQUssTUFBTSxRQUFRO0dBQ25CLFNBQVM7RUFDWCxHQUFHLEdBQUcsY0FBYyxrQkFBa0I7Q0FBQyxFQUN6QyxDQUFDO0NBRUgsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBQSxhQUFXLFVBQVUsRUFDdkMsVUFBVSxRQUNaLEdBQUcsYUFBYTtBQUNsQixDQUFDO0FBQzBDLFlBQVksY0FBYzs7OztBQUlyRSxTQUFTLGVBQWUsTUFBTSxZQUFZO0NBQ3hDLE1BQU0scUJBQXFCLFdBQVc7Q0FDdEMsTUFBTSxDQUFDLGFBQWEsa0JBQUEsYUFBd0IsU0FBUyxLQUFLO0NBQzFELHlCQUF5QjtFQUN2QixJQUFJLFFBQVEsZUFBZSxpQkFBc0I7R0FHL0MsZUFBZSxJQUFJO0dBQ25CLG1CQUFtQixNQUFBLFdBQXFDO0lBQ3RELGVBQWUsS0FBSztHQUN0QixDQUFDO0VBQ0gsT0FBTyxJQUFJLENBQUMsTUFBTTtHQUNoQixtQkFBbUIsTUFBTTtHQUN6QixlQUFlLEtBQUs7RUFDdEI7Q0FDRixHQUFHO0VBQUM7RUFBTTtFQUFZO0NBQWtCLENBQUM7Q0FDekMsT0FBTztBQUNUO0FBQ0EsU0FBUyxnQkFBZ0I7Q0FDdkIsTUFBTSxpQkFBaUIsa0JBQWtCLElBQUk7Q0FZN0MsT0FBQSxhQVhxQixjQUFjO0VBQ2pDLElBQUksZ0JBQ0YsT0FBTztHQUNMLE1BQU07R0FDTixTQUFTO0VBQ1g7RUFFRixPQUFPLEVBQ0wsTUFBTSxLQUFBLEVBQ1I7Q0FDRixHQUFHLENBQUMsY0FBYyxDQUNOO0FBQ2Q7Ozs7Ozs7Ozs7QUMzUUEsSUFBYSxlQUE0QiwyQkFBTSxXQUFXLFNBQVMsYUFBYSxnQkFBZ0IsY0FBYztDQUM1RyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsVUFDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxFQUNKLFVBQ0UsbUJBQW1CO0NBQ3ZCLE1BQU0sRUFDSixTQUNFLHlCQUF5QjtDQUM3QixNQUFNLGNBQWMsTUFBTSxTQUFTLGFBQWE7Q0FDaEQsTUFBTSxFQUNKLFVBQVUsa0JBQ1YsT0FBTyxrQkFDTCxpQkFBaUI7RUFDbkI7RUFDQTtFQUNBO0NBQ0YsQ0FBQztDQUNELE1BQU0sUUFBUTtFQUNaLHFCQUFxQixjQUFjO0VBQ25DLGVBQWUsY0FBYztFQUM3QixTQUFTO0NBQ1g7Q0FDQSxPQUFPLGlCQUFpQixPQUFPLGdCQUFnQjtFQUM3QztFQUNBLEtBQUs7RUFDTCxPQUFPLENBQUMsY0FBYyxFQUNwQixVQUFVLGlCQUNaLENBQUM7RUFDRCx3QkFBd0I7Q0FDMUIsQ0FBQztBQUNILENBQUM7QUFDMEMsYUFBYSxjQUFjOztBQzFCdEUsSUFBTSw0QkFBNEIsRUFDaEMsaUJBQWlCLEtBQUEsRUFDbkI7QUFDQSxJQUFNLDBCQUF1QywyQkFBTSxXQUFXLFNBQVMsd0JBQXdCLGdCQUFnQixjQUFjO0NBQzNILE1BQU0sRUFDSixRQUNBLFdBQ0EsT0FDQSxPQUNBLElBQUksUUFDSixlQUFlLE9BQ2YsY0FBYyxNQUNkLFFBQVEsS0FDUixhQUFhLEdBQ2IsVUFBVSxlQUFlLE9BQ3pCLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLFVBQVUsbUJBQW1CLElBQUk7Q0FDdkMsSUFBSSxTQUFTLE9BQU8sU0FBUyxRQUMzQixNQUFNLElBQUksTUFBOEMsc0VBQWdHO0NBRTFKLE1BQU0sd0JBQXdCLHlCQUF5QjtDQUN2RCxNQUFNLHFCQUFxQiwwQkFBMEI7Q0FDckQsTUFBTSxFQUNKLE9BQ0EsdUJBQ0U7Q0FDSixNQUFNLGtCQUFrQixRQUFRLE9BQU87Q0FDdkMsTUFBTSxXQUFXLHFCQUFxQjtFQUNwQyxPQUFPO0VBQ1A7Q0FDRixDQUFDO0NBQ0QsTUFBTSxnQkFBZ0IsWUFBWSxNQUFNO0NBQ3hDLE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLCtCQUFBLGFBQXFDLE9BQU8sS0FBSztDQUN2RCxNQUFNLG9CQUFvQixNQUFNLFNBQVMsbUJBQW1CO0NBQzVELE1BQU0sc0JBQXNCLE1BQU0sU0FBUyxxQkFBcUI7Q0FDaEUsTUFBTSxtQkFBbUIsTUFBTSxTQUFTLGtCQUFrQjtDQUMxRCxNQUFNLFVBQVUsTUFBTSxTQUFTLGtCQUFrQixhQUFhO0NBQzlELE1BQU0sc0JBQXNCLHVCQUF1QixlQUFlLEtBQUs7Q0FJdkUsTUFBTSxrQkFBa0IsbUJBQWtCLFlBQVc7RUFDbkQsb0JBQW9CLE9BQU87RUFDM0IsTUFBTSx1QkFBdUIsTUFBTSxPQUFPLHNCQUFzQjtFQUNoRSxJQUFJLFlBQVksUUFBUSxNQUFNLE9BQU8sTUFBTSxNQUFNLHlCQUF5QixXQUFXLE1BQU0sT0FBTyxpQkFBaUIsS0FBSyxPQUN0SCxNQUFNLE9BQU87R0FDWCxpQkFBaUIsaUJBQWlCO0dBQ2xDLHNCQUFzQjtHQUN0QjtFQUNGLENBQUM7Q0FFTCxDQUFDO0NBQ0QsTUFBTSxvQkFBQSxhQUEwQixPQUFPLElBQUk7Q0FDM0MsTUFBTSwwQkFBQSxhQUFnQyxhQUFZLE9BQU07RUFDdEQsa0JBQWtCLFVBQVU7RUFDNUIsTUFBTSxJQUFJLHdCQUF3QixFQUFFO0NBQ3RDLEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FLVix5QkFBeUI7RUFDdkIsZ0JBQWdCLGtCQUFrQixPQUFPO0VBQ3pDLGFBQWEsZ0JBQWdCLElBQUk7Q0FDbkMsR0FBRztFQUFDO0VBQWlCO0VBQWU7Q0FBSyxDQUFDO0NBQzFDLHlCQUF5QjtFQUN2QixJQUFJLENBQUMsUUFBUSxDQUFDLG1CQUNaO0VBRUYsU0FBUyxvQkFBb0IsT0FBTztHQUNsQyxJQUFJLFVBQVUsS0FBSyxNQUFNLE1BQU0sUUFBUSwyQkFBMkIsU0FDaEUsNkJBQTZCLFVBQVUsTUFBTSxrQkFBa0Isa0JBQWtCO0VBRXJGO0VBSUEsa0JBQWtCLGlCQUFpQixZQUFZLHFCQUFxQixJQUFJO0VBQ3hFLGFBQWE7R0FDWCw2QkFBNkIsVUFBVTtHQUN2QyxrQkFBa0Isb0JBQW9CLFlBQVkscUJBQXFCLElBQUk7RUFDN0U7Q0FDRixHQUFHO0VBQUM7RUFBTTtFQUFtQjtDQUFLLENBQUM7Q0FDbkMsTUFBTSxlQUFlLGNBQWMsVUFBVTtDQUM3QyxNQUFNLGVBQWUsTUFBTSxTQUFTLFVBQVU7Q0FDOUMsTUFBTSxpQkFBaUIsZ0JBQWdCLFNBQVMsVUFBVTtDQUMxRCxNQUFNLFdBQVcsZ0JBQWdCLGdCQUFnQjtDQUcvQyxhQUFNLGdCQUFnQjtFQUNwQixNQUFNLFVBQVUsa0JBQWtCO0VBQ2xDLElBQUksV0FBVyxrQkFBa0IsT0FBTyxLQUFLLENBQUMsVUFBVTtHQUN0RCxNQUFNLG9CQUFvQixVQUFVLG9CQUFvQixLQUFLO0dBQzdELEtBQUssdUxBQXVMLG1CQUFtQjtFQUNqTjtDQUNGLENBQUM7Q0FFSCxNQUFNLFlBQVksZ0JBQWdCLFNBQVMsV0FBVztDQUN0RCxNQUFNLGNBQWMsZ0JBQWdCLFNBQVMsWUFBWSxTQUFTLEtBQUs7Q0FDdkUsTUFBTSxlQUFBLGFBQXFCLGVBQWU7RUFDeEMsTUFBTTtFQUNOLFVBQVUsT0FBTztHQUNmLElBQUksZ0JBQWdCLE9BQU8sc0JBQXNCLEdBQy9DLGdCQUFnQixlQUFlLFNBQVMsT0FBT0MsU0FBaUIsS0FBSztFQUV6RTtDQUNGLElBQUksQ0FBQyxpQkFBaUIsU0FBUyxLQUFLLENBQUM7Q0FDckMsTUFBTSxFQUNKLGNBQ0EsWUFDRSxZQUFZO0VBQ2QsY0FBYztFQUNkO0VBQ0E7RUFDQSxJQUFJO0VBQ0o7RUFDQSxXQUFXLGdCQUFnQixRQUFRO0VBQ25DO0VBQ0E7RUFDQSxRQUFRLHVCQUF1QixRQUFRO0NBQ3pDLENBQUM7Q0FDRCxNQUFNLGVBQWUsTUFBTSxTQUFTLGNBQWM7Q0FDbEQsTUFBTSxhQUFhLDZCQUE2QixxQkFBcUI7RUFDbkUsU0FBUyxnQkFBZ0IsZUFBZSxDQUFDO0VBQ3pDLGFBQWEsWUFBWSxFQUN2QixvQkFBb0IsS0FDdEIsQ0FBQztFQUNELFdBQVc7RUFDWCxNQUFNO0VBQ04sUUFBUTtFQUNSLE9BQU87R0FDTCxNQUFNO0dBQ04sT0FBTztFQUNUO0VBQ0EsWUFBWSxRQUFRLFVBQVUsZ0JBQWdCLE9BQU8saUJBQWlCLElBQUksS0FBQTtFQUMxRTtFQUNBLGNBQWM7RUFDZCxpQkFBaUIsTUFBTSxPQUFPLGtCQUFrQixNQUFNO0VBR3RELGdCQUFnQjtDQUNsQixDQUFDO0NBYUQsTUFBTSx3QkFaUSxTQUFTLHFCQUFxQjtFQUMxQyxTQUFTLENBQUM7RUFDVixPQUFPO0VBTVAsUUFBUTtFQUNSLGFBQWE7RUFDYixhQUFhO0NBQ2YsQ0FDa0MsQ0FBQyxDQUFDLGFBQWE7Q0FDakQsTUFBTSxtQkFBbUIsTUFBTSxTQUFTLGdCQUFnQixJQUFJO0NBQzVELE9BQU8saUJBQWlCO0NBQ3hCLE1BQU0sUUFBUTtFQUNaO0VBQ0E7RUFDQTtDQUNGO0NBQ0EsTUFBTSxhQUFhLE1BQU0sU0FBUyxZQUFZO0NBSTlDLE1BQU0sbUJBSHVCLE1BQU0sU0FBUyxzQkFHQSxNQUFNLHFCQUEwQixlQUFlO0NBQzNGLE1BQU0scUJBQXFCLFFBQVEsb0JBQW9CQztDQUN2RCxNQUFNLHNCQUFzQixvQkFBb0IsbUJBQW1CLEVBQ2pFLFdBQVcsbUJBQW1CLGlCQUNoQyxJQUFJLEtBQUE7Q0FxQ0osT0FwQ2dCLGlCQUFpQixPQUFPLGdCQUFnQjtFQUN0RDtFQUNBLHdCQUF3QjtFQUN4QixPQUFPO0dBQUM7R0FBdUI7R0FBWTtHQUczQztHQUFxQjtHQU1yQixxQkFBcUIsNEJBQTRCLEtBQUE7R0FBVztJQUMxRCxpQkFBaUI7SUFHakIsVUFBVSxzQkFBc0IsRUFBRSxRQUFRLGVBQWUsS0FBSztJQUM5RCxRQUFRLE9BQU87S0FJYixJQUFJLE1BQU0sT0FBTyxNQUFNLEtBQUssNkJBQTZCLFNBQVM7TUFDaEUsNkJBQTZCLFVBQVU7TUFDdkMsTUFBTSxRQUFRLE9BQU8seUJBQXlCQyxVQUFrQixNQUFNLFdBQVcsQ0FBQztLQUNwRjtJQUNGO0lBQ0EsU0FBUztLQUNQLElBQUksYUFDRixnQkFBZ0IsZUFBZSxNQUFNQyxJQUFZO0lBRXJEO0dBQ0Y7R0FBRztHQUVIO0VBQVk7RUFDWixLQUFLO0dBQUM7R0FBYyxTQUFTO0dBQUs7R0FBUztHQUFpQjtFQUF1QjtDQUNyRixDQUNhO0FBQ2YsQ0FBQztBQVEwQyx3QkFBd0IsY0FBYztBQUNqRixJQUFhLHFCQUFrQywyQkFBTSxXQUFXLFNBQVMsbUJBQW1CLE9BQU8sY0FBYztDQUMvRyxNQUFNLGFBQWEsa0JBQWtCLE9BQU8sY0FBYyxpQkFBaUI7Q0FDM0UsSUFBSSxDQUFDLFdBQVcsU0FDZCxPQUFPO0NBRVQsTUFBTSxjQUFjLFdBQVcsUUFBUSxXQUFXLFdBQVcsT0FBTyxLQUFLLElBQUk7Q0FDN0UsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyx5QkFBeUI7RUFDaEQsR0FBRztFQUNILEtBQUssV0FBVztDQUNsQixDQUFDO0FBQ0gsQ0FBQztBQUMwQyxtQkFBbUIsY0FBYzs7Ozs7Ozs7OztBQ3RQNUUsSUFBYSxhQUFiLGNBQWdDLGdCQUFnQjtDQUM5QyxjQUFjO0VBQ1osTUFBTSxvQkFBb0IsR0FBRyxNQUFNO0NBQ3JDOzs7Ozs7Ozs7Q0FVQSxLQUFLLFdBQVc7RUFDZCxLQUFLLGNBQWMsU0FBUztDQUM5Qjs7Ozs7O0NBT0EsUUFBUTtFQUNOLEtBQUssV0FBVztDQUNsQjs7OztDQUtBLElBQUksU0FBUztFQUNYLE9BQU8sS0FBSyxlQUFlLE9BQU8sTUFBTSxLQUFLO0NBQy9DO0FBQ0Y7Ozs7QUFLQSxTQUFnQixtQkFBbUI7Q0FDakMsT0FBTyxJQUFJLFdBQVc7QUFDeEI7O0FDbERBLFNBQWdCLGdCQUFnQixRQUFRO0NBQ3RDLElBQUksTUFBTSxRQUFRLE1BQU0sR0FDdEIsT0FBTyxPQUFPLEtBQUksVUFBUyxnQkFBZ0IsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FFN0QsSUFBSSxVQUFVLE1BQ1osT0FBTztDQUVULE9BQU8sT0FBTyxNQUFNO0FBQ3RCOztBQ05BLElBQU0sOEJBQWMsSUFBSSxJQUFJO0FBQzVCLFNBQWdCLFVBQVUsVUFBVSxDQUFDLEdBQUc7Q0FDdEMsTUFBTSxFQUNKLFFBQ0EsR0FBRyxnQkFDRDtDQUNKLE1BQU0sa0JBQWtCO0VBQ3RCLE9BQU87RUFDUCxhQUFhO0VBQ2IsbUJBQW1CO0VBQ25CLEdBQUc7Q0FDTDtDQUNBLE1BQU0sV0FBVyxHQUFHLGdCQUFnQixNQUFNLEVBQUUsR0FBRyxLQUFLLFVBQVUsZUFBZTtDQUM3RSxNQUFNLGVBQWUsWUFBWSxJQUFJLFFBQVE7Q0FDN0MsSUFBSSxjQUNGLE9BQU87Q0FFVCxNQUFNLFdBQVcsSUFBSSxLQUFLLFNBQVMsUUFBUSxlQUFlO0NBQzFELE1BQU0sU0FBUztFQUNiLFNBQVMsTUFBTSxPQUFPLGNBQWM7R0FDbEMsSUFBSSxDQUFDLE9BQ0gsT0FBTztHQUVULE1BQU0sYUFBYSxpQkFBaUIsTUFBTSxZQUFZO0dBQ3RELEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxXQUFXLFNBQVMsTUFBTSxRQUFRLEtBQUssR0FDMUQsSUFBSSxTQUFTLFFBQVEsV0FBVyxNQUFNLEdBQUcsSUFBSSxNQUFNLE1BQU0sR0FBRyxLQUFLLE1BQU0sR0FDckUsT0FBTztHQUdYLE9BQU87RUFDVDtFQUNBLFdBQVcsTUFBTSxPQUFPLGNBQWM7R0FDcEMsSUFBSSxDQUFDLE9BQ0gsT0FBTztHQUVULE1BQU0sYUFBYSxpQkFBaUIsTUFBTSxZQUFZO0dBQ3RELE9BQU8sU0FBUyxRQUFRLFdBQVcsTUFBTSxHQUFHLE1BQU0sTUFBTSxHQUFHLEtBQUssTUFBTTtFQUN4RTtFQUNBLFNBQVMsTUFBTSxPQUFPLGNBQWM7R0FDbEMsSUFBSSxDQUFDLE9BQ0gsT0FBTztHQUVULE1BQU0sYUFBYSxpQkFBaUIsTUFBTSxZQUFZO0dBQ3RELE1BQU0sY0FBYyxNQUFNO0dBQzFCLE9BQU8sV0FBVyxVQUFVLGVBQWUsU0FBUyxRQUFRLFdBQVcsTUFBTSxXQUFXLFNBQVMsV0FBVyxHQUFHLEtBQUssTUFBTTtFQUM1SDtDQUNGO0NBQ0EsWUFBWSxJQUFJLFVBQVUsTUFBTTtDQUNoQyxPQUFPO0FBQ1Q7Ozs7Ozs7QUN4Q0EsU0FBZ0Isa0JBQWtCO0NBQ2hDLE1BQU0sZUFBZSxxQ0FBcUIsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDO0NBQ3JELE1BQU0sQ0FBQyxpQkFBaUIsc0JBQUEsYUFBNEIsU0FBUyxDQUFDO0NBQzlELE1BQU0sdUJBQUEsYUFBNkIsT0FBTyxLQUFLO0NBSS9DLE1BQU0seUJBQXlCLHdCQUF3QjtFQUNyRCxJQUFJLHFCQUFxQixTQUN2QjtFQUVGLHFCQUFxQixVQUFVO0VBQy9CLG9CQUFtQixZQUFXLFVBQVUsQ0FBQztDQUMzQyxDQUFDO0NBQ0QsTUFBTSxlQUFlLG1CQUFtQixLQUFLLFNBQVM7RUFDcEQsYUFBYSxJQUFJLEtBQUssSUFBSTtFQUMxQix1QkFBdUI7RUFDdkIsYUFBYTtHQUNYLGFBQWEsT0FBTyxHQUFHO0dBQ3ZCLHVCQUF1QjtFQUN6QjtDQUNGLENBQUM7Q0FDRCxNQUFNLGtCQUFBLGFBQXdCLGNBQWMsSUFBSSxJQUFJLFlBQVksR0FHaEUsQ0FBQyxlQUFlLENBQUM7Q0FDakIseUJBQXlCO0VBQ3ZCLHFCQUFxQixVQUFVO0NBQ2pDLEdBQUcsQ0FBQyxlQUFlLENBQUM7Q0FDcEIsT0FBTztFQUNMLE9BQU87RUFDUDtFQUNBLFdBQVc7Q0FDYjtBQUNGOztBQ3pDQSxTQUFTLHlCQUF5QjtDQUNoQyxNQUFNLElBQUksTUFBOEMsOElBQThLO0FBQ3hPO0FBQ0EsSUFBYSw0QkFBeUMsMkJBQU0sY0FBYyxJQUFJO0FBQ25DLDBCQUEwQixjQUFjO0FBQ25GLFNBQWdCLDZCQUE2QixXQUFXLE9BQU87Q0FDN0QsTUFBTSxVQUFBLGFBQWdCLFdBQVcseUJBQXlCO0NBQzFELElBQUksWUFBWSxRQUFRLENBQUMsVUFDdkIsdUJBQXVCO0NBRXpCLE9BQU87QUFDVDtBQUNBLElBQWEsNEJBQXlDLDJCQUFNLGNBQWMsSUFBSTtBQUNuQywwQkFBMEIsY0FBYztBQUNuRixTQUFnQiw2QkFBNkIsV0FBVyxPQUFPO0NBQzdELE1BQU0sVUFBQSxhQUFnQixXQUFXLHlCQUF5QjtDQUMxRCxJQUFJLFlBQVksUUFBUSxDQUFDLFVBQ3ZCLHVCQUF1QjtDQUV6QixPQUFPO0FBQ1Q7Ozs7QUFLQSxTQUFnQix3QkFBd0IsU0FBUztDQUMvQyxJQUFJLFVBQUEsYUFBZ0IsV0FBVyx5QkFBeUI7Q0FDeEQsSUFBSSxZQUFZLE1BQ2QsT0FBTztDQUVULE9BQU8sWUFBWSxRQUFRLFFBQVEsWUFBWSxTQUM3QyxVQUFVLFFBQVE7Q0FFcEIsT0FBTztBQUNUO0FBS0EsSUFBYSw2QkFBMEMsMkJBQU0sY0FBYyxFQUFFO0FBQ2xDLDJCQUEyQixjQUFjO0FBQ3BGLFNBQWdCLGdDQUFnQztDQUM5QyxPQUFBLGFBQWEsV0FBVywwQkFBMEI7QUFDcEQ7O0FDN0NBLElBQWEsWUFBWTtDQUV2QixVQUFTLFVBQVMsTUFBTSxtQkFBbUIsT0FBTyxNQUFNLHdCQUF3QixJQUFJLE1BQU0sZUFBZSxTQUFTO0NBQ2xILGdCQUFnQixPQUFPLE9BQU8sTUFBTSxtQkFBbUIsUUFBUSxNQUFNLGVBQWUsSUFBSSxFQUFFO0FBQzVGO0FBQ0EsSUFBYSxzQkFBYixjQUF5QyxXQUFXO0NBQ2xELGNBQWM7RUFDWixNQUFNO0dBQ0osZ0JBQWdCO0dBQ2hCLHFCQUFxQjtFQUN2QixHQUFHLGNBQWMsU0FBUztDQUM1QjtBQUNGOzs7OztBQU1BLElBQWEsaUJBQWlCO0NBQzVCLG9CQUFvQjtDQUNwQixPQUFPLElBQUksb0JBQW9CO0FBQ2pDOzs7Ozs7OztBQ0pBLFNBQWdCLG1CQUFtQixPQUFPO0NBQ3hDLE1BQU0sRUFDSixVQUNBLE1BQ0EsV0FBVyxPQUNYLG1CQUFtQixPQUNuQixRQUNBLE9BQ0EsT0FDQSxlQUNBLFFBQ0EsZ0JBQWdCLE9BQ2hCLFdBQVcsZUFDWCxTQUNBLGdCQUNBLGdCQUNBLGVBQWUsc0JBQ2I7Q0FDSixNQUFNLG9CQUFBLGFBQTBCLFdBQVcseUJBQXlCO0NBQ3BFLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQUEsYUFBMkIsU0FBUyxLQUFBLENBQVM7Q0FDcEUsTUFBTSxDQUFDLG1CQUFtQix3QkFBQSxhQUE4QixTQUFTLGdCQUFnQjtDQUNqRixNQUFNLENBQUMsa0JBQWtCLHVCQUFBLGFBQTZCLFNBQVMsZ0JBQWdCO0NBQy9FLE1BQU0sQ0FBQywwQkFBMEIsK0JBQUEsYUFBcUMsU0FBUyxnQkFBZ0I7Q0FHL0YsSUFBSSxxQkFBcUIsMEJBQTBCO0VBQ2pELDRCQUE0QixnQkFBZ0I7RUFDNUMscUJBQXFCLGdCQUFnQjtFQUNyQyxvQkFBb0IsZ0JBQWdCO0NBQ3RDO0NBQ0EsTUFBTSxFQUNKLE9BQU8saUJBQ1AsY0FBYyxvQkFDZCxjQUNFLGdCQUFnQjtDQUNwQixNQUFNLFlBQVksWUFBWTtDQUM5QixNQUFNLFFBQVEscUJBQXFCLElBQUksb0JBQW9CLENBQUMsQ0FBQyxDQUFDO0NBSTlELE1BQU0sZUFBZSxtQkFBbUIsSUFBSSxTQUFTO0VBQ25ELE1BQU0sYUFBYSxtQkFBbUIsSUFBSSxJQUFJO0VBQzlDLE1BQU0sSUFBSSx1QkFBdUIsVUFBVSxJQUFJO0VBQy9DLGFBQWE7R0FDWCxXQUFXO0dBQ1gsTUFBTSxJQUFJLHVCQUF1QixVQUFVLElBQUk7RUFDakQ7Q0FDRixDQUFDO0NBQ0QsTUFBTSx3QkFBQSxhQUE4QixPQUFPLElBQUk7Q0FDL0MsTUFBTSxxQkFBQSxhQUEyQixPQUFPLElBQUk7Q0FDNUMsTUFBTSxtQkFBQSxhQUF5QixjQUFjLFVBQVUsRUFDckQsT0FDRixDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDO0NBQ3JCLE1BQU0sZ0JBQWdCLHFCQUFxQjtDQUMzQyxNQUFNLGVBQWUsU0FBUyxNQUFBLENBQU8sS0FBSztDQUUxQyxNQUFNLFlBQVksZ0JBQWdCLE1BQU0sV0FBVyxPQUFPLE9BQU8sVUFBVTtDQUMzRSxNQUFNLHVCQUF1QixTQUFTLGtCQUFrQixZQUFZLGlCQUFpQixnQkFBZ0I7Q0FHckcsTUFBTSxnQkFBZ0IsWUFBWSxHQUFHLFVBQVUsU0FBUyxLQUFBO0NBQ3hELE1BQU0sVUFBVSxrQkFBa0Isa0JBQWtCLEtBQUE7Q0FFcEQsTUFBTSxZQUFZLGlCQUFpQixLQUFBO0NBQ25DLE1BQU0sb0JBQW9CLG1CQUFtQixXQUFXLGlCQUFpQjtFQUN2RSxnQkFBZ0IsV0FBVyxZQUFZO0VBR3ZDLElBQUksQ0FBQyxhQUFhLGNBQWMsQ0FBQyxlQUMvQixlQUFlLElBQUk7Q0FFdkIsQ0FBQztDQUNELE1BQU0sb0JBQW9CLG1CQUFrQixrQkFBaUI7RUFDM0QsTUFBTSxRQUFRLFFBQVE7RUFDdEIsTUFBTSxjQUFjLGVBQWU7RUFLbkMsSUFBSSxlQUFlLFFBQVEsTUFBTSxnQkFBZ0IsUUFBUSxNQUFNLGlCQUFpQixjQUFjLGNBQzVGO0VBRUYsZUFBZSx3QkFBd0IsTUFBTSxTQUFTLElBQUksSUFBSSxJQUFJO0NBQ3BFLENBQUM7Q0FLRCx5QkFBeUI7RUFDdkIsSUFBSSxDQUFDLFFBQVEsVUFBVSxLQUFBLEdBQ3JCO0VBRUYsTUFBTSxlQUFlLG1CQUFtQixZQUFZLFFBQVEsbUJBQW1CLFlBQVk7RUFDM0YsbUJBQW1CLFVBQVU7RUFJN0IsSUFBSSxjQUFjLE1BQU07R0FDdEIsTUFBTSxJQUFJLGtCQUFrQixJQUFJO0dBRWhDLElBQUksd0JBQXdCLFVBQVUsT0FBTyxHQUN2QztRQUFBLGdCQUFnQixlQUFlLEtBQUssTUFDdEMsZUFBZSxDQUFDO0dBQUEsT0FFYixJQUFJLGdCQUFnQixNQUFNLGNBQy9CLGVBQWUsSUFBSTtHQUVyQjtFQUNGO0VBQ0EsTUFBTSxhQUFhLE1BQU0sTUFBTTtFQUcvQixJQUFJLGVBQWUsUUFBUSxVQUFVLFNBQVMsR0FDNUM7RUFFRixNQUFNLDBCQUFVLElBQUksSUFBSTtFQUN4QixJQUFJLGNBQWMsZUFBZTtFQUNqQyxVQUFVLFNBQVMsRUFDakIsV0FDQyxPQUFPO0dBQ1IsTUFBTSxPQUFPLFFBQVE7R0FDckIsSUFBSSxRQUFRLFFBQVEsVUFBVSxNQUFNLFdBQVcsR0FBRztJQUNoRCxRQUFRLElBQUksRUFBRTtJQUNkLGdCQUFnQixDQUFDLFlBQVksSUFBSSxFQUFFO0dBQ3JDO0VBQ0YsQ0FBQztFQUdELElBQUksZUFBZSxZQUFZLFNBQVMsUUFBUSxNQUFNO0dBR3BELElBQUksd0JBQXdCLFFBQVEsT0FBTyxHQUN6QyxlQUFlLENBQUM7UUFDWCxJQUFJLGVBQWUsUUFBUSxjQUNoQyxlQUFlLElBQUk7R0FFckIsTUFBTSxJQUFJLGtCQUFrQixPQUFPO0VBQ3JDLE9BQU8sSUFBSSx3QkFBd0IsZ0JBQWdCLFFBQVEsT0FBTyxHQUNoRSxlQUFlLENBQUM7Q0FFcEIsR0FBRztFQUFDO0VBQU07RUFBTztFQUFhO0VBQWlCO0VBQVc7RUFBVztFQUFzQjtFQUFPO0VBQWdCO0NBQWMsQ0FBQztDQUNqSSxNQUFNLGVBQUEsYUFBcUIsZUFBZTtFQUN4QztFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLGVBQWU7RUFDZixlQUFlO0NBQ2pCLElBQUk7RUFBQztFQUFNO0VBQVU7RUFBbUI7RUFBa0I7RUFBZTtFQUFXO0VBQWU7RUFBUTtFQUFlO0VBQWdCO0VBQW1CO0NBQWlCLENBQUM7Q0FDL0ssTUFBTSxtQkFBQSxhQUF5QixlQUFlO0VBQzVDLFFBQVE7RUFDUjtFQUNBO0VBQ0E7Q0FDRixJQUFJO0VBQUM7RUFBbUI7RUFBTztFQUFjO0NBQU8sQ0FBQztDQUNyRCxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLDBCQUEwQixVQUFVO0VBQzNELE9BQU87RUFDUCxVQUF1QixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLDBCQUEwQixVQUFVO0dBQzlELE9BQU87R0FDUCxVQUF1QixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLDJCQUEyQixVQUFVO0lBQy9ELE9BQU8sU0FBUztJQUNOO0dBQ1osQ0FBQztFQUNILENBQUM7Q0FDSCxDQUFDO0FBQ0g7Ozs7OztBQ3ZMQSxTQUFnQiw0QkFBNEIsWUFBWTtDQUN0RCxNQUFNLEVBQ0osTUFDQSxTQUNBLE9BQ0Esa0JBQ0U7Q0FDSixNQUFNLENBQUMsWUFBWSxpQkFBQSxhQUF1QixTQUFTLElBQUk7Q0FDdkQsTUFBTSxrQkFBQSxhQUF3QixPQUFPLElBQUk7Q0FDekMseUJBQXlCO0VBQ3ZCLE1BQU0sVUFBVSxnQkFBZ0I7RUFDaEMsZ0JBQWdCLFVBQVU7RUFDMUIsSUFBSSxXQUFXLENBQUMsUUFBUSxVQUFVLElBQUk7R0FDcEMsY0FBYyxLQUFLO0dBQ25CLGNBQWMsSUFBSSx5QkFBeUJDLFVBQWtCLENBQUM7RUFDaEUsT0FBTyxLQUFLLFFBQVEsQ0FBQyxZQUFZLGVBQWUsTUFDOUMsY0FBYyxJQUFJO0NBRXRCLEdBQUc7RUFBQztFQUFNO0VBQVM7RUFBTztFQUFZO0NBQWEsQ0FBQztDQUNwRCxPQUFPLENBQUMsUUFBUSxlQUFlLE9BQU8sYUFBYTtBQUNyRDs7QUM5QkEsSUFBSSxhQUFhOzs7Ozs7OztBQVNqQixTQUFnQixhQUFhLE9BQU87Q0FDbEMsYUFBYTtDQUNiLElBQUk7RUFDRixNQUFNLE1BQU0sRUFDVixlQUFlLEtBQ2pCLENBQUM7Q0FDSCxVQUFVO0VBQ1IsYUFBYTtDQUNmO0FBQ0Y7QUFDQSxTQUFnQixvQkFBb0I7Q0FDbEMsT0FBTztBQUNUOztBQ1ZBLFNBQWdCLG1CQUFtQixhQUFhO0NBQzlDLE1BQU0sVUFBVSw2QkFBNkI7Q0FDN0MsTUFBTSxZQUFZLGFBQWE7Q0FDL0IsTUFBTSxFQUNKLGtCQUNFO0NBS0osTUFBTSxpQkFBQSxhQUF1QixPQUFPLElBQUk7Q0FHeEMsTUFBTSxpQkFBQSxhQUF1QixPQUFPLE9BQU87Q0FDM0MsU0FBUyxpQkFBaUIsT0FBTztFQUMvQixlQUFlLFVBQVUsTUFBTSxlQUFlO0NBQ2hEO0NBS0UsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxRQUFRLFFBQVEsY0FBYyxZQUFZLE1BQzVDLEtBQUssdUpBQTRKO0NBRXJLLEdBQUcsQ0FBQyxRQUFRLE1BQU0sYUFBYSxDQUFDO0NBRWxDLFNBQVMsa0JBQWtCLE9BQU8sZ0JBQWdCO0VBQ2hELE1BQU0sYUFBYSxjQUFjO0VBQ2pDLElBQUksQ0FBQyxRQUFRLFFBQVEsQ0FBQyxZQUNwQjtFQUVGLE1BQU0sV0FBVyxjQUFjLGNBQWMsTUFBTSxhQUFhLENBQUM7RUFDakUsSUFBSSxhQUFhLGNBQWMsU0FBUyxNQUFNLGVBQWUsUUFBUSxHQUNuRTtFQU1GLElBQUksaUJBQWlCO0VBYXJCLElBWnFCLE1BQU0sWUFBWSxhQUFhLENBQUMsQ0FBQyxNQUFLLFNBQVE7R0FDakUsSUFBSSxDQUFDLGNBQWMsSUFBSSxHQUNyQixPQUFPO0dBRVQsSUFBSSxLQUFLLGFBQWEsTUFBTSxNQUFNLFlBQVksS0FBSyxhQUFhLGtCQUFrQixHQUNoRixPQUFPO0dBRVQsSUFBSSxLQUFLLGFBQWEsZUFBZSxHQUNuQyxpQkFBaUI7R0FFbkIsT0FBTztFQUNULENBQ2UsTUFBTSxNQUFNLGVBQ3pCO0VBS0YsSUFBSSxlQUFlLFdBQVcsRUFBRSxrQkFBa0IsaUJBQ2hEO0VBRUYsSUFBSSxrQkFBa0Isa0JBQWtCLFVBQVUsTUFBTSxhQUFhLEtBQUssU0FBUyxnQkFBZ0IsTUFBTSxhQUFhLEdBQ3BIO0VBRUYsYUFBYSxVQUFVO0NBQ3pCO0NBQ0EsT0FBTztFQUVMLHlCQUF5QixLQUFBO0VBRXpCLG9CQUFvQixLQUFBO0VBQ3BCLFlBQVksT0FBTztHQUNqQixJQUFJLFVBQVUsTUFBTSxXQUFXLE1BQU0sTUFBTSxlQUV6QyxNQUFNLGVBQWU7RUFFekI7RUFDQSxlQUFlO0VBR2YsZUFBZTtFQUNmLGVBQWU7RUFDZixZQUFZLE9BQU87R0FDakIsSUFBSSxlQUFlLFlBQVksU0FDN0Isa0JBQWtCLE9BQU8sS0FBSztFQUVsQztFQUNBLFlBQVksT0FBTztHQUNqQixJQUFJLGVBQWUsWUFBWSxXQUFXLGVBQWUsU0FDdkQsa0JBQWtCLE9BQU8sSUFBSTtFQUVqQztFQUNBLFFBQVEsT0FBTztHQUViLE1BQU0sU0FBUyxVQUFVLE1BQU0sV0FBVztHQUkxQyxJQUFJLFdBQVcsY0FBYyxTQUMzQixlQUFlLFVBQVU7UUFDcEIsSUFBSSxjQUFjLE1BQU0sS0FBSyxDQUFDLFNBQVMsTUFBTSxlQUFlLE1BQU0sS0FBSyxDQUFDLGtCQUFrQixHQUMvRixlQUFlLFVBQVU7R0FLM0IsSUFBSSxRQUFRLFFBQVEsV0FBVyxNQUFNLGVBQ25DLGNBQWMsU0FBUyxNQUFNLEVBQzNCLGVBQWUsS0FDakIsQ0FBQztFQUVMO0VBQ0EsVUFBVSxPQUFPO0dBQ2YsTUFBTSxTQUFTLFVBQVUsTUFBTSxXQUFXO0dBQzFDLElBQUksV0FBVyxjQUFjLFdBQVcsa0JBQWtCLE1BQU0sR0FDOUQ7R0FFRixJQUFJLDJCQUEyQixNQUFNLEtBQUssYUFBYSxjQUFjLE9BQU8sS0FBSyxHQUFHO0lBQ2xGLGNBQWMsU0FBUyxNQUFNLEVBQzNCLGVBQWUsS0FDakIsQ0FBQztJQUVELE1BQU0sZ0JBQWdCO0dBQ3hCO0VBQ0Y7Q0FDRjtBQUNGOzs7Ozs7QUM1SEEsSUFBYSxrQkFBK0IsMkJBQU0sV0FBVyxTQUFTLGdCQUFnQixPQUFPLGNBQWM7Q0FDekcsTUFBTSxFQUNKLE9BQ0EsZ0JBQ0UsbUJBQW1CO0NBQ3ZCLE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLFNBQVMsTUFBTSxTQUFTLFFBQVE7Q0FDdEMsTUFBTSxhQUFhLE1BQU0sU0FBUyxZQUFZO0NBQzlDLE1BQU0sdUJBQXVCLE1BQU0sU0FBUyxzQkFBc0I7Q0FDbEUsTUFBTSxtQkFBbUIsbUJBQW1CLFdBQVc7Q0FDdkQsTUFBTSxnQkFBZ0IsUUFBUSx5QkFBeUI7Q0FDdkQsTUFBTSxnQkFBZ0IsT0FBTyxTQUFTLFVBQVUsU0FBUyxlQUFlLGNBQWMseUJBQXlCLHFCQUEwQix5QkFBeUIsbUJBQXdCLHlCQUF5QjtDQUduTixJQUFJLGVBQWU7Q0FDbkIsSUFBSSxlQUNGLHFCQUFxQjtFQUduQixNQUFNLGFBQWEsZUFBZSxXQUFXLGVBQWUsVUFBVSxDQUFDLE1BQU0sUUFBUTtFQUNyRixJQUFJLGlCQUFpQixXQUNuQixPQUFPO0VBRVQsT0FBTyxNQUFNLFFBQVEsaUJBQWlCLFdBQVc7Q0FDbkQ7Q0FFRixNQUFNLGFBQWEsV0FBVyxrQkFBa0IsS0FBSztDQUNyRCxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGdCQUFnQjtFQUN2QyxHQUFHO0VBQ0gsTUFBTTtFQUNRO0VBQ2QsS0FBSztDQUNQLENBQUM7QUFDSCxDQUFDO0FBQzBDLGdCQUFnQixjQUFjOztBQzdDekUsSUFBYSw2QkFBMEMsMkJBQU0sY0FBYyxJQUFJO0FBQ3BDLDJCQUEyQixjQUFjO0FBQ3BGLFNBQWdCLGdDQUFnQztDQUM5QyxPQUFBLGFBQWEsV0FBVywwQkFBMEI7QUFDcEQ7Ozs7O0FDT0EsSUFBYSxxQkFBa0MsMkJBQU0sV0FBVyxTQUFTLG1CQUFtQixnQkFBZ0IsY0FBYztDQUV4SCxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsSUFBSSxRQUNKLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLFVBQVUsNkJBQTZCO0NBQzdDLE1BQU0sQ0FBQyxJQUFJLGlCQUFpQixjQUFjLGdCQUFnQixRQUFRLGVBQWUsUUFBUSxpQkFBaUI7Q0FvQjFHLE9BQU8saUJBQWlCLE9BQU8sZ0JBQWdCO0VBQzdDLEtBQUssQ0FBQyxjQUFjLGFBQWE7RUFDakMsT0FBTztHQUFDO0lBbkJSLFVBQVU7SUFDVjtJQUNBLFFBQVEsT0FBTztLQUdiLE1BQU0sUUFBUSxRQUFRLGNBQWM7S0FDcEMsSUFBSSxTQUFTLE1BQU0sa0JBQWtCLFNBQVMsVUFBVSxNQUFNLFdBQVcsTUFBTSxNQUFNLGVBQ25GLGFBQWEsS0FBSztJQUV0QjtJQUNBLGdCQUFnQjtLQUNkLFFBQVEsb0JBQW9CLEtBQUs7SUFDbkM7SUFDQSxnQkFBZ0I7S0FDZCxRQUFRLG9CQUFvQixLQUFLO0lBQ25DO0dBSW1CO0dBQUc7R0FBYyxFQUdsQyxVQUF1QixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLDJCQUEyQixVQUFVO0lBQy9ELE9BQU87SUFDUCxVQUFVLGFBQWE7R0FDekIsQ0FBQyxFQUNIO0VBQUM7Q0FDSCxDQUFDO0FBQ0gsQ0FBQztBQUMwQyxtQkFBbUIsY0FBYzs7Ozs7QUN0QzVFLFNBQWdCLHVCQUF1QixPQUFPLFNBQVM7Q0FDckQsTUFBTSxFQUNKLGFBQ0EsS0FDQSxlQUNBLHdCQUNBLGFBQ0U7Q0FDSixNQUFNLEVBQ0osUUFDRTtDQUVKLElBQUksTUFBTSxVQUFVLEtBQ2xCLE9BQU87Q0FFVCxJQUFJLFFBQVEsT0FDVixPQUFPLE1BQU0sV0FBVyxVQUFVO0NBRXBDLElBQUksUUFBUSxTQUNWLE9BQU8sZ0JBQWdCLGFBQWE7Q0FFdEMsTUFBTSxVQUFVLElBQUksV0FBVyxPQUFPO0NBQ3RDLE1BQU0sYUFBYSxRQUFRLFVBQVUsUUFBUTtDQUk3QyxJQUFJLE1BQU0sWUFBWSxNQUFNLFdBQVcsTUFBTSxVQUFVLE1BQU0sU0FDM0QsT0FBTyxXQUFXLGNBQWMsSUFBSSxXQUFXLElBQUksU0FBUztDQUc5RCxJQUFJLElBQUksV0FBVyxHQUNqQixPQUFPO0NBSVQsSUFBSSxZQUNGLE9BQU8saUJBQWlCLENBQUMsV0FBVyxhQUFhO0NBRW5ELElBQUksQ0FBQyxTQUNILE9BQU87Q0FFVCxJQUFJLHFCQUFxQixLQUFLLFdBQVcsR0FFdkMsT0FBTyxnQkFBZ0IsZ0JBQWdCLENBQUMsaUJBQWlCLFdBQVcsU0FBUztDQUkvRSxJQUFJLDJCQUEyQiwwQkFBMEIsS0FBSyxhQUFhLEdBQUcsS0FBSywyQkFBMkIsS0FBSyxhQUFhLEtBQUssS0FBSyxJQUN4SSxPQUFPO0NBRVQsSUFBSSxnQkFBZ0IsZ0JBQWdCLENBQUMsZUFDbkMsT0FBTztDQUlULE9BQU8sV0FBVyxTQUFTO0FBQzdCOzs7Ozs7OztBQVNBLFNBQWdCLHFCQUFxQixVQUFVO0NBQzdDLE1BQU0sRUFDSixhQUNBLFVBQ0UsbUJBQW1CO0NBQ3ZCLE1BQU0saUJBQWlCLDBCQUEwQjtDQUNqRCxNQUFNLFlBQVksYUFBYTtDQUMvQixPQUFPLG1CQUFrQixVQUFTO0VBRWhDLElBQUksQ0FBQyxNQUFNLE9BQU8sTUFBTSxHQUN0QjtFQUVGLE1BQU0sYUFBYSxNQUFNLE1BQU07RUFRL0IsUUFQZSx1QkFBdUIsT0FBTztHQUMzQztHQUNBLEtBQUssY0FBYztHQUNuQixlQUFlLGNBQWM7R0FDN0Isd0JBQXdCLFlBQVksYUFBYSxlQUFlLEtBQUs7R0FDckU7RUFDRixDQUNhLEdBQWI7R0FDRSxLQUFLO0lBQ0gsTUFBTSxnQkFBZ0I7SUFHdEIsSUFBSSxNQUFNLElBQUksV0FBVyxLQUFLLENBQUMsTUFBTSxXQUFXLENBQUMsTUFBTSxXQUFXLENBQUMsTUFBTSxRQUN2RSxNQUFNLE1BQU0sV0FBVyxZQUFZLEtBQUs7SUFFMUM7R0FDRixLQUFLO0lBRUQsSUFBSSxxQkFBcUIsTUFBTSxLQUFLLFdBQVcsR0FHN0MsTUFBTSxnQkFBZ0I7SUFFeEIsTUFBTSxNQUFNLFdBQVcsWUFBWSxLQUFLO0lBQ3hDO0dBRUosS0FBSyxjQUNIO0lBQ0UsTUFBTSxnQkFBZ0I7SUFDdEIsTUFBTSxVQUFVLE1BQU0sUUFBUTtJQUM5QixNQUFNLFFBQVEsTUFBTSxRQUFRLGNBQWMsZ0JBQWdCLFNBQVMsV0FBVyxJQUFJLGdCQUFnQixTQUFTLFdBQVc7SUFDdEgsSUFBSSxRQUFRLFFBQVEsUUFBUTtLQUMxQixNQUFNLGVBQWU7S0FDckIsTUFBTSxlQUFlLE9BQU9DLFVBQWtCLE1BQU0sV0FBVztJQUNqRTtJQUNBO0dBQ0Y7R0FDRixLQUFLLFdBQ0g7SUFJRSxVQUFVLEtBQUs7SUFDZixNQUFNLDJCQUEyQkMsVUFBWSxVQUFVLENBQUMsQ0FBQztJQUN6RCxXQUFXLGNBQWMsSUFBSSx5QkFBeUIsTUFBTSxNQUFNLE1BQU0sV0FBVyxDQUFDO0lBQ3BGO0dBQ0Y7R0FDRixLQUFLO0lBQ0gsTUFBTSxlQUFlO0lBQ3JCLDJCQUEyQixZQUFZLEtBQUs7SUFDNUM7R0FDRixLQUFLLFNBQ0g7SUFJRSxVQUFVLEtBQUs7SUFDZixNQUFNLGdCQUFnQixNQUFNLE1BQU0sT0FBTyxTQUFTLFVBQVUsZ0JBQWdCLG1CQUFtQixLQUFLLE1BQU0sTUFBTTtJQUNoSCxNQUFNLFVBQVUseUJBQXlCQyxVQUFrQixNQUFNLFdBQVc7SUFDNUUsTUFBTSxRQUFRLE9BQU8sT0FBTztJQUM1QixJQUFJLENBQUMsUUFBUSxjQUFjLGNBQWMsYUFBYSxHQUNwRCxjQUFjLE1BQU07SUFFdEI7R0FDRjtFQUdKO0NBQ0YsQ0FBQztBQUNIOzs7Ozs7O0FDNUpBLFNBQWdCLGtCQUFrQixPQUFPLE1BQU0sT0FBTyxTQUFTO0NBQzdELE1BQU0sRUFDSixhQUNBLEtBQ0EsV0FDQSxnQkFDRTtDQUNKLE1BQU0sVUFBVSxNQUFNLFFBQVE7Q0FDOUIsTUFBTSxRQUFRLFFBQVE7Q0FDdEIsTUFBTSxFQUNKLFVBQ0UsaUJBQWlCLE9BQU8sTUFBTSxRQUFRLElBQUksR0FBRztFQUMvQyxXQUFXLENBQUMsMEJBQTBCLE1BQU0sS0FBSyxhQUFhLEdBQUc7RUFDakU7RUFDQTtFQUVBLGlCQUFpQjtFQUNqQixVQUFVLGdCQUFnQixTQUFTLFdBQVc7RUFDOUMsVUFBVSxnQkFBZ0IsU0FBUyxXQUFXO0NBQ2hELENBQUM7Q0FDRCxNQUFNLE9BQU8sTUFBTTtDQUNuQixJQUFJLE1BQU07RUFDUixNQUFNLGVBQWUsT0FBT0MsVUFBa0IsTUFBTSxXQUFXO0VBQy9ELEtBQUssaUJBQWlCO0dBQ3BCLE9BQU87R0FDUCxRQUFRO0VBQ1YsQ0FBQztDQUNIO0NBQ0EsT0FBTyxRQUFRLEtBQUE7QUFDakI7Ozs7OztBQ1pBLElBQWEsaUJBQThCLDJCQUFNLFdBQVcsU0FBUyxlQUFlLGdCQUFnQixjQUFjO0NBQ2hILE1BQU0sRUFDSixPQUNBLGFBQ0EsV0FDQSxnQkFDRSxtQkFBbUI7Q0FDdkIsTUFBTSxZQUFZLGFBQWE7Q0FDL0IsTUFBTSxFQUNKLGVBQ0EsZUFDQSxjQUNFLDZCQUE2QjtDQUNqQyxNQUFNLEVBQ0osWUFDRSw2QkFBNkI7Q0FDakMsTUFBTSxFQUNKLHVCQUNFLHdCQUF3QjtDQUU1QixNQUFNLHFCQUFxQixxQkFEYiw4QkFDa0MsTUFBVSxFQUFFO0NBQzVELE1BQU0sZ0JBQWdCLG1CQUFrQixVQUFTO0VBQy9DLE1BQU0sUUFBUSxjQUFjO0VBQzVCLE1BQU0sU0FBUyxVQUFVLE1BQU0sV0FBVztFQUMxQyxNQUFNLGVBQWUsU0FBUyxRQUFRLGNBQWMsY0FBYyxLQUFLLENBQUMsTUFBTTtFQUM5RSxNQUFNLGtCQUFrQixDQUFDLFNBQVMsTUFBTSxlQUFlLE1BQU07RUFHN0QsSUFBSSxTQUFTLFFBQVEsZ0JBQWdCLGlCQUFpQjtHQUNwRCxJQUFJLE1BQU0sVUFBVSxPQUFPLENBQUMsTUFBTSxZQUFZLENBQUMsTUFBTSxXQUFXLENBQUMsTUFBTSxXQUFXLENBQUMsTUFBTSxVQUFVLHFCQUFxQixNQUFNLEtBQUssV0FBVyxHQUFHO0lBSS9JLE1BQU0sZ0JBQWdCO0lBQ3RCLE1BQU0sVUFBVSxtQkFBbUIsZUFBZSxzQkFBc0IsTUFBTSxJQUFJLEtBQUE7SUFDbEYsSUFBSSxTQUNGLGtCQUFrQixPQUFPLFNBQVMsT0FBTztLQUN2QztLQUNBLEtBQUssY0FBYztLQUNuQjtLQUNBO0lBQ0YsQ0FBQztHQUVMO0dBQ0E7RUFDRjtFQUdBLElBQUksTUFBTSxrQkFDUjtFQU9GLGFBQWEsS0FBSztFQUNsQixtQkFBbUIsS0FBSztDQUMxQixDQUFDO0NBSUQsU0FBUyxzQkFBc0IsUUFBUTtFQUNyQyxNQUFNLE9BQU8sT0FBTyxZQUFZO0VBQ2hDLE9BQU8sUUFBUSxRQUFRLE1BQUssU0FBUTtHQUNsQyxNQUFNLFVBQVUsTUFBTSxhQUFhLGVBQWU7R0FDbEQsT0FBTyxXQUFXLFFBQVEsY0FBYyxJQUFJLEtBQUssU0FBUyxLQUFLLGVBQWUsT0FBTyxHQUFHLE1BQU07RUFDaEcsQ0FBQztDQUNIO0NBR0EsTUFBTSxtQkFBQSxhQUF5QixPQUFPLElBQUk7Q0FJMUMsTUFBTSxzQkFBc0Isd0JBQXdCO0VBQ2xELE1BQU0sUUFBUSxDQUFDLEdBQUcsUUFBUSxPQUFPO0VBQ2pDLE1BQU0sZ0JBQWdCLGlCQUFpQjtFQUV2QyxLQURnQixrQkFBa0IsUUFBUSxjQUFjLFdBQVcsTUFBTSxVQUFVLE1BQU0sTUFBTSxNQUFNLFVBQVUsU0FBUyxjQUFjLE1BQU0sTUFDN0gsa0JBQWtCLE1BQy9CLGNBQWMsYUFBYTtFQUU3QixpQkFBaUIsVUFBVTtDQUM3QixDQUFDO0NBQ0QseUJBQXlCO0VBQ3ZCLE9BQU8sbUJBQW1CLG1CQUFtQjtDQUMvQyxHQUFHLENBQUMsb0JBQW9CLG1CQUFtQixDQUFDO0NBQzVDLE1BQU0saUJBQWlCLGtCQUFrQixnQkFBZ0IsTUFBTSxhQUFhLElBQUk7Q0FDaEYsTUFBTSxZQUFZLFdBQVc7RUFDM0IsTUFBTTtFQUNOLG1CQUFtQjtFQUNuQixvQkFBb0IsZ0JBQWdCLGVBQWUsZUFBZSxLQUFBO0VBQ2xFLFdBQVc7Q0FDYixHQUFHLGNBQWM7Q0FDakIsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxvQkFBb0I7RUFDM0MsR0FBRztFQUNILEtBQUs7Q0FDUCxDQUFDO0FBQ0gsQ0FBQztBQUMwQyxlQUFlLGNBQWM7O0FDcEh4RSxTQUFTLGNBQWMsT0FBTyxPQUFPO0NBRW5DLElBQUksTUFBTSxtQkFBbUIsUUFBUSxNQUFNLFNBQVMsR0FDbEQsT0FBTztDQUVULEtBQUssTUFBTSxDQUFDLElBQUksYUFBYSxPQUMzQixJQUFJLFlBQVksTUFBTSxlQUFlLElBQUksRUFBRSxHQUN6QyxPQUFPO0NBR1gsT0FBTztBQUNUOzs7Ozs7QUFNQSxTQUFnQix5QkFBeUI7Q0FDdkMsTUFBTSxFQUNKLFVBQ0UsNkJBQTZCO0NBQ2pDLE1BQU0sZ0JBQWdCLDhCQUE4QjtDQUNwRCxNQUFNLEVBQ0osT0FDQSxpQkFDRSxnQkFBZ0I7Q0FDcEIsTUFBTSxTQUFTLFNBQVMsT0FBTyxlQUFlLEtBQUs7Q0FJbkQsTUFBTSxVQUFVLHFCQUFxQixPQUFPLHVCQUF1QixDQUFDLENBQUMsQ0FBQztDQUN0RSxNQUFNLG1CQUFtQixlQUFlO0NBQ3hDLHlCQUF5QixtQkFBbUIsU0FBUyxDQUFDLE1BQU0sR0FBRztFQUFDO0VBQWtCO0VBQVM7Q0FBTSxDQUFDO0NBSWxHLE9BQU87RUFDTDtFQUNBLFNBQUEsYUFMb0IsZUFBZSxFQUNuQyxhQUNGLElBQUksQ0FBQyxZQUFZLENBR1Q7Q0FDUjtBQUNGOzs7Ozs7OztBQ25DQSxJQUFhLGtCQUErQiwyQkFBTSxXQUFXLFNBQVMsZ0JBQWdCLE9BQU8sY0FBYztDQUN6RyxNQUFNLEVBQ0osUUFDQSxZQUNFLHVCQUF1QjtDQUMzQixPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLDJCQUEyQixVQUFVO0VBQzVELE9BQU87RUFDUCxVQUF1QixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGdCQUFnQjtHQUMxQyxHQUFHO0dBQ0gsUUFBUSxVQUFVLE1BQU0sVUFBVSxLQUFBO0dBQ2xDLEtBQUs7RUFDUCxDQUFDO0NBQ0gsQ0FBQztBQUNILENBQUM7QUFPMEMsZ0JBQWdCLGNBQWM7QUFDekUsSUFBYSx1QkFBb0MsMkJBQU0sV0FBVyxTQUFTLHFCQUFxQixPQUFPLGNBQWM7Q0FDbkgsTUFBTSxFQUNKLFFBQ0EsWUFDRSx1QkFBdUI7Q0FDM0IsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSywyQkFBMkIsVUFBVTtFQUM1RCxPQUFPO0VBQ1AsVUFBdUIsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxxQkFBcUI7R0FDL0MsR0FBRztHQUNILFFBQVEsVUFBVSxNQUFNLFVBQVUsS0FBQTtHQUNsQyxLQUFLO0VBQ1AsQ0FBQztDQUNILENBQUM7QUFDSCxDQUFDO0FBQzBDLHFCQUFxQixjQUFjOzs7QUNwQzlFLFNBQVMsYUFBYSxVQUFVO0NBQzlCLElBQUksT0FBTyxhQUFhLFlBQVksT0FBTyxhQUFhLFVBQ3RELE9BQU8sT0FBTyxRQUFRO0NBRXhCLElBQUksTUFBTSxRQUFRLFFBQVEsR0FDeEIsT0FBTyxTQUFTLElBQUksWUFBWSxDQUFDLENBQUMsS0FBSyxFQUFFO0NBRTNDLElBQWlCLDJCQUFNLGVBQWUsUUFBUSxHQUM1QyxPQUFPLGFBQWEsU0FBUyxNQUFNLFFBQVE7Q0FFN0MsT0FBTztBQUNUOzs7Ozs7Ozs7O0FBVUEsU0FBZ0Isc0JBQXNCLFFBQVE7Q0FDNUMsTUFBTSxFQUNKLE9BQ0EsY0FBYyxPQUNkLFVBQ0EsUUFDQSxZQUNFO0NBQ0osTUFBTSxpQkFBaUIsNkJBQTZCLFlBQVksS0FBQSxDQUFTO0NBQ3pFLE1BQU0sZUFBZSw4QkFBOEI7Q0FFbkQsTUFBTSxFQUNKLGNBQ0EsV0FIWSxZQUFZLEtBQUEsSUFBWSxpQkFBaUIsWUFJMUM7Q0FDYixNQUFNLG9CQUFvQixjQUFjO0NBQ3hDLE1BQU0sU0FBUyxxQkFBcUIsT0FBTyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM7Q0FDcEUsTUFBTSxNQUFBLGFBQVksT0FBTyxJQUFJO0NBQzdCLE1BQU0sb0JBQUEsYUFBMEIsT0FBTyxLQUFBLENBQVM7Q0FDaEQsTUFBTSxVQUFVLFNBQVMsT0FBTyxVQUFVLGVBQWUsTUFBTTtDQUsvRCxNQUFNLENBQUMsWUFBWSxpQkFBQSxhQUF1QixTQUFTLE9BQU87Q0FHMUQsTUFBTSxjQUFjLGNBQWMsUUFBUTtDQUMxQyxNQUFNLFlBQVksY0FBYyxNQUFNO0NBR3RDLE1BQU0sa0JBQUEsYUFBd0IsT0FBTyxLQUFBLENBQVM7Q0FDOUMsTUFBTSxjQUFBLGFBQW9CLGtCQUFrQjtFQUMxQyxJQUFJLFNBQVMsTUFDWCxPQUFPO0VBR1QsTUFBTSxlQUFlLGFBQWEsWUFBWSxXQUFXLHFCQUFxQixVQUFVLE9BQU8sQ0FBQztFQUNoRyxNQUFNLHVCQUF1QixnQkFBZ0I7RUFDN0MsZ0JBQWdCLFVBQVU7RUFDMUIsSUFBSSxJQUFJLFlBQVksTUFDbEIsT0FBTyxJQUFJLFFBQVEsZUFBZTtFQUtwQyxJQUFJLGtCQUFrQixZQUFZLEtBQUEsS0FBYSxpQkFBaUIsc0JBQzlELE9BQU8sa0JBQWtCO0VBRTNCLE9BQU87Q0FDVCxHQUFHO0VBQUM7RUFBTztFQUFhO0NBQVMsQ0FBQztDQUNsQyxNQUFNLFdBQUEsYUFBaUIsYUFBWSxpQkFBZ0I7RUFDakQsTUFBTSxPQUFPLGdCQUFnQixZQUFZO0VBQ3pDLElBQUksTUFDRixrQkFBa0IsVUFBVTtFQUU5QixPQUFPLGFBQWEsUUFBUSxFQUMxQixVQUFVO0dBSVIsSUFBSSxTQUFTLFFBQVEsSUFBSSxTQUN2QixrQkFBa0IsVUFBVSxJQUFJLFFBQVEsZUFBZTtHQUV6RCxPQUFPLGtCQUFrQjtFQUMzQixFQUNGLENBQUM7Q0FDSCxHQUFHO0VBQUM7RUFBUTtFQUFPO0VBQWM7Q0FBVyxDQUFDO0NBQzdDLHlCQUF5QjtFQUN2QixNQUFNLGFBQWEsU0FBUztFQUM1QixjQUFjLElBQUk7RUFDbEIsT0FBTztDQUNULEdBQUcsQ0FBQyxRQUFRLENBQUM7Q0FDYix5QkFBeUIsb0JBQW9CLFFBQVEsV0FBVyxHQUFHO0VBQUM7RUFBbUI7RUFBUTtDQUFXLENBQUM7Q0FHM0cseUJBQXlCO0VBQ3ZCLE1BQU0sT0FBTyxZQUFZO0VBQ3pCLElBQUksU0FBUyxrQkFBa0IsU0FBUztHQUN0QyxrQkFBa0IsVUFBVTtHQUM1QixTQUFjLElBQUk7RUFDcEI7Q0FDRixHQUFHO0VBQUM7RUFBVTtFQUFhO0VBQVU7RUFBUTtDQUFLLENBQUM7Q0FDbkQsT0FBTztFQUNMLFNBQVMsQ0FBQyxjQUFjO0VBQ3hCO0NBQ0Y7QUFDRjs7Ozs7O0FDM0dBLFNBQWdCLDRCQUE0QixRQUFRO0NBSWxELE1BQU0sRUFDSixPQUNBLGlCQUNFLG1CQUFtQjtDQUN2QixNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxVQUFVLE1BQU0sU0FBUyxTQUFTO0NBQ3hDLE1BQU0sU0FBUyxNQUFNLFNBQVMsUUFBUTtDQUt0QyxNQUFNLGdCQUFnQix3QkFEQSxPQUFPLFNBQVMsU0FBUyxPQUFPLE1BQU0sUUFBUSxrQkFBa0IsSUFDM0I7Q0FDM0QsTUFBTSxFQUNKLFNBQ0EsUUFDRSxzQkFBc0I7RUFDeEIsR0FBRztFQUNILFNBQVM7RUFDVCxhQUFhO0NBQ2YsQ0FBQztDQUdELHlCQUF5QjtFQUN2QixJQUFJLFdBQVcsQ0FBQyxNQUNkO0VBRUYsTUFBTSxRQUFRLE9BQU8seUJBQXlCQyxJQUFZLENBQUM7Q0FDN0QsR0FBRztFQUFDO0VBQVM7RUFBTTtDQUFLLENBQUM7Q0FDekIsTUFBTSxhQUFhLHlCQUF5QixPQUFPLG9CQUFvQjtFQUNyRSxJQUFJLE1BQU0sU0FBUyxXQUFXLE1BQU0sT0FBTyxNQUFNLE1BQU0sb0JBQW9CLGNBQWMsb0JBQW9CLFdBQVcsTUFBTSxPQUFPLHNCQUFzQixNQUFNLGtCQUMvSixNQUFNLFFBQVEsaUJBQWlCLFNBQVMsTUFBTSxFQUM1QyxlQUFlLEtBQ2pCLENBQUM7Q0FFTCxDQUFDO0NBQ0QsTUFBTSxRQUFRO0VBR1osR0FBSSxlQUFlLEVBQ2pCLGlCQUFpQixTQUNuQixJQUFJLEtBQUE7RUFDSixHQUFHO0VBQ0gsY0FBYyxPQUFPO0dBQ25CLFdBQVcsY0FBYyxLQUFLO0dBQzlCLE1BQU0sUUFBUSxlQUFlLHNCQUFzQixNQUFNLFdBQVc7RUFDdEU7RUFDQSxRQUFRLE9BQU87R0FJYixNQUFNLGFBQWEsTUFBTSxRQUFRLGlCQUFpQjtHQUNsRCxJQUFJLGNBQWMsTUFBTSxPQUFPLE1BQU0sS0FBSyxNQUFNLGtCQUFrQixZQUFZO0lBQzVFLE1BQU0scUJBQXFCO0lBQzNCLFdBQVcsTUFBTSxFQUNmLGVBQWUsS0FDakIsQ0FBQztHQUNIO0VBQ0Y7Q0FDRjtDQUNBLElBQUksa0JBQWtCLE1BRXBCLE9BQU87RUFDTCxTQUFTO0VBQ1QsS0FBSztFQUNMO0NBQ0Y7Q0FFRixPQUFPO0VBQ0wsU0FBUyxXQUFXO0VBQ3BCO0VBQ0E7Q0FDRjtBQUNGOzs7Ozs7O0FDOUVBLFNBQWdCLDZCQUE2QixPQUFPLFFBQVEsTUFBTSxjQUFjO0NBQzlFLE1BQU0sY0FBYyxPQUFPLFNBQVMsU0FBUyxPQUFPLFFBQVE7Q0FDNUQsTUFBTSx3QkFBd0IsYUFBYSxRQUFRO0NBQ25ELE1BQU0saUJBQWlCLG1CQUFtQixTQUFTLFdBQVc7RUFDNUQsTUFBTSxhQUFhLHVCQUF1QjtFQUMxQyxJQUFJLGdCQUFnQixNQUFNLE9BQU8sTUFBTSxLQUFLLENBQUMsYUFBYSxPQUFPLE1BQU0sS0FBSyxDQUFDLFlBQzNFO0VBRUYsSUFBSSxTQUFTLE1BQU0sUUFBUSxTQUFTLFNBQVMsY0FBYyxjQUFjLFVBQVUsQ0FBQyxDQUFDLEdBQ25GLFdBQVcsTUFBTSxFQUNmLGVBQWUsS0FDakIsQ0FBQztFQUVILEtBQUssV0FBVyxxQkFBMEIsV0FBVyxpQkFBc0IsWUFBWSxNQUFNLGVBQWUsTUFFMUcsWUFBWSxjQUFjLFNBQVNDLElBQVk7Q0FFbkQsQ0FBQztDQUNELHlCQUF5QjtFQUN2QixJQUFJLENBQUMsTUFBTTtHQUlULE1BQU0sVUFBVSxNQUFNLE1BQU07R0FDNUIsTUFBTSxTQUFTLE1BQU0sT0FBTyxzQkFBc0I7R0FDbEQscUJBQXFCLGVBQWUsU0FBUyxNQUFNLENBQUM7RUFDdEQ7Q0FDRixHQUFHO0VBQUM7RUFBTTtFQUFPO0NBQWMsQ0FBQztDQUloQyxTQUFTLGNBQWM7RUFDckIsSUFBSSxDQUFDLGdCQUFnQix5QkFBeUIsYUFBYSxNQUFNLGVBQWUsTUFDOUUsWUFBWSxlQUFlLE1BQU1BLElBQVk7Q0FFakQ7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtDQUNGO0FBQ0Y7O0FDOUNBLElBQWEsbUJBQW1CO0NBQzlCLE9BQU87Q0FDUCxNQUFNO0NBQ04sT0FBTztDQUNQLFlBQVk7Q0FDWixTQUFTO0NBQ1QsbUJBQW1CO0NBQ25CLGtCQUFrQjtBQUNwQjs7Ozs7OztBQ1FBLFNBQWdCLG1CQUFtQixPQUFPO0NBQ3hDLE1BQU0sRUFDSixPQUFPLFdBQ1AsZUFBZSxJQUNmLGVBQ0EsR0FBRyxrQkFDRDtDQUNKLE1BQU0sRUFDSixVQUNFLG1CQUFtQjtDQUN2QixNQUFNLE9BQU8sTUFBTSxTQUFTLE1BQU07Q0FDbEMsTUFBTSxVQUFVLE1BQU0sU0FBUyxTQUFTO0NBQ3hDLE1BQU0sZUFBZSxNQUFNLFNBQVMsY0FBYztDQUNsRCxNQUFNLGtCQUFrQixNQUFNLFNBQVMsaUJBQWlCO0NBQ3hELE1BQU0sdUJBQXVCLE1BQU0sU0FBUyxzQkFBc0I7Q0FDbEUsTUFBTSxXQUFXLE1BQU0sU0FBUyxVQUFVO0NBQzFDLE1BQU0sQ0FBQyxPQUFPLFlBQVksY0FBYztFQUN0QyxZQUFZO0VBQ1osU0FBUztFQUNULE1BQU07RUFDTixPQUFPO0NBQ1QsQ0FBQztDQUNELE1BQU0sb0JBQW9CLG1CQUFtQixXQUFXLGlCQUFpQjtFQUN2RSxnQkFBZ0IsV0FBVyxZQUFZO0VBQ3ZDLElBQUksQ0FBQyxhQUFhLFlBQ2hCLFNBQVMsU0FBUztDQUV0QixDQUFDO0NBQ0QsTUFBTSxpQkFBaUIsd0JBQXdCLE1BQU0sTUFBTSxXQUFXO0NBQ3RFLE1BQU0saUJBQWlCLG1CQUFrQixVQUFTO0VBQ2hELE1BQU0sZUFBZSxPQUFPQyxJQUFZO0NBQzFDLENBQUM7Q0FDRCxNQUFNLFFBQVEsNEJBQTRCO0VBQ3hDO0VBQ0E7RUFDQTtFQUNBLGVBQWU7Q0FDakIsQ0FBQztDQUNELE1BQU0scUJBQXFCLHNCQUFzQixVQUFVLEVBQUU7Q0FHN0QscUJBQXFCO0VBQ25CLE1BQU0sSUFBSSxzQkFBc0Isa0JBQWtCO0VBQ2xELE9BQU87Q0FDVCxDQUFDO0NBQ0QsTUFBTSxlQUFlLHNCQUFzQixrQkFBa0I7Q0FJN0QseUJBQXlCO0VBQ3ZCLElBQUksQ0FBQyxNQUNILE1BQU0sSUFBSSxnQkFBZ0IsS0FBSztDQUVuQyxHQUFHLENBQUMsTUFBTSxLQUFLLENBQUM7Q0FJaEIsTUFBTSxZQUFZLHVCQUF1QixxQkFBcUIsTUFBTSxPQUFPO0NBQzNFLE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssc0JBQXNCLFVBQVU7RUFDdkQsT0FBTztFQUNQLFVBQXVCLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssb0JBQW9CO0dBQzlDLEdBQUc7R0FDRztHQUNOLGtCQUFrQjtHQUNSO0dBQ0g7R0FDQTtHQUNQLGVBQWU7R0FDSjtHQUNYLFNBQVMsTUFBTSxRQUFRO0dBQ1A7R0FDQTtHQUNoQixlQUFlLE1BQU0sUUFBUTtFQUMvQixDQUFDO0NBQ0gsQ0FBQztBQUNIOzs7Ozs7QUFPQSxTQUFTLHNCQUFzQixVQUFVO0NBQ3ZDLE1BQU0sRUFDSixVQUNFLG1CQUFtQjtDQUN2QixNQUFNLGNBQWMsa0JBQWtCLElBQUksS0FBSztDQUMvQyxNQUFNLHFCQUFxQixxQkFBcUIsUUFBUTtDQUN4RCxPQUFBLGFBQWEsZUFBZTtFQUMxQixpQkFBaUI7RUFDakIsY0FBYyxPQUFPO0dBQ25CLE1BQU0sUUFBUSxlQUFlLHNCQUFzQixNQUFNLFdBQVc7RUFDdEU7RUFDQSxVQUFVLE9BQU87R0FDZixNQUFNLGFBQWEsTUFBTSxRQUFRLGlCQUFpQjtHQUNsRCxJQUFJLENBQUMsTUFBTSxPQUFPLE1BQU0sS0FBSyxDQUFDLGNBQWMsYUFDMUM7R0FFRixJQUFJLE1BQU0sUUFBUSxhQUFhLE1BQU0sUUFBUSxhQUFhO0lBQ3hELFdBQVcsTUFBTSxFQUNmLGVBQWUsS0FDakIsQ0FBQztJQUNELG1CQUFtQixLQUFLO0lBQ3hCLE1BQU0sZUFBZTtJQUNyQixNQUFNLHFCQUFxQjtHQUM3QixPQUFPLElBQUksTUFBTSxRQUFRLGVBQWUsTUFBTSxRQUFRLGNBRXBELE1BQU0scUJBQXFCO1FBQ3RCLElBQUksZUFBZSxLQUFLLEdBQzdCLFdBQVcsTUFBTSxFQUNmLGVBQWUsS0FDakIsQ0FBQztFQUVMO0NBQ0YsSUFBSTtFQUFDO0VBQU87RUFBYTtDQUFrQixDQUFDO0FBQzlDO0FBQ0EsU0FBUyxlQUFlLE9BQU87Q0FDN0IsT0FBTyxNQUFNLElBQUksV0FBVyxLQUFLLE1BQU0sUUFBUSxPQUFPLENBQUMsTUFBTSxXQUFXLENBQUMsTUFBTSxXQUFXLENBQUMsTUFBTTtBQUNuRzs7O0FDeElBLFNBQWdCLGtCQUFrQixPQUFPO0NBQ3ZDLE1BQU0sRUFDSixVQUNBLE9BQ0EsY0FDQSxlQUNBLFFBQ0EsZ0JBQWdCLE9BQ2hCLFFBQ0EsR0FBRyxlQUNEO0NBQ0osTUFBTSxrQkFBQSxhQUF3QixPQUFPLElBQUk7Q0FDekMsT0FBTztFQUNMO0VBQ0EsV0FBVztHQUNULEdBQUc7R0FDSCxjQUFjO0dBQ2Q7R0FDQSxhQUFhLENBQUM7R0FDZCxxQkFBcUIsa0JBQWtCO0VBQ3pDO0VBQ0EsZUFBZTtHQUNiO0dBQ0E7R0FDQTtHQUNBO0dBQ0E7R0FDQTtFQUNGO0NBQ0Y7QUFDRjs7Ozs7Ozs7QUNwQkEsU0FBZ0IsZUFBZSxPQUFPO0NBQ3BDLE1BQU0sRUFDSixVQUNBLFdBQ0Esa0JBQ0Usa0JBQWtCLEtBQUs7Q0FDM0IsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxrQkFBa0I7RUFDekMsR0FBRztFQUNILFdBQVUsWUFBd0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxvQkFBb0I7R0FDekQsR0FBRztHQUNILFVBQVUsT0FBTyxhQUFhLGFBQWEsU0FBUyxPQUFPLElBQUk7RUFDakUsQ0FBQztDQUNILENBQUM7QUFDSDs7Ozs7Ozs7QUNEQSxTQUFnQixzQkFBc0IsT0FBTztDQUMzQyxNQUFNLFNBQVMsbUJBQW1CO0NBQ2xDLE1BQU0sY0FBYyxPQUFPO0NBQzNCLE1BQU0saUJBQWlCLFlBQVksU0FBUyxVQUFVO0NBQ3RELE1BQU0sRUFDSixXQUNBLGtCQUNFLGtCQUFrQixLQUFLO0NBQzNCLE1BQU0scUJBQUEsYUFBMkIsT0FBTyxJQUFJO0NBQzVDLFNBQVMsbUJBQW1CLFNBQVMsT0FBTztFQUMxQyxNQUFNLGlCQUFpQixPQUFPLGVBQWUsWUFBWSxRQUFRLGlCQUFpQixVQUFVLGNBQWMsY0FBYyxPQUFPLENBQUM7RUFDaEksSUFBSSxjQUFjLGNBQWMsR0FBRztHQUNqQyxtQkFBbUIsVUFBVTtJQUMzQixXQUFXO0lBQ1g7R0FDRjtHQUNBLFlBQVksZUFBZSxNQUFNLFFBQVFDLFdBQW1CQyxNQUFjLEtBQUs7RUFDakY7Q0FDRjtDQUNBLFNBQVMsaUJBQWlCLFNBQVMsT0FBTztFQUN4QyxZQUFZLGNBQWMsU0FBU0QsVUFBa0IsS0FBSztDQUM1RDtDQUNBLFNBQVMsa0JBQWtCLE9BQU87RUFDaEMsTUFBTSxrQkFBa0IsbUJBQW1CO0VBQzNDLElBQUksQ0FBQyxpQkFDSDtFQUVGLGdCQUFnQixVQUFVLE1BQU0sRUFDOUIsZUFBZSxLQUNqQixDQUFDO0VBQ0QsaUJBQWlCLGdCQUFnQixTQUFTLEtBQUs7Q0FDakQ7Q0FDQSxTQUFTLGlCQUFpQixVQUFVLFNBQVM7RUFDM0MsVUFBVSxlQUFlLFVBQVUsT0FBTztFQUMxQyxJQUFJLFFBQVEsWUFDVjtFQUVGLElBQUksQ0FBQyxVQUFVO0dBQ2IsSUFBSSxRQUFRLFdBQVcsZ0JBQXFCLGNBQWMsUUFBUSxPQUFPLEdBQUc7SUFDMUUsaUJBQWlCLFFBQVEsU0FBUyxRQUFRLEtBQUs7SUFHL0MsbUJBQW1CLFVBQVU7S0FDM0IsV0FBVyxPQUFPLGVBQWUsWUFBWSxRQUFRLGlCQUFpQixXQUFXLFFBQVEsVUFBVSxRQUFRO0tBQzNHLFNBQVMsUUFBUTtJQUNuQjtHQUNGO0dBQ0E7RUFDRjtFQUNBLG1CQUFtQixVQUFVO0VBQzdCLElBQUksY0FBYyxRQUFRLE9BQU8sS0FBSyxlQUFlLFFBQVEsUUFBUSxRQUFRLEtBQUssR0FFaEYsbUJBQW1CLFFBQVEsU0FBUyxRQUFRLFdBQVcsb0JBQXlCLFFBQVEsUUFBUSxLQUFBLENBQVM7Q0FFN0c7Q0FDQSxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLGtCQUFrQjtFQUN6QyxHQUFHO0VBQ0gsV0FBVztFQUNYLFVBQVUsa0JBQWtCLE1BQU07RUFDbEMsY0FBYztFQUNkLFVBQXVCLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssNkJBQTZCO0dBQzFDO0dBQ2Isb0JBQW9CLE9BQU87R0FDM0IsbUJBQW1CLE9BQU8sZ0JBQWdCLE9BQU87R0FDakQsbUJBQW1CLE9BQU87R0FDMUIsaUJBQWlCLE9BQU87R0FDeEIsd0JBQXdCLG1CQUFtQixTQUFTLGNBQWMsT0FBTyxlQUFlLFlBQVksUUFBUSxpQkFBaUIsVUFBVSxTQUFTO0dBQ2hKLGdCQUFnQjtHQUNoQixlQUFlO0dBQ2YsVUFBdUIsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxvQkFBb0I7SUFDOUMsR0FBRztJQUNILFVBQVUsTUFBTTtHQUNsQixDQUFDO0VBQ0gsQ0FBQztDQUNILENBQUM7QUFDSDtBQUNBLFNBQVMsNEJBQTRCLE9BQU87Q0FDMUMsTUFBTSxFQUNKLFVBQ0EsYUFDQSxvQkFDQSxtQkFDQSxtQkFDQSxpQkFDQSxnQkFDQSxlQUNBLHFCQUNFO0NBQ0osTUFBTSxFQUNKLE9BQ0EsZ0JBQ0UsbUJBQW1CO0NBQ3ZCLE1BQU0sWUFBWSxhQUFhO0NBQy9CLE1BQU0sVUFBVSxNQUFNLFNBQVMsU0FBUztDQUN4QyxNQUFNLGdCQUFBLGFBQXNCLE9BQU8sS0FBSztDQUN4QyxNQUFNLG9CQUFvQix3QkFBd0I7RUFHaEQsTUFBTSxDQUFDLGNBQWMsTUFBTSxRQUFRLGdCQUFnQixTQUFTO0VBQzVELE9BQU8saUJBQWlCLE1BQU0sY0FBYyxVQUFVLElBQUksYUFBYTtDQUN6RSxDQUFDO0NBTUQseUJBQXlCO0VBQ3ZCLE1BQU0sYUFBYSxjQUFjO0VBQ2pDLGNBQWMsVUFBVTtFQUN4QixJQUFJLFdBQVcsQ0FBQyxZQUNkO0VBRUYsTUFBTSxnQkFBZ0Isa0JBQWtCO0VBQ3hDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLE9BQU8sTUFBTSxHQUM5QztFQUVGLE1BQU0sTUFBTSxjQUFjLGFBQWE7RUFDdkMsTUFBTSxXQUFXLGNBQWMsR0FBRztFQUNsQyxJQUFJLGFBQWEsSUFBSSxRQUFRLFNBQVMsTUFBTSxPQUFPLGNBQWMsR0FBRyxRQUFRLEdBQzFFLGNBQWMsTUFBTSxFQUNsQixlQUFlLEtBQ2pCLENBQUM7Q0FFTCxHQUFHO0VBQUM7RUFBUztFQUFPO0VBQWE7Q0FBaUIsQ0FBQztDQUNuRCxTQUFTLGFBQWEsTUFBTSxPQUFPO0VBQ2pDLE1BQU0sT0FBTyxrQkFBa0IsYUFBYSxNQUFNLE9BQU87R0FDdkQsYUFBYTtHQUNiLEtBQUssY0FBYztHQUNuQixXQUFXO0dBQ1gsYUFBYTtFQUNmLENBQUM7RUFDRCxJQUFJLENBQUMsb0JBQ0gsTUFBTSxNQUFNLEVBQ1YsZUFBZSxLQUNqQixDQUFDO0NBRUw7Q0FDQSxTQUFTLE1BQU0sT0FBTztFQUNwQixJQUFJLENBQUMsTUFBTSxPQUFPLE1BQU0sR0FDdEI7RUFLRixVQUFVLEtBQUs7RUFDZixNQUFNLFVBQVUsTUFBTSxPQUFPLHNCQUFzQjtFQUNuRCxNQUFNLGVBQWUseUJBQXlCRSxnQkFBd0IsTUFBTSxXQUFXO0VBQ3ZGLE1BQU0sUUFBUSxPQUFPLFlBQVk7RUFDakMsSUFBSSxDQUFDLGFBQWEsWUFDaEIsY0FBYyxNQUFNLFdBQVc7RUFJakMsTUFBTSxnQkFBZ0IsaUJBQWlCLEtBQUssTUFBTSxPQUFPLHNCQUFzQjtFQUMvRSxJQUFJLENBQUMsTUFBTSxPQUFPLE1BQU0sS0FBSyxjQUFjLGFBQWEsS0FBSyxjQUFjLGNBQWMsYUFBYSxDQUFDLE1BQU0sZUFDM0csY0FBYyxNQUFNO0VBRXRCLElBQUksQ0FBQyxNQUFNLE9BQU8sTUFBTSxLQUFLLGNBQWMsT0FBTyxLQUFLLHFCQUFxQixNQUFNLEtBQUssaUJBQWlCLEdBQ3RHLGFBQWEsU0FBUyxLQUFLO0NBRS9CO0NBQ0EsTUFBTSx1QkFBdUIsbUJBQWtCLFVBQVM7RUFDdEQsSUFBSSxxQkFBcUIsTUFBTSxLQUFLLGlCQUFpQixHQUFHO0dBQ3RELGFBQWEsTUFBTSxlQUFlLEtBQUs7R0FDdkMsTUFBTSxxQkFBcUI7R0FDM0IsVUFBVSxLQUFLO0dBQ2Y7RUFDRjtFQUNBLE1BQU0sT0FBTyxNQUFNLE9BQU8sTUFBTTtFQUNoQyxNQUFNLFFBQVEsY0FBYztFQUM1QixNQUFNLGFBQWEsMkJBQTJCLE1BQU0sS0FBSyxhQUFhLE9BQU8sS0FBSztFQUNsRixJQUFJLFFBQVEsWUFBWTtHQUN0QixNQUFNLEtBQUs7R0FDWDtFQUNGO0VBRUEsSUFBSSxDQURjLDBCQUEwQixNQUFNLEtBQUssbUJBQW1CLEtBQzdELEdBQ1g7RUFFRixVQUFVLEtBQUs7RUFDZixJQUFJLE1BQU07R0FJUixlQUFlLE1BQU0sZUFBZSxNQUFNLFdBQVc7R0FDckQsTUFBTSxRQUFRLGlCQUFpQixTQUFTLE1BQU0sRUFDNUMsZUFBZSxLQUNqQixDQUFDO0dBQ0Q7RUFDRjtFQUNBLE1BQU0sUUFBUSxNQUFNLHlCQUF5QkEsZ0JBQXdCLE1BQU0sYUFBYSxNQUFNLGFBQWEsQ0FBQztDQUM5RyxDQUFDO0NBQ0QsTUFBTSxxQkFBcUIsbUJBQWtCLFVBQVM7RUFFcEQsSUFBSSxNQUFNLFVBQVUsS0FDbEI7RUFHRixJQURtQiwyQkFBMkIsTUFBTSxLQUFLLGFBQWEsY0FBYyxPQUFPLEtBQzlFLEdBQ1gsTUFBTSxLQUFLO0NBRWYsQ0FBQztDQUNELE1BQU0sZUFBQSxhQUFxQixlQUFlO0VBQ3hDLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIsZ0JBQWdCO0NBQ2xCLElBQUk7RUFBQztFQUFtQjtFQUFzQjtDQUFrQixDQUFDO0NBQ2pFLE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssdUJBQXVCLFVBQVU7RUFDeEQsT0FBTztFQUNHO0NBQ1osQ0FBQztBQUNIOzs7Ozs7Ozs7O0FDOU5BLFNBQWdCLG1CQUFtQixPQUFPO0NBQ3hDLE1BQU0sRUFDSixVQUNBLFFBQ0EsT0FDQSxjQUNBLGVBQ0EsZUFDQSxXQUNFO0NBQ0osTUFBTSxlQUFBLGFBQXFCLGVBQWU7RUFDeEMsTUFBTTtFQUNOLGFBQWE7RUFDYixTQUFTO0dBQ1A7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0VBQ0Y7Q0FDRixJQUFJO0VBQUM7RUFBUTtFQUFPO0VBQWM7RUFBZTtFQUFlO0NBQU0sQ0FBQztDQUN2RSxPQUFvQixlQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFLLDBCQUEwQixVQUFVO0VBQzNELE9BQU87RUFDRztDQUNaLENBQUM7QUFDSDs7Ozs7QUMzQkEsSUFBYSxzQkFBbUMsMkJBQU0sV0FBVyxTQUFTLG9CQUFvQixnQkFBZ0IsY0FBYztDQUMxSCxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsSUFBSSxRQUNKLFVBQ0EsY0FDQSxpQkFDQSxHQUFHLGlCQUNEO0NBR0osTUFBTSxLQUFLLFlBQVksTUFBTTtDQUM3QixNQUFNLFVBQVUsNkJBQTZCO0NBQzdDLE1BQU0sRUFDSixZQUNFLDZCQUE2QjtDQUNqQyxNQUFNLFFBQVEsOEJBQThCO0NBRzVDLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQUEsYUFBMkIsU0FBUyxJQUFJO0NBQy9ELE1BQU0saUJBQUEsYUFBdUIsT0FBTyxLQUFLO0NBQ3pDLFNBQVMsWUFBWSxXQUFXLGFBQWE7RUFHM0MsSUFBSSxDQUFDLFFBQVEsTUFDWDtFQUVGLE1BQU0sU0FBUyxjQUFjLEtBQUtDLGFBQXFCQztFQUN2RCxRQUFRLGNBQWMsV0FBVyx5QkFBeUIsUUFBUSxXQUFXLENBQUM7Q0FDaEY7Q0FDQSxNQUFNLFFBQVEsRUFDWixhQUFhLFFBQVEsc0JBQXNCLENBQUMsUUFBUSxvQkFBb0IsZ0JBQWdCLE1BQzFGO0NBQ0EsT0FBTyxpQkFBaUIsU0FBUyxnQkFBZ0I7RUFDL0M7RUFDQSxLQUFLLENBQUMsY0FBYyxRQUFRLGFBQWE7RUFDekMsT0FBTztHQUFDO0dBQWlCO0lBQ3ZCO0lBQ0EsTUFBTTtJQUNOLFVBQVUsUUFBUSxZQUFZO0lBQzlCLHlCQUF5QjtJQUN6QixNQUFNO0lBQ04sV0FBVztJQUNYLGNBQWM7SUFDZCxZQUFZO0lBQ1osYUFBYTtJQUNiLGdCQUFnQjtJQUloQixxQkFBcUIsS0FBQTtJQUNyQixpQkFBaUIsUUFBUTtJQUN6QixPQUFPLGtCQUFrQjtJQUN6QixtQkFBbUIsT0FBTztLQUV4QixJQUFJQyxTQUNGO0tBRUYsZUFBZSxVQUFVO0tBQ3pCLGtCQUFrQixNQUFNLGNBQWMsS0FBSztJQUM3QztJQUNBLGlCQUFpQixPQUFPO0tBQ3RCLElBQUksQ0FBQyxlQUFlLFNBQ2xCO0tBRUYsZUFBZSxVQUFVO0tBQ3pCLGtCQUFrQixJQUFJO0tBQ3RCLFlBQVksTUFBTSxjQUFjLE9BQU8sTUFBTSxXQUFXO0lBQzFEO0lBQ0EsU0FBUyxPQUFPO0tBQ2QsSUFBSSxlQUFlLFNBQVM7TUFDMUIsa0JBQWtCLE1BQU0sY0FBYyxLQUFLO01BQzNDO0tBQ0Y7S0FDQSxZQUFZLE1BQU0sY0FBYyxPQUFPLE1BQU0sV0FBVztJQUMxRDtJQUNBLFlBQVk7S0FDVixRQUFRLG9CQUFvQixJQUFJO0lBQ2xDO0lBQ0EsZ0JBQWdCO0tBQ2QsUUFBUSxvQkFBb0IsS0FBSztJQUNuQztJQUNBLGFBQWEsT0FBTztLQUNsQixRQUFRLG9CQUFvQixLQUFLO0tBRWpDLElBQUksUUFBUSxNQUNWLGFBQWEsTUFBTSxhQUFhO0lBRXBDO0lBQ0EsUUFBUSxPQUFPO0tBQ2IsUUFBUSxxQkFBcUIsSUFBSTtLQU1qQyxJQUFJLFFBQVEsa0JBQWtCLFlBQVksa0JBQWtCLEdBQzFEO0tBRUYsTUFBTSxPQUFPLE1BQU07S0FDbkIsSUFBSSxTQUFTLFFBQVEsUUFBUSxRQUFRLFNBQVMsSUFBSSxHQUNoRCxRQUFRLGVBQWUsSUFBSTtJQUUvQjtJQUNBLFNBQVM7S0FDUCxRQUFRLHFCQUFxQixLQUFLO0lBQ3BDO0dBQ0Y7R0FBRztFQUFZO0NBQ2pCLENBQUM7QUFDSCxDQUFDO0FBQzBDLG9CQUFvQixjQUFjOzs7Ozs7Ozs7QUN6RzdFLElBQWEsWUFBeUIsMkJBQU0sV0FBVyxTQUFTLFVBQVUsZ0JBQWdCLGNBQWM7Q0FDdEcsa0JBQWtCLE9BQU87Q0FDekIsTUFBTSxFQUNKLFVBQ0UsbUJBQW1CO0NBQ3ZCLE1BQU0sUUFBUSw4QkFBOEI7Q0FDNUMsTUFBTSxFQUNKLFdBQ0EsR0FBRyxvQkFDRCxNQUFNLFNBQVMsWUFBWTtDQUMvQixNQUFNLGVBQWUsTUFBTSxTQUFTLG1CQUFtQjtDQUN2RCxNQUFNLGdCQUFnQixxQkFBcUIsVUFBVSxFQUFFO0NBQ3ZELE1BQU0saUJBQUEsYUFBdUIsYUFBWSxVQUFTO0VBRWhELE1BQU0sSUFBSSxnQkFBZ0IsVUFBVSxRQUFRLGNBQWMsY0FBYyxLQUFLLENBQUMsTUFBTSxLQUFLO0NBQzNGLEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FDVixNQUFNLGFBQWEsY0FBYyxjQUFjLGNBQWM7Q0FDN0QsTUFBTSxhQUFhLFdBQVc7RUFDNUIsV0FBVztFQUNYLFVBQVU7R0FDUixNQUFNLElBQUksZ0JBQWdCLElBQUk7RUFDaEM7RUFDQSxTQUFTO0dBQ1AsTUFBTSxJQUFJLGdCQUFnQixLQUFLO0VBQ2pDO0NBQ0YsR0FBRyxjQUFjO0NBQ2pCLE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUsscUJBQXFCO0VBQzVDLEdBQUc7RUFDVztFQUNHO0VBQ2pCLEtBQUs7Q0FDUCxDQUFDO0FBQ0gsQ0FBQztBQUMwQyxVQUFVLGNBQWM7O0FDNUNuRSxJQUFNLGdCQUE2QiwyQkFBTSxXQUFXLFNBQVMsY0FBYyxnQkFBZ0IsY0FBYztDQUN2RyxNQUFNLEVBQ0osUUFDQSxXQUNBLE9BQ0EsSUFBSSxRQUNKLEdBQUcsaUJBQ0Q7Q0FDSixNQUFNLEVBQ0osT0FDQSxnQkFDRSxtQkFBbUI7Q0FDdkIsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLGlCQUFpQjtDQUN4RCxNQUFNLHVCQUF1QixNQUFNLFNBQVMsc0JBQXNCO0NBQ2xFLE1BQU0saUJBQWlCLE1BQU0sZUFBZSxhQUFhO0NBQ3pELE1BQU0sS0FBSyxZQUFZLE1BQU07Q0FJN0IsTUFBTSxnQkFBQSxhQUFzQixPQUFPLEVBQUU7Q0FDckMseUJBQXlCO0VBQ3ZCLElBQUksY0FBYyxZQUFZLElBQUk7R0FDaEMsY0FBYyxVQUFVO0dBQ3hCLE1BQU0sVUFBVTtFQUNsQjtDQUNGLEdBQUcsQ0FBQyxJQUFJLEtBQUssQ0FBQztDQUNkLE1BQU0saUJBQWlCLGtCQUFrQixnQkFBZ0Isc0JBQXNCLGVBQWU7Q0FDOUYsT0FBTyxpQkFBaUIsT0FBTyxnQkFBZ0I7RUFDN0MsS0FBSyxDQUFDLGNBQWMsY0FBYztFQUNsQyxPQUFPLENBQUM7R0FDTjtHQUNBLE1BQU07R0FFTixVQUFVO0dBRVYsb0JBQW9CLGdCQUFnQixlQUFlLGVBQWUsS0FBQTtHQUNsRSxtQkFBbUI7RUFDckIsR0FBRyxZQUFZO0NBQ2pCLENBQUM7QUFDSCxDQUFDO0FBUTBDLGNBQWMsY0FBYztBQUN2RSxJQUFhLFdBQXdCLDJCQUFNLFdBQVcsU0FBUyxTQUFTLE9BQU8sY0FBYztDQUMzRixNQUFNLE9BQU8sa0JBQWtCLENBQUMsRUFBRSxRQUFRO0NBQzFDLE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUssTUFBTTtFQUM3QixHQUFHO0VBQ0gsS0FBSztDQUNQLENBQUM7QUFDSCxDQUFDO0FBQzBDLFNBQVMsY0FBYzs7Ozs7QUNyRGxFLElBQWEsc0JBQW1DLDJCQUFNLFdBQVcsU0FBUyxvQkFBb0IsZ0JBQWdCLGNBQWM7Q0FDMUgsTUFBTSxFQUNKLFFBQ0EsV0FDQSxPQUNBLFVBQVUsZUFBZSxPQUN6QixlQUFlLE1BQ2YsR0FBRyxpQkFDRDtDQUNKLE1BQU0sVUFBVSw2QkFBNkI7Q0FDN0MsTUFBTSxRQUFRLDhCQUE4QjtDQUM1QyxNQUFNLFdBQVcsUUFBUSxZQUFZO0NBQ3JDLE1BQU0sVUFBVSxVQUFVO0NBQzFCLE1BQU0sRUFDSixXQUNBLG1CQUNFLFVBQVU7RUFDWjtFQUNBLFFBQVE7Q0FDVixDQUFDO0NBT0QsT0FBTyxpQkFBaUIsVUFBVSxnQkFBZ0I7RUFDaEQsU0FBUztFQUNULE9BQUEsRUFKQSxTQUlJO0VBQ0osS0FBSyxDQUFDLGNBQWMsU0FBUztFQUM3QixPQUFPO0dBQUM7SUFDTixVQUFVO0lBQ1YsZUFBZTtJQUNmLFlBQVksT0FBTztLQUVqQixNQUFNLGVBQWU7SUFDdkI7SUFDQSxRQUFRLE9BQU87S0FDYixNQUFNLGVBQWUseUJBQXlCQyxZQUFvQixNQUFNLFdBQVc7S0FDbkYsUUFBUSxjQUFjLElBQUksWUFBWTtLQUN0QyxRQUFRLGNBQWMsU0FBUyxNQUFNLEVBQ25DLGVBQWUsS0FDakIsQ0FBQztJQUNIO0dBQ0Y7R0FBRztHQUFjO0VBQWM7Q0FDakMsQ0FBQztBQUNILENBQUM7QUFDMEMsb0JBQW9CLGNBQWM7Ozs7Ozs7OztBQzdDN0UsSUFBYSxZQUF5QiwyQkFBTSxXQUFXLFNBQVMsVUFBVSxPQUFPLGNBQWM7Q0FDN0Ysa0JBQWtCLE9BQU87Q0FDekIsT0FBb0IsZUFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSyxxQkFBcUI7RUFDNUMsR0FBRztFQUNILEtBQUs7Q0FDUCxDQUFDO0FBQ0gsQ0FBQztBQUMwQyxVQUFVLGNBQWM7O0FDZG5FLElBQU0scUJBQXFCO0FBRzNCLFNBQVMsaUJBQWlCLE1BQU07Q0FDOUIsTUFBTSxTQUFTLEtBQUssY0FBYyxpQkFBaUIsTUFBTSxXQUFXLFNBQVM7Q0FDN0UsSUFBSSxlQUFlO0NBQ25CLE9BQU8sT0FBTyxTQUFTLEdBQUc7RUFDeEIsTUFBTSxXQUFXLE9BQU87RUFDeEIsSUFBSSxTQUFTLGNBQWMsSUFDekIsZUFBZTtDQUVuQjtDQUNBLE9BQU87QUFDVDs7Ozs7QUFNQSxTQUFnQixpQ0FBaUMsVUFBVSxNQUFNO0NBQy9ELE1BQU0sVUFBVSxXQUFXO0NBQzNCLE1BQU0sVUFBQSxhQUFnQixPQUFPLElBQUk7Q0FHakMsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxDQUFDLFdBQVdDLEtBQ2Q7RUFFRixNQUFNLE9BQU8sUUFBUTtFQUNyQixJQUFJLFFBQVEsTUFDVjtFQUVGLE1BQU0sV0FBVyxpQkFBaUIsSUFBSTtFQUN0QyxJQUFJLFlBQVksTUFDZDtFQUVGLE1BQU0sZ0JBQWdCLFNBQVM7RUFDL0IsTUFBTSxjQUFjLEdBQUcsZ0JBQWdCO0VBQ3ZDLFNBQVMsWUFBWTtFQUNyQixRQUFRLE1BQUEsV0FBMkQ7R0FDakUsSUFBSSxTQUFTLGNBQWMsYUFDekIsU0FBUyxZQUFZO0VBRXpCLENBQUM7RUFDRCxhQUFhO0dBQ1gsUUFBUSxNQUFNO0dBQ2QsSUFBSSxTQUFTLGNBQWMsYUFDekIsU0FBUyxZQUFZO0VBRXpCO0NBQ0YsR0FBRztFQUFDO0VBQVM7RUFBUztDQUFPLENBQUM7Q0FDOUIsT0FBTztBQUNUOzs7OztBQzlDQSxJQUFhLHNCQUFtQywyQkFBTSxXQUFXLFNBQVMsb0JBQW9CLGdCQUFnQixjQUFjO0NBQzFILE1BQU0sRUFDSixRQUNBLFdBQ0EsT0FDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxFQUNKLFVBQ0UsNkJBQTZCO0NBQ2pDLE1BQU0sVUFBVSxTQUFTLE9BQU8sVUFBVSxPQUFPO0NBS2pELE1BQU0sQ0FBQyxPQUFPLFlBQUEsYUFBa0IsU0FBUyxLQUFLO0NBQzlDLHlCQUF5QjtFQUN2QixTQUFTLElBQUk7Q0FDZixHQUFHLENBQUMsQ0FBQztDQUNMLE1BQU0sVUFBVSxTQUFTO0NBQ3pCLE1BQU0sV0FBVyxpQ0FBaUMsT0FBTztDQUN6RCxPQUFPLGlCQUFpQixPQUFPLGdCQUFnQjtFQUM3QyxTQUFTO0VBQ1QsS0FBSyxDQUFDLGNBQWMsUUFBUTtFQUM1QixPQUFPLENBQUM7R0FDTixNQUFNO0dBQ04sYUFBYTtHQUNiLGVBQWU7RUFDakIsR0FBRyxZQUFZO0NBQ2pCLENBQUM7QUFDSCxDQUFDO0FBQzBDLG9CQUFvQixjQUFjOzs7Ozs7Ozs7QUM5QjdFLElBQWEsWUFBeUIsMkJBQU0sV0FBVyxTQUFTLFVBQVUsT0FBTyxjQUFjO0NBQzdGLGtCQUFrQixPQUFPO0NBQ3pCLE9BQW9CLGVBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUsscUJBQXFCO0VBQzVDLEdBQUc7RUFDSCxLQUFLO0NBQ1AsQ0FBQztBQUNILENBQUM7QUFDMEMsVUFBVSxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FFaEJuRSxJQUFhQyxTQUFPQzs7OztBQUlwQixJQUFhQyxXQUFTQzs7Ozs7QUFLdEIsSUFBYUMsU0FBT0M7Ozs7O0FBS3BCLElBQWFDLFVBQVFDOzs7O0FBSXJCLElBQWEsYUFBYTs7Ozs7Ozs7Ozs7QUNsQjFCLElBQWFDLFNBQU9DOzs7O0FBSXBCLElBQWFDLFdBQVNDOzs7O0FBSXRCLElBQWFDLGtCQUFnQkM7Ozs7QUFJN0IsSUFBYUMsZ0JBQWNDOzs7Ozs7Ozs7Ozs7QUNaM0IsSUFBYUMsWUFBVTs7OztBQUl2QixJQUFhQyxjQUFZOzs7O0FBSXpCLElBQWFDLGFBQVc7Ozs7QUFJeEIsSUFBYUMsa0JBQWdCQzs7OztBQUk3QixJQUFhQyxnQkFBY0M7Ozs7Ozs7OztBQ2xCM0IsSUFBYUMsZ0JBQWM7Ozs7QUFJM0IsSUFBYUMsYUFBVzs7Ozs7O0FDSnhCLElBQWFDLGdCQUFjOzs7Ozs7Ozs7Ozs7OztBQ0UzQixJQUFhQyxTQUFPQzs7OztBQUlwQixJQUFhQyxXQUFTQzs7OztBQUl0QixJQUFhQyxrQkFBZ0JDOzs7O0FBSTdCLElBQWFDLGdCQUFjQzs7Ozs7QUFLM0IsSUFBYUMsU0FBT0M7Ozs7O0FBS3BCLElBQWFDLFVBQVFDOzs7OztBQUtyQixJQUFhQyxZQUFVOzs7Ozs7Ozs7Ozs7Ozs7QUM1QnZCLElBQWEsaUJBQWlCOzs7OztBQUs5QixJQUFhLGtCQUFrQjs7Ozs7QUFLL0IsSUFBYSxjQUFjOzs7OztBQUszQixJQUFhLGVBQWU7Ozs7O0FBSzVCLElBQWEsa0JBQWtCOzs7Ozs7QUFNL0IsSUFBYSxrQkFBa0I7Ozs7OztBQU0vQixJQUFhLG1CQUFtQjs7Ozs7Ozs7Ozs7O0FDL0JoQyxJQUFhLE9BQU9DOzs7O0FBSXBCLElBQWEsU0FBU0M7Ozs7QUFJdEIsSUFBYSxlQUFlQzs7Ozs7QUFLNUIsSUFBYSxPQUFPQzs7Ozs7QUFLcEIsSUFBYSxRQUFRQzs7Ozs7Ozs7Ozs7QUNwQnJCLElBQWFDLFlBQVU7Ozs7QUFJdkIsSUFBYUMsY0FBWTs7OztBQUl6QixJQUFhQyxhQUFXOzs7O0FBSXhCLElBQWFDLGdCQUFjOzs7Ozs7Ozs7Ozs7QUNWM0IsSUFBYSxVQUFVOzs7O0FBSXZCLElBQWEsWUFBWTs7OztBQUl6QixJQUFhQyxhQUFXOzs7O0FBSXhCLElBQWEsZ0JBQWdCQzs7OztBQUk3QixJQUFhLGNBQWNDOzs7Ozs7Ozs7O0FDaEIzQixJQUFhQyxjQUFZQzs7OztBQUl6QixJQUFhLFVBQVVDOzs7O0FBSXZCLElBQWFDLGFBQVc7Ozs7Ozs7Ozs7O0FDUnhCLElBQWEsYUFBYTs7Ozs7O0FBTTFCLElBQWEsY0FBYzs7Ozs7Ozs7Ozs7O0FDUjNCLElBQWEsVUFBVTs7OztBQUl2QixJQUFhLFdBQVc7Ozs7Ozs7QUFPeEIsSUFBYSxzQkFBc0I7Ozs7QUFJbkMsSUFBYSxnQkFBZ0I7Ozs7O0FBSzdCLElBQWEsVUFBVTs7Ozs7Ozs7OztBQ2xCdkIsSUFBYSxZQUFZQzs7OztBQUl6QixJQUFhQyxnQkFBYzs7OztBQUkzQixJQUFhQyxhQUFXOzs7Ozs7O0FDVHhCLElBQWEsY0FBYzs7Ozs7O0FDRDNCLElBQWEsV0FBVyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExLDEyLDEzLDE0LDE1LDE2LDE3LDE4LDE5LDIwLDIxLDIyLDIzLDI0LDI1LDI2LDI3LDI4LDI5LDMwLDMxLDMyLDMzLDM0LDM1LDM2LDM3LDM4LDM5LDQwLDQxLDQyLDQzLDQ0LDQ1LDQ2LDQ3LDQ4LDQ5LDUwLDUxLDUyLDUzLDU0LDU1LDU2LDU3LDU4LDU5LDYwLDYxLDYyLDYzLDY0LDY1LDY2LDY3LDY4LDY5LDcwLDcxLDcyLDczLDc0LDc1LDc2LDc3LDc4LDc5LDgwLDgxLDgyLDgzLDg0LDg1LDg2LDg3LDg4LDg5LDkwLDkxLDkyLDkzLDk0LDk1XX0=