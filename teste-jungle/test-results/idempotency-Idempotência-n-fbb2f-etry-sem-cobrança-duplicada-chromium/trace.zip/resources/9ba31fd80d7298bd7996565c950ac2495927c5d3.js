import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/dropdown-menu.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport1_react, 1);const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=e9f94b2e";
import { Menu as MenuPrimitive } from "/node_modules/.vite/deps/@base-ui_react_menu.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
import { ChevronRightIcon, CheckIcon } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/dropdown-menu.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
function DropdownMenu(t0) {
	const $ = _c(5);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(MenuPrimitive.Root, {
			"data-slot": "dropdown-menu",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 26,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c2 = DropdownMenu;
function DropdownMenuPortal(t0) {
	const $ = _c(5);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(MenuPrimitive.Portal, {
			"data-slot": "dropdown-menu-portal",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 54,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c3 = DropdownMenuPortal;
function DropdownMenuTrigger(t0) {
	const $ = _c(5);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(MenuPrimitive.Trigger, {
			"data-slot": "dropdown-menu-trigger",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 82,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c4 = DropdownMenuTrigger;
function DropdownMenuContent(t0) {
	const $ = _c(19);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 19; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let className;
	let props;
	let t1;
	let t2;
	let t3;
	let t4;
	if ($[1] !== t0) {
		({align: t1, alignOffset: t2, side: t3, sideOffset: t4, className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
		$[4] = t1;
		$[5] = t2;
		$[6] = t3;
		$[7] = t4;
	} else {
		className = $[2];
		props = $[3];
		t1 = $[4];
		t2 = $[5];
		t3 = $[6];
		t4 = $[7];
	}
	const align = t1 === undefined ? "start" : t1;
	const alignOffset = t2 === undefined ? 0 : t2;
	const side = t3 === undefined ? "bottom" : t3;
	const sideOffset = t4 === undefined ? 4 : t4;
	let t5;
	if ($[8] !== className) {
		t5 = cn("z-50 max-h-(--available-height) w-(--anchor-width) min-w-32 origin-(--transform-origin) overflow-x-hidden overflow-y-auto rounded-lg bg-popover p-1 text-popover-foreground shadow-md ring-1 ring-foreground/10 duration-100 outline-none data-[side=bottom]:slide-in-from-top-2 data-[side=inline-end]:slide-in-from-left-2 data-[side=inline-start]:slide-in-from-right-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:overflow-hidden data-closed:fade-out-0 data-closed:zoom-out-95", className);
		$[8] = className;
		$[9] = t5;
	} else {
		t5 = $[9];
	}
	let t6;
	if ($[10] !== props || $[11] !== t5) {
		t6 = /* @__PURE__ */ _jsxDEV(MenuPrimitive.Popup, {
			"data-slot": "dropdown-menu-content",
			className: t5,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 142,
			columnNumber: 10
		}, this);
		$[10] = props;
		$[11] = t5;
		$[12] = t6;
	} else {
		t6 = $[12];
	}
	let t7;
	if ($[13] !== align || $[14] !== alignOffset || $[15] !== side || $[16] !== sideOffset || $[17] !== t6) {
		t7 = /* @__PURE__ */ _jsxDEV(MenuPrimitive.Portal, { children: /* @__PURE__ */ _jsxDEV(MenuPrimitive.Positioner, {
			className: "isolate z-50 outline-none",
			align,
			alignOffset,
			side,
			sideOffset,
			children: t6
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 151,
			columnNumber: 32
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 151,
			columnNumber: 10
		}, this);
		$[13] = align;
		$[14] = alignOffset;
		$[15] = side;
		$[16] = sideOffset;
		$[17] = t6;
		$[18] = t7;
	} else {
		t7 = $[18];
	}
	return t7;
}
_c5 = DropdownMenuContent;
function DropdownMenuGroup(t0) {
	const $ = _c(5);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(MenuPrimitive.Group, {
			"data-slot": "dropdown-menu-group",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 183,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c6 = DropdownMenuGroup;
function DropdownMenuLabel(t0) {
	const $ = _c(11);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 11; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let className;
	let inset;
	let props;
	if ($[1] !== t0) {
		({className, inset, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = inset;
		$[4] = props;
	} else {
		className = $[2];
		inset = $[3];
		props = $[4];
	}
	let t1;
	if ($[5] !== className) {
		t1 = cn("px-1.5 py-1 text-xs font-medium text-muted-foreground data-inset:pl-7", className);
		$[5] = className;
		$[6] = t1;
	} else {
		t1 = $[6];
	}
	let t2;
	if ($[7] !== inset || $[8] !== props || $[9] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(MenuPrimitive.GroupLabel, {
			"data-slot": "dropdown-menu-label",
			"data-inset": inset,
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 227,
			columnNumber: 10
		}, this);
		$[7] = inset;
		$[8] = props;
		$[9] = t1;
		$[10] = t2;
	} else {
		t2 = $[10];
	}
	return t2;
}
_c7 = DropdownMenuLabel;
function DropdownMenuItem(t0) {
	const $ = _c(13);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 13; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let className;
	let inset;
	let props;
	let t1;
	if ($[1] !== t0) {
		({className, inset, variant: t1, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = inset;
		$[4] = props;
		$[5] = t1;
	} else {
		className = $[2];
		inset = $[3];
		props = $[4];
		t1 = $[5];
	}
	const variant = t1 === undefined ? "default" : t1;
	let t2;
	if ($[6] !== className) {
		t2 = cn("group/dropdown-menu-item relative flex cursor-default items-center gap-1.5 rounded-md px-1.5 py-1 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground not-data-[variant=destructive]:focus:**:text-accent-foreground data-inset:pl-7 data-[variant=destructive]:text-destructive data-[variant=destructive]:focus:bg-destructive/10 data-[variant=destructive]:focus:text-destructive dark:data-[variant=destructive]:focus:bg-destructive/20 data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 data-[variant=destructive]:*:[svg]:text-destructive", className);
		$[6] = className;
		$[7] = t2;
	} else {
		t2 = $[7];
	}
	let t3;
	if ($[8] !== inset || $[9] !== props || $[10] !== t2 || $[11] !== variant) {
		t3 = /* @__PURE__ */ _jsxDEV(MenuPrimitive.Item, {
			"data-slot": "dropdown-menu-item",
			"data-inset": inset,
			"data-variant": variant,
			className: t2,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 278,
			columnNumber: 10
		}, this);
		$[8] = inset;
		$[9] = props;
		$[10] = t2;
		$[11] = variant;
		$[12] = t3;
	} else {
		t3 = $[12];
	}
	return t3;
}
_c8 = DropdownMenuItem;
function DropdownMenuSub(t0) {
	const $ = _c(5);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(MenuPrimitive.SubmenuRoot, {
			"data-slot": "dropdown-menu-sub",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 309,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c9 = DropdownMenuSub;
function DropdownMenuSubTrigger(t0) {
	const $ = _c(14);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 14; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let children;
	let className;
	let inset;
	let props;
	if ($[1] !== t0) {
		({className, inset, children, ...props} = t0);
		$[1] = t0;
		$[2] = children;
		$[3] = className;
		$[4] = inset;
		$[5] = props;
	} else {
		children = $[2];
		className = $[3];
		inset = $[4];
		props = $[5];
	}
	let t1;
	if ($[6] !== className) {
		t1 = cn("flex cursor-default items-center gap-1.5 rounded-md px-1.5 py-1 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground not-data-[variant=destructive]:focus:**:text-accent-foreground data-inset:pl-7 data-popup-open:bg-accent data-popup-open:text-accent-foreground data-open:bg-accent data-open:text-accent-foreground [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className);
		$[6] = className;
		$[7] = t1;
	} else {
		t1 = $[7];
	}
	let t2;
	if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV(ChevronRightIcon, { className: "ml-auto" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 357,
			columnNumber: 10
		}, this);
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	let t3;
	if ($[9] !== children || $[10] !== inset || $[11] !== props || $[12] !== t1) {
		t3 = /* @__PURE__ */ _jsxDEV(MenuPrimitive.SubmenuTrigger, {
			"data-slot": "dropdown-menu-sub-trigger",
			"data-inset": inset,
			className: t1,
			...props,
			children: [children, t2]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 364,
			columnNumber: 10
		}, this);
		$[9] = children;
		$[10] = inset;
		$[11] = props;
		$[12] = t1;
		$[13] = t3;
	} else {
		t3 = $[13];
	}
	return t3;
}
_c10 = DropdownMenuSubTrigger;
function DropdownMenuSubContent(t0) {
	const $ = _c(17);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 17; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let className;
	let props;
	let t1;
	let t2;
	let t3;
	let t4;
	if ($[1] !== t0) {
		({align: t1, alignOffset: t2, side: t3, sideOffset: t4, className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
		$[4] = t1;
		$[5] = t2;
		$[6] = t3;
		$[7] = t4;
	} else {
		className = $[2];
		props = $[3];
		t1 = $[4];
		t2 = $[5];
		t3 = $[6];
		t4 = $[7];
	}
	const align = t1 === undefined ? "start" : t1;
	const alignOffset = t2 === undefined ? -3 : t2;
	const side = t3 === undefined ? "right" : t3;
	const sideOffset = t4 === undefined ? 0 : t4;
	let t5;
	if ($[8] !== className) {
		t5 = cn("w-auto min-w-[96px] rounded-lg bg-popover p-1 text-popover-foreground shadow-lg ring-1 ring-foreground/10 duration-100 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", className);
		$[8] = className;
		$[9] = t5;
	} else {
		t5 = $[9];
	}
	let t6;
	if ($[10] !== align || $[11] !== alignOffset || $[12] !== props || $[13] !== side || $[14] !== sideOffset || $[15] !== t5) {
		t6 = /* @__PURE__ */ _jsxDEV(DropdownMenuContent, {
			"data-slot": "dropdown-menu-sub-content",
			className: t5,
			align,
			alignOffset,
			side,
			sideOffset,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 427,
			columnNumber: 10
		}, this);
		$[10] = align;
		$[11] = alignOffset;
		$[12] = props;
		$[13] = side;
		$[14] = sideOffset;
		$[15] = t5;
		$[16] = t6;
	} else {
		t6 = $[16];
	}
	return t6;
}
_c11 = DropdownMenuSubContent;
function DropdownMenuCheckboxItem(t0) {
	const $ = _c(16);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 16; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let checked;
	let children;
	let className;
	let inset;
	let props;
	if ($[1] !== t0) {
		({className, children, checked, inset, ...props} = t0);
		$[1] = t0;
		$[2] = checked;
		$[3] = children;
		$[4] = className;
		$[5] = inset;
		$[6] = props;
	} else {
		checked = $[2];
		children = $[3];
		className = $[4];
		inset = $[5];
		props = $[6];
	}
	let t1;
	if ($[7] !== className) {
		t1 = cn("relative flex cursor-default items-center gap-1.5 rounded-md py-1 pr-8 pl-1.5 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground focus:**:text-accent-foreground data-inset:pl-7 data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className);
		$[7] = className;
		$[8] = t1;
	} else {
		t1 = $[8];
	}
	let t2;
	if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV("span", {
			className: "pointer-events-none absolute right-2 flex items-center justify-center",
			"data-slot": "dropdown-menu-checkbox-item-indicator",
			children: /* @__PURE__ */ _jsxDEV(MenuPrimitive.CheckboxItemIndicator, { children: /* @__PURE__ */ _jsxDEV(CheckIcon, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 484,
				columnNumber: 185
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 484,
				columnNumber: 148
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 484,
			columnNumber: 10
		}, this);
		$[9] = t2;
	} else {
		t2 = $[9];
	}
	let t3;
	if ($[10] !== checked || $[11] !== children || $[12] !== inset || $[13] !== props || $[14] !== t1) {
		t3 = /* @__PURE__ */ _jsxDEV(MenuPrimitive.CheckboxItem, {
			"data-slot": "dropdown-menu-checkbox-item",
			"data-inset": inset,
			className: t1,
			checked,
			...props,
			children: [t2, children]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 491,
			columnNumber: 10
		}, this);
		$[10] = checked;
		$[11] = children;
		$[12] = inset;
		$[13] = props;
		$[14] = t1;
		$[15] = t3;
	} else {
		t3 = $[15];
	}
	return t3;
}
_c12 = DropdownMenuCheckboxItem;
function DropdownMenuRadioGroup(t0) {
	const $ = _c(5);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(MenuPrimitive.RadioGroup, {
			"data-slot": "dropdown-menu-radio-group",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 523,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c13 = DropdownMenuRadioGroup;
function DropdownMenuRadioItem(t0) {
	const $ = _c(14);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 14; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let children;
	let className;
	let inset;
	let props;
	if ($[1] !== t0) {
		({className, children, inset, ...props} = t0);
		$[1] = t0;
		$[2] = children;
		$[3] = className;
		$[4] = inset;
		$[5] = props;
	} else {
		children = $[2];
		className = $[3];
		inset = $[4];
		props = $[5];
	}
	let t1;
	if ($[6] !== className) {
		t1 = cn("relative flex cursor-default items-center gap-1.5 rounded-md py-1 pr-8 pl-1.5 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground focus:**:text-accent-foreground data-inset:pl-7 data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className);
		$[6] = className;
		$[7] = t1;
	} else {
		t1 = $[7];
	}
	let t2;
	if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV("span", {
			className: "pointer-events-none absolute right-2 flex items-center justify-center",
			"data-slot": "dropdown-menu-radio-item-indicator",
			children: /* @__PURE__ */ _jsxDEV(MenuPrimitive.RadioItemIndicator, { children: /* @__PURE__ */ _jsxDEV(CheckIcon, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 571,
				columnNumber: 179
			}, this) }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 571,
				columnNumber: 145
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 571,
			columnNumber: 10
		}, this);
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	let t3;
	if ($[9] !== children || $[10] !== inset || $[11] !== props || $[12] !== t1) {
		t3 = /* @__PURE__ */ _jsxDEV(MenuPrimitive.RadioItem, {
			"data-slot": "dropdown-menu-radio-item",
			"data-inset": inset,
			className: t1,
			...props,
			children: [t2, children]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 578,
			columnNumber: 10
		}, this);
		$[9] = children;
		$[10] = inset;
		$[11] = props;
		$[12] = t1;
		$[13] = t3;
	} else {
		t3 = $[13];
	}
	return t3;
}
_c14 = DropdownMenuRadioItem;
function DropdownMenuSeparator(t0) {
	const $ = _c(9);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("-mx-1 my-1 h-px bg-border", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(MenuPrimitive.Separator, {
			"data-slot": "dropdown-menu-separator",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 621,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c15 = DropdownMenuSeparator;
function DropdownMenuShortcut(t0) {
	const $ = _c(9);
	if ($[0] !== "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "278f3ae923439e4565a67a097a2b8a2ab980b96c00e960a99d51938878b0a21b";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("ml-auto text-xs tracking-widest text-muted-foreground group-focus/dropdown-menu-item:text-accent-foreground", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("span", {
			"data-slot": "dropdown-menu-shortcut",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 662,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c16 = DropdownMenuShortcut;
export { DropdownMenu, DropdownMenuPortal, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuGroup, DropdownMenuLabel, DropdownMenuItem, DropdownMenuCheckboxItem, DropdownMenuRadioGroup, DropdownMenuRadioItem, DropdownMenuSeparator, DropdownMenuShortcut, DropdownMenuSub, DropdownMenuSubTrigger, DropdownMenuSubContent };
var _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16;
$RefreshReg$(_c2, "DropdownMenu");
$RefreshReg$(_c3, "DropdownMenuPortal");
$RefreshReg$(_c4, "DropdownMenuTrigger");
$RefreshReg$(_c5, "DropdownMenuContent");
$RefreshReg$(_c6, "DropdownMenuGroup");
$RefreshReg$(_c7, "DropdownMenuLabel");
$RefreshReg$(_c8, "DropdownMenuItem");
$RefreshReg$(_c9, "DropdownMenuSub");
$RefreshReg$(_c10, "DropdownMenuSubTrigger");
$RefreshReg$(_c11, "DropdownMenuSubContent");
$RefreshReg$(_c12, "DropdownMenuCheckboxItem");
$RefreshReg$(_c13, "DropdownMenuRadioGroup");
$RefreshReg$(_c14, "DropdownMenuRadioItem");
$RefreshReg$(_c15, "DropdownMenuSeparator");
$RefreshReg$(_c16, "DropdownMenuShortcut");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/dropdown-menu.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/dropdown-menu.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/dropdown-menu.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/dropdown-menu.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFlBQVlBLFdBQVc7QUFDdkIsU0FBU0MsUUFBUUMscUJBQXFCO0FBQ3RDLFNBQVNDLFVBQVU7QUFDbkIsU0FBU0Msa0JBQWtCQyxpQkFBaUI7OztBQUU1QyxTQUFBQyxhQUFBQyxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFELElBQUE7RUFBc0IsS0FBQU0sU0FBQU47RUFBc0NDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztDQUFBO0VBQUFBLFFBQUFMLEVBQUE7Q0FBQTtDQUFBLElBQUFNO0NBQUEsSUFBQU4sRUFBQSxPQUFBSyxPQUFBO0VBQ25EQyxLQUFBO0dBQThCO0dBQWUsR0FBS0Q7RUFBSzs7Ozs7RUFBSUwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0NBQUE7RUFBQUEsS0FBQU4sRUFBQTtDQUFBO0NBQUEsT0FBM0RNO0FBQTJEOztBQUdwRSxTQUFBQyxtQkFBQVIsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUwsRUFBQSxPQUFBRCxJQUFBO0VBQTRCLEtBQUFNLFNBQUFOO0VBQXdDQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQUs7Q0FBQTtFQUFBQSxRQUFBTCxFQUFBO0NBQUE7Q0FBQSxJQUFBTTtDQUFBLElBQUFOLEVBQUEsT0FBQUssT0FBQTtFQUMzREMsS0FBQTtHQUFnQztHQUFzQixHQUFLRDtFQUFLOzs7OztFQUFJTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxPQUFwRU07QUFBb0U7O0FBRzdFLFNBQUFFLG9CQUFBVCxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFELElBQUE7RUFBNkIsS0FBQU0sU0FBQU47RUFBeUNDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztDQUFBO0VBQUFBLFFBQUFMLEVBQUE7Q0FBQTtDQUFBLElBQUFNO0NBQUEsSUFBQU4sRUFBQSxPQUFBSyxPQUFBO0VBQzdEQyxLQUFBO0dBQWlDO0dBQXVCLEdBQUtEO0VBQUs7Ozs7O0VBQUlMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtDQUFBO0VBQUFBLEtBQUFOLEVBQUE7Q0FBQTtDQUFBLE9BQXRFTTtBQUFzRTs7QUFHL0UsU0FBQUcsb0JBQUFWLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBVTtDQUFBLElBQUFMO0NBQUEsSUFBQUM7Q0FBQSxJQUFBSztDQUFBLElBQUFDO0NBQUEsSUFBQUM7Q0FBQSxJQUFBYixFQUFBLE9BQUFELElBQUE7RUFBNkIsRUFBQWUsT0FBQVIsSUFBQVMsYUFBQUosSUFBQUssTUFBQUosSUFBQUssWUFBQUosSUFBQUgsV0FBQSxHQUFBTCxTQUFBTjtFQVcxQkMsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFVO0VBQUFWLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFXO0VBQUFYLEVBQUEsS0FBQVk7RUFBQVosRUFBQSxLQUFBYTtDQUFBO0VBQUFILFlBQUFWLEVBQUE7RUFBQUssUUFBQUwsRUFBQTtFQUFBTSxLQUFBTixFQUFBO0VBQUFXLEtBQUFYLEVBQUE7RUFBQVksS0FBQVosRUFBQTtFQUFBYSxLQUFBYixFQUFBO0NBQUE7Q0FWRCxNQUFBYyxRQUFBUixPQUFBWSxZQUFBLFVBQUFaO0NBQ0EsTUFBQVMsY0FBQUosT0FBQU8sWUFBQSxJQUFBUDtDQUNBLE1BQUFLLE9BQUFKLE9BQUFNLFlBQUEsV0FBQU47Q0FDQSxNQUFBSyxhQUFBSixPQUFBSyxZQUFBLElBQUFMO0NBQWMsSUFBQU07Q0FBQSxJQUFBbkIsRUFBQSxPQUFBVSxXQUFBO0VBbUJLUyxLQUFBeEIsR0FBRyxxb0JBQXFvQmUsU0FBVTtFQUFDVixFQUFBLEtBQUFVO0VBQUFWLEVBQUEsS0FBQW1CO0NBQUE7RUFBQUEsS0FBQW5CLEVBQUE7Q0FBQTtDQUFBLElBQUFvQjtDQUFBLElBQUFwQixFQUFBLFFBQUFLLFNBQUFMLEVBQUEsUUFBQW1CLElBQUE7RUFGaHFCQyxLQUFBO0dBQ1k7R0FDQyxXQUFBRDtHQUFtcEIsR0FDMXBCZDtFQUFLOzs7OztFQUNUTCxFQUFBLE1BQUFLO0VBQUFMLEVBQUEsTUFBQW1CO0VBQUFuQixFQUFBLE1BQUFvQjtDQUFBO0VBQUFBLEtBQUFwQixFQUFBO0NBQUE7Q0FBQSxJQUFBcUI7Q0FBQSxJQUFBckIsRUFBQSxRQUFBYyxTQUFBZCxFQUFBLFFBQUFlLGVBQUFmLEVBQUEsUUFBQWdCLFFBQUFoQixFQUFBLFFBQUFpQixjQUFBakIsRUFBQSxRQUFBb0IsSUFBQTtFQVpOQyxLQUFBLDBEQUNFO0dBQ1k7R0FDSFA7R0FDTUM7R0FDUEM7R0FDTUM7YUFFWkc7RUFLRjs7OztXQUNGOzs7OztFQUF1QnBCLEVBQUEsTUFBQWM7RUFBQWQsRUFBQSxNQUFBZTtFQUFBZixFQUFBLE1BQUFnQjtFQUFBaEIsRUFBQSxNQUFBaUI7RUFBQWpCLEVBQUEsTUFBQW9CO0VBQUFwQixFQUFBLE1BQUFxQjtDQUFBO0VBQUFBLEtBQUFyQixFQUFBO0NBQUE7Q0FBQSxPQWR2QnFCO0FBY3VCOztBQUkzQixTQUFBQyxrQkFBQXZCLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBSztDQUFBLElBQUFMLEVBQUEsT0FBQUQsSUFBQTtFQUEyQixLQUFBTSxTQUFBTjtFQUF1Q0MsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFLO0NBQUE7RUFBQUEsUUFBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFLLE9BQUE7RUFDekRDLEtBQUE7R0FBK0I7R0FBcUIsR0FBS0Q7RUFBSzs7Ozs7RUFBSUwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0NBQUE7RUFBQUEsS0FBQU4sRUFBQTtDQUFBO0NBQUEsT0FBbEVNO0FBQWtFOztBQUczRSxTQUFBaUIsa0JBQUF4QixJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQVU7Q0FBQSxJQUFBYztDQUFBLElBQUFuQjtDQUFBLElBQUFMLEVBQUEsT0FBQUQsSUFBQTtFQUEyQixFQUFBVyxXQUFBYyxPQUFBLEdBQUFuQixTQUFBTjtFQU0xQkMsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFVO0VBQUFWLEVBQUEsS0FBQXdCO0VBQUF4QixFQUFBLEtBQUFLO0NBQUE7RUFBQUssWUFBQVYsRUFBQTtFQUFBd0IsUUFBQXhCLEVBQUE7RUFBQUssUUFBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFVLFdBQUE7RUFLZ0JKLEtBQUFYLEdBQ1QseUVBQ0FlLFNBQ0Y7RUFBQ1YsRUFBQSxLQUFBVTtFQUFBVixFQUFBLEtBQUFNO0NBQUE7RUFBQUEsS0FBQU4sRUFBQTtDQUFBO0NBQUEsSUFBQVc7Q0FBQSxJQUFBWCxFQUFBLE9BQUF3QixTQUFBeEIsRUFBQSxPQUFBSyxTQUFBTCxFQUFBLE9BQUFNLElBQUE7RUFOSEssS0FBQTtHQUNZO0dBQ0VhO0dBQ0QsV0FBQWxCO0dBR1YsR0FDR0Q7RUFBSzs7Ozs7RUFDVEwsRUFBQSxLQUFBd0I7RUFBQXhCLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtFQUFBTixFQUFBLE1BQUFXO0NBQUE7RUFBQUEsS0FBQVgsRUFBQTtDQUFBO0NBQUEsT0FSRlc7QUFRRTs7QUFJTixTQUFBYyxpQkFBQTFCLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBVTtDQUFBLElBQUFjO0NBQUEsSUFBQW5CO0NBQUEsSUFBQUM7Q0FBQSxJQUFBTixFQUFBLE9BQUFELElBQUE7RUFBMEIsRUFBQVcsV0FBQWMsT0FBQUUsU0FBQXBCLElBQUEsR0FBQUQsU0FBQU47RUFRekJDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBVTtFQUFBVixFQUFBLEtBQUF3QjtFQUFBeEIsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0NBQUE7RUFBQUksWUFBQVYsRUFBQTtFQUFBd0IsUUFBQXhCLEVBQUE7RUFBQUssUUFBQUwsRUFBQTtFQUFBTSxLQUFBTixFQUFBO0NBQUE7Q0FMQyxNQUFBMEIsVUFBQXBCLE9BQUFZLFlBQUEsWUFBQVo7Q0FBbUIsSUFBQUs7Q0FBQSxJQUFBWCxFQUFBLE9BQUFVLFdBQUE7RUFXSkMsS0FBQWhCLEdBQ1QsOG9CQUNBZSxTQUNGO0VBQUNWLEVBQUEsS0FBQVU7RUFBQVYsRUFBQSxLQUFBVztDQUFBO0VBQUFBLEtBQUFYLEVBQUE7Q0FBQTtDQUFBLElBQUFZO0NBQUEsSUFBQVosRUFBQSxPQUFBd0IsU0FBQXhCLEVBQUEsT0FBQUssU0FBQUwsRUFBQSxRQUFBVyxNQUFBWCxFQUFBLFFBQUEwQixTQUFBO0VBUEhkLEtBQUE7R0FDWTtHQUNFWTtHQUNFRTtHQUNILFdBQUFmO0dBR1YsR0FDR047RUFBSzs7Ozs7RUFDVEwsRUFBQSxLQUFBd0I7RUFBQXhCLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxNQUFBVztFQUFBWCxFQUFBLE1BQUEwQjtFQUFBMUIsRUFBQSxNQUFBWTtDQUFBO0VBQUFBLEtBQUFaLEVBQUE7Q0FBQTtDQUFBLE9BVEZZO0FBU0U7O0FBSU4sU0FBQWUsZ0JBQUE1QixJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFELElBQUE7RUFBeUIsS0FBQU0sU0FBQU47RUFBNkNDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztDQUFBO0VBQUFBLFFBQUFMLEVBQUE7Q0FBQTtDQUFBLElBQUFNO0NBQUEsSUFBQU4sRUFBQSxPQUFBSyxPQUFBO0VBQzdEQyxLQUFBO0dBQXFDO0dBQW1CLEdBQUtEO0VBQUs7Ozs7O0VBQUlMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtDQUFBO0VBQUFBLEtBQUFOLEVBQUE7Q0FBQTtDQUFBLE9BQXRFTTtBQUFzRTs7QUFHL0UsU0FBQXNCLHVCQUFBN0IsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLElBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUE2QjtDQUFBLElBQUFuQjtDQUFBLElBQUFjO0NBQUEsSUFBQW5CO0NBQUEsSUFBQUwsRUFBQSxPQUFBRCxJQUFBO0VBQWdDLEVBQUFXLFdBQUFjLE9BQUFLLFVBQUEsR0FBQXhCLFNBQUFOO0VBTy9CQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQTZCO0VBQUE3QixFQUFBLEtBQUFVO0VBQUFWLEVBQUEsS0FBQXdCO0VBQUF4QixFQUFBLEtBQUFLO0NBQUE7RUFBQXdCLFdBQUE3QixFQUFBO0VBQUFVLFlBQUFWLEVBQUE7RUFBQXdCLFFBQUF4QixFQUFBO0VBQUFLLFFBQUFMLEVBQUE7Q0FBQTtDQUFBLElBQUFNO0NBQUEsSUFBQU4sRUFBQSxPQUFBVSxXQUFBO0VBS2dCSixLQUFBWCxHQUNULDBhQUNBZSxTQUNGO0VBQUNWLEVBQUEsS0FBQVU7RUFBQVYsRUFBQSxLQUFBTTtDQUFBO0VBQUFBLEtBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFXO0NBQUEsSUFBQVgsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBSURPLEtBQUEsd0JBQUMsa0JBQUQsRUFBNEIscUJBQVM7Ozs7O0VBQUdYLEVBQUEsS0FBQVc7Q0FBQTtFQUFBQSxLQUFBWCxFQUFBO0NBQUE7Q0FBQSxJQUFBWTtDQUFBLElBQUFaLEVBQUEsT0FBQTZCLFlBQUE3QixFQUFBLFFBQUF3QixTQUFBeEIsRUFBQSxRQUFBSyxTQUFBTCxFQUFBLFFBQUFNLElBQUE7RUFWMUNNLEtBQUE7R0FDWTtHQUNFWTtHQUNELFdBQUFsQjtHQUdWLEdBQ0dEO2FBUE4sQ0FTR3dCLFVBQ0RsQixFQUNGOzs7Ozs7RUFBK0JYLEVBQUEsS0FBQTZCO0VBQUE3QixFQUFBLE1BQUF3QjtFQUFBeEIsRUFBQSxNQUFBSztFQUFBTCxFQUFBLE1BQUFNO0VBQUFOLEVBQUEsTUFBQVk7Q0FBQTtFQUFBQSxLQUFBWixFQUFBO0NBQUE7Q0FBQSxPQVgvQlk7QUFXK0I7O0FBSW5DLFNBQUFrQix1QkFBQS9CLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBVTtDQUFBLElBQUFMO0NBQUEsSUFBQUM7Q0FBQSxJQUFBSztDQUFBLElBQUFDO0NBQUEsSUFBQUM7Q0FBQSxJQUFBYixFQUFBLE9BQUFELElBQUE7RUFBZ0MsRUFBQWUsT0FBQVIsSUFBQVMsYUFBQUosSUFBQUssTUFBQUosSUFBQUssWUFBQUosSUFBQUgsV0FBQSxHQUFBTCxTQUFBTjtFQU9tQkMsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFVO0VBQUFWLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFXO0VBQUFYLEVBQUEsS0FBQVk7RUFBQVosRUFBQSxLQUFBYTtDQUFBO0VBQUFILFlBQUFWLEVBQUE7RUFBQUssUUFBQUwsRUFBQTtFQUFBTSxLQUFBTixFQUFBO0VBQUFXLEtBQUFYLEVBQUE7RUFBQVksS0FBQVosRUFBQTtFQUFBYSxLQUFBYixFQUFBO0NBQUE7Q0FOakQsTUFBQWMsUUFBQVIsT0FBQVksWUFBQSxVQUFBWjtDQUNBLE1BQUFTLGNBQUFKLE9BQUFPLFlBQUEsS0FBQVA7Q0FDQSxNQUFBSyxPQUFBSixPQUFBTSxZQUFBLFVBQUFOO0NBQ0EsTUFBQUssYUFBQUosT0FBQUssWUFBQSxJQUFBTDtDQUFjLElBQUFNO0NBQUEsSUFBQW5CLEVBQUEsT0FBQVUsV0FBQTtFQU9DUyxLQUFBeEIsR0FBRywyWkFBMlplLFNBQVU7RUFBQ1YsRUFBQSxLQUFBVTtFQUFBVixFQUFBLEtBQUFtQjtDQUFBO0VBQUFBLEtBQUFuQixFQUFBO0NBQUE7Q0FBQSxJQUFBb0I7Q0FBQSxJQUFBcEIsRUFBQSxRQUFBYyxTQUFBZCxFQUFBLFFBQUFlLGVBQUFmLEVBQUEsUUFBQUssU0FBQUwsRUFBQSxRQUFBZ0IsUUFBQWhCLEVBQUEsUUFBQWlCLGNBQUFqQixFQUFBLFFBQUFtQixJQUFBO0VBRnRiQyxLQUFBLHdCQUFDLHFCQUFEO0dBQ1k7R0FDQyxXQUFBRDtHQUNKTDtHQUNNQztHQUNQQztHQUNNQztHQUFVLEdBQ2xCWjtFQUFLOzs7OztFQUNUTCxFQUFBLE1BQUFjO0VBQUFkLEVBQUEsTUFBQWU7RUFBQWYsRUFBQSxNQUFBSztFQUFBTCxFQUFBLE1BQUFnQjtFQUFBaEIsRUFBQSxNQUFBaUI7RUFBQWpCLEVBQUEsTUFBQW1CO0VBQUFuQixFQUFBLE1BQUFvQjtDQUFBO0VBQUFBLEtBQUFwQixFQUFBO0NBQUE7Q0FBQSxPQVJGb0I7QUFRRTs7QUFJTixTQUFBVyx5QkFBQWhDLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBZ0M7Q0FBQSxJQUFBSDtDQUFBLElBQUFuQjtDQUFBLElBQUFjO0NBQUEsSUFBQW5CO0NBQUEsSUFBQUwsRUFBQSxPQUFBRCxJQUFBO0VBQWtDLEVBQUFXLFdBQUFtQixVQUFBRyxTQUFBUixPQUFBLEdBQUFuQixTQUFBTjtFQVFqQ0MsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFnQztFQUFBaEMsRUFBQSxLQUFBNkI7RUFBQTdCLEVBQUEsS0FBQVU7RUFBQVYsRUFBQSxLQUFBd0I7RUFBQXhCLEVBQUEsS0FBQUs7Q0FBQTtFQUFBMkIsVUFBQWhDLEVBQUE7RUFBQTZCLFdBQUE3QixFQUFBO0VBQUFVLFlBQUFWLEVBQUE7RUFBQXdCLFFBQUF4QixFQUFBO0VBQUFLLFFBQUFMLEVBQUE7Q0FBQTtDQUFBLElBQUFNO0NBQUEsSUFBQU4sRUFBQSxPQUFBVSxXQUFBO0VBS2dCSixLQUFBWCxHQUNULDhWQUNBZSxTQUNGO0VBQUNWLEVBQUEsS0FBQVU7RUFBQVYsRUFBQSxLQUFBTTtDQUFBO0VBQUFBLEtBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFXO0NBQUEsSUFBQVgsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBSURPLEtBQUE7R0FDWTtHQUNBO2FBRVYseUVBQ0Usd0JBQUMsV0FBRCxDQUFVOzs7O1lBRVo7Ozs7O0VBQ0s7Ozs7O0VBQUFYLEVBQUEsS0FBQVc7Q0FBQTtFQUFBQSxLQUFBWCxFQUFBO0NBQUE7Q0FBQSxJQUFBWTtDQUFBLElBQUFaLEVBQUEsUUFBQWdDLFdBQUFoQyxFQUFBLFFBQUE2QixZQUFBN0IsRUFBQSxRQUFBd0IsU0FBQXhCLEVBQUEsUUFBQUssU0FBQUwsRUFBQSxRQUFBTSxJQUFBO0VBbEJUTSxLQUFBO0dBQ1k7R0FDRVk7R0FDRCxXQUFBbEI7R0FJRjBCO0dBQU8sR0FDWjNCO2FBUk4sQ0FVRU0sSUFTQ2tCLFFBQ0g7Ozs7OztFQUE2QjdCLEVBQUEsTUFBQWdDO0VBQUFoQyxFQUFBLE1BQUE2QjtFQUFBN0IsRUFBQSxNQUFBd0I7RUFBQXhCLEVBQUEsTUFBQUs7RUFBQUwsRUFBQSxNQUFBTTtFQUFBTixFQUFBLE1BQUFZO0NBQUE7RUFBQUEsS0FBQVosRUFBQTtDQUFBO0NBQUEsT0FwQjdCWTtBQW9CNkI7O0FBSWpDLFNBQUFxQix1QkFBQWxDLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBSztDQUFBLElBQUFMLEVBQUEsT0FBQUQsSUFBQTtFQUFnQyxLQUFBTSxTQUFBTjtFQUE0Q0MsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFLO0NBQUE7RUFBQUEsUUFBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFLLE9BQUE7RUFFeEVDLEtBQUE7R0FDWTtHQUEyQixHQUNqQ0Q7RUFBSzs7Ozs7RUFDVEwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0NBQUE7RUFBQUEsS0FBQU4sRUFBQTtDQUFBO0NBQUEsT0FIRk07QUFHRTs7QUFJTixTQUFBNEIsc0JBQUFuQyxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQTZCO0NBQUEsSUFBQW5CO0NBQUEsSUFBQWM7Q0FBQSxJQUFBbkI7Q0FBQSxJQUFBTCxFQUFBLE9BQUFELElBQUE7RUFBK0IsRUFBQVcsV0FBQW1CLFVBQUFMLE9BQUEsR0FBQW5CLFNBQUFOO0VBTzlCQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQTZCO0VBQUE3QixFQUFBLEtBQUFVO0VBQUFWLEVBQUEsS0FBQXdCO0VBQUF4QixFQUFBLEtBQUFLO0NBQUE7RUFBQXdCLFdBQUE3QixFQUFBO0VBQUFVLFlBQUFWLEVBQUE7RUFBQXdCLFFBQUF4QixFQUFBO0VBQUFLLFFBQUFMLEVBQUE7Q0FBQTtDQUFBLElBQUFNO0NBQUEsSUFBQU4sRUFBQSxPQUFBVSxXQUFBO0VBS2dCSixLQUFBWCxHQUNULDhWQUNBZSxTQUNGO0VBQUNWLEVBQUEsS0FBQVU7RUFBQVYsRUFBQSxLQUFBTTtDQUFBO0VBQUFBLEtBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFXO0NBQUEsSUFBQVgsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBR0RPLEtBQUE7R0FDWTtHQUNBO2FBRVYsc0VBQ0Usd0JBQUMsV0FBRCxDQUFVOzs7O1lBRVo7Ozs7O0VBQ0s7Ozs7O0VBQUFYLEVBQUEsS0FBQVc7Q0FBQTtFQUFBQSxLQUFBWCxFQUFBO0NBQUE7Q0FBQSxJQUFBWTtDQUFBLElBQUFaLEVBQUEsT0FBQTZCLFlBQUE3QixFQUFBLFFBQUF3QixTQUFBeEIsRUFBQSxRQUFBSyxTQUFBTCxFQUFBLFFBQUFNLElBQUE7RUFqQlRNLEtBQUE7R0FDWTtHQUNFWTtHQUNELFdBQUFsQjtHQUdWLEdBQ0dEO2FBUE4sQ0FTRU0sSUFTQ2tCLFFBQ0g7Ozs7OztFQUEwQjdCLEVBQUEsS0FBQTZCO0VBQUE3QixFQUFBLE1BQUF3QjtFQUFBeEIsRUFBQSxNQUFBSztFQUFBTCxFQUFBLE1BQUFNO0VBQUFOLEVBQUEsTUFBQVk7Q0FBQTtFQUFBQSxLQUFBWixFQUFBO0NBQUE7Q0FBQSxPQW5CMUJZO0FBbUIwQjs7QUFJOUIsU0FBQXVCLHNCQUFBcEMsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFVO0NBQUEsSUFBQUw7Q0FBQSxJQUFBTCxFQUFBLE9BQUFELElBQUE7RUFBK0IsRUFBQVcsV0FBQSxHQUFBTCxTQUFBTjtFQUdDQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQVU7RUFBQVYsRUFBQSxLQUFBSztDQUFBO0VBQUFLLFlBQUFWLEVBQUE7RUFBQUssUUFBQUwsRUFBQTtDQUFBO0NBQUEsSUFBQU07Q0FBQSxJQUFBTixFQUFBLE9BQUFVLFdBQUE7RUFJZkosS0FBQVgsR0FBRyw2QkFBNkJlLFNBQVM7RUFBQ1YsRUFBQSxLQUFBVTtFQUFBVixFQUFBLEtBQUFNO0NBQUE7RUFBQUEsS0FBQU4sRUFBQTtDQUFBO0NBQUEsSUFBQVc7Q0FBQSxJQUFBWCxFQUFBLE9BQUFLLFNBQUFMLEVBQUEsT0FBQU0sSUFBQTtFQUZ2REssS0FBQTtHQUNZO0dBQ0MsV0FBQUw7R0FBMEMsR0FDakREO0VBQUs7Ozs7O0VBQ1RMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFXO0NBQUE7RUFBQUEsS0FBQVgsRUFBQTtDQUFBO0NBQUEsT0FKRlc7QUFJRTs7QUFJTixTQUFBeUIscUJBQUFyQyxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQVU7Q0FBQSxJQUFBTDtDQUFBLElBQUFMLEVBQUEsT0FBQUQsSUFBQTtFQUE4QixFQUFBVyxXQUFBLEdBQUFMLFNBQUFOO0VBR0NDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBVTtFQUFBVixFQUFBLEtBQUFLO0NBQUE7RUFBQUssWUFBQVYsRUFBQTtFQUFBSyxRQUFBTCxFQUFBO0NBQUE7Q0FBQSxJQUFBTTtDQUFBLElBQUFOLEVBQUEsT0FBQVUsV0FBQTtFQUlkSixLQUFBWCxHQUNULCtHQUNBZSxTQUNGO0VBQUNWLEVBQUEsS0FBQVU7RUFBQVYsRUFBQSxLQUFBTTtDQUFBO0VBQUFBLEtBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFXO0NBQUEsSUFBQVgsRUFBQSxPQUFBSyxTQUFBTCxFQUFBLE9BQUFNLElBQUE7RUFMSEssS0FBQTtHQUNZO0dBQ0MsV0FBQUw7R0FHVixHQUNHRDtFQUFLOzs7OztFQUNUTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBVztDQUFBO0VBQUFBLEtBQUFYLEVBQUE7Q0FBQTtDQUFBLE9BUEZXO0FBT0U7O0FBSU4sU0FDRWIsY0FDQVMsb0JBQ0FDLHFCQUNBQyxxQkFDQWEsbUJBQ0FDLG1CQUNBRSxrQkFDQU0sMEJBQ0FFLHdCQUNBQyx1QkFDQUMsdUJBQ0FDLHNCQUNBVCxpQkFDQUMsd0JBQ0FFIiwibmFtZXMiOlsiUmVhY3QiLCJNZW51IiwiTWVudVByaW1pdGl2ZSIsImNuIiwiQ2hldnJvblJpZ2h0SWNvbiIsIkNoZWNrSWNvbiIsIkRyb3Bkb3duTWVudSIsInQwIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJwcm9wcyIsInQxIiwiRHJvcGRvd25NZW51UG9ydGFsIiwiRHJvcGRvd25NZW51VHJpZ2dlciIsIkRyb3Bkb3duTWVudUNvbnRlbnQiLCJjbGFzc05hbWUiLCJ0MiIsInQzIiwidDQiLCJhbGlnbiIsImFsaWduT2Zmc2V0Iiwic2lkZSIsInNpZGVPZmZzZXQiLCJ1bmRlZmluZWQiLCJ0NSIsInQ2IiwidDciLCJEcm9wZG93bk1lbnVHcm91cCIsIkRyb3Bkb3duTWVudUxhYmVsIiwiaW5zZXQiLCJEcm9wZG93bk1lbnVJdGVtIiwidmFyaWFudCIsIkRyb3Bkb3duTWVudVN1YiIsIkRyb3Bkb3duTWVudVN1YlRyaWdnZXIiLCJjaGlsZHJlbiIsIkRyb3Bkb3duTWVudVN1YkNvbnRlbnQiLCJEcm9wZG93bk1lbnVDaGVja2JveEl0ZW0iLCJjaGVja2VkIiwiRHJvcGRvd25NZW51UmFkaW9Hcm91cCIsIkRyb3Bkb3duTWVudVJhZGlvSXRlbSIsIkRyb3Bkb3duTWVudVNlcGFyYXRvciIsIkRyb3Bkb3duTWVudVNob3J0Y3V0Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImRyb3Bkb3duLW1lbnUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiXG5pbXBvcnQgeyBNZW51IGFzIE1lbnVQcmltaXRpdmUgfSBmcm9tIFwiQGJhc2UtdWkvcmVhY3QvbWVudVwiXG5pbXBvcnQgeyBjbiB9IGZyb20gXCJjblwiXG5pbXBvcnQgeyBDaGV2cm9uUmlnaHRJY29uLCBDaGVja0ljb24gfSBmcm9tIFwibHVjaWRlLXJlYWN0XCJcblxuZnVuY3Rpb24gRHJvcGRvd25NZW51KHsgLi4ucHJvcHMgfTogTWVudVByaW1pdGl2ZS5Sb290LlByb3BzKSB7XG4gIHJldHVybiA8TWVudVByaW1pdGl2ZS5Sb290IGRhdGEtc2xvdD1cImRyb3Bkb3duLW1lbnVcIiB7Li4ucHJvcHN9IC8+XG59XG5cbmZ1bmN0aW9uIERyb3Bkb3duTWVudVBvcnRhbCh7IC4uLnByb3BzIH06IE1lbnVQcmltaXRpdmUuUG9ydGFsLlByb3BzKSB7XG4gIHJldHVybiA8TWVudVByaW1pdGl2ZS5Qb3J0YWwgZGF0YS1zbG90PVwiZHJvcGRvd24tbWVudS1wb3J0YWxcIiB7Li4ucHJvcHN9IC8+XG59XG5cbmZ1bmN0aW9uIERyb3Bkb3duTWVudVRyaWdnZXIoeyAuLi5wcm9wcyB9OiBNZW51UHJpbWl0aXZlLlRyaWdnZXIuUHJvcHMpIHtcbiAgcmV0dXJuIDxNZW51UHJpbWl0aXZlLlRyaWdnZXIgZGF0YS1zbG90PVwiZHJvcGRvd24tbWVudS10cmlnZ2VyXCIgey4uLnByb3BzfSAvPlxufVxuXG5mdW5jdGlvbiBEcm9wZG93bk1lbnVDb250ZW50KHtcbiAgYWxpZ24gPSBcInN0YXJ0XCIsXG4gIGFsaWduT2Zmc2V0ID0gMCxcbiAgc2lkZSA9IFwiYm90dG9tXCIsXG4gIHNpZGVPZmZzZXQgPSA0LFxuICBjbGFzc05hbWUsXG4gIC4uLnByb3BzXG59OiBNZW51UHJpbWl0aXZlLlBvcHVwLlByb3BzICZcbiAgUGljazxcbiAgICBNZW51UHJpbWl0aXZlLlBvc2l0aW9uZXIuUHJvcHMsXG4gICAgXCJhbGlnblwiIHwgXCJhbGlnbk9mZnNldFwiIHwgXCJzaWRlXCIgfCBcInNpZGVPZmZzZXRcIlxuICA+KSB7XG4gIHJldHVybiAoXG4gICAgPE1lbnVQcmltaXRpdmUuUG9ydGFsPlxuICAgICAgPE1lbnVQcmltaXRpdmUuUG9zaXRpb25lclxuICAgICAgICBjbGFzc05hbWU9XCJpc29sYXRlIHotNTAgb3V0bGluZS1ub25lXCJcbiAgICAgICAgYWxpZ249e2FsaWdufVxuICAgICAgICBhbGlnbk9mZnNldD17YWxpZ25PZmZzZXR9XG4gICAgICAgIHNpZGU9e3NpZGV9XG4gICAgICAgIHNpZGVPZmZzZXQ9e3NpZGVPZmZzZXR9XG4gICAgICA+XG4gICAgICAgIDxNZW51UHJpbWl0aXZlLlBvcHVwXG4gICAgICAgICAgZGF0YS1zbG90PVwiZHJvcGRvd24tbWVudS1jb250ZW50XCJcbiAgICAgICAgICBjbGFzc05hbWU9e2NuKFwiei01MCBtYXgtaC0oLS1hdmFpbGFibGUtaGVpZ2h0KSB3LSgtLWFuY2hvci13aWR0aCkgbWluLXctMzIgb3JpZ2luLSgtLXRyYW5zZm9ybS1vcmlnaW4pIG92ZXJmbG93LXgtaGlkZGVuIG92ZXJmbG93LXktYXV0byByb3VuZGVkLWxnIGJnLXBvcG92ZXIgcC0xIHRleHQtcG9wb3Zlci1mb3JlZ3JvdW5kIHNoYWRvdy1tZCByaW5nLTEgcmluZy1mb3JlZ3JvdW5kLzEwIGR1cmF0aW9uLTEwMCBvdXRsaW5lLW5vbmUgZGF0YS1bc2lkZT1ib3R0b21dOnNsaWRlLWluLWZyb20tdG9wLTIgZGF0YS1bc2lkZT1pbmxpbmUtZW5kXTpzbGlkZS1pbi1mcm9tLWxlZnQtMiBkYXRhLVtzaWRlPWlubGluZS1zdGFydF06c2xpZGUtaW4tZnJvbS1yaWdodC0yIGRhdGEtW3NpZGU9bGVmdF06c2xpZGUtaW4tZnJvbS1yaWdodC0yIGRhdGEtW3NpZGU9cmlnaHRdOnNsaWRlLWluLWZyb20tbGVmdC0yIGRhdGEtW3NpZGU9dG9wXTpzbGlkZS1pbi1mcm9tLWJvdHRvbS0yIGRhdGEtb3BlbjphbmltYXRlLWluIGRhdGEtb3BlbjpmYWRlLWluLTAgZGF0YS1vcGVuOnpvb20taW4tOTUgZGF0YS1jbG9zZWQ6YW5pbWF0ZS1vdXQgZGF0YS1jbG9zZWQ6b3ZlcmZsb3ctaGlkZGVuIGRhdGEtY2xvc2VkOmZhZGUtb3V0LTAgZGF0YS1jbG9zZWQ6em9vbS1vdXQtOTVcIiwgY2xhc3NOYW1lICl9XG4gICAgICAgICAgey4uLnByb3BzfVxuICAgICAgICAvPlxuICAgICAgPC9NZW51UHJpbWl0aXZlLlBvc2l0aW9uZXI+XG4gICAgPC9NZW51UHJpbWl0aXZlLlBvcnRhbD5cbiAgKVxufVxuXG5mdW5jdGlvbiBEcm9wZG93bk1lbnVHcm91cCh7IC4uLnByb3BzIH06IE1lbnVQcmltaXRpdmUuR3JvdXAuUHJvcHMpIHtcbiAgcmV0dXJuIDxNZW51UHJpbWl0aXZlLkdyb3VwIGRhdGEtc2xvdD1cImRyb3Bkb3duLW1lbnUtZ3JvdXBcIiB7Li4ucHJvcHN9IC8+XG59XG5cbmZ1bmN0aW9uIERyb3Bkb3duTWVudUxhYmVsKHtcbiAgY2xhc3NOYW1lLFxuICBpbnNldCxcbiAgLi4ucHJvcHNcbn06IE1lbnVQcmltaXRpdmUuR3JvdXBMYWJlbC5Qcm9wcyAmIHtcbiAgaW5zZXQ/OiBib29sZWFuXG59KSB7XG4gIHJldHVybiAoXG4gICAgPE1lbnVQcmltaXRpdmUuR3JvdXBMYWJlbFxuICAgICAgZGF0YS1zbG90PVwiZHJvcGRvd24tbWVudS1sYWJlbFwiXG4gICAgICBkYXRhLWluc2V0PXtpbnNldH1cbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwicHgtMS41IHB5LTEgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LW11dGVkLWZvcmVncm91bmQgZGF0YS1pbnNldDpwbC03XCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIERyb3Bkb3duTWVudUl0ZW0oe1xuICBjbGFzc05hbWUsXG4gIGluc2V0LFxuICB2YXJpYW50ID0gXCJkZWZhdWx0XCIsXG4gIC4uLnByb3BzXG59OiBNZW51UHJpbWl0aXZlLkl0ZW0uUHJvcHMgJiB7XG4gIGluc2V0PzogYm9vbGVhblxuICB2YXJpYW50PzogXCJkZWZhdWx0XCIgfCBcImRlc3RydWN0aXZlXCJcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8TWVudVByaW1pdGl2ZS5JdGVtXG4gICAgICBkYXRhLXNsb3Q9XCJkcm9wZG93bi1tZW51LWl0ZW1cIlxuICAgICAgZGF0YS1pbnNldD17aW5zZXR9XG4gICAgICBkYXRhLXZhcmlhbnQ9e3ZhcmlhbnR9XG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImdyb3VwL2Ryb3Bkb3duLW1lbnUtaXRlbSByZWxhdGl2ZSBmbGV4IGN1cnNvci1kZWZhdWx0IGl0ZW1zLWNlbnRlciBnYXAtMS41IHJvdW5kZWQtbWQgcHgtMS41IHB5LTEgdGV4dC1zbSBvdXRsaW5lLWhpZGRlbiBzZWxlY3Qtbm9uZSBmb2N1czpiZy1hY2NlbnQgZm9jdXM6dGV4dC1hY2NlbnQtZm9yZWdyb3VuZCBub3QtZGF0YS1bdmFyaWFudD1kZXN0cnVjdGl2ZV06Zm9jdXM6Kio6dGV4dC1hY2NlbnQtZm9yZWdyb3VuZCBkYXRhLWluc2V0OnBsLTcgZGF0YS1bdmFyaWFudD1kZXN0cnVjdGl2ZV06dGV4dC1kZXN0cnVjdGl2ZSBkYXRhLVt2YXJpYW50PWRlc3RydWN0aXZlXTpmb2N1czpiZy1kZXN0cnVjdGl2ZS8xMCBkYXRhLVt2YXJpYW50PWRlc3RydWN0aXZlXTpmb2N1czp0ZXh0LWRlc3RydWN0aXZlIGRhcms6ZGF0YS1bdmFyaWFudD1kZXN0cnVjdGl2ZV06Zm9jdXM6YmctZGVzdHJ1Y3RpdmUvMjAgZGF0YS1kaXNhYmxlZDpwb2ludGVyLWV2ZW50cy1ub25lIGRhdGEtZGlzYWJsZWQ6b3BhY2l0eS01MCBbJl9zdmddOnBvaW50ZXItZXZlbnRzLW5vbmUgWyZfc3ZnXTpzaHJpbmstMCBbJl9zdmc6bm90KFtjbGFzcyo9J3NpemUtJ10pXTpzaXplLTQgZGF0YS1bdmFyaWFudD1kZXN0cnVjdGl2ZV06Kjpbc3ZnXTp0ZXh0LWRlc3RydWN0aXZlXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIERyb3Bkb3duTWVudVN1Yih7IC4uLnByb3BzIH06IE1lbnVQcmltaXRpdmUuU3VibWVudVJvb3QuUHJvcHMpIHtcbiAgcmV0dXJuIDxNZW51UHJpbWl0aXZlLlN1Ym1lbnVSb290IGRhdGEtc2xvdD1cImRyb3Bkb3duLW1lbnUtc3ViXCIgey4uLnByb3BzfSAvPlxufVxuXG5mdW5jdGlvbiBEcm9wZG93bk1lbnVTdWJUcmlnZ2VyKHtcbiAgY2xhc3NOYW1lLFxuICBpbnNldCxcbiAgY2hpbGRyZW4sXG4gIC4uLnByb3BzXG59OiBNZW51UHJpbWl0aXZlLlN1Ym1lbnVUcmlnZ2VyLlByb3BzICYge1xuICBpbnNldD86IGJvb2xlYW5cbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8TWVudVByaW1pdGl2ZS5TdWJtZW51VHJpZ2dlclxuICAgICAgZGF0YS1zbG90PVwiZHJvcGRvd24tbWVudS1zdWItdHJpZ2dlclwiXG4gICAgICBkYXRhLWluc2V0PXtpbnNldH1cbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiZmxleCBjdXJzb3ItZGVmYXVsdCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLW1kIHB4LTEuNSBweS0xIHRleHQtc20gb3V0bGluZS1oaWRkZW4gc2VsZWN0LW5vbmUgZm9jdXM6YmctYWNjZW50IGZvY3VzOnRleHQtYWNjZW50LWZvcmVncm91bmQgbm90LWRhdGEtW3ZhcmlhbnQ9ZGVzdHJ1Y3RpdmVdOmZvY3VzOioqOnRleHQtYWNjZW50LWZvcmVncm91bmQgZGF0YS1pbnNldDpwbC03IGRhdGEtcG9wdXAtb3BlbjpiZy1hY2NlbnQgZGF0YS1wb3B1cC1vcGVuOnRleHQtYWNjZW50LWZvcmVncm91bmQgZGF0YS1vcGVuOmJnLWFjY2VudCBkYXRhLW9wZW46dGV4dC1hY2NlbnQtZm9yZWdyb3VuZCBbJl9zdmddOnBvaW50ZXItZXZlbnRzLW5vbmUgWyZfc3ZnXTpzaHJpbmstMCBbJl9zdmc6bm90KFtjbGFzcyo9J3NpemUtJ10pXTpzaXplLTRcIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDxDaGV2cm9uUmlnaHRJY29uIGNsYXNzTmFtZT1cIm1sLWF1dG9cIiAvPlxuICAgIDwvTWVudVByaW1pdGl2ZS5TdWJtZW51VHJpZ2dlcj5cbiAgKVxufVxuXG5mdW5jdGlvbiBEcm9wZG93bk1lbnVTdWJDb250ZW50KHtcbiAgYWxpZ24gPSBcInN0YXJ0XCIsXG4gIGFsaWduT2Zmc2V0ID0gLTMsXG4gIHNpZGUgPSBcInJpZ2h0XCIsXG4gIHNpZGVPZmZzZXQgPSAwLFxuICBjbGFzc05hbWUsXG4gIC4uLnByb3BzXG59OiBSZWFjdC5Db21wb25lbnRQcm9wczx0eXBlb2YgRHJvcGRvd25NZW51Q29udGVudD4pIHtcbiAgcmV0dXJuIChcbiAgICA8RHJvcGRvd25NZW51Q29udGVudFxuICAgICAgZGF0YS1zbG90PVwiZHJvcGRvd24tbWVudS1zdWItY29udGVudFwiXG4gICAgICBjbGFzc05hbWU9e2NuKFwidy1hdXRvIG1pbi13LVs5NnB4XSByb3VuZGVkLWxnIGJnLXBvcG92ZXIgcC0xIHRleHQtcG9wb3Zlci1mb3JlZ3JvdW5kIHNoYWRvdy1sZyByaW5nLTEgcmluZy1mb3JlZ3JvdW5kLzEwIGR1cmF0aW9uLTEwMCBkYXRhLVtzaWRlPWJvdHRvbV06c2xpZGUtaW4tZnJvbS10b3AtMiBkYXRhLVtzaWRlPWxlZnRdOnNsaWRlLWluLWZyb20tcmlnaHQtMiBkYXRhLVtzaWRlPXJpZ2h0XTpzbGlkZS1pbi1mcm9tLWxlZnQtMiBkYXRhLVtzaWRlPXRvcF06c2xpZGUtaW4tZnJvbS1ib3R0b20tMiBkYXRhLW9wZW46YW5pbWF0ZS1pbiBkYXRhLW9wZW46ZmFkZS1pbi0wIGRhdGEtb3Blbjp6b29tLWluLTk1IGRhdGEtY2xvc2VkOmFuaW1hdGUtb3V0IGRhdGEtY2xvc2VkOmZhZGUtb3V0LTAgZGF0YS1jbG9zZWQ6em9vbS1vdXQtOTVcIiwgY2xhc3NOYW1lICl9XG4gICAgICBhbGlnbj17YWxpZ259XG4gICAgICBhbGlnbk9mZnNldD17YWxpZ25PZmZzZXR9XG4gICAgICBzaWRlPXtzaWRlfVxuICAgICAgc2lkZU9mZnNldD17c2lkZU9mZnNldH1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIERyb3Bkb3duTWVudUNoZWNrYm94SXRlbSh7XG4gIGNsYXNzTmFtZSxcbiAgY2hpbGRyZW4sXG4gIGNoZWNrZWQsXG4gIGluc2V0LFxuICAuLi5wcm9wc1xufTogTWVudVByaW1pdGl2ZS5DaGVja2JveEl0ZW0uUHJvcHMgJiB7XG4gIGluc2V0PzogYm9vbGVhblxufSkge1xuICByZXR1cm4gKFxuICAgIDxNZW51UHJpbWl0aXZlLkNoZWNrYm94SXRlbVxuICAgICAgZGF0YS1zbG90PVwiZHJvcGRvd24tbWVudS1jaGVja2JveC1pdGVtXCJcbiAgICAgIGRhdGEtaW5zZXQ9e2luc2V0fVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJyZWxhdGl2ZSBmbGV4IGN1cnNvci1kZWZhdWx0IGl0ZW1zLWNlbnRlciBnYXAtMS41IHJvdW5kZWQtbWQgcHktMSBwci04IHBsLTEuNSB0ZXh0LXNtIG91dGxpbmUtaGlkZGVuIHNlbGVjdC1ub25lIGZvY3VzOmJnLWFjY2VudCBmb2N1czp0ZXh0LWFjY2VudC1mb3JlZ3JvdW5kIGZvY3VzOioqOnRleHQtYWNjZW50LWZvcmVncm91bmQgZGF0YS1pbnNldDpwbC03IGRhdGEtZGlzYWJsZWQ6cG9pbnRlci1ldmVudHMtbm9uZSBkYXRhLWRpc2FibGVkOm9wYWNpdHktNTAgWyZfc3ZnXTpwb2ludGVyLWV2ZW50cy1ub25lIFsmX3N2Z106c2hyaW5rLTAgWyZfc3ZnOm5vdChbY2xhc3MqPSdzaXplLSddKV06c2l6ZS00XCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIGNoZWNrZWQ9e2NoZWNrZWR9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAgPHNwYW5cbiAgICAgICAgY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZSBhYnNvbHV0ZSByaWdodC0yIGZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyXCJcbiAgICAgICAgZGF0YS1zbG90PVwiZHJvcGRvd24tbWVudS1jaGVja2JveC1pdGVtLWluZGljYXRvclwiXG4gICAgICA+XG4gICAgICAgIDxNZW51UHJpbWl0aXZlLkNoZWNrYm94SXRlbUluZGljYXRvcj5cbiAgICAgICAgICA8Q2hlY2tJY29uXG4gICAgICAgICAgLz5cbiAgICAgICAgPC9NZW51UHJpbWl0aXZlLkNoZWNrYm94SXRlbUluZGljYXRvcj5cbiAgICAgIDwvc3Bhbj5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L01lbnVQcmltaXRpdmUuQ2hlY2tib3hJdGVtPlxuICApXG59XG5cbmZ1bmN0aW9uIERyb3Bkb3duTWVudVJhZGlvR3JvdXAoeyAuLi5wcm9wcyB9OiBNZW51UHJpbWl0aXZlLlJhZGlvR3JvdXAuUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8TWVudVByaW1pdGl2ZS5SYWRpb0dyb3VwXG4gICAgICBkYXRhLXNsb3Q9XCJkcm9wZG93bi1tZW51LXJhZGlvLWdyb3VwXCJcbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIERyb3Bkb3duTWVudVJhZGlvSXRlbSh7XG4gIGNsYXNzTmFtZSxcbiAgY2hpbGRyZW4sXG4gIGluc2V0LFxuICAuLi5wcm9wc1xufTogTWVudVByaW1pdGl2ZS5SYWRpb0l0ZW0uUHJvcHMgJiB7XG4gIGluc2V0PzogYm9vbGVhblxufSkge1xuICByZXR1cm4gKFxuICAgIDxNZW51UHJpbWl0aXZlLlJhZGlvSXRlbVxuICAgICAgZGF0YS1zbG90PVwiZHJvcGRvd24tbWVudS1yYWRpby1pdGVtXCJcbiAgICAgIGRhdGEtaW5zZXQ9e2luc2V0fVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJyZWxhdGl2ZSBmbGV4IGN1cnNvci1kZWZhdWx0IGl0ZW1zLWNlbnRlciBnYXAtMS41IHJvdW5kZWQtbWQgcHktMSBwci04IHBsLTEuNSB0ZXh0LXNtIG91dGxpbmUtaGlkZGVuIHNlbGVjdC1ub25lIGZvY3VzOmJnLWFjY2VudCBmb2N1czp0ZXh0LWFjY2VudC1mb3JlZ3JvdW5kIGZvY3VzOioqOnRleHQtYWNjZW50LWZvcmVncm91bmQgZGF0YS1pbnNldDpwbC03IGRhdGEtZGlzYWJsZWQ6cG9pbnRlci1ldmVudHMtbm9uZSBkYXRhLWRpc2FibGVkOm9wYWNpdHktNTAgWyZfc3ZnXTpwb2ludGVyLWV2ZW50cy1ub25lIFsmX3N2Z106c2hyaW5rLTAgWyZfc3ZnOm5vdChbY2xhc3MqPSdzaXplLSddKV06c2l6ZS00XCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8c3BhblxuICAgICAgICBjbGFzc05hbWU9XCJwb2ludGVyLWV2ZW50cy1ub25lIGFic29sdXRlIHJpZ2h0LTIgZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIlxuICAgICAgICBkYXRhLXNsb3Q9XCJkcm9wZG93bi1tZW51LXJhZGlvLWl0ZW0taW5kaWNhdG9yXCJcbiAgICAgID5cbiAgICAgICAgPE1lbnVQcmltaXRpdmUuUmFkaW9JdGVtSW5kaWNhdG9yPlxuICAgICAgICAgIDxDaGVja0ljb25cbiAgICAgICAgICAvPlxuICAgICAgICA8L01lbnVQcmltaXRpdmUuUmFkaW9JdGVtSW5kaWNhdG9yPlxuICAgICAgPC9zcGFuPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvTWVudVByaW1pdGl2ZS5SYWRpb0l0ZW0+XG4gIClcbn1cblxuZnVuY3Rpb24gRHJvcGRvd25NZW51U2VwYXJhdG9yKHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogTWVudVByaW1pdGl2ZS5TZXBhcmF0b3IuUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8TWVudVByaW1pdGl2ZS5TZXBhcmF0b3JcbiAgICAgIGRhdGEtc2xvdD1cImRyb3Bkb3duLW1lbnUtc2VwYXJhdG9yXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXCItbXgtMSBteS0xIGgtcHggYmctYm9yZGVyXCIsIGNsYXNzTmFtZSl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBEcm9wZG93bk1lbnVTaG9ydGN1dCh7XG4gIGNsYXNzTmFtZSxcbiAgLi4ucHJvcHNcbn06IFJlYWN0LkNvbXBvbmVudFByb3BzPFwic3BhblwiPikge1xuICByZXR1cm4gKFxuICAgIDxzcGFuXG4gICAgICBkYXRhLXNsb3Q9XCJkcm9wZG93bi1tZW51LXNob3J0Y3V0XCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwibWwtYXV0byB0ZXh0LXhzIHRyYWNraW5nLXdpZGVzdCB0ZXh0LW11dGVkLWZvcmVncm91bmQgZ3JvdXAtZm9jdXMvZHJvcGRvd24tbWVudS1pdGVtOnRleHQtYWNjZW50LWZvcmVncm91bmRcIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZXhwb3J0IHtcbiAgRHJvcGRvd25NZW51LFxuICBEcm9wZG93bk1lbnVQb3J0YWwsXG4gIERyb3Bkb3duTWVudVRyaWdnZXIsXG4gIERyb3Bkb3duTWVudUNvbnRlbnQsXG4gIERyb3Bkb3duTWVudUdyb3VwLFxuICBEcm9wZG93bk1lbnVMYWJlbCxcbiAgRHJvcGRvd25NZW51SXRlbSxcbiAgRHJvcGRvd25NZW51Q2hlY2tib3hJdGVtLFxuICBEcm9wZG93bk1lbnVSYWRpb0dyb3VwLFxuICBEcm9wZG93bk1lbnVSYWRpb0l0ZW0sXG4gIERyb3Bkb3duTWVudVNlcGFyYXRvcixcbiAgRHJvcGRvd25NZW51U2hvcnRjdXQsXG4gIERyb3Bkb3duTWVudVN1YixcbiAgRHJvcGRvd25NZW51U3ViVHJpZ2dlcixcbiAgRHJvcGRvd25NZW51U3ViQ29udGVudCxcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL2NvbXBvbmVudHMvdWkvZHJvcGRvd24tbWVudS50c3gifQ==