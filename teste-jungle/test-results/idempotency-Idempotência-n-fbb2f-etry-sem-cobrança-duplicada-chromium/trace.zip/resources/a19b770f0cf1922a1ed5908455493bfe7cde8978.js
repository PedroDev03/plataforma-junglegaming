import { authHandlers } from "/src/mocks/handlers/auth.ts";
import { cartHandlers } from "/src/mocks/handlers/cart.ts";
import { nftHandlers } from "/src/mocks/handlers/nfts.ts";
import { orderHandlers } from "/src/mocks/handlers/orders.ts";
import { profileHandlers } from "/src/mocks/handlers/profile.ts";
import { socketHandlers } from "/src/mocks/handlers/socket.ts";
export const handlers = [
	...authHandlers,
	...profileHandlers,
	...nftHandlers,
	...cartHandlers,
	...orderHandlers,
	...socketHandlers
];

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxvQkFBb0I7QUFDN0IsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxxQkFBcUI7QUFDOUIsU0FBUyx1QkFBdUI7QUFDaEMsU0FBUyxzQkFBc0I7QUFFL0IsT0FBTyxNQUFNLFdBQVc7Q0FDdEIsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0NBQ0gsR0FBRztDQUNILEdBQUc7Q0FDSCxHQUFHO0FBQ0wiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiaW5kZXgudHMiXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYXV0aEhhbmRsZXJzIH0gZnJvbSAnLi9hdXRoJ1xuaW1wb3J0IHsgY2FydEhhbmRsZXJzIH0gZnJvbSAnLi9jYXJ0J1xuaW1wb3J0IHsgbmZ0SGFuZGxlcnMgfSBmcm9tICcuL25mdHMnXG5pbXBvcnQgeyBvcmRlckhhbmRsZXJzIH0gZnJvbSAnLi9vcmRlcnMnXG5pbXBvcnQgeyBwcm9maWxlSGFuZGxlcnMgfSBmcm9tICcuL3Byb2ZpbGUnXG5pbXBvcnQgeyBzb2NrZXRIYW5kbGVycyB9IGZyb20gJy4vc29ja2V0J1xuXG5leHBvcnQgY29uc3QgaGFuZGxlcnMgPSBbXG4gIC4uLmF1dGhIYW5kbGVycyxcbiAgLi4ucHJvZmlsZUhhbmRsZXJzLFxuICAuLi5uZnRIYW5kbGVycyxcbiAgLi4uY2FydEhhbmRsZXJzLFxuICAuLi5vcmRlckhhbmRsZXJzLFxuICAuLi5zb2NrZXRIYW5kbGVycyxcbl1cbiJdfQ==