const StrictMode = __vite__cjsImport0_react["StrictMode"];const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=e9f94b2e";
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=e9f94b2e";
import { QueryClientProvider } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=e9f94b2e";
import { RouterProvider } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { queryClient } from "/src/lib/query-client.ts";
import { router } from "/src/router.tsx";
import "/src/index.css";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/main.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
async function enableMocking() {
	const { worker } = await import("/src/mocks/browser.ts");
	await worker.start();
}
enableMocking().then(() => {
	createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(StrictMode, { children: /* @__PURE__ */ _jsxDEV(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ _jsxDEV(RouterProvider, { router }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 55
	}, this));
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUEsU0FBU0Esa0JBQWtCO0FBQzNCLFNBQVNDLGtCQUFrQjtBQUMzQixTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxjQUFjO0FBQ3ZCLE9BQU87OztBQUVQLGVBQWVDLGdCQUFnQjtDQUM3QixNQUFNLEVBQUVDLFdBQVcsTUFBTSxPQUFPO0NBQ2hDLE1BQU1BLE9BQU9DLE1BQU07QUFDckI7QUFFQUYsY0FBYyxDQUFDLENBQUNHLFdBQVc7Q0FDekJSLFdBQVdTLFNBQVNDLGVBQWUsTUFBTSxDQUFFLENBQUMsQ0FBQ0MsT0FDM0Msd0JBQUMsWUFBRCxZQUNFLHdCQUFDLHFCQUFEO0VBQXFCLFFBQVFSO1lBQzNCLHdCQUFDLGdCQUFELEVBQXdCQyxPQUFPOzs7OztDQUNaOzs7O1VBQ1g7Ozs7U0FDZDtBQUNGLENBQUMiLCJuYW1lcyI6WyJTdHJpY3RNb2RlIiwiY3JlYXRlUm9vdCIsIlF1ZXJ5Q2xpZW50UHJvdmlkZXIiLCJSb3V0ZXJQcm92aWRlciIsInF1ZXJ5Q2xpZW50Iiwicm91dGVyIiwiZW5hYmxlTW9ja2luZyIsIndvcmtlciIsInN0YXJ0IiwidGhlbiIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJyZW5kZXIiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibWFpbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU3RyaWN0TW9kZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnXG5pbXBvcnQgeyBRdWVyeUNsaWVudFByb3ZpZGVyIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5J1xuaW1wb3J0IHsgUm91dGVyUHJvdmlkZXIgfSBmcm9tICdAdGFuc3RhY2svcmVhY3Qtcm91dGVyJ1xuaW1wb3J0IHsgcXVlcnlDbGllbnQgfSBmcm9tICdAL2xpYi9xdWVyeS1jbGllbnQnXG5pbXBvcnQgeyByb3V0ZXIgfSBmcm9tICcuL3JvdXRlcidcbmltcG9ydCAnLi9pbmRleC5jc3MnXG5cbmFzeW5jIGZ1bmN0aW9uIGVuYWJsZU1vY2tpbmcoKSB7XG4gIGNvbnN0IHsgd29ya2VyIH0gPSBhd2FpdCBpbXBvcnQoJy4vbW9ja3MvYnJvd3NlcicpXG4gIGF3YWl0IHdvcmtlci5zdGFydCgpXG59XG5cbmVuYWJsZU1vY2tpbmcoKS50aGVuKCgpID0+IHtcbiAgY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9vdCcpISkucmVuZGVyKFxuICAgIDxTdHJpY3RNb2RlPlxuICAgICAgPFF1ZXJ5Q2xpZW50UHJvdmlkZXIgY2xpZW50PXtxdWVyeUNsaWVudH0+XG4gICAgICAgIDxSb3V0ZXJQcm92aWRlciByb3V0ZXI9e3JvdXRlcn0gLz5cbiAgICAgIDwvUXVlcnlDbGllbnRQcm92aWRlcj5cbiAgICA8L1N0cmljdE1vZGU+LFxuICApXG59KVxuXHJcblxyXG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9tYWluLnRzeCJ9