import { A as BatchInterceptor, B as createServerErrorResponse, C as getRawSetCookie, D as isStringEqual, F as FetchRequest, G as createLogger, H as isResponseError, I as FetchResponse, J as Emitter, K as createRequestId, L as InterceptorError, M as decodeBuffer, N as encodeBuffer, P as toArrayBuffer, R as RequestController, S as devUtils, U as isResponseLike, V as isObject, W as Interceptor, X as invariant, Y as TypedEvent, Z as isNodeProcess, a as executeHandlers, b as InternalError, d as kAutoConnect, f as kConnect, g as patchesRegistry, h as hasConfigurableGlobal, i as HttpResponse, k as toPublicUrl, l as getSiblingHandlers, m as WebSocketInterceptor, n as isPassthroughResponse, q as formatRequest, t as isCommonAssetRequest, u as isSiblingHandler, v as isObject$1, x as cookieStore, y as RequestHandler, z as copyRawHeaders } from "/node_modules/.vite/deps/is-common-asset-request-Bl1OJH5F.js?v=e9f94b2e";
// node_modules/until-async/lib/index.js
/**
* Gracefully handles a callback that returns a promise.
*
* @example
* await until(() => Promise.resolve(123))
* // [null, 123]
*
* await until(() => Promise.reject(new Error('Oops!')))
* // [new Error('Oops!'), null]
*/
async function until$1(callback) {
	try {
		return [null, await callback().catch((error) => {
			throw error;
		})];
	} catch (error) {
		return [error, null];
	}
}
// node_modules/msw/lib/_chunks/interceptor-source.js
var NetworkFrameEvent = class extends TypedEvent {
	frame;
	constructor(type, frame) {
		super(...[type, {}]);
		this.frame = frame;
	}
};
var NetworkSource = class {
	emitter;
	constructor() {
		this.emitter = new Emitter();
	}
	async queue(frame) {
		await this.emitter.emitAsPromise(new NetworkFrameEvent("frame", frame));
	}
	on(type, listener, options) {
		this.emitter.on(type, listener, options);
	}
	disable() {
		this.emitter.removeAllListeners();
	}
};
function addHandlerToGroup(groups, kind, handler) {
	(groups[kind] ||= []).push(handler);
}
function prependHandlersToGroup(groups, kind, overridesForKind) {
	const existingForKind = groups[kind];
	groups[kind] = existingForKind ? [...overridesForKind, ...existingForKind.filter((existingHandler) => {
		return !overridesForKind.includes(existingHandler);
	})] : overridesForKind;
}
function groupHandlersByKind(handlers) {
	const groups = {};
	const visitedHandlers = /* @__PURE__ */ new Set();
	const visit = (handler) => {
		if (visitedHandlers.has(handler)) return;
		visitedHandlers.add(handler);
		addHandlerToGroup(groups, handler.kind, handler);
		for (const sibling of getSiblingHandlers(handler)) visit(sibling);
	};
	for (const handler of handlers) visit(handler);
	return groups;
}
var HandlersController = class {
	getInitialState(initialHandlers) {
		invariant(this.#validateHandlers(initialHandlers), devUtils.formatMessage("Failed to apply given request handlers: invalid input. Did you forget to spread the request handlers Array?"));
		const normalizedInitialHandlers = groupHandlersByKind(initialHandlers);
		return {
			initialHandlers: normalizedInitialHandlers,
			handlers: { ...normalizedInitialHandlers }
		};
	}
	currentHandlers() {
		return Object.values(this.getState().handlers).flat().filter((handler) => handler != null);
	}
	/**
	* Return the list of explicitly registered handlers.
	* Unlike `currentHandlers()`, this excludes sibling handlers,
	* which are an implementation detail (e.g. the WebSocket upgrade
	* handler or the GraphQL subscription transport).
	*/
	listHandlers() {
		return this.currentHandlers().filter((handler) => {
			return !isSiblingHandler(handler);
		});
	}
	/**
	* Return the list of handlers of the given kind.
	*/
	getHandlersByKind(kind) {
		return this.getState().handlers[kind] || [];
	}
	use(nextHandlers) {
		invariant(this.#validateHandlers(nextHandlers), devUtils.formatMessage("[MSW] Failed to call \"use()\" with the given request handlers: invalid input. Did you forget to spread the array of request handlers?"));
		if (nextHandlers.length === 0) return;
		const { handlers } = this.getState();
		const overrides = groupHandlersByKind(nextHandlers);
		if (overrides.request) prependHandlersToGroup(handlers, "request", overrides.request);
		if (overrides.websocket) prependHandlersToGroup(handlers, "websocket", overrides.websocket);
		this.setState({ handlers });
	}
	reset(nextHandlers) {
		invariant(nextHandlers.length > 0 ? this.#validateHandlers(nextHandlers) : true, devUtils.formatMessage("Failed to replace initial handlers during reset: invalid handlers. Did you forget to spread the handlers array?"));
		const { initialHandlers } = this.getState();
		const nextInitialHandlers = nextHandlers.length > 0 ? groupHandlersByKind(nextHandlers) : initialHandlers;
		const currentHandlers = new Set(this.currentHandlers());
		const nextHandlersSet = new Set(Object.values(nextInitialHandlers).flat().filter(Boolean));
		for (const handler of currentHandlers.intersection(nextHandlersSet)) handler.reset();
		for (const handler of currentHandlers.difference(nextHandlersSet)) try {
			const disposal = handler.dispose();
			if (disposal instanceof Promise) disposal.catch((error) => {
				this.#printDisposalError(handler, error);
			});
		} catch (error) {
			this.#printDisposalError(handler, error);
		}
		if (nextHandlers.length === 0) {
			this.setState({ handlers: { ...initialHandlers } });
			return;
		}
		this.setState({
			initialHandlers: nextInitialHandlers,
			handlers: { ...nextInitialHandlers }
		});
	}
	restore() {
		for (const handler of this.currentHandlers()) handler.restore();
	}
	dispose() {
		const pendingDisposals = [];
		for (const handler of this.currentHandlers()) {
			const disposal = handler.dispose();
			if (disposal instanceof Promise) pendingDisposals.push(disposal);
		}
		if (pendingDisposals.length > 0) return Promise.all(pendingDisposals).then(() => {});
	}
	#validateHandlers(handlers) {
		return handlers.every((handler) => !Array.isArray(handler));
	}
	#printDisposalError(handler, error) {
		devUtils.error("Failed to dispose of \"%s\" handler removed during reset. Please see the original error below.\n%s", handler.kind, error);
	}
};
var InMemoryHandlersController = class extends HandlersController {
	#handlers;
	#initialHandlers;
	constructor(initialHandlers) {
		super();
		const initialState = this.getInitialState(initialHandlers);
		this.#initialHandlers = initialState.initialHandlers;
		this.#handlers = initialState.handlers;
	}
	getState() {
		return {
			initialHandlers: this.#initialHandlers,
			handlers: this.#handlers
		};
	}
	setState(nextState) {
		if (nextState.initialHandlers) this.#initialHandlers = nextState.initialHandlers;
		if (nextState.handlers) this.#handlers = nextState.handlers;
	}
};
/**
* Creates an immutable copy of the given array.
*/
function toReadonlyArray(source) {
	const clone = [...source];
	Object.freeze(clone);
	return clone;
}
var Disposable = class {
	subscriptions = [];
	dispose() {
		let subscription;
		const errors = [];
		while (subscription = this.subscriptions.shift()) try {
			subscription();
		} catch (error) {
			if (error instanceof Error) errors.push(error);
		}
		if (errors.length > 0) console.error(new AggregateError(errors, devUtils.formatMessage("Failed to dispose of some side effects. This is likely an issue with MSW, please report it on GitHub: https://github.com/mswjs/msw/issues")));
	}
};
function colorlessPromiseAll(values) {
	const promises = [];
	for (const value of values) if (value instanceof Promise) promises.push(value);
	if (promises.length > 0) return Promise.all(promises).then(() => {});
}
/**
* Define a network instance with the given configuration.
* @example
* import { InterceptorSource } from 'msw/experimental'
* import { handlers } from './handlers'
*
* const network = defineNetwork({
*   sources: [new InterceptorSource({ interceptors })],
*   handlers,
* })
* await network.enable()
*/
function defineNetwork(options) {
	let readyState = 0;
	const events = new Emitter();
	const disposable = new Disposable();
	const deriveHandlersController = (handlers) => {
		return handlers instanceof HandlersController ? handlers : new InMemoryHandlersController(handlers || []);
	};
	let resolvedOptions = { ...options };
	/**
	* @note Create the handlers controller immediately because
	* certain setup APIs, like `setupServer`, don't await `.enable` (`.listen`).
	*/
	let handlersController = deriveHandlersController(resolvedOptions.handlers);
	return {
		get readyState() {
			return readyState;
		},
		events,
		configure(options) {
			invariant(readyState === 0, "Failed to call \"configure()\" on the network: cannot configure an already enabled network.");
			if (options.handlers && !Object.is(options.handlers, resolvedOptions.handlers)) handlersController = deriveHandlersController(options.handlers);
			resolvedOptions = {
				...resolvedOptions,
				...options
			};
		},
		enable() {
			invariant(readyState === 0, "Failed to call \"enable\" on the network: already enabled");
			readyState = 1;
			/**
			* @note Use a session object scoped to the current "enable()"
			* to prevent "frame.events" listeners from surviving across enable/disable cycles.
			* @see The note about `AbortController` below.
			*/
			const session = { active: true };
			disposable["subscriptions"].push(() => {
				session.active = false;
			});
			return colorlessPromiseAll(resolvedOptions.sources.map((source) => {
				/**
				* @note Preemptively disable the network source before enabling.
				* This intentionally calls only the prototype method that clears the
				* event listeners and nothing else. This prevents the "frame" listeners
				* from accumulating across enable/disable in case the source is a singleton.
				*/
				NetworkSource.prototype.disable.call(source);
				source.on("frame", async ({ frame }) => {
					frame.events.on("*", (event) => {
						/**
						* @note Prevent event forwarding manually and not via an AbortController
						* because certain runtimes, like Cloudflare, throw when referencing an
						* AbortController created in a different context. Bear in mind that the frame
						* events run in the patched request client context while the AbortController
						* is created outside, in the "defineNetwork" closure, which is a test context.
						*/
						if (!session.active) return;
						events.emit(event);
					});
					const handlers = frame.getHandlers(handlersController);
					await frame.resolve(handlers, resolvedOptions.onUnhandledFrame || "warn", resolvedOptions.context);
				});
				return source.enable(resolvedOptions.context);
			}));
		},
		disable() {
			invariant(readyState === 1, "Failed to call \"disable\" on the network: already disabled");
			readyState = 0;
			const handlersDisposal = handlersController.dispose();
			disposable.dispose();
			/**
			* @note Tear down the sources synchronously, never behind the
			* handlers disposal. `disable()` is not always awaited (e.g.
			* `server.close()` is synchronous), and a deferred teardown would
			* race any `enable()` that follows, disabling the sources that the
			* new session has just enabled.
			*/
			const sourcesDisposal = colorlessPromiseAll(resolvedOptions.sources.map((source) => source.disable()));
			/**
			* @note Await both disposals so neither rejection goes unobserved.
			* Chaining them would leave the source disposal floating whenever
			* the handlers disposal rejects.
			*/
			return handlersDisposal instanceof Promise ? Promise.all([handlersDisposal, sourcesDisposal]).then(() => {}) : sourcesDisposal;
		},
		use(...handlers) {
			handlersController.use(handlers);
		},
		resetHandlers(...handlers) {
			handlersController.reset(handlers);
		},
		restoreHandlers() {
			handlersController.restore();
		},
		listHandlers() {
			return toReadonlyArray(handlersController.listHandlers());
		}
	};
}
/**
* The base for the network frames. Extend this abstract class
* to implement custom network frames.
*/
var NetworkFrame = class {
	protocol;
	data;
	events;
	constructor(protocol, data) {
		this.protocol = protocol;
		this.data = data;
		this.events = new Emitter();
	}
};
async function storeResponseCookies(request, response) {
	if (cookieStore === null) return;
	for (const responseCookie of getRawSetCookie(response)) await cookieStore.setCookie(responseCookie, request.url);
}
function shouldBypassRequest(request) {
	return !!request.headers.get("accept")?.includes("msw/passthrough");
}
/**
* Remove the internal passthrough instruction from the request's `Accept` header.
*/
function deleteRequestPassthroughHeader(request) {
	const acceptHeader = request.headers.get("accept");
	/**
	* @note Remove the internal bypass request header.
	* In the browser, this is done by the worker script.
	* In Node.js, it has to be done here.
	*/
	if (acceptHeader) {
		const nextAcceptHeader = acceptHeader.replace(/(,\s+)?msw\/passthrough/, "");
		if (nextAcceptHeader) request.headers.set("accept", nextAcceptHeader);
		else request.headers.delete("accept");
	}
}
async function executeUnhandledFrameHandle(frame, handle) {
	const printStrategyMessage = async (strategy) => {
		if (strategy === "bypass") return;
		const message = await frame.getUnhandledMessage();
		switch (strategy) {
			case "warn": return devUtils.warn("Warning: %s", message);
			case "error": return devUtils.error("Error: %s", message);
		}
	};
	const applyStrategy = async (strategy) => {
		invariant.as(InternalError, strategy === "bypass" || strategy === "warn" || strategy === "error", devUtils.formatMessage("Failed to react to an unhandled network frame: unknown strategy \"%s\". Please provide one of the supported strategies (\"bypass\", \"warn\", \"error\") or a custom callback function as the value of the \"onUnhandledFrame\" option.", strategy));
		if (strategy === "bypass") return;
		await printStrategyMessage(strategy);
		if (strategy === "error") return Promise.reject(new InternalError(devUtils.formatMessage("Cannot bypass a request when using the \"error\" strategy for the \"onUnhandledFrame\" option.")));
	};
	if (typeof handle === "function") return handle({
		frame,
		defaults: {
			warn: printStrategyMessage.bind(null, "warn"),
			/**
			* @note The defaults only print the corresponding messages now.
			* They do not affect the frame resolution (e.g. do not error the frame).
			* That is only for backward compatibility reasons. In the future, these should
			* be an alias to `applyStrategy.bind(null, 'error')` instead.
			*/
			error: printStrategyMessage.bind(null, "error")
		}
	});
	/**
	* Ignore unhandled common HTTP assets.
	* @note Calling this here applies the common assets check
	* only to the scenarios when `onUnhandledFrame` was set to a predefined strategy.
	* When using a custom function, you need to check for common assets manually.
	*/
	if (frame instanceof HttpNetworkFrame && isCommonAssetRequest(frame.data.request)) return;
	return applyStrategy(handle);
}
var RequestEvent = class extends TypedEvent {
	requestId;
	request;
	constructor(type, data) {
		super(...[type, {}]);
		this.requestId = data.requestId;
		this.request = data.request;
	}
};
var ResponseEvent = class extends TypedEvent {
	requestId;
	request;
	response;
	constructor(type, data) {
		super(...[type, {}]);
		this.requestId = data.requestId;
		this.request = data.request;
		this.response = data.response;
	}
};
var UnhandledExceptionEvent = class extends TypedEvent {
	error;
	requestId;
	request;
	constructor(type, data) {
		super(...[type, {}]);
		this.error = data.error;
		this.requestId = data.requestId;
		this.request = data.request;
	}
};
var HttpNetworkFrame = class extends NetworkFrame {
	constructor(options) {
		const id = options.id || createRequestId();
		super("http", {
			id,
			request: options.request
		});
	}
	getHandlers(controller) {
		return controller.getHandlersByKind("request");
	}
	async getUnhandledMessage() {
		const { request } = this.data;
		const url = new URL(request.url);
		const publicUrl = toPublicUrl(url) + url.search;
		const requestBody = request.body == null ? null : await request.clone().text();
		return `intercepted a request without a matching request handler:${`\n\n  \u2022 ${request.method} ${publicUrl}\n\n${requestBody ? `  \u2022 Request body: ${requestBody}\n\n` : ""}`}If you still wish to intercept this unhandled request, please create a request handler for it.\nRead more: https://mswjs.io/docs/http/intercepting-requests`;
	}
	async resolve(handlers, onUnhandledFrame, resolutionContext) {
		const { id: requestId, request } = this.data;
		const requestCloneForLogs = resolutionContext?.quiet ? null : request.clone();
		this.events.emit(new RequestEvent("request:start", {
			requestId,
			request
		}));
		if (shouldBypassRequest(request)) {
			this.events.emit(new RequestEvent("request:end", {
				requestId,
				request
			}));
			this.passthrough();
			return null;
		}
		const [lookupError, lookupResult] = await until$1(() => {
			return executeHandlers({
				requestId,
				request,
				handlers,
				resolutionContext: {
					baseUrl: resolutionContext?.baseUrl?.toString(),
					quiet: resolutionContext?.quiet
				}
			});
		});
		if (lookupError != null) {
			if (!this.events.emit(new UnhandledExceptionEvent("unhandledException", {
				error: lookupError,
				requestId,
				request
			}))) {
				console.error(lookupError);
				devUtils.error("Encountered an unhandled exception during the handler lookup for \"%s %s\". Please see the original error above.", request.method, request.url);
			}
			this.errorWith(lookupError);
			return null;
		}
		if (lookupResult == null) {
			/**
			* @note Unhandled CONNECT requests establish a tunnel through a proxy.
			* They are transport, not the request the developer cares about, so
			* they pass through silently regardless of the unhandled frame strategy.
			* The request sent through the tunnel gets its own resolution.
			*/
			if (isStringEqual(request.method, "CONNECT")) {
				this.events.emit(new RequestEvent("request:end", {
					requestId,
					request
				}));
				this.passthrough();
				return null;
			}
			this.events.emit(new RequestEvent("request:unhandled", {
				requestId,
				request
			}));
			/**
			* @note The unhandled frame handle must be executed during the request resolution
			* since it can influence it (e.g. error the request if the "error" startegy was used).
			*/
			await executeUnhandledFrameHandle(this, onUnhandledFrame).then(() => this.passthrough(), (error) => this.errorWith(error));
			this.events.emit(new RequestEvent("request:end", {
				requestId,
				request
			}));
			return false;
		}
		const { response, handler, parsedResult } = lookupResult;
		this.events.emit(new RequestEvent("request:match", {
			requestId,
			request
		}));
		if (response == null) {
			this.events.emit(new RequestEvent("request:end", {
				requestId,
				request
			}));
			this.passthrough();
			return null;
		}
		if (isPassthroughResponse(response)) {
			this.events.emit(new RequestEvent("request:end", {
				requestId,
				request
			}));
			this.passthrough();
			return null;
		}
		const responseCloneForLogs = resolutionContext?.quiet ? null : response.clone();
		await storeResponseCookies(request, response);
		this.respondWith(response);
		this.events.emit(new RequestEvent("request:end", {
			requestId,
			request
		}));
		if (!resolutionContext?.quiet) handler.log({
			request: requestCloneForLogs,
			response: responseCloneForLogs,
			parsedResult
		});
		return true;
	}
};
var WebSocketConnectionEvent = class extends TypedEvent {
	url;
	protocols;
	constructor(type, data) {
		super(...[type, {}]);
		this.url = data.url;
		this.protocols = data.protocols;
	}
};
var WebSocketErrorEvent = class extends WebSocketConnectionEvent {
	error;
	constructor(type, data) {
		super(type, data);
		this.error = data.error;
	}
};
var WebSocketNetworkFrame = class extends NetworkFrame {
	constructor(options) {
		super("ws", { connection: options.connection });
	}
	getHandlers(controller) {
		return controller.getHandlersByKind("websocket");
	}
	async resolve(handlers, onUnhandledFrame, resolutionContext) {
		const { connection } = this.data;
		this.events.emit(new WebSocketConnectionEvent("websocket:connection", {
			url: connection.client.url,
			protocols: connection.info.protocols
		}));
		const handleSocketError = (event) => {
			this.events.emit(new WebSocketErrorEvent("websocket:error", {
				url: connection.client.url,
				protocols: connection.info.protocols,
				error: getErrorFromEvent(event)
			}));
		};
		connection.client.socket.addEventListener("error", handleSocketError);
		connection.client.socket.addEventListener("close", () => {
			connection.client.socket.removeEventListener("error", handleSocketError);
		}, { once: true });
		if (handlers.length === 0) {
			await executeUnhandledFrameHandle(this, onUnhandledFrame).then(() => this.passthrough(), (error) => this.errorWith(error));
			return false;
		}
		let hasMatchingHandlers = false;
		for (const handler of handlers) {
			const handlerConnection = await handler.run(connection, {
				baseUrl: resolutionContext?.baseUrl?.toString(),
				/**
				* @note Expose an emit-only reference to this frame's events
				* so the handlers can emit additional events not covered by
				* the frame (e.g. "graphql:subscription").
				*/
				events: this.events,
				/**
				* @note Do not emit the handler's "connection" event when running the handler.
				* Use the run only to get the resolved connection object.
				*/
				[kAutoConnect]: false
			});
			if (!handlerConnection) continue;
			hasMatchingHandlers = true;
			/**
			* @note Attach the WebSocket logger *before* emitting the handler's "connection" event.
			* Connection event listeners may perform actions that should be reflected in the logs
			* (e.g. closing the connection immediately). If the logger is attached after the connection,
			* those actions cannot be properly logged.
			*/
			const removeLogger = !resolutionContext?.quiet ? handler.log(connection) : void 0;
			try {
				if (!handler[kConnect](handlerConnection)) removeLogger?.();
			} catch (error) {
				if (!this.events.emit(new WebSocketErrorEvent("unhandledException", {
					error,
					url: connection.client.url,
					protocols: connection.info.protocols
				}))) {
					console.error(error);
					devUtils.error("Encountered an unhandled exception during the handler lookup for \"%s\". Please see the original error above.", connection.client.url);
				}
				/**
				* @note Throw the caught error so it gets picked up by WebSocketInterceptor.
				* It's the interceptor who translates handler errors to WebSocket closures.
				*/
				throw error;
			}
		}
		if (!hasMatchingHandlers) {
			await executeUnhandledFrameHandle(this, onUnhandledFrame).then(() => this.passthrough(), (error) => this.errorWith(error));
			return false;
		}
		return true;
	}
	async getUnhandledMessage() {
		const { connection } = this.data;
		return `intercepted a WebSocket connection without a matching event handler:${`\n\n  \u2022 ${connection.client.url}\n\n`}If you still wish to intercept this unhandled connection, please create an event handler for it.\nRead more: https://mswjs.io/docs/websocket`;
	}
};
/**
* Extract the error from the given "error" event, if any.
* Supports both the `ErrorEvent.error` property and the `cause`
* property that MSW sets when erroring the connection itself.
*/
function getErrorFromEvent(event) {
	if ("error" in event && event.error != null) return event.error;
	if ("cause" in event && event.cause != null) return event.cause;
}
/**
* Create a network source from the given list of interceptors.
*/
var InterceptorSource = class extends NetworkSource {
	#interceptor;
	/**
	* @note Frames are keyed by the request instance, not the request ID.
	* The interceptor emits the same request instance on the "request"
	* and "response" events, so the frame can be looked up by identity.
	* A weak reference lets the frame be garbage collected alongside
	* its request once the request settles without producing a response
	* (e.g. a passthrough request failing with a network error).
	* @see https://github.com/mswjs/msw/issues/2792
	*/
	#frames;
	constructor(options) {
		super();
		this.#interceptor = new BatchInterceptor({
			name: "interceptor-source",
			interceptors: options.interceptors
		});
		this.#frames = /* @__PURE__ */ new WeakMap();
	}
	enable() {
		this.#interceptor.apply();
		this.#interceptor.on("request", this.#handleRequest.bind(this)).on("response", this.#handleResponse.bind(this)).on("connection", this.#handleWebSocketConnection.bind(this));
	}
	disable() {
		super.disable();
		this.#interceptor.dispose();
		/**
		* @todo We can also abort any pending frames here, given we implement
		* the `NetworkFrame.abort()` method.
		*/
		this.#frames = /* @__PURE__ */ new WeakMap();
	}
	async #handleRequest(event) {
		const { requestId, request, controller } = event;
		const httpFrame = new InterceptorHttpNetworkFrame({
			id: requestId,
			request,
			controller
		});
		this.#frames.set(request, httpFrame);
		await this.queue(httpFrame);
	}
	async #handleResponse({ requestId, request, response, responseType }) {
		const httpFrame = this.#frames.get(request);
		this.#frames.delete(request);
		if (httpFrame == null) return;
		queueMicrotask(() => {
			try {
				httpFrame.events.emit(new ResponseEvent(responseType === "mock" ? "response:mocked" : "response:bypass", {
					requestId,
					request,
					response
				}));
			} finally {
				/**
				* @note Remove any listeners from this frame.
				* Past this point, it won't emit anything. The removal is crucial
				* to prevent "rettime" from keeping the abort cleanup listeners internally.
				* @see https://github.com/mswjs/msw/issues/2735
				*/
				httpFrame.events.removeAllListeners();
			}
		});
	}
	async #handleWebSocketConnection(connection) {
		await this.queue(new InterceptorWebSocketNetworkFrame({ connection }));
	}
};
var InterceptorHttpNetworkFrame = class extends HttpNetworkFrame {
	#controller;
	constructor(options) {
		super({
			id: options.id,
			request: options.request
		});
		this.#controller = options.controller;
	}
	passthrough() {
		deleteRequestPassthroughHeader(this.data.request);
	}
	respondWith(response) {
		if (response) this.#controller.respondWith(response);
	}
	errorWith(reason) {
		if (reason instanceof Response) return this.respondWith(reason);
		if (reason instanceof InternalError) this.#controller.errorWith(reason);
		throw reason;
	}
};
var InterceptorWebSocketNetworkFrame = class extends WebSocketNetworkFrame {
	/**
	* The in-process client connection, whose socket
	* the frame dispatches errors on.
	*/
	#client;
	constructor(args) {
		super({ connection: args.connection });
		this.#client = args.connection.client;
		/**
		* @note Provide a similar frame listener cleanup as for HTTP.
		* When the client connection closes, the handler can no longer be used.
		*/
		args.connection.client.addEventListener("close", () => {
			this.events.removeAllListeners();
		}, { once: true });
	}
	errorWith(reason) {
		if (reason instanceof Error) {
			/**
			* Use `client.errorWith(reason)` in the future.
			* @see https://github.com/mswjs/interceptors/issues/747
			*/
			const errorEvent = new Event("error");
			Object.defineProperty(errorEvent, "cause", {
				enumerable: true,
				configurable: false,
				value: reason
			});
			this.#client.socket.dispatchEvent(errorEvent);
		}
	}
	passthrough() {
		this.data.connection.server.connect();
	}
};
// node_modules/@open-draft/until/lib/index.js
/**
* Gracefully handles a callback that returns a promise.
*
* @example
* await until(() => Promise.resolve(123))
* // [null, 123]
*
* await until(() => Promise.reject(new Error('Oops!')))
* // [new Error('Oops!'), null]
*/
async function until(callback) {
	try {
		return [null, await callback().catch((error) => {
			throw error;
		})];
	} catch (error) {
		return [error, null];
	}
}
// node_modules/@mswjs/interceptors/lib/browser/handle-request-y7ajyve5.js
var HttpRequestEvent = class extends TypedEvent {
	constructor(data) {
		super(...["request", {}]);
		this.request = data.request;
		this.requestId = data.requestId;
		this.initiator = data.initiator;
		this.controller = data.controller;
	}
};
var HttpResponseEvent = class extends TypedEvent {
	constructor(data) {
		super(...["response", {}]);
		this.response = data.response;
		this.responseType = data.responseType;
		this.request = data.request;
		this.requestId = data.requestId;
		this.initiator = data.initiator;
	}
};
var UnhandledHttpException = class extends TypedEvent {
	constructor(data) {
		super(...["unhandledException", {}]);
		this.error = data.error;
		this.request = data.request;
		this.requestId = data.requestId;
		this.initiator = data.initiator;
		this.controller = data.controller;
	}
};
function isNodeLikeError(error) {
	if (error == null) return false;
	if (!(error instanceof Error)) return false;
	return "code" in error && "errno" in error;
}
async function handleRequest(options) {
	if (options.logger?.isEnabled("default")) formatRequest(options.request).then((message) => {
		options.logger?.info("[%s] %s", options.requestId, message);
	});
	const handleResponse = async (response) => {
		if (response instanceof Error) {
			await options.controller.errorWith(response);
			return true;
		}
		if (isResponseError(response)) {
			await options.controller.respondWith(response);
			return true;
		}
		/**
		* Handle normal responses or response-like objects.
		* @note This must come before the arbitrary object check
		* since Response instances are, in fact, objects.
		*/
		if (isResponseLike(response)) {
			await options.controller.respondWith(response);
			return true;
		}
		if (isObject(response)) {
			await options.controller.errorWith(response);
			return true;
		}
		return false;
	};
	const handleResponseError = async (error) => {
		if (error instanceof InterceptorError) throw resultError;
		if (isNodeLikeError(error)) {
			await options.controller.errorWith(error);
			return true;
		}
		if (error instanceof Response) return await handleResponse(error);
		return false;
	};
	const requestAbortPromise = Promise.withResolvers();
	let requestAbortReason;
	let isRequestAborted = false;
	const onAbort = () => {
		isRequestAborted = true;
		requestAbortReason = options.request.signal?.reason;
		requestAbortPromise.reject(requestAbortReason);
	};
	/**
	* @note `signal` is not always defined in React Native.
	*/
	if (options.request.signal) {
		if (options.request.signal.aborted) {
			await options.controller.errorWith(options.request.signal.reason);
			return;
		}
		options.request.signal.addEventListener("abort", onAbort, { once: true });
	}
	const [resultError] = await until(async () => {
		const requestEvent = new HttpRequestEvent({
			initiator: options.initiator,
			requestId: options.requestId,
			request: options.request,
			controller: options.controller
		});
		const requestListenersPromise = options.emitter.emitAsPromise(requestEvent);
		await Promise.race([
			requestAbortPromise.promise,
			requestListenersPromise,
			options.controller.handled
		]);
		/**
		* @note If the "request" listener has replaced the request instance,
		* propagate that mutation back to the underlying insterceptor.
		* This happens with XMLHttpRequest that replaces request instances
		* to correctly reflect the "withCredentials" option on the Fetch API request.
		*/
		if (requestEvent.request !== options.request) options.request = requestEvent.request;
	});
	options.request.signal?.removeEventListener("abort", onAbort);
	if (isRequestAborted) {
		await options.controller.errorWith(requestAbortReason);
		return;
	}
	if (resultError) {
		if (await handleResponseError(resultError)) return;
		if (options.emitter.listenerCount("unhandledException") > 0) {
			const unhandledExceptionController = new RequestController(options.request, {
				/**
				* @note Intentionally empty passthrough handle.
				* This controller is created within another controller and we only need
				* to know if `unhandledException` listeners handled the request.
				*/
				passthrough() {},
				async respondWith(response) {
					await handleResponse(response);
				},
				async errorWith(reason) {
					/**
					* @note Handle the result of the unhandled controller
					* in the same way as the original request controller.
					* The exception here is that thrown errors within the
					* "unhandledException" event do NOT result in another
					* emit of the same event. They are forwarded as-is.
					*/
					await options.controller.errorWith(reason);
				}
			});
			await options.emitter.emitAsPromise(new UnhandledHttpException({
				initiator: options.initiator,
				error: resultError,
				request: options.request,
				requestId: options.requestId,
				controller: unhandledExceptionController
			}));
			if (unhandledExceptionController.readyState !== RequestController.PENDING) return;
		}
		await options.controller.respondWith(createServerErrorResponse(resultError));
		return;
	}
	if (options.controller.readyState === RequestController.PENDING) return await options.controller.passthrough();
	return options.controller.handled;
}
// node_modules/@mswjs/interceptors/lib/browser/web-BRBQ3YPp.js
/**
* Concatenate two `Uint8Array` buffers.
*/
function concatArrayBuffer(left, right) {
	const result = new Uint8Array(left.byteLength + right.byteLength);
	result.set(left, 0);
	result.set(right, left.byteLength);
	return result;
}
var EventPolyfill = class {
	constructor(type, options) {
		this.NONE = 0;
		this.CAPTURING_PHASE = 1;
		this.AT_TARGET = 2;
		this.BUBBLING_PHASE = 3;
		this.type = "";
		this.srcElement = null;
		this.currentTarget = null;
		this.eventPhase = 0;
		this.isTrusted = true;
		this.composed = false;
		this.cancelable = true;
		this.defaultPrevented = false;
		this.bubbles = true;
		this.lengthComputable = true;
		this.loaded = 0;
		this.total = 0;
		this.cancelBubble = false;
		this.returnValue = true;
		this.type = type;
		this.target = options?.target || null;
		this.currentTarget = options?.currentTarget || null;
		this.timeStamp = Date.now();
	}
	composedPath() {
		return [];
	}
	initEvent(type, bubbles, cancelable) {
		this.type = type;
		this.bubbles = !!bubbles;
		this.cancelable = !!cancelable;
	}
	preventDefault() {
		this.defaultPrevented = true;
	}
	stopPropagation() {}
	stopImmediatePropagation() {}
};
var ProgressEventPolyfill = class extends EventPolyfill {
	constructor(type, init) {
		super(type);
		this.lengthComputable = init?.lengthComputable || false;
		this.composed = init?.composed || false;
		this.loaded = init?.loaded || 0;
		this.total = init?.total || 0;
	}
};
var SUPPORTS_PROGRESS_EVENT = typeof ProgressEvent !== "undefined";
function createEvent(target, type, init) {
	const progressEvents = [
		"error",
		"progress",
		"loadstart",
		"loadend",
		"load",
		"timeout",
		"abort"
	];
	/**
	* `ProgressEvent` is not supported in React Native.
	* @see https://github.com/mswjs/interceptors/issues/40
	*/
	const ProgressEventClass = SUPPORTS_PROGRESS_EVENT ? ProgressEvent : ProgressEventPolyfill;
	return progressEvents.includes(type) ? new ProgressEventClass(type, {
		lengthComputable: true,
		loaded: init?.loaded || 0,
		total: init?.total || 0
	}) : new EventPolyfill(type, {
		target,
		currentTarget: target
	});
}
/**
* Returns the source object of the given property on the target object
* (the target itself, any parent in its prototype, or null).
*/
function findPropertySource(target, propertyName) {
	if (!(propertyName in target)) return null;
	if (Object.prototype.hasOwnProperty.call(target, propertyName)) return target;
	const prototype = Reflect.getPrototypeOf(target);
	return prototype ? findPropertySource(prototype, propertyName) : null;
}
function createProxy(target, options) {
	return new Proxy(target, optionsToProxyHandler(options));
}
function optionsToProxyHandler(options) {
	const { constructorCall, methodCall, getProperty, setProperty } = options;
	const handler = {};
	if (typeof constructorCall !== "undefined") handler.construct = function(target, args, newTarget) {
		const next = Reflect.construct.bind(null, target, args, newTarget);
		return constructorCall.call(newTarget, args, next);
	};
	handler.set = function(target, propertyName, nextValue) {
		const next = () => {
			const propertySource = findPropertySource(target, propertyName) || target;
			const ownDescriptors = Reflect.getOwnPropertyDescriptor(propertySource, propertyName);
			if (typeof ownDescriptors?.set !== "undefined") {
				ownDescriptors.set.apply(target, [nextValue]);
				return true;
			}
			return Reflect.defineProperty(propertySource, propertyName, {
				writable: true,
				enumerable: true,
				configurable: true,
				value: nextValue
			});
		};
		if (typeof setProperty !== "undefined") return setProperty.call(target, [propertyName, nextValue], next);
		return next();
	};
	handler.get = function(target, propertyName, receiver) {
		/**
		* @note Using `Reflect.get()` here causes "TypeError: Illegal invocation".
		*/
		const next = () => target[propertyName];
		const value = typeof getProperty !== "undefined" ? getProperty.call(target, [propertyName, receiver], next) : next();
		if (typeof value === "function") return (...args) => {
			const next = value.bind(target, ...args);
			if (typeof methodCall !== "undefined") return methodCall.call(target, [propertyName, args], next);
			return next();
		};
		return value;
	};
	return handler;
}
function isDomParserSupportedType(type) {
	return [
		"application/xhtml+xml",
		"application/xml",
		"image/svg+xml",
		"text/html",
		"text/xml"
	].some((supportedType) => {
		return type.startsWith(supportedType);
	});
}
/**
* Parses a given string into JSON.
* Gracefully handles invalid JSON by returning `null`.
*/
function parseJson(data) {
	try {
		return JSON.parse(data);
	} catch (_) {
		return null;
	}
}
/**
* Creates a Fetch API `Response` instance from the given
* `XMLHttpRequest` instance and a response body.
*/
function createResponse(request, body) {
	/**
	* Handle XMLHttpRequest responses that must have null as the
	* response body when represented using Fetch API Response.
	* XMLHttpRequest response will always have an empty string
	* as the "request.response" in those cases, resulting in an error
	* when constructing a Response instance.
	* @see https://github.com/mswjs/interceptors/issues/379
	*/
	const responseBodyOrNull = FetchResponse.isResponseWithBody(request.status) ? body : null;
	return new FetchResponse(responseBodyOrNull, {
		url: request.responseURL,
		status: request.status,
		statusText: request.statusText,
		headers: createHeadersFromXMLHttpRequestHeaders(request.getAllResponseHeaders())
	});
}
function createHeadersFromXMLHttpRequestHeaders(headersString) {
	const headers = new Headers();
	const lines = headersString.split(/[\r\n]+/);
	for (const line of lines) {
		if (line.trim() === "") continue;
		const [name, ...parts] = line.split(": ");
		const value = parts.join(": ");
		headers.append(name, value);
	}
	return headers;
}
/**
* Return a total byte length of the given request/response body.
* If the `Content-Length` header is present, it will be used as the byte length.
*/
async function getBodyByteLength(input) {
	const explicitContentLength = input.headers.get("content-length");
	if (explicitContentLength != null && explicitContentLength !== "") return Number(explicitContentLength);
	return (await input.arrayBuffer()).byteLength;
}
var kIsRequestHandled = Symbol("kIsRequestHandled");
var kFetchRequest = Symbol("kFetchRequest");
var MAX_REDIRECTS = 20;
/**
* An `XMLHttpRequest` instance controller that allows us
* to handle any given request instance (e.g. responding to it).
*/
var XMLHttpRequestController = class {
	constructor(initialRequest, logger) {
		this.initialRequest = initialRequest;
		this.logger = logger;
		this.sync = false;
		this.method = "GET";
		this.url = null;
		this[kIsRequestHandled] = false;
		this.redirectCount = 0;
		this.events = /* @__PURE__ */ new Map();
		this.uploadEvents = /* @__PURE__ */ new Map();
		this.requestId = createRequestId();
		this.requestHeaders = new Headers();
		this.responseBuffer = /* @__PURE__ */ new Uint8Array();
		this.request = createProxy(initialRequest, { methodCall: ([methodName, args], invoke) => {
			switch (methodName) {
				case "open": {
					const [method, url, async] = args;
					this.sync = !(async ?? true);
					if (typeof url === "undefined") {
						this.method = "GET";
						this.url = toAbsoluteUrl(method);
					} else {
						this.method = method;
						this.url = toAbsoluteUrl(url);
					}
					this.logger.verbose("open %s %s", this.method, this.url.href);
					return invoke();
				}
				case "addEventListener": {
					const [eventName, listener] = args;
					this.registerEvent(eventName, listener);
					this.logger.verbose("addEventListener", eventName, listener);
					return invoke();
				}
				case "setRequestHeader": {
					const [name, value] = args;
					this.requestHeaders.set(name, value);
					this.logger.verbose("setRequestHeader", name, value);
					return invoke();
				}
				case "send": {
					const [body] = args;
					if (this.sync) {
						console.warn(`Failed to intercept an XMLHttpRequest (${this.method} ${this.url}): synchronous requests are not supported. This request will be performed as-is.`);
						return invoke();
					}
					this.request.addEventListener("load", () => {
						if (typeof this.onResponse !== "undefined") {
							const fetchResponse = createResponse(
								this.request,
								/**
								* The `response` property is the right way to read
								* the ambiguous response body, as the request's "responseType" may differ.
								* @see https://xhr.spec.whatwg.org/#the-response-attribute
								*/
								this.request.response
							);
							this.onResponse.call(this, {
								response: fetchResponse,
								responseType: this[kIsRequestHandled] ? "mock" : "original",
								request: fetchRequest,
								requestId: this.requestId
							});
						}
					});
					const requestBody = typeof body === "string" ? encodeBuffer(body) : body;
					const fetchRequest = this.toFetchApiRequest(requestBody);
					this[kFetchRequest] = fetchRequest.clone();
					/**
					* @note Start request handling on the next tick so that the user
					* could add event listeners for "loadend" before the interceptor fires it.
					*/
					queueMicrotask(() => {
						(this.onRequest?.call(this, {
							request: fetchRequest,
							requestId: this.requestId
						}) || Promise.resolve()).finally(() => {
							if (!this[kIsRequestHandled]) {
								this.logger.verbose("request callback settled but request has not been handled (readystate %d), performing as-is...", this.request.readyState);
								return invoke();
							}
						});
					});
					break;
				}
				default: return invoke();
			}
		} });
		/**
		* Proxy the `.upload` property to gather the event listeners/callbacks.
		*/
		define(this.request, "upload", createProxy(this.request.upload, {
			setProperty: ([propertyName, nextValue], invoke) => {
				switch (propertyName) {
					case "onloadstart":
					case "onprogress":
					case "onaboart":
					case "onerror":
					case "onload":
					case "ontimeout":
					case "onloadend": {
						const eventName = propertyName.slice(2);
						this.registerUploadEvent(eventName, nextValue);
					}
				}
				return invoke();
			},
			methodCall: ([methodName, args], invoke) => {
				switch (methodName) {
					case "addEventListener": {
						const [eventName, listener] = args;
						this.registerUploadEvent(eventName, listener);
						this.logger.verbose("upload.addEventListener", eventName, listener);
						return invoke();
					}
				}
			}
		}));
	}
	registerEvent(eventName, listener) {
		const nextEvents = (this.events.get(eventName) || []).concat(listener);
		this.events.set(eventName, nextEvents);
		this.logger.verbose("registered event \"%s\"", eventName, listener);
	}
	registerUploadEvent(eventName, listener) {
		const nextEvents = (this.uploadEvents.get(eventName) || []).concat(listener);
		this.uploadEvents.set(eventName, nextEvents);
		this.logger.verbose("registered upload event \"%s\"", eventName, listener);
	}
	/**
	* Responds to the current request with the given
	* Fetch API `Response` instance.
	*/
	async respondWith(response) {
		/**
		* @note Since `XMLHttpRequestController` delegates the handling of the responses
		* to the "load" event listener that doesn't distinguish between the mocked and original
		* responses, mark the request that had a mocked response with a corresponding symbol.
		*
		* Mark this request as having a mocked response immediately since
		* calculating request/response total body length is asynchronous.
		*/
		this[kIsRequestHandled] = true;
		this.logger.verbose("responding with a mocked response: %d %s", response.status, response.statusText);
		FetchResponse.setUrl(this.url.href, response);
		Object.defineProperties(this.request, {
			response: {
				enumerable: true,
				configurable: false,
				get: () => this.response
			},
			responseText: {
				enumerable: true,
				configurable: false,
				get: () => this.responseText
			},
			responseXML: {
				enumerable: true,
				configurable: false,
				get: () => this.responseXML
			}
		});
		this.trigger("loadstart", this.request, {
			loaded: 0,
			total: 0
		});
		let requestBodyTransmitted = 0;
		let uploadComplete = false;
		if (this[kFetchRequest]) {
			const requestBodyLength = await getBodyByteLength(this[kFetchRequest].clone());
			if (!uploadComplete) this.trigger("loadstart", this.request.upload, {
				loaded: 0,
				total: requestBodyLength
			});
			const processRequestBodyChunkLength = (bytesLength) => {
				requestBodyTransmitted += bytesLength;
				if (requestBodyTransmitted < requestBodyLength) this.trigger("progress", this.request.upload, {
					loaded: requestBodyTransmitted,
					total: requestBodyLength
				});
			};
			const processRequestEndOfBody = () => {
				uploadComplete = true;
				this.trigger("progress", this.request.upload, {
					loaded: requestBodyTransmitted,
					total: requestBodyLength
				});
				this.trigger("load", this.request.upload, {
					loaded: requestBodyTransmitted,
					total: requestBodyLength
				});
				this.trigger("loadend", this.request.upload, {
					loaded: requestBodyTransmitted,
					total: requestBodyLength
				});
			};
			if (this[kFetchRequest]?.body != null) {
				const reader = this[kFetchRequest].body.getReader();
				while (true) {
					const { value, done } = await reader.read();
					if (done) {
						processRequestEndOfBody();
						break;
					}
					processRequestBodyChunkLength(value.byteLength);
				}
			} else processRequestEndOfBody();
		}
		let timedOut = false;
		const responseReadController = new AbortController();
		const requestErrorSteps = (event) => {
			this.setReadyState(this.request.DONE);
			if (!uploadComplete) {
				this.trigger(event, this.request.upload, {
					loaded: 0,
					total: 0
				});
				this.trigger("loadend", this.request.upload, {
					loaded: 0,
					total: 0
				});
			}
			this.trigger(event, this.request, {
				loaded: 0,
				total: 0
			});
			this.trigger("loadend", this.request, {
				loaded: 0,
				total: 0
			});
		};
		const processResponse = async (response) => {
			const handleErrors = () => {
				if (timedOut) requestErrorSteps("timeout");
				else if (responseReadController.signal.aborted) requestErrorSteps("abort");
				else if (isResponseError(response)) requestErrorSteps("error");
			};
			handleErrors();
			define(this.request, "status", response.status);
			define(this.request, "statusText", response.statusText);
			if (!this.request.responseURL) define(this.request, "responseURL", response.url);
			if (isResponseError(response)) return;
			/**
			* @note The response body length is derived ONLY from the "content-length" header.
			* If that response header is not set, the "total" in all progress events must be 0.
			*/
			const responseBodyLength = Number(response.headers.get("content-length") ?? "0");
			this.setReadyState(this.request.HEADERS_RECEIVED);
			let receivedBytes = 0;
			let lastReceivedResponseBytesAt = performance.now();
			const processResponseBodyChunk = (bytesLength) => {
				receivedBytes += bytesLength;
				const now = performance.now();
				const shouldBuffer = now - lastReceivedResponseBytesAt <= 60 && receivedBytes < responseBodyLength;
				lastReceivedResponseBytesAt = now;
				if (shouldBuffer) return;
				if (this.request.readyState === this.request.HEADERS_RECEIVED) this.setReadyState(this.request.LOADING, false);
				this.trigger("readystatechange", this.request);
				this.trigger("progress", this.request, {
					loaded: receivedBytes,
					total: responseBodyLength
				});
			};
			const processResponseBodyError = () => {
				requestErrorSteps("error");
			};
			const processResponseEndOfBody = async () => {
				handleErrors();
				if (isResponseError(response)) return;
				let transmitted = receivedBytes;
				this.setReadyState(this.request.DONE);
				this.trigger("load", this.request, {
					loaded: transmitted,
					total: responseBodyLength
				});
				this.trigger("loadend", this.request, {
					loaded: transmitted,
					total: responseBodyLength
				});
			};
			if (response.body == null) processResponseEndOfBody();
			else {
				const reader = response.body.getReader();
				while (true) {
					if (responseReadController.signal.aborted) break;
					try {
						const { value, done } = await reader.read();
						if (done) {
							processResponseEndOfBody();
							return;
						}
						processResponseBodyChunk(value.byteLength);
						this.responseBuffer = concatArrayBuffer(this.responseBuffer, value);
					} catch {
						processResponseBodyError();
					}
				}
			}
		};
		const [redirectError, finalResponse] = await until(() => {
			return this.followRedirects(response);
		});
		if (redirectError) return;
		processResponse(finalResponse);
		if (this.request.timeout) setTimeout(() => {
			if (this.request.readyState !== this.request.DONE) {
				timedOut = true;
				responseReadController.abort();
			}
		}, this.request.timeout);
		this.request.getResponseHeader = new Proxy(this.request.getResponseHeader, { apply: (_, __, args) => {
			this.logger.verbose("getResponseHeader", args[0]);
			if (this.request.readyState < this.request.HEADERS_RECEIVED) {
				this.logger.verbose("headers not received yet, returning null");
				return null;
			}
			const headerValue = finalResponse.headers.get(args[0]);
			this.logger.verbose("resolved response header \"%s\" to", args[0], headerValue);
			return headerValue;
		} });
		this.request.getAllResponseHeaders = new Proxy(this.request.getAllResponseHeaders, { apply: () => {
			this.logger.verbose("getAllResponseHeaders");
			if (this.request.readyState < this.request.HEADERS_RECEIVED) {
				this.logger.verbose("headers not received yet, returning empty string");
				return "";
			}
			const allHeaders = Array.from(finalResponse.headers).map(([headerName, headerValue]) => {
				return `${headerName}: ${headerValue}`;
			}).join("\r\n");
			this.logger.verbose("resolved all response headers to", allHeaders);
			return allHeaders;
		} });
	}
	responseBufferToText() {
		return decodeBuffer(this.responseBuffer);
	}
	get response() {
		this.logger.verbose("getResponse (responseType: %s)", this.request.responseType);
		if (this.request.readyState !== this.request.DONE) return null;
		switch (this.request.responseType) {
			case "json": {
				const responseJson = parseJson(this.responseBufferToText());
				this.logger.verbose("resolved response JSON", responseJson);
				return responseJson;
			}
			case "arraybuffer": {
				const arrayBuffer = toArrayBuffer(this.responseBuffer);
				this.logger.verbose("resolved response ArrayBuffer", arrayBuffer);
				return arrayBuffer;
			}
			case "blob": {
				const mimeType = this.request.getResponseHeader("Content-Type") || "text/plain";
				const responseBlob = new Blob([this.responseBufferToText()], { type: mimeType });
				this.logger.verbose("resolved response Blob (mime type: %s)", responseBlob, mimeType);
				return responseBlob;
			}
			default: {
				const responseText = this.responseBufferToText();
				this.logger.verbose("resolving \"%s\" response type as text", this.request.responseType, responseText);
				return responseText;
			}
		}
	}
	get responseText() {
		/**
		* Throw when trying to read the response body as text when the
		* "responseType" doesn't expect text. This just respects the spec better.
		* @see https://xhr.spec.whatwg.org/#the-responsetext-attribute
		*/
		invariant(this.request.responseType === "" || this.request.responseType === "text", "InvalidStateError: The object is in invalid state.");
		if (this.request.readyState !== this.request.LOADING && this.request.readyState !== this.request.DONE) return "";
		const responseText = this.responseBufferToText();
		this.logger.verbose("getResponseText: \"%s\"", responseText);
		return responseText;
	}
	get responseXML() {
		invariant(this.request.responseType === "" || this.request.responseType === "document", "InvalidStateError: The object is in invalid state.");
		if (this.request.readyState !== this.request.DONE) return null;
		const contentType = this.request.getResponseHeader("Content-Type") || "";
		if (typeof DOMParser === "undefined") {
			console.warn("Cannot retrieve XMLHttpRequest response body as XML: DOMParser is not defined. You are likely using an environment that is not browser or does not polyfill browser globals correctly.");
			return null;
		}
		if (isDomParserSupportedType(contentType)) return new DOMParser().parseFromString(this.responseBufferToText(), contentType);
		return null;
	}
	async followRedirects(response) {
		const redirectLocation = response.headers.get("location");
		if (!redirectLocation || !FetchResponse.isRedirectResponse(response.status)) return response;
		this.redirectCount++;
		if (this.redirectCount > MAX_REDIRECTS) throw new Error("Too many redirects");
		const redirectUrl = new URL(redirectLocation, location.href);
		const redirectMethod = FetchResponse.isResponseWithBody(response.status) ? this.method : "GET";
		const redirectResponse = await new Promise((resolve, reject) => {
			const request = new XMLHttpRequest();
			request.responseType = this.request.responseType;
			request.addEventListener("load", () => {
				this.url = new URL(request.responseURL);
				resolve(createResponse(request, request.response));
			});
			request.addEventListener("error", () => {
				this.errorWith();
				reject(/* @__PURE__ */ new Error("Redirect request failed"));
			});
			request.open(redirectMethod, redirectUrl.href);
			request.send();
		});
		return this.followRedirects(redirectResponse);
	}
	errorWith(error) {
		/**
		* @note Mark this request as handled even if it received a mock error.
		* This prevents the controller from trying to perform this request as-is.
		*/
		this[kIsRequestHandled] = true;
		this.logger.verbose("responding with an error");
		this.setReadyState(this.request.DONE);
		this.trigger("error", this.request);
		this.trigger("loadend", this.request);
	}
	/**
	* Transitions this request's `readyState` to the given one.
	*/
	setReadyState(nextReadyState, triggerReadyStateChangeEvent = true) {
		this.logger.verbose("setReadyState: %d -> %d", this.request.readyState, nextReadyState);
		if (this.request.readyState === nextReadyState) {
			this.logger.verbose("ready state identical, skipping transition...");
			return;
		}
		define(this.request, "readyState", nextReadyState);
		this.logger.verbose("set readyState to: %d", nextReadyState);
		if (!triggerReadyStateChangeEvent) return;
		if (nextReadyState !== this.request.UNSENT) {
			this.logger.verbose("triggering \"readystatechange\" event...");
			this.trigger("readystatechange", this.request);
		}
	}
	/**
	* Triggers given event on the `XMLHttpRequest` instance.
	*/
	trigger(eventName, target, options) {
		const callback = target[`on${eventName}`];
		const event = createEvent(target, eventName, options);
		this.logger.verbose("trigger \"%s\"", eventName, options || "");
		if (typeof callback === "function") {
			this.logger.verbose("found a direct \"%s\" callback, calling...", eventName);
			callback.call(target, event);
		}
		const events = target instanceof XMLHttpRequestUpload ? this.uploadEvents : this.events;
		for (const [registeredEventName, listeners] of events) if (registeredEventName === eventName) {
			this.logger.verbose("found %d listener(s) for \"%s\" event, calling...", listeners.length, eventName);
			listeners.forEach((listener) => listener.call(target, event));
		}
	}
	/**
	* Converts this `XMLHttpRequest` instance into a Fetch API `Request` instance.
	*/
	toFetchApiRequest(body) {
		this.logger.verbose("converting request to a Fetch API Request...");
		const resolvedBody = body instanceof Document ? body.documentElement.innerText : body;
		const fetchRequest = new FetchRequest(this.url.href, {
			method: this.method,
			headers: this.requestHeaders,
			/**
			* @see https://xhr.spec.whatwg.org/#cross-origin-credentials
			*/
			credentials: this.request.withCredentials ? "include" : "same-origin",
			body: resolvedBody
		});
		const headers = fetchRequest.headers;
		define(fetchRequest, "headers", createProxy(headers, { methodCall: ([methodName, args], invoke) => {
			const result = invoke();
			switch (methodName) {
				case "append":
				case "set": {
					const [headerName, headerValue] = args;
					/**
					* @note Forward only the headers the Fetch API Request accepted.
					* Forbidden request headers (e.g. "Cookie") are dropped silently
					* by the request's headers guard, and forwarding them makes
					* the browser refuse them with an error in the console.
					*/
					if (headers.has(headerName)) this.request.setRequestHeader(headerName, headerValue);
					break;
				}
				case "delete": {
					const [headerName] = args;
					console.warn(`XMLHttpRequest: Cannot remove a "${headerName}" header from the Fetch API representation of the "${fetchRequest.method} ${fetchRequest.url}" request. XMLHttpRequest headers cannot be removed.`);
					break;
				}
			}
			return result;
		} }));
		this.logger.verbose("converted request to a Fetch API Request!", fetchRequest);
		return fetchRequest;
	}
};
function toAbsoluteUrl(url) {
	/**
	* @note XMLHttpRequest interceptor may run in environments
	* that implement XMLHttpRequest but don't implement "location"
	* (for example, React Native). If that's the case, return the
	* input URL as-is (nothing to be relative to).
	* @see https://github.com/mswjs/msw/issues/1777
	*/
	if (typeof location === "undefined") return new URL(url);
	return new URL(url.toString(), location.href);
}
function define(target, property, value) {
	Reflect.defineProperty(target, property, {
		writable: true,
		enumerable: true,
		value
	});
}
/**
* Create a proxied `XMLHttpRequest` class.
* The proxied class establishes spies on certain methods,
* allowing us to intercept requests and respond to them.
*/
function createXMLHttpRequestProxy({ emitter, logger }) {
	return new Proxy(globalThis.XMLHttpRequest, { construct(target, args, newTarget) {
		logger.verbose("constructed new XMLHttpRequest");
		const originalRequest = Reflect.construct(target, args, newTarget);
		/**
		* @note Forward prototype descriptors onto the proxied object.
		* XMLHttpRequest is implemented in JSDOM in a way that assigns
		* a bunch of descriptors, like "set responseType()" on the prototype.
		* With this propagation, we make sure that those descriptors trigger
		* when the user operates with the proxied request instance.
		*/
		const prototypeDescriptors = Object.getOwnPropertyDescriptors(target.prototype);
		for (const propertyName in prototypeDescriptors) Reflect.defineProperty(originalRequest, propertyName, prototypeDescriptors[propertyName]);
		const xhrRequestController = new XMLHttpRequestController(originalRequest, logger);
		xhrRequestController.onRequest = async function({ request, requestId }) {
			const controller = new RequestController(request, {
				passthrough: () => {
					this.logger.verbose("no mocked response received, performing request as-is...");
				},
				respondWith: async (response) => {
					await this.respondWith(response);
				},
				errorWith: (reason) => {
					this.logger.verbose("request errored %o", { error: reason });
					if (reason instanceof Error) this.errorWith(reason);
				}
			}, {
				logger,
				requestId
			});
			this.logger.verbose("awaiting mocked response");
			this.logger.verbose("emitting the \"request\" event for %s listener(s)...", emitter.listenerCount("request"));
			await handleRequest({
				initiator: this.request,
				request,
				requestId,
				controller,
				emitter,
				logger
			});
		};
		xhrRequestController.onResponse = async function({ response, responseType, request, requestId }) {
			this.logger.verbose("emitting the \"response\" event for %s listener(s)...", emitter.listenerCount("response"));
			await emitter.emitAsPromise(new HttpResponseEvent({
				initiator: this.request,
				response,
				responseType,
				request,
				requestId
			}));
		};
		return xhrRequestController.request;
	} });
}
var logger$1 = createLogger("xhr");
var XMLHttpRequestInterceptor = class extends Interceptor {
	static {
		this.symbol = Symbol.for("xhr-interceptor");
	}
	predicate() {
		return hasConfigurableGlobal("XMLHttpRequest");
	}
	setup() {
		logger$1.verbose("patching \"XMLHttpRequest\"...");
		this.subscriptions.push(patchesRegistry.applyPatch(globalThis, "XMLHttpRequest", () => {
			return createXMLHttpRequestProxy({
				emitter: this.emitter,
				logger: logger$1
			});
		}));
		logger$1.verbose("global \"XMLHttpRequest\" patched!", globalThis.XMLHttpRequest.name);
	}
};
// node_modules/@mswjs/interceptors/lib/browser/web-CCLERSZF.js
function createNetworkError(cause) {
	return Object.assign(/* @__PURE__ */ new TypeError("Failed to fetch"), { cause });
}
var REQUEST_BODY_HEADERS = [
	"content-encoding",
	"content-language",
	"content-location",
	"content-type",
	"content-length"
];
var kRedirectCount = Symbol("kRedirectCount");
/**
* @see https://github.com/nodejs/undici/blob/a6dac3149c505b58d2e6d068b97f4dc993da55f0/lib/web/fetch/index.js#L1210
*/
async function followFetchRedirect(request, response) {
	if (response.status !== 303 && request.body != null) return Promise.reject(createNetworkError());
	const requestUrl = new URL(request.url);
	let locationUrl;
	try {
		locationUrl = new URL(response.headers.get("location"), request.url);
	} catch (error) {
		return Promise.reject(createNetworkError(error));
	}
	if (!(locationUrl.protocol === "http:" || locationUrl.protocol === "https:")) return Promise.reject(createNetworkError("URL scheme must be a HTTP(S) scheme"));
	if (Reflect.get(request, kRedirectCount) > 20) return Promise.reject(createNetworkError("redirect count exceeded"));
	Object.defineProperty(request, kRedirectCount, { value: (Reflect.get(request, kRedirectCount) || 0) + 1 });
	if (request.mode === "cors" && (locationUrl.username || locationUrl.password) && !sameOrigin(requestUrl, locationUrl)) return Promise.reject(createNetworkError("cross origin not allowed for request mode \"cors\""));
	const requestInit = {};
	if ([301, 302].includes(response.status) && request.method === "POST" || response.status === 303 && !["HEAD", "GET"].includes(request.method)) {
		requestInit.method = "GET";
		requestInit.body = null;
		REQUEST_BODY_HEADERS.forEach((headerName) => {
			request.headers.delete(headerName);
		});
	}
	if (!sameOrigin(requestUrl, locationUrl)) {
		request.headers.delete("authorization");
		request.headers.delete("proxy-authorization");
		request.headers.delete("cookie");
		request.headers.delete("host");
	}
	/**
	* @note Undici "safely" extracts the request body.
	* I suspect we cannot dispatch this request again
	* since its body has been read and the stream is locked.
	*/
	requestInit.headers = request.headers;
	const finalResponse = await fetch(new Request(locationUrl, requestInit));
	Object.defineProperty(finalResponse, "redirected", {
		value: true,
		configurable: true
	});
	return finalResponse;
}
/**
* @see https://github.com/nodejs/undici/blob/a6dac3149c505b58d2e6d068b97f4dc993da55f0/lib/web/fetch/util.js#L761
*/
function sameOrigin(left, right) {
	if (left.origin === right.origin && left.origin === "null") return true;
	if (left.protocol === right.protocol && left.hostname === right.hostname && left.port === right.port) return true;
	return false;
}
var BrotliDecompressionStream = class extends TransformStream {
	constructor() {
		console.warn("[Interceptors]: Brotli decompression of response streams is not supported in the browser");
		super({ transform(chunk, controller) {
			controller.enqueue(chunk);
		} });
	}
};
var PipelineStream = class extends TransformStream {
	constructor(transformStreams, ...strategies) {
		super({}, ...strategies);
		const readable = [super.readable, ...transformStreams].reduce((readable, transform) => readable.pipeThrough(transform));
		Object.defineProperty(this, "readable", { get() {
			return readable;
		} });
	}
};
function parseContentEncoding(contentEncoding) {
	return contentEncoding.toLowerCase().split(",").map((coding) => coding.trim());
}
function createDecompressionStream(contentEncoding) {
	return new PipelineStream(parseContentEncoding(contentEncoding).reduceRight((transformers, coding) => {
		if (coding === "gzip" || coding === "x-gzip") return transformers.concat(new DecompressionStream("gzip"));
		else if (coding === "deflate") return transformers.concat(new DecompressionStream("deflate"));
		else if (coding === "br") return transformers.concat(new BrotliDecompressionStream());
		else transformers.length = 0;
		return transformers;
	}, []));
}
/**
* Returns a boolean indicating whether the given response
* has a body encoded with a non-empty "content-encoding".
*/
function isCompressedResponse(response) {
	if (response.body === null) return false;
	const contentEncoding = response.headers.get("content-encoding");
	return contentEncoding !== null && contentEncoding.trim() !== "";
}
/**
* Decompresses the body of the given compressed response.
*/
function decompressResponse(response) {
	invariant(isCompressedResponse(response), "Failed to decompress a response: expected a response with a body and a non-empty \"content-encoding\" header");
	const decompressionStream = createDecompressionStream(response.headers.get("content-encoding"));
	response.body.pipeTo(decompressionStream.writable);
	return decompressionStream.readable;
}
/** Clone for observers without letting their unread body block caller cancellation. */
function cloneResponse(response) {
	const clone = FetchResponse.clone(response);
	if (!response.body || !clone.body) return [response, clone];
	const observer = wrapResponse(clone);
	return [wrapResponse(response, observer.cancel).response, observer.response];
}
function wrapResponse(response, onCancel) {
	const body = response.body;
	const reader = body.getReader();
	const cancel = (reason) => {
		return body.locked ? reader.cancel(reason) : body.cancel(reason);
	};
	const stream = new ReadableStream({
		async pull(controller) {
			try {
				const { done, value } = await reader.read();
				if (done) {
					controller.close();
					reader.releaseLock();
					return;
				}
				controller.enqueue(value);
			} catch (error) {
				controller.error(error);
				reader.releaseLock();
			}
		},
		async cancel(reason) {
			try {
				const cancellation = cancel(reason);
				if (onCancel) await Promise.all([cancellation, onCancel(reason)]);
				else cancellation.catch(() => {});
			} finally {
				reader.releaseLock();
			}
		}
	}, { highWaterMark: 0 });
	const wrappedResponse = new FetchResponse(stream, response);
	copyRawHeaders(response.headers, wrappedResponse.headers);
	Object.defineProperties(wrappedResponse, {
		type: { value: response.type },
		redirected: { value: response.redirected }
	});
	return {
		response: wrappedResponse,
		cancel
	};
}
var logger = createLogger("fetch");
/**
* Intercept `fetch` requests in the browser.
*/
var FetchInterceptor = class extends Interceptor {
	static {
		this.symbol = Symbol.for("fetch-interceptor");
	}
	predicate() {
		return hasConfigurableGlobal("fetch");
	}
	async setup() {
		logger.verbose("patching global fetch...");
		this.subscriptions.push(patchesRegistry.applyPatch(globalThis, "fetch", (realFetch) => {
			return async (input, init) => {
				const requestId = createRequestId();
				/**
				* @note Resolve potentially relative request URL
				* against the present `location`. This is mainly
				* for native `fetch` in JSDOM.
				* @see https://github.com/mswjs/msw/issues/1625
				*/
				const resolvedInput = typeof input === "string" && typeof location !== "undefined" && !URL.canParse(input) ? new URL(input, location.href) : input;
				const request = new Request(resolvedInput, init);
				const responsePromise = Promise.withResolvers();
				const controller = new RequestController(request, {
					passthrough: async () => {
						logger.verbose("performing request as-is");
						/**
						* @note Perform a clone of the request instance, not the instance itself.
						* Performing a request consumes its body, and the "response" listener
						* must still be able to read it. The clone is created right before
						* the request is performed, so it preserves any modifications made
						* to the intercepted request in the "request" listener.
						*
						* This also keeps the request instance emitted on the "response" event
						* referentially equal to the one emitted on the "request" event
						* so the consumer can associate the two by identity.
						*/
						const requestClone = request.clone();
						const [responseError, originalResponse] = await until(() => realFetch(requestClone));
						if (responseError) return responsePromise.reject(responseError);
						logger.verbose("original fetch performed %o", originalResponse);
						if (this.emitter.listenerCount("response") > 0) {
							logger.verbose("emitting the \"response\" event");
							const [response, responseClone] = cloneResponse(originalResponse);
							await this.emitter.emitAsPromise(new HttpResponseEvent({
								initiator: request,
								request,
								requestId,
								response: responseClone,
								responseType: "original"
							}));
							responsePromise.resolve(response);
							return;
						}
						responsePromise.resolve(originalResponse);
					},
					respondWith: async (rawResponse) => {
						if (isResponseError(rawResponse)) {
							logger.verbose("request errored %o", { response: rawResponse });
							responsePromise.reject(createNetworkError(rawResponse));
							return;
						}
						/**
						* @note Forward the mocked response instance as-is. Wrapping it
						* in a new `Response` drops any runtime-specific state the
						* environment attached to it (e.g. the `webSocket` property
						* of a "101 Switching Protocols" response in workerd).
						* A plain `Response` is already guaranteed to be valid by the
						* environment, and a `FetchResponse` manages its own
						* non-configurable state (status, URL) across clones.
						*
						* The only exception is a compressed mocked response body:
						* a body cannot be swapped in place, so it must be a new instance.
						*/
						let response;
						if (isCompressedResponse(rawResponse)) {
							response = new FetchResponse(decompressResponse(rawResponse), {
								status: rawResponse.status,
								statusText: rawResponse.statusText,
								headers: rawResponse.headers
							});
							copyRawHeaders(rawResponse.headers, response.headers);
						} else response = rawResponse;
						FetchResponse.setUrl(request.url, response);
						/**
						* Undici's handling of following redirect responses.
						* Treat the "manual" redirect mode as a regular mocked response.
						* This way, the client can manually follow the redirect it receives.
						* @see https://github.com/nodejs/undici/blob/a6dac3149c505b58d2e6d068b97f4dc993da55f0/lib/web/fetch/index.js#L1173
						*/
						if (FetchResponse.isRedirectResponse(response.status)) {
							if (request.redirect === "error") {
								responsePromise.reject(createNetworkError("unexpected redirect"));
								return;
							}
							if (request.redirect === "follow") {
								followFetchRedirect(request, response).then((response) => {
									responsePromise.resolve(response);
								}, (reason) => {
									responsePromise.reject(reason);
								});
								return;
							}
						}
						if (this.emitter.listenerCount("response") > 0) {
							logger.verbose("emitting the \"response\" event");
							const [callerResponse, responseClone] = cloneResponse(response);
							await this.emitter.emitAsPromise(new HttpResponseEvent({
								initiator: request,
								response: responseClone,
								responseType: "mock",
								request,
								requestId
							}));
							responsePromise.resolve(callerResponse);
							return;
						}
						responsePromise.resolve(response);
					},
					errorWith: (reason) => {
						logger.verbose("request aborted %o", { reason });
						responsePromise.reject(reason);
					}
				}, {
					logger,
					requestId
				});
				logger.verbose("awaiting request resolution");
				logger.verbose("emitting the \"request\" event for %s listener(s)...", this.emitter.listenerCount("request"));
				/**
				* @note Give the consumer a chance to abort the request before
				* it is dispatched. Fetch queues the request processing as a
				* task, so a signal aborted synchronously after `fetch()` must
				* prevent the request from ever reaching the "request" listeners.
				* Without this, the first listener is invoked synchronously
				* within the `fetch()` call itself.
				*/
				await Promise.resolve();
				await handleRequest({
					initiator: request,
					request,
					requestId,
					emitter: this.emitter,
					controller,
					logger
				});
				return responsePromise.promise;
			};
		}));
		logger.verbose("global fetch patched: %s", globalThis.fetch.name);
	}
};
// node_modules/msw/lib/browser/index.js
/**
* Checks if the Service Worker API is supproted and available
* in the current browsing context.
*/
function supportsServiceWorker() {
	return typeof navigator !== "undefined" && "serviceWorker" in navigator && typeof location !== "undefined" && location.protocol !== "file:";
}
/**
* Returns a boolean indicating whether the current browser
* supports `ReadableStream` as a `Transferable` when posting
* messages.
*/
function supportsReadableStreamTransfer() {
	try {
		const stream = new ReadableStream({ start: (controller) => controller.close() });
		new MessageChannel().port1.postMessage(stream, [stream]);
		return true;
	} catch {
		return false;
	}
}
function toResponseInit(response) {
	return {
		status: response.status,
		statusText: response.statusText,
		headers: Object.fromEntries(response.headers.entries())
	};
}
/**
* Returns an absolute Service Worker URL based on the given
* relative URL (known during the registration).
*/
function getAbsoluteWorkerUrl(workerUrl) {
	return new URL(workerUrl, location.href).href;
}
/**
* Attempts to resolve a Service Worker instance from a given registration,
* regardless of its state (active, installing, waiting).
*/
function getWorkerByRegistration(registration, absoluteWorkerUrl, findWorker) {
	return [
		registration.active,
		registration.installing,
		registration.waiting
	].filter((state) => {
		return state != null;
	}).find((worker) => {
		return findWorker(worker.scriptURL, absoluteWorkerUrl);
	}) || null;
}
/**
* Returns an active Service Worker instance.
* When not found, registers a new Service Worker.
*/
var getWorkerInstance = async (url, options = {}, findWorker) => {
	const absoluteWorkerUrl = getAbsoluteWorkerUrl(url);
	const mockRegistrations = await navigator.serviceWorker.getRegistrations().then((registrations) => registrations.filter((registration) => getWorkerByRegistration(registration, absoluteWorkerUrl, findWorker)));
	if (!navigator.serviceWorker.controller && mockRegistrations.length > 0) location.reload();
	const [existingRegistration] = mockRegistrations;
	if (existingRegistration) {
		existingRegistration.update();
		return [getWorkerByRegistration(existingRegistration, absoluteWorkerUrl, findWorker), existingRegistration];
	}
	const [registrationError, registrationResult] = await until$1(async () => {
		const registration = await navigator.serviceWorker.register(url, options);
		return [getWorkerByRegistration(registration, absoluteWorkerUrl, findWorker), registration];
	});
	if (registrationError) {
		if (registrationError.message.includes("(404)")) {
			const scopeUrl = new URL(options?.scope || "/", location.href);
			throw new Error(devUtils.formatMessage(`\
Failed to register a Service Worker for scope ('${scopeUrl.href}') with script ('${absoluteWorkerUrl}'): Service Worker script does not exist at the given path.

Did you forget to run "npx msw init <PUBLIC_DIR>"?

Learn more about creating the Service Worker script: https://mswjs.io/docs/cli/init`));
		}
		throw new Error(devUtils.formatMessage("Failed to register the Service Worker:\n\n%s", registrationError.message));
	}
	return registrationResult;
};
var SUPPORTS_SERVICE_WORKER = supportsServiceWorker();
var WorkerEvent = class extends TypedEvent {
	#workerEvent;
	constructor(workerEvent) {
		const type = workerEvent.data.type;
		const data = workerEvent.data.payload;
		/**
		* @note This is the only place we're mapping { type, payload }
		* message structure of the worker. The client references the
		* payload via `event.data`.
		*/
		super(type, { data });
		this.#workerEvent = workerEvent;
	}
	get ports() {
		return this.#workerEvent.ports;
	}
	/**
	* Reply directly to this event using its `MessagePort`.
	*/
	postMessage(type, ...rest) {
		this.#workerEvent.ports[0].postMessage({
			type,
			data: rest[0]
		}, { transfer: rest[1] });
	}
};
var WorkerChannel = class extends Emitter {
	#getWorker;
	#controller;
	constructor(options) {
		super();
		invariant(SUPPORTS_SERVICE_WORKER, "Failed to open a WorkerChannel: Service Worker is not supported in this environment.");
		this.#getWorker = options.getWorker;
		this.#controller = new AbortController();
		navigator.serviceWorker.addEventListener("message", async (event) => {
			const worker = await this.#getWorker();
			if (event.source != null && event.source !== worker) return;
			if (event.data && isObject$1(event.data) && "type" in event.data) this.emit(new WorkerEvent(event));
		}, { signal: this.#controller.signal });
	}
	/**
	* Send data to the Service Worker controlling this client.
	* This triggers the `message` event listener on ServiceWorkerGlobalScope.
	*/
	postMessage(type) {
		invariant(SUPPORTS_SERVICE_WORKER, "Failed to post message on a WorkerChannel: the Service Worker API is unavailable in this environment. This is likely an issue with MSW. Please report it on GitHub: https://github.com/mswjs/msw/issues");
		this.#getWorker().then((worker) => {
			worker.postMessage(type);
		});
	}
	/**
	* Terminal teardown. Removes the `navigator.serviceWorker` message listener
	* and all emitter subscriptions. The channel is not usable afterwards.
	*/
	terminate() {
		this.#controller.abort();
		this.removeAllListeners();
	}
};
/**
* Converts a given request received from the Service Worker
* into a Fetch `Request` instance.
*/
function deserializeRequest(serializedRequest) {
	return new FetchRequest(serializedRequest.url, { ...serializedRequest });
}
/**
* Print a warning if the given Service Worker registration has a scope
* outside of the current page's location. That is to help with debugging
* issues caused by the incorrectly registered Service Worker.
*/
function validateWorkerScope(registration) {
	if (!location.href.startsWith(registration.scope)) devUtils.warn(`Cannot intercept requests on this page because it's outside of the worker's scope ("${registration.scope}"). If you wish to mock API requests on this page, you must resolve this scope issue.

- (Recommended) Register the worker at the root level ("/") of your application.
- Set the "Service-Worker-Allowed" response header to allow out-of-scope workers.`);
}
function shouldInvalidateWorker(prevOptions, nextOptions) {
	return prevOptions.findWorker !== nextOptions.findWorker || prevOptions.serviceWorker.url !== nextOptions.serviceWorker.url || JSON.stringify(prevOptions.serviceWorker.options) !== JSON.stringify(nextOptions.serviceWorker.options);
}
var ServiceWorkerSource = class ServiceWorkerSource extends NetworkSource {
	static #current;
	/**
	* Create a new Service Worker source or reuse an existing one.
	* These sources act as a singleton and only get recreated if the options change.
	*/
	static async from(options) {
		if (ServiceWorkerSource.#current == null) ServiceWorkerSource.#current = new ServiceWorkerSource(options);
		else if (shouldInvalidateWorker(ServiceWorkerSource.#current.#options, options)) {
			await ServiceWorkerSource.#current.terminate();
			ServiceWorkerSource.#current = new ServiceWorkerSource(options);
		}
		return ServiceWorkerSource.#current;
	}
	#options;
	/**
	* The resolved context of the network this source was last enabled with.
	*/
	#context;
	/**
	* @note We cannot use `WeakMap` here as request/response
	* identity cannot be preserved through the client-worker channel.
	*/
	#frames;
	#channel;
	#listenerController;
	#clientPromise;
	#keepAliveInterval;
	workerPromise;
	#workerResolvers;
	#workerState;
	constructor(options) {
		super();
		invariant(supportsServiceWorker(), "Failed to use Service Worker as the network source: the Service Worker API is not supported in this environment");
		this.#options = options;
		this.#frames = /* @__PURE__ */ new Map();
		this.#workerResolvers = Promise.withResolvers();
		this.workerPromise = this.#workerResolvers.promise;
		this.#workerState = "pending";
		this.#channel = new WorkerChannel({ getWorker: () => this.workerPromise.then(([worker]) => worker) });
	}
	async enable(context) {
		this.#context = context;
		this.#channel.removeAllListeners();
		this.#frames.clear();
		this.#listenerController = new AbortController();
		const [worker, registration] = await this.#startWorker();
		if (worker.state !== "activated") {
			const controller = new AbortController();
			const activationPromise = Promise.withResolvers();
			activationPromise.promise.then(() => controller.abort());
			worker.addEventListener("statechange", () => {
				if (worker.state === "activated") activationPromise.resolve();
			}, { signal: controller.signal });
			await activationPromise.promise;
		}
		this.#channel.postMessage("MOCK_ACTIVATE");
		const clientConfirmationPromise = Promise.withResolvers();
		this.#clientPromise = clientConfirmationPromise.promise;
		this.#channel.once("MOCKING_ENABLED", (event) => {
			clientConfirmationPromise.resolve(event.data.client);
		});
		await clientConfirmationPromise.promise;
		if (!this.#context?.quiet) this.#printStartMessage();
		return registration;
	}
	async disable() {
		/**
		* @note Do NOT call `super.disable()` because it removes any "frame" listeners
		* from this network source, effectively turning it off. The Service Worker source
		* is a bit special since it might process in-flight requests that have been performed
		* after it's been disabled.
		*/
		this.#listenerController?.abort();
		this.#listenerController = void 0;
		const closedPromise = Promise.withResolvers();
		this.#channel.once("CLIENT_CLOSED", () => closedPromise.resolve());
		this.#channel.postMessage("CLIENT_CLOSE");
		await closedPromise.promise;
		/**
		* @note Do NOT reset `workerPromise` here. The channel must continue to
		* resolve the currently registered SW so that any in-flight requests the
		* worker forwards after `stop()` can be answered with `PASSTHROUGH` by
		* `#handleRequest`. `#startWorker` swaps in a fresh deferred on re-enable.
		*/
		if (!this.#context?.quiet) this.#printStopMessage();
	}
	/**
	* Terminal teardown. Unregisters the Service Worker, tears down the channel,
	* and clears timers. Called when the singleton is being replaced with one
	* that has different options. The instance is not usable afterwards.
	*/
	async terminate() {
		if (this.#keepAliveInterval != null) {
			clearInterval(this.#keepAliveInterval);
			this.#keepAliveInterval = void 0;
		}
		this.#frames.clear();
		this.#channel.terminate();
		this.#listenerController?.abort();
		this.#listenerController = void 0;
		if (this.#workerState === "fulfilled") {
			const [, registration] = await this.workerPromise;
			await registration.unregister();
		}
		if (ServiceWorkerSource.#current === this) ServiceWorkerSource.#current = void 0;
	}
	async #startWorker() {
		if (this.#keepAliveInterval) clearInterval(this.#keepAliveInterval);
		const workerUrl = this.#options.serviceWorker.url;
		const [worker, registration] = await getWorkerInstance(workerUrl, this.#options.serviceWorker.options, this.#options.findWorker || this.#defaultFindWorker);
		if (worker == null) {
			const missingWorkerMessage = this.#options?.findWorker ? devUtils.formatMessage(`Failed to locate the Service Worker registration using a custom "findWorker" predicate.

Please ensure that the custom predicate properly locates the Service Worker registration at "%s".
More details: https://mswjs.io/docs/api/setup-worker/start#findworker
     `, workerUrl) : devUtils.formatMessage(`Failed to locate the Service Worker registration.

This most likely means that the worker script URL "%s" cannot resolve against the actual public hostname (%s). This may happen if your application runs behind a proxy, or has a dynamic hostname.

Please consider using a custom "serviceWorker.url" option to point to the actual worker script location, or a custom "findWorker" option to resolve the Service Worker registration manually. More details: https://mswjs.io/docs/api/setup-worker/start`, workerUrl, location.host);
			throw new Error(missingWorkerMessage);
		}
		if (this.#workerState === "pending") {
			this.#workerResolvers.resolve([worker, registration]);
			this.#workerState = "fulfilled";
		} else {
			/**
			* @note Re-enable after `stop()`: the previous `workerPromise` is already
			* fulfilled and cannot be resolved again. Swap in a pre-resolved one so
			* `getWorker()` sees the new worker instance immediately.
			*/
			this.#workerResolvers = Promise.withResolvers();
			this.#workerResolvers.resolve([worker, registration]);
			this.workerPromise = this.#workerResolvers.promise;
		}
		this.#channel.on("REQUEST", this.#handleRequest.bind(this));
		this.#channel.on("RESPONSE", this.#handleResponse.bind(this));
		this.#channel.on("REQUEST_ERROR", this.#handleRequestError.bind(this));
		window.addEventListener("pagehide", (event) => {
			if (event.persisted) return;
			if (worker.state !== "redundant") this.#channel.postMessage("CLIENT_CLOSE");
			clearInterval(this.#keepAliveInterval);
			window.postMessage({ type: "msw/worker:stop" });
		}, { signal: this.#listenerController?.signal });
		await this.#checkWorkerIntegrity().catch((error) => {
			devUtils.error("Error while checking the worker script integrity. Please report this on GitHub (https://github.com/mswjs/msw/issues) and include the original error below.");
			console.error(error);
		});
		this.#keepAliveInterval = window.setInterval(() => {
			this.#channel.postMessage("KEEPALIVE_REQUEST");
		}, 5e3);
		if (!this.#context?.quiet) validateWorkerScope(registration);
		return [worker, registration];
	}
	async #handleRequest(event) {
		const request = deserializeRequest(event.data);
		RequestHandler.cache.set(request, request.clone());
		const frame = new ServiceWorkerHttpNetworkFrame({
			event,
			request
		});
		this.#frames.set(event.data.id, frame);
		await this.queue(frame);
	}
	async #handleResponse(event) {
		const { request, response, isMockedResponse } = event.data;
		const frame = this.#frames.get(request.id);
		/**
		* CORS requests with `mode: "no-cors"` result in "opaque" responses.
		* That kind of responses cannot be manipulated in JavaScript due
		* to the security considerations.
		* @see https://fetch.spec.whatwg.org/#concept-filtered-response-opaque
		* @see https://github.com/mswjs/msw/issues/529
		*/
		if (response.type?.includes("opaque")) {
			this.#frames.delete(request.id);
			frame?.events.removeAllListeners();
			return;
		}
		this.#frames.delete(request.id);
		/**
		* @note A request frame will be missing in case of passthrough after the worker is stopped.
		* Creating a frame is costly so it's better to handle it as an edge case here.
		*/
		if (frame == null) return;
		const fetchRequest = deserializeRequest(request);
		const fetchResponse = response.status === 0 ? Response.error() : new FetchResponse(
			/**
			* Responses may be streams here, but when we create a response object
			* with null-body status codes, like 204, 205, 304 Response will
			* throw when passed a non-null body, so ensure it's null here
			* for those codes
			*/
			FetchResponse.isResponseWithBody(response.status) ? response.body : null,
			{
				...response,
				/**
				* Set response URL if it's not set already.
				* @see https://github.com/mswjs/msw/issues/2030
				* @see https://developer.mozilla.org/en-US/docs/Web/API/Response/url
				*/
				url: request.url
			}
		);
		try {
			frame.events.emit(new ResponseEvent(isMockedResponse ? "response:mocked" : "response:bypass", {
				requestId: frame.data.id,
				request: fetchRequest,
				response: fetchResponse,
				isMockedResponse
			}));
		} finally {
			frame.events.removeAllListeners();
		}
	}
	/**
	* @note A request can settle without ever producing a response
	* (e.g. a passthrough request failing with a network error).
	* The worker never sends the "RESPONSE" message for such requests,
	* so the frame must be released here to prevent it from being retained.
	* No "response:*" event is emitted, consistent with the Node.js source.
	* @see https://github.com/mswjs/msw/issues/2792
	*/
	#handleRequestError(event) {
		const { request } = event.data;
		const frame = this.#frames.get(request.id);
		this.#frames.delete(request.id);
		frame?.events.removeAllListeners();
	}
	#defaultFindWorker = (workerUrl, mockServiceWorkerUrl) => {
		return workerUrl === mockServiceWorkerUrl;
	};
	async #checkWorkerIntegrity() {
		const integrityCheckPromise = Promise.withResolvers();
		this.#channel.postMessage("INTEGRITY_CHECK_REQUEST");
		this.#channel.once("INTEGRITY_CHECK_RESPONSE", (event) => {
			const { checksum, packageVersion } = event.data;
			if (checksum !== "5cd5cf8b54c3a90f82960cedcd637772") devUtils.warn(`The currently registered Service Worker has been generated by a different version of MSW (${packageVersion}) and may not be fully compatible with the installed version.

It's recommended you update your worker script by running this command:

  \u2022 npx msw init <PUBLIC_DIR>

You can also automate this process and make the worker script update automatically upon the library installations. Read more: https://mswjs.io/docs/cli/init.`);
			integrityCheckPromise.resolve();
		});
		return integrityCheckPromise.promise;
	}
	async #printStartMessage() {
		if (this.#workerState === "rejected") return;
		invariant(this.#clientPromise != null, "[ServiceWorkerSource] Failed to print a start message: client confirmation not received");
		const client = await this.#clientPromise;
		const [worker, registration] = await this.workerPromise;
		console.groupCollapsed(`%c${devUtils.formatMessage("Mocking enabled.")}`, "color:orangered;font-weight:bold;");
		console.log("%cDocumentation: %chttps://mswjs.io/docs", "font-weight:bold", "font-weight:normal");
		console.log("Found an issue? https://github.com/mswjs/msw/issues");
		console.log("Worker script URL:", worker.scriptURL);
		console.log("Worker scope:", registration.scope);
		if (client) console.log("Client ID: %s (%s)", client.id, client.frameType);
		console.groupEnd();
	}
	#printStopMessage() {
		console.log(`%c${devUtils.formatMessage("Mocking disabled.")}`, "color:orangered;font-weight:bold;");
	}
};
var ServiceWorkerHttpNetworkFrame = class extends HttpNetworkFrame {
	#event;
	constructor(options) {
		super({ request: options.request });
		this.#event = options.event;
	}
	passthrough() {
		this.#event.postMessage("PASSTHROUGH", { request: { headers: Array.from(this.data.request.headers) } });
	}
	respondWith(response) {
		if (response) this.#respondWith(response);
	}
	errorWith(reason) {
		if (reason instanceof Response) return this.respondWith(reason);
		devUtils.warn(`Uncaught exception in the request handler for "%s %s". This exception has been gracefully handled as a 500 response, however, it's strongly recommended to resolve this error, as it indicates a mistake in your code. If you wish to mock an error response, please see this guide: https://mswjs.io/docs/http/mocking-responses/error-responses`, this.data.request.method, this.data.request.url);
		const error = reason instanceof Error ? reason : new Error(reason?.toString() || "Request failure");
		this.respondWith(HttpResponse.json({
			name: error.name,
			message: error.message,
			stack: error.stack
		}, {
			status: 500,
			statusText: "Request Handler Error"
		}));
	}
	async #respondWith(response) {
		let responseBody;
		let transfer;
		const responseInit = toResponseInit(response);
		if (supportsReadableStreamTransfer()) {
			responseBody = response.body;
			transfer = response.body == null ? void 0 : [response.body];
		} else responseBody = response.body == null ? null : await response.clone().arrayBuffer();
		this.#event.postMessage("MOCK_RESPONSE", {
			...responseInit,
			body: responseBody
		}, transfer);
	}
};
var FallbackHttpSource = class extends InterceptorSource {
	/**
	* The resolved context of the network this source was last enabled with.
	*/
	#context;
	constructor() {
		super({ interceptors: [new XMLHttpRequestInterceptor(), new FetchInterceptor()] });
	}
	enable(context) {
		this.#context = context;
		super.enable();
		if (!this.#context?.quiet) this.#printStartMessage();
	}
	disable() {
		super.disable();
		if (!this.#context?.quiet) this.#printStopMessage();
	}
	#printStartMessage() {
		console.groupCollapsed(`%c${devUtils.formatMessage("Mocking enabled (fallback mode).")}`, "color:orangered;font-weight:bold;");
		console.log("%cDocumentation: %chttps://mswjs.io/docs", "font-weight:bold", "font-weight:normal");
		console.log("Found an issue? https://github.com/mswjs/msw/issues");
		console.groupEnd();
	}
	#printStopMessage() {
		console.log(`%c${devUtils.formatMessage("Mocking disabled.")}`, "color:orangered;font-weight:bold;");
	}
};
var DEFAULT_WORKER_URL = "/mockServiceWorker.js";
/**
* Sets up a requests interception in the browser with the given request handlers.
* @param {Array<AnyHandler>} handlers List of request handlers.
*
* @see {@link https://mswjs.io/docs/api/setup-worker `setupWorker()` API reference}
*/
function setupWorker(...handlers) {
	invariant(!isNodeProcess(), devUtils.formatMessage("Failed to execute `setupWorker` in a non-browser environment"));
	const network = defineNetwork({
		sources: [],
		handlers
	});
	return {
		get readyState() {
			return network.readyState;
		},
		async start(options) {
			invariant(network.readyState === 0, devUtils.formatMessage("Failed to call \"worker.start()\": the worker is already started. Remove the redundant \"worker.start()\" call."));
			const httpSource = supportsServiceWorker() ? await ServiceWorkerSource.from({
				serviceWorker: {
					url: options?.serviceWorker?.url?.toString() || DEFAULT_WORKER_URL,
					options: options?.serviceWorker?.options
				},
				findWorker: options?.findWorker
			}) : new FallbackHttpSource();
			network.configure({
				sources: [httpSource, new InterceptorSource({ interceptors: [new WebSocketInterceptor()] })],
				onUnhandledFrame: options?.onUnhandledFrame ?? "warn",
				context: { quiet: options?.quiet }
			});
			await network.enable();
			if (httpSource instanceof ServiceWorkerSource) {
				const [, registration] = await httpSource.workerPromise;
				return registration;
			}
		},
		async stop() {
			await network.disable();
			window.postMessage({ type: "msw/worker:stop" });
		},
		events: network.events,
		use: network.use.bind(network),
		resetHandlers: network.resetHandlers.bind(network),
		restoreHandlers: network.restoreHandlers.bind(network),
		listHandlers: network.listHandlers.bind(network)
	};
}
function createDefaultNetworkOptions(workerUrl = "/mockServiceWorker.js") {
	return {
		sources: [supportsServiceWorker() ? new ServiceWorkerSource({ serviceWorker: { url: workerUrl } }) : new FallbackHttpSource(), new InterceptorSource({ interceptors: [new WebSocketInterceptor()] })],
		onUnhandledFrame: "warn"
	};
}
var defaultNetworkOptions = createDefaultNetworkOptions();
export { createDefaultNetworkOptions, defaultNetworkOptions, setupWorker };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibXN3X2Jyb3dzZXIuanMiLCJuYW1lcyI6WyJ1bnRpbCIsInVudGlsIiwibG9nZ2VyIiwidW50aWwiLCJpc09iamVjdCJdLCJzb3VyY2VzIjpbIi4uLy4uL3VudGlsLWFzeW5jL2xpYi9pbmRleC5qcyIsIi4uLy4uL21zdy9saWIvX2NodW5rcy9pbnRlcmNlcHRvci1zb3VyY2UuanMiLCIuLi8uLi9Ab3Blbi1kcmFmdC91bnRpbC9saWIvaW5kZXguanMiLCIuLi8uLi9AbXN3anMvaW50ZXJjZXB0b3JzL2xpYi9icm93c2VyL2hhbmRsZS1yZXF1ZXN0LXk3YWp5dmU1LmpzIiwiLi4vLi4vQG1zd2pzL2ludGVyY2VwdG9ycy9saWIvYnJvd3Nlci93ZWItQlJCUTNZUHAuanMiLCIuLi8uLi9AbXN3anMvaW50ZXJjZXB0b3JzL2xpYi9icm93c2VyL3dlYi1DQ0xFUlNaRi5qcyIsIi4uLy4uL21zdy9saWIvYnJvd3Nlci9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyNyZWdpb24gc3JjL2luZGV4LnRzXG4vKipcbiogR3JhY2VmdWxseSBoYW5kbGVzIGEgY2FsbGJhY2sgdGhhdCByZXR1cm5zIGEgcHJvbWlzZS5cbipcbiogQGV4YW1wbGVcbiogYXdhaXQgdW50aWwoKCkgPT4gUHJvbWlzZS5yZXNvbHZlKDEyMykpXG4qIC8vIFtudWxsLCAxMjNdXG4qXG4qIGF3YWl0IHVudGlsKCgpID0+IFByb21pc2UucmVqZWN0KG5ldyBFcnJvcignT29wcyEnKSkpXG4qIC8vIFtuZXcgRXJyb3IoJ09vcHMhJyksIG51bGxdXG4qL1xuYXN5bmMgZnVuY3Rpb24gdW50aWwoY2FsbGJhY2spIHtcblx0dHJ5IHtcblx0XHRyZXR1cm4gW251bGwsIGF3YWl0IGNhbGxiYWNrKCkuY2F0Y2goKGVycm9yKSA9PiB7XG5cdFx0XHR0aHJvdyBlcnJvcjtcblx0XHR9KV07XG5cdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0cmV0dXJuIFtlcnJvciwgbnVsbF07XG5cdH1cbn1cblxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1bnRpbCB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiaW1wb3J0IHsgYyBhcyBpc1N0cmluZ0VxdWFsLCBkIGFzIGdldFJhd1NldENvb2tpZSwgaCBhcyBkZXZVdGlscywgbSBhcyBJbnRlcm5hbEVycm9yLCByIGFzIHRvUHVibGljVXJsLCB0IGFzIGNvb2tpZVN0b3JlIH0gZnJvbSBcIi4vY29va2llLXN0b3JlLmpzXCI7XG5pbXBvcnQgeyBuIGFzIGdldFNpYmxpbmdIYW5kbGVycywgbyBhcyBrQXV0b0Nvbm5lY3QsIHIgYXMgaXNTaWJsaW5nSGFuZGxlciwgcyBhcyBrQ29ubmVjdCB9IGZyb20gXCIuL2F0dGFjaC1zaWJsaW5nLWhhbmRsZXJzLmpzXCI7XG5pbXBvcnQgeyB0IGFzIGV4ZWN1dGVIYW5kbGVycyB9IGZyb20gXCIuL2V4ZWN1dGUtaGFuZGxlcnMuanNcIjtcbmltcG9ydCB7IGlzUGFzc3Rocm91Z2hSZXNwb25zZSB9IGZyb20gXCIuLi91dGlscy9wYXNzdGhyb3VnaC5qc1wiO1xuaW1wb3J0IHsgaXNDb21tb25Bc3NldFJlcXVlc3QgfSBmcm9tIFwiLi4vdXRpbHMvaXMtY29tbW9uLWFzc2V0LXJlcXVlc3QuanNcIjtcbmltcG9ydCB7IGludmFyaWFudCB9IGZyb20gXCJvdXR2YXJpYW50XCI7XG5pbXBvcnQgeyBCYXRjaEludGVyY2VwdG9yLCBjcmVhdGVSZXF1ZXN0SWQgfSBmcm9tIFwiQG1zd2pzL2ludGVyY2VwdG9yc1wiO1xuaW1wb3J0IHsgRW1pdHRlciwgVHlwZWRFdmVudCB9IGZyb20gXCJyZXR0aW1lXCI7XG5pbXBvcnQgeyB1bnRpbCB9IGZyb20gXCJ1bnRpbC1hc3luY1wiO1xuLy8jcmVnaW9uIHNyYy9jb3JlL2V4cGVyaW1lbnRhbC9zb3VyY2VzL25ldHdvcmstc291cmNlLnRzXG52YXIgTmV0d29ya0ZyYW1lRXZlbnQgPSBjbGFzcyBleHRlbmRzIFR5cGVkRXZlbnQge1xuXHRmcmFtZTtcblx0Y29uc3RydWN0b3IodHlwZSwgZnJhbWUpIHtcblx0XHRzdXBlciguLi5bdHlwZSwge31dKTtcblx0XHR0aGlzLmZyYW1lID0gZnJhbWU7XG5cdH1cbn07XG52YXIgTmV0d29ya1NvdXJjZSA9IGNsYXNzIHtcblx0ZW1pdHRlcjtcblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0dGhpcy5lbWl0dGVyID0gbmV3IEVtaXR0ZXIoKTtcblx0fVxuXHRhc3luYyBxdWV1ZShmcmFtZSkge1xuXHRcdGF3YWl0IHRoaXMuZW1pdHRlci5lbWl0QXNQcm9taXNlKG5ldyBOZXR3b3JrRnJhbWVFdmVudChcImZyYW1lXCIsIGZyYW1lKSk7XG5cdH1cblx0b24odHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpIHtcblx0XHR0aGlzLmVtaXR0ZXIub24odHlwZSwgbGlzdGVuZXIsIG9wdGlvbnMpO1xuXHR9XG5cdGRpc2FibGUoKSB7XG5cdFx0dGhpcy5lbWl0dGVyLnJlbW92ZUFsbExpc3RlbmVycygpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvZXhwZXJpbWVudGFsL2hhbmRsZXJzLWNvbnRyb2xsZXIudHNcbmZ1bmN0aW9uIGFkZEhhbmRsZXJUb0dyb3VwKGdyb3Vwcywga2luZCwgaGFuZGxlcikge1xuXHQoZ3JvdXBzW2tpbmRdIHx8PSBbXSkucHVzaChoYW5kbGVyKTtcbn1cbmZ1bmN0aW9uIHByZXBlbmRIYW5kbGVyc1RvR3JvdXAoZ3JvdXBzLCBraW5kLCBvdmVycmlkZXNGb3JLaW5kKSB7XG5cdGNvbnN0IGV4aXN0aW5nRm9yS2luZCA9IGdyb3Vwc1traW5kXTtcblx0Z3JvdXBzW2tpbmRdID0gZXhpc3RpbmdGb3JLaW5kID8gWy4uLm92ZXJyaWRlc0ZvcktpbmQsIC4uLmV4aXN0aW5nRm9yS2luZC5maWx0ZXIoKGV4aXN0aW5nSGFuZGxlcikgPT4ge1xuXHRcdHJldHVybiAhb3ZlcnJpZGVzRm9yS2luZC5pbmNsdWRlcyhleGlzdGluZ0hhbmRsZXIpO1xuXHR9KV0gOiBvdmVycmlkZXNGb3JLaW5kO1xufVxuZnVuY3Rpb24gZ3JvdXBIYW5kbGVyc0J5S2luZChoYW5kbGVycykge1xuXHRjb25zdCBncm91cHMgPSB7fTtcblx0Y29uc3QgdmlzaXRlZEhhbmRsZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0Y29uc3QgdmlzaXQgPSAoaGFuZGxlcikgPT4ge1xuXHRcdGlmICh2aXNpdGVkSGFuZGxlcnMuaGFzKGhhbmRsZXIpKSByZXR1cm47XG5cdFx0dmlzaXRlZEhhbmRsZXJzLmFkZChoYW5kbGVyKTtcblx0XHRhZGRIYW5kbGVyVG9Hcm91cChncm91cHMsIGhhbmRsZXIua2luZCwgaGFuZGxlcik7XG5cdFx0Zm9yIChjb25zdCBzaWJsaW5nIG9mIGdldFNpYmxpbmdIYW5kbGVycyhoYW5kbGVyKSkgdmlzaXQoc2libGluZyk7XG5cdH07XG5cdGZvciAoY29uc3QgaGFuZGxlciBvZiBoYW5kbGVycykgdmlzaXQoaGFuZGxlcik7XG5cdHJldHVybiBncm91cHM7XG59XG52YXIgSGFuZGxlcnNDb250cm9sbGVyID0gY2xhc3Mge1xuXHRnZXRJbml0aWFsU3RhdGUoaW5pdGlhbEhhbmRsZXJzKSB7XG5cdFx0aW52YXJpYW50KHRoaXMuI3ZhbGlkYXRlSGFuZGxlcnMoaW5pdGlhbEhhbmRsZXJzKSwgZGV2VXRpbHMuZm9ybWF0TWVzc2FnZShcIkZhaWxlZCB0byBhcHBseSBnaXZlbiByZXF1ZXN0IGhhbmRsZXJzOiBpbnZhbGlkIGlucHV0LiBEaWQgeW91IGZvcmdldCB0byBzcHJlYWQgdGhlIHJlcXVlc3QgaGFuZGxlcnMgQXJyYXk/XCIpKTtcblx0XHRjb25zdCBub3JtYWxpemVkSW5pdGlhbEhhbmRsZXJzID0gZ3JvdXBIYW5kbGVyc0J5S2luZChpbml0aWFsSGFuZGxlcnMpO1xuXHRcdHJldHVybiB7XG5cdFx0XHRpbml0aWFsSGFuZGxlcnM6IG5vcm1hbGl6ZWRJbml0aWFsSGFuZGxlcnMsXG5cdFx0XHRoYW5kbGVyczogeyAuLi5ub3JtYWxpemVkSW5pdGlhbEhhbmRsZXJzIH1cblx0XHR9O1xuXHR9XG5cdGN1cnJlbnRIYW5kbGVycygpIHtcblx0XHRyZXR1cm4gT2JqZWN0LnZhbHVlcyh0aGlzLmdldFN0YXRlKCkuaGFuZGxlcnMpLmZsYXQoKS5maWx0ZXIoKGhhbmRsZXIpID0+IGhhbmRsZXIgIT0gbnVsbCk7XG5cdH1cblx0LyoqXG5cdCogUmV0dXJuIHRoZSBsaXN0IG9mIGV4cGxpY2l0bHkgcmVnaXN0ZXJlZCBoYW5kbGVycy5cblx0KiBVbmxpa2UgYGN1cnJlbnRIYW5kbGVycygpYCwgdGhpcyBleGNsdWRlcyBzaWJsaW5nIGhhbmRsZXJzLFxuXHQqIHdoaWNoIGFyZSBhbiBpbXBsZW1lbnRhdGlvbiBkZXRhaWwgKGUuZy4gdGhlIFdlYlNvY2tldCB1cGdyYWRlXG5cdCogaGFuZGxlciBvciB0aGUgR3JhcGhRTCBzdWJzY3JpcHRpb24gdHJhbnNwb3J0KS5cblx0Ki9cblx0bGlzdEhhbmRsZXJzKCkge1xuXHRcdHJldHVybiB0aGlzLmN1cnJlbnRIYW5kbGVycygpLmZpbHRlcigoaGFuZGxlcikgPT4ge1xuXHRcdFx0cmV0dXJuICFpc1NpYmxpbmdIYW5kbGVyKGhhbmRsZXIpO1xuXHRcdH0pO1xuXHR9XG5cdC8qKlxuXHQqIFJldHVybiB0aGUgbGlzdCBvZiBoYW5kbGVycyBvZiB0aGUgZ2l2ZW4ga2luZC5cblx0Ki9cblx0Z2V0SGFuZGxlcnNCeUtpbmQoa2luZCkge1xuXHRcdHJldHVybiB0aGlzLmdldFN0YXRlKCkuaGFuZGxlcnNba2luZF0gfHwgW107XG5cdH1cblx0dXNlKG5leHRIYW5kbGVycykge1xuXHRcdGludmFyaWFudCh0aGlzLiN2YWxpZGF0ZUhhbmRsZXJzKG5leHRIYW5kbGVycyksIGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoXCJbTVNXXSBGYWlsZWQgdG8gY2FsbCBcXFwidXNlKClcXFwiIHdpdGggdGhlIGdpdmVuIHJlcXVlc3QgaGFuZGxlcnM6IGludmFsaWQgaW5wdXQuIERpZCB5b3UgZm9yZ2V0IHRvIHNwcmVhZCB0aGUgYXJyYXkgb2YgcmVxdWVzdCBoYW5kbGVycz9cIikpO1xuXHRcdGlmIChuZXh0SGFuZGxlcnMubGVuZ3RoID09PSAwKSByZXR1cm47XG5cdFx0Y29uc3QgeyBoYW5kbGVycyB9ID0gdGhpcy5nZXRTdGF0ZSgpO1xuXHRcdGNvbnN0IG92ZXJyaWRlcyA9IGdyb3VwSGFuZGxlcnNCeUtpbmQobmV4dEhhbmRsZXJzKTtcblx0XHRpZiAob3ZlcnJpZGVzLnJlcXVlc3QpIHByZXBlbmRIYW5kbGVyc1RvR3JvdXAoaGFuZGxlcnMsIFwicmVxdWVzdFwiLCBvdmVycmlkZXMucmVxdWVzdCk7XG5cdFx0aWYgKG92ZXJyaWRlcy53ZWJzb2NrZXQpIHByZXBlbmRIYW5kbGVyc1RvR3JvdXAoaGFuZGxlcnMsIFwid2Vic29ja2V0XCIsIG92ZXJyaWRlcy53ZWJzb2NrZXQpO1xuXHRcdHRoaXMuc2V0U3RhdGUoeyBoYW5kbGVycyB9KTtcblx0fVxuXHRyZXNldChuZXh0SGFuZGxlcnMpIHtcblx0XHRpbnZhcmlhbnQobmV4dEhhbmRsZXJzLmxlbmd0aCA+IDAgPyB0aGlzLiN2YWxpZGF0ZUhhbmRsZXJzKG5leHRIYW5kbGVycykgOiB0cnVlLCBkZXZVdGlscy5mb3JtYXRNZXNzYWdlKFwiRmFpbGVkIHRvIHJlcGxhY2UgaW5pdGlhbCBoYW5kbGVycyBkdXJpbmcgcmVzZXQ6IGludmFsaWQgaGFuZGxlcnMuIERpZCB5b3UgZm9yZ2V0IHRvIHNwcmVhZCB0aGUgaGFuZGxlcnMgYXJyYXk/XCIpKTtcblx0XHRjb25zdCB7IGluaXRpYWxIYW5kbGVycyB9ID0gdGhpcy5nZXRTdGF0ZSgpO1xuXHRcdGNvbnN0IG5leHRJbml0aWFsSGFuZGxlcnMgPSBuZXh0SGFuZGxlcnMubGVuZ3RoID4gMCA/IGdyb3VwSGFuZGxlcnNCeUtpbmQobmV4dEhhbmRsZXJzKSA6IGluaXRpYWxIYW5kbGVycztcblx0XHRjb25zdCBjdXJyZW50SGFuZGxlcnMgPSBuZXcgU2V0KHRoaXMuY3VycmVudEhhbmRsZXJzKCkpO1xuXHRcdGNvbnN0IG5leHRIYW5kbGVyc1NldCA9IG5ldyBTZXQoT2JqZWN0LnZhbHVlcyhuZXh0SW5pdGlhbEhhbmRsZXJzKS5mbGF0KCkuZmlsdGVyKEJvb2xlYW4pKTtcblx0XHRmb3IgKGNvbnN0IGhhbmRsZXIgb2YgY3VycmVudEhhbmRsZXJzLmludGVyc2VjdGlvbihuZXh0SGFuZGxlcnNTZXQpKSBoYW5kbGVyLnJlc2V0KCk7XG5cdFx0Zm9yIChjb25zdCBoYW5kbGVyIG9mIGN1cnJlbnRIYW5kbGVycy5kaWZmZXJlbmNlKG5leHRIYW5kbGVyc1NldCkpIHRyeSB7XG5cdFx0XHRjb25zdCBkaXNwb3NhbCA9IGhhbmRsZXIuZGlzcG9zZSgpO1xuXHRcdFx0aWYgKGRpc3Bvc2FsIGluc3RhbmNlb2YgUHJvbWlzZSkgZGlzcG9zYWwuY2F0Y2goKGVycm9yKSA9PiB7XG5cdFx0XHRcdHRoaXMuI3ByaW50RGlzcG9zYWxFcnJvcihoYW5kbGVyLCBlcnJvcik7XG5cdFx0XHR9KTtcblx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0dGhpcy4jcHJpbnREaXNwb3NhbEVycm9yKGhhbmRsZXIsIGVycm9yKTtcblx0XHR9XG5cdFx0aWYgKG5leHRIYW5kbGVycy5sZW5ndGggPT09IDApIHtcblx0XHRcdHRoaXMuc2V0U3RhdGUoeyBoYW5kbGVyczogeyAuLi5pbml0aWFsSGFuZGxlcnMgfSB9KTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0dGhpcy5zZXRTdGF0ZSh7XG5cdFx0XHRpbml0aWFsSGFuZGxlcnM6IG5leHRJbml0aWFsSGFuZGxlcnMsXG5cdFx0XHRoYW5kbGVyczogeyAuLi5uZXh0SW5pdGlhbEhhbmRsZXJzIH1cblx0XHR9KTtcblx0fVxuXHRyZXN0b3JlKCkge1xuXHRcdGZvciAoY29uc3QgaGFuZGxlciBvZiB0aGlzLmN1cnJlbnRIYW5kbGVycygpKSBoYW5kbGVyLnJlc3RvcmUoKTtcblx0fVxuXHRkaXNwb3NlKCkge1xuXHRcdGNvbnN0IHBlbmRpbmdEaXNwb3NhbHMgPSBbXTtcblx0XHRmb3IgKGNvbnN0IGhhbmRsZXIgb2YgdGhpcy5jdXJyZW50SGFuZGxlcnMoKSkge1xuXHRcdFx0Y29uc3QgZGlzcG9zYWwgPSBoYW5kbGVyLmRpc3Bvc2UoKTtcblx0XHRcdGlmIChkaXNwb3NhbCBpbnN0YW5jZW9mIFByb21pc2UpIHBlbmRpbmdEaXNwb3NhbHMucHVzaChkaXNwb3NhbCk7XG5cdFx0fVxuXHRcdGlmIChwZW5kaW5nRGlzcG9zYWxzLmxlbmd0aCA+IDApIHJldHVybiBQcm9taXNlLmFsbChwZW5kaW5nRGlzcG9zYWxzKS50aGVuKCgpID0+IHt9KTtcblx0fVxuXHQjdmFsaWRhdGVIYW5kbGVycyhoYW5kbGVycykge1xuXHRcdHJldHVybiBoYW5kbGVycy5ldmVyeSgoaGFuZGxlcikgPT4gIUFycmF5LmlzQXJyYXkoaGFuZGxlcikpO1xuXHR9XG5cdCNwcmludERpc3Bvc2FsRXJyb3IoaGFuZGxlciwgZXJyb3IpIHtcblx0XHRkZXZVdGlscy5lcnJvcihcIkZhaWxlZCB0byBkaXNwb3NlIG9mIFxcXCIlc1xcXCIgaGFuZGxlciByZW1vdmVkIGR1cmluZyByZXNldC4gUGxlYXNlIHNlZSB0aGUgb3JpZ2luYWwgZXJyb3IgYmVsb3cuXFxuJXNcIiwgaGFuZGxlci5raW5kLCBlcnJvcik7XG5cdH1cbn07XG52YXIgSW5NZW1vcnlIYW5kbGVyc0NvbnRyb2xsZXIgPSBjbGFzcyBleHRlbmRzIEhhbmRsZXJzQ29udHJvbGxlciB7XG5cdCNoYW5kbGVycztcblx0I2luaXRpYWxIYW5kbGVycztcblx0Y29uc3RydWN0b3IoaW5pdGlhbEhhbmRsZXJzKSB7XG5cdFx0c3VwZXIoKTtcblx0XHRjb25zdCBpbml0aWFsU3RhdGUgPSB0aGlzLmdldEluaXRpYWxTdGF0ZShpbml0aWFsSGFuZGxlcnMpO1xuXHRcdHRoaXMuI2luaXRpYWxIYW5kbGVycyA9IGluaXRpYWxTdGF0ZS5pbml0aWFsSGFuZGxlcnM7XG5cdFx0dGhpcy4jaGFuZGxlcnMgPSBpbml0aWFsU3RhdGUuaGFuZGxlcnM7XG5cdH1cblx0Z2V0U3RhdGUoKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdGluaXRpYWxIYW5kbGVyczogdGhpcy4jaW5pdGlhbEhhbmRsZXJzLFxuXHRcdFx0aGFuZGxlcnM6IHRoaXMuI2hhbmRsZXJzXG5cdFx0fTtcblx0fVxuXHRzZXRTdGF0ZShuZXh0U3RhdGUpIHtcblx0XHRpZiAobmV4dFN0YXRlLmluaXRpYWxIYW5kbGVycykgdGhpcy4jaW5pdGlhbEhhbmRsZXJzID0gbmV4dFN0YXRlLmluaXRpYWxIYW5kbGVycztcblx0XHRpZiAobmV4dFN0YXRlLmhhbmRsZXJzKSB0aGlzLiNoYW5kbGVycyA9IG5leHRTdGF0ZS5oYW5kbGVycztcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3V0aWxzL2ludGVybmFsL3RvLXJlYWRvbmx5LWFycmF5LnRzXG4vKipcbiogQ3JlYXRlcyBhbiBpbW11dGFibGUgY29weSBvZiB0aGUgZ2l2ZW4gYXJyYXkuXG4qL1xuZnVuY3Rpb24gdG9SZWFkb25seUFycmF5KHNvdXJjZSkge1xuXHRjb25zdCBjbG9uZSA9IFsuLi5zb3VyY2VdO1xuXHRPYmplY3QuZnJlZXplKGNsb25lKTtcblx0cmV0dXJuIGNsb25lO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvdXRpbHMvaW50ZXJuYWwvZGlzcG9zYWJsZS50c1xudmFyIERpc3Bvc2FibGUgPSBjbGFzcyB7XG5cdHN1YnNjcmlwdGlvbnMgPSBbXTtcblx0ZGlzcG9zZSgpIHtcblx0XHRsZXQgc3Vic2NyaXB0aW9uO1xuXHRcdGNvbnN0IGVycm9ycyA9IFtdO1xuXHRcdHdoaWxlIChzdWJzY3JpcHRpb24gPSB0aGlzLnN1YnNjcmlwdGlvbnMuc2hpZnQoKSkgdHJ5IHtcblx0XHRcdHN1YnNjcmlwdGlvbigpO1xuXHRcdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0XHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikgZXJyb3JzLnB1c2goZXJyb3IpO1xuXHRcdH1cblx0XHRpZiAoZXJyb3JzLmxlbmd0aCA+IDApIGNvbnNvbGUuZXJyb3IobmV3IEFnZ3JlZ2F0ZUVycm9yKGVycm9ycywgZGV2VXRpbHMuZm9ybWF0TWVzc2FnZShcIkZhaWxlZCB0byBkaXNwb3NlIG9mIHNvbWUgc2lkZSBlZmZlY3RzLiBUaGlzIGlzIGxpa2VseSBhbiBpc3N1ZSB3aXRoIE1TVywgcGxlYXNlIHJlcG9ydCBpdCBvbiBHaXRIdWI6IGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9tc3cvaXNzdWVzXCIpKSk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9leHBlcmltZW50YWwvZGVmaW5lLW5ldHdvcmsudHNcbmZ1bmN0aW9uIGNvbG9ybGVzc1Byb21pc2VBbGwodmFsdWVzKSB7XG5cdGNvbnN0IHByb21pc2VzID0gW107XG5cdGZvciAoY29uc3QgdmFsdWUgb2YgdmFsdWVzKSBpZiAodmFsdWUgaW5zdGFuY2VvZiBQcm9taXNlKSBwcm9taXNlcy5wdXNoKHZhbHVlKTtcblx0aWYgKHByb21pc2VzLmxlbmd0aCA+IDApIHJldHVybiBQcm9taXNlLmFsbChwcm9taXNlcykudGhlbigoKSA9PiB7fSk7XG59XG5sZXQgTmV0d29ya1JlYWR5U3RhdGUgPSAvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oTmV0d29ya1JlYWR5U3RhdGUpIHtcblx0TmV0d29ya1JlYWR5U3RhdGVbTmV0d29ya1JlYWR5U3RhdGVbXCJESVNBQkxFRFwiXSA9IDBdID0gXCJESVNBQkxFRFwiO1xuXHROZXR3b3JrUmVhZHlTdGF0ZVtOZXR3b3JrUmVhZHlTdGF0ZVtcIkVOQUJMRURcIl0gPSAxXSA9IFwiRU5BQkxFRFwiO1xuXHRyZXR1cm4gTmV0d29ya1JlYWR5U3RhdGU7XG59KHt9KTtcbi8qKlxuKiBEZWZpbmUgYSBuZXR3b3JrIGluc3RhbmNlIHdpdGggdGhlIGdpdmVuIGNvbmZpZ3VyYXRpb24uXG4qIEBleGFtcGxlXG4qIGltcG9ydCB7IEludGVyY2VwdG9yU291cmNlIH0gZnJvbSAnbXN3L2V4cGVyaW1lbnRhbCdcbiogaW1wb3J0IHsgaGFuZGxlcnMgfSBmcm9tICcuL2hhbmRsZXJzJ1xuKlxuKiBjb25zdCBuZXR3b3JrID0gZGVmaW5lTmV0d29yayh7XG4qICAgc291cmNlczogW25ldyBJbnRlcmNlcHRvclNvdXJjZSh7IGludGVyY2VwdG9ycyB9KV0sXG4qICAgaGFuZGxlcnMsXG4qIH0pXG4qIGF3YWl0IG5ldHdvcmsuZW5hYmxlKClcbiovXG5mdW5jdGlvbiBkZWZpbmVOZXR3b3JrKG9wdGlvbnMpIHtcblx0bGV0IHJlYWR5U3RhdGUgPSAwO1xuXHRjb25zdCBldmVudHMgPSBuZXcgRW1pdHRlcigpO1xuXHRjb25zdCBkaXNwb3NhYmxlID0gbmV3IERpc3Bvc2FibGUoKTtcblx0Y29uc3QgZGVyaXZlSGFuZGxlcnNDb250cm9sbGVyID0gKGhhbmRsZXJzKSA9PiB7XG5cdFx0cmV0dXJuIGhhbmRsZXJzIGluc3RhbmNlb2YgSGFuZGxlcnNDb250cm9sbGVyID8gaGFuZGxlcnMgOiBuZXcgSW5NZW1vcnlIYW5kbGVyc0NvbnRyb2xsZXIoaGFuZGxlcnMgfHwgW10pO1xuXHR9O1xuXHRsZXQgcmVzb2x2ZWRPcHRpb25zID0geyAuLi5vcHRpb25zIH07XG5cdC8qKlxuXHQqIEBub3RlIENyZWF0ZSB0aGUgaGFuZGxlcnMgY29udHJvbGxlciBpbW1lZGlhdGVseSBiZWNhdXNlXG5cdCogY2VydGFpbiBzZXR1cCBBUElzLCBsaWtlIGBzZXR1cFNlcnZlcmAsIGRvbid0IGF3YWl0IGAuZW5hYmxlYCAoYC5saXN0ZW5gKS5cblx0Ki9cblx0bGV0IGhhbmRsZXJzQ29udHJvbGxlciA9IGRlcml2ZUhhbmRsZXJzQ29udHJvbGxlcihyZXNvbHZlZE9wdGlvbnMuaGFuZGxlcnMpO1xuXHRyZXR1cm4ge1xuXHRcdGdldCByZWFkeVN0YXRlKCkge1xuXHRcdFx0cmV0dXJuIHJlYWR5U3RhdGU7XG5cdFx0fSxcblx0XHRldmVudHMsXG5cdFx0Y29uZmlndXJlKG9wdGlvbnMpIHtcblx0XHRcdGludmFyaWFudChyZWFkeVN0YXRlID09PSAwLCBcIkZhaWxlZCB0byBjYWxsIFxcXCJjb25maWd1cmUoKVxcXCIgb24gdGhlIG5ldHdvcms6IGNhbm5vdCBjb25maWd1cmUgYW4gYWxyZWFkeSBlbmFibGVkIG5ldHdvcmsuXCIpO1xuXHRcdFx0aWYgKG9wdGlvbnMuaGFuZGxlcnMgJiYgIU9iamVjdC5pcyhvcHRpb25zLmhhbmRsZXJzLCByZXNvbHZlZE9wdGlvbnMuaGFuZGxlcnMpKSBoYW5kbGVyc0NvbnRyb2xsZXIgPSBkZXJpdmVIYW5kbGVyc0NvbnRyb2xsZXIob3B0aW9ucy5oYW5kbGVycyk7XG5cdFx0XHRyZXNvbHZlZE9wdGlvbnMgPSB7XG5cdFx0XHRcdC4uLnJlc29sdmVkT3B0aW9ucyxcblx0XHRcdFx0Li4ub3B0aW9uc1xuXHRcdFx0fTtcblx0XHR9LFxuXHRcdGVuYWJsZSgpIHtcblx0XHRcdGludmFyaWFudChyZWFkeVN0YXRlID09PSAwLCBcIkZhaWxlZCB0byBjYWxsIFxcXCJlbmFibGVcXFwiIG9uIHRoZSBuZXR3b3JrOiBhbHJlYWR5IGVuYWJsZWRcIik7XG5cdFx0XHRyZWFkeVN0YXRlID0gMTtcblx0XHRcdC8qKlxuXHRcdFx0KiBAbm90ZSBVc2UgYSBzZXNzaW9uIG9iamVjdCBzY29wZWQgdG8gdGhlIGN1cnJlbnQgXCJlbmFibGUoKVwiXG5cdFx0XHQqIHRvIHByZXZlbnQgXCJmcmFtZS5ldmVudHNcIiBsaXN0ZW5lcnMgZnJvbSBzdXJ2aXZpbmcgYWNyb3NzIGVuYWJsZS9kaXNhYmxlIGN5Y2xlcy5cblx0XHRcdCogQHNlZSBUaGUgbm90ZSBhYm91dCBgQWJvcnRDb250cm9sbGVyYCBiZWxvdy5cblx0XHRcdCovXG5cdFx0XHRjb25zdCBzZXNzaW9uID0geyBhY3RpdmU6IHRydWUgfTtcblx0XHRcdGRpc3Bvc2FibGVbXCJzdWJzY3JpcHRpb25zXCJdLnB1c2goKCkgPT4ge1xuXHRcdFx0XHRzZXNzaW9uLmFjdGl2ZSA9IGZhbHNlO1xuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gY29sb3JsZXNzUHJvbWlzZUFsbChyZXNvbHZlZE9wdGlvbnMuc291cmNlcy5tYXAoKHNvdXJjZSkgPT4ge1xuXHRcdFx0XHQvKipcblx0XHRcdFx0KiBAbm90ZSBQcmVlbXB0aXZlbHkgZGlzYWJsZSB0aGUgbmV0d29yayBzb3VyY2UgYmVmb3JlIGVuYWJsaW5nLlxuXHRcdFx0XHQqIFRoaXMgaW50ZW50aW9uYWxseSBjYWxscyBvbmx5IHRoZSBwcm90b3R5cGUgbWV0aG9kIHRoYXQgY2xlYXJzIHRoZVxuXHRcdFx0XHQqIGV2ZW50IGxpc3RlbmVycyBhbmQgbm90aGluZyBlbHNlLiBUaGlzIHByZXZlbnRzIHRoZSBcImZyYW1lXCIgbGlzdGVuZXJzXG5cdFx0XHRcdCogZnJvbSBhY2N1bXVsYXRpbmcgYWNyb3NzIGVuYWJsZS9kaXNhYmxlIGluIGNhc2UgdGhlIHNvdXJjZSBpcyBhIHNpbmdsZXRvbi5cblx0XHRcdFx0Ki9cblx0XHRcdFx0TmV0d29ya1NvdXJjZS5wcm90b3R5cGUuZGlzYWJsZS5jYWxsKHNvdXJjZSk7XG5cdFx0XHRcdHNvdXJjZS5vbihcImZyYW1lXCIsIGFzeW5jICh7IGZyYW1lIH0pID0+IHtcblx0XHRcdFx0XHRmcmFtZS5ldmVudHMub24oXCIqXCIsIChldmVudCkgPT4ge1xuXHRcdFx0XHRcdFx0LyoqXG5cdFx0XHRcdFx0XHQqIEBub3RlIFByZXZlbnQgZXZlbnQgZm9yd2FyZGluZyBtYW51YWxseSBhbmQgbm90IHZpYSBhbiBBYm9ydENvbnRyb2xsZXJcblx0XHRcdFx0XHRcdCogYmVjYXVzZSBjZXJ0YWluIHJ1bnRpbWVzLCBsaWtlIENsb3VkZmxhcmUsIHRocm93IHdoZW4gcmVmZXJlbmNpbmcgYW5cblx0XHRcdFx0XHRcdCogQWJvcnRDb250cm9sbGVyIGNyZWF0ZWQgaW4gYSBkaWZmZXJlbnQgY29udGV4dC4gQmVhciBpbiBtaW5kIHRoYXQgdGhlIGZyYW1lXG5cdFx0XHRcdFx0XHQqIGV2ZW50cyBydW4gaW4gdGhlIHBhdGNoZWQgcmVxdWVzdCBjbGllbnQgY29udGV4dCB3aGlsZSB0aGUgQWJvcnRDb250cm9sbGVyXG5cdFx0XHRcdFx0XHQqIGlzIGNyZWF0ZWQgb3V0c2lkZSwgaW4gdGhlIFwiZGVmaW5lTmV0d29ya1wiIGNsb3N1cmUsIHdoaWNoIGlzIGEgdGVzdCBjb250ZXh0LlxuXHRcdFx0XHRcdFx0Ki9cblx0XHRcdFx0XHRcdGlmICghc2Vzc2lvbi5hY3RpdmUpIHJldHVybjtcblx0XHRcdFx0XHRcdGV2ZW50cy5lbWl0KGV2ZW50KTtcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRjb25zdCBoYW5kbGVycyA9IGZyYW1lLmdldEhhbmRsZXJzKGhhbmRsZXJzQ29udHJvbGxlcik7XG5cdFx0XHRcdFx0YXdhaXQgZnJhbWUucmVzb2x2ZShoYW5kbGVycywgcmVzb2x2ZWRPcHRpb25zLm9uVW5oYW5kbGVkRnJhbWUgfHwgXCJ3YXJuXCIsIHJlc29sdmVkT3B0aW9ucy5jb250ZXh0KTtcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHJldHVybiBzb3VyY2UuZW5hYmxlKHJlc29sdmVkT3B0aW9ucy5jb250ZXh0KTtcblx0XHRcdH0pKTtcblx0XHR9LFxuXHRcdGRpc2FibGUoKSB7XG5cdFx0XHRpbnZhcmlhbnQocmVhZHlTdGF0ZSA9PT0gMSwgXCJGYWlsZWQgdG8gY2FsbCBcXFwiZGlzYWJsZVxcXCIgb24gdGhlIG5ldHdvcms6IGFscmVhZHkgZGlzYWJsZWRcIik7XG5cdFx0XHRyZWFkeVN0YXRlID0gMDtcblx0XHRcdGNvbnN0IGhhbmRsZXJzRGlzcG9zYWwgPSBoYW5kbGVyc0NvbnRyb2xsZXIuZGlzcG9zZSgpO1xuXHRcdFx0ZGlzcG9zYWJsZS5kaXNwb3NlKCk7XG5cdFx0XHQvKipcblx0XHRcdCogQG5vdGUgVGVhciBkb3duIHRoZSBzb3VyY2VzIHN5bmNocm9ub3VzbHksIG5ldmVyIGJlaGluZCB0aGVcblx0XHRcdCogaGFuZGxlcnMgZGlzcG9zYWwuIGBkaXNhYmxlKClgIGlzIG5vdCBhbHdheXMgYXdhaXRlZCAoZS5nLlxuXHRcdFx0KiBgc2VydmVyLmNsb3NlKClgIGlzIHN5bmNocm9ub3VzKSwgYW5kIGEgZGVmZXJyZWQgdGVhcmRvd24gd291bGRcblx0XHRcdCogcmFjZSBhbnkgYGVuYWJsZSgpYCB0aGF0IGZvbGxvd3MsIGRpc2FibGluZyB0aGUgc291cmNlcyB0aGF0IHRoZVxuXHRcdFx0KiBuZXcgc2Vzc2lvbiBoYXMganVzdCBlbmFibGVkLlxuXHRcdFx0Ki9cblx0XHRcdGNvbnN0IHNvdXJjZXNEaXNwb3NhbCA9IGNvbG9ybGVzc1Byb21pc2VBbGwocmVzb2x2ZWRPcHRpb25zLnNvdXJjZXMubWFwKChzb3VyY2UpID0+IHNvdXJjZS5kaXNhYmxlKCkpKTtcblx0XHRcdC8qKlxuXHRcdFx0KiBAbm90ZSBBd2FpdCBib3RoIGRpc3Bvc2FscyBzbyBuZWl0aGVyIHJlamVjdGlvbiBnb2VzIHVub2JzZXJ2ZWQuXG5cdFx0XHQqIENoYWluaW5nIHRoZW0gd291bGQgbGVhdmUgdGhlIHNvdXJjZSBkaXNwb3NhbCBmbG9hdGluZyB3aGVuZXZlclxuXHRcdFx0KiB0aGUgaGFuZGxlcnMgZGlzcG9zYWwgcmVqZWN0cy5cblx0XHRcdCovXG5cdFx0XHRyZXR1cm4gaGFuZGxlcnNEaXNwb3NhbCBpbnN0YW5jZW9mIFByb21pc2UgPyBQcm9taXNlLmFsbChbaGFuZGxlcnNEaXNwb3NhbCwgc291cmNlc0Rpc3Bvc2FsXSkudGhlbigoKSA9PiB7fSkgOiBzb3VyY2VzRGlzcG9zYWw7XG5cdFx0fSxcblx0XHR1c2UoLi4uaGFuZGxlcnMpIHtcblx0XHRcdGhhbmRsZXJzQ29udHJvbGxlci51c2UoaGFuZGxlcnMpO1xuXHRcdH0sXG5cdFx0cmVzZXRIYW5kbGVycyguLi5oYW5kbGVycykge1xuXHRcdFx0aGFuZGxlcnNDb250cm9sbGVyLnJlc2V0KGhhbmRsZXJzKTtcblx0XHR9LFxuXHRcdHJlc3RvcmVIYW5kbGVycygpIHtcblx0XHRcdGhhbmRsZXJzQ29udHJvbGxlci5yZXN0b3JlKCk7XG5cdFx0fSxcblx0XHRsaXN0SGFuZGxlcnMoKSB7XG5cdFx0XHRyZXR1cm4gdG9SZWFkb25seUFycmF5KGhhbmRsZXJzQ29udHJvbGxlci5saXN0SGFuZGxlcnMoKSk7XG5cdFx0fVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvZXhwZXJpbWVudGFsL2ZyYW1lcy9uZXR3b3JrLWZyYW1lLnRzXG4vKipcbiogVGhlIGJhc2UgZm9yIHRoZSBuZXR3b3JrIGZyYW1lcy4gRXh0ZW5kIHRoaXMgYWJzdHJhY3QgY2xhc3NcbiogdG8gaW1wbGVtZW50IGN1c3RvbSBuZXR3b3JrIGZyYW1lcy5cbiovXG52YXIgTmV0d29ya0ZyYW1lID0gY2xhc3Mge1xuXHRwcm90b2NvbDtcblx0ZGF0YTtcblx0ZXZlbnRzO1xuXHRjb25zdHJ1Y3Rvcihwcm90b2NvbCwgZGF0YSkge1xuXHRcdHRoaXMucHJvdG9jb2wgPSBwcm90b2NvbDtcblx0XHR0aGlzLmRhdGEgPSBkYXRhO1xuXHRcdHRoaXMuZXZlbnRzID0gbmV3IEVtaXR0ZXIoKTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL3V0aWxzL3JlcXVlc3Qvc3RvcmUtcmVzcG9uc2UtY29va2llcy50c1xuYXN5bmMgZnVuY3Rpb24gc3RvcmVSZXNwb25zZUNvb2tpZXMocmVxdWVzdCwgcmVzcG9uc2UpIHtcblx0aWYgKGNvb2tpZVN0b3JlID09PSBudWxsKSByZXR1cm47XG5cdGZvciAoY29uc3QgcmVzcG9uc2VDb29raWUgb2YgZ2V0UmF3U2V0Q29va2llKHJlc3BvbnNlKSkgYXdhaXQgY29va2llU3RvcmUuc2V0Q29va2llKHJlc3BvbnNlQ29va2llLCByZXF1ZXN0LnVybCk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS9leHBlcmltZW50YWwvcmVxdWVzdC11dGlscy50c1xuZnVuY3Rpb24gc2hvdWxkQnlwYXNzUmVxdWVzdChyZXF1ZXN0KSB7XG5cdHJldHVybiAhIXJlcXVlc3QuaGVhZGVycy5nZXQoXCJhY2NlcHRcIik/LmluY2x1ZGVzKFwibXN3L3Bhc3N0aHJvdWdoXCIpO1xufVxuLyoqXG4qIFJlbW92ZSB0aGUgaW50ZXJuYWwgcGFzc3Rocm91Z2ggaW5zdHJ1Y3Rpb24gZnJvbSB0aGUgcmVxdWVzdCdzIGBBY2NlcHRgIGhlYWRlci5cbiovXG5mdW5jdGlvbiBkZWxldGVSZXF1ZXN0UGFzc3Rocm91Z2hIZWFkZXIocmVxdWVzdCkge1xuXHRjb25zdCBhY2NlcHRIZWFkZXIgPSByZXF1ZXN0LmhlYWRlcnMuZ2V0KFwiYWNjZXB0XCIpO1xuXHQvKipcblx0KiBAbm90ZSBSZW1vdmUgdGhlIGludGVybmFsIGJ5cGFzcyByZXF1ZXN0IGhlYWRlci5cblx0KiBJbiB0aGUgYnJvd3NlciwgdGhpcyBpcyBkb25lIGJ5IHRoZSB3b3JrZXIgc2NyaXB0LlxuXHQqIEluIE5vZGUuanMsIGl0IGhhcyB0byBiZSBkb25lIGhlcmUuXG5cdCovXG5cdGlmIChhY2NlcHRIZWFkZXIpIHtcblx0XHRjb25zdCBuZXh0QWNjZXB0SGVhZGVyID0gYWNjZXB0SGVhZGVyLnJlcGxhY2UoLygsXFxzKyk/bXN3XFwvcGFzc3Rocm91Z2gvLCBcIlwiKTtcblx0XHRpZiAobmV4dEFjY2VwdEhlYWRlcikgcmVxdWVzdC5oZWFkZXJzLnNldChcImFjY2VwdFwiLCBuZXh0QWNjZXB0SGVhZGVyKTtcblx0XHRlbHNlIHJlcXVlc3QuaGVhZGVycy5kZWxldGUoXCJhY2NlcHRcIik7XG5cdH1cbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2V4cGVyaW1lbnRhbC9vbi11bmhhbmRsZWQtZnJhbWUudHNcbmFzeW5jIGZ1bmN0aW9uIGV4ZWN1dGVVbmhhbmRsZWRGcmFtZUhhbmRsZShmcmFtZSwgaGFuZGxlKSB7XG5cdGNvbnN0IHByaW50U3RyYXRlZ3lNZXNzYWdlID0gYXN5bmMgKHN0cmF0ZWd5KSA9PiB7XG5cdFx0aWYgKHN0cmF0ZWd5ID09PSBcImJ5cGFzc1wiKSByZXR1cm47XG5cdFx0Y29uc3QgbWVzc2FnZSA9IGF3YWl0IGZyYW1lLmdldFVuaGFuZGxlZE1lc3NhZ2UoKTtcblx0XHRzd2l0Y2ggKHN0cmF0ZWd5KSB7XG5cdFx0XHRjYXNlIFwid2FyblwiOiByZXR1cm4gZGV2VXRpbHMud2FybihcIldhcm5pbmc6ICVzXCIsIG1lc3NhZ2UpO1xuXHRcdFx0Y2FzZSBcImVycm9yXCI6IHJldHVybiBkZXZVdGlscy5lcnJvcihcIkVycm9yOiAlc1wiLCBtZXNzYWdlKTtcblx0XHR9XG5cdH07XG5cdGNvbnN0IGFwcGx5U3RyYXRlZ3kgPSBhc3luYyAoc3RyYXRlZ3kpID0+IHtcblx0XHRpbnZhcmlhbnQuYXMoSW50ZXJuYWxFcnJvciwgc3RyYXRlZ3kgPT09IFwiYnlwYXNzXCIgfHwgc3RyYXRlZ3kgPT09IFwid2FyblwiIHx8IHN0cmF0ZWd5ID09PSBcImVycm9yXCIsIGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoXCJGYWlsZWQgdG8gcmVhY3QgdG8gYW4gdW5oYW5kbGVkIG5ldHdvcmsgZnJhbWU6IHVua25vd24gc3RyYXRlZ3kgXFxcIiVzXFxcIi4gUGxlYXNlIHByb3ZpZGUgb25lIG9mIHRoZSBzdXBwb3J0ZWQgc3RyYXRlZ2llcyAoXFxcImJ5cGFzc1xcXCIsIFxcXCJ3YXJuXFxcIiwgXFxcImVycm9yXFxcIikgb3IgYSBjdXN0b20gY2FsbGJhY2sgZnVuY3Rpb24gYXMgdGhlIHZhbHVlIG9mIHRoZSBcXFwib25VbmhhbmRsZWRGcmFtZVxcXCIgb3B0aW9uLlwiLCBzdHJhdGVneSkpO1xuXHRcdGlmIChzdHJhdGVneSA9PT0gXCJieXBhc3NcIikgcmV0dXJuO1xuXHRcdGF3YWl0IHByaW50U3RyYXRlZ3lNZXNzYWdlKHN0cmF0ZWd5KTtcblx0XHRpZiAoc3RyYXRlZ3kgPT09IFwiZXJyb3JcIikgcmV0dXJuIFByb21pc2UucmVqZWN0KG5ldyBJbnRlcm5hbEVycm9yKGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoXCJDYW5ub3QgYnlwYXNzIGEgcmVxdWVzdCB3aGVuIHVzaW5nIHRoZSBcXFwiZXJyb3JcXFwiIHN0cmF0ZWd5IGZvciB0aGUgXFxcIm9uVW5oYW5kbGVkRnJhbWVcXFwiIG9wdGlvbi5cIikpKTtcblx0fTtcblx0aWYgKHR5cGVvZiBoYW5kbGUgPT09IFwiZnVuY3Rpb25cIikgcmV0dXJuIGhhbmRsZSh7XG5cdFx0ZnJhbWUsXG5cdFx0ZGVmYXVsdHM6IHtcblx0XHRcdHdhcm46IHByaW50U3RyYXRlZ3lNZXNzYWdlLmJpbmQobnVsbCwgXCJ3YXJuXCIpLFxuXHRcdFx0LyoqXG5cdFx0XHQqIEBub3RlIFRoZSBkZWZhdWx0cyBvbmx5IHByaW50IHRoZSBjb3JyZXNwb25kaW5nIG1lc3NhZ2VzIG5vdy5cblx0XHRcdCogVGhleSBkbyBub3QgYWZmZWN0IHRoZSBmcmFtZSByZXNvbHV0aW9uIChlLmcuIGRvIG5vdCBlcnJvciB0aGUgZnJhbWUpLlxuXHRcdFx0KiBUaGF0IGlzIG9ubHkgZm9yIGJhY2t3YXJkIGNvbXBhdGliaWxpdHkgcmVhc29ucy4gSW4gdGhlIGZ1dHVyZSwgdGhlc2Ugc2hvdWxkXG5cdFx0XHQqIGJlIGFuIGFsaWFzIHRvIGBhcHBseVN0cmF0ZWd5LmJpbmQobnVsbCwgJ2Vycm9yJylgIGluc3RlYWQuXG5cdFx0XHQqL1xuXHRcdFx0ZXJyb3I6IHByaW50U3RyYXRlZ3lNZXNzYWdlLmJpbmQobnVsbCwgXCJlcnJvclwiKVxuXHRcdH1cblx0fSk7XG5cdC8qKlxuXHQqIElnbm9yZSB1bmhhbmRsZWQgY29tbW9uIEhUVFAgYXNzZXRzLlxuXHQqIEBub3RlIENhbGxpbmcgdGhpcyBoZXJlIGFwcGxpZXMgdGhlIGNvbW1vbiBhc3NldHMgY2hlY2tcblx0KiBvbmx5IHRvIHRoZSBzY2VuYXJpb3Mgd2hlbiBgb25VbmhhbmRsZWRGcmFtZWAgd2FzIHNldCB0byBhIHByZWRlZmluZWQgc3RyYXRlZ3kuXG5cdCogV2hlbiB1c2luZyBhIGN1c3RvbSBmdW5jdGlvbiwgeW91IG5lZWQgdG8gY2hlY2sgZm9yIGNvbW1vbiBhc3NldHMgbWFudWFsbHkuXG5cdCovXG5cdGlmIChmcmFtZSBpbnN0YW5jZW9mIEh0dHBOZXR3b3JrRnJhbWUgJiYgaXNDb21tb25Bc3NldFJlcXVlc3QoZnJhbWUuZGF0YS5yZXF1ZXN0KSkgcmV0dXJuO1xuXHRyZXR1cm4gYXBwbHlTdHJhdGVneShoYW5kbGUpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvZXhwZXJpbWVudGFsL2ZyYW1lcy9odHRwLWZyYW1lLnRzXG52YXIgUmVxdWVzdEV2ZW50ID0gY2xhc3MgZXh0ZW5kcyBUeXBlZEV2ZW50IHtcblx0cmVxdWVzdElkO1xuXHRyZXF1ZXN0O1xuXHRjb25zdHJ1Y3Rvcih0eXBlLCBkYXRhKSB7XG5cdFx0c3VwZXIoLi4uW3R5cGUsIHt9XSk7XG5cdFx0dGhpcy5yZXF1ZXN0SWQgPSBkYXRhLnJlcXVlc3RJZDtcblx0XHR0aGlzLnJlcXVlc3QgPSBkYXRhLnJlcXVlc3Q7XG5cdH1cbn07XG52YXIgUmVzcG9uc2VFdmVudCA9IGNsYXNzIGV4dGVuZHMgVHlwZWRFdmVudCB7XG5cdHJlcXVlc3RJZDtcblx0cmVxdWVzdDtcblx0cmVzcG9uc2U7XG5cdGNvbnN0cnVjdG9yKHR5cGUsIGRhdGEpIHtcblx0XHRzdXBlciguLi5bdHlwZSwge31dKTtcblx0XHR0aGlzLnJlcXVlc3RJZCA9IGRhdGEucmVxdWVzdElkO1xuXHRcdHRoaXMucmVxdWVzdCA9IGRhdGEucmVxdWVzdDtcblx0XHR0aGlzLnJlc3BvbnNlID0gZGF0YS5yZXNwb25zZTtcblx0fVxufTtcbnZhciBVbmhhbmRsZWRFeGNlcHRpb25FdmVudCA9IGNsYXNzIGV4dGVuZHMgVHlwZWRFdmVudCB7XG5cdGVycm9yO1xuXHRyZXF1ZXN0SWQ7XG5cdHJlcXVlc3Q7XG5cdGNvbnN0cnVjdG9yKHR5cGUsIGRhdGEpIHtcblx0XHRzdXBlciguLi5bdHlwZSwge31dKTtcblx0XHR0aGlzLmVycm9yID0gZGF0YS5lcnJvcjtcblx0XHR0aGlzLnJlcXVlc3RJZCA9IGRhdGEucmVxdWVzdElkO1xuXHRcdHRoaXMucmVxdWVzdCA9IGRhdGEucmVxdWVzdDtcblx0fVxufTtcbnZhciBIdHRwTmV0d29ya0ZyYW1lID0gY2xhc3MgZXh0ZW5kcyBOZXR3b3JrRnJhbWUge1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0Y29uc3QgaWQgPSBvcHRpb25zLmlkIHx8IGNyZWF0ZVJlcXVlc3RJZCgpO1xuXHRcdHN1cGVyKFwiaHR0cFwiLCB7XG5cdFx0XHRpZCxcblx0XHRcdHJlcXVlc3Q6IG9wdGlvbnMucmVxdWVzdFxuXHRcdH0pO1xuXHR9XG5cdGdldEhhbmRsZXJzKGNvbnRyb2xsZXIpIHtcblx0XHRyZXR1cm4gY29udHJvbGxlci5nZXRIYW5kbGVyc0J5S2luZChcInJlcXVlc3RcIik7XG5cdH1cblx0YXN5bmMgZ2V0VW5oYW5kbGVkTWVzc2FnZSgpIHtcblx0XHRjb25zdCB7IHJlcXVlc3QgfSA9IHRoaXMuZGF0YTtcblx0XHRjb25zdCB1cmwgPSBuZXcgVVJMKHJlcXVlc3QudXJsKTtcblx0XHRjb25zdCBwdWJsaWNVcmwgPSB0b1B1YmxpY1VybCh1cmwpICsgdXJsLnNlYXJjaDtcblx0XHRjb25zdCByZXF1ZXN0Qm9keSA9IHJlcXVlc3QuYm9keSA9PSBudWxsID8gbnVsbCA6IGF3YWl0IHJlcXVlc3QuY2xvbmUoKS50ZXh0KCk7XG5cdFx0cmV0dXJuIGBpbnRlcmNlcHRlZCBhIHJlcXVlc3Qgd2l0aG91dCBhIG1hdGNoaW5nIHJlcXVlc3QgaGFuZGxlcjoke2BcXG5cXG4gIFxcdTIwMjIgJHtyZXF1ZXN0Lm1ldGhvZH0gJHtwdWJsaWNVcmx9XFxuXFxuJHtyZXF1ZXN0Qm9keSA/IGAgIFxcdTIwMjIgUmVxdWVzdCBib2R5OiAke3JlcXVlc3RCb2R5fVxcblxcbmAgOiBcIlwifWB9SWYgeW91IHN0aWxsIHdpc2ggdG8gaW50ZXJjZXB0IHRoaXMgdW5oYW5kbGVkIHJlcXVlc3QsIHBsZWFzZSBjcmVhdGUgYSByZXF1ZXN0IGhhbmRsZXIgZm9yIGl0LlxcblJlYWQgbW9yZTogaHR0cHM6Ly9tc3dqcy5pby9kb2NzL2h0dHAvaW50ZXJjZXB0aW5nLXJlcXVlc3RzYDtcblx0fVxuXHRhc3luYyByZXNvbHZlKGhhbmRsZXJzLCBvblVuaGFuZGxlZEZyYW1lLCByZXNvbHV0aW9uQ29udGV4dCkge1xuXHRcdGNvbnN0IHsgaWQ6IHJlcXVlc3RJZCwgcmVxdWVzdCB9ID0gdGhpcy5kYXRhO1xuXHRcdGNvbnN0IHJlcXVlc3RDbG9uZUZvckxvZ3MgPSByZXNvbHV0aW9uQ29udGV4dD8ucXVpZXQgPyBudWxsIDogcmVxdWVzdC5jbG9uZSgpO1xuXHRcdHRoaXMuZXZlbnRzLmVtaXQobmV3IFJlcXVlc3RFdmVudChcInJlcXVlc3Q6c3RhcnRcIiwge1xuXHRcdFx0cmVxdWVzdElkLFxuXHRcdFx0cmVxdWVzdFxuXHRcdH0pKTtcblx0XHRpZiAoc2hvdWxkQnlwYXNzUmVxdWVzdChyZXF1ZXN0KSkge1xuXHRcdFx0dGhpcy5ldmVudHMuZW1pdChuZXcgUmVxdWVzdEV2ZW50KFwicmVxdWVzdDplbmRcIiwge1xuXHRcdFx0XHRyZXF1ZXN0SWQsXG5cdFx0XHRcdHJlcXVlc3Rcblx0XHRcdH0pKTtcblx0XHRcdHRoaXMucGFzc3Rocm91Z2goKTtcblx0XHRcdHJldHVybiBudWxsO1xuXHRcdH1cblx0XHRjb25zdCBbbG9va3VwRXJyb3IsIGxvb2t1cFJlc3VsdF0gPSBhd2FpdCB1bnRpbCgoKSA9PiB7XG5cdFx0XHRyZXR1cm4gZXhlY3V0ZUhhbmRsZXJzKHtcblx0XHRcdFx0cmVxdWVzdElkLFxuXHRcdFx0XHRyZXF1ZXN0LFxuXHRcdFx0XHRoYW5kbGVycyxcblx0XHRcdFx0cmVzb2x1dGlvbkNvbnRleHQ6IHtcblx0XHRcdFx0XHRiYXNlVXJsOiByZXNvbHV0aW9uQ29udGV4dD8uYmFzZVVybD8udG9TdHJpbmcoKSxcblx0XHRcdFx0XHRxdWlldDogcmVzb2x1dGlvbkNvbnRleHQ/LnF1aWV0XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdH0pO1xuXHRcdGlmIChsb29rdXBFcnJvciAhPSBudWxsKSB7XG5cdFx0XHRpZiAoIXRoaXMuZXZlbnRzLmVtaXQobmV3IFVuaGFuZGxlZEV4Y2VwdGlvbkV2ZW50KFwidW5oYW5kbGVkRXhjZXB0aW9uXCIsIHtcblx0XHRcdFx0ZXJyb3I6IGxvb2t1cEVycm9yLFxuXHRcdFx0XHRyZXF1ZXN0SWQsXG5cdFx0XHRcdHJlcXVlc3Rcblx0XHRcdH0pKSkge1xuXHRcdFx0XHRjb25zb2xlLmVycm9yKGxvb2t1cEVycm9yKTtcblx0XHRcdFx0ZGV2VXRpbHMuZXJyb3IoXCJFbmNvdW50ZXJlZCBhbiB1bmhhbmRsZWQgZXhjZXB0aW9uIGR1cmluZyB0aGUgaGFuZGxlciBsb29rdXAgZm9yIFxcXCIlcyAlc1xcXCIuIFBsZWFzZSBzZWUgdGhlIG9yaWdpbmFsIGVycm9yIGFib3ZlLlwiLCByZXF1ZXN0Lm1ldGhvZCwgcmVxdWVzdC51cmwpO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy5lcnJvcldpdGgobG9va3VwRXJyb3IpO1xuXHRcdFx0cmV0dXJuIG51bGw7XG5cdFx0fVxuXHRcdGlmIChsb29rdXBSZXN1bHQgPT0gbnVsbCkge1xuXHRcdFx0LyoqXG5cdFx0XHQqIEBub3RlIFVuaGFuZGxlZCBDT05ORUNUIHJlcXVlc3RzIGVzdGFibGlzaCBhIHR1bm5lbCB0aHJvdWdoIGEgcHJveHkuXG5cdFx0XHQqIFRoZXkgYXJlIHRyYW5zcG9ydCwgbm90IHRoZSByZXF1ZXN0IHRoZSBkZXZlbG9wZXIgY2FyZXMgYWJvdXQsIHNvXG5cdFx0XHQqIHRoZXkgcGFzcyB0aHJvdWdoIHNpbGVudGx5IHJlZ2FyZGxlc3Mgb2YgdGhlIHVuaGFuZGxlZCBmcmFtZSBzdHJhdGVneS5cblx0XHRcdCogVGhlIHJlcXVlc3Qgc2VudCB0aHJvdWdoIHRoZSB0dW5uZWwgZ2V0cyBpdHMgb3duIHJlc29sdXRpb24uXG5cdFx0XHQqL1xuXHRcdFx0aWYgKGlzU3RyaW5nRXF1YWwocmVxdWVzdC5tZXRob2QsIFwiQ09OTkVDVFwiKSkge1xuXHRcdFx0XHR0aGlzLmV2ZW50cy5lbWl0KG5ldyBSZXF1ZXN0RXZlbnQoXCJyZXF1ZXN0OmVuZFwiLCB7XG5cdFx0XHRcdFx0cmVxdWVzdElkLFxuXHRcdFx0XHRcdHJlcXVlc3Rcblx0XHRcdFx0fSkpO1xuXHRcdFx0XHR0aGlzLnBhc3N0aHJvdWdoKCk7XG5cdFx0XHRcdHJldHVybiBudWxsO1xuXHRcdFx0fVxuXHRcdFx0dGhpcy5ldmVudHMuZW1pdChuZXcgUmVxdWVzdEV2ZW50KFwicmVxdWVzdDp1bmhhbmRsZWRcIiwge1xuXHRcdFx0XHRyZXF1ZXN0SWQsXG5cdFx0XHRcdHJlcXVlc3Rcblx0XHRcdH0pKTtcblx0XHRcdC8qKlxuXHRcdFx0KiBAbm90ZSBUaGUgdW5oYW5kbGVkIGZyYW1lIGhhbmRsZSBtdXN0IGJlIGV4ZWN1dGVkIGR1cmluZyB0aGUgcmVxdWVzdCByZXNvbHV0aW9uXG5cdFx0XHQqIHNpbmNlIGl0IGNhbiBpbmZsdWVuY2UgaXQgKGUuZy4gZXJyb3IgdGhlIHJlcXVlc3QgaWYgdGhlIFwiZXJyb3JcIiBzdGFydGVneSB3YXMgdXNlZCkuXG5cdFx0XHQqL1xuXHRcdFx0YXdhaXQgZXhlY3V0ZVVuaGFuZGxlZEZyYW1lSGFuZGxlKHRoaXMsIG9uVW5oYW5kbGVkRnJhbWUpLnRoZW4oKCkgPT4gdGhpcy5wYXNzdGhyb3VnaCgpLCAoZXJyb3IpID0+IHRoaXMuZXJyb3JXaXRoKGVycm9yKSk7XG5cdFx0XHR0aGlzLmV2ZW50cy5lbWl0KG5ldyBSZXF1ZXN0RXZlbnQoXCJyZXF1ZXN0OmVuZFwiLCB7XG5cdFx0XHRcdHJlcXVlc3RJZCxcblx0XHRcdFx0cmVxdWVzdFxuXHRcdFx0fSkpO1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0XHRjb25zdCB7IHJlc3BvbnNlLCBoYW5kbGVyLCBwYXJzZWRSZXN1bHQgfSA9IGxvb2t1cFJlc3VsdDtcblx0XHR0aGlzLmV2ZW50cy5lbWl0KG5ldyBSZXF1ZXN0RXZlbnQoXCJyZXF1ZXN0Om1hdGNoXCIsIHtcblx0XHRcdHJlcXVlc3RJZCxcblx0XHRcdHJlcXVlc3Rcblx0XHR9KSk7XG5cdFx0aWYgKHJlc3BvbnNlID09IG51bGwpIHtcblx0XHRcdHRoaXMuZXZlbnRzLmVtaXQobmV3IFJlcXVlc3RFdmVudChcInJlcXVlc3Q6ZW5kXCIsIHtcblx0XHRcdFx0cmVxdWVzdElkLFxuXHRcdFx0XHRyZXF1ZXN0XG5cdFx0XHR9KSk7XG5cdFx0XHR0aGlzLnBhc3N0aHJvdWdoKCk7XG5cdFx0XHRyZXR1cm4gbnVsbDtcblx0XHR9XG5cdFx0aWYgKGlzUGFzc3Rocm91Z2hSZXNwb25zZShyZXNwb25zZSkpIHtcblx0XHRcdHRoaXMuZXZlbnRzLmVtaXQobmV3IFJlcXVlc3RFdmVudChcInJlcXVlc3Q6ZW5kXCIsIHtcblx0XHRcdFx0cmVxdWVzdElkLFxuXHRcdFx0XHRyZXF1ZXN0XG5cdFx0XHR9KSk7XG5cdFx0XHR0aGlzLnBhc3N0aHJvdWdoKCk7XG5cdFx0XHRyZXR1cm4gbnVsbDtcblx0XHR9XG5cdFx0Y29uc3QgcmVzcG9uc2VDbG9uZUZvckxvZ3MgPSByZXNvbHV0aW9uQ29udGV4dD8ucXVpZXQgPyBudWxsIDogcmVzcG9uc2UuY2xvbmUoKTtcblx0XHRhd2FpdCBzdG9yZVJlc3BvbnNlQ29va2llcyhyZXF1ZXN0LCByZXNwb25zZSk7XG5cdFx0dGhpcy5yZXNwb25kV2l0aChyZXNwb25zZSk7XG5cdFx0dGhpcy5ldmVudHMuZW1pdChuZXcgUmVxdWVzdEV2ZW50KFwicmVxdWVzdDplbmRcIiwge1xuXHRcdFx0cmVxdWVzdElkLFxuXHRcdFx0cmVxdWVzdFxuXHRcdH0pKTtcblx0XHRpZiAoIXJlc29sdXRpb25Db250ZXh0Py5xdWlldCkgaGFuZGxlci5sb2coe1xuXHRcdFx0cmVxdWVzdDogcmVxdWVzdENsb25lRm9yTG9ncyxcblx0XHRcdHJlc3BvbnNlOiByZXNwb25zZUNsb25lRm9yTG9ncyxcblx0XHRcdHBhcnNlZFJlc3VsdFxuXHRcdH0pO1xuXHRcdHJldHVybiB0cnVlO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvcmUvZXhwZXJpbWVudGFsL2ZyYW1lcy93ZWJzb2NrZXQtZnJhbWUudHNcbnZhciBXZWJTb2NrZXRDb25uZWN0aW9uRXZlbnQgPSBjbGFzcyBleHRlbmRzIFR5cGVkRXZlbnQge1xuXHR1cmw7XG5cdHByb3RvY29scztcblx0Y29uc3RydWN0b3IodHlwZSwgZGF0YSkge1xuXHRcdHN1cGVyKC4uLlt0eXBlLCB7fV0pO1xuXHRcdHRoaXMudXJsID0gZGF0YS51cmw7XG5cdFx0dGhpcy5wcm90b2NvbHMgPSBkYXRhLnByb3RvY29scztcblx0fVxufTtcbnZhciBXZWJTb2NrZXRFcnJvckV2ZW50ID0gY2xhc3MgZXh0ZW5kcyBXZWJTb2NrZXRDb25uZWN0aW9uRXZlbnQge1xuXHRlcnJvcjtcblx0Y29uc3RydWN0b3IodHlwZSwgZGF0YSkge1xuXHRcdHN1cGVyKHR5cGUsIGRhdGEpO1xuXHRcdHRoaXMuZXJyb3IgPSBkYXRhLmVycm9yO1xuXHR9XG59O1xudmFyIFdlYlNvY2tldE5ldHdvcmtGcmFtZSA9IGNsYXNzIGV4dGVuZHMgTmV0d29ya0ZyYW1lIHtcblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHN1cGVyKFwid3NcIiwgeyBjb25uZWN0aW9uOiBvcHRpb25zLmNvbm5lY3Rpb24gfSk7XG5cdH1cblx0Z2V0SGFuZGxlcnMoY29udHJvbGxlcikge1xuXHRcdHJldHVybiBjb250cm9sbGVyLmdldEhhbmRsZXJzQnlLaW5kKFwid2Vic29ja2V0XCIpO1xuXHR9XG5cdGFzeW5jIHJlc29sdmUoaGFuZGxlcnMsIG9uVW5oYW5kbGVkRnJhbWUsIHJlc29sdXRpb25Db250ZXh0KSB7XG5cdFx0Y29uc3QgeyBjb25uZWN0aW9uIH0gPSB0aGlzLmRhdGE7XG5cdFx0dGhpcy5ldmVudHMuZW1pdChuZXcgV2ViU29ja2V0Q29ubmVjdGlvbkV2ZW50KFwid2Vic29ja2V0OmNvbm5lY3Rpb25cIiwge1xuXHRcdFx0dXJsOiBjb25uZWN0aW9uLmNsaWVudC51cmwsXG5cdFx0XHRwcm90b2NvbHM6IGNvbm5lY3Rpb24uaW5mby5wcm90b2NvbHNcblx0XHR9KSk7XG5cdFx0Y29uc3QgaGFuZGxlU29ja2V0RXJyb3IgPSAoZXZlbnQpID0+IHtcblx0XHRcdHRoaXMuZXZlbnRzLmVtaXQobmV3IFdlYlNvY2tldEVycm9yRXZlbnQoXCJ3ZWJzb2NrZXQ6ZXJyb3JcIiwge1xuXHRcdFx0XHR1cmw6IGNvbm5lY3Rpb24uY2xpZW50LnVybCxcblx0XHRcdFx0cHJvdG9jb2xzOiBjb25uZWN0aW9uLmluZm8ucHJvdG9jb2xzLFxuXHRcdFx0XHRlcnJvcjogZ2V0RXJyb3JGcm9tRXZlbnQoZXZlbnQpXG5cdFx0XHR9KSk7XG5cdFx0fTtcblx0XHRjb25uZWN0aW9uLmNsaWVudC5zb2NrZXQuYWRkRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsIGhhbmRsZVNvY2tldEVycm9yKTtcblx0XHRjb25uZWN0aW9uLmNsaWVudC5zb2NrZXQuYWRkRXZlbnRMaXN0ZW5lcihcImNsb3NlXCIsICgpID0+IHtcblx0XHRcdGNvbm5lY3Rpb24uY2xpZW50LnNvY2tldC5yZW1vdmVFdmVudExpc3RlbmVyKFwiZXJyb3JcIiwgaGFuZGxlU29ja2V0RXJyb3IpO1xuXHRcdH0sIHsgb25jZTogdHJ1ZSB9KTtcblx0XHRpZiAoaGFuZGxlcnMubGVuZ3RoID09PSAwKSB7XG5cdFx0XHRhd2FpdCBleGVjdXRlVW5oYW5kbGVkRnJhbWVIYW5kbGUodGhpcywgb25VbmhhbmRsZWRGcmFtZSkudGhlbigoKSA9PiB0aGlzLnBhc3N0aHJvdWdoKCksIChlcnJvcikgPT4gdGhpcy5lcnJvcldpdGgoZXJyb3IpKTtcblx0XHRcdHJldHVybiBmYWxzZTtcblx0XHR9XG5cdFx0bGV0IGhhc01hdGNoaW5nSGFuZGxlcnMgPSBmYWxzZTtcblx0XHRmb3IgKGNvbnN0IGhhbmRsZXIgb2YgaGFuZGxlcnMpIHtcblx0XHRcdGNvbnN0IGhhbmRsZXJDb25uZWN0aW9uID0gYXdhaXQgaGFuZGxlci5ydW4oY29ubmVjdGlvbiwge1xuXHRcdFx0XHRiYXNlVXJsOiByZXNvbHV0aW9uQ29udGV4dD8uYmFzZVVybD8udG9TdHJpbmcoKSxcblx0XHRcdFx0LyoqXG5cdFx0XHRcdCogQG5vdGUgRXhwb3NlIGFuIGVtaXQtb25seSByZWZlcmVuY2UgdG8gdGhpcyBmcmFtZSdzIGV2ZW50c1xuXHRcdFx0XHQqIHNvIHRoZSBoYW5kbGVycyBjYW4gZW1pdCBhZGRpdGlvbmFsIGV2ZW50cyBub3QgY292ZXJlZCBieVxuXHRcdFx0XHQqIHRoZSBmcmFtZSAoZS5nLiBcImdyYXBocWw6c3Vic2NyaXB0aW9uXCIpLlxuXHRcdFx0XHQqL1xuXHRcdFx0XHRldmVudHM6IHRoaXMuZXZlbnRzLFxuXHRcdFx0XHQvKipcblx0XHRcdFx0KiBAbm90ZSBEbyBub3QgZW1pdCB0aGUgaGFuZGxlcidzIFwiY29ubmVjdGlvblwiIGV2ZW50IHdoZW4gcnVubmluZyB0aGUgaGFuZGxlci5cblx0XHRcdFx0KiBVc2UgdGhlIHJ1biBvbmx5IHRvIGdldCB0aGUgcmVzb2x2ZWQgY29ubmVjdGlvbiBvYmplY3QuXG5cdFx0XHRcdCovXG5cdFx0XHRcdFtrQXV0b0Nvbm5lY3RdOiBmYWxzZVxuXHRcdFx0fSk7XG5cdFx0XHRpZiAoIWhhbmRsZXJDb25uZWN0aW9uKSBjb250aW51ZTtcblx0XHRcdGhhc01hdGNoaW5nSGFuZGxlcnMgPSB0cnVlO1xuXHRcdFx0LyoqXG5cdFx0XHQqIEBub3RlIEF0dGFjaCB0aGUgV2ViU29ja2V0IGxvZ2dlciAqYmVmb3JlKiBlbWl0dGluZyB0aGUgaGFuZGxlcidzIFwiY29ubmVjdGlvblwiIGV2ZW50LlxuXHRcdFx0KiBDb25uZWN0aW9uIGV2ZW50IGxpc3RlbmVycyBtYXkgcGVyZm9ybSBhY3Rpb25zIHRoYXQgc2hvdWxkIGJlIHJlZmxlY3RlZCBpbiB0aGUgbG9nc1xuXHRcdFx0KiAoZS5nLiBjbG9zaW5nIHRoZSBjb25uZWN0aW9uIGltbWVkaWF0ZWx5KS4gSWYgdGhlIGxvZ2dlciBpcyBhdHRhY2hlZCBhZnRlciB0aGUgY29ubmVjdGlvbixcblx0XHRcdCogdGhvc2UgYWN0aW9ucyBjYW5ub3QgYmUgcHJvcGVybHkgbG9nZ2VkLlxuXHRcdFx0Ki9cblx0XHRcdGNvbnN0IHJlbW92ZUxvZ2dlciA9ICFyZXNvbHV0aW9uQ29udGV4dD8ucXVpZXQgPyBoYW5kbGVyLmxvZyhjb25uZWN0aW9uKSA6IHZvaWQgMDtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGlmICghaGFuZGxlcltrQ29ubmVjdF0oaGFuZGxlckNvbm5lY3Rpb24pKSByZW1vdmVMb2dnZXI/LigpO1xuXHRcdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdFx0aWYgKCF0aGlzLmV2ZW50cy5lbWl0KG5ldyBXZWJTb2NrZXRFcnJvckV2ZW50KFwidW5oYW5kbGVkRXhjZXB0aW9uXCIsIHtcblx0XHRcdFx0XHRlcnJvcixcblx0XHRcdFx0XHR1cmw6IGNvbm5lY3Rpb24uY2xpZW50LnVybCxcblx0XHRcdFx0XHRwcm90b2NvbHM6IGNvbm5lY3Rpb24uaW5mby5wcm90b2NvbHNcblx0XHRcdFx0fSkpKSB7XG5cdFx0XHRcdFx0Y29uc29sZS5lcnJvcihlcnJvcik7XG5cdFx0XHRcdFx0ZGV2VXRpbHMuZXJyb3IoXCJFbmNvdW50ZXJlZCBhbiB1bmhhbmRsZWQgZXhjZXB0aW9uIGR1cmluZyB0aGUgaGFuZGxlciBsb29rdXAgZm9yIFxcXCIlc1xcXCIuIFBsZWFzZSBzZWUgdGhlIG9yaWdpbmFsIGVycm9yIGFib3ZlLlwiLCBjb25uZWN0aW9uLmNsaWVudC51cmwpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdC8qKlxuXHRcdFx0XHQqIEBub3RlIFRocm93IHRoZSBjYXVnaHQgZXJyb3Igc28gaXQgZ2V0cyBwaWNrZWQgdXAgYnkgV2ViU29ja2V0SW50ZXJjZXB0b3IuXG5cdFx0XHRcdCogSXQncyB0aGUgaW50ZXJjZXB0b3Igd2hvIHRyYW5zbGF0ZXMgaGFuZGxlciBlcnJvcnMgdG8gV2ViU29ja2V0IGNsb3N1cmVzLlxuXHRcdFx0XHQqL1xuXHRcdFx0XHR0aHJvdyBlcnJvcjtcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYgKCFoYXNNYXRjaGluZ0hhbmRsZXJzKSB7XG5cdFx0XHRhd2FpdCBleGVjdXRlVW5oYW5kbGVkRnJhbWVIYW5kbGUodGhpcywgb25VbmhhbmRsZWRGcmFtZSkudGhlbigoKSA9PiB0aGlzLnBhc3N0aHJvdWdoKCksIChlcnJvcikgPT4gdGhpcy5lcnJvcldpdGgoZXJyb3IpKTtcblx0XHRcdHJldHVybiBmYWxzZTtcblx0XHR9XG5cdFx0cmV0dXJuIHRydWU7XG5cdH1cblx0YXN5bmMgZ2V0VW5oYW5kbGVkTWVzc2FnZSgpIHtcblx0XHRjb25zdCB7IGNvbm5lY3Rpb24gfSA9IHRoaXMuZGF0YTtcblx0XHRyZXR1cm4gYGludGVyY2VwdGVkIGEgV2ViU29ja2V0IGNvbm5lY3Rpb24gd2l0aG91dCBhIG1hdGNoaW5nIGV2ZW50IGhhbmRsZXI6JHtgXFxuXFxuICBcXHUyMDIyICR7Y29ubmVjdGlvbi5jbGllbnQudXJsfVxcblxcbmB9SWYgeW91IHN0aWxsIHdpc2ggdG8gaW50ZXJjZXB0IHRoaXMgdW5oYW5kbGVkIGNvbm5lY3Rpb24sIHBsZWFzZSBjcmVhdGUgYW4gZXZlbnQgaGFuZGxlciBmb3IgaXQuXFxuUmVhZCBtb3JlOiBodHRwczovL21zd2pzLmlvL2RvY3Mvd2Vic29ja2V0YDtcblx0fVxufTtcbi8qKlxuKiBFeHRyYWN0IHRoZSBlcnJvciBmcm9tIHRoZSBnaXZlbiBcImVycm9yXCIgZXZlbnQsIGlmIGFueS5cbiogU3VwcG9ydHMgYm90aCB0aGUgYEVycm9yRXZlbnQuZXJyb3JgIHByb3BlcnR5IGFuZCB0aGUgYGNhdXNlYFxuKiBwcm9wZXJ0eSB0aGF0IE1TVyBzZXRzIHdoZW4gZXJyb3JpbmcgdGhlIGNvbm5lY3Rpb24gaXRzZWxmLlxuKi9cbmZ1bmN0aW9uIGdldEVycm9yRnJvbUV2ZW50KGV2ZW50KSB7XG5cdGlmIChcImVycm9yXCIgaW4gZXZlbnQgJiYgZXZlbnQuZXJyb3IgIT0gbnVsbCkgcmV0dXJuIGV2ZW50LmVycm9yO1xuXHRpZiAoXCJjYXVzZVwiIGluIGV2ZW50ICYmIGV2ZW50LmNhdXNlICE9IG51bGwpIHJldHVybiBldmVudC5jYXVzZTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jb3JlL2V4cGVyaW1lbnRhbC9zb3VyY2VzL2ludGVyY2VwdG9yLXNvdXJjZS50c1xuLyoqXG4qIENyZWF0ZSBhIG5ldHdvcmsgc291cmNlIGZyb20gdGhlIGdpdmVuIGxpc3Qgb2YgaW50ZXJjZXB0b3JzLlxuKi9cbnZhciBJbnRlcmNlcHRvclNvdXJjZSA9IGNsYXNzIGV4dGVuZHMgTmV0d29ya1NvdXJjZSB7XG5cdCNpbnRlcmNlcHRvcjtcblx0LyoqXG5cdCogQG5vdGUgRnJhbWVzIGFyZSBrZXllZCBieSB0aGUgcmVxdWVzdCBpbnN0YW5jZSwgbm90IHRoZSByZXF1ZXN0IElELlxuXHQqIFRoZSBpbnRlcmNlcHRvciBlbWl0cyB0aGUgc2FtZSByZXF1ZXN0IGluc3RhbmNlIG9uIHRoZSBcInJlcXVlc3RcIlxuXHQqIGFuZCBcInJlc3BvbnNlXCIgZXZlbnRzLCBzbyB0aGUgZnJhbWUgY2FuIGJlIGxvb2tlZCB1cCBieSBpZGVudGl0eS5cblx0KiBBIHdlYWsgcmVmZXJlbmNlIGxldHMgdGhlIGZyYW1lIGJlIGdhcmJhZ2UgY29sbGVjdGVkIGFsb25nc2lkZVxuXHQqIGl0cyByZXF1ZXN0IG9uY2UgdGhlIHJlcXVlc3Qgc2V0dGxlcyB3aXRob3V0IHByb2R1Y2luZyBhIHJlc3BvbnNlXG5cdCogKGUuZy4gYSBwYXNzdGhyb3VnaCByZXF1ZXN0IGZhaWxpbmcgd2l0aCBhIG5ldHdvcmsgZXJyb3IpLlxuXHQqIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL21zd2pzL21zdy9pc3N1ZXMvMjc5MlxuXHQqL1xuXHQjZnJhbWVzO1xuXHRjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG5cdFx0c3VwZXIoKTtcblx0XHR0aGlzLiNpbnRlcmNlcHRvciA9IG5ldyBCYXRjaEludGVyY2VwdG9yKHtcblx0XHRcdG5hbWU6IFwiaW50ZXJjZXB0b3Itc291cmNlXCIsXG5cdFx0XHRpbnRlcmNlcHRvcnM6IG9wdGlvbnMuaW50ZXJjZXB0b3JzXG5cdFx0fSk7XG5cdFx0dGhpcy4jZnJhbWVzID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5cdH1cblx0ZW5hYmxlKCkge1xuXHRcdHRoaXMuI2ludGVyY2VwdG9yLmFwcGx5KCk7XG5cdFx0dGhpcy4jaW50ZXJjZXB0b3Iub24oXCJyZXF1ZXN0XCIsIHRoaXMuI2hhbmRsZVJlcXVlc3QuYmluZCh0aGlzKSkub24oXCJyZXNwb25zZVwiLCB0aGlzLiNoYW5kbGVSZXNwb25zZS5iaW5kKHRoaXMpKS5vbihcImNvbm5lY3Rpb25cIiwgdGhpcy4jaGFuZGxlV2ViU29ja2V0Q29ubmVjdGlvbi5iaW5kKHRoaXMpKTtcblx0fVxuXHRkaXNhYmxlKCkge1xuXHRcdHN1cGVyLmRpc2FibGUoKTtcblx0XHR0aGlzLiNpbnRlcmNlcHRvci5kaXNwb3NlKCk7XG5cdFx0LyoqXG5cdFx0KiBAdG9kbyBXZSBjYW4gYWxzbyBhYm9ydCBhbnkgcGVuZGluZyBmcmFtZXMgaGVyZSwgZ2l2ZW4gd2UgaW1wbGVtZW50XG5cdFx0KiB0aGUgYE5ldHdvcmtGcmFtZS5hYm9ydCgpYCBtZXRob2QuXG5cdFx0Ki9cblx0XHR0aGlzLiNmcmFtZXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcblx0fVxuXHRhc3luYyAjaGFuZGxlUmVxdWVzdChldmVudCkge1xuXHRcdGNvbnN0IHsgcmVxdWVzdElkLCByZXF1ZXN0LCBjb250cm9sbGVyIH0gPSBldmVudDtcblx0XHRjb25zdCBodHRwRnJhbWUgPSBuZXcgSW50ZXJjZXB0b3JIdHRwTmV0d29ya0ZyYW1lKHtcblx0XHRcdGlkOiByZXF1ZXN0SWQsXG5cdFx0XHRyZXF1ZXN0LFxuXHRcdFx0Y29udHJvbGxlclxuXHRcdH0pO1xuXHRcdHRoaXMuI2ZyYW1lcy5zZXQocmVxdWVzdCwgaHR0cEZyYW1lKTtcblx0XHRhd2FpdCB0aGlzLnF1ZXVlKGh0dHBGcmFtZSk7XG5cdH1cblx0YXN5bmMgI2hhbmRsZVJlc3BvbnNlKHsgcmVxdWVzdElkLCByZXF1ZXN0LCByZXNwb25zZSwgcmVzcG9uc2VUeXBlIH0pIHtcblx0XHRjb25zdCBodHRwRnJhbWUgPSB0aGlzLiNmcmFtZXMuZ2V0KHJlcXVlc3QpO1xuXHRcdHRoaXMuI2ZyYW1lcy5kZWxldGUocmVxdWVzdCk7XG5cdFx0aWYgKGh0dHBGcmFtZSA9PSBudWxsKSByZXR1cm47XG5cdFx0cXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0aHR0cEZyYW1lLmV2ZW50cy5lbWl0KG5ldyBSZXNwb25zZUV2ZW50KHJlc3BvbnNlVHlwZSA9PT0gXCJtb2NrXCIgPyBcInJlc3BvbnNlOm1vY2tlZFwiIDogXCJyZXNwb25zZTpieXBhc3NcIiwge1xuXHRcdFx0XHRcdHJlcXVlc3RJZCxcblx0XHRcdFx0XHRyZXF1ZXN0LFxuXHRcdFx0XHRcdHJlc3BvbnNlXG5cdFx0XHRcdH0pKTtcblx0XHRcdH0gZmluYWxseSB7XG5cdFx0XHRcdC8qKlxuXHRcdFx0XHQqIEBub3RlIFJlbW92ZSBhbnkgbGlzdGVuZXJzIGZyb20gdGhpcyBmcmFtZS5cblx0XHRcdFx0KiBQYXN0IHRoaXMgcG9pbnQsIGl0IHdvbid0IGVtaXQgYW55dGhpbmcuIFRoZSByZW1vdmFsIGlzIGNydWNpYWxcblx0XHRcdFx0KiB0byBwcmV2ZW50IFwicmV0dGltZVwiIGZyb20ga2VlcGluZyB0aGUgYWJvcnQgY2xlYW51cCBsaXN0ZW5lcnMgaW50ZXJuYWxseS5cblx0XHRcdFx0KiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9tc3cvaXNzdWVzLzI3MzVcblx0XHRcdFx0Ki9cblx0XHRcdFx0aHR0cEZyYW1lLmV2ZW50cy5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXHRhc3luYyAjaGFuZGxlV2ViU29ja2V0Q29ubmVjdGlvbihjb25uZWN0aW9uKSB7XG5cdFx0YXdhaXQgdGhpcy5xdWV1ZShuZXcgSW50ZXJjZXB0b3JXZWJTb2NrZXROZXR3b3JrRnJhbWUoeyBjb25uZWN0aW9uIH0pKTtcblx0fVxufTtcbnZhciBJbnRlcmNlcHRvckh0dHBOZXR3b3JrRnJhbWUgPSBjbGFzcyBleHRlbmRzIEh0dHBOZXR3b3JrRnJhbWUge1xuXHQjY29udHJvbGxlcjtcblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHN1cGVyKHtcblx0XHRcdGlkOiBvcHRpb25zLmlkLFxuXHRcdFx0cmVxdWVzdDogb3B0aW9ucy5yZXF1ZXN0XG5cdFx0fSk7XG5cdFx0dGhpcy4jY29udHJvbGxlciA9IG9wdGlvbnMuY29udHJvbGxlcjtcblx0fVxuXHRwYXNzdGhyb3VnaCgpIHtcblx0XHRkZWxldGVSZXF1ZXN0UGFzc3Rocm91Z2hIZWFkZXIodGhpcy5kYXRhLnJlcXVlc3QpO1xuXHR9XG5cdHJlc3BvbmRXaXRoKHJlc3BvbnNlKSB7XG5cdFx0aWYgKHJlc3BvbnNlKSB0aGlzLiNjb250cm9sbGVyLnJlc3BvbmRXaXRoKHJlc3BvbnNlKTtcblx0fVxuXHRlcnJvcldpdGgocmVhc29uKSB7XG5cdFx0aWYgKHJlYXNvbiBpbnN0YW5jZW9mIFJlc3BvbnNlKSByZXR1cm4gdGhpcy5yZXNwb25kV2l0aChyZWFzb24pO1xuXHRcdGlmIChyZWFzb24gaW5zdGFuY2VvZiBJbnRlcm5hbEVycm9yKSB0aGlzLiNjb250cm9sbGVyLmVycm9yV2l0aChyZWFzb24pO1xuXHRcdHRocm93IHJlYXNvbjtcblx0fVxufTtcbnZhciBJbnRlcmNlcHRvcldlYlNvY2tldE5ldHdvcmtGcmFtZSA9IGNsYXNzIGV4dGVuZHMgV2ViU29ja2V0TmV0d29ya0ZyYW1lIHtcblx0LyoqXG5cdCogVGhlIGluLXByb2Nlc3MgY2xpZW50IGNvbm5lY3Rpb24sIHdob3NlIHNvY2tldFxuXHQqIHRoZSBmcmFtZSBkaXNwYXRjaGVzIGVycm9ycyBvbi5cblx0Ki9cblx0I2NsaWVudDtcblx0Y29uc3RydWN0b3IoYXJncykge1xuXHRcdHN1cGVyKHsgY29ubmVjdGlvbjogYXJncy5jb25uZWN0aW9uIH0pO1xuXHRcdHRoaXMuI2NsaWVudCA9IGFyZ3MuY29ubmVjdGlvbi5jbGllbnQ7XG5cdFx0LyoqXG5cdFx0KiBAbm90ZSBQcm92aWRlIGEgc2ltaWxhciBmcmFtZSBsaXN0ZW5lciBjbGVhbnVwIGFzIGZvciBIVFRQLlxuXHRcdCogV2hlbiB0aGUgY2xpZW50IGNvbm5lY3Rpb24gY2xvc2VzLCB0aGUgaGFuZGxlciBjYW4gbm8gbG9uZ2VyIGJlIHVzZWQuXG5cdFx0Ki9cblx0XHRhcmdzLmNvbm5lY3Rpb24uY2xpZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJjbG9zZVwiLCAoKSA9PiB7XG5cdFx0XHR0aGlzLmV2ZW50cy5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcblx0XHR9LCB7IG9uY2U6IHRydWUgfSk7XG5cdH1cblx0ZXJyb3JXaXRoKHJlYXNvbikge1xuXHRcdGlmIChyZWFzb24gaW5zdGFuY2VvZiBFcnJvcikge1xuXHRcdFx0LyoqXG5cdFx0XHQqIFVzZSBgY2xpZW50LmVycm9yV2l0aChyZWFzb24pYCBpbiB0aGUgZnV0dXJlLlxuXHRcdFx0KiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9pbnRlcmNlcHRvcnMvaXNzdWVzLzc0N1xuXHRcdFx0Ki9cblx0XHRcdGNvbnN0IGVycm9yRXZlbnQgPSBuZXcgRXZlbnQoXCJlcnJvclwiKTtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlcnJvckV2ZW50LCBcImNhdXNlXCIsIHtcblx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdFx0Y29uZmlndXJhYmxlOiBmYWxzZSxcblx0XHRcdFx0dmFsdWU6IHJlYXNvblxuXHRcdFx0fSk7XG5cdFx0XHR0aGlzLiNjbGllbnQuc29ja2V0LmRpc3BhdGNoRXZlbnQoZXJyb3JFdmVudCk7XG5cdFx0fVxuXHR9XG5cdHBhc3N0aHJvdWdoKCkge1xuXHRcdHRoaXMuZGF0YS5jb25uZWN0aW9uLnNlcnZlci5jb25uZWN0KCk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IE5ldHdvcmtGcmFtZSBhcyBhLCBIYW5kbGVyc0NvbnRyb2xsZXIgYXMgYywgUmVzcG9uc2VFdmVudCBhcyBpLCBJbk1lbW9yeUhhbmRsZXJzQ29udHJvbGxlciBhcyBsLCBXZWJTb2NrZXROZXR3b3JrRnJhbWUgYXMgbiwgTmV0d29ya1JlYWR5U3RhdGUgYXMgbywgSHR0cE5ldHdvcmtGcmFtZSBhcyByLCBkZWZpbmVOZXR3b3JrIGFzIHMsIEludGVyY2VwdG9yU291cmNlIGFzIHQsIE5ldHdvcmtTb3VyY2UgYXMgdSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbnRlcmNlcHRvci1zb3VyY2UuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9pbmRleC50c1xuLyoqXG4qIEdyYWNlZnVsbHkgaGFuZGxlcyBhIGNhbGxiYWNrIHRoYXQgcmV0dXJucyBhIHByb21pc2UuXG4qXG4qIEBleGFtcGxlXG4qIGF3YWl0IHVudGlsKCgpID0+IFByb21pc2UucmVzb2x2ZSgxMjMpKVxuKiAvLyBbbnVsbCwgMTIzXVxuKlxuKiBhd2FpdCB1bnRpbCgoKSA9PiBQcm9taXNlLnJlamVjdChuZXcgRXJyb3IoJ09vcHMhJykpKVxuKiAvLyBbbmV3IEVycm9yKCdPb3BzIScpLCBudWxsXVxuKi9cbmFzeW5jIGZ1bmN0aW9uIHVudGlsKGNhbGxiYWNrKSB7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIFtudWxsLCBhd2FpdCBjYWxsYmFjaygpLmNhdGNoKChlcnJvcikgPT4ge1xuXHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0fSldO1xuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdHJldHVybiBbZXJyb3IsIG51bGxdO1xuXHR9XG59XG5cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdW50aWwgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsImltcG9ydCB7IGkgYXMgZm9ybWF0UmVxdWVzdCB9IGZyb20gXCIuL2NyZWF0ZS1yZXF1ZXN0LWlkLVlvYlVuSk5PLmpzXCI7XG5pbXBvcnQgeyBhIGFzIGlzUmVzcG9uc2VMaWtlLCBjIGFzIFJlcXVlc3RDb250cm9sbGVyLCBpIGFzIGlzUmVzcG9uc2VFcnJvciwgbCBhcyBJbnRlcmNlcHRvckVycm9yLCBvIGFzIGlzT2JqZWN0LCByIGFzIGNyZWF0ZVNlcnZlckVycm9yUmVzcG9uc2UgfSBmcm9tIFwiLi9mZXRjaC11dGlscy1DNlA2Z0xMby5qc1wiO1xuaW1wb3J0IHsgVHlwZWRFdmVudCB9IGZyb20gXCJyZXR0aW1lXCI7XG5pbXBvcnQgeyB1bnRpbCB9IGZyb20gXCJAb3Blbi1kcmFmdC91bnRpbFwiO1xuLy8jcmVnaW9uIHNyYy9ldmVudHMvaHR0cC50c1xudmFyIEh0dHBSZXF1ZXN0RXZlbnQgPSBjbGFzcyBleHRlbmRzIFR5cGVkRXZlbnQge1xuXHRjb25zdHJ1Y3RvcihkYXRhKSB7XG5cdFx0c3VwZXIoLi4uW1wicmVxdWVzdFwiLCB7fV0pO1xuXHRcdHRoaXMucmVxdWVzdCA9IGRhdGEucmVxdWVzdDtcblx0XHR0aGlzLnJlcXVlc3RJZCA9IGRhdGEucmVxdWVzdElkO1xuXHRcdHRoaXMuaW5pdGlhdG9yID0gZGF0YS5pbml0aWF0b3I7XG5cdFx0dGhpcy5jb250cm9sbGVyID0gZGF0YS5jb250cm9sbGVyO1xuXHR9XG59O1xudmFyIEh0dHBSZXNwb25zZUV2ZW50ID0gY2xhc3MgZXh0ZW5kcyBUeXBlZEV2ZW50IHtcblx0Y29uc3RydWN0b3IoZGF0YSkge1xuXHRcdHN1cGVyKC4uLltcInJlc3BvbnNlXCIsIHt9XSk7XG5cdFx0dGhpcy5yZXNwb25zZSA9IGRhdGEucmVzcG9uc2U7XG5cdFx0dGhpcy5yZXNwb25zZVR5cGUgPSBkYXRhLnJlc3BvbnNlVHlwZTtcblx0XHR0aGlzLnJlcXVlc3QgPSBkYXRhLnJlcXVlc3Q7XG5cdFx0dGhpcy5yZXF1ZXN0SWQgPSBkYXRhLnJlcXVlc3RJZDtcblx0XHR0aGlzLmluaXRpYXRvciA9IGRhdGEuaW5pdGlhdG9yO1xuXHR9XG59O1xudmFyIFVuaGFuZGxlZEh0dHBFeGNlcHRpb24gPSBjbGFzcyBleHRlbmRzIFR5cGVkRXZlbnQge1xuXHRjb25zdHJ1Y3RvcihkYXRhKSB7XG5cdFx0c3VwZXIoLi4uW1widW5oYW5kbGVkRXhjZXB0aW9uXCIsIHt9XSk7XG5cdFx0dGhpcy5lcnJvciA9IGRhdGEuZXJyb3I7XG5cdFx0dGhpcy5yZXF1ZXN0ID0gZGF0YS5yZXF1ZXN0O1xuXHRcdHRoaXMucmVxdWVzdElkID0gZGF0YS5yZXF1ZXN0SWQ7XG5cdFx0dGhpcy5pbml0aWF0b3IgPSBkYXRhLmluaXRpYXRvcjtcblx0XHR0aGlzLmNvbnRyb2xsZXIgPSBkYXRhLmNvbnRyb2xsZXI7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvdXRpbHMvaXMtbm9kZS1saWtlLWVycm9yLnRzXG5mdW5jdGlvbiBpc05vZGVMaWtlRXJyb3IoZXJyb3IpIHtcblx0aWYgKGVycm9yID09IG51bGwpIHJldHVybiBmYWxzZTtcblx0aWYgKCEoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikpIHJldHVybiBmYWxzZTtcblx0cmV0dXJuIFwiY29kZVwiIGluIGVycm9yICYmIFwiZXJybm9cIiBpbiBlcnJvcjtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy91dGlscy9oYW5kbGUtcmVxdWVzdC50c1xuYXN5bmMgZnVuY3Rpb24gaGFuZGxlUmVxdWVzdChvcHRpb25zKSB7XG5cdGlmIChvcHRpb25zLmxvZ2dlcj8uaXNFbmFibGVkKFwiZGVmYXVsdFwiKSkgZm9ybWF0UmVxdWVzdChvcHRpb25zLnJlcXVlc3QpLnRoZW4oKG1lc3NhZ2UpID0+IHtcblx0XHRvcHRpb25zLmxvZ2dlcj8uaW5mbyhcIlslc10gJXNcIiwgb3B0aW9ucy5yZXF1ZXN0SWQsIG1lc3NhZ2UpO1xuXHR9KTtcblx0Y29uc3QgaGFuZGxlUmVzcG9uc2UgPSBhc3luYyAocmVzcG9uc2UpID0+IHtcblx0XHRpZiAocmVzcG9uc2UgaW5zdGFuY2VvZiBFcnJvcikge1xuXHRcdFx0YXdhaXQgb3B0aW9ucy5jb250cm9sbGVyLmVycm9yV2l0aChyZXNwb25zZSk7XG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9XG5cdFx0aWYgKGlzUmVzcG9uc2VFcnJvcihyZXNwb25zZSkpIHtcblx0XHRcdGF3YWl0IG9wdGlvbnMuY29udHJvbGxlci5yZXNwb25kV2l0aChyZXNwb25zZSk7XG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9XG5cdFx0LyoqXG5cdFx0KiBIYW5kbGUgbm9ybWFsIHJlc3BvbnNlcyBvciByZXNwb25zZS1saWtlIG9iamVjdHMuXG5cdFx0KiBAbm90ZSBUaGlzIG11c3QgY29tZSBiZWZvcmUgdGhlIGFyYml0cmFyeSBvYmplY3QgY2hlY2tcblx0XHQqIHNpbmNlIFJlc3BvbnNlIGluc3RhbmNlcyBhcmUsIGluIGZhY3QsIG9iamVjdHMuXG5cdFx0Ki9cblx0XHRpZiAoaXNSZXNwb25zZUxpa2UocmVzcG9uc2UpKSB7XG5cdFx0XHRhd2FpdCBvcHRpb25zLmNvbnRyb2xsZXIucmVzcG9uZFdpdGgocmVzcG9uc2UpO1xuXHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0fVxuXHRcdGlmIChpc09iamVjdChyZXNwb25zZSkpIHtcblx0XHRcdGF3YWl0IG9wdGlvbnMuY29udHJvbGxlci5lcnJvcldpdGgocmVzcG9uc2UpO1xuXHRcdFx0cmV0dXJuIHRydWU7XG5cdFx0fVxuXHRcdHJldHVybiBmYWxzZTtcblx0fTtcblx0Y29uc3QgaGFuZGxlUmVzcG9uc2VFcnJvciA9IGFzeW5jIChlcnJvcikgPT4ge1xuXHRcdGlmIChlcnJvciBpbnN0YW5jZW9mIEludGVyY2VwdG9yRXJyb3IpIHRocm93IHJlc3VsdEVycm9yO1xuXHRcdGlmIChpc05vZGVMaWtlRXJyb3IoZXJyb3IpKSB7XG5cdFx0XHRhd2FpdCBvcHRpb25zLmNvbnRyb2xsZXIuZXJyb3JXaXRoKGVycm9yKTtcblx0XHRcdHJldHVybiB0cnVlO1xuXHRcdH1cblx0XHRpZiAoZXJyb3IgaW5zdGFuY2VvZiBSZXNwb25zZSkgcmV0dXJuIGF3YWl0IGhhbmRsZVJlc3BvbnNlKGVycm9yKTtcblx0XHRyZXR1cm4gZmFsc2U7XG5cdH07XG5cdGNvbnN0IHJlcXVlc3RBYm9ydFByb21pc2UgPSBQcm9taXNlLndpdGhSZXNvbHZlcnMoKTtcblx0bGV0IHJlcXVlc3RBYm9ydFJlYXNvbjtcblx0bGV0IGlzUmVxdWVzdEFib3J0ZWQgPSBmYWxzZTtcblx0Y29uc3Qgb25BYm9ydCA9ICgpID0+IHtcblx0XHRpc1JlcXVlc3RBYm9ydGVkID0gdHJ1ZTtcblx0XHRyZXF1ZXN0QWJvcnRSZWFzb24gPSBvcHRpb25zLnJlcXVlc3Quc2lnbmFsPy5yZWFzb247XG5cdFx0cmVxdWVzdEFib3J0UHJvbWlzZS5yZWplY3QocmVxdWVzdEFib3J0UmVhc29uKTtcblx0fTtcblx0LyoqXG5cdCogQG5vdGUgYHNpZ25hbGAgaXMgbm90IGFsd2F5cyBkZWZpbmVkIGluIFJlYWN0IE5hdGl2ZS5cblx0Ki9cblx0aWYgKG9wdGlvbnMucmVxdWVzdC5zaWduYWwpIHtcblx0XHRpZiAob3B0aW9ucy5yZXF1ZXN0LnNpZ25hbC5hYm9ydGVkKSB7XG5cdFx0XHRhd2FpdCBvcHRpb25zLmNvbnRyb2xsZXIuZXJyb3JXaXRoKG9wdGlvbnMucmVxdWVzdC5zaWduYWwucmVhc29uKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0b3B0aW9ucy5yZXF1ZXN0LnNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgb25BYm9ydCwgeyBvbmNlOiB0cnVlIH0pO1xuXHR9XG5cdGNvbnN0IFtyZXN1bHRFcnJvcl0gPSBhd2FpdCB1bnRpbChhc3luYyAoKSA9PiB7XG5cdFx0Y29uc3QgcmVxdWVzdEV2ZW50ID0gbmV3IEh0dHBSZXF1ZXN0RXZlbnQoe1xuXHRcdFx0aW5pdGlhdG9yOiBvcHRpb25zLmluaXRpYXRvcixcblx0XHRcdHJlcXVlc3RJZDogb3B0aW9ucy5yZXF1ZXN0SWQsXG5cdFx0XHRyZXF1ZXN0OiBvcHRpb25zLnJlcXVlc3QsXG5cdFx0XHRjb250cm9sbGVyOiBvcHRpb25zLmNvbnRyb2xsZXJcblx0XHR9KTtcblx0XHRjb25zdCByZXF1ZXN0TGlzdGVuZXJzUHJvbWlzZSA9IG9wdGlvbnMuZW1pdHRlci5lbWl0QXNQcm9taXNlKHJlcXVlc3RFdmVudCk7XG5cdFx0YXdhaXQgUHJvbWlzZS5yYWNlKFtcblx0XHRcdHJlcXVlc3RBYm9ydFByb21pc2UucHJvbWlzZSxcblx0XHRcdHJlcXVlc3RMaXN0ZW5lcnNQcm9taXNlLFxuXHRcdFx0b3B0aW9ucy5jb250cm9sbGVyLmhhbmRsZWRcblx0XHRdKTtcblx0XHQvKipcblx0XHQqIEBub3RlIElmIHRoZSBcInJlcXVlc3RcIiBsaXN0ZW5lciBoYXMgcmVwbGFjZWQgdGhlIHJlcXVlc3QgaW5zdGFuY2UsXG5cdFx0KiBwcm9wYWdhdGUgdGhhdCBtdXRhdGlvbiBiYWNrIHRvIHRoZSB1bmRlcmx5aW5nIGluc3RlcmNlcHRvci5cblx0XHQqIFRoaXMgaGFwcGVucyB3aXRoIFhNTEh0dHBSZXF1ZXN0IHRoYXQgcmVwbGFjZXMgcmVxdWVzdCBpbnN0YW5jZXNcblx0XHQqIHRvIGNvcnJlY3RseSByZWZsZWN0IHRoZSBcIndpdGhDcmVkZW50aWFsc1wiIG9wdGlvbiBvbiB0aGUgRmV0Y2ggQVBJIHJlcXVlc3QuXG5cdFx0Ki9cblx0XHRpZiAocmVxdWVzdEV2ZW50LnJlcXVlc3QgIT09IG9wdGlvbnMucmVxdWVzdCkgb3B0aW9ucy5yZXF1ZXN0ID0gcmVxdWVzdEV2ZW50LnJlcXVlc3Q7XG5cdH0pO1xuXHRvcHRpb25zLnJlcXVlc3Quc2lnbmFsPy5yZW1vdmVFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgb25BYm9ydCk7XG5cdGlmIChpc1JlcXVlc3RBYm9ydGVkKSB7XG5cdFx0YXdhaXQgb3B0aW9ucy5jb250cm9sbGVyLmVycm9yV2l0aChyZXF1ZXN0QWJvcnRSZWFzb24pO1xuXHRcdHJldHVybjtcblx0fVxuXHRpZiAocmVzdWx0RXJyb3IpIHtcblx0XHRpZiAoYXdhaXQgaGFuZGxlUmVzcG9uc2VFcnJvcihyZXN1bHRFcnJvcikpIHJldHVybjtcblx0XHRpZiAob3B0aW9ucy5lbWl0dGVyLmxpc3RlbmVyQ291bnQoXCJ1bmhhbmRsZWRFeGNlcHRpb25cIikgPiAwKSB7XG5cdFx0XHRjb25zdCB1bmhhbmRsZWRFeGNlcHRpb25Db250cm9sbGVyID0gbmV3IFJlcXVlc3RDb250cm9sbGVyKG9wdGlvbnMucmVxdWVzdCwge1xuXHRcdFx0XHQvKipcblx0XHRcdFx0KiBAbm90ZSBJbnRlbnRpb25hbGx5IGVtcHR5IHBhc3N0aHJvdWdoIGhhbmRsZS5cblx0XHRcdFx0KiBUaGlzIGNvbnRyb2xsZXIgaXMgY3JlYXRlZCB3aXRoaW4gYW5vdGhlciBjb250cm9sbGVyIGFuZCB3ZSBvbmx5IG5lZWRcblx0XHRcdFx0KiB0byBrbm93IGlmIGB1bmhhbmRsZWRFeGNlcHRpb25gIGxpc3RlbmVycyBoYW5kbGVkIHRoZSByZXF1ZXN0LlxuXHRcdFx0XHQqL1xuXHRcdFx0XHRwYXNzdGhyb3VnaCgpIHt9LFxuXHRcdFx0XHRhc3luYyByZXNwb25kV2l0aChyZXNwb25zZSkge1xuXHRcdFx0XHRcdGF3YWl0IGhhbmRsZVJlc3BvbnNlKHJlc3BvbnNlKTtcblx0XHRcdFx0fSxcblx0XHRcdFx0YXN5bmMgZXJyb3JXaXRoKHJlYXNvbikge1xuXHRcdFx0XHRcdC8qKlxuXHRcdFx0XHRcdCogQG5vdGUgSGFuZGxlIHRoZSByZXN1bHQgb2YgdGhlIHVuaGFuZGxlZCBjb250cm9sbGVyXG5cdFx0XHRcdFx0KiBpbiB0aGUgc2FtZSB3YXkgYXMgdGhlIG9yaWdpbmFsIHJlcXVlc3QgY29udHJvbGxlci5cblx0XHRcdFx0XHQqIFRoZSBleGNlcHRpb24gaGVyZSBpcyB0aGF0IHRocm93biBlcnJvcnMgd2l0aGluIHRoZVxuXHRcdFx0XHRcdCogXCJ1bmhhbmRsZWRFeGNlcHRpb25cIiBldmVudCBkbyBOT1QgcmVzdWx0IGluIGFub3RoZXJcblx0XHRcdFx0XHQqIGVtaXQgb2YgdGhlIHNhbWUgZXZlbnQuIFRoZXkgYXJlIGZvcndhcmRlZCBhcy1pcy5cblx0XHRcdFx0XHQqL1xuXHRcdFx0XHRcdGF3YWl0IG9wdGlvbnMuY29udHJvbGxlci5lcnJvcldpdGgocmVhc29uKTtcblx0XHRcdFx0fVxuXHRcdFx0fSk7XG5cdFx0XHRhd2FpdCBvcHRpb25zLmVtaXR0ZXIuZW1pdEFzUHJvbWlzZShuZXcgVW5oYW5kbGVkSHR0cEV4Y2VwdGlvbih7XG5cdFx0XHRcdGluaXRpYXRvcjogb3B0aW9ucy5pbml0aWF0b3IsXG5cdFx0XHRcdGVycm9yOiByZXN1bHRFcnJvcixcblx0XHRcdFx0cmVxdWVzdDogb3B0aW9ucy5yZXF1ZXN0LFxuXHRcdFx0XHRyZXF1ZXN0SWQ6IG9wdGlvbnMucmVxdWVzdElkLFxuXHRcdFx0XHRjb250cm9sbGVyOiB1bmhhbmRsZWRFeGNlcHRpb25Db250cm9sbGVyXG5cdFx0XHR9KSk7XG5cdFx0XHRpZiAodW5oYW5kbGVkRXhjZXB0aW9uQ29udHJvbGxlci5yZWFkeVN0YXRlICE9PSBSZXF1ZXN0Q29udHJvbGxlci5QRU5ESU5HKSByZXR1cm47XG5cdFx0fVxuXHRcdGF3YWl0IG9wdGlvbnMuY29udHJvbGxlci5yZXNwb25kV2l0aChjcmVhdGVTZXJ2ZXJFcnJvclJlc3BvbnNlKHJlc3VsdEVycm9yKSk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGlmIChvcHRpb25zLmNvbnRyb2xsZXIucmVhZHlTdGF0ZSA9PT0gUmVxdWVzdENvbnRyb2xsZXIuUEVORElORykgcmV0dXJuIGF3YWl0IG9wdGlvbnMuY29udHJvbGxlci5wYXNzdGhyb3VnaCgpO1xuXHRyZXR1cm4gb3B0aW9ucy5jb250cm9sbGVyLmhhbmRsZWQ7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEh0dHBSZXNwb25zZUV2ZW50IGFzIG4sIGhhbmRsZVJlcXVlc3QgYXMgdCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1oYW5kbGUtcmVxdWVzdC15N2FqeXZlNS5qcy5tYXAiLCJpbXBvcnQgeyBuIGFzIEludGVyY2VwdG9yLCByIGFzIGNyZWF0ZUxvZ2dlciwgdCBhcyBjcmVhdGVSZXF1ZXN0SWQgfSBmcm9tIFwiLi9jcmVhdGUtcmVxdWVzdC1pZC1Zb2JVbkpOTy5qc1wiO1xuaW1wb3J0IHsgYyBhcyBSZXF1ZXN0Q29udHJvbGxlciwgaSBhcyBpc1Jlc3BvbnNlRXJyb3IsIG4gYXMgRmV0Y2hSZXNwb25zZSwgdCBhcyBGZXRjaFJlcXVlc3QgfSBmcm9tIFwiLi9mZXRjaC11dGlscy1DNlA2Z0xMby5qc1wiO1xuaW1wb3J0IHsgbiBhcyBlbmNvZGVCdWZmZXIsIHIgYXMgdG9BcnJheUJ1ZmZlciwgdCBhcyBkZWNvZGVCdWZmZXIgfSBmcm9tIFwiLi9idWZmZXItdXRpbHMtREpqN1l6TEcuanNcIjtcbmltcG9ydCB7IG4gYXMgSHR0cFJlc3BvbnNlRXZlbnQsIHQgYXMgaGFuZGxlUmVxdWVzdCB9IGZyb20gXCIuL2hhbmRsZS1yZXF1ZXN0LXk3YWp5dmU1LmpzXCI7XG5pbXBvcnQgeyBuIGFzIHBhdGNoZXNSZWdpc3RyeSwgdCBhcyBoYXNDb25maWd1cmFibGVHbG9iYWwgfSBmcm9tIFwiLi9oYXMtY29uZmlndXJhYmxlLWdsb2JhbC1DZXctZFlxay5qc1wiO1xuaW1wb3J0IHsgaW52YXJpYW50IH0gZnJvbSBcIm91dHZhcmlhbnRcIjtcbmltcG9ydCB7IHVudGlsIH0gZnJvbSBcIkBvcGVuLWRyYWZ0L3VudGlsXCI7XG4vLyNyZWdpb24gc3JjL2ludGVyY2VwdG9ycy9YTUxIdHRwUmVxdWVzdC91dGlscy9jb25jYXQtYXJyYXktYnVmZmVyLnRzXG4vKipcbiogQ29uY2F0ZW5hdGUgdHdvIGBVaW50OEFycmF5YCBidWZmZXJzLlxuKi9cbmZ1bmN0aW9uIGNvbmNhdEFycmF5QnVmZmVyKGxlZnQsIHJpZ2h0KSB7XG5cdGNvbnN0IHJlc3VsdCA9IG5ldyBVaW50OEFycmF5KGxlZnQuYnl0ZUxlbmd0aCArIHJpZ2h0LmJ5dGVMZW5ndGgpO1xuXHRyZXN1bHQuc2V0KGxlZnQsIDApO1xuXHRyZXN1bHQuc2V0KHJpZ2h0LCBsZWZ0LmJ5dGVMZW5ndGgpO1xuXHRyZXR1cm4gcmVzdWx0O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2ludGVyY2VwdG9ycy9YTUxIdHRwUmVxdWVzdC9wb2x5ZmlsbHMvZXZlbnQtcG9seWZpbGwudHNcbnZhciBFdmVudFBvbHlmaWxsID0gY2xhc3Mge1xuXHRjb25zdHJ1Y3Rvcih0eXBlLCBvcHRpb25zKSB7XG5cdFx0dGhpcy5OT05FID0gMDtcblx0XHR0aGlzLkNBUFRVUklOR19QSEFTRSA9IDE7XG5cdFx0dGhpcy5BVF9UQVJHRVQgPSAyO1xuXHRcdHRoaXMuQlVCQkxJTkdfUEhBU0UgPSAzO1xuXHRcdHRoaXMudHlwZSA9IFwiXCI7XG5cdFx0dGhpcy5zcmNFbGVtZW50ID0gbnVsbDtcblx0XHR0aGlzLmN1cnJlbnRUYXJnZXQgPSBudWxsO1xuXHRcdHRoaXMuZXZlbnRQaGFzZSA9IDA7XG5cdFx0dGhpcy5pc1RydXN0ZWQgPSB0cnVlO1xuXHRcdHRoaXMuY29tcG9zZWQgPSBmYWxzZTtcblx0XHR0aGlzLmNhbmNlbGFibGUgPSB0cnVlO1xuXHRcdHRoaXMuZGVmYXVsdFByZXZlbnRlZCA9IGZhbHNlO1xuXHRcdHRoaXMuYnViYmxlcyA9IHRydWU7XG5cdFx0dGhpcy5sZW5ndGhDb21wdXRhYmxlID0gdHJ1ZTtcblx0XHR0aGlzLmxvYWRlZCA9IDA7XG5cdFx0dGhpcy50b3RhbCA9IDA7XG5cdFx0dGhpcy5jYW5jZWxCdWJibGUgPSBmYWxzZTtcblx0XHR0aGlzLnJldHVyblZhbHVlID0gdHJ1ZTtcblx0XHR0aGlzLnR5cGUgPSB0eXBlO1xuXHRcdHRoaXMudGFyZ2V0ID0gb3B0aW9ucz8udGFyZ2V0IHx8IG51bGw7XG5cdFx0dGhpcy5jdXJyZW50VGFyZ2V0ID0gb3B0aW9ucz8uY3VycmVudFRhcmdldCB8fCBudWxsO1xuXHRcdHRoaXMudGltZVN0YW1wID0gRGF0ZS5ub3coKTtcblx0fVxuXHRjb21wb3NlZFBhdGgoKSB7XG5cdFx0cmV0dXJuIFtdO1xuXHR9XG5cdGluaXRFdmVudCh0eXBlLCBidWJibGVzLCBjYW5jZWxhYmxlKSB7XG5cdFx0dGhpcy50eXBlID0gdHlwZTtcblx0XHR0aGlzLmJ1YmJsZXMgPSAhIWJ1YmJsZXM7XG5cdFx0dGhpcy5jYW5jZWxhYmxlID0gISFjYW5jZWxhYmxlO1xuXHR9XG5cdHByZXZlbnREZWZhdWx0KCkge1xuXHRcdHRoaXMuZGVmYXVsdFByZXZlbnRlZCA9IHRydWU7XG5cdH1cblx0c3RvcFByb3BhZ2F0aW9uKCkge31cblx0c3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCkge31cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvaW50ZXJjZXB0b3JzL1hNTEh0dHBSZXF1ZXN0L3BvbHlmaWxscy9wcm9ncmVzcy1ldmVudC1wb2x5ZmlsbC50c1xudmFyIFByb2dyZXNzRXZlbnRQb2x5ZmlsbCA9IGNsYXNzIGV4dGVuZHMgRXZlbnRQb2x5ZmlsbCB7XG5cdGNvbnN0cnVjdG9yKHR5cGUsIGluaXQpIHtcblx0XHRzdXBlcih0eXBlKTtcblx0XHR0aGlzLmxlbmd0aENvbXB1dGFibGUgPSBpbml0Py5sZW5ndGhDb21wdXRhYmxlIHx8IGZhbHNlO1xuXHRcdHRoaXMuY29tcG9zZWQgPSBpbml0Py5jb21wb3NlZCB8fCBmYWxzZTtcblx0XHR0aGlzLmxvYWRlZCA9IGluaXQ/LmxvYWRlZCB8fCAwO1xuXHRcdHRoaXMudG90YWwgPSBpbml0Py50b3RhbCB8fCAwO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2ludGVyY2VwdG9ycy9YTUxIdHRwUmVxdWVzdC91dGlscy9jcmVhdGUtZXZlbnQudHNcbmNvbnN0IFNVUFBPUlRTX1BST0dSRVNTX0VWRU5UID0gdHlwZW9mIFByb2dyZXNzRXZlbnQgIT09IFwidW5kZWZpbmVkXCI7XG5mdW5jdGlvbiBjcmVhdGVFdmVudCh0YXJnZXQsIHR5cGUsIGluaXQpIHtcblx0Y29uc3QgcHJvZ3Jlc3NFdmVudHMgPSBbXG5cdFx0XCJlcnJvclwiLFxuXHRcdFwicHJvZ3Jlc3NcIixcblx0XHRcImxvYWRzdGFydFwiLFxuXHRcdFwibG9hZGVuZFwiLFxuXHRcdFwibG9hZFwiLFxuXHRcdFwidGltZW91dFwiLFxuXHRcdFwiYWJvcnRcIlxuXHRdO1xuXHQvKipcblx0KiBgUHJvZ3Jlc3NFdmVudGAgaXMgbm90IHN1cHBvcnRlZCBpbiBSZWFjdCBOYXRpdmUuXG5cdCogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vbXN3anMvaW50ZXJjZXB0b3JzL2lzc3Vlcy80MFxuXHQqL1xuXHRjb25zdCBQcm9ncmVzc0V2ZW50Q2xhc3MgPSBTVVBQT1JUU19QUk9HUkVTU19FVkVOVCA/IFByb2dyZXNzRXZlbnQgOiBQcm9ncmVzc0V2ZW50UG9seWZpbGw7XG5cdHJldHVybiBwcm9ncmVzc0V2ZW50cy5pbmNsdWRlcyh0eXBlKSA/IG5ldyBQcm9ncmVzc0V2ZW50Q2xhc3ModHlwZSwge1xuXHRcdGxlbmd0aENvbXB1dGFibGU6IHRydWUsXG5cdFx0bG9hZGVkOiBpbml0Py5sb2FkZWQgfHwgMCxcblx0XHR0b3RhbDogaW5pdD8udG90YWwgfHwgMFxuXHR9KSA6IG5ldyBFdmVudFBvbHlmaWxsKHR5cGUsIHtcblx0XHR0YXJnZXQsXG5cdFx0Y3VycmVudFRhcmdldDogdGFyZ2V0XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3V0aWxzL2ZpbmQtcHJvcGVydHktc291cmNlLnRzXG4vKipcbiogUmV0dXJucyB0aGUgc291cmNlIG9iamVjdCBvZiB0aGUgZ2l2ZW4gcHJvcGVydHkgb24gdGhlIHRhcmdldCBvYmplY3RcbiogKHRoZSB0YXJnZXQgaXRzZWxmLCBhbnkgcGFyZW50IGluIGl0cyBwcm90b3R5cGUsIG9yIG51bGwpLlxuKi9cbmZ1bmN0aW9uIGZpbmRQcm9wZXJ0eVNvdXJjZSh0YXJnZXQsIHByb3BlcnR5TmFtZSkge1xuXHRpZiAoIShwcm9wZXJ0eU5hbWUgaW4gdGFyZ2V0KSkgcmV0dXJuIG51bGw7XG5cdGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwodGFyZ2V0LCBwcm9wZXJ0eU5hbWUpKSByZXR1cm4gdGFyZ2V0O1xuXHRjb25zdCBwcm90b3R5cGUgPSBSZWZsZWN0LmdldFByb3RvdHlwZU9mKHRhcmdldCk7XG5cdHJldHVybiBwcm90b3R5cGUgPyBmaW5kUHJvcGVydHlTb3VyY2UocHJvdG90eXBlLCBwcm9wZXJ0eU5hbWUpIDogbnVsbDtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy91dGlscy9jcmVhdGUtcHJveHkudHNcbmZ1bmN0aW9uIGNyZWF0ZVByb3h5KHRhcmdldCwgb3B0aW9ucykge1xuXHRyZXR1cm4gbmV3IFByb3h5KHRhcmdldCwgb3B0aW9uc1RvUHJveHlIYW5kbGVyKG9wdGlvbnMpKTtcbn1cbmZ1bmN0aW9uIG9wdGlvbnNUb1Byb3h5SGFuZGxlcihvcHRpb25zKSB7XG5cdGNvbnN0IHsgY29uc3RydWN0b3JDYWxsLCBtZXRob2RDYWxsLCBnZXRQcm9wZXJ0eSwgc2V0UHJvcGVydHkgfSA9IG9wdGlvbnM7XG5cdGNvbnN0IGhhbmRsZXIgPSB7fTtcblx0aWYgKHR5cGVvZiBjb25zdHJ1Y3RvckNhbGwgIT09IFwidW5kZWZpbmVkXCIpIGhhbmRsZXIuY29uc3RydWN0ID0gZnVuY3Rpb24odGFyZ2V0LCBhcmdzLCBuZXdUYXJnZXQpIHtcblx0XHRjb25zdCBuZXh0ID0gUmVmbGVjdC5jb25zdHJ1Y3QuYmluZChudWxsLCB0YXJnZXQsIGFyZ3MsIG5ld1RhcmdldCk7XG5cdFx0cmV0dXJuIGNvbnN0cnVjdG9yQ2FsbC5jYWxsKG5ld1RhcmdldCwgYXJncywgbmV4dCk7XG5cdH07XG5cdGhhbmRsZXIuc2V0ID0gZnVuY3Rpb24odGFyZ2V0LCBwcm9wZXJ0eU5hbWUsIG5leHRWYWx1ZSkge1xuXHRcdGNvbnN0IG5leHQgPSAoKSA9PiB7XG5cdFx0XHRjb25zdCBwcm9wZXJ0eVNvdXJjZSA9IGZpbmRQcm9wZXJ0eVNvdXJjZSh0YXJnZXQsIHByb3BlcnR5TmFtZSkgfHwgdGFyZ2V0O1xuXHRcdFx0Y29uc3Qgb3duRGVzY3JpcHRvcnMgPSBSZWZsZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihwcm9wZXJ0eVNvdXJjZSwgcHJvcGVydHlOYW1lKTtcblx0XHRcdGlmICh0eXBlb2Ygb3duRGVzY3JpcHRvcnM/LnNldCAhPT0gXCJ1bmRlZmluZWRcIikge1xuXHRcdFx0XHRvd25EZXNjcmlwdG9ycy5zZXQuYXBwbHkodGFyZ2V0LCBbbmV4dFZhbHVlXSk7XG5cdFx0XHRcdHJldHVybiB0cnVlO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIFJlZmxlY3QuZGVmaW5lUHJvcGVydHkocHJvcGVydHlTb3VyY2UsIHByb3BlcnR5TmFtZSwge1xuXHRcdFx0XHR3cml0YWJsZTogdHJ1ZSxcblx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdFx0Y29uZmlndXJhYmxlOiB0cnVlLFxuXHRcdFx0XHR2YWx1ZTogbmV4dFZhbHVlXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdGlmICh0eXBlb2Ygc2V0UHJvcGVydHkgIT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBzZXRQcm9wZXJ0eS5jYWxsKHRhcmdldCwgW3Byb3BlcnR5TmFtZSwgbmV4dFZhbHVlXSwgbmV4dCk7XG5cdFx0cmV0dXJuIG5leHQoKTtcblx0fTtcblx0aGFuZGxlci5nZXQgPSBmdW5jdGlvbih0YXJnZXQsIHByb3BlcnR5TmFtZSwgcmVjZWl2ZXIpIHtcblx0XHQvKipcblx0XHQqIEBub3RlIFVzaW5nIGBSZWZsZWN0LmdldCgpYCBoZXJlIGNhdXNlcyBcIlR5cGVFcnJvcjogSWxsZWdhbCBpbnZvY2F0aW9uXCIuXG5cdFx0Ki9cblx0XHRjb25zdCBuZXh0ID0gKCkgPT4gdGFyZ2V0W3Byb3BlcnR5TmFtZV07XG5cdFx0Y29uc3QgdmFsdWUgPSB0eXBlb2YgZ2V0UHJvcGVydHkgIT09IFwidW5kZWZpbmVkXCIgPyBnZXRQcm9wZXJ0eS5jYWxsKHRhcmdldCwgW3Byb3BlcnR5TmFtZSwgcmVjZWl2ZXJdLCBuZXh0KSA6IG5leHQoKTtcblx0XHRpZiAodHlwZW9mIHZhbHVlID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiAoLi4uYXJncykgPT4ge1xuXHRcdFx0Y29uc3QgbmV4dCA9IHZhbHVlLmJpbmQodGFyZ2V0LCAuLi5hcmdzKTtcblx0XHRcdGlmICh0eXBlb2YgbWV0aG9kQ2FsbCAhPT0gXCJ1bmRlZmluZWRcIikgcmV0dXJuIG1ldGhvZENhbGwuY2FsbCh0YXJnZXQsIFtwcm9wZXJ0eU5hbWUsIGFyZ3NdLCBuZXh0KTtcblx0XHRcdHJldHVybiBuZXh0KCk7XG5cdFx0fTtcblx0XHRyZXR1cm4gdmFsdWU7XG5cdH07XG5cdHJldHVybiBoYW5kbGVyO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2ludGVyY2VwdG9ycy9YTUxIdHRwUmVxdWVzdC91dGlscy9pcy1kb20tcGFyc2VyLXN1cHBvcnRlZC10eXBlLnRzXG5mdW5jdGlvbiBpc0RvbVBhcnNlclN1cHBvcnRlZFR5cGUodHlwZSkge1xuXHRyZXR1cm4gW1xuXHRcdFwiYXBwbGljYXRpb24veGh0bWwreG1sXCIsXG5cdFx0XCJhcHBsaWNhdGlvbi94bWxcIixcblx0XHRcImltYWdlL3N2Zyt4bWxcIixcblx0XHRcInRleHQvaHRtbFwiLFxuXHRcdFwidGV4dC94bWxcIlxuXHRdLnNvbWUoKHN1cHBvcnRlZFR5cGUpID0+IHtcblx0XHRyZXR1cm4gdHlwZS5zdGFydHNXaXRoKHN1cHBvcnRlZFR5cGUpO1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy91dGlscy9wYXJzZS1qc29uLnRzXG4vKipcbiogUGFyc2VzIGEgZ2l2ZW4gc3RyaW5nIGludG8gSlNPTi5cbiogR3JhY2VmdWxseSBoYW5kbGVzIGludmFsaWQgSlNPTiBieSByZXR1cm5pbmcgYG51bGxgLlxuKi9cbmZ1bmN0aW9uIHBhcnNlSnNvbihkYXRhKSB7XG5cdHRyeSB7XG5cdFx0cmV0dXJuIEpTT04ucGFyc2UoZGF0YSk7XG5cdH0gY2F0Y2ggKF8pIHtcblx0XHRyZXR1cm4gbnVsbDtcblx0fVxufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2ludGVyY2VwdG9ycy9YTUxIdHRwUmVxdWVzdC91dGlscy9jcmVhdGUtcmVzcG9uc2UudHNcbi8qKlxuKiBDcmVhdGVzIGEgRmV0Y2ggQVBJIGBSZXNwb25zZWAgaW5zdGFuY2UgZnJvbSB0aGUgZ2l2ZW5cbiogYFhNTEh0dHBSZXF1ZXN0YCBpbnN0YW5jZSBhbmQgYSByZXNwb25zZSBib2R5LlxuKi9cbmZ1bmN0aW9uIGNyZWF0ZVJlc3BvbnNlKHJlcXVlc3QsIGJvZHkpIHtcblx0LyoqXG5cdCogSGFuZGxlIFhNTEh0dHBSZXF1ZXN0IHJlc3BvbnNlcyB0aGF0IG11c3QgaGF2ZSBudWxsIGFzIHRoZVxuXHQqIHJlc3BvbnNlIGJvZHkgd2hlbiByZXByZXNlbnRlZCB1c2luZyBGZXRjaCBBUEkgUmVzcG9uc2UuXG5cdCogWE1MSHR0cFJlcXVlc3QgcmVzcG9uc2Ugd2lsbCBhbHdheXMgaGF2ZSBhbiBlbXB0eSBzdHJpbmdcblx0KiBhcyB0aGUgXCJyZXF1ZXN0LnJlc3BvbnNlXCIgaW4gdGhvc2UgY2FzZXMsIHJlc3VsdGluZyBpbiBhbiBlcnJvclxuXHQqIHdoZW4gY29uc3RydWN0aW5nIGEgUmVzcG9uc2UgaW5zdGFuY2UuXG5cdCogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vbXN3anMvaW50ZXJjZXB0b3JzL2lzc3Vlcy8zNzlcblx0Ki9cblx0Y29uc3QgcmVzcG9uc2VCb2R5T3JOdWxsID0gRmV0Y2hSZXNwb25zZS5pc1Jlc3BvbnNlV2l0aEJvZHkocmVxdWVzdC5zdGF0dXMpID8gYm9keSA6IG51bGw7XG5cdHJldHVybiBuZXcgRmV0Y2hSZXNwb25zZShyZXNwb25zZUJvZHlPck51bGwsIHtcblx0XHR1cmw6IHJlcXVlc3QucmVzcG9uc2VVUkwsXG5cdFx0c3RhdHVzOiByZXF1ZXN0LnN0YXR1cyxcblx0XHRzdGF0dXNUZXh0OiByZXF1ZXN0LnN0YXR1c1RleHQsXG5cdFx0aGVhZGVyczogY3JlYXRlSGVhZGVyc0Zyb21YTUxIdHRwUmVxdWVzdEhlYWRlcnMocmVxdWVzdC5nZXRBbGxSZXNwb25zZUhlYWRlcnMoKSlcblx0fSk7XG59XG5mdW5jdGlvbiBjcmVhdGVIZWFkZXJzRnJvbVhNTEh0dHBSZXF1ZXN0SGVhZGVycyhoZWFkZXJzU3RyaW5nKSB7XG5cdGNvbnN0IGhlYWRlcnMgPSBuZXcgSGVhZGVycygpO1xuXHRjb25zdCBsaW5lcyA9IGhlYWRlcnNTdHJpbmcuc3BsaXQoL1tcXHJcXG5dKy8pO1xuXHRmb3IgKGNvbnN0IGxpbmUgb2YgbGluZXMpIHtcblx0XHRpZiAobGluZS50cmltKCkgPT09IFwiXCIpIGNvbnRpbnVlO1xuXHRcdGNvbnN0IFtuYW1lLCAuLi5wYXJ0c10gPSBsaW5lLnNwbGl0KFwiOiBcIik7XG5cdFx0Y29uc3QgdmFsdWUgPSBwYXJ0cy5qb2luKFwiOiBcIik7XG5cdFx0aGVhZGVycy5hcHBlbmQobmFtZSwgdmFsdWUpO1xuXHR9XG5cdHJldHVybiBoZWFkZXJzO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2ludGVyY2VwdG9ycy9YTUxIdHRwUmVxdWVzdC91dGlscy9nZXQtYm9keS1ieXRlLWxlbmd0aC50c1xuLyoqXG4qIFJldHVybiBhIHRvdGFsIGJ5dGUgbGVuZ3RoIG9mIHRoZSBnaXZlbiByZXF1ZXN0L3Jlc3BvbnNlIGJvZHkuXG4qIElmIHRoZSBgQ29udGVudC1MZW5ndGhgIGhlYWRlciBpcyBwcmVzZW50LCBpdCB3aWxsIGJlIHVzZWQgYXMgdGhlIGJ5dGUgbGVuZ3RoLlxuKi9cbmFzeW5jIGZ1bmN0aW9uIGdldEJvZHlCeXRlTGVuZ3RoKGlucHV0KSB7XG5cdGNvbnN0IGV4cGxpY2l0Q29udGVudExlbmd0aCA9IGlucHV0LmhlYWRlcnMuZ2V0KFwiY29udGVudC1sZW5ndGhcIik7XG5cdGlmIChleHBsaWNpdENvbnRlbnRMZW5ndGggIT0gbnVsbCAmJiBleHBsaWNpdENvbnRlbnRMZW5ndGggIT09IFwiXCIpIHJldHVybiBOdW1iZXIoZXhwbGljaXRDb250ZW50TGVuZ3RoKTtcblx0cmV0dXJuIChhd2FpdCBpbnB1dC5hcnJheUJ1ZmZlcigpKS5ieXRlTGVuZ3RoO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2ludGVyY2VwdG9ycy9YTUxIdHRwUmVxdWVzdC94bWwtaHR0cC1yZXF1ZXN0LWNvbnRyb2xsZXIudHNcbmNvbnN0IGtJc1JlcXVlc3RIYW5kbGVkID0gU3ltYm9sKFwia0lzUmVxdWVzdEhhbmRsZWRcIik7XG5jb25zdCBrRmV0Y2hSZXF1ZXN0ID0gU3ltYm9sKFwia0ZldGNoUmVxdWVzdFwiKTtcbmNvbnN0IE1BWF9SRURJUkVDVFMgPSAyMDtcbi8qKlxuKiBBbiBgWE1MSHR0cFJlcXVlc3RgIGluc3RhbmNlIGNvbnRyb2xsZXIgdGhhdCBhbGxvd3MgdXNcbiogdG8gaGFuZGxlIGFueSBnaXZlbiByZXF1ZXN0IGluc3RhbmNlIChlLmcuIHJlc3BvbmRpbmcgdG8gaXQpLlxuKi9cbnZhciBYTUxIdHRwUmVxdWVzdENvbnRyb2xsZXIgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKGluaXRpYWxSZXF1ZXN0LCBsb2dnZXIpIHtcblx0XHR0aGlzLmluaXRpYWxSZXF1ZXN0ID0gaW5pdGlhbFJlcXVlc3Q7XG5cdFx0dGhpcy5sb2dnZXIgPSBsb2dnZXI7XG5cdFx0dGhpcy5zeW5jID0gZmFsc2U7XG5cdFx0dGhpcy5tZXRob2QgPSBcIkdFVFwiO1xuXHRcdHRoaXMudXJsID0gbnVsbDtcblx0XHR0aGlzW2tJc1JlcXVlc3RIYW5kbGVkXSA9IGZhbHNlO1xuXHRcdHRoaXMucmVkaXJlY3RDb3VudCA9IDA7XG5cdFx0dGhpcy5ldmVudHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdHRoaXMudXBsb2FkRXZlbnRzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHR0aGlzLnJlcXVlc3RJZCA9IGNyZWF0ZVJlcXVlc3RJZCgpO1xuXHRcdHRoaXMucmVxdWVzdEhlYWRlcnMgPSBuZXcgSGVhZGVycygpO1xuXHRcdHRoaXMucmVzcG9uc2VCdWZmZXIgPSAvKiBAX19QVVJFX18gKi8gbmV3IFVpbnQ4QXJyYXkoKTtcblx0XHR0aGlzLnJlcXVlc3QgPSBjcmVhdGVQcm94eShpbml0aWFsUmVxdWVzdCwgeyBtZXRob2RDYWxsOiAoW21ldGhvZE5hbWUsIGFyZ3NdLCBpbnZva2UpID0+IHtcblx0XHRcdHN3aXRjaCAobWV0aG9kTmFtZSkge1xuXHRcdFx0XHRjYXNlIFwib3BlblwiOiB7XG5cdFx0XHRcdFx0Y29uc3QgW21ldGhvZCwgdXJsLCBhc3luY10gPSBhcmdzO1xuXHRcdFx0XHRcdHRoaXMuc3luYyA9ICEoYXN5bmMgPz8gdHJ1ZSk7XG5cdFx0XHRcdFx0aWYgKHR5cGVvZiB1cmwgPT09IFwidW5kZWZpbmVkXCIpIHtcblx0XHRcdFx0XHRcdHRoaXMubWV0aG9kID0gXCJHRVRcIjtcblx0XHRcdFx0XHRcdHRoaXMudXJsID0gdG9BYnNvbHV0ZVVybChtZXRob2QpO1xuXHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHR0aGlzLm1ldGhvZCA9IG1ldGhvZDtcblx0XHRcdFx0XHRcdHRoaXMudXJsID0gdG9BYnNvbHV0ZVVybCh1cmwpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwib3BlbiAlcyAlc1wiLCB0aGlzLm1ldGhvZCwgdGhpcy51cmwuaHJlZik7XG5cdFx0XHRcdFx0cmV0dXJuIGludm9rZSgpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGNhc2UgXCJhZGRFdmVudExpc3RlbmVyXCI6IHtcblx0XHRcdFx0XHRjb25zdCBbZXZlbnROYW1lLCBsaXN0ZW5lcl0gPSBhcmdzO1xuXHRcdFx0XHRcdHRoaXMucmVnaXN0ZXJFdmVudChldmVudE5hbWUsIGxpc3RlbmVyKTtcblx0XHRcdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwiYWRkRXZlbnRMaXN0ZW5lclwiLCBldmVudE5hbWUsIGxpc3RlbmVyKTtcblx0XHRcdFx0XHRyZXR1cm4gaW52b2tlKCk7XG5cdFx0XHRcdH1cblx0XHRcdFx0Y2FzZSBcInNldFJlcXVlc3RIZWFkZXJcIjoge1xuXHRcdFx0XHRcdGNvbnN0IFtuYW1lLCB2YWx1ZV0gPSBhcmdzO1xuXHRcdFx0XHRcdHRoaXMucmVxdWVzdEhlYWRlcnMuc2V0KG5hbWUsIHZhbHVlKTtcblx0XHRcdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwic2V0UmVxdWVzdEhlYWRlclwiLCBuYW1lLCB2YWx1ZSk7XG5cdFx0XHRcdFx0cmV0dXJuIGludm9rZSgpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGNhc2UgXCJzZW5kXCI6IHtcblx0XHRcdFx0XHRjb25zdCBbYm9keV0gPSBhcmdzO1xuXHRcdFx0XHRcdGlmICh0aGlzLnN5bmMpIHtcblx0XHRcdFx0XHRcdGNvbnNvbGUud2FybihgRmFpbGVkIHRvIGludGVyY2VwdCBhbiBYTUxIdHRwUmVxdWVzdCAoJHt0aGlzLm1ldGhvZH0gJHt0aGlzLnVybH0pOiBzeW5jaHJvbm91cyByZXF1ZXN0cyBhcmUgbm90IHN1cHBvcnRlZC4gVGhpcyByZXF1ZXN0IHdpbGwgYmUgcGVyZm9ybWVkIGFzLWlzLmApO1xuXHRcdFx0XHRcdFx0cmV0dXJuIGludm9rZSgpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHR0aGlzLnJlcXVlc3QuYWRkRXZlbnRMaXN0ZW5lcihcImxvYWRcIiwgKCkgPT4ge1xuXHRcdFx0XHRcdFx0aWYgKHR5cGVvZiB0aGlzLm9uUmVzcG9uc2UgIT09IFwidW5kZWZpbmVkXCIpIHtcblx0XHRcdFx0XHRcdFx0Y29uc3QgZmV0Y2hSZXNwb25zZSA9IGNyZWF0ZVJlc3BvbnNlKFxuXHRcdFx0XHRcdFx0XHRcdHRoaXMucmVxdWVzdCxcblx0XHRcdFx0XHRcdFx0XHQvKipcblx0XHRcdFx0XHRcdFx0XHQqIFRoZSBgcmVzcG9uc2VgIHByb3BlcnR5IGlzIHRoZSByaWdodCB3YXkgdG8gcmVhZFxuXHRcdFx0XHRcdFx0XHRcdCogdGhlIGFtYmlndW91cyByZXNwb25zZSBib2R5LCBhcyB0aGUgcmVxdWVzdCdzIFwicmVzcG9uc2VUeXBlXCIgbWF5IGRpZmZlci5cblx0XHRcdFx0XHRcdFx0XHQqIEBzZWUgaHR0cHM6Ly94aHIuc3BlYy53aGF0d2cub3JnLyN0aGUtcmVzcG9uc2UtYXR0cmlidXRlXG5cdFx0XHRcdFx0XHRcdFx0Ki9cblx0XHRcdFx0XHRcdFx0XHR0aGlzLnJlcXVlc3QucmVzcG9uc2Vcblx0XHRcdFx0XHRcdFx0KTtcblx0XHRcdFx0XHRcdFx0dGhpcy5vblJlc3BvbnNlLmNhbGwodGhpcywge1xuXHRcdFx0XHRcdFx0XHRcdHJlc3BvbnNlOiBmZXRjaFJlc3BvbnNlLFxuXHRcdFx0XHRcdFx0XHRcdHJlc3BvbnNlVHlwZTogdGhpc1trSXNSZXF1ZXN0SGFuZGxlZF0gPyBcIm1vY2tcIiA6IFwib3JpZ2luYWxcIixcblx0XHRcdFx0XHRcdFx0XHRyZXF1ZXN0OiBmZXRjaFJlcXVlc3QsXG5cdFx0XHRcdFx0XHRcdFx0cmVxdWVzdElkOiB0aGlzLnJlcXVlc3RJZFxuXHRcdFx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRjb25zdCByZXF1ZXN0Qm9keSA9IHR5cGVvZiBib2R5ID09PSBcInN0cmluZ1wiID8gZW5jb2RlQnVmZmVyKGJvZHkpIDogYm9keTtcblx0XHRcdFx0XHRjb25zdCBmZXRjaFJlcXVlc3QgPSB0aGlzLnRvRmV0Y2hBcGlSZXF1ZXN0KHJlcXVlc3RCb2R5KTtcblx0XHRcdFx0XHR0aGlzW2tGZXRjaFJlcXVlc3RdID0gZmV0Y2hSZXF1ZXN0LmNsb25lKCk7XG5cdFx0XHRcdFx0LyoqXG5cdFx0XHRcdFx0KiBAbm90ZSBTdGFydCByZXF1ZXN0IGhhbmRsaW5nIG9uIHRoZSBuZXh0IHRpY2sgc28gdGhhdCB0aGUgdXNlclxuXHRcdFx0XHRcdCogY291bGQgYWRkIGV2ZW50IGxpc3RlbmVycyBmb3IgXCJsb2FkZW5kXCIgYmVmb3JlIHRoZSBpbnRlcmNlcHRvciBmaXJlcyBpdC5cblx0XHRcdFx0XHQqL1xuXHRcdFx0XHRcdHF1ZXVlTWljcm90YXNrKCgpID0+IHtcblx0XHRcdFx0XHRcdCh0aGlzLm9uUmVxdWVzdD8uY2FsbCh0aGlzLCB7XG5cdFx0XHRcdFx0XHRcdHJlcXVlc3Q6IGZldGNoUmVxdWVzdCxcblx0XHRcdFx0XHRcdFx0cmVxdWVzdElkOiB0aGlzLnJlcXVlc3RJZFxuXHRcdFx0XHRcdFx0fSkgfHwgUHJvbWlzZS5yZXNvbHZlKCkpLmZpbmFsbHkoKCkgPT4ge1xuXHRcdFx0XHRcdFx0XHRpZiAoIXRoaXNba0lzUmVxdWVzdEhhbmRsZWRdKSB7XG5cdFx0XHRcdFx0XHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInJlcXVlc3QgY2FsbGJhY2sgc2V0dGxlZCBidXQgcmVxdWVzdCBoYXMgbm90IGJlZW4gaGFuZGxlZCAocmVhZHlzdGF0ZSAlZCksIHBlcmZvcm1pbmcgYXMtaXMuLi5cIiwgdGhpcy5yZXF1ZXN0LnJlYWR5U3RhdGUpO1xuXHRcdFx0XHRcdFx0XHRcdHJldHVybiBpbnZva2UoKTtcblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdH1cblx0XHRcdFx0ZGVmYXVsdDogcmV0dXJuIGludm9rZSgpO1xuXHRcdFx0fVxuXHRcdH0gfSk7XG5cdFx0LyoqXG5cdFx0KiBQcm94eSB0aGUgYC51cGxvYWRgIHByb3BlcnR5IHRvIGdhdGhlciB0aGUgZXZlbnQgbGlzdGVuZXJzL2NhbGxiYWNrcy5cblx0XHQqL1xuXHRcdGRlZmluZSh0aGlzLnJlcXVlc3QsIFwidXBsb2FkXCIsIGNyZWF0ZVByb3h5KHRoaXMucmVxdWVzdC51cGxvYWQsIHtcblx0XHRcdHNldFByb3BlcnR5OiAoW3Byb3BlcnR5TmFtZSwgbmV4dFZhbHVlXSwgaW52b2tlKSA9PiB7XG5cdFx0XHRcdHN3aXRjaCAocHJvcGVydHlOYW1lKSB7XG5cdFx0XHRcdFx0Y2FzZSBcIm9ubG9hZHN0YXJ0XCI6XG5cdFx0XHRcdFx0Y2FzZSBcIm9ucHJvZ3Jlc3NcIjpcblx0XHRcdFx0XHRjYXNlIFwib25hYm9hcnRcIjpcblx0XHRcdFx0XHRjYXNlIFwib25lcnJvclwiOlxuXHRcdFx0XHRcdGNhc2UgXCJvbmxvYWRcIjpcblx0XHRcdFx0XHRjYXNlIFwib250aW1lb3V0XCI6XG5cdFx0XHRcdFx0Y2FzZSBcIm9ubG9hZGVuZFwiOiB7XG5cdFx0XHRcdFx0XHRjb25zdCBldmVudE5hbWUgPSBwcm9wZXJ0eU5hbWUuc2xpY2UoMik7XG5cdFx0XHRcdFx0XHR0aGlzLnJlZ2lzdGVyVXBsb2FkRXZlbnQoZXZlbnROYW1lLCBuZXh0VmFsdWUpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gaW52b2tlKCk7XG5cdFx0XHR9LFxuXHRcdFx0bWV0aG9kQ2FsbDogKFttZXRob2ROYW1lLCBhcmdzXSwgaW52b2tlKSA9PiB7XG5cdFx0XHRcdHN3aXRjaCAobWV0aG9kTmFtZSkge1xuXHRcdFx0XHRcdGNhc2UgXCJhZGRFdmVudExpc3RlbmVyXCI6IHtcblx0XHRcdFx0XHRcdGNvbnN0IFtldmVudE5hbWUsIGxpc3RlbmVyXSA9IGFyZ3M7XG5cdFx0XHRcdFx0XHR0aGlzLnJlZ2lzdGVyVXBsb2FkRXZlbnQoZXZlbnROYW1lLCBsaXN0ZW5lcik7XG5cdFx0XHRcdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwidXBsb2FkLmFkZEV2ZW50TGlzdGVuZXJcIiwgZXZlbnROYW1lLCBsaXN0ZW5lcik7XG5cdFx0XHRcdFx0XHRyZXR1cm4gaW52b2tlKCk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSkpO1xuXHR9XG5cdHJlZ2lzdGVyRXZlbnQoZXZlbnROYW1lLCBsaXN0ZW5lcikge1xuXHRcdGNvbnN0IG5leHRFdmVudHMgPSAodGhpcy5ldmVudHMuZ2V0KGV2ZW50TmFtZSkgfHwgW10pLmNvbmNhdChsaXN0ZW5lcik7XG5cdFx0dGhpcy5ldmVudHMuc2V0KGV2ZW50TmFtZSwgbmV4dEV2ZW50cyk7XG5cdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInJlZ2lzdGVyZWQgZXZlbnQgXFxcIiVzXFxcIlwiLCBldmVudE5hbWUsIGxpc3RlbmVyKTtcblx0fVxuXHRyZWdpc3RlclVwbG9hZEV2ZW50KGV2ZW50TmFtZSwgbGlzdGVuZXIpIHtcblx0XHRjb25zdCBuZXh0RXZlbnRzID0gKHRoaXMudXBsb2FkRXZlbnRzLmdldChldmVudE5hbWUpIHx8IFtdKS5jb25jYXQobGlzdGVuZXIpO1xuXHRcdHRoaXMudXBsb2FkRXZlbnRzLnNldChldmVudE5hbWUsIG5leHRFdmVudHMpO1xuXHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJyZWdpc3RlcmVkIHVwbG9hZCBldmVudCBcXFwiJXNcXFwiXCIsIGV2ZW50TmFtZSwgbGlzdGVuZXIpO1xuXHR9XG5cdC8qKlxuXHQqIFJlc3BvbmRzIHRvIHRoZSBjdXJyZW50IHJlcXVlc3Qgd2l0aCB0aGUgZ2l2ZW5cblx0KiBGZXRjaCBBUEkgYFJlc3BvbnNlYCBpbnN0YW5jZS5cblx0Ki9cblx0YXN5bmMgcmVzcG9uZFdpdGgocmVzcG9uc2UpIHtcblx0XHQvKipcblx0XHQqIEBub3RlIFNpbmNlIGBYTUxIdHRwUmVxdWVzdENvbnRyb2xsZXJgIGRlbGVnYXRlcyB0aGUgaGFuZGxpbmcgb2YgdGhlIHJlc3BvbnNlc1xuXHRcdCogdG8gdGhlIFwibG9hZFwiIGV2ZW50IGxpc3RlbmVyIHRoYXQgZG9lc24ndCBkaXN0aW5ndWlzaCBiZXR3ZWVuIHRoZSBtb2NrZWQgYW5kIG9yaWdpbmFsXG5cdFx0KiByZXNwb25zZXMsIG1hcmsgdGhlIHJlcXVlc3QgdGhhdCBoYWQgYSBtb2NrZWQgcmVzcG9uc2Ugd2l0aCBhIGNvcnJlc3BvbmRpbmcgc3ltYm9sLlxuXHRcdCpcblx0XHQqIE1hcmsgdGhpcyByZXF1ZXN0IGFzIGhhdmluZyBhIG1vY2tlZCByZXNwb25zZSBpbW1lZGlhdGVseSBzaW5jZVxuXHRcdCogY2FsY3VsYXRpbmcgcmVxdWVzdC9yZXNwb25zZSB0b3RhbCBib2R5IGxlbmd0aCBpcyBhc3luY2hyb25vdXMuXG5cdFx0Ki9cblx0XHR0aGlzW2tJc1JlcXVlc3RIYW5kbGVkXSA9IHRydWU7XG5cdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInJlc3BvbmRpbmcgd2l0aCBhIG1vY2tlZCByZXNwb25zZTogJWQgJXNcIiwgcmVzcG9uc2Uuc3RhdHVzLCByZXNwb25zZS5zdGF0dXNUZXh0KTtcblx0XHRGZXRjaFJlc3BvbnNlLnNldFVybCh0aGlzLnVybC5ocmVmLCByZXNwb25zZSk7XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnRpZXModGhpcy5yZXF1ZXN0LCB7XG5cdFx0XHRyZXNwb25zZToge1xuXHRcdFx0XHRlbnVtZXJhYmxlOiB0cnVlLFxuXHRcdFx0XHRjb25maWd1cmFibGU6IGZhbHNlLFxuXHRcdFx0XHRnZXQ6ICgpID0+IHRoaXMucmVzcG9uc2Vcblx0XHRcdH0sXG5cdFx0XHRyZXNwb25zZVRleHQ6IHtcblx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHRcdFx0Y29uZmlndXJhYmxlOiBmYWxzZSxcblx0XHRcdFx0Z2V0OiAoKSA9PiB0aGlzLnJlc3BvbnNlVGV4dFxuXHRcdFx0fSxcblx0XHRcdHJlc3BvbnNlWE1MOiB7XG5cdFx0XHRcdGVudW1lcmFibGU6IHRydWUsXG5cdFx0XHRcdGNvbmZpZ3VyYWJsZTogZmFsc2UsXG5cdFx0XHRcdGdldDogKCkgPT4gdGhpcy5yZXNwb25zZVhNTFxuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdHRoaXMudHJpZ2dlcihcImxvYWRzdGFydFwiLCB0aGlzLnJlcXVlc3QsIHtcblx0XHRcdGxvYWRlZDogMCxcblx0XHRcdHRvdGFsOiAwXG5cdFx0fSk7XG5cdFx0bGV0IHJlcXVlc3RCb2R5VHJhbnNtaXR0ZWQgPSAwO1xuXHRcdGxldCB1cGxvYWRDb21wbGV0ZSA9IGZhbHNlO1xuXHRcdGlmICh0aGlzW2tGZXRjaFJlcXVlc3RdKSB7XG5cdFx0XHRjb25zdCByZXF1ZXN0Qm9keUxlbmd0aCA9IGF3YWl0IGdldEJvZHlCeXRlTGVuZ3RoKHRoaXNba0ZldGNoUmVxdWVzdF0uY2xvbmUoKSk7XG5cdFx0XHRpZiAoIXVwbG9hZENvbXBsZXRlKSB0aGlzLnRyaWdnZXIoXCJsb2Fkc3RhcnRcIiwgdGhpcy5yZXF1ZXN0LnVwbG9hZCwge1xuXHRcdFx0XHRsb2FkZWQ6IDAsXG5cdFx0XHRcdHRvdGFsOiByZXF1ZXN0Qm9keUxlbmd0aFxuXHRcdFx0fSk7XG5cdFx0XHRjb25zdCBwcm9jZXNzUmVxdWVzdEJvZHlDaHVua0xlbmd0aCA9IChieXRlc0xlbmd0aCkgPT4ge1xuXHRcdFx0XHRyZXF1ZXN0Qm9keVRyYW5zbWl0dGVkICs9IGJ5dGVzTGVuZ3RoO1xuXHRcdFx0XHRpZiAocmVxdWVzdEJvZHlUcmFuc21pdHRlZCA8IHJlcXVlc3RCb2R5TGVuZ3RoKSB0aGlzLnRyaWdnZXIoXCJwcm9ncmVzc1wiLCB0aGlzLnJlcXVlc3QudXBsb2FkLCB7XG5cdFx0XHRcdFx0bG9hZGVkOiByZXF1ZXN0Qm9keVRyYW5zbWl0dGVkLFxuXHRcdFx0XHRcdHRvdGFsOiByZXF1ZXN0Qm9keUxlbmd0aFxuXHRcdFx0XHR9KTtcblx0XHRcdH07XG5cdFx0XHRjb25zdCBwcm9jZXNzUmVxdWVzdEVuZE9mQm9keSA9ICgpID0+IHtcblx0XHRcdFx0dXBsb2FkQ29tcGxldGUgPSB0cnVlO1xuXHRcdFx0XHR0aGlzLnRyaWdnZXIoXCJwcm9ncmVzc1wiLCB0aGlzLnJlcXVlc3QudXBsb2FkLCB7XG5cdFx0XHRcdFx0bG9hZGVkOiByZXF1ZXN0Qm9keVRyYW5zbWl0dGVkLFxuXHRcdFx0XHRcdHRvdGFsOiByZXF1ZXN0Qm9keUxlbmd0aFxuXHRcdFx0XHR9KTtcblx0XHRcdFx0dGhpcy50cmlnZ2VyKFwibG9hZFwiLCB0aGlzLnJlcXVlc3QudXBsb2FkLCB7XG5cdFx0XHRcdFx0bG9hZGVkOiByZXF1ZXN0Qm9keVRyYW5zbWl0dGVkLFxuXHRcdFx0XHRcdHRvdGFsOiByZXF1ZXN0Qm9keUxlbmd0aFxuXHRcdFx0XHR9KTtcblx0XHRcdFx0dGhpcy50cmlnZ2VyKFwibG9hZGVuZFwiLCB0aGlzLnJlcXVlc3QudXBsb2FkLCB7XG5cdFx0XHRcdFx0bG9hZGVkOiByZXF1ZXN0Qm9keVRyYW5zbWl0dGVkLFxuXHRcdFx0XHRcdHRvdGFsOiByZXF1ZXN0Qm9keUxlbmd0aFxuXHRcdFx0XHR9KTtcblx0XHRcdH07XG5cdFx0XHRpZiAodGhpc1trRmV0Y2hSZXF1ZXN0XT8uYm9keSAhPSBudWxsKSB7XG5cdFx0XHRcdGNvbnN0IHJlYWRlciA9IHRoaXNba0ZldGNoUmVxdWVzdF0uYm9keS5nZXRSZWFkZXIoKTtcblx0XHRcdFx0d2hpbGUgKHRydWUpIHtcblx0XHRcdFx0XHRjb25zdCB7IHZhbHVlLCBkb25lIH0gPSBhd2FpdCByZWFkZXIucmVhZCgpO1xuXHRcdFx0XHRcdGlmIChkb25lKSB7XG5cdFx0XHRcdFx0XHRwcm9jZXNzUmVxdWVzdEVuZE9mQm9keSgpO1xuXHRcdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdHByb2Nlc3NSZXF1ZXN0Qm9keUNodW5rTGVuZ3RoKHZhbHVlLmJ5dGVMZW5ndGgpO1xuXHRcdFx0XHR9XG5cdFx0XHR9IGVsc2UgcHJvY2Vzc1JlcXVlc3RFbmRPZkJvZHkoKTtcblx0XHR9XG5cdFx0bGV0IHRpbWVkT3V0ID0gZmFsc2U7XG5cdFx0Y29uc3QgcmVzcG9uc2VSZWFkQ29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0XHRjb25zdCByZXF1ZXN0RXJyb3JTdGVwcyA9IChldmVudCkgPT4ge1xuXHRcdFx0dGhpcy5zZXRSZWFkeVN0YXRlKHRoaXMucmVxdWVzdC5ET05FKTtcblx0XHRcdGlmICghdXBsb2FkQ29tcGxldGUpIHtcblx0XHRcdFx0dGhpcy50cmlnZ2VyKGV2ZW50LCB0aGlzLnJlcXVlc3QudXBsb2FkLCB7XG5cdFx0XHRcdFx0bG9hZGVkOiAwLFxuXHRcdFx0XHRcdHRvdGFsOiAwXG5cdFx0XHRcdH0pO1xuXHRcdFx0XHR0aGlzLnRyaWdnZXIoXCJsb2FkZW5kXCIsIHRoaXMucmVxdWVzdC51cGxvYWQsIHtcblx0XHRcdFx0XHRsb2FkZWQ6IDAsXG5cdFx0XHRcdFx0dG90YWw6IDBcblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0XHR0aGlzLnRyaWdnZXIoZXZlbnQsIHRoaXMucmVxdWVzdCwge1xuXHRcdFx0XHRsb2FkZWQ6IDAsXG5cdFx0XHRcdHRvdGFsOiAwXG5cdFx0XHR9KTtcblx0XHRcdHRoaXMudHJpZ2dlcihcImxvYWRlbmRcIiwgdGhpcy5yZXF1ZXN0LCB7XG5cdFx0XHRcdGxvYWRlZDogMCxcblx0XHRcdFx0dG90YWw6IDBcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0Y29uc3QgcHJvY2Vzc1Jlc3BvbnNlID0gYXN5bmMgKHJlc3BvbnNlKSA9PiB7XG5cdFx0XHRjb25zdCBoYW5kbGVFcnJvcnMgPSAoKSA9PiB7XG5cdFx0XHRcdGlmICh0aW1lZE91dCkgcmVxdWVzdEVycm9yU3RlcHMoXCJ0aW1lb3V0XCIpO1xuXHRcdFx0XHRlbHNlIGlmIChyZXNwb25zZVJlYWRDb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKSByZXF1ZXN0RXJyb3JTdGVwcyhcImFib3J0XCIpO1xuXHRcdFx0XHRlbHNlIGlmIChpc1Jlc3BvbnNlRXJyb3IocmVzcG9uc2UpKSByZXF1ZXN0RXJyb3JTdGVwcyhcImVycm9yXCIpO1xuXHRcdFx0fTtcblx0XHRcdGhhbmRsZUVycm9ycygpO1xuXHRcdFx0ZGVmaW5lKHRoaXMucmVxdWVzdCwgXCJzdGF0dXNcIiwgcmVzcG9uc2Uuc3RhdHVzKTtcblx0XHRcdGRlZmluZSh0aGlzLnJlcXVlc3QsIFwic3RhdHVzVGV4dFwiLCByZXNwb25zZS5zdGF0dXNUZXh0KTtcblx0XHRcdGlmICghdGhpcy5yZXF1ZXN0LnJlc3BvbnNlVVJMKSBkZWZpbmUodGhpcy5yZXF1ZXN0LCBcInJlc3BvbnNlVVJMXCIsIHJlc3BvbnNlLnVybCk7XG5cdFx0XHRpZiAoaXNSZXNwb25zZUVycm9yKHJlc3BvbnNlKSkgcmV0dXJuO1xuXHRcdFx0LyoqXG5cdFx0XHQqIEBub3RlIFRoZSByZXNwb25zZSBib2R5IGxlbmd0aCBpcyBkZXJpdmVkIE9OTFkgZnJvbSB0aGUgXCJjb250ZW50LWxlbmd0aFwiIGhlYWRlci5cblx0XHRcdCogSWYgdGhhdCByZXNwb25zZSBoZWFkZXIgaXMgbm90IHNldCwgdGhlIFwidG90YWxcIiBpbiBhbGwgcHJvZ3Jlc3MgZXZlbnRzIG11c3QgYmUgMC5cblx0XHRcdCovXG5cdFx0XHRjb25zdCByZXNwb25zZUJvZHlMZW5ndGggPSBOdW1iZXIocmVzcG9uc2UuaGVhZGVycy5nZXQoXCJjb250ZW50LWxlbmd0aFwiKSA/PyBcIjBcIik7XG5cdFx0XHR0aGlzLnNldFJlYWR5U3RhdGUodGhpcy5yZXF1ZXN0LkhFQURFUlNfUkVDRUlWRUQpO1xuXHRcdFx0bGV0IHJlY2VpdmVkQnl0ZXMgPSAwO1xuXHRcdFx0bGV0IGxhc3RSZWNlaXZlZFJlc3BvbnNlQnl0ZXNBdCA9IHBlcmZvcm1hbmNlLm5vdygpO1xuXHRcdFx0Y29uc3QgcHJvY2Vzc1Jlc3BvbnNlQm9keUNodW5rID0gKGJ5dGVzTGVuZ3RoKSA9PiB7XG5cdFx0XHRcdHJlY2VpdmVkQnl0ZXMgKz0gYnl0ZXNMZW5ndGg7XG5cdFx0XHRcdGNvbnN0IG5vdyA9IHBlcmZvcm1hbmNlLm5vdygpO1xuXHRcdFx0XHRjb25zdCBzaG91bGRCdWZmZXIgPSBub3cgLSBsYXN0UmVjZWl2ZWRSZXNwb25zZUJ5dGVzQXQgPD0gNjAgJiYgcmVjZWl2ZWRCeXRlcyA8IHJlc3BvbnNlQm9keUxlbmd0aDtcblx0XHRcdFx0bGFzdFJlY2VpdmVkUmVzcG9uc2VCeXRlc0F0ID0gbm93O1xuXHRcdFx0XHRpZiAoc2hvdWxkQnVmZmVyKSByZXR1cm47XG5cdFx0XHRcdGlmICh0aGlzLnJlcXVlc3QucmVhZHlTdGF0ZSA9PT0gdGhpcy5yZXF1ZXN0LkhFQURFUlNfUkVDRUlWRUQpIHRoaXMuc2V0UmVhZHlTdGF0ZSh0aGlzLnJlcXVlc3QuTE9BRElORywgZmFsc2UpO1xuXHRcdFx0XHR0aGlzLnRyaWdnZXIoXCJyZWFkeXN0YXRlY2hhbmdlXCIsIHRoaXMucmVxdWVzdCk7XG5cdFx0XHRcdHRoaXMudHJpZ2dlcihcInByb2dyZXNzXCIsIHRoaXMucmVxdWVzdCwge1xuXHRcdFx0XHRcdGxvYWRlZDogcmVjZWl2ZWRCeXRlcyxcblx0XHRcdFx0XHR0b3RhbDogcmVzcG9uc2VCb2R5TGVuZ3RoXG5cdFx0XHRcdH0pO1xuXHRcdFx0fTtcblx0XHRcdGNvbnN0IHByb2Nlc3NSZXNwb25zZUJvZHlFcnJvciA9ICgpID0+IHtcblx0XHRcdFx0cmVxdWVzdEVycm9yU3RlcHMoXCJlcnJvclwiKTtcblx0XHRcdH07XG5cdFx0XHRjb25zdCBwcm9jZXNzUmVzcG9uc2VFbmRPZkJvZHkgPSBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdGhhbmRsZUVycm9ycygpO1xuXHRcdFx0XHRpZiAoaXNSZXNwb25zZUVycm9yKHJlc3BvbnNlKSkgcmV0dXJuO1xuXHRcdFx0XHRsZXQgdHJhbnNtaXR0ZWQgPSByZWNlaXZlZEJ5dGVzO1xuXHRcdFx0XHR0aGlzLnNldFJlYWR5U3RhdGUodGhpcy5yZXF1ZXN0LkRPTkUpO1xuXHRcdFx0XHR0aGlzLnRyaWdnZXIoXCJsb2FkXCIsIHRoaXMucmVxdWVzdCwge1xuXHRcdFx0XHRcdGxvYWRlZDogdHJhbnNtaXR0ZWQsXG5cdFx0XHRcdFx0dG90YWw6IHJlc3BvbnNlQm9keUxlbmd0aFxuXHRcdFx0XHR9KTtcblx0XHRcdFx0dGhpcy50cmlnZ2VyKFwibG9hZGVuZFwiLCB0aGlzLnJlcXVlc3QsIHtcblx0XHRcdFx0XHRsb2FkZWQ6IHRyYW5zbWl0dGVkLFxuXHRcdFx0XHRcdHRvdGFsOiByZXNwb25zZUJvZHlMZW5ndGhcblx0XHRcdFx0fSk7XG5cdFx0XHR9O1xuXHRcdFx0aWYgKHJlc3BvbnNlLmJvZHkgPT0gbnVsbCkgcHJvY2Vzc1Jlc3BvbnNlRW5kT2ZCb2R5KCk7XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0Y29uc3QgcmVhZGVyID0gcmVzcG9uc2UuYm9keS5nZXRSZWFkZXIoKTtcblx0XHRcdFx0d2hpbGUgKHRydWUpIHtcblx0XHRcdFx0XHRpZiAocmVzcG9uc2VSZWFkQ29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkgYnJlYWs7XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdGNvbnN0IHsgdmFsdWUsIGRvbmUgfSA9IGF3YWl0IHJlYWRlci5yZWFkKCk7XG5cdFx0XHRcdFx0XHRpZiAoZG9uZSkge1xuXHRcdFx0XHRcdFx0XHRwcm9jZXNzUmVzcG9uc2VFbmRPZkJvZHkoKTtcblx0XHRcdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0cHJvY2Vzc1Jlc3BvbnNlQm9keUNodW5rKHZhbHVlLmJ5dGVMZW5ndGgpO1xuXHRcdFx0XHRcdFx0dGhpcy5yZXNwb25zZUJ1ZmZlciA9IGNvbmNhdEFycmF5QnVmZmVyKHRoaXMucmVzcG9uc2VCdWZmZXIsIHZhbHVlKTtcblx0XHRcdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0XHRcdHByb2Nlc3NSZXNwb25zZUJvZHlFcnJvcigpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH07XG5cdFx0Y29uc3QgW3JlZGlyZWN0RXJyb3IsIGZpbmFsUmVzcG9uc2VdID0gYXdhaXQgdW50aWwoKCkgPT4ge1xuXHRcdFx0cmV0dXJuIHRoaXMuZm9sbG93UmVkaXJlY3RzKHJlc3BvbnNlKTtcblx0XHR9KTtcblx0XHRpZiAocmVkaXJlY3RFcnJvcikgcmV0dXJuO1xuXHRcdHByb2Nlc3NSZXNwb25zZShmaW5hbFJlc3BvbnNlKTtcblx0XHRpZiAodGhpcy5yZXF1ZXN0LnRpbWVvdXQpIHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0aWYgKHRoaXMucmVxdWVzdC5yZWFkeVN0YXRlICE9PSB0aGlzLnJlcXVlc3QuRE9ORSkge1xuXHRcdFx0XHR0aW1lZE91dCA9IHRydWU7XG5cdFx0XHRcdHJlc3BvbnNlUmVhZENvbnRyb2xsZXIuYWJvcnQoKTtcblx0XHRcdH1cblx0XHR9LCB0aGlzLnJlcXVlc3QudGltZW91dCk7XG5cdFx0dGhpcy5yZXF1ZXN0LmdldFJlc3BvbnNlSGVhZGVyID0gbmV3IFByb3h5KHRoaXMucmVxdWVzdC5nZXRSZXNwb25zZUhlYWRlciwgeyBhcHBseTogKF8sIF9fLCBhcmdzKSA9PiB7XG5cdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwiZ2V0UmVzcG9uc2VIZWFkZXJcIiwgYXJnc1swXSk7XG5cdFx0XHRpZiAodGhpcy5yZXF1ZXN0LnJlYWR5U3RhdGUgPCB0aGlzLnJlcXVlc3QuSEVBREVSU19SRUNFSVZFRCkge1xuXHRcdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwiaGVhZGVycyBub3QgcmVjZWl2ZWQgeWV0LCByZXR1cm5pbmcgbnVsbFwiKTtcblx0XHRcdFx0cmV0dXJuIG51bGw7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBoZWFkZXJWYWx1ZSA9IGZpbmFsUmVzcG9uc2UuaGVhZGVycy5nZXQoYXJnc1swXSk7XG5cdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwicmVzb2x2ZWQgcmVzcG9uc2UgaGVhZGVyIFxcXCIlc1xcXCIgdG9cIiwgYXJnc1swXSwgaGVhZGVyVmFsdWUpO1xuXHRcdFx0cmV0dXJuIGhlYWRlclZhbHVlO1xuXHRcdH0gfSk7XG5cdFx0dGhpcy5yZXF1ZXN0LmdldEFsbFJlc3BvbnNlSGVhZGVycyA9IG5ldyBQcm94eSh0aGlzLnJlcXVlc3QuZ2V0QWxsUmVzcG9uc2VIZWFkZXJzLCB7IGFwcGx5OiAoKSA9PiB7XG5cdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwiZ2V0QWxsUmVzcG9uc2VIZWFkZXJzXCIpO1xuXHRcdFx0aWYgKHRoaXMucmVxdWVzdC5yZWFkeVN0YXRlIDwgdGhpcy5yZXF1ZXN0LkhFQURFUlNfUkVDRUlWRUQpIHtcblx0XHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcImhlYWRlcnMgbm90IHJlY2VpdmVkIHlldCwgcmV0dXJuaW5nIGVtcHR5IHN0cmluZ1wiKTtcblx0XHRcdFx0cmV0dXJuIFwiXCI7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBhbGxIZWFkZXJzID0gQXJyYXkuZnJvbShmaW5hbFJlc3BvbnNlLmhlYWRlcnMpLm1hcCgoW2hlYWRlck5hbWUsIGhlYWRlclZhbHVlXSkgPT4ge1xuXHRcdFx0XHRyZXR1cm4gYCR7aGVhZGVyTmFtZX06ICR7aGVhZGVyVmFsdWV9YDtcblx0XHRcdH0pLmpvaW4oXCJcXHJcXG5cIik7XG5cdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwicmVzb2x2ZWQgYWxsIHJlc3BvbnNlIGhlYWRlcnMgdG9cIiwgYWxsSGVhZGVycyk7XG5cdFx0XHRyZXR1cm4gYWxsSGVhZGVycztcblx0XHR9IH0pO1xuXHR9XG5cdHJlc3BvbnNlQnVmZmVyVG9UZXh0KCkge1xuXHRcdHJldHVybiBkZWNvZGVCdWZmZXIodGhpcy5yZXNwb25zZUJ1ZmZlcik7XG5cdH1cblx0Z2V0IHJlc3BvbnNlKCkge1xuXHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJnZXRSZXNwb25zZSAocmVzcG9uc2VUeXBlOiAlcylcIiwgdGhpcy5yZXF1ZXN0LnJlc3BvbnNlVHlwZSk7XG5cdFx0aWYgKHRoaXMucmVxdWVzdC5yZWFkeVN0YXRlICE9PSB0aGlzLnJlcXVlc3QuRE9ORSkgcmV0dXJuIG51bGw7XG5cdFx0c3dpdGNoICh0aGlzLnJlcXVlc3QucmVzcG9uc2VUeXBlKSB7XG5cdFx0XHRjYXNlIFwianNvblwiOiB7XG5cdFx0XHRcdGNvbnN0IHJlc3BvbnNlSnNvbiA9IHBhcnNlSnNvbih0aGlzLnJlc3BvbnNlQnVmZmVyVG9UZXh0KCkpO1xuXHRcdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwicmVzb2x2ZWQgcmVzcG9uc2UgSlNPTlwiLCByZXNwb25zZUpzb24pO1xuXHRcdFx0XHRyZXR1cm4gcmVzcG9uc2VKc29uO1xuXHRcdFx0fVxuXHRcdFx0Y2FzZSBcImFycmF5YnVmZmVyXCI6IHtcblx0XHRcdFx0Y29uc3QgYXJyYXlCdWZmZXIgPSB0b0FycmF5QnVmZmVyKHRoaXMucmVzcG9uc2VCdWZmZXIpO1xuXHRcdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwicmVzb2x2ZWQgcmVzcG9uc2UgQXJyYXlCdWZmZXJcIiwgYXJyYXlCdWZmZXIpO1xuXHRcdFx0XHRyZXR1cm4gYXJyYXlCdWZmZXI7XG5cdFx0XHR9XG5cdFx0XHRjYXNlIFwiYmxvYlwiOiB7XG5cdFx0XHRcdGNvbnN0IG1pbWVUeXBlID0gdGhpcy5yZXF1ZXN0LmdldFJlc3BvbnNlSGVhZGVyKFwiQ29udGVudC1UeXBlXCIpIHx8IFwidGV4dC9wbGFpblwiO1xuXHRcdFx0XHRjb25zdCByZXNwb25zZUJsb2IgPSBuZXcgQmxvYihbdGhpcy5yZXNwb25zZUJ1ZmZlclRvVGV4dCgpXSwgeyB0eXBlOiBtaW1lVHlwZSB9KTtcblx0XHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInJlc29sdmVkIHJlc3BvbnNlIEJsb2IgKG1pbWUgdHlwZTogJXMpXCIsIHJlc3BvbnNlQmxvYiwgbWltZVR5cGUpO1xuXHRcdFx0XHRyZXR1cm4gcmVzcG9uc2VCbG9iO1xuXHRcdFx0fVxuXHRcdFx0ZGVmYXVsdDoge1xuXHRcdFx0XHRjb25zdCByZXNwb25zZVRleHQgPSB0aGlzLnJlc3BvbnNlQnVmZmVyVG9UZXh0KCk7XG5cdFx0XHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJyZXNvbHZpbmcgXFxcIiVzXFxcIiByZXNwb25zZSB0eXBlIGFzIHRleHRcIiwgdGhpcy5yZXF1ZXN0LnJlc3BvbnNlVHlwZSwgcmVzcG9uc2VUZXh0KTtcblx0XHRcdFx0cmV0dXJuIHJlc3BvbnNlVGV4dDtcblx0XHRcdH1cblx0XHR9XG5cdH1cblx0Z2V0IHJlc3BvbnNlVGV4dCgpIHtcblx0XHQvKipcblx0XHQqIFRocm93IHdoZW4gdHJ5aW5nIHRvIHJlYWQgdGhlIHJlc3BvbnNlIGJvZHkgYXMgdGV4dCB3aGVuIHRoZVxuXHRcdCogXCJyZXNwb25zZVR5cGVcIiBkb2Vzbid0IGV4cGVjdCB0ZXh0LiBUaGlzIGp1c3QgcmVzcGVjdHMgdGhlIHNwZWMgYmV0dGVyLlxuXHRcdCogQHNlZSBodHRwczovL3hoci5zcGVjLndoYXR3Zy5vcmcvI3RoZS1yZXNwb25zZXRleHQtYXR0cmlidXRlXG5cdFx0Ki9cblx0XHRpbnZhcmlhbnQodGhpcy5yZXF1ZXN0LnJlc3BvbnNlVHlwZSA9PT0gXCJcIiB8fCB0aGlzLnJlcXVlc3QucmVzcG9uc2VUeXBlID09PSBcInRleHRcIiwgXCJJbnZhbGlkU3RhdGVFcnJvcjogVGhlIG9iamVjdCBpcyBpbiBpbnZhbGlkIHN0YXRlLlwiKTtcblx0XHRpZiAodGhpcy5yZXF1ZXN0LnJlYWR5U3RhdGUgIT09IHRoaXMucmVxdWVzdC5MT0FESU5HICYmIHRoaXMucmVxdWVzdC5yZWFkeVN0YXRlICE9PSB0aGlzLnJlcXVlc3QuRE9ORSkgcmV0dXJuIFwiXCI7XG5cdFx0Y29uc3QgcmVzcG9uc2VUZXh0ID0gdGhpcy5yZXNwb25zZUJ1ZmZlclRvVGV4dCgpO1xuXHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJnZXRSZXNwb25zZVRleHQ6IFxcXCIlc1xcXCJcIiwgcmVzcG9uc2VUZXh0KTtcblx0XHRyZXR1cm4gcmVzcG9uc2VUZXh0O1xuXHR9XG5cdGdldCByZXNwb25zZVhNTCgpIHtcblx0XHRpbnZhcmlhbnQodGhpcy5yZXF1ZXN0LnJlc3BvbnNlVHlwZSA9PT0gXCJcIiB8fCB0aGlzLnJlcXVlc3QucmVzcG9uc2VUeXBlID09PSBcImRvY3VtZW50XCIsIFwiSW52YWxpZFN0YXRlRXJyb3I6IFRoZSBvYmplY3QgaXMgaW4gaW52YWxpZCBzdGF0ZS5cIik7XG5cdFx0aWYgKHRoaXMucmVxdWVzdC5yZWFkeVN0YXRlICE9PSB0aGlzLnJlcXVlc3QuRE9ORSkgcmV0dXJuIG51bGw7XG5cdFx0Y29uc3QgY29udGVudFR5cGUgPSB0aGlzLnJlcXVlc3QuZ2V0UmVzcG9uc2VIZWFkZXIoXCJDb250ZW50LVR5cGVcIikgfHwgXCJcIjtcblx0XHRpZiAodHlwZW9mIERPTVBhcnNlciA9PT0gXCJ1bmRlZmluZWRcIikge1xuXHRcdFx0Y29uc29sZS53YXJuKFwiQ2Fubm90IHJldHJpZXZlIFhNTEh0dHBSZXF1ZXN0IHJlc3BvbnNlIGJvZHkgYXMgWE1MOiBET01QYXJzZXIgaXMgbm90IGRlZmluZWQuIFlvdSBhcmUgbGlrZWx5IHVzaW5nIGFuIGVudmlyb25tZW50IHRoYXQgaXMgbm90IGJyb3dzZXIgb3IgZG9lcyBub3QgcG9seWZpbGwgYnJvd3NlciBnbG9iYWxzIGNvcnJlY3RseS5cIik7XG5cdFx0XHRyZXR1cm4gbnVsbDtcblx0XHR9XG5cdFx0aWYgKGlzRG9tUGFyc2VyU3VwcG9ydGVkVHlwZShjb250ZW50VHlwZSkpIHJldHVybiBuZXcgRE9NUGFyc2VyKCkucGFyc2VGcm9tU3RyaW5nKHRoaXMucmVzcG9uc2VCdWZmZXJUb1RleHQoKSwgY29udGVudFR5cGUpO1xuXHRcdHJldHVybiBudWxsO1xuXHR9XG5cdGFzeW5jIGZvbGxvd1JlZGlyZWN0cyhyZXNwb25zZSkge1xuXHRcdGNvbnN0IHJlZGlyZWN0TG9jYXRpb24gPSByZXNwb25zZS5oZWFkZXJzLmdldChcImxvY2F0aW9uXCIpO1xuXHRcdGlmICghcmVkaXJlY3RMb2NhdGlvbiB8fCAhRmV0Y2hSZXNwb25zZS5pc1JlZGlyZWN0UmVzcG9uc2UocmVzcG9uc2Uuc3RhdHVzKSkgcmV0dXJuIHJlc3BvbnNlO1xuXHRcdHRoaXMucmVkaXJlY3RDb3VudCsrO1xuXHRcdGlmICh0aGlzLnJlZGlyZWN0Q291bnQgPiBNQVhfUkVESVJFQ1RTKSB0aHJvdyBuZXcgRXJyb3IoXCJUb28gbWFueSByZWRpcmVjdHNcIik7XG5cdFx0Y29uc3QgcmVkaXJlY3RVcmwgPSBuZXcgVVJMKHJlZGlyZWN0TG9jYXRpb24sIGxvY2F0aW9uLmhyZWYpO1xuXHRcdGNvbnN0IHJlZGlyZWN0TWV0aG9kID0gRmV0Y2hSZXNwb25zZS5pc1Jlc3BvbnNlV2l0aEJvZHkocmVzcG9uc2Uuc3RhdHVzKSA/IHRoaXMubWV0aG9kIDogXCJHRVRcIjtcblx0XHRjb25zdCByZWRpcmVjdFJlc3BvbnNlID0gYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0Y29uc3QgcmVxdWVzdCA9IG5ldyBYTUxIdHRwUmVxdWVzdCgpO1xuXHRcdFx0cmVxdWVzdC5yZXNwb25zZVR5cGUgPSB0aGlzLnJlcXVlc3QucmVzcG9uc2VUeXBlO1xuXHRcdFx0cmVxdWVzdC5hZGRFdmVudExpc3RlbmVyKFwibG9hZFwiLCAoKSA9PiB7XG5cdFx0XHRcdHRoaXMudXJsID0gbmV3IFVSTChyZXF1ZXN0LnJlc3BvbnNlVVJMKTtcblx0XHRcdFx0cmVzb2x2ZShjcmVhdGVSZXNwb25zZShyZXF1ZXN0LCByZXF1ZXN0LnJlc3BvbnNlKSk7XG5cdFx0XHR9KTtcblx0XHRcdHJlcXVlc3QuYWRkRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsICgpID0+IHtcblx0XHRcdFx0dGhpcy5lcnJvcldpdGgoKTtcblx0XHRcdFx0cmVqZWN0KC8qIEBfX1BVUkVfXyAqLyBuZXcgRXJyb3IoXCJSZWRpcmVjdCByZXF1ZXN0IGZhaWxlZFwiKSk7XG5cdFx0XHR9KTtcblx0XHRcdHJlcXVlc3Qub3BlbihyZWRpcmVjdE1ldGhvZCwgcmVkaXJlY3RVcmwuaHJlZik7XG5cdFx0XHRyZXF1ZXN0LnNlbmQoKTtcblx0XHR9KTtcblx0XHRyZXR1cm4gdGhpcy5mb2xsb3dSZWRpcmVjdHMocmVkaXJlY3RSZXNwb25zZSk7XG5cdH1cblx0ZXJyb3JXaXRoKGVycm9yKSB7XG5cdFx0LyoqXG5cdFx0KiBAbm90ZSBNYXJrIHRoaXMgcmVxdWVzdCBhcyBoYW5kbGVkIGV2ZW4gaWYgaXQgcmVjZWl2ZWQgYSBtb2NrIGVycm9yLlxuXHRcdCogVGhpcyBwcmV2ZW50cyB0aGUgY29udHJvbGxlciBmcm9tIHRyeWluZyB0byBwZXJmb3JtIHRoaXMgcmVxdWVzdCBhcy1pcy5cblx0XHQqL1xuXHRcdHRoaXNba0lzUmVxdWVzdEhhbmRsZWRdID0gdHJ1ZTtcblx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwicmVzcG9uZGluZyB3aXRoIGFuIGVycm9yXCIpO1xuXHRcdHRoaXMuc2V0UmVhZHlTdGF0ZSh0aGlzLnJlcXVlc3QuRE9ORSk7XG5cdFx0dGhpcy50cmlnZ2VyKFwiZXJyb3JcIiwgdGhpcy5yZXF1ZXN0KTtcblx0XHR0aGlzLnRyaWdnZXIoXCJsb2FkZW5kXCIsIHRoaXMucmVxdWVzdCk7XG5cdH1cblx0LyoqXG5cdCogVHJhbnNpdGlvbnMgdGhpcyByZXF1ZXN0J3MgYHJlYWR5U3RhdGVgIHRvIHRoZSBnaXZlbiBvbmUuXG5cdCovXG5cdHNldFJlYWR5U3RhdGUobmV4dFJlYWR5U3RhdGUsIHRyaWdnZXJSZWFkeVN0YXRlQ2hhbmdlRXZlbnQgPSB0cnVlKSB7XG5cdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInNldFJlYWR5U3RhdGU6ICVkIC0+ICVkXCIsIHRoaXMucmVxdWVzdC5yZWFkeVN0YXRlLCBuZXh0UmVhZHlTdGF0ZSk7XG5cdFx0aWYgKHRoaXMucmVxdWVzdC5yZWFkeVN0YXRlID09PSBuZXh0UmVhZHlTdGF0ZSkge1xuXHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcInJlYWR5IHN0YXRlIGlkZW50aWNhbCwgc2tpcHBpbmcgdHJhbnNpdGlvbi4uLlwiKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0ZGVmaW5lKHRoaXMucmVxdWVzdCwgXCJyZWFkeVN0YXRlXCIsIG5leHRSZWFkeVN0YXRlKTtcblx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwic2V0IHJlYWR5U3RhdGUgdG86ICVkXCIsIG5leHRSZWFkeVN0YXRlKTtcblx0XHRpZiAoIXRyaWdnZXJSZWFkeVN0YXRlQ2hhbmdlRXZlbnQpIHJldHVybjtcblx0XHRpZiAobmV4dFJlYWR5U3RhdGUgIT09IHRoaXMucmVxdWVzdC5VTlNFTlQpIHtcblx0XHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJ0cmlnZ2VyaW5nIFxcXCJyZWFkeXN0YXRlY2hhbmdlXFxcIiBldmVudC4uLlwiKTtcblx0XHRcdHRoaXMudHJpZ2dlcihcInJlYWR5c3RhdGVjaGFuZ2VcIiwgdGhpcy5yZXF1ZXN0KTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogVHJpZ2dlcnMgZ2l2ZW4gZXZlbnQgb24gdGhlIGBYTUxIdHRwUmVxdWVzdGAgaW5zdGFuY2UuXG5cdCovXG5cdHRyaWdnZXIoZXZlbnROYW1lLCB0YXJnZXQsIG9wdGlvbnMpIHtcblx0XHRjb25zdCBjYWxsYmFjayA9IHRhcmdldFtgb24ke2V2ZW50TmFtZX1gXTtcblx0XHRjb25zdCBldmVudCA9IGNyZWF0ZUV2ZW50KHRhcmdldCwgZXZlbnROYW1lLCBvcHRpb25zKTtcblx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwidHJpZ2dlciBcXFwiJXNcXFwiXCIsIGV2ZW50TmFtZSwgb3B0aW9ucyB8fCBcIlwiKTtcblx0XHRpZiAodHlwZW9mIGNhbGxiYWNrID09PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJmb3VuZCBhIGRpcmVjdCBcXFwiJXNcXFwiIGNhbGxiYWNrLCBjYWxsaW5nLi4uXCIsIGV2ZW50TmFtZSk7XG5cdFx0XHRjYWxsYmFjay5jYWxsKHRhcmdldCwgZXZlbnQpO1xuXHRcdH1cblx0XHRjb25zdCBldmVudHMgPSB0YXJnZXQgaW5zdGFuY2VvZiBYTUxIdHRwUmVxdWVzdFVwbG9hZCA/IHRoaXMudXBsb2FkRXZlbnRzIDogdGhpcy5ldmVudHM7XG5cdFx0Zm9yIChjb25zdCBbcmVnaXN0ZXJlZEV2ZW50TmFtZSwgbGlzdGVuZXJzXSBvZiBldmVudHMpIGlmIChyZWdpc3RlcmVkRXZlbnROYW1lID09PSBldmVudE5hbWUpIHtcblx0XHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJmb3VuZCAlZCBsaXN0ZW5lcihzKSBmb3IgXFxcIiVzXFxcIiBldmVudCwgY2FsbGluZy4uLlwiLCBsaXN0ZW5lcnMubGVuZ3RoLCBldmVudE5hbWUpO1xuXHRcdFx0bGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiBsaXN0ZW5lci5jYWxsKHRhcmdldCwgZXZlbnQpKTtcblx0XHR9XG5cdH1cblx0LyoqXG5cdCogQ29udmVydHMgdGhpcyBgWE1MSHR0cFJlcXVlc3RgIGluc3RhbmNlIGludG8gYSBGZXRjaCBBUEkgYFJlcXVlc3RgIGluc3RhbmNlLlxuXHQqL1xuXHR0b0ZldGNoQXBpUmVxdWVzdChib2R5KSB7XG5cdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcImNvbnZlcnRpbmcgcmVxdWVzdCB0byBhIEZldGNoIEFQSSBSZXF1ZXN0Li4uXCIpO1xuXHRcdGNvbnN0IHJlc29sdmVkQm9keSA9IGJvZHkgaW5zdGFuY2VvZiBEb2N1bWVudCA/IGJvZHkuZG9jdW1lbnRFbGVtZW50LmlubmVyVGV4dCA6IGJvZHk7XG5cdFx0Y29uc3QgZmV0Y2hSZXF1ZXN0ID0gbmV3IEZldGNoUmVxdWVzdCh0aGlzLnVybC5ocmVmLCB7XG5cdFx0XHRtZXRob2Q6IHRoaXMubWV0aG9kLFxuXHRcdFx0aGVhZGVyczogdGhpcy5yZXF1ZXN0SGVhZGVycyxcblx0XHRcdC8qKlxuXHRcdFx0KiBAc2VlIGh0dHBzOi8veGhyLnNwZWMud2hhdHdnLm9yZy8jY3Jvc3Mtb3JpZ2luLWNyZWRlbnRpYWxzXG5cdFx0XHQqL1xuXHRcdFx0Y3JlZGVudGlhbHM6IHRoaXMucmVxdWVzdC53aXRoQ3JlZGVudGlhbHMgPyBcImluY2x1ZGVcIiA6IFwic2FtZS1vcmlnaW5cIixcblx0XHRcdGJvZHk6IHJlc29sdmVkQm9keVxuXHRcdH0pO1xuXHRcdGNvbnN0IGhlYWRlcnMgPSBmZXRjaFJlcXVlc3QuaGVhZGVycztcblx0XHRkZWZpbmUoZmV0Y2hSZXF1ZXN0LCBcImhlYWRlcnNcIiwgY3JlYXRlUHJveHkoaGVhZGVycywgeyBtZXRob2RDYWxsOiAoW21ldGhvZE5hbWUsIGFyZ3NdLCBpbnZva2UpID0+IHtcblx0XHRcdGNvbnN0IHJlc3VsdCA9IGludm9rZSgpO1xuXHRcdFx0c3dpdGNoIChtZXRob2ROYW1lKSB7XG5cdFx0XHRcdGNhc2UgXCJhcHBlbmRcIjpcblx0XHRcdFx0Y2FzZSBcInNldFwiOiB7XG5cdFx0XHRcdFx0Y29uc3QgW2hlYWRlck5hbWUsIGhlYWRlclZhbHVlXSA9IGFyZ3M7XG5cdFx0XHRcdFx0LyoqXG5cdFx0XHRcdFx0KiBAbm90ZSBGb3J3YXJkIG9ubHkgdGhlIGhlYWRlcnMgdGhlIEZldGNoIEFQSSBSZXF1ZXN0IGFjY2VwdGVkLlxuXHRcdFx0XHRcdCogRm9yYmlkZGVuIHJlcXVlc3QgaGVhZGVycyAoZS5nLiBcIkNvb2tpZVwiKSBhcmUgZHJvcHBlZCBzaWxlbnRseVxuXHRcdFx0XHRcdCogYnkgdGhlIHJlcXVlc3QncyBoZWFkZXJzIGd1YXJkLCBhbmQgZm9yd2FyZGluZyB0aGVtIG1ha2VzXG5cdFx0XHRcdFx0KiB0aGUgYnJvd3NlciByZWZ1c2UgdGhlbSB3aXRoIGFuIGVycm9yIGluIHRoZSBjb25zb2xlLlxuXHRcdFx0XHRcdCovXG5cdFx0XHRcdFx0aWYgKGhlYWRlcnMuaGFzKGhlYWRlck5hbWUpKSB0aGlzLnJlcXVlc3Quc2V0UmVxdWVzdEhlYWRlcihoZWFkZXJOYW1lLCBoZWFkZXJWYWx1ZSk7XG5cdFx0XHRcdFx0YnJlYWs7XG5cdFx0XHRcdH1cblx0XHRcdFx0Y2FzZSBcImRlbGV0ZVwiOiB7XG5cdFx0XHRcdFx0Y29uc3QgW2hlYWRlck5hbWVdID0gYXJncztcblx0XHRcdFx0XHRjb25zb2xlLndhcm4oYFhNTEh0dHBSZXF1ZXN0OiBDYW5ub3QgcmVtb3ZlIGEgXCIke2hlYWRlck5hbWV9XCIgaGVhZGVyIGZyb20gdGhlIEZldGNoIEFQSSByZXByZXNlbnRhdGlvbiBvZiB0aGUgXCIke2ZldGNoUmVxdWVzdC5tZXRob2R9ICR7ZmV0Y2hSZXF1ZXN0LnVybH1cIiByZXF1ZXN0LiBYTUxIdHRwUmVxdWVzdCBoZWFkZXJzIGNhbm5vdCBiZSByZW1vdmVkLmApO1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gcmVzdWx0O1xuXHRcdH0gfSkpO1xuXHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJjb252ZXJ0ZWQgcmVxdWVzdCB0byBhIEZldGNoIEFQSSBSZXF1ZXN0IVwiLCBmZXRjaFJlcXVlc3QpO1xuXHRcdHJldHVybiBmZXRjaFJlcXVlc3Q7XG5cdH1cbn07XG5mdW5jdGlvbiB0b0Fic29sdXRlVXJsKHVybCkge1xuXHQvKipcblx0KiBAbm90ZSBYTUxIdHRwUmVxdWVzdCBpbnRlcmNlcHRvciBtYXkgcnVuIGluIGVudmlyb25tZW50c1xuXHQqIHRoYXQgaW1wbGVtZW50IFhNTEh0dHBSZXF1ZXN0IGJ1dCBkb24ndCBpbXBsZW1lbnQgXCJsb2NhdGlvblwiXG5cdCogKGZvciBleGFtcGxlLCBSZWFjdCBOYXRpdmUpLiBJZiB0aGF0J3MgdGhlIGNhc2UsIHJldHVybiB0aGVcblx0KiBpbnB1dCBVUkwgYXMtaXMgKG5vdGhpbmcgdG8gYmUgcmVsYXRpdmUgdG8pLlxuXHQqIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL21zd2pzL21zdy9pc3N1ZXMvMTc3N1xuXHQqL1xuXHRpZiAodHlwZW9mIGxvY2F0aW9uID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gbmV3IFVSTCh1cmwpO1xuXHRyZXR1cm4gbmV3IFVSTCh1cmwudG9TdHJpbmcoKSwgbG9jYXRpb24uaHJlZik7XG59XG5mdW5jdGlvbiBkZWZpbmUodGFyZ2V0LCBwcm9wZXJ0eSwgdmFsdWUpIHtcblx0UmVmbGVjdC5kZWZpbmVQcm9wZXJ0eSh0YXJnZXQsIHByb3BlcnR5LCB7XG5cdFx0d3JpdGFibGU6IHRydWUsXG5cdFx0ZW51bWVyYWJsZTogdHJ1ZSxcblx0XHR2YWx1ZVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvWE1MSHR0cFJlcXVlc3QveG1sLWh0dHAtcmVxdWVzdC1wcm94eS50c1xuLyoqXG4qIENyZWF0ZSBhIHByb3hpZWQgYFhNTEh0dHBSZXF1ZXN0YCBjbGFzcy5cbiogVGhlIHByb3hpZWQgY2xhc3MgZXN0YWJsaXNoZXMgc3BpZXMgb24gY2VydGFpbiBtZXRob2RzLFxuKiBhbGxvd2luZyB1cyB0byBpbnRlcmNlcHQgcmVxdWVzdHMgYW5kIHJlc3BvbmQgdG8gdGhlbS5cbiovXG5mdW5jdGlvbiBjcmVhdGVYTUxIdHRwUmVxdWVzdFByb3h5KHsgZW1pdHRlciwgbG9nZ2VyIH0pIHtcblx0cmV0dXJuIG5ldyBQcm94eShnbG9iYWxUaGlzLlhNTEh0dHBSZXF1ZXN0LCB7IGNvbnN0cnVjdCh0YXJnZXQsIGFyZ3MsIG5ld1RhcmdldCkge1xuXHRcdGxvZ2dlci52ZXJib3NlKFwiY29uc3RydWN0ZWQgbmV3IFhNTEh0dHBSZXF1ZXN0XCIpO1xuXHRcdGNvbnN0IG9yaWdpbmFsUmVxdWVzdCA9IFJlZmxlY3QuY29uc3RydWN0KHRhcmdldCwgYXJncywgbmV3VGFyZ2V0KTtcblx0XHQvKipcblx0XHQqIEBub3RlIEZvcndhcmQgcHJvdG90eXBlIGRlc2NyaXB0b3JzIG9udG8gdGhlIHByb3hpZWQgb2JqZWN0LlxuXHRcdCogWE1MSHR0cFJlcXVlc3QgaXMgaW1wbGVtZW50ZWQgaW4gSlNET00gaW4gYSB3YXkgdGhhdCBhc3NpZ25zXG5cdFx0KiBhIGJ1bmNoIG9mIGRlc2NyaXB0b3JzLCBsaWtlIFwic2V0IHJlc3BvbnNlVHlwZSgpXCIgb24gdGhlIHByb3RvdHlwZS5cblx0XHQqIFdpdGggdGhpcyBwcm9wYWdhdGlvbiwgd2UgbWFrZSBzdXJlIHRoYXQgdGhvc2UgZGVzY3JpcHRvcnMgdHJpZ2dlclxuXHRcdCogd2hlbiB0aGUgdXNlciBvcGVyYXRlcyB3aXRoIHRoZSBwcm94aWVkIHJlcXVlc3QgaW5zdGFuY2UuXG5cdFx0Ki9cblx0XHRjb25zdCBwcm90b3R5cGVEZXNjcmlwdG9ycyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHRhcmdldC5wcm90b3R5cGUpO1xuXHRcdGZvciAoY29uc3QgcHJvcGVydHlOYW1lIGluIHByb3RvdHlwZURlc2NyaXB0b3JzKSBSZWZsZWN0LmRlZmluZVByb3BlcnR5KG9yaWdpbmFsUmVxdWVzdCwgcHJvcGVydHlOYW1lLCBwcm90b3R5cGVEZXNjcmlwdG9yc1twcm9wZXJ0eU5hbWVdKTtcblx0XHRjb25zdCB4aHJSZXF1ZXN0Q29udHJvbGxlciA9IG5ldyBYTUxIdHRwUmVxdWVzdENvbnRyb2xsZXIob3JpZ2luYWxSZXF1ZXN0LCBsb2dnZXIpO1xuXHRcdHhoclJlcXVlc3RDb250cm9sbGVyLm9uUmVxdWVzdCA9IGFzeW5jIGZ1bmN0aW9uKHsgcmVxdWVzdCwgcmVxdWVzdElkIH0pIHtcblx0XHRcdGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgUmVxdWVzdENvbnRyb2xsZXIocmVxdWVzdCwge1xuXHRcdFx0XHRwYXNzdGhyb3VnaDogKCkgPT4ge1xuXHRcdFx0XHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJubyBtb2NrZWQgcmVzcG9uc2UgcmVjZWl2ZWQsIHBlcmZvcm1pbmcgcmVxdWVzdCBhcy1pcy4uLlwiKTtcblx0XHRcdFx0fSxcblx0XHRcdFx0cmVzcG9uZFdpdGg6IGFzeW5jIChyZXNwb25zZSkgPT4ge1xuXHRcdFx0XHRcdGF3YWl0IHRoaXMucmVzcG9uZFdpdGgocmVzcG9uc2UpO1xuXHRcdFx0XHR9LFxuXHRcdFx0XHRlcnJvcldpdGg6IChyZWFzb24pID0+IHtcblx0XHRcdFx0XHR0aGlzLmxvZ2dlci52ZXJib3NlKFwicmVxdWVzdCBlcnJvcmVkICVvXCIsIHsgZXJyb3I6IHJlYXNvbiB9KTtcblx0XHRcdFx0XHRpZiAocmVhc29uIGluc3RhbmNlb2YgRXJyb3IpIHRoaXMuZXJyb3JXaXRoKHJlYXNvbik7XG5cdFx0XHRcdH1cblx0XHRcdH0sIHtcblx0XHRcdFx0bG9nZ2VyLFxuXHRcdFx0XHRyZXF1ZXN0SWRcblx0XHRcdH0pO1xuXHRcdFx0dGhpcy5sb2dnZXIudmVyYm9zZShcImF3YWl0aW5nIG1vY2tlZCByZXNwb25zZVwiKTtcblx0XHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJlbWl0dGluZyB0aGUgXFxcInJlcXVlc3RcXFwiIGV2ZW50IGZvciAlcyBsaXN0ZW5lcihzKS4uLlwiLCBlbWl0dGVyLmxpc3RlbmVyQ291bnQoXCJyZXF1ZXN0XCIpKTtcblx0XHRcdGF3YWl0IGhhbmRsZVJlcXVlc3Qoe1xuXHRcdFx0XHRpbml0aWF0b3I6IHRoaXMucmVxdWVzdCxcblx0XHRcdFx0cmVxdWVzdCxcblx0XHRcdFx0cmVxdWVzdElkLFxuXHRcdFx0XHRjb250cm9sbGVyLFxuXHRcdFx0XHRlbWl0dGVyLFxuXHRcdFx0XHRsb2dnZXJcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0eGhyUmVxdWVzdENvbnRyb2xsZXIub25SZXNwb25zZSA9IGFzeW5jIGZ1bmN0aW9uKHsgcmVzcG9uc2UsIHJlc3BvbnNlVHlwZSwgcmVxdWVzdCwgcmVxdWVzdElkIH0pIHtcblx0XHRcdHRoaXMubG9nZ2VyLnZlcmJvc2UoXCJlbWl0dGluZyB0aGUgXFxcInJlc3BvbnNlXFxcIiBldmVudCBmb3IgJXMgbGlzdGVuZXIocykuLi5cIiwgZW1pdHRlci5saXN0ZW5lckNvdW50KFwicmVzcG9uc2VcIikpO1xuXHRcdFx0YXdhaXQgZW1pdHRlci5lbWl0QXNQcm9taXNlKG5ldyBIdHRwUmVzcG9uc2VFdmVudCh7XG5cdFx0XHRcdGluaXRpYXRvcjogdGhpcy5yZXF1ZXN0LFxuXHRcdFx0XHRyZXNwb25zZSxcblx0XHRcdFx0cmVzcG9uc2VUeXBlLFxuXHRcdFx0XHRyZXF1ZXN0LFxuXHRcdFx0XHRyZXF1ZXN0SWRcblx0XHRcdH0pKTtcblx0XHR9O1xuXHRcdHJldHVybiB4aHJSZXF1ZXN0Q29udHJvbGxlci5yZXF1ZXN0O1xuXHR9IH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2ludGVyY2VwdG9ycy9YTUxIdHRwUmVxdWVzdC93ZWIudHNcbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZUxvZ2dlcihcInhoclwiKTtcbnZhciBYTUxIdHRwUmVxdWVzdEludGVyY2VwdG9yID0gY2xhc3MgZXh0ZW5kcyBJbnRlcmNlcHRvciB7XG5cdHN0YXRpYyB7XG5cdFx0dGhpcy5zeW1ib2wgPSBTeW1ib2wuZm9yKFwieGhyLWludGVyY2VwdG9yXCIpO1xuXHR9XG5cdHByZWRpY2F0ZSgpIHtcblx0XHRyZXR1cm4gaGFzQ29uZmlndXJhYmxlR2xvYmFsKFwiWE1MSHR0cFJlcXVlc3RcIik7XG5cdH1cblx0c2V0dXAoKSB7XG5cdFx0bG9nZ2VyLnZlcmJvc2UoXCJwYXRjaGluZyBcXFwiWE1MSHR0cFJlcXVlc3RcXFwiLi4uXCIpO1xuXHRcdHRoaXMuc3Vic2NyaXB0aW9ucy5wdXNoKHBhdGNoZXNSZWdpc3RyeS5hcHBseVBhdGNoKGdsb2JhbFRoaXMsIFwiWE1MSHR0cFJlcXVlc3RcIiwgKCkgPT4ge1xuXHRcdFx0cmV0dXJuIGNyZWF0ZVhNTEh0dHBSZXF1ZXN0UHJveHkoe1xuXHRcdFx0XHRlbWl0dGVyOiB0aGlzLmVtaXR0ZXIsXG5cdFx0XHRcdGxvZ2dlclxuXHRcdFx0fSk7XG5cdFx0fSkpO1xuXHRcdGxvZ2dlci52ZXJib3NlKFwiZ2xvYmFsIFxcXCJYTUxIdHRwUmVxdWVzdFxcXCIgcGF0Y2hlZCFcIiwgZ2xvYmFsVGhpcy5YTUxIdHRwUmVxdWVzdC5uYW1lKTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgWE1MSHR0cFJlcXVlc3RJbnRlcmNlcHRvciBhcyB0IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXdlYi1CUkJRM1lQcC5qcy5tYXAiLCJpbXBvcnQgeyBuIGFzIEludGVyY2VwdG9yLCByIGFzIGNyZWF0ZUxvZ2dlciwgdCBhcyBjcmVhdGVSZXF1ZXN0SWQgfSBmcm9tIFwiLi9jcmVhdGUtcmVxdWVzdC1pZC1Zb2JVbkpOTy5qc1wiO1xuaW1wb3J0IHsgYyBhcyBSZXF1ZXN0Q29udHJvbGxlciwgaSBhcyBpc1Jlc3BvbnNlRXJyb3IsIG4gYXMgRmV0Y2hSZXNwb25zZSwgcyBhcyBjb3B5UmF3SGVhZGVycyB9IGZyb20gXCIuL2ZldGNoLXV0aWxzLUM2UDZnTExvLmpzXCI7XG5pbXBvcnQgeyBuIGFzIEh0dHBSZXNwb25zZUV2ZW50LCB0IGFzIGhhbmRsZVJlcXVlc3QgfSBmcm9tIFwiLi9oYW5kbGUtcmVxdWVzdC15N2FqeXZlNS5qc1wiO1xuaW1wb3J0IHsgbiBhcyBwYXRjaGVzUmVnaXN0cnksIHQgYXMgaGFzQ29uZmlndXJhYmxlR2xvYmFsIH0gZnJvbSBcIi4vaGFzLWNvbmZpZ3VyYWJsZS1nbG9iYWwtQ2V3LWRZcWsuanNcIjtcbmltcG9ydCB7IGludmFyaWFudCB9IGZyb20gXCJvdXR2YXJpYW50XCI7XG5pbXBvcnQgeyB1bnRpbCB9IGZyb20gXCJAb3Blbi1kcmFmdC91bnRpbFwiO1xuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvZmV0Y2gvdXRpbHMvY3JlYXRlLW5ldHdvcmstZXJyb3IudHNcbmZ1bmN0aW9uIGNyZWF0ZU5ldHdvcmtFcnJvcihjYXVzZSkge1xuXHRyZXR1cm4gT2JqZWN0LmFzc2lnbigvKiBAX19QVVJFX18gKi8gbmV3IFR5cGVFcnJvcihcIkZhaWxlZCB0byBmZXRjaFwiKSwgeyBjYXVzZSB9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9pbnRlcmNlcHRvcnMvZmV0Y2gvdXRpbHMvZm9sbG93LXJlZGlyZWN0LnRzXG5jb25zdCBSRVFVRVNUX0JPRFlfSEVBREVSUyA9IFtcblx0XCJjb250ZW50LWVuY29kaW5nXCIsXG5cdFwiY29udGVudC1sYW5ndWFnZVwiLFxuXHRcImNvbnRlbnQtbG9jYXRpb25cIixcblx0XCJjb250ZW50LXR5cGVcIixcblx0XCJjb250ZW50LWxlbmd0aFwiXG5dO1xuY29uc3Qga1JlZGlyZWN0Q291bnQgPSBTeW1ib2woXCJrUmVkaXJlY3RDb3VudFwiKTtcbi8qKlxuKiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9ub2RlanMvdW5kaWNpL2Jsb2IvYTZkYWMzMTQ5YzUwNWI1OGQyZTZkMDY4Yjk3ZjRkYzk5M2RhNTVmMC9saWIvd2ViL2ZldGNoL2luZGV4LmpzI0wxMjEwXG4qL1xuYXN5bmMgZnVuY3Rpb24gZm9sbG93RmV0Y2hSZWRpcmVjdChyZXF1ZXN0LCByZXNwb25zZSkge1xuXHRpZiAocmVzcG9uc2Uuc3RhdHVzICE9PSAzMDMgJiYgcmVxdWVzdC5ib2R5ICE9IG51bGwpIHJldHVybiBQcm9taXNlLnJlamVjdChjcmVhdGVOZXR3b3JrRXJyb3IoKSk7XG5cdGNvbnN0IHJlcXVlc3RVcmwgPSBuZXcgVVJMKHJlcXVlc3QudXJsKTtcblx0bGV0IGxvY2F0aW9uVXJsO1xuXHR0cnkge1xuXHRcdGxvY2F0aW9uVXJsID0gbmV3IFVSTChyZXNwb25zZS5oZWFkZXJzLmdldChcImxvY2F0aW9uXCIpLCByZXF1ZXN0LnVybCk7XG5cdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KGNyZWF0ZU5ldHdvcmtFcnJvcihlcnJvcikpO1xuXHR9XG5cdGlmICghKGxvY2F0aW9uVXJsLnByb3RvY29sID09PSBcImh0dHA6XCIgfHwgbG9jYXRpb25VcmwucHJvdG9jb2wgPT09IFwiaHR0cHM6XCIpKSByZXR1cm4gUHJvbWlzZS5yZWplY3QoY3JlYXRlTmV0d29ya0Vycm9yKFwiVVJMIHNjaGVtZSBtdXN0IGJlIGEgSFRUUChTKSBzY2hlbWVcIikpO1xuXHRpZiAoUmVmbGVjdC5nZXQocmVxdWVzdCwga1JlZGlyZWN0Q291bnQpID4gMjApIHJldHVybiBQcm9taXNlLnJlamVjdChjcmVhdGVOZXR3b3JrRXJyb3IoXCJyZWRpcmVjdCBjb3VudCBleGNlZWRlZFwiKSk7XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShyZXF1ZXN0LCBrUmVkaXJlY3RDb3VudCwgeyB2YWx1ZTogKFJlZmxlY3QuZ2V0KHJlcXVlc3QsIGtSZWRpcmVjdENvdW50KSB8fCAwKSArIDEgfSk7XG5cdGlmIChyZXF1ZXN0Lm1vZGUgPT09IFwiY29yc1wiICYmIChsb2NhdGlvblVybC51c2VybmFtZSB8fCBsb2NhdGlvblVybC5wYXNzd29yZCkgJiYgIXNhbWVPcmlnaW4ocmVxdWVzdFVybCwgbG9jYXRpb25VcmwpKSByZXR1cm4gUHJvbWlzZS5yZWplY3QoY3JlYXRlTmV0d29ya0Vycm9yKFwiY3Jvc3Mgb3JpZ2luIG5vdCBhbGxvd2VkIGZvciByZXF1ZXN0IG1vZGUgXFxcImNvcnNcXFwiXCIpKTtcblx0Y29uc3QgcmVxdWVzdEluaXQgPSB7fTtcblx0aWYgKFszMDEsIDMwMl0uaW5jbHVkZXMocmVzcG9uc2Uuc3RhdHVzKSAmJiByZXF1ZXN0Lm1ldGhvZCA9PT0gXCJQT1NUXCIgfHwgcmVzcG9uc2Uuc3RhdHVzID09PSAzMDMgJiYgIVtcIkhFQURcIiwgXCJHRVRcIl0uaW5jbHVkZXMocmVxdWVzdC5tZXRob2QpKSB7XG5cdFx0cmVxdWVzdEluaXQubWV0aG9kID0gXCJHRVRcIjtcblx0XHRyZXF1ZXN0SW5pdC5ib2R5ID0gbnVsbDtcblx0XHRSRVFVRVNUX0JPRFlfSEVBREVSUy5mb3JFYWNoKChoZWFkZXJOYW1lKSA9PiB7XG5cdFx0XHRyZXF1ZXN0LmhlYWRlcnMuZGVsZXRlKGhlYWRlck5hbWUpO1xuXHRcdH0pO1xuXHR9XG5cdGlmICghc2FtZU9yaWdpbihyZXF1ZXN0VXJsLCBsb2NhdGlvblVybCkpIHtcblx0XHRyZXF1ZXN0LmhlYWRlcnMuZGVsZXRlKFwiYXV0aG9yaXphdGlvblwiKTtcblx0XHRyZXF1ZXN0LmhlYWRlcnMuZGVsZXRlKFwicHJveHktYXV0aG9yaXphdGlvblwiKTtcblx0XHRyZXF1ZXN0LmhlYWRlcnMuZGVsZXRlKFwiY29va2llXCIpO1xuXHRcdHJlcXVlc3QuaGVhZGVycy5kZWxldGUoXCJob3N0XCIpO1xuXHR9XG5cdC8qKlxuXHQqIEBub3RlIFVuZGljaSBcInNhZmVseVwiIGV4dHJhY3RzIHRoZSByZXF1ZXN0IGJvZHkuXG5cdCogSSBzdXNwZWN0IHdlIGNhbm5vdCBkaXNwYXRjaCB0aGlzIHJlcXVlc3QgYWdhaW5cblx0KiBzaW5jZSBpdHMgYm9keSBoYXMgYmVlbiByZWFkIGFuZCB0aGUgc3RyZWFtIGlzIGxvY2tlZC5cblx0Ki9cblx0cmVxdWVzdEluaXQuaGVhZGVycyA9IHJlcXVlc3QuaGVhZGVycztcblx0Y29uc3QgZmluYWxSZXNwb25zZSA9IGF3YWl0IGZldGNoKG5ldyBSZXF1ZXN0KGxvY2F0aW9uVXJsLCByZXF1ZXN0SW5pdCkpO1xuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZmluYWxSZXNwb25zZSwgXCJyZWRpcmVjdGVkXCIsIHtcblx0XHR2YWx1ZTogdHJ1ZSxcblx0XHRjb25maWd1cmFibGU6IHRydWVcblx0fSk7XG5cdHJldHVybiBmaW5hbFJlc3BvbnNlO1xufVxuLyoqXG4qIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL25vZGVqcy91bmRpY2kvYmxvYi9hNmRhYzMxNDljNTA1YjU4ZDJlNmQwNjhiOTdmNGRjOTkzZGE1NWYwL2xpYi93ZWIvZmV0Y2gvdXRpbC5qcyNMNzYxXG4qL1xuZnVuY3Rpb24gc2FtZU9yaWdpbihsZWZ0LCByaWdodCkge1xuXHRpZiAobGVmdC5vcmlnaW4gPT09IHJpZ2h0Lm9yaWdpbiAmJiBsZWZ0Lm9yaWdpbiA9PT0gXCJudWxsXCIpIHJldHVybiB0cnVlO1xuXHRpZiAobGVmdC5wcm90b2NvbCA9PT0gcmlnaHQucHJvdG9jb2wgJiYgbGVmdC5ob3N0bmFtZSA9PT0gcmlnaHQuaG9zdG5hbWUgJiYgbGVmdC5wb3J0ID09PSByaWdodC5wb3J0KSByZXR1cm4gdHJ1ZTtcblx0cmV0dXJuIGZhbHNlO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2ludGVyY2VwdG9ycy9mZXRjaC91dGlscy9icm90bGktZGVjb21wcmVzcy5icm93c2VyLnRzXG52YXIgQnJvdGxpRGVjb21wcmVzc2lvblN0cmVhbSA9IGNsYXNzIGV4dGVuZHMgVHJhbnNmb3JtU3RyZWFtIHtcblx0Y29uc3RydWN0b3IoKSB7XG5cdFx0Y29uc29sZS53YXJuKFwiW0ludGVyY2VwdG9yc106IEJyb3RsaSBkZWNvbXByZXNzaW9uIG9mIHJlc3BvbnNlIHN0cmVhbXMgaXMgbm90IHN1cHBvcnRlZCBpbiB0aGUgYnJvd3NlclwiKTtcblx0XHRzdXBlcih7IHRyYW5zZm9ybShjaHVuaywgY29udHJvbGxlcikge1xuXHRcdFx0Y29udHJvbGxlci5lbnF1ZXVlKGNodW5rKTtcblx0XHR9IH0pO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2ludGVyY2VwdG9ycy9mZXRjaC91dGlscy9kZWNvbXByZXNzaW9uLnRzXG52YXIgUGlwZWxpbmVTdHJlYW0gPSBjbGFzcyBleHRlbmRzIFRyYW5zZm9ybVN0cmVhbSB7XG5cdGNvbnN0cnVjdG9yKHRyYW5zZm9ybVN0cmVhbXMsIC4uLnN0cmF0ZWdpZXMpIHtcblx0XHRzdXBlcih7fSwgLi4uc3RyYXRlZ2llcyk7XG5cdFx0Y29uc3QgcmVhZGFibGUgPSBbc3VwZXIucmVhZGFibGUsIC4uLnRyYW5zZm9ybVN0cmVhbXNdLnJlZHVjZSgocmVhZGFibGUsIHRyYW5zZm9ybSkgPT4gcmVhZGFibGUucGlwZVRocm91Z2godHJhbnNmb3JtKSk7XG5cdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KHRoaXMsIFwicmVhZGFibGVcIiwgeyBnZXQoKSB7XG5cdFx0XHRyZXR1cm4gcmVhZGFibGU7XG5cdFx0fSB9KTtcblx0fVxufTtcbmZ1bmN0aW9uIHBhcnNlQ29udGVudEVuY29kaW5nKGNvbnRlbnRFbmNvZGluZykge1xuXHRyZXR1cm4gY29udGVudEVuY29kaW5nLnRvTG93ZXJDYXNlKCkuc3BsaXQoXCIsXCIpLm1hcCgoY29kaW5nKSA9PiBjb2RpbmcudHJpbSgpKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZURlY29tcHJlc3Npb25TdHJlYW0oY29udGVudEVuY29kaW5nKSB7XG5cdHJldHVybiBuZXcgUGlwZWxpbmVTdHJlYW0ocGFyc2VDb250ZW50RW5jb2RpbmcoY29udGVudEVuY29kaW5nKS5yZWR1Y2VSaWdodCgodHJhbnNmb3JtZXJzLCBjb2RpbmcpID0+IHtcblx0XHRpZiAoY29kaW5nID09PSBcImd6aXBcIiB8fCBjb2RpbmcgPT09IFwieC1nemlwXCIpIHJldHVybiB0cmFuc2Zvcm1lcnMuY29uY2F0KG5ldyBEZWNvbXByZXNzaW9uU3RyZWFtKFwiZ3ppcFwiKSk7XG5cdFx0ZWxzZSBpZiAoY29kaW5nID09PSBcImRlZmxhdGVcIikgcmV0dXJuIHRyYW5zZm9ybWVycy5jb25jYXQobmV3IERlY29tcHJlc3Npb25TdHJlYW0oXCJkZWZsYXRlXCIpKTtcblx0XHRlbHNlIGlmIChjb2RpbmcgPT09IFwiYnJcIikgcmV0dXJuIHRyYW5zZm9ybWVycy5jb25jYXQobmV3IEJyb3RsaURlY29tcHJlc3Npb25TdHJlYW0oKSk7XG5cdFx0ZWxzZSB0cmFuc2Zvcm1lcnMubGVuZ3RoID0gMDtcblx0XHRyZXR1cm4gdHJhbnNmb3JtZXJzO1xuXHR9LCBbXSkpO1xufVxuLyoqXG4qIFJldHVybnMgYSBib29sZWFuIGluZGljYXRpbmcgd2hldGhlciB0aGUgZ2l2ZW4gcmVzcG9uc2VcbiogaGFzIGEgYm9keSBlbmNvZGVkIHdpdGggYSBub24tZW1wdHkgXCJjb250ZW50LWVuY29kaW5nXCIuXG4qL1xuZnVuY3Rpb24gaXNDb21wcmVzc2VkUmVzcG9uc2UocmVzcG9uc2UpIHtcblx0aWYgKHJlc3BvbnNlLmJvZHkgPT09IG51bGwpIHJldHVybiBmYWxzZTtcblx0Y29uc3QgY29udGVudEVuY29kaW5nID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoXCJjb250ZW50LWVuY29kaW5nXCIpO1xuXHRyZXR1cm4gY29udGVudEVuY29kaW5nICE9PSBudWxsICYmIGNvbnRlbnRFbmNvZGluZy50cmltKCkgIT09IFwiXCI7XG59XG4vKipcbiogRGVjb21wcmVzc2VzIHRoZSBib2R5IG9mIHRoZSBnaXZlbiBjb21wcmVzc2VkIHJlc3BvbnNlLlxuKi9cbmZ1bmN0aW9uIGRlY29tcHJlc3NSZXNwb25zZShyZXNwb25zZSkge1xuXHRpbnZhcmlhbnQoaXNDb21wcmVzc2VkUmVzcG9uc2UocmVzcG9uc2UpLCBcIkZhaWxlZCB0byBkZWNvbXByZXNzIGEgcmVzcG9uc2U6IGV4cGVjdGVkIGEgcmVzcG9uc2Ugd2l0aCBhIGJvZHkgYW5kIGEgbm9uLWVtcHR5IFxcXCJjb250ZW50LWVuY29kaW5nXFxcIiBoZWFkZXJcIik7XG5cdGNvbnN0IGRlY29tcHJlc3Npb25TdHJlYW0gPSBjcmVhdGVEZWNvbXByZXNzaW9uU3RyZWFtKHJlc3BvbnNlLmhlYWRlcnMuZ2V0KFwiY29udGVudC1lbmNvZGluZ1wiKSk7XG5cdHJlc3BvbnNlLmJvZHkucGlwZVRvKGRlY29tcHJlc3Npb25TdHJlYW0ud3JpdGFibGUpO1xuXHRyZXR1cm4gZGVjb21wcmVzc2lvblN0cmVhbS5yZWFkYWJsZTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy91dGlscy9jbG9uZS1yZXNwb25zZS50c1xuLyoqIENsb25lIGZvciBvYnNlcnZlcnMgd2l0aG91dCBsZXR0aW5nIHRoZWlyIHVucmVhZCBib2R5IGJsb2NrIGNhbGxlciBjYW5jZWxsYXRpb24uICovXG5mdW5jdGlvbiBjbG9uZVJlc3BvbnNlKHJlc3BvbnNlKSB7XG5cdGNvbnN0IGNsb25lID0gRmV0Y2hSZXNwb25zZS5jbG9uZShyZXNwb25zZSk7XG5cdGlmICghcmVzcG9uc2UuYm9keSB8fCAhY2xvbmUuYm9keSkgcmV0dXJuIFtyZXNwb25zZSwgY2xvbmVdO1xuXHRjb25zdCBvYnNlcnZlciA9IHdyYXBSZXNwb25zZShjbG9uZSk7XG5cdHJldHVybiBbd3JhcFJlc3BvbnNlKHJlc3BvbnNlLCBvYnNlcnZlci5jYW5jZWwpLnJlc3BvbnNlLCBvYnNlcnZlci5yZXNwb25zZV07XG59XG5mdW5jdGlvbiB3cmFwUmVzcG9uc2UocmVzcG9uc2UsIG9uQ2FuY2VsKSB7XG5cdGNvbnN0IGJvZHkgPSByZXNwb25zZS5ib2R5O1xuXHRjb25zdCByZWFkZXIgPSBib2R5LmdldFJlYWRlcigpO1xuXHRjb25zdCBjYW5jZWwgPSAocmVhc29uKSA9PiB7XG5cdFx0cmV0dXJuIGJvZHkubG9ja2VkID8gcmVhZGVyLmNhbmNlbChyZWFzb24pIDogYm9keS5jYW5jZWwocmVhc29uKTtcblx0fTtcblx0Y29uc3Qgc3RyZWFtID0gbmV3IFJlYWRhYmxlU3RyZWFtKHtcblx0XHRhc3luYyBwdWxsKGNvbnRyb2xsZXIpIHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGNvbnN0IHsgZG9uZSwgdmFsdWUgfSA9IGF3YWl0IHJlYWRlci5yZWFkKCk7XG5cdFx0XHRcdGlmIChkb25lKSB7XG5cdFx0XHRcdFx0Y29udHJvbGxlci5jbG9zZSgpO1xuXHRcdFx0XHRcdHJlYWRlci5yZWxlYXNlTG9jaygpO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXHRcdFx0XHRjb250cm9sbGVyLmVucXVldWUodmFsdWUpO1xuXHRcdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdFx0Y29udHJvbGxlci5lcnJvcihlcnJvcik7XG5cdFx0XHRcdHJlYWRlci5yZWxlYXNlTG9jaygpO1xuXHRcdFx0fVxuXHRcdH0sXG5cdFx0YXN5bmMgY2FuY2VsKHJlYXNvbikge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3QgY2FuY2VsbGF0aW9uID0gY2FuY2VsKHJlYXNvbik7XG5cdFx0XHRcdGlmIChvbkNhbmNlbCkgYXdhaXQgUHJvbWlzZS5hbGwoW2NhbmNlbGxhdGlvbiwgb25DYW5jZWwocmVhc29uKV0pO1xuXHRcdFx0XHRlbHNlIGNhbmNlbGxhdGlvbi5jYXRjaCgoKSA9PiB7fSk7XG5cdFx0XHR9IGZpbmFsbHkge1xuXHRcdFx0XHRyZWFkZXIucmVsZWFzZUxvY2soKTtcblx0XHRcdH1cblx0XHR9XG5cdH0sIHsgaGlnaFdhdGVyTWFyazogMCB9KTtcblx0Y29uc3Qgd3JhcHBlZFJlc3BvbnNlID0gbmV3IEZldGNoUmVzcG9uc2Uoc3RyZWFtLCByZXNwb25zZSk7XG5cdGNvcHlSYXdIZWFkZXJzKHJlc3BvbnNlLmhlYWRlcnMsIHdyYXBwZWRSZXNwb25zZS5oZWFkZXJzKTtcblx0T2JqZWN0LmRlZmluZVByb3BlcnRpZXMod3JhcHBlZFJlc3BvbnNlLCB7XG5cdFx0dHlwZTogeyB2YWx1ZTogcmVzcG9uc2UudHlwZSB9LFxuXHRcdHJlZGlyZWN0ZWQ6IHsgdmFsdWU6IHJlc3BvbnNlLnJlZGlyZWN0ZWQgfVxuXHR9KTtcblx0cmV0dXJuIHtcblx0XHRyZXNwb25zZTogd3JhcHBlZFJlc3BvbnNlLFxuXHRcdGNhbmNlbFxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2ludGVyY2VwdG9ycy9mZXRjaC93ZWIudHNcbmNvbnN0IGxvZ2dlciA9IGNyZWF0ZUxvZ2dlcihcImZldGNoXCIpO1xuLyoqXG4qIEludGVyY2VwdCBgZmV0Y2hgIHJlcXVlc3RzIGluIHRoZSBicm93c2VyLlxuKi9cbnZhciBGZXRjaEludGVyY2VwdG9yID0gY2xhc3MgZXh0ZW5kcyBJbnRlcmNlcHRvciB7XG5cdHN0YXRpYyB7XG5cdFx0dGhpcy5zeW1ib2wgPSBTeW1ib2wuZm9yKFwiZmV0Y2gtaW50ZXJjZXB0b3JcIik7XG5cdH1cblx0cHJlZGljYXRlKCkge1xuXHRcdHJldHVybiBoYXNDb25maWd1cmFibGVHbG9iYWwoXCJmZXRjaFwiKTtcblx0fVxuXHRhc3luYyBzZXR1cCgpIHtcblx0XHRsb2dnZXIudmVyYm9zZShcInBhdGNoaW5nIGdsb2JhbCBmZXRjaC4uLlwiKTtcblx0XHR0aGlzLnN1YnNjcmlwdGlvbnMucHVzaChwYXRjaGVzUmVnaXN0cnkuYXBwbHlQYXRjaChnbG9iYWxUaGlzLCBcImZldGNoXCIsIChyZWFsRmV0Y2gpID0+IHtcblx0XHRcdHJldHVybiBhc3luYyAoaW5wdXQsIGluaXQpID0+IHtcblx0XHRcdFx0Y29uc3QgcmVxdWVzdElkID0gY3JlYXRlUmVxdWVzdElkKCk7XG5cdFx0XHRcdC8qKlxuXHRcdFx0XHQqIEBub3RlIFJlc29sdmUgcG90ZW50aWFsbHkgcmVsYXRpdmUgcmVxdWVzdCBVUkxcblx0XHRcdFx0KiBhZ2FpbnN0IHRoZSBwcmVzZW50IGBsb2NhdGlvbmAuIFRoaXMgaXMgbWFpbmx5XG5cdFx0XHRcdCogZm9yIG5hdGl2ZSBgZmV0Y2hgIGluIEpTRE9NLlxuXHRcdFx0XHQqIEBzZWUgaHR0cHM6Ly9naXRodWIuY29tL21zd2pzL21zdy9pc3N1ZXMvMTYyNVxuXHRcdFx0XHQqL1xuXHRcdFx0XHRjb25zdCByZXNvbHZlZElucHV0ID0gdHlwZW9mIGlucHV0ID09PSBcInN0cmluZ1wiICYmIHR5cGVvZiBsb2NhdGlvbiAhPT0gXCJ1bmRlZmluZWRcIiAmJiAhVVJMLmNhblBhcnNlKGlucHV0KSA/IG5ldyBVUkwoaW5wdXQsIGxvY2F0aW9uLmhyZWYpIDogaW5wdXQ7XG5cdFx0XHRcdGNvbnN0IHJlcXVlc3QgPSBuZXcgUmVxdWVzdChyZXNvbHZlZElucHV0LCBpbml0KTtcblx0XHRcdFx0Y29uc3QgcmVzcG9uc2VQcm9taXNlID0gUHJvbWlzZS53aXRoUmVzb2x2ZXJzKCk7XG5cdFx0XHRcdGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgUmVxdWVzdENvbnRyb2xsZXIocmVxdWVzdCwge1xuXHRcdFx0XHRcdHBhc3N0aHJvdWdoOiBhc3luYyAoKSA9PiB7XG5cdFx0XHRcdFx0XHRsb2dnZXIudmVyYm9zZShcInBlcmZvcm1pbmcgcmVxdWVzdCBhcy1pc1wiKTtcblx0XHRcdFx0XHRcdC8qKlxuXHRcdFx0XHRcdFx0KiBAbm90ZSBQZXJmb3JtIGEgY2xvbmUgb2YgdGhlIHJlcXVlc3QgaW5zdGFuY2UsIG5vdCB0aGUgaW5zdGFuY2UgaXRzZWxmLlxuXHRcdFx0XHRcdFx0KiBQZXJmb3JtaW5nIGEgcmVxdWVzdCBjb25zdW1lcyBpdHMgYm9keSwgYW5kIHRoZSBcInJlc3BvbnNlXCIgbGlzdGVuZXJcblx0XHRcdFx0XHRcdCogbXVzdCBzdGlsbCBiZSBhYmxlIHRvIHJlYWQgaXQuIFRoZSBjbG9uZSBpcyBjcmVhdGVkIHJpZ2h0IGJlZm9yZVxuXHRcdFx0XHRcdFx0KiB0aGUgcmVxdWVzdCBpcyBwZXJmb3JtZWQsIHNvIGl0IHByZXNlcnZlcyBhbnkgbW9kaWZpY2F0aW9ucyBtYWRlXG5cdFx0XHRcdFx0XHQqIHRvIHRoZSBpbnRlcmNlcHRlZCByZXF1ZXN0IGluIHRoZSBcInJlcXVlc3RcIiBsaXN0ZW5lci5cblx0XHRcdFx0XHRcdCpcblx0XHRcdFx0XHRcdCogVGhpcyBhbHNvIGtlZXBzIHRoZSByZXF1ZXN0IGluc3RhbmNlIGVtaXR0ZWQgb24gdGhlIFwicmVzcG9uc2VcIiBldmVudFxuXHRcdFx0XHRcdFx0KiByZWZlcmVudGlhbGx5IGVxdWFsIHRvIHRoZSBvbmUgZW1pdHRlZCBvbiB0aGUgXCJyZXF1ZXN0XCIgZXZlbnRcblx0XHRcdFx0XHRcdCogc28gdGhlIGNvbnN1bWVyIGNhbiBhc3NvY2lhdGUgdGhlIHR3byBieSBpZGVudGl0eS5cblx0XHRcdFx0XHRcdCovXG5cdFx0XHRcdFx0XHRjb25zdCByZXF1ZXN0Q2xvbmUgPSByZXF1ZXN0LmNsb25lKCk7XG5cdFx0XHRcdFx0XHRjb25zdCBbcmVzcG9uc2VFcnJvciwgb3JpZ2luYWxSZXNwb25zZV0gPSBhd2FpdCB1bnRpbCgoKSA9PiByZWFsRmV0Y2gocmVxdWVzdENsb25lKSk7XG5cdFx0XHRcdFx0XHRpZiAocmVzcG9uc2VFcnJvcikgcmV0dXJuIHJlc3BvbnNlUHJvbWlzZS5yZWplY3QocmVzcG9uc2VFcnJvcik7XG5cdFx0XHRcdFx0XHRsb2dnZXIudmVyYm9zZShcIm9yaWdpbmFsIGZldGNoIHBlcmZvcm1lZCAlb1wiLCBvcmlnaW5hbFJlc3BvbnNlKTtcblx0XHRcdFx0XHRcdGlmICh0aGlzLmVtaXR0ZXIubGlzdGVuZXJDb3VudChcInJlc3BvbnNlXCIpID4gMCkge1xuXHRcdFx0XHRcdFx0XHRsb2dnZXIudmVyYm9zZShcImVtaXR0aW5nIHRoZSBcXFwicmVzcG9uc2VcXFwiIGV2ZW50XCIpO1xuXHRcdFx0XHRcdFx0XHRjb25zdCBbcmVzcG9uc2UsIHJlc3BvbnNlQ2xvbmVdID0gY2xvbmVSZXNwb25zZShvcmlnaW5hbFJlc3BvbnNlKTtcblx0XHRcdFx0XHRcdFx0YXdhaXQgdGhpcy5lbWl0dGVyLmVtaXRBc1Byb21pc2UobmV3IEh0dHBSZXNwb25zZUV2ZW50KHtcblx0XHRcdFx0XHRcdFx0XHRpbml0aWF0b3I6IHJlcXVlc3QsXG5cdFx0XHRcdFx0XHRcdFx0cmVxdWVzdCxcblx0XHRcdFx0XHRcdFx0XHRyZXF1ZXN0SWQsXG5cdFx0XHRcdFx0XHRcdFx0cmVzcG9uc2U6IHJlc3BvbnNlQ2xvbmUsXG5cdFx0XHRcdFx0XHRcdFx0cmVzcG9uc2VUeXBlOiBcIm9yaWdpbmFsXCJcblx0XHRcdFx0XHRcdFx0fSkpO1xuXHRcdFx0XHRcdFx0XHRyZXNwb25zZVByb21pc2UucmVzb2x2ZShyZXNwb25zZSk7XG5cdFx0XHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdHJlc3BvbnNlUHJvbWlzZS5yZXNvbHZlKG9yaWdpbmFsUmVzcG9uc2UpO1xuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0cmVzcG9uZFdpdGg6IGFzeW5jIChyYXdSZXNwb25zZSkgPT4ge1xuXHRcdFx0XHRcdFx0aWYgKGlzUmVzcG9uc2VFcnJvcihyYXdSZXNwb25zZSkpIHtcblx0XHRcdFx0XHRcdFx0bG9nZ2VyLnZlcmJvc2UoXCJyZXF1ZXN0IGVycm9yZWQgJW9cIiwgeyByZXNwb25zZTogcmF3UmVzcG9uc2UgfSk7XG5cdFx0XHRcdFx0XHRcdHJlc3BvbnNlUHJvbWlzZS5yZWplY3QoY3JlYXRlTmV0d29ya0Vycm9yKHJhd1Jlc3BvbnNlKSk7XG5cdFx0XHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdC8qKlxuXHRcdFx0XHRcdFx0KiBAbm90ZSBGb3J3YXJkIHRoZSBtb2NrZWQgcmVzcG9uc2UgaW5zdGFuY2UgYXMtaXMuIFdyYXBwaW5nIGl0XG5cdFx0XHRcdFx0XHQqIGluIGEgbmV3IGBSZXNwb25zZWAgZHJvcHMgYW55IHJ1bnRpbWUtc3BlY2lmaWMgc3RhdGUgdGhlXG5cdFx0XHRcdFx0XHQqIGVudmlyb25tZW50IGF0dGFjaGVkIHRvIGl0IChlLmcuIHRoZSBgd2ViU29ja2V0YCBwcm9wZXJ0eVxuXHRcdFx0XHRcdFx0KiBvZiBhIFwiMTAxIFN3aXRjaGluZyBQcm90b2NvbHNcIiByZXNwb25zZSBpbiB3b3JrZXJkKS5cblx0XHRcdFx0XHRcdCogQSBwbGFpbiBgUmVzcG9uc2VgIGlzIGFscmVhZHkgZ3VhcmFudGVlZCB0byBiZSB2YWxpZCBieSB0aGVcblx0XHRcdFx0XHRcdCogZW52aXJvbm1lbnQsIGFuZCBhIGBGZXRjaFJlc3BvbnNlYCBtYW5hZ2VzIGl0cyBvd25cblx0XHRcdFx0XHRcdCogbm9uLWNvbmZpZ3VyYWJsZSBzdGF0ZSAoc3RhdHVzLCBVUkwpIGFjcm9zcyBjbG9uZXMuXG5cdFx0XHRcdFx0XHQqXG5cdFx0XHRcdFx0XHQqIFRoZSBvbmx5IGV4Y2VwdGlvbiBpcyBhIGNvbXByZXNzZWQgbW9ja2VkIHJlc3BvbnNlIGJvZHk6XG5cdFx0XHRcdFx0XHQqIGEgYm9keSBjYW5ub3QgYmUgc3dhcHBlZCBpbiBwbGFjZSwgc28gaXQgbXVzdCBiZSBhIG5ldyBpbnN0YW5jZS5cblx0XHRcdFx0XHRcdCovXG5cdFx0XHRcdFx0XHRsZXQgcmVzcG9uc2U7XG5cdFx0XHRcdFx0XHRpZiAoaXNDb21wcmVzc2VkUmVzcG9uc2UocmF3UmVzcG9uc2UpKSB7XG5cdFx0XHRcdFx0XHRcdHJlc3BvbnNlID0gbmV3IEZldGNoUmVzcG9uc2UoZGVjb21wcmVzc1Jlc3BvbnNlKHJhd1Jlc3BvbnNlKSwge1xuXHRcdFx0XHRcdFx0XHRcdHN0YXR1czogcmF3UmVzcG9uc2Uuc3RhdHVzLFxuXHRcdFx0XHRcdFx0XHRcdHN0YXR1c1RleHQ6IHJhd1Jlc3BvbnNlLnN0YXR1c1RleHQsXG5cdFx0XHRcdFx0XHRcdFx0aGVhZGVyczogcmF3UmVzcG9uc2UuaGVhZGVyc1xuXHRcdFx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRcdFx0Y29weVJhd0hlYWRlcnMocmF3UmVzcG9uc2UuaGVhZGVycywgcmVzcG9uc2UuaGVhZGVycyk7XG5cdFx0XHRcdFx0XHR9IGVsc2UgcmVzcG9uc2UgPSByYXdSZXNwb25zZTtcblx0XHRcdFx0XHRcdEZldGNoUmVzcG9uc2Uuc2V0VXJsKHJlcXVlc3QudXJsLCByZXNwb25zZSk7XG5cdFx0XHRcdFx0XHQvKipcblx0XHRcdFx0XHRcdCogVW5kaWNpJ3MgaGFuZGxpbmcgb2YgZm9sbG93aW5nIHJlZGlyZWN0IHJlc3BvbnNlcy5cblx0XHRcdFx0XHRcdCogVHJlYXQgdGhlIFwibWFudWFsXCIgcmVkaXJlY3QgbW9kZSBhcyBhIHJlZ3VsYXIgbW9ja2VkIHJlc3BvbnNlLlxuXHRcdFx0XHRcdFx0KiBUaGlzIHdheSwgdGhlIGNsaWVudCBjYW4gbWFudWFsbHkgZm9sbG93IHRoZSByZWRpcmVjdCBpdCByZWNlaXZlcy5cblx0XHRcdFx0XHRcdCogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vbm9kZWpzL3VuZGljaS9ibG9iL2E2ZGFjMzE0OWM1MDViNThkMmU2ZDA2OGI5N2Y0ZGM5OTNkYTU1ZjAvbGliL3dlYi9mZXRjaC9pbmRleC5qcyNMMTE3M1xuXHRcdFx0XHRcdFx0Ki9cblx0XHRcdFx0XHRcdGlmIChGZXRjaFJlc3BvbnNlLmlzUmVkaXJlY3RSZXNwb25zZShyZXNwb25zZS5zdGF0dXMpKSB7XG5cdFx0XHRcdFx0XHRcdGlmIChyZXF1ZXN0LnJlZGlyZWN0ID09PSBcImVycm9yXCIpIHtcblx0XHRcdFx0XHRcdFx0XHRyZXNwb25zZVByb21pc2UucmVqZWN0KGNyZWF0ZU5ldHdvcmtFcnJvcihcInVuZXhwZWN0ZWQgcmVkaXJlY3RcIikpO1xuXHRcdFx0XHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0XHRpZiAocmVxdWVzdC5yZWRpcmVjdCA9PT0gXCJmb2xsb3dcIikge1xuXHRcdFx0XHRcdFx0XHRcdGZvbGxvd0ZldGNoUmVkaXJlY3QocmVxdWVzdCwgcmVzcG9uc2UpLnRoZW4oKHJlc3BvbnNlKSA9PiB7XG5cdFx0XHRcdFx0XHRcdFx0XHRyZXNwb25zZVByb21pc2UucmVzb2x2ZShyZXNwb25zZSk7XG5cdFx0XHRcdFx0XHRcdFx0fSwgKHJlYXNvbikgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdFx0cmVzcG9uc2VQcm9taXNlLnJlamVjdChyZWFzb24pO1xuXHRcdFx0XHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0aWYgKHRoaXMuZW1pdHRlci5saXN0ZW5lckNvdW50KFwicmVzcG9uc2VcIikgPiAwKSB7XG5cdFx0XHRcdFx0XHRcdGxvZ2dlci52ZXJib3NlKFwiZW1pdHRpbmcgdGhlIFxcXCJyZXNwb25zZVxcXCIgZXZlbnRcIik7XG5cdFx0XHRcdFx0XHRcdGNvbnN0IFtjYWxsZXJSZXNwb25zZSwgcmVzcG9uc2VDbG9uZV0gPSBjbG9uZVJlc3BvbnNlKHJlc3BvbnNlKTtcblx0XHRcdFx0XHRcdFx0YXdhaXQgdGhpcy5lbWl0dGVyLmVtaXRBc1Byb21pc2UobmV3IEh0dHBSZXNwb25zZUV2ZW50KHtcblx0XHRcdFx0XHRcdFx0XHRpbml0aWF0b3I6IHJlcXVlc3QsXG5cdFx0XHRcdFx0XHRcdFx0cmVzcG9uc2U6IHJlc3BvbnNlQ2xvbmUsXG5cdFx0XHRcdFx0XHRcdFx0cmVzcG9uc2VUeXBlOiBcIm1vY2tcIixcblx0XHRcdFx0XHRcdFx0XHRyZXF1ZXN0LFxuXHRcdFx0XHRcdFx0XHRcdHJlcXVlc3RJZFxuXHRcdFx0XHRcdFx0XHR9KSk7XG5cdFx0XHRcdFx0XHRcdHJlc3BvbnNlUHJvbWlzZS5yZXNvbHZlKGNhbGxlclJlc3BvbnNlKTtcblx0XHRcdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0cmVzcG9uc2VQcm9taXNlLnJlc29sdmUocmVzcG9uc2UpO1xuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0ZXJyb3JXaXRoOiAocmVhc29uKSA9PiB7XG5cdFx0XHRcdFx0XHRsb2dnZXIudmVyYm9zZShcInJlcXVlc3QgYWJvcnRlZCAlb1wiLCB7IHJlYXNvbiB9KTtcblx0XHRcdFx0XHRcdHJlc3BvbnNlUHJvbWlzZS5yZWplY3QocmVhc29uKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0sIHtcblx0XHRcdFx0XHRsb2dnZXIsXG5cdFx0XHRcdFx0cmVxdWVzdElkXG5cdFx0XHRcdH0pO1xuXHRcdFx0XHRsb2dnZXIudmVyYm9zZShcImF3YWl0aW5nIHJlcXVlc3QgcmVzb2x1dGlvblwiKTtcblx0XHRcdFx0bG9nZ2VyLnZlcmJvc2UoXCJlbWl0dGluZyB0aGUgXFxcInJlcXVlc3RcXFwiIGV2ZW50IGZvciAlcyBsaXN0ZW5lcihzKS4uLlwiLCB0aGlzLmVtaXR0ZXIubGlzdGVuZXJDb3VudChcInJlcXVlc3RcIikpO1xuXHRcdFx0XHQvKipcblx0XHRcdFx0KiBAbm90ZSBHaXZlIHRoZSBjb25zdW1lciBhIGNoYW5jZSB0byBhYm9ydCB0aGUgcmVxdWVzdCBiZWZvcmVcblx0XHRcdFx0KiBpdCBpcyBkaXNwYXRjaGVkLiBGZXRjaCBxdWV1ZXMgdGhlIHJlcXVlc3QgcHJvY2Vzc2luZyBhcyBhXG5cdFx0XHRcdCogdGFzaywgc28gYSBzaWduYWwgYWJvcnRlZCBzeW5jaHJvbm91c2x5IGFmdGVyIGBmZXRjaCgpYCBtdXN0XG5cdFx0XHRcdCogcHJldmVudCB0aGUgcmVxdWVzdCBmcm9tIGV2ZXIgcmVhY2hpbmcgdGhlIFwicmVxdWVzdFwiIGxpc3RlbmVycy5cblx0XHRcdFx0KiBXaXRob3V0IHRoaXMsIHRoZSBmaXJzdCBsaXN0ZW5lciBpcyBpbnZva2VkIHN5bmNocm9ub3VzbHlcblx0XHRcdFx0KiB3aXRoaW4gdGhlIGBmZXRjaCgpYCBjYWxsIGl0c2VsZi5cblx0XHRcdFx0Ki9cblx0XHRcdFx0YXdhaXQgUHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0XHRcdGF3YWl0IGhhbmRsZVJlcXVlc3Qoe1xuXHRcdFx0XHRcdGluaXRpYXRvcjogcmVxdWVzdCxcblx0XHRcdFx0XHRyZXF1ZXN0LFxuXHRcdFx0XHRcdHJlcXVlc3RJZCxcblx0XHRcdFx0XHRlbWl0dGVyOiB0aGlzLmVtaXR0ZXIsXG5cdFx0XHRcdFx0Y29udHJvbGxlcixcblx0XHRcdFx0XHRsb2dnZXJcblx0XHRcdFx0fSk7XG5cdFx0XHRcdHJldHVybiByZXNwb25zZVByb21pc2UucHJvbWlzZTtcblx0XHRcdH07XG5cdFx0fSkpO1xuXHRcdGxvZ2dlci52ZXJib3NlKFwiZ2xvYmFsIGZldGNoIHBhdGNoZWQ6ICVzXCIsIGdsb2JhbFRoaXMuZmV0Y2gubmFtZSk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEZldGNoSW50ZXJjZXB0b3IgYXMgdCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD13ZWItQ0NMRVJTWkYuanMubWFwIiwiaW1wb3J0IHsgaCBhcyBkZXZVdGlscyB9IGZyb20gXCIuLi9fY2h1bmtzL2Nvb2tpZS1zdG9yZS5qc1wiO1xuaW1wb3J0IHsgdCBhcyBSZXF1ZXN0SGFuZGxlciB9IGZyb20gXCIuLi9fY2h1bmtzL3JlcXVlc3QtaGFuZGxlci5qc1wiO1xuaW1wb3J0IHsgdCBhcyBpc09iamVjdCB9IGZyb20gXCIuLi9fY2h1bmtzL2lzLW9iamVjdC5qc1wiO1xuaW1wb3J0IHsgdCBhcyBIdHRwUmVzcG9uc2UgfSBmcm9tIFwiLi4vX2NodW5rcy9odHRwLXJlc3BvbnNlLmpzXCI7XG5pbXBvcnQgeyBpIGFzIFJlc3BvbnNlRXZlbnQsIHIgYXMgSHR0cE5ldHdvcmtGcmFtZSwgcyBhcyBkZWZpbmVOZXR3b3JrLCB0IGFzIEludGVyY2VwdG9yU291cmNlLCB1IGFzIE5ldHdvcmtTb3VyY2UgfSBmcm9tIFwiLi4vX2NodW5rcy9pbnRlcmNlcHRvci1zb3VyY2UuanNcIjtcbmltcG9ydCB7IGlzTm9kZVByb2Nlc3MgfSBmcm9tIFwiaXMtbm9kZS1wcm9jZXNzXCI7XG5pbXBvcnQgeyBpbnZhcmlhbnQgfSBmcm9tIFwib3V0dmFyaWFudFwiO1xuaW1wb3J0IHsgRmV0Y2hSZXF1ZXN0LCBGZXRjaFJlc3BvbnNlIH0gZnJvbSBcIkBtc3dqcy9pbnRlcmNlcHRvcnNcIjtcbmltcG9ydCB7IEVtaXR0ZXIsIFR5cGVkRXZlbnQgfSBmcm9tIFwicmV0dGltZVwiO1xuaW1wb3J0IHsgV2ViU29ja2V0SW50ZXJjZXB0b3IgfSBmcm9tIFwiQG1zd2pzL2ludGVyY2VwdG9ycy9XZWJTb2NrZXRcIjtcbmltcG9ydCB7IHVudGlsIH0gZnJvbSBcInVudGlsLWFzeW5jXCI7XG5pbXBvcnQgeyBYTUxIdHRwUmVxdWVzdEludGVyY2VwdG9yIH0gZnJvbSBcIkBtc3dqcy9pbnRlcmNlcHRvcnMvWE1MSHR0cFJlcXVlc3RcIjtcbmltcG9ydCB7IEZldGNoSW50ZXJjZXB0b3IgfSBmcm9tIFwiQG1zd2pzL2ludGVyY2VwdG9ycy9mZXRjaFwiO1xuLy8jcmVnaW9uIHNyYy9icm93c2VyL3V0aWxzL3N1cHBvcnRzLnRzXG4vKipcbiogQ2hlY2tzIGlmIHRoZSBTZXJ2aWNlIFdvcmtlciBBUEkgaXMgc3VwcHJvdGVkIGFuZCBhdmFpbGFibGVcbiogaW4gdGhlIGN1cnJlbnQgYnJvd3NpbmcgY29udGV4dC5cbiovXG5mdW5jdGlvbiBzdXBwb3J0c1NlcnZpY2VXb3JrZXIoKSB7XG5cdHJldHVybiB0eXBlb2YgbmF2aWdhdG9yICE9PSBcInVuZGVmaW5lZFwiICYmIFwic2VydmljZVdvcmtlclwiIGluIG5hdmlnYXRvciAmJiB0eXBlb2YgbG9jYXRpb24gIT09IFwidW5kZWZpbmVkXCIgJiYgbG9jYXRpb24ucHJvdG9jb2wgIT09IFwiZmlsZTpcIjtcbn1cbi8qKlxuKiBSZXR1cm5zIGEgYm9vbGVhbiBpbmRpY2F0aW5nIHdoZXRoZXIgdGhlIGN1cnJlbnQgYnJvd3NlclxuKiBzdXBwb3J0cyBgUmVhZGFibGVTdHJlYW1gIGFzIGEgYFRyYW5zZmVyYWJsZWAgd2hlbiBwb3N0aW5nXG4qIG1lc3NhZ2VzLlxuKi9cbmZ1bmN0aW9uIHN1cHBvcnRzUmVhZGFibGVTdHJlYW1UcmFuc2ZlcigpIHtcblx0dHJ5IHtcblx0XHRjb25zdCBzdHJlYW0gPSBuZXcgUmVhZGFibGVTdHJlYW0oeyBzdGFydDogKGNvbnRyb2xsZXIpID0+IGNvbnRyb2xsZXIuY2xvc2UoKSB9KTtcblx0XHRuZXcgTWVzc2FnZUNoYW5uZWwoKS5wb3J0MS5wb3N0TWVzc2FnZShzdHJlYW0sIFtzdHJlYW1dKTtcblx0XHRyZXR1cm4gdHJ1ZTtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY29yZS91dGlscy90by1yZXNwb25zZS1pbml0LnRzXG5mdW5jdGlvbiB0b1Jlc3BvbnNlSW5pdChyZXNwb25zZSkge1xuXHRyZXR1cm4ge1xuXHRcdHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLFxuXHRcdHN0YXR1c1RleHQ6IHJlc3BvbnNlLnN0YXR1c1RleHQsXG5cdFx0aGVhZGVyczogT2JqZWN0LmZyb21FbnRyaWVzKHJlc3BvbnNlLmhlYWRlcnMuZW50cmllcygpKVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2Jyb3dzZXIvdXRpbHMvZ2V0LWFic29sdXRlLXdvcmtlci11cmwudHNcbi8qKlxuKiBSZXR1cm5zIGFuIGFic29sdXRlIFNlcnZpY2UgV29ya2VyIFVSTCBiYXNlZCBvbiB0aGUgZ2l2ZW5cbiogcmVsYXRpdmUgVVJMIChrbm93biBkdXJpbmcgdGhlIHJlZ2lzdHJhdGlvbikuXG4qL1xuZnVuY3Rpb24gZ2V0QWJzb2x1dGVXb3JrZXJVcmwod29ya2VyVXJsKSB7XG5cdHJldHVybiBuZXcgVVJMKHdvcmtlclVybCwgbG9jYXRpb24uaHJlZikuaHJlZjtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9icm93c2VyL3V0aWxzL2dldC13b3JrZXItYnktcmVnaXN0cmF0aW9uLnRzXG4vKipcbiogQXR0ZW1wdHMgdG8gcmVzb2x2ZSBhIFNlcnZpY2UgV29ya2VyIGluc3RhbmNlIGZyb20gYSBnaXZlbiByZWdpc3RyYXRpb24sXG4qIHJlZ2FyZGxlc3Mgb2YgaXRzIHN0YXRlIChhY3RpdmUsIGluc3RhbGxpbmcsIHdhaXRpbmcpLlxuKi9cbmZ1bmN0aW9uIGdldFdvcmtlckJ5UmVnaXN0cmF0aW9uKHJlZ2lzdHJhdGlvbiwgYWJzb2x1dGVXb3JrZXJVcmwsIGZpbmRXb3JrZXIpIHtcblx0cmV0dXJuIFtcblx0XHRyZWdpc3RyYXRpb24uYWN0aXZlLFxuXHRcdHJlZ2lzdHJhdGlvbi5pbnN0YWxsaW5nLFxuXHRcdHJlZ2lzdHJhdGlvbi53YWl0aW5nXG5cdF0uZmlsdGVyKChzdGF0ZSkgPT4ge1xuXHRcdHJldHVybiBzdGF0ZSAhPSBudWxsO1xuXHR9KS5maW5kKCh3b3JrZXIpID0+IHtcblx0XHRyZXR1cm4gZmluZFdvcmtlcih3b3JrZXIuc2NyaXB0VVJMLCBhYnNvbHV0ZVdvcmtlclVybCk7XG5cdH0pIHx8IG51bGw7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYnJvd3Nlci91dGlscy9nZXQtd29ya2VyLWluc3RhbmNlLnRzXG4vKipcbiogUmV0dXJucyBhbiBhY3RpdmUgU2VydmljZSBXb3JrZXIgaW5zdGFuY2UuXG4qIFdoZW4gbm90IGZvdW5kLCByZWdpc3RlcnMgYSBuZXcgU2VydmljZSBXb3JrZXIuXG4qL1xuY29uc3QgZ2V0V29ya2VySW5zdGFuY2UgPSBhc3luYyAodXJsLCBvcHRpb25zID0ge30sIGZpbmRXb3JrZXIpID0+IHtcblx0Y29uc3QgYWJzb2x1dGVXb3JrZXJVcmwgPSBnZXRBYnNvbHV0ZVdvcmtlclVybCh1cmwpO1xuXHRjb25zdCBtb2NrUmVnaXN0cmF0aW9ucyA9IGF3YWl0IG5hdmlnYXRvci5zZXJ2aWNlV29ya2VyLmdldFJlZ2lzdHJhdGlvbnMoKS50aGVuKChyZWdpc3RyYXRpb25zKSA9PiByZWdpc3RyYXRpb25zLmZpbHRlcigocmVnaXN0cmF0aW9uKSA9PiBnZXRXb3JrZXJCeVJlZ2lzdHJhdGlvbihyZWdpc3RyYXRpb24sIGFic29sdXRlV29ya2VyVXJsLCBmaW5kV29ya2VyKSkpO1xuXHRpZiAoIW5hdmlnYXRvci5zZXJ2aWNlV29ya2VyLmNvbnRyb2xsZXIgJiYgbW9ja1JlZ2lzdHJhdGlvbnMubGVuZ3RoID4gMCkgbG9jYXRpb24ucmVsb2FkKCk7XG5cdGNvbnN0IFtleGlzdGluZ1JlZ2lzdHJhdGlvbl0gPSBtb2NrUmVnaXN0cmF0aW9ucztcblx0aWYgKGV4aXN0aW5nUmVnaXN0cmF0aW9uKSB7XG5cdFx0ZXhpc3RpbmdSZWdpc3RyYXRpb24udXBkYXRlKCk7XG5cdFx0cmV0dXJuIFtnZXRXb3JrZXJCeVJlZ2lzdHJhdGlvbihleGlzdGluZ1JlZ2lzdHJhdGlvbiwgYWJzb2x1dGVXb3JrZXJVcmwsIGZpbmRXb3JrZXIpLCBleGlzdGluZ1JlZ2lzdHJhdGlvbl07XG5cdH1cblx0Y29uc3QgW3JlZ2lzdHJhdGlvbkVycm9yLCByZWdpc3RyYXRpb25SZXN1bHRdID0gYXdhaXQgdW50aWwoYXN5bmMgKCkgPT4ge1xuXHRcdGNvbnN0IHJlZ2lzdHJhdGlvbiA9IGF3YWl0IG5hdmlnYXRvci5zZXJ2aWNlV29ya2VyLnJlZ2lzdGVyKHVybCwgb3B0aW9ucyk7XG5cdFx0cmV0dXJuIFtnZXRXb3JrZXJCeVJlZ2lzdHJhdGlvbihyZWdpc3RyYXRpb24sIGFic29sdXRlV29ya2VyVXJsLCBmaW5kV29ya2VyKSwgcmVnaXN0cmF0aW9uXTtcblx0fSk7XG5cdGlmIChyZWdpc3RyYXRpb25FcnJvcikge1xuXHRcdGlmIChyZWdpc3RyYXRpb25FcnJvci5tZXNzYWdlLmluY2x1ZGVzKFwiKDQwNClcIikpIHtcblx0XHRcdGNvbnN0IHNjb3BlVXJsID0gbmV3IFVSTChvcHRpb25zPy5zY29wZSB8fCBcIi9cIiwgbG9jYXRpb24uaHJlZik7XG5cdFx0XHR0aHJvdyBuZXcgRXJyb3IoZGV2VXRpbHMuZm9ybWF0TWVzc2FnZShgXFxcbkZhaWxlZCB0byByZWdpc3RlciBhIFNlcnZpY2UgV29ya2VyIGZvciBzY29wZSAoJyR7c2NvcGVVcmwuaHJlZn0nKSB3aXRoIHNjcmlwdCAoJyR7YWJzb2x1dGVXb3JrZXJVcmx9Jyk6IFNlcnZpY2UgV29ya2VyIHNjcmlwdCBkb2VzIG5vdCBleGlzdCBhdCB0aGUgZ2l2ZW4gcGF0aC5cblxuRGlkIHlvdSBmb3JnZXQgdG8gcnVuIFwibnB4IG1zdyBpbml0IDxQVUJMSUNfRElSPlwiP1xuXG5MZWFybiBtb3JlIGFib3V0IGNyZWF0aW5nIHRoZSBTZXJ2aWNlIFdvcmtlciBzY3JpcHQ6IGh0dHBzOi8vbXN3anMuaW8vZG9jcy9jbGkvaW5pdGApKTtcblx0XHR9XG5cdFx0dGhyb3cgbmV3IEVycm9yKGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoXCJGYWlsZWQgdG8gcmVnaXN0ZXIgdGhlIFNlcnZpY2UgV29ya2VyOlxcblxcbiVzXCIsIHJlZ2lzdHJhdGlvbkVycm9yLm1lc3NhZ2UpKTtcblx0fVxuXHRyZXR1cm4gcmVnaXN0cmF0aW9uUmVzdWx0O1xufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9icm93c2VyL3V0aWxzL3dvcmtlci1jaGFubmVsLnRzXG5jb25zdCBTVVBQT1JUU19TRVJWSUNFX1dPUktFUiA9IHN1cHBvcnRzU2VydmljZVdvcmtlcigpO1xudmFyIFdvcmtlckV2ZW50ID0gY2xhc3MgZXh0ZW5kcyBUeXBlZEV2ZW50IHtcblx0I3dvcmtlckV2ZW50O1xuXHRjb25zdHJ1Y3Rvcih3b3JrZXJFdmVudCkge1xuXHRcdGNvbnN0IHR5cGUgPSB3b3JrZXJFdmVudC5kYXRhLnR5cGU7XG5cdFx0Y29uc3QgZGF0YSA9IHdvcmtlckV2ZW50LmRhdGEucGF5bG9hZDtcblx0XHQvKipcblx0XHQqIEBub3RlIFRoaXMgaXMgdGhlIG9ubHkgcGxhY2Ugd2UncmUgbWFwcGluZyB7IHR5cGUsIHBheWxvYWQgfVxuXHRcdCogbWVzc2FnZSBzdHJ1Y3R1cmUgb2YgdGhlIHdvcmtlci4gVGhlIGNsaWVudCByZWZlcmVuY2VzIHRoZVxuXHRcdCogcGF5bG9hZCB2aWEgYGV2ZW50LmRhdGFgLlxuXHRcdCovXG5cdFx0c3VwZXIodHlwZSwgeyBkYXRhIH0pO1xuXHRcdHRoaXMuI3dvcmtlckV2ZW50ID0gd29ya2VyRXZlbnQ7XG5cdH1cblx0Z2V0IHBvcnRzKCkge1xuXHRcdHJldHVybiB0aGlzLiN3b3JrZXJFdmVudC5wb3J0cztcblx0fVxuXHQvKipcblx0KiBSZXBseSBkaXJlY3RseSB0byB0aGlzIGV2ZW50IHVzaW5nIGl0cyBgTWVzc2FnZVBvcnRgLlxuXHQqL1xuXHRwb3N0TWVzc2FnZSh0eXBlLCAuLi5yZXN0KSB7XG5cdFx0dGhpcy4jd29ya2VyRXZlbnQucG9ydHNbMF0ucG9zdE1lc3NhZ2Uoe1xuXHRcdFx0dHlwZSxcblx0XHRcdGRhdGE6IHJlc3RbMF1cblx0XHR9LCB7IHRyYW5zZmVyOiByZXN0WzFdIH0pO1xuXHR9XG59O1xudmFyIFdvcmtlckNoYW5uZWwgPSBjbGFzcyBleHRlbmRzIEVtaXR0ZXIge1xuXHQjZ2V0V29ya2VyO1xuXHQjY29udHJvbGxlcjtcblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHN1cGVyKCk7XG5cdFx0aW52YXJpYW50KFNVUFBPUlRTX1NFUlZJQ0VfV09SS0VSLCBcIkZhaWxlZCB0byBvcGVuIGEgV29ya2VyQ2hhbm5lbDogU2VydmljZSBXb3JrZXIgaXMgbm90IHN1cHBvcnRlZCBpbiB0aGlzIGVudmlyb25tZW50LlwiKTtcblx0XHR0aGlzLiNnZXRXb3JrZXIgPSBvcHRpb25zLmdldFdvcmtlcjtcblx0XHR0aGlzLiNjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuXHRcdG5hdmlnYXRvci5zZXJ2aWNlV29ya2VyLmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIGFzeW5jIChldmVudCkgPT4ge1xuXHRcdFx0Y29uc3Qgd29ya2VyID0gYXdhaXQgdGhpcy4jZ2V0V29ya2VyKCk7XG5cdFx0XHRpZiAoZXZlbnQuc291cmNlICE9IG51bGwgJiYgZXZlbnQuc291cmNlICE9PSB3b3JrZXIpIHJldHVybjtcblx0XHRcdGlmIChldmVudC5kYXRhICYmIGlzT2JqZWN0KGV2ZW50LmRhdGEpICYmIFwidHlwZVwiIGluIGV2ZW50LmRhdGEpIHRoaXMuZW1pdChuZXcgV29ya2VyRXZlbnQoZXZlbnQpKTtcblx0XHR9LCB7IHNpZ25hbDogdGhpcy4jY29udHJvbGxlci5zaWduYWwgfSk7XG5cdH1cblx0LyoqXG5cdCogU2VuZCBkYXRhIHRvIHRoZSBTZXJ2aWNlIFdvcmtlciBjb250cm9sbGluZyB0aGlzIGNsaWVudC5cblx0KiBUaGlzIHRyaWdnZXJzIHRoZSBgbWVzc2FnZWAgZXZlbnQgbGlzdGVuZXIgb24gU2VydmljZVdvcmtlckdsb2JhbFNjb3BlLlxuXHQqL1xuXHRwb3N0TWVzc2FnZSh0eXBlKSB7XG5cdFx0aW52YXJpYW50KFNVUFBPUlRTX1NFUlZJQ0VfV09SS0VSLCBcIkZhaWxlZCB0byBwb3N0IG1lc3NhZ2Ugb24gYSBXb3JrZXJDaGFubmVsOiB0aGUgU2VydmljZSBXb3JrZXIgQVBJIGlzIHVuYXZhaWxhYmxlIGluIHRoaXMgZW52aXJvbm1lbnQuIFRoaXMgaXMgbGlrZWx5IGFuIGlzc3VlIHdpdGggTVNXLiBQbGVhc2UgcmVwb3J0IGl0IG9uIEdpdEh1YjogaHR0cHM6Ly9naXRodWIuY29tL21zd2pzL21zdy9pc3N1ZXNcIik7XG5cdFx0dGhpcy4jZ2V0V29ya2VyKCkudGhlbigod29ya2VyKSA9PiB7XG5cdFx0XHR3b3JrZXIucG9zdE1lc3NhZ2UodHlwZSk7XG5cdFx0fSk7XG5cdH1cblx0LyoqXG5cdCogVGVybWluYWwgdGVhcmRvd24uIFJlbW92ZXMgdGhlIGBuYXZpZ2F0b3Iuc2VydmljZVdvcmtlcmAgbWVzc2FnZSBsaXN0ZW5lclxuXHQqIGFuZCBhbGwgZW1pdHRlciBzdWJzY3JpcHRpb25zLiBUaGUgY2hhbm5lbCBpcyBub3QgdXNhYmxlIGFmdGVyd2FyZHMuXG5cdCovXG5cdHRlcm1pbmF0ZSgpIHtcblx0XHR0aGlzLiNjb250cm9sbGVyLmFib3J0KCk7XG5cdFx0dGhpcy5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9icm93c2VyL3V0aWxzL2Rlc2VyaWFsaXplLXJlcXVlc3QudHNcbi8qKlxuKiBDb252ZXJ0cyBhIGdpdmVuIHJlcXVlc3QgcmVjZWl2ZWQgZnJvbSB0aGUgU2VydmljZSBXb3JrZXJcbiogaW50byBhIEZldGNoIGBSZXF1ZXN0YCBpbnN0YW5jZS5cbiovXG5mdW5jdGlvbiBkZXNlcmlhbGl6ZVJlcXVlc3Qoc2VyaWFsaXplZFJlcXVlc3QpIHtcblx0cmV0dXJuIG5ldyBGZXRjaFJlcXVlc3Qoc2VyaWFsaXplZFJlcXVlc3QudXJsLCB7IC4uLnNlcmlhbGl6ZWRSZXF1ZXN0IH0pO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2Jyb3dzZXIvdXRpbHMvdmFsaWRhdGUtd29ya2VyLXNjb3BlLnRzXG4vKipcbiogUHJpbnQgYSB3YXJuaW5nIGlmIHRoZSBnaXZlbiBTZXJ2aWNlIFdvcmtlciByZWdpc3RyYXRpb24gaGFzIGEgc2NvcGVcbiogb3V0c2lkZSBvZiB0aGUgY3VycmVudCBwYWdlJ3MgbG9jYXRpb24uIFRoYXQgaXMgdG8gaGVscCB3aXRoIGRlYnVnZ2luZ1xuKiBpc3N1ZXMgY2F1c2VkIGJ5IHRoZSBpbmNvcnJlY3RseSByZWdpc3RlcmVkIFNlcnZpY2UgV29ya2VyLlxuKi9cbmZ1bmN0aW9uIHZhbGlkYXRlV29ya2VyU2NvcGUocmVnaXN0cmF0aW9uKSB7XG5cdGlmICghbG9jYXRpb24uaHJlZi5zdGFydHNXaXRoKHJlZ2lzdHJhdGlvbi5zY29wZSkpIGRldlV0aWxzLndhcm4oYENhbm5vdCBpbnRlcmNlcHQgcmVxdWVzdHMgb24gdGhpcyBwYWdlIGJlY2F1c2UgaXQncyBvdXRzaWRlIG9mIHRoZSB3b3JrZXIncyBzY29wZSAoXCIke3JlZ2lzdHJhdGlvbi5zY29wZX1cIikuIElmIHlvdSB3aXNoIHRvIG1vY2sgQVBJIHJlcXVlc3RzIG9uIHRoaXMgcGFnZSwgeW91IG11c3QgcmVzb2x2ZSB0aGlzIHNjb3BlIGlzc3VlLlxuXG4tIChSZWNvbW1lbmRlZCkgUmVnaXN0ZXIgdGhlIHdvcmtlciBhdCB0aGUgcm9vdCBsZXZlbCAoXCIvXCIpIG9mIHlvdXIgYXBwbGljYXRpb24uXG4tIFNldCB0aGUgXCJTZXJ2aWNlLVdvcmtlci1BbGxvd2VkXCIgcmVzcG9uc2UgaGVhZGVyIHRvIGFsbG93IG91dC1vZi1zY29wZSB3b3JrZXJzLmApO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2Jyb3dzZXIvdXRpbHMvc2hvdWxkLWludmFsaWRhdGUtd29ya2VyLnRzXG5mdW5jdGlvbiBzaG91bGRJbnZhbGlkYXRlV29ya2VyKHByZXZPcHRpb25zLCBuZXh0T3B0aW9ucykge1xuXHRyZXR1cm4gcHJldk9wdGlvbnMuZmluZFdvcmtlciAhPT0gbmV4dE9wdGlvbnMuZmluZFdvcmtlciB8fCBwcmV2T3B0aW9ucy5zZXJ2aWNlV29ya2VyLnVybCAhPT0gbmV4dE9wdGlvbnMuc2VydmljZVdvcmtlci51cmwgfHwgSlNPTi5zdHJpbmdpZnkocHJldk9wdGlvbnMuc2VydmljZVdvcmtlci5vcHRpb25zKSAhPT0gSlNPTi5zdHJpbmdpZnkobmV4dE9wdGlvbnMuc2VydmljZVdvcmtlci5vcHRpb25zKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9icm93c2VyL3NvdXJjZXMvc2VydmljZS13b3JrZXItc291cmNlLnRzXG52YXIgU2VydmljZVdvcmtlclNvdXJjZSA9IGNsYXNzIFNlcnZpY2VXb3JrZXJTb3VyY2UgZXh0ZW5kcyBOZXR3b3JrU291cmNlIHtcblx0c3RhdGljICNjdXJyZW50O1xuXHQvKipcblx0KiBDcmVhdGUgYSBuZXcgU2VydmljZSBXb3JrZXIgc291cmNlIG9yIHJldXNlIGFuIGV4aXN0aW5nIG9uZS5cblx0KiBUaGVzZSBzb3VyY2VzIGFjdCBhcyBhIHNpbmdsZXRvbiBhbmQgb25seSBnZXQgcmVjcmVhdGVkIGlmIHRoZSBvcHRpb25zIGNoYW5nZS5cblx0Ki9cblx0c3RhdGljIGFzeW5jIGZyb20ob3B0aW9ucykge1xuXHRcdGlmIChTZXJ2aWNlV29ya2VyU291cmNlLiNjdXJyZW50ID09IG51bGwpIFNlcnZpY2VXb3JrZXJTb3VyY2UuI2N1cnJlbnQgPSBuZXcgU2VydmljZVdvcmtlclNvdXJjZShvcHRpb25zKTtcblx0XHRlbHNlIGlmIChzaG91bGRJbnZhbGlkYXRlV29ya2VyKFNlcnZpY2VXb3JrZXJTb3VyY2UuI2N1cnJlbnQuI29wdGlvbnMsIG9wdGlvbnMpKSB7XG5cdFx0XHRhd2FpdCBTZXJ2aWNlV29ya2VyU291cmNlLiNjdXJyZW50LnRlcm1pbmF0ZSgpO1xuXHRcdFx0U2VydmljZVdvcmtlclNvdXJjZS4jY3VycmVudCA9IG5ldyBTZXJ2aWNlV29ya2VyU291cmNlKG9wdGlvbnMpO1xuXHRcdH1cblx0XHRyZXR1cm4gU2VydmljZVdvcmtlclNvdXJjZS4jY3VycmVudDtcblx0fVxuXHQjb3B0aW9ucztcblx0LyoqXG5cdCogVGhlIHJlc29sdmVkIGNvbnRleHQgb2YgdGhlIG5ldHdvcmsgdGhpcyBzb3VyY2Ugd2FzIGxhc3QgZW5hYmxlZCB3aXRoLlxuXHQqL1xuXHQjY29udGV4dDtcblx0LyoqXG5cdCogQG5vdGUgV2UgY2Fubm90IHVzZSBgV2Vha01hcGAgaGVyZSBhcyByZXF1ZXN0L3Jlc3BvbnNlXG5cdCogaWRlbnRpdHkgY2Fubm90IGJlIHByZXNlcnZlZCB0aHJvdWdoIHRoZSBjbGllbnQtd29ya2VyIGNoYW5uZWwuXG5cdCovXG5cdCNmcmFtZXM7XG5cdCNjaGFubmVsO1xuXHQjbGlzdGVuZXJDb250cm9sbGVyO1xuXHQjY2xpZW50UHJvbWlzZTtcblx0I2tlZXBBbGl2ZUludGVydmFsO1xuXHR3b3JrZXJQcm9taXNlO1xuXHQjd29ya2VyUmVzb2x2ZXJzO1xuXHQjd29ya2VyU3RhdGU7XG5cdGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcblx0XHRzdXBlcigpO1xuXHRcdGludmFyaWFudChzdXBwb3J0c1NlcnZpY2VXb3JrZXIoKSwgXCJGYWlsZWQgdG8gdXNlIFNlcnZpY2UgV29ya2VyIGFzIHRoZSBuZXR3b3JrIHNvdXJjZTogdGhlIFNlcnZpY2UgV29ya2VyIEFQSSBpcyBub3Qgc3VwcG9ydGVkIGluIHRoaXMgZW52aXJvbm1lbnRcIik7XG5cdFx0dGhpcy4jb3B0aW9ucyA9IG9wdGlvbnM7XG5cdFx0dGhpcy4jZnJhbWVzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHR0aGlzLiN3b3JrZXJSZXNvbHZlcnMgPSBQcm9taXNlLndpdGhSZXNvbHZlcnMoKTtcblx0XHR0aGlzLndvcmtlclByb21pc2UgPSB0aGlzLiN3b3JrZXJSZXNvbHZlcnMucHJvbWlzZTtcblx0XHR0aGlzLiN3b3JrZXJTdGF0ZSA9IFwicGVuZGluZ1wiO1xuXHRcdHRoaXMuI2NoYW5uZWwgPSBuZXcgV29ya2VyQ2hhbm5lbCh7IGdldFdvcmtlcjogKCkgPT4gdGhpcy53b3JrZXJQcm9taXNlLnRoZW4oKFt3b3JrZXJdKSA9PiB3b3JrZXIpIH0pO1xuXHR9XG5cdGFzeW5jIGVuYWJsZShjb250ZXh0KSB7XG5cdFx0dGhpcy4jY29udGV4dCA9IGNvbnRleHQ7XG5cdFx0dGhpcy4jY2hhbm5lbC5yZW1vdmVBbGxMaXN0ZW5lcnMoKTtcblx0XHR0aGlzLiNmcmFtZXMuY2xlYXIoKTtcblx0XHR0aGlzLiNsaXN0ZW5lckNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cdFx0Y29uc3QgW3dvcmtlciwgcmVnaXN0cmF0aW9uXSA9IGF3YWl0IHRoaXMuI3N0YXJ0V29ya2VyKCk7XG5cdFx0aWYgKHdvcmtlci5zdGF0ZSAhPT0gXCJhY3RpdmF0ZWRcIikge1xuXHRcdFx0Y29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0XHRcdGNvbnN0IGFjdGl2YXRpb25Qcm9taXNlID0gUHJvbWlzZS53aXRoUmVzb2x2ZXJzKCk7XG5cdFx0XHRhY3RpdmF0aW9uUHJvbWlzZS5wcm9taXNlLnRoZW4oKCkgPT4gY29udHJvbGxlci5hYm9ydCgpKTtcblx0XHRcdHdvcmtlci5hZGRFdmVudExpc3RlbmVyKFwic3RhdGVjaGFuZ2VcIiwgKCkgPT4ge1xuXHRcdFx0XHRpZiAod29ya2VyLnN0YXRlID09PSBcImFjdGl2YXRlZFwiKSBhY3RpdmF0aW9uUHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0XHR9LCB7IHNpZ25hbDogY29udHJvbGxlci5zaWduYWwgfSk7XG5cdFx0XHRhd2FpdCBhY3RpdmF0aW9uUHJvbWlzZS5wcm9taXNlO1xuXHRcdH1cblx0XHR0aGlzLiNjaGFubmVsLnBvc3RNZXNzYWdlKFwiTU9DS19BQ1RJVkFURVwiKTtcblx0XHRjb25zdCBjbGllbnRDb25maXJtYXRpb25Qcm9taXNlID0gUHJvbWlzZS53aXRoUmVzb2x2ZXJzKCk7XG5cdFx0dGhpcy4jY2xpZW50UHJvbWlzZSA9IGNsaWVudENvbmZpcm1hdGlvblByb21pc2UucHJvbWlzZTtcblx0XHR0aGlzLiNjaGFubmVsLm9uY2UoXCJNT0NLSU5HX0VOQUJMRURcIiwgKGV2ZW50KSA9PiB7XG5cdFx0XHRjbGllbnRDb25maXJtYXRpb25Qcm9taXNlLnJlc29sdmUoZXZlbnQuZGF0YS5jbGllbnQpO1xuXHRcdH0pO1xuXHRcdGF3YWl0IGNsaWVudENvbmZpcm1hdGlvblByb21pc2UucHJvbWlzZTtcblx0XHRpZiAoIXRoaXMuI2NvbnRleHQ/LnF1aWV0KSB0aGlzLiNwcmludFN0YXJ0TWVzc2FnZSgpO1xuXHRcdHJldHVybiByZWdpc3RyYXRpb247XG5cdH1cblx0YXN5bmMgZGlzYWJsZSgpIHtcblx0XHQvKipcblx0XHQqIEBub3RlIERvIE5PVCBjYWxsIGBzdXBlci5kaXNhYmxlKClgIGJlY2F1c2UgaXQgcmVtb3ZlcyBhbnkgXCJmcmFtZVwiIGxpc3RlbmVyc1xuXHRcdCogZnJvbSB0aGlzIG5ldHdvcmsgc291cmNlLCBlZmZlY3RpdmVseSB0dXJuaW5nIGl0IG9mZi4gVGhlIFNlcnZpY2UgV29ya2VyIHNvdXJjZVxuXHRcdCogaXMgYSBiaXQgc3BlY2lhbCBzaW5jZSBpdCBtaWdodCBwcm9jZXNzIGluLWZsaWdodCByZXF1ZXN0cyB0aGF0IGhhdmUgYmVlbiBwZXJmb3JtZWRcblx0XHQqIGFmdGVyIGl0J3MgYmVlbiBkaXNhYmxlZC5cblx0XHQqL1xuXHRcdHRoaXMuI2xpc3RlbmVyQ29udHJvbGxlcj8uYWJvcnQoKTtcblx0XHR0aGlzLiNsaXN0ZW5lckNvbnRyb2xsZXIgPSB2b2lkIDA7XG5cdFx0Y29uc3QgY2xvc2VkUHJvbWlzZSA9IFByb21pc2Uud2l0aFJlc29sdmVycygpO1xuXHRcdHRoaXMuI2NoYW5uZWwub25jZShcIkNMSUVOVF9DTE9TRURcIiwgKCkgPT4gY2xvc2VkUHJvbWlzZS5yZXNvbHZlKCkpO1xuXHRcdHRoaXMuI2NoYW5uZWwucG9zdE1lc3NhZ2UoXCJDTElFTlRfQ0xPU0VcIik7XG5cdFx0YXdhaXQgY2xvc2VkUHJvbWlzZS5wcm9taXNlO1xuXHRcdC8qKlxuXHRcdCogQG5vdGUgRG8gTk9UIHJlc2V0IGB3b3JrZXJQcm9taXNlYCBoZXJlLiBUaGUgY2hhbm5lbCBtdXN0IGNvbnRpbnVlIHRvXG5cdFx0KiByZXNvbHZlIHRoZSBjdXJyZW50bHkgcmVnaXN0ZXJlZCBTVyBzbyB0aGF0IGFueSBpbi1mbGlnaHQgcmVxdWVzdHMgdGhlXG5cdFx0KiB3b3JrZXIgZm9yd2FyZHMgYWZ0ZXIgYHN0b3AoKWAgY2FuIGJlIGFuc3dlcmVkIHdpdGggYFBBU1NUSFJPVUdIYCBieVxuXHRcdCogYCNoYW5kbGVSZXF1ZXN0YC4gYCNzdGFydFdvcmtlcmAgc3dhcHMgaW4gYSBmcmVzaCBkZWZlcnJlZCBvbiByZS1lbmFibGUuXG5cdFx0Ki9cblx0XHRpZiAoIXRoaXMuI2NvbnRleHQ/LnF1aWV0KSB0aGlzLiNwcmludFN0b3BNZXNzYWdlKCk7XG5cdH1cblx0LyoqXG5cdCogVGVybWluYWwgdGVhcmRvd24uIFVucmVnaXN0ZXJzIHRoZSBTZXJ2aWNlIFdvcmtlciwgdGVhcnMgZG93biB0aGUgY2hhbm5lbCxcblx0KiBhbmQgY2xlYXJzIHRpbWVycy4gQ2FsbGVkIHdoZW4gdGhlIHNpbmdsZXRvbiBpcyBiZWluZyByZXBsYWNlZCB3aXRoIG9uZVxuXHQqIHRoYXQgaGFzIGRpZmZlcmVudCBvcHRpb25zLiBUaGUgaW5zdGFuY2UgaXMgbm90IHVzYWJsZSBhZnRlcndhcmRzLlxuXHQqL1xuXHRhc3luYyB0ZXJtaW5hdGUoKSB7XG5cdFx0aWYgKHRoaXMuI2tlZXBBbGl2ZUludGVydmFsICE9IG51bGwpIHtcblx0XHRcdGNsZWFySW50ZXJ2YWwodGhpcy4ja2VlcEFsaXZlSW50ZXJ2YWwpO1xuXHRcdFx0dGhpcy4ja2VlcEFsaXZlSW50ZXJ2YWwgPSB2b2lkIDA7XG5cdFx0fVxuXHRcdHRoaXMuI2ZyYW1lcy5jbGVhcigpO1xuXHRcdHRoaXMuI2NoYW5uZWwudGVybWluYXRlKCk7XG5cdFx0dGhpcy4jbGlzdGVuZXJDb250cm9sbGVyPy5hYm9ydCgpO1xuXHRcdHRoaXMuI2xpc3RlbmVyQ29udHJvbGxlciA9IHZvaWQgMDtcblx0XHRpZiAodGhpcy4jd29ya2VyU3RhdGUgPT09IFwiZnVsZmlsbGVkXCIpIHtcblx0XHRcdGNvbnN0IFssIHJlZ2lzdHJhdGlvbl0gPSBhd2FpdCB0aGlzLndvcmtlclByb21pc2U7XG5cdFx0XHRhd2FpdCByZWdpc3RyYXRpb24udW5yZWdpc3RlcigpO1xuXHRcdH1cblx0XHRpZiAoU2VydmljZVdvcmtlclNvdXJjZS4jY3VycmVudCA9PT0gdGhpcykgU2VydmljZVdvcmtlclNvdXJjZS4jY3VycmVudCA9IHZvaWQgMDtcblx0fVxuXHRhc3luYyAjc3RhcnRXb3JrZXIoKSB7XG5cdFx0aWYgKHRoaXMuI2tlZXBBbGl2ZUludGVydmFsKSBjbGVhckludGVydmFsKHRoaXMuI2tlZXBBbGl2ZUludGVydmFsKTtcblx0XHRjb25zdCB3b3JrZXJVcmwgPSB0aGlzLiNvcHRpb25zLnNlcnZpY2VXb3JrZXIudXJsO1xuXHRcdGNvbnN0IFt3b3JrZXIsIHJlZ2lzdHJhdGlvbl0gPSBhd2FpdCBnZXRXb3JrZXJJbnN0YW5jZSh3b3JrZXJVcmwsIHRoaXMuI29wdGlvbnMuc2VydmljZVdvcmtlci5vcHRpb25zLCB0aGlzLiNvcHRpb25zLmZpbmRXb3JrZXIgfHwgdGhpcy4jZGVmYXVsdEZpbmRXb3JrZXIpO1xuXHRcdGlmICh3b3JrZXIgPT0gbnVsbCkge1xuXHRcdFx0Y29uc3QgbWlzc2luZ1dvcmtlck1lc3NhZ2UgPSB0aGlzLiNvcHRpb25zPy5maW5kV29ya2VyID8gZGV2VXRpbHMuZm9ybWF0TWVzc2FnZShgRmFpbGVkIHRvIGxvY2F0ZSB0aGUgU2VydmljZSBXb3JrZXIgcmVnaXN0cmF0aW9uIHVzaW5nIGEgY3VzdG9tIFwiZmluZFdvcmtlclwiIHByZWRpY2F0ZS5cblxuUGxlYXNlIGVuc3VyZSB0aGF0IHRoZSBjdXN0b20gcHJlZGljYXRlIHByb3Blcmx5IGxvY2F0ZXMgdGhlIFNlcnZpY2UgV29ya2VyIHJlZ2lzdHJhdGlvbiBhdCBcIiVzXCIuXG5Nb3JlIGRldGFpbHM6IGh0dHBzOi8vbXN3anMuaW8vZG9jcy9hcGkvc2V0dXAtd29ya2VyL3N0YXJ0I2ZpbmR3b3JrZXJcbiAgICAgYCwgd29ya2VyVXJsKSA6IGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoYEZhaWxlZCB0byBsb2NhdGUgdGhlIFNlcnZpY2UgV29ya2VyIHJlZ2lzdHJhdGlvbi5cblxuVGhpcyBtb3N0IGxpa2VseSBtZWFucyB0aGF0IHRoZSB3b3JrZXIgc2NyaXB0IFVSTCBcIiVzXCIgY2Fubm90IHJlc29sdmUgYWdhaW5zdCB0aGUgYWN0dWFsIHB1YmxpYyBob3N0bmFtZSAoJXMpLiBUaGlzIG1heSBoYXBwZW4gaWYgeW91ciBhcHBsaWNhdGlvbiBydW5zIGJlaGluZCBhIHByb3h5LCBvciBoYXMgYSBkeW5hbWljIGhvc3RuYW1lLlxuXG5QbGVhc2UgY29uc2lkZXIgdXNpbmcgYSBjdXN0b20gXCJzZXJ2aWNlV29ya2VyLnVybFwiIG9wdGlvbiB0byBwb2ludCB0byB0aGUgYWN0dWFsIHdvcmtlciBzY3JpcHQgbG9jYXRpb24sIG9yIGEgY3VzdG9tIFwiZmluZFdvcmtlclwiIG9wdGlvbiB0byByZXNvbHZlIHRoZSBTZXJ2aWNlIFdvcmtlciByZWdpc3RyYXRpb24gbWFudWFsbHkuIE1vcmUgZGV0YWlsczogaHR0cHM6Ly9tc3dqcy5pby9kb2NzL2FwaS9zZXR1cC13b3JrZXIvc3RhcnRgLCB3b3JrZXJVcmwsIGxvY2F0aW9uLmhvc3QpO1xuXHRcdFx0dGhyb3cgbmV3IEVycm9yKG1pc3NpbmdXb3JrZXJNZXNzYWdlKTtcblx0XHR9XG5cdFx0aWYgKHRoaXMuI3dvcmtlclN0YXRlID09PSBcInBlbmRpbmdcIikge1xuXHRcdFx0dGhpcy4jd29ya2VyUmVzb2x2ZXJzLnJlc29sdmUoW3dvcmtlciwgcmVnaXN0cmF0aW9uXSk7XG5cdFx0XHR0aGlzLiN3b3JrZXJTdGF0ZSA9IFwiZnVsZmlsbGVkXCI7XG5cdFx0fSBlbHNlIHtcblx0XHRcdC8qKlxuXHRcdFx0KiBAbm90ZSBSZS1lbmFibGUgYWZ0ZXIgYHN0b3AoKWA6IHRoZSBwcmV2aW91cyBgd29ya2VyUHJvbWlzZWAgaXMgYWxyZWFkeVxuXHRcdFx0KiBmdWxmaWxsZWQgYW5kIGNhbm5vdCBiZSByZXNvbHZlZCBhZ2Fpbi4gU3dhcCBpbiBhIHByZS1yZXNvbHZlZCBvbmUgc29cblx0XHRcdCogYGdldFdvcmtlcigpYCBzZWVzIHRoZSBuZXcgd29ya2VyIGluc3RhbmNlIGltbWVkaWF0ZWx5LlxuXHRcdFx0Ki9cblx0XHRcdHRoaXMuI3dvcmtlclJlc29sdmVycyA9IFByb21pc2Uud2l0aFJlc29sdmVycygpO1xuXHRcdFx0dGhpcy4jd29ya2VyUmVzb2x2ZXJzLnJlc29sdmUoW3dvcmtlciwgcmVnaXN0cmF0aW9uXSk7XG5cdFx0XHR0aGlzLndvcmtlclByb21pc2UgPSB0aGlzLiN3b3JrZXJSZXNvbHZlcnMucHJvbWlzZTtcblx0XHR9XG5cdFx0dGhpcy4jY2hhbm5lbC5vbihcIlJFUVVFU1RcIiwgdGhpcy4jaGFuZGxlUmVxdWVzdC5iaW5kKHRoaXMpKTtcblx0XHR0aGlzLiNjaGFubmVsLm9uKFwiUkVTUE9OU0VcIiwgdGhpcy4jaGFuZGxlUmVzcG9uc2UuYmluZCh0aGlzKSk7XG5cdFx0dGhpcy4jY2hhbm5lbC5vbihcIlJFUVVFU1RfRVJST1JcIiwgdGhpcy4jaGFuZGxlUmVxdWVzdEVycm9yLmJpbmQodGhpcykpO1xuXHRcdHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwicGFnZWhpZGVcIiwgKGV2ZW50KSA9PiB7XG5cdFx0XHRpZiAoZXZlbnQucGVyc2lzdGVkKSByZXR1cm47XG5cdFx0XHRpZiAod29ya2VyLnN0YXRlICE9PSBcInJlZHVuZGFudFwiKSB0aGlzLiNjaGFubmVsLnBvc3RNZXNzYWdlKFwiQ0xJRU5UX0NMT1NFXCIpO1xuXHRcdFx0Y2xlYXJJbnRlcnZhbCh0aGlzLiNrZWVwQWxpdmVJbnRlcnZhbCk7XG5cdFx0XHR3aW5kb3cucG9zdE1lc3NhZ2UoeyB0eXBlOiBcIm1zdy93b3JrZXI6c3RvcFwiIH0pO1xuXHRcdH0sIHsgc2lnbmFsOiB0aGlzLiNsaXN0ZW5lckNvbnRyb2xsZXI/LnNpZ25hbCB9KTtcblx0XHRhd2FpdCB0aGlzLiNjaGVja1dvcmtlckludGVncml0eSgpLmNhdGNoKChlcnJvcikgPT4ge1xuXHRcdFx0ZGV2VXRpbHMuZXJyb3IoXCJFcnJvciB3aGlsZSBjaGVja2luZyB0aGUgd29ya2VyIHNjcmlwdCBpbnRlZ3JpdHkuIFBsZWFzZSByZXBvcnQgdGhpcyBvbiBHaXRIdWIgKGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9tc3cvaXNzdWVzKSBhbmQgaW5jbHVkZSB0aGUgb3JpZ2luYWwgZXJyb3IgYmVsb3cuXCIpO1xuXHRcdFx0Y29uc29sZS5lcnJvcihlcnJvcik7XG5cdFx0fSk7XG5cdFx0dGhpcy4ja2VlcEFsaXZlSW50ZXJ2YWwgPSB3aW5kb3cuc2V0SW50ZXJ2YWwoKCkgPT4ge1xuXHRcdFx0dGhpcy4jY2hhbm5lbC5wb3N0TWVzc2FnZShcIktFRVBBTElWRV9SRVFVRVNUXCIpO1xuXHRcdH0sIDVlMyk7XG5cdFx0aWYgKCF0aGlzLiNjb250ZXh0Py5xdWlldCkgdmFsaWRhdGVXb3JrZXJTY29wZShyZWdpc3RyYXRpb24pO1xuXHRcdHJldHVybiBbd29ya2VyLCByZWdpc3RyYXRpb25dO1xuXHR9XG5cdGFzeW5jICNoYW5kbGVSZXF1ZXN0KGV2ZW50KSB7XG5cdFx0Y29uc3QgcmVxdWVzdCA9IGRlc2VyaWFsaXplUmVxdWVzdChldmVudC5kYXRhKTtcblx0XHRSZXF1ZXN0SGFuZGxlci5jYWNoZS5zZXQocmVxdWVzdCwgcmVxdWVzdC5jbG9uZSgpKTtcblx0XHRjb25zdCBmcmFtZSA9IG5ldyBTZXJ2aWNlV29ya2VySHR0cE5ldHdvcmtGcmFtZSh7XG5cdFx0XHRldmVudCxcblx0XHRcdHJlcXVlc3Rcblx0XHR9KTtcblx0XHR0aGlzLiNmcmFtZXMuc2V0KGV2ZW50LmRhdGEuaWQsIGZyYW1lKTtcblx0XHRhd2FpdCB0aGlzLnF1ZXVlKGZyYW1lKTtcblx0fVxuXHRhc3luYyAjaGFuZGxlUmVzcG9uc2UoZXZlbnQpIHtcblx0XHRjb25zdCB7IHJlcXVlc3QsIHJlc3BvbnNlLCBpc01vY2tlZFJlc3BvbnNlIH0gPSBldmVudC5kYXRhO1xuXHRcdGNvbnN0IGZyYW1lID0gdGhpcy4jZnJhbWVzLmdldChyZXF1ZXN0LmlkKTtcblx0XHQvKipcblx0XHQqIENPUlMgcmVxdWVzdHMgd2l0aCBgbW9kZTogXCJuby1jb3JzXCJgIHJlc3VsdCBpbiBcIm9wYXF1ZVwiIHJlc3BvbnNlcy5cblx0XHQqIFRoYXQga2luZCBvZiByZXNwb25zZXMgY2Fubm90IGJlIG1hbmlwdWxhdGVkIGluIEphdmFTY3JpcHQgZHVlXG5cdFx0KiB0byB0aGUgc2VjdXJpdHkgY29uc2lkZXJhdGlvbnMuXG5cdFx0KiBAc2VlIGh0dHBzOi8vZmV0Y2guc3BlYy53aGF0d2cub3JnLyNjb25jZXB0LWZpbHRlcmVkLXJlc3BvbnNlLW9wYXF1ZVxuXHRcdCogQHNlZSBodHRwczovL2dpdGh1Yi5jb20vbXN3anMvbXN3L2lzc3Vlcy81Mjlcblx0XHQqL1xuXHRcdGlmIChyZXNwb25zZS50eXBlPy5pbmNsdWRlcyhcIm9wYXF1ZVwiKSkge1xuXHRcdFx0dGhpcy4jZnJhbWVzLmRlbGV0ZShyZXF1ZXN0LmlkKTtcblx0XHRcdGZyYW1lPy5ldmVudHMucmVtb3ZlQWxsTGlzdGVuZXJzKCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdHRoaXMuI2ZyYW1lcy5kZWxldGUocmVxdWVzdC5pZCk7XG5cdFx0LyoqXG5cdFx0KiBAbm90ZSBBIHJlcXVlc3QgZnJhbWUgd2lsbCBiZSBtaXNzaW5nIGluIGNhc2Ugb2YgcGFzc3Rocm91Z2ggYWZ0ZXIgdGhlIHdvcmtlciBpcyBzdG9wcGVkLlxuXHRcdCogQ3JlYXRpbmcgYSBmcmFtZSBpcyBjb3N0bHkgc28gaXQncyBiZXR0ZXIgdG8gaGFuZGxlIGl0IGFzIGFuIGVkZ2UgY2FzZSBoZXJlLlxuXHRcdCovXG5cdFx0aWYgKGZyYW1lID09IG51bGwpIHJldHVybjtcblx0XHRjb25zdCBmZXRjaFJlcXVlc3QgPSBkZXNlcmlhbGl6ZVJlcXVlc3QocmVxdWVzdCk7XG5cdFx0Y29uc3QgZmV0Y2hSZXNwb25zZSA9IHJlc3BvbnNlLnN0YXR1cyA9PT0gMCA/IFJlc3BvbnNlLmVycm9yKCkgOiBuZXcgRmV0Y2hSZXNwb25zZShcblx0XHRcdC8qKlxuXHRcdFx0KiBSZXNwb25zZXMgbWF5IGJlIHN0cmVhbXMgaGVyZSwgYnV0IHdoZW4gd2UgY3JlYXRlIGEgcmVzcG9uc2Ugb2JqZWN0XG5cdFx0XHQqIHdpdGggbnVsbC1ib2R5IHN0YXR1cyBjb2RlcywgbGlrZSAyMDQsIDIwNSwgMzA0IFJlc3BvbnNlIHdpbGxcblx0XHRcdCogdGhyb3cgd2hlbiBwYXNzZWQgYSBub24tbnVsbCBib2R5LCBzbyBlbnN1cmUgaXQncyBudWxsIGhlcmVcblx0XHRcdCogZm9yIHRob3NlIGNvZGVzXG5cdFx0XHQqL1xuXHRcdFx0RmV0Y2hSZXNwb25zZS5pc1Jlc3BvbnNlV2l0aEJvZHkocmVzcG9uc2Uuc3RhdHVzKSA/IHJlc3BvbnNlLmJvZHkgOiBudWxsLFxuXHRcdFx0e1xuXHRcdFx0XHQuLi5yZXNwb25zZSxcblx0XHRcdFx0LyoqXG5cdFx0XHRcdCogU2V0IHJlc3BvbnNlIFVSTCBpZiBpdCdzIG5vdCBzZXQgYWxyZWFkeS5cblx0XHRcdFx0KiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9tc3cvaXNzdWVzLzIwMzBcblx0XHRcdFx0KiBAc2VlIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9SZXNwb25zZS91cmxcblx0XHRcdFx0Ki9cblx0XHRcdFx0dXJsOiByZXF1ZXN0LnVybFxuXHRcdFx0fVxuXHRcdCk7XG5cdFx0dHJ5IHtcblx0XHRcdGZyYW1lLmV2ZW50cy5lbWl0KG5ldyBSZXNwb25zZUV2ZW50KGlzTW9ja2VkUmVzcG9uc2UgPyBcInJlc3BvbnNlOm1vY2tlZFwiIDogXCJyZXNwb25zZTpieXBhc3NcIiwge1xuXHRcdFx0XHRyZXF1ZXN0SWQ6IGZyYW1lLmRhdGEuaWQsXG5cdFx0XHRcdHJlcXVlc3Q6IGZldGNoUmVxdWVzdCxcblx0XHRcdFx0cmVzcG9uc2U6IGZldGNoUmVzcG9uc2UsXG5cdFx0XHRcdGlzTW9ja2VkUmVzcG9uc2Vcblx0XHRcdH0pKTtcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0ZnJhbWUuZXZlbnRzLnJlbW92ZUFsbExpc3RlbmVycygpO1xuXHRcdH1cblx0fVxuXHQvKipcblx0KiBAbm90ZSBBIHJlcXVlc3QgY2FuIHNldHRsZSB3aXRob3V0IGV2ZXIgcHJvZHVjaW5nIGEgcmVzcG9uc2Vcblx0KiAoZS5nLiBhIHBhc3N0aHJvdWdoIHJlcXVlc3QgZmFpbGluZyB3aXRoIGEgbmV0d29yayBlcnJvcikuXG5cdCogVGhlIHdvcmtlciBuZXZlciBzZW5kcyB0aGUgXCJSRVNQT05TRVwiIG1lc3NhZ2UgZm9yIHN1Y2ggcmVxdWVzdHMsXG5cdCogc28gdGhlIGZyYW1lIG11c3QgYmUgcmVsZWFzZWQgaGVyZSB0byBwcmV2ZW50IGl0IGZyb20gYmVpbmcgcmV0YWluZWQuXG5cdCogTm8gXCJyZXNwb25zZToqXCIgZXZlbnQgaXMgZW1pdHRlZCwgY29uc2lzdGVudCB3aXRoIHRoZSBOb2RlLmpzIHNvdXJjZS5cblx0KiBAc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tc3dqcy9tc3cvaXNzdWVzLzI3OTJcblx0Ki9cblx0I2hhbmRsZVJlcXVlc3RFcnJvcihldmVudCkge1xuXHRcdGNvbnN0IHsgcmVxdWVzdCB9ID0gZXZlbnQuZGF0YTtcblx0XHRjb25zdCBmcmFtZSA9IHRoaXMuI2ZyYW1lcy5nZXQocmVxdWVzdC5pZCk7XG5cdFx0dGhpcy4jZnJhbWVzLmRlbGV0ZShyZXF1ZXN0LmlkKTtcblx0XHRmcmFtZT8uZXZlbnRzLnJlbW92ZUFsbExpc3RlbmVycygpO1xuXHR9XG5cdCNkZWZhdWx0RmluZFdvcmtlciA9ICh3b3JrZXJVcmwsIG1vY2tTZXJ2aWNlV29ya2VyVXJsKSA9PiB7XG5cdFx0cmV0dXJuIHdvcmtlclVybCA9PT0gbW9ja1NlcnZpY2VXb3JrZXJVcmw7XG5cdH07XG5cdGFzeW5jICNjaGVja1dvcmtlckludGVncml0eSgpIHtcblx0XHRjb25zdCBpbnRlZ3JpdHlDaGVja1Byb21pc2UgPSBQcm9taXNlLndpdGhSZXNvbHZlcnMoKTtcblx0XHR0aGlzLiNjaGFubmVsLnBvc3RNZXNzYWdlKFwiSU5URUdSSVRZX0NIRUNLX1JFUVVFU1RcIik7XG5cdFx0dGhpcy4jY2hhbm5lbC5vbmNlKFwiSU5URUdSSVRZX0NIRUNLX1JFU1BPTlNFXCIsIChldmVudCkgPT4ge1xuXHRcdFx0Y29uc3QgeyBjaGVja3N1bSwgcGFja2FnZVZlcnNpb24gfSA9IGV2ZW50LmRhdGE7XG5cdFx0XHRpZiAoY2hlY2tzdW0gIT09IFwiNWNkNWNmOGI1NGMzYTkwZjgyOTYwY2VkY2Q2Mzc3NzJcIikgZGV2VXRpbHMud2FybihgVGhlIGN1cnJlbnRseSByZWdpc3RlcmVkIFNlcnZpY2UgV29ya2VyIGhhcyBiZWVuIGdlbmVyYXRlZCBieSBhIGRpZmZlcmVudCB2ZXJzaW9uIG9mIE1TVyAoJHtwYWNrYWdlVmVyc2lvbn0pIGFuZCBtYXkgbm90IGJlIGZ1bGx5IGNvbXBhdGlibGUgd2l0aCB0aGUgaW5zdGFsbGVkIHZlcnNpb24uXG5cbkl0J3MgcmVjb21tZW5kZWQgeW91IHVwZGF0ZSB5b3VyIHdvcmtlciBzY3JpcHQgYnkgcnVubmluZyB0aGlzIGNvbW1hbmQ6XG5cbiAgXFx1MjAyMiBucHggbXN3IGluaXQgPFBVQkxJQ19ESVI+XG5cbllvdSBjYW4gYWxzbyBhdXRvbWF0ZSB0aGlzIHByb2Nlc3MgYW5kIG1ha2UgdGhlIHdvcmtlciBzY3JpcHQgdXBkYXRlIGF1dG9tYXRpY2FsbHkgdXBvbiB0aGUgbGlicmFyeSBpbnN0YWxsYXRpb25zLiBSZWFkIG1vcmU6IGh0dHBzOi8vbXN3anMuaW8vZG9jcy9jbGkvaW5pdC5gKTtcblx0XHRcdGludGVncml0eUNoZWNrUHJvbWlzZS5yZXNvbHZlKCk7XG5cdFx0fSk7XG5cdFx0cmV0dXJuIGludGVncml0eUNoZWNrUHJvbWlzZS5wcm9taXNlO1xuXHR9XG5cdGFzeW5jICNwcmludFN0YXJ0TWVzc2FnZSgpIHtcblx0XHRpZiAodGhpcy4jd29ya2VyU3RhdGUgPT09IFwicmVqZWN0ZWRcIikgcmV0dXJuO1xuXHRcdGludmFyaWFudCh0aGlzLiNjbGllbnRQcm9taXNlICE9IG51bGwsIFwiW1NlcnZpY2VXb3JrZXJTb3VyY2VdIEZhaWxlZCB0byBwcmludCBhIHN0YXJ0IG1lc3NhZ2U6IGNsaWVudCBjb25maXJtYXRpb24gbm90IHJlY2VpdmVkXCIpO1xuXHRcdGNvbnN0IGNsaWVudCA9IGF3YWl0IHRoaXMuI2NsaWVudFByb21pc2U7XG5cdFx0Y29uc3QgW3dvcmtlciwgcmVnaXN0cmF0aW9uXSA9IGF3YWl0IHRoaXMud29ya2VyUHJvbWlzZTtcblx0XHRjb25zb2xlLmdyb3VwQ29sbGFwc2VkKGAlYyR7ZGV2VXRpbHMuZm9ybWF0TWVzc2FnZShcIk1vY2tpbmcgZW5hYmxlZC5cIil9YCwgXCJjb2xvcjpvcmFuZ2VyZWQ7Zm9udC13ZWlnaHQ6Ym9sZDtcIik7XG5cdFx0Y29uc29sZS5sb2coXCIlY0RvY3VtZW50YXRpb246ICVjaHR0cHM6Ly9tc3dqcy5pby9kb2NzXCIsIFwiZm9udC13ZWlnaHQ6Ym9sZFwiLCBcImZvbnQtd2VpZ2h0Om5vcm1hbFwiKTtcblx0XHRjb25zb2xlLmxvZyhcIkZvdW5kIGFuIGlzc3VlPyBodHRwczovL2dpdGh1Yi5jb20vbXN3anMvbXN3L2lzc3Vlc1wiKTtcblx0XHRjb25zb2xlLmxvZyhcIldvcmtlciBzY3JpcHQgVVJMOlwiLCB3b3JrZXIuc2NyaXB0VVJMKTtcblx0XHRjb25zb2xlLmxvZyhcIldvcmtlciBzY29wZTpcIiwgcmVnaXN0cmF0aW9uLnNjb3BlKTtcblx0XHRpZiAoY2xpZW50KSBjb25zb2xlLmxvZyhcIkNsaWVudCBJRDogJXMgKCVzKVwiLCBjbGllbnQuaWQsIGNsaWVudC5mcmFtZVR5cGUpO1xuXHRcdGNvbnNvbGUuZ3JvdXBFbmQoKTtcblx0fVxuXHQjcHJpbnRTdG9wTWVzc2FnZSgpIHtcblx0XHRjb25zb2xlLmxvZyhgJWMke2RldlV0aWxzLmZvcm1hdE1lc3NhZ2UoXCJNb2NraW5nIGRpc2FibGVkLlwiKX1gLCBcImNvbG9yOm9yYW5nZXJlZDtmb250LXdlaWdodDpib2xkO1wiKTtcblx0fVxufTtcbnZhciBTZXJ2aWNlV29ya2VySHR0cE5ldHdvcmtGcmFtZSA9IGNsYXNzIGV4dGVuZHMgSHR0cE5ldHdvcmtGcmFtZSB7XG5cdCNldmVudDtcblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHN1cGVyKHsgcmVxdWVzdDogb3B0aW9ucy5yZXF1ZXN0IH0pO1xuXHRcdHRoaXMuI2V2ZW50ID0gb3B0aW9ucy5ldmVudDtcblx0fVxuXHRwYXNzdGhyb3VnaCgpIHtcblx0XHR0aGlzLiNldmVudC5wb3N0TWVzc2FnZShcIlBBU1NUSFJPVUdIXCIsIHsgcmVxdWVzdDogeyBoZWFkZXJzOiBBcnJheS5mcm9tKHRoaXMuZGF0YS5yZXF1ZXN0LmhlYWRlcnMpIH0gfSk7XG5cdH1cblx0cmVzcG9uZFdpdGgocmVzcG9uc2UpIHtcblx0XHRpZiAocmVzcG9uc2UpIHRoaXMuI3Jlc3BvbmRXaXRoKHJlc3BvbnNlKTtcblx0fVxuXHRlcnJvcldpdGgocmVhc29uKSB7XG5cdFx0aWYgKHJlYXNvbiBpbnN0YW5jZW9mIFJlc3BvbnNlKSByZXR1cm4gdGhpcy5yZXNwb25kV2l0aChyZWFzb24pO1xuXHRcdGRldlV0aWxzLndhcm4oYFVuY2F1Z2h0IGV4Y2VwdGlvbiBpbiB0aGUgcmVxdWVzdCBoYW5kbGVyIGZvciBcIiVzICVzXCIuIFRoaXMgZXhjZXB0aW9uIGhhcyBiZWVuIGdyYWNlZnVsbHkgaGFuZGxlZCBhcyBhIDUwMCByZXNwb25zZSwgaG93ZXZlciwgaXQncyBzdHJvbmdseSByZWNvbW1lbmRlZCB0byByZXNvbHZlIHRoaXMgZXJyb3IsIGFzIGl0IGluZGljYXRlcyBhIG1pc3Rha2UgaW4geW91ciBjb2RlLiBJZiB5b3Ugd2lzaCB0byBtb2NrIGFuIGVycm9yIHJlc3BvbnNlLCBwbGVhc2Ugc2VlIHRoaXMgZ3VpZGU6IGh0dHBzOi8vbXN3anMuaW8vZG9jcy9odHRwL21vY2tpbmctcmVzcG9uc2VzL2Vycm9yLXJlc3BvbnNlc2AsIHRoaXMuZGF0YS5yZXF1ZXN0Lm1ldGhvZCwgdGhpcy5kYXRhLnJlcXVlc3QudXJsKTtcblx0XHRjb25zdCBlcnJvciA9IHJlYXNvbiBpbnN0YW5jZW9mIEVycm9yID8gcmVhc29uIDogbmV3IEVycm9yKHJlYXNvbj8udG9TdHJpbmcoKSB8fCBcIlJlcXVlc3QgZmFpbHVyZVwiKTtcblx0XHR0aGlzLnJlc3BvbmRXaXRoKEh0dHBSZXNwb25zZS5qc29uKHtcblx0XHRcdG5hbWU6IGVycm9yLm5hbWUsXG5cdFx0XHRtZXNzYWdlOiBlcnJvci5tZXNzYWdlLFxuXHRcdFx0c3RhY2s6IGVycm9yLnN0YWNrXG5cdFx0fSwge1xuXHRcdFx0c3RhdHVzOiA1MDAsXG5cdFx0XHRzdGF0dXNUZXh0OiBcIlJlcXVlc3QgSGFuZGxlciBFcnJvclwiXG5cdFx0fSkpO1xuXHR9XG5cdGFzeW5jICNyZXNwb25kV2l0aChyZXNwb25zZSkge1xuXHRcdGxldCByZXNwb25zZUJvZHk7XG5cdFx0bGV0IHRyYW5zZmVyO1xuXHRcdGNvbnN0IHJlc3BvbnNlSW5pdCA9IHRvUmVzcG9uc2VJbml0KHJlc3BvbnNlKTtcblx0XHRpZiAoc3VwcG9ydHNSZWFkYWJsZVN0cmVhbVRyYW5zZmVyKCkpIHtcblx0XHRcdHJlc3BvbnNlQm9keSA9IHJlc3BvbnNlLmJvZHk7XG5cdFx0XHR0cmFuc2ZlciA9IHJlc3BvbnNlLmJvZHkgPT0gbnVsbCA/IHZvaWQgMCA6IFtyZXNwb25zZS5ib2R5XTtcblx0XHR9IGVsc2UgcmVzcG9uc2VCb2R5ID0gcmVzcG9uc2UuYm9keSA9PSBudWxsID8gbnVsbCA6IGF3YWl0IHJlc3BvbnNlLmNsb25lKCkuYXJyYXlCdWZmZXIoKTtcblx0XHR0aGlzLiNldmVudC5wb3N0TWVzc2FnZShcIk1PQ0tfUkVTUE9OU0VcIiwge1xuXHRcdFx0Li4ucmVzcG9uc2VJbml0LFxuXHRcdFx0Ym9keTogcmVzcG9uc2VCb2R5XG5cdFx0fSwgdHJhbnNmZXIpO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2Jyb3dzZXIvc291cmNlcy9mYWxsYmFjay1odHRwLXNvdXJjZS50c1xudmFyIEZhbGxiYWNrSHR0cFNvdXJjZSA9IGNsYXNzIGV4dGVuZHMgSW50ZXJjZXB0b3JTb3VyY2Uge1xuXHQvKipcblx0KiBUaGUgcmVzb2x2ZWQgY29udGV4dCBvZiB0aGUgbmV0d29yayB0aGlzIHNvdXJjZSB3YXMgbGFzdCBlbmFibGVkIHdpdGguXG5cdCovXG5cdCNjb250ZXh0O1xuXHRjb25zdHJ1Y3RvcigpIHtcblx0XHRzdXBlcih7IGludGVyY2VwdG9yczogW25ldyBYTUxIdHRwUmVxdWVzdEludGVyY2VwdG9yKCksIG5ldyBGZXRjaEludGVyY2VwdG9yKCldIH0pO1xuXHR9XG5cdGVuYWJsZShjb250ZXh0KSB7XG5cdFx0dGhpcy4jY29udGV4dCA9IGNvbnRleHQ7XG5cdFx0c3VwZXIuZW5hYmxlKCk7XG5cdFx0aWYgKCF0aGlzLiNjb250ZXh0Py5xdWlldCkgdGhpcy4jcHJpbnRTdGFydE1lc3NhZ2UoKTtcblx0fVxuXHRkaXNhYmxlKCkge1xuXHRcdHN1cGVyLmRpc2FibGUoKTtcblx0XHRpZiAoIXRoaXMuI2NvbnRleHQ/LnF1aWV0KSB0aGlzLiNwcmludFN0b3BNZXNzYWdlKCk7XG5cdH1cblx0I3ByaW50U3RhcnRNZXNzYWdlKCkge1xuXHRcdGNvbnNvbGUuZ3JvdXBDb2xsYXBzZWQoYCVjJHtkZXZVdGlscy5mb3JtYXRNZXNzYWdlKFwiTW9ja2luZyBlbmFibGVkIChmYWxsYmFjayBtb2RlKS5cIil9YCwgXCJjb2xvcjpvcmFuZ2VyZWQ7Zm9udC13ZWlnaHQ6Ym9sZDtcIik7XG5cdFx0Y29uc29sZS5sb2coXCIlY0RvY3VtZW50YXRpb246ICVjaHR0cHM6Ly9tc3dqcy5pby9kb2NzXCIsIFwiZm9udC13ZWlnaHQ6Ym9sZFwiLCBcImZvbnQtd2VpZ2h0Om5vcm1hbFwiKTtcblx0XHRjb25zb2xlLmxvZyhcIkZvdW5kIGFuIGlzc3VlPyBodHRwczovL2dpdGh1Yi5jb20vbXN3anMvbXN3L2lzc3Vlc1wiKTtcblx0XHRjb25zb2xlLmdyb3VwRW5kKCk7XG5cdH1cblx0I3ByaW50U3RvcE1lc3NhZ2UoKSB7XG5cdFx0Y29uc29sZS5sb2coYCVjJHtkZXZVdGlscy5mb3JtYXRNZXNzYWdlKFwiTW9ja2luZyBkaXNhYmxlZC5cIil9YCwgXCJjb2xvcjpvcmFuZ2VyZWQ7Zm9udC13ZWlnaHQ6Ym9sZDtcIik7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYnJvd3Nlci9zZXR1cC13b3JrZXIudHNcbmNvbnN0IERFRkFVTFRfV09SS0VSX1VSTCA9IFwiL21vY2tTZXJ2aWNlV29ya2VyLmpzXCI7XG4vKipcbiogU2V0cyB1cCBhIHJlcXVlc3RzIGludGVyY2VwdGlvbiBpbiB0aGUgYnJvd3NlciB3aXRoIHRoZSBnaXZlbiByZXF1ZXN0IGhhbmRsZXJzLlxuKiBAcGFyYW0ge0FycmF5PEFueUhhbmRsZXI+fSBoYW5kbGVycyBMaXN0IG9mIHJlcXVlc3QgaGFuZGxlcnMuXG4qXG4qIEBzZWUge0BsaW5rIGh0dHBzOi8vbXN3anMuaW8vZG9jcy9hcGkvc2V0dXAtd29ya2VyIGBzZXR1cFdvcmtlcigpYCBBUEkgcmVmZXJlbmNlfVxuKi9cbmZ1bmN0aW9uIHNldHVwV29ya2VyKC4uLmhhbmRsZXJzKSB7XG5cdGludmFyaWFudCghaXNOb2RlUHJvY2VzcygpLCBkZXZVdGlscy5mb3JtYXRNZXNzYWdlKFwiRmFpbGVkIHRvIGV4ZWN1dGUgYHNldHVwV29ya2VyYCBpbiBhIG5vbi1icm93c2VyIGVudmlyb25tZW50XCIpKTtcblx0Y29uc3QgbmV0d29yayA9IGRlZmluZU5ldHdvcmsoe1xuXHRcdHNvdXJjZXM6IFtdLFxuXHRcdGhhbmRsZXJzXG5cdH0pO1xuXHRyZXR1cm4ge1xuXHRcdGdldCByZWFkeVN0YXRlKCkge1xuXHRcdFx0cmV0dXJuIG5ldHdvcmsucmVhZHlTdGF0ZTtcblx0XHR9LFxuXHRcdGFzeW5jIHN0YXJ0KG9wdGlvbnMpIHtcblx0XHRcdGludmFyaWFudChuZXR3b3JrLnJlYWR5U3RhdGUgPT09IDAsIGRldlV0aWxzLmZvcm1hdE1lc3NhZ2UoXCJGYWlsZWQgdG8gY2FsbCBcXFwid29ya2VyLnN0YXJ0KClcXFwiOiB0aGUgd29ya2VyIGlzIGFscmVhZHkgc3RhcnRlZC4gUmVtb3ZlIHRoZSByZWR1bmRhbnQgXFxcIndvcmtlci5zdGFydCgpXFxcIiBjYWxsLlwiKSk7XG5cdFx0XHRjb25zdCBodHRwU291cmNlID0gc3VwcG9ydHNTZXJ2aWNlV29ya2VyKCkgPyBhd2FpdCBTZXJ2aWNlV29ya2VyU291cmNlLmZyb20oe1xuXHRcdFx0XHRzZXJ2aWNlV29ya2VyOiB7XG5cdFx0XHRcdFx0dXJsOiBvcHRpb25zPy5zZXJ2aWNlV29ya2VyPy51cmw/LnRvU3RyaW5nKCkgfHwgREVGQVVMVF9XT1JLRVJfVVJMLFxuXHRcdFx0XHRcdG9wdGlvbnM6IG9wdGlvbnM/LnNlcnZpY2VXb3JrZXI/Lm9wdGlvbnNcblx0XHRcdFx0fSxcblx0XHRcdFx0ZmluZFdvcmtlcjogb3B0aW9ucz8uZmluZFdvcmtlclxuXHRcdFx0fSkgOiBuZXcgRmFsbGJhY2tIdHRwU291cmNlKCk7XG5cdFx0XHRuZXR3b3JrLmNvbmZpZ3VyZSh7XG5cdFx0XHRcdHNvdXJjZXM6IFtodHRwU291cmNlLCBuZXcgSW50ZXJjZXB0b3JTb3VyY2UoeyBpbnRlcmNlcHRvcnM6IFtuZXcgV2ViU29ja2V0SW50ZXJjZXB0b3IoKV0gfSldLFxuXHRcdFx0XHRvblVuaGFuZGxlZEZyYW1lOiBvcHRpb25zPy5vblVuaGFuZGxlZEZyYW1lID8/IFwid2FyblwiLFxuXHRcdFx0XHRjb250ZXh0OiB7IHF1aWV0OiBvcHRpb25zPy5xdWlldCB9XG5cdFx0XHR9KTtcblx0XHRcdGF3YWl0IG5ldHdvcmsuZW5hYmxlKCk7XG5cdFx0XHRpZiAoaHR0cFNvdXJjZSBpbnN0YW5jZW9mIFNlcnZpY2VXb3JrZXJTb3VyY2UpIHtcblx0XHRcdFx0Y29uc3QgWywgcmVnaXN0cmF0aW9uXSA9IGF3YWl0IGh0dHBTb3VyY2Uud29ya2VyUHJvbWlzZTtcblx0XHRcdFx0cmV0dXJuIHJlZ2lzdHJhdGlvbjtcblx0XHRcdH1cblx0XHR9LFxuXHRcdGFzeW5jIHN0b3AoKSB7XG5cdFx0XHRhd2FpdCBuZXR3b3JrLmRpc2FibGUoKTtcblx0XHRcdHdpbmRvdy5wb3N0TWVzc2FnZSh7IHR5cGU6IFwibXN3L3dvcmtlcjpzdG9wXCIgfSk7XG5cdFx0fSxcblx0XHRldmVudHM6IG5ldHdvcmsuZXZlbnRzLFxuXHRcdHVzZTogbmV0d29yay51c2UuYmluZChuZXR3b3JrKSxcblx0XHRyZXNldEhhbmRsZXJzOiBuZXR3b3JrLnJlc2V0SGFuZGxlcnMuYmluZChuZXR3b3JrKSxcblx0XHRyZXN0b3JlSGFuZGxlcnM6IG5ldHdvcmsucmVzdG9yZUhhbmRsZXJzLmJpbmQobmV0d29yayksXG5cdFx0bGlzdEhhbmRsZXJzOiBuZXR3b3JrLmxpc3RIYW5kbGVycy5iaW5kKG5ldHdvcmspXG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYnJvd3Nlci9kZWZhdWx0LW5ldHdvcmstb3B0aW9ucy50c1xuZnVuY3Rpb24gY3JlYXRlRGVmYXVsdE5ldHdvcmtPcHRpb25zKHdvcmtlclVybCA9IFwiL21vY2tTZXJ2aWNlV29ya2VyLmpzXCIpIHtcblx0cmV0dXJuIHtcblx0XHRzb3VyY2VzOiBbc3VwcG9ydHNTZXJ2aWNlV29ya2VyKCkgPyBuZXcgU2VydmljZVdvcmtlclNvdXJjZSh7IHNlcnZpY2VXb3JrZXI6IHsgdXJsOiB3b3JrZXJVcmwgfSB9KSA6IG5ldyBGYWxsYmFja0h0dHBTb3VyY2UoKSwgbmV3IEludGVyY2VwdG9yU291cmNlKHsgaW50ZXJjZXB0b3JzOiBbbmV3IFdlYlNvY2tldEludGVyY2VwdG9yKCldIH0pXSxcblx0XHRvblVuaGFuZGxlZEZyYW1lOiBcIndhcm5cIlxuXHR9O1xufVxuY29uc3QgZGVmYXVsdE5ldHdvcmtPcHRpb25zID0gY3JlYXRlRGVmYXVsdE5ldHdvcmtPcHRpb25zKCk7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNyZWF0ZURlZmF1bHROZXR3b3JrT3B0aW9ucywgZGVmYXVsdE5ldHdvcmtPcHRpb25zLCBzZXR1cFdvcmtlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQVdBLGVBQWVBLFFBQU0sVUFBVTtDQUM5QixJQUFJO0VBQ0gsT0FBTyxDQUFDLE1BQU0sTUFBTSxTQUFTLENBQUMsQ0FBQyxPQUFPLFVBQVU7R0FDL0MsTUFBTTtFQUNQLENBQUMsQ0FBQztDQUNILFNBQVMsT0FBTztFQUNmLE9BQU8sQ0FBQyxPQUFPLElBQUk7Q0FDcEI7QUFDRDs7QUNUQSxJQUFJLG9CQUFvQixjQUFjLFdBQVc7Q0FDaEQ7Q0FDQSxZQUFZLE1BQU0sT0FBTztFQUN4QixNQUFNLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ25CLEtBQUssUUFBUTtDQUNkO0FBQ0Q7QUFDQSxJQUFJLGdCQUFnQixNQUFNO0NBQ3pCO0NBQ0EsY0FBYztFQUNiLEtBQUssVUFBVSxJQUFJLFFBQVE7Q0FDNUI7Q0FDQSxNQUFNLE1BQU0sT0FBTztFQUNsQixNQUFNLEtBQUssUUFBUSxjQUFjLElBQUksa0JBQWtCLFNBQVMsS0FBSyxDQUFDO0NBQ3ZFO0NBQ0EsR0FBRyxNQUFNLFVBQVUsU0FBUztFQUMzQixLQUFLLFFBQVEsR0FBRyxNQUFNLFVBQVUsT0FBTztDQUN4QztDQUNBLFVBQVU7RUFDVCxLQUFLLFFBQVEsbUJBQW1CO0NBQ2pDO0FBQ0Q7QUFHQSxTQUFTLGtCQUFrQixRQUFRLE1BQU0sU0FBUztDQUNqRCxDQUFDLE9BQU8sVUFBVSxDQUFDLEVBQUEsQ0FBRyxLQUFLLE9BQU87QUFDbkM7QUFDQSxTQUFTLHVCQUF1QixRQUFRLE1BQU0sa0JBQWtCO0NBQy9ELE1BQU0sa0JBQWtCLE9BQU87Q0FDL0IsT0FBTyxRQUFRLGtCQUFrQixDQUFDLEdBQUcsa0JBQWtCLEdBQUcsZ0JBQWdCLFFBQVEsb0JBQW9CO0VBQ3JHLE9BQU8sQ0FBQyxpQkFBaUIsU0FBUyxlQUFlO0NBQ2xELENBQUMsQ0FBQyxJQUFJO0FBQ1A7QUFDQSxTQUFTLG9CQUFvQixVQUFVO0NBQ3RDLE1BQU0sU0FBUyxDQUFDO0NBQ2hCLE1BQU0sa0NBQWtDLElBQUksSUFBSTtDQUNoRCxNQUFNLFNBQVMsWUFBWTtFQUMxQixJQUFJLGdCQUFnQixJQUFJLE9BQU8sR0FBRztFQUNsQyxnQkFBZ0IsSUFBSSxPQUFPO0VBQzNCLGtCQUFrQixRQUFRLFFBQVEsTUFBTSxPQUFPO0VBQy9DLEtBQUssTUFBTSxXQUFXLG1CQUFtQixPQUFPLEdBQUcsTUFBTSxPQUFPO0NBQ2pFO0NBQ0EsS0FBSyxNQUFNLFdBQVcsVUFBVSxNQUFNLE9BQU87Q0FDN0MsT0FBTztBQUNSO0FBQ0EsSUFBSSxxQkFBcUIsTUFBTTtDQUM5QixnQkFBZ0IsaUJBQWlCO0VBQ2hDLFVBQVUsS0FBSyxrQkFBa0IsZUFBZSxHQUFHLFNBQVMsY0FBYyw2R0FBNkcsQ0FBQztFQUN4TCxNQUFNLDRCQUE0QixvQkFBb0IsZUFBZTtFQUNyRSxPQUFPO0dBQ04saUJBQWlCO0dBQ2pCLFVBQVUsRUFBRSxHQUFHLDBCQUEwQjtFQUMxQztDQUNEO0NBQ0Esa0JBQWtCO0VBQ2pCLE9BQU8sT0FBTyxPQUFPLEtBQUssU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxZQUFZLFdBQVcsSUFBSTtDQUMxRjs7Ozs7OztDQU9BLGVBQWU7RUFDZCxPQUFPLEtBQUssZ0JBQWdCLENBQUMsQ0FBQyxRQUFRLFlBQVk7R0FDakQsT0FBTyxDQUFDLGlCQUFpQixPQUFPO0VBQ2pDLENBQUM7Q0FDRjs7OztDQUlBLGtCQUFrQixNQUFNO0VBQ3ZCLE9BQU8sS0FBSyxTQUFTLENBQUMsQ0FBQyxTQUFTLFNBQVMsQ0FBQztDQUMzQztDQUNBLElBQUksY0FBYztFQUNqQixVQUFVLEtBQUssa0JBQWtCLFlBQVksR0FBRyxTQUFTLGNBQWMsd0lBQXdJLENBQUM7RUFDaE4sSUFBSSxhQUFhLFdBQVcsR0FBRztFQUMvQixNQUFNLEVBQUUsYUFBYSxLQUFLLFNBQVM7RUFDbkMsTUFBTSxZQUFZLG9CQUFvQixZQUFZO0VBQ2xELElBQUksVUFBVSxTQUFTLHVCQUF1QixVQUFVLFdBQVcsVUFBVSxPQUFPO0VBQ3BGLElBQUksVUFBVSxXQUFXLHVCQUF1QixVQUFVLGFBQWEsVUFBVSxTQUFTO0VBQzFGLEtBQUssU0FBUyxFQUFFLFNBQVMsQ0FBQztDQUMzQjtDQUNBLE1BQU0sY0FBYztFQUNuQixVQUFVLGFBQWEsU0FBUyxJQUFJLEtBQUssa0JBQWtCLFlBQVksSUFBSSxNQUFNLFNBQVMsY0FBYyxpSEFBaUgsQ0FBQztFQUMxTixNQUFNLEVBQUUsb0JBQW9CLEtBQUssU0FBUztFQUMxQyxNQUFNLHNCQUFzQixhQUFhLFNBQVMsSUFBSSxvQkFBb0IsWUFBWSxJQUFJO0VBQzFGLE1BQU0sa0JBQWtCLElBQUksSUFBSSxLQUFLLGdCQUFnQixDQUFDO0VBQ3RELE1BQU0sa0JBQWtCLElBQUksSUFBSSxPQUFPLE9BQU8sbUJBQW1CLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQztFQUN6RixLQUFLLE1BQU0sV0FBVyxnQkFBZ0IsYUFBYSxlQUFlLEdBQUcsUUFBUSxNQUFNO0VBQ25GLEtBQUssTUFBTSxXQUFXLGdCQUFnQixXQUFXLGVBQWUsR0FBRyxJQUFJO0dBQ3RFLE1BQU0sV0FBVyxRQUFRLFFBQVE7R0FDakMsSUFBSSxvQkFBb0IsU0FBUyxTQUFTLE9BQU8sVUFBVTtJQUMxRCxLQUFLLG9CQUFvQixTQUFTLEtBQUs7R0FDeEMsQ0FBQztFQUNGLFNBQVMsT0FBTztHQUNmLEtBQUssb0JBQW9CLFNBQVMsS0FBSztFQUN4QztFQUNBLElBQUksYUFBYSxXQUFXLEdBQUc7R0FDOUIsS0FBSyxTQUFTLEVBQUUsVUFBVSxFQUFFLEdBQUcsZ0JBQWdCLEVBQUUsQ0FBQztHQUNsRDtFQUNEO0VBQ0EsS0FBSyxTQUFTO0dBQ2IsaUJBQWlCO0dBQ2pCLFVBQVUsRUFBRSxHQUFHLG9CQUFvQjtFQUNwQyxDQUFDO0NBQ0Y7Q0FDQSxVQUFVO0VBQ1QsS0FBSyxNQUFNLFdBQVcsS0FBSyxnQkFBZ0IsR0FBRyxRQUFRLFFBQVE7Q0FDL0Q7Q0FDQSxVQUFVO0VBQ1QsTUFBTSxtQkFBbUIsQ0FBQztFQUMxQixLQUFLLE1BQU0sV0FBVyxLQUFLLGdCQUFnQixHQUFHO0dBQzdDLE1BQU0sV0FBVyxRQUFRLFFBQVE7R0FDakMsSUFBSSxvQkFBb0IsU0FBUyxpQkFBaUIsS0FBSyxRQUFRO0VBQ2hFO0VBQ0EsSUFBSSxpQkFBaUIsU0FBUyxHQUFHLE9BQU8sUUFBUSxJQUFJLGdCQUFnQixDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7Q0FDcEY7Q0FDQSxrQkFBa0IsVUFBVTtFQUMzQixPQUFPLFNBQVMsT0FBTyxZQUFZLENBQUMsTUFBTSxRQUFRLE9BQU8sQ0FBQztDQUMzRDtDQUNBLG9CQUFvQixTQUFTLE9BQU87RUFDbkMsU0FBUyxNQUFNLHNHQUFzRyxRQUFRLE1BQU0sS0FBSztDQUN6STtBQUNEO0FBQ0EsSUFBSSw2QkFBNkIsY0FBYyxtQkFBbUI7Q0FDakU7Q0FDQTtDQUNBLFlBQVksaUJBQWlCO0VBQzVCLE1BQU07RUFDTixNQUFNLGVBQWUsS0FBSyxnQkFBZ0IsZUFBZTtFQUN6RCxLQUFLLG1CQUFtQixhQUFhO0VBQ3JDLEtBQUssWUFBWSxhQUFhO0NBQy9CO0NBQ0EsV0FBVztFQUNWLE9BQU87R0FDTixpQkFBaUIsS0FBSztHQUN0QixVQUFVLEtBQUs7RUFDaEI7Q0FDRDtDQUNBLFNBQVMsV0FBVztFQUNuQixJQUFJLFVBQVUsaUJBQWlCLEtBQUssbUJBQW1CLFVBQVU7RUFDakUsSUFBSSxVQUFVLFVBQVUsS0FBSyxZQUFZLFVBQVU7Q0FDcEQ7QUFDRDs7OztBQU1BLFNBQVMsZ0JBQWdCLFFBQVE7Q0FDaEMsTUFBTSxRQUFRLENBQUMsR0FBRyxNQUFNO0NBQ3hCLE9BQU8sT0FBTyxLQUFLO0NBQ25CLE9BQU87QUFDUjtBQUdBLElBQUksYUFBYSxNQUFNO0NBQ3RCLGdCQUFnQixDQUFDO0NBQ2pCLFVBQVU7RUFDVCxJQUFJO0VBQ0osTUFBTSxTQUFTLENBQUM7RUFDaEIsT0FBTyxlQUFlLEtBQUssY0FBYyxNQUFNLEdBQUcsSUFBSTtHQUNyRCxhQUFhO0VBQ2QsU0FBUyxPQUFPO0dBQ2YsSUFBSSxpQkFBaUIsT0FBTyxPQUFPLEtBQUssS0FBSztFQUM5QztFQUNBLElBQUksT0FBTyxTQUFTLEdBQUcsUUFBUSxNQUFNLElBQUksZUFBZSxRQUFRLFNBQVMsY0FBYywySUFBMkksQ0FBQyxDQUFDO0NBQ3JPO0FBQ0Q7QUFHQSxTQUFTLG9CQUFvQixRQUFRO0NBQ3BDLE1BQU0sV0FBVyxDQUFDO0NBQ2xCLEtBQUssTUFBTSxTQUFTLFFBQVEsSUFBSSxpQkFBaUIsU0FBUyxTQUFTLEtBQUssS0FBSztDQUM3RSxJQUFJLFNBQVMsU0FBUyxHQUFHLE9BQU8sUUFBUSxJQUFJLFFBQVEsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3BFOzs7Ozs7Ozs7Ozs7O0FBa0JBLFNBQVMsY0FBYyxTQUFTO0NBQy9CLElBQUksYUFBYTtDQUNqQixNQUFNLFNBQVMsSUFBSSxRQUFRO0NBQzNCLE1BQU0sYUFBYSxJQUFJLFdBQVc7Q0FDbEMsTUFBTSw0QkFBNEIsYUFBYTtFQUM5QyxPQUFPLG9CQUFvQixxQkFBcUIsV0FBVyxJQUFJLDJCQUEyQixZQUFZLENBQUMsQ0FBQztDQUN6RztDQUNBLElBQUksa0JBQWtCLEVBQUUsR0FBRyxRQUFROzs7OztDQUtuQyxJQUFJLHFCQUFxQix5QkFBeUIsZ0JBQWdCLFFBQVE7Q0FDMUUsT0FBTztFQUNOLElBQUksYUFBYTtHQUNoQixPQUFPO0VBQ1I7RUFDQTtFQUNBLFVBQVUsU0FBUztHQUNsQixVQUFVLGVBQWUsR0FBRyw2RkFBNkY7R0FDekgsSUFBSSxRQUFRLFlBQVksQ0FBQyxPQUFPLEdBQUcsUUFBUSxVQUFVLGdCQUFnQixRQUFRLEdBQUcscUJBQXFCLHlCQUF5QixRQUFRLFFBQVE7R0FDOUksa0JBQWtCO0lBQ2pCLEdBQUc7SUFDSCxHQUFHO0dBQ0o7RUFDRDtFQUNBLFNBQVM7R0FDUixVQUFVLGVBQWUsR0FBRywyREFBMkQ7R0FDdkYsYUFBYTs7Ozs7O0dBTWIsTUFBTSxVQUFVLEVBQUUsUUFBUSxLQUFLO0dBQy9CLFdBQVcsZ0JBQWdCLENBQUMsV0FBVztJQUN0QyxRQUFRLFNBQVM7R0FDbEIsQ0FBQztHQUNELE9BQU8sb0JBQW9CLGdCQUFnQixRQUFRLEtBQUssV0FBVzs7Ozs7OztJQU9sRSxjQUFjLFVBQVUsUUFBUSxLQUFLLE1BQU07SUFDM0MsT0FBTyxHQUFHLFNBQVMsT0FBTyxFQUFFLFlBQVk7S0FDdkMsTUFBTSxPQUFPLEdBQUcsTUFBTSxVQUFVOzs7Ozs7OztNQVEvQixJQUFJLENBQUMsUUFBUSxRQUFRO01BQ3JCLE9BQU8sS0FBSyxLQUFLO0tBQ2xCLENBQUM7S0FDRCxNQUFNLFdBQVcsTUFBTSxZQUFZLGtCQUFrQjtLQUNyRCxNQUFNLE1BQU0sUUFBUSxVQUFVLGdCQUFnQixvQkFBb0IsUUFBUSxnQkFBZ0IsT0FBTztJQUNsRyxDQUFDO0lBQ0QsT0FBTyxPQUFPLE9BQU8sZ0JBQWdCLE9BQU87R0FDN0MsQ0FBQyxDQUFDO0VBQ0g7RUFDQSxVQUFVO0dBQ1QsVUFBVSxlQUFlLEdBQUcsNkRBQTZEO0dBQ3pGLGFBQWE7R0FDYixNQUFNLG1CQUFtQixtQkFBbUIsUUFBUTtHQUNwRCxXQUFXLFFBQVE7Ozs7Ozs7O0dBUW5CLE1BQU0sa0JBQWtCLG9CQUFvQixnQkFBZ0IsUUFBUSxLQUFLLFdBQVcsT0FBTyxRQUFRLENBQUMsQ0FBQzs7Ozs7O0dBTXJHLE9BQU8sNEJBQTRCLFVBQVUsUUFBUSxJQUFJLENBQUMsa0JBQWtCLGVBQWUsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSTtFQUNoSDtFQUNBLElBQUksR0FBRyxVQUFVO0dBQ2hCLG1CQUFtQixJQUFJLFFBQVE7RUFDaEM7RUFDQSxjQUFjLEdBQUcsVUFBVTtHQUMxQixtQkFBbUIsTUFBTSxRQUFRO0VBQ2xDO0VBQ0Esa0JBQWtCO0dBQ2pCLG1CQUFtQixRQUFRO0VBQzVCO0VBQ0EsZUFBZTtHQUNkLE9BQU8sZ0JBQWdCLG1CQUFtQixhQUFhLENBQUM7RUFDekQ7Q0FDRDtBQUNEOzs7OztBQU9BLElBQUksZUFBZSxNQUFNO0NBQ3hCO0NBQ0E7Q0FDQTtDQUNBLFlBQVksVUFBVSxNQUFNO0VBQzNCLEtBQUssV0FBVztFQUNoQixLQUFLLE9BQU87RUFDWixLQUFLLFNBQVMsSUFBSSxRQUFRO0NBQzNCO0FBQ0Q7QUFHQSxlQUFlLHFCQUFxQixTQUFTLFVBQVU7Q0FDdEQsSUFBSSxnQkFBZ0IsTUFBTTtDQUMxQixLQUFLLE1BQU0sa0JBQWtCLGdCQUFnQixRQUFRLEdBQUcsTUFBTSxZQUFZLFVBQVUsZ0JBQWdCLFFBQVEsR0FBRztBQUNoSDtBQUdBLFNBQVMsb0JBQW9CLFNBQVM7Q0FDckMsT0FBTyxDQUFDLENBQUMsUUFBUSxRQUFRLElBQUksUUFBUSxDQUFDLEVBQUUsU0FBUyxpQkFBaUI7QUFDbkU7Ozs7QUFJQSxTQUFTLCtCQUErQixTQUFTO0NBQ2hELE1BQU0sZUFBZSxRQUFRLFFBQVEsSUFBSSxRQUFROzs7Ozs7Q0FNakQsSUFBSSxjQUFjO0VBQ2pCLE1BQU0sbUJBQW1CLGFBQWEsUUFBUSwyQkFBMkIsRUFBRTtFQUMzRSxJQUFJLGtCQUFrQixRQUFRLFFBQVEsSUFBSSxVQUFVLGdCQUFnQjtPQUMvRCxRQUFRLFFBQVEsT0FBTyxRQUFRO0NBQ3JDO0FBQ0Q7QUFHQSxlQUFlLDRCQUE0QixPQUFPLFFBQVE7Q0FDekQsTUFBTSx1QkFBdUIsT0FBTyxhQUFhO0VBQ2hELElBQUksYUFBYSxVQUFVO0VBQzNCLE1BQU0sVUFBVSxNQUFNLE1BQU0sb0JBQW9CO0VBQ2hELFFBQVEsVUFBUjtHQUNDLEtBQUssUUFBUSxPQUFPLFNBQVMsS0FBSyxlQUFlLE9BQU87R0FDeEQsS0FBSyxTQUFTLE9BQU8sU0FBUyxNQUFNLGFBQWEsT0FBTztFQUN6RDtDQUNEO0NBQ0EsTUFBTSxnQkFBZ0IsT0FBTyxhQUFhO0VBQ3pDLFVBQVUsR0FBRyxlQUFlLGFBQWEsWUFBWSxhQUFhLFVBQVUsYUFBYSxTQUFTLFNBQVMsY0FBYywyT0FBMk8sUUFBUSxDQUFDO0VBQzdXLElBQUksYUFBYSxVQUFVO0VBQzNCLE1BQU0scUJBQXFCLFFBQVE7RUFDbkMsSUFBSSxhQUFhLFNBQVMsT0FBTyxRQUFRLE9BQU8sSUFBSSxjQUFjLFNBQVMsY0FBYyxnR0FBZ0csQ0FBQyxDQUFDO0NBQzVMO0NBQ0EsSUFBSSxPQUFPLFdBQVcsWUFBWSxPQUFPLE9BQU87RUFDL0M7RUFDQSxVQUFVO0dBQ1QsTUFBTSxxQkFBcUIsS0FBSyxNQUFNLE1BQU07Ozs7Ozs7R0FPNUMsT0FBTyxxQkFBcUIsS0FBSyxNQUFNLE9BQU87RUFDL0M7Q0FDRCxDQUFDOzs7Ozs7O0NBT0QsSUFBSSxpQkFBaUIsb0JBQW9CLHFCQUFxQixNQUFNLEtBQUssT0FBTyxHQUFHO0NBQ25GLE9BQU8sY0FBYyxNQUFNO0FBQzVCO0FBR0EsSUFBSSxlQUFlLGNBQWMsV0FBVztDQUMzQztDQUNBO0NBQ0EsWUFBWSxNQUFNLE1BQU07RUFDdkIsTUFBTSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztFQUNuQixLQUFLLFlBQVksS0FBSztFQUN0QixLQUFLLFVBQVUsS0FBSztDQUNyQjtBQUNEO0FBQ0EsSUFBSSxnQkFBZ0IsY0FBYyxXQUFXO0NBQzVDO0NBQ0E7Q0FDQTtDQUNBLFlBQVksTUFBTSxNQUFNO0VBQ3ZCLE1BQU0sR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7RUFDbkIsS0FBSyxZQUFZLEtBQUs7RUFDdEIsS0FBSyxVQUFVLEtBQUs7RUFDcEIsS0FBSyxXQUFXLEtBQUs7Q0FDdEI7QUFDRDtBQUNBLElBQUksMEJBQTBCLGNBQWMsV0FBVztDQUN0RDtDQUNBO0NBQ0E7Q0FDQSxZQUFZLE1BQU0sTUFBTTtFQUN2QixNQUFNLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ25CLEtBQUssUUFBUSxLQUFLO0VBQ2xCLEtBQUssWUFBWSxLQUFLO0VBQ3RCLEtBQUssVUFBVSxLQUFLO0NBQ3JCO0FBQ0Q7QUFDQSxJQUFJLG1CQUFtQixjQUFjLGFBQWE7Q0FDakQsWUFBWSxTQUFTO0VBQ3BCLE1BQU0sS0FBSyxRQUFRLE1BQU0sZ0JBQWdCO0VBQ3pDLE1BQU0sUUFBUTtHQUNiO0dBQ0EsU0FBUyxRQUFRO0VBQ2xCLENBQUM7Q0FDRjtDQUNBLFlBQVksWUFBWTtFQUN2QixPQUFPLFdBQVcsa0JBQWtCLFNBQVM7Q0FDOUM7Q0FDQSxNQUFNLHNCQUFzQjtFQUMzQixNQUFNLEVBQUUsWUFBWSxLQUFLO0VBQ3pCLE1BQU0sTUFBTSxJQUFJLElBQUksUUFBUSxHQUFHO0VBQy9CLE1BQU0sWUFBWSxZQUFZLEdBQUcsSUFBSSxJQUFJO0VBQ3pDLE1BQU0sY0FBYyxRQUFRLFFBQVEsT0FBTyxPQUFPLE1BQU0sUUFBUSxNQUFNLENBQUMsQ0FBQyxLQUFLO0VBQzdFLE9BQU8sNERBQTRELGdCQUFnQixRQUFRLE9BQU8sR0FBRyxVQUFVLE1BQU0sY0FBYywwQkFBMEIsWUFBWSxRQUFRLEtBQUs7Q0FDdkw7Q0FDQSxNQUFNLFFBQVEsVUFBVSxrQkFBa0IsbUJBQW1CO0VBQzVELE1BQU0sRUFBRSxJQUFJLFdBQVcsWUFBWSxLQUFLO0VBQ3hDLE1BQU0sc0JBQXNCLG1CQUFtQixRQUFRLE9BQU8sUUFBUSxNQUFNO0VBQzVFLEtBQUssT0FBTyxLQUFLLElBQUksYUFBYSxpQkFBaUI7R0FDbEQ7R0FDQTtFQUNELENBQUMsQ0FBQztFQUNGLElBQUksb0JBQW9CLE9BQU8sR0FBRztHQUNqQyxLQUFLLE9BQU8sS0FBSyxJQUFJLGFBQWEsZUFBZTtJQUNoRDtJQUNBO0dBQ0QsQ0FBQyxDQUFDO0dBQ0YsS0FBSyxZQUFZO0dBQ2pCLE9BQU87RUFDUjtFQUNBLE1BQU0sQ0FBQyxhQUFhLGdCQUFnQixNQUFNQyxjQUFZO0dBQ3JELE9BQU8sZ0JBQWdCO0lBQ3RCO0lBQ0E7SUFDQTtJQUNBLG1CQUFtQjtLQUNsQixTQUFTLG1CQUFtQixTQUFTLFNBQVM7S0FDOUMsT0FBTyxtQkFBbUI7SUFDM0I7R0FDRCxDQUFDO0VBQ0YsQ0FBQztFQUNELElBQUksZUFBZSxNQUFNO0dBQ3hCLElBQUksQ0FBQyxLQUFLLE9BQU8sS0FBSyxJQUFJLHdCQUF3QixzQkFBc0I7SUFDdkUsT0FBTztJQUNQO0lBQ0E7R0FDRCxDQUFDLENBQUMsR0FBRztJQUNKLFFBQVEsTUFBTSxXQUFXO0lBQ3pCLFNBQVMsTUFBTSxvSEFBb0gsUUFBUSxRQUFRLFFBQVEsR0FBRztHQUMvSjtHQUNBLEtBQUssVUFBVSxXQUFXO0dBQzFCLE9BQU87RUFDUjtFQUNBLElBQUksZ0JBQWdCLE1BQU07Ozs7Ozs7R0FPekIsSUFBSSxjQUFjLFFBQVEsUUFBUSxTQUFTLEdBQUc7SUFDN0MsS0FBSyxPQUFPLEtBQUssSUFBSSxhQUFhLGVBQWU7S0FDaEQ7S0FDQTtJQUNELENBQUMsQ0FBQztJQUNGLEtBQUssWUFBWTtJQUNqQixPQUFPO0dBQ1I7R0FDQSxLQUFLLE9BQU8sS0FBSyxJQUFJLGFBQWEscUJBQXFCO0lBQ3REO0lBQ0E7R0FDRCxDQUFDLENBQUM7Ozs7O0dBS0YsTUFBTSw0QkFBNEIsTUFBTSxnQkFBZ0IsQ0FBQyxDQUFDLFdBQVcsS0FBSyxZQUFZLElBQUksVUFBVSxLQUFLLFVBQVUsS0FBSyxDQUFDO0dBQ3pILEtBQUssT0FBTyxLQUFLLElBQUksYUFBYSxlQUFlO0lBQ2hEO0lBQ0E7R0FDRCxDQUFDLENBQUM7R0FDRixPQUFPO0VBQ1I7RUFDQSxNQUFNLEVBQUUsVUFBVSxTQUFTLGlCQUFpQjtFQUM1QyxLQUFLLE9BQU8sS0FBSyxJQUFJLGFBQWEsaUJBQWlCO0dBQ2xEO0dBQ0E7RUFDRCxDQUFDLENBQUM7RUFDRixJQUFJLFlBQVksTUFBTTtHQUNyQixLQUFLLE9BQU8sS0FBSyxJQUFJLGFBQWEsZUFBZTtJQUNoRDtJQUNBO0dBQ0QsQ0FBQyxDQUFDO0dBQ0YsS0FBSyxZQUFZO0dBQ2pCLE9BQU87RUFDUjtFQUNBLElBQUksc0JBQXNCLFFBQVEsR0FBRztHQUNwQyxLQUFLLE9BQU8sS0FBSyxJQUFJLGFBQWEsZUFBZTtJQUNoRDtJQUNBO0dBQ0QsQ0FBQyxDQUFDO0dBQ0YsS0FBSyxZQUFZO0dBQ2pCLE9BQU87RUFDUjtFQUNBLE1BQU0sdUJBQXVCLG1CQUFtQixRQUFRLE9BQU8sU0FBUyxNQUFNO0VBQzlFLE1BQU0scUJBQXFCLFNBQVMsUUFBUTtFQUM1QyxLQUFLLFlBQVksUUFBUTtFQUN6QixLQUFLLE9BQU8sS0FBSyxJQUFJLGFBQWEsZUFBZTtHQUNoRDtHQUNBO0VBQ0QsQ0FBQyxDQUFDO0VBQ0YsSUFBSSxDQUFDLG1CQUFtQixPQUFPLFFBQVEsSUFBSTtHQUMxQyxTQUFTO0dBQ1QsVUFBVTtHQUNWO0VBQ0QsQ0FBQztFQUNELE9BQU87Q0FDUjtBQUNEO0FBR0EsSUFBSSwyQkFBMkIsY0FBYyxXQUFXO0NBQ3ZEO0NBQ0E7Q0FDQSxZQUFZLE1BQU0sTUFBTTtFQUN2QixNQUFNLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQ25CLEtBQUssTUFBTSxLQUFLO0VBQ2hCLEtBQUssWUFBWSxLQUFLO0NBQ3ZCO0FBQ0Q7QUFDQSxJQUFJLHNCQUFzQixjQUFjLHlCQUF5QjtDQUNoRTtDQUNBLFlBQVksTUFBTSxNQUFNO0VBQ3ZCLE1BQU0sTUFBTSxJQUFJO0VBQ2hCLEtBQUssUUFBUSxLQUFLO0NBQ25CO0FBQ0Q7QUFDQSxJQUFJLHdCQUF3QixjQUFjLGFBQWE7Q0FDdEQsWUFBWSxTQUFTO0VBQ3BCLE1BQU0sTUFBTSxFQUFFLFlBQVksUUFBUSxXQUFXLENBQUM7Q0FDL0M7Q0FDQSxZQUFZLFlBQVk7RUFDdkIsT0FBTyxXQUFXLGtCQUFrQixXQUFXO0NBQ2hEO0NBQ0EsTUFBTSxRQUFRLFVBQVUsa0JBQWtCLG1CQUFtQjtFQUM1RCxNQUFNLEVBQUUsZUFBZSxLQUFLO0VBQzVCLEtBQUssT0FBTyxLQUFLLElBQUkseUJBQXlCLHdCQUF3QjtHQUNyRSxLQUFLLFdBQVcsT0FBTztHQUN2QixXQUFXLFdBQVcsS0FBSztFQUM1QixDQUFDLENBQUM7RUFDRixNQUFNLHFCQUFxQixVQUFVO0dBQ3BDLEtBQUssT0FBTyxLQUFLLElBQUksb0JBQW9CLG1CQUFtQjtJQUMzRCxLQUFLLFdBQVcsT0FBTztJQUN2QixXQUFXLFdBQVcsS0FBSztJQUMzQixPQUFPLGtCQUFrQixLQUFLO0dBQy9CLENBQUMsQ0FBQztFQUNIO0VBQ0EsV0FBVyxPQUFPLE9BQU8saUJBQWlCLFNBQVMsaUJBQWlCO0VBQ3BFLFdBQVcsT0FBTyxPQUFPLGlCQUFpQixlQUFlO0dBQ3hELFdBQVcsT0FBTyxPQUFPLG9CQUFvQixTQUFTLGlCQUFpQjtFQUN4RSxHQUFHLEVBQUUsTUFBTSxLQUFLLENBQUM7RUFDakIsSUFBSSxTQUFTLFdBQVcsR0FBRztHQUMxQixNQUFNLDRCQUE0QixNQUFNLGdCQUFnQixDQUFDLENBQUMsV0FBVyxLQUFLLFlBQVksSUFBSSxVQUFVLEtBQUssVUFBVSxLQUFLLENBQUM7R0FDekgsT0FBTztFQUNSO0VBQ0EsSUFBSSxzQkFBc0I7RUFDMUIsS0FBSyxNQUFNLFdBQVcsVUFBVTtHQUMvQixNQUFNLG9CQUFvQixNQUFNLFFBQVEsSUFBSSxZQUFZO0lBQ3ZELFNBQVMsbUJBQW1CLFNBQVMsU0FBUzs7Ozs7O0lBTTlDLFFBQVEsS0FBSzs7Ozs7S0FLWixlQUFlO0dBQ2pCLENBQUM7R0FDRCxJQUFJLENBQUMsbUJBQW1CO0dBQ3hCLHNCQUFzQjs7Ozs7OztHQU90QixNQUFNLGVBQWUsQ0FBQyxtQkFBbUIsUUFBUSxRQUFRLElBQUksVUFBVSxJQUFJLEtBQUs7R0FDaEYsSUFBSTtJQUNILElBQUksQ0FBQyxRQUFRLFNBQVMsQ0FBQyxpQkFBaUIsR0FBRyxlQUFlO0dBQzNELFNBQVMsT0FBTztJQUNmLElBQUksQ0FBQyxLQUFLLE9BQU8sS0FBSyxJQUFJLG9CQUFvQixzQkFBc0I7S0FDbkU7S0FDQSxLQUFLLFdBQVcsT0FBTztLQUN2QixXQUFXLFdBQVcsS0FBSztJQUM1QixDQUFDLENBQUMsR0FBRztLQUNKLFFBQVEsTUFBTSxLQUFLO0tBQ25CLFNBQVMsTUFBTSxpSEFBaUgsV0FBVyxPQUFPLEdBQUc7SUFDdEo7Ozs7O0lBS0EsTUFBTTtHQUNQO0VBQ0Q7RUFDQSxJQUFJLENBQUMscUJBQXFCO0dBQ3pCLE1BQU0sNEJBQTRCLE1BQU0sZ0JBQWdCLENBQUMsQ0FBQyxXQUFXLEtBQUssWUFBWSxJQUFJLFVBQVUsS0FBSyxVQUFVLEtBQUssQ0FBQztHQUN6SCxPQUFPO0VBQ1I7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxNQUFNLHNCQUFzQjtFQUMzQixNQUFNLEVBQUUsZUFBZSxLQUFLO0VBQzVCLE9BQU8sdUVBQXVFLGdCQUFnQixXQUFXLE9BQU8sSUFBSSxNQUFNO0NBQzNIO0FBQ0Q7Ozs7OztBQU1BLFNBQVMsa0JBQWtCLE9BQU87Q0FDakMsSUFBSSxXQUFXLFNBQVMsTUFBTSxTQUFTLE1BQU0sT0FBTyxNQUFNO0NBQzFELElBQUksV0FBVyxTQUFTLE1BQU0sU0FBUyxNQUFNLE9BQU8sTUFBTTtBQUMzRDs7OztBQU1BLElBQUksb0JBQW9CLGNBQWMsY0FBYztDQUNuRDs7Ozs7Ozs7OztDQVVBO0NBQ0EsWUFBWSxTQUFTO0VBQ3BCLE1BQU07RUFDTixLQUFLLGVBQWUsSUFBSSxpQkFBaUI7R0FDeEMsTUFBTTtHQUNOLGNBQWMsUUFBUTtFQUN2QixDQUFDO0VBQ0QsS0FBSywwQkFBMEIsSUFBSSxRQUFRO0NBQzVDO0NBQ0EsU0FBUztFQUNSLEtBQUssYUFBYSxNQUFNO0VBQ3hCLEtBQUssYUFBYSxHQUFHLFdBQVcsS0FBSyxlQUFlLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLFlBQVksS0FBSyxnQkFBZ0IsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsY0FBYyxLQUFLLDJCQUEyQixLQUFLLElBQUksQ0FBQztDQUM1SztDQUNBLFVBQVU7RUFDVCxNQUFNLFFBQVE7RUFDZCxLQUFLLGFBQWEsUUFBUTs7Ozs7RUFLMUIsS0FBSywwQkFBMEIsSUFBSSxRQUFRO0NBQzVDO0NBQ0EsTUFBTSxlQUFlLE9BQU87RUFDM0IsTUFBTSxFQUFFLFdBQVcsU0FBUyxlQUFlO0VBQzNDLE1BQU0sWUFBWSxJQUFJLDRCQUE0QjtHQUNqRCxJQUFJO0dBQ0o7R0FDQTtFQUNELENBQUM7RUFDRCxLQUFLLFFBQVEsSUFBSSxTQUFTLFNBQVM7RUFDbkMsTUFBTSxLQUFLLE1BQU0sU0FBUztDQUMzQjtDQUNBLE1BQU0sZ0JBQWdCLEVBQUUsV0FBVyxTQUFTLFVBQVUsZ0JBQWdCO0VBQ3JFLE1BQU0sWUFBWSxLQUFLLFFBQVEsSUFBSSxPQUFPO0VBQzFDLEtBQUssUUFBUSxPQUFPLE9BQU87RUFDM0IsSUFBSSxhQUFhLE1BQU07RUFDdkIscUJBQXFCO0dBQ3BCLElBQUk7SUFDSCxVQUFVLE9BQU8sS0FBSyxJQUFJLGNBQWMsaUJBQWlCLFNBQVMsb0JBQW9CLG1CQUFtQjtLQUN4RztLQUNBO0tBQ0E7SUFDRCxDQUFDLENBQUM7R0FDSCxVQUFVOzs7Ozs7O0lBT1QsVUFBVSxPQUFPLG1CQUFtQjtHQUNyQztFQUNELENBQUM7Q0FDRjtDQUNBLE1BQU0sMkJBQTJCLFlBQVk7RUFDNUMsTUFBTSxLQUFLLE1BQU0sSUFBSSxpQ0FBaUMsRUFBRSxXQUFXLENBQUMsQ0FBQztDQUN0RTtBQUNEO0FBQ0EsSUFBSSw4QkFBOEIsY0FBYyxpQkFBaUI7Q0FDaEU7Q0FDQSxZQUFZLFNBQVM7RUFDcEIsTUFBTTtHQUNMLElBQUksUUFBUTtHQUNaLFNBQVMsUUFBUTtFQUNsQixDQUFDO0VBQ0QsS0FBSyxjQUFjLFFBQVE7Q0FDNUI7Q0FDQSxjQUFjO0VBQ2IsK0JBQStCLEtBQUssS0FBSyxPQUFPO0NBQ2pEO0NBQ0EsWUFBWSxVQUFVO0VBQ3JCLElBQUksVUFBVSxLQUFLLFlBQVksWUFBWSxRQUFRO0NBQ3BEO0NBQ0EsVUFBVSxRQUFRO0VBQ2pCLElBQUksa0JBQWtCLFVBQVUsT0FBTyxLQUFLLFlBQVksTUFBTTtFQUM5RCxJQUFJLGtCQUFrQixlQUFlLEtBQUssWUFBWSxVQUFVLE1BQU07RUFDdEUsTUFBTTtDQUNQO0FBQ0Q7QUFDQSxJQUFJLG1DQUFtQyxjQUFjLHNCQUFzQjs7Ozs7Q0FLMUU7Q0FDQSxZQUFZLE1BQU07RUFDakIsTUFBTSxFQUFFLFlBQVksS0FBSyxXQUFXLENBQUM7RUFDckMsS0FBSyxVQUFVLEtBQUssV0FBVzs7Ozs7RUFLL0IsS0FBSyxXQUFXLE9BQU8saUJBQWlCLGVBQWU7R0FDdEQsS0FBSyxPQUFPLG1CQUFtQjtFQUNoQyxHQUFHLEVBQUUsTUFBTSxLQUFLLENBQUM7Q0FDbEI7Q0FDQSxVQUFVLFFBQVE7RUFDakIsSUFBSSxrQkFBa0IsT0FBTzs7Ozs7R0FLNUIsTUFBTSxhQUFhLElBQUksTUFBTSxPQUFPO0dBQ3BDLE9BQU8sZUFBZSxZQUFZLFNBQVM7SUFDMUMsWUFBWTtJQUNaLGNBQWM7SUFDZCxPQUFPO0dBQ1IsQ0FBQztHQUNELEtBQUssUUFBUSxPQUFPLGNBQWMsVUFBVTtFQUM3QztDQUNEO0NBQ0EsY0FBYztFQUNiLEtBQUssS0FBSyxXQUFXLE9BQU8sUUFBUTtDQUNyQztBQUNEOzs7Ozs7Ozs7Ozs7QUMvdkJBLGVBQWUsTUFBTSxVQUFVO0NBQzlCLElBQUk7RUFDSCxPQUFPLENBQUMsTUFBTSxNQUFNLFNBQVMsQ0FBQyxDQUFDLE9BQU8sVUFBVTtHQUMvQyxNQUFNO0VBQ1AsQ0FBQyxDQUFDO0NBQ0gsU0FBUyxPQUFPO0VBQ2YsT0FBTyxDQUFDLE9BQU8sSUFBSTtDQUNwQjtBQUNEOztBQ2RBLElBQUksbUJBQW1CLGNBQWMsV0FBVztDQUMvQyxZQUFZLE1BQU07RUFDakIsTUFBTSxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQztFQUN4QixLQUFLLFVBQVUsS0FBSztFQUNwQixLQUFLLFlBQVksS0FBSztFQUN0QixLQUFLLFlBQVksS0FBSztFQUN0QixLQUFLLGFBQWEsS0FBSztDQUN4QjtBQUNEO0FBQ0EsSUFBSSxvQkFBb0IsY0FBYyxXQUFXO0NBQ2hELFlBQVksTUFBTTtFQUNqQixNQUFNLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0VBQ3pCLEtBQUssV0FBVyxLQUFLO0VBQ3JCLEtBQUssZUFBZSxLQUFLO0VBQ3pCLEtBQUssVUFBVSxLQUFLO0VBQ3BCLEtBQUssWUFBWSxLQUFLO0VBQ3RCLEtBQUssWUFBWSxLQUFLO0NBQ3ZCO0FBQ0Q7QUFDQSxJQUFJLHlCQUF5QixjQUFjLFdBQVc7Q0FDckQsWUFBWSxNQUFNO0VBQ2pCLE1BQU0sR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUMsQ0FBQztFQUNuQyxLQUFLLFFBQVEsS0FBSztFQUNsQixLQUFLLFVBQVUsS0FBSztFQUNwQixLQUFLLFlBQVksS0FBSztFQUN0QixLQUFLLFlBQVksS0FBSztFQUN0QixLQUFLLGFBQWEsS0FBSztDQUN4QjtBQUNEO0FBR0EsU0FBUyxnQkFBZ0IsT0FBTztDQUMvQixJQUFJLFNBQVMsTUFBTSxPQUFPO0NBQzFCLElBQUksRUFBRSxpQkFBaUIsUUFBUSxPQUFPO0NBQ3RDLE9BQU8sVUFBVSxTQUFTLFdBQVc7QUFDdEM7QUFHQSxlQUFlLGNBQWMsU0FBUztDQUNyQyxJQUFJLFFBQVEsUUFBUSxVQUFVLFNBQVMsR0FBRyxjQUFjLFFBQVEsT0FBTyxDQUFDLENBQUMsTUFBTSxZQUFZO0VBQzFGLFFBQVEsUUFBUSxLQUFLLFdBQVcsUUFBUSxXQUFXLE9BQU87Q0FDM0QsQ0FBQztDQUNELE1BQU0saUJBQWlCLE9BQU8sYUFBYTtFQUMxQyxJQUFJLG9CQUFvQixPQUFPO0dBQzlCLE1BQU0sUUFBUSxXQUFXLFVBQVUsUUFBUTtHQUMzQyxPQUFPO0VBQ1I7RUFDQSxJQUFJLGdCQUFnQixRQUFRLEdBQUc7R0FDOUIsTUFBTSxRQUFRLFdBQVcsWUFBWSxRQUFRO0dBQzdDLE9BQU87RUFDUjs7Ozs7O0VBTUEsSUFBSSxlQUFlLFFBQVEsR0FBRztHQUM3QixNQUFNLFFBQVEsV0FBVyxZQUFZLFFBQVE7R0FDN0MsT0FBTztFQUNSO0VBQ0EsSUFBSSxTQUFTLFFBQVEsR0FBRztHQUN2QixNQUFNLFFBQVEsV0FBVyxVQUFVLFFBQVE7R0FDM0MsT0FBTztFQUNSO0VBQ0EsT0FBTztDQUNSO0NBQ0EsTUFBTSxzQkFBc0IsT0FBTyxVQUFVO0VBQzVDLElBQUksaUJBQWlCLGtCQUFrQixNQUFNO0VBQzdDLElBQUksZ0JBQWdCLEtBQUssR0FBRztHQUMzQixNQUFNLFFBQVEsV0FBVyxVQUFVLEtBQUs7R0FDeEMsT0FBTztFQUNSO0VBQ0EsSUFBSSxpQkFBaUIsVUFBVSxPQUFPLE1BQU0sZUFBZSxLQUFLO0VBQ2hFLE9BQU87Q0FDUjtDQUNBLE1BQU0sc0JBQXNCLFFBQVEsY0FBYztDQUNsRCxJQUFJO0NBQ0osSUFBSSxtQkFBbUI7Q0FDdkIsTUFBTSxnQkFBZ0I7RUFDckIsbUJBQW1CO0VBQ25CLHFCQUFxQixRQUFRLFFBQVEsUUFBUTtFQUM3QyxvQkFBb0IsT0FBTyxrQkFBa0I7Q0FDOUM7Ozs7Q0FJQSxJQUFJLFFBQVEsUUFBUSxRQUFRO0VBQzNCLElBQUksUUFBUSxRQUFRLE9BQU8sU0FBUztHQUNuQyxNQUFNLFFBQVEsV0FBVyxVQUFVLFFBQVEsUUFBUSxPQUFPLE1BQU07R0FDaEU7RUFDRDtFQUNBLFFBQVEsUUFBUSxPQUFPLGlCQUFpQixTQUFTLFNBQVMsRUFBRSxNQUFNLEtBQUssQ0FBQztDQUN6RTtDQUNBLE1BQU0sQ0FBQyxlQUFlLE1BQU0sTUFBTSxZQUFZO0VBQzdDLE1BQU0sZUFBZSxJQUFJLGlCQUFpQjtHQUN6QyxXQUFXLFFBQVE7R0FDbkIsV0FBVyxRQUFRO0dBQ25CLFNBQVMsUUFBUTtHQUNqQixZQUFZLFFBQVE7RUFDckIsQ0FBQztFQUNELE1BQU0sMEJBQTBCLFFBQVEsUUFBUSxjQUFjLFlBQVk7RUFDMUUsTUFBTSxRQUFRLEtBQUs7R0FDbEIsb0JBQW9CO0dBQ3BCO0dBQ0EsUUFBUSxXQUFXO0VBQ3BCLENBQUM7Ozs7Ozs7RUFPRCxJQUFJLGFBQWEsWUFBWSxRQUFRLFNBQVMsUUFBUSxVQUFVLGFBQWE7Q0FDOUUsQ0FBQztDQUNELFFBQVEsUUFBUSxRQUFRLG9CQUFvQixTQUFTLE9BQU87Q0FDNUQsSUFBSSxrQkFBa0I7RUFDckIsTUFBTSxRQUFRLFdBQVcsVUFBVSxrQkFBa0I7RUFDckQ7Q0FDRDtDQUNBLElBQUksYUFBYTtFQUNoQixJQUFJLE1BQU0sb0JBQW9CLFdBQVcsR0FBRztFQUM1QyxJQUFJLFFBQVEsUUFBUSxjQUFjLG9CQUFvQixJQUFJLEdBQUc7R0FDNUQsTUFBTSwrQkFBK0IsSUFBSSxrQkFBa0IsUUFBUSxTQUFTOzs7Ozs7SUFNM0UsY0FBYyxDQUFDO0lBQ2YsTUFBTSxZQUFZLFVBQVU7S0FDM0IsTUFBTSxlQUFlLFFBQVE7SUFDOUI7SUFDQSxNQUFNLFVBQVUsUUFBUTs7Ozs7Ozs7S0FRdkIsTUFBTSxRQUFRLFdBQVcsVUFBVSxNQUFNO0lBQzFDO0dBQ0QsQ0FBQztHQUNELE1BQU0sUUFBUSxRQUFRLGNBQWMsSUFBSSx1QkFBdUI7SUFDOUQsV0FBVyxRQUFRO0lBQ25CLE9BQU87SUFDUCxTQUFTLFFBQVE7SUFDakIsV0FBVyxRQUFRO0lBQ25CLFlBQVk7R0FDYixDQUFDLENBQUM7R0FDRixJQUFJLDZCQUE2QixlQUFlLGtCQUFrQixTQUFTO0VBQzVFO0VBQ0EsTUFBTSxRQUFRLFdBQVcsWUFBWSwwQkFBMEIsV0FBVyxDQUFDO0VBQzNFO0NBQ0Q7Q0FDQSxJQUFJLFFBQVEsV0FBVyxlQUFlLGtCQUFrQixTQUFTLE9BQU8sTUFBTSxRQUFRLFdBQVcsWUFBWTtDQUM3RyxPQUFPLFFBQVEsV0FBVztBQUMzQjs7Ozs7QUN2SkEsU0FBUyxrQkFBa0IsTUFBTSxPQUFPO0NBQ3ZDLE1BQU0sU0FBUyxJQUFJLFdBQVcsS0FBSyxhQUFhLE1BQU0sVUFBVTtDQUNoRSxPQUFPLElBQUksTUFBTSxDQUFDO0NBQ2xCLE9BQU8sSUFBSSxPQUFPLEtBQUssVUFBVTtDQUNqQyxPQUFPO0FBQ1I7QUFHQSxJQUFJLGdCQUFnQixNQUFNO0NBQ3pCLFlBQVksTUFBTSxTQUFTO0VBQzFCLEtBQUssT0FBTztFQUNaLEtBQUssa0JBQWtCO0VBQ3ZCLEtBQUssWUFBWTtFQUNqQixLQUFLLGlCQUFpQjtFQUN0QixLQUFLLE9BQU87RUFDWixLQUFLLGFBQWE7RUFDbEIsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyxhQUFhO0VBQ2xCLEtBQUssWUFBWTtFQUNqQixLQUFLLFdBQVc7RUFDaEIsS0FBSyxhQUFhO0VBQ2xCLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUssVUFBVTtFQUNmLEtBQUssbUJBQW1CO0VBQ3hCLEtBQUssU0FBUztFQUNkLEtBQUssUUFBUTtFQUNiLEtBQUssZUFBZTtFQUNwQixLQUFLLGNBQWM7RUFDbkIsS0FBSyxPQUFPO0VBQ1osS0FBSyxTQUFTLFNBQVMsVUFBVTtFQUNqQyxLQUFLLGdCQUFnQixTQUFTLGlCQUFpQjtFQUMvQyxLQUFLLFlBQVksS0FBSyxJQUFJO0NBQzNCO0NBQ0EsZUFBZTtFQUNkLE9BQU8sQ0FBQztDQUNUO0NBQ0EsVUFBVSxNQUFNLFNBQVMsWUFBWTtFQUNwQyxLQUFLLE9BQU87RUFDWixLQUFLLFVBQVUsQ0FBQyxDQUFDO0VBQ2pCLEtBQUssYUFBYSxDQUFDLENBQUM7Q0FDckI7Q0FDQSxpQkFBaUI7RUFDaEIsS0FBSyxtQkFBbUI7Q0FDekI7Q0FDQSxrQkFBa0IsQ0FBQztDQUNuQiwyQkFBMkIsQ0FBQztBQUM3QjtBQUdBLElBQUksd0JBQXdCLGNBQWMsY0FBYztDQUN2RCxZQUFZLE1BQU0sTUFBTTtFQUN2QixNQUFNLElBQUk7RUFDVixLQUFLLG1CQUFtQixNQUFNLG9CQUFvQjtFQUNsRCxLQUFLLFdBQVcsTUFBTSxZQUFZO0VBQ2xDLEtBQUssU0FBUyxNQUFNLFVBQVU7RUFDOUIsS0FBSyxRQUFRLE1BQU0sU0FBUztDQUM3QjtBQUNEO0FBR0EsSUFBTSwwQkFBMEIsT0FBTyxrQkFBa0I7QUFDekQsU0FBUyxZQUFZLFFBQVEsTUFBTSxNQUFNO0NBQ3hDLE1BQU0saUJBQWlCO0VBQ3RCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Q7Ozs7O0NBS0EsTUFBTSxxQkFBcUIsMEJBQTBCLGdCQUFnQjtDQUNyRSxPQUFPLGVBQWUsU0FBUyxJQUFJLElBQUksSUFBSSxtQkFBbUIsTUFBTTtFQUNuRSxrQkFBa0I7RUFDbEIsUUFBUSxNQUFNLFVBQVU7RUFDeEIsT0FBTyxNQUFNLFNBQVM7Q0FDdkIsQ0FBQyxJQUFJLElBQUksY0FBYyxNQUFNO0VBQzVCO0VBQ0EsZUFBZTtDQUNoQixDQUFDO0FBQ0Y7Ozs7O0FBT0EsU0FBUyxtQkFBbUIsUUFBUSxjQUFjO0NBQ2pELElBQUksRUFBRSxnQkFBZ0IsU0FBUyxPQUFPO0NBQ3RDLElBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxRQUFRLFlBQVksR0FBRyxPQUFPO0NBQ3ZFLE1BQU0sWUFBWSxRQUFRLGVBQWUsTUFBTTtDQUMvQyxPQUFPLFlBQVksbUJBQW1CLFdBQVcsWUFBWSxJQUFJO0FBQ2xFO0FBR0EsU0FBUyxZQUFZLFFBQVEsU0FBUztDQUNyQyxPQUFPLElBQUksTUFBTSxRQUFRLHNCQUFzQixPQUFPLENBQUM7QUFDeEQ7QUFDQSxTQUFTLHNCQUFzQixTQUFTO0NBQ3ZDLE1BQU0sRUFBRSxpQkFBaUIsWUFBWSxhQUFhLGdCQUFnQjtDQUNsRSxNQUFNLFVBQVUsQ0FBQztDQUNqQixJQUFJLE9BQU8sb0JBQW9CLGFBQWEsUUFBUSxZQUFZLFNBQVMsUUFBUSxNQUFNLFdBQVc7RUFDakcsTUFBTSxPQUFPLFFBQVEsVUFBVSxLQUFLLE1BQU0sUUFBUSxNQUFNLFNBQVM7RUFDakUsT0FBTyxnQkFBZ0IsS0FBSyxXQUFXLE1BQU0sSUFBSTtDQUNsRDtDQUNBLFFBQVEsTUFBTSxTQUFTLFFBQVEsY0FBYyxXQUFXO0VBQ3ZELE1BQU0sYUFBYTtHQUNsQixNQUFNLGlCQUFpQixtQkFBbUIsUUFBUSxZQUFZLEtBQUs7R0FDbkUsTUFBTSxpQkFBaUIsUUFBUSx5QkFBeUIsZ0JBQWdCLFlBQVk7R0FDcEYsSUFBSSxPQUFPLGdCQUFnQixRQUFRLGFBQWE7SUFDL0MsZUFBZSxJQUFJLE1BQU0sUUFBUSxDQUFDLFNBQVMsQ0FBQztJQUM1QyxPQUFPO0dBQ1I7R0FDQSxPQUFPLFFBQVEsZUFBZSxnQkFBZ0IsY0FBYztJQUMzRCxVQUFVO0lBQ1YsWUFBWTtJQUNaLGNBQWM7SUFDZCxPQUFPO0dBQ1IsQ0FBQztFQUNGO0VBQ0EsSUFBSSxPQUFPLGdCQUFnQixhQUFhLE9BQU8sWUFBWSxLQUFLLFFBQVEsQ0FBQyxjQUFjLFNBQVMsR0FBRyxJQUFJO0VBQ3ZHLE9BQU8sS0FBSztDQUNiO0NBQ0EsUUFBUSxNQUFNLFNBQVMsUUFBUSxjQUFjLFVBQVU7Ozs7RUFJdEQsTUFBTSxhQUFhLE9BQU87RUFDMUIsTUFBTSxRQUFRLE9BQU8sZ0JBQWdCLGNBQWMsWUFBWSxLQUFLLFFBQVEsQ0FBQyxjQUFjLFFBQVEsR0FBRyxJQUFJLElBQUksS0FBSztFQUNuSCxJQUFJLE9BQU8sVUFBVSxZQUFZLFFBQVEsR0FBRyxTQUFTO0dBQ3BELE1BQU0sT0FBTyxNQUFNLEtBQUssUUFBUSxHQUFHLElBQUk7R0FDdkMsSUFBSSxPQUFPLGVBQWUsYUFBYSxPQUFPLFdBQVcsS0FBSyxRQUFRLENBQUMsY0FBYyxJQUFJLEdBQUcsSUFBSTtHQUNoRyxPQUFPLEtBQUs7RUFDYjtFQUNBLE9BQU87Q0FDUjtDQUNBLE9BQU87QUFDUjtBQUdBLFNBQVMseUJBQXlCLE1BQU07Q0FDdkMsT0FBTztFQUNOO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDLENBQUMsTUFBTSxrQkFBa0I7RUFDekIsT0FBTyxLQUFLLFdBQVcsYUFBYTtDQUNyQyxDQUFDO0FBQ0Y7Ozs7O0FBT0EsU0FBUyxVQUFVLE1BQU07Q0FDeEIsSUFBSTtFQUNILE9BQU8sS0FBSyxNQUFNLElBQUk7Q0FDdkIsU0FBUyxHQUFHO0VBQ1gsT0FBTztDQUNSO0FBQ0Q7Ozs7O0FBT0EsU0FBUyxlQUFlLFNBQVMsTUFBTTs7Ozs7Ozs7O0NBU3RDLE1BQU0scUJBQXFCLGNBQWMsbUJBQW1CLFFBQVEsTUFBTSxJQUFJLE9BQU87Q0FDckYsT0FBTyxJQUFJLGNBQWMsb0JBQW9CO0VBQzVDLEtBQUssUUFBUTtFQUNiLFFBQVEsUUFBUTtFQUNoQixZQUFZLFFBQVE7RUFDcEIsU0FBUyx1Q0FBdUMsUUFBUSxzQkFBc0IsQ0FBQztDQUNoRixDQUFDO0FBQ0Y7QUFDQSxTQUFTLHVDQUF1QyxlQUFlO0NBQzlELE1BQU0sVUFBVSxJQUFJLFFBQVE7Q0FDNUIsTUFBTSxRQUFRLGNBQWMsTUFBTSxTQUFTO0NBQzNDLEtBQUssTUFBTSxRQUFRLE9BQU87RUFDekIsSUFBSSxLQUFLLEtBQUssTUFBTSxJQUFJO0VBQ3hCLE1BQU0sQ0FBQyxNQUFNLEdBQUcsU0FBUyxLQUFLLE1BQU0sSUFBSTtFQUN4QyxNQUFNLFFBQVEsTUFBTSxLQUFLLElBQUk7RUFDN0IsUUFBUSxPQUFPLE1BQU0sS0FBSztDQUMzQjtDQUNBLE9BQU87QUFDUjs7Ozs7QUFPQSxlQUFlLGtCQUFrQixPQUFPO0NBQ3ZDLE1BQU0sd0JBQXdCLE1BQU0sUUFBUSxJQUFJLGdCQUFnQjtDQUNoRSxJQUFJLHlCQUF5QixRQUFRLDBCQUEwQixJQUFJLE9BQU8sT0FBTyxxQkFBcUI7Q0FDdEcsUUFBUSxNQUFNLE1BQU0sWUFBWSxFQUFBLENBQUc7QUFDcEM7QUFHQSxJQUFNLG9CQUFvQixPQUFPLG1CQUFtQjtBQUNwRCxJQUFNLGdCQUFnQixPQUFPLGVBQWU7QUFDNUMsSUFBTSxnQkFBZ0I7Ozs7O0FBS3RCLElBQUksMkJBQTJCLE1BQU07Q0FDcEMsWUFBWSxnQkFBZ0IsUUFBUTtFQUNuQyxLQUFLLGlCQUFpQjtFQUN0QixLQUFLLFNBQVM7RUFDZCxLQUFLLE9BQU87RUFDWixLQUFLLFNBQVM7RUFDZCxLQUFLLE1BQU07RUFDWCxLQUFLLHFCQUFxQjtFQUMxQixLQUFLLGdCQUFnQjtFQUNyQixLQUFLLHlCQUF5QixJQUFJLElBQUk7RUFDdEMsS0FBSywrQkFBK0IsSUFBSSxJQUFJO0VBQzVDLEtBQUssWUFBWSxnQkFBZ0I7RUFDakMsS0FBSyxpQkFBaUIsSUFBSSxRQUFRO0VBQ2xDLEtBQUssaUNBQWlDLElBQUksV0FBVztFQUNyRCxLQUFLLFVBQVUsWUFBWSxnQkFBZ0IsRUFBRSxhQUFhLENBQUMsWUFBWSxPQUFPLFdBQVc7R0FDeEYsUUFBUSxZQUFSO0lBQ0MsS0FBSyxRQUFRO0tBQ1osTUFBTSxDQUFDLFFBQVEsS0FBSyxTQUFTO0tBQzdCLEtBQUssT0FBTyxFQUFFLFNBQVM7S0FDdkIsSUFBSSxPQUFPLFFBQVEsYUFBYTtNQUMvQixLQUFLLFNBQVM7TUFDZCxLQUFLLE1BQU0sY0FBYyxNQUFNO0tBQ2hDLE9BQU87TUFDTixLQUFLLFNBQVM7TUFDZCxLQUFLLE1BQU0sY0FBYyxHQUFHO0tBQzdCO0tBQ0EsS0FBSyxPQUFPLFFBQVEsY0FBYyxLQUFLLFFBQVEsS0FBSyxJQUFJLElBQUk7S0FDNUQsT0FBTyxPQUFPO0lBQ2Y7SUFDQSxLQUFLLG9CQUFvQjtLQUN4QixNQUFNLENBQUMsV0FBVyxZQUFZO0tBQzlCLEtBQUssY0FBYyxXQUFXLFFBQVE7S0FDdEMsS0FBSyxPQUFPLFFBQVEsb0JBQW9CLFdBQVcsUUFBUTtLQUMzRCxPQUFPLE9BQU87SUFDZjtJQUNBLEtBQUssb0JBQW9CO0tBQ3hCLE1BQU0sQ0FBQyxNQUFNLFNBQVM7S0FDdEIsS0FBSyxlQUFlLElBQUksTUFBTSxLQUFLO0tBQ25DLEtBQUssT0FBTyxRQUFRLG9CQUFvQixNQUFNLEtBQUs7S0FDbkQsT0FBTyxPQUFPO0lBQ2Y7SUFDQSxLQUFLLFFBQVE7S0FDWixNQUFNLENBQUMsUUFBUTtLQUNmLElBQUksS0FBSyxNQUFNO01BQ2QsUUFBUSxLQUFLLDBDQUEwQyxLQUFLLE9BQU8sR0FBRyxLQUFLLElBQUksaUZBQWlGO01BQ2hLLE9BQU8sT0FBTztLQUNmO0tBQ0EsS0FBSyxRQUFRLGlCQUFpQixjQUFjO01BQzNDLElBQUksT0FBTyxLQUFLLGVBQWUsYUFBYTtPQUMzQyxNQUFNLGdCQUFnQjtRQUNyQixLQUFLOzs7Ozs7UUFNTCxLQUFLLFFBQVE7T0FDZDtPQUNBLEtBQUssV0FBVyxLQUFLLE1BQU07UUFDMUIsVUFBVTtRQUNWLGNBQWMsS0FBSyxxQkFBcUIsU0FBUztRQUNqRCxTQUFTO1FBQ1QsV0FBVyxLQUFLO09BQ2pCLENBQUM7TUFDRjtLQUNELENBQUM7S0FDRCxNQUFNLGNBQWMsT0FBTyxTQUFTLFdBQVcsYUFBYSxJQUFJLElBQUk7S0FDcEUsTUFBTSxlQUFlLEtBQUssa0JBQWtCLFdBQVc7S0FDdkQsS0FBSyxpQkFBaUIsYUFBYSxNQUFNOzs7OztLQUt6QyxxQkFBcUI7TUFDcEIsQ0FBQyxLQUFLLFdBQVcsS0FBSyxNQUFNO09BQzNCLFNBQVM7T0FDVCxXQUFXLEtBQUs7TUFDakIsQ0FBQyxLQUFLLFFBQVEsUUFBUSxFQUFBLENBQUcsY0FBYztPQUN0QyxJQUFJLENBQUMsS0FBSyxvQkFBb0I7UUFDN0IsS0FBSyxPQUFPLFFBQVEsa0dBQWtHLEtBQUssUUFBUSxVQUFVO1FBQzdJLE9BQU8sT0FBTztPQUNmO01BQ0QsQ0FBQztLQUNGLENBQUM7S0FDRDtJQUNEO0lBQ0EsU0FBUyxPQUFPLE9BQU87R0FDeEI7RUFDRCxFQUFFLENBQUM7Ozs7RUFJSCxPQUFPLEtBQUssU0FBUyxVQUFVLFlBQVksS0FBSyxRQUFRLFFBQVE7R0FDL0QsY0FBYyxDQUFDLGNBQWMsWUFBWSxXQUFXO0lBQ25ELFFBQVEsY0FBUjtLQUNDLEtBQUs7S0FDTCxLQUFLO0tBQ0wsS0FBSztLQUNMLEtBQUs7S0FDTCxLQUFLO0tBQ0wsS0FBSztLQUNMLEtBQUssYUFBYTtNQUNqQixNQUFNLFlBQVksYUFBYSxNQUFNLENBQUM7TUFDdEMsS0FBSyxvQkFBb0IsV0FBVyxTQUFTO0tBQzlDO0lBQ0Q7SUFDQSxPQUFPLE9BQU87R0FDZjtHQUNBLGFBQWEsQ0FBQyxZQUFZLE9BQU8sV0FBVztJQUMzQyxRQUFRLFlBQVI7S0FDQyxLQUFLLG9CQUFvQjtNQUN4QixNQUFNLENBQUMsV0FBVyxZQUFZO01BQzlCLEtBQUssb0JBQW9CLFdBQVcsUUFBUTtNQUM1QyxLQUFLLE9BQU8sUUFBUSwyQkFBMkIsV0FBVyxRQUFRO01BQ2xFLE9BQU8sT0FBTztLQUNmO0lBQ0Q7R0FDRDtFQUNELENBQUMsQ0FBQztDQUNIO0NBQ0EsY0FBYyxXQUFXLFVBQVU7RUFDbEMsTUFBTSxjQUFjLEtBQUssT0FBTyxJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUEsQ0FBRyxPQUFPLFFBQVE7RUFDckUsS0FBSyxPQUFPLElBQUksV0FBVyxVQUFVO0VBQ3JDLEtBQUssT0FBTyxRQUFRLDJCQUEyQixXQUFXLFFBQVE7Q0FDbkU7Q0FDQSxvQkFBb0IsV0FBVyxVQUFVO0VBQ3hDLE1BQU0sY0FBYyxLQUFLLGFBQWEsSUFBSSxTQUFTLEtBQUssQ0FBQyxFQUFBLENBQUcsT0FBTyxRQUFRO0VBQzNFLEtBQUssYUFBYSxJQUFJLFdBQVcsVUFBVTtFQUMzQyxLQUFLLE9BQU8sUUFBUSxrQ0FBa0MsV0FBVyxRQUFRO0NBQzFFOzs7OztDQUtBLE1BQU0sWUFBWSxVQUFVOzs7Ozs7Ozs7RUFTM0IsS0FBSyxxQkFBcUI7RUFDMUIsS0FBSyxPQUFPLFFBQVEsNENBQTRDLFNBQVMsUUFBUSxTQUFTLFVBQVU7RUFDcEcsY0FBYyxPQUFPLEtBQUssSUFBSSxNQUFNLFFBQVE7RUFDNUMsT0FBTyxpQkFBaUIsS0FBSyxTQUFTO0dBQ3JDLFVBQVU7SUFDVCxZQUFZO0lBQ1osY0FBYztJQUNkLFdBQVcsS0FBSztHQUNqQjtHQUNBLGNBQWM7SUFDYixZQUFZO0lBQ1osY0FBYztJQUNkLFdBQVcsS0FBSztHQUNqQjtHQUNBLGFBQWE7SUFDWixZQUFZO0lBQ1osY0FBYztJQUNkLFdBQVcsS0FBSztHQUNqQjtFQUNELENBQUM7RUFDRCxLQUFLLFFBQVEsYUFBYSxLQUFLLFNBQVM7R0FDdkMsUUFBUTtHQUNSLE9BQU87RUFDUixDQUFDO0VBQ0QsSUFBSSx5QkFBeUI7RUFDN0IsSUFBSSxpQkFBaUI7RUFDckIsSUFBSSxLQUFLLGdCQUFnQjtHQUN4QixNQUFNLG9CQUFvQixNQUFNLGtCQUFrQixLQUFLLGNBQWMsQ0FBQyxNQUFNLENBQUM7R0FDN0UsSUFBSSxDQUFDLGdCQUFnQixLQUFLLFFBQVEsYUFBYSxLQUFLLFFBQVEsUUFBUTtJQUNuRSxRQUFRO0lBQ1IsT0FBTztHQUNSLENBQUM7R0FDRCxNQUFNLGlDQUFpQyxnQkFBZ0I7SUFDdEQsMEJBQTBCO0lBQzFCLElBQUkseUJBQXlCLG1CQUFtQixLQUFLLFFBQVEsWUFBWSxLQUFLLFFBQVEsUUFBUTtLQUM3RixRQUFRO0tBQ1IsT0FBTztJQUNSLENBQUM7R0FDRjtHQUNBLE1BQU0sZ0NBQWdDO0lBQ3JDLGlCQUFpQjtJQUNqQixLQUFLLFFBQVEsWUFBWSxLQUFLLFFBQVEsUUFBUTtLQUM3QyxRQUFRO0tBQ1IsT0FBTztJQUNSLENBQUM7SUFDRCxLQUFLLFFBQVEsUUFBUSxLQUFLLFFBQVEsUUFBUTtLQUN6QyxRQUFRO0tBQ1IsT0FBTztJQUNSLENBQUM7SUFDRCxLQUFLLFFBQVEsV0FBVyxLQUFLLFFBQVEsUUFBUTtLQUM1QyxRQUFRO0tBQ1IsT0FBTztJQUNSLENBQUM7R0FDRjtHQUNBLElBQUksS0FBSyxjQUFjLEVBQUUsUUFBUSxNQUFNO0lBQ3RDLE1BQU0sU0FBUyxLQUFLLGNBQWMsQ0FBQyxLQUFLLFVBQVU7SUFDbEQsT0FBTyxNQUFNO0tBQ1osTUFBTSxFQUFFLE9BQU8sU0FBUyxNQUFNLE9BQU8sS0FBSztLQUMxQyxJQUFJLE1BQU07TUFDVCx3QkFBd0I7TUFDeEI7S0FDRDtLQUNBLDhCQUE4QixNQUFNLFVBQVU7SUFDL0M7R0FDRCxPQUFPLHdCQUF3QjtFQUNoQztFQUNBLElBQUksV0FBVztFQUNmLE1BQU0seUJBQXlCLElBQUksZ0JBQWdCO0VBQ25ELE1BQU0scUJBQXFCLFVBQVU7R0FDcEMsS0FBSyxjQUFjLEtBQUssUUFBUSxJQUFJO0dBQ3BDLElBQUksQ0FBQyxnQkFBZ0I7SUFDcEIsS0FBSyxRQUFRLE9BQU8sS0FBSyxRQUFRLFFBQVE7S0FDeEMsUUFBUTtLQUNSLE9BQU87SUFDUixDQUFDO0lBQ0QsS0FBSyxRQUFRLFdBQVcsS0FBSyxRQUFRLFFBQVE7S0FDNUMsUUFBUTtLQUNSLE9BQU87SUFDUixDQUFDO0dBQ0Y7R0FDQSxLQUFLLFFBQVEsT0FBTyxLQUFLLFNBQVM7SUFDakMsUUFBUTtJQUNSLE9BQU87R0FDUixDQUFDO0dBQ0QsS0FBSyxRQUFRLFdBQVcsS0FBSyxTQUFTO0lBQ3JDLFFBQVE7SUFDUixPQUFPO0dBQ1IsQ0FBQztFQUNGO0VBQ0EsTUFBTSxrQkFBa0IsT0FBTyxhQUFhO0dBQzNDLE1BQU0scUJBQXFCO0lBQzFCLElBQUksVUFBVSxrQkFBa0IsU0FBUztTQUNwQyxJQUFJLHVCQUF1QixPQUFPLFNBQVMsa0JBQWtCLE9BQU87U0FDcEUsSUFBSSxnQkFBZ0IsUUFBUSxHQUFHLGtCQUFrQixPQUFPO0dBQzlEO0dBQ0EsYUFBYTtHQUNiLE9BQU8sS0FBSyxTQUFTLFVBQVUsU0FBUyxNQUFNO0dBQzlDLE9BQU8sS0FBSyxTQUFTLGNBQWMsU0FBUyxVQUFVO0dBQ3RELElBQUksQ0FBQyxLQUFLLFFBQVEsYUFBYSxPQUFPLEtBQUssU0FBUyxlQUFlLFNBQVMsR0FBRztHQUMvRSxJQUFJLGdCQUFnQixRQUFRLEdBQUc7Ozs7O0dBSy9CLE1BQU0scUJBQXFCLE9BQU8sU0FBUyxRQUFRLElBQUksZ0JBQWdCLEtBQUssR0FBRztHQUMvRSxLQUFLLGNBQWMsS0FBSyxRQUFRLGdCQUFnQjtHQUNoRCxJQUFJLGdCQUFnQjtHQUNwQixJQUFJLDhCQUE4QixZQUFZLElBQUk7R0FDbEQsTUFBTSw0QkFBNEIsZ0JBQWdCO0lBQ2pELGlCQUFpQjtJQUNqQixNQUFNLE1BQU0sWUFBWSxJQUFJO0lBQzVCLE1BQU0sZUFBZSxNQUFNLCtCQUErQixNQUFNLGdCQUFnQjtJQUNoRiw4QkFBOEI7SUFDOUIsSUFBSSxjQUFjO0lBQ2xCLElBQUksS0FBSyxRQUFRLGVBQWUsS0FBSyxRQUFRLGtCQUFrQixLQUFLLGNBQWMsS0FBSyxRQUFRLFNBQVMsS0FBSztJQUM3RyxLQUFLLFFBQVEsb0JBQW9CLEtBQUssT0FBTztJQUM3QyxLQUFLLFFBQVEsWUFBWSxLQUFLLFNBQVM7S0FDdEMsUUFBUTtLQUNSLE9BQU87SUFDUixDQUFDO0dBQ0Y7R0FDQSxNQUFNLGlDQUFpQztJQUN0QyxrQkFBa0IsT0FBTztHQUMxQjtHQUNBLE1BQU0sMkJBQTJCLFlBQVk7SUFDNUMsYUFBYTtJQUNiLElBQUksZ0JBQWdCLFFBQVEsR0FBRztJQUMvQixJQUFJLGNBQWM7SUFDbEIsS0FBSyxjQUFjLEtBQUssUUFBUSxJQUFJO0lBQ3BDLEtBQUssUUFBUSxRQUFRLEtBQUssU0FBUztLQUNsQyxRQUFRO0tBQ1IsT0FBTztJQUNSLENBQUM7SUFDRCxLQUFLLFFBQVEsV0FBVyxLQUFLLFNBQVM7S0FDckMsUUFBUTtLQUNSLE9BQU87SUFDUixDQUFDO0dBQ0Y7R0FDQSxJQUFJLFNBQVMsUUFBUSxNQUFNLHlCQUF5QjtRQUMvQztJQUNKLE1BQU0sU0FBUyxTQUFTLEtBQUssVUFBVTtJQUN2QyxPQUFPLE1BQU07S0FDWixJQUFJLHVCQUF1QixPQUFPLFNBQVM7S0FDM0MsSUFBSTtNQUNILE1BQU0sRUFBRSxPQUFPLFNBQVMsTUFBTSxPQUFPLEtBQUs7TUFDMUMsSUFBSSxNQUFNO09BQ1QseUJBQXlCO09BQ3pCO01BQ0Q7TUFDQSx5QkFBeUIsTUFBTSxVQUFVO01BQ3pDLEtBQUssaUJBQWlCLGtCQUFrQixLQUFLLGdCQUFnQixLQUFLO0tBQ25FLFFBQVE7TUFDUCx5QkFBeUI7S0FDMUI7SUFDRDtHQUNEO0VBQ0Q7RUFDQSxNQUFNLENBQUMsZUFBZSxpQkFBaUIsTUFBTSxZQUFZO0dBQ3hELE9BQU8sS0FBSyxnQkFBZ0IsUUFBUTtFQUNyQyxDQUFDO0VBQ0QsSUFBSSxlQUFlO0VBQ25CLGdCQUFnQixhQUFhO0VBQzdCLElBQUksS0FBSyxRQUFRLFNBQVMsaUJBQWlCO0dBQzFDLElBQUksS0FBSyxRQUFRLGVBQWUsS0FBSyxRQUFRLE1BQU07SUFDbEQsV0FBVztJQUNYLHVCQUF1QixNQUFNO0dBQzlCO0VBQ0QsR0FBRyxLQUFLLFFBQVEsT0FBTztFQUN2QixLQUFLLFFBQVEsb0JBQW9CLElBQUksTUFBTSxLQUFLLFFBQVEsbUJBQW1CLEVBQUUsUUFBUSxHQUFHLElBQUksU0FBUztHQUNwRyxLQUFLLE9BQU8sUUFBUSxxQkFBcUIsS0FBSyxFQUFFO0dBQ2hELElBQUksS0FBSyxRQUFRLGFBQWEsS0FBSyxRQUFRLGtCQUFrQjtJQUM1RCxLQUFLLE9BQU8sUUFBUSwwQ0FBMEM7SUFDOUQsT0FBTztHQUNSO0dBQ0EsTUFBTSxjQUFjLGNBQWMsUUFBUSxJQUFJLEtBQUssRUFBRTtHQUNyRCxLQUFLLE9BQU8sUUFBUSxzQ0FBc0MsS0FBSyxJQUFJLFdBQVc7R0FDOUUsT0FBTztFQUNSLEVBQUUsQ0FBQztFQUNILEtBQUssUUFBUSx3QkFBd0IsSUFBSSxNQUFNLEtBQUssUUFBUSx1QkFBdUIsRUFBRSxhQUFhO0dBQ2pHLEtBQUssT0FBTyxRQUFRLHVCQUF1QjtHQUMzQyxJQUFJLEtBQUssUUFBUSxhQUFhLEtBQUssUUFBUSxrQkFBa0I7SUFDNUQsS0FBSyxPQUFPLFFBQVEsa0RBQWtEO0lBQ3RFLE9BQU87R0FDUjtHQUNBLE1BQU0sYUFBYSxNQUFNLEtBQUssY0FBYyxPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUMsWUFBWSxpQkFBaUI7SUFDdkYsT0FBTyxHQUFHLFdBQVcsSUFBSTtHQUMxQixDQUFDLENBQUMsQ0FBQyxLQUFLLE1BQU07R0FDZCxLQUFLLE9BQU8sUUFBUSxvQ0FBb0MsVUFBVTtHQUNsRSxPQUFPO0VBQ1IsRUFBRSxDQUFDO0NBQ0o7Q0FDQSx1QkFBdUI7RUFDdEIsT0FBTyxhQUFhLEtBQUssY0FBYztDQUN4QztDQUNBLElBQUksV0FBVztFQUNkLEtBQUssT0FBTyxRQUFRLGtDQUFrQyxLQUFLLFFBQVEsWUFBWTtFQUMvRSxJQUFJLEtBQUssUUFBUSxlQUFlLEtBQUssUUFBUSxNQUFNLE9BQU87RUFDMUQsUUFBUSxLQUFLLFFBQVEsY0FBckI7R0FDQyxLQUFLLFFBQVE7SUFDWixNQUFNLGVBQWUsVUFBVSxLQUFLLHFCQUFxQixDQUFDO0lBQzFELEtBQUssT0FBTyxRQUFRLDBCQUEwQixZQUFZO0lBQzFELE9BQU87R0FDUjtHQUNBLEtBQUssZUFBZTtJQUNuQixNQUFNLGNBQWMsY0FBYyxLQUFLLGNBQWM7SUFDckQsS0FBSyxPQUFPLFFBQVEsaUNBQWlDLFdBQVc7SUFDaEUsT0FBTztHQUNSO0dBQ0EsS0FBSyxRQUFRO0lBQ1osTUFBTSxXQUFXLEtBQUssUUFBUSxrQkFBa0IsY0FBYyxLQUFLO0lBQ25FLE1BQU0sZUFBZSxJQUFJLEtBQUssQ0FBQyxLQUFLLHFCQUFxQixDQUFDLEdBQUcsRUFBRSxNQUFNLFNBQVMsQ0FBQztJQUMvRSxLQUFLLE9BQU8sUUFBUSwwQ0FBMEMsY0FBYyxRQUFRO0lBQ3BGLE9BQU87R0FDUjtHQUNBLFNBQVM7SUFDUixNQUFNLGVBQWUsS0FBSyxxQkFBcUI7SUFDL0MsS0FBSyxPQUFPLFFBQVEsMENBQTBDLEtBQUssUUFBUSxjQUFjLFlBQVk7SUFDckcsT0FBTztHQUNSO0VBQ0Q7Q0FDRDtDQUNBLElBQUksZUFBZTs7Ozs7O0VBTWxCLFVBQVUsS0FBSyxRQUFRLGlCQUFpQixNQUFNLEtBQUssUUFBUSxpQkFBaUIsUUFBUSxvREFBb0Q7RUFDeEksSUFBSSxLQUFLLFFBQVEsZUFBZSxLQUFLLFFBQVEsV0FBVyxLQUFLLFFBQVEsZUFBZSxLQUFLLFFBQVEsTUFBTSxPQUFPO0VBQzlHLE1BQU0sZUFBZSxLQUFLLHFCQUFxQjtFQUMvQyxLQUFLLE9BQU8sUUFBUSwyQkFBMkIsWUFBWTtFQUMzRCxPQUFPO0NBQ1I7Q0FDQSxJQUFJLGNBQWM7RUFDakIsVUFBVSxLQUFLLFFBQVEsaUJBQWlCLE1BQU0sS0FBSyxRQUFRLGlCQUFpQixZQUFZLG9EQUFvRDtFQUM1SSxJQUFJLEtBQUssUUFBUSxlQUFlLEtBQUssUUFBUSxNQUFNLE9BQU87RUFDMUQsTUFBTSxjQUFjLEtBQUssUUFBUSxrQkFBa0IsY0FBYyxLQUFLO0VBQ3RFLElBQUksT0FBTyxjQUFjLGFBQWE7R0FDckMsUUFBUSxLQUFLLHdMQUF3TDtHQUNyTSxPQUFPO0VBQ1I7RUFDQSxJQUFJLHlCQUF5QixXQUFXLEdBQUcsT0FBTyxJQUFJLFVBQVUsQ0FBQyxDQUFDLGdCQUFnQixLQUFLLHFCQUFxQixHQUFHLFdBQVc7RUFDMUgsT0FBTztDQUNSO0NBQ0EsTUFBTSxnQkFBZ0IsVUFBVTtFQUMvQixNQUFNLG1CQUFtQixTQUFTLFFBQVEsSUFBSSxVQUFVO0VBQ3hELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxjQUFjLG1CQUFtQixTQUFTLE1BQU0sR0FBRyxPQUFPO0VBQ3BGLEtBQUs7RUFDTCxJQUFJLEtBQUssZ0JBQWdCLGVBQWUsTUFBTSxJQUFJLE1BQU0sb0JBQW9CO0VBQzVFLE1BQU0sY0FBYyxJQUFJLElBQUksa0JBQWtCLFNBQVMsSUFBSTtFQUMzRCxNQUFNLGlCQUFpQixjQUFjLG1CQUFtQixTQUFTLE1BQU0sSUFBSSxLQUFLLFNBQVM7RUFDekYsTUFBTSxtQkFBbUIsTUFBTSxJQUFJLFNBQVMsU0FBUyxXQUFXO0dBQy9ELE1BQU0sVUFBVSxJQUFJLGVBQWU7R0FDbkMsUUFBUSxlQUFlLEtBQUssUUFBUTtHQUNwQyxRQUFRLGlCQUFpQixjQUFjO0lBQ3RDLEtBQUssTUFBTSxJQUFJLElBQUksUUFBUSxXQUFXO0lBQ3RDLFFBQVEsZUFBZSxTQUFTLFFBQVEsUUFBUSxDQUFDO0dBQ2xELENBQUM7R0FDRCxRQUFRLGlCQUFpQixlQUFlO0lBQ3ZDLEtBQUssVUFBVTtJQUNmLHVCQUF1QixJQUFJLE1BQU0seUJBQXlCLENBQUM7R0FDNUQsQ0FBQztHQUNELFFBQVEsS0FBSyxnQkFBZ0IsWUFBWSxJQUFJO0dBQzdDLFFBQVEsS0FBSztFQUNkLENBQUM7RUFDRCxPQUFPLEtBQUssZ0JBQWdCLGdCQUFnQjtDQUM3QztDQUNBLFVBQVUsT0FBTzs7Ozs7RUFLaEIsS0FBSyxxQkFBcUI7RUFDMUIsS0FBSyxPQUFPLFFBQVEsMEJBQTBCO0VBQzlDLEtBQUssY0FBYyxLQUFLLFFBQVEsSUFBSTtFQUNwQyxLQUFLLFFBQVEsU0FBUyxLQUFLLE9BQU87RUFDbEMsS0FBSyxRQUFRLFdBQVcsS0FBSyxPQUFPO0NBQ3JDOzs7O0NBSUEsY0FBYyxnQkFBZ0IsK0JBQStCLE1BQU07RUFDbEUsS0FBSyxPQUFPLFFBQVEsMkJBQTJCLEtBQUssUUFBUSxZQUFZLGNBQWM7RUFDdEYsSUFBSSxLQUFLLFFBQVEsZUFBZSxnQkFBZ0I7R0FDL0MsS0FBSyxPQUFPLFFBQVEsK0NBQStDO0dBQ25FO0VBQ0Q7RUFDQSxPQUFPLEtBQUssU0FBUyxjQUFjLGNBQWM7RUFDakQsS0FBSyxPQUFPLFFBQVEseUJBQXlCLGNBQWM7RUFDM0QsSUFBSSxDQUFDLDhCQUE4QjtFQUNuQyxJQUFJLG1CQUFtQixLQUFLLFFBQVEsUUFBUTtHQUMzQyxLQUFLLE9BQU8sUUFBUSwwQ0FBMEM7R0FDOUQsS0FBSyxRQUFRLG9CQUFvQixLQUFLLE9BQU87RUFDOUM7Q0FDRDs7OztDQUlBLFFBQVEsV0FBVyxRQUFRLFNBQVM7RUFDbkMsTUFBTSxXQUFXLE9BQU8sS0FBSztFQUM3QixNQUFNLFFBQVEsWUFBWSxRQUFRLFdBQVcsT0FBTztFQUNwRCxLQUFLLE9BQU8sUUFBUSxrQkFBa0IsV0FBVyxXQUFXLEVBQUU7RUFDOUQsSUFBSSxPQUFPLGFBQWEsWUFBWTtHQUNuQyxLQUFLLE9BQU8sUUFBUSw4Q0FBOEMsU0FBUztHQUMzRSxTQUFTLEtBQUssUUFBUSxLQUFLO0VBQzVCO0VBQ0EsTUFBTSxTQUFTLGtCQUFrQix1QkFBdUIsS0FBSyxlQUFlLEtBQUs7RUFDakYsS0FBSyxNQUFNLENBQUMscUJBQXFCLGNBQWMsUUFBUSxJQUFJLHdCQUF3QixXQUFXO0dBQzdGLEtBQUssT0FBTyxRQUFRLHFEQUFxRCxVQUFVLFFBQVEsU0FBUztHQUNwRyxVQUFVLFNBQVMsYUFBYSxTQUFTLEtBQUssUUFBUSxLQUFLLENBQUM7RUFDN0Q7Q0FDRDs7OztDQUlBLGtCQUFrQixNQUFNO0VBQ3ZCLEtBQUssT0FBTyxRQUFRLDhDQUE4QztFQUNsRSxNQUFNLGVBQWUsZ0JBQWdCLFdBQVcsS0FBSyxnQkFBZ0IsWUFBWTtFQUNqRixNQUFNLGVBQWUsSUFBSSxhQUFhLEtBQUssSUFBSSxNQUFNO0dBQ3BELFFBQVEsS0FBSztHQUNiLFNBQVMsS0FBSzs7OztHQUlkLGFBQWEsS0FBSyxRQUFRLGtCQUFrQixZQUFZO0dBQ3hELE1BQU07RUFDUCxDQUFDO0VBQ0QsTUFBTSxVQUFVLGFBQWE7RUFDN0IsT0FBTyxjQUFjLFdBQVcsWUFBWSxTQUFTLEVBQUUsYUFBYSxDQUFDLFlBQVksT0FBTyxXQUFXO0dBQ2xHLE1BQU0sU0FBUyxPQUFPO0dBQ3RCLFFBQVEsWUFBUjtJQUNDLEtBQUs7SUFDTCxLQUFLLE9BQU87S0FDWCxNQUFNLENBQUMsWUFBWSxlQUFlOzs7Ozs7O0tBT2xDLElBQUksUUFBUSxJQUFJLFVBQVUsR0FBRyxLQUFLLFFBQVEsaUJBQWlCLFlBQVksV0FBVztLQUNsRjtJQUNEO0lBQ0EsS0FBSyxVQUFVO0tBQ2QsTUFBTSxDQUFDLGNBQWM7S0FDckIsUUFBUSxLQUFLLG9DQUFvQyxXQUFXLHFEQUFxRCxhQUFhLE9BQU8sR0FBRyxhQUFhLElBQUkscURBQXFEO0tBQzlNO0lBQ0Q7R0FDRDtHQUNBLE9BQU87RUFDUixFQUFFLENBQUMsQ0FBQztFQUNKLEtBQUssT0FBTyxRQUFRLDZDQUE2QyxZQUFZO0VBQzdFLE9BQU87Q0FDUjtBQUNEO0FBQ0EsU0FBUyxjQUFjLEtBQUs7Ozs7Ozs7O0NBUTNCLElBQUksT0FBTyxhQUFhLGFBQWEsT0FBTyxJQUFJLElBQUksR0FBRztDQUN2RCxPQUFPLElBQUksSUFBSSxJQUFJLFNBQVMsR0FBRyxTQUFTLElBQUk7QUFDN0M7QUFDQSxTQUFTLE9BQU8sUUFBUSxVQUFVLE9BQU87Q0FDeEMsUUFBUSxlQUFlLFFBQVEsVUFBVTtFQUN4QyxVQUFVO0VBQ1YsWUFBWTtFQUNaO0NBQ0QsQ0FBQztBQUNGOzs7Ozs7QUFRQSxTQUFTLDBCQUEwQixFQUFFLFNBQVMsVUFBVTtDQUN2RCxPQUFPLElBQUksTUFBTSxXQUFXLGdCQUFnQixFQUFFLFVBQVUsUUFBUSxNQUFNLFdBQVc7RUFDaEYsT0FBTyxRQUFRLGdDQUFnQztFQUMvQyxNQUFNLGtCQUFrQixRQUFRLFVBQVUsUUFBUSxNQUFNLFNBQVM7Ozs7Ozs7O0VBUWpFLE1BQU0sdUJBQXVCLE9BQU8sMEJBQTBCLE9BQU8sU0FBUztFQUM5RSxLQUFLLE1BQU0sZ0JBQWdCLHNCQUFzQixRQUFRLGVBQWUsaUJBQWlCLGNBQWMscUJBQXFCLGFBQWE7RUFDekksTUFBTSx1QkFBdUIsSUFBSSx5QkFBeUIsaUJBQWlCLE1BQU07RUFDakYscUJBQXFCLFlBQVksZUFBZSxFQUFFLFNBQVMsYUFBYTtHQUN2RSxNQUFNLGFBQWEsSUFBSSxrQkFBa0IsU0FBUztJQUNqRCxtQkFBbUI7S0FDbEIsS0FBSyxPQUFPLFFBQVEsMERBQTBEO0lBQy9FO0lBQ0EsYUFBYSxPQUFPLGFBQWE7S0FDaEMsTUFBTSxLQUFLLFlBQVksUUFBUTtJQUNoQztJQUNBLFlBQVksV0FBVztLQUN0QixLQUFLLE9BQU8sUUFBUSxzQkFBc0IsRUFBRSxPQUFPLE9BQU8sQ0FBQztLQUMzRCxJQUFJLGtCQUFrQixPQUFPLEtBQUssVUFBVSxNQUFNO0lBQ25EO0dBQ0QsR0FBRztJQUNGO0lBQ0E7R0FDRCxDQUFDO0dBQ0QsS0FBSyxPQUFPLFFBQVEsMEJBQTBCO0dBQzlDLEtBQUssT0FBTyxRQUFRLHdEQUF3RCxRQUFRLGNBQWMsU0FBUyxDQUFDO0dBQzVHLE1BQU0sY0FBYztJQUNuQixXQUFXLEtBQUs7SUFDaEI7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNELENBQUM7RUFDRjtFQUNBLHFCQUFxQixhQUFhLGVBQWUsRUFBRSxVQUFVLGNBQWMsU0FBUyxhQUFhO0dBQ2hHLEtBQUssT0FBTyxRQUFRLHlEQUF5RCxRQUFRLGNBQWMsVUFBVSxDQUFDO0dBQzlHLE1BQU0sUUFBUSxjQUFjLElBQUksa0JBQWtCO0lBQ2pELFdBQVcsS0FBSztJQUNoQjtJQUNBO0lBQ0E7SUFDQTtHQUNELENBQUMsQ0FBQztFQUNIO0VBQ0EsT0FBTyxxQkFBcUI7Q0FDN0IsRUFBRSxDQUFDO0FBQ0o7QUFHQSxJQUFNQyxXQUFTLGFBQWEsS0FBSztBQUNqQyxJQUFJLDRCQUE0QixjQUFjLFlBQVk7Q0FDekQ7RUFDQyxLQUFLLFNBQVMsT0FBTyxJQUFJLGlCQUFpQjtDQUMzQztDQUNBLFlBQVk7RUFDWCxPQUFPLHNCQUFzQixnQkFBZ0I7Q0FDOUM7Q0FDQSxRQUFRO0VBQ1AsU0FBTyxRQUFRLGdDQUFnQztFQUMvQyxLQUFLLGNBQWMsS0FBSyxnQkFBZ0IsV0FBVyxZQUFZLHdCQUF3QjtHQUN0RixPQUFPLDBCQUEwQjtJQUNoQyxTQUFTLEtBQUs7SUFDZCxRQUFBO0dBQ0QsQ0FBQztFQUNGLENBQUMsQ0FBQztFQUNGLFNBQU8sUUFBUSxzQ0FBc0MsV0FBVyxlQUFlLElBQUk7Q0FDcEY7QUFDRDs7QUN2ekJBLFNBQVMsbUJBQW1CLE9BQU87Q0FDbEMsT0FBTyxPQUFPLHVCQUF1QixJQUFJLFVBQVUsaUJBQWlCLEdBQUcsRUFBRSxNQUFNLENBQUM7QUFDakY7QUFHQSxJQUFNLHVCQUF1QjtDQUM1QjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Q7QUFDQSxJQUFNLGlCQUFpQixPQUFPLGdCQUFnQjs7OztBQUk5QyxlQUFlLG9CQUFvQixTQUFTLFVBQVU7Q0FDckQsSUFBSSxTQUFTLFdBQVcsT0FBTyxRQUFRLFFBQVEsTUFBTSxPQUFPLFFBQVEsT0FBTyxtQkFBbUIsQ0FBQztDQUMvRixNQUFNLGFBQWEsSUFBSSxJQUFJLFFBQVEsR0FBRztDQUN0QyxJQUFJO0NBQ0osSUFBSTtFQUNILGNBQWMsSUFBSSxJQUFJLFNBQVMsUUFBUSxJQUFJLFVBQVUsR0FBRyxRQUFRLEdBQUc7Q0FDcEUsU0FBUyxPQUFPO0VBQ2YsT0FBTyxRQUFRLE9BQU8sbUJBQW1CLEtBQUssQ0FBQztDQUNoRDtDQUNBLElBQUksRUFBRSxZQUFZLGFBQWEsV0FBVyxZQUFZLGFBQWEsV0FBVyxPQUFPLFFBQVEsT0FBTyxtQkFBbUIscUNBQXFDLENBQUM7Q0FDN0osSUFBSSxRQUFRLElBQUksU0FBUyxjQUFjLElBQUksSUFBSSxPQUFPLFFBQVEsT0FBTyxtQkFBbUIseUJBQXlCLENBQUM7Q0FDbEgsT0FBTyxlQUFlLFNBQVMsZ0JBQWdCLEVBQUUsUUFBUSxRQUFRLElBQUksU0FBUyxjQUFjLEtBQUssS0FBSyxFQUFFLENBQUM7Q0FDekcsSUFBSSxRQUFRLFNBQVMsV0FBVyxZQUFZLFlBQVksWUFBWSxhQUFhLENBQUMsV0FBVyxZQUFZLFdBQVcsR0FBRyxPQUFPLFFBQVEsT0FBTyxtQkFBbUIsb0RBQW9ELENBQUM7Q0FDck4sTUFBTSxjQUFjLENBQUM7Q0FDckIsSUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsU0FBUyxTQUFTLE1BQU0sS0FBSyxRQUFRLFdBQVcsVUFBVSxTQUFTLFdBQVcsT0FBTyxDQUFDLENBQUMsUUFBUSxLQUFLLENBQUMsQ0FBQyxTQUFTLFFBQVEsTUFBTSxHQUFHO0VBQzlJLFlBQVksU0FBUztFQUNyQixZQUFZLE9BQU87RUFDbkIscUJBQXFCLFNBQVMsZUFBZTtHQUM1QyxRQUFRLFFBQVEsT0FBTyxVQUFVO0VBQ2xDLENBQUM7Q0FDRjtDQUNBLElBQUksQ0FBQyxXQUFXLFlBQVksV0FBVyxHQUFHO0VBQ3pDLFFBQVEsUUFBUSxPQUFPLGVBQWU7RUFDdEMsUUFBUSxRQUFRLE9BQU8scUJBQXFCO0VBQzVDLFFBQVEsUUFBUSxPQUFPLFFBQVE7RUFDL0IsUUFBUSxRQUFRLE9BQU8sTUFBTTtDQUM5Qjs7Ozs7O0NBTUEsWUFBWSxVQUFVLFFBQVE7Q0FDOUIsTUFBTSxnQkFBZ0IsTUFBTSxNQUFNLElBQUksUUFBUSxhQUFhLFdBQVcsQ0FBQztDQUN2RSxPQUFPLGVBQWUsZUFBZSxjQUFjO0VBQ2xELE9BQU87RUFDUCxjQUFjO0NBQ2YsQ0FBQztDQUNELE9BQU87QUFDUjs7OztBQUlBLFNBQVMsV0FBVyxNQUFNLE9BQU87Q0FDaEMsSUFBSSxLQUFLLFdBQVcsTUFBTSxVQUFVLEtBQUssV0FBVyxRQUFRLE9BQU87Q0FDbkUsSUFBSSxLQUFLLGFBQWEsTUFBTSxZQUFZLEtBQUssYUFBYSxNQUFNLFlBQVksS0FBSyxTQUFTLE1BQU0sTUFBTSxPQUFPO0NBQzdHLE9BQU87QUFDUjtBQUdBLElBQUksNEJBQTRCLGNBQWMsZ0JBQWdCO0NBQzdELGNBQWM7RUFDYixRQUFRLEtBQUssMEZBQTBGO0VBQ3ZHLE1BQU0sRUFBRSxVQUFVLE9BQU8sWUFBWTtHQUNwQyxXQUFXLFFBQVEsS0FBSztFQUN6QixFQUFFLENBQUM7Q0FDSjtBQUNEO0FBR0EsSUFBSSxpQkFBaUIsY0FBYyxnQkFBZ0I7Q0FDbEQsWUFBWSxrQkFBa0IsR0FBRyxZQUFZO0VBQzVDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsVUFBVTtFQUN2QixNQUFNLFdBQVcsQ0FBQyxNQUFNLFVBQVUsR0FBRyxnQkFBZ0IsQ0FBQyxDQUFDLFFBQVEsVUFBVSxjQUFjLFNBQVMsWUFBWSxTQUFTLENBQUM7RUFDdEgsT0FBTyxlQUFlLE1BQU0sWUFBWSxFQUFFLE1BQU07R0FDL0MsT0FBTztFQUNSLEVBQUUsQ0FBQztDQUNKO0FBQ0Q7QUFDQSxTQUFTLHFCQUFxQixpQkFBaUI7Q0FDOUMsT0FBTyxnQkFBZ0IsWUFBWSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxLQUFLLFdBQVcsT0FBTyxLQUFLLENBQUM7QUFDOUU7QUFDQSxTQUFTLDBCQUEwQixpQkFBaUI7Q0FDbkQsT0FBTyxJQUFJLGVBQWUscUJBQXFCLGVBQWUsQ0FBQyxDQUFDLGFBQWEsY0FBYyxXQUFXO0VBQ3JHLElBQUksV0FBVyxVQUFVLFdBQVcsVUFBVSxPQUFPLGFBQWEsT0FBTyxJQUFJLG9CQUFvQixNQUFNLENBQUM7T0FDbkcsSUFBSSxXQUFXLFdBQVcsT0FBTyxhQUFhLE9BQU8sSUFBSSxvQkFBb0IsU0FBUyxDQUFDO09BQ3ZGLElBQUksV0FBVyxNQUFNLE9BQU8sYUFBYSxPQUFPLElBQUksMEJBQTBCLENBQUM7T0FDL0UsYUFBYSxTQUFTO0VBQzNCLE9BQU87Q0FDUixHQUFHLENBQUMsQ0FBQyxDQUFDO0FBQ1A7Ozs7O0FBS0EsU0FBUyxxQkFBcUIsVUFBVTtDQUN2QyxJQUFJLFNBQVMsU0FBUyxNQUFNLE9BQU87Q0FDbkMsTUFBTSxrQkFBa0IsU0FBUyxRQUFRLElBQUksa0JBQWtCO0NBQy9ELE9BQU8sb0JBQW9CLFFBQVEsZ0JBQWdCLEtBQUssTUFBTTtBQUMvRDs7OztBQUlBLFNBQVMsbUJBQW1CLFVBQVU7Q0FDckMsVUFBVSxxQkFBcUIsUUFBUSxHQUFHLDhHQUE4RztDQUN4SixNQUFNLHNCQUFzQiwwQkFBMEIsU0FBUyxRQUFRLElBQUksa0JBQWtCLENBQUM7Q0FDOUYsU0FBUyxLQUFLLE9BQU8sb0JBQW9CLFFBQVE7Q0FDakQsT0FBTyxvQkFBb0I7QUFDNUI7O0FBSUEsU0FBUyxjQUFjLFVBQVU7Q0FDaEMsTUFBTSxRQUFRLGNBQWMsTUFBTSxRQUFRO0NBQzFDLElBQUksQ0FBQyxTQUFTLFFBQVEsQ0FBQyxNQUFNLE1BQU0sT0FBTyxDQUFDLFVBQVUsS0FBSztDQUMxRCxNQUFNLFdBQVcsYUFBYSxLQUFLO0NBQ25DLE9BQU8sQ0FBQyxhQUFhLFVBQVUsU0FBUyxNQUFNLENBQUMsQ0FBQyxVQUFVLFNBQVMsUUFBUTtBQUM1RTtBQUNBLFNBQVMsYUFBYSxVQUFVLFVBQVU7Q0FDekMsTUFBTSxPQUFPLFNBQVM7Q0FDdEIsTUFBTSxTQUFTLEtBQUssVUFBVTtDQUM5QixNQUFNLFVBQVUsV0FBVztFQUMxQixPQUFPLEtBQUssU0FBUyxPQUFPLE9BQU8sTUFBTSxJQUFJLEtBQUssT0FBTyxNQUFNO0NBQ2hFO0NBQ0EsTUFBTSxTQUFTLElBQUksZUFBZTtFQUNqQyxNQUFNLEtBQUssWUFBWTtHQUN0QixJQUFJO0lBQ0gsTUFBTSxFQUFFLE1BQU0sVUFBVSxNQUFNLE9BQU8sS0FBSztJQUMxQyxJQUFJLE1BQU07S0FDVCxXQUFXLE1BQU07S0FDakIsT0FBTyxZQUFZO0tBQ25CO0lBQ0Q7SUFDQSxXQUFXLFFBQVEsS0FBSztHQUN6QixTQUFTLE9BQU87SUFDZixXQUFXLE1BQU0sS0FBSztJQUN0QixPQUFPLFlBQVk7R0FDcEI7RUFDRDtFQUNBLE1BQU0sT0FBTyxRQUFRO0dBQ3BCLElBQUk7SUFDSCxNQUFNLGVBQWUsT0FBTyxNQUFNO0lBQ2xDLElBQUksVUFBVSxNQUFNLFFBQVEsSUFBSSxDQUFDLGNBQWMsU0FBUyxNQUFNLENBQUMsQ0FBQztTQUMzRCxhQUFhLFlBQVksQ0FBQyxDQUFDO0dBQ2pDLFVBQVU7SUFDVCxPQUFPLFlBQVk7R0FDcEI7RUFDRDtDQUNELEdBQUcsRUFBRSxlQUFlLEVBQUUsQ0FBQztDQUN2QixNQUFNLGtCQUFrQixJQUFJLGNBQWMsUUFBUSxRQUFRO0NBQzFELGVBQWUsU0FBUyxTQUFTLGdCQUFnQixPQUFPO0NBQ3hELE9BQU8saUJBQWlCLGlCQUFpQjtFQUN4QyxNQUFNLEVBQUUsT0FBTyxTQUFTLEtBQUs7RUFDN0IsWUFBWSxFQUFFLE9BQU8sU0FBUyxXQUFXO0NBQzFDLENBQUM7Q0FDRCxPQUFPO0VBQ04sVUFBVTtFQUNWO0NBQ0Q7QUFDRDtBQUdBLElBQU0sU0FBUyxhQUFhLE9BQU87Ozs7QUFJbkMsSUFBSSxtQkFBbUIsY0FBYyxZQUFZO0NBQ2hEO0VBQ0MsS0FBSyxTQUFTLE9BQU8sSUFBSSxtQkFBbUI7Q0FDN0M7Q0FDQSxZQUFZO0VBQ1gsT0FBTyxzQkFBc0IsT0FBTztDQUNyQztDQUNBLE1BQU0sUUFBUTtFQUNiLE9BQU8sUUFBUSwwQkFBMEI7RUFDekMsS0FBSyxjQUFjLEtBQUssZ0JBQWdCLFdBQVcsWUFBWSxVQUFVLGNBQWM7R0FDdEYsT0FBTyxPQUFPLE9BQU8sU0FBUztJQUM3QixNQUFNLFlBQVksZ0JBQWdCOzs7Ozs7O0lBT2xDLE1BQU0sZ0JBQWdCLE9BQU8sVUFBVSxZQUFZLE9BQU8sYUFBYSxlQUFlLENBQUMsSUFBSSxTQUFTLEtBQUssSUFBSSxJQUFJLElBQUksT0FBTyxTQUFTLElBQUksSUFBSTtJQUM3SSxNQUFNLFVBQVUsSUFBSSxRQUFRLGVBQWUsSUFBSTtJQUMvQyxNQUFNLGtCQUFrQixRQUFRLGNBQWM7SUFDOUMsTUFBTSxhQUFhLElBQUksa0JBQWtCLFNBQVM7S0FDakQsYUFBYSxZQUFZO01BQ3hCLE9BQU8sUUFBUSwwQkFBMEI7Ozs7Ozs7Ozs7OztNQVl6QyxNQUFNLGVBQWUsUUFBUSxNQUFNO01BQ25DLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixNQUFNLFlBQVksVUFBVSxZQUFZLENBQUM7TUFDbkYsSUFBSSxlQUFlLE9BQU8sZ0JBQWdCLE9BQU8sYUFBYTtNQUM5RCxPQUFPLFFBQVEsK0JBQStCLGdCQUFnQjtNQUM5RCxJQUFJLEtBQUssUUFBUSxjQUFjLFVBQVUsSUFBSSxHQUFHO09BQy9DLE9BQU8sUUFBUSxpQ0FBaUM7T0FDaEQsTUFBTSxDQUFDLFVBQVUsaUJBQWlCLGNBQWMsZ0JBQWdCO09BQ2hFLE1BQU0sS0FBSyxRQUFRLGNBQWMsSUFBSSxrQkFBa0I7UUFDdEQsV0FBVztRQUNYO1FBQ0E7UUFDQSxVQUFVO1FBQ1YsY0FBYztPQUNmLENBQUMsQ0FBQztPQUNGLGdCQUFnQixRQUFRLFFBQVE7T0FDaEM7TUFDRDtNQUNBLGdCQUFnQixRQUFRLGdCQUFnQjtLQUN6QztLQUNBLGFBQWEsT0FBTyxnQkFBZ0I7TUFDbkMsSUFBSSxnQkFBZ0IsV0FBVyxHQUFHO09BQ2pDLE9BQU8sUUFBUSxzQkFBc0IsRUFBRSxVQUFVLFlBQVksQ0FBQztPQUM5RCxnQkFBZ0IsT0FBTyxtQkFBbUIsV0FBVyxDQUFDO09BQ3REO01BQ0Q7Ozs7Ozs7Ozs7Ozs7TUFhQSxJQUFJO01BQ0osSUFBSSxxQkFBcUIsV0FBVyxHQUFHO09BQ3RDLFdBQVcsSUFBSSxjQUFjLG1CQUFtQixXQUFXLEdBQUc7UUFDN0QsUUFBUSxZQUFZO1FBQ3BCLFlBQVksWUFBWTtRQUN4QixTQUFTLFlBQVk7T0FDdEIsQ0FBQztPQUNELGVBQWUsWUFBWSxTQUFTLFNBQVMsT0FBTztNQUNyRCxPQUFPLFdBQVc7TUFDbEIsY0FBYyxPQUFPLFFBQVEsS0FBSyxRQUFROzs7Ozs7O01BTzFDLElBQUksY0FBYyxtQkFBbUIsU0FBUyxNQUFNLEdBQUc7T0FDdEQsSUFBSSxRQUFRLGFBQWEsU0FBUztRQUNqQyxnQkFBZ0IsT0FBTyxtQkFBbUIscUJBQXFCLENBQUM7UUFDaEU7T0FDRDtPQUNBLElBQUksUUFBUSxhQUFhLFVBQVU7UUFDbEMsb0JBQW9CLFNBQVMsUUFBUSxDQUFDLENBQUMsTUFBTSxhQUFhO1NBQ3pELGdCQUFnQixRQUFRLFFBQVE7UUFDakMsSUFBSSxXQUFXO1NBQ2QsZ0JBQWdCLE9BQU8sTUFBTTtRQUM5QixDQUFDO1FBQ0Q7T0FDRDtNQUNEO01BQ0EsSUFBSSxLQUFLLFFBQVEsY0FBYyxVQUFVLElBQUksR0FBRztPQUMvQyxPQUFPLFFBQVEsaUNBQWlDO09BQ2hELE1BQU0sQ0FBQyxnQkFBZ0IsaUJBQWlCLGNBQWMsUUFBUTtPQUM5RCxNQUFNLEtBQUssUUFBUSxjQUFjLElBQUksa0JBQWtCO1FBQ3RELFdBQVc7UUFDWCxVQUFVO1FBQ1YsY0FBYztRQUNkO1FBQ0E7T0FDRCxDQUFDLENBQUM7T0FDRixnQkFBZ0IsUUFBUSxjQUFjO09BQ3RDO01BQ0Q7TUFDQSxnQkFBZ0IsUUFBUSxRQUFRO0tBQ2pDO0tBQ0EsWUFBWSxXQUFXO01BQ3RCLE9BQU8sUUFBUSxzQkFBc0IsRUFBRSxPQUFPLENBQUM7TUFDL0MsZ0JBQWdCLE9BQU8sTUFBTTtLQUM5QjtJQUNELEdBQUc7S0FDRjtLQUNBO0lBQ0QsQ0FBQztJQUNELE9BQU8sUUFBUSw2QkFBNkI7SUFDNUMsT0FBTyxRQUFRLHdEQUF3RCxLQUFLLFFBQVEsY0FBYyxTQUFTLENBQUM7Ozs7Ozs7OztJQVM1RyxNQUFNLFFBQVEsUUFBUTtJQUN0QixNQUFNLGNBQWM7S0FDbkIsV0FBVztLQUNYO0tBQ0E7S0FDQSxTQUFTLEtBQUs7S0FDZDtLQUNBO0lBQ0QsQ0FBQztJQUNELE9BQU8sZ0JBQWdCO0dBQ3hCO0VBQ0QsQ0FBQyxDQUFDO0VBQ0YsT0FBTyxRQUFRLDRCQUE0QixXQUFXLE1BQU0sSUFBSTtDQUNqRTtBQUNEOzs7Ozs7QUN0VEEsU0FBUyx3QkFBd0I7Q0FDaEMsT0FBTyxPQUFPLGNBQWMsZUFBZSxtQkFBbUIsYUFBYSxPQUFPLGFBQWEsZUFBZSxTQUFTLGFBQWE7QUFDckk7Ozs7OztBQU1BLFNBQVMsaUNBQWlDO0NBQ3pDLElBQUk7RUFDSCxNQUFNLFNBQVMsSUFBSSxlQUFlLEVBQUUsUUFBUSxlQUFlLFdBQVcsTUFBTSxFQUFFLENBQUM7RUFDL0UsSUFBSSxlQUFlLENBQUMsQ0FBQyxNQUFNLFlBQVksUUFBUSxDQUFDLE1BQU0sQ0FBQztFQUN2RCxPQUFPO0NBQ1IsUUFBUTtFQUNQLE9BQU87Q0FDUjtBQUNEO0FBR0EsU0FBUyxlQUFlLFVBQVU7Q0FDakMsT0FBTztFQUNOLFFBQVEsU0FBUztFQUNqQixZQUFZLFNBQVM7RUFDckIsU0FBUyxPQUFPLFlBQVksU0FBUyxRQUFRLFFBQVEsQ0FBQztDQUN2RDtBQUNEOzs7OztBQU9BLFNBQVMscUJBQXFCLFdBQVc7Q0FDeEMsT0FBTyxJQUFJLElBQUksV0FBVyxTQUFTLElBQUksQ0FBQyxDQUFDO0FBQzFDOzs7OztBQU9BLFNBQVMsd0JBQXdCLGNBQWMsbUJBQW1CLFlBQVk7Q0FDN0UsT0FBTztFQUNOLGFBQWE7RUFDYixhQUFhO0VBQ2IsYUFBYTtDQUNkLENBQUMsQ0FBQyxRQUFRLFVBQVU7RUFDbkIsT0FBTyxTQUFTO0NBQ2pCLENBQUMsQ0FBQyxDQUFDLE1BQU0sV0FBVztFQUNuQixPQUFPLFdBQVcsT0FBTyxXQUFXLGlCQUFpQjtDQUN0RCxDQUFDLEtBQUs7QUFDUDs7Ozs7QUFPQSxJQUFNLG9CQUFvQixPQUFPLEtBQUssVUFBVSxDQUFDLEdBQUcsZUFBZTtDQUNsRSxNQUFNLG9CQUFvQixxQkFBcUIsR0FBRztDQUNsRCxNQUFNLG9CQUFvQixNQUFNLFVBQVUsY0FBYyxpQkFBaUIsQ0FBQyxDQUFDLE1BQU0sa0JBQWtCLGNBQWMsUUFBUSxpQkFBaUIsd0JBQXdCLGNBQWMsbUJBQW1CLFVBQVUsQ0FBQyxDQUFDO0NBQy9NLElBQUksQ0FBQyxVQUFVLGNBQWMsY0FBYyxrQkFBa0IsU0FBUyxHQUFHLFNBQVMsT0FBTztDQUN6RixNQUFNLENBQUMsd0JBQXdCO0NBQy9CLElBQUksc0JBQXNCO0VBQ3pCLHFCQUFxQixPQUFPO0VBQzVCLE9BQU8sQ0FBQyx3QkFBd0Isc0JBQXNCLG1CQUFtQixVQUFVLEdBQUcsb0JBQW9CO0NBQzNHO0NBQ0EsTUFBTSxDQUFDLG1CQUFtQixzQkFBc0IsTUFBTUMsUUFBTSxZQUFZO0VBQ3ZFLE1BQU0sZUFBZSxNQUFNLFVBQVUsY0FBYyxTQUFTLEtBQUssT0FBTztFQUN4RSxPQUFPLENBQUMsd0JBQXdCLGNBQWMsbUJBQW1CLFVBQVUsR0FBRyxZQUFZO0NBQzNGLENBQUM7Q0FDRCxJQUFJLG1CQUFtQjtFQUN0QixJQUFJLGtCQUFrQixRQUFRLFNBQVMsT0FBTyxHQUFHO0dBQ2hELE1BQU0sV0FBVyxJQUFJLElBQUksU0FBUyxTQUFTLEtBQUssU0FBUyxJQUFJO0dBQzdELE1BQU0sSUFBSSxNQUFNLFNBQVMsY0FBYztrREFDUSxTQUFTLEtBQUssbUJBQW1CLGtCQUFrQjs7OztvRkFJakIsQ0FBQztFQUNuRjtFQUNBLE1BQU0sSUFBSSxNQUFNLFNBQVMsY0FBYyxnREFBZ0Qsa0JBQWtCLE9BQU8sQ0FBQztDQUNsSDtDQUNBLE9BQU87QUFDUjtBQUdBLElBQU0sMEJBQTBCLHNCQUFzQjtBQUN0RCxJQUFJLGNBQWMsY0FBYyxXQUFXO0NBQzFDO0NBQ0EsWUFBWSxhQUFhO0VBQ3hCLE1BQU0sT0FBTyxZQUFZLEtBQUs7RUFDOUIsTUFBTSxPQUFPLFlBQVksS0FBSzs7Ozs7O0VBTTlCLE1BQU0sTUFBTSxFQUFFLEtBQUssQ0FBQztFQUNwQixLQUFLLGVBQWU7Q0FDckI7Q0FDQSxJQUFJLFFBQVE7RUFDWCxPQUFPLEtBQUssYUFBYTtDQUMxQjs7OztDQUlBLFlBQVksTUFBTSxHQUFHLE1BQU07RUFDMUIsS0FBSyxhQUFhLE1BQU0sRUFBRSxDQUFDLFlBQVk7R0FDdEM7R0FDQSxNQUFNLEtBQUs7RUFDWixHQUFHLEVBQUUsVUFBVSxLQUFLLEdBQUcsQ0FBQztDQUN6QjtBQUNEO0FBQ0EsSUFBSSxnQkFBZ0IsY0FBYyxRQUFRO0NBQ3pDO0NBQ0E7Q0FDQSxZQUFZLFNBQVM7RUFDcEIsTUFBTTtFQUNOLFVBQVUseUJBQXlCLHNGQUFzRjtFQUN6SCxLQUFLLGFBQWEsUUFBUTtFQUMxQixLQUFLLGNBQWMsSUFBSSxnQkFBZ0I7RUFDdkMsVUFBVSxjQUFjLGlCQUFpQixXQUFXLE9BQU8sVUFBVTtHQUNwRSxNQUFNLFNBQVMsTUFBTSxLQUFLLFdBQVc7R0FDckMsSUFBSSxNQUFNLFVBQVUsUUFBUSxNQUFNLFdBQVcsUUFBUTtHQUNyRCxJQUFJLE1BQU0sUUFBUUMsV0FBUyxNQUFNLElBQUksS0FBSyxVQUFVLE1BQU0sTUFBTSxLQUFLLEtBQUssSUFBSSxZQUFZLEtBQUssQ0FBQztFQUNqRyxHQUFHLEVBQUUsUUFBUSxLQUFLLFlBQVksT0FBTyxDQUFDO0NBQ3ZDOzs7OztDQUtBLFlBQVksTUFBTTtFQUNqQixVQUFVLHlCQUF5Qix5TUFBeU07RUFDNU8sS0FBSyxXQUFXLENBQUMsQ0FBQyxNQUFNLFdBQVc7R0FDbEMsT0FBTyxZQUFZLElBQUk7RUFDeEIsQ0FBQztDQUNGOzs7OztDQUtBLFlBQVk7RUFDWCxLQUFLLFlBQVksTUFBTTtFQUN2QixLQUFLLG1CQUFtQjtDQUN6QjtBQUNEOzs7OztBQU9BLFNBQVMsbUJBQW1CLG1CQUFtQjtDQUM5QyxPQUFPLElBQUksYUFBYSxrQkFBa0IsS0FBSyxFQUFFLEdBQUcsa0JBQWtCLENBQUM7QUFDeEU7Ozs7OztBQVFBLFNBQVMsb0JBQW9CLGNBQWM7Q0FDMUMsSUFBSSxDQUFDLFNBQVMsS0FBSyxXQUFXLGFBQWEsS0FBSyxHQUFHLFNBQVMsS0FBSyx1RkFBdUYsYUFBYSxNQUFNOzs7a0ZBRzFGO0FBQ2xGO0FBR0EsU0FBUyx1QkFBdUIsYUFBYSxhQUFhO0NBQ3pELE9BQU8sWUFBWSxlQUFlLFlBQVksY0FBYyxZQUFZLGNBQWMsUUFBUSxZQUFZLGNBQWMsT0FBTyxLQUFLLFVBQVUsWUFBWSxjQUFjLE9BQU8sTUFBTSxLQUFLLFVBQVUsWUFBWSxjQUFjLE9BQU87QUFDdE87QUFHQSxJQUFJLHNCQUFzQixNQUFNLDRCQUE0QixjQUFjO0NBQ3pFLE9BQU87Ozs7O0NBS1AsYUFBYSxLQUFLLFNBQVM7RUFDMUIsSUFBSSxvQkFBb0IsWUFBWSxNQUFNLG9CQUFvQixXQUFXLElBQUksb0JBQW9CLE9BQU87T0FDbkcsSUFBSSx1QkFBdUIsb0JBQW9CLFNBQVMsVUFBVSxPQUFPLEdBQUc7R0FDaEYsTUFBTSxvQkFBb0IsU0FBUyxVQUFVO0dBQzdDLG9CQUFvQixXQUFXLElBQUksb0JBQW9CLE9BQU87RUFDL0Q7RUFDQSxPQUFPLG9CQUFvQjtDQUM1QjtDQUNBOzs7O0NBSUE7Ozs7O0NBS0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLFlBQVksU0FBUztFQUNwQixNQUFNO0VBQ04sVUFBVSxzQkFBc0IsR0FBRyxpSEFBaUg7RUFDcEosS0FBSyxXQUFXO0VBQ2hCLEtBQUssMEJBQTBCLElBQUksSUFBSTtFQUN2QyxLQUFLLG1CQUFtQixRQUFRLGNBQWM7RUFDOUMsS0FBSyxnQkFBZ0IsS0FBSyxpQkFBaUI7RUFDM0MsS0FBSyxlQUFlO0VBQ3BCLEtBQUssV0FBVyxJQUFJLGNBQWMsRUFBRSxpQkFBaUIsS0FBSyxjQUFjLE1BQU0sQ0FBQyxZQUFZLE1BQU0sRUFBRSxDQUFDO0NBQ3JHO0NBQ0EsTUFBTSxPQUFPLFNBQVM7RUFDckIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssU0FBUyxtQkFBbUI7RUFDakMsS0FBSyxRQUFRLE1BQU07RUFDbkIsS0FBSyxzQkFBc0IsSUFBSSxnQkFBZ0I7RUFDL0MsTUFBTSxDQUFDLFFBQVEsZ0JBQWdCLE1BQU0sS0FBSyxhQUFhO0VBQ3ZELElBQUksT0FBTyxVQUFVLGFBQWE7R0FDakMsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0dBQ3ZDLE1BQU0sb0JBQW9CLFFBQVEsY0FBYztHQUNoRCxrQkFBa0IsUUFBUSxXQUFXLFdBQVcsTUFBTSxDQUFDO0dBQ3ZELE9BQU8saUJBQWlCLHFCQUFxQjtJQUM1QyxJQUFJLE9BQU8sVUFBVSxhQUFhLGtCQUFrQixRQUFRO0dBQzdELEdBQUcsRUFBRSxRQUFRLFdBQVcsT0FBTyxDQUFDO0dBQ2hDLE1BQU0sa0JBQWtCO0VBQ3pCO0VBQ0EsS0FBSyxTQUFTLFlBQVksZUFBZTtFQUN6QyxNQUFNLDRCQUE0QixRQUFRLGNBQWM7RUFDeEQsS0FBSyxpQkFBaUIsMEJBQTBCO0VBQ2hELEtBQUssU0FBUyxLQUFLLG9CQUFvQixVQUFVO0dBQ2hELDBCQUEwQixRQUFRLE1BQU0sS0FBSyxNQUFNO0VBQ3BELENBQUM7RUFDRCxNQUFNLDBCQUEwQjtFQUNoQyxJQUFJLENBQUMsS0FBSyxVQUFVLE9BQU8sS0FBSyxtQkFBbUI7RUFDbkQsT0FBTztDQUNSO0NBQ0EsTUFBTSxVQUFVOzs7Ozs7O0VBT2YsS0FBSyxxQkFBcUIsTUFBTTtFQUNoQyxLQUFLLHNCQUFzQixLQUFLO0VBQ2hDLE1BQU0sZ0JBQWdCLFFBQVEsY0FBYztFQUM1QyxLQUFLLFNBQVMsS0FBSyx1QkFBdUIsY0FBYyxRQUFRLENBQUM7RUFDakUsS0FBSyxTQUFTLFlBQVksY0FBYztFQUN4QyxNQUFNLGNBQWM7Ozs7Ozs7RUFPcEIsSUFBSSxDQUFDLEtBQUssVUFBVSxPQUFPLEtBQUssa0JBQWtCO0NBQ25EOzs7Ozs7Q0FNQSxNQUFNLFlBQVk7RUFDakIsSUFBSSxLQUFLLHNCQUFzQixNQUFNO0dBQ3BDLGNBQWMsS0FBSyxrQkFBa0I7R0FDckMsS0FBSyxxQkFBcUIsS0FBSztFQUNoQztFQUNBLEtBQUssUUFBUSxNQUFNO0VBQ25CLEtBQUssU0FBUyxVQUFVO0VBQ3hCLEtBQUsscUJBQXFCLE1BQU07RUFDaEMsS0FBSyxzQkFBc0IsS0FBSztFQUNoQyxJQUFJLEtBQUssaUJBQWlCLGFBQWE7R0FDdEMsTUFBTSxHQUFHLGdCQUFnQixNQUFNLEtBQUs7R0FDcEMsTUFBTSxhQUFhLFdBQVc7RUFDL0I7RUFDQSxJQUFJLG9CQUFvQixhQUFhLE1BQU0sb0JBQW9CLFdBQVcsS0FBSztDQUNoRjtDQUNBLE1BQU0sZUFBZTtFQUNwQixJQUFJLEtBQUssb0JBQW9CLGNBQWMsS0FBSyxrQkFBa0I7RUFDbEUsTUFBTSxZQUFZLEtBQUssU0FBUyxjQUFjO0VBQzlDLE1BQU0sQ0FBQyxRQUFRLGdCQUFnQixNQUFNLGtCQUFrQixXQUFXLEtBQUssU0FBUyxjQUFjLFNBQVMsS0FBSyxTQUFTLGNBQWMsS0FBSyxrQkFBa0I7RUFDMUosSUFBSSxVQUFVLE1BQU07R0FDbkIsTUFBTSx1QkFBdUIsS0FBSyxVQUFVLGFBQWEsU0FBUyxjQUFjOzs7O1FBSTNFLFNBQVMsSUFBSSxTQUFTLGNBQWM7Ozs7MlBBSStNLFdBQVcsU0FBUyxJQUFJO0dBQ2hSLE1BQU0sSUFBSSxNQUFNLG9CQUFvQjtFQUNyQztFQUNBLElBQUksS0FBSyxpQkFBaUIsV0FBVztHQUNwQyxLQUFLLGlCQUFpQixRQUFRLENBQUMsUUFBUSxZQUFZLENBQUM7R0FDcEQsS0FBSyxlQUFlO0VBQ3JCLE9BQU87Ozs7OztHQU1OLEtBQUssbUJBQW1CLFFBQVEsY0FBYztHQUM5QyxLQUFLLGlCQUFpQixRQUFRLENBQUMsUUFBUSxZQUFZLENBQUM7R0FDcEQsS0FBSyxnQkFBZ0IsS0FBSyxpQkFBaUI7RUFDNUM7RUFDQSxLQUFLLFNBQVMsR0FBRyxXQUFXLEtBQUssZUFBZSxLQUFLLElBQUksQ0FBQztFQUMxRCxLQUFLLFNBQVMsR0FBRyxZQUFZLEtBQUssZ0JBQWdCLEtBQUssSUFBSSxDQUFDO0VBQzVELEtBQUssU0FBUyxHQUFHLGlCQUFpQixLQUFLLG9CQUFvQixLQUFLLElBQUksQ0FBQztFQUNyRSxPQUFPLGlCQUFpQixhQUFhLFVBQVU7R0FDOUMsSUFBSSxNQUFNLFdBQVc7R0FDckIsSUFBSSxPQUFPLFVBQVUsYUFBYSxLQUFLLFNBQVMsWUFBWSxjQUFjO0dBQzFFLGNBQWMsS0FBSyxrQkFBa0I7R0FDckMsT0FBTyxZQUFZLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztFQUMvQyxHQUFHLEVBQUUsUUFBUSxLQUFLLHFCQUFxQixPQUFPLENBQUM7RUFDL0MsTUFBTSxLQUFLLHNCQUFzQixDQUFDLENBQUMsT0FBTyxVQUFVO0dBQ25ELFNBQVMsTUFBTSw0SkFBNEo7R0FDM0ssUUFBUSxNQUFNLEtBQUs7RUFDcEIsQ0FBQztFQUNELEtBQUsscUJBQXFCLE9BQU8sa0JBQWtCO0dBQ2xELEtBQUssU0FBUyxZQUFZLG1CQUFtQjtFQUM5QyxHQUFHLEdBQUc7RUFDTixJQUFJLENBQUMsS0FBSyxVQUFVLE9BQU8sb0JBQW9CLFlBQVk7RUFDM0QsT0FBTyxDQUFDLFFBQVEsWUFBWTtDQUM3QjtDQUNBLE1BQU0sZUFBZSxPQUFPO0VBQzNCLE1BQU0sVUFBVSxtQkFBbUIsTUFBTSxJQUFJO0VBQzdDLGVBQWUsTUFBTSxJQUFJLFNBQVMsUUFBUSxNQUFNLENBQUM7RUFDakQsTUFBTSxRQUFRLElBQUksOEJBQThCO0dBQy9DO0dBQ0E7RUFDRCxDQUFDO0VBQ0QsS0FBSyxRQUFRLElBQUksTUFBTSxLQUFLLElBQUksS0FBSztFQUNyQyxNQUFNLEtBQUssTUFBTSxLQUFLO0NBQ3ZCO0NBQ0EsTUFBTSxnQkFBZ0IsT0FBTztFQUM1QixNQUFNLEVBQUUsU0FBUyxVQUFVLHFCQUFxQixNQUFNO0VBQ3RELE1BQU0sUUFBUSxLQUFLLFFBQVEsSUFBSSxRQUFRLEVBQUU7Ozs7Ozs7O0VBUXpDLElBQUksU0FBUyxNQUFNLFNBQVMsUUFBUSxHQUFHO0dBQ3RDLEtBQUssUUFBUSxPQUFPLFFBQVEsRUFBRTtHQUM5QixPQUFPLE9BQU8sbUJBQW1CO0dBQ2pDO0VBQ0Q7RUFDQSxLQUFLLFFBQVEsT0FBTyxRQUFRLEVBQUU7Ozs7O0VBSzlCLElBQUksU0FBUyxNQUFNO0VBQ25CLE1BQU0sZUFBZSxtQkFBbUIsT0FBTztFQUMvQyxNQUFNLGdCQUFnQixTQUFTLFdBQVcsSUFBSSxTQUFTLE1BQU0sSUFBSSxJQUFJOzs7Ozs7O0dBT3BFLGNBQWMsbUJBQW1CLFNBQVMsTUFBTSxJQUFJLFNBQVMsT0FBTztHQUNwRTtJQUNDLEdBQUc7Ozs7OztJQU1ILEtBQUssUUFBUTtHQUNkO0VBQ0Q7RUFDQSxJQUFJO0dBQ0gsTUFBTSxPQUFPLEtBQUssSUFBSSxjQUFjLG1CQUFtQixvQkFBb0IsbUJBQW1CO0lBQzdGLFdBQVcsTUFBTSxLQUFLO0lBQ3RCLFNBQVM7SUFDVCxVQUFVO0lBQ1Y7R0FDRCxDQUFDLENBQUM7RUFDSCxVQUFVO0dBQ1QsTUFBTSxPQUFPLG1CQUFtQjtFQUNqQztDQUNEOzs7Ozs7Ozs7Q0FTQSxvQkFBb0IsT0FBTztFQUMxQixNQUFNLEVBQUUsWUFBWSxNQUFNO0VBQzFCLE1BQU0sUUFBUSxLQUFLLFFBQVEsSUFBSSxRQUFRLEVBQUU7RUFDekMsS0FBSyxRQUFRLE9BQU8sUUFBUSxFQUFFO0VBQzlCLE9BQU8sT0FBTyxtQkFBbUI7Q0FDbEM7Q0FDQSxzQkFBc0IsV0FBVyx5QkFBeUI7RUFDekQsT0FBTyxjQUFjO0NBQ3RCO0NBQ0EsTUFBTSx3QkFBd0I7RUFDN0IsTUFBTSx3QkFBd0IsUUFBUSxjQUFjO0VBQ3BELEtBQUssU0FBUyxZQUFZLHlCQUF5QjtFQUNuRCxLQUFLLFNBQVMsS0FBSyw2QkFBNkIsVUFBVTtHQUN6RCxNQUFNLEVBQUUsVUFBVSxtQkFBbUIsTUFBTTtHQUMzQyxJQUFJLGFBQWEsb0NBQW9DLFNBQVMsS0FBSyw2RkFBNkYsZUFBZTs7Ozs7OzhKQU1wQjtHQUMzSixzQkFBc0IsUUFBUTtFQUMvQixDQUFDO0VBQ0QsT0FBTyxzQkFBc0I7Q0FDOUI7Q0FDQSxNQUFNLHFCQUFxQjtFQUMxQixJQUFJLEtBQUssaUJBQWlCLFlBQVk7RUFDdEMsVUFBVSxLQUFLLGtCQUFrQixNQUFNLHlGQUF5RjtFQUNoSSxNQUFNLFNBQVMsTUFBTSxLQUFLO0VBQzFCLE1BQU0sQ0FBQyxRQUFRLGdCQUFnQixNQUFNLEtBQUs7RUFDMUMsUUFBUSxlQUFlLEtBQUssU0FBUyxjQUFjLGtCQUFrQixLQUFLLG1DQUFtQztFQUM3RyxRQUFRLElBQUksNENBQTRDLG9CQUFvQixvQkFBb0I7RUFDaEcsUUFBUSxJQUFJLHFEQUFxRDtFQUNqRSxRQUFRLElBQUksc0JBQXNCLE9BQU8sU0FBUztFQUNsRCxRQUFRLElBQUksaUJBQWlCLGFBQWEsS0FBSztFQUMvQyxJQUFJLFFBQVEsUUFBUSxJQUFJLHNCQUFzQixPQUFPLElBQUksT0FBTyxTQUFTO0VBQ3pFLFFBQVEsU0FBUztDQUNsQjtDQUNBLG9CQUFvQjtFQUNuQixRQUFRLElBQUksS0FBSyxTQUFTLGNBQWMsbUJBQW1CLEtBQUssbUNBQW1DO0NBQ3BHO0FBQ0Q7QUFDQSxJQUFJLGdDQUFnQyxjQUFjLGlCQUFpQjtDQUNsRTtDQUNBLFlBQVksU0FBUztFQUNwQixNQUFNLEVBQUUsU0FBUyxRQUFRLFFBQVEsQ0FBQztFQUNsQyxLQUFLLFNBQVMsUUFBUTtDQUN2QjtDQUNBLGNBQWM7RUFDYixLQUFLLE9BQU8sWUFBWSxlQUFlLEVBQUUsU0FBUyxFQUFFLFNBQVMsTUFBTSxLQUFLLEtBQUssS0FBSyxRQUFRLE9BQU8sRUFBRSxFQUFFLENBQUM7Q0FDdkc7Q0FDQSxZQUFZLFVBQVU7RUFDckIsSUFBSSxVQUFVLEtBQUssYUFBYSxRQUFRO0NBQ3pDO0NBQ0EsVUFBVSxRQUFRO0VBQ2pCLElBQUksa0JBQWtCLFVBQVUsT0FBTyxLQUFLLFlBQVksTUFBTTtFQUM5RCxTQUFTLEtBQUsscVZBQXFWLEtBQUssS0FBSyxRQUFRLFFBQVEsS0FBSyxLQUFLLFFBQVEsR0FBRztFQUNsWixNQUFNLFFBQVEsa0JBQWtCLFFBQVEsU0FBUyxJQUFJLE1BQU0sUUFBUSxTQUFTLEtBQUssaUJBQWlCO0VBQ2xHLEtBQUssWUFBWSxhQUFhLEtBQUs7R0FDbEMsTUFBTSxNQUFNO0dBQ1osU0FBUyxNQUFNO0dBQ2YsT0FBTyxNQUFNO0VBQ2QsR0FBRztHQUNGLFFBQVE7R0FDUixZQUFZO0VBQ2IsQ0FBQyxDQUFDO0NBQ0g7Q0FDQSxNQUFNLGFBQWEsVUFBVTtFQUM1QixJQUFJO0VBQ0osSUFBSTtFQUNKLE1BQU0sZUFBZSxlQUFlLFFBQVE7RUFDNUMsSUFBSSwrQkFBK0IsR0FBRztHQUNyQyxlQUFlLFNBQVM7R0FDeEIsV0FBVyxTQUFTLFFBQVEsT0FBTyxLQUFLLElBQUksQ0FBQyxTQUFTLElBQUk7RUFDM0QsT0FBTyxlQUFlLFNBQVMsUUFBUSxPQUFPLE9BQU8sTUFBTSxTQUFTLE1BQU0sQ0FBQyxDQUFDLFlBQVk7RUFDeEYsS0FBSyxPQUFPLFlBQVksaUJBQWlCO0dBQ3hDLEdBQUc7R0FDSCxNQUFNO0VBQ1AsR0FBRyxRQUFRO0NBQ1o7QUFDRDtBQUdBLElBQUkscUJBQXFCLGNBQWMsa0JBQWtCOzs7O0NBSXhEO0NBQ0EsY0FBYztFQUNiLE1BQU0sRUFBRSxjQUFjLENBQUMsSUFBSSwwQkFBMEIsR0FBRyxJQUFJLGlCQUFpQixDQUFDLEVBQUUsQ0FBQztDQUNsRjtDQUNBLE9BQU8sU0FBUztFQUNmLEtBQUssV0FBVztFQUNoQixNQUFNLE9BQU87RUFDYixJQUFJLENBQUMsS0FBSyxVQUFVLE9BQU8sS0FBSyxtQkFBbUI7Q0FDcEQ7Q0FDQSxVQUFVO0VBQ1QsTUFBTSxRQUFRO0VBQ2QsSUFBSSxDQUFDLEtBQUssVUFBVSxPQUFPLEtBQUssa0JBQWtCO0NBQ25EO0NBQ0EscUJBQXFCO0VBQ3BCLFFBQVEsZUFBZSxLQUFLLFNBQVMsY0FBYyxrQ0FBa0MsS0FBSyxtQ0FBbUM7RUFDN0gsUUFBUSxJQUFJLDRDQUE0QyxvQkFBb0Isb0JBQW9CO0VBQ2hHLFFBQVEsSUFBSSxxREFBcUQ7RUFDakUsUUFBUSxTQUFTO0NBQ2xCO0NBQ0Esb0JBQW9CO0VBQ25CLFFBQVEsSUFBSSxLQUFLLFNBQVMsY0FBYyxtQkFBbUIsS0FBSyxtQ0FBbUM7Q0FDcEc7QUFDRDtBQUdBLElBQU0scUJBQXFCOzs7Ozs7O0FBTzNCLFNBQVMsWUFBWSxHQUFHLFVBQVU7Q0FDakMsVUFBVSxDQUFDLGNBQWMsR0FBRyxTQUFTLGNBQWMsOERBQThELENBQUM7Q0FDbEgsTUFBTSxVQUFVLGNBQWM7RUFDN0IsU0FBUyxDQUFDO0VBQ1Y7Q0FDRCxDQUFDO0NBQ0QsT0FBTztFQUNOLElBQUksYUFBYTtHQUNoQixPQUFPLFFBQVE7RUFDaEI7RUFDQSxNQUFNLE1BQU0sU0FBUztHQUNwQixVQUFVLFFBQVEsZUFBZSxHQUFHLFNBQVMsY0FBYyxpSEFBaUgsQ0FBQztHQUM3SyxNQUFNLGFBQWEsc0JBQXNCLElBQUksTUFBTSxvQkFBb0IsS0FBSztJQUMzRSxlQUFlO0tBQ2QsS0FBSyxTQUFTLGVBQWUsS0FBSyxTQUFTLEtBQUs7S0FDaEQsU0FBUyxTQUFTLGVBQWU7SUFDbEM7SUFDQSxZQUFZLFNBQVM7R0FDdEIsQ0FBQyxJQUFJLElBQUksbUJBQW1CO0dBQzVCLFFBQVEsVUFBVTtJQUNqQixTQUFTLENBQUMsWUFBWSxJQUFJLGtCQUFrQixFQUFFLGNBQWMsQ0FBQyxJQUFJLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzNGLGtCQUFrQixTQUFTLG9CQUFvQjtJQUMvQyxTQUFTLEVBQUUsT0FBTyxTQUFTLE1BQU07R0FDbEMsQ0FBQztHQUNELE1BQU0sUUFBUSxPQUFPO0dBQ3JCLElBQUksc0JBQXNCLHFCQUFxQjtJQUM5QyxNQUFNLEdBQUcsZ0JBQWdCLE1BQU0sV0FBVztJQUMxQyxPQUFPO0dBQ1I7RUFDRDtFQUNBLE1BQU0sT0FBTztHQUNaLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLE9BQU8sWUFBWSxFQUFFLE1BQU0sa0JBQWtCLENBQUM7RUFDL0M7RUFDQSxRQUFRLFFBQVE7RUFDaEIsS0FBSyxRQUFRLElBQUksS0FBSyxPQUFPO0VBQzdCLGVBQWUsUUFBUSxjQUFjLEtBQUssT0FBTztFQUNqRCxpQkFBaUIsUUFBUSxnQkFBZ0IsS0FBSyxPQUFPO0VBQ3JELGNBQWMsUUFBUSxhQUFhLEtBQUssT0FBTztDQUNoRDtBQUNEO0FBR0EsU0FBUyw0QkFBNEIsWUFBWSx5QkFBeUI7Q0FDekUsT0FBTztFQUNOLFNBQVMsQ0FBQyxzQkFBc0IsSUFBSSxJQUFJLG9CQUFvQixFQUFFLGVBQWUsRUFBRSxLQUFLLFVBQVUsRUFBRSxDQUFDLElBQUksSUFBSSxtQkFBbUIsR0FBRyxJQUFJLGtCQUFrQixFQUFFLGNBQWMsQ0FBQyxJQUFJLHFCQUFxQixDQUFDLEVBQUUsQ0FBQyxDQUFDO0VBQ3BNLGtCQUFrQjtDQUNuQjtBQUNEO0FBQ0EsSUFBTSx3QkFBd0IsNEJBQTRCIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDZdfQ==