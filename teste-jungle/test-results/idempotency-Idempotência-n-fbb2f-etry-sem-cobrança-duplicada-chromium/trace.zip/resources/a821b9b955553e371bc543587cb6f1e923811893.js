import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/radio-group.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];"use client";
import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Radio as RadioPrimitive } from "/node_modules/.vite/deps/@base-ui_react_radio.js?v=e9f94b2e";
import { RadioGroup as RadioGroupPrimitive } from "/node_modules/.vite/deps/@base-ui_react_radio-group.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/radio-group.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
function RadioGroup(t0) {
	const $ = _c(9);
	if ($[0] !== "b7223d541f303ca79268f980da1c95768fe668eb98bf58f49ebe02899e66e4af") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "b7223d541f303ca79268f980da1c95768fe668eb98bf58f49ebe02899e66e4af";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("grid w-full gap-2", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(RadioGroupPrimitive, {
			"data-slot": "radio-group",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c2 = RadioGroup;
function RadioGroupItem(t0) {
	const $ = _c(10);
	if ($[0] !== "b7223d541f303ca79268f980da1c95768fe668eb98bf58f49ebe02899e66e4af") {
		for (let $i = 0; $i < 10; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "b7223d541f303ca79268f980da1c95768fe668eb98bf58f49ebe02899e66e4af";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("group/radio-group-item peer relative flex aspect-square size-4 shrink-0 rounded-full border border-input outline-none group-has-[:focus-visible]/field-label:ring-0 group-has-[:focus-visible]/field-label:not-data-checked:border-input after:absolute after:-inset-x-3 after:-inset-y-2 focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 aria-invalid:aria-checked:border-primary dark:bg-input/30 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 data-checked:border-primary data-checked:bg-primary data-checked:text-primary-foreground group-has-[:focus-visible]/field-label:data-checked:border-primary dark:data-checked:bg-primary", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV(RadioPrimitive.Indicator, {
			"data-slot": "radio-group-indicator",
			className: "flex size-4 items-center justify-center",
			children: /* @__PURE__ */ _jsxDEV("span", { className: "absolute top-1/2 left-1/2 size-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary-foreground" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 122
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 10
		}, this);
		$[6] = t2;
	} else {
		t2 = $[6];
	}
	let t3;
	if ($[7] !== props || $[8] !== t1) {
		t3 = /* @__PURE__ */ _jsxDEV(RadioPrimitive.Root, {
			"data-slot": "radio-group-item",
			className: t1,
			...props,
			children: t2
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 87,
			columnNumber: 10
		}, this);
		$[7] = props;
		$[8] = t1;
		$[9] = t3;
	} else {
		t3 = $[9];
	}
	return t3;
}
_c3 = RadioGroupItem;
export { RadioGroup, RadioGroupItem };
var _c2, _c3;
$RefreshReg$(_c2, "RadioGroup");
$RefreshReg$(_c3, "RadioGroupItem");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/radio-group.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/radio-group.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/radio-group.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/radio-group.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFBWSxTQUFBQSxLQUFBQyxVQUFBO0FBRVosU0FBU0MsU0FBU0Msc0JBQXNCO0FBQ3hDLFNBQVNDLGNBQWNDLDJCQUEyQjtBQUNsRCxTQUFTQyxVQUFVOzs7QUFFbkIsU0FBQUYsV0FBQUcsSUFBQTtDQUFBLE1BQUFDLElBQUFQLEdBQUE7Q0FBQSxJQUFBTyxFQUFBO0VBQUEsU0FBQUMsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUQsRUFBQUMsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFILEVBQUE7Q0FBQTtDQUFBLElBQUFJO0NBQUEsSUFBQUM7Q0FBQSxJQUFBTCxFQUFBLE9BQUFELElBQUE7RUFBb0IsRUFBQUssV0FBQSxHQUFBQyxTQUFBTjtFQUFrREMsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFJO0VBQUFKLEVBQUEsS0FBQUs7Q0FBQTtFQUFBRCxZQUFBSixFQUFBO0VBQUFLLFFBQUFMLEVBQUE7Q0FBQTtDQUFBLElBQUFNO0NBQUEsSUFBQU4sRUFBQSxPQUFBSSxXQUFBO0VBSXJERSxLQUFBUixHQUFHLHFCQUFxQk0sU0FBUztFQUFDSixFQUFBLEtBQUFJO0VBQUFKLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxJQUFBTztDQUFBLElBQUFQLEVBQUEsT0FBQUssU0FBQUwsRUFBQSxPQUFBTSxJQUFBO0VBRi9DQyxLQUFBLHdCQUFDLHFCQUFEO0dBQ1k7R0FDQyxXQUFBRDtHQUFrQyxHQUN6Q0Q7RUFBSzs7Ozs7RUFDVEwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQU87Q0FBQTtFQUFBQSxLQUFBUCxFQUFBO0NBQUE7Q0FBQSxPQUpGTztBQUlFOztBQUlOLFNBQUFDLGVBQUFULElBQUE7Q0FBQSxNQUFBQyxJQUFBUCxHQUFBO0NBQUEsSUFBQU8sRUFBQTtFQUFBLFNBQUFDLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFELEVBQUFDLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSCxFQUFBO0NBQUE7Q0FBQSxJQUFBSTtDQUFBLElBQUFDO0NBQUEsSUFBQUwsRUFBQSxPQUFBRCxJQUFBO0VBQXdCLEVBQUFLLFdBQUEsR0FBQUMsU0FBQU47RUFBa0RDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFLO0NBQUE7RUFBQUQsWUFBQUosRUFBQTtFQUFBSyxRQUFBTCxFQUFBO0NBQUE7Q0FBQSxJQUFBTTtDQUFBLElBQUFOLEVBQUEsT0FBQUksV0FBQTtFQUl6REUsS0FBQVIsR0FDVCw2eUJBQ0FNLFNBQ0Y7RUFBQ0osRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFNO0NBQUE7RUFBQUEsS0FBQU4sRUFBQTtDQUFBO0NBQUEsSUFBQU87Q0FBQSxJQUFBUCxFQUFBLE9BQUFFLE9BQUFDLElBQUE7RUFHREksS0FBQTtHQUNZO0dBQ0E7YUFFVixrQ0FBZ0IsbUhBQXVHOzs7OztFQUN6SDs7Ozs7RUFBMkJQLEVBQUEsS0FBQU87Q0FBQTtFQUFBQSxLQUFBUCxFQUFBO0NBQUE7Q0FBQSxJQUFBUztDQUFBLElBQUFULEVBQUEsT0FBQUssU0FBQUwsRUFBQSxPQUFBTSxJQUFBO0VBYjdCRyxLQUFBO0dBQ1k7R0FDQyxXQUFBSDtHQUdWLEdBQ0dEO2FBRUpFO0VBTUY7Ozs7O0VBQXNCUCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBUztDQUFBO0VBQUFBLEtBQUFULEVBQUE7Q0FBQTtDQUFBLE9BZHRCUztBQWNzQjs7QUFJMUIsU0FBU2IsWUFBWVkiLCJuYW1lcyI6WyJjIiwiX2MiLCJSYWRpbyIsIlJhZGlvUHJpbWl0aXZlIiwiUmFkaW9Hcm91cCIsIlJhZGlvR3JvdXBQcmltaXRpdmUiLCJjbiIsInQwIiwiJCIsIiRpIiwiU3ltYm9sIiwiZm9yIiwiY2xhc3NOYW1lIiwicHJvcHMiLCJ0MSIsInQyIiwiUmFkaW9Hcm91cEl0ZW0iLCJ0MyJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJyYWRpby1ncm91cC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2UgY2xpZW50XCJcblxuaW1wb3J0IHsgUmFkaW8gYXMgUmFkaW9QcmltaXRpdmUgfSBmcm9tIFwiQGJhc2UtdWkvcmVhY3QvcmFkaW9cIlxuaW1wb3J0IHsgUmFkaW9Hcm91cCBhcyBSYWRpb0dyb3VwUHJpbWl0aXZlIH0gZnJvbSBcIkBiYXNlLXVpL3JlYWN0L3JhZGlvLWdyb3VwXCJcbmltcG9ydCB7IGNuIH0gZnJvbSBcImNuXCJcblxuZnVuY3Rpb24gUmFkaW9Hcm91cCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfTogUmFkaW9Hcm91cFByaW1pdGl2ZS5Qcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxSYWRpb0dyb3VwUHJpbWl0aXZlXG4gICAgICBkYXRhLXNsb3Q9XCJyYWRpby1ncm91cFwiXG4gICAgICBjbGFzc05hbWU9e2NuKFwiZ3JpZCB3LWZ1bGwgZ2FwLTJcIiwgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIFJhZGlvR3JvdXBJdGVtKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9OiBSYWRpb1ByaW1pdGl2ZS5Sb290LlByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPFJhZGlvUHJpbWl0aXZlLlJvb3RcbiAgICAgIGRhdGEtc2xvdD1cInJhZGlvLWdyb3VwLWl0ZW1cIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJncm91cC9yYWRpby1ncm91cC1pdGVtIHBlZXIgcmVsYXRpdmUgZmxleCBhc3BlY3Qtc3F1YXJlIHNpemUtNCBzaHJpbmstMCByb3VuZGVkLWZ1bGwgYm9yZGVyIGJvcmRlci1pbnB1dCBvdXRsaW5lLW5vbmUgZ3JvdXAtaGFzLVs6Zm9jdXMtdmlzaWJsZV0vZmllbGQtbGFiZWw6cmluZy0wIGdyb3VwLWhhcy1bOmZvY3VzLXZpc2libGVdL2ZpZWxkLWxhYmVsOm5vdC1kYXRhLWNoZWNrZWQ6Ym9yZGVyLWlucHV0IGFmdGVyOmFic29sdXRlIGFmdGVyOi1pbnNldC14LTMgYWZ0ZXI6LWluc2V0LXktMiBmb2N1cy12aXNpYmxlOmJvcmRlci1yaW5nIGZvY3VzLXZpc2libGU6cmluZy0zIGZvY3VzLXZpc2libGU6cmluZy1yaW5nLzUwIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBkaXNhYmxlZDpvcGFjaXR5LTUwIGFyaWEtaW52YWxpZDpib3JkZXItZGVzdHJ1Y3RpdmUgYXJpYS1pbnZhbGlkOnJpbmctMyBhcmlhLWludmFsaWQ6cmluZy1kZXN0cnVjdGl2ZS8yMCBhcmlhLWludmFsaWQ6YXJpYS1jaGVja2VkOmJvcmRlci1wcmltYXJ5IGRhcms6YmctaW5wdXQvMzAgZGFyazphcmlhLWludmFsaWQ6Ym9yZGVyLWRlc3RydWN0aXZlLzUwIGRhcms6YXJpYS1pbnZhbGlkOnJpbmctZGVzdHJ1Y3RpdmUvNDAgZGF0YS1jaGVja2VkOmJvcmRlci1wcmltYXJ5IGRhdGEtY2hlY2tlZDpiZy1wcmltYXJ5IGRhdGEtY2hlY2tlZDp0ZXh0LXByaW1hcnktZm9yZWdyb3VuZCBncm91cC1oYXMtWzpmb2N1cy12aXNpYmxlXS9maWVsZC1sYWJlbDpkYXRhLWNoZWNrZWQ6Ym9yZGVyLXByaW1hcnkgZGFyazpkYXRhLWNoZWNrZWQ6YmctcHJpbWFyeVwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAgPFJhZGlvUHJpbWl0aXZlLkluZGljYXRvclxuICAgICAgICBkYXRhLXNsb3Q9XCJyYWRpby1ncm91cC1pbmRpY2F0b3JcIlxuICAgICAgICBjbGFzc05hbWU9XCJmbGV4IHNpemUtNCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIlxuICAgICAgPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSB0b3AtMS8yIGxlZnQtMS8yIHNpemUtMiAtdHJhbnNsYXRlLXgtMS8yIC10cmFuc2xhdGUteS0xLzIgcm91bmRlZC1mdWxsIGJnLXByaW1hcnktZm9yZWdyb3VuZFwiIC8+XG4gICAgICA8L1JhZGlvUHJpbWl0aXZlLkluZGljYXRvcj5cbiAgICA8L1JhZGlvUHJpbWl0aXZlLlJvb3Q+XG4gIClcbn1cblxuZXhwb3J0IHsgUmFkaW9Hcm91cCwgUmFkaW9Hcm91cEl0ZW0gfVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvY29tcG9uZW50cy91aS9yYWRpby1ncm91cC50c3gifQ==