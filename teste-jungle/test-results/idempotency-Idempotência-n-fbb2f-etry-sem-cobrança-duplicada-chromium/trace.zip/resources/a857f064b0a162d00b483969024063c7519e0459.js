import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/_authenticated.tsx?tsr-split=component");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Outlet } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated.tsx?tsr-split=component";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
/** Layout guard: protege Carrinho, Checkout e Perfil. */
const SplitComponent = () => {
	const $ = _c(2);
	if ($[0] !== "da44b39f2e513c2f449b05ebb233a45bf202f47d8ca91ffd79ef9244ba0b029b") {
		for (let $i = 0; $i < 2; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "da44b39f2e513c2f449b05ebb233a45bf202f47d8ca91ffd79ef9244ba0b029b";
	}
	let t0;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ _jsxDEV(Outlet, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 10
		}, this);
		$[1] = t0;
	} else {
		t0 = $[1];
	}
	return t0;
};
_c2 = SplitComponent;
export { SplitComponent as component };
var _c2;
$RefreshReg$(_c2, "SplitComponent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/_authenticated.tsx?tsr-split=component";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated.tsx?tsr-split=component", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated.tsx?tsr-split=component", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated.tsx?tsr-split=component" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQTBCQSxjQUF3Qjs7OztBQUdsRCxNQUFBQyx1QkFPYUE7Q0FBQUE7Q0FBQUE7RUFBQUE7R0FBQUE7RUFBQUE7RUFBQUE7Q0FBQUE7Q0FBQUE7Q0FBQUE7RUFBTUMsS0FBQSx3QkFBQyxRQUFELENBQU87Ozs7O0VBQUdDLEVBQUEsS0FBQUQ7Q0FBQTtFQUFBQSxLQUFBQyxFQUFBO0NBQUE7Q0FBQSxPQUFWRDtBQUFVOztBQUFBLFNBQUFELGtCQUFBRyIsIm5hbWVzIjpbIk91dGxldCIsIlNwbGl0Q29tcG9uZW50IiwidDAiLCIkIiwiY29tcG9uZW50Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbIl9hdXRoZW50aWNhdGVkLnRzeD90c3Itc3BsaXQ9Y29tcG9uZW50Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUZpbGVSb3V0ZSwgT3V0bGV0LCByZWRpcmVjdCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1yb3V0ZXInXG5pbXBvcnQgeyBzZXNzaW9uIH0gZnJvbSAnQC9saWIvc2Vzc2lvbidcblxuLyoqIExheW91dCBndWFyZDogcHJvdGVnZSBDYXJyaW5obywgQ2hlY2tvdXQgZSBQZXJmaWwuICovXG5leHBvcnQgY29uc3QgUm91dGUgPSBjcmVhdGVGaWxlUm91dGUoJy9fYXV0aGVudGljYXRlZCcpKHtcbiAgYmVmb3JlTG9hZDogKHsgbG9jYXRpb24gfSkgPT4ge1xuICAgIGlmICghc2Vzc2lvbi5pc0F1dGhlbnRpY2F0ZWQoKSkge1xuICAgICAgdGhyb3cgcmVkaXJlY3QoeyB0bzogJy9sb2dpbicsIHNlYXJjaDogeyByZWRpcmVjdDogbG9jYXRpb24uaHJlZiB9IH0pXG4gICAgfVxuICB9LFxuICBjb21wb25lbnQ6ICgpID0+IDxPdXRsZXQgLz4sXG59KVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvcm91dGVzL19hdXRoZW50aWNhdGVkLnRzeCJ9