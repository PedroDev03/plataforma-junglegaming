import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/tooltip.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];"use client";
import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Tooltip as TooltipPrimitive } from "/node_modules/.vite/deps/@base-ui_react_tooltip.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/tooltip.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
function TooltipProvider(t0) {
	const $ = _c(7);
	if ($[0] !== "570dab3f9cd5bd68466b072043812edf6450eb8a8392ce2579931e46ad49715d") {
		for (let $i = 0; $i < 7; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "570dab3f9cd5bd68466b072043812edf6450eb8a8392ce2579931e46ad49715d";
	}
	let props;
	let t1;
	if ($[1] !== t0) {
		({delay: t1, ...props} = t0);
		$[1] = t0;
		$[2] = props;
		$[3] = t1;
	} else {
		props = $[2];
		t1 = $[3];
	}
	const delay = t1 === undefined ? 0 : t1;
	let t2;
	if ($[4] !== delay || $[5] !== props) {
		t2 = /* @__PURE__ */ _jsxDEV(TooltipPrimitive.Provider, {
			"data-slot": "tooltip-provider",
			delay,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 10
		}, this);
		$[4] = delay;
		$[5] = props;
		$[6] = t2;
	} else {
		t2 = $[6];
	}
	return t2;
}
_c2 = TooltipProvider;
function Tooltip(t0) {
	const $ = _c(5);
	if ($[0] !== "570dab3f9cd5bd68466b072043812edf6450eb8a8392ce2579931e46ad49715d") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "570dab3f9cd5bd68466b072043812edf6450eb8a8392ce2579931e46ad49715d";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(TooltipPrimitive.Root, {
			"data-slot": "tooltip",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 60,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c3 = Tooltip;
function TooltipTrigger(t0) {
	const $ = _c(5);
	if ($[0] !== "570dab3f9cd5bd68466b072043812edf6450eb8a8392ce2579931e46ad49715d") {
		for (let $i = 0; $i < 5; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "570dab3f9cd5bd68466b072043812edf6450eb8a8392ce2579931e46ad49715d";
	}
	let props;
	if ($[1] !== t0) {
		({...props} = t0);
		$[1] = t0;
		$[2] = props;
	} else {
		props = $[2];
	}
	let t1;
	if ($[3] !== props) {
		t1 = /* @__PURE__ */ _jsxDEV(TooltipPrimitive.Trigger, {
			"data-slot": "tooltip-trigger",
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 88,
			columnNumber: 10
		}, this);
		$[3] = props;
		$[4] = t1;
	} else {
		t1 = $[4];
	}
	return t1;
}
_c4 = TooltipTrigger;
function TooltipContent(t0) {
	const $ = _c(22);
	if ($[0] !== "570dab3f9cd5bd68466b072043812edf6450eb8a8392ce2579931e46ad49715d") {
		for (let $i = 0; $i < 22; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "570dab3f9cd5bd68466b072043812edf6450eb8a8392ce2579931e46ad49715d";
	}
	let children;
	let className;
	let props;
	let t1;
	let t2;
	let t3;
	let t4;
	if ($[1] !== t0) {
		({className, side: t1, sideOffset: t2, align: t3, alignOffset: t4, children, ...props} = t0);
		$[1] = t0;
		$[2] = children;
		$[3] = className;
		$[4] = props;
		$[5] = t1;
		$[6] = t2;
		$[7] = t3;
		$[8] = t4;
	} else {
		children = $[2];
		className = $[3];
		props = $[4];
		t1 = $[5];
		t2 = $[6];
		t3 = $[7];
		t4 = $[8];
	}
	const side = t1 === undefined ? "top" : t1;
	const sideOffset = t2 === undefined ? 4 : t2;
	const align = t3 === undefined ? "center" : t3;
	const alignOffset = t4 === undefined ? 0 : t4;
	let t5;
	if ($[9] !== className) {
		t5 = cn("z-50 inline-flex w-fit max-w-xs origin-(--transform-origin) items-center gap-1.5 rounded-md bg-foreground px-3 py-1.5 text-xs text-background has-data-[slot=kbd]:pr-1.5 data-[side=bottom]:slide-in-from-top-2 data-[side=inline-end]:slide-in-from-left-2 data-[side=inline-start]:slide-in-from-right-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 **:data-[slot=kbd]:relative **:data-[slot=kbd]:isolate **:data-[slot=kbd]:z-50 **:data-[slot=kbd]:rounded-sm data-[state=delayed-open]:animate-in data-[state=delayed-open]:fade-in-0 data-[state=delayed-open]:zoom-in-95 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", className);
		$[9] = className;
		$[10] = t5;
	} else {
		t5 = $[10];
	}
	let t6;
	if ($[11] === Symbol.for("react.memo_cache_sentinel")) {
		t6 = /* @__PURE__ */ _jsxDEV(TooltipPrimitive.Arrow, { className: "z-50 size-2.5 translate-y-[calc(-50%-2px)] rotate-45 rounded-[2px] bg-foreground fill-foreground data-[side=bottom]:top-1 data-[side=inline-end]:top-1/2! data-[side=inline-end]:-left-1 data-[side=inline-end]:-translate-y-1/2 data-[side=inline-start]:top-1/2! data-[side=inline-start]:-right-1 data-[side=inline-start]:-translate-y-1/2 data-[side=left]:top-1/2! data-[side=left]:-right-1 data-[side=left]:-translate-y-1/2 data-[side=right]:top-1/2! data-[side=right]:-left-1 data-[side=right]:-translate-y-1/2 data-[side=top]:-bottom-2.5" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 152,
			columnNumber: 10
		}, this);
		$[11] = t6;
	} else {
		t6 = $[11];
	}
	let t7;
	if ($[12] !== children || $[13] !== props || $[14] !== t5) {
		t7 = /* @__PURE__ */ _jsxDEV(TooltipPrimitive.Popup, {
			"data-slot": "tooltip-content",
			className: t5,
			...props,
			children: [children, t6]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 159,
			columnNumber: 10
		}, this);
		$[12] = children;
		$[13] = props;
		$[14] = t5;
		$[15] = t7;
	} else {
		t7 = $[15];
	}
	let t8;
	if ($[16] !== align || $[17] !== alignOffset || $[18] !== side || $[19] !== sideOffset || $[20] !== t7) {
		t8 = /* @__PURE__ */ _jsxDEV(TooltipPrimitive.Portal, { children: /* @__PURE__ */ _jsxDEV(TooltipPrimitive.Positioner, {
			align,
			alignOffset,
			side,
			sideOffset,
			className: "isolate z-50",
			children: t7
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 169,
			columnNumber: 35
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 169,
			columnNumber: 10
		}, this);
		$[16] = align;
		$[17] = alignOffset;
		$[18] = side;
		$[19] = sideOffset;
		$[20] = t7;
		$[21] = t8;
	} else {
		t8 = $[21];
	}
	return t8;
}
_c5 = TooltipContent;
export { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider };
var _c2, _c3, _c4, _c5;
$RefreshReg$(_c2, "TooltipProvider");
$RefreshReg$(_c3, "Tooltip");
$RefreshReg$(_c4, "TooltipTrigger");
$RefreshReg$(_c5, "TooltipContent");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/tooltip.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/tooltip.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/tooltip.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/tooltip.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFBWSxTQUFBQSxLQUFBQyxVQUFBO0FBRVosU0FBU0MsV0FBV0Msd0JBQXdCO0FBQzVDLFNBQVNDLFVBQVU7OztBQUVuQixTQUFBQyxnQkFBQUMsSUFBQTtDQUFBLE1BQUFDLElBQUFOLEdBQUE7Q0FBQSxJQUFBTSxFQUFBO0VBQUEsU0FBQUMsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUQsRUFBQUMsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFILEVBQUE7Q0FBQTtDQUFBLElBQUFJO0NBQUEsSUFBQUM7Q0FBQSxJQUFBTCxFQUFBLE9BQUFELElBQUE7RUFBeUIsRUFBQU8sT0FBQUQsSUFBQSxHQUFBRCxTQUFBTDtFQUdTQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQUk7RUFBQUosRUFBQSxLQUFBSztDQUFBO0VBQUFELFFBQUFKLEVBQUE7RUFBQUssS0FBQUwsRUFBQTtDQUFBO0NBRmhDLE1BQUFNLFFBQUFELE9BQUFFLFlBQUEsSUFBQUY7Q0FBUyxJQUFBRztDQUFBLElBQUFSLEVBQUEsT0FBQU0sU0FBQU4sRUFBQSxPQUFBSSxPQUFBO0VBSVBJLEtBQUE7R0FDWTtHQUNIRjtHQUFLLEdBQ1JGO0VBQUs7Ozs7O0VBQ1RKLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFRO0NBQUE7RUFBQUEsS0FBQVIsRUFBQTtDQUFBO0NBQUEsT0FKRlE7QUFJRTs7QUFJTixTQUFBYixRQUFBSSxJQUFBO0NBQUEsTUFBQUMsSUFBQU4sR0FBQTtDQUFBLElBQUFNLEVBQUE7RUFBQSxTQUFBQyxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRCxFQUFBQyxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUgsRUFBQTtDQUFBO0NBQUEsSUFBQUk7Q0FBQSxJQUFBSixFQUFBLE9BQUFELElBQUE7RUFBaUIsS0FBQUssU0FBQUw7RUFBeUNDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSTtDQUFBO0VBQUFBLFFBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUwsRUFBQSxPQUFBSSxPQUFBO0VBQ2pEQyxLQUFBO0dBQWlDO0dBQVMsR0FBS0Q7RUFBSzs7Ozs7RUFBSUosRUFBQSxLQUFBSTtFQUFBSixFQUFBLEtBQUFLO0NBQUE7RUFBQUEsS0FBQUwsRUFBQTtDQUFBO0NBQUEsT0FBeERLO0FBQXdEOztBQUdqRSxTQUFBSSxlQUFBVixJQUFBO0NBQUEsTUFBQUMsSUFBQU4sR0FBQTtDQUFBLElBQUFNLEVBQUE7RUFBQSxTQUFBQyxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRCxFQUFBQyxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUgsRUFBQTtDQUFBO0NBQUEsSUFBQUk7Q0FBQSxJQUFBSixFQUFBLE9BQUFELElBQUE7RUFBd0IsS0FBQUssU0FBQUw7RUFBNENDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSTtDQUFBO0VBQUFBLFFBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUwsRUFBQSxPQUFBSSxPQUFBO0VBQzNEQyxLQUFBO0dBQW9DO0dBQWlCLEdBQUtEO0VBQUs7Ozs7O0VBQUlKLEVBQUEsS0FBQUk7RUFBQUosRUFBQSxLQUFBSztDQUFBO0VBQUFBLEtBQUFMLEVBQUE7Q0FBQTtDQUFBLE9BQW5FSztBQUFtRTs7QUFHNUUsU0FBQUssZUFBQVgsSUFBQTtDQUFBLE1BQUFDLElBQUFOLEdBQUE7Q0FBQSxJQUFBTSxFQUFBO0VBQUEsU0FBQUMsS0FBQSxHQUFBQSxLQUFBLElBQUFBLE1BQUE7R0FBQUQsRUFBQUMsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFILEVBQUE7Q0FBQTtDQUFBLElBQUFXO0NBQUEsSUFBQUM7Q0FBQSxJQUFBUjtDQUFBLElBQUFDO0NBQUEsSUFBQUc7Q0FBQSxJQUFBSztDQUFBLElBQUFDO0NBQUEsSUFBQWQsRUFBQSxPQUFBRCxJQUFBO0VBQXdCLEVBQUFhLFdBQUFHLE1BQUFWLElBQUFXLFlBQUFSLElBQUFTLE9BQUFKLElBQUFLLGFBQUFKLElBQUFILFVBQUEsR0FBQVAsU0FBQUw7RUFZckJDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBVztFQUFBWCxFQUFBLEtBQUFZO0VBQUFaLEVBQUEsS0FBQUk7RUFBQUosRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFRO0VBQUFSLEVBQUEsS0FBQWE7RUFBQWIsRUFBQSxLQUFBYztDQUFBO0VBQUFILFdBQUFYLEVBQUE7RUFBQVksWUFBQVosRUFBQTtFQUFBSSxRQUFBSixFQUFBO0VBQUFLLEtBQUFMLEVBQUE7RUFBQVEsS0FBQVIsRUFBQTtFQUFBYSxLQUFBYixFQUFBO0VBQUFjLEtBQUFkLEVBQUE7Q0FBQTtDQVZELE1BQUFlLE9BQUFWLE9BQUFFLFlBQUEsUUFBQUY7Q0FDQSxNQUFBVyxhQUFBUixPQUFBRCxZQUFBLElBQUFDO0NBQ0EsTUFBQVMsUUFBQUosT0FBQU4sWUFBQSxXQUFBTTtDQUNBLE1BQUFLLGNBQUFKLE9BQUFQLFlBQUEsSUFBQU87Q0FBZSxJQUFBSztDQUFBLElBQUFuQixFQUFBLE9BQUFZLFdBQUE7RUFtQklPLEtBQUF0QixHQUNULG13QkFDQWUsU0FDRjtFQUFDWixFQUFBLEtBQUFZO0VBQUFaLEVBQUEsTUFBQW1CO0NBQUE7RUFBQUEsS0FBQW5CLEVBQUE7Q0FBQTtDQUFBLElBQUFvQjtDQUFBLElBQUFwQixFQUFBLFFBQUFFLE9BQUFDLElBQUE7RUFJRGlCLEtBQUEsa0RBQWtDLHNpQkFBMGhCOzs7OztFQUFHcEIsRUFBQSxNQUFBb0I7Q0FBQTtFQUFBQSxLQUFBcEIsRUFBQTtDQUFBO0NBQUEsSUFBQXFCO0NBQUEsSUFBQXJCLEVBQUEsUUFBQVcsWUFBQVgsRUFBQSxRQUFBSSxTQUFBSixFQUFBLFFBQUFtQixJQUFBO0VBVGprQkUsS0FBQTtHQUNZO0dBQ0MsV0FBQUY7R0FHVixHQUNHZjthQU5OLENBUUdPLFVBQ0RTLEVBQ0Y7Ozs7OztFQUF5QnBCLEVBQUEsTUFBQVc7RUFBQVgsRUFBQSxNQUFBSTtFQUFBSixFQUFBLE1BQUFtQjtFQUFBbkIsRUFBQSxNQUFBcUI7Q0FBQTtFQUFBQSxLQUFBckIsRUFBQTtDQUFBO0NBQUEsSUFBQXNCO0NBQUEsSUFBQXRCLEVBQUEsUUFBQWlCLFNBQUFqQixFQUFBLFFBQUFrQixlQUFBbEIsRUFBQSxRQUFBZSxRQUFBZixFQUFBLFFBQUFnQixjQUFBaEIsRUFBQSxRQUFBcUIsSUFBQTtFQWxCN0JDLEtBQUEsNkRBQ0U7R0FDU0w7R0FDTUM7R0FDUEg7R0FDTUM7R0FDRjthQUVWSztFQVdGOzs7O1dBQ0Y7Ozs7O0VBQTBCckIsRUFBQSxNQUFBaUI7RUFBQWpCLEVBQUEsTUFBQWtCO0VBQUFsQixFQUFBLE1BQUFlO0VBQUFmLEVBQUEsTUFBQWdCO0VBQUFoQixFQUFBLE1BQUFxQjtFQUFBckIsRUFBQSxNQUFBc0I7Q0FBQTtFQUFBQSxLQUFBdEIsRUFBQTtDQUFBO0NBQUEsT0FwQjFCc0I7QUFvQjBCOztBQUk5QixTQUFTM0IsU0FBU2MsZ0JBQWdCQyxnQkFBZ0JaIiwibmFtZXMiOlsiYyIsIl9jIiwiVG9vbHRpcCIsIlRvb2x0aXBQcmltaXRpdmUiLCJjbiIsIlRvb2x0aXBQcm92aWRlciIsInQwIiwiJCIsIiRpIiwiU3ltYm9sIiwiZm9yIiwicHJvcHMiLCJ0MSIsImRlbGF5IiwidW5kZWZpbmVkIiwidDIiLCJUb29sdGlwVHJpZ2dlciIsIlRvb2x0aXBDb250ZW50IiwiY2hpbGRyZW4iLCJjbGFzc05hbWUiLCJ0MyIsInQ0Iiwic2lkZSIsInNpZGVPZmZzZXQiLCJhbGlnbiIsImFsaWduT2Zmc2V0IiwidDUiLCJ0NiIsInQ3IiwidDgiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsidG9vbHRpcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2UgY2xpZW50XCJcblxuaW1wb3J0IHsgVG9vbHRpcCBhcyBUb29sdGlwUHJpbWl0aXZlIH0gZnJvbSBcIkBiYXNlLXVpL3JlYWN0L3Rvb2x0aXBcIlxuaW1wb3J0IHsgY24gfSBmcm9tIFwiY25cIlxuXG5mdW5jdGlvbiBUb29sdGlwUHJvdmlkZXIoe1xuICBkZWxheSA9IDAsXG4gIC4uLnByb3BzXG59OiBUb29sdGlwUHJpbWl0aXZlLlByb3ZpZGVyLlByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPFRvb2x0aXBQcmltaXRpdmUuUHJvdmlkZXJcbiAgICAgIGRhdGEtc2xvdD1cInRvb2x0aXAtcHJvdmlkZXJcIlxuICAgICAgZGVsYXk9e2RlbGF5fVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZnVuY3Rpb24gVG9vbHRpcCh7IC4uLnByb3BzIH06IFRvb2x0aXBQcmltaXRpdmUuUm9vdC5Qcm9wcykge1xuICByZXR1cm4gPFRvb2x0aXBQcmltaXRpdmUuUm9vdCBkYXRhLXNsb3Q9XCJ0b29sdGlwXCIgey4uLnByb3BzfSAvPlxufVxuXG5mdW5jdGlvbiBUb29sdGlwVHJpZ2dlcih7IC4uLnByb3BzIH06IFRvb2x0aXBQcmltaXRpdmUuVHJpZ2dlci5Qcm9wcykge1xuICByZXR1cm4gPFRvb2x0aXBQcmltaXRpdmUuVHJpZ2dlciBkYXRhLXNsb3Q9XCJ0b29sdGlwLXRyaWdnZXJcIiB7Li4ucHJvcHN9IC8+XG59XG5cbmZ1bmN0aW9uIFRvb2x0aXBDb250ZW50KHtcbiAgY2xhc3NOYW1lLFxuICBzaWRlID0gXCJ0b3BcIixcbiAgc2lkZU9mZnNldCA9IDQsXG4gIGFsaWduID0gXCJjZW50ZXJcIixcbiAgYWxpZ25PZmZzZXQgPSAwLFxuICBjaGlsZHJlbixcbiAgLi4ucHJvcHNcbn06IFRvb2x0aXBQcmltaXRpdmUuUG9wdXAuUHJvcHMgJlxuICBQaWNrPFxuICAgIFRvb2x0aXBQcmltaXRpdmUuUG9zaXRpb25lci5Qcm9wcyxcbiAgICBcImFsaWduXCIgfCBcImFsaWduT2Zmc2V0XCIgfCBcInNpZGVcIiB8IFwic2lkZU9mZnNldFwiXG4gID4pIHtcbiAgcmV0dXJuIChcbiAgICA8VG9vbHRpcFByaW1pdGl2ZS5Qb3J0YWw+XG4gICAgICA8VG9vbHRpcFByaW1pdGl2ZS5Qb3NpdGlvbmVyXG4gICAgICAgIGFsaWduPXthbGlnbn1cbiAgICAgICAgYWxpZ25PZmZzZXQ9e2FsaWduT2Zmc2V0fVxuICAgICAgICBzaWRlPXtzaWRlfVxuICAgICAgICBzaWRlT2Zmc2V0PXtzaWRlT2Zmc2V0fVxuICAgICAgICBjbGFzc05hbWU9XCJpc29sYXRlIHotNTBcIlxuICAgICAgPlxuICAgICAgICA8VG9vbHRpcFByaW1pdGl2ZS5Qb3B1cFxuICAgICAgICAgIGRhdGEtc2xvdD1cInRvb2x0aXAtY29udGVudFwiXG4gICAgICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgICAgIFwiei01MCBpbmxpbmUtZmxleCB3LWZpdCBtYXgtdy14cyBvcmlnaW4tKC0tdHJhbnNmb3JtLW9yaWdpbikgaXRlbXMtY2VudGVyIGdhcC0xLjUgcm91bmRlZC1tZCBiZy1mb3JlZ3JvdW5kIHB4LTMgcHktMS41IHRleHQteHMgdGV4dC1iYWNrZ3JvdW5kIGhhcy1kYXRhLVtzbG90PWtiZF06cHItMS41IGRhdGEtW3NpZGU9Ym90dG9tXTpzbGlkZS1pbi1mcm9tLXRvcC0yIGRhdGEtW3NpZGU9aW5saW5lLWVuZF06c2xpZGUtaW4tZnJvbS1sZWZ0LTIgZGF0YS1bc2lkZT1pbmxpbmUtc3RhcnRdOnNsaWRlLWluLWZyb20tcmlnaHQtMiBkYXRhLVtzaWRlPWxlZnRdOnNsaWRlLWluLWZyb20tcmlnaHQtMiBkYXRhLVtzaWRlPXJpZ2h0XTpzbGlkZS1pbi1mcm9tLWxlZnQtMiBkYXRhLVtzaWRlPXRvcF06c2xpZGUtaW4tZnJvbS1ib3R0b20tMiAqKjpkYXRhLVtzbG90PWtiZF06cmVsYXRpdmUgKio6ZGF0YS1bc2xvdD1rYmRdOmlzb2xhdGUgKio6ZGF0YS1bc2xvdD1rYmRdOnotNTAgKio6ZGF0YS1bc2xvdD1rYmRdOnJvdW5kZWQtc20gZGF0YS1bc3RhdGU9ZGVsYXllZC1vcGVuXTphbmltYXRlLWluIGRhdGEtW3N0YXRlPWRlbGF5ZWQtb3Blbl06ZmFkZS1pbi0wIGRhdGEtW3N0YXRlPWRlbGF5ZWQtb3Blbl06em9vbS1pbi05NSBkYXRhLW9wZW46YW5pbWF0ZS1pbiBkYXRhLW9wZW46ZmFkZS1pbi0wIGRhdGEtb3Blbjp6b29tLWluLTk1IGRhdGEtY2xvc2VkOmFuaW1hdGUtb3V0IGRhdGEtY2xvc2VkOmZhZGUtb3V0LTAgZGF0YS1jbG9zZWQ6em9vbS1vdXQtOTVcIixcbiAgICAgICAgICAgIGNsYXNzTmFtZVxuICAgICAgICAgICl9XG4gICAgICAgICAgey4uLnByb3BzfVxuICAgICAgICA+XG4gICAgICAgICAge2NoaWxkcmVufVxuICAgICAgICAgIDxUb29sdGlwUHJpbWl0aXZlLkFycm93IGNsYXNzTmFtZT1cInotNTAgc2l6ZS0yLjUgdHJhbnNsYXRlLXktW2NhbGMoLTUwJS0ycHgpXSByb3RhdGUtNDUgcm91bmRlZC1bMnB4XSBiZy1mb3JlZ3JvdW5kIGZpbGwtZm9yZWdyb3VuZCBkYXRhLVtzaWRlPWJvdHRvbV06dG9wLTEgZGF0YS1bc2lkZT1pbmxpbmUtZW5kXTp0b3AtMS8yISBkYXRhLVtzaWRlPWlubGluZS1lbmRdOi1sZWZ0LTEgZGF0YS1bc2lkZT1pbmxpbmUtZW5kXTotdHJhbnNsYXRlLXktMS8yIGRhdGEtW3NpZGU9aW5saW5lLXN0YXJ0XTp0b3AtMS8yISBkYXRhLVtzaWRlPWlubGluZS1zdGFydF06LXJpZ2h0LTEgZGF0YS1bc2lkZT1pbmxpbmUtc3RhcnRdOi10cmFuc2xhdGUteS0xLzIgZGF0YS1bc2lkZT1sZWZ0XTp0b3AtMS8yISBkYXRhLVtzaWRlPWxlZnRdOi1yaWdodC0xIGRhdGEtW3NpZGU9bGVmdF06LXRyYW5zbGF0ZS15LTEvMiBkYXRhLVtzaWRlPXJpZ2h0XTp0b3AtMS8yISBkYXRhLVtzaWRlPXJpZ2h0XTotbGVmdC0xIGRhdGEtW3NpZGU9cmlnaHRdOi10cmFuc2xhdGUteS0xLzIgZGF0YS1bc2lkZT10b3BdOi1ib3R0b20tMi41XCIgLz5cbiAgICAgICAgPC9Ub29sdGlwUHJpbWl0aXZlLlBvcHVwPlxuICAgICAgPC9Ub29sdGlwUHJpbWl0aXZlLlBvc2l0aW9uZXI+XG4gICAgPC9Ub29sdGlwUHJpbWl0aXZlLlBvcnRhbD5cbiAgKVxufVxuXG5leHBvcnQgeyBUb29sdGlwLCBUb29sdGlwVHJpZ2dlciwgVG9vbHRpcENvbnRlbnQsIFRvb2x0aXBQcm92aWRlciB9XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9jb21wb25lbnRzL3VpL3Rvb2x0aXAudHN4In0=