import { n as __exportAll } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
// node_modules/@base-ui/react/separator/SeparatorDataAttributes.mjs
var SeparatorDataAttributes_exports = /* @__PURE__ */ __exportAll({ orientation: () => orientation });
/**
* Indicates the orientation of the separator.
* @type {'horizontal' | 'vertical'}
*/
var orientation = "data-orientation";
export { SeparatorDataAttributes_exports as t };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiU2VwYXJhdG9yRGF0YUF0dHJpYnV0ZXMtQmZIbHJiOFguanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vQGJhc2UtdWkvcmVhY3Qvc2VwYXJhdG9yL1NlcGFyYXRvckRhdGFBdHRyaWJ1dGVzLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEluZGljYXRlcyB0aGUgb3JpZW50YXRpb24gb2YgdGhlIHNlcGFyYXRvci5cbiAqIEB0eXBlIHsnaG9yaXpvbnRhbCcgfCAndmVydGljYWwnfVxuICovXG5leHBvcnQgY29uc3Qgb3JpZW50YXRpb24gPSAnZGF0YS1vcmllbnRhdGlvbic7Il0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBSUEsSUFBYSxjQUFjIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzBdfQ==