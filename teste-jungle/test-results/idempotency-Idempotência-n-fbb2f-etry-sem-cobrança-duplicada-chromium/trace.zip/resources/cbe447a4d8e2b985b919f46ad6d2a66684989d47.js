import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/alert.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport1_react, 1);const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=e9f94b2e";
import { cva } from "/node_modules/.vite/deps/class-variance-authority.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/alert.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
const alertVariants = cva("group/alert relative grid w-full gap-0.5 rounded-lg border px-2.5 py-2 text-left text-sm has-data-[slot=alert-action]:relative has-data-[slot=alert-action]:pr-18 has-[>svg]:grid-cols-[auto_1fr] has-[>svg]:gap-x-2 *:[svg]:row-span-2 *:[svg]:translate-y-0.5 *:[svg]:text-current *:[svg:not([class*='size-'])]:size-4", {
	variants: { variant: {
		default: "bg-card text-card-foreground",
		destructive: "bg-card text-destructive *:data-[slot=alert-description]:text-destructive/90 *:[svg]:text-current"
	} },
	defaultVariants: { variant: "default" }
});
function Alert(t0) {
	const $ = _c(11);
	if ($[0] !== "da35e2c976297f9cb61f43b142d696f9e107c00b6b634db85938a18a616ef3af") {
		for (let $i = 0; $i < 11; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "da35e2c976297f9cb61f43b142d696f9e107c00b6b634db85938a18a616ef3af";
	}
	let className;
	let props;
	let variant;
	if ($[1] !== t0) {
		({className, variant, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
		$[4] = variant;
	} else {
		className = $[2];
		props = $[3];
		variant = $[4];
	}
	let t1;
	if ($[5] !== className || $[6] !== variant) {
		t1 = cn(alertVariants({ variant }), className);
		$[5] = className;
		$[6] = variant;
		$[7] = t1;
	} else {
		t1 = $[7];
	}
	let t2;
	if ($[8] !== props || $[9] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "alert",
			role: "alert",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 10
		}, this);
		$[8] = props;
		$[9] = t1;
		$[10] = t2;
	} else {
		t2 = $[10];
	}
	return t2;
}
_c2 = Alert;
function AlertTitle(t0) {
	const $ = _c(9);
	if ($[0] !== "da35e2c976297f9cb61f43b142d696f9e107c00b6b634db85938a18a616ef3af") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "da35e2c976297f9cb61f43b142d696f9e107c00b6b634db85938a18a616ef3af";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("font-medium group-has-[>svg]/alert:col-start-2 [&_a]:underline [&_a]:underline-offset-3 [&_a]:hover:text-foreground", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "alert-title",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 96,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c3 = AlertTitle;
function AlertDescription(t0) {
	const $ = _c(9);
	if ($[0] !== "da35e2c976297f9cb61f43b142d696f9e107c00b6b634db85938a18a616ef3af") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "da35e2c976297f9cb61f43b142d696f9e107c00b6b634db85938a18a616ef3af";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("text-sm text-balance text-muted-foreground md:text-pretty [&_a]:underline [&_a]:underline-offset-3 [&_a]:hover:text-foreground [&_p:not(:last-child)]:mb-4", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "alert-description",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 137,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c4 = AlertDescription;
function AlertAction(t0) {
	const $ = _c(9);
	if ($[0] !== "da35e2c976297f9cb61f43b142d696f9e107c00b6b634db85938a18a616ef3af") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "da35e2c976297f9cb61f43b142d696f9e107c00b6b634db85938a18a616ef3af";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("absolute top-2 right-2", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			"data-slot": "alert-action",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 178,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c5 = AlertAction;
export { Alert, AlertTitle, AlertDescription, AlertAction };
var _c2, _c3, _c4, _c5;
$RefreshReg$(_c2, "Alert");
$RefreshReg$(_c3, "AlertTitle");
$RefreshReg$(_c4, "AlertDescription");
$RefreshReg$(_c5, "AlertAction");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/alert.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/alert.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/alert.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/alert.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFlBQVlBLFdBQVc7QUFDdkIsU0FBU0MsV0FBOEI7QUFDdkMsU0FBU0MsVUFBVTs7O0FBRW5CLE1BQU1DLGdCQUFnQkYsSUFDcEIsNlRBQ0E7Q0FDRUcsVUFBVSxFQUNSQyxTQUFTO0VBQ1BDLFNBQVM7RUFDVEMsYUFDRTtDQUNKLEVBQ0Y7Q0FDQUMsaUJBQWlCLEVBQ2ZILFNBQVMsVUFDWDtBQUNGLENBQ0Y7QUFFQSxTQUFBSSxNQUFBQyxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBQztDQUFBLElBQUFaO0NBQUEsSUFBQU0sRUFBQSxPQUFBRCxJQUFBO0VBQWUsRUFBQU0sV0FBQVgsU0FBQSxHQUFBWSxTQUFBUDtFQUlvREMsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBTjtDQUFBO0VBQUFXLFlBQUFMLEVBQUE7RUFBQU0sUUFBQU4sRUFBQTtFQUFBTixVQUFBTSxFQUFBO0NBQUE7Q0FBQSxJQUFBTztDQUFBLElBQUFQLEVBQUEsT0FBQUssYUFBQUwsRUFBQSxPQUFBTixTQUFBO0VBS2xEYSxLQUFBaEIsR0FBR0MsY0FBYyxFQUFBRSxRQUFVLENBQUMsR0FBR1csU0FBUztFQUFDTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU47RUFBQU0sRUFBQSxLQUFBTztDQUFBO0VBQUFBLEtBQUFQLEVBQUE7Q0FBQTtDQUFBLElBQUFRO0NBQUEsSUFBQVIsRUFBQSxPQUFBTSxTQUFBTixFQUFBLE9BQUFPLElBQUE7RUFIdERDLEtBQUE7R0FDWTtHQUNMO0dBQ00sV0FBQUQ7R0FBeUMsR0FDaEREO0VBQUs7Ozs7O0VBQ1ROLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBTztFQUFBUCxFQUFBLE1BQUFRO0NBQUE7RUFBQUEsS0FBQVIsRUFBQTtDQUFBO0NBQUEsT0FMRlE7QUFLRTs7QUFJTixTQUFBQyxXQUFBVixJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBQztDQUFBLElBQUFOLEVBQUEsT0FBQUQsSUFBQTtFQUFvQixFQUFBTSxXQUFBLEdBQUFDLFNBQUFQO0VBQW9EQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtDQUFBO0VBQUFELFlBQUFMLEVBQUE7RUFBQU0sUUFBQU4sRUFBQTtDQUFBO0NBQUEsSUFBQU87Q0FBQSxJQUFBUCxFQUFBLE9BQUFLLFdBQUE7RUFJdkRFLEtBQUFoQixHQUNULHVIQUNBYyxTQUNGO0VBQUNMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTztDQUFBO0VBQUFBLEtBQUFQLEVBQUE7Q0FBQTtDQUFBLElBQUFRO0NBQUEsSUFBQVIsRUFBQSxPQUFBTSxTQUFBTixFQUFBLE9BQUFPLElBQUE7RUFMSEMsS0FBQTtHQUNZO0dBQ0MsV0FBQUQ7R0FHVixHQUNHRDtFQUFLOzs7OztFQUNUTixFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBUTtDQUFBO0VBQUFBLEtBQUFSLEVBQUE7Q0FBQTtDQUFBLE9BUEZRO0FBT0U7O0FBSU4sU0FBQUUsaUJBQUFYLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBSztDQUFBLElBQUFDO0NBQUEsSUFBQU4sRUFBQSxPQUFBRCxJQUFBO0VBQTBCLEVBQUFNLFdBQUEsR0FBQUMsU0FBQVA7RUFHSUMsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07Q0FBQTtFQUFBRCxZQUFBTCxFQUFBO0VBQUFNLFFBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFPO0NBQUEsSUFBQVAsRUFBQSxPQUFBSyxXQUFBO0VBSWJFLEtBQUFoQixHQUNULDhKQUNBYyxTQUNGO0VBQUNMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTztDQUFBO0VBQUFBLEtBQUFQLEVBQUE7Q0FBQTtDQUFBLElBQUFRO0NBQUEsSUFBQVIsRUFBQSxPQUFBTSxTQUFBTixFQUFBLE9BQUFPLElBQUE7RUFMSEMsS0FBQTtHQUNZO0dBQ0MsV0FBQUQ7R0FHVixHQUNHRDtFQUFLOzs7OztFQUNUTixFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBUTtDQUFBO0VBQUFBLEtBQUFSLEVBQUE7Q0FBQTtDQUFBLE9BUEZRO0FBT0U7O0FBSU4sU0FBQUcsWUFBQVosSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFLO0NBQUEsSUFBQUM7Q0FBQSxJQUFBTixFQUFBLE9BQUFELElBQUE7RUFBcUIsRUFBQU0sV0FBQSxHQUFBQyxTQUFBUDtFQUFvREMsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07Q0FBQTtFQUFBRCxZQUFBTCxFQUFBO0VBQUFNLFFBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFPO0NBQUEsSUFBQVAsRUFBQSxPQUFBSyxXQUFBO0VBSXhERSxLQUFBaEIsR0FBRywwQkFBMEJjLFNBQVM7RUFBQ0wsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFPO0NBQUE7RUFBQUEsS0FBQVAsRUFBQTtDQUFBO0NBQUEsSUFBQVE7Q0FBQSxJQUFBUixFQUFBLE9BQUFNLFNBQUFOLEVBQUEsT0FBQU8sSUFBQTtFQUZwREMsS0FBQTtHQUNZO0dBQ0MsV0FBQUQ7R0FBdUMsR0FDOUNEO0VBQUs7Ozs7O0VBQ1ROLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBTztFQUFBUCxFQUFBLEtBQUFRO0NBQUE7RUFBQUEsS0FBQVIsRUFBQTtDQUFBO0NBQUEsT0FKRlE7QUFJRTs7QUFJTixTQUFTVixPQUFPVyxZQUFZQyxrQkFBa0JDIiwibmFtZXMiOlsiUmVhY3QiLCJjdmEiLCJjbiIsImFsZXJ0VmFyaWFudHMiLCJ2YXJpYW50cyIsInZhcmlhbnQiLCJkZWZhdWx0IiwiZGVzdHJ1Y3RpdmUiLCJkZWZhdWx0VmFyaWFudHMiLCJBbGVydCIsInQwIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJjbGFzc05hbWUiLCJwcm9wcyIsInQxIiwidDIiLCJBbGVydFRpdGxlIiwiQWxlcnREZXNjcmlwdGlvbiIsIkFsZXJ0QWN0aW9uIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImFsZXJ0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIlxuaW1wb3J0IHsgY3ZhLCB0eXBlIFZhcmlhbnRQcm9wcyB9IGZyb20gXCJjbGFzcy12YXJpYW5jZS1hdXRob3JpdHlcIlxuaW1wb3J0IHsgY24gfSBmcm9tIFwiY25cIlxuXG5jb25zdCBhbGVydFZhcmlhbnRzID0gY3ZhKFxuICBcImdyb3VwL2FsZXJ0IHJlbGF0aXZlIGdyaWQgdy1mdWxsIGdhcC0wLjUgcm91bmRlZC1sZyBib3JkZXIgcHgtMi41IHB5LTIgdGV4dC1sZWZ0IHRleHQtc20gaGFzLWRhdGEtW3Nsb3Q9YWxlcnQtYWN0aW9uXTpyZWxhdGl2ZSBoYXMtZGF0YS1bc2xvdD1hbGVydC1hY3Rpb25dOnByLTE4IGhhcy1bPnN2Z106Z3JpZC1jb2xzLVthdXRvXzFmcl0gaGFzLVs+c3ZnXTpnYXAteC0yICo6W3N2Z106cm93LXNwYW4tMiAqOltzdmddOnRyYW5zbGF0ZS15LTAuNSAqOltzdmddOnRleHQtY3VycmVudCAqOltzdmc6bm90KFtjbGFzcyo9J3NpemUtJ10pXTpzaXplLTRcIixcbiAge1xuICAgIHZhcmlhbnRzOiB7XG4gICAgICB2YXJpYW50OiB7XG4gICAgICAgIGRlZmF1bHQ6IFwiYmctY2FyZCB0ZXh0LWNhcmQtZm9yZWdyb3VuZFwiLFxuICAgICAgICBkZXN0cnVjdGl2ZTpcbiAgICAgICAgICBcImJnLWNhcmQgdGV4dC1kZXN0cnVjdGl2ZSAqOmRhdGEtW3Nsb3Q9YWxlcnQtZGVzY3JpcHRpb25dOnRleHQtZGVzdHJ1Y3RpdmUvOTAgKjpbc3ZnXTp0ZXh0LWN1cnJlbnRcIixcbiAgICAgIH0sXG4gICAgfSxcbiAgICBkZWZhdWx0VmFyaWFudHM6IHtcbiAgICAgIHZhcmlhbnQ6IFwiZGVmYXVsdFwiLFxuICAgIH0sXG4gIH1cbilcblxuZnVuY3Rpb24gQWxlcnQoe1xuICBjbGFzc05hbWUsXG4gIHZhcmlhbnQsXG4gIC4uLnByb3BzXG59OiBSZWFjdC5Db21wb25lbnRQcm9wczxcImRpdlwiPiAmIFZhcmlhbnRQcm9wczx0eXBlb2YgYWxlcnRWYXJpYW50cz4pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBkYXRhLXNsb3Q9XCJhbGVydFwiXG4gICAgICByb2xlPVwiYWxlcnRcIlxuICAgICAgY2xhc3NOYW1lPXtjbihhbGVydFZhcmlhbnRzKHsgdmFyaWFudCB9KSwgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIEFsZXJ0VGl0bGUoeyBjbGFzc05hbWUsIC4uLnByb3BzIH06IFJlYWN0LkNvbXBvbmVudFByb3BzPFwiZGl2XCI+KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgZGF0YS1zbG90PVwiYWxlcnQtdGl0bGVcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJmb250LW1lZGl1bSBncm91cC1oYXMtWz5zdmddL2FsZXJ0OmNvbC1zdGFydC0yIFsmX2FdOnVuZGVybGluZSBbJl9hXTp1bmRlcmxpbmUtb2Zmc2V0LTMgWyZfYV06aG92ZXI6dGV4dC1mb3JlZ3JvdW5kXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIEFsZXJ0RGVzY3JpcHRpb24oe1xuICBjbGFzc05hbWUsXG4gIC4uLnByb3BzXG59OiBSZWFjdC5Db21wb25lbnRQcm9wczxcImRpdlwiPikge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGRhdGEtc2xvdD1cImFsZXJ0LWRlc2NyaXB0aW9uXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwidGV4dC1zbSB0ZXh0LWJhbGFuY2UgdGV4dC1tdXRlZC1mb3JlZ3JvdW5kIG1kOnRleHQtcHJldHR5IFsmX2FdOnVuZGVybGluZSBbJl9hXTp1bmRlcmxpbmUtb2Zmc2V0LTMgWyZfYV06aG92ZXI6dGV4dC1mb3JlZ3JvdW5kIFsmX3A6bm90KDpsYXN0LWNoaWxkKV06bWItNFwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgLz5cbiAgKVxufVxuXG5mdW5jdGlvbiBBbGVydEFjdGlvbih7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfTogUmVhY3QuQ29tcG9uZW50UHJvcHM8XCJkaXZcIj4pIHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBkYXRhLXNsb3Q9XCJhbGVydC1hY3Rpb25cIlxuICAgICAgY2xhc3NOYW1lPXtjbihcImFic29sdXRlIHRvcC0yIHJpZ2h0LTJcIiwgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmV4cG9ydCB7IEFsZXJ0LCBBbGVydFRpdGxlLCBBbGVydERlc2NyaXB0aW9uLCBBbGVydEFjdGlvbiB9XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9jb21wb25lbnRzL3VpL2FsZXJ0LnRzeCJ9