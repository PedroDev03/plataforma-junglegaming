import { n as __exportAll, r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=e9f94b2e";
import { n as useRenderElement } from "/node_modules/.vite/deps/useRenderElement-CvMw8z9e.js?v=e9f94b2e";
import { t as useButton } from "/node_modules/.vite/deps/useButton-DC28DUmR.js?v=e9f94b2e";
/**
* A button component that can be used to trigger actions.
* Renders a `<button>` element.
*
* Documentation: [Base UI Button](https://base-ui.com/react/components/button)
*/
var Button = /*#__PURE__*/ (/* @__PURE__ */ __toESM(require_react(), 1)).forwardRef(function Button(componentProps, forwardedRef) {
	const { render, className, disabled = false, focusableWhenDisabled = false, nativeButton = true, style, ...elementProps } = componentProps;
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		focusableWhenDisabled,
		native: nativeButton
	});
	return useRenderElement("button", componentProps, {
		state: { disabled },
		ref: [forwardedRef, buttonRef],
		props: [elementProps, getButtonProps]
	});
});
Button.displayName = "Button";
// node_modules/@base-ui/react/button/ButtonDataAttributes.mjs
var ButtonDataAttributes_exports = /* @__PURE__ */ __exportAll({ disabled: () => disabled });
/**
* Present when the button is disabled.
*/
var disabled = "data-disabled";
export { Button, ButtonDataAttributes_exports as ButtonDataAttributes };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQGJhc2UtdWlfcmVhY3RfYnV0dG9uLmpzIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIi4uLy4uL0BiYXNlLXVpL3JlYWN0L2J1dHRvbi9CdXR0b24ubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvYnV0dG9uL0J1dHRvbkRhdGFBdHRyaWJ1dGVzLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIGNsaWVudCc7XG5cbmltcG9ydCAqIGFzIFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCB7IHVzZUJ1dHRvbiB9IGZyb20gXCIuLi9pbnRlcm5hbHMvdXNlLWJ1dHRvbi91c2VCdXR0b24ubWpzXCI7XG5pbXBvcnQgeyB1c2VSZW5kZXJFbGVtZW50IH0gZnJvbSBcIi4uL2ludGVybmFscy91c2VSZW5kZXJFbGVtZW50Lm1qc1wiO1xuLyoqXG4gKiBBIGJ1dHRvbiBjb21wb25lbnQgdGhhdCBjYW4gYmUgdXNlZCB0byB0cmlnZ2VyIGFjdGlvbnMuXG4gKiBSZW5kZXJzIGEgYDxidXR0b24+YCBlbGVtZW50LlxuICpcbiAqIERvY3VtZW50YXRpb246IFtCYXNlIFVJIEJ1dHRvbl0oaHR0cHM6Ly9iYXNlLXVpLmNvbS9yZWFjdC9jb21wb25lbnRzL2J1dHRvbilcbiAqL1xuZXhwb3J0IGNvbnN0IEJ1dHRvbiA9IC8qI19fUFVSRV9fKi9SZWFjdC5mb3J3YXJkUmVmKGZ1bmN0aW9uIEJ1dHRvbihjb21wb25lbnRQcm9wcywgZm9yd2FyZGVkUmVmKSB7XG4gIGNvbnN0IHtcbiAgICByZW5kZXIsXG4gICAgY2xhc3NOYW1lLFxuICAgIGRpc2FibGVkID0gZmFsc2UsXG4gICAgZm9jdXNhYmxlV2hlbkRpc2FibGVkID0gZmFsc2UsXG4gICAgbmF0aXZlQnV0dG9uID0gdHJ1ZSxcbiAgICBzdHlsZSxcbiAgICAuLi5lbGVtZW50UHJvcHNcbiAgfSA9IGNvbXBvbmVudFByb3BzO1xuICBjb25zdCB7XG4gICAgZ2V0QnV0dG9uUHJvcHMsXG4gICAgYnV0dG9uUmVmXG4gIH0gPSB1c2VCdXR0b24oe1xuICAgIGRpc2FibGVkLFxuICAgIGZvY3VzYWJsZVdoZW5EaXNhYmxlZCxcbiAgICBuYXRpdmU6IG5hdGl2ZUJ1dHRvblxuICB9KTtcbiAgY29uc3Qgc3RhdGUgPSB7XG4gICAgZGlzYWJsZWRcbiAgfTtcbiAgcmV0dXJuIHVzZVJlbmRlckVsZW1lbnQoJ2J1dHRvbicsIGNvbXBvbmVudFByb3BzLCB7XG4gICAgc3RhdGUsXG4gICAgcmVmOiBbZm9yd2FyZGVkUmVmLCBidXR0b25SZWZdLFxuICAgIHByb3BzOiBbZWxlbWVudFByb3BzLCBnZXRCdXR0b25Qcm9wc11cbiAgfSk7XG59KTtcbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIEJ1dHRvbi5kaXNwbGF5TmFtZSA9IFwiQnV0dG9uXCI7IiwiLyoqXG4gKiBQcmVzZW50IHdoZW4gdGhlIGJ1dHRvbiBpcyBkaXNhYmxlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IGRpc2FibGVkID0gJ2RhdGEtZGlzYWJsZWQnOyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQVdBLElBQWEsU0FBc0IsK0IsMEJBQUEsRUFBQSxDQUFNLFdBQVcsU0FBUyxPQUFPLGdCQUFnQixjQUFjO0NBQ2hHLE1BQU0sRUFDSixRQUNBLFdBQ0EsV0FBVyxPQUNYLHdCQUF3QixPQUN4QixlQUFlLE1BQ2YsT0FDQSxHQUFHLGlCQUNEO0NBQ0osTUFBTSxFQUNKLGdCQUNBLGNBQ0UsVUFBVTtFQUNaO0VBQ0E7RUFDQSxRQUFRO0NBQ1YsQ0FBQztDQUlELE9BQU8saUJBQWlCLFVBQVUsZ0JBQWdCO0VBQ2hELE9BQUEsRUFIQSxTQUdJO0VBQ0osS0FBSyxDQUFDLGNBQWMsU0FBUztFQUM3QixPQUFPLENBQUMsY0FBYyxjQUFjO0NBQ3RDLENBQUM7QUFDSCxDQUFDO0FBQzBDLE9BQU8sY0FBYzs7Ozs7O0FDbkNoRSxJQUFhLFdBQVciLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMCwxXX0=