// node_modules/decimal.js/decimal.mjs
/*!
*  decimal.js v10.6.0
*  An arbitrary-precision Decimal type for JavaScript.
*  https://github.com/MikeMcl/decimal.js
*  Copyright (c) 2025 Michael Mclaughlin <M8ch88l@gmail.com>
*  MIT Licence
*/
var EXP_LIMIT = 9e15;
var MAX_DIGITS = 1e9;
var NUMERALS = "0123456789abcdef";
var LN10 = "2.3025850929940456840179914546843642076011014886287729760333279009675726096773524802359972050895982983419677840422862486334095254650828067566662873690987816894829072083255546808437998948262331985283935053089653777326288461633662222876982198867465436674744042432743651550489343149393914796194044002221051017141748003688084012647080685567743216228355220114804663715659121373450747856947683463616792101806445070648000277502684916746550586856935673420670581136429224554405758925724208241314695689016758940256776311356919292033376587141660230105703089634572075440370847469940168269282808481184289314848524948644871927809676271275775397027668605952496716674183485704422507197965004714951050492214776567636938662976979522110718264549734772662425709429322582798502585509785265383207606726317164309505995087807523710333101197857547331541421808427543863591778117054309827482385045648019095610299291824318237525357709750539565187697510374970888692180205189339507238539205144634197265287286965110862571492198849978748873771345686209167058";
var PI = "3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679821480865132823066470938446095505822317253594081284811174502841027019385211055596446229489549303819644288109756659334461284756482337867831652712019091456485669234603486104543266482133936072602491412737245870066063155881748815209209628292540917153643678925903600113305305488204665213841469519415116094330572703657595919530921861173819326117931051185480744623799627495673518857527248912279381830119491298336733624406566430860213949463952247371907021798609437027705392171762931767523846748184676694051320005681271452635608277857713427577896091736371787214684409012249534301465495853710507922796892589235420199561121290219608640344181598136297747713099605187072113499999983729780499510597317328160963185950244594553469083026425223082533446850352619311881710100031378387528865875332083814206171776691473035982534904287554687311595628638823537875937519577818577805321712268066130019278766111959092164201989380952572010654858632789";
var DEFAULTS = {
	precision: 20,
	rounding: 4,
	modulo: 1,
	toExpNeg: -7,
	toExpPos: 21,
	minE: -EXP_LIMIT,
	maxE: EXP_LIMIT,
	crypto: false
};
var inexact;
var quadrant;
var external = true;
var decimalError = "[DecimalError] ";
var invalidArgument = decimalError + "Invalid argument: ";
var precisionLimitExceeded = decimalError + "Precision limit exceeded";
var cryptoUnavailable = decimalError + "crypto unavailable";
var tag = "[object Decimal]";
var mathfloor = Math.floor;
var mathpow = Math.pow;
var isBinary = /^0b([01]+(\.[01]*)?|\.[01]+)(p[+-]?\d+)?$/i;
var isHex = /^0x([0-9a-f]+(\.[0-9a-f]*)?|\.[0-9a-f]+)(p[+-]?\d+)?$/i;
var isOctal = /^0o([0-7]+(\.[0-7]*)?|\.[0-7]+)(p[+-]?\d+)?$/i;
var isDecimal = /^(\d+(\.\d*)?|\.\d+)(e[+-]?\d+)?$/i;
var BASE = 1e7;
var LOG_BASE = 7;
var MAX_SAFE_INTEGER = 9007199254740991;
var LN10_PRECISION = LN10.length - 1;
var PI_PRECISION = PI.length - 1;
var P = { toStringTag: tag };
P.absoluteValue = P.abs = function() {
	var x = new this.constructor(this);
	if (x.s < 0) x.s = 1;
	return finalise(x);
};
P.ceil = function() {
	return finalise(new this.constructor(this), this.e + 1, 2);
};
P.clampedTo = P.clamp = function(min, max) {
	var k, x = this, Ctor = x.constructor;
	min = new Ctor(min);
	max = new Ctor(max);
	if (!min.s || !max.s) return new Ctor(NaN);
	if (min.gt(max)) throw Error(invalidArgument + max);
	k = x.cmp(min);
	return k < 0 ? min : x.cmp(max) > 0 ? max : new Ctor(x);
};
P.comparedTo = P.cmp = function(y) {
	var i, j, xdL, ydL, x = this, xd = x.d, yd = (y = new x.constructor(y)).d, xs = x.s, ys = y.s;
	if (!xd || !yd) return !xs || !ys ? NaN : xs !== ys ? xs : xd === yd ? 0 : !xd ^ xs < 0 ? 1 : -1;
	if (!xd[0] || !yd[0]) return xd[0] ? xs : yd[0] ? -ys : 0;
	if (xs !== ys) return xs;
	if (x.e !== y.e) return x.e > y.e ^ xs < 0 ? 1 : -1;
	xdL = xd.length;
	ydL = yd.length;
	for (i = 0, j = xdL < ydL ? xdL : ydL; i < j; ++i) if (xd[i] !== yd[i]) return xd[i] > yd[i] ^ xs < 0 ? 1 : -1;
	return xdL === ydL ? 0 : xdL > ydL ^ xs < 0 ? 1 : -1;
};
P.cosine = P.cos = function() {
	var pr, rm, x = this, Ctor = x.constructor;
	if (!x.d) return new Ctor(NaN);
	if (!x.d[0]) return new Ctor(1);
	pr = Ctor.precision;
	rm = Ctor.rounding;
	Ctor.precision = pr + Math.max(x.e, x.sd()) + LOG_BASE;
	Ctor.rounding = 1;
	x = cosine(Ctor, toLessThanHalfPi(Ctor, x));
	Ctor.precision = pr;
	Ctor.rounding = rm;
	return finalise(quadrant == 2 || quadrant == 3 ? x.neg() : x, pr, rm, true);
};
P.cubeRoot = P.cbrt = function() {
	var e, m, n, r, rep, s, sd, t, t3, t3plusx, x = this, Ctor = x.constructor;
	if (!x.isFinite() || x.isZero()) return new Ctor(x);
	external = false;
	s = x.s * mathpow(x.s * x, 1 / 3);
	if (!s || Math.abs(s) == 1 / 0) {
		n = digitsToString(x.d);
		e = x.e;
		if (s = (e - n.length + 1) % 3) n += s == 1 || s == -2 ? "0" : "00";
		s = mathpow(n, 1 / 3);
		e = mathfloor((e + 1) / 3) - (e % 3 == (e < 0 ? -1 : 2));
		if (s == 1 / 0) n = "5e" + e;
		else {
			n = s.toExponential();
			n = n.slice(0, n.indexOf("e") + 1) + e;
		}
		r = new Ctor(n);
		r.s = x.s;
	} else r = new Ctor(s.toString());
	sd = (e = Ctor.precision) + 3;
	for (;;) {
		t = r;
		t3 = t.times(t).times(t);
		t3plusx = t3.plus(x);
		r = divide(t3plusx.plus(x).times(t), t3plusx.plus(t3), sd + 2, 1);
		if (digitsToString(t.d).slice(0, sd) === (n = digitsToString(r.d)).slice(0, sd)) {
			n = n.slice(sd - 3, sd + 1);
			if (n == "9999" || !rep && n == "4999") {
				if (!rep) {
					finalise(t, e + 1, 0);
					if (t.times(t).times(t).eq(x)) {
						r = t;
						break;
					}
				}
				sd += 4;
				rep = 1;
			} else {
				if (!+n || !+n.slice(1) && n.charAt(0) == "5") {
					finalise(r, e + 1, 1);
					m = !r.times(r).times(r).eq(x);
				}
				break;
			}
		}
	}
	external = true;
	return finalise(r, e, Ctor.rounding, m);
};
P.decimalPlaces = P.dp = function() {
	var w, d = this.d, n = NaN;
	if (d) {
		w = d.length - 1;
		n = (w - mathfloor(this.e / LOG_BASE)) * LOG_BASE;
		w = d[w];
		if (w) for (; w % 10 == 0; w /= 10) n--;
		if (n < 0) n = 0;
	}
	return n;
};
P.dividedBy = P.div = function(y) {
	return divide(this, new this.constructor(y));
};
P.dividedToIntegerBy = P.divToInt = function(y) {
	var x = this, Ctor = x.constructor;
	return finalise(divide(x, new Ctor(y), 0, 1, 1), Ctor.precision, Ctor.rounding);
};
P.equals = P.eq = function(y) {
	return this.cmp(y) === 0;
};
P.floor = function() {
	return finalise(new this.constructor(this), this.e + 1, 3);
};
P.greaterThan = P.gt = function(y) {
	return this.cmp(y) > 0;
};
P.greaterThanOrEqualTo = P.gte = function(y) {
	var k = this.cmp(y);
	return k == 1 || k === 0;
};
P.hyperbolicCosine = P.cosh = function() {
	var k, n, pr, rm, len, x = this, Ctor = x.constructor, one = new Ctor(1);
	if (!x.isFinite()) return new Ctor(x.s ? 1 / 0 : NaN);
	if (x.isZero()) return one;
	pr = Ctor.precision;
	rm = Ctor.rounding;
	Ctor.precision = pr + Math.max(x.e, x.sd()) + 4;
	Ctor.rounding = 1;
	len = x.d.length;
	if (len < 32) {
		k = Math.ceil(len / 3);
		n = (1 / tinyPow(4, k)).toString();
	} else {
		k = 16;
		n = "2.3283064365386962890625e-10";
	}
	x = taylorSeries(Ctor, 1, x.times(n), new Ctor(1), true);
	var cosh2_x, i = k, d8 = new Ctor(8);
	for (; i--;) {
		cosh2_x = x.times(x);
		x = one.minus(cosh2_x.times(d8.minus(cosh2_x.times(d8))));
	}
	return finalise(x, Ctor.precision = pr, Ctor.rounding = rm, true);
};
P.hyperbolicSine = P.sinh = function() {
	var k, pr, rm, len, x = this, Ctor = x.constructor;
	if (!x.isFinite() || x.isZero()) return new Ctor(x);
	pr = Ctor.precision;
	rm = Ctor.rounding;
	Ctor.precision = pr + Math.max(x.e, x.sd()) + 4;
	Ctor.rounding = 1;
	len = x.d.length;
	if (len < 3) x = taylorSeries(Ctor, 2, x, x, true);
	else {
		k = 1.4 * Math.sqrt(len);
		k = k > 16 ? 16 : k | 0;
		x = x.times(1 / tinyPow(5, k));
		x = taylorSeries(Ctor, 2, x, x, true);
		var sinh2_x, d5 = new Ctor(5), d16 = new Ctor(16), d20 = new Ctor(20);
		for (; k--;) {
			sinh2_x = x.times(x);
			x = x.times(d5.plus(sinh2_x.times(d16.times(sinh2_x).plus(d20))));
		}
	}
	Ctor.precision = pr;
	Ctor.rounding = rm;
	return finalise(x, pr, rm, true);
};
P.hyperbolicTangent = P.tanh = function() {
	var pr, rm, x = this, Ctor = x.constructor;
	if (!x.isFinite()) return new Ctor(x.s);
	if (x.isZero()) return new Ctor(x);
	pr = Ctor.precision;
	rm = Ctor.rounding;
	Ctor.precision = pr + 7;
	Ctor.rounding = 1;
	return divide(x.sinh(), x.cosh(), Ctor.precision = pr, Ctor.rounding = rm);
};
P.inverseCosine = P.acos = function() {
	var x = this, Ctor = x.constructor, k = x.abs().cmp(1), pr = Ctor.precision, rm = Ctor.rounding;
	if (k !== -1) return k === 0 ? x.isNeg() ? getPi(Ctor, pr, rm) : new Ctor(0) : new Ctor(NaN);
	if (x.isZero()) return getPi(Ctor, pr + 4, rm).times(.5);
	Ctor.precision = pr + 6;
	Ctor.rounding = 1;
	x = new Ctor(1).minus(x).div(x.plus(1)).sqrt().atan();
	Ctor.precision = pr;
	Ctor.rounding = rm;
	return x.times(2);
};
P.inverseHyperbolicCosine = P.acosh = function() {
	var pr, rm, x = this, Ctor = x.constructor;
	if (x.lte(1)) return new Ctor(x.eq(1) ? 0 : NaN);
	if (!x.isFinite()) return new Ctor(x);
	pr = Ctor.precision;
	rm = Ctor.rounding;
	Ctor.precision = pr + Math.max(Math.abs(x.e), x.sd()) + 4;
	Ctor.rounding = 1;
	external = false;
	x = x.times(x).minus(1).sqrt().plus(x);
	external = true;
	Ctor.precision = pr;
	Ctor.rounding = rm;
	return x.ln();
};
P.inverseHyperbolicSine = P.asinh = function() {
	var pr, rm, x = this, Ctor = x.constructor;
	if (!x.isFinite() || x.isZero()) return new Ctor(x);
	pr = Ctor.precision;
	rm = Ctor.rounding;
	Ctor.precision = pr + 2 * Math.max(Math.abs(x.e), x.sd()) + 6;
	Ctor.rounding = 1;
	external = false;
	x = x.times(x).plus(1).sqrt().plus(x);
	external = true;
	Ctor.precision = pr;
	Ctor.rounding = rm;
	return x.ln();
};
P.inverseHyperbolicTangent = P.atanh = function() {
	var pr, rm, wpr, xsd, x = this, Ctor = x.constructor;
	if (!x.isFinite()) return new Ctor(NaN);
	if (x.e >= 0) return new Ctor(x.abs().eq(1) ? x.s / 0 : x.isZero() ? x : NaN);
	pr = Ctor.precision;
	rm = Ctor.rounding;
	xsd = x.sd();
	if (Math.max(xsd, pr) < 2 * -x.e - 1) return finalise(new Ctor(x), pr, rm, true);
	Ctor.precision = wpr = xsd - x.e;
	x = divide(x.plus(1), new Ctor(1).minus(x), wpr + pr, 1);
	Ctor.precision = pr + 4;
	Ctor.rounding = 1;
	x = x.ln();
	Ctor.precision = pr;
	Ctor.rounding = rm;
	return x.times(.5);
};
P.inverseSine = P.asin = function() {
	var halfPi, k, pr, rm, x = this, Ctor = x.constructor;
	if (x.isZero()) return new Ctor(x);
	k = x.abs().cmp(1);
	pr = Ctor.precision;
	rm = Ctor.rounding;
	if (k !== -1) {
		if (k === 0) {
			halfPi = getPi(Ctor, pr + 4, rm).times(.5);
			halfPi.s = x.s;
			return halfPi;
		}
		return new Ctor(NaN);
	}
	Ctor.precision = pr + 6;
	Ctor.rounding = 1;
	x = x.div(new Ctor(1).minus(x.times(x)).sqrt().plus(1)).atan();
	Ctor.precision = pr;
	Ctor.rounding = rm;
	return x.times(2);
};
P.inverseTangent = P.atan = function() {
	var i, j, k, n, px, t, r, wpr, x2, x = this, Ctor = x.constructor, pr = Ctor.precision, rm = Ctor.rounding;
	if (!x.isFinite()) {
		if (!x.s) return new Ctor(NaN);
		if (pr + 4 <= PI_PRECISION) {
			r = getPi(Ctor, pr + 4, rm).times(.5);
			r.s = x.s;
			return r;
		}
	} else if (x.isZero()) return new Ctor(x);
	else if (x.abs().eq(1) && pr + 4 <= PI_PRECISION) {
		r = getPi(Ctor, pr + 4, rm).times(.25);
		r.s = x.s;
		return r;
	}
	Ctor.precision = wpr = pr + 10;
	Ctor.rounding = 1;
	k = Math.min(28, wpr / LOG_BASE + 2 | 0);
	for (i = k; i; --i) x = x.div(x.times(x).plus(1).sqrt().plus(1));
	external = false;
	j = Math.ceil(wpr / LOG_BASE);
	n = 1;
	x2 = x.times(x);
	r = new Ctor(x);
	px = x;
	for (; i !== -1;) {
		px = px.times(x2);
		t = r.minus(px.div(n += 2));
		px = px.times(x2);
		r = t.plus(px.div(n += 2));
		if (r.d[j] !== void 0) for (i = j; r.d[i] === t.d[i] && i--;);
	}
	if (k) r = r.times(2 << k - 1);
	external = true;
	return finalise(r, Ctor.precision = pr, Ctor.rounding = rm, true);
};
P.isFinite = function() {
	return !!this.d;
};
P.isInteger = P.isInt = function() {
	return !!this.d && mathfloor(this.e / LOG_BASE) > this.d.length - 2;
};
P.isNaN = function() {
	return !this.s;
};
P.isNegative = P.isNeg = function() {
	return this.s < 0;
};
P.isPositive = P.isPos = function() {
	return this.s > 0;
};
P.isZero = function() {
	return !!this.d && this.d[0] === 0;
};
P.lessThan = P.lt = function(y) {
	return this.cmp(y) < 0;
};
P.lessThanOrEqualTo = P.lte = function(y) {
	return this.cmp(y) < 1;
};
P.logarithm = P.log = function(base) {
	var isBase10, d, denominator, k, inf, num, sd, r, arg = this, Ctor = arg.constructor, pr = Ctor.precision, rm = Ctor.rounding, guard = 5;
	if (base == null) {
		base = new Ctor(10);
		isBase10 = true;
	} else {
		base = new Ctor(base);
		d = base.d;
		if (base.s < 0 || !d || !d[0] || base.eq(1)) return new Ctor(NaN);
		isBase10 = base.eq(10);
	}
	d = arg.d;
	if (arg.s < 0 || !d || !d[0] || arg.eq(1)) return new Ctor(d && !d[0] ? -1 / 0 : arg.s != 1 ? NaN : d ? 0 : 1 / 0);
	if (isBase10) {
		if (d.length > 1) inf = true;
		else {
			for (k = d[0]; k % 10 === 0;) k /= 10;
			inf = k !== 1;
		}
	}
	external = false;
	sd = pr + guard;
	num = naturalLogarithm(arg, sd);
	denominator = isBase10 ? getLn10(Ctor, sd + 10) : naturalLogarithm(base, sd);
	r = divide(num, denominator, sd, 1);
	if (checkRoundingDigits(r.d, k = pr, rm)) do {
		sd += 10;
		num = naturalLogarithm(arg, sd);
		denominator = isBase10 ? getLn10(Ctor, sd + 10) : naturalLogarithm(base, sd);
		r = divide(num, denominator, sd, 1);
		if (!inf) {
			if (+digitsToString(r.d).slice(k + 1, k + 15) + 1 == 0x5af3107a4000) r = finalise(r, pr + 1, 0);
			break;
		}
	} while (checkRoundingDigits(r.d, k += 10, rm));
	external = true;
	return finalise(r, pr, rm);
};
P.minus = P.sub = function(y) {
	var d, e, i, j, k, len, pr, rm, xd, xe, xLTy, yd, x = this, Ctor = x.constructor;
	y = new Ctor(y);
	if (!x.d || !y.d) {
		if (!x.s || !y.s) y = new Ctor(NaN);
		else if (x.d) y.s = -y.s;
		else y = new Ctor(y.d || x.s !== y.s ? x : NaN);
		return y;
	}
	if (x.s != y.s) {
		y.s = -y.s;
		return x.plus(y);
	}
	xd = x.d;
	yd = y.d;
	pr = Ctor.precision;
	rm = Ctor.rounding;
	if (!xd[0] || !yd[0]) {
		if (yd[0]) y.s = -y.s;
		else if (xd[0]) y = new Ctor(x);
		else return new Ctor(rm === 3 ? -0 : 0);
		return external ? finalise(y, pr, rm) : y;
	}
	e = mathfloor(y.e / LOG_BASE);
	xe = mathfloor(x.e / LOG_BASE);
	xd = xd.slice();
	k = xe - e;
	if (k) {
		xLTy = k < 0;
		if (xLTy) {
			d = xd;
			k = -k;
			len = yd.length;
		} else {
			d = yd;
			e = xe;
			len = xd.length;
		}
		i = Math.max(Math.ceil(pr / LOG_BASE), len) + 2;
		if (k > i) {
			k = i;
			d.length = 1;
		}
		d.reverse();
		for (i = k; i--;) d.push(0);
		d.reverse();
	} else {
		i = xd.length;
		len = yd.length;
		xLTy = i < len;
		if (xLTy) len = i;
		for (i = 0; i < len; i++) if (xd[i] != yd[i]) {
			xLTy = xd[i] < yd[i];
			break;
		}
		k = 0;
	}
	if (xLTy) {
		d = xd;
		xd = yd;
		yd = d;
		y.s = -y.s;
	}
	len = xd.length;
	for (i = yd.length - len; i > 0; --i) xd[len++] = 0;
	for (i = yd.length; i > k;) {
		if (xd[--i] < yd[i]) {
			for (j = i; j && xd[--j] === 0;) xd[j] = BASE - 1;
			--xd[j];
			xd[i] += BASE;
		}
		xd[i] -= yd[i];
	}
	for (; xd[--len] === 0;) xd.pop();
	for (; xd[0] === 0; xd.shift()) --e;
	if (!xd[0]) return new Ctor(rm === 3 ? -0 : 0);
	y.d = xd;
	y.e = getBase10Exponent(xd, e);
	return external ? finalise(y, pr, rm) : y;
};
P.modulo = P.mod = function(y) {
	var q, x = this, Ctor = x.constructor;
	y = new Ctor(y);
	if (!x.d || !y.s || y.d && !y.d[0]) return new Ctor(NaN);
	if (!y.d || x.d && !x.d[0]) return finalise(new Ctor(x), Ctor.precision, Ctor.rounding);
	external = false;
	if (Ctor.modulo == 9) {
		q = divide(x, y.abs(), 0, 3, 1);
		q.s *= y.s;
	} else q = divide(x, y, 0, Ctor.modulo, 1);
	q = q.times(y);
	external = true;
	return x.minus(q);
};
P.naturalExponential = P.exp = function() {
	return naturalExponential(this);
};
P.naturalLogarithm = P.ln = function() {
	return naturalLogarithm(this);
};
P.negated = P.neg = function() {
	var x = new this.constructor(this);
	x.s = -x.s;
	return finalise(x);
};
P.plus = P.add = function(y) {
	var carry, d, e, i, k, len, pr, rm, xd, yd, x = this, Ctor = x.constructor;
	y = new Ctor(y);
	if (!x.d || !y.d) {
		if (!x.s || !y.s) y = new Ctor(NaN);
		else if (!x.d) y = new Ctor(y.d || x.s === y.s ? x : NaN);
		return y;
	}
	if (x.s != y.s) {
		y.s = -y.s;
		return x.minus(y);
	}
	xd = x.d;
	yd = y.d;
	pr = Ctor.precision;
	rm = Ctor.rounding;
	if (!xd[0] || !yd[0]) {
		if (!yd[0]) y = new Ctor(x);
		return external ? finalise(y, pr, rm) : y;
	}
	k = mathfloor(x.e / LOG_BASE);
	e = mathfloor(y.e / LOG_BASE);
	xd = xd.slice();
	i = k - e;
	if (i) {
		if (i < 0) {
			d = xd;
			i = -i;
			len = yd.length;
		} else {
			d = yd;
			e = k;
			len = xd.length;
		}
		k = Math.ceil(pr / LOG_BASE);
		len = k > len ? k + 1 : len + 1;
		if (i > len) {
			i = len;
			d.length = 1;
		}
		d.reverse();
		for (; i--;) d.push(0);
		d.reverse();
	}
	len = xd.length;
	i = yd.length;
	if (len - i < 0) {
		i = len;
		d = yd;
		yd = xd;
		xd = d;
	}
	for (carry = 0; i;) {
		carry = (xd[--i] = xd[i] + yd[i] + carry) / BASE | 0;
		xd[i] %= BASE;
	}
	if (carry) {
		xd.unshift(carry);
		++e;
	}
	for (len = xd.length; xd[--len] == 0;) xd.pop();
	y.d = xd;
	y.e = getBase10Exponent(xd, e);
	return external ? finalise(y, pr, rm) : y;
};
P.precision = P.sd = function(z) {
	var k, x = this;
	if (z !== void 0 && z !== !!z && z !== 1 && z !== 0) throw Error(invalidArgument + z);
	if (x.d) {
		k = getPrecision(x.d);
		if (z && x.e + 1 > k) k = x.e + 1;
	} else k = NaN;
	return k;
};
P.round = function() {
	var x = this, Ctor = x.constructor;
	return finalise(new Ctor(x), x.e + 1, Ctor.rounding);
};
P.sine = P.sin = function() {
	var pr, rm, x = this, Ctor = x.constructor;
	if (!x.isFinite()) return new Ctor(NaN);
	if (x.isZero()) return new Ctor(x);
	pr = Ctor.precision;
	rm = Ctor.rounding;
	Ctor.precision = pr + Math.max(x.e, x.sd()) + LOG_BASE;
	Ctor.rounding = 1;
	x = sine(Ctor, toLessThanHalfPi(Ctor, x));
	Ctor.precision = pr;
	Ctor.rounding = rm;
	return finalise(quadrant > 2 ? x.neg() : x, pr, rm, true);
};
P.squareRoot = P.sqrt = function() {
	var m, n, sd, r, rep, t, x = this, d = x.d, e = x.e, s = x.s, Ctor = x.constructor;
	if (s !== 1 || !d || !d[0]) return new Ctor(!s || s < 0 && (!d || d[0]) ? NaN : d ? x : 1 / 0);
	external = false;
	s = Math.sqrt(+x);
	if (s == 0 || s == 1 / 0) {
		n = digitsToString(d);
		if ((n.length + e) % 2 == 0) n += "0";
		s = Math.sqrt(n);
		e = mathfloor((e + 1) / 2) - (e < 0 || e % 2);
		if (s == 1 / 0) n = "5e" + e;
		else {
			n = s.toExponential();
			n = n.slice(0, n.indexOf("e") + 1) + e;
		}
		r = new Ctor(n);
	} else r = new Ctor(s.toString());
	sd = (e = Ctor.precision) + 3;
	for (;;) {
		t = r;
		r = t.plus(divide(x, t, sd + 2, 1)).times(.5);
		if (digitsToString(t.d).slice(0, sd) === (n = digitsToString(r.d)).slice(0, sd)) {
			n = n.slice(sd - 3, sd + 1);
			if (n == "9999" || !rep && n == "4999") {
				if (!rep) {
					finalise(t, e + 1, 0);
					if (t.times(t).eq(x)) {
						r = t;
						break;
					}
				}
				sd += 4;
				rep = 1;
			} else {
				if (!+n || !+n.slice(1) && n.charAt(0) == "5") {
					finalise(r, e + 1, 1);
					m = !r.times(r).eq(x);
				}
				break;
			}
		}
	}
	external = true;
	return finalise(r, e, Ctor.rounding, m);
};
P.tangent = P.tan = function() {
	var pr, rm, x = this, Ctor = x.constructor;
	if (!x.isFinite()) return new Ctor(NaN);
	if (x.isZero()) return new Ctor(x);
	pr = Ctor.precision;
	rm = Ctor.rounding;
	Ctor.precision = pr + 10;
	Ctor.rounding = 1;
	x = x.sin();
	x.s = 1;
	x = divide(x, new Ctor(1).minus(x.times(x)).sqrt(), pr + 10, 0);
	Ctor.precision = pr;
	Ctor.rounding = rm;
	return finalise(quadrant == 2 || quadrant == 4 ? x.neg() : x, pr, rm, true);
};
P.times = P.mul = function(y) {
	var carry, e, i, k, r, rL, t, xdL, ydL, x = this, Ctor = x.constructor, xd = x.d, yd = (y = new Ctor(y)).d;
	y.s *= x.s;
	if (!xd || !xd[0] || !yd || !yd[0]) return new Ctor(!y.s || xd && !xd[0] && !yd || yd && !yd[0] && !xd ? NaN : !xd || !yd ? y.s / 0 : y.s * 0);
	e = mathfloor(x.e / LOG_BASE) + mathfloor(y.e / LOG_BASE);
	xdL = xd.length;
	ydL = yd.length;
	if (xdL < ydL) {
		r = xd;
		xd = yd;
		yd = r;
		rL = xdL;
		xdL = ydL;
		ydL = rL;
	}
	r = [];
	rL = xdL + ydL;
	for (i = rL; i--;) r.push(0);
	for (i = ydL; --i >= 0;) {
		carry = 0;
		for (k = xdL + i; k > i;) {
			t = r[k] + yd[i] * xd[k - i - 1] + carry;
			r[k--] = t % BASE | 0;
			carry = t / BASE | 0;
		}
		r[k] = (r[k] + carry) % BASE | 0;
	}
	for (; !r[--rL];) r.pop();
	if (carry) ++e;
	else r.shift();
	y.d = r;
	y.e = getBase10Exponent(r, e);
	return external ? finalise(y, Ctor.precision, Ctor.rounding) : y;
};
P.toBinary = function(sd, rm) {
	return toStringBinary(this, 2, sd, rm);
};
P.toDecimalPlaces = P.toDP = function(dp, rm) {
	var x = this, Ctor = x.constructor;
	x = new Ctor(x);
	if (dp === void 0) return x;
	checkInt32(dp, 0, MAX_DIGITS);
	if (rm === void 0) rm = Ctor.rounding;
	else checkInt32(rm, 0, 8);
	return finalise(x, dp + x.e + 1, rm);
};
P.toExponential = function(dp, rm) {
	var str, x = this, Ctor = x.constructor;
	if (dp === void 0) str = finiteToString(x, true);
	else {
		checkInt32(dp, 0, MAX_DIGITS);
		if (rm === void 0) rm = Ctor.rounding;
		else checkInt32(rm, 0, 8);
		x = finalise(new Ctor(x), dp + 1, rm);
		str = finiteToString(x, true, dp + 1);
	}
	return x.isNeg() && !x.isZero() ? "-" + str : str;
};
P.toFixed = function(dp, rm) {
	var str, y, x = this, Ctor = x.constructor;
	if (dp === void 0) str = finiteToString(x);
	else {
		checkInt32(dp, 0, MAX_DIGITS);
		if (rm === void 0) rm = Ctor.rounding;
		else checkInt32(rm, 0, 8);
		y = finalise(new Ctor(x), dp + x.e + 1, rm);
		str = finiteToString(y, false, dp + y.e + 1);
	}
	return x.isNeg() && !x.isZero() ? "-" + str : str;
};
P.toFraction = function(maxD) {
	var d, d0, d1, d2, e, k, n, n0, n1, pr, q, r, x = this, xd = x.d, Ctor = x.constructor;
	if (!xd) return new Ctor(x);
	n1 = d0 = new Ctor(1);
	d1 = n0 = new Ctor(0);
	d = new Ctor(d1);
	e = d.e = getPrecision(xd) - x.e - 1;
	k = e % LOG_BASE;
	d.d[0] = mathpow(10, k < 0 ? LOG_BASE + k : k);
	if (maxD == null) maxD = e > 0 ? d : n1;
	else {
		n = new Ctor(maxD);
		if (!n.isInt() || n.lt(n1)) throw Error(invalidArgument + n);
		maxD = n.gt(d) ? e > 0 ? d : n1 : n;
	}
	external = false;
	n = new Ctor(digitsToString(xd));
	pr = Ctor.precision;
	Ctor.precision = e = xd.length * LOG_BASE * 2;
	for (;;) {
		q = divide(n, d, 0, 1, 1);
		d2 = d0.plus(q.times(d1));
		if (d2.cmp(maxD) == 1) break;
		d0 = d1;
		d1 = d2;
		d2 = n1;
		n1 = n0.plus(q.times(d2));
		n0 = d2;
		d2 = d;
		d = n.minus(q.times(d2));
		n = d2;
	}
	d2 = divide(maxD.minus(d0), d1, 0, 1, 1);
	n0 = n0.plus(d2.times(n1));
	d0 = d0.plus(d2.times(d1));
	n0.s = n1.s = x.s;
	r = divide(n1, d1, e, 1).minus(x).abs().cmp(divide(n0, d0, e, 1).minus(x).abs()) < 1 ? [n1, d1] : [n0, d0];
	Ctor.precision = pr;
	external = true;
	return r;
};
P.toHexadecimal = P.toHex = function(sd, rm) {
	return toStringBinary(this, 16, sd, rm);
};
P.toNearest = function(y, rm) {
	var x = this, Ctor = x.constructor;
	x = new Ctor(x);
	if (y == null) {
		if (!x.d) return x;
		y = new Ctor(1);
		rm = Ctor.rounding;
	} else {
		y = new Ctor(y);
		if (rm === void 0) rm = Ctor.rounding;
		else checkInt32(rm, 0, 8);
		if (!x.d) return y.s ? x : y;
		if (!y.d) {
			if (y.s) y.s = x.s;
			return y;
		}
	}
	if (y.d[0]) {
		external = false;
		x = divide(x, y, 0, rm, 1).times(y);
		external = true;
		finalise(x);
	} else {
		y.s = x.s;
		x = y;
	}
	return x;
};
P.toNumber = function() {
	return +this;
};
P.toOctal = function(sd, rm) {
	return toStringBinary(this, 8, sd, rm);
};
P.toPower = P.pow = function(y) {
	var e, k, pr, r, rm, s, x = this, Ctor = x.constructor, yn = +(y = new Ctor(y));
	if (!x.d || !y.d || !x.d[0] || !y.d[0]) return new Ctor(mathpow(+x, yn));
	x = new Ctor(x);
	if (x.eq(1)) return x;
	pr = Ctor.precision;
	rm = Ctor.rounding;
	if (y.eq(1)) return finalise(x, pr, rm);
	e = mathfloor(y.e / LOG_BASE);
	if (e >= y.d.length - 1 && (k = yn < 0 ? -yn : yn) <= MAX_SAFE_INTEGER) {
		r = intPow(Ctor, x, k, pr);
		return y.s < 0 ? new Ctor(1).div(r) : finalise(r, pr, rm);
	}
	s = x.s;
	if (s < 0) {
		if (e < y.d.length - 1) return new Ctor(NaN);
		if ((y.d[e] & 1) == 0) s = 1;
		if (x.e == 0 && x.d[0] == 1 && x.d.length == 1) {
			x.s = s;
			return x;
		}
	}
	k = mathpow(+x, yn);
	e = k == 0 || !isFinite(k) ? mathfloor(yn * (Math.log("0." + digitsToString(x.d)) / Math.LN10 + x.e + 1)) : new Ctor(k + "").e;
	if (e > Ctor.maxE + 1 || e < Ctor.minE - 1) return new Ctor(e > 0 ? s / 0 : 0);
	external = false;
	Ctor.rounding = x.s = 1;
	k = Math.min(12, (e + "").length);
	r = naturalExponential(y.times(naturalLogarithm(x, pr + k)), pr);
	if (r.d) {
		r = finalise(r, pr + 5, 1);
		if (checkRoundingDigits(r.d, pr, rm)) {
			e = pr + 10;
			r = finalise(naturalExponential(y.times(naturalLogarithm(x, e + k)), e), e + 5, 1);
			if (+digitsToString(r.d).slice(pr + 1, pr + 15) + 1 == 0x5af3107a4000) r = finalise(r, pr + 1, 0);
		}
	}
	r.s = s;
	external = true;
	Ctor.rounding = rm;
	return finalise(r, pr, rm);
};
P.toPrecision = function(sd, rm) {
	var str, x = this, Ctor = x.constructor;
	if (sd === void 0) str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
	else {
		checkInt32(sd, 1, MAX_DIGITS);
		if (rm === void 0) rm = Ctor.rounding;
		else checkInt32(rm, 0, 8);
		x = finalise(new Ctor(x), sd, rm);
		str = finiteToString(x, sd <= x.e || x.e <= Ctor.toExpNeg, sd);
	}
	return x.isNeg() && !x.isZero() ? "-" + str : str;
};
P.toSignificantDigits = P.toSD = function(sd, rm) {
	var x = this, Ctor = x.constructor;
	if (sd === void 0) {
		sd = Ctor.precision;
		rm = Ctor.rounding;
	} else {
		checkInt32(sd, 1, MAX_DIGITS);
		if (rm === void 0) rm = Ctor.rounding;
		else checkInt32(rm, 0, 8);
	}
	return finalise(new Ctor(x), sd, rm);
};
P.toString = function() {
	var x = this, Ctor = x.constructor, str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
	return x.isNeg() && !x.isZero() ? "-" + str : str;
};
P.truncated = P.trunc = function() {
	return finalise(new this.constructor(this), this.e + 1, 1);
};
P.valueOf = P.toJSON = function() {
	var x = this, Ctor = x.constructor, str = finiteToString(x, x.e <= Ctor.toExpNeg || x.e >= Ctor.toExpPos);
	return x.isNeg() ? "-" + str : str;
};
function digitsToString(d) {
	var i, k, ws, indexOfLastWord = d.length - 1, str = "", w = d[0];
	if (indexOfLastWord > 0) {
		str += w;
		for (i = 1; i < indexOfLastWord; i++) {
			ws = d[i] + "";
			k = LOG_BASE - ws.length;
			if (k) str += getZeroString(k);
			str += ws;
		}
		w = d[i];
		ws = w + "";
		k = LOG_BASE - ws.length;
		if (k) str += getZeroString(k);
	} else if (w === 0) return "0";
	for (; w % 10 === 0;) w /= 10;
	return str + w;
}
function checkInt32(i, min, max) {
	if (i !== ~~i || i < min || i > max) throw Error(invalidArgument + i);
}
function checkRoundingDigits(d, i, rm, repeating) {
	var di, k = d[0], r, rd;
	for (; k >= 10; k /= 10) --i;
	if (--i < 0) {
		i += LOG_BASE;
		di = 0;
	} else {
		di = Math.ceil((i + 1) / LOG_BASE);
		i %= LOG_BASE;
	}
	k = mathpow(10, LOG_BASE - i);
	rd = d[di] % k | 0;
	if (repeating == null) {
		if (i < 3) {
			if (i == 0) rd = rd / 100 | 0;
			else if (i == 1) rd = rd / 10 | 0;
			r = rm < 4 && rd == 99999 || rm > 3 && rd == 49999 || rd == 5e4 || rd == 0;
		} else r = (rm < 4 && rd + 1 == k || rm > 3 && rd + 1 == k / 2) && (d[di + 1] / k / 100 | 0) == mathpow(10, i - 2) - 1 || (rd == k / 2 || rd == 0) && (d[di + 1] / k / 100 | 0) == 0;
	} else if (i < 4) {
		if (i == 0) rd = rd / 1e3 | 0;
		else if (i == 1) rd = rd / 100 | 0;
		else if (i == 2) rd = rd / 10 | 0;
		r = (repeating || rm < 4) && rd == 9999 || !repeating && rm > 3 && rd == 4999;
	} else r = ((repeating || rm < 4) && rd + 1 == k || !repeating && rm > 3 && rd + 1 == k / 2) && (d[di + 1] / k / 1e3 | 0) == mathpow(10, i - 3) - 1;
	return r;
}
function convertBase(str, baseIn, baseOut) {
	var j, arr = [0], arrL, i = 0, strL = str.length;
	for (; i < strL;) {
		for (arrL = arr.length; arrL--;) arr[arrL] *= baseIn;
		arr[0] += NUMERALS.indexOf(str.charAt(i++));
		for (j = 0; j < arr.length; j++) if (arr[j] > baseOut - 1) {
			if (arr[j + 1] === void 0) arr[j + 1] = 0;
			arr[j + 1] += arr[j] / baseOut | 0;
			arr[j] %= baseOut;
		}
	}
	return arr.reverse();
}
function cosine(Ctor, x) {
	var k, len, y;
	if (x.isZero()) return x;
	len = x.d.length;
	if (len < 32) {
		k = Math.ceil(len / 3);
		y = (1 / tinyPow(4, k)).toString();
	} else {
		k = 16;
		y = "2.3283064365386962890625e-10";
	}
	Ctor.precision += k;
	x = taylorSeries(Ctor, 1, x.times(y), new Ctor(1));
	for (var i = k; i--;) {
		var cos2x = x.times(x);
		x = cos2x.times(cos2x).minus(cos2x).times(8).plus(1);
	}
	Ctor.precision -= k;
	return x;
}
var divide = (function() {
	function multiplyInteger(x, k, base) {
		var temp, carry = 0, i = x.length;
		for (x = x.slice(); i--;) {
			temp = x[i] * k + carry;
			x[i] = temp % base | 0;
			carry = temp / base | 0;
		}
		if (carry) x.unshift(carry);
		return x;
	}
	function compare(a, b, aL, bL) {
		var i, r;
		if (aL != bL) r = aL > bL ? 1 : -1;
		else for (i = r = 0; i < aL; i++) if (a[i] != b[i]) {
			r = a[i] > b[i] ? 1 : -1;
			break;
		}
		return r;
	}
	function subtract(a, b, aL, base) {
		var i = 0;
		for (; aL--;) {
			a[aL] -= i;
			i = a[aL] < b[aL] ? 1 : 0;
			a[aL] = i * base + a[aL] - b[aL];
		}
		for (; !a[0] && a.length > 1;) a.shift();
	}
	return function(x, y, pr, rm, dp, base) {
		var cmp, e, i, k, logBase, more, prod, prodL, q, qd, rem, remL, rem0, sd, t, xi, xL, yd0, yL, yz, Ctor = x.constructor, sign = x.s == y.s ? 1 : -1, xd = x.d, yd = y.d;
		if (!xd || !xd[0] || !yd || !yd[0]) return new Ctor(!x.s || !y.s || (xd ? yd && xd[0] == yd[0] : !yd) ? NaN : xd && xd[0] == 0 || !yd ? sign * 0 : sign / 0);
		if (base) {
			logBase = 1;
			e = x.e - y.e;
		} else {
			base = BASE;
			logBase = LOG_BASE;
			e = mathfloor(x.e / logBase) - mathfloor(y.e / logBase);
		}
		yL = yd.length;
		xL = xd.length;
		q = new Ctor(sign);
		qd = q.d = [];
		for (i = 0; yd[i] == (xd[i] || 0); i++);
		if (yd[i] > (xd[i] || 0)) e--;
		if (pr == null) {
			sd = pr = Ctor.precision;
			rm = Ctor.rounding;
		} else if (dp) sd = pr + (x.e - y.e) + 1;
		else sd = pr;
		if (sd < 0) {
			qd.push(1);
			more = true;
		} else {
			sd = sd / logBase + 2 | 0;
			i = 0;
			if (yL == 1) {
				k = 0;
				yd = yd[0];
				sd++;
				for (; (i < xL || k) && sd--; i++) {
					t = k * base + (xd[i] || 0);
					qd[i] = t / yd | 0;
					k = t % yd | 0;
				}
				more = k || i < xL;
			} else {
				k = base / (yd[0] + 1) | 0;
				if (k > 1) {
					yd = multiplyInteger(yd, k, base);
					xd = multiplyInteger(xd, k, base);
					yL = yd.length;
					xL = xd.length;
				}
				xi = yL;
				rem = xd.slice(0, yL);
				remL = rem.length;
				for (; remL < yL;) rem[remL++] = 0;
				yz = yd.slice();
				yz.unshift(0);
				yd0 = yd[0];
				if (yd[1] >= base / 2) ++yd0;
				do {
					k = 0;
					cmp = compare(yd, rem, yL, remL);
					if (cmp < 0) {
						rem0 = rem[0];
						if (yL != remL) rem0 = rem0 * base + (rem[1] || 0);
						k = rem0 / yd0 | 0;
						if (k > 1) {
							if (k >= base) k = base - 1;
							prod = multiplyInteger(yd, k, base);
							prodL = prod.length;
							remL = rem.length;
							cmp = compare(prod, rem, prodL, remL);
							if (cmp == 1) {
								k--;
								subtract(prod, yL < prodL ? yz : yd, prodL, base);
							}
						} else {
							if (k == 0) cmp = k = 1;
							prod = yd.slice();
						}
						prodL = prod.length;
						if (prodL < remL) prod.unshift(0);
						subtract(rem, prod, remL, base);
						if (cmp == -1) {
							remL = rem.length;
							cmp = compare(yd, rem, yL, remL);
							if (cmp < 1) {
								k++;
								subtract(rem, yL < remL ? yz : yd, remL, base);
							}
						}
						remL = rem.length;
					} else if (cmp === 0) {
						k++;
						rem = [0];
					}
					qd[i++] = k;
					if (cmp && rem[0]) rem[remL++] = xd[xi] || 0;
					else {
						rem = [xd[xi]];
						remL = 1;
					}
				} while ((xi++ < xL || rem[0] !== void 0) && sd--);
				more = rem[0] !== void 0;
			}
			if (!qd[0]) qd.shift();
		}
		if (logBase == 1) {
			q.e = e;
			inexact = more;
		} else {
			for (i = 1, k = qd[0]; k >= 10; k /= 10) i++;
			q.e = i + e * logBase - 1;
			finalise(q, dp ? pr + q.e + 1 : pr, rm, more);
		}
		return q;
	};
})();
function finalise(x, sd, rm, isTruncated) {
	var digits, i, j, k, rd, roundUp, w, xd, xdi, Ctor = x.constructor;
	out: if (sd != null) {
		xd = x.d;
		if (!xd) return x;
		for (digits = 1, k = xd[0]; k >= 10; k /= 10) digits++;
		i = sd - digits;
		if (i < 0) {
			i += LOG_BASE;
			j = sd;
			w = xd[xdi = 0];
			rd = w / mathpow(10, digits - j - 1) % 10 | 0;
		} else {
			xdi = Math.ceil((i + 1) / LOG_BASE);
			k = xd.length;
			if (xdi >= k) {
				if (isTruncated) {
					for (; k++ <= xdi;) xd.push(0);
					w = rd = 0;
					digits = 1;
					i %= LOG_BASE;
					j = i - LOG_BASE + 1;
				} else break out;
			} else {
				w = k = xd[xdi];
				for (digits = 1; k >= 10; k /= 10) digits++;
				i %= LOG_BASE;
				j = i - LOG_BASE + digits;
				rd = j < 0 ? 0 : w / mathpow(10, digits - j - 1) % 10 | 0;
			}
		}
		isTruncated = isTruncated || sd < 0 || xd[xdi + 1] !== void 0 || (j < 0 ? w : w % mathpow(10, digits - j - 1));
		roundUp = rm < 4 ? (rd || isTruncated) && (rm == 0 || rm == (x.s < 0 ? 3 : 2)) : rd > 5 || rd == 5 && (rm == 4 || isTruncated || rm == 6 && (i > 0 ? j > 0 ? w / mathpow(10, digits - j) : 0 : xd[xdi - 1]) % 10 & 1 || rm == (x.s < 0 ? 8 : 7));
		if (sd < 1 || !xd[0]) {
			xd.length = 0;
			if (roundUp) {
				sd -= x.e + 1;
				xd[0] = mathpow(10, (LOG_BASE - sd % LOG_BASE) % LOG_BASE);
				x.e = -sd || 0;
			} else xd[0] = x.e = 0;
			return x;
		}
		if (i == 0) {
			xd.length = xdi;
			k = 1;
			xdi--;
		} else {
			xd.length = xdi + 1;
			k = mathpow(10, LOG_BASE - i);
			xd[xdi] = j > 0 ? (w / mathpow(10, digits - j) % mathpow(10, j) | 0) * k : 0;
		}
		if (roundUp) for (;;) if (xdi == 0) {
			for (i = 1, j = xd[0]; j >= 10; j /= 10) i++;
			j = xd[0] += k;
			for (k = 1; j >= 10; j /= 10) k++;
			if (i != k) {
				x.e++;
				if (xd[0] == BASE) xd[0] = 1;
			}
			break;
		} else {
			xd[xdi] += k;
			if (xd[xdi] != BASE) break;
			xd[xdi--] = 0;
			k = 1;
		}
		for (i = xd.length; xd[--i] === 0;) xd.pop();
	}
	if (external) {
		if (x.e > Ctor.maxE) {
			x.d = null;
			x.e = NaN;
		} else if (x.e < Ctor.minE) {
			x.e = 0;
			x.d = [0];
		}
	}
	return x;
}
function finiteToString(x, isExp, sd) {
	if (!x.isFinite()) return nonFiniteToString(x);
	var k, e = x.e, str = digitsToString(x.d), len = str.length;
	if (isExp) {
		if (sd && (k = sd - len) > 0) str = str.charAt(0) + "." + str.slice(1) + getZeroString(k);
		else if (len > 1) str = str.charAt(0) + "." + str.slice(1);
		str = str + (x.e < 0 ? "e" : "e+") + x.e;
	} else if (e < 0) {
		str = "0." + getZeroString(-e - 1) + str;
		if (sd && (k = sd - len) > 0) str += getZeroString(k);
	} else if (e >= len) {
		str += getZeroString(e + 1 - len);
		if (sd && (k = sd - e - 1) > 0) str = str + "." + getZeroString(k);
	} else {
		if ((k = e + 1) < len) str = str.slice(0, k) + "." + str.slice(k);
		if (sd && (k = sd - len) > 0) {
			if (e + 1 === len) str += ".";
			str += getZeroString(k);
		}
	}
	return str;
}
function getBase10Exponent(digits, e) {
	var w = digits[0];
	for (e *= LOG_BASE; w >= 10; w /= 10) e++;
	return e;
}
function getLn10(Ctor, sd, pr) {
	if (sd > LN10_PRECISION) {
		external = true;
		if (pr) Ctor.precision = pr;
		throw Error(precisionLimitExceeded);
	}
	return finalise(new Ctor(LN10), sd, 1, true);
}
function getPi(Ctor, sd, rm) {
	if (sd > PI_PRECISION) throw Error(precisionLimitExceeded);
	return finalise(new Ctor(PI), sd, rm, true);
}
function getPrecision(digits) {
	var w = digits.length - 1, len = w * LOG_BASE + 1;
	w = digits[w];
	if (w) {
		for (; w % 10 == 0; w /= 10) len--;
		for (w = digits[0]; w >= 10; w /= 10) len++;
	}
	return len;
}
function getZeroString(k) {
	var zs = "";
	for (; k--;) zs += "0";
	return zs;
}
function intPow(Ctor, x, n, pr) {
	var isTruncated, r = new Ctor(1), k = Math.ceil(pr / LOG_BASE + 4);
	external = false;
	for (;;) {
		if (n % 2) {
			r = r.times(x);
			if (truncate(r.d, k)) isTruncated = true;
		}
		n = mathfloor(n / 2);
		if (n === 0) {
			n = r.d.length - 1;
			if (isTruncated && r.d[n] === 0) ++r.d[n];
			break;
		}
		x = x.times(x);
		truncate(x.d, k);
	}
	external = true;
	return r;
}
function isOdd(n) {
	return n.d[n.d.length - 1] & 1;
}
function maxOrMin(Ctor, args, n) {
	var k, y, x = new Ctor(args[0]), i = 0;
	for (; ++i < args.length;) {
		y = new Ctor(args[i]);
		if (!y.s) {
			x = y;
			break;
		}
		k = x.cmp(y);
		if (k === n || k === 0 && x.s === n) x = y;
	}
	return x;
}
function naturalExponential(x, sd) {
	var denominator, guard, j, pow, sum, t, wpr, rep = 0, i = 0, k = 0, Ctor = x.constructor, rm = Ctor.rounding, pr = Ctor.precision;
	if (!x.d || !x.d[0] || x.e > 17) return new Ctor(x.d ? !x.d[0] ? 1 : x.s < 0 ? 0 : 1 / 0 : x.s ? x.s < 0 ? 0 : x : NaN);
	if (sd == null) {
		external = false;
		wpr = pr;
	} else wpr = sd;
	t = new Ctor(.03125);
	while (x.e > -2) {
		x = x.times(t);
		k += 5;
	}
	guard = Math.log(mathpow(2, k)) / Math.LN10 * 2 + 5 | 0;
	wpr += guard;
	denominator = pow = sum = new Ctor(1);
	Ctor.precision = wpr;
	for (;;) {
		pow = finalise(pow.times(x), wpr, 1);
		denominator = denominator.times(++i);
		t = sum.plus(divide(pow, denominator, wpr, 1));
		if (digitsToString(t.d).slice(0, wpr) === digitsToString(sum.d).slice(0, wpr)) {
			j = k;
			while (j--) sum = finalise(sum.times(sum), wpr, 1);
			if (sd == null) {
				if (rep < 3 && checkRoundingDigits(sum.d, wpr - guard, rm, rep)) {
					Ctor.precision = wpr += 10;
					denominator = pow = t = new Ctor(1);
					i = 0;
					rep++;
				} else return finalise(sum, Ctor.precision = pr, rm, external = true);
			} else {
				Ctor.precision = pr;
				return sum;
			}
		}
		sum = t;
	}
}
function naturalLogarithm(y, sd) {
	var c, c0, denominator, e, numerator, rep, sum, t, wpr, x1, x2, n = 1, guard = 10, x = y, xd = x.d, Ctor = x.constructor, rm = Ctor.rounding, pr = Ctor.precision;
	if (x.s < 0 || !xd || !xd[0] || !x.e && xd[0] == 1 && xd.length == 1) return new Ctor(xd && !xd[0] ? -1 / 0 : x.s != 1 ? NaN : xd ? 0 : x);
	if (sd == null) {
		external = false;
		wpr = pr;
	} else wpr = sd;
	Ctor.precision = wpr += guard;
	c = digitsToString(xd);
	c0 = c.charAt(0);
	if (Math.abs(e = x.e) < 0x5543df729c000) {
		while (c0 < 7 && c0 != 1 || c0 == 1 && c.charAt(1) > 3) {
			x = x.times(y);
			c = digitsToString(x.d);
			c0 = c.charAt(0);
			n++;
		}
		e = x.e;
		if (c0 > 1) {
			x = new Ctor("0." + c);
			e++;
		} else x = new Ctor(c0 + "." + c.slice(1));
	} else {
		t = getLn10(Ctor, wpr + 2, pr).times(e + "");
		x = naturalLogarithm(new Ctor(c0 + "." + c.slice(1)), wpr - guard).plus(t);
		Ctor.precision = pr;
		return sd == null ? finalise(x, pr, rm, external = true) : x;
	}
	x1 = x;
	sum = numerator = x = divide(x.minus(1), x.plus(1), wpr, 1);
	x2 = finalise(x.times(x), wpr, 1);
	denominator = 3;
	for (;;) {
		numerator = finalise(numerator.times(x2), wpr, 1);
		t = sum.plus(divide(numerator, new Ctor(denominator), wpr, 1));
		if (digitsToString(t.d).slice(0, wpr) === digitsToString(sum.d).slice(0, wpr)) {
			sum = sum.times(2);
			if (e !== 0) sum = sum.plus(getLn10(Ctor, wpr + 2, pr).times(e + ""));
			sum = divide(sum, new Ctor(n), wpr, 1);
			if (sd == null) {
				if (checkRoundingDigits(sum.d, wpr - guard, rm, rep)) {
					Ctor.precision = wpr += guard;
					t = numerator = x = divide(x1.minus(1), x1.plus(1), wpr, 1);
					x2 = finalise(x.times(x), wpr, 1);
					denominator = rep = 1;
				} else return finalise(sum, Ctor.precision = pr, rm, external = true);
			} else {
				Ctor.precision = pr;
				return sum;
			}
		}
		sum = t;
		denominator += 2;
	}
}
function nonFiniteToString(x) {
	return String(x.s * x.s / 0);
}
function parseDecimal(x, str) {
	var e, i, len;
	if ((e = str.indexOf(".")) > -1) str = str.replace(".", "");
	if ((i = str.search(/e/i)) > 0) {
		if (e < 0) e = i;
		e += +str.slice(i + 1);
		str = str.substring(0, i);
	} else if (e < 0) e = str.length;
	for (i = 0; str.charCodeAt(i) === 48; i++);
	for (len = str.length; str.charCodeAt(len - 1) === 48; --len);
	str = str.slice(i, len);
	if (str) {
		len -= i;
		x.e = e = e - i - 1;
		x.d = [];
		i = (e + 1) % LOG_BASE;
		if (e < 0) i += LOG_BASE;
		if (i < len) {
			if (i) x.d.push(+str.slice(0, i));
			for (len -= LOG_BASE; i < len;) x.d.push(+str.slice(i, i += LOG_BASE));
			str = str.slice(i);
			i = LOG_BASE - str.length;
		} else i -= len;
		for (; i--;) str += "0";
		x.d.push(+str);
		if (external) {
			if (x.e > x.constructor.maxE) {
				x.d = null;
				x.e = NaN;
			} else if (x.e < x.constructor.minE) {
				x.e = 0;
				x.d = [0];
			}
		}
	} else {
		x.e = 0;
		x.d = [0];
	}
	return x;
}
function parseOther(x, str) {
	var base, Ctor, divisor, i, isFloat, len, p, xd, xe;
	if (str.indexOf("_") > -1) {
		str = str.replace(/(\d)_(?=\d)/g, "$1");
		if (isDecimal.test(str)) return parseDecimal(x, str);
	} else if (str === "Infinity" || str === "NaN") {
		if (!+str) x.s = NaN;
		x.e = NaN;
		x.d = null;
		return x;
	}
	if (isHex.test(str)) {
		base = 16;
		str = str.toLowerCase();
	} else if (isBinary.test(str)) base = 2;
	else if (isOctal.test(str)) base = 8;
	else throw Error(invalidArgument + str);
	i = str.search(/p/i);
	if (i > 0) {
		p = +str.slice(i + 1);
		str = str.substring(2, i);
	} else str = str.slice(2);
	i = str.indexOf(".");
	isFloat = i >= 0;
	Ctor = x.constructor;
	if (isFloat) {
		str = str.replace(".", "");
		len = str.length;
		i = len - i;
		divisor = intPow(Ctor, new Ctor(base), i, i * 2);
	}
	xd = convertBase(str, base, BASE);
	xe = xd.length - 1;
	for (i = xe; xd[i] === 0; --i) xd.pop();
	if (i < 0) return new Ctor(x.s * 0);
	x.e = getBase10Exponent(xd, xe);
	x.d = xd;
	external = false;
	if (isFloat) x = divide(x, divisor, len * 4);
	if (p) x = x.times(Math.abs(p) < 54 ? mathpow(2, p) : Decimal.pow(2, p));
	external = true;
	return x;
}
function sine(Ctor, x) {
	var k, len = x.d.length;
	if (len < 3) return x.isZero() ? x : taylorSeries(Ctor, 2, x, x);
	k = 1.4 * Math.sqrt(len);
	k = k > 16 ? 16 : k | 0;
	x = x.times(1 / tinyPow(5, k));
	x = taylorSeries(Ctor, 2, x, x);
	var sin2_x, d5 = new Ctor(5), d16 = new Ctor(16), d20 = new Ctor(20);
	for (; k--;) {
		sin2_x = x.times(x);
		x = x.times(d5.plus(sin2_x.times(d16.times(sin2_x).minus(d20))));
	}
	return x;
}
function taylorSeries(Ctor, n, x, y, isHyperbolic) {
	var j, t, u, x2, i = 1, pr = Ctor.precision, k = Math.ceil(pr / LOG_BASE);
	external = false;
	x2 = x.times(x);
	u = new Ctor(y);
	for (;;) {
		t = divide(u.times(x2), new Ctor(n++ * n++), pr, 1);
		u = isHyperbolic ? y.plus(t) : y.minus(t);
		y = divide(t.times(x2), new Ctor(n++ * n++), pr, 1);
		t = u.plus(y);
		if (t.d[k] !== void 0) {
			for (j = k; t.d[j] === u.d[j] && j--;);
			if (j == -1) break;
		}
		j = u;
		u = y;
		y = t;
		t = j;
		i++;
	}
	external = true;
	t.d.length = k + 1;
	return t;
}
function tinyPow(b, e) {
	var n = b;
	while (--e) n *= b;
	return n;
}
function toLessThanHalfPi(Ctor, x) {
	var t, isNeg = x.s < 0, pi = getPi(Ctor, Ctor.precision, 1), halfPi = pi.times(.5);
	x = x.abs();
	if (x.lte(halfPi)) {
		quadrant = isNeg ? 4 : 1;
		return x;
	}
	t = x.divToInt(pi);
	if (t.isZero()) quadrant = isNeg ? 3 : 2;
	else {
		x = x.minus(t.times(pi));
		if (x.lte(halfPi)) {
			quadrant = isOdd(t) ? isNeg ? 2 : 3 : isNeg ? 4 : 1;
			return x;
		}
		quadrant = isOdd(t) ? isNeg ? 1 : 4 : isNeg ? 3 : 2;
	}
	return x.minus(pi).abs();
}
function toStringBinary(x, baseOut, sd, rm) {
	var base, e, i, k, len, roundUp, str, xd, y, Ctor = x.constructor, isExp = sd !== void 0;
	if (isExp) {
		checkInt32(sd, 1, MAX_DIGITS);
		if (rm === void 0) rm = Ctor.rounding;
		else checkInt32(rm, 0, 8);
	} else {
		sd = Ctor.precision;
		rm = Ctor.rounding;
	}
	if (!x.isFinite()) str = nonFiniteToString(x);
	else {
		str = finiteToString(x);
		i = str.indexOf(".");
		if (isExp) {
			base = 2;
			if (baseOut == 16) sd = sd * 4 - 3;
			else if (baseOut == 8) sd = sd * 3 - 2;
		} else base = baseOut;
		if (i >= 0) {
			str = str.replace(".", "");
			y = new Ctor(1);
			y.e = str.length - i;
			y.d = convertBase(finiteToString(y), 10, base);
			y.e = y.d.length;
		}
		xd = convertBase(str, 10, base);
		e = len = xd.length;
		for (; xd[--len] == 0;) xd.pop();
		if (!xd[0]) str = isExp ? "0p+0" : "0";
		else {
			if (i < 0) e--;
			else {
				x = new Ctor(x);
				x.d = xd;
				x.e = e;
				x = divide(x, y, sd, rm, 0, base);
				xd = x.d;
				e = x.e;
				roundUp = inexact;
			}
			i = xd[sd];
			k = base / 2;
			roundUp = roundUp || xd[sd + 1] !== void 0;
			roundUp = rm < 4 ? (i !== void 0 || roundUp) && (rm === 0 || rm === (x.s < 0 ? 3 : 2)) : i > k || i === k && (rm === 4 || roundUp || rm === 6 && xd[sd - 1] & 1 || rm === (x.s < 0 ? 8 : 7));
			xd.length = sd;
			if (roundUp) for (; ++xd[--sd] > base - 1;) {
				xd[sd] = 0;
				if (!sd) {
					++e;
					xd.unshift(1);
				}
			}
			for (len = xd.length; !xd[len - 1]; --len);
			for (i = 0, str = ""; i < len; i++) str += NUMERALS.charAt(xd[i]);
			if (isExp) {
				if (len > 1) {
					if (baseOut == 16 || baseOut == 8) {
						i = baseOut == 16 ? 4 : 3;
						for (--len; len % i; len++) str += "0";
						xd = convertBase(str, base, baseOut);
						for (len = xd.length; !xd[len - 1]; --len);
						for (i = 1, str = "1."; i < len; i++) str += NUMERALS.charAt(xd[i]);
					} else str = str.charAt(0) + "." + str.slice(1);
				}
				str = str + (e < 0 ? "p" : "p+") + e;
			} else if (e < 0) {
				for (; ++e;) str = "0" + str;
				str = "0." + str;
			} else if (++e > len) for (e -= len; e--;) str += "0";
			else if (e < len) str = str.slice(0, e) + "." + str.slice(e);
		}
		str = (baseOut == 16 ? "0x" : baseOut == 2 ? "0b" : baseOut == 8 ? "0o" : "") + str;
	}
	return x.s < 0 ? "-" + str : str;
}
function truncate(arr, len) {
	if (arr.length > len) {
		arr.length = len;
		return true;
	}
}
function abs(x) {
	return new this(x).abs();
}
function acos(x) {
	return new this(x).acos();
}
function acosh(x) {
	return new this(x).acosh();
}
function add(x, y) {
	return new this(x).plus(y);
}
function asin(x) {
	return new this(x).asin();
}
function asinh(x) {
	return new this(x).asinh();
}
function atan(x) {
	return new this(x).atan();
}
function atanh(x) {
	return new this(x).atanh();
}
function atan2(y, x) {
	y = new this(y);
	x = new this(x);
	var r, pr = this.precision, rm = this.rounding, wpr = pr + 4;
	if (!y.s || !x.s) r = new this(NaN);
	else if (!y.d && !x.d) {
		r = getPi(this, wpr, 1).times(x.s > 0 ? .25 : .75);
		r.s = y.s;
	} else if (!x.d || y.isZero()) {
		r = x.s < 0 ? getPi(this, pr, rm) : new this(0);
		r.s = y.s;
	} else if (!y.d || x.isZero()) {
		r = getPi(this, wpr, 1).times(.5);
		r.s = y.s;
	} else if (x.s < 0) {
		this.precision = wpr;
		this.rounding = 1;
		r = this.atan(divide(y, x, wpr, 1));
		x = getPi(this, wpr, 1);
		this.precision = pr;
		this.rounding = rm;
		r = y.s < 0 ? r.minus(x) : r.plus(x);
	} else r = this.atan(divide(y, x, wpr, 1));
	return r;
}
function cbrt(x) {
	return new this(x).cbrt();
}
function ceil(x) {
	return finalise(x = new this(x), x.e + 1, 2);
}
function clamp(x, min, max) {
	return new this(x).clamp(min, max);
}
function config(obj) {
	if (!obj || typeof obj !== "object") throw Error(decimalError + "Object expected");
	var i, p, v, useDefaults = obj.defaults === true, ps = [
		"precision",
		1,
		MAX_DIGITS,
		"rounding",
		0,
		8,
		"toExpNeg",
		-EXP_LIMIT,
		0,
		"toExpPos",
		0,
		EXP_LIMIT,
		"maxE",
		0,
		EXP_LIMIT,
		"minE",
		-EXP_LIMIT,
		0,
		"modulo",
		0,
		9
	];
	for (i = 0; i < ps.length; i += 3) {
		if (p = ps[i], useDefaults) this[p] = DEFAULTS[p];
		if ((v = obj[p]) !== void 0) {
			if (mathfloor(v) === v && v >= ps[i + 1] && v <= ps[i + 2]) this[p] = v;
			else throw Error(invalidArgument + p + ": " + v);
		}
	}
	if (p = "crypto", useDefaults) this[p] = DEFAULTS[p];
	if ((v = obj[p]) !== void 0) {
		if (v === true || v === false || v === 0 || v === 1) {
			if (v) {
				if (typeof crypto != "undefined" && crypto && (crypto.getRandomValues || crypto.randomBytes)) this[p] = true;
				else throw Error(cryptoUnavailable);
			} else this[p] = false;
		} else throw Error(invalidArgument + p + ": " + v);
	}
	return this;
}
function cos(x) {
	return new this(x).cos();
}
function cosh(x) {
	return new this(x).cosh();
}
function clone(obj) {
	var i, p, ps;
	function Decimal(v) {
		var e, i, t, x = this;
		if (!(x instanceof Decimal)) return new Decimal(v);
		x.constructor = Decimal;
		if (isDecimalInstance(v)) {
			x.s = v.s;
			if (external) {
				if (!v.d || v.e > Decimal.maxE) {
					x.e = NaN;
					x.d = null;
				} else if (v.e < Decimal.minE) {
					x.e = 0;
					x.d = [0];
				} else {
					x.e = v.e;
					x.d = v.d.slice();
				}
			} else {
				x.e = v.e;
				x.d = v.d ? v.d.slice() : v.d;
			}
			return;
		}
		t = typeof v;
		if (t === "number") {
			if (v === 0) {
				x.s = 1 / v < 0 ? -1 : 1;
				x.e = 0;
				x.d = [0];
				return;
			}
			if (v < 0) {
				v = -v;
				x.s = -1;
			} else x.s = 1;
			if (v === ~~v && v < 1e7) {
				for (e = 0, i = v; i >= 10; i /= 10) e++;
				if (external) {
					if (e > Decimal.maxE) {
						x.e = NaN;
						x.d = null;
					} else if (e < Decimal.minE) {
						x.e = 0;
						x.d = [0];
					} else {
						x.e = e;
						x.d = [v];
					}
				} else {
					x.e = e;
					x.d = [v];
				}
				return;
			}
			if (v * 0 !== 0) {
				if (!v) x.s = NaN;
				x.e = NaN;
				x.d = null;
				return;
			}
			return parseDecimal(x, v.toString());
		}
		if (t === "string") {
			if ((i = v.charCodeAt(0)) === 45) {
				v = v.slice(1);
				x.s = -1;
			} else {
				if (i === 43) v = v.slice(1);
				x.s = 1;
			}
			return isDecimal.test(v) ? parseDecimal(x, v) : parseOther(x, v);
		}
		if (t === "bigint") {
			if (v < 0) {
				v = -v;
				x.s = -1;
			} else x.s = 1;
			return parseDecimal(x, v.toString());
		}
		throw Error(invalidArgument + v);
	}
	Decimal.prototype = P;
	Decimal.ROUND_UP = 0;
	Decimal.ROUND_DOWN = 1;
	Decimal.ROUND_CEIL = 2;
	Decimal.ROUND_FLOOR = 3;
	Decimal.ROUND_HALF_UP = 4;
	Decimal.ROUND_HALF_DOWN = 5;
	Decimal.ROUND_HALF_EVEN = 6;
	Decimal.ROUND_HALF_CEIL = 7;
	Decimal.ROUND_HALF_FLOOR = 8;
	Decimal.EUCLID = 9;
	Decimal.config = Decimal.set = config;
	Decimal.clone = clone;
	Decimal.isDecimal = isDecimalInstance;
	Decimal.abs = abs;
	Decimal.acos = acos;
	Decimal.acosh = acosh;
	Decimal.add = add;
	Decimal.asin = asin;
	Decimal.asinh = asinh;
	Decimal.atan = atan;
	Decimal.atanh = atanh;
	Decimal.atan2 = atan2;
	Decimal.cbrt = cbrt;
	Decimal.ceil = ceil;
	Decimal.clamp = clamp;
	Decimal.cos = cos;
	Decimal.cosh = cosh;
	Decimal.div = div;
	Decimal.exp = exp;
	Decimal.floor = floor;
	Decimal.hypot = hypot;
	Decimal.ln = ln;
	Decimal.log = log;
	Decimal.log10 = log10;
	Decimal.log2 = log2;
	Decimal.max = max;
	Decimal.min = min;
	Decimal.mod = mod;
	Decimal.mul = mul;
	Decimal.pow = pow;
	Decimal.random = random;
	Decimal.round = round;
	Decimal.sign = sign;
	Decimal.sin = sin;
	Decimal.sinh = sinh;
	Decimal.sqrt = sqrt;
	Decimal.sub = sub;
	Decimal.sum = sum;
	Decimal.tan = tan;
	Decimal.tanh = tanh;
	Decimal.trunc = trunc;
	if (obj === void 0) obj = {};
	if (obj) {
		if (obj.defaults !== true) {
			ps = [
				"precision",
				"rounding",
				"toExpNeg",
				"toExpPos",
				"maxE",
				"minE",
				"modulo",
				"crypto"
			];
			for (i = 0; i < ps.length;) if (!obj.hasOwnProperty(p = ps[i++])) obj[p] = this[p];
		}
	}
	Decimal.config(obj);
	return Decimal;
}
function div(x, y) {
	return new this(x).div(y);
}
function exp(x) {
	return new this(x).exp();
}
function floor(x) {
	return finalise(x = new this(x), x.e + 1, 3);
}
function hypot() {
	var i, n, t = new this(0);
	external = false;
	for (i = 0; i < arguments.length;) {
		n = new this(arguments[i++]);
		if (!n.d) {
			if (n.s) {
				external = true;
				return new this(1 / 0);
			}
			t = n;
		} else if (t.d) t = t.plus(n.times(n));
	}
	external = true;
	return t.sqrt();
}
function isDecimalInstance(obj) {
	return obj instanceof Decimal || obj && obj.toStringTag === tag || false;
}
function ln(x) {
	return new this(x).ln();
}
function log(x, y) {
	return new this(x).log(y);
}
function log2(x) {
	return new this(x).log(2);
}
function log10(x) {
	return new this(x).log(10);
}
function max() {
	return maxOrMin(this, arguments, -1);
}
function min() {
	return maxOrMin(this, arguments, 1);
}
function mod(x, y) {
	return new this(x).mod(y);
}
function mul(x, y) {
	return new this(x).mul(y);
}
function pow(x, y) {
	return new this(x).pow(y);
}
function random(sd) {
	var d, e, k, n, i = 0, r = new this(1), rd = [];
	if (sd === void 0) sd = this.precision;
	else checkInt32(sd, 1, MAX_DIGITS);
	k = Math.ceil(sd / LOG_BASE);
	if (!this.crypto) for (; i < k;) rd[i++] = Math.random() * 1e7 | 0;
	else if (crypto.getRandomValues) {
		d = crypto.getRandomValues(new Uint32Array(k));
		for (; i < k;) {
			n = d[i];
			if (n >= 429e7) d[i] = crypto.getRandomValues(/* @__PURE__ */ new Uint32Array(1))[0];
			else rd[i++] = n % 1e7;
		}
	} else if (crypto.randomBytes) {
		d = crypto.randomBytes(k *= 4);
		for (; i < k;) {
			n = d[i] + (d[i + 1] << 8) + (d[i + 2] << 16) + ((d[i + 3] & 127) << 24);
			if (n >= 214e7) crypto.randomBytes(4).copy(d, i);
			else {
				rd.push(n % 1e7);
				i += 4;
			}
		}
		i = k / 4;
	} else throw Error(cryptoUnavailable);
	k = rd[--i];
	sd %= LOG_BASE;
	if (k && sd) {
		n = mathpow(10, LOG_BASE - sd);
		rd[i] = (k / n | 0) * n;
	}
	for (; rd[i] === 0; i--) rd.pop();
	if (i < 0) {
		e = 0;
		rd = [0];
	} else {
		e = -1;
		for (; rd[0] === 0; e -= LOG_BASE) rd.shift();
		for (k = 1, n = rd[0]; n >= 10; n /= 10) k++;
		if (k < LOG_BASE) e -= LOG_BASE - k;
	}
	r.e = e;
	r.d = rd;
	return r;
}
function round(x) {
	return finalise(x = new this(x), x.e + 1, this.rounding);
}
function sign(x) {
	x = new this(x);
	return x.d ? x.d[0] ? x.s : 0 * x.s : x.s || NaN;
}
function sin(x) {
	return new this(x).sin();
}
function sinh(x) {
	return new this(x).sinh();
}
function sqrt(x) {
	return new this(x).sqrt();
}
function sub(x, y) {
	return new this(x).sub(y);
}
function sum() {
	var i = 0, args = arguments, x = new this(args[i]);
	external = false;
	for (; x.s && ++i < args.length;) x = x.plus(args[i]);
	external = true;
	return finalise(x, this.precision, this.rounding);
}
function tan(x) {
	return new this(x).tan();
}
function tanh(x) {
	return new this(x).tanh();
}
function trunc(x) {
	return finalise(x = new this(x), x.e + 1, 1);
}
P[Symbol.for("nodejs.util.inspect.custom")] = P.toString;
P[Symbol.toStringTag] = "Decimal";
var Decimal = P.constructor = clone(DEFAULTS);
LN10 = new Decimal(LN10);
PI = new Decimal(PI);
export { Decimal, Decimal as default };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjaW1hbF9fanMuanMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiLi4vLi4vZGVjaW1hbC5qcy9kZWNpbWFsLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKiFcclxuICogIGRlY2ltYWwuanMgdjEwLjYuMFxyXG4gKiAgQW4gYXJiaXRyYXJ5LXByZWNpc2lvbiBEZWNpbWFsIHR5cGUgZm9yIEphdmFTY3JpcHQuXHJcbiAqICBodHRwczovL2dpdGh1Yi5jb20vTWlrZU1jbC9kZWNpbWFsLmpzXHJcbiAqICBDb3B5cmlnaHQgKGMpIDIwMjUgTWljaGFlbCBNY2xhdWdobGluIDxNOGNoODhsQGdtYWlsLmNvbT5cclxuICogIE1JVCBMaWNlbmNlXHJcbiAqL1xyXG5cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICBFRElUQUJMRSBERUZBVUxUUyAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tIC8vXHJcblxyXG5cclxuICAvLyBUaGUgbWF4aW11bSBleHBvbmVudCBtYWduaXR1ZGUuXHJcbiAgLy8gVGhlIGxpbWl0IG9uIHRoZSB2YWx1ZSBvZiBgdG9FeHBOZWdgLCBgdG9FeHBQb3NgLCBgbWluRWAgYW5kIGBtYXhFYC5cclxudmFyIEVYUF9MSU1JVCA9IDllMTUsICAgICAgICAgICAgICAgICAgICAgIC8vIDAgdG8gOWUxNVxyXG5cclxuICAvLyBUaGUgbGltaXQgb24gdGhlIHZhbHVlIG9mIGBwcmVjaXNpb25gLCBhbmQgb24gdGhlIHZhbHVlIG9mIHRoZSBmaXJzdCBhcmd1bWVudCB0b1xyXG4gIC8vIGB0b0RlY2ltYWxQbGFjZXNgLCBgdG9FeHBvbmVudGlhbGAsIGB0b0ZpeGVkYCwgYHRvUHJlY2lzaW9uYCBhbmQgYHRvU2lnbmlmaWNhbnREaWdpdHNgLlxyXG4gIE1BWF9ESUdJVFMgPSAxZTksICAgICAgICAgICAgICAgICAgICAgICAgLy8gMCB0byAxZTlcclxuXHJcbiAgLy8gQmFzZSBjb252ZXJzaW9uIGFscGhhYmV0LlxyXG4gIE5VTUVSQUxTID0gJzAxMjM0NTY3ODlhYmNkZWYnLFxyXG5cclxuICAvLyBUaGUgbmF0dXJhbCBsb2dhcml0aG0gb2YgMTAgKDEwMjUgZGlnaXRzKS5cclxuICBMTjEwID0gJzIuMzAyNTg1MDkyOTk0MDQ1Njg0MDE3OTkxNDU0Njg0MzY0MjA3NjAxMTAxNDg4NjI4NzcyOTc2MDMzMzI3OTAwOTY3NTcyNjA5Njc3MzUyNDgwMjM1OTk3MjA1MDg5NTk4Mjk4MzQxOTY3Nzg0MDQyMjg2MjQ4NjMzNDA5NTI1NDY1MDgyODA2NzU2NjY2Mjg3MzY5MDk4NzgxNjg5NDgyOTA3MjA4MzI1NTU0NjgwODQzNzk5ODk0ODI2MjMzMTk4NTI4MzkzNTA1MzA4OTY1Mzc3NzMyNjI4ODQ2MTYzMzY2MjIyMjg3Njk4MjE5ODg2NzQ2NTQzNjY3NDc0NDA0MjQzMjc0MzY1MTU1MDQ4OTM0MzE0OTM5MzkxNDc5NjE5NDA0NDAwMjIyMTA1MTAxNzE0MTc0ODAwMzY4ODA4NDAxMjY0NzA4MDY4NTU2Nzc0MzIxNjIyODM1NTIyMDExNDgwNDY2MzcxNTY1OTEyMTM3MzQ1MDc0Nzg1Njk0NzY4MzQ2MzYxNjc5MjEwMTgwNjQ0NTA3MDY0ODAwMDI3NzUwMjY4NDkxNjc0NjU1MDU4Njg1NjkzNTY3MzQyMDY3MDU4MTEzNjQyOTIyNDU1NDQwNTc1ODkyNTcyNDIwODI0MTMxNDY5NTY4OTAxNjc1ODk0MDI1Njc3NjMxMTM1NjkxOTI5MjAzMzM3NjU4NzE0MTY2MDIzMDEwNTcwMzA4OTYzNDU3MjA3NTQ0MDM3MDg0NzQ2OTk0MDE2ODI2OTI4MjgwODQ4MTE4NDI4OTMxNDg0ODUyNDk0ODY0NDg3MTkyNzgwOTY3NjI3MTI3NTc3NTM5NzAyNzY2ODYwNTk1MjQ5NjcxNjY3NDE4MzQ4NTcwNDQyMjUwNzE5Nzk2NTAwNDcxNDk1MTA1MDQ5MjIxNDc3NjU2NzYzNjkzODY2Mjk3Njk3OTUyMjExMDcxODI2NDU0OTczNDc3MjY2MjQyNTcwOTQyOTMyMjU4Mjc5ODUwMjU4NTUwOTc4NTI2NTM4MzIwNzYwNjcyNjMxNzE2NDMwOTUwNTk5NTA4NzgwNzUyMzcxMDMzMzEwMTE5Nzg1NzU0NzMzMTU0MTQyMTgwODQyNzU0Mzg2MzU5MTc3ODExNzA1NDMwOTgyNzQ4MjM4NTA0NTY0ODAxOTA5NTYxMDI5OTI5MTgyNDMxODIzNzUyNTM1NzcwOTc1MDUzOTU2NTE4NzY5NzUxMDM3NDk3MDg4ODY5MjE4MDIwNTE4OTMzOTUwNzIzODUzOTIwNTE0NDYzNDE5NzI2NTI4NzI4Njk2NTExMDg2MjU3MTQ5MjE5ODg0OTk3ODc0ODg3Mzc3MTM0NTY4NjIwOTE2NzA1OCcsXHJcblxyXG4gIC8vIFBpICgxMDI1IGRpZ2l0cykuXHJcbiAgUEkgPSAnMy4xNDE1OTI2NTM1ODk3OTMyMzg0NjI2NDMzODMyNzk1MDI4ODQxOTcxNjkzOTkzNzUxMDU4MjA5NzQ5NDQ1OTIzMDc4MTY0MDYyODYyMDg5OTg2MjgwMzQ4MjUzNDIxMTcwNjc5ODIxNDgwODY1MTMyODIzMDY2NDcwOTM4NDQ2MDk1NTA1ODIyMzE3MjUzNTk0MDgxMjg0ODExMTc0NTAyODQxMDI3MDE5Mzg1MjExMDU1NTk2NDQ2MjI5NDg5NTQ5MzAzODE5NjQ0Mjg4MTA5NzU2NjU5MzM0NDYxMjg0NzU2NDgyMzM3ODY3ODMxNjUyNzEyMDE5MDkxNDU2NDg1NjY5MjM0NjAzNDg2MTA0NTQzMjY2NDgyMTMzOTM2MDcyNjAyNDkxNDEyNzM3MjQ1ODcwMDY2MDYzMTU1ODgxNzQ4ODE1MjA5MjA5NjI4MjkyNTQwOTE3MTUzNjQzNjc4OTI1OTAzNjAwMTEzMzA1MzA1NDg4MjA0NjY1MjEzODQxNDY5NTE5NDE1MTE2MDk0MzMwNTcyNzAzNjU3NTk1OTE5NTMwOTIxODYxMTczODE5MzI2MTE3OTMxMDUxMTg1NDgwNzQ0NjIzNzk5NjI3NDk1NjczNTE4ODU3NTI3MjQ4OTEyMjc5MzgxODMwMTE5NDkxMjk4MzM2NzMzNjI0NDA2NTY2NDMwODYwMjEzOTQ5NDYzOTUyMjQ3MzcxOTA3MDIxNzk4NjA5NDM3MDI3NzA1MzkyMTcxNzYyOTMxNzY3NTIzODQ2NzQ4MTg0Njc2Njk0MDUxMzIwMDA1NjgxMjcxNDUyNjM1NjA4Mjc3ODU3NzEzNDI3NTc3ODk2MDkxNzM2MzcxNzg3MjE0Njg0NDA5MDEyMjQ5NTM0MzAxNDY1NDk1ODUzNzEwNTA3OTIyNzk2ODkyNTg5MjM1NDIwMTk5NTYxMTIxMjkwMjE5NjA4NjQwMzQ0MTgxNTk4MTM2Mjk3NzQ3NzEzMDk5NjA1MTg3MDcyMTEzNDk5OTk5OTgzNzI5NzgwNDk5NTEwNTk3MzE3MzI4MTYwOTYzMTg1OTUwMjQ0NTk0NTUzNDY5MDgzMDI2NDI1MjIzMDgyNTMzNDQ2ODUwMzUyNjE5MzExODgxNzEwMTAwMDMxMzc4Mzg3NTI4ODY1ODc1MzMyMDgzODE0MjA2MTcxNzc2NjkxNDczMDM1OTgyNTM0OTA0Mjg3NTU0Njg3MzExNTk1NjI4NjM4ODIzNTM3ODc1OTM3NTE5NTc3ODE4NTc3ODA1MzIxNzEyMjY4MDY2MTMwMDE5Mjc4NzY2MTExOTU5MDkyMTY0MjAxOTg5MzgwOTUyNTcyMDEwNjU0ODU4NjMyNzg5JyxcclxuXHJcblxyXG4gIC8vIFRoZSBpbml0aWFsIGNvbmZpZ3VyYXRpb24gcHJvcGVydGllcyBvZiB0aGUgRGVjaW1hbCBjb25zdHJ1Y3Rvci5cclxuICBERUZBVUxUUyA9IHtcclxuXHJcbiAgICAvLyBUaGVzZSB2YWx1ZXMgbXVzdCBiZSBpbnRlZ2VycyB3aXRoaW4gdGhlIHN0YXRlZCByYW5nZXMgKGluY2x1c2l2ZSkuXHJcbiAgICAvLyBNb3N0IG9mIHRoZXNlIHZhbHVlcyBjYW4gYmUgY2hhbmdlZCBhdCBydW4tdGltZSB1c2luZyB0aGUgYERlY2ltYWwuY29uZmlnYCBtZXRob2QuXHJcblxyXG4gICAgLy8gVGhlIG1heGltdW0gbnVtYmVyIG9mIHNpZ25pZmljYW50IGRpZ2l0cyBvZiB0aGUgcmVzdWx0IG9mIGEgY2FsY3VsYXRpb24gb3IgYmFzZSBjb252ZXJzaW9uLlxyXG4gICAgLy8gRS5nLiBgRGVjaW1hbC5jb25maWcoeyBwcmVjaXNpb246IDIwIH0pO2BcclxuICAgIHByZWNpc2lvbjogMjAsICAgICAgICAgICAgICAgICAgICAgICAgIC8vIDEgdG8gTUFYX0RJR0lUU1xyXG5cclxuICAgIC8vIFRoZSByb3VuZGluZyBtb2RlIHVzZWQgd2hlbiByb3VuZGluZyB0byBgcHJlY2lzaW9uYC5cclxuICAgIC8vXHJcbiAgICAvLyBST1VORF9VUCAgICAgICAgIDAgQXdheSBmcm9tIHplcm8uXHJcbiAgICAvLyBST1VORF9ET1dOICAgICAgIDEgVG93YXJkcyB6ZXJvLlxyXG4gICAgLy8gUk9VTkRfQ0VJTCAgICAgICAyIFRvd2FyZHMgK0luZmluaXR5LlxyXG4gICAgLy8gUk9VTkRfRkxPT1IgICAgICAzIFRvd2FyZHMgLUluZmluaXR5LlxyXG4gICAgLy8gUk9VTkRfSEFMRl9VUCAgICA0IFRvd2FyZHMgbmVhcmVzdCBuZWlnaGJvdXIuIElmIGVxdWlkaXN0YW50LCB1cC5cclxuICAgIC8vIFJPVU5EX0hBTEZfRE9XTiAgNSBUb3dhcmRzIG5lYXJlc3QgbmVpZ2hib3VyLiBJZiBlcXVpZGlzdGFudCwgZG93bi5cclxuICAgIC8vIFJPVU5EX0hBTEZfRVZFTiAgNiBUb3dhcmRzIG5lYXJlc3QgbmVpZ2hib3VyLiBJZiBlcXVpZGlzdGFudCwgdG93YXJkcyBldmVuIG5laWdoYm91ci5cclxuICAgIC8vIFJPVU5EX0hBTEZfQ0VJTCAgNyBUb3dhcmRzIG5lYXJlc3QgbmVpZ2hib3VyLiBJZiBlcXVpZGlzdGFudCwgdG93YXJkcyArSW5maW5pdHkuXHJcbiAgICAvLyBST1VORF9IQUxGX0ZMT09SIDggVG93YXJkcyBuZWFyZXN0IG5laWdoYm91ci4gSWYgZXF1aWRpc3RhbnQsIHRvd2FyZHMgLUluZmluaXR5LlxyXG4gICAgLy9cclxuICAgIC8vIEUuZy5cclxuICAgIC8vIGBEZWNpbWFsLnJvdW5kaW5nID0gNDtgXHJcbiAgICAvLyBgRGVjaW1hbC5yb3VuZGluZyA9IERlY2ltYWwuUk9VTkRfSEFMRl9VUDtgXHJcbiAgICByb3VuZGluZzogNCwgICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAwIHRvIDhcclxuXHJcbiAgICAvLyBUaGUgbW9kdWxvIG1vZGUgdXNlZCB3aGVuIGNhbGN1bGF0aW5nIHRoZSBtb2R1bHVzOiBhIG1vZCBuLlxyXG4gICAgLy8gVGhlIHF1b3RpZW50IChxID0gYSAvIG4pIGlzIGNhbGN1bGF0ZWQgYWNjb3JkaW5nIHRvIHRoZSBjb3JyZXNwb25kaW5nIHJvdW5kaW5nIG1vZGUuXHJcbiAgICAvLyBUaGUgcmVtYWluZGVyIChyKSBpcyBjYWxjdWxhdGVkIGFzOiByID0gYSAtIG4gKiBxLlxyXG4gICAgLy9cclxuICAgIC8vIFVQICAgICAgICAgMCBUaGUgcmVtYWluZGVyIGlzIHBvc2l0aXZlIGlmIHRoZSBkaXZpZGVuZCBpcyBuZWdhdGl2ZSwgZWxzZSBpcyBuZWdhdGl2ZS5cclxuICAgIC8vIERPV04gICAgICAgMSBUaGUgcmVtYWluZGVyIGhhcyB0aGUgc2FtZSBzaWduIGFzIHRoZSBkaXZpZGVuZCAoSmF2YVNjcmlwdCAlKS5cclxuICAgIC8vIEZMT09SICAgICAgMyBUaGUgcmVtYWluZGVyIGhhcyB0aGUgc2FtZSBzaWduIGFzIHRoZSBkaXZpc29yIChQeXRob24gJSkuXHJcbiAgICAvLyBIQUxGX0VWRU4gIDYgVGhlIElFRUUgNzU0IHJlbWFpbmRlciBmdW5jdGlvbi5cclxuICAgIC8vIEVVQ0xJRCAgICAgOSBFdWNsaWRpYW4gZGl2aXNpb24uIHEgPSBzaWduKG4pICogZmxvb3IoYSAvIGFicyhuKSkuIEFsd2F5cyBwb3NpdGl2ZS5cclxuICAgIC8vXHJcbiAgICAvLyBUcnVuY2F0ZWQgZGl2aXNpb24gKDEpLCBmbG9vcmVkIGRpdmlzaW9uICgzKSwgdGhlIElFRUUgNzU0IHJlbWFpbmRlciAoNiksIGFuZCBFdWNsaWRpYW5cclxuICAgIC8vIGRpdmlzaW9uICg5KSBhcmUgY29tbW9ubHkgdXNlZCBmb3IgdGhlIG1vZHVsdXMgb3BlcmF0aW9uLiBUaGUgb3RoZXIgcm91bmRpbmcgbW9kZXMgY2FuIGFsc29cclxuICAgIC8vIGJlIHVzZWQsIGJ1dCB0aGV5IG1heSBub3QgZ2l2ZSB1c2VmdWwgcmVzdWx0cy5cclxuICAgIG1vZHVsbzogMSwgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIDAgdG8gOVxyXG5cclxuICAgIC8vIFRoZSBleHBvbmVudCB2YWx1ZSBhdCBhbmQgYmVuZWF0aCB3aGljaCBgdG9TdHJpbmdgIHJldHVybnMgZXhwb25lbnRpYWwgbm90YXRpb24uXHJcbiAgICAvLyBKYXZhU2NyaXB0IG51bWJlcnM6IC03XHJcbiAgICB0b0V4cE5lZzogLTcsICAgICAgICAgICAgICAgICAgICAgICAgICAvLyAwIHRvIC1FWFBfTElNSVRcclxuXHJcbiAgICAvLyBUaGUgZXhwb25lbnQgdmFsdWUgYXQgYW5kIGFib3ZlIHdoaWNoIGB0b1N0cmluZ2AgcmV0dXJucyBleHBvbmVudGlhbCBub3RhdGlvbi5cclxuICAgIC8vIEphdmFTY3JpcHQgbnVtYmVyczogMjFcclxuICAgIHRvRXhwUG9zOiAgMjEsICAgICAgICAgICAgICAgICAgICAgICAgIC8vIDAgdG8gRVhQX0xJTUlUXHJcblxyXG4gICAgLy8gVGhlIG1pbmltdW0gZXhwb25lbnQgdmFsdWUsIGJlbmVhdGggd2hpY2ggdW5kZXJmbG93IHRvIHplcm8gb2NjdXJzLlxyXG4gICAgLy8gSmF2YVNjcmlwdCBudW1iZXJzOiAtMzI0ICAoNWUtMzI0KVxyXG4gICAgbWluRTogLUVYUF9MSU1JVCwgICAgICAgICAgICAgICAgICAgICAgLy8gLTEgdG8gLUVYUF9MSU1JVFxyXG5cclxuICAgIC8vIFRoZSBtYXhpbXVtIGV4cG9uZW50IHZhbHVlLCBhYm92ZSB3aGljaCBvdmVyZmxvdyB0byBJbmZpbml0eSBvY2N1cnMuXHJcbiAgICAvLyBKYXZhU2NyaXB0IG51bWJlcnM6IDMwOCAgKDEuNzk3NjkzMTM0ODYyMzE1N2UrMzA4KVxyXG4gICAgbWF4RTogRVhQX0xJTUlULCAgICAgICAgICAgICAgICAgICAgICAgLy8gMSB0byBFWFBfTElNSVRcclxuXHJcbiAgICAvLyBXaGV0aGVyIHRvIHVzZSBjcnlwdG9ncmFwaGljYWxseS1zZWN1cmUgcmFuZG9tIG51bWJlciBnZW5lcmF0aW9uLCBpZiBhdmFpbGFibGUuXHJcbiAgICBjcnlwdG86IGZhbHNlICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB0cnVlL2ZhbHNlXHJcbiAgfSxcclxuXHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSBFTkQgT0YgRURJVEFCTEUgREVGQVVMVFMgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAvL1xyXG5cclxuXHJcbiAgaW5leGFjdCwgcXVhZHJhbnQsXHJcbiAgZXh0ZXJuYWwgPSB0cnVlLFxyXG5cclxuICBkZWNpbWFsRXJyb3IgPSAnW0RlY2ltYWxFcnJvcl0gJyxcclxuICBpbnZhbGlkQXJndW1lbnQgPSBkZWNpbWFsRXJyb3IgKyAnSW52YWxpZCBhcmd1bWVudDogJyxcclxuICBwcmVjaXNpb25MaW1pdEV4Y2VlZGVkID0gZGVjaW1hbEVycm9yICsgJ1ByZWNpc2lvbiBsaW1pdCBleGNlZWRlZCcsXHJcbiAgY3J5cHRvVW5hdmFpbGFibGUgPSBkZWNpbWFsRXJyb3IgKyAnY3J5cHRvIHVuYXZhaWxhYmxlJyxcclxuICB0YWcgPSAnW29iamVjdCBEZWNpbWFsXScsXHJcblxyXG4gIG1hdGhmbG9vciA9IE1hdGguZmxvb3IsXHJcbiAgbWF0aHBvdyA9IE1hdGgucG93LFxyXG5cclxuICBpc0JpbmFyeSA9IC9eMGIoWzAxXSsoXFwuWzAxXSopP3xcXC5bMDFdKykocFsrLV0/XFxkKyk/JC9pLFxyXG4gIGlzSGV4ID0gL14weChbMC05YS1mXSsoXFwuWzAtOWEtZl0qKT98XFwuWzAtOWEtZl0rKShwWystXT9cXGQrKT8kL2ksXHJcbiAgaXNPY3RhbCA9IC9eMG8oWzAtN10rKFxcLlswLTddKik/fFxcLlswLTddKykocFsrLV0/XFxkKyk/JC9pLFxyXG4gIGlzRGVjaW1hbCA9IC9eKFxcZCsoXFwuXFxkKik/fFxcLlxcZCspKGVbKy1dP1xcZCspPyQvaSxcclxuXHJcbiAgQkFTRSA9IDFlNyxcclxuICBMT0dfQkFTRSA9IDcsXHJcbiAgTUFYX1NBRkVfSU5URUdFUiA9IDkwMDcxOTkyNTQ3NDA5OTEsXHJcblxyXG4gIExOMTBfUFJFQ0lTSU9OID0gTE4xMC5sZW5ndGggLSAxLFxyXG4gIFBJX1BSRUNJU0lPTiA9IFBJLmxlbmd0aCAtIDEsXHJcblxyXG4gIC8vIERlY2ltYWwucHJvdG90eXBlIG9iamVjdFxyXG4gIFAgPSB7IHRvU3RyaW5nVGFnOiB0YWcgfTtcclxuXHJcblxyXG4vLyBEZWNpbWFsIHByb3RvdHlwZSBtZXRob2RzXHJcblxyXG5cclxuLypcclxuICogIGFic29sdXRlVmFsdWUgICAgICAgICAgICAgYWJzXHJcbiAqICBjZWlsXHJcbiAqICBjbGFtcGVkVG8gICAgICAgICAgICAgICAgIGNsYW1wXHJcbiAqICBjb21wYXJlZFRvICAgICAgICAgICAgICAgIGNtcFxyXG4gKiAgY29zaW5lICAgICAgICAgICAgICAgICAgICBjb3NcclxuICogIGN1YmVSb290ICAgICAgICAgICAgICAgICAgY2JydFxyXG4gKiAgZGVjaW1hbFBsYWNlcyAgICAgICAgICAgICBkcFxyXG4gKiAgZGl2aWRlZEJ5ICAgICAgICAgICAgICAgICBkaXZcclxuICogIGRpdmlkZWRUb0ludGVnZXJCeSAgICAgICAgZGl2VG9JbnRcclxuICogIGVxdWFscyAgICAgICAgICAgICAgICAgICAgZXFcclxuICogIGZsb29yXHJcbiAqICBncmVhdGVyVGhhbiAgICAgICAgICAgICAgIGd0XHJcbiAqICBncmVhdGVyVGhhbk9yRXF1YWxUbyAgICAgIGd0ZVxyXG4gKiAgaHlwZXJib2xpY0Nvc2luZSAgICAgICAgICBjb3NoXHJcbiAqICBoeXBlcmJvbGljU2luZSAgICAgICAgICAgIHNpbmhcclxuICogIGh5cGVyYm9saWNUYW5nZW50ICAgICAgICAgdGFuaFxyXG4gKiAgaW52ZXJzZUNvc2luZSAgICAgICAgICAgICBhY29zXHJcbiAqICBpbnZlcnNlSHlwZXJib2xpY0Nvc2luZSAgIGFjb3NoXHJcbiAqICBpbnZlcnNlSHlwZXJib2xpY1NpbmUgICAgIGFzaW5oXHJcbiAqICBpbnZlcnNlSHlwZXJib2xpY1RhbmdlbnQgIGF0YW5oXHJcbiAqICBpbnZlcnNlU2luZSAgICAgICAgICAgICAgIGFzaW5cclxuICogIGludmVyc2VUYW5nZW50ICAgICAgICAgICAgYXRhblxyXG4gKiAgaXNGaW5pdGVcclxuICogIGlzSW50ZWdlciAgICAgICAgICAgICAgICAgaXNJbnRcclxuICogIGlzTmFOXHJcbiAqICBpc05lZ2F0aXZlICAgICAgICAgICAgICAgIGlzTmVnXHJcbiAqICBpc1Bvc2l0aXZlICAgICAgICAgICAgICAgIGlzUG9zXHJcbiAqICBpc1plcm9cclxuICogIGxlc3NUaGFuICAgICAgICAgICAgICAgICAgbHRcclxuICogIGxlc3NUaGFuT3JFcXVhbFRvICAgICAgICAgbHRlXHJcbiAqICBsb2dhcml0aG0gICAgICAgICAgICAgICAgIGxvZ1xyXG4gKiAgW21heGltdW1dICAgICAgICAgICAgICAgICBbbWF4XVxyXG4gKiAgW21pbmltdW1dICAgICAgICAgICAgICAgICBbbWluXVxyXG4gKiAgbWludXMgICAgICAgICAgICAgICAgICAgICBzdWJcclxuICogIG1vZHVsbyAgICAgICAgICAgICAgICAgICAgbW9kXHJcbiAqICBuYXR1cmFsRXhwb25lbnRpYWwgICAgICAgIGV4cFxyXG4gKiAgbmF0dXJhbExvZ2FyaXRobSAgICAgICAgICBsblxyXG4gKiAgbmVnYXRlZCAgICAgICAgICAgICAgICAgICBuZWdcclxuICogIHBsdXMgICAgICAgICAgICAgICAgICAgICAgYWRkXHJcbiAqICBwcmVjaXNpb24gICAgICAgICAgICAgICAgIHNkXHJcbiAqICByb3VuZFxyXG4gKiAgc2luZSAgICAgICAgICAgICAgICAgICAgICBzaW5cclxuICogIHNxdWFyZVJvb3QgICAgICAgICAgICAgICAgc3FydFxyXG4gKiAgdGFuZ2VudCAgICAgICAgICAgICAgICAgICB0YW5cclxuICogIHRpbWVzICAgICAgICAgICAgICAgICAgICAgbXVsXHJcbiAqICB0b0JpbmFyeVxyXG4gKiAgdG9EZWNpbWFsUGxhY2VzICAgICAgICAgICB0b0RQXHJcbiAqICB0b0V4cG9uZW50aWFsXHJcbiAqICB0b0ZpeGVkXHJcbiAqICB0b0ZyYWN0aW9uXHJcbiAqICB0b0hleGFkZWNpbWFsICAgICAgICAgICAgIHRvSGV4XHJcbiAqICB0b05lYXJlc3RcclxuICogIHRvTnVtYmVyXHJcbiAqICB0b09jdGFsXHJcbiAqICB0b1Bvd2VyICAgICAgICAgICAgICAgICAgIHBvd1xyXG4gKiAgdG9QcmVjaXNpb25cclxuICogIHRvU2lnbmlmaWNhbnREaWdpdHMgICAgICAgdG9TRFxyXG4gKiAgdG9TdHJpbmdcclxuICogIHRydW5jYXRlZCAgICAgICAgICAgICAgICAgdHJ1bmNcclxuICogIHZhbHVlT2YgICAgICAgICAgICAgICAgICAgdG9KU09OXHJcbiAqL1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBhYnNvbHV0ZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwuXHJcbiAqXHJcbiAqL1xyXG5QLmFic29sdXRlVmFsdWUgPSBQLmFicyA9IGZ1bmN0aW9uICgpIHtcclxuICB2YXIgeCA9IG5ldyB0aGlzLmNvbnN0cnVjdG9yKHRoaXMpO1xyXG4gIGlmICh4LnMgPCAwKSB4LnMgPSAxO1xyXG4gIHJldHVybiBmaW5hbGlzZSh4KTtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsIHJvdW5kZWQgdG8gYSB3aG9sZSBudW1iZXIgaW4gdGhlXHJcbiAqIGRpcmVjdGlvbiBvZiBwb3NpdGl2ZSBJbmZpbml0eS5cclxuICpcclxuICovXHJcblAuY2VpbCA9IGZ1bmN0aW9uICgpIHtcclxuICByZXR1cm4gZmluYWxpc2UobmV3IHRoaXMuY29uc3RydWN0b3IodGhpcyksIHRoaXMuZSArIDEsIDIpO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgY2xhbXBlZCB0byB0aGUgcmFuZ2VcclxuICogZGVsaW5lYXRlZCBieSBgbWluYCBhbmQgYG1heGAuXHJcbiAqXHJcbiAqIG1pbiB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH1cclxuICogbWF4IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfVxyXG4gKlxyXG4gKi9cclxuUC5jbGFtcGVkVG8gPSBQLmNsYW1wID0gZnVuY3Rpb24gKG1pbiwgbWF4KSB7XHJcbiAgdmFyIGssXHJcbiAgICB4ID0gdGhpcyxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yO1xyXG4gIG1pbiA9IG5ldyBDdG9yKG1pbik7XHJcbiAgbWF4ID0gbmV3IEN0b3IobWF4KTtcclxuICBpZiAoIW1pbi5zIHx8ICFtYXgucykgcmV0dXJuIG5ldyBDdG9yKE5hTik7XHJcbiAgaWYgKG1pbi5ndChtYXgpKSB0aHJvdyBFcnJvcihpbnZhbGlkQXJndW1lbnQgKyBtYXgpO1xyXG4gIGsgPSB4LmNtcChtaW4pO1xyXG4gIHJldHVybiBrIDwgMCA/IG1pbiA6IHguY21wKG1heCkgPiAwID8gbWF4IDogbmV3IEN0b3IoeCk7XHJcbn07XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuXHJcbiAqICAgMSAgICBpZiB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsIGlzIGdyZWF0ZXIgdGhhbiB0aGUgdmFsdWUgb2YgYHlgLFxyXG4gKiAgLTEgICAgaWYgdGhlIHZhbHVlIG9mIHRoaXMgRGVjaW1hbCBpcyBsZXNzIHRoYW4gdGhlIHZhbHVlIG9mIGB5YCxcclxuICogICAwICAgIGlmIHRoZXkgaGF2ZSB0aGUgc2FtZSB2YWx1ZSxcclxuICogICBOYU4gIGlmIHRoZSB2YWx1ZSBvZiBlaXRoZXIgRGVjaW1hbCBpcyBOYU4uXHJcbiAqXHJcbiAqL1xyXG5QLmNvbXBhcmVkVG8gPSBQLmNtcCA9IGZ1bmN0aW9uICh5KSB7XHJcbiAgdmFyIGksIGosIHhkTCwgeWRMLFxyXG4gICAgeCA9IHRoaXMsXHJcbiAgICB4ZCA9IHguZCxcclxuICAgIHlkID0gKHkgPSBuZXcgeC5jb25zdHJ1Y3Rvcih5KSkuZCxcclxuICAgIHhzID0geC5zLFxyXG4gICAgeXMgPSB5LnM7XHJcblxyXG4gIC8vIEVpdGhlciBOYU4gb3IgwrFJbmZpbml0eT9cclxuICBpZiAoIXhkIHx8ICF5ZCkge1xyXG4gICAgcmV0dXJuICF4cyB8fCAheXMgPyBOYU4gOiB4cyAhPT0geXMgPyB4cyA6IHhkID09PSB5ZCA/IDAgOiAheGQgXiB4cyA8IDAgPyAxIDogLTE7XHJcbiAgfVxyXG5cclxuICAvLyBFaXRoZXIgemVybz9cclxuICBpZiAoIXhkWzBdIHx8ICF5ZFswXSkgcmV0dXJuIHhkWzBdID8geHMgOiB5ZFswXSA/IC15cyA6IDA7XHJcblxyXG4gIC8vIFNpZ25zIGRpZmZlcj9cclxuICBpZiAoeHMgIT09IHlzKSByZXR1cm4geHM7XHJcblxyXG4gIC8vIENvbXBhcmUgZXhwb25lbnRzLlxyXG4gIGlmICh4LmUgIT09IHkuZSkgcmV0dXJuIHguZSA+IHkuZSBeIHhzIDwgMCA/IDEgOiAtMTtcclxuXHJcbiAgeGRMID0geGQubGVuZ3RoO1xyXG4gIHlkTCA9IHlkLmxlbmd0aDtcclxuXHJcbiAgLy8gQ29tcGFyZSBkaWdpdCBieSBkaWdpdC5cclxuICBmb3IgKGkgPSAwLCBqID0geGRMIDwgeWRMID8geGRMIDogeWRMOyBpIDwgajsgKytpKSB7XHJcbiAgICBpZiAoeGRbaV0gIT09IHlkW2ldKSByZXR1cm4geGRbaV0gPiB5ZFtpXSBeIHhzIDwgMCA/IDEgOiAtMTtcclxuICB9XHJcblxyXG4gIC8vIENvbXBhcmUgbGVuZ3Rocy5cclxuICByZXR1cm4geGRMID09PSB5ZEwgPyAwIDogeGRMID4geWRMIF4geHMgPCAwID8gMSA6IC0xO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBjb3NpbmUgb2YgdGhlIHZhbHVlIGluIHJhZGlhbnMgb2YgdGhpcyBEZWNpbWFsLlxyXG4gKlxyXG4gKiBEb21haW46IFstSW5maW5pdHksIEluZmluaXR5XVxyXG4gKiBSYW5nZTogWy0xLCAxXVxyXG4gKlxyXG4gKiBjb3MoMCkgICAgICAgICA9IDFcclxuICogY29zKC0wKSAgICAgICAgPSAxXHJcbiAqIGNvcyhJbmZpbml0eSkgID0gTmFOXHJcbiAqIGNvcygtSW5maW5pdHkpID0gTmFOXHJcbiAqIGNvcyhOYU4pICAgICAgID0gTmFOXHJcbiAqXHJcbiAqL1xyXG5QLmNvc2luZSA9IFAuY29zID0gZnVuY3Rpb24gKCkge1xyXG4gIHZhciBwciwgcm0sXHJcbiAgICB4ID0gdGhpcyxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yO1xyXG5cclxuICBpZiAoIXguZCkgcmV0dXJuIG5ldyBDdG9yKE5hTik7XHJcblxyXG4gIC8vIGNvcygwKSA9IGNvcygtMCkgPSAxXHJcbiAgaWYgKCF4LmRbMF0pIHJldHVybiBuZXcgQ3RvcigxKTtcclxuXHJcbiAgcHIgPSBDdG9yLnByZWNpc2lvbjtcclxuICBybSA9IEN0b3Iucm91bmRpbmc7XHJcbiAgQ3Rvci5wcmVjaXNpb24gPSBwciArIE1hdGgubWF4KHguZSwgeC5zZCgpKSArIExPR19CQVNFO1xyXG4gIEN0b3Iucm91bmRpbmcgPSAxO1xyXG5cclxuICB4ID0gY29zaW5lKEN0b3IsIHRvTGVzc1RoYW5IYWxmUGkoQ3RvciwgeCkpO1xyXG5cclxuICBDdG9yLnByZWNpc2lvbiA9IHByO1xyXG4gIEN0b3Iucm91bmRpbmcgPSBybTtcclxuXHJcbiAgcmV0dXJuIGZpbmFsaXNlKHF1YWRyYW50ID09IDIgfHwgcXVhZHJhbnQgPT0gMyA/IHgubmVnKCkgOiB4LCBwciwgcm0sIHRydWUpO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBjdWJlIHJvb3Qgb2YgdGhlIHZhbHVlIG9mIHRoaXMgRGVjaW1hbCwgcm91bmRlZCB0b1xyXG4gKiBgcHJlY2lzaW9uYCBzaWduaWZpY2FudCBkaWdpdHMgdXNpbmcgcm91bmRpbmcgbW9kZSBgcm91bmRpbmdgLlxyXG4gKlxyXG4gKiAgY2JydCgwKSAgPSAgMFxyXG4gKiAgY2JydCgtMCkgPSAtMFxyXG4gKiAgY2JydCgxKSAgPSAgMVxyXG4gKiAgY2JydCgtMSkgPSAtMVxyXG4gKiAgY2JydChOKSAgPSAgTlxyXG4gKiAgY2JydCgtSSkgPSAtSVxyXG4gKiAgY2JydChJKSAgPSAgSVxyXG4gKlxyXG4gKiBNYXRoLmNicnQoeCkgPSAoeCA8IDAgPyAtTWF0aC5wb3coLXgsIDEvMykgOiBNYXRoLnBvdyh4LCAxLzMpKVxyXG4gKlxyXG4gKi9cclxuUC5jdWJlUm9vdCA9IFAuY2JydCA9IGZ1bmN0aW9uICgpIHtcclxuICB2YXIgZSwgbSwgbiwgciwgcmVwLCBzLCBzZCwgdCwgdDMsIHQzcGx1c3gsXHJcbiAgICB4ID0gdGhpcyxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yO1xyXG5cclxuICBpZiAoIXguaXNGaW5pdGUoKSB8fCB4LmlzWmVybygpKSByZXR1cm4gbmV3IEN0b3IoeCk7XHJcbiAgZXh0ZXJuYWwgPSBmYWxzZTtcclxuXHJcbiAgLy8gSW5pdGlhbCBlc3RpbWF0ZS5cclxuICBzID0geC5zICogbWF0aHBvdyh4LnMgKiB4LCAxIC8gMyk7XHJcblxyXG4gICAvLyBNYXRoLmNicnQgdW5kZXJmbG93L292ZXJmbG93P1xyXG4gICAvLyBQYXNzIHggdG8gTWF0aC5wb3cgYXMgaW50ZWdlciwgdGhlbiBhZGp1c3QgdGhlIGV4cG9uZW50IG9mIHRoZSByZXN1bHQuXHJcbiAgaWYgKCFzIHx8IE1hdGguYWJzKHMpID09IDEgLyAwKSB7XHJcbiAgICBuID0gZGlnaXRzVG9TdHJpbmcoeC5kKTtcclxuICAgIGUgPSB4LmU7XHJcblxyXG4gICAgLy8gQWRqdXN0IG4gZXhwb25lbnQgc28gaXQgaXMgYSBtdWx0aXBsZSBvZiAzIGF3YXkgZnJvbSB4IGV4cG9uZW50LlxyXG4gICAgaWYgKHMgPSAoZSAtIG4ubGVuZ3RoICsgMSkgJSAzKSBuICs9IChzID09IDEgfHwgcyA9PSAtMiA/ICcwJyA6ICcwMCcpO1xyXG4gICAgcyA9IG1hdGhwb3cobiwgMSAvIDMpO1xyXG5cclxuICAgIC8vIFJhcmVseSwgZSBtYXkgYmUgb25lIGxlc3MgdGhhbiB0aGUgcmVzdWx0IGV4cG9uZW50IHZhbHVlLlxyXG4gICAgZSA9IG1hdGhmbG9vcigoZSArIDEpIC8gMykgLSAoZSAlIDMgPT0gKGUgPCAwID8gLTEgOiAyKSk7XHJcblxyXG4gICAgaWYgKHMgPT0gMSAvIDApIHtcclxuICAgICAgbiA9ICc1ZScgKyBlO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgbiA9IHMudG9FeHBvbmVudGlhbCgpO1xyXG4gICAgICBuID0gbi5zbGljZSgwLCBuLmluZGV4T2YoJ2UnKSArIDEpICsgZTtcclxuICAgIH1cclxuXHJcbiAgICByID0gbmV3IEN0b3Iobik7XHJcbiAgICByLnMgPSB4LnM7XHJcbiAgfSBlbHNlIHtcclxuICAgIHIgPSBuZXcgQ3RvcihzLnRvU3RyaW5nKCkpO1xyXG4gIH1cclxuXHJcbiAgc2QgPSAoZSA9IEN0b3IucHJlY2lzaW9uKSArIDM7XHJcblxyXG4gIC8vIEhhbGxleSdzIG1ldGhvZC5cclxuICAvLyBUT0RPPyBDb21wYXJlIE5ld3RvbidzIG1ldGhvZC5cclxuICBmb3IgKDs7KSB7XHJcbiAgICB0ID0gcjtcclxuICAgIHQzID0gdC50aW1lcyh0KS50aW1lcyh0KTtcclxuICAgIHQzcGx1c3ggPSB0My5wbHVzKHgpO1xyXG4gICAgciA9IGRpdmlkZSh0M3BsdXN4LnBsdXMoeCkudGltZXModCksIHQzcGx1c3gucGx1cyh0MyksIHNkICsgMiwgMSk7XHJcblxyXG4gICAgLy8gVE9ETz8gUmVwbGFjZSB3aXRoIGZvci1sb29wIGFuZCBjaGVja1JvdW5kaW5nRGlnaXRzLlxyXG4gICAgaWYgKGRpZ2l0c1RvU3RyaW5nKHQuZCkuc2xpY2UoMCwgc2QpID09PSAobiA9IGRpZ2l0c1RvU3RyaW5nKHIuZCkpLnNsaWNlKDAsIHNkKSkge1xyXG4gICAgICBuID0gbi5zbGljZShzZCAtIDMsIHNkICsgMSk7XHJcblxyXG4gICAgICAvLyBUaGUgNHRoIHJvdW5kaW5nIGRpZ2l0IG1heSBiZSBpbiBlcnJvciBieSAtMSBzbyBpZiB0aGUgNCByb3VuZGluZyBkaWdpdHMgYXJlIDk5OTkgb3IgNDk5OVxyXG4gICAgICAvLyAsIGkuZS4gYXBwcm9hY2hpbmcgYSByb3VuZGluZyBib3VuZGFyeSwgY29udGludWUgdGhlIGl0ZXJhdGlvbi5cclxuICAgICAgaWYgKG4gPT0gJzk5OTknIHx8ICFyZXAgJiYgbiA9PSAnNDk5OScpIHtcclxuXHJcbiAgICAgICAgLy8gT24gdGhlIGZpcnN0IGl0ZXJhdGlvbiBvbmx5LCBjaGVjayB0byBzZWUgaWYgcm91bmRpbmcgdXAgZ2l2ZXMgdGhlIGV4YWN0IHJlc3VsdCBhcyB0aGVcclxuICAgICAgICAvLyBuaW5lcyBtYXkgaW5maW5pdGVseSByZXBlYXQuXHJcbiAgICAgICAgaWYgKCFyZXApIHtcclxuICAgICAgICAgIGZpbmFsaXNlKHQsIGUgKyAxLCAwKTtcclxuXHJcbiAgICAgICAgICBpZiAodC50aW1lcyh0KS50aW1lcyh0KS5lcSh4KSkge1xyXG4gICAgICAgICAgICByID0gdDtcclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBzZCArPSA0O1xyXG4gICAgICAgIHJlcCA9IDE7XHJcbiAgICAgIH0gZWxzZSB7XHJcblxyXG4gICAgICAgIC8vIElmIHRoZSByb3VuZGluZyBkaWdpdHMgYXJlIG51bGwsIDB7MCw0fSBvciA1MHswLDN9LCBjaGVjayBmb3IgYW4gZXhhY3QgcmVzdWx0LlxyXG4gICAgICAgIC8vIElmIG5vdCwgdGhlbiB0aGVyZSBhcmUgZnVydGhlciBkaWdpdHMgYW5kIG0gd2lsbCBiZSB0cnV0aHkuXHJcbiAgICAgICAgaWYgKCErbiB8fCAhK24uc2xpY2UoMSkgJiYgbi5jaGFyQXQoMCkgPT0gJzUnKSB7XHJcblxyXG4gICAgICAgICAgLy8gVHJ1bmNhdGUgdG8gdGhlIGZpcnN0IHJvdW5kaW5nIGRpZ2l0LlxyXG4gICAgICAgICAgZmluYWxpc2UociwgZSArIDEsIDEpO1xyXG4gICAgICAgICAgbSA9ICFyLnRpbWVzKHIpLnRpbWVzKHIpLmVxKHgpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIGV4dGVybmFsID0gdHJ1ZTtcclxuXHJcbiAgcmV0dXJuIGZpbmFsaXNlKHIsIGUsIEN0b3Iucm91bmRpbmcsIG0pO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiB0aGUgbnVtYmVyIG9mIGRlY2ltYWwgcGxhY2VzIG9mIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwuXHJcbiAqXHJcbiAqL1xyXG5QLmRlY2ltYWxQbGFjZXMgPSBQLmRwID0gZnVuY3Rpb24gKCkge1xyXG4gIHZhciB3LFxyXG4gICAgZCA9IHRoaXMuZCxcclxuICAgIG4gPSBOYU47XHJcblxyXG4gIGlmIChkKSB7XHJcbiAgICB3ID0gZC5sZW5ndGggLSAxO1xyXG4gICAgbiA9ICh3IC0gbWF0aGZsb29yKHRoaXMuZSAvIExPR19CQVNFKSkgKiBMT0dfQkFTRTtcclxuXHJcbiAgICAvLyBTdWJ0cmFjdCB0aGUgbnVtYmVyIG9mIHRyYWlsaW5nIHplcm9zIG9mIHRoZSBsYXN0IHdvcmQuXHJcbiAgICB3ID0gZFt3XTtcclxuICAgIGlmICh3KSBmb3IgKDsgdyAlIDEwID09IDA7IHcgLz0gMTApIG4tLTtcclxuICAgIGlmIChuIDwgMCkgbiA9IDA7XHJcbiAgfVxyXG5cclxuICByZXR1cm4gbjtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiAgbiAvIDAgPSBJXHJcbiAqICBuIC8gTiA9IE5cclxuICogIG4gLyBJID0gMFxyXG4gKiAgMCAvIG4gPSAwXHJcbiAqICAwIC8gMCA9IE5cclxuICogIDAgLyBOID0gTlxyXG4gKiAgMCAvIEkgPSAwXHJcbiAqICBOIC8gbiA9IE5cclxuICogIE4gLyAwID0gTlxyXG4gKiAgTiAvIE4gPSBOXHJcbiAqICBOIC8gSSA9IE5cclxuICogIEkgLyBuID0gSVxyXG4gKiAgSSAvIDAgPSBJXHJcbiAqICBJIC8gTiA9IE5cclxuICogIEkgLyBJID0gTlxyXG4gKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsIGRpdmlkZWQgYnkgYHlgLCByb3VuZGVkIHRvXHJcbiAqIGBwcmVjaXNpb25gIHNpZ25pZmljYW50IGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqL1xyXG5QLmRpdmlkZWRCeSA9IFAuZGl2ID0gZnVuY3Rpb24gKHkpIHtcclxuICByZXR1cm4gZGl2aWRlKHRoaXMsIG5ldyB0aGlzLmNvbnN0cnVjdG9yKHkpKTtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgaW50ZWdlciBwYXJ0IG9mIGRpdmlkaW5nIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWxcclxuICogYnkgdGhlIHZhbHVlIG9mIGB5YCwgcm91bmRlZCB0byBgcHJlY2lzaW9uYCBzaWduaWZpY2FudCBkaWdpdHMgdXNpbmcgcm91bmRpbmcgbW9kZSBgcm91bmRpbmdgLlxyXG4gKlxyXG4gKi9cclxuUC5kaXZpZGVkVG9JbnRlZ2VyQnkgPSBQLmRpdlRvSW50ID0gZnVuY3Rpb24gKHkpIHtcclxuICB2YXIgeCA9IHRoaXMsXHJcbiAgICBDdG9yID0geC5jb25zdHJ1Y3RvcjtcclxuICByZXR1cm4gZmluYWxpc2UoZGl2aWRlKHgsIG5ldyBDdG9yKHkpLCAwLCAxLCAxKSwgQ3Rvci5wcmVjaXNpb24sIEN0b3Iucm91bmRpbmcpO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiB0cnVlIGlmIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgaXMgZXF1YWwgdG8gdGhlIHZhbHVlIG9mIGB5YCwgb3RoZXJ3aXNlIHJldHVybiBmYWxzZS5cclxuICpcclxuICovXHJcblAuZXF1YWxzID0gUC5lcSA9IGZ1bmN0aW9uICh5KSB7XHJcbiAgcmV0dXJuIHRoaXMuY21wKHkpID09PSAwO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgcm91bmRlZCB0byBhIHdob2xlIG51bWJlciBpbiB0aGVcclxuICogZGlyZWN0aW9uIG9mIG5lZ2F0aXZlIEluZmluaXR5LlxyXG4gKlxyXG4gKi9cclxuUC5mbG9vciA9IGZ1bmN0aW9uICgpIHtcclxuICByZXR1cm4gZmluYWxpc2UobmV3IHRoaXMuY29uc3RydWN0b3IodGhpcyksIHRoaXMuZSArIDEsIDMpO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiB0cnVlIGlmIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgaXMgZ3JlYXRlciB0aGFuIHRoZSB2YWx1ZSBvZiBgeWAsIG90aGVyd2lzZSByZXR1cm5cclxuICogZmFsc2UuXHJcbiAqXHJcbiAqL1xyXG5QLmdyZWF0ZXJUaGFuID0gUC5ndCA9IGZ1bmN0aW9uICh5KSB7XHJcbiAgcmV0dXJuIHRoaXMuY21wKHkpID4gMDtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gdHJ1ZSBpZiB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsIGlzIGdyZWF0ZXIgdGhhbiBvciBlcXVhbCB0byB0aGUgdmFsdWUgb2YgYHlgLFxyXG4gKiBvdGhlcndpc2UgcmV0dXJuIGZhbHNlLlxyXG4gKlxyXG4gKi9cclxuUC5ncmVhdGVyVGhhbk9yRXF1YWxUbyA9IFAuZ3RlID0gZnVuY3Rpb24gKHkpIHtcclxuICB2YXIgayA9IHRoaXMuY21wKHkpO1xyXG4gIHJldHVybiBrID09IDEgfHwgayA9PT0gMDtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgaHlwZXJib2xpYyBjb3NpbmUgb2YgdGhlIHZhbHVlIGluIHJhZGlhbnMgb2YgdGhpc1xyXG4gKiBEZWNpbWFsLlxyXG4gKlxyXG4gKiBEb21haW46IFstSW5maW5pdHksIEluZmluaXR5XVxyXG4gKiBSYW5nZTogWzEsIEluZmluaXR5XVxyXG4gKlxyXG4gKiBjb3NoKHgpID0gMSArIHheMi8yISArIHheNC80ISArIHheNi82ISArIC4uLlxyXG4gKlxyXG4gKiBjb3NoKDApICAgICAgICAgPSAxXHJcbiAqIGNvc2goLTApICAgICAgICA9IDFcclxuICogY29zaChJbmZpbml0eSkgID0gSW5maW5pdHlcclxuICogY29zaCgtSW5maW5pdHkpID0gSW5maW5pdHlcclxuICogY29zaChOYU4pICAgICAgID0gTmFOXHJcbiAqXHJcbiAqICB4ICAgICAgICB0aW1lIHRha2VuIChtcykgICByZXN1bHRcclxuICogMTAwMCAgICAgIDkgICAgICAgICAgICAgICAgIDkuODUwMzU1NTcwMDg1MjM0OTY5NGUrNDMzXHJcbiAqIDEwMDAwICAgICAyNSAgICAgICAgICAgICAgICA0LjQwMzQwOTExMjgzMTQ2MDc5MzZlKzQzNDJcclxuICogMTAwMDAwICAgIDE3MSAgICAgICAgICAgICAgIDEuNDAzMzMxNjgwMjEzMDYxNTg5N2UrNDM0MjlcclxuICogMTAwMDAwMCAgIDM4MTcgICAgICAgICAgICAgIDEuNTE2NjA3Njk4NDAxMDQzNzcyNWUrNDM0Mjk0XHJcbiAqIDEwMDAwMDAwICBhYmFuZG9uZWQgYWZ0ZXIgMiBtaW51dGUgd2FpdFxyXG4gKlxyXG4gKiBUT0RPPyBDb21wYXJlIHBlcmZvcm1hbmNlIG9mIGNvc2goeCkgPSAwLjUgKiAoZXhwKHgpICsgZXhwKC14KSlcclxuICpcclxuICovXHJcblAuaHlwZXJib2xpY0Nvc2luZSA9IFAuY29zaCA9IGZ1bmN0aW9uICgpIHtcclxuICB2YXIgaywgbiwgcHIsIHJtLCBsZW4sXHJcbiAgICB4ID0gdGhpcyxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yLFxyXG4gICAgb25lID0gbmV3IEN0b3IoMSk7XHJcblxyXG4gIGlmICgheC5pc0Zpbml0ZSgpKSByZXR1cm4gbmV3IEN0b3IoeC5zID8gMSAvIDAgOiBOYU4pO1xyXG4gIGlmICh4LmlzWmVybygpKSByZXR1cm4gb25lO1xyXG5cclxuICBwciA9IEN0b3IucHJlY2lzaW9uO1xyXG4gIHJtID0gQ3Rvci5yb3VuZGluZztcclxuICBDdG9yLnByZWNpc2lvbiA9IHByICsgTWF0aC5tYXgoeC5lLCB4LnNkKCkpICsgNDtcclxuICBDdG9yLnJvdW5kaW5nID0gMTtcclxuICBsZW4gPSB4LmQubGVuZ3RoO1xyXG5cclxuICAvLyBBcmd1bWVudCByZWR1Y3Rpb246IGNvcyg0eCkgPSAxIC0gOGNvc14yKHgpICsgOGNvc140KHgpICsgMVxyXG4gIC8vIGkuZS4gY29zKHgpID0gMSAtIGNvc14yKHgvNCkoOCAtIDhjb3NeMih4LzQpKVxyXG5cclxuICAvLyBFc3RpbWF0ZSB0aGUgb3B0aW11bSBudW1iZXIgb2YgdGltZXMgdG8gdXNlIHRoZSBhcmd1bWVudCByZWR1Y3Rpb24uXHJcbiAgLy8gVE9ETz8gRXN0aW1hdGlvbiByZXVzZWQgZnJvbSBjb3NpbmUoKSBhbmQgbWF5IG5vdCBiZSBvcHRpbWFsIGhlcmUuXHJcbiAgaWYgKGxlbiA8IDMyKSB7XHJcbiAgICBrID0gTWF0aC5jZWlsKGxlbiAvIDMpO1xyXG4gICAgbiA9ICgxIC8gdGlueVBvdyg0LCBrKSkudG9TdHJpbmcoKTtcclxuICB9IGVsc2Uge1xyXG4gICAgayA9IDE2O1xyXG4gICAgbiA9ICcyLjMyODMwNjQzNjUzODY5NjI4OTA2MjVlLTEwJztcclxuICB9XHJcblxyXG4gIHggPSB0YXlsb3JTZXJpZXMoQ3RvciwgMSwgeC50aW1lcyhuKSwgbmV3IEN0b3IoMSksIHRydWUpO1xyXG5cclxuICAvLyBSZXZlcnNlIGFyZ3VtZW50IHJlZHVjdGlvblxyXG4gIHZhciBjb3NoMl94LFxyXG4gICAgaSA9IGssXHJcbiAgICBkOCA9IG5ldyBDdG9yKDgpO1xyXG4gIGZvciAoOyBpLS07KSB7XHJcbiAgICBjb3NoMl94ID0geC50aW1lcyh4KTtcclxuICAgIHggPSBvbmUubWludXMoY29zaDJfeC50aW1lcyhkOC5taW51cyhjb3NoMl94LnRpbWVzKGQ4KSkpKTtcclxuICB9XHJcblxyXG4gIHJldHVybiBmaW5hbGlzZSh4LCBDdG9yLnByZWNpc2lvbiA9IHByLCBDdG9yLnJvdW5kaW5nID0gcm0sIHRydWUpO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBoeXBlcmJvbGljIHNpbmUgb2YgdGhlIHZhbHVlIGluIHJhZGlhbnMgb2YgdGhpc1xyXG4gKiBEZWNpbWFsLlxyXG4gKlxyXG4gKiBEb21haW46IFstSW5maW5pdHksIEluZmluaXR5XVxyXG4gKiBSYW5nZTogWy1JbmZpbml0eSwgSW5maW5pdHldXHJcbiAqXHJcbiAqIHNpbmgoeCkgPSB4ICsgeF4zLzMhICsgeF41LzUhICsgeF43LzchICsgLi4uXHJcbiAqXHJcbiAqIHNpbmgoMCkgICAgICAgICA9IDBcclxuICogc2luaCgtMCkgICAgICAgID0gLTBcclxuICogc2luaChJbmZpbml0eSkgID0gSW5maW5pdHlcclxuICogc2luaCgtSW5maW5pdHkpID0gLUluZmluaXR5XHJcbiAqIHNpbmgoTmFOKSAgICAgICA9IE5hTlxyXG4gKlxyXG4gKiB4ICAgICAgICB0aW1lIHRha2VuIChtcylcclxuICogMTAgICAgICAgMiBtc1xyXG4gKiAxMDAgICAgICA1IG1zXHJcbiAqIDEwMDAgICAgIDE0IG1zXHJcbiAqIDEwMDAwICAgIDgyIG1zXHJcbiAqIDEwMDAwMCAgIDg4NiBtcyAgICAgICAgICAgIDEuNDAzMzMxNjgwMjEzMDYxNTg5N2UrNDM0MjlcclxuICogMjAwMDAwICAgMjYxMyBtc1xyXG4gKiAzMDAwMDAgICA1NDA3IG1zXHJcbiAqIDQwMDAwMCAgIDg4MjQgbXNcclxuICogNTAwMDAwICAgMTMwMjYgbXMgICAgICAgICAgOC43MDgwNjQzNjEyNzE4MDg0MTI5ZSsyMTcxNDZcclxuICogMTAwMDAwMCAgNDg1NDMgbXNcclxuICpcclxuICogVE9ETz8gQ29tcGFyZSBwZXJmb3JtYW5jZSBvZiBzaW5oKHgpID0gMC41ICogKGV4cCh4KSAtIGV4cCgteCkpXHJcbiAqXHJcbiAqL1xyXG5QLmh5cGVyYm9saWNTaW5lID0gUC5zaW5oID0gZnVuY3Rpb24gKCkge1xyXG4gIHZhciBrLCBwciwgcm0sIGxlbixcclxuICAgIHggPSB0aGlzLFxyXG4gICAgQ3RvciA9IHguY29uc3RydWN0b3I7XHJcblxyXG4gIGlmICgheC5pc0Zpbml0ZSgpIHx8IHguaXNaZXJvKCkpIHJldHVybiBuZXcgQ3Rvcih4KTtcclxuXHJcbiAgcHIgPSBDdG9yLnByZWNpc2lvbjtcclxuICBybSA9IEN0b3Iucm91bmRpbmc7XHJcbiAgQ3Rvci5wcmVjaXNpb24gPSBwciArIE1hdGgubWF4KHguZSwgeC5zZCgpKSArIDQ7XHJcbiAgQ3Rvci5yb3VuZGluZyA9IDE7XHJcbiAgbGVuID0geC5kLmxlbmd0aDtcclxuXHJcbiAgaWYgKGxlbiA8IDMpIHtcclxuICAgIHggPSB0YXlsb3JTZXJpZXMoQ3RvciwgMiwgeCwgeCwgdHJ1ZSk7XHJcbiAgfSBlbHNlIHtcclxuXHJcbiAgICAvLyBBbHRlcm5hdGl2ZSBhcmd1bWVudCByZWR1Y3Rpb246IHNpbmgoM3gpID0gc2luaCh4KSgzICsgNHNpbmheMih4KSlcclxuICAgIC8vIGkuZS4gc2luaCh4KSA9IHNpbmgoeC8zKSgzICsgNHNpbmheMih4LzMpKVxyXG4gICAgLy8gMyBtdWx0aXBsaWNhdGlvbnMgYW5kIDEgYWRkaXRpb25cclxuXHJcbiAgICAvLyBBcmd1bWVudCByZWR1Y3Rpb246IHNpbmgoNXgpID0gc2luaCh4KSg1ICsgc2luaF4yKHgpKDIwICsgMTZzaW5oXjIoeCkpKVxyXG4gICAgLy8gaS5lLiBzaW5oKHgpID0gc2luaCh4LzUpKDUgKyBzaW5oXjIoeC81KSgyMCArIDE2c2luaF4yKHgvNSkpKVxyXG4gICAgLy8gNCBtdWx0aXBsaWNhdGlvbnMgYW5kIDIgYWRkaXRpb25zXHJcblxyXG4gICAgLy8gRXN0aW1hdGUgdGhlIG9wdGltdW0gbnVtYmVyIG9mIHRpbWVzIHRvIHVzZSB0aGUgYXJndW1lbnQgcmVkdWN0aW9uLlxyXG4gICAgayA9IDEuNCAqIE1hdGguc3FydChsZW4pO1xyXG4gICAgayA9IGsgPiAxNiA/IDE2IDogayB8IDA7XHJcblxyXG4gICAgeCA9IHgudGltZXMoMSAvIHRpbnlQb3coNSwgaykpO1xyXG4gICAgeCA9IHRheWxvclNlcmllcyhDdG9yLCAyLCB4LCB4LCB0cnVlKTtcclxuXHJcbiAgICAvLyBSZXZlcnNlIGFyZ3VtZW50IHJlZHVjdGlvblxyXG4gICAgdmFyIHNpbmgyX3gsXHJcbiAgICAgIGQ1ID0gbmV3IEN0b3IoNSksXHJcbiAgICAgIGQxNiA9IG5ldyBDdG9yKDE2KSxcclxuICAgICAgZDIwID0gbmV3IEN0b3IoMjApO1xyXG4gICAgZm9yICg7IGstLTspIHtcclxuICAgICAgc2luaDJfeCA9IHgudGltZXMoeCk7XHJcbiAgICAgIHggPSB4LnRpbWVzKGQ1LnBsdXMoc2luaDJfeC50aW1lcyhkMTYudGltZXMoc2luaDJfeCkucGx1cyhkMjApKSkpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgQ3Rvci5wcmVjaXNpb24gPSBwcjtcclxuICBDdG9yLnJvdW5kaW5nID0gcm07XHJcblxyXG4gIHJldHVybiBmaW5hbGlzZSh4LCBwciwgcm0sIHRydWUpO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBoeXBlcmJvbGljIHRhbmdlbnQgb2YgdGhlIHZhbHVlIGluIHJhZGlhbnMgb2YgdGhpc1xyXG4gKiBEZWNpbWFsLlxyXG4gKlxyXG4gKiBEb21haW46IFstSW5maW5pdHksIEluZmluaXR5XVxyXG4gKiBSYW5nZTogWy0xLCAxXVxyXG4gKlxyXG4gKiB0YW5oKHgpID0gc2luaCh4KSAvIGNvc2goeClcclxuICpcclxuICogdGFuaCgwKSAgICAgICAgID0gMFxyXG4gKiB0YW5oKC0wKSAgICAgICAgPSAtMFxyXG4gKiB0YW5oKEluZmluaXR5KSAgPSAxXHJcbiAqIHRhbmgoLUluZmluaXR5KSA9IC0xXHJcbiAqIHRhbmgoTmFOKSAgICAgICA9IE5hTlxyXG4gKlxyXG4gKi9cclxuUC5oeXBlcmJvbGljVGFuZ2VudCA9IFAudGFuaCA9IGZ1bmN0aW9uICgpIHtcclxuICB2YXIgcHIsIHJtLFxyXG4gICAgeCA9IHRoaXMsXHJcbiAgICBDdG9yID0geC5jb25zdHJ1Y3RvcjtcclxuXHJcbiAgaWYgKCF4LmlzRmluaXRlKCkpIHJldHVybiBuZXcgQ3Rvcih4LnMpO1xyXG4gIGlmICh4LmlzWmVybygpKSByZXR1cm4gbmV3IEN0b3IoeCk7XHJcblxyXG4gIHByID0gQ3Rvci5wcmVjaXNpb247XHJcbiAgcm0gPSBDdG9yLnJvdW5kaW5nO1xyXG4gIEN0b3IucHJlY2lzaW9uID0gcHIgKyA3O1xyXG4gIEN0b3Iucm91bmRpbmcgPSAxO1xyXG5cclxuICByZXR1cm4gZGl2aWRlKHguc2luaCgpLCB4LmNvc2goKSwgQ3Rvci5wcmVjaXNpb24gPSBwciwgQ3Rvci5yb3VuZGluZyA9IHJtKTtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgYXJjY29zaW5lIChpbnZlcnNlIGNvc2luZSkgaW4gcmFkaWFucyBvZiB0aGUgdmFsdWUgb2ZcclxuICogdGhpcyBEZWNpbWFsLlxyXG4gKlxyXG4gKiBEb21haW46IFstMSwgMV1cclxuICogUmFuZ2U6IFswLCBwaV1cclxuICpcclxuICogYWNvcyh4KSA9IHBpLzIgLSBhc2luKHgpXHJcbiAqXHJcbiAqIGFjb3MoMCkgICAgICAgPSBwaS8yXHJcbiAqIGFjb3MoLTApICAgICAgPSBwaS8yXHJcbiAqIGFjb3MoMSkgICAgICAgPSAwXHJcbiAqIGFjb3MoLTEpICAgICAgPSBwaVxyXG4gKiBhY29zKDEvMikgICAgID0gcGkvM1xyXG4gKiBhY29zKC0xLzIpICAgID0gMipwaS8zXHJcbiAqIGFjb3MofHh8ID4gMSkgPSBOYU5cclxuICogYWNvcyhOYU4pICAgICA9IE5hTlxyXG4gKlxyXG4gKi9cclxuUC5pbnZlcnNlQ29zaW5lID0gUC5hY29zID0gZnVuY3Rpb24gKCkge1xyXG4gIHZhciB4ID0gdGhpcyxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yLFxyXG4gICAgayA9IHguYWJzKCkuY21wKDEpLFxyXG4gICAgcHIgPSBDdG9yLnByZWNpc2lvbixcclxuICAgIHJtID0gQ3Rvci5yb3VuZGluZztcclxuXHJcbiAgaWYgKGsgIT09IC0xKSB7XHJcbiAgICByZXR1cm4gayA9PT0gMFxyXG4gICAgICAvLyB8eHwgaXMgMVxyXG4gICAgICA/IHguaXNOZWcoKSA/IGdldFBpKEN0b3IsIHByLCBybSkgOiBuZXcgQ3RvcigwKVxyXG4gICAgICAvLyB8eHwgPiAxIG9yIHggaXMgTmFOXHJcbiAgICAgIDogbmV3IEN0b3IoTmFOKTtcclxuICB9XHJcblxyXG4gIGlmICh4LmlzWmVybygpKSByZXR1cm4gZ2V0UGkoQ3RvciwgcHIgKyA0LCBybSkudGltZXMoMC41KTtcclxuXHJcbiAgLy8gVE9ETz8gU3BlY2lhbCBjYXNlIGFjb3MoMC41KSA9IHBpLzMgYW5kIGFjb3MoLTAuNSkgPSAyKnBpLzNcclxuXHJcbiAgQ3Rvci5wcmVjaXNpb24gPSBwciArIDY7XHJcbiAgQ3Rvci5yb3VuZGluZyA9IDE7XHJcblxyXG4gIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vTWlrZU1jbC9kZWNpbWFsLmpzL3B1bGwvMjE3XHJcbiAgeCA9IG5ldyBDdG9yKDEpLm1pbnVzKHgpLmRpdih4LnBsdXMoMSkpLnNxcnQoKS5hdGFuKCk7XHJcblxyXG4gIEN0b3IucHJlY2lzaW9uID0gcHI7XHJcbiAgQ3Rvci5yb3VuZGluZyA9IHJtO1xyXG5cclxuICByZXR1cm4geC50aW1lcygyKTtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgaW52ZXJzZSBvZiB0aGUgaHlwZXJib2xpYyBjb3NpbmUgaW4gcmFkaWFucyBvZiB0aGVcclxuICogdmFsdWUgb2YgdGhpcyBEZWNpbWFsLlxyXG4gKlxyXG4gKiBEb21haW46IFsxLCBJbmZpbml0eV1cclxuICogUmFuZ2U6IFswLCBJbmZpbml0eV1cclxuICpcclxuICogYWNvc2goeCkgPSBsbih4ICsgc3FydCh4XjIgLSAxKSlcclxuICpcclxuICogYWNvc2goeCA8IDEpICAgICA9IE5hTlxyXG4gKiBhY29zaChOYU4pICAgICAgID0gTmFOXHJcbiAqIGFjb3NoKEluZmluaXR5KSAgPSBJbmZpbml0eVxyXG4gKiBhY29zaCgtSW5maW5pdHkpID0gTmFOXHJcbiAqIGFjb3NoKDApICAgICAgICAgPSBOYU5cclxuICogYWNvc2goLTApICAgICAgICA9IE5hTlxyXG4gKiBhY29zaCgxKSAgICAgICAgID0gMFxyXG4gKiBhY29zaCgtMSkgICAgICAgID0gTmFOXHJcbiAqXHJcbiAqL1xyXG5QLmludmVyc2VIeXBlcmJvbGljQ29zaW5lID0gUC5hY29zaCA9IGZ1bmN0aW9uICgpIHtcclxuICB2YXIgcHIsIHJtLFxyXG4gICAgeCA9IHRoaXMsXHJcbiAgICBDdG9yID0geC5jb25zdHJ1Y3RvcjtcclxuXHJcbiAgaWYgKHgubHRlKDEpKSByZXR1cm4gbmV3IEN0b3IoeC5lcSgxKSA/IDAgOiBOYU4pO1xyXG4gIGlmICgheC5pc0Zpbml0ZSgpKSByZXR1cm4gbmV3IEN0b3IoeCk7XHJcblxyXG4gIHByID0gQ3Rvci5wcmVjaXNpb247XHJcbiAgcm0gPSBDdG9yLnJvdW5kaW5nO1xyXG4gIEN0b3IucHJlY2lzaW9uID0gcHIgKyBNYXRoLm1heChNYXRoLmFicyh4LmUpLCB4LnNkKCkpICsgNDtcclxuICBDdG9yLnJvdW5kaW5nID0gMTtcclxuICBleHRlcm5hbCA9IGZhbHNlO1xyXG5cclxuICB4ID0geC50aW1lcyh4KS5taW51cygxKS5zcXJ0KCkucGx1cyh4KTtcclxuXHJcbiAgZXh0ZXJuYWwgPSB0cnVlO1xyXG4gIEN0b3IucHJlY2lzaW9uID0gcHI7XHJcbiAgQ3Rvci5yb3VuZGluZyA9IHJtO1xyXG5cclxuICByZXR1cm4geC5sbigpO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBpbnZlcnNlIG9mIHRoZSBoeXBlcmJvbGljIHNpbmUgaW4gcmFkaWFucyBvZiB0aGUgdmFsdWVcclxuICogb2YgdGhpcyBEZWNpbWFsLlxyXG4gKlxyXG4gKiBEb21haW46IFstSW5maW5pdHksIEluZmluaXR5XVxyXG4gKiBSYW5nZTogWy1JbmZpbml0eSwgSW5maW5pdHldXHJcbiAqXHJcbiAqIGFzaW5oKHgpID0gbG4oeCArIHNxcnQoeF4yICsgMSkpXHJcbiAqXHJcbiAqIGFzaW5oKE5hTikgICAgICAgPSBOYU5cclxuICogYXNpbmgoSW5maW5pdHkpICA9IEluZmluaXR5XHJcbiAqIGFzaW5oKC1JbmZpbml0eSkgPSAtSW5maW5pdHlcclxuICogYXNpbmgoMCkgICAgICAgICA9IDBcclxuICogYXNpbmgoLTApICAgICAgICA9IC0wXHJcbiAqXHJcbiAqL1xyXG5QLmludmVyc2VIeXBlcmJvbGljU2luZSA9IFAuYXNpbmggPSBmdW5jdGlvbiAoKSB7XHJcbiAgdmFyIHByLCBybSxcclxuICAgIHggPSB0aGlzLFxyXG4gICAgQ3RvciA9IHguY29uc3RydWN0b3I7XHJcblxyXG4gIGlmICgheC5pc0Zpbml0ZSgpIHx8IHguaXNaZXJvKCkpIHJldHVybiBuZXcgQ3Rvcih4KTtcclxuXHJcbiAgcHIgPSBDdG9yLnByZWNpc2lvbjtcclxuICBybSA9IEN0b3Iucm91bmRpbmc7XHJcbiAgQ3Rvci5wcmVjaXNpb24gPSBwciArIDIgKiBNYXRoLm1heChNYXRoLmFicyh4LmUpLCB4LnNkKCkpICsgNjtcclxuICBDdG9yLnJvdW5kaW5nID0gMTtcclxuICBleHRlcm5hbCA9IGZhbHNlO1xyXG5cclxuICB4ID0geC50aW1lcyh4KS5wbHVzKDEpLnNxcnQoKS5wbHVzKHgpO1xyXG5cclxuICBleHRlcm5hbCA9IHRydWU7XHJcbiAgQ3Rvci5wcmVjaXNpb24gPSBwcjtcclxuICBDdG9yLnJvdW5kaW5nID0gcm07XHJcblxyXG4gIHJldHVybiB4LmxuKCk7XHJcbn07XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIGludmVyc2Ugb2YgdGhlIGh5cGVyYm9saWMgdGFuZ2VudCBpbiByYWRpYW5zIG9mIHRoZVxyXG4gKiB2YWx1ZSBvZiB0aGlzIERlY2ltYWwuXHJcbiAqXHJcbiAqIERvbWFpbjogWy0xLCAxXVxyXG4gKiBSYW5nZTogWy1JbmZpbml0eSwgSW5maW5pdHldXHJcbiAqXHJcbiAqIGF0YW5oKHgpID0gMC41ICogbG4oKDEgKyB4KSAvICgxIC0geCkpXHJcbiAqXHJcbiAqIGF0YW5oKHx4fCA+IDEpICAgPSBOYU5cclxuICogYXRhbmgoTmFOKSAgICAgICA9IE5hTlxyXG4gKiBhdGFuaChJbmZpbml0eSkgID0gTmFOXHJcbiAqIGF0YW5oKC1JbmZpbml0eSkgPSBOYU5cclxuICogYXRhbmgoMCkgICAgICAgICA9IDBcclxuICogYXRhbmgoLTApICAgICAgICA9IC0wXHJcbiAqIGF0YW5oKDEpICAgICAgICAgPSBJbmZpbml0eVxyXG4gKiBhdGFuaCgtMSkgICAgICAgID0gLUluZmluaXR5XHJcbiAqXHJcbiAqL1xyXG5QLmludmVyc2VIeXBlcmJvbGljVGFuZ2VudCA9IFAuYXRhbmggPSBmdW5jdGlvbiAoKSB7XHJcbiAgdmFyIHByLCBybSwgd3ByLCB4c2QsXHJcbiAgICB4ID0gdGhpcyxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yO1xyXG5cclxuICBpZiAoIXguaXNGaW5pdGUoKSkgcmV0dXJuIG5ldyBDdG9yKE5hTik7XHJcbiAgaWYgKHguZSA+PSAwKSByZXR1cm4gbmV3IEN0b3IoeC5hYnMoKS5lcSgxKSA/IHgucyAvIDAgOiB4LmlzWmVybygpID8geCA6IE5hTik7XHJcblxyXG4gIHByID0gQ3Rvci5wcmVjaXNpb247XHJcbiAgcm0gPSBDdG9yLnJvdW5kaW5nO1xyXG4gIHhzZCA9IHguc2QoKTtcclxuXHJcbiAgaWYgKE1hdGgubWF4KHhzZCwgcHIpIDwgMiAqIC14LmUgLSAxKSByZXR1cm4gZmluYWxpc2UobmV3IEN0b3IoeCksIHByLCBybSwgdHJ1ZSk7XHJcblxyXG4gIEN0b3IucHJlY2lzaW9uID0gd3ByID0geHNkIC0geC5lO1xyXG5cclxuICB4ID0gZGl2aWRlKHgucGx1cygxKSwgbmV3IEN0b3IoMSkubWludXMoeCksIHdwciArIHByLCAxKTtcclxuXHJcbiAgQ3Rvci5wcmVjaXNpb24gPSBwciArIDQ7XHJcbiAgQ3Rvci5yb3VuZGluZyA9IDE7XHJcblxyXG4gIHggPSB4LmxuKCk7XHJcblxyXG4gIEN0b3IucHJlY2lzaW9uID0gcHI7XHJcbiAgQ3Rvci5yb3VuZGluZyA9IHJtO1xyXG5cclxuICByZXR1cm4geC50aW1lcygwLjUpO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBhcmNzaW5lIChpbnZlcnNlIHNpbmUpIGluIHJhZGlhbnMgb2YgdGhlIHZhbHVlIG9mIHRoaXNcclxuICogRGVjaW1hbC5cclxuICpcclxuICogRG9tYWluOiBbLUluZmluaXR5LCBJbmZpbml0eV1cclxuICogUmFuZ2U6IFstcGkvMiwgcGkvMl1cclxuICpcclxuICogYXNpbih4KSA9IDIqYXRhbih4LygxICsgc3FydCgxIC0geF4yKSkpXHJcbiAqXHJcbiAqIGFzaW4oMCkgICAgICAgPSAwXHJcbiAqIGFzaW4oLTApICAgICAgPSAtMFxyXG4gKiBhc2luKDEvMikgICAgID0gcGkvNlxyXG4gKiBhc2luKC0xLzIpICAgID0gLXBpLzZcclxuICogYXNpbigxKSAgICAgICA9IHBpLzJcclxuICogYXNpbigtMSkgICAgICA9IC1waS8yXHJcbiAqIGFzaW4ofHh8ID4gMSkgPSBOYU5cclxuICogYXNpbihOYU4pICAgICA9IE5hTlxyXG4gKlxyXG4gKiBUT0RPPyBDb21wYXJlIHBlcmZvcm1hbmNlIG9mIFRheWxvciBzZXJpZXMuXHJcbiAqXHJcbiAqL1xyXG5QLmludmVyc2VTaW5lID0gUC5hc2luID0gZnVuY3Rpb24gKCkge1xyXG4gIHZhciBoYWxmUGksIGssXHJcbiAgICBwciwgcm0sXHJcbiAgICB4ID0gdGhpcyxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yO1xyXG5cclxuICBpZiAoeC5pc1plcm8oKSkgcmV0dXJuIG5ldyBDdG9yKHgpO1xyXG5cclxuICBrID0geC5hYnMoKS5jbXAoMSk7XHJcbiAgcHIgPSBDdG9yLnByZWNpc2lvbjtcclxuICBybSA9IEN0b3Iucm91bmRpbmc7XHJcblxyXG4gIGlmIChrICE9PSAtMSkge1xyXG5cclxuICAgIC8vIHx4fCBpcyAxXHJcbiAgICBpZiAoayA9PT0gMCkge1xyXG4gICAgICBoYWxmUGkgPSBnZXRQaShDdG9yLCBwciArIDQsIHJtKS50aW1lcygwLjUpO1xyXG4gICAgICBoYWxmUGkucyA9IHgucztcclxuICAgICAgcmV0dXJuIGhhbGZQaTtcclxuICAgIH1cclxuXHJcbiAgICAvLyB8eHwgPiAxIG9yIHggaXMgTmFOXHJcbiAgICByZXR1cm4gbmV3IEN0b3IoTmFOKTtcclxuICB9XHJcblxyXG4gIC8vIFRPRE8/IFNwZWNpYWwgY2FzZSBhc2luKDEvMikgPSBwaS82IGFuZCBhc2luKC0xLzIpID0gLXBpLzZcclxuXHJcbiAgQ3Rvci5wcmVjaXNpb24gPSBwciArIDY7XHJcbiAgQ3Rvci5yb3VuZGluZyA9IDE7XHJcblxyXG4gIHggPSB4LmRpdihuZXcgQ3RvcigxKS5taW51cyh4LnRpbWVzKHgpKS5zcXJ0KCkucGx1cygxKSkuYXRhbigpO1xyXG5cclxuICBDdG9yLnByZWNpc2lvbiA9IHByO1xyXG4gIEN0b3Iucm91bmRpbmcgPSBybTtcclxuXHJcbiAgcmV0dXJuIHgudGltZXMoMik7XHJcbn07XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIGFyY3RhbmdlbnQgKGludmVyc2UgdGFuZ2VudCkgaW4gcmFkaWFucyBvZiB0aGUgdmFsdWVcclxuICogb2YgdGhpcyBEZWNpbWFsLlxyXG4gKlxyXG4gKiBEb21haW46IFstSW5maW5pdHksIEluZmluaXR5XVxyXG4gKiBSYW5nZTogWy1waS8yLCBwaS8yXVxyXG4gKlxyXG4gKiBhdGFuKHgpID0geCAtIHheMy8zICsgeF41LzUgLSB4XjcvNyArIC4uLlxyXG4gKlxyXG4gKiBhdGFuKDApICAgICAgICAgPSAwXHJcbiAqIGF0YW4oLTApICAgICAgICA9IC0wXHJcbiAqIGF0YW4oMSkgICAgICAgICA9IHBpLzRcclxuICogYXRhbigtMSkgICAgICAgID0gLXBpLzRcclxuICogYXRhbihJbmZpbml0eSkgID0gcGkvMlxyXG4gKiBhdGFuKC1JbmZpbml0eSkgPSAtcGkvMlxyXG4gKiBhdGFuKE5hTikgICAgICAgPSBOYU5cclxuICpcclxuICovXHJcblAuaW52ZXJzZVRhbmdlbnQgPSBQLmF0YW4gPSBmdW5jdGlvbiAoKSB7XHJcbiAgdmFyIGksIGosIGssIG4sIHB4LCB0LCByLCB3cHIsIHgyLFxyXG4gICAgeCA9IHRoaXMsXHJcbiAgICBDdG9yID0geC5jb25zdHJ1Y3RvcixcclxuICAgIHByID0gQ3Rvci5wcmVjaXNpb24sXHJcbiAgICBybSA9IEN0b3Iucm91bmRpbmc7XHJcblxyXG4gIGlmICgheC5pc0Zpbml0ZSgpKSB7XHJcbiAgICBpZiAoIXgucykgcmV0dXJuIG5ldyBDdG9yKE5hTik7XHJcbiAgICBpZiAocHIgKyA0IDw9IFBJX1BSRUNJU0lPTikge1xyXG4gICAgICByID0gZ2V0UGkoQ3RvciwgcHIgKyA0LCBybSkudGltZXMoMC41KTtcclxuICAgICAgci5zID0geC5zO1xyXG4gICAgICByZXR1cm4gcjtcclxuICAgIH1cclxuICB9IGVsc2UgaWYgKHguaXNaZXJvKCkpIHtcclxuICAgIHJldHVybiBuZXcgQ3Rvcih4KTtcclxuICB9IGVsc2UgaWYgKHguYWJzKCkuZXEoMSkgJiYgcHIgKyA0IDw9IFBJX1BSRUNJU0lPTikge1xyXG4gICAgciA9IGdldFBpKEN0b3IsIHByICsgNCwgcm0pLnRpbWVzKDAuMjUpO1xyXG4gICAgci5zID0geC5zO1xyXG4gICAgcmV0dXJuIHI7XHJcbiAgfVxyXG5cclxuICBDdG9yLnByZWNpc2lvbiA9IHdwciA9IHByICsgMTA7XHJcbiAgQ3Rvci5yb3VuZGluZyA9IDE7XHJcblxyXG4gIC8vIFRPRE8/IGlmICh4ID49IDEgJiYgcHIgPD0gUElfUFJFQ0lTSU9OKSBhdGFuKHgpID0gaGFsZlBpICogeC5zIC0gYXRhbigxIC8geCk7XHJcblxyXG4gIC8vIEFyZ3VtZW50IHJlZHVjdGlvblxyXG4gIC8vIEVuc3VyZSB8eHwgPCAwLjQyXHJcbiAgLy8gYXRhbih4KSA9IDIgKiBhdGFuKHggLyAoMSArIHNxcnQoMSArIHheMikpKVxyXG5cclxuICBrID0gTWF0aC5taW4oMjgsIHdwciAvIExPR19CQVNFICsgMiB8IDApO1xyXG5cclxuICBmb3IgKGkgPSBrOyBpOyAtLWkpIHggPSB4LmRpdih4LnRpbWVzKHgpLnBsdXMoMSkuc3FydCgpLnBsdXMoMSkpO1xyXG5cclxuICBleHRlcm5hbCA9IGZhbHNlO1xyXG5cclxuICBqID0gTWF0aC5jZWlsKHdwciAvIExPR19CQVNFKTtcclxuICBuID0gMTtcclxuICB4MiA9IHgudGltZXMoeCk7XHJcbiAgciA9IG5ldyBDdG9yKHgpO1xyXG4gIHB4ID0geDtcclxuXHJcbiAgLy8gYXRhbih4KSA9IHggLSB4XjMvMyArIHheNS81IC0geF43LzcgKyAuLi5cclxuICBmb3IgKDsgaSAhPT0gLTE7KSB7XHJcbiAgICBweCA9IHB4LnRpbWVzKHgyKTtcclxuICAgIHQgPSByLm1pbnVzKHB4LmRpdihuICs9IDIpKTtcclxuXHJcbiAgICBweCA9IHB4LnRpbWVzKHgyKTtcclxuICAgIHIgPSB0LnBsdXMocHguZGl2KG4gKz0gMikpO1xyXG5cclxuICAgIGlmIChyLmRbal0gIT09IHZvaWQgMCkgZm9yIChpID0gajsgci5kW2ldID09PSB0LmRbaV0gJiYgaS0tOyk7XHJcbiAgfVxyXG5cclxuICBpZiAoaykgciA9IHIudGltZXMoMiA8PCAoayAtIDEpKTtcclxuXHJcbiAgZXh0ZXJuYWwgPSB0cnVlO1xyXG5cclxuICByZXR1cm4gZmluYWxpc2UociwgQ3Rvci5wcmVjaXNpb24gPSBwciwgQ3Rvci5yb3VuZGluZyA9IHJtLCB0cnVlKTtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gdHJ1ZSBpZiB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsIGlzIGEgZmluaXRlIG51bWJlciwgb3RoZXJ3aXNlIHJldHVybiBmYWxzZS5cclxuICpcclxuICovXHJcblAuaXNGaW5pdGUgPSBmdW5jdGlvbiAoKSB7XHJcbiAgcmV0dXJuICEhdGhpcy5kO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiB0cnVlIGlmIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgaXMgYW4gaW50ZWdlciwgb3RoZXJ3aXNlIHJldHVybiBmYWxzZS5cclxuICpcclxuICovXHJcblAuaXNJbnRlZ2VyID0gUC5pc0ludCA9IGZ1bmN0aW9uICgpIHtcclxuICByZXR1cm4gISF0aGlzLmQgJiYgbWF0aGZsb29yKHRoaXMuZSAvIExPR19CQVNFKSA+IHRoaXMuZC5sZW5ndGggLSAyO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiB0cnVlIGlmIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgaXMgTmFOLCBvdGhlcndpc2UgcmV0dXJuIGZhbHNlLlxyXG4gKlxyXG4gKi9cclxuUC5pc05hTiA9IGZ1bmN0aW9uICgpIHtcclxuICByZXR1cm4gIXRoaXMucztcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gdHJ1ZSBpZiB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsIGlzIG5lZ2F0aXZlLCBvdGhlcndpc2UgcmV0dXJuIGZhbHNlLlxyXG4gKlxyXG4gKi9cclxuUC5pc05lZ2F0aXZlID0gUC5pc05lZyA9IGZ1bmN0aW9uICgpIHtcclxuICByZXR1cm4gdGhpcy5zIDwgMDtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gdHJ1ZSBpZiB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsIGlzIHBvc2l0aXZlLCBvdGhlcndpc2UgcmV0dXJuIGZhbHNlLlxyXG4gKlxyXG4gKi9cclxuUC5pc1Bvc2l0aXZlID0gUC5pc1BvcyA9IGZ1bmN0aW9uICgpIHtcclxuICByZXR1cm4gdGhpcy5zID4gMDtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gdHJ1ZSBpZiB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsIGlzIDAgb3IgLTAsIG90aGVyd2lzZSByZXR1cm4gZmFsc2UuXHJcbiAqXHJcbiAqL1xyXG5QLmlzWmVybyA9IGZ1bmN0aW9uICgpIHtcclxuICByZXR1cm4gISF0aGlzLmQgJiYgdGhpcy5kWzBdID09PSAwO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiB0cnVlIGlmIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgaXMgbGVzcyB0aGFuIGB5YCwgb3RoZXJ3aXNlIHJldHVybiBmYWxzZS5cclxuICpcclxuICovXHJcblAubGVzc1RoYW4gPSBQLmx0ID0gZnVuY3Rpb24gKHkpIHtcclxuICByZXR1cm4gdGhpcy5jbXAoeSkgPCAwO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiB0cnVlIGlmIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgaXMgbGVzcyB0aGFuIG9yIGVxdWFsIHRvIGB5YCwgb3RoZXJ3aXNlIHJldHVybiBmYWxzZS5cclxuICpcclxuICovXHJcblAubGVzc1RoYW5PckVxdWFsVG8gPSBQLmx0ZSA9IGZ1bmN0aW9uICh5KSB7XHJcbiAgcmV0dXJuIHRoaXMuY21wKHkpIDwgMTtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gdGhlIGxvZ2FyaXRobSBvZiB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsIHRvIHRoZSBzcGVjaWZpZWQgYmFzZSwgcm91bmRlZCB0byBgcHJlY2lzaW9uYFxyXG4gKiBzaWduaWZpY2FudCBkaWdpdHMgdXNpbmcgcm91bmRpbmcgbW9kZSBgcm91bmRpbmdgLlxyXG4gKlxyXG4gKiBJZiBubyBiYXNlIGlzIHNwZWNpZmllZCwgcmV0dXJuIGxvZ1sxMF0oYXJnKS5cclxuICpcclxuICogbG9nW2Jhc2VdKGFyZykgPSBsbihhcmcpIC8gbG4oYmFzZSlcclxuICpcclxuICogVGhlIHJlc3VsdCB3aWxsIGFsd2F5cyBiZSBjb3JyZWN0bHkgcm91bmRlZCBpZiB0aGUgYmFzZSBvZiB0aGUgbG9nIGlzIDEwLCBhbmQgJ2FsbW9zdCBhbHdheXMnXHJcbiAqIG90aGVyd2lzZTpcclxuICpcclxuICogRGVwZW5kaW5nIG9uIHRoZSByb3VuZGluZyBtb2RlLCB0aGUgcmVzdWx0IG1heSBiZSBpbmNvcnJlY3RseSByb3VuZGVkIGlmIHRoZSBmaXJzdCBmaWZ0ZWVuXHJcbiAqIHJvdW5kaW5nIGRpZ2l0cyBhcmUgWzQ5XTk5OTk5OTk5OTk5OTk5IG9yIFs1MF0wMDAwMDAwMDAwMDAwMC4gSW4gdGhhdCBjYXNlLCB0aGUgbWF4aW11bSBlcnJvclxyXG4gKiBiZXR3ZWVuIHRoZSByZXN1bHQgYW5kIHRoZSBjb3JyZWN0bHkgcm91bmRlZCByZXN1bHQgd2lsbCBiZSBvbmUgdWxwICh1bml0IGluIHRoZSBsYXN0IHBsYWNlKS5cclxuICpcclxuICogbG9nWy1iXShhKSAgICAgICA9IE5hTlxyXG4gKiBsb2dbMF0oYSkgICAgICAgID0gTmFOXHJcbiAqIGxvZ1sxXShhKSAgICAgICAgPSBOYU5cclxuICogbG9nW05hTl0oYSkgICAgICA9IE5hTlxyXG4gKiBsb2dbSW5maW5pdHldKGEpID0gTmFOXHJcbiAqIGxvZ1tiXSgwKSAgICAgICAgPSAtSW5maW5pdHlcclxuICogbG9nW2JdKC0wKSAgICAgICA9IC1JbmZpbml0eVxyXG4gKiBsb2dbYl0oLWEpICAgICAgID0gTmFOXHJcbiAqIGxvZ1tiXSgxKSAgICAgICAgPSAwXHJcbiAqIGxvZ1tiXShJbmZpbml0eSkgPSBJbmZpbml0eVxyXG4gKiBsb2dbYl0oTmFOKSAgICAgID0gTmFOXHJcbiAqXHJcbiAqIFtiYXNlXSB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH0gVGhlIGJhc2Ugb2YgdGhlIGxvZ2FyaXRobS5cclxuICpcclxuICovXHJcblAubG9nYXJpdGhtID0gUC5sb2cgPSBmdW5jdGlvbiAoYmFzZSkge1xyXG4gIHZhciBpc0Jhc2UxMCwgZCwgZGVub21pbmF0b3IsIGssIGluZiwgbnVtLCBzZCwgcixcclxuICAgIGFyZyA9IHRoaXMsXHJcbiAgICBDdG9yID0gYXJnLmNvbnN0cnVjdG9yLFxyXG4gICAgcHIgPSBDdG9yLnByZWNpc2lvbixcclxuICAgIHJtID0gQ3Rvci5yb3VuZGluZyxcclxuICAgIGd1YXJkID0gNTtcclxuXHJcbiAgLy8gRGVmYXVsdCBiYXNlIGlzIDEwLlxyXG4gIGlmIChiYXNlID09IG51bGwpIHtcclxuICAgIGJhc2UgPSBuZXcgQ3RvcigxMCk7XHJcbiAgICBpc0Jhc2UxMCA9IHRydWU7XHJcbiAgfSBlbHNlIHtcclxuICAgIGJhc2UgPSBuZXcgQ3RvcihiYXNlKTtcclxuICAgIGQgPSBiYXNlLmQ7XHJcblxyXG4gICAgLy8gUmV0dXJuIE5hTiBpZiBiYXNlIGlzIG5lZ2F0aXZlLCBvciBub24tZmluaXRlLCBvciBpcyAwIG9yIDEuXHJcbiAgICBpZiAoYmFzZS5zIDwgMCB8fCAhZCB8fCAhZFswXSB8fCBiYXNlLmVxKDEpKSByZXR1cm4gbmV3IEN0b3IoTmFOKTtcclxuXHJcbiAgICBpc0Jhc2UxMCA9IGJhc2UuZXEoMTApO1xyXG4gIH1cclxuXHJcbiAgZCA9IGFyZy5kO1xyXG5cclxuICAvLyBJcyBhcmcgbmVnYXRpdmUsIG5vbi1maW5pdGUsIDAgb3IgMT9cclxuICBpZiAoYXJnLnMgPCAwIHx8ICFkIHx8ICFkWzBdIHx8IGFyZy5lcSgxKSkge1xyXG4gICAgcmV0dXJuIG5ldyBDdG9yKGQgJiYgIWRbMF0gPyAtMSAvIDAgOiBhcmcucyAhPSAxID8gTmFOIDogZCA/IDAgOiAxIC8gMCk7XHJcbiAgfVxyXG5cclxuICAvLyBUaGUgcmVzdWx0IHdpbGwgaGF2ZSBhIG5vbi10ZXJtaW5hdGluZyBkZWNpbWFsIGV4cGFuc2lvbiBpZiBiYXNlIGlzIDEwIGFuZCBhcmcgaXMgbm90IGFuXHJcbiAgLy8gaW50ZWdlciBwb3dlciBvZiAxMC5cclxuICBpZiAoaXNCYXNlMTApIHtcclxuICAgIGlmIChkLmxlbmd0aCA+IDEpIHtcclxuICAgICAgaW5mID0gdHJ1ZTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGZvciAoayA9IGRbMF07IGsgJSAxMCA9PT0gMDspIGsgLz0gMTA7XHJcbiAgICAgIGluZiA9IGsgIT09IDE7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBleHRlcm5hbCA9IGZhbHNlO1xyXG4gIHNkID0gcHIgKyBndWFyZDtcclxuICBudW0gPSBuYXR1cmFsTG9nYXJpdGhtKGFyZywgc2QpO1xyXG4gIGRlbm9taW5hdG9yID0gaXNCYXNlMTAgPyBnZXRMbjEwKEN0b3IsIHNkICsgMTApIDogbmF0dXJhbExvZ2FyaXRobShiYXNlLCBzZCk7XHJcblxyXG4gIC8vIFRoZSByZXN1bHQgd2lsbCBoYXZlIDUgcm91bmRpbmcgZGlnaXRzLlxyXG4gIHIgPSBkaXZpZGUobnVtLCBkZW5vbWluYXRvciwgc2QsIDEpO1xyXG5cclxuICAvLyBJZiBhdCBhIHJvdW5kaW5nIGJvdW5kYXJ5LCBpLmUuIHRoZSByZXN1bHQncyByb3VuZGluZyBkaWdpdHMgYXJlIFs0OV05OTk5IG9yIFs1MF0wMDAwLFxyXG4gIC8vIGNhbGN1bGF0ZSAxMCBmdXJ0aGVyIGRpZ2l0cy5cclxuICAvL1xyXG4gIC8vIElmIHRoZSByZXN1bHQgaXMga25vd24gdG8gaGF2ZSBhbiBpbmZpbml0ZSBkZWNpbWFsIGV4cGFuc2lvbiwgcmVwZWF0IHRoaXMgdW50aWwgaXQgaXMgY2xlYXJcclxuICAvLyB0aGF0IHRoZSByZXN1bHQgaXMgYWJvdmUgb3IgYmVsb3cgdGhlIGJvdW5kYXJ5LiBPdGhlcndpc2UsIGlmIGFmdGVyIGNhbGN1bGF0aW5nIHRoZSAxMFxyXG4gIC8vIGZ1cnRoZXIgZGlnaXRzLCB0aGUgbGFzdCAxNCBhcmUgbmluZXMsIHJvdW5kIHVwIGFuZCBhc3N1bWUgdGhlIHJlc3VsdCBpcyBleGFjdC5cclxuICAvLyBBbHNvIGFzc3VtZSB0aGUgcmVzdWx0IGlzIGV4YWN0IGlmIHRoZSBsYXN0IDE0IGFyZSB6ZXJvLlxyXG4gIC8vXHJcbiAgLy8gRXhhbXBsZSBvZiBhIHJlc3VsdCB0aGF0IHdpbGwgYmUgaW5jb3JyZWN0bHkgcm91bmRlZDpcclxuICAvLyBsb2dbMTA0ODU3Nl0oNDUwMzU5OTYyNzM3MDUwMikgPSAyLjYwMDAwMDAwMDAwMDAwMDA5NjEwMjc5NTExNDQ0NzQ2Li4uXHJcbiAgLy8gVGhlIGFib3ZlIHJlc3VsdCBjb3JyZWN0bHkgcm91bmRlZCB1c2luZyBST1VORF9DRUlMIHRvIDEgZGVjaW1hbCBwbGFjZSBzaG91bGQgYmUgMi43LCBidXQgaXRcclxuICAvLyB3aWxsIGJlIGdpdmVuIGFzIDIuNiBhcyB0aGVyZSBhcmUgMTUgemVyb3MgaW1tZWRpYXRlbHkgYWZ0ZXIgdGhlIHJlcXVlc3RlZCBkZWNpbWFsIHBsYWNlLCBzb1xyXG4gIC8vIHRoZSBleGFjdCByZXN1bHQgd291bGQgYmUgYXNzdW1lZCB0byBiZSAyLjYsIHdoaWNoIHJvdW5kZWQgdXNpbmcgUk9VTkRfQ0VJTCB0byAxIGRlY2ltYWxcclxuICAvLyBwbGFjZSBpcyBzdGlsbCAyLjYuXHJcbiAgaWYgKGNoZWNrUm91bmRpbmdEaWdpdHMoci5kLCBrID0gcHIsIHJtKSkge1xyXG5cclxuICAgIGRvIHtcclxuICAgICAgc2QgKz0gMTA7XHJcbiAgICAgIG51bSA9IG5hdHVyYWxMb2dhcml0aG0oYXJnLCBzZCk7XHJcbiAgICAgIGRlbm9taW5hdG9yID0gaXNCYXNlMTAgPyBnZXRMbjEwKEN0b3IsIHNkICsgMTApIDogbmF0dXJhbExvZ2FyaXRobShiYXNlLCBzZCk7XHJcbiAgICAgIHIgPSBkaXZpZGUobnVtLCBkZW5vbWluYXRvciwgc2QsIDEpO1xyXG5cclxuICAgICAgaWYgKCFpbmYpIHtcclxuXHJcbiAgICAgICAgLy8gQ2hlY2sgZm9yIDE0IG5pbmVzIGZyb20gdGhlIDJuZCByb3VuZGluZyBkaWdpdCwgYXMgdGhlIGZpcnN0IG1heSBiZSA0LlxyXG4gICAgICAgIGlmICgrZGlnaXRzVG9TdHJpbmcoci5kKS5zbGljZShrICsgMSwgayArIDE1KSArIDEgPT0gMWUxNCkge1xyXG4gICAgICAgICAgciA9IGZpbmFsaXNlKHIsIHByICsgMSwgMCk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBicmVhaztcclxuICAgICAgfVxyXG4gICAgfSB3aGlsZSAoY2hlY2tSb3VuZGluZ0RpZ2l0cyhyLmQsIGsgKz0gMTAsIHJtKSk7XHJcbiAgfVxyXG5cclxuICBleHRlcm5hbCA9IHRydWU7XHJcblxyXG4gIHJldHVybiBmaW5hbGlzZShyLCBwciwgcm0pO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBtYXhpbXVtIG9mIHRoZSBhcmd1bWVudHMgYW5kIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwuXHJcbiAqXHJcbiAqIGFyZ3VtZW50cyB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH1cclxuICpcclxuUC5tYXggPSBmdW5jdGlvbiAoKSB7XHJcbiAgQXJyYXkucHJvdG90eXBlLnB1c2guY2FsbChhcmd1bWVudHMsIHRoaXMpO1xyXG4gIHJldHVybiBtYXhPck1pbih0aGlzLmNvbnN0cnVjdG9yLCBhcmd1bWVudHMsIC0xKTtcclxufTtcclxuICovXHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIG1pbmltdW0gb2YgdGhlIGFyZ3VtZW50cyBhbmQgdGhlIHZhbHVlIG9mIHRoaXMgRGVjaW1hbC5cclxuICpcclxuICogYXJndW1lbnRzIHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfVxyXG4gKlxyXG5QLm1pbiA9IGZ1bmN0aW9uICgpIHtcclxuICBBcnJheS5wcm90b3R5cGUucHVzaC5jYWxsKGFyZ3VtZW50cywgdGhpcyk7XHJcbiAgcmV0dXJuIG1heE9yTWluKHRoaXMuY29uc3RydWN0b3IsIGFyZ3VtZW50cywgMSk7XHJcbn07XHJcbiAqL1xyXG5cclxuXHJcbi8qXHJcbiAqICBuIC0gMCA9IG5cclxuICogIG4gLSBOID0gTlxyXG4gKiAgbiAtIEkgPSAtSVxyXG4gKiAgMCAtIG4gPSAtblxyXG4gKiAgMCAtIDAgPSAwXHJcbiAqICAwIC0gTiA9IE5cclxuICogIDAgLSBJID0gLUlcclxuICogIE4gLSBuID0gTlxyXG4gKiAgTiAtIDAgPSBOXHJcbiAqICBOIC0gTiA9IE5cclxuICogIE4gLSBJID0gTlxyXG4gKiAgSSAtIG4gPSBJXHJcbiAqICBJIC0gMCA9IElcclxuICogIEkgLSBOID0gTlxyXG4gKiAgSSAtIEkgPSBOXHJcbiAqXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgbWludXMgYHlgLCByb3VuZGVkIHRvIGBwcmVjaXNpb25gXHJcbiAqIHNpZ25pZmljYW50IGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqL1xyXG5QLm1pbnVzID0gUC5zdWIgPSBmdW5jdGlvbiAoeSkge1xyXG4gIHZhciBkLCBlLCBpLCBqLCBrLCBsZW4sIHByLCBybSwgeGQsIHhlLCB4TFR5LCB5ZCxcclxuICAgIHggPSB0aGlzLFxyXG4gICAgQ3RvciA9IHguY29uc3RydWN0b3I7XHJcblxyXG4gIHkgPSBuZXcgQ3Rvcih5KTtcclxuXHJcbiAgLy8gSWYgZWl0aGVyIGlzIG5vdCBmaW5pdGUuLi5cclxuICBpZiAoIXguZCB8fCAheS5kKSB7XHJcblxyXG4gICAgLy8gUmV0dXJuIE5hTiBpZiBlaXRoZXIgaXMgTmFOLlxyXG4gICAgaWYgKCF4LnMgfHwgIXkucykgeSA9IG5ldyBDdG9yKE5hTik7XHJcblxyXG4gICAgLy8gUmV0dXJuIHkgbmVnYXRlZCBpZiB4IGlzIGZpbml0ZSBhbmQgeSBpcyDCsUluZmluaXR5LlxyXG4gICAgZWxzZSBpZiAoeC5kKSB5LnMgPSAteS5zO1xyXG5cclxuICAgIC8vIFJldHVybiB4IGlmIHkgaXMgZmluaXRlIGFuZCB4IGlzIMKxSW5maW5pdHkuXHJcbiAgICAvLyBSZXR1cm4geCBpZiBib3RoIGFyZSDCsUluZmluaXR5IHdpdGggZGlmZmVyZW50IHNpZ25zLlxyXG4gICAgLy8gUmV0dXJuIE5hTiBpZiBib3RoIGFyZSDCsUluZmluaXR5IHdpdGggdGhlIHNhbWUgc2lnbi5cclxuICAgIGVsc2UgeSA9IG5ldyBDdG9yKHkuZCB8fCB4LnMgIT09IHkucyA/IHggOiBOYU4pO1xyXG5cclxuICAgIHJldHVybiB5O1xyXG4gIH1cclxuXHJcbiAgLy8gSWYgc2lnbnMgZGlmZmVyLi4uXHJcbiAgaWYgKHgucyAhPSB5LnMpIHtcclxuICAgIHkucyA9IC15LnM7XHJcbiAgICByZXR1cm4geC5wbHVzKHkpO1xyXG4gIH1cclxuXHJcbiAgeGQgPSB4LmQ7XHJcbiAgeWQgPSB5LmQ7XHJcbiAgcHIgPSBDdG9yLnByZWNpc2lvbjtcclxuICBybSA9IEN0b3Iucm91bmRpbmc7XHJcblxyXG4gIC8vIElmIGVpdGhlciBpcyB6ZXJvLi4uXHJcbiAgaWYgKCF4ZFswXSB8fCAheWRbMF0pIHtcclxuXHJcbiAgICAvLyBSZXR1cm4geSBuZWdhdGVkIGlmIHggaXMgemVybyBhbmQgeSBpcyBub24temVyby5cclxuICAgIGlmICh5ZFswXSkgeS5zID0gLXkucztcclxuXHJcbiAgICAvLyBSZXR1cm4geCBpZiB5IGlzIHplcm8gYW5kIHggaXMgbm9uLXplcm8uXHJcbiAgICBlbHNlIGlmICh4ZFswXSkgeSA9IG5ldyBDdG9yKHgpO1xyXG5cclxuICAgIC8vIFJldHVybiB6ZXJvIGlmIGJvdGggYXJlIHplcm8uXHJcbiAgICAvLyBGcm9tIElFRUUgNzU0ICgyMDA4KSA2LjM6IDAgLSAwID0gLTAgLSAtMCA9IC0wIHdoZW4gcm91bmRpbmcgdG8gLUluZmluaXR5LlxyXG4gICAgZWxzZSByZXR1cm4gbmV3IEN0b3Iocm0gPT09IDMgPyAtMCA6IDApO1xyXG5cclxuICAgIHJldHVybiBleHRlcm5hbCA/IGZpbmFsaXNlKHksIHByLCBybSkgOiB5O1xyXG4gIH1cclxuXHJcbiAgLy8geCBhbmQgeSBhcmUgZmluaXRlLCBub24temVybyBudW1iZXJzIHdpdGggdGhlIHNhbWUgc2lnbi5cclxuXHJcbiAgLy8gQ2FsY3VsYXRlIGJhc2UgMWU3IGV4cG9uZW50cy5cclxuICBlID0gbWF0aGZsb29yKHkuZSAvIExPR19CQVNFKTtcclxuICB4ZSA9IG1hdGhmbG9vcih4LmUgLyBMT0dfQkFTRSk7XHJcblxyXG4gIHhkID0geGQuc2xpY2UoKTtcclxuICBrID0geGUgLSBlO1xyXG5cclxuICAvLyBJZiBiYXNlIDFlNyBleHBvbmVudHMgZGlmZmVyLi4uXHJcbiAgaWYgKGspIHtcclxuICAgIHhMVHkgPSBrIDwgMDtcclxuXHJcbiAgICBpZiAoeExUeSkge1xyXG4gICAgICBkID0geGQ7XHJcbiAgICAgIGsgPSAtaztcclxuICAgICAgbGVuID0geWQubGVuZ3RoO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZCA9IHlkO1xyXG4gICAgICBlID0geGU7XHJcbiAgICAgIGxlbiA9IHhkLmxlbmd0aDtcclxuICAgIH1cclxuXHJcbiAgICAvLyBOdW1iZXJzIHdpdGggbWFzc2l2ZWx5IGRpZmZlcmVudCBleHBvbmVudHMgd291bGQgcmVzdWx0IGluIGEgdmVyeSBoaWdoIG51bWJlciBvZlxyXG4gICAgLy8gemVyb3MgbmVlZGluZyB0byBiZSBwcmVwZW5kZWQsIGJ1dCB0aGlzIGNhbiBiZSBhdm9pZGVkIHdoaWxlIHN0aWxsIGVuc3VyaW5nIGNvcnJlY3RcclxuICAgIC8vIHJvdW5kaW5nIGJ5IGxpbWl0aW5nIHRoZSBudW1iZXIgb2YgemVyb3MgdG8gYE1hdGguY2VpbChwciAvIExPR19CQVNFKSArIDJgLlxyXG4gICAgaSA9IE1hdGgubWF4KE1hdGguY2VpbChwciAvIExPR19CQVNFKSwgbGVuKSArIDI7XHJcblxyXG4gICAgaWYgKGsgPiBpKSB7XHJcbiAgICAgIGsgPSBpO1xyXG4gICAgICBkLmxlbmd0aCA9IDE7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gUHJlcGVuZCB6ZXJvcyB0byBlcXVhbGlzZSBleHBvbmVudHMuXHJcbiAgICBkLnJldmVyc2UoKTtcclxuICAgIGZvciAoaSA9IGs7IGktLTspIGQucHVzaCgwKTtcclxuICAgIGQucmV2ZXJzZSgpO1xyXG5cclxuICAvLyBCYXNlIDFlNyBleHBvbmVudHMgZXF1YWwuXHJcbiAgfSBlbHNlIHtcclxuXHJcbiAgICAvLyBDaGVjayBkaWdpdHMgdG8gZGV0ZXJtaW5lIHdoaWNoIGlzIHRoZSBiaWdnZXIgbnVtYmVyLlxyXG5cclxuICAgIGkgPSB4ZC5sZW5ndGg7XHJcbiAgICBsZW4gPSB5ZC5sZW5ndGg7XHJcbiAgICB4TFR5ID0gaSA8IGxlbjtcclxuICAgIGlmICh4TFR5KSBsZW4gPSBpO1xyXG5cclxuICAgIGZvciAoaSA9IDA7IGkgPCBsZW47IGkrKykge1xyXG4gICAgICBpZiAoeGRbaV0gIT0geWRbaV0pIHtcclxuICAgICAgICB4TFR5ID0geGRbaV0gPCB5ZFtpXTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGsgPSAwO1xyXG4gIH1cclxuXHJcbiAgaWYgKHhMVHkpIHtcclxuICAgIGQgPSB4ZDtcclxuICAgIHhkID0geWQ7XHJcbiAgICB5ZCA9IGQ7XHJcbiAgICB5LnMgPSAteS5zO1xyXG4gIH1cclxuXHJcbiAgbGVuID0geGQubGVuZ3RoO1xyXG5cclxuICAvLyBBcHBlbmQgemVyb3MgdG8gYHhkYCBpZiBzaG9ydGVyLlxyXG4gIC8vIERvbid0IGFkZCB6ZXJvcyB0byBgeWRgIGlmIHNob3J0ZXIgYXMgc3VidHJhY3Rpb24gb25seSBuZWVkcyB0byBzdGFydCBhdCBgeWRgIGxlbmd0aC5cclxuICBmb3IgKGkgPSB5ZC5sZW5ndGggLSBsZW47IGkgPiAwOyAtLWkpIHhkW2xlbisrXSA9IDA7XHJcblxyXG4gIC8vIFN1YnRyYWN0IHlkIGZyb20geGQuXHJcbiAgZm9yIChpID0geWQubGVuZ3RoOyBpID4gazspIHtcclxuXHJcbiAgICBpZiAoeGRbLS1pXSA8IHlkW2ldKSB7XHJcbiAgICAgIGZvciAoaiA9IGk7IGogJiYgeGRbLS1qXSA9PT0gMDspIHhkW2pdID0gQkFTRSAtIDE7XHJcbiAgICAgIC0teGRbal07XHJcbiAgICAgIHhkW2ldICs9IEJBU0U7XHJcbiAgICB9XHJcblxyXG4gICAgeGRbaV0gLT0geWRbaV07XHJcbiAgfVxyXG5cclxuICAvLyBSZW1vdmUgdHJhaWxpbmcgemVyb3MuXHJcbiAgZm9yICg7IHhkWy0tbGVuXSA9PT0gMDspIHhkLnBvcCgpO1xyXG5cclxuICAvLyBSZW1vdmUgbGVhZGluZyB6ZXJvcyBhbmQgYWRqdXN0IGV4cG9uZW50IGFjY29yZGluZ2x5LlxyXG4gIGZvciAoOyB4ZFswXSA9PT0gMDsgeGQuc2hpZnQoKSkgLS1lO1xyXG5cclxuICAvLyBaZXJvP1xyXG4gIGlmICgheGRbMF0pIHJldHVybiBuZXcgQ3RvcihybSA9PT0gMyA/IC0wIDogMCk7XHJcblxyXG4gIHkuZCA9IHhkO1xyXG4gIHkuZSA9IGdldEJhc2UxMEV4cG9uZW50KHhkLCBlKTtcclxuXHJcbiAgcmV0dXJuIGV4dGVybmFsID8gZmluYWxpc2UoeSwgcHIsIHJtKSA6IHk7XHJcbn07XHJcblxyXG5cclxuLypcclxuICogICBuICUgMCA9ICBOXHJcbiAqICAgbiAlIE4gPSAgTlxyXG4gKiAgIG4gJSBJID0gIG5cclxuICogICAwICUgbiA9ICAwXHJcbiAqICAtMCAlIG4gPSAtMFxyXG4gKiAgIDAgJSAwID0gIE5cclxuICogICAwICUgTiA9ICBOXHJcbiAqICAgMCAlIEkgPSAgMFxyXG4gKiAgIE4gJSBuID0gIE5cclxuICogICBOICUgMCA9ICBOXHJcbiAqICAgTiAlIE4gPSAgTlxyXG4gKiAgIE4gJSBJID0gIE5cclxuICogICBJICUgbiA9ICBOXHJcbiAqICAgSSAlIDAgPSAgTlxyXG4gKiAgIEkgJSBOID0gIE5cclxuICogICBJICUgSSA9ICBOXHJcbiAqXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgbW9kdWxvIGB5YCwgcm91bmRlZCB0b1xyXG4gKiBgcHJlY2lzaW9uYCBzaWduaWZpY2FudCBkaWdpdHMgdXNpbmcgcm91bmRpbmcgbW9kZSBgcm91bmRpbmdgLlxyXG4gKlxyXG4gKiBUaGUgcmVzdWx0IGRlcGVuZHMgb24gdGhlIG1vZHVsbyBtb2RlLlxyXG4gKlxyXG4gKi9cclxuUC5tb2R1bG8gPSBQLm1vZCA9IGZ1bmN0aW9uICh5KSB7XHJcbiAgdmFyIHEsXHJcbiAgICB4ID0gdGhpcyxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yO1xyXG5cclxuICB5ID0gbmV3IEN0b3IoeSk7XHJcblxyXG4gIC8vIFJldHVybiBOYU4gaWYgeCBpcyDCsUluZmluaXR5IG9yIE5hTiwgb3IgeSBpcyBOYU4gb3IgwrEwLlxyXG4gIGlmICgheC5kIHx8ICF5LnMgfHwgeS5kICYmICF5LmRbMF0pIHJldHVybiBuZXcgQ3RvcihOYU4pO1xyXG5cclxuICAvLyBSZXR1cm4geCBpZiB5IGlzIMKxSW5maW5pdHkgb3IgeCBpcyDCsTAuXHJcbiAgaWYgKCF5LmQgfHwgeC5kICYmICF4LmRbMF0pIHtcclxuICAgIHJldHVybiBmaW5hbGlzZShuZXcgQ3Rvcih4KSwgQ3Rvci5wcmVjaXNpb24sIEN0b3Iucm91bmRpbmcpO1xyXG4gIH1cclxuXHJcbiAgLy8gUHJldmVudCByb3VuZGluZyBvZiBpbnRlcm1lZGlhdGUgY2FsY3VsYXRpb25zLlxyXG4gIGV4dGVybmFsID0gZmFsc2U7XHJcblxyXG4gIGlmIChDdG9yLm1vZHVsbyA9PSA5KSB7XHJcblxyXG4gICAgLy8gRXVjbGlkaWFuIGRpdmlzaW9uOiBxID0gc2lnbih5KSAqIGZsb29yKHggLyBhYnMoeSkpXHJcbiAgICAvLyByZXN1bHQgPSB4IC0gcSAqIHkgICAgd2hlcmUgIDAgPD0gcmVzdWx0IDwgYWJzKHkpXHJcbiAgICBxID0gZGl2aWRlKHgsIHkuYWJzKCksIDAsIDMsIDEpO1xyXG4gICAgcS5zICo9IHkucztcclxuICB9IGVsc2Uge1xyXG4gICAgcSA9IGRpdmlkZSh4LCB5LCAwLCBDdG9yLm1vZHVsbywgMSk7XHJcbiAgfVxyXG5cclxuICBxID0gcS50aW1lcyh5KTtcclxuXHJcbiAgZXh0ZXJuYWwgPSB0cnVlO1xyXG5cclxuICByZXR1cm4geC5taW51cyhxKTtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgbmF0dXJhbCBleHBvbmVudGlhbCBvZiB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsLFxyXG4gKiBpLmUuIHRoZSBiYXNlIGUgcmFpc2VkIHRvIHRoZSBwb3dlciB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsLCByb3VuZGVkIHRvIGBwcmVjaXNpb25gXHJcbiAqIHNpZ25pZmljYW50IGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqL1xyXG5QLm5hdHVyYWxFeHBvbmVudGlhbCA9IFAuZXhwID0gZnVuY3Rpb24gKCkge1xyXG4gIHJldHVybiBuYXR1cmFsRXhwb25lbnRpYWwodGhpcyk7XHJcbn07XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIG5hdHVyYWwgbG9nYXJpdGhtIG9mIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwsXHJcbiAqIHJvdW5kZWQgdG8gYHByZWNpc2lvbmAgc2lnbmlmaWNhbnQgZGlnaXRzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJvdW5kaW5nYC5cclxuICpcclxuICovXHJcblAubmF0dXJhbExvZ2FyaXRobSA9IFAubG4gPSBmdW5jdGlvbiAoKSB7XHJcbiAgcmV0dXJuIG5hdHVyYWxMb2dhcml0aG0odGhpcyk7XHJcbn07XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIHZhbHVlIG9mIHRoaXMgRGVjaW1hbCBuZWdhdGVkLCBpLmUuIGFzIGlmIG11bHRpcGxpZWQgYnlcclxuICogLTEuXHJcbiAqXHJcbiAqL1xyXG5QLm5lZ2F0ZWQgPSBQLm5lZyA9IGZ1bmN0aW9uICgpIHtcclxuICB2YXIgeCA9IG5ldyB0aGlzLmNvbnN0cnVjdG9yKHRoaXMpO1xyXG4gIHgucyA9IC14LnM7XHJcbiAgcmV0dXJuIGZpbmFsaXNlKHgpO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqICBuICsgMCA9IG5cclxuICogIG4gKyBOID0gTlxyXG4gKiAgbiArIEkgPSBJXHJcbiAqICAwICsgbiA9IG5cclxuICogIDAgKyAwID0gMFxyXG4gKiAgMCArIE4gPSBOXHJcbiAqICAwICsgSSA9IElcclxuICogIE4gKyBuID0gTlxyXG4gKiAgTiArIDAgPSBOXHJcbiAqICBOICsgTiA9IE5cclxuICogIE4gKyBJID0gTlxyXG4gKiAgSSArIG4gPSBJXHJcbiAqICBJICsgMCA9IElcclxuICogIEkgKyBOID0gTlxyXG4gKiAgSSArIEkgPSBJXHJcbiAqXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgcGx1cyBgeWAsIHJvdW5kZWQgdG8gYHByZWNpc2lvbmBcclxuICogc2lnbmlmaWNhbnQgZGlnaXRzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJvdW5kaW5nYC5cclxuICpcclxuICovXHJcblAucGx1cyA9IFAuYWRkID0gZnVuY3Rpb24gKHkpIHtcclxuICB2YXIgY2FycnksIGQsIGUsIGksIGssIGxlbiwgcHIsIHJtLCB4ZCwgeWQsXHJcbiAgICB4ID0gdGhpcyxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yO1xyXG5cclxuICB5ID0gbmV3IEN0b3IoeSk7XHJcblxyXG4gIC8vIElmIGVpdGhlciBpcyBub3QgZmluaXRlLi4uXHJcbiAgaWYgKCF4LmQgfHwgIXkuZCkge1xyXG5cclxuICAgIC8vIFJldHVybiBOYU4gaWYgZWl0aGVyIGlzIE5hTi5cclxuICAgIGlmICgheC5zIHx8ICF5LnMpIHkgPSBuZXcgQ3RvcihOYU4pO1xyXG5cclxuICAgIC8vIFJldHVybiB4IGlmIHkgaXMgZmluaXRlIGFuZCB4IGlzIMKxSW5maW5pdHkuXHJcbiAgICAvLyBSZXR1cm4geCBpZiBib3RoIGFyZSDCsUluZmluaXR5IHdpdGggdGhlIHNhbWUgc2lnbi5cclxuICAgIC8vIFJldHVybiBOYU4gaWYgYm90aCBhcmUgwrFJbmZpbml0eSB3aXRoIGRpZmZlcmVudCBzaWducy5cclxuICAgIC8vIFJldHVybiB5IGlmIHggaXMgZmluaXRlIGFuZCB5IGlzIMKxSW5maW5pdHkuXHJcbiAgICBlbHNlIGlmICgheC5kKSB5ID0gbmV3IEN0b3IoeS5kIHx8IHgucyA9PT0geS5zID8geCA6IE5hTik7XHJcblxyXG4gICAgcmV0dXJuIHk7XHJcbiAgfVxyXG5cclxuICAgLy8gSWYgc2lnbnMgZGlmZmVyLi4uXHJcbiAgaWYgKHgucyAhPSB5LnMpIHtcclxuICAgIHkucyA9IC15LnM7XHJcbiAgICByZXR1cm4geC5taW51cyh5KTtcclxuICB9XHJcblxyXG4gIHhkID0geC5kO1xyXG4gIHlkID0geS5kO1xyXG4gIHByID0gQ3Rvci5wcmVjaXNpb247XHJcbiAgcm0gPSBDdG9yLnJvdW5kaW5nO1xyXG5cclxuICAvLyBJZiBlaXRoZXIgaXMgemVyby4uLlxyXG4gIGlmICgheGRbMF0gfHwgIXlkWzBdKSB7XHJcblxyXG4gICAgLy8gUmV0dXJuIHggaWYgeSBpcyB6ZXJvLlxyXG4gICAgLy8gUmV0dXJuIHkgaWYgeSBpcyBub24temVyby5cclxuICAgIGlmICgheWRbMF0pIHkgPSBuZXcgQ3Rvcih4KTtcclxuXHJcbiAgICByZXR1cm4gZXh0ZXJuYWwgPyBmaW5hbGlzZSh5LCBwciwgcm0pIDogeTtcclxuICB9XHJcblxyXG4gIC8vIHggYW5kIHkgYXJlIGZpbml0ZSwgbm9uLXplcm8gbnVtYmVycyB3aXRoIHRoZSBzYW1lIHNpZ24uXHJcblxyXG4gIC8vIENhbGN1bGF0ZSBiYXNlIDFlNyBleHBvbmVudHMuXHJcbiAgayA9IG1hdGhmbG9vcih4LmUgLyBMT0dfQkFTRSk7XHJcbiAgZSA9IG1hdGhmbG9vcih5LmUgLyBMT0dfQkFTRSk7XHJcblxyXG4gIHhkID0geGQuc2xpY2UoKTtcclxuICBpID0gayAtIGU7XHJcblxyXG4gIC8vIElmIGJhc2UgMWU3IGV4cG9uZW50cyBkaWZmZXIuLi5cclxuICBpZiAoaSkge1xyXG5cclxuICAgIGlmIChpIDwgMCkge1xyXG4gICAgICBkID0geGQ7XHJcbiAgICAgIGkgPSAtaTtcclxuICAgICAgbGVuID0geWQubGVuZ3RoO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZCA9IHlkO1xyXG4gICAgICBlID0gaztcclxuICAgICAgbGVuID0geGQubGVuZ3RoO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIExpbWl0IG51bWJlciBvZiB6ZXJvcyBwcmVwZW5kZWQgdG8gbWF4KGNlaWwocHIgLyBMT0dfQkFTRSksIGxlbikgKyAxLlxyXG4gICAgayA9IE1hdGguY2VpbChwciAvIExPR19CQVNFKTtcclxuICAgIGxlbiA9IGsgPiBsZW4gPyBrICsgMSA6IGxlbiArIDE7XHJcblxyXG4gICAgaWYgKGkgPiBsZW4pIHtcclxuICAgICAgaSA9IGxlbjtcclxuICAgICAgZC5sZW5ndGggPSAxO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFByZXBlbmQgemVyb3MgdG8gZXF1YWxpc2UgZXhwb25lbnRzLiBOb3RlOiBGYXN0ZXIgdG8gdXNlIHJldmVyc2UgdGhlbiBkbyB1bnNoaWZ0cy5cclxuICAgIGQucmV2ZXJzZSgpO1xyXG4gICAgZm9yICg7IGktLTspIGQucHVzaCgwKTtcclxuICAgIGQucmV2ZXJzZSgpO1xyXG4gIH1cclxuXHJcbiAgbGVuID0geGQubGVuZ3RoO1xyXG4gIGkgPSB5ZC5sZW5ndGg7XHJcblxyXG4gIC8vIElmIHlkIGlzIGxvbmdlciB0aGFuIHhkLCBzd2FwIHhkIGFuZCB5ZCBzbyB4ZCBwb2ludHMgdG8gdGhlIGxvbmdlciBhcnJheS5cclxuICBpZiAobGVuIC0gaSA8IDApIHtcclxuICAgIGkgPSBsZW47XHJcbiAgICBkID0geWQ7XHJcbiAgICB5ZCA9IHhkO1xyXG4gICAgeGQgPSBkO1xyXG4gIH1cclxuXHJcbiAgLy8gT25seSBzdGFydCBhZGRpbmcgYXQgeWQubGVuZ3RoIC0gMSBhcyB0aGUgZnVydGhlciBkaWdpdHMgb2YgeGQgY2FuIGJlIGxlZnQgYXMgdGhleSBhcmUuXHJcbiAgZm9yIChjYXJyeSA9IDA7IGk7KSB7XHJcbiAgICBjYXJyeSA9ICh4ZFstLWldID0geGRbaV0gKyB5ZFtpXSArIGNhcnJ5KSAvIEJBU0UgfCAwO1xyXG4gICAgeGRbaV0gJT0gQkFTRTtcclxuICB9XHJcblxyXG4gIGlmIChjYXJyeSkge1xyXG4gICAgeGQudW5zaGlmdChjYXJyeSk7XHJcbiAgICArK2U7XHJcbiAgfVxyXG5cclxuICAvLyBSZW1vdmUgdHJhaWxpbmcgemVyb3MuXHJcbiAgLy8gTm8gbmVlZCB0byBjaGVjayBmb3IgemVybywgYXMgK3ggKyAreSAhPSAwICYmIC14ICsgLXkgIT0gMFxyXG4gIGZvciAobGVuID0geGQubGVuZ3RoOyB4ZFstLWxlbl0gPT0gMDspIHhkLnBvcCgpO1xyXG5cclxuICB5LmQgPSB4ZDtcclxuICB5LmUgPSBnZXRCYXNlMTBFeHBvbmVudCh4ZCwgZSk7XHJcblxyXG4gIHJldHVybiBleHRlcm5hbCA/IGZpbmFsaXNlKHksIHByLCBybSkgOiB5O1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiB0aGUgbnVtYmVyIG9mIHNpZ25pZmljYW50IGRpZ2l0cyBvZiB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsLlxyXG4gKlxyXG4gKiBbel0ge2Jvb2xlYW58bnVtYmVyfSBXaGV0aGVyIHRvIGNvdW50IGludGVnZXItcGFydCB0cmFpbGluZyB6ZXJvczogdHJ1ZSwgZmFsc2UsIDEgb3IgMC5cclxuICpcclxuICovXHJcblAucHJlY2lzaW9uID0gUC5zZCA9IGZ1bmN0aW9uICh6KSB7XHJcbiAgdmFyIGssXHJcbiAgICB4ID0gdGhpcztcclxuXHJcbiAgaWYgKHogIT09IHZvaWQgMCAmJiB6ICE9PSAhIXogJiYgeiAhPT0gMSAmJiB6ICE9PSAwKSB0aHJvdyBFcnJvcihpbnZhbGlkQXJndW1lbnQgKyB6KTtcclxuXHJcbiAgaWYgKHguZCkge1xyXG4gICAgayA9IGdldFByZWNpc2lvbih4LmQpO1xyXG4gICAgaWYgKHogJiYgeC5lICsgMSA+IGspIGsgPSB4LmUgKyAxO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBrID0gTmFOO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGs7XHJcbn07XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIHZhbHVlIG9mIHRoaXMgRGVjaW1hbCByb3VuZGVkIHRvIGEgd2hvbGUgbnVtYmVyIHVzaW5nXHJcbiAqIHJvdW5kaW5nIG1vZGUgYHJvdW5kaW5nYC5cclxuICpcclxuICovXHJcblAucm91bmQgPSBmdW5jdGlvbiAoKSB7XHJcbiAgdmFyIHggPSB0aGlzLFxyXG4gICAgQ3RvciA9IHguY29uc3RydWN0b3I7XHJcblxyXG4gIHJldHVybiBmaW5hbGlzZShuZXcgQ3Rvcih4KSwgeC5lICsgMSwgQ3Rvci5yb3VuZGluZyk7XHJcbn07XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIHNpbmUgb2YgdGhlIHZhbHVlIGluIHJhZGlhbnMgb2YgdGhpcyBEZWNpbWFsLlxyXG4gKlxyXG4gKiBEb21haW46IFstSW5maW5pdHksIEluZmluaXR5XVxyXG4gKiBSYW5nZTogWy0xLCAxXVxyXG4gKlxyXG4gKiBzaW4oeCkgPSB4IC0geF4zLzMhICsgeF41LzUhIC0gLi4uXHJcbiAqXHJcbiAqIHNpbigwKSAgICAgICAgID0gMFxyXG4gKiBzaW4oLTApICAgICAgICA9IC0wXHJcbiAqIHNpbihJbmZpbml0eSkgID0gTmFOXHJcbiAqIHNpbigtSW5maW5pdHkpID0gTmFOXHJcbiAqIHNpbihOYU4pICAgICAgID0gTmFOXHJcbiAqXHJcbiAqL1xyXG5QLnNpbmUgPSBQLnNpbiA9IGZ1bmN0aW9uICgpIHtcclxuICB2YXIgcHIsIHJtLFxyXG4gICAgeCA9IHRoaXMsXHJcbiAgICBDdG9yID0geC5jb25zdHJ1Y3RvcjtcclxuXHJcbiAgaWYgKCF4LmlzRmluaXRlKCkpIHJldHVybiBuZXcgQ3RvcihOYU4pO1xyXG4gIGlmICh4LmlzWmVybygpKSByZXR1cm4gbmV3IEN0b3IoeCk7XHJcblxyXG4gIHByID0gQ3Rvci5wcmVjaXNpb247XHJcbiAgcm0gPSBDdG9yLnJvdW5kaW5nO1xyXG4gIEN0b3IucHJlY2lzaW9uID0gcHIgKyBNYXRoLm1heCh4LmUsIHguc2QoKSkgKyBMT0dfQkFTRTtcclxuICBDdG9yLnJvdW5kaW5nID0gMTtcclxuXHJcbiAgeCA9IHNpbmUoQ3RvciwgdG9MZXNzVGhhbkhhbGZQaShDdG9yLCB4KSk7XHJcblxyXG4gIEN0b3IucHJlY2lzaW9uID0gcHI7XHJcbiAgQ3Rvci5yb3VuZGluZyA9IHJtO1xyXG5cclxuICByZXR1cm4gZmluYWxpc2UocXVhZHJhbnQgPiAyID8geC5uZWcoKSA6IHgsIHByLCBybSwgdHJ1ZSk7XHJcbn07XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIHNxdWFyZSByb290IG9mIHRoaXMgRGVjaW1hbCwgcm91bmRlZCB0byBgcHJlY2lzaW9uYFxyXG4gKiBzaWduaWZpY2FudCBkaWdpdHMgdXNpbmcgcm91bmRpbmcgbW9kZSBgcm91bmRpbmdgLlxyXG4gKlxyXG4gKiAgc3FydCgtbikgPSAgTlxyXG4gKiAgc3FydChOKSAgPSAgTlxyXG4gKiAgc3FydCgtSSkgPSAgTlxyXG4gKiAgc3FydChJKSAgPSAgSVxyXG4gKiAgc3FydCgwKSAgPSAgMFxyXG4gKiAgc3FydCgtMCkgPSAtMFxyXG4gKlxyXG4gKi9cclxuUC5zcXVhcmVSb290ID0gUC5zcXJ0ID0gZnVuY3Rpb24gKCkge1xyXG4gIHZhciBtLCBuLCBzZCwgciwgcmVwLCB0LFxyXG4gICAgeCA9IHRoaXMsXHJcbiAgICBkID0geC5kLFxyXG4gICAgZSA9IHguZSxcclxuICAgIHMgPSB4LnMsXHJcbiAgICBDdG9yID0geC5jb25zdHJ1Y3RvcjtcclxuXHJcbiAgLy8gTmVnYXRpdmUvTmFOL0luZmluaXR5L3plcm8/XHJcbiAgaWYgKHMgIT09IDEgfHwgIWQgfHwgIWRbMF0pIHtcclxuICAgIHJldHVybiBuZXcgQ3RvcighcyB8fCBzIDwgMCAmJiAoIWQgfHwgZFswXSkgPyBOYU4gOiBkID8geCA6IDEgLyAwKTtcclxuICB9XHJcblxyXG4gIGV4dGVybmFsID0gZmFsc2U7XHJcblxyXG4gIC8vIEluaXRpYWwgZXN0aW1hdGUuXHJcbiAgcyA9IE1hdGguc3FydCgreCk7XHJcblxyXG4gIC8vIE1hdGguc3FydCB1bmRlcmZsb3cvb3ZlcmZsb3c/XHJcbiAgLy8gUGFzcyB4IHRvIE1hdGguc3FydCBhcyBpbnRlZ2VyLCB0aGVuIGFkanVzdCB0aGUgZXhwb25lbnQgb2YgdGhlIHJlc3VsdC5cclxuICBpZiAocyA9PSAwIHx8IHMgPT0gMSAvIDApIHtcclxuICAgIG4gPSBkaWdpdHNUb1N0cmluZyhkKTtcclxuXHJcbiAgICBpZiAoKG4ubGVuZ3RoICsgZSkgJSAyID09IDApIG4gKz0gJzAnO1xyXG4gICAgcyA9IE1hdGguc3FydChuKTtcclxuICAgIGUgPSBtYXRoZmxvb3IoKGUgKyAxKSAvIDIpIC0gKGUgPCAwIHx8IGUgJSAyKTtcclxuXHJcbiAgICBpZiAocyA9PSAxIC8gMCkge1xyXG4gICAgICBuID0gJzVlJyArIGU7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBuID0gcy50b0V4cG9uZW50aWFsKCk7XHJcbiAgICAgIG4gPSBuLnNsaWNlKDAsIG4uaW5kZXhPZignZScpICsgMSkgKyBlO1xyXG4gICAgfVxyXG5cclxuICAgIHIgPSBuZXcgQ3RvcihuKTtcclxuICB9IGVsc2Uge1xyXG4gICAgciA9IG5ldyBDdG9yKHMudG9TdHJpbmcoKSk7XHJcbiAgfVxyXG5cclxuICBzZCA9IChlID0gQ3Rvci5wcmVjaXNpb24pICsgMztcclxuXHJcbiAgLy8gTmV3dG9uLVJhcGhzb24gaXRlcmF0aW9uLlxyXG4gIGZvciAoOzspIHtcclxuICAgIHQgPSByO1xyXG4gICAgciA9IHQucGx1cyhkaXZpZGUoeCwgdCwgc2QgKyAyLCAxKSkudGltZXMoMC41KTtcclxuXHJcbiAgICAvLyBUT0RPPyBSZXBsYWNlIHdpdGggZm9yLWxvb3AgYW5kIGNoZWNrUm91bmRpbmdEaWdpdHMuXHJcbiAgICBpZiAoZGlnaXRzVG9TdHJpbmcodC5kKS5zbGljZSgwLCBzZCkgPT09IChuID0gZGlnaXRzVG9TdHJpbmcoci5kKSkuc2xpY2UoMCwgc2QpKSB7XHJcbiAgICAgIG4gPSBuLnNsaWNlKHNkIC0gMywgc2QgKyAxKTtcclxuXHJcbiAgICAgIC8vIFRoZSA0dGggcm91bmRpbmcgZGlnaXQgbWF5IGJlIGluIGVycm9yIGJ5IC0xIHNvIGlmIHRoZSA0IHJvdW5kaW5nIGRpZ2l0cyBhcmUgOTk5OSBvclxyXG4gICAgICAvLyA0OTk5LCBpLmUuIGFwcHJvYWNoaW5nIGEgcm91bmRpbmcgYm91bmRhcnksIGNvbnRpbnVlIHRoZSBpdGVyYXRpb24uXHJcbiAgICAgIGlmIChuID09ICc5OTk5JyB8fCAhcmVwICYmIG4gPT0gJzQ5OTknKSB7XHJcblxyXG4gICAgICAgIC8vIE9uIHRoZSBmaXJzdCBpdGVyYXRpb24gb25seSwgY2hlY2sgdG8gc2VlIGlmIHJvdW5kaW5nIHVwIGdpdmVzIHRoZSBleGFjdCByZXN1bHQgYXMgdGhlXHJcbiAgICAgICAgLy8gbmluZXMgbWF5IGluZmluaXRlbHkgcmVwZWF0LlxyXG4gICAgICAgIGlmICghcmVwKSB7XHJcbiAgICAgICAgICBmaW5hbGlzZSh0LCBlICsgMSwgMCk7XHJcblxyXG4gICAgICAgICAgaWYgKHQudGltZXModCkuZXEoeCkpIHtcclxuICAgICAgICAgICAgciA9IHQ7XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc2QgKz0gNDtcclxuICAgICAgICByZXAgPSAxO1xyXG4gICAgICB9IGVsc2Uge1xyXG5cclxuICAgICAgICAvLyBJZiB0aGUgcm91bmRpbmcgZGlnaXRzIGFyZSBudWxsLCAwezAsNH0gb3IgNTB7MCwzfSwgY2hlY2sgZm9yIGFuIGV4YWN0IHJlc3VsdC5cclxuICAgICAgICAvLyBJZiBub3QsIHRoZW4gdGhlcmUgYXJlIGZ1cnRoZXIgZGlnaXRzIGFuZCBtIHdpbGwgYmUgdHJ1dGh5LlxyXG4gICAgICAgIGlmICghK24gfHwgIStuLnNsaWNlKDEpICYmIG4uY2hhckF0KDApID09ICc1Jykge1xyXG5cclxuICAgICAgICAgIC8vIFRydW5jYXRlIHRvIHRoZSBmaXJzdCByb3VuZGluZyBkaWdpdC5cclxuICAgICAgICAgIGZpbmFsaXNlKHIsIGUgKyAxLCAxKTtcclxuICAgICAgICAgIG0gPSAhci50aW1lcyhyKS5lcSh4KTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBleHRlcm5hbCA9IHRydWU7XHJcblxyXG4gIHJldHVybiBmaW5hbGlzZShyLCBlLCBDdG9yLnJvdW5kaW5nLCBtKTtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgdGFuZ2VudCBvZiB0aGUgdmFsdWUgaW4gcmFkaWFucyBvZiB0aGlzIERlY2ltYWwuXHJcbiAqXHJcbiAqIERvbWFpbjogWy1JbmZpbml0eSwgSW5maW5pdHldXHJcbiAqIFJhbmdlOiBbLUluZmluaXR5LCBJbmZpbml0eV1cclxuICpcclxuICogdGFuKDApICAgICAgICAgPSAwXHJcbiAqIHRhbigtMCkgICAgICAgID0gLTBcclxuICogdGFuKEluZmluaXR5KSAgPSBOYU5cclxuICogdGFuKC1JbmZpbml0eSkgPSBOYU5cclxuICogdGFuKE5hTikgICAgICAgPSBOYU5cclxuICpcclxuICovXHJcblAudGFuZ2VudCA9IFAudGFuID0gZnVuY3Rpb24gKCkge1xyXG4gIHZhciBwciwgcm0sXHJcbiAgICB4ID0gdGhpcyxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yO1xyXG5cclxuICBpZiAoIXguaXNGaW5pdGUoKSkgcmV0dXJuIG5ldyBDdG9yKE5hTik7XHJcbiAgaWYgKHguaXNaZXJvKCkpIHJldHVybiBuZXcgQ3Rvcih4KTtcclxuXHJcbiAgcHIgPSBDdG9yLnByZWNpc2lvbjtcclxuICBybSA9IEN0b3Iucm91bmRpbmc7XHJcbiAgQ3Rvci5wcmVjaXNpb24gPSBwciArIDEwO1xyXG4gIEN0b3Iucm91bmRpbmcgPSAxO1xyXG5cclxuICB4ID0geC5zaW4oKTtcclxuICB4LnMgPSAxO1xyXG4gIHggPSBkaXZpZGUoeCwgbmV3IEN0b3IoMSkubWludXMoeC50aW1lcyh4KSkuc3FydCgpLCBwciArIDEwLCAwKTtcclxuXHJcbiAgQ3Rvci5wcmVjaXNpb24gPSBwcjtcclxuICBDdG9yLnJvdW5kaW5nID0gcm07XHJcblxyXG4gIHJldHVybiBmaW5hbGlzZShxdWFkcmFudCA9PSAyIHx8IHF1YWRyYW50ID09IDQgPyB4Lm5lZygpIDogeCwgcHIsIHJtLCB0cnVlKTtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiAgbiAqIDAgPSAwXHJcbiAqICBuICogTiA9IE5cclxuICogIG4gKiBJID0gSVxyXG4gKiAgMCAqIG4gPSAwXHJcbiAqICAwICogMCA9IDBcclxuICogIDAgKiBOID0gTlxyXG4gKiAgMCAqIEkgPSBOXHJcbiAqICBOICogbiA9IE5cclxuICogIE4gKiAwID0gTlxyXG4gKiAgTiAqIE4gPSBOXHJcbiAqICBOICogSSA9IE5cclxuICogIEkgKiBuID0gSVxyXG4gKiAgSSAqIDAgPSBOXHJcbiAqICBJICogTiA9IE5cclxuICogIEkgKiBJID0gSVxyXG4gKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGlzIERlY2ltYWwgdGltZXMgYHlgLCByb3VuZGVkIHRvIGBwcmVjaXNpb25gIHNpZ25pZmljYW50XHJcbiAqIGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqL1xyXG5QLnRpbWVzID0gUC5tdWwgPSBmdW5jdGlvbiAoeSkge1xyXG4gIHZhciBjYXJyeSwgZSwgaSwgaywgciwgckwsIHQsIHhkTCwgeWRMLFxyXG4gICAgeCA9IHRoaXMsXHJcbiAgICBDdG9yID0geC5jb25zdHJ1Y3RvcixcclxuICAgIHhkID0geC5kLFxyXG4gICAgeWQgPSAoeSA9IG5ldyBDdG9yKHkpKS5kO1xyXG5cclxuICB5LnMgKj0geC5zO1xyXG5cclxuICAgLy8gSWYgZWl0aGVyIGlzIE5hTiwgwrFJbmZpbml0eSBvciDCsTAuLi5cclxuICBpZiAoIXhkIHx8ICF4ZFswXSB8fCAheWQgfHwgIXlkWzBdKSB7XHJcblxyXG4gICAgcmV0dXJuIG5ldyBDdG9yKCF5LnMgfHwgeGQgJiYgIXhkWzBdICYmICF5ZCB8fCB5ZCAmJiAheWRbMF0gJiYgIXhkXHJcblxyXG4gICAgICAvLyBSZXR1cm4gTmFOIGlmIGVpdGhlciBpcyBOYU4uXHJcbiAgICAgIC8vIFJldHVybiBOYU4gaWYgeCBpcyDCsTAgYW5kIHkgaXMgwrFJbmZpbml0eSwgb3IgeSBpcyDCsTAgYW5kIHggaXMgwrFJbmZpbml0eS5cclxuICAgICAgPyBOYU5cclxuXHJcbiAgICAgIC8vIFJldHVybiDCsUluZmluaXR5IGlmIGVpdGhlciBpcyDCsUluZmluaXR5LlxyXG4gICAgICAvLyBSZXR1cm4gwrEwIGlmIGVpdGhlciBpcyDCsTAuXHJcbiAgICAgIDogIXhkIHx8ICF5ZCA/IHkucyAvIDAgOiB5LnMgKiAwKTtcclxuICB9XHJcblxyXG4gIGUgPSBtYXRoZmxvb3IoeC5lIC8gTE9HX0JBU0UpICsgbWF0aGZsb29yKHkuZSAvIExPR19CQVNFKTtcclxuICB4ZEwgPSB4ZC5sZW5ndGg7XHJcbiAgeWRMID0geWQubGVuZ3RoO1xyXG5cclxuICAvLyBFbnN1cmUgeGQgcG9pbnRzIHRvIHRoZSBsb25nZXIgYXJyYXkuXHJcbiAgaWYgKHhkTCA8IHlkTCkge1xyXG4gICAgciA9IHhkO1xyXG4gICAgeGQgPSB5ZDtcclxuICAgIHlkID0gcjtcclxuICAgIHJMID0geGRMO1xyXG4gICAgeGRMID0geWRMO1xyXG4gICAgeWRMID0gckw7XHJcbiAgfVxyXG5cclxuICAvLyBJbml0aWFsaXNlIHRoZSByZXN1bHQgYXJyYXkgd2l0aCB6ZXJvcy5cclxuICByID0gW107XHJcbiAgckwgPSB4ZEwgKyB5ZEw7XHJcbiAgZm9yIChpID0gckw7IGktLTspIHIucHVzaCgwKTtcclxuXHJcbiAgLy8gTXVsdGlwbHkhXHJcbiAgZm9yIChpID0geWRMOyAtLWkgPj0gMDspIHtcclxuICAgIGNhcnJ5ID0gMDtcclxuICAgIGZvciAoayA9IHhkTCArIGk7IGsgPiBpOykge1xyXG4gICAgICB0ID0gcltrXSArIHlkW2ldICogeGRbayAtIGkgLSAxXSArIGNhcnJ5O1xyXG4gICAgICByW2stLV0gPSB0ICUgQkFTRSB8IDA7XHJcbiAgICAgIGNhcnJ5ID0gdCAvIEJBU0UgfCAwO1xyXG4gICAgfVxyXG5cclxuICAgIHJba10gPSAocltrXSArIGNhcnJ5KSAlIEJBU0UgfCAwO1xyXG4gIH1cclxuXHJcbiAgLy8gUmVtb3ZlIHRyYWlsaW5nIHplcm9zLlxyXG4gIGZvciAoOyAhclstLXJMXTspIHIucG9wKCk7XHJcblxyXG4gIGlmIChjYXJyeSkgKytlO1xyXG4gIGVsc2Ugci5zaGlmdCgpO1xyXG5cclxuICB5LmQgPSByO1xyXG4gIHkuZSA9IGdldEJhc2UxMEV4cG9uZW50KHIsIGUpO1xyXG5cclxuICByZXR1cm4gZXh0ZXJuYWwgPyBmaW5hbGlzZSh5LCBDdG9yLnByZWNpc2lvbiwgQ3Rvci5yb3VuZGluZykgOiB5O1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIHN0cmluZyByZXByZXNlbnRpbmcgdGhlIHZhbHVlIG9mIHRoaXMgRGVjaW1hbCBpbiBiYXNlIDIsIHJvdW5kIHRvIGBzZGAgc2lnbmlmaWNhbnRcclxuICogZGlnaXRzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJtYC5cclxuICpcclxuICogSWYgdGhlIG9wdGlvbmFsIGBzZGAgYXJndW1lbnQgaXMgcHJlc2VudCB0aGVuIHJldHVybiBiaW5hcnkgZXhwb25lbnRpYWwgbm90YXRpb24uXHJcbiAqXHJcbiAqIFtzZF0ge251bWJlcn0gU2lnbmlmaWNhbnQgZGlnaXRzLiBJbnRlZ2VyLCAxIHRvIE1BWF9ESUdJVFMgaW5jbHVzaXZlLlxyXG4gKiBbcm1dIHtudW1iZXJ9IFJvdW5kaW5nIG1vZGUuIEludGVnZXIsIDAgdG8gOCBpbmNsdXNpdmUuXHJcbiAqXHJcbiAqL1xyXG5QLnRvQmluYXJ5ID0gZnVuY3Rpb24gKHNkLCBybSkge1xyXG4gIHJldHVybiB0b1N0cmluZ0JpbmFyeSh0aGlzLCAyLCBzZCwgcm0pO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgcm91bmRlZCB0byBhIG1heGltdW0gb2YgYGRwYFxyXG4gKiBkZWNpbWFsIHBsYWNlcyB1c2luZyByb3VuZGluZyBtb2RlIGBybWAgb3IgYHJvdW5kaW5nYCBpZiBgcm1gIGlzIG9taXR0ZWQuXHJcbiAqXHJcbiAqIElmIGBkcGAgaXMgb21pdHRlZCwgcmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIHZhbHVlIG9mIHRoaXMgRGVjaW1hbC5cclxuICpcclxuICogW2RwXSB7bnVtYmVyfSBEZWNpbWFsIHBsYWNlcy4gSW50ZWdlciwgMCB0byBNQVhfRElHSVRTIGluY2x1c2l2ZS5cclxuICogW3JtXSB7bnVtYmVyfSBSb3VuZGluZyBtb2RlLiBJbnRlZ2VyLCAwIHRvIDggaW5jbHVzaXZlLlxyXG4gKlxyXG4gKi9cclxuUC50b0RlY2ltYWxQbGFjZXMgPSBQLnRvRFAgPSBmdW5jdGlvbiAoZHAsIHJtKSB7XHJcbiAgdmFyIHggPSB0aGlzLFxyXG4gICAgQ3RvciA9IHguY29uc3RydWN0b3I7XHJcblxyXG4gIHggPSBuZXcgQ3Rvcih4KTtcclxuICBpZiAoZHAgPT09IHZvaWQgMCkgcmV0dXJuIHg7XHJcblxyXG4gIGNoZWNrSW50MzIoZHAsIDAsIE1BWF9ESUdJVFMpO1xyXG5cclxuICBpZiAocm0gPT09IHZvaWQgMCkgcm0gPSBDdG9yLnJvdW5kaW5nO1xyXG4gIGVsc2UgY2hlY2tJbnQzMihybSwgMCwgOCk7XHJcblxyXG4gIHJldHVybiBmaW5hbGlzZSh4LCBkcCArIHguZSArIDEsIHJtKTtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBzdHJpbmcgcmVwcmVzZW50aW5nIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgaW4gZXhwb25lbnRpYWwgbm90YXRpb24gcm91bmRlZCB0b1xyXG4gKiBgZHBgIGZpeGVkIGRlY2ltYWwgcGxhY2VzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJvdW5kaW5nYC5cclxuICpcclxuICogW2RwXSB7bnVtYmVyfSBEZWNpbWFsIHBsYWNlcy4gSW50ZWdlciwgMCB0byBNQVhfRElHSVRTIGluY2x1c2l2ZS5cclxuICogW3JtXSB7bnVtYmVyfSBSb3VuZGluZyBtb2RlLiBJbnRlZ2VyLCAwIHRvIDggaW5jbHVzaXZlLlxyXG4gKlxyXG4gKi9cclxuUC50b0V4cG9uZW50aWFsID0gZnVuY3Rpb24gKGRwLCBybSkge1xyXG4gIHZhciBzdHIsXHJcbiAgICB4ID0gdGhpcyxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yO1xyXG5cclxuICBpZiAoZHAgPT09IHZvaWQgMCkge1xyXG4gICAgc3RyID0gZmluaXRlVG9TdHJpbmcoeCwgdHJ1ZSk7XHJcbiAgfSBlbHNlIHtcclxuICAgIGNoZWNrSW50MzIoZHAsIDAsIE1BWF9ESUdJVFMpO1xyXG5cclxuICAgIGlmIChybSA9PT0gdm9pZCAwKSBybSA9IEN0b3Iucm91bmRpbmc7XHJcbiAgICBlbHNlIGNoZWNrSW50MzIocm0sIDAsIDgpO1xyXG5cclxuICAgIHggPSBmaW5hbGlzZShuZXcgQ3Rvcih4KSwgZHAgKyAxLCBybSk7XHJcbiAgICBzdHIgPSBmaW5pdGVUb1N0cmluZyh4LCB0cnVlLCBkcCArIDEpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHguaXNOZWcoKSAmJiAheC5pc1plcm8oKSA/ICctJyArIHN0ciA6IHN0cjtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBzdHJpbmcgcmVwcmVzZW50aW5nIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgaW4gbm9ybWFsIChmaXhlZC1wb2ludCkgbm90YXRpb24gdG9cclxuICogYGRwYCBmaXhlZCBkZWNpbWFsIHBsYWNlcyBhbmQgcm91bmRlZCB1c2luZyByb3VuZGluZyBtb2RlIGBybWAgb3IgYHJvdW5kaW5nYCBpZiBgcm1gIGlzXHJcbiAqIG9taXR0ZWQuXHJcbiAqXHJcbiAqIEFzIHdpdGggSmF2YVNjcmlwdCBudW1iZXJzLCAoLTApLnRvRml4ZWQoMCkgaXMgJzAnLCBidXQgZS5nLiAoLTAuMDAwMDEpLnRvRml4ZWQoMCkgaXMgJy0wJy5cclxuICpcclxuICogW2RwXSB7bnVtYmVyfSBEZWNpbWFsIHBsYWNlcy4gSW50ZWdlciwgMCB0byBNQVhfRElHSVRTIGluY2x1c2l2ZS5cclxuICogW3JtXSB7bnVtYmVyfSBSb3VuZGluZyBtb2RlLiBJbnRlZ2VyLCAwIHRvIDggaW5jbHVzaXZlLlxyXG4gKlxyXG4gKiAoLTApLnRvRml4ZWQoMCkgaXMgJzAnLCBidXQgKC0wLjEpLnRvRml4ZWQoMCkgaXMgJy0wJy5cclxuICogKC0wKS50b0ZpeGVkKDEpIGlzICcwLjAnLCBidXQgKC0wLjAxKS50b0ZpeGVkKDEpIGlzICctMC4wJy5cclxuICogKC0wKS50b0ZpeGVkKDMpIGlzICcwLjAwMCcuXHJcbiAqICgtMC41KS50b0ZpeGVkKDApIGlzICctMCcuXHJcbiAqXHJcbiAqL1xyXG5QLnRvRml4ZWQgPSBmdW5jdGlvbiAoZHAsIHJtKSB7XHJcbiAgdmFyIHN0ciwgeSxcclxuICAgIHggPSB0aGlzLFxyXG4gICAgQ3RvciA9IHguY29uc3RydWN0b3I7XHJcblxyXG4gIGlmIChkcCA9PT0gdm9pZCAwKSB7XHJcbiAgICBzdHIgPSBmaW5pdGVUb1N0cmluZyh4KTtcclxuICB9IGVsc2Uge1xyXG4gICAgY2hlY2tJbnQzMihkcCwgMCwgTUFYX0RJR0lUUyk7XHJcblxyXG4gICAgaWYgKHJtID09PSB2b2lkIDApIHJtID0gQ3Rvci5yb3VuZGluZztcclxuICAgIGVsc2UgY2hlY2tJbnQzMihybSwgMCwgOCk7XHJcblxyXG4gICAgeSA9IGZpbmFsaXNlKG5ldyBDdG9yKHgpLCBkcCArIHguZSArIDEsIHJtKTtcclxuICAgIHN0ciA9IGZpbml0ZVRvU3RyaW5nKHksIGZhbHNlLCBkcCArIHkuZSArIDEpO1xyXG4gIH1cclxuXHJcbiAgLy8gVG8gZGV0ZXJtaW5lIHdoZXRoZXIgdG8gYWRkIHRoZSBtaW51cyBzaWduIGxvb2sgYXQgdGhlIHZhbHVlIGJlZm9yZSBpdCB3YXMgcm91bmRlZCxcclxuICAvLyBpLmUuIGxvb2sgYXQgYHhgIHJhdGhlciB0aGFuIGB5YC5cclxuICByZXR1cm4geC5pc05lZygpICYmICF4LmlzWmVybygpID8gJy0nICsgc3RyIDogc3RyO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhbiBhcnJheSByZXByZXNlbnRpbmcgdGhlIHZhbHVlIG9mIHRoaXMgRGVjaW1hbCBhcyBhIHNpbXBsZSBmcmFjdGlvbiB3aXRoIGFuIGludGVnZXJcclxuICogbnVtZXJhdG9yIGFuZCBhbiBpbnRlZ2VyIGRlbm9taW5hdG9yLlxyXG4gKlxyXG4gKiBUaGUgZGVub21pbmF0b3Igd2lsbCBiZSBhIHBvc2l0aXZlIG5vbi16ZXJvIHZhbHVlIGxlc3MgdGhhbiBvciBlcXVhbCB0byB0aGUgc3BlY2lmaWVkIG1heGltdW1cclxuICogZGVub21pbmF0b3IuIElmIGEgbWF4aW11bSBkZW5vbWluYXRvciBpcyBub3Qgc3BlY2lmaWVkLCB0aGUgZGVub21pbmF0b3Igd2lsbCBiZSB0aGUgbG93ZXN0XHJcbiAqIHZhbHVlIG5lY2Vzc2FyeSB0byByZXByZXNlbnQgdGhlIG51bWJlciBleGFjdGx5LlxyXG4gKlxyXG4gKiBbbWF4RF0ge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9IE1heGltdW0gZGVub21pbmF0b3IuIEludGVnZXIgPj0gMSBhbmQgPCBJbmZpbml0eS5cclxuICpcclxuICovXHJcblAudG9GcmFjdGlvbiA9IGZ1bmN0aW9uIChtYXhEKSB7XHJcbiAgdmFyIGQsIGQwLCBkMSwgZDIsIGUsIGssIG4sIG4wLCBuMSwgcHIsIHEsIHIsXHJcbiAgICB4ID0gdGhpcyxcclxuICAgIHhkID0geC5kLFxyXG4gICAgQ3RvciA9IHguY29uc3RydWN0b3I7XHJcblxyXG4gIGlmICgheGQpIHJldHVybiBuZXcgQ3Rvcih4KTtcclxuXHJcbiAgbjEgPSBkMCA9IG5ldyBDdG9yKDEpO1xyXG4gIGQxID0gbjAgPSBuZXcgQ3RvcigwKTtcclxuXHJcbiAgZCA9IG5ldyBDdG9yKGQxKTtcclxuICBlID0gZC5lID0gZ2V0UHJlY2lzaW9uKHhkKSAtIHguZSAtIDE7XHJcbiAgayA9IGUgJSBMT0dfQkFTRTtcclxuICBkLmRbMF0gPSBtYXRocG93KDEwLCBrIDwgMCA/IExPR19CQVNFICsgayA6IGspO1xyXG5cclxuICBpZiAobWF4RCA9PSBudWxsKSB7XHJcblxyXG4gICAgLy8gZCBpcyAxMCoqZSwgdGhlIG1pbmltdW0gbWF4LWRlbm9taW5hdG9yIG5lZWRlZC5cclxuICAgIG1heEQgPSBlID4gMCA/IGQgOiBuMTtcclxuICB9IGVsc2Uge1xyXG4gICAgbiA9IG5ldyBDdG9yKG1heEQpO1xyXG4gICAgaWYgKCFuLmlzSW50KCkgfHwgbi5sdChuMSkpIHRocm93IEVycm9yKGludmFsaWRBcmd1bWVudCArIG4pO1xyXG4gICAgbWF4RCA9IG4uZ3QoZCkgPyAoZSA+IDAgPyBkIDogbjEpIDogbjtcclxuICB9XHJcblxyXG4gIGV4dGVybmFsID0gZmFsc2U7XHJcbiAgbiA9IG5ldyBDdG9yKGRpZ2l0c1RvU3RyaW5nKHhkKSk7XHJcbiAgcHIgPSBDdG9yLnByZWNpc2lvbjtcclxuICBDdG9yLnByZWNpc2lvbiA9IGUgPSB4ZC5sZW5ndGggKiBMT0dfQkFTRSAqIDI7XHJcblxyXG4gIGZvciAoOzspICB7XHJcbiAgICBxID0gZGl2aWRlKG4sIGQsIDAsIDEsIDEpO1xyXG4gICAgZDIgPSBkMC5wbHVzKHEudGltZXMoZDEpKTtcclxuICAgIGlmIChkMi5jbXAobWF4RCkgPT0gMSkgYnJlYWs7XHJcbiAgICBkMCA9IGQxO1xyXG4gICAgZDEgPSBkMjtcclxuICAgIGQyID0gbjE7XHJcbiAgICBuMSA9IG4wLnBsdXMocS50aW1lcyhkMikpO1xyXG4gICAgbjAgPSBkMjtcclxuICAgIGQyID0gZDtcclxuICAgIGQgPSBuLm1pbnVzKHEudGltZXMoZDIpKTtcclxuICAgIG4gPSBkMjtcclxuICB9XHJcblxyXG4gIGQyID0gZGl2aWRlKG1heEQubWludXMoZDApLCBkMSwgMCwgMSwgMSk7XHJcbiAgbjAgPSBuMC5wbHVzKGQyLnRpbWVzKG4xKSk7XHJcbiAgZDAgPSBkMC5wbHVzKGQyLnRpbWVzKGQxKSk7XHJcbiAgbjAucyA9IG4xLnMgPSB4LnM7XHJcblxyXG4gIC8vIERldGVybWluZSB3aGljaCBmcmFjdGlvbiBpcyBjbG9zZXIgdG8geCwgbjAvZDAgb3IgbjEvZDE/XHJcbiAgciA9IGRpdmlkZShuMSwgZDEsIGUsIDEpLm1pbnVzKHgpLmFicygpLmNtcChkaXZpZGUobjAsIGQwLCBlLCAxKS5taW51cyh4KS5hYnMoKSkgPCAxXHJcbiAgICAgID8gW24xLCBkMV0gOiBbbjAsIGQwXTtcclxuXHJcbiAgQ3Rvci5wcmVjaXNpb24gPSBwcjtcclxuICBleHRlcm5hbCA9IHRydWU7XHJcblxyXG4gIHJldHVybiByO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIHN0cmluZyByZXByZXNlbnRpbmcgdGhlIHZhbHVlIG9mIHRoaXMgRGVjaW1hbCBpbiBiYXNlIDE2LCByb3VuZCB0byBgc2RgIHNpZ25pZmljYW50XHJcbiAqIGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGBybWAuXHJcbiAqXHJcbiAqIElmIHRoZSBvcHRpb25hbCBgc2RgIGFyZ3VtZW50IGlzIHByZXNlbnQgdGhlbiByZXR1cm4gYmluYXJ5IGV4cG9uZW50aWFsIG5vdGF0aW9uLlxyXG4gKlxyXG4gKiBbc2RdIHtudW1iZXJ9IFNpZ25pZmljYW50IGRpZ2l0cy4gSW50ZWdlciwgMSB0byBNQVhfRElHSVRTIGluY2x1c2l2ZS5cclxuICogW3JtXSB7bnVtYmVyfSBSb3VuZGluZyBtb2RlLiBJbnRlZ2VyLCAwIHRvIDggaW5jbHVzaXZlLlxyXG4gKlxyXG4gKi9cclxuUC50b0hleGFkZWNpbWFsID0gUC50b0hleCA9IGZ1bmN0aW9uIChzZCwgcm0pIHtcclxuICByZXR1cm4gdG9TdHJpbmdCaW5hcnkodGhpcywgMTYsIHNkLCBybSk7XHJcbn07XHJcblxyXG5cclxuLypcclxuICogUmV0dXJucyBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBuZWFyZXN0IG11bHRpcGxlIG9mIGB5YCBpbiB0aGUgZGlyZWN0aW9uIG9mIHJvdW5kaW5nXHJcbiAqIG1vZGUgYHJtYCwgb3IgYERlY2ltYWwucm91bmRpbmdgIGlmIGBybWAgaXMgb21pdHRlZCwgdG8gdGhlIHZhbHVlIG9mIHRoaXMgRGVjaW1hbC5cclxuICpcclxuICogVGhlIHJldHVybiB2YWx1ZSB3aWxsIGFsd2F5cyBoYXZlIHRoZSBzYW1lIHNpZ24gYXMgdGhpcyBEZWNpbWFsLCB1bmxlc3MgZWl0aGVyIHRoaXMgRGVjaW1hbFxyXG4gKiBvciBgeWAgaXMgTmFOLCBpbiB3aGljaCBjYXNlIHRoZSByZXR1cm4gdmFsdWUgd2lsbCBiZSBhbHNvIGJlIE5hTi5cclxuICpcclxuICogVGhlIHJldHVybiB2YWx1ZSBpcyBub3QgYWZmZWN0ZWQgYnkgdGhlIHZhbHVlIG9mIGBwcmVjaXNpb25gLlxyXG4gKlxyXG4gKiB5IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfSBUaGUgbWFnbml0dWRlIHRvIHJvdW5kIHRvIGEgbXVsdGlwbGUgb2YuXHJcbiAqIFtybV0ge251bWJlcn0gUm91bmRpbmcgbW9kZS4gSW50ZWdlciwgMCB0byA4IGluY2x1c2l2ZS5cclxuICpcclxuICogJ3RvTmVhcmVzdCgpIHJvdW5kaW5nIG1vZGUgbm90IGFuIGludGVnZXI6IHtybX0nXHJcbiAqICd0b05lYXJlc3QoKSByb3VuZGluZyBtb2RlIG91dCBvZiByYW5nZToge3JtfSdcclxuICpcclxuICovXHJcblAudG9OZWFyZXN0ID0gZnVuY3Rpb24gKHksIHJtKSB7XHJcbiAgdmFyIHggPSB0aGlzLFxyXG4gICAgQ3RvciA9IHguY29uc3RydWN0b3I7XHJcblxyXG4gIHggPSBuZXcgQ3Rvcih4KTtcclxuXHJcbiAgaWYgKHkgPT0gbnVsbCkge1xyXG5cclxuICAgIC8vIElmIHggaXMgbm90IGZpbml0ZSwgcmV0dXJuIHguXHJcbiAgICBpZiAoIXguZCkgcmV0dXJuIHg7XHJcblxyXG4gICAgeSA9IG5ldyBDdG9yKDEpO1xyXG4gICAgcm0gPSBDdG9yLnJvdW5kaW5nO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB5ID0gbmV3IEN0b3IoeSk7XHJcbiAgICBpZiAocm0gPT09IHZvaWQgMCkge1xyXG4gICAgICBybSA9IEN0b3Iucm91bmRpbmc7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBjaGVja0ludDMyKHJtLCAwLCA4KTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBJZiB4IGlzIG5vdCBmaW5pdGUsIHJldHVybiB4IGlmIHkgaXMgbm90IE5hTiwgZWxzZSBOYU4uXHJcbiAgICBpZiAoIXguZCkgcmV0dXJuIHkucyA/IHggOiB5O1xyXG5cclxuICAgIC8vIElmIHkgaXMgbm90IGZpbml0ZSwgcmV0dXJuIEluZmluaXR5IHdpdGggdGhlIHNpZ24gb2YgeCBpZiB5IGlzIEluZmluaXR5LCBlbHNlIE5hTi5cclxuICAgIGlmICgheS5kKSB7XHJcbiAgICAgIGlmICh5LnMpIHkucyA9IHgucztcclxuICAgICAgcmV0dXJuIHk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvLyBJZiB5IGlzIG5vdCB6ZXJvLCBjYWxjdWxhdGUgdGhlIG5lYXJlc3QgbXVsdGlwbGUgb2YgeSB0byB4LlxyXG4gIGlmICh5LmRbMF0pIHtcclxuICAgIGV4dGVybmFsID0gZmFsc2U7XHJcbiAgICB4ID0gZGl2aWRlKHgsIHksIDAsIHJtLCAxKS50aW1lcyh5KTtcclxuICAgIGV4dGVybmFsID0gdHJ1ZTtcclxuICAgIGZpbmFsaXNlKHgpO1xyXG5cclxuICAvLyBJZiB5IGlzIHplcm8sIHJldHVybiB6ZXJvIHdpdGggdGhlIHNpZ24gb2YgeC5cclxuICB9IGVsc2Uge1xyXG4gICAgeS5zID0geC5zO1xyXG4gICAgeCA9IHk7XHJcbiAgfVxyXG5cclxuICByZXR1cm4geDtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gdGhlIHZhbHVlIG9mIHRoaXMgRGVjaW1hbCBjb252ZXJ0ZWQgdG8gYSBudW1iZXIgcHJpbWl0aXZlLlxyXG4gKiBaZXJvIGtlZXBzIGl0cyBzaWduLlxyXG4gKlxyXG4gKi9cclxuUC50b051bWJlciA9IGZ1bmN0aW9uICgpIHtcclxuICByZXR1cm4gK3RoaXM7XHJcbn07XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgc3RyaW5nIHJlcHJlc2VudGluZyB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsIGluIGJhc2UgOCwgcm91bmQgdG8gYHNkYCBzaWduaWZpY2FudFxyXG4gKiBkaWdpdHMgdXNpbmcgcm91bmRpbmcgbW9kZSBgcm1gLlxyXG4gKlxyXG4gKiBJZiB0aGUgb3B0aW9uYWwgYHNkYCBhcmd1bWVudCBpcyBwcmVzZW50IHRoZW4gcmV0dXJuIGJpbmFyeSBleHBvbmVudGlhbCBub3RhdGlvbi5cclxuICpcclxuICogW3NkXSB7bnVtYmVyfSBTaWduaWZpY2FudCBkaWdpdHMuIEludGVnZXIsIDEgdG8gTUFYX0RJR0lUUyBpbmNsdXNpdmUuXHJcbiAqIFtybV0ge251bWJlcn0gUm91bmRpbmcgbW9kZS4gSW50ZWdlciwgMCB0byA4IGluY2x1c2l2ZS5cclxuICpcclxuICovXHJcblAudG9PY3RhbCA9IGZ1bmN0aW9uIChzZCwgcm0pIHtcclxuICByZXR1cm4gdG9TdHJpbmdCaW5hcnkodGhpcywgOCwgc2QsIHJtKTtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsIHJhaXNlZCB0byB0aGUgcG93ZXIgYHlgLCByb3VuZGVkXHJcbiAqIHRvIGBwcmVjaXNpb25gIHNpZ25pZmljYW50IGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqIEVDTUFTY3JpcHQgY29tcGxpYW50LlxyXG4gKlxyXG4gKiAgIHBvdyh4LCBOYU4pICAgICAgICAgICAgICAgICAgICAgICAgICAgPSBOYU5cclxuICogICBwb3coeCwgwrEwKSAgICAgICAgICAgICAgICAgICAgICAgICAgICA9IDFcclxuXHJcbiAqICAgcG93KE5hTiwgbm9uLXplcm8pICAgICAgICAgICAgICAgICAgICA9IE5hTlxyXG4gKiAgIHBvdyhhYnMoeCkgPiAxLCArSW5maW5pdHkpICAgICAgICAgICAgPSArSW5maW5pdHlcclxuICogICBwb3coYWJzKHgpID4gMSwgLUluZmluaXR5KSAgICAgICAgICAgID0gKzBcclxuICogICBwb3coYWJzKHgpID09IDEsIMKxSW5maW5pdHkpICAgICAgICAgICA9IE5hTlxyXG4gKiAgIHBvdyhhYnMoeCkgPCAxLCArSW5maW5pdHkpICAgICAgICAgICAgPSArMFxyXG4gKiAgIHBvdyhhYnMoeCkgPCAxLCAtSW5maW5pdHkpICAgICAgICAgICAgPSArSW5maW5pdHlcclxuICogICBwb3coK0luZmluaXR5LCB5ID4gMCkgICAgICAgICAgICAgICAgID0gK0luZmluaXR5XHJcbiAqICAgcG93KCtJbmZpbml0eSwgeSA8IDApICAgICAgICAgICAgICAgICA9ICswXHJcbiAqICAgcG93KC1JbmZpbml0eSwgb2RkIGludGVnZXIgPiAwKSAgICAgICA9IC1JbmZpbml0eVxyXG4gKiAgIHBvdygtSW5maW5pdHksIGV2ZW4gaW50ZWdlciA+IDApICAgICAgPSArSW5maW5pdHlcclxuICogICBwb3coLUluZmluaXR5LCBvZGQgaW50ZWdlciA8IDApICAgICAgID0gLTBcclxuICogICBwb3coLUluZmluaXR5LCBldmVuIGludGVnZXIgPCAwKSAgICAgID0gKzBcclxuICogICBwb3coKzAsIHkgPiAwKSAgICAgICAgICAgICAgICAgICAgICAgID0gKzBcclxuICogICBwb3coKzAsIHkgPCAwKSAgICAgICAgICAgICAgICAgICAgICAgID0gK0luZmluaXR5XHJcbiAqICAgcG93KC0wLCBvZGQgaW50ZWdlciA+IDApICAgICAgICAgICAgICA9IC0wXHJcbiAqICAgcG93KC0wLCBldmVuIGludGVnZXIgPiAwKSAgICAgICAgICAgICA9ICswXHJcbiAqICAgcG93KC0wLCBvZGQgaW50ZWdlciA8IDApICAgICAgICAgICAgICA9IC1JbmZpbml0eVxyXG4gKiAgIHBvdygtMCwgZXZlbiBpbnRlZ2VyIDwgMCkgICAgICAgICAgICAgPSArSW5maW5pdHlcclxuICogICBwb3coZmluaXRlIHggPCAwLCBmaW5pdGUgbm9uLWludGVnZXIpID0gTmFOXHJcbiAqXHJcbiAqIEZvciBub24taW50ZWdlciBvciB2ZXJ5IGxhcmdlIGV4cG9uZW50cyBwb3coeCwgeSkgaXMgY2FsY3VsYXRlZCB1c2luZ1xyXG4gKlxyXG4gKiAgIHheeSA9IGV4cCh5KmxuKHgpKVxyXG4gKlxyXG4gKiBBc3N1bWluZyB0aGUgZmlyc3QgMTUgcm91bmRpbmcgZGlnaXRzIGFyZSBlYWNoIGVxdWFsbHkgbGlrZWx5IHRvIGJlIGFueSBkaWdpdCAwLTksIHRoZVxyXG4gKiBwcm9iYWJpbGl0eSBvZiBhbiBpbmNvcnJlY3RseSByb3VuZGVkIHJlc3VsdFxyXG4gKiBQKFs0OV05ezE0fSB8IFs1MF0wezE0fSkgPSAyICogMC4yICogMTBeLTE0ID0gNGUtMTUgPSAxLzIuNWUrMTRcclxuICogaS5lLiAxIGluIDI1MCwwMDAsMDAwLDAwMCwwMDBcclxuICpcclxuICogSWYgYSByZXN1bHQgaXMgaW5jb3JyZWN0bHkgcm91bmRlZCB0aGUgbWF4aW11bSBlcnJvciB3aWxsIGJlIDEgdWxwICh1bml0IGluIGxhc3QgcGxhY2UpLlxyXG4gKlxyXG4gKiB5IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfSBUaGUgcG93ZXIgdG8gd2hpY2ggdG8gcmFpc2UgdGhpcyBEZWNpbWFsLlxyXG4gKlxyXG4gKi9cclxuUC50b1Bvd2VyID0gUC5wb3cgPSBmdW5jdGlvbiAoeSkge1xyXG4gIHZhciBlLCBrLCBwciwgciwgcm0sIHMsXHJcbiAgICB4ID0gdGhpcyxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yLFxyXG4gICAgeW4gPSArKHkgPSBuZXcgQ3Rvcih5KSk7XHJcblxyXG4gIC8vIEVpdGhlciDCsUluZmluaXR5LCBOYU4gb3IgwrEwP1xyXG4gIGlmICgheC5kIHx8ICF5LmQgfHwgIXguZFswXSB8fCAheS5kWzBdKSByZXR1cm4gbmV3IEN0b3IobWF0aHBvdygreCwgeW4pKTtcclxuXHJcbiAgeCA9IG5ldyBDdG9yKHgpO1xyXG5cclxuICBpZiAoeC5lcSgxKSkgcmV0dXJuIHg7XHJcblxyXG4gIHByID0gQ3Rvci5wcmVjaXNpb247XHJcbiAgcm0gPSBDdG9yLnJvdW5kaW5nO1xyXG5cclxuICBpZiAoeS5lcSgxKSkgcmV0dXJuIGZpbmFsaXNlKHgsIHByLCBybSk7XHJcblxyXG4gIC8vIHkgZXhwb25lbnRcclxuICBlID0gbWF0aGZsb29yKHkuZSAvIExPR19CQVNFKTtcclxuXHJcbiAgLy8gSWYgeSBpcyBhIHNtYWxsIGludGVnZXIgdXNlIHRoZSAnZXhwb25lbnRpYXRpb24gYnkgc3F1YXJpbmcnIGFsZ29yaXRobS5cclxuICBpZiAoZSA+PSB5LmQubGVuZ3RoIC0gMSAmJiAoayA9IHluIDwgMCA/IC15biA6IHluKSA8PSBNQVhfU0FGRV9JTlRFR0VSKSB7XHJcbiAgICByID0gaW50UG93KEN0b3IsIHgsIGssIHByKTtcclxuICAgIHJldHVybiB5LnMgPCAwID8gbmV3IEN0b3IoMSkuZGl2KHIpIDogZmluYWxpc2UociwgcHIsIHJtKTtcclxuICB9XHJcblxyXG4gIHMgPSB4LnM7XHJcblxyXG4gIC8vIGlmIHggaXMgbmVnYXRpdmVcclxuICBpZiAocyA8IDApIHtcclxuXHJcbiAgICAvLyBpZiB5IGlzIG5vdCBhbiBpbnRlZ2VyXHJcbiAgICBpZiAoZSA8IHkuZC5sZW5ndGggLSAxKSByZXR1cm4gbmV3IEN0b3IoTmFOKTtcclxuXHJcbiAgICAvLyBSZXN1bHQgaXMgcG9zaXRpdmUgaWYgeCBpcyBuZWdhdGl2ZSBhbmQgdGhlIGxhc3QgZGlnaXQgb2YgaW50ZWdlciB5IGlzIGV2ZW4uXHJcbiAgICBpZiAoKHkuZFtlXSAmIDEpID09IDApIHMgPSAxO1xyXG5cclxuICAgIC8vIGlmIHguZXEoLTEpXHJcbiAgICBpZiAoeC5lID09IDAgJiYgeC5kWzBdID09IDEgJiYgeC5kLmxlbmd0aCA9PSAxKSB7XHJcbiAgICAgIHgucyA9IHM7XHJcbiAgICAgIHJldHVybiB4O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8gRXN0aW1hdGUgcmVzdWx0IGV4cG9uZW50LlxyXG4gIC8vIHheeSA9IDEwXmUsICB3aGVyZSBlID0geSAqIGxvZzEwKHgpXHJcbiAgLy8gbG9nMTAoeCkgPSBsb2cxMCh4X3NpZ25pZmljYW5kKSArIHhfZXhwb25lbnRcclxuICAvLyBsb2cxMCh4X3NpZ25pZmljYW5kKSA9IGxuKHhfc2lnbmlmaWNhbmQpIC8gbG4oMTApXHJcbiAgayA9IG1hdGhwb3coK3gsIHluKTtcclxuICBlID0gayA9PSAwIHx8ICFpc0Zpbml0ZShrKVxyXG4gICAgPyBtYXRoZmxvb3IoeW4gKiAoTWF0aC5sb2coJzAuJyArIGRpZ2l0c1RvU3RyaW5nKHguZCkpIC8gTWF0aC5MTjEwICsgeC5lICsgMSkpXHJcbiAgICA6IG5ldyBDdG9yKGsgKyAnJykuZTtcclxuXHJcbiAgLy8gRXhwb25lbnQgZXN0aW1hdGUgbWF5IGJlIGluY29ycmVjdCBlLmcuIHg6IDAuOTk5OTk5OTk5OTk5OTk5OTk5LCB5OiAyLjI5LCBlOiAwLCByLmU6IC0xLlxyXG5cclxuICAvLyBPdmVyZmxvdy91bmRlcmZsb3c/XHJcbiAgaWYgKGUgPiBDdG9yLm1heEUgKyAxIHx8IGUgPCBDdG9yLm1pbkUgLSAxKSByZXR1cm4gbmV3IEN0b3IoZSA+IDAgPyBzIC8gMCA6IDApO1xyXG5cclxuICBleHRlcm5hbCA9IGZhbHNlO1xyXG4gIEN0b3Iucm91bmRpbmcgPSB4LnMgPSAxO1xyXG5cclxuICAvLyBFc3RpbWF0ZSB0aGUgZXh0cmEgZ3VhcmQgZGlnaXRzIG5lZWRlZCB0byBlbnN1cmUgZml2ZSBjb3JyZWN0IHJvdW5kaW5nIGRpZ2l0cyBmcm9tXHJcbiAgLy8gbmF0dXJhbExvZ2FyaXRobSh4KS4gRXhhbXBsZSBvZiBmYWlsdXJlIHdpdGhvdXQgdGhlc2UgZXh0cmEgZGlnaXRzIChwcmVjaXNpb246IDEwKTpcclxuICAvLyBuZXcgRGVjaW1hbCgyLjMyNDU2KS5wb3coJzIwODc5ODc0MzY1MzQ1NjYuNDY0MTEnKVxyXG4gIC8vIHNob3VsZCBiZSAxLjE2MjM3NzgyM2UrNzY0OTE0OTA1MTczODE1LCBidXQgaXMgMS4xNjIzNTU4MjNlKzc2NDkxNDkwNTE3MzgxNVxyXG4gIGsgPSBNYXRoLm1pbigxMiwgKGUgKyAnJykubGVuZ3RoKTtcclxuXHJcbiAgLy8gciA9IHheeSA9IGV4cCh5KmxuKHgpKVxyXG4gIHIgPSBuYXR1cmFsRXhwb25lbnRpYWwoeS50aW1lcyhuYXR1cmFsTG9nYXJpdGhtKHgsIHByICsgaykpLCBwcik7XHJcblxyXG4gIC8vIHIgbWF5IGJlIEluZmluaXR5LCBlLmcuICgwLjk5OTk5OTk5OTk5OTk5OTkpLnBvdygtMWUrNDApXHJcbiAgaWYgKHIuZCkge1xyXG5cclxuICAgIC8vIFRydW5jYXRlIHRvIHRoZSByZXF1aXJlZCBwcmVjaXNpb24gcGx1cyBmaXZlIHJvdW5kaW5nIGRpZ2l0cy5cclxuICAgIHIgPSBmaW5hbGlzZShyLCBwciArIDUsIDEpO1xyXG5cclxuICAgIC8vIElmIHRoZSByb3VuZGluZyBkaWdpdHMgYXJlIFs0OV05OTk5IG9yIFs1MF0wMDAwIGluY3JlYXNlIHRoZSBwcmVjaXNpb24gYnkgMTAgYW5kIHJlY2FsY3VsYXRlXHJcbiAgICAvLyB0aGUgcmVzdWx0LlxyXG4gICAgaWYgKGNoZWNrUm91bmRpbmdEaWdpdHMoci5kLCBwciwgcm0pKSB7XHJcbiAgICAgIGUgPSBwciArIDEwO1xyXG5cclxuICAgICAgLy8gVHJ1bmNhdGUgdG8gdGhlIGluY3JlYXNlZCBwcmVjaXNpb24gcGx1cyBmaXZlIHJvdW5kaW5nIGRpZ2l0cy5cclxuICAgICAgciA9IGZpbmFsaXNlKG5hdHVyYWxFeHBvbmVudGlhbCh5LnRpbWVzKG5hdHVyYWxMb2dhcml0aG0oeCwgZSArIGspKSwgZSksIGUgKyA1LCAxKTtcclxuXHJcbiAgICAgIC8vIENoZWNrIGZvciAxNCBuaW5lcyBmcm9tIHRoZSAybmQgcm91bmRpbmcgZGlnaXQgKHRoZSBmaXJzdCByb3VuZGluZyBkaWdpdCBtYXkgYmUgNCBvciA5KS5cclxuICAgICAgaWYgKCtkaWdpdHNUb1N0cmluZyhyLmQpLnNsaWNlKHByICsgMSwgcHIgKyAxNSkgKyAxID09IDFlMTQpIHtcclxuICAgICAgICByID0gZmluYWxpc2UociwgcHIgKyAxLCAwKTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgci5zID0gcztcclxuICBleHRlcm5hbCA9IHRydWU7XHJcbiAgQ3Rvci5yb3VuZGluZyA9IHJtO1xyXG5cclxuICByZXR1cm4gZmluYWxpc2UociwgcHIsIHJtKTtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBzdHJpbmcgcmVwcmVzZW50aW5nIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwgcm91bmRlZCB0byBgc2RgIHNpZ25pZmljYW50IGRpZ2l0c1xyXG4gKiB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqIFJldHVybiBleHBvbmVudGlhbCBub3RhdGlvbiBpZiBgc2RgIGlzIGxlc3MgdGhhbiB0aGUgbnVtYmVyIG9mIGRpZ2l0cyBuZWNlc3NhcnkgdG8gcmVwcmVzZW50XHJcbiAqIHRoZSBpbnRlZ2VyIHBhcnQgb2YgdGhlIHZhbHVlIGluIG5vcm1hbCBub3RhdGlvbi5cclxuICpcclxuICogW3NkXSB7bnVtYmVyfSBTaWduaWZpY2FudCBkaWdpdHMuIEludGVnZXIsIDEgdG8gTUFYX0RJR0lUUyBpbmNsdXNpdmUuXHJcbiAqIFtybV0ge251bWJlcn0gUm91bmRpbmcgbW9kZS4gSW50ZWdlciwgMCB0byA4IGluY2x1c2l2ZS5cclxuICpcclxuICovXHJcblAudG9QcmVjaXNpb24gPSBmdW5jdGlvbiAoc2QsIHJtKSB7XHJcbiAgdmFyIHN0cixcclxuICAgIHggPSB0aGlzLFxyXG4gICAgQ3RvciA9IHguY29uc3RydWN0b3I7XHJcblxyXG4gIGlmIChzZCA9PT0gdm9pZCAwKSB7XHJcbiAgICBzdHIgPSBmaW5pdGVUb1N0cmluZyh4LCB4LmUgPD0gQ3Rvci50b0V4cE5lZyB8fCB4LmUgPj0gQ3Rvci50b0V4cFBvcyk7XHJcbiAgfSBlbHNlIHtcclxuICAgIGNoZWNrSW50MzIoc2QsIDEsIE1BWF9ESUdJVFMpO1xyXG5cclxuICAgIGlmIChybSA9PT0gdm9pZCAwKSBybSA9IEN0b3Iucm91bmRpbmc7XHJcbiAgICBlbHNlIGNoZWNrSW50MzIocm0sIDAsIDgpO1xyXG5cclxuICAgIHggPSBmaW5hbGlzZShuZXcgQ3Rvcih4KSwgc2QsIHJtKTtcclxuICAgIHN0ciA9IGZpbml0ZVRvU3RyaW5nKHgsIHNkIDw9IHguZSB8fCB4LmUgPD0gQ3Rvci50b0V4cE5lZywgc2QpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHguaXNOZWcoKSAmJiAheC5pc1plcm8oKSA/ICctJyArIHN0ciA6IHN0cjtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgdmFsdWUgb2YgdGhpcyBEZWNpbWFsIHJvdW5kZWQgdG8gYSBtYXhpbXVtIG9mIGBzZGBcclxuICogc2lnbmlmaWNhbnQgZGlnaXRzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJtYCwgb3IgdG8gYHByZWNpc2lvbmAgYW5kIGByb3VuZGluZ2AgcmVzcGVjdGl2ZWx5IGlmXHJcbiAqIG9taXR0ZWQuXHJcbiAqXHJcbiAqIFtzZF0ge251bWJlcn0gU2lnbmlmaWNhbnQgZGlnaXRzLiBJbnRlZ2VyLCAxIHRvIE1BWF9ESUdJVFMgaW5jbHVzaXZlLlxyXG4gKiBbcm1dIHtudW1iZXJ9IFJvdW5kaW5nIG1vZGUuIEludGVnZXIsIDAgdG8gOCBpbmNsdXNpdmUuXHJcbiAqXHJcbiAqICd0b1NEKCkgZGlnaXRzIG91dCBvZiByYW5nZToge3NkfSdcclxuICogJ3RvU0QoKSBkaWdpdHMgbm90IGFuIGludGVnZXI6IHtzZH0nXHJcbiAqICd0b1NEKCkgcm91bmRpbmcgbW9kZSBub3QgYW4gaW50ZWdlcjoge3JtfSdcclxuICogJ3RvU0QoKSByb3VuZGluZyBtb2RlIG91dCBvZiByYW5nZToge3JtfSdcclxuICpcclxuICovXHJcblAudG9TaWduaWZpY2FudERpZ2l0cyA9IFAudG9TRCA9IGZ1bmN0aW9uIChzZCwgcm0pIHtcclxuICB2YXIgeCA9IHRoaXMsXHJcbiAgICBDdG9yID0geC5jb25zdHJ1Y3RvcjtcclxuXHJcbiAgaWYgKHNkID09PSB2b2lkIDApIHtcclxuICAgIHNkID0gQ3Rvci5wcmVjaXNpb247XHJcbiAgICBybSA9IEN0b3Iucm91bmRpbmc7XHJcbiAgfSBlbHNlIHtcclxuICAgIGNoZWNrSW50MzIoc2QsIDEsIE1BWF9ESUdJVFMpO1xyXG5cclxuICAgIGlmIChybSA9PT0gdm9pZCAwKSBybSA9IEN0b3Iucm91bmRpbmc7XHJcbiAgICBlbHNlIGNoZWNrSW50MzIocm0sIDAsIDgpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGZpbmFsaXNlKG5ldyBDdG9yKHgpLCBzZCwgcm0pO1xyXG59O1xyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIHN0cmluZyByZXByZXNlbnRpbmcgdGhlIHZhbHVlIG9mIHRoaXMgRGVjaW1hbC5cclxuICpcclxuICogUmV0dXJuIGV4cG9uZW50aWFsIG5vdGF0aW9uIGlmIHRoaXMgRGVjaW1hbCBoYXMgYSBwb3NpdGl2ZSBleHBvbmVudCBlcXVhbCB0byBvciBncmVhdGVyIHRoYW5cclxuICogYHRvRXhwUG9zYCwgb3IgYSBuZWdhdGl2ZSBleHBvbmVudCBlcXVhbCB0byBvciBsZXNzIHRoYW4gYHRvRXhwTmVnYC5cclxuICpcclxuICovXHJcblAudG9TdHJpbmcgPSBmdW5jdGlvbiAoKSB7XHJcbiAgdmFyIHggPSB0aGlzLFxyXG4gICAgQ3RvciA9IHguY29uc3RydWN0b3IsXHJcbiAgICBzdHIgPSBmaW5pdGVUb1N0cmluZyh4LCB4LmUgPD0gQ3Rvci50b0V4cE5lZyB8fCB4LmUgPj0gQ3Rvci50b0V4cFBvcyk7XHJcblxyXG4gIHJldHVybiB4LmlzTmVnKCkgJiYgIXguaXNaZXJvKCkgPyAnLScgKyBzdHIgOiBzdHI7XHJcbn07XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIHZhbHVlIG9mIHRoaXMgRGVjaW1hbCB0cnVuY2F0ZWQgdG8gYSB3aG9sZSBudW1iZXIuXHJcbiAqXHJcbiAqL1xyXG5QLnRydW5jYXRlZCA9IFAudHJ1bmMgPSBmdW5jdGlvbiAoKSB7XHJcbiAgcmV0dXJuIGZpbmFsaXNlKG5ldyB0aGlzLmNvbnN0cnVjdG9yKHRoaXMpLCB0aGlzLmUgKyAxLCAxKTtcclxufTtcclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBzdHJpbmcgcmVwcmVzZW50aW5nIHRoZSB2YWx1ZSBvZiB0aGlzIERlY2ltYWwuXHJcbiAqIFVubGlrZSBgdG9TdHJpbmdgLCBuZWdhdGl2ZSB6ZXJvIHdpbGwgaW5jbHVkZSB0aGUgbWludXMgc2lnbi5cclxuICpcclxuICovXHJcblAudmFsdWVPZiA9IFAudG9KU09OID0gZnVuY3Rpb24gKCkge1xyXG4gIHZhciB4ID0gdGhpcyxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yLFxyXG4gICAgc3RyID0gZmluaXRlVG9TdHJpbmcoeCwgeC5lIDw9IEN0b3IudG9FeHBOZWcgfHwgeC5lID49IEN0b3IudG9FeHBQb3MpO1xyXG5cclxuICByZXR1cm4geC5pc05lZygpID8gJy0nICsgc3RyIDogc3RyO1xyXG59O1xyXG5cclxuXHJcbi8vIEhlbHBlciBmdW5jdGlvbnMgZm9yIERlY2ltYWwucHJvdG90eXBlIChQKSBhbmQvb3IgRGVjaW1hbCBtZXRob2RzLCBhbmQgdGhlaXIgY2FsbGVycy5cclxuXHJcblxyXG4vKlxyXG4gKiAgZGlnaXRzVG9TdHJpbmcgICAgICAgICAgIFAuY3ViZVJvb3QsIFAubG9nYXJpdGhtLCBQLnNxdWFyZVJvb3QsIFAudG9GcmFjdGlvbiwgUC50b1Bvd2VyLFxyXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgIGZpbml0ZVRvU3RyaW5nLCBuYXR1cmFsRXhwb25lbnRpYWwsIG5hdHVyYWxMb2dhcml0aG1cclxuICogIGNoZWNrSW50MzIgICAgICAgICAgICAgICBQLnRvRGVjaW1hbFBsYWNlcywgUC50b0V4cG9uZW50aWFsLCBQLnRvRml4ZWQsIFAudG9OZWFyZXN0LFxyXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgIFAudG9QcmVjaXNpb24sIFAudG9TaWduaWZpY2FudERpZ2l0cywgdG9TdHJpbmdCaW5hcnksIHJhbmRvbVxyXG4gKiAgY2hlY2tSb3VuZGluZ0RpZ2l0cyAgICAgIFAubG9nYXJpdGhtLCBQLnRvUG93ZXIsIG5hdHVyYWxFeHBvbmVudGlhbCwgbmF0dXJhbExvZ2FyaXRobVxyXG4gKiAgY29udmVydEJhc2UgICAgICAgICAgICAgIHRvU3RyaW5nQmluYXJ5LCBwYXJzZU90aGVyXHJcbiAqICBjb3MgICAgICAgICAgICAgICAgICAgICAgUC5jb3NcclxuICogIGRpdmlkZSAgICAgICAgICAgICAgICAgICBQLmF0YW5oLCBQLmN1YmVSb290LCBQLmRpdmlkZWRCeSwgUC5kaXZpZGVkVG9JbnRlZ2VyQnksXHJcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgUC5sb2dhcml0aG0sIFAubW9kdWxvLCBQLnNxdWFyZVJvb3QsIFAudGFuLCBQLnRhbmgsIFAudG9GcmFjdGlvbixcclxuICogICAgICAgICAgICAgICAgICAgICAgICAgICBQLnRvTmVhcmVzdCwgdG9TdHJpbmdCaW5hcnksIG5hdHVyYWxFeHBvbmVudGlhbCwgbmF0dXJhbExvZ2FyaXRobSxcclxuICogICAgICAgICAgICAgICAgICAgICAgICAgICB0YXlsb3JTZXJpZXMsIGF0YW4yLCBwYXJzZU90aGVyXHJcbiAqICBmaW5hbGlzZSAgICAgICAgICAgICAgICAgUC5hYnNvbHV0ZVZhbHVlLCBQLmF0YW4sIFAuYXRhbmgsIFAuY2VpbCwgUC5jb3MsIFAuY29zaCxcclxuICogICAgICAgICAgICAgICAgICAgICAgICAgICBQLmN1YmVSb290LCBQLmRpdmlkZWRUb0ludGVnZXJCeSwgUC5mbG9vciwgUC5sb2dhcml0aG0sIFAubWludXMsXHJcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgUC5tb2R1bG8sIFAubmVnYXRlZCwgUC5wbHVzLCBQLnJvdW5kLCBQLnNpbiwgUC5zaW5oLCBQLnNxdWFyZVJvb3QsXHJcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgUC50YW4sIFAudGltZXMsIFAudG9EZWNpbWFsUGxhY2VzLCBQLnRvRXhwb25lbnRpYWwsIFAudG9GaXhlZCxcclxuICogICAgICAgICAgICAgICAgICAgICAgICAgICBQLnRvTmVhcmVzdCwgUC50b1Bvd2VyLCBQLnRvUHJlY2lzaW9uLCBQLnRvU2lnbmlmaWNhbnREaWdpdHMsXHJcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgUC50cnVuY2F0ZWQsIGRpdmlkZSwgZ2V0TG4xMCwgZ2V0UGksIG5hdHVyYWxFeHBvbmVudGlhbCxcclxuICogICAgICAgICAgICAgICAgICAgICAgICAgICBuYXR1cmFsTG9nYXJpdGhtLCBjZWlsLCBmbG9vciwgcm91bmQsIHRydW5jXHJcbiAqICBmaW5pdGVUb1N0cmluZyAgICAgICAgICAgUC50b0V4cG9uZW50aWFsLCBQLnRvRml4ZWQsIFAudG9QcmVjaXNpb24sIFAudG9TdHJpbmcsIFAudmFsdWVPZixcclxuICogICAgICAgICAgICAgICAgICAgICAgICAgICB0b1N0cmluZ0JpbmFyeVxyXG4gKiAgZ2V0QmFzZTEwRXhwb25lbnQgICAgICAgIFAubWludXMsIFAucGx1cywgUC50aW1lcywgcGFyc2VPdGhlclxyXG4gKiAgZ2V0TG4xMCAgICAgICAgICAgICAgICAgIFAubG9nYXJpdGhtLCBuYXR1cmFsTG9nYXJpdGhtXHJcbiAqICBnZXRQaSAgICAgICAgICAgICAgICAgICAgUC5hY29zLCBQLmFzaW4sIFAuYXRhbiwgdG9MZXNzVGhhbkhhbGZQaSwgYXRhbjJcclxuICogIGdldFByZWNpc2lvbiAgICAgICAgICAgICBQLnByZWNpc2lvbiwgUC50b0ZyYWN0aW9uXHJcbiAqICBnZXRaZXJvU3RyaW5nICAgICAgICAgICAgZGlnaXRzVG9TdHJpbmcsIGZpbml0ZVRvU3RyaW5nXHJcbiAqICBpbnRQb3cgICAgICAgICAgICAgICAgICAgUC50b1Bvd2VyLCBwYXJzZU90aGVyXHJcbiAqICBpc09kZCAgICAgICAgICAgICAgICAgICAgdG9MZXNzVGhhbkhhbGZQaVxyXG4gKiAgbWF4T3JNaW4gICAgICAgICAgICAgICAgIG1heCwgbWluXHJcbiAqICBuYXR1cmFsRXhwb25lbnRpYWwgICAgICAgUC5uYXR1cmFsRXhwb25lbnRpYWwsIFAudG9Qb3dlclxyXG4gKiAgbmF0dXJhbExvZ2FyaXRobSAgICAgICAgIFAuYWNvc2gsIFAuYXNpbmgsIFAuYXRhbmgsIFAubG9nYXJpdGhtLCBQLm5hdHVyYWxMb2dhcml0aG0sXHJcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgUC50b1Bvd2VyLCBuYXR1cmFsRXhwb25lbnRpYWxcclxuICogIG5vbkZpbml0ZVRvU3RyaW5nICAgICAgICBmaW5pdGVUb1N0cmluZywgdG9TdHJpbmdCaW5hcnlcclxuICogIHBhcnNlRGVjaW1hbCAgICAgICAgICAgICBEZWNpbWFsXHJcbiAqICBwYXJzZU90aGVyICAgICAgICAgICAgICAgRGVjaW1hbFxyXG4gKiAgc2luICAgICAgICAgICAgICAgICAgICAgIFAuc2luXHJcbiAqICB0YXlsb3JTZXJpZXMgICAgICAgICAgICAgUC5jb3NoLCBQLnNpbmgsIGNvcywgc2luXHJcbiAqICB0b0xlc3NUaGFuSGFsZlBpICAgICAgICAgUC5jb3MsIFAuc2luXHJcbiAqICB0b1N0cmluZ0JpbmFyeSAgICAgICAgICAgUC50b0JpbmFyeSwgUC50b0hleGFkZWNpbWFsLCBQLnRvT2N0YWxcclxuICogIHRydW5jYXRlICAgICAgICAgICAgICAgICBpbnRQb3dcclxuICpcclxuICogIFRocm93czogICAgICAgICAgICAgICAgICBQLmxvZ2FyaXRobSwgUC5wcmVjaXNpb24sIFAudG9GcmFjdGlvbiwgY2hlY2tJbnQzMiwgZ2V0TG4xMCwgZ2V0UGksXHJcbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgbmF0dXJhbExvZ2FyaXRobSwgY29uZmlnLCBwYXJzZU90aGVyLCByYW5kb20sIERlY2ltYWxcclxuICovXHJcblxyXG5cclxuZnVuY3Rpb24gZGlnaXRzVG9TdHJpbmcoZCkge1xyXG4gIHZhciBpLCBrLCB3cyxcclxuICAgIGluZGV4T2ZMYXN0V29yZCA9IGQubGVuZ3RoIC0gMSxcclxuICAgIHN0ciA9ICcnLFxyXG4gICAgdyA9IGRbMF07XHJcblxyXG4gIGlmIChpbmRleE9mTGFzdFdvcmQgPiAwKSB7XHJcbiAgICBzdHIgKz0gdztcclxuICAgIGZvciAoaSA9IDE7IGkgPCBpbmRleE9mTGFzdFdvcmQ7IGkrKykge1xyXG4gICAgICB3cyA9IGRbaV0gKyAnJztcclxuICAgICAgayA9IExPR19CQVNFIC0gd3MubGVuZ3RoO1xyXG4gICAgICBpZiAoaykgc3RyICs9IGdldFplcm9TdHJpbmcoayk7XHJcbiAgICAgIHN0ciArPSB3cztcclxuICAgIH1cclxuXHJcbiAgICB3ID0gZFtpXTtcclxuICAgIHdzID0gdyArICcnO1xyXG4gICAgayA9IExPR19CQVNFIC0gd3MubGVuZ3RoO1xyXG4gICAgaWYgKGspIHN0ciArPSBnZXRaZXJvU3RyaW5nKGspO1xyXG4gIH0gZWxzZSBpZiAodyA9PT0gMCkge1xyXG4gICAgcmV0dXJuICcwJztcclxuICB9XHJcblxyXG4gIC8vIFJlbW92ZSB0cmFpbGluZyB6ZXJvcyBvZiBsYXN0IHcuXHJcbiAgZm9yICg7IHcgJSAxMCA9PT0gMDspIHcgLz0gMTA7XHJcblxyXG4gIHJldHVybiBzdHIgKyB3O1xyXG59XHJcblxyXG5cclxuZnVuY3Rpb24gY2hlY2tJbnQzMihpLCBtaW4sIG1heCkge1xyXG4gIGlmIChpICE9PSB+fmkgfHwgaSA8IG1pbiB8fCBpID4gbWF4KSB7XHJcbiAgICB0aHJvdyBFcnJvcihpbnZhbGlkQXJndW1lbnQgKyBpKTtcclxuICB9XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBDaGVjayA1IHJvdW5kaW5nIGRpZ2l0cyBpZiBgcmVwZWF0aW5nYCBpcyBudWxsLCA0IG90aGVyd2lzZS5cclxuICogYHJlcGVhdGluZyA9PSBudWxsYCBpZiBjYWxsZXIgaXMgYGxvZ2Agb3IgYHBvd2AsXHJcbiAqIGByZXBlYXRpbmcgIT0gbnVsbGAgaWYgY2FsbGVyIGlzIGBuYXR1cmFsTG9nYXJpdGhtYCBvciBgbmF0dXJhbEV4cG9uZW50aWFsYC5cclxuICovXHJcbmZ1bmN0aW9uIGNoZWNrUm91bmRpbmdEaWdpdHMoZCwgaSwgcm0sIHJlcGVhdGluZykge1xyXG4gIHZhciBkaSwgaywgciwgcmQ7XHJcblxyXG4gIC8vIEdldCB0aGUgbGVuZ3RoIG9mIHRoZSBmaXJzdCB3b3JkIG9mIHRoZSBhcnJheSBkLlxyXG4gIGZvciAoayA9IGRbMF07IGsgPj0gMTA7IGsgLz0gMTApIC0taTtcclxuXHJcbiAgLy8gSXMgdGhlIHJvdW5kaW5nIGRpZ2l0IGluIHRoZSBmaXJzdCB3b3JkIG9mIGQ/XHJcbiAgaWYgKC0taSA8IDApIHtcclxuICAgIGkgKz0gTE9HX0JBU0U7XHJcbiAgICBkaSA9IDA7XHJcbiAgfSBlbHNlIHtcclxuICAgIGRpID0gTWF0aC5jZWlsKChpICsgMSkgLyBMT0dfQkFTRSk7XHJcbiAgICBpICU9IExPR19CQVNFO1xyXG4gIH1cclxuXHJcbiAgLy8gaSBpcyB0aGUgaW5kZXggKDAgLSA2KSBvZiB0aGUgcm91bmRpbmcgZGlnaXQuXHJcbiAgLy8gRS5nLiBpZiB3aXRoaW4gdGhlIHdvcmQgMzQ4NzU2MyB0aGUgZmlyc3Qgcm91bmRpbmcgZGlnaXQgaXMgNSxcclxuICAvLyB0aGVuIGkgPSA0LCBrID0gMTAwMCwgcmQgPSAzNDg3NTYzICUgMTAwMCA9IDU2M1xyXG4gIGsgPSBtYXRocG93KDEwLCBMT0dfQkFTRSAtIGkpO1xyXG4gIHJkID0gZFtkaV0gJSBrIHwgMDtcclxuXHJcbiAgaWYgKHJlcGVhdGluZyA9PSBudWxsKSB7XHJcbiAgICBpZiAoaSA8IDMpIHtcclxuICAgICAgaWYgKGkgPT0gMCkgcmQgPSByZCAvIDEwMCB8IDA7XHJcbiAgICAgIGVsc2UgaWYgKGkgPT0gMSkgcmQgPSByZCAvIDEwIHwgMDtcclxuICAgICAgciA9IHJtIDwgNCAmJiByZCA9PSA5OTk5OSB8fCBybSA+IDMgJiYgcmQgPT0gNDk5OTkgfHwgcmQgPT0gNTAwMDAgfHwgcmQgPT0gMDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHIgPSAocm0gPCA0ICYmIHJkICsgMSA9PSBrIHx8IHJtID4gMyAmJiByZCArIDEgPT0gayAvIDIpICYmXHJcbiAgICAgICAgKGRbZGkgKyAxXSAvIGsgLyAxMDAgfCAwKSA9PSBtYXRocG93KDEwLCBpIC0gMikgLSAxIHx8XHJcbiAgICAgICAgICAocmQgPT0gayAvIDIgfHwgcmQgPT0gMCkgJiYgKGRbZGkgKyAxXSAvIGsgLyAxMDAgfCAwKSA9PSAwO1xyXG4gICAgfVxyXG4gIH0gZWxzZSB7XHJcbiAgICBpZiAoaSA8IDQpIHtcclxuICAgICAgaWYgKGkgPT0gMCkgcmQgPSByZCAvIDEwMDAgfCAwO1xyXG4gICAgICBlbHNlIGlmIChpID09IDEpIHJkID0gcmQgLyAxMDAgfCAwO1xyXG4gICAgICBlbHNlIGlmIChpID09IDIpIHJkID0gcmQgLyAxMCB8IDA7XHJcbiAgICAgIHIgPSAocmVwZWF0aW5nIHx8IHJtIDwgNCkgJiYgcmQgPT0gOTk5OSB8fCAhcmVwZWF0aW5nICYmIHJtID4gMyAmJiByZCA9PSA0OTk5O1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgciA9ICgocmVwZWF0aW5nIHx8IHJtIDwgNCkgJiYgcmQgKyAxID09IGsgfHxcclxuICAgICAgKCFyZXBlYXRpbmcgJiYgcm0gPiAzKSAmJiByZCArIDEgPT0gayAvIDIpICYmXHJcbiAgICAgICAgKGRbZGkgKyAxXSAvIGsgLyAxMDAwIHwgMCkgPT0gbWF0aHBvdygxMCwgaSAtIDMpIC0gMTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiByO1xyXG59XHJcblxyXG5cclxuLy8gQ29udmVydCBzdHJpbmcgb2YgYGJhc2VJbmAgdG8gYW4gYXJyYXkgb2YgbnVtYmVycyBvZiBgYmFzZU91dGAuXHJcbi8vIEVnLiBjb252ZXJ0QmFzZSgnMjU1JywgMTAsIDE2KSByZXR1cm5zIFsxNSwgMTVdLlxyXG4vLyBFZy4gY29udmVydEJhc2UoJ2ZmJywgMTYsIDEwKSByZXR1cm5zIFsyLCA1LCA1XS5cclxuZnVuY3Rpb24gY29udmVydEJhc2Uoc3RyLCBiYXNlSW4sIGJhc2VPdXQpIHtcclxuICB2YXIgaixcclxuICAgIGFyciA9IFswXSxcclxuICAgIGFyckwsXHJcbiAgICBpID0gMCxcclxuICAgIHN0ckwgPSBzdHIubGVuZ3RoO1xyXG5cclxuICBmb3IgKDsgaSA8IHN0ckw7KSB7XHJcbiAgICBmb3IgKGFyckwgPSBhcnIubGVuZ3RoOyBhcnJMLS07KSBhcnJbYXJyTF0gKj0gYmFzZUluO1xyXG4gICAgYXJyWzBdICs9IE5VTUVSQUxTLmluZGV4T2Yoc3RyLmNoYXJBdChpKyspKTtcclxuICAgIGZvciAoaiA9IDA7IGogPCBhcnIubGVuZ3RoOyBqKyspIHtcclxuICAgICAgaWYgKGFycltqXSA+IGJhc2VPdXQgLSAxKSB7XHJcbiAgICAgICAgaWYgKGFycltqICsgMV0gPT09IHZvaWQgMCkgYXJyW2ogKyAxXSA9IDA7XHJcbiAgICAgICAgYXJyW2ogKyAxXSArPSBhcnJbal0gLyBiYXNlT3V0IHwgMDtcclxuICAgICAgICBhcnJbal0gJT0gYmFzZU91dDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGFyci5yZXZlcnNlKCk7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBjb3MoeCkgPSAxIC0geF4yLzIhICsgeF40LzQhIC0gLi4uXHJcbiAqIHx4fCA8IHBpLzJcclxuICpcclxuICovXHJcbmZ1bmN0aW9uIGNvc2luZShDdG9yLCB4KSB7XHJcbiAgdmFyIGssIGxlbiwgeTtcclxuXHJcbiAgaWYgKHguaXNaZXJvKCkpIHJldHVybiB4O1xyXG5cclxuICAvLyBBcmd1bWVudCByZWR1Y3Rpb246IGNvcyg0eCkgPSA4Kihjb3NeNCh4KSAtIGNvc14yKHgpKSArIDFcclxuICAvLyBpLmUuIGNvcyh4KSA9IDgqKGNvc140KHgvNCkgLSBjb3NeMih4LzQpKSArIDFcclxuXHJcbiAgLy8gRXN0aW1hdGUgdGhlIG9wdGltdW0gbnVtYmVyIG9mIHRpbWVzIHRvIHVzZSB0aGUgYXJndW1lbnQgcmVkdWN0aW9uLlxyXG4gIGxlbiA9IHguZC5sZW5ndGg7XHJcbiAgaWYgKGxlbiA8IDMyKSB7XHJcbiAgICBrID0gTWF0aC5jZWlsKGxlbiAvIDMpO1xyXG4gICAgeSA9ICgxIC8gdGlueVBvdyg0LCBrKSkudG9TdHJpbmcoKTtcclxuICB9IGVsc2Uge1xyXG4gICAgayA9IDE2O1xyXG4gICAgeSA9ICcyLjMyODMwNjQzNjUzODY5NjI4OTA2MjVlLTEwJztcclxuICB9XHJcblxyXG4gIEN0b3IucHJlY2lzaW9uICs9IGs7XHJcblxyXG4gIHggPSB0YXlsb3JTZXJpZXMoQ3RvciwgMSwgeC50aW1lcyh5KSwgbmV3IEN0b3IoMSkpO1xyXG5cclxuICAvLyBSZXZlcnNlIGFyZ3VtZW50IHJlZHVjdGlvblxyXG4gIGZvciAodmFyIGkgPSBrOyBpLS07KSB7XHJcbiAgICB2YXIgY29zMnggPSB4LnRpbWVzKHgpO1xyXG4gICAgeCA9IGNvczJ4LnRpbWVzKGNvczJ4KS5taW51cyhjb3MyeCkudGltZXMoOCkucGx1cygxKTtcclxuICB9XHJcblxyXG4gIEN0b3IucHJlY2lzaW9uIC09IGs7XHJcblxyXG4gIHJldHVybiB4O1xyXG59XHJcblxyXG5cclxuLypcclxuICogUGVyZm9ybSBkaXZpc2lvbiBpbiB0aGUgc3BlY2lmaWVkIGJhc2UuXHJcbiAqL1xyXG52YXIgZGl2aWRlID0gKGZ1bmN0aW9uICgpIHtcclxuXHJcbiAgLy8gQXNzdW1lcyBub24temVybyB4IGFuZCBrLCBhbmQgaGVuY2Ugbm9uLXplcm8gcmVzdWx0LlxyXG4gIGZ1bmN0aW9uIG11bHRpcGx5SW50ZWdlcih4LCBrLCBiYXNlKSB7XHJcbiAgICB2YXIgdGVtcCxcclxuICAgICAgY2FycnkgPSAwLFxyXG4gICAgICBpID0geC5sZW5ndGg7XHJcblxyXG4gICAgZm9yICh4ID0geC5zbGljZSgpOyBpLS07KSB7XHJcbiAgICAgIHRlbXAgPSB4W2ldICogayArIGNhcnJ5O1xyXG4gICAgICB4W2ldID0gdGVtcCAlIGJhc2UgfCAwO1xyXG4gICAgICBjYXJyeSA9IHRlbXAgLyBiYXNlIHwgMDtcclxuICAgIH1cclxuXHJcbiAgICBpZiAoY2FycnkpIHgudW5zaGlmdChjYXJyeSk7XHJcblxyXG4gICAgcmV0dXJuIHg7XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBjb21wYXJlKGEsIGIsIGFMLCBiTCkge1xyXG4gICAgdmFyIGksIHI7XHJcblxyXG4gICAgaWYgKGFMICE9IGJMKSB7XHJcbiAgICAgIHIgPSBhTCA+IGJMID8gMSA6IC0xO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgZm9yIChpID0gciA9IDA7IGkgPCBhTDsgaSsrKSB7XHJcbiAgICAgICAgaWYgKGFbaV0gIT0gYltpXSkge1xyXG4gICAgICAgICAgciA9IGFbaV0gPiBiW2ldID8gMSA6IC0xO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHI7XHJcbiAgfVxyXG5cclxuICBmdW5jdGlvbiBzdWJ0cmFjdChhLCBiLCBhTCwgYmFzZSkge1xyXG4gICAgdmFyIGkgPSAwO1xyXG5cclxuICAgIC8vIFN1YnRyYWN0IGIgZnJvbSBhLlxyXG4gICAgZm9yICg7IGFMLS07KSB7XHJcbiAgICAgIGFbYUxdIC09IGk7XHJcbiAgICAgIGkgPSBhW2FMXSA8IGJbYUxdID8gMSA6IDA7XHJcbiAgICAgIGFbYUxdID0gaSAqIGJhc2UgKyBhW2FMXSAtIGJbYUxdO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFJlbW92ZSBsZWFkaW5nIHplcm9zLlxyXG4gICAgZm9yICg7ICFhWzBdICYmIGEubGVuZ3RoID4gMTspIGEuc2hpZnQoKTtcclxuICB9XHJcblxyXG4gIHJldHVybiBmdW5jdGlvbiAoeCwgeSwgcHIsIHJtLCBkcCwgYmFzZSkge1xyXG4gICAgdmFyIGNtcCwgZSwgaSwgaywgbG9nQmFzZSwgbW9yZSwgcHJvZCwgcHJvZEwsIHEsIHFkLCByZW0sIHJlbUwsIHJlbTAsIHNkLCB0LCB4aSwgeEwsIHlkMCxcclxuICAgICAgeUwsIHl6LFxyXG4gICAgICBDdG9yID0geC5jb25zdHJ1Y3RvcixcclxuICAgICAgc2lnbiA9IHgucyA9PSB5LnMgPyAxIDogLTEsXHJcbiAgICAgIHhkID0geC5kLFxyXG4gICAgICB5ZCA9IHkuZDtcclxuXHJcbiAgICAvLyBFaXRoZXIgTmFOLCBJbmZpbml0eSBvciAwP1xyXG4gICAgaWYgKCF4ZCB8fCAheGRbMF0gfHwgIXlkIHx8ICF5ZFswXSkge1xyXG5cclxuICAgICAgcmV0dXJuIG5ldyBDdG9yKC8vIFJldHVybiBOYU4gaWYgZWl0aGVyIE5hTiwgb3IgYm90aCBJbmZpbml0eSBvciAwLlxyXG4gICAgICAgICF4LnMgfHwgIXkucyB8fCAoeGQgPyB5ZCAmJiB4ZFswXSA9PSB5ZFswXSA6ICF5ZCkgPyBOYU4gOlxyXG5cclxuICAgICAgICAvLyBSZXR1cm4gwrEwIGlmIHggaXMgMCBvciB5IGlzIMKxSW5maW5pdHksIG9yIHJldHVybiDCsUluZmluaXR5IGFzIHkgaXMgMC5cclxuICAgICAgICB4ZCAmJiB4ZFswXSA9PSAwIHx8ICF5ZCA/IHNpZ24gKiAwIDogc2lnbiAvIDApO1xyXG4gICAgfVxyXG5cclxuICAgIGlmIChiYXNlKSB7XHJcbiAgICAgIGxvZ0Jhc2UgPSAxO1xyXG4gICAgICBlID0geC5lIC0geS5lO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgYmFzZSA9IEJBU0U7XHJcbiAgICAgIGxvZ0Jhc2UgPSBMT0dfQkFTRTtcclxuICAgICAgZSA9IG1hdGhmbG9vcih4LmUgLyBsb2dCYXNlKSAtIG1hdGhmbG9vcih5LmUgLyBsb2dCYXNlKTtcclxuICAgIH1cclxuXHJcbiAgICB5TCA9IHlkLmxlbmd0aDtcclxuICAgIHhMID0geGQubGVuZ3RoO1xyXG4gICAgcSA9IG5ldyBDdG9yKHNpZ24pO1xyXG4gICAgcWQgPSBxLmQgPSBbXTtcclxuXHJcbiAgICAvLyBSZXN1bHQgZXhwb25lbnQgbWF5IGJlIG9uZSBsZXNzIHRoYW4gZS5cclxuICAgIC8vIFRoZSBkaWdpdCBhcnJheSBvZiBhIERlY2ltYWwgZnJvbSB0b1N0cmluZ0JpbmFyeSBtYXkgaGF2ZSB0cmFpbGluZyB6ZXJvcy5cclxuICAgIGZvciAoaSA9IDA7IHlkW2ldID09ICh4ZFtpXSB8fCAwKTsgaSsrKTtcclxuXHJcbiAgICBpZiAoeWRbaV0gPiAoeGRbaV0gfHwgMCkpIGUtLTtcclxuXHJcbiAgICBpZiAocHIgPT0gbnVsbCkge1xyXG4gICAgICBzZCA9IHByID0gQ3Rvci5wcmVjaXNpb247XHJcbiAgICAgIHJtID0gQ3Rvci5yb3VuZGluZztcclxuICAgIH0gZWxzZSBpZiAoZHApIHtcclxuICAgICAgc2QgPSBwciArICh4LmUgLSB5LmUpICsgMTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHNkID0gcHI7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHNkIDwgMCkge1xyXG4gICAgICBxZC5wdXNoKDEpO1xyXG4gICAgICBtb3JlID0gdHJ1ZTtcclxuICAgIH0gZWxzZSB7XHJcblxyXG4gICAgICAvLyBDb252ZXJ0IHByZWNpc2lvbiBpbiBudW1iZXIgb2YgYmFzZSAxMCBkaWdpdHMgdG8gYmFzZSAxZTcgZGlnaXRzLlxyXG4gICAgICBzZCA9IHNkIC8gbG9nQmFzZSArIDIgfCAwO1xyXG4gICAgICBpID0gMDtcclxuXHJcbiAgICAgIC8vIGRpdmlzb3IgPCAxZTdcclxuICAgICAgaWYgKHlMID09IDEpIHtcclxuICAgICAgICBrID0gMDtcclxuICAgICAgICB5ZCA9IHlkWzBdO1xyXG4gICAgICAgIHNkKys7XHJcblxyXG4gICAgICAgIC8vIGsgaXMgdGhlIGNhcnJ5LlxyXG4gICAgICAgIGZvciAoOyAoaSA8IHhMIHx8IGspICYmIHNkLS07IGkrKykge1xyXG4gICAgICAgICAgdCA9IGsgKiBiYXNlICsgKHhkW2ldIHx8IDApO1xyXG4gICAgICAgICAgcWRbaV0gPSB0IC8geWQgfCAwO1xyXG4gICAgICAgICAgayA9IHQgJSB5ZCB8IDA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBtb3JlID0gayB8fCBpIDwgeEw7XHJcblxyXG4gICAgICAvLyBkaXZpc29yID49IDFlN1xyXG4gICAgICB9IGVsc2Uge1xyXG5cclxuICAgICAgICAvLyBOb3JtYWxpc2UgeGQgYW5kIHlkIHNvIGhpZ2hlc3Qgb3JkZXIgZGlnaXQgb2YgeWQgaXMgPj0gYmFzZS8yXHJcbiAgICAgICAgayA9IGJhc2UgLyAoeWRbMF0gKyAxKSB8IDA7XHJcblxyXG4gICAgICAgIGlmIChrID4gMSkge1xyXG4gICAgICAgICAgeWQgPSBtdWx0aXBseUludGVnZXIoeWQsIGssIGJhc2UpO1xyXG4gICAgICAgICAgeGQgPSBtdWx0aXBseUludGVnZXIoeGQsIGssIGJhc2UpO1xyXG4gICAgICAgICAgeUwgPSB5ZC5sZW5ndGg7XHJcbiAgICAgICAgICB4TCA9IHhkLmxlbmd0aDtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHhpID0geUw7XHJcbiAgICAgICAgcmVtID0geGQuc2xpY2UoMCwgeUwpO1xyXG4gICAgICAgIHJlbUwgPSByZW0ubGVuZ3RoO1xyXG5cclxuICAgICAgICAvLyBBZGQgemVyb3MgdG8gbWFrZSByZW1haW5kZXIgYXMgbG9uZyBhcyBkaXZpc29yLlxyXG4gICAgICAgIGZvciAoOyByZW1MIDwgeUw7KSByZW1bcmVtTCsrXSA9IDA7XHJcblxyXG4gICAgICAgIHl6ID0geWQuc2xpY2UoKTtcclxuICAgICAgICB5ei51bnNoaWZ0KDApO1xyXG4gICAgICAgIHlkMCA9IHlkWzBdO1xyXG5cclxuICAgICAgICBpZiAoeWRbMV0gPj0gYmFzZSAvIDIpICsreWQwO1xyXG5cclxuICAgICAgICBkbyB7XHJcbiAgICAgICAgICBrID0gMDtcclxuXHJcbiAgICAgICAgICAvLyBDb21wYXJlIGRpdmlzb3IgYW5kIHJlbWFpbmRlci5cclxuICAgICAgICAgIGNtcCA9IGNvbXBhcmUoeWQsIHJlbSwgeUwsIHJlbUwpO1xyXG5cclxuICAgICAgICAgIC8vIElmIGRpdmlzb3IgPCByZW1haW5kZXIuXHJcbiAgICAgICAgICBpZiAoY21wIDwgMCkge1xyXG5cclxuICAgICAgICAgICAgLy8gQ2FsY3VsYXRlIHRyaWFsIGRpZ2l0LCBrLlxyXG4gICAgICAgICAgICByZW0wID0gcmVtWzBdO1xyXG4gICAgICAgICAgICBpZiAoeUwgIT0gcmVtTCkgcmVtMCA9IHJlbTAgKiBiYXNlICsgKHJlbVsxXSB8fCAwKTtcclxuXHJcbiAgICAgICAgICAgIC8vIGsgd2lsbCBiZSBob3cgbWFueSB0aW1lcyB0aGUgZGl2aXNvciBnb2VzIGludG8gdGhlIGN1cnJlbnQgcmVtYWluZGVyLlxyXG4gICAgICAgICAgICBrID0gcmVtMCAvIHlkMCB8IDA7XHJcblxyXG4gICAgICAgICAgICAvLyAgQWxnb3JpdGhtOlxyXG4gICAgICAgICAgICAvLyAgMS4gcHJvZHVjdCA9IGRpdmlzb3IgKiB0cmlhbCBkaWdpdCAoaylcclxuICAgICAgICAgICAgLy8gIDIuIGlmIHByb2R1Y3QgPiByZW1haW5kZXI6IHByb2R1Y3QgLT0gZGl2aXNvciwgay0tXHJcbiAgICAgICAgICAgIC8vICAzLiByZW1haW5kZXIgLT0gcHJvZHVjdFxyXG4gICAgICAgICAgICAvLyAgNC4gaWYgcHJvZHVjdCB3YXMgPCByZW1haW5kZXIgYXQgMjpcclxuICAgICAgICAgICAgLy8gICAgNS4gY29tcGFyZSBuZXcgcmVtYWluZGVyIGFuZCBkaXZpc29yXHJcbiAgICAgICAgICAgIC8vICAgIDYuIElmIHJlbWFpbmRlciA+IGRpdmlzb3I6IHJlbWFpbmRlciAtPSBkaXZpc29yLCBrKytcclxuXHJcbiAgICAgICAgICAgIGlmIChrID4gMSkge1xyXG4gICAgICAgICAgICAgIGlmIChrID49IGJhc2UpIGsgPSBiYXNlIC0gMTtcclxuXHJcbiAgICAgICAgICAgICAgLy8gcHJvZHVjdCA9IGRpdmlzb3IgKiB0cmlhbCBkaWdpdC5cclxuICAgICAgICAgICAgICBwcm9kID0gbXVsdGlwbHlJbnRlZ2VyKHlkLCBrLCBiYXNlKTtcclxuICAgICAgICAgICAgICBwcm9kTCA9IHByb2QubGVuZ3RoO1xyXG4gICAgICAgICAgICAgIHJlbUwgPSByZW0ubGVuZ3RoO1xyXG5cclxuICAgICAgICAgICAgICAvLyBDb21wYXJlIHByb2R1Y3QgYW5kIHJlbWFpbmRlci5cclxuICAgICAgICAgICAgICBjbXAgPSBjb21wYXJlKHByb2QsIHJlbSwgcHJvZEwsIHJlbUwpO1xyXG5cclxuICAgICAgICAgICAgICAvLyBwcm9kdWN0ID4gcmVtYWluZGVyLlxyXG4gICAgICAgICAgICAgIGlmIChjbXAgPT0gMSkge1xyXG4gICAgICAgICAgICAgICAgay0tO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIFN1YnRyYWN0IGRpdmlzb3IgZnJvbSBwcm9kdWN0LlxyXG4gICAgICAgICAgICAgICAgc3VidHJhY3QocHJvZCwgeUwgPCBwcm9kTCA/IHl6IDogeWQsIHByb2RMLCBiYXNlKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcblxyXG4gICAgICAgICAgICAgIC8vIGNtcCBpcyAtMS5cclxuICAgICAgICAgICAgICAvLyBJZiBrIGlzIDAsIHRoZXJlIGlzIG5vIG5lZWQgdG8gY29tcGFyZSB5ZCBhbmQgcmVtIGFnYWluIGJlbG93LCBzbyBjaGFuZ2UgY21wIHRvIDFcclxuICAgICAgICAgICAgICAvLyB0byBhdm9pZCBpdC4gSWYgayBpcyAxIHRoZXJlIGlzIGEgbmVlZCB0byBjb21wYXJlIHlkIGFuZCByZW0gYWdhaW4gYmVsb3cuXHJcbiAgICAgICAgICAgICAgaWYgKGsgPT0gMCkgY21wID0gayA9IDE7XHJcbiAgICAgICAgICAgICAgcHJvZCA9IHlkLnNsaWNlKCk7XHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIHByb2RMID0gcHJvZC5sZW5ndGg7XHJcbiAgICAgICAgICAgIGlmIChwcm9kTCA8IHJlbUwpIHByb2QudW5zaGlmdCgwKTtcclxuXHJcbiAgICAgICAgICAgIC8vIFN1YnRyYWN0IHByb2R1Y3QgZnJvbSByZW1haW5kZXIuXHJcbiAgICAgICAgICAgIHN1YnRyYWN0KHJlbSwgcHJvZCwgcmVtTCwgYmFzZSk7XHJcblxyXG4gICAgICAgICAgICAvLyBJZiBwcm9kdWN0IHdhcyA8IHByZXZpb3VzIHJlbWFpbmRlci5cclxuICAgICAgICAgICAgaWYgKGNtcCA9PSAtMSkge1xyXG4gICAgICAgICAgICAgIHJlbUwgPSByZW0ubGVuZ3RoO1xyXG5cclxuICAgICAgICAgICAgICAvLyBDb21wYXJlIGRpdmlzb3IgYW5kIG5ldyByZW1haW5kZXIuXHJcbiAgICAgICAgICAgICAgY21wID0gY29tcGFyZSh5ZCwgcmVtLCB5TCwgcmVtTCk7XHJcblxyXG4gICAgICAgICAgICAgIC8vIElmIGRpdmlzb3IgPCBuZXcgcmVtYWluZGVyLCBzdWJ0cmFjdCBkaXZpc29yIGZyb20gcmVtYWluZGVyLlxyXG4gICAgICAgICAgICAgIGlmIChjbXAgPCAxKSB7XHJcbiAgICAgICAgICAgICAgICBrKys7XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gU3VidHJhY3QgZGl2aXNvciBmcm9tIHJlbWFpbmRlci5cclxuICAgICAgICAgICAgICAgIHN1YnRyYWN0KHJlbSwgeUwgPCByZW1MID8geXogOiB5ZCwgcmVtTCwgYmFzZSk7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICByZW1MID0gcmVtLmxlbmd0aDtcclxuICAgICAgICAgIH0gZWxzZSBpZiAoY21wID09PSAwKSB7XHJcbiAgICAgICAgICAgIGsrKztcclxuICAgICAgICAgICAgcmVtID0gWzBdO1xyXG4gICAgICAgICAgfSAgICAvLyBpZiBjbXAgPT09IDEsIGsgd2lsbCBiZSAwXHJcblxyXG4gICAgICAgICAgLy8gQWRkIHRoZSBuZXh0IGRpZ2l0LCBrLCB0byB0aGUgcmVzdWx0IGFycmF5LlxyXG4gICAgICAgICAgcWRbaSsrXSA9IGs7XHJcblxyXG4gICAgICAgICAgLy8gVXBkYXRlIHRoZSByZW1haW5kZXIuXHJcbiAgICAgICAgICBpZiAoY21wICYmIHJlbVswXSkge1xyXG4gICAgICAgICAgICByZW1bcmVtTCsrXSA9IHhkW3hpXSB8fCAwO1xyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVtID0gW3hkW3hpXV07XHJcbiAgICAgICAgICAgIHJlbUwgPSAxO1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICB9IHdoaWxlICgoeGkrKyA8IHhMIHx8IHJlbVswXSAhPT0gdm9pZCAwKSAmJiBzZC0tKTtcclxuXHJcbiAgICAgICAgbW9yZSA9IHJlbVswXSAhPT0gdm9pZCAwO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBMZWFkaW5nIHplcm8/XHJcbiAgICAgIGlmICghcWRbMF0pIHFkLnNoaWZ0KCk7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gbG9nQmFzZSBpcyAxIHdoZW4gZGl2aWRlIGlzIGJlaW5nIHVzZWQgZm9yIGJhc2UgY29udmVyc2lvbi5cclxuICAgIGlmIChsb2dCYXNlID09IDEpIHtcclxuICAgICAgcS5lID0gZTtcclxuICAgICAgaW5leGFjdCA9IG1vcmU7XHJcbiAgICB9IGVsc2Uge1xyXG5cclxuICAgICAgLy8gVG8gY2FsY3VsYXRlIHEuZSwgZmlyc3QgZ2V0IHRoZSBudW1iZXIgb2YgZGlnaXRzIG9mIHFkWzBdLlxyXG4gICAgICBmb3IgKGkgPSAxLCBrID0gcWRbMF07IGsgPj0gMTA7IGsgLz0gMTApIGkrKztcclxuICAgICAgcS5lID0gaSArIGUgKiBsb2dCYXNlIC0gMTtcclxuXHJcbiAgICAgIGZpbmFsaXNlKHEsIGRwID8gcHIgKyBxLmUgKyAxIDogcHIsIHJtLCBtb3JlKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gcTtcclxuICB9O1xyXG59KSgpO1xyXG5cclxuXHJcbi8qXHJcbiAqIFJvdW5kIGB4YCB0byBgc2RgIHNpZ25pZmljYW50IGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGBybWAuXHJcbiAqIENoZWNrIGZvciBvdmVyL3VuZGVyLWZsb3cuXHJcbiAqL1xyXG4gZnVuY3Rpb24gZmluYWxpc2UoeCwgc2QsIHJtLCBpc1RydW5jYXRlZCkge1xyXG4gIHZhciBkaWdpdHMsIGksIGosIGssIHJkLCByb3VuZFVwLCB3LCB4ZCwgeGRpLFxyXG4gICAgQ3RvciA9IHguY29uc3RydWN0b3I7XHJcblxyXG4gIC8vIERvbid0IHJvdW5kIGlmIHNkIGlzIG51bGwgb3IgdW5kZWZpbmVkLlxyXG4gIG91dDogaWYgKHNkICE9IG51bGwpIHtcclxuICAgIHhkID0geC5kO1xyXG5cclxuICAgIC8vIEluZmluaXR5L05hTi5cclxuICAgIGlmICgheGQpIHJldHVybiB4O1xyXG5cclxuICAgIC8vIHJkOiB0aGUgcm91bmRpbmcgZGlnaXQsIGkuZS4gdGhlIGRpZ2l0IGFmdGVyIHRoZSBkaWdpdCB0aGF0IG1heSBiZSByb3VuZGVkIHVwLlxyXG4gICAgLy8gdzogdGhlIHdvcmQgb2YgeGQgY29udGFpbmluZyByZCwgYSBiYXNlIDFlNyBudW1iZXIuXHJcbiAgICAvLyB4ZGk6IHRoZSBpbmRleCBvZiB3IHdpdGhpbiB4ZC5cclxuICAgIC8vIGRpZ2l0czogdGhlIG51bWJlciBvZiBkaWdpdHMgb2Ygdy5cclxuICAgIC8vIGk6IHdoYXQgd291bGQgYmUgdGhlIGluZGV4IG9mIHJkIHdpdGhpbiB3IGlmIGFsbCB0aGUgbnVtYmVycyB3ZXJlIDcgZGlnaXRzIGxvbmcgKGkuZS4gaWZcclxuICAgIC8vIHRoZXkgaGFkIGxlYWRpbmcgemVyb3MpXHJcbiAgICAvLyBqOiBpZiA+IDAsIHRoZSBhY3R1YWwgaW5kZXggb2YgcmQgd2l0aGluIHcgKGlmIDwgMCwgcmQgaXMgYSBsZWFkaW5nIHplcm8pLlxyXG5cclxuICAgIC8vIEdldCB0aGUgbGVuZ3RoIG9mIHRoZSBmaXJzdCB3b3JkIG9mIHRoZSBkaWdpdHMgYXJyYXkgeGQuXHJcbiAgICBmb3IgKGRpZ2l0cyA9IDEsIGsgPSB4ZFswXTsgayA+PSAxMDsgayAvPSAxMCkgZGlnaXRzKys7XHJcbiAgICBpID0gc2QgLSBkaWdpdHM7XHJcblxyXG4gICAgLy8gSXMgdGhlIHJvdW5kaW5nIGRpZ2l0IGluIHRoZSBmaXJzdCB3b3JkIG9mIHhkP1xyXG4gICAgaWYgKGkgPCAwKSB7XHJcbiAgICAgIGkgKz0gTE9HX0JBU0U7XHJcbiAgICAgIGogPSBzZDtcclxuICAgICAgdyA9IHhkW3hkaSA9IDBdO1xyXG5cclxuICAgICAgLy8gR2V0IHRoZSByb3VuZGluZyBkaWdpdCBhdCBpbmRleCBqIG9mIHcuXHJcbiAgICAgIHJkID0gdyAvIG1hdGhwb3coMTAsIGRpZ2l0cyAtIGogLSAxKSAlIDEwIHwgMDtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHhkaSA9IE1hdGguY2VpbCgoaSArIDEpIC8gTE9HX0JBU0UpO1xyXG4gICAgICBrID0geGQubGVuZ3RoO1xyXG4gICAgICBpZiAoeGRpID49IGspIHtcclxuICAgICAgICBpZiAoaXNUcnVuY2F0ZWQpIHtcclxuXHJcbiAgICAgICAgICAvLyBOZWVkZWQgYnkgYG5hdHVyYWxFeHBvbmVudGlhbGAsIGBuYXR1cmFsTG9nYXJpdGhtYCBhbmQgYHNxdWFyZVJvb3RgLlxyXG4gICAgICAgICAgZm9yICg7IGsrKyA8PSB4ZGk7KSB4ZC5wdXNoKDApO1xyXG4gICAgICAgICAgdyA9IHJkID0gMDtcclxuICAgICAgICAgIGRpZ2l0cyA9IDE7XHJcbiAgICAgICAgICBpICU9IExPR19CQVNFO1xyXG4gICAgICAgICAgaiA9IGkgLSBMT0dfQkFTRSArIDE7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGJyZWFrIG91dDtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgdyA9IGsgPSB4ZFt4ZGldO1xyXG5cclxuICAgICAgICAvLyBHZXQgdGhlIG51bWJlciBvZiBkaWdpdHMgb2Ygdy5cclxuICAgICAgICBmb3IgKGRpZ2l0cyA9IDE7IGsgPj0gMTA7IGsgLz0gMTApIGRpZ2l0cysrO1xyXG5cclxuICAgICAgICAvLyBHZXQgdGhlIGluZGV4IG9mIHJkIHdpdGhpbiB3LlxyXG4gICAgICAgIGkgJT0gTE9HX0JBU0U7XHJcblxyXG4gICAgICAgIC8vIEdldCB0aGUgaW5kZXggb2YgcmQgd2l0aGluIHcsIGFkanVzdGVkIGZvciBsZWFkaW5nIHplcm9zLlxyXG4gICAgICAgIC8vIFRoZSBudW1iZXIgb2YgbGVhZGluZyB6ZXJvcyBvZiB3IGlzIGdpdmVuIGJ5IExPR19CQVNFIC0gZGlnaXRzLlxyXG4gICAgICAgIGogPSBpIC0gTE9HX0JBU0UgKyBkaWdpdHM7XHJcblxyXG4gICAgICAgIC8vIEdldCB0aGUgcm91bmRpbmcgZGlnaXQgYXQgaW5kZXggaiBvZiB3LlxyXG4gICAgICAgIHJkID0gaiA8IDAgPyAwIDogdyAvIG1hdGhwb3coMTAsIGRpZ2l0cyAtIGogLSAxKSAlIDEwIHwgMDtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIEFyZSB0aGVyZSBhbnkgbm9uLXplcm8gZGlnaXRzIGFmdGVyIHRoZSByb3VuZGluZyBkaWdpdD9cclxuICAgIGlzVHJ1bmNhdGVkID0gaXNUcnVuY2F0ZWQgfHwgc2QgPCAwIHx8XHJcbiAgICAgIHhkW3hkaSArIDFdICE9PSB2b2lkIDAgfHwgKGogPCAwID8gdyA6IHcgJSBtYXRocG93KDEwLCBkaWdpdHMgLSBqIC0gMSkpO1xyXG5cclxuICAgIC8vIFRoZSBleHByZXNzaW9uIGB3ICUgbWF0aHBvdygxMCwgZGlnaXRzIC0gaiAtIDEpYCByZXR1cm5zIGFsbCB0aGUgZGlnaXRzIG9mIHcgdG8gdGhlIHJpZ2h0XHJcbiAgICAvLyBvZiB0aGUgZGlnaXQgYXQgKGxlZnQtdG8tcmlnaHQpIGluZGV4IGosIGUuZy4gaWYgdyBpcyA5MDg3MTQgYW5kIGogaXMgMiwgdGhlIGV4cHJlc3Npb25cclxuICAgIC8vIHdpbGwgZ2l2ZSA3MTQuXHJcblxyXG4gICAgcm91bmRVcCA9IHJtIDwgNFxyXG4gICAgICA/IChyZCB8fCBpc1RydW5jYXRlZCkgJiYgKHJtID09IDAgfHwgcm0gPT0gKHgucyA8IDAgPyAzIDogMikpXHJcbiAgICAgIDogcmQgPiA1IHx8IHJkID09IDUgJiYgKHJtID09IDQgfHwgaXNUcnVuY2F0ZWQgfHwgcm0gPT0gNiAmJlxyXG5cclxuICAgICAgICAvLyBDaGVjayB3aGV0aGVyIHRoZSBkaWdpdCB0byB0aGUgbGVmdCBvZiB0aGUgcm91bmRpbmcgZGlnaXQgaXMgb2RkLlxyXG4gICAgICAgICgoaSA+IDAgPyBqID4gMCA/IHcgLyBtYXRocG93KDEwLCBkaWdpdHMgLSBqKSA6IDAgOiB4ZFt4ZGkgLSAxXSkgJSAxMCkgJiAxIHx8XHJcbiAgICAgICAgICBybSA9PSAoeC5zIDwgMCA/IDggOiA3KSk7XHJcblxyXG4gICAgaWYgKHNkIDwgMSB8fCAheGRbMF0pIHtcclxuICAgICAgeGQubGVuZ3RoID0gMDtcclxuICAgICAgaWYgKHJvdW5kVXApIHtcclxuXHJcbiAgICAgICAgLy8gQ29udmVydCBzZCB0byBkZWNpbWFsIHBsYWNlcy5cclxuICAgICAgICBzZCAtPSB4LmUgKyAxO1xyXG5cclxuICAgICAgICAvLyAxLCAwLjEsIDAuMDEsIDAuMDAxLCAwLjAwMDEgZXRjLlxyXG4gICAgICAgIHhkWzBdID0gbWF0aHBvdygxMCwgKExPR19CQVNFIC0gc2QgJSBMT0dfQkFTRSkgJSBMT0dfQkFTRSk7XHJcbiAgICAgICAgeC5lID0gLXNkIHx8IDA7XHJcbiAgICAgIH0gZWxzZSB7XHJcblxyXG4gICAgICAgIC8vIFplcm8uXHJcbiAgICAgICAgeGRbMF0gPSB4LmUgPSAwO1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4geDtcclxuICAgIH1cclxuXHJcbiAgICAvLyBSZW1vdmUgZXhjZXNzIGRpZ2l0cy5cclxuICAgIGlmIChpID09IDApIHtcclxuICAgICAgeGQubGVuZ3RoID0geGRpO1xyXG4gICAgICBrID0gMTtcclxuICAgICAgeGRpLS07XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICB4ZC5sZW5ndGggPSB4ZGkgKyAxO1xyXG4gICAgICBrID0gbWF0aHBvdygxMCwgTE9HX0JBU0UgLSBpKTtcclxuXHJcbiAgICAgIC8vIEUuZy4gNTY3MDAgYmVjb21lcyA1NjAwMCBpZiA3IGlzIHRoZSByb3VuZGluZyBkaWdpdC5cclxuICAgICAgLy8gaiA+IDAgbWVhbnMgaSA+IG51bWJlciBvZiBsZWFkaW5nIHplcm9zIG9mIHcuXHJcbiAgICAgIHhkW3hkaV0gPSBqID4gMCA/ICh3IC8gbWF0aHBvdygxMCwgZGlnaXRzIC0gaikgJSBtYXRocG93KDEwLCBqKSB8IDApICogayA6IDA7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHJvdW5kVXApIHtcclxuICAgICAgZm9yICg7Oykge1xyXG5cclxuICAgICAgICAvLyBJcyB0aGUgZGlnaXQgdG8gYmUgcm91bmRlZCB1cCBpbiB0aGUgZmlyc3Qgd29yZCBvZiB4ZD9cclxuICAgICAgICBpZiAoeGRpID09IDApIHtcclxuXHJcbiAgICAgICAgICAvLyBpIHdpbGwgYmUgdGhlIGxlbmd0aCBvZiB4ZFswXSBiZWZvcmUgayBpcyBhZGRlZC5cclxuICAgICAgICAgIGZvciAoaSA9IDEsIGogPSB4ZFswXTsgaiA+PSAxMDsgaiAvPSAxMCkgaSsrO1xyXG4gICAgICAgICAgaiA9IHhkWzBdICs9IGs7XHJcbiAgICAgICAgICBmb3IgKGsgPSAxOyBqID49IDEwOyBqIC89IDEwKSBrKys7XHJcblxyXG4gICAgICAgICAgLy8gaWYgaSAhPSBrIHRoZSBsZW5ndGggaGFzIGluY3JlYXNlZC5cclxuICAgICAgICAgIGlmIChpICE9IGspIHtcclxuICAgICAgICAgICAgeC5lKys7XHJcbiAgICAgICAgICAgIGlmICh4ZFswXSA9PSBCQVNFKSB4ZFswXSA9IDE7XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHhkW3hkaV0gKz0gaztcclxuICAgICAgICAgIGlmICh4ZFt4ZGldICE9IEJBU0UpIGJyZWFrO1xyXG4gICAgICAgICAgeGRbeGRpLS1dID0gMDtcclxuICAgICAgICAgIGsgPSAxO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIC8vIFJlbW92ZSB0cmFpbGluZyB6ZXJvcy5cclxuICAgIGZvciAoaSA9IHhkLmxlbmd0aDsgeGRbLS1pXSA9PT0gMDspIHhkLnBvcCgpO1xyXG4gIH1cclxuXHJcbiAgaWYgKGV4dGVybmFsKSB7XHJcblxyXG4gICAgLy8gT3ZlcmZsb3c/XHJcbiAgICBpZiAoeC5lID4gQ3Rvci5tYXhFKSB7XHJcblxyXG4gICAgICAvLyBJbmZpbml0eS5cclxuICAgICAgeC5kID0gbnVsbDtcclxuICAgICAgeC5lID0gTmFOO1xyXG5cclxuICAgIC8vIFVuZGVyZmxvdz9cclxuICAgIH0gZWxzZSBpZiAoeC5lIDwgQ3Rvci5taW5FKSB7XHJcblxyXG4gICAgICAvLyBaZXJvLlxyXG4gICAgICB4LmUgPSAwO1xyXG4gICAgICB4LmQgPSBbMF07XHJcbiAgICAgIC8vIEN0b3IudW5kZXJmbG93ID0gdHJ1ZTtcclxuICAgIH0gLy8gZWxzZSBDdG9yLnVuZGVyZmxvdyA9IGZhbHNlO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHg7XHJcbn1cclxuXHJcblxyXG5mdW5jdGlvbiBmaW5pdGVUb1N0cmluZyh4LCBpc0V4cCwgc2QpIHtcclxuICBpZiAoIXguaXNGaW5pdGUoKSkgcmV0dXJuIG5vbkZpbml0ZVRvU3RyaW5nKHgpO1xyXG4gIHZhciBrLFxyXG4gICAgZSA9IHguZSxcclxuICAgIHN0ciA9IGRpZ2l0c1RvU3RyaW5nKHguZCksXHJcbiAgICBsZW4gPSBzdHIubGVuZ3RoO1xyXG5cclxuICBpZiAoaXNFeHApIHtcclxuICAgIGlmIChzZCAmJiAoayA9IHNkIC0gbGVuKSA+IDApIHtcclxuICAgICAgc3RyID0gc3RyLmNoYXJBdCgwKSArICcuJyArIHN0ci5zbGljZSgxKSArIGdldFplcm9TdHJpbmcoayk7XHJcbiAgICB9IGVsc2UgaWYgKGxlbiA+IDEpIHtcclxuICAgICAgc3RyID0gc3RyLmNoYXJBdCgwKSArICcuJyArIHN0ci5zbGljZSgxKTtcclxuICAgIH1cclxuXHJcbiAgICBzdHIgPSBzdHIgKyAoeC5lIDwgMCA/ICdlJyA6ICdlKycpICsgeC5lO1xyXG4gIH0gZWxzZSBpZiAoZSA8IDApIHtcclxuICAgIHN0ciA9ICcwLicgKyBnZXRaZXJvU3RyaW5nKC1lIC0gMSkgKyBzdHI7XHJcbiAgICBpZiAoc2QgJiYgKGsgPSBzZCAtIGxlbikgPiAwKSBzdHIgKz0gZ2V0WmVyb1N0cmluZyhrKTtcclxuICB9IGVsc2UgaWYgKGUgPj0gbGVuKSB7XHJcbiAgICBzdHIgKz0gZ2V0WmVyb1N0cmluZyhlICsgMSAtIGxlbik7XHJcbiAgICBpZiAoc2QgJiYgKGsgPSBzZCAtIGUgLSAxKSA+IDApIHN0ciA9IHN0ciArICcuJyArIGdldFplcm9TdHJpbmcoayk7XHJcbiAgfSBlbHNlIHtcclxuICAgIGlmICgoayA9IGUgKyAxKSA8IGxlbikgc3RyID0gc3RyLnNsaWNlKDAsIGspICsgJy4nICsgc3RyLnNsaWNlKGspO1xyXG4gICAgaWYgKHNkICYmIChrID0gc2QgLSBsZW4pID4gMCkge1xyXG4gICAgICBpZiAoZSArIDEgPT09IGxlbikgc3RyICs9ICcuJztcclxuICAgICAgc3RyICs9IGdldFplcm9TdHJpbmcoayk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gc3RyO1xyXG59XHJcblxyXG5cclxuLy8gQ2FsY3VsYXRlIHRoZSBiYXNlIDEwIGV4cG9uZW50IGZyb20gdGhlIGJhc2UgMWU3IGV4cG9uZW50LlxyXG5mdW5jdGlvbiBnZXRCYXNlMTBFeHBvbmVudChkaWdpdHMsIGUpIHtcclxuICB2YXIgdyA9IGRpZ2l0c1swXTtcclxuXHJcbiAgLy8gQWRkIHRoZSBudW1iZXIgb2YgZGlnaXRzIG9mIHRoZSBmaXJzdCB3b3JkIG9mIHRoZSBkaWdpdHMgYXJyYXkuXHJcbiAgZm9yICggZSAqPSBMT0dfQkFTRTsgdyA+PSAxMDsgdyAvPSAxMCkgZSsrO1xyXG4gIHJldHVybiBlO1xyXG59XHJcblxyXG5cclxuZnVuY3Rpb24gZ2V0TG4xMChDdG9yLCBzZCwgcHIpIHtcclxuICBpZiAoc2QgPiBMTjEwX1BSRUNJU0lPTikge1xyXG5cclxuICAgIC8vIFJlc2V0IGdsb2JhbCBzdGF0ZSBpbiBjYXNlIHRoZSBleGNlcHRpb24gaXMgY2F1Z2h0LlxyXG4gICAgZXh0ZXJuYWwgPSB0cnVlO1xyXG4gICAgaWYgKHByKSBDdG9yLnByZWNpc2lvbiA9IHByO1xyXG4gICAgdGhyb3cgRXJyb3IocHJlY2lzaW9uTGltaXRFeGNlZWRlZCk7XHJcbiAgfVxyXG4gIHJldHVybiBmaW5hbGlzZShuZXcgQ3RvcihMTjEwKSwgc2QsIDEsIHRydWUpO1xyXG59XHJcblxyXG5cclxuZnVuY3Rpb24gZ2V0UGkoQ3Rvciwgc2QsIHJtKSB7XHJcbiAgaWYgKHNkID4gUElfUFJFQ0lTSU9OKSB0aHJvdyBFcnJvcihwcmVjaXNpb25MaW1pdEV4Y2VlZGVkKTtcclxuICByZXR1cm4gZmluYWxpc2UobmV3IEN0b3IoUEkpLCBzZCwgcm0sIHRydWUpO1xyXG59XHJcblxyXG5cclxuZnVuY3Rpb24gZ2V0UHJlY2lzaW9uKGRpZ2l0cykge1xyXG4gIHZhciB3ID0gZGlnaXRzLmxlbmd0aCAtIDEsXHJcbiAgICBsZW4gPSB3ICogTE9HX0JBU0UgKyAxO1xyXG5cclxuICB3ID0gZGlnaXRzW3ddO1xyXG5cclxuICAvLyBJZiBub24temVyby4uLlxyXG4gIGlmICh3KSB7XHJcblxyXG4gICAgLy8gU3VidHJhY3QgdGhlIG51bWJlciBvZiB0cmFpbGluZyB6ZXJvcyBvZiB0aGUgbGFzdCB3b3JkLlxyXG4gICAgZm9yICg7IHcgJSAxMCA9PSAwOyB3IC89IDEwKSBsZW4tLTtcclxuXHJcbiAgICAvLyBBZGQgdGhlIG51bWJlciBvZiBkaWdpdHMgb2YgdGhlIGZpcnN0IHdvcmQuXHJcbiAgICBmb3IgKHcgPSBkaWdpdHNbMF07IHcgPj0gMTA7IHcgLz0gMTApIGxlbisrO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGxlbjtcclxufVxyXG5cclxuXHJcbmZ1bmN0aW9uIGdldFplcm9TdHJpbmcoaykge1xyXG4gIHZhciB6cyA9ICcnO1xyXG4gIGZvciAoOyBrLS07KSB6cyArPSAnMCc7XHJcbiAgcmV0dXJuIHpzO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIHZhbHVlIG9mIERlY2ltYWwgYHhgIHRvIHRoZSBwb3dlciBgbmAsIHdoZXJlIGBuYCBpcyBhblxyXG4gKiBpbnRlZ2VyIG9mIHR5cGUgbnVtYmVyLlxyXG4gKlxyXG4gKiBJbXBsZW1lbnRzICdleHBvbmVudGlhdGlvbiBieSBzcXVhcmluZycuIENhbGxlZCBieSBgcG93YCBhbmQgYHBhcnNlT3RoZXJgLlxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gaW50UG93KEN0b3IsIHgsIG4sIHByKSB7XHJcbiAgdmFyIGlzVHJ1bmNhdGVkLFxyXG4gICAgciA9IG5ldyBDdG9yKDEpLFxyXG5cclxuICAgIC8vIE1heCBuIG9mIDkwMDcxOTkyNTQ3NDA5OTEgdGFrZXMgNTMgbG9vcCBpdGVyYXRpb25zLlxyXG4gICAgLy8gTWF4aW11bSBkaWdpdHMgYXJyYXkgbGVuZ3RoOyBsZWF2ZXMgWzI4LCAzNF0gZ3VhcmQgZGlnaXRzLlxyXG4gICAgayA9IE1hdGguY2VpbChwciAvIExPR19CQVNFICsgNCk7XHJcblxyXG4gIGV4dGVybmFsID0gZmFsc2U7XHJcblxyXG4gIGZvciAoOzspIHtcclxuICAgIGlmIChuICUgMikge1xyXG4gICAgICByID0gci50aW1lcyh4KTtcclxuICAgICAgaWYgKHRydW5jYXRlKHIuZCwgaykpIGlzVHJ1bmNhdGVkID0gdHJ1ZTtcclxuICAgIH1cclxuXHJcbiAgICBuID0gbWF0aGZsb29yKG4gLyAyKTtcclxuICAgIGlmIChuID09PSAwKSB7XHJcblxyXG4gICAgICAvLyBUbyBlbnN1cmUgY29ycmVjdCByb3VuZGluZyB3aGVuIHIuZCBpcyB0cnVuY2F0ZWQsIGluY3JlbWVudCB0aGUgbGFzdCB3b3JkIGlmIGl0IGlzIHplcm8uXHJcbiAgICAgIG4gPSByLmQubGVuZ3RoIC0gMTtcclxuICAgICAgaWYgKGlzVHJ1bmNhdGVkICYmIHIuZFtuXSA9PT0gMCkgKytyLmRbbl07XHJcbiAgICAgIGJyZWFrO1xyXG4gICAgfVxyXG5cclxuICAgIHggPSB4LnRpbWVzKHgpO1xyXG4gICAgdHJ1bmNhdGUoeC5kLCBrKTtcclxuICB9XHJcblxyXG4gIGV4dGVybmFsID0gdHJ1ZTtcclxuXHJcbiAgcmV0dXJuIHI7XHJcbn1cclxuXHJcblxyXG5mdW5jdGlvbiBpc09kZChuKSB7XHJcbiAgcmV0dXJuIG4uZFtuLmQubGVuZ3RoIC0gMV0gJiAxO1xyXG59XHJcblxyXG5cclxuLypcclxuICogSGFuZGxlIGBtYXhgIChgbmAgaXMgLTEpIGFuZCBgbWluYCAoYG5gIGlzIDEpLlxyXG4gKi9cclxuZnVuY3Rpb24gbWF4T3JNaW4oQ3RvciwgYXJncywgbikge1xyXG4gIHZhciBrLCB5LFxyXG4gICAgeCA9IG5ldyBDdG9yKGFyZ3NbMF0pLFxyXG4gICAgaSA9IDA7XHJcblxyXG4gIGZvciAoOyArK2kgPCBhcmdzLmxlbmd0aDspIHtcclxuICAgIHkgPSBuZXcgQ3RvcihhcmdzW2ldKTtcclxuXHJcbiAgICAvLyBOYU4/XHJcbiAgICBpZiAoIXkucykge1xyXG4gICAgICB4ID0geTtcclxuICAgICAgYnJlYWs7XHJcbiAgICB9XHJcblxyXG4gICAgayA9IHguY21wKHkpO1xyXG5cclxuICAgIGlmIChrID09PSBuIHx8IGsgPT09IDAgJiYgeC5zID09PSBuKSB7XHJcbiAgICAgIHggPSB5O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHg7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgbmF0dXJhbCBleHBvbmVudGlhbCBvZiBgeGAgcm91bmRlZCB0byBgc2RgIHNpZ25pZmljYW50XHJcbiAqIGRpZ2l0cy5cclxuICpcclxuICogVGF5bG9yL01hY2xhdXJpbiBzZXJpZXMuXHJcbiAqXHJcbiAqIGV4cCh4KSA9IHheMC8wISArIHheMS8xISArIHheMi8yISArIHheMy8zISArIC4uLlxyXG4gKlxyXG4gKiBBcmd1bWVudCByZWR1Y3Rpb246XHJcbiAqICAgUmVwZWF0IHggPSB4IC8gMzIsIGsgKz0gNSwgdW50aWwgfHh8IDwgMC4xXHJcbiAqICAgZXhwKHgpID0gZXhwKHggLyAyXmspXigyXmspXHJcbiAqXHJcbiAqIFByZXZpb3VzbHksIHRoZSBhcmd1bWVudCB3YXMgaW5pdGlhbGx5IHJlZHVjZWQgYnlcclxuICogZXhwKHgpID0gZXhwKHIpICogMTBeayAgd2hlcmUgciA9IHggLSBrICogbG4xMCwgayA9IGZsb29yKHggLyBsbjEwKVxyXG4gKiB0byBmaXJzdCBwdXQgciBpbiB0aGUgcmFuZ2UgWzAsIGxuMTBdLCBiZWZvcmUgZGl2aWRpbmcgYnkgMzIgdW50aWwgfHh8IDwgMC4xLCBidXQgdGhpcyB3YXNcclxuICogZm91bmQgdG8gYmUgc2xvd2VyIHRoYW4ganVzdCBkaXZpZGluZyByZXBlYXRlZGx5IGJ5IDMyIGFzIGFib3ZlLlxyXG4gKlxyXG4gKiBNYXggaW50ZWdlciBhcmd1bWVudDogZXhwKCcyMDcyMzI2NTgzNjk0NjQxMycpID0gNi4zZSs5MDAwMDAwMDAwMDAwMDAwXHJcbiAqIE1pbiBpbnRlZ2VyIGFyZ3VtZW50OiBleHAoJy0yMDcyMzI2NTgzNjk0NjQxMScpID0gMS4yZS05MDAwMDAwMDAwMDAwMDAwXHJcbiAqIChNYXRoIG9iamVjdCBpbnRlZ2VyIG1pbi9tYXg6IE1hdGguZXhwKDcwOSkgPSA4LjJlKzMwNywgTWF0aC5leHAoLTc0NSkgPSA1ZS0zMjQpXHJcbiAqXHJcbiAqICBleHAoSW5maW5pdHkpICA9IEluZmluaXR5XHJcbiAqICBleHAoLUluZmluaXR5KSA9IDBcclxuICogIGV4cChOYU4pICAgICAgID0gTmFOXHJcbiAqICBleHAowrEwKSAgICAgICAgPSAxXHJcbiAqXHJcbiAqICBleHAoeCkgaXMgbm9uLXRlcm1pbmF0aW5nIGZvciBhbnkgZmluaXRlLCBub24temVybyB4LlxyXG4gKlxyXG4gKiAgVGhlIHJlc3VsdCB3aWxsIGFsd2F5cyBiZSBjb3JyZWN0bHkgcm91bmRlZC5cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIG5hdHVyYWxFeHBvbmVudGlhbCh4LCBzZCkge1xyXG4gIHZhciBkZW5vbWluYXRvciwgZ3VhcmQsIGosIHBvdywgc3VtLCB0LCB3cHIsXHJcbiAgICByZXAgPSAwLFxyXG4gICAgaSA9IDAsXHJcbiAgICBrID0gMCxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yLFxyXG4gICAgcm0gPSBDdG9yLnJvdW5kaW5nLFxyXG4gICAgcHIgPSBDdG9yLnByZWNpc2lvbjtcclxuXHJcbiAgLy8gMC9OYU4vSW5maW5pdHk/XHJcbiAgaWYgKCF4LmQgfHwgIXguZFswXSB8fCB4LmUgPiAxNykge1xyXG5cclxuICAgIHJldHVybiBuZXcgQ3Rvcih4LmRcclxuICAgICAgPyAheC5kWzBdID8gMSA6IHgucyA8IDAgPyAwIDogMSAvIDBcclxuICAgICAgOiB4LnMgPyB4LnMgPCAwID8gMCA6IHggOiAwIC8gMCk7XHJcbiAgfVxyXG5cclxuICBpZiAoc2QgPT0gbnVsbCkge1xyXG4gICAgZXh0ZXJuYWwgPSBmYWxzZTtcclxuICAgIHdwciA9IHByO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB3cHIgPSBzZDtcclxuICB9XHJcblxyXG4gIHQgPSBuZXcgQ3RvcigwLjAzMTI1KTtcclxuXHJcbiAgLy8gd2hpbGUgYWJzKHgpID49IDAuMVxyXG4gIHdoaWxlICh4LmUgPiAtMikge1xyXG5cclxuICAgIC8vIHggPSB4IC8gMl41XHJcbiAgICB4ID0geC50aW1lcyh0KTtcclxuICAgIGsgKz0gNTtcclxuICB9XHJcblxyXG4gIC8vIFVzZSAyICogbG9nMTAoMl5rKSArIDUgKGVtcGlyaWNhbGx5IGRlcml2ZWQpIHRvIGVzdGltYXRlIHRoZSBpbmNyZWFzZSBpbiBwcmVjaXNpb25cclxuICAvLyBuZWNlc3NhcnkgdG8gZW5zdXJlIHRoZSBmaXJzdCA0IHJvdW5kaW5nIGRpZ2l0cyBhcmUgY29ycmVjdC5cclxuICBndWFyZCA9IE1hdGgubG9nKG1hdGhwb3coMiwgaykpIC8gTWF0aC5MTjEwICogMiArIDUgfCAwO1xyXG4gIHdwciArPSBndWFyZDtcclxuICBkZW5vbWluYXRvciA9IHBvdyA9IHN1bSA9IG5ldyBDdG9yKDEpO1xyXG4gIEN0b3IucHJlY2lzaW9uID0gd3ByO1xyXG5cclxuICBmb3IgKDs7KSB7XHJcbiAgICBwb3cgPSBmaW5hbGlzZShwb3cudGltZXMoeCksIHdwciwgMSk7XHJcbiAgICBkZW5vbWluYXRvciA9IGRlbm9taW5hdG9yLnRpbWVzKCsraSk7XHJcbiAgICB0ID0gc3VtLnBsdXMoZGl2aWRlKHBvdywgZGVub21pbmF0b3IsIHdwciwgMSkpO1xyXG5cclxuICAgIGlmIChkaWdpdHNUb1N0cmluZyh0LmQpLnNsaWNlKDAsIHdwcikgPT09IGRpZ2l0c1RvU3RyaW5nKHN1bS5kKS5zbGljZSgwLCB3cHIpKSB7XHJcbiAgICAgIGogPSBrO1xyXG4gICAgICB3aGlsZSAoai0tKSBzdW0gPSBmaW5hbGlzZShzdW0udGltZXMoc3VtKSwgd3ByLCAxKTtcclxuXHJcbiAgICAgIC8vIENoZWNrIHRvIHNlZSBpZiB0aGUgZmlyc3QgNCByb3VuZGluZyBkaWdpdHMgYXJlIFs0OV05OTkuXHJcbiAgICAgIC8vIElmIHNvLCByZXBlYXQgdGhlIHN1bW1hdGlvbiB3aXRoIGEgaGlnaGVyIHByZWNpc2lvbiwgb3RoZXJ3aXNlXHJcbiAgICAgIC8vIGUuZy4gd2l0aCBwcmVjaXNpb246IDE4LCByb3VuZGluZzogMVxyXG4gICAgICAvLyBleHAoMTguNDA0MjcyNDYyNTk1MDM0MDgzNTY3NzkzOTE5ODQzNzYxKSA9IDk4MzcyNTYwLjEyMjk5OTk5OTkgKHNob3VsZCBiZSA5ODM3MjU2MC4xMjMpXHJcbiAgICAgIC8vIGB3cHIgLSBndWFyZGAgaXMgdGhlIGluZGV4IG9mIGZpcnN0IHJvdW5kaW5nIGRpZ2l0LlxyXG4gICAgICBpZiAoc2QgPT0gbnVsbCkge1xyXG5cclxuICAgICAgICBpZiAocmVwIDwgMyAmJiBjaGVja1JvdW5kaW5nRGlnaXRzKHN1bS5kLCB3cHIgLSBndWFyZCwgcm0sIHJlcCkpIHtcclxuICAgICAgICAgIEN0b3IucHJlY2lzaW9uID0gd3ByICs9IDEwO1xyXG4gICAgICAgICAgZGVub21pbmF0b3IgPSBwb3cgPSB0ID0gbmV3IEN0b3IoMSk7XHJcbiAgICAgICAgICBpID0gMDtcclxuICAgICAgICAgIHJlcCsrO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICByZXR1cm4gZmluYWxpc2Uoc3VtLCBDdG9yLnByZWNpc2lvbiA9IHByLCBybSwgZXh0ZXJuYWwgPSB0cnVlKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgQ3Rvci5wcmVjaXNpb24gPSBwcjtcclxuICAgICAgICByZXR1cm4gc3VtO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgc3VtID0gdDtcclxuICB9XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgbmF0dXJhbCBsb2dhcml0aG0gb2YgYHhgIHJvdW5kZWQgdG8gYHNkYCBzaWduaWZpY2FudFxyXG4gKiBkaWdpdHMuXHJcbiAqXHJcbiAqICBsbigtbikgICAgICAgID0gTmFOXHJcbiAqICBsbigwKSAgICAgICAgID0gLUluZmluaXR5XHJcbiAqICBsbigtMCkgICAgICAgID0gLUluZmluaXR5XHJcbiAqICBsbigxKSAgICAgICAgID0gMFxyXG4gKiAgbG4oSW5maW5pdHkpICA9IEluZmluaXR5XHJcbiAqICBsbigtSW5maW5pdHkpID0gTmFOXHJcbiAqICBsbihOYU4pICAgICAgID0gTmFOXHJcbiAqXHJcbiAqICBsbihuKSAobiAhPSAxKSBpcyBub24tdGVybWluYXRpbmcuXHJcbiAqXHJcbiAqL1xyXG5mdW5jdGlvbiBuYXR1cmFsTG9nYXJpdGhtKHksIHNkKSB7XHJcbiAgdmFyIGMsIGMwLCBkZW5vbWluYXRvciwgZSwgbnVtZXJhdG9yLCByZXAsIHN1bSwgdCwgd3ByLCB4MSwgeDIsXHJcbiAgICBuID0gMSxcclxuICAgIGd1YXJkID0gMTAsXHJcbiAgICB4ID0geSxcclxuICAgIHhkID0geC5kLFxyXG4gICAgQ3RvciA9IHguY29uc3RydWN0b3IsXHJcbiAgICBybSA9IEN0b3Iucm91bmRpbmcsXHJcbiAgICBwciA9IEN0b3IucHJlY2lzaW9uO1xyXG5cclxuICAvLyBJcyB4IG5lZ2F0aXZlIG9yIEluZmluaXR5LCBOYU4sIDAgb3IgMT9cclxuICBpZiAoeC5zIDwgMCB8fCAheGQgfHwgIXhkWzBdIHx8ICF4LmUgJiYgeGRbMF0gPT0gMSAmJiB4ZC5sZW5ndGggPT0gMSkge1xyXG4gICAgcmV0dXJuIG5ldyBDdG9yKHhkICYmICF4ZFswXSA/IC0xIC8gMCA6IHgucyAhPSAxID8gTmFOIDogeGQgPyAwIDogeCk7XHJcbiAgfVxyXG5cclxuICBpZiAoc2QgPT0gbnVsbCkge1xyXG4gICAgZXh0ZXJuYWwgPSBmYWxzZTtcclxuICAgIHdwciA9IHByO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB3cHIgPSBzZDtcclxuICB9XHJcblxyXG4gIEN0b3IucHJlY2lzaW9uID0gd3ByICs9IGd1YXJkO1xyXG4gIGMgPSBkaWdpdHNUb1N0cmluZyh4ZCk7XHJcbiAgYzAgPSBjLmNoYXJBdCgwKTtcclxuXHJcbiAgaWYgKE1hdGguYWJzKGUgPSB4LmUpIDwgMS41ZTE1KSB7XHJcblxyXG4gICAgLy8gQXJndW1lbnQgcmVkdWN0aW9uLlxyXG4gICAgLy8gVGhlIHNlcmllcyBjb252ZXJnZXMgZmFzdGVyIHRoZSBjbG9zZXIgdGhlIGFyZ3VtZW50IGlzIHRvIDEsIHNvIHVzaW5nXHJcbiAgICAvLyBsbihhXmIpID0gYiAqIGxuKGEpLCAgIGxuKGEpID0gbG4oYV5iKSAvIGJcclxuICAgIC8vIG11bHRpcGx5IHRoZSBhcmd1bWVudCBieSBpdHNlbGYgdW50aWwgdGhlIGxlYWRpbmcgZGlnaXRzIG9mIHRoZSBzaWduaWZpY2FuZCBhcmUgNywgOCwgOSxcclxuICAgIC8vIDEwLCAxMSwgMTIgb3IgMTMsIHJlY29yZGluZyB0aGUgbnVtYmVyIG9mIG11bHRpcGxpY2F0aW9ucyBzbyB0aGUgc3VtIG9mIHRoZSBzZXJpZXMgY2FuXHJcbiAgICAvLyBsYXRlciBiZSBkaXZpZGVkIGJ5IHRoaXMgbnVtYmVyLCB0aGVuIHNlcGFyYXRlIG91dCB0aGUgcG93ZXIgb2YgMTAgdXNpbmdcclxuICAgIC8vIGxuKGEqMTBeYikgPSBsbihhKSArIGIqbG4oMTApLlxyXG5cclxuICAgIC8vIG1heCBuIGlzIDIxIChnaXZlcyAwLjksIDEuMCBvciAxLjEpICg5ZTE1IC8gMjEgPSA0LjJlMTQpLlxyXG4gICAgLy93aGlsZSAoYzAgPCA5ICYmIGMwICE9IDEgfHwgYzAgPT0gMSAmJiBjLmNoYXJBdCgxKSA+IDEpIHtcclxuICAgIC8vIG1heCBuIGlzIDYgKGdpdmVzIDAuNyAtIDEuMylcclxuICAgIHdoaWxlIChjMCA8IDcgJiYgYzAgIT0gMSB8fCBjMCA9PSAxICYmIGMuY2hhckF0KDEpID4gMykge1xyXG4gICAgICB4ID0geC50aW1lcyh5KTtcclxuICAgICAgYyA9IGRpZ2l0c1RvU3RyaW5nKHguZCk7XHJcbiAgICAgIGMwID0gYy5jaGFyQXQoMCk7XHJcbiAgICAgIG4rKztcclxuICAgIH1cclxuXHJcbiAgICBlID0geC5lO1xyXG5cclxuICAgIGlmIChjMCA+IDEpIHtcclxuICAgICAgeCA9IG5ldyBDdG9yKCcwLicgKyBjKTtcclxuICAgICAgZSsrO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgeCA9IG5ldyBDdG9yKGMwICsgJy4nICsgYy5zbGljZSgxKSk7XHJcbiAgICB9XHJcbiAgfSBlbHNlIHtcclxuXHJcbiAgICAvLyBUaGUgYXJndW1lbnQgcmVkdWN0aW9uIG1ldGhvZCBhYm92ZSBtYXkgcmVzdWx0IGluIG92ZXJmbG93IGlmIHRoZSBhcmd1bWVudCB5IGlzIGEgbWFzc2l2ZVxyXG4gICAgLy8gbnVtYmVyIHdpdGggZXhwb25lbnQgPj0gMTUwMDAwMDAwMDAwMDAwMCAoOWUxNSAvIDYgPSAxLjVlMTUpLCBzbyBpbnN0ZWFkIHJlY2FsbCB0aGlzXHJcbiAgICAvLyBmdW5jdGlvbiB1c2luZyBsbih4KjEwXmUpID0gbG4oeCkgKyBlKmxuKDEwKS5cclxuICAgIHQgPSBnZXRMbjEwKEN0b3IsIHdwciArIDIsIHByKS50aW1lcyhlICsgJycpO1xyXG4gICAgeCA9IG5hdHVyYWxMb2dhcml0aG0obmV3IEN0b3IoYzAgKyAnLicgKyBjLnNsaWNlKDEpKSwgd3ByIC0gZ3VhcmQpLnBsdXModCk7XHJcbiAgICBDdG9yLnByZWNpc2lvbiA9IHByO1xyXG5cclxuICAgIHJldHVybiBzZCA9PSBudWxsID8gZmluYWxpc2UoeCwgcHIsIHJtLCBleHRlcm5hbCA9IHRydWUpIDogeDtcclxuICB9XHJcblxyXG4gIC8vIHgxIGlzIHggcmVkdWNlZCB0byBhIHZhbHVlIG5lYXIgMS5cclxuICB4MSA9IHg7XHJcblxyXG4gIC8vIFRheWxvciBzZXJpZXMuXHJcbiAgLy8gbG4oeSkgPSBsbigoMSArIHgpLygxIC0geCkpID0gMih4ICsgeF4zLzMgKyB4XjUvNSArIHheNy83ICsgLi4uKVxyXG4gIC8vIHdoZXJlIHggPSAoeSAtIDEpLyh5ICsgMSkgICAgKHx4fCA8IDEpXHJcbiAgc3VtID0gbnVtZXJhdG9yID0geCA9IGRpdmlkZSh4Lm1pbnVzKDEpLCB4LnBsdXMoMSksIHdwciwgMSk7XHJcbiAgeDIgPSBmaW5hbGlzZSh4LnRpbWVzKHgpLCB3cHIsIDEpO1xyXG4gIGRlbm9taW5hdG9yID0gMztcclxuXHJcbiAgZm9yICg7Oykge1xyXG4gICAgbnVtZXJhdG9yID0gZmluYWxpc2UobnVtZXJhdG9yLnRpbWVzKHgyKSwgd3ByLCAxKTtcclxuICAgIHQgPSBzdW0ucGx1cyhkaXZpZGUobnVtZXJhdG9yLCBuZXcgQ3RvcihkZW5vbWluYXRvciksIHdwciwgMSkpO1xyXG5cclxuICAgIGlmIChkaWdpdHNUb1N0cmluZyh0LmQpLnNsaWNlKDAsIHdwcikgPT09IGRpZ2l0c1RvU3RyaW5nKHN1bS5kKS5zbGljZSgwLCB3cHIpKSB7XHJcbiAgICAgIHN1bSA9IHN1bS50aW1lcygyKTtcclxuXHJcbiAgICAgIC8vIFJldmVyc2UgdGhlIGFyZ3VtZW50IHJlZHVjdGlvbi4gQ2hlY2sgdGhhdCBlIGlzIG5vdCAwIGJlY2F1c2UsIGJlc2lkZXMgcHJldmVudGluZyBhblxyXG4gICAgICAvLyB1bm5lY2Vzc2FyeSBjYWxjdWxhdGlvbiwgLTAgKyAwID0gKzAgYW5kIHRvIGVuc3VyZSBjb3JyZWN0IHJvdW5kaW5nIC0wIG5lZWRzIHRvIHN0YXkgLTAuXHJcbiAgICAgIGlmIChlICE9PSAwKSBzdW0gPSBzdW0ucGx1cyhnZXRMbjEwKEN0b3IsIHdwciArIDIsIHByKS50aW1lcyhlICsgJycpKTtcclxuICAgICAgc3VtID0gZGl2aWRlKHN1bSwgbmV3IEN0b3IobiksIHdwciwgMSk7XHJcblxyXG4gICAgICAvLyBJcyBybSA+IDMgYW5kIHRoZSBmaXJzdCA0IHJvdW5kaW5nIGRpZ2l0cyA0OTk5LCBvciBybSA8IDQgKG9yIHRoZSBzdW1tYXRpb24gaGFzXHJcbiAgICAgIC8vIGJlZW4gcmVwZWF0ZWQgcHJldmlvdXNseSkgYW5kIHRoZSBmaXJzdCA0IHJvdW5kaW5nIGRpZ2l0cyA5OTk5P1xyXG4gICAgICAvLyBJZiBzbywgcmVzdGFydCB0aGUgc3VtbWF0aW9uIHdpdGggYSBoaWdoZXIgcHJlY2lzaW9uLCBvdGhlcndpc2VcclxuICAgICAgLy8gZS5nLiB3aXRoIHByZWNpc2lvbjogMTIsIHJvdW5kaW5nOiAxXHJcbiAgICAgIC8vIGxuKDEzNTUyMDAyOC42MTI2MDkxNzE0MjY1MzgxNTMzKSA9IDE4LjcyNDYyOTk5OTkgd2hlbiBpdCBzaG91bGQgYmUgMTguNzI0NjMuXHJcbiAgICAgIC8vIGB3cHIgLSBndWFyZGAgaXMgdGhlIGluZGV4IG9mIGZpcnN0IHJvdW5kaW5nIGRpZ2l0LlxyXG4gICAgICBpZiAoc2QgPT0gbnVsbCkge1xyXG4gICAgICAgIGlmIChjaGVja1JvdW5kaW5nRGlnaXRzKHN1bS5kLCB3cHIgLSBndWFyZCwgcm0sIHJlcCkpIHtcclxuICAgICAgICAgIEN0b3IucHJlY2lzaW9uID0gd3ByICs9IGd1YXJkO1xyXG4gICAgICAgICAgdCA9IG51bWVyYXRvciA9IHggPSBkaXZpZGUoeDEubWludXMoMSksIHgxLnBsdXMoMSksIHdwciwgMSk7XHJcbiAgICAgICAgICB4MiA9IGZpbmFsaXNlKHgudGltZXMoeCksIHdwciwgMSk7XHJcbiAgICAgICAgICBkZW5vbWluYXRvciA9IHJlcCA9IDE7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHJldHVybiBmaW5hbGlzZShzdW0sIEN0b3IucHJlY2lzaW9uID0gcHIsIHJtLCBleHRlcm5hbCA9IHRydWUpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBDdG9yLnByZWNpc2lvbiA9IHByO1xyXG4gICAgICAgIHJldHVybiBzdW07XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBzdW0gPSB0O1xyXG4gICAgZGVub21pbmF0b3IgKz0gMjtcclxuICB9XHJcbn1cclxuXHJcblxyXG4vLyDCsUluZmluaXR5LCBOYU4uXHJcbmZ1bmN0aW9uIG5vbkZpbml0ZVRvU3RyaW5nKHgpIHtcclxuICAvLyBVbnNpZ25lZC5cclxuICByZXR1cm4gU3RyaW5nKHgucyAqIHgucyAvIDApO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUGFyc2UgdGhlIHZhbHVlIG9mIGEgbmV3IERlY2ltYWwgYHhgIGZyb20gc3RyaW5nIGBzdHJgLlxyXG4gKi9cclxuZnVuY3Rpb24gcGFyc2VEZWNpbWFsKHgsIHN0cikge1xyXG4gIHZhciBlLCBpLCBsZW47XHJcblxyXG4gIC8vIFRPRE8gQmlnSW50IHN0cjogbm8gbmVlZCB0byBjaGVjayBmb3IgZGVjaW1hbCBwb2ludCwgZXhwb25lbnRpYWwgZm9ybSBvciBsZWFkaW5nIHplcm9zLlxyXG4gIC8vIERlY2ltYWwgcG9pbnQ/XHJcbiAgaWYgKChlID0gc3RyLmluZGV4T2YoJy4nKSkgPiAtMSkgc3RyID0gc3RyLnJlcGxhY2UoJy4nLCAnJyk7XHJcblxyXG4gIC8vIEV4cG9uZW50aWFsIGZvcm0/XHJcbiAgaWYgKChpID0gc3RyLnNlYXJjaCgvZS9pKSkgPiAwKSB7XHJcblxyXG4gICAgLy8gRGV0ZXJtaW5lIGV4cG9uZW50LlxyXG4gICAgaWYgKGUgPCAwKSBlID0gaTtcclxuICAgIGUgKz0gK3N0ci5zbGljZShpICsgMSk7XHJcbiAgICBzdHIgPSBzdHIuc3Vic3RyaW5nKDAsIGkpO1xyXG4gIH0gZWxzZSBpZiAoZSA8IDApIHtcclxuXHJcbiAgICAvLyBJbnRlZ2VyLlxyXG4gICAgZSA9IHN0ci5sZW5ndGg7XHJcbiAgfVxyXG5cclxuICAvLyBEZXRlcm1pbmUgbGVhZGluZyB6ZXJvcy5cclxuICBmb3IgKGkgPSAwOyBzdHIuY2hhckNvZGVBdChpKSA9PT0gNDg7IGkrKyk7XHJcblxyXG4gIC8vIERldGVybWluZSB0cmFpbGluZyB6ZXJvcy5cclxuICBmb3IgKGxlbiA9IHN0ci5sZW5ndGg7IHN0ci5jaGFyQ29kZUF0KGxlbiAtIDEpID09PSA0ODsgLS1sZW4pO1xyXG4gIHN0ciA9IHN0ci5zbGljZShpLCBsZW4pO1xyXG5cclxuICBpZiAoc3RyKSB7XHJcbiAgICBsZW4gLT0gaTtcclxuICAgIHguZSA9IGUgPSBlIC0gaSAtIDE7XHJcbiAgICB4LmQgPSBbXTtcclxuXHJcbiAgICAvLyBUcmFuc2Zvcm0gYmFzZVxyXG5cclxuICAgIC8vIGUgaXMgdGhlIGJhc2UgMTAgZXhwb25lbnQuXHJcbiAgICAvLyBpIGlzIHdoZXJlIHRvIHNsaWNlIHN0ciB0byBnZXQgdGhlIGZpcnN0IHdvcmQgb2YgdGhlIGRpZ2l0cyBhcnJheS5cclxuICAgIGkgPSAoZSArIDEpICUgTE9HX0JBU0U7XHJcbiAgICBpZiAoZSA8IDApIGkgKz0gTE9HX0JBU0U7XHJcblxyXG4gICAgaWYgKGkgPCBsZW4pIHtcclxuICAgICAgaWYgKGkpIHguZC5wdXNoKCtzdHIuc2xpY2UoMCwgaSkpO1xyXG4gICAgICBmb3IgKGxlbiAtPSBMT0dfQkFTRTsgaSA8IGxlbjspIHguZC5wdXNoKCtzdHIuc2xpY2UoaSwgaSArPSBMT0dfQkFTRSkpO1xyXG4gICAgICBzdHIgPSBzdHIuc2xpY2UoaSk7XHJcbiAgICAgIGkgPSBMT0dfQkFTRSAtIHN0ci5sZW5ndGg7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpIC09IGxlbjtcclxuICAgIH1cclxuXHJcbiAgICBmb3IgKDsgaS0tOykgc3RyICs9ICcwJztcclxuICAgIHguZC5wdXNoKCtzdHIpO1xyXG5cclxuICAgIGlmIChleHRlcm5hbCkge1xyXG5cclxuICAgICAgLy8gT3ZlcmZsb3c/XHJcbiAgICAgIGlmICh4LmUgPiB4LmNvbnN0cnVjdG9yLm1heEUpIHtcclxuXHJcbiAgICAgICAgLy8gSW5maW5pdHkuXHJcbiAgICAgICAgeC5kID0gbnVsbDtcclxuICAgICAgICB4LmUgPSBOYU47XHJcblxyXG4gICAgICAvLyBVbmRlcmZsb3c/XHJcbiAgICAgIH0gZWxzZSBpZiAoeC5lIDwgeC5jb25zdHJ1Y3Rvci5taW5FKSB7XHJcblxyXG4gICAgICAgIC8vIFplcm8uXHJcbiAgICAgICAgeC5lID0gMDtcclxuICAgICAgICB4LmQgPSBbMF07XHJcbiAgICAgICAgLy8geC5jb25zdHJ1Y3Rvci51bmRlcmZsb3cgPSB0cnVlO1xyXG4gICAgICB9IC8vIGVsc2UgeC5jb25zdHJ1Y3Rvci51bmRlcmZsb3cgPSBmYWxzZTtcclxuICAgIH1cclxuICB9IGVsc2Uge1xyXG5cclxuICAgIC8vIFplcm8uXHJcbiAgICB4LmUgPSAwO1xyXG4gICAgeC5kID0gWzBdO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHg7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBQYXJzZSB0aGUgdmFsdWUgb2YgYSBuZXcgRGVjaW1hbCBgeGAgZnJvbSBhIHN0cmluZyBgc3RyYCwgd2hpY2ggaXMgbm90IGEgZGVjaW1hbCB2YWx1ZS5cclxuICovXHJcbmZ1bmN0aW9uIHBhcnNlT3RoZXIoeCwgc3RyKSB7XHJcbiAgdmFyIGJhc2UsIEN0b3IsIGRpdmlzb3IsIGksIGlzRmxvYXQsIGxlbiwgcCwgeGQsIHhlO1xyXG5cclxuICBpZiAoc3RyLmluZGV4T2YoJ18nKSA+IC0xKSB7XHJcbiAgICBzdHIgPSBzdHIucmVwbGFjZSgvKFxcZClfKD89XFxkKS9nLCAnJDEnKTtcclxuICAgIGlmIChpc0RlY2ltYWwudGVzdChzdHIpKSByZXR1cm4gcGFyc2VEZWNpbWFsKHgsIHN0cik7XHJcbiAgfSBlbHNlIGlmIChzdHIgPT09ICdJbmZpbml0eScgfHwgc3RyID09PSAnTmFOJykge1xyXG4gICAgaWYgKCErc3RyKSB4LnMgPSBOYU47XHJcbiAgICB4LmUgPSBOYU47XHJcbiAgICB4LmQgPSBudWxsO1xyXG4gICAgcmV0dXJuIHg7XHJcbiAgfVxyXG5cclxuICBpZiAoaXNIZXgudGVzdChzdHIpKSAge1xyXG4gICAgYmFzZSA9IDE2O1xyXG4gICAgc3RyID0gc3RyLnRvTG93ZXJDYXNlKCk7XHJcbiAgfSBlbHNlIGlmIChpc0JpbmFyeS50ZXN0KHN0cikpICB7XHJcbiAgICBiYXNlID0gMjtcclxuICB9IGVsc2UgaWYgKGlzT2N0YWwudGVzdChzdHIpKSAge1xyXG4gICAgYmFzZSA9IDg7XHJcbiAgfSBlbHNlIHtcclxuICAgIHRocm93IEVycm9yKGludmFsaWRBcmd1bWVudCArIHN0cik7XHJcbiAgfVxyXG5cclxuICAvLyBJcyB0aGVyZSBhIGJpbmFyeSBleHBvbmVudCBwYXJ0P1xyXG4gIGkgPSBzdHIuc2VhcmNoKC9wL2kpO1xyXG5cclxuICBpZiAoaSA+IDApIHtcclxuICAgIHAgPSArc3RyLnNsaWNlKGkgKyAxKTtcclxuICAgIHN0ciA9IHN0ci5zdWJzdHJpbmcoMiwgaSk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHN0ciA9IHN0ci5zbGljZSgyKTtcclxuICB9XHJcblxyXG4gIC8vIENvbnZlcnQgYHN0cmAgYXMgYW4gaW50ZWdlciB0aGVuIGRpdmlkZSB0aGUgcmVzdWx0IGJ5IGBiYXNlYCByYWlzZWQgdG8gYSBwb3dlciBzdWNoIHRoYXQgdGhlXHJcbiAgLy8gZnJhY3Rpb24gcGFydCB3aWxsIGJlIHJlc3RvcmVkLlxyXG4gIGkgPSBzdHIuaW5kZXhPZignLicpO1xyXG4gIGlzRmxvYXQgPSBpID49IDA7XHJcbiAgQ3RvciA9IHguY29uc3RydWN0b3I7XHJcblxyXG4gIGlmIChpc0Zsb2F0KSB7XHJcbiAgICBzdHIgPSBzdHIucmVwbGFjZSgnLicsICcnKTtcclxuICAgIGxlbiA9IHN0ci5sZW5ndGg7XHJcbiAgICBpID0gbGVuIC0gaTtcclxuXHJcbiAgICAvLyBsb2dbMTBdKDE2KSA9IDEuMjA0MS4uLiAsIGxvZ1sxMF0oODgpID0gMS45NDQ0Li4uLlxyXG4gICAgZGl2aXNvciA9IGludFBvdyhDdG9yLCBuZXcgQ3RvcihiYXNlKSwgaSwgaSAqIDIpO1xyXG4gIH1cclxuXHJcbiAgeGQgPSBjb252ZXJ0QmFzZShzdHIsIGJhc2UsIEJBU0UpO1xyXG4gIHhlID0geGQubGVuZ3RoIC0gMTtcclxuXHJcbiAgLy8gUmVtb3ZlIHRyYWlsaW5nIHplcm9zLlxyXG4gIGZvciAoaSA9IHhlOyB4ZFtpXSA9PT0gMDsgLS1pKSB4ZC5wb3AoKTtcclxuICBpZiAoaSA8IDApIHJldHVybiBuZXcgQ3Rvcih4LnMgKiAwKTtcclxuICB4LmUgPSBnZXRCYXNlMTBFeHBvbmVudCh4ZCwgeGUpO1xyXG4gIHguZCA9IHhkO1xyXG4gIGV4dGVybmFsID0gZmFsc2U7XHJcblxyXG4gIC8vIEF0IHdoYXQgcHJlY2lzaW9uIHRvIHBlcmZvcm0gdGhlIGRpdmlzaW9uIHRvIGVuc3VyZSBleGFjdCBjb252ZXJzaW9uP1xyXG4gIC8vIG1heERlY2ltYWxJbnRlZ2VyUGFydERpZ2l0Q291bnQgPSBjZWlsKGxvZ1sxMF0oYikgKiBvdGhlckJhc2VJbnRlZ2VyUGFydERpZ2l0Q291bnQpXHJcbiAgLy8gbG9nWzEwXSgyKSA9IDAuMzAxMDMsIGxvZ1sxMF0oOCkgPSAwLjkwMzA5LCBsb2dbMTBdKDE2KSA9IDEuMjA0MTJcclxuICAvLyBFLmcuIGNlaWwoMS4yICogMykgPSA0LCBzbyB1cCB0byA0IGRlY2ltYWwgZGlnaXRzIGFyZSBuZWVkZWQgdG8gcmVwcmVzZW50IDMgaGV4IGludCBkaWdpdHMuXHJcbiAgLy8gbWF4RGVjaW1hbEZyYWN0aW9uUGFydERpZ2l0Q291bnQgPSB7SGV4OjR8T2N0OjN8QmluOjF9ICogb3RoZXJCYXNlRnJhY3Rpb25QYXJ0RGlnaXRDb3VudFxyXG4gIC8vIFRoZXJlZm9yZSB1c2luZyA0ICogdGhlIG51bWJlciBvZiBkaWdpdHMgb2Ygc3RyIHdpbGwgYWx3YXlzIGJlIGVub3VnaC5cclxuICBpZiAoaXNGbG9hdCkgeCA9IGRpdmlkZSh4LCBkaXZpc29yLCBsZW4gKiA0KTtcclxuXHJcbiAgLy8gTXVsdGlwbHkgYnkgdGhlIGJpbmFyeSBleHBvbmVudCBwYXJ0IGlmIHByZXNlbnQuXHJcbiAgaWYgKHApIHggPSB4LnRpbWVzKE1hdGguYWJzKHApIDwgNTQgPyBtYXRocG93KDIsIHApIDogRGVjaW1hbC5wb3coMiwgcCkpO1xyXG4gIGV4dGVybmFsID0gdHJ1ZTtcclxuXHJcbiAgcmV0dXJuIHg7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBzaW4oeCkgPSB4IC0geF4zLzMhICsgeF41LzUhIC0gLi4uXHJcbiAqIHx4fCA8IHBpLzJcclxuICpcclxuICovXHJcbmZ1bmN0aW9uIHNpbmUoQ3RvciwgeCkge1xyXG4gIHZhciBrLFxyXG4gICAgbGVuID0geC5kLmxlbmd0aDtcclxuXHJcbiAgaWYgKGxlbiA8IDMpIHtcclxuICAgIHJldHVybiB4LmlzWmVybygpID8geCA6IHRheWxvclNlcmllcyhDdG9yLCAyLCB4LCB4KTtcclxuICB9XHJcblxyXG4gIC8vIEFyZ3VtZW50IHJlZHVjdGlvbjogc2luKDV4KSA9IDE2KnNpbl41KHgpIC0gMjAqc2luXjMoeCkgKyA1KnNpbih4KVxyXG4gIC8vIGkuZS4gc2luKHgpID0gMTYqc2luXjUoeC81KSAtIDIwKnNpbl4zKHgvNSkgKyA1KnNpbih4LzUpXHJcbiAgLy8gYW5kICBzaW4oeCkgPSBzaW4oeC81KSg1ICsgc2luXjIoeC81KSgxNnNpbl4yKHgvNSkgLSAyMCkpXHJcblxyXG4gIC8vIEVzdGltYXRlIHRoZSBvcHRpbXVtIG51bWJlciBvZiB0aW1lcyB0byB1c2UgdGhlIGFyZ3VtZW50IHJlZHVjdGlvbi5cclxuICBrID0gMS40ICogTWF0aC5zcXJ0KGxlbik7XHJcbiAgayA9IGsgPiAxNiA/IDE2IDogayB8IDA7XHJcblxyXG4gIHggPSB4LnRpbWVzKDEgLyB0aW55UG93KDUsIGspKTtcclxuICB4ID0gdGF5bG9yU2VyaWVzKEN0b3IsIDIsIHgsIHgpO1xyXG5cclxuICAvLyBSZXZlcnNlIGFyZ3VtZW50IHJlZHVjdGlvblxyXG4gIHZhciBzaW4yX3gsXHJcbiAgICBkNSA9IG5ldyBDdG9yKDUpLFxyXG4gICAgZDE2ID0gbmV3IEN0b3IoMTYpLFxyXG4gICAgZDIwID0gbmV3IEN0b3IoMjApO1xyXG4gIGZvciAoOyBrLS07KSB7XHJcbiAgICBzaW4yX3ggPSB4LnRpbWVzKHgpO1xyXG4gICAgeCA9IHgudGltZXMoZDUucGx1cyhzaW4yX3gudGltZXMoZDE2LnRpbWVzKHNpbjJfeCkubWludXMoZDIwKSkpKTtcclxuICB9XHJcblxyXG4gIHJldHVybiB4O1xyXG59XHJcblxyXG5cclxuLy8gQ2FsY3VsYXRlIFRheWxvciBzZXJpZXMgZm9yIGBjb3NgLCBgY29zaGAsIGBzaW5gIGFuZCBgc2luaGAuXHJcbmZ1bmN0aW9uIHRheWxvclNlcmllcyhDdG9yLCBuLCB4LCB5LCBpc0h5cGVyYm9saWMpIHtcclxuICB2YXIgaiwgdCwgdSwgeDIsXHJcbiAgICBpID0gMSxcclxuICAgIHByID0gQ3Rvci5wcmVjaXNpb24sXHJcbiAgICBrID0gTWF0aC5jZWlsKHByIC8gTE9HX0JBU0UpO1xyXG5cclxuICBleHRlcm5hbCA9IGZhbHNlO1xyXG4gIHgyID0geC50aW1lcyh4KTtcclxuICB1ID0gbmV3IEN0b3IoeSk7XHJcblxyXG4gIGZvciAoOzspIHtcclxuICAgIHQgPSBkaXZpZGUodS50aW1lcyh4MiksIG5ldyBDdG9yKG4rKyAqIG4rKyksIHByLCAxKTtcclxuICAgIHUgPSBpc0h5cGVyYm9saWMgPyB5LnBsdXModCkgOiB5Lm1pbnVzKHQpO1xyXG4gICAgeSA9IGRpdmlkZSh0LnRpbWVzKHgyKSwgbmV3IEN0b3IobisrICogbisrKSwgcHIsIDEpO1xyXG4gICAgdCA9IHUucGx1cyh5KTtcclxuXHJcbiAgICBpZiAodC5kW2tdICE9PSB2b2lkIDApIHtcclxuICAgICAgZm9yIChqID0gazsgdC5kW2pdID09PSB1LmRbal0gJiYgai0tOyk7XHJcbiAgICAgIGlmIChqID09IC0xKSBicmVhaztcclxuICAgIH1cclxuXHJcbiAgICBqID0gdTtcclxuICAgIHUgPSB5O1xyXG4gICAgeSA9IHQ7XHJcbiAgICB0ID0gajtcclxuICAgIGkrKztcclxuICB9XHJcblxyXG4gIGV4dGVybmFsID0gdHJ1ZTtcclxuICB0LmQubGVuZ3RoID0gayArIDE7XHJcblxyXG4gIHJldHVybiB0O1xyXG59XHJcblxyXG5cclxuLy8gRXhwb25lbnQgZSBtdXN0IGJlIHBvc2l0aXZlIGFuZCBub24temVyby5cclxuZnVuY3Rpb24gdGlueVBvdyhiLCBlKSB7XHJcbiAgdmFyIG4gPSBiO1xyXG4gIHdoaWxlICgtLWUpIG4gKj0gYjtcclxuICByZXR1cm4gbjtcclxufVxyXG5cclxuXHJcbi8vIFJldHVybiB0aGUgYWJzb2x1dGUgdmFsdWUgb2YgYHhgIHJlZHVjZWQgdG8gbGVzcyB0aGFuIG9yIGVxdWFsIHRvIGhhbGYgcGkuXHJcbmZ1bmN0aW9uIHRvTGVzc1RoYW5IYWxmUGkoQ3RvciwgeCkge1xyXG4gIHZhciB0LFxyXG4gICAgaXNOZWcgPSB4LnMgPCAwLFxyXG4gICAgcGkgPSBnZXRQaShDdG9yLCBDdG9yLnByZWNpc2lvbiwgMSksXHJcbiAgICBoYWxmUGkgPSBwaS50aW1lcygwLjUpO1xyXG5cclxuICB4ID0geC5hYnMoKTtcclxuXHJcbiAgaWYgKHgubHRlKGhhbGZQaSkpIHtcclxuICAgIHF1YWRyYW50ID0gaXNOZWcgPyA0IDogMTtcclxuICAgIHJldHVybiB4O1xyXG4gIH1cclxuXHJcbiAgdCA9IHguZGl2VG9JbnQocGkpO1xyXG5cclxuICBpZiAodC5pc1plcm8oKSkge1xyXG4gICAgcXVhZHJhbnQgPSBpc05lZyA/IDMgOiAyO1xyXG4gIH0gZWxzZSB7XHJcbiAgICB4ID0geC5taW51cyh0LnRpbWVzKHBpKSk7XHJcblxyXG4gICAgLy8gMCA8PSB4IDwgcGlcclxuICAgIGlmICh4Lmx0ZShoYWxmUGkpKSB7XHJcbiAgICAgIHF1YWRyYW50ID0gaXNPZGQodCkgPyAoaXNOZWcgPyAyIDogMykgOiAoaXNOZWcgPyA0IDogMSk7XHJcbiAgICAgIHJldHVybiB4O1xyXG4gICAgfVxyXG5cclxuICAgIHF1YWRyYW50ID0gaXNPZGQodCkgPyAoaXNOZWcgPyAxIDogNCkgOiAoaXNOZWcgPyAzIDogMik7XHJcbiAgfVxyXG5cclxuICByZXR1cm4geC5taW51cyhwaSkuYWJzKCk7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gdGhlIHZhbHVlIG9mIERlY2ltYWwgYHhgIGFzIGEgc3RyaW5nIGluIGJhc2UgYGJhc2VPdXRgLlxyXG4gKlxyXG4gKiBJZiB0aGUgb3B0aW9uYWwgYHNkYCBhcmd1bWVudCBpcyBwcmVzZW50IGluY2x1ZGUgYSBiaW5hcnkgZXhwb25lbnQgc3VmZml4LlxyXG4gKi9cclxuZnVuY3Rpb24gdG9TdHJpbmdCaW5hcnkoeCwgYmFzZU91dCwgc2QsIHJtKSB7XHJcbiAgdmFyIGJhc2UsIGUsIGksIGssIGxlbiwgcm91bmRVcCwgc3RyLCB4ZCwgeSxcclxuICAgIEN0b3IgPSB4LmNvbnN0cnVjdG9yLFxyXG4gICAgaXNFeHAgPSBzZCAhPT0gdm9pZCAwO1xyXG5cclxuICBpZiAoaXNFeHApIHtcclxuICAgIGNoZWNrSW50MzIoc2QsIDEsIE1BWF9ESUdJVFMpO1xyXG4gICAgaWYgKHJtID09PSB2b2lkIDApIHJtID0gQ3Rvci5yb3VuZGluZztcclxuICAgIGVsc2UgY2hlY2tJbnQzMihybSwgMCwgOCk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHNkID0gQ3Rvci5wcmVjaXNpb247XHJcbiAgICBybSA9IEN0b3Iucm91bmRpbmc7XHJcbiAgfVxyXG5cclxuICBpZiAoIXguaXNGaW5pdGUoKSkge1xyXG4gICAgc3RyID0gbm9uRmluaXRlVG9TdHJpbmcoeCk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHN0ciA9IGZpbml0ZVRvU3RyaW5nKHgpO1xyXG4gICAgaSA9IHN0ci5pbmRleE9mKCcuJyk7XHJcblxyXG4gICAgLy8gVXNlIGV4cG9uZW50aWFsIG5vdGF0aW9uIGFjY29yZGluZyB0byBgdG9FeHBQb3NgIGFuZCBgdG9FeHBOZWdgPyBObywgYnV0IGlmIHJlcXVpcmVkOlxyXG4gICAgLy8gbWF4QmluYXJ5RXhwb25lbnQgPSBmbG9vcigoZGVjaW1hbEV4cG9uZW50ICsgMSkgKiBsb2dbMl0oMTApKVxyXG4gICAgLy8gbWluQmluYXJ5RXhwb25lbnQgPSBmbG9vcihkZWNpbWFsRXhwb25lbnQgKiBsb2dbMl0oMTApKVxyXG4gICAgLy8gbG9nWzJdKDEwKSA9IDMuMzIxOTI4MDk0ODg3MzYyMzQ3ODcwMzE5NDI5NDg5MzkwMTc1ODY0XHJcblxyXG4gICAgaWYgKGlzRXhwKSB7XHJcbiAgICAgIGJhc2UgPSAyO1xyXG4gICAgICBpZiAoYmFzZU91dCA9PSAxNikge1xyXG4gICAgICAgIHNkID0gc2QgKiA0IC0gMztcclxuICAgICAgfSBlbHNlIGlmIChiYXNlT3V0ID09IDgpIHtcclxuICAgICAgICBzZCA9IHNkICogMyAtIDI7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGJhc2UgPSBiYXNlT3V0O1xyXG4gICAgfVxyXG5cclxuICAgIC8vIENvbnZlcnQgdGhlIG51bWJlciBhcyBhbiBpbnRlZ2VyIHRoZW4gZGl2aWRlIHRoZSByZXN1bHQgYnkgaXRzIGJhc2UgcmFpc2VkIHRvIGEgcG93ZXIgc3VjaFxyXG4gICAgLy8gdGhhdCB0aGUgZnJhY3Rpb24gcGFydCB3aWxsIGJlIHJlc3RvcmVkLlxyXG5cclxuICAgIC8vIE5vbi1pbnRlZ2VyLlxyXG4gICAgaWYgKGkgPj0gMCkge1xyXG4gICAgICBzdHIgPSBzdHIucmVwbGFjZSgnLicsICcnKTtcclxuICAgICAgeSA9IG5ldyBDdG9yKDEpO1xyXG4gICAgICB5LmUgPSBzdHIubGVuZ3RoIC0gaTtcclxuICAgICAgeS5kID0gY29udmVydEJhc2UoZmluaXRlVG9TdHJpbmcoeSksIDEwLCBiYXNlKTtcclxuICAgICAgeS5lID0geS5kLmxlbmd0aDtcclxuICAgIH1cclxuXHJcbiAgICB4ZCA9IGNvbnZlcnRCYXNlKHN0ciwgMTAsIGJhc2UpO1xyXG4gICAgZSA9IGxlbiA9IHhkLmxlbmd0aDtcclxuXHJcbiAgICAvLyBSZW1vdmUgdHJhaWxpbmcgemVyb3MuXHJcbiAgICBmb3IgKDsgeGRbLS1sZW5dID09IDA7KSB4ZC5wb3AoKTtcclxuXHJcbiAgICBpZiAoIXhkWzBdKSB7XHJcbiAgICAgIHN0ciA9IGlzRXhwID8gJzBwKzAnIDogJzAnO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgaWYgKGkgPCAwKSB7XHJcbiAgICAgICAgZS0tO1xyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIHggPSBuZXcgQ3Rvcih4KTtcclxuICAgICAgICB4LmQgPSB4ZDtcclxuICAgICAgICB4LmUgPSBlO1xyXG4gICAgICAgIHggPSBkaXZpZGUoeCwgeSwgc2QsIHJtLCAwLCBiYXNlKTtcclxuICAgICAgICB4ZCA9IHguZDtcclxuICAgICAgICBlID0geC5lO1xyXG4gICAgICAgIHJvdW5kVXAgPSBpbmV4YWN0O1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBUaGUgcm91bmRpbmcgZGlnaXQsIGkuZS4gdGhlIGRpZ2l0IGFmdGVyIHRoZSBkaWdpdCB0aGF0IG1heSBiZSByb3VuZGVkIHVwLlxyXG4gICAgICBpID0geGRbc2RdO1xyXG4gICAgICBrID0gYmFzZSAvIDI7XHJcbiAgICAgIHJvdW5kVXAgPSByb3VuZFVwIHx8IHhkW3NkICsgMV0gIT09IHZvaWQgMDtcclxuXHJcbiAgICAgIHJvdW5kVXAgPSBybSA8IDRcclxuICAgICAgICA/IChpICE9PSB2b2lkIDAgfHwgcm91bmRVcCkgJiYgKHJtID09PSAwIHx8IHJtID09PSAoeC5zIDwgMCA/IDMgOiAyKSlcclxuICAgICAgICA6IGkgPiBrIHx8IGkgPT09IGsgJiYgKHJtID09PSA0IHx8IHJvdW5kVXAgfHwgcm0gPT09IDYgJiYgeGRbc2QgLSAxXSAmIDEgfHxcclxuICAgICAgICAgIHJtID09PSAoeC5zIDwgMCA/IDggOiA3KSk7XHJcblxyXG4gICAgICB4ZC5sZW5ndGggPSBzZDtcclxuXHJcbiAgICAgIGlmIChyb3VuZFVwKSB7XHJcblxyXG4gICAgICAgIC8vIFJvdW5kaW5nIHVwIG1heSBtZWFuIHRoZSBwcmV2aW91cyBkaWdpdCBoYXMgdG8gYmUgcm91bmRlZCB1cCBhbmQgc28gb24uXHJcbiAgICAgICAgZm9yICg7ICsreGRbLS1zZF0gPiBiYXNlIC0gMTspIHtcclxuICAgICAgICAgIHhkW3NkXSA9IDA7XHJcbiAgICAgICAgICBpZiAoIXNkKSB7XHJcbiAgICAgICAgICAgICsrZTtcclxuICAgICAgICAgICAgeGQudW5zaGlmdCgxKTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIERldGVybWluZSB0cmFpbGluZyB6ZXJvcy5cclxuICAgICAgZm9yIChsZW4gPSB4ZC5sZW5ndGg7ICF4ZFtsZW4gLSAxXTsgLS1sZW4pO1xyXG5cclxuICAgICAgLy8gRS5nLiBbNCwgMTEsIDE1XSBiZWNvbWVzIDRiZi5cclxuICAgICAgZm9yIChpID0gMCwgc3RyID0gJyc7IGkgPCBsZW47IGkrKykgc3RyICs9IE5VTUVSQUxTLmNoYXJBdCh4ZFtpXSk7XHJcblxyXG4gICAgICAvLyBBZGQgYmluYXJ5IGV4cG9uZW50IHN1ZmZpeD9cclxuICAgICAgaWYgKGlzRXhwKSB7XHJcbiAgICAgICAgaWYgKGxlbiA+IDEpIHtcclxuICAgICAgICAgIGlmIChiYXNlT3V0ID09IDE2IHx8IGJhc2VPdXQgPT0gOCkge1xyXG4gICAgICAgICAgICBpID0gYmFzZU91dCA9PSAxNiA/IDQgOiAzO1xyXG4gICAgICAgICAgICBmb3IgKC0tbGVuOyBsZW4gJSBpOyBsZW4rKykgc3RyICs9ICcwJztcclxuICAgICAgICAgICAgeGQgPSBjb252ZXJ0QmFzZShzdHIsIGJhc2UsIGJhc2VPdXQpO1xyXG4gICAgICAgICAgICBmb3IgKGxlbiA9IHhkLmxlbmd0aDsgIXhkW2xlbiAtIDFdOyAtLWxlbik7XHJcblxyXG4gICAgICAgICAgICAvLyB4ZFswXSB3aWxsIGFsd2F5cyBiZSBiZSAxXHJcbiAgICAgICAgICAgIGZvciAoaSA9IDEsIHN0ciA9ICcxLic7IGkgPCBsZW47IGkrKykgc3RyICs9IE5VTUVSQUxTLmNoYXJBdCh4ZFtpXSk7XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBzdHIgPSBzdHIuY2hhckF0KDApICsgJy4nICsgc3RyLnNsaWNlKDEpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc3RyID0gIHN0ciArIChlIDwgMCA/ICdwJyA6ICdwKycpICsgZTtcclxuICAgICAgfSBlbHNlIGlmIChlIDwgMCkge1xyXG4gICAgICAgIGZvciAoOyArK2U7KSBzdHIgPSAnMCcgKyBzdHI7XHJcbiAgICAgICAgc3RyID0gJzAuJyArIHN0cjtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBpZiAoKytlID4gbGVuKSBmb3IgKGUgLT0gbGVuOyBlLS0gOykgc3RyICs9ICcwJztcclxuICAgICAgICBlbHNlIGlmIChlIDwgbGVuKSBzdHIgPSBzdHIuc2xpY2UoMCwgZSkgKyAnLicgKyBzdHIuc2xpY2UoZSk7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBzdHIgPSAoYmFzZU91dCA9PSAxNiA/ICcweCcgOiBiYXNlT3V0ID09IDIgPyAnMGInIDogYmFzZU91dCA9PSA4ID8gJzBvJyA6ICcnKSArIHN0cjtcclxuICB9XHJcblxyXG4gIHJldHVybiB4LnMgPCAwID8gJy0nICsgc3RyIDogc3RyO1xyXG59XHJcblxyXG5cclxuLy8gRG9lcyBub3Qgc3RyaXAgdHJhaWxpbmcgemVyb3MuXHJcbmZ1bmN0aW9uIHRydW5jYXRlKGFyciwgbGVuKSB7XHJcbiAgaWYgKGFyci5sZW5ndGggPiBsZW4pIHtcclxuICAgIGFyci5sZW5ndGggPSBsZW47XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9XHJcbn1cclxuXHJcblxyXG4vLyBEZWNpbWFsIG1ldGhvZHNcclxuXHJcblxyXG4vKlxyXG4gKiAgYWJzXHJcbiAqICBhY29zXHJcbiAqICBhY29zaFxyXG4gKiAgYWRkXHJcbiAqICBhc2luXHJcbiAqICBhc2luaFxyXG4gKiAgYXRhblxyXG4gKiAgYXRhbmhcclxuICogIGF0YW4yXHJcbiAqICBjYnJ0XHJcbiAqICBjZWlsXHJcbiAqICBjbGFtcFxyXG4gKiAgY2xvbmVcclxuICogIGNvbmZpZ1xyXG4gKiAgY29zXHJcbiAqICBjb3NoXHJcbiAqICBkaXZcclxuICogIGV4cFxyXG4gKiAgZmxvb3JcclxuICogIGh5cG90XHJcbiAqICBsblxyXG4gKiAgbG9nXHJcbiAqICBsb2cyXHJcbiAqICBsb2cxMFxyXG4gKiAgbWF4XHJcbiAqICBtaW5cclxuICogIG1vZFxyXG4gKiAgbXVsXHJcbiAqICBwb3dcclxuICogIHJhbmRvbVxyXG4gKiAgcm91bmRcclxuICogIHNldFxyXG4gKiAgc2lnblxyXG4gKiAgc2luXHJcbiAqICBzaW5oXHJcbiAqICBzcXJ0XHJcbiAqICBzdWJcclxuICogIHN1bVxyXG4gKiAgdGFuXHJcbiAqICB0YW5oXHJcbiAqICB0cnVuY1xyXG4gKi9cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgYWJzb2x1dGUgdmFsdWUgb2YgYHhgLlxyXG4gKlxyXG4gKiB4IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfVxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gYWJzKHgpIHtcclxuICByZXR1cm4gbmV3IHRoaXMoeCkuYWJzKCk7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgYXJjY29zaW5lIGluIHJhZGlhbnMgb2YgYHhgLlxyXG4gKlxyXG4gKiB4IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfVxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gYWNvcyh4KSB7XHJcbiAgcmV0dXJuIG5ldyB0aGlzKHgpLmFjb3MoKTtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBpbnZlcnNlIG9mIHRoZSBoeXBlcmJvbGljIGNvc2luZSBvZiBgeGAsIHJvdW5kZWQgdG9cclxuICogYHByZWNpc2lvbmAgc2lnbmlmaWNhbnQgZGlnaXRzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJvdW5kaW5nYC5cclxuICpcclxuICogeCB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH0gQSB2YWx1ZSBpbiByYWRpYW5zLlxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gYWNvc2goeCkge1xyXG4gIHJldHVybiBuZXcgdGhpcyh4KS5hY29zaCgpO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIHN1bSBvZiBgeGAgYW5kIGB5YCwgcm91bmRlZCB0byBgcHJlY2lzaW9uYCBzaWduaWZpY2FudFxyXG4gKiBkaWdpdHMgdXNpbmcgcm91bmRpbmcgbW9kZSBgcm91bmRpbmdgLlxyXG4gKlxyXG4gKiB4IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfVxyXG4gKiB5IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfVxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gYWRkKHgsIHkpIHtcclxuICByZXR1cm4gbmV3IHRoaXMoeCkucGx1cyh5KTtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBhcmNzaW5lIGluIHJhZGlhbnMgb2YgYHhgLCByb3VuZGVkIHRvIGBwcmVjaXNpb25gXHJcbiAqIHNpZ25pZmljYW50IGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqIHgge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9XHJcbiAqXHJcbiAqL1xyXG5mdW5jdGlvbiBhc2luKHgpIHtcclxuICByZXR1cm4gbmV3IHRoaXMoeCkuYXNpbigpO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIGludmVyc2Ugb2YgdGhlIGh5cGVyYm9saWMgc2luZSBvZiBgeGAsIHJvdW5kZWQgdG9cclxuICogYHByZWNpc2lvbmAgc2lnbmlmaWNhbnQgZGlnaXRzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJvdW5kaW5nYC5cclxuICpcclxuICogeCB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH0gQSB2YWx1ZSBpbiByYWRpYW5zLlxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gYXNpbmgoeCkge1xyXG4gIHJldHVybiBuZXcgdGhpcyh4KS5hc2luaCgpO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIGFyY3RhbmdlbnQgaW4gcmFkaWFucyBvZiBgeGAsIHJvdW5kZWQgdG8gYHByZWNpc2lvbmBcclxuICogc2lnbmlmaWNhbnQgZGlnaXRzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJvdW5kaW5nYC5cclxuICpcclxuICogeCB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH1cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIGF0YW4oeCkge1xyXG4gIHJldHVybiBuZXcgdGhpcyh4KS5hdGFuKCk7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgaW52ZXJzZSBvZiB0aGUgaHlwZXJib2xpYyB0YW5nZW50IG9mIGB4YCwgcm91bmRlZCB0b1xyXG4gKiBgcHJlY2lzaW9uYCBzaWduaWZpY2FudCBkaWdpdHMgdXNpbmcgcm91bmRpbmcgbW9kZSBgcm91bmRpbmdgLlxyXG4gKlxyXG4gKiB4IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfSBBIHZhbHVlIGluIHJhZGlhbnMuXHJcbiAqXHJcbiAqL1xyXG5mdW5jdGlvbiBhdGFuaCh4KSB7XHJcbiAgcmV0dXJuIG5ldyB0aGlzKHgpLmF0YW5oKCk7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgYXJjdGFuZ2VudCBpbiByYWRpYW5zIG9mIGB5L3hgIGluIHRoZSByYW5nZSAtcGkgdG8gcGlcclxuICogKGluY2x1c2l2ZSksIHJvdW5kZWQgdG8gYHByZWNpc2lvbmAgc2lnbmlmaWNhbnQgZGlnaXRzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJvdW5kaW5nYC5cclxuICpcclxuICogRG9tYWluOiBbLUluZmluaXR5LCBJbmZpbml0eV1cclxuICogUmFuZ2U6IFstcGksIHBpXVxyXG4gKlxyXG4gKiB5IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfSBUaGUgeS1jb29yZGluYXRlLlxyXG4gKiB4IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfSBUaGUgeC1jb29yZGluYXRlLlxyXG4gKlxyXG4gKiBhdGFuMijCsTAsIC0wKSAgICAgICAgICAgICAgID0gwrFwaVxyXG4gKiBhdGFuMijCsTAsICswKSAgICAgICAgICAgICAgID0gwrEwXHJcbiAqIGF0YW4yKMKxMCwgLXgpICAgICAgICAgICAgICAgPSDCsXBpIGZvciB4ID4gMFxyXG4gKiBhdGFuMijCsTAsIHgpICAgICAgICAgICAgICAgID0gwrEwIGZvciB4ID4gMFxyXG4gKiBhdGFuMigteSwgwrEwKSAgICAgICAgICAgICAgID0gLXBpLzIgZm9yIHkgPiAwXHJcbiAqIGF0YW4yKHksIMKxMCkgICAgICAgICAgICAgICAgPSBwaS8yIGZvciB5ID4gMFxyXG4gKiBhdGFuMijCsXksIC1JbmZpbml0eSkgICAgICAgID0gwrFwaSBmb3IgZmluaXRlIHkgPiAwXHJcbiAqIGF0YW4yKMKxeSwgK0luZmluaXR5KSAgICAgICAgPSDCsTAgZm9yIGZpbml0ZSB5ID4gMFxyXG4gKiBhdGFuMijCsUluZmluaXR5LCB4KSAgICAgICAgID0gwrFwaS8yIGZvciBmaW5pdGUgeFxyXG4gKiBhdGFuMijCsUluZmluaXR5LCAtSW5maW5pdHkpID0gwrEzKnBpLzRcclxuICogYXRhbjIowrFJbmZpbml0eSwgK0luZmluaXR5KSA9IMKxcGkvNFxyXG4gKiBhdGFuMihOYU4sIHgpID0gTmFOXHJcbiAqIGF0YW4yKHksIE5hTikgPSBOYU5cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIGF0YW4yKHksIHgpIHtcclxuICB5ID0gbmV3IHRoaXMoeSk7XHJcbiAgeCA9IG5ldyB0aGlzKHgpO1xyXG4gIHZhciByLFxyXG4gICAgcHIgPSB0aGlzLnByZWNpc2lvbixcclxuICAgIHJtID0gdGhpcy5yb3VuZGluZyxcclxuICAgIHdwciA9IHByICsgNDtcclxuXHJcbiAgLy8gRWl0aGVyIE5hTlxyXG4gIGlmICgheS5zIHx8ICF4LnMpIHtcclxuICAgIHIgPSBuZXcgdGhpcyhOYU4pO1xyXG5cclxuICAvLyBCb3RoIMKxSW5maW5pdHlcclxuICB9IGVsc2UgaWYgKCF5LmQgJiYgIXguZCkge1xyXG4gICAgciA9IGdldFBpKHRoaXMsIHdwciwgMSkudGltZXMoeC5zID4gMCA/IDAuMjUgOiAwLjc1KTtcclxuICAgIHIucyA9IHkucztcclxuXHJcbiAgLy8geCBpcyDCsUluZmluaXR5IG9yIHkgaXMgwrEwXHJcbiAgfSBlbHNlIGlmICgheC5kIHx8IHkuaXNaZXJvKCkpIHtcclxuICAgIHIgPSB4LnMgPCAwID8gZ2V0UGkodGhpcywgcHIsIHJtKSA6IG5ldyB0aGlzKDApO1xyXG4gICAgci5zID0geS5zO1xyXG5cclxuICAvLyB5IGlzIMKxSW5maW5pdHkgb3IgeCBpcyDCsTBcclxuICB9IGVsc2UgaWYgKCF5LmQgfHwgeC5pc1plcm8oKSkge1xyXG4gICAgciA9IGdldFBpKHRoaXMsIHdwciwgMSkudGltZXMoMC41KTtcclxuICAgIHIucyA9IHkucztcclxuXHJcbiAgLy8gQm90aCBub24temVybyBhbmQgZmluaXRlXHJcbiAgfSBlbHNlIGlmICh4LnMgPCAwKSB7XHJcbiAgICB0aGlzLnByZWNpc2lvbiA9IHdwcjtcclxuICAgIHRoaXMucm91bmRpbmcgPSAxO1xyXG4gICAgciA9IHRoaXMuYXRhbihkaXZpZGUoeSwgeCwgd3ByLCAxKSk7XHJcbiAgICB4ID0gZ2V0UGkodGhpcywgd3ByLCAxKTtcclxuICAgIHRoaXMucHJlY2lzaW9uID0gcHI7XHJcbiAgICB0aGlzLnJvdW5kaW5nID0gcm07XHJcbiAgICByID0geS5zIDwgMCA/IHIubWludXMoeCkgOiByLnBsdXMoeCk7XHJcbiAgfSBlbHNlIHtcclxuICAgIHIgPSB0aGlzLmF0YW4oZGl2aWRlKHksIHgsIHdwciwgMSkpO1xyXG4gIH1cclxuXHJcbiAgcmV0dXJuIHI7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgY3ViZSByb290IG9mIGB4YCwgcm91bmRlZCB0byBgcHJlY2lzaW9uYCBzaWduaWZpY2FudFxyXG4gKiBkaWdpdHMgdXNpbmcgcm91bmRpbmcgbW9kZSBgcm91bmRpbmdgLlxyXG4gKlxyXG4gKiB4IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfVxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gY2JydCh4KSB7XHJcbiAgcmV0dXJuIG5ldyB0aGlzKHgpLmNicnQoKTtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIGB4YCByb3VuZGVkIHRvIGFuIGludGVnZXIgdXNpbmcgYFJPVU5EX0NFSUxgLlxyXG4gKlxyXG4gKiB4IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfVxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gY2VpbCh4KSB7XHJcbiAgcmV0dXJuIGZpbmFsaXNlKHggPSBuZXcgdGhpcyh4KSwgeC5lICsgMSwgMik7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyBgeGAgY2xhbXBlZCB0byB0aGUgcmFuZ2UgZGVsaW5lYXRlZCBieSBgbWluYCBhbmQgYG1heGAuXHJcbiAqXHJcbiAqIHgge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9XHJcbiAqIG1pbiB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH1cclxuICogbWF4IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfVxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gY2xhbXAoeCwgbWluLCBtYXgpIHtcclxuICByZXR1cm4gbmV3IHRoaXMoeCkuY2xhbXAobWluLCBtYXgpO1xyXG59XHJcblxyXG5cclxuLypcclxuICogQ29uZmlndXJlIGdsb2JhbCBzZXR0aW5ncyBmb3IgYSBEZWNpbWFsIGNvbnN0cnVjdG9yLlxyXG4gKlxyXG4gKiBgb2JqYCBpcyBhbiBvYmplY3Qgd2l0aCBvbmUgb3IgbW9yZSBvZiB0aGUgZm9sbG93aW5nIHByb3BlcnRpZXMsXHJcbiAqXHJcbiAqICAgcHJlY2lzaW9uICB7bnVtYmVyfVxyXG4gKiAgIHJvdW5kaW5nICAge251bWJlcn1cclxuICogICB0b0V4cE5lZyAgIHtudW1iZXJ9XHJcbiAqICAgdG9FeHBQb3MgICB7bnVtYmVyfVxyXG4gKiAgIG1heEUgICAgICAge251bWJlcn1cclxuICogICBtaW5FICAgICAgIHtudW1iZXJ9XHJcbiAqICAgbW9kdWxvICAgICB7bnVtYmVyfVxyXG4gKiAgIGNyeXB0byAgICAge2Jvb2xlYW58bnVtYmVyfVxyXG4gKiAgIGRlZmF1bHRzICAge3RydWV9XHJcbiAqXHJcbiAqIEUuZy4gRGVjaW1hbC5jb25maWcoeyBwcmVjaXNpb246IDIwLCByb3VuZGluZzogNCB9KVxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gY29uZmlnKG9iaikge1xyXG4gIGlmICghb2JqIHx8IHR5cGVvZiBvYmogIT09ICdvYmplY3QnKSB0aHJvdyBFcnJvcihkZWNpbWFsRXJyb3IgKyAnT2JqZWN0IGV4cGVjdGVkJyk7XHJcbiAgdmFyIGksIHAsIHYsXHJcbiAgICB1c2VEZWZhdWx0cyA9IG9iai5kZWZhdWx0cyA9PT0gdHJ1ZSxcclxuICAgIHBzID0gW1xyXG4gICAgICAncHJlY2lzaW9uJywgMSwgTUFYX0RJR0lUUyxcclxuICAgICAgJ3JvdW5kaW5nJywgMCwgOCxcclxuICAgICAgJ3RvRXhwTmVnJywgLUVYUF9MSU1JVCwgMCxcclxuICAgICAgJ3RvRXhwUG9zJywgMCwgRVhQX0xJTUlULFxyXG4gICAgICAnbWF4RScsIDAsIEVYUF9MSU1JVCxcclxuICAgICAgJ21pbkUnLCAtRVhQX0xJTUlULCAwLFxyXG4gICAgICAnbW9kdWxvJywgMCwgOVxyXG4gICAgXTtcclxuXHJcbiAgZm9yIChpID0gMDsgaSA8IHBzLmxlbmd0aDsgaSArPSAzKSB7XHJcbiAgICBpZiAocCA9IHBzW2ldLCB1c2VEZWZhdWx0cykgdGhpc1twXSA9IERFRkFVTFRTW3BdO1xyXG4gICAgaWYgKCh2ID0gb2JqW3BdKSAhPT0gdm9pZCAwKSB7XHJcbiAgICAgIGlmIChtYXRoZmxvb3IodikgPT09IHYgJiYgdiA+PSBwc1tpICsgMV0gJiYgdiA8PSBwc1tpICsgMl0pIHRoaXNbcF0gPSB2O1xyXG4gICAgICBlbHNlIHRocm93IEVycm9yKGludmFsaWRBcmd1bWVudCArIHAgKyAnOiAnICsgdik7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBpZiAocCA9ICdjcnlwdG8nLCB1c2VEZWZhdWx0cykgdGhpc1twXSA9IERFRkFVTFRTW3BdO1xyXG4gIGlmICgodiA9IG9ialtwXSkgIT09IHZvaWQgMCkge1xyXG4gICAgaWYgKHYgPT09IHRydWUgfHwgdiA9PT0gZmFsc2UgfHwgdiA9PT0gMCB8fCB2ID09PSAxKSB7XHJcbiAgICAgIGlmICh2KSB7XHJcbiAgICAgICAgaWYgKHR5cGVvZiBjcnlwdG8gIT0gJ3VuZGVmaW5lZCcgJiYgY3J5cHRvICYmXHJcbiAgICAgICAgICAoY3J5cHRvLmdldFJhbmRvbVZhbHVlcyB8fCBjcnlwdG8ucmFuZG9tQnl0ZXMpKSB7XHJcbiAgICAgICAgICB0aGlzW3BdID0gdHJ1ZTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhyb3cgRXJyb3IoY3J5cHRvVW5hdmFpbGFibGUpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB0aGlzW3BdID0gZmFsc2U7XHJcbiAgICAgIH1cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRocm93IEVycm9yKGludmFsaWRBcmd1bWVudCArIHAgKyAnOiAnICsgdik7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gdGhpcztcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBjb3NpbmUgb2YgYHhgLCByb3VuZGVkIHRvIGBwcmVjaXNpb25gIHNpZ25pZmljYW50XHJcbiAqIGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqIHgge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9IEEgdmFsdWUgaW4gcmFkaWFucy5cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIGNvcyh4KSB7XHJcbiAgcmV0dXJuIG5ldyB0aGlzKHgpLmNvcygpO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIGh5cGVyYm9saWMgY29zaW5lIG9mIGB4YCwgcm91bmRlZCB0byBwcmVjaXNpb25cclxuICogc2lnbmlmaWNhbnQgZGlnaXRzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJvdW5kaW5nYC5cclxuICpcclxuICogeCB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH0gQSB2YWx1ZSBpbiByYWRpYW5zLlxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gY29zaCh4KSB7XHJcbiAgcmV0dXJuIG5ldyB0aGlzKHgpLmNvc2goKTtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIENyZWF0ZSBhbmQgcmV0dXJuIGEgRGVjaW1hbCBjb25zdHJ1Y3RvciB3aXRoIHRoZSBzYW1lIGNvbmZpZ3VyYXRpb24gcHJvcGVydGllcyBhcyB0aGlzIERlY2ltYWxcclxuICogY29uc3RydWN0b3IuXHJcbiAqXHJcbiAqL1xyXG5mdW5jdGlvbiBjbG9uZShvYmopIHtcclxuICB2YXIgaSwgcCwgcHM7XHJcblxyXG4gIC8qXHJcbiAgICogVGhlIERlY2ltYWwgY29uc3RydWN0b3IgYW5kIGV4cG9ydGVkIGZ1bmN0aW9uLlxyXG4gICAqIFJldHVybiBhIG5ldyBEZWNpbWFsIGluc3RhbmNlLlxyXG4gICAqXHJcbiAgICogdiB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH0gQSBudW1lcmljIHZhbHVlLlxyXG4gICAqXHJcbiAgICovXHJcbiAgZnVuY3Rpb24gRGVjaW1hbCh2KSB7XHJcbiAgICB2YXIgZSwgaSwgdCxcclxuICAgICAgeCA9IHRoaXM7XHJcblxyXG4gICAgLy8gRGVjaW1hbCBjYWxsZWQgd2l0aG91dCBuZXcuXHJcbiAgICBpZiAoISh4IGluc3RhbmNlb2YgRGVjaW1hbCkpIHJldHVybiBuZXcgRGVjaW1hbCh2KTtcclxuXHJcbiAgICAvLyBSZXRhaW4gYSByZWZlcmVuY2UgdG8gdGhpcyBEZWNpbWFsIGNvbnN0cnVjdG9yLCBhbmQgc2hhZG93IERlY2ltYWwucHJvdG90eXBlLmNvbnN0cnVjdG9yXHJcbiAgICAvLyB3aGljaCBwb2ludHMgdG8gT2JqZWN0LlxyXG4gICAgeC5jb25zdHJ1Y3RvciA9IERlY2ltYWw7XHJcblxyXG4gICAgaWYgKGlzRGVjaW1hbEluc3RhbmNlKHYpKSB7XHJcbiAgICAgIHgucyA9IHYucztcclxuXHJcbiAgICAgIGlmIChleHRlcm5hbCkge1xyXG4gICAgICAgIGlmICghdi5kIHx8IHYuZSA+IERlY2ltYWwubWF4RSkge1xyXG5cclxuICAgICAgICAgIC8vIEluZmluaXR5LlxyXG4gICAgICAgICAgeC5lID0gTmFOO1xyXG4gICAgICAgICAgeC5kID0gbnVsbDtcclxuICAgICAgICB9IGVsc2UgaWYgKHYuZSA8IERlY2ltYWwubWluRSkge1xyXG5cclxuICAgICAgICAgIC8vIFplcm8uXHJcbiAgICAgICAgICB4LmUgPSAwO1xyXG4gICAgICAgICAgeC5kID0gWzBdO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICB4LmUgPSB2LmU7XHJcbiAgICAgICAgICB4LmQgPSB2LmQuc2xpY2UoKTtcclxuICAgICAgICB9XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgeC5lID0gdi5lO1xyXG4gICAgICAgIHguZCA9IHYuZCA/IHYuZC5zbGljZSgpIDogdi5kO1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdCA9IHR5cGVvZiB2O1xyXG5cclxuICAgIGlmICh0ID09PSAnbnVtYmVyJykge1xyXG4gICAgICBpZiAodiA9PT0gMCkge1xyXG4gICAgICAgIHgucyA9IDEgLyB2IDwgMCA/IC0xIDogMTtcclxuICAgICAgICB4LmUgPSAwO1xyXG4gICAgICAgIHguZCA9IFswXTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGlmICh2IDwgMCkge1xyXG4gICAgICAgIHYgPSAtdjtcclxuICAgICAgICB4LnMgPSAtMTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB4LnMgPSAxO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyBGYXN0IHBhdGggZm9yIHNtYWxsIGludGVnZXJzLlxyXG4gICAgICBpZiAodiA9PT0gfn52ICYmIHYgPCAxZTcpIHtcclxuICAgICAgICBmb3IgKGUgPSAwLCBpID0gdjsgaSA+PSAxMDsgaSAvPSAxMCkgZSsrO1xyXG5cclxuICAgICAgICBpZiAoZXh0ZXJuYWwpIHtcclxuICAgICAgICAgIGlmIChlID4gRGVjaW1hbC5tYXhFKSB7XHJcbiAgICAgICAgICAgIHguZSA9IE5hTjtcclxuICAgICAgICAgICAgeC5kID0gbnVsbDtcclxuICAgICAgICAgIH0gZWxzZSBpZiAoZSA8IERlY2ltYWwubWluRSkge1xyXG4gICAgICAgICAgICB4LmUgPSAwO1xyXG4gICAgICAgICAgICB4LmQgPSBbMF07XHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICB4LmUgPSBlO1xyXG4gICAgICAgICAgICB4LmQgPSBbdl07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIHguZSA9IGU7XHJcbiAgICAgICAgICB4LmQgPSBbdl07XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIEluZmluaXR5IG9yIE5hTj9cclxuICAgICAgaWYgKHYgKiAwICE9PSAwKSB7XHJcbiAgICAgICAgaWYgKCF2KSB4LnMgPSBOYU47XHJcbiAgICAgICAgeC5lID0gTmFOO1xyXG4gICAgICAgIHguZCA9IG51bGw7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4gcGFyc2VEZWNpbWFsKHgsIHYudG9TdHJpbmcoKSk7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHQgPT09ICdzdHJpbmcnKSB7XHJcbiAgICAgIGlmICgoaSA9IHYuY2hhckNvZGVBdCgwKSkgPT09IDQ1KSB7ICAvLyBtaW51cyBzaWduXHJcbiAgICAgICAgdiA9IHYuc2xpY2UoMSk7XHJcbiAgICAgICAgeC5zID0gLTE7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgaWYgKGkgPT09IDQzKSB2ID0gdi5zbGljZSgxKTsgIC8vIHBsdXMgc2lnblxyXG4gICAgICAgIHgucyA9IDE7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHJldHVybiBpc0RlY2ltYWwudGVzdCh2KSA/IHBhcnNlRGVjaW1hbCh4LCB2KSA6IHBhcnNlT3RoZXIoeCwgdik7XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKHQgPT09ICdiaWdpbnQnKSB7XHJcbiAgICAgIGlmICh2IDwgMCkge1xyXG4gICAgICAgIHYgPSAtdjtcclxuICAgICAgICB4LnMgPSAtMTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICB4LnMgPSAxO1xyXG4gICAgICB9XHJcblxyXG4gICAgICByZXR1cm4gcGFyc2VEZWNpbWFsKHgsIHYudG9TdHJpbmcoKSk7XHJcbiAgICB9XHJcblxyXG4gICAgdGhyb3cgRXJyb3IoaW52YWxpZEFyZ3VtZW50ICsgdik7XHJcbiAgfVxyXG5cclxuICBEZWNpbWFsLnByb3RvdHlwZSA9IFA7XHJcblxyXG4gIERlY2ltYWwuUk9VTkRfVVAgPSAwO1xyXG4gIERlY2ltYWwuUk9VTkRfRE9XTiA9IDE7XHJcbiAgRGVjaW1hbC5ST1VORF9DRUlMID0gMjtcclxuICBEZWNpbWFsLlJPVU5EX0ZMT09SID0gMztcclxuICBEZWNpbWFsLlJPVU5EX0hBTEZfVVAgPSA0O1xyXG4gIERlY2ltYWwuUk9VTkRfSEFMRl9ET1dOID0gNTtcclxuICBEZWNpbWFsLlJPVU5EX0hBTEZfRVZFTiA9IDY7XHJcbiAgRGVjaW1hbC5ST1VORF9IQUxGX0NFSUwgPSA3O1xyXG4gIERlY2ltYWwuUk9VTkRfSEFMRl9GTE9PUiA9IDg7XHJcbiAgRGVjaW1hbC5FVUNMSUQgPSA5O1xyXG5cclxuICBEZWNpbWFsLmNvbmZpZyA9IERlY2ltYWwuc2V0ID0gY29uZmlnO1xyXG4gIERlY2ltYWwuY2xvbmUgPSBjbG9uZTtcclxuICBEZWNpbWFsLmlzRGVjaW1hbCA9IGlzRGVjaW1hbEluc3RhbmNlO1xyXG5cclxuICBEZWNpbWFsLmFicyA9IGFicztcclxuICBEZWNpbWFsLmFjb3MgPSBhY29zO1xyXG4gIERlY2ltYWwuYWNvc2ggPSBhY29zaDsgICAgICAgIC8vIEVTNlxyXG4gIERlY2ltYWwuYWRkID0gYWRkO1xyXG4gIERlY2ltYWwuYXNpbiA9IGFzaW47XHJcbiAgRGVjaW1hbC5hc2luaCA9IGFzaW5oOyAgICAgICAgLy8gRVM2XHJcbiAgRGVjaW1hbC5hdGFuID0gYXRhbjtcclxuICBEZWNpbWFsLmF0YW5oID0gYXRhbmg7ICAgICAgICAvLyBFUzZcclxuICBEZWNpbWFsLmF0YW4yID0gYXRhbjI7XHJcbiAgRGVjaW1hbC5jYnJ0ID0gY2JydDsgICAgICAgICAgLy8gRVM2XHJcbiAgRGVjaW1hbC5jZWlsID0gY2VpbDtcclxuICBEZWNpbWFsLmNsYW1wID0gY2xhbXA7XHJcbiAgRGVjaW1hbC5jb3MgPSBjb3M7XHJcbiAgRGVjaW1hbC5jb3NoID0gY29zaDsgICAgICAgICAgLy8gRVM2XHJcbiAgRGVjaW1hbC5kaXYgPSBkaXY7XHJcbiAgRGVjaW1hbC5leHAgPSBleHA7XHJcbiAgRGVjaW1hbC5mbG9vciA9IGZsb29yO1xyXG4gIERlY2ltYWwuaHlwb3QgPSBoeXBvdDsgICAgICAgIC8vIEVTNlxyXG4gIERlY2ltYWwubG4gPSBsbjtcclxuICBEZWNpbWFsLmxvZyA9IGxvZztcclxuICBEZWNpbWFsLmxvZzEwID0gbG9nMTA7ICAgICAgICAvLyBFUzZcclxuICBEZWNpbWFsLmxvZzIgPSBsb2cyOyAgICAgICAgICAvLyBFUzZcclxuICBEZWNpbWFsLm1heCA9IG1heDtcclxuICBEZWNpbWFsLm1pbiA9IG1pbjtcclxuICBEZWNpbWFsLm1vZCA9IG1vZDtcclxuICBEZWNpbWFsLm11bCA9IG11bDtcclxuICBEZWNpbWFsLnBvdyA9IHBvdztcclxuICBEZWNpbWFsLnJhbmRvbSA9IHJhbmRvbTtcclxuICBEZWNpbWFsLnJvdW5kID0gcm91bmQ7XHJcbiAgRGVjaW1hbC5zaWduID0gc2lnbjsgICAgICAgICAgLy8gRVM2XHJcbiAgRGVjaW1hbC5zaW4gPSBzaW47XHJcbiAgRGVjaW1hbC5zaW5oID0gc2luaDsgICAgICAgICAgLy8gRVM2XHJcbiAgRGVjaW1hbC5zcXJ0ID0gc3FydDtcclxuICBEZWNpbWFsLnN1YiA9IHN1YjtcclxuICBEZWNpbWFsLnN1bSA9IHN1bTtcclxuICBEZWNpbWFsLnRhbiA9IHRhbjtcclxuICBEZWNpbWFsLnRhbmggPSB0YW5oOyAgICAgICAgICAvLyBFUzZcclxuICBEZWNpbWFsLnRydW5jID0gdHJ1bmM7ICAgICAgICAvLyBFUzZcclxuXHJcbiAgaWYgKG9iaiA9PT0gdm9pZCAwKSBvYmogPSB7fTtcclxuICBpZiAob2JqKSB7XHJcbiAgICBpZiAob2JqLmRlZmF1bHRzICE9PSB0cnVlKSB7XHJcbiAgICAgIHBzID0gWydwcmVjaXNpb24nLCAncm91bmRpbmcnLCAndG9FeHBOZWcnLCAndG9FeHBQb3MnLCAnbWF4RScsICdtaW5FJywgJ21vZHVsbycsICdjcnlwdG8nXTtcclxuICAgICAgZm9yIChpID0gMDsgaSA8IHBzLmxlbmd0aDspIGlmICghb2JqLmhhc093blByb3BlcnR5KHAgPSBwc1tpKytdKSkgb2JqW3BdID0gdGhpc1twXTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIERlY2ltYWwuY29uZmlnKG9iaik7XHJcblxyXG4gIHJldHVybiBEZWNpbWFsO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgYHhgIGRpdmlkZWQgYnkgYHlgLCByb3VuZGVkIHRvIGBwcmVjaXNpb25gIHNpZ25pZmljYW50XHJcbiAqIGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqIHgge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9XHJcbiAqIHkge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9XHJcbiAqXHJcbiAqL1xyXG5mdW5jdGlvbiBkaXYoeCwgeSkge1xyXG4gIHJldHVybiBuZXcgdGhpcyh4KS5kaXYoeSk7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgbmF0dXJhbCBleHBvbmVudGlhbCBvZiBgeGAsIHJvdW5kZWQgdG8gYHByZWNpc2lvbmBcclxuICogc2lnbmlmaWNhbnQgZGlnaXRzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJvdW5kaW5nYC5cclxuICpcclxuICogeCB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH0gVGhlIHBvd2VyIHRvIHdoaWNoIHRvIHJhaXNlIHRoZSBiYXNlIG9mIHRoZSBuYXR1cmFsIGxvZy5cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIGV4cCh4KSB7XHJcbiAgcmV0dXJuIG5ldyB0aGlzKHgpLmV4cCgpO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgYHhgIHJvdW5kIHRvIGFuIGludGVnZXIgdXNpbmcgYFJPVU5EX0ZMT09SYC5cclxuICpcclxuICogeCB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH1cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIGZsb29yKHgpIHtcclxuICByZXR1cm4gZmluYWxpc2UoeCA9IG5ldyB0aGlzKHgpLCB4LmUgKyAxLCAzKTtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBzcXVhcmUgcm9vdCBvZiB0aGUgc3VtIG9mIHRoZSBzcXVhcmVzIG9mIHRoZSBhcmd1bWVudHMsXHJcbiAqIHJvdW5kZWQgdG8gYHByZWNpc2lvbmAgc2lnbmlmaWNhbnQgZGlnaXRzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJvdW5kaW5nYC5cclxuICpcclxuICogaHlwb3QoYSwgYiwgLi4uKSA9IHNxcnQoYV4yICsgYl4yICsgLi4uKVxyXG4gKlxyXG4gKiBhcmd1bWVudHMge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9XHJcbiAqXHJcbiAqL1xyXG5mdW5jdGlvbiBoeXBvdCgpIHtcclxuICB2YXIgaSwgbixcclxuICAgIHQgPSBuZXcgdGhpcygwKTtcclxuXHJcbiAgZXh0ZXJuYWwgPSBmYWxzZTtcclxuXHJcbiAgZm9yIChpID0gMDsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7KSB7XHJcbiAgICBuID0gbmV3IHRoaXMoYXJndW1lbnRzW2krK10pO1xyXG4gICAgaWYgKCFuLmQpIHtcclxuICAgICAgaWYgKG4ucykge1xyXG4gICAgICAgIGV4dGVybmFsID0gdHJ1ZTtcclxuICAgICAgICByZXR1cm4gbmV3IHRoaXMoMSAvIDApO1xyXG4gICAgICB9XHJcbiAgICAgIHQgPSBuO1xyXG4gICAgfSBlbHNlIGlmICh0LmQpIHtcclxuICAgICAgdCA9IHQucGx1cyhuLnRpbWVzKG4pKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGV4dGVybmFsID0gdHJ1ZTtcclxuXHJcbiAgcmV0dXJuIHQuc3FydCgpO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIHRydWUgaWYgb2JqZWN0IGlzIGEgRGVjaW1hbCBpbnN0YW5jZSAod2hlcmUgRGVjaW1hbCBpcyBhbnkgRGVjaW1hbCBjb25zdHJ1Y3RvciksXHJcbiAqIG90aGVyd2lzZSByZXR1cm4gZmFsc2UuXHJcbiAqXHJcbiAqL1xyXG5mdW5jdGlvbiBpc0RlY2ltYWxJbnN0YW5jZShvYmopIHtcclxuICByZXR1cm4gb2JqIGluc3RhbmNlb2YgRGVjaW1hbCB8fCBvYmogJiYgb2JqLnRvU3RyaW5nVGFnID09PSB0YWcgfHwgZmFsc2U7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgbmF0dXJhbCBsb2dhcml0aG0gb2YgYHhgLCByb3VuZGVkIHRvIGBwcmVjaXNpb25gXHJcbiAqIHNpZ25pZmljYW50IGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqIHgge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9XHJcbiAqXHJcbiAqL1xyXG5mdW5jdGlvbiBsbih4KSB7XHJcbiAgcmV0dXJuIG5ldyB0aGlzKHgpLmxuKCk7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgbG9nIG9mIGB4YCB0byB0aGUgYmFzZSBgeWAsIG9yIHRvIGJhc2UgMTAgaWYgbm8gYmFzZVxyXG4gKiBpcyBzcGVjaWZpZWQsIHJvdW5kZWQgdG8gYHByZWNpc2lvbmAgc2lnbmlmaWNhbnQgZGlnaXRzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJvdW5kaW5nYC5cclxuICpcclxuICogbG9nW3ldKHgpXHJcbiAqXHJcbiAqIHgge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9IFRoZSBhcmd1bWVudCBvZiB0aGUgbG9nYXJpdGhtLlxyXG4gKiB5IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfSBUaGUgYmFzZSBvZiB0aGUgbG9nYXJpdGhtLlxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gbG9nKHgsIHkpIHtcclxuICByZXR1cm4gbmV3IHRoaXMoeCkubG9nKHkpO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIGJhc2UgMiBsb2dhcml0aG0gb2YgYHhgLCByb3VuZGVkIHRvIGBwcmVjaXNpb25gXHJcbiAqIHNpZ25pZmljYW50IGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqIHgge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9XHJcbiAqXHJcbiAqL1xyXG5mdW5jdGlvbiBsb2cyKHgpIHtcclxuICByZXR1cm4gbmV3IHRoaXMoeCkubG9nKDIpO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIGJhc2UgMTAgbG9nYXJpdGhtIG9mIGB4YCwgcm91bmRlZCB0byBgcHJlY2lzaW9uYFxyXG4gKiBzaWduaWZpY2FudCBkaWdpdHMgdXNpbmcgcm91bmRpbmcgbW9kZSBgcm91bmRpbmdgLlxyXG4gKlxyXG4gKiB4IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfVxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gbG9nMTAoeCkge1xyXG4gIHJldHVybiBuZXcgdGhpcyh4KS5sb2coMTApO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIG1heGltdW0gb2YgdGhlIGFyZ3VtZW50cy5cclxuICpcclxuICogYXJndW1lbnRzIHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfVxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gbWF4KCkge1xyXG4gIHJldHVybiBtYXhPck1pbih0aGlzLCBhcmd1bWVudHMsIC0xKTtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBtaW5pbXVtIG9mIHRoZSBhcmd1bWVudHMuXHJcbiAqXHJcbiAqIGFyZ3VtZW50cyB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH1cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIG1pbigpIHtcclxuICByZXR1cm4gbWF4T3JNaW4odGhpcywgYXJndW1lbnRzLCAxKTtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIGB4YCBtb2R1bG8gYHlgLCByb3VuZGVkIHRvIGBwcmVjaXNpb25gIHNpZ25pZmljYW50IGRpZ2l0c1xyXG4gKiB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqIHgge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9XHJcbiAqIHkge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9XHJcbiAqXHJcbiAqL1xyXG5mdW5jdGlvbiBtb2QoeCwgeSkge1xyXG4gIHJldHVybiBuZXcgdGhpcyh4KS5tb2QoeSk7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyBgeGAgbXVsdGlwbGllZCBieSBgeWAsIHJvdW5kZWQgdG8gYHByZWNpc2lvbmAgc2lnbmlmaWNhbnRcclxuICogZGlnaXRzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJvdW5kaW5nYC5cclxuICpcclxuICogeCB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH1cclxuICogeSB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH1cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIG11bCh4LCB5KSB7XHJcbiAgcmV0dXJuIG5ldyB0aGlzKHgpLm11bCh5KTtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIGB4YCByYWlzZWQgdG8gdGhlIHBvd2VyIGB5YCwgcm91bmRlZCB0byBwcmVjaXNpb25cclxuICogc2lnbmlmaWNhbnQgZGlnaXRzIHVzaW5nIHJvdW5kaW5nIG1vZGUgYHJvdW5kaW5nYC5cclxuICpcclxuICogeCB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH0gVGhlIGJhc2UuXHJcbiAqIHkge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9IFRoZSBleHBvbmVudC5cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIHBvdyh4LCB5KSB7XHJcbiAgcmV0dXJuIG5ldyB0aGlzKHgpLnBvdyh5KTtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybnMgYSBuZXcgRGVjaW1hbCB3aXRoIGEgcmFuZG9tIHZhbHVlIGVxdWFsIHRvIG9yIGdyZWF0ZXIgdGhhbiAwIGFuZCBsZXNzIHRoYW4gMSwgYW5kIHdpdGhcclxuICogYHNkYCwgb3IgYERlY2ltYWwucHJlY2lzaW9uYCBpZiBgc2RgIGlzIG9taXR0ZWQsIHNpZ25pZmljYW50IGRpZ2l0cyAob3IgbGVzcyBpZiB0cmFpbGluZyB6ZXJvc1xyXG4gKiBhcmUgcHJvZHVjZWQpLlxyXG4gKlxyXG4gKiBbc2RdIHtudW1iZXJ9IFNpZ25pZmljYW50IGRpZ2l0cy4gSW50ZWdlciwgMCB0byBNQVhfRElHSVRTIGluY2x1c2l2ZS5cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIHJhbmRvbShzZCkge1xyXG4gIHZhciBkLCBlLCBrLCBuLFxyXG4gICAgaSA9IDAsXHJcbiAgICByID0gbmV3IHRoaXMoMSksXHJcbiAgICByZCA9IFtdO1xyXG5cclxuICBpZiAoc2QgPT09IHZvaWQgMCkgc2QgPSB0aGlzLnByZWNpc2lvbjtcclxuICBlbHNlIGNoZWNrSW50MzIoc2QsIDEsIE1BWF9ESUdJVFMpO1xyXG5cclxuICBrID0gTWF0aC5jZWlsKHNkIC8gTE9HX0JBU0UpO1xyXG5cclxuICBpZiAoIXRoaXMuY3J5cHRvKSB7XHJcbiAgICBmb3IgKDsgaSA8IGs7KSByZFtpKytdID0gTWF0aC5yYW5kb20oKSAqIDFlNyB8IDA7XHJcblxyXG4gIC8vIEJyb3dzZXJzIHN1cHBvcnRpbmcgY3J5cHRvLmdldFJhbmRvbVZhbHVlcy5cclxuICB9IGVsc2UgaWYgKGNyeXB0by5nZXRSYW5kb21WYWx1ZXMpIHtcclxuICAgIGQgPSBjcnlwdG8uZ2V0UmFuZG9tVmFsdWVzKG5ldyBVaW50MzJBcnJheShrKSk7XHJcblxyXG4gICAgZm9yICg7IGkgPCBrOykge1xyXG4gICAgICBuID0gZFtpXTtcclxuXHJcbiAgICAgIC8vIDAgPD0gbiA8IDQyOTQ5NjcyOTZcclxuICAgICAgLy8gUHJvYmFiaWxpdHkgbiA+PSA0LjI5ZTksIGlzIDQ5NjcyOTYgLyA0Mjk0OTY3Mjk2ID0gMC4wMDExNiAoMSBpbiA4NjUpLlxyXG4gICAgICBpZiAobiA+PSA0LjI5ZTkpIHtcclxuICAgICAgICBkW2ldID0gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDMyQXJyYXkoMSkpWzBdO1xyXG4gICAgICB9IGVsc2Uge1xyXG5cclxuICAgICAgICAvLyAwIDw9IG4gPD0gNDI4OTk5OTk5OVxyXG4gICAgICAgIC8vIDAgPD0gKG4gJSAxZTcpIDw9IDk5OTk5OTlcclxuICAgICAgICByZFtpKytdID0gbiAlIDFlNztcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAvLyBOb2RlLmpzIHN1cHBvcnRpbmcgY3J5cHRvLnJhbmRvbUJ5dGVzLlxyXG4gIH0gZWxzZSBpZiAoY3J5cHRvLnJhbmRvbUJ5dGVzKSB7XHJcblxyXG4gICAgLy8gYnVmZmVyXHJcbiAgICBkID0gY3J5cHRvLnJhbmRvbUJ5dGVzKGsgKj0gNCk7XHJcblxyXG4gICAgZm9yICg7IGkgPCBrOykge1xyXG5cclxuICAgICAgLy8gMCA8PSBuIDwgMjE0NzQ4MzY0OFxyXG4gICAgICBuID0gZFtpXSArIChkW2kgKyAxXSA8PCA4KSArIChkW2kgKyAyXSA8PCAxNikgKyAoKGRbaSArIDNdICYgMHg3ZikgPDwgMjQpO1xyXG5cclxuICAgICAgLy8gUHJvYmFiaWxpdHkgbiA+PSAyLjE0ZTksIGlzIDc0ODM2NDggLyAyMTQ3NDgzNjQ4ID0gMC4wMDM1ICgxIGluIDI4NikuXHJcbiAgICAgIGlmIChuID49IDIuMTRlOSkge1xyXG4gICAgICAgIGNyeXB0by5yYW5kb21CeXRlcyg0KS5jb3B5KGQsIGkpO1xyXG4gICAgICB9IGVsc2Uge1xyXG5cclxuICAgICAgICAvLyAwIDw9IG4gPD0gMjEzOTk5OTk5OVxyXG4gICAgICAgIC8vIDAgPD0gKG4gJSAxZTcpIDw9IDk5OTk5OTlcclxuICAgICAgICByZC5wdXNoKG4gJSAxZTcpO1xyXG4gICAgICAgIGkgKz0gNDtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGkgPSBrIC8gNDtcclxuICB9IGVsc2Uge1xyXG4gICAgdGhyb3cgRXJyb3IoY3J5cHRvVW5hdmFpbGFibGUpO1xyXG4gIH1cclxuXHJcbiAgayA9IHJkWy0taV07XHJcbiAgc2QgJT0gTE9HX0JBU0U7XHJcblxyXG4gIC8vIENvbnZlcnQgdHJhaWxpbmcgZGlnaXRzIHRvIHplcm9zIGFjY29yZGluZyB0byBzZC5cclxuICBpZiAoayAmJiBzZCkge1xyXG4gICAgbiA9IG1hdGhwb3coMTAsIExPR19CQVNFIC0gc2QpO1xyXG4gICAgcmRbaV0gPSAoayAvIG4gfCAwKSAqIG47XHJcbiAgfVxyXG5cclxuICAvLyBSZW1vdmUgdHJhaWxpbmcgd29yZHMgd2hpY2ggYXJlIHplcm8uXHJcbiAgZm9yICg7IHJkW2ldID09PSAwOyBpLS0pIHJkLnBvcCgpO1xyXG5cclxuICAvLyBaZXJvP1xyXG4gIGlmIChpIDwgMCkge1xyXG4gICAgZSA9IDA7XHJcbiAgICByZCA9IFswXTtcclxuICB9IGVsc2Uge1xyXG4gICAgZSA9IC0xO1xyXG5cclxuICAgIC8vIFJlbW92ZSBsZWFkaW5nIHdvcmRzIHdoaWNoIGFyZSB6ZXJvIGFuZCBhZGp1c3QgZXhwb25lbnQgYWNjb3JkaW5nbHkuXHJcbiAgICBmb3IgKDsgcmRbMF0gPT09IDA7IGUgLT0gTE9HX0JBU0UpIHJkLnNoaWZ0KCk7XHJcblxyXG4gICAgLy8gQ291bnQgdGhlIGRpZ2l0cyBvZiB0aGUgZmlyc3Qgd29yZCBvZiByZCB0byBkZXRlcm1pbmUgbGVhZGluZyB6ZXJvcy5cclxuICAgIGZvciAoayA9IDEsIG4gPSByZFswXTsgbiA+PSAxMDsgbiAvPSAxMCkgaysrO1xyXG5cclxuICAgIC8vIEFkanVzdCB0aGUgZXhwb25lbnQgZm9yIGxlYWRpbmcgemVyb3Mgb2YgdGhlIGZpcnN0IHdvcmQgb2YgcmQuXHJcbiAgICBpZiAoayA8IExPR19CQVNFKSBlIC09IExPR19CQVNFIC0gaztcclxuICB9XHJcblxyXG4gIHIuZSA9IGU7XHJcbiAgci5kID0gcmQ7XHJcblxyXG4gIHJldHVybiByO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgYHhgIHJvdW5kZWQgdG8gYW4gaW50ZWdlciB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqIFRvIGVtdWxhdGUgYE1hdGgucm91bmRgLCBzZXQgcm91bmRpbmcgdG8gNyAoUk9VTkRfSEFMRl9DRUlMKS5cclxuICpcclxuICogeCB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH1cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIHJvdW5kKHgpIHtcclxuICByZXR1cm4gZmluYWxpc2UoeCA9IG5ldyB0aGlzKHgpLCB4LmUgKyAxLCB0aGlzLnJvdW5kaW5nKTtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVyblxyXG4gKiAgIDEgICAgaWYgeCA+IDAsXHJcbiAqICAtMSAgICBpZiB4IDwgMCxcclxuICogICAwICAgIGlmIHggaXMgMCxcclxuICogIC0wICAgIGlmIHggaXMgLTAsXHJcbiAqICAgTmFOICBvdGhlcndpc2VcclxuICpcclxuICogeCB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH1cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIHNpZ24oeCkge1xyXG4gIHggPSBuZXcgdGhpcyh4KTtcclxuICByZXR1cm4geC5kID8gKHguZFswXSA/IHgucyA6IDAgKiB4LnMpIDogeC5zIHx8IE5hTjtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBzaW5lIG9mIGB4YCwgcm91bmRlZCB0byBgcHJlY2lzaW9uYCBzaWduaWZpY2FudCBkaWdpdHNcclxuICogdXNpbmcgcm91bmRpbmcgbW9kZSBgcm91bmRpbmdgLlxyXG4gKlxyXG4gKiB4IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfSBBIHZhbHVlIGluIHJhZGlhbnMuXHJcbiAqXHJcbiAqL1xyXG5mdW5jdGlvbiBzaW4oeCkge1xyXG4gIHJldHVybiBuZXcgdGhpcyh4KS5zaW4oKTtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBoeXBlcmJvbGljIHNpbmUgb2YgYHhgLCByb3VuZGVkIHRvIGBwcmVjaXNpb25gXHJcbiAqIHNpZ25pZmljYW50IGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqIHgge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9IEEgdmFsdWUgaW4gcmFkaWFucy5cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIHNpbmgoeCkge1xyXG4gIHJldHVybiBuZXcgdGhpcyh4KS5zaW5oKCk7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyB0aGUgc3F1YXJlIHJvb3Qgb2YgYHhgLCByb3VuZGVkIHRvIGBwcmVjaXNpb25gIHNpZ25pZmljYW50XHJcbiAqIGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqIHgge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9XHJcbiAqXHJcbiAqL1xyXG5mdW5jdGlvbiBzcXJ0KHgpIHtcclxuICByZXR1cm4gbmV3IHRoaXMoeCkuc3FydCgpO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgYHhgIG1pbnVzIGB5YCwgcm91bmRlZCB0byBgcHJlY2lzaW9uYCBzaWduaWZpY2FudCBkaWdpdHNcclxuICogdXNpbmcgcm91bmRpbmcgbW9kZSBgcm91bmRpbmdgLlxyXG4gKlxyXG4gKiB4IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfVxyXG4gKiB5IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfVxyXG4gKlxyXG4gKi9cclxuZnVuY3Rpb24gc3ViKHgsIHkpIHtcclxuICByZXR1cm4gbmV3IHRoaXMoeCkuc3ViKHkpO1xyXG59XHJcblxyXG5cclxuLypcclxuICogUmV0dXJuIGEgbmV3IERlY2ltYWwgd2hvc2UgdmFsdWUgaXMgdGhlIHN1bSBvZiB0aGUgYXJndW1lbnRzLCByb3VuZGVkIHRvIGBwcmVjaXNpb25gXHJcbiAqIHNpZ25pZmljYW50IGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqIE9ubHkgdGhlIHJlc3VsdCBpcyByb3VuZGVkLCBub3QgdGhlIGludGVybWVkaWF0ZSBjYWxjdWxhdGlvbnMuXHJcbiAqXHJcbiAqIGFyZ3VtZW50cyB7bnVtYmVyfHN0cmluZ3xiaWdpbnR8RGVjaW1hbH1cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIHN1bSgpIHtcclxuICB2YXIgaSA9IDAsXHJcbiAgICBhcmdzID0gYXJndW1lbnRzLFxyXG4gICAgeCA9IG5ldyB0aGlzKGFyZ3NbaV0pO1xyXG5cclxuICBleHRlcm5hbCA9IGZhbHNlO1xyXG4gIGZvciAoOyB4LnMgJiYgKytpIDwgYXJncy5sZW5ndGg7KSB4ID0geC5wbHVzKGFyZ3NbaV0pO1xyXG4gIGV4dGVybmFsID0gdHJ1ZTtcclxuXHJcbiAgcmV0dXJuIGZpbmFsaXNlKHgsIHRoaXMucHJlY2lzaW9uLCB0aGlzLnJvdW5kaW5nKTtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSB0YW5nZW50IG9mIGB4YCwgcm91bmRlZCB0byBgcHJlY2lzaW9uYCBzaWduaWZpY2FudFxyXG4gKiBkaWdpdHMgdXNpbmcgcm91bmRpbmcgbW9kZSBgcm91bmRpbmdgLlxyXG4gKlxyXG4gKiB4IHtudW1iZXJ8c3RyaW5nfGJpZ2ludHxEZWNpbWFsfSBBIHZhbHVlIGluIHJhZGlhbnMuXHJcbiAqXHJcbiAqL1xyXG5mdW5jdGlvbiB0YW4oeCkge1xyXG4gIHJldHVybiBuZXcgdGhpcyh4KS50YW4oKTtcclxufVxyXG5cclxuXHJcbi8qXHJcbiAqIFJldHVybiBhIG5ldyBEZWNpbWFsIHdob3NlIHZhbHVlIGlzIHRoZSBoeXBlcmJvbGljIHRhbmdlbnQgb2YgYHhgLCByb3VuZGVkIHRvIGBwcmVjaXNpb25gXHJcbiAqIHNpZ25pZmljYW50IGRpZ2l0cyB1c2luZyByb3VuZGluZyBtb2RlIGByb3VuZGluZ2AuXHJcbiAqXHJcbiAqIHgge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9IEEgdmFsdWUgaW4gcmFkaWFucy5cclxuICpcclxuICovXHJcbmZ1bmN0aW9uIHRhbmgoeCkge1xyXG4gIHJldHVybiBuZXcgdGhpcyh4KS50YW5oKCk7XHJcbn1cclxuXHJcblxyXG4vKlxyXG4gKiBSZXR1cm4gYSBuZXcgRGVjaW1hbCB3aG9zZSB2YWx1ZSBpcyBgeGAgdHJ1bmNhdGVkIHRvIGFuIGludGVnZXIuXHJcbiAqXHJcbiAqIHgge251bWJlcnxzdHJpbmd8YmlnaW50fERlY2ltYWx9XHJcbiAqXHJcbiAqL1xyXG5mdW5jdGlvbiB0cnVuYyh4KSB7XHJcbiAgcmV0dXJuIGZpbmFsaXNlKHggPSBuZXcgdGhpcyh4KSwgeC5lICsgMSwgMSk7XHJcbn1cclxuXHJcblxyXG5QW1N5bWJvbC5mb3IoJ25vZGVqcy51dGlsLmluc3BlY3QuY3VzdG9tJyldID0gUC50b1N0cmluZztcclxuUFtTeW1ib2wudG9TdHJpbmdUYWddID0gJ0RlY2ltYWwnO1xyXG5cclxuLy8gQ3JlYXRlIGFuZCBjb25maWd1cmUgaW5pdGlhbCBEZWNpbWFsIGNvbnN0cnVjdG9yLlxyXG5leHBvcnQgdmFyIERlY2ltYWwgPSBQLmNvbnN0cnVjdG9yID0gY2xvbmUoREVGQVVMVFMpO1xyXG5cclxuLy8gQ3JlYXRlIHRoZSBpbnRlcm5hbCBjb25zdGFudHMgZnJvbSB0aGVpciBzdHJpbmcgdmFsdWVzLlxyXG5MTjEwID0gbmV3IERlY2ltYWwoTE4xMCk7XHJcblBJID0gbmV3IERlY2ltYWwoUEkpO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGVjaW1hbDtcclxuIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQWNBLElBQUksWUFBWTtBQUlkLElBQUEsYUFBYTtBQUdiLElBQUEsV0FBVztBQUdYLElBQUEsT0FBTztBQUdQLElBQUEsS0FBSztBQUlMLElBQUEsV0FBVztDQU9ULFdBQVc7Q0FpQlgsVUFBVTtDQWVWLFFBQVE7Q0FJUixVQUFVO0NBSVYsVUFBVztDQUlYLE1BQU0sQ0FBQztDQUlQLE1BQU07Q0FHTixRQUFRO0FBQ1Y7QUFNQSxJQUFBO0FBQVMsSUFBQTtBQUNULElBQUEsV0FBVztBQUVYLElBQUEsZUFBZTtBQUNmLElBQUEsa0JBQWtCLGVBQWU7QUFDakMsSUFBQSx5QkFBeUIsZUFBZTtBQUN4QyxJQUFBLG9CQUFvQixlQUFlO0FBQ25DLElBQUEsTUFBTTtBQUVOLElBQUEsWUFBWSxLQUFLO0FBQ2pCLElBQUEsVUFBVSxLQUFLO0FBRWYsSUFBQSxXQUFXO0FBQ1gsSUFBQSxRQUFRO0FBQ1IsSUFBQSxVQUFVO0FBQ1YsSUFBQSxZQUFZO0FBRVosSUFBQSxPQUFPO0FBQ1AsSUFBQSxXQUFXO0FBQ1gsSUFBQSxtQkFBbUI7QUFFbkIsSUFBQSxpQkFBaUIsS0FBSyxTQUFTO0FBQy9CLElBQUEsZUFBZSxHQUFHLFNBQVM7QUFHM0IsSUFBQSxJQUFJLEVBQUUsYUFBYSxJQUFJO0FBMEV6QixFQUFFLGdCQUFnQixFQUFFLE1BQU0sV0FBWTtDQUNwQyxJQUFJLElBQUksSUFBSSxLQUFLLFlBQVksSUFBSTtDQUNqQyxJQUFJLEVBQUUsSUFBSSxHQUFHLEVBQUUsSUFBSTtDQUNuQixPQUFPLFNBQVMsQ0FBQztBQUNuQjtBQVFBLEVBQUUsT0FBTyxXQUFZO0NBQ25CLE9BQU8sU0FBUyxJQUFJLEtBQUssWUFBWSxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsQ0FBQztBQUMzRDtBQVdBLEVBQUUsWUFBWSxFQUFFLFFBQVEsU0FBVSxLQUFLLEtBQUs7Q0FDMUMsSUFBSSxHQUNGLElBQUksTUFDSixPQUFPLEVBQUU7Q0FDWCxNQUFNLElBQUksS0FBSyxHQUFHO0NBQ2xCLE1BQU0sSUFBSSxLQUFLLEdBQUc7Q0FDbEIsSUFBSSxDQUFDLElBQUksS0FBSyxDQUFDLElBQUksR0FBRyxPQUFPLElBQUksS0FBSyxHQUFHO0NBQ3pDLElBQUksSUFBSSxHQUFHLEdBQUcsR0FBRyxNQUFNLE1BQU0sa0JBQWtCLEdBQUc7Q0FDbEQsSUFBSSxFQUFFLElBQUksR0FBRztDQUNiLE9BQU8sSUFBSSxJQUFJLE1BQU0sRUFBRSxJQUFJLEdBQUcsSUFBSSxJQUFJLE1BQU0sSUFBSSxLQUFLLENBQUM7QUFDeEQ7QUFXQSxFQUFFLGFBQWEsRUFBRSxNQUFNLFNBQVUsR0FBRztDQUNsQyxJQUFJLEdBQUcsR0FBRyxLQUFLLEtBQ2IsSUFBSSxNQUNKLEtBQUssRUFBRSxHQUNQLE1BQU0sSUFBSSxJQUFJLEVBQUUsWUFBWSxDQUFDLEVBQUEsQ0FBRyxHQUNoQyxLQUFLLEVBQUUsR0FDUCxLQUFLLEVBQUU7Q0FHVCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQ1YsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLE1BQU0sT0FBTyxLQUFLLEtBQUssT0FBTyxLQUFLLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxJQUFJO0NBSWhGLElBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLElBQUksT0FBTyxHQUFHLEtBQUssS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLO0NBR3hELElBQUksT0FBTyxJQUFJLE9BQU87Q0FHdEIsSUFBSSxFQUFFLE1BQU0sRUFBRSxHQUFHLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxLQUFLLElBQUksSUFBSTtDQUVqRCxNQUFNLEdBQUc7Q0FDVCxNQUFNLEdBQUc7Q0FHVCxLQUFLLElBQUksR0FBRyxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUssSUFBSSxHQUFHLEVBQUUsR0FDOUMsSUFBSSxHQUFHLE9BQU8sR0FBRyxJQUFJLE9BQU8sR0FBRyxLQUFLLEdBQUcsS0FBSyxLQUFLLElBQUksSUFBSTtDQUkzRCxPQUFPLFFBQVEsTUFBTSxJQUFJLE1BQU0sTUFBTSxLQUFLLElBQUksSUFBSTtBQUNwRDtBQWdCQSxFQUFFLFNBQVMsRUFBRSxNQUFNLFdBQVk7Q0FDN0IsSUFBSSxJQUFJLElBQ04sSUFBSSxNQUNKLE9BQU8sRUFBRTtDQUVYLElBQUksQ0FBQyxFQUFFLEdBQUcsT0FBTyxJQUFJLEtBQUssR0FBRztDQUc3QixJQUFJLENBQUMsRUFBRSxFQUFFLElBQUksT0FBTyxJQUFJLEtBQUssQ0FBQztDQUU5QixLQUFLLEtBQUs7Q0FDVixLQUFLLEtBQUs7Q0FDVixLQUFLLFlBQVksS0FBSyxLQUFLLElBQUksRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLElBQUk7Q0FDOUMsS0FBSyxXQUFXO0NBRWhCLElBQUksT0FBTyxNQUFNLGlCQUFpQixNQUFNLENBQUMsQ0FBQztDQUUxQyxLQUFLLFlBQVk7Q0FDakIsS0FBSyxXQUFXO0NBRWhCLE9BQU8sU0FBUyxZQUFZLEtBQUssWUFBWSxJQUFJLEVBQUUsSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLElBQUk7QUFDNUU7QUFtQkEsRUFBRSxXQUFXLEVBQUUsT0FBTyxXQUFZO0NBQ2hDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxLQUFLLEdBQUcsSUFBSSxHQUFHLElBQUksU0FDakMsSUFBSSxNQUNKLE9BQU8sRUFBRTtDQUVYLElBQUksQ0FBQyxFQUFFLFNBQVMsS0FBSyxFQUFFLE9BQU8sR0FBRyxPQUFPLElBQUksS0FBSyxDQUFDO0NBQ2xELFdBQVc7Q0FHWCxJQUFJLEVBQUUsSUFBSSxRQUFRLEVBQUUsSUFBSSxHQUFHLElBQUksQ0FBQztDQUloQyxJQUFJLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxLQUFLLElBQUksR0FBRztFQUM5QixJQUFJLGVBQWUsRUFBRSxDQUFDO0VBQ3RCLElBQUksRUFBRTtFQUdOLElBQUksS0FBSyxJQUFJLEVBQUUsU0FBUyxLQUFLLEdBQUcsS0FBTSxLQUFLLEtBQUssS0FBSyxLQUFLLE1BQU07RUFDaEUsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDO0VBR3BCLElBQUksV0FBVyxJQUFJLEtBQUssQ0FBQyxLQUFLLElBQUksTUFBTSxJQUFJLElBQUksS0FBSztFQUVyRCxJQUFJLEtBQUssSUFBSSxHQUNYLElBQUksT0FBTztPQUNOO0dBQ0wsSUFBSSxFQUFFLGNBQWM7R0FDcEIsSUFBSSxFQUFFLE1BQU0sR0FBRyxFQUFFLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSTtFQUN2QztFQUVBLElBQUksSUFBSSxLQUFLLENBQUM7RUFDZCxFQUFFLElBQUksRUFBRTtDQUNWLE9BQ0UsSUFBSSxJQUFJLEtBQUssRUFBRSxTQUFTLENBQUM7Q0FHM0IsTUFBTSxJQUFJLEtBQUssYUFBYTtDQUk1QixTQUFTO0VBQ1AsSUFBSTtFQUNKLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztFQUN2QixVQUFVLEdBQUcsS0FBSyxDQUFDO0VBQ25CLElBQUksT0FBTyxRQUFRLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsUUFBUSxLQUFLLEVBQUUsR0FBRyxLQUFLLEdBQUcsQ0FBQztFQUdoRSxJQUFJLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRSxPQUFPLElBQUksZUFBZSxFQUFFLENBQUMsRUFBQSxDQUFHLE1BQU0sR0FBRyxFQUFFLEdBQUc7R0FDL0UsSUFBSSxFQUFFLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQztHQUkxQixJQUFJLEtBQUssVUFBVSxDQUFDLE9BQU8sS0FBSyxRQUFRO0lBSXRDLElBQUksQ0FBQyxLQUFLO0tBQ1IsU0FBUyxHQUFHLElBQUksR0FBRyxDQUFDO0tBRXBCLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUc7TUFDN0IsSUFBSTtNQUNKO0tBQ0Y7SUFDRjtJQUVBLE1BQU07SUFDTixNQUFNO0dBQ1IsT0FBTztJQUlMLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsS0FBSyxLQUFLO0tBRzdDLFNBQVMsR0FBRyxJQUFJLEdBQUcsQ0FBQztLQUNwQixJQUFJLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0lBQy9CO0lBRUE7R0FDRjtFQUNGO0NBQ0Y7Q0FFQSxXQUFXO0NBRVgsT0FBTyxTQUFTLEdBQUcsR0FBRyxLQUFLLFVBQVUsQ0FBQztBQUN4QztBQU9BLEVBQUUsZ0JBQWdCLEVBQUUsS0FBSyxXQUFZO0NBQ25DLElBQUksR0FDRixJQUFJLEtBQUssR0FDVCxJQUFJO0NBRU4sSUFBSSxHQUFHO0VBQ0wsSUFBSSxFQUFFLFNBQVM7RUFDZixLQUFLLElBQUksVUFBVSxLQUFLLElBQUksUUFBUSxLQUFLO0VBR3pDLElBQUksRUFBRTtFQUNOLElBQUksR0FBRyxPQUFPLElBQUksTUFBTSxHQUFHLEtBQUssSUFBSTtFQUNwQyxJQUFJLElBQUksR0FBRyxJQUFJO0NBQ2pCO0NBRUEsT0FBTztBQUNUO0FBd0JBLEVBQUUsWUFBWSxFQUFFLE1BQU0sU0FBVSxHQUFHO0NBQ2pDLE9BQU8sT0FBTyxNQUFNLElBQUksS0FBSyxZQUFZLENBQUMsQ0FBQztBQUM3QztBQVFBLEVBQUUscUJBQXFCLEVBQUUsV0FBVyxTQUFVLEdBQUc7Q0FDL0MsSUFBSSxJQUFJLE1BQ04sT0FBTyxFQUFFO0NBQ1gsT0FBTyxTQUFTLE9BQU8sR0FBRyxJQUFJLEtBQUssQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLEdBQUcsS0FBSyxXQUFXLEtBQUssUUFBUTtBQUNoRjtBQU9BLEVBQUUsU0FBUyxFQUFFLEtBQUssU0FBVSxHQUFHO0NBQzdCLE9BQU8sS0FBSyxJQUFJLENBQUMsTUFBTTtBQUN6QjtBQVFBLEVBQUUsUUFBUSxXQUFZO0NBQ3BCLE9BQU8sU0FBUyxJQUFJLEtBQUssWUFBWSxJQUFJLEdBQUcsS0FBSyxJQUFJLEdBQUcsQ0FBQztBQUMzRDtBQVFBLEVBQUUsY0FBYyxFQUFFLEtBQUssU0FBVSxHQUFHO0NBQ2xDLE9BQU8sS0FBSyxJQUFJLENBQUMsSUFBSTtBQUN2QjtBQVFBLEVBQUUsdUJBQXVCLEVBQUUsTUFBTSxTQUFVLEdBQUc7Q0FDNUMsSUFBSSxJQUFJLEtBQUssSUFBSSxDQUFDO0NBQ2xCLE9BQU8sS0FBSyxLQUFLLE1BQU07QUFDekI7QUE0QkEsRUFBRSxtQkFBbUIsRUFBRSxPQUFPLFdBQVk7Q0FDeEMsSUFBSSxHQUFHLEdBQUcsSUFBSSxJQUFJLEtBQ2hCLElBQUksTUFDSixPQUFPLEVBQUUsYUFDVCxNQUFNLElBQUksS0FBSyxDQUFDO0NBRWxCLElBQUksQ0FBQyxFQUFFLFNBQVMsR0FBRyxPQUFPLElBQUksS0FBSyxFQUFFLElBQUksSUFBSSxJQUFJLEdBQUc7Q0FDcEQsSUFBSSxFQUFFLE9BQU8sR0FBRyxPQUFPO0NBRXZCLEtBQUssS0FBSztDQUNWLEtBQUssS0FBSztDQUNWLEtBQUssWUFBWSxLQUFLLEtBQUssSUFBSSxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsSUFBSTtDQUM5QyxLQUFLLFdBQVc7Q0FDaEIsTUFBTSxFQUFFLEVBQUU7Q0FPVixJQUFJLE1BQU0sSUFBSTtFQUNaLElBQUksS0FBSyxLQUFLLE1BQU0sQ0FBQztFQUNyQixLQUFLLElBQUksUUFBUSxHQUFHLENBQUMsRUFBQSxDQUFHLFNBQVM7Q0FDbkMsT0FBTztFQUNMLElBQUk7RUFDSixJQUFJO0NBQ047Q0FFQSxJQUFJLGFBQWEsTUFBTSxHQUFHLEVBQUUsTUFBTSxDQUFDLEdBQUcsSUFBSSxLQUFLLENBQUMsR0FBRyxJQUFJO0NBR3ZELElBQUksU0FDRixJQUFJLEdBQ0osS0FBSyxJQUFJLEtBQUssQ0FBQztDQUNqQixPQUFPLE1BQU07RUFDWCxVQUFVLEVBQUUsTUFBTSxDQUFDO0VBQ25CLElBQUksSUFBSSxNQUFNLFFBQVEsTUFBTSxHQUFHLE1BQU0sUUFBUSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUM7Q0FDMUQ7Q0FFQSxPQUFPLFNBQVMsR0FBRyxLQUFLLFlBQVksSUFBSSxLQUFLLFdBQVcsSUFBSSxJQUFJO0FBQ2xFO0FBaUNBLEVBQUUsaUJBQWlCLEVBQUUsT0FBTyxXQUFZO0NBQ3RDLElBQUksR0FBRyxJQUFJLElBQUksS0FDYixJQUFJLE1BQ0osT0FBTyxFQUFFO0NBRVgsSUFBSSxDQUFDLEVBQUUsU0FBUyxLQUFLLEVBQUUsT0FBTyxHQUFHLE9BQU8sSUFBSSxLQUFLLENBQUM7Q0FFbEQsS0FBSyxLQUFLO0NBQ1YsS0FBSyxLQUFLO0NBQ1YsS0FBSyxZQUFZLEtBQUssS0FBSyxJQUFJLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQyxJQUFJO0NBQzlDLEtBQUssV0FBVztDQUNoQixNQUFNLEVBQUUsRUFBRTtDQUVWLElBQUksTUFBTSxHQUNSLElBQUksYUFBYSxNQUFNLEdBQUcsR0FBRyxHQUFHLElBQUk7TUFDL0I7RUFXTCxJQUFJLE1BQU0sS0FBSyxLQUFLLEdBQUc7RUFDdkIsSUFBSSxJQUFJLEtBQUssS0FBSyxJQUFJO0VBRXRCLElBQUksRUFBRSxNQUFNLElBQUksUUFBUSxHQUFHLENBQUMsQ0FBQztFQUM3QixJQUFJLGFBQWEsTUFBTSxHQUFHLEdBQUcsR0FBRyxJQUFJO0VBR3BDLElBQUksU0FDRixLQUFLLElBQUksS0FBSyxDQUFDLEdBQ2YsTUFBTSxJQUFJLEtBQUssRUFBRSxHQUNqQixNQUFNLElBQUksS0FBSyxFQUFFO0VBQ25CLE9BQU8sTUFBTTtHQUNYLFVBQVUsRUFBRSxNQUFNLENBQUM7R0FDbkIsSUFBSSxFQUFFLE1BQU0sR0FBRyxLQUFLLFFBQVEsTUFBTSxJQUFJLE1BQU0sT0FBTyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDO0VBQ2xFO0NBQ0Y7Q0FFQSxLQUFLLFlBQVk7Q0FDakIsS0FBSyxXQUFXO0NBRWhCLE9BQU8sU0FBUyxHQUFHLElBQUksSUFBSSxJQUFJO0FBQ2pDO0FBbUJBLEVBQUUsb0JBQW9CLEVBQUUsT0FBTyxXQUFZO0NBQ3pDLElBQUksSUFBSSxJQUNOLElBQUksTUFDSixPQUFPLEVBQUU7Q0FFWCxJQUFJLENBQUMsRUFBRSxTQUFTLEdBQUcsT0FBTyxJQUFJLEtBQUssRUFBRSxDQUFDO0NBQ3RDLElBQUksRUFBRSxPQUFPLEdBQUcsT0FBTyxJQUFJLEtBQUssQ0FBQztDQUVqQyxLQUFLLEtBQUs7Q0FDVixLQUFLLEtBQUs7Q0FDVixLQUFLLFlBQVksS0FBSztDQUN0QixLQUFLLFdBQVc7Q0FFaEIsT0FBTyxPQUFPLEVBQUUsS0FBSyxHQUFHLEVBQUUsS0FBSyxHQUFHLEtBQUssWUFBWSxJQUFJLEtBQUssV0FBVyxFQUFFO0FBQzNFO0FBc0JBLEVBQUUsZ0JBQWdCLEVBQUUsT0FBTyxXQUFZO0NBQ3JDLElBQUksSUFBSSxNQUNOLE9BQU8sRUFBRSxhQUNULElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FDakIsS0FBSyxLQUFLLFdBQ1YsS0FBSyxLQUFLO0NBRVosSUFBSSxNQUFNLElBQ1IsT0FBTyxNQUFNLElBRVQsRUFBRSxNQUFNLElBQUksTUFBTSxNQUFNLElBQUksRUFBRSxJQUFJLElBQUksS0FBSyxDQUFDLElBRTVDLElBQUksS0FBSyxHQUFHO0NBR2xCLElBQUksRUFBRSxPQUFPLEdBQUcsT0FBTyxNQUFNLE1BQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQyxDQUFDLE1BQU0sRUFBRztDQUl4RCxLQUFLLFlBQVksS0FBSztDQUN0QixLQUFLLFdBQVc7Q0FHaEIsSUFBSSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUs7Q0FFcEQsS0FBSyxZQUFZO0NBQ2pCLEtBQUssV0FBVztDQUVoQixPQUFPLEVBQUUsTUFBTSxDQUFDO0FBQ2xCO0FBc0JBLEVBQUUsMEJBQTBCLEVBQUUsUUFBUSxXQUFZO0NBQ2hELElBQUksSUFBSSxJQUNOLElBQUksTUFDSixPQUFPLEVBQUU7Q0FFWCxJQUFJLEVBQUUsSUFBSSxDQUFDLEdBQUcsT0FBTyxJQUFJLEtBQUssRUFBRSxHQUFHLENBQUMsSUFBSSxJQUFJLEdBQUc7Q0FDL0MsSUFBSSxDQUFDLEVBQUUsU0FBUyxHQUFHLE9BQU8sSUFBSSxLQUFLLENBQUM7Q0FFcEMsS0FBSyxLQUFLO0NBQ1YsS0FBSyxLQUFLO0NBQ1YsS0FBSyxZQUFZLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxJQUFJO0NBQ3hELEtBQUssV0FBVztDQUNoQixXQUFXO0NBRVgsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUM7Q0FFckMsV0FBVztDQUNYLEtBQUssWUFBWTtDQUNqQixLQUFLLFdBQVc7Q0FFaEIsT0FBTyxFQUFFLEdBQUc7QUFDZDtBQW1CQSxFQUFFLHdCQUF3QixFQUFFLFFBQVEsV0FBWTtDQUM5QyxJQUFJLElBQUksSUFDTixJQUFJLE1BQ0osT0FBTyxFQUFFO0NBRVgsSUFBSSxDQUFDLEVBQUUsU0FBUyxLQUFLLEVBQUUsT0FBTyxHQUFHLE9BQU8sSUFBSSxLQUFLLENBQUM7Q0FFbEQsS0FBSyxLQUFLO0NBQ1YsS0FBSyxLQUFLO0NBQ1YsS0FBSyxZQUFZLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLEVBQUUsQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLElBQUk7Q0FDNUQsS0FBSyxXQUFXO0NBQ2hCLFdBQVc7Q0FFWCxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQztDQUVwQyxXQUFXO0NBQ1gsS0FBSyxZQUFZO0NBQ2pCLEtBQUssV0FBVztDQUVoQixPQUFPLEVBQUUsR0FBRztBQUNkO0FBc0JBLEVBQUUsMkJBQTJCLEVBQUUsUUFBUSxXQUFZO0NBQ2pELElBQUksSUFBSSxJQUFJLEtBQUssS0FDZixJQUFJLE1BQ0osT0FBTyxFQUFFO0NBRVgsSUFBSSxDQUFDLEVBQUUsU0FBUyxHQUFHLE9BQU8sSUFBSSxLQUFLLEdBQUc7Q0FDdEMsSUFBSSxFQUFFLEtBQUssR0FBRyxPQUFPLElBQUksS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUUsT0FBTyxJQUFJLElBQUksR0FBRztDQUU1RSxLQUFLLEtBQUs7Q0FDVixLQUFLLEtBQUs7Q0FDVixNQUFNLEVBQUUsR0FBRztDQUVYLElBQUksS0FBSyxJQUFJLEtBQUssRUFBRSxJQUFJLElBQUksQ0FBQyxFQUFFLElBQUksR0FBRyxPQUFPLFNBQVMsSUFBSSxLQUFLLENBQUMsR0FBRyxJQUFJLElBQUksSUFBSTtDQUUvRSxLQUFLLFlBQVksTUFBTSxNQUFNLEVBQUU7Q0FFL0IsSUFBSSxPQUFPLEVBQUUsS0FBSyxDQUFDLEdBQUcsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sSUFBSSxDQUFDO0NBRXZELEtBQUssWUFBWSxLQUFLO0NBQ3RCLEtBQUssV0FBVztDQUVoQixJQUFJLEVBQUUsR0FBRztDQUVULEtBQUssWUFBWTtDQUNqQixLQUFLLFdBQVc7Q0FFaEIsT0FBTyxFQUFFLE1BQU0sRUFBRztBQUNwQjtBQXdCQSxFQUFFLGNBQWMsRUFBRSxPQUFPLFdBQVk7Q0FDbkMsSUFBSSxRQUFRLEdBQ1YsSUFBSSxJQUNKLElBQUksTUFDSixPQUFPLEVBQUU7Q0FFWCxJQUFJLEVBQUUsT0FBTyxHQUFHLE9BQU8sSUFBSSxLQUFLLENBQUM7Q0FFakMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQztDQUNqQixLQUFLLEtBQUs7Q0FDVixLQUFLLEtBQUs7Q0FFVixJQUFJLE1BQU0sSUFBSTtFQUdaLElBQUksTUFBTSxHQUFHO0dBQ1gsU0FBUyxNQUFNLE1BQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQyxDQUFDLE1BQU0sRUFBRztHQUMxQyxPQUFPLElBQUksRUFBRTtHQUNiLE9BQU87RUFDVDtFQUdBLE9BQU8sSUFBSSxLQUFLLEdBQUc7Q0FDckI7Q0FJQSxLQUFLLFlBQVksS0FBSztDQUN0QixLQUFLLFdBQVc7Q0FFaEIsSUFBSSxFQUFFLElBQUksSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUs7Q0FFN0QsS0FBSyxZQUFZO0NBQ2pCLEtBQUssV0FBVztDQUVoQixPQUFPLEVBQUUsTUFBTSxDQUFDO0FBQ2xCO0FBcUJBLEVBQUUsaUJBQWlCLEVBQUUsT0FBTyxXQUFZO0NBQ3RDLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxJQUFJLEdBQUcsR0FBRyxLQUFLLElBQzdCLElBQUksTUFDSixPQUFPLEVBQUUsYUFDVCxLQUFLLEtBQUssV0FDVixLQUFLLEtBQUs7Q0FFWixJQUFJLENBQUMsRUFBRSxTQUFTLEdBQUc7RUFDakIsSUFBSSxDQUFDLEVBQUUsR0FBRyxPQUFPLElBQUksS0FBSyxHQUFHO0VBQzdCLElBQUksS0FBSyxLQUFLLGNBQWM7R0FDMUIsSUFBSSxNQUFNLE1BQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQyxDQUFDLE1BQU0sRUFBRztHQUNyQyxFQUFFLElBQUksRUFBRTtHQUNSLE9BQU87RUFDVDtDQUNGLE9BQU8sSUFBSSxFQUFFLE9BQU8sR0FDbEIsT0FBTyxJQUFJLEtBQUssQ0FBQztNQUNaLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsS0FBSyxLQUFLLEtBQUssY0FBYztFQUNsRCxJQUFJLE1BQU0sTUFBTSxLQUFLLEdBQUcsRUFBRSxDQUFDLENBQUMsTUFBTSxHQUFJO0VBQ3RDLEVBQUUsSUFBSSxFQUFFO0VBQ1IsT0FBTztDQUNUO0NBRUEsS0FBSyxZQUFZLE1BQU0sS0FBSztDQUM1QixLQUFLLFdBQVc7Q0FRaEIsSUFBSSxLQUFLLElBQUksSUFBSSxNQUFNLFdBQVcsSUFBSSxDQUFDO0NBRXZDLEtBQUssSUFBSSxHQUFHLEdBQUcsRUFBRSxHQUFHLElBQUksRUFBRSxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO0NBRS9ELFdBQVc7Q0FFWCxJQUFJLEtBQUssS0FBSyxNQUFNLFFBQVE7Q0FDNUIsSUFBSTtDQUNKLEtBQUssRUFBRSxNQUFNLENBQUM7Q0FDZCxJQUFJLElBQUksS0FBSyxDQUFDO0NBQ2QsS0FBSztDQUdMLE9BQU8sTUFBTSxLQUFLO0VBQ2hCLEtBQUssR0FBRyxNQUFNLEVBQUU7RUFDaEIsSUFBSSxFQUFFLE1BQU0sR0FBRyxJQUFJLEtBQUssQ0FBQyxDQUFDO0VBRTFCLEtBQUssR0FBRyxNQUFNLEVBQUU7RUFDaEIsSUFBSSxFQUFFLEtBQUssR0FBRyxJQUFJLEtBQUssQ0FBQyxDQUFDO0VBRXpCLElBQUksRUFBRSxFQUFFLE9BQU8sS0FBSyxHQUFHLEtBQUssSUFBSSxHQUFHLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxNQUFNO0NBQzFEO0NBRUEsSUFBSSxHQUFHLElBQUksRUFBRSxNQUFNLEtBQU0sSUFBSSxDQUFFO0NBRS9CLFdBQVc7Q0FFWCxPQUFPLFNBQVMsR0FBRyxLQUFLLFlBQVksSUFBSSxLQUFLLFdBQVcsSUFBSSxJQUFJO0FBQ2xFO0FBT0EsRUFBRSxXQUFXLFdBQVk7Q0FDdkIsT0FBTyxDQUFDLENBQUMsS0FBSztBQUNoQjtBQU9BLEVBQUUsWUFBWSxFQUFFLFFBQVEsV0FBWTtDQUNsQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEtBQUssVUFBVSxLQUFLLElBQUksUUFBUSxJQUFJLEtBQUssRUFBRSxTQUFTO0FBQ3BFO0FBT0EsRUFBRSxRQUFRLFdBQVk7Q0FDcEIsT0FBTyxDQUFDLEtBQUs7QUFDZjtBQU9BLEVBQUUsYUFBYSxFQUFFLFFBQVEsV0FBWTtDQUNuQyxPQUFPLEtBQUssSUFBSTtBQUNsQjtBQU9BLEVBQUUsYUFBYSxFQUFFLFFBQVEsV0FBWTtDQUNuQyxPQUFPLEtBQUssSUFBSTtBQUNsQjtBQU9BLEVBQUUsU0FBUyxXQUFZO0NBQ3JCLE9BQU8sQ0FBQyxDQUFDLEtBQUssS0FBSyxLQUFLLEVBQUUsT0FBTztBQUNuQztBQU9BLEVBQUUsV0FBVyxFQUFFLEtBQUssU0FBVSxHQUFHO0NBQy9CLE9BQU8sS0FBSyxJQUFJLENBQUMsSUFBSTtBQUN2QjtBQU9BLEVBQUUsb0JBQW9CLEVBQUUsTUFBTSxTQUFVLEdBQUc7Q0FDekMsT0FBTyxLQUFLLElBQUksQ0FBQyxJQUFJO0FBQ3ZCO0FBaUNBLEVBQUUsWUFBWSxFQUFFLE1BQU0sU0FBVSxNQUFNO0NBQ3BDLElBQUksVUFBVSxHQUFHLGFBQWEsR0FBRyxLQUFLLEtBQUssSUFBSSxHQUM3QyxNQUFNLE1BQ04sT0FBTyxJQUFJLGFBQ1gsS0FBSyxLQUFLLFdBQ1YsS0FBSyxLQUFLLFVBQ1YsUUFBUTtDQUdWLElBQUksUUFBUSxNQUFNO0VBQ2hCLE9BQU8sSUFBSSxLQUFLLEVBQUU7RUFDbEIsV0FBVztDQUNiLE9BQU87RUFDTCxPQUFPLElBQUksS0FBSyxJQUFJO0VBQ3BCLElBQUksS0FBSztFQUdULElBQUksS0FBSyxJQUFJLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxNQUFNLEtBQUssR0FBRyxDQUFDLEdBQUcsT0FBTyxJQUFJLEtBQUssR0FBRztFQUVoRSxXQUFXLEtBQUssR0FBRyxFQUFFO0NBQ3ZCO0NBRUEsSUFBSSxJQUFJO0NBR1IsSUFBSSxJQUFJLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFLE1BQU0sSUFBSSxHQUFHLENBQUMsR0FDdEMsT0FBTyxJQUFJLEtBQUssS0FBSyxDQUFDLEVBQUUsS0FBSyxLQUFLLElBQUksSUFBSSxLQUFLLElBQUksTUFBTSxJQUFJLElBQUksSUFBSSxDQUFDO0NBS3hFLElBQUksVUFBVTtFQUNaLElBQUksRUFBRSxTQUFTLEdBQ2IsTUFBTTtPQUNEO0dBQ0wsS0FBSyxJQUFJLEVBQUUsSUFBSSxJQUFJLE9BQU8sSUFBSSxLQUFLO0dBQ25DLE1BQU0sTUFBTTtFQUNkO0NBQ0Y7Q0FFQSxXQUFXO0NBQ1gsS0FBSyxLQUFLO0NBQ1YsTUFBTSxpQkFBaUIsS0FBSyxFQUFFO0NBQzlCLGNBQWMsV0FBVyxRQUFRLE1BQU0sS0FBSyxFQUFFLElBQUksaUJBQWlCLE1BQU0sRUFBRTtDQUczRSxJQUFJLE9BQU8sS0FBSyxhQUFhLElBQUksQ0FBQztDQWdCbEMsSUFBSSxvQkFBb0IsRUFBRSxHQUFHLElBQUksSUFBSSxFQUFFLEdBRXJDLEdBQUc7RUFDRCxNQUFNO0VBQ04sTUFBTSxpQkFBaUIsS0FBSyxFQUFFO0VBQzlCLGNBQWMsV0FBVyxRQUFRLE1BQU0sS0FBSyxFQUFFLElBQUksaUJBQWlCLE1BQU0sRUFBRTtFQUMzRSxJQUFJLE9BQU8sS0FBSyxhQUFhLElBQUksQ0FBQztFQUVsQyxJQUFJLENBQUMsS0FBSztHQUdSLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxJQUFJLEdBQUcsSUFBSSxFQUFFLElBQUksS0FBSyxnQkFDbkQsSUFBSSxTQUFTLEdBQUcsS0FBSyxHQUFHLENBQUM7R0FHM0I7RUFDRjtDQUNGLFNBQVMsb0JBQW9CLEVBQUUsR0FBRyxLQUFLLElBQUksRUFBRTtDQUcvQyxXQUFXO0NBRVgsT0FBTyxTQUFTLEdBQUcsSUFBSSxFQUFFO0FBQzNCO0FBZ0RBLEVBQUUsUUFBUSxFQUFFLE1BQU0sU0FBVSxHQUFHO0NBQzdCLElBQUksR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxNQUFNLElBQzVDLElBQUksTUFDSixPQUFPLEVBQUU7Q0FFWCxJQUFJLElBQUksS0FBSyxDQUFDO0NBR2QsSUFBSSxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUUsR0FBRztFQUdoQixJQUFJLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBRSxHQUFHLElBQUksSUFBSSxLQUFLLEdBQUc7T0FHN0IsSUFBSSxFQUFFLEdBQUcsRUFBRSxJQUFJLENBQUMsRUFBRTtPQUtsQixJQUFJLElBQUksS0FBSyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsSUFBSSxJQUFJLEdBQUc7RUFFOUMsT0FBTztDQUNUO0NBR0EsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUFHO0VBQ2QsRUFBRSxJQUFJLENBQUMsRUFBRTtFQUNULE9BQU8sRUFBRSxLQUFLLENBQUM7Q0FDakI7Q0FFQSxLQUFLLEVBQUU7Q0FDUCxLQUFLLEVBQUU7Q0FDUCxLQUFLLEtBQUs7Q0FDVixLQUFLLEtBQUs7Q0FHVixJQUFJLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxJQUFJO0VBR3BCLElBQUksR0FBRyxJQUFJLEVBQUUsSUFBSSxDQUFDLEVBQUU7T0FHZixJQUFJLEdBQUcsSUFBSSxJQUFJLElBQUksS0FBSyxDQUFDO09BSXpCLE9BQU8sSUFBSSxLQUFLLE9BQU8sSUFBSSxLQUFLLENBQUM7RUFFdEMsT0FBTyxXQUFXLFNBQVMsR0FBRyxJQUFJLEVBQUUsSUFBSTtDQUMxQztDQUtBLElBQUksVUFBVSxFQUFFLElBQUksUUFBUTtDQUM1QixLQUFLLFVBQVUsRUFBRSxJQUFJLFFBQVE7Q0FFN0IsS0FBSyxHQUFHLE1BQU07Q0FDZCxJQUFJLEtBQUs7Q0FHVCxJQUFJLEdBQUc7RUFDTCxPQUFPLElBQUk7RUFFWCxJQUFJLE1BQU07R0FDUixJQUFJO0dBQ0osSUFBSSxDQUFDO0dBQ0wsTUFBTSxHQUFHO0VBQ1gsT0FBTztHQUNMLElBQUk7R0FDSixJQUFJO0dBQ0osTUFBTSxHQUFHO0VBQ1g7RUFLQSxJQUFJLEtBQUssSUFBSSxLQUFLLEtBQUssS0FBSyxRQUFRLEdBQUcsR0FBRyxJQUFJO0VBRTlDLElBQUksSUFBSSxHQUFHO0dBQ1QsSUFBSTtHQUNKLEVBQUUsU0FBUztFQUNiO0VBR0EsRUFBRSxRQUFRO0VBQ1YsS0FBSyxJQUFJLEdBQUcsTUFBTSxFQUFFLEtBQUssQ0FBQztFQUMxQixFQUFFLFFBQVE7Q0FHWixPQUFPO0VBSUwsSUFBSSxHQUFHO0VBQ1AsTUFBTSxHQUFHO0VBQ1QsT0FBTyxJQUFJO0VBQ1gsSUFBSSxNQUFNLE1BQU07RUFFaEIsS0FBSyxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQ25CLElBQUksR0FBRyxNQUFNLEdBQUcsSUFBSTtHQUNsQixPQUFPLEdBQUcsS0FBSyxHQUFHO0dBQ2xCO0VBQ0Y7RUFHRixJQUFJO0NBQ047Q0FFQSxJQUFJLE1BQU07RUFDUixJQUFJO0VBQ0osS0FBSztFQUNMLEtBQUs7RUFDTCxFQUFFLElBQUksQ0FBQyxFQUFFO0NBQ1g7Q0FFQSxNQUFNLEdBQUc7Q0FJVCxLQUFLLElBQUksR0FBRyxTQUFTLEtBQUssSUFBSSxHQUFHLEVBQUUsR0FBRyxHQUFHLFNBQVM7Q0FHbEQsS0FBSyxJQUFJLEdBQUcsUUFBUSxJQUFJLElBQUk7RUFFMUIsSUFBSSxHQUFHLEVBQUUsS0FBSyxHQUFHLElBQUk7R0FDbkIsS0FBSyxJQUFJLEdBQUcsS0FBSyxHQUFHLEVBQUUsT0FBTyxJQUFJLEdBQUcsS0FBSyxPQUFPO0dBQ2hELEVBQUUsR0FBRztHQUNMLEdBQUcsTUFBTTtFQUNYO0VBRUEsR0FBRyxNQUFNLEdBQUc7Q0FDZDtDQUdBLE9BQU8sR0FBRyxFQUFFLFNBQVMsSUFBSSxHQUFHLElBQUk7Q0FHaEMsT0FBTyxHQUFHLE9BQU8sR0FBRyxHQUFHLE1BQU0sR0FBRyxFQUFFO0NBR2xDLElBQUksQ0FBQyxHQUFHLElBQUksT0FBTyxJQUFJLEtBQUssT0FBTyxJQUFJLEtBQUssQ0FBQztDQUU3QyxFQUFFLElBQUk7Q0FDTixFQUFFLElBQUksa0JBQWtCLElBQUksQ0FBQztDQUU3QixPQUFPLFdBQVcsU0FBUyxHQUFHLElBQUksRUFBRSxJQUFJO0FBQzFDO0FBMkJBLEVBQUUsU0FBUyxFQUFFLE1BQU0sU0FBVSxHQUFHO0NBQzlCLElBQUksR0FDRixJQUFJLE1BQ0osT0FBTyxFQUFFO0NBRVgsSUFBSSxJQUFJLEtBQUssQ0FBQztDQUdkLElBQUksQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFFLEtBQUssRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLElBQUksT0FBTyxJQUFJLEtBQUssR0FBRztDQUd2RCxJQUFJLENBQUMsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxJQUN0QixPQUFPLFNBQVMsSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLFdBQVcsS0FBSyxRQUFRO0NBSTVELFdBQVc7Q0FFWCxJQUFJLEtBQUssVUFBVSxHQUFHO0VBSXBCLElBQUksT0FBTyxHQUFHLEVBQUUsSUFBSSxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQzlCLEVBQUUsS0FBSyxFQUFFO0NBQ1gsT0FDRSxJQUFJLE9BQU8sR0FBRyxHQUFHLEdBQUcsS0FBSyxRQUFRLENBQUM7Q0FHcEMsSUFBSSxFQUFFLE1BQU0sQ0FBQztDQUViLFdBQVc7Q0FFWCxPQUFPLEVBQUUsTUFBTSxDQUFDO0FBQ2xCO0FBU0EsRUFBRSxxQkFBcUIsRUFBRSxNQUFNLFdBQVk7Q0FDekMsT0FBTyxtQkFBbUIsSUFBSTtBQUNoQztBQVFBLEVBQUUsbUJBQW1CLEVBQUUsS0FBSyxXQUFZO0NBQ3RDLE9BQU8saUJBQWlCLElBQUk7QUFDOUI7QUFRQSxFQUFFLFVBQVUsRUFBRSxNQUFNLFdBQVk7Q0FDOUIsSUFBSSxJQUFJLElBQUksS0FBSyxZQUFZLElBQUk7Q0FDakMsRUFBRSxJQUFJLENBQUMsRUFBRTtDQUNULE9BQU8sU0FBUyxDQUFDO0FBQ25CO0FBd0JBLEVBQUUsT0FBTyxFQUFFLE1BQU0sU0FBVSxHQUFHO0NBQzVCLElBQUksT0FBTyxHQUFHLEdBQUcsR0FBRyxHQUFHLEtBQUssSUFBSSxJQUFJLElBQUksSUFDdEMsSUFBSSxNQUNKLE9BQU8sRUFBRTtDQUVYLElBQUksSUFBSSxLQUFLLENBQUM7Q0FHZCxJQUFJLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBRSxHQUFHO0VBR2hCLElBQUksQ0FBQyxFQUFFLEtBQUssQ0FBQyxFQUFFLEdBQUcsSUFBSSxJQUFJLEtBQUssR0FBRztPQU03QixJQUFJLENBQUMsRUFBRSxHQUFHLElBQUksSUFBSSxLQUFLLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxJQUFJLElBQUksR0FBRztFQUV4RCxPQUFPO0NBQ1Q7Q0FHQSxJQUFJLEVBQUUsS0FBSyxFQUFFLEdBQUc7RUFDZCxFQUFFLElBQUksQ0FBQyxFQUFFO0VBQ1QsT0FBTyxFQUFFLE1BQU0sQ0FBQztDQUNsQjtDQUVBLEtBQUssRUFBRTtDQUNQLEtBQUssRUFBRTtDQUNQLEtBQUssS0FBSztDQUNWLEtBQUssS0FBSztDQUdWLElBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxHQUFHLElBQUk7RUFJcEIsSUFBSSxDQUFDLEdBQUcsSUFBSSxJQUFJLElBQUksS0FBSyxDQUFDO0VBRTFCLE9BQU8sV0FBVyxTQUFTLEdBQUcsSUFBSSxFQUFFLElBQUk7Q0FDMUM7Q0FLQSxJQUFJLFVBQVUsRUFBRSxJQUFJLFFBQVE7Q0FDNUIsSUFBSSxVQUFVLEVBQUUsSUFBSSxRQUFRO0NBRTVCLEtBQUssR0FBRyxNQUFNO0NBQ2QsSUFBSSxJQUFJO0NBR1IsSUFBSSxHQUFHO0VBRUwsSUFBSSxJQUFJLEdBQUc7R0FDVCxJQUFJO0dBQ0osSUFBSSxDQUFDO0dBQ0wsTUFBTSxHQUFHO0VBQ1gsT0FBTztHQUNMLElBQUk7R0FDSixJQUFJO0dBQ0osTUFBTSxHQUFHO0VBQ1g7RUFHQSxJQUFJLEtBQUssS0FBSyxLQUFLLFFBQVE7RUFDM0IsTUFBTSxJQUFJLE1BQU0sSUFBSSxJQUFJLE1BQU07RUFFOUIsSUFBSSxJQUFJLEtBQUs7R0FDWCxJQUFJO0dBQ0osRUFBRSxTQUFTO0VBQ2I7RUFHQSxFQUFFLFFBQVE7RUFDVixPQUFPLE1BQU0sRUFBRSxLQUFLLENBQUM7RUFDckIsRUFBRSxRQUFRO0NBQ1o7Q0FFQSxNQUFNLEdBQUc7Q0FDVCxJQUFJLEdBQUc7Q0FHUCxJQUFJLE1BQU0sSUFBSSxHQUFHO0VBQ2YsSUFBSTtFQUNKLElBQUk7RUFDSixLQUFLO0VBQ0wsS0FBSztDQUNQO0NBR0EsS0FBSyxRQUFRLEdBQUcsSUFBSTtFQUNsQixTQUFTLEdBQUcsRUFBRSxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssU0FBUyxPQUFPO0VBQ25ELEdBQUcsTUFBTTtDQUNYO0NBRUEsSUFBSSxPQUFPO0VBQ1QsR0FBRyxRQUFRLEtBQUs7RUFDaEIsRUFBRTtDQUNKO0NBSUEsS0FBSyxNQUFNLEdBQUcsUUFBUSxHQUFHLEVBQUUsUUFBUSxJQUFJLEdBQUcsSUFBSTtDQUU5QyxFQUFFLElBQUk7Q0FDTixFQUFFLElBQUksa0JBQWtCLElBQUksQ0FBQztDQUU3QixPQUFPLFdBQVcsU0FBUyxHQUFHLElBQUksRUFBRSxJQUFJO0FBQzFDO0FBU0EsRUFBRSxZQUFZLEVBQUUsS0FBSyxTQUFVLEdBQUc7Q0FDaEMsSUFBSSxHQUNGLElBQUk7Q0FFTixJQUFJLE1BQU0sS0FBSyxLQUFLLE1BQU0sQ0FBQyxDQUFDLEtBQUssTUFBTSxLQUFLLE1BQU0sR0FBRyxNQUFNLE1BQU0sa0JBQWtCLENBQUM7Q0FFcEYsSUFBSSxFQUFFLEdBQUc7RUFDUCxJQUFJLGFBQWEsRUFBRSxDQUFDO0VBQ3BCLElBQUksS0FBSyxFQUFFLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxJQUFJO0NBQ2xDLE9BQ0UsSUFBSTtDQUdOLE9BQU87QUFDVDtBQVFBLEVBQUUsUUFBUSxXQUFZO0NBQ3BCLElBQUksSUFBSSxNQUNOLE9BQU8sRUFBRTtDQUVYLE9BQU8sU0FBUyxJQUFJLEtBQUssQ0FBQyxHQUFHLEVBQUUsSUFBSSxHQUFHLEtBQUssUUFBUTtBQUNyRDtBQWtCQSxFQUFFLE9BQU8sRUFBRSxNQUFNLFdBQVk7Q0FDM0IsSUFBSSxJQUFJLElBQ04sSUFBSSxNQUNKLE9BQU8sRUFBRTtDQUVYLElBQUksQ0FBQyxFQUFFLFNBQVMsR0FBRyxPQUFPLElBQUksS0FBSyxHQUFHO0NBQ3RDLElBQUksRUFBRSxPQUFPLEdBQUcsT0FBTyxJQUFJLEtBQUssQ0FBQztDQUVqQyxLQUFLLEtBQUs7Q0FDVixLQUFLLEtBQUs7Q0FDVixLQUFLLFlBQVksS0FBSyxLQUFLLElBQUksRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDLElBQUk7Q0FDOUMsS0FBSyxXQUFXO0NBRWhCLElBQUksS0FBSyxNQUFNLGlCQUFpQixNQUFNLENBQUMsQ0FBQztDQUV4QyxLQUFLLFlBQVk7Q0FDakIsS0FBSyxXQUFXO0NBRWhCLE9BQU8sU0FBUyxXQUFXLElBQUksRUFBRSxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksSUFBSTtBQUMxRDtBQWVBLEVBQUUsYUFBYSxFQUFFLE9BQU8sV0FBWTtDQUNsQyxJQUFJLEdBQUcsR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUNwQixJQUFJLE1BQ0osSUFBSSxFQUFFLEdBQ04sSUFBSSxFQUFFLEdBQ04sSUFBSSxFQUFFLEdBQ04sT0FBTyxFQUFFO0NBR1gsSUFBSSxNQUFNLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRSxJQUN0QixPQUFPLElBQUksS0FBSyxDQUFDLEtBQUssSUFBSSxNQUFNLENBQUMsS0FBSyxFQUFFLE1BQU0sTUFBTSxJQUFJLElBQUksSUFBSSxDQUFDO0NBR25FLFdBQVc7Q0FHWCxJQUFJLEtBQUssS0FBSyxDQUFDLENBQUM7Q0FJaEIsSUFBSSxLQUFLLEtBQUssS0FBSyxJQUFJLEdBQUc7RUFDeEIsSUFBSSxlQUFlLENBQUM7RUFFcEIsS0FBSyxFQUFFLFNBQVMsS0FBSyxLQUFLLEdBQUcsS0FBSztFQUNsQyxJQUFJLEtBQUssS0FBSyxDQUFDO0VBQ2YsSUFBSSxXQUFXLElBQUksS0FBSyxDQUFDLEtBQUssSUFBSSxLQUFLLElBQUk7RUFFM0MsSUFBSSxLQUFLLElBQUksR0FDWCxJQUFJLE9BQU87T0FDTjtHQUNMLElBQUksRUFBRSxjQUFjO0dBQ3BCLElBQUksRUFBRSxNQUFNLEdBQUcsRUFBRSxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUk7RUFDdkM7RUFFQSxJQUFJLElBQUksS0FBSyxDQUFDO0NBQ2hCLE9BQ0UsSUFBSSxJQUFJLEtBQUssRUFBRSxTQUFTLENBQUM7Q0FHM0IsTUFBTSxJQUFJLEtBQUssYUFBYTtDQUc1QixTQUFTO0VBQ1AsSUFBSTtFQUNKLElBQUksRUFBRSxLQUFLLE9BQU8sR0FBRyxHQUFHLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRztFQUc3QyxJQUFJLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRSxPQUFPLElBQUksZUFBZSxFQUFFLENBQUMsRUFBQSxDQUFHLE1BQU0sR0FBRyxFQUFFLEdBQUc7R0FDL0UsSUFBSSxFQUFFLE1BQU0sS0FBSyxHQUFHLEtBQUssQ0FBQztHQUkxQixJQUFJLEtBQUssVUFBVSxDQUFDLE9BQU8sS0FBSyxRQUFRO0lBSXRDLElBQUksQ0FBQyxLQUFLO0tBQ1IsU0FBUyxHQUFHLElBQUksR0FBRyxDQUFDO0tBRXBCLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxHQUFHO01BQ3BCLElBQUk7TUFDSjtLQUNGO0lBQ0Y7SUFFQSxNQUFNO0lBQ04sTUFBTTtHQUNSLE9BQU87SUFJTCxJQUFJLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUssS0FBSztLQUc3QyxTQUFTLEdBQUcsSUFBSSxHQUFHLENBQUM7S0FDcEIsSUFBSSxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7SUFDdEI7SUFFQTtHQUNGO0VBQ0Y7Q0FDRjtDQUVBLFdBQVc7Q0FFWCxPQUFPLFNBQVMsR0FBRyxHQUFHLEtBQUssVUFBVSxDQUFDO0FBQ3hDO0FBZ0JBLEVBQUUsVUFBVSxFQUFFLE1BQU0sV0FBWTtDQUM5QixJQUFJLElBQUksSUFDTixJQUFJLE1BQ0osT0FBTyxFQUFFO0NBRVgsSUFBSSxDQUFDLEVBQUUsU0FBUyxHQUFHLE9BQU8sSUFBSSxLQUFLLEdBQUc7Q0FDdEMsSUFBSSxFQUFFLE9BQU8sR0FBRyxPQUFPLElBQUksS0FBSyxDQUFDO0NBRWpDLEtBQUssS0FBSztDQUNWLEtBQUssS0FBSztDQUNWLEtBQUssWUFBWSxLQUFLO0NBQ3RCLEtBQUssV0FBVztDQUVoQixJQUFJLEVBQUUsSUFBSTtDQUNWLEVBQUUsSUFBSTtDQUNOLElBQUksT0FBTyxHQUFHLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxLQUFLLElBQUksQ0FBQztDQUU5RCxLQUFLLFlBQVk7Q0FDakIsS0FBSyxXQUFXO0NBRWhCLE9BQU8sU0FBUyxZQUFZLEtBQUssWUFBWSxJQUFJLEVBQUUsSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLElBQUk7QUFDNUU7QUF3QkEsRUFBRSxRQUFRLEVBQUUsTUFBTSxTQUFVLEdBQUc7Q0FDN0IsSUFBSSxPQUFPLEdBQUcsR0FBRyxHQUFHLEdBQUcsSUFBSSxHQUFHLEtBQUssS0FDakMsSUFBSSxNQUNKLE9BQU8sRUFBRSxhQUNULEtBQUssRUFBRSxHQUNQLE1BQU0sSUFBSSxJQUFJLEtBQUssQ0FBQyxFQUFBLENBQUc7Q0FFekIsRUFBRSxLQUFLLEVBQUU7Q0FHVCxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBRTlCLE9BQU8sSUFBSSxLQUFLLENBQUMsRUFBRSxLQUFLLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxLQUk1RCxNQUlBLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxJQUFJLElBQUksRUFBRSxJQUFJLENBQUM7Q0FHcEMsSUFBSSxVQUFVLEVBQUUsSUFBSSxRQUFRLElBQUksVUFBVSxFQUFFLElBQUksUUFBUTtDQUN4RCxNQUFNLEdBQUc7Q0FDVCxNQUFNLEdBQUc7Q0FHVCxJQUFJLE1BQU0sS0FBSztFQUNiLElBQUk7RUFDSixLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxNQUFNO0VBQ04sTUFBTTtDQUNSO0NBR0EsSUFBSSxDQUFDO0NBQ0wsS0FBSyxNQUFNO0NBQ1gsS0FBSyxJQUFJLElBQUksTUFBTSxFQUFFLEtBQUssQ0FBQztDQUczQixLQUFLLElBQUksS0FBSyxFQUFFLEtBQUssSUFBSTtFQUN2QixRQUFRO0VBQ1IsS0FBSyxJQUFJLE1BQU0sR0FBRyxJQUFJLElBQUk7R0FDeEIsSUFBSSxFQUFFLEtBQUssR0FBRyxLQUFLLEdBQUcsSUFBSSxJQUFJLEtBQUs7R0FDbkMsRUFBRSxPQUFPLElBQUksT0FBTztHQUNwQixRQUFRLElBQUksT0FBTztFQUNyQjtFQUVBLEVBQUUsTUFBTSxFQUFFLEtBQUssU0FBUyxPQUFPO0NBQ2pDO0NBR0EsT0FBTyxDQUFDLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSTtDQUV4QixJQUFJLE9BQU8sRUFBRTtNQUNSLEVBQUUsTUFBTTtDQUViLEVBQUUsSUFBSTtDQUNOLEVBQUUsSUFBSSxrQkFBa0IsR0FBRyxDQUFDO0NBRTVCLE9BQU8sV0FBVyxTQUFTLEdBQUcsS0FBSyxXQUFXLEtBQUssUUFBUSxJQUFJO0FBQ2pFO0FBYUEsRUFBRSxXQUFXLFNBQVUsSUFBSSxJQUFJO0NBQzdCLE9BQU8sZUFBZSxNQUFNLEdBQUcsSUFBSSxFQUFFO0FBQ3ZDO0FBYUEsRUFBRSxrQkFBa0IsRUFBRSxPQUFPLFNBQVUsSUFBSSxJQUFJO0NBQzdDLElBQUksSUFBSSxNQUNOLE9BQU8sRUFBRTtDQUVYLElBQUksSUFBSSxLQUFLLENBQUM7Q0FDZCxJQUFJLE9BQU8sS0FBSyxHQUFHLE9BQU87Q0FFMUIsV0FBVyxJQUFJLEdBQUcsVUFBVTtDQUU1QixJQUFJLE9BQU8sS0FBSyxHQUFHLEtBQUssS0FBSztNQUN4QixXQUFXLElBQUksR0FBRyxDQUFDO0NBRXhCLE9BQU8sU0FBUyxHQUFHLEtBQUssRUFBRSxJQUFJLEdBQUcsRUFBRTtBQUNyQztBQVdBLEVBQUUsZ0JBQWdCLFNBQVUsSUFBSSxJQUFJO0NBQ2xDLElBQUksS0FDRixJQUFJLE1BQ0osT0FBTyxFQUFFO0NBRVgsSUFBSSxPQUFPLEtBQUssR0FDZCxNQUFNLGVBQWUsR0FBRyxJQUFJO01BQ3ZCO0VBQ0wsV0FBVyxJQUFJLEdBQUcsVUFBVTtFQUU1QixJQUFJLE9BQU8sS0FBSyxHQUFHLEtBQUssS0FBSztPQUN4QixXQUFXLElBQUksR0FBRyxDQUFDO0VBRXhCLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxHQUFHLEtBQUssR0FBRyxFQUFFO0VBQ3BDLE1BQU0sZUFBZSxHQUFHLE1BQU0sS0FBSyxDQUFDO0NBQ3RDO0NBRUEsT0FBTyxFQUFFLE1BQU0sS0FBSyxDQUFDLEVBQUUsT0FBTyxJQUFJLE1BQU0sTUFBTTtBQUNoRDtBQW1CQSxFQUFFLFVBQVUsU0FBVSxJQUFJLElBQUk7Q0FDNUIsSUFBSSxLQUFLLEdBQ1AsSUFBSSxNQUNKLE9BQU8sRUFBRTtDQUVYLElBQUksT0FBTyxLQUFLLEdBQ2QsTUFBTSxlQUFlLENBQUM7TUFDakI7RUFDTCxXQUFXLElBQUksR0FBRyxVQUFVO0VBRTVCLElBQUksT0FBTyxLQUFLLEdBQUcsS0FBSyxLQUFLO09BQ3hCLFdBQVcsSUFBSSxHQUFHLENBQUM7RUFFeEIsSUFBSSxTQUFTLElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxFQUFFLElBQUksR0FBRyxFQUFFO0VBQzFDLE1BQU0sZUFBZSxHQUFHLE9BQU8sS0FBSyxFQUFFLElBQUksQ0FBQztDQUM3QztDQUlBLE9BQU8sRUFBRSxNQUFNLEtBQUssQ0FBQyxFQUFFLE9BQU8sSUFBSSxNQUFNLE1BQU07QUFDaEQ7QUFjQSxFQUFFLGFBQWEsU0FBVSxNQUFNO0NBQzdCLElBQUksR0FBRyxJQUFJLElBQUksSUFBSSxHQUFHLEdBQUcsR0FBRyxJQUFJLElBQUksSUFBSSxHQUFHLEdBQ3pDLElBQUksTUFDSixLQUFLLEVBQUUsR0FDUCxPQUFPLEVBQUU7Q0FFWCxJQUFJLENBQUMsSUFBSSxPQUFPLElBQUksS0FBSyxDQUFDO0NBRTFCLEtBQUssS0FBSyxJQUFJLEtBQUssQ0FBQztDQUNwQixLQUFLLEtBQUssSUFBSSxLQUFLLENBQUM7Q0FFcEIsSUFBSSxJQUFJLEtBQUssRUFBRTtDQUNmLElBQUksRUFBRSxJQUFJLGFBQWEsRUFBRSxJQUFJLEVBQUUsSUFBSTtDQUNuQyxJQUFJLElBQUk7Q0FDUixFQUFFLEVBQUUsS0FBSyxRQUFRLElBQUksSUFBSSxJQUFJLFdBQVcsSUFBSSxDQUFDO0NBRTdDLElBQUksUUFBUSxNQUdWLE9BQU8sSUFBSSxJQUFJLElBQUk7TUFDZDtFQUNMLElBQUksSUFBSSxLQUFLLElBQUk7RUFDakIsSUFBSSxDQUFDLEVBQUUsTUFBTSxLQUFLLEVBQUUsR0FBRyxFQUFFLEdBQUcsTUFBTSxNQUFNLGtCQUFrQixDQUFDO0VBQzNELE9BQU8sRUFBRSxHQUFHLENBQUMsSUFBSyxJQUFJLElBQUksSUFBSSxLQUFNO0NBQ3RDO0NBRUEsV0FBVztDQUNYLElBQUksSUFBSSxLQUFLLGVBQWUsRUFBRSxDQUFDO0NBQy9CLEtBQUssS0FBSztDQUNWLEtBQUssWUFBWSxJQUFJLEdBQUcsU0FBUyxXQUFXO0NBRTVDLFNBQVU7RUFDUixJQUFJLE9BQU8sR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDO0VBQ3hCLEtBQUssR0FBRyxLQUFLLEVBQUUsTUFBTSxFQUFFLENBQUM7RUFDeEIsSUFBSSxHQUFHLElBQUksSUFBSSxLQUFLLEdBQUc7RUFDdkIsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSyxHQUFHLEtBQUssRUFBRSxNQUFNLEVBQUUsQ0FBQztFQUN4QixLQUFLO0VBQ0wsS0FBSztFQUNMLElBQUksRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLENBQUM7RUFDdkIsSUFBSTtDQUNOO0NBRUEsS0FBSyxPQUFPLEtBQUssTUFBTSxFQUFFLEdBQUcsSUFBSSxHQUFHLEdBQUcsQ0FBQztDQUN2QyxLQUFLLEdBQUcsS0FBSyxHQUFHLE1BQU0sRUFBRSxDQUFDO0NBQ3pCLEtBQUssR0FBRyxLQUFLLEdBQUcsTUFBTSxFQUFFLENBQUM7Q0FDekIsR0FBRyxJQUFJLEdBQUcsSUFBSSxFQUFFO0NBR2hCLElBQUksT0FBTyxJQUFJLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksT0FBTyxJQUFJLElBQUksR0FBRyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLElBQzdFLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLEVBQUU7Q0FFeEIsS0FBSyxZQUFZO0NBQ2pCLFdBQVc7Q0FFWCxPQUFPO0FBQ1Q7QUFhQSxFQUFFLGdCQUFnQixFQUFFLFFBQVEsU0FBVSxJQUFJLElBQUk7Q0FDNUMsT0FBTyxlQUFlLE1BQU0sSUFBSSxJQUFJLEVBQUU7QUFDeEM7QUFtQkEsRUFBRSxZQUFZLFNBQVUsR0FBRyxJQUFJO0NBQzdCLElBQUksSUFBSSxNQUNOLE9BQU8sRUFBRTtDQUVYLElBQUksSUFBSSxLQUFLLENBQUM7Q0FFZCxJQUFJLEtBQUssTUFBTTtFQUdiLElBQUksQ0FBQyxFQUFFLEdBQUcsT0FBTztFQUVqQixJQUFJLElBQUksS0FBSyxDQUFDO0VBQ2QsS0FBSyxLQUFLO0NBQ1osT0FBTztFQUNMLElBQUksSUFBSSxLQUFLLENBQUM7RUFDZCxJQUFJLE9BQU8sS0FBSyxHQUNkLEtBQUssS0FBSztPQUVWLFdBQVcsSUFBSSxHQUFHLENBQUM7RUFJckIsSUFBSSxDQUFDLEVBQUUsR0FBRyxPQUFPLEVBQUUsSUFBSSxJQUFJO0VBRzNCLElBQUksQ0FBQyxFQUFFLEdBQUc7R0FDUixJQUFJLEVBQUUsR0FBRyxFQUFFLElBQUksRUFBRTtHQUNqQixPQUFPO0VBQ1Q7Q0FDRjtDQUdBLElBQUksRUFBRSxFQUFFLElBQUk7RUFDVixXQUFXO0VBQ1gsSUFBSSxPQUFPLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDO0VBQ2xDLFdBQVc7RUFDWCxTQUFTLENBQUM7Q0FHWixPQUFPO0VBQ0wsRUFBRSxJQUFJLEVBQUU7RUFDUixJQUFJO0NBQ047Q0FFQSxPQUFPO0FBQ1Q7QUFRQSxFQUFFLFdBQVcsV0FBWTtDQUN2QixPQUFPLENBQUM7QUFDVjtBQWFBLEVBQUUsVUFBVSxTQUFVLElBQUksSUFBSTtDQUM1QixPQUFPLGVBQWUsTUFBTSxHQUFHLElBQUksRUFBRTtBQUN2QztBQThDQSxFQUFFLFVBQVUsRUFBRSxNQUFNLFNBQVUsR0FBRztDQUMvQixJQUFJLEdBQUcsR0FBRyxJQUFJLEdBQUcsSUFBSSxHQUNuQixJQUFJLE1BQ0osT0FBTyxFQUFFLGFBQ1QsS0FBSyxFQUFFLElBQUksSUFBSSxLQUFLLENBQUM7Q0FHdkIsSUFBSSxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUUsS0FBSyxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsRUFBRSxFQUFFLElBQUksT0FBTyxJQUFJLEtBQUssUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDO0NBRXZFLElBQUksSUFBSSxLQUFLLENBQUM7Q0FFZCxJQUFJLEVBQUUsR0FBRyxDQUFDLEdBQUcsT0FBTztDQUVwQixLQUFLLEtBQUs7Q0FDVixLQUFLLEtBQUs7Q0FFVixJQUFJLEVBQUUsR0FBRyxDQUFDLEdBQUcsT0FBTyxTQUFTLEdBQUcsSUFBSSxFQUFFO0NBR3RDLElBQUksVUFBVSxFQUFFLElBQUksUUFBUTtDQUc1QixJQUFJLEtBQUssRUFBRSxFQUFFLFNBQVMsTUFBTSxJQUFJLEtBQUssSUFBSSxDQUFDLEtBQUssT0FBTyxrQkFBa0I7RUFDdEUsSUFBSSxPQUFPLE1BQU0sR0FBRyxHQUFHLEVBQUU7RUFDekIsT0FBTyxFQUFFLElBQUksSUFBSSxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksU0FBUyxHQUFHLElBQUksRUFBRTtDQUMxRDtDQUVBLElBQUksRUFBRTtDQUdOLElBQUksSUFBSSxHQUFHO0VBR1QsSUFBSSxJQUFJLEVBQUUsRUFBRSxTQUFTLEdBQUcsT0FBTyxJQUFJLEtBQUssR0FBRztFQUczQyxLQUFLLEVBQUUsRUFBRSxLQUFLLE1BQU0sR0FBRyxJQUFJO0VBRzNCLElBQUksRUFBRSxLQUFLLEtBQUssRUFBRSxFQUFFLE1BQU0sS0FBSyxFQUFFLEVBQUUsVUFBVSxHQUFHO0dBQzlDLEVBQUUsSUFBSTtHQUNOLE9BQU87RUFDVDtDQUNGO0NBTUEsSUFBSSxRQUFRLENBQUMsR0FBRyxFQUFFO0NBQ2xCLElBQUksS0FBSyxLQUFLLENBQUMsU0FBUyxDQUFDLElBQ3JCLFVBQVUsTUFBTSxLQUFLLElBQUksT0FBTyxlQUFlLEVBQUUsQ0FBQyxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUUsSUFBSSxFQUFFLElBQzNFLElBQUksS0FBSyxJQUFJLEVBQUUsQ0FBQyxDQUFDO0NBS3JCLElBQUksSUFBSSxLQUFLLE9BQU8sS0FBSyxJQUFJLEtBQUssT0FBTyxHQUFHLE9BQU8sSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLElBQUksQ0FBQztDQUU3RSxXQUFXO0NBQ1gsS0FBSyxXQUFXLEVBQUUsSUFBSTtDQU10QixJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksR0FBQSxDQUFJLE1BQU07Q0FHaEMsSUFBSSxtQkFBbUIsRUFBRSxNQUFNLGlCQUFpQixHQUFHLEtBQUssQ0FBQyxDQUFDLEdBQUcsRUFBRTtDQUcvRCxJQUFJLEVBQUUsR0FBRztFQUdQLElBQUksU0FBUyxHQUFHLEtBQUssR0FBRyxDQUFDO0VBSXpCLElBQUksb0JBQW9CLEVBQUUsR0FBRyxJQUFJLEVBQUUsR0FBRztHQUNwQyxJQUFJLEtBQUs7R0FHVCxJQUFJLFNBQVMsbUJBQW1CLEVBQUUsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQztHQUdqRixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDLE1BQU0sS0FBSyxHQUFHLEtBQUssRUFBRSxJQUFJLEtBQUssZ0JBQ3JELElBQUksU0FBUyxHQUFHLEtBQUssR0FBRyxDQUFDO0VBRTdCO0NBQ0Y7Q0FFQSxFQUFFLElBQUk7Q0FDTixXQUFXO0NBQ1gsS0FBSyxXQUFXO0NBRWhCLE9BQU8sU0FBUyxHQUFHLElBQUksRUFBRTtBQUMzQjtBQWNBLEVBQUUsY0FBYyxTQUFVLElBQUksSUFBSTtDQUNoQyxJQUFJLEtBQ0YsSUFBSSxNQUNKLE9BQU8sRUFBRTtDQUVYLElBQUksT0FBTyxLQUFLLEdBQ2QsTUFBTSxlQUFlLEdBQUcsRUFBRSxLQUFLLEtBQUssWUFBWSxFQUFFLEtBQUssS0FBSyxRQUFRO01BQy9EO0VBQ0wsV0FBVyxJQUFJLEdBQUcsVUFBVTtFQUU1QixJQUFJLE9BQU8sS0FBSyxHQUFHLEtBQUssS0FBSztPQUN4QixXQUFXLElBQUksR0FBRyxDQUFDO0VBRXhCLElBQUksU0FBUyxJQUFJLEtBQUssQ0FBQyxHQUFHLElBQUksRUFBRTtFQUNoQyxNQUFNLGVBQWUsR0FBRyxNQUFNLEVBQUUsS0FBSyxFQUFFLEtBQUssS0FBSyxVQUFVLEVBQUU7Q0FDL0Q7Q0FFQSxPQUFPLEVBQUUsTUFBTSxLQUFLLENBQUMsRUFBRSxPQUFPLElBQUksTUFBTSxNQUFNO0FBQ2hEO0FBaUJBLEVBQUUsc0JBQXNCLEVBQUUsT0FBTyxTQUFVLElBQUksSUFBSTtDQUNqRCxJQUFJLElBQUksTUFDTixPQUFPLEVBQUU7Q0FFWCxJQUFJLE9BQU8sS0FBSyxHQUFHO0VBQ2pCLEtBQUssS0FBSztFQUNWLEtBQUssS0FBSztDQUNaLE9BQU87RUFDTCxXQUFXLElBQUksR0FBRyxVQUFVO0VBRTVCLElBQUksT0FBTyxLQUFLLEdBQUcsS0FBSyxLQUFLO09BQ3hCLFdBQVcsSUFBSSxHQUFHLENBQUM7Q0FDMUI7Q0FFQSxPQUFPLFNBQVMsSUFBSSxLQUFLLENBQUMsR0FBRyxJQUFJLEVBQUU7QUFDckM7QUFVQSxFQUFFLFdBQVcsV0FBWTtDQUN2QixJQUFJLElBQUksTUFDTixPQUFPLEVBQUUsYUFDVCxNQUFNLGVBQWUsR0FBRyxFQUFFLEtBQUssS0FBSyxZQUFZLEVBQUUsS0FBSyxLQUFLLFFBQVE7Q0FFdEUsT0FBTyxFQUFFLE1BQU0sS0FBSyxDQUFDLEVBQUUsT0FBTyxJQUFJLE1BQU0sTUFBTTtBQUNoRDtBQU9BLEVBQUUsWUFBWSxFQUFFLFFBQVEsV0FBWTtDQUNsQyxPQUFPLFNBQVMsSUFBSSxLQUFLLFlBQVksSUFBSSxHQUFHLEtBQUssSUFBSSxHQUFHLENBQUM7QUFDM0Q7QUFRQSxFQUFFLFVBQVUsRUFBRSxTQUFTLFdBQVk7Q0FDakMsSUFBSSxJQUFJLE1BQ04sT0FBTyxFQUFFLGFBQ1QsTUFBTSxlQUFlLEdBQUcsRUFBRSxLQUFLLEtBQUssWUFBWSxFQUFFLEtBQUssS0FBSyxRQUFRO0NBRXRFLE9BQU8sRUFBRSxNQUFNLElBQUksTUFBTSxNQUFNO0FBQ2pDO0FBb0RBLFNBQVMsZUFBZSxHQUFHO0NBQ3pCLElBQUksR0FBRyxHQUFHLElBQ1Isa0JBQWtCLEVBQUUsU0FBUyxHQUM3QixNQUFNLElBQ04sSUFBSSxFQUFFO0NBRVIsSUFBSSxrQkFBa0IsR0FBRztFQUN2QixPQUFPO0VBQ1AsS0FBSyxJQUFJLEdBQUcsSUFBSSxpQkFBaUIsS0FBSztHQUNwQyxLQUFLLEVBQUUsS0FBSztHQUNaLElBQUksV0FBVyxHQUFHO0dBQ2xCLElBQUksR0FBRyxPQUFPLGNBQWMsQ0FBQztHQUM3QixPQUFPO0VBQ1Q7RUFFQSxJQUFJLEVBQUU7RUFDTixLQUFLLElBQUk7RUFDVCxJQUFJLFdBQVcsR0FBRztFQUNsQixJQUFJLEdBQUcsT0FBTyxjQUFjLENBQUM7Q0FDL0IsT0FBTyxJQUFJLE1BQU0sR0FDZixPQUFPO0NBSVQsT0FBTyxJQUFJLE9BQU8sSUFBSSxLQUFLO0NBRTNCLE9BQU8sTUFBTTtBQUNmO0FBR0EsU0FBUyxXQUFXLEdBQUcsS0FBSyxLQUFLO0NBQy9CLElBQUksTUFBTSxDQUFDLENBQUMsS0FBSyxJQUFJLE9BQU8sSUFBSSxLQUM5QixNQUFNLE1BQU0sa0JBQWtCLENBQUM7QUFFbkM7QUFRQSxTQUFTLG9CQUFvQixHQUFHLEdBQUcsSUFBSSxXQUFXO0NBQ2hELElBQUksSUFBSSxJQUdDLEVBQUUsSUFIQSxHQUFHO0NBR2QsT0FBZSxLQUFLLElBQUksS0FBSyxJQUFJLEVBQUU7Q0FHbkMsSUFBSSxFQUFFLElBQUksR0FBRztFQUNYLEtBQUs7RUFDTCxLQUFLO0NBQ1AsT0FBTztFQUNMLEtBQUssS0FBSyxNQUFNLElBQUksS0FBSyxRQUFRO0VBQ2pDLEtBQUs7Q0FDUDtDQUtBLElBQUksUUFBUSxJQUFJLFdBQVcsQ0FBQztDQUM1QixLQUFLLEVBQUUsTUFBTSxJQUFJO0NBRWpCLElBQUksYUFBYSxNQUFNO0VBQ3JCLElBQUksSUFBSSxHQUFHO0dBQ1QsSUFBSSxLQUFLLEdBQUcsS0FBSyxLQUFLLE1BQU07UUFDdkIsSUFBSSxLQUFLLEdBQUcsS0FBSyxLQUFLLEtBQUs7R0FDaEMsSUFBSSxLQUFLLEtBQUssTUFBTSxTQUFTLEtBQUssS0FBSyxNQUFNLFNBQVMsTUFBTSxPQUFTLE1BQU07RUFDN0UsT0FDRSxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLElBQUksT0FDbkQsRUFBRSxLQUFLLEtBQUssSUFBSSxNQUFNLE1BQU0sUUFBUSxJQUFJLElBQUksQ0FBQyxJQUFJLE1BQy9DLE1BQU0sSUFBSSxLQUFLLE1BQU0sT0FBTyxFQUFFLEtBQUssS0FBSyxJQUFJLE1BQU0sTUFBTTtDQUVqRSxPQUNFLElBQUksSUFBSSxHQUFHO0VBQ1QsSUFBSSxLQUFLLEdBQUcsS0FBSyxLQUFLLE1BQU87T0FDeEIsSUFBSSxLQUFLLEdBQUcsS0FBSyxLQUFLLE1BQU07T0FDNUIsSUFBSSxLQUFLLEdBQUcsS0FBSyxLQUFLLEtBQUs7RUFDaEMsS0FBSyxhQUFhLEtBQUssTUFBTSxNQUFNLFFBQVEsQ0FBQyxhQUFhLEtBQUssS0FBSyxNQUFNO0NBQzNFLE9BQ0UsTUFBTSxhQUFhLEtBQUssTUFBTSxLQUFLLEtBQUssS0FDdkMsQ0FBQyxhQUFhLEtBQUssS0FBTSxLQUFLLEtBQUssSUFBSSxPQUNyQyxFQUFFLEtBQUssS0FBSyxJQUFJLE1BQU8sTUFBTSxRQUFRLElBQUksSUFBSSxDQUFDLElBQUk7Q0FJekQsT0FBTztBQUNUO0FBTUEsU0FBUyxZQUFZLEtBQUssUUFBUSxTQUFTO0NBQ3pDLElBQUksR0FDRixNQUFNLENBQUMsQ0FBQyxHQUNSLE1BQ0EsSUFBSSxHQUNKLE9BQU8sSUFBSTtDQUViLE9BQU8sSUFBSSxPQUFPO0VBQ2hCLEtBQUssT0FBTyxJQUFJLFFBQVEsU0FBUyxJQUFJLFNBQVM7RUFDOUMsSUFBSSxNQUFNLFNBQVMsUUFBUSxJQUFJLE9BQU8sR0FBRyxDQUFDO0VBQzFDLEtBQUssSUFBSSxHQUFHLElBQUksSUFBSSxRQUFRLEtBQzFCLElBQUksSUFBSSxLQUFLLFVBQVUsR0FBRztHQUN4QixJQUFJLElBQUksSUFBSSxPQUFPLEtBQUssR0FBRyxJQUFJLElBQUksS0FBSztHQUN4QyxJQUFJLElBQUksTUFBTSxJQUFJLEtBQUssVUFBVTtHQUNqQyxJQUFJLE1BQU07RUFDWjtDQUVKO0NBRUEsT0FBTyxJQUFJLFFBQVE7QUFDckI7QUFRQSxTQUFTLE9BQU8sTUFBTSxHQUFHO0NBQ3ZCLElBQUksR0FBRyxLQUFLO0NBRVosSUFBSSxFQUFFLE9BQU8sR0FBRyxPQUFPO0NBTXZCLE1BQU0sRUFBRSxFQUFFO0NBQ1YsSUFBSSxNQUFNLElBQUk7RUFDWixJQUFJLEtBQUssS0FBSyxNQUFNLENBQUM7RUFDckIsS0FBSyxJQUFJLFFBQVEsR0FBRyxDQUFDLEVBQUEsQ0FBRyxTQUFTO0NBQ25DLE9BQU87RUFDTCxJQUFJO0VBQ0osSUFBSTtDQUNOO0NBRUEsS0FBSyxhQUFhO0NBRWxCLElBQUksYUFBYSxNQUFNLEdBQUcsRUFBRSxNQUFNLENBQUMsR0FBRyxJQUFJLEtBQUssQ0FBQyxDQUFDO0NBR2pELEtBQUssSUFBSSxJQUFJLEdBQUcsTUFBTTtFQUNwQixJQUFJLFFBQVEsRUFBRSxNQUFNLENBQUM7RUFDckIsSUFBSSxNQUFNLE1BQU0sS0FBSyxDQUFDLENBQUMsTUFBTSxLQUFLLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztDQUNyRDtDQUVBLEtBQUssYUFBYTtDQUVsQixPQUFPO0FBQ1Q7QUFNQSxJQUFJLFVBQVUsV0FBWTtDQUd4QixTQUFTLGdCQUFnQixHQUFHLEdBQUcsTUFBTTtFQUNuQyxJQUFJLE1BQ0YsUUFBUSxHQUNSLElBQUksRUFBRTtFQUVSLEtBQUssSUFBSSxFQUFFLE1BQU0sR0FBRyxNQUFNO0dBQ3hCLE9BQU8sRUFBRSxLQUFLLElBQUk7R0FDbEIsRUFBRSxLQUFLLE9BQU8sT0FBTztHQUNyQixRQUFRLE9BQU8sT0FBTztFQUN4QjtFQUVBLElBQUksT0FBTyxFQUFFLFFBQVEsS0FBSztFQUUxQixPQUFPO0NBQ1Q7Q0FFQSxTQUFTLFFBQVEsR0FBRyxHQUFHLElBQUksSUFBSTtFQUM3QixJQUFJLEdBQUc7RUFFUCxJQUFJLE1BQU0sSUFDUixJQUFJLEtBQUssS0FBSyxJQUFJO09BRWxCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQ3RCLElBQUksRUFBRSxNQUFNLEVBQUUsSUFBSTtHQUNoQixJQUFJLEVBQUUsS0FBSyxFQUFFLEtBQUssSUFBSTtHQUN0QjtFQUNGO0VBSUosT0FBTztDQUNUO0NBRUEsU0FBUyxTQUFTLEdBQUcsR0FBRyxJQUFJLE1BQU07RUFDaEMsSUFBSSxJQUFJO0VBR1IsT0FBTyxPQUFPO0dBQ1osRUFBRSxPQUFPO0dBQ1QsSUFBSSxFQUFFLE1BQU0sRUFBRSxNQUFNLElBQUk7R0FDeEIsRUFBRSxNQUFNLElBQUksT0FBTyxFQUFFLE1BQU0sRUFBRTtFQUMvQjtFQUdBLE9BQU8sQ0FBQyxFQUFFLE1BQU0sRUFBRSxTQUFTLElBQUksRUFBRSxNQUFNO0NBQ3pDO0NBRUEsT0FBTyxTQUFVLEdBQUcsR0FBRyxJQUFJLElBQUksSUFBSSxNQUFNO0VBQ3ZDLElBQUksS0FBSyxHQUFHLEdBQUcsR0FBRyxTQUFTLE1BQU0sTUFBTSxPQUFPLEdBQUcsSUFBSSxLQUFLLE1BQU0sTUFBTSxJQUFJLEdBQUcsSUFBSSxJQUFJLEtBQ25GLElBQUksSUFDSixPQUFPLEVBQUUsYUFDVCxPQUFPLEVBQUUsS0FBSyxFQUFFLElBQUksSUFBSSxJQUN4QixLQUFLLEVBQUUsR0FDUCxLQUFLLEVBQUU7RUFHVCxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBRTlCLE9BQU8sSUFBSSxLQUNULENBQUMsRUFBRSxLQUFLLENBQUMsRUFBRSxNQUFNLEtBQUssTUFBTSxHQUFHLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxNQUdwRCxNQUFNLEdBQUcsTUFBTSxLQUFLLENBQUMsS0FBSyxPQUFPLElBQUksT0FBTyxDQUFDO0VBR2pELElBQUksTUFBTTtHQUNSLFVBQVU7R0FDVixJQUFJLEVBQUUsSUFBSSxFQUFFO0VBQ2QsT0FBTztHQUNMLE9BQU87R0FDUCxVQUFVO0dBQ1YsSUFBSSxVQUFVLEVBQUUsSUFBSSxPQUFPLElBQUksVUFBVSxFQUFFLElBQUksT0FBTztFQUN4RDtFQUVBLEtBQUssR0FBRztFQUNSLEtBQUssR0FBRztFQUNSLElBQUksSUFBSSxLQUFLLElBQUk7RUFDakIsS0FBSyxFQUFFLElBQUksQ0FBQztFQUlaLEtBQUssSUFBSSxHQUFHLEdBQUcsT0FBTyxHQUFHLE1BQU0sSUFBSTtFQUVuQyxJQUFJLEdBQUcsTUFBTSxHQUFHLE1BQU0sSUFBSTtFQUUxQixJQUFJLE1BQU0sTUFBTTtHQUNkLEtBQUssS0FBSyxLQUFLO0dBQ2YsS0FBSyxLQUFLO0VBQ1osT0FBTyxJQUFJLElBQ1QsS0FBSyxNQUFNLEVBQUUsSUFBSSxFQUFFLEtBQUs7T0FFeEIsS0FBSztFQUdQLElBQUksS0FBSyxHQUFHO0dBQ1YsR0FBRyxLQUFLLENBQUM7R0FDVCxPQUFPO0VBQ1QsT0FBTztHQUdMLEtBQUssS0FBSyxVQUFVLElBQUk7R0FDeEIsSUFBSTtHQUdKLElBQUksTUFBTSxHQUFHO0lBQ1gsSUFBSTtJQUNKLEtBQUssR0FBRztJQUNSO0lBR0EsUUFBUSxJQUFJLE1BQU0sTUFBTSxNQUFNLEtBQUs7S0FDakMsSUFBSSxJQUFJLFFBQVEsR0FBRyxNQUFNO0tBQ3pCLEdBQUcsS0FBSyxJQUFJLEtBQUs7S0FDakIsSUFBSSxJQUFJLEtBQUs7SUFDZjtJQUVBLE9BQU8sS0FBSyxJQUFJO0dBR2xCLE9BQU87SUFHTCxJQUFJLFFBQVEsR0FBRyxLQUFLLEtBQUs7SUFFekIsSUFBSSxJQUFJLEdBQUc7S0FDVCxLQUFLLGdCQUFnQixJQUFJLEdBQUcsSUFBSTtLQUNoQyxLQUFLLGdCQUFnQixJQUFJLEdBQUcsSUFBSTtLQUNoQyxLQUFLLEdBQUc7S0FDUixLQUFLLEdBQUc7SUFDVjtJQUVBLEtBQUs7SUFDTCxNQUFNLEdBQUcsTUFBTSxHQUFHLEVBQUU7SUFDcEIsT0FBTyxJQUFJO0lBR1gsT0FBTyxPQUFPLEtBQUssSUFBSSxVQUFVO0lBRWpDLEtBQUssR0FBRyxNQUFNO0lBQ2QsR0FBRyxRQUFRLENBQUM7SUFDWixNQUFNLEdBQUc7SUFFVCxJQUFJLEdBQUcsTUFBTSxPQUFPLEdBQUcsRUFBRTtJQUV6QixHQUFHO0tBQ0QsSUFBSTtLQUdKLE1BQU0sUUFBUSxJQUFJLEtBQUssSUFBSSxJQUFJO0tBRy9CLElBQUksTUFBTSxHQUFHO01BR1gsT0FBTyxJQUFJO01BQ1gsSUFBSSxNQUFNLE1BQU0sT0FBTyxPQUFPLFFBQVEsSUFBSSxNQUFNO01BR2hELElBQUksT0FBTyxNQUFNO01BVWpCLElBQUksSUFBSSxHQUFHO09BQ1QsSUFBSSxLQUFLLE1BQU0sSUFBSSxPQUFPO09BRzFCLE9BQU8sZ0JBQWdCLElBQUksR0FBRyxJQUFJO09BQ2xDLFFBQVEsS0FBSztPQUNiLE9BQU8sSUFBSTtPQUdYLE1BQU0sUUFBUSxNQUFNLEtBQUssT0FBTyxJQUFJO09BR3BDLElBQUksT0FBTyxHQUFHO1FBQ1o7UUFHQSxTQUFTLE1BQU0sS0FBSyxRQUFRLEtBQUssSUFBSSxPQUFPLElBQUk7T0FDbEQ7TUFDRixPQUFPO09BS0wsSUFBSSxLQUFLLEdBQUcsTUFBTSxJQUFJO09BQ3RCLE9BQU8sR0FBRyxNQUFNO01BQ2xCO01BRUEsUUFBUSxLQUFLO01BQ2IsSUFBSSxRQUFRLE1BQU0sS0FBSyxRQUFRLENBQUM7TUFHaEMsU0FBUyxLQUFLLE1BQU0sTUFBTSxJQUFJO01BRzlCLElBQUksT0FBTyxJQUFJO09BQ2IsT0FBTyxJQUFJO09BR1gsTUFBTSxRQUFRLElBQUksS0FBSyxJQUFJLElBQUk7T0FHL0IsSUFBSSxNQUFNLEdBQUc7UUFDWDtRQUdBLFNBQVMsS0FBSyxLQUFLLE9BQU8sS0FBSyxJQUFJLE1BQU0sSUFBSTtPQUMvQztNQUNGO01BRUEsT0FBTyxJQUFJO0tBQ2IsT0FBTyxJQUFJLFFBQVEsR0FBRztNQUNwQjtNQUNBLE1BQU0sQ0FBQyxDQUFDO0tBQ1Y7S0FHQSxHQUFHLE9BQU87S0FHVixJQUFJLE9BQU8sSUFBSSxJQUNiLElBQUksVUFBVSxHQUFHLE9BQU87VUFDbkI7TUFDTCxNQUFNLENBQUMsR0FBRyxHQUFHO01BQ2IsT0FBTztLQUNUO0lBRUYsVUFBVSxPQUFPLE1BQU0sSUFBSSxPQUFPLEtBQUssTUFBTTtJQUU3QyxPQUFPLElBQUksT0FBTyxLQUFLO0dBQ3pCO0dBR0EsSUFBSSxDQUFDLEdBQUcsSUFBSSxHQUFHLE1BQU07RUFDdkI7RUFHQSxJQUFJLFdBQVcsR0FBRztHQUNoQixFQUFFLElBQUk7R0FDTixVQUFVO0VBQ1osT0FBTztHQUdMLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUk7R0FDekMsRUFBRSxJQUFJLElBQUksSUFBSSxVQUFVO0dBRXhCLFNBQVMsR0FBRyxLQUFLLEtBQUssRUFBRSxJQUFJLElBQUksSUFBSSxJQUFJLElBQUk7RUFDOUM7RUFFQSxPQUFPO0NBQ1Q7QUFDRixFQUFBLENBQUc7QUFPRixTQUFTLFNBQVMsR0FBRyxJQUFJLElBQUksYUFBYTtDQUN6QyxJQUFJLFFBQVEsR0FBRyxHQUFHLEdBQUcsSUFBSSxTQUFTLEdBQUcsSUFBSSxLQUN2QyxPQUFPLEVBQUU7Q0FHWCxLQUFLLElBQUksTUFBTSxNQUFNO0VBQ25CLEtBQUssRUFBRTtFQUdQLElBQUksQ0FBQyxJQUFJLE9BQU87RUFXaEIsS0FBSyxTQUFTLEdBQUcsSUFBSSxHQUFHLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSTtFQUM5QyxJQUFJLEtBQUs7RUFHVCxJQUFJLElBQUksR0FBRztHQUNULEtBQUs7R0FDTCxJQUFJO0dBQ0osSUFBSSxHQUFHLE1BQU07R0FHYixLQUFLLElBQUksUUFBUSxJQUFJLFNBQVMsSUFBSSxDQUFDLElBQUksS0FBSztFQUM5QyxPQUFPO0dBQ0wsTUFBTSxLQUFLLE1BQU0sSUFBSSxLQUFLLFFBQVE7R0FDbEMsSUFBSSxHQUFHO0dBQ1AsSUFBSSxPQUFPLEdBQUc7SUFDWixJQUFJLGFBQWE7S0FHZixPQUFPLE9BQU8sTUFBTSxHQUFHLEtBQUssQ0FBQztLQUM3QixJQUFJLEtBQUs7S0FDVCxTQUFTO0tBQ1QsS0FBSztLQUNMLElBQUksSUFBSSxXQUFXO0lBQ3JCLE9BQ0UsTUFBTTtHQUVWLE9BQU87SUFDTCxJQUFJLElBQUksR0FBRztJQUdYLEtBQUssU0FBUyxHQUFHLEtBQUssSUFBSSxLQUFLLElBQUk7SUFHbkMsS0FBSztJQUlMLElBQUksSUFBSSxXQUFXO0lBR25CLEtBQUssSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLElBQUksU0FBUyxJQUFJLENBQUMsSUFBSSxLQUFLO0dBQzFEO0VBQ0Y7RUFHQSxjQUFjLGVBQWUsS0FBSyxLQUNoQyxHQUFHLE1BQU0sT0FBTyxLQUFLLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxRQUFRLElBQUksU0FBUyxJQUFJLENBQUM7RUFNdkUsVUFBVSxLQUFLLEtBQ1YsTUFBTSxpQkFBaUIsTUFBTSxLQUFLLE9BQU8sRUFBRSxJQUFJLElBQUksSUFBSSxNQUN4RCxLQUFLLEtBQUssTUFBTSxNQUFNLE1BQU0sS0FBSyxlQUFlLE1BQU0sTUFHcEQsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLFFBQVEsSUFBSSxTQUFTLENBQUMsSUFBSSxJQUFJLEdBQUcsTUFBTSxNQUFNLEtBQU0sS0FDdkUsT0FBTyxFQUFFLElBQUksSUFBSSxJQUFJO0VBRTNCLElBQUksS0FBSyxLQUFLLENBQUMsR0FBRyxJQUFJO0dBQ3BCLEdBQUcsU0FBUztHQUNaLElBQUksU0FBUztJQUdYLE1BQU0sRUFBRSxJQUFJO0lBR1osR0FBRyxLQUFLLFFBQVEsS0FBSyxXQUFXLEtBQUssWUFBWSxRQUFRO0lBQ3pELEVBQUUsSUFBSSxDQUFDLE1BQU07R0FDZixPQUdFLEdBQUcsS0FBSyxFQUFFLElBQUk7R0FHaEIsT0FBTztFQUNUO0VBR0EsSUFBSSxLQUFLLEdBQUc7R0FDVixHQUFHLFNBQVM7R0FDWixJQUFJO0dBQ0o7RUFDRixPQUFPO0dBQ0wsR0FBRyxTQUFTLE1BQU07R0FDbEIsSUFBSSxRQUFRLElBQUksV0FBVyxDQUFDO0dBSTVCLEdBQUcsT0FBTyxJQUFJLEtBQUssSUFBSSxRQUFRLElBQUksU0FBUyxDQUFDLElBQUksUUFBUSxJQUFJLENBQUMsSUFBSSxLQUFLLElBQUk7RUFDN0U7RUFFQSxJQUFJLFNBQ0YsU0FHRSxJQUFJLE9BQU8sR0FBRztHQUdaLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUk7R0FDekMsSUFBSSxHQUFHLE1BQU07R0FDYixLQUFLLElBQUksR0FBRyxLQUFLLElBQUksS0FBSyxJQUFJO0dBRzlCLElBQUksS0FBSyxHQUFHO0lBQ1YsRUFBRTtJQUNGLElBQUksR0FBRyxNQUFNLE1BQU0sR0FBRyxLQUFLO0dBQzdCO0dBRUE7RUFDRixPQUFPO0dBQ0wsR0FBRyxRQUFRO0dBQ1gsSUFBSSxHQUFHLFFBQVEsTUFBTTtHQUNyQixHQUFHLFNBQVM7R0FDWixJQUFJO0VBQ047RUFLSixLQUFLLElBQUksR0FBRyxRQUFRLEdBQUcsRUFBRSxPQUFPLElBQUksR0FBRyxJQUFJO0NBQzdDO0NBRUEsSUFBSSxVQUFVO0VBR1osSUFBSSxFQUFFLElBQUksS0FBSyxNQUFNO0dBR25CLEVBQUUsSUFBSTtHQUNOLEVBQUUsSUFBSTtFQUdSLE9BQU8sSUFBSSxFQUFFLElBQUksS0FBSyxNQUFNO0dBRzFCLEVBQUUsSUFBSTtHQUNOLEVBQUUsSUFBSSxDQUFDLENBQUM7RUFFVjtDQUNGO0NBRUEsT0FBTztBQUNUO0FBR0EsU0FBUyxlQUFlLEdBQUcsT0FBTyxJQUFJO0NBQ3BDLElBQUksQ0FBQyxFQUFFLFNBQVMsR0FBRyxPQUFPLGtCQUFrQixDQUFDO0NBQzdDLElBQUksR0FDRixJQUFJLEVBQUUsR0FDTixNQUFNLGVBQWUsRUFBRSxDQUFDLEdBQ3hCLE1BQU0sSUFBSTtDQUVaLElBQUksT0FBTztFQUNULElBQUksT0FBTyxJQUFJLEtBQUssT0FBTyxHQUN6QixNQUFNLElBQUksT0FBTyxDQUFDLElBQUksTUFBTSxJQUFJLE1BQU0sQ0FBQyxJQUFJLGNBQWMsQ0FBQztPQUNyRCxJQUFJLE1BQU0sR0FDZixNQUFNLElBQUksT0FBTyxDQUFDLElBQUksTUFBTSxJQUFJLE1BQU0sQ0FBQztFQUd6QyxNQUFNLE9BQU8sRUFBRSxJQUFJLElBQUksTUFBTSxRQUFRLEVBQUU7Q0FDekMsT0FBTyxJQUFJLElBQUksR0FBRztFQUNoQixNQUFNLE9BQU8sY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJO0VBQ3JDLElBQUksT0FBTyxJQUFJLEtBQUssT0FBTyxHQUFHLE9BQU8sY0FBYyxDQUFDO0NBQ3RELE9BQU8sSUFBSSxLQUFLLEtBQUs7RUFDbkIsT0FBTyxjQUFjLElBQUksSUFBSSxHQUFHO0VBQ2hDLElBQUksT0FBTyxJQUFJLEtBQUssSUFBSSxLQUFLLEdBQUcsTUFBTSxNQUFNLE1BQU0sY0FBYyxDQUFDO0NBQ25FLE9BQU87RUFDTCxLQUFLLElBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxJQUFJLE1BQU0sR0FBRyxDQUFDLElBQUksTUFBTSxJQUFJLE1BQU0sQ0FBQztFQUNoRSxJQUFJLE9BQU8sSUFBSSxLQUFLLE9BQU8sR0FBRztHQUM1QixJQUFJLElBQUksTUFBTSxLQUFLLE9BQU87R0FDMUIsT0FBTyxjQUFjLENBQUM7RUFDeEI7Q0FDRjtDQUVBLE9BQU87QUFDVDtBQUlBLFNBQVMsa0JBQWtCLFFBQVEsR0FBRztDQUNwQyxJQUFJLElBQUksT0FBTztDQUdmLEtBQU0sS0FBSyxVQUFVLEtBQUssSUFBSSxLQUFLLElBQUk7Q0FDdkMsT0FBTztBQUNUO0FBR0EsU0FBUyxRQUFRLE1BQU0sSUFBSSxJQUFJO0NBQzdCLElBQUksS0FBSyxnQkFBZ0I7RUFHdkIsV0FBVztFQUNYLElBQUksSUFBSSxLQUFLLFlBQVk7RUFDekIsTUFBTSxNQUFNLHNCQUFzQjtDQUNwQztDQUNBLE9BQU8sU0FBUyxJQUFJLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJO0FBQzdDO0FBR0EsU0FBUyxNQUFNLE1BQU0sSUFBSSxJQUFJO0NBQzNCLElBQUksS0FBSyxjQUFjLE1BQU0sTUFBTSxzQkFBc0I7Q0FDekQsT0FBTyxTQUFTLElBQUksS0FBSyxFQUFFLEdBQUcsSUFBSSxJQUFJLElBQUk7QUFDNUM7QUFHQSxTQUFTLGFBQWEsUUFBUTtDQUM1QixJQUFJLElBQUksT0FBTyxTQUFTLEdBQ3RCLE1BQU0sSUFBSSxXQUFXO0NBRXZCLElBQUksT0FBTztDQUdYLElBQUksR0FBRztFQUdMLE9BQU8sSUFBSSxNQUFNLEdBQUcsS0FBSyxJQUFJO0VBRzdCLEtBQUssSUFBSSxPQUFPLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSTtDQUN4QztDQUVBLE9BQU87QUFDVDtBQUdBLFNBQVMsY0FBYyxHQUFHO0NBQ3hCLElBQUksS0FBSztDQUNULE9BQU8sTUFBTSxNQUFNO0NBQ25CLE9BQU87QUFDVDtBQVVBLFNBQVMsT0FBTyxNQUFNLEdBQUcsR0FBRyxJQUFJO0NBQzlCLElBQUksYUFDRixJQUFJLElBQUksS0FBSyxDQUFDLEdBSWQsSUFBSSxLQUFLLEtBQUssS0FBSyxXQUFXLENBQUM7Q0FFakMsV0FBVztDQUVYLFNBQVM7RUFDUCxJQUFJLElBQUksR0FBRztHQUNULElBQUksRUFBRSxNQUFNLENBQUM7R0FDYixJQUFJLFNBQVMsRUFBRSxHQUFHLENBQUMsR0FBRyxjQUFjO0VBQ3RDO0VBRUEsSUFBSSxVQUFVLElBQUksQ0FBQztFQUNuQixJQUFJLE1BQU0sR0FBRztHQUdYLElBQUksRUFBRSxFQUFFLFNBQVM7R0FDakIsSUFBSSxlQUFlLEVBQUUsRUFBRSxPQUFPLEdBQUcsRUFBRSxFQUFFLEVBQUU7R0FDdkM7RUFDRjtFQUVBLElBQUksRUFBRSxNQUFNLENBQUM7RUFDYixTQUFTLEVBQUUsR0FBRyxDQUFDO0NBQ2pCO0NBRUEsV0FBVztDQUVYLE9BQU87QUFDVDtBQUdBLFNBQVMsTUFBTSxHQUFHO0NBQ2hCLE9BQU8sRUFBRSxFQUFFLEVBQUUsRUFBRSxTQUFTLEtBQUs7QUFDL0I7QUFNQSxTQUFTLFNBQVMsTUFBTSxNQUFNLEdBQUc7Q0FDL0IsSUFBSSxHQUFHLEdBQ0wsSUFBSSxJQUFJLEtBQUssS0FBSyxFQUFFLEdBQ3BCLElBQUk7Q0FFTixPQUFPLEVBQUUsSUFBSSxLQUFLLFNBQVM7RUFDekIsSUFBSSxJQUFJLEtBQUssS0FBSyxFQUFFO0VBR3BCLElBQUksQ0FBQyxFQUFFLEdBQUc7R0FDUixJQUFJO0dBQ0o7RUFDRjtFQUVBLElBQUksRUFBRSxJQUFJLENBQUM7RUFFWCxJQUFJLE1BQU0sS0FBSyxNQUFNLEtBQUssRUFBRSxNQUFNLEdBQ2hDLElBQUk7Q0FFUjtDQUVBLE9BQU87QUFDVDtBQWtDQSxTQUFTLG1CQUFtQixHQUFHLElBQUk7Q0FDakMsSUFBSSxhQUFhLE9BQU8sR0FBRyxLQUFLLEtBQUssR0FBRyxLQUN0QyxNQUFNLEdBQ04sSUFBSSxHQUNKLElBQUksR0FDSixPQUFPLEVBQUUsYUFDVCxLQUFLLEtBQUssVUFDVixLQUFLLEtBQUs7Q0FHWixJQUFJLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLElBRTNCLE9BQU8sSUFBSSxLQUFLLEVBQUUsSUFDZCxDQUFDLEVBQUUsRUFBRSxLQUFLLElBQUksRUFBRSxJQUFJLElBQUksSUFBSSxJQUFJLElBQ2hDLEVBQUUsSUFBSSxFQUFFLElBQUksSUFBSSxJQUFJLElBQUksR0FBSztDQUduQyxJQUFJLE1BQU0sTUFBTTtFQUNkLFdBQVc7RUFDWCxNQUFNO0NBQ1IsT0FDRSxNQUFNO0NBR1IsSUFBSSxJQUFJLEtBQUssTUFBTztDQUdwQixPQUFPLEVBQUUsSUFBSSxJQUFJO0VBR2YsSUFBSSxFQUFFLE1BQU0sQ0FBQztFQUNiLEtBQUs7Q0FDUDtDQUlBLFFBQVEsS0FBSyxJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUMsSUFBSSxLQUFLLE9BQU8sSUFBSSxJQUFJO0NBQ3RELE9BQU87Q0FDUCxjQUFjLE1BQU0sTUFBTSxJQUFJLEtBQUssQ0FBQztDQUNwQyxLQUFLLFlBQVk7Q0FFakIsU0FBUztFQUNQLE1BQU0sU0FBUyxJQUFJLE1BQU0sQ0FBQyxHQUFHLEtBQUssQ0FBQztFQUNuQyxjQUFjLFlBQVksTUFBTSxFQUFFLENBQUM7RUFDbkMsSUFBSSxJQUFJLEtBQUssT0FBTyxLQUFLLGFBQWEsS0FBSyxDQUFDLENBQUM7RUFFN0MsSUFBSSxlQUFlLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLEdBQUcsTUFBTSxlQUFlLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHLEdBQUcsR0FBRztHQUM3RSxJQUFJO0dBQ0osT0FBTyxLQUFLLE1BQU0sU0FBUyxJQUFJLE1BQU0sR0FBRyxHQUFHLEtBQUssQ0FBQztHQU9qRCxJQUFJLE1BQU0sTUFBTTtJQUVkLElBQUksTUFBTSxLQUFLLG9CQUFvQixJQUFJLEdBQUcsTUFBTSxPQUFPLElBQUksR0FBRyxHQUFHO0tBQy9ELEtBQUssWUFBWSxPQUFPO0tBQ3hCLGNBQWMsTUFBTSxJQUFJLElBQUksS0FBSyxDQUFDO0tBQ2xDLElBQUk7S0FDSjtJQUNGLE9BQ0UsT0FBTyxTQUFTLEtBQUssS0FBSyxZQUFZLElBQUksSUFBSSxXQUFXLElBQUk7R0FFakUsT0FBTztJQUNMLEtBQUssWUFBWTtJQUNqQixPQUFPO0dBQ1Q7RUFDRjtFQUVBLE1BQU07Q0FDUjtBQUNGO0FBa0JBLFNBQVMsaUJBQWlCLEdBQUcsSUFBSTtDQUMvQixJQUFJLEdBQUcsSUFBSSxhQUFhLEdBQUcsV0FBVyxLQUFLLEtBQUssR0FBRyxLQUFLLElBQUksSUFDMUQsSUFBSSxHQUNKLFFBQVEsSUFDUixJQUFJLEdBQ0osS0FBSyxFQUFFLEdBQ1AsT0FBTyxFQUFFLGFBQ1QsS0FBSyxLQUFLLFVBQ1YsS0FBSyxLQUFLO0NBR1osSUFBSSxFQUFFLElBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLE1BQU0sQ0FBQyxFQUFFLEtBQUssR0FBRyxNQUFNLEtBQUssR0FBRyxVQUFVLEdBQ2pFLE9BQU8sSUFBSSxLQUFLLE1BQU0sQ0FBQyxHQUFHLEtBQUssS0FBSyxJQUFJLEVBQUUsS0FBSyxJQUFJLE1BQU0sS0FBSyxJQUFJLENBQUM7Q0FHckUsSUFBSSxNQUFNLE1BQU07RUFDZCxXQUFXO0VBQ1gsTUFBTTtDQUNSLE9BQ0UsTUFBTTtDQUdSLEtBQUssWUFBWSxPQUFPO0NBQ3hCLElBQUksZUFBZSxFQUFFO0NBQ3JCLEtBQUssRUFBRSxPQUFPLENBQUM7Q0FFZixJQUFJLEtBQUssSUFBSSxJQUFJLEVBQUUsQ0FBQyxJQUFJLGlCQUFRO0VBYTlCLE9BQU8sS0FBSyxLQUFLLE1BQU0sS0FBSyxNQUFNLEtBQUssRUFBRSxPQUFPLENBQUMsSUFBSSxHQUFHO0dBQ3RELElBQUksRUFBRSxNQUFNLENBQUM7R0FDYixJQUFJLGVBQWUsRUFBRSxDQUFDO0dBQ3RCLEtBQUssRUFBRSxPQUFPLENBQUM7R0FDZjtFQUNGO0VBRUEsSUFBSSxFQUFFO0VBRU4sSUFBSSxLQUFLLEdBQUc7R0FDVixJQUFJLElBQUksS0FBSyxPQUFPLENBQUM7R0FDckI7RUFDRixPQUNFLElBQUksSUFBSSxLQUFLLEtBQUssTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0NBRXRDLE9BQU87RUFLTCxJQUFJLFFBQVEsTUFBTSxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUMsTUFBTSxJQUFJLEVBQUU7RUFDM0MsSUFBSSxpQkFBaUIsSUFBSSxLQUFLLEtBQUssTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDLEdBQUcsTUFBTSxLQUFLLENBQUMsQ0FBQyxLQUFLLENBQUM7RUFDekUsS0FBSyxZQUFZO0VBRWpCLE9BQU8sTUFBTSxPQUFPLFNBQVMsR0FBRyxJQUFJLElBQUksV0FBVyxJQUFJLElBQUk7Q0FDN0Q7Q0FHQSxLQUFLO0NBS0wsTUFBTSxZQUFZLElBQUksT0FBTyxFQUFFLE1BQU0sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDO0NBQzFELEtBQUssU0FBUyxFQUFFLE1BQU0sQ0FBQyxHQUFHLEtBQUssQ0FBQztDQUNoQyxjQUFjO0NBRWQsU0FBUztFQUNQLFlBQVksU0FBUyxVQUFVLE1BQU0sRUFBRSxHQUFHLEtBQUssQ0FBQztFQUNoRCxJQUFJLElBQUksS0FBSyxPQUFPLFdBQVcsSUFBSSxLQUFLLFdBQVcsR0FBRyxLQUFLLENBQUMsQ0FBQztFQUU3RCxJQUFJLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsR0FBRyxNQUFNLGVBQWUsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNLEdBQUcsR0FBRyxHQUFHO0dBQzdFLE1BQU0sSUFBSSxNQUFNLENBQUM7R0FJakIsSUFBSSxNQUFNLEdBQUcsTUFBTSxJQUFJLEtBQUssUUFBUSxNQUFNLE1BQU0sR0FBRyxFQUFFLENBQUMsQ0FBQyxNQUFNLElBQUksRUFBRSxDQUFDO0dBQ3BFLE1BQU0sT0FBTyxLQUFLLElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDO0dBUXJDLElBQUksTUFBTSxNQUFNO0lBQ2QsSUFBSSxvQkFBb0IsSUFBSSxHQUFHLE1BQU0sT0FBTyxJQUFJLEdBQUcsR0FBRztLQUNwRCxLQUFLLFlBQVksT0FBTztLQUN4QixJQUFJLFlBQVksSUFBSSxPQUFPLEdBQUcsTUFBTSxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUM7S0FDMUQsS0FBSyxTQUFTLEVBQUUsTUFBTSxDQUFDLEdBQUcsS0FBSyxDQUFDO0tBQ2hDLGNBQWMsTUFBTTtJQUN0QixPQUNFLE9BQU8sU0FBUyxLQUFLLEtBQUssWUFBWSxJQUFJLElBQUksV0FBVyxJQUFJO0dBRWpFLE9BQU87SUFDTCxLQUFLLFlBQVk7SUFDakIsT0FBTztHQUNUO0VBQ0Y7RUFFQSxNQUFNO0VBQ04sZUFBZTtDQUNqQjtBQUNGO0FBSUEsU0FBUyxrQkFBa0IsR0FBRztDQUU1QixPQUFPLE9BQU8sRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDO0FBQzdCO0FBTUEsU0FBUyxhQUFhLEdBQUcsS0FBSztDQUM1QixJQUFJLEdBQUcsR0FBRztDQUlWLEtBQUssSUFBSSxJQUFJLFFBQVEsR0FBRyxLQUFLLElBQUksTUFBTSxJQUFJLFFBQVEsS0FBSyxFQUFFO0NBRzFELEtBQUssSUFBSSxJQUFJLE9BQU8sSUFBSSxLQUFLLEdBQUc7RUFHOUIsSUFBSSxJQUFJLEdBQUcsSUFBSTtFQUNmLEtBQUssQ0FBQyxJQUFJLE1BQU0sSUFBSSxDQUFDO0VBQ3JCLE1BQU0sSUFBSSxVQUFVLEdBQUcsQ0FBQztDQUMxQixPQUFPLElBQUksSUFBSSxHQUdiLElBQUksSUFBSTtDQUlWLEtBQUssSUFBSSxHQUFHLElBQUksV0FBVyxDQUFDLE1BQU0sSUFBSTtDQUd0QyxLQUFLLE1BQU0sSUFBSSxRQUFRLElBQUksV0FBVyxNQUFNLENBQUMsTUFBTSxJQUFJLEVBQUU7Q0FDekQsTUFBTSxJQUFJLE1BQU0sR0FBRyxHQUFHO0NBRXRCLElBQUksS0FBSztFQUNQLE9BQU87RUFDUCxFQUFFLElBQUksSUFBSSxJQUFJLElBQUk7RUFDbEIsRUFBRSxJQUFJLENBQUM7RUFNUCxLQUFLLElBQUksS0FBSztFQUNkLElBQUksSUFBSSxHQUFHLEtBQUs7RUFFaEIsSUFBSSxJQUFJLEtBQUs7R0FDWCxJQUFJLEdBQUcsRUFBRSxFQUFFLEtBQUssQ0FBQyxJQUFJLE1BQU0sR0FBRyxDQUFDLENBQUM7R0FDaEMsS0FBSyxPQUFPLFVBQVUsSUFBSSxNQUFNLEVBQUUsRUFBRSxLQUFLLENBQUMsSUFBSSxNQUFNLEdBQUcsS0FBSyxRQUFRLENBQUM7R0FDckUsTUFBTSxJQUFJLE1BQU0sQ0FBQztHQUNqQixJQUFJLFdBQVcsSUFBSTtFQUNyQixPQUNFLEtBQUs7RUFHUCxPQUFPLE1BQU0sT0FBTztFQUNwQixFQUFFLEVBQUUsS0FBSyxDQUFDLEdBQUc7RUFFYixJQUFJLFVBQVU7R0FHWixJQUFJLEVBQUUsSUFBSSxFQUFFLFlBQVksTUFBTTtJQUc1QixFQUFFLElBQUk7SUFDTixFQUFFLElBQUk7R0FHUixPQUFPLElBQUksRUFBRSxJQUFJLEVBQUUsWUFBWSxNQUFNO0lBR25DLEVBQUUsSUFBSTtJQUNOLEVBQUUsSUFBSSxDQUFDLENBQUM7R0FFVjtFQUNGO0NBQ0YsT0FBTztFQUdMLEVBQUUsSUFBSTtFQUNOLEVBQUUsSUFBSSxDQUFDLENBQUM7Q0FDVjtDQUVBLE9BQU87QUFDVDtBQU1BLFNBQVMsV0FBVyxHQUFHLEtBQUs7Q0FDMUIsSUFBSSxNQUFNLE1BQU0sU0FBUyxHQUFHLFNBQVMsS0FBSyxHQUFHLElBQUk7Q0FFakQsSUFBSSxJQUFJLFFBQVEsR0FBRyxJQUFJLElBQUk7RUFDekIsTUFBTSxJQUFJLFFBQVEsZ0JBQWdCLElBQUk7RUFDdEMsSUFBSSxVQUFVLEtBQUssR0FBRyxHQUFHLE9BQU8sYUFBYSxHQUFHLEdBQUc7Q0FDckQsT0FBTyxJQUFJLFFBQVEsY0FBYyxRQUFRLE9BQU87RUFDOUMsSUFBSSxDQUFDLENBQUMsS0FBSyxFQUFFLElBQUk7RUFDakIsRUFBRSxJQUFJO0VBQ04sRUFBRSxJQUFJO0VBQ04sT0FBTztDQUNUO0NBRUEsSUFBSSxNQUFNLEtBQUssR0FBRyxHQUFJO0VBQ3BCLE9BQU87RUFDUCxNQUFNLElBQUksWUFBWTtDQUN4QixPQUFPLElBQUksU0FBUyxLQUFLLEdBQUcsR0FDMUIsT0FBTztNQUNGLElBQUksUUFBUSxLQUFLLEdBQUcsR0FDekIsT0FBTztNQUVQLE1BQU0sTUFBTSxrQkFBa0IsR0FBRztDQUluQyxJQUFJLElBQUksT0FBTyxJQUFJO0NBRW5CLElBQUksSUFBSSxHQUFHO0VBQ1QsSUFBSSxDQUFDLElBQUksTUFBTSxJQUFJLENBQUM7RUFDcEIsTUFBTSxJQUFJLFVBQVUsR0FBRyxDQUFDO0NBQzFCLE9BQ0UsTUFBTSxJQUFJLE1BQU0sQ0FBQztDQUtuQixJQUFJLElBQUksUUFBUSxHQUFHO0NBQ25CLFVBQVUsS0FBSztDQUNmLE9BQU8sRUFBRTtDQUVULElBQUksU0FBUztFQUNYLE1BQU0sSUFBSSxRQUFRLEtBQUssRUFBRTtFQUN6QixNQUFNLElBQUk7RUFDVixJQUFJLE1BQU07RUFHVixVQUFVLE9BQU8sTUFBTSxJQUFJLEtBQUssSUFBSSxHQUFHLEdBQUcsSUFBSSxDQUFDO0NBQ2pEO0NBRUEsS0FBSyxZQUFZLEtBQUssTUFBTSxJQUFJO0NBQ2hDLEtBQUssR0FBRyxTQUFTO0NBR2pCLEtBQUssSUFBSSxJQUFJLEdBQUcsT0FBTyxHQUFHLEVBQUUsR0FBRyxHQUFHLElBQUk7Q0FDdEMsSUFBSSxJQUFJLEdBQUcsT0FBTyxJQUFJLEtBQUssRUFBRSxJQUFJLENBQUM7Q0FDbEMsRUFBRSxJQUFJLGtCQUFrQixJQUFJLEVBQUU7Q0FDOUIsRUFBRSxJQUFJO0NBQ04sV0FBVztDQVFYLElBQUksU0FBUyxJQUFJLE9BQU8sR0FBRyxTQUFTLE1BQU0sQ0FBQztDQUczQyxJQUFJLEdBQUcsSUFBSSxFQUFFLE1BQU0sS0FBSyxJQUFJLENBQUMsSUFBSSxLQUFLLFFBQVEsR0FBRyxDQUFDLElBQUksUUFBUSxJQUFJLEdBQUcsQ0FBQyxDQUFDO0NBQ3ZFLFdBQVc7Q0FFWCxPQUFPO0FBQ1Q7QUFRQSxTQUFTLEtBQUssTUFBTSxHQUFHO0NBQ3JCLElBQUksR0FDRixNQUFNLEVBQUUsRUFBRTtDQUVaLElBQUksTUFBTSxHQUNSLE9BQU8sRUFBRSxPQUFPLElBQUksSUFBSSxhQUFhLE1BQU0sR0FBRyxHQUFHLENBQUM7Q0FRcEQsSUFBSSxNQUFNLEtBQUssS0FBSyxHQUFHO0NBQ3ZCLElBQUksSUFBSSxLQUFLLEtBQUssSUFBSTtDQUV0QixJQUFJLEVBQUUsTUFBTSxJQUFJLFFBQVEsR0FBRyxDQUFDLENBQUM7Q0FDN0IsSUFBSSxhQUFhLE1BQU0sR0FBRyxHQUFHLENBQUM7Q0FHOUIsSUFBSSxRQUNGLEtBQUssSUFBSSxLQUFLLENBQUMsR0FDZixNQUFNLElBQUksS0FBSyxFQUFFLEdBQ2pCLE1BQU0sSUFBSSxLQUFLLEVBQUU7Q0FDbkIsT0FBTyxNQUFNO0VBQ1gsU0FBUyxFQUFFLE1BQU0sQ0FBQztFQUNsQixJQUFJLEVBQUUsTUFBTSxHQUFHLEtBQUssT0FBTyxNQUFNLElBQUksTUFBTSxNQUFNLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7Q0FDakU7Q0FFQSxPQUFPO0FBQ1Q7QUFJQSxTQUFTLGFBQWEsTUFBTSxHQUFHLEdBQUcsR0FBRyxjQUFjO0NBQ2pELElBQUksR0FBRyxHQUFHLEdBQUcsSUFDWCxJQUFJLEdBQ0osS0FBSyxLQUFLLFdBQ1YsSUFBSSxLQUFLLEtBQUssS0FBSyxRQUFRO0NBRTdCLFdBQVc7Q0FDWCxLQUFLLEVBQUUsTUFBTSxDQUFDO0NBQ2QsSUFBSSxJQUFJLEtBQUssQ0FBQztDQUVkLFNBQVM7RUFDUCxJQUFJLE9BQU8sRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFJLEtBQUssTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDO0VBQ2xELElBQUksZUFBZSxFQUFFLEtBQUssQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDO0VBQ3hDLElBQUksT0FBTyxFQUFFLE1BQU0sRUFBRSxHQUFHLElBQUksS0FBSyxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUM7RUFDbEQsSUFBSSxFQUFFLEtBQUssQ0FBQztFQUVaLElBQUksRUFBRSxFQUFFLE9BQU8sS0FBSyxHQUFHO0dBQ3JCLEtBQUssSUFBSSxHQUFHLEVBQUUsRUFBRSxPQUFPLEVBQUUsRUFBRSxNQUFNO0dBQ2pDLElBQUksS0FBSyxJQUFJO0VBQ2Y7RUFFQSxJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJO0VBQ0o7Q0FDRjtDQUVBLFdBQVc7Q0FDWCxFQUFFLEVBQUUsU0FBUyxJQUFJO0NBRWpCLE9BQU87QUFDVDtBQUlBLFNBQVMsUUFBUSxHQUFHLEdBQUc7Q0FDckIsSUFBSSxJQUFJO0NBQ1IsT0FBTyxFQUFFLEdBQUcsS0FBSztDQUNqQixPQUFPO0FBQ1Q7QUFJQSxTQUFTLGlCQUFpQixNQUFNLEdBQUc7Q0FDakMsSUFBSSxHQUNGLFFBQVEsRUFBRSxJQUFJLEdBQ2QsS0FBSyxNQUFNLE1BQU0sS0FBSyxXQUFXLENBQUMsR0FDbEMsU0FBUyxHQUFHLE1BQU0sRUFBRztDQUV2QixJQUFJLEVBQUUsSUFBSTtDQUVWLElBQUksRUFBRSxJQUFJLE1BQU0sR0FBRztFQUNqQixXQUFXLFFBQVEsSUFBSTtFQUN2QixPQUFPO0NBQ1Q7Q0FFQSxJQUFJLEVBQUUsU0FBUyxFQUFFO0NBRWpCLElBQUksRUFBRSxPQUFPLEdBQ1gsV0FBVyxRQUFRLElBQUk7TUFDbEI7RUFDTCxJQUFJLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxDQUFDO0VBR3ZCLElBQUksRUFBRSxJQUFJLE1BQU0sR0FBRztHQUNqQixXQUFXLE1BQU0sQ0FBQyxJQUFLLFFBQVEsSUFBSSxJQUFNLFFBQVEsSUFBSTtHQUNyRCxPQUFPO0VBQ1Q7RUFFQSxXQUFXLE1BQU0sQ0FBQyxJQUFLLFFBQVEsSUFBSSxJQUFNLFFBQVEsSUFBSTtDQUN2RDtDQUVBLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFDLElBQUk7QUFDekI7QUFRQSxTQUFTLGVBQWUsR0FBRyxTQUFTLElBQUksSUFBSTtDQUMxQyxJQUFJLE1BQU0sR0FBRyxHQUFHLEdBQUcsS0FBSyxTQUFTLEtBQUssSUFBSSxHQUN4QyxPQUFPLEVBQUUsYUFDVCxRQUFRLE9BQU8sS0FBSztDQUV0QixJQUFJLE9BQU87RUFDVCxXQUFXLElBQUksR0FBRyxVQUFVO0VBQzVCLElBQUksT0FBTyxLQUFLLEdBQUcsS0FBSyxLQUFLO09BQ3hCLFdBQVcsSUFBSSxHQUFHLENBQUM7Q0FDMUIsT0FBTztFQUNMLEtBQUssS0FBSztFQUNWLEtBQUssS0FBSztDQUNaO0NBRUEsSUFBSSxDQUFDLEVBQUUsU0FBUyxHQUNkLE1BQU0sa0JBQWtCLENBQUM7TUFDcEI7RUFDTCxNQUFNLGVBQWUsQ0FBQztFQUN0QixJQUFJLElBQUksUUFBUSxHQUFHO0VBT25CLElBQUksT0FBTztHQUNULE9BQU87R0FDUCxJQUFJLFdBQVcsSUFDYixLQUFLLEtBQUssSUFBSTtRQUNULElBQUksV0FBVyxHQUNwQixLQUFLLEtBQUssSUFBSTtFQUVsQixPQUNFLE9BQU87RUFPVCxJQUFJLEtBQUssR0FBRztHQUNWLE1BQU0sSUFBSSxRQUFRLEtBQUssRUFBRTtHQUN6QixJQUFJLElBQUksS0FBSyxDQUFDO0dBQ2QsRUFBRSxJQUFJLElBQUksU0FBUztHQUNuQixFQUFFLElBQUksWUFBWSxlQUFlLENBQUMsR0FBRyxJQUFJLElBQUk7R0FDN0MsRUFBRSxJQUFJLEVBQUUsRUFBRTtFQUNaO0VBRUEsS0FBSyxZQUFZLEtBQUssSUFBSSxJQUFJO0VBQzlCLElBQUksTUFBTSxHQUFHO0VBR2IsT0FBTyxHQUFHLEVBQUUsUUFBUSxJQUFJLEdBQUcsSUFBSTtFQUUvQixJQUFJLENBQUMsR0FBRyxJQUNOLE1BQU0sUUFBUSxTQUFTO09BQ2xCO0dBQ0wsSUFBSSxJQUFJLEdBQ047UUFDSztJQUNMLElBQUksSUFBSSxLQUFLLENBQUM7SUFDZCxFQUFFLElBQUk7SUFDTixFQUFFLElBQUk7SUFDTixJQUFJLE9BQU8sR0FBRyxHQUFHLElBQUksSUFBSSxHQUFHLElBQUk7SUFDaEMsS0FBSyxFQUFFO0lBQ1AsSUFBSSxFQUFFO0lBQ04sVUFBVTtHQUNaO0dBR0EsSUFBSSxHQUFHO0dBQ1AsSUFBSSxPQUFPO0dBQ1gsVUFBVSxXQUFXLEdBQUcsS0FBSyxPQUFPLEtBQUs7R0FFekMsVUFBVSxLQUFLLEtBQ1YsTUFBTSxLQUFLLEtBQUssYUFBYSxPQUFPLEtBQUssUUFBUSxFQUFFLElBQUksSUFBSSxJQUFJLE1BQ2hFLElBQUksS0FBSyxNQUFNLE1BQU0sT0FBTyxLQUFLLFdBQVcsT0FBTyxLQUFLLEdBQUcsS0FBSyxLQUFLLEtBQ3JFLFFBQVEsRUFBRSxJQUFJLElBQUksSUFBSTtHQUUxQixHQUFHLFNBQVM7R0FFWixJQUFJLFNBR0YsT0FBTyxFQUFFLEdBQUcsRUFBRSxNQUFNLE9BQU8sSUFBSTtJQUM3QixHQUFHLE1BQU07SUFDVCxJQUFJLENBQUMsSUFBSTtLQUNQLEVBQUU7S0FDRixHQUFHLFFBQVEsQ0FBQztJQUNkO0dBQ0Y7R0FJRixLQUFLLE1BQU0sR0FBRyxRQUFRLENBQUMsR0FBRyxNQUFNLElBQUksRUFBRTtHQUd0QyxLQUFLLElBQUksR0FBRyxNQUFNLElBQUksSUFBSSxLQUFLLEtBQUssT0FBTyxTQUFTLE9BQU8sR0FBRyxFQUFFO0dBR2hFLElBQUksT0FBTztJQUNULElBQUksTUFBTSxHQUFHO0tBQ1gsSUFBSSxXQUFXLE1BQU0sV0FBVyxHQUFHO01BQ2pDLElBQUksV0FBVyxLQUFLLElBQUk7TUFDeEIsS0FBSyxFQUFFLEtBQUssTUFBTSxHQUFHLE9BQU8sT0FBTztNQUNuQyxLQUFLLFlBQVksS0FBSyxNQUFNLE9BQU87TUFDbkMsS0FBSyxNQUFNLEdBQUcsUUFBUSxDQUFDLEdBQUcsTUFBTSxJQUFJLEVBQUU7TUFHdEMsS0FBSyxJQUFJLEdBQUcsTUFBTSxNQUFNLElBQUksS0FBSyxLQUFLLE9BQU8sU0FBUyxPQUFPLEdBQUcsRUFBRTtLQUNwRSxPQUNFLE1BQU0sSUFBSSxPQUFPLENBQUMsSUFBSSxNQUFNLElBQUksTUFBTSxDQUFDO0lBRTNDO0lBRUEsTUFBTyxPQUFPLElBQUksSUFBSSxNQUFNLFFBQVE7R0FDdEMsT0FBTyxJQUFJLElBQUksR0FBRztJQUNoQixPQUFPLEVBQUUsSUFBSSxNQUFNLE1BQU07SUFDekIsTUFBTSxPQUFPO0dBQ2YsT0FDRSxJQUFJLEVBQUUsSUFBSSxLQUFLLEtBQUssS0FBSyxLQUFLLE1BQU8sT0FBTztRQUN2QyxJQUFJLElBQUksS0FBSyxNQUFNLElBQUksTUFBTSxHQUFHLENBQUMsSUFBSSxNQUFNLElBQUksTUFBTSxDQUFDO0VBRS9EO0VBRUEsT0FBTyxXQUFXLEtBQUssT0FBTyxXQUFXLElBQUksT0FBTyxXQUFXLElBQUksT0FBTyxNQUFNO0NBQ2xGO0NBRUEsT0FBTyxFQUFFLElBQUksSUFBSSxNQUFNLE1BQU07QUFDL0I7QUFJQSxTQUFTLFNBQVMsS0FBSyxLQUFLO0NBQzFCLElBQUksSUFBSSxTQUFTLEtBQUs7RUFDcEIsSUFBSSxTQUFTO0VBQ2IsT0FBTztDQUNUO0FBQ0Y7QUF5REEsU0FBUyxJQUFJLEdBQUc7Q0FDZCxPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3pCO0FBU0EsU0FBUyxLQUFLLEdBQUc7Q0FDZixPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzFCO0FBVUEsU0FBUyxNQUFNLEdBQUc7Q0FDaEIsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUMzQjtBQVdBLFNBQVMsSUFBSSxHQUFHLEdBQUc7Q0FDakIsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO0FBQzNCO0FBVUEsU0FBUyxLQUFLLEdBQUc7Q0FDZixPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzFCO0FBVUEsU0FBUyxNQUFNLEdBQUc7Q0FDaEIsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTTtBQUMzQjtBQVVBLFNBQVMsS0FBSyxHQUFHO0NBQ2YsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUMxQjtBQVVBLFNBQVMsTUFBTSxHQUFHO0NBQ2hCLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU07QUFDM0I7QUE0QkEsU0FBUyxNQUFNLEdBQUcsR0FBRztDQUNuQixJQUFJLElBQUksS0FBSyxDQUFDO0NBQ2QsSUFBSSxJQUFJLEtBQUssQ0FBQztDQUNkLElBQUksR0FDRixLQUFLLEtBQUssV0FDVixLQUFLLEtBQUssVUFDVixNQUFNLEtBQUs7Q0FHYixJQUFJLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBRSxHQUNiLElBQUksSUFBSSxLQUFLLEdBQUc7TUFHWCxJQUFJLENBQUMsRUFBRSxLQUFLLENBQUMsRUFBRSxHQUFHO0VBQ3ZCLElBQUksTUFBTSxNQUFNLEtBQUssQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLElBQUksSUFBSSxNQUFPLEdBQUk7RUFDbkQsRUFBRSxJQUFJLEVBQUU7Q0FHVixPQUFPLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxPQUFPLEdBQUc7RUFDN0IsSUFBSSxFQUFFLElBQUksSUFBSSxNQUFNLE1BQU0sSUFBSSxFQUFFLElBQUksSUFBSSxLQUFLLENBQUM7RUFDOUMsRUFBRSxJQUFJLEVBQUU7Q0FHVixPQUFPLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxPQUFPLEdBQUc7RUFDN0IsSUFBSSxNQUFNLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUc7RUFDakMsRUFBRSxJQUFJLEVBQUU7Q0FHVixPQUFPLElBQUksRUFBRSxJQUFJLEdBQUc7RUFDbEIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssV0FBVztFQUNoQixJQUFJLEtBQUssS0FBSyxPQUFPLEdBQUcsR0FBRyxLQUFLLENBQUMsQ0FBQztFQUNsQyxJQUFJLE1BQU0sTUFBTSxLQUFLLENBQUM7RUFDdEIsS0FBSyxZQUFZO0VBQ2pCLEtBQUssV0FBVztFQUNoQixJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUM7Q0FDckMsT0FDRSxJQUFJLEtBQUssS0FBSyxPQUFPLEdBQUcsR0FBRyxLQUFLLENBQUMsQ0FBQztDQUdwQyxPQUFPO0FBQ1Q7QUFVQSxTQUFTLEtBQUssR0FBRztDQUNmLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDMUI7QUFTQSxTQUFTLEtBQUssR0FBRztDQUNmLE9BQU8sU0FBUyxJQUFJLElBQUksS0FBSyxDQUFDLEdBQUcsRUFBRSxJQUFJLEdBQUcsQ0FBQztBQUM3QztBQVdBLFNBQVMsTUFBTSxHQUFHLEtBQUssS0FBSztDQUMxQixPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLEtBQUssR0FBRztBQUNuQztBQXFCQSxTQUFTLE9BQU8sS0FBSztDQUNuQixJQUFJLENBQUMsT0FBTyxPQUFPLFFBQVEsVUFBVSxNQUFNLE1BQU0sZUFBZSxpQkFBaUI7Q0FDakYsSUFBSSxHQUFHLEdBQUcsR0FDUixjQUFjLElBQUksYUFBYSxNQUMvQixLQUFLO0VBQ0g7RUFBYTtFQUFHO0VBQ2hCO0VBQVk7RUFBRztFQUNmO0VBQVksQ0FBQztFQUFXO0VBQ3hCO0VBQVk7RUFBRztFQUNmO0VBQVE7RUFBRztFQUNYO0VBQVEsQ0FBQztFQUFXO0VBQ3BCO0VBQVU7RUFBRztDQUNmO0NBRUYsS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLFFBQVEsS0FBSyxHQUFHO0VBQ2pDLElBQUksSUFBSSxHQUFHLElBQUksYUFBYSxLQUFLLEtBQUssU0FBUztFQUMvQyxLQUFLLElBQUksSUFBSSxRQUFRLEtBQUssR0FBRztHQUMzQixJQUFJLFVBQVUsQ0FBQyxNQUFNLEtBQUssS0FBSyxHQUFHLElBQUksTUFBTSxLQUFLLEdBQUcsSUFBSSxJQUFJLEtBQUssS0FBSztRQUNqRSxNQUFNLE1BQU0sa0JBQWtCLElBQUksT0FBTyxDQUFDO0VBQ2pEO0NBQ0Y7Q0FFQSxJQUFJLElBQUksVUFBVSxhQUFhLEtBQUssS0FBSyxTQUFTO0NBQ2xELEtBQUssSUFBSSxJQUFJLFFBQVEsS0FBSyxHQUFHO0VBQzNCLElBQUksTUFBTSxRQUFRLE1BQU0sU0FBUyxNQUFNLEtBQUssTUFBTSxHQUFHO0dBQ25ELElBQUksR0FBRztJQUNMLElBQUksT0FBTyxVQUFVLGVBQWUsV0FDakMsT0FBTyxtQkFBbUIsT0FBTyxjQUNsQyxLQUFLLEtBQUs7U0FFVixNQUFNLE1BQU0saUJBQWlCO0dBRWpDLE9BQ0UsS0FBSyxLQUFLO0VBRWQsT0FDRSxNQUFNLE1BQU0sa0JBQWtCLElBQUksT0FBTyxDQUFDO0NBRTlDO0NBRUEsT0FBTztBQUNUO0FBVUEsU0FBUyxJQUFJLEdBQUc7Q0FDZCxPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3pCO0FBVUEsU0FBUyxLQUFLLEdBQUc7Q0FDZixPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLO0FBQzFCO0FBUUEsU0FBUyxNQUFNLEtBQUs7Q0FDbEIsSUFBSSxHQUFHLEdBQUc7Q0FTVixTQUFTLFFBQVEsR0FBRztFQUNsQixJQUFJLEdBQUcsR0FBRyxHQUNSLElBQUk7RUFHTixJQUFJLEVBQUUsYUFBYSxVQUFVLE9BQU8sSUFBSSxRQUFRLENBQUM7RUFJakQsRUFBRSxjQUFjO0VBRWhCLElBQUksa0JBQWtCLENBQUMsR0FBRztHQUN4QixFQUFFLElBQUksRUFBRTtHQUVSLElBQUksVUFBVTtJQUNaLElBQUksQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLFFBQVEsTUFBTTtLQUc5QixFQUFFLElBQUk7S0FDTixFQUFFLElBQUk7SUFDUixPQUFPLElBQUksRUFBRSxJQUFJLFFBQVEsTUFBTTtLQUc3QixFQUFFLElBQUk7S0FDTixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ1YsT0FBTztLQUNMLEVBQUUsSUFBSSxFQUFFO0tBQ1IsRUFBRSxJQUFJLEVBQUUsRUFBRSxNQUFNO0lBQ2xCO0dBQ0YsT0FBTztJQUNMLEVBQUUsSUFBSSxFQUFFO0lBQ1IsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEVBQUUsTUFBTSxJQUFJLEVBQUU7R0FDOUI7R0FFQTtFQUNGO0VBRUEsSUFBSSxPQUFPO0VBRVgsSUFBSSxNQUFNLFVBQVU7R0FDbEIsSUFBSSxNQUFNLEdBQUc7SUFDWCxFQUFFLElBQUksSUFBSSxJQUFJLElBQUksS0FBSztJQUN2QixFQUFFLElBQUk7SUFDTixFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ1I7R0FDRjtHQUVBLElBQUksSUFBSSxHQUFHO0lBQ1QsSUFBSSxDQUFDO0lBQ0wsRUFBRSxJQUFJO0dBQ1IsT0FDRSxFQUFFLElBQUk7R0FJUixJQUFJLE1BQU0sQ0FBQyxDQUFDLEtBQUssSUFBSSxLQUFLO0lBQ3hCLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLLElBQUksS0FBSyxJQUFJO0lBRXJDLElBQUksVUFBVTtLQUNaLElBQUksSUFBSSxRQUFRLE1BQU07TUFDcEIsRUFBRSxJQUFJO01BQ04sRUFBRSxJQUFJO0tBQ1IsT0FBTyxJQUFJLElBQUksUUFBUSxNQUFNO01BQzNCLEVBQUUsSUFBSTtNQUNOLEVBQUUsSUFBSSxDQUFDLENBQUM7S0FDVixPQUFPO01BQ0wsRUFBRSxJQUFJO01BQ04sRUFBRSxJQUFJLENBQUMsQ0FBQztLQUNWO0lBQ0YsT0FBTztLQUNMLEVBQUUsSUFBSTtLQUNOLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDVjtJQUVBO0dBQ0Y7R0FHQSxJQUFJLElBQUksTUFBTSxHQUFHO0lBQ2YsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJO0lBQ2QsRUFBRSxJQUFJO0lBQ04sRUFBRSxJQUFJO0lBQ047R0FDRjtHQUVBLE9BQU8sYUFBYSxHQUFHLEVBQUUsU0FBUyxDQUFDO0VBQ3JDO0VBRUEsSUFBSSxNQUFNLFVBQVU7R0FDbEIsS0FBSyxJQUFJLEVBQUUsV0FBVyxDQUFDLE9BQU8sSUFBSTtJQUNoQyxJQUFJLEVBQUUsTUFBTSxDQUFDO0lBQ2IsRUFBRSxJQUFJO0dBQ1IsT0FBTztJQUNMLElBQUksTUFBTSxJQUFJLElBQUksRUFBRSxNQUFNLENBQUM7SUFDM0IsRUFBRSxJQUFJO0dBQ1I7R0FFQSxPQUFPLFVBQVUsS0FBSyxDQUFDLElBQUksYUFBYSxHQUFHLENBQUMsSUFBSSxXQUFXLEdBQUcsQ0FBQztFQUNqRTtFQUVBLElBQUksTUFBTSxVQUFVO0dBQ2xCLElBQUksSUFBSSxHQUFHO0lBQ1QsSUFBSSxDQUFDO0lBQ0wsRUFBRSxJQUFJO0dBQ1IsT0FDRSxFQUFFLElBQUk7R0FHUixPQUFPLGFBQWEsR0FBRyxFQUFFLFNBQVMsQ0FBQztFQUNyQztFQUVBLE1BQU0sTUFBTSxrQkFBa0IsQ0FBQztDQUNqQztDQUVBLFFBQVEsWUFBWTtDQUVwQixRQUFRLFdBQVc7Q0FDbkIsUUFBUSxhQUFhO0NBQ3JCLFFBQVEsYUFBYTtDQUNyQixRQUFRLGNBQWM7Q0FDdEIsUUFBUSxnQkFBZ0I7Q0FDeEIsUUFBUSxrQkFBa0I7Q0FDMUIsUUFBUSxrQkFBa0I7Q0FDMUIsUUFBUSxrQkFBa0I7Q0FDMUIsUUFBUSxtQkFBbUI7Q0FDM0IsUUFBUSxTQUFTO0NBRWpCLFFBQVEsU0FBUyxRQUFRLE1BQU07Q0FDL0IsUUFBUSxRQUFRO0NBQ2hCLFFBQVEsWUFBWTtDQUVwQixRQUFRLE1BQU07Q0FDZCxRQUFRLE9BQU87Q0FDZixRQUFRLFFBQVE7Q0FDaEIsUUFBUSxNQUFNO0NBQ2QsUUFBUSxPQUFPO0NBQ2YsUUFBUSxRQUFRO0NBQ2hCLFFBQVEsT0FBTztDQUNmLFFBQVEsUUFBUTtDQUNoQixRQUFRLFFBQVE7Q0FDaEIsUUFBUSxPQUFPO0NBQ2YsUUFBUSxPQUFPO0NBQ2YsUUFBUSxRQUFRO0NBQ2hCLFFBQVEsTUFBTTtDQUNkLFFBQVEsT0FBTztDQUNmLFFBQVEsTUFBTTtDQUNkLFFBQVEsTUFBTTtDQUNkLFFBQVEsUUFBUTtDQUNoQixRQUFRLFFBQVE7Q0FDaEIsUUFBUSxLQUFLO0NBQ2IsUUFBUSxNQUFNO0NBQ2QsUUFBUSxRQUFRO0NBQ2hCLFFBQVEsT0FBTztDQUNmLFFBQVEsTUFBTTtDQUNkLFFBQVEsTUFBTTtDQUNkLFFBQVEsTUFBTTtDQUNkLFFBQVEsTUFBTTtDQUNkLFFBQVEsTUFBTTtDQUNkLFFBQVEsU0FBUztDQUNqQixRQUFRLFFBQVE7Q0FDaEIsUUFBUSxPQUFPO0NBQ2YsUUFBUSxNQUFNO0NBQ2QsUUFBUSxPQUFPO0NBQ2YsUUFBUSxPQUFPO0NBQ2YsUUFBUSxNQUFNO0NBQ2QsUUFBUSxNQUFNO0NBQ2QsUUFBUSxNQUFNO0NBQ2QsUUFBUSxPQUFPO0NBQ2YsUUFBUSxRQUFRO0NBRWhCLElBQUksUUFBUSxLQUFLLEdBQUcsTUFBTSxDQUFDO0NBQzNCLElBQUksS0FDRTtNQUFBLElBQUksYUFBYSxNQUFNO0dBQ3pCLEtBQUs7SUFBQztJQUFhO0lBQVk7SUFBWTtJQUFZO0lBQVE7SUFBUTtJQUFVO0dBQVE7R0FDekYsS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLFNBQVMsSUFBSSxDQUFDLElBQUksZUFBZSxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLO0VBQ2xGOztDQUdGLFFBQVEsT0FBTyxHQUFHO0NBRWxCLE9BQU87QUFDVDtBQVdBLFNBQVMsSUFBSSxHQUFHLEdBQUc7Q0FDakIsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzFCO0FBVUEsU0FBUyxJQUFJLEdBQUc7Q0FDZCxPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJO0FBQ3pCO0FBU0EsU0FBUyxNQUFNLEdBQUc7Q0FDaEIsT0FBTyxTQUFTLElBQUksSUFBSSxLQUFLLENBQUMsR0FBRyxFQUFFLElBQUksR0FBRyxDQUFDO0FBQzdDO0FBWUEsU0FBUyxRQUFRO0NBQ2YsSUFBSSxHQUFHLEdBQ0wsSUFBSSxJQUFJLEtBQUssQ0FBQztDQUVoQixXQUFXO0NBRVgsS0FBSyxJQUFJLEdBQUcsSUFBSSxVQUFVLFNBQVM7RUFDakMsSUFBSSxJQUFJLEtBQUssVUFBVSxJQUFJO0VBQzNCLElBQUksQ0FBQyxFQUFFLEdBQUc7R0FDUixJQUFJLEVBQUUsR0FBRztJQUNQLFdBQVc7SUFDWCxPQUFPLElBQUksS0FBSyxJQUFJLENBQUM7R0FDdkI7R0FDQSxJQUFJO0VBQ04sT0FBTyxJQUFJLEVBQUUsR0FDWCxJQUFJLEVBQUUsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDO0NBRXpCO0NBRUEsV0FBVztDQUVYLE9BQU8sRUFBRSxLQUFLO0FBQ2hCO0FBUUEsU0FBUyxrQkFBa0IsS0FBSztDQUM5QixPQUFPLGVBQWUsV0FBVyxPQUFPLElBQUksZ0JBQWdCLE9BQU87QUFDckU7QUFVQSxTQUFTLEdBQUcsR0FBRztDQUNiLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLEdBQUc7QUFDeEI7QUFhQSxTQUFTLElBQUksR0FBRyxHQUFHO0NBQ2pCLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMxQjtBQVVBLFNBQVMsS0FBSyxHQUFHO0NBQ2YsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzFCO0FBVUEsU0FBUyxNQUFNLEdBQUc7Q0FDaEIsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFO0FBQzNCO0FBU0EsU0FBUyxNQUFNO0NBQ2IsT0FBTyxTQUFTLE1BQU0sV0FBVyxFQUFFO0FBQ3JDO0FBU0EsU0FBUyxNQUFNO0NBQ2IsT0FBTyxTQUFTLE1BQU0sV0FBVyxDQUFDO0FBQ3BDO0FBV0EsU0FBUyxJQUFJLEdBQUcsR0FBRztDQUNqQixPQUFPLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7QUFDMUI7QUFXQSxTQUFTLElBQUksR0FBRyxHQUFHO0NBQ2pCLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUMxQjtBQVdBLFNBQVMsSUFBSSxHQUFHLEdBQUc7Q0FDakIsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzFCO0FBV0EsU0FBUyxPQUFPLElBQUk7Q0FDbEIsSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUNYLElBQUksR0FDSixJQUFJLElBQUksS0FBSyxDQUFDLEdBQ2QsS0FBSyxDQUFDO0NBRVIsSUFBSSxPQUFPLEtBQUssR0FBRyxLQUFLLEtBQUs7TUFDeEIsV0FBVyxJQUFJLEdBQUcsVUFBVTtDQUVqQyxJQUFJLEtBQUssS0FBSyxLQUFLLFFBQVE7Q0FFM0IsSUFBSSxDQUFDLEtBQUssUUFDUixPQUFPLElBQUksSUFBSSxHQUFHLE9BQU8sS0FBSyxPQUFPLElBQUksTUFBTTtNQUcxQyxJQUFJLE9BQU8saUJBQWlCO0VBQ2pDLElBQUksT0FBTyxnQkFBZ0IsSUFBSSxZQUFZLENBQUMsQ0FBQztFQUU3QyxPQUFPLElBQUksSUFBSTtHQUNiLElBQUksRUFBRTtHQUlOLElBQUksS0FBSyxPQUNQLEVBQUUsS0FBSyxPQUFPLGdDQUFnQixJQUFJLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUtsRCxHQUFHLE9BQU8sSUFBSTtFQUVsQjtDQUdGLE9BQU8sSUFBSSxPQUFPLGFBQWE7RUFHN0IsSUFBSSxPQUFPLFlBQVksS0FBSyxDQUFDO0VBRTdCLE9BQU8sSUFBSSxJQUFJO0dBR2IsSUFBSSxFQUFFLE1BQU0sRUFBRSxJQUFJLE1BQU0sTUFBTSxFQUFFLElBQUksTUFBTSxRQUFRLEVBQUUsSUFBSSxLQUFLLFFBQVM7R0FHdEUsSUFBSSxLQUFLLE9BQ1AsT0FBTyxZQUFZLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDO1FBQzFCO0lBSUwsR0FBRyxLQUFLLElBQUksR0FBRztJQUNmLEtBQUs7R0FDUDtFQUNGO0VBRUEsSUFBSSxJQUFJO0NBQ1YsT0FDRSxNQUFNLE1BQU0saUJBQWlCO0NBRy9CLElBQUksR0FBRyxFQUFFO0NBQ1QsTUFBTTtDQUdOLElBQUksS0FBSyxJQUFJO0VBQ1gsSUFBSSxRQUFRLElBQUksV0FBVyxFQUFFO0VBQzdCLEdBQUcsTUFBTSxJQUFJLElBQUksS0FBSztDQUN4QjtDQUdBLE9BQU8sR0FBRyxPQUFPLEdBQUcsS0FBSyxHQUFHLElBQUk7Q0FHaEMsSUFBSSxJQUFJLEdBQUc7RUFDVCxJQUFJO0VBQ0osS0FBSyxDQUFDLENBQUM7Q0FDVCxPQUFPO0VBQ0wsSUFBSTtFQUdKLE9BQU8sR0FBRyxPQUFPLEdBQUcsS0FBSyxVQUFVLEdBQUcsTUFBTTtFQUc1QyxLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJO0VBR3pDLElBQUksSUFBSSxVQUFVLEtBQUssV0FBVztDQUNwQztDQUVBLEVBQUUsSUFBSTtDQUNOLEVBQUUsSUFBSTtDQUVOLE9BQU87QUFDVDtBQVdBLFNBQVMsTUFBTSxHQUFHO0NBQ2hCLE9BQU8sU0FBUyxJQUFJLElBQUksS0FBSyxDQUFDLEdBQUcsRUFBRSxJQUFJLEdBQUcsS0FBSyxRQUFRO0FBQ3pEO0FBY0EsU0FBUyxLQUFLLEdBQUc7Q0FDZixJQUFJLElBQUksS0FBSyxDQUFDO0NBQ2QsT0FBTyxFQUFFLElBQUssRUFBRSxFQUFFLEtBQUssRUFBRSxJQUFJLElBQUksRUFBRSxJQUFLLEVBQUUsS0FBSztBQUNqRDtBQVVBLFNBQVMsSUFBSSxHQUFHO0NBQ2QsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSTtBQUN6QjtBQVVBLFNBQVMsS0FBSyxHQUFHO0NBQ2YsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUMxQjtBQVVBLFNBQVMsS0FBSyxHQUFHO0NBQ2YsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSztBQUMxQjtBQVdBLFNBQVMsSUFBSSxHQUFHLEdBQUc7Q0FDakIsT0FBTyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO0FBQzFCO0FBWUEsU0FBUyxNQUFNO0NBQ2IsSUFBSSxJQUFJLEdBQ04sT0FBTyxXQUNQLElBQUksSUFBSSxLQUFLLEtBQUssRUFBRTtDQUV0QixXQUFXO0NBQ1gsT0FBTyxFQUFFLEtBQUssRUFBRSxJQUFJLEtBQUssU0FBUyxJQUFJLEVBQUUsS0FBSyxLQUFLLEVBQUU7Q0FDcEQsV0FBVztDQUVYLE9BQU8sU0FBUyxHQUFHLEtBQUssV0FBVyxLQUFLLFFBQVE7QUFDbEQ7QUFVQSxTQUFTLElBQUksR0FBRztDQUNkLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLElBQUk7QUFDekI7QUFVQSxTQUFTLEtBQUssR0FBRztDQUNmLE9BQU8sSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUs7QUFDMUI7QUFTQSxTQUFTLE1BQU0sR0FBRztDQUNoQixPQUFPLFNBQVMsSUFBSSxJQUFJLEtBQUssQ0FBQyxHQUFHLEVBQUUsSUFBSSxHQUFHLENBQUM7QUFDN0M7QUFHQSxFQUFFLE9BQU8sSUFBSSw0QkFBNEIsS0FBSyxFQUFFO0FBQ2hELEVBQUUsT0FBTyxlQUFlO0FBR3hCLElBQVcsVUFBVSxFQUFFLGNBQWMsTUFBTSxRQUFRO0FBR25ELE9BQU8sSUFBSSxRQUFRLElBQUk7QUFDdkIsS0FBSyxJQUFJLFFBQVEsRUFBRSIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=