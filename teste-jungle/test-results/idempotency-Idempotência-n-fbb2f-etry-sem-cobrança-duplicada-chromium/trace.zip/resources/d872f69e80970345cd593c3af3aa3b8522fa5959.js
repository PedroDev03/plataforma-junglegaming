import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=e9f94b2e";
import { t as require_react_dom } from "/node_modules/.vite/deps/react-dom-CRx58tZq.js?v=e9f94b2e";
import { r as useIsoLayoutEffect, t as useStableCallback } from "/node_modules/.vite/deps/formatErrorMessage-BEgQI17N.js?v=e9f94b2e";
import { _ as isTableElement, a as getNodeName, c as getParentNode, d as isElement, f as isHTMLElement, h as isOverflowElement, i as getFrameElement, l as getWindow, n as getContainingBlock, o as getNodeScroll, p as isLastTraversableNode, r as getDocumentElement, s as getOverflowAncestors, t as getComputedStyle$1, u as isContainingBlock, v as isTopLayer, y as isWebKit } from "/node_modules/.vite/deps/floating-ui.utils.dom-B45hE2lE.js?v=e9f94b2e";
import { D as useFloatingTree, N as DISABLED_TRANSITIONS_STYLE, q as useValueAsRef, rt as popupStateMapping } from "/node_modules/.vite/deps/FloatingRootStore-BMBEPfxq.js?v=e9f94b2e";
import { n as ownerDocument } from "/node_modules/.vite/deps/inertValue-DbKApsSW.js?v=e9f94b2e";
import { c as EMPTY_OBJECT, n as useRenderElement } from "/node_modules/.vite/deps/useRenderElement-CvMw8z9e.js?v=e9f94b2e";
import { _ as min, a as getAlignment, c as getAxisLength, d as getOppositeAxisPlacements, f as getOppositePlacement, g as max, h as getSideAxis, i as floor, l as getExpandedPlacements, m as getSide, n as createCoords, o as getAlignmentAxis, p as getPaddingObject, r as evaluate, s as getAlignmentSides, t as clamp, u as getOppositeAxis, v as rectToClientRect, y as round } from "/node_modules/.vite/deps/floating-ui.utils-BnTHImEf.js?v=e9f94b2e";
import { t as useDirection } from "/node_modules/.vite/deps/DirectionContext-BppzJsM-.js?v=e9f94b2e";
// node_modules/@floating-ui/core/dist/floating-ui.core.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function computeCoordsFromPlacement(_ref, placement, rtl) {
	let { reference, floating } = _ref;
	const sideAxis = getSideAxis(placement);
	const alignmentAxis = getAlignmentAxis(placement);
	const alignLength = getAxisLength(alignmentAxis);
	const side = getSide(placement);
	const isVertical = sideAxis === "y";
	const commonX = reference.x + reference.width / 2 - floating.width / 2;
	const commonY = reference.y + reference.height / 2 - floating.height / 2;
	const commonAlign = reference[alignLength] / 2 - floating[alignLength] / 2;
	let coords;
	switch (side) {
		case "top":
			coords = {
				x: commonX,
				y: reference.y - floating.height
			};
			break;
		case "bottom":
			coords = {
				x: commonX,
				y: reference.y + reference.height
			};
			break;
		case "right":
			coords = {
				x: reference.x + reference.width,
				y: commonY
			};
			break;
		case "left":
			coords = {
				x: reference.x - floating.width,
				y: commonY
			};
			break;
		default: coords = {
			x: reference.x,
			y: reference.y
		};
	}
	const alignment = getAlignment(placement);
	if (alignment) coords[alignmentAxis] += commonAlign * (alignment === "end" ? 1 : -1) * (rtl && isVertical ? -1 : 1);
	return coords;
}
/**
* Resolves with an object of overflow side offsets that determine how much the
* element is overflowing a given clipping boundary on each side.
* - positive = overflowing the boundary by that number of pixels
* - negative = how many pixels left before it will overflow
* - 0 = lies flush with the boundary
* @see https://floating-ui.com/docs/detectOverflow
*/
async function detectOverflow(state, options) {
	var _await$platform$isEle;
	if (options === void 0) options = {};
	const { x, y, platform, rects, elements, strategy } = state;
	const { boundary = "clippingAncestors", rootBoundary = "viewport", elementContext = "floating", altBoundary = false, padding = 0 } = evaluate(options, state);
	const paddingObject = getPaddingObject(padding);
	const element = elements[altBoundary ? elementContext === "floating" ? "reference" : "floating" : elementContext];
	const clippingClientRect = rectToClientRect(await platform.getClippingRect({
		element: ((_await$platform$isEle = await (platform.isElement == null ? void 0 : platform.isElement(element))) != null ? _await$platform$isEle : true) ? element : element.contextElement || await (platform.getDocumentElement == null ? void 0 : platform.getDocumentElement(elements.floating)),
		boundary,
		rootBoundary,
		strategy
	}));
	const rect = elementContext === "floating" ? {
		x,
		y,
		width: rects.floating.width,
		height: rects.floating.height
	} : rects.reference;
	const offsetParent = await (platform.getOffsetParent == null ? void 0 : platform.getOffsetParent(elements.floating));
	const offsetScale = await (platform.isElement == null ? void 0 : platform.isElement(offsetParent)) && await (platform.getScale == null ? void 0 : platform.getScale(offsetParent)) || {
		x: 1,
		y: 1
	};
	const elementClientRect = rectToClientRect(platform.convertOffsetParentRelativeRectToViewportRelativeRect ? await platform.convertOffsetParentRelativeRectToViewportRelativeRect({
		elements,
		rect,
		offsetParent,
		strategy
	}) : rect);
	return {
		top: (clippingClientRect.top - elementClientRect.top + paddingObject.top) / offsetScale.y,
		bottom: (elementClientRect.bottom - clippingClientRect.bottom + paddingObject.bottom) / offsetScale.y,
		left: (clippingClientRect.left - elementClientRect.left + paddingObject.left) / offsetScale.x,
		right: (elementClientRect.right - clippingClientRect.right + paddingObject.right) / offsetScale.x
	};
}
var MAX_RESET_COUNT = 50;
/**
* Computes the `x` and `y` coordinates that will place the floating element
* next to a given reference element.
*
* This export does not have any `platform` interface logic. You will need to
* write one for the platform you are using Floating UI with.
*/
var computePosition$1 = async (reference, floating, config) => {
	const { placement = "bottom", strategy = "absolute", middleware = [], platform } = config;
	const platformWithDetectOverflow = platform.detectOverflow ? platform : {
		...platform,
		detectOverflow
	};
	const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(floating));
	let rects = await platform.getElementRects({
		reference,
		floating,
		strategy
	});
	let { x, y } = computeCoordsFromPlacement(rects, placement, rtl);
	let statefulPlacement = placement;
	let resetCount = 0;
	const middlewareData = {};
	for (let i = 0; i < middleware.length; i++) {
		const currentMiddleware = middleware[i];
		if (!currentMiddleware) continue;
		const { name, fn } = currentMiddleware;
		const { x: nextX, y: nextY, data, reset } = await fn({
			x,
			y,
			initialPlacement: placement,
			placement: statefulPlacement,
			strategy,
			middlewareData,
			rects,
			platform: platformWithDetectOverflow,
			elements: {
				reference,
				floating
			}
		});
		x = nextX != null ? nextX : x;
		y = nextY != null ? nextY : y;
		middlewareData[name] = {
			...middlewareData[name],
			...data
		};
		if (reset && resetCount < MAX_RESET_COUNT) {
			resetCount++;
			if (typeof reset === "object") {
				if (reset.placement) statefulPlacement = reset.placement;
				if (reset.rects) rects = reset.rects === true ? await platform.getElementRects({
					reference,
					floating,
					strategy
				}) : reset.rects;
				({x, y} = computeCoordsFromPlacement(rects, statefulPlacement, rtl));
			}
			i = -1;
		}
	}
	return {
		x,
		y,
		placement: statefulPlacement,
		strategy,
		middlewareData
	};
};
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip$1 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "flip",
		options,
		async fn(state) {
			var _middlewareData$arrow, _middlewareData$flip;
			const { placement, middlewareData, rects, initialPlacement, platform, elements } = state;
			const { mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = true, fallbackPlacements: specifiedFallbackPlacements, fallbackStrategy = "bestFit", fallbackAxisSideDirection = "none", flipAlignment = true, ...detectOverflowOptions } = evaluate(options, state);
			if ((_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) return {};
			const side = getSide(placement);
			const initialSideAxis = getSideAxis(initialPlacement);
			const isBasePlacement = getSide(initialPlacement) === initialPlacement;
			const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating));
			const fallbackPlacements = specifiedFallbackPlacements || (isBasePlacement || !flipAlignment ? [getOppositePlacement(initialPlacement)] : getExpandedPlacements(initialPlacement));
			const hasFallbackAxisSideDirection = fallbackAxisSideDirection !== "none";
			if (!specifiedFallbackPlacements && hasFallbackAxisSideDirection) fallbackPlacements.push(...getOppositeAxisPlacements(initialPlacement, flipAlignment, fallbackAxisSideDirection, rtl));
			const placements = [initialPlacement, ...fallbackPlacements];
			const overflow = await platform.detectOverflow(state, detectOverflowOptions);
			const overflows = [];
			let overflowsData = ((_middlewareData$flip = middlewareData.flip) == null ? void 0 : _middlewareData$flip.overflows) || [];
			if (checkMainAxis) overflows.push(overflow[side]);
			if (checkCrossAxis) {
				const sides = getAlignmentSides(placement, rects, rtl);
				overflows.push(overflow[sides[0]], overflow[sides[1]]);
			}
			overflowsData = [...overflowsData, {
				placement,
				overflows
			}];
			if (!overflows.every((side) => side <= 0)) {
				var _middlewareData$flip2, _overflowsData$filter;
				const nextIndex = (((_middlewareData$flip2 = middlewareData.flip) == null ? void 0 : _middlewareData$flip2.index) || 0) + 1;
				const nextPlacement = placements[nextIndex];
				if (nextPlacement) {
					if (!(checkCrossAxis === "alignment" ? initialSideAxis !== getSideAxis(nextPlacement) : false) || overflowsData.every((d) => getSideAxis(d.placement) === initialSideAxis ? d.overflows[0] > 0 : true)) return {
						data: {
							index: nextIndex,
							overflows: overflowsData
						},
						reset: { placement: nextPlacement }
					};
				}
				let resetPlacement = (_overflowsData$filter = overflowsData.filter((d) => d.overflows[0] <= 0).sort((a, b) => a.overflows[1] - b.overflows[1])[0]) == null ? void 0 : _overflowsData$filter.placement;
				if (!resetPlacement) switch (fallbackStrategy) {
					case "bestFit": {
						var _overflowsData$filter2;
						const placement = (_overflowsData$filter2 = overflowsData.filter((d) => {
							if (hasFallbackAxisSideDirection) {
								const currentSideAxis = getSideAxis(d.placement);
								return currentSideAxis === initialSideAxis || currentSideAxis === "y";
							}
							return true;
						}).map((d) => [d.placement, d.overflows.filter((overflow) => overflow > 0).reduce((acc, overflow) => acc + overflow, 0)]).sort((a, b) => a[1] - b[1])[0]) == null ? void 0 : _overflowsData$filter2[0];
						if (placement) resetPlacement = placement;
						break;
					}
					case "initialPlacement": resetPlacement = initialPlacement;
				}
				if (placement !== resetPlacement) return { reset: { placement: resetPlacement } };
			}
			return {};
		}
	};
};
var originSides = /*#__PURE__*/ new Set(["left", "top"]);
async function convertValueToCoords(state, options) {
	const { placement, platform, elements } = state;
	const rtl = await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating));
	const side = getSide(placement);
	const alignment = getAlignment(placement);
	const isVertical = getSideAxis(placement) === "y";
	const mainAxisMulti = originSides.has(side) ? -1 : 1;
	const crossAxisMulti = rtl && isVertical ? -1 : 1;
	const rawValue = evaluate(options, state);
	let { mainAxis, crossAxis, alignmentAxis } = typeof rawValue === "number" ? {
		mainAxis: rawValue,
		crossAxis: 0,
		alignmentAxis: null
	} : {
		mainAxis: rawValue.mainAxis || 0,
		crossAxis: rawValue.crossAxis || 0,
		alignmentAxis: rawValue.alignmentAxis
	};
	if (alignment && typeof alignmentAxis === "number") crossAxis = alignment === "end" ? alignmentAxis * -1 : alignmentAxis;
	return isVertical ? {
		x: crossAxis * crossAxisMulti,
		y: mainAxis * mainAxisMulti
	} : {
		x: mainAxis * mainAxisMulti,
		y: crossAxis * crossAxisMulti
	};
}
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset$1 = function(options) {
	if (options === void 0) options = 0;
	return {
		name: "offset",
		options,
		async fn(state) {
			var _middlewareData$offse, _middlewareData$arrow;
			const { x, y, placement, middlewareData } = state;
			const diffCoords = await convertValueToCoords(state, options);
			if (placement === ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse.placement) && (_middlewareData$arrow = middlewareData.arrow) != null && _middlewareData$arrow.alignmentOffset) return {};
			return {
				x: x + diffCoords.x,
				y: y + diffCoords.y,
				data: {
					...diffCoords,
					placement
				}
			};
		}
	};
};
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift$1 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "shift",
		options,
		async fn(state) {
			const { x, y, placement, platform } = state;
			const { mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = false, limiter = { fn: (_ref) => {
				let { x, y } = _ref;
				return {
					x,
					y
				};
			} }, ...detectOverflowOptions } = evaluate(options, state);
			const coords = {
				x,
				y
			};
			const overflow = await platform.detectOverflow(state, detectOverflowOptions);
			const crossAxis = getSideAxis(placement);
			const mainAxis = getOppositeAxis(crossAxis);
			let mainAxisCoord = coords[mainAxis];
			let crossAxisCoord = coords[crossAxis];
			const clampCoord = (axis, coord) => clamp(coord + overflow[axis === "y" ? "top" : "left"], coord, coord - overflow[axis === "y" ? "bottom" : "right"]);
			if (checkMainAxis) mainAxisCoord = clampCoord(mainAxis, mainAxisCoord);
			if (checkCrossAxis) crossAxisCoord = clampCoord(crossAxis, crossAxisCoord);
			const limitedCoords = limiter.fn({
				...state,
				[mainAxis]: mainAxisCoord,
				[crossAxis]: crossAxisCoord
			});
			return {
				...limitedCoords,
				data: {
					x: limitedCoords.x - x,
					y: limitedCoords.y - y,
					enabled: {
						[mainAxis]: checkMainAxis,
						[crossAxis]: checkCrossAxis
					}
				}
			};
		}
	};
};
/**
* Built-in `limiter` that will stop `shift()` at a certain point.
*/
var limitShift$1 = function(options) {
	if (options === void 0) options = {};
	return {
		options,
		fn(state) {
			var _rawOffset$mainAxis, _rawOffset$crossAxis;
			const { x, y, placement, rects, middlewareData } = state;
			const { offset = 0, mainAxis: checkMainAxis = true, crossAxis: checkCrossAxis = true } = evaluate(options, state);
			const coords = {
				x,
				y
			};
			const crossAxis = getSideAxis(placement);
			const mainAxis = getOppositeAxis(crossAxis);
			let mainAxisCoord = coords[mainAxis];
			let crossAxisCoord = coords[crossAxis];
			const rawOffset = evaluate(offset, state);
			const computedOffset = typeof rawOffset === "number" ? {
				mainAxis: rawOffset,
				crossAxis: 0
			} : {
				mainAxis: (_rawOffset$mainAxis = rawOffset.mainAxis) != null ? _rawOffset$mainAxis : 0,
				crossAxis: (_rawOffset$crossAxis = rawOffset.crossAxis) != null ? _rawOffset$crossAxis : 0
			};
			if (checkMainAxis) {
				const len = mainAxis === "y" ? "height" : "width";
				const limitMin = rects.reference[mainAxis] - rects.floating[len] + computedOffset.mainAxis;
				const limitMax = rects.reference[mainAxis] + rects.reference[len] - computedOffset.mainAxis;
				if (mainAxisCoord < limitMin) mainAxisCoord = limitMin;
				else if (mainAxisCoord > limitMax) mainAxisCoord = limitMax;
			}
			if (checkCrossAxis) {
				var _middlewareData$offse, _middlewareData$offse2;
				const len = mainAxis === "y" ? "width" : "height";
				const isOriginSide = originSides.has(getSide(placement));
				const limitMin = rects.reference[crossAxis] - rects.floating[len] + (isOriginSide ? ((_middlewareData$offse = middlewareData.offset) == null ? void 0 : _middlewareData$offse[crossAxis]) || 0 : 0) + (isOriginSide ? 0 : computedOffset.crossAxis);
				const limitMax = rects.reference[crossAxis] + rects.reference[len] + (isOriginSide ? 0 : ((_middlewareData$offse2 = middlewareData.offset) == null ? void 0 : _middlewareData$offse2[crossAxis]) || 0) - (isOriginSide ? computedOffset.crossAxis : 0);
				if (crossAxisCoord < limitMin) crossAxisCoord = limitMin;
				else if (crossAxisCoord > limitMax) crossAxisCoord = limitMax;
			}
			return {
				[mainAxis]: mainAxisCoord,
				[crossAxis]: crossAxisCoord
			};
		}
	};
};
/**
* Provides data that allows you to change the size of the floating element —
* for instance, prevent it from overflowing the clipping boundary or match the
* width of the reference element.
* @see https://floating-ui.com/docs/size
*/
var size$1 = function(options) {
	if (options === void 0) options = {};
	return {
		name: "size",
		options,
		async fn(state) {
			const { placement, rects, platform, elements } = state;
			const { apply = () => {}, ...detectOverflowOptions } = evaluate(options, state);
			const overflow = await platform.detectOverflow(state, detectOverflowOptions);
			const side = getSide(placement);
			const alignment = getAlignment(placement);
			const isYAxis = getSideAxis(placement) === "y";
			const { width, height } = rects.floating;
			let heightSide;
			let widthSide;
			if (side === "top" || side === "bottom") {
				heightSide = side;
				widthSide = alignment === (await (platform.isRTL == null ? void 0 : platform.isRTL(elements.floating)) ? "start" : "end") ? "left" : "right";
			} else {
				widthSide = side;
				heightSide = alignment === "end" ? "top" : "bottom";
			}
			const maximumClippingHeight = height - overflow.top - overflow.bottom;
			const maximumClippingWidth = width - overflow.left - overflow.right;
			const overflowAvailableHeight = min(height - overflow[heightSide], maximumClippingHeight);
			const overflowAvailableWidth = min(width - overflow[widthSide], maximumClippingWidth);
			const shiftData = state.middlewareData.shift;
			const noShift = !shiftData;
			let availableHeight = overflowAvailableHeight;
			let availableWidth = overflowAvailableWidth;
			if (shiftData != null && shiftData.enabled.x) availableWidth = maximumClippingWidth;
			if (shiftData != null && shiftData.enabled.y) availableHeight = maximumClippingHeight;
			if (noShift && !alignment) {
				if (isYAxis) availableWidth = width - 2 * max(overflow.left, overflow.right);
				else availableHeight = height - 2 * max(overflow.top, overflow.bottom);
			}
			await apply({
				...state,
				availableWidth,
				availableHeight
			});
			const nextDimensions = await platform.getDimensions(elements.floating);
			if (width !== nextDimensions.width || height !== nextDimensions.height) return { reset: { rects: true } };
			return {};
		}
	};
};
// node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs
function getCssDimensions(element) {
	const css = getComputedStyle$1(element);
	let width = parseFloat(css.width) || 0;
	let height = parseFloat(css.height) || 0;
	const hasOffset = isHTMLElement(element);
	const offsetWidth = hasOffset ? element.offsetWidth : width;
	const offsetHeight = hasOffset ? element.offsetHeight : height;
	const shouldFallback = round(width) !== offsetWidth || round(height) !== offsetHeight;
	if (shouldFallback) {
		width = offsetWidth;
		height = offsetHeight;
	}
	return {
		width,
		height,
		$: shouldFallback
	};
}
function unwrapElement(element) {
	return !isElement(element) ? element.contextElement : element;
}
function getScale(element) {
	const domElement = unwrapElement(element);
	if (!isHTMLElement(domElement)) return createCoords(1);
	const rect = domElement.getBoundingClientRect();
	const { width, height, $ } = getCssDimensions(domElement);
	let x = ($ ? round(rect.width) : rect.width) / width;
	let y = ($ ? round(rect.height) : rect.height) / height;
	if (!x || !Number.isFinite(x)) x = 1;
	if (!y || !Number.isFinite(y)) y = 1;
	return {
		x,
		y
	};
}
var noOffsets = /*#__PURE__*/ createCoords(0);
function getVisualOffsets(element) {
	const win = getWindow(element);
	if (!isWebKit() || !win.visualViewport) return noOffsets;
	return {
		x: win.visualViewport.offsetLeft,
		y: win.visualViewport.offsetTop
	};
}
function shouldAddVisualOffsets(element, isFixed, floatingOffsetParent) {
	if (isFixed === void 0) isFixed = false;
	return !!floatingOffsetParent && isFixed && floatingOffsetParent === getWindow(element);
}
function getBoundingClientRect(element, includeScale, isFixedStrategy, offsetParent) {
	if (includeScale === void 0) includeScale = false;
	if (isFixedStrategy === void 0) isFixedStrategy = false;
	const clientRect = element.getBoundingClientRect();
	const domElement = unwrapElement(element);
	let scale = createCoords(1);
	if (includeScale) {
		if (offsetParent) {
			if (isElement(offsetParent)) scale = getScale(offsetParent);
		} else scale = getScale(element);
	}
	const visualOffsets = shouldAddVisualOffsets(domElement, isFixedStrategy, offsetParent) ? getVisualOffsets(domElement) : createCoords(0);
	let x = (clientRect.left + visualOffsets.x) / scale.x;
	let y = (clientRect.top + visualOffsets.y) / scale.y;
	let width = clientRect.width / scale.x;
	let height = clientRect.height / scale.y;
	if (domElement && offsetParent) {
		const win = getWindow(domElement);
		const offsetWin = isElement(offsetParent) ? getWindow(offsetParent) : offsetParent;
		let currentWin = win;
		let currentIFrame = getFrameElement(currentWin);
		while (currentIFrame && offsetWin !== currentWin) {
			const iframeScale = getScale(currentIFrame);
			const iframeRect = currentIFrame.getBoundingClientRect();
			const css = getComputedStyle$1(currentIFrame);
			const left = iframeRect.left + (currentIFrame.clientLeft + parseFloat(css.paddingLeft)) * iframeScale.x;
			const top = iframeRect.top + (currentIFrame.clientTop + parseFloat(css.paddingTop)) * iframeScale.y;
			x *= iframeScale.x;
			y *= iframeScale.y;
			width *= iframeScale.x;
			height *= iframeScale.y;
			x += left;
			y += top;
			currentWin = getWindow(currentIFrame);
			currentIFrame = getFrameElement(currentWin);
		}
	}
	return rectToClientRect({
		width,
		height,
		x,
		y
	});
}
function getWindowScrollBarX(element, rect) {
	const leftScroll = getNodeScroll(element).scrollLeft;
	if (!rect) return getBoundingClientRect(getDocumentElement(element)).left + leftScroll;
	return rect.left + leftScroll;
}
function getHTMLOffset(documentElement, scroll) {
	const htmlRect = documentElement.getBoundingClientRect();
	return {
		x: htmlRect.left + scroll.scrollLeft - getWindowScrollBarX(documentElement, htmlRect),
		y: htmlRect.top + scroll.scrollTop
	};
}
function convertOffsetParentRelativeRectToViewportRelativeRect(_ref) {
	let { elements, rect, offsetParent, strategy } = _ref;
	const isFixed = strategy === "fixed";
	const documentElement = getDocumentElement(offsetParent);
	const topLayer = elements ? isTopLayer(elements.floating) : false;
	if (offsetParent === documentElement || topLayer && isFixed) return rect;
	let scroll = {
		scrollLeft: 0,
		scrollTop: 0
	};
	let scale = createCoords(1);
	const offsets = createCoords(0);
	const isOffsetParentAnElement = isHTMLElement(offsetParent);
	if (isOffsetParentAnElement || !isFixed) {
		if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) scroll = getNodeScroll(offsetParent);
		if (isOffsetParentAnElement) {
			const offsetRect = getBoundingClientRect(offsetParent);
			scale = getScale(offsetParent);
			offsets.x = offsetRect.x + offsetParent.clientLeft;
			offsets.y = offsetRect.y + offsetParent.clientTop;
		}
	}
	const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
	return {
		width: rect.width * scale.x,
		height: rect.height * scale.y,
		x: rect.x * scale.x - scroll.scrollLeft * scale.x + offsets.x + htmlOffset.x,
		y: rect.y * scale.y - scroll.scrollTop * scale.y + offsets.y + htmlOffset.y
	};
}
function getClientRects(element) {
	return element.getClientRects ? Array.from(element.getClientRects()) : [];
}
function getDocumentRect(html) {
	const scroll = getNodeScroll(html);
	const body = html.ownerDocument.body;
	const width = max(html.scrollWidth, html.clientWidth, body.scrollWidth, body.clientWidth);
	const height = max(html.scrollHeight, html.clientHeight, body.scrollHeight, body.clientHeight);
	let x = -scroll.scrollLeft + getWindowScrollBarX(html);
	const y = -scroll.scrollTop;
	if (getComputedStyle$1(body).direction === "rtl") x += max(html.clientWidth, body.clientWidth) - width;
	return {
		width,
		height,
		x,
		y
	};
}
var SCROLLBAR_MAX = 25;
function getViewportRect(element, strategy, rootBoundary) {
	if (rootBoundary === void 0) rootBoundary = "viewport";
	const isLayoutViewport = rootBoundary === "layoutViewport";
	const win = getWindow(element);
	const html = getDocumentElement(element);
	const visualViewport = win.visualViewport;
	let width = html.clientWidth;
	let height = html.clientHeight;
	let x = 0;
	let y = 0;
	if (visualViewport) {
		const layoutRelativeClientCoords = !isWebKit() || strategy === "fixed";
		if (isLayoutViewport) {
			if (!layoutRelativeClientCoords) {
				x = -visualViewport.offsetLeft;
				y = -visualViewport.offsetTop;
			}
		} else {
			width = visualViewport.width;
			height = visualViewport.height;
			if (layoutRelativeClientCoords) {
				x = visualViewport.offsetLeft;
				y = visualViewport.offsetTop;
			}
		}
	}
	if (getWindowScrollBarX(html) <= 0) {
		const doc = html.ownerDocument;
		const body = doc.body;
		const bodyStyles = getComputedStyle(body);
		const bodyMarginInline = doc.compatMode === "CSS1Compat" ? parseFloat(bodyStyles.marginLeft) + parseFloat(bodyStyles.marginRight) || 0 : 0;
		const reservedWidth = Math.abs(html.clientWidth - body.clientWidth - bodyMarginInline);
		const gutter = getComputedStyle(html).scrollbarGutter === "stable both-edges" ? reservedWidth / 2 : reservedWidth;
		if (gutter <= SCROLLBAR_MAX) width -= gutter;
	}
	return {
		width,
		height,
		x,
		y
	};
}
function getInnerBoundingClientRect(element, strategy) {
	const clientRect = getBoundingClientRect(element, true, strategy === "fixed");
	const top = clientRect.top + element.clientTop;
	const left = clientRect.left + element.clientLeft;
	const scale = getScale(element);
	return {
		width: element.clientWidth * scale.x,
		height: element.clientHeight * scale.y,
		x: left * scale.x,
		y: top * scale.y
	};
}
function getClientRectFromClippingAncestor(element, clippingAncestor, strategy) {
	let rect;
	if (clippingAncestor === "viewport" || clippingAncestor === "layoutViewport") rect = getViewportRect(element, strategy, clippingAncestor);
	else if (clippingAncestor === "document") rect = getDocumentRect(getDocumentElement(element));
	else if (isElement(clippingAncestor)) rect = getInnerBoundingClientRect(clippingAncestor, strategy);
	else {
		const visualOffsets = getVisualOffsets(element);
		rect = {
			x: clippingAncestor.x - visualOffsets.x,
			y: clippingAncestor.y - visualOffsets.y,
			width: clippingAncestor.width,
			height: clippingAncestor.height
		};
	}
	return rectToClientRect(rect);
}
function getClippingElementAncestors(element, cache) {
	const cachedResult = cache.get(element);
	if (cachedResult) return cachedResult;
	let result = getOverflowAncestors(element, [], false).filter((el) => isElement(el) && getNodeName(el) !== "body");
	let lastKeptComputedStyle = null;
	const elementIsFixed = getComputedStyle$1(element).position === "fixed";
	let currentNode = elementIsFixed ? getParentNode(element) : element;
	while (isElement(currentNode) && !isLastTraversableNode(currentNode)) {
		const computedStyle = getComputedStyle$1(currentNode);
		const currentNodeIsContaining = isContainingBlock(currentNode);
		const lastPosition = lastKeptComputedStyle ? lastKeptComputedStyle.position : elementIsFixed ? "fixed" : "";
		if (!currentNodeIsContaining && (lastPosition === "fixed" || lastPosition === "absolute" && computedStyle.position === "static")) result = result.filter((ancestor) => ancestor !== currentNode);
		else lastKeptComputedStyle = computedStyle;
		currentNode = getParentNode(currentNode);
	}
	cache.set(element, result);
	return result;
}
function getClippingRect(_ref) {
	let { element, boundary, rootBoundary, strategy } = _ref;
	const clippingAncestors = [...boundary === "clippingAncestors" ? isTopLayer(element) ? [] : getClippingElementAncestors(element, this._c) : [].concat(boundary), rootBoundary];
	const firstRect = getClientRectFromClippingAncestor(element, clippingAncestors[0], strategy);
	let top = firstRect.top;
	let right = firstRect.right;
	let bottom = firstRect.bottom;
	let left = firstRect.left;
	for (let i = 1; i < clippingAncestors.length; i++) {
		const rect = getClientRectFromClippingAncestor(element, clippingAncestors[i], strategy);
		top = max(rect.top, top);
		right = min(rect.right, right);
		bottom = min(rect.bottom, bottom);
		left = max(rect.left, left);
	}
	return {
		width: right - left,
		height: bottom - top,
		x: left,
		y: top
	};
}
function getDimensions(element) {
	const { width, height } = getCssDimensions(element);
	return {
		width,
		height
	};
}
function getRectRelativeToOffsetParent(element, offsetParent, strategy) {
	const isOffsetParentAnElement = isHTMLElement(offsetParent);
	const documentElement = getDocumentElement(offsetParent);
	const isFixed = strategy === "fixed";
	const rect = getBoundingClientRect(element, true, isFixed, offsetParent);
	let scroll = {
		scrollLeft: 0,
		scrollTop: 0
	};
	const offsets = createCoords(0);
	if (isOffsetParentAnElement || !isFixed) {
		if (getNodeName(offsetParent) !== "body" || isOverflowElement(documentElement)) scroll = getNodeScroll(offsetParent);
		if (isOffsetParentAnElement) {
			const offsetRect = getBoundingClientRect(offsetParent, true, isFixed, offsetParent);
			offsets.x = offsetRect.x + offsetParent.clientLeft;
			offsets.y = offsetRect.y + offsetParent.clientTop;
		}
	}
	if (!isOffsetParentAnElement && documentElement) offsets.x = getWindowScrollBarX(documentElement);
	const htmlOffset = documentElement && !isOffsetParentAnElement && !isFixed ? getHTMLOffset(documentElement, scroll) : createCoords(0);
	return {
		x: rect.left + scroll.scrollLeft - offsets.x - htmlOffset.x,
		y: rect.top + scroll.scrollTop - offsets.y - htmlOffset.y,
		width: rect.width,
		height: rect.height
	};
}
function isStaticPositioned(element) {
	return getComputedStyle$1(element).position === "static";
}
function getTrueOffsetParent(element, polyfill) {
	if (!isHTMLElement(element) || getComputedStyle$1(element).position === "fixed") return null;
	if (polyfill) return polyfill(element);
	let rawOffsetParent = element.offsetParent;
	if (getDocumentElement(element) === rawOffsetParent) rawOffsetParent = rawOffsetParent.ownerDocument.body;
	return rawOffsetParent;
}
function getOffsetParent(element, polyfill) {
	const win = getWindow(element);
	if (isTopLayer(element)) return win;
	if (!isHTMLElement(element)) {
		let svgOffsetParent = getParentNode(element);
		while (svgOffsetParent && !isLastTraversableNode(svgOffsetParent)) {
			if (isElement(svgOffsetParent) && !isStaticPositioned(svgOffsetParent)) return svgOffsetParent;
			svgOffsetParent = getParentNode(svgOffsetParent);
		}
		return win;
	}
	let offsetParent = getTrueOffsetParent(element, polyfill);
	while (offsetParent && isTableElement(offsetParent) && isStaticPositioned(offsetParent)) offsetParent = getTrueOffsetParent(offsetParent, polyfill);
	if (offsetParent && isLastTraversableNode(offsetParent) && isStaticPositioned(offsetParent) && !isContainingBlock(offsetParent)) return win;
	return offsetParent || getContainingBlock(element) || win;
}
var getElementRects = async function(data) {
	const getOffsetParentFn = this.getOffsetParent || getOffsetParent;
	const getDimensionsFn = this.getDimensions;
	const floatingDimensions = await getDimensionsFn(data.floating);
	return {
		reference: getRectRelativeToOffsetParent(data.reference, await getOffsetParentFn(data.floating), data.strategy),
		floating: {
			x: 0,
			y: 0,
			width: floatingDimensions.width,
			height: floatingDimensions.height
		}
	};
};
function isRTL(element) {
	return getComputedStyle$1(element).direction === "rtl";
}
var platform = {
	convertOffsetParentRelativeRectToViewportRelativeRect,
	getDocumentElement,
	getClippingRect,
	getOffsetParent,
	getElementRects,
	getClientRects,
	getDimensions,
	getScale,
	isElement,
	isRTL
};
function rectsAreEqual(a, b) {
	return a.x === b.x && a.y === b.y && a.width === b.width && a.height === b.height;
}
function observeMove(element, onMove, ancestorResize) {
	let io = null;
	let timeoutId;
	const root = getDocumentElement(element);
	function cleanup() {
		var _io;
		clearTimeout(timeoutId);
		(_io = io) == null || _io.disconnect();
		io = null;
	}
	function refresh(skip, threshold) {
		if (skip === void 0) skip = false;
		if (threshold === void 0) threshold = 1;
		cleanup();
		const elementRectForRootMargin = element.getBoundingClientRect();
		const { left, top, width, height } = elementRectForRootMargin;
		if (!skip) onMove();
		if (!width || !height) return;
		const insetTop = floor(top);
		const insetRight = floor(root.clientWidth - (left + width));
		const insetBottom = floor(root.clientHeight - (top + height));
		const insetLeft = floor(left);
		const options = {
			rootMargin: -insetTop + "px " + -insetRight + "px " + -insetBottom + "px " + -insetLeft + "px",
			threshold: max(0, min(1, threshold)) || 1
		};
		let isFirstUpdate = true;
		function handleObserve(entries) {
			const ratio = entries[0].intersectionRatio;
			if (!rectsAreEqual(elementRectForRootMargin, element.getBoundingClientRect())) return refresh();
			if (ratio !== threshold) {
				if (!isFirstUpdate) return refresh();
				if (!ratio) timeoutId = setTimeout(() => {
					refresh(false, 1e-7);
				}, 1e3);
				else refresh(false, ratio);
			}
			isFirstUpdate = false;
		}
		try {
			io = new IntersectionObserver(handleObserve, {
				...options,
				root: root.ownerDocument
			});
		} catch (_e) {
			io = new IntersectionObserver(handleObserve, options);
		}
		io.observe(element);
	}
	const win = getWindow(element);
	const handleResize = () => refresh(ancestorResize);
	win.addEventListener("resize", handleResize);
	refresh(true);
	return () => {
		win.removeEventListener("resize", handleResize);
		cleanup();
	};
}
/**
* Automatically updates the position of the floating element when necessary.
* Should only be called when the floating element is mounted on the DOM or
* visible on the screen.
* @returns cleanup function that should be invoked when the floating element is
* removed from the DOM or hidden from the screen.
* @see https://floating-ui.com/docs/autoUpdate
*/
function autoUpdate(reference, floating, update, options) {
	if (options === void 0) options = {};
	const { ancestorScroll = true, ancestorResize = true, elementResize = typeof ResizeObserver === "function", layoutShift = typeof IntersectionObserver === "function", animationFrame = false } = options;
	const referenceEl = unwrapElement(reference);
	const ancestors = ancestorScroll || ancestorResize ? [...referenceEl ? getOverflowAncestors(referenceEl) : [], ...floating ? getOverflowAncestors(floating) : []] : [];
	ancestors.forEach((ancestor) => {
		ancestorScroll && ancestor.addEventListener("scroll", update);
		ancestorResize && ancestor.addEventListener("resize", update);
	});
	const cleanupIo = referenceEl && layoutShift ? observeMove(referenceEl, update, ancestorResize) : null;
	let reobserveFrame = -1;
	let resizeObserver = null;
	if (elementResize) {
		resizeObserver = new ResizeObserver((_ref) => {
			let [firstEntry] = _ref;
			if (firstEntry && firstEntry.target === referenceEl && resizeObserver && floating) {
				resizeObserver.unobserve(floating);
				cancelAnimationFrame(reobserveFrame);
				reobserveFrame = requestAnimationFrame(() => {
					var _resizeObserver;
					(_resizeObserver = resizeObserver) == null || _resizeObserver.observe(floating);
				});
			}
			update();
		});
		if (referenceEl && !animationFrame) resizeObserver.observe(referenceEl);
		if (floating) resizeObserver.observe(floating);
	}
	let frameId;
	let prevRefRect = animationFrame ? getBoundingClientRect(reference) : null;
	if (animationFrame) frameLoop();
	function frameLoop() {
		const nextRefRect = getBoundingClientRect(reference);
		if (prevRefRect && !rectsAreEqual(prevRefRect, nextRefRect)) update();
		prevRefRect = nextRefRect;
		frameId = requestAnimationFrame(frameLoop);
	}
	update();
	return () => {
		var _resizeObserver2;
		ancestors.forEach((ancestor) => {
			ancestorScroll && ancestor.removeEventListener("scroll", update);
			ancestorResize && ancestor.removeEventListener("resize", update);
		});
		cleanupIo?.();
		(_resizeObserver2 = resizeObserver) == null || _resizeObserver2.disconnect();
		resizeObserver = null;
		if (animationFrame) cancelAnimationFrame(frameId);
	};
}
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset$2 = offset$1;
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift$2 = shift$1;
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip$2 = flip$1;
/**
* Provides data that allows you to change the size of the floating element —
* for instance, prevent it from overflowing the clipping boundary or match the
* width of the reference element.
* @see https://floating-ui.com/docs/size
*/
var size$2 = size$1;
/**
* Built-in `limiter` that will stop `shift()` at a certain point.
*/
var limitShift$2 = limitShift$1;
/**
* Computes the `x` and `y` coordinates that will place the floating element
* next to a given reference element.
*/
var computePosition = (reference, floating, options) => {
	const cache = /* @__PURE__ */ new Map();
	const mergedOptions = options != null ? options : {};
	const platformWithCache = {
		...platform,
		...mergedOptions.platform,
		_c: cache
	};
	return computePosition$1(reference, floating, {
		...mergedOptions,
		platform: platformWithCache
	});
};
// node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
var index = typeof document !== "undefined" ? import_react.useLayoutEffect : function noop() {};
function deepEqual(a, b) {
	if (a === b) return true;
	if (typeof a !== typeof b) return false;
	if (typeof a === "function" && a.toString() === b.toString()) return true;
	let length;
	let i;
	let keys;
	if (a && b && typeof a === "object") {
		if (Array.isArray(a)) {
			length = a.length;
			if (length !== b.length) return false;
			for (i = length; i-- !== 0;) if (!deepEqual(a[i], b[i])) return false;
			return true;
		}
		keys = Object.keys(a);
		length = keys.length;
		if (length !== Object.keys(b).length) return false;
		for (i = length; i-- !== 0;) if (!{}.hasOwnProperty.call(b, keys[i])) return false;
		for (i = length; i-- !== 0;) {
			const key = keys[i];
			if (key === "_owner" && a.$$typeof) continue;
			if (!deepEqual(a[key], b[key])) return false;
		}
		return true;
	}
	return a !== a && b !== b;
}
function getDPR(element) {
	if (typeof window === "undefined") return 1;
	return (element.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function roundByDPR(element, value) {
	const dpr = getDPR(element);
	return Math.round(value * dpr) / dpr;
}
function useLatestRef(value) {
	const ref = import_react.useRef(value);
	index(() => {
		ref.current = value;
	});
	return ref;
}
/**
* Provides data to position a floating element.
* @see https://floating-ui.com/docs/useFloating
*/
function useFloating(options) {
	if (options === void 0) options = {};
	const { placement = "bottom", strategy = "absolute", middleware = [], platform, elements: { reference: externalReference, floating: externalFloating } = {}, transform = true, whileElementsMounted, open } = options;
	const [data, setData] = import_react.useState({
		x: 0,
		y: 0,
		strategy,
		placement,
		middlewareData: {},
		isPositioned: false
	});
	const [latestMiddleware, setLatestMiddleware] = import_react.useState(middleware);
	if (!deepEqual(latestMiddleware, middleware)) setLatestMiddleware(middleware);
	const [_reference, _setReference] = import_react.useState(null);
	const [_floating, _setFloating] = import_react.useState(null);
	const setReference = import_react.useCallback((node) => {
		if (node !== referenceRef.current) {
			referenceRef.current = node;
			_setReference(node);
		}
	}, []);
	const setFloating = import_react.useCallback((node) => {
		if (node !== floatingRef.current) {
			floatingRef.current = node;
			_setFloating(node);
		}
	}, []);
	const referenceEl = externalReference || _reference;
	const floatingEl = externalFloating || _floating;
	const referenceRef = import_react.useRef(null);
	const floatingRef = import_react.useRef(null);
	const dataRef = import_react.useRef(data);
	const hasWhileElementsMounted = whileElementsMounted != null;
	const whileElementsMountedRef = useLatestRef(whileElementsMounted);
	const platformRef = useLatestRef(platform);
	const openRef = useLatestRef(open);
	const update = import_react.useCallback(() => {
		if (!referenceRef.current || !floatingRef.current) return;
		const config = {
			placement,
			strategy,
			middleware: latestMiddleware
		};
		if (platformRef.current) config.platform = platformRef.current;
		computePosition(referenceRef.current, floatingRef.current, config).then((data) => {
			const fullData = {
				...data,
				isPositioned: openRef.current !== false
			};
			if (isMountedRef.current && !deepEqual(dataRef.current, fullData)) {
				dataRef.current = fullData;
				import_react_dom.flushSync(() => {
					setData(fullData);
				});
			}
		});
	}, [
		latestMiddleware,
		placement,
		strategy,
		platformRef,
		openRef
	]);
	index(() => {
		if (open === false && dataRef.current.isPositioned) {
			dataRef.current.isPositioned = false;
			setData((data) => ({
				...data,
				isPositioned: false
			}));
		}
	}, [open]);
	const isMountedRef = import_react.useRef(false);
	index(() => {
		isMountedRef.current = true;
		return () => {
			isMountedRef.current = false;
		};
	}, []);
	index(() => {
		if (referenceEl) referenceRef.current = referenceEl;
		if (floatingEl) floatingRef.current = floatingEl;
		if (referenceEl && floatingEl) {
			if (whileElementsMountedRef.current) return whileElementsMountedRef.current(referenceEl, floatingEl, update);
			update();
		}
	}, [
		referenceEl,
		floatingEl,
		update,
		whileElementsMountedRef,
		hasWhileElementsMounted
	]);
	const refs = import_react.useMemo(() => ({
		reference: referenceRef,
		floating: floatingRef,
		setReference,
		setFloating
	}), [setReference, setFloating]);
	const elements = import_react.useMemo(() => ({
		reference: referenceEl,
		floating: floatingEl
	}), [referenceEl, floatingEl]);
	const floatingStyles = import_react.useMemo(() => {
		const initialStyles = {
			position: strategy,
			left: 0,
			top: 0
		};
		if (!elements.floating) return initialStyles;
		const x = roundByDPR(elements.floating, data.x);
		const y = roundByDPR(elements.floating, data.y);
		if (transform) return {
			...initialStyles,
			transform: "translate(" + x + "px, " + y + "px)",
			...getDPR(elements.floating) >= 1.5 && { willChange: "transform" }
		};
		return {
			position: strategy,
			left: x,
			top: y
		};
	}, [
		strategy,
		transform,
		elements.floating,
		data.x,
		data.y
	]);
	return import_react.useMemo(() => ({
		...data,
		update,
		refs,
		elements,
		floatingStyles
	}), [
		data,
		update,
		refs,
		elements,
		floatingStyles
	]);
}
/**
* Modifies the placement by translating the floating element along the
* specified axes.
* A number (shorthand for `mainAxis` or distance), or an axes configuration
* object may be passed.
* @see https://floating-ui.com/docs/offset
*/
var offset = (options, deps) => {
	const result = offset$2(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Optimizes the visibility of the floating element by shifting it in order to
* keep it in view when it will overflow the clipping boundary.
* @see https://floating-ui.com/docs/shift
*/
var shift = (options, deps) => {
	const result = shift$2(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Built-in `limiter` that will stop `shift()` at a certain point.
*/
var limitShift = (options, deps) => {
	return {
		fn: limitShift$2(options).fn,
		options: [options, deps]
	};
};
/**
* Optimizes the visibility of the floating element by flipping the `placement`
* in order to keep it in view when the preferred placement(s) will overflow the
* clipping boundary. Alternative to `autoPlacement`.
* @see https://floating-ui.com/docs/flip
*/
var flip = (options, deps) => {
	const result = flip$2(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
/**
* Provides data that allows you to change the size of the floating element —
* for instance, prevent it from overflowing the clipping boundary or match the
* width of the reference element.
* @see https://floating-ui.com/docs/size
*/
var size = (options, deps) => {
	const result = size$2(options);
	return {
		name: result.name,
		fn: result.fn,
		options: [options, deps]
	};
};
// node_modules/@base-ui/react/internals/getDisabledMountTransitionStyles.mjs
function getDisabledMountTransitionStyles(transitionStatus) {
	return transitionStatus === "starting" ? DISABLED_TRANSITIONS_STYLE : EMPTY_OBJECT;
}
// node_modules/@base-ui/react/floating-ui-react/hooks/useFloating.mjs
/**
* Provides data to position a floating element and context to add interactions.
* The caller supplies the root store, which owns the reference and floating elements.
* @see https://floating-ui.com/docs/useFloating
*/
function useBaseUIFloating(options) {
	const { nodeId, externalTree, rootContext: store } = options;
	const referenceElement = store.useState("referenceElement");
	const floatingElement = store.useState("floatingElement");
	const domReferenceElement = store.useState("domReferenceElement");
	const open = store.useState("open");
	const floatingId = store.useState("floatingId");
	const [positionReference, setPositionReferenceRaw] = import_react.useState(null);
	const domReferenceRef = import_react.useRef(null);
	const tree = useFloatingTree(externalTree);
	const storeElements = import_react.useMemo(() => ({
		reference: referenceElement,
		floating: floatingElement,
		domReference: domReferenceElement
	}), [
		referenceElement,
		floatingElement,
		domReferenceElement
	]);
	const position = useFloating({
		...options,
		elements: {
			...storeElements,
			...positionReference && { reference: positionReference }
		}
	});
	const setPositionReference = import_react.useCallback((node) => {
		const computedPositionReference = isElement(node) ? {
			getBoundingClientRect: () => node.getBoundingClientRect(),
			getClientRects: () => node.getClientRects(),
			contextElement: node
		} : node;
		setPositionReferenceRaw(computedPositionReference);
		position.refs.setReference(computedPositionReference);
	}, [position.refs]);
	const refs = import_react.useMemo(() => ({
		...position.refs,
		setPositionReference,
		domReference: domReferenceRef
	}), [position.refs, setPositionReference]);
	const elements = import_react.useMemo(() => ({
		...position.elements,
		domReference: domReferenceElement
	}), [position.elements, domReferenceElement]);
	const context = import_react.useMemo(() => ({
		...position,
		dataRef: store.context.dataRef,
		open,
		onOpenChange: store.setOpen,
		events: store.context.events,
		floatingId,
		refs,
		elements,
		nodeId,
		rootStore: store
	}), [
		position,
		refs,
		elements,
		nodeId,
		store,
		open,
		floatingId
	]);
	useIsoLayoutEffect(() => {
		if (domReferenceElement) domReferenceRef.current = domReferenceElement;
	}, [domReferenceElement]);
	useIsoLayoutEffect(() => {
		store.context.dataRef.current.floatingContext = context;
		const node = tree?.nodesRef.current.find((n) => n.id === nodeId);
		if (node) node.context = context;
	});
	return import_react.useMemo(() => ({
		...position,
		context,
		refs,
		elements,
		rootStore: store
	}), [
		position,
		refs,
		elements,
		context,
		store
	]);
}
// node_modules/@base-ui/react/floating-ui-react/middleware/arrow.mjs
/**
* Fork of the original `arrow` middleware from Floating UI that always uses the floating element
* as the arrow's offset parent.
*/
var baseArrow = (options) => ({
	name: "arrow",
	options,
	async fn(state) {
		const { x, y, placement, rects, platform, elements, middlewareData } = state;
		const { element, padding = 0 } = evaluate(options, state) || {};
		if (element == null) return {};
		const paddingObject = getPaddingObject(padding);
		const coords = {
			x,
			y
		};
		const axis = getAlignmentAxis(placement);
		const length = getAxisLength(axis);
		const arrowDimensions = await platform.getDimensions(element);
		const isYAxis = axis === "y";
		const minProp = isYAxis ? "top" : "left";
		const maxProp = isYAxis ? "bottom" : "right";
		const clientProp = isYAxis ? "clientHeight" : "clientWidth";
		const endDiff = rects.reference[length] + rects.reference[axis] - coords[axis] - rects.floating[length];
		const startDiff = coords[axis] - rects.reference[axis];
		const clientSize = elements.floating[clientProp] || rects.floating[length];
		const centerToReference = endDiff / 2 - startDiff / 2;
		const largestPossiblePadding = clientSize / 2 - arrowDimensions[length] / 2 - 1;
		const minPadding = Math.min(paddingObject[minProp], largestPossiblePadding);
		const maxPadding = Math.min(paddingObject[maxProp], largestPossiblePadding);
		const min = minPadding;
		const max = clientSize - arrowDimensions[length] - maxPadding;
		const center = clientSize / 2 - arrowDimensions[length] / 2 + centerToReference;
		const offset = clamp(min, center, max);
		const shouldAddOffset = !middlewareData.arrow && getAlignment(placement) != null && center !== offset && rects.reference[length] / 2 - (center < min ? minPadding : maxPadding) - arrowDimensions[length] / 2 < 0;
		const alignmentOffset = shouldAddOffset ? center < min ? center - min : center - max : 0;
		return {
			[axis]: coords[axis] + alignmentOffset,
			data: {
				[axis]: offset,
				centerOffset: center - offset - alignmentOffset,
				...shouldAddOffset && { alignmentOffset }
			},
			reset: shouldAddOffset
		};
	}
});
/**
* Provides data to position an inner element of the floating element so that it
* appears centered to the reference element.
* This wraps the core `arrow` middleware to allow React refs as the element.
* @see https://floating-ui.com/docs/arrow
*/
var arrow = (options, deps) => {
	const { name, fn } = baseArrow(options);
	return {
		name,
		fn,
		options: [options, deps]
	};
};
// node_modules/@base-ui/react/utils/hideMiddleware.mjs
var hide = {
	name: "hide",
	async fn(state) {
		const { width, height, x, y } = state.rects.reference;
		const anchorHidden = width === 0 && height === 0 && x === 0 && y === 0;
		const overflow = await state.platform.detectOverflow(state, { elementContext: "reference" });
		return { data: { referenceHidden: overflow.top - height >= 0 || overflow.right - width >= 0 || overflow.bottom - height >= 0 || overflow.left - width >= 0 || anchorHidden } };
	}
};
// node_modules/@base-ui/react/utils/adaptiveOriginConstants.mjs
var DEFAULT_SIDES = {
	sideX: "left",
	sideY: "top"
};
// node_modules/@base-ui/react/utils/CommonPositionerCssVars.mjs
/**
* The available width between the trigger and the edge of the viewport.
* @type {number}
*/
var availableWidth = "--available-width";
/**
* The available height between the trigger and the edge of the viewport.
* @type {number}
*/
var availableHeight = "--available-height";
/**
* The anchor's width.
* @type {number}
*/
var anchorWidth = "--anchor-width";
/**
* The anchor's height.
* @type {number}
*/
var anchorHeight = "--anchor-height";
/**
* The coordinates that this element is anchored to. Used for animations and transitions.
* @type {string}
*/
var transformOrigin = "--transform-origin";
/**
* The width of the popup's positioner.
* It is important to set `width` to this value when using CSS to animate size changes.
* @type {number}
*/
var positionerWidth = "--positioner-width";
/**
* The height of the popup's positioner.
* It is important to set `height` to this value when using CSS to animate size changes.
* @type {number}
*/
var positionerHeight = "--positioner-height";
// node_modules/@base-ui/react/internals/useAnchorPositioning.mjs
var AVAILABLE_WIDTH_VAR = availableWidth;
var AVAILABLE_HEIGHT_VAR = availableHeight;
function getLogicalSide(sideParam, renderedSide, isRtl) {
	const isLogicalSideParam = sideParam === "inline-start" || sideParam === "inline-end";
	return {
		top: "top",
		right: isLogicalSideParam ? isRtl ? "inline-start" : "inline-end" : "right",
		bottom: "bottom",
		left: isLogicalSideParam ? isRtl ? "inline-end" : "inline-start" : "left"
	}[renderedSide];
}
function getOffsetData(state, sideParam, isRtl) {
	const { rects, placement } = state;
	return {
		side: getLogicalSide(sideParam, getSide(placement), isRtl),
		align: getAlignment(placement) || "center",
		anchor: {
			width: rects.reference.width,
			height: rects.reference.height
		},
		positioner: {
			width: rects.floating.width,
			height: rects.floating.height
		}
	};
}
/**
* Provides standardized anchor positioning behavior for floating elements. Wraps Floating UI's
* `useFloating` hook.
*/
function useAnchorPositioning(params) {
	return useAnchorPositioningWithHook(params, useBaseUIFloating);
}
function useAnchorPositioningWithHook(params, useFloatingHook) {
	const { anchor, positionMethod = "absolute", side: sideParam = "bottom", sideOffset = 0, align = "center", alignOffset = 0, collisionBoundary, collisionPadding: collisionPaddingParam = 5, sticky = false, arrowPadding = 5, disableAnchorTracking = false, inline: inlineMiddleware, keepMounted = false, floatingRootContext, mounted, collisionAvoidance, shift: shift$3, nodeId, adaptiveOrigin, lazyFlip = false, externalTree } = params;
	const collisionAvoidanceSide = collisionAvoidance.side || "flip";
	const collisionAvoidanceAlign = collisionAvoidance.align || "flip";
	const collisionAvoidanceFallbackAxisSide = collisionAvoidance.fallbackAxisSide || "end";
	const shiftCrossAxis = shift$3?.crossAxis ?? false;
	const shiftRootBoundary = shift$3?.rootBoundary;
	const anchorFn = typeof anchor === "function" ? anchor : void 0;
	const anchorFnCallback = useStableCallback(anchorFn);
	const anchorDep = anchorFn ? anchorFnCallback : anchor;
	const anchorValueRef = useValueAsRef(anchor);
	const mountedRef = useValueAsRef(mounted);
	const isRtl = useDirection() === "rtl";
	const [mountPlacement, setMountPlacement] = import_react.useState(null);
	if (!mounted && mountPlacement !== null) setMountPlacement(null);
	const lockAlign = lazyFlip === "placement";
	const mountSide = mountPlacement ? getSide(mountPlacement) : null;
	const mountAlign = mountPlacement && lockAlign ? getAlignment(mountPlacement) || "center" : null;
	const side = mountSide || {
		top: "top",
		right: "right",
		bottom: "bottom",
		left: "left",
		"inline-end": isRtl ? "left" : "right",
		"inline-start": isRtl ? "right" : "left"
	}[sideParam];
	const placementAlign = mountAlign || align;
	const placement = placementAlign === "center" ? side : `${side}-${placementAlign}`;
	let collisionPadding = collisionPaddingParam;
	if (typeof collisionPadding === "number") collisionPadding = {
		top: collisionPadding,
		right: collisionPadding,
		bottom: collisionPadding,
		left: collisionPadding
	};
	else if (collisionPadding) collisionPadding = {
		top: collisionPadding.top || 0,
		right: collisionPadding.right || 0,
		bottom: collisionPadding.bottom || 0,
		left: collisionPadding.left || 0
	};
	const bias = 1;
	const biasTop = sideParam === "bottom" ? bias : 0;
	const biasBottom = sideParam === "top" ? bias : 0;
	const biasLeft = sideParam === "right" ? bias : 0;
	const biasRight = sideParam === "left" ? bias : 0;
	const commonCollisionProps = {
		boundary: collisionBoundary === "clipping-ancestors" ? "clippingAncestors" : collisionBoundary,
		padding: collisionPadding
	};
	const arrowRef = import_react.useRef(null);
	const sideOffsetRef = useValueAsRef(sideOffset);
	const alignOffsetRef = useValueAsRef(alignOffset);
	const sideOffsetDep = typeof sideOffset !== "function" ? sideOffset : 0;
	const alignOffsetDep = typeof alignOffset !== "function" ? alignOffset : 0;
	const middleware = [];
	if (inlineMiddleware) middleware.push(inlineMiddleware);
	middleware.push(offset((state) => {
		const data = getOffsetData(state, sideParam, isRtl);
		const sideAxis = typeof sideOffsetRef.current === "function" ? sideOffsetRef.current(data) : sideOffsetRef.current;
		const alignAxis = typeof alignOffsetRef.current === "function" ? alignOffsetRef.current(data) : alignOffsetRef.current;
		return {
			mainAxis: sideAxis,
			crossAxis: alignAxis,
			alignmentAxis: alignAxis
		};
	}, [
		sideOffsetDep,
		alignOffsetDep,
		isRtl,
		sideParam
	]));
	const shiftDisabled = collisionAvoidanceAlign === "none" && collisionAvoidanceSide !== "shift";
	const crossAxisShiftEnabled = !shiftDisabled && (sticky || shiftCrossAxis || collisionAvoidanceSide === "shift");
	const flipMiddleware = collisionAvoidanceSide === "none" ? null : flip({
		...commonCollisionProps,
		padding: {
			top: collisionPadding.top + bias + biasTop,
			right: collisionPadding.right + bias + biasRight,
			bottom: collisionPadding.bottom + bias + biasBottom,
			left: collisionPadding.left + bias + biasLeft
		},
		mainAxis: !shiftCrossAxis && collisionAvoidanceSide === "flip",
		crossAxis: collisionAvoidanceAlign === "flip" ? "alignment" : false,
		fallbackAxisSideDirection: collisionAvoidanceFallbackAxisSide
	});
	const shiftMiddleware = shiftDisabled ? null : shift({
		...commonCollisionProps,
		rootBoundary: shiftRootBoundary,
		mainAxis: collisionAvoidanceAlign !== "none",
		crossAxis: crossAxisShiftEnabled,
		limiter: sticky || shiftCrossAxis ? void 0 : limitShift((limitData) => {
			if (!arrowRef.current) return {};
			const { width, height } = arrowRef.current.getBoundingClientRect();
			const sideAxis = getSideAxis(getSide(limitData.placement));
			const arrowSize = sideAxis === "y" ? width : height;
			const offsetAmount = sideAxis === "y" ? collisionPadding.left + collisionPadding.right : collisionPadding.top + collisionPadding.bottom;
			return { offset: arrowSize / 2 + offsetAmount / 2 };
		})
	}, [
		commonCollisionProps,
		sticky,
		shiftCrossAxis,
		shiftRootBoundary,
		collisionPadding,
		collisionAvoidanceAlign
	]);
	if (collisionAvoidanceSide === "shift" || collisionAvoidanceAlign === "shift" || placementAlign === "center") middleware.push(shiftMiddleware, flipMiddleware);
	else middleware.push(flipMiddleware, shiftMiddleware);
	middleware.push(size({
		...commonCollisionProps,
		apply({ elements: { floating }, availableWidth, availableHeight, rects }) {
			if (!mountedRef.current) return;
			const floatingStyle = floating.style;
			floatingStyle.setProperty(AVAILABLE_WIDTH_VAR, `${availableWidth}px`);
			floatingStyle.setProperty(AVAILABLE_HEIGHT_VAR, `${availableHeight}px`);
			const dpr = getWindow(floating).devicePixelRatio || 1;
			const { x, y, width, height } = rects.reference;
			const anchorWidth$1 = (Math.round((x + width) * dpr) - Math.round(x * dpr)) / dpr;
			const anchorHeight$1 = (Math.round((y + height) * dpr) - Math.round(y * dpr)) / dpr;
			floatingStyle.setProperty(anchorWidth, `${anchorWidth$1}px`);
			floatingStyle.setProperty(anchorHeight, `${anchorHeight$1}px`);
		}
	}), arrow((state) => ({
		element: arrowRef.current || ownerDocument(state.elements.floating).createElement("div"),
		padding: arrowRef.current ? arrowPadding : 0
	}), [arrowPadding]), {
		name: "transformOrigin",
		fn(state) {
			const { elements: { floating }, middlewareData, placement: renderedPlacement, platform, rects, y } = state;
			const renderedSide = getSide(renderedPlacement);
			const renderedAlign = getAlignment(renderedPlacement);
			const isVertical = getSideAxis(renderedSide) === "y";
			const arrowEl = arrowRef.current;
			const sideOffsetValue = typeof sideOffset === "function" ? sideOffset(getOffsetData(state, sideParam, isRtl)) : sideOffset;
			let crossOrigin;
			if (!arrowEl && renderedAlign && Math.abs(isVertical ? middlewareData.shift?.x || 0 : middlewareData.shift?.y || 0) <= 1) crossOrigin = renderedAlign === "start" === (isVertical && platform.isRTL?.(floating) === true) ? "100%" : "0%";
			else crossOrigin = `${(isVertical ? middlewareData.arrow?.x || 0 : middlewareData.arrow?.y || 0) + (isVertical ? arrowEl?.clientWidth || 0 : arrowEl?.clientHeight || 0) / 2}px`;
			let sideOrigin = renderedSide === "top" || renderedSide === "left" ? `calc(100% + ${sideOffsetValue}px)` : `${-sideOffsetValue}px`;
			if (crossAxisShiftEnabled && isVertical && Math.abs(middlewareData.shift?.y || 0) > sideOffsetValue) sideOrigin = `${rects.reference.y + rects.reference.height / 2 - y}px`;
			floating.style.setProperty(transformOrigin, isVertical ? `${crossOrigin} ${sideOrigin}` : `${sideOrigin} ${crossOrigin}`);
			return {};
		}
	}, hide, adaptiveOrigin);
	useIsoLayoutEffect(() => {
		if (!mounted && floatingRootContext) floatingRootContext.update({
			referenceElement: null,
			floatingElement: null,
			domReferenceElement: null,
			positionReference: null
		});
	}, [mounted, floatingRootContext]);
	const autoUpdateOptions = import_react.useMemo(() => ({
		ancestorScroll: !disableAnchorTracking,
		elementResize: !disableAnchorTracking && typeof ResizeObserver !== "undefined",
		layoutShift: !disableAnchorTracking && typeof IntersectionObserver !== "undefined"
	}), [disableAnchorTracking]);
	const { refs, elements, x, y, middlewareData, update, placement: renderedPlacement, context, isPositioned, floatingStyles: originalFloatingStyles } = useFloatingHook({
		rootContext: floatingRootContext,
		open: keepMounted ? mounted : void 0,
		placement,
		middleware,
		strategy: positionMethod,
		whileElementsMounted: keepMounted ? void 0 : (...args) => autoUpdate(...args, autoUpdateOptions),
		nodeId,
		externalTree
	});
	const { sideX, sideY } = middlewareData.adaptiveOrigin || DEFAULT_SIDES;
	const resolvedPosition = isPositioned ? positionMethod : "fixed";
	const floatingStyles = import_react.useMemo(() => {
		let base;
		if (!isPositioned) base = {
			position: resolvedPosition,
			top: 0,
			left: 0
		};
		else if (adaptiveOrigin) base = {
			position: resolvedPosition,
			[sideX]: x,
			[sideY]: y
		};
		else base = {
			...originalFloatingStyles,
			position: resolvedPosition
		};
		base[AVAILABLE_WIDTH_VAR] = "100vw";
		base[AVAILABLE_HEIGHT_VAR] = "100vh";
		if (!isPositioned) base.opacity = 0;
		return base;
	}, [
		adaptiveOrigin,
		resolvedPosition,
		sideX,
		x,
		sideY,
		y,
		originalFloatingStyles,
		isPositioned
	]);
	const registeredPositionReferenceRef = import_react.useRef(null);
	useIsoLayoutEffect(() => {
		if (!mounted) return;
		const anchorValue = anchorValueRef.current;
		const resolvedAnchor = typeof anchorValue === "function" ? anchorValue() : anchorValue;
		const finalAnchor = (isRef(resolvedAnchor) ? resolvedAnchor.current : resolvedAnchor) || null;
		if (finalAnchor !== registeredPositionReferenceRef.current) {
			refs.setPositionReference(finalAnchor);
			registeredPositionReferenceRef.current = finalAnchor;
		}
	}, [
		mounted,
		refs,
		anchorDep,
		anchorValueRef
	]);
	import_react.useEffect(() => {
		if (!mounted) return;
		const anchorValue = anchorValueRef.current;
		if (typeof anchorValue === "function") return;
		if (isRef(anchorValue) && anchorValue.current !== registeredPositionReferenceRef.current) {
			refs.setPositionReference(anchorValue.current);
			registeredPositionReferenceRef.current = anchorValue.current;
		}
	}, [
		mounted,
		refs,
		anchorDep,
		anchorValueRef
	]);
	import_react.useEffect(() => {
		if (keepMounted && mounted && elements.reference && elements.floating) return autoUpdate(elements.reference, elements.floating, update, autoUpdateOptions);
	}, [
		keepMounted,
		mounted,
		elements,
		update,
		autoUpdateOptions
	]);
	const renderedSide = getSide(renderedPlacement);
	const logicalRenderedSide = getLogicalSide(sideParam, renderedSide, isRtl);
	const renderedAlign = getAlignment(renderedPlacement) || "center";
	const anchorHidden = Boolean(middlewareData.hide?.referenceHidden);
	useIsoLayoutEffect(() => {
		if (lazyFlip && mounted && isPositioned && (renderedSide !== side || lockAlign && renderedAlign !== placementAlign)) setMountPlacement(renderedPlacement);
	}, [
		lazyFlip,
		lockAlign,
		mounted,
		isPositioned,
		renderedPlacement,
		renderedSide,
		renderedAlign,
		side,
		placementAlign
	]);
	const arrowStyles = import_react.useMemo(() => ({
		position: "absolute",
		top: middlewareData.arrow?.y,
		left: middlewareData.arrow?.x
	}), [middlewareData.arrow]);
	const arrowUncentered = middlewareData.arrow?.centerOffset !== 0;
	return import_react.useMemo(() => ({
		positionerStyles: floatingStyles,
		arrowStyles,
		arrowRef,
		arrowUncentered,
		side: logicalRenderedSide,
		align: renderedAlign,
		physicalSide: renderedSide,
		anchorHidden,
		refs,
		context,
		isPositioned,
		update
	}), [
		floatingStyles,
		arrowStyles,
		arrowRef,
		arrowUncentered,
		logicalRenderedSide,
		renderedAlign,
		renderedSide,
		anchorHidden,
		refs,
		context,
		isPositioned,
		update
	]);
}
function isRef(param) {
	return param != null && "current" in param;
}
// node_modules/@base-ui/react/utils/usePositioner.mjs
/**
* Renders the shared outer Positioner element used by popup components.
* Applies the common role, hidden state, transition styles, state attributes, and optional inert styling.
*/
function usePositioner(componentProps, state, { styles, transitionStatus, props, refs, hidden, inert = false }) {
	const style = { ...styles };
	if (inert) style.pointerEvents = "none";
	return useRenderElement("div", componentProps, {
		state,
		ref: refs,
		props: [
			{
				role: "presentation",
				hidden,
				style
			},
			getDisabledMountTransitionStyles(transitionStatus),
			props
		],
		stateAttributesMapping: popupStateMapping
	});
}
// node_modules/@base-ui/utils/usePreviousValue.mjs
/**
* Returns a previous value of its argument.
* @param value Current value.
* @returns Previous value, or null if there is no previous value.
*/
function usePreviousValue(value) {
	const [state, setState] = import_react.useState({
		current: value,
		previous: null
	});
	if (!Object.is(value, state.current)) setState({
		current: value,
		previous: state.current
	});
	return state.previous;
}
export { availableWidth as a, DEFAULT_SIDES as c, availableHeight as i, getDisabledMountTransitionStyles as l, usePositioner as n, positionerHeight as o, useAnchorPositioning as r, positionerWidth as s, usePreviousValue as t, platform as u };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlUHJldmlvdXNWYWx1ZS1lNEtnR3BueS5qcyIsIm5hbWVzIjpbImNvbXB1dGVQb3NpdGlvbiIsImZsaXAiLCJvZmZzZXQiLCJzaGlmdCIsImxpbWl0U2hpZnQiLCJzaXplIiwib2Zmc2V0Iiwic2hpZnQiLCJmbGlwIiwic2l6ZSIsImxpbWl0U2hpZnQiLCJ1c2VMYXlvdXRFZmZlY3QiLCJvZmZzZXQkMSIsInNoaWZ0JDEiLCJsaW1pdFNoaWZ0JDEiLCJmbGlwJDEiLCJzaXplJDEiLCJ1c2VQb3NpdGlvbiIsIkNvbW1vblBvc2l0aW9uZXJDc3NWYXJzLmF2YWlsYWJsZVdpZHRoIiwiQ29tbW9uUG9zaXRpb25lckNzc1ZhcnMuYXZhaWxhYmxlSGVpZ2h0Iiwic2hpZnQiLCJmbG9hdGluZ1NoaWZ0Iiwib3duZXJXaW5kb3ciLCJhbmNob3JXaWR0aCIsImFuY2hvckhlaWdodCIsIkNvbW1vblBvc2l0aW9uZXJDc3NWYXJzLmFuY2hvcldpZHRoIiwiQ29tbW9uUG9zaXRpb25lckNzc1ZhcnMuYW5jaG9ySGVpZ2h0IiwiQ29tbW9uUG9zaXRpb25lckNzc1ZhcnMudHJhbnNmb3JtT3JpZ2luIl0sInNvdXJjZXMiOlsiLi4vLi4vQGZsb2F0aW5nLXVpL2NvcmUvZGlzdC9mbG9hdGluZy11aS5jb3JlLm1qcyIsIi4uLy4uL0BmbG9hdGluZy11aS9kb20vZGlzdC9mbG9hdGluZy11aS5kb20ubWpzIiwiLi4vLi4vQGZsb2F0aW5nLXVpL3JlYWN0LWRvbS9kaXN0L2Zsb2F0aW5nLXVpLnJlYWN0LWRvbS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9pbnRlcm5hbHMvZ2V0RGlzYWJsZWRNb3VudFRyYW5zaXRpb25TdHlsZXMubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvaG9va3MvdXNlRmxvYXRpbmcubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvZmxvYXRpbmctdWktcmVhY3QvbWlkZGxld2FyZS9hcnJvdy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9oaWRlTWlkZGxld2FyZS5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9hZGFwdGl2ZU9yaWdpbkNvbnN0YW50cy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC91dGlscy9Db21tb25Qb3NpdGlvbmVyQ3NzVmFycy5tanMiLCIuLi8uLi9AYmFzZS11aS9yZWFjdC9pbnRlcm5hbHMvdXNlQW5jaG9yUG9zaXRpb25pbmcubWpzIiwiLi4vLi4vQGJhc2UtdWkvcmVhY3QvdXRpbHMvdXNlUG9zaXRpb25lci5tanMiLCIuLi8uLi9AYmFzZS11aS91dGlscy91c2VQcmV2aW91c1ZhbHVlLm1qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBnZXRTaWRlQXhpcywgZ2V0QWxpZ25tZW50QXhpcywgZ2V0QXhpc0xlbmd0aCwgZ2V0U2lkZSwgZ2V0QWxpZ25tZW50LCBldmFsdWF0ZSwgZ2V0UGFkZGluZ09iamVjdCwgcmVjdFRvQ2xpZW50UmVjdCwgbWluLCBjbGFtcCwgcGxhY2VtZW50cywgZ2V0QWxpZ25tZW50U2lkZXMsIGdldE9wcG9zaXRlQWxpZ25tZW50UGxhY2VtZW50LCBnZXRPcHBvc2l0ZVBsYWNlbWVudCwgZ2V0RXhwYW5kZWRQbGFjZW1lbnRzLCBnZXRPcHBvc2l0ZUF4aXNQbGFjZW1lbnRzLCBzaWRlcywgbWF4LCBnZXRPcHBvc2l0ZUF4aXMgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMnO1xuZXhwb3J0IHsgcmVjdFRvQ2xpZW50UmVjdCB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscyc7XG5cbmZ1bmN0aW9uIGNvbXB1dGVDb29yZHNGcm9tUGxhY2VtZW50KF9yZWYsIHBsYWNlbWVudCwgcnRsKSB7XG4gIGxldCB7XG4gICAgcmVmZXJlbmNlLFxuICAgIGZsb2F0aW5nXG4gIH0gPSBfcmVmO1xuICBjb25zdCBzaWRlQXhpcyA9IGdldFNpZGVBeGlzKHBsYWNlbWVudCk7XG4gIGNvbnN0IGFsaWdubWVudEF4aXMgPSBnZXRBbGlnbm1lbnRBeGlzKHBsYWNlbWVudCk7XG4gIGNvbnN0IGFsaWduTGVuZ3RoID0gZ2V0QXhpc0xlbmd0aChhbGlnbm1lbnRBeGlzKTtcbiAgY29uc3Qgc2lkZSA9IGdldFNpZGUocGxhY2VtZW50KTtcbiAgY29uc3QgaXNWZXJ0aWNhbCA9IHNpZGVBeGlzID09PSAneSc7XG4gIGNvbnN0IGNvbW1vblggPSByZWZlcmVuY2UueCArIHJlZmVyZW5jZS53aWR0aCAvIDIgLSBmbG9hdGluZy53aWR0aCAvIDI7XG4gIGNvbnN0IGNvbW1vblkgPSByZWZlcmVuY2UueSArIHJlZmVyZW5jZS5oZWlnaHQgLyAyIC0gZmxvYXRpbmcuaGVpZ2h0IC8gMjtcbiAgY29uc3QgY29tbW9uQWxpZ24gPSByZWZlcmVuY2VbYWxpZ25MZW5ndGhdIC8gMiAtIGZsb2F0aW5nW2FsaWduTGVuZ3RoXSAvIDI7XG4gIGxldCBjb29yZHM7XG4gIHN3aXRjaCAoc2lkZSkge1xuICAgIGNhc2UgJ3RvcCc6XG4gICAgICBjb29yZHMgPSB7XG4gICAgICAgIHg6IGNvbW1vblgsXG4gICAgICAgIHk6IHJlZmVyZW5jZS55IC0gZmxvYXRpbmcuaGVpZ2h0XG4gICAgICB9O1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAnYm90dG9tJzpcbiAgICAgIGNvb3JkcyA9IHtcbiAgICAgICAgeDogY29tbW9uWCxcbiAgICAgICAgeTogcmVmZXJlbmNlLnkgKyByZWZlcmVuY2UuaGVpZ2h0XG4gICAgICB9O1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSAncmlnaHQnOlxuICAgICAgY29vcmRzID0ge1xuICAgICAgICB4OiByZWZlcmVuY2UueCArIHJlZmVyZW5jZS53aWR0aCxcbiAgICAgICAgeTogY29tbW9uWVxuICAgICAgfTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgJ2xlZnQnOlxuICAgICAgY29vcmRzID0ge1xuICAgICAgICB4OiByZWZlcmVuY2UueCAtIGZsb2F0aW5nLndpZHRoLFxuICAgICAgICB5OiBjb21tb25ZXG4gICAgICB9O1xuICAgICAgYnJlYWs7XG4gICAgZGVmYXVsdDpcbiAgICAgIGNvb3JkcyA9IHtcbiAgICAgICAgeDogcmVmZXJlbmNlLngsXG4gICAgICAgIHk6IHJlZmVyZW5jZS55XG4gICAgICB9O1xuICB9XG4gIGNvbnN0IGFsaWdubWVudCA9IGdldEFsaWdubWVudChwbGFjZW1lbnQpO1xuICBpZiAoYWxpZ25tZW50KSB7XG4gICAgY29vcmRzW2FsaWdubWVudEF4aXNdICs9IGNvbW1vbkFsaWduICogKGFsaWdubWVudCA9PT0gJ2VuZCcgPyAxIDogLTEpICogKHJ0bCAmJiBpc1ZlcnRpY2FsID8gLTEgOiAxKTtcbiAgfVxuICByZXR1cm4gY29vcmRzO1xufVxuXG4vKipcbiAqIFJlc29sdmVzIHdpdGggYW4gb2JqZWN0IG9mIG92ZXJmbG93IHNpZGUgb2Zmc2V0cyB0aGF0IGRldGVybWluZSBob3cgbXVjaCB0aGVcbiAqIGVsZW1lbnQgaXMgb3ZlcmZsb3dpbmcgYSBnaXZlbiBjbGlwcGluZyBib3VuZGFyeSBvbiBlYWNoIHNpZGUuXG4gKiAtIHBvc2l0aXZlID0gb3ZlcmZsb3dpbmcgdGhlIGJvdW5kYXJ5IGJ5IHRoYXQgbnVtYmVyIG9mIHBpeGVsc1xuICogLSBuZWdhdGl2ZSA9IGhvdyBtYW55IHBpeGVscyBsZWZ0IGJlZm9yZSBpdCB3aWxsIG92ZXJmbG93XG4gKiAtIDAgPSBsaWVzIGZsdXNoIHdpdGggdGhlIGJvdW5kYXJ5XG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvZGV0ZWN0T3ZlcmZsb3dcbiAqL1xuYXN5bmMgZnVuY3Rpb24gZGV0ZWN0T3ZlcmZsb3coc3RhdGUsIG9wdGlvbnMpIHtcbiAgdmFyIF9hd2FpdCRwbGF0Zm9ybSRpc0VsZTtcbiAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkge1xuICAgIG9wdGlvbnMgPSB7fTtcbiAgfVxuICBjb25zdCB7XG4gICAgeCxcbiAgICB5LFxuICAgIHBsYXRmb3JtLFxuICAgIHJlY3RzLFxuICAgIGVsZW1lbnRzLFxuICAgIHN0cmF0ZWd5XG4gIH0gPSBzdGF0ZTtcbiAgY29uc3Qge1xuICAgIGJvdW5kYXJ5ID0gJ2NsaXBwaW5nQW5jZXN0b3JzJyxcbiAgICByb290Qm91bmRhcnkgPSAndmlld3BvcnQnLFxuICAgIGVsZW1lbnRDb250ZXh0ID0gJ2Zsb2F0aW5nJyxcbiAgICBhbHRCb3VuZGFyeSA9IGZhbHNlLFxuICAgIHBhZGRpbmcgPSAwXG4gIH0gPSBldmFsdWF0ZShvcHRpb25zLCBzdGF0ZSk7XG4gIGNvbnN0IHBhZGRpbmdPYmplY3QgPSBnZXRQYWRkaW5nT2JqZWN0KHBhZGRpbmcpO1xuICBjb25zdCBhbHRDb250ZXh0ID0gZWxlbWVudENvbnRleHQgPT09ICdmbG9hdGluZycgPyAncmVmZXJlbmNlJyA6ICdmbG9hdGluZyc7XG4gIGNvbnN0IGVsZW1lbnQgPSBlbGVtZW50c1thbHRCb3VuZGFyeSA/IGFsdENvbnRleHQgOiBlbGVtZW50Q29udGV4dF07XG4gIGNvbnN0IGNsaXBwaW5nQ2xpZW50UmVjdCA9IHJlY3RUb0NsaWVudFJlY3QoYXdhaXQgcGxhdGZvcm0uZ2V0Q2xpcHBpbmdSZWN0KHtcbiAgICBlbGVtZW50OiAoKF9hd2FpdCRwbGF0Zm9ybSRpc0VsZSA9IGF3YWl0IChwbGF0Zm9ybS5pc0VsZW1lbnQgPT0gbnVsbCA/IHZvaWQgMCA6IHBsYXRmb3JtLmlzRWxlbWVudChlbGVtZW50KSkpICE9IG51bGwgPyBfYXdhaXQkcGxhdGZvcm0kaXNFbGUgOiB0cnVlKSA/IGVsZW1lbnQgOiBlbGVtZW50LmNvbnRleHRFbGVtZW50IHx8IChhd2FpdCAocGxhdGZvcm0uZ2V0RG9jdW1lbnRFbGVtZW50ID09IG51bGwgPyB2b2lkIDAgOiBwbGF0Zm9ybS5nZXREb2N1bWVudEVsZW1lbnQoZWxlbWVudHMuZmxvYXRpbmcpKSksXG4gICAgYm91bmRhcnksXG4gICAgcm9vdEJvdW5kYXJ5LFxuICAgIHN0cmF0ZWd5XG4gIH0pKTtcbiAgY29uc3QgcmVjdCA9IGVsZW1lbnRDb250ZXh0ID09PSAnZmxvYXRpbmcnID8ge1xuICAgIHgsXG4gICAgeSxcbiAgICB3aWR0aDogcmVjdHMuZmxvYXRpbmcud2lkdGgsXG4gICAgaGVpZ2h0OiByZWN0cy5mbG9hdGluZy5oZWlnaHRcbiAgfSA6IHJlY3RzLnJlZmVyZW5jZTtcbiAgY29uc3Qgb2Zmc2V0UGFyZW50ID0gYXdhaXQgKHBsYXRmb3JtLmdldE9mZnNldFBhcmVudCA9PSBudWxsID8gdm9pZCAwIDogcGxhdGZvcm0uZ2V0T2Zmc2V0UGFyZW50KGVsZW1lbnRzLmZsb2F0aW5nKSk7XG4gIGNvbnN0IG9mZnNldFNjYWxlID0gKGF3YWl0IChwbGF0Zm9ybS5pc0VsZW1lbnQgPT0gbnVsbCA/IHZvaWQgMCA6IHBsYXRmb3JtLmlzRWxlbWVudChvZmZzZXRQYXJlbnQpKSkgJiYgKGF3YWl0IChwbGF0Zm9ybS5nZXRTY2FsZSA9PSBudWxsID8gdm9pZCAwIDogcGxhdGZvcm0uZ2V0U2NhbGUob2Zmc2V0UGFyZW50KSkpIHx8IHtcbiAgICB4OiAxLFxuICAgIHk6IDFcbiAgfTtcbiAgY29uc3QgZWxlbWVudENsaWVudFJlY3QgPSByZWN0VG9DbGllbnRSZWN0KHBsYXRmb3JtLmNvbnZlcnRPZmZzZXRQYXJlbnRSZWxhdGl2ZVJlY3RUb1ZpZXdwb3J0UmVsYXRpdmVSZWN0ID8gYXdhaXQgcGxhdGZvcm0uY29udmVydE9mZnNldFBhcmVudFJlbGF0aXZlUmVjdFRvVmlld3BvcnRSZWxhdGl2ZVJlY3Qoe1xuICAgIGVsZW1lbnRzLFxuICAgIHJlY3QsXG4gICAgb2Zmc2V0UGFyZW50LFxuICAgIHN0cmF0ZWd5XG4gIH0pIDogcmVjdCk7XG4gIHJldHVybiB7XG4gICAgdG9wOiAoY2xpcHBpbmdDbGllbnRSZWN0LnRvcCAtIGVsZW1lbnRDbGllbnRSZWN0LnRvcCArIHBhZGRpbmdPYmplY3QudG9wKSAvIG9mZnNldFNjYWxlLnksXG4gICAgYm90dG9tOiAoZWxlbWVudENsaWVudFJlY3QuYm90dG9tIC0gY2xpcHBpbmdDbGllbnRSZWN0LmJvdHRvbSArIHBhZGRpbmdPYmplY3QuYm90dG9tKSAvIG9mZnNldFNjYWxlLnksXG4gICAgbGVmdDogKGNsaXBwaW5nQ2xpZW50UmVjdC5sZWZ0IC0gZWxlbWVudENsaWVudFJlY3QubGVmdCArIHBhZGRpbmdPYmplY3QubGVmdCkgLyBvZmZzZXRTY2FsZS54LFxuICAgIHJpZ2h0OiAoZWxlbWVudENsaWVudFJlY3QucmlnaHQgLSBjbGlwcGluZ0NsaWVudFJlY3QucmlnaHQgKyBwYWRkaW5nT2JqZWN0LnJpZ2h0KSAvIG9mZnNldFNjYWxlLnhcbiAgfTtcbn1cblxuLy8gTWF4aW11bSBudW1iZXIgb2YgcmVzZXRzIHRoYXQgY2FuIG9jY3VyIGJlZm9yZSBiYWlsaW5nIHRvIGF2b2lkIGluZmluaXRlIHJlc2V0IGxvb3BzLlxuY29uc3QgTUFYX1JFU0VUX0NPVU5UID0gNTA7XG5cbi8qKlxuICogQ29tcHV0ZXMgdGhlIGB4YCBhbmQgYHlgIGNvb3JkaW5hdGVzIHRoYXQgd2lsbCBwbGFjZSB0aGUgZmxvYXRpbmcgZWxlbWVudFxuICogbmV4dCB0byBhIGdpdmVuIHJlZmVyZW5jZSBlbGVtZW50LlxuICpcbiAqIFRoaXMgZXhwb3J0IGRvZXMgbm90IGhhdmUgYW55IGBwbGF0Zm9ybWAgaW50ZXJmYWNlIGxvZ2ljLiBZb3Ugd2lsbCBuZWVkIHRvXG4gKiB3cml0ZSBvbmUgZm9yIHRoZSBwbGF0Zm9ybSB5b3UgYXJlIHVzaW5nIEZsb2F0aW5nIFVJIHdpdGguXG4gKi9cbmNvbnN0IGNvbXB1dGVQb3NpdGlvbiA9IGFzeW5jIChyZWZlcmVuY2UsIGZsb2F0aW5nLCBjb25maWcpID0+IHtcbiAgY29uc3Qge1xuICAgIHBsYWNlbWVudCA9ICdib3R0b20nLFxuICAgIHN0cmF0ZWd5ID0gJ2Fic29sdXRlJyxcbiAgICBtaWRkbGV3YXJlID0gW10sXG4gICAgcGxhdGZvcm1cbiAgfSA9IGNvbmZpZztcbiAgY29uc3QgcGxhdGZvcm1XaXRoRGV0ZWN0T3ZlcmZsb3cgPSBwbGF0Zm9ybS5kZXRlY3RPdmVyZmxvdyA/IHBsYXRmb3JtIDoge1xuICAgIC4uLnBsYXRmb3JtLFxuICAgIGRldGVjdE92ZXJmbG93XG4gIH07XG4gIGNvbnN0IHJ0bCA9IGF3YWl0IChwbGF0Zm9ybS5pc1JUTCA9PSBudWxsID8gdm9pZCAwIDogcGxhdGZvcm0uaXNSVEwoZmxvYXRpbmcpKTtcbiAgbGV0IHJlY3RzID0gYXdhaXQgcGxhdGZvcm0uZ2V0RWxlbWVudFJlY3RzKHtcbiAgICByZWZlcmVuY2UsXG4gICAgZmxvYXRpbmcsXG4gICAgc3RyYXRlZ3lcbiAgfSk7XG4gIGxldCB7XG4gICAgeCxcbiAgICB5XG4gIH0gPSBjb21wdXRlQ29vcmRzRnJvbVBsYWNlbWVudChyZWN0cywgcGxhY2VtZW50LCBydGwpO1xuICBsZXQgc3RhdGVmdWxQbGFjZW1lbnQgPSBwbGFjZW1lbnQ7XG4gIGxldCByZXNldENvdW50ID0gMDtcbiAgY29uc3QgbWlkZGxld2FyZURhdGEgPSB7fTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBtaWRkbGV3YXJlLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgY3VycmVudE1pZGRsZXdhcmUgPSBtaWRkbGV3YXJlW2ldO1xuICAgIGlmICghY3VycmVudE1pZGRsZXdhcmUpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cbiAgICBjb25zdCB7XG4gICAgICBuYW1lLFxuICAgICAgZm5cbiAgICB9ID0gY3VycmVudE1pZGRsZXdhcmU7XG4gICAgY29uc3Qge1xuICAgICAgeDogbmV4dFgsXG4gICAgICB5OiBuZXh0WSxcbiAgICAgIGRhdGEsXG4gICAgICByZXNldFxuICAgIH0gPSBhd2FpdCBmbih7XG4gICAgICB4LFxuICAgICAgeSxcbiAgICAgIGluaXRpYWxQbGFjZW1lbnQ6IHBsYWNlbWVudCxcbiAgICAgIHBsYWNlbWVudDogc3RhdGVmdWxQbGFjZW1lbnQsXG4gICAgICBzdHJhdGVneSxcbiAgICAgIG1pZGRsZXdhcmVEYXRhLFxuICAgICAgcmVjdHMsXG4gICAgICBwbGF0Zm9ybTogcGxhdGZvcm1XaXRoRGV0ZWN0T3ZlcmZsb3csXG4gICAgICBlbGVtZW50czoge1xuICAgICAgICByZWZlcmVuY2UsXG4gICAgICAgIGZsb2F0aW5nXG4gICAgICB9XG4gICAgfSk7XG4gICAgeCA9IG5leHRYICE9IG51bGwgPyBuZXh0WCA6IHg7XG4gICAgeSA9IG5leHRZICE9IG51bGwgPyBuZXh0WSA6IHk7XG4gICAgbWlkZGxld2FyZURhdGFbbmFtZV0gPSB7XG4gICAgICAuLi5taWRkbGV3YXJlRGF0YVtuYW1lXSxcbiAgICAgIC4uLmRhdGFcbiAgICB9O1xuICAgIGlmIChyZXNldCAmJiByZXNldENvdW50IDwgTUFYX1JFU0VUX0NPVU5UKSB7XG4gICAgICByZXNldENvdW50Kys7XG4gICAgICBpZiAodHlwZW9mIHJlc2V0ID09PSAnb2JqZWN0Jykge1xuICAgICAgICBpZiAocmVzZXQucGxhY2VtZW50KSB7XG4gICAgICAgICAgc3RhdGVmdWxQbGFjZW1lbnQgPSByZXNldC5wbGFjZW1lbnQ7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHJlc2V0LnJlY3RzKSB7XG4gICAgICAgICAgcmVjdHMgPSByZXNldC5yZWN0cyA9PT0gdHJ1ZSA/IGF3YWl0IHBsYXRmb3JtLmdldEVsZW1lbnRSZWN0cyh7XG4gICAgICAgICAgICByZWZlcmVuY2UsXG4gICAgICAgICAgICBmbG9hdGluZyxcbiAgICAgICAgICAgIHN0cmF0ZWd5XG4gICAgICAgICAgfSkgOiByZXNldC5yZWN0cztcbiAgICAgICAgfVxuICAgICAgICAoe1xuICAgICAgICAgIHgsXG4gICAgICAgICAgeVxuICAgICAgICB9ID0gY29tcHV0ZUNvb3Jkc0Zyb21QbGFjZW1lbnQocmVjdHMsIHN0YXRlZnVsUGxhY2VtZW50LCBydGwpKTtcbiAgICAgIH1cbiAgICAgIGkgPSAtMTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB4LFxuICAgIHksXG4gICAgcGxhY2VtZW50OiBzdGF0ZWZ1bFBsYWNlbWVudCxcbiAgICBzdHJhdGVneSxcbiAgICBtaWRkbGV3YXJlRGF0YVxuICB9O1xufTtcblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRvIHBvc2l0aW9uIGFuIGlubmVyIGVsZW1lbnQgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgc28gdGhhdCBpdFxuICogYXBwZWFycyBjZW50ZXJlZCB0byB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvYXJyb3dcbiAqL1xuY29uc3QgYXJyb3cgPSBvcHRpb25zID0+ICh7XG4gIG5hbWU6ICdhcnJvdycsXG4gIG9wdGlvbnMsXG4gIGFzeW5jIGZuKHN0YXRlKSB7XG4gICAgY29uc3Qge1xuICAgICAgeCxcbiAgICAgIHksXG4gICAgICBwbGFjZW1lbnQsXG4gICAgICByZWN0cyxcbiAgICAgIHBsYXRmb3JtLFxuICAgICAgZWxlbWVudHMsXG4gICAgICBtaWRkbGV3YXJlRGF0YVxuICAgIH0gPSBzdGF0ZTtcbiAgICAvLyBTaW5jZSBgZWxlbWVudGAgaXMgcmVxdWlyZWQsIHdlIGRvbid0IFBhcnRpYWw8PiB0aGUgdHlwZS5cbiAgICBjb25zdCB7XG4gICAgICBlbGVtZW50LFxuICAgICAgcGFkZGluZyA9IDBcbiAgICB9ID0gZXZhbHVhdGUob3B0aW9ucywgc3RhdGUpIHx8IHt9O1xuICAgIGlmIChlbGVtZW50ID09IG51bGwpIHtcbiAgICAgIHJldHVybiB7fTtcbiAgICB9XG4gICAgY29uc3QgcGFkZGluZ09iamVjdCA9IGdldFBhZGRpbmdPYmplY3QocGFkZGluZyk7XG4gICAgY29uc3QgY29vcmRzID0ge1xuICAgICAgeCxcbiAgICAgIHlcbiAgICB9O1xuICAgIGNvbnN0IGF4aXMgPSBnZXRBbGlnbm1lbnRBeGlzKHBsYWNlbWVudCk7XG4gICAgY29uc3QgbGVuZ3RoID0gZ2V0QXhpc0xlbmd0aChheGlzKTtcbiAgICBjb25zdCBhcnJvd0RpbWVuc2lvbnMgPSBhd2FpdCBwbGF0Zm9ybS5nZXREaW1lbnNpb25zKGVsZW1lbnQpO1xuICAgIGNvbnN0IGlzWUF4aXMgPSBheGlzID09PSAneSc7XG4gICAgY29uc3QgbWluUHJvcCA9IGlzWUF4aXMgPyAndG9wJyA6ICdsZWZ0JztcbiAgICBjb25zdCBtYXhQcm9wID0gaXNZQXhpcyA/ICdib3R0b20nIDogJ3JpZ2h0JztcbiAgICBjb25zdCBjbGllbnRQcm9wID0gaXNZQXhpcyA/ICdjbGllbnRIZWlnaHQnIDogJ2NsaWVudFdpZHRoJztcbiAgICBjb25zdCBlbmREaWZmID0gcmVjdHMucmVmZXJlbmNlW2xlbmd0aF0gKyByZWN0cy5yZWZlcmVuY2VbYXhpc10gLSBjb29yZHNbYXhpc10gLSByZWN0cy5mbG9hdGluZ1tsZW5ndGhdO1xuICAgIGNvbnN0IHN0YXJ0RGlmZiA9IGNvb3Jkc1theGlzXSAtIHJlY3RzLnJlZmVyZW5jZVtheGlzXTtcbiAgICBjb25zdCBhcnJvd09mZnNldFBhcmVudCA9IGF3YWl0IChwbGF0Zm9ybS5nZXRPZmZzZXRQYXJlbnQgPT0gbnVsbCA/IHZvaWQgMCA6IHBsYXRmb3JtLmdldE9mZnNldFBhcmVudChlbGVtZW50KSk7XG4gICAgbGV0IGNsaWVudFNpemUgPSBhcnJvd09mZnNldFBhcmVudCA/IGFycm93T2Zmc2V0UGFyZW50W2NsaWVudFByb3BdIDogMDtcblxuICAgIC8vIERPTSBwbGF0Zm9ybSBjYW4gcmV0dXJuIGB3aW5kb3dgIGFzIHRoZSBgb2Zmc2V0UGFyZW50YC5cbiAgICBpZiAoIWNsaWVudFNpemUgfHwgIShhd2FpdCAocGxhdGZvcm0uaXNFbGVtZW50ID09IG51bGwgPyB2b2lkIDAgOiBwbGF0Zm9ybS5pc0VsZW1lbnQoYXJyb3dPZmZzZXRQYXJlbnQpKSkpIHtcbiAgICAgIGNsaWVudFNpemUgPSBlbGVtZW50cy5mbG9hdGluZ1tjbGllbnRQcm9wXSB8fCByZWN0cy5mbG9hdGluZ1tsZW5ndGhdO1xuICAgIH1cbiAgICBjb25zdCBjZW50ZXJUb1JlZmVyZW5jZSA9IGVuZERpZmYgLyAyIC0gc3RhcnREaWZmIC8gMjtcblxuICAgIC8vIElmIHRoZSBwYWRkaW5nIGlzIGxhcmdlIGVub3VnaCB0aGF0IGl0IGNhdXNlcyB0aGUgYXJyb3cgdG8gbm8gbG9uZ2VyIGJlXG4gICAgLy8gY2VudGVyZWQsIG1vZGlmeSB0aGUgcGFkZGluZyBzbyB0aGF0IGl0IGlzIGNlbnRlcmVkLlxuICAgIGNvbnN0IGxhcmdlc3RQb3NzaWJsZVBhZGRpbmcgPSBjbGllbnRTaXplIC8gMiAtIGFycm93RGltZW5zaW9uc1tsZW5ndGhdIC8gMiAtIDE7XG4gICAgY29uc3QgbWluUGFkZGluZyA9IG1pbihwYWRkaW5nT2JqZWN0W21pblByb3BdLCBsYXJnZXN0UG9zc2libGVQYWRkaW5nKTtcbiAgICBjb25zdCBtYXhQYWRkaW5nID0gbWluKHBhZGRpbmdPYmplY3RbbWF4UHJvcF0sIGxhcmdlc3RQb3NzaWJsZVBhZGRpbmcpO1xuXG4gICAgLy8gTWFrZSBzdXJlIHRoZSBhcnJvdyBkb2Vzbid0IG92ZXJmbG93IHRoZSBmbG9hdGluZyBlbGVtZW50IGlmIHRoZSBjZW50ZXJcbiAgICAvLyBwb2ludCBpcyBvdXRzaWRlIHRoZSBmbG9hdGluZyBlbGVtZW50J3MgYm91bmRzLlxuICAgIGNvbnN0IG1heCA9IGNsaWVudFNpemUgLSBhcnJvd0RpbWVuc2lvbnNbbGVuZ3RoXSAtIG1heFBhZGRpbmc7XG4gICAgY29uc3QgY2VudGVyID0gY2xpZW50U2l6ZSAvIDIgLSBhcnJvd0RpbWVuc2lvbnNbbGVuZ3RoXSAvIDIgKyBjZW50ZXJUb1JlZmVyZW5jZTtcbiAgICBjb25zdCBvZmZzZXQgPSBjbGFtcChtaW5QYWRkaW5nLCBjZW50ZXIsIG1heCk7XG5cbiAgICAvLyBJZiB0aGUgcmVmZXJlbmNlIGlzIHNtYWxsIGVub3VnaCB0aGF0IHRoZSBhcnJvdydzIHBhZGRpbmcgY2F1c2VzIGl0IHRvXG4gICAgLy8gdG8gcG9pbnQgdG8gbm90aGluZyBmb3IgYW4gYWxpZ25lZCBwbGFjZW1lbnQsIGFkanVzdCB0aGUgb2Zmc2V0IG9mIHRoZVxuICAgIC8vIGZsb2F0aW5nIGVsZW1lbnQgaXRzZWxmLiBUbyBlbnN1cmUgYHNoaWZ0KClgIGNvbnRpbnVlcyB0byB0YWtlIGFjdGlvbixcbiAgICAvLyBhIHNpbmdsZSByZXNldCBpcyBwZXJmb3JtZWQgd2hlbiB0aGlzIGlzIHRydWUuXG4gICAgY29uc3Qgc2hvdWxkQWRkT2Zmc2V0ID0gIW1pZGRsZXdhcmVEYXRhLmFycm93ICYmIGdldEFsaWdubWVudChwbGFjZW1lbnQpICE9IG51bGwgJiYgY2VudGVyICE9PSBvZmZzZXQgJiYgcmVjdHMucmVmZXJlbmNlW2xlbmd0aF0gLyAyIC0gKGNlbnRlciA8IG1pblBhZGRpbmcgPyBtaW5QYWRkaW5nIDogbWF4UGFkZGluZykgLSBhcnJvd0RpbWVuc2lvbnNbbGVuZ3RoXSAvIDIgPCAwO1xuICAgIGNvbnN0IGFsaWdubWVudE9mZnNldCA9IHNob3VsZEFkZE9mZnNldCA/IGNlbnRlciA8IG1pblBhZGRpbmcgPyBjZW50ZXIgLSBtaW5QYWRkaW5nIDogY2VudGVyIC0gbWF4IDogMDtcbiAgICByZXR1cm4ge1xuICAgICAgW2F4aXNdOiBjb29yZHNbYXhpc10gKyBhbGlnbm1lbnRPZmZzZXQsXG4gICAgICBkYXRhOiB7XG4gICAgICAgIFtheGlzXTogb2Zmc2V0LFxuICAgICAgICBjZW50ZXJPZmZzZXQ6IGNlbnRlciAtIG9mZnNldCAtIGFsaWdubWVudE9mZnNldCxcbiAgICAgICAgLi4uKHNob3VsZEFkZE9mZnNldCAmJiB7XG4gICAgICAgICAgYWxpZ25tZW50T2Zmc2V0XG4gICAgICAgIH0pXG4gICAgICB9LFxuICAgICAgcmVzZXQ6IHNob3VsZEFkZE9mZnNldFxuICAgIH07XG4gIH1cbn0pO1xuXG5mdW5jdGlvbiBnZXRQbGFjZW1lbnRMaXN0KGFsaWdubWVudCwgYXV0b0FsaWdubWVudCwgYWxsb3dlZFBsYWNlbWVudHMpIHtcbiAgY29uc3QgYWxsb3dlZFBsYWNlbWVudHNTb3J0ZWRCeUFsaWdubWVudCA9IGFsaWdubWVudCA/IFsuLi5hbGxvd2VkUGxhY2VtZW50cy5maWx0ZXIocGxhY2VtZW50ID0+IGdldEFsaWdubWVudChwbGFjZW1lbnQpID09PSBhbGlnbm1lbnQpLCAuLi5hbGxvd2VkUGxhY2VtZW50cy5maWx0ZXIocGxhY2VtZW50ID0+IGdldEFsaWdubWVudChwbGFjZW1lbnQpICE9PSBhbGlnbm1lbnQpXSA6IGFsbG93ZWRQbGFjZW1lbnRzLmZpbHRlcihwbGFjZW1lbnQgPT4gZ2V0U2lkZShwbGFjZW1lbnQpID09PSBwbGFjZW1lbnQpO1xuICByZXR1cm4gYWxsb3dlZFBsYWNlbWVudHNTb3J0ZWRCeUFsaWdubWVudC5maWx0ZXIocGxhY2VtZW50ID0+IHtcbiAgICBpZiAoYWxpZ25tZW50KSB7XG4gICAgICByZXR1cm4gZ2V0QWxpZ25tZW50KHBsYWNlbWVudCkgPT09IGFsaWdubWVudCB8fCAoYXV0b0FsaWdubWVudCA/IGdldE9wcG9zaXRlQWxpZ25tZW50UGxhY2VtZW50KHBsYWNlbWVudCkgIT09IHBsYWNlbWVudCA6IGZhbHNlKTtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH0pO1xufVxuLyoqXG4gKiBPcHRpbWl6ZXMgdGhlIHZpc2liaWxpdHkgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgYnkgY2hvb3NpbmcgdGhlIHBsYWNlbWVudFxuICogdGhhdCBoYXMgdGhlIG1vc3Qgc3BhY2UgYXZhaWxhYmxlIGF1dG9tYXRpY2FsbHksIHdpdGhvdXQgbmVlZGluZyB0byBzcGVjaWZ5IGFcbiAqIHByZWZlcnJlZCBwbGFjZW1lbnQuIEFsdGVybmF0aXZlIHRvIGBmbGlwYC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9hdXRvUGxhY2VtZW50XG4gKi9cbmNvbnN0IGF1dG9QbGFjZW1lbnQgPSBmdW5jdGlvbiAob3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIHJldHVybiB7XG4gICAgbmFtZTogJ2F1dG9QbGFjZW1lbnQnLFxuICAgIG9wdGlvbnMsXG4gICAgYXN5bmMgZm4oc3RhdGUpIHtcbiAgICAgIHZhciBfbWlkZGxld2FyZURhdGEkYXV0b1AsIF9taWRkbGV3YXJlRGF0YSRhdXRvUDIsIF9wbGFjZW1lbnRzVGhhdEZpdE9uRTtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgcmVjdHMsXG4gICAgICAgIG1pZGRsZXdhcmVEYXRhLFxuICAgICAgICBwbGFjZW1lbnQsXG4gICAgICAgIHBsYXRmb3JtLFxuICAgICAgICBlbGVtZW50c1xuICAgICAgfSA9IHN0YXRlO1xuICAgICAgY29uc3Qge1xuICAgICAgICBjcm9zc0F4aXMgPSBmYWxzZSxcbiAgICAgICAgYWxpZ25tZW50LFxuICAgICAgICBhbGxvd2VkUGxhY2VtZW50cyA9IHBsYWNlbWVudHMsXG4gICAgICAgIGF1dG9BbGlnbm1lbnQgPSB0cnVlLFxuICAgICAgICAuLi5kZXRlY3RPdmVyZmxvd09wdGlvbnNcbiAgICAgIH0gPSBldmFsdWF0ZShvcHRpb25zLCBzdGF0ZSk7XG4gICAgICBjb25zdCBwbGFjZW1lbnRzJDEgPSBhbGlnbm1lbnQgIT09IHVuZGVmaW5lZCB8fCBhbGxvd2VkUGxhY2VtZW50cyA9PT0gcGxhY2VtZW50cyA/IGdldFBsYWNlbWVudExpc3QoYWxpZ25tZW50IHx8IG51bGwsIGF1dG9BbGlnbm1lbnQsIGFsbG93ZWRQbGFjZW1lbnRzKSA6IGFsbG93ZWRQbGFjZW1lbnRzO1xuICAgICAgY29uc3QgY3VycmVudEluZGV4ID0gKChfbWlkZGxld2FyZURhdGEkYXV0b1AgPSBtaWRkbGV3YXJlRGF0YS5hdXRvUGxhY2VtZW50KSA9PSBudWxsID8gdm9pZCAwIDogX21pZGRsZXdhcmVEYXRhJGF1dG9QLmluZGV4KSB8fCAwO1xuICAgICAgY29uc3QgY3VycmVudFBsYWNlbWVudCA9IHBsYWNlbWVudHMkMVtjdXJyZW50SW5kZXhdO1xuICAgICAgaWYgKGN1cnJlbnRQbGFjZW1lbnQgPT0gbnVsbCkge1xuICAgICAgICByZXR1cm4ge307XG4gICAgICB9XG5cbiAgICAgIC8vIE1ha2UgYGNvbXB1dGVDb29yZHNgIHN0YXJ0IGZyb20gdGhlIHJpZ2h0IHBsYWNlLlxuICAgICAgaWYgKHBsYWNlbWVudCAhPT0gY3VycmVudFBsYWNlbWVudCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHJlc2V0OiB7XG4gICAgICAgICAgICBwbGFjZW1lbnQ6IHBsYWNlbWVudHMkMVswXVxuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG92ZXJmbG93ID0gYXdhaXQgcGxhdGZvcm0uZGV0ZWN0T3ZlcmZsb3coc3RhdGUsIGRldGVjdE92ZXJmbG93T3B0aW9ucyk7XG4gICAgICBjb25zdCBhbGlnbm1lbnRTaWRlcyA9IGdldEFsaWdubWVudFNpZGVzKGN1cnJlbnRQbGFjZW1lbnQsIHJlY3RzLCBhd2FpdCAocGxhdGZvcm0uaXNSVEwgPT0gbnVsbCA/IHZvaWQgMCA6IHBsYXRmb3JtLmlzUlRMKGVsZW1lbnRzLmZsb2F0aW5nKSkpO1xuICAgICAgY29uc3QgY3VycmVudE92ZXJmbG93cyA9IFtvdmVyZmxvd1tnZXRTaWRlKGN1cnJlbnRQbGFjZW1lbnQpXSwgb3ZlcmZsb3dbYWxpZ25tZW50U2lkZXNbMF1dLCBvdmVyZmxvd1thbGlnbm1lbnRTaWRlc1sxXV1dO1xuICAgICAgY29uc3QgYWxsT3ZlcmZsb3dzID0gWy4uLigoKF9taWRkbGV3YXJlRGF0YSRhdXRvUDIgPSBtaWRkbGV3YXJlRGF0YS5hdXRvUGxhY2VtZW50KSA9PSBudWxsID8gdm9pZCAwIDogX21pZGRsZXdhcmVEYXRhJGF1dG9QMi5vdmVyZmxvd3MpIHx8IFtdKSwge1xuICAgICAgICBwbGFjZW1lbnQ6IGN1cnJlbnRQbGFjZW1lbnQsXG4gICAgICAgIG92ZXJmbG93czogY3VycmVudE92ZXJmbG93c1xuICAgICAgfV07XG4gICAgICBjb25zdCBuZXh0UGxhY2VtZW50ID0gcGxhY2VtZW50cyQxW2N1cnJlbnRJbmRleCArIDFdO1xuXG4gICAgICAvLyBUaGVyZSBhcmUgbW9yZSBwbGFjZW1lbnRzIHRvIGNoZWNrLlxuICAgICAgaWYgKG5leHRQbGFjZW1lbnQpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICBpbmRleDogY3VycmVudEluZGV4ICsgMSxcbiAgICAgICAgICAgIG92ZXJmbG93czogYWxsT3ZlcmZsb3dzXG4gICAgICAgICAgfSxcbiAgICAgICAgICByZXNldDoge1xuICAgICAgICAgICAgcGxhY2VtZW50OiBuZXh0UGxhY2VtZW50XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgY29uc3QgcGxhY2VtZW50c1NvcnRlZEJ5TW9zdFNwYWNlID0gYWxsT3ZlcmZsb3dzLm1hcChkID0+IHtcbiAgICAgICAgY29uc3QgYWxpZ25tZW50ID0gZ2V0QWxpZ25tZW50KGQucGxhY2VtZW50KTtcbiAgICAgICAgcmV0dXJuIFtkLnBsYWNlbWVudCwgYWxpZ25tZW50ICYmIGNyb3NzQXhpcyA/XG4gICAgICAgIC8vIENoZWNrIGFsb25nIHRoZSBtYWluQXhpcyBhbmQgbWFpbiBjcm9zc0F4aXMgc2lkZS5cbiAgICAgICAgZC5vdmVyZmxvd3Muc2xpY2UoMCwgMikucmVkdWNlKChhY2MsIHYpID0+IGFjYyArIHYsIDApIDpcbiAgICAgICAgLy8gQ2hlY2sgb25seSB0aGUgbWFpbkF4aXMuXG4gICAgICAgIGQub3ZlcmZsb3dzWzBdLCBkLm92ZXJmbG93c107XG4gICAgICB9KS5zb3J0KChhLCBiKSA9PiBhWzFdIC0gYlsxXSk7XG4gICAgICBjb25zdCBwbGFjZW1lbnRzVGhhdEZpdE9uRWFjaFNpZGUgPSBwbGFjZW1lbnRzU29ydGVkQnlNb3N0U3BhY2UuZmlsdGVyKGQgPT4gZFsyXS5zbGljZSgwLFxuICAgICAgLy8gQWxpZ25lZCBwbGFjZW1lbnRzIHNob3VsZCBub3QgY2hlY2sgdGhlaXIgb3Bwb3NpdGUgY3Jvc3NBeGlzXG4gICAgICAvLyBzaWRlLlxuICAgICAgZ2V0QWxpZ25tZW50KGRbMF0pID8gMiA6IDMpLmV2ZXJ5KHYgPT4gdiA8PSAwKSk7XG4gICAgICBjb25zdCByZXNldFBsYWNlbWVudCA9ICgoX3BsYWNlbWVudHNUaGF0Rml0T25FID0gcGxhY2VtZW50c1RoYXRGaXRPbkVhY2hTaWRlWzBdKSA9PSBudWxsID8gdm9pZCAwIDogX3BsYWNlbWVudHNUaGF0Rml0T25FWzBdKSB8fCBwbGFjZW1lbnRzU29ydGVkQnlNb3N0U3BhY2VbMF1bMF07XG4gICAgICBpZiAocmVzZXRQbGFjZW1lbnQgIT09IHBsYWNlbWVudCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgIGluZGV4OiBjdXJyZW50SW5kZXggKyAxLFxuICAgICAgICAgICAgb3ZlcmZsb3dzOiBhbGxPdmVyZmxvd3NcbiAgICAgICAgICB9LFxuICAgICAgICAgIHJlc2V0OiB7XG4gICAgICAgICAgICBwbGFjZW1lbnQ6IHJlc2V0UGxhY2VtZW50XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgfTtcbn07XG5cbi8qKlxuICogT3B0aW1pemVzIHRoZSB2aXNpYmlsaXR5IG9mIHRoZSBmbG9hdGluZyBlbGVtZW50IGJ5IGZsaXBwaW5nIHRoZSBgcGxhY2VtZW50YFxuICogaW4gb3JkZXIgdG8ga2VlcCBpdCBpbiB2aWV3IHdoZW4gdGhlIHByZWZlcnJlZCBwbGFjZW1lbnQocykgd2lsbCBvdmVyZmxvdyB0aGVcbiAqIGNsaXBwaW5nIGJvdW5kYXJ5LiBBbHRlcm5hdGl2ZSB0byBgYXV0b1BsYWNlbWVudGAuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvZmxpcFxuICovXG5jb25zdCBmbGlwID0gZnVuY3Rpb24gKG9wdGlvbnMpIHtcbiAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkge1xuICAgIG9wdGlvbnMgPSB7fTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG5hbWU6ICdmbGlwJyxcbiAgICBvcHRpb25zLFxuICAgIGFzeW5jIGZuKHN0YXRlKSB7XG4gICAgICB2YXIgX21pZGRsZXdhcmVEYXRhJGFycm93LCBfbWlkZGxld2FyZURhdGEkZmxpcDtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgcGxhY2VtZW50LFxuICAgICAgICBtaWRkbGV3YXJlRGF0YSxcbiAgICAgICAgcmVjdHMsXG4gICAgICAgIGluaXRpYWxQbGFjZW1lbnQsXG4gICAgICAgIHBsYXRmb3JtLFxuICAgICAgICBlbGVtZW50c1xuICAgICAgfSA9IHN0YXRlO1xuICAgICAgY29uc3Qge1xuICAgICAgICBtYWluQXhpczogY2hlY2tNYWluQXhpcyA9IHRydWUsXG4gICAgICAgIGNyb3NzQXhpczogY2hlY2tDcm9zc0F4aXMgPSB0cnVlLFxuICAgICAgICBmYWxsYmFja1BsYWNlbWVudHM6IHNwZWNpZmllZEZhbGxiYWNrUGxhY2VtZW50cyxcbiAgICAgICAgZmFsbGJhY2tTdHJhdGVneSA9ICdiZXN0Rml0JyxcbiAgICAgICAgZmFsbGJhY2tBeGlzU2lkZURpcmVjdGlvbiA9ICdub25lJyxcbiAgICAgICAgZmxpcEFsaWdubWVudCA9IHRydWUsXG4gICAgICAgIC4uLmRldGVjdE92ZXJmbG93T3B0aW9uc1xuICAgICAgfSA9IGV2YWx1YXRlKG9wdGlvbnMsIHN0YXRlKTtcblxuICAgICAgLy8gSWYgYSByZXNldCBieSB0aGUgYXJyb3cgd2FzIGNhdXNlZCBkdWUgdG8gYW4gYWxpZ25tZW50IG9mZnNldCBiZWluZ1xuICAgICAgLy8gYWRkZWQsIHdlIHNob3VsZCBza2lwIGFueSBsb2dpYyBub3cgc2luY2UgYGZsaXAoKWAgaGFzIGFscmVhZHkgZG9uZSBpdHNcbiAgICAgIC8vIHdvcmsuXG4gICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vZmxvYXRpbmctdWkvZmxvYXRpbmctdWkvaXNzdWVzLzI1NDkjaXNzdWVjb21tZW50LTE3MTk2MDE2NDNcbiAgICAgIGlmICgoX21pZGRsZXdhcmVEYXRhJGFycm93ID0gbWlkZGxld2FyZURhdGEuYXJyb3cpICE9IG51bGwgJiYgX21pZGRsZXdhcmVEYXRhJGFycm93LmFsaWdubWVudE9mZnNldCkge1xuICAgICAgICByZXR1cm4ge307XG4gICAgICB9XG4gICAgICBjb25zdCBzaWRlID0gZ2V0U2lkZShwbGFjZW1lbnQpO1xuICAgICAgY29uc3QgaW5pdGlhbFNpZGVBeGlzID0gZ2V0U2lkZUF4aXMoaW5pdGlhbFBsYWNlbWVudCk7XG4gICAgICBjb25zdCBpc0Jhc2VQbGFjZW1lbnQgPSBnZXRTaWRlKGluaXRpYWxQbGFjZW1lbnQpID09PSBpbml0aWFsUGxhY2VtZW50O1xuICAgICAgY29uc3QgcnRsID0gYXdhaXQgKHBsYXRmb3JtLmlzUlRMID09IG51bGwgPyB2b2lkIDAgOiBwbGF0Zm9ybS5pc1JUTChlbGVtZW50cy5mbG9hdGluZykpO1xuICAgICAgY29uc3QgZmFsbGJhY2tQbGFjZW1lbnRzID0gc3BlY2lmaWVkRmFsbGJhY2tQbGFjZW1lbnRzIHx8IChpc0Jhc2VQbGFjZW1lbnQgfHwgIWZsaXBBbGlnbm1lbnQgPyBbZ2V0T3Bwb3NpdGVQbGFjZW1lbnQoaW5pdGlhbFBsYWNlbWVudCldIDogZ2V0RXhwYW5kZWRQbGFjZW1lbnRzKGluaXRpYWxQbGFjZW1lbnQpKTtcbiAgICAgIGNvbnN0IGhhc0ZhbGxiYWNrQXhpc1NpZGVEaXJlY3Rpb24gPSBmYWxsYmFja0F4aXNTaWRlRGlyZWN0aW9uICE9PSAnbm9uZSc7XG4gICAgICBpZiAoIXNwZWNpZmllZEZhbGxiYWNrUGxhY2VtZW50cyAmJiBoYXNGYWxsYmFja0F4aXNTaWRlRGlyZWN0aW9uKSB7XG4gICAgICAgIGZhbGxiYWNrUGxhY2VtZW50cy5wdXNoKC4uLmdldE9wcG9zaXRlQXhpc1BsYWNlbWVudHMoaW5pdGlhbFBsYWNlbWVudCwgZmxpcEFsaWdubWVudCwgZmFsbGJhY2tBeGlzU2lkZURpcmVjdGlvbiwgcnRsKSk7XG4gICAgICB9XG4gICAgICBjb25zdCBwbGFjZW1lbnRzID0gW2luaXRpYWxQbGFjZW1lbnQsIC4uLmZhbGxiYWNrUGxhY2VtZW50c107XG4gICAgICBjb25zdCBvdmVyZmxvdyA9IGF3YWl0IHBsYXRmb3JtLmRldGVjdE92ZXJmbG93KHN0YXRlLCBkZXRlY3RPdmVyZmxvd09wdGlvbnMpO1xuICAgICAgY29uc3Qgb3ZlcmZsb3dzID0gW107XG4gICAgICBsZXQgb3ZlcmZsb3dzRGF0YSA9ICgoX21pZGRsZXdhcmVEYXRhJGZsaXAgPSBtaWRkbGV3YXJlRGF0YS5mbGlwKSA9PSBudWxsID8gdm9pZCAwIDogX21pZGRsZXdhcmVEYXRhJGZsaXAub3ZlcmZsb3dzKSB8fCBbXTtcbiAgICAgIGlmIChjaGVja01haW5BeGlzKSB7XG4gICAgICAgIG92ZXJmbG93cy5wdXNoKG92ZXJmbG93W3NpZGVdKTtcbiAgICAgIH1cbiAgICAgIGlmIChjaGVja0Nyb3NzQXhpcykge1xuICAgICAgICBjb25zdCBzaWRlcyA9IGdldEFsaWdubWVudFNpZGVzKHBsYWNlbWVudCwgcmVjdHMsIHJ0bCk7XG4gICAgICAgIG92ZXJmbG93cy5wdXNoKG92ZXJmbG93W3NpZGVzWzBdXSwgb3ZlcmZsb3dbc2lkZXNbMV1dKTtcbiAgICAgIH1cbiAgICAgIG92ZXJmbG93c0RhdGEgPSBbLi4ub3ZlcmZsb3dzRGF0YSwge1xuICAgICAgICBwbGFjZW1lbnQsXG4gICAgICAgIG92ZXJmbG93c1xuICAgICAgfV07XG5cbiAgICAgIC8vIE9uZSBvciBtb3JlIHNpZGVzIGlzIG92ZXJmbG93aW5nLlxuICAgICAgaWYgKCFvdmVyZmxvd3MuZXZlcnkoc2lkZSA9PiBzaWRlIDw9IDApKSB7XG4gICAgICAgIHZhciBfbWlkZGxld2FyZURhdGEkZmxpcDIsIF9vdmVyZmxvd3NEYXRhJGZpbHRlcjtcbiAgICAgICAgY29uc3QgbmV4dEluZGV4ID0gKCgoX21pZGRsZXdhcmVEYXRhJGZsaXAyID0gbWlkZGxld2FyZURhdGEuZmxpcCkgPT0gbnVsbCA/IHZvaWQgMCA6IF9taWRkbGV3YXJlRGF0YSRmbGlwMi5pbmRleCkgfHwgMCkgKyAxO1xuICAgICAgICBjb25zdCBuZXh0UGxhY2VtZW50ID0gcGxhY2VtZW50c1tuZXh0SW5kZXhdO1xuICAgICAgICBpZiAobmV4dFBsYWNlbWVudCkge1xuICAgICAgICAgIGNvbnN0IGlnbm9yZUNyb3NzQXhpc092ZXJmbG93ID0gY2hlY2tDcm9zc0F4aXMgPT09ICdhbGlnbm1lbnQnID8gaW5pdGlhbFNpZGVBeGlzICE9PSBnZXRTaWRlQXhpcyhuZXh0UGxhY2VtZW50KSA6IGZhbHNlO1xuICAgICAgICAgIGlmICghaWdub3JlQ3Jvc3NBeGlzT3ZlcmZsb3cgfHxcbiAgICAgICAgICAvLyBXZSBsZWF2ZSB0aGUgY3VycmVudCBtYWluIGF4aXMgb25seSBpZiBldmVyeSBwbGFjZW1lbnQgb24gdGhhdCBheGlzXG4gICAgICAgICAgLy8gb3ZlcmZsb3dzIHRoZSBtYWluIGF4aXMuXG4gICAgICAgICAgb3ZlcmZsb3dzRGF0YS5ldmVyeShkID0+IGdldFNpZGVBeGlzKGQucGxhY2VtZW50KSA9PT0gaW5pdGlhbFNpZGVBeGlzID8gZC5vdmVyZmxvd3NbMF0gPiAwIDogdHJ1ZSkpIHtcbiAgICAgICAgICAgIC8vIFRyeSBuZXh0IHBsYWNlbWVudCBhbmQgcmUtcnVuIHRoZSBsaWZlY3ljbGUuXG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgICAgICAgaW5kZXg6IG5leHRJbmRleCxcbiAgICAgICAgICAgICAgICBvdmVyZmxvd3M6IG92ZXJmbG93c0RhdGFcbiAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgcmVzZXQ6IHtcbiAgICAgICAgICAgICAgICBwbGFjZW1lbnQ6IG5leHRQbGFjZW1lbnRcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICAvLyBGaXJzdCwgZmluZCB0aGUgY2FuZGlkYXRlcyB0aGF0IGZpdCBvbiB0aGUgbWFpbkF4aXMgc2lkZSBvZiBvdmVyZmxvdyxcbiAgICAgICAgLy8gdGhlbiBmaW5kIHRoZSBwbGFjZW1lbnQgdGhhdCBmaXRzIHRoZSBiZXN0IG9uIHRoZSBtYWluIGNyb3NzQXhpcyBzaWRlLlxuICAgICAgICBsZXQgcmVzZXRQbGFjZW1lbnQgPSAoX292ZXJmbG93c0RhdGEkZmlsdGVyID0gb3ZlcmZsb3dzRGF0YS5maWx0ZXIoZCA9PiBkLm92ZXJmbG93c1swXSA8PSAwKS5zb3J0KChhLCBiKSA9PiBhLm92ZXJmbG93c1sxXSAtIGIub3ZlcmZsb3dzWzFdKVswXSkgPT0gbnVsbCA/IHZvaWQgMCA6IF9vdmVyZmxvd3NEYXRhJGZpbHRlci5wbGFjZW1lbnQ7XG5cbiAgICAgICAgLy8gT3RoZXJ3aXNlIGZhbGxiYWNrLlxuICAgICAgICBpZiAoIXJlc2V0UGxhY2VtZW50KSB7XG4gICAgICAgICAgc3dpdGNoIChmYWxsYmFja1N0cmF0ZWd5KSB7XG4gICAgICAgICAgICBjYXNlICdiZXN0Rml0JzpcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHZhciBfb3ZlcmZsb3dzRGF0YSRmaWx0ZXIyO1xuICAgICAgICAgICAgICAgIGNvbnN0IHBsYWNlbWVudCA9IChfb3ZlcmZsb3dzRGF0YSRmaWx0ZXIyID0gb3ZlcmZsb3dzRGF0YS5maWx0ZXIoZCA9PiB7XG4gICAgICAgICAgICAgICAgICBpZiAoaGFzRmFsbGJhY2tBeGlzU2lkZURpcmVjdGlvbikge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBjdXJyZW50U2lkZUF4aXMgPSBnZXRTaWRlQXhpcyhkLnBsYWNlbWVudCk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBjdXJyZW50U2lkZUF4aXMgPT09IGluaXRpYWxTaWRlQXhpcyB8fFxuICAgICAgICAgICAgICAgICAgICAvLyBDcmVhdGUgYSBiaWFzIHRvIHRoZSBgeWAgc2lkZSBheGlzIGR1ZSB0byBob3Jpem9udGFsXG4gICAgICAgICAgICAgICAgICAgIC8vIHJlYWRpbmcgZGlyZWN0aW9ucyBmYXZvcmluZyBncmVhdGVyIHdpZHRoLlxuICAgICAgICAgICAgICAgICAgICBjdXJyZW50U2lkZUF4aXMgPT09ICd5JztcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgIH0pLm1hcChkID0+IFtkLnBsYWNlbWVudCwgZC5vdmVyZmxvd3MuZmlsdGVyKG92ZXJmbG93ID0+IG92ZXJmbG93ID4gMCkucmVkdWNlKChhY2MsIG92ZXJmbG93KSA9PiBhY2MgKyBvdmVyZmxvdywgMCldKS5zb3J0KChhLCBiKSA9PiBhWzFdIC0gYlsxXSlbMF0pID09IG51bGwgPyB2b2lkIDAgOiBfb3ZlcmZsb3dzRGF0YSRmaWx0ZXIyWzBdO1xuICAgICAgICAgICAgICAgIGlmIChwbGFjZW1lbnQpIHtcbiAgICAgICAgICAgICAgICAgIHJlc2V0UGxhY2VtZW50ID0gcGxhY2VtZW50O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2FzZSAnaW5pdGlhbFBsYWNlbWVudCc6XG4gICAgICAgICAgICAgIHJlc2V0UGxhY2VtZW50ID0gaW5pdGlhbFBsYWNlbWVudDtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChwbGFjZW1lbnQgIT09IHJlc2V0UGxhY2VtZW50KSB7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHJlc2V0OiB7XG4gICAgICAgICAgICAgIHBsYWNlbWVudDogcmVzZXRQbGFjZW1lbnRcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuICB9O1xufTtcblxuZnVuY3Rpb24gZ2V0U2lkZU9mZnNldHMob3ZlcmZsb3csIHJlY3QpIHtcbiAgcmV0dXJuIHtcbiAgICB0b3A6IG92ZXJmbG93LnRvcCAtIHJlY3QuaGVpZ2h0LFxuICAgIHJpZ2h0OiBvdmVyZmxvdy5yaWdodCAtIHJlY3Qud2lkdGgsXG4gICAgYm90dG9tOiBvdmVyZmxvdy5ib3R0b20gLSByZWN0LmhlaWdodCxcbiAgICBsZWZ0OiBvdmVyZmxvdy5sZWZ0IC0gcmVjdC53aWR0aFxuICB9O1xufVxuZnVuY3Rpb24gaXNBbnlTaWRlRnVsbHlDbGlwcGVkKG92ZXJmbG93KSB7XG4gIHJldHVybiBzaWRlcy5zb21lKHNpZGUgPT4gb3ZlcmZsb3dbc2lkZV0gPj0gMCk7XG59XG4vKipcbiAqIFByb3ZpZGVzIGRhdGEgdG8gaGlkZSB0aGUgZmxvYXRpbmcgZWxlbWVudCBpbiBhcHBsaWNhYmxlIHNpdHVhdGlvbnMsIHN1Y2ggYXNcbiAqIHdoZW4gaXQgaXMgbm90IGluIHRoZSBzYW1lIGNsaXBwaW5nIGNvbnRleHQgYXMgdGhlIHJlZmVyZW5jZSBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2hpZGVcbiAqL1xuY29uc3QgaGlkZSA9IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBuYW1lOiAnaGlkZScsXG4gICAgb3B0aW9ucyxcbiAgICBhc3luYyBmbihzdGF0ZSkge1xuICAgICAgY29uc3Qge1xuICAgICAgICByZWN0cyxcbiAgICAgICAgcGxhdGZvcm1cbiAgICAgIH0gPSBzdGF0ZTtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgc3RyYXRlZ3kgPSAncmVmZXJlbmNlSGlkZGVuJyxcbiAgICAgICAgLi4uZGV0ZWN0T3ZlcmZsb3dPcHRpb25zXG4gICAgICB9ID0gZXZhbHVhdGUob3B0aW9ucywgc3RhdGUpO1xuICAgICAgc3dpdGNoIChzdHJhdGVneSkge1xuICAgICAgICBjYXNlICdyZWZlcmVuY2VIaWRkZW4nOlxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGNvbnN0IG92ZXJmbG93ID0gYXdhaXQgcGxhdGZvcm0uZGV0ZWN0T3ZlcmZsb3coc3RhdGUsIHtcbiAgICAgICAgICAgICAgLi4uZGV0ZWN0T3ZlcmZsb3dPcHRpb25zLFxuICAgICAgICAgICAgICBlbGVtZW50Q29udGV4dDogJ3JlZmVyZW5jZSdcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgY29uc3Qgb2Zmc2V0cyA9IGdldFNpZGVPZmZzZXRzKG92ZXJmbG93LCByZWN0cy5yZWZlcmVuY2UpO1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgIHJlZmVyZW5jZUhpZGRlbk9mZnNldHM6IG9mZnNldHMsXG4gICAgICAgICAgICAgICAgcmVmZXJlbmNlSGlkZGVuOiBpc0FueVNpZGVGdWxseUNsaXBwZWQob2Zmc2V0cylcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9XG4gICAgICAgIGNhc2UgJ2VzY2FwZWQnOlxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGNvbnN0IG92ZXJmbG93ID0gYXdhaXQgcGxhdGZvcm0uZGV0ZWN0T3ZlcmZsb3coc3RhdGUsIHtcbiAgICAgICAgICAgICAgLi4uZGV0ZWN0T3ZlcmZsb3dPcHRpb25zLFxuICAgICAgICAgICAgICBhbHRCb3VuZGFyeTogdHJ1ZVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBjb25zdCBvZmZzZXRzID0gZ2V0U2lkZU9mZnNldHMob3ZlcmZsb3csIHJlY3RzLmZsb2F0aW5nKTtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICBlc2NhcGVkT2Zmc2V0czogb2Zmc2V0cyxcbiAgICAgICAgICAgICAgICBlc2NhcGVkOiBpc0FueVNpZGVGdWxseUNsaXBwZWQob2Zmc2V0cylcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAge1xuICAgICAgICAgICAgcmV0dXJuIHt9O1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH07XG59O1xuXG5mdW5jdGlvbiBnZXRCb3VuZGluZ1JlY3QocmVjdHMpIHtcbiAgY29uc3QgbWluWCA9IG1pbiguLi5yZWN0cy5tYXAocmVjdCA9PiByZWN0LmxlZnQpKTtcbiAgY29uc3QgbWluWSA9IG1pbiguLi5yZWN0cy5tYXAocmVjdCA9PiByZWN0LnRvcCkpO1xuICBjb25zdCBtYXhYID0gbWF4KC4uLnJlY3RzLm1hcChyZWN0ID0+IHJlY3QucmlnaHQpKTtcbiAgY29uc3QgbWF4WSA9IG1heCguLi5yZWN0cy5tYXAocmVjdCA9PiByZWN0LmJvdHRvbSkpO1xuICByZXR1cm4ge1xuICAgIHg6IG1pblgsXG4gICAgeTogbWluWSxcbiAgICB3aWR0aDogbWF4WCAtIG1pblgsXG4gICAgaGVpZ2h0OiBtYXhZIC0gbWluWVxuICB9O1xufVxuZnVuY3Rpb24gZ2V0UmVjdHNCeUxpbmUocmVjdHMpIHtcbiAgY29uc3Qgc29ydGVkUmVjdHMgPSByZWN0cy5zbGljZSgpLnNvcnQoKGEsIGIpID0+IGEueSAtIGIueSk7XG4gIGNvbnN0IGdyb3VwcyA9IFtdO1xuICBsZXQgcHJldlJlY3QgPSBudWxsO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IHNvcnRlZFJlY3RzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgcmVjdCA9IHNvcnRlZFJlY3RzW2ldO1xuICAgIGlmICghcHJldlJlY3QgfHwgcmVjdC55IC0gcHJldlJlY3QueSA+IHByZXZSZWN0LmhlaWdodCAvIDIpIHtcbiAgICAgIGdyb3Vwcy5wdXNoKFtyZWN0XSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGdyb3Vwc1tncm91cHMubGVuZ3RoIC0gMV0ucHVzaChyZWN0KTtcbiAgICB9XG4gICAgcHJldlJlY3QgPSByZWN0O1xuICB9XG4gIHJldHVybiBncm91cHMubWFwKHJlY3QgPT4gcmVjdFRvQ2xpZW50UmVjdChnZXRCb3VuZGluZ1JlY3QocmVjdCkpKTtcbn1cbi8qKlxuICogUHJvdmlkZXMgaW1wcm92ZWQgcG9zaXRpb25pbmcgZm9yIGlubGluZSByZWZlcmVuY2UgZWxlbWVudHMgdGhhdCBjYW4gc3BhblxuICogb3ZlciBtdWx0aXBsZSBsaW5lcywgc3VjaCBhcyBoeXBlcmxpbmtzIG9yIHJhbmdlIHNlbGVjdGlvbnMuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvaW5saW5lXG4gKi9cbmNvbnN0IGlubGluZSA9IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBuYW1lOiAnaW5saW5lJyxcbiAgICBvcHRpb25zLFxuICAgIGFzeW5jIGZuKHN0YXRlKSB7XG4gICAgICBjb25zdCB7XG4gICAgICAgIHBsYWNlbWVudCxcbiAgICAgICAgZWxlbWVudHMsXG4gICAgICAgIHJlY3RzLFxuICAgICAgICBwbGF0Zm9ybSxcbiAgICAgICAgc3RyYXRlZ3lcbiAgICAgIH0gPSBzdGF0ZTtcbiAgICAgIC8vIEEgTW91c2VFdmVudCdzIGNsaWVudHtYLFl9IGNvb3JkcyBjYW4gYmUgdXAgdG8gMiBwaXhlbHMgb2ZmIGFcbiAgICAgIC8vIENsaWVudFJlY3QncyBib3VuZHMsIGRlc3BpdGUgdGhlIGV2ZW50IGxpc3RlbmVyIGJlaW5nIHRyaWdnZXJlZC4gQVxuICAgICAgLy8gcGFkZGluZyBvZiAyIHNlZW1zIHRvIGhhbmRsZSB0aGlzIGlzc3VlLlxuICAgICAgY29uc3Qge1xuICAgICAgICBwYWRkaW5nID0gMixcbiAgICAgICAgeCxcbiAgICAgICAgeVxuICAgICAgfSA9IGV2YWx1YXRlKG9wdGlvbnMsIHN0YXRlKTtcbiAgICAgIGNvbnN0IG5hdGl2ZUNsaWVudFJlY3RzID0gQXJyYXkuZnJvbSgoYXdhaXQgKHBsYXRmb3JtLmdldENsaWVudFJlY3RzID09IG51bGwgPyB2b2lkIDAgOiBwbGF0Zm9ybS5nZXRDbGllbnRSZWN0cyhlbGVtZW50cy5yZWZlcmVuY2UpKSkgfHwgW10pO1xuXG4gICAgICAvLyBObyByZWN0cyAoZS5nLiBhIGhpZGRlbiBvciBkZXRhY2hlZCByZWZlcmVuY2UsIG9yIGEgY29sbGFwc2VkIHJhbmdlKSDigJRcbiAgICAgIC8vIGtlZXAgdGhlIGV4aXN0aW5nIHJlZmVyZW5jZSByZWN0IHJhdGhlciB0aGFuIHJlc2V0dGluZyB0byBhbiBpbnZhbGlkXG4gICAgICAvLyBvbmUgd2l0aCBub24tZmluaXRlIHZhbHVlcy5cbiAgICAgIGlmICghbmF0aXZlQ2xpZW50UmVjdHMubGVuZ3RoKSB7XG4gICAgICAgIHJldHVybiB7fTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGNsaWVudFJlY3RzID0gZ2V0UmVjdHNCeUxpbmUobmF0aXZlQ2xpZW50UmVjdHMpO1xuICAgICAgY29uc3QgZmFsbGJhY2sgPSByZWN0VG9DbGllbnRSZWN0KGdldEJvdW5kaW5nUmVjdChuYXRpdmVDbGllbnRSZWN0cykpO1xuICAgICAgY29uc3QgcGFkZGluZ09iamVjdCA9IGdldFBhZGRpbmdPYmplY3QocGFkZGluZyk7XG4gICAgICBmdW5jdGlvbiBnZXRCb3VuZGluZ0NsaWVudFJlY3QoKSB7XG4gICAgICAgIC8vIFRoZXJlIGFyZSB0d28gcmVjdHMgYW5kIHRoZXkgYXJlIGRpc2pvaW5lZC5cbiAgICAgICAgaWYgKGNsaWVudFJlY3RzLmxlbmd0aCA9PT0gMiAmJiAoY2xpZW50UmVjdHNbMF0ubGVmdCA+IGNsaWVudFJlY3RzWzFdLnJpZ2h0IHx8IGNsaWVudFJlY3RzWzFdLmxlZnQgPiBjbGllbnRSZWN0c1swXS5yaWdodCkgJiYgeCAhPSBudWxsICYmIHkgIT0gbnVsbCkge1xuICAgICAgICAgIC8vIEZpbmQgdGhlIGZpcnN0IHJlY3QgaW4gd2hpY2ggdGhlIHBvaW50IGlzIGZ1bGx5IGluc2lkZS5cbiAgICAgICAgICByZXR1cm4gY2xpZW50UmVjdHMuZmluZChyZWN0ID0+IHggPiByZWN0LmxlZnQgLSBwYWRkaW5nT2JqZWN0LmxlZnQgJiYgeCA8IHJlY3QucmlnaHQgKyBwYWRkaW5nT2JqZWN0LnJpZ2h0ICYmIHkgPiByZWN0LnRvcCAtIHBhZGRpbmdPYmplY3QudG9wICYmIHkgPCByZWN0LmJvdHRvbSArIHBhZGRpbmdPYmplY3QuYm90dG9tKSB8fCBmYWxsYmFjaztcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFRoZXJlIGFyZSAyIG9yIG1vcmUgY29ubmVjdGVkIHJlY3RzLlxuICAgICAgICBpZiAoY2xpZW50UmVjdHMubGVuZ3RoID49IDIpIHtcbiAgICAgICAgICBpZiAoZ2V0U2lkZUF4aXMocGxhY2VtZW50KSA9PT0gJ3knKSB7XG4gICAgICAgICAgICBjb25zdCBmaXJzdFJlY3QgPSBjbGllbnRSZWN0c1swXTtcbiAgICAgICAgICAgIGNvbnN0IGxhc3RSZWN0ID0gY2xpZW50UmVjdHNbY2xpZW50UmVjdHMubGVuZ3RoIC0gMV07XG4gICAgICAgICAgICBjb25zdCBpc1RvcCA9IGdldFNpZGUocGxhY2VtZW50KSA9PT0gJ3RvcCc7XG4gICAgICAgICAgICBjb25zdCB0b3AgPSBmaXJzdFJlY3QudG9wO1xuICAgICAgICAgICAgY29uc3QgYm90dG9tID0gbGFzdFJlY3QuYm90dG9tO1xuICAgICAgICAgICAgY29uc3QgbGVmdCA9IGlzVG9wID8gZmlyc3RSZWN0LmxlZnQgOiBsYXN0UmVjdC5sZWZ0O1xuICAgICAgICAgICAgY29uc3QgcmlnaHQgPSBpc1RvcCA/IGZpcnN0UmVjdC5yaWdodCA6IGxhc3RSZWN0LnJpZ2h0O1xuICAgICAgICAgICAgcmV0dXJuIHJlY3RUb0NsaWVudFJlY3Qoe1xuICAgICAgICAgICAgICB4OiBsZWZ0LFxuICAgICAgICAgICAgICB5OiB0b3AsXG4gICAgICAgICAgICAgIHdpZHRoOiByaWdodCAtIGxlZnQsXG4gICAgICAgICAgICAgIGhlaWdodDogYm90dG9tIC0gdG9wXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgaXNMZWZ0U2lkZSA9IGdldFNpZGUocGxhY2VtZW50KSA9PT0gJ2xlZnQnO1xuICAgICAgICAgIGNvbnN0IG1heFJpZ2h0ID0gbWF4KC4uLmNsaWVudFJlY3RzLm1hcChyZWN0ID0+IHJlY3QucmlnaHQpKTtcbiAgICAgICAgICBjb25zdCBtaW5MZWZ0ID0gbWluKC4uLmNsaWVudFJlY3RzLm1hcChyZWN0ID0+IHJlY3QubGVmdCkpO1xuICAgICAgICAgIGNvbnN0IG1lYXN1cmVSZWN0cyA9IGNsaWVudFJlY3RzLmZpbHRlcihyZWN0ID0+IGlzTGVmdFNpZGUgPyByZWN0LmxlZnQgPT09IG1pbkxlZnQgOiByZWN0LnJpZ2h0ID09PSBtYXhSaWdodCk7XG4gICAgICAgICAgY29uc3QgdG9wID0gbWVhc3VyZVJlY3RzWzBdLnRvcDtcbiAgICAgICAgICBjb25zdCBib3R0b20gPSBtZWFzdXJlUmVjdHNbbWVhc3VyZVJlY3RzLmxlbmd0aCAtIDFdLmJvdHRvbTtcbiAgICAgICAgICByZXR1cm4gcmVjdFRvQ2xpZW50UmVjdCh7XG4gICAgICAgICAgICB4OiBtaW5MZWZ0LFxuICAgICAgICAgICAgeTogdG9wLFxuICAgICAgICAgICAgd2lkdGg6IG1heFJpZ2h0IC0gbWluTGVmdCxcbiAgICAgICAgICAgIGhlaWdodDogYm90dG9tIC0gdG9wXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbGxiYWNrO1xuICAgICAgfVxuICAgICAgY29uc3QgcmVzZXRSZWN0cyA9IGF3YWl0IHBsYXRmb3JtLmdldEVsZW1lbnRSZWN0cyh7XG4gICAgICAgIHJlZmVyZW5jZToge1xuICAgICAgICAgIGdldEJvdW5kaW5nQ2xpZW50UmVjdFxuICAgICAgICB9LFxuICAgICAgICBmbG9hdGluZzogZWxlbWVudHMuZmxvYXRpbmcsXG4gICAgICAgIHN0cmF0ZWd5XG4gICAgICB9KTtcbiAgICAgIGlmIChyZWN0cy5yZWZlcmVuY2UueCAhPT0gcmVzZXRSZWN0cy5yZWZlcmVuY2UueCB8fCByZWN0cy5yZWZlcmVuY2UueSAhPT0gcmVzZXRSZWN0cy5yZWZlcmVuY2UueSB8fCByZWN0cy5yZWZlcmVuY2Uud2lkdGggIT09IHJlc2V0UmVjdHMucmVmZXJlbmNlLndpZHRoIHx8IHJlY3RzLnJlZmVyZW5jZS5oZWlnaHQgIT09IHJlc2V0UmVjdHMucmVmZXJlbmNlLmhlaWdodCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHJlc2V0OiB7XG4gICAgICAgICAgICByZWN0czogcmVzZXRSZWN0c1xuICAgICAgICAgIH1cbiAgICAgICAgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7fTtcbiAgICB9XG4gIH07XG59O1xuXG5jb25zdCBvcmlnaW5TaWRlcyA9IC8qI19fUFVSRV9fKi9uZXcgU2V0KFsnbGVmdCcsICd0b3AnXSk7XG5cbi8vIEZvciB0eXBlIGJhY2t3YXJkcy1jb21wYXRpYmlsaXR5LCB0aGUgYE9mZnNldE9wdGlvbnNgIHR5cGUgd2FzIGFsc29cbi8vIERlcml2YWJsZS5cblxuYXN5bmMgZnVuY3Rpb24gY29udmVydFZhbHVlVG9Db29yZHMoc3RhdGUsIG9wdGlvbnMpIHtcbiAgY29uc3Qge1xuICAgIHBsYWNlbWVudCxcbiAgICBwbGF0Zm9ybSxcbiAgICBlbGVtZW50c1xuICB9ID0gc3RhdGU7XG4gIGNvbnN0IHJ0bCA9IGF3YWl0IChwbGF0Zm9ybS5pc1JUTCA9PSBudWxsID8gdm9pZCAwIDogcGxhdGZvcm0uaXNSVEwoZWxlbWVudHMuZmxvYXRpbmcpKTtcbiAgY29uc3Qgc2lkZSA9IGdldFNpZGUocGxhY2VtZW50KTtcbiAgY29uc3QgYWxpZ25tZW50ID0gZ2V0QWxpZ25tZW50KHBsYWNlbWVudCk7XG4gIGNvbnN0IGlzVmVydGljYWwgPSBnZXRTaWRlQXhpcyhwbGFjZW1lbnQpID09PSAneSc7XG4gIGNvbnN0IG1haW5BeGlzTXVsdGkgPSBvcmlnaW5TaWRlcy5oYXMoc2lkZSkgPyAtMSA6IDE7XG4gIGNvbnN0IGNyb3NzQXhpc011bHRpID0gcnRsICYmIGlzVmVydGljYWwgPyAtMSA6IDE7XG4gIGNvbnN0IHJhd1ZhbHVlID0gZXZhbHVhdGUob3B0aW9ucywgc3RhdGUpO1xuXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBwcmVmZXItY29uc3RcbiAgbGV0IHtcbiAgICBtYWluQXhpcyxcbiAgICBjcm9zc0F4aXMsXG4gICAgYWxpZ25tZW50QXhpc1xuICB9ID0gdHlwZW9mIHJhd1ZhbHVlID09PSAnbnVtYmVyJyA/IHtcbiAgICBtYWluQXhpczogcmF3VmFsdWUsXG4gICAgY3Jvc3NBeGlzOiAwLFxuICAgIGFsaWdubWVudEF4aXM6IG51bGxcbiAgfSA6IHtcbiAgICBtYWluQXhpczogcmF3VmFsdWUubWFpbkF4aXMgfHwgMCxcbiAgICBjcm9zc0F4aXM6IHJhd1ZhbHVlLmNyb3NzQXhpcyB8fCAwLFxuICAgIGFsaWdubWVudEF4aXM6IHJhd1ZhbHVlLmFsaWdubWVudEF4aXNcbiAgfTtcbiAgaWYgKGFsaWdubWVudCAmJiB0eXBlb2YgYWxpZ25tZW50QXhpcyA9PT0gJ251bWJlcicpIHtcbiAgICBjcm9zc0F4aXMgPSBhbGlnbm1lbnQgPT09ICdlbmQnID8gYWxpZ25tZW50QXhpcyAqIC0xIDogYWxpZ25tZW50QXhpcztcbiAgfVxuICByZXR1cm4gaXNWZXJ0aWNhbCA/IHtcbiAgICB4OiBjcm9zc0F4aXMgKiBjcm9zc0F4aXNNdWx0aSxcbiAgICB5OiBtYWluQXhpcyAqIG1haW5BeGlzTXVsdGlcbiAgfSA6IHtcbiAgICB4OiBtYWluQXhpcyAqIG1haW5BeGlzTXVsdGksXG4gICAgeTogY3Jvc3NBeGlzICogY3Jvc3NBeGlzTXVsdGlcbiAgfTtcbn1cblxuLyoqXG4gKiBNb2RpZmllcyB0aGUgcGxhY2VtZW50IGJ5IHRyYW5zbGF0aW5nIHRoZSBmbG9hdGluZyBlbGVtZW50IGFsb25nIHRoZVxuICogc3BlY2lmaWVkIGF4ZXMuXG4gKiBBIG51bWJlciAoc2hvcnRoYW5kIGZvciBgbWFpbkF4aXNgIG9yIGRpc3RhbmNlKSwgb3IgYW4gYXhlcyBjb25maWd1cmF0aW9uXG4gKiBvYmplY3QgbWF5IGJlIHBhc3NlZC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9vZmZzZXRcbiAqL1xuY29uc3Qgb2Zmc2V0ID0gZnVuY3Rpb24gKG9wdGlvbnMpIHtcbiAgaWYgKG9wdGlvbnMgPT09IHZvaWQgMCkge1xuICAgIG9wdGlvbnMgPSAwO1xuICB9XG4gIHJldHVybiB7XG4gICAgbmFtZTogJ29mZnNldCcsXG4gICAgb3B0aW9ucyxcbiAgICBhc3luYyBmbihzdGF0ZSkge1xuICAgICAgdmFyIF9taWRkbGV3YXJlRGF0YSRvZmZzZSwgX21pZGRsZXdhcmVEYXRhJGFycm93O1xuICAgICAgY29uc3Qge1xuICAgICAgICB4LFxuICAgICAgICB5LFxuICAgICAgICBwbGFjZW1lbnQsXG4gICAgICAgIG1pZGRsZXdhcmVEYXRhXG4gICAgICB9ID0gc3RhdGU7XG4gICAgICBjb25zdCBkaWZmQ29vcmRzID0gYXdhaXQgY29udmVydFZhbHVlVG9Db29yZHMoc3RhdGUsIG9wdGlvbnMpO1xuXG4gICAgICAvLyBJZiB0aGUgcGxhY2VtZW50IGlzIHRoZSBzYW1lIGFuZCB0aGUgYXJyb3cgY2F1c2VkIGFuIGFsaWdubWVudCBvZmZzZXRcbiAgICAgIC8vIHRoZW4gd2UgZG9uJ3QgbmVlZCB0byBjaGFuZ2UgdGhlIHBvc2l0aW9uaW5nIGNvb3JkaW5hdGVzLlxuICAgICAgaWYgKHBsYWNlbWVudCA9PT0gKChfbWlkZGxld2FyZURhdGEkb2Zmc2UgPSBtaWRkbGV3YXJlRGF0YS5vZmZzZXQpID09IG51bGwgPyB2b2lkIDAgOiBfbWlkZGxld2FyZURhdGEkb2Zmc2UucGxhY2VtZW50KSAmJiAoX21pZGRsZXdhcmVEYXRhJGFycm93ID0gbWlkZGxld2FyZURhdGEuYXJyb3cpICE9IG51bGwgJiYgX21pZGRsZXdhcmVEYXRhJGFycm93LmFsaWdubWVudE9mZnNldCkge1xuICAgICAgICByZXR1cm4ge307XG4gICAgICB9XG4gICAgICByZXR1cm4ge1xuICAgICAgICB4OiB4ICsgZGlmZkNvb3Jkcy54LFxuICAgICAgICB5OiB5ICsgZGlmZkNvb3Jkcy55LFxuICAgICAgICBkYXRhOiB7XG4gICAgICAgICAgLi4uZGlmZkNvb3JkcyxcbiAgICAgICAgICBwbGFjZW1lbnRcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9XG4gIH07XG59O1xuXG4vKipcbiAqIE9wdGltaXplcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBieSBzaGlmdGluZyBpdCBpbiBvcmRlciB0b1xuICoga2VlcCBpdCBpbiB2aWV3IHdoZW4gaXQgd2lsbCBvdmVyZmxvdyB0aGUgY2xpcHBpbmcgYm91bmRhcnkuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3Mvc2hpZnRcbiAqL1xuY29uc3Qgc2hpZnQgPSBmdW5jdGlvbiAob3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIHJldHVybiB7XG4gICAgbmFtZTogJ3NoaWZ0JyxcbiAgICBvcHRpb25zLFxuICAgIGFzeW5jIGZuKHN0YXRlKSB7XG4gICAgICBjb25zdCB7XG4gICAgICAgIHgsXG4gICAgICAgIHksXG4gICAgICAgIHBsYWNlbWVudCxcbiAgICAgICAgcGxhdGZvcm1cbiAgICAgIH0gPSBzdGF0ZTtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgbWFpbkF4aXM6IGNoZWNrTWFpbkF4aXMgPSB0cnVlLFxuICAgICAgICBjcm9zc0F4aXM6IGNoZWNrQ3Jvc3NBeGlzID0gZmFsc2UsXG4gICAgICAgIGxpbWl0ZXIgPSB7XG4gICAgICAgICAgZm46IF9yZWYgPT4ge1xuICAgICAgICAgICAgbGV0IHtcbiAgICAgICAgICAgICAgeCxcbiAgICAgICAgICAgICAgeVxuICAgICAgICAgICAgfSA9IF9yZWY7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICB4LFxuICAgICAgICAgICAgICB5XG4gICAgICAgICAgICB9O1xuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgLi4uZGV0ZWN0T3ZlcmZsb3dPcHRpb25zXG4gICAgICB9ID0gZXZhbHVhdGUob3B0aW9ucywgc3RhdGUpO1xuICAgICAgY29uc3QgY29vcmRzID0ge1xuICAgICAgICB4LFxuICAgICAgICB5XG4gICAgICB9O1xuICAgICAgY29uc3Qgb3ZlcmZsb3cgPSBhd2FpdCBwbGF0Zm9ybS5kZXRlY3RPdmVyZmxvdyhzdGF0ZSwgZGV0ZWN0T3ZlcmZsb3dPcHRpb25zKTtcbiAgICAgIGNvbnN0IGNyb3NzQXhpcyA9IGdldFNpZGVBeGlzKHBsYWNlbWVudCk7XG4gICAgICBjb25zdCBtYWluQXhpcyA9IGdldE9wcG9zaXRlQXhpcyhjcm9zc0F4aXMpO1xuICAgICAgbGV0IG1haW5BeGlzQ29vcmQgPSBjb29yZHNbbWFpbkF4aXNdO1xuICAgICAgbGV0IGNyb3NzQXhpc0Nvb3JkID0gY29vcmRzW2Nyb3NzQXhpc107XG4gICAgICBjb25zdCBjbGFtcENvb3JkID0gKGF4aXMsIGNvb3JkKSA9PiBjbGFtcChjb29yZCArIG92ZXJmbG93W2F4aXMgPT09ICd5JyA/ICd0b3AnIDogJ2xlZnQnXSwgY29vcmQsIGNvb3JkIC0gb3ZlcmZsb3dbYXhpcyA9PT0gJ3knID8gJ2JvdHRvbScgOiAncmlnaHQnXSk7XG4gICAgICBpZiAoY2hlY2tNYWluQXhpcykge1xuICAgICAgICBtYWluQXhpc0Nvb3JkID0gY2xhbXBDb29yZChtYWluQXhpcywgbWFpbkF4aXNDb29yZCk7XG4gICAgICB9XG4gICAgICBpZiAoY2hlY2tDcm9zc0F4aXMpIHtcbiAgICAgICAgY3Jvc3NBeGlzQ29vcmQgPSBjbGFtcENvb3JkKGNyb3NzQXhpcywgY3Jvc3NBeGlzQ29vcmQpO1xuICAgICAgfVxuICAgICAgY29uc3QgbGltaXRlZENvb3JkcyA9IGxpbWl0ZXIuZm4oe1xuICAgICAgICAuLi5zdGF0ZSxcbiAgICAgICAgW21haW5BeGlzXTogbWFpbkF4aXNDb29yZCxcbiAgICAgICAgW2Nyb3NzQXhpc106IGNyb3NzQXhpc0Nvb3JkXG4gICAgICB9KTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLmxpbWl0ZWRDb29yZHMsXG4gICAgICAgIGRhdGE6IHtcbiAgICAgICAgICB4OiBsaW1pdGVkQ29vcmRzLnggLSB4LFxuICAgICAgICAgIHk6IGxpbWl0ZWRDb29yZHMueSAtIHksXG4gICAgICAgICAgZW5hYmxlZDoge1xuICAgICAgICAgICAgW21haW5BeGlzXTogY2hlY2tNYWluQXhpcyxcbiAgICAgICAgICAgIFtjcm9zc0F4aXNdOiBjaGVja0Nyb3NzQXhpc1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfTtcbiAgICB9XG4gIH07XG59O1xuLyoqXG4gKiBCdWlsdC1pbiBgbGltaXRlcmAgdGhhdCB3aWxsIHN0b3AgYHNoaWZ0KClgIGF0IGEgY2VydGFpbiBwb2ludC5cbiAqL1xuY29uc3QgbGltaXRTaGlmdCA9IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBvcHRpb25zLFxuICAgIGZuKHN0YXRlKSB7XG4gICAgICB2YXIgX3Jhd09mZnNldCRtYWluQXhpcywgX3Jhd09mZnNldCRjcm9zc0F4aXM7XG4gICAgICBjb25zdCB7XG4gICAgICAgIHgsXG4gICAgICAgIHksXG4gICAgICAgIHBsYWNlbWVudCxcbiAgICAgICAgcmVjdHMsXG4gICAgICAgIG1pZGRsZXdhcmVEYXRhXG4gICAgICB9ID0gc3RhdGU7XG4gICAgICBjb25zdCB7XG4gICAgICAgIG9mZnNldCA9IDAsXG4gICAgICAgIG1haW5BeGlzOiBjaGVja01haW5BeGlzID0gdHJ1ZSxcbiAgICAgICAgY3Jvc3NBeGlzOiBjaGVja0Nyb3NzQXhpcyA9IHRydWVcbiAgICAgIH0gPSBldmFsdWF0ZShvcHRpb25zLCBzdGF0ZSk7XG4gICAgICBjb25zdCBjb29yZHMgPSB7XG4gICAgICAgIHgsXG4gICAgICAgIHlcbiAgICAgIH07XG4gICAgICBjb25zdCBjcm9zc0F4aXMgPSBnZXRTaWRlQXhpcyhwbGFjZW1lbnQpO1xuICAgICAgY29uc3QgbWFpbkF4aXMgPSBnZXRPcHBvc2l0ZUF4aXMoY3Jvc3NBeGlzKTtcbiAgICAgIGxldCBtYWluQXhpc0Nvb3JkID0gY29vcmRzW21haW5BeGlzXTtcbiAgICAgIGxldCBjcm9zc0F4aXNDb29yZCA9IGNvb3Jkc1tjcm9zc0F4aXNdO1xuICAgICAgY29uc3QgcmF3T2Zmc2V0ID0gZXZhbHVhdGUob2Zmc2V0LCBzdGF0ZSk7XG4gICAgICBjb25zdCBjb21wdXRlZE9mZnNldCA9IHR5cGVvZiByYXdPZmZzZXQgPT09ICdudW1iZXInID8ge1xuICAgICAgICBtYWluQXhpczogcmF3T2Zmc2V0LFxuICAgICAgICBjcm9zc0F4aXM6IDBcbiAgICAgIH0gOiB7XG4gICAgICAgIG1haW5BeGlzOiAoX3Jhd09mZnNldCRtYWluQXhpcyA9IHJhd09mZnNldC5tYWluQXhpcykgIT0gbnVsbCA/IF9yYXdPZmZzZXQkbWFpbkF4aXMgOiAwLFxuICAgICAgICBjcm9zc0F4aXM6IChfcmF3T2Zmc2V0JGNyb3NzQXhpcyA9IHJhd09mZnNldC5jcm9zc0F4aXMpICE9IG51bGwgPyBfcmF3T2Zmc2V0JGNyb3NzQXhpcyA6IDBcbiAgICAgIH07XG4gICAgICBpZiAoY2hlY2tNYWluQXhpcykge1xuICAgICAgICBjb25zdCBsZW4gPSBtYWluQXhpcyA9PT0gJ3knID8gJ2hlaWdodCcgOiAnd2lkdGgnO1xuICAgICAgICBjb25zdCBsaW1pdE1pbiA9IHJlY3RzLnJlZmVyZW5jZVttYWluQXhpc10gLSByZWN0cy5mbG9hdGluZ1tsZW5dICsgY29tcHV0ZWRPZmZzZXQubWFpbkF4aXM7XG4gICAgICAgIGNvbnN0IGxpbWl0TWF4ID0gcmVjdHMucmVmZXJlbmNlW21haW5BeGlzXSArIHJlY3RzLnJlZmVyZW5jZVtsZW5dIC0gY29tcHV0ZWRPZmZzZXQubWFpbkF4aXM7XG4gICAgICAgIGlmIChtYWluQXhpc0Nvb3JkIDwgbGltaXRNaW4pIHtcbiAgICAgICAgICBtYWluQXhpc0Nvb3JkID0gbGltaXRNaW47XG4gICAgICAgIH0gZWxzZSBpZiAobWFpbkF4aXNDb29yZCA+IGxpbWl0TWF4KSB7XG4gICAgICAgICAgbWFpbkF4aXNDb29yZCA9IGxpbWl0TWF4O1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBpZiAoY2hlY2tDcm9zc0F4aXMpIHtcbiAgICAgICAgdmFyIF9taWRkbGV3YXJlRGF0YSRvZmZzZSwgX21pZGRsZXdhcmVEYXRhJG9mZnNlMjtcbiAgICAgICAgY29uc3QgbGVuID0gbWFpbkF4aXMgPT09ICd5JyA/ICd3aWR0aCcgOiAnaGVpZ2h0JztcbiAgICAgICAgY29uc3QgaXNPcmlnaW5TaWRlID0gb3JpZ2luU2lkZXMuaGFzKGdldFNpZGUocGxhY2VtZW50KSk7XG4gICAgICAgIGNvbnN0IGxpbWl0TWluID0gcmVjdHMucmVmZXJlbmNlW2Nyb3NzQXhpc10gLSByZWN0cy5mbG9hdGluZ1tsZW5dICsgKGlzT3JpZ2luU2lkZSA/ICgoX21pZGRsZXdhcmVEYXRhJG9mZnNlID0gbWlkZGxld2FyZURhdGEub2Zmc2V0KSA9PSBudWxsID8gdm9pZCAwIDogX21pZGRsZXdhcmVEYXRhJG9mZnNlW2Nyb3NzQXhpc10pIHx8IDAgOiAwKSArIChpc09yaWdpblNpZGUgPyAwIDogY29tcHV0ZWRPZmZzZXQuY3Jvc3NBeGlzKTtcbiAgICAgICAgY29uc3QgbGltaXRNYXggPSByZWN0cy5yZWZlcmVuY2VbY3Jvc3NBeGlzXSArIHJlY3RzLnJlZmVyZW5jZVtsZW5dICsgKGlzT3JpZ2luU2lkZSA/IDAgOiAoKF9taWRkbGV3YXJlRGF0YSRvZmZzZTIgPSBtaWRkbGV3YXJlRGF0YS5vZmZzZXQpID09IG51bGwgPyB2b2lkIDAgOiBfbWlkZGxld2FyZURhdGEkb2Zmc2UyW2Nyb3NzQXhpc10pIHx8IDApIC0gKGlzT3JpZ2luU2lkZSA/IGNvbXB1dGVkT2Zmc2V0LmNyb3NzQXhpcyA6IDApO1xuICAgICAgICBpZiAoY3Jvc3NBeGlzQ29vcmQgPCBsaW1pdE1pbikge1xuICAgICAgICAgIGNyb3NzQXhpc0Nvb3JkID0gbGltaXRNaW47XG4gICAgICAgIH0gZWxzZSBpZiAoY3Jvc3NBeGlzQ29vcmQgPiBsaW1pdE1heCkge1xuICAgICAgICAgIGNyb3NzQXhpc0Nvb3JkID0gbGltaXRNYXg7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiB7XG4gICAgICAgIFttYWluQXhpc106IG1haW5BeGlzQ29vcmQsXG4gICAgICAgIFtjcm9zc0F4aXNdOiBjcm9zc0F4aXNDb29yZFxuICAgICAgfTtcbiAgICB9XG4gIH07XG59O1xuXG4vLyBNZXRob2Qgc3ludGF4IGtlZXBzIGNhbGxiYWNrIHBhcmFtZXRlcnMgYml2YXJpYW50LCBidXQgZXhwcmVzc2luZyB0aGVcbi8vIGV4cGxpY2l0IGB8IHVuZGVmaW5lZGAgcmVxdWlyZWQgYnkgYGV4YWN0T3B0aW9uYWxQcm9wZXJ0eVR5cGVzYCBuZWVkc1xuLy8gcHJvcGVydHkgc3ludGF4LCB3aGljaCBpcyBjb250cmF2YXJpYW50IHVuZGVyIGBzdHJpY3RGdW5jdGlvblR5cGVzYC5cbi8vIEV4dHJhY3RpbmcgdGhlIGZ1bmN0aW9uIGZyb20gYSBtZXRob2QgcG9zaXRpb24gcmVzdG9yZXMgdGhhdCBiaXZhcmlhbmNlIHNvXG4vLyBjb25zdW1lcnMgY2FuIHN0aWxsIGFzc2lnbiBjYWxsYmFja3Mgd2l0aCBuYXJyb3dlciBwYXJhbWV0ZXIgdHlwZXMuXG5cbi8qKlxuICogUHJvdmlkZXMgZGF0YSB0aGF0IGFsbG93cyB5b3UgdG8gY2hhbmdlIHRoZSBzaXplIG9mIHRoZSBmbG9hdGluZyBlbGVtZW50IOKAlFxuICogZm9yIGluc3RhbmNlLCBwcmV2ZW50IGl0IGZyb20gb3ZlcmZsb3dpbmcgdGhlIGNsaXBwaW5nIGJvdW5kYXJ5IG9yIG1hdGNoIHRoZVxuICogd2lkdGggb2YgdGhlIHJlZmVyZW5jZSBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL3NpemVcbiAqL1xuY29uc3Qgc2l6ZSA9IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgcmV0dXJuIHtcbiAgICBuYW1lOiAnc2l6ZScsXG4gICAgb3B0aW9ucyxcbiAgICBhc3luYyBmbihzdGF0ZSkge1xuICAgICAgY29uc3Qge1xuICAgICAgICBwbGFjZW1lbnQsXG4gICAgICAgIHJlY3RzLFxuICAgICAgICBwbGF0Zm9ybSxcbiAgICAgICAgZWxlbWVudHNcbiAgICAgIH0gPSBzdGF0ZTtcbiAgICAgIGNvbnN0IHtcbiAgICAgICAgYXBwbHkgPSAoKSA9PiB7fSxcbiAgICAgICAgLi4uZGV0ZWN0T3ZlcmZsb3dPcHRpb25zXG4gICAgICB9ID0gZXZhbHVhdGUob3B0aW9ucywgc3RhdGUpO1xuICAgICAgY29uc3Qgb3ZlcmZsb3cgPSBhd2FpdCBwbGF0Zm9ybS5kZXRlY3RPdmVyZmxvdyhzdGF0ZSwgZGV0ZWN0T3ZlcmZsb3dPcHRpb25zKTtcbiAgICAgIGNvbnN0IHNpZGUgPSBnZXRTaWRlKHBsYWNlbWVudCk7XG4gICAgICBjb25zdCBhbGlnbm1lbnQgPSBnZXRBbGlnbm1lbnQocGxhY2VtZW50KTtcbiAgICAgIGNvbnN0IGlzWUF4aXMgPSBnZXRTaWRlQXhpcyhwbGFjZW1lbnQpID09PSAneSc7XG4gICAgICBjb25zdCB7XG4gICAgICAgIHdpZHRoLFxuICAgICAgICBoZWlnaHRcbiAgICAgIH0gPSByZWN0cy5mbG9hdGluZztcbiAgICAgIGxldCBoZWlnaHRTaWRlO1xuICAgICAgbGV0IHdpZHRoU2lkZTtcbiAgICAgIGlmIChzaWRlID09PSAndG9wJyB8fCBzaWRlID09PSAnYm90dG9tJykge1xuICAgICAgICBoZWlnaHRTaWRlID0gc2lkZTtcbiAgICAgICAgd2lkdGhTaWRlID0gYWxpZ25tZW50ID09PSAoKGF3YWl0IChwbGF0Zm9ybS5pc1JUTCA9PSBudWxsID8gdm9pZCAwIDogcGxhdGZvcm0uaXNSVEwoZWxlbWVudHMuZmxvYXRpbmcpKSkgPyAnc3RhcnQnIDogJ2VuZCcpID8gJ2xlZnQnIDogJ3JpZ2h0JztcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHdpZHRoU2lkZSA9IHNpZGU7XG4gICAgICAgIGhlaWdodFNpZGUgPSBhbGlnbm1lbnQgPT09ICdlbmQnID8gJ3RvcCcgOiAnYm90dG9tJztcbiAgICAgIH1cbiAgICAgIGNvbnN0IG1heGltdW1DbGlwcGluZ0hlaWdodCA9IGhlaWdodCAtIG92ZXJmbG93LnRvcCAtIG92ZXJmbG93LmJvdHRvbTtcbiAgICAgIGNvbnN0IG1heGltdW1DbGlwcGluZ1dpZHRoID0gd2lkdGggLSBvdmVyZmxvdy5sZWZ0IC0gb3ZlcmZsb3cucmlnaHQ7XG4gICAgICBjb25zdCBvdmVyZmxvd0F2YWlsYWJsZUhlaWdodCA9IG1pbihoZWlnaHQgLSBvdmVyZmxvd1toZWlnaHRTaWRlXSwgbWF4aW11bUNsaXBwaW5nSGVpZ2h0KTtcbiAgICAgIGNvbnN0IG92ZXJmbG93QXZhaWxhYmxlV2lkdGggPSBtaW4od2lkdGggLSBvdmVyZmxvd1t3aWR0aFNpZGVdLCBtYXhpbXVtQ2xpcHBpbmdXaWR0aCk7XG4gICAgICBjb25zdCBzaGlmdERhdGEgPSBzdGF0ZS5taWRkbGV3YXJlRGF0YS5zaGlmdDtcbiAgICAgIGNvbnN0IG5vU2hpZnQgPSAhc2hpZnREYXRhO1xuICAgICAgbGV0IGF2YWlsYWJsZUhlaWdodCA9IG92ZXJmbG93QXZhaWxhYmxlSGVpZ2h0O1xuICAgICAgbGV0IGF2YWlsYWJsZVdpZHRoID0gb3ZlcmZsb3dBdmFpbGFibGVXaWR0aDtcbiAgICAgIGlmIChzaGlmdERhdGEgIT0gbnVsbCAmJiBzaGlmdERhdGEuZW5hYmxlZC54KSB7XG4gICAgICAgIGF2YWlsYWJsZVdpZHRoID0gbWF4aW11bUNsaXBwaW5nV2lkdGg7XG4gICAgICB9XG4gICAgICBpZiAoc2hpZnREYXRhICE9IG51bGwgJiYgc2hpZnREYXRhLmVuYWJsZWQueSkge1xuICAgICAgICBhdmFpbGFibGVIZWlnaHQgPSBtYXhpbXVtQ2xpcHBpbmdIZWlnaHQ7XG4gICAgICB9XG4gICAgICBpZiAobm9TaGlmdCAmJiAhYWxpZ25tZW50KSB7XG4gICAgICAgIGlmIChpc1lBeGlzKSB7XG4gICAgICAgICAgYXZhaWxhYmxlV2lkdGggPSB3aWR0aCAtIDIgKiBtYXgob3ZlcmZsb3cubGVmdCwgb3ZlcmZsb3cucmlnaHQpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGF2YWlsYWJsZUhlaWdodCA9IGhlaWdodCAtIDIgKiBtYXgob3ZlcmZsb3cudG9wLCBvdmVyZmxvdy5ib3R0b20pO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBhd2FpdCBhcHBseSh7XG4gICAgICAgIC4uLnN0YXRlLFxuICAgICAgICBhdmFpbGFibGVXaWR0aCxcbiAgICAgICAgYXZhaWxhYmxlSGVpZ2h0XG4gICAgICB9KTtcbiAgICAgIGNvbnN0IG5leHREaW1lbnNpb25zID0gYXdhaXQgcGxhdGZvcm0uZ2V0RGltZW5zaW9ucyhlbGVtZW50cy5mbG9hdGluZyk7XG4gICAgICBpZiAod2lkdGggIT09IG5leHREaW1lbnNpb25zLndpZHRoIHx8IGhlaWdodCAhPT0gbmV4dERpbWVuc2lvbnMuaGVpZ2h0KSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgcmVzZXQ6IHtcbiAgICAgICAgICAgIHJlY3RzOiB0cnVlXG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgfTtcbn07XG5cbmV4cG9ydCB7IGFycm93LCBhdXRvUGxhY2VtZW50LCBjb21wdXRlUG9zaXRpb24sIGRldGVjdE92ZXJmbG93LCBmbGlwLCBoaWRlLCBpbmxpbmUsIGxpbWl0U2hpZnQsIG9mZnNldCwgc2hpZnQsIHNpemUgfTtcbiIsImltcG9ydCB7IHJlY3RUb0NsaWVudFJlY3QsIGFycm93IGFzIGFycm93JDEsIGF1dG9QbGFjZW1lbnQgYXMgYXV0b1BsYWNlbWVudCQxLCBkZXRlY3RPdmVyZmxvdyBhcyBkZXRlY3RPdmVyZmxvdyQxLCBmbGlwIGFzIGZsaXAkMSwgaGlkZSBhcyBoaWRlJDEsIGlubGluZSBhcyBpbmxpbmUkMSwgbGltaXRTaGlmdCBhcyBsaW1pdFNoaWZ0JDEsIG9mZnNldCBhcyBvZmZzZXQkMSwgc2hpZnQgYXMgc2hpZnQkMSwgc2l6ZSBhcyBzaXplJDEsIGNvbXB1dGVQb3NpdGlvbiBhcyBjb21wdXRlUG9zaXRpb24kMSB9IGZyb20gJ0BmbG9hdGluZy11aS9jb3JlJztcbmltcG9ydCB7IHJvdW5kLCBjcmVhdGVDb29yZHMsIG1heCwgbWluLCBmbG9vciB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscyc7XG5pbXBvcnQgeyBnZXRDb21wdXRlZFN0eWxlIGFzIGdldENvbXB1dGVkU3R5bGUkMSwgaXNIVE1MRWxlbWVudCwgaXNFbGVtZW50LCBnZXRXaW5kb3csIGlzV2ViS2l0LCBnZXRGcmFtZUVsZW1lbnQsIGdldE5vZGVTY3JvbGwsIGdldERvY3VtZW50RWxlbWVudCwgaXNUb3BMYXllciwgZ2V0Tm9kZU5hbWUsIGlzT3ZlcmZsb3dFbGVtZW50LCBnZXRPdmVyZmxvd0FuY2VzdG9ycywgZ2V0UGFyZW50Tm9kZSwgaXNMYXN0VHJhdmVyc2FibGVOb2RlLCBpc0NvbnRhaW5pbmdCbG9jaywgaXNUYWJsZUVsZW1lbnQsIGdldENvbnRhaW5pbmdCbG9jayB9IGZyb20gJ0BmbG9hdGluZy11aS91dGlscy9kb20nO1xuZXhwb3J0IHsgZ2V0T3ZlcmZsb3dBbmNlc3RvcnMgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcblxuZnVuY3Rpb24gZ2V0Q3NzRGltZW5zaW9ucyhlbGVtZW50KSB7XG4gIGNvbnN0IGNzcyA9IGdldENvbXB1dGVkU3R5bGUkMShlbGVtZW50KTtcbiAgLy8gSW4gdGVzdGluZyBlbnZpcm9ubWVudHMsIHRoZSBgd2lkdGhgIGFuZCBgaGVpZ2h0YCBwcm9wZXJ0aWVzIGFyZSBlbXB0eVxuICAvLyBzdHJpbmdzIGZvciBTVkcgZWxlbWVudHMsIHJldHVybmluZyBOYU4uIEZhbGxiYWNrIHRvIGAwYCBpbiB0aGlzIGNhc2UuXG4gIGxldCB3aWR0aCA9IHBhcnNlRmxvYXQoY3NzLndpZHRoKSB8fCAwO1xuICBsZXQgaGVpZ2h0ID0gcGFyc2VGbG9hdChjc3MuaGVpZ2h0KSB8fCAwO1xuICBjb25zdCBoYXNPZmZzZXQgPSBpc0hUTUxFbGVtZW50KGVsZW1lbnQpO1xuICBjb25zdCBvZmZzZXRXaWR0aCA9IGhhc09mZnNldCA/IGVsZW1lbnQub2Zmc2V0V2lkdGggOiB3aWR0aDtcbiAgY29uc3Qgb2Zmc2V0SGVpZ2h0ID0gaGFzT2Zmc2V0ID8gZWxlbWVudC5vZmZzZXRIZWlnaHQgOiBoZWlnaHQ7XG4gIGNvbnN0IHNob3VsZEZhbGxiYWNrID0gcm91bmQod2lkdGgpICE9PSBvZmZzZXRXaWR0aCB8fCByb3VuZChoZWlnaHQpICE9PSBvZmZzZXRIZWlnaHQ7XG4gIGlmIChzaG91bGRGYWxsYmFjaykge1xuICAgIHdpZHRoID0gb2Zmc2V0V2lkdGg7XG4gICAgaGVpZ2h0ID0gb2Zmc2V0SGVpZ2h0O1xuICB9XG4gIHJldHVybiB7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0LFxuICAgICQ6IHNob3VsZEZhbGxiYWNrXG4gIH07XG59XG5cbmZ1bmN0aW9uIHVud3JhcEVsZW1lbnQoZWxlbWVudCkge1xuICByZXR1cm4gIWlzRWxlbWVudChlbGVtZW50KSA/IGVsZW1lbnQuY29udGV4dEVsZW1lbnQgOiBlbGVtZW50O1xufVxuXG5mdW5jdGlvbiBnZXRTY2FsZShlbGVtZW50KSB7XG4gIGNvbnN0IGRvbUVsZW1lbnQgPSB1bndyYXBFbGVtZW50KGVsZW1lbnQpO1xuICBpZiAoIWlzSFRNTEVsZW1lbnQoZG9tRWxlbWVudCkpIHtcbiAgICByZXR1cm4gY3JlYXRlQ29vcmRzKDEpO1xuICB9XG4gIGNvbnN0IHJlY3QgPSBkb21FbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICBjb25zdCB7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0LFxuICAgICRcbiAgfSA9IGdldENzc0RpbWVuc2lvbnMoZG9tRWxlbWVudCk7XG4gIGxldCB4ID0gKCQgPyByb3VuZChyZWN0LndpZHRoKSA6IHJlY3Qud2lkdGgpIC8gd2lkdGg7XG4gIGxldCB5ID0gKCQgPyByb3VuZChyZWN0LmhlaWdodCkgOiByZWN0LmhlaWdodCkgLyBoZWlnaHQ7XG5cbiAgLy8gMCwgTmFOLCBvciBJbmZpbml0eSBzaG91bGQgYWx3YXlzIGZhbGxiYWNrIHRvIDEuXG5cbiAgaWYgKCF4IHx8ICFOdW1iZXIuaXNGaW5pdGUoeCkpIHtcbiAgICB4ID0gMTtcbiAgfVxuICBpZiAoIXkgfHwgIU51bWJlci5pc0Zpbml0ZSh5KSkge1xuICAgIHkgPSAxO1xuICB9XG4gIHJldHVybiB7XG4gICAgeCxcbiAgICB5XG4gIH07XG59XG5cbmNvbnN0IG5vT2Zmc2V0cyA9IC8qI19fUFVSRV9fKi9jcmVhdGVDb29yZHMoMCk7XG5mdW5jdGlvbiBnZXRWaXN1YWxPZmZzZXRzKGVsZW1lbnQpIHtcbiAgY29uc3Qgd2luID0gZ2V0V2luZG93KGVsZW1lbnQpO1xuICBpZiAoIWlzV2ViS2l0KCkgfHwgIXdpbi52aXN1YWxWaWV3cG9ydCkge1xuICAgIHJldHVybiBub09mZnNldHM7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB4OiB3aW4udmlzdWFsVmlld3BvcnQub2Zmc2V0TGVmdCxcbiAgICB5OiB3aW4udmlzdWFsVmlld3BvcnQub2Zmc2V0VG9wXG4gIH07XG59XG5mdW5jdGlvbiBzaG91bGRBZGRWaXN1YWxPZmZzZXRzKGVsZW1lbnQsIGlzRml4ZWQsIGZsb2F0aW5nT2Zmc2V0UGFyZW50KSB7XG4gIGlmIChpc0ZpeGVkID09PSB2b2lkIDApIHtcbiAgICBpc0ZpeGVkID0gZmFsc2U7XG4gIH1cbiAgcmV0dXJuICEhZmxvYXRpbmdPZmZzZXRQYXJlbnQgJiYgaXNGaXhlZCAmJiBmbG9hdGluZ09mZnNldFBhcmVudCA9PT0gZ2V0V2luZG93KGVsZW1lbnQpO1xufVxuXG5mdW5jdGlvbiBnZXRCb3VuZGluZ0NsaWVudFJlY3QoZWxlbWVudCwgaW5jbHVkZVNjYWxlLCBpc0ZpeGVkU3RyYXRlZ3ksIG9mZnNldFBhcmVudCkge1xuICBpZiAoaW5jbHVkZVNjYWxlID09PSB2b2lkIDApIHtcbiAgICBpbmNsdWRlU2NhbGUgPSBmYWxzZTtcbiAgfVxuICBpZiAoaXNGaXhlZFN0cmF0ZWd5ID09PSB2b2lkIDApIHtcbiAgICBpc0ZpeGVkU3RyYXRlZ3kgPSBmYWxzZTtcbiAgfVxuICBjb25zdCBjbGllbnRSZWN0ID0gZWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgY29uc3QgZG9tRWxlbWVudCA9IHVud3JhcEVsZW1lbnQoZWxlbWVudCk7XG4gIGxldCBzY2FsZSA9IGNyZWF0ZUNvb3JkcygxKTtcbiAgaWYgKGluY2x1ZGVTY2FsZSkge1xuICAgIGlmIChvZmZzZXRQYXJlbnQpIHtcbiAgICAgIGlmIChpc0VsZW1lbnQob2Zmc2V0UGFyZW50KSkge1xuICAgICAgICBzY2FsZSA9IGdldFNjYWxlKG9mZnNldFBhcmVudCk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHNjYWxlID0gZ2V0U2NhbGUoZWxlbWVudCk7XG4gICAgfVxuICB9XG4gIGNvbnN0IHZpc3VhbE9mZnNldHMgPSBzaG91bGRBZGRWaXN1YWxPZmZzZXRzKGRvbUVsZW1lbnQsIGlzRml4ZWRTdHJhdGVneSwgb2Zmc2V0UGFyZW50KSA/IGdldFZpc3VhbE9mZnNldHMoZG9tRWxlbWVudCkgOiBjcmVhdGVDb29yZHMoMCk7XG4gIGxldCB4ID0gKGNsaWVudFJlY3QubGVmdCArIHZpc3VhbE9mZnNldHMueCkgLyBzY2FsZS54O1xuICBsZXQgeSA9IChjbGllbnRSZWN0LnRvcCArIHZpc3VhbE9mZnNldHMueSkgLyBzY2FsZS55O1xuICBsZXQgd2lkdGggPSBjbGllbnRSZWN0LndpZHRoIC8gc2NhbGUueDtcbiAgbGV0IGhlaWdodCA9IGNsaWVudFJlY3QuaGVpZ2h0IC8gc2NhbGUueTtcbiAgaWYgKGRvbUVsZW1lbnQgJiYgb2Zmc2V0UGFyZW50KSB7XG4gICAgY29uc3Qgd2luID0gZ2V0V2luZG93KGRvbUVsZW1lbnQpO1xuICAgIGNvbnN0IG9mZnNldFdpbiA9IGlzRWxlbWVudChvZmZzZXRQYXJlbnQpID8gZ2V0V2luZG93KG9mZnNldFBhcmVudCkgOiBvZmZzZXRQYXJlbnQ7XG4gICAgbGV0IGN1cnJlbnRXaW4gPSB3aW47XG4gICAgbGV0IGN1cnJlbnRJRnJhbWUgPSBnZXRGcmFtZUVsZW1lbnQoY3VycmVudFdpbik7XG4gICAgd2hpbGUgKGN1cnJlbnRJRnJhbWUgJiYgb2Zmc2V0V2luICE9PSBjdXJyZW50V2luKSB7XG4gICAgICBjb25zdCBpZnJhbWVTY2FsZSA9IGdldFNjYWxlKGN1cnJlbnRJRnJhbWUpO1xuICAgICAgY29uc3QgaWZyYW1lUmVjdCA9IGN1cnJlbnRJRnJhbWUuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICBjb25zdCBjc3MgPSBnZXRDb21wdXRlZFN0eWxlJDEoY3VycmVudElGcmFtZSk7XG4gICAgICBjb25zdCBsZWZ0ID0gaWZyYW1lUmVjdC5sZWZ0ICsgKGN1cnJlbnRJRnJhbWUuY2xpZW50TGVmdCArIHBhcnNlRmxvYXQoY3NzLnBhZGRpbmdMZWZ0KSkgKiBpZnJhbWVTY2FsZS54O1xuICAgICAgY29uc3QgdG9wID0gaWZyYW1lUmVjdC50b3AgKyAoY3VycmVudElGcmFtZS5jbGllbnRUb3AgKyBwYXJzZUZsb2F0KGNzcy5wYWRkaW5nVG9wKSkgKiBpZnJhbWVTY2FsZS55O1xuICAgICAgeCAqPSBpZnJhbWVTY2FsZS54O1xuICAgICAgeSAqPSBpZnJhbWVTY2FsZS55O1xuICAgICAgd2lkdGggKj0gaWZyYW1lU2NhbGUueDtcbiAgICAgIGhlaWdodCAqPSBpZnJhbWVTY2FsZS55O1xuICAgICAgeCArPSBsZWZ0O1xuICAgICAgeSArPSB0b3A7XG4gICAgICBjdXJyZW50V2luID0gZ2V0V2luZG93KGN1cnJlbnRJRnJhbWUpO1xuICAgICAgY3VycmVudElGcmFtZSA9IGdldEZyYW1lRWxlbWVudChjdXJyZW50V2luKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHJlY3RUb0NsaWVudFJlY3Qoe1xuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICB4LFxuICAgIHlcbiAgfSk7XG59XG5cbi8vIElmIDxodG1sPiBoYXMgYSBDU1Mgd2lkdGggZ3JlYXRlciB0aGFuIHRoZSB2aWV3cG9ydCwgdGhlbiB0aGlzIHdpbGwgYmVcbi8vIGluY29ycmVjdCBmb3IgUlRMLlxuZnVuY3Rpb24gZ2V0V2luZG93U2Nyb2xsQmFyWChlbGVtZW50LCByZWN0KSB7XG4gIGNvbnN0IGxlZnRTY3JvbGwgPSBnZXROb2RlU2Nyb2xsKGVsZW1lbnQpLnNjcm9sbExlZnQ7XG4gIGlmICghcmVjdCkge1xuICAgIHJldHVybiBnZXRCb3VuZGluZ0NsaWVudFJlY3QoZ2V0RG9jdW1lbnRFbGVtZW50KGVsZW1lbnQpKS5sZWZ0ICsgbGVmdFNjcm9sbDtcbiAgfVxuICByZXR1cm4gcmVjdC5sZWZ0ICsgbGVmdFNjcm9sbDtcbn1cblxuZnVuY3Rpb24gZ2V0SFRNTE9mZnNldChkb2N1bWVudEVsZW1lbnQsIHNjcm9sbCkge1xuICBjb25zdCBodG1sUmVjdCA9IGRvY3VtZW50RWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgY29uc3QgeCA9IGh0bWxSZWN0LmxlZnQgKyBzY3JvbGwuc2Nyb2xsTGVmdCAtIGdldFdpbmRvd1Njcm9sbEJhclgoZG9jdW1lbnRFbGVtZW50LCBodG1sUmVjdCk7XG4gIGNvbnN0IHkgPSBodG1sUmVjdC50b3AgKyBzY3JvbGwuc2Nyb2xsVG9wO1xuICByZXR1cm4ge1xuICAgIHgsXG4gICAgeVxuICB9O1xufVxuXG5mdW5jdGlvbiBjb252ZXJ0T2Zmc2V0UGFyZW50UmVsYXRpdmVSZWN0VG9WaWV3cG9ydFJlbGF0aXZlUmVjdChfcmVmKSB7XG4gIGxldCB7XG4gICAgZWxlbWVudHMsXG4gICAgcmVjdCxcbiAgICBvZmZzZXRQYXJlbnQsXG4gICAgc3RyYXRlZ3lcbiAgfSA9IF9yZWY7XG4gIGNvbnN0IGlzRml4ZWQgPSBzdHJhdGVneSA9PT0gJ2ZpeGVkJztcbiAgY29uc3QgZG9jdW1lbnRFbGVtZW50ID0gZ2V0RG9jdW1lbnRFbGVtZW50KG9mZnNldFBhcmVudCk7XG4gIGNvbnN0IHRvcExheWVyID0gZWxlbWVudHMgPyBpc1RvcExheWVyKGVsZW1lbnRzLmZsb2F0aW5nKSA6IGZhbHNlO1xuICBpZiAob2Zmc2V0UGFyZW50ID09PSBkb2N1bWVudEVsZW1lbnQgfHwgdG9wTGF5ZXIgJiYgaXNGaXhlZCkge1xuICAgIHJldHVybiByZWN0O1xuICB9XG4gIGxldCBzY3JvbGwgPSB7XG4gICAgc2Nyb2xsTGVmdDogMCxcbiAgICBzY3JvbGxUb3A6IDBcbiAgfTtcbiAgbGV0IHNjYWxlID0gY3JlYXRlQ29vcmRzKDEpO1xuICBjb25zdCBvZmZzZXRzID0gY3JlYXRlQ29vcmRzKDApO1xuICBjb25zdCBpc09mZnNldFBhcmVudEFuRWxlbWVudCA9IGlzSFRNTEVsZW1lbnQob2Zmc2V0UGFyZW50KTtcbiAgaWYgKGlzT2Zmc2V0UGFyZW50QW5FbGVtZW50IHx8ICFpc0ZpeGVkKSB7XG4gICAgaWYgKGdldE5vZGVOYW1lKG9mZnNldFBhcmVudCkgIT09ICdib2R5JyB8fCBpc092ZXJmbG93RWxlbWVudChkb2N1bWVudEVsZW1lbnQpKSB7XG4gICAgICBzY3JvbGwgPSBnZXROb2RlU2Nyb2xsKG9mZnNldFBhcmVudCk7XG4gICAgfVxuICAgIGlmIChpc09mZnNldFBhcmVudEFuRWxlbWVudCkge1xuICAgICAgY29uc3Qgb2Zmc2V0UmVjdCA9IGdldEJvdW5kaW5nQ2xpZW50UmVjdChvZmZzZXRQYXJlbnQpO1xuICAgICAgc2NhbGUgPSBnZXRTY2FsZShvZmZzZXRQYXJlbnQpO1xuICAgICAgb2Zmc2V0cy54ID0gb2Zmc2V0UmVjdC54ICsgb2Zmc2V0UGFyZW50LmNsaWVudExlZnQ7XG4gICAgICBvZmZzZXRzLnkgPSBvZmZzZXRSZWN0LnkgKyBvZmZzZXRQYXJlbnQuY2xpZW50VG9wO1xuICAgIH1cbiAgfVxuICBjb25zdCBodG1sT2Zmc2V0ID0gZG9jdW1lbnRFbGVtZW50ICYmICFpc09mZnNldFBhcmVudEFuRWxlbWVudCAmJiAhaXNGaXhlZCA/IGdldEhUTUxPZmZzZXQoZG9jdW1lbnRFbGVtZW50LCBzY3JvbGwpIDogY3JlYXRlQ29vcmRzKDApO1xuICByZXR1cm4ge1xuICAgIHdpZHRoOiByZWN0LndpZHRoICogc2NhbGUueCxcbiAgICBoZWlnaHQ6IHJlY3QuaGVpZ2h0ICogc2NhbGUueSxcbiAgICB4OiByZWN0LnggKiBzY2FsZS54IC0gc2Nyb2xsLnNjcm9sbExlZnQgKiBzY2FsZS54ICsgb2Zmc2V0cy54ICsgaHRtbE9mZnNldC54LFxuICAgIHk6IHJlY3QueSAqIHNjYWxlLnkgLSBzY3JvbGwuc2Nyb2xsVG9wICogc2NhbGUueSArIG9mZnNldHMueSArIGh0bWxPZmZzZXQueVxuICB9O1xufVxuXG5mdW5jdGlvbiBnZXRDbGllbnRSZWN0cyhlbGVtZW50KSB7XG4gIHJldHVybiBlbGVtZW50LmdldENsaWVudFJlY3RzID8gQXJyYXkuZnJvbShlbGVtZW50LmdldENsaWVudFJlY3RzKCkpIDogW107XG59XG5cbi8vIEdldHMgdGhlIGVudGlyZSBzaXplIG9mIHRoZSBzY3JvbGxhYmxlIGRvY3VtZW50IGFyZWEsIGV2ZW4gZXh0ZW5kaW5nIG91dHNpZGVcbi8vIG9mIHRoZSBgPGh0bWw+YCBhbmQgYDxib2R5PmAgcmVjdCBib3VuZHMgaWYgaG9yaXpvbnRhbGx5IHNjcm9sbGFibGUuXG5mdW5jdGlvbiBnZXREb2N1bWVudFJlY3QoaHRtbCkge1xuICBjb25zdCBzY3JvbGwgPSBnZXROb2RlU2Nyb2xsKGh0bWwpO1xuICBjb25zdCBib2R5ID0gaHRtbC5vd25lckRvY3VtZW50LmJvZHk7XG4gIGNvbnN0IHdpZHRoID0gbWF4KGh0bWwuc2Nyb2xsV2lkdGgsIGh0bWwuY2xpZW50V2lkdGgsIGJvZHkuc2Nyb2xsV2lkdGgsIGJvZHkuY2xpZW50V2lkdGgpO1xuICBjb25zdCBoZWlnaHQgPSBtYXgoaHRtbC5zY3JvbGxIZWlnaHQsIGh0bWwuY2xpZW50SGVpZ2h0LCBib2R5LnNjcm9sbEhlaWdodCwgYm9keS5jbGllbnRIZWlnaHQpO1xuICBsZXQgeCA9IC1zY3JvbGwuc2Nyb2xsTGVmdCArIGdldFdpbmRvd1Njcm9sbEJhclgoaHRtbCk7XG4gIGNvbnN0IHkgPSAtc2Nyb2xsLnNjcm9sbFRvcDtcbiAgaWYgKGdldENvbXB1dGVkU3R5bGUkMShib2R5KS5kaXJlY3Rpb24gPT09ICdydGwnKSB7XG4gICAgeCArPSBtYXgoaHRtbC5jbGllbnRXaWR0aCwgYm9keS5jbGllbnRXaWR0aCkgLSB3aWR0aDtcbiAgfVxuICByZXR1cm4ge1xuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICB4LFxuICAgIHlcbiAgfTtcbn1cblxuLy8gU2FmZXR5IGNoZWNrOiBlbnN1cmUgdGhlIHNjcm9sbGJhciBzcGFjZSBpcyByZWFzb25hYmxlIGluIGNhc2UgdGhpc1xuLy8gY2FsY3VsYXRpb24gaXMgYWZmZWN0ZWQgYnkgdW51c3VhbCBzdHlsZXMuXG4vLyBNb3N0IHNjcm9sbGJhcnMgbGVhdmUgMTUtMThweCBvZiBzcGFjZS5cbmNvbnN0IFNDUk9MTEJBUl9NQVggPSAyNTtcbmZ1bmN0aW9uIGdldFZpZXdwb3J0UmVjdChlbGVtZW50LCBzdHJhdGVneSwgcm9vdEJvdW5kYXJ5KSB7XG4gIGlmIChyb290Qm91bmRhcnkgPT09IHZvaWQgMCkge1xuICAgIHJvb3RCb3VuZGFyeSA9ICd2aWV3cG9ydCc7XG4gIH1cbiAgY29uc3QgaXNMYXlvdXRWaWV3cG9ydCA9IHJvb3RCb3VuZGFyeSA9PT0gJ2xheW91dFZpZXdwb3J0JztcbiAgY29uc3Qgd2luID0gZ2V0V2luZG93KGVsZW1lbnQpO1xuICBjb25zdCBodG1sID0gZ2V0RG9jdW1lbnRFbGVtZW50KGVsZW1lbnQpO1xuICBjb25zdCB2aXN1YWxWaWV3cG9ydCA9IHdpbi52aXN1YWxWaWV3cG9ydDtcbiAgbGV0IHdpZHRoID0gaHRtbC5jbGllbnRXaWR0aDtcbiAgbGV0IGhlaWdodCA9IGh0bWwuY2xpZW50SGVpZ2h0O1xuICBsZXQgeCA9IDA7XG4gIGxldCB5ID0gMDtcbiAgaWYgKHZpc3VhbFZpZXdwb3J0KSB7XG4gICAgLy8gQ2xpZW50IGNvb3JkaW5hdGVzIGFyZSByZWxhdGl2ZSB0byB0aGUgbGF5b3V0IHZpZXdwb3J0LCBleGNlcHQgaW5cbiAgICAvLyBXZWJLaXQgd2l0aCBhbiBgYWJzb2x1dGVgIHN0cmF0ZWd5LCB3aGVyZSB0aGV5IGFyZSByZWxhdGl2ZSB0byB0aGVcbiAgICAvLyB2aXN1YWwgdmlld3BvcnQuXG4gICAgY29uc3QgbGF5b3V0UmVsYXRpdmVDbGllbnRDb29yZHMgPSAhaXNXZWJLaXQoKSB8fCBzdHJhdGVneSA9PT0gJ2ZpeGVkJztcbiAgICBpZiAoaXNMYXlvdXRWaWV3cG9ydCkge1xuICAgICAgaWYgKCFsYXlvdXRSZWxhdGl2ZUNsaWVudENvb3Jkcykge1xuICAgICAgICB4ID0gLXZpc3VhbFZpZXdwb3J0Lm9mZnNldExlZnQ7XG4gICAgICAgIHkgPSAtdmlzdWFsVmlld3BvcnQub2Zmc2V0VG9wO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB3aWR0aCA9IHZpc3VhbFZpZXdwb3J0LndpZHRoO1xuICAgICAgaGVpZ2h0ID0gdmlzdWFsVmlld3BvcnQuaGVpZ2h0O1xuICAgICAgaWYgKGxheW91dFJlbGF0aXZlQ2xpZW50Q29vcmRzKSB7XG4gICAgICAgIHggPSB2aXN1YWxWaWV3cG9ydC5vZmZzZXRMZWZ0O1xuICAgICAgICB5ID0gdmlzdWFsVmlld3BvcnQub2Zmc2V0VG9wO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBjb25zdCB3aW5kb3dTY3JvbGxiYXJYID0gZ2V0V2luZG93U2Nyb2xsQmFyWChodG1sKTtcbiAgLy8gYHNjcm9sbGJhci1ndXR0ZXI6IHN0YWJsZWAgb24gdGhlIDxodG1sPiByZXNlcnZlcyBndXR0ZXIgc3BhY2UgdGhhdCBzaHJpbmtzXG4gIC8vIHRoZSB2aXN1YWwgd2lkdGggYnV0IGlzbid0IHJlZmxlY3RlZCBpbiBgaHRtbC5jbGllbnRXaWR0aGAsIHNvIHN1YnRyYWN0IGl0LlxuICAvLyBPbmx5IHRoZSBpbmxpbmUtZW5kIChyaWdodCkgZ3V0dGVyIGNhbiBob2xkIHRoZSBzY3JvbGxiYXI7IGBib3RoLWVkZ2VzYCBhbHNvXG4gIC8vIHJlc2VydmVzIGFuIGVtcHR5IGlubGluZS1zdGFydCBndXR0ZXIgdGhhdCBjbGlwcyBub3RoaW5nLCBzbyBleGNsdWRlIGp1c3RcbiAgLy8gdGhlIG9uZSBzY3JvbGxiYXItc2lkZSBndXR0ZXIg4oCUIGhhbHZlIHRoZSBtZWFzdXJlZCAodHdvLWd1dHRlcikgdG90YWwuIEFcbiAgLy8gbGVmdC1zaWRlIHNjcm9sbGJhciAoYHdpbmRvd1Njcm9sbGJhclggPiAwYCkgaXMgYWxyZWFkeSBoYW5kbGVkIGJ5XG4gIC8vIGBnZXRIVE1MT2Zmc2V0YC9gdmlzdWFsVmlld3BvcnQud2lkdGhgOyBza2lwIGl0IGhlcmUuXG4gIGlmICh3aW5kb3dTY3JvbGxiYXJYIDw9IDApIHtcbiAgICBjb25zdCBkb2MgPSBodG1sLm93bmVyRG9jdW1lbnQ7XG4gICAgY29uc3QgYm9keSA9IGRvYy5ib2R5O1xuICAgIGNvbnN0IGJvZHlTdHlsZXMgPSBnZXRDb21wdXRlZFN0eWxlKGJvZHkpO1xuICAgIGNvbnN0IGJvZHlNYXJnaW5JbmxpbmUgPSBkb2MuY29tcGF0TW9kZSA9PT0gJ0NTUzFDb21wYXQnID8gcGFyc2VGbG9hdChib2R5U3R5bGVzLm1hcmdpbkxlZnQpICsgcGFyc2VGbG9hdChib2R5U3R5bGVzLm1hcmdpblJpZ2h0KSB8fCAwIDogMDtcbiAgICBjb25zdCByZXNlcnZlZFdpZHRoID0gTWF0aC5hYnMoaHRtbC5jbGllbnRXaWR0aCAtIGJvZHkuY2xpZW50V2lkdGggLSBib2R5TWFyZ2luSW5saW5lKTtcbiAgICBjb25zdCBndXR0ZXIgPSBnZXRDb21wdXRlZFN0eWxlKGh0bWwpLnNjcm9sbGJhckd1dHRlciA9PT0gJ3N0YWJsZSBib3RoLWVkZ2VzJyA/IHJlc2VydmVkV2lkdGggLyAyIDogcmVzZXJ2ZWRXaWR0aDtcbiAgICBpZiAoZ3V0dGVyIDw9IFNDUk9MTEJBUl9NQVgpIHtcbiAgICAgIHdpZHRoIC09IGd1dHRlcjtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB3aWR0aCxcbiAgICBoZWlnaHQsXG4gICAgeCxcbiAgICB5XG4gIH07XG59XG5cbi8vIFJldHVybnMgdGhlIGlubmVyIGNsaWVudCByZWN0LCBzdWJ0cmFjdGluZyBzY3JvbGxiYXJzIGlmIHByZXNlbnQuXG5mdW5jdGlvbiBnZXRJbm5lckJvdW5kaW5nQ2xpZW50UmVjdChlbGVtZW50LCBzdHJhdGVneSkge1xuICBjb25zdCBjbGllbnRSZWN0ID0gZ2V0Qm91bmRpbmdDbGllbnRSZWN0KGVsZW1lbnQsIHRydWUsIHN0cmF0ZWd5ID09PSAnZml4ZWQnKTtcbiAgY29uc3QgdG9wID0gY2xpZW50UmVjdC50b3AgKyBlbGVtZW50LmNsaWVudFRvcDtcbiAgY29uc3QgbGVmdCA9IGNsaWVudFJlY3QubGVmdCArIGVsZW1lbnQuY2xpZW50TGVmdDtcbiAgY29uc3Qgc2NhbGUgPSBnZXRTY2FsZShlbGVtZW50KTtcbiAgY29uc3Qgd2lkdGggPSBlbGVtZW50LmNsaWVudFdpZHRoICogc2NhbGUueDtcbiAgY29uc3QgaGVpZ2h0ID0gZWxlbWVudC5jbGllbnRIZWlnaHQgKiBzY2FsZS55O1xuICBjb25zdCB4ID0gbGVmdCAqIHNjYWxlLng7XG4gIGNvbnN0IHkgPSB0b3AgKiBzY2FsZS55O1xuICByZXR1cm4ge1xuICAgIHdpZHRoLFxuICAgIGhlaWdodCxcbiAgICB4LFxuICAgIHlcbiAgfTtcbn1cbmZ1bmN0aW9uIGdldENsaWVudFJlY3RGcm9tQ2xpcHBpbmdBbmNlc3RvcihlbGVtZW50LCBjbGlwcGluZ0FuY2VzdG9yLCBzdHJhdGVneSkge1xuICBsZXQgcmVjdDtcbiAgaWYgKGNsaXBwaW5nQW5jZXN0b3IgPT09ICd2aWV3cG9ydCcgfHwgY2xpcHBpbmdBbmNlc3RvciA9PT0gJ2xheW91dFZpZXdwb3J0Jykge1xuICAgIHJlY3QgPSBnZXRWaWV3cG9ydFJlY3QoZWxlbWVudCwgc3RyYXRlZ3ksIGNsaXBwaW5nQW5jZXN0b3IpO1xuICB9IGVsc2UgaWYgKGNsaXBwaW5nQW5jZXN0b3IgPT09ICdkb2N1bWVudCcpIHtcbiAgICByZWN0ID0gZ2V0RG9jdW1lbnRSZWN0KGdldERvY3VtZW50RWxlbWVudChlbGVtZW50KSk7XG4gIH0gZWxzZSBpZiAoaXNFbGVtZW50KGNsaXBwaW5nQW5jZXN0b3IpKSB7XG4gICAgcmVjdCA9IGdldElubmVyQm91bmRpbmdDbGllbnRSZWN0KGNsaXBwaW5nQW5jZXN0b3IsIHN0cmF0ZWd5KTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCB2aXN1YWxPZmZzZXRzID0gZ2V0VmlzdWFsT2Zmc2V0cyhlbGVtZW50KTtcbiAgICByZWN0ID0ge1xuICAgICAgeDogY2xpcHBpbmdBbmNlc3Rvci54IC0gdmlzdWFsT2Zmc2V0cy54LFxuICAgICAgeTogY2xpcHBpbmdBbmNlc3Rvci55IC0gdmlzdWFsT2Zmc2V0cy55LFxuICAgICAgd2lkdGg6IGNsaXBwaW5nQW5jZXN0b3Iud2lkdGgsXG4gICAgICBoZWlnaHQ6IGNsaXBwaW5nQW5jZXN0b3IuaGVpZ2h0XG4gICAgfTtcbiAgfVxuICByZXR1cm4gcmVjdFRvQ2xpZW50UmVjdChyZWN0KTtcbn1cblxuLy8gQSBcImNsaXBwaW5nIGFuY2VzdG9yXCIgaXMgYW4gYG92ZXJmbG93YCBlbGVtZW50IHdpdGggdGhlIGNoYXJhY3RlcmlzdGljIG9mXG4vLyBjbGlwcGluZyAob3IgaGlkaW5nKSBjaGlsZCBlbGVtZW50cy4gVGhpcyByZXR1cm5zIGFsbCBjbGlwcGluZyBhbmNlc3RvcnNcbi8vIG9mIHRoZSBnaXZlbiBlbGVtZW50IHVwIHRoZSB0cmVlLlxuZnVuY3Rpb24gZ2V0Q2xpcHBpbmdFbGVtZW50QW5jZXN0b3JzKGVsZW1lbnQsIGNhY2hlKSB7XG4gIGNvbnN0IGNhY2hlZFJlc3VsdCA9IGNhY2hlLmdldChlbGVtZW50KTtcbiAgaWYgKGNhY2hlZFJlc3VsdCkge1xuICAgIHJldHVybiBjYWNoZWRSZXN1bHQ7XG4gIH1cbiAgbGV0IHJlc3VsdCA9IGdldE92ZXJmbG93QW5jZXN0b3JzKGVsZW1lbnQsIFtdLCBmYWxzZSkuZmlsdGVyKGVsID0+IGlzRWxlbWVudChlbCkgJiYgZ2V0Tm9kZU5hbWUoZWwpICE9PSAnYm9keScpO1xuICBsZXQgbGFzdEtlcHRDb21wdXRlZFN0eWxlID0gbnVsbDtcbiAgY29uc3QgZWxlbWVudElzRml4ZWQgPSBnZXRDb21wdXRlZFN0eWxlJDEoZWxlbWVudCkucG9zaXRpb24gPT09ICdmaXhlZCc7XG4gIGxldCBjdXJyZW50Tm9kZSA9IGVsZW1lbnRJc0ZpeGVkID8gZ2V0UGFyZW50Tm9kZShlbGVtZW50KSA6IGVsZW1lbnQ7XG5cbiAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvQ1NTL0NvbnRhaW5pbmdfYmxvY2sjaWRlbnRpZnlpbmdfdGhlX2NvbnRhaW5pbmdfYmxvY2tcbiAgd2hpbGUgKGlzRWxlbWVudChjdXJyZW50Tm9kZSkgJiYgIWlzTGFzdFRyYXZlcnNhYmxlTm9kZShjdXJyZW50Tm9kZSkpIHtcbiAgICBjb25zdCBjb21wdXRlZFN0eWxlID0gZ2V0Q29tcHV0ZWRTdHlsZSQxKGN1cnJlbnROb2RlKTtcbiAgICBjb25zdCBjdXJyZW50Tm9kZUlzQ29udGFpbmluZyA9IGlzQ29udGFpbmluZ0Jsb2NrKGN1cnJlbnROb2RlKTtcbiAgICAvLyBQb3NpdGlvbiBvZiB0aGUgY29udGFpbmluZyBibG9jayBjaGFpbiBiZWxvdyB0aGUgY3VycmVudCBub2RlLiBBIGZpeGVkXG4gICAgLy8gZWxlbWVudCB3aG9zZSBjb250YWluaW5nIGJsb2NrIGhhc24ndCBiZWVuIGZvdW5kIHlldCBpcyBhIGZpeGVkIGNoYWluLlxuICAgIGNvbnN0IGxhc3RQb3NpdGlvbiA9IGxhc3RLZXB0Q29tcHV0ZWRTdHlsZSA/IGxhc3RLZXB0Q29tcHV0ZWRTdHlsZS5wb3NpdGlvbiA6IGVsZW1lbnRJc0ZpeGVkID8gJ2ZpeGVkJyA6ICcnO1xuXG4gICAgLy8gQSBub24tY29udGFpbmluZyBhbmNlc3RvciBkb2VzIG5vdCBjbGlwIHRoZSBlbGVtZW50IHdoZW4gdGhlIGNoYWluXG4gICAgLy8gYmVsb3cgaXQgZXNjYXBlcyBpdDogYSBmaXhlZCBjaGFpbiBlc2NhcGVzIGFsbCBhbmNlc3RvcnMgdXAgdG8gdGhlXG4gICAgLy8gbmV4dCBjb250YWluaW5nIGJsb2NrLCBhbiBhYnNvbHV0ZSBjaGFpbiBlc2NhcGVzIHN0YXRpYyBhbmNlc3RvcnMuXG4gICAgY29uc3Qgc2hvdWxkRHJvcEN1cnJlbnROb2RlID0gIWN1cnJlbnROb2RlSXNDb250YWluaW5nICYmIChsYXN0UG9zaXRpb24gPT09ICdmaXhlZCcgfHwgbGFzdFBvc2l0aW9uID09PSAnYWJzb2x1dGUnICYmIGNvbXB1dGVkU3R5bGUucG9zaXRpb24gPT09ICdzdGF0aWMnKTtcbiAgICBpZiAoc2hvdWxkRHJvcEN1cnJlbnROb2RlKSB7XG4gICAgICAvLyBEcm9wIG5vbi1jb250YWluaW5nIGJsb2Nrcy5cbiAgICAgIHJlc3VsdCA9IHJlc3VsdC5maWx0ZXIoYW5jZXN0b3IgPT4gYW5jZXN0b3IgIT09IGN1cnJlbnROb2RlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gVGhlIGtlcHQgbm9kZSBjYXJyaWVzIHRoZSBjaGFpbiBwb3NpdGlvbiBmb3IgdGhlIG5leHQgaXRlcmF0aW9uLlxuICAgICAgbGFzdEtlcHRDb21wdXRlZFN0eWxlID0gY29tcHV0ZWRTdHlsZTtcbiAgICB9XG4gICAgY3VycmVudE5vZGUgPSBnZXRQYXJlbnROb2RlKGN1cnJlbnROb2RlKTtcbiAgfVxuICBjYWNoZS5zZXQoZWxlbWVudCwgcmVzdWx0KTtcbiAgcmV0dXJuIHJlc3VsdDtcbn1cblxuLy8gR2V0cyB0aGUgbWF4aW11bSBhcmVhIHRoYXQgdGhlIGVsZW1lbnQgaXMgdmlzaWJsZSBpbiBkdWUgdG8gYW55IG51bWJlciBvZlxuLy8gY2xpcHBpbmcgYW5jZXN0b3JzLlxuZnVuY3Rpb24gZ2V0Q2xpcHBpbmdSZWN0KF9yZWYpIHtcbiAgbGV0IHtcbiAgICBlbGVtZW50LFxuICAgIGJvdW5kYXJ5LFxuICAgIHJvb3RCb3VuZGFyeSxcbiAgICBzdHJhdGVneVxuICB9ID0gX3JlZjtcbiAgY29uc3QgZWxlbWVudENsaXBwaW5nQW5jZXN0b3JzID0gYm91bmRhcnkgPT09ICdjbGlwcGluZ0FuY2VzdG9ycycgPyBpc1RvcExheWVyKGVsZW1lbnQpID8gW10gOiBnZXRDbGlwcGluZ0VsZW1lbnRBbmNlc3RvcnMoZWxlbWVudCwgdGhpcy5fYykgOiBbXS5jb25jYXQoYm91bmRhcnkpO1xuICBjb25zdCBjbGlwcGluZ0FuY2VzdG9ycyA9IFsuLi5lbGVtZW50Q2xpcHBpbmdBbmNlc3RvcnMsIHJvb3RCb3VuZGFyeV07XG4gIGNvbnN0IGZpcnN0UmVjdCA9IGdldENsaWVudFJlY3RGcm9tQ2xpcHBpbmdBbmNlc3RvcihlbGVtZW50LCBjbGlwcGluZ0FuY2VzdG9yc1swXSwgc3RyYXRlZ3kpO1xuICBsZXQgdG9wID0gZmlyc3RSZWN0LnRvcDtcbiAgbGV0IHJpZ2h0ID0gZmlyc3RSZWN0LnJpZ2h0O1xuICBsZXQgYm90dG9tID0gZmlyc3RSZWN0LmJvdHRvbTtcbiAgbGV0IGxlZnQgPSBmaXJzdFJlY3QubGVmdDtcbiAgZm9yIChsZXQgaSA9IDE7IGkgPCBjbGlwcGluZ0FuY2VzdG9ycy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IHJlY3QgPSBnZXRDbGllbnRSZWN0RnJvbUNsaXBwaW5nQW5jZXN0b3IoZWxlbWVudCwgY2xpcHBpbmdBbmNlc3RvcnNbaV0sIHN0cmF0ZWd5KTtcbiAgICB0b3AgPSBtYXgocmVjdC50b3AsIHRvcCk7XG4gICAgcmlnaHQgPSBtaW4ocmVjdC5yaWdodCwgcmlnaHQpO1xuICAgIGJvdHRvbSA9IG1pbihyZWN0LmJvdHRvbSwgYm90dG9tKTtcbiAgICBsZWZ0ID0gbWF4KHJlY3QubGVmdCwgbGVmdCk7XG4gIH1cbiAgcmV0dXJuIHtcbiAgICB3aWR0aDogcmlnaHQgLSBsZWZ0LFxuICAgIGhlaWdodDogYm90dG9tIC0gdG9wLFxuICAgIHg6IGxlZnQsXG4gICAgeTogdG9wXG4gIH07XG59XG5cbmZ1bmN0aW9uIGdldERpbWVuc2lvbnMoZWxlbWVudCkge1xuICBjb25zdCB7XG4gICAgd2lkdGgsXG4gICAgaGVpZ2h0XG4gIH0gPSBnZXRDc3NEaW1lbnNpb25zKGVsZW1lbnQpO1xuICByZXR1cm4ge1xuICAgIHdpZHRoLFxuICAgIGhlaWdodFxuICB9O1xufVxuXG5mdW5jdGlvbiBnZXRSZWN0UmVsYXRpdmVUb09mZnNldFBhcmVudChlbGVtZW50LCBvZmZzZXRQYXJlbnQsIHN0cmF0ZWd5KSB7XG4gIGNvbnN0IGlzT2Zmc2V0UGFyZW50QW5FbGVtZW50ID0gaXNIVE1MRWxlbWVudChvZmZzZXRQYXJlbnQpO1xuICBjb25zdCBkb2N1bWVudEVsZW1lbnQgPSBnZXREb2N1bWVudEVsZW1lbnQob2Zmc2V0UGFyZW50KTtcbiAgY29uc3QgaXNGaXhlZCA9IHN0cmF0ZWd5ID09PSAnZml4ZWQnO1xuICBjb25zdCByZWN0ID0gZ2V0Qm91bmRpbmdDbGllbnRSZWN0KGVsZW1lbnQsIHRydWUsIGlzRml4ZWQsIG9mZnNldFBhcmVudCk7XG4gIGxldCBzY3JvbGwgPSB7XG4gICAgc2Nyb2xsTGVmdDogMCxcbiAgICBzY3JvbGxUb3A6IDBcbiAgfTtcbiAgY29uc3Qgb2Zmc2V0cyA9IGNyZWF0ZUNvb3JkcygwKTtcbiAgaWYgKGlzT2Zmc2V0UGFyZW50QW5FbGVtZW50IHx8ICFpc0ZpeGVkKSB7XG4gICAgaWYgKGdldE5vZGVOYW1lKG9mZnNldFBhcmVudCkgIT09ICdib2R5JyB8fCBpc092ZXJmbG93RWxlbWVudChkb2N1bWVudEVsZW1lbnQpKSB7XG4gICAgICBzY3JvbGwgPSBnZXROb2RlU2Nyb2xsKG9mZnNldFBhcmVudCk7XG4gICAgfVxuICAgIGlmIChpc09mZnNldFBhcmVudEFuRWxlbWVudCkge1xuICAgICAgY29uc3Qgb2Zmc2V0UmVjdCA9IGdldEJvdW5kaW5nQ2xpZW50UmVjdChvZmZzZXRQYXJlbnQsIHRydWUsIGlzRml4ZWQsIG9mZnNldFBhcmVudCk7XG4gICAgICBvZmZzZXRzLnggPSBvZmZzZXRSZWN0LnggKyBvZmZzZXRQYXJlbnQuY2xpZW50TGVmdDtcbiAgICAgIG9mZnNldHMueSA9IG9mZnNldFJlY3QueSArIG9mZnNldFBhcmVudC5jbGllbnRUb3A7XG4gICAgfVxuICB9XG5cbiAgLy8gSWYgdGhlIDxib2R5PiBzY3JvbGxiYXIgYXBwZWFycyBvbiB0aGUgbGVmdCAoZS5nLiBSVEwgc3lzdGVtcykuIFVzZVxuICAvLyBGaXJlZm94IHdpdGggbGF5b3V0LnNjcm9sbGJhci5zaWRlID0gMyBpbiBhYm91dDpjb25maWcgdG8gdGVzdCB0aGlzLlxuICBpZiAoIWlzT2Zmc2V0UGFyZW50QW5FbGVtZW50ICYmIGRvY3VtZW50RWxlbWVudCkge1xuICAgIG9mZnNldHMueCA9IGdldFdpbmRvd1Njcm9sbEJhclgoZG9jdW1lbnRFbGVtZW50KTtcbiAgfVxuICBjb25zdCBodG1sT2Zmc2V0ID0gZG9jdW1lbnRFbGVtZW50ICYmICFpc09mZnNldFBhcmVudEFuRWxlbWVudCAmJiAhaXNGaXhlZCA/IGdldEhUTUxPZmZzZXQoZG9jdW1lbnRFbGVtZW50LCBzY3JvbGwpIDogY3JlYXRlQ29vcmRzKDApO1xuICBjb25zdCB4ID0gcmVjdC5sZWZ0ICsgc2Nyb2xsLnNjcm9sbExlZnQgLSBvZmZzZXRzLnggLSBodG1sT2Zmc2V0Lng7XG4gIGNvbnN0IHkgPSByZWN0LnRvcCArIHNjcm9sbC5zY3JvbGxUb3AgLSBvZmZzZXRzLnkgLSBodG1sT2Zmc2V0Lnk7XG4gIHJldHVybiB7XG4gICAgeCxcbiAgICB5LFxuICAgIHdpZHRoOiByZWN0LndpZHRoLFxuICAgIGhlaWdodDogcmVjdC5oZWlnaHRcbiAgfTtcbn1cblxuZnVuY3Rpb24gaXNTdGF0aWNQb3NpdGlvbmVkKGVsZW1lbnQpIHtcbiAgcmV0dXJuIGdldENvbXB1dGVkU3R5bGUkMShlbGVtZW50KS5wb3NpdGlvbiA9PT0gJ3N0YXRpYyc7XG59XG5cbmZ1bmN0aW9uIGdldFRydWVPZmZzZXRQYXJlbnQoZWxlbWVudCwgcG9seWZpbGwpIHtcbiAgaWYgKCFpc0hUTUxFbGVtZW50KGVsZW1lbnQpIHx8IGdldENvbXB1dGVkU3R5bGUkMShlbGVtZW50KS5wb3NpdGlvbiA9PT0gJ2ZpeGVkJykge1xuICAgIHJldHVybiBudWxsO1xuICB9XG4gIGlmIChwb2x5ZmlsbCkge1xuICAgIHJldHVybiBwb2x5ZmlsbChlbGVtZW50KTtcbiAgfVxuICBsZXQgcmF3T2Zmc2V0UGFyZW50ID0gZWxlbWVudC5vZmZzZXRQYXJlbnQ7XG5cbiAgLy8gRmlyZWZveCByZXR1cm5zIHRoZSA8aHRtbD4gZWxlbWVudCBhcyB0aGUgb2Zmc2V0UGFyZW50IGlmIGl0J3Mgbm9uLXN0YXRpYyxcbiAgLy8gd2hpbGUgQ2hyb21lIGFuZCBTYWZhcmkgcmV0dXJuIHRoZSA8Ym9keT4gZWxlbWVudC4gVGhlIDxib2R5PiBlbGVtZW50IG11c3RcbiAgLy8gYmUgdXNlZCB0byBwZXJmb3JtIHRoZSBjb3JyZWN0IGNhbGN1bGF0aW9ucyBldmVuIGlmIHRoZSA8aHRtbD4gZWxlbWVudCBpc1xuICAvLyBub24tc3RhdGljLlxuICBpZiAoZ2V0RG9jdW1lbnRFbGVtZW50KGVsZW1lbnQpID09PSByYXdPZmZzZXRQYXJlbnQpIHtcbiAgICByYXdPZmZzZXRQYXJlbnQgPSByYXdPZmZzZXRQYXJlbnQub3duZXJEb2N1bWVudC5ib2R5O1xuICB9XG4gIHJldHVybiByYXdPZmZzZXRQYXJlbnQ7XG59XG5cbi8vIEdldHMgdGhlIGNsb3Nlc3QgYW5jZXN0b3IgcG9zaXRpb25lZCBlbGVtZW50LiBIYW5kbGVzIHNvbWUgZWRnZSBjYXNlcyxcbi8vIHN1Y2ggYXMgdGFibGUgYW5jZXN0b3JzIGFuZCBjcm9zcyBicm93c2VyIGJ1Z3MuXG5mdW5jdGlvbiBnZXRPZmZzZXRQYXJlbnQoZWxlbWVudCwgcG9seWZpbGwpIHtcbiAgY29uc3Qgd2luID0gZ2V0V2luZG93KGVsZW1lbnQpO1xuICBpZiAoaXNUb3BMYXllcihlbGVtZW50KSkge1xuICAgIHJldHVybiB3aW47XG4gIH1cbiAgaWYgKCFpc0hUTUxFbGVtZW50KGVsZW1lbnQpKSB7XG4gICAgbGV0IHN2Z09mZnNldFBhcmVudCA9IGdldFBhcmVudE5vZGUoZWxlbWVudCk7XG4gICAgd2hpbGUgKHN2Z09mZnNldFBhcmVudCAmJiAhaXNMYXN0VHJhdmVyc2FibGVOb2RlKHN2Z09mZnNldFBhcmVudCkpIHtcbiAgICAgIGlmIChpc0VsZW1lbnQoc3ZnT2Zmc2V0UGFyZW50KSAmJiAhaXNTdGF0aWNQb3NpdGlvbmVkKHN2Z09mZnNldFBhcmVudCkpIHtcbiAgICAgICAgcmV0dXJuIHN2Z09mZnNldFBhcmVudDtcbiAgICAgIH1cbiAgICAgIHN2Z09mZnNldFBhcmVudCA9IGdldFBhcmVudE5vZGUoc3ZnT2Zmc2V0UGFyZW50KTtcbiAgICB9XG4gICAgcmV0dXJuIHdpbjtcbiAgfVxuICBsZXQgb2Zmc2V0UGFyZW50ID0gZ2V0VHJ1ZU9mZnNldFBhcmVudChlbGVtZW50LCBwb2x5ZmlsbCk7XG4gIHdoaWxlIChvZmZzZXRQYXJlbnQgJiYgaXNUYWJsZUVsZW1lbnQob2Zmc2V0UGFyZW50KSAmJiBpc1N0YXRpY1Bvc2l0aW9uZWQob2Zmc2V0UGFyZW50KSkge1xuICAgIG9mZnNldFBhcmVudCA9IGdldFRydWVPZmZzZXRQYXJlbnQob2Zmc2V0UGFyZW50LCBwb2x5ZmlsbCk7XG4gIH1cbiAgaWYgKG9mZnNldFBhcmVudCAmJiBpc0xhc3RUcmF2ZXJzYWJsZU5vZGUob2Zmc2V0UGFyZW50KSAmJiBpc1N0YXRpY1Bvc2l0aW9uZWQob2Zmc2V0UGFyZW50KSAmJiAhaXNDb250YWluaW5nQmxvY2sob2Zmc2V0UGFyZW50KSkge1xuICAgIHJldHVybiB3aW47XG4gIH1cbiAgcmV0dXJuIG9mZnNldFBhcmVudCB8fCBnZXRDb250YWluaW5nQmxvY2soZWxlbWVudCkgfHwgd2luO1xufVxuXG5jb25zdCBnZXRFbGVtZW50UmVjdHMgPSBhc3luYyBmdW5jdGlvbiAoZGF0YSkge1xuICBjb25zdCBnZXRPZmZzZXRQYXJlbnRGbiA9IHRoaXMuZ2V0T2Zmc2V0UGFyZW50IHx8IGdldE9mZnNldFBhcmVudDtcbiAgY29uc3QgZ2V0RGltZW5zaW9uc0ZuID0gdGhpcy5nZXREaW1lbnNpb25zO1xuICBjb25zdCBmbG9hdGluZ0RpbWVuc2lvbnMgPSBhd2FpdCBnZXREaW1lbnNpb25zRm4oZGF0YS5mbG9hdGluZyk7XG4gIHJldHVybiB7XG4gICAgcmVmZXJlbmNlOiBnZXRSZWN0UmVsYXRpdmVUb09mZnNldFBhcmVudChkYXRhLnJlZmVyZW5jZSwgYXdhaXQgZ2V0T2Zmc2V0UGFyZW50Rm4oZGF0YS5mbG9hdGluZyksIGRhdGEuc3RyYXRlZ3kpLFxuICAgIGZsb2F0aW5nOiB7XG4gICAgICB4OiAwLFxuICAgICAgeTogMCxcbiAgICAgIHdpZHRoOiBmbG9hdGluZ0RpbWVuc2lvbnMud2lkdGgsXG4gICAgICBoZWlnaHQ6IGZsb2F0aW5nRGltZW5zaW9ucy5oZWlnaHRcbiAgICB9XG4gIH07XG59O1xuXG5mdW5jdGlvbiBpc1JUTChlbGVtZW50KSB7XG4gIHJldHVybiBnZXRDb21wdXRlZFN0eWxlJDEoZWxlbWVudCkuZGlyZWN0aW9uID09PSAncnRsJztcbn1cblxuY29uc3QgcGxhdGZvcm0gPSB7XG4gIGNvbnZlcnRPZmZzZXRQYXJlbnRSZWxhdGl2ZVJlY3RUb1ZpZXdwb3J0UmVsYXRpdmVSZWN0LFxuICBnZXREb2N1bWVudEVsZW1lbnQsXG4gIGdldENsaXBwaW5nUmVjdCxcbiAgZ2V0T2Zmc2V0UGFyZW50LFxuICBnZXRFbGVtZW50UmVjdHMsXG4gIGdldENsaWVudFJlY3RzLFxuICBnZXREaW1lbnNpb25zLFxuICBnZXRTY2FsZSxcbiAgaXNFbGVtZW50LFxuICBpc1JUTFxufTtcblxuZnVuY3Rpb24gcmVjdHNBcmVFcXVhbChhLCBiKSB7XG4gIHJldHVybiBhLnggPT09IGIueCAmJiBhLnkgPT09IGIueSAmJiBhLndpZHRoID09PSBiLndpZHRoICYmIGEuaGVpZ2h0ID09PSBiLmhlaWdodDtcbn1cblxuLy8gaHR0cHM6Ly9zYW10aG9yLmF1LzIwMjEvb2JzZXJ2aW5nLWRvbS9cbmZ1bmN0aW9uIG9ic2VydmVNb3ZlKGVsZW1lbnQsIG9uTW92ZSwgYW5jZXN0b3JSZXNpemUpIHtcbiAgbGV0IGlvID0gbnVsbDtcbiAgbGV0IHRpbWVvdXRJZDtcbiAgY29uc3Qgcm9vdCA9IGdldERvY3VtZW50RWxlbWVudChlbGVtZW50KTtcbiAgZnVuY3Rpb24gY2xlYW51cCgpIHtcbiAgICB2YXIgX2lvO1xuICAgIGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuICAgIChfaW8gPSBpbykgPT0gbnVsbCB8fCBfaW8uZGlzY29ubmVjdCgpO1xuICAgIGlvID0gbnVsbDtcbiAgfVxuICBmdW5jdGlvbiByZWZyZXNoKHNraXAsIHRocmVzaG9sZCkge1xuICAgIGlmIChza2lwID09PSB2b2lkIDApIHtcbiAgICAgIHNraXAgPSBmYWxzZTtcbiAgICB9XG4gICAgaWYgKHRocmVzaG9sZCA9PT0gdm9pZCAwKSB7XG4gICAgICB0aHJlc2hvbGQgPSAxO1xuICAgIH1cbiAgICBjbGVhbnVwKCk7XG4gICAgY29uc3QgZWxlbWVudFJlY3RGb3JSb290TWFyZ2luID0gZWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBjb25zdCB7XG4gICAgICBsZWZ0LFxuICAgICAgdG9wLFxuICAgICAgd2lkdGgsXG4gICAgICBoZWlnaHRcbiAgICB9ID0gZWxlbWVudFJlY3RGb3JSb290TWFyZ2luO1xuICAgIGlmICghc2tpcCkge1xuICAgICAgb25Nb3ZlKCk7XG4gICAgfVxuICAgIGlmICghd2lkdGggfHwgIWhlaWdodCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBpbnNldFRvcCA9IGZsb29yKHRvcCk7XG4gICAgY29uc3QgaW5zZXRSaWdodCA9IGZsb29yKHJvb3QuY2xpZW50V2lkdGggLSAobGVmdCArIHdpZHRoKSk7XG4gICAgY29uc3QgaW5zZXRCb3R0b20gPSBmbG9vcihyb290LmNsaWVudEhlaWdodCAtICh0b3AgKyBoZWlnaHQpKTtcbiAgICBjb25zdCBpbnNldExlZnQgPSBmbG9vcihsZWZ0KTtcbiAgICBjb25zdCByb290TWFyZ2luID0gLWluc2V0VG9wICsgXCJweCBcIiArIC1pbnNldFJpZ2h0ICsgXCJweCBcIiArIC1pbnNldEJvdHRvbSArIFwicHggXCIgKyAtaW5zZXRMZWZ0ICsgXCJweFwiO1xuICAgIGNvbnN0IG9wdGlvbnMgPSB7XG4gICAgICByb290TWFyZ2luLFxuICAgICAgdGhyZXNob2xkOiBtYXgoMCwgbWluKDEsIHRocmVzaG9sZCkpIHx8IDFcbiAgICB9O1xuICAgIGxldCBpc0ZpcnN0VXBkYXRlID0gdHJ1ZTtcbiAgICBmdW5jdGlvbiBoYW5kbGVPYnNlcnZlKGVudHJpZXMpIHtcbiAgICAgIGNvbnN0IHJhdGlvID0gZW50cmllc1swXS5pbnRlcnNlY3Rpb25SYXRpbztcblxuICAgICAgLy8gVGhlIGVudHJ5IGlzIGEgc25hcHNob3QsIHNvIHRoZSByZWZlcmVuY2UgbWF5IGhhdmUgbW92ZWQgc2luY2UgdGhlXG4gICAgICAvLyBpbnRlcnNlY3Rpb24gd2FzIGNvbXB1dGVkICh1bmRlciBwZXJmb3JtYW5jZSBjb25zdHJhaW50cywgb3IgYmV0d2VlblxuICAgICAgLy8gY29uc2VjdXRpdmUgZnJhbWVzIG9mIGEgbXVsdGktZnJhbWUgbGF5b3V0IHNoaWZ0KS4gVGhlIHJlcG9ydGVkIHJhdGlvXG4gICAgICAvLyBhbmQgdGhlIG9ic2VydmVkIGFyZWEgYXJlIHN0YWxlIGluIHRoYXQgY2FzZSBhbmQgY2Fubm90IGJlIHRydXN0ZWQgdG9cbiAgICAgIC8vIGRldGVjdCBzdWJzZXF1ZW50IG1vdmVtZW50LCBzbyByZWZyZXNoIHJlZ2FyZGxlc3Mgb2YgdGhlIHJhdGlvLlxuICAgICAgaWYgKCFyZWN0c0FyZUVxdWFsKGVsZW1lbnRSZWN0Rm9yUm9vdE1hcmdpbiwgZWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSkpIHtcbiAgICAgICAgcmV0dXJuIHJlZnJlc2goKTtcbiAgICAgIH1cbiAgICAgIGlmIChyYXRpbyAhPT0gdGhyZXNob2xkKSB7XG4gICAgICAgIGlmICghaXNGaXJzdFVwZGF0ZSkge1xuICAgICAgICAgIHJldHVybiByZWZyZXNoKCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFyYXRpbykge1xuICAgICAgICAgIC8vIElmIHRoZSByZWZlcmVuY2UgaXMgY2xpcHBlZCBpbiBwbGFjZSwgdGhlIHJhdGlvIGlzIDAuIFRocm90dGxlXG4gICAgICAgICAgLy8gdGhlIHJlZnJlc2ggdG8gcHJldmVudCBhbiBpbmZpbml0ZSBsb29wIG9mIHVwZGF0ZXMuXG4gICAgICAgICAgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgICByZWZyZXNoKGZhbHNlLCAxZS03KTtcbiAgICAgICAgICB9LCAxMDAwKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZWZyZXNoKGZhbHNlLCByYXRpbyk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlzRmlyc3RVcGRhdGUgPSBmYWxzZTtcbiAgICB9XG5cbiAgICAvLyBPbGRlciBicm93c2VycyBkb24ndCBzdXBwb3J0IGEgYGRvY3VtZW50YCBhcyB0aGUgcm9vdCBhbmQgd2lsbCB0aHJvdyBhblxuICAgIC8vIGVycm9yLlxuICAgIHRyeSB7XG4gICAgICBpbyA9IG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcihoYW5kbGVPYnNlcnZlLCB7XG4gICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIC8vIEhhbmRsZSA8aWZyYW1lPnNcbiAgICAgICAgcm9vdDogcm9vdC5vd25lckRvY3VtZW50XG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChfZSkge1xuICAgICAgaW8gPSBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIoaGFuZGxlT2JzZXJ2ZSwgb3B0aW9ucyk7XG4gICAgfVxuICAgIGlvLm9ic2VydmUoZWxlbWVudCk7XG4gIH1cbiAgY29uc3Qgd2luID0gZ2V0V2luZG93KGVsZW1lbnQpO1xuICAvLyBUaGUgd2luZG93IGlzIGEgcmVzaXplIGFuY2VzdG9yLCBzbyB3aGVuIGBhbmNlc3RvclJlc2l6ZWAgaXMgZW5hYmxlZCBpdHNcbiAgLy8gbGlzdGVuZXIgYWxyZWFkeSBydW5zIHRoZSB1cGRhdGUgb24gcmVzaXplLiBIZXJlIHdlIG9ubHkgbmVlZCB0byByZWJ1aWxkXG4gIC8vIHRoZSBgSW50ZXJzZWN0aW9uT2JzZXJ2ZXJgIGZvciB0aGUgbmV3IHJvb3Qgc2l6ZSwgc2tpcHBpbmcgYSByZWR1bmRhbnRcbiAgLy8gdXBkYXRlLiBXaGVuIGBhbmNlc3RvclJlc2l6ZWAgaXMgZGlzYWJsZWQsIHRoaXMgYmVjb21lcyB0aGUgc29sZSB1cGRhdGUuXG4gIGNvbnN0IGhhbmRsZVJlc2l6ZSA9ICgpID0+IHJlZnJlc2goYW5jZXN0b3JSZXNpemUpO1xuICB3aW4uYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgaGFuZGxlUmVzaXplKTtcbiAgcmVmcmVzaCh0cnVlKTtcbiAgcmV0dXJuICgpID0+IHtcbiAgICB3aW4ucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgaGFuZGxlUmVzaXplKTtcbiAgICBjbGVhbnVwKCk7XG4gIH07XG59XG5cbi8qKlxuICogQXV0b21hdGljYWxseSB1cGRhdGVzIHRoZSBwb3NpdGlvbiBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCB3aGVuIG5lY2Vzc2FyeS5cbiAqIFNob3VsZCBvbmx5IGJlIGNhbGxlZCB3aGVuIHRoZSBmbG9hdGluZyBlbGVtZW50IGlzIG1vdW50ZWQgb24gdGhlIERPTSBvclxuICogdmlzaWJsZSBvbiB0aGUgc2NyZWVuLlxuICogQHJldHVybnMgY2xlYW51cCBmdW5jdGlvbiB0aGF0IHNob3VsZCBiZSBpbnZva2VkIHdoZW4gdGhlIGZsb2F0aW5nIGVsZW1lbnQgaXNcbiAqIHJlbW92ZWQgZnJvbSB0aGUgRE9NIG9yIGhpZGRlbiBmcm9tIHRoZSBzY3JlZW4uXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvYXV0b1VwZGF0ZVxuICovXG5mdW5jdGlvbiBhdXRvVXBkYXRlKHJlZmVyZW5jZSwgZmxvYXRpbmcsIHVwZGF0ZSwgb3B0aW9ucykge1xuICBpZiAob3B0aW9ucyA9PT0gdm9pZCAwKSB7XG4gICAgb3B0aW9ucyA9IHt9O1xuICB9XG4gIGNvbnN0IHtcbiAgICBhbmNlc3RvclNjcm9sbCA9IHRydWUsXG4gICAgYW5jZXN0b3JSZXNpemUgPSB0cnVlLFxuICAgIGVsZW1lbnRSZXNpemUgPSB0eXBlb2YgUmVzaXplT2JzZXJ2ZXIgPT09ICdmdW5jdGlvbicsXG4gICAgbGF5b3V0U2hpZnQgPSB0eXBlb2YgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgPT09ICdmdW5jdGlvbicsXG4gICAgYW5pbWF0aW9uRnJhbWUgPSBmYWxzZVxuICB9ID0gb3B0aW9ucztcbiAgY29uc3QgcmVmZXJlbmNlRWwgPSB1bndyYXBFbGVtZW50KHJlZmVyZW5jZSk7XG4gIGNvbnN0IGFuY2VzdG9ycyA9IGFuY2VzdG9yU2Nyb2xsIHx8IGFuY2VzdG9yUmVzaXplID8gWy4uLihyZWZlcmVuY2VFbCA/IGdldE92ZXJmbG93QW5jZXN0b3JzKHJlZmVyZW5jZUVsKSA6IFtdKSwgLi4uKGZsb2F0aW5nID8gZ2V0T3ZlcmZsb3dBbmNlc3RvcnMoZmxvYXRpbmcpIDogW10pXSA6IFtdO1xuICBhbmNlc3RvcnMuZm9yRWFjaChhbmNlc3RvciA9PiB7XG4gICAgYW5jZXN0b3JTY3JvbGwgJiYgYW5jZXN0b3IuYWRkRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgdXBkYXRlKTtcbiAgICBhbmNlc3RvclJlc2l6ZSAmJiBhbmNlc3Rvci5hZGRFdmVudExpc3RlbmVyKCdyZXNpemUnLCB1cGRhdGUpO1xuICB9KTtcbiAgY29uc3QgY2xlYW51cElvID0gcmVmZXJlbmNlRWwgJiYgbGF5b3V0U2hpZnQgPyBvYnNlcnZlTW92ZShyZWZlcmVuY2VFbCwgdXBkYXRlLCBhbmNlc3RvclJlc2l6ZSkgOiBudWxsO1xuICBsZXQgcmVvYnNlcnZlRnJhbWUgPSAtMTtcbiAgbGV0IHJlc2l6ZU9ic2VydmVyID0gbnVsbDtcbiAgaWYgKGVsZW1lbnRSZXNpemUpIHtcbiAgICByZXNpemVPYnNlcnZlciA9IG5ldyBSZXNpemVPYnNlcnZlcihfcmVmID0+IHtcbiAgICAgIGxldCBbZmlyc3RFbnRyeV0gPSBfcmVmO1xuICAgICAgaWYgKGZpcnN0RW50cnkgJiYgZmlyc3RFbnRyeS50YXJnZXQgPT09IHJlZmVyZW5jZUVsICYmIHJlc2l6ZU9ic2VydmVyICYmIGZsb2F0aW5nKSB7XG4gICAgICAgIC8vIFByZXZlbnQgdXBkYXRlIGxvb3BzIHdoZW4gdXNpbmcgdGhlIGBzaXplYCBtaWRkbGV3YXJlLlxuICAgICAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vZmxvYXRpbmctdWkvZmxvYXRpbmctdWkvaXNzdWVzLzE3NDBcbiAgICAgICAgcmVzaXplT2JzZXJ2ZXIudW5vYnNlcnZlKGZsb2F0aW5nKTtcbiAgICAgICAgY2FuY2VsQW5pbWF0aW9uRnJhbWUocmVvYnNlcnZlRnJhbWUpO1xuICAgICAgICByZW9ic2VydmVGcmFtZSA9IHJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICAgICAgdmFyIF9yZXNpemVPYnNlcnZlcjtcbiAgICAgICAgICAoX3Jlc2l6ZU9ic2VydmVyID0gcmVzaXplT2JzZXJ2ZXIpID09IG51bGwgfHwgX3Jlc2l6ZU9ic2VydmVyLm9ic2VydmUoZmxvYXRpbmcpO1xuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHVwZGF0ZSgpO1xuICAgIH0pO1xuICAgIGlmIChyZWZlcmVuY2VFbCAmJiAhYW5pbWF0aW9uRnJhbWUpIHtcbiAgICAgIHJlc2l6ZU9ic2VydmVyLm9ic2VydmUocmVmZXJlbmNlRWwpO1xuICAgIH1cbiAgICBpZiAoZmxvYXRpbmcpIHtcbiAgICAgIHJlc2l6ZU9ic2VydmVyLm9ic2VydmUoZmxvYXRpbmcpO1xuICAgIH1cbiAgfVxuICBsZXQgZnJhbWVJZDtcbiAgbGV0IHByZXZSZWZSZWN0ID0gYW5pbWF0aW9uRnJhbWUgPyBnZXRCb3VuZGluZ0NsaWVudFJlY3QocmVmZXJlbmNlKSA6IG51bGw7XG4gIGlmIChhbmltYXRpb25GcmFtZSkge1xuICAgIGZyYW1lTG9vcCgpO1xuICB9XG4gIGZ1bmN0aW9uIGZyYW1lTG9vcCgpIHtcbiAgICBjb25zdCBuZXh0UmVmUmVjdCA9IGdldEJvdW5kaW5nQ2xpZW50UmVjdChyZWZlcmVuY2UpO1xuICAgIGlmIChwcmV2UmVmUmVjdCAmJiAhcmVjdHNBcmVFcXVhbChwcmV2UmVmUmVjdCwgbmV4dFJlZlJlY3QpKSB7XG4gICAgICB1cGRhdGUoKTtcbiAgICB9XG4gICAgcHJldlJlZlJlY3QgPSBuZXh0UmVmUmVjdDtcbiAgICBmcmFtZUlkID0gcmVxdWVzdEFuaW1hdGlvbkZyYW1lKGZyYW1lTG9vcCk7XG4gIH1cbiAgdXBkYXRlKCk7XG4gIHJldHVybiAoKSA9PiB7XG4gICAgdmFyIF9yZXNpemVPYnNlcnZlcjI7XG4gICAgYW5jZXN0b3JzLmZvckVhY2goYW5jZXN0b3IgPT4ge1xuICAgICAgYW5jZXN0b3JTY3JvbGwgJiYgYW5jZXN0b3IucmVtb3ZlRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgdXBkYXRlKTtcbiAgICAgIGFuY2VzdG9yUmVzaXplICYmIGFuY2VzdG9yLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Jlc2l6ZScsIHVwZGF0ZSk7XG4gICAgfSk7XG4gICAgY2xlYW51cElvID09IG51bGwgfHwgY2xlYW51cElvKCk7XG4gICAgKF9yZXNpemVPYnNlcnZlcjIgPSByZXNpemVPYnNlcnZlcikgPT0gbnVsbCB8fCBfcmVzaXplT2JzZXJ2ZXIyLmRpc2Nvbm5lY3QoKTtcbiAgICByZXNpemVPYnNlcnZlciA9IG51bGw7XG4gICAgaWYgKGFuaW1hdGlvbkZyYW1lKSB7XG4gICAgICBjYW5jZWxBbmltYXRpb25GcmFtZShmcmFtZUlkKTtcbiAgICB9XG4gIH07XG59XG5cbi8qKlxuICogUmVzb2x2ZXMgd2l0aCBhbiBvYmplY3Qgb2Ygb3ZlcmZsb3cgc2lkZSBvZmZzZXRzIHRoYXQgZGV0ZXJtaW5lIGhvdyBtdWNoIHRoZVxuICogZWxlbWVudCBpcyBvdmVyZmxvd2luZyBhIGdpdmVuIGNsaXBwaW5nIGJvdW5kYXJ5IG9uIGVhY2ggc2lkZS5cbiAqIC0gcG9zaXRpdmUgPSBvdmVyZmxvd2luZyB0aGUgYm91bmRhcnkgYnkgdGhhdCBudW1iZXIgb2YgcGl4ZWxzXG4gKiAtIG5lZ2F0aXZlID0gaG93IG1hbnkgcGl4ZWxzIGxlZnQgYmVmb3JlIGl0IHdpbGwgb3ZlcmZsb3dcbiAqIC0gMCA9IGxpZXMgZmx1c2ggd2l0aCB0aGUgYm91bmRhcnlcbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9kZXRlY3RPdmVyZmxvd1xuICovXG5jb25zdCBkZXRlY3RPdmVyZmxvdyA9IGRldGVjdE92ZXJmbG93JDE7XG5cbi8qKlxuICogTW9kaWZpZXMgdGhlIHBsYWNlbWVudCBieSB0cmFuc2xhdGluZyB0aGUgZmxvYXRpbmcgZWxlbWVudCBhbG9uZyB0aGVcbiAqIHNwZWNpZmllZCBheGVzLlxuICogQSBudW1iZXIgKHNob3J0aGFuZCBmb3IgYG1haW5BeGlzYCBvciBkaXN0YW5jZSksIG9yIGFuIGF4ZXMgY29uZmlndXJhdGlvblxuICogb2JqZWN0IG1heSBiZSBwYXNzZWQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3Mvb2Zmc2V0XG4gKi9cbmNvbnN0IG9mZnNldCA9IG9mZnNldCQxO1xuXG4vKipcbiAqIE9wdGltaXplcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBieSBjaG9vc2luZyB0aGUgcGxhY2VtZW50XG4gKiB0aGF0IGhhcyB0aGUgbW9zdCBzcGFjZSBhdmFpbGFibGUgYXV0b21hdGljYWxseSwgd2l0aG91dCBuZWVkaW5nIHRvIHNwZWNpZnkgYVxuICogcHJlZmVycmVkIHBsYWNlbWVudC4gQWx0ZXJuYXRpdmUgdG8gYGZsaXBgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2F1dG9QbGFjZW1lbnRcbiAqL1xuY29uc3QgYXV0b1BsYWNlbWVudCA9IGF1dG9QbGFjZW1lbnQkMTtcblxuLyoqXG4gKiBPcHRpbWl6ZXMgdGhlIHZpc2liaWxpdHkgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgYnkgc2hpZnRpbmcgaXQgaW4gb3JkZXIgdG9cbiAqIGtlZXAgaXQgaW4gdmlldyB3aGVuIGl0IHdpbGwgb3ZlcmZsb3cgdGhlIGNsaXBwaW5nIGJvdW5kYXJ5LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL3NoaWZ0XG4gKi9cbmNvbnN0IHNoaWZ0ID0gc2hpZnQkMTtcblxuLyoqXG4gKiBPcHRpbWl6ZXMgdGhlIHZpc2liaWxpdHkgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgYnkgZmxpcHBpbmcgdGhlIGBwbGFjZW1lbnRgXG4gKiBpbiBvcmRlciB0byBrZWVwIGl0IGluIHZpZXcgd2hlbiB0aGUgcHJlZmVycmVkIHBsYWNlbWVudChzKSB3aWxsIG92ZXJmbG93IHRoZVxuICogY2xpcHBpbmcgYm91bmRhcnkuIEFsdGVybmF0aXZlIHRvIGBhdXRvUGxhY2VtZW50YC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9mbGlwXG4gKi9cbmNvbnN0IGZsaXAgPSBmbGlwJDE7XG5cbi8qKlxuICogUHJvdmlkZXMgZGF0YSB0aGF0IGFsbG93cyB5b3UgdG8gY2hhbmdlIHRoZSBzaXplIG9mIHRoZSBmbG9hdGluZyBlbGVtZW50IOKAlFxuICogZm9yIGluc3RhbmNlLCBwcmV2ZW50IGl0IGZyb20gb3ZlcmZsb3dpbmcgdGhlIGNsaXBwaW5nIGJvdW5kYXJ5IG9yIG1hdGNoIHRoZVxuICogd2lkdGggb2YgdGhlIHJlZmVyZW5jZSBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL3NpemVcbiAqL1xuY29uc3Qgc2l6ZSA9IHNpemUkMTtcblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRvIGhpZGUgdGhlIGZsb2F0aW5nIGVsZW1lbnQgaW4gYXBwbGljYWJsZSBzaXR1YXRpb25zLCBzdWNoIGFzXG4gKiB3aGVuIGl0IGlzIG5vdCBpbiB0aGUgc2FtZSBjbGlwcGluZyBjb250ZXh0IGFzIHRoZSByZWZlcmVuY2UgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9oaWRlXG4gKi9cbmNvbnN0IGhpZGUgPSBoaWRlJDE7XG5cbi8qKlxuICogUHJvdmlkZXMgZGF0YSB0byBwb3NpdGlvbiBhbiBpbm5lciBlbGVtZW50IG9mIHRoZSBmbG9hdGluZyBlbGVtZW50IHNvIHRoYXQgaXRcbiAqIGFwcGVhcnMgY2VudGVyZWQgdG8gdGhlIHJlZmVyZW5jZSBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2Fycm93XG4gKi9cbmNvbnN0IGFycm93ID0gYXJyb3ckMTtcblxuLyoqXG4gKiBQcm92aWRlcyBpbXByb3ZlZCBwb3NpdGlvbmluZyBmb3IgaW5saW5lIHJlZmVyZW5jZSBlbGVtZW50cyB0aGF0IGNhbiBzcGFuXG4gKiBvdmVyIG11bHRpcGxlIGxpbmVzLCBzdWNoIGFzIGh5cGVybGlua3Mgb3IgcmFuZ2Ugc2VsZWN0aW9ucy5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9pbmxpbmVcbiAqL1xuY29uc3QgaW5saW5lID0gaW5saW5lJDE7XG5cbi8qKlxuICogQnVpbHQtaW4gYGxpbWl0ZXJgIHRoYXQgd2lsbCBzdG9wIGBzaGlmdCgpYCBhdCBhIGNlcnRhaW4gcG9pbnQuXG4gKi9cbmNvbnN0IGxpbWl0U2hpZnQgPSBsaW1pdFNoaWZ0JDE7XG5cbi8qKlxuICogQ29tcHV0ZXMgdGhlIGB4YCBhbmQgYHlgIGNvb3JkaW5hdGVzIHRoYXQgd2lsbCBwbGFjZSB0aGUgZmxvYXRpbmcgZWxlbWVudFxuICogbmV4dCB0byBhIGdpdmVuIHJlZmVyZW5jZSBlbGVtZW50LlxuICovXG5jb25zdCBjb21wdXRlUG9zaXRpb24gPSAocmVmZXJlbmNlLCBmbG9hdGluZywgb3B0aW9ucykgPT4ge1xuICAvLyBUaGlzIGNhY2hlcyB0aGUgZXhwZW5zaXZlIGBnZXRDbGlwcGluZ0VsZW1lbnRBbmNlc3RvcnNgIGZ1bmN0aW9uIHNvIHRoYXRcbiAgLy8gbXVsdGlwbGUgbGlmZWN5Y2xlIHJlc2V0cyByZS11c2UgdGhlIHNhbWUgcmVzdWx0LiBJdCBvbmx5IGxpdmVzIGZvciBhXG4gIC8vIHNpbmdsZSBjYWxsLiBJZiBvdGhlciBmdW5jdGlvbnMgYmVjb21lIGV4cGVuc2l2ZSwgd2UgY2FuIGFkZCB0aGVtIGFzIHdlbGwuXG4gIGNvbnN0IGNhY2hlID0gbmV3IE1hcCgpO1xuICBjb25zdCBtZXJnZWRPcHRpb25zID0gb3B0aW9ucyAhPSBudWxsID8gb3B0aW9ucyA6IHt9O1xuICBjb25zdCBwbGF0Zm9ybVdpdGhDYWNoZSA9IHtcbiAgICAuLi5wbGF0Zm9ybSxcbiAgICAuLi5tZXJnZWRPcHRpb25zLnBsYXRmb3JtLFxuICAgIF9jOiBjYWNoZVxuICB9O1xuICByZXR1cm4gY29tcHV0ZVBvc2l0aW9uJDEocmVmZXJlbmNlLCBmbG9hdGluZywge1xuICAgIC4uLm1lcmdlZE9wdGlvbnMsXG4gICAgcGxhdGZvcm06IHBsYXRmb3JtV2l0aENhY2hlXG4gIH0pO1xufTtcblxuZXhwb3J0IHsgYXJyb3csIGF1dG9QbGFjZW1lbnQsIGF1dG9VcGRhdGUsIGNvbXB1dGVQb3NpdGlvbiwgZGV0ZWN0T3ZlcmZsb3csIGZsaXAsIGhpZGUsIGlubGluZSwgbGltaXRTaGlmdCwgb2Zmc2V0LCBwbGF0Zm9ybSwgc2hpZnQsIHNpemUgfTtcbiIsImltcG9ydCB7IGNvbXB1dGVQb3NpdGlvbiwgYXJyb3cgYXMgYXJyb3ckMiwgYXV0b1BsYWNlbWVudCBhcyBhdXRvUGxhY2VtZW50JDEsIGZsaXAgYXMgZmxpcCQxLCBoaWRlIGFzIGhpZGUkMSwgaW5saW5lIGFzIGlubGluZSQxLCBsaW1pdFNoaWZ0IGFzIGxpbWl0U2hpZnQkMSwgb2Zmc2V0IGFzIG9mZnNldCQxLCBzaGlmdCBhcyBzaGlmdCQxLCBzaXplIGFzIHNpemUkMSB9IGZyb20gJ0BmbG9hdGluZy11aS9kb20nO1xuZXhwb3J0IHsgYXV0b1VwZGF0ZSwgY29tcHV0ZVBvc2l0aW9uLCBkZXRlY3RPdmVyZmxvdywgZ2V0T3ZlcmZsb3dBbmNlc3RvcnMsIHBsYXRmb3JtIH0gZnJvbSAnQGZsb2F0aW5nLXVpL2RvbSc7XG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VMYXlvdXRFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgKiBhcyBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20nO1xuXG52YXIgaXNDbGllbnQgPSB0eXBlb2YgZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnO1xuXG52YXIgbm9vcCA9IGZ1bmN0aW9uIG5vb3AoKSB7fTtcbnZhciBpbmRleCA9IGlzQ2xpZW50ID8gdXNlTGF5b3V0RWZmZWN0IDogbm9vcDtcblxuLy8gRm9yayBvZiBgZmFzdC1kZWVwLWVxdWFsYCB0aGF0IG9ubHkgZG9lcyB0aGUgY29tcGFyaXNvbnMgd2UgbmVlZCBhbmQgY29tcGFyZXNcbi8vIGZ1bmN0aW9uc1xuZnVuY3Rpb24gZGVlcEVxdWFsKGEsIGIpIHtcbiAgaWYgKGEgPT09IGIpIHtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBpZiAodHlwZW9mIGEgIT09IHR5cGVvZiBiKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIGlmICh0eXBlb2YgYSA9PT0gJ2Z1bmN0aW9uJyAmJiBhLnRvU3RyaW5nKCkgPT09IGIudG9TdHJpbmcoKSkge1xuICAgIHJldHVybiB0cnVlO1xuICB9XG4gIGxldCBsZW5ndGg7XG4gIGxldCBpO1xuICBsZXQga2V5cztcbiAgaWYgKGEgJiYgYiAmJiB0eXBlb2YgYSA9PT0gJ29iamVjdCcpIHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShhKSkge1xuICAgICAgbGVuZ3RoID0gYS5sZW5ndGg7XG4gICAgICBpZiAobGVuZ3RoICE9PSBiLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuICAgICAgZm9yIChpID0gbGVuZ3RoOyBpLS0gIT09IDA7KSB7XG4gICAgICAgIGlmICghZGVlcEVxdWFsKGFbaV0sIGJbaV0pKSB7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAga2V5cyA9IE9iamVjdC5rZXlzKGEpO1xuICAgIGxlbmd0aCA9IGtleXMubGVuZ3RoO1xuICAgIGlmIChsZW5ndGggIT09IE9iamVjdC5rZXlzKGIpLmxlbmd0aCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBmb3IgKGkgPSBsZW5ndGg7IGktLSAhPT0gMDspIHtcbiAgICAgIGlmICghe30uaGFzT3duUHJvcGVydHkuY2FsbChiLCBrZXlzW2ldKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgfVxuICAgIGZvciAoaSA9IGxlbmd0aDsgaS0tICE9PSAwOykge1xuICAgICAgY29uc3Qga2V5ID0ga2V5c1tpXTtcbiAgICAgIGlmIChrZXkgPT09ICdfb3duZXInICYmIGEuJCR0eXBlb2YpIHtcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG4gICAgICBpZiAoIWRlZXBFcXVhbChhW2tleV0sIGJba2V5XSkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICByZXR1cm4gYSAhPT0gYSAmJiBiICE9PSBiO1xufVxuXG5mdW5jdGlvbiBnZXREUFIoZWxlbWVudCkge1xuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gMTtcbiAgfVxuICBjb25zdCB3aW4gPSBlbGVtZW50Lm93bmVyRG9jdW1lbnQuZGVmYXVsdFZpZXcgfHwgd2luZG93O1xuICByZXR1cm4gd2luLmRldmljZVBpeGVsUmF0aW8gfHwgMTtcbn1cblxuZnVuY3Rpb24gcm91bmRCeURQUihlbGVtZW50LCB2YWx1ZSkge1xuICBjb25zdCBkcHIgPSBnZXREUFIoZWxlbWVudCk7XG4gIHJldHVybiBNYXRoLnJvdW5kKHZhbHVlICogZHByKSAvIGRwcjtcbn1cblxuZnVuY3Rpb24gdXNlTGF0ZXN0UmVmKHZhbHVlKSB7XG4gIGNvbnN0IHJlZiA9IFJlYWN0LnVzZVJlZih2YWx1ZSk7XG4gIGluZGV4KCgpID0+IHtcbiAgICByZWYuY3VycmVudCA9IHZhbHVlO1xuICB9KTtcbiAgcmV0dXJuIHJlZjtcbn1cblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRvIHBvc2l0aW9uIGEgZmxvYXRpbmcgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy91c2VGbG9hdGluZ1xuICovXG5mdW5jdGlvbiB1c2VGbG9hdGluZyhvcHRpb25zKSB7XG4gIGlmIChvcHRpb25zID09PSB2b2lkIDApIHtcbiAgICBvcHRpb25zID0ge307XG4gIH1cbiAgY29uc3Qge1xuICAgIHBsYWNlbWVudCA9ICdib3R0b20nLFxuICAgIHN0cmF0ZWd5ID0gJ2Fic29sdXRlJyxcbiAgICBtaWRkbGV3YXJlID0gW10sXG4gICAgcGxhdGZvcm0sXG4gICAgZWxlbWVudHM6IHtcbiAgICAgIHJlZmVyZW5jZTogZXh0ZXJuYWxSZWZlcmVuY2UsXG4gICAgICBmbG9hdGluZzogZXh0ZXJuYWxGbG9hdGluZ1xuICAgIH0gPSB7fSxcbiAgICB0cmFuc2Zvcm0gPSB0cnVlLFxuICAgIHdoaWxlRWxlbWVudHNNb3VudGVkLFxuICAgIG9wZW5cbiAgfSA9IG9wdGlvbnM7XG4gIGNvbnN0IFtkYXRhLCBzZXREYXRhXSA9IFJlYWN0LnVzZVN0YXRlKHtcbiAgICB4OiAwLFxuICAgIHk6IDAsXG4gICAgc3RyYXRlZ3ksXG4gICAgcGxhY2VtZW50LFxuICAgIG1pZGRsZXdhcmVEYXRhOiB7fSxcbiAgICBpc1Bvc2l0aW9uZWQ6IGZhbHNlXG4gIH0pO1xuICBjb25zdCBbbGF0ZXN0TWlkZGxld2FyZSwgc2V0TGF0ZXN0TWlkZGxld2FyZV0gPSBSZWFjdC51c2VTdGF0ZShtaWRkbGV3YXJlKTtcbiAgaWYgKCFkZWVwRXF1YWwobGF0ZXN0TWlkZGxld2FyZSwgbWlkZGxld2FyZSkpIHtcbiAgICBzZXRMYXRlc3RNaWRkbGV3YXJlKG1pZGRsZXdhcmUpO1xuICB9XG4gIGNvbnN0IFtfcmVmZXJlbmNlLCBfc2V0UmVmZXJlbmNlXSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBbX2Zsb2F0aW5nLCBfc2V0RmxvYXRpbmddID0gUmVhY3QudXNlU3RhdGUobnVsbCk7XG4gIGNvbnN0IHNldFJlZmVyZW5jZSA9IFJlYWN0LnVzZUNhbGxiYWNrKG5vZGUgPT4ge1xuICAgIGlmIChub2RlICE9PSByZWZlcmVuY2VSZWYuY3VycmVudCkge1xuICAgICAgcmVmZXJlbmNlUmVmLmN1cnJlbnQgPSBub2RlO1xuICAgICAgX3NldFJlZmVyZW5jZShub2RlKTtcbiAgICB9XG4gIH0sIFtdKTtcbiAgY29uc3Qgc2V0RmxvYXRpbmcgPSBSZWFjdC51c2VDYWxsYmFjayhub2RlID0+IHtcbiAgICBpZiAobm9kZSAhPT0gZmxvYXRpbmdSZWYuY3VycmVudCkge1xuICAgICAgZmxvYXRpbmdSZWYuY3VycmVudCA9IG5vZGU7XG4gICAgICBfc2V0RmxvYXRpbmcobm9kZSk7XG4gICAgfVxuICB9LCBbXSk7XG4gIGNvbnN0IHJlZmVyZW5jZUVsID0gZXh0ZXJuYWxSZWZlcmVuY2UgfHwgX3JlZmVyZW5jZTtcbiAgY29uc3QgZmxvYXRpbmdFbCA9IGV4dGVybmFsRmxvYXRpbmcgfHwgX2Zsb2F0aW5nO1xuICBjb25zdCByZWZlcmVuY2VSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IGZsb2F0aW5nUmVmID0gUmVhY3QudXNlUmVmKG51bGwpO1xuICBjb25zdCBkYXRhUmVmID0gUmVhY3QudXNlUmVmKGRhdGEpO1xuICBjb25zdCBoYXNXaGlsZUVsZW1lbnRzTW91bnRlZCA9IHdoaWxlRWxlbWVudHNNb3VudGVkICE9IG51bGw7XG4gIGNvbnN0IHdoaWxlRWxlbWVudHNNb3VudGVkUmVmID0gdXNlTGF0ZXN0UmVmKHdoaWxlRWxlbWVudHNNb3VudGVkKTtcbiAgY29uc3QgcGxhdGZvcm1SZWYgPSB1c2VMYXRlc3RSZWYocGxhdGZvcm0pO1xuICBjb25zdCBvcGVuUmVmID0gdXNlTGF0ZXN0UmVmKG9wZW4pO1xuICBjb25zdCB1cGRhdGUgPSBSZWFjdC51c2VDYWxsYmFjaygoKSA9PiB7XG4gICAgaWYgKCFyZWZlcmVuY2VSZWYuY3VycmVudCB8fCAhZmxvYXRpbmdSZWYuY3VycmVudCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjb25maWcgPSB7XG4gICAgICBwbGFjZW1lbnQsXG4gICAgICBzdHJhdGVneSxcbiAgICAgIG1pZGRsZXdhcmU6IGxhdGVzdE1pZGRsZXdhcmVcbiAgICB9O1xuICAgIGlmIChwbGF0Zm9ybVJlZi5jdXJyZW50KSB7XG4gICAgICBjb25maWcucGxhdGZvcm0gPSBwbGF0Zm9ybVJlZi5jdXJyZW50O1xuICAgIH1cbiAgICBjb21wdXRlUG9zaXRpb24ocmVmZXJlbmNlUmVmLmN1cnJlbnQsIGZsb2F0aW5nUmVmLmN1cnJlbnQsIGNvbmZpZykudGhlbihkYXRhID0+IHtcbiAgICAgIGNvbnN0IGZ1bGxEYXRhID0ge1xuICAgICAgICAuLi5kYXRhLFxuICAgICAgICAvLyBUaGUgZmxvYXRpbmcgZWxlbWVudCdzIHBvc2l0aW9uIG1heSBiZSByZWNvbXB1dGVkIHdoaWxlIGl0J3MgY2xvc2VkXG4gICAgICAgIC8vIGJ1dCBzdGlsbCBtb3VudGVkIChzdWNoIGFzIHdoZW4gdHJhbnNpdGlvbmluZyBvdXQpLiBUbyBlbnN1cmVcbiAgICAgICAgLy8gYGlzUG9zaXRpb25lZGAgd2lsbCBiZSBgZmFsc2VgIGluaXRpYWxseSBvbiB0aGUgbmV4dCBvcGVuLCBhdm9pZFxuICAgICAgICAvLyBzZXR0aW5nIGl0IHRvIGB0cnVlYCB3aGVuIGBvcGVuID09PSBmYWxzZWAgKG11c3QgYmUgc3BlY2lmaWVkKS5cbiAgICAgICAgaXNQb3NpdGlvbmVkOiBvcGVuUmVmLmN1cnJlbnQgIT09IGZhbHNlXG4gICAgICB9O1xuICAgICAgaWYgKGlzTW91bnRlZFJlZi5jdXJyZW50ICYmICFkZWVwRXF1YWwoZGF0YVJlZi5jdXJyZW50LCBmdWxsRGF0YSkpIHtcbiAgICAgICAgZGF0YVJlZi5jdXJyZW50ID0gZnVsbERhdGE7XG4gICAgICAgIFJlYWN0RE9NLmZsdXNoU3luYygoKSA9PiB7XG4gICAgICAgICAgc2V0RGF0YShmdWxsRGF0YSk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICB9LCBbbGF0ZXN0TWlkZGxld2FyZSwgcGxhY2VtZW50LCBzdHJhdGVneSwgcGxhdGZvcm1SZWYsIG9wZW5SZWZdKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlmIChvcGVuID09PSBmYWxzZSAmJiBkYXRhUmVmLmN1cnJlbnQuaXNQb3NpdGlvbmVkKSB7XG4gICAgICBkYXRhUmVmLmN1cnJlbnQuaXNQb3NpdGlvbmVkID0gZmFsc2U7XG4gICAgICBzZXREYXRhKGRhdGEgPT4gKHtcbiAgICAgICAgLi4uZGF0YSxcbiAgICAgICAgaXNQb3NpdGlvbmVkOiBmYWxzZVxuICAgICAgfSkpO1xuICAgIH1cbiAgfSwgW29wZW5dKTtcbiAgY29uc3QgaXNNb3VudGVkUmVmID0gUmVhY3QudXNlUmVmKGZhbHNlKTtcbiAgaW5kZXgoKCkgPT4ge1xuICAgIGlzTW91bnRlZFJlZi5jdXJyZW50ID0gdHJ1ZTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgaXNNb3VudGVkUmVmLmN1cnJlbnQgPSBmYWxzZTtcbiAgICB9O1xuICB9LCBbXSk7XG4gIGluZGV4KCgpID0+IHtcbiAgICBpZiAocmVmZXJlbmNlRWwpIHJlZmVyZW5jZVJlZi5jdXJyZW50ID0gcmVmZXJlbmNlRWw7XG4gICAgaWYgKGZsb2F0aW5nRWwpIGZsb2F0aW5nUmVmLmN1cnJlbnQgPSBmbG9hdGluZ0VsO1xuICAgIGlmIChyZWZlcmVuY2VFbCAmJiBmbG9hdGluZ0VsKSB7XG4gICAgICBpZiAod2hpbGVFbGVtZW50c01vdW50ZWRSZWYuY3VycmVudCkge1xuICAgICAgICByZXR1cm4gd2hpbGVFbGVtZW50c01vdW50ZWRSZWYuY3VycmVudChyZWZlcmVuY2VFbCwgZmxvYXRpbmdFbCwgdXBkYXRlKTtcbiAgICAgIH1cbiAgICAgIHVwZGF0ZSgpO1xuICAgIH1cbiAgfSwgW3JlZmVyZW5jZUVsLCBmbG9hdGluZ0VsLCB1cGRhdGUsIHdoaWxlRWxlbWVudHNNb3VudGVkUmVmLCBoYXNXaGlsZUVsZW1lbnRzTW91bnRlZF0pO1xuICBjb25zdCByZWZzID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIHJlZmVyZW5jZTogcmVmZXJlbmNlUmVmLFxuICAgIGZsb2F0aW5nOiBmbG9hdGluZ1JlZixcbiAgICBzZXRSZWZlcmVuY2UsXG4gICAgc2V0RmxvYXRpbmdcbiAgfSksIFtzZXRSZWZlcmVuY2UsIHNldEZsb2F0aW5nXSk7XG4gIGNvbnN0IGVsZW1lbnRzID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIHJlZmVyZW5jZTogcmVmZXJlbmNlRWwsXG4gICAgZmxvYXRpbmc6IGZsb2F0aW5nRWxcbiAgfSksIFtyZWZlcmVuY2VFbCwgZmxvYXRpbmdFbF0pO1xuICBjb25zdCBmbG9hdGluZ1N0eWxlcyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4ge1xuICAgIGNvbnN0IGluaXRpYWxTdHlsZXMgPSB7XG4gICAgICBwb3NpdGlvbjogc3RyYXRlZ3ksXG4gICAgICBsZWZ0OiAwLFxuICAgICAgdG9wOiAwXG4gICAgfTtcbiAgICBpZiAoIWVsZW1lbnRzLmZsb2F0aW5nKSB7XG4gICAgICByZXR1cm4gaW5pdGlhbFN0eWxlcztcbiAgICB9XG4gICAgY29uc3QgeCA9IHJvdW5kQnlEUFIoZWxlbWVudHMuZmxvYXRpbmcsIGRhdGEueCk7XG4gICAgY29uc3QgeSA9IHJvdW5kQnlEUFIoZWxlbWVudHMuZmxvYXRpbmcsIGRhdGEueSk7XG4gICAgaWYgKHRyYW5zZm9ybSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uaW5pdGlhbFN0eWxlcyxcbiAgICAgICAgdHJhbnNmb3JtOiBcInRyYW5zbGF0ZShcIiArIHggKyBcInB4LCBcIiArIHkgKyBcInB4KVwiLFxuICAgICAgICAuLi4oZ2V0RFBSKGVsZW1lbnRzLmZsb2F0aW5nKSA+PSAxLjUgJiYge1xuICAgICAgICAgIHdpbGxDaGFuZ2U6ICd0cmFuc2Zvcm0nXG4gICAgICAgIH0pXG4gICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgcG9zaXRpb246IHN0cmF0ZWd5LFxuICAgICAgbGVmdDogeCxcbiAgICAgIHRvcDogeVxuICAgIH07XG4gIH0sIFtzdHJhdGVneSwgdHJhbnNmb3JtLCBlbGVtZW50cy5mbG9hdGluZywgZGF0YS54LCBkYXRhLnldKTtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICAuLi5kYXRhLFxuICAgIHVwZGF0ZSxcbiAgICByZWZzLFxuICAgIGVsZW1lbnRzLFxuICAgIGZsb2F0aW5nU3R5bGVzXG4gIH0pLCBbZGF0YSwgdXBkYXRlLCByZWZzLCBlbGVtZW50cywgZmxvYXRpbmdTdHlsZXNdKTtcbn1cblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRvIHBvc2l0aW9uIGFuIGlubmVyIGVsZW1lbnQgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgc28gdGhhdCBpdFxuICogYXBwZWFycyBjZW50ZXJlZCB0byB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBUaGlzIHdyYXBzIHRoZSBjb3JlIGBhcnJvd2AgbWlkZGxld2FyZSB0byBhbGxvdyBSZWFjdCByZWZzIGFzIHRoZSBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2Fycm93XG4gKi9cbmNvbnN0IGFycm93JDEgPSBvcHRpb25zID0+IHtcbiAgZnVuY3Rpb24gaXNSZWYodmFsdWUpIHtcbiAgICByZXR1cm4ge30uaGFzT3duUHJvcGVydHkuY2FsbCh2YWx1ZSwgJ2N1cnJlbnQnKTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG5hbWU6ICdhcnJvdycsXG4gICAgb3B0aW9ucyxcbiAgICBmbihzdGF0ZSkge1xuICAgICAgY29uc3Qge1xuICAgICAgICBlbGVtZW50LFxuICAgICAgICBwYWRkaW5nXG4gICAgICB9ID0gdHlwZW9mIG9wdGlvbnMgPT09ICdmdW5jdGlvbicgPyBvcHRpb25zKHN0YXRlKSA6IG9wdGlvbnM7XG4gICAgICBpZiAoZWxlbWVudCAmJiBpc1JlZihlbGVtZW50KSkge1xuICAgICAgICBpZiAoZWxlbWVudC5jdXJyZW50ICE9IG51bGwpIHtcbiAgICAgICAgICByZXR1cm4gYXJyb3ckMih7XG4gICAgICAgICAgICBlbGVtZW50OiBlbGVtZW50LmN1cnJlbnQsXG4gICAgICAgICAgICBwYWRkaW5nXG4gICAgICAgICAgfSkuZm4oc3RhdGUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7fTtcbiAgICAgIH1cbiAgICAgIGlmIChlbGVtZW50KSB7XG4gICAgICAgIHJldHVybiBhcnJvdyQyKHtcbiAgICAgICAgICBlbGVtZW50LFxuICAgICAgICAgIHBhZGRpbmdcbiAgICAgICAgfSkuZm4oc3RhdGUpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgfTtcbn07XG5cbi8qKlxuICogTW9kaWZpZXMgdGhlIHBsYWNlbWVudCBieSB0cmFuc2xhdGluZyB0aGUgZmxvYXRpbmcgZWxlbWVudCBhbG9uZyB0aGVcbiAqIHNwZWNpZmllZCBheGVzLlxuICogQSBudW1iZXIgKHNob3J0aGFuZCBmb3IgYG1haW5BeGlzYCBvciBkaXN0YW5jZSksIG9yIGFuIGF4ZXMgY29uZmlndXJhdGlvblxuICogb2JqZWN0IG1heSBiZSBwYXNzZWQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3Mvb2Zmc2V0XG4gKi9cbmNvbnN0IG9mZnNldCA9IChvcHRpb25zLCBkZXBzKSA9PiB7XG4gIGNvbnN0IHJlc3VsdCA9IG9mZnNldCQxKG9wdGlvbnMpO1xuICByZXR1cm4ge1xuICAgIG5hbWU6IHJlc3VsdC5uYW1lLFxuICAgIGZuOiByZXN1bHQuZm4sXG4gICAgb3B0aW9uczogW29wdGlvbnMsIGRlcHNdXG4gIH07XG59O1xuXG4vKipcbiAqIE9wdGltaXplcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBieSBzaGlmdGluZyBpdCBpbiBvcmRlciB0b1xuICoga2VlcCBpdCBpbiB2aWV3IHdoZW4gaXQgd2lsbCBvdmVyZmxvdyB0aGUgY2xpcHBpbmcgYm91bmRhcnkuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3Mvc2hpZnRcbiAqL1xuY29uc3Qgc2hpZnQgPSAob3B0aW9ucywgZGVwcykgPT4ge1xuICBjb25zdCByZXN1bHQgPSBzaGlmdCQxKG9wdGlvbnMpO1xuICByZXR1cm4ge1xuICAgIG5hbWU6IHJlc3VsdC5uYW1lLFxuICAgIGZuOiByZXN1bHQuZm4sXG4gICAgb3B0aW9uczogW29wdGlvbnMsIGRlcHNdXG4gIH07XG59O1xuXG4vKipcbiAqIEJ1aWx0LWluIGBsaW1pdGVyYCB0aGF0IHdpbGwgc3RvcCBgc2hpZnQoKWAgYXQgYSBjZXJ0YWluIHBvaW50LlxuICovXG5jb25zdCBsaW1pdFNoaWZ0ID0gKG9wdGlvbnMsIGRlcHMpID0+IHtcbiAgY29uc3QgcmVzdWx0ID0gbGltaXRTaGlmdCQxKG9wdGlvbnMpO1xuICByZXR1cm4ge1xuICAgIGZuOiByZXN1bHQuZm4sXG4gICAgb3B0aW9uczogW29wdGlvbnMsIGRlcHNdXG4gIH07XG59O1xuXG4vKipcbiAqIE9wdGltaXplcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBieSBmbGlwcGluZyB0aGUgYHBsYWNlbWVudGBcbiAqIGluIG9yZGVyIHRvIGtlZXAgaXQgaW4gdmlldyB3aGVuIHRoZSBwcmVmZXJyZWQgcGxhY2VtZW50KHMpIHdpbGwgb3ZlcmZsb3cgdGhlXG4gKiBjbGlwcGluZyBib3VuZGFyeS4gQWx0ZXJuYXRpdmUgdG8gYGF1dG9QbGFjZW1lbnRgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2ZsaXBcbiAqL1xuY29uc3QgZmxpcCA9IChvcHRpb25zLCBkZXBzKSA9PiB7XG4gIGNvbnN0IHJlc3VsdCA9IGZsaXAkMShvcHRpb25zKTtcbiAgcmV0dXJuIHtcbiAgICBuYW1lOiByZXN1bHQubmFtZSxcbiAgICBmbjogcmVzdWx0LmZuLFxuICAgIG9wdGlvbnM6IFtvcHRpb25zLCBkZXBzXVxuICB9O1xufTtcblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRoYXQgYWxsb3dzIHlvdSB0byBjaGFuZ2UgdGhlIHNpemUgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQg4oCUXG4gKiBmb3IgaW5zdGFuY2UsIHByZXZlbnQgaXQgZnJvbSBvdmVyZmxvd2luZyB0aGUgY2xpcHBpbmcgYm91bmRhcnkgb3IgbWF0Y2ggdGhlXG4gKiB3aWR0aCBvZiB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3Mvc2l6ZVxuICovXG5jb25zdCBzaXplID0gKG9wdGlvbnMsIGRlcHMpID0+IHtcbiAgY29uc3QgcmVzdWx0ID0gc2l6ZSQxKG9wdGlvbnMpO1xuICByZXR1cm4ge1xuICAgIG5hbWU6IHJlc3VsdC5uYW1lLFxuICAgIGZuOiByZXN1bHQuZm4sXG4gICAgb3B0aW9uczogW29wdGlvbnMsIGRlcHNdXG4gIH07XG59O1xuXG4vKipcbiAqIE9wdGltaXplcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBieSBjaG9vc2luZyB0aGUgcGxhY2VtZW50XG4gKiB0aGF0IGhhcyB0aGUgbW9zdCBzcGFjZSBhdmFpbGFibGUgYXV0b21hdGljYWxseSwgd2l0aG91dCBuZWVkaW5nIHRvIHNwZWNpZnkgYVxuICogcHJlZmVycmVkIHBsYWNlbWVudC4gQWx0ZXJuYXRpdmUgdG8gYGZsaXBgLlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2F1dG9QbGFjZW1lbnRcbiAqL1xuY29uc3QgYXV0b1BsYWNlbWVudCA9IChvcHRpb25zLCBkZXBzKSA9PiB7XG4gIGNvbnN0IHJlc3VsdCA9IGF1dG9QbGFjZW1lbnQkMShvcHRpb25zKTtcbiAgcmV0dXJuIHtcbiAgICBuYW1lOiByZXN1bHQubmFtZSxcbiAgICBmbjogcmVzdWx0LmZuLFxuICAgIG9wdGlvbnM6IFtvcHRpb25zLCBkZXBzXVxuICB9O1xufTtcblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRvIGhpZGUgdGhlIGZsb2F0aW5nIGVsZW1lbnQgaW4gYXBwbGljYWJsZSBzaXR1YXRpb25zLCBzdWNoIGFzXG4gKiB3aGVuIGl0IGlzIG5vdCBpbiB0aGUgc2FtZSBjbGlwcGluZyBjb250ZXh0IGFzIHRoZSByZWZlcmVuY2UgZWxlbWVudC5cbiAqIEBzZWUgaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9oaWRlXG4gKi9cbmNvbnN0IGhpZGUgPSAob3B0aW9ucywgZGVwcykgPT4ge1xuICBjb25zdCByZXN1bHQgPSBoaWRlJDEob3B0aW9ucyk7XG4gIHJldHVybiB7XG4gICAgbmFtZTogcmVzdWx0Lm5hbWUsXG4gICAgZm46IHJlc3VsdC5mbixcbiAgICBvcHRpb25zOiBbb3B0aW9ucywgZGVwc11cbiAgfTtcbn07XG5cbi8qKlxuICogUHJvdmlkZXMgaW1wcm92ZWQgcG9zaXRpb25pbmcgZm9yIGlubGluZSByZWZlcmVuY2UgZWxlbWVudHMgdGhhdCBjYW4gc3BhblxuICogb3ZlciBtdWx0aXBsZSBsaW5lcywgc3VjaCBhcyBoeXBlcmxpbmtzIG9yIHJhbmdlIHNlbGVjdGlvbnMuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvaW5saW5lXG4gKi9cbmNvbnN0IGlubGluZSA9IChvcHRpb25zLCBkZXBzKSA9PiB7XG4gIGNvbnN0IHJlc3VsdCA9IGlubGluZSQxKG9wdGlvbnMpO1xuICByZXR1cm4ge1xuICAgIG5hbWU6IHJlc3VsdC5uYW1lLFxuICAgIGZuOiByZXN1bHQuZm4sXG4gICAgb3B0aW9uczogW29wdGlvbnMsIGRlcHNdXG4gIH07XG59O1xuXG4vKipcbiAqIFByb3ZpZGVzIGRhdGEgdG8gcG9zaXRpb24gYW4gaW5uZXIgZWxlbWVudCBvZiB0aGUgZmxvYXRpbmcgZWxlbWVudCBzbyB0aGF0IGl0XG4gKiBhcHBlYXJzIGNlbnRlcmVkIHRvIHRoZSByZWZlcmVuY2UgZWxlbWVudC5cbiAqIFRoaXMgd3JhcHMgdGhlIGNvcmUgYGFycm93YCBtaWRkbGV3YXJlIHRvIGFsbG93IFJlYWN0IHJlZnMgYXMgdGhlIGVsZW1lbnQuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvYXJyb3dcbiAqL1xuY29uc3QgYXJyb3cgPSAob3B0aW9ucywgZGVwcykgPT4ge1xuICBjb25zdCByZXN1bHQgPSBhcnJvdyQxKG9wdGlvbnMpO1xuICByZXR1cm4ge1xuICAgIG5hbWU6IHJlc3VsdC5uYW1lLFxuICAgIGZuOiByZXN1bHQuZm4sXG4gICAgb3B0aW9uczogW29wdGlvbnMsIGRlcHNdXG4gIH07XG59O1xuXG5leHBvcnQgeyBhcnJvdywgYXV0b1BsYWNlbWVudCwgZmxpcCwgaGlkZSwgaW5saW5lLCBsaW1pdFNoaWZ0LCBvZmZzZXQsIHNoaWZ0LCBzaXplLCB1c2VGbG9hdGluZyB9O1xuIiwiaW1wb3J0IHsgRU1QVFlfT0JKRUNUIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvZW1wdHknO1xuaW1wb3J0IHsgRElTQUJMRURfVFJBTlNJVElPTlNfU1RZTEUgfSBmcm9tIFwiLi9jb25zdGFudHMubWpzXCI7XG5leHBvcnQgZnVuY3Rpb24gZ2V0RGlzYWJsZWRNb3VudFRyYW5zaXRpb25TdHlsZXModHJhbnNpdGlvblN0YXR1cykge1xuICByZXR1cm4gdHJhbnNpdGlvblN0YXR1cyA9PT0gJ3N0YXJ0aW5nJyA/IERJU0FCTEVEX1RSQU5TSVRJT05TX1NUWUxFIDogRU1QVFlfT0JKRUNUO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZUZsb2F0aW5nIGFzIHVzZVBvc2l0aW9uIH0gZnJvbSAnQGZsb2F0aW5nLXVpL3JlYWN0LWRvbSc7XG5pbXBvcnQgeyBpc0VsZW1lbnQgfSBmcm9tICdAZmxvYXRpbmctdWkvdXRpbHMvZG9tJztcbmltcG9ydCB7IHVzZUZsb2F0aW5nVHJlZSB9IGZyb20gXCIuLi9jb21wb25lbnRzL0Zsb2F0aW5nVHJlZS5tanNcIjtcbi8qKlxuICogUHJvdmlkZXMgZGF0YSB0byBwb3NpdGlvbiBhIGZsb2F0aW5nIGVsZW1lbnQgYW5kIGNvbnRleHQgdG8gYWRkIGludGVyYWN0aW9ucy5cbiAqIFRoZSBjYWxsZXIgc3VwcGxpZXMgdGhlIHJvb3Qgc3RvcmUsIHdoaWNoIG93bnMgdGhlIHJlZmVyZW5jZSBhbmQgZmxvYXRpbmcgZWxlbWVudHMuXG4gKiBAc2VlIGh0dHBzOi8vZmxvYXRpbmctdWkuY29tL2RvY3MvdXNlRmxvYXRpbmdcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZUJhc2VVSUZsb2F0aW5nKG9wdGlvbnMpIHtcbiAgY29uc3Qge1xuICAgIG5vZGVJZCxcbiAgICBleHRlcm5hbFRyZWUsXG4gICAgcm9vdENvbnRleHQ6IHN0b3JlXG4gIH0gPSBvcHRpb25zO1xuICBjb25zdCByZWZlcmVuY2VFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ3JlZmVyZW5jZUVsZW1lbnQnKTtcbiAgY29uc3QgZmxvYXRpbmdFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ2Zsb2F0aW5nRWxlbWVudCcpO1xuICBjb25zdCBkb21SZWZlcmVuY2VFbGVtZW50ID0gc3RvcmUudXNlU3RhdGUoJ2RvbVJlZmVyZW5jZUVsZW1lbnQnKTtcbiAgY29uc3Qgb3BlbiA9IHN0b3JlLnVzZVN0YXRlKCdvcGVuJyk7XG4gIGNvbnN0IGZsb2F0aW5nSWQgPSBzdG9yZS51c2VTdGF0ZSgnZmxvYXRpbmdJZCcpO1xuICBjb25zdCBbcG9zaXRpb25SZWZlcmVuY2UsIHNldFBvc2l0aW9uUmVmZXJlbmNlUmF3XSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBjb25zdCBkb21SZWZlcmVuY2VSZWYgPSBSZWFjdC51c2VSZWYobnVsbCk7XG4gIGNvbnN0IHRyZWUgPSB1c2VGbG9hdGluZ1RyZWUoZXh0ZXJuYWxUcmVlKTtcbiAgY29uc3Qgc3RvcmVFbGVtZW50cyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICByZWZlcmVuY2U6IHJlZmVyZW5jZUVsZW1lbnQsXG4gICAgZmxvYXRpbmc6IGZsb2F0aW5nRWxlbWVudCxcbiAgICBkb21SZWZlcmVuY2U6IGRvbVJlZmVyZW5jZUVsZW1lbnRcbiAgfSksIFtyZWZlcmVuY2VFbGVtZW50LCBmbG9hdGluZ0VsZW1lbnQsIGRvbVJlZmVyZW5jZUVsZW1lbnRdKTtcbiAgY29uc3QgcG9zaXRpb24gPSB1c2VQb3NpdGlvbih7XG4gICAgLi4ub3B0aW9ucyxcbiAgICBlbGVtZW50czoge1xuICAgICAgLi4uc3RvcmVFbGVtZW50cyxcbiAgICAgIC4uLihwb3NpdGlvblJlZmVyZW5jZSAmJiB7XG4gICAgICAgIHJlZmVyZW5jZTogcG9zaXRpb25SZWZlcmVuY2VcbiAgICAgIH0pXG4gICAgfVxuICB9KTtcbiAgY29uc3Qgc2V0UG9zaXRpb25SZWZlcmVuY2UgPSBSZWFjdC51c2VDYWxsYmFjayhub2RlID0+IHtcbiAgICBjb25zdCBjb21wdXRlZFBvc2l0aW9uUmVmZXJlbmNlID0gaXNFbGVtZW50KG5vZGUpID8ge1xuICAgICAgZ2V0Qm91bmRpbmdDbGllbnRSZWN0OiAoKSA9PiBub2RlLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLFxuICAgICAgZ2V0Q2xpZW50UmVjdHM6ICgpID0+IG5vZGUuZ2V0Q2xpZW50UmVjdHMoKSxcbiAgICAgIGNvbnRleHRFbGVtZW50OiBub2RlXG4gICAgfSA6IG5vZGU7XG4gICAgLy8gU3RvcmUgdGhlIHBvc2l0aW9uUmVmZXJlbmNlIGluIHN0YXRlIGlmIHRoZSBET00gcmVmZXJlbmNlIGlzIHNwZWNpZmllZCBleHRlcm5hbGx5IHZpYSB0aGVcbiAgICAvLyBgZWxlbWVudHMucmVmZXJlbmNlYCBvcHRpb24uIFRoaXMgZW5zdXJlcyB0aGF0IGl0IHdvbid0IGJlIG92ZXJyaWRkZW4gb24gZnV0dXJlIHJlbmRlcnMuXG4gICAgc2V0UG9zaXRpb25SZWZlcmVuY2VSYXcoY29tcHV0ZWRQb3NpdGlvblJlZmVyZW5jZSk7XG4gICAgcG9zaXRpb24ucmVmcy5zZXRSZWZlcmVuY2UoY29tcHV0ZWRQb3NpdGlvblJlZmVyZW5jZSk7XG4gIH0sIFtwb3NpdGlvbi5yZWZzXSk7XG4gIGNvbnN0IHJlZnMgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgLi4ucG9zaXRpb24ucmVmcyxcbiAgICBzZXRQb3NpdGlvblJlZmVyZW5jZSxcbiAgICBkb21SZWZlcmVuY2U6IGRvbVJlZmVyZW5jZVJlZlxuICB9KSwgW3Bvc2l0aW9uLnJlZnMsIHNldFBvc2l0aW9uUmVmZXJlbmNlXSk7XG4gIGNvbnN0IGVsZW1lbnRzID0gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIC4uLnBvc2l0aW9uLmVsZW1lbnRzLFxuICAgIGRvbVJlZmVyZW5jZTogZG9tUmVmZXJlbmNlRWxlbWVudFxuICB9KSwgW3Bvc2l0aW9uLmVsZW1lbnRzLCBkb21SZWZlcmVuY2VFbGVtZW50XSk7XG4gIGNvbnN0IGNvbnRleHQgPSBSZWFjdC51c2VNZW1vKCgpID0+ICh7XG4gICAgLi4ucG9zaXRpb24sXG4gICAgZGF0YVJlZjogc3RvcmUuY29udGV4dC5kYXRhUmVmLFxuICAgIG9wZW4sXG4gICAgb25PcGVuQ2hhbmdlOiBzdG9yZS5zZXRPcGVuLFxuICAgIGV2ZW50czogc3RvcmUuY29udGV4dC5ldmVudHMsXG4gICAgZmxvYXRpbmdJZCxcbiAgICByZWZzLFxuICAgIGVsZW1lbnRzLFxuICAgIG5vZGVJZCxcbiAgICByb290U3RvcmU6IHN0b3JlXG4gIH0pLCBbcG9zaXRpb24sIHJlZnMsIGVsZW1lbnRzLCBub2RlSWQsIHN0b3JlLCBvcGVuLCBmbG9hdGluZ0lkXSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGRvbVJlZmVyZW5jZUVsZW1lbnQpIHtcbiAgICAgIGRvbVJlZmVyZW5jZVJlZi5jdXJyZW50ID0gZG9tUmVmZXJlbmNlRWxlbWVudDtcbiAgICB9XG4gIH0sIFtkb21SZWZlcmVuY2VFbGVtZW50XSk7XG4gIHVzZUlzb0xheW91dEVmZmVjdCgoKSA9PiB7XG4gICAgc3RvcmUuY29udGV4dC5kYXRhUmVmLmN1cnJlbnQuZmxvYXRpbmdDb250ZXh0ID0gY29udGV4dDtcbiAgICBjb25zdCBub2RlID0gdHJlZT8ubm9kZXNSZWYuY3VycmVudC5maW5kKG4gPT4gbi5pZCA9PT0gbm9kZUlkKTtcbiAgICBpZiAobm9kZSkge1xuICAgICAgbm9kZS5jb250ZXh0ID0gY29udGV4dDtcbiAgICB9XG4gIH0pO1xuICByZXR1cm4gUmVhY3QudXNlTWVtbygoKSA9PiAoe1xuICAgIC4uLnBvc2l0aW9uLFxuICAgIGNvbnRleHQsXG4gICAgcmVmcyxcbiAgICBlbGVtZW50cyxcbiAgICByb290U3RvcmU6IHN0b3JlXG4gIH0pLCBbcG9zaXRpb24sIHJlZnMsIGVsZW1lbnRzLCBjb250ZXh0LCBzdG9yZV0pO1xufSIsImltcG9ydCB7IGNsYW1wLCBldmFsdWF0ZSwgZ2V0QWxpZ25tZW50LCBnZXRBbGlnbm1lbnRBeGlzLCBnZXRBeGlzTGVuZ3RoLCBnZXRQYWRkaW5nT2JqZWN0IH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzJztcbi8qKlxuICogRm9yayBvZiB0aGUgb3JpZ2luYWwgYGFycm93YCBtaWRkbGV3YXJlIGZyb20gRmxvYXRpbmcgVUkgdGhhdCBhbHdheXMgdXNlcyB0aGUgZmxvYXRpbmcgZWxlbWVudFxuICogYXMgdGhlIGFycm93J3Mgb2Zmc2V0IHBhcmVudC5cbiAqL1xuZXhwb3J0IGNvbnN0IGJhc2VBcnJvdyA9IG9wdGlvbnMgPT4gKHtcbiAgbmFtZTogJ2Fycm93JyxcbiAgb3B0aW9ucyxcbiAgYXN5bmMgZm4oc3RhdGUpIHtcbiAgICBjb25zdCB7XG4gICAgICB4LFxuICAgICAgeSxcbiAgICAgIHBsYWNlbWVudCxcbiAgICAgIHJlY3RzLFxuICAgICAgcGxhdGZvcm0sXG4gICAgICBlbGVtZW50cyxcbiAgICAgIG1pZGRsZXdhcmVEYXRhXG4gICAgfSA9IHN0YXRlO1xuICAgIC8vIFNpbmNlIGBlbGVtZW50YCBpcyByZXF1aXJlZCwgd2UgZG9uJ3QgUGFydGlhbDw+IHRoZSB0eXBlLlxuICAgIGNvbnN0IHtcbiAgICAgIGVsZW1lbnQsXG4gICAgICBwYWRkaW5nID0gMFxuICAgIH0gPSBldmFsdWF0ZShvcHRpb25zLCBzdGF0ZSkgfHwge307XG4gICAgaWYgKGVsZW1lbnQgPT0gbnVsbCkge1xuICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgICBjb25zdCBwYWRkaW5nT2JqZWN0ID0gZ2V0UGFkZGluZ09iamVjdChwYWRkaW5nKTtcbiAgICBjb25zdCBjb29yZHMgPSB7XG4gICAgICB4LFxuICAgICAgeVxuICAgIH07XG4gICAgY29uc3QgYXhpcyA9IGdldEFsaWdubWVudEF4aXMocGxhY2VtZW50KTtcbiAgICBjb25zdCBsZW5ndGggPSBnZXRBeGlzTGVuZ3RoKGF4aXMpO1xuICAgIGNvbnN0IGFycm93RGltZW5zaW9ucyA9IGF3YWl0IHBsYXRmb3JtLmdldERpbWVuc2lvbnMoZWxlbWVudCk7XG4gICAgY29uc3QgaXNZQXhpcyA9IGF4aXMgPT09ICd5JztcbiAgICBjb25zdCBtaW5Qcm9wID0gaXNZQXhpcyA/ICd0b3AnIDogJ2xlZnQnO1xuICAgIGNvbnN0IG1heFByb3AgPSBpc1lBeGlzID8gJ2JvdHRvbScgOiAncmlnaHQnO1xuICAgIGNvbnN0IGNsaWVudFByb3AgPSBpc1lBeGlzID8gJ2NsaWVudEhlaWdodCcgOiAnY2xpZW50V2lkdGgnO1xuICAgIGNvbnN0IGVuZERpZmYgPSByZWN0cy5yZWZlcmVuY2VbbGVuZ3RoXSArIHJlY3RzLnJlZmVyZW5jZVtheGlzXSAtIGNvb3Jkc1theGlzXSAtIHJlY3RzLmZsb2F0aW5nW2xlbmd0aF07XG4gICAgY29uc3Qgc3RhcnREaWZmID0gY29vcmRzW2F4aXNdIC0gcmVjdHMucmVmZXJlbmNlW2F4aXNdO1xuICAgIGNvbnN0IGNsaWVudFNpemUgPSBlbGVtZW50cy5mbG9hdGluZ1tjbGllbnRQcm9wXSB8fCByZWN0cy5mbG9hdGluZ1tsZW5ndGhdO1xuICAgIGNvbnN0IGNlbnRlclRvUmVmZXJlbmNlID0gZW5kRGlmZiAvIDIgLSBzdGFydERpZmYgLyAyO1xuXG4gICAgLy8gSWYgdGhlIHBhZGRpbmcgaXMgbGFyZ2UgZW5vdWdoIHRoYXQgaXQgY2F1c2VzIHRoZSBhcnJvdyB0byBubyBsb25nZXIgYmVcbiAgICAvLyBjZW50ZXJlZCwgbW9kaWZ5IHRoZSBwYWRkaW5nIHNvIHRoYXQgaXQgaXMgY2VudGVyZWQuXG4gICAgY29uc3QgbGFyZ2VzdFBvc3NpYmxlUGFkZGluZyA9IGNsaWVudFNpemUgLyAyIC0gYXJyb3dEaW1lbnNpb25zW2xlbmd0aF0gLyAyIC0gMTtcbiAgICBjb25zdCBtaW5QYWRkaW5nID0gTWF0aC5taW4ocGFkZGluZ09iamVjdFttaW5Qcm9wXSwgbGFyZ2VzdFBvc3NpYmxlUGFkZGluZyk7XG4gICAgY29uc3QgbWF4UGFkZGluZyA9IE1hdGgubWluKHBhZGRpbmdPYmplY3RbbWF4UHJvcF0sIGxhcmdlc3RQb3NzaWJsZVBhZGRpbmcpO1xuXG4gICAgLy8gTWFrZSBzdXJlIHRoZSBhcnJvdyBkb2Vzbid0IG92ZXJmbG93IHRoZSBmbG9hdGluZyBlbGVtZW50IGlmIHRoZSBjZW50ZXJcbiAgICAvLyBwb2ludCBpcyBvdXRzaWRlIHRoZSBmbG9hdGluZyBlbGVtZW50J3MgYm91bmRzLlxuICAgIGNvbnN0IG1pbiA9IG1pblBhZGRpbmc7XG4gICAgY29uc3QgbWF4ID0gY2xpZW50U2l6ZSAtIGFycm93RGltZW5zaW9uc1tsZW5ndGhdIC0gbWF4UGFkZGluZztcbiAgICBjb25zdCBjZW50ZXIgPSBjbGllbnRTaXplIC8gMiAtIGFycm93RGltZW5zaW9uc1tsZW5ndGhdIC8gMiArIGNlbnRlclRvUmVmZXJlbmNlO1xuICAgIGNvbnN0IG9mZnNldCA9IGNsYW1wKG1pbiwgY2VudGVyLCBtYXgpO1xuXG4gICAgLy8gSWYgdGhlIHJlZmVyZW5jZSBpcyBzbWFsbCBlbm91Z2ggdGhhdCB0aGUgYXJyb3cncyBwYWRkaW5nIGNhdXNlcyBpdCB0b1xuICAgIC8vIHRvIHBvaW50IHRvIG5vdGhpbmcgZm9yIGFuIGFsaWduZWQgcGxhY2VtZW50LCBhZGp1c3QgdGhlIG9mZnNldCBvZiB0aGVcbiAgICAvLyBmbG9hdGluZyBlbGVtZW50IGl0c2VsZi4gVG8gZW5zdXJlIGBzaGlmdCgpYCBjb250aW51ZXMgdG8gdGFrZSBhY3Rpb24sXG4gICAgLy8gYSBzaW5nbGUgcmVzZXQgaXMgcGVyZm9ybWVkIHdoZW4gdGhpcyBpcyB0cnVlLlxuICAgIGNvbnN0IHNob3VsZEFkZE9mZnNldCA9ICFtaWRkbGV3YXJlRGF0YS5hcnJvdyAmJiBnZXRBbGlnbm1lbnQocGxhY2VtZW50KSAhPSBudWxsICYmIGNlbnRlciAhPT0gb2Zmc2V0ICYmIHJlY3RzLnJlZmVyZW5jZVtsZW5ndGhdIC8gMiAtIChjZW50ZXIgPCBtaW4gPyBtaW5QYWRkaW5nIDogbWF4UGFkZGluZykgLSBhcnJvd0RpbWVuc2lvbnNbbGVuZ3RoXSAvIDIgPCAwO1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1uZXN0ZWQtdGVybmFyeVxuICAgIGNvbnN0IGFsaWdubWVudE9mZnNldCA9IHNob3VsZEFkZE9mZnNldCA/IGNlbnRlciA8IG1pbiA/IGNlbnRlciAtIG1pbiA6IGNlbnRlciAtIG1heCA6IDA7XG4gICAgcmV0dXJuIHtcbiAgICAgIFtheGlzXTogY29vcmRzW2F4aXNdICsgYWxpZ25tZW50T2Zmc2V0LFxuICAgICAgZGF0YToge1xuICAgICAgICBbYXhpc106IG9mZnNldCxcbiAgICAgICAgY2VudGVyT2Zmc2V0OiBjZW50ZXIgLSBvZmZzZXQgLSBhbGlnbm1lbnRPZmZzZXQsXG4gICAgICAgIC4uLihzaG91bGRBZGRPZmZzZXQgJiYge1xuICAgICAgICAgIGFsaWdubWVudE9mZnNldFxuICAgICAgICB9KVxuICAgICAgfSxcbiAgICAgIHJlc2V0OiBzaG91bGRBZGRPZmZzZXRcbiAgICB9O1xuICB9XG59KTtcblxuLyoqXG4gKiBQcm92aWRlcyBkYXRhIHRvIHBvc2l0aW9uIGFuIGlubmVyIGVsZW1lbnQgb2YgdGhlIGZsb2F0aW5nIGVsZW1lbnQgc28gdGhhdCBpdFxuICogYXBwZWFycyBjZW50ZXJlZCB0byB0aGUgcmVmZXJlbmNlIGVsZW1lbnQuXG4gKiBUaGlzIHdyYXBzIHRoZSBjb3JlIGBhcnJvd2AgbWlkZGxld2FyZSB0byBhbGxvdyBSZWFjdCByZWZzIGFzIHRoZSBlbGVtZW50LlxuICogQHNlZSBodHRwczovL2Zsb2F0aW5nLXVpLmNvbS9kb2NzL2Fycm93XG4gKi9cbmV4cG9ydCBjb25zdCBhcnJvdyA9IChvcHRpb25zLCBkZXBzKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBuYW1lLFxuICAgIGZuXG4gIH0gPSBiYXNlQXJyb3cob3B0aW9ucyk7XG4gIHJldHVybiB7XG4gICAgbmFtZSxcbiAgICBmbixcbiAgICBvcHRpb25zOiBbb3B0aW9ucywgZGVwc11cbiAgfTtcbn07IiwiZXhwb3J0IGNvbnN0IGhpZGUgPSB7XG4gIG5hbWU6ICdoaWRlJyxcbiAgYXN5bmMgZm4oc3RhdGUpIHtcbiAgICBjb25zdCB7XG4gICAgICB3aWR0aCxcbiAgICAgIGhlaWdodCxcbiAgICAgIHgsXG4gICAgICB5XG4gICAgfSA9IHN0YXRlLnJlY3RzLnJlZmVyZW5jZTtcbiAgICBjb25zdCBhbmNob3JIaWRkZW4gPSB3aWR0aCA9PT0gMCAmJiBoZWlnaHQgPT09IDAgJiYgeCA9PT0gMCAmJiB5ID09PSAwO1xuICAgIC8vIE1pcnJvcnMgRmxvYXRpbmcgVUkncyBgaGlkZSgpYCByZWZlcmVuY2VIaWRkZW4gc3RyYXRlZ3kuIEZsb2F0aW5nIFVJIGluamVjdHNcbiAgICAvLyBgZGV0ZWN0T3ZlcmZsb3dgIGludG8gdGhlIG1pZGRsZXdhcmUgcGxhdGZvcm0gYmVmb3JlIGludm9raW5nIG1pZGRsZXdhcmUuXG4gICAgY29uc3Qgb3ZlcmZsb3cgPSBhd2FpdCBzdGF0ZS5wbGF0Zm9ybS5kZXRlY3RPdmVyZmxvdyhzdGF0ZSwge1xuICAgICAgZWxlbWVudENvbnRleHQ6ICdyZWZlcmVuY2UnXG4gICAgfSk7XG4gICAgY29uc3QgcmVmZXJlbmNlSGlkZGVuID0gb3ZlcmZsb3cudG9wIC0gaGVpZ2h0ID49IDAgfHwgb3ZlcmZsb3cucmlnaHQgLSB3aWR0aCA+PSAwIHx8IG92ZXJmbG93LmJvdHRvbSAtIGhlaWdodCA+PSAwIHx8IG92ZXJmbG93LmxlZnQgLSB3aWR0aCA+PSAwO1xuICAgIHJldHVybiB7XG4gICAgICBkYXRhOiB7XG4gICAgICAgIHJlZmVyZW5jZUhpZGRlbjogcmVmZXJlbmNlSGlkZGVuIHx8IGFuY2hvckhpZGRlblxuICAgICAgfVxuICAgIH07XG4gIH1cbn07IiwiZXhwb3J0IGNvbnN0IERFRkFVTFRfU0lERVMgPSB7XG4gIHNpZGVYOiAnbGVmdCcsXG4gIHNpZGVZOiAndG9wJ1xufTtcblxuLy8gU2VsZi1jb250YWluZWQgc3RhbmQtaW4gZm9yIEZsb2F0aW5nIFVJJ3MgYE1pZGRsZXdhcmVgIHR5cGUuIFJlZmVyZW5jaW5nIHRoZSByZWFsIHR5cGUgaW5cbi8vIHN0b3JlIHN0YXRlIG1ha2VzIGB0c2NgIGRlY2xhcmF0aW9uIGVtaXQgcmVmZXJlbmNlIGBQbGF0Zm9ybWAvYGRldGVjdE92ZXJmbG93YCBmcm9tXG4vLyBgQGZsb2F0aW5nLXVpL2NvcmVgIGludGVybmFscywgd2hpY2ggZmFpbHMgYXMgbm9uLXBvcnRhYmxlIChUUzI4ODMpIGluIGNvbnN1bWluZyBidWlsZHMuIiwiLyoqXG4gKiBUaGUgYXZhaWxhYmxlIHdpZHRoIGJldHdlZW4gdGhlIHRyaWdnZXIgYW5kIHRoZSBlZGdlIG9mIHRoZSB2aWV3cG9ydC5cbiAqIEB0eXBlIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBjb25zdCBhdmFpbGFibGVXaWR0aCA9ICctLWF2YWlsYWJsZS13aWR0aCc7XG4vKipcbiAqIFRoZSBhdmFpbGFibGUgaGVpZ2h0IGJldHdlZW4gdGhlIHRyaWdnZXIgYW5kIHRoZSBlZGdlIG9mIHRoZSB2aWV3cG9ydC5cbiAqIEB0eXBlIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBjb25zdCBhdmFpbGFibGVIZWlnaHQgPSAnLS1hdmFpbGFibGUtaGVpZ2h0Jztcbi8qKlxuICogVGhlIGFuY2hvcidzIHdpZHRoLlxuICogQHR5cGUge251bWJlcn1cbiAqL1xuZXhwb3J0IGNvbnN0IGFuY2hvcldpZHRoID0gJy0tYW5jaG9yLXdpZHRoJztcbi8qKlxuICogVGhlIGFuY2hvcidzIGhlaWdodC5cbiAqIEB0eXBlIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBjb25zdCBhbmNob3JIZWlnaHQgPSAnLS1hbmNob3ItaGVpZ2h0Jztcbi8qKlxuICogVGhlIGNvb3JkaW5hdGVzIHRoYXQgdGhpcyBlbGVtZW50IGlzIGFuY2hvcmVkIHRvLiBVc2VkIGZvciBhbmltYXRpb25zIGFuZCB0cmFuc2l0aW9ucy5cbiAqIEB0eXBlIHtzdHJpbmd9XG4gKi9cbmV4cG9ydCBjb25zdCB0cmFuc2Zvcm1PcmlnaW4gPSAnLS10cmFuc2Zvcm0tb3JpZ2luJztcbi8qKlxuICogVGhlIHdpZHRoIG9mIHRoZSBwb3B1cCdzIHBvc2l0aW9uZXIuXG4gKiBJdCBpcyBpbXBvcnRhbnQgdG8gc2V0IGB3aWR0aGAgdG8gdGhpcyB2YWx1ZSB3aGVuIHVzaW5nIENTUyB0byBhbmltYXRlIHNpemUgY2hhbmdlcy5cbiAqIEB0eXBlIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBjb25zdCBwb3NpdGlvbmVyV2lkdGggPSAnLS1wb3NpdGlvbmVyLXdpZHRoJztcbi8qKlxuICogVGhlIGhlaWdodCBvZiB0aGUgcG9wdXAncyBwb3NpdGlvbmVyLlxuICogSXQgaXMgaW1wb3J0YW50IHRvIHNldCBgaGVpZ2h0YCB0byB0aGlzIHZhbHVlIHdoZW4gdXNpbmcgQ1NTIHRvIGFuaW1hdGUgc2l6ZSBjaGFuZ2VzLlxuICogQHR5cGUge251bWJlcn1cbiAqL1xuZXhwb3J0IGNvbnN0IHBvc2l0aW9uZXJIZWlnaHQgPSAnLS1wb3NpdGlvbmVyLWhlaWdodCc7IiwiJ3VzZSBjbGllbnQnO1xuXG5pbXBvcnQgKiBhcyBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBnZXRTaWRlLCBnZXRBbGlnbm1lbnQsIGdldFNpZGVBeGlzIH0gZnJvbSAnQGZsb2F0aW5nLXVpL3V0aWxzJztcbmltcG9ydCB7IG93bmVyRG9jdW1lbnQsIG93bmVyV2luZG93IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvb3duZXInO1xuaW1wb3J0IHsgdXNlSXNvTGF5b3V0RWZmZWN0IH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlSXNvTGF5b3V0RWZmZWN0JztcbmltcG9ydCB7IHVzZVZhbHVlQXNSZWYgfSBmcm9tICdAYmFzZS11aS91dGlscy91c2VWYWx1ZUFzUmVmJztcbmltcG9ydCB7IHVzZVN0YWJsZUNhbGxiYWNrIH0gZnJvbSAnQGJhc2UtdWkvdXRpbHMvdXNlU3RhYmxlQ2FsbGJhY2snO1xuaW1wb3J0IHsgYXV0b1VwZGF0ZSwgZmxpcCwgbGltaXRTaGlmdCwgb2Zmc2V0LCBzaGlmdCBhcyBmbG9hdGluZ1NoaWZ0LCBzaXplIH0gZnJvbSBcIi4uL2Zsb2F0aW5nLXVpLXJlYWN0L2luZGV4Lm1qc1wiO1xuaW1wb3J0IHsgdXNlQmFzZVVJRmxvYXRpbmcgfSBmcm9tIFwiLi4vZmxvYXRpbmctdWktcmVhY3QvaG9va3MvdXNlRmxvYXRpbmcubWpzXCI7XG5pbXBvcnQgeyB1c2VEaXJlY3Rpb24gfSBmcm9tIFwiLi9kaXJlY3Rpb24tY29udGV4dC9EaXJlY3Rpb25Db250ZXh0Lm1qc1wiO1xuaW1wb3J0IHsgYXJyb3cgfSBmcm9tIFwiLi4vZmxvYXRpbmctdWktcmVhY3QvbWlkZGxld2FyZS9hcnJvdy5tanNcIjtcbmltcG9ydCB7IGhpZGUgfSBmcm9tIFwiLi4vdXRpbHMvaGlkZU1pZGRsZXdhcmUubWpzXCI7XG5pbXBvcnQgeyBERUZBVUxUX1NJREVTIH0gZnJvbSBcIi4uL3V0aWxzL2FkYXB0aXZlT3JpZ2luQ29uc3RhbnRzLm1qc1wiO1xuaW1wb3J0ICogYXMgQ29tbW9uUG9zaXRpb25lckNzc1ZhcnMgZnJvbSBcIi4uL3V0aWxzL0NvbW1vblBvc2l0aW9uZXJDc3NWYXJzLm1qc1wiO1xuY29uc3QgQVZBSUxBQkxFX1dJRFRIX1ZBUiA9IENvbW1vblBvc2l0aW9uZXJDc3NWYXJzLmF2YWlsYWJsZVdpZHRoO1xuY29uc3QgQVZBSUxBQkxFX0hFSUdIVF9WQVIgPSBDb21tb25Qb3NpdGlvbmVyQ3NzVmFycy5hdmFpbGFibGVIZWlnaHQ7XG5mdW5jdGlvbiBnZXRMb2dpY2FsU2lkZShzaWRlUGFyYW0sIHJlbmRlcmVkU2lkZSwgaXNSdGwpIHtcbiAgY29uc3QgaXNMb2dpY2FsU2lkZVBhcmFtID0gc2lkZVBhcmFtID09PSAnaW5saW5lLXN0YXJ0JyB8fCBzaWRlUGFyYW0gPT09ICdpbmxpbmUtZW5kJztcbiAgY29uc3QgbG9naWNhbFJpZ2h0ID0gaXNSdGwgPyAnaW5saW5lLXN0YXJ0JyA6ICdpbmxpbmUtZW5kJztcbiAgY29uc3QgbG9naWNhbExlZnQgPSBpc1J0bCA/ICdpbmxpbmUtZW5kJyA6ICdpbmxpbmUtc3RhcnQnO1xuICByZXR1cm4ge1xuICAgIHRvcDogJ3RvcCcsXG4gICAgcmlnaHQ6IGlzTG9naWNhbFNpZGVQYXJhbSA/IGxvZ2ljYWxSaWdodCA6ICdyaWdodCcsXG4gICAgYm90dG9tOiAnYm90dG9tJyxcbiAgICBsZWZ0OiBpc0xvZ2ljYWxTaWRlUGFyYW0gPyBsb2dpY2FsTGVmdCA6ICdsZWZ0J1xuICB9W3JlbmRlcmVkU2lkZV07XG59XG5mdW5jdGlvbiBnZXRPZmZzZXREYXRhKHN0YXRlLCBzaWRlUGFyYW0sIGlzUnRsKSB7XG4gIGNvbnN0IHtcbiAgICByZWN0cyxcbiAgICBwbGFjZW1lbnRcbiAgfSA9IHN0YXRlO1xuICBjb25zdCBkYXRhID0ge1xuICAgIHNpZGU6IGdldExvZ2ljYWxTaWRlKHNpZGVQYXJhbSwgZ2V0U2lkZShwbGFjZW1lbnQpLCBpc1J0bCksXG4gICAgYWxpZ246IGdldEFsaWdubWVudChwbGFjZW1lbnQpIHx8ICdjZW50ZXInLFxuICAgIGFuY2hvcjoge1xuICAgICAgd2lkdGg6IHJlY3RzLnJlZmVyZW5jZS53aWR0aCxcbiAgICAgIGhlaWdodDogcmVjdHMucmVmZXJlbmNlLmhlaWdodFxuICAgIH0sXG4gICAgcG9zaXRpb25lcjoge1xuICAgICAgd2lkdGg6IHJlY3RzLmZsb2F0aW5nLndpZHRoLFxuICAgICAgaGVpZ2h0OiByZWN0cy5mbG9hdGluZy5oZWlnaHRcbiAgICB9XG4gIH07XG4gIHJldHVybiBkYXRhO1xufVxuLyoqXG4gKiBQcm92aWRlcyBzdGFuZGFyZGl6ZWQgYW5jaG9yIHBvc2l0aW9uaW5nIGJlaGF2aW9yIGZvciBmbG9hdGluZyBlbGVtZW50cy4gV3JhcHMgRmxvYXRpbmcgVUknc1xuICogYHVzZUZsb2F0aW5nYCBob29rLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlQW5jaG9yUG9zaXRpb25pbmcocGFyYW1zKSB7XG4gIHJldHVybiB1c2VBbmNob3JQb3NpdGlvbmluZ1dpdGhIb29rKHBhcmFtcywgdXNlQmFzZVVJRmxvYXRpbmcpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHVzZUFuY2hvclBvc2l0aW9uaW5nV2l0aEhvb2socGFyYW1zLCB1c2VGbG9hdGluZ0hvb2spIHtcbiAgY29uc3Qge1xuICAgIC8vIFB1YmxpYyBwYXJhbWV0ZXJzXG4gICAgYW5jaG9yLFxuICAgIHBvc2l0aW9uTWV0aG9kID0gJ2Fic29sdXRlJyxcbiAgICBzaWRlOiBzaWRlUGFyYW0gPSAnYm90dG9tJyxcbiAgICBzaWRlT2Zmc2V0ID0gMCxcbiAgICBhbGlnbiA9ICdjZW50ZXInLFxuICAgIGFsaWduT2Zmc2V0ID0gMCxcbiAgICBjb2xsaXNpb25Cb3VuZGFyeSxcbiAgICBjb2xsaXNpb25QYWRkaW5nOiBjb2xsaXNpb25QYWRkaW5nUGFyYW0gPSA1LFxuICAgIHN0aWNreSA9IGZhbHNlLFxuICAgIGFycm93UGFkZGluZyA9IDUsXG4gICAgZGlzYWJsZUFuY2hvclRyYWNraW5nID0gZmFsc2UsXG4gICAgaW5saW5lOiBpbmxpbmVNaWRkbGV3YXJlLFxuICAgIC8vIFByaXZhdGUgcGFyYW1ldGVyc1xuICAgIGtlZXBNb3VudGVkID0gZmFsc2UsXG4gICAgZmxvYXRpbmdSb290Q29udGV4dCxcbiAgICBtb3VudGVkLFxuICAgIGNvbGxpc2lvbkF2b2lkYW5jZSxcbiAgICBzaGlmdCxcbiAgICBub2RlSWQsXG4gICAgYWRhcHRpdmVPcmlnaW4sXG4gICAgbGF6eUZsaXAgPSBmYWxzZSxcbiAgICBleHRlcm5hbFRyZWVcbiAgfSA9IHBhcmFtcztcbiAgY29uc3QgY29sbGlzaW9uQXZvaWRhbmNlU2lkZSA9IGNvbGxpc2lvbkF2b2lkYW5jZS5zaWRlIHx8ICdmbGlwJztcbiAgY29uc3QgY29sbGlzaW9uQXZvaWRhbmNlQWxpZ24gPSBjb2xsaXNpb25Bdm9pZGFuY2UuYWxpZ24gfHwgJ2ZsaXAnO1xuICBjb25zdCBjb2xsaXNpb25Bdm9pZGFuY2VGYWxsYmFja0F4aXNTaWRlID0gY29sbGlzaW9uQXZvaWRhbmNlLmZhbGxiYWNrQXhpc1NpZGUgfHwgJ2VuZCc7XG4gIGNvbnN0IHNoaWZ0Q3Jvc3NBeGlzID0gc2hpZnQ/LmNyb3NzQXhpcyA/PyBmYWxzZTtcbiAgY29uc3Qgc2hpZnRSb290Qm91bmRhcnkgPSBzaGlmdD8ucm9vdEJvdW5kYXJ5O1xuICBjb25zdCBhbmNob3JGbiA9IHR5cGVvZiBhbmNob3IgPT09ICdmdW5jdGlvbicgPyBhbmNob3IgOiB1bmRlZmluZWQ7XG4gIGNvbnN0IGFuY2hvckZuQ2FsbGJhY2sgPSB1c2VTdGFibGVDYWxsYmFjayhhbmNob3JGbik7XG4gIGNvbnN0IGFuY2hvckRlcCA9IGFuY2hvckZuID8gYW5jaG9yRm5DYWxsYmFjayA6IGFuY2hvcjtcbiAgY29uc3QgYW5jaG9yVmFsdWVSZWYgPSB1c2VWYWx1ZUFzUmVmKGFuY2hvcik7XG4gIGNvbnN0IG1vdW50ZWRSZWYgPSB1c2VWYWx1ZUFzUmVmKG1vdW50ZWQpO1xuICBjb25zdCBkaXJlY3Rpb24gPSB1c2VEaXJlY3Rpb24oKTtcbiAgY29uc3QgaXNSdGwgPSBkaXJlY3Rpb24gPT09ICdydGwnO1xuICBjb25zdCBbbW91bnRQbGFjZW1lbnQsIHNldE1vdW50UGxhY2VtZW50XSA9IFJlYWN0LnVzZVN0YXRlKG51bGwpO1xuICBpZiAoIW1vdW50ZWQgJiYgbW91bnRQbGFjZW1lbnQgIT09IG51bGwpIHtcbiAgICBzZXRNb3VudFBsYWNlbWVudChudWxsKTtcbiAgfVxuICBjb25zdCBsb2NrQWxpZ24gPSBsYXp5RmxpcCA9PT0gJ3BsYWNlbWVudCc7XG4gIGNvbnN0IG1vdW50U2lkZSA9IG1vdW50UGxhY2VtZW50ID8gZ2V0U2lkZShtb3VudFBsYWNlbWVudCkgOiBudWxsO1xuICBjb25zdCBtb3VudEFsaWduID0gbW91bnRQbGFjZW1lbnQgJiYgbG9ja0FsaWduID8gZ2V0QWxpZ25tZW50KG1vdW50UGxhY2VtZW50KSB8fCAnY2VudGVyJyA6IG51bGw7XG4gIGNvbnN0IHNpZGUgPSBtb3VudFNpZGUgfHwge1xuICAgIHRvcDogJ3RvcCcsXG4gICAgcmlnaHQ6ICdyaWdodCcsXG4gICAgYm90dG9tOiAnYm90dG9tJyxcbiAgICBsZWZ0OiAnbGVmdCcsXG4gICAgJ2lubGluZS1lbmQnOiBpc1J0bCA/ICdsZWZ0JyA6ICdyaWdodCcsXG4gICAgJ2lubGluZS1zdGFydCc6IGlzUnRsID8gJ3JpZ2h0JyA6ICdsZWZ0J1xuICB9W3NpZGVQYXJhbV07XG4gIGNvbnN0IHBsYWNlbWVudEFsaWduID0gbW91bnRBbGlnbiB8fCBhbGlnbjtcbiAgY29uc3QgcGxhY2VtZW50ID0gcGxhY2VtZW50QWxpZ24gPT09ICdjZW50ZXInID8gc2lkZSA6IGAke3NpZGV9LSR7cGxhY2VtZW50QWxpZ259YDtcbiAgbGV0IGNvbGxpc2lvblBhZGRpbmcgPSBjb2xsaXNpb25QYWRkaW5nUGFyYW07XG4gIGlmICh0eXBlb2YgY29sbGlzaW9uUGFkZGluZyA9PT0gJ251bWJlcicpIHtcbiAgICBjb2xsaXNpb25QYWRkaW5nID0ge1xuICAgICAgdG9wOiBjb2xsaXNpb25QYWRkaW5nLFxuICAgICAgcmlnaHQ6IGNvbGxpc2lvblBhZGRpbmcsXG4gICAgICBib3R0b206IGNvbGxpc2lvblBhZGRpbmcsXG4gICAgICBsZWZ0OiBjb2xsaXNpb25QYWRkaW5nXG4gICAgfTtcbiAgfSBlbHNlIGlmIChjb2xsaXNpb25QYWRkaW5nKSB7XG4gICAgY29sbGlzaW9uUGFkZGluZyA9IHtcbiAgICAgIHRvcDogY29sbGlzaW9uUGFkZGluZy50b3AgfHwgMCxcbiAgICAgIHJpZ2h0OiBjb2xsaXNpb25QYWRkaW5nLnJpZ2h0IHx8IDAsXG4gICAgICBib3R0b206IGNvbGxpc2lvblBhZGRpbmcuYm90dG9tIHx8IDAsXG4gICAgICBsZWZ0OiBjb2xsaXNpb25QYWRkaW5nLmxlZnQgfHwgMFxuICAgIH07XG4gIH1cblxuICAvLyBDcmVhdGUgYSBiaWFzIHRvIHRoZSBwcmVmZXJyZWQgc2lkZS5cbiAgLy8gT24gaU9TLCB3aGVuIHRoZSBtb2JpbGUgc29mdHdhcmUga2V5Ym9hcmQgb3BlbnMsIHRoZSBpbnB1dCBpcyBleGFjdGx5IGNlbnRlcmVkXG4gIC8vIGluIHRoZSB2aWV3cG9ydCwgYnV0IHRoaXMgY2FuIGNhdXNlIGl0IHRvIGZsaXAgdG8gdGhlIHRvcCB1bmRlc2lyYWJseS5cbiAgLy8gVGhlIGJpYXMgaXMgb25seSBhcHBsaWVkIHRvIGBmbGlwKClgIHNvIGl0IGRvZXNuJ3Qgc2hpZnQgdGhlIHJlc3RpbmcgcG9zaXRpb25cbiAgLy8gY29tcHV0ZWQgYnkgYHNoaWZ0KClgIGFuZCBgc2l6ZSgpYCBhd2F5IGZyb20gdGhlIHJlcXVlc3RlZCBgY29sbGlzaW9uUGFkZGluZ2AuXG4gIGNvbnN0IGJpYXMgPSAxO1xuICBjb25zdCBiaWFzVG9wID0gc2lkZVBhcmFtID09PSAnYm90dG9tJyA/IGJpYXMgOiAwO1xuICBjb25zdCBiaWFzQm90dG9tID0gc2lkZVBhcmFtID09PSAndG9wJyA/IGJpYXMgOiAwO1xuICBjb25zdCBiaWFzTGVmdCA9IHNpZGVQYXJhbSA9PT0gJ3JpZ2h0JyA/IGJpYXMgOiAwO1xuICBjb25zdCBiaWFzUmlnaHQgPSBzaWRlUGFyYW0gPT09ICdsZWZ0JyA/IGJpYXMgOiAwO1xuICBjb25zdCBjb21tb25Db2xsaXNpb25Qcm9wcyA9IHtcbiAgICBib3VuZGFyeTogY29sbGlzaW9uQm91bmRhcnkgPT09ICdjbGlwcGluZy1hbmNlc3RvcnMnID8gJ2NsaXBwaW5nQW5jZXN0b3JzJyA6IGNvbGxpc2lvbkJvdW5kYXJ5LFxuICAgIHBhZGRpbmc6IGNvbGxpc2lvblBhZGRpbmdcbiAgfTtcblxuICAvLyBVc2luZyBhIHJlZiBhc3N1bWVzIHRoYXQgdGhlIGFycm93IGVsZW1lbnQgaXMgYWx3YXlzIHByZXNlbnQgaW4gdGhlIERPTSBmb3IgdGhlIGxpZmV0aW1lIG9mIHRoZVxuICAvLyBwb3B1cC4gSWYgdGhpcyBhc3N1bXB0aW9uIGVuZHMgdXAgYmVpbmcgZmFsc2UsIHdlIGNhbiBzd2l0Y2ggdG8gc3RhdGUgdG8gbWFuYWdlIHRoZSBhcnJvdydzXG4gIC8vIHByZXNlbmNlLlxuICBjb25zdCBhcnJvd1JlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcblxuICAvLyBLZWVwIHRoZXNlIHJlYWN0aXZlIGlmIHRoZXkncmUgbm90IGZ1bmN0aW9uc1xuICBjb25zdCBzaWRlT2Zmc2V0UmVmID0gdXNlVmFsdWVBc1JlZihzaWRlT2Zmc2V0KTtcbiAgY29uc3QgYWxpZ25PZmZzZXRSZWYgPSB1c2VWYWx1ZUFzUmVmKGFsaWduT2Zmc2V0KTtcbiAgY29uc3Qgc2lkZU9mZnNldERlcCA9IHR5cGVvZiBzaWRlT2Zmc2V0ICE9PSAnZnVuY3Rpb24nID8gc2lkZU9mZnNldCA6IDA7XG4gIGNvbnN0IGFsaWduT2Zmc2V0RGVwID0gdHlwZW9mIGFsaWduT2Zmc2V0ICE9PSAnZnVuY3Rpb24nID8gYWxpZ25PZmZzZXQgOiAwO1xuICBjb25zdCBtaWRkbGV3YXJlID0gW107XG4gIGlmIChpbmxpbmVNaWRkbGV3YXJlKSB7XG4gICAgbWlkZGxld2FyZS5wdXNoKGlubGluZU1pZGRsZXdhcmUpO1xuICB9XG4gIG1pZGRsZXdhcmUucHVzaChvZmZzZXQoc3RhdGUgPT4ge1xuICAgIGNvbnN0IGRhdGEgPSBnZXRPZmZzZXREYXRhKHN0YXRlLCBzaWRlUGFyYW0sIGlzUnRsKTtcbiAgICBjb25zdCBzaWRlQXhpcyA9IHR5cGVvZiBzaWRlT2Zmc2V0UmVmLmN1cnJlbnQgPT09ICdmdW5jdGlvbicgPyBzaWRlT2Zmc2V0UmVmLmN1cnJlbnQoZGF0YSkgOiBzaWRlT2Zmc2V0UmVmLmN1cnJlbnQ7XG4gICAgY29uc3QgYWxpZ25BeGlzID0gdHlwZW9mIGFsaWduT2Zmc2V0UmVmLmN1cnJlbnQgPT09ICdmdW5jdGlvbicgPyBhbGlnbk9mZnNldFJlZi5jdXJyZW50KGRhdGEpIDogYWxpZ25PZmZzZXRSZWYuY3VycmVudDtcbiAgICByZXR1cm4ge1xuICAgICAgbWFpbkF4aXM6IHNpZGVBeGlzLFxuICAgICAgY3Jvc3NBeGlzOiBhbGlnbkF4aXMsXG4gICAgICBhbGlnbm1lbnRBeGlzOiBhbGlnbkF4aXNcbiAgICB9O1xuICB9LCBbc2lkZU9mZnNldERlcCwgYWxpZ25PZmZzZXREZXAsIGlzUnRsLCBzaWRlUGFyYW1dKSk7XG4gIGNvbnN0IHNoaWZ0RGlzYWJsZWQgPSBjb2xsaXNpb25Bdm9pZGFuY2VBbGlnbiA9PT0gJ25vbmUnICYmIGNvbGxpc2lvbkF2b2lkYW5jZVNpZGUgIT09ICdzaGlmdCc7XG4gIGNvbnN0IGNyb3NzQXhpc1NoaWZ0RW5hYmxlZCA9ICFzaGlmdERpc2FibGVkICYmIChzdGlja3kgfHwgc2hpZnRDcm9zc0F4aXMgfHwgY29sbGlzaW9uQXZvaWRhbmNlU2lkZSA9PT0gJ3NoaWZ0Jyk7XG4gIGNvbnN0IGZsaXBNaWRkbGV3YXJlID0gY29sbGlzaW9uQXZvaWRhbmNlU2lkZSA9PT0gJ25vbmUnID8gbnVsbCA6IGZsaXAoe1xuICAgIC4uLmNvbW1vbkNvbGxpc2lvblByb3BzLFxuICAgIC8vIEVuc3VyZSB0aGUgcG9wdXAgZmxpcHMgaWYgaXQncyBiZWVuIGxpbWl0ZWQgYnkgaXRzIC0tYXZhaWxhYmxlLWhlaWdodCBhbmQgaXQgcmVzaXplcy5cbiAgICAvLyBTaW5jZSB0aGUgc2l6ZSgpIHBhZGRpbmcgaXMgc21hbGxlciB0aGFuIHRoZSBmbGlwKCkgcGFkZGluZywgZmxpcCgpIHdpbGwgdGFrZSBwcmVjZWRlbmNlLlxuICAgIHBhZGRpbmc6IHtcbiAgICAgIHRvcDogY29sbGlzaW9uUGFkZGluZy50b3AgKyBiaWFzICsgYmlhc1RvcCxcbiAgICAgIHJpZ2h0OiBjb2xsaXNpb25QYWRkaW5nLnJpZ2h0ICsgYmlhcyArIGJpYXNSaWdodCxcbiAgICAgIGJvdHRvbTogY29sbGlzaW9uUGFkZGluZy5ib3R0b20gKyBiaWFzICsgYmlhc0JvdHRvbSxcbiAgICAgIGxlZnQ6IGNvbGxpc2lvblBhZGRpbmcubGVmdCArIGJpYXMgKyBiaWFzTGVmdFxuICAgIH0sXG4gICAgbWFpbkF4aXM6ICFzaGlmdENyb3NzQXhpcyAmJiBjb2xsaXNpb25Bdm9pZGFuY2VTaWRlID09PSAnZmxpcCcsXG4gICAgY3Jvc3NBeGlzOiBjb2xsaXNpb25Bdm9pZGFuY2VBbGlnbiA9PT0gJ2ZsaXAnID8gJ2FsaWdubWVudCcgOiBmYWxzZSxcbiAgICBmYWxsYmFja0F4aXNTaWRlRGlyZWN0aW9uOiBjb2xsaXNpb25Bdm9pZGFuY2VGYWxsYmFja0F4aXNTaWRlXG4gIH0pO1xuICBjb25zdCBzaGlmdE1pZGRsZXdhcmUgPSBzaGlmdERpc2FibGVkID8gbnVsbCA6IGZsb2F0aW5nU2hpZnQoe1xuICAgIC4uLmNvbW1vbkNvbGxpc2lvblByb3BzLFxuICAgIC8vIFVzZSB0aGUgTGF5b3V0IFZpZXdwb3J0IHRvIGF2b2lkIHNoaWZ0aW5nIGFyb3VuZCB3aGVuIHBpbmNoLXpvb21pbmcuXG4gICAgcm9vdEJvdW5kYXJ5OiBzaGlmdFJvb3RCb3VuZGFyeSxcbiAgICBtYWluQXhpczogY29sbGlzaW9uQXZvaWRhbmNlQWxpZ24gIT09ICdub25lJyxcbiAgICBjcm9zc0F4aXM6IGNyb3NzQXhpc1NoaWZ0RW5hYmxlZCxcbiAgICBsaW1pdGVyOiBzdGlja3kgfHwgc2hpZnRDcm9zc0F4aXMgPyB1bmRlZmluZWQgOiBsaW1pdFNoaWZ0KGxpbWl0RGF0YSA9PiB7XG4gICAgICBpZiAoIWFycm93UmVmLmN1cnJlbnQpIHtcbiAgICAgICAgcmV0dXJuIHt9O1xuICAgICAgfVxuICAgICAgY29uc3Qge1xuICAgICAgICB3aWR0aCxcbiAgICAgICAgaGVpZ2h0XG4gICAgICB9ID0gYXJyb3dSZWYuY3VycmVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgIGNvbnN0IHNpZGVBeGlzID0gZ2V0U2lkZUF4aXMoZ2V0U2lkZShsaW1pdERhdGEucGxhY2VtZW50KSk7XG4gICAgICBjb25zdCBhcnJvd1NpemUgPSBzaWRlQXhpcyA9PT0gJ3knID8gd2lkdGggOiBoZWlnaHQ7XG4gICAgICBjb25zdCBvZmZzZXRBbW91bnQgPSBzaWRlQXhpcyA9PT0gJ3knID8gY29sbGlzaW9uUGFkZGluZy5sZWZ0ICsgY29sbGlzaW9uUGFkZGluZy5yaWdodCA6IGNvbGxpc2lvblBhZGRpbmcudG9wICsgY29sbGlzaW9uUGFkZGluZy5ib3R0b207XG4gICAgICByZXR1cm4ge1xuICAgICAgICBvZmZzZXQ6IGFycm93U2l6ZSAvIDIgKyBvZmZzZXRBbW91bnQgLyAyXG4gICAgICB9O1xuICAgIH0pXG4gIH0sIFtjb21tb25Db2xsaXNpb25Qcm9wcywgc3RpY2t5LCBzaGlmdENyb3NzQXhpcywgc2hpZnRSb290Qm91bmRhcnksIGNvbGxpc2lvblBhZGRpbmcsIGNvbGxpc2lvbkF2b2lkYW5jZUFsaWduXSk7XG5cbiAgLy8gaHR0cHM6Ly9mbG9hdGluZy11aS5jb20vZG9jcy9mbGlwI2NvbWJpbmluZy13aXRoLXNoaWZ0XG4gIC8vIEtleWVkIG9uIHRoZSBhbGlnbm1lbnQgYWN0dWFsbHkgYmVpbmcgcmVxdWVzdGVkLCBub3QgdGhlIHJhdyBwcm9wOiBhIGxvY2tlZCBhbGlnbm1lbnQgY2FuXG4gIC8vIGRpZmZlciBmcm9tIGBhbGlnbmAsIGFuZCB0aGUgb3JkZXJpbmcgaGFzIHRvIG1hdGNoIHRoZSBwbGFjZW1lbnQgdGhhdCBpcyBhc2tlZCBmb3IuXG4gIGlmIChjb2xsaXNpb25Bdm9pZGFuY2VTaWRlID09PSAnc2hpZnQnIHx8IGNvbGxpc2lvbkF2b2lkYW5jZUFsaWduID09PSAnc2hpZnQnIHx8IHBsYWNlbWVudEFsaWduID09PSAnY2VudGVyJykge1xuICAgIG1pZGRsZXdhcmUucHVzaChzaGlmdE1pZGRsZXdhcmUsIGZsaXBNaWRkbGV3YXJlKTtcbiAgfSBlbHNlIHtcbiAgICBtaWRkbGV3YXJlLnB1c2goZmxpcE1pZGRsZXdhcmUsIHNoaWZ0TWlkZGxld2FyZSk7XG4gIH1cbiAgbWlkZGxld2FyZS5wdXNoKHNpemUoe1xuICAgIC4uLmNvbW1vbkNvbGxpc2lvblByb3BzLFxuICAgIGFwcGx5KHtcbiAgICAgIGVsZW1lbnRzOiB7XG4gICAgICAgIGZsb2F0aW5nXG4gICAgICB9LFxuICAgICAgYXZhaWxhYmxlV2lkdGgsXG4gICAgICBhdmFpbGFibGVIZWlnaHQsXG4gICAgICByZWN0c1xuICAgIH0pIHtcbiAgICAgIGlmICghbW91bnRlZFJlZi5jdXJyZW50KSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGZsb2F0aW5nU3R5bGUgPSBmbG9hdGluZy5zdHlsZTtcbiAgICAgIGZsb2F0aW5nU3R5bGUuc2V0UHJvcGVydHkoQVZBSUxBQkxFX1dJRFRIX1ZBUiwgYCR7YXZhaWxhYmxlV2lkdGh9cHhgKTtcbiAgICAgIGZsb2F0aW5nU3R5bGUuc2V0UHJvcGVydHkoQVZBSUxBQkxFX0hFSUdIVF9WQVIsIGAke2F2YWlsYWJsZUhlaWdodH1weGApO1xuXG4gICAgICAvLyBTbmFwIGFuY2hvciBkaW1lbnNpb25zIHRvIGRldmljZSBwaXhlbHMgdG8gZW5zdXJlIHRoZSBwb3B1cCdzIHZpc3VhbCB3aWR0aCBtYXRjaGVzIHRoZSBhbmNob3IncyBvbmUuXG4gICAgICBjb25zdCBkcHIgPSBvd25lcldpbmRvdyhmbG9hdGluZykuZGV2aWNlUGl4ZWxSYXRpbyB8fCAxO1xuICAgICAgY29uc3Qge1xuICAgICAgICB4LFxuICAgICAgICB5LFxuICAgICAgICB3aWR0aCxcbiAgICAgICAgaGVpZ2h0XG4gICAgICB9ID0gcmVjdHMucmVmZXJlbmNlO1xuICAgICAgY29uc3QgYW5jaG9yV2lkdGggPSAoTWF0aC5yb3VuZCgoeCArIHdpZHRoKSAqIGRwcikgLSBNYXRoLnJvdW5kKHggKiBkcHIpKSAvIGRwcjtcbiAgICAgIGNvbnN0IGFuY2hvckhlaWdodCA9IChNYXRoLnJvdW5kKCh5ICsgaGVpZ2h0KSAqIGRwcikgLSBNYXRoLnJvdW5kKHkgKiBkcHIpKSAvIGRwcjtcbiAgICAgIGZsb2F0aW5nU3R5bGUuc2V0UHJvcGVydHkoQ29tbW9uUG9zaXRpb25lckNzc1ZhcnMuYW5jaG9yV2lkdGgsIGAke2FuY2hvcldpZHRofXB4YCk7XG4gICAgICBmbG9hdGluZ1N0eWxlLnNldFByb3BlcnR5KENvbW1vblBvc2l0aW9uZXJDc3NWYXJzLmFuY2hvckhlaWdodCwgYCR7YW5jaG9ySGVpZ2h0fXB4YCk7XG4gICAgfVxuICB9KSwgYXJyb3coc3RhdGUgPT4gKHtcbiAgICAvLyBgdHJhbnNmb3JtLW9yaWdpbmAgY2FsY3VsYXRpb25zIHJlbHkgb24gYW4gZWxlbWVudCBleGlzdGluZy4gSWYgdGhlIGFycm93IGhhc24ndCBiZWVuIHNldCxcbiAgICAvLyB3ZSdsbCBjcmVhdGUgYSBmYWtlIGVsZW1lbnQuXG4gICAgZWxlbWVudDogYXJyb3dSZWYuY3VycmVudCB8fCBvd25lckRvY3VtZW50KHN0YXRlLmVsZW1lbnRzLmZsb2F0aW5nKS5jcmVhdGVFbGVtZW50KCdkaXYnKSxcbiAgICAvLyBObyBwYWRkaW5nIGZvciB0aGUgZmFrZSBhcnJvdzogaXQgd291bGQgZGlzcGxhY2UgYWxpZ25lZCBwb3B1cHMgb24gbmFycm93IGFuY2hvcnMuXG4gICAgcGFkZGluZzogYXJyb3dSZWYuY3VycmVudCA/IGFycm93UGFkZGluZyA6IDBcbiAgfSksIFthcnJvd1BhZGRpbmddKSwge1xuICAgIG5hbWU6ICd0cmFuc2Zvcm1PcmlnaW4nLFxuICAgIGZuKHN0YXRlKSB7XG4gICAgICBjb25zdCB7XG4gICAgICAgIGVsZW1lbnRzOiB7XG4gICAgICAgICAgZmxvYXRpbmdcbiAgICAgICAgfSxcbiAgICAgICAgbWlkZGxld2FyZURhdGEsXG4gICAgICAgIHBsYWNlbWVudDogcmVuZGVyZWRQbGFjZW1lbnQsXG4gICAgICAgIHBsYXRmb3JtLFxuICAgICAgICByZWN0cyxcbiAgICAgICAgeVxuICAgICAgfSA9IHN0YXRlO1xuICAgICAgY29uc3QgcmVuZGVyZWRTaWRlID0gZ2V0U2lkZShyZW5kZXJlZFBsYWNlbWVudCk7XG4gICAgICBjb25zdCByZW5kZXJlZEFsaWduID0gZ2V0QWxpZ25tZW50KHJlbmRlcmVkUGxhY2VtZW50KTtcbiAgICAgIGNvbnN0IGlzVmVydGljYWwgPSBnZXRTaWRlQXhpcyhyZW5kZXJlZFNpZGUpID09PSAneSc7XG4gICAgICBjb25zdCBhcnJvd0VsID0gYXJyb3dSZWYuY3VycmVudDtcbiAgICAgIGNvbnN0IHNpZGVPZmZzZXRWYWx1ZSA9IHR5cGVvZiBzaWRlT2Zmc2V0ID09PSAnZnVuY3Rpb24nID8gc2lkZU9mZnNldChnZXRPZmZzZXREYXRhKHN0YXRlLCBzaWRlUGFyYW0sIGlzUnRsKSkgOiBzaWRlT2Zmc2V0O1xuXG4gICAgICAvLyBBbiBhbGlnbmVkIGFycm93bGVzcyBwb3B1cCBncm93cyBmcm9tIGl0cyBhbGlnbmVkIGVkZ2UsIHVudGlsIGEgc2hpZnQgKGJleW9uZCBzdWJwaXhlbClcbiAgICAgIC8vIGJyZWFrcyBpdHMgYWxpZ25tZW50IHdpdGggdGhlIGFuY2hvci4gRXZlcnl0aGluZyBlbHNlIGdyb3dzIGZyb20gdGhlIGFycm93LCByZWFsIG9yIGZha2UuXG4gICAgICBsZXQgY3Jvc3NPcmlnaW47XG4gICAgICBpZiAoIWFycm93RWwgJiYgcmVuZGVyZWRBbGlnbiAmJiBNYXRoLmFicyhpc1ZlcnRpY2FsID8gbWlkZGxld2FyZURhdGEuc2hpZnQ/LnggfHwgMCA6IG1pZGRsZXdhcmVEYXRhLnNoaWZ0Py55IHx8IDApIDw9IDEpIHtcbiAgICAgICAgLy8gVGhlIHBsYXRmb3JtIGRpcmVjdGlvbiwgbm90IGBpc1J0bGA6IGl0IG11c3QgbWF0Y2ggd2hhdCBGbG9hdGluZyBVSSBwbGFjZWQgd2l0aC5cbiAgICAgICAgY3Jvc3NPcmlnaW4gPSByZW5kZXJlZEFsaWduID09PSAnc3RhcnQnID09PSAoaXNWZXJ0aWNhbCAmJiBwbGF0Zm9ybS5pc1JUTD8uKGZsb2F0aW5nKSA9PT0gdHJ1ZSkgPyAnMTAwJScgOiAnMCUnO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgY29uc3QgYXJyb3dPZmZzZXQgPSBpc1ZlcnRpY2FsID8gbWlkZGxld2FyZURhdGEuYXJyb3c/LnggfHwgMCA6IG1pZGRsZXdhcmVEYXRhLmFycm93Py55IHx8IDA7XG4gICAgICAgIGNvbnN0IGFycm93U2l6ZSA9IGlzVmVydGljYWwgPyBhcnJvd0VsPy5jbGllbnRXaWR0aCB8fCAwIDogYXJyb3dFbD8uY2xpZW50SGVpZ2h0IHx8IDA7XG4gICAgICAgIGNyb3NzT3JpZ2luID0gYCR7YXJyb3dPZmZzZXQgKyBhcnJvd1NpemUgLyAyfXB4YDtcbiAgICAgIH1cblxuICAgICAgLy8gU2lkZSBheGlzOiB0aGUgYW5jaG9yLWZhY2luZyBlZGdlLCBvciB0aGUgYW5jaG9yJ3MgY2VudGVyIHdoZW4gdGhlIHBvcHVwIG92ZXJsYXBzIGl0LlxuICAgICAgbGV0IHNpZGVPcmlnaW4gPSByZW5kZXJlZFNpZGUgPT09ICd0b3AnIHx8IHJlbmRlcmVkU2lkZSA9PT0gJ2xlZnQnID8gYGNhbGMoMTAwJSArICR7c2lkZU9mZnNldFZhbHVlfXB4KWAgOiBgJHstc2lkZU9mZnNldFZhbHVlfXB4YDtcbiAgICAgIGlmIChjcm9zc0F4aXNTaGlmdEVuYWJsZWQgJiYgaXNWZXJ0aWNhbCAmJiBNYXRoLmFicyhtaWRkbGV3YXJlRGF0YS5zaGlmdD8ueSB8fCAwKSA+IHNpZGVPZmZzZXRWYWx1ZSkge1xuICAgICAgICBzaWRlT3JpZ2luID0gYCR7cmVjdHMucmVmZXJlbmNlLnkgKyByZWN0cy5yZWZlcmVuY2UuaGVpZ2h0IC8gMiAtIHl9cHhgO1xuICAgICAgfVxuICAgICAgZmxvYXRpbmcuc3R5bGUuc2V0UHJvcGVydHkoQ29tbW9uUG9zaXRpb25lckNzc1ZhcnMudHJhbnNmb3JtT3JpZ2luLCBpc1ZlcnRpY2FsID8gYCR7Y3Jvc3NPcmlnaW59ICR7c2lkZU9yaWdpbn1gIDogYCR7c2lkZU9yaWdpbn0gJHtjcm9zc09yaWdpbn1gKTtcbiAgICAgIHJldHVybiB7fTtcbiAgICB9XG4gIH0sIGhpZGUsIGFkYXB0aXZlT3JpZ2luKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICAvLyBFbnN1cmUgcG9zaXRpb25pbmcgZG9lc24ndCBydW4gaW5pdGlhbGx5IGZvciBga2VlcE1vdW50ZWRgIGVsZW1lbnRzIHRoYXRcbiAgICAvLyBhcmVuJ3QgaW5pdGlhbGx5IG9wZW4uXG4gICAgaWYgKCFtb3VudGVkICYmIGZsb2F0aW5nUm9vdENvbnRleHQpIHtcbiAgICAgIGZsb2F0aW5nUm9vdENvbnRleHQudXBkYXRlKHtcbiAgICAgICAgcmVmZXJlbmNlRWxlbWVudDogbnVsbCxcbiAgICAgICAgZmxvYXRpbmdFbGVtZW50OiBudWxsLFxuICAgICAgICBkb21SZWZlcmVuY2VFbGVtZW50OiBudWxsLFxuICAgICAgICBwb3NpdGlvblJlZmVyZW5jZTogbnVsbFxuICAgICAgfSk7XG4gICAgfVxuICB9LCBbbW91bnRlZCwgZmxvYXRpbmdSb290Q29udGV4dF0pO1xuICBjb25zdCBhdXRvVXBkYXRlT3B0aW9ucyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBhbmNlc3RvclNjcm9sbDogIWRpc2FibGVBbmNob3JUcmFja2luZyxcbiAgICBlbGVtZW50UmVzaXplOiAhZGlzYWJsZUFuY2hvclRyYWNraW5nICYmIHR5cGVvZiBSZXNpemVPYnNlcnZlciAhPT0gJ3VuZGVmaW5lZCcsXG4gICAgbGF5b3V0U2hpZnQ6ICFkaXNhYmxlQW5jaG9yVHJhY2tpbmcgJiYgdHlwZW9mIEludGVyc2VjdGlvbk9ic2VydmVyICE9PSAndW5kZWZpbmVkJ1xuICB9KSwgW2Rpc2FibGVBbmNob3JUcmFja2luZ10pO1xuICBjb25zdCB7XG4gICAgcmVmcyxcbiAgICBlbGVtZW50cyxcbiAgICB4LFxuICAgIHksXG4gICAgbWlkZGxld2FyZURhdGEsXG4gICAgdXBkYXRlLFxuICAgIHBsYWNlbWVudDogcmVuZGVyZWRQbGFjZW1lbnQsXG4gICAgY29udGV4dCxcbiAgICBpc1Bvc2l0aW9uZWQsXG4gICAgZmxvYXRpbmdTdHlsZXM6IG9yaWdpbmFsRmxvYXRpbmdTdHlsZXNcbiAgfSA9IHVzZUZsb2F0aW5nSG9vayh7XG4gICAgcm9vdENvbnRleHQ6IGZsb2F0aW5nUm9vdENvbnRleHQsXG4gICAgb3Blbjoga2VlcE1vdW50ZWQgPyBtb3VudGVkIDogdW5kZWZpbmVkLFxuICAgIHBsYWNlbWVudCxcbiAgICBtaWRkbGV3YXJlLFxuICAgIHN0cmF0ZWd5OiBwb3NpdGlvbk1ldGhvZCxcbiAgICB3aGlsZUVsZW1lbnRzTW91bnRlZDoga2VlcE1vdW50ZWQgPyB1bmRlZmluZWQgOiAoLi4uYXJncykgPT4gYXV0b1VwZGF0ZSguLi5hcmdzLCBhdXRvVXBkYXRlT3B0aW9ucyksXG4gICAgbm9kZUlkLFxuICAgIGV4dGVybmFsVHJlZVxuICB9KTtcbiAgY29uc3Qge1xuICAgIHNpZGVYLFxuICAgIHNpZGVZXG4gIH0gPSBtaWRkbGV3YXJlRGF0YS5hZGFwdGl2ZU9yaWdpbiB8fCBERUZBVUxUX1NJREVTO1xuXG4gIC8vIERlZmF1bHQgdG8gYGZpeGVkYCB3aGVuIG5vdCBwb3NpdGlvbmVkIHRvIHByZXZlbnQgYGF1dG9Gb2N1c2Agc2Nyb2xsIGp1bXBzLlxuICAvLyBUaGlzIGVuc3VyZXMgdGhlIHBvcHVwIGlzIGluc2lkZSB0aGUgdmlld3BvcnQgaW5pdGlhbGx5IGJlZm9yZSBpdCBnZXRzIHBvc2l0aW9uZWQuXG4gIGNvbnN0IHJlc29sdmVkUG9zaXRpb24gPSBpc1Bvc2l0aW9uZWQgPyBwb3NpdGlvbk1ldGhvZCA6ICdmaXhlZCc7XG4gIGNvbnN0IGZsb2F0aW5nU3R5bGVzID0gUmVhY3QudXNlTWVtbygoKSA9PiB7XG4gICAgbGV0IGJhc2U7XG4gICAgaWYgKCFpc1Bvc2l0aW9uZWQpIHtcbiAgICAgIC8vIFVudGlsIGEgcG9zaXRpb24gZm9yIHRoZSBjdXJyZW50IG9wZW4gaXMgY29tcHV0ZWQsIGlnbm9yZSBhbnkgY29vcmRpbmF0ZXMgcmV0YWluZWQgZnJvbSBhXG4gICAgICAvLyBwcmV2aW91cyBvcGVuIChvciBmcm9tIGEgcGFzcyB0aGF0IG1lYXN1cmVkIHRoZSBoaWRkZW4gcG9wdXAgYXMgMHgwKS4gUmVuZGVyaW5nIHRoZVxuICAgICAgLy8gZnVsbC1zaXplIHBvcHVwIGF0IHN1Y2ggc3RhbGUgY29vcmRpbmF0ZXMgY2FuIG92ZXJmbG93IHRoZSBsYXlvdXQgdmlld3BvcnQsIHdoaWNoIG1ha2VzXG4gICAgICAvLyBtb2JpbGUgQ2hyb21lIHpvb20gdGhlIHBhZ2Ugb3V0IGFuZCByZWZsb3cgZXZlcnl0aGluZyB0aGUgcG9wdXAgaXMgYW5jaG9yZWQgdG8uXG4gICAgICBiYXNlID0ge1xuICAgICAgICBwb3NpdGlvbjogcmVzb2x2ZWRQb3NpdGlvbixcbiAgICAgICAgdG9wOiAwLFxuICAgICAgICBsZWZ0OiAwXG4gICAgICB9O1xuICAgIH0gZWxzZSBpZiAoYWRhcHRpdmVPcmlnaW4pIHtcbiAgICAgIGJhc2UgPSB7XG4gICAgICAgIHBvc2l0aW9uOiByZXNvbHZlZFBvc2l0aW9uLFxuICAgICAgICBbc2lkZVhdOiB4LFxuICAgICAgICBbc2lkZVldOiB5XG4gICAgICB9O1xuICAgIH0gZWxzZSB7XG4gICAgICBiYXNlID0ge1xuICAgICAgICAuLi5vcmlnaW5hbEZsb2F0aW5nU3R5bGVzLFxuICAgICAgICBwb3NpdGlvbjogcmVzb2x2ZWRQb3NpdGlvblxuICAgICAgfTtcbiAgICB9XG5cbiAgICAvLyBTZWVkIHRoZSBhdmFpbGFibGUgc2l6ZSB2YXJzIHNvIGNvbnN1bWVyIGBtYXgtaGVpZ2h0OiBtaW4oeCwgdmFyKC0tYXZhaWxhYmxlLWhlaWdodCkpYCBydWxlc1xuICAgIC8vIHJlc29sdmUgdG8gYSB2YWxpZCBsZW5ndGggb24gdGhlIGZpcnN0IHBvc2l0aW9uaW5nIHBhc3MsIGJlZm9yZSBgc2l6ZSgpYCB3cml0ZXMgdGhlIHJlYWxcbiAgICAvLyB2YWx1ZXMuIFdpdGhvdXQgYSBmYWxsYmFjayB0aGUgdW5yZXNvbHZlZCBgdmFyKClgIGludmFsaWRhdGVzIHRoZSB3aG9sZSBkZWNsYXJhdGlvbiwgc28gdGhlXG4gICAgLy8gcG9wdXAgaXMgbWVhc3VyZWQgdW5jb25zdHJhaW5lZCB3aGlsZSBgZmxpcCgpYCBwaWNrcyBpdHMgc2lkZSwgYWdhaW5zdCB0aGUgZnVsbCBjb250ZW50XG4gICAgLy8gaGVpZ2h0IHJhdGhlciB0aGFuIHRoZSBjYXBwZWQgb25lLiBTZWVkZWQgdW5jb25kaXRpb25hbGx5IChub3Qgb25seSB3aGlsZSBgIWlzUG9zaXRpb25lZGApOlxuICAgIC8vIHRoZSBrZXlzIG11c3Qgc3RheSBwcmVzZW50IHdpdGggYSBjb25zdGFudCB2YWx1ZSBzbyBSZWFjdCdzIHBlci1wcm9wZXJ0eSBzdHlsZSBkaWZmIG5ldmVyXG4gICAgLy8gcmV3cml0ZXMgdGhlbSBhZnRlciBtb3VudCwgcHJlc2VydmluZyB0aGUgcHggdmFsdWVzIGBzaXplKClgIHNldHMgaW1wZXJhdGl2ZWx5LiBNb3ZpbmcgdGhlbVxuICAgIC8vIGludG8gdGhlIGAhaXNQb3NpdGlvbmVkYCBicmFuY2ggbWFrZXMgUmVhY3QgcmVtb3ZlIHRoZW0gb25jZSBwb3NpdGlvbmVkLCB3aXBpbmcgYHNpemUoKWAnc1xuICAgIC8vIHZhbHVlcyBhbmQgbGVhdmluZyB0aGUgcG9wdXAgdW5jb25zdHJhaW5lZC5cbiAgICBiYXNlW0FWQUlMQUJMRV9XSURUSF9WQVJdID0gJzEwMHZ3JztcbiAgICBiYXNlW0FWQUlMQUJMRV9IRUlHSFRfVkFSXSA9ICcxMDB2aCc7XG4gICAgaWYgKCFpc1Bvc2l0aW9uZWQpIHtcbiAgICAgIGJhc2Uub3BhY2l0eSA9IDA7XG4gICAgfVxuICAgIHJldHVybiBiYXNlO1xuICB9LCBbYWRhcHRpdmVPcmlnaW4sIHJlc29sdmVkUG9zaXRpb24sIHNpZGVYLCB4LCBzaWRlWSwgeSwgb3JpZ2luYWxGbG9hdGluZ1N0eWxlcywgaXNQb3NpdGlvbmVkXSk7XG4gIGNvbnN0IHJlZ2lzdGVyZWRQb3NpdGlvblJlZmVyZW5jZVJlZiA9IFJlYWN0LnVzZVJlZihudWxsKTtcbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIW1vdW50ZWQpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgYW5jaG9yVmFsdWUgPSBhbmNob3JWYWx1ZVJlZi5jdXJyZW50O1xuICAgIGNvbnN0IHJlc29sdmVkQW5jaG9yID0gdHlwZW9mIGFuY2hvclZhbHVlID09PSAnZnVuY3Rpb24nID8gYW5jaG9yVmFsdWUoKSA6IGFuY2hvclZhbHVlO1xuICAgIGNvbnN0IHVud3JhcHBlZEVsZW1lbnQgPSAoaXNSZWYocmVzb2x2ZWRBbmNob3IpID8gcmVzb2x2ZWRBbmNob3IuY3VycmVudCA6IHJlc29sdmVkQW5jaG9yKSB8fCBudWxsO1xuICAgIGNvbnN0IGZpbmFsQW5jaG9yID0gdW53cmFwcGVkRWxlbWVudCB8fCBudWxsO1xuICAgIGlmIChmaW5hbEFuY2hvciAhPT0gcmVnaXN0ZXJlZFBvc2l0aW9uUmVmZXJlbmNlUmVmLmN1cnJlbnQpIHtcbiAgICAgIHJlZnMuc2V0UG9zaXRpb25SZWZlcmVuY2UoZmluYWxBbmNob3IpO1xuICAgICAgcmVnaXN0ZXJlZFBvc2l0aW9uUmVmZXJlbmNlUmVmLmN1cnJlbnQgPSBmaW5hbEFuY2hvcjtcbiAgICB9XG4gIH0sIFttb3VudGVkLCByZWZzLCBhbmNob3JEZXAsIGFuY2hvclZhbHVlUmVmXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFtb3VudGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGFuY2hvclZhbHVlID0gYW5jaG9yVmFsdWVSZWYuY3VycmVudDtcblxuICAgIC8vIFJlZnMgZnJvbSBwYXJlbnQgY29tcG9uZW50cyBhcmUgc2V0IGFmdGVyIHVzZUxheW91dEVmZmVjdCBydW5zIGFuZCBhcmUgYXZhaWxhYmxlIGluIHVzZUVmZmVjdC5cbiAgICAvLyBUaGVyZWZvcmUsIGlmIHRoZSBhbmNob3IgaXMgYSByZWYsIHdlIG5lZWQgdG8gdXBkYXRlIHRoZSBwb3NpdGlvbiByZWZlcmVuY2UgaW4gdXNlRWZmZWN0LlxuICAgIGlmICh0eXBlb2YgYW5jaG9yVmFsdWUgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGlzUmVmKGFuY2hvclZhbHVlKSAmJiBhbmNob3JWYWx1ZS5jdXJyZW50ICE9PSByZWdpc3RlcmVkUG9zaXRpb25SZWZlcmVuY2VSZWYuY3VycmVudCkge1xuICAgICAgcmVmcy5zZXRQb3NpdGlvblJlZmVyZW5jZShhbmNob3JWYWx1ZS5jdXJyZW50KTtcbiAgICAgIHJlZ2lzdGVyZWRQb3NpdGlvblJlZmVyZW5jZVJlZi5jdXJyZW50ID0gYW5jaG9yVmFsdWUuY3VycmVudDtcbiAgICB9XG4gIH0sIFttb3VudGVkLCByZWZzLCBhbmNob3JEZXAsIGFuY2hvclZhbHVlUmVmXSk7XG4gIFJlYWN0LnVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKGtlZXBNb3VudGVkICYmIG1vdW50ZWQgJiYgZWxlbWVudHMucmVmZXJlbmNlICYmIGVsZW1lbnRzLmZsb2F0aW5nKSB7XG4gICAgICByZXR1cm4gYXV0b1VwZGF0ZShlbGVtZW50cy5yZWZlcmVuY2UsIGVsZW1lbnRzLmZsb2F0aW5nLCB1cGRhdGUsIGF1dG9VcGRhdGVPcHRpb25zKTtcbiAgICB9XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfSwgW2tlZXBNb3VudGVkLCBtb3VudGVkLCBlbGVtZW50cywgdXBkYXRlLCBhdXRvVXBkYXRlT3B0aW9uc10pO1xuICBjb25zdCByZW5kZXJlZFNpZGUgPSBnZXRTaWRlKHJlbmRlcmVkUGxhY2VtZW50KTtcbiAgY29uc3QgbG9naWNhbFJlbmRlcmVkU2lkZSA9IGdldExvZ2ljYWxTaWRlKHNpZGVQYXJhbSwgcmVuZGVyZWRTaWRlLCBpc1J0bCk7XG4gIGNvbnN0IHJlbmRlcmVkQWxpZ24gPSBnZXRBbGlnbm1lbnQocmVuZGVyZWRQbGFjZW1lbnQpIHx8ICdjZW50ZXInO1xuICBjb25zdCBhbmNob3JIaWRkZW4gPSBCb29sZWFuKG1pZGRsZXdhcmVEYXRhLmhpZGU/LnJlZmVyZW5jZUhpZGRlbik7XG5cbiAgLy8gTG9ja3MgdGhlIGZsaXBwZWQgc2lkZSwgYW5kIHRoZSBhbGlnbm1lbnQgdG9vIHdoZW4gdGhlIGNvbnN1bWVyIG9wdHMgaW4sIHdoaWxlIGZpbHRlcmluZ1xuICAvLyByZXNpemVzIHRoZSBwb3B1cC5cbiAgdXNlSXNvTGF5b3V0RWZmZWN0KCgpID0+IHtcbiAgICBpZiAobGF6eUZsaXAgJiYgbW91bnRlZCAmJiBpc1Bvc2l0aW9uZWQgJiYgKHJlbmRlcmVkU2lkZSAhPT0gc2lkZSB8fCBsb2NrQWxpZ24gJiYgcmVuZGVyZWRBbGlnbiAhPT0gcGxhY2VtZW50QWxpZ24pKSB7XG4gICAgICBzZXRNb3VudFBsYWNlbWVudChyZW5kZXJlZFBsYWNlbWVudCk7XG4gICAgfVxuICB9LCBbbGF6eUZsaXAsIGxvY2tBbGlnbiwgbW91bnRlZCwgaXNQb3NpdGlvbmVkLCByZW5kZXJlZFBsYWNlbWVudCwgcmVuZGVyZWRTaWRlLCByZW5kZXJlZEFsaWduLCBzaWRlLCBwbGFjZW1lbnRBbGlnbl0pO1xuICBjb25zdCBhcnJvd1N0eWxlcyA9IFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICB0b3A6IG1pZGRsZXdhcmVEYXRhLmFycm93Py55LFxuICAgIGxlZnQ6IG1pZGRsZXdhcmVEYXRhLmFycm93Py54XG4gIH0pLCBbbWlkZGxld2FyZURhdGEuYXJyb3ddKTtcbiAgY29uc3QgYXJyb3dVbmNlbnRlcmVkID0gbWlkZGxld2FyZURhdGEuYXJyb3c/LmNlbnRlck9mZnNldCAhPT0gMDtcbiAgcmV0dXJuIFJlYWN0LnVzZU1lbW8oKCkgPT4gKHtcbiAgICBwb3NpdGlvbmVyU3R5bGVzOiBmbG9hdGluZ1N0eWxlcyxcbiAgICBhcnJvd1N0eWxlcyxcbiAgICBhcnJvd1JlZixcbiAgICBhcnJvd1VuY2VudGVyZWQsXG4gICAgc2lkZTogbG9naWNhbFJlbmRlcmVkU2lkZSxcbiAgICBhbGlnbjogcmVuZGVyZWRBbGlnbixcbiAgICBwaHlzaWNhbFNpZGU6IHJlbmRlcmVkU2lkZSxcbiAgICBhbmNob3JIaWRkZW4sXG4gICAgcmVmcyxcbiAgICBjb250ZXh0LFxuICAgIGlzUG9zaXRpb25lZCxcbiAgICB1cGRhdGVcbiAgfSksIFtmbG9hdGluZ1N0eWxlcywgYXJyb3dTdHlsZXMsIGFycm93UmVmLCBhcnJvd1VuY2VudGVyZWQsIGxvZ2ljYWxSZW5kZXJlZFNpZGUsIHJlbmRlcmVkQWxpZ24sIHJlbmRlcmVkU2lkZSwgYW5jaG9ySGlkZGVuLCByZWZzLCBjb250ZXh0LCBpc1Bvc2l0aW9uZWQsIHVwZGF0ZV0pO1xufVxuZnVuY3Rpb24gaXNSZWYocGFyYW0pIHtcbiAgcmV0dXJuIHBhcmFtICE9IG51bGwgJiYgJ2N1cnJlbnQnIGluIHBhcmFtO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0IHsgcG9wdXBTdGF0ZU1hcHBpbmcgfSBmcm9tIFwiLi9wb3B1cFN0YXRlTWFwcGluZy5tanNcIjtcbmltcG9ydCB7IHVzZVJlbmRlckVsZW1lbnQgfSBmcm9tIFwiLi4vaW50ZXJuYWxzL3VzZVJlbmRlckVsZW1lbnQubWpzXCI7XG5pbXBvcnQgeyBnZXREaXNhYmxlZE1vdW50VHJhbnNpdGlvblN0eWxlcyB9IGZyb20gXCIuLi9pbnRlcm5hbHMvZ2V0RGlzYWJsZWRNb3VudFRyYW5zaXRpb25TdHlsZXMubWpzXCI7XG4vKipcbiAqIFJlbmRlcnMgdGhlIHNoYXJlZCBvdXRlciBQb3NpdGlvbmVyIGVsZW1lbnQgdXNlZCBieSBwb3B1cCBjb21wb25lbnRzLlxuICogQXBwbGllcyB0aGUgY29tbW9uIHJvbGUsIGhpZGRlbiBzdGF0ZSwgdHJhbnNpdGlvbiBzdHlsZXMsIHN0YXRlIGF0dHJpYnV0ZXMsIGFuZCBvcHRpb25hbCBpbmVydCBzdHlsaW5nLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlUG9zaXRpb25lcihjb21wb25lbnRQcm9wcywgc3RhdGUsIHtcbiAgc3R5bGVzLFxuICB0cmFuc2l0aW9uU3RhdHVzLFxuICBwcm9wcyxcbiAgcmVmcyxcbiAgaGlkZGVuLFxuICBpbmVydCA9IGZhbHNlXG59KSB7XG4gIGNvbnN0IHN0eWxlID0ge1xuICAgIC4uLnN0eWxlc1xuICB9O1xuICBpZiAoaW5lcnQpIHtcbiAgICBzdHlsZS5wb2ludGVyRXZlbnRzID0gJ25vbmUnO1xuICB9XG4gIHJldHVybiB1c2VSZW5kZXJFbGVtZW50KCdkaXYnLCBjb21wb25lbnRQcm9wcywge1xuICAgIHN0YXRlLFxuICAgIHJlZjogcmVmcyxcbiAgICBwcm9wczogW3tcbiAgICAgIHJvbGU6ICdwcmVzZW50YXRpb24nLFxuICAgICAgaGlkZGVuLFxuICAgICAgc3R5bGVcbiAgICB9LCBnZXREaXNhYmxlZE1vdW50VHJhbnNpdGlvblN0eWxlcyh0cmFuc2l0aW9uU3RhdHVzKSwgcHJvcHNdLFxuICAgIHN0YXRlQXR0cmlidXRlc01hcHBpbmc6IHBvcHVwU3RhdGVNYXBwaW5nXG4gIH0pO1xufSIsIid1c2UgY2xpZW50JztcblxuaW1wb3J0ICogYXMgUmVhY3QgZnJvbSAncmVhY3QnO1xuXG4vKipcbiAqIFJldHVybnMgYSBwcmV2aW91cyB2YWx1ZSBvZiBpdHMgYXJndW1lbnQuXG4gKiBAcGFyYW0gdmFsdWUgQ3VycmVudCB2YWx1ZS5cbiAqIEByZXR1cm5zIFByZXZpb3VzIHZhbHVlLCBvciBudWxsIGlmIHRoZXJlIGlzIG5vIHByZXZpb3VzIHZhbHVlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gdXNlUHJldmlvdXNWYWx1ZSh2YWx1ZSkge1xuICBjb25zdCBbc3RhdGUsIHNldFN0YXRlXSA9IFJlYWN0LnVzZVN0YXRlKHtcbiAgICBjdXJyZW50OiB2YWx1ZSxcbiAgICBwcmV2aW91czogbnVsbFxuICB9KTtcbiAgaWYgKCFPYmplY3QuaXModmFsdWUsIHN0YXRlLmN1cnJlbnQpKSB7XG4gICAgc2V0U3RhdGUoe1xuICAgICAgY3VycmVudDogdmFsdWUsXG4gICAgICBwcmV2aW91czogc3RhdGUuY3VycmVudFxuICAgIH0pO1xuICB9XG4gIHJldHVybiBzdGF0ZS5wcmV2aW91cztcbn0iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUdBLFNBQVMsMkJBQTJCLE1BQU0sV0FBVyxLQUFLO0NBQ3hELElBQUksRUFDRixXQUNBLGFBQ0U7Q0FDSixNQUFNLFdBQVcsWUFBWSxTQUFTO0NBQ3RDLE1BQU0sZ0JBQWdCLGlCQUFpQixTQUFTO0NBQ2hELE1BQU0sY0FBYyxjQUFjLGFBQWE7Q0FDL0MsTUFBTSxPQUFPLFFBQVEsU0FBUztDQUM5QixNQUFNLGFBQWEsYUFBYTtDQUNoQyxNQUFNLFVBQVUsVUFBVSxJQUFJLFVBQVUsUUFBUSxJQUFJLFNBQVMsUUFBUTtDQUNyRSxNQUFNLFVBQVUsVUFBVSxJQUFJLFVBQVUsU0FBUyxJQUFJLFNBQVMsU0FBUztDQUN2RSxNQUFNLGNBQWMsVUFBVSxlQUFlLElBQUksU0FBUyxlQUFlO0NBQ3pFLElBQUk7Q0FDSixRQUFRLE1BQVI7RUFDRSxLQUFLO0dBQ0gsU0FBUztJQUNQLEdBQUc7SUFDSCxHQUFHLFVBQVUsSUFBSSxTQUFTO0dBQzVCO0dBQ0E7RUFDRixLQUFLO0dBQ0gsU0FBUztJQUNQLEdBQUc7SUFDSCxHQUFHLFVBQVUsSUFBSSxVQUFVO0dBQzdCO0dBQ0E7RUFDRixLQUFLO0dBQ0gsU0FBUztJQUNQLEdBQUcsVUFBVSxJQUFJLFVBQVU7SUFDM0IsR0FBRztHQUNMO0dBQ0E7RUFDRixLQUFLO0dBQ0gsU0FBUztJQUNQLEdBQUcsVUFBVSxJQUFJLFNBQVM7SUFDMUIsR0FBRztHQUNMO0dBQ0E7RUFDRixTQUNFLFNBQVM7R0FDUCxHQUFHLFVBQVU7R0FDYixHQUFHLFVBQVU7RUFDZjtDQUNKO0NBQ0EsTUFBTSxZQUFZLGFBQWEsU0FBUztDQUN4QyxJQUFJLFdBQ0YsT0FBTyxrQkFBa0IsZUFBZSxjQUFjLFFBQVEsSUFBSSxPQUFPLE9BQU8sYUFBYSxLQUFLO0NBRXBHLE9BQU87QUFDVDs7Ozs7Ozs7O0FBVUEsZUFBZSxlQUFlLE9BQU8sU0FBUztDQUM1QyxJQUFJO0NBQ0osSUFBSSxZQUFZLEtBQUssR0FDbkIsVUFBVSxDQUFDO0NBRWIsTUFBTSxFQUNKLEdBQ0EsR0FDQSxVQUNBLE9BQ0EsVUFDQSxhQUNFO0NBQ0osTUFBTSxFQUNKLFdBQVcscUJBQ1gsZUFBZSxZQUNmLGlCQUFpQixZQUNqQixjQUFjLE9BQ2QsVUFBVSxNQUNSLFNBQVMsU0FBUyxLQUFLO0NBQzNCLE1BQU0sZ0JBQWdCLGlCQUFpQixPQUFPO0NBRTlDLE1BQU0sVUFBVSxTQUFTLGNBRE4sbUJBQW1CLGFBQWEsY0FBYyxhQUNiO0NBQ3BELE1BQU0scUJBQXFCLGlCQUFpQixNQUFNLFNBQVMsZ0JBQWdCO0VBQ3pFLFdBQVcsd0JBQXdCLE9BQU8sU0FBUyxhQUFhLE9BQU8sS0FBSyxJQUFJLFNBQVMsVUFBVSxPQUFPLE9BQU8sT0FBTyx3QkFBd0IsUUFBUSxVQUFVLFFBQVEsa0JBQW1CLE9BQU8sU0FBUyxzQkFBc0IsT0FBTyxLQUFLLElBQUksU0FBUyxtQkFBbUIsU0FBUyxRQUFRO0VBQ2hTO0VBQ0E7RUFDQTtDQUNGLENBQUMsQ0FBQztDQUNGLE1BQU0sT0FBTyxtQkFBbUIsYUFBYTtFQUMzQztFQUNBO0VBQ0EsT0FBTyxNQUFNLFNBQVM7RUFDdEIsUUFBUSxNQUFNLFNBQVM7Q0FDekIsSUFBSSxNQUFNO0NBQ1YsTUFBTSxlQUFlLE9BQU8sU0FBUyxtQkFBbUIsT0FBTyxLQUFLLElBQUksU0FBUyxnQkFBZ0IsU0FBUyxRQUFRO0NBQ2xILE1BQU0sY0FBZSxPQUFPLFNBQVMsYUFBYSxPQUFPLEtBQUssSUFBSSxTQUFTLFVBQVUsWUFBWSxNQUFRLE9BQU8sU0FBUyxZQUFZLE9BQU8sS0FBSyxJQUFJLFNBQVMsU0FBUyxZQUFZLE1BQU87RUFDeEwsR0FBRztFQUNILEdBQUc7Q0FDTDtDQUNBLE1BQU0sb0JBQW9CLGlCQUFpQixTQUFTLHdEQUF3RCxNQUFNLFNBQVMsc0RBQXNEO0VBQy9LO0VBQ0E7RUFDQTtFQUNBO0NBQ0YsQ0FBQyxJQUFJLElBQUk7Q0FDVCxPQUFPO0VBQ0wsTUFBTSxtQkFBbUIsTUFBTSxrQkFBa0IsTUFBTSxjQUFjLE9BQU8sWUFBWTtFQUN4RixTQUFTLGtCQUFrQixTQUFTLG1CQUFtQixTQUFTLGNBQWMsVUFBVSxZQUFZO0VBQ3BHLE9BQU8sbUJBQW1CLE9BQU8sa0JBQWtCLE9BQU8sY0FBYyxRQUFRLFlBQVk7RUFDNUYsUUFBUSxrQkFBa0IsUUFBUSxtQkFBbUIsUUFBUSxjQUFjLFNBQVMsWUFBWTtDQUNsRztBQUNGO0FBR0EsSUFBTSxrQkFBa0I7Ozs7Ozs7O0FBU3hCLElBQU1BLG9CQUFrQixPQUFPLFdBQVcsVUFBVSxXQUFXO0NBQzdELE1BQU0sRUFDSixZQUFZLFVBQ1osV0FBVyxZQUNYLGFBQWEsQ0FBQyxHQUNkLGFBQ0U7Q0FDSixNQUFNLDZCQUE2QixTQUFTLGlCQUFpQixXQUFXO0VBQ3RFLEdBQUc7RUFDSDtDQUNGO0NBQ0EsTUFBTSxNQUFNLE9BQU8sU0FBUyxTQUFTLE9BQU8sS0FBSyxJQUFJLFNBQVMsTUFBTSxRQUFRO0NBQzVFLElBQUksUUFBUSxNQUFNLFNBQVMsZ0JBQWdCO0VBQ3pDO0VBQ0E7RUFDQTtDQUNGLENBQUM7Q0FDRCxJQUFJLEVBQ0YsR0FDQSxNQUNFLDJCQUEyQixPQUFPLFdBQVcsR0FBRztDQUNwRCxJQUFJLG9CQUFvQjtDQUN4QixJQUFJLGFBQWE7Q0FDakIsTUFBTSxpQkFBaUIsQ0FBQztDQUN4QixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksV0FBVyxRQUFRLEtBQUs7RUFDMUMsTUFBTSxvQkFBb0IsV0FBVztFQUNyQyxJQUFJLENBQUMsbUJBQ0g7RUFFRixNQUFNLEVBQ0osTUFDQSxPQUNFO0VBQ0osTUFBTSxFQUNKLEdBQUcsT0FDSCxHQUFHLE9BQ0gsTUFDQSxVQUNFLE1BQU0sR0FBRztHQUNYO0dBQ0E7R0FDQSxrQkFBa0I7R0FDbEIsV0FBVztHQUNYO0dBQ0E7R0FDQTtHQUNBLFVBQVU7R0FDVixVQUFVO0lBQ1I7SUFDQTtHQUNGO0VBQ0YsQ0FBQztFQUNELElBQUksU0FBUyxPQUFPLFFBQVE7RUFDNUIsSUFBSSxTQUFTLE9BQU8sUUFBUTtFQUM1QixlQUFlLFFBQVE7R0FDckIsR0FBRyxlQUFlO0dBQ2xCLEdBQUc7RUFDTDtFQUNBLElBQUksU0FBUyxhQUFhLGlCQUFpQjtHQUN6QztHQUNBLElBQUksT0FBTyxVQUFVLFVBQVU7SUFDN0IsSUFBSSxNQUFNLFdBQ1Isb0JBQW9CLE1BQU07SUFFNUIsSUFBSSxNQUFNLE9BQ1IsUUFBUSxNQUFNLFVBQVUsT0FBTyxNQUFNLFNBQVMsZ0JBQWdCO0tBQzVEO0tBQ0E7S0FDQTtJQUNGLENBQUMsSUFBSSxNQUFNO0lBRWIsQ0FBQyxDQUNDLEdBQ0EsS0FDRSwyQkFBMkIsT0FBTyxtQkFBbUIsR0FBRztHQUM5RDtHQUNBLElBQUk7RUFDTjtDQUNGO0NBQ0EsT0FBTztFQUNMO0VBQ0E7RUFDQSxXQUFXO0VBQ1g7RUFDQTtDQUNGO0FBQ0Y7Ozs7Ozs7QUFnTUEsSUFBTUMsU0FBTyxTQUFVLFNBQVM7Q0FDOUIsSUFBSSxZQUFZLEtBQUssR0FDbkIsVUFBVSxDQUFDO0NBRWIsT0FBTztFQUNMLE1BQU07RUFDTjtFQUNBLE1BQU0sR0FBRyxPQUFPO0dBQ2QsSUFBSSx1QkFBdUI7R0FDM0IsTUFBTSxFQUNKLFdBQ0EsZ0JBQ0EsT0FDQSxrQkFDQSxVQUNBLGFBQ0U7R0FDSixNQUFNLEVBQ0osVUFBVSxnQkFBZ0IsTUFDMUIsV0FBVyxpQkFBaUIsTUFDNUIsb0JBQW9CLDZCQUNwQixtQkFBbUIsV0FDbkIsNEJBQTRCLFFBQzVCLGdCQUFnQixNQUNoQixHQUFHLDBCQUNELFNBQVMsU0FBUyxLQUFLO0dBTTNCLEtBQUssd0JBQXdCLGVBQWUsVUFBVSxRQUFRLHNCQUFzQixpQkFDbEYsT0FBTyxDQUFDO0dBRVYsTUFBTSxPQUFPLFFBQVEsU0FBUztHQUM5QixNQUFNLGtCQUFrQixZQUFZLGdCQUFnQjtHQUNwRCxNQUFNLGtCQUFrQixRQUFRLGdCQUFnQixNQUFNO0dBQ3RELE1BQU0sTUFBTSxPQUFPLFNBQVMsU0FBUyxPQUFPLEtBQUssSUFBSSxTQUFTLE1BQU0sU0FBUyxRQUFRO0dBQ3JGLE1BQU0scUJBQXFCLGdDQUFnQyxtQkFBbUIsQ0FBQyxnQkFBZ0IsQ0FBQyxxQkFBcUIsZ0JBQWdCLENBQUMsSUFBSSxzQkFBc0IsZ0JBQWdCO0dBQ2hMLE1BQU0sK0JBQStCLDhCQUE4QjtHQUNuRSxJQUFJLENBQUMsK0JBQStCLDhCQUNsQyxtQkFBbUIsS0FBSyxHQUFHLDBCQUEwQixrQkFBa0IsZUFBZSwyQkFBMkIsR0FBRyxDQUFDO0dBRXZILE1BQU0sYUFBYSxDQUFDLGtCQUFrQixHQUFHLGtCQUFrQjtHQUMzRCxNQUFNLFdBQVcsTUFBTSxTQUFTLGVBQWUsT0FBTyxxQkFBcUI7R0FDM0UsTUFBTSxZQUFZLENBQUM7R0FDbkIsSUFBSSxrQkFBa0IsdUJBQXVCLGVBQWUsU0FBUyxPQUFPLEtBQUssSUFBSSxxQkFBcUIsY0FBYyxDQUFDO0dBQ3pILElBQUksZUFDRixVQUFVLEtBQUssU0FBUyxLQUFLO0dBRS9CLElBQUksZ0JBQWdCO0lBQ2xCLE1BQU0sUUFBUSxrQkFBa0IsV0FBVyxPQUFPLEdBQUc7SUFDckQsVUFBVSxLQUFLLFNBQVMsTUFBTSxLQUFLLFNBQVMsTUFBTSxHQUFHO0dBQ3ZEO0dBQ0EsZ0JBQWdCLENBQUMsR0FBRyxlQUFlO0lBQ2pDO0lBQ0E7R0FDRixDQUFDO0dBR0QsSUFBSSxDQUFDLFVBQVUsT0FBTSxTQUFRLFFBQVEsQ0FBQyxHQUFHO0lBQ3ZDLElBQUksdUJBQXVCO0lBQzNCLE1BQU0sZUFBZSx3QkFBd0IsZUFBZSxTQUFTLE9BQU8sS0FBSyxJQUFJLHNCQUFzQixVQUFVLEtBQUs7SUFDMUgsTUFBTSxnQkFBZ0IsV0FBVztJQUNqQyxJQUFJLGVBRUU7U0FBQSxFQUQ0QixtQkFBbUIsY0FBYyxvQkFBb0IsWUFBWSxhQUFhLElBQUksVUFJbEgsY0FBYyxPQUFNLE1BQUssWUFBWSxFQUFFLFNBQVMsTUFBTSxrQkFBa0IsRUFBRSxVQUFVLEtBQUssSUFBSSxJQUFJLEdBRS9GLE9BQU87TUFDTCxNQUFNO09BQ0osT0FBTztPQUNQLFdBQVc7TUFDYjtNQUNBLE9BQU8sRUFDTCxXQUFXLGNBQ2I7S0FDRjtJQUFBO0lBTUosSUFBSSxrQkFBa0Isd0JBQXdCLGNBQWMsUUFBTyxNQUFLLEVBQUUsVUFBVSxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLEVBQUUsVUFBVSxLQUFLLEVBQUUsVUFBVSxFQUFFLENBQUMsQ0FBQyxPQUFPLE9BQU8sS0FBSyxJQUFJLHNCQUFzQjtJQUcxTCxJQUFJLENBQUMsZ0JBQ0gsUUFBUSxrQkFBUjtLQUNFLEtBQUssV0FDSDtNQUNFLElBQUk7TUFDSixNQUFNLGFBQWEseUJBQXlCLGNBQWMsUUFBTyxNQUFLO09BQ3BFLElBQUksOEJBQThCO1FBQ2hDLE1BQU0sa0JBQWtCLFlBQVksRUFBRSxTQUFTO1FBQy9DLE9BQU8sb0JBQW9CLG1CQUczQixvQkFBb0I7T0FDdEI7T0FDQSxPQUFPO01BQ1QsQ0FBQyxDQUFDLENBQUMsS0FBSSxNQUFLLENBQUMsRUFBRSxXQUFXLEVBQUUsVUFBVSxRQUFPLGFBQVksV0FBVyxDQUFDLENBQUMsQ0FBQyxRQUFRLEtBQUssYUFBYSxNQUFNLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sR0FBRyxNQUFNLEVBQUUsS0FBSyxFQUFFLEVBQUUsQ0FBQyxDQUFDLE9BQU8sT0FBTyxLQUFLLElBQUksdUJBQXVCO01BQ2hNLElBQUksV0FDRixpQkFBaUI7TUFFbkI7S0FDRjtLQUNGLEtBQUssb0JBQ0gsaUJBQWlCO0lBRXJCO0lBRUYsSUFBSSxjQUFjLGdCQUNoQixPQUFPLEVBQ0wsT0FBTyxFQUNMLFdBQVcsZUFDYixFQUNGO0dBRUo7R0FDQSxPQUFPLENBQUM7RUFDVjtDQUNGO0FBQ0Y7QUFvTUEsSUFBTSw0QkFBMkIsSUFBSSxJQUFJLENBQUMsUUFBUSxLQUFLLENBQUM7QUFLeEQsZUFBZSxxQkFBcUIsT0FBTyxTQUFTO0NBQ2xELE1BQU0sRUFDSixXQUNBLFVBQ0EsYUFDRTtDQUNKLE1BQU0sTUFBTSxPQUFPLFNBQVMsU0FBUyxPQUFPLEtBQUssSUFBSSxTQUFTLE1BQU0sU0FBUyxRQUFRO0NBQ3JGLE1BQU0sT0FBTyxRQUFRLFNBQVM7Q0FDOUIsTUFBTSxZQUFZLGFBQWEsU0FBUztDQUN4QyxNQUFNLGFBQWEsWUFBWSxTQUFTLE1BQU07Q0FDOUMsTUFBTSxnQkFBZ0IsWUFBWSxJQUFJLElBQUksSUFBSSxLQUFLO0NBQ25ELE1BQU0saUJBQWlCLE9BQU8sYUFBYSxLQUFLO0NBQ2hELE1BQU0sV0FBVyxTQUFTLFNBQVMsS0FBSztDQUd4QyxJQUFJLEVBQ0YsVUFDQSxXQUNBLGtCQUNFLE9BQU8sYUFBYSxXQUFXO0VBQ2pDLFVBQVU7RUFDVixXQUFXO0VBQ1gsZUFBZTtDQUNqQixJQUFJO0VBQ0YsVUFBVSxTQUFTLFlBQVk7RUFDL0IsV0FBVyxTQUFTLGFBQWE7RUFDakMsZUFBZSxTQUFTO0NBQzFCO0NBQ0EsSUFBSSxhQUFhLE9BQU8sa0JBQWtCLFVBQ3hDLFlBQVksY0FBYyxRQUFRLGdCQUFnQixLQUFLO0NBRXpELE9BQU8sYUFBYTtFQUNsQixHQUFHLFlBQVk7RUFDZixHQUFHLFdBQVc7Q0FDaEIsSUFBSTtFQUNGLEdBQUcsV0FBVztFQUNkLEdBQUcsWUFBWTtDQUNqQjtBQUNGOzs7Ozs7OztBQVNBLElBQU1DLFdBQVMsU0FBVSxTQUFTO0NBQ2hDLElBQUksWUFBWSxLQUFLLEdBQ25CLFVBQVU7Q0FFWixPQUFPO0VBQ0wsTUFBTTtFQUNOO0VBQ0EsTUFBTSxHQUFHLE9BQU87R0FDZCxJQUFJLHVCQUF1QjtHQUMzQixNQUFNLEVBQ0osR0FDQSxHQUNBLFdBQ0EsbUJBQ0U7R0FDSixNQUFNLGFBQWEsTUFBTSxxQkFBcUIsT0FBTyxPQUFPO0dBSTVELElBQUksZ0JBQWdCLHdCQUF3QixlQUFlLFdBQVcsT0FBTyxLQUFLLElBQUksc0JBQXNCLGVBQWUsd0JBQXdCLGVBQWUsVUFBVSxRQUFRLHNCQUFzQixpQkFDeE0sT0FBTyxDQUFDO0dBRVYsT0FBTztJQUNMLEdBQUcsSUFBSSxXQUFXO0lBQ2xCLEdBQUcsSUFBSSxXQUFXO0lBQ2xCLE1BQU07S0FDSixHQUFHO0tBQ0g7SUFDRjtHQUNGO0VBQ0Y7Q0FDRjtBQUNGOzs7Ozs7QUFPQSxJQUFNQyxVQUFRLFNBQVUsU0FBUztDQUMvQixJQUFJLFlBQVksS0FBSyxHQUNuQixVQUFVLENBQUM7Q0FFYixPQUFPO0VBQ0wsTUFBTTtFQUNOO0VBQ0EsTUFBTSxHQUFHLE9BQU87R0FDZCxNQUFNLEVBQ0osR0FDQSxHQUNBLFdBQ0EsYUFDRTtHQUNKLE1BQU0sRUFDSixVQUFVLGdCQUFnQixNQUMxQixXQUFXLGlCQUFpQixPQUM1QixVQUFVLEVBQ1IsS0FBSSxTQUFRO0lBQ1YsSUFBSSxFQUNGLEdBQ0EsTUFDRTtJQUNKLE9BQU87S0FDTDtLQUNBO0lBQ0Y7R0FDRixFQUNGLEdBQ0EsR0FBRywwQkFDRCxTQUFTLFNBQVMsS0FBSztHQUMzQixNQUFNLFNBQVM7SUFDYjtJQUNBO0dBQ0Y7R0FDQSxNQUFNLFdBQVcsTUFBTSxTQUFTLGVBQWUsT0FBTyxxQkFBcUI7R0FDM0UsTUFBTSxZQUFZLFlBQVksU0FBUztHQUN2QyxNQUFNLFdBQVcsZ0JBQWdCLFNBQVM7R0FDMUMsSUFBSSxnQkFBZ0IsT0FBTztHQUMzQixJQUFJLGlCQUFpQixPQUFPO0dBQzVCLE1BQU0sY0FBYyxNQUFNLFVBQVUsTUFBTSxRQUFRLFNBQVMsU0FBUyxNQUFNLFFBQVEsU0FBUyxPQUFPLFFBQVEsU0FBUyxTQUFTLE1BQU0sV0FBVyxRQUFRO0dBQ3JKLElBQUksZUFDRixnQkFBZ0IsV0FBVyxVQUFVLGFBQWE7R0FFcEQsSUFBSSxnQkFDRixpQkFBaUIsV0FBVyxXQUFXLGNBQWM7R0FFdkQsTUFBTSxnQkFBZ0IsUUFBUSxHQUFHO0lBQy9CLEdBQUc7S0FDRixXQUFXO0tBQ1gsWUFBWTtHQUNmLENBQUM7R0FDRCxPQUFPO0lBQ0wsR0FBRztJQUNILE1BQU07S0FDSixHQUFHLGNBQWMsSUFBSTtLQUNyQixHQUFHLGNBQWMsSUFBSTtLQUNyQixTQUFTO09BQ04sV0FBVztPQUNYLFlBQVk7S0FDZjtJQUNGO0dBQ0Y7RUFDRjtDQUNGO0FBQ0Y7Ozs7QUFJQSxJQUFNQyxlQUFhLFNBQVUsU0FBUztDQUNwQyxJQUFJLFlBQVksS0FBSyxHQUNuQixVQUFVLENBQUM7Q0FFYixPQUFPO0VBQ0w7RUFDQSxHQUFHLE9BQU87R0FDUixJQUFJLHFCQUFxQjtHQUN6QixNQUFNLEVBQ0osR0FDQSxHQUNBLFdBQ0EsT0FDQSxtQkFDRTtHQUNKLE1BQU0sRUFDSixTQUFTLEdBQ1QsVUFBVSxnQkFBZ0IsTUFDMUIsV0FBVyxpQkFBaUIsU0FDMUIsU0FBUyxTQUFTLEtBQUs7R0FDM0IsTUFBTSxTQUFTO0lBQ2I7SUFDQTtHQUNGO0dBQ0EsTUFBTSxZQUFZLFlBQVksU0FBUztHQUN2QyxNQUFNLFdBQVcsZ0JBQWdCLFNBQVM7R0FDMUMsSUFBSSxnQkFBZ0IsT0FBTztHQUMzQixJQUFJLGlCQUFpQixPQUFPO0dBQzVCLE1BQU0sWUFBWSxTQUFTLFFBQVEsS0FBSztHQUN4QyxNQUFNLGlCQUFpQixPQUFPLGNBQWMsV0FBVztJQUNyRCxVQUFVO0lBQ1YsV0FBVztHQUNiLElBQUk7SUFDRixXQUFXLHNCQUFzQixVQUFVLGFBQWEsT0FBTyxzQkFBc0I7SUFDckYsWUFBWSx1QkFBdUIsVUFBVSxjQUFjLE9BQU8sdUJBQXVCO0dBQzNGO0dBQ0EsSUFBSSxlQUFlO0lBQ2pCLE1BQU0sTUFBTSxhQUFhLE1BQU0sV0FBVztJQUMxQyxNQUFNLFdBQVcsTUFBTSxVQUFVLFlBQVksTUFBTSxTQUFTLE9BQU8sZUFBZTtJQUNsRixNQUFNLFdBQVcsTUFBTSxVQUFVLFlBQVksTUFBTSxVQUFVLE9BQU8sZUFBZTtJQUNuRixJQUFJLGdCQUFnQixVQUNsQixnQkFBZ0I7U0FDWCxJQUFJLGdCQUFnQixVQUN6QixnQkFBZ0I7R0FFcEI7R0FDQSxJQUFJLGdCQUFnQjtJQUNsQixJQUFJLHVCQUF1QjtJQUMzQixNQUFNLE1BQU0sYUFBYSxNQUFNLFVBQVU7SUFDekMsTUFBTSxlQUFlLFlBQVksSUFBSSxRQUFRLFNBQVMsQ0FBQztJQUN2RCxNQUFNLFdBQVcsTUFBTSxVQUFVLGFBQWEsTUFBTSxTQUFTLFFBQVEsaUJBQWlCLHdCQUF3QixlQUFlLFdBQVcsT0FBTyxLQUFLLElBQUksc0JBQXNCLGVBQWUsSUFBSSxNQUFNLGVBQWUsSUFBSSxlQUFlO0lBQ3pPLE1BQU0sV0FBVyxNQUFNLFVBQVUsYUFBYSxNQUFNLFVBQVUsUUFBUSxlQUFlLE1BQU0seUJBQXlCLGVBQWUsV0FBVyxPQUFPLEtBQUssSUFBSSx1QkFBdUIsZUFBZSxNQUFNLGVBQWUsZUFBZSxZQUFZO0lBQ3BQLElBQUksaUJBQWlCLFVBQ25CLGlCQUFpQjtTQUNaLElBQUksaUJBQWlCLFVBQzFCLGlCQUFpQjtHQUVyQjtHQUNBLE9BQU87S0FDSixXQUFXO0tBQ1gsWUFBWTtHQUNmO0VBQ0Y7Q0FDRjtBQUNGOzs7Ozs7O0FBY0EsSUFBTUMsU0FBTyxTQUFVLFNBQVM7Q0FDOUIsSUFBSSxZQUFZLEtBQUssR0FDbkIsVUFBVSxDQUFDO0NBRWIsT0FBTztFQUNMLE1BQU07RUFDTjtFQUNBLE1BQU0sR0FBRyxPQUFPO0dBQ2QsTUFBTSxFQUNKLFdBQ0EsT0FDQSxVQUNBLGFBQ0U7R0FDSixNQUFNLEVBQ0osY0FBYyxDQUFDLEdBQ2YsR0FBRywwQkFDRCxTQUFTLFNBQVMsS0FBSztHQUMzQixNQUFNLFdBQVcsTUFBTSxTQUFTLGVBQWUsT0FBTyxxQkFBcUI7R0FDM0UsTUFBTSxPQUFPLFFBQVEsU0FBUztHQUM5QixNQUFNLFlBQVksYUFBYSxTQUFTO0dBQ3hDLE1BQU0sVUFBVSxZQUFZLFNBQVMsTUFBTTtHQUMzQyxNQUFNLEVBQ0osT0FDQSxXQUNFLE1BQU07R0FDVixJQUFJO0dBQ0osSUFBSTtHQUNKLElBQUksU0FBUyxTQUFTLFNBQVMsVUFBVTtJQUN2QyxhQUFhO0lBQ2IsWUFBWSxlQUFnQixPQUFPLFNBQVMsU0FBUyxPQUFPLEtBQUssSUFBSSxTQUFTLE1BQU0sU0FBUyxRQUFRLEtBQU0sVUFBVSxTQUFTLFNBQVM7R0FDekksT0FBTztJQUNMLFlBQVk7SUFDWixhQUFhLGNBQWMsUUFBUSxRQUFRO0dBQzdDO0dBQ0EsTUFBTSx3QkFBd0IsU0FBUyxTQUFTLE1BQU0sU0FBUztHQUMvRCxNQUFNLHVCQUF1QixRQUFRLFNBQVMsT0FBTyxTQUFTO0dBQzlELE1BQU0sMEJBQTBCLElBQUksU0FBUyxTQUFTLGFBQWEscUJBQXFCO0dBQ3hGLE1BQU0seUJBQXlCLElBQUksUUFBUSxTQUFTLFlBQVksb0JBQW9CO0dBQ3BGLE1BQU0sWUFBWSxNQUFNLGVBQWU7R0FDdkMsTUFBTSxVQUFVLENBQUM7R0FDakIsSUFBSSxrQkFBa0I7R0FDdEIsSUFBSSxpQkFBaUI7R0FDckIsSUFBSSxhQUFhLFFBQVEsVUFBVSxRQUFRLEdBQ3pDLGlCQUFpQjtHQUVuQixJQUFJLGFBQWEsUUFBUSxVQUFVLFFBQVEsR0FDekMsa0JBQWtCO0dBRXBCLElBQUksV0FBVyxDQUFDLFdBQVc7SUFDekIsSUFBSSxTQUNGLGlCQUFpQixRQUFRLElBQUksSUFBSSxTQUFTLE1BQU0sU0FBUyxLQUFLO1NBRTlELGtCQUFrQixTQUFTLElBQUksSUFBSSxTQUFTLEtBQUssU0FBUyxNQUFNO0dBRXBFO0dBQ0EsTUFBTSxNQUFNO0lBQ1YsR0FBRztJQUNIO0lBQ0E7R0FDRixDQUFDO0dBQ0QsTUFBTSxpQkFBaUIsTUFBTSxTQUFTLGNBQWMsU0FBUyxRQUFRO0dBQ3JFLElBQUksVUFBVSxlQUFlLFNBQVMsV0FBVyxlQUFlLFFBQzlELE9BQU8sRUFDTCxPQUFPLEVBQ0wsT0FBTyxLQUNULEVBQ0Y7R0FFRixPQUFPLENBQUM7RUFDVjtDQUNGO0FBQ0Y7O0FDdGdDQSxTQUFTLGlCQUFpQixTQUFTO0NBQ2pDLE1BQU0sTUFBTSxtQkFBbUIsT0FBTztDQUd0QyxJQUFJLFFBQVEsV0FBVyxJQUFJLEtBQUssS0FBSztDQUNyQyxJQUFJLFNBQVMsV0FBVyxJQUFJLE1BQU0sS0FBSztDQUN2QyxNQUFNLFlBQVksY0FBYyxPQUFPO0NBQ3ZDLE1BQU0sY0FBYyxZQUFZLFFBQVEsY0FBYztDQUN0RCxNQUFNLGVBQWUsWUFBWSxRQUFRLGVBQWU7Q0FDeEQsTUFBTSxpQkFBaUIsTUFBTSxLQUFLLE1BQU0sZUFBZSxNQUFNLE1BQU0sTUFBTTtDQUN6RSxJQUFJLGdCQUFnQjtFQUNsQixRQUFRO0VBQ1IsU0FBUztDQUNYO0NBQ0EsT0FBTztFQUNMO0VBQ0E7RUFDQSxHQUFHO0NBQ0w7QUFDRjtBQUVBLFNBQVMsY0FBYyxTQUFTO0NBQzlCLE9BQU8sQ0FBQyxVQUFVLE9BQU8sSUFBSSxRQUFRLGlCQUFpQjtBQUN4RDtBQUVBLFNBQVMsU0FBUyxTQUFTO0NBQ3pCLE1BQU0sYUFBYSxjQUFjLE9BQU87Q0FDeEMsSUFBSSxDQUFDLGNBQWMsVUFBVSxHQUMzQixPQUFPLGFBQWEsQ0FBQztDQUV2QixNQUFNLE9BQU8sV0FBVyxzQkFBc0I7Q0FDOUMsTUFBTSxFQUNKLE9BQ0EsUUFDQSxNQUNFLGlCQUFpQixVQUFVO0NBQy9CLElBQUksS0FBSyxJQUFJLE1BQU0sS0FBSyxLQUFLLElBQUksS0FBSyxTQUFTO0NBQy9DLElBQUksS0FBSyxJQUFJLE1BQU0sS0FBSyxNQUFNLElBQUksS0FBSyxVQUFVO0NBSWpELElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxTQUFTLENBQUMsR0FDMUIsSUFBSTtDQUVOLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxTQUFTLENBQUMsR0FDMUIsSUFBSTtDQUVOLE9BQU87RUFDTDtFQUNBO0NBQ0Y7QUFDRjtBQUVBLElBQU0sWUFBeUIsMkJBQWEsQ0FBQztBQUM3QyxTQUFTLGlCQUFpQixTQUFTO0NBQ2pDLE1BQU0sTUFBTSxVQUFVLE9BQU87Q0FDN0IsSUFBSSxDQUFDLFNBQVMsS0FBSyxDQUFDLElBQUksZ0JBQ3RCLE9BQU87Q0FFVCxPQUFPO0VBQ0wsR0FBRyxJQUFJLGVBQWU7RUFDdEIsR0FBRyxJQUFJLGVBQWU7Q0FDeEI7QUFDRjtBQUNBLFNBQVMsdUJBQXVCLFNBQVMsU0FBUyxzQkFBc0I7Q0FDdEUsSUFBSSxZQUFZLEtBQUssR0FDbkIsVUFBVTtDQUVaLE9BQU8sQ0FBQyxDQUFDLHdCQUF3QixXQUFXLHlCQUF5QixVQUFVLE9BQU87QUFDeEY7QUFFQSxTQUFTLHNCQUFzQixTQUFTLGNBQWMsaUJBQWlCLGNBQWM7Q0FDbkYsSUFBSSxpQkFBaUIsS0FBSyxHQUN4QixlQUFlO0NBRWpCLElBQUksb0JBQW9CLEtBQUssR0FDM0Isa0JBQWtCO0NBRXBCLE1BQU0sYUFBYSxRQUFRLHNCQUFzQjtDQUNqRCxNQUFNLGFBQWEsY0FBYyxPQUFPO0NBQ3hDLElBQUksUUFBUSxhQUFhLENBQUM7Q0FDMUIsSUFBSSxjQUFjO0VBQ2hCLElBQUksY0FDRTtPQUFBLFVBQVUsWUFBWSxHQUN4QixRQUFRLFNBQVMsWUFBWTtFQUFBLE9BRy9CLFFBQVEsU0FBUyxPQUFPO0NBRTVCO0NBQ0EsTUFBTSxnQkFBZ0IsdUJBQXVCLFlBQVksaUJBQWlCLFlBQVksSUFBSSxpQkFBaUIsVUFBVSxJQUFJLGFBQWEsQ0FBQztDQUN2SSxJQUFJLEtBQUssV0FBVyxPQUFPLGNBQWMsS0FBSyxNQUFNO0NBQ3BELElBQUksS0FBSyxXQUFXLE1BQU0sY0FBYyxLQUFLLE1BQU07Q0FDbkQsSUFBSSxRQUFRLFdBQVcsUUFBUSxNQUFNO0NBQ3JDLElBQUksU0FBUyxXQUFXLFNBQVMsTUFBTTtDQUN2QyxJQUFJLGNBQWMsY0FBYztFQUM5QixNQUFNLE1BQU0sVUFBVSxVQUFVO0VBQ2hDLE1BQU0sWUFBWSxVQUFVLFlBQVksSUFBSSxVQUFVLFlBQVksSUFBSTtFQUN0RSxJQUFJLGFBQWE7RUFDakIsSUFBSSxnQkFBZ0IsZ0JBQWdCLFVBQVU7RUFDOUMsT0FBTyxpQkFBaUIsY0FBYyxZQUFZO0dBQ2hELE1BQU0sY0FBYyxTQUFTLGFBQWE7R0FDMUMsTUFBTSxhQUFhLGNBQWMsc0JBQXNCO0dBQ3ZELE1BQU0sTUFBTSxtQkFBbUIsYUFBYTtHQUM1QyxNQUFNLE9BQU8sV0FBVyxRQUFRLGNBQWMsYUFBYSxXQUFXLElBQUksV0FBVyxLQUFLLFlBQVk7R0FDdEcsTUFBTSxNQUFNLFdBQVcsT0FBTyxjQUFjLFlBQVksV0FBVyxJQUFJLFVBQVUsS0FBSyxZQUFZO0dBQ2xHLEtBQUssWUFBWTtHQUNqQixLQUFLLFlBQVk7R0FDakIsU0FBUyxZQUFZO0dBQ3JCLFVBQVUsWUFBWTtHQUN0QixLQUFLO0dBQ0wsS0FBSztHQUNMLGFBQWEsVUFBVSxhQUFhO0dBQ3BDLGdCQUFnQixnQkFBZ0IsVUFBVTtFQUM1QztDQUNGO0NBQ0EsT0FBTyxpQkFBaUI7RUFDdEI7RUFDQTtFQUNBO0VBQ0E7Q0FDRixDQUFDO0FBQ0g7QUFJQSxTQUFTLG9CQUFvQixTQUFTLE1BQU07Q0FDMUMsTUFBTSxhQUFhLGNBQWMsT0FBTyxDQUFDLENBQUM7Q0FDMUMsSUFBSSxDQUFDLE1BQ0gsT0FBTyxzQkFBc0IsbUJBQW1CLE9BQU8sQ0FBQyxDQUFDLENBQUMsT0FBTztDQUVuRSxPQUFPLEtBQUssT0FBTztBQUNyQjtBQUVBLFNBQVMsY0FBYyxpQkFBaUIsUUFBUTtDQUM5QyxNQUFNLFdBQVcsZ0JBQWdCLHNCQUFzQjtDQUd2RCxPQUFPO0VBQ0wsR0FIUSxTQUFTLE9BQU8sT0FBTyxhQUFhLG9CQUFvQixpQkFBaUIsUUFBUTtFQUl6RixHQUhRLFNBQVMsTUFBTSxPQUFPO0NBSWhDO0FBQ0Y7QUFFQSxTQUFTLHNEQUFzRCxNQUFNO0NBQ25FLElBQUksRUFDRixVQUNBLE1BQ0EsY0FDQSxhQUNFO0NBQ0osTUFBTSxVQUFVLGFBQWE7Q0FDN0IsTUFBTSxrQkFBa0IsbUJBQW1CLFlBQVk7Q0FDdkQsTUFBTSxXQUFXLFdBQVcsV0FBVyxTQUFTLFFBQVEsSUFBSTtDQUM1RCxJQUFJLGlCQUFpQixtQkFBbUIsWUFBWSxTQUNsRCxPQUFPO0NBRVQsSUFBSSxTQUFTO0VBQ1gsWUFBWTtFQUNaLFdBQVc7Q0FDYjtDQUNBLElBQUksUUFBUSxhQUFhLENBQUM7Q0FDMUIsTUFBTSxVQUFVLGFBQWEsQ0FBQztDQUM5QixNQUFNLDBCQUEwQixjQUFjLFlBQVk7Q0FDMUQsSUFBSSwyQkFBMkIsQ0FBQyxTQUFTO0VBQ3ZDLElBQUksWUFBWSxZQUFZLE1BQU0sVUFBVSxrQkFBa0IsZUFBZSxHQUMzRSxTQUFTLGNBQWMsWUFBWTtFQUVyQyxJQUFJLHlCQUF5QjtHQUMzQixNQUFNLGFBQWEsc0JBQXNCLFlBQVk7R0FDckQsUUFBUSxTQUFTLFlBQVk7R0FDN0IsUUFBUSxJQUFJLFdBQVcsSUFBSSxhQUFhO0dBQ3hDLFFBQVEsSUFBSSxXQUFXLElBQUksYUFBYTtFQUMxQztDQUNGO0NBQ0EsTUFBTSxhQUFhLG1CQUFtQixDQUFDLDJCQUEyQixDQUFDLFVBQVUsY0FBYyxpQkFBaUIsTUFBTSxJQUFJLGFBQWEsQ0FBQztDQUNwSSxPQUFPO0VBQ0wsT0FBTyxLQUFLLFFBQVEsTUFBTTtFQUMxQixRQUFRLEtBQUssU0FBUyxNQUFNO0VBQzVCLEdBQUcsS0FBSyxJQUFJLE1BQU0sSUFBSSxPQUFPLGFBQWEsTUFBTSxJQUFJLFFBQVEsSUFBSSxXQUFXO0VBQzNFLEdBQUcsS0FBSyxJQUFJLE1BQU0sSUFBSSxPQUFPLFlBQVksTUFBTSxJQUFJLFFBQVEsSUFBSSxXQUFXO0NBQzVFO0FBQ0Y7QUFFQSxTQUFTLGVBQWUsU0FBUztDQUMvQixPQUFPLFFBQVEsaUJBQWlCLE1BQU0sS0FBSyxRQUFRLGVBQWUsQ0FBQyxJQUFJLENBQUM7QUFDMUU7QUFJQSxTQUFTLGdCQUFnQixNQUFNO0NBQzdCLE1BQU0sU0FBUyxjQUFjLElBQUk7Q0FDakMsTUFBTSxPQUFPLEtBQUssY0FBYztDQUNoQyxNQUFNLFFBQVEsSUFBSSxLQUFLLGFBQWEsS0FBSyxhQUFhLEtBQUssYUFBYSxLQUFLLFdBQVc7Q0FDeEYsTUFBTSxTQUFTLElBQUksS0FBSyxjQUFjLEtBQUssY0FBYyxLQUFLLGNBQWMsS0FBSyxZQUFZO0NBQzdGLElBQUksSUFBSSxDQUFDLE9BQU8sYUFBYSxvQkFBb0IsSUFBSTtDQUNyRCxNQUFNLElBQUksQ0FBQyxPQUFPO0NBQ2xCLElBQUksbUJBQW1CLElBQUksQ0FBQyxDQUFDLGNBQWMsT0FDekMsS0FBSyxJQUFJLEtBQUssYUFBYSxLQUFLLFdBQVcsSUFBSTtDQUVqRCxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBS0EsSUFBTSxnQkFBZ0I7QUFDdEIsU0FBUyxnQkFBZ0IsU0FBUyxVQUFVLGNBQWM7Q0FDeEQsSUFBSSxpQkFBaUIsS0FBSyxHQUN4QixlQUFlO0NBRWpCLE1BQU0sbUJBQW1CLGlCQUFpQjtDQUMxQyxNQUFNLE1BQU0sVUFBVSxPQUFPO0NBQzdCLE1BQU0sT0FBTyxtQkFBbUIsT0FBTztDQUN2QyxNQUFNLGlCQUFpQixJQUFJO0NBQzNCLElBQUksUUFBUSxLQUFLO0NBQ2pCLElBQUksU0FBUyxLQUFLO0NBQ2xCLElBQUksSUFBSTtDQUNSLElBQUksSUFBSTtDQUNSLElBQUksZ0JBQWdCO0VBSWxCLE1BQU0sNkJBQTZCLENBQUMsU0FBUyxLQUFLLGFBQWE7RUFDL0QsSUFBSSxrQkFDRTtPQUFBLENBQUMsNEJBQTRCO0lBQy9CLElBQUksQ0FBQyxlQUFlO0lBQ3BCLElBQUksQ0FBQyxlQUFlO0dBQ3RCO1NBQ0s7R0FDTCxRQUFRLGVBQWU7R0FDdkIsU0FBUyxlQUFlO0dBQ3hCLElBQUksNEJBQTRCO0lBQzlCLElBQUksZUFBZTtJQUNuQixJQUFJLGVBQWU7R0FDckI7RUFDRjtDQUNGO0NBU0EsSUFSeUIsb0JBQW9CLElBUTFCLEtBQUssR0FBRztFQUN6QixNQUFNLE1BQU0sS0FBSztFQUNqQixNQUFNLE9BQU8sSUFBSTtFQUNqQixNQUFNLGFBQWEsaUJBQWlCLElBQUk7RUFDeEMsTUFBTSxtQkFBbUIsSUFBSSxlQUFlLGVBQWUsV0FBVyxXQUFXLFVBQVUsSUFBSSxXQUFXLFdBQVcsV0FBVyxLQUFLLElBQUk7RUFDekksTUFBTSxnQkFBZ0IsS0FBSyxJQUFJLEtBQUssY0FBYyxLQUFLLGNBQWMsZ0JBQWdCO0VBQ3JGLE1BQU0sU0FBUyxpQkFBaUIsSUFBSSxDQUFDLENBQUMsb0JBQW9CLHNCQUFzQixnQkFBZ0IsSUFBSTtFQUNwRyxJQUFJLFVBQVUsZUFDWixTQUFTO0NBRWI7Q0FDQSxPQUFPO0VBQ0w7RUFDQTtFQUNBO0VBQ0E7Q0FDRjtBQUNGO0FBR0EsU0FBUywyQkFBMkIsU0FBUyxVQUFVO0NBQ3JELE1BQU0sYUFBYSxzQkFBc0IsU0FBUyxNQUFNLGFBQWEsT0FBTztDQUM1RSxNQUFNLE1BQU0sV0FBVyxNQUFNLFFBQVE7Q0FDckMsTUFBTSxPQUFPLFdBQVcsT0FBTyxRQUFRO0NBQ3ZDLE1BQU0sUUFBUSxTQUFTLE9BQU87Q0FLOUIsT0FBTztFQUNMLE9BTFksUUFBUSxjQUFjLE1BQU07RUFNeEMsUUFMYSxRQUFRLGVBQWUsTUFBTTtFQU0xQyxHQUxRLE9BQU8sTUFBTTtFQU1yQixHQUxRLE1BQU0sTUFBTTtDQU10QjtBQUNGO0FBQ0EsU0FBUyxrQ0FBa0MsU0FBUyxrQkFBa0IsVUFBVTtDQUM5RSxJQUFJO0NBQ0osSUFBSSxxQkFBcUIsY0FBYyxxQkFBcUIsa0JBQzFELE9BQU8sZ0JBQWdCLFNBQVMsVUFBVSxnQkFBZ0I7TUFDckQsSUFBSSxxQkFBcUIsWUFDOUIsT0FBTyxnQkFBZ0IsbUJBQW1CLE9BQU8sQ0FBQztNQUM3QyxJQUFJLFVBQVUsZ0JBQWdCLEdBQ25DLE9BQU8sMkJBQTJCLGtCQUFrQixRQUFRO01BQ3ZEO0VBQ0wsTUFBTSxnQkFBZ0IsaUJBQWlCLE9BQU87RUFDOUMsT0FBTztHQUNMLEdBQUcsaUJBQWlCLElBQUksY0FBYztHQUN0QyxHQUFHLGlCQUFpQixJQUFJLGNBQWM7R0FDdEMsT0FBTyxpQkFBaUI7R0FDeEIsUUFBUSxpQkFBaUI7RUFDM0I7Q0FDRjtDQUNBLE9BQU8saUJBQWlCLElBQUk7QUFDOUI7QUFLQSxTQUFTLDRCQUE0QixTQUFTLE9BQU87Q0FDbkQsTUFBTSxlQUFlLE1BQU0sSUFBSSxPQUFPO0NBQ3RDLElBQUksY0FDRixPQUFPO0NBRVQsSUFBSSxTQUFTLHFCQUFxQixTQUFTLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxRQUFPLE9BQU0sVUFBVSxFQUFFLEtBQUssWUFBWSxFQUFFLE1BQU0sTUFBTTtDQUM5RyxJQUFJLHdCQUF3QjtDQUM1QixNQUFNLGlCQUFpQixtQkFBbUIsT0FBTyxDQUFDLENBQUMsYUFBYTtDQUNoRSxJQUFJLGNBQWMsaUJBQWlCLGNBQWMsT0FBTyxJQUFJO0NBRzVELE9BQU8sVUFBVSxXQUFXLEtBQUssQ0FBQyxzQkFBc0IsV0FBVyxHQUFHO0VBQ3BFLE1BQU0sZ0JBQWdCLG1CQUFtQixXQUFXO0VBQ3BELE1BQU0sMEJBQTBCLGtCQUFrQixXQUFXO0VBRzdELE1BQU0sZUFBZSx3QkFBd0Isc0JBQXNCLFdBQVcsaUJBQWlCLFVBQVU7RUFNekcsSUFEOEIsQ0FBQyw0QkFBNEIsaUJBQWlCLFdBQVcsaUJBQWlCLGNBQWMsY0FBYyxhQUFhLFdBRy9JLFNBQVMsT0FBTyxRQUFPLGFBQVksYUFBYSxXQUFXO09BRzNELHdCQUF3QjtFQUUxQixjQUFjLGNBQWMsV0FBVztDQUN6QztDQUNBLE1BQU0sSUFBSSxTQUFTLE1BQU07Q0FDekIsT0FBTztBQUNUO0FBSUEsU0FBUyxnQkFBZ0IsTUFBTTtDQUM3QixJQUFJLEVBQ0YsU0FDQSxVQUNBLGNBQ0EsYUFDRTtDQUVKLE1BQU0sb0JBQW9CLENBQUMsR0FETSxhQUFhLHNCQUFzQixXQUFXLE9BQU8sSUFBSSxDQUFDLElBQUksNEJBQTRCLFNBQVMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxRQUFRLEdBQ3pHLFlBQVk7Q0FDcEUsTUFBTSxZQUFZLGtDQUFrQyxTQUFTLGtCQUFrQixJQUFJLFFBQVE7Q0FDM0YsSUFBSSxNQUFNLFVBQVU7Q0FDcEIsSUFBSSxRQUFRLFVBQVU7Q0FDdEIsSUFBSSxTQUFTLFVBQVU7Q0FDdkIsSUFBSSxPQUFPLFVBQVU7Q0FDckIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGtCQUFrQixRQUFRLEtBQUs7RUFDakQsTUFBTSxPQUFPLGtDQUFrQyxTQUFTLGtCQUFrQixJQUFJLFFBQVE7RUFDdEYsTUFBTSxJQUFJLEtBQUssS0FBSyxHQUFHO0VBQ3ZCLFFBQVEsSUFBSSxLQUFLLE9BQU8sS0FBSztFQUM3QixTQUFTLElBQUksS0FBSyxRQUFRLE1BQU07RUFDaEMsT0FBTyxJQUFJLEtBQUssTUFBTSxJQUFJO0NBQzVCO0NBQ0EsT0FBTztFQUNMLE9BQU8sUUFBUTtFQUNmLFFBQVEsU0FBUztFQUNqQixHQUFHO0VBQ0gsR0FBRztDQUNMO0FBQ0Y7QUFFQSxTQUFTLGNBQWMsU0FBUztDQUM5QixNQUFNLEVBQ0osT0FDQSxXQUNFLGlCQUFpQixPQUFPO0NBQzVCLE9BQU87RUFDTDtFQUNBO0NBQ0Y7QUFDRjtBQUVBLFNBQVMsOEJBQThCLFNBQVMsY0FBYyxVQUFVO0NBQ3RFLE1BQU0sMEJBQTBCLGNBQWMsWUFBWTtDQUMxRCxNQUFNLGtCQUFrQixtQkFBbUIsWUFBWTtDQUN2RCxNQUFNLFVBQVUsYUFBYTtDQUM3QixNQUFNLE9BQU8sc0JBQXNCLFNBQVMsTUFBTSxTQUFTLFlBQVk7Q0FDdkUsSUFBSSxTQUFTO0VBQ1gsWUFBWTtFQUNaLFdBQVc7Q0FDYjtDQUNBLE1BQU0sVUFBVSxhQUFhLENBQUM7Q0FDOUIsSUFBSSwyQkFBMkIsQ0FBQyxTQUFTO0VBQ3ZDLElBQUksWUFBWSxZQUFZLE1BQU0sVUFBVSxrQkFBa0IsZUFBZSxHQUMzRSxTQUFTLGNBQWMsWUFBWTtFQUVyQyxJQUFJLHlCQUF5QjtHQUMzQixNQUFNLGFBQWEsc0JBQXNCLGNBQWMsTUFBTSxTQUFTLFlBQVk7R0FDbEYsUUFBUSxJQUFJLFdBQVcsSUFBSSxhQUFhO0dBQ3hDLFFBQVEsSUFBSSxXQUFXLElBQUksYUFBYTtFQUMxQztDQUNGO0NBSUEsSUFBSSxDQUFDLDJCQUEyQixpQkFDOUIsUUFBUSxJQUFJLG9CQUFvQixlQUFlO0NBRWpELE1BQU0sYUFBYSxtQkFBbUIsQ0FBQywyQkFBMkIsQ0FBQyxVQUFVLGNBQWMsaUJBQWlCLE1BQU0sSUFBSSxhQUFhLENBQUM7Q0FHcEksT0FBTztFQUNMLEdBSFEsS0FBSyxPQUFPLE9BQU8sYUFBYSxRQUFRLElBQUksV0FBVztFQUkvRCxHQUhRLEtBQUssTUFBTSxPQUFPLFlBQVksUUFBUSxJQUFJLFdBQVc7RUFJN0QsT0FBTyxLQUFLO0VBQ1osUUFBUSxLQUFLO0NBQ2Y7QUFDRjtBQUVBLFNBQVMsbUJBQW1CLFNBQVM7Q0FDbkMsT0FBTyxtQkFBbUIsT0FBTyxDQUFDLENBQUMsYUFBYTtBQUNsRDtBQUVBLFNBQVMsb0JBQW9CLFNBQVMsVUFBVTtDQUM5QyxJQUFJLENBQUMsY0FBYyxPQUFPLEtBQUssbUJBQW1CLE9BQU8sQ0FBQyxDQUFDLGFBQWEsU0FDdEUsT0FBTztDQUVULElBQUksVUFDRixPQUFPLFNBQVMsT0FBTztDQUV6QixJQUFJLGtCQUFrQixRQUFRO0NBTTlCLElBQUksbUJBQW1CLE9BQU8sTUFBTSxpQkFDbEMsa0JBQWtCLGdCQUFnQixjQUFjO0NBRWxELE9BQU87QUFDVDtBQUlBLFNBQVMsZ0JBQWdCLFNBQVMsVUFBVTtDQUMxQyxNQUFNLE1BQU0sVUFBVSxPQUFPO0NBQzdCLElBQUksV0FBVyxPQUFPLEdBQ3BCLE9BQU87Q0FFVCxJQUFJLENBQUMsY0FBYyxPQUFPLEdBQUc7RUFDM0IsSUFBSSxrQkFBa0IsY0FBYyxPQUFPO0VBQzNDLE9BQU8sbUJBQW1CLENBQUMsc0JBQXNCLGVBQWUsR0FBRztHQUNqRSxJQUFJLFVBQVUsZUFBZSxLQUFLLENBQUMsbUJBQW1CLGVBQWUsR0FDbkUsT0FBTztHQUVULGtCQUFrQixjQUFjLGVBQWU7RUFDakQ7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLGVBQWUsb0JBQW9CLFNBQVMsUUFBUTtDQUN4RCxPQUFPLGdCQUFnQixlQUFlLFlBQVksS0FBSyxtQkFBbUIsWUFBWSxHQUNwRixlQUFlLG9CQUFvQixjQUFjLFFBQVE7Q0FFM0QsSUFBSSxnQkFBZ0Isc0JBQXNCLFlBQVksS0FBSyxtQkFBbUIsWUFBWSxLQUFLLENBQUMsa0JBQWtCLFlBQVksR0FDNUgsT0FBTztDQUVULE9BQU8sZ0JBQWdCLG1CQUFtQixPQUFPLEtBQUs7QUFDeEQ7QUFFQSxJQUFNLGtCQUFrQixlQUFnQixNQUFNO0NBQzVDLE1BQU0sb0JBQW9CLEtBQUssbUJBQW1CO0NBQ2xELE1BQU0sa0JBQWtCLEtBQUs7Q0FDN0IsTUFBTSxxQkFBcUIsTUFBTSxnQkFBZ0IsS0FBSyxRQUFRO0NBQzlELE9BQU87RUFDTCxXQUFXLDhCQUE4QixLQUFLLFdBQVcsTUFBTSxrQkFBa0IsS0FBSyxRQUFRLEdBQUcsS0FBSyxRQUFRO0VBQzlHLFVBQVU7R0FDUixHQUFHO0dBQ0gsR0FBRztHQUNILE9BQU8sbUJBQW1CO0dBQzFCLFFBQVEsbUJBQW1CO0VBQzdCO0NBQ0Y7QUFDRjtBQUVBLFNBQVMsTUFBTSxTQUFTO0NBQ3RCLE9BQU8sbUJBQW1CLE9BQU8sQ0FBQyxDQUFDLGNBQWM7QUFDbkQ7QUFFQSxJQUFNLFdBQVc7Q0FDZjtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGO0FBRUEsU0FBUyxjQUFjLEdBQUcsR0FBRztDQUMzQixPQUFPLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFO0FBQzdFO0FBR0EsU0FBUyxZQUFZLFNBQVMsUUFBUSxnQkFBZ0I7Q0FDcEQsSUFBSSxLQUFLO0NBQ1QsSUFBSTtDQUNKLE1BQU0sT0FBTyxtQkFBbUIsT0FBTztDQUN2QyxTQUFTLFVBQVU7RUFDakIsSUFBSTtFQUNKLGFBQWEsU0FBUztFQUN0QixDQUFDLE1BQU0sT0FBTyxRQUFRLElBQUksV0FBVztFQUNyQyxLQUFLO0NBQ1A7Q0FDQSxTQUFTLFFBQVEsTUFBTSxXQUFXO0VBQ2hDLElBQUksU0FBUyxLQUFLLEdBQ2hCLE9BQU87RUFFVCxJQUFJLGNBQWMsS0FBSyxHQUNyQixZQUFZO0VBRWQsUUFBUTtFQUNSLE1BQU0sMkJBQTJCLFFBQVEsc0JBQXNCO0VBQy9ELE1BQU0sRUFDSixNQUNBLEtBQ0EsT0FDQSxXQUNFO0VBQ0osSUFBSSxDQUFDLE1BQ0gsT0FBTztFQUVULElBQUksQ0FBQyxTQUFTLENBQUMsUUFDYjtFQUVGLE1BQU0sV0FBVyxNQUFNLEdBQUc7RUFDMUIsTUFBTSxhQUFhLE1BQU0sS0FBSyxlQUFlLE9BQU8sTUFBTTtFQUMxRCxNQUFNLGNBQWMsTUFBTSxLQUFLLGdCQUFnQixNQUFNLE9BQU87RUFDNUQsTUFBTSxZQUFZLE1BQU0sSUFBSTtFQUU1QixNQUFNLFVBQVU7R0FDZCxZQUZpQixDQUFDLFdBQVcsUUFBUSxDQUFDLGFBQWEsUUFBUSxDQUFDLGNBQWMsUUFBUSxDQUFDLFlBQVk7R0FHL0YsV0FBVyxJQUFJLEdBQUcsSUFBSSxHQUFHLFNBQVMsQ0FBQyxLQUFLO0VBQzFDO0VBQ0EsSUFBSSxnQkFBZ0I7RUFDcEIsU0FBUyxjQUFjLFNBQVM7R0FDOUIsTUFBTSxRQUFRLFFBQVEsRUFBRSxDQUFDO0dBT3pCLElBQUksQ0FBQyxjQUFjLDBCQUEwQixRQUFRLHNCQUFzQixDQUFDLEdBQzFFLE9BQU8sUUFBUTtHQUVqQixJQUFJLFVBQVUsV0FBVztJQUN2QixJQUFJLENBQUMsZUFDSCxPQUFPLFFBQVE7SUFFakIsSUFBSSxDQUFDLE9BR0gsWUFBWSxpQkFBaUI7S0FDM0IsUUFBUSxPQUFPLElBQUk7SUFDckIsR0FBRyxHQUFJO1NBRVAsUUFBUSxPQUFPLEtBQUs7R0FFeEI7R0FDQSxnQkFBZ0I7RUFDbEI7RUFJQSxJQUFJO0dBQ0YsS0FBSyxJQUFJLHFCQUFxQixlQUFlO0lBQzNDLEdBQUc7SUFFSCxNQUFNLEtBQUs7R0FDYixDQUFDO0VBQ0gsU0FBUyxJQUFJO0dBQ1gsS0FBSyxJQUFJLHFCQUFxQixlQUFlLE9BQU87RUFDdEQ7RUFDQSxHQUFHLFFBQVEsT0FBTztDQUNwQjtDQUNBLE1BQU0sTUFBTSxVQUFVLE9BQU87Q0FLN0IsTUFBTSxxQkFBcUIsUUFBUSxjQUFjO0NBQ2pELElBQUksaUJBQWlCLFVBQVUsWUFBWTtDQUMzQyxRQUFRLElBQUk7Q0FDWixhQUFhO0VBQ1gsSUFBSSxvQkFBb0IsVUFBVSxZQUFZO0VBQzlDLFFBQVE7Q0FDVjtBQUNGOzs7Ozs7Ozs7QUFVQSxTQUFTLFdBQVcsV0FBVyxVQUFVLFFBQVEsU0FBUztDQUN4RCxJQUFJLFlBQVksS0FBSyxHQUNuQixVQUFVLENBQUM7Q0FFYixNQUFNLEVBQ0osaUJBQWlCLE1BQ2pCLGlCQUFpQixNQUNqQixnQkFBZ0IsT0FBTyxtQkFBbUIsWUFDMUMsY0FBYyxPQUFPLHlCQUF5QixZQUM5QyxpQkFBaUIsVUFDZjtDQUNKLE1BQU0sY0FBYyxjQUFjLFNBQVM7Q0FDM0MsTUFBTSxZQUFZLGtCQUFrQixpQkFBaUIsQ0FBQyxHQUFJLGNBQWMscUJBQXFCLFdBQVcsSUFBSSxDQUFDLEdBQUksR0FBSSxXQUFXLHFCQUFxQixRQUFRLElBQUksQ0FBQyxDQUFFLElBQUksQ0FBQztDQUN6SyxVQUFVLFNBQVEsYUFBWTtFQUM1QixrQkFBa0IsU0FBUyxpQkFBaUIsVUFBVSxNQUFNO0VBQzVELGtCQUFrQixTQUFTLGlCQUFpQixVQUFVLE1BQU07Q0FDOUQsQ0FBQztDQUNELE1BQU0sWUFBWSxlQUFlLGNBQWMsWUFBWSxhQUFhLFFBQVEsY0FBYyxJQUFJO0NBQ2xHLElBQUksaUJBQWlCO0NBQ3JCLElBQUksaUJBQWlCO0NBQ3JCLElBQUksZUFBZTtFQUNqQixpQkFBaUIsSUFBSSxnQkFBZSxTQUFRO0dBQzFDLElBQUksQ0FBQyxjQUFjO0dBQ25CLElBQUksY0FBYyxXQUFXLFdBQVcsZUFBZSxrQkFBa0IsVUFBVTtJQUdqRixlQUFlLFVBQVUsUUFBUTtJQUNqQyxxQkFBcUIsY0FBYztJQUNuQyxpQkFBaUIsNEJBQTRCO0tBQzNDLElBQUk7S0FDSixDQUFDLGtCQUFrQixtQkFBbUIsUUFBUSxnQkFBZ0IsUUFBUSxRQUFRO0lBQ2hGLENBQUM7R0FDSDtHQUNBLE9BQU87RUFDVCxDQUFDO0VBQ0QsSUFBSSxlQUFlLENBQUMsZ0JBQ2xCLGVBQWUsUUFBUSxXQUFXO0VBRXBDLElBQUksVUFDRixlQUFlLFFBQVEsUUFBUTtDQUVuQztDQUNBLElBQUk7Q0FDSixJQUFJLGNBQWMsaUJBQWlCLHNCQUFzQixTQUFTLElBQUk7Q0FDdEUsSUFBSSxnQkFDRixVQUFVO0NBRVosU0FBUyxZQUFZO0VBQ25CLE1BQU0sY0FBYyxzQkFBc0IsU0FBUztFQUNuRCxJQUFJLGVBQWUsQ0FBQyxjQUFjLGFBQWEsV0FBVyxHQUN4RCxPQUFPO0VBRVQsY0FBYztFQUNkLFVBQVUsc0JBQXNCLFNBQVM7Q0FDM0M7Q0FDQSxPQUFPO0NBQ1AsYUFBYTtFQUNYLElBQUk7RUFDSixVQUFVLFNBQVEsYUFBWTtHQUM1QixrQkFBa0IsU0FBUyxvQkFBb0IsVUFBVSxNQUFNO0dBQy9ELGtCQUFrQixTQUFTLG9CQUFvQixVQUFVLE1BQU07RUFDakUsQ0FBQztFQUNELFlBQStCO0VBQy9CLENBQUMsbUJBQW1CLG1CQUFtQixRQUFRLGlCQUFpQixXQUFXO0VBQzNFLGlCQUFpQjtFQUNqQixJQUFJLGdCQUNGLHFCQUFxQixPQUFPO0NBRWhDO0FBQ0Y7Ozs7Ozs7O0FBbUJBLElBQU1DLFdBQVM7Ozs7OztBQWVmLElBQU1DLFVBQVE7Ozs7Ozs7QUFRZCxJQUFNQyxTQUFPOzs7Ozs7O0FBUWIsSUFBTUMsU0FBTzs7OztBQTBCYixJQUFNQyxlQUFhOzs7OztBQU1uQixJQUFNLG1CQUFtQixXQUFXLFVBQVUsWUFBWTtDQUl4RCxNQUFNLHdCQUFRLElBQUksSUFBSTtDQUN0QixNQUFNLGdCQUFnQixXQUFXLE9BQU8sVUFBVSxDQUFDO0NBQ25ELE1BQU0sb0JBQW9CO0VBQ3hCLEdBQUc7RUFDSCxHQUFHLGNBQWM7RUFDakIsSUFBSTtDQUNOO0NBQ0EsT0FBTyxrQkFBa0IsV0FBVyxVQUFVO0VBQzVDLEdBQUc7RUFDSCxVQUFVO0NBQ1osQ0FBQztBQUNIOzs7QUN6d0JBLElBQUksUUFIVyxPQUFPLGFBQWEsY0FHWkMsYUFBQUEsa0JBQWtCLFNBRHJCLE9BQU8sQ0FBQztBQUs1QixTQUFTLFVBQVUsR0FBRyxHQUFHO0NBQ3ZCLElBQUksTUFBTSxHQUNSLE9BQU87Q0FFVCxJQUFJLE9BQU8sTUFBTSxPQUFPLEdBQ3RCLE9BQU87Q0FFVCxJQUFJLE9BQU8sTUFBTSxjQUFjLEVBQUUsU0FBUyxNQUFNLEVBQUUsU0FBUyxHQUN6RCxPQUFPO0NBRVQsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSSxLQUFLLEtBQUssT0FBTyxNQUFNLFVBQVU7RUFDbkMsSUFBSSxNQUFNLFFBQVEsQ0FBQyxHQUFHO0dBQ3BCLFNBQVMsRUFBRTtHQUNYLElBQUksV0FBVyxFQUFFLFFBQVEsT0FBTztHQUNoQyxLQUFLLElBQUksUUFBUSxRQUFRLElBQ3ZCLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxFQUFFLEVBQUUsR0FDdkIsT0FBTztHQUdYLE9BQU87RUFDVDtFQUNBLE9BQU8sT0FBTyxLQUFLLENBQUM7RUFDcEIsU0FBUyxLQUFLO0VBQ2QsSUFBSSxXQUFXLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxRQUM1QixPQUFPO0VBRVQsS0FBSyxJQUFJLFFBQVEsUUFBUSxJQUN2QixJQUFJLENBQUMsQ0FBQyxFQUFFLGVBQWUsS0FBSyxHQUFHLEtBQUssRUFBRSxHQUNwQyxPQUFPO0VBR1gsS0FBSyxJQUFJLFFBQVEsUUFBUSxJQUFJO0dBQzNCLE1BQU0sTUFBTSxLQUFLO0dBQ2pCLElBQUksUUFBUSxZQUFZLEVBQUUsVUFDeEI7R0FFRixJQUFJLENBQUMsVUFBVSxFQUFFLE1BQU0sRUFBRSxJQUFJLEdBQzNCLE9BQU87RUFFWDtFQUNBLE9BQU87Q0FDVDtDQUNBLE9BQU8sTUFBTSxLQUFLLE1BQU07QUFDMUI7QUFFQSxTQUFTLE9BQU8sU0FBUztDQUN2QixJQUFJLE9BQU8sV0FBVyxhQUNwQixPQUFPO0NBR1QsUUFEWSxRQUFRLGNBQWMsZUFBZSxPQUFBLENBQ3RDLG9CQUFvQjtBQUNqQztBQUVBLFNBQVMsV0FBVyxTQUFTLE9BQU87Q0FDbEMsTUFBTSxNQUFNLE9BQU8sT0FBTztDQUMxQixPQUFPLEtBQUssTUFBTSxRQUFRLEdBQUcsSUFBSTtBQUNuQztBQUVBLFNBQVMsYUFBYSxPQUFPO0NBQzNCLE1BQU0sTUFBQSxhQUFZLE9BQU8sS0FBSztDQUM5QixZQUFZO0VBQ1YsSUFBSSxVQUFVO0NBQ2hCLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7Ozs7O0FBTUEsU0FBUyxZQUFZLFNBQVM7Q0FDNUIsSUFBSSxZQUFZLEtBQUssR0FDbkIsVUFBVSxDQUFDO0NBRWIsTUFBTSxFQUNKLFlBQVksVUFDWixXQUFXLFlBQ1gsYUFBYSxDQUFDLEdBQ2QsVUFDQSxVQUFVLEVBQ1IsV0FBVyxtQkFDWCxVQUFVLHFCQUNSLENBQUMsR0FDTCxZQUFZLE1BQ1osc0JBQ0EsU0FDRTtDQUNKLE1BQU0sQ0FBQyxNQUFNLFdBQUEsYUFBaUIsU0FBUztFQUNyQyxHQUFHO0VBQ0gsR0FBRztFQUNIO0VBQ0E7RUFDQSxnQkFBZ0IsQ0FBQztFQUNqQixjQUFjO0NBQ2hCLENBQUM7Q0FDRCxNQUFNLENBQUMsa0JBQWtCLHVCQUFBLGFBQTZCLFNBQVMsVUFBVTtDQUN6RSxJQUFJLENBQUMsVUFBVSxrQkFBa0IsVUFBVSxHQUN6QyxvQkFBb0IsVUFBVTtDQUVoQyxNQUFNLENBQUMsWUFBWSxpQkFBQSxhQUF1QixTQUFTLElBQUk7Q0FDdkQsTUFBTSxDQUFDLFdBQVcsZ0JBQUEsYUFBc0IsU0FBUyxJQUFJO0NBQ3JELE1BQU0sZUFBQSxhQUFxQixhQUFZLFNBQVE7RUFDN0MsSUFBSSxTQUFTLGFBQWEsU0FBUztHQUNqQyxhQUFhLFVBQVU7R0FDdkIsY0FBYyxJQUFJO0VBQ3BCO0NBQ0YsR0FBRyxDQUFDLENBQUM7Q0FDTCxNQUFNLGNBQUEsYUFBb0IsYUFBWSxTQUFRO0VBQzVDLElBQUksU0FBUyxZQUFZLFNBQVM7R0FDaEMsWUFBWSxVQUFVO0dBQ3RCLGFBQWEsSUFBSTtFQUNuQjtDQUNGLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsTUFBTSxjQUFjLHFCQUFxQjtDQUN6QyxNQUFNLGFBQWEsb0JBQW9CO0NBQ3ZDLE1BQU0sZUFBQSxhQUFxQixPQUFPLElBQUk7Q0FDdEMsTUFBTSxjQUFBLGFBQW9CLE9BQU8sSUFBSTtDQUNyQyxNQUFNLFVBQUEsYUFBZ0IsT0FBTyxJQUFJO0NBQ2pDLE1BQU0sMEJBQTBCLHdCQUF3QjtDQUN4RCxNQUFNLDBCQUEwQixhQUFhLG9CQUFvQjtDQUNqRSxNQUFNLGNBQWMsYUFBYSxRQUFRO0NBQ3pDLE1BQU0sVUFBVSxhQUFhLElBQUk7Q0FDakMsTUFBTSxTQUFBLGFBQWUsa0JBQWtCO0VBQ3JDLElBQUksQ0FBQyxhQUFhLFdBQVcsQ0FBQyxZQUFZLFNBQ3hDO0VBRUYsTUFBTSxTQUFTO0dBQ2I7R0FDQTtHQUNBLFlBQVk7RUFDZDtFQUNBLElBQUksWUFBWSxTQUNkLE9BQU8sV0FBVyxZQUFZO0VBRWhDLGdCQUFnQixhQUFhLFNBQVMsWUFBWSxTQUFTLE1BQU0sQ0FBQyxDQUFDLE1BQUssU0FBUTtHQUM5RSxNQUFNLFdBQVc7SUFDZixHQUFHO0lBS0gsY0FBYyxRQUFRLFlBQVk7R0FDcEM7R0FDQSxJQUFJLGFBQWEsV0FBVyxDQUFDLFVBQVUsUUFBUSxTQUFTLFFBQVEsR0FBRztJQUNqRSxRQUFRLFVBQVU7SUFDbEIsaUJBQVMsZ0JBQWdCO0tBQ3ZCLFFBQVEsUUFBUTtJQUNsQixDQUFDO0dBQ0g7RUFDRixDQUFDO0NBQ0gsR0FBRztFQUFDO0VBQWtCO0VBQVc7RUFBVTtFQUFhO0NBQU8sQ0FBQztDQUNoRSxZQUFZO0VBQ1YsSUFBSSxTQUFTLFNBQVMsUUFBUSxRQUFRLGNBQWM7R0FDbEQsUUFBUSxRQUFRLGVBQWU7R0FDL0IsU0FBUSxVQUFTO0lBQ2YsR0FBRztJQUNILGNBQWM7R0FDaEIsRUFBRTtFQUNKO0NBQ0YsR0FBRyxDQUFDLElBQUksQ0FBQztDQUNULE1BQU0sZUFBQSxhQUFxQixPQUFPLEtBQUs7Q0FDdkMsWUFBWTtFQUNWLGFBQWEsVUFBVTtFQUN2QixhQUFhO0dBQ1gsYUFBYSxVQUFVO0VBQ3pCO0NBQ0YsR0FBRyxDQUFDLENBQUM7Q0FDTCxZQUFZO0VBQ1YsSUFBSSxhQUFhLGFBQWEsVUFBVTtFQUN4QyxJQUFJLFlBQVksWUFBWSxVQUFVO0VBQ3RDLElBQUksZUFBZSxZQUFZO0dBQzdCLElBQUksd0JBQXdCLFNBQzFCLE9BQU8sd0JBQXdCLFFBQVEsYUFBYSxZQUFZLE1BQU07R0FFeEUsT0FBTztFQUNUO0NBQ0YsR0FBRztFQUFDO0VBQWE7RUFBWTtFQUFRO0VBQXlCO0NBQXVCLENBQUM7Q0FDdEYsTUFBTSxPQUFBLGFBQWEsZUFBZTtFQUNoQyxXQUFXO0VBQ1gsVUFBVTtFQUNWO0VBQ0E7Q0FDRixJQUFJLENBQUMsY0FBYyxXQUFXLENBQUM7Q0FDL0IsTUFBTSxXQUFBLGFBQWlCLGVBQWU7RUFDcEMsV0FBVztFQUNYLFVBQVU7Q0FDWixJQUFJLENBQUMsYUFBYSxVQUFVLENBQUM7Q0FDN0IsTUFBTSxpQkFBQSxhQUF1QixjQUFjO0VBQ3pDLE1BQU0sZ0JBQWdCO0dBQ3BCLFVBQVU7R0FDVixNQUFNO0dBQ04sS0FBSztFQUNQO0VBQ0EsSUFBSSxDQUFDLFNBQVMsVUFDWixPQUFPO0VBRVQsTUFBTSxJQUFJLFdBQVcsU0FBUyxVQUFVLEtBQUssQ0FBQztFQUM5QyxNQUFNLElBQUksV0FBVyxTQUFTLFVBQVUsS0FBSyxDQUFDO0VBQzlDLElBQUksV0FDRixPQUFPO0dBQ0wsR0FBRztHQUNILFdBQVcsZUFBZSxJQUFJLFNBQVMsSUFBSTtHQUMzQyxHQUFJLE9BQU8sU0FBUyxRQUFRLEtBQUssT0FBTyxFQUN0QyxZQUFZLFlBQ2Q7RUFDRjtFQUVGLE9BQU87R0FDTCxVQUFVO0dBQ1YsTUFBTTtHQUNOLEtBQUs7RUFDUDtDQUNGLEdBQUc7RUFBQztFQUFVO0VBQVcsU0FBUztFQUFVLEtBQUs7RUFBRyxLQUFLO0NBQUMsQ0FBQztDQUMzRCxPQUFBLGFBQWEsZUFBZTtFQUMxQixHQUFHO0VBQ0g7RUFDQTtFQUNBO0VBQ0E7Q0FDRixJQUFJO0VBQUM7RUFBTTtFQUFRO0VBQU07RUFBVTtDQUFjLENBQUM7QUFDcEQ7Ozs7Ozs7O0FBK0NBLElBQU0sVUFBVSxTQUFTLFNBQVM7Q0FDaEMsTUFBTSxTQUFTQyxTQUFTLE9BQU87Q0FDL0IsT0FBTztFQUNMLE1BQU0sT0FBTztFQUNiLElBQUksT0FBTztFQUNYLFNBQVMsQ0FBQyxTQUFTLElBQUk7Q0FDekI7QUFDRjs7Ozs7O0FBT0EsSUFBTSxTQUFTLFNBQVMsU0FBUztDQUMvQixNQUFNLFNBQVNDLFFBQVEsT0FBTztDQUM5QixPQUFPO0VBQ0wsTUFBTSxPQUFPO0VBQ2IsSUFBSSxPQUFPO0VBQ1gsU0FBUyxDQUFDLFNBQVMsSUFBSTtDQUN6QjtBQUNGOzs7O0FBS0EsSUFBTSxjQUFjLFNBQVMsU0FBUztDQUVwQyxPQUFPO0VBQ0wsSUFGYUMsYUFBYSxPQUVqQixDQUFDLENBQUM7RUFDWCxTQUFTLENBQUMsU0FBUyxJQUFJO0NBQ3pCO0FBQ0Y7Ozs7Ozs7QUFRQSxJQUFNLFFBQVEsU0FBUyxTQUFTO0NBQzlCLE1BQU0sU0FBU0MsT0FBTyxPQUFPO0NBQzdCLE9BQU87RUFDTCxNQUFNLE9BQU87RUFDYixJQUFJLE9BQU87RUFDWCxTQUFTLENBQUMsU0FBUyxJQUFJO0NBQ3pCO0FBQ0Y7Ozs7Ozs7QUFRQSxJQUFNLFFBQVEsU0FBUyxTQUFTO0NBQzlCLE1BQU0sU0FBU0MsT0FBTyxPQUFPO0NBQzdCLE9BQU87RUFDTCxNQUFNLE9BQU87RUFDYixJQUFJLE9BQU87RUFDWCxTQUFTLENBQUMsU0FBUyxJQUFJO0NBQ3pCO0FBQ0Y7O0FDdlZBLFNBQWdCLGlDQUFpQyxrQkFBa0I7Q0FDakUsT0FBTyxxQkFBcUIsYUFBYSw2QkFBNkI7QUFDeEU7Ozs7Ozs7QUNRQSxTQUFnQixrQkFBa0IsU0FBUztDQUN6QyxNQUFNLEVBQ0osUUFDQSxjQUNBLGFBQWEsVUFDWDtDQUNKLE1BQU0sbUJBQW1CLE1BQU0sU0FBUyxrQkFBa0I7Q0FDMUQsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLGlCQUFpQjtDQUN4RCxNQUFNLHNCQUFzQixNQUFNLFNBQVMscUJBQXFCO0NBQ2hFLE1BQU0sT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUNsQyxNQUFNLGFBQWEsTUFBTSxTQUFTLFlBQVk7Q0FDOUMsTUFBTSxDQUFDLG1CQUFtQiwyQkFBQSxhQUFpQyxTQUFTLElBQUk7Q0FDeEUsTUFBTSxrQkFBQSxhQUF3QixPQUFPLElBQUk7Q0FDekMsTUFBTSxPQUFPLGdCQUFnQixZQUFZO0NBQ3pDLE1BQU0sZ0JBQUEsYUFBc0IsZUFBZTtFQUN6QyxXQUFXO0VBQ1gsVUFBVTtFQUNWLGNBQWM7Q0FDaEIsSUFBSTtFQUFDO0VBQWtCO0VBQWlCO0NBQW1CLENBQUM7Q0FDNUQsTUFBTSxXQUFXQyxZQUFZO0VBQzNCLEdBQUc7RUFDSCxVQUFVO0dBQ1IsR0FBRztHQUNILEdBQUkscUJBQXFCLEVBQ3ZCLFdBQVcsa0JBQ2I7RUFDRjtDQUNGLENBQUM7Q0FDRCxNQUFNLHVCQUFBLGFBQTZCLGFBQVksU0FBUTtFQUNyRCxNQUFNLDRCQUE0QixVQUFVLElBQUksSUFBSTtHQUNsRCw2QkFBNkIsS0FBSyxzQkFBc0I7R0FDeEQsc0JBQXNCLEtBQUssZUFBZTtHQUMxQyxnQkFBZ0I7RUFDbEIsSUFBSTtFQUdKLHdCQUF3Qix5QkFBeUI7RUFDakQsU0FBUyxLQUFLLGFBQWEseUJBQXlCO0NBQ3RELEdBQUcsQ0FBQyxTQUFTLElBQUksQ0FBQztDQUNsQixNQUFNLE9BQUEsYUFBYSxlQUFlO0VBQ2hDLEdBQUcsU0FBUztFQUNaO0VBQ0EsY0FBYztDQUNoQixJQUFJLENBQUMsU0FBUyxNQUFNLG9CQUFvQixDQUFDO0NBQ3pDLE1BQU0sV0FBQSxhQUFpQixlQUFlO0VBQ3BDLEdBQUcsU0FBUztFQUNaLGNBQWM7Q0FDaEIsSUFBSSxDQUFDLFNBQVMsVUFBVSxtQkFBbUIsQ0FBQztDQUM1QyxNQUFNLFVBQUEsYUFBZ0IsZUFBZTtFQUNuQyxHQUFHO0VBQ0gsU0FBUyxNQUFNLFFBQVE7RUFDdkI7RUFDQSxjQUFjLE1BQU07RUFDcEIsUUFBUSxNQUFNLFFBQVE7RUFDdEI7RUFDQTtFQUNBO0VBQ0E7RUFDQSxXQUFXO0NBQ2IsSUFBSTtFQUFDO0VBQVU7RUFBTTtFQUFVO0VBQVE7RUFBTztFQUFNO0NBQVUsQ0FBQztDQUMvRCx5QkFBeUI7RUFDdkIsSUFBSSxxQkFDRixnQkFBZ0IsVUFBVTtDQUU5QixHQUFHLENBQUMsbUJBQW1CLENBQUM7Q0FDeEIseUJBQXlCO0VBQ3ZCLE1BQU0sUUFBUSxRQUFRLFFBQVEsa0JBQWtCO0VBQ2hELE1BQU0sT0FBTyxNQUFNLFNBQVMsUUFBUSxNQUFLLE1BQUssRUFBRSxPQUFPLE1BQU07RUFDN0QsSUFBSSxNQUNGLEtBQUssVUFBVTtDQUVuQixDQUFDO0NBQ0QsT0FBQSxhQUFhLGVBQWU7RUFDMUIsR0FBRztFQUNIO0VBQ0E7RUFDQTtFQUNBLFdBQVc7Q0FDYixJQUFJO0VBQUM7RUFBVTtFQUFNO0VBQVU7RUFBUztDQUFLLENBQUM7QUFDaEQ7Ozs7OztBQ3RGQSxJQUFhLGFBQVksYUFBWTtDQUNuQyxNQUFNO0NBQ047Q0FDQSxNQUFNLEdBQUcsT0FBTztFQUNkLE1BQU0sRUFDSixHQUNBLEdBQ0EsV0FDQSxPQUNBLFVBQ0EsVUFDQSxtQkFDRTtFQUVKLE1BQU0sRUFDSixTQUNBLFVBQVUsTUFDUixTQUFTLFNBQVMsS0FBSyxLQUFLLENBQUM7RUFDakMsSUFBSSxXQUFXLE1BQ2IsT0FBTyxDQUFDO0VBRVYsTUFBTSxnQkFBZ0IsaUJBQWlCLE9BQU87RUFDOUMsTUFBTSxTQUFTO0dBQ2I7R0FDQTtFQUNGO0VBQ0EsTUFBTSxPQUFPLGlCQUFpQixTQUFTO0VBQ3ZDLE1BQU0sU0FBUyxjQUFjLElBQUk7RUFDakMsTUFBTSxrQkFBa0IsTUFBTSxTQUFTLGNBQWMsT0FBTztFQUM1RCxNQUFNLFVBQVUsU0FBUztFQUN6QixNQUFNLFVBQVUsVUFBVSxRQUFRO0VBQ2xDLE1BQU0sVUFBVSxVQUFVLFdBQVc7RUFDckMsTUFBTSxhQUFhLFVBQVUsaUJBQWlCO0VBQzlDLE1BQU0sVUFBVSxNQUFNLFVBQVUsVUFBVSxNQUFNLFVBQVUsUUFBUSxPQUFPLFFBQVEsTUFBTSxTQUFTO0VBQ2hHLE1BQU0sWUFBWSxPQUFPLFFBQVEsTUFBTSxVQUFVO0VBQ2pELE1BQU0sYUFBYSxTQUFTLFNBQVMsZUFBZSxNQUFNLFNBQVM7RUFDbkUsTUFBTSxvQkFBb0IsVUFBVSxJQUFJLFlBQVk7RUFJcEQsTUFBTSx5QkFBeUIsYUFBYSxJQUFJLGdCQUFnQixVQUFVLElBQUk7RUFDOUUsTUFBTSxhQUFhLEtBQUssSUFBSSxjQUFjLFVBQVUsc0JBQXNCO0VBQzFFLE1BQU0sYUFBYSxLQUFLLElBQUksY0FBYyxVQUFVLHNCQUFzQjtFQUkxRSxNQUFNLE1BQU07RUFDWixNQUFNLE1BQU0sYUFBYSxnQkFBZ0IsVUFBVTtFQUNuRCxNQUFNLFNBQVMsYUFBYSxJQUFJLGdCQUFnQixVQUFVLElBQUk7RUFDOUQsTUFBTSxTQUFTLE1BQU0sS0FBSyxRQUFRLEdBQUc7RUFNckMsTUFBTSxrQkFBa0IsQ0FBQyxlQUFlLFNBQVMsYUFBYSxTQUFTLEtBQUssUUFBUSxXQUFXLFVBQVUsTUFBTSxVQUFVLFVBQVUsS0FBSyxTQUFTLE1BQU0sYUFBYSxjQUFjLGdCQUFnQixVQUFVLElBQUk7RUFFaE4sTUFBTSxrQkFBa0Isa0JBQWtCLFNBQVMsTUFBTSxTQUFTLE1BQU0sU0FBUyxNQUFNO0VBQ3ZGLE9BQU87SUFDSixPQUFPLE9BQU8sUUFBUTtHQUN2QixNQUFNO0tBQ0gsT0FBTztJQUNSLGNBQWMsU0FBUyxTQUFTO0lBQ2hDLEdBQUksbUJBQW1CLEVBQ3JCLGdCQUNGO0dBQ0Y7R0FDQSxPQUFPO0VBQ1Q7Q0FDRjtBQUNGOzs7Ozs7O0FBUUEsSUFBYSxTQUFTLFNBQVMsU0FBUztDQUN0QyxNQUFNLEVBQ0osTUFDQSxPQUNFLFVBQVUsT0FBTztDQUNyQixPQUFPO0VBQ0w7RUFDQTtFQUNBLFNBQVMsQ0FBQyxTQUFTLElBQUk7Q0FDekI7QUFDRjs7QUM3RkEsSUFBYSxPQUFPO0NBQ2xCLE1BQU07Q0FDTixNQUFNLEdBQUcsT0FBTztFQUNkLE1BQU0sRUFDSixPQUNBLFFBQ0EsR0FDQSxNQUNFLE1BQU0sTUFBTTtFQUNoQixNQUFNLGVBQWUsVUFBVSxLQUFLLFdBQVcsS0FBSyxNQUFNLEtBQUssTUFBTTtFQUdyRSxNQUFNLFdBQVcsTUFBTSxNQUFNLFNBQVMsZUFBZSxPQUFPLEVBQzFELGdCQUFnQixZQUNsQixDQUFDO0VBRUQsT0FBTyxFQUNMLE1BQU0sRUFDSixpQkFIb0IsU0FBUyxNQUFNLFVBQVUsS0FBSyxTQUFTLFFBQVEsU0FBUyxLQUFLLFNBQVMsU0FBUyxVQUFVLEtBQUssU0FBUyxPQUFPLFNBQVMsS0FHdkcsYUFDdEMsRUFDRjtDQUNGO0FBQ0Y7O0FDdEJBLElBQWEsZ0JBQWdCO0NBQzNCLE9BQU87Q0FDUCxPQUFPO0FBQ1Q7Ozs7OztBQ0NBLElBQWEsaUJBQWlCOzs7OztBQUs5QixJQUFhLGtCQUFrQjs7Ozs7QUFLL0IsSUFBYSxjQUFjOzs7OztBQUszQixJQUFhLGVBQWU7Ozs7O0FBSzVCLElBQWEsa0JBQWtCOzs7Ozs7QUFNL0IsSUFBYSxrQkFBa0I7Ozs7OztBQU0vQixJQUFhLG1CQUFtQjs7QUNyQmhDLElBQU0sc0JBQXNCQztBQUM1QixJQUFNLHVCQUF1QkM7QUFDN0IsU0FBUyxlQUFlLFdBQVcsY0FBYyxPQUFPO0NBQ3RELE1BQU0scUJBQXFCLGNBQWMsa0JBQWtCLGNBQWM7Q0FHekUsT0FBTztFQUNMLEtBQUs7RUFDTCxPQUFPLHFCQUpZLFFBQVEsaUJBQWlCLGVBSUQ7RUFDM0MsUUFBUTtFQUNSLE1BQU0scUJBTFksUUFBUSxlQUFlLGlCQUtBO0NBQzNDLEVBQUU7QUFDSjtBQUNBLFNBQVMsY0FBYyxPQUFPLFdBQVcsT0FBTztDQUM5QyxNQUFNLEVBQ0osT0FDQSxjQUNFO0NBYUosT0FBTztFQVhMLE1BQU0sZUFBZSxXQUFXLFFBQVEsU0FBUyxHQUFHLEtBQUs7RUFDekQsT0FBTyxhQUFhLFNBQVMsS0FBSztFQUNsQyxRQUFRO0dBQ04sT0FBTyxNQUFNLFVBQVU7R0FDdkIsUUFBUSxNQUFNLFVBQVU7RUFDMUI7RUFDQSxZQUFZO0dBQ1YsT0FBTyxNQUFNLFNBQVM7R0FDdEIsUUFBUSxNQUFNLFNBQVM7RUFDekI7Q0FFUTtBQUNaOzs7OztBQUtBLFNBQWdCLHFCQUFxQixRQUFRO0NBQzNDLE9BQU8sNkJBQTZCLFFBQVEsaUJBQWlCO0FBQy9EO0FBQ0EsU0FBZ0IsNkJBQTZCLFFBQVEsaUJBQWlCO0NBQ3BFLE1BQU0sRUFFSixRQUNBLGlCQUFpQixZQUNqQixNQUFNLFlBQVksVUFDbEIsYUFBYSxHQUNiLFFBQVEsVUFDUixjQUFjLEdBQ2QsbUJBQ0Esa0JBQWtCLHdCQUF3QixHQUMxQyxTQUFTLE9BQ1QsZUFBZSxHQUNmLHdCQUF3QixPQUN4QixRQUFRLGtCQUVSLGNBQWMsT0FDZCxxQkFDQSxTQUNBLG9CQUNBLE9BQUEsU0FDQSxRQUNBLGdCQUNBLFdBQVcsT0FDWCxpQkFDRTtDQUNKLE1BQU0seUJBQXlCLG1CQUFtQixRQUFRO0NBQzFELE1BQU0sMEJBQTBCLG1CQUFtQixTQUFTO0NBQzVELE1BQU0scUNBQXFDLG1CQUFtQixvQkFBb0I7Q0FDbEYsTUFBTSxpQkFBaUJDLFNBQU8sYUFBYTtDQUMzQyxNQUFNLG9CQUFvQkEsU0FBTztDQUNqQyxNQUFNLFdBQVcsT0FBTyxXQUFXLGFBQWEsU0FBUyxLQUFBO0NBQ3pELE1BQU0sbUJBQW1CLGtCQUFrQixRQUFRO0NBQ25ELE1BQU0sWUFBWSxXQUFXLG1CQUFtQjtDQUNoRCxNQUFNLGlCQUFpQixjQUFjLE1BQU07Q0FDM0MsTUFBTSxhQUFhLGNBQWMsT0FBTztDQUV4QyxNQUFNLFFBRFksYUFDSSxNQUFNO0NBQzVCLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQUEsYUFBMkIsU0FBUyxJQUFJO0NBQy9ELElBQUksQ0FBQyxXQUFXLG1CQUFtQixNQUNqQyxrQkFBa0IsSUFBSTtDQUV4QixNQUFNLFlBQVksYUFBYTtDQUMvQixNQUFNLFlBQVksaUJBQWlCLFFBQVEsY0FBYyxJQUFJO0NBQzdELE1BQU0sYUFBYSxrQkFBa0IsWUFBWSxhQUFhLGNBQWMsS0FBSyxXQUFXO0NBQzVGLE1BQU0sT0FBTyxhQUFhO0VBQ3hCLEtBQUs7RUFDTCxPQUFPO0VBQ1AsUUFBUTtFQUNSLE1BQU07RUFDTixjQUFjLFFBQVEsU0FBUztFQUMvQixnQkFBZ0IsUUFBUSxVQUFVO0NBQ3BDLEVBQUU7Q0FDRixNQUFNLGlCQUFpQixjQUFjO0NBQ3JDLE1BQU0sWUFBWSxtQkFBbUIsV0FBVyxPQUFPLEdBQUcsS0FBSyxHQUFHO0NBQ2xFLElBQUksbUJBQW1CO0NBQ3ZCLElBQUksT0FBTyxxQkFBcUIsVUFDOUIsbUJBQW1CO0VBQ2pCLEtBQUs7RUFDTCxPQUFPO0VBQ1AsUUFBUTtFQUNSLE1BQU07Q0FDUjtNQUNLLElBQUksa0JBQ1QsbUJBQW1CO0VBQ2pCLEtBQUssaUJBQWlCLE9BQU87RUFDN0IsT0FBTyxpQkFBaUIsU0FBUztFQUNqQyxRQUFRLGlCQUFpQixVQUFVO0VBQ25DLE1BQU0saUJBQWlCLFFBQVE7Q0FDakM7Q0FRRixNQUFNLE9BQU87Q0FDYixNQUFNLFVBQVUsY0FBYyxXQUFXLE9BQU87Q0FDaEQsTUFBTSxhQUFhLGNBQWMsUUFBUSxPQUFPO0NBQ2hELE1BQU0sV0FBVyxjQUFjLFVBQVUsT0FBTztDQUNoRCxNQUFNLFlBQVksY0FBYyxTQUFTLE9BQU87Q0FDaEQsTUFBTSx1QkFBdUI7RUFDM0IsVUFBVSxzQkFBc0IsdUJBQXVCLHNCQUFzQjtFQUM3RSxTQUFTO0NBQ1g7Q0FLQSxNQUFNLFdBQUEsYUFBaUIsT0FBTyxJQUFJO0NBR2xDLE1BQU0sZ0JBQWdCLGNBQWMsVUFBVTtDQUM5QyxNQUFNLGlCQUFpQixjQUFjLFdBQVc7Q0FDaEQsTUFBTSxnQkFBZ0IsT0FBTyxlQUFlLGFBQWEsYUFBYTtDQUN0RSxNQUFNLGlCQUFpQixPQUFPLGdCQUFnQixhQUFhLGNBQWM7Q0FDekUsTUFBTSxhQUFhLENBQUM7Q0FDcEIsSUFBSSxrQkFDRixXQUFXLEtBQUssZ0JBQWdCO0NBRWxDLFdBQVcsS0FBSyxRQUFPLFVBQVM7RUFDOUIsTUFBTSxPQUFPLGNBQWMsT0FBTyxXQUFXLEtBQUs7RUFDbEQsTUFBTSxXQUFXLE9BQU8sY0FBYyxZQUFZLGFBQWEsY0FBYyxRQUFRLElBQUksSUFBSSxjQUFjO0VBQzNHLE1BQU0sWUFBWSxPQUFPLGVBQWUsWUFBWSxhQUFhLGVBQWUsUUFBUSxJQUFJLElBQUksZUFBZTtFQUMvRyxPQUFPO0dBQ0wsVUFBVTtHQUNWLFdBQVc7R0FDWCxlQUFlO0VBQ2pCO0NBQ0YsR0FBRztFQUFDO0VBQWU7RUFBZ0I7RUFBTztDQUFTLENBQUMsQ0FBQztDQUNyRCxNQUFNLGdCQUFnQiw0QkFBNEIsVUFBVSwyQkFBMkI7Q0FDdkYsTUFBTSx3QkFBd0IsQ0FBQyxrQkFBa0IsVUFBVSxrQkFBa0IsMkJBQTJCO0NBQ3hHLE1BQU0saUJBQWlCLDJCQUEyQixTQUFTLE9BQU8sS0FBSztFQUNyRSxHQUFHO0VBR0gsU0FBUztHQUNQLEtBQUssaUJBQWlCLE1BQU0sT0FBTztHQUNuQyxPQUFPLGlCQUFpQixRQUFRLE9BQU87R0FDdkMsUUFBUSxpQkFBaUIsU0FBUyxPQUFPO0dBQ3pDLE1BQU0saUJBQWlCLE9BQU8sT0FBTztFQUN2QztFQUNBLFVBQVUsQ0FBQyxrQkFBa0IsMkJBQTJCO0VBQ3hELFdBQVcsNEJBQTRCLFNBQVMsY0FBYztFQUM5RCwyQkFBMkI7Q0FDN0IsQ0FBQztDQUNELE1BQU0sa0JBQWtCLGdCQUFnQixPQUFPQyxNQUFjO0VBQzNELEdBQUc7RUFFSCxjQUFjO0VBQ2QsVUFBVSw0QkFBNEI7RUFDdEMsV0FBVztFQUNYLFNBQVMsVUFBVSxpQkFBaUIsS0FBQSxJQUFZLFlBQVcsY0FBYTtHQUN0RSxJQUFJLENBQUMsU0FBUyxTQUNaLE9BQU8sQ0FBQztHQUVWLE1BQU0sRUFDSixPQUNBLFdBQ0UsU0FBUyxRQUFRLHNCQUFzQjtHQUMzQyxNQUFNLFdBQVcsWUFBWSxRQUFRLFVBQVUsU0FBUyxDQUFDO0dBQ3pELE1BQU0sWUFBWSxhQUFhLE1BQU0sUUFBUTtHQUM3QyxNQUFNLGVBQWUsYUFBYSxNQUFNLGlCQUFpQixPQUFPLGlCQUFpQixRQUFRLGlCQUFpQixNQUFNLGlCQUFpQjtHQUNqSSxPQUFPLEVBQ0wsUUFBUSxZQUFZLElBQUksZUFBZSxFQUN6QztFQUNGLENBQUM7Q0FDSCxHQUFHO0VBQUM7RUFBc0I7RUFBUTtFQUFnQjtFQUFtQjtFQUFrQjtDQUF1QixDQUFDO0NBSy9HLElBQUksMkJBQTJCLFdBQVcsNEJBQTRCLFdBQVcsbUJBQW1CLFVBQ2xHLFdBQVcsS0FBSyxpQkFBaUIsY0FBYztNQUUvQyxXQUFXLEtBQUssZ0JBQWdCLGVBQWU7Q0FFakQsV0FBVyxLQUFLLEtBQUs7RUFDbkIsR0FBRztFQUNILE1BQU0sRUFDSixVQUFVLEVBQ1IsWUFFRixnQkFDQSxpQkFDQSxTQUNDO0dBQ0QsSUFBSSxDQUFDLFdBQVcsU0FDZDtHQUVGLE1BQU0sZ0JBQWdCLFNBQVM7R0FDL0IsY0FBYyxZQUFZLHFCQUFxQixHQUFHLGVBQWUsR0FBRztHQUNwRSxjQUFjLFlBQVksc0JBQXNCLEdBQUcsZ0JBQWdCLEdBQUc7R0FHdEUsTUFBTSxNQUFNQyxVQUFZLFFBQVEsQ0FBQyxDQUFDLG9CQUFvQjtHQUN0RCxNQUFNLEVBQ0osR0FDQSxHQUNBLE9BQ0EsV0FDRSxNQUFNO0dBQ1YsTUFBTUMsaUJBQWUsS0FBSyxPQUFPLElBQUksU0FBUyxHQUFHLElBQUksS0FBSyxNQUFNLElBQUksR0FBRyxLQUFLO0dBQzVFLE1BQU1DLGtCQUFnQixLQUFLLE9BQU8sSUFBSSxVQUFVLEdBQUcsSUFBSSxLQUFLLE1BQU0sSUFBSSxHQUFHLEtBQUs7R0FDOUUsY0FBYyxZQUFZQyxhQUFxQyxHQUFHRixjQUFZLEdBQUc7R0FDakYsY0FBYyxZQUFZRyxjQUFzQyxHQUFHRixlQUFhLEdBQUc7RUFDckY7Q0FDRixDQUFDLEdBQUcsT0FBTSxXQUFVO0VBR2xCLFNBQVMsU0FBUyxXQUFXLGNBQWMsTUFBTSxTQUFTLFFBQVEsQ0FBQyxDQUFDLGNBQWMsS0FBSztFQUV2RixTQUFTLFNBQVMsVUFBVSxlQUFlO0NBQzdDLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRztFQUNuQixNQUFNO0VBQ04sR0FBRyxPQUFPO0dBQ1IsTUFBTSxFQUNKLFVBQVUsRUFDUixZQUVGLGdCQUNBLFdBQVcsbUJBQ1gsVUFDQSxPQUNBLE1BQ0U7R0FDSixNQUFNLGVBQWUsUUFBUSxpQkFBaUI7R0FDOUMsTUFBTSxnQkFBZ0IsYUFBYSxpQkFBaUI7R0FDcEQsTUFBTSxhQUFhLFlBQVksWUFBWSxNQUFNO0dBQ2pELE1BQU0sVUFBVSxTQUFTO0dBQ3pCLE1BQU0sa0JBQWtCLE9BQU8sZUFBZSxhQUFhLFdBQVcsY0FBYyxPQUFPLFdBQVcsS0FBSyxDQUFDLElBQUk7R0FJaEgsSUFBSTtHQUNKLElBQUksQ0FBQyxXQUFXLGlCQUFpQixLQUFLLElBQUksYUFBYSxlQUFlLE9BQU8sS0FBSyxJQUFJLGVBQWUsT0FBTyxLQUFLLENBQUMsS0FBSyxHQUVySCxjQUFjLGtCQUFrQixhQUFhLGNBQWMsU0FBUyxRQUFRLFFBQVEsTUFBTSxRQUFRLFNBQVM7UUFJM0csY0FBYyxJQUZNLGFBQWEsZUFBZSxPQUFPLEtBQUssSUFBSSxlQUFlLE9BQU8sS0FBSyxNQUN6RSxhQUFhLFNBQVMsZUFBZSxJQUFJLFNBQVMsZ0JBQWdCLEtBQ3pDLEVBQUU7R0FJL0MsSUFBSSxhQUFhLGlCQUFpQixTQUFTLGlCQUFpQixTQUFTLGVBQWUsZ0JBQWdCLE9BQU8sR0FBRyxDQUFDLGdCQUFnQjtHQUMvSCxJQUFJLHlCQUF5QixjQUFjLEtBQUssSUFBSSxlQUFlLE9BQU8sS0FBSyxDQUFDLElBQUksaUJBQ2xGLGFBQWEsR0FBRyxNQUFNLFVBQVUsSUFBSSxNQUFNLFVBQVUsU0FBUyxJQUFJLEVBQUU7R0FFckUsU0FBUyxNQUFNLFlBQVlHLGlCQUF5QyxhQUFhLEdBQUcsWUFBWSxHQUFHLGVBQWUsR0FBRyxXQUFXLEdBQUcsYUFBYTtHQUNoSixPQUFPLENBQUM7RUFDVjtDQUNGLEdBQUcsTUFBTSxjQUFjO0NBQ3ZCLHlCQUF5QjtFQUd2QixJQUFJLENBQUMsV0FBVyxxQkFDZCxvQkFBb0IsT0FBTztHQUN6QixrQkFBa0I7R0FDbEIsaUJBQWlCO0dBQ2pCLHFCQUFxQjtHQUNyQixtQkFBbUI7RUFDckIsQ0FBQztDQUVMLEdBQUcsQ0FBQyxTQUFTLG1CQUFtQixDQUFDO0NBQ2pDLE1BQU0sb0JBQUEsYUFBMEIsZUFBZTtFQUM3QyxnQkFBZ0IsQ0FBQztFQUNqQixlQUFlLENBQUMseUJBQXlCLE9BQU8sbUJBQW1CO0VBQ25FLGFBQWEsQ0FBQyx5QkFBeUIsT0FBTyx5QkFBeUI7Q0FDekUsSUFBSSxDQUFDLHFCQUFxQixDQUFDO0NBQzNCLE1BQU0sRUFDSixNQUNBLFVBQ0EsR0FDQSxHQUNBLGdCQUNBLFFBQ0EsV0FBVyxtQkFDWCxTQUNBLGNBQ0EsZ0JBQWdCLDJCQUNkLGdCQUFnQjtFQUNsQixhQUFhO0VBQ2IsTUFBTSxjQUFjLFVBQVUsS0FBQTtFQUM5QjtFQUNBO0VBQ0EsVUFBVTtFQUNWLHNCQUFzQixjQUFjLEtBQUEsS0FBYSxHQUFHLFNBQVMsV0FBVyxHQUFHLE1BQU0saUJBQWlCO0VBQ2xHO0VBQ0E7Q0FDRixDQUFDO0NBQ0QsTUFBTSxFQUNKLE9BQ0EsVUFDRSxlQUFlLGtCQUFrQjtDQUlyQyxNQUFNLG1CQUFtQixlQUFlLGlCQUFpQjtDQUN6RCxNQUFNLGlCQUFBLGFBQXVCLGNBQWM7RUFDekMsSUFBSTtFQUNKLElBQUksQ0FBQyxjQUtILE9BQU87R0FDTCxVQUFVO0dBQ1YsS0FBSztHQUNMLE1BQU07RUFDUjtPQUNLLElBQUksZ0JBQ1QsT0FBTztHQUNMLFVBQVU7SUFDVCxRQUFRO0lBQ1IsUUFBUTtFQUNYO09BRUEsT0FBTztHQUNMLEdBQUc7R0FDSCxVQUFVO0VBQ1o7RUFZRixLQUFLLHVCQUF1QjtFQUM1QixLQUFLLHdCQUF3QjtFQUM3QixJQUFJLENBQUMsY0FDSCxLQUFLLFVBQVU7RUFFakIsT0FBTztDQUNULEdBQUc7RUFBQztFQUFnQjtFQUFrQjtFQUFPO0VBQUc7RUFBTztFQUFHO0VBQXdCO0NBQVksQ0FBQztDQUMvRixNQUFNLGlDQUFBLGFBQXVDLE9BQU8sSUFBSTtDQUN4RCx5QkFBeUI7RUFDdkIsSUFBSSxDQUFDLFNBQ0g7RUFFRixNQUFNLGNBQWMsZUFBZTtFQUNuQyxNQUFNLGlCQUFpQixPQUFPLGdCQUFnQixhQUFhLFlBQVksSUFBSTtFQUUzRSxNQUFNLGVBRG9CLE1BQU0sY0FBYyxJQUFJLGVBQWUsVUFBVSxtQkFDbkM7RUFDeEMsSUFBSSxnQkFBZ0IsK0JBQStCLFNBQVM7R0FDMUQsS0FBSyxxQkFBcUIsV0FBVztHQUNyQywrQkFBK0IsVUFBVTtFQUMzQztDQUNGLEdBQUc7RUFBQztFQUFTO0VBQU07RUFBVztDQUFjLENBQUM7Q0FDN0MsYUFBTSxnQkFBZ0I7RUFDcEIsSUFBSSxDQUFDLFNBQ0g7RUFFRixNQUFNLGNBQWMsZUFBZTtFQUluQyxJQUFJLE9BQU8sZ0JBQWdCLFlBQ3pCO0VBRUYsSUFBSSxNQUFNLFdBQVcsS0FBSyxZQUFZLFlBQVksK0JBQStCLFNBQVM7R0FDeEYsS0FBSyxxQkFBcUIsWUFBWSxPQUFPO0dBQzdDLCtCQUErQixVQUFVLFlBQVk7RUFDdkQ7Q0FDRixHQUFHO0VBQUM7RUFBUztFQUFNO0VBQVc7Q0FBYyxDQUFDO0NBQzdDLGFBQU0sZ0JBQWdCO0VBQ3BCLElBQUksZUFBZSxXQUFXLFNBQVMsYUFBYSxTQUFTLFVBQzNELE9BQU8sV0FBVyxTQUFTLFdBQVcsU0FBUyxVQUFVLFFBQVEsaUJBQWlCO0NBR3RGLEdBQUc7RUFBQztFQUFhO0VBQVM7RUFBVTtFQUFRO0NBQWlCLENBQUM7Q0FDOUQsTUFBTSxlQUFlLFFBQVEsaUJBQWlCO0NBQzlDLE1BQU0sc0JBQXNCLGVBQWUsV0FBVyxjQUFjLEtBQUs7Q0FDekUsTUFBTSxnQkFBZ0IsYUFBYSxpQkFBaUIsS0FBSztDQUN6RCxNQUFNLGVBQWUsUUFBUSxlQUFlLE1BQU0sZUFBZTtDQUlqRSx5QkFBeUI7RUFDdkIsSUFBSSxZQUFZLFdBQVcsaUJBQWlCLGlCQUFpQixRQUFRLGFBQWEsa0JBQWtCLGlCQUNsRyxrQkFBa0IsaUJBQWlCO0NBRXZDLEdBQUc7RUFBQztFQUFVO0VBQVc7RUFBUztFQUFjO0VBQW1CO0VBQWM7RUFBZTtFQUFNO0NBQWMsQ0FBQztDQUNySCxNQUFNLGNBQUEsYUFBb0IsZUFBZTtFQUN2QyxVQUFVO0VBQ1YsS0FBSyxlQUFlLE9BQU87RUFDM0IsTUFBTSxlQUFlLE9BQU87Q0FDOUIsSUFBSSxDQUFDLGVBQWUsS0FBSyxDQUFDO0NBQzFCLE1BQU0sa0JBQWtCLGVBQWUsT0FBTyxpQkFBaUI7Q0FDL0QsT0FBQSxhQUFhLGVBQWU7RUFDMUIsa0JBQWtCO0VBQ2xCO0VBQ0E7RUFDQTtFQUNBLE1BQU07RUFDTixPQUFPO0VBQ1AsY0FBYztFQUNkO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRixJQUFJO0VBQUM7RUFBZ0I7RUFBYTtFQUFVO0VBQWlCO0VBQXFCO0VBQWU7RUFBYztFQUFjO0VBQU07RUFBUztFQUFjO0NBQU0sQ0FBQztBQUNuSztBQUNBLFNBQVMsTUFBTSxPQUFPO0NBQ3BCLE9BQU8sU0FBUyxRQUFRLGFBQWE7QUFDdkM7Ozs7OztBQ3JiQSxTQUFnQixjQUFjLGdCQUFnQixPQUFPLEVBQ25ELFFBQ0Esa0JBQ0EsT0FDQSxNQUNBLFFBQ0EsUUFBUSxTQUNQO0NBQ0QsTUFBTSxRQUFRLEVBQ1osR0FBRyxPQUNMO0NBQ0EsSUFBSSxPQUNGLE1BQU0sZ0JBQWdCO0NBRXhCLE9BQU8saUJBQWlCLE9BQU8sZ0JBQWdCO0VBQzdDO0VBQ0EsS0FBSztFQUNMLE9BQU87R0FBQztJQUNOLE1BQU07SUFDTjtJQUNBO0dBQ0Y7R0FBRyxpQ0FBaUMsZ0JBQWdCO0dBQUc7RUFBSztFQUM1RCx3QkFBd0I7Q0FDMUIsQ0FBQztBQUNIOzs7Ozs7O0FDeEJBLFNBQWdCLGlCQUFpQixPQUFPO0NBQ3RDLE1BQU0sQ0FBQyxPQUFPLFlBQUEsYUFBa0IsU0FBUztFQUN2QyxTQUFTO0VBQ1QsVUFBVTtDQUNaLENBQUM7Q0FDRCxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sTUFBTSxPQUFPLEdBQ2pDLFNBQVM7RUFDUCxTQUFTO0VBQ1QsVUFBVSxNQUFNO0NBQ2xCLENBQUM7Q0FFSCxPQUFPLE1BQU07QUFDZiIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDQsNSw2LDcsOCw5LDEwLDExXX0=