import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/form/submit-button.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Loader2 } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { Button } from "/src/components/ui/button.tsx";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/form/submit-button.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
/** Botão de envio que bloqueia cliques duplos e mostra spinner. */
export function SubmitButton(t0) {
	const $ = _c(16);
	if ($[0] !== "55d8c2dd995e2701bb342b0d8b98c9caec753db1a4eead94013ba4c030017c9c") {
		for (let $i = 0; $i < 16; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "55d8c2dd995e2701bb342b0d8b98c9caec753db1a4eead94013ba4c030017c9c";
	}
	let children;
	let disabled;
	let isPending;
	let props;
	let t1;
	if ($[1] !== t0) {
		({isPending, pendingText: t1, children, disabled, ...props} = t0);
		$[1] = t0;
		$[2] = children;
		$[3] = disabled;
		$[4] = isPending;
		$[5] = props;
		$[6] = t1;
	} else {
		children = $[2];
		disabled = $[3];
		isPending = $[4];
		props = $[5];
		t1 = $[6];
	}
	const pendingText = t1 === undefined ? "Enviando..." : t1;
	const t2 = isPending || disabled;
	let t3;
	if ($[7] !== children || $[8] !== isPending || $[9] !== pendingText) {
		t3 = isPending ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(Loader2, {
			className: "animate-spin motion-reduce:animate-none",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 24
		}, this), pendingText] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 22
		}, this) : children;
		$[7] = children;
		$[8] = isPending;
		$[9] = pendingText;
		$[10] = t3;
	} else {
		t3 = $[10];
	}
	let t4;
	if ($[11] !== isPending || $[12] !== props || $[13] !== t2 || $[14] !== t3) {
		t4 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "submit",
			disabled: t2,
			"aria-busy": isPending,
			...props,
			children: t3
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 59,
			columnNumber: 10
		}, this);
		$[11] = isPending;
		$[12] = props;
		$[13] = t2;
		$[14] = t3;
		$[15] = t4;
	} else {
		t4 = $[15];
	}
	return t4;
}
_c2 = SubmitButton;
var _c2;
$RefreshReg$(_c2, "SubmitButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/form/submit-button.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/form/submit-button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/form/submit-button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/form/submit-button.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUNBLFNBQVNBLGVBQWU7QUFDeEIsU0FBU0MsY0FBYzs7OztBQVF2QixPQUFPLFNBQUFDLGFBQUFDLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBSztDQUFBLElBQUFDO0NBQUEsSUFBQUM7Q0FBQSxJQUFBQztDQUFBLElBQUFDO0NBQUEsSUFBQVQsRUFBQSxPQUFBRCxJQUFBO0VBQXNCLEVBQUFRLFdBQUFHLGFBQUFELElBQUFKLFVBQUFDLFVBQUEsR0FBQUUsU0FBQVQ7RUFBMkZDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBUTtFQUFBUixFQUFBLEtBQUFTO0NBQUE7RUFBQUosV0FBQUwsRUFBQTtFQUFBTSxXQUFBTixFQUFBO0VBQUFPLFlBQUFQLEVBQUE7RUFBQVEsUUFBQVIsRUFBQTtFQUFBUyxLQUFBVCxFQUFBO0NBQUE7Q0FBOUUsTUFBQVUsY0FBQUQsT0FBQUUsWUFBQSxnQkFBQUY7Q0FFTixNQUFBRyxLQUFBTCxhQUFBRDtDQUFxQixJQUFBTztDQUFBLElBQUFiLEVBQUEsT0FBQUssWUFBQUwsRUFBQSxPQUFBTyxhQUFBUCxFQUFBLE9BQUFVLGFBQUE7RUFDbERHLEtBQUFOLFlBQUEsZ0RBRUcsd0JBQUMsU0FBRDtHQUFtQjtHQUFzRDtFQUFNOzs7O1lBQzlFRyxXQUFXOzs7O2FBSGZMO0VBT0FMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTztFQUFBUCxFQUFBLEtBQUFVO0VBQUFWLEVBQUEsTUFBQWE7Q0FBQTtFQUFBQSxLQUFBYixFQUFBO0NBQUE7Q0FBQSxJQUFBYztDQUFBLElBQUFkLEVBQUEsUUFBQU8sYUFBQVAsRUFBQSxRQUFBUSxTQUFBUixFQUFBLFFBQUFZLE1BQUFaLEVBQUEsUUFBQWEsSUFBQTtFQVJIQyxLQUFBLHdCQUFDLFFBQUQ7R0FBYTtHQUFtQixVQUFBRjtHQUFrQ0w7R0FBUyxHQUFNQzthQUM5RUs7RUFESTs7Ozs7RUFTRWIsRUFBQSxNQUFBTztFQUFBUCxFQUFBLE1BQUFRO0VBQUFSLEVBQUEsTUFBQVk7RUFBQVosRUFBQSxNQUFBYTtFQUFBYixFQUFBLE1BQUFjO0NBQUE7RUFBQUEsS0FBQWQsRUFBQTtDQUFBO0NBQUEsT0FUVGM7QUFTUyIsIm5hbWVzIjpbIkxvYWRlcjIiLCJCdXR0b24iLCJTdWJtaXRCdXR0b24iLCJ0MCIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwiY2hpbGRyZW4iLCJkaXNhYmxlZCIsImlzUGVuZGluZyIsInByb3BzIiwidDEiLCJwZW5kaW5nVGV4dCIsInVuZGVmaW5lZCIsInQyIiwidDMiLCJ0NCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJzdWJtaXQtYnV0dG9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgdHlwZSB7IENvbXBvbmVudFByb3BzIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBMb2FkZXIyIH0gZnJvbSAnbHVjaWRlLXJlYWN0J1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcblxuaW50ZXJmYWNlIFN1Ym1pdEJ1dHRvblByb3BzIGV4dGVuZHMgQ29tcG9uZW50UHJvcHM8dHlwZW9mIEJ1dHRvbj4ge1xuICBpc1BlbmRpbmc6IGJvb2xlYW5cbiAgcGVuZGluZ1RleHQ/OiBzdHJpbmdcbn1cblxuLyoqIEJvdMOjbyBkZSBlbnZpbyBxdWUgYmxvcXVlaWEgY2xpcXVlcyBkdXBsb3MgZSBtb3N0cmEgc3Bpbm5lci4gKi9cbmV4cG9ydCBmdW5jdGlvbiBTdWJtaXRCdXR0b24oeyBpc1BlbmRpbmcsIHBlbmRpbmdUZXh0ID0gJ0VudmlhbmRvLi4uJywgY2hpbGRyZW4sIGRpc2FibGVkLCAuLi5wcm9wcyB9OiBTdWJtaXRCdXR0b25Qcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxCdXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXtpc1BlbmRpbmcgfHwgZGlzYWJsZWR9IGFyaWEtYnVzeT17aXNQZW5kaW5nfSB7Li4ucHJvcHN9PlxuICAgICAge2lzUGVuZGluZyA/IChcbiAgICAgICAgPD5cbiAgICAgICAgICA8TG9hZGVyMiBjbGFzc05hbWU9XCJhbmltYXRlLXNwaW4gbW90aW9uLXJlZHVjZTphbmltYXRlLW5vbmVcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgIHtwZW5kaW5nVGV4dH1cbiAgICAgICAgPC8+XG4gICAgICApIDogKFxuICAgICAgICBjaGlsZHJlblxuICAgICAgKX1cbiAgICA8L0J1dHRvbj5cbiAgKVxufVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvY29tcG9uZW50cy9mb3JtL3N1Ym1pdC1idXR0b24udHN4In0=