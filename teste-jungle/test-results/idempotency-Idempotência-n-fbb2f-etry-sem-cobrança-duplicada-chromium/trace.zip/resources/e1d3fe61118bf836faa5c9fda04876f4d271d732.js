const _c = __vite__cjsImport0_react_compilerRuntime["c"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { queryOptions, useMutation, useQuery, useQueryClient } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=e9f94b2e";
import { toast } from "/node_modules/.vite/deps/sonner.js?v=e9f94b2e";
import { getErrorMessage } from "/src/lib/api.ts";
import { calculateCartTotals } from "/src/lib/eth.ts";
import { queryKeys } from "/src/lib/query-keys.ts";
import { useIsAuthenticated } from "/src/lib/session.ts";
import { cartService } from "/src/services/cart.service.ts";
export const cartQueryOptions = queryOptions({
	queryKey: queryKeys.cart.all,
	queryFn: cartService.getCart,
	staleTime: 3e4
});
export function useCart() {
	const $ = _c(3);
	if ($[0] !== "adde3347c4e6599877252af543cad9736baec95b27babcd887d2aceb6018226b") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "adde3347c4e6599877252af543cad9736baec95b27babcd887d2aceb6018226b";
	}
	const isAuthenticated = useIsAuthenticated();
	let t0;
	if ($[1] !== isAuthenticated) {
		t0 = {
			...cartQueryOptions,
			enabled: isAuthenticated
		};
		$[1] = isAuthenticated;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return useQuery(t0);
}
function recalculateOptimisticCart(cart, nextItems) {
	const totalItems = nextItems.reduce((sum, item) => sum + item.quantity, 0);
	const discountPercent = nextItems.length > 0 ? cart.discountPercent : 0;
	const couponCode = nextItems.length > 0 ? cart.couponCode : null;
	const totals = calculateCartTotals(nextItems, discountPercent);
	return {
		items: nextItems,
		totalItems,
		couponCode,
		discountPercent,
		...totals
	};
}
/**
* Adiciona um NFT ao carrinho com Optimistic Update completo:
* - onMutate: cancela queries, faz snapshot do carrinho, injeta o item e recalcula Subtotal/Desconto/Taxa/Total em ETH via Decimal
* - onError: faz rollback para o snapshot anterior e dispara toast.error
* - onSettled: invalida a query do carrinho para sincronizar com o MSW
*/
export function useAddToCart() {
	const $ = _c(3);
	if ($[0] !== "adde3347c4e6599877252af543cad9736baec95b27babcd887d2aceb6018226b") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "adde3347c4e6599877252af543cad9736baec95b27babcd887d2aceb6018226b";
	}
	const queryClient = useQueryClient();
	const key = queryKeys.cart.all;
	let t0;
	if ($[1] !== queryClient) {
		t0 = {
			mutationFn: _temp,
			onMutate: async (t1) => {
				const { nft: nft_0, quantity: t2 } = t1;
				const quantity_0 = t2 === undefined ? 1 : t2;
				await queryClient.cancelQueries({ queryKey: key });
				const previous = queryClient.getQueryData(key);
				if (previous) {
					const existingIndex = previous.items.findIndex((i) => i.nftId === nft_0.id);
					const nextItems = [...previous.items];
					if (existingIndex >= 0) {
						const current = nextItems[existingIndex];
						nextItems[existingIndex] = {
							...current,
							quantity: Math.min(10, current.quantity + quantity_0)
						};
					} else {
						nextItems.push({
							id: `optimistic-${nft_0.id}`,
							userId: "current",
							nftId: nft_0.id,
							name: nft_0.name,
							imageUrl: nft_0.imageUrl,
							collection: nft_0.collection,
							creatorName: nft_0.creatorName,
							priceEth: nft_0.priceEth,
							quantity: quantity_0,
							addedAt: new Date().toISOString()
						});
					}
					queryClient.setQueryData(key, recalculateOptimisticCart(previous, nextItems));
				}
				return { previous };
			},
			onSuccess: (data, t3) => {
				const { nft: nft_1 } = t3;
				queryClient.setQueryData(key, data);
				toast.success(`"${nft_1.name}" adicionado ao carrinho.`);
			},
			onError: (error, _vars, context) => {
				if (context?.previous) {
					queryClient.setQueryData(key, context.previous);
				}
				toast.error(getErrorMessage(error));
			},
			onSettled: () => {
				queryClient.invalidateQueries({ queryKey: key });
			}
		};
		$[1] = queryClient;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return useMutation(t0);
}
/**
* Altera a quantidade de um item do carrinho com Optimistic Update e recálculo imediato em ETH.
*/
function _temp(t0) {
	const { nft, quantity: t1 } = t0;
	const quantity = t1 === undefined ? 1 : t1;
	return cartService.addItem({
		nftId: nft.id,
		quantity
	});
}
export function useUpdateCartItemQuantity() {
	const $ = _c(3);
	if ($[0] !== "adde3347c4e6599877252af543cad9736baec95b27babcd887d2aceb6018226b") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "adde3347c4e6599877252af543cad9736baec95b27babcd887d2aceb6018226b";
	}
	const queryClient = useQueryClient();
	const key = queryKeys.cart.all;
	let t0;
	if ($[1] !== queryClient) {
		t0 = {
			mutationFn: cartService.updateItemQuantity,
			onMutate: async (t1) => {
				const { itemId, quantity } = t1;
				await queryClient.cancelQueries({ queryKey: key });
				const previous = queryClient.getQueryData(key);
				if (previous) {
					const nextItems = quantity <= 0 ? previous.items.filter((i) => i.id !== itemId) : previous.items.map((i_0) => i_0.id === itemId ? {
						...i_0,
						quantity: Math.min(10, quantity)
					} : i_0);
					queryClient.setQueryData(key, recalculateOptimisticCart(previous, nextItems));
				}
				return { previous };
			},
			onError: (error, _vars, context) => {
				if (context?.previous) {
					queryClient.setQueryData(key, context.previous);
				}
				toast.error(getErrorMessage(error));
			},
			onSettled: () => {
				queryClient.invalidateQueries({ queryKey: key });
			}
		};
		$[1] = queryClient;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return useMutation(t0);
}
/**
* Remove um item do carrinho com Optimistic Update, rollback em erro e sincronização em onSettled.
*/
export function useRemoveCartItem() {
	const $ = _c(10);
	if ($[0] !== "adde3347c4e6599877252af543cad9736baec95b27babcd887d2aceb6018226b") {
		for (let $i = 0; $i < 10; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "adde3347c4e6599877252af543cad9736baec95b27babcd887d2aceb6018226b";
	}
	const queryClient = useQueryClient();
	const key = queryKeys.cart.all;
	let t0;
	if ($[1] !== queryClient) {
		t0 = async (itemId) => {
			await queryClient.cancelQueries({ queryKey: key });
			const previous = queryClient.getQueryData(key);
			if (previous) {
				const nextItems = previous.items.filter((i) => i.id !== itemId);
				queryClient.setQueryData(key, recalculateOptimisticCart(previous, nextItems));
			}
			return { previous };
		};
		$[1] = queryClient;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	let t1;
	let t2;
	if ($[3] !== queryClient) {
		t1 = (error, _itemId, context) => {
			if (context?.previous) {
				queryClient.setQueryData(key, context.previous);
			}
			toast.error(getErrorMessage(error));
		};
		t2 = () => {
			queryClient.invalidateQueries({ queryKey: key });
		};
		$[3] = queryClient;
		$[4] = t1;
		$[5] = t2;
	} else {
		t1 = $[4];
		t2 = $[5];
	}
	let t3;
	if ($[6] !== t0 || $[7] !== t1 || $[8] !== t2) {
		t3 = {
			mutationFn: cartService.removeItem,
			onMutate: t0,
			onSuccess: _temp2,
			onError: t1,
			onSettled: t2
		};
		$[6] = t0;
		$[7] = t1;
		$[8] = t2;
		$[9] = t3;
	} else {
		t3 = $[9];
	}
	return useMutation(t3);
}
function _temp2() {
	toast.success("Item removido do carrinho.");
}
export function useApplyCoupon() {
	const $ = _c(3);
	if ($[0] !== "adde3347c4e6599877252af543cad9736baec95b27babcd887d2aceb6018226b") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "adde3347c4e6599877252af543cad9736baec95b27babcd887d2aceb6018226b";
	}
	const queryClient = useQueryClient();
	const key = queryKeys.cart.all;
	let t0;
	if ($[1] !== queryClient) {
		t0 = {
			mutationFn: cartService.applyCoupon,
			onSuccess: (data) => {
				queryClient.setQueryData(key, data);
				toast.success(`Cupom ${data.couponCode} (${data.discountPercent}% OFF) aplicado!`);
			}
		};
		$[1] = queryClient;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return useMutation(t0);
}
export function useRemoveCoupon() {
	const $ = _c(3);
	if ($[0] !== "adde3347c4e6599877252af543cad9736baec95b27babcd887d2aceb6018226b") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "adde3347c4e6599877252af543cad9736baec95b27babcd887d2aceb6018226b";
	}
	const queryClient = useQueryClient();
	const key = queryKeys.cart.all;
	let t0;
	if ($[1] !== queryClient) {
		t0 = {
			mutationFn: cartService.removeCoupon,
			onSuccess: (data) => {
				queryClient.setQueryData(key, data);
				toast.success("Cupom removido.");
			},
			onError: _temp3
		};
		$[1] = queryClient;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return useMutation(t0);
}
function _temp3(error) {
	toast.error(getErrorMessage(error));
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGNBQWNDLGFBQWFDLFVBQVVDLHNCQUFzQjtBQUNwRSxTQUFTQyxhQUFhO0FBQ3RCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQywyQkFBMkI7QUFDcEMsU0FBU0MsaUJBQWlCO0FBQzFCLFNBQVNDLDBCQUEwQjtBQUNuQyxTQUFTQyxtQkFBbUI7QUFJNUIsT0FBTyxNQUFNQyxtQkFBbUJWLGFBQWE7Q0FDM0NXLFVBQVVKLFVBQVVLLEtBQUtDO0NBQ3pCQyxTQUFTTCxZQUFZTTtDQUNyQkMsV0FBVztBQUNiLENBQUM7QUFFRCxPQUFPLFNBQUFDLFVBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FDTCxNQUFBSyxrQkFBd0JmLG1CQUFtQjtDQUFDLElBQUFnQjtDQUFBLElBQUFOLEVBQUEsT0FBQUssaUJBQUE7RUFDNUJDLEtBQUE7R0FBQSxHQUNYZDtHQUFnQmUsU0FDVkY7RUFDWDtFQUFDTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxPQUhNaEIsU0FBU3NCLEVBR2Y7QUFBQztBQUdKLFNBQVNFLDBCQUEwQmQsTUFBb0JlLFdBQXFDO0NBQzFGLE1BQU1DLGFBQWFELFVBQVVFLFFBQVFDLEtBQUtDLFNBQVNELE1BQU1DLEtBQUtDLFVBQVUsQ0FBQztDQUN6RSxNQUFNQyxrQkFBa0JOLFVBQVVPLFNBQVMsSUFBSXRCLEtBQUtxQixrQkFBa0I7Q0FDdEUsTUFBTUUsYUFBYVIsVUFBVU8sU0FBUyxJQUFJdEIsS0FBS3VCLGFBQWE7Q0FDNUQsTUFBTUMsU0FBUzlCLG9CQUFvQnFCLFdBQVdNLGVBQWU7Q0FFN0QsT0FBTztFQUNMSSxPQUFPVjtFQUNQQztFQUNBTztFQUNBRjtFQUNBLEdBQUdHO0NBQ0w7QUFDRjs7Ozs7OztBQWFBLE9BQU8sU0FBQUUsZUFBQTtDQUFBLE1BQUFwQixJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FDTCxNQUFBcUIsY0FBb0JwQyxlQUFlO0NBQ25DLE1BQUFxQyxNQUFZakMsVUFBU0ssS0FBS0M7Q0FBSSxJQUFBVztDQUFBLElBQUFOLEVBQUEsT0FBQXFCLGFBQUE7RUFFWGYsS0FBQTtHQUFBaUIsWUFDTEM7R0FDc0NDLFVBQ3hDLE9BQUFDLE9BQUE7SUFBTyxRQUFBQyxLQUFBQyxPQUFBZCxVQUFBZSxPQUFBSDtJQUFPLE1BQUFJLGFBQUFELE9BQUFFLFlBQUEsSUFBQUY7SUFDdEIsTUFBTVIsWUFBV1csY0FBZSxFQUFBdkMsVUFBWTZCLElBQUksQ0FBQztJQUNqRCxNQUFBVyxXQUFpQlosWUFBV2EsYUFBNEJaLEdBQUc7SUFFM0QsSUFBSVcsVUFBUTtLQUNWLE1BQUFFLGdCQUFzQkYsU0FBUWQsTUFBTWlCLFdBQVdDLE1BQU9BLEVBQUNDLFVBQVdYLE1BQUdZLEVBQUc7S0FDeEUsTUFBQTlCLFlBQWtCLElBQUl3QixTQUFRZCxLQUFNO0tBRXBDLElBQUlnQixpQkFBaUIsR0FBQztNQUNwQixNQUFBSyxVQUFnQi9CLFVBQVUwQjtNQUMxQjFCLFVBQVUwQixpQkFBaUI7T0FBQSxHQUN0Qks7T0FBTzFCLFVBQ0EyQixLQUFJQyxJQUFLLElBQUlGLFFBQU8xQixXQUFZQSxVQUFRO01BQ3BEO0tBSHdCO01BS3hCTCxVQUFTa0MsS0FBTTtPQUFBSixJQUNULGNBQWNaLE1BQUdZO09BQUtLLFFBQ2xCO09BQVNOLE9BQ1ZYLE1BQUdZO09BQUdNLE1BQ1BsQixNQUFHa0I7T0FBS0MsVUFDSm5CLE1BQUdtQjtPQUFTQyxZQUNWcEIsTUFBR29CO09BQVdDLGFBQ2JyQixNQUFHcUI7T0FBWUMsVUFDbEJ0QixNQUFHc0I7T0FBU25DLFVBQ3RCQTtPQUFRb0MsU0FDQyxJQUFJQyxLQUFLLENBQUMsQ0FBQUMsWUFBYTtNQUNsQyxDQUFDO0tBQUM7S0FHSi9CLFlBQVdnQyxhQUE0Qi9CLEtBQUtkLDBCQUEwQnlCLFVBQVV4QixTQUFTLENBQUM7SUFBQztJQUM1RixPQUVNLEVBQUF3QixTQUFXO0dBQUM7R0FDcEJxQixZQUNVQyxNQUFBQyxPQUFBO0lBQU8sUUFBQTdCLEtBQUE4QixVQUFBRDtJQUNoQm5DLFlBQVdnQyxhQUFjL0IsS0FBS2lDLElBQUk7SUFDbENyRSxNQUFLd0UsUUFBUyxJQUFJL0IsTUFBR2tCLEtBQUssMEJBQTJCO0dBQUM7R0FDdkRjLFVBQ1FDLE9BQUFDLE9BQUFDLFlBQUE7SUFDUCxJQUFJQSxTQUFPN0IsVUFBVTtLQUFFWixZQUFXZ0MsYUFBYy9CLEtBQUt3QyxRQUFPN0IsUUFBUztJQUFDO0lBQ3RFL0MsTUFBSzBFLE1BQU96RSxnQkFBZ0J5RSxLQUFLLENBQUM7R0FBQztHQUNwQ0csaUJBQ1U7SUFDSjFDLFlBQVcyQyxrQkFBbUIsRUFBQXZFLFVBQVk2QixJQUFJLENBQUM7R0FBQztFQUV6RDtFQUFDdEIsRUFBQSxLQUFBcUI7RUFBQXJCLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxPQWhETWpCLFlBQVl1QixFQWdEbEI7QUFBQzs7OztBQXBERyxTQUFBa0IsTUFBQWxCLElBQUE7Q0FLVSxRQUFBcUIsS0FBQWIsVUFBQVksT0FBQXBCO0NBQU8sTUFBQVEsV0FBQVksT0FBQUssWUFBQSxJQUFBTDtDQUFZLE9BQzlCbkMsWUFBVzBFLFFBQVM7RUFBQTNCLE9BQVNYLElBQUdZO0VBQUd6QjtDQUFXLENBQUM7QUFBQztBQW9EdEQsT0FBTyxTQUFBb0QsNEJBQUE7Q0FBQSxNQUFBbEUsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQ0wsTUFBQXFCLGNBQW9CcEMsZUFBZTtDQUNuQyxNQUFBcUMsTUFBWWpDLFVBQVNLLEtBQUtDO0NBQUksSUFBQVc7Q0FBQSxJQUFBTixFQUFBLE9BQUFxQixhQUFBO0VBRVhmLEtBQUE7R0FBQWlCLFlBQ0xoQyxZQUFXNEU7R0FBbUIxQyxVQUNoQyxPQUFBQyxPQUFBO0lBQU8sUUFBQTBDLFFBQUF0RCxhQUFBWTtJQUNmLE1BQU1MLFlBQVdXLGNBQWUsRUFBQXZDLFVBQVk2QixJQUFJLENBQUM7SUFDakQsTUFBQVcsV0FBaUJaLFlBQVdhLGFBQTRCWixHQUFHO0lBRTNELElBQUlXLFVBQVE7S0FDVixNQUFBeEIsWUFDRUssWUFBWSxJQUNSbUIsU0FBUWQsTUFBTWtELFFBQVFoQyxNQUFPQSxFQUFDRSxPQUFRNkIsTUFHdEMsSUFGQW5DLFNBQVFkLE1BQU1tRCxLQUFLQyxRQUNqQmxDLElBQUNFLE9BQVE2QixTQUFUO01BQUEsR0FBdUIvQjtNQUFDdkIsVUFBWTJCLEtBQUlDLElBQUssSUFBSTVCLFFBQVE7S0FBTSxJQUEvRHlELEdBQ0Y7S0FFTmxELFlBQVdnQyxhQUE0Qi9CLEtBQUtkLDBCQUEwQnlCLFVBQVV4QixTQUFTLENBQUM7SUFBQztJQUM1RixPQUVNLEVBQUF3QixTQUFXO0dBQUM7R0FDcEIwQixVQUNRQyxPQUFBQyxPQUFBQyxZQUFBO0lBQ1AsSUFBSUEsU0FBTzdCLFVBQVU7S0FBRVosWUFBV2dDLGFBQWMvQixLQUFLd0MsUUFBTzdCLFFBQVM7SUFBQztJQUN0RS9DLE1BQUswRSxNQUFPekUsZ0JBQWdCeUUsS0FBSyxDQUFDO0dBQUM7R0FDcENHLGlCQUNVO0lBQ0oxQyxZQUFXMkMsa0JBQW1CLEVBQUF2RSxVQUFZNkIsSUFBSSxDQUFDO0dBQUM7RUFFekQ7RUFBQ3RCLEVBQUEsS0FBQXFCO0VBQUFyQixFQUFBLEtBQUFNO0NBQUE7RUFBQUEsS0FBQU4sRUFBQTtDQUFBO0NBQUEsT0ExQk1qQixZQUFZdUIsRUEwQmxCO0FBQUM7Ozs7QUFNSixPQUFPLFNBQUFrRSxvQkFBQTtDQUFBLE1BQUF4RSxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FDTCxNQUFBcUIsY0FBb0JwQyxlQUFlO0NBQ25DLE1BQUFxQyxNQUFZakMsVUFBU0ssS0FBS0M7Q0FBSSxJQUFBVztDQUFBLElBQUFOLEVBQUEsT0FBQXFCLGFBQUE7RUFJbEJmLEtBQUEsT0FBQThELFdBQUE7R0FDUixNQUFNL0MsWUFBV1csY0FBZSxFQUFBdkMsVUFBWTZCLElBQUksQ0FBQztHQUNqRCxNQUFBVyxXQUFpQlosWUFBV2EsYUFBNEJaLEdBQUc7R0FFM0QsSUFBSVcsVUFBUTtJQUNWLE1BQUF4QixZQUFrQndCLFNBQVFkLE1BQU1rRCxRQUFRaEMsTUFBT0EsRUFBQ0UsT0FBUTZCLE1BQU07SUFDOUQvQyxZQUFXZ0MsYUFBNEIvQixLQUFLZCwwQkFBMEJ5QixVQUFVeEIsU0FBUyxDQUFDO0dBQUM7R0FDNUYsT0FFTSxFQUFBd0IsU0FBVztFQUFDO0VBQ3BCakMsRUFBQSxLQUFBcUI7RUFBQXJCLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxJQUFBMEI7Q0FBQSxJQUFBRztDQUFBLElBQUE3QixFQUFBLE9BQUFxQixhQUFBO0VBSVFLLE1BQUFrQyxPQUFBYSxTQUFBWCxZQUFBO0dBQ1AsSUFBSUEsU0FBTzdCLFVBQVU7SUFBRVosWUFBV2dDLGFBQWMvQixLQUFLd0MsUUFBTzdCLFFBQVM7R0FBQztHQUN0RS9DLE1BQUswRSxNQUFPekUsZ0JBQWdCeUUsS0FBSyxDQUFDO0VBQUM7RUFFMUIvQixXQUFBO0dBQ0pSLFlBQVcyQyxrQkFBbUIsRUFBQXZFLFVBQVk2QixJQUFJLENBQUM7RUFBQztFQUN0RHRCLEVBQUEsS0FBQXFCO0VBQUFyQixFQUFBLEtBQUEwQjtFQUFBMUIsRUFBQSxLQUFBNkI7Q0FBQTtFQUFBSCxLQUFBMUIsRUFBQTtFQUFBNkIsS0FBQTdCLEVBQUE7Q0FBQTtDQUFBLElBQUF3RDtDQUFBLElBQUF4RCxFQUFBLE9BQUFNLE1BQUFOLEVBQUEsT0FBQTBCLE1BQUExQixFQUFBLE9BQUE2QixJQUFBO0VBdEJnQjJCLEtBQUE7R0FBQWpDLFlBQ0xoQyxZQUFXbUY7R0FBV2pELFVBQ3hCbkI7R0FVVGdELFdBQ1VxQjtHQUVWaEIsU0FDUWpDO0dBR1JxQyxXQUNVbEM7RUFHYjtFQUFDN0IsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUEwQjtFQUFBMUIsRUFBQSxLQUFBNkI7RUFBQTdCLEVBQUEsS0FBQXdEO0NBQUE7RUFBQUEsS0FBQXhELEVBQUE7Q0FBQTtDQUFBLE9BdkJNakIsWUFBWXlFLEVBdUJsQjtBQUFDO0FBM0JHLFNBQUFtQixTQUFBO0NBa0JEekYsTUFBS3dFLFFBQVMsNEJBQTRCO0FBQUM7QUFZakQsT0FBTyxTQUFBa0IsaUJBQUE7Q0FBQSxNQUFBNUUsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQ0wsTUFBQXFCLGNBQW9CcEMsZUFBZTtDQUNuQyxNQUFBcUMsTUFBWWpDLFVBQVNLLEtBQUtDO0NBQUksSUFBQVc7Q0FBQSxJQUFBTixFQUFBLE9BQUFxQixhQUFBO0VBRVhmLEtBQUE7R0FBQWlCLFlBQ0xoQyxZQUFXc0Y7R0FBWXZCLFlBQ3hCQyxTQUFBO0lBQ1RsQyxZQUFXZ0MsYUFBYy9CLEtBQUtpQyxJQUFJO0lBQ2xDckUsTUFBS3dFLFFBQVMsU0FBU0gsS0FBSXRDLFdBQVcsSUFBS3NDLEtBQUl4QyxnQkFBZ0IsaUJBQWtCO0dBQUM7RUFFdEY7RUFBQ2YsRUFBQSxLQUFBcUI7RUFBQXJCLEVBQUEsS0FBQU07Q0FBQTtFQUFBQSxLQUFBTixFQUFBO0NBQUE7Q0FBQSxPQU5NakIsWUFBWXVCLEVBTWxCO0FBQUM7QUFHSixPQUFPLFNBQUF3RSxrQkFBQTtDQUFBLE1BQUE5RSxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FDTCxNQUFBcUIsY0FBb0JwQyxlQUFlO0NBQ25DLE1BQUFxQyxNQUFZakMsVUFBU0ssS0FBS0M7Q0FBSSxJQUFBVztDQUFBLElBQUFOLEVBQUEsT0FBQXFCLGFBQUE7RUFFWGYsS0FBQTtHQUFBaUIsWUFDTGhDLFlBQVd3RjtHQUFhekIsWUFDekJDLFNBQUE7SUFDVGxDLFlBQVdnQyxhQUFjL0IsS0FBS2lDLElBQUk7SUFDbENyRSxNQUFLd0UsUUFBUyxpQkFBaUI7R0FBQztHQUNqQ0MsU0FDUXFCO0VBR1g7RUFBQ2hGLEVBQUEsS0FBQXFCO0VBQUFyQixFQUFBLEtBQUFNO0NBQUE7RUFBQUEsS0FBQU4sRUFBQTtDQUFBO0NBQUEsT0FUTWpCLFlBQVl1QixFQVNsQjtBQUFDO0FBYkcsU0FBQTBFLE9BQUFwQixPQUFBO0NBV0QxRSxNQUFLMEUsTUFBT3pFLGdCQUFnQnlFLEtBQUssQ0FBQztBQUFDIiwibmFtZXMiOlsicXVlcnlPcHRpb25zIiwidXNlTXV0YXRpb24iLCJ1c2VRdWVyeSIsInVzZVF1ZXJ5Q2xpZW50IiwidG9hc3QiLCJnZXRFcnJvck1lc3NhZ2UiLCJjYWxjdWxhdGVDYXJ0VG90YWxzIiwicXVlcnlLZXlzIiwidXNlSXNBdXRoZW50aWNhdGVkIiwiY2FydFNlcnZpY2UiLCJjYXJ0UXVlcnlPcHRpb25zIiwicXVlcnlLZXkiLCJjYXJ0IiwiYWxsIiwicXVlcnlGbiIsImdldENhcnQiLCJzdGFsZVRpbWUiLCJ1c2VDYXJ0IiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJpc0F1dGhlbnRpY2F0ZWQiLCJ0MCIsImVuYWJsZWQiLCJyZWNhbGN1bGF0ZU9wdGltaXN0aWNDYXJ0IiwibmV4dEl0ZW1zIiwidG90YWxJdGVtcyIsInJlZHVjZSIsInN1bSIsIml0ZW0iLCJxdWFudGl0eSIsImRpc2NvdW50UGVyY2VudCIsImxlbmd0aCIsImNvdXBvbkNvZGUiLCJ0b3RhbHMiLCJpdGVtcyIsInVzZUFkZFRvQ2FydCIsInF1ZXJ5Q2xpZW50Iiwia2V5IiwibXV0YXRpb25GbiIsIl90ZW1wIiwib25NdXRhdGUiLCJ0MSIsIm5mdCIsIm5mdF8wIiwidDIiLCJxdWFudGl0eV8wIiwidW5kZWZpbmVkIiwiY2FuY2VsUXVlcmllcyIsInByZXZpb3VzIiwiZ2V0UXVlcnlEYXRhIiwiZXhpc3RpbmdJbmRleCIsImZpbmRJbmRleCIsImkiLCJuZnRJZCIsImlkIiwiY3VycmVudCIsIk1hdGgiLCJtaW4iLCJwdXNoIiwidXNlcklkIiwibmFtZSIsImltYWdlVXJsIiwiY29sbGVjdGlvbiIsImNyZWF0b3JOYW1lIiwicHJpY2VFdGgiLCJhZGRlZEF0IiwiRGF0ZSIsInRvSVNPU3RyaW5nIiwic2V0UXVlcnlEYXRhIiwib25TdWNjZXNzIiwiZGF0YSIsInQzIiwibmZ0XzEiLCJzdWNjZXNzIiwib25FcnJvciIsImVycm9yIiwiX3ZhcnMiLCJjb250ZXh0Iiwib25TZXR0bGVkIiwiaW52YWxpZGF0ZVF1ZXJpZXMiLCJhZGRJdGVtIiwidXNlVXBkYXRlQ2FydEl0ZW1RdWFudGl0eSIsInVwZGF0ZUl0ZW1RdWFudGl0eSIsIml0ZW1JZCIsImZpbHRlciIsIm1hcCIsImlfMCIsInVzZVJlbW92ZUNhcnRJdGVtIiwiX2l0ZW1JZCIsInJlbW92ZUl0ZW0iLCJfdGVtcDIiLCJ1c2VBcHBseUNvdXBvbiIsImFwcGx5Q291cG9uIiwidXNlUmVtb3ZlQ291cG9uIiwicmVtb3ZlQ291cG9uIiwiX3RlbXAzIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInVzZS1jYXJ0LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHF1ZXJ5T3B0aW9ucywgdXNlTXV0YXRpb24sIHVzZVF1ZXJ5LCB1c2VRdWVyeUNsaWVudCB9IGZyb20gJ0B0YW5zdGFjay9yZWFjdC1xdWVyeSdcbmltcG9ydCB7IHRvYXN0IH0gZnJvbSAnc29ubmVyJ1xuaW1wb3J0IHsgZ2V0RXJyb3JNZXNzYWdlIH0gZnJvbSAnQC9saWIvYXBpJ1xuaW1wb3J0IHsgY2FsY3VsYXRlQ2FydFRvdGFscyB9IGZyb20gJ0AvbGliL2V0aCdcbmltcG9ydCB7IHF1ZXJ5S2V5cyB9IGZyb20gJ0AvbGliL3F1ZXJ5LWtleXMnXG5pbXBvcnQgeyB1c2VJc0F1dGhlbnRpY2F0ZWQgfSBmcm9tICdAL2xpYi9zZXNzaW9uJ1xuaW1wb3J0IHsgY2FydFNlcnZpY2UgfSBmcm9tICdAL3NlcnZpY2VzL2NhcnQuc2VydmljZSdcbmltcG9ydCB0eXBlIHsgQ2FydFJlc3BvbnNlIH0gZnJvbSAnQC90eXBlcy9hcGknXG5pbXBvcnQgdHlwZSB7IENhcnRJdGVtLCBORlQgfSBmcm9tICdAL3R5cGVzL21vZGVscydcblxuZXhwb3J0IGNvbnN0IGNhcnRRdWVyeU9wdGlvbnMgPSBxdWVyeU9wdGlvbnMoe1xuICBxdWVyeUtleTogcXVlcnlLZXlzLmNhcnQuYWxsLFxuICBxdWVyeUZuOiBjYXJ0U2VydmljZS5nZXRDYXJ0LFxuICBzdGFsZVRpbWU6IDMwXzAwMCxcbn0pXG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VDYXJ0KCkge1xuICBjb25zdCBpc0F1dGhlbnRpY2F0ZWQgPSB1c2VJc0F1dGhlbnRpY2F0ZWQoKVxuICByZXR1cm4gdXNlUXVlcnkoe1xuICAgIC4uLmNhcnRRdWVyeU9wdGlvbnMsXG4gICAgZW5hYmxlZDogaXNBdXRoZW50aWNhdGVkLFxuICB9KVxufVxuXG5mdW5jdGlvbiByZWNhbGN1bGF0ZU9wdGltaXN0aWNDYXJ0KGNhcnQ6IENhcnRSZXNwb25zZSwgbmV4dEl0ZW1zOiBDYXJ0SXRlbVtdKTogQ2FydFJlc3BvbnNlIHtcbiAgY29uc3QgdG90YWxJdGVtcyA9IG5leHRJdGVtcy5yZWR1Y2UoKHN1bSwgaXRlbSkgPT4gc3VtICsgaXRlbS5xdWFudGl0eSwgMClcbiAgY29uc3QgZGlzY291bnRQZXJjZW50ID0gbmV4dEl0ZW1zLmxlbmd0aCA+IDAgPyBjYXJ0LmRpc2NvdW50UGVyY2VudCA6IDBcbiAgY29uc3QgY291cG9uQ29kZSA9IG5leHRJdGVtcy5sZW5ndGggPiAwID8gY2FydC5jb3Vwb25Db2RlIDogbnVsbFxuICBjb25zdCB0b3RhbHMgPSBjYWxjdWxhdGVDYXJ0VG90YWxzKG5leHRJdGVtcywgZGlzY291bnRQZXJjZW50KVxuXG4gIHJldHVybiB7XG4gICAgaXRlbXM6IG5leHRJdGVtcyxcbiAgICB0b3RhbEl0ZW1zLFxuICAgIGNvdXBvbkNvZGUsXG4gICAgZGlzY291bnRQZXJjZW50LFxuICAgIC4uLnRvdGFscyxcbiAgfVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIEFkZFRvQ2FydElucHV0IHtcbiAgbmZ0OiBORlRcbiAgcXVhbnRpdHk/OiBudW1iZXJcbn1cblxuLyoqXG4gKiBBZGljaW9uYSB1bSBORlQgYW8gY2FycmluaG8gY29tIE9wdGltaXN0aWMgVXBkYXRlIGNvbXBsZXRvOlxuICogLSBvbk11dGF0ZTogY2FuY2VsYSBxdWVyaWVzLCBmYXogc25hcHNob3QgZG8gY2FycmluaG8sIGluamV0YSBvIGl0ZW0gZSByZWNhbGN1bGEgU3VidG90YWwvRGVzY29udG8vVGF4YS9Ub3RhbCBlbSBFVEggdmlhIERlY2ltYWxcbiAqIC0gb25FcnJvcjogZmF6IHJvbGxiYWNrIHBhcmEgbyBzbmFwc2hvdCBhbnRlcmlvciBlIGRpc3BhcmEgdG9hc3QuZXJyb3JcbiAqIC0gb25TZXR0bGVkOiBpbnZhbGlkYSBhIHF1ZXJ5IGRvIGNhcnJpbmhvIHBhcmEgc2luY3Jvbml6YXIgY29tIG8gTVNXXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB1c2VBZGRUb0NhcnQoKSB7XG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxuICBjb25zdCBrZXkgPSBxdWVyeUtleXMuY2FydC5hbGxcblxuICByZXR1cm4gdXNlTXV0YXRpb24oe1xuICAgIG11dGF0aW9uRm46ICh7IG5mdCwgcXVhbnRpdHkgPSAxIH06IEFkZFRvQ2FydElucHV0KSA9PlxuICAgICAgY2FydFNlcnZpY2UuYWRkSXRlbSh7IG5mdElkOiBuZnQuaWQsIHF1YW50aXR5IH0pLFxuICAgIG9uTXV0YXRlOiBhc3luYyAoeyBuZnQsIHF1YW50aXR5ID0gMSB9KSA9PiB7XG4gICAgICBhd2FpdCBxdWVyeUNsaWVudC5jYW5jZWxRdWVyaWVzKHsgcXVlcnlLZXk6IGtleSB9KVxuICAgICAgY29uc3QgcHJldmlvdXMgPSBxdWVyeUNsaWVudC5nZXRRdWVyeURhdGE8Q2FydFJlc3BvbnNlPihrZXkpXG5cbiAgICAgIGlmIChwcmV2aW91cykge1xuICAgICAgICBjb25zdCBleGlzdGluZ0luZGV4ID0gcHJldmlvdXMuaXRlbXMuZmluZEluZGV4KChpKSA9PiBpLm5mdElkID09PSBuZnQuaWQpXG4gICAgICAgIGNvbnN0IG5leHRJdGVtcyA9IFsuLi5wcmV2aW91cy5pdGVtc11cblxuICAgICAgICBpZiAoZXhpc3RpbmdJbmRleCA+PSAwKSB7XG4gICAgICAgICAgY29uc3QgY3VycmVudCA9IG5leHRJdGVtc1tleGlzdGluZ0luZGV4XVxuICAgICAgICAgIG5leHRJdGVtc1tleGlzdGluZ0luZGV4XSA9IHtcbiAgICAgICAgICAgIC4uLmN1cnJlbnQsXG4gICAgICAgICAgICBxdWFudGl0eTogTWF0aC5taW4oMTAsIGN1cnJlbnQucXVhbnRpdHkgKyBxdWFudGl0eSksXG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIG5leHRJdGVtcy5wdXNoKHtcbiAgICAgICAgICAgIGlkOiBgb3B0aW1pc3RpYy0ke25mdC5pZH1gLFxuICAgICAgICAgICAgdXNlcklkOiAnY3VycmVudCcsXG4gICAgICAgICAgICBuZnRJZDogbmZ0LmlkLFxuICAgICAgICAgICAgbmFtZTogbmZ0Lm5hbWUsXG4gICAgICAgICAgICBpbWFnZVVybDogbmZ0LmltYWdlVXJsLFxuICAgICAgICAgICAgY29sbGVjdGlvbjogbmZ0LmNvbGxlY3Rpb24sXG4gICAgICAgICAgICBjcmVhdG9yTmFtZTogbmZ0LmNyZWF0b3JOYW1lLFxuICAgICAgICAgICAgcHJpY2VFdGg6IG5mdC5wcmljZUV0aCxcbiAgICAgICAgICAgIHF1YW50aXR5LFxuICAgICAgICAgICAgYWRkZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgIH0pXG4gICAgICAgIH1cblxuICAgICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGE8Q2FydFJlc3BvbnNlPihrZXksIHJlY2FsY3VsYXRlT3B0aW1pc3RpY0NhcnQocHJldmlvdXMsIG5leHRJdGVtcykpXG4gICAgICB9XG5cbiAgICAgIHJldHVybiB7IHByZXZpb3VzIH1cbiAgICB9LFxuICAgIG9uU3VjY2VzczogKGRhdGEsIHsgbmZ0IH0pID0+IHtcbiAgICAgIHF1ZXJ5Q2xpZW50LnNldFF1ZXJ5RGF0YShrZXksIGRhdGEpXG4gICAgICB0b2FzdC5zdWNjZXNzKGBcIiR7bmZ0Lm5hbWV9XCIgYWRpY2lvbmFkbyBhbyBjYXJyaW5oby5gKVxuICAgIH0sXG4gICAgb25FcnJvcjogKGVycm9yLCBfdmFycywgY29udGV4dCkgPT4ge1xuICAgICAgaWYgKGNvbnRleHQ/LnByZXZpb3VzKSBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGEoa2V5LCBjb250ZXh0LnByZXZpb3VzKVxuICAgICAgdG9hc3QuZXJyb3IoZ2V0RXJyb3JNZXNzYWdlKGVycm9yKSlcbiAgICB9LFxuICAgIG9uU2V0dGxlZDogKCkgPT4ge1xuICAgICAgdm9pZCBxdWVyeUNsaWVudC5pbnZhbGlkYXRlUXVlcmllcyh7IHF1ZXJ5S2V5OiBrZXkgfSlcbiAgICB9LFxuICB9KVxufVxuXG4vKipcbiAqIEFsdGVyYSBhIHF1YW50aWRhZGUgZGUgdW0gaXRlbSBkbyBjYXJyaW5obyBjb20gT3B0aW1pc3RpYyBVcGRhdGUgZSByZWPDoWxjdWxvIGltZWRpYXRvIGVtIEVUSC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVVwZGF0ZUNhcnRJdGVtUXVhbnRpdHkoKSB7XG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxuICBjb25zdCBrZXkgPSBxdWVyeUtleXMuY2FydC5hbGxcblxuICByZXR1cm4gdXNlTXV0YXRpb24oe1xuICAgIG11dGF0aW9uRm46IGNhcnRTZXJ2aWNlLnVwZGF0ZUl0ZW1RdWFudGl0eSxcbiAgICBvbk11dGF0ZTogYXN5bmMgKHsgaXRlbUlkLCBxdWFudGl0eSB9KSA9PiB7XG4gICAgICBhd2FpdCBxdWVyeUNsaWVudC5jYW5jZWxRdWVyaWVzKHsgcXVlcnlLZXk6IGtleSB9KVxuICAgICAgY29uc3QgcHJldmlvdXMgPSBxdWVyeUNsaWVudC5nZXRRdWVyeURhdGE8Q2FydFJlc3BvbnNlPihrZXkpXG5cbiAgICAgIGlmIChwcmV2aW91cykge1xuICAgICAgICBjb25zdCBuZXh0SXRlbXMgPVxuICAgICAgICAgIHF1YW50aXR5IDw9IDBcbiAgICAgICAgICAgID8gcHJldmlvdXMuaXRlbXMuZmlsdGVyKChpKSA9PiBpLmlkICE9PSBpdGVtSWQpXG4gICAgICAgICAgICA6IHByZXZpb3VzLml0ZW1zLm1hcCgoaSkgPT5cbiAgICAgICAgICAgICAgICBpLmlkID09PSBpdGVtSWQgPyB7IC4uLmksIHF1YW50aXR5OiBNYXRoLm1pbigxMCwgcXVhbnRpdHkpIH0gOiBpLFxuICAgICAgICAgICAgICApXG5cbiAgICAgICAgcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhPENhcnRSZXNwb25zZT4oa2V5LCByZWNhbGN1bGF0ZU9wdGltaXN0aWNDYXJ0KHByZXZpb3VzLCBuZXh0SXRlbXMpKVxuICAgICAgfVxuXG4gICAgICByZXR1cm4geyBwcmV2aW91cyB9XG4gICAgfSxcbiAgICBvbkVycm9yOiAoZXJyb3IsIF92YXJzLCBjb250ZXh0KSA9PiB7XG4gICAgICBpZiAoY29udGV4dD8ucHJldmlvdXMpIHF1ZXJ5Q2xpZW50LnNldFF1ZXJ5RGF0YShrZXksIGNvbnRleHQucHJldmlvdXMpXG4gICAgICB0b2FzdC5lcnJvcihnZXRFcnJvck1lc3NhZ2UoZXJyb3IpKVxuICAgIH0sXG4gICAgb25TZXR0bGVkOiAoKSA9PiB7XG4gICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IGtleSB9KVxuICAgIH0sXG4gIH0pXG59XG5cbi8qKlxuICogUmVtb3ZlIHVtIGl0ZW0gZG8gY2FycmluaG8gY29tIE9wdGltaXN0aWMgVXBkYXRlLCByb2xsYmFjayBlbSBlcnJvIGUgc2luY3Jvbml6YcOnw6NvIGVtIG9uU2V0dGxlZC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVzZVJlbW92ZUNhcnRJdGVtKCkge1xuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbiAgY29uc3Qga2V5ID0gcXVlcnlLZXlzLmNhcnQuYWxsXG5cbiAgcmV0dXJuIHVzZU11dGF0aW9uKHtcbiAgICBtdXRhdGlvbkZuOiBjYXJ0U2VydmljZS5yZW1vdmVJdGVtLFxuICAgIG9uTXV0YXRlOiBhc3luYyAoaXRlbUlkOiBzdHJpbmcpID0+IHtcbiAgICAgIGF3YWl0IHF1ZXJ5Q2xpZW50LmNhbmNlbFF1ZXJpZXMoeyBxdWVyeUtleToga2V5IH0pXG4gICAgICBjb25zdCBwcmV2aW91cyA9IHF1ZXJ5Q2xpZW50LmdldFF1ZXJ5RGF0YTxDYXJ0UmVzcG9uc2U+KGtleSlcblxuICAgICAgaWYgKHByZXZpb3VzKSB7XG4gICAgICAgIGNvbnN0IG5leHRJdGVtcyA9IHByZXZpb3VzLml0ZW1zLmZpbHRlcigoaSkgPT4gaS5pZCAhPT0gaXRlbUlkKVxuICAgICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGE8Q2FydFJlc3BvbnNlPihrZXksIHJlY2FsY3VsYXRlT3B0aW1pc3RpY0NhcnQocHJldmlvdXMsIG5leHRJdGVtcykpXG4gICAgICB9XG5cbiAgICAgIHJldHVybiB7IHByZXZpb3VzIH1cbiAgICB9LFxuICAgIG9uU3VjY2VzczogKCkgPT4ge1xuICAgICAgdG9hc3Quc3VjY2VzcygnSXRlbSByZW1vdmlkbyBkbyBjYXJyaW5oby4nKVxuICAgIH0sXG4gICAgb25FcnJvcjogKGVycm9yLCBfaXRlbUlkLCBjb250ZXh0KSA9PiB7XG4gICAgICBpZiAoY29udGV4dD8ucHJldmlvdXMpIHF1ZXJ5Q2xpZW50LnNldFF1ZXJ5RGF0YShrZXksIGNvbnRleHQucHJldmlvdXMpXG4gICAgICB0b2FzdC5lcnJvcihnZXRFcnJvck1lc3NhZ2UoZXJyb3IpKVxuICAgIH0sXG4gICAgb25TZXR0bGVkOiAoKSA9PiB7XG4gICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IGtleSB9KVxuICAgIH0sXG4gIH0pXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VBcHBseUNvdXBvbigpIHtcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG4gIGNvbnN0IGtleSA9IHF1ZXJ5S2V5cy5jYXJ0LmFsbFxuXG4gIHJldHVybiB1c2VNdXRhdGlvbih7XG4gICAgbXV0YXRpb25GbjogY2FydFNlcnZpY2UuYXBwbHlDb3Vwb24sXG4gICAgb25TdWNjZXNzOiAoZGF0YSkgPT4ge1xuICAgICAgcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhKGtleSwgZGF0YSlcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoYEN1cG9tICR7ZGF0YS5jb3Vwb25Db2RlfSAoJHtkYXRhLmRpc2NvdW50UGVyY2VudH0lIE9GRikgYXBsaWNhZG8hYClcbiAgICB9LFxuICB9KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlUmVtb3ZlQ291cG9uKCkge1xuICBjb25zdCBxdWVyeUNsaWVudCA9IHVzZVF1ZXJ5Q2xpZW50KClcbiAgY29uc3Qga2V5ID0gcXVlcnlLZXlzLmNhcnQuYWxsXG5cbiAgcmV0dXJuIHVzZU11dGF0aW9uKHtcbiAgICBtdXRhdGlvbkZuOiBjYXJ0U2VydmljZS5yZW1vdmVDb3Vwb24sXG4gICAgb25TdWNjZXNzOiAoZGF0YSkgPT4ge1xuICAgICAgcXVlcnlDbGllbnQuc2V0UXVlcnlEYXRhKGtleSwgZGF0YSlcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoJ0N1cG9tIHJlbW92aWRvLicpXG4gICAgfSxcbiAgICBvbkVycm9yOiAoZXJyb3IpID0+IHtcbiAgICAgIHRvYXN0LmVycm9yKGdldEVycm9yTWVzc2FnZShlcnJvcikpXG4gICAgfSxcbiAgfSlcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL2hvb2tzL3VzZS1jYXJ0LnRzIn0=