"use client";
import { r as __toESM } from "/node_modules/.vite/deps/rolldown-runtime-SbdDWaPq.js?v=e9f94b2e";
import { t as require_react } from "/node_modules/.vite/deps/react-4hkZzRew.js?v=e9f94b2e";
import { t as require_jsx_runtime } from "/node_modules/.vite/deps/jsx-runtime-cNwuCTLA.js?v=e9f94b2e";
import { t as require_with_selector } from "/node_modules/.vite/deps/with-selector-QKyvNQmu.js?v=e9f94b2e";
// node_modules/@tanstack/router-core/dist/esm/not-found.js
/**
* Create a not-found error object recognized by TanStack Router.
*
* Throw this from loaders/actions to trigger the nearest `notFoundComponent`.
* Use `routeId` to target a specific route's not-found boundary. If `throw`
* is true, the error is thrown instead of returned.
*
* @param options Optional settings including `routeId`, `headers`, and `throw`.
* @returns A not-found error object that can be thrown or returned.
* @link https://tanstack.com/router/latest/docs/router/framework/react/api/router/notFoundFunction
*/
function notFound(options = {}) {
	options.isNotFound = true;
	if (options.throw) throw options;
	return options;
}
/** Determine if a value is a TanStack Router not-found error. */
function isNotFound(obj) {
	return obj?.isNotFound === true;
}
// node_modules/@tanstack/router-core/dist/esm/root.js
/** Stable identifier used for the root route in a route tree. */
var rootRouteId = "__root__";
// node_modules/@tanstack/router-core/dist/esm/redirect.js
/**
* Create a redirect Response understood by TanStack Router.
*
* Use from route `loader`/`beforeLoad` or server functions to trigger a
* navigation. If `throw: true` is set, the redirect is thrown instead of
* returned. External `href` values are classified as full-document
* navigations when the router resolves the redirect.
*
* @param opts Options for the redirect. Common fields:
* - `href`: absolute URL for external redirects.
* - `statusCode`: HTTP status code to use (defaults to 307).
* - `headers`: additional headers to include on the Response.
* - Standard navigation options like `to`, `params`, `search`, `replace`,
*   and `reloadDocument` for internal redirects.
* @returns A Response augmented with router navigation options.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/redirectFunction
*/
function redirect(opts) {
	opts.statusCode = opts.statusCode || opts.code || 307;
	const headers = new Headers(opts.headers);
	if (opts.href && headers.get("Location") === null) headers.set("Location", opts.href);
	const response = new Response(null, {
		status: opts.statusCode,
		headers
	});
	response.options = opts;
	if (opts.throw) throw response;
	return response;
}
/** Check whether a value is a TanStack Router redirect Response. */
function isRedirect(obj) {
	return obj instanceof Response && !!obj.options;
}
// node_modules/@tanstack/router-core/dist/esm/utils.js
/**
* Return the last element of an array.
* Intended for non-empty arrays used within router internals.
*/
function last(arr) {
	return arr[arr.length - 1];
}
/**
* Apply a value-or-updater to a previous value.
* Accepts either a literal value or a function of the previous value.
*/
function functionalUpdate(updater, previous) {
	if (typeof updater === "function") return updater(previous);
	return updater;
}
var hasOwn = Object.prototype.hasOwnProperty;
function hasKeys(obj) {
	for (const key in obj) if (hasOwn.call(obj, key)) return true;
	return false;
}
var createNull = () => Object.create(null);
var nullReplaceEqualDeep = (prev, next) => replaceEqualDeep(prev, next, true);
function replaceEqualDeep(prev, next, _nullProto, _depth = 0) {
	if (prev === next) return prev;
	if (_depth++ > 500) return next;
	const array = Array.isArray(prev) && Array.isArray(next);
	if (!array && !(isPlainObject(prev) && isPlainObject(next))) return next;
	const prevKeys = Object.keys(prev);
	const previousCount = prevKeys.length;
	const nextKeys = Object.keys(next);
	const length = nextKeys.length;
	if (array ? previousCount !== prev.length || length !== next.length || previousCount && last(prevKeys) !== `${previousCount - 1}` || length && last(nextKeys) !== `${length - 1}` : previousCount !== Object.getOwnPropertyNames(prev).length || length !== Object.getOwnPropertyNames(next).length || Object.getOwnPropertySymbols(next).length) return next;
	let i = 0;
	let child;
	let previous;
	let key;
	if (array) {
		for (; i < length; i++) {
			key = i;
			previous = prev[key];
			child = next[key];
			child = previous === child ? previous : typeof previous === "object" ? replaceEqualDeep(previous, child, _nullProto, _depth) : child;
			if (child !== previous) break;
		}
		if (i === length && previousCount === length) return prev;
	} else {
		let equal = previousCount === length;
		let unchanged = true;
		for (; i < length; i++) {
			key = nextKeys[i];
			previous = prev[key];
			const incoming = next[key];
			child = previous === incoming ? previous : typeof previous === "object" ? replaceEqualDeep(previous, incoming, _nullProto, _depth) : incoming;
			equal &&= child === previous && (prevKeys[i] === key || hasOwn.call(prev, key));
			unchanged &&= Object.is(child, incoming);
			prevKeys[i] = child;
		}
		if (equal) return Object.getOwnPropertySymbols(prev).length ? next : prev;
		if (unchanged) return next;
	}
	const copy = array ? nextKeys.fill(0) : _nullProto ? createNull() : {};
	for (let j = 0; j < length; j++) {
		key = array ? j : nextKeys[j];
		if (array) {
			previous = prev[key];
			if (j > i) {
				child = next[key];
				child = previous === child ? previous : typeof previous === "object" ? replaceEqualDeep(previous, child, _nullProto, _depth) : child;
			}
			copy[key] = j < i ? previous : child;
		} else copy[key] = prevKeys[j];
	}
	return copy;
}
function isPlainObject(o) {
	if (!o || typeof o !== "object") return false;
	return (Object.getPrototypeOf(o)?.constructor ?? Object) === Object;
}
/**
* Perform a deep equality check optimized for router state comparisons.
*
* - `partial`: `b` may omit keys that `a` has (arrays stay length-exact).
* - `explicitUndefined`: keys holding `undefined` take part in the comparison
*   instead of being ignored.
*
* Internal: the flags are positional so hot callers pass no options object.
*/
function deepEqual(a, b, partial, explicitUndefined) {
	if (a === b) return true;
	if (Array.isArray(a) && Array.isArray(b)) {
		if (a.length !== b.length) return false;
		for (let i = 0, l = a.length; i < l; i++) {
			const av = a[i];
			const bv = b[i];
			if (av !== bv && !deepEqual(av, bv, partial, explicitUndefined)) return false;
		}
		return true;
	}
	if (isPlainObject(a) && isPlainObject(b)) {
		if (partial) {
			for (const k in b) if (explicitUndefined || b[k] !== void 0) {
				if (!deepEqual(a[k], b[k], partial, explicitUndefined)) return false;
			}
			return true;
		}
		let aCount = 0;
		if (explicitUndefined) aCount = Object.keys(a).length;
		else for (const k in a) if (a[k] !== void 0) aCount++;
		for (const k in b) if (explicitUndefined || b[k] !== void 0) {
			if (aCount-- === 0 || !deepEqual(a[k], b[k], partial, explicitUndefined)) return false;
		}
		return aCount === 0;
	}
	return false;
}
/**
* Create a promise with exposed resolve/reject and status fields.
* Useful for coordinating async router lifecycle operations.
*/
function createControlledPromise(onResolve) {
	let resolveLoadPromise;
	let rejectLoadPromise;
	const controlledPromise = new Promise((resolve, reject) => {
		resolveLoadPromise = resolve;
		rejectLoadPromise = reject;
	});
	controlledPromise.status = "pending";
	controlledPromise.resolve = (value) => {
		controlledPromise.status = "resolved";
		controlledPromise.value = value;
		resolveLoadPromise(value);
		onResolve?.(value);
	};
	controlledPromise.reject = (e) => {
		controlledPromise.status = "rejected";
		rejectLoadPromise(e);
	};
	return controlledPromise;
}
/**
* Heuristically detect dynamic import "module not found" errors
* across major browsers for lazy route component handling.
*/
function isModuleNotFoundError(error) {
	if (typeof error?.message !== "string") return false;
	return error.message.startsWith("Failed to fetch dynamically imported module") || error.message.startsWith("error loading dynamically imported module") || error.message.startsWith("Importing a module script failed");
}
function findLast(array, predicate) {
	for (let i = array.length - 1; i >= 0; i--) {
		const item = array[i];
		if (predicate(item)) return item;
	}
}
/**
* Re-encode characters that are unsafe in URL paths.
* Includes ASCII control characters (0x00-0x1F, 0x7F) and a subset of the
* WHATWG URL "path percent-encode set" (", <, >, `, {, }).
*
* Space (0x20) is intentionally excluded — decodeURI decodes %20 to space
* and the router stores decoded spaces in location.pathname. The existing
* encodePathLikeUrl already handles re-encoding spaces for outgoing URLs.
*
* These characters are decoded by decodeURI but must remain percent-encoded
* in paths to match how upstream layers (CDNs, edge middleware, browsers)
* interpret the URL, preventing infinite redirect loops and path mismatches.
*/
var PATH_UNSAFE_RE = /[\x00-\x1f\x7f"<>`{}]/g;
function sanitizePathSegment(segment) {
	return segment.replace(PATH_UNSAFE_RE, (ch) => "%" + ch.charCodeAt(0).toString(16).toUpperCase().padStart(2, "0"));
}
function decodeSegment(segment) {
	let decoded;
	try {
		decoded = decodeURI(segment);
	} catch {
		decoded = segment.replaceAll(/%[0-9A-F]{2}/gi, (match) => {
			try {
				return decodeURI(match);
			} catch {
				return match;
			}
		});
	}
	return sanitizePathSegment(decoded);
}
/**
* Default list of URL protocols to allow in links, redirects, and navigation.
* Any absolute URL protocol not in this list is treated as dangerous by default.
*/
var DEFAULT_PROTOCOL_ALLOWLIST = [
	"http:",
	"https:",
	"mailto:",
	"tel:"
];
/**
* Extract the explicit URL scheme, including its colon, using WHATWG
* normalization rules. This does not validate the rest of the URL.
*
* Returning `undefined` means "no explicit scheme", not "safe URL";
* protocol-relative URLs such as "//evil.example" require a separate check.
*/
function getUrlScheme(url) {
	if (url[0] === "/") return;
	if (!url.includes(":")) return;
	return /^[\x00-\x20]*([a-z][a-z\d+.\t\n\r-]*:)/i.exec(url)?.[1]?.replace(/[\t\n\r]/g, "").toLowerCase();
}
var protocolRelativePrefixRegex = /^[\x00-\x20]*[\\/][\t\n\r]*[\\/]/;
/**
* Check if a URL string uses a protocol that is not in the allowlist or is
* protocol-relative (e.g. "//evil.example"), which can navigate to another host.
* Returns true for blocked protocols like javascript:, blob:, and data:, as
* well as slash/backslash variants of protocol-relative URLs.
*
* Scheme parsing normalizes:
* - Mixed case (JavaScript: → javascript:)
* - Whitespace/control characters (java\nscript: → javascript:)
* - Leading whitespace
*
* For relative URLs without a protocol-relative prefix, returns false.
*
* @param url - The URL string to check
* @param allowlist - Set of protocols to allow
* @returns true if the URL uses a protocol that is not allowed or can escape
* the current origin through a protocol-relative URL
*/
function isDangerousProtocol(url, allowlist) {
	if (!url) return false;
	if (protocolRelativePrefixRegex.test(url)) return true;
	const scheme = getUrlScheme(url);
	return scheme ? !allowlist.has(scheme) : false;
}
var HTML_ESCAPE_LOOKUP = {
	"&": "\\u0026",
	">": "\\u003e",
	"<": "\\u003c",
	"\u2028": "\\u2028",
	"\u2029": "\\u2029"
};
var HTML_ESCAPE_REGEX = /[&><\u2028\u2029]/g;
/**
* Escape HTML special characters in a string to prevent XSS attacks
* when embedding strings in script tags during SSR.
*
* This is essential for preventing XSS vulnerabilities when user-controlled
* content is embedded in inline scripts.
*/
function escapeHtml(str) {
	return str.replace(HTML_ESCAPE_REGEX, (match) => HTML_ESCAPE_LOOKUP[match]);
}
function decodePath(path) {
	if (!path) return path;
	let result = path;
	if (/[%\\\x00-\x1f\x7f]/.test(path)) {
		const re = /%25|%5C/gi;
		let cursor = 0;
		let match;
		result = "";
		while (null !== (match = re.exec(path))) {
			result += decodeSegment(path.slice(cursor, match.index)) + match[0];
			cursor = re.lastIndex;
		}
		result += decodeSegment(cursor ? path.slice(cursor) : path);
	}
	return result;
}
/**
* Encodes a path the same way `new URL()` would, but without the overhead of full URL parsing.
*
* This function encodes:
* - Whitespace characters (spaces → %20, tabs → %09, etc.)
* - Non-ASCII/Unicode characters (emojis, accented characters, etc.)
*
* It preserves:
* - Already percent-encoded sequences (won't double-encode %2F, %25, etc.)
* - ASCII special characters valid in URL paths (@, $, &, +, etc.)
* - Forward slashes as path separators
*
* Used to generate proper href values for SSR without constructing URL objects.
*
* @example
* encodePathLikeUrl('/path/file name.pdf') // '/path/file%20name.pdf'
* encodePathLikeUrl('/path/日本語') // '/path/%E6%97%A5%E6%9C%AC%E8%AA%9E'
* encodePathLikeUrl('/path/already%20encoded') // '/path/already%20encoded' (preserved)
*/
function encodePathLikeUrl(path) {
	if (!/[\s\u0080-\uFFFF]/.test(path)) return path;
	return path.replace(/\s|[^\u0000-\u007F]/gu, encodeURIComponent);
}
function arraysEqual(a, b) {
	if (a === b) return true;
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
	return true;
}
// node_modules/@tanstack/router-core/dist/esm/path.js
/** Join path segments, cleaning duplicate slashes between parts. */
function joinPaths(paths) {
	return cleanPath(paths.filter((val) => {
		return val !== void 0;
	}).join("/"));
}
/** Remove repeated slashes from a path string. */
function cleanPath(path) {
	return path.replace(/\/{2,}/g, "/");
}
/** Trim leading slashes (except preserving root '/'). */
function trimPathLeft(path) {
	return path === "/" ? path : path.replace(/^\/+/, "");
}
/** Trim trailing slashes (except preserving root '/'). */
function trimPathRight(path) {
	const len = path.length;
	return len > 1 && path[len - 1] === "/" ? path.replace(/\/+$/, "") : path;
}
/** Trim both leading and trailing slashes. */
function trimPath(path) {
	return trimPathRight(trimPathLeft(path));
}
/** Remove a trailing slash from value when appropriate for comparisons. */
function removeTrailingSlash(value, basepath) {
	if (value?.endsWith("/") && value !== "/" && value !== `${basepath}/`) return value.slice(0, -1);
	return value;
}
/**
* Resolve a destination path against a base, honoring trailing-slash policy
* and supporting relative segments (`.`/`..`) and absolute `to` values.
*
* Internal: parameters are positional so the router's hot callers pass no
* options object.
*/
function resolvePath(base, to, trailingSlash = "never", cache) {
	if (to.includes("//")) to = cleanPath(to);
	if (to.startsWith("/")) {
		if (to.length === 1 || trailingSlash === "preserve") return to;
		if (trailingSlash === "always") return to.endsWith("/") ? to : `${to}/`;
		return to.endsWith("/") ? to.slice(0, -1) : to;
	}
	const isBase = to === ".";
	let key;
	if (cache) {
		key = isBase ? base : base + "\0" + to;
		const cached = cache.get(key);
		if (cached) return cached;
	}
	let baseSegments;
	if (isBase) baseSegments = base.split("/");
	else {
		if (base.includes("//")) base = cleanPath(base);
		baseSegments = base.split("/");
		while (baseSegments.length > 1 && last(baseSegments) === "") baseSegments.pop();
		const toSegments = to.split("/");
		for (let index = 0, length = toSegments.length; index < length; index++) {
			const value = toSegments[index];
			if (value === "") {
				if (!index) baseSegments = [value];
				else if (index === length - 1) baseSegments.push(value);
			} else if (value === "..") {
				if (baseSegments.length > 1) baseSegments.pop();
				else baseSegments = [""];
			} else if (value === ".") {} else baseSegments.push(value);
		}
	}
	if (baseSegments.length > 1) {
		if (last(baseSegments) === "") {
			if (trailingSlash === "never") baseSegments.pop();
		} else if (trailingSlash === "always") baseSegments.push("");
	}
	const joined = baseSegments.join("/");
	const result = (isBase ? cleanPath(joined) : joined) || "/";
	if (key && cache) cache.set(key, result);
	return result;
}
/**
* Create a pre-compiled decode config from allowed characters.
* Created once for the router's fixed encoding configuration.
*/
function compileDecodeCharMap(pathParamsAllowedCharacters) {
	const charMap = new Map(pathParamsAllowedCharacters.map((char) => [encodeURIComponent(char), char]));
	const regex = new RegExp([...charMap.keys()].join("|").replace(/[.*()]/g, "\\$&"), "g");
	return (encoded) => encoded.replace(regex, (match) => charMap.get(match) ?? match);
}
/** A splat is missing when it has no value; `0` and `false` are stringified like any other param. */
function isMissingSplat(value) {
	return value == null || value === "";
}
function encodeParam(key, value, decoder) {
	if (typeof value !== "string") return "" + (value ?? void 0);
	const splat = key === "_splat";
	if (splat && (!value || /^[a-zA-Z0-9\-._~!/]*$/.test(value))) return value;
	let encoded = encodeURIComponent(value);
	if (splat) encoded = encoded.replaceAll("%2F", "/");
	return decoder ? decoder(encoded) : encoded;
}
/** Substitute current values into parsed segments, optionally collecting raw params. */
function interpolatePath(path, segments, params, decoder, usedParams) {
	const trailingSlash = path.endsWith("/") ? "/" : "";
	let joined = "";
	for (const part of segments) {
		if (typeof part === "string") {
			joined += part;
			continue;
		}
		const [kind, key, prefix, rawSuffix] = part;
		const splat = kind === 2;
		const suffix = splat && rawSuffix !== void 0 ? rawSuffix + trailingSlash : rawSuffix;
		let paramValue = params[key];
		if (kind === 3 && paramValue == null) continue;
		if (usedParams) {
			usedParams[key] = paramValue;
			if (splat) usedParams["*"] = paramValue;
		}
		if (splat && isMissingSplat(paramValue)) {
			if (prefix === "/" && !suffix) continue;
			paramValue = "";
		}
		joined += prefix + encodeParam(key, paramValue, decoder) + (suffix || "");
	}
	return joined + trailingSlash || "/";
}
// node_modules/@tanstack/router-core/dist/esm/sieve-cache.js
/**
* A fixed-capacity cache using the SIEVE eviction algorithm
* (https://cachemon.github.io/SIEVE-website/).
*
* Entries live in the Map's FIFO insertion order; a hit only flips a `visited`
* bit instead of relinking the entry, which makes `get` (by far the hottest
* operation here) one `Map.get` plus a boolean store. Eviction sweeps a `hand`
* from the oldest entry towards the newest, clearing `visited` bits until it
* finds an unvisited entry to drop, so entries touched since the last sweep
* survive one more round. This keeps LRU-like hit ratios while being
* scan-resistant.
*/
function createSieveCache(max) {
	const cache = /* @__PURE__ */ new Map();
	let hand;
	let newest;
	return {
		get(key) {
			const entry = cache.get(key);
			if (!entry) return;
			entry.visited = true;
			return entry.value;
		},
		set(key, value) {
			const existing = cache.get(key);
			if (existing) {
				existing.value = value;
				return;
			}
			if (cache.size >= max) {
				let node = hand?.next().value;
				while (!node || node.visited) {
					if (node) node.visited = false;
					else hand = cache.values();
					node = hand.next().value;
				}
				if (node === newest) hand = void 0;
				cache.delete(node.key);
			}
			const entry = {
				key,
				value,
				visited: false
			};
			newest = entry;
			cache.set(key, entry);
		},
		clear() {
			cache.clear();
			hand = void 0;
			newest = void 0;
		}
	};
}
// node_modules/@tanstack/router-core/dist/esm/new-process-route-tree.js
var SEGMENT_TYPE_INDEX = 4;
var SEGMENT_TYPE_PATHLESS = 5;
function getParamNames(data) {
	const cached = data.names;
	if (cached) return cached;
	const keys = [];
	for (const segment of data) if (typeof segment !== "string") keys.push(segment[1]);
	return data.names = keys;
}
/** Parse one segment for matching and retain the same record for interpolation. */
function parseSegment(path, start, end) {
	const part = path.slice(start, end);
	if (part.charCodeAt(0) === 36) return part.length === 1 ? [
		2,
		"_splat",
		"",
		void 0
	] : [
		1,
		part.slice(1),
		"",
		""
	];
	const open = part.indexOf("{");
	if (open >= 0) {
		const close = part.indexOf("}", open);
		const optional = part.charCodeAt(open + 1) === 45;
		const nameStart = open + (optional ? 3 : 2);
		if (close >= 0 && part.charCodeAt(nameStart - 1) === 36 && (!optional || nameStart < close)) {
			const key = part.slice(nameStart, close);
			return [
				optional ? 3 : key ? 1 : 2,
				key || "_splat",
				part.slice(0, open),
				path.slice(start + close + 1, key ? end : path.length)
			];
		}
	}
	return part;
}
function parseSegments(defaultCaseSensitive, route, start, node, dynamicListsToSort, parentInterpolation) {
	let cursor = start;
	const path = route.fullPath ?? route.from;
	const options = route.options;
	const length = path.length;
	const literalEnd = path.endsWith("/") ? length - 1 : length;
	const caseSensitive = options?.caseSensitive ?? defaultCaseSensitive;
	const parseParams = options?.params?.parse ?? options?.parseParams;
	let interpolation;
	let literalStart = parentInterpolation ? start - 1 : 0;
	if (!node || path.includes("$")) {
		interpolation = parentInterpolation?.slice() ?? [];
		const tail = last(interpolation);
		if (tail && typeof tail !== "string" && tail[0] === 2) {
			interpolation[interpolation.length - 1] = [
				tail[0],
				tail[1],
				tail[2],
				tail[3] === void 0 ? void 0 : tail[3] + path.substring(start - (path[start - 2] === "/" ? 2 : 1), literalEnd)
			];
			literalStart = length;
		}
	}
	while (cursor < length) {
		const start = cursor;
		const next = path.indexOf("/", start);
		let end = next === -1 ? length : next;
		const segment = parseSegment(path, start, end);
		cursor = end + 1;
		let nextNode;
		if (typeof segment === "string") {
			if (!node) continue;
			let name = segment;
			let staticChildren;
			if (caseSensitive) staticChildren = node.static ??= /* @__PURE__ */ new Map();
			else {
				name = segment.toLowerCase();
				staticChildren = node.staticInsensitive ??= /* @__PURE__ */ new Map();
			}
			const existingNode = staticChildren.get(name);
			if (existingNode) nextNode = existingNode;
			else {
				const next = createSegmentNode(node);
				nextNode = next;
				staticChildren.set(name, next);
			}
		} else {
			const kind = segment[0];
			let prefix = segment[2];
			let suffix = segment[3] ?? "";
			if (kind === 2) {
				end = length;
				cursor = end + 1;
			}
			if (interpolation && literalStart < end) {
				if (literalStart < start - 1) interpolation.push(path.slice(literalStart, start - 1));
				segment[2] = "/" + prefix;
				if (kind === 2 && segment[3] !== void 0 && literalEnd < length) segment[3] = suffix.slice(0, -1);
				interpolation.push(segment);
				literalStart = end;
			}
			if (!node) continue;
			const actuallyCaseSensitive = caseSensitive && !!(prefix || suffix);
			if (!caseSensitive) {
				prefix = prefix.toLowerCase();
				suffix = suffix.toLowerCase();
			}
			const siblings = kind === 1 ? node.dynamic ??= [] : kind === 3 ? node.optional ??= [] : node.wildcard ??= [];
			const existingNode = kind !== 2 && !parseParams && siblings.find((s) => !s.parse && s.caseSensitive === actuallyCaseSensitive && s.prefix === prefix && s.suffix === suffix);
			if (existingNode) nextNode = existingNode;
			else {
				const next = createSegmentNode(node, kind, actuallyCaseSensitive, prefix, suffix);
				nextNode = next;
				siblings.push(next);
				if (siblings.length === 2) dynamicListsToSort?.push(siblings);
			}
		}
		node = nextNode;
	}
	if (interpolation && literalStart < literalEnd) interpolation.push(path.slice(literalStart, literalEnd));
	const segmentData = interpolation?.slice();
	if (!node) return segmentData;
	if (parseParams && route.children && !route.isRoot && route.id && route.id.charCodeAt(route.id.lastIndexOf("/") + 1) === 95) {
		const pathlessNode = createSegmentNode(node, SEGMENT_TYPE_PATHLESS);
		(node.pathless ??= []).push(pathlessNode);
		node = pathlessNode;
	}
	const isLeaf = (route.path || !route.children) && !route.isRoot;
	if (isLeaf && literalEnd < length) {
		const indexNode = createSegmentNode(node, SEGMENT_TYPE_INDEX);
		node.index = indexNode;
		node = indexNode;
	}
	node.parse = parseParams ?? null;
	node.priority = options?.params?.priority ?? 0;
	if (!node.route) {
		node.data = segmentData;
		if (isLeaf) node.route = route;
	}
	return [
		node,
		cursor,
		segmentData
	];
}
function sortDynamic(a, b) {
	if (a.parse && !b.parse) return -1;
	if (!a.parse && b.parse) return 1;
	if (a.parse && b.parse && (a.priority || b.priority)) return b.priority - a.priority;
	if (a.prefix && b.prefix && a.prefix !== b.prefix) {
		if (a.prefix.startsWith(b.prefix)) return -1;
		if (b.prefix.startsWith(a.prefix)) return 1;
	}
	if (a.suffix && b.suffix && a.suffix !== b.suffix) {
		if (a.suffix.endsWith(b.suffix)) return -1;
		if (b.suffix.endsWith(a.suffix)) return 1;
	}
	if (a.prefix && !b.prefix) return -1;
	if (!a.prefix && b.prefix) return 1;
	if (a.suffix && !b.suffix) return -1;
	if (!a.suffix && b.suffix) return 1;
	if (a.caseSensitive && !b.caseSensitive) return -1;
	if (!a.caseSensitive && b.caseSensitive) return 1;
	return 0;
}
function createSegmentNode(parent, kind = 0, caseSensitive, prefix, suffix) {
	return {
		kind,
		depth: parent ? parent.depth + 1 : 0,
		pathless: null,
		index: null,
		static: null,
		staticInsensitive: null,
		dynamic: null,
		optional: null,
		wildcard: null,
		route: null,
		data: void 0,
		parent,
		parse: null,
		priority: 0,
		caseSensitive,
		prefix,
		suffix
	};
}
function processRouteMasks(routeList, processedTree) {
	const segmentTree = createSegmentNode();
	const dynamicListsToSort = [];
	function visit(route, start, parentNode, parentInterpolation) {
		const [node, cursor, segments] = parseSegments(false, route, start, parentNode, dynamicListsToSort, parentInterpolation);
		if (route.children) for (const child of route.children) visit(child, cursor, node, segments);
	}
	for (const route of routeList) visit(route, 1, segmentTree);
	for (const nodes of dynamicListsToSort) nodes.sort(sortDynamic);
	processedTree.masksTree = segmentTree;
	processedTree.flatCache = createSieveCache(1e3);
}
/**
* Take an arbitrary list of routes, create a tree from them (if it hasn't been created already), and match a path against it.
*/
function findFlatMatch(path, processedTree) {
	path ||= "/";
	const cached = processedTree.flatCache.get(path);
	if (cached !== void 0) return cached;
	const result = findMatch(path, processedTree.masksTree);
	processedTree.flatCache.set(path, result);
	return result;
}
/**
* @deprecated keep until v2 so that `router.matchRoute` can keep not caring about the actual route tree
*/
function findSingleMatch(from, caseSensitive, fuzzy, path, processedTree) {
	from ||= "/";
	path ||= "/";
	const key = caseSensitive ? `case\0${from}` : from;
	let tree = processedTree.singleCache.get(key);
	if (!tree) {
		tree = createSegmentNode();
		parseSegments(caseSensitive, { from }, 1, tree);
		processedTree.singleCache.set(key, tree);
	}
	return findMatch(path, tree, fuzzy);
}
function findRouteMatch(path, processedTree, fuzzy = false) {
	const key = fuzzy ? path : `nofuzz\0${path}`;
	const cached = processedTree.matchCache.get(key);
	if (cached !== void 0) return cached;
	path ||= "/";
	let result;
	try {
		result = findMatch(path, processedTree.segmentTree, fuzzy);
	} catch (err) {
		if (err instanceof URIError) result = null;
		else throw err;
	}
	if (result) result.branch = buildRouteBranch(result.route);
	processedTree.matchCache.set(key, result);
	return result;
}
/**
* Processes a route tree into a segment trie for efficient path matching.
* Also builds lookup maps for routes by ID and by trimmed full path.
*/
function processRouteTree(routeTree, caseSensitive = false) {
	const segmentTree = createSegmentNode();
	const dynamicListsToSort = [];
	const routesById = {};
	const routesByPath = {};
	let index = 0;
	function visit(route, start, parentNode, parentInterpolation) {
		route.init(index);
		if (route.id in routesById) throw new Error(`Invariant failed: Duplicate routes found with id: ${String(route.id)}`);
		routesById[route.id] = route;
		if (index !== 0 && route.path) {
			const trimmedFullPath = trimPathRight(route.fullPath);
			if (!routesByPath[trimmedFullPath] || route.fullPath.endsWith("/")) routesByPath[trimmedFullPath] = route;
		}
		index++;
		const [node, cursor, segments] = parseSegments(caseSensitive, route, start, parentNode, dynamicListsToSort, parentInterpolation);
		route._interpolation = segments;
		if (route.children) for (const child of route.children) visit(child, cursor, node, segments);
	}
	visit(routeTree, 1, segmentTree);
	for (const nodes of dynamicListsToSort) nodes.sort(sortDynamic);
	return {
		processedTree: {
			segmentTree,
			singleCache: createSieveCache(1e3),
			matchCache: createSieveCache(1e3),
			flatCache: null,
			masksTree: null
		},
		routesById,
		routesByPath
	};
}
function findMatch(path, segmentTree, fuzzy = false) {
	const parts = path.split("/");
	const leaf = getNodeMatch(path, parts, segmentTree, fuzzy);
	if (!leaf) return null;
	const [rawParams] = extractParams(path, parts, leaf);
	return {
		route: leaf.node.route,
		rawParams
	};
}
/**
* This function is "resumable":
* - the `leaf` input can contain `extract` and `rawParams` properties from a previous `extractParams` call
* - the returned `state` can be passed back as `extract` in a future call to continue extracting params from where we left off
*
* Inputs are *not* mutated.
*/
function extractParams(path, parts, leaf) {
	const list = buildBranch(leaf.node);
	const names = leaf.node.data && getParamNames(leaf.node.data);
	const rawParams = Object.create(null);
	/** which segment of the path we're currently processing */
	let partIndex = leaf.extract?.part ?? 0;
	/** which node of the route tree branch we're currently processing */
	let nodeIndex = leaf.extract?.node ?? 0;
	/** index of the 1st character of the segment we're processing in the path string */
	let pathIndex = leaf.extract?.path ?? 0;
	/** Next original parameter name, independent of pathless/static nodes. */
	let paramIndex = leaf.extract?.param ?? 0;
	for (; nodeIndex < list.length; partIndex++, nodeIndex++, pathIndex++) {
		const node = list[nodeIndex];
		if (node.kind === SEGMENT_TYPE_INDEX) break;
		if (node.kind === SEGMENT_TYPE_PATHLESS) {
			partIndex--;
			pathIndex--;
			continue;
		}
		const part = parts[partIndex];
		const currentPathIndex = pathIndex;
		if (part) pathIndex += part.length;
		if (node.kind === 1 || node.kind === 3) {
			const name = names[paramIndex++];
			if (node.kind === 3 && leaf.skipped & 1 << nodeIndex) {
				partIndex--;
				pathIndex = currentPathIndex - 1;
				continue;
			}
			const value = node.suffix || node.prefix ? part.substring(node.prefix.length, part.length - node.suffix.length) : part;
			if (value || node.kind === 1) rawParams[name] = decodeURIComponent(value);
		} else if (node.kind === 2) {
			const n = node;
			const value = path.substring(currentPathIndex + n.prefix.length, path.length - n.suffix.length);
			const splat = decodeURIComponent(value);
			rawParams["*"] = splat;
			rawParams._splat = splat;
			break;
		}
	}
	if (leaf.rawParams) Object.assign(rawParams, leaf.rawParams);
	return [rawParams, {
		part: partIndex,
		node: nodeIndex,
		path: pathIndex,
		param: paramIndex
	}];
}
function buildRouteBranch(route) {
	const list = [route];
	while (route.parentRoute) {
		route = route.parentRoute;
		list.push(route);
	}
	list.reverse();
	return list;
}
function buildBranch(node) {
	const list = Array(node.depth + 1);
	do {
		list[node.depth] = node;
		node = node.parent;
	} while (node);
	return list;
}
function getNodeMatch(path, parts, segmentTree, fuzzy) {
	if (path === "/" && segmentTree.index) return {
		node: segmentTree.index,
		skipped: 0
	};
	const trailingSlash = !last(parts);
	const pathIsIndex = trailingSlash && path !== "/";
	const partsLength = parts.length - (trailingSlash ? 1 : 0);
	const stack = [{
		node: segmentTree,
		index: 1,
		skipped: 0,
		statics: 0,
		dynamics: 0,
		optionals: 0
	}];
	let bestFuzzy = null;
	let bestMatch = null;
	while (stack.length) {
		const frame = stack.pop();
		const { node, index, skipped, statics, dynamics, optionals } = frame;
		let { extract, rawParams } = frame;
		if (node.kind === 2 && node.route && !isFrameMoreSpecific(bestMatch, frame)) continue;
		if (node.parse) {
			if (!validateParseParams(path, parts, frame)) continue;
			rawParams = frame.rawParams;
			extract = frame.extract;
		}
		if (fuzzy && node.route && node.kind !== SEGMENT_TYPE_INDEX && isFrameMoreSpecific(bestFuzzy, frame)) bestFuzzy = frame;
		const isBeyondPath = index === partsLength;
		if (isBeyondPath) {
			if (node.route && (!pathIsIndex || node.kind === SEGMENT_TYPE_INDEX || node.kind === 2) && isFrameMoreSpecific(bestMatch, frame)) bestMatch = frame;
			if (!node.optional && !node.wildcard && !node.index && !node.pathless) continue;
		}
		const part = isBeyondPath ? void 0 : parts[index];
		let lowerPart;
		if (isBeyondPath && node.index) {
			const indexFrame = {
				node: node.index,
				index,
				skipped,
				statics,
				dynamics,
				optionals,
				extract,
				rawParams
			};
			let indexValid = true;
			if (node.index.parse) {
				if (!validateParseParams(path, parts, indexFrame)) indexValid = false;
			}
			if (indexValid) {
				if (!dynamics && !optionals && !skipped && isPerfectStaticMatch(statics, partsLength)) return indexFrame;
				if (isFrameMoreSpecific(bestMatch, indexFrame)) bestMatch = indexFrame;
			}
		}
		if (node.wildcard) for (let i = node.wildcard.length - 1; i >= 0; i--) {
			const segment = node.wildcard[i];
			const { prefix, suffix } = segment;
			if (prefix) {
				if (isBeyondPath) continue;
				if (!(segment.caseSensitive ? part : lowerPart ??= part.toLowerCase()).startsWith(prefix)) continue;
			}
			if (suffix) {
				if (isBeyondPath) continue;
				const end = parts.slice(index).join("/");
				const suffixPart = end.slice(-suffix.length);
				if ((segment.caseSensitive ? suffixPart : suffixPart.toLowerCase()) !== suffix || end.length - suffix.length < prefix.length) continue;
			}
			stack.push({
				node: segment,
				index: partsLength,
				skipped,
				statics,
				dynamics,
				optionals,
				extract,
				rawParams
			});
		}
		if (node.optional) {
			const nextSkipped = skipped | 1 << node.depth + 1;
			for (let i = node.optional.length - 1; i >= 0; i--) {
				const segment = node.optional[i];
				stack.push({
					node: segment,
					index,
					skipped: nextSkipped,
					statics,
					dynamics,
					optionals,
					extract,
					rawParams
				});
			}
			if (!isBeyondPath) for (let i = node.optional.length - 1; i >= 0; i--) {
				const segment = node.optional[i];
				const { prefix, suffix } = segment;
				if (prefix || suffix) {
					const casePart = segment.caseSensitive ? part : lowerPart ??= part.toLowerCase();
					if (prefix && !casePart.startsWith(prefix)) continue;
					if (suffix && casePart.indexOf(suffix, casePart.length - suffix.length) < prefix.length) continue;
				}
				stack.push({
					node: segment,
					index: index + 1,
					skipped,
					statics,
					dynamics,
					optionals: optionals + segmentScore(partsLength, index),
					extract,
					rawParams
				});
			}
		}
		if (!isBeyondPath && node.dynamic && part) for (let i = node.dynamic.length - 1; i >= 0; i--) {
			const segment = node.dynamic[i];
			const { prefix, suffix } = segment;
			if (prefix || suffix) {
				const casePart = segment.caseSensitive ? part : lowerPart ??= part.toLowerCase();
				if (prefix && !casePart.startsWith(prefix)) continue;
				if (suffix && casePart.indexOf(suffix, casePart.length - suffix.length) < prefix.length) continue;
			}
			stack.push({
				node: segment,
				index: index + 1,
				skipped,
				statics,
				dynamics: dynamics + segmentScore(partsLength, index),
				optionals,
				extract,
				rawParams
			});
		}
		if (!isBeyondPath && node.staticInsensitive) {
			const match = node.staticInsensitive.get(lowerPart ??= part.toLowerCase());
			if (match) stack.push({
				node: match,
				index: index + 1,
				skipped,
				statics: statics + segmentScore(partsLength, index),
				dynamics,
				optionals,
				extract,
				rawParams
			});
		}
		if (!isBeyondPath && node.static) {
			const match = node.static.get(part);
			if (match) stack.push({
				node: match,
				index: index + 1,
				skipped,
				statics: statics + segmentScore(partsLength, index),
				dynamics,
				optionals,
				extract,
				rawParams
			});
		}
		if (node.pathless) for (let i = node.pathless.length - 1; i >= 0; i--) {
			const segment = node.pathless[i];
			stack.push({
				node: segment,
				index,
				skipped,
				statics,
				dynamics,
				optionals,
				extract,
				rawParams
			});
		}
	}
	if (bestMatch) return bestMatch;
	if (fuzzy && bestFuzzy) {
		let sliceIndex = bestFuzzy.index;
		for (let i = 0; i < bestFuzzy.index; i++) sliceIndex += parts[i].length;
		const splat = sliceIndex === path.length ? "/" : path.slice(sliceIndex);
		bestFuzzy.rawParams ??= Object.create(null);
		bestFuzzy.rawParams["**"] = decodeURIComponent(splat);
		return bestFuzzy;
	}
	return null;
}
function segmentScore(partsLength, index) {
	return 2 ** (partsLength - index - 1);
}
function isPerfectStaticMatch(statics, partsLength) {
	return statics === 2 ** (partsLength - 1) - 1;
}
function validateParseParams(path, parts, frame) {
	let rawParams;
	let state;
	try {
		[rawParams, state] = extractParams(path, parts, frame);
	} catch {
		return null;
	}
	frame.rawParams = rawParams;
	frame.extract = state;
	if (!frame.node.parse) return true;
	try {
		if (frame.node.parse(rawParams) === false) return null;
	} catch {}
	return true;
}
function isFrameMoreSpecific(prev, next) {
	if (!prev) return true;
	return next.statics > prev.statics || next.statics === prev.statics && (next.dynamics > prev.dynamics || next.dynamics === prev.dynamics && (next.optionals > prev.optionals || next.optionals === prev.optionals && ((next.node.kind === SEGMENT_TYPE_INDEX) > (prev.node.kind === SEGMENT_TYPE_INDEX) || next.node.kind === SEGMENT_TYPE_INDEX === (prev.node.kind === SEGMENT_TYPE_INDEX) && next.node.depth > prev.node.depth)));
}
// node_modules/@tanstack/router-core/dist/esm/scroll-restoration.js
function getSafeSessionStorage() {
	try {
		return sessionStorage;
	} catch {
		return;
	}
}
var storageKey = "tsr-scroll-restoration-v1_3";
var safeSessionStorage = getSafeSessionStorage();
function createScrollRestorationCache() {
	try {
		return JSON.parse(safeSessionStorage?.getItem("tsr-scroll-restoration-v1_3") || "{}");
	} catch {
		return {};
	}
}
var scrollRestorationCache = /* @__PURE__ */ createScrollRestorationCache();
var scrollRestorationIdAttribute = "data-scroll-restoration-id";
/**
* The default `getKey` function for `useScrollRestoration`.
* It returns the `key` from the location state or the `href` of the location.
*
* The `location.href` is used as a fallback to support the use case where the location state is not available like the initial render.
*/
var defaultGetScrollRestorationKey = (location) => {
	return location.state.__TSR_key || location.href;
};
function getScrollRestorationSelector(element) {
	const attrId = element.getAttribute(scrollRestorationIdAttribute);
	if (attrId) return `[${scrollRestorationIdAttribute}="${attrId}"]`;
	let selector = "";
	let el = element;
	let parent;
	while (parent = el.parentNode) {
		let index = 1;
		let sibling = el;
		while (sibling = sibling.previousElementSibling) index++;
		const part = `${el.localName}:nth-child(${index})`;
		selector = selector ? `${part} > ${selector}` : part;
		el = parent;
	}
	return selector;
}
function getElementScrollRestorationEntry(router, options) {
	const entries = scrollRestorationCache[(options.getKey || defaultGetScrollRestorationKey)(router.latestLocation)];
	if (!entries) return;
	if (options.id) return entries[`[${scrollRestorationIdAttribute}="${options.id}"]`];
	const element = options.getElement?.();
	if (!element) return;
	return entries[element === window ? windowScrollTarget : getScrollRestorationSelector(element)];
}
var ignoreScroll = false;
var windowScrollTarget = "window";
function getElement(selector) {
	try {
		return typeof selector === "function" ? selector() : document.querySelector(selector);
	} catch {}
}
function getScrollToTopElements(scrollToTopSelectors) {
	const elements = /* @__PURE__ */ new Set();
	for (const selector of scrollToTopSelectors) {
		if (selector === windowScrollTarget) continue;
		const element = getElement(selector);
		if (element) elements.add(element);
	}
	return elements;
}
function setupScrollRestoration(router, force) {
	const shouldSetupScrollRestoration = force ?? router.options.scrollRestoration;
	const scroll = router._scroll;
	if (shouldSetupScrollRestoration) scroll.e = true;
	if (router.isServer) return;
	const getKey = router.options.getScrollRestorationKey || defaultGetScrollRestorationKey;
	const trackedScrollTargets = /* @__PURE__ */ new Set();
	const snapshotCurrentScrollTargets = (restoreKey) => {
		const keyEntry = scrollRestorationCache[restoreKey] ||= {};
		for (const target of trackedScrollTargets) if (target === document) keyEntry[windowScrollTarget] = {
			scrollX,
			scrollY
		};
		else if (target.isConnected) keyEntry[getScrollRestorationSelector(target)] = {
			scrollX: target.scrollLeft,
			scrollY: target.scrollTop
		};
	};
	if (shouldSetupScrollRestoration && !scroll.s) {
		scroll.s = true;
		ignoreScroll = false;
		history.scrollRestoration = "manual";
		document.addEventListener("scroll", (event) => {
			if (ignoreScroll) return;
			trackedScrollTargets.add(event.target);
		}, true);
		router.subscribe("onBeforeLoad", (event) => {
			if (event.fromLocation) snapshotCurrentScrollTargets(getKey(event.fromLocation));
			trackedScrollTargets.clear();
		});
		addEventListener("pagehide", () => {
			history.scrollRestoration = "auto";
			snapshotCurrentScrollTargets(getKey(router.stores.resolvedLocation.get() ?? router.stores.location.get()));
			try {
				safeSessionStorage?.setItem(storageKey, JSON.stringify(scrollRestorationCache));
			} catch {
				console.warn("[ts-router] Could not persist scroll restoration state to sessionStorage.");
			}
		});
		addEventListener("pageshow", (event) => {
			if (event.persisted) history.scrollRestoration = "manual";
		});
	}
	if (scroll.r) return;
	scroll.r = true;
	router.subscribe("onRendered", (event) => {
		const behavior = router.options.scrollRestorationBehavior;
		const scrollToTopSelectors = router.options.scrollToTopSelectors;
		const shouldResetScroll = scroll.n;
		const hashNavigation = scroll.h;
		let scrollToTopElements;
		trackedScrollTargets.clear();
		scroll.n = true;
		scroll.h = false;
		if (typeof router.options.scrollRestoration === "function" && !router.options.scrollRestoration({ location: router.latestLocation })) return;
		const cacheKey = getKey(event.toLocation);
		const fromCacheKey = event.fromLocation && getKey(event.fromLocation);
		if (scroll.e && fromCacheKey && fromCacheKey !== cacheKey) {
			const fromElementEntries = scrollRestorationCache[fromCacheKey];
			if (fromElementEntries) {
				let toElementEntries = scrollRestorationCache[cacheKey];
				for (const elementSelector in fromElementEntries) {
					if (elementSelector === windowScrollTarget) {
						if (shouldResetScroll) continue;
					} else {
						const element = getElement(elementSelector);
						if (!element) continue;
						if (shouldResetScroll && scrollToTopSelectors) {
							scrollToTopElements ??= getScrollToTopElements(scrollToTopSelectors);
							if (scrollToTopElements.has(element)) continue;
						}
					}
					if (!toElementEntries) toElementEntries = scrollRestorationCache[cacheKey] = {};
					toElementEntries[elementSelector] ??= fromElementEntries[elementSelector];
				}
			}
		}
		ignoreScroll = true;
		try {
			const hash = event.toLocation.hash;
			const hashScrollIntoViewOptions = event.toLocation.state.__hashScrollIntoViewOptions ?? true;
			let windowRestored = false;
			if (shouldResetScroll) {
				if (!hash && scrollToTopSelectors) scrollToTopElements ??= getScrollToTopElements(scrollToTopSelectors);
				const skipWindowRestore = hash && hashScrollIntoViewOptions && hashNavigation;
				const elementEntries = scroll.e ? scrollRestorationCache[cacheKey] : void 0;
				if (elementEntries) for (const elementSelector in elementEntries) {
					const { scrollX, scrollY } = elementEntries[elementSelector];
					if (elementSelector === windowScrollTarget) {
						if (skipWindowRestore) continue;
						scrollTo({
							top: scrollY,
							left: scrollX,
							behavior
						});
						windowRestored = true;
					} else {
						const element = getElement(elementSelector);
						if (element) {
							element.scrollLeft = scrollX;
							element.scrollTop = scrollY;
							scrollToTopElements?.delete(element);
						}
					}
				}
				if (!hash) {
					const scrollOptions = {
						top: 0,
						left: 0,
						behavior
					};
					if (!windowRestored) scrollTo(scrollOptions);
					if (scrollToTopElements) for (const element of scrollToTopElements) element.scrollTo(scrollOptions);
				}
			}
			if (!windowRestored && hash && hashScrollIntoViewOptions) document.getElementById(hash)?.scrollIntoView(hashScrollIntoViewOptions);
		} finally {
			ignoreScroll = false;
		}
	});
}
// node_modules/@tanstack/router-core/dist/esm/qss.js
/**
* Program is a reimplementation of the `qss` package:
* Copyright (c) Luke Edwards luke.edwards05@gmail.com, MIT License
* https://github.com/lukeed/qss/blob/master/license.md
*
* This reimplementation uses modern browser APIs
* (namely URLSearchParams) and TypeScript while still
* maintaining the original functionality and interface.
*
* Update: this implementation has also been mangled to
* fit exactly our use-case (single value per key in encoding).
*/
/**
* Encodes an object into a query string.
* @param obj - The object to encode into a query string.
* @param stringify - An optional custom stringify function.
* @returns The encoded query string.
* @example
* ```
* // Example input: encode({ token: 'foo', key: 'value' })
* // Expected output: "token=foo&key=value"
* ```
*/
function encode(obj, stringify = String) {
	let result;
	for (const key in obj) {
		const val = obj[key];
		if (val !== void 0) (result ||= new URLSearchParams()).set(key, stringify(val));
	}
	return result ? result.toString() : "";
}
/**
* Converts a string value to its appropriate type (string, number, boolean).
* @param mix - The string value to convert.
* @returns The converted value.
* @example
* // Example input: toValue("123")
* // Expected output: 123
*/
function toValue(str) {
	if (!str) return "";
	if (str === "false") return false;
	if (str === "true") return true;
	return +str * 0 === 0 && +str + "" === str ? +str : str;
}
/**
* Decodes a query string into an object.
* @param str - The query string to decode.
* @returns The decoded key-value pairs in an object format.
* @example
* // Example input: decode("token=foo&key=value")
* // Expected output: { "token": "foo", "key": "value" }
*/
function decode(str) {
	const searchParams = new URLSearchParams(str);
	const result = Object.create(null);
	for (const [key, value] of searchParams.entries()) {
		const previousValue = result[key];
		if (previousValue == null) result[key] = toValue(value);
		else if (Array.isArray(previousValue)) previousValue.push(toValue(value));
		else result[key] = [previousValue, toValue(value)];
	}
	return result;
}
// node_modules/@tanstack/router-core/dist/esm/searchParams.js
var jsonStart = /^(?:\s|["[{\d-]|fa|nu|tr)/;
/** Default `parseSearch` that strips leading '?' and JSON-parses values. */
var defaultParseSearch = parseSearchWith(JSON.parse);
/** Default `stringifySearch` using JSON.stringify for complex values. */
var defaultStringifySearch = stringifySearchWith(JSON.stringify, JSON.parse);
/**
* Build a `parseSearch` function using a provided JSON-like parser.
*
* The returned function strips a leading `?`, decodes values, and attempts to
* JSON-parse string values using the given `parser`.
*
* @param parser Function to parse a string value (e.g. `JSON.parse`).
* @returns A `parseSearch` function compatible with `Router` options.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/custom-search-param-serialization
*/
function parseSearchWith(parser) {
	const isJsonParser = parser === JSON.parse;
	return (searchStr) => {
		if (searchStr[0] === "?") searchStr = searchStr.slice(1);
		const query = decode(searchStr);
		for (const key in query) {
			const value = query[key];
			if (typeof value === "string") {
				if (isJsonParser && !jsonStart.test(value)) continue;
				try {
					query[key] = parser(value);
				} catch (_err) {}
			}
		}
		return query;
	};
}
/**
* Build a `stringifySearch` function using a provided serializer.
*
* Non-primitive values are serialized with `stringify`. If a `parser` is
* supplied, string values that are parseable are re-serialized to ensure
* symmetry with `parseSearch`.
*
* @param stringify Function to serialize a value (e.g. `JSON.stringify`).
* @param parser Optional parser to detect parseable strings.
* @returns A `stringifySearch` function compatible with `Router` options.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/custom-search-param-serialization
*/
function stringifySearchWith(stringify, parser) {
	const isJsonParser = parser === JSON.parse;
	function stringifyValue(val) {
		if (val && typeof val === "object") try {
			return stringify(val);
		} catch (_err) {}
		else if (parser && typeof val === "string") {
			if (isJsonParser && !jsonStart.test(val)) return val;
			try {
				parser(val);
				return stringify(val);
			} catch (_err) {}
		}
		return val;
	}
	return (search) => {
		const searchStr = encode(search, stringifyValue);
		return searchStr ? `?${searchStr}` : "";
	};
}
// node_modules/@tanstack/router-core/dist/esm/rewrite.js
/** Compose multiple rewrite pairs into a single in/out rewrite. */
function composeRewrites(rewrites) {
	return {
		input: ({ url }) => {
			for (const rewrite of rewrites) url = executeRewriteInput(rewrite, url);
			return url;
		},
		output: ({ url }) => {
			for (let i = rewrites.length - 1; i >= 0; i--) url = executeRewriteOutput(rewrites[i], url);
			return url;
		}
	};
}
/** Create a rewrite pair that strips/adds a basepath on input/output. */
function rewriteBasepath(basepath, caseSensitive, rewrite) {
	const trimmedBasepath = trimPath(basepath);
	const normalizedBasepath = `/${trimmedBasepath}`;
	const checkBasepath = caseSensitive ? normalizedBasepath : normalizedBasepath.toLowerCase();
	const checkBasepathWithSlash = `${checkBasepath}/`;
	const basepathRewrite = {
		input: ({ url }) => {
			const pathname = caseSensitive ? url.pathname : url.pathname.toLowerCase();
			if (pathname === checkBasepath) url.pathname = "/";
			else if (pathname.startsWith(checkBasepathWithSlash)) url.pathname = url.pathname.slice(normalizedBasepath.length);
			return url;
		},
		output: ({ url }) => {
			url.pathname = cleanPath(`/${trimmedBasepath}${url.pathname}`);
			return url;
		}
	};
	return rewrite ? {
		input: ({ url }) => executeRewriteInput(rewrite, basepathRewrite.input({ url })),
		output: ({ url }) => basepathRewrite.output({ url: executeRewriteOutput(rewrite, url) })
	} : basepathRewrite;
}
/** Execute a location input rewrite if provided. */
function executeRewriteInput(rewrite, url) {
	const res = rewrite?.input?.({ url });
	if (res) {
		if (typeof res === "string") return new URL(res);
		else if (res instanceof URL) return res;
	}
	return url;
}
/** Execute a location output rewrite if provided. */
function executeRewriteOutput(rewrite, url) {
	const res = rewrite?.output?.({ url });
	if (res) {
		if (typeof res === "string") return new URL(res);
		else if (res instanceof URL) return res;
	}
	return url;
}
// node_modules/@tanstack/router-core/dist/esm/stores.js
/** SSR non-reactive createMutableStore */
function createNonReactiveMutableStore(initialValue) {
	let value = initialValue;
	return {
		get() {
			return value;
		},
		set(nextOrUpdater) {
			value = functionalUpdate(nextOrUpdater, value);
		}
	};
}
/** SSR non-reactive createReadonlyStore */
function createNonReactiveReadonlyStore(read) {
	return { get() {
		return read();
	} };
}
function createRouterStores(initialLocation, config) {
	const { createMutableStore, createReadonlyStore, batch } = config;
	const byRoute = /* @__PURE__ */ new Map();
	const status = createMutableStore("idle");
	const location = createMutableStore(initialLocation);
	const resolvedLocation = createMutableStore(void 0);
	const ids = createMutableStore([]);
	const matches = createReadonlyStore(() => ids.get().map((id) => byRoute.get(id).get()));
	const __store = createReadonlyStore(() => ({
		status: status.get(),
		isLoading: status.get() === "pending",
		matches: matches.get(),
		location: location.get(),
		resolvedLocation: resolvedLocation.get()
	}));
	function getMatchStore(routeId) {
		let matchStore = byRoute.get(routeId);
		if (!matchStore) {
			matchStore = createMutableStore(void 0);
			byRoute.set(routeId, matchStore);
		}
		return matchStore;
	}
	const store = {
		status,
		location,
		resolvedLocation,
		ids,
		matches,
		byRoute,
		__store,
		getMatchStore,
		setMatches
	};
	function setMatches(nextMatches) {
		const previousIds = ids.get();
		const nextIds = nextMatches.map((match) => match.routeId);
		batch(() => {
			if (!arraysEqual(previousIds, nextIds)) ids.set(nextIds);
			for (const id of previousIds) if (!nextIds.includes(id)) byRoute.get(id).set(() => void 0);
			for (const nextMatch of nextMatches) {
				const matchStore = getMatchStore(nextMatch.routeId);
				if (matchStore.get() !== nextMatch) matchStore.set(nextMatch);
			}
		});
	}
	return store;
}
// node_modules/@tanstack/history/dist/esm/index.js
var stateIndexKey = "__TSR_index";
var popStateEvent = "popstate";
var beforeUnloadEvent = "beforeunload";
/**
* Turn protocol-relative inputs such as "//evil.example" into paths
* such as "/evil.example", keeping navigation on the current origin.
*
* For HTTP(S) URLs, WHATWG parsing ignores leading C0 controls and spaces,
* removes tabs/newlines, and treats backslashes as slashes, so inputs like
* "/\evil.example" also need normalization. This only allocates when those
* rules would make the input protocol-relative.
*/
var protocolRelativePrefix = /^[\x00-\x20]*(?:[\\/][\t\n\r]*){2,}/;
function normalizeProtocolRelative(url) {
	const match = protocolRelativePrefix.exec(url);
	return match ? "/" + url.slice(match[0].length) : url;
}
function normalizeHref(href) {
	if (/[\x00-\x1f\x7f]/.test(href)) href = href.replace(/[\x00-\x1f\x7f]/g, (character) => "	\n\r".includes(character) ? "" : encodeURIComponent(character));
	return normalizeProtocolRelative(href);
}
function createHistory(opts) {
	let location = opts.getLocation();
	const subscribers = /* @__PURE__ */ new Set();
	const notify = (action) => {
		location = opts.getLocation();
		subscribers.forEach((subscriber) => subscriber({
			location,
			action
		}));
	};
	const handleIndexChange = (action) => {
		if (opts.notifyOnIndexChange ?? true) notify(action);
		else location = opts.getLocation();
	};
	const tryNavigation = async (args) => {
		const blockers = args.navigateOpts?.ignoreBlocker ? void 0 : opts.getBlockers?.();
		if (typeof document !== "undefined" && blockers?.length && (args.type === "PUSH" || args.type === "REPLACE")) for (const blocker of blockers) {
			const nextLocation = parseHref(args.path, args.state);
			if (await blocker.blockerFn({
				currentLocation: location,
				nextLocation,
				action: args.type
			})) {
				opts.onBlocked?.();
				return;
			}
		}
		args.task();
	};
	return {
		get location() {
			return location;
		},
		get length() {
			return opts.getLength();
		},
		subscribers,
		subscribe: (cb) => {
			subscribers.add(cb);
			return () => {
				subscribers.delete(cb);
			};
		},
		push: (path, state, navigateOpts) => {
			const currentIndex = location.state[stateIndexKey];
			state = assignKeyAndIndex(currentIndex + 1, state);
			tryNavigation({
				task: () => {
					opts.pushState(path, state);
					notify({ type: "PUSH" });
				},
				navigateOpts,
				type: "PUSH",
				path,
				state
			});
		},
		replace: (path, state, navigateOpts) => {
			const currentIndex = location.state[stateIndexKey];
			state = assignKeyAndIndex(currentIndex, state);
			tryNavigation({
				task: () => {
					opts.replaceState(path, state);
					notify({ type: "REPLACE" });
				},
				navigateOpts,
				type: "REPLACE",
				path,
				state
			});
		},
		go: (index, navigateOpts) => {
			tryNavigation({
				task: () => {
					opts.go(index, navigateOpts?.ignoreBlocker ?? false);
					handleIndexChange({
						type: "GO",
						index
					});
				},
				navigateOpts,
				type: "GO"
			});
		},
		back: (navigateOpts) => {
			tryNavigation({
				task: () => {
					opts.back(navigateOpts?.ignoreBlocker ?? false);
					handleIndexChange({ type: "BACK" });
				},
				navigateOpts,
				type: "BACK"
			});
		},
		forward: (navigateOpts) => {
			tryNavigation({
				task: () => {
					opts.forward(navigateOpts?.ignoreBlocker ?? false);
					handleIndexChange({ type: "FORWARD" });
				},
				navigateOpts,
				type: "FORWARD"
			});
		},
		canGoBack: () => location.state[stateIndexKey] !== 0,
		createHref: (str) => opts.createHref(str),
		block: (blocker) => {
			if (!opts.setBlockers) return () => {};
			const blockers = opts.getBlockers?.() ?? [];
			opts.setBlockers([...blockers, blocker]);
			return () => {
				const blockers = opts.getBlockers?.() ?? [];
				opts.setBlockers?.(blockers.filter((b) => b !== blocker));
			};
		},
		flush: () => opts.flush?.(),
		destroy: () => opts.destroy?.(),
		notify,
		_getBlockers: () => opts.getBlockers?.() ?? []
	};
}
function assignKeyAndIndex(index, state) {
	const key = createRandomKey();
	return {
		...state,
		key,
		__TSR_key: key,
		[stateIndexKey]: index
	};
}
/**
* Creates a history object that can be used to interact with the browser's
* navigation. This is a lightweight API wrapping the browser's native methods.
* It is designed to work with TanStack Router, but could be used as a standalone API as well.
* IMPORTANT: This API implements history throttling via a microtask to prevent
* excessive calls to the history API. In some browsers, calling history.pushState or
* history.replaceState in quick succession can cause the browser to ignore subsequent
* calls. This API smooths out those differences and ensures that your application
* state will *eventually* match the browser state. In most cases, this is not a problem,
* but if you need to ensure that the browser state is up to date, you can use the
* `history.flush` method to immediately flush all pending state changes to the browser URL.
* @param opts
* @param opts.getHref A function that returns the current href (path + search + hash)
* @param opts.createHref A function that takes a path and returns a href (path + search + hash)
* @returns A history instance
*/
function createBrowserHistory(opts) {
	const win = opts?.window ?? (typeof document !== "undefined" ? window : void 0);
	const originalPushState = win.history.pushState;
	const originalReplaceState = win.history.replaceState;
	let blockers = [];
	const _getBlockers = () => blockers;
	const _setBlockers = (newBlockers) => blockers = newBlockers;
	const createHref = (path) => normalizeHref(opts?.createHref ? opts.createHref(path) : path);
	const parseLocation = opts?.parseLocation ?? (() => parseHref(`${win.location.pathname}${win.location.search}${win.location.hash}`, win.history.state));
	if (!win.history.state?.__TSR_key && !win.history.state?.key) {
		const addedKey = createRandomKey();
		win.history.replaceState({
			[stateIndexKey]: 0,
			key: addedKey,
			__TSR_key: addedKey
		}, "");
	}
	let currentLocation = parseLocation();
	let rollbackLocation;
	let nextPopIsGo = false;
	let ignoreNextPop = false;
	let skipBlockerNextPop = false;
	let ignoreNextBeforeUnload = false;
	const getLocation = () => currentLocation;
	let next;
	const flush = () => {
		if (!next) return;
		history._ignoreSubscribers = true;
		(next[2] ? win.history.pushState : win.history.replaceState)(next[1], "", next[0]);
		history._ignoreSubscribers = false;
		next = void 0;
		rollbackLocation = void 0;
	};
	const queueHistoryAction = (isPush, destHref, state) => {
		const href = opts?.createHref ? createHref(destHref) : void 0;
		const hasPendingAction = !!next;
		if (!hasPendingAction) rollbackLocation = currentLocation;
		currentLocation = parseHref(destHref, state);
		next = [
			href ?? currentLocation.href,
			state,
			next?.[2] || isPush
		];
		if (!hasPendingAction) queueMicrotask(() => flush());
	};
	const onPushPop = (type) => {
		currentLocation = parseLocation();
		history.notify({ type });
	};
	const onPushPopEvent = async () => {
		ignoreNextBeforeUnload = false;
		if (ignoreNextPop) {
			ignoreNextPop = false;
			return;
		}
		const nextLocation = parseLocation();
		const delta = nextLocation.state[stateIndexKey] - currentLocation.state[stateIndexKey];
		const isForward = delta === 1;
		const isBack = delta === -1;
		const isGo = !isForward && !isBack || nextPopIsGo;
		nextPopIsGo = false;
		const action = isGo ? "GO" : isBack ? "BACK" : "FORWARD";
		const notify = isGo ? {
			type: "GO",
			index: delta
		} : { type: isBack ? "BACK" : "FORWARD" };
		if (skipBlockerNextPop) skipBlockerNextPop = false;
		else {
			const blockers = _getBlockers();
			if (typeof document !== "undefined" && blockers.length) {
				for (const blocker of blockers) if (await blocker.blockerFn({
					currentLocation,
					nextLocation,
					action
				})) {
					ignoreNextPop = true;
					win.history.go(-delta);
					history.notify(notify);
					return;
				}
			}
		}
		currentLocation = parseLocation();
		history.notify(notify);
	};
	const onBeforeUnload = (e) => {
		if (ignoreNextBeforeUnload) {
			ignoreNextBeforeUnload = false;
			return;
		}
		let shouldBlock = false;
		const blockers = _getBlockers();
		if (typeof document !== "undefined" && blockers.length) for (const blocker of blockers) {
			const shouldHaveBeforeUnload = blocker.enableBeforeUnload ?? true;
			if (shouldHaveBeforeUnload === true) {
				shouldBlock = true;
				break;
			}
			if (typeof shouldHaveBeforeUnload === "function" && shouldHaveBeforeUnload() === true) {
				shouldBlock = true;
				break;
			}
		}
		if (shouldBlock) {
			e.preventDefault();
			return e.returnValue = "";
		}
	};
	const history = createHistory({
		getLocation,
		getLength: () => win.history.length,
		pushState: (href, state) => queueHistoryAction(true, href, state),
		replaceState: (href, state) => queueHistoryAction(false, href, state),
		back: (ignoreBlocker) => {
			if (ignoreBlocker) {
				skipBlockerNextPop = true;
				ignoreNextBeforeUnload = true;
			}
			return win.history.back();
		},
		forward: (ignoreBlocker) => {
			if (ignoreBlocker) {
				skipBlockerNextPop = true;
				ignoreNextBeforeUnload = true;
			}
			win.history.forward();
		},
		go: (n, ignoreBlocker) => {
			nextPopIsGo = true;
			if (ignoreBlocker) {
				skipBlockerNextPop = true;
				ignoreNextBeforeUnload = true;
			}
			win.history.go(n);
		},
		createHref,
		flush,
		destroy: () => {
			win.history.pushState = originalPushState;
			win.history.replaceState = originalReplaceState;
			win.removeEventListener(beforeUnloadEvent, onBeforeUnload, { capture: true });
			win.removeEventListener(popStateEvent, onPushPopEvent);
		},
		onBlocked: () => {
			if (rollbackLocation && currentLocation !== rollbackLocation) currentLocation = rollbackLocation;
		},
		getBlockers: _getBlockers,
		setBlockers: _setBlockers,
		notifyOnIndexChange: false
	});
	history._ignoreNextBeforeUnload = (href) => {
		ignoreNextBeforeUnload = false;
		try {
			href = new URL(href, win.document.baseURI).href;
			ignoreNextBeforeUnload = /^https?:/.test(href) && (!href.includes("#") || href.split("#")[0] !== win.location.href.split("#")[0]);
		} catch {}
	};
	win.addEventListener(beforeUnloadEvent, onBeforeUnload, { capture: true });
	win.addEventListener(popStateEvent, onPushPopEvent);
	win.history.pushState = function(...args) {
		const res = originalPushState.apply(win.history, args);
		if (!history._ignoreSubscribers) onPushPop("PUSH");
		return res;
	};
	win.history.replaceState = function(...args) {
		const res = originalReplaceState.apply(win.history, args);
		if (!history._ignoreSubscribers) onPushPop("REPLACE");
		return res;
	};
	return history;
}
/**
* Create a hash-based history implementation.
* Useful for static hosts or environments without server URL rewriting.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/history-types
*/
function createHashHistory(opts) {
	const win = opts?.window ?? (typeof document !== "undefined" ? window : void 0);
	return createBrowserHistory({
		window: win,
		parseLocation: () => {
			const hash = win.location.hash;
			let hashIndex = hash.indexOf("#", 1);
			if (hashIndex < 0) hashIndex = hash.length;
			return parseHref(`${hash ? hash.slice(1, hashIndex) : "/"}${win.location.search}${hash.slice(hashIndex)}`, win.history.state);
		},
		createHref: (href) => `${win.location.pathname}${win.location.search}#${href}`
	});
}
/**
* Create an in-memory history implementation.
* Ideal for server rendering, tests, and non-DOM environments.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/history-types
*/
function createMemoryHistory(opts = { initialEntries: ["/"] }) {
	const entries = opts.initialEntries;
	let index = opts.initialIndex ? Math.min(Math.max(opts.initialIndex, 0), entries.length - 1) : entries.length - 1;
	const states = entries.map((_entry, index) => assignKeyAndIndex(index, void 0));
	const getLocation = () => parseHref(entries[index], states[index]);
	let blockers = [];
	const _getBlockers = () => blockers;
	const _setBlockers = (newBlockers) => blockers = newBlockers;
	return createHistory({
		getLocation,
		getLength: () => entries.length,
		pushState: (path, state) => {
			index = index < entries.length - 1 ? index + 1 : entries.length;
			states[index] = state;
			entries[index] = path;
			if (index < entries.length - 1) {
				entries.length = index + 1;
				states.length = index + 1;
			}
		},
		replaceState: (path, state) => {
			states[index] = state;
			entries[index] = path;
		},
		back: () => {
			index = Math.max(index - 1, 0);
		},
		forward: () => {
			index = Math.min(index + 1, entries.length - 1);
		},
		go: (n) => {
			index = Math.min(Math.max(index + n, 0), entries.length - 1);
		},
		createHref: normalizeHref,
		getBlockers: _getBlockers,
		setBlockers: _setBlockers
	});
}
function parseHref(href, state) {
	const sanitizedHref = normalizeHref(href);
	const hashIndex = sanitizedHref.indexOf("#");
	const searchIndex = sanitizedHref.indexOf("?");
	if (!state) {
		const key = createRandomKey();
		state = {
			[stateIndexKey]: 0,
			key,
			__TSR_key: key
		};
	}
	return {
		href: sanitizedHref,
		pathname: sanitizedHref.slice(0, hashIndex > -1 ? searchIndex > -1 ? Math.min(hashIndex, searchIndex) : hashIndex : searchIndex > -1 ? searchIndex : sanitizedHref.length),
		hash: hashIndex > -1 ? sanitizedHref.slice(hashIndex) : "",
		search: searchIndex > -1 ? sanitizedHref.slice(searchIndex, hashIndex === -1 ? void 0 : hashIndex) : "",
		state
	};
}
function createRandomKey() {
	return (Math.random() + 1).toString(36).slice(7);
}
// node_modules/@tanstack/router-core/dist/esm/router.js
function isExternalUrl(url, origin) {
	return url.protocol !== "http:" && url.protocol !== "https:" || url.origin !== origin || !!url.username || !!url.password;
}
function getUrlPath(url) {
	return url.pathname + url.search + url.hash;
}
function routeNeedsLoad(route) {
	return route.options.loader || route.options.beforeLoad || route.lazyFn || route.options.component?.preload || route.options.pendingComponent?.preload;
}
/**
* Convert an unknown error into a minimal, serializable object.
* Includes name and message (and stack in development).
*/
function defaultSerializeError(err) {
	if (err instanceof Error) {
		const obj = {
			name: err.name,
			message: err.message
		};
		obj.stack = err.stack;
		return obj;
	}
	return { data: err };
}
/**
* Compute whether path, href or hash changed between previous and current
* resolved locations.
*/
function getLocationChangeInfo(location, resolvedLocation) {
	return {
		fromLocation: resolvedLocation,
		toLocation: location,
		pathChanged: resolvedLocation?.pathname !== location.pathname,
		hrefChanged: resolvedLocation?.href !== location.href,
		hashChanged: resolvedLocation?.hash !== location.hash
	};
}
/**
* Return only state owned by the application, excluding volatile history
* bookkeeping. Mask payloads (`__tempLocation`/`__tempKey`) are kept: they
* distinguish otherwise-identical locations.
*/
function _getUserHistoryState({ key: _key, __TSR_key: _tsrKey, __TSR_index: _tsrIndex, __hashScrollIntoViewOptions: _hashScroll, ...state }) {
	return state;
}
function lifecycleEnd(matches) {
	return matches.findIndex((match) => match.status === "error" || match.status === "notFound" || match._notFound) + 1;
}
/** Run route lifecycle callbacks in leave/enter/stay phases. */
function runRouteLifecycle(router, previous, matches, previousEnd, nextEnd, owner) {
	if (previousEnd) previous = previous.slice(0, previousEnd);
	if (nextEnd) matches = matches.slice(0, nextEnd);
	for (const match of previous) {
		if (owner && router._tx !== owner) return;
		if (!matches.some((candidate) => candidate.routeId === match.routeId)) router.routesById[match.routeId].options.onLeave?.(match);
	}
	for (const match of matches) {
		if (owner && router._tx !== owner) return;
		router.routesById[match.routeId].options[previous.some((candidate) => candidate.routeId === match.routeId) ? "onStay" : "onEnter"]?.(match);
	}
}
/**
* Core, framework-agnostic router engine that powers TanStack Router.
*
* Provides navigation, matching, loading, preloading, caching and event APIs
* used by framework adapters (React/Solid). Prefer framework helpers like
* `createRouter` in app code.
*
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/RouterType
*/
var RouterCore = class {
	/**
	* @deprecated Use the `createRouter` function instead
	*/
	constructor(options, getStoreConfig) {
		this.tempLocationKey = `${Math.round(Math.random() * 1e7)}`;
		this._scroll = { n: true };
		this.subscribers = /* @__PURE__ */ new Set();
		this._cache = /* @__PURE__ */ new Map();
		this._committed = [];
		this.startTransition = async (fn) => {
			fn();
			return false;
		};
		this.update = (newOptions) => {
			if (newOptions.notFoundRoute) console.warn("The notFoundRoute API is deprecated and will be removed in the next major version. See https://tanstack.com/router/v1/docs/framework/react/guide/not-found-errors#migrating-from-notfoundroute for more info.");
			const prevOptions = this.options;
			this.options = {
				...prevOptions,
				...newOptions
			};
			this.isServer = this.options.isServer ?? void 0 ?? typeof document === "undefined";
			if (!this.isServer) this.staticLocations = /* @__PURE__ */ new WeakMap();
			this.protocolAllowlist = new Set(this.options.protocolAllowlist);
			if (!this.history || this.options.history && this.options.history !== this.history) {
				if (!this.options.history) {
					if (!this.isServer) this.history = createBrowserHistory();
				} else this.history = this.options.history;
			}
			this.origin = this.options.origin;
			if (!this.origin) {
				if (!this.isServer && window?.origin && window.origin !== "null") this.origin = window.origin;
				else this.origin = "http://localhost";
			}
			const nextBasepath = this.options.basepath ?? "/";
			const nextRewriteOption = this.options.rewrite;
			const rewriteChanged = this.basepath !== nextBasepath || prevOptions?.rewrite !== nextRewriteOption || prevOptions?.caseSensitive !== this.options.caseSensitive;
			if (rewriteChanged) {
				this.basepath = nextBasepath;
				this.rewrite = nextBasepath !== "/" && trimPath(nextBasepath) ? rewriteBasepath(nextBasepath, this.options.caseSensitive, nextRewriteOption) : nextRewriteOption;
			}
			if (this.history) this.updateLatestLocation();
			if (this.options.routeTree !== this.routeTree || this.isServer && prevOptions?.caseSensitive !== this.options.caseSensitive) {
				this.routeTree = this.options.routeTree;
				let processRouteTreeResult;
				processRouteTreeResult = this.buildRouteTree();
				this.setRoutes(processRouteTreeResult);
			}
			if (!this.stores) {
				if (this.latestLocation) {
					const config = this.getStoreConfig(this);
					this.batch = config.batch;
					this.stores = createRouterStores(this.latestLocation, config);
					if (!this.isServer) setupScrollRestoration(this);
				}
			} else if (rewriteChanged) this.stores.location.set(this.latestLocation);
		};
		this.updateLatestLocation = () => {
			this.latestLocation = this.parseLocation(this.history.location, this.latestLocation);
		};
		this.buildRouteTree = () => {
			const result = processRouteTree(this.routeTree, this.options.caseSensitive);
			if (this.options.routeMasks) processRouteMasks(this.options.routeMasks, result.processedTree);
			return {
				...result,
				resolvePathCache: createSieveCache(1e3)
			};
		};
		this.subscribe = (eventType, fn) => {
			const listener = {
				eventType,
				fn
			};
			this.subscribers.add(listener);
			return () => {
				this.subscribers.delete(listener);
			};
		};
		this.emit = (routerEvent) => {
			for (const listener of this.subscribers) if (listener.eventType === routerEvent.type) try {
				listener.fn(routerEvent);
			} catch (e) {
				console.error(e);
			}
		};
		this.parseLocation = (locationToParse, previousLocation) => {
			const parse = ({ pathname, search, hash, href }, state) => {
				if (!this.rewrite && !/[ \x00-\x1f\x7f\u0080-\uffff]/.test(pathname)) {
					const parsedSearch = this.options.parseSearch(search);
					const searchStr = this.options.stringifySearch(parsedSearch);
					return {
						href: pathname + searchStr + hash,
						publicHref: pathname + searchStr + hash,
						pathname: decodePath(pathname),
						external: false,
						searchStr,
						search: nullReplaceEqualDeep(previousLocation?.search, parsedSearch),
						hash: decodePath(hash.slice(1)),
						state: replaceEqualDeep(previousLocation?.state, state)
					};
				}
				const url = executeRewriteInput(this.rewrite, new URL(href, this.origin));
				const parsedSearch = this.options.parseSearch(url.search);
				const searchStr = this.options.stringifySearch(parsedSearch);
				url.search = searchStr;
				return {
					href: url.href.replace(url.origin, ""),
					publicHref: href,
					pathname: decodePath(normalizeProtocolRelative(url.pathname)),
					external: !!this.rewrite && isExternalUrl(url, this.origin),
					searchStr,
					search: nullReplaceEqualDeep(previousLocation?.search, parsedSearch),
					hash: decodePath(url.hash.slice(1)),
					state: replaceEqualDeep(previousLocation?.state, state)
				};
			};
			const location = parse(locationToParse, locationToParse.state);
			const { __tempLocation, __tempKey } = location.state;
			if (__tempLocation && (!__tempKey || __tempKey === this.tempLocationKey)) {
				const parsedTempLocation = parse(__tempLocation, {
					...__tempLocation.state,
					__tempLocation: void 0,
					key: location.state.key,
					__TSR_key: location.state.__TSR_key
				});
				parsedTempLocation.maskedLocation = location;
				return parsedTempLocation;
			}
			return location;
		};
		this.matchRoutes = (pathnameOrNext, locationSearchOrOpts, opts) => {
			if (typeof pathnameOrNext === "string") return this.matchRoutesInternal({
				pathname: pathnameOrNext,
				search: locationSearchOrOpts
			}, opts);
			return this.matchRoutesInternal(pathnameOrNext, locationSearchOrOpts);
		};
		this.getMatchedRoutes = (pathname) => {
			const rawParams = Object.create(null);
			const match = findRouteMatch(trimPathRight(pathname), this.processedTree, true);
			if (match) Object.assign(rawParams, match.rawParams);
			return [
				match?.branch || [this.routesById["__root__"]],
				rawParams,
				match?.route
			];
		};
		this.buildLocation = (opts) => {
			if (!this.isServer) {
				const cached = this.staticLocations.get(opts);
				if (cached) return cached;
			}
			let usedCurrent = false;
			const build = (dest = {}) => {
				if (dest.href) {
					const parsed = parseHref(dest.href, {});
					dest = {
						...dest,
						to: executeRewriteInput(this.rewrite, new URL(parsed.pathname, this.origin)).pathname,
						search: this.options.parseSearch(parsed.search),
						hash: parsed.hash.slice(1)
					};
				}
				const currentLocation = opts._fromLocation || this._pendingLocation || this.latestLocation;
				let lightweight;
				const current = () => {
					usedCurrent = true;
					return currentLocation;
				};
				const currentMatch = () => lightweight ??= this.matchRoutesLightweight(current());
				if (dest.from && dest._isNavigate) {
					const [allFromMatches] = this.getMatchedRoutes(dest.from);
					const [matchedRoutes, fullPath] = currentMatch();
					const matchedFrom = findLast(matchedRoutes, (d) => {
						return comparePaths(d.fullPath, dest.from);
					});
					const matchedCurrent = findLast(allFromMatches, (d) => {
						return comparePaths(d.fullPath, fullPath);
					});
					if (!matchedFrom && !matchedCurrent) console.warn(`Could not find match for from: ${dest.from}`);
				}
				const to = dest.to ? `${dest.to}` : ".";
				const nextTo = resolvePath(to[0] === "/" ? "" : dest.unsafeRelative === "path" ? current().pathname : dest.from ?? currentMatch()[1], to, this.options.trailingSlash, this.resolvePathCache);
				const destRoute = this.routesByPath[trimPathRight(nextTo)];
				const isTemplate = nextTo.includes("$");
				let destRoutes;
				if (destRoute) destRoutes = destRoute._branch ??= buildRouteBranch(destRoute);
				else if (isTemplate) destRoutes = [];
				else {
					const [matchedRoutes, rawParams, foundRoute] = this.getMatchedRoutes(nextTo);
					destRoutes = matchedRoutes;
					if (this.options.notFoundRoute && (!foundRoute || foundRoute.path !== "/" && rawParams["**"])) destRoutes = [...destRoutes, this.options.notFoundRoute];
				}
				const interpolation = isTemplate ? destRoute?._interpolation ?? parseSegments(false, { fullPath: nextTo }, 0) : void 0;
				let nextParams;
				for (const route of destRoutes) {
					const fn = route.options.params?.stringify ?? route.options.stringifyParams;
					if (fn) {
						const fromParams = currentMatch()[3];
						nextParams ??= resolveNextParams(dest.params, fromParams);
						if (!hasKeys(nextParams)) break;
						if (nextParams === fromParams) nextParams = Object.assign(createNull(), nextParams);
						try {
							Object.assign(nextParams, fn(nextParams));
						} catch {}
					}
				}
				nextParams ??= resolveNextParams(dest.params, needsInheritedParams(dest.params, interpolation) ? currentMatch()[3] : EMPTY_RECORD);
				const nextPathname = opts.leaveParams ? nextTo : normalizeProtocolRelative(decodePath(interpolation ? interpolatePath(nextTo, interpolation, nextParams, this.pathParamsDecoder) : nextTo));
				if (destRoute && !opts.leaveParams) try {
					const foundRoute = this.getMatchedRoutes(nextPathname)[2];
					if (foundRoute?.id !== destRoute.id) console.warn(`Generated path "${nextPathname}" for route "${destRoute.id}" matched route "${foundRoute?.id}" instead. This can happen when multiple route templates resolve to the same URL. Use the route template that matches the intended route, or adjust params.stringify if it changed the target path.`);
				} catch {}
				const middlewares = getSearchMiddlewares(destRoutes, opts._includeValidateSearch);
				const fromSearch = () => {
					let search = currentMatch()[2];
					if (opts._includeValidateSearch && this.options.search?.strict) {
						const validatedSearch = {};
						destRoutes.forEach((route) => {
							if (route.options.validateSearch) try {
								Object.assign(validatedSearch, validateSearch(route.options.validateSearch, {
									...validatedSearch,
									...search
								}));
							} catch {}
						});
						search = validatedSearch;
					}
					return search;
				};
				const nextSearch = middlewares.length ? applySearchMiddleware(middlewares, fromSearch(), dest) : dest.search === true ? fromSearch() : typeof dest.search === "function" ? dest.search(fromSearch()) : dest.search || EMPTY_RECORD;
				const searchStr = this.options.stringifySearch(nextSearch);
				const hash = dest.hash === true ? current().hash : typeof dest.hash === "function" ? dest.hash(current().hash) : dest.hash || void 0;
				const hashStr = hash ? `#${hash}` : "";
				const nextState = !dest.state ? EMPTY_RECORD : dest.state === true ? current().state : typeof dest.state === "function" ? dest.state(current().state) : dest.state;
				const fullPath = `${nextPathname}${searchStr}${hashStr}`;
				let href;
				let publicHref;
				let external = false;
				if (this.rewrite) {
					const url = new URL(fullPath, this.origin);
					const origin = url.origin;
					const rewrittenUrl = executeRewriteOutput(this.rewrite, url);
					href = getUrlPath(url);
					if (isExternalUrl(rewrittenUrl, origin)) {
						publicHref = rewrittenUrl.href;
						external = true;
					} else publicHref = normalizeProtocolRelative(getUrlPath(rewrittenUrl));
				} else {
					href = encodePathLikeUrl(fullPath);
					publicHref = href;
				}
				return {
					publicHref,
					href,
					pathname: nextPathname,
					search: nextSearch,
					searchStr,
					state: nextState,
					hash: hash ?? "",
					external,
					unmaskOnReload: dest.unmaskOnReload
				};
			};
			const next = build(opts);
			if (opts.mask) next.maskedLocation = build({
				from: opts.from,
				...opts.mask
			});
			else if (this.options.routeMasks) {
				const match = findFlatMatch(next.pathname, this.processedTree);
				if (match) {
					const params = Object.assign(createNull(), match.rawParams);
					const { from: _from, params: maskParams, ...maskProps } = match.route;
					const nextParams = resolveNextParams(maskParams, params);
					next.maskedLocation = build({
						from: opts.from,
						...maskProps,
						params: nextParams
					});
				}
			}
			if (!this.isServer && !usedCurrent && opts._fromLocation) this.staticLocations.set(opts, next);
			return next;
		};
		this.commitLocation = async ({ viewTransition, ignoreBlocker, ...next }) => {
			if (this.isServer) return;
			const nextLocation = next.maskedLocation ?? next;
			if (nextLocation.external && !this.isServer) return documentNavigation(this, nextLocation.publicHref, {
				replace: next.replace,
				ignoreBlocker
			});
			let historyAction;
			const isSameLocation = trimPathRight(this.latestLocation.href) === trimPathRight(next.href) && deepEqual(_getUserHistoryState(next.state), _getUserHistoryState(this.latestLocation.state));
			const previousCommitPromise = this._commitPromise;
			let resolve;
			const commitPromise = new Promise((done) => {
				resolve = done;
			});
			commitPromise.resolve = () => {
				resolve();
				previousCommitPromise?.resolve();
			};
			this._commitPromise = commitPromise;
			if (isSameLocation) this.load();
			else {
				let { maskedLocation, hashScrollIntoView, ...nextHistory } = next;
				if (maskedLocation) {
					nextHistory = {
						...maskedLocation,
						state: {
							...maskedLocation.state,
							__tempKey: void 0,
							__tempLocation: {
								...nextHistory,
								search: nextHistory.searchStr,
								state: {
									...nextHistory.state,
									__tempKey: void 0,
									__tempLocation: void 0,
									__TSR_key: void 0,
									key: void 0
								}
							}
						}
					};
					if (nextHistory.unmaskOnReload ?? this.options.unmaskOnReload ?? false) nextHistory.state.__tempKey = this.tempLocationKey;
				}
				nextHistory.state = {
					...nextHistory.state,
					__hashScrollIntoViewOptions: hashScrollIntoView ?? this.options.defaultHashScrollIntoView ?? true
				};
				this.shouldViewTransition = viewTransition;
				historyAction = next.replace ? "REPLACE" : "PUSH";
				this.history[historyAction === "REPLACE" ? "replace" : "push"](nextHistory.publicHref, nextHistory.state, { ignoreBlocker });
				if (!this.history.subscribers.size) this.load({ action: { type: historyAction } });
			}
			this._scroll.n = next.resetScroll ?? true;
			return this._commitPromise;
		};
		this.buildAndCommitLocation = ({ replace, resetScroll, hashScrollIntoView, viewTransition, ignoreBlocker, ...rest } = {}) => {
			if (this.isServer) return Promise.resolve();
			const location = this.buildLocation({
				...rest,
				_includeValidateSearch: true
			});
			this._pendingLocation = location;
			const commitPromise = this.commitLocation({
				...location,
				viewTransition,
				replace,
				resetScroll,
				hashScrollIntoView,
				ignoreBlocker
			});
			queueMicrotask(() => {
				if (this._pendingLocation === location) this._pendingLocation = void 0;
			});
			return commitPromise;
		};
		this.navigate = async ({ to, reloadDocument, href, publicHref, ...rest }) => {
			if (this.isServer) return;
			const hrefScheme = href ? getUrlScheme(href) : void 0;
			if (hrefScheme || reloadDocument) {
				if (to !== void 0 || !href) {
					const location = this.buildLocation({
						to,
						...rest
					});
					const publicLocation = location.maskedLocation ?? location;
					href ??= publicLocation.publicHref;
					publicHref ??= publicLocation.publicHref;
				}
				const reloadHref = !hrefScheme && publicHref ? publicHref : href;
				return documentNavigation(this, reloadHref, rest);
			}
			return this.buildAndCommitLocation({
				...rest,
				href,
				to,
				_isNavigate: true
			});
		};
		this.load = async (opts) => {
			if (this.isServer) return loadServerRoute(this, opts);
			this.updateLatestLocation();
			if (opts?.action) this._scroll.h = opts.action.type === "PUSH" || opts.action.type === "REPLACE";
			await loadClientRoute(this, opts);
		};
		this.startViewTransition = (fn) => {
			const shouldViewTransition = this.shouldViewTransition ?? this.options.defaultViewTransition;
			this.shouldViewTransition = void 0;
			if (shouldViewTransition && !(typeof document === "undefined") && typeof document.startViewTransition === "function") {
				let startViewTransitionParams;
				if (typeof shouldViewTransition === "object" && window.CSS?.supports?.("selector(:active-view-transition-type(a))")) {
					const next = this.latestLocation;
					const prevLocation = this.stores.resolvedLocation.get();
					const resolvedViewTransitionTypes = typeof shouldViewTransition.types === "function" ? shouldViewTransition.types(getLocationChangeInfo(next, prevLocation)) : shouldViewTransition.types;
					if (resolvedViewTransitionTypes === false) return fn();
					startViewTransitionParams = {
						update: fn,
						types: resolvedViewTransitionTypes
					};
				} else startViewTransitionParams = fn;
				return document.startViewTransition(startViewTransitionParams).updateCallbackDone;
			}
			return fn();
		};
		this.invalidate = (opts) => {
			const committedMatches = this._committed;
			const filter = opts?.filter;
			const preloads = this._preloads;
			const invalidIds = /* @__PURE__ */ new Set();
			const consider = (match) => {
				if (!filter || filter(match)) invalidIds.add(match.id);
			};
			committedMatches.forEach(consider);
			this._cache.forEach(consider);
			preloads?.forEach((matches) => matches.forEach(consider));
			this._tx?.[3].forEach(consider);
			const abort = [];
			for (const [controller, matches] of preloads ?? []) if (matches.some((match) => invalidIds.has(match.id))) {
				preloads.delete(controller);
				abort.push(controller);
			}
			const invalidate = (d) => {
				if (invalidIds.has(d.id)) {
					const route = this.routesById[d.routeId];
					const next = {
						...d,
						invalid: true,
						...(opts?.forcePending || d.status === "error" || d.status === "notFound") && routeNeedsLoad(route) ? {
							status: "pending",
							error: void 0
						} : void 0
					};
					d._flight = void 0;
					return next;
				}
				return d;
			};
			this._committed = committedMatches.map(invalidate);
			for (const [id, match] of this._cache) if (invalidIds.has(id)) {
				match.invalid = true;
				if (opts?.forcePending) match.status = "pending";
			}
			for (const id of invalidIds) {
				const flight = this._flights?.get(id);
				this._flights?.delete(id);
				if (flight && !flight[2]) abort.push(flight[1]);
			}
			for (const controller of abort) controller.abort();
			this.shouldViewTransition = false;
			return this.load({ sync: opts?.sync });
		};
		this.resolveRedirect = (redirect) => {
			const options = redirect.options;
			let href = redirect.headers.get("Location") || options.href;
			if (!href) {
				const location = this.buildLocation(options);
				href = (location.maskedLocation ?? location).publicHref || "/";
			}
			let scheme;
			if (protocolRelativePrefixRegex.test(href) || (scheme = getUrlScheme(href)) && !this.protocolAllowlist.has(scheme)) throw new Error(`Redirect blocked: unsafe protocol in href "${href}". Allowed protocols: ${Array.from(this.protocolAllowlist).join(", ")}.`);
			if (scheme === "http:" || scheme === "https:") {
				const url = new URL(href);
				if (url.pathname.startsWith("//")) href = url.href;
				else if (!isExternalUrl(url, this.origin)) {
					href = getUrlPath(url);
					scheme = void 0;
				}
			}
			if (scheme) options.reloadDocument = true;
			options.href = href;
			redirect.headers.set("Location", href);
			return redirect;
		};
		this.clearCache = (opts) => {
			const cached = this._cache;
			const preloads = this._preloads;
			const filter = opts?.filter;
			const discarded = [];
			const discardedIds = [];
			for (const [id, match] of cached) if (!filter || filter(match)) {
				discardedIds.push(id);
				discarded.push(match);
			}
			const abort = [];
			for (const [controller, matches] of preloads ?? []) if (!filter || matches.some(filter)) {
				abort.push(controller);
				discarded.push(...matches);
			}
			for (const id of discardedIds) cached.delete(id);
			for (const controller of abort) preloads.delete(controller);
			for (const match of discarded) {
				const flight = match._flight;
				match._flight = void 0;
				if (flight && !--flight[2]) {
					if (this._flights?.get(match.id) === flight) this._flights.delete(match.id);
					abort.push(flight[1]);
				}
			}
			for (const controller of abort) controller.abort();
		};
		this.loadRouteChunk = loadRouteChunk;
		this.preloadRoute = (opts) => preloadClientRoute(this, opts);
		this.matchRoute = (location, opts) => {
			const matchLocation = {
				...location,
				to: location.to ? resolvePath(location.from || "", location.to, this.options.trailingSlash, this.resolvePathCache) : void 0,
				params: location.params || {},
				leaveParams: true
			};
			const next = this.buildLocation(matchLocation);
			const isPending = this.stores.status.get() === "pending";
			if (opts?.pending && !isPending) return false;
			const baseLocation = opts?.pending ?? !isPending ? this.latestLocation : this.stores.resolvedLocation.get() || this.stores.location.get();
			const match = findSingleMatch(next.pathname, opts?.caseSensitive ?? false, opts?.fuzzy ?? false, baseLocation.pathname, this.processedTree);
			if (!match) return false;
			if (location.params) {
				if (!deepEqual(match.rawParams, location.params, true)) return false;
			}
			if (opts?.includeSearch ?? true) return deepEqual(baseLocation.search, next.search, true) ? match.rawParams : false;
			return match.rawParams;
		};
		this.getStoreConfig = getStoreConfig;
		if (options.pathParamsAllowedCharacters?.length) this.pathParamsDecoder = compileDecodeCharMap(options.pathParamsAllowedCharacters);
		this.update({
			defaultPreloadDelay: 50,
			defaultPendingMs: 1e3,
			defaultPendingMinMs: 500,
			context: void 0,
			...options,
			caseSensitive: options.caseSensitive ?? false,
			notFoundMode: options.notFoundMode ?? "fuzzy",
			stringifySearch: options.stringifySearch ?? defaultStringifySearch,
			parseSearch: options.parseSearch ?? defaultParseSearch,
			protocolAllowlist: options.protocolAllowlist ?? DEFAULT_PROTOCOL_ALLOWLIST
		});
		if (!(typeof document === "undefined")) self.__TSR_ROUTER__ = this;
	}
	isShell() {
		return !!this.options.isShell;
	}
	get state() {
		return this.stores.__store.get();
	}
	setRoutes(caches) {
		Object.assign(this, caches);
		this.lightweightCache = /* @__PURE__ */ new WeakMap();
		if (!this.isServer) this.staticLocations = /* @__PURE__ */ new WeakMap();
		const notFoundRoute = this.options.notFoundRoute;
		if (notFoundRoute) {
			notFoundRoute.init(99999999999);
			if (this.routesById[notFoundRoute.id] !== notFoundRoute) notFoundRoute._interpolation = parseSegments(false, notFoundRoute, 0);
			this.routesById[notFoundRoute.id] = notFoundRoute;
		}
	}
	matchRoutesInternal(next, opts) {
		const [initialMatchedRoutes, rawParams, foundRoute] = this.getMatchedRoutes(next.pathname);
		let matchedRoutes = initialMatchedRoutes;
		let isGlobalNotFound = false;
		if (foundRoute ? foundRoute.path !== "/" && rawParams["**"] : trimPathRight(next.pathname)) {
			if (this.options.notFoundRoute) matchedRoutes = [...matchedRoutes, this.options.notFoundRoute];
			else isGlobalNotFound = true;
		}
		const _notFoundRouteId = isGlobalNotFound ? findGlobalNotFoundRouteId(this.options.notFoundMode, matchedRoutes) : void 0;
		const matches = new Array(matchedRoutes.length);
		const committed = this._committed;
		const previousAt = (route, index) => {
			const match = committed[index];
			return match?.routeId === route.id ? match : route === this.options.notFoundRoute ? committed.find((candidate) => candidate.routeId === route.id) : void 0;
		};
		let strictParams;
		for (let index = 0; index < matchedRoutes.length; index++) {
			const route = matchedRoutes[index];
			const parentMatch = matches[index - 1];
			let preMatchSearch;
			let strictMatchSearch;
			let searchError;
			{
				const parentSearch = parentMatch?.search ?? next.search;
				const parentStrictSearch = parentMatch?._strictSearch ?? void 0;
				try {
					const strictSearch = validateSearch(route.options.validateSearch, { ...parentSearch }) ?? void 0;
					preMatchSearch = {
						...parentSearch,
						...strictSearch
					};
					strictMatchSearch = {
						...parentStrictSearch,
						...strictSearch
					};
				} catch (err) {
					let searchParamError = err;
					if (!(err instanceof SearchParamError)) searchParamError = new SearchParamError(err.message, { cause: err });
					if (opts?.throwOnError) throw searchParamError;
					preMatchSearch = parentSearch;
					strictMatchSearch = {};
					searchError = searchParamError;
				}
			}
			let loaderDeps = "";
			let loaderDepsHash = "";
			try {
				loaderDeps = route.options.loaderDeps?.({ search: preMatchSearch }) ?? "";
				loaderDepsHash = loaderDeps ? JSON.stringify(loaderDeps) || "" : "";
			} catch (cause) {
				if (opts?.throwOnError) throw cause;
				searchError ??= cause;
			}
			const usedParams = createNull();
			const interpolatedPath = route._interpolation ? interpolatePath(route.fullPath, route._interpolation, rawParams, this.pathParamsDecoder, usedParams) : route.fullPath;
			const matchId = route.id + interpolatedPath + loaderDepsHash;
			const previousMatch = previousAt(route, index);
			const existingMatch = opts?._rematerialize ? void 0 : this._cache.get(matchId) ?? (previousMatch?.id === matchId ? previousMatch : void 0);
			strictParams = existingMatch?._strictParams ?? Object.assign(usedParams, strictParams);
			let paramsError;
			if (!existingMatch) try {
				extractStrictParams(route, strictParams);
			} catch (err) {
				if (isNotFound(err) || isRedirect(err)) paramsError = err;
				else paramsError = new PathParamError(err.message, { cause: err });
				if (opts?.throwOnError) throw paramsError;
			}
			const cause = previousMatch ? "stay" : "enter";
			let match;
			if (existingMatch) match = {
				...existingMatch,
				cause,
				search: previousMatch ? nullReplaceEqualDeep(previousMatch.search, preMatchSearch) : nullReplaceEqualDeep(existingMatch.search, preMatchSearch),
				_strictSearch: strictMatchSearch,
				searchError
			};
			else {
				const status = routeNeedsLoad(route) ? "pending" : "success";
				match = {
					id: matchId,
					ssr: this.isServer ? void 0 : route.options.ssr,
					index,
					routeId: route.id,
					params: previousMatch?.params ?? strictParams,
					_strictParams: strictParams,
					pathname: interpolatedPath,
					updatedAt: Date.now(),
					search: previousMatch ? nullReplaceEqualDeep(previousMatch.search, preMatchSearch) : preMatchSearch,
					_strictSearch: strictMatchSearch,
					searchError,
					status,
					isFetching: false,
					error: void 0,
					paramsError,
					context: {},
					abortController: opts?._controller ?? new AbortController(),
					cause,
					loaderDeps: previousMatch ? replaceEqualDeep(previousMatch.loaderDeps, loaderDeps) : loaderDeps,
					invalid: false,
					preload: false,
					staticData: route.options.staticData || {},
					fullPath: route.fullPath
				};
			}
			const _notFound = _notFoundRouteId === route.id;
			if (match._notFound && !_notFound) match.error = void 0;
			match._notFound = _notFound;
			matches[index] = match;
		}
		for (let index = 0; index < matches.length; index++) {
			const match = matches[index];
			match.params = match.cause === "stay" ? nullReplaceEqualDeep(match.params, strictParams) : strictParams;
			if (opts?._controller) match.context = {};
		}
		return matches;
	}
	/**
	* Lightweight route matching for buildLocation.
	* Only computes fullPath, accumulated search, and params - skipping expensive
	* operations like AbortController, loaderDeps, and full match objects.
	*/
	matchRoutesLightweight(location) {
		const lastRouteId = last(this.stores.ids.get());
		const lastStateMatch = lastRouteId ? this.stores.byRoute.get(lastRouteId).get() : void 0;
		const lastStateMatchId = lastStateMatch?.id;
		const cached = this.lightweightCache.get(location);
		if (cached && cached[0] === lastStateMatchId) return cached[1];
		const [matchedRoutes, rawParams] = this.getMatchedRoutes(location.pathname);
		const lastRoute = last(matchedRoutes);
		const accumulatedSearch = { ...location.search };
		for (const route of matchedRoutes) try {
			Object.assign(accumulatedSearch, validateSearch(route.options.validateSearch, accumulatedSearch));
		} catch {}
		const canReuseParams = lastStateMatch && lastStateMatch.routeId === lastRoute.id && lastStateMatch.pathname === location.pathname;
		let params;
		if (canReuseParams) params = lastStateMatch.params;
		else {
			const strictParams = rawParams;
			for (const route of matchedRoutes) try {
				extractStrictParams(route, strictParams);
			} catch {}
			params = strictParams;
		}
		const result = [
			matchedRoutes,
			lastRoute.fullPath,
			accumulatedSearch,
			params
		];
		this.lightweightCache.set(location, [lastStateMatchId, result]);
		return result;
	}
};
async function documentNavigation(router, href, { replace, ignoreBlocker }) {
	if (isDangerousProtocol(href, router.protocolAllowlist)) {
		console.warn(`Blocked navigation to dangerous protocol: ${href}`);
		return;
	}
	if (!ignoreBlocker) {
		const blockers = router.history._getBlockers();
		for (const blocker of blockers) if (blocker?.blockerFn) {
			if (await blocker.blockerFn({
				currentLocation: router.history.location,
				nextLocation: router.history.location,
				action: replace ? "REPLACE" : "PUSH"
			})) return;
		}
	}
	router.history._ignoreNextBeforeUnload?.(href);
	if (replace) window.location.replace(href);
	else window.location.href = href;
}
RouterCore.prototype._replaceRouteChunk = replaceRouteChunk;
RouterCore.prototype._refreshRoute = async function() {
	this._serverResult = void 0;
	this.updateLatestLocation();
	await refreshClientRoute(this);
};
/** Error thrown when search parameter validation fails. */
var SearchParamError = class extends Error {};
/** Error thrown when path parameter parsing/validation fails. */
var PathParamError = class extends Error {};
var normalize$2 = (str) => str.endsWith("/") && str.length > 1 ? str.slice(0, -1) : str;
function comparePaths(a, b) {
	return normalize$2(a) === normalize$2(b);
}
/**
* Lazily import a module function and forward arguments to it, retaining
* parameter and return types for the selected export key.
*/
function lazyFn(fn, key) {
	return async (...args) => {
		return (await fn())[key || "default"](...args);
	};
}
function validateSearch(validateSearch, input) {
	if (validateSearch == null) return {};
	if ("~standard" in validateSearch) {
		const result = validateSearch["~standard"].validate(input);
		if (result instanceof Promise) throw new SearchParamError("Async validation not supported");
		if (result.issues) throw new SearchParamError(JSON.stringify(result.issues, void 0, 2), { cause: result });
		return result.value;
	}
	if ("parse" in validateSearch) return validateSearch.parse(input);
	if (typeof validateSearch === "function") return validateSearch(input);
	return {};
}
function resolveNextParams(spec, base) {
	if (spec === void 0 || spec === true) return base;
	const next = Object.create(null);
	if (spec === false || spec === null) return next;
	if (typeof spec === "function") {
		Object.assign(next, base);
		return Object.assign(next, spec(next));
	}
	return Object.assign(next, base, spec);
}
function needsInheritedParams(spec, interpolation) {
	if (typeof spec === "function") return true;
	if (!interpolation || spec === false || spec === null) return false;
	return spec === void 0 || spec === true || interpolation.some((part) => typeof part !== "string" && !hasOwn.call(spec, part[1]));
}
var EMPTY_RECORD = Object.freeze({});
function getSearchMiddlewares(destRoutes, includeValidateSearch) {
	const middlewares = [];
	for (let i = 0; i < destRoutes.length; i++) {
		const routeOptions = destRoutes[i].options;
		if ("search" in routeOptions) {
			if (routeOptions.search?.middlewares) middlewares.push(...routeOptions.search.middlewares);
		} else if (routeOptions.preSearchFilters || routeOptions.postSearchFilters) {
			const legacyMiddleware = ({ search, next }) => {
				const result = next(routeOptions.preSearchFilters ? routeOptions.preSearchFilters.reduce((prev, next) => next(prev), search) : search);
				return routeOptions.postSearchFilters ? routeOptions.postSearchFilters.reduce((prev, next) => next(prev), result) : result;
			};
			middlewares.push(legacyMiddleware);
		}
		const routeValidateSearch = routeOptions.validateSearch;
		if (includeValidateSearch && routeValidateSearch) {
			const validate = ({ search, next, meta }) => {
				const result = next(search);
				try {
					const validated = validateSearch(routeValidateSearch, result);
					if (meta && validated) {
						for (const key in validated) if (!(key in result)) (meta.defaulted ||= /* @__PURE__ */ new Map()).set(key, validated[key]);
					}
					return {
						...result,
						...validated
					};
				} catch {}
				return result;
			};
			middlewares.push(validate);
		}
	}
	return middlewares;
}
function applySearchMiddleware(middlewares, search, dest) {
	const applyNext = (index, currentSearch, meta) => {
		if (index >= middlewares.length) {
			if (!dest.search) return {};
			if (dest.search === true) return currentSearch;
			const result = functionalUpdate(dest.search, currentSearch);
			if (meta) meta.explicit = result;
			return result;
		}
		const next = (newSearch, collectMeta) => {
			if (collectMeta) {
				const nextMeta = meta || {};
				return {
					search: applyNext(index + 1, newSearch, nextMeta),
					meta: nextMeta
				};
			}
			return applyNext(index + 1, newSearch, meta);
		};
		return middlewares[index]({
			search: currentSearch,
			next,
			meta
		});
	};
	return applyNext(0, search);
}
function findGlobalNotFoundRouteId(notFoundMode, routes) {
	if (notFoundMode !== "root") {
		let fallback;
		for (let i = routes.length - 1; i >= 0; i--) {
			const route = routes[i];
			if (route.options.notFoundComponent) return route.id;
			fallback ||= route.children && route.id;
		}
		if (fallback) return fallback;
	}
	return rootRouteId;
}
function extractStrictParams(route, accumulatedParams) {
	const parseParams = route.options.params?.parse ?? route.options.parseParams;
	if (parseParams) Object.assign(accumulatedParams, parseParams(accumulatedParams));
}
// node_modules/@tanstack/router-core/dist/esm/load-client.js
function replaceRouteChunk(route, lazyFn) {
	route.lazyFn = lazyFn ?? route.lazyFn;
	route._lazy = void 0;
}
function preloadComponent(route, type) {
	return route.options[type]?.preload?.();
}
function loadComponents(route, onPendingReady) {
	const component = preloadComponent(route, "component");
	let pending = preloadComponent(route, "pendingComponent");
	if (onPendingReady) {
		if (pending) pending = pending.then(onPendingReady);
		else onPendingReady();
	}
	if (component && pending) return Promise.all([component, pending]).then(() => {});
	return component ?? pending;
}
function loadRouteChunk(route, componentType, onPendingReady) {
	const afterLazy = () => componentType === false ? void 0 : componentType ? preloadComponent(route, componentType) : loadComponents(route, onPendingReady);
	const current = route._lazy;
	if (current) return current === true ? afterLazy() : current.then(afterLazy);
	if (!route.lazyFn) return afterLazy();
	const promise = route.lazyFn().then((lazyRoute) => {
		if (route._lazy === promise) {
			const { id: _id, ...options } = lazyRoute.options;
			Object.assign(route.options, options);
			route._lazy = true;
		}
	}, (error) => {
		if (route._lazy === promise) route._lazy = void 0;
		throw error;
	});
	route._lazy = promise;
	return promise.then(afterLazy);
}
/** Return the structural lane through the first terminal render boundary. */
function _getRenderedMatches(matches) {
	const end = matches.findIndex((match) => match.status !== "success" || match._notFound) + 1;
	return end && end < matches.length ? matches.slice(0, end) : matches;
}
/**
* Truthy when the transaction publishing `location` leaves `routeId` out of its
* matches, so subscribers scoped to that route can skip the publication: the
* route unmounts when the transaction commits, and a transaction that ends
* otherwise is superseded or redirected by a newer publication. Only valid
* synchronously inside the publication: the transaction's matches are emptied
* at commit and before following a redirect. Publications without a matching
* transaction (hydration) and scopes without a route never depart.
*/
function _isRouteDeparting(router, routeId, location) {
	const tx = router._tx;
	return routeId && tx?.[2] === location && !tx[3].some((match) => match.routeId === routeId);
}
/** Return the lane whose document assets belong to the current presentation. */
function _getAssetMatches(matches) {
	let end = matches.length;
	for (let index = 0; index < end; index++) {
		const match = matches[index];
		if (match._assetEnd !== void 0) {
			end = Math.min(end, Math.max(index + 1, match._assetEnd));
			continue;
		}
		if (match.status !== "success" || match._notFound) {
			end = index + 1;
			break;
		}
	}
	return end < matches.length ? matches.slice(0, end) : matches;
}
var SUCCESS$1 = 0;
var ERROR$1 = 1;
var NOT_FOUND$1 = 2;
var REDIRECTED$1 = 3;
var CANCELED_OUTCOME = [4];
function isControl(result) {
	return typeof result[0] === "number";
}
function waitFor$1(value, signal) {
	if (signal.aborted) return Promise.race([Promise.reject(signal), value]);
	return new Promise((resolve, reject) => {
		const abort = () => reject(signal);
		signal.addEventListener("abort", abort, { once: true });
		Promise.resolve(value).then(resolve, reject).then(() => signal.removeEventListener("abort", abort));
	});
}
function getRoute$1(router, match) {
	return router.routesById[match.routeId];
}
function normalize$1(value, rejected, routeId) {
	if (isRedirect(value)) return [REDIRECTED$1, value];
	if (isNotFound(value)) {
		value.routeId ||= routeId;
		return [NOT_FOUND$1, value];
	}
	if (!rejected) return [SUCCESS$1, value];
	if (typeof value?.then === "function") value = new Error("A Promise was thrown", { cause: value });
	return [ERROR$1, value];
}
function normalizeError$1(route, cause) {
	let outcome = normalize$1(cause, true, route.id);
	if (outcome[0] !== ERROR$1) return outcome;
	try {
		route.options.onError?.(outcome[1]);
	} catch (onErrorCause) {
		outcome = normalize$1(onErrorCause, true, route.id);
	}
	return outcome;
}
function normalizeLaneError(router, lane, route, cause, options) {
	if (options[0].signal.aborted) return CANCELED_OUTCOME;
	return materializeRedirect$1(router, lane, route, normalizeError$1(route, cause), options);
}
async function contextualize$1(router, lane, options, end, planSuccessfulLane, retainedEnd) {
	const [location, matches] = lane;
	const signal = options[0].signal;
	const preload = !!options[3];
	for (let index = options[6] ?? 0; index < end; index++) {
		const match = matches[index];
		const route = getRoute$1(router, match);
		match.abortController = options[0];
		const parentContext = matches[index - 1]?.context ?? router.options.context ?? {};
		const common = {
			params: match.params,
			location,
			navigate: (opts) => router.navigate({
				...opts,
				_fromLocation: location
			}),
			buildLocation: router.buildLocation,
			cause: preload ? "preload" : match.cause,
			abortController: options[0],
			preload,
			matches,
			routeId: route.id
		};
		try {
			const routeContext = match._ctx ||= route.options.context ? route.options.context({
				...common,
				deps: match.loaderDeps,
				context: parentContext
			}) || {} : void 0;
			match.context = {
				...parentContext,
				...routeContext
			};
		} catch (cause) {
			releaseFlight(router, match);
			return [index, normalizeLaneError(router, lane, route, cause, options)];
		}
		if (signal.aborted) return [index, CANCELED_OUTCOME];
		const validationError = match.paramsError ?? match.searchError;
		if (validationError !== void 0) {
			releaseFlight(router, match);
			return [index, normalizeLaneError(router, lane, route, validationError, options)];
		}
		const beforeLoad = route.options.beforeLoad;
		if (!beforeLoad) continue;
		const previousStatus = match.status;
		if (index >= retainedEnd) {
			match.status = "pending";
			options[7]?.();
		}
		try {
			setFetching(router, match, "beforeLoad", options[0]);
			const value = beforeLoad({
				...common,
				search: match.search,
				context: match.context,
				...router.options.additionalContext
			});
			const result = await (typeof value?.then === "function" ? waitFor$1(value, signal) : value);
			if (signal.aborted) return [index, CANCELED_OUTCOME];
			const outcome = materializeRedirect$1(router, lane, route, normalize$1(result, false, route.id), options);
			if (outcome[0] !== SUCCESS$1) {
				releaseFlight(router, match);
				return [index, outcome];
			}
			match.context = {
				...match.context,
				...result
			};
		} catch (cause) {
			releaseFlight(router, match);
			return [index, normalizeLaneError(router, lane, route, cause, options)];
		} finally {
			match.status = previousStatus;
			setFetching(router, match, false, options[0]);
		}
	}
	planSuccessfulLane();
}
function releaseOwnedFlight(router, match, flight) {
	if (!flight || --flight[2]) return;
	if (router._flights?.get(match.id) === flight) {
		const current = router._tx;
		if (current && !current[0].signal.aborted && !current[3].includes(match) && current[3].some((candidate) => candidate.id === match.id) && current[3].some((candidate) => candidate.isFetching === "beforeLoad")) return;
		router._flights.delete(match.id);
	}
	return flight[1];
}
function releaseFlight(router, match) {
	const flight = match._flight;
	match._flight = void 0;
	releaseOwnedFlight(router, match, flight)?.abort();
}
/**
* Not passing in a `next` ownership recipient
* is equivalent to discarding the match resources
*/
function transferMatchResources(router, previous, next, deferSameIdFlight) {
	const abort = [];
	for (const match of previous) if (!next?.includes(match)) {
		const flight = match._flight;
		match._flight = void 0;
		if (deferSameIdFlight && flight?.[2] === 1 && router._flights?.get(match.id) === flight && next?.some((candidate) => candidate.id === match.id)) flight[2] = 0;
		else {
			const controller = releaseOwnedFlight(router, match, flight);
			if (controller) abort.push(controller);
		}
	}
	for (const controller of abort) controller.abort();
}
function acquireMatchResources(matches) {
	for (const match of matches) {
		const flight = match._flight;
		if (flight) flight[2]++;
	}
}
function setFetching(router, match, value, owner) {
	match.isFetching = value;
	if (owner && router._tx?.[0] !== owner) return;
	const store = router.stores.byRoute.get(match.routeId);
	const presented = store?.get();
	if (presented?.id === match.id) store.set({
		...presented,
		isFetching: value
	});
}
function getLoaderContext$1(router, lane, match, route, controller, parentMatchPromise, preload) {
	const location = lane[0];
	return {
		params: match.params,
		location,
		navigate: (opts) => router.navigate({
			...opts,
			_fromLocation: location
		}),
		cause: preload ? "preload" : match.cause,
		abortController: controller,
		preload,
		deps: match.loaderDeps,
		parentMatchPromise,
		context: match.context,
		route,
		...router.options.additionalContext
	};
}
async function loadResource(router, lane, match, route, loader, parentMatchPromise, options) {
	const owner = options[0];
	const signal = owner.signal;
	if (signal.aborted) return CANCELED_OUTCOME;
	if (!loader) return [SUCCESS$1, void 0];
	let flight = match._flight;
	setFetching(router, match, "loader", owner);
	try {
		if (!flight) {
			const controller = new AbortController();
			flight = [
				Promise.resolve().then(() => loader(getLoaderContext$1(router, lane, match, route, controller, parentMatchPromise, !!options[3]))).then((value) => normalize$1(value, false, route.id), (cause) => normalize$1(cause, true, route.id)).then((result) => {
					if (result[0] !== SUCCESS$1 && router._flights?.get(match.id) === flight) {
						router._flights.delete(match.id);
						if (!flight[2]) controller.abort();
					}
					return result[0] === ERROR$1 && flight[2] ? normalizeError$1(route, result[1]) : result;
				}),
				controller,
				1
			];
			(router._flights ??= /* @__PURE__ */ new Map()).set(match.id, flight);
		}
		match._flight = flight;
		match.abortController = flight[1];
		return materializeRedirect$1(router, lane, route, await waitFor$1(flight[0], signal), options);
	} catch (cause) {
		if (cause !== signal || !signal.aborted) throw cause;
		releaseFlight(router, match);
		return CANCELED_OUTCOME;
	} finally {
		setFetching(router, match, false, owner);
	}
}
function settleInto(match, result, preload) {
	if (result[0] === REDIRECTED$1) return;
	match.status = "success";
	match.error = void 0;
	if (result[0] === SUCCESS$1) {
		match.loaderData = result[1];
		match.invalid = false;
		match.updatedAt = Date.now();
		match.preload = preload;
	} else match.invalid = true;
}
function cacheLoaderMatch(router, match, planned) {
	const current = router._cache.get(match.id);
	if (current !== planned || router._committed.some((candidate) => candidate.id === match.id && candidate._flight === match._flight)) return;
	const cached = {
		...match,
		_notFound: void 0,
		context: {}
	};
	if (cached._flight) cached._flight[2]++;
	router._cache.set(match.id, cached);
	if (current) releaseFlight(router, current);
}
function getParentSnapshot(match, outcome) {
	if (outcome[0] === ERROR$1 || outcome[0] === NOT_FOUND$1) return {
		...match,
		status: outcome[0] === ERROR$1 ? "error" : "notFound",
		error: outcome[1],
		_flight: void 0
	};
	return match;
}
function createLoaderTask$1(router, lane, index, tasks, semanticParent, options, retainedEnd) {
	const match = lane[1][index];
	const route = getRoute$1(router, match);
	const preload = !!options[3];
	const plannedCacheMatch = router._cache.get(match.id);
	let configured;
	let reload = false;
	let reloadFailure;
	try {
		if (match.status === "success") {
			configured = route.options.shouldReload;
			if (typeof configured === "function") configured = configured(getLoaderContext$1(router, lane, match, route, options[0], semanticParent, preload));
			if (options[0].signal.aborted) reloadFailure = CANCELED_OUTCOME;
		}
		if (!reloadFailure) {
			if (match.status !== "success") reload = true;
			else {
				const staleAge = preload || match.preload ? route.options.preloadStaleTime ?? router.options.defaultPreloadStaleTime ?? 3e4 : route.options.staleTime ?? router.options.defaultStaleTime ?? 0;
				reload = !!(match.invalid || configured || configured === void 0 && Date.now() - match.updatedAt >= staleAge && (options[5] || match.cause === "enter" || options[2].some((candidate) => candidate.routeId === match.routeId && candidate.id !== match.id)));
			}
		}
	} catch (cause) {
		match.invalid = true;
		releaseFlight(router, match);
		reloadFailure = normalizeLaneError(router, lane, route, cause, options);
	}
	const routeLoader = route.options.loader;
	const isLoaderFn = typeof routeLoader === "function";
	const loader = isLoaderFn ? routeLoader : routeLoader?.handler;
	const preloadable = !preload || route.options.preload !== false;
	let donor = preloadable && routeLoader && !router._tx?.[6] ? router._flights?.get(match.id) : void 0;
	if (donor === match._flight || reloadFailure) donor = void 0;
	else if (donor && !reload && !preload && configured === void 0) reload = true;
	else if (!reload) donor = void 0;
	const background = !!(routeLoader && reload && match.status === "success" && !preload && !options[4] && ((isLoaderFn ? void 0 : routeLoader.staleReloadMode) ?? router.options.defaultStaleReloadMode) !== "blocking");
	const loaded = reload && preloadable;
	const blocking = loaded && !background && (match.status !== "success" || !!routeLoader);
	const onReady = index >= retainedEnd ? options[7] : void 0;
	const onLazyReady = route.lazyFn && route._lazy !== true ? onReady : void 0;
	if (loaded && !routeLoader) {
		match.invalid = false;
		match.updatedAt = Date.now();
	}
	if (donor) donor[2]++;
	if (blocking) {
		const acceptedFlight = match._flight;
		match._flight = donor;
		releaseOwnedFlight(router, match, acceptedFlight)?.abort();
		if (index >= retainedEnd) match.status = "pending";
		onReady?.();
	}
	if (!loaded) match.isFetching = false;
	const outcome = !reloadFailure && blocking ? loadResource(router, lane, match, route, loader, semanticParent, options).then((result) => {
		settleInto(match, result, preload);
		if (result[0] === SUCCESS$1) {
			if (routeLoader && !options[0].signal.aborted) cacheLoaderMatch(router, match, plannedCacheMatch);
			if (index >= retainedEnd) match.status = "pending";
		}
		return result;
	}) : Promise.resolve(reloadFailure ?? [SUCCESS$1, match.loaderData]);
	const chunkFailure = (async () => {
		try {
			const chunk = loadRouteChunk(route, void 0, onLazyReady);
			if (chunk) await waitFor$1(chunk, options[0].signal);
		} catch (cause) {
			if (!lane[1].some((candidate, candidateIndex) => candidateIndex <= index && (candidate.status === "error" || candidate.status === "notFound" || candidate._notFound))) return [index, normalizeLaneError(router, lane, route, cause, options)];
		}
		const result = await outcome;
		if (blocking && result[0] === SUCCESS$1 && match.status === "pending" && !options[0].signal.aborted) {
			match.status = "success";
			onReady?.();
		}
	})();
	tasks.push([
		index,
		outcome,
		chunkFailure
	]);
	if (!background) return outcome.then((result) => getParentSnapshot(match, result));
	const candidate = {
		...match,
		status: "pending",
		preload: false,
		_flight: donor
	};
	match.invalid = false;
	match.isFetching = "loader";
	const backgroundOutcome = loadResource(router, lane, candidate, route, loader, semanticParent, options).then((result) => {
		match.isFetching = false;
		settleInto(candidate, result, false);
		return result;
	});
	(lane[2] ??= []).push([
		index,
		backgroundOutcome,
		chunkFailure,
		candidate
	]);
	return backgroundOutcome.then((result) => getParentSnapshot(candidate, result));
}
async function getNotFoundBoundary$1(router, matches, indexed, signal, fallback = 0) {
	const cause = indexed?.[1][1];
	let index = cause?.routeId ? matches.findIndex((match) => match.routeId === cause.routeId) : indexed?.[0] ?? matches.length - 1;
	if (index < 0) index = 0;
	for (let i = index; i >= 0; i--) {
		const route = getRoute$1(router, matches[i]);
		try {
			const loading = loadRouteChunk(route, false);
			if (loading) await waitFor$1(loading, signal);
		} catch (cause) {
			if (cause === signal && signal.aborted) throw cause;
		}
		if (route.options.notFoundComponent) return i;
	}
	return cause?.routeId ? index : fallback;
}
function discardBackground(router, lane) {
	if (lane[2]) {
		transferMatchResources(router, lane[2].map((task) => task[3]));
		lane[2] = void 0;
	}
}
async function settleTasks(tasks, serialFailure, redirectTasks, gate) {
	let loaderFailure;
	try {
		await Promise.all(tasks.map((task) => task[1].then(async (outcome) => {
			const taskIndex = task[0];
			if (gate && taskIndex >= await gate) return;
			if (outcome[0] >= REDIRECTED$1) throw [taskIndex, outcome];
			if (!loaderFailure && outcome[0] !== SUCCESS$1) {
				loaderFailure = [taskIndex, outcome];
				await Promise.all((redirectTasks ?? []).map((nextTask) => {
					if (nextTask[0] <= taskIndex) return;
					return nextTask[1].then((nextOutcome) => {
						if (nextOutcome[0] === REDIRECTED$1) throw [nextTask[0], nextOutcome];
					});
				}));
			}
		})));
	} catch (cause) {
		return cause;
	}
	return serialFailure ?? loaderFailure;
}
function materializeRedirect$1(router, lane, route, outcome, options, failed) {
	while (outcome[0] === REDIRECTED$1) {
		const redirect = outcome[1];
		const redirectOptions = redirect.options;
		try {
			if (redirectOptions.href || redirect.headers.has("Location")) {
				router.resolveRedirect(redirect);
				if (redirectOptions.reloadDocument) return outcome;
			}
			if (redirectOptions.reloadDocument ? options[3] : options[1] >= 20) return outcome;
			const location = router.buildLocation({
				...redirectOptions,
				_fromLocation: lane[0],
				_includeValidateSearch: true
			});
			const publicLocation = location.maskedLocation ?? location;
			if (publicLocation.external) {
				const resolved = redirect.clone();
				resolved.options = { ...redirectOptions };
				resolved.headers.set("Location", publicLocation.publicHref);
				router.resolveRedirect(resolved);
				return options[3] ? [REDIRECTED$1, resolved] : [
					REDIRECTED$1,
					resolved,
					publicLocation
				];
			}
			return [
				REDIRECTED$1,
				redirect,
				location
			];
		} catch (cause) {
			outcome = failed ? [ERROR$1, cause] : normalizeError$1(route, cause);
			failed = true;
		}
	}
	return outcome;
}
async function reduceLane(router, lane, tasks, controller, settlement, onReady) {
	const matches = lane[1];
	let failure = await settlement;
	let redirectLimitExceeded = false;
	const plannedBoundary = matches.findIndex((match) => match._notFound);
	const boundaryOf = (found) => found[1][0] === NOT_FOUND$1 ? getNotFoundBoundary$1(router, matches, found, controller.signal) : found[0];
	let readinessEnd = plannedBoundary < 0 ? matches.length : plannedBoundary;
	if ((failure?.[1][0] ?? 0) >= REDIRECTED$1) readinessEnd = 0;
	else if (failure) {
		readinessEnd = failure[2] ??= await boundaryOf(failure);
		for (const task of tasks) {
			if (task[0] >= readinessEnd) break;
			const outcome = await task[1];
			if (outcome[0] !== SUCCESS$1 && outcome[0] < REDIRECTED$1 && !("loaderData" in matches[task[0]])) {
				failure = [task[0], outcome];
				readinessEnd = failure[2] = await boundaryOf(failure);
				break;
			}
		}
	}
	for (const task of tasks) {
		if (task[0] >= readinessEnd) break;
		const chunkFailure = await task[2];
		if (!chunkFailure) continue;
		failure = chunkFailure;
		break;
	}
	if ((failure?.[1][0] ?? 0) >= REDIRECTED$1) {
		const outcome = failure[1];
		if (outcome[0] !== REDIRECTED$1 || outcome[1].options.reloadDocument || outcome[2]) {
			discardBackground(router, lane);
			return outcome;
		}
		redirectLimitExceeded = true;
		failure = [0, [ERROR$1, /* @__PURE__ */ new Error("Too many redirects")]];
	}
	const boundary = failure ? failure[2] ?? await boundaryOf(failure) : plannedBoundary;
	if (boundary >= 0) {
		const outcome = failure?.[1];
		const kind = outcome?.[0];
		const match = matches[boundary];
		const cause = outcome?.[1];
		const install = () => {
			if (outcome) {
				match._notFound = void 0;
				if (kind === ERROR$1) match.status = "error";
				else {
					cause.routeId = match.routeId;
					if (match.routeId === router.routeTree.id) {
						match.status = "success";
						match._notFound = true;
					} else match.status = "notFound";
				}
				match.error = cause;
				match.isFetching = false;
			}
		};
		install();
		if (!outcome) onReady?.();
		const route = getRoute$1(router, match);
		try {
			await waitFor$1(outcome ? Promise.resolve().then(() => loadRouteChunk(route, kind === ERROR$1 ? "errorComponent" : "notFoundComponent")) : Promise.all([loadRouteChunk(route), loadRouteChunk(route, "notFoundComponent")]), controller.signal);
		} catch (cause) {
			if (cause === controller.signal && controller.signal.aborted) {
				discardBackground(router, lane);
				return CANCELED_OUTCOME;
			}
		}
		if (!outcome) match.status = "success";
		else if (redirectLimitExceeded) {
			controller.abort();
			await Promise.all([
				...tasks.map((task) => task[1]),
				...tasks.map((task) => task[2]),
				...(lane[2] ?? []).map((task) => task[1])
			]);
			discardBackground(router, lane);
			transferMatchResources(router, matches);
			install();
		}
	}
	return lane;
}
async function projectLane$1(router, lane, signal, start = 0, end = lane[1].length) {
	const matches = lane[1];
	for (let index = start; index < end; index++) {
		const match = matches[index];
		const routeOptions = getRoute$1(router, match).options;
		if (routeOptions.head || routeOptions.scripts) try {
			const context = {
				ssr: router.options.ssr,
				matches,
				match,
				params: match.params,
				loaderData: match.loaderData
			};
			const [head, scripts] = await waitFor$1(Promise.all([routeOptions.head?.(context), routeOptions.scripts?.(context)]), signal);
			match.meta = head?.meta;
			match.links = head?.links;
			match.headScripts = head?.scripts;
			match.styles = head?.styles;
			match.scripts = scripts;
		} catch (cause) {
			if (cause === signal && signal.aborted) break;
			console.error(cause);
		}
		if (match.status !== "success" || match._notFound) break;
	}
	return lane;
}
async function executeClientLane(router, location, matches, options) {
	const matched = [location, matches];
	const signal = options[0].signal;
	let reduced;
	try {
		const presented = router.stores.matches.get();
		let plannedBoundary = matches.findIndex((match) => match._notFound);
		if (router.options.notFoundMode !== "root" && plannedBoundary >= 0) {
			const boundary = await getNotFoundBoundary$1(router, matches, void 0, signal, plannedBoundary);
			matches[plannedBoundary]._notFound = void 0;
			matches[boundary]._notFound = true;
			plannedBoundary = boundary;
		}
		let end = plannedBoundary < 0 ? matches.length : plannedBoundary + 1;
		let retainedEnd = 0;
		while (retainedEnd < end && retainedEnd !== plannedBoundary) {
			const match = matches[retainedEnd];
			const committed = options[2][retainedEnd];
			const visible = presented[retainedEnd];
			if (committed?.id !== match.id || committed.status !== "success" || match.preload || visible?.id !== match.id || visible.status !== "success") break;
			retainedEnd++;
			if (committed._notFound || visible._notFound) break;
		}
		const tasks = [];
		const start = options[6] ?? 0;
		let semanticParent = start ? Promise.resolve(matches[start - 1]) : void 0;
		const planSuccessfulLane = () => {
			for (let index = start; index < end; index++) {
				if (signal.aborted) break;
				semanticParent = createLoaderTask$1(router, matched, index, tasks, semanticParent, options, retainedEnd);
			}
		};
		const failure = await contextualize$1(router, matched, options, end, planSuccessfulLane, retainedEnd);
		if (failure) {
			options[4] = true;
			end = failure[0];
			if (failure[1][0] === NOT_FOUND$1) {
				const boundary = await getNotFoundBoundary$1(router, matches, failure, signal);
				failure[2] = boundary;
				end = Math.min(end, boundary + 1);
			} else if (failure[1][0] >= REDIRECTED$1) end = 0;
			planSuccessfulLane();
		}
		if (!signal.aborted && !options[3]) {
			const abort = [];
			for (const [id, flight] of router._flights ?? []) if (!flight[2]) {
				router._flights.delete(id);
				abort.push(flight[1]);
			}
			for (const controller of abort) controller.abort();
		}
		const reduction = reduceLane(router, matched, tasks, options[0], settleTasks(tasks, failure, matched[2]), options[7]);
		if (matched[2]?.length) matched[3] = settleTasks(matched[2], void 0, void 0, reduction.then((foreground) => isControl(foreground) ? 0 : _getRenderedMatches(matches).length, () => 0));
		reduced = await reduction;
	} catch (cause) {
		discardBackground(router, matched);
		if (cause === signal && signal.aborted) return CANCELED_OUTCOME;
		throw cause;
	}
	if (isControl(reduced)) return reduced;
	return projectLane$1(router, reduced, signal, options[6] === matches.length ? options[6] : 0);
}
/**
* Waits for `pendingMs`, then presents the complete lane. Rendering applies the
* selected boundary cutoff while retaining every match's structural state.
* A replacement load for the same match keeps the timer; choosing a different
* match resets it. `pendingMinMs` starts after the fallback renders.
*/
function offerPending(router, tx) {
	if (router._tx !== tx) return;
	const matches = tx[3];
	const presented = router.stores.matches.get();
	let session = router._pending;
	for (let index = 0; index < matches.length; index++) {
		const match = matches[index];
		const success = match.status === "success" && !match._notFound;
		const presentedPending = presented[index]?.id === match.id && presented[index]?.status === "pending";
		if (success && !presentedPending) continue;
		const route = getRoute$1(router, match);
		const delay = success || match.invalid ? 0 : route.options.pendingMs ?? router.options.defaultPendingMs;
		const component = route.options.pendingComponent ?? router.options.defaultPendingComponent;
		if (!component || typeof delay !== "number" || delay === Infinity) {
			if (session) {
				session[0] = tx;
				session[2] = 0;
				session[4] = true;
			}
			return;
		}
		const min = route.options.pendingMinMs ?? router.options.defaultPendingMinMs ?? 0;
		let tookOver = false;
		if (session?.[1] === match.id) {
			tookOver = session[0] !== tx;
			session[0] = tx;
		} else {
			clearTimeout(session?.[3]);
			router._pending = session = void 0;
		}
		if (!session) router._pending = session = [
			tx,
			match.id,
			presentedPending ? Date.now() + min : tx[4] + delay,
			void 0,
			presentedPending || void 0,
			component
		];
		if (session[4] && !tookOver && session[5] === component) return;
		session[5] = component;
		if (!session[4]) {
			clearTimeout(session[3]);
			const remaining = session[2] - Date.now();
			if (remaining > 0) {
				session[3] = setTimeout(() => offerPending(router, tx), remaining);
				return;
			}
			session[2] = 0;
		}
		const offered = matches.map((match) => ({
			...match,
			_flight: void 0
		}));
		offered[index].status = "pending";
		const ack = session[4] = router.startTransition(() => router.stores.setMatches(offered), offered).then((rendered) => {
			if (rendered && router._pending === session && session[4] === ack && !session[2]) session[2] = Date.now() + min;
			return rendered;
		});
		return;
	}
}
/**
* Cancels pending UI timing unless the current successor can take over the
* same boundary that remains painted.
*/
function finishPending(router, tx) {
	const session = router._pending;
	if (router._tx === tx || !router._tx?.[3].some((match) => match.id === session?.[1])) {
		clearTimeout(session?.[3]);
		router._pending = void 0;
	}
}
async function awaitPendingMinimum(router, tx) {
	const session = router._pending;
	if (!session) return;
	clearTimeout(session[3]);
	const remaining = session[2] - Date.now();
	if (!session[4] || remaining <= 0 || !_getRenderedMatches(tx[3]).some((match) => match.id === session[1])) return;
	let timer;
	try {
		await waitFor$1(new Promise((resolve) => {
			timer = setTimeout(resolve, remaining);
		}), tx[0].signal);
	} catch {}
	clearTimeout(timer);
}
function publishMatches(router, matches) {
	router._committed = matches;
	router.stores.setMatches(matches);
}
function commitMatches(router, tx, matches, resolvedPrefix) {
	const previous = router._committed;
	const previousEnd = router._lifecycleEnd;
	const previousCached = router._cache;
	for (const match of matches) {
		match.preload = false;
		if (resolvedPrefix) match._assetEnd = void 0;
	}
	const cut = _getRenderedMatches(matches).length;
	const cached = /* @__PURE__ */ new Map();
	if (!tx[6]) {
		const now = Date.now();
		const superseded = /* @__PURE__ */ new Set();
		for (let index = 0; index < matches.length; index++) {
			const match = matches[index];
			if (index < cut || match.status === "success") superseded.add(match.id);
		}
		for (const match of [...previous, ...previousCached.values()]) {
			if (match.status !== "success" || superseded.has(match.id)) continue;
			const route = getRoute$1(router, match);
			if (!route.options.loader || now - match.updatedAt >= (match.preload ? route.options.preloadGcTime ?? router.options.defaultPreloadGcTime ?? 3e5 : route.options.gcTime ?? router.options.defaultGcTime ?? 3e5)) continue;
			cached.set(match.id, previousCached.get(match.id) === match ? match : {
				...match,
				_flight: void 0,
				isFetching: false,
				context: {}
			});
		}
	}
	tx[3] = [];
	router._cache = cached;
	const nextEnd = router._lifecycleEnd = lifecycleEnd(matches);
	publishMatches(router, matches);
	transferMatchResources(router, [...previousCached.values(), ...previous].filter((match) => match._flight && cached.get(match.id) !== match), matches);
	{
		const handoff = tx[6]?.[0];
		if (handoff && router._handoff === handoff) handoff[1]();
	}
	runRouteLifecycle(router, previous, matches, previousEnd, nextEnd, tx);
}
/**
* Resolve once the router has settled on a transaction other than `owner`.
* Each transaction's completion follows its current successor, so all waiters
* share the same chain instead of polling every successor independently.
*/
async function awaitCurrent(router, owner) {
	let current = router._tx;
	while (current && current !== owner) {
		owner = current;
		await current[5];
		current = router._tx;
	}
}
function followRedirect(router, tx, outcome) {
	const options = outcome[1].options;
	const location = outcome[2];
	if (!location) return router.navigate({
		...options,
		replace: true,
		ignoreBlocker: true
	});
	if (options.reloadDocument) return router.navigate({
		href: (location.maskedLocation ?? location).publicHref,
		reloadDocument: true,
		replace: true,
		ignoreBlocker: true
	});
	location._redirects = tx[1] + 1;
	router._pendingLocation = location;
	const committed = router.commitLocation({
		...location,
		viewTransition: options.viewTransition,
		replace: true,
		resetScroll: options.resetScroll,
		hashScrollIntoView: options.hashScrollIntoView,
		ignoreBlocker: true
	});
	queueMicrotask(() => {
		if (router._pendingLocation === location) router._pendingLocation = void 0;
	});
	return committed;
}
async function runBackground(router, tx, base, tasks, settlement) {
	const next = base.map((match) => ({ ...match }));
	acquireMatchResources(next);
	for (const task of tasks) {
		releaseFlight(router, next[task[0]]);
		next[task[0]] = task[3];
	}
	const lane = [tx[2], next];
	let reduced;
	try {
		reduced = await reduceLane(router, lane, tasks, tx[0], settlement);
	} catch (cause) {
		transferMatchResources(router, next);
		throw cause;
	}
	if (isControl(reduced)) {
		transferMatchResources(router, next);
		if (reduced[0] === REDIRECTED$1 && router._tx === tx && router._committed === base) await followRedirect(router, tx, reduced);
		return;
	}
	await projectLane$1(router, reduced, tx[0].signal);
	if (router._tx !== tx || router._committed !== base) {
		transferMatchResources(router, next);
		return;
	}
	for (const match of next) {
		const cached = router._cache.get(match.id);
		if (cached?._flight && cached._flight === match._flight) {
			router._cache.delete(match.id);
			releaseFlight(router, cached);
		}
	}
	publishMatches(router, next);
	transferMatchResources(router, base, next);
}
async function runClientTransaction(router, tx, forceStaleReload, onReady, sync, resolvedPrefix) {
	const result = await executeClientLane(router, tx[2], tx[3], [
		tx[0],
		tx[1],
		router._committed,
		void 0,
		sync,
		forceStaleReload,
		resolvedPrefix,
		onReady
	]);
	if (isControl(result)) {
		const follow = result[0] === REDIRECTED$1 && router._tx === tx;
		if (!follow || result[1].options.reloadDocument) finishPending(router, tx);
		transferMatchResources(router, tx[3]);
		tx[3] = [];
		if (!follow) return;
		if (router._tx !== tx) {
			finishPending(router, tx);
			return;
		}
		if (tx[6]) router._refreshNextLoad = true;
		await followRedirect(router, tx, result);
		return;
	}
	const matches = result[1];
	if (router._tx === tx) await awaitPendingMinimum(router, tx);
	if (router._tx !== tx) {
		finishPending(router, tx);
		transferMatchResources(router, matches);
		discardBackground(router, result);
		return;
	}
	const toLocation = tx[2];
	const changeInfo = getLocationChangeInfo(toLocation, router.stores.resolvedLocation.get());
	const background = result[2];
	await router.startViewTransition(async () => {
		if (router._tx === tx) await awaitPendingMinimum(router, tx);
		if (router._tx !== tx) {
			finishPending(router, tx);
			transferMatchResources(router, matches);
			discardBackground(router, result);
			return;
		}
		const commit = () => {
			finishPending(router, tx);
			commitMatches(router, tx, matches, resolvedPrefix);
			if (router._tx !== tx) return;
			router.emit({
				type: "onLoad",
				...changeInfo
			});
			if (router._tx === tx) router.emit({
				type: "onBeforeRouteMount",
				...changeInfo
			});
		};
		const rendered = await router.startTransition(commit, matches);
		if (tx[6]) tx[6] = void 0;
		if (router._tx !== tx) {
			discardBackground(router, result);
			return;
		}
		if (background?.length) runBackground(router, tx, matches, background, result[3]).catch(console.error);
		router.batch(() => {
			router.stores.resolvedLocation.set(toLocation);
			router.stores.status.set("idle");
			if (router._tx === tx) router.emit({
				type: "onResolved",
				...changeInfo
			});
			if (rendered && router._tx === tx) router.emit({
				type: "onRendered",
				...changeInfo
			});
		});
		if (router._tx !== tx) return;
		router._commitPromise?.resolve();
		router._commitPromise = void 0;
	});
}
async function loadClientRoute(router, opts) {
	let rematerialize = false;
	rematerialize = !!router._refreshNextLoad || !!router._tx?.[6];
	const previousOwner = router._tx;
	const resolvedLocation = router.stores.resolvedLocation.get();
	const previousLocation = resolvedLocation ?? router.stores.location.get();
	const location = router.latestLocation;
	const pendingLocation = router._pendingLocation;
	const redirects = pendingLocation?.href === location.href ? pendingLocation._redirects ?? 0 : 0;
	const handoff = router._handoff;
	const hydrationController = rematerialize ? void 0 : handoff?.[0]();
	const preflight = new AbortController();
	const previousPreflight = router._preflight;
	router._preflight = preflight;
	if (!rematerialize && !hydrationController) handoff?.[1]();
	previousPreflight?.abort();
	if (!preflight.signal.aborted) {
		const changeInfo = getLocationChangeInfo(location, resolvedLocation);
		router.emit({
			type: "onBeforeNavigate",
			...changeInfo
		});
		if (!preflight.signal.aborted) router.emit({
			type: "onBeforeLoad",
			...changeInfo
		});
	}
	if (preflight.signal.aborted) {
		await awaitCurrent(router, previousOwner);
		return;
	}
	const sameHref = previousLocation.href === location.href;
	let controller = preflight;
	const matches = rematerialize ? router.matchRoutes(location, {
		_controller: preflight,
		_rematerialize: true
	}) : router.matchRoutes(location, { _controller: preflight });
	acquireMatchResources(matches);
	const resolvedPrefix = hydrationController ? handoff[1](matches) : void 0;
	if (resolvedPrefix) controller = hydrationController;
	else hydrationController?.abort();
	if (preflight.signal.aborted) {
		transferMatchResources(router, matches);
		await awaitCurrent(router, previousOwner);
		return;
	}
	router._preflight = void 0;
	let settle;
	const run = () => runClientTransaction(router, tx, sameHref, () => offerPending(router, tx), opts?.sync, resolvedPrefix);
	const done = opts?.sync ? new Promise((resolve) => settle = resolve) : Promise.resolve().then(run);
	const tx = [
		controller,
		redirects,
		location,
		matches,
		Date.now(),
		done.then(() => awaitCurrent(router, tx))
	];
	if (rematerialize) {
		tx[6] = [handoff];
		router._refreshNextLoad = void 0;
	}
	router._tx = tx;
	if (previousOwner) {
		for (const match of router.stores.matches.get()) {
			if (router._tx !== tx) break;
			if (match.isFetching) setFetching(router, match, false);
		}
		previousOwner[0].abort();
		transferMatchResources(router, previousOwner[3], tx[3], true);
	}
	if (router._tx !== tx) {
		transferMatchResources(router, tx[3]);
		tx[3] = [];
		settle?.();
		await awaitCurrent(router, tx);
		return;
	}
	router.batch(() => {
		router.stores.status.set("pending");
		router.stores.location.set(location);
	});
	if (resolvedPrefix || !router._committed.length && matches[0]?.status !== "success" && !matches.some((match) => match._notFound)) offerPending(router, tx);
	settle?.(run());
	await tx[5];
}
async function refreshClientRoute(router) {
	const pending = router._tx;
	if (pending && !pending[6] && router.stores.status.get() === "pending") {
		await pending[5];
		if (router._tx !== pending) await awaitCurrent(router, pending);
	}
	router._flights?.clear();
	router.clearCache();
	router._refreshNextLoad = true;
	await loadClientRoute(router, { sync: true });
}
async function preloadClientRoute(router, opts) {
	if (router._refreshNextLoad || router._tx?.[6]) return;
	let location = router.buildLocation(opts);
	for (let redirects = 0;; redirects++) {
		const base = router._committed;
		const controller = new AbortController();
		let matches;
		let active;
		let result;
		try {
			try {
				matches = router.matchRoutes(location, { _controller: controller });
				acquireMatchResources(matches);
				active = (router._preloads ??= /* @__PURE__ */ new Map()).set(controller, matches);
				result = await executeClientLane(router, location, matches, [
					controller,
					redirects,
					base,
					true
				]);
			} finally {
				if (active) {
					active = active.delete(controller);
					transferMatchResources(router, matches);
				}
				controller.abort();
			}
			if (!isControl(result)) return result[1];
			if (!active || result.length < 3 || router._refreshNextLoad || router._tx?.[6]) return;
			location = result[2];
		} catch (cause) {
			if (!isNotFound(cause)) console.error(cause);
			return;
		}
	}
}
// node_modules/@tanstack/router-core/dist/esm/await-signal.js
function observeLate(callback, value) {
	if (!callback) return;
	try {
		const result = callback(value);
		if (result !== void 0) Promise.resolve(result).catch(() => {});
	} catch {}
}
/**
* Await `value` unless `signal` aborts first. A result that settles after the
* abort is passed to `onLate` / `onLateError` instead.
*
* One abort listener per wait: SSR requests nest at most a few waits on one
* signal, so pooling them was measurably slower than this.
*/
function waitForReason(value, signal, onLate, onLateError) {
	const promise = Promise.resolve(value);
	if (signal.aborted) {
		promise.then((result) => observeLate(onLate, result), (error) => observeLate(onLateError, error));
		return Promise.reject(signal.reason);
	}
	return new Promise((resolve, reject) => {
		const abort = () => reject(signal.reason);
		signal.addEventListener("abort", abort, { once: true });
		promise.then((result) => {
			signal.removeEventListener("abort", abort);
			if (signal.aborted) observeLate(onLate, result);
			else resolve(result);
		}, (error) => {
			signal.removeEventListener("abort", abort);
			if (signal.aborted) observeLate(onLateError, error);
			else reject(error);
		});
	});
}
// node_modules/@tanstack/router-core/dist/esm/load-server.js
var SUCCESS = 0;
var ERROR = 1;
var NOT_FOUND = 2;
var REDIRECTED = 3;
var SKIPPED = 4;
var MATCH_SETTLED_ABORT_REASON = Object.freeze({
	name: "AbortError",
	message: "TanStack Router aborted this server match because it settled."
});
var REDIRECT_ABORT_REASON = Object.freeze({
	name: "AbortError",
	message: "TanStack Router aborted this server match because of a redirect."
});
function getRoute(router, match) {
	return router.routesById[match.routeId];
}
function normalize(value, rejected) {
	if (isRedirect(value)) return [REDIRECTED, value];
	if (isNotFound(value)) return [NOT_FOUND, value];
	if (rejected && typeof value?.then === "function") value = new Error("A Promise was thrown", { cause: value });
	return rejected ? [ERROR, value] : [SUCCESS, value];
}
function normalizeError(router, lane, route, cause, signal, notify = true) {
	signal?.throwIfAborted();
	let outcome = normalize(cause, true);
	if (outcome[0] !== ERROR) return materializeRedirect(router, lane, route, outcome, signal, notify);
	try {
		route.options.onError?.(outcome[1]);
	} catch (onErrorCause) {
		outcome = normalize(onErrorCause, true);
	}
	signal?.throwIfAborted();
	return materializeRedirect(router, lane, route, outcome, signal, notify);
}
function materializeRedirect(router, lane, route, outcome, signal, notify = true) {
	if (outcome[0] !== REDIRECTED) return outcome;
	signal?.throwIfAborted();
	try {
		outcome[1].options._fromLocation = lane.location;
		router.resolveRedirect(outcome[1]);
		signal?.throwIfAborted();
		return outcome;
	} catch (cause) {
		signal?.throwIfAborted();
		return notify ? normalizeError(router, lane, route, cause, signal, false) : [ERROR, cause];
	}
}
function maybe(value, cause) {
	if (cause !== void 0) return {
		status: "error",
		error: cause
	};
	return {
		status: "success",
		value
	};
}
function navigateFrom(router, location) {
	return (options) => router.navigate({
		...options,
		_fromLocation: location
	});
}
function waitFor(value, signal) {
	return signal ? waitForReason(value, signal) : value;
}
function resolveSsr(router, lane, index) {
	const match = lane.matches[index];
	const route = getRoute(router, match);
	const parentSsr = lane.matches[index - 1]?.ssr;
	if (router.isShell()) return route.id === rootRouteId;
	if (parentSsr === false) return false;
	const inherit = (value) => {
		return value === true && parentSsr === "data-only" ? "data-only" : value;
	};
	const defaultSsr = router.options.defaultSsr ?? true;
	const inheritedDefault = inherit(defaultSsr);
	match.ssr = inheritedDefault;
	const option = route.options.ssr;
	if (option === void 0) return inheritedDefault;
	if (typeof option !== "function") return inherit(option);
	const context = {
		search: maybe(match.search, match.searchError),
		params: maybe(match.params, match.paramsError),
		location: lane.location,
		matches: lane.matches.map((candidate) => ({
			index: candidate.index,
			pathname: candidate.pathname,
			fullPath: candidate.fullPath,
			staticData: candidate.staticData,
			id: candidate.id,
			routeId: candidate.routeId,
			search: maybe(candidate.search, candidate.searchError),
			params: maybe(candidate.params, candidate.paramsError),
			ssr: candidate.ssr
		}))
	};
	try {
		return Promise.resolve(option(context)).then((value) => inherit(value ?? defaultSsr));
	} catch (cause) {
		return Promise.reject(cause);
	}
}
function stampNotFound(match, outcome) {
	if (outcome[0] === NOT_FOUND && !outcome[1].routeId) outcome[1].routeId = match.routeId;
	return outcome;
}
async function contextualize(router, lane, signal) {
	const globalBoundary = lane.matches.findIndex((match) => match._notFound);
	let end = globalBoundary < 0 ? lane.matches.length : globalBoundary + 1;
	let failure;
	let parentContext = { ...router.options.context ?? {} };
	for (let index = 0; index < end; index++) {
		const match = lane.matches[index];
		const route = getRoute(router, match);
		try {
			const ssr = resolveSsr(router, lane, index);
			match.ssr = ssr instanceof Promise ? await ssr : ssr;
		} catch (cause) {
			signal?.throwIfAborted();
			failure = [index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))];
			end = index;
		}
		signal?.throwIfAborted();
		if (failure?.[1][0] === REDIRECTED) break;
		match.__beforeLoadContext = void 0;
		let context = parentContext;
		try {
			let routeContext;
			if (route.options.context) {
				const routeContextOptions = {
					deps: match.loaderDeps,
					params: match.params,
					context: parentContext,
					location: lane.location,
					navigate: navigateFrom(router, lane.location),
					buildLocation: router.buildLocation,
					cause: match.cause,
					abortController: match.abortController,
					preload: false,
					matches: lane.matches,
					routeId: route.id
				};
				routeContext = route.options.context(routeContextOptions) ?? void 0;
			}
			context = {
				...parentContext,
				...routeContext
			};
			match.context = context;
		} catch (cause) {
			signal?.throwIfAborted();
			if (!failure) failure = [index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))];
			end = index;
			break;
		}
		signal?.throwIfAborted();
		if (failure) break;
		const validationError = match.paramsError ?? match.searchError;
		if (validationError !== void 0) {
			failure = [index, stampNotFound(match, normalizeError(router, lane, route, validationError, signal))];
			end = index;
			break;
		}
		signal?.throwIfAborted();
		if (match.ssr === false || !route.options.beforeLoad) {
			parentContext = context;
			continue;
		}
		const abortController = match.abortController;
		const options = {
			search: match.search,
			abortController,
			params: match.params,
			preload: false,
			context,
			location: lane.location,
			navigate: navigateFrom(router, lane.location),
			buildLocation: router.buildLocation,
			cause: match.cause,
			matches: lane.matches,
			routeId: route.id,
			...router.options.additionalContext
		};
		try {
			const beforeLoadContext = await route.options.beforeLoad(options);
			signal?.throwIfAborted();
			const outcome = stampNotFound(match, materializeRedirect(router, lane, route, normalize(beforeLoadContext, false), signal));
			if (outcome[0] !== SUCCESS) {
				failure = [index, outcome];
				end = index;
				break;
			}
			match.__beforeLoadContext = beforeLoadContext;
			match.context = {
				...context,
				...beforeLoadContext
			};
			parentContext = match.context;
		} catch (cause) {
			signal?.throwIfAborted();
			failure = [index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))];
			end = index;
			break;
		}
	}
	return {
		location: lane.location,
		matches: lane.matches,
		end,
		failure
	};
}
function getLoaderContext(router, lane, match, route, index, tasks) {
	return {
		params: match.params,
		deps: match.loaderDeps,
		preload: false,
		parentMatchPromise: tasks[index - 1]?.match,
		abortController: match.abortController,
		context: match.context,
		location: lane.location,
		navigate: navigateFrom(router, lane.location),
		cause: match.cause,
		route,
		...router.options.additionalContext
	};
}
function createLoaderTask(router, lane, index, tasks, signal) {
	const match = lane.matches[index];
	const route = getRoute(router, match);
	let outcome;
	if (match.ssr === false) outcome = Promise.resolve([SKIPPED]);
	else {
		const routeLoader = route.options.loader;
		const loader = typeof routeLoader === "function" ? routeLoader : routeLoader?.handler;
		if (!loader) outcome = Promise.resolve([SUCCESS, void 0]);
		else outcome = Promise.resolve().then(() => loader(getLoaderContext(router, lane, match, route, index, tasks))).then((result) => normalize(result, false), (cause) => normalize(cause, true)).then((result) => {
			if (signal?.aborted || match.abortController.signal.reason === REDIRECT_ABORT_REASON) return [SKIPPED];
			if (result[0] === ERROR) result = normalizeError(router, lane, route, result[1], signal);
			else result = materializeRedirect(router, lane, route, result, signal);
			return stampNotFound(match, result);
		});
	}
	const parentMatch = outcome.then((result) => {
		const snapshot = { ...match };
		if (result[0] === SUCCESS) {
			snapshot.loaderData = result[1];
			snapshot.status = "success";
			snapshot.error = void 0;
			snapshot.invalid = false;
			snapshot.isFetching = false;
		} else if (result[0] === ERROR) {
			snapshot.status = "error";
			snapshot.error = result[1];
		} else if (result[0] === NOT_FOUND) {
			snapshot.status = "notFound";
			snapshot.error = result[1];
		}
		return snapshot;
	});
	return {
		index,
		outcome,
		match: parentMatch
	};
}
async function getNotFoundBoundary(router, matches, indexed, signal, fallback = 0) {
	const cause = indexed?.[1][1];
	let index = cause?.routeId ? matches.findIndex((match) => match.routeId === cause.routeId) : indexed?.[0] ?? matches.length - 1;
	if (index < 0) index = 0;
	for (let candidate = index; candidate >= 0; candidate--) {
		const route = getRoute(router, matches[candidate]);
		try {
			const loading = loadRouteChunk(route, false);
			if (loading) await loading;
		} catch {
			signal?.throwIfAborted();
		}
		signal?.throwIfAborted();
		if (route.options.notFoundComponent) return candidate;
	}
	return cause?.routeId ? index : fallback;
}
function abortMatches(matches, start = 0, reason = MATCH_SETTLED_ABORT_REASON) {
	for (let index = start; index < matches.length; index++) matches[index].abortController.abort(reason);
}
async function applyFailure(router, lane, indexed, signal) {
	if (!indexed) {
		const boundary = lane.matches.findIndex((match) => match._notFound);
		if (boundary >= 0) {
			abortMatches(lane.matches, boundary + 1);
			return {
				status: 404,
				boundary,
				kind: NOT_FOUND
			};
		}
		return { status: 200 };
	}
	const [index, outcome] = indexed;
	if (outcome[0] === ERROR) {
		const match = lane.matches[index];
		match._notFound = void 0;
		match.status = "error";
		match.error = outcome[1];
		match.isFetching = false;
		abortMatches(lane.matches, index + 1);
		return {
			status: 500,
			boundary: index,
			kind: ERROR
		};
	}
	const boundary = indexed[2] ?? await getNotFoundBoundary(router, lane.matches, indexed, signal);
	const match = lane.matches[boundary];
	const cause = outcome[1];
	cause.routeId = match.routeId;
	match._notFound = void 0;
	if (match.routeId === router.routeTree.id) {
		match.status = "success";
		match._notFound = true;
		match.error = cause;
	} else {
		match.status = "notFound";
		match.error = cause;
	}
	match.isFetching = false;
	abortMatches(lane.matches, boundary + 1);
	return {
		status: 404,
		boundary,
		kind: NOT_FOUND
	};
}
async function loadNormalChunks(router, lane, end, signal) {
	const chunks = [];
	for (let index = 0; index < lane.matches.length; index++) {
		const match = lane.matches[index];
		if (index >= end || match.ssr !== true || match.status !== "success") continue;
		const route = getRoute(router, match);
		try {
			const loading = loadRouteChunk(route);
			if (loading) {
				const chunk = loading.then(() => {
					signal?.throwIfAborted();
				}, (cause) => {
					signal?.throwIfAborted();
					return [index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))];
				});
				chunk.catch(() => {});
				chunks.push(chunk);
			}
		} catch (cause) {
			signal?.throwIfAborted();
			chunks.push([index, stampNotFound(match, normalizeError(router, lane, route, cause, signal))]);
		}
	}
	for (const chunk of chunks) {
		const indexed = Array.isArray(chunk) ? chunk : await chunk;
		if (indexed) return indexed;
	}
}
async function projectLane(router, lane, signal) {
	for (const match of lane.matches) {
		const routeOptions = getRoute(router, match).options;
		if (routeOptions.head || routeOptions.scripts || routeOptions.headers) {
			const context = {
				ssr: router.options.ssr,
				matches: lane.matches,
				match,
				params: match.params,
				loaderData: match.loaderData
			};
			try {
				const [head, scripts, headers] = await Promise.all([
					routeOptions.head?.(context),
					routeOptions.scripts?.(context),
					routeOptions.headers?.(context)
				]);
				signal?.throwIfAborted();
				match.meta = head?.meta;
				match.links = head?.links;
				match.headScripts = head?.scripts;
				match.styles = head?.styles;
				match.scripts = scripts;
				match.headers = headers;
			} catch (cause) {
				signal?.throwIfAborted();
				console.error(cause);
			}
		}
		if (match.ssr === false || match.status !== "success" || match._notFound) break;
	}
}
async function executeServerLane(router, location, matchedMatches, signal) {
	const matched = {
		location,
		matches: matchedMatches.map((match) => ({
			...match,
			__beforeLoadContext: void 0,
			context: {},
			isFetching: false,
			abortController: new AbortController()
		}))
	};
	const abortLane = () => abortMatches(matched.matches, 0, signal?.reason ?? MATCH_SETTLED_ABORT_REASON);
	if (signal?.aborted) {
		abortLane();
		signal.throwIfAborted();
	}
	signal?.addEventListener("abort", abortLane, { once: true });
	try {
		const plannedGlobalBoundary = matched.matches.findIndex((match) => match._notFound);
		if (router.options.notFoundMode !== "root" && plannedGlobalBoundary >= 0) {
			const boundary = await getNotFoundBoundary(router, matched.matches, void 0, signal, plannedGlobalBoundary);
			if (boundary !== plannedGlobalBoundary) {
				matched.matches[plannedGlobalBoundary]._notFound = void 0;
				matched.matches[boundary]._notFound = true;
			}
		}
		const lane = await contextualize(router, matched, signal);
		signal?.throwIfAborted();
		let loaderEnd = lane.end;
		if (lane.failure?.[1][0] === REDIRECTED) loaderEnd = 0;
		else if (lane.failure?.[1][0] === NOT_FOUND) {
			lane.failure[2] = await getNotFoundBoundary(router, lane.matches, lane.failure, signal);
			loaderEnd = Math.min(loaderEnd, lane.failure[2] + 1);
		}
		const tasks = [];
		for (let index = 0; index < loaderEnd; index++) {
			const task = createLoaderTask(router, lane, index, tasks, signal);
			tasks.push(task);
		}
		let loaderFailure;
		let control = lane.failure?.[1][0] === REDIRECTED ? lane.failure : void 0;
		try {
			await Promise.all(tasks.map((task) => task.outcome.then((loadedOutcome) => {
				const match = lane.matches[task.index];
				const outcome = loadedOutcome;
				if (outcome[0] === SUCCESS) {
					match.loaderData = outcome[1];
					match.status = "success";
					match.error = void 0;
					match.invalid = false;
					match.isFetching = false;
					match.updatedAt = Date.now();
				} else if (outcome[0] === REDIRECTED) {
					control = [task.index, outcome];
					throw control;
				} else {
					if (match.ssr !== false) {
						match.status = "success";
						match.error = void 0;
						match.invalid = true;
						match.isFetching = false;
					}
					if (!loaderFailure && outcome[0] !== SKIPPED) loaderFailure = [task.index, outcome];
				}
			})));
		} catch (cause) {
			if (!Array.isArray(cause)) throw cause;
			control = cause;
		}
		signal?.throwIfAborted();
		if (control?.[1][0] === REDIRECTED) {
			abortMatches(lane.matches, 0, REDIRECT_ABORT_REASON);
			return {
				type: "redirect",
				redirect: control[1][1]
			};
		}
		let failure = lane.failure ?? loaderFailure;
		const plannedBoundary = lane.matches.findIndex((match) => match._notFound);
		let readinessEnd;
		if (failure) {
			const outcomeEnd = failure[2] ??= failure[1][0] === NOT_FOUND ? await getNotFoundBoundary(router, lane.matches, failure, signal) : failure[0];
			for (const task of tasks) {
				if (task.index >= outcomeEnd) break;
				const outcome = await task.outcome;
				if (outcome[0] !== SUCCESS && outcome[0] < REDIRECTED && !("loaderData" in lane.matches[task.index])) {
					failure = [task.index, outcome];
					failure[2] = outcome[0] === NOT_FOUND ? await getNotFoundBoundary(router, lane.matches, failure, signal) : task.index;
					break;
				}
			}
			readinessEnd = failure[2];
		} else readinessEnd = plannedBoundary < 0 ? lane.matches.length : plannedBoundary;
		const requiredFailure = await loadNormalChunks(router, lane, readinessEnd, signal);
		signal?.throwIfAborted();
		if (requiredFailure) {
			if (requiredFailure[1][0] === REDIRECTED) {
				abortMatches(lane.matches, 0, REDIRECT_ABORT_REASON);
				return {
					type: "redirect",
					redirect: requiredFailure[1][1]
				};
			}
			failure = requiredFailure;
		}
		const terminal = await applyFailure(router, lane, failure, signal);
		if (terminal.boundary !== void 0) {
			const match = lane.matches[terminal.boundary];
			if (match.ssr === true) {
				const route = getRoute(router, match);
				try {
					if (terminal.kind === ERROR) await loadRouteChunk(route, "errorComponent");
					else if (match._notFound) await Promise.all([loadRouteChunk(route), loadRouteChunk(route, "notFoundComponent")]);
					else await loadRouteChunk(route, "notFoundComponent");
				} catch {}
				signal?.throwIfAborted();
			}
		}
		signal?.throwIfAborted();
		await projectLane(router, {
			location: lane.location,
			matches: lane.matches
		}, signal);
		signal?.throwIfAborted();
		router.serverSsr?.onCleanup((settled) => {
			if (!settled) abortLane();
		});
		return {
			type: "render",
			status: terminal.status,
			matches: lane.matches
		};
	} finally {
		signal?.removeEventListener("abort", abortLane);
	}
}
async function loadServerRoute(router, opts) {
	if (!opts?._skipLocationUpdate) router.updateLatestLocation();
	const next = router.latestLocation;
	const previous = router._committed;
	const previousEnd = router._lifecycleEnd;
	let result;
	try {
		const canonical = router.buildLocation({
			to: next.pathname,
			search: true,
			params: true,
			hash: true,
			state: true,
			_includeValidateSearch: true
		});
		if (next.publicHref !== canonical.publicHref) throw redirect({ href: canonical.publicHref || "/" });
		const changeInfo = getLocationChangeInfo(next, router.stores.resolvedLocation.get());
		router.emit({
			type: "onBeforeNavigate",
			...changeInfo
		});
		router.emit({
			type: "onBeforeLoad",
			...changeInfo
		});
		opts?._signal?.throwIfAborted();
		result = await waitFor(executeServerLane(router, next, router.matchRoutes(next), opts?._signal), opts?._signal);
		opts?._signal?.throwIfAborted();
	} catch (cause) {
		opts?._signal?.throwIfAborted();
		if (!isRedirect(cause)) throw cause;
		cause.options._fromLocation = next;
		result = {
			type: "redirect",
			redirect: router.resolveRedirect(cause)
		};
	}
	router._serverResult = result;
	let nextEnd = 0;
	router.batch(() => {
		router.stores.location.set(next);
		router.stores.status.set("idle");
		if (result.type === "render") {
			router._committed = result.matches;
			nextEnd = router._lifecycleEnd = lifecycleEnd(result.matches);
			router.stores.setMatches(result.matches);
			router.stores.resolvedLocation.set(next);
		}
	});
	if (result.type === "render") runRouteLifecycle(router, previous, result.matches, previousEnd, nextEnd);
	router._commitPromise?.resolve();
	router._commitPromise = void 0;
}
// node_modules/@tanstack/react-router/dist/esm/utils.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* React.use if available (React 19+), undefined otherwise.
* Use dynamic lookup to avoid Webpack compilation errors with React 18.
*/
var reactUse = import_react.use;
var useLayoutEffect = typeof window === "undefined" ? import_react.useEffect : import_react.useLayoutEffect;
// node_modules/@tanstack/router-core/dist/esm/defer.js
/**
* Well-known symbol used by {@link defer} to tag a promise with
* its deferred state. Consumers can read `promise[TSR_DEFERRED_PROMISE]`
* to access `status`, `data`, or `error`.
*/
var TSR_DEFERRED_PROMISE = Symbol.for("TSR_DEFERRED_PROMISE");
/**
* Wrap a promise with a deferred state for use with `<Await>` and `useAwaited`.
*
* The returned promise is augmented with internal state (status/data/error)
* so UI can read progress or suspend until it settles.
*
* @param _promise The promise to wrap.
* @param options Optional config. Provide `serializeError` to customize how
* errors are serialized for transfer.
* @returns The same promise with attached deferred metadata.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/deferFunction
*/
function defer(_promise, options) {
	const promise = _promise;
	if (promise[TSR_DEFERRED_PROMISE]) return promise;
	promise[TSR_DEFERRED_PROMISE] = { status: "pending" };
	promise.then((data) => {
		promise[TSR_DEFERRED_PROMISE].status = "success";
		promise[TSR_DEFERRED_PROMISE].data = data;
	}).catch((error) => {
		promise[TSR_DEFERRED_PROMISE].status = "error";
		promise[TSR_DEFERRED_PROMISE].error = {
			data: (options?.serializeError ?? defaultSerializeError)(error),
			__isServerError: true
		};
	});
	return promise;
}
// node_modules/@tanstack/router-core/dist/esm/link.js
var preloadWarning = "Error preloading route! ☝️";
// node_modules/@tanstack/router-core/dist/esm/manifest.js
var DEV_STYLES_ATTR = "data-tanstack-router-dev-styles";
function getAssetCrossOrigin(assetCrossOrigin, kind) {
	if (!assetCrossOrigin) return;
	if (typeof assetCrossOrigin === "string") return assetCrossOrigin;
	return assetCrossOrigin[kind];
}
function getManifestScriptFormat(manifest) {
	return manifest?.scriptFormat ?? "module";
}
function getScriptPreloadAttrs(manifest, link, assetCrossOrigin) {
	const preloadLink = resolveManifestAssetLink(link);
	const crossOrigin = getAssetCrossOrigin(assetCrossOrigin, "script") ?? preloadLink.crossOrigin;
	return {
		...getManifestScriptFormat(manifest) === "iife" ? {
			rel: "preload",
			as: "script"
		} : { rel: "modulepreload" },
		href: preloadLink.href,
		fetchPriority: "low",
		...crossOrigin ? { crossOrigin } : {}
	};
}
function resolveManifestAssetLink(link) {
	if (typeof link === "string") return {
		href: link,
		crossOrigin: void 0
	};
	return link;
}
function appendUniqueUserTags(target, tags) {
	if (tags.length === 0) return;
	if (tags.length === 1) {
		target.push(tags[0]);
		return;
	}
	const seen = /* @__PURE__ */ new Set();
	for (const tag of tags) {
		const key = JSON.stringify(tag);
		if (seen.has(key)) continue;
		seen.add(key);
		target.push(tag);
	}
}
function resolveManifestCssLink(link) {
	if (typeof link === "string") return {
		href: link,
		crossOrigin: void 0
	};
	return link;
}
// node_modules/@tanstack/router-core/dist/esm/Matches.js
/**
* Narrows matches based on a path
* @experimental
*/
var isMatch = (match, path) => {
	const parts = path.split(".");
	let part;
	let i = 0;
	let value = match;
	while ((part = parts[i++]) != null && value != null) value = value[part];
	return value != null;
};
// node_modules/@tanstack/router-core/dist/esm/ssr/bodyScripts.js
function getSsrBodyScriptParts(matches, manifest, nonce, routeScriptAttrs) {
	const assetMatches = _getAssetMatches(matches);
	const routeScripts = [];
	const manifestScripts = [];
	for (const match of assetMatches) for (const script of Array.isArray(match.scripts) ? match.scripts : []) {
		if (!script) continue;
		const { children, ...attrs } = script;
		routeScripts.push({
			tag: "script",
			attrs: {
				...attrs,
				...routeScriptAttrs,
				nonce
			},
			children
		});
	}
	if (manifest) for (const match of assetMatches) for (const asset of manifest.routes[match.routeId]?.scripts ?? []) manifestScripts.push({
		tag: "script",
		attrs: {
			...asset.attrs,
			nonce
		},
		children: asset.children
	});
	return [routeScripts, manifestScripts];
}
function composeSsrBodyScripts([routeScripts, manifestScripts], initialHydrationScripts) {
	if (!initialHydrationScripts) return [...routeScripts, ...manifestScripts];
	return [
		...initialHydrationScripts.before,
		...routeScripts,
		...manifestScripts,
		initialHydrationScripts.boundary
	];
}
// node_modules/@tanstack/router-core/dist/esm/route.js
var BaseRoute = class {
	get to() {
		return this._to;
	}
	get id() {
		return this._id;
	}
	get path() {
		return this._path;
	}
	get fullPath() {
		return this._fullPath;
	}
	constructor(options) {
		this.init = (originalIndex) => {
			this.originalIndex = originalIndex;
			this._branch = void 0;
			const options = this.options;
			const isRoot = !options?.path && !options?.id;
			this.parentRoute = this.options.getParentRoute?.();
			if (isRoot) this._path = rootRouteId;
			else if (!this.parentRoute) throw new Error(`Invariant failed: Child Route instances must pass a 'getParentRoute: () => ParentRoute' option that returns a Route instance.`);
			let path = isRoot ? rootRouteId : options?.path;
			if (path && path !== "/") path = trimPathLeft(path);
			const customId = options?.id || path;
			const id = isRoot ? rootRouteId : cleanPath((this.parentRoute.id === "__root__" ? "" : this.parentRoute.id) + "/" + (customId ?? ""));
			if (path === "__root__") path = "/";
			const fullPath = id === "__root__" ? "/" : path === void 0 ? this.parentRoute.fullPath : cleanPath(this.parentRoute.fullPath + "/" + path);
			this._path = path;
			this._id = id;
			this._fullPath = fullPath;
			this._to = trimPathRight(fullPath);
		};
		this.addChildren = (children) => {
			return this._addFileChildren(children);
		};
		this._addFileChildren = (children) => {
			if (Array.isArray(children)) this.children = children;
			if (typeof children === "object" && children !== null) this.children = Object.values(children);
			return this;
		};
		this._addFileTypes = () => {
			return this;
		};
		this.updateLoader = (options) => {
			Object.assign(this.options, options);
			return this;
		};
		this.update = (options) => {
			Object.assign(this.options, options);
			return this;
		};
		this.lazy = (lazyFn) => {
			this.lazyFn = lazyFn;
			return this;
		};
		this.redirect = (opts) => redirect({
			from: this.fullPath,
			...opts
		});
		this.options = options || {};
		this.isRoot = !options?.getParentRoute;
		if (options?.id && options?.path) throw new Error(`Route cannot have both an 'id' and a 'path' option.`);
	}
};
var BaseRouteApi = class {
	constructor({ id }) {
		this.notFound = (opts) => {
			return notFound({
				routeId: this.id,
				...opts
			});
		};
		this.redirect = (opts) => redirect({
			from: this.id,
			...opts
		});
		this.id = id;
	}
};
var BaseRootRoute = class extends BaseRoute {
	constructor(options) {
		super(options);
	}
};
// node_modules/@tanstack/router-core/dist/esm/config.js
var createRouterConfig = (options) => {
	return {
		serializationAdapters: options.serializationAdapters,
		defaultSsr: options.defaultSsr
	};
};
// node_modules/@tanstack/router-core/dist/esm/searchMiddleware.js
/**
* Retain specified search params across navigations.
*
* If `keys` is `true`, retain all current params. Otherwise, copy only the
* listed keys from the current search into the next search.
*
* @param keys `true` to retain all, or a list of keys to retain.
* @returns A search middleware suitable for route `search.middlewares`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/retainSearchParamsFunction
*/
function retainSearchParams(keys) {
	return ({ search, next }) => {
		const { search: resultSearch, meta } = next(search, true);
		if (keys === true) {
			const copy = {
				...search,
				...resultSearch
			};
			const removed = meta.removed;
			const explicit = meta.explicit;
			for (const key of removed?.keys() || []) if (explicit && hasOwn.call(explicit, key) || deepEqual(search[key], removed.get(key))) delete copy[key];
			for (const key of meta.removedAny || []) delete copy[key];
			for (const key of meta.defaulted?.keys() || []) if (key in search && !meta.removedAny?.has(key) && !(meta.removed?.has(key) && (explicit && hasOwn.call(explicit, key) || deepEqual(search[key], meta.removed.get(key))))) copy[key] = search[key];
			return copy;
		}
		const copy = { ...resultSearch };
		const explicit = meta.explicit;
		for (const key of keys) {
			const stringKey = key;
			if (!(meta.removedAny?.has(stringKey) || meta.removed?.has(stringKey) && (explicit && hasOwn.call(explicit, stringKey) || deepEqual(search[key], meta.removed.get(stringKey)))) && (!(key in copy) || key in search && meta.defaulted?.has(stringKey) && deepEqual(copy[key], meta.defaulted.get(stringKey)))) copy[key] = search[key];
		}
		return copy;
	};
}
/**
* Remove optional or default-valued search params from navigations.
*
* - Pass `true` (only if there are no required search params) to strip all.
* - Pass an array to always remove those optional keys.
* - Pass an object of default values; keys equal (deeply) to the defaults are removed.
*
* @returns A search middleware suitable for route `search.middlewares`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/stripSearchParamsFunction
*/
function stripSearchParams(input) {
	return (({ search, next, meta }) => {
		if (input === true) {
			Object.keys(search).forEach((key) => {
				if (meta) (meta.removedAny ||= /* @__PURE__ */ new Set()).add(key);
			});
			return {};
		}
		const result = { ...next(search) };
		if (Array.isArray(input)) input.forEach((key) => {
			delete result[key];
			if (meta) (meta.removedAny ||= /* @__PURE__ */ new Set()).add(key);
		});
		else Object.entries(input).forEach(([key, value]) => {
			if (deepEqual(result[key], value)) {
				delete result[key];
				if (meta) (meta.removed ||= /* @__PURE__ */ new Map()).set(key, value);
			}
		});
		return result;
	});
}
// node_modules/@tanstack/router-core/dist/esm/ssr/serializer/transformer.js
/**
* Create a strongly-typed serialization adapter for SSR hydration.
* Use to register custom types with the router serializer.
*/
function createSerializationAdapter(opts) {
	if (!opts.key || /[\0"\\<\b\t\f\r\n\u2028\u2029\uD800-\uDFFF]/.test(opts.key)) throw new Error(`createSerializationAdapter: key ${JSON.stringify(opts.key)} is invalid. Serialization adapter keys must be non-empty and not contain NUL, ", \\, <, backspace, tab, form feed, line terminators, or UTF-16 surrogate code units.`);
	return opts;
}
// node_modules/@tanstack/react-router/dist/esm/awaited.js
var import_jsx_runtime = require_jsx_runtime();
/** Suspend until a deferred promise resolves or rejects and return its data. */
function useAwaited({ promise: _promise }) {
	if (reactUse) return reactUse(_promise);
	const promise = defer(_promise);
	if (promise[TSR_DEFERRED_PROMISE].status === "pending") throw promise;
	if (promise[TSR_DEFERRED_PROMISE].status === "error") throw promise[TSR_DEFERRED_PROMISE].error;
	return promise[TSR_DEFERRED_PROMISE].data;
}
/**
* Component that suspends on a deferred promise and renders its child with
* the resolved value. Optionally provides a Suspense fallback.
*/
function Await(props) {
	const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AwaitInner, { ...props });
	if (props.fallback) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: props.fallback,
		children: inner
	});
	return inner;
}
function AwaitInner(props) {
	const data = useAwaited(props);
	return props.children(data);
}
// node_modules/@tanstack/react-router/dist/esm/nonRouteComponentContext.js
var nonRouteComponentContext = import_react.createContext(void 0);
function wrapInNonRouteComponentContext(element, component) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(nonRouteComponentContext.Provider, {
		value: component,
		children: element
	});
}
// node_modules/@tanstack/react-router/dist/esm/CatchBoundary.js
var CatchBoundary = class extends import_react.Component {
	constructor(..._args) {
		super(..._args);
		this.state = { error: 0 };
		this.reset = () => {
			this.setState({ error: 0 });
		};
	}
	static getDerivedStateFromProps(props, state) {
		const resetKey = props.getResetKey();
		if (state.error && state.resetKey !== resetKey) return {
			resetKey,
			error: 0
		};
		return { resetKey };
	}
	static getDerivedStateFromError(error) {
		return { error: [error] };
	}
	componentDidCatch(error, errorInfo) {
		this.props.onCatch?.(error, errorInfo);
	}
	render() {
		const error = this.state.error;
		if (error) return wrapInNonRouteComponentContext(import_react.createElement(this.props.errorComponent ?? ErrorComponent, {
			error: error[0],
			reset: this.reset
		}), "errorComponent");
		return this.props.children;
	}
};
function ErrorComponent({ error }) {
	const [show, setShow] = import_react.useState(true);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			padding: ".5rem",
			maxWidth: "100%"
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: ".5rem"
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					style: { fontSize: "1rem" },
					children: "Something went wrong!"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					style: {
						appearance: "none",
						fontSize: ".6em",
						border: "1px solid currentColor",
						padding: ".1rem .2rem",
						fontWeight: "bold",
						borderRadius: ".25rem"
					},
					onClick: () => setShow((d) => !d),
					children: show ? "Hide Error" : "Show Error"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { height: ".25rem" } }),
			show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				style: {
					fontSize: ".7em",
					border: "1px solid red",
					borderRadius: ".25rem",
					padding: ".3rem",
					color: "red",
					overflow: "auto"
				},
				children: error?.message ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: error.message }) : null
			}) }) : null
		]
	});
}
// node_modules/@tanstack/react-router/dist/esm/ClientOnly.js
var getSnapshot = () => true;
var getServerSnapshot = () => false;
/**
* Render the children only after the JS has loaded client-side. Use an optional
* fallback component if the JS is not yet loaded.
*
* @example
* Render a Chart component if JS loads, renders a simple FakeChart
* component server-side or if there is no JS. The FakeChart can have only the
* UI without the behavior or be a loading spinner or skeleton.
*
* ```tsx
* return (
*   <ClientOnly fallback={<FakeChart />}>
*     <Chart />
*   </ClientOnly>
* )
* ```
*/
function ClientOnly({ children, fallback = null }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Fragment, { children: useHydrated() ? children : fallback });
}
/** @internal */
function useHydrated(enabled = true) {
	return import_react.useSyncExternalStore(subscribe, getSnapshot, enabled ? getServerSnapshot : getSnapshot);
}
function subscribe() {
	return () => {};
}
// node_modules/@tanstack/react-router/dist/esm/routerContext.js
var routerContext = import_react.createContext(null);
// node_modules/@tanstack/react-router/dist/esm/useRouter.js
/**
* Access the current TanStack Router instance from React context.
* Must be used within a `RouterProvider`.
*
* Options:
* - `warn`: Log a warning if no router context is found (default: true).
*
* @returns The registered router instance.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useRouterHook
*/
function useRouter(opts) {
	const value = import_react.useContext(routerContext);
	if (!value) warnMissingRouter(opts);
	return value;
}
function warnMissingRouter(opts) {
	if (opts?.warn ?? true) console.warn("Warning: useRouter must be used inside a <RouterProvider> component!");
}
// node_modules/@tanstack/react-router/dist/esm/matchContext.js
function createLinkScope(router, routeId) {
	const store = router.stores.location;
	const listeners = /* @__PURE__ */ new Set();
	let source;
	let unsubscribe;
	const update = (location) => {
		if (!_isRouteDeparting(router, routeId, location)) {
			source = location;
			listeners.forEach((listener) => listener());
		}
	};
	return [() => source ?? store.get(), (listener) => {
		if (!listeners.size) {
			source = store.get();
			unsubscribe = store.subscribe(update).unsubscribe;
		}
		listeners.add(listener);
		return () => {
			listeners.delete(listener);
			if (!listeners.size) {
				unsubscribe();
				source = void 0;
			}
		};
	}];
}
var matchContext = import_react.createContext(void 0);
var dummyMatchContext = import_react.createContext(void 0);
// node_modules/@tanstack/store/dist/alien.js
/* @__NO_SIDE_EFFECTS__ */
function createReactiveSystem({ update, notify, unwatched }) {
	return {
		link,
		unlink,
		propagate,
		checkDirty,
		shallowPropagate
	};
	function link(dep, sub, version) {
		const prevDep = sub.depsTail;
		if (prevDep !== void 0 && prevDep.dep === dep) return;
		const nextDep = prevDep !== void 0 ? prevDep.nextDep : sub.deps;
		if (nextDep !== void 0 && nextDep.dep === dep) {
			nextDep.version = version;
			sub.depsTail = nextDep;
			return;
		}
		const prevSub = dep.subsTail;
		if (prevSub !== void 0 && prevSub.version === version && prevSub.sub === sub) return;
		const newLink = sub.depsTail = dep.subsTail = {
			version,
			dep,
			sub,
			prevDep,
			nextDep,
			prevSub,
			nextSub: void 0
		};
		if (nextDep !== void 0) nextDep.prevDep = newLink;
		if (prevDep !== void 0) prevDep.nextDep = newLink;
		else sub.deps = newLink;
		if (prevSub !== void 0) prevSub.nextSub = newLink;
		else dep.subs = newLink;
	}
	function unlink(link, sub = link.sub) {
		const dep = link.dep;
		const prevDep = link.prevDep;
		const nextDep = link.nextDep;
		const nextSub = link.nextSub;
		const prevSub = link.prevSub;
		if (nextDep !== void 0) nextDep.prevDep = prevDep;
		else sub.depsTail = prevDep;
		if (prevDep !== void 0) prevDep.nextDep = nextDep;
		else sub.deps = nextDep;
		if (nextSub !== void 0) nextSub.prevSub = prevSub;
		else dep.subsTail = prevSub;
		if (prevSub !== void 0) prevSub.nextSub = nextSub;
		else if ((dep.subs = nextSub) === void 0) unwatched(dep);
		return nextDep;
	}
	function propagate(link) {
		let next = link.nextSub;
		let stack;
		top: do {
			const sub = link.sub;
			let flags = sub.flags;
			if (!(flags & 60)) sub.flags = flags | 32;
			else if (!(flags & 12)) flags = 0;
			else if (!(flags & 4)) sub.flags = flags & -9 | 32;
			else if (!(flags & 48) && isValidLink(link, sub)) {
				sub.flags = flags | 40;
				flags &= 1;
			} else flags = 0;
			if (flags & 2) notify(sub);
			if (flags & 1) {
				const subSubs = sub.subs;
				if (subSubs !== void 0) {
					const nextSub = (link = subSubs).nextSub;
					if (nextSub !== void 0) {
						stack = {
							value: next,
							prev: stack
						};
						next = nextSub;
					}
					continue;
				}
			}
			if ((link = next) !== void 0) {
				next = link.nextSub;
				continue;
			}
			while (stack !== void 0) {
				link = stack.value;
				stack = stack.prev;
				if (link !== void 0) {
					next = link.nextSub;
					continue top;
				}
			}
			break;
		} while (true);
	}
	function checkDirty(link, sub) {
		let stack;
		let checkDepth = 0;
		let dirty = false;
		top: do {
			const dep = link.dep;
			const flags = dep.flags;
			if (sub.flags & 16) dirty = true;
			else if ((flags & 17) === 17) {
				if (update(dep)) {
					const subs = dep.subs;
					if (subs.nextSub !== void 0) shallowPropagate(subs);
					dirty = true;
				}
			} else if ((flags & 33) === 33) {
				if (link.nextSub !== void 0 || link.prevSub !== void 0) stack = {
					value: link,
					prev: stack
				};
				link = dep.deps;
				sub = dep;
				++checkDepth;
				continue;
			}
			if (!dirty) {
				const nextDep = link.nextDep;
				if (nextDep !== void 0) {
					link = nextDep;
					continue;
				}
			}
			while (checkDepth--) {
				const firstSub = sub.subs;
				const hasMultipleSubs = firstSub.nextSub !== void 0;
				if (hasMultipleSubs) {
					link = stack.value;
					stack = stack.prev;
				} else link = firstSub;
				if (dirty) {
					if (update(sub)) {
						if (hasMultipleSubs) shallowPropagate(firstSub);
						sub = link.sub;
						continue;
					}
					dirty = false;
				} else sub.flags &= -33;
				sub = link.sub;
				const nextDep = link.nextDep;
				if (nextDep !== void 0) {
					link = nextDep;
					continue top;
				}
			}
			return dirty;
		} while (true);
	}
	function shallowPropagate(link) {
		do {
			const sub = link.sub;
			const flags = sub.flags;
			if ((flags & 48) === 32) {
				sub.flags = flags | 16;
				if ((flags & 6) === 2) notify(sub);
			}
		} while ((link = link.nextSub) !== void 0);
	}
	function isValidLink(checkLink, sub) {
		let link = sub.depsTail;
		while (link !== void 0) {
			if (link === checkLink) return true;
			link = link.prevDep;
		}
		return false;
	}
}
// node_modules/@tanstack/store/dist/atom.js
function toObserver(nextHandler, errorHandler, completionHandler) {
	const isObserver = typeof nextHandler === "object";
	const self = isObserver ? nextHandler : void 0;
	return {
		next: (isObserver ? nextHandler.next : nextHandler)?.bind(self),
		error: (isObserver ? nextHandler.error : errorHandler)?.bind(self),
		complete: (isObserver ? nextHandler.complete : completionHandler)?.bind(self)
	};
}
var queuedEffects = [];
var cycle = 0;
var { link, unlink, propagate, checkDirty, shallowPropagate } = /* @__PURE__ */ createReactiveSystem({
	update(atom) {
		return atom._update();
	},
	notify(effect) {
		queuedEffects[queuedEffectsLength++] = effect;
		effect.flags &= -3;
	},
	unwatched(atom) {
		if (atom.depsTail !== void 0) {
			atom.depsTail = void 0;
			atom.flags = 17;
			purgeDeps(atom);
		}
	}
});
var notifyIndex = 0;
var queuedEffectsLength = 0;
var activeSub;
var batchDepth = 0;
function batch(fn) {
	try {
		++batchDepth;
		fn();
	} finally {
		if (!--batchDepth) flush();
	}
}
function purgeDeps(sub) {
	const depsTail = sub.depsTail;
	let dep = depsTail !== void 0 ? depsTail.nextDep : sub.deps;
	while (dep !== void 0) dep = unlink(dep, sub);
}
function flush() {
	if (batchDepth > 0) return;
	while (notifyIndex < queuedEffectsLength) {
		const effect = queuedEffects[notifyIndex];
		queuedEffects[notifyIndex++] = void 0;
		effect.notify();
	}
	notifyIndex = 0;
	queuedEffectsLength = 0;
}
function createAtom(valueOrFn, options) {
	const isComputed = typeof valueOrFn === "function";
	const getter = valueOrFn;
	const atom = {
		_snapshot: isComputed ? void 0 : valueOrFn,
		subs: void 0,
		subsTail: void 0,
		deps: void 0,
		depsTail: void 0,
		flags: isComputed ? 0 : 1,
		get() {
			if (activeSub !== void 0) link(atom, activeSub, cycle);
			return atom._snapshot;
		},
		subscribe(observerOrFn) {
			const obs = toObserver(observerOrFn);
			const observed = { current: false };
			const e = effect(() => {
				atom.get();
				if (!observed.current) observed.current = true;
				else {
					activeSub = void 0;
					obs.next?.(atom._snapshot);
				}
			});
			return { unsubscribe: () => {
				e.stop();
			} };
		},
		_update(getValue) {
			const prevSub = activeSub;
			const compare = options?.compare ?? Object.is;
			if (isComputed) {
				activeSub = atom;
				++cycle;
				atom.depsTail = void 0;
			} else if (getValue === void 0) return false;
			if (isComputed) atom.flags = 5;
			try {
				const oldValue = atom._snapshot;
				const newValue = typeof getValue === "function" ? getValue(oldValue) : getValue === void 0 && isComputed ? getter(oldValue) : getValue;
				if (oldValue === void 0 || !compare(oldValue, newValue)) {
					atom._snapshot = newValue;
					return true;
				}
				return false;
			} finally {
				activeSub = prevSub;
				if (isComputed) atom.flags &= -5;
				purgeDeps(atom);
			}
		}
	};
	if (isComputed) {
		atom.flags = 17;
		atom.get = function() {
			const flags = atom.flags;
			if (flags & 16 || flags & 32 && checkDirty(atom.deps, atom)) {
				if (atom._update()) {
					const subs = atom.subs;
					if (subs !== void 0) shallowPropagate(subs);
				}
			} else if (flags & 32) atom.flags = flags & -33;
			if (activeSub !== void 0) link(atom, activeSub, cycle);
			return atom._snapshot;
		};
	} else atom.set = function(valueOrFn) {
		if (atom._update(valueOrFn)) {
			const subs = atom.subs;
			if (subs !== void 0) {
				propagate(subs);
				shallowPropagate(subs);
				flush();
			}
		}
	};
	return atom;
}
function effect(fn) {
	const run = () => {
		const prevSub = activeSub;
		activeSub = effectObj;
		++cycle;
		effectObj.depsTail = void 0;
		effectObj.flags = 6;
		try {
			return fn();
		} finally {
			activeSub = prevSub;
			effectObj.flags &= -5;
			purgeDeps(effectObj);
		}
	};
	const effectObj = {
		deps: void 0,
		depsTail: void 0,
		subs: void 0,
		subsTail: void 0,
		flags: 6,
		notify() {
			const flags = this.flags;
			if (flags & 16 || flags & 32 && checkDirty(this.deps, this)) run();
			else this.flags = 2;
		},
		stop() {
			this.flags = 0;
			this.depsTail = void 0;
			purgeDeps(this);
		}
	};
	run();
	return effectObj;
}
// node_modules/@tanstack/react-store/dist/useSelector.js
var import_with_selector = require_with_selector();
function defaultCompare(a, b) {
	return a === b;
}
/**
* Selects a slice of state from an atom or store and subscribes the component
* to that selection.
*
* This is the primary React read hook for TanStack Store. It works with any
* source that exposes `get()` and `subscribe()`, including atoms, readonly
* atoms, stores, and readonly stores.
*
* Omit the selector to subscribe to the whole value.
*
* @example
* ```tsx
* const count = useSelector(counterStore, (state) => state.count)
* ```
*
* @example
* ```tsx
* const value = useSelector(countAtom)
* ```
*/
function useSelector(source, selector = (s) => s, options) {
	const compare = options?.compare ?? defaultCompare;
	const subscribe = (0, import_react.useCallback)((handleStoreChange) => {
		const { unsubscribe } = source.subscribe(handleStoreChange);
		return unsubscribe;
	}, [source]);
	const getSnapshot = (0, import_react.useCallback)(() => source.get(), [source]);
	return (0, import_with_selector.useSyncExternalStoreWithSelector)(subscribe, getSnapshot, getSnapshot, selector, compare);
}
// node_modules/@tanstack/react-router/dist/esm/useMatch.js
var dummyMatch = {};
function useStructuralSharing(opts, router) {
	const previousResult = import_react.useRef();
	return (slice) => {
		const selected = opts?.select ? opts.select(slice) : slice;
		if (opts?.structuralSharing ?? router.options.defaultStructuralSharing) return previousResult.current = replaceEqualDeep(previousResult.current, selected);
		return selected;
	};
}
/**
* Read and select the nearest or targeted route match.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useMatchHook
*/
function useMatch(opts) {
	const router = useRouter();
	const nearestRouteId = import_react.useContext(opts.from ? dummyMatchContext : matchContext);
	const routeId = opts.from ?? nearestRouteId;
	const matchStore = router.stores.getMatchStore(routeId);
	if (router.isServer) {
		const match = matchStore.get();
		if (!match) {
			if (opts.shouldThrow ?? true) throw new Error(`Invariant failed: Could not find ${opts.from ? `an active match from "${opts.from}"` : "a nearest match!"}`);
			return;
		}
		return opts.select ? opts.select(match) : match;
	}
	const selector = useStructuralSharing(opts, router);
	const matchSelection = useSelector(matchStore, (match) => match ? selector(match) : dummyMatch);
	if (matchSelection !== dummyMatch) return matchSelection;
	if (opts.shouldThrow ?? true) throw new Error(`Invariant failed: Could not find ${opts.from ? `an active match from "${opts.from}"` : "a nearest match!"}`);
}
// node_modules/@tanstack/react-router/dist/esm/useLoaderData.js
/**
* Read and select the current route's loader data with type‑safety.
*
* Options:
* - `from`/`strict`: Choose which route's data to read and strictness
* - `select`: Map the loader data to a derived value
* - `structuralSharing`: Enable structural sharing for stable references
*
* @returns The loader data (or selected value) for the matched route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useLoaderDataHook
*/
function useLoaderData(opts) {
	return useMatch({
		from: opts.from,
		strict: opts.strict,
		structuralSharing: opts.structuralSharing,
		select: (match) => {
			return opts.select ? opts.select(match.loaderData) : match.loaderData;
		}
	});
}
// node_modules/@tanstack/react-router/dist/esm/useLoaderDeps.js
/**
* Read and select the current route's loader dependencies object.
*
* Options:
* - `from`: Choose which route's loader deps to read
* - `select`: Map the deps to a derived value
* - `structuralSharing`: Enable structural sharing for stable references
*
* @returns The loader deps (or selected value) for the matched route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useLoaderDepsHook
*/
function useLoaderDeps(opts) {
	const { select, ...rest } = opts;
	return useMatch({
		...rest,
		select: (match) => {
			return select ? select(match.loaderDeps) : match.loaderDeps;
		}
	});
}
// node_modules/@tanstack/react-router/dist/esm/useParams.js
/**
* Access the current route's path parameters with type-safety.
*
* Options:
* - `from`/`strict`: Specify the matched route and whether to enforce strict typing
* - `select`: Project the params object to a derived value for memoized renders
* - `structuralSharing`: Enable structural sharing for stable references
* - `shouldThrow`: Throw if the route is not found in strict contexts
*
* @returns The params object (or selected value) for the matched route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useParamsHook
*/
function useParams(opts) {
	return useMatch({
		from: opts.from,
		shouldThrow: opts.shouldThrow,
		structuralSharing: opts.structuralSharing,
		strict: opts.strict,
		select: (match) => {
			const params = opts.strict === false ? match.params : match._strictParams;
			return opts.select ? opts.select(params) : params;
		}
	});
}
// node_modules/@tanstack/react-router/dist/esm/useSearch.js
/**
* Read and select the current route's search parameters with type-safety.
*
* Options:
* - `from`/`strict`: Control which route's search is read and how strictly it's typed
* - `select`: Map the search object to a derived value for render optimization
* - `structuralSharing`: Enable structural sharing for stable references
* - `shouldThrow`: Throw when the route is not found (strict contexts)
*
* @returns The search object (or selected value) for the matched route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useSearchHook
*/
function useSearch(opts) {
	return useMatch({
		from: opts.from,
		strict: opts.strict,
		shouldThrow: opts.shouldThrow,
		structuralSharing: opts.structuralSharing,
		select: (match) => {
			return opts.select ? opts.select(match.search) : match.search;
		}
	});
}
// node_modules/@tanstack/react-router/dist/esm/useNavigate.js
/**
* Imperative navigation hook.
*
* Returns a stable `navigate(options)` function to change the current location
* programmatically. Prefer the `Link` component for user-initiated navigation,
* and use this hook from effects, callbacks, or handlers where imperative
* navigation is required.
*
* Options:
* - `from`: Optional route base used to resolve relative `to` paths.
*
* @returns A function that accepts `NavigateOptions`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useNavigateHook
*/
function useNavigate(_defaultOpts) {
	const router = useRouter();
	return import_react.useCallback((options) => {
		return router.navigate({
			...options,
			from: options.from ?? _defaultOpts?.from
		});
	}, [_defaultOpts?.from, router]);
}
/**
* Component that triggers a navigation when rendered. Navigation executes
* in an effect after mount/update.
*
* Props are the same as `NavigateOptions` used by `navigate()`.
*
* @returns null
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/navigateComponent
*/
function Navigate(props) {
	const router = useRouter();
	const navigate = useNavigate();
	const previousPropsRef = import_react.useRef(null);
	useLayoutEffect(() => {
		if (previousPropsRef.current !== props) {
			navigate(props);
			previousPropsRef.current = props;
		}
	}, [
		router,
		props,
		navigate
	]);
	return null;
}
// node_modules/@tanstack/react-router/dist/esm/useRouteContext.js
function useRouteContext(opts) {
	return useMatch({
		...opts,
		select: (match) => opts.select ? opts.select(match.context) : match.context
	});
}
// node_modules/@tanstack/react-router/dist/esm/link.js
function useStableValues(...values) {
	const ref = import_react.useRef(values);
	const stable = ref.current;
	values.forEach((value, index) => {
		if (!deepEqual(stable[index], value, false, true)) stable[index] = value;
	});
	return ref.current;
}
function preloadLink(router, options) {
	router.preloadRoute(options).catch((err) => {
		console.warn(err);
		console.warn(preloadWarning);
	});
}
function resolveExternalLink(to, protocolAllowlist) {
	const scheme = typeof to === "string" && getUrlScheme(to);
	if (!scheme) return;
	if (!protocolAllowlist.has(scheme)) {
		console.warn(`Blocked Link with dangerous protocol: ${to}`);
		return null;
	}
	return to;
}
function resolveIsActive(location, next, activeOptions, basepath) {
	const currentPath = removeTrailingSlash(location.pathname, basepath);
	const nextPath = removeTrailingSlash(next.pathname, basepath);
	if (activeOptions?.exact ? currentPath !== nextPath : !(currentPath.startsWith(nextPath) && (currentPath.length === nextPath.length || currentPath[nextPath.length] === "/"))) return false;
	if (activeOptions?.includeSearch ?? true) {
		if (!deepEqual(location.search, next.search, !activeOptions?.exact, activeOptions?.explicitUndefined)) return false;
	}
	return !activeOptions?.includeHash || location.hash === next.hash;
}
function useLinkProps(options, forwardedRef, host) {
	const router = useRouter();
	if (router.isServer) return getServerLinkProps(router, options, forwardedRef, host);
	const innerRef = import_react.useRef(null);
	const mergedRef = import_react.useCallback((element) => {
		innerRef.current = element;
		if (typeof forwardedRef === "function") return forwardedRef(element);
		if (forwardedRef) forwardedRef.current = element;
	}, [forwardedRef]);
	const { activeOptions, to, preload: userPreload, preloadDelay: userPreloadDelay, disabled, target, onClick, onBlur, onFocus, onMouseEnter, onMouseLeave, onTouchStart } = options;
	const [stableSearch, stableParams, stableActiveOptions] = useStableValues(options.search, options.params, activeOptions);
	const routeId = import_react.useContext(matchContext);
	const scope = (router.stores._linkScopes ??= {})[routeId] ??= createLinkScope(router, routeId);
	const [dest, getLinkState, getHydrationState] = import_react.useMemo(() => {
		const directExternalLink = resolveExternalLink(to, router.protocolAllowlist);
		if (directExternalLink !== void 0) {
			const state = [directExternalLink ?? void 0];
			return [options, () => state];
		}
		const dest = { ...options };
		let source;
		let state;
		let hydrationState;
		const getLinkState = () => {
			const location = scope[0]();
			if (location !== source) {
				dest._fromLocation = location;
				const next = router.buildLocation(dest);
				const href = getHrefOption(next, router, disabled);
				const isActive = disabled || href && !getUrlScheme(href) ? resolveIsActive(location, next, stableActiveOptions, router.basepath) : void 0;
				if (!state || state[0] !== href || state[1] !== isActive) state = [href, isActive];
				source = location;
			}
			return state;
		};
		return [
			dest,
			getLinkState,
			stableActiveOptions?.includeHash && (() => {
				const state = getLinkState();
				return state[1] ? hydrationState ??= [state[0], false] : state;
			})
		];
	}, [
		router,
		scope,
		options.from,
		options.hash,
		options.href,
		to,
		stableSearch,
		stableParams,
		options.state,
		options.mask,
		options.unsafeRelative,
		stableActiveOptions,
		disabled
	]);
	const [href, isActive] = import_react.useSyncExternalStore(scope[1], getLinkState, getHydrationState || getLinkState);
	const externalLink = isActive === void 0 && href;
	const linkDisabled = disabled || href === void 0;
	const hasRenderFetched = import_react.useRef(false);
	const preload = options.reloadDocument || externalLink || linkDisabled ? false : userPreload ?? router.options.defaultPreload;
	const preloadDelay = userPreloadDelay ?? router.options.defaultPreloadDelay ?? 0;
	const enqueuePreload = import_react.useCallback((e) => {
		const isIntersecting = e?.isIntersecting;
		if (!(isIntersecting ?? preload === "intent")) {
			if (isIntersecting === false) cancelPreload(innerRef);
			return;
		}
		if (!preloadDelay) {
			preloadLink(router, dest);
			return;
		}
		innerRef.t ??= setTimeout(() => {
			innerRef.t = void 0;
			preloadLink(router, dest);
		}, preloadDelay);
	}, [
		router,
		dest,
		innerRef,
		preload,
		preloadDelay
	]);
	import_react.useEffect(() => {
		if (!preload) return;
		if (preload === "render" && !hasRenderFetched.current) {
			hasRenderFetched.current = true;
			preloadLink(router, dest);
		}
		let active = true;
		let observer;
		if (preload === "viewport" && innerRef.current && typeof IntersectionObserver === "function") {
			observer = new IntersectionObserver((entries) => {
				if (active) enqueuePreload(entries.pop());
			}, { rootMargin: "100px" });
			observer.observe(innerRef.current);
		}
		return () => {
			active = false;
			observer?.disconnect();
			cancelPreload(innerRef);
		};
	}, [
		router,
		dest,
		preload,
		enqueuePreload,
		innerRef
	]);
	const props = collectElementProps(options, host);
	props.ref = forwardedRef ? mergedRef : innerRef;
	if (externalLink) {
		props.href = externalLink;
		return props;
	}
	const handleClick = (e) => {
		const effectiveTarget = target ?? e.currentTarget.getAttribute("target");
		if (!linkDisabled && !(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey) && !e.defaultPrevented && (!effectiveTarget || effectiveTarget === "_self") && e.button === 0) {
			e.preventDefault();
			cancelPreload(innerRef);
			router.navigate({
				...options,
				_fromLocation: dest._fromLocation
			});
		}
	};
	const handleTouchStart = () => {
		if (preload === "intent") preloadLink(router, dest);
	};
	const handleLeave = () => {
		if (preload === "intent") cancelPreload(innerRef);
	};
	props.onClick = composeHandlers(onClick, handleClick);
	props.onBlur = composeHandlers(onBlur, handleLeave);
	props.onFocus = composeHandlers(onFocus, enqueuePreload);
	props.onMouseEnter = composeHandlers(onMouseEnter, enqueuePreload);
	props.onMouseLeave = composeHandlers(onMouseLeave, handleLeave);
	props.onTouchStart = composeHandlers(onTouchStart, handleTouchStart);
	return applyLinkState(props, options, isActive, href, linkDisabled, host);
}
var STATIC_EMPTY_OBJECT = {};
var STATIC_ACTIVE_OBJECT = { className: "active" };
var ROUTER_OPTION_KEYS = /* @__PURE__ */ new Set([
	"to",
	"params",
	"search",
	"hash",
	"state",
	"mask",
	"from",
	"unsafeRelative",
	"reloadDocument",
	"preload",
	"preloadDelay",
	"preloadIntentProximity",
	"hashScrollIntoView",
	"replace",
	"startTransition",
	"resetScroll",
	"viewTransition",
	"ignoreBlocker",
	"activeProps",
	"inactiveProps",
	"activeOptions",
	"_asChild"
]);
function collectElementProps(options, host) {
	const props = {};
	for (const key in options) {
		if (ROUTER_OPTION_KEYS.has(key) || key === "type" && host !== void 0 || key === "disabled" && host === "a") continue;
		props[key] = options[key];
	}
	return props;
}
function applyLinkState(props, options, isActive, href, linkDisabled, host) {
	const { activeProps, inactiveProps, className, style, target } = options;
	const stateProps = functionalUpdate(isActive ? activeProps : inactiveProps, {}) ?? (isActive ? STATIC_ACTIVE_OBJECT : STATIC_EMPTY_OBJECT);
	Object.assign(props, stateProps);
	props.href = href;
	if (host !== "a") props.disabled = linkDisabled;
	props.target = target;
	const stateStyle = stateProps.style;
	if (style || stateStyle) props.style = style && stateStyle ? {
		...style,
		...stateStyle
	} : style || stateStyle;
	const stateClassName = stateProps.className;
	if (className || stateClassName) props.className = className ? stateClassName ? `${className} ${stateClassName}` : className : stateClassName;
	if (linkDisabled) {
		props.role = "link";
		props["aria-disabled"] = true;
	}
	if (isActive) {
		props["data-status"] = "active";
		props["aria-current"] = "page";
	}
	return props;
}
function getServerLinkProps(router, options, forwardedRef, host) {
	const { to, disabled, activeOptions } = options;
	const directExternalLink = resolveExternalLink(to, router.protocolAllowlist);
	const next = directExternalLink === void 0 ? router.buildLocation(options) : void 0;
	const hrefOption = next ? getHrefOption(next, router, disabled) : directExternalLink ?? void 0;
	const linkDisabled = disabled || !hrefOption;
	const externalLink = directExternalLink ?? (hrefOption && getUrlScheme(hrefOption) ? hrefOption : void 0);
	const props = collectElementProps(options, host);
	props.ref = forwardedRef;
	if (externalLink) {
		props.href = externalLink;
		return props;
	}
	return applyLinkState(props, options, !!next && !(!disabled && !hrefOption) && !activeOptions?.includeHash && resolveIsActive(router.stores.location.get(), next, activeOptions, router.basepath), hrefOption, linkDisabled, host);
}
var cancelPreload = (ref) => {
	clearTimeout(ref.t);
	ref.t = void 0;
};
var composeHandlers = (first, second) => {
	if (!first) return second;
	return (event) => event.defaultPrevented || (first(event), event.defaultPrevented || second(event));
};
function getHrefOption(next, router, disabled) {
	if (disabled) return;
	const location = next.maskedLocation ?? next;
	const href = location.external ? location.publicHref : router.history.createHref(location.publicHref) || "/";
	if ((location.external || href !== location.publicHref) && isDangerousProtocol(href, router.protocolAllowlist)) {
		console.warn(`Blocked Link with dangerous protocol: ${href}`);
		return;
	}
	return href;
}
/**
* Creates a typed Link-like component that preserves TanStack Router's
* navigation semantics and type-safety while delegating rendering to the
* provided host component.
*
* Useful for integrating design system anchors/buttons while keeping
* router-aware props (eg. `to`, `params`, `search`, `preload`).
*
* @param Comp The host component to render (eg. a design-system Link/Button)
* @returns A router-aware component with the same API as `Link`.
* @link https://tanstack.com/router/latest/docs/framework/react/guide/custom-link
*/
function createLink(Comp) {
	return import_react.forwardRef(function CreatedLink(props, ref) {
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			...props,
			_asChild: Comp,
			ref
		});
	});
}
/**
* A strongly-typed anchor component for declarative navigation.
* Handles path, search, hash and state updates with optional route preloading
* and active-state styling.
*
* Props:
* - `preload`: Controls route preloading (eg. 'intent', 'render', 'viewport', true/false)
* - `preloadDelay`: Delay in ms before preloading on focus, hover, or viewport entry
* - `activeProps`/`inactiveProps`: Additional props merged when link is active/inactive
* - `resetScroll`/`hashScrollIntoView`: Control scroll behavior on navigation
* - `viewTransition`/`startTransition`: Use View Transitions/React transitions for navigation
* - `ignoreBlocker`: Bypass registered blockers
*
* @returns An anchor-like element that navigates without full page reloads.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/linkComponent
*/
var Link = import_react.memo(import_react.forwardRef((props, ref) => {
	const host = props._asChild || "a";
	const linkProps = useLinkProps(props, ref, host);
	const children = typeof props.children === "function" ? props.children({ isActive: linkProps["data-status"] === "active" }) : props.children;
	return import_react.createElement(host, linkProps, children);
}), areLinkPropsEqual);
function areLinkPropsEqual(prev, next) {
	let extraKeys = 0;
	for (const key in next) {
		extraKeys++;
		if (prev[key] === next[key]) continue;
		if (!ROUTER_OPTION_KEYS.has(key) || !deepEqual(prev[key], next[key], false, true)) return false;
	}
	for (const _key in prev) extraKeys--;
	return extraKeys === 0;
}
/**
* Validate and reuse navigation options for `Link`, `navigate` or `redirect`.
* Accepts a literal options object and returns it typed for later spreading.
* @example
* const opts = linkOptions({ to: '/dashboard', search: { tab: 'home' } })
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/linkOptions
*/
var linkOptions = (options) => {
	return options;
};
// node_modules/@tanstack/react-router/dist/esm/route.js
/**
* Returns a route-specific API that exposes type-safe hooks pre-bound
* to a single route ID. Useful for consuming a route's APIs from files
* where the route object isn't directly imported (e.g. code-split files).
*
* @param id Route ID string literal for the target route.
* @returns A `RouteApi` instance bound to the given route ID.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/getRouteApiFunction
*/
function getRouteApi(id) {
	return new RouteApi({ id });
}
var RouteApi = class extends BaseRouteApi {
	/**
	* @deprecated Use the `getRouteApi` function instead.
	*/
	constructor({ id }) {
		super({ id });
		this.useMatch = (opts) => {
			return useMatch({
				...opts,
				from: this.id
			});
		};
		this.useRouteContext = (opts) => {
			return useRouteContext({
				...opts,
				from: this.id
			});
		};
		this.useSearch = (opts) => {
			return useSearch({
				...opts,
				from: this.id
			});
		};
		this.useParams = (opts) => {
			return useParams({
				...opts,
				from: this.id
			});
		};
		this.useLoaderDeps = (opts) => {
			return useLoaderDeps({
				...opts,
				from: this.id,
				strict: false
			});
		};
		this.useLoaderData = (opts) => {
			return useLoaderData({
				...opts,
				from: this.id,
				strict: false
			});
		};
		this.useNavigate = () => {
			return useNavigate({ from: useRouter().routesById[this.id].fullPath });
		};
		this.notFound = (opts) => {
			return notFound({
				routeId: this.id,
				...opts
			});
		};
		this.Link = import_react.forwardRef((props, ref) => {
			const fullPath = useRouter().routesById[this.id].fullPath;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				ref,
				from: fullPath,
				...props
			});
		});
	}
};
var Route = class extends BaseRoute {
	/**
	* @deprecated Use the `createRoute` function instead.
	*/
	constructor(options) {
		super(options);
		this.useMatch = (opts) => {
			return useMatch({
				...opts,
				from: this.id
			});
		};
		this.useRouteContext = (opts) => {
			return useRouteContext({
				...opts,
				from: this.id
			});
		};
		this.useSearch = (opts) => {
			return useSearch({
				...opts,
				from: this.id
			});
		};
		this.useParams = (opts) => {
			return useParams({
				...opts,
				from: this.id
			});
		};
		this.useLoaderDeps = (opts) => {
			return useLoaderDeps({
				...opts,
				from: this.id
			});
		};
		this.useLoaderData = (opts) => {
			return useLoaderData({
				...opts,
				from: this.id
			});
		};
		this.useNavigate = () => {
			return useNavigate({ from: this.fullPath });
		};
		this.Link = import_react.forwardRef((props, ref) => {
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				ref,
				from: this.fullPath,
				...props
			});
		});
	}
};
/**
* Creates a non-root Route instance for code-based routing.
*
* Use this to define a route that will be composed into a route tree
* (typically via a parent route's `addChildren`). If you're using file-based
* routing, prefer `createFileRoute`.
*
* @param options Route options (path, component, loader, context, etc.).
* @returns A Route instance to be attached to the route tree.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRouteFunction
*/
function createRoute(options) {
	return new Route(options);
}
/**
* Creates a root route factory that requires a router context type.
*
* Use when your root route expects `context` to be provided to `createRouter`.
* The returned function behaves like `createRootRoute` but enforces a context type.
*
* @returns A factory function to configure and return a root route.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRootRouteWithContextFunction
*/
function createRootRouteWithContext() {
	return (options) => {
		return createRootRoute(options);
	};
}
/**
* @deprecated Use the `createRootRouteWithContext` function instead.
*/
var rootRouteWithContext = createRootRouteWithContext;
var RootRoute = class extends BaseRootRoute {
	/**
	* @deprecated `RootRoute` is now an internal implementation detail. Use `createRootRoute()` instead.
	*/
	constructor(options) {
		super(options);
		this.useMatch = (opts) => {
			return useMatch({
				...opts,
				from: this.id
			});
		};
		this.useRouteContext = (opts) => {
			return useRouteContext({
				...opts,
				from: this.id
			});
		};
		this.useSearch = (opts) => {
			return useSearch({
				...opts,
				from: this.id
			});
		};
		this.useParams = (opts) => {
			return useParams({
				...opts,
				from: this.id
			});
		};
		this.useLoaderDeps = (opts) => {
			return useLoaderDeps({
				...opts,
				from: this.id
			});
		};
		this.useLoaderData = (opts) => {
			return useLoaderData({
				...opts,
				from: this.id
			});
		};
		this.useNavigate = () => {
			return useNavigate({ from: this.fullPath });
		};
		this.Link = import_react.forwardRef((props, ref) => {
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				ref,
				from: this.fullPath,
				...props
			});
		});
	}
};
/**
* Creates a root Route instance used to build your route tree.
*
* Typically paired with `createRouter({ routeTree })`. If you need to require
* a typed router context, use `createRootRouteWithContext` instead.
*
* @param options Root route options (component, error, pending, etc.).
* @returns A root route instance.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRootRouteFunction
*/
function createRootRoute(options) {
	return new RootRoute(options);
}
function createRouteMask(opts) {
	return opts;
}
var NotFoundRoute = class extends Route {
	constructor(options) {
		super({
			...options,
			id: "404"
		});
	}
};
// node_modules/@tanstack/react-router/dist/esm/fileRoute.js
/**
* Creates a file-based Route factory for a given path.
*
* Used by TanStack Router's file-based routing to associate a file with a
* route. The returned function accepts standard route options. In normal usage
* the `path` string is inserted and maintained by the `tsr` generator.
*
* @param path File path literal for the route (usually auto-generated).
* @returns A function that accepts Route options and returns a Route instance.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createFileRouteFunction
*/
function createFileRoute(path) {
	return (options) => {
		const route = createRoute(options);
		route.isRoot = false;
		return route;
	};
}
/** 
@deprecated It's no longer recommended to use the `FileRoute` class directly.
Instead, use `createFileRoute('/path/to/file')(options)` to create a file route.
*/
var FileRoute = class {
	constructor(path, _opts) {
		this.path = path;
		this.createRoute = (options) => {
			if (!this.silent) console.warn("Warning: FileRoute is deprecated and will be removed in the next major version. Use the createFileRoute(path)(options) function instead.");
			const route = createRoute(options);
			route.isRoot = false;
			return route;
		};
		this.silent = _opts?.silent;
	}
};
/**
@deprecated It's recommended not to split loaders into separate files.
Instead, place the loader function in the main route file via `createFileRoute`.
*/
function FileRouteLoader(_path) {
	console.warn(`Warning: FileRouteLoader is deprecated and will be removed in the next major version. Please place the loader function in the main route file, inside the \`createFileRoute('/path/to/file')(options)\` options`);
	return (loaderFn) => loaderFn;
}
var LazyRoute = class {
	constructor(opts) {
		this.useMatch = (opts) => {
			return useMatch({
				...opts,
				from: this.options.id
			});
		};
		this.useRouteContext = (opts) => {
			return useRouteContext({
				...opts,
				from: this.options.id
			});
		};
		this.useSearch = (opts) => {
			return useSearch({
				...opts,
				from: this.options.id
			});
		};
		this.useParams = (opts) => {
			return useParams({
				...opts,
				from: this.options.id
			});
		};
		this.useLoaderDeps = (opts) => {
			return useLoaderDeps({
				...opts,
				from: this.options.id
			});
		};
		this.useLoaderData = (opts) => {
			return useLoaderData({
				...opts,
				from: this.options.id
			});
		};
		this.useNavigate = () => {
			return useNavigate({ from: useRouter().routesById[this.options.id].fullPath });
		};
		this.options = opts;
	}
};
/**
* Creates a lazily-configurable code-based route stub by ID.
*
* Use this for code-splitting with code-based routes. The returned function
* accepts only non-critical route options like `component`, `pendingComponent`,
* `errorComponent`, and `notFoundComponent` which are applied when the route
* is matched.
*
* @param id Route ID string literal to associate with the lazy route.
* @returns A function that accepts lazy route options and returns a `LazyRoute`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createLazyRouteFunction
*/
function createLazyRoute(id) {
	return (opts) => {
		return new LazyRoute({
			id,
			...opts
		});
	};
}
/**
* Creates a lazily-configurable file-based route stub by file path.
*
* Use this for code-splitting with file-based routes (eg. `.lazy.tsx` files).
* The returned function accepts only non-critical route options like
* `component`, `pendingComponent`, `errorComponent`, and `notFoundComponent`.
*
* @param id File path literal for the route file.
* @returns A function that accepts lazy route options and returns a `LazyRoute`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createLazyFileRouteFunction
*/
function createLazyFileRoute(id) {
	if (typeof id === "object") return new LazyRoute(id);
	return (opts) => new LazyRoute({
		id,
		...opts
	});
}
// node_modules/@tanstack/react-router/dist/esm/lazyRouteComponent.js
/**
* Wrap a dynamic import to create a route component that supports
* `.preload()` and friendly reload-on-module-missing behavior.
*
* @param importer Function returning a module promise
* @param exportName Named export to use (default: `default`)
* @returns A lazy route component compatible with TanStack Router
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/lazyRouteComponentFunction
*/
function lazyRouteComponent(importer, exportName) {
	let loadPromise;
	let comp;
	let error;
	const load = () => {
		if (!loadPromise) {
			error = void 0;
			loadPromise = importer().then((res) => {
				if (!(typeof window === "undefined")) {
					loadPromise = void 0;
					lazyComp.preload = void 0;
				}
				comp = res[exportName ?? "default"];
			}).catch((err) => {
				loadPromise = void 0;
				error = err;
			});
		}
		return loadPromise;
	};
	const lazyComp = function Lazy(props) {
		if (error) {
			if (isModuleNotFoundError(error) && !(typeof window === "undefined") && typeof sessionStorage !== "undefined") {
				const storageKey = `tanstack_router_reload:${error.message}`;
				if (!sessionStorage.getItem(storageKey)) {
					sessionStorage.setItem(storageKey, "1");
					window.location.reload();
					throw new Promise(() => {});
				}
			}
			throw error;
		}
		if (!comp) {
			if (reactUse) reactUse(load());
			else throw load();
		}
		return import_react.createElement(comp, props);
	};
	lazyComp.preload = load;
	return lazyComp;
}
// node_modules/@tanstack/react-router/dist/esm/not-found.js
function CatchNotFound(props) {
	const router = useRouter();
	if (router.isServer) {
		const resetKey = `not-found-${router.stores.location.get().pathname}-${router.stores.status.get()}`;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchBoundary, {
			getResetKey: () => resetKey,
			onCatch: (error, errorInfo) => {
				if (isNotFound(error)) props.onCatch?.(error, errorInfo);
				else throw error;
			},
			errorComponent: ({ error }) => {
				if (isNotFound(error)) return props.fallback?.(error);
				else throw error;
			},
			children: props.children
		});
	}
	const resetKey = `not-found-${useSelector(router.stores.location, (location) => location.pathname)}-${useSelector(router.stores.status)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchBoundary, {
		getResetKey: () => resetKey,
		onCatch: (error, errorInfo) => {
			if (isNotFound(error)) props.onCatch?.(error, errorInfo);
			else throw error;
		},
		errorComponent: ({ error }) => {
			if (isNotFound(error)) return props.fallback?.(error);
			else throw error;
		},
		children: props.children
	});
}
function DefaultGlobalNotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Not Found" });
}
// node_modules/@tanstack/react-router/dist/esm/ScriptOnce.js
/**
* Server-only helper to emit a script tag exactly once during SSR.
*/
function ScriptOnce({ children }) {
	const router = useRouter();
	if (!router.isServer) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
		nonce: router.options.ssr?.nonce,
		dangerouslySetInnerHTML: { __html: children + ";document.currentScript.remove()" }
	});
}
// node_modules/@tanstack/react-router/dist/esm/renderRouteNotFound.js
/**
* Renders a not found component for a route when no matching route is found.
*
* @param router - The router instance containing the route configuration
* @param route - The route that triggered the not found state
* @param data - Additional data to pass to the not found component
* @returns The rendered not found component or a default fallback component
*/
function renderRouteNotFound(router, route, data) {
	if (!route.options.notFoundComponent) {
		if (router.options.defaultNotFoundComponent) return wrapInNonRouteComponentContext(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(router.options.defaultNotFoundComponent, { ...data }), "notFoundComponent");
		if (!route.options.notFoundComponent) console.warn(`Warning: A notFoundError was encountered on the route with ID "${route.id}", but a notFoundComponent option was not configured, nor was a router level defaultNotFoundComponent configured. Consider configuring at least one of these to avoid TanStack Router's overly generic defaultNotFoundComponent (<p>Not Found</p>)`);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DefaultGlobalNotFound, {});
	}
	return wrapInNonRouteComponentContext(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(route.options.notFoundComponent, { ...data }), "notFoundComponent");
}
// node_modules/@tanstack/router-core/dist/esm/scroll-restoration-script/client.js
function getScrollRestorationScriptForRouter(_router) {
	return null;
}
// node_modules/@tanstack/react-router/dist/esm/scroll-restoration.js
function ScrollRestoration$1() {
	const script = getScrollRestorationScriptForRouter(useRouter());
	if (!script) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScriptOnce, { children: script });
}
// node_modules/@tanstack/react-router/dist/esm/Match.js
function renderPending(router, route) {
	const PendingComponent = route?.options.pendingComponent ?? router.options.defaultPendingComponent;
	if (!PendingComponent) return null;
	return wrapInNonRouteComponentContext(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PendingComponent, {}), "pendingComponent");
}
var outletMatchSelectionEqual = (a, b) => a[0] === b[0] && a[1] === b[1];
var canWrapInSuspense = (router, route, ssr) => !route.isRoot || route.options.shellComponent || route.options.wrapInSuspense || ssr === false || ssr === "data-only" || !(router.isServer || router.ssr);
var Match = import_react.memo(function MatchImpl({ routeId }) {
	const router = useRouter();
	if (router.isServer) return matchView(router, router.stores.byRoute.get(routeId).get());
	return matchView(router, useSelector(router.stores.getMatchStore(routeId)));
});
function matchView(router, match) {
	const route = router.routesById[match.routeId];
	const pendingElement = renderPending(router, route);
	const routeErrorComponent = route.options.errorComponent ?? router.options.defaultErrorComponent;
	const routeOnCatch = route.options.onCatch ?? router.options.defaultOnCatch;
	const routeNotFoundComponent = route.isRoot ? route.options.notFoundComponent ?? router.options.notFoundRoute?.options.component : route.options.notFoundComponent;
	const resolvedNoSsr = match.ssr === false || match.ssr === "data-only";
	const wrapInSuspense = canWrapInSuspense(router, route, match.ssr) && (route.options.wrapInSuspense ?? pendingElement ?? (route.options.errorComponent?.preload || resolvedNoSsr));
	let content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchInner, { match });
	if (resolvedNoSsr) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClientOnly, {
		fallback: pendingElement,
		children: content
	});
	if (routeNotFoundComponent) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchNotFound, {
		fallback: (error) => {
			error.routeId ??= match.routeId;
			if (error.routeId !== match.routeId) throw error;
			return wrapInNonRouteComponentContext(import_react.createElement(routeNotFoundComponent, error), "notFoundComponent");
		},
		children: content
	});
	if (routeErrorComponent) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchBoundary, {
		getResetKey: () => match,
		errorComponent: routeErrorComponent,
		onCatch: (error, errorInfo) => {
			if (isNotFound(error)) {
				error.routeId ??= match.routeId;
				throw error;
			}
			console.warn(`Warning: Error in route match: ${match.id}`);
			routeOnCatch?.(error, errorInfo);
		},
		children: content
	});
	if (wrapInSuspense) content = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: pendingElement,
		children: content
	});
	const scrollRestoration = router.isServer && route.parentRoute?.id === "__root__" && router.options.scrollRestoration ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollRestoration$1, {}) : null;
	const ShellComponent = route.isRoot && route.options.shellComponent;
	return ShellComponent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(matchContext.Provider, {
		value: match.routeId,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ShellComponent, { children: [content, scrollRestoration] })
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(matchContext.Provider, {
		value: match.routeId,
		children: [content, scrollRestoration]
	});
}
var MatchInner = import_react.memo(function MatchInnerImpl({ match }) {
	const router = useRouter();
	const routeId = match.routeId;
	const route = router.routesById[routeId];
	const key = import_react.useMemo(() => {
		const remountDeps = (route.options.remountDeps ?? router.options.defaultRemountDeps)?.({
			routeId,
			loaderDeps: match.loaderDeps,
			params: match._strictParams,
			search: match._strictSearch
		});
		return remountDeps ? JSON.stringify(remountDeps) : void 0;
	}, [
		routeId,
		match.loaderDeps,
		match._strictParams,
		match._strictSearch,
		route.options.remountDeps,
		router.options.defaultRemountDeps
	]);
	const out = import_react.useMemo(() => {
		const Comp = route.options.component ?? router.options.defaultComponent;
		return Comp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Comp, {}, key) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
	}, [
		key,
		route.options.component,
		router.options.defaultComponent
	]);
	if (match.status === "pending") {
		if (router.ssr && !canWrapInSuspense(router, route, match.ssr)) return out;
		if (router._tx) throw router._tx[5];
		return renderPending(router, route);
	}
	if (match.status === "notFound") return renderRouteNotFound(router, route, match.error);
	if (match.status === "error") {
		if (router.isServer) {
			const RouteErrorComponent = (route.options.errorComponent ?? router.options.defaultErrorComponent) || ErrorComponent;
			return wrapInNonRouteComponentContext(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RouteErrorComponent, {
				error: match.error,
				reset: void 0,
				info: { componentStack: "" }
			}), "errorComponent");
		}
		throw match.error;
	}
	return out;
});
/**
* Render the next child match in the route tree. Typically used inside
* a route component to render nested routes.
*
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/outletComponent
*/
var Outlet = import_react.memo(function OutletImpl() {
	{
		const nonRouteComponent = import_react.useContext(nonRouteComponentContext);
		if (nonRouteComponent) console.warn(`Warning: An <Outlet /> was rendered inside a ${nonRouteComponent}. <Outlet /> should only be rendered inside a route component.`);
	}
	const router = useRouter();
	const routeId = import_react.useContext(matchContext);
	let parentGlobalNotFound;
	let parentNotFoundError;
	let childRouteId;
	if (router.isServer) {
		const matches = router.stores.matches.get();
		const parentIndex = matches.findIndex((match) => match.routeId === routeId);
		const parentMatch = matches[parentIndex];
		parentGlobalNotFound = !!parentMatch._notFound;
		parentNotFoundError = parentMatch.error;
		childRouteId = matches[parentIndex + 1]?.routeId;
	} else {
		const parentMatchStore = router.stores.getMatchStore(routeId);
		[parentGlobalNotFound, parentNotFoundError] = useSelector(parentMatchStore, (match) => [!!match._notFound, match.error], { compare: outletMatchSelectionEqual });
		childRouteId = useSelector(router.stores.ids, (ids) => {
			return ids[ids.indexOf(routeId) + 1];
		});
	}
	if (parentGlobalNotFound) return renderRouteNotFound(router, router.routesById[routeId], parentNotFoundError);
	if (!childRouteId) return null;
	const nextMatch = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Match, { routeId: childRouteId });
	if (routeId === "__root__") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: renderPending(router),
		children: nextMatch
	});
	return nextMatch;
});
// node_modules/@tanstack/react-router/dist/esm/Transitioner.js
function settleOwner(owner, rendered) {
	const settle = owner[1];
	owner.length = 0;
	settle?.(rendered);
}
function Transitioner({ t }) {
	const router = useRouter();
	const acknowledgement = router._rendered ??= [];
	const mounted = import_react.useRef(false);
	router.startTransition = (fn, expected) => new Promise((resolve) => {
		settleOwner(acknowledgement, false);
		acknowledgement.push(expected, resolve);
		t(router);
		import_react.startTransition(fn);
	});
	useLayoutEffect(() => {
		const unsub = router.history.subscribe(router.load);
		if (mounted?.current) return unsub;
		if (mounted) mounted.current = true;
		router.updateLatestLocation();
		const location = router.latestLocation;
		const nextLocation = router.buildLocation({
			to: location.pathname,
			search: true,
			params: true,
			hash: true,
			state: true,
			_includeValidateSearch: true
		});
		if (trimPathRight(location.publicHref) !== trimPathRight(nextLocation.publicHref)) {
			router.commitLocation({
				...nextLocation,
				replace: true,
				ignoreBlocker: true
			});
			return unsub;
		}
		const resolvedLocation = router.stores.resolvedLocation.get();
		if (resolvedLocation?.href === location.href && resolvedLocation.state.__TSR_key === location.state.__TSR_key) acknowledgement.push(router.stores.matches.get(), (rendered) => {
			if (rendered) router.emit({
				type: "onRendered",
				...getLocationChangeInfo(resolvedLocation, resolvedLocation)
			});
		});
		else if (!router._tx) router.load({ sync: true }).catch(console.error);
		return unsub;
	}, [router, router.history]);
	return null;
}
// node_modules/@tanstack/react-router/dist/esm/Matches.js
/**
* Internal component that renders the router's active match tree with
* suspense, error, and not-found boundaries. Rendered by `RouterProvider`.
*/
function Matches() {
	const router = useRouter();
	const rootRoute = router.routesById[rootRouteId];
	const pendingElement = renderPending(router, rootRoute);
	const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [!router.isServer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Transitioner, { t: import_react.useState()[1] }), router.isServer || router.ssr ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchesInner, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
		fallback: pendingElement,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchesInner, {})
	})] });
	return router.options.InnerWrap ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(router.options.InnerWrap, { children: inner }) : inner;
}
function MatchesInner() {
	const router = useRouter();
	const acknowledgement = router._rendered;
	const matches = router.isServer ? router.stores.matches.get() : useSelector(router.stores.matches, (value) => acknowledgement[0] ?? value);
	const match = matches[0];
	const routeId = match?.routeId;
	useLayoutEffect(() => {
		if (acknowledgement[0] === matches) settleOwner(acknowledgement, true);
	}, [acknowledgement, matches]);
	const matchComponent = routeId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Match, { routeId }) : null;
	return router.options.disableGlobalCatchBoundary ? matchComponent : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CatchBoundary, {
		getResetKey: () => match,
		onCatch: (error) => {
			console.warn(`Warning: The following error wasn't caught by any route! At the very least, consider setting an 'errorComponent' in your RootRoute!`);
			console.warn("Warning:", error);
		},
		children: matchComponent
	});
}
/**
* Create a matcher function for testing locations against route definitions.
*
* The returned function accepts standard navigation options (`to`, `params`,
* `search`, etc.) and returns either `false` (no match) or the matched params
* object when the route matches the current or pending location.
*
* Useful for conditional rendering and active UI states because it subscribes
* the component to the router state used for matching. The returned function's
* identity changes when that state changes. For imperative checks in event
* handlers, get the router with `useRouter` and call `router.matchRoute(...)`
* to avoid that subscription.
*
* @returns A `matchRoute(options)` function that returns `false` or params.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useMatchRouteHook
*/
function useMatchRoute() {
	const router = useRouter();
	if (router.isServer) return (opts) => {
		const { pending, caseSensitive, fuzzy, includeSearch, ...rest } = opts;
		return router.matchRoute(rest, {
			pending,
			caseSensitive,
			fuzzy,
			includeSearch
		});
	};
	return import_react.useCallback((opts) => {
		const { pending, caseSensitive, fuzzy, includeSearch, ...rest } = opts;
		return router.matchRoute(rest, {
			pending,
			caseSensitive,
			fuzzy,
			includeSearch
		});
	}, [
		router,
		useSelector(router.stores.location, (location) => location.href),
		useSelector(router.stores.resolvedLocation, (location) => location?.href),
		useSelector(router.stores.status)
	]);
}
/**
* Component that conditionally renders its children based on whether a route
* matches the provided `from`/`to` options. If `children` is a function, it
* receives the matched params object.
*
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/matchRouteComponent
*/
function MatchRoute(props) {
	const params = useMatchRoute()(props);
	if (typeof props.children === "function") return props.children(params);
	return params ? props.children : null;
}
function useMatches(opts) {
	const router = useRouter();
	if (router.isServer) {
		const matches = router.stores.matches.get();
		return opts?.select ? opts.select(matches) : matches;
	}
	return useSelector(router.stores.matches, useStructuralSharing(opts, router));
}
/**
* Read the presented route matches above the current match, or select a
* derived value from them.
*/
function useParentMatches(opts) {
	const contextRouteId = import_react.useContext(matchContext);
	return useMatches({
		select: (matches) => {
			matches = matches.slice(0, matches.findIndex((d) => d.routeId === contextRouteId));
			return opts?.select ? opts.select(matches) : matches;
		},
		structuralSharing: opts?.structuralSharing
	});
}
/**
* Read the presented route matches below the current match, or select a
* derived value from them.
*/
function useChildMatches(opts) {
	const contextRouteId = import_react.useContext(matchContext);
	return useMatches({
		select: (matches) => {
			matches = matches.slice(matches.findIndex((d) => d.routeId === contextRouteId) + 1);
			return opts?.select ? opts.select(matches) : matches;
		},
		structuralSharing: opts?.structuralSharing
	});
}
// node_modules/@tanstack/react-router/dist/esm/routerStores.js
var getStoreFactory = (opts) => {
	if (opts.isServer) return {
		createMutableStore: createNonReactiveMutableStore,
		createReadonlyStore: createNonReactiveReadonlyStore,
		batch: (fn) => fn()
	};
	return {
		createMutableStore: createAtom,
		createReadonlyStore: createAtom,
		batch
	};
};
// node_modules/@tanstack/react-router/dist/esm/router.js
/**
* Creates a new Router instance for React.
*
* Pass the returned router to `RouterProvider` to enable routing.
* Notable options: `routeTree` (your route definitions) and `context`
* (required if the root route was created with `createRootRouteWithContext`).
*
* @param options Router options used to configure the router.
* @returns A Router instance to be provided to `RouterProvider`.
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRouterFunction
*/
var createRouter = (options) => {
	return new Router(options);
};
var Router = class extends RouterCore {
	constructor(options) {
		super(options, getStoreFactory);
	}
};
// node_modules/@tanstack/react-router/dist/esm/RouterProvider.js
/**
* Low-level provider that places the router into React context and optionally
* updates router options from props. Most apps should use `RouterProvider`.
*/
function RouterContextProvider({ router, children, ...rest }) {
	if (hasKeys(rest)) router.update({
		...router.options,
		...rest,
		context: {
			...router.options.context,
			...rest.context
		}
	});
	const provider = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(routerContext.Provider, {
		value: router,
		children
	});
	if (router.options.Wrap) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(router.options.Wrap, { children: provider });
	return provider;
}
/**
* Renders the current match presentation and provides the router to the React
* tree via context.
*
* Accepts mutable router options via props. Configure initialization-only
* options with `createRouter`.
*
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/createRouterFunction
*/
function RouterProvider({ router, ...rest }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RouterContextProvider, {
		router,
		...rest,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Matches, {})
	});
}
// node_modules/@tanstack/react-router/dist/esm/ScrollRestoration.js
function useScrollRestoration() {
	setupScrollRestoration(useRouter(), true);
}
/**
* @deprecated Use the `scrollRestoration` router option instead.
*/
function ScrollRestoration(_props) {
	useScrollRestoration();
	console.warn("The ScrollRestoration component is deprecated. Use createRouter's `scrollRestoration` option instead.");
	return null;
}
function useElementScrollRestoration(options) {
	useScrollRestoration();
	return getElementScrollRestorationEntry(useRouter(), options);
}
// node_modules/@tanstack/react-router/dist/esm/useBlocker.js
function _resolveBlockerOpts(opts, condition) {
	if (opts === void 0) return {
		shouldBlockFn: () => true,
		withResolver: false
	};
	if ("shouldBlockFn" in opts) return opts;
	if (typeof opts === "function") {
		const shouldBlock = Boolean(condition ?? true);
		const _customBlockerFn = async () => {
			if (shouldBlock) return await opts();
			return false;
		};
		return {
			shouldBlockFn: _customBlockerFn,
			enableBeforeUnload: shouldBlock,
			withResolver: false
		};
	}
	const shouldBlock = Boolean(opts.condition ?? true);
	const fn = opts.blockerFn;
	const _customBlockerFn = async () => {
		if (shouldBlock && fn !== void 0) return await fn();
		return shouldBlock;
	};
	return {
		shouldBlockFn: _customBlockerFn,
		enableBeforeUnload: shouldBlock,
		withResolver: fn === void 0
	};
}
function useBlocker(opts, condition) {
	const { shouldBlockFn, enableBeforeUnload = true, disabled = false, withResolver = false } = _resolveBlockerOpts(opts, condition);
	const router = useRouter();
	const { history } = router;
	const [resolver, setResolver] = import_react.useState({
		status: "idle",
		current: void 0,
		next: void 0,
		action: void 0,
		proceed: void 0,
		reset: void 0
	});
	import_react.useEffect(() => {
		const blockerFnComposed = async (blockerFnArgs) => {
			function getLocation(location) {
				const parsedLocation = router.parseLocation(location);
				const [, rawParams, foundRoute] = router.getMatchedRoutes(parsedLocation.pathname);
				if (foundRoute === void 0) return {
					routeId: "__notFound__",
					fullPath: parsedLocation.pathname,
					pathname: parsedLocation.pathname,
					params: rawParams,
					search: router.options.parseSearch(location.search)
				};
				return {
					routeId: foundRoute.id,
					fullPath: foundRoute.fullPath,
					pathname: parsedLocation.pathname,
					params: rawParams,
					search: router.options.parseSearch(location.search)
				};
			}
			const current = getLocation(blockerFnArgs.currentLocation);
			const next = getLocation(blockerFnArgs.nextLocation);
			if (current.routeId === "__notFound__" && next.routeId !== "__notFound__") return false;
			const shouldBlock = await shouldBlockFn({
				action: blockerFnArgs.action,
				current,
				next
			});
			if (!withResolver) return shouldBlock;
			if (!shouldBlock) return false;
			const canNavigateAsync = await new Promise((resolve) => {
				setResolver({
					status: "blocked",
					current,
					next,
					action: blockerFnArgs.action,
					proceed: () => resolve(false),
					reset: () => resolve(true)
				});
			});
			setResolver({
				status: "idle",
				current: void 0,
				next: void 0,
				action: void 0,
				proceed: void 0,
				reset: void 0
			});
			return canNavigateAsync;
		};
		return disabled ? void 0 : history.block({
			blockerFn: blockerFnComposed,
			enableBeforeUnload
		});
	}, [
		shouldBlockFn,
		enableBeforeUnload,
		disabled,
		withResolver,
		history,
		router
	]);
	return resolver;
}
var _resolvePromptBlockerArgs = (props) => {
	if ("shouldBlockFn" in props) return { ...props };
	const shouldBlock = Boolean(props.condition ?? true);
	const fn = props.blockerFn;
	const _customBlockerFn = async () => {
		if (shouldBlock && fn !== void 0) return await fn();
		return shouldBlock;
	};
	return {
		shouldBlockFn: _customBlockerFn,
		enableBeforeUnload: shouldBlock,
		withResolver: fn === void 0
	};
};
function Block(opts) {
	const { children, ...rest } = opts;
	const resolver = useBlocker(_resolvePromptBlockerArgs(rest));
	return children ? typeof children === "function" ? children(resolver) : children : null;
}
// node_modules/@tanstack/react-router/dist/esm/useRouterState.js
/**
* Subscribe to the router's state store with optional selection and
* structural sharing for render optimization.
*
* Options:
* - `select`: Project the full router state to a derived slice
* - `structuralSharing`: Replace-equal semantics for stable references
* - `router`: Read state from a specific router instance instead of context
*
* @returns The selected router state (or the full state by default).
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useRouterStateHook
*/
function useRouterState(opts) {
	const contextRouter = useRouter({ warn: opts?.router === void 0 });
	const router = opts?.router || contextRouter;
	if (router.isServer) {
		const state = router.stores.__store.get();
		return opts?.select ? opts.select(state) : state;
	}
	return useSelector(router.stores.__store, useStructuralSharing(opts, router));
}
// node_modules/@tanstack/react-router/dist/esm/useLocation.js
/**
* Read the current location from the router state with optional selection.
* Useful for subscribing to just the pieces of location you care about.
*
* Options:
* - `select`: Project the `location` object to a derived value
* - `structuralSharing`: Enable structural sharing for stable references
*
* @returns The current location (or selected value).
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useLocationHook
*/
function useLocation(opts) {
	const router = useRouter();
	if (router.isServer) {
		const location = router.stores.location.get();
		return opts?.select ? opts.select(location) : location;
	}
	return useSelector(router.stores.location, useStructuralSharing(opts, router));
}
// node_modules/@tanstack/react-router/dist/esm/useCanGoBack.js
function useCanGoBack() {
	const router = useRouter();
	if (router.isServer) return router.stores.location.get().state.__TSR_index !== 0;
	return useSelector(router.stores.location, (location) => location.state.__TSR_index !== 0);
}
// node_modules/@tanstack/react-router/dist/esm/Asset.js
var INLINE_CSS_HYDRATION_ATTR = "data-tsr-inline-css";
var noopScriptHandler = () => {};
function setScriptAttrs(script, attrs) {
	if (!attrs) return;
	for (const [key, value] of Object.entries(attrs)) if (key !== "suppressHydrationWarning" && value !== void 0 && value !== false) script.setAttribute(key, typeof value === "boolean" ? "" : String(value));
}
function Asset(asset) {
	const { attrs, children, nonce, preventScriptHoist } = asset;
	const innerHTML = import_react.useMemo(() => children === void 0 ? void 0 : { __html: children }, [children]);
	switch (asset.tag) {
		case "title": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("title", {
			...attrs,
			suppressHydrationWarning: true,
			children
		});
		case "meta": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meta", {
			...attrs,
			suppressHydrationWarning: true
		});
		case "link": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("link", {
			...attrs,
			precedence: attrs?.precedence ?? (attrs?.rel === "stylesheet" ? "default" : void 0),
			nonce,
			suppressHydrationWarning: true
		});
		case "style":
			if (asset.inlineCss && (process.env.TSS_INLINE_CSS_ENABLED === "true" || process.env.TSS_INLINE_CSS_ENABLED === void 0 && void 0)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InlineCssStyle, {
				attrs,
				nonce,
				children
			});
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", {
				...attrs,
				dangerouslySetInnerHTML: innerHTML,
				nonce
			});
		case "script": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Script, {
			attrs,
			preventScriptHoist,
			children
		});
		default: return null;
	}
}
function InlineCssStyle({ attrs, children, nonce }) {
	const isInlineCssPlaceholder = children === void 0;
	const [hydratedInlineCss] = import_react.useState(() => {
		if (!isInlineCssPlaceholder || typeof document === "undefined") return;
		return document.querySelector(`style[${INLINE_CSS_HYDRATION_ATTR}]`)?.textContent ?? void 0;
	});
	const html = isInlineCssPlaceholder ? hydratedInlineCss ?? "" : children ?? "";
	const innerHTML = import_react.useMemo(() => ({ __html: html }), [html]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", {
		...attrs,
		[INLINE_CSS_HYDRATION_ATTR]: "",
		dangerouslySetInnerHTML: innerHTML,
		nonce,
		suppressHydrationWarning: true
	});
}
function Script({ attrs, children, preventScriptHoist }) {
	const router = useRouter();
	const hydrated = useHydrated();
	const innerHTML = import_react.useMemo(() => children === void 0 ? void 0 : { __html: children }, [children]);
	const dataScript = typeof attrs?.type === "string" && attrs.type !== "" && attrs.type !== "text/javascript" && attrs.type !== "module";
	if (attrs?.src && typeof children === "string" && children.trim().length) console.warn("[TanStack Router] <Script> received both `src` and `children`. The `children` content will be ignored. Remove `children` or remove `src`.");
	import_react.useEffect(() => {
		if (dataScript) return;
		if (attrs?.src) {
			const link = document.createElement("a");
			link.href = attrs.src;
			const normSrc = link.href;
			for (const el of document.scripts) if (el.src === normSrc) return;
			const script = document.createElement("script");
			setScriptAttrs(script, attrs);
			document.head.appendChild(script);
			return () => script.remove();
		}
		if (typeof children === "string") {
			const typeAttr = typeof attrs?.type === "string" ? attrs.type : "text/javascript";
			const nonceAttr = typeof attrs?.nonce === "string" ? attrs.nonce : void 0;
			for (const el of document.scripts) {
				if (el.hasAttribute("src")) continue;
				const sType = el.getAttribute("type") ?? "text/javascript";
				const sNonce = el.getAttribute("nonce") ?? void 0;
				if (el.textContent === children && sType === typeAttr && sNonce === nonceAttr) return;
			}
			const script = document.createElement("script");
			script.textContent = children;
			setScriptAttrs(script, attrs);
			document.head.appendChild(script);
			return () => script.remove();
		}
	}, [
		attrs,
		children,
		dataScript
	]);
	if (router.isServer) {
		if (attrs?.src) {
			if (!preventScriptHoist) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
				...attrs,
				suppressHydrationWarning: true
			});
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
				...attrs,
				onLoad: noopScriptHandler,
				suppressHydrationWarning: true
			});
		}
		if (typeof children === "string") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			...attrs,
			dangerouslySetInnerHTML: innerHTML,
			suppressHydrationWarning: true
		});
		return null;
	}
	if (dataScript && typeof children === "string") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
		...attrs,
		suppressHydrationWarning: true,
		dangerouslySetInnerHTML: innerHTML
	});
	if (!hydrated) {
		if (attrs?.src) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			...attrs,
			suppressHydrationWarning: true
		});
		if (typeof children === "string") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", {
			...attrs,
			dangerouslySetInnerHTML: innerHTML,
			suppressHydrationWarning: true
		});
	}
	return null;
}
// node_modules/@tanstack/react-router/dist/esm/headContentUtils.js
function buildTagsFromMatches(router, nonce, matches, assetCrossOrigin) {
	matches = _getAssetMatches(matches);
	const routeMeta = matches.map((match) => match.meta).filter((meta) => meta !== void 0);
	const resultMeta = [];
	const metaByAttribute = {};
	let title;
	for (let i = routeMeta.length - 1; i >= 0; i--) {
		const metas = routeMeta[i];
		for (let j = metas.length - 1; j >= 0; j--) {
			const m = metas[j];
			if (!m) continue;
			if (m.title) {
				if (!title) title = {
					tag: "title",
					children: m.title
				};
			} else if ("script:ld+json" in m) try {
				const json = JSON.stringify(m["script:ld+json"]);
				resultMeta.push({
					tag: "script",
					attrs: { type: "application/ld+json" },
					children: escapeHtml(json)
				});
			} catch {}
			else {
				const attribute = m.name ?? m.property;
				if (attribute) {
					if (metaByAttribute[attribute]) continue;
					else metaByAttribute[attribute] = true;
				}
				resultMeta.push({
					tag: "meta",
					attrs: {
						...m,
						nonce
					}
				});
			}
		}
	}
	if (title) resultMeta.push(title);
	if (nonce) resultMeta.push({
		tag: "meta",
		attrs: {
			property: "csp-nonce",
			content: nonce
		}
	});
	resultMeta.reverse();
	const constructedLinks = matches.flatMap((match) => match.links ?? []).filter((link) => link !== void 0).map((link) => ({
		tag: "link",
		attrs: {
			...link,
			nonce
		}
	}));
	const manifest = router.ssr?.manifest;
	const manifestCssTags = [];
	if (manifest) {
		matches.forEach((match) => {
			(manifest.routes[match.routeId]?.css)?.forEach((link) => {
				const resolvedLink = resolveManifestCssLink(link);
				manifestCssTags.push({
					tag: "link",
					attrs: {
						rel: "stylesheet",
						...resolvedLink,
						crossOrigin: getAssetCrossOrigin(assetCrossOrigin, "stylesheet") ?? resolvedLink.crossOrigin,
						suppressHydrationWarning: true,
						nonce
					}
				});
			});
		});
		if (manifest.inlineStyle) manifestCssTags.push({
			tag: "style",
			attrs: {
				...manifest.inlineStyle.attrs,
				nonce
			},
			children: manifest.inlineStyle.children,
			inlineCss: true
		});
	}
	const preloadLinks = [];
	if (manifest) matches.forEach((match) => {
		manifest.routes[match.routeId]?.preloads?.forEach((preload) => {
			preloadLinks.push({
				tag: "link",
				attrs: {
					...getScriptPreloadAttrs(manifest, preload, assetCrossOrigin),
					nonce
				}
			});
		});
	});
	const styles = matches.flatMap((match) => match.styles ?? []).filter((style) => style !== void 0).map(({ children, ...attrs }) => ({
		tag: "style",
		attrs: {
			...attrs,
			nonce
		},
		children
	}));
	const headScripts = matches.flatMap((match) => match.headScripts ?? []).filter((script) => script !== void 0).map(({ children, ...script }) => ({
		tag: "script",
		attrs: {
			...script,
			nonce
		},
		children
	}));
	const tags = [];
	appendUniqueUserTags(tags, resultMeta);
	tags.push(...preloadLinks);
	appendUniqueUserTags(tags, constructedLinks);
	tags.push(...manifestCssTags);
	appendUniqueUserTags(tags, styles);
	appendUniqueUserTags(tags, headScripts);
	return tags;
}
/**
* Build the head/link/meta/script tags from the renderable presented prefix.
* Used internally by `HeadContent`.
*/
var useTags = (assetCrossOrigin) => {
	const router = useRouter();
	const nonce = router.options.ssr?.nonce;
	if (router.isServer) return buildTagsFromMatches(router, nonce, router.stores.matches.get(), assetCrossOrigin);
	const selectTags = import_react.useCallback((matches) => buildTagsFromMatches(router, nonce, matches, assetCrossOrigin), [
		assetCrossOrigin,
		nonce,
		router
	]);
	return useSelector(router.stores.matches, selectTags, { compare: deepEqual });
};
// node_modules/@tanstack/react-router/dist/esm/Scripts.js
var routeScriptAttrs = { suppressHydrationWarning: true };
/**
* Render body script tags collected from route matches and SSR manifests.
* During streaming SSR, `<Scripts>` marks where late hydration scripts may
* begin to be inserted.
*/
var Scripts = () => {
	const router = useRouter();
	const nonce = router.options.ssr?.nonce;
	const getParts = (matches) => {
		const parts = getSsrBodyScriptParts(matches, router.ssr?.manifest, nonce, routeScriptAttrs);
		for (const script of parts[1]) if (typeof script.attrs?.src === "string") {
			const scriptWithHoist = script;
			scriptWithHoist.preventScriptHoist = true;
		}
		return parts;
	};
	const getScripts = (matches) => {
		return composeSsrBodyScripts(getParts(matches));
	};
	if (router.isServer) return renderScripts(composeSsrBodyScripts(getParts(router.stores.matches.get()), router.serverSsr?.takeInitialHydrationScriptTags()));
	return renderScripts(useSelector(router.stores.matches, getScripts, { compare: deepEqual }));
};
function renderScripts(scripts) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: scripts.map((asset, i) => /* @__PURE__ */ (0, import_react.createElement)(Asset, {
		...asset,
		key: `tsr-scripts-${asset.tag}-${i}`
	})) });
}
// node_modules/@tanstack/react-router/dist/esm/HeadContent.dev.js
/**
* Render route-managed head tags (title, meta, links, styles, head scripts).
* Place inside the document head of your app shell.
*
* Development version: filters out dev styles link after hydration and
* includes a fallback cleanup effect for hydration mismatch cases.
*
* @link https://tanstack.com/router/latest/docs/framework/react/guide/document-head-management
*/
function HeadContent(props) {
	const tags = useTags(props.assetCrossOrigin);
	const nonce = useRouter().options.ssr?.nonce;
	const hydrated = useHydrated();
	import_react.useEffect(() => {
		if (hydrated) document.querySelectorAll(`link[${DEV_STYLES_ATTR}]`).forEach((el) => el.remove());
	}, [hydrated]);
	const filteredTags = hydrated ? tags.filter((tag) => tag.tag !== "link" || tag.attrs?.["data-tanstack-router-dev-styles"] !== true) : tags;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: filteredTags.map((tag) => /* @__PURE__ */ (0, import_react.createElement)(Asset, {
		...tag,
		key: `tsr-meta-${JSON.stringify(tag)}`,
		nonce
	})) });
}
export { Asset, Await, Block, CatchBoundary, CatchNotFound, ClientOnly, DEFAULT_PROTOCOL_ALLOWLIST, DefaultGlobalNotFound, ErrorComponent, FileRoute, FileRouteLoader, HeadContent, LazyRoute, Link, Match, MatchRoute, Matches, Navigate, NotFoundRoute, Outlet, RootRoute, Route, RouteApi, Router, RouterContextProvider, RouterProvider, ScriptOnce, Scripts, ScrollRestoration, SearchParamError, cleanPath, composeRewrites, createBrowserHistory, createControlledPromise, createFileRoute, createHashHistory, createHistory, createLazyFileRoute, createLazyRoute, createLink, createMemoryHistory, createRootRoute, createRootRouteWithContext, createRoute, createRouteMask, createRouter, createRouterConfig, createSerializationAdapter, deepEqual, defaultParseSearch, defaultStringifySearch, defer, functionalUpdate, getRouteApi, interpolatePath, isMatch, isNotFound, isRedirect, joinPaths, lazyFn, lazyRouteComponent, linkOptions, notFound, parseSearchWith, reactUse, redirect, replaceEqualDeep, resolvePath, retainSearchParams, rootRouteId, rootRouteWithContext, stringifySearchWith, stripSearchParams, trimPath, trimPathLeft, trimPathRight, useAwaited, useBlocker, useCanGoBack, useChildMatches, useElementScrollRestoration, useHydrated, useLayoutEffect, useLinkProps, useLoaderData, useLoaderDeps, useLocation, useMatch, useMatchRoute, useMatches, useNavigate, useParams, useParentMatches, useRouteContext, useRouter, useRouterState, useSearch, useTags };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHRhbnN0YWNrX3JlYWN0LXJvdXRlci5qcyIsIm5hbWVzIjpbIm5vcm1hbGl6ZSIsIlNVQ0NFU1MiLCJFUlJPUiIsIk5PVF9GT1VORCIsIlJFRElSRUNURUQiLCJ3YWl0Rm9yIiwiZ2V0Um91dGUiLCJub3JtYWxpemUiLCJub3JtYWxpemVFcnJvciIsIm1hdGVyaWFsaXplUmVkaXJlY3QiLCJjb250ZXh0dWFsaXplIiwiZ2V0TG9hZGVyQ29udGV4dCIsImNyZWF0ZUxvYWRlclRhc2siLCJnZXROb3RGb3VuZEJvdW5kYXJ5IiwicHJvamVjdExhbmUiLCJcInVzZVwiIiwidXNlQ2FsbGJhY2siLCJ1c2VTeW5jRXh0ZXJuYWxTdG9yZVdpdGhTZWxlY3RvciIsIlNjcm9sbFJlc3RvcmF0aW9uIiwianN4IiwiU2Nyb2xsUmVzdG9yYXRpb24iLCJGcmFnbWVudCIsIkZyYWdtZW50IiwiRnJhZ21lbnQiXSwic291cmNlcyI6WyIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vbm90LWZvdW5kLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL3Jvb3QuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vcmVkaXJlY3QuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vdXRpbHMuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vcGF0aC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9zaWV2ZS1jYWNoZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9uZXctcHJvY2Vzcy1yb3V0ZS10cmVlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL3Njcm9sbC1yZXN0b3JhdGlvbi5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9xc3MuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vc2VhcmNoUGFyYW1zLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL3Jld3JpdGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vc3RvcmVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL2hpc3RvcnkvZGlzdC9lc20vaW5kZXguanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vcm91dGVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL2xvYWQtY2xpZW50LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL2F3YWl0LXNpZ25hbC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9sb2FkLXNlcnZlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vdXRpbHMuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vZGVmZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vbGluay5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9tYW5pZmVzdC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9NYXRjaGVzLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL3Nzci9ib2R5U2NyaXB0cy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9yb3V0ZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9jb25maWcuanMiLCIuLi8uLi9AdGFuc3RhY2svcm91dGVyLWNvcmUvZGlzdC9lc20vc2VhcmNoTWlkZGxld2FyZS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yb3V0ZXItY29yZS9kaXN0L2VzbS9zc3Ivc2VyaWFsaXplci90cmFuc2Zvcm1lci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vYXdhaXRlZC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vbm9uUm91dGVDb21wb25lbnRDb250ZXh0LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9DYXRjaEJvdW5kYXJ5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9DbGllbnRPbmx5LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9yb3V0ZXJDb250ZXh0LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS91c2VSb3V0ZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL21hdGNoQ29udGV4dC5qcyIsIi4uLy4uL0B0YW5zdGFjay9zdG9yZS9kaXN0L2FsaWVuLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3N0b3JlL2Rpc3QvYXRvbS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1zdG9yZS9kaXN0L3VzZVNlbGVjdG9yLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS91c2VNYXRjaC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vdXNlTG9hZGVyRGF0YS5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vdXNlTG9hZGVyRGVwcy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vdXNlUGFyYW1zLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS91c2VTZWFyY2guanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3VzZU5hdmlnYXRlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS91c2VSb3V0ZUNvbnRleHQuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL2xpbmsuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3JvdXRlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9maWxlUm91dGUuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL2xhenlSb3V0ZUNvbXBvbmVudC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vbm90LWZvdW5kLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9TY3JpcHRPbmNlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9yZW5kZXJSb3V0ZU5vdEZvdW5kLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JvdXRlci1jb3JlL2Rpc3QvZXNtL3Njcm9sbC1yZXN0b3JhdGlvbi1zY3JpcHQvY2xpZW50LmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9zY3JvbGwtcmVzdG9yYXRpb24uanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL01hdGNoLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9UcmFuc2l0aW9uZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL01hdGNoZXMuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3JvdXRlclN0b3Jlcy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vcm91dGVyLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9Sb3V0ZXJQcm92aWRlci5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vU2Nyb2xsUmVzdG9yYXRpb24uanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3VzZUJsb2NrZXIuanMiLCIuLi8uLi9AdGFuc3RhY2svcmVhY3Qtcm91dGVyL2Rpc3QvZXNtL3VzZVJvdXRlclN0YXRlLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS91c2VMb2NhdGlvbi5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vdXNlQ2FuR29CYWNrLmpzIiwiLi4vLi4vQHRhbnN0YWNrL3JlYWN0LXJvdXRlci9kaXN0L2VzbS9Bc3NldC5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vaGVhZENvbnRlbnRVdGlscy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vU2NyaXB0cy5qcyIsIi4uLy4uL0B0YW5zdGFjay9yZWFjdC1yb3V0ZXIvZGlzdC9lc20vSGVhZENvbnRlbnQuZGV2LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vI3JlZ2lvbiBzcmMvbm90LWZvdW5kLnRzXG4vKipcbiogQ3JlYXRlIGEgbm90LWZvdW5kIGVycm9yIG9iamVjdCByZWNvZ25pemVkIGJ5IFRhblN0YWNrIFJvdXRlci5cbipcbiogVGhyb3cgdGhpcyBmcm9tIGxvYWRlcnMvYWN0aW9ucyB0byB0cmlnZ2VyIHRoZSBuZWFyZXN0IGBub3RGb3VuZENvbXBvbmVudGAuXG4qIFVzZSBgcm91dGVJZGAgdG8gdGFyZ2V0IGEgc3BlY2lmaWMgcm91dGUncyBub3QtZm91bmQgYm91bmRhcnkuIElmIGB0aHJvd2BcbiogaXMgdHJ1ZSwgdGhlIGVycm9yIGlzIHRocm93biBpbnN0ZWFkIG9mIHJldHVybmVkLlxuKlxuKiBAcGFyYW0gb3B0aW9ucyBPcHRpb25hbCBzZXR0aW5ncyBpbmNsdWRpbmcgYHJvdXRlSWRgLCBgaGVhZGVyc2AsIGFuZCBgdGhyb3dgLlxuKiBAcmV0dXJucyBBIG5vdC1mb3VuZCBlcnJvciBvYmplY3QgdGhhdCBjYW4gYmUgdGhyb3duIG9yIHJldHVybmVkLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3Mvcm91dGVyL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL25vdEZvdW5kRnVuY3Rpb25cbiovXG5mdW5jdGlvbiBub3RGb3VuZChvcHRpb25zID0ge30pIHtcblx0b3B0aW9ucy5pc05vdEZvdW5kID0gdHJ1ZTtcblx0aWYgKG9wdGlvbnMudGhyb3cpIHRocm93IG9wdGlvbnM7XG5cdHJldHVybiBvcHRpb25zO1xufVxuLyoqIERldGVybWluZSBpZiBhIHZhbHVlIGlzIGEgVGFuU3RhY2sgUm91dGVyIG5vdC1mb3VuZCBlcnJvci4gKi9cbmZ1bmN0aW9uIGlzTm90Rm91bmQob2JqKSB7XG5cdHJldHVybiBvYmo/LmlzTm90Rm91bmQgPT09IHRydWU7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGlzTm90Rm91bmQsIG5vdEZvdW5kIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vdC1mb3VuZC5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL3Jvb3QudHNcbi8qKiBTdGFibGUgaWRlbnRpZmllciB1c2VkIGZvciB0aGUgcm9vdCByb3V0ZSBpbiBhIHJvdXRlIHRyZWUuICovXG5jb25zdCByb290Um91dGVJZCA9IFwiX19yb290X19cIjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgcm9vdFJvdXRlSWQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm9vdC5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL3JlZGlyZWN0LnRzXG4vKipcbiogQ3JlYXRlIGEgcmVkaXJlY3QgUmVzcG9uc2UgdW5kZXJzdG9vZCBieSBUYW5TdGFjayBSb3V0ZXIuXG4qXG4qIFVzZSBmcm9tIHJvdXRlIGBsb2FkZXJgL2BiZWZvcmVMb2FkYCBvciBzZXJ2ZXIgZnVuY3Rpb25zIHRvIHRyaWdnZXIgYVxuKiBuYXZpZ2F0aW9uLiBJZiBgdGhyb3c6IHRydWVgIGlzIHNldCwgdGhlIHJlZGlyZWN0IGlzIHRocm93biBpbnN0ZWFkIG9mXG4qIHJldHVybmVkLiBFeHRlcm5hbCBgaHJlZmAgdmFsdWVzIGFyZSBjbGFzc2lmaWVkIGFzIGZ1bGwtZG9jdW1lbnRcbiogbmF2aWdhdGlvbnMgd2hlbiB0aGUgcm91dGVyIHJlc29sdmVzIHRoZSByZWRpcmVjdC5cbipcbiogQHBhcmFtIG9wdHMgT3B0aW9ucyBmb3IgdGhlIHJlZGlyZWN0LiBDb21tb24gZmllbGRzOlxuKiAtIGBocmVmYDogYWJzb2x1dGUgVVJMIGZvciBleHRlcm5hbCByZWRpcmVjdHMuXG4qIC0gYHN0YXR1c0NvZGVgOiBIVFRQIHN0YXR1cyBjb2RlIHRvIHVzZSAoZGVmYXVsdHMgdG8gMzA3KS5cbiogLSBgaGVhZGVyc2A6IGFkZGl0aW9uYWwgaGVhZGVycyB0byBpbmNsdWRlIG9uIHRoZSBSZXNwb25zZS5cbiogLSBTdGFuZGFyZCBuYXZpZ2F0aW9uIG9wdGlvbnMgbGlrZSBgdG9gLCBgcGFyYW1zYCwgYHNlYXJjaGAsIGByZXBsYWNlYCxcbiogICBhbmQgYHJlbG9hZERvY3VtZW50YCBmb3IgaW50ZXJuYWwgcmVkaXJlY3RzLlxuKiBAcmV0dXJucyBBIFJlc3BvbnNlIGF1Z21lbnRlZCB3aXRoIHJvdXRlciBuYXZpZ2F0aW9uIG9wdGlvbnMuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9yZWRpcmVjdEZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gcmVkaXJlY3Qob3B0cykge1xuXHRvcHRzLnN0YXR1c0NvZGUgPSBvcHRzLnN0YXR1c0NvZGUgfHwgb3B0cy5jb2RlIHx8IDMwNztcblx0Y29uc3QgaGVhZGVycyA9IG5ldyBIZWFkZXJzKG9wdHMuaGVhZGVycyk7XG5cdGlmIChvcHRzLmhyZWYgJiYgaGVhZGVycy5nZXQoXCJMb2NhdGlvblwiKSA9PT0gbnVsbCkgaGVhZGVycy5zZXQoXCJMb2NhdGlvblwiLCBvcHRzLmhyZWYpO1xuXHRjb25zdCByZXNwb25zZSA9IG5ldyBSZXNwb25zZShudWxsLCB7XG5cdFx0c3RhdHVzOiBvcHRzLnN0YXR1c0NvZGUsXG5cdFx0aGVhZGVyc1xuXHR9KTtcblx0cmVzcG9uc2Uub3B0aW9ucyA9IG9wdHM7XG5cdGlmIChvcHRzLnRocm93KSB0aHJvdyByZXNwb25zZTtcblx0cmV0dXJuIHJlc3BvbnNlO1xufVxuLyoqIENoZWNrIHdoZXRoZXIgYSB2YWx1ZSBpcyBhIFRhblN0YWNrIFJvdXRlciByZWRpcmVjdCBSZXNwb25zZS4gKi9cbmZ1bmN0aW9uIGlzUmVkaXJlY3Qob2JqKSB7XG5cdHJldHVybiBvYmogaW5zdGFuY2VvZiBSZXNwb25zZSAmJiAhIW9iai5vcHRpb25zO1xufVxuLyoqIFRydWUgaWYgdmFsdWUgaXMgYSByZWRpcmVjdCB3aXRoIGEgcmVzb2x2ZWQgYGhyZWZgIGxvY2F0aW9uLiAqL1xuZnVuY3Rpb24gaXNSZXNvbHZlZFJlZGlyZWN0KG9iaikge1xuXHRyZXR1cm4gaXNSZWRpcmVjdChvYmopICYmICEhb2JqLm9wdGlvbnMuaHJlZjtcbn1cbi8qKiBQYXJzZSBhIHNlcmlhbGl6ZWQgcmVkaXJlY3Qgb2JqZWN0IGJhY2sgaW50byBhIHJlZGlyZWN0IFJlc3BvbnNlLiAqL1xuZnVuY3Rpb24gcGFyc2VSZWRpcmVjdChvYmopIHtcblx0aWYgKG9iaiAhPT0gbnVsbCAmJiB0eXBlb2Ygb2JqID09PSBcIm9iamVjdFwiICYmIG9iai5pc1NlcmlhbGl6ZWRSZWRpcmVjdCkgcmV0dXJuIHJlZGlyZWN0KG9iaik7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGlzUmVkaXJlY3QsIGlzUmVzb2x2ZWRSZWRpcmVjdCwgcGFyc2VSZWRpcmVjdCwgcmVkaXJlY3QgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVkaXJlY3QuanMubWFwIiwiaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG4vLyNyZWdpb24gc3JjL3V0aWxzLnRzXG4vKipcbiogUmV0dXJuIHRoZSBsYXN0IGVsZW1lbnQgb2YgYW4gYXJyYXkuXG4qIEludGVuZGVkIGZvciBub24tZW1wdHkgYXJyYXlzIHVzZWQgd2l0aGluIHJvdXRlciBpbnRlcm5hbHMuXG4qL1xuZnVuY3Rpb24gbGFzdChhcnIpIHtcblx0cmV0dXJuIGFyclthcnIubGVuZ3RoIC0gMV07XG59XG4vKipcbiogQXBwbHkgYSB2YWx1ZS1vci11cGRhdGVyIHRvIGEgcHJldmlvdXMgdmFsdWUuXG4qIEFjY2VwdHMgZWl0aGVyIGEgbGl0ZXJhbCB2YWx1ZSBvciBhIGZ1bmN0aW9uIG9mIHRoZSBwcmV2aW91cyB2YWx1ZS5cbiovXG5mdW5jdGlvbiBmdW5jdGlvbmFsVXBkYXRlKHVwZGF0ZXIsIHByZXZpb3VzKSB7XG5cdGlmICh0eXBlb2YgdXBkYXRlciA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gdXBkYXRlcihwcmV2aW91cyk7XG5cdHJldHVybiB1cGRhdGVyO1xufVxuY29uc3QgaGFzT3duID0gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eTtcbmZ1bmN0aW9uIGhhc0tleXMob2JqKSB7XG5cdGZvciAoY29uc3Qga2V5IGluIG9iaikgaWYgKGhhc093bi5jYWxsKG9iaiwga2V5KSkgcmV0dXJuIHRydWU7XG5cdHJldHVybiBmYWxzZTtcbn1cbmNvbnN0IGNyZWF0ZU51bGwgPSAoKSA9PiBPYmplY3QuY3JlYXRlKG51bGwpO1xuY29uc3QgbnVsbFJlcGxhY2VFcXVhbERlZXAgPSAocHJldiwgbmV4dCkgPT4gcmVwbGFjZUVxdWFsRGVlcChwcmV2LCBuZXh0LCB0cnVlKTtcbmZ1bmN0aW9uIHJlcGxhY2VFcXVhbERlZXAocHJldiwgbmV4dCwgX251bGxQcm90bywgX2RlcHRoID0gMCkge1xuXHRpZiAoaXNTZXJ2ZXIpIHJldHVybiBuZXh0O1xuXHRpZiAocHJldiA9PT0gbmV4dCkgcmV0dXJuIHByZXY7XG5cdGlmIChfZGVwdGgrKyA+IDUwMCkgcmV0dXJuIG5leHQ7XG5cdGNvbnN0IGFycmF5ID0gQXJyYXkuaXNBcnJheShwcmV2KSAmJiBBcnJheS5pc0FycmF5KG5leHQpO1xuXHRpZiAoIWFycmF5ICYmICEoaXNQbGFpbk9iamVjdChwcmV2KSAmJiBpc1BsYWluT2JqZWN0KG5leHQpKSkgcmV0dXJuIG5leHQ7XG5cdGNvbnN0IHByZXZLZXlzID0gT2JqZWN0LmtleXMocHJldik7XG5cdGNvbnN0IHByZXZpb3VzQ291bnQgPSBwcmV2S2V5cy5sZW5ndGg7XG5cdGNvbnN0IG5leHRLZXlzID0gT2JqZWN0LmtleXMobmV4dCk7XG5cdGNvbnN0IGxlbmd0aCA9IG5leHRLZXlzLmxlbmd0aDtcblx0aWYgKGFycmF5ID8gcHJldmlvdXNDb3VudCAhPT0gcHJldi5sZW5ndGggfHwgbGVuZ3RoICE9PSBuZXh0Lmxlbmd0aCB8fCBwcmV2aW91c0NvdW50ICYmIGxhc3QocHJldktleXMpICE9PSBgJHtwcmV2aW91c0NvdW50IC0gMX1gIHx8IGxlbmd0aCAmJiBsYXN0KG5leHRLZXlzKSAhPT0gYCR7bGVuZ3RoIC0gMX1gIDogcHJldmlvdXNDb3VudCAhPT0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMocHJldikubGVuZ3RoIHx8IGxlbmd0aCAhPT0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXMobmV4dCkubGVuZ3RoIHx8IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMobmV4dCkubGVuZ3RoKSByZXR1cm4gbmV4dDtcblx0bGV0IGkgPSAwO1xuXHRsZXQgY2hpbGQ7XG5cdGxldCBwcmV2aW91cztcblx0bGV0IGtleTtcblx0aWYgKGFycmF5KSB7XG5cdFx0Zm9yICg7IGkgPCBsZW5ndGg7IGkrKykge1xuXHRcdFx0a2V5ID0gaTtcblx0XHRcdHByZXZpb3VzID0gcHJldltrZXldO1xuXHRcdFx0Y2hpbGQgPSBuZXh0W2tleV07XG5cdFx0XHRjaGlsZCA9IHByZXZpb3VzID09PSBjaGlsZCA/IHByZXZpb3VzIDogdHlwZW9mIHByZXZpb3VzID09PSBcIm9iamVjdFwiID8gcmVwbGFjZUVxdWFsRGVlcChwcmV2aW91cywgY2hpbGQsIF9udWxsUHJvdG8sIF9kZXB0aCkgOiBjaGlsZDtcblx0XHRcdGlmIChjaGlsZCAhPT0gcHJldmlvdXMpIGJyZWFrO1xuXHRcdH1cblx0XHRpZiAoaSA9PT0gbGVuZ3RoICYmIHByZXZpb3VzQ291bnQgPT09IGxlbmd0aCkgcmV0dXJuIHByZXY7XG5cdH0gZWxzZSB7XG5cdFx0bGV0IGVxdWFsID0gcHJldmlvdXNDb3VudCA9PT0gbGVuZ3RoO1xuXHRcdGxldCB1bmNoYW5nZWQgPSB0cnVlO1xuXHRcdGZvciAoOyBpIDwgbGVuZ3RoOyBpKyspIHtcblx0XHRcdGtleSA9IG5leHRLZXlzW2ldO1xuXHRcdFx0cHJldmlvdXMgPSBwcmV2W2tleV07XG5cdFx0XHRjb25zdCBpbmNvbWluZyA9IG5leHRba2V5XTtcblx0XHRcdGNoaWxkID0gcHJldmlvdXMgPT09IGluY29taW5nID8gcHJldmlvdXMgOiB0eXBlb2YgcHJldmlvdXMgPT09IFwib2JqZWN0XCIgPyByZXBsYWNlRXF1YWxEZWVwKHByZXZpb3VzLCBpbmNvbWluZywgX251bGxQcm90bywgX2RlcHRoKSA6IGluY29taW5nO1xuXHRcdFx0ZXF1YWwgJiY9IGNoaWxkID09PSBwcmV2aW91cyAmJiAocHJldktleXNbaV0gPT09IGtleSB8fCBoYXNPd24uY2FsbChwcmV2LCBrZXkpKTtcblx0XHRcdHVuY2hhbmdlZCAmJj0gT2JqZWN0LmlzKGNoaWxkLCBpbmNvbWluZyk7XG5cdFx0XHRwcmV2S2V5c1tpXSA9IGNoaWxkO1xuXHRcdH1cblx0XHRpZiAoZXF1YWwpIHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHByZXYpLmxlbmd0aCA/IG5leHQgOiBwcmV2O1xuXHRcdGlmICh1bmNoYW5nZWQpIHJldHVybiBuZXh0O1xuXHR9XG5cdGNvbnN0IGNvcHkgPSBhcnJheSA/IG5leHRLZXlzLmZpbGwoMCkgOiBfbnVsbFByb3RvID8gY3JlYXRlTnVsbCgpIDoge307XG5cdGZvciAobGV0IGogPSAwOyBqIDwgbGVuZ3RoOyBqKyspIHtcblx0XHRrZXkgPSBhcnJheSA/IGogOiBuZXh0S2V5c1tqXTtcblx0XHRpZiAoYXJyYXkpIHtcblx0XHRcdHByZXZpb3VzID0gcHJldltrZXldO1xuXHRcdFx0aWYgKGogPiBpKSB7XG5cdFx0XHRcdGNoaWxkID0gbmV4dFtrZXldO1xuXHRcdFx0XHRjaGlsZCA9IHByZXZpb3VzID09PSBjaGlsZCA/IHByZXZpb3VzIDogdHlwZW9mIHByZXZpb3VzID09PSBcIm9iamVjdFwiID8gcmVwbGFjZUVxdWFsRGVlcChwcmV2aW91cywgY2hpbGQsIF9udWxsUHJvdG8sIF9kZXB0aCkgOiBjaGlsZDtcblx0XHRcdH1cblx0XHRcdGNvcHlba2V5XSA9IGogPCBpID8gcHJldmlvdXMgOiBjaGlsZDtcblx0XHR9IGVsc2UgY29weVtrZXldID0gcHJldktleXNbal07XG5cdH1cblx0cmV0dXJuIGNvcHk7XG59XG5mdW5jdGlvbiBpc1BsYWluT2JqZWN0KG8pIHtcblx0aWYgKCFvIHx8IHR5cGVvZiBvICE9PSBcIm9iamVjdFwiKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiAoT2JqZWN0LmdldFByb3RvdHlwZU9mKG8pPy5jb25zdHJ1Y3RvciA/PyBPYmplY3QpID09PSBPYmplY3Q7XG59XG4vKipcbiogUGVyZm9ybSBhIGRlZXAgZXF1YWxpdHkgY2hlY2sgb3B0aW1pemVkIGZvciByb3V0ZXIgc3RhdGUgY29tcGFyaXNvbnMuXG4qXG4qIC0gYHBhcnRpYWxgOiBgYmAgbWF5IG9taXQga2V5cyB0aGF0IGBhYCBoYXMgKGFycmF5cyBzdGF5IGxlbmd0aC1leGFjdCkuXG4qIC0gYGV4cGxpY2l0VW5kZWZpbmVkYDoga2V5cyBob2xkaW5nIGB1bmRlZmluZWRgIHRha2UgcGFydCBpbiB0aGUgY29tcGFyaXNvblxuKiAgIGluc3RlYWQgb2YgYmVpbmcgaWdub3JlZC5cbipcbiogSW50ZXJuYWw6IHRoZSBmbGFncyBhcmUgcG9zaXRpb25hbCBzbyBob3QgY2FsbGVycyBwYXNzIG5vIG9wdGlvbnMgb2JqZWN0LlxuKi9cbmZ1bmN0aW9uIGRlZXBFcXVhbChhLCBiLCBwYXJ0aWFsLCBleHBsaWNpdFVuZGVmaW5lZCkge1xuXHRpZiAoYSA9PT0gYikgcmV0dXJuIHRydWU7XG5cdGlmIChBcnJheS5pc0FycmF5KGEpICYmIEFycmF5LmlzQXJyYXkoYikpIHtcblx0XHRpZiAoYS5sZW5ndGggIT09IGIubGVuZ3RoKSByZXR1cm4gZmFsc2U7XG5cdFx0Zm9yIChsZXQgaSA9IDAsIGwgPSBhLmxlbmd0aDsgaSA8IGw7IGkrKykge1xuXHRcdFx0Y29uc3QgYXYgPSBhW2ldO1xuXHRcdFx0Y29uc3QgYnYgPSBiW2ldO1xuXHRcdFx0aWYgKGF2ICE9PSBidiAmJiAhZGVlcEVxdWFsKGF2LCBidiwgcGFydGlhbCwgZXhwbGljaXRVbmRlZmluZWQpKSByZXR1cm4gZmFsc2U7XG5cdFx0fVxuXHRcdHJldHVybiB0cnVlO1xuXHR9XG5cdGlmIChpc1BsYWluT2JqZWN0KGEpICYmIGlzUGxhaW5PYmplY3QoYikpIHtcblx0XHRpZiAocGFydGlhbCkge1xuXHRcdFx0Zm9yIChjb25zdCBrIGluIGIpIGlmIChleHBsaWNpdFVuZGVmaW5lZCB8fCBiW2tdICE9PSB2b2lkIDApIHtcblx0XHRcdFx0aWYgKCFkZWVwRXF1YWwoYVtrXSwgYltrXSwgcGFydGlhbCwgZXhwbGljaXRVbmRlZmluZWQpKSByZXR1cm4gZmFsc2U7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHR9XG5cdFx0bGV0IGFDb3VudCA9IDA7XG5cdFx0aWYgKGV4cGxpY2l0VW5kZWZpbmVkKSBhQ291bnQgPSBPYmplY3Qua2V5cyhhKS5sZW5ndGg7XG5cdFx0ZWxzZSBmb3IgKGNvbnN0IGsgaW4gYSkgaWYgKGFba10gIT09IHZvaWQgMCkgYUNvdW50Kys7XG5cdFx0Zm9yIChjb25zdCBrIGluIGIpIGlmIChleHBsaWNpdFVuZGVmaW5lZCB8fCBiW2tdICE9PSB2b2lkIDApIHtcblx0XHRcdGlmIChhQ291bnQtLSA9PT0gMCB8fCAhZGVlcEVxdWFsKGFba10sIGJba10sIHBhcnRpYWwsIGV4cGxpY2l0VW5kZWZpbmVkKSkgcmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0XHRyZXR1cm4gYUNvdW50ID09PSAwO1xuXHR9XG5cdHJldHVybiBmYWxzZTtcbn1cbi8qKlxuKiBDcmVhdGUgYSBwcm9taXNlIHdpdGggZXhwb3NlZCByZXNvbHZlL3JlamVjdCBhbmQgc3RhdHVzIGZpZWxkcy5cbiogVXNlZnVsIGZvciBjb29yZGluYXRpbmcgYXN5bmMgcm91dGVyIGxpZmVjeWNsZSBvcGVyYXRpb25zLlxuKi9cbmZ1bmN0aW9uIGNyZWF0ZUNvbnRyb2xsZWRQcm9taXNlKG9uUmVzb2x2ZSkge1xuXHRsZXQgcmVzb2x2ZUxvYWRQcm9taXNlO1xuXHRsZXQgcmVqZWN0TG9hZFByb21pc2U7XG5cdGNvbnN0IGNvbnRyb2xsZWRQcm9taXNlID0gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdHJlc29sdmVMb2FkUHJvbWlzZSA9IHJlc29sdmU7XG5cdFx0cmVqZWN0TG9hZFByb21pc2UgPSByZWplY3Q7XG5cdH0pO1xuXHRjb250cm9sbGVkUHJvbWlzZS5zdGF0dXMgPSBcInBlbmRpbmdcIjtcblx0Y29udHJvbGxlZFByb21pc2UucmVzb2x2ZSA9ICh2YWx1ZSkgPT4ge1xuXHRcdGNvbnRyb2xsZWRQcm9taXNlLnN0YXR1cyA9IFwicmVzb2x2ZWRcIjtcblx0XHRjb250cm9sbGVkUHJvbWlzZS52YWx1ZSA9IHZhbHVlO1xuXHRcdHJlc29sdmVMb2FkUHJvbWlzZSh2YWx1ZSk7XG5cdFx0b25SZXNvbHZlPy4odmFsdWUpO1xuXHR9O1xuXHRjb250cm9sbGVkUHJvbWlzZS5yZWplY3QgPSAoZSkgPT4ge1xuXHRcdGNvbnRyb2xsZWRQcm9taXNlLnN0YXR1cyA9IFwicmVqZWN0ZWRcIjtcblx0XHRyZWplY3RMb2FkUHJvbWlzZShlKTtcblx0fTtcblx0cmV0dXJuIGNvbnRyb2xsZWRQcm9taXNlO1xufVxuLyoqXG4qIEhldXJpc3RpY2FsbHkgZGV0ZWN0IGR5bmFtaWMgaW1wb3J0IFwibW9kdWxlIG5vdCBmb3VuZFwiIGVycm9yc1xuKiBhY3Jvc3MgbWFqb3IgYnJvd3NlcnMgZm9yIGxhenkgcm91dGUgY29tcG9uZW50IGhhbmRsaW5nLlxuKi9cbmZ1bmN0aW9uIGlzTW9kdWxlTm90Rm91bmRFcnJvcihlcnJvcikge1xuXHRpZiAodHlwZW9mIGVycm9yPy5tZXNzYWdlICE9PSBcInN0cmluZ1wiKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiBlcnJvci5tZXNzYWdlLnN0YXJ0c1dpdGgoXCJGYWlsZWQgdG8gZmV0Y2ggZHluYW1pY2FsbHkgaW1wb3J0ZWQgbW9kdWxlXCIpIHx8IGVycm9yLm1lc3NhZ2Uuc3RhcnRzV2l0aChcImVycm9yIGxvYWRpbmcgZHluYW1pY2FsbHkgaW1wb3J0ZWQgbW9kdWxlXCIpIHx8IGVycm9yLm1lc3NhZ2Uuc3RhcnRzV2l0aChcIkltcG9ydGluZyBhIG1vZHVsZSBzY3JpcHQgZmFpbGVkXCIpO1xufVxuZnVuY3Rpb24gaXNQcm9taXNlKHZhbHVlKSB7XG5cdHJldHVybiBCb29sZWFuKHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgdmFsdWUudGhlbiA9PT0gXCJmdW5jdGlvblwiKTtcbn1cbmZ1bmN0aW9uIGZpbmRMYXN0KGFycmF5LCBwcmVkaWNhdGUpIHtcblx0Zm9yIChsZXQgaSA9IGFycmF5Lmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0Y29uc3QgaXRlbSA9IGFycmF5W2ldO1xuXHRcdGlmIChwcmVkaWNhdGUoaXRlbSkpIHJldHVybiBpdGVtO1xuXHR9XG59XG4vKipcbiogUmUtZW5jb2RlIGNoYXJhY3RlcnMgdGhhdCBhcmUgdW5zYWZlIGluIFVSTCBwYXRocy5cbiogSW5jbHVkZXMgQVNDSUkgY29udHJvbCBjaGFyYWN0ZXJzICgweDAwLTB4MUYsIDB4N0YpIGFuZCBhIHN1YnNldCBvZiB0aGVcbiogV0hBVFdHIFVSTCBcInBhdGggcGVyY2VudC1lbmNvZGUgc2V0XCIgKFwiLCA8LCA+LCBgLCB7LCB9KS5cbipcbiogU3BhY2UgKDB4MjApIGlzIGludGVudGlvbmFsbHkgZXhjbHVkZWQg4oCUIGRlY29kZVVSSSBkZWNvZGVzICUyMCB0byBzcGFjZVxuKiBhbmQgdGhlIHJvdXRlciBzdG9yZXMgZGVjb2RlZCBzcGFjZXMgaW4gbG9jYXRpb24ucGF0aG5hbWUuIFRoZSBleGlzdGluZ1xuKiBlbmNvZGVQYXRoTGlrZVVybCBhbHJlYWR5IGhhbmRsZXMgcmUtZW5jb2Rpbmcgc3BhY2VzIGZvciBvdXRnb2luZyBVUkxzLlxuKlxuKiBUaGVzZSBjaGFyYWN0ZXJzIGFyZSBkZWNvZGVkIGJ5IGRlY29kZVVSSSBidXQgbXVzdCByZW1haW4gcGVyY2VudC1lbmNvZGVkXG4qIGluIHBhdGhzIHRvIG1hdGNoIGhvdyB1cHN0cmVhbSBsYXllcnMgKENETnMsIGVkZ2UgbWlkZGxld2FyZSwgYnJvd3NlcnMpXG4qIGludGVycHJldCB0aGUgVVJMLCBwcmV2ZW50aW5nIGluZmluaXRlIHJlZGlyZWN0IGxvb3BzIGFuZCBwYXRoIG1pc21hdGNoZXMuXG4qL1xuY29uc3QgUEFUSF9VTlNBRkVfUkUgPSAvW1xceDAwLVxceDFmXFx4N2ZcIjw+YHt9XS9nO1xuZnVuY3Rpb24gc2FuaXRpemVQYXRoU2VnbWVudChzZWdtZW50KSB7XG5cdHJldHVybiBzZWdtZW50LnJlcGxhY2UoUEFUSF9VTlNBRkVfUkUsIChjaCkgPT4gXCIlXCIgKyBjaC5jaGFyQ29kZUF0KDApLnRvU3RyaW5nKDE2KS50b1VwcGVyQ2FzZSgpLnBhZFN0YXJ0KDIsIFwiMFwiKSk7XG59XG5mdW5jdGlvbiBkZWNvZGVTZWdtZW50KHNlZ21lbnQpIHtcblx0bGV0IGRlY29kZWQ7XG5cdHRyeSB7XG5cdFx0ZGVjb2RlZCA9IGRlY29kZVVSSShzZWdtZW50KTtcblx0fSBjYXRjaCB7XG5cdFx0ZGVjb2RlZCA9IHNlZ21lbnQucmVwbGFjZUFsbCgvJVswLTlBLUZdezJ9L2dpLCAobWF0Y2gpID0+IHtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHJldHVybiBkZWNvZGVVUkkobWF0Y2gpO1xuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdHJldHVybiBtYXRjaDtcblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXHRyZXR1cm4gc2FuaXRpemVQYXRoU2VnbWVudChkZWNvZGVkKTtcbn1cbi8qKlxuKiBEZWZhdWx0IGxpc3Qgb2YgVVJMIHByb3RvY29scyB0byBhbGxvdyBpbiBsaW5rcywgcmVkaXJlY3RzLCBhbmQgbmF2aWdhdGlvbi5cbiogQW55IGFic29sdXRlIFVSTCBwcm90b2NvbCBub3QgaW4gdGhpcyBsaXN0IGlzIHRyZWF0ZWQgYXMgZGFuZ2Vyb3VzIGJ5IGRlZmF1bHQuXG4qL1xuY29uc3QgREVGQVVMVF9QUk9UT0NPTF9BTExPV0xJU1QgPSBbXG5cdFwiaHR0cDpcIixcblx0XCJodHRwczpcIixcblx0XCJtYWlsdG86XCIsXG5cdFwidGVsOlwiXG5dO1xuLyoqXG4qIEV4dHJhY3QgdGhlIGV4cGxpY2l0IFVSTCBzY2hlbWUsIGluY2x1ZGluZyBpdHMgY29sb24sIHVzaW5nIFdIQVRXR1xuKiBub3JtYWxpemF0aW9uIHJ1bGVzLiBUaGlzIGRvZXMgbm90IHZhbGlkYXRlIHRoZSByZXN0IG9mIHRoZSBVUkwuXG4qXG4qIFJldHVybmluZyBgdW5kZWZpbmVkYCBtZWFucyBcIm5vIGV4cGxpY2l0IHNjaGVtZVwiLCBub3QgXCJzYWZlIFVSTFwiO1xuKiBwcm90b2NvbC1yZWxhdGl2ZSBVUkxzIHN1Y2ggYXMgXCIvL2V2aWwuZXhhbXBsZVwiIHJlcXVpcmUgYSBzZXBhcmF0ZSBjaGVjay5cbiovXG5mdW5jdGlvbiBnZXRVcmxTY2hlbWUodXJsKSB7XG5cdGlmICh1cmxbMF0gPT09IFwiL1wiKSByZXR1cm47XG5cdGlmICghdXJsLmluY2x1ZGVzKFwiOlwiKSkgcmV0dXJuO1xuXHRyZXR1cm4gL15bXFx4MDAtXFx4MjBdKihbYS16XVthLXpcXGQrLlxcdFxcblxcci1dKjopL2kuZXhlYyh1cmwpPy5bMV0/LnJlcGxhY2UoL1tcXHRcXG5cXHJdL2csIFwiXCIpLnRvTG93ZXJDYXNlKCk7XG59XG5jb25zdCBwcm90b2NvbFJlbGF0aXZlUHJlZml4UmVnZXggPSAvXltcXHgwMC1cXHgyMF0qW1xcXFwvXVtcXHRcXG5cXHJdKltcXFxcL10vO1xuLyoqXG4qIENoZWNrIGlmIGEgVVJMIHN0cmluZyB1c2VzIGEgcHJvdG9jb2wgdGhhdCBpcyBub3QgaW4gdGhlIGFsbG93bGlzdCBvciBpc1xuKiBwcm90b2NvbC1yZWxhdGl2ZSAoZS5nLiBcIi8vZXZpbC5leGFtcGxlXCIpLCB3aGljaCBjYW4gbmF2aWdhdGUgdG8gYW5vdGhlciBob3N0LlxuKiBSZXR1cm5zIHRydWUgZm9yIGJsb2NrZWQgcHJvdG9jb2xzIGxpa2UgamF2YXNjcmlwdDosIGJsb2I6LCBhbmQgZGF0YTosIGFzXG4qIHdlbGwgYXMgc2xhc2gvYmFja3NsYXNoIHZhcmlhbnRzIG9mIHByb3RvY29sLXJlbGF0aXZlIFVSTHMuXG4qXG4qIFNjaGVtZSBwYXJzaW5nIG5vcm1hbGl6ZXM6XG4qIC0gTWl4ZWQgY2FzZSAoSmF2YVNjcmlwdDog4oaSIGphdmFzY3JpcHQ6KVxuKiAtIFdoaXRlc3BhY2UvY29udHJvbCBjaGFyYWN0ZXJzIChqYXZhXFxuc2NyaXB0OiDihpIgamF2YXNjcmlwdDopXG4qIC0gTGVhZGluZyB3aGl0ZXNwYWNlXG4qXG4qIEZvciByZWxhdGl2ZSBVUkxzIHdpdGhvdXQgYSBwcm90b2NvbC1yZWxhdGl2ZSBwcmVmaXgsIHJldHVybnMgZmFsc2UuXG4qXG4qIEBwYXJhbSB1cmwgLSBUaGUgVVJMIHN0cmluZyB0byBjaGVja1xuKiBAcGFyYW0gYWxsb3dsaXN0IC0gU2V0IG9mIHByb3RvY29scyB0byBhbGxvd1xuKiBAcmV0dXJucyB0cnVlIGlmIHRoZSBVUkwgdXNlcyBhIHByb3RvY29sIHRoYXQgaXMgbm90IGFsbG93ZWQgb3IgY2FuIGVzY2FwZVxuKiB0aGUgY3VycmVudCBvcmlnaW4gdGhyb3VnaCBhIHByb3RvY29sLXJlbGF0aXZlIFVSTFxuKi9cbmZ1bmN0aW9uIGlzRGFuZ2Vyb3VzUHJvdG9jb2wodXJsLCBhbGxvd2xpc3QpIHtcblx0aWYgKCF1cmwpIHJldHVybiBmYWxzZTtcblx0aWYgKHByb3RvY29sUmVsYXRpdmVQcmVmaXhSZWdleC50ZXN0KHVybCkpIHJldHVybiB0cnVlO1xuXHRjb25zdCBzY2hlbWUgPSBnZXRVcmxTY2hlbWUodXJsKTtcblx0cmV0dXJuIHNjaGVtZSA/ICFhbGxvd2xpc3QuaGFzKHNjaGVtZSkgOiBmYWxzZTtcbn1cbmNvbnN0IEhUTUxfRVNDQVBFX0xPT0tVUCA9IHtcblx0XCImXCI6IFwiXFxcXHUwMDI2XCIsXG5cdFwiPlwiOiBcIlxcXFx1MDAzZVwiLFxuXHRcIjxcIjogXCJcXFxcdTAwM2NcIixcblx0XCJcXHUyMDI4XCI6IFwiXFxcXHUyMDI4XCIsXG5cdFwiXFx1MjAyOVwiOiBcIlxcXFx1MjAyOVwiXG59O1xuY29uc3QgSFRNTF9FU0NBUEVfUkVHRVggPSAvWyY+PFxcdTIwMjhcXHUyMDI5XS9nO1xuLyoqXG4qIEVzY2FwZSBIVE1MIHNwZWNpYWwgY2hhcmFjdGVycyBpbiBhIHN0cmluZyB0byBwcmV2ZW50IFhTUyBhdHRhY2tzXG4qIHdoZW4gZW1iZWRkaW5nIHN0cmluZ3MgaW4gc2NyaXB0IHRhZ3MgZHVyaW5nIFNTUi5cbipcbiogVGhpcyBpcyBlc3NlbnRpYWwgZm9yIHByZXZlbnRpbmcgWFNTIHZ1bG5lcmFiaWxpdGllcyB3aGVuIHVzZXItY29udHJvbGxlZFxuKiBjb250ZW50IGlzIGVtYmVkZGVkIGluIGlubGluZSBzY3JpcHRzLlxuKi9cbmZ1bmN0aW9uIGVzY2FwZUh0bWwoc3RyKSB7XG5cdHJldHVybiBzdHIucmVwbGFjZShIVE1MX0VTQ0FQRV9SRUdFWCwgKG1hdGNoKSA9PiBIVE1MX0VTQ0FQRV9MT09LVVBbbWF0Y2hdKTtcbn1cbmZ1bmN0aW9uIGRlY29kZVBhdGgocGF0aCkge1xuXHRpZiAoIXBhdGgpIHJldHVybiBwYXRoO1xuXHRsZXQgcmVzdWx0ID0gcGF0aDtcblx0aWYgKC9bJVxcXFxcXHgwMC1cXHgxZlxceDdmXS8udGVzdChwYXRoKSkge1xuXHRcdGNvbnN0IHJlID0gLyUyNXwlNUMvZ2k7XG5cdFx0bGV0IGN1cnNvciA9IDA7XG5cdFx0bGV0IG1hdGNoO1xuXHRcdHJlc3VsdCA9IFwiXCI7XG5cdFx0d2hpbGUgKG51bGwgIT09IChtYXRjaCA9IHJlLmV4ZWMocGF0aCkpKSB7XG5cdFx0XHRyZXN1bHQgKz0gZGVjb2RlU2VnbWVudChwYXRoLnNsaWNlKGN1cnNvciwgbWF0Y2guaW5kZXgpKSArIG1hdGNoWzBdO1xuXHRcdFx0Y3Vyc29yID0gcmUubGFzdEluZGV4O1xuXHRcdH1cblx0XHRyZXN1bHQgKz0gZGVjb2RlU2VnbWVudChjdXJzb3IgPyBwYXRoLnNsaWNlKGN1cnNvcikgOiBwYXRoKTtcblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufVxuLyoqXG4qIEVuY29kZXMgYSBwYXRoIHRoZSBzYW1lIHdheSBgbmV3IFVSTCgpYCB3b3VsZCwgYnV0IHdpdGhvdXQgdGhlIG92ZXJoZWFkIG9mIGZ1bGwgVVJMIHBhcnNpbmcuXG4qXG4qIFRoaXMgZnVuY3Rpb24gZW5jb2RlczpcbiogLSBXaGl0ZXNwYWNlIGNoYXJhY3RlcnMgKHNwYWNlcyDihpIgJTIwLCB0YWJzIOKGkiAlMDksIGV0Yy4pXG4qIC0gTm9uLUFTQ0lJL1VuaWNvZGUgY2hhcmFjdGVycyAoZW1vamlzLCBhY2NlbnRlZCBjaGFyYWN0ZXJzLCBldGMuKVxuKlxuKiBJdCBwcmVzZXJ2ZXM6XG4qIC0gQWxyZWFkeSBwZXJjZW50LWVuY29kZWQgc2VxdWVuY2VzICh3b24ndCBkb3VibGUtZW5jb2RlICUyRiwgJTI1LCBldGMuKVxuKiAtIEFTQ0lJIHNwZWNpYWwgY2hhcmFjdGVycyB2YWxpZCBpbiBVUkwgcGF0aHMgKEAsICQsICYsICssIGV0Yy4pXG4qIC0gRm9yd2FyZCBzbGFzaGVzIGFzIHBhdGggc2VwYXJhdG9yc1xuKlxuKiBVc2VkIHRvIGdlbmVyYXRlIHByb3BlciBocmVmIHZhbHVlcyBmb3IgU1NSIHdpdGhvdXQgY29uc3RydWN0aW5nIFVSTCBvYmplY3RzLlxuKlxuKiBAZXhhbXBsZVxuKiBlbmNvZGVQYXRoTGlrZVVybCgnL3BhdGgvZmlsZSBuYW1lLnBkZicpIC8vICcvcGF0aC9maWxlJTIwbmFtZS5wZGYnXG4qIGVuY29kZVBhdGhMaWtlVXJsKCcvcGF0aC/ml6XmnKzoqp4nKSAvLyAnL3BhdGgvJUU2JTk3JUE1JUU2JTlDJUFDJUU4JUFBJTlFJ1xuKiBlbmNvZGVQYXRoTGlrZVVybCgnL3BhdGgvYWxyZWFkeSUyMGVuY29kZWQnKSAvLyAnL3BhdGgvYWxyZWFkeSUyMGVuY29kZWQnIChwcmVzZXJ2ZWQpXG4qL1xuZnVuY3Rpb24gZW5jb2RlUGF0aExpa2VVcmwocGF0aCkge1xuXHRpZiAoIS9bXFxzXFx1MDA4MC1cXHVGRkZGXS8udGVzdChwYXRoKSkgcmV0dXJuIHBhdGg7XG5cdHJldHVybiBwYXRoLnJlcGxhY2UoL1xcc3xbXlxcdTAwMDAtXFx1MDA3Rl0vZ3UsIGVuY29kZVVSSUNvbXBvbmVudCk7XG59XG4vKipcbiogQnVpbGRzIHRoZSBkZXYtbW9kZSBDU1Mgc3R5bGVzIFVSTCBmb3Igcm91dGUtc2NvcGVkIENTUyBjb2xsZWN0aW9uLlxuKiBVc2VkIGJ5IEhlYWRDb250ZW50IGNvbXBvbmVudHMgaW4gYWxsIGZyYW1ld29yayBpbXBsZW1lbnRhdGlvbnMgdG8gY29uc3RydWN0XG4qIHRoZSBVUkwgZm9yIHRoZSBgL0B0YW5zdGFjay1zdGFydC9zdHlsZXMuY3NzYCBlbmRwb2ludC5cbipcbiogQHBhcmFtIGJhc2VwYXRoIC0gVGhlIHJvdXRlcidzIGJhc2VwYXRoIChtYXkgb3IgbWF5IG5vdCBoYXZlIGxlYWRpbmcgc2xhc2gpXG4qIEBwYXJhbSByb3V0ZUlkcyAtIEFycmF5IG9mIG1hdGNoZWQgcm91dGUgSURzIHRvIGluY2x1ZGUgaW4gdGhlIENTUyBjb2xsZWN0aW9uXG4qIEByZXR1cm5zIFRoZSBmdWxsIFVSTCBwYXRoIGZvciB0aGUgZGV2IHN0eWxlcyBDU1MgZW5kcG9pbnRcbiovXG5mdW5jdGlvbiBidWlsZERldlN0eWxlc1VybChiYXNlcGF0aCwgcm91dGVJZHMpIHtcblx0Y29uc3QgdHJpbW1lZEJhc2VwYXRoID0gYmFzZXBhdGgucmVwbGFjZSgvXlxcLyt8XFwvKyQvZywgXCJcIik7XG5cdHJldHVybiBgJHt0cmltbWVkQmFzZXBhdGggPT09IFwiXCIgPyBcIlwiIDogYC8ke3RyaW1tZWRCYXNlcGF0aH1gfS9AdGFuc3RhY2stc3RhcnQvc3R5bGVzLmNzcz9yb3V0ZXM9JHtlbmNvZGVVUklDb21wb25lbnQocm91dGVJZHMuam9pbihcIixcIikpfWA7XG59XG5mdW5jdGlvbiBhcnJheXNFcXVhbChhLCBiKSB7XG5cdGlmIChhID09PSBiKSByZXR1cm4gdHJ1ZTtcblx0aWYgKGEubGVuZ3RoICE9PSBiLmxlbmd0aCkgcmV0dXJuIGZhbHNlO1xuXHRmb3IgKGxldCBpID0gMDsgaSA8IGEubGVuZ3RoOyBpKyspIGlmIChhW2ldICE9PSBiW2ldKSByZXR1cm4gZmFsc2U7XG5cdHJldHVybiB0cnVlO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBERUZBVUxUX1BST1RPQ09MX0FMTE9XTElTVCwgYXJyYXlzRXF1YWwsIGJ1aWxkRGV2U3R5bGVzVXJsLCBjcmVhdGVDb250cm9sbGVkUHJvbWlzZSwgY3JlYXRlTnVsbCwgZGVjb2RlUGF0aCwgZGVlcEVxdWFsLCBlbmNvZGVQYXRoTGlrZVVybCwgZXNjYXBlSHRtbCwgZmluZExhc3QsIGZ1bmN0aW9uYWxVcGRhdGUsIGdldFVybFNjaGVtZSwgaGFzS2V5cywgaGFzT3duLCBpc0Rhbmdlcm91c1Byb3RvY29sLCBpc01vZHVsZU5vdEZvdW5kRXJyb3IsIGlzUGxhaW5PYmplY3QsIGlzUHJvbWlzZSwgbGFzdCwgbnVsbFJlcGxhY2VFcXVhbERlZXAsIHByb3RvY29sUmVsYXRpdmVQcmVmaXhSZWdleCwgcmVwbGFjZUVxdWFsRGVlcCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11dGlscy5qcy5tYXAiLCJpbXBvcnQgeyBsYXN0IH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbi8vI3JlZ2lvbiBzcmMvcGF0aC50c1xuLyoqIEpvaW4gcGF0aCBzZWdtZW50cywgY2xlYW5pbmcgZHVwbGljYXRlIHNsYXNoZXMgYmV0d2VlbiBwYXJ0cy4gKi9cbmZ1bmN0aW9uIGpvaW5QYXRocyhwYXRocykge1xuXHRyZXR1cm4gY2xlYW5QYXRoKHBhdGhzLmZpbHRlcigodmFsKSA9PiB7XG5cdFx0cmV0dXJuIHZhbCAhPT0gdm9pZCAwO1xuXHR9KS5qb2luKFwiL1wiKSk7XG59XG4vKiogUmVtb3ZlIHJlcGVhdGVkIHNsYXNoZXMgZnJvbSBhIHBhdGggc3RyaW5nLiAqL1xuZnVuY3Rpb24gY2xlYW5QYXRoKHBhdGgpIHtcblx0cmV0dXJuIHBhdGgucmVwbGFjZSgvXFwvezIsfS9nLCBcIi9cIik7XG59XG4vKiogVHJpbSBsZWFkaW5nIHNsYXNoZXMgKGV4Y2VwdCBwcmVzZXJ2aW5nIHJvb3QgJy8nKS4gKi9cbmZ1bmN0aW9uIHRyaW1QYXRoTGVmdChwYXRoKSB7XG5cdHJldHVybiBwYXRoID09PSBcIi9cIiA/IHBhdGggOiBwYXRoLnJlcGxhY2UoL15cXC8rLywgXCJcIik7XG59XG4vKiogVHJpbSB0cmFpbGluZyBzbGFzaGVzIChleGNlcHQgcHJlc2VydmluZyByb290ICcvJykuICovXG5mdW5jdGlvbiB0cmltUGF0aFJpZ2h0KHBhdGgpIHtcblx0Y29uc3QgbGVuID0gcGF0aC5sZW5ndGg7XG5cdHJldHVybiBsZW4gPiAxICYmIHBhdGhbbGVuIC0gMV0gPT09IFwiL1wiID8gcGF0aC5yZXBsYWNlKC9cXC8rJC8sIFwiXCIpIDogcGF0aDtcbn1cbi8qKiBUcmltIGJvdGggbGVhZGluZyBhbmQgdHJhaWxpbmcgc2xhc2hlcy4gKi9cbmZ1bmN0aW9uIHRyaW1QYXRoKHBhdGgpIHtcblx0cmV0dXJuIHRyaW1QYXRoUmlnaHQodHJpbVBhdGhMZWZ0KHBhdGgpKTtcbn1cbi8qKiBSZW1vdmUgYSB0cmFpbGluZyBzbGFzaCBmcm9tIHZhbHVlIHdoZW4gYXBwcm9wcmlhdGUgZm9yIGNvbXBhcmlzb25zLiAqL1xuZnVuY3Rpb24gcmVtb3ZlVHJhaWxpbmdTbGFzaCh2YWx1ZSwgYmFzZXBhdGgpIHtcblx0aWYgKHZhbHVlPy5lbmRzV2l0aChcIi9cIikgJiYgdmFsdWUgIT09IFwiL1wiICYmIHZhbHVlICE9PSBgJHtiYXNlcGF0aH0vYCkgcmV0dXJuIHZhbHVlLnNsaWNlKDAsIC0xKTtcblx0cmV0dXJuIHZhbHVlO1xufVxuLyoqXG4qIENvbXBhcmUgdHdvIHBhdGhuYW1lcyBmb3IgZXhhY3QgZXF1YWxpdHkgYWZ0ZXIgbm9ybWFsaXppbmcgdHJhaWxpbmcgc2xhc2hlc1xuKiByZWxhdGl2ZSB0byB0aGUgcHJvdmlkZWQgYGJhc2VwYXRoYC5cbiovXG5mdW5jdGlvbiBleGFjdFBhdGhUZXN0KHBhdGhOYW1lMSwgcGF0aE5hbWUyLCBiYXNlcGF0aCkge1xuXHRyZXR1cm4gcmVtb3ZlVHJhaWxpbmdTbGFzaChwYXRoTmFtZTEsIGJhc2VwYXRoKSA9PT0gcmVtb3ZlVHJhaWxpbmdTbGFzaChwYXRoTmFtZTIsIGJhc2VwYXRoKTtcbn1cbi8qKlxuKiBSZXNvbHZlIGEgZGVzdGluYXRpb24gcGF0aCBhZ2FpbnN0IGEgYmFzZSwgaG9ub3JpbmcgdHJhaWxpbmctc2xhc2ggcG9saWN5XG4qIGFuZCBzdXBwb3J0aW5nIHJlbGF0aXZlIHNlZ21lbnRzIChgLmAvYC4uYCkgYW5kIGFic29sdXRlIGB0b2AgdmFsdWVzLlxuKlxuKiBJbnRlcm5hbDogcGFyYW1ldGVycyBhcmUgcG9zaXRpb25hbCBzbyB0aGUgcm91dGVyJ3MgaG90IGNhbGxlcnMgcGFzcyBub1xuKiBvcHRpb25zIG9iamVjdC5cbiovXG5mdW5jdGlvbiByZXNvbHZlUGF0aChiYXNlLCB0bywgdHJhaWxpbmdTbGFzaCA9IFwibmV2ZXJcIiwgY2FjaGUpIHtcblx0aWYgKHRvLmluY2x1ZGVzKFwiLy9cIikpIHRvID0gY2xlYW5QYXRoKHRvKTtcblx0aWYgKHRvLnN0YXJ0c1dpdGgoXCIvXCIpKSB7XG5cdFx0aWYgKHRvLmxlbmd0aCA9PT0gMSB8fCB0cmFpbGluZ1NsYXNoID09PSBcInByZXNlcnZlXCIpIHJldHVybiB0bztcblx0XHRpZiAodHJhaWxpbmdTbGFzaCA9PT0gXCJhbHdheXNcIikgcmV0dXJuIHRvLmVuZHNXaXRoKFwiL1wiKSA/IHRvIDogYCR7dG99L2A7XG5cdFx0cmV0dXJuIHRvLmVuZHNXaXRoKFwiL1wiKSA/IHRvLnNsaWNlKDAsIC0xKSA6IHRvO1xuXHR9XG5cdGNvbnN0IGlzQmFzZSA9IHRvID09PSBcIi5cIjtcblx0bGV0IGtleTtcblx0aWYgKGNhY2hlKSB7XG5cdFx0a2V5ID0gaXNCYXNlID8gYmFzZSA6IGJhc2UgKyBcIlxcMFwiICsgdG87XG5cdFx0Y29uc3QgY2FjaGVkID0gY2FjaGUuZ2V0KGtleSk7XG5cdFx0aWYgKGNhY2hlZCkgcmV0dXJuIGNhY2hlZDtcblx0fVxuXHRsZXQgYmFzZVNlZ21lbnRzO1xuXHRpZiAoaXNCYXNlKSBiYXNlU2VnbWVudHMgPSBiYXNlLnNwbGl0KFwiL1wiKTtcblx0ZWxzZSB7XG5cdFx0aWYgKGJhc2UuaW5jbHVkZXMoXCIvL1wiKSkgYmFzZSA9IGNsZWFuUGF0aChiYXNlKTtcblx0XHRiYXNlU2VnbWVudHMgPSBiYXNlLnNwbGl0KFwiL1wiKTtcblx0XHR3aGlsZSAoYmFzZVNlZ21lbnRzLmxlbmd0aCA+IDEgJiYgbGFzdChiYXNlU2VnbWVudHMpID09PSBcIlwiKSBiYXNlU2VnbWVudHMucG9wKCk7XG5cdFx0Y29uc3QgdG9TZWdtZW50cyA9IHRvLnNwbGl0KFwiL1wiKTtcblx0XHRmb3IgKGxldCBpbmRleCA9IDAsIGxlbmd0aCA9IHRvU2VnbWVudHMubGVuZ3RoOyBpbmRleCA8IGxlbmd0aDsgaW5kZXgrKykge1xuXHRcdFx0Y29uc3QgdmFsdWUgPSB0b1NlZ21lbnRzW2luZGV4XTtcblx0XHRcdGlmICh2YWx1ZSA9PT0gXCJcIikge1xuXHRcdFx0XHRpZiAoIWluZGV4KSBiYXNlU2VnbWVudHMgPSBbdmFsdWVdO1xuXHRcdFx0XHRlbHNlIGlmIChpbmRleCA9PT0gbGVuZ3RoIC0gMSkgYmFzZVNlZ21lbnRzLnB1c2godmFsdWUpO1xuXHRcdFx0fSBlbHNlIGlmICh2YWx1ZSA9PT0gXCIuLlwiKSB7XG5cdFx0XHRcdGlmIChiYXNlU2VnbWVudHMubGVuZ3RoID4gMSkgYmFzZVNlZ21lbnRzLnBvcCgpO1xuXHRcdFx0XHRlbHNlIGJhc2VTZWdtZW50cyA9IFtcIlwiXTtcblx0XHRcdH0gZWxzZSBpZiAodmFsdWUgPT09IFwiLlwiKSB7fSBlbHNlIGJhc2VTZWdtZW50cy5wdXNoKHZhbHVlKTtcblx0XHR9XG5cdH1cblx0aWYgKGJhc2VTZWdtZW50cy5sZW5ndGggPiAxKSB7XG5cdFx0aWYgKGxhc3QoYmFzZVNlZ21lbnRzKSA9PT0gXCJcIikge1xuXHRcdFx0aWYgKHRyYWlsaW5nU2xhc2ggPT09IFwibmV2ZXJcIikgYmFzZVNlZ21lbnRzLnBvcCgpO1xuXHRcdH0gZWxzZSBpZiAodHJhaWxpbmdTbGFzaCA9PT0gXCJhbHdheXNcIikgYmFzZVNlZ21lbnRzLnB1c2goXCJcIik7XG5cdH1cblx0Y29uc3Qgam9pbmVkID0gYmFzZVNlZ21lbnRzLmpvaW4oXCIvXCIpO1xuXHRjb25zdCByZXN1bHQgPSAoaXNCYXNlID8gY2xlYW5QYXRoKGpvaW5lZCkgOiBqb2luZWQpIHx8IFwiL1wiO1xuXHRpZiAoa2V5ICYmIGNhY2hlKSBjYWNoZS5zZXQoa2V5LCByZXN1bHQpO1xuXHRyZXR1cm4gcmVzdWx0O1xufVxuLyoqXG4qIENyZWF0ZSBhIHByZS1jb21waWxlZCBkZWNvZGUgY29uZmlnIGZyb20gYWxsb3dlZCBjaGFyYWN0ZXJzLlxuKiBDcmVhdGVkIG9uY2UgZm9yIHRoZSByb3V0ZXIncyBmaXhlZCBlbmNvZGluZyBjb25maWd1cmF0aW9uLlxuKi9cbmZ1bmN0aW9uIGNvbXBpbGVEZWNvZGVDaGFyTWFwKHBhdGhQYXJhbXNBbGxvd2VkQ2hhcmFjdGVycykge1xuXHRjb25zdCBjaGFyTWFwID0gbmV3IE1hcChwYXRoUGFyYW1zQWxsb3dlZENoYXJhY3RlcnMubWFwKChjaGFyKSA9PiBbZW5jb2RlVVJJQ29tcG9uZW50KGNoYXIpLCBjaGFyXSkpO1xuXHRjb25zdCByZWdleCA9IG5ldyBSZWdFeHAoWy4uLmNoYXJNYXAua2V5cygpXS5qb2luKFwifFwiKS5yZXBsYWNlKC9bLiooKV0vZywgXCJcXFxcJCZcIiksIFwiZ1wiKTtcblx0cmV0dXJuIChlbmNvZGVkKSA9PiBlbmNvZGVkLnJlcGxhY2UocmVnZXgsIChtYXRjaCkgPT4gY2hhck1hcC5nZXQobWF0Y2gpID8/IG1hdGNoKTtcbn1cbmZ1bmN0aW9uIGdldFJvdXRlU2VnbWVudHMocm91dGUpIHtcblx0cmV0dXJuIHJvdXRlLl9pbnRlcnBvbGF0aW9uO1xufVxuLyoqIEEgc3BsYXQgaXMgbWlzc2luZyB3aGVuIGl0IGhhcyBubyB2YWx1ZTsgYDBgIGFuZCBgZmFsc2VgIGFyZSBzdHJpbmdpZmllZCBsaWtlIGFueSBvdGhlciBwYXJhbS4gKi9cbmZ1bmN0aW9uIGlzTWlzc2luZ1NwbGF0KHZhbHVlKSB7XG5cdHJldHVybiB2YWx1ZSA9PSBudWxsIHx8IHZhbHVlID09PSBcIlwiO1xufVxuLyoqIERldnRvb2xzIGNoZWNrcyBuYXZpZ2F0aW9uIGF2YWlsYWJpbGl0eSBzZXBhcmF0ZWx5IGZyb20gdGhlIGhvdCBmb3JtYXR0ZXIuICovXG5mdW5jdGlvbiBoYXNNaXNzaW5nUGF0aFBhcmFtcyhzZWdtZW50cywgcGFyYW1zKSB7XG5cdHJldHVybiBzZWdtZW50cy5zb21lKChwYXJ0KSA9PiB7XG5cdFx0aWYgKHR5cGVvZiBwYXJ0ID09PSBcInN0cmluZ1wiKSByZXR1cm4gZmFsc2U7XG5cdFx0Y29uc3QgW2tpbmQsIGtleV0gPSBwYXJ0O1xuXHRcdHJldHVybiBraW5kID09PSAyID8gaXNNaXNzaW5nU3BsYXQocGFyYW1zW2tleV0pIDoga2luZCA9PT0gMSAmJiAhKGtleSBpbiBwYXJhbXMpO1xuXHR9KTtcbn1cbmZ1bmN0aW9uIGVuY29kZVBhcmFtKGtleSwgdmFsdWUsIGRlY29kZXIpIHtcblx0aWYgKHR5cGVvZiB2YWx1ZSAhPT0gXCJzdHJpbmdcIikgcmV0dXJuIFwiXCIgKyAodmFsdWUgPz8gdm9pZCAwKTtcblx0Y29uc3Qgc3BsYXQgPSBrZXkgPT09IFwiX3NwbGF0XCI7XG5cdGlmIChzcGxhdCAmJiAoIXZhbHVlIHx8IC9eW2EtekEtWjAtOVxcLS5ffiEvXSokLy50ZXN0KHZhbHVlKSkpIHJldHVybiB2YWx1ZTtcblx0bGV0IGVuY29kZWQgPSBlbmNvZGVVUklDb21wb25lbnQodmFsdWUpO1xuXHRpZiAoc3BsYXQpIGVuY29kZWQgPSBlbmNvZGVkLnJlcGxhY2VBbGwoXCIlMkZcIiwgXCIvXCIpO1xuXHRyZXR1cm4gZGVjb2RlciA/IGRlY29kZXIoZW5jb2RlZCkgOiBlbmNvZGVkO1xufVxuLyoqIFN1YnN0aXR1dGUgY3VycmVudCB2YWx1ZXMgaW50byBwYXJzZWQgc2VnbWVudHMsIG9wdGlvbmFsbHkgY29sbGVjdGluZyByYXcgcGFyYW1zLiAqL1xuZnVuY3Rpb24gaW50ZXJwb2xhdGVQYXRoKHBhdGgsIHNlZ21lbnRzLCBwYXJhbXMsIGRlY29kZXIsIHVzZWRQYXJhbXMpIHtcblx0Y29uc3QgdHJhaWxpbmdTbGFzaCA9IHBhdGguZW5kc1dpdGgoXCIvXCIpID8gXCIvXCIgOiBcIlwiO1xuXHRsZXQgam9pbmVkID0gXCJcIjtcblx0Zm9yIChjb25zdCBwYXJ0IG9mIHNlZ21lbnRzKSB7XG5cdFx0aWYgKHR5cGVvZiBwYXJ0ID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRqb2luZWQgKz0gcGFydDtcblx0XHRcdGNvbnRpbnVlO1xuXHRcdH1cblx0XHRjb25zdCBba2luZCwga2V5LCBwcmVmaXgsIHJhd1N1ZmZpeF0gPSBwYXJ0O1xuXHRcdGNvbnN0IHNwbGF0ID0ga2luZCA9PT0gMjtcblx0XHRjb25zdCBzdWZmaXggPSBzcGxhdCAmJiByYXdTdWZmaXggIT09IHZvaWQgMCA/IHJhd1N1ZmZpeCArIHRyYWlsaW5nU2xhc2ggOiByYXdTdWZmaXg7XG5cdFx0bGV0IHBhcmFtVmFsdWUgPSBwYXJhbXNba2V5XTtcblx0XHRpZiAoa2luZCA9PT0gMyAmJiBwYXJhbVZhbHVlID09IG51bGwpIGNvbnRpbnVlO1xuXHRcdGlmICh1c2VkUGFyYW1zKSB7XG5cdFx0XHR1c2VkUGFyYW1zW2tleV0gPSBwYXJhbVZhbHVlO1xuXHRcdFx0aWYgKHNwbGF0KSB1c2VkUGFyYW1zW1wiKlwiXSA9IHBhcmFtVmFsdWU7XG5cdFx0fVxuXHRcdGlmIChzcGxhdCAmJiBpc01pc3NpbmdTcGxhdChwYXJhbVZhbHVlKSkge1xuXHRcdFx0aWYgKHByZWZpeCA9PT0gXCIvXCIgJiYgIXN1ZmZpeCkgY29udGludWU7XG5cdFx0XHRwYXJhbVZhbHVlID0gXCJcIjtcblx0XHR9XG5cdFx0am9pbmVkICs9IHByZWZpeCArIGVuY29kZVBhcmFtKGtleSwgcGFyYW1WYWx1ZSwgZGVjb2RlcikgKyAoc3VmZml4IHx8IFwiXCIpO1xuXHR9XG5cdHJldHVybiBqb2luZWQgKyB0cmFpbGluZ1NsYXNoIHx8IFwiL1wiO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBjbGVhblBhdGgsIGNvbXBpbGVEZWNvZGVDaGFyTWFwLCBleGFjdFBhdGhUZXN0LCBnZXRSb3V0ZVNlZ21lbnRzLCBoYXNNaXNzaW5nUGF0aFBhcmFtcywgaW50ZXJwb2xhdGVQYXRoLCBqb2luUGF0aHMsIHJlbW92ZVRyYWlsaW5nU2xhc2gsIHJlc29sdmVQYXRoLCB0cmltUGF0aCwgdHJpbVBhdGhMZWZ0LCB0cmltUGF0aFJpZ2h0IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhdGguanMubWFwIiwiLy8jcmVnaW9uIHNyYy9zaWV2ZS1jYWNoZS50c1xuLyoqXG4qIEEgZml4ZWQtY2FwYWNpdHkgY2FjaGUgdXNpbmcgdGhlIFNJRVZFIGV2aWN0aW9uIGFsZ29yaXRobVxuKiAoaHR0cHM6Ly9jYWNoZW1vbi5naXRodWIuaW8vU0lFVkUtd2Vic2l0ZS8pLlxuKlxuKiBFbnRyaWVzIGxpdmUgaW4gdGhlIE1hcCdzIEZJRk8gaW5zZXJ0aW9uIG9yZGVyOyBhIGhpdCBvbmx5IGZsaXBzIGEgYHZpc2l0ZWRgXG4qIGJpdCBpbnN0ZWFkIG9mIHJlbGlua2luZyB0aGUgZW50cnksIHdoaWNoIG1ha2VzIGBnZXRgIChieSBmYXIgdGhlIGhvdHRlc3Rcbiogb3BlcmF0aW9uIGhlcmUpIG9uZSBgTWFwLmdldGAgcGx1cyBhIGJvb2xlYW4gc3RvcmUuIEV2aWN0aW9uIHN3ZWVwcyBhIGBoYW5kYFxuKiBmcm9tIHRoZSBvbGRlc3QgZW50cnkgdG93YXJkcyB0aGUgbmV3ZXN0LCBjbGVhcmluZyBgdmlzaXRlZGAgYml0cyB1bnRpbCBpdFxuKiBmaW5kcyBhbiB1bnZpc2l0ZWQgZW50cnkgdG8gZHJvcCwgc28gZW50cmllcyB0b3VjaGVkIHNpbmNlIHRoZSBsYXN0IHN3ZWVwXG4qIHN1cnZpdmUgb25lIG1vcmUgcm91bmQuIFRoaXMga2VlcHMgTFJVLWxpa2UgaGl0IHJhdGlvcyB3aGlsZSBiZWluZ1xuKiBzY2FuLXJlc2lzdGFudC5cbiovXG5mdW5jdGlvbiBjcmVhdGVTaWV2ZUNhY2hlKG1heCkge1xuXHRjb25zdCBjYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGxldCBoYW5kO1xuXHRsZXQgbmV3ZXN0O1xuXHRyZXR1cm4ge1xuXHRcdGdldChrZXkpIHtcblx0XHRcdGNvbnN0IGVudHJ5ID0gY2FjaGUuZ2V0KGtleSk7XG5cdFx0XHRpZiAoIWVudHJ5KSByZXR1cm47XG5cdFx0XHRlbnRyeS52aXNpdGVkID0gdHJ1ZTtcblx0XHRcdHJldHVybiBlbnRyeS52YWx1ZTtcblx0XHR9LFxuXHRcdHNldChrZXksIHZhbHVlKSB7XG5cdFx0XHRjb25zdCBleGlzdGluZyA9IGNhY2hlLmdldChrZXkpO1xuXHRcdFx0aWYgKGV4aXN0aW5nKSB7XG5cdFx0XHRcdGV4aXN0aW5nLnZhbHVlID0gdmFsdWU7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHRcdGlmIChjYWNoZS5zaXplID49IG1heCkge1xuXHRcdFx0XHRsZXQgbm9kZSA9IGhhbmQ/Lm5leHQoKS52YWx1ZTtcblx0XHRcdFx0d2hpbGUgKCFub2RlIHx8IG5vZGUudmlzaXRlZCkge1xuXHRcdFx0XHRcdGlmIChub2RlKSBub2RlLnZpc2l0ZWQgPSBmYWxzZTtcblx0XHRcdFx0XHRlbHNlIGhhbmQgPSBjYWNoZS52YWx1ZXMoKTtcblx0XHRcdFx0XHRub2RlID0gaGFuZC5uZXh0KCkudmFsdWU7XG5cdFx0XHRcdH1cblx0XHRcdFx0aWYgKG5vZGUgPT09IG5ld2VzdCkgaGFuZCA9IHZvaWQgMDtcblx0XHRcdFx0Y2FjaGUuZGVsZXRlKG5vZGUua2V5KTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IGVudHJ5ID0ge1xuXHRcdFx0XHRrZXksXG5cdFx0XHRcdHZhbHVlLFxuXHRcdFx0XHR2aXNpdGVkOiBmYWxzZVxuXHRcdFx0fTtcblx0XHRcdG5ld2VzdCA9IGVudHJ5O1xuXHRcdFx0Y2FjaGUuc2V0KGtleSwgZW50cnkpO1xuXHRcdH0sXG5cdFx0Y2xlYXIoKSB7XG5cdFx0XHRjYWNoZS5jbGVhcigpO1xuXHRcdFx0aGFuZCA9IHZvaWQgMDtcblx0XHRcdG5ld2VzdCA9IHZvaWQgMDtcblx0XHR9XG5cdH07XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNyZWF0ZVNpZXZlQ2FjaGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2lldmUtY2FjaGUuanMubWFwIiwiaW1wb3J0IHsgbGFzdCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBpbnZhcmlhbnQgfSBmcm9tIFwiLi9pbnZhcmlhbnQuanNcIjtcbmltcG9ydCB7IHRyaW1QYXRoUmlnaHQgfSBmcm9tIFwiLi9wYXRoLmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVTaWV2ZUNhY2hlIH0gZnJvbSBcIi4vc2lldmUtY2FjaGUuanNcIjtcbmNvbnN0IFNFR01FTlRfVFlQRV9JTkRFWCA9IDQ7XG5jb25zdCBTRUdNRU5UX1RZUEVfUEFUSExFU1MgPSA1O1xuZnVuY3Rpb24gZ2V0UGFyYW1OYW1lcyhkYXRhKSB7XG5cdGNvbnN0IGNhY2hlZCA9IGRhdGEubmFtZXM7XG5cdGlmIChjYWNoZWQpIHJldHVybiBjYWNoZWQ7XG5cdGNvbnN0IGtleXMgPSBbXTtcblx0Zm9yIChjb25zdCBzZWdtZW50IG9mIGRhdGEpIGlmICh0eXBlb2Ygc2VnbWVudCAhPT0gXCJzdHJpbmdcIikga2V5cy5wdXNoKHNlZ21lbnRbMV0pO1xuXHRyZXR1cm4gZGF0YS5uYW1lcyA9IGtleXM7XG59XG4vKiogUGFyc2Ugb25lIHNlZ21lbnQgZm9yIG1hdGNoaW5nIGFuZCByZXRhaW4gdGhlIHNhbWUgcmVjb3JkIGZvciBpbnRlcnBvbGF0aW9uLiAqL1xuZnVuY3Rpb24gcGFyc2VTZWdtZW50KHBhdGgsIHN0YXJ0LCBlbmQpIHtcblx0Y29uc3QgcGFydCA9IHBhdGguc2xpY2Uoc3RhcnQsIGVuZCk7XG5cdGlmIChwYXJ0LmNoYXJDb2RlQXQoMCkgPT09IDM2KSByZXR1cm4gcGFydC5sZW5ndGggPT09IDEgPyBbXG5cdFx0Mixcblx0XHRcIl9zcGxhdFwiLFxuXHRcdFwiXCIsXG5cdFx0dm9pZCAwXG5cdF0gOiBbXG5cdFx0MSxcblx0XHRwYXJ0LnNsaWNlKDEpLFxuXHRcdFwiXCIsXG5cdFx0XCJcIlxuXHRdO1xuXHRjb25zdCBvcGVuID0gcGFydC5pbmRleE9mKFwie1wiKTtcblx0aWYgKG9wZW4gPj0gMCkge1xuXHRcdGNvbnN0IGNsb3NlID0gcGFydC5pbmRleE9mKFwifVwiLCBvcGVuKTtcblx0XHRjb25zdCBvcHRpb25hbCA9IHBhcnQuY2hhckNvZGVBdChvcGVuICsgMSkgPT09IDQ1O1xuXHRcdGNvbnN0IG5hbWVTdGFydCA9IG9wZW4gKyAob3B0aW9uYWwgPyAzIDogMik7XG5cdFx0aWYgKGNsb3NlID49IDAgJiYgcGFydC5jaGFyQ29kZUF0KG5hbWVTdGFydCAtIDEpID09PSAzNiAmJiAoIW9wdGlvbmFsIHx8IG5hbWVTdGFydCA8IGNsb3NlKSkge1xuXHRcdFx0Y29uc3Qga2V5ID0gcGFydC5zbGljZShuYW1lU3RhcnQsIGNsb3NlKTtcblx0XHRcdHJldHVybiBbXG5cdFx0XHRcdG9wdGlvbmFsID8gMyA6IGtleSA/IDEgOiAyLFxuXHRcdFx0XHRrZXkgfHwgXCJfc3BsYXRcIixcblx0XHRcdFx0cGFydC5zbGljZSgwLCBvcGVuKSxcblx0XHRcdFx0cGF0aC5zbGljZShzdGFydCArIGNsb3NlICsgMSwga2V5ID8gZW5kIDogcGF0aC5sZW5ndGgpXG5cdFx0XHRdO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gcGFydDtcbn1cbmZ1bmN0aW9uIHBhcnNlU2VnbWVudHMoZGVmYXVsdENhc2VTZW5zaXRpdmUsIHJvdXRlLCBzdGFydCwgbm9kZSwgZHluYW1pY0xpc3RzVG9Tb3J0LCBwYXJlbnRJbnRlcnBvbGF0aW9uKSB7XG5cdGxldCBjdXJzb3IgPSBzdGFydDtcblx0Y29uc3QgcGF0aCA9IHJvdXRlLmZ1bGxQYXRoID8/IHJvdXRlLmZyb207XG5cdGNvbnN0IG9wdGlvbnMgPSByb3V0ZS5vcHRpb25zO1xuXHRjb25zdCBsZW5ndGggPSBwYXRoLmxlbmd0aDtcblx0Y29uc3QgbGl0ZXJhbEVuZCA9IHBhdGguZW5kc1dpdGgoXCIvXCIpID8gbGVuZ3RoIC0gMSA6IGxlbmd0aDtcblx0Y29uc3QgY2FzZVNlbnNpdGl2ZSA9IG9wdGlvbnM/LmNhc2VTZW5zaXRpdmUgPz8gZGVmYXVsdENhc2VTZW5zaXRpdmU7XG5cdGNvbnN0IHBhcnNlUGFyYW1zID0gb3B0aW9ucz8ucGFyYW1zPy5wYXJzZSA/PyBvcHRpb25zPy5wYXJzZVBhcmFtcztcblx0bGV0IGludGVycG9sYXRpb247XG5cdGxldCBsaXRlcmFsU3RhcnQgPSBwYXJlbnRJbnRlcnBvbGF0aW9uID8gc3RhcnQgLSAxIDogMDtcblx0aWYgKCFub2RlIHx8IHBhdGguaW5jbHVkZXMoXCIkXCIpKSB7XG5cdFx0aW50ZXJwb2xhdGlvbiA9IHBhcmVudEludGVycG9sYXRpb24/LnNsaWNlKCkgPz8gW107XG5cdFx0Y29uc3QgdGFpbCA9IGxhc3QoaW50ZXJwb2xhdGlvbik7XG5cdFx0aWYgKHRhaWwgJiYgdHlwZW9mIHRhaWwgIT09IFwic3RyaW5nXCIgJiYgdGFpbFswXSA9PT0gMikge1xuXHRcdFx0aW50ZXJwb2xhdGlvbltpbnRlcnBvbGF0aW9uLmxlbmd0aCAtIDFdID0gW1xuXHRcdFx0XHR0YWlsWzBdLFxuXHRcdFx0XHR0YWlsWzFdLFxuXHRcdFx0XHR0YWlsWzJdLFxuXHRcdFx0XHR0YWlsWzNdID09PSB2b2lkIDAgPyB2b2lkIDAgOiB0YWlsWzNdICsgcGF0aC5zdWJzdHJpbmcoc3RhcnQgLSAocGF0aFtzdGFydCAtIDJdID09PSBcIi9cIiA/IDIgOiAxKSwgbGl0ZXJhbEVuZClcblx0XHRcdF07XG5cdFx0XHRsaXRlcmFsU3RhcnQgPSBsZW5ndGg7XG5cdFx0fVxuXHR9XG5cdHdoaWxlIChjdXJzb3IgPCBsZW5ndGgpIHtcblx0XHRjb25zdCBzdGFydCA9IGN1cnNvcjtcblx0XHRjb25zdCBuZXh0ID0gcGF0aC5pbmRleE9mKFwiL1wiLCBzdGFydCk7XG5cdFx0bGV0IGVuZCA9IG5leHQgPT09IC0xID8gbGVuZ3RoIDogbmV4dDtcblx0XHRjb25zdCBzZWdtZW50ID0gcGFyc2VTZWdtZW50KHBhdGgsIHN0YXJ0LCBlbmQpO1xuXHRcdGN1cnNvciA9IGVuZCArIDE7XG5cdFx0bGV0IG5leHROb2RlO1xuXHRcdGlmICh0eXBlb2Ygc2VnbWVudCA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0aWYgKCFub2RlKSBjb250aW51ZTtcblx0XHRcdGxldCBuYW1lID0gc2VnbWVudDtcblx0XHRcdGxldCBzdGF0aWNDaGlsZHJlbjtcblx0XHRcdGlmIChjYXNlU2Vuc2l0aXZlKSBzdGF0aWNDaGlsZHJlbiA9IG5vZGUuc3RhdGljID8/PSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdG5hbWUgPSBzZWdtZW50LnRvTG93ZXJDYXNlKCk7XG5cdFx0XHRcdHN0YXRpY0NoaWxkcmVuID0gbm9kZS5zdGF0aWNJbnNlbnNpdGl2ZSA/Pz0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IGV4aXN0aW5nTm9kZSA9IHN0YXRpY0NoaWxkcmVuLmdldChuYW1lKTtcblx0XHRcdGlmIChleGlzdGluZ05vZGUpIG5leHROb2RlID0gZXhpc3RpbmdOb2RlO1xuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdGNvbnN0IG5leHQgPSBjcmVhdGVTZWdtZW50Tm9kZShub2RlKTtcblx0XHRcdFx0bmV4dE5vZGUgPSBuZXh0O1xuXHRcdFx0XHRzdGF0aWNDaGlsZHJlbi5zZXQobmFtZSwgbmV4dCk7XG5cdFx0XHR9XG5cdFx0fSBlbHNlIHtcblx0XHRcdGNvbnN0IGtpbmQgPSBzZWdtZW50WzBdO1xuXHRcdFx0bGV0IHByZWZpeCA9IHNlZ21lbnRbMl07XG5cdFx0XHRsZXQgc3VmZml4ID0gc2VnbWVudFszXSA/PyBcIlwiO1xuXHRcdFx0aWYgKGtpbmQgPT09IDIpIHtcblx0XHRcdFx0ZW5kID0gbGVuZ3RoO1xuXHRcdFx0XHRjdXJzb3IgPSBlbmQgKyAxO1xuXHRcdFx0fVxuXHRcdFx0aWYgKGludGVycG9sYXRpb24gJiYgbGl0ZXJhbFN0YXJ0IDwgZW5kKSB7XG5cdFx0XHRcdGlmIChsaXRlcmFsU3RhcnQgPCBzdGFydCAtIDEpIGludGVycG9sYXRpb24ucHVzaChwYXRoLnNsaWNlKGxpdGVyYWxTdGFydCwgc3RhcnQgLSAxKSk7XG5cdFx0XHRcdHNlZ21lbnRbMl0gPSBcIi9cIiArIHByZWZpeDtcblx0XHRcdFx0aWYgKGtpbmQgPT09IDIgJiYgc2VnbWVudFszXSAhPT0gdm9pZCAwICYmIGxpdGVyYWxFbmQgPCBsZW5ndGgpIHNlZ21lbnRbM10gPSBzdWZmaXguc2xpY2UoMCwgLTEpO1xuXHRcdFx0XHRpbnRlcnBvbGF0aW9uLnB1c2goc2VnbWVudCk7XG5cdFx0XHRcdGxpdGVyYWxTdGFydCA9IGVuZDtcblx0XHRcdH1cblx0XHRcdGlmICghbm9kZSkgY29udGludWU7XG5cdFx0XHRjb25zdCBhY3R1YWxseUNhc2VTZW5zaXRpdmUgPSBjYXNlU2Vuc2l0aXZlICYmICEhKHByZWZpeCB8fCBzdWZmaXgpO1xuXHRcdFx0aWYgKCFjYXNlU2Vuc2l0aXZlKSB7XG5cdFx0XHRcdHByZWZpeCA9IHByZWZpeC50b0xvd2VyQ2FzZSgpO1xuXHRcdFx0XHRzdWZmaXggPSBzdWZmaXgudG9Mb3dlckNhc2UoKTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IHNpYmxpbmdzID0ga2luZCA9PT0gMSA/IG5vZGUuZHluYW1pYyA/Pz0gW10gOiBraW5kID09PSAzID8gbm9kZS5vcHRpb25hbCA/Pz0gW10gOiBub2RlLndpbGRjYXJkID8/PSBbXTtcblx0XHRcdGNvbnN0IGV4aXN0aW5nTm9kZSA9IGtpbmQgIT09IDIgJiYgIXBhcnNlUGFyYW1zICYmIHNpYmxpbmdzLmZpbmQoKHMpID0+ICFzLnBhcnNlICYmIHMuY2FzZVNlbnNpdGl2ZSA9PT0gYWN0dWFsbHlDYXNlU2Vuc2l0aXZlICYmIHMucHJlZml4ID09PSBwcmVmaXggJiYgcy5zdWZmaXggPT09IHN1ZmZpeCk7XG5cdFx0XHRpZiAoZXhpc3RpbmdOb2RlKSBuZXh0Tm9kZSA9IGV4aXN0aW5nTm9kZTtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRjb25zdCBuZXh0ID0gY3JlYXRlU2VnbWVudE5vZGUobm9kZSwga2luZCwgYWN0dWFsbHlDYXNlU2Vuc2l0aXZlLCBwcmVmaXgsIHN1ZmZpeCk7XG5cdFx0XHRcdG5leHROb2RlID0gbmV4dDtcblx0XHRcdFx0c2libGluZ3MucHVzaChuZXh0KTtcblx0XHRcdFx0aWYgKHNpYmxpbmdzLmxlbmd0aCA9PT0gMikgZHluYW1pY0xpc3RzVG9Tb3J0Py5wdXNoKHNpYmxpbmdzKTtcblx0XHRcdH1cblx0XHR9XG5cdFx0bm9kZSA9IG5leHROb2RlO1xuXHR9XG5cdGlmIChpbnRlcnBvbGF0aW9uICYmIGxpdGVyYWxTdGFydCA8IGxpdGVyYWxFbmQpIGludGVycG9sYXRpb24ucHVzaChwYXRoLnNsaWNlKGxpdGVyYWxTdGFydCwgbGl0ZXJhbEVuZCkpO1xuXHRjb25zdCBzZWdtZW50RGF0YSA9IGludGVycG9sYXRpb24/LnNsaWNlKCk7XG5cdGlmICghbm9kZSkgcmV0dXJuIHNlZ21lbnREYXRhO1xuXHRpZiAocGFyc2VQYXJhbXMgJiYgcm91dGUuY2hpbGRyZW4gJiYgIXJvdXRlLmlzUm9vdCAmJiByb3V0ZS5pZCAmJiByb3V0ZS5pZC5jaGFyQ29kZUF0KHJvdXRlLmlkLmxhc3RJbmRleE9mKFwiL1wiKSArIDEpID09PSA5NSkge1xuXHRcdGNvbnN0IHBhdGhsZXNzTm9kZSA9IGNyZWF0ZVNlZ21lbnROb2RlKG5vZGUsIFNFR01FTlRfVFlQRV9QQVRITEVTUyk7XG5cdFx0KG5vZGUucGF0aGxlc3MgPz89IFtdKS5wdXNoKHBhdGhsZXNzTm9kZSk7XG5cdFx0bm9kZSA9IHBhdGhsZXNzTm9kZTtcblx0fVxuXHRjb25zdCBpc0xlYWYgPSAocm91dGUucGF0aCB8fCAhcm91dGUuY2hpbGRyZW4pICYmICFyb3V0ZS5pc1Jvb3Q7XG5cdGlmIChpc0xlYWYgJiYgbGl0ZXJhbEVuZCA8IGxlbmd0aCkge1xuXHRcdGNvbnN0IGluZGV4Tm9kZSA9IGNyZWF0ZVNlZ21lbnROb2RlKG5vZGUsIFNFR01FTlRfVFlQRV9JTkRFWCk7XG5cdFx0bm9kZS5pbmRleCA9IGluZGV4Tm9kZTtcblx0XHRub2RlID0gaW5kZXhOb2RlO1xuXHR9XG5cdG5vZGUucGFyc2UgPSBwYXJzZVBhcmFtcyA/PyBudWxsO1xuXHRub2RlLnByaW9yaXR5ID0gb3B0aW9ucz8ucGFyYW1zPy5wcmlvcml0eSA/PyAwO1xuXHRpZiAoIW5vZGUucm91dGUpIHtcblx0XHRub2RlLmRhdGEgPSBzZWdtZW50RGF0YTtcblx0XHRpZiAoaXNMZWFmKSBub2RlLnJvdXRlID0gcm91dGU7XG5cdH1cblx0cmV0dXJuIFtcblx0XHRub2RlLFxuXHRcdGN1cnNvcixcblx0XHRzZWdtZW50RGF0YVxuXHRdO1xufVxuZnVuY3Rpb24gc29ydER5bmFtaWMoYSwgYikge1xuXHRpZiAoYS5wYXJzZSAmJiAhYi5wYXJzZSkgcmV0dXJuIC0xO1xuXHRpZiAoIWEucGFyc2UgJiYgYi5wYXJzZSkgcmV0dXJuIDE7XG5cdGlmIChhLnBhcnNlICYmIGIucGFyc2UgJiYgKGEucHJpb3JpdHkgfHwgYi5wcmlvcml0eSkpIHJldHVybiBiLnByaW9yaXR5IC0gYS5wcmlvcml0eTtcblx0aWYgKGEucHJlZml4ICYmIGIucHJlZml4ICYmIGEucHJlZml4ICE9PSBiLnByZWZpeCkge1xuXHRcdGlmIChhLnByZWZpeC5zdGFydHNXaXRoKGIucHJlZml4KSkgcmV0dXJuIC0xO1xuXHRcdGlmIChiLnByZWZpeC5zdGFydHNXaXRoKGEucHJlZml4KSkgcmV0dXJuIDE7XG5cdH1cblx0aWYgKGEuc3VmZml4ICYmIGIuc3VmZml4ICYmIGEuc3VmZml4ICE9PSBiLnN1ZmZpeCkge1xuXHRcdGlmIChhLnN1ZmZpeC5lbmRzV2l0aChiLnN1ZmZpeCkpIHJldHVybiAtMTtcblx0XHRpZiAoYi5zdWZmaXguZW5kc1dpdGgoYS5zdWZmaXgpKSByZXR1cm4gMTtcblx0fVxuXHRpZiAoYS5wcmVmaXggJiYgIWIucHJlZml4KSByZXR1cm4gLTE7XG5cdGlmICghYS5wcmVmaXggJiYgYi5wcmVmaXgpIHJldHVybiAxO1xuXHRpZiAoYS5zdWZmaXggJiYgIWIuc3VmZml4KSByZXR1cm4gLTE7XG5cdGlmICghYS5zdWZmaXggJiYgYi5zdWZmaXgpIHJldHVybiAxO1xuXHRpZiAoYS5jYXNlU2Vuc2l0aXZlICYmICFiLmNhc2VTZW5zaXRpdmUpIHJldHVybiAtMTtcblx0aWYgKCFhLmNhc2VTZW5zaXRpdmUgJiYgYi5jYXNlU2Vuc2l0aXZlKSByZXR1cm4gMTtcblx0cmV0dXJuIDA7XG59XG5mdW5jdGlvbiBjcmVhdGVTZWdtZW50Tm9kZShwYXJlbnQsIGtpbmQgPSAwLCBjYXNlU2Vuc2l0aXZlLCBwcmVmaXgsIHN1ZmZpeCkge1xuXHRyZXR1cm4ge1xuXHRcdGtpbmQsXG5cdFx0ZGVwdGg6IHBhcmVudCA/IHBhcmVudC5kZXB0aCArIDEgOiAwLFxuXHRcdHBhdGhsZXNzOiBudWxsLFxuXHRcdGluZGV4OiBudWxsLFxuXHRcdHN0YXRpYzogbnVsbCxcblx0XHRzdGF0aWNJbnNlbnNpdGl2ZTogbnVsbCxcblx0XHRkeW5hbWljOiBudWxsLFxuXHRcdG9wdGlvbmFsOiBudWxsLFxuXHRcdHdpbGRjYXJkOiBudWxsLFxuXHRcdHJvdXRlOiBudWxsLFxuXHRcdGRhdGE6IHZvaWQgMCxcblx0XHRwYXJlbnQsXG5cdFx0cGFyc2U6IG51bGwsXG5cdFx0cHJpb3JpdHk6IDAsXG5cdFx0Y2FzZVNlbnNpdGl2ZSxcblx0XHRwcmVmaXgsXG5cdFx0c3VmZml4XG5cdH07XG59XG5mdW5jdGlvbiBwcm9jZXNzUm91dGVNYXNrcyhyb3V0ZUxpc3QsIHByb2Nlc3NlZFRyZWUpIHtcblx0Y29uc3Qgc2VnbWVudFRyZWUgPSBjcmVhdGVTZWdtZW50Tm9kZSgpO1xuXHRjb25zdCBkeW5hbWljTGlzdHNUb1NvcnQgPSBbXTtcblx0ZnVuY3Rpb24gdmlzaXQocm91dGUsIHN0YXJ0LCBwYXJlbnROb2RlLCBwYXJlbnRJbnRlcnBvbGF0aW9uKSB7XG5cdFx0Y29uc3QgW25vZGUsIGN1cnNvciwgc2VnbWVudHNdID0gcGFyc2VTZWdtZW50cyhmYWxzZSwgcm91dGUsIHN0YXJ0LCBwYXJlbnROb2RlLCBkeW5hbWljTGlzdHNUb1NvcnQsIHBhcmVudEludGVycG9sYXRpb24pO1xuXHRcdGlmIChyb3V0ZS5jaGlsZHJlbikgZm9yIChjb25zdCBjaGlsZCBvZiByb3V0ZS5jaGlsZHJlbikgdmlzaXQoY2hpbGQsIGN1cnNvciwgbm9kZSwgc2VnbWVudHMpO1xuXHR9XG5cdGZvciAoY29uc3Qgcm91dGUgb2Ygcm91dGVMaXN0KSB2aXNpdChyb3V0ZSwgMSwgc2VnbWVudFRyZWUpO1xuXHRmb3IgKGNvbnN0IG5vZGVzIG9mIGR5bmFtaWNMaXN0c1RvU29ydCkgbm9kZXMuc29ydChzb3J0RHluYW1pYyk7XG5cdHByb2Nlc3NlZFRyZWUubWFza3NUcmVlID0gc2VnbWVudFRyZWU7XG5cdHByb2Nlc3NlZFRyZWUuZmxhdENhY2hlID0gY3JlYXRlU2lldmVDYWNoZSgxZTMpO1xufVxuLyoqXG4qIFRha2UgYW4gYXJiaXRyYXJ5IGxpc3Qgb2Ygcm91dGVzLCBjcmVhdGUgYSB0cmVlIGZyb20gdGhlbSAoaWYgaXQgaGFzbid0IGJlZW4gY3JlYXRlZCBhbHJlYWR5KSwgYW5kIG1hdGNoIGEgcGF0aCBhZ2FpbnN0IGl0LlxuKi9cbmZ1bmN0aW9uIGZpbmRGbGF0TWF0Y2gocGF0aCwgcHJvY2Vzc2VkVHJlZSkge1xuXHRwYXRoIHx8PSBcIi9cIjtcblx0Y29uc3QgY2FjaGVkID0gcHJvY2Vzc2VkVHJlZS5mbGF0Q2FjaGUuZ2V0KHBhdGgpO1xuXHRpZiAoY2FjaGVkICE9PSB2b2lkIDApIHJldHVybiBjYWNoZWQ7XG5cdGNvbnN0IHJlc3VsdCA9IGZpbmRNYXRjaChwYXRoLCBwcm9jZXNzZWRUcmVlLm1hc2tzVHJlZSk7XG5cdHByb2Nlc3NlZFRyZWUuZmxhdENhY2hlLnNldChwYXRoLCByZXN1bHQpO1xuXHRyZXR1cm4gcmVzdWx0O1xufVxuLyoqXG4qIEBkZXByZWNhdGVkIGtlZXAgdW50aWwgdjIgc28gdGhhdCBgcm91dGVyLm1hdGNoUm91dGVgIGNhbiBrZWVwIG5vdCBjYXJpbmcgYWJvdXQgdGhlIGFjdHVhbCByb3V0ZSB0cmVlXG4qL1xuZnVuY3Rpb24gZmluZFNpbmdsZU1hdGNoKGZyb20sIGNhc2VTZW5zaXRpdmUsIGZ1enp5LCBwYXRoLCBwcm9jZXNzZWRUcmVlKSB7XG5cdGZyb20gfHw9IFwiL1wiO1xuXHRwYXRoIHx8PSBcIi9cIjtcblx0Y29uc3Qga2V5ID0gY2FzZVNlbnNpdGl2ZSA/IGBjYXNlXFwwJHtmcm9tfWAgOiBmcm9tO1xuXHRsZXQgdHJlZSA9IHByb2Nlc3NlZFRyZWUuc2luZ2xlQ2FjaGUuZ2V0KGtleSk7XG5cdGlmICghdHJlZSkge1xuXHRcdHRyZWUgPSBjcmVhdGVTZWdtZW50Tm9kZSgpO1xuXHRcdHBhcnNlU2VnbWVudHMoY2FzZVNlbnNpdGl2ZSwgeyBmcm9tIH0sIDEsIHRyZWUpO1xuXHRcdHByb2Nlc3NlZFRyZWUuc2luZ2xlQ2FjaGUuc2V0KGtleSwgdHJlZSk7XG5cdH1cblx0cmV0dXJuIGZpbmRNYXRjaChwYXRoLCB0cmVlLCBmdXp6eSk7XG59XG5mdW5jdGlvbiBmaW5kUm91dGVNYXRjaChwYXRoLCBwcm9jZXNzZWRUcmVlLCBmdXp6eSA9IGZhbHNlKSB7XG5cdGNvbnN0IGtleSA9IGZ1enp5ID8gcGF0aCA6IGBub2Z1enpcXDAke3BhdGh9YDtcblx0Y29uc3QgY2FjaGVkID0gcHJvY2Vzc2VkVHJlZS5tYXRjaENhY2hlLmdldChrZXkpO1xuXHRpZiAoY2FjaGVkICE9PSB2b2lkIDApIHJldHVybiBjYWNoZWQ7XG5cdHBhdGggfHw9IFwiL1wiO1xuXHRsZXQgcmVzdWx0O1xuXHR0cnkge1xuXHRcdHJlc3VsdCA9IGZpbmRNYXRjaChwYXRoLCBwcm9jZXNzZWRUcmVlLnNlZ21lbnRUcmVlLCBmdXp6eSk7XG5cdH0gY2F0Y2ggKGVycikge1xuXHRcdGlmIChlcnIgaW5zdGFuY2VvZiBVUklFcnJvcikgcmVzdWx0ID0gbnVsbDtcblx0XHRlbHNlIHRocm93IGVycjtcblx0fVxuXHRpZiAocmVzdWx0KSByZXN1bHQuYnJhbmNoID0gYnVpbGRSb3V0ZUJyYW5jaChyZXN1bHQucm91dGUpO1xuXHRwcm9jZXNzZWRUcmVlLm1hdGNoQ2FjaGUuc2V0KGtleSwgcmVzdWx0KTtcblx0cmV0dXJuIHJlc3VsdDtcbn1cbi8qKlxuKiBQcm9jZXNzZXMgYSByb3V0ZSB0cmVlIGludG8gYSBzZWdtZW50IHRyaWUgZm9yIGVmZmljaWVudCBwYXRoIG1hdGNoaW5nLlxuKiBBbHNvIGJ1aWxkcyBsb29rdXAgbWFwcyBmb3Igcm91dGVzIGJ5IElEIGFuZCBieSB0cmltbWVkIGZ1bGwgcGF0aC5cbiovXG5mdW5jdGlvbiBwcm9jZXNzUm91dGVUcmVlKHJvdXRlVHJlZSwgY2FzZVNlbnNpdGl2ZSA9IGZhbHNlKSB7XG5cdGNvbnN0IHNlZ21lbnRUcmVlID0gY3JlYXRlU2VnbWVudE5vZGUoKTtcblx0Y29uc3QgZHluYW1pY0xpc3RzVG9Tb3J0ID0gW107XG5cdGNvbnN0IHJvdXRlc0J5SWQgPSB7fTtcblx0Y29uc3Qgcm91dGVzQnlQYXRoID0ge307XG5cdGxldCBpbmRleCA9IDA7XG5cdGZ1bmN0aW9uIHZpc2l0KHJvdXRlLCBzdGFydCwgcGFyZW50Tm9kZSwgcGFyZW50SW50ZXJwb2xhdGlvbikge1xuXHRcdHJvdXRlLmluaXQoaW5kZXgpO1xuXHRcdGlmIChyb3V0ZS5pZCBpbiByb3V0ZXNCeUlkKSB7XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0aHJvdyBuZXcgRXJyb3IoYEludmFyaWFudCBmYWlsZWQ6IER1cGxpY2F0ZSByb3V0ZXMgZm91bmQgd2l0aCBpZDogJHtTdHJpbmcocm91dGUuaWQpfWApO1xuXHRcdFx0aW52YXJpYW50KCk7XG5cdFx0fVxuXHRcdHJvdXRlc0J5SWRbcm91dGUuaWRdID0gcm91dGU7XG5cdFx0aWYgKGluZGV4ICE9PSAwICYmIHJvdXRlLnBhdGgpIHtcblx0XHRcdGNvbnN0IHRyaW1tZWRGdWxsUGF0aCA9IHRyaW1QYXRoUmlnaHQocm91dGUuZnVsbFBhdGgpO1xuXHRcdFx0aWYgKCFyb3V0ZXNCeVBhdGhbdHJpbW1lZEZ1bGxQYXRoXSB8fCByb3V0ZS5mdWxsUGF0aC5lbmRzV2l0aChcIi9cIikpIHJvdXRlc0J5UGF0aFt0cmltbWVkRnVsbFBhdGhdID0gcm91dGU7XG5cdFx0fVxuXHRcdGluZGV4Kys7XG5cdFx0Y29uc3QgW25vZGUsIGN1cnNvciwgc2VnbWVudHNdID0gcGFyc2VTZWdtZW50cyhjYXNlU2Vuc2l0aXZlLCByb3V0ZSwgc3RhcnQsIHBhcmVudE5vZGUsIGR5bmFtaWNMaXN0c1RvU29ydCwgcGFyZW50SW50ZXJwb2xhdGlvbik7XG5cdFx0cm91dGUuX2ludGVycG9sYXRpb24gPSBzZWdtZW50cztcblx0XHRpZiAocm91dGUuY2hpbGRyZW4pIGZvciAoY29uc3QgY2hpbGQgb2Ygcm91dGUuY2hpbGRyZW4pIHZpc2l0KGNoaWxkLCBjdXJzb3IsIG5vZGUsIHNlZ21lbnRzKTtcblx0fVxuXHR2aXNpdChyb3V0ZVRyZWUsIDEsIHNlZ21lbnRUcmVlKTtcblx0Zm9yIChjb25zdCBub2RlcyBvZiBkeW5hbWljTGlzdHNUb1NvcnQpIG5vZGVzLnNvcnQoc29ydER5bmFtaWMpO1xuXHRyZXR1cm4ge1xuXHRcdHByb2Nlc3NlZFRyZWU6IHtcblx0XHRcdHNlZ21lbnRUcmVlLFxuXHRcdFx0c2luZ2xlQ2FjaGU6IGNyZWF0ZVNpZXZlQ2FjaGUoMWUzKSxcblx0XHRcdG1hdGNoQ2FjaGU6IGNyZWF0ZVNpZXZlQ2FjaGUoMWUzKSxcblx0XHRcdGZsYXRDYWNoZTogbnVsbCxcblx0XHRcdG1hc2tzVHJlZTogbnVsbFxuXHRcdH0sXG5cdFx0cm91dGVzQnlJZCxcblx0XHRyb3V0ZXNCeVBhdGhcblx0fTtcbn1cbmZ1bmN0aW9uIGZpbmRNYXRjaChwYXRoLCBzZWdtZW50VHJlZSwgZnV6enkgPSBmYWxzZSkge1xuXHRjb25zdCBwYXJ0cyA9IHBhdGguc3BsaXQoXCIvXCIpO1xuXHRjb25zdCBsZWFmID0gZ2V0Tm9kZU1hdGNoKHBhdGgsIHBhcnRzLCBzZWdtZW50VHJlZSwgZnV6enkpO1xuXHRpZiAoIWxlYWYpIHJldHVybiBudWxsO1xuXHRjb25zdCBbcmF3UGFyYW1zXSA9IGV4dHJhY3RQYXJhbXMocGF0aCwgcGFydHMsIGxlYWYpO1xuXHRyZXR1cm4ge1xuXHRcdHJvdXRlOiBsZWFmLm5vZGUucm91dGUsXG5cdFx0cmF3UGFyYW1zXG5cdH07XG59XG4vKipcbiogVGhpcyBmdW5jdGlvbiBpcyBcInJlc3VtYWJsZVwiOlxuKiAtIHRoZSBgbGVhZmAgaW5wdXQgY2FuIGNvbnRhaW4gYGV4dHJhY3RgIGFuZCBgcmF3UGFyYW1zYCBwcm9wZXJ0aWVzIGZyb20gYSBwcmV2aW91cyBgZXh0cmFjdFBhcmFtc2AgY2FsbFxuKiAtIHRoZSByZXR1cm5lZCBgc3RhdGVgIGNhbiBiZSBwYXNzZWQgYmFjayBhcyBgZXh0cmFjdGAgaW4gYSBmdXR1cmUgY2FsbCB0byBjb250aW51ZSBleHRyYWN0aW5nIHBhcmFtcyBmcm9tIHdoZXJlIHdlIGxlZnQgb2ZmXG4qXG4qIElucHV0cyBhcmUgKm5vdCogbXV0YXRlZC5cbiovXG5mdW5jdGlvbiBleHRyYWN0UGFyYW1zKHBhdGgsIHBhcnRzLCBsZWFmKSB7XG5cdGNvbnN0IGxpc3QgPSBidWlsZEJyYW5jaChsZWFmLm5vZGUpO1xuXHRjb25zdCBuYW1lcyA9IGxlYWYubm9kZS5kYXRhICYmIGdldFBhcmFtTmFtZXMobGVhZi5ub2RlLmRhdGEpO1xuXHRjb25zdCByYXdQYXJhbXMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXHQvKiogd2hpY2ggc2VnbWVudCBvZiB0aGUgcGF0aCB3ZSdyZSBjdXJyZW50bHkgcHJvY2Vzc2luZyAqL1xuXHRsZXQgcGFydEluZGV4ID0gbGVhZi5leHRyYWN0Py5wYXJ0ID8/IDA7XG5cdC8qKiB3aGljaCBub2RlIG9mIHRoZSByb3V0ZSB0cmVlIGJyYW5jaCB3ZSdyZSBjdXJyZW50bHkgcHJvY2Vzc2luZyAqL1xuXHRsZXQgbm9kZUluZGV4ID0gbGVhZi5leHRyYWN0Py5ub2RlID8/IDA7XG5cdC8qKiBpbmRleCBvZiB0aGUgMXN0IGNoYXJhY3RlciBvZiB0aGUgc2VnbWVudCB3ZSdyZSBwcm9jZXNzaW5nIGluIHRoZSBwYXRoIHN0cmluZyAqL1xuXHRsZXQgcGF0aEluZGV4ID0gbGVhZi5leHRyYWN0Py5wYXRoID8/IDA7XG5cdC8qKiBOZXh0IG9yaWdpbmFsIHBhcmFtZXRlciBuYW1lLCBpbmRlcGVuZGVudCBvZiBwYXRobGVzcy9zdGF0aWMgbm9kZXMuICovXG5cdGxldCBwYXJhbUluZGV4ID0gbGVhZi5leHRyYWN0Py5wYXJhbSA/PyAwO1xuXHRmb3IgKDsgbm9kZUluZGV4IDwgbGlzdC5sZW5ndGg7IHBhcnRJbmRleCsrLCBub2RlSW5kZXgrKywgcGF0aEluZGV4KyspIHtcblx0XHRjb25zdCBub2RlID0gbGlzdFtub2RlSW5kZXhdO1xuXHRcdGlmIChub2RlLmtpbmQgPT09IFNFR01FTlRfVFlQRV9JTkRFWCkgYnJlYWs7XG5cdFx0aWYgKG5vZGUua2luZCA9PT0gU0VHTUVOVF9UWVBFX1BBVEhMRVNTKSB7XG5cdFx0XHRwYXJ0SW5kZXgtLTtcblx0XHRcdHBhdGhJbmRleC0tO1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdGNvbnN0IHBhcnQgPSBwYXJ0c1twYXJ0SW5kZXhdO1xuXHRcdGNvbnN0IGN1cnJlbnRQYXRoSW5kZXggPSBwYXRoSW5kZXg7XG5cdFx0aWYgKHBhcnQpIHBhdGhJbmRleCArPSBwYXJ0Lmxlbmd0aDtcblx0XHRpZiAobm9kZS5raW5kID09PSAxIHx8IG5vZGUua2luZCA9PT0gMykge1xuXHRcdFx0Y29uc3QgbmFtZSA9IG5hbWVzW3BhcmFtSW5kZXgrK107XG5cdFx0XHRpZiAobm9kZS5raW5kID09PSAzICYmIGxlYWYuc2tpcHBlZCAmIDEgPDwgbm9kZUluZGV4KSB7XG5cdFx0XHRcdHBhcnRJbmRleC0tO1xuXHRcdFx0XHRwYXRoSW5kZXggPSBjdXJyZW50UGF0aEluZGV4IC0gMTtcblx0XHRcdFx0Y29udGludWU7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCB2YWx1ZSA9IG5vZGUuc3VmZml4IHx8IG5vZGUucHJlZml4ID8gcGFydC5zdWJzdHJpbmcobm9kZS5wcmVmaXgubGVuZ3RoLCBwYXJ0Lmxlbmd0aCAtIG5vZGUuc3VmZml4Lmxlbmd0aCkgOiBwYXJ0O1xuXHRcdFx0aWYgKHZhbHVlIHx8IG5vZGUua2luZCA9PT0gMSkgcmF3UGFyYW1zW25hbWVdID0gZGVjb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcblx0XHR9IGVsc2UgaWYgKG5vZGUua2luZCA9PT0gMikge1xuXHRcdFx0Y29uc3QgbiA9IG5vZGU7XG5cdFx0XHRjb25zdCB2YWx1ZSA9IHBhdGguc3Vic3RyaW5nKGN1cnJlbnRQYXRoSW5kZXggKyBuLnByZWZpeC5sZW5ndGgsIHBhdGgubGVuZ3RoIC0gbi5zdWZmaXgubGVuZ3RoKTtcblx0XHRcdGNvbnN0IHNwbGF0ID0gZGVjb2RlVVJJQ29tcG9uZW50KHZhbHVlKTtcblx0XHRcdHJhd1BhcmFtc1tcIipcIl0gPSBzcGxhdDtcblx0XHRcdHJhd1BhcmFtcy5fc3BsYXQgPSBzcGxhdDtcblx0XHRcdGJyZWFrO1xuXHRcdH1cblx0fVxuXHRpZiAobGVhZi5yYXdQYXJhbXMpIE9iamVjdC5hc3NpZ24ocmF3UGFyYW1zLCBsZWFmLnJhd1BhcmFtcyk7XG5cdHJldHVybiBbcmF3UGFyYW1zLCB7XG5cdFx0cGFydDogcGFydEluZGV4LFxuXHRcdG5vZGU6IG5vZGVJbmRleCxcblx0XHRwYXRoOiBwYXRoSW5kZXgsXG5cdFx0cGFyYW06IHBhcmFtSW5kZXhcblx0fV07XG59XG5mdW5jdGlvbiBidWlsZFJvdXRlQnJhbmNoKHJvdXRlKSB7XG5cdGNvbnN0IGxpc3QgPSBbcm91dGVdO1xuXHR3aGlsZSAocm91dGUucGFyZW50Um91dGUpIHtcblx0XHRyb3V0ZSA9IHJvdXRlLnBhcmVudFJvdXRlO1xuXHRcdGxpc3QucHVzaChyb3V0ZSk7XG5cdH1cblx0bGlzdC5yZXZlcnNlKCk7XG5cdHJldHVybiBsaXN0O1xufVxuZnVuY3Rpb24gYnVpbGRCcmFuY2gobm9kZSkge1xuXHRjb25zdCBsaXN0ID0gQXJyYXkobm9kZS5kZXB0aCArIDEpO1xuXHRkbyB7XG5cdFx0bGlzdFtub2RlLmRlcHRoXSA9IG5vZGU7XG5cdFx0bm9kZSA9IG5vZGUucGFyZW50O1xuXHR9IHdoaWxlIChub2RlKTtcblx0cmV0dXJuIGxpc3Q7XG59XG5mdW5jdGlvbiBnZXROb2RlTWF0Y2gocGF0aCwgcGFydHMsIHNlZ21lbnRUcmVlLCBmdXp6eSkge1xuXHRpZiAocGF0aCA9PT0gXCIvXCIgJiYgc2VnbWVudFRyZWUuaW5kZXgpIHJldHVybiB7XG5cdFx0bm9kZTogc2VnbWVudFRyZWUuaW5kZXgsXG5cdFx0c2tpcHBlZDogMFxuXHR9O1xuXHRjb25zdCB0cmFpbGluZ1NsYXNoID0gIWxhc3QocGFydHMpO1xuXHRjb25zdCBwYXRoSXNJbmRleCA9IHRyYWlsaW5nU2xhc2ggJiYgcGF0aCAhPT0gXCIvXCI7XG5cdGNvbnN0IHBhcnRzTGVuZ3RoID0gcGFydHMubGVuZ3RoIC0gKHRyYWlsaW5nU2xhc2ggPyAxIDogMCk7XG5cdGNvbnN0IHN0YWNrID0gW3tcblx0XHRub2RlOiBzZWdtZW50VHJlZSxcblx0XHRpbmRleDogMSxcblx0XHRza2lwcGVkOiAwLFxuXHRcdHN0YXRpY3M6IDAsXG5cdFx0ZHluYW1pY3M6IDAsXG5cdFx0b3B0aW9uYWxzOiAwXG5cdH1dO1xuXHRsZXQgYmVzdEZ1enp5ID0gbnVsbDtcblx0bGV0IGJlc3RNYXRjaCA9IG51bGw7XG5cdHdoaWxlIChzdGFjay5sZW5ndGgpIHtcblx0XHRjb25zdCBmcmFtZSA9IHN0YWNrLnBvcCgpO1xuXHRcdGNvbnN0IHsgbm9kZSwgaW5kZXgsIHNraXBwZWQsIHN0YXRpY3MsIGR5bmFtaWNzLCBvcHRpb25hbHMgfSA9IGZyYW1lO1xuXHRcdGxldCB7IGV4dHJhY3QsIHJhd1BhcmFtcyB9ID0gZnJhbWU7XG5cdFx0aWYgKG5vZGUua2luZCA9PT0gMiAmJiBub2RlLnJvdXRlICYmICFpc0ZyYW1lTW9yZVNwZWNpZmljKGJlc3RNYXRjaCwgZnJhbWUpKSBjb250aW51ZTtcblx0XHRpZiAobm9kZS5wYXJzZSkge1xuXHRcdFx0aWYgKCF2YWxpZGF0ZVBhcnNlUGFyYW1zKHBhdGgsIHBhcnRzLCBmcmFtZSkpIGNvbnRpbnVlO1xuXHRcdFx0cmF3UGFyYW1zID0gZnJhbWUucmF3UGFyYW1zO1xuXHRcdFx0ZXh0cmFjdCA9IGZyYW1lLmV4dHJhY3Q7XG5cdFx0fVxuXHRcdGlmIChmdXp6eSAmJiBub2RlLnJvdXRlICYmIG5vZGUua2luZCAhPT0gU0VHTUVOVF9UWVBFX0lOREVYICYmIGlzRnJhbWVNb3JlU3BlY2lmaWMoYmVzdEZ1enp5LCBmcmFtZSkpIGJlc3RGdXp6eSA9IGZyYW1lO1xuXHRcdGNvbnN0IGlzQmV5b25kUGF0aCA9IGluZGV4ID09PSBwYXJ0c0xlbmd0aDtcblx0XHRpZiAoaXNCZXlvbmRQYXRoKSB7XG5cdFx0XHRpZiAobm9kZS5yb3V0ZSAmJiAoIXBhdGhJc0luZGV4IHx8IG5vZGUua2luZCA9PT0gU0VHTUVOVF9UWVBFX0lOREVYIHx8IG5vZGUua2luZCA9PT0gMikgJiYgaXNGcmFtZU1vcmVTcGVjaWZpYyhiZXN0TWF0Y2gsIGZyYW1lKSkgYmVzdE1hdGNoID0gZnJhbWU7XG5cdFx0XHRpZiAoIW5vZGUub3B0aW9uYWwgJiYgIW5vZGUud2lsZGNhcmQgJiYgIW5vZGUuaW5kZXggJiYgIW5vZGUucGF0aGxlc3MpIGNvbnRpbnVlO1xuXHRcdH1cblx0XHRjb25zdCBwYXJ0ID0gaXNCZXlvbmRQYXRoID8gdm9pZCAwIDogcGFydHNbaW5kZXhdO1xuXHRcdGxldCBsb3dlclBhcnQ7XG5cdFx0aWYgKGlzQmV5b25kUGF0aCAmJiBub2RlLmluZGV4KSB7XG5cdFx0XHRjb25zdCBpbmRleEZyYW1lID0ge1xuXHRcdFx0XHRub2RlOiBub2RlLmluZGV4LFxuXHRcdFx0XHRpbmRleCxcblx0XHRcdFx0c2tpcHBlZCxcblx0XHRcdFx0c3RhdGljcyxcblx0XHRcdFx0ZHluYW1pY3MsXG5cdFx0XHRcdG9wdGlvbmFscyxcblx0XHRcdFx0ZXh0cmFjdCxcblx0XHRcdFx0cmF3UGFyYW1zXG5cdFx0XHR9O1xuXHRcdFx0bGV0IGluZGV4VmFsaWQgPSB0cnVlO1xuXHRcdFx0aWYgKG5vZGUuaW5kZXgucGFyc2UpIHtcblx0XHRcdFx0aWYgKCF2YWxpZGF0ZVBhcnNlUGFyYW1zKHBhdGgsIHBhcnRzLCBpbmRleEZyYW1lKSkgaW5kZXhWYWxpZCA9IGZhbHNlO1xuXHRcdFx0fVxuXHRcdFx0aWYgKGluZGV4VmFsaWQpIHtcblx0XHRcdFx0aWYgKCFkeW5hbWljcyAmJiAhb3B0aW9uYWxzICYmICFza2lwcGVkICYmIGlzUGVyZmVjdFN0YXRpY01hdGNoKHN0YXRpY3MsIHBhcnRzTGVuZ3RoKSkgcmV0dXJuIGluZGV4RnJhbWU7XG5cdFx0XHRcdGlmIChpc0ZyYW1lTW9yZVNwZWNpZmljKGJlc3RNYXRjaCwgaW5kZXhGcmFtZSkpIGJlc3RNYXRjaCA9IGluZGV4RnJhbWU7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmIChub2RlLndpbGRjYXJkKSBmb3IgKGxldCBpID0gbm9kZS53aWxkY2FyZC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdFx0Y29uc3Qgc2VnbWVudCA9IG5vZGUud2lsZGNhcmRbaV07XG5cdFx0XHRjb25zdCB7IHByZWZpeCwgc3VmZml4IH0gPSBzZWdtZW50O1xuXHRcdFx0aWYgKHByZWZpeCkge1xuXHRcdFx0XHRpZiAoaXNCZXlvbmRQYXRoKSBjb250aW51ZTtcblx0XHRcdFx0aWYgKCEoc2VnbWVudC5jYXNlU2Vuc2l0aXZlID8gcGFydCA6IGxvd2VyUGFydCA/Pz0gcGFydC50b0xvd2VyQ2FzZSgpKS5zdGFydHNXaXRoKHByZWZpeCkpIGNvbnRpbnVlO1xuXHRcdFx0fVxuXHRcdFx0aWYgKHN1ZmZpeCkge1xuXHRcdFx0XHRpZiAoaXNCZXlvbmRQYXRoKSBjb250aW51ZTtcblx0XHRcdFx0Y29uc3QgZW5kID0gcGFydHMuc2xpY2UoaW5kZXgpLmpvaW4oXCIvXCIpO1xuXHRcdFx0XHRjb25zdCBzdWZmaXhQYXJ0ID0gZW5kLnNsaWNlKC1zdWZmaXgubGVuZ3RoKTtcblx0XHRcdFx0aWYgKChzZWdtZW50LmNhc2VTZW5zaXRpdmUgPyBzdWZmaXhQYXJ0IDogc3VmZml4UGFydC50b0xvd2VyQ2FzZSgpKSAhPT0gc3VmZml4IHx8IGVuZC5sZW5ndGggLSBzdWZmaXgubGVuZ3RoIDwgcHJlZml4Lmxlbmd0aCkgY29udGludWU7XG5cdFx0XHR9XG5cdFx0XHRzdGFjay5wdXNoKHtcblx0XHRcdFx0bm9kZTogc2VnbWVudCxcblx0XHRcdFx0aW5kZXg6IHBhcnRzTGVuZ3RoLFxuXHRcdFx0XHRza2lwcGVkLFxuXHRcdFx0XHRzdGF0aWNzLFxuXHRcdFx0XHRkeW5hbWljcyxcblx0XHRcdFx0b3B0aW9uYWxzLFxuXHRcdFx0XHRleHRyYWN0LFxuXHRcdFx0XHRyYXdQYXJhbXNcblx0XHRcdH0pO1xuXHRcdH1cblx0XHRpZiAobm9kZS5vcHRpb25hbCkge1xuXHRcdFx0Y29uc3QgbmV4dFNraXBwZWQgPSBza2lwcGVkIHwgMSA8PCBub2RlLmRlcHRoICsgMTtcblx0XHRcdGZvciAobGV0IGkgPSBub2RlLm9wdGlvbmFsLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0XHRcdGNvbnN0IHNlZ21lbnQgPSBub2RlLm9wdGlvbmFsW2ldO1xuXHRcdFx0XHRzdGFjay5wdXNoKHtcblx0XHRcdFx0XHRub2RlOiBzZWdtZW50LFxuXHRcdFx0XHRcdGluZGV4LFxuXHRcdFx0XHRcdHNraXBwZWQ6IG5leHRTa2lwcGVkLFxuXHRcdFx0XHRcdHN0YXRpY3MsXG5cdFx0XHRcdFx0ZHluYW1pY3MsXG5cdFx0XHRcdFx0b3B0aW9uYWxzLFxuXHRcdFx0XHRcdGV4dHJhY3QsXG5cdFx0XHRcdFx0cmF3UGFyYW1zXG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdFx0aWYgKCFpc0JleW9uZFBhdGgpIGZvciAobGV0IGkgPSBub2RlLm9wdGlvbmFsLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0XHRcdGNvbnN0IHNlZ21lbnQgPSBub2RlLm9wdGlvbmFsW2ldO1xuXHRcdFx0XHRjb25zdCB7IHByZWZpeCwgc3VmZml4IH0gPSBzZWdtZW50O1xuXHRcdFx0XHRpZiAocHJlZml4IHx8IHN1ZmZpeCkge1xuXHRcdFx0XHRcdGNvbnN0IGNhc2VQYXJ0ID0gc2VnbWVudC5jYXNlU2Vuc2l0aXZlID8gcGFydCA6IGxvd2VyUGFydCA/Pz0gcGFydC50b0xvd2VyQ2FzZSgpO1xuXHRcdFx0XHRcdGlmIChwcmVmaXggJiYgIWNhc2VQYXJ0LnN0YXJ0c1dpdGgocHJlZml4KSkgY29udGludWU7XG5cdFx0XHRcdFx0aWYgKHN1ZmZpeCAmJiBjYXNlUGFydC5pbmRleE9mKHN1ZmZpeCwgY2FzZVBhcnQubGVuZ3RoIC0gc3VmZml4Lmxlbmd0aCkgPCBwcmVmaXgubGVuZ3RoKSBjb250aW51ZTtcblx0XHRcdFx0fVxuXHRcdFx0XHRzdGFjay5wdXNoKHtcblx0XHRcdFx0XHRub2RlOiBzZWdtZW50LFxuXHRcdFx0XHRcdGluZGV4OiBpbmRleCArIDEsXG5cdFx0XHRcdFx0c2tpcHBlZCxcblx0XHRcdFx0XHRzdGF0aWNzLFxuXHRcdFx0XHRcdGR5bmFtaWNzLFxuXHRcdFx0XHRcdG9wdGlvbmFsczogb3B0aW9uYWxzICsgc2VnbWVudFNjb3JlKHBhcnRzTGVuZ3RoLCBpbmRleCksXG5cdFx0XHRcdFx0ZXh0cmFjdCxcblx0XHRcdFx0XHRyYXdQYXJhbXNcblx0XHRcdFx0fSk7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlmICghaXNCZXlvbmRQYXRoICYmIG5vZGUuZHluYW1pYyAmJiBwYXJ0KSBmb3IgKGxldCBpID0gbm9kZS5keW5hbWljLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0XHRjb25zdCBzZWdtZW50ID0gbm9kZS5keW5hbWljW2ldO1xuXHRcdFx0Y29uc3QgeyBwcmVmaXgsIHN1ZmZpeCB9ID0gc2VnbWVudDtcblx0XHRcdGlmIChwcmVmaXggfHwgc3VmZml4KSB7XG5cdFx0XHRcdGNvbnN0IGNhc2VQYXJ0ID0gc2VnbWVudC5jYXNlU2Vuc2l0aXZlID8gcGFydCA6IGxvd2VyUGFydCA/Pz0gcGFydC50b0xvd2VyQ2FzZSgpO1xuXHRcdFx0XHRpZiAocHJlZml4ICYmICFjYXNlUGFydC5zdGFydHNXaXRoKHByZWZpeCkpIGNvbnRpbnVlO1xuXHRcdFx0XHRpZiAoc3VmZml4ICYmIGNhc2VQYXJ0LmluZGV4T2Yoc3VmZml4LCBjYXNlUGFydC5sZW5ndGggLSBzdWZmaXgubGVuZ3RoKSA8IHByZWZpeC5sZW5ndGgpIGNvbnRpbnVlO1xuXHRcdFx0fVxuXHRcdFx0c3RhY2sucHVzaCh7XG5cdFx0XHRcdG5vZGU6IHNlZ21lbnQsXG5cdFx0XHRcdGluZGV4OiBpbmRleCArIDEsXG5cdFx0XHRcdHNraXBwZWQsXG5cdFx0XHRcdHN0YXRpY3MsXG5cdFx0XHRcdGR5bmFtaWNzOiBkeW5hbWljcyArIHNlZ21lbnRTY29yZShwYXJ0c0xlbmd0aCwgaW5kZXgpLFxuXHRcdFx0XHRvcHRpb25hbHMsXG5cdFx0XHRcdGV4dHJhY3QsXG5cdFx0XHRcdHJhd1BhcmFtc1xuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdGlmICghaXNCZXlvbmRQYXRoICYmIG5vZGUuc3RhdGljSW5zZW5zaXRpdmUpIHtcblx0XHRcdGNvbnN0IG1hdGNoID0gbm9kZS5zdGF0aWNJbnNlbnNpdGl2ZS5nZXQobG93ZXJQYXJ0ID8/PSBwYXJ0LnRvTG93ZXJDYXNlKCkpO1xuXHRcdFx0aWYgKG1hdGNoKSBzdGFjay5wdXNoKHtcblx0XHRcdFx0bm9kZTogbWF0Y2gsXG5cdFx0XHRcdGluZGV4OiBpbmRleCArIDEsXG5cdFx0XHRcdHNraXBwZWQsXG5cdFx0XHRcdHN0YXRpY3M6IHN0YXRpY3MgKyBzZWdtZW50U2NvcmUocGFydHNMZW5ndGgsIGluZGV4KSxcblx0XHRcdFx0ZHluYW1pY3MsXG5cdFx0XHRcdG9wdGlvbmFscyxcblx0XHRcdFx0ZXh0cmFjdCxcblx0XHRcdFx0cmF3UGFyYW1zXG5cdFx0XHR9KTtcblx0XHR9XG5cdFx0aWYgKCFpc0JleW9uZFBhdGggJiYgbm9kZS5zdGF0aWMpIHtcblx0XHRcdGNvbnN0IG1hdGNoID0gbm9kZS5zdGF0aWMuZ2V0KHBhcnQpO1xuXHRcdFx0aWYgKG1hdGNoKSBzdGFjay5wdXNoKHtcblx0XHRcdFx0bm9kZTogbWF0Y2gsXG5cdFx0XHRcdGluZGV4OiBpbmRleCArIDEsXG5cdFx0XHRcdHNraXBwZWQsXG5cdFx0XHRcdHN0YXRpY3M6IHN0YXRpY3MgKyBzZWdtZW50U2NvcmUocGFydHNMZW5ndGgsIGluZGV4KSxcblx0XHRcdFx0ZHluYW1pY3MsXG5cdFx0XHRcdG9wdGlvbmFscyxcblx0XHRcdFx0ZXh0cmFjdCxcblx0XHRcdFx0cmF3UGFyYW1zXG5cdFx0XHR9KTtcblx0XHR9XG5cdFx0aWYgKG5vZGUucGF0aGxlc3MpIGZvciAobGV0IGkgPSBub2RlLnBhdGhsZXNzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG5cdFx0XHRjb25zdCBzZWdtZW50ID0gbm9kZS5wYXRobGVzc1tpXTtcblx0XHRcdHN0YWNrLnB1c2goe1xuXHRcdFx0XHRub2RlOiBzZWdtZW50LFxuXHRcdFx0XHRpbmRleCxcblx0XHRcdFx0c2tpcHBlZCxcblx0XHRcdFx0c3RhdGljcyxcblx0XHRcdFx0ZHluYW1pY3MsXG5cdFx0XHRcdG9wdGlvbmFscyxcblx0XHRcdFx0ZXh0cmFjdCxcblx0XHRcdFx0cmF3UGFyYW1zXG5cdFx0XHR9KTtcblx0XHR9XG5cdH1cblx0aWYgKGJlc3RNYXRjaCkgcmV0dXJuIGJlc3RNYXRjaDtcblx0aWYgKGZ1enp5ICYmIGJlc3RGdXp6eSkge1xuXHRcdGxldCBzbGljZUluZGV4ID0gYmVzdEZ1enp5LmluZGV4O1xuXHRcdGZvciAobGV0IGkgPSAwOyBpIDwgYmVzdEZ1enp5LmluZGV4OyBpKyspIHNsaWNlSW5kZXggKz0gcGFydHNbaV0ubGVuZ3RoO1xuXHRcdGNvbnN0IHNwbGF0ID0gc2xpY2VJbmRleCA9PT0gcGF0aC5sZW5ndGggPyBcIi9cIiA6IHBhdGguc2xpY2Uoc2xpY2VJbmRleCk7XG5cdFx0YmVzdEZ1enp5LnJhd1BhcmFtcyA/Pz0gT2JqZWN0LmNyZWF0ZShudWxsKTtcblx0XHRiZXN0RnV6enkucmF3UGFyYW1zW1wiKipcIl0gPSBkZWNvZGVVUklDb21wb25lbnQoc3BsYXQpO1xuXHRcdHJldHVybiBiZXN0RnV6enk7XG5cdH1cblx0cmV0dXJuIG51bGw7XG59XG5mdW5jdGlvbiBzZWdtZW50U2NvcmUocGFydHNMZW5ndGgsIGluZGV4KSB7XG5cdHJldHVybiAyICoqIChwYXJ0c0xlbmd0aCAtIGluZGV4IC0gMSk7XG59XG5mdW5jdGlvbiBpc1BlcmZlY3RTdGF0aWNNYXRjaChzdGF0aWNzLCBwYXJ0c0xlbmd0aCkge1xuXHRyZXR1cm4gc3RhdGljcyA9PT0gMiAqKiAocGFydHNMZW5ndGggLSAxKSAtIDE7XG59XG5mdW5jdGlvbiB2YWxpZGF0ZVBhcnNlUGFyYW1zKHBhdGgsIHBhcnRzLCBmcmFtZSkge1xuXHRsZXQgcmF3UGFyYW1zO1xuXHRsZXQgc3RhdGU7XG5cdHRyeSB7XG5cdFx0W3Jhd1BhcmFtcywgc3RhdGVdID0gZXh0cmFjdFBhcmFtcyhwYXRoLCBwYXJ0cywgZnJhbWUpO1xuXHR9IGNhdGNoIHtcblx0XHRyZXR1cm4gbnVsbDtcblx0fVxuXHRmcmFtZS5yYXdQYXJhbXMgPSByYXdQYXJhbXM7XG5cdGZyYW1lLmV4dHJhY3QgPSBzdGF0ZTtcblx0aWYgKCFmcmFtZS5ub2RlLnBhcnNlKSByZXR1cm4gdHJ1ZTtcblx0dHJ5IHtcblx0XHRpZiAoZnJhbWUubm9kZS5wYXJzZShyYXdQYXJhbXMpID09PSBmYWxzZSkgcmV0dXJuIG51bGw7XG5cdH0gY2F0Y2gge31cblx0cmV0dXJuIHRydWU7XG59XG5mdW5jdGlvbiBpc0ZyYW1lTW9yZVNwZWNpZmljKHByZXYsIG5leHQpIHtcblx0aWYgKCFwcmV2KSByZXR1cm4gdHJ1ZTtcblx0cmV0dXJuIG5leHQuc3RhdGljcyA+IHByZXYuc3RhdGljcyB8fCBuZXh0LnN0YXRpY3MgPT09IHByZXYuc3RhdGljcyAmJiAobmV4dC5keW5hbWljcyA+IHByZXYuZHluYW1pY3MgfHwgbmV4dC5keW5hbWljcyA9PT0gcHJldi5keW5hbWljcyAmJiAobmV4dC5vcHRpb25hbHMgPiBwcmV2Lm9wdGlvbmFscyB8fCBuZXh0Lm9wdGlvbmFscyA9PT0gcHJldi5vcHRpb25hbHMgJiYgKChuZXh0Lm5vZGUua2luZCA9PT0gU0VHTUVOVF9UWVBFX0lOREVYKSA+IChwcmV2Lm5vZGUua2luZCA9PT0gU0VHTUVOVF9UWVBFX0lOREVYKSB8fCBuZXh0Lm5vZGUua2luZCA9PT0gU0VHTUVOVF9UWVBFX0lOREVYID09PSAocHJldi5ub2RlLmtpbmQgPT09IFNFR01FTlRfVFlQRV9JTkRFWCkgJiYgbmV4dC5ub2RlLmRlcHRoID4gcHJldi5ub2RlLmRlcHRoKSkpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBidWlsZFJvdXRlQnJhbmNoLCBmaW5kRmxhdE1hdGNoLCBmaW5kUm91dGVNYXRjaCwgZmluZFNpbmdsZU1hdGNoLCBnZXRQYXJhbU5hbWVzLCBwYXJzZVNlZ21lbnQsIHBhcnNlU2VnbWVudHMsIHByb2Nlc3NSb3V0ZU1hc2tzLCBwcm9jZXNzUm91dGVUcmVlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5ldy1wcm9jZXNzLXJvdXRlLXRyZWUuanMubWFwIiwiaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG4vLyNyZWdpb24gc3JjL3Njcm9sbC1yZXN0b3JhdGlvbi50c1xuZnVuY3Rpb24gZ2V0U2FmZVNlc3Npb25TdG9yYWdlKCkge1xuXHR0cnkge1xuXHRcdHJldHVybiBzZXNzaW9uU3RvcmFnZTtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuO1xuXHR9XG59XG5jb25zdCBzdG9yYWdlS2V5ID0gXCJ0c3Itc2Nyb2xsLXJlc3RvcmF0aW9uLXYxXzNcIjtcbmNvbnN0IHNhZmVTZXNzaW9uU3RvcmFnZSA9IGdldFNhZmVTZXNzaW9uU3RvcmFnZSgpO1xuZnVuY3Rpb24gY3JlYXRlU2Nyb2xsUmVzdG9yYXRpb25DYWNoZSgpIHtcblx0dHJ5IHtcblx0XHRyZXR1cm4gSlNPTi5wYXJzZShzYWZlU2Vzc2lvblN0b3JhZ2U/LmdldEl0ZW0oXCJ0c3Itc2Nyb2xsLXJlc3RvcmF0aW9uLXYxXzNcIikgfHwgXCJ7fVwiKTtcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuIHt9O1xuXHR9XG59XG5jb25zdCBzY3JvbGxSZXN0b3JhdGlvbkNhY2hlID0gLyogQF9fUFVSRV9fICovIGNyZWF0ZVNjcm9sbFJlc3RvcmF0aW9uQ2FjaGUoKTtcbmNvbnN0IHNjcm9sbFJlc3RvcmF0aW9uSWRBdHRyaWJ1dGUgPSBcImRhdGEtc2Nyb2xsLXJlc3RvcmF0aW9uLWlkXCI7XG4vKipcbiogVGhlIGRlZmF1bHQgYGdldEtleWAgZnVuY3Rpb24gZm9yIGB1c2VTY3JvbGxSZXN0b3JhdGlvbmAuXG4qIEl0IHJldHVybnMgdGhlIGBrZXlgIGZyb20gdGhlIGxvY2F0aW9uIHN0YXRlIG9yIHRoZSBgaHJlZmAgb2YgdGhlIGxvY2F0aW9uLlxuKlxuKiBUaGUgYGxvY2F0aW9uLmhyZWZgIGlzIHVzZWQgYXMgYSBmYWxsYmFjayB0byBzdXBwb3J0IHRoZSB1c2UgY2FzZSB3aGVyZSB0aGUgbG9jYXRpb24gc3RhdGUgaXMgbm90IGF2YWlsYWJsZSBsaWtlIHRoZSBpbml0aWFsIHJlbmRlci5cbiovXG5jb25zdCBkZWZhdWx0R2V0U2Nyb2xsUmVzdG9yYXRpb25LZXkgPSAobG9jYXRpb24pID0+IHtcblx0cmV0dXJuIGxvY2F0aW9uLnN0YXRlLl9fVFNSX2tleSB8fCBsb2NhdGlvbi5ocmVmO1xufTtcbmZ1bmN0aW9uIGdldFNjcm9sbFJlc3RvcmF0aW9uU2VsZWN0b3IoZWxlbWVudCkge1xuXHRjb25zdCBhdHRySWQgPSBlbGVtZW50LmdldEF0dHJpYnV0ZShzY3JvbGxSZXN0b3JhdGlvbklkQXR0cmlidXRlKTtcblx0aWYgKGF0dHJJZCkgcmV0dXJuIGBbJHtzY3JvbGxSZXN0b3JhdGlvbklkQXR0cmlidXRlfT1cIiR7YXR0cklkfVwiXWA7XG5cdGxldCBzZWxlY3RvciA9IFwiXCI7XG5cdGxldCBlbCA9IGVsZW1lbnQ7XG5cdGxldCBwYXJlbnQ7XG5cdHdoaWxlIChwYXJlbnQgPSBlbC5wYXJlbnROb2RlKSB7XG5cdFx0bGV0IGluZGV4ID0gMTtcblx0XHRsZXQgc2libGluZyA9IGVsO1xuXHRcdHdoaWxlIChzaWJsaW5nID0gc2libGluZy5wcmV2aW91c0VsZW1lbnRTaWJsaW5nKSBpbmRleCsrO1xuXHRcdGNvbnN0IHBhcnQgPSBgJHtlbC5sb2NhbE5hbWV9Om50aC1jaGlsZCgke2luZGV4fSlgO1xuXHRcdHNlbGVjdG9yID0gc2VsZWN0b3IgPyBgJHtwYXJ0fSA+ICR7c2VsZWN0b3J9YCA6IHBhcnQ7XG5cdFx0ZWwgPSBwYXJlbnQ7XG5cdH1cblx0cmV0dXJuIHNlbGVjdG9yO1xufVxuZnVuY3Rpb24gZ2V0RWxlbWVudFNjcm9sbFJlc3RvcmF0aW9uRW50cnkocm91dGVyLCBvcHRpb25zKSB7XG5cdGNvbnN0IHJlc3RvcmVLZXkgPSAob3B0aW9ucy5nZXRLZXkgfHwgZGVmYXVsdEdldFNjcm9sbFJlc3RvcmF0aW9uS2V5KShyb3V0ZXIubGF0ZXN0TG9jYXRpb24pO1xuXHRjb25zdCBlbnRyaWVzID0gc2Nyb2xsUmVzdG9yYXRpb25DYWNoZVtyZXN0b3JlS2V5XTtcblx0aWYgKCFlbnRyaWVzKSByZXR1cm47XG5cdGlmIChvcHRpb25zLmlkKSByZXR1cm4gZW50cmllc1tgWyR7c2Nyb2xsUmVzdG9yYXRpb25JZEF0dHJpYnV0ZX09XCIke29wdGlvbnMuaWR9XCJdYF07XG5cdGNvbnN0IGVsZW1lbnQgPSBvcHRpb25zLmdldEVsZW1lbnQ/LigpO1xuXHRpZiAoIWVsZW1lbnQpIHJldHVybjtcblx0cmV0dXJuIGVudHJpZXNbZWxlbWVudCA9PT0gd2luZG93ID8gd2luZG93U2Nyb2xsVGFyZ2V0IDogZ2V0U2Nyb2xsUmVzdG9yYXRpb25TZWxlY3RvcihlbGVtZW50KV07XG59XG5sZXQgaWdub3JlU2Nyb2xsID0gZmFsc2U7XG5jb25zdCB3aW5kb3dTY3JvbGxUYXJnZXQgPSBcIndpbmRvd1wiO1xuZnVuY3Rpb24gZ2V0RWxlbWVudChzZWxlY3Rvcikge1xuXHR0cnkge1xuXHRcdHJldHVybiB0eXBlb2Ygc2VsZWN0b3IgPT09IFwiZnVuY3Rpb25cIiA/IHNlbGVjdG9yKCkgOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKHNlbGVjdG9yKTtcblx0fSBjYXRjaCB7fVxufVxuZnVuY3Rpb24gZ2V0U2Nyb2xsVG9Ub3BFbGVtZW50cyhzY3JvbGxUb1RvcFNlbGVjdG9ycykge1xuXHRjb25zdCBlbGVtZW50cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdGZvciAoY29uc3Qgc2VsZWN0b3Igb2Ygc2Nyb2xsVG9Ub3BTZWxlY3RvcnMpIHtcblx0XHRpZiAoc2VsZWN0b3IgPT09IHdpbmRvd1Njcm9sbFRhcmdldCkgY29udGludWU7XG5cdFx0Y29uc3QgZWxlbWVudCA9IGdldEVsZW1lbnQoc2VsZWN0b3IpO1xuXHRcdGlmIChlbGVtZW50KSBlbGVtZW50cy5hZGQoZWxlbWVudCk7XG5cdH1cblx0cmV0dXJuIGVsZW1lbnRzO1xufVxuZnVuY3Rpb24gc2V0dXBTY3JvbGxSZXN0b3JhdGlvbihyb3V0ZXIsIGZvcmNlKSB7XG5cdGNvbnN0IHNob3VsZFNldHVwU2Nyb2xsUmVzdG9yYXRpb24gPSBmb3JjZSA/PyByb3V0ZXIub3B0aW9ucy5zY3JvbGxSZXN0b3JhdGlvbjtcblx0Y29uc3Qgc2Nyb2xsID0gcm91dGVyLl9zY3JvbGw7XG5cdGlmIChzaG91bGRTZXR1cFNjcm9sbFJlc3RvcmF0aW9uKSBzY3JvbGwuZSA9IHRydWU7XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHJldHVybjtcblx0Y29uc3QgZ2V0S2V5ID0gcm91dGVyLm9wdGlvbnMuZ2V0U2Nyb2xsUmVzdG9yYXRpb25LZXkgfHwgZGVmYXVsdEdldFNjcm9sbFJlc3RvcmF0aW9uS2V5O1xuXHRjb25zdCB0cmFja2VkU2Nyb2xsVGFyZ2V0cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdGNvbnN0IHNuYXBzaG90Q3VycmVudFNjcm9sbFRhcmdldHMgPSAocmVzdG9yZUtleSkgPT4ge1xuXHRcdGNvbnN0IGtleUVudHJ5ID0gc2Nyb2xsUmVzdG9yYXRpb25DYWNoZVtyZXN0b3JlS2V5XSB8fD0ge307XG5cdFx0Zm9yIChjb25zdCB0YXJnZXQgb2YgdHJhY2tlZFNjcm9sbFRhcmdldHMpIGlmICh0YXJnZXQgPT09IGRvY3VtZW50KSBrZXlFbnRyeVt3aW5kb3dTY3JvbGxUYXJnZXRdID0ge1xuXHRcdFx0c2Nyb2xsWCxcblx0XHRcdHNjcm9sbFlcblx0XHR9O1xuXHRcdGVsc2UgaWYgKHRhcmdldC5pc0Nvbm5lY3RlZCkga2V5RW50cnlbZ2V0U2Nyb2xsUmVzdG9yYXRpb25TZWxlY3Rvcih0YXJnZXQpXSA9IHtcblx0XHRcdHNjcm9sbFg6IHRhcmdldC5zY3JvbGxMZWZ0LFxuXHRcdFx0c2Nyb2xsWTogdGFyZ2V0LnNjcm9sbFRvcFxuXHRcdH07XG5cdH07XG5cdGlmIChzaG91bGRTZXR1cFNjcm9sbFJlc3RvcmF0aW9uICYmICFzY3JvbGwucykge1xuXHRcdHNjcm9sbC5zID0gdHJ1ZTtcblx0XHRpZ25vcmVTY3JvbGwgPSBmYWxzZTtcblx0XHRoaXN0b3J5LnNjcm9sbFJlc3RvcmF0aW9uID0gXCJtYW51YWxcIjtcblx0XHRkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwic2Nyb2xsXCIsIChldmVudCkgPT4ge1xuXHRcdFx0aWYgKGlnbm9yZVNjcm9sbCkgcmV0dXJuO1xuXHRcdFx0dHJhY2tlZFNjcm9sbFRhcmdldHMuYWRkKGV2ZW50LnRhcmdldCk7XG5cdFx0fSwgdHJ1ZSk7XG5cdFx0cm91dGVyLnN1YnNjcmliZShcIm9uQmVmb3JlTG9hZFwiLCAoZXZlbnQpID0+IHtcblx0XHRcdGlmIChldmVudC5mcm9tTG9jYXRpb24pIHNuYXBzaG90Q3VycmVudFNjcm9sbFRhcmdldHMoZ2V0S2V5KGV2ZW50LmZyb21Mb2NhdGlvbikpO1xuXHRcdFx0dHJhY2tlZFNjcm9sbFRhcmdldHMuY2xlYXIoKTtcblx0XHR9KTtcblx0XHRhZGRFdmVudExpc3RlbmVyKFwicGFnZWhpZGVcIiwgKCkgPT4ge1xuXHRcdFx0aGlzdG9yeS5zY3JvbGxSZXN0b3JhdGlvbiA9IFwiYXV0b1wiO1xuXHRcdFx0c25hcHNob3RDdXJyZW50U2Nyb2xsVGFyZ2V0cyhnZXRLZXkocm91dGVyLnN0b3Jlcy5yZXNvbHZlZExvY2F0aW9uLmdldCgpID8/IHJvdXRlci5zdG9yZXMubG9jYXRpb24uZ2V0KCkpKTtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdHNhZmVTZXNzaW9uU3RvcmFnZT8uc2V0SXRlbShzdG9yYWdlS2V5LCBKU09OLnN0cmluZ2lmeShzY3JvbGxSZXN0b3JhdGlvbkNhY2hlKSk7XG5cdFx0XHR9IGNhdGNoIHtcblx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgY29uc29sZS53YXJuKFwiW3RzLXJvdXRlcl0gQ291bGQgbm90IHBlcnNpc3Qgc2Nyb2xsIHJlc3RvcmF0aW9uIHN0YXRlIHRvIHNlc3Npb25TdG9yYWdlLlwiKTtcblx0XHRcdH1cblx0XHR9KTtcblx0XHRhZGRFdmVudExpc3RlbmVyKFwicGFnZXNob3dcIiwgKGV2ZW50KSA9PiB7XG5cdFx0XHRpZiAoZXZlbnQucGVyc2lzdGVkKSBoaXN0b3J5LnNjcm9sbFJlc3RvcmF0aW9uID0gXCJtYW51YWxcIjtcblx0XHR9KTtcblx0fVxuXHRpZiAoc2Nyb2xsLnIpIHJldHVybjtcblx0c2Nyb2xsLnIgPSB0cnVlO1xuXHRyb3V0ZXIuc3Vic2NyaWJlKFwib25SZW5kZXJlZFwiLCAoZXZlbnQpID0+IHtcblx0XHRjb25zdCBiZWhhdmlvciA9IHJvdXRlci5vcHRpb25zLnNjcm9sbFJlc3RvcmF0aW9uQmVoYXZpb3I7XG5cdFx0Y29uc3Qgc2Nyb2xsVG9Ub3BTZWxlY3RvcnMgPSByb3V0ZXIub3B0aW9ucy5zY3JvbGxUb1RvcFNlbGVjdG9ycztcblx0XHRjb25zdCBzaG91bGRSZXNldFNjcm9sbCA9IHNjcm9sbC5uO1xuXHRcdGNvbnN0IGhhc2hOYXZpZ2F0aW9uID0gc2Nyb2xsLmg7XG5cdFx0bGV0IHNjcm9sbFRvVG9wRWxlbWVudHM7XG5cdFx0dHJhY2tlZFNjcm9sbFRhcmdldHMuY2xlYXIoKTtcblx0XHRzY3JvbGwubiA9IHRydWU7XG5cdFx0c2Nyb2xsLmggPSBmYWxzZTtcblx0XHRpZiAodHlwZW9mIHJvdXRlci5vcHRpb25zLnNjcm9sbFJlc3RvcmF0aW9uID09PSBcImZ1bmN0aW9uXCIgJiYgIXJvdXRlci5vcHRpb25zLnNjcm9sbFJlc3RvcmF0aW9uKHsgbG9jYXRpb246IHJvdXRlci5sYXRlc3RMb2NhdGlvbiB9KSkgcmV0dXJuO1xuXHRcdGNvbnN0IGNhY2hlS2V5ID0gZ2V0S2V5KGV2ZW50LnRvTG9jYXRpb24pO1xuXHRcdGNvbnN0IGZyb21DYWNoZUtleSA9IGV2ZW50LmZyb21Mb2NhdGlvbiAmJiBnZXRLZXkoZXZlbnQuZnJvbUxvY2F0aW9uKTtcblx0XHRpZiAoc2Nyb2xsLmUgJiYgZnJvbUNhY2hlS2V5ICYmIGZyb21DYWNoZUtleSAhPT0gY2FjaGVLZXkpIHtcblx0XHRcdGNvbnN0IGZyb21FbGVtZW50RW50cmllcyA9IHNjcm9sbFJlc3RvcmF0aW9uQ2FjaGVbZnJvbUNhY2hlS2V5XTtcblx0XHRcdGlmIChmcm9tRWxlbWVudEVudHJpZXMpIHtcblx0XHRcdFx0bGV0IHRvRWxlbWVudEVudHJpZXMgPSBzY3JvbGxSZXN0b3JhdGlvbkNhY2hlW2NhY2hlS2V5XTtcblx0XHRcdFx0Zm9yIChjb25zdCBlbGVtZW50U2VsZWN0b3IgaW4gZnJvbUVsZW1lbnRFbnRyaWVzKSB7XG5cdFx0XHRcdFx0aWYgKGVsZW1lbnRTZWxlY3RvciA9PT0gd2luZG93U2Nyb2xsVGFyZ2V0KSB7XG5cdFx0XHRcdFx0XHRpZiAoc2hvdWxkUmVzZXRTY3JvbGwpIGNvbnRpbnVlO1xuXHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRjb25zdCBlbGVtZW50ID0gZ2V0RWxlbWVudChlbGVtZW50U2VsZWN0b3IpO1xuXHRcdFx0XHRcdFx0aWYgKCFlbGVtZW50KSBjb250aW51ZTtcblx0XHRcdFx0XHRcdGlmIChzaG91bGRSZXNldFNjcm9sbCAmJiBzY3JvbGxUb1RvcFNlbGVjdG9ycykge1xuXHRcdFx0XHRcdFx0XHRzY3JvbGxUb1RvcEVsZW1lbnRzID8/PSBnZXRTY3JvbGxUb1RvcEVsZW1lbnRzKHNjcm9sbFRvVG9wU2VsZWN0b3JzKTtcblx0XHRcdFx0XHRcdFx0aWYgKHNjcm9sbFRvVG9wRWxlbWVudHMuaGFzKGVsZW1lbnQpKSBjb250aW51ZTtcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKCF0b0VsZW1lbnRFbnRyaWVzKSB0b0VsZW1lbnRFbnRyaWVzID0gc2Nyb2xsUmVzdG9yYXRpb25DYWNoZVtjYWNoZUtleV0gPSB7fTtcblx0XHRcdFx0XHR0b0VsZW1lbnRFbnRyaWVzW2VsZW1lbnRTZWxlY3Rvcl0gPz89IGZyb21FbGVtZW50RW50cmllc1tlbGVtZW50U2VsZWN0b3JdO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGlnbm9yZVNjcm9sbCA9IHRydWU7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGhhc2ggPSBldmVudC50b0xvY2F0aW9uLmhhc2g7XG5cdFx0XHRjb25zdCBoYXNoU2Nyb2xsSW50b1ZpZXdPcHRpb25zID0gZXZlbnQudG9Mb2NhdGlvbi5zdGF0ZS5fX2hhc2hTY3JvbGxJbnRvVmlld09wdGlvbnMgPz8gdHJ1ZTtcblx0XHRcdGxldCB3aW5kb3dSZXN0b3JlZCA9IGZhbHNlO1xuXHRcdFx0aWYgKHNob3VsZFJlc2V0U2Nyb2xsKSB7XG5cdFx0XHRcdGlmICghaGFzaCAmJiBzY3JvbGxUb1RvcFNlbGVjdG9ycykgc2Nyb2xsVG9Ub3BFbGVtZW50cyA/Pz0gZ2V0U2Nyb2xsVG9Ub3BFbGVtZW50cyhzY3JvbGxUb1RvcFNlbGVjdG9ycyk7XG5cdFx0XHRcdGNvbnN0IHNraXBXaW5kb3dSZXN0b3JlID0gaGFzaCAmJiBoYXNoU2Nyb2xsSW50b1ZpZXdPcHRpb25zICYmIGhhc2hOYXZpZ2F0aW9uO1xuXHRcdFx0XHRjb25zdCBlbGVtZW50RW50cmllcyA9IHNjcm9sbC5lID8gc2Nyb2xsUmVzdG9yYXRpb25DYWNoZVtjYWNoZUtleV0gOiB2b2lkIDA7XG5cdFx0XHRcdGlmIChlbGVtZW50RW50cmllcykgZm9yIChjb25zdCBlbGVtZW50U2VsZWN0b3IgaW4gZWxlbWVudEVudHJpZXMpIHtcblx0XHRcdFx0XHRjb25zdCB7IHNjcm9sbFgsIHNjcm9sbFkgfSA9IGVsZW1lbnRFbnRyaWVzW2VsZW1lbnRTZWxlY3Rvcl07XG5cdFx0XHRcdFx0aWYgKGVsZW1lbnRTZWxlY3RvciA9PT0gd2luZG93U2Nyb2xsVGFyZ2V0KSB7XG5cdFx0XHRcdFx0XHRpZiAoc2tpcFdpbmRvd1Jlc3RvcmUpIGNvbnRpbnVlO1xuXHRcdFx0XHRcdFx0c2Nyb2xsVG8oe1xuXHRcdFx0XHRcdFx0XHR0b3A6IHNjcm9sbFksXG5cdFx0XHRcdFx0XHRcdGxlZnQ6IHNjcm9sbFgsXG5cdFx0XHRcdFx0XHRcdGJlaGF2aW9yXG5cdFx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRcdHdpbmRvd1Jlc3RvcmVkID0gdHJ1ZTtcblx0XHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdFx0Y29uc3QgZWxlbWVudCA9IGdldEVsZW1lbnQoZWxlbWVudFNlbGVjdG9yKTtcblx0XHRcdFx0XHRcdGlmIChlbGVtZW50KSB7XG5cdFx0XHRcdFx0XHRcdGVsZW1lbnQuc2Nyb2xsTGVmdCA9IHNjcm9sbFg7XG5cdFx0XHRcdFx0XHRcdGVsZW1lbnQuc2Nyb2xsVG9wID0gc2Nyb2xsWTtcblx0XHRcdFx0XHRcdFx0c2Nyb2xsVG9Ub3BFbGVtZW50cz8uZGVsZXRlKGVsZW1lbnQpO1xuXHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoIWhhc2gpIHtcblx0XHRcdFx0XHRjb25zdCBzY3JvbGxPcHRpb25zID0ge1xuXHRcdFx0XHRcdFx0dG9wOiAwLFxuXHRcdFx0XHRcdFx0bGVmdDogMCxcblx0XHRcdFx0XHRcdGJlaGF2aW9yXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRpZiAoIXdpbmRvd1Jlc3RvcmVkKSBzY3JvbGxUbyhzY3JvbGxPcHRpb25zKTtcblx0XHRcdFx0XHRpZiAoc2Nyb2xsVG9Ub3BFbGVtZW50cykgZm9yIChjb25zdCBlbGVtZW50IG9mIHNjcm9sbFRvVG9wRWxlbWVudHMpIGVsZW1lbnQuc2Nyb2xsVG8oc2Nyb2xsT3B0aW9ucyk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGlmICghd2luZG93UmVzdG9yZWQgJiYgaGFzaCAmJiBoYXNoU2Nyb2xsSW50b1ZpZXdPcHRpb25zKSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChoYXNoKT8uc2Nyb2xsSW50b1ZpZXcoaGFzaFNjcm9sbEludG9WaWV3T3B0aW9ucyk7XG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdGlnbm9yZVNjcm9sbCA9IGZhbHNlO1xuXHRcdH1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGRlZmF1bHRHZXRTY3JvbGxSZXN0b3JhdGlvbktleSwgZ2V0RWxlbWVudFNjcm9sbFJlc3RvcmF0aW9uRW50cnksIHNldHVwU2Nyb2xsUmVzdG9yYXRpb24sIHN0b3JhZ2VLZXkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2Nyb2xsLXJlc3RvcmF0aW9uLmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvcXNzLnRzXG4vKipcbiogUHJvZ3JhbSBpcyBhIHJlaW1wbGVtZW50YXRpb24gb2YgdGhlIGBxc3NgIHBhY2thZ2U6XG4qIENvcHlyaWdodCAoYykgTHVrZSBFZHdhcmRzIGx1a2UuZWR3YXJkczA1QGdtYWlsLmNvbSwgTUlUIExpY2Vuc2VcbiogaHR0cHM6Ly9naXRodWIuY29tL2x1a2VlZC9xc3MvYmxvYi9tYXN0ZXIvbGljZW5zZS5tZFxuKlxuKiBUaGlzIHJlaW1wbGVtZW50YXRpb24gdXNlcyBtb2Rlcm4gYnJvd3NlciBBUElzXG4qIChuYW1lbHkgVVJMU2VhcmNoUGFyYW1zKSBhbmQgVHlwZVNjcmlwdCB3aGlsZSBzdGlsbFxuKiBtYWludGFpbmluZyB0aGUgb3JpZ2luYWwgZnVuY3Rpb25hbGl0eSBhbmQgaW50ZXJmYWNlLlxuKlxuKiBVcGRhdGU6IHRoaXMgaW1wbGVtZW50YXRpb24gaGFzIGFsc28gYmVlbiBtYW5nbGVkIHRvXG4qIGZpdCBleGFjdGx5IG91ciB1c2UtY2FzZSAoc2luZ2xlIHZhbHVlIHBlciBrZXkgaW4gZW5jb2RpbmcpLlxuKi9cbi8qKlxuKiBFbmNvZGVzIGFuIG9iamVjdCBpbnRvIGEgcXVlcnkgc3RyaW5nLlxuKiBAcGFyYW0gb2JqIC0gVGhlIG9iamVjdCB0byBlbmNvZGUgaW50byBhIHF1ZXJ5IHN0cmluZy5cbiogQHBhcmFtIHN0cmluZ2lmeSAtIEFuIG9wdGlvbmFsIGN1c3RvbSBzdHJpbmdpZnkgZnVuY3Rpb24uXG4qIEByZXR1cm5zIFRoZSBlbmNvZGVkIHF1ZXJ5IHN0cmluZy5cbiogQGV4YW1wbGVcbiogYGBgXG4qIC8vIEV4YW1wbGUgaW5wdXQ6IGVuY29kZSh7IHRva2VuOiAnZm9vJywga2V5OiAndmFsdWUnIH0pXG4qIC8vIEV4cGVjdGVkIG91dHB1dDogXCJ0b2tlbj1mb28ma2V5PXZhbHVlXCJcbiogYGBgXG4qL1xuZnVuY3Rpb24gZW5jb2RlKG9iaiwgc3RyaW5naWZ5ID0gU3RyaW5nKSB7XG5cdGxldCByZXN1bHQ7XG5cdGZvciAoY29uc3Qga2V5IGluIG9iaikge1xuXHRcdGNvbnN0IHZhbCA9IG9ialtrZXldO1xuXHRcdGlmICh2YWwgIT09IHZvaWQgMCkgKHJlc3VsdCB8fD0gbmV3IFVSTFNlYXJjaFBhcmFtcygpKS5zZXQoa2V5LCBzdHJpbmdpZnkodmFsKSk7XG5cdH1cblx0cmV0dXJuIHJlc3VsdCA/IHJlc3VsdC50b1N0cmluZygpIDogXCJcIjtcbn1cbi8qKlxuKiBDb252ZXJ0cyBhIHN0cmluZyB2YWx1ZSB0byBpdHMgYXBwcm9wcmlhdGUgdHlwZSAoc3RyaW5nLCBudW1iZXIsIGJvb2xlYW4pLlxuKiBAcGFyYW0gbWl4IC0gVGhlIHN0cmluZyB2YWx1ZSB0byBjb252ZXJ0LlxuKiBAcmV0dXJucyBUaGUgY29udmVydGVkIHZhbHVlLlxuKiBAZXhhbXBsZVxuKiAvLyBFeGFtcGxlIGlucHV0OiB0b1ZhbHVlKFwiMTIzXCIpXG4qIC8vIEV4cGVjdGVkIG91dHB1dDogMTIzXG4qL1xuZnVuY3Rpb24gdG9WYWx1ZShzdHIpIHtcblx0aWYgKCFzdHIpIHJldHVybiBcIlwiO1xuXHRpZiAoc3RyID09PSBcImZhbHNlXCIpIHJldHVybiBmYWxzZTtcblx0aWYgKHN0ciA9PT0gXCJ0cnVlXCIpIHJldHVybiB0cnVlO1xuXHRyZXR1cm4gK3N0ciAqIDAgPT09IDAgJiYgK3N0ciArIFwiXCIgPT09IHN0ciA/ICtzdHIgOiBzdHI7XG59XG4vKipcbiogRGVjb2RlcyBhIHF1ZXJ5IHN0cmluZyBpbnRvIGFuIG9iamVjdC5cbiogQHBhcmFtIHN0ciAtIFRoZSBxdWVyeSBzdHJpbmcgdG8gZGVjb2RlLlxuKiBAcmV0dXJucyBUaGUgZGVjb2RlZCBrZXktdmFsdWUgcGFpcnMgaW4gYW4gb2JqZWN0IGZvcm1hdC5cbiogQGV4YW1wbGVcbiogLy8gRXhhbXBsZSBpbnB1dDogZGVjb2RlKFwidG9rZW49Zm9vJmtleT12YWx1ZVwiKVxuKiAvLyBFeHBlY3RlZCBvdXRwdXQ6IHsgXCJ0b2tlblwiOiBcImZvb1wiLCBcImtleVwiOiBcInZhbHVlXCIgfVxuKi9cbmZ1bmN0aW9uIGRlY29kZShzdHIpIHtcblx0Y29uc3Qgc2VhcmNoUGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyhzdHIpO1xuXHRjb25zdCByZXN1bHQgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXHRmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBzZWFyY2hQYXJhbXMuZW50cmllcygpKSB7XG5cdFx0Y29uc3QgcHJldmlvdXNWYWx1ZSA9IHJlc3VsdFtrZXldO1xuXHRcdGlmIChwcmV2aW91c1ZhbHVlID09IG51bGwpIHJlc3VsdFtrZXldID0gdG9WYWx1ZSh2YWx1ZSk7XG5cdFx0ZWxzZSBpZiAoQXJyYXkuaXNBcnJheShwcmV2aW91c1ZhbHVlKSkgcHJldmlvdXNWYWx1ZS5wdXNoKHRvVmFsdWUodmFsdWUpKTtcblx0XHRlbHNlIHJlc3VsdFtrZXldID0gW3ByZXZpb3VzVmFsdWUsIHRvVmFsdWUodmFsdWUpXTtcblx0fVxuXHRyZXR1cm4gcmVzdWx0O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBkZWNvZGUsIGVuY29kZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1xc3MuanMubWFwIiwiaW1wb3J0IHsgZGVjb2RlLCBlbmNvZGUgfSBmcm9tIFwiLi9xc3MuanNcIjtcbi8vI3JlZ2lvbiBzcmMvc2VhcmNoUGFyYW1zLnRzXG5jb25zdCBqc29uU3RhcnQgPSAvXig/Olxcc3xbXCJbe1xcZC1dfGZhfG51fHRyKS87XG4vKiogRGVmYXVsdCBgcGFyc2VTZWFyY2hgIHRoYXQgc3RyaXBzIGxlYWRpbmcgJz8nIGFuZCBKU09OLXBhcnNlcyB2YWx1ZXMuICovXG5jb25zdCBkZWZhdWx0UGFyc2VTZWFyY2ggPSBwYXJzZVNlYXJjaFdpdGgoSlNPTi5wYXJzZSk7XG4vKiogRGVmYXVsdCBgc3RyaW5naWZ5U2VhcmNoYCB1c2luZyBKU09OLnN0cmluZ2lmeSBmb3IgY29tcGxleCB2YWx1ZXMuICovXG5jb25zdCBkZWZhdWx0U3RyaW5naWZ5U2VhcmNoID0gc3RyaW5naWZ5U2VhcmNoV2l0aChKU09OLnN0cmluZ2lmeSwgSlNPTi5wYXJzZSk7XG4vKipcbiogQnVpbGQgYSBgcGFyc2VTZWFyY2hgIGZ1bmN0aW9uIHVzaW5nIGEgcHJvdmlkZWQgSlNPTi1saWtlIHBhcnNlci5cbipcbiogVGhlIHJldHVybmVkIGZ1bmN0aW9uIHN0cmlwcyBhIGxlYWRpbmcgYD9gLCBkZWNvZGVzIHZhbHVlcywgYW5kIGF0dGVtcHRzIHRvXG4qIEpTT04tcGFyc2Ugc3RyaW5nIHZhbHVlcyB1c2luZyB0aGUgZ2l2ZW4gYHBhcnNlcmAuXG4qXG4qIEBwYXJhbSBwYXJzZXIgRnVuY3Rpb24gdG8gcGFyc2UgYSBzdHJpbmcgdmFsdWUgKGUuZy4gYEpTT04ucGFyc2VgKS5cbiogQHJldHVybnMgQSBgcGFyc2VTZWFyY2hgIGZ1bmN0aW9uIGNvbXBhdGlibGUgd2l0aCBgUm91dGVyYCBvcHRpb25zLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2d1aWRlL2N1c3RvbS1zZWFyY2gtcGFyYW0tc2VyaWFsaXphdGlvblxuKi9cbmZ1bmN0aW9uIHBhcnNlU2VhcmNoV2l0aChwYXJzZXIpIHtcblx0Y29uc3QgaXNKc29uUGFyc2VyID0gcGFyc2VyID09PSBKU09OLnBhcnNlO1xuXHRyZXR1cm4gKHNlYXJjaFN0cikgPT4ge1xuXHRcdGlmIChzZWFyY2hTdHJbMF0gPT09IFwiP1wiKSBzZWFyY2hTdHIgPSBzZWFyY2hTdHIuc2xpY2UoMSk7XG5cdFx0Y29uc3QgcXVlcnkgPSBkZWNvZGUoc2VhcmNoU3RyKTtcblx0XHRmb3IgKGNvbnN0IGtleSBpbiBxdWVyeSkge1xuXHRcdFx0Y29uc3QgdmFsdWUgPSBxdWVyeVtrZXldO1xuXHRcdFx0aWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0XHRpZiAoaXNKc29uUGFyc2VyICYmICFqc29uU3RhcnQudGVzdCh2YWx1ZSkpIGNvbnRpbnVlO1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdHF1ZXJ5W2tleV0gPSBwYXJzZXIodmFsdWUpO1xuXHRcdFx0XHR9IGNhdGNoIChfZXJyKSB7fVxuXHRcdFx0fVxuXHRcdH1cblx0XHRyZXR1cm4gcXVlcnk7XG5cdH07XG59XG4vKipcbiogQnVpbGQgYSBgc3RyaW5naWZ5U2VhcmNoYCBmdW5jdGlvbiB1c2luZyBhIHByb3ZpZGVkIHNlcmlhbGl6ZXIuXG4qXG4qIE5vbi1wcmltaXRpdmUgdmFsdWVzIGFyZSBzZXJpYWxpemVkIHdpdGggYHN0cmluZ2lmeWAuIElmIGEgYHBhcnNlcmAgaXNcbiogc3VwcGxpZWQsIHN0cmluZyB2YWx1ZXMgdGhhdCBhcmUgcGFyc2VhYmxlIGFyZSByZS1zZXJpYWxpemVkIHRvIGVuc3VyZVxuKiBzeW1tZXRyeSB3aXRoIGBwYXJzZVNlYXJjaGAuXG4qXG4qIEBwYXJhbSBzdHJpbmdpZnkgRnVuY3Rpb24gdG8gc2VyaWFsaXplIGEgdmFsdWUgKGUuZy4gYEpTT04uc3RyaW5naWZ5YCkuXG4qIEBwYXJhbSBwYXJzZXIgT3B0aW9uYWwgcGFyc2VyIHRvIGRldGVjdCBwYXJzZWFibGUgc3RyaW5ncy5cbiogQHJldHVybnMgQSBgc3RyaW5naWZ5U2VhcmNoYCBmdW5jdGlvbiBjb21wYXRpYmxlIHdpdGggYFJvdXRlcmAgb3B0aW9ucy5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9ndWlkZS9jdXN0b20tc2VhcmNoLXBhcmFtLXNlcmlhbGl6YXRpb25cbiovXG5mdW5jdGlvbiBzdHJpbmdpZnlTZWFyY2hXaXRoKHN0cmluZ2lmeSwgcGFyc2VyKSB7XG5cdGNvbnN0IGlzSnNvblBhcnNlciA9IHBhcnNlciA9PT0gSlNPTi5wYXJzZTtcblx0ZnVuY3Rpb24gc3RyaW5naWZ5VmFsdWUodmFsKSB7XG5cdFx0aWYgKHZhbCAmJiB0eXBlb2YgdmFsID09PSBcIm9iamVjdFwiKSB0cnkge1xuXHRcdFx0cmV0dXJuIHN0cmluZ2lmeSh2YWwpO1xuXHRcdH0gY2F0Y2ggKF9lcnIpIHt9XG5cdFx0ZWxzZSBpZiAocGFyc2VyICYmIHR5cGVvZiB2YWwgPT09IFwic3RyaW5nXCIpIHtcblx0XHRcdGlmIChpc0pzb25QYXJzZXIgJiYgIWpzb25TdGFydC50ZXN0KHZhbCkpIHJldHVybiB2YWw7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRwYXJzZXIodmFsKTtcblx0XHRcdFx0cmV0dXJuIHN0cmluZ2lmeSh2YWwpO1xuXHRcdFx0fSBjYXRjaCAoX2Vycikge31cblx0XHR9XG5cdFx0cmV0dXJuIHZhbDtcblx0fVxuXHRyZXR1cm4gKHNlYXJjaCkgPT4ge1xuXHRcdGNvbnN0IHNlYXJjaFN0ciA9IGVuY29kZShzZWFyY2gsIHN0cmluZ2lmeVZhbHVlKTtcblx0XHRyZXR1cm4gc2VhcmNoU3RyID8gYD8ke3NlYXJjaFN0cn1gIDogXCJcIjtcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZGVmYXVsdFBhcnNlU2VhcmNoLCBkZWZhdWx0U3RyaW5naWZ5U2VhcmNoLCBwYXJzZVNlYXJjaFdpdGgsIHN0cmluZ2lmeVNlYXJjaFdpdGggfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2VhcmNoUGFyYW1zLmpzLm1hcCIsImltcG9ydCB7IGNsZWFuUGF0aCwgdHJpbVBhdGggfSBmcm9tIFwiLi9wYXRoLmpzXCI7XG4vLyNyZWdpb24gc3JjL3Jld3JpdGUudHNcbi8qKiBDb21wb3NlIG11bHRpcGxlIHJld3JpdGUgcGFpcnMgaW50byBhIHNpbmdsZSBpbi9vdXQgcmV3cml0ZS4gKi9cbmZ1bmN0aW9uIGNvbXBvc2VSZXdyaXRlcyhyZXdyaXRlcykge1xuXHRyZXR1cm4ge1xuXHRcdGlucHV0OiAoeyB1cmwgfSkgPT4ge1xuXHRcdFx0Zm9yIChjb25zdCByZXdyaXRlIG9mIHJld3JpdGVzKSB1cmwgPSBleGVjdXRlUmV3cml0ZUlucHV0KHJld3JpdGUsIHVybCk7XG5cdFx0XHRyZXR1cm4gdXJsO1xuXHRcdH0sXG5cdFx0b3V0cHV0OiAoeyB1cmwgfSkgPT4ge1xuXHRcdFx0Zm9yIChsZXQgaSA9IHJld3JpdGVzLmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB1cmwgPSBleGVjdXRlUmV3cml0ZU91dHB1dChyZXdyaXRlc1tpXSwgdXJsKTtcblx0XHRcdHJldHVybiB1cmw7XG5cdFx0fVxuXHR9O1xufVxuLyoqIENyZWF0ZSBhIHJld3JpdGUgcGFpciB0aGF0IHN0cmlwcy9hZGRzIGEgYmFzZXBhdGggb24gaW5wdXQvb3V0cHV0LiAqL1xuZnVuY3Rpb24gcmV3cml0ZUJhc2VwYXRoKGJhc2VwYXRoLCBjYXNlU2Vuc2l0aXZlLCByZXdyaXRlKSB7XG5cdGNvbnN0IHRyaW1tZWRCYXNlcGF0aCA9IHRyaW1QYXRoKGJhc2VwYXRoKTtcblx0Y29uc3Qgbm9ybWFsaXplZEJhc2VwYXRoID0gYC8ke3RyaW1tZWRCYXNlcGF0aH1gO1xuXHRjb25zdCBjaGVja0Jhc2VwYXRoID0gY2FzZVNlbnNpdGl2ZSA/IG5vcm1hbGl6ZWRCYXNlcGF0aCA6IG5vcm1hbGl6ZWRCYXNlcGF0aC50b0xvd2VyQ2FzZSgpO1xuXHRjb25zdCBjaGVja0Jhc2VwYXRoV2l0aFNsYXNoID0gYCR7Y2hlY2tCYXNlcGF0aH0vYDtcblx0Y29uc3QgYmFzZXBhdGhSZXdyaXRlID0ge1xuXHRcdGlucHV0OiAoeyB1cmwgfSkgPT4ge1xuXHRcdFx0Y29uc3QgcGF0aG5hbWUgPSBjYXNlU2Vuc2l0aXZlID8gdXJsLnBhdGhuYW1lIDogdXJsLnBhdGhuYW1lLnRvTG93ZXJDYXNlKCk7XG5cdFx0XHRpZiAocGF0aG5hbWUgPT09IGNoZWNrQmFzZXBhdGgpIHVybC5wYXRobmFtZSA9IFwiL1wiO1xuXHRcdFx0ZWxzZSBpZiAocGF0aG5hbWUuc3RhcnRzV2l0aChjaGVja0Jhc2VwYXRoV2l0aFNsYXNoKSkgdXJsLnBhdGhuYW1lID0gdXJsLnBhdGhuYW1lLnNsaWNlKG5vcm1hbGl6ZWRCYXNlcGF0aC5sZW5ndGgpO1xuXHRcdFx0cmV0dXJuIHVybDtcblx0XHR9LFxuXHRcdG91dHB1dDogKHsgdXJsIH0pID0+IHtcblx0XHRcdHVybC5wYXRobmFtZSA9IGNsZWFuUGF0aChgLyR7dHJpbW1lZEJhc2VwYXRofSR7dXJsLnBhdGhuYW1lfWApO1xuXHRcdFx0cmV0dXJuIHVybDtcblx0XHR9XG5cdH07XG5cdHJldHVybiByZXdyaXRlID8ge1xuXHRcdGlucHV0OiAoeyB1cmwgfSkgPT4gZXhlY3V0ZVJld3JpdGVJbnB1dChyZXdyaXRlLCBiYXNlcGF0aFJld3JpdGUuaW5wdXQoeyB1cmwgfSkpLFxuXHRcdG91dHB1dDogKHsgdXJsIH0pID0+IGJhc2VwYXRoUmV3cml0ZS5vdXRwdXQoeyB1cmw6IGV4ZWN1dGVSZXdyaXRlT3V0cHV0KHJld3JpdGUsIHVybCkgfSlcblx0fSA6IGJhc2VwYXRoUmV3cml0ZTtcbn1cbi8qKiBFeGVjdXRlIGEgbG9jYXRpb24gaW5wdXQgcmV3cml0ZSBpZiBwcm92aWRlZC4gKi9cbmZ1bmN0aW9uIGV4ZWN1dGVSZXdyaXRlSW5wdXQocmV3cml0ZSwgdXJsKSB7XG5cdGNvbnN0IHJlcyA9IHJld3JpdGU/LmlucHV0Py4oeyB1cmwgfSk7XG5cdGlmIChyZXMpIHtcblx0XHRpZiAodHlwZW9mIHJlcyA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIG5ldyBVUkwocmVzKTtcblx0XHRlbHNlIGlmIChyZXMgaW5zdGFuY2VvZiBVUkwpIHJldHVybiByZXM7XG5cdH1cblx0cmV0dXJuIHVybDtcbn1cbi8qKiBFeGVjdXRlIGEgbG9jYXRpb24gb3V0cHV0IHJld3JpdGUgaWYgcHJvdmlkZWQuICovXG5mdW5jdGlvbiBleGVjdXRlUmV3cml0ZU91dHB1dChyZXdyaXRlLCB1cmwpIHtcblx0Y29uc3QgcmVzID0gcmV3cml0ZT8ub3V0cHV0Py4oeyB1cmwgfSk7XG5cdGlmIChyZXMpIHtcblx0XHRpZiAodHlwZW9mIHJlcyA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIG5ldyBVUkwocmVzKTtcblx0XHRlbHNlIGlmIChyZXMgaW5zdGFuY2VvZiBVUkwpIHJldHVybiByZXM7XG5cdH1cblx0cmV0dXJuIHVybDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgY29tcG9zZVJld3JpdGVzLCBleGVjdXRlUmV3cml0ZUlucHV0LCBleGVjdXRlUmV3cml0ZU91dHB1dCwgcmV3cml0ZUJhc2VwYXRoIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJld3JpdGUuanMubWFwIiwiaW1wb3J0IHsgYXJyYXlzRXF1YWwsIGZ1bmN0aW9uYWxVcGRhdGUgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuLy8jcmVnaW9uIHNyYy9zdG9yZXMudHNcbi8qKiBTU1Igbm9uLXJlYWN0aXZlIGNyZWF0ZU11dGFibGVTdG9yZSAqL1xuZnVuY3Rpb24gY3JlYXRlTm9uUmVhY3RpdmVNdXRhYmxlU3RvcmUoaW5pdGlhbFZhbHVlKSB7XG5cdGxldCB2YWx1ZSA9IGluaXRpYWxWYWx1ZTtcblx0cmV0dXJuIHtcblx0XHRnZXQoKSB7XG5cdFx0XHRyZXR1cm4gdmFsdWU7XG5cdFx0fSxcblx0XHRzZXQobmV4dE9yVXBkYXRlcikge1xuXHRcdFx0dmFsdWUgPSBmdW5jdGlvbmFsVXBkYXRlKG5leHRPclVwZGF0ZXIsIHZhbHVlKTtcblx0XHR9XG5cdH07XG59XG4vKiogU1NSIG5vbi1yZWFjdGl2ZSBjcmVhdGVSZWFkb25seVN0b3JlICovXG5mdW5jdGlvbiBjcmVhdGVOb25SZWFjdGl2ZVJlYWRvbmx5U3RvcmUocmVhZCkge1xuXHRyZXR1cm4geyBnZXQoKSB7XG5cdFx0cmV0dXJuIHJlYWQoKTtcblx0fSB9O1xufVxuZnVuY3Rpb24gY3JlYXRlUm91dGVyU3RvcmVzKGluaXRpYWxMb2NhdGlvbiwgY29uZmlnKSB7XG5cdGNvbnN0IHsgY3JlYXRlTXV0YWJsZVN0b3JlLCBjcmVhdGVSZWFkb25seVN0b3JlLCBiYXRjaCB9ID0gY29uZmlnO1xuXHRjb25zdCBieVJvdXRlID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0Y29uc3Qgc3RhdHVzID0gY3JlYXRlTXV0YWJsZVN0b3JlKFwiaWRsZVwiKTtcblx0Y29uc3QgbG9jYXRpb24gPSBjcmVhdGVNdXRhYmxlU3RvcmUoaW5pdGlhbExvY2F0aW9uKTtcblx0Y29uc3QgcmVzb2x2ZWRMb2NhdGlvbiA9IGNyZWF0ZU11dGFibGVTdG9yZSh2b2lkIDApO1xuXHRjb25zdCBpZHMgPSBjcmVhdGVNdXRhYmxlU3RvcmUoW10pO1xuXHRjb25zdCBtYXRjaGVzID0gY3JlYXRlUmVhZG9ubHlTdG9yZSgoKSA9PiBpZHMuZ2V0KCkubWFwKChpZCkgPT4gYnlSb3V0ZS5nZXQoaWQpLmdldCgpKSk7XG5cdGNvbnN0IF9fc3RvcmUgPSBjcmVhdGVSZWFkb25seVN0b3JlKCgpID0+ICh7XG5cdFx0c3RhdHVzOiBzdGF0dXMuZ2V0KCksXG5cdFx0aXNMb2FkaW5nOiBzdGF0dXMuZ2V0KCkgPT09IFwicGVuZGluZ1wiLFxuXHRcdG1hdGNoZXM6IG1hdGNoZXMuZ2V0KCksXG5cdFx0bG9jYXRpb246IGxvY2F0aW9uLmdldCgpLFxuXHRcdHJlc29sdmVkTG9jYXRpb246IHJlc29sdmVkTG9jYXRpb24uZ2V0KClcblx0fSkpO1xuXHRmdW5jdGlvbiBnZXRNYXRjaFN0b3JlKHJvdXRlSWQpIHtcblx0XHRsZXQgbWF0Y2hTdG9yZSA9IGJ5Um91dGUuZ2V0KHJvdXRlSWQpO1xuXHRcdGlmICghbWF0Y2hTdG9yZSkge1xuXHRcdFx0bWF0Y2hTdG9yZSA9IGNyZWF0ZU11dGFibGVTdG9yZSh2b2lkIDApO1xuXHRcdFx0YnlSb3V0ZS5zZXQocm91dGVJZCwgbWF0Y2hTdG9yZSk7XG5cdFx0fVxuXHRcdHJldHVybiBtYXRjaFN0b3JlO1xuXHR9XG5cdGNvbnN0IHN0b3JlID0ge1xuXHRcdHN0YXR1cyxcblx0XHRsb2NhdGlvbixcblx0XHRyZXNvbHZlZExvY2F0aW9uLFxuXHRcdGlkcyxcblx0XHRtYXRjaGVzLFxuXHRcdGJ5Um91dGUsXG5cdFx0X19zdG9yZSxcblx0XHRnZXRNYXRjaFN0b3JlLFxuXHRcdHNldE1hdGNoZXNcblx0fTtcblx0ZnVuY3Rpb24gc2V0TWF0Y2hlcyhuZXh0TWF0Y2hlcykge1xuXHRcdGNvbnN0IHByZXZpb3VzSWRzID0gaWRzLmdldCgpO1xuXHRcdGNvbnN0IG5leHRJZHMgPSBuZXh0TWF0Y2hlcy5tYXAoKG1hdGNoKSA9PiBtYXRjaC5yb3V0ZUlkKTtcblx0XHRiYXRjaCgoKSA9PiB7XG5cdFx0XHRpZiAoIWFycmF5c0VxdWFsKHByZXZpb3VzSWRzLCBuZXh0SWRzKSkgaWRzLnNldChuZXh0SWRzKTtcblx0XHRcdGZvciAoY29uc3QgaWQgb2YgcHJldmlvdXNJZHMpIGlmICghbmV4dElkcy5pbmNsdWRlcyhpZCkpIGJ5Um91dGUuZ2V0KGlkKS5zZXQoKCkgPT4gdm9pZCAwKTtcblx0XHRcdGZvciAoY29uc3QgbmV4dE1hdGNoIG9mIG5leHRNYXRjaGVzKSB7XG5cdFx0XHRcdGNvbnN0IG1hdGNoU3RvcmUgPSBnZXRNYXRjaFN0b3JlKG5leHRNYXRjaC5yb3V0ZUlkKTtcblx0XHRcdFx0aWYgKG1hdGNoU3RvcmUuZ2V0KCkgIT09IG5leHRNYXRjaCkgbWF0Y2hTdG9yZS5zZXQobmV4dE1hdGNoKTtcblx0XHRcdH1cblx0XHR9KTtcblx0fVxuXHRyZXR1cm4gc3RvcmU7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNyZWF0ZU5vblJlYWN0aXZlTXV0YWJsZVN0b3JlLCBjcmVhdGVOb25SZWFjdGl2ZVJlYWRvbmx5U3RvcmUsIGNyZWF0ZVJvdXRlclN0b3JlcyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1zdG9yZXMuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9pbmRleC50c1xudmFyIHN0YXRlSW5kZXhLZXkgPSBcIl9fVFNSX2luZGV4XCI7XG52YXIgcG9wU3RhdGVFdmVudCA9IFwicG9wc3RhdGVcIjtcbnZhciBiZWZvcmVVbmxvYWRFdmVudCA9IFwiYmVmb3JldW5sb2FkXCI7XG4vKipcbiogVHVybiBwcm90b2NvbC1yZWxhdGl2ZSBpbnB1dHMgc3VjaCBhcyBcIi8vZXZpbC5leGFtcGxlXCIgaW50byBwYXRoc1xuKiBzdWNoIGFzIFwiL2V2aWwuZXhhbXBsZVwiLCBrZWVwaW5nIG5hdmlnYXRpb24gb24gdGhlIGN1cnJlbnQgb3JpZ2luLlxuKlxuKiBGb3IgSFRUUChTKSBVUkxzLCBXSEFUV0cgcGFyc2luZyBpZ25vcmVzIGxlYWRpbmcgQzAgY29udHJvbHMgYW5kIHNwYWNlcyxcbiogcmVtb3ZlcyB0YWJzL25ld2xpbmVzLCBhbmQgdHJlYXRzIGJhY2tzbGFzaGVzIGFzIHNsYXNoZXMsIHNvIGlucHV0cyBsaWtlXG4qIFwiL1xcZXZpbC5leGFtcGxlXCIgYWxzbyBuZWVkIG5vcm1hbGl6YXRpb24uIFRoaXMgb25seSBhbGxvY2F0ZXMgd2hlbiB0aG9zZVxuKiBydWxlcyB3b3VsZCBtYWtlIHRoZSBpbnB1dCBwcm90b2NvbC1yZWxhdGl2ZS5cbiovXG52YXIgcHJvdG9jb2xSZWxhdGl2ZVByZWZpeCA9IC9eW1xceDAwLVxceDIwXSooPzpbXFxcXC9dW1xcdFxcblxccl0qKXsyLH0vO1xuZnVuY3Rpb24gbm9ybWFsaXplUHJvdG9jb2xSZWxhdGl2ZSh1cmwpIHtcblx0Y29uc3QgbWF0Y2ggPSBwcm90b2NvbFJlbGF0aXZlUHJlZml4LmV4ZWModXJsKTtcblx0cmV0dXJuIG1hdGNoID8gXCIvXCIgKyB1cmwuc2xpY2UobWF0Y2hbMF0ubGVuZ3RoKSA6IHVybDtcbn1cbmZ1bmN0aW9uIG5vcm1hbGl6ZUhyZWYoaHJlZikge1xuXHRpZiAoL1tcXHgwMC1cXHgxZlxceDdmXS8udGVzdChocmVmKSkgaHJlZiA9IGhyZWYucmVwbGFjZSgvW1xceDAwLVxceDFmXFx4N2ZdL2csIChjaGFyYWN0ZXIpID0+IFwiXHRcXG5cXHJcIi5pbmNsdWRlcyhjaGFyYWN0ZXIpID8gXCJcIiA6IGVuY29kZVVSSUNvbXBvbmVudChjaGFyYWN0ZXIpKTtcblx0cmV0dXJuIG5vcm1hbGl6ZVByb3RvY29sUmVsYXRpdmUoaHJlZik7XG59XG5mdW5jdGlvbiBjcmVhdGVIaXN0b3J5KG9wdHMpIHtcblx0bGV0IGxvY2F0aW9uID0gb3B0cy5nZXRMb2NhdGlvbigpO1xuXHRjb25zdCBzdWJzY3JpYmVycyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdGNvbnN0IG5vdGlmeSA9IChhY3Rpb24pID0+IHtcblx0XHRsb2NhdGlvbiA9IG9wdHMuZ2V0TG9jYXRpb24oKTtcblx0XHRzdWJzY3JpYmVycy5mb3JFYWNoKChzdWJzY3JpYmVyKSA9PiBzdWJzY3JpYmVyKHtcblx0XHRcdGxvY2F0aW9uLFxuXHRcdFx0YWN0aW9uXG5cdFx0fSkpO1xuXHR9O1xuXHRjb25zdCBoYW5kbGVJbmRleENoYW5nZSA9IChhY3Rpb24pID0+IHtcblx0XHRpZiAob3B0cy5ub3RpZnlPbkluZGV4Q2hhbmdlID8/IHRydWUpIG5vdGlmeShhY3Rpb24pO1xuXHRcdGVsc2UgbG9jYXRpb24gPSBvcHRzLmdldExvY2F0aW9uKCk7XG5cdH07XG5cdGNvbnN0IHRyeU5hdmlnYXRpb24gPSBhc3luYyAoYXJncykgPT4ge1xuXHRcdGNvbnN0IGJsb2NrZXJzID0gYXJncy5uYXZpZ2F0ZU9wdHM/Lmlnbm9yZUJsb2NrZXIgPyB2b2lkIDAgOiBvcHRzLmdldEJsb2NrZXJzPy4oKTtcblx0XHRpZiAodHlwZW9mIGRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiICYmIGJsb2NrZXJzPy5sZW5ndGggJiYgKGFyZ3MudHlwZSA9PT0gXCJQVVNIXCIgfHwgYXJncy50eXBlID09PSBcIlJFUExBQ0VcIikpIGZvciAoY29uc3QgYmxvY2tlciBvZiBibG9ja2Vycykge1xuXHRcdFx0Y29uc3QgbmV4dExvY2F0aW9uID0gcGFyc2VIcmVmKGFyZ3MucGF0aCwgYXJncy5zdGF0ZSk7XG5cdFx0XHRpZiAoYXdhaXQgYmxvY2tlci5ibG9ja2VyRm4oe1xuXHRcdFx0XHRjdXJyZW50TG9jYXRpb246IGxvY2F0aW9uLFxuXHRcdFx0XHRuZXh0TG9jYXRpb24sXG5cdFx0XHRcdGFjdGlvbjogYXJncy50eXBlXG5cdFx0XHR9KSkge1xuXHRcdFx0XHRvcHRzLm9uQmxvY2tlZD8uKCk7XG5cdFx0XHRcdHJldHVybjtcblx0XHRcdH1cblx0XHR9XG5cdFx0YXJncy50YXNrKCk7XG5cdH07XG5cdHJldHVybiB7XG5cdFx0Z2V0IGxvY2F0aW9uKCkge1xuXHRcdFx0cmV0dXJuIGxvY2F0aW9uO1xuXHRcdH0sXG5cdFx0Z2V0IGxlbmd0aCgpIHtcblx0XHRcdHJldHVybiBvcHRzLmdldExlbmd0aCgpO1xuXHRcdH0sXG5cdFx0c3Vic2NyaWJlcnMsXG5cdFx0c3Vic2NyaWJlOiAoY2IpID0+IHtcblx0XHRcdHN1YnNjcmliZXJzLmFkZChjYik7XG5cdFx0XHRyZXR1cm4gKCkgPT4ge1xuXHRcdFx0XHRzdWJzY3JpYmVycy5kZWxldGUoY2IpO1xuXHRcdFx0fTtcblx0XHR9LFxuXHRcdHB1c2g6IChwYXRoLCBzdGF0ZSwgbmF2aWdhdGVPcHRzKSA9PiB7XG5cdFx0XHRjb25zdCBjdXJyZW50SW5kZXggPSBsb2NhdGlvbi5zdGF0ZVtzdGF0ZUluZGV4S2V5XTtcblx0XHRcdHN0YXRlID0gYXNzaWduS2V5QW5kSW5kZXgoY3VycmVudEluZGV4ICsgMSwgc3RhdGUpO1xuXHRcdFx0dHJ5TmF2aWdhdGlvbih7XG5cdFx0XHRcdHRhc2s6ICgpID0+IHtcblx0XHRcdFx0XHRvcHRzLnB1c2hTdGF0ZShwYXRoLCBzdGF0ZSk7XG5cdFx0XHRcdFx0bm90aWZ5KHsgdHlwZTogXCJQVVNIXCIgfSk7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdG5hdmlnYXRlT3B0cyxcblx0XHRcdFx0dHlwZTogXCJQVVNIXCIsXG5cdFx0XHRcdHBhdGgsXG5cdFx0XHRcdHN0YXRlXG5cdFx0XHR9KTtcblx0XHR9LFxuXHRcdHJlcGxhY2U6IChwYXRoLCBzdGF0ZSwgbmF2aWdhdGVPcHRzKSA9PiB7XG5cdFx0XHRjb25zdCBjdXJyZW50SW5kZXggPSBsb2NhdGlvbi5zdGF0ZVtzdGF0ZUluZGV4S2V5XTtcblx0XHRcdHN0YXRlID0gYXNzaWduS2V5QW5kSW5kZXgoY3VycmVudEluZGV4LCBzdGF0ZSk7XG5cdFx0XHR0cnlOYXZpZ2F0aW9uKHtcblx0XHRcdFx0dGFzazogKCkgPT4ge1xuXHRcdFx0XHRcdG9wdHMucmVwbGFjZVN0YXRlKHBhdGgsIHN0YXRlKTtcblx0XHRcdFx0XHRub3RpZnkoeyB0eXBlOiBcIlJFUExBQ0VcIiB9KTtcblx0XHRcdFx0fSxcblx0XHRcdFx0bmF2aWdhdGVPcHRzLFxuXHRcdFx0XHR0eXBlOiBcIlJFUExBQ0VcIixcblx0XHRcdFx0cGF0aCxcblx0XHRcdFx0c3RhdGVcblx0XHRcdH0pO1xuXHRcdH0sXG5cdFx0Z286IChpbmRleCwgbmF2aWdhdGVPcHRzKSA9PiB7XG5cdFx0XHR0cnlOYXZpZ2F0aW9uKHtcblx0XHRcdFx0dGFzazogKCkgPT4ge1xuXHRcdFx0XHRcdG9wdHMuZ28oaW5kZXgsIG5hdmlnYXRlT3B0cz8uaWdub3JlQmxvY2tlciA/PyBmYWxzZSk7XG5cdFx0XHRcdFx0aGFuZGxlSW5kZXhDaGFuZ2Uoe1xuXHRcdFx0XHRcdFx0dHlwZTogXCJHT1wiLFxuXHRcdFx0XHRcdFx0aW5kZXhcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0fSxcblx0XHRcdFx0bmF2aWdhdGVPcHRzLFxuXHRcdFx0XHR0eXBlOiBcIkdPXCJcblx0XHRcdH0pO1xuXHRcdH0sXG5cdFx0YmFjazogKG5hdmlnYXRlT3B0cykgPT4ge1xuXHRcdFx0dHJ5TmF2aWdhdGlvbih7XG5cdFx0XHRcdHRhc2s6ICgpID0+IHtcblx0XHRcdFx0XHRvcHRzLmJhY2sobmF2aWdhdGVPcHRzPy5pZ25vcmVCbG9ja2VyID8/IGZhbHNlKTtcblx0XHRcdFx0XHRoYW5kbGVJbmRleENoYW5nZSh7IHR5cGU6IFwiQkFDS1wiIH0pO1xuXHRcdFx0XHR9LFxuXHRcdFx0XHRuYXZpZ2F0ZU9wdHMsXG5cdFx0XHRcdHR5cGU6IFwiQkFDS1wiXG5cdFx0XHR9KTtcblx0XHR9LFxuXHRcdGZvcndhcmQ6IChuYXZpZ2F0ZU9wdHMpID0+IHtcblx0XHRcdHRyeU5hdmlnYXRpb24oe1xuXHRcdFx0XHR0YXNrOiAoKSA9PiB7XG5cdFx0XHRcdFx0b3B0cy5mb3J3YXJkKG5hdmlnYXRlT3B0cz8uaWdub3JlQmxvY2tlciA/PyBmYWxzZSk7XG5cdFx0XHRcdFx0aGFuZGxlSW5kZXhDaGFuZ2UoeyB0eXBlOiBcIkZPUldBUkRcIiB9KTtcblx0XHRcdFx0fSxcblx0XHRcdFx0bmF2aWdhdGVPcHRzLFxuXHRcdFx0XHR0eXBlOiBcIkZPUldBUkRcIlxuXHRcdFx0fSk7XG5cdFx0fSxcblx0XHRjYW5Hb0JhY2s6ICgpID0+IGxvY2F0aW9uLnN0YXRlW3N0YXRlSW5kZXhLZXldICE9PSAwLFxuXHRcdGNyZWF0ZUhyZWY6IChzdHIpID0+IG9wdHMuY3JlYXRlSHJlZihzdHIpLFxuXHRcdGJsb2NrOiAoYmxvY2tlcikgPT4ge1xuXHRcdFx0aWYgKCFvcHRzLnNldEJsb2NrZXJzKSByZXR1cm4gKCkgPT4ge307XG5cdFx0XHRjb25zdCBibG9ja2VycyA9IG9wdHMuZ2V0QmxvY2tlcnM/LigpID8/IFtdO1xuXHRcdFx0b3B0cy5zZXRCbG9ja2VycyhbLi4uYmxvY2tlcnMsIGJsb2NrZXJdKTtcblx0XHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRcdGNvbnN0IGJsb2NrZXJzID0gb3B0cy5nZXRCbG9ja2Vycz8uKCkgPz8gW107XG5cdFx0XHRcdG9wdHMuc2V0QmxvY2tlcnM/LihibG9ja2Vycy5maWx0ZXIoKGIpID0+IGIgIT09IGJsb2NrZXIpKTtcblx0XHRcdH07XG5cdFx0fSxcblx0XHRmbHVzaDogKCkgPT4gb3B0cy5mbHVzaD8uKCksXG5cdFx0ZGVzdHJveTogKCkgPT4gb3B0cy5kZXN0cm95Py4oKSxcblx0XHRub3RpZnksXG5cdFx0X2dldEJsb2NrZXJzOiAoKSA9PiBvcHRzLmdldEJsb2NrZXJzPy4oKSA/PyBbXVxuXHR9O1xufVxuZnVuY3Rpb24gYXNzaWduS2V5QW5kSW5kZXgoaW5kZXgsIHN0YXRlKSB7XG5cdGNvbnN0IGtleSA9IGNyZWF0ZVJhbmRvbUtleSgpO1xuXHRyZXR1cm4ge1xuXHRcdC4uLnN0YXRlLFxuXHRcdGtleSxcblx0XHRfX1RTUl9rZXk6IGtleSxcblx0XHRbc3RhdGVJbmRleEtleV06IGluZGV4XG5cdH07XG59XG4vKipcbiogQ3JlYXRlcyBhIGhpc3Rvcnkgb2JqZWN0IHRoYXQgY2FuIGJlIHVzZWQgdG8gaW50ZXJhY3Qgd2l0aCB0aGUgYnJvd3NlcidzXG4qIG5hdmlnYXRpb24uIFRoaXMgaXMgYSBsaWdodHdlaWdodCBBUEkgd3JhcHBpbmcgdGhlIGJyb3dzZXIncyBuYXRpdmUgbWV0aG9kcy5cbiogSXQgaXMgZGVzaWduZWQgdG8gd29yayB3aXRoIFRhblN0YWNrIFJvdXRlciwgYnV0IGNvdWxkIGJlIHVzZWQgYXMgYSBzdGFuZGFsb25lIEFQSSBhcyB3ZWxsLlxuKiBJTVBPUlRBTlQ6IFRoaXMgQVBJIGltcGxlbWVudHMgaGlzdG9yeSB0aHJvdHRsaW5nIHZpYSBhIG1pY3JvdGFzayB0byBwcmV2ZW50XG4qIGV4Y2Vzc2l2ZSBjYWxscyB0byB0aGUgaGlzdG9yeSBBUEkuIEluIHNvbWUgYnJvd3NlcnMsIGNhbGxpbmcgaGlzdG9yeS5wdXNoU3RhdGUgb3JcbiogaGlzdG9yeS5yZXBsYWNlU3RhdGUgaW4gcXVpY2sgc3VjY2Vzc2lvbiBjYW4gY2F1c2UgdGhlIGJyb3dzZXIgdG8gaWdub3JlIHN1YnNlcXVlbnRcbiogY2FsbHMuIFRoaXMgQVBJIHNtb290aHMgb3V0IHRob3NlIGRpZmZlcmVuY2VzIGFuZCBlbnN1cmVzIHRoYXQgeW91ciBhcHBsaWNhdGlvblxuKiBzdGF0ZSB3aWxsICpldmVudHVhbGx5KiBtYXRjaCB0aGUgYnJvd3NlciBzdGF0ZS4gSW4gbW9zdCBjYXNlcywgdGhpcyBpcyBub3QgYSBwcm9ibGVtLFxuKiBidXQgaWYgeW91IG5lZWQgdG8gZW5zdXJlIHRoYXQgdGhlIGJyb3dzZXIgc3RhdGUgaXMgdXAgdG8gZGF0ZSwgeW91IGNhbiB1c2UgdGhlXG4qIGBoaXN0b3J5LmZsdXNoYCBtZXRob2QgdG8gaW1tZWRpYXRlbHkgZmx1c2ggYWxsIHBlbmRpbmcgc3RhdGUgY2hhbmdlcyB0byB0aGUgYnJvd3NlciBVUkwuXG4qIEBwYXJhbSBvcHRzXG4qIEBwYXJhbSBvcHRzLmdldEhyZWYgQSBmdW5jdGlvbiB0aGF0IHJldHVybnMgdGhlIGN1cnJlbnQgaHJlZiAocGF0aCArIHNlYXJjaCArIGhhc2gpXG4qIEBwYXJhbSBvcHRzLmNyZWF0ZUhyZWYgQSBmdW5jdGlvbiB0aGF0IHRha2VzIGEgcGF0aCBhbmQgcmV0dXJucyBhIGhyZWYgKHBhdGggKyBzZWFyY2ggKyBoYXNoKVxuKiBAcmV0dXJucyBBIGhpc3RvcnkgaW5zdGFuY2VcbiovXG5mdW5jdGlvbiBjcmVhdGVCcm93c2VySGlzdG9yeShvcHRzKSB7XG5cdGNvbnN0IHdpbiA9IG9wdHM/LndpbmRvdyA/PyAodHlwZW9mIGRvY3VtZW50ICE9PSBcInVuZGVmaW5lZFwiID8gd2luZG93IDogdm9pZCAwKTtcblx0Y29uc3Qgb3JpZ2luYWxQdXNoU3RhdGUgPSB3aW4uaGlzdG9yeS5wdXNoU3RhdGU7XG5cdGNvbnN0IG9yaWdpbmFsUmVwbGFjZVN0YXRlID0gd2luLmhpc3RvcnkucmVwbGFjZVN0YXRlO1xuXHRsZXQgYmxvY2tlcnMgPSBbXTtcblx0Y29uc3QgX2dldEJsb2NrZXJzID0gKCkgPT4gYmxvY2tlcnM7XG5cdGNvbnN0IF9zZXRCbG9ja2VycyA9IChuZXdCbG9ja2VycykgPT4gYmxvY2tlcnMgPSBuZXdCbG9ja2Vycztcblx0Y29uc3QgY3JlYXRlSHJlZiA9IChwYXRoKSA9PiBub3JtYWxpemVIcmVmKG9wdHM/LmNyZWF0ZUhyZWYgPyBvcHRzLmNyZWF0ZUhyZWYocGF0aCkgOiBwYXRoKTtcblx0Y29uc3QgcGFyc2VMb2NhdGlvbiA9IG9wdHM/LnBhcnNlTG9jYXRpb24gPz8gKCgpID0+IHBhcnNlSHJlZihgJHt3aW4ubG9jYXRpb24ucGF0aG5hbWV9JHt3aW4ubG9jYXRpb24uc2VhcmNofSR7d2luLmxvY2F0aW9uLmhhc2h9YCwgd2luLmhpc3Rvcnkuc3RhdGUpKTtcblx0aWYgKCF3aW4uaGlzdG9yeS5zdGF0ZT8uX19UU1Jfa2V5ICYmICF3aW4uaGlzdG9yeS5zdGF0ZT8ua2V5KSB7XG5cdFx0Y29uc3QgYWRkZWRLZXkgPSBjcmVhdGVSYW5kb21LZXkoKTtcblx0XHR3aW4uaGlzdG9yeS5yZXBsYWNlU3RhdGUoe1xuXHRcdFx0W3N0YXRlSW5kZXhLZXldOiAwLFxuXHRcdFx0a2V5OiBhZGRlZEtleSxcblx0XHRcdF9fVFNSX2tleTogYWRkZWRLZXlcblx0XHR9LCBcIlwiKTtcblx0fVxuXHRsZXQgY3VycmVudExvY2F0aW9uID0gcGFyc2VMb2NhdGlvbigpO1xuXHRsZXQgcm9sbGJhY2tMb2NhdGlvbjtcblx0bGV0IG5leHRQb3BJc0dvID0gZmFsc2U7XG5cdGxldCBpZ25vcmVOZXh0UG9wID0gZmFsc2U7XG5cdGxldCBza2lwQmxvY2tlck5leHRQb3AgPSBmYWxzZTtcblx0bGV0IGlnbm9yZU5leHRCZWZvcmVVbmxvYWQgPSBmYWxzZTtcblx0Y29uc3QgZ2V0TG9jYXRpb24gPSAoKSA9PiBjdXJyZW50TG9jYXRpb247XG5cdGxldCBuZXh0O1xuXHRjb25zdCBmbHVzaCA9ICgpID0+IHtcblx0XHRpZiAoIW5leHQpIHJldHVybjtcblx0XHRoaXN0b3J5Ll9pZ25vcmVTdWJzY3JpYmVycyA9IHRydWU7XG5cdFx0KG5leHRbMl0gPyB3aW4uaGlzdG9yeS5wdXNoU3RhdGUgOiB3aW4uaGlzdG9yeS5yZXBsYWNlU3RhdGUpKG5leHRbMV0sIFwiXCIsIG5leHRbMF0pO1xuXHRcdGhpc3RvcnkuX2lnbm9yZVN1YnNjcmliZXJzID0gZmFsc2U7XG5cdFx0bmV4dCA9IHZvaWQgMDtcblx0XHRyb2xsYmFja0xvY2F0aW9uID0gdm9pZCAwO1xuXHR9O1xuXHRjb25zdCBxdWV1ZUhpc3RvcnlBY3Rpb24gPSAoaXNQdXNoLCBkZXN0SHJlZiwgc3RhdGUpID0+IHtcblx0XHRjb25zdCBocmVmID0gb3B0cz8uY3JlYXRlSHJlZiA/IGNyZWF0ZUhyZWYoZGVzdEhyZWYpIDogdm9pZCAwO1xuXHRcdGNvbnN0IGhhc1BlbmRpbmdBY3Rpb24gPSAhIW5leHQ7XG5cdFx0aWYgKCFoYXNQZW5kaW5nQWN0aW9uKSByb2xsYmFja0xvY2F0aW9uID0gY3VycmVudExvY2F0aW9uO1xuXHRcdGN1cnJlbnRMb2NhdGlvbiA9IHBhcnNlSHJlZihkZXN0SHJlZiwgc3RhdGUpO1xuXHRcdG5leHQgPSBbXG5cdFx0XHRocmVmID8/IGN1cnJlbnRMb2NhdGlvbi5ocmVmLFxuXHRcdFx0c3RhdGUsXG5cdFx0XHRuZXh0Py5bMl0gfHwgaXNQdXNoXG5cdFx0XTtcblx0XHRpZiAoIWhhc1BlbmRpbmdBY3Rpb24pIHF1ZXVlTWljcm90YXNrKCgpID0+IGZsdXNoKCkpO1xuXHR9O1xuXHRjb25zdCBvblB1c2hQb3AgPSAodHlwZSkgPT4ge1xuXHRcdGN1cnJlbnRMb2NhdGlvbiA9IHBhcnNlTG9jYXRpb24oKTtcblx0XHRoaXN0b3J5Lm5vdGlmeSh7IHR5cGUgfSk7XG5cdH07XG5cdGNvbnN0IG9uUHVzaFBvcEV2ZW50ID0gYXN5bmMgKCkgPT4ge1xuXHRcdGlnbm9yZU5leHRCZWZvcmVVbmxvYWQgPSBmYWxzZTtcblx0XHRpZiAoaWdub3JlTmV4dFBvcCkge1xuXHRcdFx0aWdub3JlTmV4dFBvcCA9IGZhbHNlO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRjb25zdCBuZXh0TG9jYXRpb24gPSBwYXJzZUxvY2F0aW9uKCk7XG5cdFx0Y29uc3QgZGVsdGEgPSBuZXh0TG9jYXRpb24uc3RhdGVbc3RhdGVJbmRleEtleV0gLSBjdXJyZW50TG9jYXRpb24uc3RhdGVbc3RhdGVJbmRleEtleV07XG5cdFx0Y29uc3QgaXNGb3J3YXJkID0gZGVsdGEgPT09IDE7XG5cdFx0Y29uc3QgaXNCYWNrID0gZGVsdGEgPT09IC0xO1xuXHRcdGNvbnN0IGlzR28gPSAhaXNGb3J3YXJkICYmICFpc0JhY2sgfHwgbmV4dFBvcElzR287XG5cdFx0bmV4dFBvcElzR28gPSBmYWxzZTtcblx0XHRjb25zdCBhY3Rpb24gPSBpc0dvID8gXCJHT1wiIDogaXNCYWNrID8gXCJCQUNLXCIgOiBcIkZPUldBUkRcIjtcblx0XHRjb25zdCBub3RpZnkgPSBpc0dvID8ge1xuXHRcdFx0dHlwZTogXCJHT1wiLFxuXHRcdFx0aW5kZXg6IGRlbHRhXG5cdFx0fSA6IHsgdHlwZTogaXNCYWNrID8gXCJCQUNLXCIgOiBcIkZPUldBUkRcIiB9O1xuXHRcdGlmIChza2lwQmxvY2tlck5leHRQb3ApIHNraXBCbG9ja2VyTmV4dFBvcCA9IGZhbHNlO1xuXHRcdGVsc2Uge1xuXHRcdFx0Y29uc3QgYmxvY2tlcnMgPSBfZ2V0QmxvY2tlcnMoKTtcblx0XHRcdGlmICh0eXBlb2YgZG9jdW1lbnQgIT09IFwidW5kZWZpbmVkXCIgJiYgYmxvY2tlcnMubGVuZ3RoKSB7XG5cdFx0XHRcdGZvciAoY29uc3QgYmxvY2tlciBvZiBibG9ja2VycykgaWYgKGF3YWl0IGJsb2NrZXIuYmxvY2tlckZuKHtcblx0XHRcdFx0XHRjdXJyZW50TG9jYXRpb24sXG5cdFx0XHRcdFx0bmV4dExvY2F0aW9uLFxuXHRcdFx0XHRcdGFjdGlvblxuXHRcdFx0XHR9KSkge1xuXHRcdFx0XHRcdGlnbm9yZU5leHRQb3AgPSB0cnVlO1xuXHRcdFx0XHRcdHdpbi5oaXN0b3J5LmdvKC1kZWx0YSk7XG5cdFx0XHRcdFx0aGlzdG9yeS5ub3RpZnkobm90aWZ5KTtcblx0XHRcdFx0XHRyZXR1cm47XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdFx0Y3VycmVudExvY2F0aW9uID0gcGFyc2VMb2NhdGlvbigpO1xuXHRcdGhpc3Rvcnkubm90aWZ5KG5vdGlmeSk7XG5cdH07XG5cdGNvbnN0IG9uQmVmb3JlVW5sb2FkID0gKGUpID0+IHtcblx0XHRpZiAoaWdub3JlTmV4dEJlZm9yZVVubG9hZCkge1xuXHRcdFx0aWdub3JlTmV4dEJlZm9yZVVubG9hZCA9IGZhbHNlO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRsZXQgc2hvdWxkQmxvY2sgPSBmYWxzZTtcblx0XHRjb25zdCBibG9ja2VycyA9IF9nZXRCbG9ja2VycygpO1xuXHRcdGlmICh0eXBlb2YgZG9jdW1lbnQgIT09IFwidW5kZWZpbmVkXCIgJiYgYmxvY2tlcnMubGVuZ3RoKSBmb3IgKGNvbnN0IGJsb2NrZXIgb2YgYmxvY2tlcnMpIHtcblx0XHRcdGNvbnN0IHNob3VsZEhhdmVCZWZvcmVVbmxvYWQgPSBibG9ja2VyLmVuYWJsZUJlZm9yZVVubG9hZCA/PyB0cnVlO1xuXHRcdFx0aWYgKHNob3VsZEhhdmVCZWZvcmVVbmxvYWQgPT09IHRydWUpIHtcblx0XHRcdFx0c2hvdWxkQmxvY2sgPSB0cnVlO1xuXHRcdFx0XHRicmVhaztcblx0XHRcdH1cblx0XHRcdGlmICh0eXBlb2Ygc2hvdWxkSGF2ZUJlZm9yZVVubG9hZCA9PT0gXCJmdW5jdGlvblwiICYmIHNob3VsZEhhdmVCZWZvcmVVbmxvYWQoKSA9PT0gdHJ1ZSkge1xuXHRcdFx0XHRzaG91bGRCbG9jayA9IHRydWU7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZiAoc2hvdWxkQmxvY2spIHtcblx0XHRcdGUucHJldmVudERlZmF1bHQoKTtcblx0XHRcdHJldHVybiBlLnJldHVyblZhbHVlID0gXCJcIjtcblx0XHR9XG5cdH07XG5cdGNvbnN0IGhpc3RvcnkgPSBjcmVhdGVIaXN0b3J5KHtcblx0XHRnZXRMb2NhdGlvbixcblx0XHRnZXRMZW5ndGg6ICgpID0+IHdpbi5oaXN0b3J5Lmxlbmd0aCxcblx0XHRwdXNoU3RhdGU6IChocmVmLCBzdGF0ZSkgPT4gcXVldWVIaXN0b3J5QWN0aW9uKHRydWUsIGhyZWYsIHN0YXRlKSxcblx0XHRyZXBsYWNlU3RhdGU6IChocmVmLCBzdGF0ZSkgPT4gcXVldWVIaXN0b3J5QWN0aW9uKGZhbHNlLCBocmVmLCBzdGF0ZSksXG5cdFx0YmFjazogKGlnbm9yZUJsb2NrZXIpID0+IHtcblx0XHRcdGlmIChpZ25vcmVCbG9ja2VyKSB7XG5cdFx0XHRcdHNraXBCbG9ja2VyTmV4dFBvcCA9IHRydWU7XG5cdFx0XHRcdGlnbm9yZU5leHRCZWZvcmVVbmxvYWQgPSB0cnVlO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHdpbi5oaXN0b3J5LmJhY2soKTtcblx0XHR9LFxuXHRcdGZvcndhcmQ6IChpZ25vcmVCbG9ja2VyKSA9PiB7XG5cdFx0XHRpZiAoaWdub3JlQmxvY2tlcikge1xuXHRcdFx0XHRza2lwQmxvY2tlck5leHRQb3AgPSB0cnVlO1xuXHRcdFx0XHRpZ25vcmVOZXh0QmVmb3JlVW5sb2FkID0gdHJ1ZTtcblx0XHRcdH1cblx0XHRcdHdpbi5oaXN0b3J5LmZvcndhcmQoKTtcblx0XHR9LFxuXHRcdGdvOiAobiwgaWdub3JlQmxvY2tlcikgPT4ge1xuXHRcdFx0bmV4dFBvcElzR28gPSB0cnVlO1xuXHRcdFx0aWYgKGlnbm9yZUJsb2NrZXIpIHtcblx0XHRcdFx0c2tpcEJsb2NrZXJOZXh0UG9wID0gdHJ1ZTtcblx0XHRcdFx0aWdub3JlTmV4dEJlZm9yZVVubG9hZCA9IHRydWU7XG5cdFx0XHR9XG5cdFx0XHR3aW4uaGlzdG9yeS5nbyhuKTtcblx0XHR9LFxuXHRcdGNyZWF0ZUhyZWYsXG5cdFx0Zmx1c2gsXG5cdFx0ZGVzdHJveTogKCkgPT4ge1xuXHRcdFx0d2luLmhpc3RvcnkucHVzaFN0YXRlID0gb3JpZ2luYWxQdXNoU3RhdGU7XG5cdFx0XHR3aW4uaGlzdG9yeS5yZXBsYWNlU3RhdGUgPSBvcmlnaW5hbFJlcGxhY2VTdGF0ZTtcblx0XHRcdHdpbi5yZW1vdmVFdmVudExpc3RlbmVyKGJlZm9yZVVubG9hZEV2ZW50LCBvbkJlZm9yZVVubG9hZCwgeyBjYXB0dXJlOiB0cnVlIH0pO1xuXHRcdFx0d2luLnJlbW92ZUV2ZW50TGlzdGVuZXIocG9wU3RhdGVFdmVudCwgb25QdXNoUG9wRXZlbnQpO1xuXHRcdH0sXG5cdFx0b25CbG9ja2VkOiAoKSA9PiB7XG5cdFx0XHRpZiAocm9sbGJhY2tMb2NhdGlvbiAmJiBjdXJyZW50TG9jYXRpb24gIT09IHJvbGxiYWNrTG9jYXRpb24pIGN1cnJlbnRMb2NhdGlvbiA9IHJvbGxiYWNrTG9jYXRpb247XG5cdFx0fSxcblx0XHRnZXRCbG9ja2VyczogX2dldEJsb2NrZXJzLFxuXHRcdHNldEJsb2NrZXJzOiBfc2V0QmxvY2tlcnMsXG5cdFx0bm90aWZ5T25JbmRleENoYW5nZTogZmFsc2Vcblx0fSk7XG5cdGhpc3RvcnkuX2lnbm9yZU5leHRCZWZvcmVVbmxvYWQgPSAoaHJlZikgPT4ge1xuXHRcdGlnbm9yZU5leHRCZWZvcmVVbmxvYWQgPSBmYWxzZTtcblx0XHR0cnkge1xuXHRcdFx0aHJlZiA9IG5ldyBVUkwoaHJlZiwgd2luLmRvY3VtZW50LmJhc2VVUkkpLmhyZWY7XG5cdFx0XHRpZ25vcmVOZXh0QmVmb3JlVW5sb2FkID0gL15odHRwcz86Ly50ZXN0KGhyZWYpICYmICghaHJlZi5pbmNsdWRlcyhcIiNcIikgfHwgaHJlZi5zcGxpdChcIiNcIilbMF0gIT09IHdpbi5sb2NhdGlvbi5ocmVmLnNwbGl0KFwiI1wiKVswXSk7XG5cdFx0fSBjYXRjaCB7fVxuXHR9O1xuXHR3aW4uYWRkRXZlbnRMaXN0ZW5lcihiZWZvcmVVbmxvYWRFdmVudCwgb25CZWZvcmVVbmxvYWQsIHsgY2FwdHVyZTogdHJ1ZSB9KTtcblx0d2luLmFkZEV2ZW50TGlzdGVuZXIocG9wU3RhdGVFdmVudCwgb25QdXNoUG9wRXZlbnQpO1xuXHR3aW4uaGlzdG9yeS5wdXNoU3RhdGUgPSBmdW5jdGlvbiguLi5hcmdzKSB7XG5cdFx0Y29uc3QgcmVzID0gb3JpZ2luYWxQdXNoU3RhdGUuYXBwbHkod2luLmhpc3RvcnksIGFyZ3MpO1xuXHRcdGlmICghaGlzdG9yeS5faWdub3JlU3Vic2NyaWJlcnMpIG9uUHVzaFBvcChcIlBVU0hcIik7XG5cdFx0cmV0dXJuIHJlcztcblx0fTtcblx0d2luLmhpc3RvcnkucmVwbGFjZVN0YXRlID0gZnVuY3Rpb24oLi4uYXJncykge1xuXHRcdGNvbnN0IHJlcyA9IG9yaWdpbmFsUmVwbGFjZVN0YXRlLmFwcGx5KHdpbi5oaXN0b3J5LCBhcmdzKTtcblx0XHRpZiAoIWhpc3RvcnkuX2lnbm9yZVN1YnNjcmliZXJzKSBvblB1c2hQb3AoXCJSRVBMQUNFXCIpO1xuXHRcdHJldHVybiByZXM7XG5cdH07XG5cdHJldHVybiBoaXN0b3J5O1xufVxuLyoqXG4qIENyZWF0ZSBhIGhhc2gtYmFzZWQgaGlzdG9yeSBpbXBsZW1lbnRhdGlvbi5cbiogVXNlZnVsIGZvciBzdGF0aWMgaG9zdHMgb3IgZW52aXJvbm1lbnRzIHdpdGhvdXQgc2VydmVyIFVSTCByZXdyaXRpbmcuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvZ3VpZGUvaGlzdG9yeS10eXBlc1xuKi9cbmZ1bmN0aW9uIGNyZWF0ZUhhc2hIaXN0b3J5KG9wdHMpIHtcblx0Y29uc3Qgd2luID0gb3B0cz8ud2luZG93ID8/ICh0eXBlb2YgZG9jdW1lbnQgIT09IFwidW5kZWZpbmVkXCIgPyB3aW5kb3cgOiB2b2lkIDApO1xuXHRyZXR1cm4gY3JlYXRlQnJvd3Nlckhpc3Rvcnkoe1xuXHRcdHdpbmRvdzogd2luLFxuXHRcdHBhcnNlTG9jYXRpb246ICgpID0+IHtcblx0XHRcdGNvbnN0IGhhc2ggPSB3aW4ubG9jYXRpb24uaGFzaDtcblx0XHRcdGxldCBoYXNoSW5kZXggPSBoYXNoLmluZGV4T2YoXCIjXCIsIDEpO1xuXHRcdFx0aWYgKGhhc2hJbmRleCA8IDApIGhhc2hJbmRleCA9IGhhc2gubGVuZ3RoO1xuXHRcdFx0cmV0dXJuIHBhcnNlSHJlZihgJHtoYXNoID8gaGFzaC5zbGljZSgxLCBoYXNoSW5kZXgpIDogXCIvXCJ9JHt3aW4ubG9jYXRpb24uc2VhcmNofSR7aGFzaC5zbGljZShoYXNoSW5kZXgpfWAsIHdpbi5oaXN0b3J5LnN0YXRlKTtcblx0XHR9LFxuXHRcdGNyZWF0ZUhyZWY6IChocmVmKSA9PiBgJHt3aW4ubG9jYXRpb24ucGF0aG5hbWV9JHt3aW4ubG9jYXRpb24uc2VhcmNofSMke2hyZWZ9YFxuXHR9KTtcbn1cbi8qKlxuKiBDcmVhdGUgYW4gaW4tbWVtb3J5IGhpc3RvcnkgaW1wbGVtZW50YXRpb24uXG4qIElkZWFsIGZvciBzZXJ2ZXIgcmVuZGVyaW5nLCB0ZXN0cywgYW5kIG5vbi1ET00gZW52aXJvbm1lbnRzLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2d1aWRlL2hpc3RvcnktdHlwZXNcbiovXG5mdW5jdGlvbiBjcmVhdGVNZW1vcnlIaXN0b3J5KG9wdHMgPSB7IGluaXRpYWxFbnRyaWVzOiBbXCIvXCJdIH0pIHtcblx0Y29uc3QgZW50cmllcyA9IG9wdHMuaW5pdGlhbEVudHJpZXM7XG5cdGxldCBpbmRleCA9IG9wdHMuaW5pdGlhbEluZGV4ID8gTWF0aC5taW4oTWF0aC5tYXgob3B0cy5pbml0aWFsSW5kZXgsIDApLCBlbnRyaWVzLmxlbmd0aCAtIDEpIDogZW50cmllcy5sZW5ndGggLSAxO1xuXHRjb25zdCBzdGF0ZXMgPSBlbnRyaWVzLm1hcCgoX2VudHJ5LCBpbmRleCkgPT4gYXNzaWduS2V5QW5kSW5kZXgoaW5kZXgsIHZvaWQgMCkpO1xuXHRjb25zdCBnZXRMb2NhdGlvbiA9ICgpID0+IHBhcnNlSHJlZihlbnRyaWVzW2luZGV4XSwgc3RhdGVzW2luZGV4XSk7XG5cdGxldCBibG9ja2VycyA9IFtdO1xuXHRjb25zdCBfZ2V0QmxvY2tlcnMgPSAoKSA9PiBibG9ja2Vycztcblx0Y29uc3QgX3NldEJsb2NrZXJzID0gKG5ld0Jsb2NrZXJzKSA9PiBibG9ja2VycyA9IG5ld0Jsb2NrZXJzO1xuXHRyZXR1cm4gY3JlYXRlSGlzdG9yeSh7XG5cdFx0Z2V0TG9jYXRpb24sXG5cdFx0Z2V0TGVuZ3RoOiAoKSA9PiBlbnRyaWVzLmxlbmd0aCxcblx0XHRwdXNoU3RhdGU6IChwYXRoLCBzdGF0ZSkgPT4ge1xuXHRcdFx0aW5kZXggPSBpbmRleCA8IGVudHJpZXMubGVuZ3RoIC0gMSA/IGluZGV4ICsgMSA6IGVudHJpZXMubGVuZ3RoO1xuXHRcdFx0c3RhdGVzW2luZGV4XSA9IHN0YXRlO1xuXHRcdFx0ZW50cmllc1tpbmRleF0gPSBwYXRoO1xuXHRcdFx0aWYgKGluZGV4IDwgZW50cmllcy5sZW5ndGggLSAxKSB7XG5cdFx0XHRcdGVudHJpZXMubGVuZ3RoID0gaW5kZXggKyAxO1xuXHRcdFx0XHRzdGF0ZXMubGVuZ3RoID0gaW5kZXggKyAxO1xuXHRcdFx0fVxuXHRcdH0sXG5cdFx0cmVwbGFjZVN0YXRlOiAocGF0aCwgc3RhdGUpID0+IHtcblx0XHRcdHN0YXRlc1tpbmRleF0gPSBzdGF0ZTtcblx0XHRcdGVudHJpZXNbaW5kZXhdID0gcGF0aDtcblx0XHR9LFxuXHRcdGJhY2s6ICgpID0+IHtcblx0XHRcdGluZGV4ID0gTWF0aC5tYXgoaW5kZXggLSAxLCAwKTtcblx0XHR9LFxuXHRcdGZvcndhcmQ6ICgpID0+IHtcblx0XHRcdGluZGV4ID0gTWF0aC5taW4oaW5kZXggKyAxLCBlbnRyaWVzLmxlbmd0aCAtIDEpO1xuXHRcdH0sXG5cdFx0Z286IChuKSA9PiB7XG5cdFx0XHRpbmRleCA9IE1hdGgubWluKE1hdGgubWF4KGluZGV4ICsgbiwgMCksIGVudHJpZXMubGVuZ3RoIC0gMSk7XG5cdFx0fSxcblx0XHRjcmVhdGVIcmVmOiBub3JtYWxpemVIcmVmLFxuXHRcdGdldEJsb2NrZXJzOiBfZ2V0QmxvY2tlcnMsXG5cdFx0c2V0QmxvY2tlcnM6IF9zZXRCbG9ja2Vyc1xuXHR9KTtcbn1cbnZhciBub29wID0gKCkgPT4ge307XG52YXIgU2VydmVySGlzdG9yeSA9IGNsYXNzIHtcblx0Y29uc3RydWN0b3IobG9jYXRpb24pIHtcblx0XHR0aGlzLmxvY2F0aW9uID0gbG9jYXRpb247XG5cdH1cblx0Z2V0IGxlbmd0aCgpIHtcblx0XHRyZXR1cm4gMTtcblx0fVxuXHRnZXQgc3Vic2NyaWJlcnMoKSB7XG5cdFx0cmV0dXJuIHRoaXMuX3N1YnNjcmliZXJzID8/PSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHR9XG5cdHN1YnNjcmliZSgpIHtcblx0XHRyZXR1cm4gbm9vcDtcblx0fVxuXHRwdXNoKCkge31cblx0cmVwbGFjZSgpIHt9XG5cdGdvKCkge31cblx0YmFjaygpIHt9XG5cdGZvcndhcmQoKSB7fVxuXHRjYW5Hb0JhY2soKSB7XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG5cdGNyZWF0ZUhyZWYoaHJlZikge1xuXHRcdHJldHVybiBub3JtYWxpemVIcmVmKGhyZWYpO1xuXHR9XG5cdGJsb2NrKCkge1xuXHRcdHJldHVybiBub29wO1xuXHR9XG5cdGZsdXNoKCkge31cblx0ZGVzdHJveSgpIHt9XG5cdG5vdGlmeSgpIHt9XG5cdF9nZXRCbG9ja2VycygpIHtcblx0XHRyZXR1cm4gW107XG5cdH1cbn07XG4vKiogQSBmaXhlZCByZXF1ZXN0IGxvY2F0aW9uOyBzZXJ2ZXIgbmF2aWdhdGlvbiBpcyBhIG5vLW9wLiAqL1xuZnVuY3Rpb24gY3JlYXRlU2VydmVySGlzdG9yeShocmVmKSB7XG5cdHJldHVybiBuZXcgU2VydmVySGlzdG9yeShwYXJzZUhyZWYoaHJlZiwgdm9pZCAwKSk7XG59XG5mdW5jdGlvbiBwYXJzZUhyZWYoaHJlZiwgc3RhdGUpIHtcblx0Y29uc3Qgc2FuaXRpemVkSHJlZiA9IG5vcm1hbGl6ZUhyZWYoaHJlZik7XG5cdGNvbnN0IGhhc2hJbmRleCA9IHNhbml0aXplZEhyZWYuaW5kZXhPZihcIiNcIik7XG5cdGNvbnN0IHNlYXJjaEluZGV4ID0gc2FuaXRpemVkSHJlZi5pbmRleE9mKFwiP1wiKTtcblx0aWYgKCFzdGF0ZSkge1xuXHRcdGNvbnN0IGtleSA9IGNyZWF0ZVJhbmRvbUtleSgpO1xuXHRcdHN0YXRlID0ge1xuXHRcdFx0W3N0YXRlSW5kZXhLZXldOiAwLFxuXHRcdFx0a2V5LFxuXHRcdFx0X19UU1Jfa2V5OiBrZXlcblx0XHR9O1xuXHR9XG5cdHJldHVybiB7XG5cdFx0aHJlZjogc2FuaXRpemVkSHJlZixcblx0XHRwYXRobmFtZTogc2FuaXRpemVkSHJlZi5zbGljZSgwLCBoYXNoSW5kZXggPiAtMSA/IHNlYXJjaEluZGV4ID4gLTEgPyBNYXRoLm1pbihoYXNoSW5kZXgsIHNlYXJjaEluZGV4KSA6IGhhc2hJbmRleCA6IHNlYXJjaEluZGV4ID4gLTEgPyBzZWFyY2hJbmRleCA6IHNhbml0aXplZEhyZWYubGVuZ3RoKSxcblx0XHRoYXNoOiBoYXNoSW5kZXggPiAtMSA/IHNhbml0aXplZEhyZWYuc2xpY2UoaGFzaEluZGV4KSA6IFwiXCIsXG5cdFx0c2VhcmNoOiBzZWFyY2hJbmRleCA+IC0xID8gc2FuaXRpemVkSHJlZi5zbGljZShzZWFyY2hJbmRleCwgaGFzaEluZGV4ID09PSAtMSA/IHZvaWQgMCA6IGhhc2hJbmRleCkgOiBcIlwiLFxuXHRcdHN0YXRlXG5cdH07XG59XG5mdW5jdGlvbiBjcmVhdGVSYW5kb21LZXkoKSB7XG5cdHJldHVybiAoTWF0aC5yYW5kb20oKSArIDEpLnRvU3RyaW5nKDM2KS5zbGljZSg3KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgY3JlYXRlQnJvd3Nlckhpc3RvcnksIGNyZWF0ZUhhc2hIaXN0b3J5LCBjcmVhdGVIaXN0b3J5LCBjcmVhdGVNZW1vcnlIaXN0b3J5LCBjcmVhdGVTZXJ2ZXJIaXN0b3J5LCBub3JtYWxpemVQcm90b2NvbFJlbGF0aXZlLCBwYXJzZUhyZWYgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiaW1wb3J0IHsgREVGQVVMVF9QUk9UT0NPTF9BTExPV0xJU1QsIGNyZWF0ZU51bGwsIGRlY29kZVBhdGgsIGRlZXBFcXVhbCwgZW5jb2RlUGF0aExpa2VVcmwsIGZpbmRMYXN0LCBmdW5jdGlvbmFsVXBkYXRlLCBnZXRVcmxTY2hlbWUsIGhhc0tleXMsIGhhc093biwgaXNEYW5nZXJvdXNQcm90b2NvbCwgbGFzdCwgbnVsbFJlcGxhY2VFcXVhbERlZXAsIHByb3RvY29sUmVsYXRpdmVQcmVmaXhSZWdleCwgcmVwbGFjZUVxdWFsRGVlcCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyBjb21waWxlRGVjb2RlQ2hhck1hcCwgaW50ZXJwb2xhdGVQYXRoLCByZXNvbHZlUGF0aCwgdHJpbVBhdGgsIHRyaW1QYXRoUmlnaHQgfSBmcm9tIFwiLi9wYXRoLmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVTaWV2ZUNhY2hlIH0gZnJvbSBcIi4vc2lldmUtY2FjaGUuanNcIjtcbmltcG9ydCB7IGJ1aWxkUm91dGVCcmFuY2gsIGZpbmRGbGF0TWF0Y2gsIGZpbmRSb3V0ZU1hdGNoLCBmaW5kU2luZ2xlTWF0Y2gsIHBhcnNlU2VnbWVudHMsIHByb2Nlc3NSb3V0ZU1hc2tzLCBwcm9jZXNzUm91dGVUcmVlIH0gZnJvbSBcIi4vbmV3LXByb2Nlc3Mtcm91dGUtdHJlZS5qc1wiO1xuaW1wb3J0IHsgaXNOb3RGb3VuZCB9IGZyb20gXCIuL25vdC1mb3VuZC5qc1wiO1xuaW1wb3J0IHsgc2V0dXBTY3JvbGxSZXN0b3JhdGlvbiB9IGZyb20gXCIuL3Njcm9sbC1yZXN0b3JhdGlvbi5qc1wiO1xuaW1wb3J0IHsgZGVmYXVsdFBhcnNlU2VhcmNoLCBkZWZhdWx0U3RyaW5naWZ5U2VhcmNoIH0gZnJvbSBcIi4vc2VhcmNoUGFyYW1zLmpzXCI7XG5pbXBvcnQgeyByb290Um91dGVJZCB9IGZyb20gXCIuL3Jvb3QuanNcIjtcbmltcG9ydCB7IGlzUmVkaXJlY3QgfSBmcm9tIFwiLi9yZWRpcmVjdC5qc1wiO1xuaW1wb3J0IHsgbG9hZENsaWVudFJvdXRlLCBsb2FkUm91dGVDaHVuaywgcHJlbG9hZENsaWVudFJvdXRlLCByZWZyZXNoQ2xpZW50Um91dGUsIHJlcGxhY2VSb3V0ZUNodW5rIH0gZnJvbSBcIi4vbG9hZC1jbGllbnQuanNcIjtcbmltcG9ydCB7IGV4ZWN1dGVSZXdyaXRlSW5wdXQsIGV4ZWN1dGVSZXdyaXRlT3V0cHV0LCByZXdyaXRlQmFzZXBhdGggfSBmcm9tIFwiLi9yZXdyaXRlLmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVSb3V0ZXJTdG9yZXMgfSBmcm9tIFwiLi9zdG9yZXMuanNcIjtcbmltcG9ydCB7IGNyZWF0ZUJyb3dzZXJIaXN0b3J5LCBub3JtYWxpemVQcm90b2NvbFJlbGF0aXZlLCBwYXJzZUhyZWYgfSBmcm9tIFwiQHRhbnN0YWNrL2hpc3RvcnlcIjtcbmltcG9ydCB7IGlzU2VydmVyLCBsb2FkU2VydmVyUm91dGUgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG4vLyNyZWdpb24gc3JjL3JvdXRlci50c1xuZnVuY3Rpb24gaXNFeHRlcm5hbFVybCh1cmwsIG9yaWdpbikge1xuXHRyZXR1cm4gdXJsLnByb3RvY29sICE9PSBcImh0dHA6XCIgJiYgdXJsLnByb3RvY29sICE9PSBcImh0dHBzOlwiIHx8IHVybC5vcmlnaW4gIT09IG9yaWdpbiB8fCAhIXVybC51c2VybmFtZSB8fCAhIXVybC5wYXNzd29yZDtcbn1cbmZ1bmN0aW9uIGdldFVybFBhdGgodXJsKSB7XG5cdHJldHVybiB1cmwucGF0aG5hbWUgKyB1cmwuc2VhcmNoICsgdXJsLmhhc2g7XG59XG5mdW5jdGlvbiByb3V0ZU5lZWRzTG9hZChyb3V0ZSkge1xuXHRyZXR1cm4gcm91dGUub3B0aW9ucy5sb2FkZXIgfHwgcm91dGUub3B0aW9ucy5iZWZvcmVMb2FkIHx8IHJvdXRlLmxhenlGbiB8fCByb3V0ZS5vcHRpb25zLmNvbXBvbmVudD8ucHJlbG9hZCB8fCByb3V0ZS5vcHRpb25zLnBlbmRpbmdDb21wb25lbnQ/LnByZWxvYWQ7XG59XG4vKipcbiogQ29udmVydCBhbiB1bmtub3duIGVycm9yIGludG8gYSBtaW5pbWFsLCBzZXJpYWxpemFibGUgb2JqZWN0LlxuKiBJbmNsdWRlcyBuYW1lIGFuZCBtZXNzYWdlIChhbmQgc3RhY2sgaW4gZGV2ZWxvcG1lbnQpLlxuKi9cbmZ1bmN0aW9uIGRlZmF1bHRTZXJpYWxpemVFcnJvcihlcnIpIHtcblx0aWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSB7XG5cdFx0Y29uc3Qgb2JqID0ge1xuXHRcdFx0bmFtZTogZXJyLm5hbWUsXG5cdFx0XHRtZXNzYWdlOiBlcnIubWVzc2FnZVxuXHRcdH07XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcImRldmVsb3BtZW50XCIpIG9iai5zdGFjayA9IGVyci5zdGFjaztcblx0XHRyZXR1cm4gb2JqO1xuXHR9XG5cdHJldHVybiB7IGRhdGE6IGVyciB9O1xufVxuLyoqIE9wdGlvbnMgZm9yIGNvbmZpZ3VyaW5nIHRyYWlsaW5nLXNsYXNoIGJlaGF2aW9yLiAqL1xuY29uc3QgdHJhaWxpbmdTbGFzaE9wdGlvbnMgPSB7XG5cdGFsd2F5czogXCJhbHdheXNcIixcblx0bmV2ZXI6IFwibmV2ZXJcIixcblx0cHJlc2VydmU6IFwicHJlc2VydmVcIlxufTtcbi8qKlxuKiBDb21wdXRlIHdoZXRoZXIgcGF0aCwgaHJlZiBvciBoYXNoIGNoYW5nZWQgYmV0d2VlbiBwcmV2aW91cyBhbmQgY3VycmVudFxuKiByZXNvbHZlZCBsb2NhdGlvbnMuXG4qL1xuZnVuY3Rpb24gZ2V0TG9jYXRpb25DaGFuZ2VJbmZvKGxvY2F0aW9uLCByZXNvbHZlZExvY2F0aW9uKSB7XG5cdHJldHVybiB7XG5cdFx0ZnJvbUxvY2F0aW9uOiByZXNvbHZlZExvY2F0aW9uLFxuXHRcdHRvTG9jYXRpb246IGxvY2F0aW9uLFxuXHRcdHBhdGhDaGFuZ2VkOiByZXNvbHZlZExvY2F0aW9uPy5wYXRobmFtZSAhPT0gbG9jYXRpb24ucGF0aG5hbWUsXG5cdFx0aHJlZkNoYW5nZWQ6IHJlc29sdmVkTG9jYXRpb24/LmhyZWYgIT09IGxvY2F0aW9uLmhyZWYsXG5cdFx0aGFzaENoYW5nZWQ6IHJlc29sdmVkTG9jYXRpb24/Lmhhc2ggIT09IGxvY2F0aW9uLmhhc2hcblx0fTtcbn1cbi8qKlxuKiBSZXR1cm4gb25seSBzdGF0ZSBvd25lZCBieSB0aGUgYXBwbGljYXRpb24sIGV4Y2x1ZGluZyB2b2xhdGlsZSBoaXN0b3J5XG4qIGJvb2trZWVwaW5nLiBNYXNrIHBheWxvYWRzIChgX190ZW1wTG9jYXRpb25gL2BfX3RlbXBLZXlgKSBhcmUga2VwdDogdGhleVxuKiBkaXN0aW5ndWlzaCBvdGhlcndpc2UtaWRlbnRpY2FsIGxvY2F0aW9ucy5cbiovXG5mdW5jdGlvbiBfZ2V0VXNlckhpc3RvcnlTdGF0ZSh7IGtleTogX2tleSwgX19UU1Jfa2V5OiBfdHNyS2V5LCBfX1RTUl9pbmRleDogX3RzckluZGV4LCBfX2hhc2hTY3JvbGxJbnRvVmlld09wdGlvbnM6IF9oYXNoU2Nyb2xsLCAuLi5zdGF0ZSB9KSB7XG5cdHJldHVybiBzdGF0ZTtcbn1cbmZ1bmN0aW9uIGxpZmVjeWNsZUVuZChtYXRjaGVzKSB7XG5cdHJldHVybiBtYXRjaGVzLmZpbmRJbmRleCgobWF0Y2gpID0+IG1hdGNoLnN0YXR1cyA9PT0gXCJlcnJvclwiIHx8IG1hdGNoLnN0YXR1cyA9PT0gXCJub3RGb3VuZFwiIHx8IG1hdGNoLl9ub3RGb3VuZCkgKyAxO1xufVxuLyoqIFJ1biByb3V0ZSBsaWZlY3ljbGUgY2FsbGJhY2tzIGluIGxlYXZlL2VudGVyL3N0YXkgcGhhc2VzLiAqL1xuZnVuY3Rpb24gcnVuUm91dGVMaWZlY3ljbGUocm91dGVyLCBwcmV2aW91cywgbWF0Y2hlcywgcHJldmlvdXNFbmQsIG5leHRFbmQsIG93bmVyKSB7XG5cdGlmIChwcmV2aW91c0VuZCkgcHJldmlvdXMgPSBwcmV2aW91cy5zbGljZSgwLCBwcmV2aW91c0VuZCk7XG5cdGlmIChuZXh0RW5kKSBtYXRjaGVzID0gbWF0Y2hlcy5zbGljZSgwLCBuZXh0RW5kKTtcblx0Zm9yIChjb25zdCBtYXRjaCBvZiBwcmV2aW91cykge1xuXHRcdGlmIChvd25lciAmJiByb3V0ZXIuX3R4ICE9PSBvd25lcikgcmV0dXJuO1xuXHRcdGlmICghbWF0Y2hlcy5zb21lKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5yb3V0ZUlkID09PSBtYXRjaC5yb3V0ZUlkKSkgcm91dGVyLnJvdXRlc0J5SWRbbWF0Y2gucm91dGVJZF0ub3B0aW9ucy5vbkxlYXZlPy4obWF0Y2gpO1xuXHR9XG5cdGZvciAoY29uc3QgbWF0Y2ggb2YgbWF0Y2hlcykge1xuXHRcdGlmIChvd25lciAmJiByb3V0ZXIuX3R4ICE9PSBvd25lcikgcmV0dXJuO1xuXHRcdHJvdXRlci5yb3V0ZXNCeUlkW21hdGNoLnJvdXRlSWRdLm9wdGlvbnNbcHJldmlvdXMuc29tZSgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUucm91dGVJZCA9PT0gbWF0Y2gucm91dGVJZCkgPyBcIm9uU3RheVwiIDogXCJvbkVudGVyXCJdPy4obWF0Y2gpO1xuXHR9XG59XG4vKipcbiogQ29yZSwgZnJhbWV3b3JrLWFnbm9zdGljIHJvdXRlciBlbmdpbmUgdGhhdCBwb3dlcnMgVGFuU3RhY2sgUm91dGVyLlxuKlxuKiBQcm92aWRlcyBuYXZpZ2F0aW9uLCBtYXRjaGluZywgbG9hZGluZywgcHJlbG9hZGluZywgY2FjaGluZyBhbmQgZXZlbnQgQVBJc1xuKiB1c2VkIGJ5IGZyYW1ld29yayBhZGFwdGVycyAoUmVhY3QvU29saWQpLiBQcmVmZXIgZnJhbWV3b3JrIGhlbHBlcnMgbGlrZVxuKiBgY3JlYXRlUm91dGVyYCBpbiBhcHAgY29kZS5cbipcbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL1JvdXRlclR5cGVcbiovXG52YXIgUm91dGVyQ29yZSA9IGNsYXNzIHtcblx0LyoqXG5cdCogQGRlcHJlY2F0ZWQgVXNlIHRoZSBgY3JlYXRlUm91dGVyYCBmdW5jdGlvbiBpbnN0ZWFkXG5cdCovXG5cdGNvbnN0cnVjdG9yKG9wdGlvbnMsIGdldFN0b3JlQ29uZmlnKSB7XG5cdFx0dGhpcy50ZW1wTG9jYXRpb25LZXkgPSBgJHtNYXRoLnJvdW5kKE1hdGgucmFuZG9tKCkgKiAxZTcpfWA7XG5cdFx0dGhpcy5fc2Nyb2xsID0geyBuOiB0cnVlIH07XG5cdFx0dGhpcy5zdWJzY3JpYmVycyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0dGhpcy5fY2FjaGUgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuXHRcdHRoaXMuX2NvbW1pdHRlZCA9IFtdO1xuXHRcdHRoaXMuc3RhcnRUcmFuc2l0aW9uID0gYXN5bmMgKGZuKSA9PiB7XG5cdFx0XHRmbigpO1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH07XG5cdFx0dGhpcy51cGRhdGUgPSAobmV3T3B0aW9ucykgPT4ge1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0XHRpZiAobmV3T3B0aW9ucy5ub3RGb3VuZFJvdXRlKSBjb25zb2xlLndhcm4oXCJUaGUgbm90Rm91bmRSb3V0ZSBBUEkgaXMgZGVwcmVjYXRlZCBhbmQgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24uIFNlZSBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvdjEvZG9jcy9mcmFtZXdvcmsvcmVhY3QvZ3VpZGUvbm90LWZvdW5kLWVycm9ycyNtaWdyYXRpbmctZnJvbS1ub3Rmb3VuZHJvdXRlIGZvciBtb3JlIGluZm8uXCIpO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgcHJldk9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG5cdFx0XHR0aGlzLm9wdGlvbnMgPSB7XG5cdFx0XHRcdC4uLnByZXZPcHRpb25zLFxuXHRcdFx0XHQuLi5uZXdPcHRpb25zXG5cdFx0XHR9O1xuXHRcdFx0dGhpcy5pc1NlcnZlciA9IHRoaXMub3B0aW9ucy5pc1NlcnZlciA/PyBpc1NlcnZlciA/PyB0eXBlb2YgZG9jdW1lbnQgPT09IFwidW5kZWZpbmVkXCI7XG5cdFx0XHRpZiAoIShpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSkgdGhpcy5zdGF0aWNMb2NhdGlvbnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcblx0XHRcdHRoaXMucHJvdG9jb2xBbGxvd2xpc3QgPSBuZXcgU2V0KHRoaXMub3B0aW9ucy5wcm90b2NvbEFsbG93bGlzdCk7XG5cdFx0XHRpZiAoIXRoaXMuaGlzdG9yeSB8fCB0aGlzLm9wdGlvbnMuaGlzdG9yeSAmJiB0aGlzLm9wdGlvbnMuaGlzdG9yeSAhPT0gdGhpcy5oaXN0b3J5KSB7XG5cdFx0XHRcdGlmICghdGhpcy5vcHRpb25zLmhpc3RvcnkpIHtcblx0XHRcdFx0XHRpZiAoIShpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSkgdGhpcy5oaXN0b3J5ID0gY3JlYXRlQnJvd3Nlckhpc3RvcnkoKTtcblx0XHRcdFx0fSBlbHNlIHRoaXMuaGlzdG9yeSA9IHRoaXMub3B0aW9ucy5oaXN0b3J5O1xuXHRcdFx0fVxuXHRcdFx0dGhpcy5vcmlnaW4gPSB0aGlzLm9wdGlvbnMub3JpZ2luO1xuXHRcdFx0aWYgKCF0aGlzLm9yaWdpbikge1xuXHRcdFx0XHRpZiAoIShpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSAmJiB3aW5kb3c/Lm9yaWdpbiAmJiB3aW5kb3cub3JpZ2luICE9PSBcIm51bGxcIikgdGhpcy5vcmlnaW4gPSB3aW5kb3cub3JpZ2luO1xuXHRcdFx0XHRlbHNlIHRoaXMub3JpZ2luID0gXCJodHRwOi8vbG9jYWxob3N0XCI7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBuZXh0QmFzZXBhdGggPSB0aGlzLm9wdGlvbnMuYmFzZXBhdGggPz8gXCIvXCI7XG5cdFx0XHRjb25zdCBuZXh0UmV3cml0ZU9wdGlvbiA9IHRoaXMub3B0aW9ucy5yZXdyaXRlO1xuXHRcdFx0Y29uc3QgcmV3cml0ZUNoYW5nZWQgPSB0aGlzLmJhc2VwYXRoICE9PSBuZXh0QmFzZXBhdGggfHwgcHJldk9wdGlvbnM/LnJld3JpdGUgIT09IG5leHRSZXdyaXRlT3B0aW9uIHx8IHByZXZPcHRpb25zPy5jYXNlU2Vuc2l0aXZlICE9PSB0aGlzLm9wdGlvbnMuY2FzZVNlbnNpdGl2ZTtcblx0XHRcdGlmIChyZXdyaXRlQ2hhbmdlZCkge1xuXHRcdFx0XHR0aGlzLmJhc2VwYXRoID0gbmV4dEJhc2VwYXRoO1xuXHRcdFx0XHR0aGlzLnJld3JpdGUgPSBuZXh0QmFzZXBhdGggIT09IFwiL1wiICYmIHRyaW1QYXRoKG5leHRCYXNlcGF0aCkgPyByZXdyaXRlQmFzZXBhdGgobmV4dEJhc2VwYXRoLCB0aGlzLm9wdGlvbnMuY2FzZVNlbnNpdGl2ZSwgbmV4dFJld3JpdGVPcHRpb24pIDogbmV4dFJld3JpdGVPcHRpb247XG5cdFx0XHR9XG5cdFx0XHRpZiAodGhpcy5oaXN0b3J5KSB0aGlzLnVwZGF0ZUxhdGVzdExvY2F0aW9uKCk7XG5cdFx0XHRpZiAodGhpcy5vcHRpb25zLnJvdXRlVHJlZSAhPT0gdGhpcy5yb3V0ZVRyZWUgfHwgKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpICYmIHByZXZPcHRpb25zPy5jYXNlU2Vuc2l0aXZlICE9PSB0aGlzLm9wdGlvbnMuY2FzZVNlbnNpdGl2ZSkge1xuXHRcdFx0XHR0aGlzLnJvdXRlVHJlZSA9IHRoaXMub3B0aW9ucy5yb3V0ZVRyZWU7XG5cdFx0XHRcdGxldCBwcm9jZXNzUm91dGVUcmVlUmVzdWx0O1xuXHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwiZGV2ZWxvcG1lbnRcIiAmJiAoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikgJiYgZ2xvYmFsVGhpcy5fX1RTUl9DQUNIRV9fICYmIGdsb2JhbFRoaXMuX19UU1JfQ0FDSEVfXy5yb3V0ZVRyZWUgPT09IHRoaXMucm91dGVUcmVlICYmIGdsb2JhbFRoaXMuX19UU1JfQ0FDSEVfXy5jYXNlU2Vuc2l0aXZlID09PSB0aGlzLm9wdGlvbnMuY2FzZVNlbnNpdGl2ZSkgcHJvY2Vzc1JvdXRlVHJlZVJlc3VsdCA9IGdsb2JhbFRoaXMuX19UU1JfQ0FDSEVfXy5wcm9jZXNzUm91dGVUcmVlUmVzdWx0O1xuXHRcdFx0XHRlbHNlIHtcblx0XHRcdFx0XHRwcm9jZXNzUm91dGVUcmVlUmVzdWx0ID0gdGhpcy5idWlsZFJvdXRlVHJlZSgpO1xuXHRcdFx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJkZXZlbG9wbWVudFwiICYmIChpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSAmJiBnbG9iYWxUaGlzLl9fVFNSX0NBQ0hFX18gPT09IHZvaWQgMCkgZ2xvYmFsVGhpcy5fX1RTUl9DQUNIRV9fID0ge1xuXHRcdFx0XHRcdFx0cm91dGVUcmVlOiB0aGlzLnJvdXRlVHJlZSxcblx0XHRcdFx0XHRcdGNhc2VTZW5zaXRpdmU6IHRoaXMub3B0aW9ucy5jYXNlU2Vuc2l0aXZlLFxuXHRcdFx0XHRcdFx0cHJvY2Vzc1JvdXRlVHJlZVJlc3VsdFxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdH1cblx0XHRcdFx0dGhpcy5zZXRSb3V0ZXMocHJvY2Vzc1JvdXRlVHJlZVJlc3VsdCk7XG5cdFx0XHR9XG5cdFx0XHRpZiAoIXRoaXMuc3RvcmVzKSB7XG5cdFx0XHRcdGlmICh0aGlzLmxhdGVzdExvY2F0aW9uKSB7XG5cdFx0XHRcdFx0Y29uc3QgY29uZmlnID0gdGhpcy5nZXRTdG9yZUNvbmZpZyh0aGlzKTtcblx0XHRcdFx0XHR0aGlzLmJhdGNoID0gY29uZmlnLmJhdGNoO1xuXHRcdFx0XHRcdHRoaXMuc3RvcmVzID0gY3JlYXRlUm91dGVyU3RvcmVzKHRoaXMubGF0ZXN0TG9jYXRpb24sIGNvbmZpZyk7XG5cdFx0XHRcdFx0aWYgKCEoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikpIHNldHVwU2Nyb2xsUmVzdG9yYXRpb24odGhpcyk7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBpZiAocmV3cml0ZUNoYW5nZWQpIHRoaXMuc3RvcmVzLmxvY2F0aW9uLnNldCh0aGlzLmxhdGVzdExvY2F0aW9uKTtcblx0XHR9O1xuXHRcdHRoaXMudXBkYXRlTGF0ZXN0TG9jYXRpb24gPSAoKSA9PiB7XG5cdFx0XHR0aGlzLmxhdGVzdExvY2F0aW9uID0gdGhpcy5wYXJzZUxvY2F0aW9uKHRoaXMuaGlzdG9yeS5sb2NhdGlvbiwgdGhpcy5sYXRlc3RMb2NhdGlvbik7XG5cdFx0fTtcblx0XHR0aGlzLmJ1aWxkUm91dGVUcmVlID0gKCkgPT4ge1xuXHRcdFx0Y29uc3QgcmVzdWx0ID0gcHJvY2Vzc1JvdXRlVHJlZSh0aGlzLnJvdXRlVHJlZSwgdGhpcy5vcHRpb25zLmNhc2VTZW5zaXRpdmUpO1xuXHRcdFx0aWYgKHRoaXMub3B0aW9ucy5yb3V0ZU1hc2tzKSBwcm9jZXNzUm91dGVNYXNrcyh0aGlzLm9wdGlvbnMucm91dGVNYXNrcywgcmVzdWx0LnByb2Nlc3NlZFRyZWUpO1xuXHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0Li4ucmVzdWx0LFxuXHRcdFx0XHRyZXNvbHZlUGF0aENhY2hlOiBjcmVhdGVTaWV2ZUNhY2hlKDFlMylcblx0XHRcdH07XG5cdFx0fTtcblx0XHR0aGlzLnN1YnNjcmliZSA9IChldmVudFR5cGUsIGZuKSA9PiB7XG5cdFx0XHRjb25zdCBsaXN0ZW5lciA9IHtcblx0XHRcdFx0ZXZlbnRUeXBlLFxuXHRcdFx0XHRmblxuXHRcdFx0fTtcblx0XHRcdHRoaXMuc3Vic2NyaWJlcnMuYWRkKGxpc3RlbmVyKTtcblx0XHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRcdHRoaXMuc3Vic2NyaWJlcnMuZGVsZXRlKGxpc3RlbmVyKTtcblx0XHRcdH07XG5cdFx0fTtcblx0XHR0aGlzLmVtaXQgPSAocm91dGVyRXZlbnQpID0+IHtcblx0XHRcdGZvciAoY29uc3QgbGlzdGVuZXIgb2YgdGhpcy5zdWJzY3JpYmVycykgaWYgKGxpc3RlbmVyLmV2ZW50VHlwZSA9PT0gcm91dGVyRXZlbnQudHlwZSkgdHJ5IHtcblx0XHRcdFx0bGlzdGVuZXIuZm4ocm91dGVyRXZlbnQpO1xuXHRcdFx0fSBjYXRjaCAoZSkge1xuXHRcdFx0XHRjb25zb2xlLmVycm9yKGUpO1xuXHRcdFx0fVxuXHRcdH07XG5cdFx0dGhpcy5wYXJzZUxvY2F0aW9uID0gKGxvY2F0aW9uVG9QYXJzZSwgcHJldmlvdXNMb2NhdGlvbikgPT4ge1xuXHRcdFx0Y29uc3QgcGFyc2UgPSAoeyBwYXRobmFtZSwgc2VhcmNoLCBoYXNoLCBocmVmIH0sIHN0YXRlKSA9PiB7XG5cdFx0XHRcdGlmICghdGhpcy5yZXdyaXRlICYmICEvWyBcXHgwMC1cXHgxZlxceDdmXFx1MDA4MC1cXHVmZmZmXS8udGVzdChwYXRobmFtZSkpIHtcblx0XHRcdFx0XHRjb25zdCBwYXJzZWRTZWFyY2ggPSB0aGlzLm9wdGlvbnMucGFyc2VTZWFyY2goc2VhcmNoKTtcblx0XHRcdFx0XHRjb25zdCBzZWFyY2hTdHIgPSB0aGlzLm9wdGlvbnMuc3RyaW5naWZ5U2VhcmNoKHBhcnNlZFNlYXJjaCk7XG5cdFx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRcdGhyZWY6IHBhdGhuYW1lICsgc2VhcmNoU3RyICsgaGFzaCxcblx0XHRcdFx0XHRcdHB1YmxpY0hyZWY6IHBhdGhuYW1lICsgc2VhcmNoU3RyICsgaGFzaCxcblx0XHRcdFx0XHRcdHBhdGhuYW1lOiBkZWNvZGVQYXRoKHBhdGhuYW1lKSxcblx0XHRcdFx0XHRcdGV4dGVybmFsOiBmYWxzZSxcblx0XHRcdFx0XHRcdHNlYXJjaFN0cixcblx0XHRcdFx0XHRcdHNlYXJjaDogbnVsbFJlcGxhY2VFcXVhbERlZXAocHJldmlvdXNMb2NhdGlvbj8uc2VhcmNoLCBwYXJzZWRTZWFyY2gpLFxuXHRcdFx0XHRcdFx0aGFzaDogZGVjb2RlUGF0aChoYXNoLnNsaWNlKDEpKSxcblx0XHRcdFx0XHRcdHN0YXRlOiByZXBsYWNlRXF1YWxEZWVwKHByZXZpb3VzTG9jYXRpb24/LnN0YXRlLCBzdGF0ZSlcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHR9XG5cdFx0XHRcdGNvbnN0IHVybCA9IGV4ZWN1dGVSZXdyaXRlSW5wdXQodGhpcy5yZXdyaXRlLCBuZXcgVVJMKGhyZWYsIHRoaXMub3JpZ2luKSk7XG5cdFx0XHRcdGNvbnN0IHBhcnNlZFNlYXJjaCA9IHRoaXMub3B0aW9ucy5wYXJzZVNlYXJjaCh1cmwuc2VhcmNoKTtcblx0XHRcdFx0Y29uc3Qgc2VhcmNoU3RyID0gdGhpcy5vcHRpb25zLnN0cmluZ2lmeVNlYXJjaChwYXJzZWRTZWFyY2gpO1xuXHRcdFx0XHR1cmwuc2VhcmNoID0gc2VhcmNoU3RyO1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdGhyZWY6IHVybC5ocmVmLnJlcGxhY2UodXJsLm9yaWdpbiwgXCJcIiksXG5cdFx0XHRcdFx0cHVibGljSHJlZjogaHJlZixcblx0XHRcdFx0XHRwYXRobmFtZTogZGVjb2RlUGF0aChub3JtYWxpemVQcm90b2NvbFJlbGF0aXZlKHVybC5wYXRobmFtZSkpLFxuXHRcdFx0XHRcdGV4dGVybmFsOiAhIXRoaXMucmV3cml0ZSAmJiBpc0V4dGVybmFsVXJsKHVybCwgdGhpcy5vcmlnaW4pLFxuXHRcdFx0XHRcdHNlYXJjaFN0cixcblx0XHRcdFx0XHRzZWFyY2g6IG51bGxSZXBsYWNlRXF1YWxEZWVwKHByZXZpb3VzTG9jYXRpb24/LnNlYXJjaCwgcGFyc2VkU2VhcmNoKSxcblx0XHRcdFx0XHRoYXNoOiBkZWNvZGVQYXRoKHVybC5oYXNoLnNsaWNlKDEpKSxcblx0XHRcdFx0XHRzdGF0ZTogcmVwbGFjZUVxdWFsRGVlcChwcmV2aW91c0xvY2F0aW9uPy5zdGF0ZSwgc3RhdGUpXG5cdFx0XHRcdH07XG5cdFx0XHR9O1xuXHRcdFx0Y29uc3QgbG9jYXRpb24gPSBwYXJzZShsb2NhdGlvblRvUGFyc2UsIGxvY2F0aW9uVG9QYXJzZS5zdGF0ZSk7XG5cdFx0XHRjb25zdCB7IF9fdGVtcExvY2F0aW9uLCBfX3RlbXBLZXkgfSA9IGxvY2F0aW9uLnN0YXRlO1xuXHRcdFx0aWYgKF9fdGVtcExvY2F0aW9uICYmICghX190ZW1wS2V5IHx8IF9fdGVtcEtleSA9PT0gdGhpcy50ZW1wTG9jYXRpb25LZXkpKSB7XG5cdFx0XHRcdGNvbnN0IHBhcnNlZFRlbXBMb2NhdGlvbiA9IHBhcnNlKF9fdGVtcExvY2F0aW9uLCB7XG5cdFx0XHRcdFx0Li4uX190ZW1wTG9jYXRpb24uc3RhdGUsXG5cdFx0XHRcdFx0X190ZW1wTG9jYXRpb246IHZvaWQgMCxcblx0XHRcdFx0XHRrZXk6IGxvY2F0aW9uLnN0YXRlLmtleSxcblx0XHRcdFx0XHRfX1RTUl9rZXk6IGxvY2F0aW9uLnN0YXRlLl9fVFNSX2tleVxuXHRcdFx0XHR9KTtcblx0XHRcdFx0cGFyc2VkVGVtcExvY2F0aW9uLm1hc2tlZExvY2F0aW9uID0gbG9jYXRpb247XG5cdFx0XHRcdHJldHVybiBwYXJzZWRUZW1wTG9jYXRpb247XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gbG9jYXRpb247XG5cdFx0fTtcblx0XHR0aGlzLm1hdGNoUm91dGVzID0gKHBhdGhuYW1lT3JOZXh0LCBsb2NhdGlvblNlYXJjaE9yT3B0cywgb3B0cykgPT4ge1xuXHRcdFx0aWYgKHR5cGVvZiBwYXRobmFtZU9yTmV4dCA9PT0gXCJzdHJpbmdcIikgcmV0dXJuIHRoaXMubWF0Y2hSb3V0ZXNJbnRlcm5hbCh7XG5cdFx0XHRcdHBhdGhuYW1lOiBwYXRobmFtZU9yTmV4dCxcblx0XHRcdFx0c2VhcmNoOiBsb2NhdGlvblNlYXJjaE9yT3B0c1xuXHRcdFx0fSwgb3B0cyk7XG5cdFx0XHRyZXR1cm4gdGhpcy5tYXRjaFJvdXRlc0ludGVybmFsKHBhdGhuYW1lT3JOZXh0LCBsb2NhdGlvblNlYXJjaE9yT3B0cyk7XG5cdFx0fTtcblx0XHR0aGlzLmdldE1hdGNoZWRSb3V0ZXMgPSAocGF0aG5hbWUpID0+IHtcblx0XHRcdGNvbnN0IHJhd1BhcmFtcyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG5cdFx0XHRjb25zdCBtYXRjaCA9IGZpbmRSb3V0ZU1hdGNoKHRyaW1QYXRoUmlnaHQocGF0aG5hbWUpLCB0aGlzLnByb2Nlc3NlZFRyZWUsIHRydWUpO1xuXHRcdFx0aWYgKG1hdGNoKSBPYmplY3QuYXNzaWduKHJhd1BhcmFtcywgbWF0Y2gucmF3UGFyYW1zKTtcblx0XHRcdHJldHVybiBbXG5cdFx0XHRcdG1hdGNoPy5icmFuY2ggfHwgW3RoaXMucm91dGVzQnlJZFtcIl9fcm9vdF9fXCJdXSxcblx0XHRcdFx0cmF3UGFyYW1zLFxuXHRcdFx0XHRtYXRjaD8ucm91dGVcblx0XHRcdF07XG5cdFx0fTtcblx0XHR0aGlzLmJ1aWxkTG9jYXRpb24gPSAob3B0cykgPT4ge1xuXHRcdFx0aWYgKCEoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikpIHtcblx0XHRcdFx0Y29uc3QgY2FjaGVkID0gdGhpcy5zdGF0aWNMb2NhdGlvbnMuZ2V0KG9wdHMpO1xuXHRcdFx0XHRpZiAoY2FjaGVkKSByZXR1cm4gY2FjaGVkO1xuXHRcdFx0fVxuXHRcdFx0bGV0IHVzZWRDdXJyZW50ID0gZmFsc2U7XG5cdFx0XHRjb25zdCBidWlsZCA9IChkZXN0ID0ge30pID0+IHtcblx0XHRcdFx0aWYgKGRlc3QuaHJlZikge1xuXHRcdFx0XHRcdGNvbnN0IHBhcnNlZCA9IHBhcnNlSHJlZihkZXN0LmhyZWYsIHt9KTtcblx0XHRcdFx0XHRkZXN0ID0ge1xuXHRcdFx0XHRcdFx0Li4uZGVzdCxcblx0XHRcdFx0XHRcdHRvOiBleGVjdXRlUmV3cml0ZUlucHV0KHRoaXMucmV3cml0ZSwgbmV3IFVSTChwYXJzZWQucGF0aG5hbWUsIHRoaXMub3JpZ2luKSkucGF0aG5hbWUsXG5cdFx0XHRcdFx0XHRzZWFyY2g6IHRoaXMub3B0aW9ucy5wYXJzZVNlYXJjaChwYXJzZWQuc2VhcmNoKSxcblx0XHRcdFx0XHRcdGhhc2g6IHBhcnNlZC5oYXNoLnNsaWNlKDEpXG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjb25zdCBjdXJyZW50TG9jYXRpb24gPSBvcHRzLl9mcm9tTG9jYXRpb24gfHwgdGhpcy5fcGVuZGluZ0xvY2F0aW9uIHx8IHRoaXMubGF0ZXN0TG9jYXRpb247XG5cdFx0XHRcdGxldCBsaWdodHdlaWdodDtcblx0XHRcdFx0Y29uc3QgY3VycmVudCA9ICgpID0+IHtcblx0XHRcdFx0XHR1c2VkQ3VycmVudCA9IHRydWU7XG5cdFx0XHRcdFx0cmV0dXJuIGN1cnJlbnRMb2NhdGlvbjtcblx0XHRcdFx0fTtcblx0XHRcdFx0Y29uc3QgY3VycmVudE1hdGNoID0gKCkgPT4gbGlnaHR3ZWlnaHQgPz89IHRoaXMubWF0Y2hSb3V0ZXNMaWdodHdlaWdodChjdXJyZW50KCkpO1xuXHRcdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGRlc3QuZnJvbSAmJiBkZXN0Ll9pc05hdmlnYXRlKSB7XG5cdFx0XHRcdFx0Y29uc3QgW2FsbEZyb21NYXRjaGVzXSA9IHRoaXMuZ2V0TWF0Y2hlZFJvdXRlcyhkZXN0LmZyb20pO1xuXHRcdFx0XHRcdGNvbnN0IFttYXRjaGVkUm91dGVzLCBmdWxsUGF0aF0gPSBjdXJyZW50TWF0Y2goKTtcblx0XHRcdFx0XHRjb25zdCBtYXRjaGVkRnJvbSA9IGZpbmRMYXN0KG1hdGNoZWRSb3V0ZXMsIChkKSA9PiB7XG5cdFx0XHRcdFx0XHRyZXR1cm4gY29tcGFyZVBhdGhzKGQuZnVsbFBhdGgsIGRlc3QuZnJvbSk7XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0Y29uc3QgbWF0Y2hlZEN1cnJlbnQgPSBmaW5kTGFzdChhbGxGcm9tTWF0Y2hlcywgKGQpID0+IHtcblx0XHRcdFx0XHRcdHJldHVybiBjb21wYXJlUGF0aHMoZC5mdWxsUGF0aCwgZnVsbFBhdGgpO1xuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHRcdGlmICghbWF0Y2hlZEZyb20gJiYgIW1hdGNoZWRDdXJyZW50KSBjb25zb2xlLndhcm4oYENvdWxkIG5vdCBmaW5kIG1hdGNoIGZvciBmcm9tOiAke2Rlc3QuZnJvbX1gKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjb25zdCB0byA9IGRlc3QudG8gPyBgJHtkZXN0LnRvfWAgOiBcIi5cIjtcblx0XHRcdFx0Y29uc3QgbmV4dFRvID0gcmVzb2x2ZVBhdGgodG9bMF0gPT09IFwiL1wiID8gXCJcIiA6IGRlc3QudW5zYWZlUmVsYXRpdmUgPT09IFwicGF0aFwiID8gY3VycmVudCgpLnBhdGhuYW1lIDogZGVzdC5mcm9tID8/IGN1cnJlbnRNYXRjaCgpWzFdLCB0bywgdGhpcy5vcHRpb25zLnRyYWlsaW5nU2xhc2gsIHRoaXMucmVzb2x2ZVBhdGhDYWNoZSk7XG5cdFx0XHRcdGNvbnN0IGRlc3RSb3V0ZSA9IHRoaXMucm91dGVzQnlQYXRoW3RyaW1QYXRoUmlnaHQobmV4dFRvKV07XG5cdFx0XHRcdGNvbnN0IGlzVGVtcGxhdGUgPSBuZXh0VG8uaW5jbHVkZXMoXCIkXCIpO1xuXHRcdFx0XHRsZXQgZGVzdFJvdXRlcztcblx0XHRcdFx0aWYgKGRlc3RSb3V0ZSkgZGVzdFJvdXRlcyA9IGRlc3RSb3V0ZS5fYnJhbmNoID8/PSBidWlsZFJvdXRlQnJhbmNoKGRlc3RSb3V0ZSk7XG5cdFx0XHRcdGVsc2UgaWYgKGlzVGVtcGxhdGUpIGRlc3RSb3V0ZXMgPSBbXTtcblx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0Y29uc3QgW21hdGNoZWRSb3V0ZXMsIHJhd1BhcmFtcywgZm91bmRSb3V0ZV0gPSB0aGlzLmdldE1hdGNoZWRSb3V0ZXMobmV4dFRvKTtcblx0XHRcdFx0XHRkZXN0Um91dGVzID0gbWF0Y2hlZFJvdXRlcztcblx0XHRcdFx0XHRpZiAodGhpcy5vcHRpb25zLm5vdEZvdW5kUm91dGUgJiYgKCFmb3VuZFJvdXRlIHx8IGZvdW5kUm91dGUucGF0aCAhPT0gXCIvXCIgJiYgcmF3UGFyYW1zW1wiKipcIl0pKSBkZXN0Um91dGVzID0gWy4uLmRlc3RSb3V0ZXMsIHRoaXMub3B0aW9ucy5ub3RGb3VuZFJvdXRlXTtcblx0XHRcdFx0fVxuXHRcdFx0XHRjb25zdCBpbnRlcnBvbGF0aW9uID0gaXNUZW1wbGF0ZSA/IGRlc3RSb3V0ZT8uX2ludGVycG9sYXRpb24gPz8gcGFyc2VTZWdtZW50cyhmYWxzZSwgeyBmdWxsUGF0aDogbmV4dFRvIH0sIDApIDogdm9pZCAwO1xuXHRcdFx0XHRsZXQgbmV4dFBhcmFtcztcblx0XHRcdFx0Zm9yIChjb25zdCByb3V0ZSBvZiBkZXN0Um91dGVzKSB7XG5cdFx0XHRcdFx0Y29uc3QgZm4gPSByb3V0ZS5vcHRpb25zLnBhcmFtcz8uc3RyaW5naWZ5ID8/IHJvdXRlLm9wdGlvbnMuc3RyaW5naWZ5UGFyYW1zO1xuXHRcdFx0XHRcdGlmIChmbikge1xuXHRcdFx0XHRcdFx0Y29uc3QgZnJvbVBhcmFtcyA9IGN1cnJlbnRNYXRjaCgpWzNdO1xuXHRcdFx0XHRcdFx0bmV4dFBhcmFtcyA/Pz0gcmVzb2x2ZU5leHRQYXJhbXMoZGVzdC5wYXJhbXMsIGZyb21QYXJhbXMpO1xuXHRcdFx0XHRcdFx0aWYgKCFoYXNLZXlzKG5leHRQYXJhbXMpKSBicmVhaztcblx0XHRcdFx0XHRcdGlmIChuZXh0UGFyYW1zID09PSBmcm9tUGFyYW1zKSBuZXh0UGFyYW1zID0gT2JqZWN0LmFzc2lnbihjcmVhdGVOdWxsKCksIG5leHRQYXJhbXMpO1xuXHRcdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdFx0T2JqZWN0LmFzc2lnbihuZXh0UGFyYW1zLCBmbihuZXh0UGFyYW1zKSk7XG5cdFx0XHRcdFx0XHR9IGNhdGNoIHt9XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHRcdG5leHRQYXJhbXMgPz89IHJlc29sdmVOZXh0UGFyYW1zKGRlc3QucGFyYW1zLCBuZWVkc0luaGVyaXRlZFBhcmFtcyhkZXN0LnBhcmFtcywgaW50ZXJwb2xhdGlvbikgPyBjdXJyZW50TWF0Y2goKVszXSA6IEVNUFRZX1JFQ09SRCk7XG5cdFx0XHRcdGNvbnN0IG5leHRQYXRobmFtZSA9IG9wdHMubGVhdmVQYXJhbXMgPyBuZXh0VG8gOiBub3JtYWxpemVQcm90b2NvbFJlbGF0aXZlKGRlY29kZVBhdGgoaW50ZXJwb2xhdGlvbiA/IGludGVycG9sYXRlUGF0aChuZXh0VG8sIGludGVycG9sYXRpb24sIG5leHRQYXJhbXMsIHRoaXMucGF0aFBhcmFtc0RlY29kZXIpIDogbmV4dFRvKSk7XG5cdFx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgZGVzdFJvdXRlICYmICFvcHRzLmxlYXZlUGFyYW1zKSB0cnkge1xuXHRcdFx0XHRcdGNvbnN0IGZvdW5kUm91dGUgPSB0aGlzLmdldE1hdGNoZWRSb3V0ZXMobmV4dFBhdGhuYW1lKVsyXTtcblx0XHRcdFx0XHRpZiAoZm91bmRSb3V0ZT8uaWQgIT09IGRlc3RSb3V0ZS5pZCkgY29uc29sZS53YXJuKGBHZW5lcmF0ZWQgcGF0aCBcIiR7bmV4dFBhdGhuYW1lfVwiIGZvciByb3V0ZSBcIiR7ZGVzdFJvdXRlLmlkfVwiIG1hdGNoZWQgcm91dGUgXCIke2ZvdW5kUm91dGU/LmlkfVwiIGluc3RlYWQuIFRoaXMgY2FuIGhhcHBlbiB3aGVuIG11bHRpcGxlIHJvdXRlIHRlbXBsYXRlcyByZXNvbHZlIHRvIHRoZSBzYW1lIFVSTC4gVXNlIHRoZSByb3V0ZSB0ZW1wbGF0ZSB0aGF0IG1hdGNoZXMgdGhlIGludGVuZGVkIHJvdXRlLCBvciBhZGp1c3QgcGFyYW1zLnN0cmluZ2lmeSBpZiBpdCBjaGFuZ2VkIHRoZSB0YXJnZXQgcGF0aC5gKTtcblx0XHRcdFx0fSBjYXRjaCB7fVxuXHRcdFx0XHRjb25zdCBtaWRkbGV3YXJlcyA9IGdldFNlYXJjaE1pZGRsZXdhcmVzKGRlc3RSb3V0ZXMsIG9wdHMuX2luY2x1ZGVWYWxpZGF0ZVNlYXJjaCk7XG5cdFx0XHRcdGNvbnN0IGZyb21TZWFyY2ggPSAoKSA9PiB7XG5cdFx0XHRcdFx0bGV0IHNlYXJjaCA9IGN1cnJlbnRNYXRjaCgpWzJdO1xuXHRcdFx0XHRcdGlmIChvcHRzLl9pbmNsdWRlVmFsaWRhdGVTZWFyY2ggJiYgdGhpcy5vcHRpb25zLnNlYXJjaD8uc3RyaWN0KSB7XG5cdFx0XHRcdFx0XHRjb25zdCB2YWxpZGF0ZWRTZWFyY2ggPSB7fTtcblx0XHRcdFx0XHRcdGRlc3RSb3V0ZXMuZm9yRWFjaCgocm91dGUpID0+IHtcblx0XHRcdFx0XHRcdFx0aWYgKHJvdXRlLm9wdGlvbnMudmFsaWRhdGVTZWFyY2gpIHRyeSB7XG5cdFx0XHRcdFx0XHRcdFx0T2JqZWN0LmFzc2lnbih2YWxpZGF0ZWRTZWFyY2gsIHZhbGlkYXRlU2VhcmNoKHJvdXRlLm9wdGlvbnMudmFsaWRhdGVTZWFyY2gsIHtcblx0XHRcdFx0XHRcdFx0XHRcdC4uLnZhbGlkYXRlZFNlYXJjaCxcblx0XHRcdFx0XHRcdFx0XHRcdC4uLnNlYXJjaFxuXHRcdFx0XHRcdFx0XHRcdH0pKTtcblx0XHRcdFx0XHRcdFx0fSBjYXRjaCB7fVxuXHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0XHRzZWFyY2ggPSB2YWxpZGF0ZWRTZWFyY2g7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdHJldHVybiBzZWFyY2g7XG5cdFx0XHRcdH07XG5cdFx0XHRcdGNvbnN0IG5leHRTZWFyY2ggPSBtaWRkbGV3YXJlcy5sZW5ndGggPyBhcHBseVNlYXJjaE1pZGRsZXdhcmUobWlkZGxld2FyZXMsIGZyb21TZWFyY2goKSwgZGVzdCkgOiBkZXN0LnNlYXJjaCA9PT0gdHJ1ZSA/IGZyb21TZWFyY2goKSA6IHR5cGVvZiBkZXN0LnNlYXJjaCA9PT0gXCJmdW5jdGlvblwiID8gZGVzdC5zZWFyY2goZnJvbVNlYXJjaCgpKSA6IGRlc3Quc2VhcmNoIHx8IEVNUFRZX1JFQ09SRDtcblx0XHRcdFx0Y29uc3Qgc2VhcmNoU3RyID0gdGhpcy5vcHRpb25zLnN0cmluZ2lmeVNlYXJjaChuZXh0U2VhcmNoKTtcblx0XHRcdFx0Y29uc3QgaGFzaCA9IGRlc3QuaGFzaCA9PT0gdHJ1ZSA/IGN1cnJlbnQoKS5oYXNoIDogdHlwZW9mIGRlc3QuaGFzaCA9PT0gXCJmdW5jdGlvblwiID8gZGVzdC5oYXNoKGN1cnJlbnQoKS5oYXNoKSA6IGRlc3QuaGFzaCB8fCB2b2lkIDA7XG5cdFx0XHRcdGNvbnN0IGhhc2hTdHIgPSBoYXNoID8gYCMke2hhc2h9YCA6IFwiXCI7XG5cdFx0XHRcdGNvbnN0IG5leHRTdGF0ZSA9ICFkZXN0LnN0YXRlID8gRU1QVFlfUkVDT1JEIDogZGVzdC5zdGF0ZSA9PT0gdHJ1ZSA/IGN1cnJlbnQoKS5zdGF0ZSA6IHR5cGVvZiBkZXN0LnN0YXRlID09PSBcImZ1bmN0aW9uXCIgPyBkZXN0LnN0YXRlKGN1cnJlbnQoKS5zdGF0ZSkgOiBkZXN0LnN0YXRlO1xuXHRcdFx0XHRjb25zdCBmdWxsUGF0aCA9IGAke25leHRQYXRobmFtZX0ke3NlYXJjaFN0cn0ke2hhc2hTdHJ9YDtcblx0XHRcdFx0bGV0IGhyZWY7XG5cdFx0XHRcdGxldCBwdWJsaWNIcmVmO1xuXHRcdFx0XHRsZXQgZXh0ZXJuYWwgPSBmYWxzZTtcblx0XHRcdFx0aWYgKHRoaXMucmV3cml0ZSkge1xuXHRcdFx0XHRcdGNvbnN0IHVybCA9IG5ldyBVUkwoZnVsbFBhdGgsIHRoaXMub3JpZ2luKTtcblx0XHRcdFx0XHRjb25zdCBvcmlnaW4gPSB1cmwub3JpZ2luO1xuXHRcdFx0XHRcdGNvbnN0IHJld3JpdHRlblVybCA9IGV4ZWN1dGVSZXdyaXRlT3V0cHV0KHRoaXMucmV3cml0ZSwgdXJsKTtcblx0XHRcdFx0XHRocmVmID0gZ2V0VXJsUGF0aCh1cmwpO1xuXHRcdFx0XHRcdGlmIChpc0V4dGVybmFsVXJsKHJld3JpdHRlblVybCwgb3JpZ2luKSkge1xuXHRcdFx0XHRcdFx0cHVibGljSHJlZiA9IHJld3JpdHRlblVybC5ocmVmO1xuXHRcdFx0XHRcdFx0ZXh0ZXJuYWwgPSB0cnVlO1xuXHRcdFx0XHRcdH0gZWxzZSBwdWJsaWNIcmVmID0gbm9ybWFsaXplUHJvdG9jb2xSZWxhdGl2ZShnZXRVcmxQYXRoKHJld3JpdHRlblVybCkpO1xuXHRcdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRcdGhyZWYgPSBlbmNvZGVQYXRoTGlrZVVybChmdWxsUGF0aCk7XG5cdFx0XHRcdFx0cHVibGljSHJlZiA9IGhyZWY7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmV0dXJuIHtcblx0XHRcdFx0XHRwdWJsaWNIcmVmLFxuXHRcdFx0XHRcdGhyZWYsXG5cdFx0XHRcdFx0cGF0aG5hbWU6IG5leHRQYXRobmFtZSxcblx0XHRcdFx0XHRzZWFyY2g6IG5leHRTZWFyY2gsXG5cdFx0XHRcdFx0c2VhcmNoU3RyLFxuXHRcdFx0XHRcdHN0YXRlOiBuZXh0U3RhdGUsXG5cdFx0XHRcdFx0aGFzaDogaGFzaCA/PyBcIlwiLFxuXHRcdFx0XHRcdGV4dGVybmFsLFxuXHRcdFx0XHRcdHVubWFza09uUmVsb2FkOiBkZXN0LnVubWFza09uUmVsb2FkXG5cdFx0XHRcdH07XG5cdFx0XHR9O1xuXHRcdFx0Y29uc3QgbmV4dCA9IGJ1aWxkKG9wdHMpO1xuXHRcdFx0aWYgKG9wdHMubWFzaykgbmV4dC5tYXNrZWRMb2NhdGlvbiA9IGJ1aWxkKHtcblx0XHRcdFx0ZnJvbTogb3B0cy5mcm9tLFxuXHRcdFx0XHQuLi5vcHRzLm1hc2tcblx0XHRcdH0pO1xuXHRcdFx0ZWxzZSBpZiAodGhpcy5vcHRpb25zLnJvdXRlTWFza3MpIHtcblx0XHRcdFx0Y29uc3QgbWF0Y2ggPSBmaW5kRmxhdE1hdGNoKG5leHQucGF0aG5hbWUsIHRoaXMucHJvY2Vzc2VkVHJlZSk7XG5cdFx0XHRcdGlmIChtYXRjaCkge1xuXHRcdFx0XHRcdGNvbnN0IHBhcmFtcyA9IE9iamVjdC5hc3NpZ24oY3JlYXRlTnVsbCgpLCBtYXRjaC5yYXdQYXJhbXMpO1xuXHRcdFx0XHRcdGNvbnN0IHsgZnJvbTogX2Zyb20sIHBhcmFtczogbWFza1BhcmFtcywgLi4ubWFza1Byb3BzIH0gPSBtYXRjaC5yb3V0ZTtcblx0XHRcdFx0XHRjb25zdCBuZXh0UGFyYW1zID0gcmVzb2x2ZU5leHRQYXJhbXMobWFza1BhcmFtcywgcGFyYW1zKTtcblx0XHRcdFx0XHRuZXh0Lm1hc2tlZExvY2F0aW9uID0gYnVpbGQoe1xuXHRcdFx0XHRcdFx0ZnJvbTogb3B0cy5mcm9tLFxuXHRcdFx0XHRcdFx0Li4ubWFza1Byb3BzLFxuXHRcdFx0XHRcdFx0cGFyYW1zOiBuZXh0UGFyYW1zXG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGlmICghKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpICYmICF1c2VkQ3VycmVudCAmJiBvcHRzLl9mcm9tTG9jYXRpb24pIHRoaXMuc3RhdGljTG9jYXRpb25zLnNldChvcHRzLCBuZXh0KTtcblx0XHRcdHJldHVybiBuZXh0O1xuXHRcdH07XG5cdFx0dGhpcy5jb21taXRMb2NhdGlvbiA9IGFzeW5jICh7IHZpZXdUcmFuc2l0aW9uLCBpZ25vcmVCbG9ja2VyLCAuLi5uZXh0IH0pID0+IHtcblx0XHRcdGlmIChpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSByZXR1cm47XG5cdFx0XHRjb25zdCBuZXh0TG9jYXRpb24gPSBuZXh0Lm1hc2tlZExvY2F0aW9uID8/IG5leHQ7XG5cdFx0XHRpZiAobmV4dExvY2F0aW9uLmV4dGVybmFsICYmICEoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikpIHJldHVybiBkb2N1bWVudE5hdmlnYXRpb24odGhpcywgbmV4dExvY2F0aW9uLnB1YmxpY0hyZWYsIHtcblx0XHRcdFx0cmVwbGFjZTogbmV4dC5yZXBsYWNlLFxuXHRcdFx0XHRpZ25vcmVCbG9ja2VyXG5cdFx0XHR9KTtcblx0XHRcdGxldCBoaXN0b3J5QWN0aW9uO1xuXHRcdFx0Y29uc3QgaXNTYW1lTG9jYXRpb24gPSB0cmltUGF0aFJpZ2h0KHRoaXMubGF0ZXN0TG9jYXRpb24uaHJlZikgPT09IHRyaW1QYXRoUmlnaHQobmV4dC5ocmVmKSAmJiBkZWVwRXF1YWwoX2dldFVzZXJIaXN0b3J5U3RhdGUobmV4dC5zdGF0ZSksIF9nZXRVc2VySGlzdG9yeVN0YXRlKHRoaXMubGF0ZXN0TG9jYXRpb24uc3RhdGUpKTtcblx0XHRcdGNvbnN0IHByZXZpb3VzQ29tbWl0UHJvbWlzZSA9IHRoaXMuX2NvbW1pdFByb21pc2U7XG5cdFx0XHRsZXQgcmVzb2x2ZTtcblx0XHRcdGNvbnN0IGNvbW1pdFByb21pc2UgPSBuZXcgUHJvbWlzZSgoZG9uZSkgPT4ge1xuXHRcdFx0XHRyZXNvbHZlID0gZG9uZTtcblx0XHRcdH0pO1xuXHRcdFx0Y29tbWl0UHJvbWlzZS5yZXNvbHZlID0gKCkgPT4ge1xuXHRcdFx0XHRyZXNvbHZlKCk7XG5cdFx0XHRcdHByZXZpb3VzQ29tbWl0UHJvbWlzZT8ucmVzb2x2ZSgpO1xuXHRcdFx0fTtcblx0XHRcdHRoaXMuX2NvbW1pdFByb21pc2UgPSBjb21taXRQcm9taXNlO1xuXHRcdFx0aWYgKGlzU2FtZUxvY2F0aW9uKSB0aGlzLmxvYWQoKTtcblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRsZXQgeyBtYXNrZWRMb2NhdGlvbiwgaGFzaFNjcm9sbEludG9WaWV3LCAuLi5uZXh0SGlzdG9yeSB9ID0gbmV4dDtcblx0XHRcdFx0aWYgKG1hc2tlZExvY2F0aW9uKSB7XG5cdFx0XHRcdFx0bmV4dEhpc3RvcnkgPSB7XG5cdFx0XHRcdFx0XHQuLi5tYXNrZWRMb2NhdGlvbixcblx0XHRcdFx0XHRcdHN0YXRlOiB7XG5cdFx0XHRcdFx0XHRcdC4uLm1hc2tlZExvY2F0aW9uLnN0YXRlLFxuXHRcdFx0XHRcdFx0XHRfX3RlbXBLZXk6IHZvaWQgMCxcblx0XHRcdFx0XHRcdFx0X190ZW1wTG9jYXRpb246IHtcblx0XHRcdFx0XHRcdFx0XHQuLi5uZXh0SGlzdG9yeSxcblx0XHRcdFx0XHRcdFx0XHRzZWFyY2g6IG5leHRIaXN0b3J5LnNlYXJjaFN0cixcblx0XHRcdFx0XHRcdFx0XHRzdGF0ZToge1xuXHRcdFx0XHRcdFx0XHRcdFx0Li4ubmV4dEhpc3Rvcnkuc3RhdGUsXG5cdFx0XHRcdFx0XHRcdFx0XHRfX3RlbXBLZXk6IHZvaWQgMCxcblx0XHRcdFx0XHRcdFx0XHRcdF9fdGVtcExvY2F0aW9uOiB2b2lkIDAsXG5cdFx0XHRcdFx0XHRcdFx0XHRfX1RTUl9rZXk6IHZvaWQgMCxcblx0XHRcdFx0XHRcdFx0XHRcdGtleTogdm9pZCAwXG5cdFx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRpZiAobmV4dEhpc3RvcnkudW5tYXNrT25SZWxvYWQgPz8gdGhpcy5vcHRpb25zLnVubWFza09uUmVsb2FkID8/IGZhbHNlKSBuZXh0SGlzdG9yeS5zdGF0ZS5fX3RlbXBLZXkgPSB0aGlzLnRlbXBMb2NhdGlvbktleTtcblx0XHRcdFx0fVxuXHRcdFx0XHRuZXh0SGlzdG9yeS5zdGF0ZSA9IHtcblx0XHRcdFx0XHQuLi5uZXh0SGlzdG9yeS5zdGF0ZSxcblx0XHRcdFx0XHRfX2hhc2hTY3JvbGxJbnRvVmlld09wdGlvbnM6IGhhc2hTY3JvbGxJbnRvVmlldyA/PyB0aGlzLm9wdGlvbnMuZGVmYXVsdEhhc2hTY3JvbGxJbnRvVmlldyA/PyB0cnVlXG5cdFx0XHRcdH07XG5cdFx0XHRcdHRoaXMuc2hvdWxkVmlld1RyYW5zaXRpb24gPSB2aWV3VHJhbnNpdGlvbjtcblx0XHRcdFx0aGlzdG9yeUFjdGlvbiA9IG5leHQucmVwbGFjZSA/IFwiUkVQTEFDRVwiIDogXCJQVVNIXCI7XG5cdFx0XHRcdHRoaXMuaGlzdG9yeVtoaXN0b3J5QWN0aW9uID09PSBcIlJFUExBQ0VcIiA/IFwicmVwbGFjZVwiIDogXCJwdXNoXCJdKG5leHRIaXN0b3J5LnB1YmxpY0hyZWYsIG5leHRIaXN0b3J5LnN0YXRlLCB7IGlnbm9yZUJsb2NrZXIgfSk7XG5cdFx0XHRcdGlmICghdGhpcy5oaXN0b3J5LnN1YnNjcmliZXJzLnNpemUpIHRoaXMubG9hZCh7IGFjdGlvbjogeyB0eXBlOiBoaXN0b3J5QWN0aW9uIH0gfSk7XG5cdFx0XHR9XG5cdFx0XHR0aGlzLl9zY3JvbGwubiA9IG5leHQucmVzZXRTY3JvbGwgPz8gdHJ1ZTtcblx0XHRcdHJldHVybiB0aGlzLl9jb21taXRQcm9taXNlO1xuXHRcdH07XG5cdFx0dGhpcy5idWlsZEFuZENvbW1pdExvY2F0aW9uID0gKHsgcmVwbGFjZSwgcmVzZXRTY3JvbGwsIGhhc2hTY3JvbGxJbnRvVmlldywgdmlld1RyYW5zaXRpb24sIGlnbm9yZUJsb2NrZXIsIC4uLnJlc3QgfSA9IHt9KSA9PiB7XG5cdFx0XHRpZiAoaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlcikgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuXHRcdFx0Y29uc3QgbG9jYXRpb24gPSB0aGlzLmJ1aWxkTG9jYXRpb24oe1xuXHRcdFx0XHQuLi5yZXN0LFxuXHRcdFx0XHRfaW5jbHVkZVZhbGlkYXRlU2VhcmNoOiB0cnVlXG5cdFx0XHR9KTtcblx0XHRcdHRoaXMuX3BlbmRpbmdMb2NhdGlvbiA9IGxvY2F0aW9uO1xuXHRcdFx0Y29uc3QgY29tbWl0UHJvbWlzZSA9IHRoaXMuY29tbWl0TG9jYXRpb24oe1xuXHRcdFx0XHQuLi5sb2NhdGlvbixcblx0XHRcdFx0dmlld1RyYW5zaXRpb24sXG5cdFx0XHRcdHJlcGxhY2UsXG5cdFx0XHRcdHJlc2V0U2Nyb2xsLFxuXHRcdFx0XHRoYXNoU2Nyb2xsSW50b1ZpZXcsXG5cdFx0XHRcdGlnbm9yZUJsb2NrZXJcblx0XHRcdH0pO1xuXHRcdFx0cXVldWVNaWNyb3Rhc2soKCkgPT4ge1xuXHRcdFx0XHRpZiAodGhpcy5fcGVuZGluZ0xvY2F0aW9uID09PSBsb2NhdGlvbikgdGhpcy5fcGVuZGluZ0xvY2F0aW9uID0gdm9pZCAwO1xuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gY29tbWl0UHJvbWlzZTtcblx0XHR9O1xuXHRcdHRoaXMubmF2aWdhdGUgPSBhc3luYyAoeyB0bywgcmVsb2FkRG9jdW1lbnQsIGhyZWYsIHB1YmxpY0hyZWYsIC4uLnJlc3QgfSkgPT4ge1xuXHRcdFx0aWYgKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpIHJldHVybjtcblx0XHRcdGNvbnN0IGhyZWZTY2hlbWUgPSBocmVmID8gZ2V0VXJsU2NoZW1lKGhyZWYpIDogdm9pZCAwO1xuXHRcdFx0aWYgKGhyZWZTY2hlbWUgfHwgcmVsb2FkRG9jdW1lbnQpIHtcblx0XHRcdFx0aWYgKHRvICE9PSB2b2lkIDAgfHwgIWhyZWYpIHtcblx0XHRcdFx0XHRjb25zdCBsb2NhdGlvbiA9IHRoaXMuYnVpbGRMb2NhdGlvbih7XG5cdFx0XHRcdFx0XHR0byxcblx0XHRcdFx0XHRcdC4uLnJlc3Rcblx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRjb25zdCBwdWJsaWNMb2NhdGlvbiA9IGxvY2F0aW9uLm1hc2tlZExvY2F0aW9uID8/IGxvY2F0aW9uO1xuXHRcdFx0XHRcdGhyZWYgPz89IHB1YmxpY0xvY2F0aW9uLnB1YmxpY0hyZWY7XG5cdFx0XHRcdFx0cHVibGljSHJlZiA/Pz0gcHVibGljTG9jYXRpb24ucHVibGljSHJlZjtcblx0XHRcdFx0fVxuXHRcdFx0XHRjb25zdCByZWxvYWRIcmVmID0gIWhyZWZTY2hlbWUgJiYgcHVibGljSHJlZiA/IHB1YmxpY0hyZWYgOiBocmVmO1xuXHRcdFx0XHRyZXR1cm4gZG9jdW1lbnROYXZpZ2F0aW9uKHRoaXMsIHJlbG9hZEhyZWYsIHJlc3QpO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHRoaXMuYnVpbGRBbmRDb21taXRMb2NhdGlvbih7XG5cdFx0XHRcdC4uLnJlc3QsXG5cdFx0XHRcdGhyZWYsXG5cdFx0XHRcdHRvLFxuXHRcdFx0XHRfaXNOYXZpZ2F0ZTogdHJ1ZVxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLmxvYWQgPSBhc3luYyAob3B0cykgPT4ge1xuXHRcdFx0aWYgKGlzU2VydmVyID8/IHRoaXMuaXNTZXJ2ZXIpIHJldHVybiBsb2FkU2VydmVyUm91dGUodGhpcywgb3B0cyk7XG5cdFx0XHR0aGlzLnVwZGF0ZUxhdGVzdExvY2F0aW9uKCk7XG5cdFx0XHRpZiAob3B0cz8uYWN0aW9uKSB0aGlzLl9zY3JvbGwuaCA9IG9wdHMuYWN0aW9uLnR5cGUgPT09IFwiUFVTSFwiIHx8IG9wdHMuYWN0aW9uLnR5cGUgPT09IFwiUkVQTEFDRVwiO1xuXHRcdFx0YXdhaXQgbG9hZENsaWVudFJvdXRlKHRoaXMsIG9wdHMpO1xuXHRcdH07XG5cdFx0dGhpcy5zdGFydFZpZXdUcmFuc2l0aW9uID0gKGZuKSA9PiB7XG5cdFx0XHRjb25zdCBzaG91bGRWaWV3VHJhbnNpdGlvbiA9IHRoaXMuc2hvdWxkVmlld1RyYW5zaXRpb24gPz8gdGhpcy5vcHRpb25zLmRlZmF1bHRWaWV3VHJhbnNpdGlvbjtcblx0XHRcdHRoaXMuc2hvdWxkVmlld1RyYW5zaXRpb24gPSB2b2lkIDA7XG5cdFx0XHRpZiAoc2hvdWxkVmlld1RyYW5zaXRpb24gJiYgIShpc1NlcnZlciA/PyB0eXBlb2YgZG9jdW1lbnQgPT09IFwidW5kZWZpbmVkXCIpICYmIHR5cGVvZiBkb2N1bWVudC5zdGFydFZpZXdUcmFuc2l0aW9uID09PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRcdFx0bGV0IHN0YXJ0Vmlld1RyYW5zaXRpb25QYXJhbXM7XG5cdFx0XHRcdGlmICh0eXBlb2Ygc2hvdWxkVmlld1RyYW5zaXRpb24gPT09IFwib2JqZWN0XCIgJiYgd2luZG93LkNTUz8uc3VwcG9ydHM/LihcInNlbGVjdG9yKDphY3RpdmUtdmlldy10cmFuc2l0aW9uLXR5cGUoYSkpXCIpKSB7XG5cdFx0XHRcdFx0Y29uc3QgbmV4dCA9IHRoaXMubGF0ZXN0TG9jYXRpb247XG5cdFx0XHRcdFx0Y29uc3QgcHJldkxvY2F0aW9uID0gdGhpcy5zdG9yZXMucmVzb2x2ZWRMb2NhdGlvbi5nZXQoKTtcblx0XHRcdFx0XHRjb25zdCByZXNvbHZlZFZpZXdUcmFuc2l0aW9uVHlwZXMgPSB0eXBlb2Ygc2hvdWxkVmlld1RyYW5zaXRpb24udHlwZXMgPT09IFwiZnVuY3Rpb25cIiA/IHNob3VsZFZpZXdUcmFuc2l0aW9uLnR5cGVzKGdldExvY2F0aW9uQ2hhbmdlSW5mbyhuZXh0LCBwcmV2TG9jYXRpb24pKSA6IHNob3VsZFZpZXdUcmFuc2l0aW9uLnR5cGVzO1xuXHRcdFx0XHRcdGlmIChyZXNvbHZlZFZpZXdUcmFuc2l0aW9uVHlwZXMgPT09IGZhbHNlKSByZXR1cm4gZm4oKTtcblx0XHRcdFx0XHRzdGFydFZpZXdUcmFuc2l0aW9uUGFyYW1zID0ge1xuXHRcdFx0XHRcdFx0dXBkYXRlOiBmbixcblx0XHRcdFx0XHRcdHR5cGVzOiByZXNvbHZlZFZpZXdUcmFuc2l0aW9uVHlwZXNcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHR9IGVsc2Ugc3RhcnRWaWV3VHJhbnNpdGlvblBhcmFtcyA9IGZuO1xuXHRcdFx0XHRyZXR1cm4gZG9jdW1lbnQuc3RhcnRWaWV3VHJhbnNpdGlvbihzdGFydFZpZXdUcmFuc2l0aW9uUGFyYW1zKS51cGRhdGVDYWxsYmFja0RvbmU7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZm4oKTtcblx0XHR9O1xuXHRcdHRoaXMuaW52YWxpZGF0ZSA9IChvcHRzKSA9PiB7XG5cdFx0XHRjb25zdCBjb21taXR0ZWRNYXRjaGVzID0gdGhpcy5fY29tbWl0dGVkO1xuXHRcdFx0Y29uc3QgZmlsdGVyID0gb3B0cz8uZmlsdGVyO1xuXHRcdFx0Y29uc3QgcHJlbG9hZHMgPSB0aGlzLl9wcmVsb2Fkcztcblx0XHRcdGNvbnN0IGludmFsaWRJZHMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdFx0Y29uc3QgY29uc2lkZXIgPSAobWF0Y2gpID0+IHtcblx0XHRcdFx0aWYgKCFmaWx0ZXIgfHwgZmlsdGVyKG1hdGNoKSkgaW52YWxpZElkcy5hZGQobWF0Y2guaWQpO1xuXHRcdFx0fTtcblx0XHRcdGNvbW1pdHRlZE1hdGNoZXMuZm9yRWFjaChjb25zaWRlcik7XG5cdFx0XHR0aGlzLl9jYWNoZS5mb3JFYWNoKGNvbnNpZGVyKTtcblx0XHRcdHByZWxvYWRzPy5mb3JFYWNoKChtYXRjaGVzKSA9PiBtYXRjaGVzLmZvckVhY2goY29uc2lkZXIpKTtcblx0XHRcdHRoaXMuX3R4Py5bM10uZm9yRWFjaChjb25zaWRlcik7XG5cdFx0XHRjb25zdCBhYm9ydCA9IFtdO1xuXHRcdFx0Zm9yIChjb25zdCBbY29udHJvbGxlciwgbWF0Y2hlc10gb2YgcHJlbG9hZHMgPz8gW10pIGlmIChtYXRjaGVzLnNvbWUoKG1hdGNoKSA9PiBpbnZhbGlkSWRzLmhhcyhtYXRjaC5pZCkpKSB7XG5cdFx0XHRcdHByZWxvYWRzLmRlbGV0ZShjb250cm9sbGVyKTtcblx0XHRcdFx0YWJvcnQucHVzaChjb250cm9sbGVyKTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IGludmFsaWRhdGUgPSAoZCkgPT4ge1xuXHRcdFx0XHRpZiAoaW52YWxpZElkcy5oYXMoZC5pZCkpIHtcblx0XHRcdFx0XHRjb25zdCByb3V0ZSA9IHRoaXMucm91dGVzQnlJZFtkLnJvdXRlSWRdO1xuXHRcdFx0XHRcdGNvbnN0IG5leHQgPSB7XG5cdFx0XHRcdFx0XHQuLi5kLFxuXHRcdFx0XHRcdFx0aW52YWxpZDogdHJ1ZSxcblx0XHRcdFx0XHRcdC4uLihvcHRzPy5mb3JjZVBlbmRpbmcgfHwgZC5zdGF0dXMgPT09IFwiZXJyb3JcIiB8fCBkLnN0YXR1cyA9PT0gXCJub3RGb3VuZFwiKSAmJiByb3V0ZU5lZWRzTG9hZChyb3V0ZSkgPyB7XG5cdFx0XHRcdFx0XHRcdHN0YXR1czogXCJwZW5kaW5nXCIsXG5cdFx0XHRcdFx0XHRcdGVycm9yOiB2b2lkIDBcblx0XHRcdFx0XHRcdH0gOiB2b2lkIDBcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdGQuX2ZsaWdodCA9IHZvaWQgMDtcblx0XHRcdFx0XHRyZXR1cm4gbmV4dDtcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gZDtcblx0XHRcdH07XG5cdFx0XHR0aGlzLl9jb21taXR0ZWQgPSBjb21taXR0ZWRNYXRjaGVzLm1hcChpbnZhbGlkYXRlKTtcblx0XHRcdGZvciAoY29uc3QgW2lkLCBtYXRjaF0gb2YgdGhpcy5fY2FjaGUpIGlmIChpbnZhbGlkSWRzLmhhcyhpZCkpIHtcblx0XHRcdFx0bWF0Y2guaW52YWxpZCA9IHRydWU7XG5cdFx0XHRcdGlmIChvcHRzPy5mb3JjZVBlbmRpbmcpIG1hdGNoLnN0YXR1cyA9IFwicGVuZGluZ1wiO1xuXHRcdFx0fVxuXHRcdFx0Zm9yIChjb25zdCBpZCBvZiBpbnZhbGlkSWRzKSB7XG5cdFx0XHRcdGNvbnN0IGZsaWdodCA9IHRoaXMuX2ZsaWdodHM/LmdldChpZCk7XG5cdFx0XHRcdHRoaXMuX2ZsaWdodHM/LmRlbGV0ZShpZCk7XG5cdFx0XHRcdGlmIChmbGlnaHQgJiYgIWZsaWdodFsyXSkgYWJvcnQucHVzaChmbGlnaHRbMV0pO1xuXHRcdFx0fVxuXHRcdFx0Zm9yIChjb25zdCBjb250cm9sbGVyIG9mIGFib3J0KSBjb250cm9sbGVyLmFib3J0KCk7XG5cdFx0XHR0aGlzLnNob3VsZFZpZXdUcmFuc2l0aW9uID0gZmFsc2U7XG5cdFx0XHRyZXR1cm4gdGhpcy5sb2FkKHsgc3luYzogb3B0cz8uc3luYyB9KTtcblx0XHR9O1xuXHRcdHRoaXMucmVzb2x2ZVJlZGlyZWN0ID0gKHJlZGlyZWN0KSA9PiB7XG5cdFx0XHRjb25zdCBvcHRpb25zID0gcmVkaXJlY3Qub3B0aW9ucztcblx0XHRcdGxldCBocmVmID0gcmVkaXJlY3QuaGVhZGVycy5nZXQoXCJMb2NhdGlvblwiKSB8fCBvcHRpb25zLmhyZWY7XG5cdFx0XHRpZiAoIWhyZWYpIHtcblx0XHRcdFx0Y29uc3QgbG9jYXRpb24gPSB0aGlzLmJ1aWxkTG9jYXRpb24ob3B0aW9ucyk7XG5cdFx0XHRcdGhyZWYgPSAobG9jYXRpb24ubWFza2VkTG9jYXRpb24gPz8gbG9jYXRpb24pLnB1YmxpY0hyZWYgfHwgXCIvXCI7XG5cdFx0XHR9XG5cdFx0XHRsZXQgc2NoZW1lO1xuXHRcdFx0aWYgKHByb3RvY29sUmVsYXRpdmVQcmVmaXhSZWdleC50ZXN0KGhyZWYpIHx8IChzY2hlbWUgPSBnZXRVcmxTY2hlbWUoaHJlZikpICYmICF0aGlzLnByb3RvY29sQWxsb3dsaXN0LmhhcyhzY2hlbWUpKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gYFJlZGlyZWN0IGJsb2NrZWQ6IHVuc2FmZSBwcm90b2NvbCBpbiBocmVmIFwiJHtocmVmfVwiLiBBbGxvd2VkIHByb3RvY29sczogJHtBcnJheS5mcm9tKHRoaXMucHJvdG9jb2xBbGxvd2xpc3QpLmpvaW4oXCIsIFwiKX0uYCA6IFwiUmVkaXJlY3QgYmxvY2tlZDogdW5zYWZlIHByb3RvY29sXCIpO1xuXHRcdFx0aWYgKHNjaGVtZSA9PT0gXCJodHRwOlwiIHx8IHNjaGVtZSA9PT0gXCJodHRwczpcIikge1xuXHRcdFx0XHRjb25zdCB1cmwgPSBuZXcgVVJMKGhyZWYpO1xuXHRcdFx0XHRpZiAodXJsLnBhdGhuYW1lLnN0YXJ0c1dpdGgoXCIvL1wiKSkgaHJlZiA9IHVybC5ocmVmO1xuXHRcdFx0XHRlbHNlIGlmICghaXNFeHRlcm5hbFVybCh1cmwsIHRoaXMub3JpZ2luKSkge1xuXHRcdFx0XHRcdGhyZWYgPSBnZXRVcmxQYXRoKHVybCk7XG5cdFx0XHRcdFx0c2NoZW1lID0gdm9pZCAwO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoc2NoZW1lKSBvcHRpb25zLnJlbG9hZERvY3VtZW50ID0gdHJ1ZTtcblx0XHRcdG9wdGlvbnMuaHJlZiA9IGhyZWY7XG5cdFx0XHRyZWRpcmVjdC5oZWFkZXJzLnNldChcIkxvY2F0aW9uXCIsIGhyZWYpO1xuXHRcdFx0cmV0dXJuIHJlZGlyZWN0O1xuXHRcdH07XG5cdFx0dGhpcy5jbGVhckNhY2hlID0gKG9wdHMpID0+IHtcblx0XHRcdGNvbnN0IGNhY2hlZCA9IHRoaXMuX2NhY2hlO1xuXHRcdFx0Y29uc3QgcHJlbG9hZHMgPSB0aGlzLl9wcmVsb2Fkcztcblx0XHRcdGNvbnN0IGZpbHRlciA9IG9wdHM/LmZpbHRlcjtcblx0XHRcdGNvbnN0IGRpc2NhcmRlZCA9IFtdO1xuXHRcdFx0Y29uc3QgZGlzY2FyZGVkSWRzID0gW107XG5cdFx0XHRmb3IgKGNvbnN0IFtpZCwgbWF0Y2hdIG9mIGNhY2hlZCkgaWYgKCFmaWx0ZXIgfHwgZmlsdGVyKG1hdGNoKSkge1xuXHRcdFx0XHRkaXNjYXJkZWRJZHMucHVzaChpZCk7XG5cdFx0XHRcdGRpc2NhcmRlZC5wdXNoKG1hdGNoKTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IGFib3J0ID0gW107XG5cdFx0XHRmb3IgKGNvbnN0IFtjb250cm9sbGVyLCBtYXRjaGVzXSBvZiBwcmVsb2FkcyA/PyBbXSkgaWYgKCFmaWx0ZXIgfHwgbWF0Y2hlcy5zb21lKGZpbHRlcikpIHtcblx0XHRcdFx0YWJvcnQucHVzaChjb250cm9sbGVyKTtcblx0XHRcdFx0ZGlzY2FyZGVkLnB1c2goLi4ubWF0Y2hlcyk7XG5cdFx0XHR9XG5cdFx0XHRmb3IgKGNvbnN0IGlkIG9mIGRpc2NhcmRlZElkcykgY2FjaGVkLmRlbGV0ZShpZCk7XG5cdFx0XHRmb3IgKGNvbnN0IGNvbnRyb2xsZXIgb2YgYWJvcnQpIHByZWxvYWRzLmRlbGV0ZShjb250cm9sbGVyKTtcblx0XHRcdGZvciAoY29uc3QgbWF0Y2ggb2YgZGlzY2FyZGVkKSB7XG5cdFx0XHRcdGNvbnN0IGZsaWdodCA9IG1hdGNoLl9mbGlnaHQ7XG5cdFx0XHRcdG1hdGNoLl9mbGlnaHQgPSB2b2lkIDA7XG5cdFx0XHRcdGlmIChmbGlnaHQgJiYgIS0tZmxpZ2h0WzJdKSB7XG5cdFx0XHRcdFx0aWYgKHRoaXMuX2ZsaWdodHM/LmdldChtYXRjaC5pZCkgPT09IGZsaWdodCkgdGhpcy5fZmxpZ2h0cy5kZWxldGUobWF0Y2guaWQpO1xuXHRcdFx0XHRcdGFib3J0LnB1c2goZmxpZ2h0WzFdKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0Zm9yIChjb25zdCBjb250cm9sbGVyIG9mIGFib3J0KSBjb250cm9sbGVyLmFib3J0KCk7XG5cdFx0fTtcblx0XHR0aGlzLmxvYWRSb3V0ZUNodW5rID0gbG9hZFJvdXRlQ2h1bms7XG5cdFx0dGhpcy5wcmVsb2FkUm91dGUgPSAob3B0cykgPT4gcHJlbG9hZENsaWVudFJvdXRlKHRoaXMsIG9wdHMpO1xuXHRcdHRoaXMubWF0Y2hSb3V0ZSA9IChsb2NhdGlvbiwgb3B0cykgPT4ge1xuXHRcdFx0Y29uc3QgbWF0Y2hMb2NhdGlvbiA9IHtcblx0XHRcdFx0Li4ubG9jYXRpb24sXG5cdFx0XHRcdHRvOiBsb2NhdGlvbi50byA/IHJlc29sdmVQYXRoKGxvY2F0aW9uLmZyb20gfHwgXCJcIiwgbG9jYXRpb24udG8sIHRoaXMub3B0aW9ucy50cmFpbGluZ1NsYXNoLCB0aGlzLnJlc29sdmVQYXRoQ2FjaGUpIDogdm9pZCAwLFxuXHRcdFx0XHRwYXJhbXM6IGxvY2F0aW9uLnBhcmFtcyB8fCB7fSxcblx0XHRcdFx0bGVhdmVQYXJhbXM6IHRydWVcblx0XHRcdH07XG5cdFx0XHRjb25zdCBuZXh0ID0gdGhpcy5idWlsZExvY2F0aW9uKG1hdGNoTG9jYXRpb24pO1xuXHRcdFx0Y29uc3QgaXNQZW5kaW5nID0gdGhpcy5zdG9yZXMuc3RhdHVzLmdldCgpID09PSBcInBlbmRpbmdcIjtcblx0XHRcdGlmIChvcHRzPy5wZW5kaW5nICYmICFpc1BlbmRpbmcpIHJldHVybiBmYWxzZTtcblx0XHRcdGNvbnN0IGJhc2VMb2NhdGlvbiA9IG9wdHM/LnBlbmRpbmcgPz8gIWlzUGVuZGluZyA/IHRoaXMubGF0ZXN0TG9jYXRpb24gOiB0aGlzLnN0b3Jlcy5yZXNvbHZlZExvY2F0aW9uLmdldCgpIHx8IHRoaXMuc3RvcmVzLmxvY2F0aW9uLmdldCgpO1xuXHRcdFx0Y29uc3QgbWF0Y2ggPSBmaW5kU2luZ2xlTWF0Y2gobmV4dC5wYXRobmFtZSwgb3B0cz8uY2FzZVNlbnNpdGl2ZSA/PyBmYWxzZSwgb3B0cz8uZnV6enkgPz8gZmFsc2UsIGJhc2VMb2NhdGlvbi5wYXRobmFtZSwgdGhpcy5wcm9jZXNzZWRUcmVlKTtcblx0XHRcdGlmICghbWF0Y2gpIHJldHVybiBmYWxzZTtcblx0XHRcdGlmIChsb2NhdGlvbi5wYXJhbXMpIHtcblx0XHRcdFx0aWYgKCFkZWVwRXF1YWwobWF0Y2gucmF3UGFyYW1zLCBsb2NhdGlvbi5wYXJhbXMsIHRydWUpKSByZXR1cm4gZmFsc2U7XG5cdFx0XHR9XG5cdFx0XHRpZiAob3B0cz8uaW5jbHVkZVNlYXJjaCA/PyB0cnVlKSByZXR1cm4gZGVlcEVxdWFsKGJhc2VMb2NhdGlvbi5zZWFyY2gsIG5leHQuc2VhcmNoLCB0cnVlKSA/IG1hdGNoLnJhd1BhcmFtcyA6IGZhbHNlO1xuXHRcdFx0cmV0dXJuIG1hdGNoLnJhd1BhcmFtcztcblx0XHR9O1xuXHRcdHRoaXMuZ2V0U3RvcmVDb25maWcgPSBnZXRTdG9yZUNvbmZpZztcblx0XHRpZiAob3B0aW9ucy5wYXRoUGFyYW1zQWxsb3dlZENoYXJhY3RlcnM/Lmxlbmd0aCkgdGhpcy5wYXRoUGFyYW1zRGVjb2RlciA9IGNvbXBpbGVEZWNvZGVDaGFyTWFwKG9wdGlvbnMucGF0aFBhcmFtc0FsbG93ZWRDaGFyYWN0ZXJzKTtcblx0XHR0aGlzLnVwZGF0ZSh7XG5cdFx0XHRkZWZhdWx0UHJlbG9hZERlbGF5OiA1MCxcblx0XHRcdGRlZmF1bHRQZW5kaW5nTXM6IDFlMyxcblx0XHRcdGRlZmF1bHRQZW5kaW5nTWluTXM6IDUwMCxcblx0XHRcdGNvbnRleHQ6IHZvaWQgMCxcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRjYXNlU2Vuc2l0aXZlOiBvcHRpb25zLmNhc2VTZW5zaXRpdmUgPz8gZmFsc2UsXG5cdFx0XHRub3RGb3VuZE1vZGU6IG9wdGlvbnMubm90Rm91bmRNb2RlID8/IFwiZnV6enlcIixcblx0XHRcdHN0cmluZ2lmeVNlYXJjaDogb3B0aW9ucy5zdHJpbmdpZnlTZWFyY2ggPz8gZGVmYXVsdFN0cmluZ2lmeVNlYXJjaCxcblx0XHRcdHBhcnNlU2VhcmNoOiBvcHRpb25zLnBhcnNlU2VhcmNoID8/IGRlZmF1bHRQYXJzZVNlYXJjaCxcblx0XHRcdHByb3RvY29sQWxsb3dsaXN0OiBvcHRpb25zLnByb3RvY29sQWxsb3dsaXN0ID8/IERFRkFVTFRfUFJPVE9DT0xfQUxMT1dMSVNUXG5cdFx0fSk7XG5cdFx0aWYgKCEoaXNTZXJ2ZXIgPz8gdHlwZW9mIGRvY3VtZW50ID09PSBcInVuZGVmaW5lZFwiKSkgc2VsZi5fX1RTUl9ST1VURVJfXyA9IHRoaXM7XG5cdH1cblx0aXNTaGVsbCgpIHtcblx0XHRyZXR1cm4gISF0aGlzLm9wdGlvbnMuaXNTaGVsbDtcblx0fVxuXHRnZXQgc3RhdGUoKSB7XG5cdFx0cmV0dXJuIHRoaXMuc3RvcmVzLl9fc3RvcmUuZ2V0KCk7XG5cdH1cblx0c2V0Um91dGVzKGNhY2hlcykge1xuXHRcdE9iamVjdC5hc3NpZ24odGhpcywgY2FjaGVzKTtcblx0XHR0aGlzLmxpZ2h0d2VpZ2h0Q2FjaGUgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcblx0XHRpZiAoIShpc1NlcnZlciA/PyB0aGlzLmlzU2VydmVyKSkgdGhpcy5zdGF0aWNMb2NhdGlvbnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcblx0XHRjb25zdCBub3RGb3VuZFJvdXRlID0gdGhpcy5vcHRpb25zLm5vdEZvdW5kUm91dGU7XG5cdFx0aWYgKG5vdEZvdW5kUm91dGUpIHtcblx0XHRcdG5vdEZvdW5kUm91dGUuaW5pdCg5OTk5OTk5OTk5OSk7XG5cdFx0XHRpZiAodGhpcy5yb3V0ZXNCeUlkW25vdEZvdW5kUm91dGUuaWRdICE9PSBub3RGb3VuZFJvdXRlKSBub3RGb3VuZFJvdXRlLl9pbnRlcnBvbGF0aW9uID0gcGFyc2VTZWdtZW50cyhmYWxzZSwgbm90Rm91bmRSb3V0ZSwgMCk7XG5cdFx0XHR0aGlzLnJvdXRlc0J5SWRbbm90Rm91bmRSb3V0ZS5pZF0gPSBub3RGb3VuZFJvdXRlO1xuXHRcdH1cblx0fVxuXHRtYXRjaFJvdXRlc0ludGVybmFsKG5leHQsIG9wdHMpIHtcblx0XHRjb25zdCBbaW5pdGlhbE1hdGNoZWRSb3V0ZXMsIHJhd1BhcmFtcywgZm91bmRSb3V0ZV0gPSB0aGlzLmdldE1hdGNoZWRSb3V0ZXMobmV4dC5wYXRobmFtZSk7XG5cdFx0bGV0IG1hdGNoZWRSb3V0ZXMgPSBpbml0aWFsTWF0Y2hlZFJvdXRlcztcblx0XHRsZXQgaXNHbG9iYWxOb3RGb3VuZCA9IGZhbHNlO1xuXHRcdGlmIChmb3VuZFJvdXRlID8gZm91bmRSb3V0ZS5wYXRoICE9PSBcIi9cIiAmJiByYXdQYXJhbXNbXCIqKlwiXSA6IHRyaW1QYXRoUmlnaHQobmV4dC5wYXRobmFtZSkpIHtcblx0XHRcdGlmICh0aGlzLm9wdGlvbnMubm90Rm91bmRSb3V0ZSkgbWF0Y2hlZFJvdXRlcyA9IFsuLi5tYXRjaGVkUm91dGVzLCB0aGlzLm9wdGlvbnMubm90Rm91bmRSb3V0ZV07XG5cdFx0XHRlbHNlIGlzR2xvYmFsTm90Rm91bmQgPSB0cnVlO1xuXHRcdH1cblx0XHRjb25zdCBfbm90Rm91bmRSb3V0ZUlkID0gaXNHbG9iYWxOb3RGb3VuZCA/IGZpbmRHbG9iYWxOb3RGb3VuZFJvdXRlSWQodGhpcy5vcHRpb25zLm5vdEZvdW5kTW9kZSwgbWF0Y2hlZFJvdXRlcykgOiB2b2lkIDA7XG5cdFx0Y29uc3QgbWF0Y2hlcyA9IG5ldyBBcnJheShtYXRjaGVkUm91dGVzLmxlbmd0aCk7XG5cdFx0Y29uc3QgY29tbWl0dGVkID0gdGhpcy5fY29tbWl0dGVkO1xuXHRcdGNvbnN0IHByZXZpb3VzQXQgPSAocm91dGUsIGluZGV4KSA9PiB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IGNvbW1pdHRlZFtpbmRleF07XG5cdFx0XHRyZXR1cm4gbWF0Y2g/LnJvdXRlSWQgPT09IHJvdXRlLmlkID8gbWF0Y2ggOiByb3V0ZSA9PT0gdGhpcy5vcHRpb25zLm5vdEZvdW5kUm91dGUgPyBjb21taXR0ZWQuZmluZCgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUucm91dGVJZCA9PT0gcm91dGUuaWQpIDogdm9pZCAwO1xuXHRcdH07XG5cdFx0bGV0IHN0cmljdFBhcmFtcztcblx0XHRmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgbWF0Y2hlZFJvdXRlcy5sZW5ndGg7IGluZGV4KyspIHtcblx0XHRcdGNvbnN0IHJvdXRlID0gbWF0Y2hlZFJvdXRlc1tpbmRleF07XG5cdFx0XHRjb25zdCBwYXJlbnRNYXRjaCA9IG1hdGNoZXNbaW5kZXggLSAxXTtcblx0XHRcdGxldCBwcmVNYXRjaFNlYXJjaDtcblx0XHRcdGxldCBzdHJpY3RNYXRjaFNlYXJjaDtcblx0XHRcdGxldCBzZWFyY2hFcnJvcjtcblx0XHRcdHtcblx0XHRcdFx0Y29uc3QgcGFyZW50U2VhcmNoID0gcGFyZW50TWF0Y2g/LnNlYXJjaCA/PyBuZXh0LnNlYXJjaDtcblx0XHRcdFx0Y29uc3QgcGFyZW50U3RyaWN0U2VhcmNoID0gcGFyZW50TWF0Y2g/Ll9zdHJpY3RTZWFyY2ggPz8gdm9pZCAwO1xuXHRcdFx0XHR0cnkge1xuXHRcdFx0XHRcdGNvbnN0IHN0cmljdFNlYXJjaCA9IHZhbGlkYXRlU2VhcmNoKHJvdXRlLm9wdGlvbnMudmFsaWRhdGVTZWFyY2gsIHsgLi4ucGFyZW50U2VhcmNoIH0pID8/IHZvaWQgMDtcblx0XHRcdFx0XHRwcmVNYXRjaFNlYXJjaCA9IHtcblx0XHRcdFx0XHRcdC4uLnBhcmVudFNlYXJjaCxcblx0XHRcdFx0XHRcdC4uLnN0cmljdFNlYXJjaFxuXHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0c3RyaWN0TWF0Y2hTZWFyY2ggPSB7XG5cdFx0XHRcdFx0XHQuLi5wYXJlbnRTdHJpY3RTZWFyY2gsXG5cdFx0XHRcdFx0XHQuLi5zdHJpY3RTZWFyY2hcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHR9IGNhdGNoIChlcnIpIHtcblx0XHRcdFx0XHRsZXQgc2VhcmNoUGFyYW1FcnJvciA9IGVycjtcblx0XHRcdFx0XHRpZiAoIShlcnIgaW5zdGFuY2VvZiBTZWFyY2hQYXJhbUVycm9yKSkgc2VhcmNoUGFyYW1FcnJvciA9IG5ldyBTZWFyY2hQYXJhbUVycm9yKGVyci5tZXNzYWdlLCB7IGNhdXNlOiBlcnIgfSk7XG5cdFx0XHRcdFx0aWYgKG9wdHM/LnRocm93T25FcnJvcikgdGhyb3cgc2VhcmNoUGFyYW1FcnJvcjtcblx0XHRcdFx0XHRwcmVNYXRjaFNlYXJjaCA9IHBhcmVudFNlYXJjaDtcblx0XHRcdFx0XHRzdHJpY3RNYXRjaFNlYXJjaCA9IHt9O1xuXHRcdFx0XHRcdHNlYXJjaEVycm9yID0gc2VhcmNoUGFyYW1FcnJvcjtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0bGV0IGxvYWRlckRlcHMgPSBcIlwiO1xuXHRcdFx0bGV0IGxvYWRlckRlcHNIYXNoID0gXCJcIjtcblx0XHRcdHRyeSB7XG5cdFx0XHRcdGxvYWRlckRlcHMgPSByb3V0ZS5vcHRpb25zLmxvYWRlckRlcHM/Lih7IHNlYXJjaDogcHJlTWF0Y2hTZWFyY2ggfSkgPz8gXCJcIjtcblx0XHRcdFx0bG9hZGVyRGVwc0hhc2ggPSBsb2FkZXJEZXBzID8gSlNPTi5zdHJpbmdpZnkobG9hZGVyRGVwcykgfHwgXCJcIiA6IFwiXCI7XG5cdFx0XHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdFx0XHRpZiAob3B0cz8udGhyb3dPbkVycm9yKSB0aHJvdyBjYXVzZTtcblx0XHRcdFx0c2VhcmNoRXJyb3IgPz89IGNhdXNlO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgdXNlZFBhcmFtcyA9IGNyZWF0ZU51bGwoKTtcblx0XHRcdGNvbnN0IGludGVycG9sYXRlZFBhdGggPSByb3V0ZS5faW50ZXJwb2xhdGlvbiA/IGludGVycG9sYXRlUGF0aChyb3V0ZS5mdWxsUGF0aCwgcm91dGUuX2ludGVycG9sYXRpb24sIHJhd1BhcmFtcywgdGhpcy5wYXRoUGFyYW1zRGVjb2RlciwgdXNlZFBhcmFtcykgOiByb3V0ZS5mdWxsUGF0aDtcblx0XHRcdGNvbnN0IG1hdGNoSWQgPSByb3V0ZS5pZCArIGludGVycG9sYXRlZFBhdGggKyBsb2FkZXJEZXBzSGFzaDtcblx0XHRcdGNvbnN0IHByZXZpb3VzTWF0Y2ggPSBwcmV2aW91c0F0KHJvdXRlLCBpbmRleCk7XG5cdFx0XHRjb25zdCBleGlzdGluZ01hdGNoID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIG9wdHM/Ll9yZW1hdGVyaWFsaXplID8gdm9pZCAwIDogdGhpcy5fY2FjaGUuZ2V0KG1hdGNoSWQpID8/IChwcmV2aW91c01hdGNoPy5pZCA9PT0gbWF0Y2hJZCA/IHByZXZpb3VzTWF0Y2ggOiB2b2lkIDApO1xuXHRcdFx0c3RyaWN0UGFyYW1zID0gZXhpc3RpbmdNYXRjaD8uX3N0cmljdFBhcmFtcyA/PyBPYmplY3QuYXNzaWduKHVzZWRQYXJhbXMsIHN0cmljdFBhcmFtcyk7XG5cdFx0XHRsZXQgcGFyYW1zRXJyb3I7XG5cdFx0XHRpZiAoIWV4aXN0aW5nTWF0Y2gpIHRyeSB7XG5cdFx0XHRcdGV4dHJhY3RTdHJpY3RQYXJhbXMocm91dGUsIHN0cmljdFBhcmFtcyk7XG5cdFx0XHR9IGNhdGNoIChlcnIpIHtcblx0XHRcdFx0aWYgKGlzTm90Rm91bmQoZXJyKSB8fCBpc1JlZGlyZWN0KGVycikpIHBhcmFtc0Vycm9yID0gZXJyO1xuXHRcdFx0XHRlbHNlIHBhcmFtc0Vycm9yID0gbmV3IFBhdGhQYXJhbUVycm9yKGVyci5tZXNzYWdlLCB7IGNhdXNlOiBlcnIgfSk7XG5cdFx0XHRcdGlmIChvcHRzPy50aHJvd09uRXJyb3IpIHRocm93IHBhcmFtc0Vycm9yO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3QgY2F1c2UgPSBwcmV2aW91c01hdGNoID8gXCJzdGF5XCIgOiBcImVudGVyXCI7XG5cdFx0XHRsZXQgbWF0Y2g7XG5cdFx0XHRpZiAoZXhpc3RpbmdNYXRjaCkgbWF0Y2ggPSB7XG5cdFx0XHRcdC4uLmV4aXN0aW5nTWF0Y2gsXG5cdFx0XHRcdGNhdXNlLFxuXHRcdFx0XHRzZWFyY2g6IHByZXZpb3VzTWF0Y2ggPyBudWxsUmVwbGFjZUVxdWFsRGVlcChwcmV2aW91c01hdGNoLnNlYXJjaCwgcHJlTWF0Y2hTZWFyY2gpIDogbnVsbFJlcGxhY2VFcXVhbERlZXAoZXhpc3RpbmdNYXRjaC5zZWFyY2gsIHByZU1hdGNoU2VhcmNoKSxcblx0XHRcdFx0X3N0cmljdFNlYXJjaDogc3RyaWN0TWF0Y2hTZWFyY2gsXG5cdFx0XHRcdHNlYXJjaEVycm9yXG5cdFx0XHR9O1xuXHRcdFx0ZWxzZSB7XG5cdFx0XHRcdGNvbnN0IHN0YXR1cyA9IHJvdXRlTmVlZHNMb2FkKHJvdXRlKSA/IFwicGVuZGluZ1wiIDogXCJzdWNjZXNzXCI7XG5cdFx0XHRcdG1hdGNoID0ge1xuXHRcdFx0XHRcdGlkOiBtYXRjaElkLFxuXHRcdFx0XHRcdHNzcjogaXNTZXJ2ZXIgPz8gdGhpcy5pc1NlcnZlciA/IHZvaWQgMCA6IHJvdXRlLm9wdGlvbnMuc3NyLFxuXHRcdFx0XHRcdGluZGV4LFxuXHRcdFx0XHRcdHJvdXRlSWQ6IHJvdXRlLmlkLFxuXHRcdFx0XHRcdHBhcmFtczogcHJldmlvdXNNYXRjaD8ucGFyYW1zID8/IHN0cmljdFBhcmFtcyxcblx0XHRcdFx0XHRfc3RyaWN0UGFyYW1zOiBzdHJpY3RQYXJhbXMsXG5cdFx0XHRcdFx0cGF0aG5hbWU6IGludGVycG9sYXRlZFBhdGgsXG5cdFx0XHRcdFx0dXBkYXRlZEF0OiBEYXRlLm5vdygpLFxuXHRcdFx0XHRcdHNlYXJjaDogcHJldmlvdXNNYXRjaCA/IG51bGxSZXBsYWNlRXF1YWxEZWVwKHByZXZpb3VzTWF0Y2guc2VhcmNoLCBwcmVNYXRjaFNlYXJjaCkgOiBwcmVNYXRjaFNlYXJjaCxcblx0XHRcdFx0XHRfc3RyaWN0U2VhcmNoOiBzdHJpY3RNYXRjaFNlYXJjaCxcblx0XHRcdFx0XHRzZWFyY2hFcnJvcixcblx0XHRcdFx0XHRzdGF0dXMsXG5cdFx0XHRcdFx0aXNGZXRjaGluZzogZmFsc2UsXG5cdFx0XHRcdFx0ZXJyb3I6IHZvaWQgMCxcblx0XHRcdFx0XHRwYXJhbXNFcnJvcixcblx0XHRcdFx0XHRjb250ZXh0OiB7fSxcblx0XHRcdFx0XHRhYm9ydENvbnRyb2xsZXI6IG9wdHM/Ll9jb250cm9sbGVyID8/IG5ldyBBYm9ydENvbnRyb2xsZXIoKSxcblx0XHRcdFx0XHRjYXVzZSxcblx0XHRcdFx0XHRsb2FkZXJEZXBzOiBwcmV2aW91c01hdGNoID8gcmVwbGFjZUVxdWFsRGVlcChwcmV2aW91c01hdGNoLmxvYWRlckRlcHMsIGxvYWRlckRlcHMpIDogbG9hZGVyRGVwcyxcblx0XHRcdFx0XHRpbnZhbGlkOiBmYWxzZSxcblx0XHRcdFx0XHRwcmVsb2FkOiBmYWxzZSxcblx0XHRcdFx0XHRzdGF0aWNEYXRhOiByb3V0ZS5vcHRpb25zLnN0YXRpY0RhdGEgfHwge30sXG5cdFx0XHRcdFx0ZnVsbFBhdGg6IHJvdXRlLmZ1bGxQYXRoXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBfbm90Rm91bmQgPSBfbm90Rm91bmRSb3V0ZUlkID09PSByb3V0ZS5pZDtcblx0XHRcdGlmIChtYXRjaC5fbm90Rm91bmQgJiYgIV9ub3RGb3VuZCkgbWF0Y2guZXJyb3IgPSB2b2lkIDA7XG5cdFx0XHRtYXRjaC5fbm90Rm91bmQgPSBfbm90Rm91bmQ7XG5cdFx0XHRtYXRjaGVzW2luZGV4XSA9IG1hdGNoO1xuXHRcdH1cblx0XHRmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgbWF0Y2hlcy5sZW5ndGg7IGluZGV4KyspIHtcblx0XHRcdGNvbnN0IG1hdGNoID0gbWF0Y2hlc1tpbmRleF07XG5cdFx0XHRtYXRjaC5wYXJhbXMgPSBtYXRjaC5jYXVzZSA9PT0gXCJzdGF5XCIgPyBudWxsUmVwbGFjZUVxdWFsRGVlcChtYXRjaC5wYXJhbXMsIHN0cmljdFBhcmFtcykgOiBzdHJpY3RQYXJhbXM7XG5cdFx0XHRpZiAob3B0cz8uX2NvbnRyb2xsZXIpIG1hdGNoLmNvbnRleHQgPSB7fTtcblx0XHR9XG5cdFx0cmV0dXJuIG1hdGNoZXM7XG5cdH1cblx0LyoqXG5cdCogTGlnaHR3ZWlnaHQgcm91dGUgbWF0Y2hpbmcgZm9yIGJ1aWxkTG9jYXRpb24uXG5cdCogT25seSBjb21wdXRlcyBmdWxsUGF0aCwgYWNjdW11bGF0ZWQgc2VhcmNoLCBhbmQgcGFyYW1zIC0gc2tpcHBpbmcgZXhwZW5zaXZlXG5cdCogb3BlcmF0aW9ucyBsaWtlIEFib3J0Q29udHJvbGxlciwgbG9hZGVyRGVwcywgYW5kIGZ1bGwgbWF0Y2ggb2JqZWN0cy5cblx0Ki9cblx0bWF0Y2hSb3V0ZXNMaWdodHdlaWdodChsb2NhdGlvbikge1xuXHRcdGNvbnN0IGxhc3RSb3V0ZUlkID0gbGFzdCh0aGlzLnN0b3Jlcy5pZHMuZ2V0KCkpO1xuXHRcdGNvbnN0IGxhc3RTdGF0ZU1hdGNoID0gbGFzdFJvdXRlSWQgPyB0aGlzLnN0b3Jlcy5ieVJvdXRlLmdldChsYXN0Um91dGVJZCkuZ2V0KCkgOiB2b2lkIDA7XG5cdFx0Y29uc3QgbGFzdFN0YXRlTWF0Y2hJZCA9IGxhc3RTdGF0ZU1hdGNoPy5pZDtcblx0XHRjb25zdCBjYWNoZWQgPSB0aGlzLmxpZ2h0d2VpZ2h0Q2FjaGUuZ2V0KGxvY2F0aW9uKTtcblx0XHRpZiAoY2FjaGVkICYmIGNhY2hlZFswXSA9PT0gbGFzdFN0YXRlTWF0Y2hJZCkgcmV0dXJuIGNhY2hlZFsxXTtcblx0XHRjb25zdCBbbWF0Y2hlZFJvdXRlcywgcmF3UGFyYW1zXSA9IHRoaXMuZ2V0TWF0Y2hlZFJvdXRlcyhsb2NhdGlvbi5wYXRobmFtZSk7XG5cdFx0Y29uc3QgbGFzdFJvdXRlID0gbGFzdChtYXRjaGVkUm91dGVzKTtcblx0XHRjb25zdCBhY2N1bXVsYXRlZFNlYXJjaCA9IHsgLi4ubG9jYXRpb24uc2VhcmNoIH07XG5cdFx0Zm9yIChjb25zdCByb3V0ZSBvZiBtYXRjaGVkUm91dGVzKSB0cnkge1xuXHRcdFx0T2JqZWN0LmFzc2lnbihhY2N1bXVsYXRlZFNlYXJjaCwgdmFsaWRhdGVTZWFyY2gocm91dGUub3B0aW9ucy52YWxpZGF0ZVNlYXJjaCwgYWNjdW11bGF0ZWRTZWFyY2gpKTtcblx0XHR9IGNhdGNoIHt9XG5cdFx0Y29uc3QgY2FuUmV1c2VQYXJhbXMgPSBsYXN0U3RhdGVNYXRjaCAmJiBsYXN0U3RhdGVNYXRjaC5yb3V0ZUlkID09PSBsYXN0Um91dGUuaWQgJiYgbGFzdFN0YXRlTWF0Y2gucGF0aG5hbWUgPT09IGxvY2F0aW9uLnBhdGhuYW1lO1xuXHRcdGxldCBwYXJhbXM7XG5cdFx0aWYgKGNhblJldXNlUGFyYW1zKSBwYXJhbXMgPSBsYXN0U3RhdGVNYXRjaC5wYXJhbXM7XG5cdFx0ZWxzZSB7XG5cdFx0XHRjb25zdCBzdHJpY3RQYXJhbXMgPSByYXdQYXJhbXM7XG5cdFx0XHRmb3IgKGNvbnN0IHJvdXRlIG9mIG1hdGNoZWRSb3V0ZXMpIHRyeSB7XG5cdFx0XHRcdGV4dHJhY3RTdHJpY3RQYXJhbXMocm91dGUsIHN0cmljdFBhcmFtcyk7XG5cdFx0XHR9IGNhdGNoIHt9XG5cdFx0XHRwYXJhbXMgPSBzdHJpY3RQYXJhbXM7XG5cdFx0fVxuXHRcdGNvbnN0IHJlc3VsdCA9IFtcblx0XHRcdG1hdGNoZWRSb3V0ZXMsXG5cdFx0XHRsYXN0Um91dGUuZnVsbFBhdGgsXG5cdFx0XHRhY2N1bXVsYXRlZFNlYXJjaCxcblx0XHRcdHBhcmFtc1xuXHRcdF07XG5cdFx0dGhpcy5saWdodHdlaWdodENhY2hlLnNldChsb2NhdGlvbiwgW2xhc3RTdGF0ZU1hdGNoSWQsIHJlc3VsdF0pO1xuXHRcdHJldHVybiByZXN1bHQ7XG5cdH1cbn07XG5hc3luYyBmdW5jdGlvbiBkb2N1bWVudE5hdmlnYXRpb24ocm91dGVyLCBocmVmLCB7IHJlcGxhY2UsIGlnbm9yZUJsb2NrZXIgfSkge1xuXHRpZiAoaXNEYW5nZXJvdXNQcm90b2NvbChocmVmLCByb3V0ZXIucHJvdG9jb2xBbGxvd2xpc3QpKSB7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgY29uc29sZS53YXJuKGBCbG9ja2VkIG5hdmlnYXRpb24gdG8gZGFuZ2Vyb3VzIHByb3RvY29sOiAke2hyZWZ9YCk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGlmICghaWdub3JlQmxvY2tlcikge1xuXHRcdGNvbnN0IGJsb2NrZXJzID0gcm91dGVyLmhpc3RvcnkuX2dldEJsb2NrZXJzKCk7XG5cdFx0Zm9yIChjb25zdCBibG9ja2VyIG9mIGJsb2NrZXJzKSBpZiAoYmxvY2tlcj8uYmxvY2tlckZuKSB7XG5cdFx0XHRpZiAoYXdhaXQgYmxvY2tlci5ibG9ja2VyRm4oe1xuXHRcdFx0XHRjdXJyZW50TG9jYXRpb246IHJvdXRlci5oaXN0b3J5LmxvY2F0aW9uLFxuXHRcdFx0XHRuZXh0TG9jYXRpb246IHJvdXRlci5oaXN0b3J5LmxvY2F0aW9uLFxuXHRcdFx0XHRhY3Rpb246IHJlcGxhY2UgPyBcIlJFUExBQ0VcIiA6IFwiUFVTSFwiXG5cdFx0XHR9KSkgcmV0dXJuO1xuXHRcdH1cblx0fVxuXHRyb3V0ZXIuaGlzdG9yeS5faWdub3JlTmV4dEJlZm9yZVVubG9hZD8uKGhyZWYpO1xuXHRpZiAocmVwbGFjZSkgd2luZG93LmxvY2F0aW9uLnJlcGxhY2UoaHJlZik7XG5cdGVsc2Ugd2luZG93LmxvY2F0aW9uLmhyZWYgPSBocmVmO1xufVxuLyoqXG4qIEluIG5vbi1wcm9kdWN0aW9uIGVudmlyb25tZW50cyxcbiogYXVnbWVudCB0aGUgUm91dGVyQ29yZSBjbGFzcyB3aXRoIGEgYF9yZWZyZXNoUm91dGVgIG1ldGhvZFxuKiBkZWRpY2F0ZWQgdG8gSE1SLlxuKi9cbmlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0Um91dGVyQ29yZS5wcm90b3R5cGUuX3JlcGxhY2VSb3V0ZUNodW5rID0gcmVwbGFjZVJvdXRlQ2h1bms7XG5cdFJvdXRlckNvcmUucHJvdG90eXBlLl9yZWZyZXNoUm91dGUgPSBhc3luYyBmdW5jdGlvbigpIHtcblx0XHR0aGlzLl9zZXJ2ZXJSZXN1bHQgPSB2b2lkIDA7XG5cdFx0dGhpcy51cGRhdGVMYXRlc3RMb2NhdGlvbigpO1xuXHRcdGF3YWl0IHJlZnJlc2hDbGllbnRSb3V0ZSh0aGlzKTtcblx0fTtcbn1cbi8qKiBFcnJvciB0aHJvd24gd2hlbiBzZWFyY2ggcGFyYW1ldGVyIHZhbGlkYXRpb24gZmFpbHMuICovXG52YXIgU2VhcmNoUGFyYW1FcnJvciA9IGNsYXNzIGV4dGVuZHMgRXJyb3Ige307XG4vKiogRXJyb3IgdGhyb3duIHdoZW4gcGF0aCBwYXJhbWV0ZXIgcGFyc2luZy92YWxpZGF0aW9uIGZhaWxzLiAqL1xudmFyIFBhdGhQYXJhbUVycm9yID0gY2xhc3MgZXh0ZW5kcyBFcnJvciB7fTtcbmNvbnN0IG5vcm1hbGl6ZSA9IChzdHIpID0+IHN0ci5lbmRzV2l0aChcIi9cIikgJiYgc3RyLmxlbmd0aCA+IDEgPyBzdHIuc2xpY2UoMCwgLTEpIDogc3RyO1xuZnVuY3Rpb24gY29tcGFyZVBhdGhzKGEsIGIpIHtcblx0cmV0dXJuIG5vcm1hbGl6ZShhKSA9PT0gbm9ybWFsaXplKGIpO1xufVxuLyoqXG4qIExhemlseSBpbXBvcnQgYSBtb2R1bGUgZnVuY3Rpb24gYW5kIGZvcndhcmQgYXJndW1lbnRzIHRvIGl0LCByZXRhaW5pbmdcbiogcGFyYW1ldGVyIGFuZCByZXR1cm4gdHlwZXMgZm9yIHRoZSBzZWxlY3RlZCBleHBvcnQga2V5LlxuKi9cbmZ1bmN0aW9uIGxhenlGbihmbiwga2V5KSB7XG5cdHJldHVybiBhc3luYyAoLi4uYXJncykgPT4ge1xuXHRcdHJldHVybiAoYXdhaXQgZm4oKSlba2V5IHx8IFwiZGVmYXVsdFwiXSguLi5hcmdzKTtcblx0fTtcbn1cbi8qKiBDcmVhdGUgYW4gaW5pdGlhbCBSb3V0ZXJTdGF0ZSBmcm9tIGEgcGFyc2VkIGxvY2F0aW9uLiAqL1xuZnVuY3Rpb24gZ2V0SW5pdGlhbFJvdXRlclN0YXRlKGxvY2F0aW9uKSB7XG5cdHJldHVybiB7XG5cdFx0aXNMb2FkaW5nOiBmYWxzZSxcblx0XHRzdGF0dXM6IFwiaWRsZVwiLFxuXHRcdHJlc29sdmVkTG9jYXRpb246IHZvaWQgMCxcblx0XHRsb2NhdGlvbixcblx0XHRtYXRjaGVzOiBbXVxuXHR9O1xufVxuZnVuY3Rpb24gdmFsaWRhdGVTZWFyY2godmFsaWRhdGVTZWFyY2gsIGlucHV0KSB7XG5cdGlmICh2YWxpZGF0ZVNlYXJjaCA9PSBudWxsKSByZXR1cm4ge307XG5cdGlmIChcIn5zdGFuZGFyZFwiIGluIHZhbGlkYXRlU2VhcmNoKSB7XG5cdFx0Y29uc3QgcmVzdWx0ID0gdmFsaWRhdGVTZWFyY2hbXCJ+c3RhbmRhcmRcIl0udmFsaWRhdGUoaW5wdXQpO1xuXHRcdGlmIChyZXN1bHQgaW5zdGFuY2VvZiBQcm9taXNlKSB0aHJvdyBuZXcgU2VhcmNoUGFyYW1FcnJvcihcIkFzeW5jIHZhbGlkYXRpb24gbm90IHN1cHBvcnRlZFwiKTtcblx0XHRpZiAocmVzdWx0Lmlzc3VlcykgdGhyb3cgbmV3IFNlYXJjaFBhcmFtRXJyb3IoSlNPTi5zdHJpbmdpZnkocmVzdWx0Lmlzc3Vlcywgdm9pZCAwLCAyKSwgeyBjYXVzZTogcmVzdWx0IH0pO1xuXHRcdHJldHVybiByZXN1bHQudmFsdWU7XG5cdH1cblx0aWYgKFwicGFyc2VcIiBpbiB2YWxpZGF0ZVNlYXJjaCkgcmV0dXJuIHZhbGlkYXRlU2VhcmNoLnBhcnNlKGlucHV0KTtcblx0aWYgKHR5cGVvZiB2YWxpZGF0ZVNlYXJjaCA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gdmFsaWRhdGVTZWFyY2goaW5wdXQpO1xuXHRyZXR1cm4ge307XG59XG5mdW5jdGlvbiByZXNvbHZlTmV4dFBhcmFtcyhzcGVjLCBiYXNlKSB7XG5cdGlmIChzcGVjID09PSB2b2lkIDAgfHwgc3BlYyA9PT0gdHJ1ZSkgcmV0dXJuIGJhc2U7XG5cdGNvbnN0IG5leHQgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuXHRpZiAoc3BlYyA9PT0gZmFsc2UgfHwgc3BlYyA9PT0gbnVsbCkgcmV0dXJuIG5leHQ7XG5cdGlmICh0eXBlb2Ygc3BlYyA9PT0gXCJmdW5jdGlvblwiKSB7XG5cdFx0T2JqZWN0LmFzc2lnbihuZXh0LCBiYXNlKTtcblx0XHRyZXR1cm4gT2JqZWN0LmFzc2lnbihuZXh0LCBzcGVjKG5leHQpKTtcblx0fVxuXHRyZXR1cm4gT2JqZWN0LmFzc2lnbihuZXh0LCBiYXNlLCBzcGVjKTtcbn1cbmZ1bmN0aW9uIG5lZWRzSW5oZXJpdGVkUGFyYW1zKHNwZWMsIGludGVycG9sYXRpb24pIHtcblx0aWYgKHR5cGVvZiBzcGVjID09PSBcImZ1bmN0aW9uXCIpIHJldHVybiB0cnVlO1xuXHRpZiAoIWludGVycG9sYXRpb24gfHwgc3BlYyA9PT0gZmFsc2UgfHwgc3BlYyA9PT0gbnVsbCkgcmV0dXJuIGZhbHNlO1xuXHRyZXR1cm4gc3BlYyA9PT0gdm9pZCAwIHx8IHNwZWMgPT09IHRydWUgfHwgaW50ZXJwb2xhdGlvbi5zb21lKChwYXJ0KSA9PiB0eXBlb2YgcGFydCAhPT0gXCJzdHJpbmdcIiAmJiAhaGFzT3duLmNhbGwoc3BlYywgcGFydFsxXSkpO1xufVxuY29uc3QgRU1QVFlfUkVDT1JEID0gT2JqZWN0LmZyZWV6ZSh7fSk7XG5mdW5jdGlvbiBnZXRTZWFyY2hNaWRkbGV3YXJlcyhkZXN0Um91dGVzLCBpbmNsdWRlVmFsaWRhdGVTZWFyY2gpIHtcblx0Y29uc3QgbWlkZGxld2FyZXMgPSBbXTtcblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBkZXN0Um91dGVzLmxlbmd0aDsgaSsrKSB7XG5cdFx0Y29uc3Qgcm91dGVPcHRpb25zID0gZGVzdFJvdXRlc1tpXS5vcHRpb25zO1xuXHRcdGlmIChcInNlYXJjaFwiIGluIHJvdXRlT3B0aW9ucykge1xuXHRcdFx0aWYgKHJvdXRlT3B0aW9ucy5zZWFyY2g/Lm1pZGRsZXdhcmVzKSBtaWRkbGV3YXJlcy5wdXNoKC4uLnJvdXRlT3B0aW9ucy5zZWFyY2gubWlkZGxld2FyZXMpO1xuXHRcdH0gZWxzZSBpZiAocm91dGVPcHRpb25zLnByZVNlYXJjaEZpbHRlcnMgfHwgcm91dGVPcHRpb25zLnBvc3RTZWFyY2hGaWx0ZXJzKSB7XG5cdFx0XHRjb25zdCBsZWdhY3lNaWRkbGV3YXJlID0gKHsgc2VhcmNoLCBuZXh0IH0pID0+IHtcblx0XHRcdFx0Y29uc3QgcmVzdWx0ID0gbmV4dChyb3V0ZU9wdGlvbnMucHJlU2VhcmNoRmlsdGVycyA/IHJvdXRlT3B0aW9ucy5wcmVTZWFyY2hGaWx0ZXJzLnJlZHVjZSgocHJldiwgbmV4dCkgPT4gbmV4dChwcmV2KSwgc2VhcmNoKSA6IHNlYXJjaCk7XG5cdFx0XHRcdHJldHVybiByb3V0ZU9wdGlvbnMucG9zdFNlYXJjaEZpbHRlcnMgPyByb3V0ZU9wdGlvbnMucG9zdFNlYXJjaEZpbHRlcnMucmVkdWNlKChwcmV2LCBuZXh0KSA9PiBuZXh0KHByZXYpLCByZXN1bHQpIDogcmVzdWx0O1xuXHRcdFx0fTtcblx0XHRcdG1pZGRsZXdhcmVzLnB1c2gobGVnYWN5TWlkZGxld2FyZSk7XG5cdFx0fVxuXHRcdGNvbnN0IHJvdXRlVmFsaWRhdGVTZWFyY2ggPSByb3V0ZU9wdGlvbnMudmFsaWRhdGVTZWFyY2g7XG5cdFx0aWYgKGluY2x1ZGVWYWxpZGF0ZVNlYXJjaCAmJiByb3V0ZVZhbGlkYXRlU2VhcmNoKSB7XG5cdFx0XHRjb25zdCB2YWxpZGF0ZSA9ICh7IHNlYXJjaCwgbmV4dCwgbWV0YSB9KSA9PiB7XG5cdFx0XHRcdGNvbnN0IHJlc3VsdCA9IG5leHQoc2VhcmNoKTtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRjb25zdCB2YWxpZGF0ZWQgPSB2YWxpZGF0ZVNlYXJjaChyb3V0ZVZhbGlkYXRlU2VhcmNoLCByZXN1bHQpO1xuXHRcdFx0XHRcdGlmIChtZXRhICYmIHZhbGlkYXRlZCkge1xuXHRcdFx0XHRcdFx0Zm9yIChjb25zdCBrZXkgaW4gdmFsaWRhdGVkKSBpZiAoIShrZXkgaW4gcmVzdWx0KSkgKG1ldGEuZGVmYXVsdGVkIHx8PSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpKS5zZXQoa2V5LCB2YWxpZGF0ZWRba2V5XSk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0XHQuLi5yZXN1bHQsXG5cdFx0XHRcdFx0XHQuLi52YWxpZGF0ZWRcblx0XHRcdFx0XHR9O1xuXHRcdFx0XHR9IGNhdGNoIHt9XG5cdFx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0XHR9O1xuXHRcdFx0bWlkZGxld2FyZXMucHVzaCh2YWxpZGF0ZSk7XG5cdFx0fVxuXHR9XG5cdHJldHVybiBtaWRkbGV3YXJlcztcbn1cbmZ1bmN0aW9uIGFwcGx5U2VhcmNoTWlkZGxld2FyZShtaWRkbGV3YXJlcywgc2VhcmNoLCBkZXN0KSB7XG5cdGNvbnN0IGFwcGx5TmV4dCA9IChpbmRleCwgY3VycmVudFNlYXJjaCwgbWV0YSkgPT4ge1xuXHRcdGlmIChpbmRleCA+PSBtaWRkbGV3YXJlcy5sZW5ndGgpIHtcblx0XHRcdGlmICghZGVzdC5zZWFyY2gpIHJldHVybiB7fTtcblx0XHRcdGlmIChkZXN0LnNlYXJjaCA9PT0gdHJ1ZSkgcmV0dXJuIGN1cnJlbnRTZWFyY2g7XG5cdFx0XHRjb25zdCByZXN1bHQgPSBmdW5jdGlvbmFsVXBkYXRlKGRlc3Quc2VhcmNoLCBjdXJyZW50U2VhcmNoKTtcblx0XHRcdGlmIChtZXRhKSBtZXRhLmV4cGxpY2l0ID0gcmVzdWx0O1xuXHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHR9XG5cdFx0Y29uc3QgbmV4dCA9IChuZXdTZWFyY2gsIGNvbGxlY3RNZXRhKSA9PiB7XG5cdFx0XHRpZiAoY29sbGVjdE1ldGEpIHtcblx0XHRcdFx0Y29uc3QgbmV4dE1ldGEgPSBtZXRhIHx8IHt9O1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdHNlYXJjaDogYXBwbHlOZXh0KGluZGV4ICsgMSwgbmV3U2VhcmNoLCBuZXh0TWV0YSksXG5cdFx0XHRcdFx0bWV0YTogbmV4dE1ldGFcblx0XHRcdFx0fTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBhcHBseU5leHQoaW5kZXggKyAxLCBuZXdTZWFyY2gsIG1ldGEpO1xuXHRcdH07XG5cdFx0cmV0dXJuIG1pZGRsZXdhcmVzW2luZGV4XSh7XG5cdFx0XHRzZWFyY2g6IGN1cnJlbnRTZWFyY2gsXG5cdFx0XHRuZXh0LFxuXHRcdFx0bWV0YVxuXHRcdH0pO1xuXHR9O1xuXHRyZXR1cm4gYXBwbHlOZXh0KDAsIHNlYXJjaCk7XG59XG5mdW5jdGlvbiBmaW5kR2xvYmFsTm90Rm91bmRSb3V0ZUlkKG5vdEZvdW5kTW9kZSwgcm91dGVzKSB7XG5cdGlmIChub3RGb3VuZE1vZGUgIT09IFwicm9vdFwiKSB7XG5cdFx0bGV0IGZhbGxiYWNrO1xuXHRcdGZvciAobGV0IGkgPSByb3V0ZXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcblx0XHRcdGNvbnN0IHJvdXRlID0gcm91dGVzW2ldO1xuXHRcdFx0aWYgKHJvdXRlLm9wdGlvbnMubm90Rm91bmRDb21wb25lbnQpIHJldHVybiByb3V0ZS5pZDtcblx0XHRcdGZhbGxiYWNrIHx8PSByb3V0ZS5jaGlsZHJlbiAmJiByb3V0ZS5pZDtcblx0XHR9XG5cdFx0aWYgKGZhbGxiYWNrKSByZXR1cm4gZmFsbGJhY2s7XG5cdH1cblx0cmV0dXJuIHJvb3RSb3V0ZUlkO1xufVxuZnVuY3Rpb24gZXh0cmFjdFN0cmljdFBhcmFtcyhyb3V0ZSwgYWNjdW11bGF0ZWRQYXJhbXMpIHtcblx0Y29uc3QgcGFyc2VQYXJhbXMgPSByb3V0ZS5vcHRpb25zLnBhcmFtcz8ucGFyc2UgPz8gcm91dGUub3B0aW9ucy5wYXJzZVBhcmFtcztcblx0aWYgKHBhcnNlUGFyYW1zKSBPYmplY3QuYXNzaWduKGFjY3VtdWxhdGVkUGFyYW1zLCBwYXJzZVBhcmFtcyhhY2N1bXVsYXRlZFBhcmFtcykpO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBQYXRoUGFyYW1FcnJvciwgUm91dGVyQ29yZSwgU2VhcmNoUGFyYW1FcnJvciwgX2dldFVzZXJIaXN0b3J5U3RhdGUsIGRlZmF1bHRTZXJpYWxpemVFcnJvciwgZ2V0SW5pdGlhbFJvdXRlclN0YXRlLCBnZXRMb2NhdGlvbkNoYW5nZUluZm8sIGxhenlGbiwgbGlmZWN5Y2xlRW5kLCBydW5Sb3V0ZUxpZmVjeWNsZSwgdHJhaWxpbmdTbGFzaE9wdGlvbnMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGVyLmpzLm1hcCIsImltcG9ydCB7IGlzTm90Rm91bmQgfSBmcm9tIFwiLi9ub3QtZm91bmQuanNcIjtcbmltcG9ydCB7IGlzUmVkaXJlY3QgfSBmcm9tIFwiLi9yZWRpcmVjdC5qc1wiO1xuaW1wb3J0IHsgZGVoeWRyYXRlU3NyTWF0Y2hJZCB9IGZyb20gXCIuL3Nzci9zc3ItbWF0Y2gtaWQuanNcIjtcbmltcG9ydCB7IGdldExvY2F0aW9uQ2hhbmdlSW5mbywgbGlmZWN5Y2xlRW5kLCBydW5Sb3V0ZUxpZmVjeWNsZSB9IGZyb20gXCIuL3JvdXRlci5qc1wiO1xuLy8jcmVnaW9uIHNyYy9sb2FkLWNsaWVudC50c1xuZnVuY3Rpb24gcmVwbGFjZVJvdXRlQ2h1bmsocm91dGUsIGxhenlGbikge1xuXHRyb3V0ZS5sYXp5Rm4gPSBsYXp5Rm4gPz8gcm91dGUubGF6eUZuO1xuXHRyb3V0ZS5fbGF6eSA9IHZvaWQgMDtcbn1cbmZ1bmN0aW9uIHByZWxvYWRDb21wb25lbnQocm91dGUsIHR5cGUpIHtcblx0cmV0dXJuIHJvdXRlLm9wdGlvbnNbdHlwZV0/LnByZWxvYWQ/LigpO1xufVxuZnVuY3Rpb24gbG9hZENvbXBvbmVudHMocm91dGUsIG9uUGVuZGluZ1JlYWR5KSB7XG5cdGNvbnN0IGNvbXBvbmVudCA9IHByZWxvYWRDb21wb25lbnQocm91dGUsIFwiY29tcG9uZW50XCIpO1xuXHRsZXQgcGVuZGluZyA9IHByZWxvYWRDb21wb25lbnQocm91dGUsIFwicGVuZGluZ0NvbXBvbmVudFwiKTtcblx0aWYgKG9uUGVuZGluZ1JlYWR5KSB7XG5cdFx0aWYgKHBlbmRpbmcpIHBlbmRpbmcgPSBwZW5kaW5nLnRoZW4ob25QZW5kaW5nUmVhZHkpO1xuXHRcdGVsc2Ugb25QZW5kaW5nUmVhZHkoKTtcblx0fVxuXHRpZiAoY29tcG9uZW50ICYmIHBlbmRpbmcpIHJldHVybiBQcm9taXNlLmFsbChbY29tcG9uZW50LCBwZW5kaW5nXSkudGhlbigoKSA9PiB7fSk7XG5cdHJldHVybiBjb21wb25lbnQgPz8gcGVuZGluZztcbn1cbmZ1bmN0aW9uIGxvYWRSb3V0ZUNodW5rKHJvdXRlLCBjb21wb25lbnRUeXBlLCBvblBlbmRpbmdSZWFkeSkge1xuXHRjb25zdCBhZnRlckxhenkgPSAoKSA9PiBjb21wb25lbnRUeXBlID09PSBmYWxzZSA/IHZvaWQgMCA6IGNvbXBvbmVudFR5cGUgPyBwcmVsb2FkQ29tcG9uZW50KHJvdXRlLCBjb21wb25lbnRUeXBlKSA6IGxvYWRDb21wb25lbnRzKHJvdXRlLCBvblBlbmRpbmdSZWFkeSk7XG5cdGNvbnN0IGN1cnJlbnQgPSByb3V0ZS5fbGF6eTtcblx0aWYgKGN1cnJlbnQpIHJldHVybiBjdXJyZW50ID09PSB0cnVlID8gYWZ0ZXJMYXp5KCkgOiBjdXJyZW50LnRoZW4oYWZ0ZXJMYXp5KTtcblx0aWYgKCFyb3V0ZS5sYXp5Rm4pIHJldHVybiBhZnRlckxhenkoKTtcblx0Y29uc3QgcHJvbWlzZSA9IHJvdXRlLmxhenlGbigpLnRoZW4oKGxhenlSb3V0ZSkgPT4ge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgfHwgcm91dGUuX2xhenkgPT09IHByb21pc2UpIHtcblx0XHRcdGNvbnN0IHsgaWQ6IF9pZCwgLi4ub3B0aW9ucyB9ID0gbGF6eVJvdXRlLm9wdGlvbnM7XG5cdFx0XHRPYmplY3QuYXNzaWduKHJvdXRlLm9wdGlvbnMsIG9wdGlvbnMpO1xuXHRcdFx0cm91dGUuX2xhenkgPSB0cnVlO1xuXHRcdH1cblx0fSwgKGVycm9yKSA9PiB7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiB8fCByb3V0ZS5fbGF6eSA9PT0gcHJvbWlzZSkgcm91dGUuX2xhenkgPSB2b2lkIDA7XG5cdFx0dGhyb3cgZXJyb3I7XG5cdH0pO1xuXHRyb3V0ZS5fbGF6eSA9IHByb21pc2U7XG5cdHJldHVybiBwcm9taXNlLnRoZW4oYWZ0ZXJMYXp5KTtcbn1cbi8qKiBSZXR1cm4gdGhlIHN0cnVjdHVyYWwgbGFuZSB0aHJvdWdoIHRoZSBmaXJzdCB0ZXJtaW5hbCByZW5kZXIgYm91bmRhcnkuICovXG5mdW5jdGlvbiBfZ2V0UmVuZGVyZWRNYXRjaGVzKG1hdGNoZXMpIHtcblx0Y29uc3QgZW5kID0gbWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5zdGF0dXMgIT09IFwic3VjY2Vzc1wiIHx8IG1hdGNoLl9ub3RGb3VuZCkgKyAxO1xuXHRyZXR1cm4gZW5kICYmIGVuZCA8IG1hdGNoZXMubGVuZ3RoID8gbWF0Y2hlcy5zbGljZSgwLCBlbmQpIDogbWF0Y2hlcztcbn1cbi8qKlxuKiBUcnV0aHkgd2hlbiB0aGUgdHJhbnNhY3Rpb24gcHVibGlzaGluZyBgbG9jYXRpb25gIGxlYXZlcyBgcm91dGVJZGAgb3V0IG9mIGl0c1xuKiBtYXRjaGVzLCBzbyBzdWJzY3JpYmVycyBzY29wZWQgdG8gdGhhdCByb3V0ZSBjYW4gc2tpcCB0aGUgcHVibGljYXRpb246IHRoZVxuKiByb3V0ZSB1bm1vdW50cyB3aGVuIHRoZSB0cmFuc2FjdGlvbiBjb21taXRzLCBhbmQgYSB0cmFuc2FjdGlvbiB0aGF0IGVuZHNcbiogb3RoZXJ3aXNlIGlzIHN1cGVyc2VkZWQgb3IgcmVkaXJlY3RlZCBieSBhIG5ld2VyIHB1YmxpY2F0aW9uLiBPbmx5IHZhbGlkXG4qIHN5bmNocm9ub3VzbHkgaW5zaWRlIHRoZSBwdWJsaWNhdGlvbjogdGhlIHRyYW5zYWN0aW9uJ3MgbWF0Y2hlcyBhcmUgZW1wdGllZFxuKiBhdCBjb21taXQgYW5kIGJlZm9yZSBmb2xsb3dpbmcgYSByZWRpcmVjdC4gUHVibGljYXRpb25zIHdpdGhvdXQgYSBtYXRjaGluZ1xuKiB0cmFuc2FjdGlvbiAoaHlkcmF0aW9uKSBhbmQgc2NvcGVzIHdpdGhvdXQgYSByb3V0ZSBuZXZlciBkZXBhcnQuXG4qL1xuZnVuY3Rpb24gX2lzUm91dGVEZXBhcnRpbmcocm91dGVyLCByb3V0ZUlkLCBsb2NhdGlvbikge1xuXHRjb25zdCB0eCA9IHJvdXRlci5fdHg7XG5cdHJldHVybiByb3V0ZUlkICYmIHR4Py5bMl0gPT09IGxvY2F0aW9uICYmICF0eFszXS5zb21lKChtYXRjaCkgPT4gbWF0Y2gucm91dGVJZCA9PT0gcm91dGVJZCk7XG59XG4vKiogUmV0dXJuIHRoZSBsYW5lIHdob3NlIGRvY3VtZW50IGFzc2V0cyBiZWxvbmcgdG8gdGhlIGN1cnJlbnQgcHJlc2VudGF0aW9uLiAqL1xuZnVuY3Rpb24gX2dldEFzc2V0TWF0Y2hlcyhtYXRjaGVzKSB7XG5cdGxldCBlbmQgPSBtYXRjaGVzLmxlbmd0aDtcblx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGVuZDsgaW5kZXgrKykge1xuXHRcdGNvbnN0IG1hdGNoID0gbWF0Y2hlc1tpbmRleF07XG5cdFx0aWYgKG1hdGNoLl9hc3NldEVuZCAhPT0gdm9pZCAwKSB7XG5cdFx0XHRlbmQgPSBNYXRoLm1pbihlbmQsIE1hdGgubWF4KGluZGV4ICsgMSwgbWF0Y2guX2Fzc2V0RW5kKSk7XG5cdFx0XHRjb250aW51ZTtcblx0XHR9XG5cdFx0aWYgKG1hdGNoLnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIgfHwgbWF0Y2guX25vdEZvdW5kKSB7XG5cdFx0XHRlbmQgPSBpbmRleCArIDE7XG5cdFx0XHRicmVhaztcblx0XHR9XG5cdH1cblx0cmV0dXJuIGVuZCA8IG1hdGNoZXMubGVuZ3RoID8gbWF0Y2hlcy5zbGljZSgwLCBlbmQpIDogbWF0Y2hlcztcbn1cbmNvbnN0IFNVQ0NFU1MgPSAwO1xuY29uc3QgRVJST1IgPSAxO1xuY29uc3QgTk9UX0ZPVU5EID0gMjtcbmNvbnN0IFJFRElSRUNURUQgPSAzO1xuY29uc3QgQ0FOQ0VMRURfT1VUQ09NRSA9IFs0XTtcbmZ1bmN0aW9uIGlzQ29udHJvbChyZXN1bHQpIHtcblx0cmV0dXJuIHR5cGVvZiByZXN1bHRbMF0gPT09IFwibnVtYmVyXCI7XG59XG5mdW5jdGlvbiB3YWl0Rm9yKHZhbHVlLCBzaWduYWwpIHtcblx0aWYgKHNpZ25hbC5hYm9ydGVkKSByZXR1cm4gUHJvbWlzZS5yYWNlKFtQcm9taXNlLnJlamVjdChzaWduYWwpLCB2YWx1ZV0pO1xuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IGFib3J0ID0gKCkgPT4gcmVqZWN0KHNpZ25hbCk7XG5cdFx0c2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBhYm9ydCwgeyBvbmNlOiB0cnVlIH0pO1xuXHRcdFByb21pc2UucmVzb2x2ZSh2YWx1ZSkudGhlbihyZXNvbHZlLCByZWplY3QpLnRoZW4oKCkgPT4gc2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBhYm9ydCkpO1xuXHR9KTtcbn1cbmZ1bmN0aW9uIGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpIHtcblx0cmV0dXJuIHJvdXRlci5yb3V0ZXNCeUlkW21hdGNoLnJvdXRlSWRdO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplKHZhbHVlLCByZWplY3RlZCwgcm91dGVJZCkge1xuXHRpZiAoaXNSZWRpcmVjdCh2YWx1ZSkpIHJldHVybiBbUkVESVJFQ1RFRCwgdmFsdWVdO1xuXHRpZiAoaXNOb3RGb3VuZCh2YWx1ZSkpIHtcblx0XHR2YWx1ZS5yb3V0ZUlkIHx8PSByb3V0ZUlkO1xuXHRcdHJldHVybiBbTk9UX0ZPVU5ELCB2YWx1ZV07XG5cdH1cblx0aWYgKCFyZWplY3RlZCkgcmV0dXJuIFtTVUNDRVNTLCB2YWx1ZV07XG5cdGlmICh0eXBlb2YgdmFsdWU/LnRoZW4gPT09IFwiZnVuY3Rpb25cIikgdmFsdWUgPSBuZXcgRXJyb3IoXCJBIFByb21pc2Ugd2FzIHRocm93blwiLCB7IGNhdXNlOiB2YWx1ZSB9KTtcblx0cmV0dXJuIFtFUlJPUiwgdmFsdWVdO1xufVxuZnVuY3Rpb24gbm9ybWFsaXplRXJyb3Iocm91dGUsIGNhdXNlKSB7XG5cdGxldCBvdXRjb21lID0gbm9ybWFsaXplKGNhdXNlLCB0cnVlLCByb3V0ZS5pZCk7XG5cdGlmIChvdXRjb21lWzBdICE9PSBFUlJPUikgcmV0dXJuIG91dGNvbWU7XG5cdHRyeSB7XG5cdFx0cm91dGUub3B0aW9ucy5vbkVycm9yPy4ob3V0Y29tZVsxXSk7XG5cdH0gY2F0Y2ggKG9uRXJyb3JDYXVzZSkge1xuXHRcdG91dGNvbWUgPSBub3JtYWxpemUob25FcnJvckNhdXNlLCB0cnVlLCByb3V0ZS5pZCk7XG5cdH1cblx0cmV0dXJuIG91dGNvbWU7XG59XG5mdW5jdGlvbiBub3JtYWxpemVMYW5lRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIG9wdGlvbnMpIHtcblx0aWYgKG9wdGlvbnNbMF0uc2lnbmFsLmFib3J0ZWQpIHJldHVybiBDQU5DRUxFRF9PVVRDT01FO1xuXHRyZXR1cm4gbWF0ZXJpYWxpemVSZWRpcmVjdChyb3V0ZXIsIGxhbmUsIHJvdXRlLCBub3JtYWxpemVFcnJvcihyb3V0ZSwgY2F1c2UpLCBvcHRpb25zKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIGNvbnRleHR1YWxpemUocm91dGVyLCBsYW5lLCBvcHRpb25zLCBlbmQsIHBsYW5TdWNjZXNzZnVsTGFuZSwgcmV0YWluZWRFbmQpIHtcblx0Y29uc3QgW2xvY2F0aW9uLCBtYXRjaGVzXSA9IGxhbmU7XG5cdGNvbnN0IHNpZ25hbCA9IG9wdGlvbnNbMF0uc2lnbmFsO1xuXHRjb25zdCBwcmVsb2FkID0gISFvcHRpb25zWzNdO1xuXHRmb3IgKGxldCBpbmRleCA9IG9wdGlvbnNbNl0gPz8gMDsgaW5kZXggPCBlbmQ7IGluZGV4KyspIHtcblx0XHRjb25zdCBtYXRjaCA9IG1hdGNoZXNbaW5kZXhdO1xuXHRcdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCk7XG5cdFx0bWF0Y2guYWJvcnRDb250cm9sbGVyID0gb3B0aW9uc1swXTtcblx0XHRjb25zdCBwYXJlbnRDb250ZXh0ID0gbWF0Y2hlc1tpbmRleCAtIDFdPy5jb250ZXh0ID8/IHJvdXRlci5vcHRpb25zLmNvbnRleHQgPz8ge307XG5cdFx0Y29uc3QgY29tbW9uID0ge1xuXHRcdFx0cGFyYW1zOiBtYXRjaC5wYXJhbXMsXG5cdFx0XHRsb2NhdGlvbixcblx0XHRcdG5hdmlnYXRlOiAob3B0cykgPT4gcm91dGVyLm5hdmlnYXRlKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0X2Zyb21Mb2NhdGlvbjogbG9jYXRpb25cblx0XHRcdH0pLFxuXHRcdFx0YnVpbGRMb2NhdGlvbjogcm91dGVyLmJ1aWxkTG9jYXRpb24sXG5cdFx0XHRjYXVzZTogcHJlbG9hZCA/IFwicHJlbG9hZFwiIDogbWF0Y2guY2F1c2UsXG5cdFx0XHRhYm9ydENvbnRyb2xsZXI6IG9wdGlvbnNbMF0sXG5cdFx0XHRwcmVsb2FkLFxuXHRcdFx0bWF0Y2hlcyxcblx0XHRcdHJvdXRlSWQ6IHJvdXRlLmlkXG5cdFx0fTtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3Qgcm91dGVDb250ZXh0ID0gbWF0Y2guX2N0eCB8fD0gcm91dGUub3B0aW9ucy5jb250ZXh0ID8gcm91dGUub3B0aW9ucy5jb250ZXh0KHtcblx0XHRcdFx0Li4uY29tbW9uLFxuXHRcdFx0XHRkZXBzOiBtYXRjaC5sb2FkZXJEZXBzLFxuXHRcdFx0XHRjb250ZXh0OiBwYXJlbnRDb250ZXh0XG5cdFx0XHR9KSB8fCB7fSA6IHZvaWQgMDtcblx0XHRcdG1hdGNoLmNvbnRleHQgPSB7XG5cdFx0XHRcdC4uLnBhcmVudENvbnRleHQsXG5cdFx0XHRcdC4uLnJvdXRlQ29udGV4dFxuXHRcdFx0fTtcblx0XHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdFx0cmVsZWFzZUZsaWdodChyb3V0ZXIsIG1hdGNoKTtcblx0XHRcdHJldHVybiBbaW5kZXgsIG5vcm1hbGl6ZUxhbmVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCBjYXVzZSwgb3B0aW9ucyldO1xuXHRcdH1cblx0XHRpZiAoc2lnbmFsLmFib3J0ZWQpIHJldHVybiBbaW5kZXgsIENBTkNFTEVEX09VVENPTUVdO1xuXHRcdGNvbnN0IHZhbGlkYXRpb25FcnJvciA9IG1hdGNoLnBhcmFtc0Vycm9yID8/IG1hdGNoLnNlYXJjaEVycm9yO1xuXHRcdGlmICh2YWxpZGF0aW9uRXJyb3IgIT09IHZvaWQgMCkge1xuXHRcdFx0cmVsZWFzZUZsaWdodChyb3V0ZXIsIG1hdGNoKTtcblx0XHRcdHJldHVybiBbaW5kZXgsIG5vcm1hbGl6ZUxhbmVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCB2YWxpZGF0aW9uRXJyb3IsIG9wdGlvbnMpXTtcblx0XHR9XG5cdFx0Y29uc3QgYmVmb3JlTG9hZCA9IHJvdXRlLm9wdGlvbnMuYmVmb3JlTG9hZDtcblx0XHRpZiAoIWJlZm9yZUxvYWQpIGNvbnRpbnVlO1xuXHRcdGNvbnN0IHByZXZpb3VzU3RhdHVzID0gbWF0Y2guc3RhdHVzO1xuXHRcdGlmIChpbmRleCA+PSByZXRhaW5lZEVuZCkge1xuXHRcdFx0bWF0Y2guc3RhdHVzID0gXCJwZW5kaW5nXCI7XG5cdFx0XHRvcHRpb25zWzddPy4oKTtcblx0XHR9XG5cdFx0dHJ5IHtcblx0XHRcdHNldEZldGNoaW5nKHJvdXRlciwgbWF0Y2gsIFwiYmVmb3JlTG9hZFwiLCBvcHRpb25zWzBdKTtcblx0XHRcdGNvbnN0IHZhbHVlID0gYmVmb3JlTG9hZCh7XG5cdFx0XHRcdC4uLmNvbW1vbixcblx0XHRcdFx0c2VhcmNoOiBtYXRjaC5zZWFyY2gsXG5cdFx0XHRcdGNvbnRleHQ6IG1hdGNoLmNvbnRleHQsXG5cdFx0XHRcdC4uLnJvdXRlci5vcHRpb25zLmFkZGl0aW9uYWxDb250ZXh0XG5cdFx0XHR9KTtcblx0XHRcdGNvbnN0IHJlc3VsdCA9IGF3YWl0ICh0eXBlb2YgdmFsdWU/LnRoZW4gPT09IFwiZnVuY3Rpb25cIiA/IHdhaXRGb3IodmFsdWUsIHNpZ25hbCkgOiB2YWx1ZSk7XG5cdFx0XHRpZiAoc2lnbmFsLmFib3J0ZWQpIHJldHVybiBbaW5kZXgsIENBTkNFTEVEX09VVENPTUVdO1xuXHRcdFx0Y29uc3Qgb3V0Y29tZSA9IG1hdGVyaWFsaXplUmVkaXJlY3Qocm91dGVyLCBsYW5lLCByb3V0ZSwgbm9ybWFsaXplKHJlc3VsdCwgZmFsc2UsIHJvdXRlLmlkKSwgb3B0aW9ucyk7XG5cdFx0XHRpZiAob3V0Y29tZVswXSAhPT0gU1VDQ0VTUykge1xuXHRcdFx0XHRyZWxlYXNlRmxpZ2h0KHJvdXRlciwgbWF0Y2gpO1xuXHRcdFx0XHRyZXR1cm4gW2luZGV4LCBvdXRjb21lXTtcblx0XHRcdH1cblx0XHRcdG1hdGNoLmNvbnRleHQgPSB7XG5cdFx0XHRcdC4uLm1hdGNoLmNvbnRleHQsXG5cdFx0XHRcdC4uLnJlc3VsdFxuXHRcdFx0fTtcblx0XHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdFx0cmVsZWFzZUZsaWdodChyb3V0ZXIsIG1hdGNoKTtcblx0XHRcdHJldHVybiBbaW5kZXgsIG5vcm1hbGl6ZUxhbmVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCBjYXVzZSwgb3B0aW9ucyldO1xuXHRcdH0gZmluYWxseSB7XG5cdFx0XHRtYXRjaC5zdGF0dXMgPSBwcmV2aW91c1N0YXR1cztcblx0XHRcdHNldEZldGNoaW5nKHJvdXRlciwgbWF0Y2gsIGZhbHNlLCBvcHRpb25zWzBdKTtcblx0XHR9XG5cdH1cblx0cGxhblN1Y2Nlc3NmdWxMYW5lKCk7XG59XG5mdW5jdGlvbiByZWxlYXNlT3duZWRGbGlnaHQocm91dGVyLCBtYXRjaCwgZmxpZ2h0KSB7XG5cdGlmICghZmxpZ2h0IHx8IC0tZmxpZ2h0WzJdKSByZXR1cm47XG5cdGlmIChyb3V0ZXIuX2ZsaWdodHM/LmdldChtYXRjaC5pZCkgPT09IGZsaWdodCkge1xuXHRcdGNvbnN0IGN1cnJlbnQgPSByb3V0ZXIuX3R4O1xuXHRcdGlmIChjdXJyZW50ICYmICFjdXJyZW50WzBdLnNpZ25hbC5hYm9ydGVkICYmICFjdXJyZW50WzNdLmluY2x1ZGVzKG1hdGNoKSAmJiBjdXJyZW50WzNdLnNvbWUoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkID09PSBtYXRjaC5pZCkgJiYgY3VycmVudFszXS5zb21lKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5pc0ZldGNoaW5nID09PSBcImJlZm9yZUxvYWRcIikpIHJldHVybjtcblx0XHRyb3V0ZXIuX2ZsaWdodHMuZGVsZXRlKG1hdGNoLmlkKTtcblx0fVxuXHRyZXR1cm4gZmxpZ2h0WzFdO1xufVxuZnVuY3Rpb24gcmVsZWFzZUZsaWdodChyb3V0ZXIsIG1hdGNoKSB7XG5cdGNvbnN0IGZsaWdodCA9IG1hdGNoLl9mbGlnaHQ7XG5cdG1hdGNoLl9mbGlnaHQgPSB2b2lkIDA7XG5cdHJlbGVhc2VPd25lZEZsaWdodChyb3V0ZXIsIG1hdGNoLCBmbGlnaHQpPy5hYm9ydCgpO1xufVxuLyoqXG4qIE5vdCBwYXNzaW5nIGluIGEgYG5leHRgIG93bmVyc2hpcCByZWNpcGllbnRcbiogaXMgZXF1aXZhbGVudCB0byBkaXNjYXJkaW5nIHRoZSBtYXRjaCByZXNvdXJjZXNcbiovXG5mdW5jdGlvbiB0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgcHJldmlvdXMsIG5leHQsIGRlZmVyU2FtZUlkRmxpZ2h0KSB7XG5cdGNvbnN0IGFib3J0ID0gW107XG5cdGZvciAoY29uc3QgbWF0Y2ggb2YgcHJldmlvdXMpIGlmICghbmV4dD8uaW5jbHVkZXMobWF0Y2gpKSB7XG5cdFx0Y29uc3QgZmxpZ2h0ID0gbWF0Y2guX2ZsaWdodDtcblx0XHRtYXRjaC5fZmxpZ2h0ID0gdm9pZCAwO1xuXHRcdGlmIChkZWZlclNhbWVJZEZsaWdodCAmJiBmbGlnaHQ/LlsyXSA9PT0gMSAmJiByb3V0ZXIuX2ZsaWdodHM/LmdldChtYXRjaC5pZCkgPT09IGZsaWdodCAmJiBuZXh0Py5zb21lKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5pZCA9PT0gbWF0Y2guaWQpKSBmbGlnaHRbMl0gPSAwO1xuXHRcdGVsc2Uge1xuXHRcdFx0Y29uc3QgY29udHJvbGxlciA9IHJlbGVhc2VPd25lZEZsaWdodChyb3V0ZXIsIG1hdGNoLCBmbGlnaHQpO1xuXHRcdFx0aWYgKGNvbnRyb2xsZXIpIGFib3J0LnB1c2goY29udHJvbGxlcik7XG5cdFx0fVxuXHR9XG5cdGZvciAoY29uc3QgY29udHJvbGxlciBvZiBhYm9ydCkgY29udHJvbGxlci5hYm9ydCgpO1xufVxuZnVuY3Rpb24gYWNxdWlyZU1hdGNoUmVzb3VyY2VzKG1hdGNoZXMpIHtcblx0Zm9yIChjb25zdCBtYXRjaCBvZiBtYXRjaGVzKSB7XG5cdFx0Y29uc3QgZmxpZ2h0ID0gbWF0Y2guX2ZsaWdodDtcblx0XHRpZiAoZmxpZ2h0KSBmbGlnaHRbMl0rKztcblx0fVxufVxuZnVuY3Rpb24gc2V0RmV0Y2hpbmcocm91dGVyLCBtYXRjaCwgdmFsdWUsIG93bmVyKSB7XG5cdG1hdGNoLmlzRmV0Y2hpbmcgPSB2YWx1ZTtcblx0aWYgKG93bmVyICYmIHJvdXRlci5fdHg/LlswXSAhPT0gb3duZXIpIHJldHVybjtcblx0Y29uc3Qgc3RvcmUgPSByb3V0ZXIuc3RvcmVzLmJ5Um91dGUuZ2V0KG1hdGNoLnJvdXRlSWQpO1xuXHRjb25zdCBwcmVzZW50ZWQgPSBzdG9yZT8uZ2V0KCk7XG5cdGlmIChwcmVzZW50ZWQ/LmlkID09PSBtYXRjaC5pZCkgc3RvcmUuc2V0KHtcblx0XHQuLi5wcmVzZW50ZWQsXG5cdFx0aXNGZXRjaGluZzogdmFsdWVcblx0fSk7XG59XG5mdW5jdGlvbiBnZXRMb2FkZXJDb250ZXh0KHJvdXRlciwgbGFuZSwgbWF0Y2gsIHJvdXRlLCBjb250cm9sbGVyLCBwYXJlbnRNYXRjaFByb21pc2UsIHByZWxvYWQpIHtcblx0Y29uc3QgbG9jYXRpb24gPSBsYW5lWzBdO1xuXHRyZXR1cm4ge1xuXHRcdHBhcmFtczogbWF0Y2gucGFyYW1zLFxuXHRcdGxvY2F0aW9uLFxuXHRcdG5hdmlnYXRlOiAob3B0cykgPT4gcm91dGVyLm5hdmlnYXRlKHtcblx0XHRcdC4uLm9wdHMsXG5cdFx0XHRfZnJvbUxvY2F0aW9uOiBsb2NhdGlvblxuXHRcdH0pLFxuXHRcdGNhdXNlOiBwcmVsb2FkID8gXCJwcmVsb2FkXCIgOiBtYXRjaC5jYXVzZSxcblx0XHRhYm9ydENvbnRyb2xsZXI6IGNvbnRyb2xsZXIsXG5cdFx0cHJlbG9hZCxcblx0XHRkZXBzOiBtYXRjaC5sb2FkZXJEZXBzLFxuXHRcdHBhcmVudE1hdGNoUHJvbWlzZSxcblx0XHRjb250ZXh0OiBtYXRjaC5jb250ZXh0LFxuXHRcdHJvdXRlLFxuXHRcdC4uLnJvdXRlci5vcHRpb25zLmFkZGl0aW9uYWxDb250ZXh0XG5cdH07XG59XG5hc3luYyBmdW5jdGlvbiBsb2FkUmVzb3VyY2Uocm91dGVyLCBsYW5lLCBtYXRjaCwgcm91dGUsIGxvYWRlciwgcGFyZW50TWF0Y2hQcm9taXNlLCBvcHRpb25zKSB7XG5cdGNvbnN0IG93bmVyID0gb3B0aW9uc1swXTtcblx0Y29uc3Qgc2lnbmFsID0gb3duZXIuc2lnbmFsO1xuXHRpZiAoc2lnbmFsLmFib3J0ZWQpIHJldHVybiBDQU5DRUxFRF9PVVRDT01FO1xuXHRpZiAoIWxvYWRlcikgcmV0dXJuIFtTVUNDRVNTLCB2b2lkIDBdO1xuXHRsZXQgZmxpZ2h0ID0gbWF0Y2guX2ZsaWdodDtcblx0c2V0RmV0Y2hpbmcocm91dGVyLCBtYXRjaCwgXCJsb2FkZXJcIiwgb3duZXIpO1xuXHR0cnkge1xuXHRcdGlmICghZmxpZ2h0KSB7XG5cdFx0XHRjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuXHRcdFx0ZmxpZ2h0ID0gW1xuXHRcdFx0XHRQcm9taXNlLnJlc29sdmUoKS50aGVuKCgpID0+IGxvYWRlcihnZXRMb2FkZXJDb250ZXh0KHJvdXRlciwgbGFuZSwgbWF0Y2gsIHJvdXRlLCBjb250cm9sbGVyLCBwYXJlbnRNYXRjaFByb21pc2UsICEhb3B0aW9uc1szXSkpKS50aGVuKCh2YWx1ZSkgPT4gbm9ybWFsaXplKHZhbHVlLCBmYWxzZSwgcm91dGUuaWQpLCAoY2F1c2UpID0+IG5vcm1hbGl6ZShjYXVzZSwgdHJ1ZSwgcm91dGUuaWQpKS50aGVuKChyZXN1bHQpID0+IHtcblx0XHRcdFx0XHRpZiAocmVzdWx0WzBdICE9PSBTVUNDRVNTICYmIHJvdXRlci5fZmxpZ2h0cz8uZ2V0KG1hdGNoLmlkKSA9PT0gZmxpZ2h0KSB7XG5cdFx0XHRcdFx0XHRyb3V0ZXIuX2ZsaWdodHMuZGVsZXRlKG1hdGNoLmlkKTtcblx0XHRcdFx0XHRcdGlmICghZmxpZ2h0WzJdKSBjb250cm9sbGVyLmFib3J0KCk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdHJldHVybiByZXN1bHRbMF0gPT09IEVSUk9SICYmIGZsaWdodFsyXSA/IG5vcm1hbGl6ZUVycm9yKHJvdXRlLCByZXN1bHRbMV0pIDogcmVzdWx0O1xuXHRcdFx0XHR9KSxcblx0XHRcdFx0Y29udHJvbGxlcixcblx0XHRcdFx0MVxuXHRcdFx0XTtcblx0XHRcdChyb3V0ZXIuX2ZsaWdodHMgPz89IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkpLnNldChtYXRjaC5pZCwgZmxpZ2h0KTtcblx0XHR9XG5cdFx0bWF0Y2guX2ZsaWdodCA9IGZsaWdodDtcblx0XHRtYXRjaC5hYm9ydENvbnRyb2xsZXIgPSBmbGlnaHRbMV07XG5cdFx0cmV0dXJuIG1hdGVyaWFsaXplUmVkaXJlY3Qocm91dGVyLCBsYW5lLCByb3V0ZSwgYXdhaXQgd2FpdEZvcihmbGlnaHRbMF0sIHNpZ25hbCksIG9wdGlvbnMpO1xuXHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdGlmIChjYXVzZSAhPT0gc2lnbmFsIHx8ICFzaWduYWwuYWJvcnRlZCkgdGhyb3cgY2F1c2U7XG5cdFx0cmVsZWFzZUZsaWdodChyb3V0ZXIsIG1hdGNoKTtcblx0XHRyZXR1cm4gQ0FOQ0VMRURfT1VUQ09NRTtcblx0fSBmaW5hbGx5IHtcblx0XHRzZXRGZXRjaGluZyhyb3V0ZXIsIG1hdGNoLCBmYWxzZSwgb3duZXIpO1xuXHR9XG59XG5mdW5jdGlvbiBzZXR0bGVJbnRvKG1hdGNoLCByZXN1bHQsIHByZWxvYWQpIHtcblx0aWYgKHJlc3VsdFswXSA9PT0gUkVESVJFQ1RFRCkgcmV0dXJuO1xuXHRtYXRjaC5zdGF0dXMgPSBcInN1Y2Nlc3NcIjtcblx0bWF0Y2guZXJyb3IgPSB2b2lkIDA7XG5cdGlmIChyZXN1bHRbMF0gPT09IFNVQ0NFU1MpIHtcblx0XHRtYXRjaC5sb2FkZXJEYXRhID0gcmVzdWx0WzFdO1xuXHRcdG1hdGNoLmludmFsaWQgPSBmYWxzZTtcblx0XHRtYXRjaC51cGRhdGVkQXQgPSBEYXRlLm5vdygpO1xuXHRcdG1hdGNoLnByZWxvYWQgPSBwcmVsb2FkO1xuXHR9IGVsc2UgbWF0Y2guaW52YWxpZCA9IHRydWU7XG59XG5mdW5jdGlvbiBjYWNoZUxvYWRlck1hdGNoKHJvdXRlciwgbWF0Y2gsIHBsYW5uZWQpIHtcblx0Y29uc3QgY3VycmVudCA9IHJvdXRlci5fY2FjaGUuZ2V0KG1hdGNoLmlkKTtcblx0aWYgKGN1cnJlbnQgIT09IHBsYW5uZWQgfHwgcm91dGVyLl9jb21taXR0ZWQuc29tZSgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgPT09IG1hdGNoLmlkICYmIGNhbmRpZGF0ZS5fZmxpZ2h0ID09PSBtYXRjaC5fZmxpZ2h0KSkgcmV0dXJuO1xuXHRjb25zdCBjYWNoZWQgPSB7XG5cdFx0Li4ubWF0Y2gsXG5cdFx0X25vdEZvdW5kOiB2b2lkIDAsXG5cdFx0Y29udGV4dDoge31cblx0fTtcblx0aWYgKGNhY2hlZC5fZmxpZ2h0KSBjYWNoZWQuX2ZsaWdodFsyXSsrO1xuXHRyb3V0ZXIuX2NhY2hlLnNldChtYXRjaC5pZCwgY2FjaGVkKTtcblx0aWYgKGN1cnJlbnQpIHJlbGVhc2VGbGlnaHQocm91dGVyLCBjdXJyZW50KTtcbn1cbmZ1bmN0aW9uIGdldFBhcmVudFNuYXBzaG90KG1hdGNoLCBvdXRjb21lKSB7XG5cdGlmIChvdXRjb21lWzBdID09PSBFUlJPUiB8fCBvdXRjb21lWzBdID09PSBOT1RfRk9VTkQpIHJldHVybiB7XG5cdFx0Li4ubWF0Y2gsXG5cdFx0c3RhdHVzOiBvdXRjb21lWzBdID09PSBFUlJPUiA/IFwiZXJyb3JcIiA6IFwibm90Rm91bmRcIixcblx0XHRlcnJvcjogb3V0Y29tZVsxXSxcblx0XHRfZmxpZ2h0OiB2b2lkIDBcblx0fTtcblx0cmV0dXJuIG1hdGNoO1xufVxuZnVuY3Rpb24gY3JlYXRlTG9hZGVyVGFzayhyb3V0ZXIsIGxhbmUsIGluZGV4LCB0YXNrcywgc2VtYW50aWNQYXJlbnQsIG9wdGlvbnMsIHJldGFpbmVkRW5kKSB7XG5cdGNvbnN0IG1hdGNoID0gbGFuZVsxXVtpbmRleF07XG5cdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCk7XG5cdGNvbnN0IHByZWxvYWQgPSAhIW9wdGlvbnNbM107XG5cdGNvbnN0IHBsYW5uZWRDYWNoZU1hdGNoID0gcm91dGVyLl9jYWNoZS5nZXQobWF0Y2guaWQpO1xuXHRsZXQgY29uZmlndXJlZDtcblx0bGV0IHJlbG9hZCA9IGZhbHNlO1xuXHRsZXQgcmVsb2FkRmFpbHVyZTtcblx0dHJ5IHtcblx0XHRpZiAobWF0Y2guc3RhdHVzID09PSBcInN1Y2Nlc3NcIikge1xuXHRcdFx0Y29uZmlndXJlZCA9IHJvdXRlLm9wdGlvbnMuc2hvdWxkUmVsb2FkO1xuXHRcdFx0aWYgKHR5cGVvZiBjb25maWd1cmVkID09PSBcImZ1bmN0aW9uXCIpIGNvbmZpZ3VyZWQgPSBjb25maWd1cmVkKGdldExvYWRlckNvbnRleHQocm91dGVyLCBsYW5lLCBtYXRjaCwgcm91dGUsIG9wdGlvbnNbMF0sIHNlbWFudGljUGFyZW50LCBwcmVsb2FkKSk7XG5cdFx0XHRpZiAob3B0aW9uc1swXS5zaWduYWwuYWJvcnRlZCkgcmVsb2FkRmFpbHVyZSA9IENBTkNFTEVEX09VVENPTUU7XG5cdFx0fVxuXHRcdGlmICghcmVsb2FkRmFpbHVyZSkge1xuXHRcdFx0aWYgKG1hdGNoLnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIpIHJlbG9hZCA9IHRydWU7XG5cdFx0XHRlbHNlIHtcblx0XHRcdFx0Y29uc3Qgc3RhbGVBZ2UgPSBwcmVsb2FkIHx8IG1hdGNoLnByZWxvYWQgPyByb3V0ZS5vcHRpb25zLnByZWxvYWRTdGFsZVRpbWUgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFByZWxvYWRTdGFsZVRpbWUgPz8gM2U0IDogcm91dGUub3B0aW9ucy5zdGFsZVRpbWUgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFN0YWxlVGltZSA/PyAwO1xuXHRcdFx0XHRyZWxvYWQgPSAhIShtYXRjaC5pbnZhbGlkIHx8IGNvbmZpZ3VyZWQgfHwgY29uZmlndXJlZCA9PT0gdm9pZCAwICYmIERhdGUubm93KCkgLSBtYXRjaC51cGRhdGVkQXQgPj0gc3RhbGVBZ2UgJiYgKG9wdGlvbnNbNV0gfHwgbWF0Y2guY2F1c2UgPT09IFwiZW50ZXJcIiB8fCBvcHRpb25zWzJdLnNvbWUoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLnJvdXRlSWQgPT09IG1hdGNoLnJvdXRlSWQgJiYgY2FuZGlkYXRlLmlkICE9PSBtYXRjaC5pZCkpKTtcblx0XHRcdH1cblx0XHR9XG5cdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0bWF0Y2guaW52YWxpZCA9IHRydWU7XG5cdFx0cmVsZWFzZUZsaWdodChyb3V0ZXIsIG1hdGNoKTtcblx0XHRyZWxvYWRGYWlsdXJlID0gbm9ybWFsaXplTGFuZUVycm9yKHJvdXRlciwgbGFuZSwgcm91dGUsIGNhdXNlLCBvcHRpb25zKTtcblx0fVxuXHRjb25zdCByb3V0ZUxvYWRlciA9IHJvdXRlLm9wdGlvbnMubG9hZGVyO1xuXHRjb25zdCBpc0xvYWRlckZuID0gdHlwZW9mIHJvdXRlTG9hZGVyID09PSBcImZ1bmN0aW9uXCI7XG5cdGNvbnN0IGxvYWRlciA9IGlzTG9hZGVyRm4gPyByb3V0ZUxvYWRlciA6IHJvdXRlTG9hZGVyPy5oYW5kbGVyO1xuXHRjb25zdCBwcmVsb2FkYWJsZSA9ICFwcmVsb2FkIHx8IHJvdXRlLm9wdGlvbnMucHJlbG9hZCAhPT0gZmFsc2U7XG5cdGxldCBkb25vciA9IHByZWxvYWRhYmxlICYmIHJvdXRlTG9hZGVyICYmICEocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIHJvdXRlci5fdHg/Lls2XSkgPyByb3V0ZXIuX2ZsaWdodHM/LmdldChtYXRjaC5pZCkgOiB2b2lkIDA7XG5cdGlmIChkb25vciA9PT0gbWF0Y2guX2ZsaWdodCB8fCByZWxvYWRGYWlsdXJlKSBkb25vciA9IHZvaWQgMDtcblx0ZWxzZSBpZiAoZG9ub3IgJiYgIXJlbG9hZCAmJiAhcHJlbG9hZCAmJiBjb25maWd1cmVkID09PSB2b2lkIDApIHJlbG9hZCA9IHRydWU7XG5cdGVsc2UgaWYgKCFyZWxvYWQpIGRvbm9yID0gdm9pZCAwO1xuXHRjb25zdCBiYWNrZ3JvdW5kID0gISEocm91dGVMb2FkZXIgJiYgcmVsb2FkICYmIG1hdGNoLnN0YXR1cyA9PT0gXCJzdWNjZXNzXCIgJiYgIXByZWxvYWQgJiYgIW9wdGlvbnNbNF0gJiYgKChpc0xvYWRlckZuID8gdm9pZCAwIDogcm91dGVMb2FkZXIuc3RhbGVSZWxvYWRNb2RlKSA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0U3RhbGVSZWxvYWRNb2RlKSAhPT0gXCJibG9ja2luZ1wiKTtcblx0Y29uc3QgbG9hZGVkID0gcmVsb2FkICYmIHByZWxvYWRhYmxlO1xuXHRjb25zdCBibG9ja2luZyA9IGxvYWRlZCAmJiAhYmFja2dyb3VuZCAmJiAobWF0Y2guc3RhdHVzICE9PSBcInN1Y2Nlc3NcIiB8fCAhIXJvdXRlTG9hZGVyKTtcblx0Y29uc3Qgb25SZWFkeSA9IGluZGV4ID49IHJldGFpbmVkRW5kID8gb3B0aW9uc1s3XSA6IHZvaWQgMDtcblx0Y29uc3Qgb25MYXp5UmVhZHkgPSByb3V0ZS5sYXp5Rm4gJiYgcm91dGUuX2xhenkgIT09IHRydWUgPyBvblJlYWR5IDogdm9pZCAwO1xuXHRpZiAobG9hZGVkICYmICFyb3V0ZUxvYWRlcikge1xuXHRcdG1hdGNoLmludmFsaWQgPSBmYWxzZTtcblx0XHRtYXRjaC51cGRhdGVkQXQgPSBEYXRlLm5vdygpO1xuXHR9XG5cdGlmIChkb25vcikgZG9ub3JbMl0rKztcblx0aWYgKGJsb2NraW5nKSB7XG5cdFx0Y29uc3QgYWNjZXB0ZWRGbGlnaHQgPSBtYXRjaC5fZmxpZ2h0O1xuXHRcdG1hdGNoLl9mbGlnaHQgPSBkb25vcjtcblx0XHRyZWxlYXNlT3duZWRGbGlnaHQocm91dGVyLCBtYXRjaCwgYWNjZXB0ZWRGbGlnaHQpPy5hYm9ydCgpO1xuXHRcdGlmIChpbmRleCA+PSByZXRhaW5lZEVuZCkgbWF0Y2guc3RhdHVzID0gXCJwZW5kaW5nXCI7XG5cdFx0b25SZWFkeT8uKCk7XG5cdH1cblx0aWYgKCFsb2FkZWQpIG1hdGNoLmlzRmV0Y2hpbmcgPSBmYWxzZTtcblx0Y29uc3Qgb3V0Y29tZSA9ICFyZWxvYWRGYWlsdXJlICYmIGJsb2NraW5nID8gbG9hZFJlc291cmNlKHJvdXRlciwgbGFuZSwgbWF0Y2gsIHJvdXRlLCBsb2FkZXIsIHNlbWFudGljUGFyZW50LCBvcHRpb25zKS50aGVuKChyZXN1bHQpID0+IHtcblx0XHRzZXR0bGVJbnRvKG1hdGNoLCByZXN1bHQsIHByZWxvYWQpO1xuXHRcdGlmIChyZXN1bHRbMF0gPT09IFNVQ0NFU1MpIHtcblx0XHRcdGlmIChyb3V0ZUxvYWRlciAmJiAhb3B0aW9uc1swXS5zaWduYWwuYWJvcnRlZCkgY2FjaGVMb2FkZXJNYXRjaChyb3V0ZXIsIG1hdGNoLCBwbGFubmVkQ2FjaGVNYXRjaCk7XG5cdFx0XHRpZiAoaW5kZXggPj0gcmV0YWluZWRFbmQpIG1hdGNoLnN0YXR1cyA9IFwicGVuZGluZ1wiO1xuXHRcdH1cblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9KSA6IFByb21pc2UucmVzb2x2ZShyZWxvYWRGYWlsdXJlID8/IFtTVUNDRVNTLCBtYXRjaC5sb2FkZXJEYXRhXSk7XG5cdGNvbnN0IGNodW5rRmFpbHVyZSA9IChhc3luYyAoKSA9PiB7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGNodW5rID0gbG9hZFJvdXRlQ2h1bmsocm91dGUsIHZvaWQgMCwgb25MYXp5UmVhZHkpO1xuXHRcdFx0aWYgKGNodW5rKSBhd2FpdCB3YWl0Rm9yKGNodW5rLCBvcHRpb25zWzBdLnNpZ25hbCk7XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdGlmICghbGFuZVsxXS5zb21lKChjYW5kaWRhdGUsIGNhbmRpZGF0ZUluZGV4KSA9PiBjYW5kaWRhdGVJbmRleCA8PSBpbmRleCAmJiAoY2FuZGlkYXRlLnN0YXR1cyA9PT0gXCJlcnJvclwiIHx8IGNhbmRpZGF0ZS5zdGF0dXMgPT09IFwibm90Rm91bmRcIiB8fCBjYW5kaWRhdGUuX25vdEZvdW5kKSkpIHJldHVybiBbaW5kZXgsIG5vcm1hbGl6ZUxhbmVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCBjYXVzZSwgb3B0aW9ucyldO1xuXHRcdH1cblx0XHRjb25zdCByZXN1bHQgPSBhd2FpdCBvdXRjb21lO1xuXHRcdGlmIChibG9ja2luZyAmJiByZXN1bHRbMF0gPT09IFNVQ0NFU1MgJiYgbWF0Y2guc3RhdHVzID09PSBcInBlbmRpbmdcIiAmJiAhb3B0aW9uc1swXS5zaWduYWwuYWJvcnRlZCkge1xuXHRcdFx0bWF0Y2guc3RhdHVzID0gXCJzdWNjZXNzXCI7XG5cdFx0XHRvblJlYWR5Py4oKTtcblx0XHR9XG5cdH0pKCk7XG5cdHRhc2tzLnB1c2goW1xuXHRcdGluZGV4LFxuXHRcdG91dGNvbWUsXG5cdFx0Y2h1bmtGYWlsdXJlXG5cdF0pO1xuXHRpZiAoIWJhY2tncm91bmQpIHJldHVybiBvdXRjb21lLnRoZW4oKHJlc3VsdCkgPT4gZ2V0UGFyZW50U25hcHNob3QobWF0Y2gsIHJlc3VsdCkpO1xuXHRjb25zdCBjYW5kaWRhdGUgPSB7XG5cdFx0Li4ubWF0Y2gsXG5cdFx0c3RhdHVzOiBcInBlbmRpbmdcIixcblx0XHRwcmVsb2FkOiBmYWxzZSxcblx0XHRfZmxpZ2h0OiBkb25vclxuXHR9O1xuXHRtYXRjaC5pbnZhbGlkID0gZmFsc2U7XG5cdG1hdGNoLmlzRmV0Y2hpbmcgPSBcImxvYWRlclwiO1xuXHRjb25zdCBiYWNrZ3JvdW5kT3V0Y29tZSA9IGxvYWRSZXNvdXJjZShyb3V0ZXIsIGxhbmUsIGNhbmRpZGF0ZSwgcm91dGUsIGxvYWRlciwgc2VtYW50aWNQYXJlbnQsIG9wdGlvbnMpLnRoZW4oKHJlc3VsdCkgPT4ge1xuXHRcdG1hdGNoLmlzRmV0Y2hpbmcgPSBmYWxzZTtcblx0XHRzZXR0bGVJbnRvKGNhbmRpZGF0ZSwgcmVzdWx0LCBmYWxzZSk7XG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fSk7XG5cdChsYW5lWzJdID8/PSBbXSkucHVzaChbXG5cdFx0aW5kZXgsXG5cdFx0YmFja2dyb3VuZE91dGNvbWUsXG5cdFx0Y2h1bmtGYWlsdXJlLFxuXHRcdGNhbmRpZGF0ZVxuXHRdKTtcblx0cmV0dXJuIGJhY2tncm91bmRPdXRjb21lLnRoZW4oKHJlc3VsdCkgPT4gZ2V0UGFyZW50U25hcHNob3QoY2FuZGlkYXRlLCByZXN1bHQpKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIGdldE5vdEZvdW5kQm91bmRhcnkocm91dGVyLCBtYXRjaGVzLCBpbmRleGVkLCBzaWduYWwsIGZhbGxiYWNrID0gMCkge1xuXHRjb25zdCBjYXVzZSA9IGluZGV4ZWQ/LlsxXVsxXTtcblx0bGV0IGluZGV4ID0gY2F1c2U/LnJvdXRlSWQgPyBtYXRjaGVzLmZpbmRJbmRleCgobWF0Y2gpID0+IG1hdGNoLnJvdXRlSWQgPT09IGNhdXNlLnJvdXRlSWQpIDogaW5kZXhlZD8uWzBdID8/IG1hdGNoZXMubGVuZ3RoIC0gMTtcblx0aWYgKGluZGV4IDwgMCkgaW5kZXggPSAwO1xuXHRmb3IgKGxldCBpID0gaW5kZXg7IGkgPj0gMDsgaS0tKSB7XG5cdFx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoZXNbaV0pO1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBsb2FkaW5nID0gbG9hZFJvdXRlQ2h1bmsocm91dGUsIGZhbHNlKTtcblx0XHRcdGlmIChsb2FkaW5nKSBhd2FpdCB3YWl0Rm9yKGxvYWRpbmcsIHNpZ25hbCk7XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdGlmIChjYXVzZSA9PT0gc2lnbmFsICYmIHNpZ25hbC5hYm9ydGVkKSB0aHJvdyBjYXVzZTtcblx0XHR9XG5cdFx0aWYgKHJvdXRlLm9wdGlvbnMubm90Rm91bmRDb21wb25lbnQpIHJldHVybiBpO1xuXHR9XG5cdHJldHVybiBjYXVzZT8ucm91dGVJZCA/IGluZGV4IDogZmFsbGJhY2s7XG59XG5mdW5jdGlvbiBkaXNjYXJkQmFja2dyb3VuZChyb3V0ZXIsIGxhbmUpIHtcblx0aWYgKGxhbmVbMl0pIHtcblx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgbGFuZVsyXS5tYXAoKHRhc2spID0+IHRhc2tbM10pKTtcblx0XHRsYW5lWzJdID0gdm9pZCAwO1xuXHR9XG59XG5hc3luYyBmdW5jdGlvbiBzZXR0bGVUYXNrcyh0YXNrcywgc2VyaWFsRmFpbHVyZSwgcmVkaXJlY3RUYXNrcywgZ2F0ZSkge1xuXHRsZXQgbG9hZGVyRmFpbHVyZTtcblx0dHJ5IHtcblx0XHRhd2FpdCBQcm9taXNlLmFsbCh0YXNrcy5tYXAoKHRhc2spID0+IHRhc2tbMV0udGhlbihhc3luYyAob3V0Y29tZSkgPT4ge1xuXHRcdFx0Y29uc3QgdGFza0luZGV4ID0gdGFza1swXTtcblx0XHRcdGlmIChnYXRlICYmIHRhc2tJbmRleCA+PSBhd2FpdCBnYXRlKSByZXR1cm47XG5cdFx0XHRpZiAob3V0Y29tZVswXSA+PSBSRURJUkVDVEVEKSB0aHJvdyBbdGFza0luZGV4LCBvdXRjb21lXTtcblx0XHRcdGlmICghbG9hZGVyRmFpbHVyZSAmJiBvdXRjb21lWzBdICE9PSBTVUNDRVNTKSB7XG5cdFx0XHRcdGxvYWRlckZhaWx1cmUgPSBbdGFza0luZGV4LCBvdXRjb21lXTtcblx0XHRcdFx0YXdhaXQgUHJvbWlzZS5hbGwoKHJlZGlyZWN0VGFza3MgPz8gW10pLm1hcCgobmV4dFRhc2spID0+IHtcblx0XHRcdFx0XHRpZiAobmV4dFRhc2tbMF0gPD0gdGFza0luZGV4KSByZXR1cm47XG5cdFx0XHRcdFx0cmV0dXJuIG5leHRUYXNrWzFdLnRoZW4oKG5leHRPdXRjb21lKSA9PiB7XG5cdFx0XHRcdFx0XHRpZiAobmV4dE91dGNvbWVbMF0gPT09IFJFRElSRUNURUQpIHRocm93IFtuZXh0VGFza1swXSwgbmV4dE91dGNvbWVdO1xuXHRcdFx0XHRcdH0pO1xuXHRcdFx0XHR9KSk7XG5cdFx0XHR9XG5cdFx0fSkpKTtcblx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRyZXR1cm4gY2F1c2U7XG5cdH1cblx0cmV0dXJuIHNlcmlhbEZhaWx1cmUgPz8gbG9hZGVyRmFpbHVyZTtcbn1cbmZ1bmN0aW9uIG1hdGVyaWFsaXplUmVkaXJlY3Qocm91dGVyLCBsYW5lLCByb3V0ZSwgb3V0Y29tZSwgb3B0aW9ucywgZmFpbGVkKSB7XG5cdHdoaWxlIChvdXRjb21lWzBdID09PSBSRURJUkVDVEVEKSB7XG5cdFx0Y29uc3QgcmVkaXJlY3QgPSBvdXRjb21lWzFdO1xuXHRcdGNvbnN0IHJlZGlyZWN0T3B0aW9ucyA9IHJlZGlyZWN0Lm9wdGlvbnM7XG5cdFx0dHJ5IHtcblx0XHRcdGlmIChyZWRpcmVjdE9wdGlvbnMuaHJlZiB8fCByZWRpcmVjdC5oZWFkZXJzLmhhcyhcIkxvY2F0aW9uXCIpKSB7XG5cdFx0XHRcdHJvdXRlci5yZXNvbHZlUmVkaXJlY3QocmVkaXJlY3QpO1xuXHRcdFx0XHRpZiAocmVkaXJlY3RPcHRpb25zLnJlbG9hZERvY3VtZW50KSByZXR1cm4gb3V0Y29tZTtcblx0XHRcdH1cblx0XHRcdGlmIChyZWRpcmVjdE9wdGlvbnMucmVsb2FkRG9jdW1lbnQgPyBvcHRpb25zWzNdIDogb3B0aW9uc1sxXSA+PSAyMCkgcmV0dXJuIG91dGNvbWU7XG5cdFx0XHRjb25zdCBsb2NhdGlvbiA9IHJvdXRlci5idWlsZExvY2F0aW9uKHtcblx0XHRcdFx0Li4ucmVkaXJlY3RPcHRpb25zLFxuXHRcdFx0XHRfZnJvbUxvY2F0aW9uOiBsYW5lWzBdLFxuXHRcdFx0XHRfaW5jbHVkZVZhbGlkYXRlU2VhcmNoOiB0cnVlXG5cdFx0XHR9KTtcblx0XHRcdGNvbnN0IHB1YmxpY0xvY2F0aW9uID0gbG9jYXRpb24ubWFza2VkTG9jYXRpb24gPz8gbG9jYXRpb247XG5cdFx0XHRpZiAocHVibGljTG9jYXRpb24uZXh0ZXJuYWwpIHtcblx0XHRcdFx0Y29uc3QgcmVzb2x2ZWQgPSByZWRpcmVjdC5jbG9uZSgpO1xuXHRcdFx0XHRyZXNvbHZlZC5vcHRpb25zID0geyAuLi5yZWRpcmVjdE9wdGlvbnMgfTtcblx0XHRcdFx0cmVzb2x2ZWQuaGVhZGVycy5zZXQoXCJMb2NhdGlvblwiLCBwdWJsaWNMb2NhdGlvbi5wdWJsaWNIcmVmKTtcblx0XHRcdFx0cm91dGVyLnJlc29sdmVSZWRpcmVjdChyZXNvbHZlZCk7XG5cdFx0XHRcdHJldHVybiBvcHRpb25zWzNdID8gW1JFRElSRUNURUQsIHJlc29sdmVkXSA6IFtcblx0XHRcdFx0XHRSRURJUkVDVEVELFxuXHRcdFx0XHRcdHJlc29sdmVkLFxuXHRcdFx0XHRcdHB1YmxpY0xvY2F0aW9uXG5cdFx0XHRcdF07XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gW1xuXHRcdFx0XHRSRURJUkVDVEVELFxuXHRcdFx0XHRyZWRpcmVjdCxcblx0XHRcdFx0bG9jYXRpb25cblx0XHRcdF07XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdG91dGNvbWUgPSBmYWlsZWQgPyBbRVJST1IsIGNhdXNlXSA6IG5vcm1hbGl6ZUVycm9yKHJvdXRlLCBjYXVzZSk7XG5cdFx0XHRmYWlsZWQgPSB0cnVlO1xuXHRcdH1cblx0fVxuXHRyZXR1cm4gb3V0Y29tZTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHJlZHVjZUxhbmUocm91dGVyLCBsYW5lLCB0YXNrcywgY29udHJvbGxlciwgc2V0dGxlbWVudCwgb25SZWFkeSkge1xuXHRjb25zdCBtYXRjaGVzID0gbGFuZVsxXTtcblx0bGV0IGZhaWx1cmUgPSBhd2FpdCBzZXR0bGVtZW50O1xuXHRsZXQgcmVkaXJlY3RMaW1pdEV4Y2VlZGVkID0gZmFsc2U7XG5cdGNvbnN0IHBsYW5uZWRCb3VuZGFyeSA9IG1hdGNoZXMuZmluZEluZGV4KChtYXRjaCkgPT4gbWF0Y2guX25vdEZvdW5kKTtcblx0Y29uc3QgYm91bmRhcnlPZiA9IChmb3VuZCkgPT4gZm91bmRbMV1bMF0gPT09IE5PVF9GT1VORCA/IGdldE5vdEZvdW5kQm91bmRhcnkocm91dGVyLCBtYXRjaGVzLCBmb3VuZCwgY29udHJvbGxlci5zaWduYWwpIDogZm91bmRbMF07XG5cdGxldCByZWFkaW5lc3NFbmQgPSBwbGFubmVkQm91bmRhcnkgPCAwID8gbWF0Y2hlcy5sZW5ndGggOiBwbGFubmVkQm91bmRhcnk7XG5cdGlmICgoZmFpbHVyZT8uWzFdWzBdID8/IDApID49IFJFRElSRUNURUQpIHJlYWRpbmVzc0VuZCA9IDA7XG5cdGVsc2UgaWYgKGZhaWx1cmUpIHtcblx0XHRyZWFkaW5lc3NFbmQgPSBmYWlsdXJlWzJdID8/PSBhd2FpdCBib3VuZGFyeU9mKGZhaWx1cmUpO1xuXHRcdGZvciAoY29uc3QgdGFzayBvZiB0YXNrcykge1xuXHRcdFx0aWYgKHRhc2tbMF0gPj0gcmVhZGluZXNzRW5kKSBicmVhaztcblx0XHRcdGNvbnN0IG91dGNvbWUgPSBhd2FpdCB0YXNrWzFdO1xuXHRcdFx0aWYgKG91dGNvbWVbMF0gIT09IFNVQ0NFU1MgJiYgb3V0Y29tZVswXSA8IFJFRElSRUNURUQgJiYgIShcImxvYWRlckRhdGFcIiBpbiBtYXRjaGVzW3Rhc2tbMF1dKSkge1xuXHRcdFx0XHRmYWlsdXJlID0gW3Rhc2tbMF0sIG91dGNvbWVdO1xuXHRcdFx0XHRyZWFkaW5lc3NFbmQgPSBmYWlsdXJlWzJdID0gYXdhaXQgYm91bmRhcnlPZihmYWlsdXJlKTtcblx0XHRcdFx0YnJlYWs7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cdGZvciAoY29uc3QgdGFzayBvZiB0YXNrcykge1xuXHRcdGlmICh0YXNrWzBdID49IHJlYWRpbmVzc0VuZCkgYnJlYWs7XG5cdFx0Y29uc3QgY2h1bmtGYWlsdXJlID0gYXdhaXQgdGFza1syXTtcblx0XHRpZiAoIWNodW5rRmFpbHVyZSkgY29udGludWU7XG5cdFx0ZmFpbHVyZSA9IGNodW5rRmFpbHVyZTtcblx0XHRicmVhaztcblx0fVxuXHRpZiAoKGZhaWx1cmU/LlsxXVswXSA/PyAwKSA+PSBSRURJUkVDVEVEKSB7XG5cdFx0Y29uc3Qgb3V0Y29tZSA9IGZhaWx1cmVbMV07XG5cdFx0aWYgKG91dGNvbWVbMF0gIT09IFJFRElSRUNURUQgfHwgb3V0Y29tZVsxXS5vcHRpb25zLnJlbG9hZERvY3VtZW50IHx8IG91dGNvbWVbMl0pIHtcblx0XHRcdGRpc2NhcmRCYWNrZ3JvdW5kKHJvdXRlciwgbGFuZSk7XG5cdFx0XHRyZXR1cm4gb3V0Y29tZTtcblx0XHR9XG5cdFx0cmVkaXJlY3RMaW1pdEV4Y2VlZGVkID0gdHJ1ZTtcblx0XHRmYWlsdXJlID0gWzAsIFtFUlJPUiwgLyogQF9fUFVSRV9fICovIG5ldyBFcnJvcihcIlRvbyBtYW55IHJlZGlyZWN0c1wiKV1dO1xuXHR9XG5cdGNvbnN0IGJvdW5kYXJ5ID0gZmFpbHVyZSA/IGZhaWx1cmVbMl0gPz8gYXdhaXQgYm91bmRhcnlPZihmYWlsdXJlKSA6IHBsYW5uZWRCb3VuZGFyeTtcblx0aWYgKGJvdW5kYXJ5ID49IDApIHtcblx0XHRjb25zdCBvdXRjb21lID0gZmFpbHVyZT8uWzFdO1xuXHRcdGNvbnN0IGtpbmQgPSBvdXRjb21lPy5bMF07XG5cdFx0Y29uc3QgbWF0Y2ggPSBtYXRjaGVzW2JvdW5kYXJ5XTtcblx0XHRjb25zdCBjYXVzZSA9IG91dGNvbWU/LlsxXTtcblx0XHRjb25zdCBpbnN0YWxsID0gKCkgPT4ge1xuXHRcdFx0aWYgKG91dGNvbWUpIHtcblx0XHRcdFx0bWF0Y2guX25vdEZvdW5kID0gdm9pZCAwO1xuXHRcdFx0XHRpZiAoa2luZCA9PT0gRVJST1IpIG1hdGNoLnN0YXR1cyA9IFwiZXJyb3JcIjtcblx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0Y2F1c2Uucm91dGVJZCA9IG1hdGNoLnJvdXRlSWQ7XG5cdFx0XHRcdFx0aWYgKG1hdGNoLnJvdXRlSWQgPT09IHJvdXRlci5yb3V0ZVRyZWUuaWQpIHtcblx0XHRcdFx0XHRcdG1hdGNoLnN0YXR1cyA9IFwic3VjY2Vzc1wiO1xuXHRcdFx0XHRcdFx0bWF0Y2guX25vdEZvdW5kID0gdHJ1ZTtcblx0XHRcdFx0XHR9IGVsc2UgbWF0Y2guc3RhdHVzID0gXCJub3RGb3VuZFwiO1xuXHRcdFx0XHR9XG5cdFx0XHRcdG1hdGNoLmVycm9yID0gY2F1c2U7XG5cdFx0XHRcdG1hdGNoLmlzRmV0Y2hpbmcgPSBmYWxzZTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdGluc3RhbGwoKTtcblx0XHRpZiAoIW91dGNvbWUpIG9uUmVhZHk/LigpO1xuXHRcdGNvbnN0IHJvdXRlID0gZ2V0Um91dGUocm91dGVyLCBtYXRjaCk7XG5cdFx0dHJ5IHtcblx0XHRcdGF3YWl0IHdhaXRGb3Iob3V0Y29tZSA/IFByb21pc2UucmVzb2x2ZSgpLnRoZW4oKCkgPT4gbG9hZFJvdXRlQ2h1bmsocm91dGUsIGtpbmQgPT09IEVSUk9SID8gXCJlcnJvckNvbXBvbmVudFwiIDogXCJub3RGb3VuZENvbXBvbmVudFwiKSkgOiBQcm9taXNlLmFsbChbbG9hZFJvdXRlQ2h1bmsocm91dGUpLCBsb2FkUm91dGVDaHVuayhyb3V0ZSwgXCJub3RGb3VuZENvbXBvbmVudFwiKV0pLCBjb250cm9sbGVyLnNpZ25hbCk7XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdGlmIChjYXVzZSA9PT0gY29udHJvbGxlci5zaWduYWwgJiYgY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkge1xuXHRcdFx0XHRkaXNjYXJkQmFja2dyb3VuZChyb3V0ZXIsIGxhbmUpO1xuXHRcdFx0XHRyZXR1cm4gQ0FOQ0VMRURfT1VUQ09NRTtcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYgKCFvdXRjb21lKSBtYXRjaC5zdGF0dXMgPSBcInN1Y2Nlc3NcIjtcblx0XHRlbHNlIGlmIChyZWRpcmVjdExpbWl0RXhjZWVkZWQpIHtcblx0XHRcdGNvbnRyb2xsZXIuYWJvcnQoKTtcblx0XHRcdGF3YWl0IFByb21pc2UuYWxsKFtcblx0XHRcdFx0Li4udGFza3MubWFwKCh0YXNrKSA9PiB0YXNrWzFdKSxcblx0XHRcdFx0Li4udGFza3MubWFwKCh0YXNrKSA9PiB0YXNrWzJdKSxcblx0XHRcdFx0Li4uKGxhbmVbMl0gPz8gW10pLm1hcCgodGFzaykgPT4gdGFza1sxXSlcblx0XHRcdF0pO1xuXHRcdFx0ZGlzY2FyZEJhY2tncm91bmQocm91dGVyLCBsYW5lKTtcblx0XHRcdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBtYXRjaGVzKTtcblx0XHRcdGluc3RhbGwoKTtcblx0XHR9XG5cdH1cblx0cmV0dXJuIGxhbmU7XG59XG5hc3luYyBmdW5jdGlvbiBwcm9qZWN0TGFuZShyb3V0ZXIsIGxhbmUsIHNpZ25hbCwgc3RhcnQgPSAwLCBlbmQgPSBsYW5lWzFdLmxlbmd0aCkge1xuXHRjb25zdCBtYXRjaGVzID0gbGFuZVsxXTtcblx0Zm9yIChsZXQgaW5kZXggPSBzdGFydDsgaW5kZXggPCBlbmQ7IGluZGV4KyspIHtcblx0XHRjb25zdCBtYXRjaCA9IG1hdGNoZXNbaW5kZXhdO1xuXHRcdGNvbnN0IHJvdXRlT3B0aW9ucyA9IGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpLm9wdGlvbnM7XG5cdFx0aWYgKHJvdXRlT3B0aW9ucy5oZWFkIHx8IHJvdXRlT3B0aW9ucy5zY3JpcHRzKSB0cnkge1xuXHRcdFx0Y29uc3QgY29udGV4dCA9IHtcblx0XHRcdFx0c3NyOiByb3V0ZXIub3B0aW9ucy5zc3IsXG5cdFx0XHRcdG1hdGNoZXMsXG5cdFx0XHRcdG1hdGNoLFxuXHRcdFx0XHRwYXJhbXM6IG1hdGNoLnBhcmFtcyxcblx0XHRcdFx0bG9hZGVyRGF0YTogbWF0Y2gubG9hZGVyRGF0YVxuXHRcdFx0fTtcblx0XHRcdGNvbnN0IFtoZWFkLCBzY3JpcHRzXSA9IGF3YWl0IHdhaXRGb3IoUHJvbWlzZS5hbGwoW3JvdXRlT3B0aW9ucy5oZWFkPy4oY29udGV4dCksIHJvdXRlT3B0aW9ucy5zY3JpcHRzPy4oY29udGV4dCldKSwgc2lnbmFsKTtcblx0XHRcdG1hdGNoLm1ldGEgPSBoZWFkPy5tZXRhO1xuXHRcdFx0bWF0Y2gubGlua3MgPSBoZWFkPy5saW5rcztcblx0XHRcdG1hdGNoLmhlYWRTY3JpcHRzID0gaGVhZD8uc2NyaXB0cztcblx0XHRcdG1hdGNoLnN0eWxlcyA9IGhlYWQ/LnN0eWxlcztcblx0XHRcdG1hdGNoLnNjcmlwdHMgPSBzY3JpcHRzO1xuXHRcdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0XHRpZiAoY2F1c2UgPT09IHNpZ25hbCAmJiBzaWduYWwuYWJvcnRlZCkgYnJlYWs7XG5cdFx0XHRjb25zb2xlLmVycm9yKGNhdXNlKTtcblx0XHR9XG5cdFx0aWYgKG1hdGNoLnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIgfHwgbWF0Y2guX25vdEZvdW5kKSBicmVhaztcblx0fVxuXHRyZXR1cm4gbGFuZTtcbn1cbmFzeW5jIGZ1bmN0aW9uIGV4ZWN1dGVDbGllbnRMYW5lKHJvdXRlciwgbG9jYXRpb24sIG1hdGNoZXMsIG9wdGlvbnMpIHtcblx0Y29uc3QgbWF0Y2hlZCA9IFtsb2NhdGlvbiwgbWF0Y2hlc107XG5cdGNvbnN0IHNpZ25hbCA9IG9wdGlvbnNbMF0uc2lnbmFsO1xuXHRsZXQgcmVkdWNlZDtcblx0dHJ5IHtcblx0XHRjb25zdCBwcmVzZW50ZWQgPSByb3V0ZXIuc3RvcmVzLm1hdGNoZXMuZ2V0KCk7XG5cdFx0bGV0IHBsYW5uZWRCb3VuZGFyeSA9IG1hdGNoZXMuZmluZEluZGV4KChtYXRjaCkgPT4gbWF0Y2guX25vdEZvdW5kKTtcblx0XHRpZiAocm91dGVyLm9wdGlvbnMubm90Rm91bmRNb2RlICE9PSBcInJvb3RcIiAmJiBwbGFubmVkQm91bmRhcnkgPj0gMCkge1xuXHRcdFx0Y29uc3QgYm91bmRhcnkgPSBhd2FpdCBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbWF0Y2hlcywgdm9pZCAwLCBzaWduYWwsIHBsYW5uZWRCb3VuZGFyeSk7XG5cdFx0XHRtYXRjaGVzW3BsYW5uZWRCb3VuZGFyeV0uX25vdEZvdW5kID0gdm9pZCAwO1xuXHRcdFx0bWF0Y2hlc1tib3VuZGFyeV0uX25vdEZvdW5kID0gdHJ1ZTtcblx0XHRcdHBsYW5uZWRCb3VuZGFyeSA9IGJvdW5kYXJ5O1xuXHRcdH1cblx0XHRsZXQgZW5kID0gcGxhbm5lZEJvdW5kYXJ5IDwgMCA/IG1hdGNoZXMubGVuZ3RoIDogcGxhbm5lZEJvdW5kYXJ5ICsgMTtcblx0XHRsZXQgcmV0YWluZWRFbmQgPSAwO1xuXHRcdHdoaWxlIChyZXRhaW5lZEVuZCA8IGVuZCAmJiByZXRhaW5lZEVuZCAhPT0gcGxhbm5lZEJvdW5kYXJ5KSB7XG5cdFx0XHRjb25zdCBtYXRjaCA9IG1hdGNoZXNbcmV0YWluZWRFbmRdO1xuXHRcdFx0Y29uc3QgY29tbWl0dGVkID0gb3B0aW9uc1syXVtyZXRhaW5lZEVuZF07XG5cdFx0XHRjb25zdCB2aXNpYmxlID0gcHJlc2VudGVkW3JldGFpbmVkRW5kXTtcblx0XHRcdGlmIChjb21taXR0ZWQ/LmlkICE9PSBtYXRjaC5pZCB8fCBjb21taXR0ZWQuc3RhdHVzICE9PSBcInN1Y2Nlc3NcIiB8fCBtYXRjaC5wcmVsb2FkIHx8IHZpc2libGU/LmlkICE9PSBtYXRjaC5pZCB8fCB2aXNpYmxlLnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIpIGJyZWFrO1xuXHRcdFx0cmV0YWluZWRFbmQrKztcblx0XHRcdGlmIChjb21taXR0ZWQuX25vdEZvdW5kIHx8IHZpc2libGUuX25vdEZvdW5kKSBicmVhaztcblx0XHR9XG5cdFx0Y29uc3QgdGFza3MgPSBbXTtcblx0XHRjb25zdCBzdGFydCA9IG9wdGlvbnNbNl0gPz8gMDtcblx0XHRsZXQgc2VtYW50aWNQYXJlbnQgPSBzdGFydCA/IFByb21pc2UucmVzb2x2ZShtYXRjaGVzW3N0YXJ0IC0gMV0pIDogdm9pZCAwO1xuXHRcdGNvbnN0IHBsYW5TdWNjZXNzZnVsTGFuZSA9ICgpID0+IHtcblx0XHRcdGZvciAobGV0IGluZGV4ID0gc3RhcnQ7IGluZGV4IDwgZW5kOyBpbmRleCsrKSB7XG5cdFx0XHRcdGlmIChzaWduYWwuYWJvcnRlZCkgYnJlYWs7XG5cdFx0XHRcdHNlbWFudGljUGFyZW50ID0gY3JlYXRlTG9hZGVyVGFzayhyb3V0ZXIsIG1hdGNoZWQsIGluZGV4LCB0YXNrcywgc2VtYW50aWNQYXJlbnQsIG9wdGlvbnMsIHJldGFpbmVkRW5kKTtcblx0XHRcdH1cblx0XHR9O1xuXHRcdGNvbnN0IGZhaWx1cmUgPSBhd2FpdCBjb250ZXh0dWFsaXplKHJvdXRlciwgbWF0Y2hlZCwgb3B0aW9ucywgZW5kLCBwbGFuU3VjY2Vzc2Z1bExhbmUsIHJldGFpbmVkRW5kKTtcblx0XHRpZiAoZmFpbHVyZSkge1xuXHRcdFx0b3B0aW9uc1s0XSA9IHRydWU7XG5cdFx0XHRlbmQgPSBmYWlsdXJlWzBdO1xuXHRcdFx0aWYgKGZhaWx1cmVbMV1bMF0gPT09IE5PVF9GT1VORCkge1xuXHRcdFx0XHRjb25zdCBib3VuZGFyeSA9IGF3YWl0IGdldE5vdEZvdW5kQm91bmRhcnkocm91dGVyLCBtYXRjaGVzLCBmYWlsdXJlLCBzaWduYWwpO1xuXHRcdFx0XHRmYWlsdXJlWzJdID0gYm91bmRhcnk7XG5cdFx0XHRcdGVuZCA9IE1hdGgubWluKGVuZCwgYm91bmRhcnkgKyAxKTtcblx0XHRcdH0gZWxzZSBpZiAoZmFpbHVyZVsxXVswXSA+PSBSRURJUkVDVEVEKSBlbmQgPSAwO1xuXHRcdFx0cGxhblN1Y2Nlc3NmdWxMYW5lKCk7XG5cdFx0fVxuXHRcdGlmICghc2lnbmFsLmFib3J0ZWQgJiYgIW9wdGlvbnNbM10pIHtcblx0XHRcdGNvbnN0IGFib3J0ID0gW107XG5cdFx0XHRmb3IgKGNvbnN0IFtpZCwgZmxpZ2h0XSBvZiByb3V0ZXIuX2ZsaWdodHMgPz8gW10pIGlmICghZmxpZ2h0WzJdKSB7XG5cdFx0XHRcdHJvdXRlci5fZmxpZ2h0cy5kZWxldGUoaWQpO1xuXHRcdFx0XHRhYm9ydC5wdXNoKGZsaWdodFsxXSk7XG5cdFx0XHR9XG5cdFx0XHRmb3IgKGNvbnN0IGNvbnRyb2xsZXIgb2YgYWJvcnQpIGNvbnRyb2xsZXIuYWJvcnQoKTtcblx0XHR9XG5cdFx0Y29uc3QgcmVkdWN0aW9uID0gcmVkdWNlTGFuZShyb3V0ZXIsIG1hdGNoZWQsIHRhc2tzLCBvcHRpb25zWzBdLCBzZXR0bGVUYXNrcyh0YXNrcywgZmFpbHVyZSwgbWF0Y2hlZFsyXSksIG9wdGlvbnNbN10pO1xuXHRcdGlmIChtYXRjaGVkWzJdPy5sZW5ndGgpIG1hdGNoZWRbM10gPSBzZXR0bGVUYXNrcyhtYXRjaGVkWzJdLCB2b2lkIDAsIHZvaWQgMCwgcmVkdWN0aW9uLnRoZW4oKGZvcmVncm91bmQpID0+IGlzQ29udHJvbChmb3JlZ3JvdW5kKSA/IDAgOiBfZ2V0UmVuZGVyZWRNYXRjaGVzKG1hdGNoZXMpLmxlbmd0aCwgKCkgPT4gMCkpO1xuXHRcdHJlZHVjZWQgPSBhd2FpdCByZWR1Y3Rpb247XG5cdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0ZGlzY2FyZEJhY2tncm91bmQocm91dGVyLCBtYXRjaGVkKTtcblx0XHRpZiAoY2F1c2UgPT09IHNpZ25hbCAmJiBzaWduYWwuYWJvcnRlZCkgcmV0dXJuIENBTkNFTEVEX09VVENPTUU7XG5cdFx0dGhyb3cgY2F1c2U7XG5cdH1cblx0aWYgKGlzQ29udHJvbChyZWR1Y2VkKSkgcmV0dXJuIHJlZHVjZWQ7XG5cdHJldHVybiBwcm9qZWN0TGFuZShyb3V0ZXIsIHJlZHVjZWQsIHNpZ25hbCwgb3B0aW9uc1s2XSA9PT0gbWF0Y2hlcy5sZW5ndGggPyBvcHRpb25zWzZdIDogMCk7XG59XG4vKipcbiogV2FpdHMgZm9yIGBwZW5kaW5nTXNgLCB0aGVuIHByZXNlbnRzIHRoZSBjb21wbGV0ZSBsYW5lLiBSZW5kZXJpbmcgYXBwbGllcyB0aGVcbiogc2VsZWN0ZWQgYm91bmRhcnkgY3V0b2ZmIHdoaWxlIHJldGFpbmluZyBldmVyeSBtYXRjaCdzIHN0cnVjdHVyYWwgc3RhdGUuXG4qIEEgcmVwbGFjZW1lbnQgbG9hZCBmb3IgdGhlIHNhbWUgbWF0Y2gga2VlcHMgdGhlIHRpbWVyOyBjaG9vc2luZyBhIGRpZmZlcmVudFxuKiBtYXRjaCByZXNldHMgaXQuIGBwZW5kaW5nTWluTXNgIHN0YXJ0cyBhZnRlciB0aGUgZmFsbGJhY2sgcmVuZGVycy5cbiovXG5mdW5jdGlvbiBvZmZlclBlbmRpbmcocm91dGVyLCB0eCkge1xuXHRpZiAocm91dGVyLl90eCAhPT0gdHgpIHJldHVybjtcblx0Y29uc3QgbWF0Y2hlcyA9IHR4WzNdO1xuXHRjb25zdCBwcmVzZW50ZWQgPSByb3V0ZXIuc3RvcmVzLm1hdGNoZXMuZ2V0KCk7XG5cdGxldCBzZXNzaW9uID0gcm91dGVyLl9wZW5kaW5nO1xuXHRmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgbWF0Y2hlcy5sZW5ndGg7IGluZGV4KyspIHtcblx0XHRjb25zdCBtYXRjaCA9IG1hdGNoZXNbaW5kZXhdO1xuXHRcdGNvbnN0IHN1Y2Nlc3MgPSBtYXRjaC5zdGF0dXMgPT09IFwic3VjY2Vzc1wiICYmICFtYXRjaC5fbm90Rm91bmQ7XG5cdFx0Y29uc3QgcHJlc2VudGVkUGVuZGluZyA9IHByZXNlbnRlZFtpbmRleF0/LmlkID09PSBtYXRjaC5pZCAmJiBwcmVzZW50ZWRbaW5kZXhdPy5zdGF0dXMgPT09IFwicGVuZGluZ1wiO1xuXHRcdGlmIChzdWNjZXNzICYmICFwcmVzZW50ZWRQZW5kaW5nKSBjb250aW51ZTtcblx0XHRjb25zdCByb3V0ZSA9IGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpO1xuXHRcdGNvbnN0IGRlbGF5ID0gc3VjY2VzcyB8fCBtYXRjaC5pbnZhbGlkID8gMCA6IHJvdXRlLm9wdGlvbnMucGVuZGluZ01zID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRQZW5kaW5nTXM7XG5cdFx0Y29uc3QgY29tcG9uZW50ID0gcm91dGUub3B0aW9ucy5wZW5kaW5nQ29tcG9uZW50ID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRQZW5kaW5nQ29tcG9uZW50O1xuXHRcdGlmICghY29tcG9uZW50IHx8IHR5cGVvZiBkZWxheSAhPT0gXCJudW1iZXJcIiB8fCBkZWxheSA9PT0gSW5maW5pdHkpIHtcblx0XHRcdGlmIChzZXNzaW9uKSB7XG5cdFx0XHRcdHNlc3Npb25bMF0gPSB0eDtcblx0XHRcdFx0c2Vzc2lvblsyXSA9IDA7XG5cdFx0XHRcdHNlc3Npb25bNF0gPSB0cnVlO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRjb25zdCBtaW4gPSByb3V0ZS5vcHRpb25zLnBlbmRpbmdNaW5NcyA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0UGVuZGluZ01pbk1zID8/IDA7XG5cdFx0bGV0IHRvb2tPdmVyID0gZmFsc2U7XG5cdFx0aWYgKHNlc3Npb24/LlsxXSA9PT0gbWF0Y2guaWQpIHtcblx0XHRcdHRvb2tPdmVyID0gc2Vzc2lvblswXSAhPT0gdHg7XG5cdFx0XHRzZXNzaW9uWzBdID0gdHg7XG5cdFx0fSBlbHNlIHtcblx0XHRcdGNsZWFyVGltZW91dChzZXNzaW9uPy5bM10pO1xuXHRcdFx0cm91dGVyLl9wZW5kaW5nID0gc2Vzc2lvbiA9IHZvaWQgMDtcblx0XHR9XG5cdFx0aWYgKCFzZXNzaW9uKSByb3V0ZXIuX3BlbmRpbmcgPSBzZXNzaW9uID0gW1xuXHRcdFx0dHgsXG5cdFx0XHRtYXRjaC5pZCxcblx0XHRcdHByZXNlbnRlZFBlbmRpbmcgPyBEYXRlLm5vdygpICsgbWluIDogdHhbNF0gKyBkZWxheSxcblx0XHRcdHZvaWQgMCxcblx0XHRcdHByZXNlbnRlZFBlbmRpbmcgfHwgdm9pZCAwLFxuXHRcdFx0Y29tcG9uZW50XG5cdFx0XTtcblx0XHRpZiAoc2Vzc2lvbls0XSAmJiAhdG9va092ZXIgJiYgc2Vzc2lvbls1XSA9PT0gY29tcG9uZW50KSByZXR1cm47XG5cdFx0c2Vzc2lvbls1XSA9IGNvbXBvbmVudDtcblx0XHRpZiAoIXNlc3Npb25bNF0pIHtcblx0XHRcdGNsZWFyVGltZW91dChzZXNzaW9uWzNdKTtcblx0XHRcdGNvbnN0IHJlbWFpbmluZyA9IHNlc3Npb25bMl0gLSBEYXRlLm5vdygpO1xuXHRcdFx0aWYgKHJlbWFpbmluZyA+IDApIHtcblx0XHRcdFx0c2Vzc2lvblszXSA9IHNldFRpbWVvdXQoKCkgPT4gb2ZmZXJQZW5kaW5nKHJvdXRlciwgdHgpLCByZW1haW5pbmcpO1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cdFx0XHRzZXNzaW9uWzJdID0gMDtcblx0XHR9XG5cdFx0Y29uc3Qgb2ZmZXJlZCA9IG1hdGNoZXMubWFwKChtYXRjaCkgPT4gKHtcblx0XHRcdC4uLm1hdGNoLFxuXHRcdFx0X2ZsaWdodDogdm9pZCAwXG5cdFx0fSkpO1xuXHRcdG9mZmVyZWRbaW5kZXhdLnN0YXR1cyA9IFwicGVuZGluZ1wiO1xuXHRcdGNvbnN0IGFjayA9IHNlc3Npb25bNF0gPSByb3V0ZXIuc3RhcnRUcmFuc2l0aW9uKCgpID0+IHJvdXRlci5zdG9yZXMuc2V0TWF0Y2hlcyhvZmZlcmVkKSwgb2ZmZXJlZCkudGhlbigocmVuZGVyZWQpID0+IHtcblx0XHRcdGlmIChyZW5kZXJlZCAmJiByb3V0ZXIuX3BlbmRpbmcgPT09IHNlc3Npb24gJiYgc2Vzc2lvbls0XSA9PT0gYWNrICYmICFzZXNzaW9uWzJdKSBzZXNzaW9uWzJdID0gRGF0ZS5ub3coKSArIG1pbjtcblx0XHRcdHJldHVybiByZW5kZXJlZDtcblx0XHR9KTtcblx0XHRyZXR1cm47XG5cdH1cbn1cbi8qKlxuKiBDYW5jZWxzIHBlbmRpbmcgVUkgdGltaW5nIHVubGVzcyB0aGUgY3VycmVudCBzdWNjZXNzb3IgY2FuIHRha2Ugb3ZlciB0aGVcbiogc2FtZSBib3VuZGFyeSB0aGF0IHJlbWFpbnMgcGFpbnRlZC5cbiovXG5mdW5jdGlvbiBmaW5pc2hQZW5kaW5nKHJvdXRlciwgdHgpIHtcblx0Y29uc3Qgc2Vzc2lvbiA9IHJvdXRlci5fcGVuZGluZztcblx0aWYgKHJvdXRlci5fdHggPT09IHR4IHx8ICFyb3V0ZXIuX3R4Py5bM10uc29tZSgobWF0Y2gpID0+IG1hdGNoLmlkID09PSBzZXNzaW9uPy5bMV0pKSB7XG5cdFx0Y2xlYXJUaW1lb3V0KHNlc3Npb24/LlszXSk7XG5cdFx0cm91dGVyLl9wZW5kaW5nID0gdm9pZCAwO1xuXHR9XG59XG5hc3luYyBmdW5jdGlvbiBhd2FpdFBlbmRpbmdNaW5pbXVtKHJvdXRlciwgdHgpIHtcblx0Y29uc3Qgc2Vzc2lvbiA9IHJvdXRlci5fcGVuZGluZztcblx0aWYgKCFzZXNzaW9uKSByZXR1cm47XG5cdGNsZWFyVGltZW91dChzZXNzaW9uWzNdKTtcblx0Y29uc3QgcmVtYWluaW5nID0gc2Vzc2lvblsyXSAtIERhdGUubm93KCk7XG5cdGlmICghc2Vzc2lvbls0XSB8fCByZW1haW5pbmcgPD0gMCB8fCAhX2dldFJlbmRlcmVkTWF0Y2hlcyh0eFszXSkuc29tZSgobWF0Y2gpID0+IG1hdGNoLmlkID09PSBzZXNzaW9uWzFdKSkgcmV0dXJuO1xuXHRsZXQgdGltZXI7XG5cdHRyeSB7XG5cdFx0YXdhaXQgd2FpdEZvcihuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuXHRcdFx0dGltZXIgPSBzZXRUaW1lb3V0KHJlc29sdmUsIHJlbWFpbmluZyk7XG5cdFx0fSksIHR4WzBdLnNpZ25hbCk7XG5cdH0gY2F0Y2gge31cblx0Y2xlYXJUaW1lb3V0KHRpbWVyKTtcbn1cbmZ1bmN0aW9uIHB1Ymxpc2hNYXRjaGVzKHJvdXRlciwgbWF0Y2hlcykge1xuXHRyb3V0ZXIuX2NvbW1pdHRlZCA9IG1hdGNoZXM7XG5cdHJvdXRlci5zdG9yZXMuc2V0TWF0Y2hlcyhtYXRjaGVzKTtcbn1cbmZ1bmN0aW9uIGNvbW1pdE1hdGNoZXMocm91dGVyLCB0eCwgbWF0Y2hlcywgcmVzb2x2ZWRQcmVmaXgpIHtcblx0Y29uc3QgcHJldmlvdXMgPSByb3V0ZXIuX2NvbW1pdHRlZDtcblx0Y29uc3QgcHJldmlvdXNFbmQgPSByb3V0ZXIuX2xpZmVjeWNsZUVuZDtcblx0Y29uc3QgcHJldmlvdXNDYWNoZWQgPSByb3V0ZXIuX2NhY2hlO1xuXHRmb3IgKGNvbnN0IG1hdGNoIG9mIG1hdGNoZXMpIHtcblx0XHRtYXRjaC5wcmVsb2FkID0gZmFsc2U7XG5cdFx0aWYgKHJlc29sdmVkUHJlZml4KSBtYXRjaC5fYXNzZXRFbmQgPSB2b2lkIDA7XG5cdH1cblx0Y29uc3QgY3V0ID0gX2dldFJlbmRlcmVkTWF0Y2hlcyhtYXRjaGVzKS5sZW5ndGg7XG5cdGNvbnN0IGNhY2hlZCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgfHwgIXR4WzZdKSB7XG5cdFx0Y29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcblx0XHRjb25zdCBzdXBlcnNlZGVkID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHRmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgbWF0Y2hlcy5sZW5ndGg7IGluZGV4KyspIHtcblx0XHRcdGNvbnN0IG1hdGNoID0gbWF0Y2hlc1tpbmRleF07XG5cdFx0XHRpZiAoaW5kZXggPCBjdXQgfHwgbWF0Y2guc3RhdHVzID09PSBcInN1Y2Nlc3NcIikgc3VwZXJzZWRlZC5hZGQobWF0Y2guaWQpO1xuXHRcdH1cblx0XHRmb3IgKGNvbnN0IG1hdGNoIG9mIFsuLi5wcmV2aW91cywgLi4ucHJldmlvdXNDYWNoZWQudmFsdWVzKCldKSB7XG5cdFx0XHRpZiAobWF0Y2guc3RhdHVzICE9PSBcInN1Y2Nlc3NcIiB8fCBzdXBlcnNlZGVkLmhhcyhtYXRjaC5pZCkpIGNvbnRpbnVlO1xuXHRcdFx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKTtcblx0XHRcdGlmICghcm91dGUub3B0aW9ucy5sb2FkZXIgfHwgbm93IC0gbWF0Y2gudXBkYXRlZEF0ID49IChtYXRjaC5wcmVsb2FkID8gcm91dGUub3B0aW9ucy5wcmVsb2FkR2NUaW1lID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRQcmVsb2FkR2NUaW1lID8/IDNlNSA6IHJvdXRlLm9wdGlvbnMuZ2NUaW1lID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRHY1RpbWUgPz8gM2U1KSkgY29udGludWU7XG5cdFx0XHRjYWNoZWQuc2V0KG1hdGNoLmlkLCBwcmV2aW91c0NhY2hlZC5nZXQobWF0Y2guaWQpID09PSBtYXRjaCA/IG1hdGNoIDoge1xuXHRcdFx0XHQuLi5tYXRjaCxcblx0XHRcdFx0X2ZsaWdodDogdm9pZCAwLFxuXHRcdFx0XHRpc0ZldGNoaW5nOiBmYWxzZSxcblx0XHRcdFx0Y29udGV4dDoge31cblx0XHRcdH0pO1xuXHRcdH1cblx0fVxuXHR0eFszXSA9IFtdO1xuXHRyb3V0ZXIuX2NhY2hlID0gY2FjaGVkO1xuXHRjb25zdCBuZXh0RW5kID0gcm91dGVyLl9saWZlY3ljbGVFbmQgPSBsaWZlY3ljbGVFbmQobWF0Y2hlcyk7XG5cdHB1Ymxpc2hNYXRjaGVzKHJvdXRlciwgbWF0Y2hlcyk7XG5cdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBbLi4ucHJldmlvdXNDYWNoZWQudmFsdWVzKCksIC4uLnByZXZpb3VzXS5maWx0ZXIoKG1hdGNoKSA9PiBtYXRjaC5fZmxpZ2h0ICYmIGNhY2hlZC5nZXQobWF0Y2guaWQpICE9PSBtYXRjaCksIG1hdGNoZXMpO1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0Y29uc3QgaGFuZG9mZiA9IHR4WzZdPy5bMF07XG5cdFx0aWYgKGhhbmRvZmYgJiYgcm91dGVyLl9oYW5kb2ZmID09PSBoYW5kb2ZmKSBoYW5kb2ZmWzFdKCk7XG5cdH1cblx0cnVuUm91dGVMaWZlY3ljbGUocm91dGVyLCBwcmV2aW91cywgbWF0Y2hlcywgcHJldmlvdXNFbmQsIG5leHRFbmQsIHR4KTtcbn1cbi8qKlxuKiBSZXNvbHZlIG9uY2UgdGhlIHJvdXRlciBoYXMgc2V0dGxlZCBvbiBhIHRyYW5zYWN0aW9uIG90aGVyIHRoYW4gYG93bmVyYC5cbiogRWFjaCB0cmFuc2FjdGlvbidzIGNvbXBsZXRpb24gZm9sbG93cyBpdHMgY3VycmVudCBzdWNjZXNzb3IsIHNvIGFsbCB3YWl0ZXJzXG4qIHNoYXJlIHRoZSBzYW1lIGNoYWluIGluc3RlYWQgb2YgcG9sbGluZyBldmVyeSBzdWNjZXNzb3IgaW5kZXBlbmRlbnRseS5cbiovXG5hc3luYyBmdW5jdGlvbiBhd2FpdEN1cnJlbnQocm91dGVyLCBvd25lcikge1xuXHRsZXQgY3VycmVudCA9IHJvdXRlci5fdHg7XG5cdHdoaWxlIChjdXJyZW50ICYmIGN1cnJlbnQgIT09IG93bmVyKSB7XG5cdFx0b3duZXIgPSBjdXJyZW50O1xuXHRcdGF3YWl0IGN1cnJlbnRbNV07XG5cdFx0Y3VycmVudCA9IHJvdXRlci5fdHg7XG5cdH1cbn1cbmZ1bmN0aW9uIGZvbGxvd1JlZGlyZWN0KHJvdXRlciwgdHgsIG91dGNvbWUpIHtcblx0Y29uc3Qgb3B0aW9ucyA9IG91dGNvbWVbMV0ub3B0aW9ucztcblx0Y29uc3QgbG9jYXRpb24gPSBvdXRjb21lWzJdO1xuXHRpZiAoIWxvY2F0aW9uKSByZXR1cm4gcm91dGVyLm5hdmlnYXRlKHtcblx0XHQuLi5vcHRpb25zLFxuXHRcdHJlcGxhY2U6IHRydWUsXG5cdFx0aWdub3JlQmxvY2tlcjogdHJ1ZVxuXHR9KTtcblx0aWYgKG9wdGlvbnMucmVsb2FkRG9jdW1lbnQpIHJldHVybiByb3V0ZXIubmF2aWdhdGUoe1xuXHRcdGhyZWY6IChsb2NhdGlvbi5tYXNrZWRMb2NhdGlvbiA/PyBsb2NhdGlvbikucHVibGljSHJlZixcblx0XHRyZWxvYWREb2N1bWVudDogdHJ1ZSxcblx0XHRyZXBsYWNlOiB0cnVlLFxuXHRcdGlnbm9yZUJsb2NrZXI6IHRydWVcblx0fSk7XG5cdGxvY2F0aW9uLl9yZWRpcmVjdHMgPSB0eFsxXSArIDE7XG5cdHJvdXRlci5fcGVuZGluZ0xvY2F0aW9uID0gbG9jYXRpb247XG5cdGNvbnN0IGNvbW1pdHRlZCA9IHJvdXRlci5jb21taXRMb2NhdGlvbih7XG5cdFx0Li4ubG9jYXRpb24sXG5cdFx0dmlld1RyYW5zaXRpb246IG9wdGlvbnMudmlld1RyYW5zaXRpb24sXG5cdFx0cmVwbGFjZTogdHJ1ZSxcblx0XHRyZXNldFNjcm9sbDogb3B0aW9ucy5yZXNldFNjcm9sbCxcblx0XHRoYXNoU2Nyb2xsSW50b1ZpZXc6IG9wdGlvbnMuaGFzaFNjcm9sbEludG9WaWV3LFxuXHRcdGlnbm9yZUJsb2NrZXI6IHRydWVcblx0fSk7XG5cdHF1ZXVlTWljcm90YXNrKCgpID0+IHtcblx0XHRpZiAocm91dGVyLl9wZW5kaW5nTG9jYXRpb24gPT09IGxvY2F0aW9uKSByb3V0ZXIuX3BlbmRpbmdMb2NhdGlvbiA9IHZvaWQgMDtcblx0fSk7XG5cdHJldHVybiBjb21taXR0ZWQ7XG59XG5hc3luYyBmdW5jdGlvbiBydW5CYWNrZ3JvdW5kKHJvdXRlciwgdHgsIGJhc2UsIHRhc2tzLCBzZXR0bGVtZW50KSB7XG5cdGNvbnN0IG5leHQgPSBiYXNlLm1hcCgobWF0Y2gpID0+ICh7IC4uLm1hdGNoIH0pKTtcblx0YWNxdWlyZU1hdGNoUmVzb3VyY2VzKG5leHQpO1xuXHRmb3IgKGNvbnN0IHRhc2sgb2YgdGFza3MpIHtcblx0XHRyZWxlYXNlRmxpZ2h0KHJvdXRlciwgbmV4dFt0YXNrWzBdXSk7XG5cdFx0bmV4dFt0YXNrWzBdXSA9IHRhc2tbM107XG5cdH1cblx0Y29uc3QgbGFuZSA9IFt0eFsyXSwgbmV4dF07XG5cdGxldCByZWR1Y2VkO1xuXHR0cnkge1xuXHRcdHJlZHVjZWQgPSBhd2FpdCByZWR1Y2VMYW5lKHJvdXRlciwgbGFuZSwgdGFza3MsIHR4WzBdLCBzZXR0bGVtZW50KTtcblx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgbmV4dCk7XG5cdFx0dGhyb3cgY2F1c2U7XG5cdH1cblx0aWYgKGlzQ29udHJvbChyZWR1Y2VkKSkge1xuXHRcdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBuZXh0KTtcblx0XHRpZiAocmVkdWNlZFswXSA9PT0gUkVESVJFQ1RFRCAmJiByb3V0ZXIuX3R4ID09PSB0eCAmJiByb3V0ZXIuX2NvbW1pdHRlZCA9PT0gYmFzZSkgYXdhaXQgZm9sbG93UmVkaXJlY3Qocm91dGVyLCB0eCwgcmVkdWNlZCk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGF3YWl0IHByb2plY3RMYW5lKHJvdXRlciwgcmVkdWNlZCwgdHhbMF0uc2lnbmFsKTtcblx0aWYgKHJvdXRlci5fdHggIT09IHR4IHx8IHJvdXRlci5fY29tbWl0dGVkICE9PSBiYXNlKSB7XG5cdFx0dHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIG5leHQpO1xuXHRcdHJldHVybjtcblx0fVxuXHRmb3IgKGNvbnN0IG1hdGNoIG9mIG5leHQpIHtcblx0XHRjb25zdCBjYWNoZWQgPSByb3V0ZXIuX2NhY2hlLmdldChtYXRjaC5pZCk7XG5cdFx0aWYgKGNhY2hlZD8uX2ZsaWdodCAmJiBjYWNoZWQuX2ZsaWdodCA9PT0gbWF0Y2guX2ZsaWdodCkge1xuXHRcdFx0cm91dGVyLl9jYWNoZS5kZWxldGUobWF0Y2guaWQpO1xuXHRcdFx0cmVsZWFzZUZsaWdodChyb3V0ZXIsIGNhY2hlZCk7XG5cdFx0fVxuXHR9XG5cdHB1Ymxpc2hNYXRjaGVzKHJvdXRlciwgbmV4dCk7XG5cdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBiYXNlLCBuZXh0KTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHJ1bkNsaWVudFRyYW5zYWN0aW9uKHJvdXRlciwgdHgsIGZvcmNlU3RhbGVSZWxvYWQsIG9uUmVhZHksIHN5bmMsIHJlc29sdmVkUHJlZml4KSB7XG5cdGNvbnN0IHJlc3VsdCA9IGF3YWl0IGV4ZWN1dGVDbGllbnRMYW5lKHJvdXRlciwgdHhbMl0sIHR4WzNdLCBbXG5cdFx0dHhbMF0sXG5cdFx0dHhbMV0sXG5cdFx0cm91dGVyLl9jb21taXR0ZWQsXG5cdFx0dm9pZCAwLFxuXHRcdHN5bmMsXG5cdFx0Zm9yY2VTdGFsZVJlbG9hZCxcblx0XHRyZXNvbHZlZFByZWZpeCxcblx0XHRvblJlYWR5XG5cdF0pO1xuXHRpZiAoaXNDb250cm9sKHJlc3VsdCkpIHtcblx0XHRjb25zdCBmb2xsb3cgPSByZXN1bHRbMF0gPT09IFJFRElSRUNURUQgJiYgcm91dGVyLl90eCA9PT0gdHg7XG5cdFx0aWYgKCFmb2xsb3cgfHwgcmVzdWx0WzFdLm9wdGlvbnMucmVsb2FkRG9jdW1lbnQpIGZpbmlzaFBlbmRpbmcocm91dGVyLCB0eCk7XG5cdFx0dHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIHR4WzNdKTtcblx0XHR0eFszXSA9IFtdO1xuXHRcdGlmICghZm9sbG93KSByZXR1cm47XG5cdFx0aWYgKHJvdXRlci5fdHggIT09IHR4KSB7XG5cdFx0XHRmaW5pc2hQZW5kaW5nKHJvdXRlciwgdHgpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIHR4WzZdKSByb3V0ZXIuX3JlZnJlc2hOZXh0TG9hZCA9IHRydWU7XG5cdFx0YXdhaXQgZm9sbG93UmVkaXJlY3Qocm91dGVyLCB0eCwgcmVzdWx0KTtcblx0XHRyZXR1cm47XG5cdH1cblx0Y29uc3QgbWF0Y2hlcyA9IHJlc3VsdFsxXTtcblx0aWYgKHJvdXRlci5fdHggPT09IHR4KSBhd2FpdCBhd2FpdFBlbmRpbmdNaW5pbXVtKHJvdXRlciwgdHgpO1xuXHRpZiAocm91dGVyLl90eCAhPT0gdHgpIHtcblx0XHRmaW5pc2hQZW5kaW5nKHJvdXRlciwgdHgpO1xuXHRcdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBtYXRjaGVzKTtcblx0XHRkaXNjYXJkQmFja2dyb3VuZChyb3V0ZXIsIHJlc3VsdCk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGNvbnN0IHRvTG9jYXRpb24gPSB0eFsyXTtcblx0Y29uc3QgY2hhbmdlSW5mbyA9IGdldExvY2F0aW9uQ2hhbmdlSW5mbyh0b0xvY2F0aW9uLCByb3V0ZXIuc3RvcmVzLnJlc29sdmVkTG9jYXRpb24uZ2V0KCkpO1xuXHRjb25zdCBiYWNrZ3JvdW5kID0gcmVzdWx0WzJdO1xuXHRhd2FpdCByb3V0ZXIuc3RhcnRWaWV3VHJhbnNpdGlvbihhc3luYyAoKSA9PiB7XG5cdFx0aWYgKHJvdXRlci5fdHggPT09IHR4KSBhd2FpdCBhd2FpdFBlbmRpbmdNaW5pbXVtKHJvdXRlciwgdHgpO1xuXHRcdGlmIChyb3V0ZXIuX3R4ICE9PSB0eCkge1xuXHRcdFx0ZmluaXNoUGVuZGluZyhyb3V0ZXIsIHR4KTtcblx0XHRcdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCBtYXRjaGVzKTtcblx0XHRcdGRpc2NhcmRCYWNrZ3JvdW5kKHJvdXRlciwgcmVzdWx0KTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0Y29uc3QgY29tbWl0ID0gKCkgPT4ge1xuXHRcdFx0ZmluaXNoUGVuZGluZyhyb3V0ZXIsIHR4KTtcblx0XHRcdGNvbW1pdE1hdGNoZXMocm91dGVyLCB0eCwgbWF0Y2hlcywgcmVzb2x2ZWRQcmVmaXgpO1xuXHRcdFx0aWYgKHJvdXRlci5fdHggIT09IHR4KSByZXR1cm47XG5cdFx0XHRyb3V0ZXIuZW1pdCh7XG5cdFx0XHRcdHR5cGU6IFwib25Mb2FkXCIsXG5cdFx0XHRcdC4uLmNoYW5nZUluZm9cblx0XHRcdH0pO1xuXHRcdFx0aWYgKHJvdXRlci5fdHggPT09IHR4KSByb3V0ZXIuZW1pdCh7XG5cdFx0XHRcdHR5cGU6IFwib25CZWZvcmVSb3V0ZU1vdW50XCIsXG5cdFx0XHRcdC4uLmNoYW5nZUluZm9cblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0Y29uc3QgcmVuZGVyZWQgPSBhd2FpdCByb3V0ZXIuc3RhcnRUcmFuc2l0aW9uKGNvbW1pdCwgbWF0Y2hlcyk7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiB0eFs2XSkgdHhbNl0gPSB2b2lkIDA7XG5cdFx0aWYgKHJvdXRlci5fdHggIT09IHR4KSB7XG5cdFx0XHRkaXNjYXJkQmFja2dyb3VuZChyb3V0ZXIsIHJlc3VsdCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmIChiYWNrZ3JvdW5kPy5sZW5ndGgpIHJ1bkJhY2tncm91bmQocm91dGVyLCB0eCwgbWF0Y2hlcywgYmFja2dyb3VuZCwgcmVzdWx0WzNdKS5jYXRjaChjb25zb2xlLmVycm9yKTtcblx0XHRyb3V0ZXIuYmF0Y2goKCkgPT4ge1xuXHRcdFx0cm91dGVyLnN0b3Jlcy5yZXNvbHZlZExvY2F0aW9uLnNldCh0b0xvY2F0aW9uKTtcblx0XHRcdHJvdXRlci5zdG9yZXMuc3RhdHVzLnNldChcImlkbGVcIik7XG5cdFx0XHRpZiAocm91dGVyLl90eCA9PT0gdHgpIHJvdXRlci5lbWl0KHtcblx0XHRcdFx0dHlwZTogXCJvblJlc29sdmVkXCIsXG5cdFx0XHRcdC4uLmNoYW5nZUluZm9cblx0XHRcdH0pO1xuXHRcdFx0aWYgKHJlbmRlcmVkICYmIHJvdXRlci5fdHggPT09IHR4KSByb3V0ZXIuZW1pdCh7XG5cdFx0XHRcdHR5cGU6IFwib25SZW5kZXJlZFwiLFxuXHRcdFx0XHQuLi5jaGFuZ2VJbmZvXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHRpZiAocm91dGVyLl90eCAhPT0gdHgpIHJldHVybjtcblx0XHRyb3V0ZXIuX2NvbW1pdFByb21pc2U/LnJlc29sdmUoKTtcblx0XHRyb3V0ZXIuX2NvbW1pdFByb21pc2UgPSB2b2lkIDA7XG5cdH0pO1xufVxuYXN5bmMgZnVuY3Rpb24gbG9hZENsaWVudFJvdXRlKHJvdXRlciwgb3B0cykge1xuXHRsZXQgcmVtYXRlcmlhbGl6ZSA9IGZhbHNlO1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSByZW1hdGVyaWFsaXplID0gISFyb3V0ZXIuX3JlZnJlc2hOZXh0TG9hZCB8fCAhIXJvdXRlci5fdHg/Lls2XTtcblx0Y29uc3QgcHJldmlvdXNPd25lciA9IHJvdXRlci5fdHg7XG5cdGNvbnN0IHJlc29sdmVkTG9jYXRpb24gPSByb3V0ZXIuc3RvcmVzLnJlc29sdmVkTG9jYXRpb24uZ2V0KCk7XG5cdGNvbnN0IHByZXZpb3VzTG9jYXRpb24gPSByZXNvbHZlZExvY2F0aW9uID8/IHJvdXRlci5zdG9yZXMubG9jYXRpb24uZ2V0KCk7XG5cdGNvbnN0IGxvY2F0aW9uID0gcm91dGVyLmxhdGVzdExvY2F0aW9uO1xuXHRjb25zdCBwZW5kaW5nTG9jYXRpb24gPSByb3V0ZXIuX3BlbmRpbmdMb2NhdGlvbjtcblx0Y29uc3QgcmVkaXJlY3RzID0gcGVuZGluZ0xvY2F0aW9uPy5ocmVmID09PSBsb2NhdGlvbi5ocmVmID8gcGVuZGluZ0xvY2F0aW9uLl9yZWRpcmVjdHMgPz8gMCA6IDA7XG5cdGNvbnN0IGhhbmRvZmYgPSByb3V0ZXIuX2hhbmRvZmY7XG5cdGNvbnN0IGh5ZHJhdGlvbkNvbnRyb2xsZXIgPSByZW1hdGVyaWFsaXplID8gdm9pZCAwIDogaGFuZG9mZj8uWzBdKCk7XG5cdGNvbnN0IHByZWZsaWdodCA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0Y29uc3QgcHJldmlvdXNQcmVmbGlnaHQgPSByb3V0ZXIuX3ByZWZsaWdodDtcblx0cm91dGVyLl9wcmVmbGlnaHQgPSBwcmVmbGlnaHQ7XG5cdGlmICghcmVtYXRlcmlhbGl6ZSAmJiAhaHlkcmF0aW9uQ29udHJvbGxlcikgaGFuZG9mZj8uWzFdKCk7XG5cdHByZXZpb3VzUHJlZmxpZ2h0Py5hYm9ydCgpO1xuXHRpZiAoIXByZWZsaWdodC5zaWduYWwuYWJvcnRlZCkge1xuXHRcdGNvbnN0IGNoYW5nZUluZm8gPSBnZXRMb2NhdGlvbkNoYW5nZUluZm8obG9jYXRpb24sIHJlc29sdmVkTG9jYXRpb24pO1xuXHRcdHJvdXRlci5lbWl0KHtcblx0XHRcdHR5cGU6IFwib25CZWZvcmVOYXZpZ2F0ZVwiLFxuXHRcdFx0Li4uY2hhbmdlSW5mb1xuXHRcdH0pO1xuXHRcdGlmICghcHJlZmxpZ2h0LnNpZ25hbC5hYm9ydGVkKSByb3V0ZXIuZW1pdCh7XG5cdFx0XHR0eXBlOiBcIm9uQmVmb3JlTG9hZFwiLFxuXHRcdFx0Li4uY2hhbmdlSW5mb1xuXHRcdH0pO1xuXHR9XG5cdGlmIChwcmVmbGlnaHQuc2lnbmFsLmFib3J0ZWQpIHtcblx0XHRhd2FpdCBhd2FpdEN1cnJlbnQocm91dGVyLCBwcmV2aW91c093bmVyKTtcblx0XHRyZXR1cm47XG5cdH1cblx0Y29uc3Qgc2FtZUhyZWYgPSBwcmV2aW91c0xvY2F0aW9uLmhyZWYgPT09IGxvY2F0aW9uLmhyZWY7XG5cdGxldCBjb250cm9sbGVyID0gcHJlZmxpZ2h0O1xuXHRjb25zdCBtYXRjaGVzID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIHJlbWF0ZXJpYWxpemUgPyByb3V0ZXIubWF0Y2hSb3V0ZXMobG9jYXRpb24sIHtcblx0XHRfY29udHJvbGxlcjogcHJlZmxpZ2h0LFxuXHRcdF9yZW1hdGVyaWFsaXplOiB0cnVlXG5cdH0pIDogcm91dGVyLm1hdGNoUm91dGVzKGxvY2F0aW9uLCB7IF9jb250cm9sbGVyOiBwcmVmbGlnaHQgfSk7XG5cdGFjcXVpcmVNYXRjaFJlc291cmNlcyhtYXRjaGVzKTtcblx0Y29uc3QgcmVzb2x2ZWRQcmVmaXggPSBoeWRyYXRpb25Db250cm9sbGVyID8gaGFuZG9mZlsxXShtYXRjaGVzKSA6IHZvaWQgMDtcblx0aWYgKHJlc29sdmVkUHJlZml4KSBjb250cm9sbGVyID0gaHlkcmF0aW9uQ29udHJvbGxlcjtcblx0ZWxzZSBoeWRyYXRpb25Db250cm9sbGVyPy5hYm9ydCgpO1xuXHRpZiAocHJlZmxpZ2h0LnNpZ25hbC5hYm9ydGVkKSB7XG5cdFx0dHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIG1hdGNoZXMpO1xuXHRcdGF3YWl0IGF3YWl0Q3VycmVudChyb3V0ZXIsIHByZXZpb3VzT3duZXIpO1xuXHRcdHJldHVybjtcblx0fVxuXHRyb3V0ZXIuX3ByZWZsaWdodCA9IHZvaWQgMDtcblx0bGV0IHNldHRsZTtcblx0Y29uc3QgcnVuID0gKCkgPT4gcnVuQ2xpZW50VHJhbnNhY3Rpb24ocm91dGVyLCB0eCwgc2FtZUhyZWYsICgpID0+IG9mZmVyUGVuZGluZyhyb3V0ZXIsIHR4KSwgb3B0cz8uc3luYywgcmVzb2x2ZWRQcmVmaXgpO1xuXHRjb25zdCBkb25lID0gb3B0cz8uc3luYyA/IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiBzZXR0bGUgPSByZXNvbHZlKSA6IFByb21pc2UucmVzb2x2ZSgpLnRoZW4ocnVuKTtcblx0Y29uc3QgdHggPSBbXG5cdFx0Y29udHJvbGxlcixcblx0XHRyZWRpcmVjdHMsXG5cdFx0bG9jYXRpb24sXG5cdFx0bWF0Y2hlcyxcblx0XHREYXRlLm5vdygpLFxuXHRcdGRvbmUudGhlbigoKSA9PiBhd2FpdEN1cnJlbnQocm91dGVyLCB0eCkpXG5cdF07XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgcmVtYXRlcmlhbGl6ZSkge1xuXHRcdHR4WzZdID0gW2hhbmRvZmZdO1xuXHRcdHJvdXRlci5fcmVmcmVzaE5leHRMb2FkID0gdm9pZCAwO1xuXHR9XG5cdHJvdXRlci5fdHggPSB0eDtcblx0aWYgKHByZXZpb3VzT3duZXIpIHtcblx0XHRmb3IgKGNvbnN0IG1hdGNoIG9mIHJvdXRlci5zdG9yZXMubWF0Y2hlcy5nZXQoKSkge1xuXHRcdFx0aWYgKHJvdXRlci5fdHggIT09IHR4KSBicmVhaztcblx0XHRcdGlmIChtYXRjaC5pc0ZldGNoaW5nKSBzZXRGZXRjaGluZyhyb3V0ZXIsIG1hdGNoLCBmYWxzZSk7XG5cdFx0fVxuXHRcdHByZXZpb3VzT3duZXJbMF0uYWJvcnQoKTtcblx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgcHJldmlvdXNPd25lclszXSwgdHhbM10sIHRydWUpO1xuXHR9XG5cdGlmIChyb3V0ZXIuX3R4ICE9PSB0eCkge1xuXHRcdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCB0eFszXSk7XG5cdFx0dHhbM10gPSBbXTtcblx0XHRzZXR0bGU/LigpO1xuXHRcdGF3YWl0IGF3YWl0Q3VycmVudChyb3V0ZXIsIHR4KTtcblx0XHRyZXR1cm47XG5cdH1cblx0cm91dGVyLmJhdGNoKCgpID0+IHtcblx0XHRyb3V0ZXIuc3RvcmVzLnN0YXR1cy5zZXQoXCJwZW5kaW5nXCIpO1xuXHRcdHJvdXRlci5zdG9yZXMubG9jYXRpb24uc2V0KGxvY2F0aW9uKTtcblx0fSk7XG5cdGlmIChyZXNvbHZlZFByZWZpeCB8fCAhcm91dGVyLl9jb21taXR0ZWQubGVuZ3RoICYmIG1hdGNoZXNbMF0/LnN0YXR1cyAhPT0gXCJzdWNjZXNzXCIgJiYgIW1hdGNoZXMuc29tZSgobWF0Y2gpID0+IG1hdGNoLl9ub3RGb3VuZCkpIG9mZmVyUGVuZGluZyhyb3V0ZXIsIHR4KTtcblx0c2V0dGxlPy4ocnVuKCkpO1xuXHRhd2FpdCB0eFs1XTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHJlZnJlc2hDbGllbnRSb3V0ZShyb3V0ZXIpIHtcblx0Y29uc3QgcGVuZGluZyA9IHJvdXRlci5fdHg7XG5cdGlmIChwZW5kaW5nICYmICFwZW5kaW5nWzZdICYmIHJvdXRlci5zdG9yZXMuc3RhdHVzLmdldCgpID09PSBcInBlbmRpbmdcIikge1xuXHRcdGF3YWl0IHBlbmRpbmdbNV07XG5cdFx0aWYgKHJvdXRlci5fdHggIT09IHBlbmRpbmcpIGF3YWl0IGF3YWl0Q3VycmVudChyb3V0ZXIsIHBlbmRpbmcpO1xuXHR9XG5cdHJvdXRlci5fZmxpZ2h0cz8uY2xlYXIoKTtcblx0cm91dGVyLmNsZWFyQ2FjaGUoKTtcblx0cm91dGVyLl9yZWZyZXNoTmV4dExvYWQgPSB0cnVlO1xuXHRhd2FpdCBsb2FkQ2xpZW50Um91dGUocm91dGVyLCB7IHN5bmM6IHRydWUgfSk7XG59XG5hc3luYyBmdW5jdGlvbiBwcmVsb2FkQ2xpZW50Um91dGUocm91dGVyLCBvcHRzKSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgKHJvdXRlci5fcmVmcmVzaE5leHRMb2FkIHx8IHJvdXRlci5fdHg/Lls2XSkpIHJldHVybjtcblx0bGV0IGxvY2F0aW9uID0gcm91dGVyLmJ1aWxkTG9jYXRpb24ob3B0cyk7XG5cdGZvciAobGV0IHJlZGlyZWN0cyA9IDA7OyByZWRpcmVjdHMrKykge1xuXHRcdGNvbnN0IGJhc2UgPSByb3V0ZXIuX2NvbW1pdHRlZDtcblx0XHRjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuXHRcdGxldCBtYXRjaGVzO1xuXHRcdGxldCBhY3RpdmU7XG5cdFx0bGV0IHJlc3VsdDtcblx0XHR0cnkge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0bWF0Y2hlcyA9IHJvdXRlci5tYXRjaFJvdXRlcyhsb2NhdGlvbiwgeyBfY29udHJvbGxlcjogY29udHJvbGxlciB9KTtcblx0XHRcdFx0YWNxdWlyZU1hdGNoUmVzb3VyY2VzKG1hdGNoZXMpO1xuXHRcdFx0XHRhY3RpdmUgPSAocm91dGVyLl9wcmVsb2FkcyA/Pz0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSkuc2V0KGNvbnRyb2xsZXIsIG1hdGNoZXMpO1xuXHRcdFx0XHRyZXN1bHQgPSBhd2FpdCBleGVjdXRlQ2xpZW50TGFuZShyb3V0ZXIsIGxvY2F0aW9uLCBtYXRjaGVzLCBbXG5cdFx0XHRcdFx0Y29udHJvbGxlcixcblx0XHRcdFx0XHRyZWRpcmVjdHMsXG5cdFx0XHRcdFx0YmFzZSxcblx0XHRcdFx0XHR0cnVlXG5cdFx0XHRcdF0pO1xuXHRcdFx0fSBmaW5hbGx5IHtcblx0XHRcdFx0aWYgKGFjdGl2ZSkge1xuXHRcdFx0XHRcdGFjdGl2ZSA9IGFjdGl2ZS5kZWxldGUoY29udHJvbGxlcik7XG5cdFx0XHRcdFx0dHJhbnNmZXJNYXRjaFJlc291cmNlcyhyb3V0ZXIsIG1hdGNoZXMpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGNvbnRyb2xsZXIuYWJvcnQoKTtcblx0XHRcdH1cblx0XHRcdGlmICghaXNDb250cm9sKHJlc3VsdCkpIHJldHVybiByZXN1bHRbMV07XG5cdFx0XHRpZiAoIWFjdGl2ZSB8fCByZXN1bHQubGVuZ3RoIDwgMyB8fCBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgKHJvdXRlci5fcmVmcmVzaE5leHRMb2FkIHx8IHJvdXRlci5fdHg/Lls2XSkpIHJldHVybjtcblx0XHRcdGxvY2F0aW9uID0gcmVzdWx0WzJdO1xuXHRcdH0gY2F0Y2ggKGNhdXNlKSB7XG5cdFx0XHRpZiAoIWlzTm90Rm91bmQoY2F1c2UpKSBjb25zb2xlLmVycm9yKGNhdXNlKTtcblx0XHRcdHJldHVybjtcblx0XHR9XG5cdH1cbn1cbmFzeW5jIGZ1bmN0aW9uIGh5ZHJhdGUocm91dGVyKSB7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIXdpbmRvdy4kX1RTUikgdGhyb3cgbmV3IEVycm9yKFwiSW52YXJpYW50IGZhaWxlZDogRXhwZWN0ZWQgdG8gZmluZCBib290c3RyYXAgZGF0YSBvbiB3aW5kb3cuJF9UU1IsIGJ1dCB3ZSBkaWQgbm90LiBQbGVhc2UgZmlsZSBhbiBpc3N1ZSFcIik7XG5cdGNvbnN0IHRzciA9IHdpbmRvdy4kX1RTUjtcblx0Y29uc3QgYWRhcHRlcnMgPSByb3V0ZXIub3B0aW9ucy5zZXJpYWxpemF0aW9uQWRhcHRlcnM7XG5cdGlmIChhZGFwdGVycz8ubGVuZ3RoKSB7XG5cdFx0dHNyLnQgPSBuZXcgTWFwKGFkYXB0ZXJzLm1hcCgoYWRhcHRlcikgPT4gW2FkYXB0ZXIua2V5LCBhZGFwdGVyLmZyb21TZXJpYWxpemFibGVdKSk7XG5cdFx0dHNyLmJ1ZmZlci5mb3JFYWNoKChzY3JpcHQpID0+IHNjcmlwdCgpKTtcblx0fVxuXHR0c3IuaW5pdGlhbGl6ZWQgPSB0cnVlO1xuXHRjb25zdCBkZWh5ZHJhdGVkUm91dGVyID0gdHNyLnJvdXRlcjtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAhZGVoeWRyYXRlZFJvdXRlcikgdGhyb3cgbmV3IEVycm9yKFwiSW52YXJpYW50IGZhaWxlZDogRXhwZWN0ZWQgdG8gZmluZCBhIGRlaHlkcmF0ZWQgZGF0YSBvbiB3aW5kb3cuJF9UU1Iucm91dGVyLCBidXQgd2UgZGlkIG5vdC4gUGxlYXNlIGZpbGUgYW4gaXNzdWUhXCIpO1xuXHRyb3V0ZXIuc3NyID0geyBtYW5pZmVzdDogZGVoeWRyYXRlZFJvdXRlci5tYW5pZmVzdCB9O1xuXHRyb3V0ZXIub3B0aW9ucy5zc3IgPSB7IG5vbmNlOiBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwibWV0YVtwcm9wZXJ0eT1cXFwiY3NwLW5vbmNlXFxcIl1cIik/LmNvbnRlbnQgfTtcblx0Y29uc3QgZGVoeWRyYXRlZE1hdGNoZXMgPSBkZWh5ZHJhdGVkUm91dGVyLm1hdGNoZXM7XG5cdGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG5cdGNvbnN0IHByZXZpb3VzUHJlZmxpZ2h0ID0gcm91dGVyLl9wcmVmbGlnaHQ7XG5cdHJvdXRlci5fcHJlZmxpZ2h0ID0gY29udHJvbGxlcjtcblx0cHJldmlvdXNQcmVmbGlnaHQ/LmFib3J0KCk7XG5cdGNvbnN0IGlzQ3VycmVudCA9ICgpID0+IHJvdXRlci5fcHJlZmxpZ2h0ID09PSBjb250cm9sbGVyO1xuXHRsZXQgbG9jYXRpb247XG5cdGxldCBjYW5kaWRhdGVzO1xuXHRsZXQgaGFuZG9mZkhpc3RvcnlIcmVmO1xuXHRsZXQgaGFuZG9mZkhpc3RvcnlTdGF0ZTtcblx0dHJ5IHtcblx0XHRhd2FpdCB3YWl0Rm9yKHJvdXRlci5vcHRpb25zLmh5ZHJhdGU/LihkZWh5ZHJhdGVkUm91dGVyLmRlaHlkcmF0ZWREYXRhKSwgY29udHJvbGxlci5zaWduYWwpO1xuXHRcdGlmICghaXNDdXJyZW50KCkpIHJldHVybjtcblx0XHRjb25zdCBoaXN0b3J5TG9jYXRpb24gPSByb3V0ZXIuaGlzdG9yeS5sb2NhdGlvbjtcblx0XHRoYW5kb2ZmSGlzdG9yeUhyZWYgPSBoaXN0b3J5TG9jYXRpb24uaHJlZjtcblx0XHRoYW5kb2ZmSGlzdG9yeVN0YXRlID0gaGlzdG9yeUxvY2F0aW9uLnN0YXRlO1xuXHRcdHJvdXRlci51cGRhdGVMYXRlc3RMb2NhdGlvbigpO1xuXHRcdGxvY2F0aW9uID0gcm91dGVyLmxhdGVzdExvY2F0aW9uO1xuXHRcdHJvdXRlci5zdG9yZXMubG9jYXRpb24uc2V0KGxvY2F0aW9uKTtcblx0XHRjYW5kaWRhdGVzID0gcm91dGVyLm1hdGNoUm91dGVzKGxvY2F0aW9uLCB7IF9jb250cm9sbGVyOiBjb250cm9sbGVyIH0pO1xuXHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdGlmIChpc0N1cnJlbnQoKSkgcm91dGVyLl9wcmVmbGlnaHQgPSB2b2lkIDA7XG5cdFx0Y29udHJvbGxlci5hYm9ydChjYXVzZSk7XG5cdFx0aWYgKGNhdXNlICE9PSBjb250cm9sbGVyLnNpZ25hbCkgdGhyb3cgY2F1c2U7XG5cdH1cblx0aWYgKCFpc0N1cnJlbnQoKSkgcmV0dXJuO1xuXHRjb25zdCBjb21taXR0ZWQgPSBbXTtcblx0bGV0IHBlbmRpbmdCb3VuZGFyeTtcblx0bGV0IHZlcmlmaWVkQXNzZXRFbmQgPSAwO1xuXHRjb25zdCByZXRyeUZyb20gPSAoaW5kZXgpID0+IHtcblx0XHR2ZXJpZmllZEFzc2V0RW5kID0gTWF0aC5taW4odmVyaWZpZWRBc3NldEVuZCwgaW5kZXggKyAxKTtcblx0XHRjb25zdCByZW1vdmVkID0gY29tbWl0dGVkLnNwbGljZShpbmRleCk7XG5cdFx0Zm9yIChjb25zdCBtYXRjaCBvZiByZW1vdmVkKSBpZiAoZ2V0Um91dGUocm91dGVyLCBtYXRjaCkub3B0aW9ucy5sb2FkZXIgJiYgKG1hdGNoLnN0YXR1cyA9PT0gXCJzdWNjZXNzXCIgfHwgIW1hdGNoLmludmFsaWQgJiYgXCJsb2FkZXJEYXRhXCIgaW4gbWF0Y2gpKSBjYWNoZUxvYWRlck1hdGNoKHJvdXRlciwge1xuXHRcdFx0Li4ubWF0Y2gsXG5cdFx0XHRzdGF0dXM6IFwic3VjY2Vzc1wiLFxuXHRcdFx0ZXJyb3I6IHZvaWQgMCxcblx0XHRcdHByZWxvYWQ6IHRydWVcblx0XHR9LCByb3V0ZXIuX2NhY2hlLmdldChtYXRjaC5pZCkpO1xuXHRcdHRyYW5zZmVyTWF0Y2hSZXNvdXJjZXMocm91dGVyLCByZW1vdmVkKTtcblx0fTtcblx0Y29uc3Qgc2hhcmVkID0gZGVoeWRyYXRlZE1hdGNoZXMubGVuZ3RoID4gY2FuZGlkYXRlcy5sZW5ndGggPyBjYW5kaWRhdGVzLmZpbmRJbmRleCgobWF0Y2gpID0+IG1hdGNoLl9ub3RGb3VuZCkgKyAxIDogZGVoeWRyYXRlZE1hdGNoZXMubGVuZ3RoO1xuXHRsZXQgaXNUZXJtaW5hbCA9IGZhbHNlO1xuXHRmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgc2hhcmVkOyBpbmRleCsrKSB7XG5cdFx0Y29uc3QgY2FuZGlkYXRlID0gY2FuZGlkYXRlc1tpbmRleF07XG5cdFx0Y29uc3QgZGVoeWRyYXRlZCA9IGRlaHlkcmF0ZWRNYXRjaGVzW2luZGV4XTtcblx0XHRpZiAoZGVoeWRyYXRlZC5pICE9PSBkZWh5ZHJhdGVTc3JNYXRjaElkKGNhbmRpZGF0ZS5pZCkpIHtcblx0XHRcdHBlbmRpbmdCb3VuZGFyeSA/Pz0gaW5kZXg7XG5cdFx0XHRicmVhaztcblx0XHR9XG5cdFx0dmVyaWZpZWRBc3NldEVuZCA9IGluZGV4ICsgMTtcblx0XHRjb25zdCByb3V0ZSA9IGdldFJvdXRlKHJvdXRlciwgY2FuZGlkYXRlKTtcblx0XHRpZiAoXCJsXCIgaW4gZGVoeWRyYXRlZCB8fCBkZWh5ZHJhdGVkLnMgPT09IFwic3VjY2Vzc1wiICYmIGRlaHlkcmF0ZWQuZSA9PT0gdm9pZCAwICYmIHJvdXRlLm9wdGlvbnMubG9hZGVyKSBjYW5kaWRhdGUubG9hZGVyRGF0YSA9IGRlaHlkcmF0ZWQubDtcblx0XHRjYW5kaWRhdGUuc3RhdHVzID0gZGVoeWRyYXRlZC5zO1xuXHRcdGNhbmRpZGF0ZS5zc3IgPSBkZWh5ZHJhdGVkLnNzcjtcblx0XHRyb3V0ZS5vcHRpb25zLnNzciA9IGNhbmRpZGF0ZS5zc3I7XG5cdFx0Y2FuZGlkYXRlLnVwZGF0ZWRBdCA9IGRlaHlkcmF0ZWQudTtcblx0XHRjYW5kaWRhdGUuZXJyb3IgPSBkZWh5ZHJhdGVkLmU7XG5cdFx0Y2FuZGlkYXRlLl9ub3RGb3VuZCB8fD0gZGVoeWRyYXRlZC5nO1xuXHRcdGlmIChjYW5kaWRhdGUuc3RhdHVzID09PSBcImVycm9yXCIgfHwgY2FuZGlkYXRlLnN0YXR1cyA9PT0gXCJub3RGb3VuZFwiIHx8IGNhbmRpZGF0ZS5fbm90Rm91bmQpIHtcblx0XHRcdGlzVGVybWluYWwgPSB0cnVlO1xuXHRcdFx0Y29tbWl0dGVkLnB1c2goY2FuZGlkYXRlKTtcblx0XHRcdGlmIChjYW5kaWRhdGUuc3NyID09PSBmYWxzZSB8fCBjYW5kaWRhdGUuc3NyID09PSBcImRhdGEtb25seVwiKSBwZW5kaW5nQm91bmRhcnkgPz89IGluZGV4O1xuXHRcdFx0YnJlYWs7XG5cdFx0fVxuXHRcdGlmIChjYW5kaWRhdGUuc3RhdHVzID09PSBcInBlbmRpbmdcIikge1xuXHRcdFx0cGVuZGluZ0JvdW5kYXJ5ID8/PSBpbmRleDtcblx0XHRcdGJyZWFrO1xuXHRcdH1cblx0XHRjb21taXR0ZWQucHVzaChjYW5kaWRhdGUpO1xuXHRcdGlmIChjYW5kaWRhdGUuc3NyID09PSBcImRhdGEtb25seVwiKSBwZW5kaW5nQm91bmRhcnkgPz89IGluZGV4O1xuXHR9XG5cdGlmICghaXNUZXJtaW5hbCAmJiBjb21taXR0ZWQubGVuZ3RoID09PSBzaGFyZWQgJiYgc2hhcmVkIDwgY2FuZGlkYXRlcy5sZW5ndGgpIHBlbmRpbmdCb3VuZGFyeSA9IHNoYXJlZDtcblx0Y29uc3QgY2h1bmtzID0gY29tbWl0dGVkLm1hcChhc3luYyAobWF0Y2gpID0+IHtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKTtcblx0XHRcdGF3YWl0IChtYXRjaC5fbm90Rm91bmQgPyBQcm9taXNlLmFsbChbbG9hZFJvdXRlQ2h1bmsocm91dGUpLCBsb2FkUm91dGVDaHVuayhyb3V0ZSwgXCJub3RGb3VuZENvbXBvbmVudFwiKV0pIDogbG9hZFJvdXRlQ2h1bmsocm91dGUsIG1hdGNoLnN0YXR1cyA9PT0gXCJlcnJvclwiID8gXCJlcnJvckNvbXBvbmVudFwiIDogbWF0Y2guc3RhdHVzID09PSBcIm5vdEZvdW5kXCIgPyBcIm5vdEZvdW5kQ29tcG9uZW50XCIgOiB2b2lkIDApKTtcblx0XHRcdHJldHVybiB0cnVlO1xuXHRcdH0gY2F0Y2gge1xuXHRcdFx0cmV0dXJuIGZhbHNlO1xuXHRcdH1cblx0fSk7XG5cdGxldCBjaHVua0ZhaWx1cmUgPSAwO1xuXHR0cnkge1xuXHRcdHdoaWxlIChjaHVua0ZhaWx1cmUgPCBjaHVua3MubGVuZ3RoICYmIGF3YWl0IHdhaXRGb3IoY2h1bmtzW2NodW5rRmFpbHVyZV0sIGNvbnRyb2xsZXIuc2lnbmFsKSkgY2h1bmtGYWlsdXJlKys7XG5cdH0gY2F0Y2gge1xuXHRcdHJldHVybjtcblx0fVxuXHRpZiAoIWlzQ3VycmVudCgpKSByZXR1cm47XG5cdGlmIChjaHVua0ZhaWx1cmUgPCBjb21taXR0ZWQubGVuZ3RoKSByZXRyeUZyb20oY2h1bmtGYWlsdXJlKTtcblx0Y29uc3QgY29udGV4dEVuZCA9IE1hdGgubWF4KHBlbmRpbmdCb3VuZGFyeSA9PT0gY29tbWl0dGVkLmxlbmd0aCA/IGNvbW1pdHRlZC5sZW5ndGggKyAxIDogY29tbWl0dGVkLmxlbmd0aCwgY2h1bmtGYWlsdXJlIDwgY2h1bmtzLmxlbmd0aCA/IGNodW5rRmFpbHVyZSA6IHZlcmlmaWVkQXNzZXRFbmQpO1xuXHRmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgY29udGV4dEVuZDsgaW5kZXgrKykge1xuXHRcdGNvbnN0IG1hdGNoID0gY2FuZGlkYXRlc1tpbmRleF07XG5cdFx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKTtcblx0XHRjb25zdCBwYXJlbnRDb250ZXh0ID0gY2FuZGlkYXRlc1tpbmRleCAtIDFdPy5jb250ZXh0ID8/IHJvdXRlci5vcHRpb25zLmNvbnRleHQgPz8ge307XG5cdFx0bGV0IHJvdXRlQ29udGV4dDtcblx0XHRpZiAocm91dGUub3B0aW9ucy5jb250ZXh0KSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRyb3V0ZUNvbnRleHQgPSBtYXRjaC5fY3R4ID0gcm91dGUub3B0aW9ucy5jb250ZXh0KHtcblx0XHRcdFx0XHRkZXBzOiBtYXRjaC5sb2FkZXJEZXBzLFxuXHRcdFx0XHRcdHBhcmFtczogbWF0Y2gucGFyYW1zLFxuXHRcdFx0XHRcdGNvbnRleHQ6IHBhcmVudENvbnRleHQsXG5cdFx0XHRcdFx0bG9jYXRpb24sXG5cdFx0XHRcdFx0bmF2aWdhdGU6IChvcHRzKSA9PiByb3V0ZXIubmF2aWdhdGUoe1xuXHRcdFx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0XHRcdF9mcm9tTG9jYXRpb246IGxvY2F0aW9uXG5cdFx0XHRcdFx0fSksXG5cdFx0XHRcdFx0YnVpbGRMb2NhdGlvbjogcm91dGVyLmJ1aWxkTG9jYXRpb24sXG5cdFx0XHRcdFx0Y2F1c2U6IG1hdGNoLmNhdXNlLFxuXHRcdFx0XHRcdGFib3J0Q29udHJvbGxlcjogY29udHJvbGxlcixcblx0XHRcdFx0XHRwcmVsb2FkOiBmYWxzZSxcblx0XHRcdFx0XHRtYXRjaGVzOiBjYW5kaWRhdGVzLFxuXHRcdFx0XHRcdHJvdXRlSWQ6IHJvdXRlLmlkXG5cdFx0XHRcdH0pIHx8IHt9O1xuXHRcdFx0fSBjYXRjaCB7XG5cdFx0XHRcdGlmICghaXNDdXJyZW50KCkpIHJldHVybjtcblx0XHRcdFx0aWYgKG1hdGNoLnN0YXR1cyAhPT0gXCJlcnJvclwiICYmIG1hdGNoLnN0YXR1cyAhPT0gXCJub3RGb3VuZFwiICYmICFtYXRjaC5fbm90Rm91bmQpIHtcblx0XHRcdFx0XHRwZW5kaW5nQm91bmRhcnkgPSBNYXRoLm1pbihwZW5kaW5nQm91bmRhcnkgPz8gaW5kZXgsIGluZGV4KTtcblx0XHRcdFx0XHRyZXRyeUZyb20oaW5kZXgpO1xuXHRcdFx0XHRcdGJyZWFrO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoIWlzQ3VycmVudCgpKSByZXR1cm47XG5cdFx0fVxuXHRcdG1hdGNoLmNvbnRleHQgPSB7XG5cdFx0XHQuLi5wYXJlbnRDb250ZXh0LFxuXHRcdFx0Li4ucm91dGVDb250ZXh0LFxuXHRcdFx0Li4uY29tbWl0dGVkW2luZGV4XSAmJiBkZWh5ZHJhdGVkTWF0Y2hlc1tpbmRleF0uYlxuXHRcdH07XG5cdH1cblx0YXdhaXQgcHJvamVjdExhbmUocm91dGVyLCBbbG9jYXRpb24sIGNhbmRpZGF0ZXNdLCBjb250cm9sbGVyLnNpZ25hbCwgMCwgdmVyaWZpZWRBc3NldEVuZCk7XG5cdGlmICghaXNDdXJyZW50KCkpIHJldHVybjtcblx0Y29uc3QgbmVlZHNDbGllbnRMb2FkID0gcGVuZGluZ0JvdW5kYXJ5ICE9PSB2b2lkIDAgfHwgY29tbWl0dGVkLmxlbmd0aCA8IHNoYXJlZDtcblx0Y29uc3QgY29tbWl0dGVkTWF0Y2hlcyA9IGlzVGVybWluYWwgJiYgY29tbWl0dGVkLmxlbmd0aCA9PT0gc2hhcmVkID8gY2FuZGlkYXRlcyA6IGNvbW1pdHRlZDtcblx0bGV0IHByZXNlbnRlZCA9IG5lZWRzQ2xpZW50TG9hZCA/IGNhbmRpZGF0ZXMgOiBjb21taXR0ZWRNYXRjaGVzO1xuXHRsZXQgZGF0YU9ubHlBc3NldEVuZDtcblx0aWYgKG5lZWRzQ2xpZW50TG9hZCAmJiBwZW5kaW5nQm91bmRhcnkgIT09IHZvaWQgMCkge1xuXHRcdGNvbnN0IGJvdW5kYXJ5ID0gcHJlc2VudGVkW3BlbmRpbmdCb3VuZGFyeV07XG5cdFx0ZGF0YU9ubHlBc3NldEVuZCA9IGJvdW5kYXJ5LnNzciA9PT0gXCJkYXRhLW9ubHlcIiAmJiB2ZXJpZmllZEFzc2V0RW5kID4gcGVuZGluZ0JvdW5kYXJ5ICsgMSA/IHZlcmlmaWVkQXNzZXRFbmQgOiB2b2lkIDA7XG5cdFx0cHJlc2VudGVkID0gcHJlc2VudGVkLnNsaWNlKCk7XG5cdFx0cHJlc2VudGVkW3BlbmRpbmdCb3VuZGFyeV0gPSB7XG5cdFx0XHQuLi5ib3VuZGFyeSxcblx0XHRcdHN0YXR1czogXCJwZW5kaW5nXCIsXG5cdFx0XHRzc3I6IGJvdW5kYXJ5LnNzciA9PT0gXCJkYXRhLW9ubHlcIiA/IFwiZGF0YS1vbmx5XCIgOiBmYWxzZSxcblx0XHRcdF9hc3NldEVuZDogZGF0YU9ubHlBc3NldEVuZFxuXHRcdH07XG5cdH1cblx0Y29uc3QgY2xhaW0gPSAoKSA9PiB7XG5cdFx0Y29uc3QgaGlzdG9yeUxvY2F0aW9uID0gcm91dGVyLmhpc3RvcnkubG9jYXRpb247XG5cdFx0cmV0dXJuIG5lZWRzQ2xpZW50TG9hZCAmJiAhcm91dGVyLl90eCAmJiBoaXN0b3J5TG9jYXRpb24uaHJlZiA9PT0gaGFuZG9mZkhpc3RvcnlIcmVmICYmIGhpc3RvcnlMb2NhdGlvbi5zdGF0ZSA9PT0gaGFuZG9mZkhpc3RvcnlTdGF0ZSAmJiByb3V0ZXIuX2NvbW1pdHRlZCA9PT0gY29tbWl0dGVkTWF0Y2hlcyAmJiBjb21taXR0ZWRNYXRjaGVzLmxlbmd0aCAmJiAhY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCA/IGNvbnRyb2xsZXIgOiB2b2lkIDA7XG5cdH07XG5cdGNvbnN0IGhhbmRvZmYgPSBbY2xhaW0sIChtYXRjaGVzKSA9PiB7XG5cdFx0aWYgKHJvdXRlci5faGFuZG9mZiAhPT0gaGFuZG9mZikgcmV0dXJuO1xuXHRcdHJvdXRlci5faGFuZG9mZiA9IHZvaWQgMDtcblx0XHRjb25zdCBwcmVmaXggPSBjb21taXR0ZWRNYXRjaGVzLmxlbmd0aDtcblx0XHRpZiAoIW1hdGNoZXMgfHwgIWNsYWltKCkgfHwgY29tbWl0dGVkTWF0Y2hlcy5zb21lKChtYXRjaCwgaW5kZXgpID0+IG1hdGNoLmlkICE9PSBtYXRjaGVzW2luZGV4XT8uaWQpKSB7XG5cdFx0XHRjb250cm9sbGVyLmFib3J0KCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGxldCBoYW5kb2ZmQXNzZXRFbmQgPSBkYXRhT25seUFzc2V0RW5kO1xuXHRcdGlmIChoYW5kb2ZmQXNzZXRFbmQgIT09IHZvaWQgMCkge1xuXHRcdFx0Zm9yIChsZXQgaW5kZXggPSBwcmVmaXg7IGluZGV4IDwgaGFuZG9mZkFzc2V0RW5kOyBpbmRleCsrKSBpZiAoY2FuZGlkYXRlc1tpbmRleF0/LmlkICE9PSBtYXRjaGVzW2luZGV4XT8uaWQpIHtcblx0XHRcdFx0aGFuZG9mZkFzc2V0RW5kID0gaW5kZXggPiBwZW5kaW5nQm91bmRhcnkgKyAxID8gaW5kZXggOiB2b2lkIDA7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0fVxuXHRcdH1cblx0XHRjb25zdCBjbG9uZXMgPSBjb21taXR0ZWRNYXRjaGVzLm1hcCgobWF0Y2gpID0+ICh7IC4uLm1hdGNoIH0pKTtcblx0XHRpZiAoaGFuZG9mZkFzc2V0RW5kICE9PSB2b2lkIDApIGNsb25lc1twZW5kaW5nQm91bmRhcnldLl9hc3NldEVuZCA9IGhhbmRvZmZBc3NldEVuZDtcblx0XHR0cmFuc2Zlck1hdGNoUmVzb3VyY2VzKHJvdXRlciwgbWF0Y2hlcy5zcGxpY2UoMCwgcHJlZml4LCAuLi5jbG9uZXMpKTtcblx0XHRmb3IgKGxldCBpbmRleCA9IHByZWZpeDsgaW5kZXggPCBtYXRjaGVzLmxlbmd0aDsgaW5kZXgrKykge1xuXHRcdFx0Y29uc3QgbWF0Y2ggPSBtYXRjaGVzW2luZGV4XTtcblx0XHRcdGNvbnN0IGh5ZHJhdGVkID0gY2FuZGlkYXRlc1tpbmRleF07XG5cdFx0XHRpZiAoaHlkcmF0ZWQ/LmlkID09PSBtYXRjaC5pZCAmJiBoeWRyYXRlZC5fY3R4KSBtYXRjaC5fY3R4ID0gaHlkcmF0ZWQuX2N0eDtcblx0XHRcdG1hdGNoLmFib3J0Q29udHJvbGxlciA9IGNvbnRyb2xsZXI7XG5cdFx0fVxuXHRcdHJldHVybiBwcmVmaXg7XG5cdH1dO1xuXHRyb3V0ZXIuX2NvbW1pdHRlZCA9IGNvbW1pdHRlZE1hdGNoZXM7XG5cdHJvdXRlci5fbGlmZWN5Y2xlRW5kID0gbGlmZWN5Y2xlRW5kKGNvbW1pdHRlZE1hdGNoZXMpO1xuXHRyb3V0ZXIuX2hhbmRvZmYgPSBoYW5kb2ZmO1xuXHRyb3V0ZXIuX3ByZWZsaWdodCA9IHZvaWQgMDtcblx0cm91dGVyLmJhdGNoKCgpID0+IHtcblx0XHRyb3V0ZXIuc3RvcmVzLnNldE1hdGNoZXMocHJlc2VudGVkKTtcblx0XHRyb3V0ZXIuc3RvcmVzLnN0YXR1cy5zZXQoXCJpZGxlXCIpO1xuXHRcdGlmICghbmVlZHNDbGllbnRMb2FkKSByb3V0ZXIuc3RvcmVzLnJlc29sdmVkTG9jYXRpb24uc2V0KHJvdXRlci5zdG9yZXMubG9jYXRpb24uZ2V0KCkpO1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgX2dldEFzc2V0TWF0Y2hlcywgX2dldFJlbmRlcmVkTWF0Y2hlcywgX2lzUm91dGVEZXBhcnRpbmcsIGNhY2hlTG9hZGVyTWF0Y2gsIGNvbW1pdE1hdGNoZXMsIGdldFJvdXRlLCBoeWRyYXRlLCBsb2FkQ2xpZW50Um91dGUsIGxvYWRSb3V0ZUNodW5rLCBwcmVsb2FkQ2xpZW50Um91dGUsIHByb2plY3RMYW5lLCByZWZyZXNoQ2xpZW50Um91dGUsIHJlcGxhY2VSb3V0ZUNodW5rLCB3YWl0Rm9yIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWxvYWQtY2xpZW50LmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvYXdhaXQtc2lnbmFsLnRzXG5mdW5jdGlvbiBvYnNlcnZlTGF0ZShjYWxsYmFjaywgdmFsdWUpIHtcblx0aWYgKCFjYWxsYmFjaykgcmV0dXJuO1xuXHR0cnkge1xuXHRcdGNvbnN0IHJlc3VsdCA9IGNhbGxiYWNrKHZhbHVlKTtcblx0XHRpZiAocmVzdWx0ICE9PSB2b2lkIDApIFByb21pc2UucmVzb2x2ZShyZXN1bHQpLmNhdGNoKCgpID0+IHt9KTtcblx0fSBjYXRjaCB7fVxufVxuLyoqXG4qIEF3YWl0IGB2YWx1ZWAgdW5sZXNzIGBzaWduYWxgIGFib3J0cyBmaXJzdC4gQSByZXN1bHQgdGhhdCBzZXR0bGVzIGFmdGVyIHRoZVxuKiBhYm9ydCBpcyBwYXNzZWQgdG8gYG9uTGF0ZWAgLyBgb25MYXRlRXJyb3JgIGluc3RlYWQuXG4qXG4qIE9uZSBhYm9ydCBsaXN0ZW5lciBwZXIgd2FpdDogU1NSIHJlcXVlc3RzIG5lc3QgYXQgbW9zdCBhIGZldyB3YWl0cyBvbiBvbmVcbiogc2lnbmFsLCBzbyBwb29saW5nIHRoZW0gd2FzIG1lYXN1cmFibHkgc2xvd2VyIHRoYW4gdGhpcy5cbiovXG5mdW5jdGlvbiB3YWl0Rm9yUmVhc29uKHZhbHVlLCBzaWduYWwsIG9uTGF0ZSwgb25MYXRlRXJyb3IpIHtcblx0Y29uc3QgcHJvbWlzZSA9IFByb21pc2UucmVzb2x2ZSh2YWx1ZSk7XG5cdGlmIChzaWduYWwuYWJvcnRlZCkge1xuXHRcdHByb21pc2UudGhlbigocmVzdWx0KSA9PiBvYnNlcnZlTGF0ZShvbkxhdGUsIHJlc3VsdCksIChlcnJvcikgPT4gb2JzZXJ2ZUxhdGUob25MYXRlRXJyb3IsIGVycm9yKSk7XG5cdFx0cmV0dXJuIFByb21pc2UucmVqZWN0KHNpZ25hbC5yZWFzb24pO1xuXHR9XG5cdHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0Y29uc3QgYWJvcnQgPSAoKSA9PiByZWplY3Qoc2lnbmFsLnJlYXNvbik7XG5cdFx0c2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBhYm9ydCwgeyBvbmNlOiB0cnVlIH0pO1xuXHRcdHByb21pc2UudGhlbigocmVzdWx0KSA9PiB7XG5cdFx0XHRzaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIGFib3J0KTtcblx0XHRcdGlmIChzaWduYWwuYWJvcnRlZCkgb2JzZXJ2ZUxhdGUob25MYXRlLCByZXN1bHQpO1xuXHRcdFx0ZWxzZSByZXNvbHZlKHJlc3VsdCk7XG5cdFx0fSwgKGVycm9yKSA9PiB7XG5cdFx0XHRzaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIGFib3J0KTtcblx0XHRcdGlmIChzaWduYWwuYWJvcnRlZCkgb2JzZXJ2ZUxhdGUob25MYXRlRXJyb3IsIGVycm9yKTtcblx0XHRcdGVsc2UgcmVqZWN0KGVycm9yKTtcblx0XHR9KTtcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHdhaXRGb3JSZWFzb24gfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YXdhaXQtc2lnbmFsLmpzLm1hcCIsImltcG9ydCB7IGlzTm90Rm91bmQgfSBmcm9tIFwiLi9ub3QtZm91bmQuanNcIjtcbmltcG9ydCB7IHJvb3RSb3V0ZUlkIH0gZnJvbSBcIi4vcm9vdC5qc1wiO1xuaW1wb3J0IHsgaXNSZWRpcmVjdCwgcmVkaXJlY3QgfSBmcm9tIFwiLi9yZWRpcmVjdC5qc1wiO1xuaW1wb3J0IHsgbG9hZFJvdXRlQ2h1bmsgfSBmcm9tIFwiLi9sb2FkLWNsaWVudC5qc1wiO1xuaW1wb3J0IHsgZ2V0TG9jYXRpb25DaGFuZ2VJbmZvLCBsaWZlY3ljbGVFbmQsIHJ1blJvdXRlTGlmZWN5Y2xlIH0gZnJvbSBcIi4vcm91dGVyLmpzXCI7XG5pbXBvcnQgeyB3YWl0Rm9yUmVhc29uIH0gZnJvbSBcIi4vYXdhaXQtc2lnbmFsLmpzXCI7XG4vLyNyZWdpb24gc3JjL2xvYWQtc2VydmVyLnRzXG5jb25zdCBTVUNDRVNTID0gMDtcbmNvbnN0IEVSUk9SID0gMTtcbmNvbnN0IE5PVF9GT1VORCA9IDI7XG5jb25zdCBSRURJUkVDVEVEID0gMztcbmNvbnN0IFNLSVBQRUQgPSA0O1xuY29uc3QgTUFUQ0hfU0VUVExFRF9BQk9SVF9SRUFTT04gPSBPYmplY3QuZnJlZXplKHtcblx0bmFtZTogXCJBYm9ydEVycm9yXCIsXG5cdG1lc3NhZ2U6IFwiVGFuU3RhY2sgUm91dGVyIGFib3J0ZWQgdGhpcyBzZXJ2ZXIgbWF0Y2ggYmVjYXVzZSBpdCBzZXR0bGVkLlwiXG59KTtcbmNvbnN0IFJFRElSRUNUX0FCT1JUX1JFQVNPTiA9IE9iamVjdC5mcmVlemUoe1xuXHRuYW1lOiBcIkFib3J0RXJyb3JcIixcblx0bWVzc2FnZTogXCJUYW5TdGFjayBSb3V0ZXIgYWJvcnRlZCB0aGlzIHNlcnZlciBtYXRjaCBiZWNhdXNlIG9mIGEgcmVkaXJlY3QuXCJcbn0pO1xuZnVuY3Rpb24gZ2V0Um91dGUocm91dGVyLCBtYXRjaCkge1xuXHRyZXR1cm4gcm91dGVyLnJvdXRlc0J5SWRbbWF0Y2gucm91dGVJZF07XG59XG5mdW5jdGlvbiBub3JtYWxpemUodmFsdWUsIHJlamVjdGVkKSB7XG5cdGlmIChpc1JlZGlyZWN0KHZhbHVlKSkgcmV0dXJuIFtSRURJUkVDVEVELCB2YWx1ZV07XG5cdGlmIChpc05vdEZvdW5kKHZhbHVlKSkgcmV0dXJuIFtOT1RfRk9VTkQsIHZhbHVlXTtcblx0aWYgKHJlamVjdGVkICYmIHR5cGVvZiB2YWx1ZT8udGhlbiA9PT0gXCJmdW5jdGlvblwiKSB2YWx1ZSA9IG5ldyBFcnJvcihcIkEgUHJvbWlzZSB3YXMgdGhyb3duXCIsIHsgY2F1c2U6IHZhbHVlIH0pO1xuXHRyZXR1cm4gcmVqZWN0ZWQgPyBbRVJST1IsIHZhbHVlXSA6IFtTVUNDRVNTLCB2YWx1ZV07XG59XG5mdW5jdGlvbiBub3JtYWxpemVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCBjYXVzZSwgc2lnbmFsLCBub3RpZnkgPSB0cnVlKSB7XG5cdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0bGV0IG91dGNvbWUgPSBub3JtYWxpemUoY2F1c2UsIHRydWUpO1xuXHRpZiAob3V0Y29tZVswXSAhPT0gRVJST1IpIHJldHVybiBtYXRlcmlhbGl6ZVJlZGlyZWN0KHJvdXRlciwgbGFuZSwgcm91dGUsIG91dGNvbWUsIHNpZ25hbCwgbm90aWZ5KTtcblx0dHJ5IHtcblx0XHRyb3V0ZS5vcHRpb25zLm9uRXJyb3I/LihvdXRjb21lWzFdKTtcblx0fSBjYXRjaCAob25FcnJvckNhdXNlKSB7XG5cdFx0b3V0Y29tZSA9IG5vcm1hbGl6ZShvbkVycm9yQ2F1c2UsIHRydWUpO1xuXHR9XG5cdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0cmV0dXJuIG1hdGVyaWFsaXplUmVkaXJlY3Qocm91dGVyLCBsYW5lLCByb3V0ZSwgb3V0Y29tZSwgc2lnbmFsLCBub3RpZnkpO1xufVxuZnVuY3Rpb24gbWF0ZXJpYWxpemVSZWRpcmVjdChyb3V0ZXIsIGxhbmUsIHJvdXRlLCBvdXRjb21lLCBzaWduYWwsIG5vdGlmeSA9IHRydWUpIHtcblx0aWYgKG91dGNvbWVbMF0gIT09IFJFRElSRUNURUQpIHJldHVybiBvdXRjb21lO1xuXHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdHRyeSB7XG5cdFx0b3V0Y29tZVsxXS5vcHRpb25zLl9mcm9tTG9jYXRpb24gPSBsYW5lLmxvY2F0aW9uO1xuXHRcdHJvdXRlci5yZXNvbHZlUmVkaXJlY3Qob3V0Y29tZVsxXSk7XG5cdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdHJldHVybiBvdXRjb21lO1xuXHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRyZXR1cm4gbm90aWZ5ID8gbm9ybWFsaXplRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIHNpZ25hbCwgZmFsc2UpIDogW0VSUk9SLCBjYXVzZV07XG5cdH1cbn1cbmZ1bmN0aW9uIG1heWJlKHZhbHVlLCBjYXVzZSkge1xuXHRpZiAoY2F1c2UgIT09IHZvaWQgMCkgcmV0dXJuIHtcblx0XHRzdGF0dXM6IFwiZXJyb3JcIixcblx0XHRlcnJvcjogY2F1c2Vcblx0fTtcblx0cmV0dXJuIHtcblx0XHRzdGF0dXM6IFwic3VjY2Vzc1wiLFxuXHRcdHZhbHVlXG5cdH07XG59XG5mdW5jdGlvbiBuYXZpZ2F0ZUZyb20ocm91dGVyLCBsb2NhdGlvbikge1xuXHRyZXR1cm4gKG9wdGlvbnMpID0+IHJvdXRlci5uYXZpZ2F0ZSh7XG5cdFx0Li4ub3B0aW9ucyxcblx0XHRfZnJvbUxvY2F0aW9uOiBsb2NhdGlvblxuXHR9KTtcbn1cbmZ1bmN0aW9uIHdhaXRGb3IodmFsdWUsIHNpZ25hbCkge1xuXHRyZXR1cm4gc2lnbmFsID8gd2FpdEZvclJlYXNvbih2YWx1ZSwgc2lnbmFsKSA6IHZhbHVlO1xufVxuZnVuY3Rpb24gcmVzb2x2ZVNzcihyb3V0ZXIsIGxhbmUsIGluZGV4KSB7XG5cdGNvbnN0IG1hdGNoID0gbGFuZS5tYXRjaGVzW2luZGV4XTtcblx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKTtcblx0Y29uc3QgcGFyZW50U3NyID0gbGFuZS5tYXRjaGVzW2luZGV4IC0gMV0/LnNzcjtcblx0aWYgKHJvdXRlci5pc1NoZWxsKCkpIHJldHVybiByb3V0ZS5pZCA9PT0gcm9vdFJvdXRlSWQ7XG5cdGlmIChwYXJlbnRTc3IgPT09IGZhbHNlKSByZXR1cm4gZmFsc2U7XG5cdGNvbnN0IGluaGVyaXQgPSAodmFsdWUpID0+IHtcblx0XHRyZXR1cm4gdmFsdWUgPT09IHRydWUgJiYgcGFyZW50U3NyID09PSBcImRhdGEtb25seVwiID8gXCJkYXRhLW9ubHlcIiA6IHZhbHVlO1xuXHR9O1xuXHRjb25zdCBkZWZhdWx0U3NyID0gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFNzciA/PyB0cnVlO1xuXHRjb25zdCBpbmhlcml0ZWREZWZhdWx0ID0gaW5oZXJpdChkZWZhdWx0U3NyKTtcblx0bWF0Y2guc3NyID0gaW5oZXJpdGVkRGVmYXVsdDtcblx0Y29uc3Qgb3B0aW9uID0gcm91dGUub3B0aW9ucy5zc3I7XG5cdGlmIChvcHRpb24gPT09IHZvaWQgMCkgcmV0dXJuIGluaGVyaXRlZERlZmF1bHQ7XG5cdGlmICh0eXBlb2Ygb3B0aW9uICE9PSBcImZ1bmN0aW9uXCIpIHJldHVybiBpbmhlcml0KG9wdGlvbik7XG5cdGNvbnN0IGNvbnRleHQgPSB7XG5cdFx0c2VhcmNoOiBtYXliZShtYXRjaC5zZWFyY2gsIG1hdGNoLnNlYXJjaEVycm9yKSxcblx0XHRwYXJhbXM6IG1heWJlKG1hdGNoLnBhcmFtcywgbWF0Y2gucGFyYW1zRXJyb3IpLFxuXHRcdGxvY2F0aW9uOiBsYW5lLmxvY2F0aW9uLFxuXHRcdG1hdGNoZXM6IGxhbmUubWF0Y2hlcy5tYXAoKGNhbmRpZGF0ZSkgPT4gKHtcblx0XHRcdGluZGV4OiBjYW5kaWRhdGUuaW5kZXgsXG5cdFx0XHRwYXRobmFtZTogY2FuZGlkYXRlLnBhdGhuYW1lLFxuXHRcdFx0ZnVsbFBhdGg6IGNhbmRpZGF0ZS5mdWxsUGF0aCxcblx0XHRcdHN0YXRpY0RhdGE6IGNhbmRpZGF0ZS5zdGF0aWNEYXRhLFxuXHRcdFx0aWQ6IGNhbmRpZGF0ZS5pZCxcblx0XHRcdHJvdXRlSWQ6IGNhbmRpZGF0ZS5yb3V0ZUlkLFxuXHRcdFx0c2VhcmNoOiBtYXliZShjYW5kaWRhdGUuc2VhcmNoLCBjYW5kaWRhdGUuc2VhcmNoRXJyb3IpLFxuXHRcdFx0cGFyYW1zOiBtYXliZShjYW5kaWRhdGUucGFyYW1zLCBjYW5kaWRhdGUucGFyYW1zRXJyb3IpLFxuXHRcdFx0c3NyOiBjYW5kaWRhdGUuc3NyXG5cdFx0fSkpXG5cdH07XG5cdHRyeSB7XG5cdFx0cmV0dXJuIFByb21pc2UucmVzb2x2ZShvcHRpb24oY29udGV4dCkpLnRoZW4oKHZhbHVlKSA9PiBpbmhlcml0KHZhbHVlID8/IGRlZmF1bHRTc3IpKTtcblx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRyZXR1cm4gUHJvbWlzZS5yZWplY3QoY2F1c2UpO1xuXHR9XG59XG5mdW5jdGlvbiBzdGFtcE5vdEZvdW5kKG1hdGNoLCBvdXRjb21lKSB7XG5cdGlmIChvdXRjb21lWzBdID09PSBOT1RfRk9VTkQgJiYgIW91dGNvbWVbMV0ucm91dGVJZCkgb3V0Y29tZVsxXS5yb3V0ZUlkID0gbWF0Y2gucm91dGVJZDtcblx0cmV0dXJuIG91dGNvbWU7XG59XG5hc3luYyBmdW5jdGlvbiBjb250ZXh0dWFsaXplKHJvdXRlciwgbGFuZSwgc2lnbmFsKSB7XG5cdGNvbnN0IGdsb2JhbEJvdW5kYXJ5ID0gbGFuZS5tYXRjaGVzLmZpbmRJbmRleCgobWF0Y2gpID0+IG1hdGNoLl9ub3RGb3VuZCk7XG5cdGxldCBlbmQgPSBnbG9iYWxCb3VuZGFyeSA8IDAgPyBsYW5lLm1hdGNoZXMubGVuZ3RoIDogZ2xvYmFsQm91bmRhcnkgKyAxO1xuXHRsZXQgZmFpbHVyZTtcblx0bGV0IHBhcmVudENvbnRleHQgPSB7IC4uLnJvdXRlci5vcHRpb25zLmNvbnRleHQgPz8ge30gfTtcblx0Zm9yIChsZXQgaW5kZXggPSAwOyBpbmRleCA8IGVuZDsgaW5kZXgrKykge1xuXHRcdGNvbnN0IG1hdGNoID0gbGFuZS5tYXRjaGVzW2luZGV4XTtcblx0XHRjb25zdCByb3V0ZSA9IGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpO1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBzc3IgPSByZXNvbHZlU3NyKHJvdXRlciwgbGFuZSwgaW5kZXgpO1xuXHRcdFx0bWF0Y2guc3NyID0gc3NyIGluc3RhbmNlb2YgUHJvbWlzZSA/IGF3YWl0IHNzciA6IHNzcjtcblx0XHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdFx0ZmFpbHVyZSA9IFtpbmRleCwgc3RhbXBOb3RGb3VuZChtYXRjaCwgbm9ybWFsaXplRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIHNpZ25hbCkpXTtcblx0XHRcdGVuZCA9IGluZGV4O1xuXHRcdH1cblx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0aWYgKGZhaWx1cmU/LlsxXVswXSA9PT0gUkVESVJFQ1RFRCkgYnJlYWs7XG5cdFx0bWF0Y2guX19iZWZvcmVMb2FkQ29udGV4dCA9IHZvaWQgMDtcblx0XHRsZXQgY29udGV4dCA9IHBhcmVudENvbnRleHQ7XG5cdFx0dHJ5IHtcblx0XHRcdGxldCByb3V0ZUNvbnRleHQ7XG5cdFx0XHRpZiAocm91dGUub3B0aW9ucy5jb250ZXh0KSB7XG5cdFx0XHRcdGNvbnN0IHJvdXRlQ29udGV4dE9wdGlvbnMgPSB7XG5cdFx0XHRcdFx0ZGVwczogbWF0Y2gubG9hZGVyRGVwcyxcblx0XHRcdFx0XHRwYXJhbXM6IG1hdGNoLnBhcmFtcyxcblx0XHRcdFx0XHRjb250ZXh0OiBwYXJlbnRDb250ZXh0LFxuXHRcdFx0XHRcdGxvY2F0aW9uOiBsYW5lLmxvY2F0aW9uLFxuXHRcdFx0XHRcdG5hdmlnYXRlOiBuYXZpZ2F0ZUZyb20ocm91dGVyLCBsYW5lLmxvY2F0aW9uKSxcblx0XHRcdFx0XHRidWlsZExvY2F0aW9uOiByb3V0ZXIuYnVpbGRMb2NhdGlvbixcblx0XHRcdFx0XHRjYXVzZTogbWF0Y2guY2F1c2UsXG5cdFx0XHRcdFx0YWJvcnRDb250cm9sbGVyOiBtYXRjaC5hYm9ydENvbnRyb2xsZXIsXG5cdFx0XHRcdFx0cHJlbG9hZDogZmFsc2UsXG5cdFx0XHRcdFx0bWF0Y2hlczogbGFuZS5tYXRjaGVzLFxuXHRcdFx0XHRcdHJvdXRlSWQ6IHJvdXRlLmlkXG5cdFx0XHRcdH07XG5cdFx0XHRcdHJvdXRlQ29udGV4dCA9IHJvdXRlLm9wdGlvbnMuY29udGV4dChyb3V0ZUNvbnRleHRPcHRpb25zKSA/PyB2b2lkIDA7XG5cdFx0XHR9XG5cdFx0XHRjb250ZXh0ID0ge1xuXHRcdFx0XHQuLi5wYXJlbnRDb250ZXh0LFxuXHRcdFx0XHQuLi5yb3V0ZUNvbnRleHRcblx0XHRcdH07XG5cdFx0XHRtYXRjaC5jb250ZXh0ID0gY29udGV4dDtcblx0XHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdFx0aWYgKCFmYWlsdXJlKSBmYWlsdXJlID0gW2luZGV4LCBzdGFtcE5vdEZvdW5kKG1hdGNoLCBub3JtYWxpemVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCBjYXVzZSwgc2lnbmFsKSldO1xuXHRcdFx0ZW5kID0gaW5kZXg7XG5cdFx0XHRicmVhaztcblx0XHR9XG5cdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdGlmIChmYWlsdXJlKSBicmVhaztcblx0XHRjb25zdCB2YWxpZGF0aW9uRXJyb3IgPSBtYXRjaC5wYXJhbXNFcnJvciA/PyBtYXRjaC5zZWFyY2hFcnJvcjtcblx0XHRpZiAodmFsaWRhdGlvbkVycm9yICE9PSB2b2lkIDApIHtcblx0XHRcdGZhaWx1cmUgPSBbaW5kZXgsIHN0YW1wTm90Rm91bmQobWF0Y2gsIG5vcm1hbGl6ZUVycm9yKHJvdXRlciwgbGFuZSwgcm91dGUsIHZhbGlkYXRpb25FcnJvciwgc2lnbmFsKSldO1xuXHRcdFx0ZW5kID0gaW5kZXg7XG5cdFx0XHRicmVhaztcblx0XHR9XG5cdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdGlmIChtYXRjaC5zc3IgPT09IGZhbHNlIHx8ICFyb3V0ZS5vcHRpb25zLmJlZm9yZUxvYWQpIHtcblx0XHRcdHBhcmVudENvbnRleHQgPSBjb250ZXh0O1xuXHRcdFx0Y29udGludWU7XG5cdFx0fVxuXHRcdGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG1hdGNoLmFib3J0Q29udHJvbGxlcjtcblx0XHRjb25zdCBvcHRpb25zID0ge1xuXHRcdFx0c2VhcmNoOiBtYXRjaC5zZWFyY2gsXG5cdFx0XHRhYm9ydENvbnRyb2xsZXIsXG5cdFx0XHRwYXJhbXM6IG1hdGNoLnBhcmFtcyxcblx0XHRcdHByZWxvYWQ6IGZhbHNlLFxuXHRcdFx0Y29udGV4dCxcblx0XHRcdGxvY2F0aW9uOiBsYW5lLmxvY2F0aW9uLFxuXHRcdFx0bmF2aWdhdGU6IG5hdmlnYXRlRnJvbShyb3V0ZXIsIGxhbmUubG9jYXRpb24pLFxuXHRcdFx0YnVpbGRMb2NhdGlvbjogcm91dGVyLmJ1aWxkTG9jYXRpb24sXG5cdFx0XHRjYXVzZTogbWF0Y2guY2F1c2UsXG5cdFx0XHRtYXRjaGVzOiBsYW5lLm1hdGNoZXMsXG5cdFx0XHRyb3V0ZUlkOiByb3V0ZS5pZCxcblx0XHRcdC4uLnJvdXRlci5vcHRpb25zLmFkZGl0aW9uYWxDb250ZXh0XG5cdFx0fTtcblx0XHR0cnkge1xuXHRcdFx0Y29uc3QgYmVmb3JlTG9hZENvbnRleHQgPSBhd2FpdCByb3V0ZS5vcHRpb25zLmJlZm9yZUxvYWQob3B0aW9ucyk7XG5cdFx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0XHRjb25zdCBvdXRjb21lID0gc3RhbXBOb3RGb3VuZChtYXRjaCwgbWF0ZXJpYWxpemVSZWRpcmVjdChyb3V0ZXIsIGxhbmUsIHJvdXRlLCBub3JtYWxpemUoYmVmb3JlTG9hZENvbnRleHQsIGZhbHNlKSwgc2lnbmFsKSk7XG5cdFx0XHRpZiAob3V0Y29tZVswXSAhPT0gU1VDQ0VTUykge1xuXHRcdFx0XHRmYWlsdXJlID0gW2luZGV4LCBvdXRjb21lXTtcblx0XHRcdFx0ZW5kID0gaW5kZXg7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0fVxuXHRcdFx0bWF0Y2guX19iZWZvcmVMb2FkQ29udGV4dCA9IGJlZm9yZUxvYWRDb250ZXh0O1xuXHRcdFx0bWF0Y2guY29udGV4dCA9IHtcblx0XHRcdFx0Li4uY29udGV4dCxcblx0XHRcdFx0Li4uYmVmb3JlTG9hZENvbnRleHRcblx0XHRcdH07XG5cdFx0XHRwYXJlbnRDb250ZXh0ID0gbWF0Y2guY29udGV4dDtcblx0XHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdFx0ZmFpbHVyZSA9IFtpbmRleCwgc3RhbXBOb3RGb3VuZChtYXRjaCwgbm9ybWFsaXplRXJyb3Iocm91dGVyLCBsYW5lLCByb3V0ZSwgY2F1c2UsIHNpZ25hbCkpXTtcblx0XHRcdGVuZCA9IGluZGV4O1xuXHRcdFx0YnJlYWs7XG5cdFx0fVxuXHR9XG5cdHJldHVybiB7XG5cdFx0bG9jYXRpb246IGxhbmUubG9jYXRpb24sXG5cdFx0bWF0Y2hlczogbGFuZS5tYXRjaGVzLFxuXHRcdGVuZCxcblx0XHRmYWlsdXJlXG5cdH07XG59XG5mdW5jdGlvbiBnZXRMb2FkZXJDb250ZXh0KHJvdXRlciwgbGFuZSwgbWF0Y2gsIHJvdXRlLCBpbmRleCwgdGFza3MpIHtcblx0cmV0dXJuIHtcblx0XHRwYXJhbXM6IG1hdGNoLnBhcmFtcyxcblx0XHRkZXBzOiBtYXRjaC5sb2FkZXJEZXBzLFxuXHRcdHByZWxvYWQ6IGZhbHNlLFxuXHRcdHBhcmVudE1hdGNoUHJvbWlzZTogdGFza3NbaW5kZXggLSAxXT8ubWF0Y2gsXG5cdFx0YWJvcnRDb250cm9sbGVyOiBtYXRjaC5hYm9ydENvbnRyb2xsZXIsXG5cdFx0Y29udGV4dDogbWF0Y2guY29udGV4dCxcblx0XHRsb2NhdGlvbjogbGFuZS5sb2NhdGlvbixcblx0XHRuYXZpZ2F0ZTogbmF2aWdhdGVGcm9tKHJvdXRlciwgbGFuZS5sb2NhdGlvbiksXG5cdFx0Y2F1c2U6IG1hdGNoLmNhdXNlLFxuXHRcdHJvdXRlLFxuXHRcdC4uLnJvdXRlci5vcHRpb25zLmFkZGl0aW9uYWxDb250ZXh0XG5cdH07XG59XG5mdW5jdGlvbiBjcmVhdGVMb2FkZXJUYXNrKHJvdXRlciwgbGFuZSwgaW5kZXgsIHRhc2tzLCBzaWduYWwpIHtcblx0Y29uc3QgbWF0Y2ggPSBsYW5lLm1hdGNoZXNbaW5kZXhdO1xuXHRjb25zdCByb3V0ZSA9IGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpO1xuXHRsZXQgb3V0Y29tZTtcblx0aWYgKG1hdGNoLnNzciA9PT0gZmFsc2UpIG91dGNvbWUgPSBQcm9taXNlLnJlc29sdmUoW1NLSVBQRURdKTtcblx0ZWxzZSB7XG5cdFx0Y29uc3Qgcm91dGVMb2FkZXIgPSByb3V0ZS5vcHRpb25zLmxvYWRlcjtcblx0XHRjb25zdCBsb2FkZXIgPSB0eXBlb2Ygcm91dGVMb2FkZXIgPT09IFwiZnVuY3Rpb25cIiA/IHJvdXRlTG9hZGVyIDogcm91dGVMb2FkZXI/LmhhbmRsZXI7XG5cdFx0aWYgKCFsb2FkZXIpIG91dGNvbWUgPSBQcm9taXNlLnJlc29sdmUoW1NVQ0NFU1MsIHZvaWQgMF0pO1xuXHRcdGVsc2Ugb3V0Y29tZSA9IFByb21pc2UucmVzb2x2ZSgpLnRoZW4oKCkgPT4gbG9hZGVyKGdldExvYWRlckNvbnRleHQocm91dGVyLCBsYW5lLCBtYXRjaCwgcm91dGUsIGluZGV4LCB0YXNrcykpKS50aGVuKChyZXN1bHQpID0+IG5vcm1hbGl6ZShyZXN1bHQsIGZhbHNlKSwgKGNhdXNlKSA9PiBub3JtYWxpemUoY2F1c2UsIHRydWUpKS50aGVuKChyZXN1bHQpID0+IHtcblx0XHRcdGlmIChzaWduYWw/LmFib3J0ZWQgfHwgbWF0Y2guYWJvcnRDb250cm9sbGVyLnNpZ25hbC5yZWFzb24gPT09IFJFRElSRUNUX0FCT1JUX1JFQVNPTikgcmV0dXJuIFtTS0lQUEVEXTtcblx0XHRcdGlmIChyZXN1bHRbMF0gPT09IEVSUk9SKSByZXN1bHQgPSBub3JtYWxpemVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCByZXN1bHRbMV0sIHNpZ25hbCk7XG5cdFx0XHRlbHNlIHJlc3VsdCA9IG1hdGVyaWFsaXplUmVkaXJlY3Qocm91dGVyLCBsYW5lLCByb3V0ZSwgcmVzdWx0LCBzaWduYWwpO1xuXHRcdFx0cmV0dXJuIHN0YW1wTm90Rm91bmQobWF0Y2gsIHJlc3VsdCk7XG5cdFx0fSk7XG5cdH1cblx0Y29uc3QgcGFyZW50TWF0Y2ggPSBvdXRjb21lLnRoZW4oKHJlc3VsdCkgPT4ge1xuXHRcdGNvbnN0IHNuYXBzaG90ID0geyAuLi5tYXRjaCB9O1xuXHRcdGlmIChyZXN1bHRbMF0gPT09IFNVQ0NFU1MpIHtcblx0XHRcdHNuYXBzaG90LmxvYWRlckRhdGEgPSByZXN1bHRbMV07XG5cdFx0XHRzbmFwc2hvdC5zdGF0dXMgPSBcInN1Y2Nlc3NcIjtcblx0XHRcdHNuYXBzaG90LmVycm9yID0gdm9pZCAwO1xuXHRcdFx0c25hcHNob3QuaW52YWxpZCA9IGZhbHNlO1xuXHRcdFx0c25hcHNob3QuaXNGZXRjaGluZyA9IGZhbHNlO1xuXHRcdH0gZWxzZSBpZiAocmVzdWx0WzBdID09PSBFUlJPUikge1xuXHRcdFx0c25hcHNob3Quc3RhdHVzID0gXCJlcnJvclwiO1xuXHRcdFx0c25hcHNob3QuZXJyb3IgPSByZXN1bHRbMV07XG5cdFx0fSBlbHNlIGlmIChyZXN1bHRbMF0gPT09IE5PVF9GT1VORCkge1xuXHRcdFx0c25hcHNob3Quc3RhdHVzID0gXCJub3RGb3VuZFwiO1xuXHRcdFx0c25hcHNob3QuZXJyb3IgPSByZXN1bHRbMV07XG5cdFx0fVxuXHRcdHJldHVybiBzbmFwc2hvdDtcblx0fSk7XG5cdHJldHVybiB7XG5cdFx0aW5kZXgsXG5cdFx0b3V0Y29tZSxcblx0XHRtYXRjaDogcGFyZW50TWF0Y2hcblx0fTtcbn1cbmFzeW5jIGZ1bmN0aW9uIGdldE5vdEZvdW5kQm91bmRhcnkocm91dGVyLCBtYXRjaGVzLCBpbmRleGVkLCBzaWduYWwsIGZhbGxiYWNrID0gMCkge1xuXHRjb25zdCBjYXVzZSA9IGluZGV4ZWQ/LlsxXVsxXTtcblx0bGV0IGluZGV4ID0gY2F1c2U/LnJvdXRlSWQgPyBtYXRjaGVzLmZpbmRJbmRleCgobWF0Y2gpID0+IG1hdGNoLnJvdXRlSWQgPT09IGNhdXNlLnJvdXRlSWQpIDogaW5kZXhlZD8uWzBdID8/IG1hdGNoZXMubGVuZ3RoIC0gMTtcblx0aWYgKGluZGV4IDwgMCkgaW5kZXggPSAwO1xuXHRmb3IgKGxldCBjYW5kaWRhdGUgPSBpbmRleDsgY2FuZGlkYXRlID49IDA7IGNhbmRpZGF0ZS0tKSB7XG5cdFx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoZXNbY2FuZGlkYXRlXSk7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IGxvYWRpbmcgPSBsb2FkUm91dGVDaHVuayhyb3V0ZSwgZmFsc2UpO1xuXHRcdFx0aWYgKGxvYWRpbmcpIGF3YWl0IGxvYWRpbmc7XG5cdFx0fSBjYXRjaCB7XG5cdFx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0fVxuXHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRpZiAocm91dGUub3B0aW9ucy5ub3RGb3VuZENvbXBvbmVudCkgcmV0dXJuIGNhbmRpZGF0ZTtcblx0fVxuXHRyZXR1cm4gY2F1c2U/LnJvdXRlSWQgPyBpbmRleCA6IGZhbGxiYWNrO1xufVxuZnVuY3Rpb24gYWJvcnRNYXRjaGVzKG1hdGNoZXMsIHN0YXJ0ID0gMCwgcmVhc29uID0gTUFUQ0hfU0VUVExFRF9BQk9SVF9SRUFTT04pIHtcblx0Zm9yIChsZXQgaW5kZXggPSBzdGFydDsgaW5kZXggPCBtYXRjaGVzLmxlbmd0aDsgaW5kZXgrKykgbWF0Y2hlc1tpbmRleF0uYWJvcnRDb250cm9sbGVyLmFib3J0KHJlYXNvbik7XG59XG5hc3luYyBmdW5jdGlvbiBhcHBseUZhaWx1cmUocm91dGVyLCBsYW5lLCBpbmRleGVkLCBzaWduYWwpIHtcblx0aWYgKCFpbmRleGVkKSB7XG5cdFx0Y29uc3QgYm91bmRhcnkgPSBsYW5lLm1hdGNoZXMuZmluZEluZGV4KChtYXRjaCkgPT4gbWF0Y2guX25vdEZvdW5kKTtcblx0XHRpZiAoYm91bmRhcnkgPj0gMCkge1xuXHRcdFx0YWJvcnRNYXRjaGVzKGxhbmUubWF0Y2hlcywgYm91bmRhcnkgKyAxKTtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdHN0YXR1czogNDA0LFxuXHRcdFx0XHRib3VuZGFyeSxcblx0XHRcdFx0a2luZDogTk9UX0ZPVU5EXG5cdFx0XHR9O1xuXHRcdH1cblx0XHRyZXR1cm4geyBzdGF0dXM6IDIwMCB9O1xuXHR9XG5cdGNvbnN0IFtpbmRleCwgb3V0Y29tZV0gPSBpbmRleGVkO1xuXHRpZiAob3V0Y29tZVswXSA9PT0gRVJST1IpIHtcblx0XHRjb25zdCBtYXRjaCA9IGxhbmUubWF0Y2hlc1tpbmRleF07XG5cdFx0bWF0Y2guX25vdEZvdW5kID0gdm9pZCAwO1xuXHRcdG1hdGNoLnN0YXR1cyA9IFwiZXJyb3JcIjtcblx0XHRtYXRjaC5lcnJvciA9IG91dGNvbWVbMV07XG5cdFx0bWF0Y2guaXNGZXRjaGluZyA9IGZhbHNlO1xuXHRcdGFib3J0TWF0Y2hlcyhsYW5lLm1hdGNoZXMsIGluZGV4ICsgMSk7XG5cdFx0cmV0dXJuIHtcblx0XHRcdHN0YXR1czogNTAwLFxuXHRcdFx0Ym91bmRhcnk6IGluZGV4LFxuXHRcdFx0a2luZDogRVJST1Jcblx0XHR9O1xuXHR9XG5cdGNvbnN0IGJvdW5kYXJ5ID0gaW5kZXhlZFsyXSA/PyBhd2FpdCBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbGFuZS5tYXRjaGVzLCBpbmRleGVkLCBzaWduYWwpO1xuXHRjb25zdCBtYXRjaCA9IGxhbmUubWF0Y2hlc1tib3VuZGFyeV07XG5cdGNvbnN0IGNhdXNlID0gb3V0Y29tZVsxXTtcblx0Y2F1c2Uucm91dGVJZCA9IG1hdGNoLnJvdXRlSWQ7XG5cdG1hdGNoLl9ub3RGb3VuZCA9IHZvaWQgMDtcblx0aWYgKG1hdGNoLnJvdXRlSWQgPT09IHJvdXRlci5yb3V0ZVRyZWUuaWQpIHtcblx0XHRtYXRjaC5zdGF0dXMgPSBcInN1Y2Nlc3NcIjtcblx0XHRtYXRjaC5fbm90Rm91bmQgPSB0cnVlO1xuXHRcdG1hdGNoLmVycm9yID0gY2F1c2U7XG5cdH0gZWxzZSB7XG5cdFx0bWF0Y2guc3RhdHVzID0gXCJub3RGb3VuZFwiO1xuXHRcdG1hdGNoLmVycm9yID0gY2F1c2U7XG5cdH1cblx0bWF0Y2guaXNGZXRjaGluZyA9IGZhbHNlO1xuXHRhYm9ydE1hdGNoZXMobGFuZS5tYXRjaGVzLCBib3VuZGFyeSArIDEpO1xuXHRyZXR1cm4ge1xuXHRcdHN0YXR1czogNDA0LFxuXHRcdGJvdW5kYXJ5LFxuXHRcdGtpbmQ6IE5PVF9GT1VORFxuXHR9O1xufVxuYXN5bmMgZnVuY3Rpb24gbG9hZE5vcm1hbENodW5rcyhyb3V0ZXIsIGxhbmUsIGVuZCwgc2lnbmFsKSB7XG5cdGNvbnN0IGNodW5rcyA9IFtdO1xuXHRmb3IgKGxldCBpbmRleCA9IDA7IGluZGV4IDwgbGFuZS5tYXRjaGVzLmxlbmd0aDsgaW5kZXgrKykge1xuXHRcdGNvbnN0IG1hdGNoID0gbGFuZS5tYXRjaGVzW2luZGV4XTtcblx0XHRpZiAoaW5kZXggPj0gZW5kIHx8IG1hdGNoLnNzciAhPT0gdHJ1ZSB8fCBtYXRjaC5zdGF0dXMgIT09IFwic3VjY2Vzc1wiKSBjb250aW51ZTtcblx0XHRjb25zdCByb3V0ZSA9IGdldFJvdXRlKHJvdXRlciwgbWF0Y2gpO1xuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBsb2FkaW5nID0gbG9hZFJvdXRlQ2h1bmsocm91dGUpO1xuXHRcdFx0aWYgKGxvYWRpbmcpIHtcblx0XHRcdFx0Y29uc3QgY2h1bmsgPSBsb2FkaW5nLnRoZW4oKCkgPT4ge1xuXHRcdFx0XHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRcdFx0fSwgKGNhdXNlKSA9PiB7XG5cdFx0XHRcdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdFx0XHRcdHJldHVybiBbaW5kZXgsIHN0YW1wTm90Rm91bmQobWF0Y2gsIG5vcm1hbGl6ZUVycm9yKHJvdXRlciwgbGFuZSwgcm91dGUsIGNhdXNlLCBzaWduYWwpKV07XG5cdFx0XHRcdH0pO1xuXHRcdFx0XHRjaHVuay5jYXRjaCgoKSA9PiB7fSk7XG5cdFx0XHRcdGNodW5rcy5wdXNoKGNodW5rKTtcblx0XHRcdH1cblx0XHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdFx0Y2h1bmtzLnB1c2goW2luZGV4LCBzdGFtcE5vdEZvdW5kKG1hdGNoLCBub3JtYWxpemVFcnJvcihyb3V0ZXIsIGxhbmUsIHJvdXRlLCBjYXVzZSwgc2lnbmFsKSldKTtcblx0XHR9XG5cdH1cblx0Zm9yIChjb25zdCBjaHVuayBvZiBjaHVua3MpIHtcblx0XHRjb25zdCBpbmRleGVkID0gQXJyYXkuaXNBcnJheShjaHVuaykgPyBjaHVuayA6IGF3YWl0IGNodW5rO1xuXHRcdGlmIChpbmRleGVkKSByZXR1cm4gaW5kZXhlZDtcblx0fVxufVxuYXN5bmMgZnVuY3Rpb24gcHJvamVjdExhbmUocm91dGVyLCBsYW5lLCBzaWduYWwpIHtcblx0Zm9yIChjb25zdCBtYXRjaCBvZiBsYW5lLm1hdGNoZXMpIHtcblx0XHRjb25zdCByb3V0ZU9wdGlvbnMgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKS5vcHRpb25zO1xuXHRcdGlmIChyb3V0ZU9wdGlvbnMuaGVhZCB8fCByb3V0ZU9wdGlvbnMuc2NyaXB0cyB8fCByb3V0ZU9wdGlvbnMuaGVhZGVycykge1xuXHRcdFx0Y29uc3QgY29udGV4dCA9IHtcblx0XHRcdFx0c3NyOiByb3V0ZXIub3B0aW9ucy5zc3IsXG5cdFx0XHRcdG1hdGNoZXM6IGxhbmUubWF0Y2hlcyxcblx0XHRcdFx0bWF0Y2gsXG5cdFx0XHRcdHBhcmFtczogbWF0Y2gucGFyYW1zLFxuXHRcdFx0XHRsb2FkZXJEYXRhOiBtYXRjaC5sb2FkZXJEYXRhXG5cdFx0XHR9O1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3QgW2hlYWQsIHNjcmlwdHMsIGhlYWRlcnNdID0gYXdhaXQgUHJvbWlzZS5hbGwoW1xuXHRcdFx0XHRcdHJvdXRlT3B0aW9ucy5oZWFkPy4oY29udGV4dCksXG5cdFx0XHRcdFx0cm91dGVPcHRpb25zLnNjcmlwdHM/Lihjb250ZXh0KSxcblx0XHRcdFx0XHRyb3V0ZU9wdGlvbnMuaGVhZGVycz8uKGNvbnRleHQpXG5cdFx0XHRcdF0pO1xuXHRcdFx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0XHRcdG1hdGNoLm1ldGEgPSBoZWFkPy5tZXRhO1xuXHRcdFx0XHRtYXRjaC5saW5rcyA9IGhlYWQ/LmxpbmtzO1xuXHRcdFx0XHRtYXRjaC5oZWFkU2NyaXB0cyA9IGhlYWQ/LnNjcmlwdHM7XG5cdFx0XHRcdG1hdGNoLnN0eWxlcyA9IGhlYWQ/LnN0eWxlcztcblx0XHRcdFx0bWF0Y2guc2NyaXB0cyA9IHNjcmlwdHM7XG5cdFx0XHRcdG1hdGNoLmhlYWRlcnMgPSBoZWFkZXJzO1xuXHRcdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdFx0XHRjb25zb2xlLmVycm9yKGNhdXNlKTtcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYgKG1hdGNoLnNzciA9PT0gZmFsc2UgfHwgbWF0Y2guc3RhdHVzICE9PSBcInN1Y2Nlc3NcIiB8fCBtYXRjaC5fbm90Rm91bmQpIGJyZWFrO1xuXHR9XG59XG5hc3luYyBmdW5jdGlvbiBleGVjdXRlU2VydmVyTGFuZShyb3V0ZXIsIGxvY2F0aW9uLCBtYXRjaGVkTWF0Y2hlcywgc2lnbmFsKSB7XG5cdGNvbnN0IG1hdGNoZWQgPSB7XG5cdFx0bG9jYXRpb24sXG5cdFx0bWF0Y2hlczogbWF0Y2hlZE1hdGNoZXMubWFwKChtYXRjaCkgPT4gKHtcblx0XHRcdC4uLm1hdGNoLFxuXHRcdFx0X19iZWZvcmVMb2FkQ29udGV4dDogdm9pZCAwLFxuXHRcdFx0Y29udGV4dDoge30sXG5cdFx0XHRpc0ZldGNoaW5nOiBmYWxzZSxcblx0XHRcdGFib3J0Q29udHJvbGxlcjogbmV3IEFib3J0Q29udHJvbGxlcigpXG5cdFx0fSkpXG5cdH07XG5cdGNvbnN0IGFib3J0TGFuZSA9ICgpID0+IGFib3J0TWF0Y2hlcyhtYXRjaGVkLm1hdGNoZXMsIDAsIHNpZ25hbD8ucmVhc29uID8/IE1BVENIX1NFVFRMRURfQUJPUlRfUkVBU09OKTtcblx0aWYgKHNpZ25hbD8uYWJvcnRlZCkge1xuXHRcdGFib3J0TGFuZSgpO1xuXHRcdHNpZ25hbC50aHJvd0lmQWJvcnRlZCgpO1xuXHR9XG5cdHNpZ25hbD8uYWRkRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIGFib3J0TGFuZSwgeyBvbmNlOiB0cnVlIH0pO1xuXHR0cnkge1xuXHRcdGNvbnN0IHBsYW5uZWRHbG9iYWxCb3VuZGFyeSA9IG1hdGNoZWQubWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5fbm90Rm91bmQpO1xuXHRcdGlmIChyb3V0ZXIub3B0aW9ucy5ub3RGb3VuZE1vZGUgIT09IFwicm9vdFwiICYmIHBsYW5uZWRHbG9iYWxCb3VuZGFyeSA+PSAwKSB7XG5cdFx0XHRjb25zdCBib3VuZGFyeSA9IGF3YWl0IGdldE5vdEZvdW5kQm91bmRhcnkocm91dGVyLCBtYXRjaGVkLm1hdGNoZXMsIHZvaWQgMCwgc2lnbmFsLCBwbGFubmVkR2xvYmFsQm91bmRhcnkpO1xuXHRcdFx0aWYgKGJvdW5kYXJ5ICE9PSBwbGFubmVkR2xvYmFsQm91bmRhcnkpIHtcblx0XHRcdFx0bWF0Y2hlZC5tYXRjaGVzW3BsYW5uZWRHbG9iYWxCb3VuZGFyeV0uX25vdEZvdW5kID0gdm9pZCAwO1xuXHRcdFx0XHRtYXRjaGVkLm1hdGNoZXNbYm91bmRhcnldLl9ub3RGb3VuZCA9IHRydWU7XG5cdFx0XHR9XG5cdFx0fVxuXHRcdGNvbnN0IGxhbmUgPSBhd2FpdCBjb250ZXh0dWFsaXplKHJvdXRlciwgbWF0Y2hlZCwgc2lnbmFsKTtcblx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0bGV0IGxvYWRlckVuZCA9IGxhbmUuZW5kO1xuXHRcdGlmIChsYW5lLmZhaWx1cmU/LlsxXVswXSA9PT0gUkVESVJFQ1RFRCkgbG9hZGVyRW5kID0gMDtcblx0XHRlbHNlIGlmIChsYW5lLmZhaWx1cmU/LlsxXVswXSA9PT0gTk9UX0ZPVU5EKSB7XG5cdFx0XHRsYW5lLmZhaWx1cmVbMl0gPSBhd2FpdCBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbGFuZS5tYXRjaGVzLCBsYW5lLmZhaWx1cmUsIHNpZ25hbCk7XG5cdFx0XHRsb2FkZXJFbmQgPSBNYXRoLm1pbihsb2FkZXJFbmQsIGxhbmUuZmFpbHVyZVsyXSArIDEpO1xuXHRcdH1cblx0XHRjb25zdCB0YXNrcyA9IFtdO1xuXHRcdGZvciAobGV0IGluZGV4ID0gMDsgaW5kZXggPCBsb2FkZXJFbmQ7IGluZGV4KyspIHtcblx0XHRcdGNvbnN0IHRhc2sgPSBjcmVhdGVMb2FkZXJUYXNrKHJvdXRlciwgbGFuZSwgaW5kZXgsIHRhc2tzLCBzaWduYWwpO1xuXHRcdFx0dGFza3MucHVzaCh0YXNrKTtcblx0XHR9XG5cdFx0bGV0IGxvYWRlckZhaWx1cmU7XG5cdFx0bGV0IGNvbnRyb2wgPSBsYW5lLmZhaWx1cmU/LlsxXVswXSA9PT0gUkVESVJFQ1RFRCA/IGxhbmUuZmFpbHVyZSA6IHZvaWQgMDtcblx0XHR0cnkge1xuXHRcdFx0YXdhaXQgUHJvbWlzZS5hbGwodGFza3MubWFwKCh0YXNrKSA9PiB0YXNrLm91dGNvbWUudGhlbigobG9hZGVkT3V0Y29tZSkgPT4ge1xuXHRcdFx0XHRjb25zdCBtYXRjaCA9IGxhbmUubWF0Y2hlc1t0YXNrLmluZGV4XTtcblx0XHRcdFx0Y29uc3Qgb3V0Y29tZSA9IGxvYWRlZE91dGNvbWU7XG5cdFx0XHRcdGlmIChvdXRjb21lWzBdID09PSBTVUNDRVNTKSB7XG5cdFx0XHRcdFx0bWF0Y2gubG9hZGVyRGF0YSA9IG91dGNvbWVbMV07XG5cdFx0XHRcdFx0bWF0Y2guc3RhdHVzID0gXCJzdWNjZXNzXCI7XG5cdFx0XHRcdFx0bWF0Y2guZXJyb3IgPSB2b2lkIDA7XG5cdFx0XHRcdFx0bWF0Y2guaW52YWxpZCA9IGZhbHNlO1xuXHRcdFx0XHRcdG1hdGNoLmlzRmV0Y2hpbmcgPSBmYWxzZTtcblx0XHRcdFx0XHRtYXRjaC51cGRhdGVkQXQgPSBEYXRlLm5vdygpO1xuXHRcdFx0XHR9IGVsc2UgaWYgKG91dGNvbWVbMF0gPT09IFJFRElSRUNURUQpIHtcblx0XHRcdFx0XHRjb250cm9sID0gW3Rhc2suaW5kZXgsIG91dGNvbWVdO1xuXHRcdFx0XHRcdHRocm93IGNvbnRyb2w7XG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0aWYgKG1hdGNoLnNzciAhPT0gZmFsc2UpIHtcblx0XHRcdFx0XHRcdG1hdGNoLnN0YXR1cyA9IFwic3VjY2Vzc1wiO1xuXHRcdFx0XHRcdFx0bWF0Y2guZXJyb3IgPSB2b2lkIDA7XG5cdFx0XHRcdFx0XHRtYXRjaC5pbnZhbGlkID0gdHJ1ZTtcblx0XHRcdFx0XHRcdG1hdGNoLmlzRmV0Y2hpbmcgPSBmYWxzZTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKCFsb2FkZXJGYWlsdXJlICYmIG91dGNvbWVbMF0gIT09IFNLSVBQRUQpIGxvYWRlckZhaWx1cmUgPSBbdGFzay5pbmRleCwgb3V0Y29tZV07XG5cdFx0XHRcdH1cblx0XHRcdH0pKSk7XG5cdFx0fSBjYXRjaCAoY2F1c2UpIHtcblx0XHRcdGlmICghQXJyYXkuaXNBcnJheShjYXVzZSkpIHRocm93IGNhdXNlO1xuXHRcdFx0Y29udHJvbCA9IGNhdXNlO1xuXHRcdH1cblx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0aWYgKGNvbnRyb2w/LlsxXVswXSA9PT0gUkVESVJFQ1RFRCkge1xuXHRcdFx0YWJvcnRNYXRjaGVzKGxhbmUubWF0Y2hlcywgMCwgUkVESVJFQ1RfQUJPUlRfUkVBU09OKTtcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdHR5cGU6IFwicmVkaXJlY3RcIixcblx0XHRcdFx0cmVkaXJlY3Q6IGNvbnRyb2xbMV1bMV1cblx0XHRcdH07XG5cdFx0fVxuXHRcdGxldCBmYWlsdXJlID0gbGFuZS5mYWlsdXJlID8/IGxvYWRlckZhaWx1cmU7XG5cdFx0Y29uc3QgcGxhbm5lZEJvdW5kYXJ5ID0gbGFuZS5tYXRjaGVzLmZpbmRJbmRleCgobWF0Y2gpID0+IG1hdGNoLl9ub3RGb3VuZCk7XG5cdFx0bGV0IHJlYWRpbmVzc0VuZDtcblx0XHRpZiAoZmFpbHVyZSkge1xuXHRcdFx0Y29uc3Qgb3V0Y29tZUVuZCA9IGZhaWx1cmVbMl0gPz89IGZhaWx1cmVbMV1bMF0gPT09IE5PVF9GT1VORCA/IGF3YWl0IGdldE5vdEZvdW5kQm91bmRhcnkocm91dGVyLCBsYW5lLm1hdGNoZXMsIGZhaWx1cmUsIHNpZ25hbCkgOiBmYWlsdXJlWzBdO1xuXHRcdFx0Zm9yIChjb25zdCB0YXNrIG9mIHRhc2tzKSB7XG5cdFx0XHRcdGlmICh0YXNrLmluZGV4ID49IG91dGNvbWVFbmQpIGJyZWFrO1xuXHRcdFx0XHRjb25zdCBvdXRjb21lID0gYXdhaXQgdGFzay5vdXRjb21lO1xuXHRcdFx0XHRpZiAob3V0Y29tZVswXSAhPT0gU1VDQ0VTUyAmJiBvdXRjb21lWzBdIDwgUkVESVJFQ1RFRCAmJiAhKFwibG9hZGVyRGF0YVwiIGluIGxhbmUubWF0Y2hlc1t0YXNrLmluZGV4XSkpIHtcblx0XHRcdFx0XHRmYWlsdXJlID0gW3Rhc2suaW5kZXgsIG91dGNvbWVdO1xuXHRcdFx0XHRcdGZhaWx1cmVbMl0gPSBvdXRjb21lWzBdID09PSBOT1RfRk9VTkQgPyBhd2FpdCBnZXROb3RGb3VuZEJvdW5kYXJ5KHJvdXRlciwgbGFuZS5tYXRjaGVzLCBmYWlsdXJlLCBzaWduYWwpIDogdGFzay5pbmRleDtcblx0XHRcdFx0XHRicmVhaztcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0cmVhZGluZXNzRW5kID0gZmFpbHVyZVsyXTtcblx0XHR9IGVsc2UgcmVhZGluZXNzRW5kID0gcGxhbm5lZEJvdW5kYXJ5IDwgMCA/IGxhbmUubWF0Y2hlcy5sZW5ndGggOiBwbGFubmVkQm91bmRhcnk7XG5cdFx0Y29uc3QgcmVxdWlyZWRGYWlsdXJlID0gYXdhaXQgbG9hZE5vcm1hbENodW5rcyhyb3V0ZXIsIGxhbmUsIHJlYWRpbmVzc0VuZCwgc2lnbmFsKTtcblx0XHRzaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0aWYgKHJlcXVpcmVkRmFpbHVyZSkge1xuXHRcdFx0aWYgKHJlcXVpcmVkRmFpbHVyZVsxXVswXSA9PT0gUkVESVJFQ1RFRCkge1xuXHRcdFx0XHRhYm9ydE1hdGNoZXMobGFuZS5tYXRjaGVzLCAwLCBSRURJUkVDVF9BQk9SVF9SRUFTT04pO1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdHR5cGU6IFwicmVkaXJlY3RcIixcblx0XHRcdFx0XHRyZWRpcmVjdDogcmVxdWlyZWRGYWlsdXJlWzFdWzFdXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cdFx0XHRmYWlsdXJlID0gcmVxdWlyZWRGYWlsdXJlO1xuXHRcdH1cblx0XHRjb25zdCB0ZXJtaW5hbCA9IGF3YWl0IGFwcGx5RmFpbHVyZShyb3V0ZXIsIGxhbmUsIGZhaWx1cmUsIHNpZ25hbCk7XG5cdFx0aWYgKHRlcm1pbmFsLmJvdW5kYXJ5ICE9PSB2b2lkIDApIHtcblx0XHRcdGNvbnN0IG1hdGNoID0gbGFuZS5tYXRjaGVzW3Rlcm1pbmFsLmJvdW5kYXJ5XTtcblx0XHRcdGlmIChtYXRjaC5zc3IgPT09IHRydWUpIHtcblx0XHRcdFx0Y29uc3Qgcm91dGUgPSBnZXRSb3V0ZShyb3V0ZXIsIG1hdGNoKTtcblx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRpZiAodGVybWluYWwua2luZCA9PT0gRVJST1IpIGF3YWl0IGxvYWRSb3V0ZUNodW5rKHJvdXRlLCBcImVycm9yQ29tcG9uZW50XCIpO1xuXHRcdFx0XHRcdGVsc2UgaWYgKG1hdGNoLl9ub3RGb3VuZCkgYXdhaXQgUHJvbWlzZS5hbGwoW2xvYWRSb3V0ZUNodW5rKHJvdXRlKSwgbG9hZFJvdXRlQ2h1bmsocm91dGUsIFwibm90Rm91bmRDb21wb25lbnRcIildKTtcblx0XHRcdFx0XHRlbHNlIGF3YWl0IGxvYWRSb3V0ZUNodW5rKHJvdXRlLCBcIm5vdEZvdW5kQ29tcG9uZW50XCIpO1xuXHRcdFx0XHR9IGNhdGNoIHt9XG5cdFx0XHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRcdH1cblx0XHR9XG5cdFx0c2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdGF3YWl0IHByb2plY3RMYW5lKHJvdXRlciwge1xuXHRcdFx0bG9jYXRpb246IGxhbmUubG9jYXRpb24sXG5cdFx0XHRtYXRjaGVzOiBsYW5lLm1hdGNoZXNcblx0XHR9LCBzaWduYWwpO1xuXHRcdHNpZ25hbD8udGhyb3dJZkFib3J0ZWQoKTtcblx0XHRyb3V0ZXIuc2VydmVyU3NyPy5vbkNsZWFudXAoKHNldHRsZWQpID0+IHtcblx0XHRcdGlmICghc2V0dGxlZCkgYWJvcnRMYW5lKCk7XG5cdFx0fSk7XG5cdFx0cmV0dXJuIHtcblx0XHRcdHR5cGU6IFwicmVuZGVyXCIsXG5cdFx0XHRzdGF0dXM6IHRlcm1pbmFsLnN0YXR1cyxcblx0XHRcdG1hdGNoZXM6IGxhbmUubWF0Y2hlc1xuXHRcdH07XG5cdH0gZmluYWxseSB7XG5cdFx0c2lnbmFsPy5yZW1vdmVFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgYWJvcnRMYW5lKTtcblx0fVxufVxuYXN5bmMgZnVuY3Rpb24gbG9hZFNlcnZlclJvdXRlKHJvdXRlciwgb3B0cykge1xuXHRpZiAoIW9wdHM/Ll9za2lwTG9jYXRpb25VcGRhdGUpIHJvdXRlci51cGRhdGVMYXRlc3RMb2NhdGlvbigpO1xuXHRjb25zdCBuZXh0ID0gcm91dGVyLmxhdGVzdExvY2F0aW9uO1xuXHRjb25zdCBwcmV2aW91cyA9IHJvdXRlci5fY29tbWl0dGVkO1xuXHRjb25zdCBwcmV2aW91c0VuZCA9IHJvdXRlci5fbGlmZWN5Y2xlRW5kO1xuXHRsZXQgcmVzdWx0O1xuXHR0cnkge1xuXHRcdGNvbnN0IGNhbm9uaWNhbCA9IHJvdXRlci5idWlsZExvY2F0aW9uKHtcblx0XHRcdHRvOiBuZXh0LnBhdGhuYW1lLFxuXHRcdFx0c2VhcmNoOiB0cnVlLFxuXHRcdFx0cGFyYW1zOiB0cnVlLFxuXHRcdFx0aGFzaDogdHJ1ZSxcblx0XHRcdHN0YXRlOiB0cnVlLFxuXHRcdFx0X2luY2x1ZGVWYWxpZGF0ZVNlYXJjaDogdHJ1ZVxuXHRcdH0pO1xuXHRcdGlmIChuZXh0LnB1YmxpY0hyZWYgIT09IGNhbm9uaWNhbC5wdWJsaWNIcmVmKSB7XG5cdFx0XHRjb25zdCBocmVmID0gY2Fub25pY2FsLnB1YmxpY0hyZWYgfHwgXCIvXCI7XG5cdFx0XHR0aHJvdyByZWRpcmVjdCh7IGhyZWYgfSk7XG5cdFx0fVxuXHRcdGNvbnN0IGZyb21Mb2NhdGlvbiA9IHJvdXRlci5zdG9yZXMucmVzb2x2ZWRMb2NhdGlvbi5nZXQoKTtcblx0XHRjb25zdCBjaGFuZ2VJbmZvID0gZ2V0TG9jYXRpb25DaGFuZ2VJbmZvKG5leHQsIGZyb21Mb2NhdGlvbik7XG5cdFx0cm91dGVyLmVtaXQoe1xuXHRcdFx0dHlwZTogXCJvbkJlZm9yZU5hdmlnYXRlXCIsXG5cdFx0XHQuLi5jaGFuZ2VJbmZvXG5cdFx0fSk7XG5cdFx0cm91dGVyLmVtaXQoe1xuXHRcdFx0dHlwZTogXCJvbkJlZm9yZUxvYWRcIixcblx0XHRcdC4uLmNoYW5nZUluZm9cblx0XHR9KTtcblx0XHRvcHRzPy5fc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdHJlc3VsdCA9IGF3YWl0IHdhaXRGb3IoZXhlY3V0ZVNlcnZlckxhbmUocm91dGVyLCBuZXh0LCByb3V0ZXIubWF0Y2hSb3V0ZXMobmV4dCksIG9wdHM/Ll9zaWduYWwpLCBvcHRzPy5fc2lnbmFsKTtcblx0XHRvcHRzPy5fc2lnbmFsPy50aHJvd0lmQWJvcnRlZCgpO1xuXHR9IGNhdGNoIChjYXVzZSkge1xuXHRcdG9wdHM/Ll9zaWduYWw/LnRocm93SWZBYm9ydGVkKCk7XG5cdFx0aWYgKCFpc1JlZGlyZWN0KGNhdXNlKSkgdGhyb3cgY2F1c2U7XG5cdFx0Y2F1c2Uub3B0aW9ucy5fZnJvbUxvY2F0aW9uID0gbmV4dDtcblx0XHRyZXN1bHQgPSB7XG5cdFx0XHR0eXBlOiBcInJlZGlyZWN0XCIsXG5cdFx0XHRyZWRpcmVjdDogcm91dGVyLnJlc29sdmVSZWRpcmVjdChjYXVzZSlcblx0XHR9O1xuXHR9XG5cdHJvdXRlci5fc2VydmVyUmVzdWx0ID0gcmVzdWx0O1xuXHRsZXQgbmV4dEVuZCA9IDA7XG5cdHJvdXRlci5iYXRjaCgoKSA9PiB7XG5cdFx0cm91dGVyLnN0b3Jlcy5sb2NhdGlvbi5zZXQobmV4dCk7XG5cdFx0cm91dGVyLnN0b3Jlcy5zdGF0dXMuc2V0KFwiaWRsZVwiKTtcblx0XHRpZiAocmVzdWx0LnR5cGUgPT09IFwicmVuZGVyXCIpIHtcblx0XHRcdHJvdXRlci5fY29tbWl0dGVkID0gcmVzdWx0Lm1hdGNoZXM7XG5cdFx0XHRuZXh0RW5kID0gcm91dGVyLl9saWZlY3ljbGVFbmQgPSBsaWZlY3ljbGVFbmQocmVzdWx0Lm1hdGNoZXMpO1xuXHRcdFx0cm91dGVyLnN0b3Jlcy5zZXRNYXRjaGVzKHJlc3VsdC5tYXRjaGVzKTtcblx0XHRcdHJvdXRlci5zdG9yZXMucmVzb2x2ZWRMb2NhdGlvbi5zZXQobmV4dCk7XG5cdFx0fVxuXHR9KTtcblx0aWYgKHJlc3VsdC50eXBlID09PSBcInJlbmRlclwiKSBydW5Sb3V0ZUxpZmVjeWNsZShyb3V0ZXIsIHByZXZpb3VzLCByZXN1bHQubWF0Y2hlcywgcHJldmlvdXNFbmQsIG5leHRFbmQpO1xuXHRyb3V0ZXIuX2NvbW1pdFByb21pc2U/LnJlc29sdmUoKTtcblx0cm91dGVyLl9jb21taXRQcm9taXNlID0gdm9pZCAwO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBsb2FkU2VydmVyUm91dGUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bG9hZC1zZXJ2ZXIuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG4vKipcbiogUmVhY3QudXNlIGlmIGF2YWlsYWJsZSAoUmVhY3QgMTkrKSwgdW5kZWZpbmVkIG90aGVyd2lzZS5cbiogVXNlIGR5bmFtaWMgbG9va3VwIHRvIGF2b2lkIFdlYnBhY2sgY29tcGlsYXRpb24gZXJyb3JzIHdpdGggUmVhY3QgMTguXG4qL1xudmFyIHJlYWN0VXNlID0gUmVhY3QkMVtcInVzZVwiXTtcbnZhciB1c2VMYXlvdXRFZmZlY3QgPSBpc1NlcnZlciA/PyB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiID8gUmVhY3QkMS51c2VFZmZlY3QgOiBSZWFjdCQxLnVzZUxheW91dEVmZmVjdDtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgcmVhY3RVc2UsIHVzZUxheW91dEVmZmVjdCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11dGlscy5qcy5tYXAiLCJpbXBvcnQgeyBkZWZhdWx0U2VyaWFsaXplRXJyb3IgfSBmcm9tIFwiLi9yb3V0ZXIuanNcIjtcbi8vI3JlZ2lvbiBzcmMvZGVmZXIudHNcbi8qKlxuKiBXZWxsLWtub3duIHN5bWJvbCB1c2VkIGJ5IHtAbGluayBkZWZlcn0gdG8gdGFnIGEgcHJvbWlzZSB3aXRoXG4qIGl0cyBkZWZlcnJlZCBzdGF0ZS4gQ29uc3VtZXJzIGNhbiByZWFkIGBwcm9taXNlW1RTUl9ERUZFUlJFRF9QUk9NSVNFXWBcbiogdG8gYWNjZXNzIGBzdGF0dXNgLCBgZGF0YWAsIG9yIGBlcnJvcmAuXG4qL1xuY29uc3QgVFNSX0RFRkVSUkVEX1BST01JU0UgPSBTeW1ib2wuZm9yKFwiVFNSX0RFRkVSUkVEX1BST01JU0VcIik7XG4vKipcbiogV3JhcCBhIHByb21pc2Ugd2l0aCBhIGRlZmVycmVkIHN0YXRlIGZvciB1c2Ugd2l0aCBgPEF3YWl0PmAgYW5kIGB1c2VBd2FpdGVkYC5cbipcbiogVGhlIHJldHVybmVkIHByb21pc2UgaXMgYXVnbWVudGVkIHdpdGggaW50ZXJuYWwgc3RhdGUgKHN0YXR1cy9kYXRhL2Vycm9yKVxuKiBzbyBVSSBjYW4gcmVhZCBwcm9ncmVzcyBvciBzdXNwZW5kIHVudGlsIGl0IHNldHRsZXMuXG4qXG4qIEBwYXJhbSBfcHJvbWlzZSBUaGUgcHJvbWlzZSB0byB3cmFwLlxuKiBAcGFyYW0gb3B0aW9ucyBPcHRpb25hbCBjb25maWcuIFByb3ZpZGUgYHNlcmlhbGl6ZUVycm9yYCB0byBjdXN0b21pemUgaG93XG4qIGVycm9ycyBhcmUgc2VyaWFsaXplZCBmb3IgdHJhbnNmZXIuXG4qIEByZXR1cm5zIFRoZSBzYW1lIHByb21pc2Ugd2l0aCBhdHRhY2hlZCBkZWZlcnJlZCBtZXRhZGF0YS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2RlZmVyRnVuY3Rpb25cbiovXG5mdW5jdGlvbiBkZWZlcihfcHJvbWlzZSwgb3B0aW9ucykge1xuXHRjb25zdCBwcm9taXNlID0gX3Byb21pc2U7XG5cdGlmIChwcm9taXNlW1RTUl9ERUZFUlJFRF9QUk9NSVNFXSkgcmV0dXJuIHByb21pc2U7XG5cdHByb21pc2VbVFNSX0RFRkVSUkVEX1BST01JU0VdID0geyBzdGF0dXM6IFwicGVuZGluZ1wiIH07XG5cdHByb21pc2UudGhlbigoZGF0YSkgPT4ge1xuXHRcdHByb21pc2VbVFNSX0RFRkVSUkVEX1BST01JU0VdLnN0YXR1cyA9IFwic3VjY2Vzc1wiO1xuXHRcdHByb21pc2VbVFNSX0RFRkVSUkVEX1BST01JU0VdLmRhdGEgPSBkYXRhO1xuXHR9KS5jYXRjaCgoZXJyb3IpID0+IHtcblx0XHRwcm9taXNlW1RTUl9ERUZFUlJFRF9QUk9NSVNFXS5zdGF0dXMgPSBcImVycm9yXCI7XG5cdFx0cHJvbWlzZVtUU1JfREVGRVJSRURfUFJPTUlTRV0uZXJyb3IgPSB7XG5cdFx0XHRkYXRhOiAob3B0aW9ucz8uc2VyaWFsaXplRXJyb3IgPz8gZGVmYXVsdFNlcmlhbGl6ZUVycm9yKShlcnJvciksXG5cdFx0XHRfX2lzU2VydmVyRXJyb3I6IHRydWVcblx0XHR9O1xuXHR9KTtcblx0cmV0dXJuIHByb21pc2U7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFRTUl9ERUZFUlJFRF9QUk9NSVNFLCBkZWZlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1kZWZlci5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL2xpbmsudHNcbmNvbnN0IHByZWxvYWRXYXJuaW5nID0gXCJFcnJvciBwcmVsb2FkaW5nIHJvdXRlISDimJ3vuI9cIjtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgcHJlbG9hZFdhcm5pbmcgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bGluay5qcy5tYXAiLCIvLyNyZWdpb24gc3JjL21hbmlmZXN0LnRzXG5jb25zdCBERVZfU1RZTEVTX0FUVFIgPSBcImRhdGEtdGFuc3RhY2stcm91dGVyLWRldi1zdHlsZXNcIjtcbmZ1bmN0aW9uIGdldEFzc2V0Q3Jvc3NPcmlnaW4oYXNzZXRDcm9zc09yaWdpbiwga2luZCkge1xuXHRpZiAoIWFzc2V0Q3Jvc3NPcmlnaW4pIHJldHVybjtcblx0aWYgKHR5cGVvZiBhc3NldENyb3NzT3JpZ2luID09PSBcInN0cmluZ1wiKSByZXR1cm4gYXNzZXRDcm9zc09yaWdpbjtcblx0cmV0dXJuIGFzc2V0Q3Jvc3NPcmlnaW5ba2luZF07XG59XG5mdW5jdGlvbiBnZXRNYW5pZmVzdFNjcmlwdEZvcm1hdChtYW5pZmVzdCkge1xuXHRyZXR1cm4gbWFuaWZlc3Q/LnNjcmlwdEZvcm1hdCA/PyBcIm1vZHVsZVwiO1xufVxuZnVuY3Rpb24gZ2V0U2NyaXB0UHJlbG9hZEF0dHJzKG1hbmlmZXN0LCBsaW5rLCBhc3NldENyb3NzT3JpZ2luKSB7XG5cdGNvbnN0IHByZWxvYWRMaW5rID0gcmVzb2x2ZU1hbmlmZXN0QXNzZXRMaW5rKGxpbmspO1xuXHRjb25zdCBjcm9zc09yaWdpbiA9IGdldEFzc2V0Q3Jvc3NPcmlnaW4oYXNzZXRDcm9zc09yaWdpbiwgXCJzY3JpcHRcIikgPz8gcHJlbG9hZExpbmsuY3Jvc3NPcmlnaW47XG5cdHJldHVybiB7XG5cdFx0Li4uZ2V0TWFuaWZlc3RTY3JpcHRGb3JtYXQobWFuaWZlc3QpID09PSBcImlpZmVcIiA/IHtcblx0XHRcdHJlbDogXCJwcmVsb2FkXCIsXG5cdFx0XHRhczogXCJzY3JpcHRcIlxuXHRcdH0gOiB7IHJlbDogXCJtb2R1bGVwcmVsb2FkXCIgfSxcblx0XHRocmVmOiBwcmVsb2FkTGluay5ocmVmLFxuXHRcdGZldGNoUHJpb3JpdHk6IFwibG93XCIsXG5cdFx0Li4uY3Jvc3NPcmlnaW4gPyB7IGNyb3NzT3JpZ2luIH0gOiB7fVxuXHR9O1xufVxuZnVuY3Rpb24gcmVzb2x2ZU1hbmlmZXN0QXNzZXRMaW5rKGxpbmspIHtcblx0aWYgKHR5cGVvZiBsaW5rID09PSBcInN0cmluZ1wiKSByZXR1cm4ge1xuXHRcdGhyZWY6IGxpbmssXG5cdFx0Y3Jvc3NPcmlnaW46IHZvaWQgMFxuXHR9O1xuXHRyZXR1cm4gbGluaztcbn1cbmZ1bmN0aW9uIGFwcGVuZFVuaXF1ZVVzZXJUYWdzKHRhcmdldCwgdGFncykge1xuXHRpZiAodGFncy5sZW5ndGggPT09IDApIHJldHVybjtcblx0aWYgKHRhZ3MubGVuZ3RoID09PSAxKSB7XG5cdFx0dGFyZ2V0LnB1c2godGFnc1swXSk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdGNvbnN0IHNlZW4gPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRmb3IgKGNvbnN0IHRhZyBvZiB0YWdzKSB7XG5cdFx0Y29uc3Qga2V5ID0gSlNPTi5zdHJpbmdpZnkodGFnKTtcblx0XHRpZiAoc2Vlbi5oYXMoa2V5KSkgY29udGludWU7XG5cdFx0c2Vlbi5hZGQoa2V5KTtcblx0XHR0YXJnZXQucHVzaCh0YWcpO1xuXHR9XG59XG5mdW5jdGlvbiBnZXRTdHlsZXNoZWV0SHJlZihhc3NldCkge1xuXHRyZXR1cm4gcmVzb2x2ZU1hbmlmZXN0Q3NzTGluayhhc3NldCkuaHJlZjtcbn1cbmZ1bmN0aW9uIHJlc29sdmVNYW5pZmVzdENzc0xpbmsobGluaykge1xuXHRpZiAodHlwZW9mIGxpbmsgPT09IFwic3RyaW5nXCIpIHJldHVybiB7XG5cdFx0aHJlZjogbGluayxcblx0XHRjcm9zc09yaWdpbjogdm9pZCAwXG5cdH07XG5cdHJldHVybiBsaW5rO1xufVxuZnVuY3Rpb24gY3JlYXRlSW5saW5lQ3NzU3R5bGVBc3NldChjc3MpIHtcblx0cmV0dXJuIHtcblx0XHRhdHRyczogeyBzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWUgfSxcblx0XHRjaGlsZHJlbjogY3NzXG5cdH07XG59XG5mdW5jdGlvbiBjcmVhdGVJbmxpbmVDc3NQbGFjZWhvbGRlckFzc2V0KCkge1xuXHRyZXR1cm4geyBhdHRyczogeyBzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWUgfSB9O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBERVZfU1RZTEVTX0FUVFIsIGFwcGVuZFVuaXF1ZVVzZXJUYWdzLCBjcmVhdGVJbmxpbmVDc3NQbGFjZWhvbGRlckFzc2V0LCBjcmVhdGVJbmxpbmVDc3NTdHlsZUFzc2V0LCBnZXRBc3NldENyb3NzT3JpZ2luLCBnZXRNYW5pZmVzdFNjcmlwdEZvcm1hdCwgZ2V0U2NyaXB0UHJlbG9hZEF0dHJzLCBnZXRTdHlsZXNoZWV0SHJlZiwgcmVzb2x2ZU1hbmlmZXN0QXNzZXRMaW5rLCByZXNvbHZlTWFuaWZlc3RDc3NMaW5rIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW1hbmlmZXN0LmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvTWF0Y2hlcy50c1xuLyoqXG4qIE5hcnJvd3MgbWF0Y2hlcyBiYXNlZCBvbiBhIHBhdGhcbiogQGV4cGVyaW1lbnRhbFxuKi9cbmNvbnN0IGlzTWF0Y2ggPSAobWF0Y2gsIHBhdGgpID0+IHtcblx0Y29uc3QgcGFydHMgPSBwYXRoLnNwbGl0KFwiLlwiKTtcblx0bGV0IHBhcnQ7XG5cdGxldCBpID0gMDtcblx0bGV0IHZhbHVlID0gbWF0Y2g7XG5cdHdoaWxlICgocGFydCA9IHBhcnRzW2krK10pICE9IG51bGwgJiYgdmFsdWUgIT0gbnVsbCkgdmFsdWUgPSB2YWx1ZVtwYXJ0XTtcblx0cmV0dXJuIHZhbHVlICE9IG51bGw7XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBpc01hdGNoIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPU1hdGNoZXMuanMubWFwIiwiaW1wb3J0IHsgX2dldEFzc2V0TWF0Y2hlcyB9IGZyb20gXCIuLi9sb2FkLWNsaWVudC5qc1wiO1xuLy8jcmVnaW9uIHNyYy9zc3IvYm9keVNjcmlwdHMudHNcbmZ1bmN0aW9uIGdldFNzckJvZHlTY3JpcHRQYXJ0cyhtYXRjaGVzLCBtYW5pZmVzdCwgbm9uY2UsIHJvdXRlU2NyaXB0QXR0cnMpIHtcblx0Y29uc3QgYXNzZXRNYXRjaGVzID0gX2dldEFzc2V0TWF0Y2hlcyhtYXRjaGVzKTtcblx0Y29uc3Qgcm91dGVTY3JpcHRzID0gW107XG5cdGNvbnN0IG1hbmlmZXN0U2NyaXB0cyA9IFtdO1xuXHRmb3IgKGNvbnN0IG1hdGNoIG9mIGFzc2V0TWF0Y2hlcykgZm9yIChjb25zdCBzY3JpcHQgb2YgQXJyYXkuaXNBcnJheShtYXRjaC5zY3JpcHRzKSA/IG1hdGNoLnNjcmlwdHMgOiBbXSkge1xuXHRcdGlmICghc2NyaXB0KSBjb250aW51ZTtcblx0XHRjb25zdCB7IGNoaWxkcmVuLCAuLi5hdHRycyB9ID0gc2NyaXB0O1xuXHRcdHJvdXRlU2NyaXB0cy5wdXNoKHtcblx0XHRcdHRhZzogXCJzY3JpcHRcIixcblx0XHRcdGF0dHJzOiB7XG5cdFx0XHRcdC4uLmF0dHJzLFxuXHRcdFx0XHQuLi5yb3V0ZVNjcmlwdEF0dHJzLFxuXHRcdFx0XHRub25jZVxuXHRcdFx0fSxcblx0XHRcdGNoaWxkcmVuXG5cdFx0fSk7XG5cdH1cblx0aWYgKG1hbmlmZXN0KSBmb3IgKGNvbnN0IG1hdGNoIG9mIGFzc2V0TWF0Y2hlcykgZm9yIChjb25zdCBhc3NldCBvZiBtYW5pZmVzdC5yb3V0ZXNbbWF0Y2gucm91dGVJZF0/LnNjcmlwdHMgPz8gW10pIG1hbmlmZXN0U2NyaXB0cy5wdXNoKHtcblx0XHR0YWc6IFwic2NyaXB0XCIsXG5cdFx0YXR0cnM6IHtcblx0XHRcdC4uLmFzc2V0LmF0dHJzLFxuXHRcdFx0bm9uY2Vcblx0XHR9LFxuXHRcdGNoaWxkcmVuOiBhc3NldC5jaGlsZHJlblxuXHR9KTtcblx0cmV0dXJuIFtyb3V0ZVNjcmlwdHMsIG1hbmlmZXN0U2NyaXB0c107XG59XG5mdW5jdGlvbiBjb21wb3NlU3NyQm9keVNjcmlwdHMoW3JvdXRlU2NyaXB0cywgbWFuaWZlc3RTY3JpcHRzXSwgaW5pdGlhbEh5ZHJhdGlvblNjcmlwdHMpIHtcblx0aWYgKCFpbml0aWFsSHlkcmF0aW9uU2NyaXB0cykgcmV0dXJuIFsuLi5yb3V0ZVNjcmlwdHMsIC4uLm1hbmlmZXN0U2NyaXB0c107XG5cdHJldHVybiBbXG5cdFx0Li4uaW5pdGlhbEh5ZHJhdGlvblNjcmlwdHMuYmVmb3JlLFxuXHRcdC4uLnJvdXRlU2NyaXB0cyxcblx0XHQuLi5tYW5pZmVzdFNjcmlwdHMsXG5cdFx0aW5pdGlhbEh5ZHJhdGlvblNjcmlwdHMuYm91bmRhcnlcblx0XTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgY29tcG9zZVNzckJvZHlTY3JpcHRzLCBnZXRTc3JCb2R5U2NyaXB0UGFydHMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Ym9keVNjcmlwdHMuanMubWFwIiwiaW1wb3J0IHsgaW52YXJpYW50IH0gZnJvbSBcIi4vaW52YXJpYW50LmpzXCI7XG5pbXBvcnQgeyBjbGVhblBhdGgsIHRyaW1QYXRoTGVmdCwgdHJpbVBhdGhSaWdodCB9IGZyb20gXCIuL3BhdGguanNcIjtcbmltcG9ydCB7IG5vdEZvdW5kIH0gZnJvbSBcIi4vbm90LWZvdW5kLmpzXCI7XG5pbXBvcnQgeyByb290Um91dGVJZCB9IGZyb20gXCIuL3Jvb3QuanNcIjtcbmltcG9ydCB7IHJlZGlyZWN0IH0gZnJvbSBcIi4vcmVkaXJlY3QuanNcIjtcbi8vI3JlZ2lvbiBzcmMvcm91dGUudHNcbnZhciBCYXNlUm91dGUgPSBjbGFzcyB7XG5cdGdldCB0bygpIHtcblx0XHRyZXR1cm4gdGhpcy5fdG87XG5cdH1cblx0Z2V0IGlkKCkge1xuXHRcdHJldHVybiB0aGlzLl9pZDtcblx0fVxuXHRnZXQgcGF0aCgpIHtcblx0XHRyZXR1cm4gdGhpcy5fcGF0aDtcblx0fVxuXHRnZXQgZnVsbFBhdGgoKSB7XG5cdFx0cmV0dXJuIHRoaXMuX2Z1bGxQYXRoO1xuXHR9XG5cdGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcblx0XHR0aGlzLmluaXQgPSAob3JpZ2luYWxJbmRleCkgPT4ge1xuXHRcdFx0dGhpcy5vcmlnaW5hbEluZGV4ID0gb3JpZ2luYWxJbmRleDtcblx0XHRcdHRoaXMuX2JyYW5jaCA9IHZvaWQgMDtcblx0XHRcdGNvbnN0IG9wdGlvbnMgPSB0aGlzLm9wdGlvbnM7XG5cdFx0XHRjb25zdCBpc1Jvb3QgPSAhb3B0aW9ucz8ucGF0aCAmJiAhb3B0aW9ucz8uaWQ7XG5cdFx0XHR0aGlzLnBhcmVudFJvdXRlID0gdGhpcy5vcHRpb25zLmdldFBhcmVudFJvdXRlPy4oKTtcblx0XHRcdGlmIChpc1Jvb3QpIHRoaXMuX3BhdGggPSByb290Um91dGVJZDtcblx0XHRcdGVsc2UgaWYgKCF0aGlzLnBhcmVudFJvdXRlKSB7XG5cdFx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHRocm93IG5ldyBFcnJvcihgSW52YXJpYW50IGZhaWxlZDogQ2hpbGQgUm91dGUgaW5zdGFuY2VzIG11c3QgcGFzcyBhICdnZXRQYXJlbnRSb3V0ZTogKCkgPT4gUGFyZW50Um91dGUnIG9wdGlvbiB0aGF0IHJldHVybnMgYSBSb3V0ZSBpbnN0YW5jZS5gKTtcblx0XHRcdFx0aW52YXJpYW50KCk7XG5cdFx0XHR9XG5cdFx0XHRsZXQgcGF0aCA9IGlzUm9vdCA/IHJvb3RSb3V0ZUlkIDogb3B0aW9ucz8ucGF0aDtcblx0XHRcdGlmIChwYXRoICYmIHBhdGggIT09IFwiL1wiKSBwYXRoID0gdHJpbVBhdGhMZWZ0KHBhdGgpO1xuXHRcdFx0Y29uc3QgY3VzdG9tSWQgPSBvcHRpb25zPy5pZCB8fCBwYXRoO1xuXHRcdFx0Y29uc3QgaWQgPSBpc1Jvb3QgPyByb290Um91dGVJZCA6IGNsZWFuUGF0aCgodGhpcy5wYXJlbnRSb3V0ZS5pZCA9PT0gXCJfX3Jvb3RfX1wiID8gXCJcIiA6IHRoaXMucGFyZW50Um91dGUuaWQpICsgXCIvXCIgKyAoY3VzdG9tSWQgPz8gXCJcIikpO1xuXHRcdFx0aWYgKHBhdGggPT09IFwiX19yb290X19cIikgcGF0aCA9IFwiL1wiO1xuXHRcdFx0Y29uc3QgZnVsbFBhdGggPSBpZCA9PT0gXCJfX3Jvb3RfX1wiID8gXCIvXCIgOiBwYXRoID09PSB2b2lkIDAgPyB0aGlzLnBhcmVudFJvdXRlLmZ1bGxQYXRoIDogY2xlYW5QYXRoKHRoaXMucGFyZW50Um91dGUuZnVsbFBhdGggKyBcIi9cIiArIHBhdGgpO1xuXHRcdFx0dGhpcy5fcGF0aCA9IHBhdGg7XG5cdFx0XHR0aGlzLl9pZCA9IGlkO1xuXHRcdFx0dGhpcy5fZnVsbFBhdGggPSBmdWxsUGF0aDtcblx0XHRcdHRoaXMuX3RvID0gdHJpbVBhdGhSaWdodChmdWxsUGF0aCk7XG5cdFx0fTtcblx0XHR0aGlzLmFkZENoaWxkcmVuID0gKGNoaWxkcmVuKSA9PiB7XG5cdFx0XHRyZXR1cm4gdGhpcy5fYWRkRmlsZUNoaWxkcmVuKGNoaWxkcmVuKTtcblx0XHR9O1xuXHRcdHRoaXMuX2FkZEZpbGVDaGlsZHJlbiA9IChjaGlsZHJlbikgPT4ge1xuXHRcdFx0aWYgKEFycmF5LmlzQXJyYXkoY2hpbGRyZW4pKSB0aGlzLmNoaWxkcmVuID0gY2hpbGRyZW47XG5cdFx0XHRpZiAodHlwZW9mIGNoaWxkcmVuID09PSBcIm9iamVjdFwiICYmIGNoaWxkcmVuICE9PSBudWxsKSB0aGlzLmNoaWxkcmVuID0gT2JqZWN0LnZhbHVlcyhjaGlsZHJlbik7XG5cdFx0XHRyZXR1cm4gdGhpcztcblx0XHR9O1xuXHRcdHRoaXMuX2FkZEZpbGVUeXBlcyA9ICgpID0+IHtcblx0XHRcdHJldHVybiB0aGlzO1xuXHRcdH07XG5cdFx0dGhpcy51cGRhdGVMb2FkZXIgPSAob3B0aW9ucykgPT4ge1xuXHRcdFx0T2JqZWN0LmFzc2lnbih0aGlzLm9wdGlvbnMsIG9wdGlvbnMpO1xuXHRcdFx0cmV0dXJuIHRoaXM7XG5cdFx0fTtcblx0XHR0aGlzLnVwZGF0ZSA9IChvcHRpb25zKSA9PiB7XG5cdFx0XHRPYmplY3QuYXNzaWduKHRoaXMub3B0aW9ucywgb3B0aW9ucyk7XG5cdFx0XHRyZXR1cm4gdGhpcztcblx0XHR9O1xuXHRcdHRoaXMubGF6eSA9IChsYXp5Rm4pID0+IHtcblx0XHRcdHRoaXMubGF6eUZuID0gbGF6eUZuO1xuXHRcdFx0cmV0dXJuIHRoaXM7XG5cdFx0fTtcblx0XHR0aGlzLnJlZGlyZWN0ID0gKG9wdHMpID0+IHJlZGlyZWN0KHtcblx0XHRcdGZyb206IHRoaXMuZnVsbFBhdGgsXG5cdFx0XHQuLi5vcHRzXG5cdFx0fSk7XG5cdFx0dGhpcy5vcHRpb25zID0gb3B0aW9ucyB8fCB7fTtcblx0XHR0aGlzLmlzUm9vdCA9ICFvcHRpb25zPy5nZXRQYXJlbnRSb3V0ZTtcblx0XHRpZiAob3B0aW9ucz8uaWQgJiYgb3B0aW9ucz8ucGF0aCkgdGhyb3cgbmV3IEVycm9yKGBSb3V0ZSBjYW5ub3QgaGF2ZSBib3RoIGFuICdpZCcgYW5kIGEgJ3BhdGgnIG9wdGlvbi5gKTtcblx0fVxufTtcbnZhciBCYXNlUm91dGVBcGkgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKHsgaWQgfSkge1xuXHRcdHRoaXMubm90Rm91bmQgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIG5vdEZvdW5kKHtcblx0XHRcdFx0cm91dGVJZDogdGhpcy5pZCxcblx0XHRcdFx0Li4ub3B0c1xuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnJlZGlyZWN0ID0gKG9wdHMpID0+IHJlZGlyZWN0KHtcblx0XHRcdGZyb206IHRoaXMuaWQsXG5cdFx0XHQuLi5vcHRzXG5cdFx0fSk7XG5cdFx0dGhpcy5pZCA9IGlkO1xuXHR9XG59O1xudmFyIEJhc2VSb290Um91dGUgPSBjbGFzcyBleHRlbmRzIEJhc2VSb3V0ZSB7XG5cdGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcblx0XHRzdXBlcihvcHRpb25zKTtcblx0fVxufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgQmFzZVJvb3RSb3V0ZSwgQmFzZVJvdXRlLCBCYXNlUm91dGVBcGkgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGUuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9jb25maWcudHNcbmNvbnN0IGNyZWF0ZVJvdXRlckNvbmZpZyA9IChvcHRpb25zKSA9PiB7XG5cdHJldHVybiB7XG5cdFx0c2VyaWFsaXphdGlvbkFkYXB0ZXJzOiBvcHRpb25zLnNlcmlhbGl6YXRpb25BZGFwdGVycyxcblx0XHRkZWZhdWx0U3NyOiBvcHRpb25zLmRlZmF1bHRTc3Jcblx0fTtcbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNyZWF0ZVJvdXRlckNvbmZpZyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb25maWcuanMubWFwIiwiaW1wb3J0IHsgZGVlcEVxdWFsLCBoYXNPd24gfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuLy8jcmVnaW9uIHNyYy9zZWFyY2hNaWRkbGV3YXJlLnRzXG4vKipcbiogUmV0YWluIHNwZWNpZmllZCBzZWFyY2ggcGFyYW1zIGFjcm9zcyBuYXZpZ2F0aW9ucy5cbipcbiogSWYgYGtleXNgIGlzIGB0cnVlYCwgcmV0YWluIGFsbCBjdXJyZW50IHBhcmFtcy4gT3RoZXJ3aXNlLCBjb3B5IG9ubHkgdGhlXG4qIGxpc3RlZCBrZXlzIGZyb20gdGhlIGN1cnJlbnQgc2VhcmNoIGludG8gdGhlIG5leHQgc2VhcmNoLlxuKlxuKiBAcGFyYW0ga2V5cyBgdHJ1ZWAgdG8gcmV0YWluIGFsbCwgb3IgYSBsaXN0IG9mIGtleXMgdG8gcmV0YWluLlxuKiBAcmV0dXJucyBBIHNlYXJjaCBtaWRkbGV3YXJlIHN1aXRhYmxlIGZvciByb3V0ZSBgc2VhcmNoLm1pZGRsZXdhcmVzYC5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL3JldGFpblNlYXJjaFBhcmFtc0Z1bmN0aW9uXG4qL1xuZnVuY3Rpb24gcmV0YWluU2VhcmNoUGFyYW1zKGtleXMpIHtcblx0cmV0dXJuICh7IHNlYXJjaCwgbmV4dCB9KSA9PiB7XG5cdFx0Y29uc3QgeyBzZWFyY2g6IHJlc3VsdFNlYXJjaCwgbWV0YSB9ID0gbmV4dChzZWFyY2gsIHRydWUpO1xuXHRcdGlmIChrZXlzID09PSB0cnVlKSB7XG5cdFx0XHRjb25zdCBjb3B5ID0ge1xuXHRcdFx0XHQuLi5zZWFyY2gsXG5cdFx0XHRcdC4uLnJlc3VsdFNlYXJjaFxuXHRcdFx0fTtcblx0XHRcdGNvbnN0IHJlbW92ZWQgPSBtZXRhLnJlbW92ZWQ7XG5cdFx0XHRjb25zdCBleHBsaWNpdCA9IG1ldGEuZXhwbGljaXQ7XG5cdFx0XHRmb3IgKGNvbnN0IGtleSBvZiByZW1vdmVkPy5rZXlzKCkgfHwgW10pIGlmIChleHBsaWNpdCAmJiBoYXNPd24uY2FsbChleHBsaWNpdCwga2V5KSB8fCBkZWVwRXF1YWwoc2VhcmNoW2tleV0sIHJlbW92ZWQuZ2V0KGtleSkpKSBkZWxldGUgY29weVtrZXldO1xuXHRcdFx0Zm9yIChjb25zdCBrZXkgb2YgbWV0YS5yZW1vdmVkQW55IHx8IFtdKSBkZWxldGUgY29weVtrZXldO1xuXHRcdFx0Zm9yIChjb25zdCBrZXkgb2YgbWV0YS5kZWZhdWx0ZWQ/LmtleXMoKSB8fCBbXSkgaWYgKGtleSBpbiBzZWFyY2ggJiYgIW1ldGEucmVtb3ZlZEFueT8uaGFzKGtleSkgJiYgIShtZXRhLnJlbW92ZWQ/LmhhcyhrZXkpICYmIChleHBsaWNpdCAmJiBoYXNPd24uY2FsbChleHBsaWNpdCwga2V5KSB8fCBkZWVwRXF1YWwoc2VhcmNoW2tleV0sIG1ldGEucmVtb3ZlZC5nZXQoa2V5KSkpKSkgY29weVtrZXldID0gc2VhcmNoW2tleV07XG5cdFx0XHRyZXR1cm4gY29weTtcblx0XHR9XG5cdFx0Y29uc3QgY29weSA9IHsgLi4ucmVzdWx0U2VhcmNoIH07XG5cdFx0Y29uc3QgZXhwbGljaXQgPSBtZXRhLmV4cGxpY2l0O1xuXHRcdGZvciAoY29uc3Qga2V5IG9mIGtleXMpIHtcblx0XHRcdGNvbnN0IHN0cmluZ0tleSA9IGtleTtcblx0XHRcdGlmICghKG1ldGEucmVtb3ZlZEFueT8uaGFzKHN0cmluZ0tleSkgfHwgbWV0YS5yZW1vdmVkPy5oYXMoc3RyaW5nS2V5KSAmJiAoZXhwbGljaXQgJiYgaGFzT3duLmNhbGwoZXhwbGljaXQsIHN0cmluZ0tleSkgfHwgZGVlcEVxdWFsKHNlYXJjaFtrZXldLCBtZXRhLnJlbW92ZWQuZ2V0KHN0cmluZ0tleSkpKSkgJiYgKCEoa2V5IGluIGNvcHkpIHx8IGtleSBpbiBzZWFyY2ggJiYgbWV0YS5kZWZhdWx0ZWQ/LmhhcyhzdHJpbmdLZXkpICYmIGRlZXBFcXVhbChjb3B5W2tleV0sIG1ldGEuZGVmYXVsdGVkLmdldChzdHJpbmdLZXkpKSkpIGNvcHlba2V5XSA9IHNlYXJjaFtrZXldO1xuXHRcdH1cblx0XHRyZXR1cm4gY29weTtcblx0fTtcbn1cbi8qKlxuKiBSZW1vdmUgb3B0aW9uYWwgb3IgZGVmYXVsdC12YWx1ZWQgc2VhcmNoIHBhcmFtcyBmcm9tIG5hdmlnYXRpb25zLlxuKlxuKiAtIFBhc3MgYHRydWVgIChvbmx5IGlmIHRoZXJlIGFyZSBubyByZXF1aXJlZCBzZWFyY2ggcGFyYW1zKSB0byBzdHJpcCBhbGwuXG4qIC0gUGFzcyBhbiBhcnJheSB0byBhbHdheXMgcmVtb3ZlIHRob3NlIG9wdGlvbmFsIGtleXMuXG4qIC0gUGFzcyBhbiBvYmplY3Qgb2YgZGVmYXVsdCB2YWx1ZXM7IGtleXMgZXF1YWwgKGRlZXBseSkgdG8gdGhlIGRlZmF1bHRzIGFyZSByZW1vdmVkLlxuKlxuKiBAcmV0dXJucyBBIHNlYXJjaCBtaWRkbGV3YXJlIHN1aXRhYmxlIGZvciByb3V0ZSBgc2VhcmNoLm1pZGRsZXdhcmVzYC5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL3N0cmlwU2VhcmNoUGFyYW1zRnVuY3Rpb25cbiovXG5mdW5jdGlvbiBzdHJpcFNlYXJjaFBhcmFtcyhpbnB1dCkge1xuXHRyZXR1cm4gKCh7IHNlYXJjaCwgbmV4dCwgbWV0YSB9KSA9PiB7XG5cdFx0aWYgKGlucHV0ID09PSB0cnVlKSB7XG5cdFx0XHRPYmplY3Qua2V5cyhzZWFyY2gpLmZvckVhY2goKGtleSkgPT4ge1xuXHRcdFx0XHRpZiAobWV0YSkgKG1ldGEucmVtb3ZlZEFueSB8fD0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSkuYWRkKGtleSk7XG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiB7fTtcblx0XHR9XG5cdFx0Y29uc3QgcmVzdWx0ID0geyAuLi5uZXh0KHNlYXJjaCkgfTtcblx0XHRpZiAoQXJyYXkuaXNBcnJheShpbnB1dCkpIGlucHV0LmZvckVhY2goKGtleSkgPT4ge1xuXHRcdFx0ZGVsZXRlIHJlc3VsdFtrZXldO1xuXHRcdFx0aWYgKG1ldGEpIChtZXRhLnJlbW92ZWRBbnkgfHw9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCkpLmFkZChrZXkpO1xuXHRcdH0pO1xuXHRcdGVsc2UgT2JqZWN0LmVudHJpZXMoaW5wdXQpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4ge1xuXHRcdFx0aWYgKGRlZXBFcXVhbChyZXN1bHRba2V5XSwgdmFsdWUpKSB7XG5cdFx0XHRcdGRlbGV0ZSByZXN1bHRba2V5XTtcblx0XHRcdFx0aWYgKG1ldGEpIChtZXRhLnJlbW92ZWQgfHw9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCkpLnNldChrZXksIHZhbHVlKTtcblx0XHRcdH1cblx0XHR9KTtcblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgcmV0YWluU2VhcmNoUGFyYW1zLCBzdHJpcFNlYXJjaFBhcmFtcyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1zZWFyY2hNaWRkbGV3YXJlLmpzLm1hcCIsIi8vI3JlZ2lvbiBzcmMvc3NyL3NlcmlhbGl6ZXIvdHJhbnNmb3JtZXIudHNcbi8qKlxuKiBDcmVhdGUgYSBzdHJvbmdseS10eXBlZCBzZXJpYWxpemF0aW9uIGFkYXB0ZXIgZm9yIFNTUiBoeWRyYXRpb24uXG4qIFVzZSB0byByZWdpc3RlciBjdXN0b20gdHlwZXMgd2l0aCB0aGUgcm91dGVyIHNlcmlhbGl6ZXIuXG4qL1xuZnVuY3Rpb24gY3JlYXRlU2VyaWFsaXphdGlvbkFkYXB0ZXIob3B0cykge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0aWYgKCFvcHRzLmtleSB8fCAvW1xcMFwiXFxcXDxcXGJcXHRcXGZcXHJcXG5cXHUyMDI4XFx1MjAyOVxcdUQ4MDAtXFx1REZGRl0vLnRlc3Qob3B0cy5rZXkpKSB0aHJvdyBuZXcgRXJyb3IoYGNyZWF0ZVNlcmlhbGl6YXRpb25BZGFwdGVyOiBrZXkgJHtKU09OLnN0cmluZ2lmeShvcHRzLmtleSl9IGlzIGludmFsaWQuIFNlcmlhbGl6YXRpb24gYWRhcHRlciBrZXlzIG11c3QgYmUgbm9uLWVtcHR5IGFuZCBub3QgY29udGFpbiBOVUwsIFwiLCBcXFxcLCA8LCBiYWNrc3BhY2UsIHRhYiwgZm9ybSBmZWVkLCBsaW5lIHRlcm1pbmF0b3JzLCBvciBVVEYtMTYgc3Vycm9nYXRlIGNvZGUgdW5pdHMuYCk7XG5cdH1cblx0cmV0dXJuIG9wdHM7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNyZWF0ZVNlcmlhbGl6YXRpb25BZGFwdGVyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXRyYW5zZm9ybWVyLmpzLm1hcCIsImltcG9ydCB7IHJlYWN0VXNlIH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IFRTUl9ERUZFUlJFRF9QUk9NSVNFLCBkZWZlciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvYXdhaXRlZC50c3hcbi8qKiBTdXNwZW5kIHVudGlsIGEgZGVmZXJyZWQgcHJvbWlzZSByZXNvbHZlcyBvciByZWplY3RzIGFuZCByZXR1cm4gaXRzIGRhdGEuICovXG5mdW5jdGlvbiB1c2VBd2FpdGVkKHsgcHJvbWlzZTogX3Byb21pc2UgfSkge1xuXHRpZiAocmVhY3RVc2UpIHJldHVybiByZWFjdFVzZShfcHJvbWlzZSk7XG5cdGNvbnN0IHByb21pc2UgPSBkZWZlcihfcHJvbWlzZSk7XG5cdGlmIChwcm9taXNlW1RTUl9ERUZFUlJFRF9QUk9NSVNFXS5zdGF0dXMgPT09IFwicGVuZGluZ1wiKSB0aHJvdyBwcm9taXNlO1xuXHRpZiAocHJvbWlzZVtUU1JfREVGRVJSRURfUFJPTUlTRV0uc3RhdHVzID09PSBcImVycm9yXCIpIHRocm93IHByb21pc2VbVFNSX0RFRkVSUkVEX1BST01JU0VdLmVycm9yO1xuXHRyZXR1cm4gcHJvbWlzZVtUU1JfREVGRVJSRURfUFJPTUlTRV0uZGF0YTtcbn1cbi8qKlxuKiBDb21wb25lbnQgdGhhdCBzdXNwZW5kcyBvbiBhIGRlZmVycmVkIHByb21pc2UgYW5kIHJlbmRlcnMgaXRzIGNoaWxkIHdpdGhcbiogdGhlIHJlc29sdmVkIHZhbHVlLiBPcHRpb25hbGx5IHByb3ZpZGVzIGEgU3VzcGVuc2UgZmFsbGJhY2suXG4qL1xuZnVuY3Rpb24gQXdhaXQocHJvcHMpIHtcblx0Y29uc3QgaW5uZXIgPSAvKiBAX19QVVJFX18gKi8ganN4KEF3YWl0SW5uZXIsIHsgLi4ucHJvcHMgfSk7XG5cdGlmIChwcm9wcy5mYWxsYmFjaykgcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goUmVhY3QkMS5TdXNwZW5zZSwge1xuXHRcdGZhbGxiYWNrOiBwcm9wcy5mYWxsYmFjayxcblx0XHRjaGlsZHJlbjogaW5uZXJcblx0fSk7XG5cdHJldHVybiBpbm5lcjtcbn1cbmZ1bmN0aW9uIEF3YWl0SW5uZXIocHJvcHMpIHtcblx0Y29uc3QgZGF0YSA9IHVzZUF3YWl0ZWQocHJvcHMpO1xuXHRyZXR1cm4gcHJvcHMuY2hpbGRyZW4oZGF0YSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEF3YWl0LCB1c2VBd2FpdGVkIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWF3YWl0ZWQuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL25vblJvdXRlQ29tcG9uZW50Q29udGV4dC50c3hcbnZhciBub25Sb3V0ZUNvbXBvbmVudENvbnRleHQgPSBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyBSZWFjdCQxLmNyZWF0ZUNvbnRleHQodm9pZCAwKSA6IHZvaWQgMDtcbmZ1bmN0aW9uIHdyYXBJbk5vblJvdXRlQ29tcG9uZW50Q29udGV4dChlbGVtZW50LCBjb21wb25lbnQpIHtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3gobm9uUm91dGVDb21wb25lbnRDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0dmFsdWU6IGNvbXBvbmVudCxcblx0XHRjaGlsZHJlbjogZWxlbWVudFxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgbm9uUm91dGVDb21wb25lbnRDb250ZXh0LCB3cmFwSW5Ob25Sb3V0ZUNvbXBvbmVudENvbnRleHQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bm9uUm91dGVDb21wb25lbnRDb250ZXh0LmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgd3JhcEluTm9uUm91dGVDb21wb25lbnRDb250ZXh0IH0gZnJvbSBcIi4vbm9uUm91dGVDb21wb25lbnRDb250ZXh0LmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsganN4LCBqc3hzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL0NhdGNoQm91bmRhcnkudHN4XG52YXIgQ2F0Y2hCb3VuZGFyeSA9IGNsYXNzIGV4dGVuZHMgUmVhY3QkMS5Db21wb25lbnQge1xuXHRjb25zdHJ1Y3RvciguLi5fYXJncykge1xuXHRcdHN1cGVyKC4uLl9hcmdzKTtcblx0XHR0aGlzLnN0YXRlID0geyBlcnJvcjogMCB9O1xuXHRcdHRoaXMucmVzZXQgPSAoKSA9PiB7XG5cdFx0XHR0aGlzLnNldFN0YXRlKHsgZXJyb3I6IDAgfSk7XG5cdFx0fTtcblx0fVxuXHRzdGF0aWMgZ2V0RGVyaXZlZFN0YXRlRnJvbVByb3BzKHByb3BzLCBzdGF0ZSkge1xuXHRcdGNvbnN0IHJlc2V0S2V5ID0gcHJvcHMuZ2V0UmVzZXRLZXkoKTtcblx0XHRpZiAoc3RhdGUuZXJyb3IgJiYgc3RhdGUucmVzZXRLZXkgIT09IHJlc2V0S2V5KSByZXR1cm4ge1xuXHRcdFx0cmVzZXRLZXksXG5cdFx0XHRlcnJvcjogMFxuXHRcdH07XG5cdFx0cmV0dXJuIHsgcmVzZXRLZXkgfTtcblx0fVxuXHRzdGF0aWMgZ2V0RGVyaXZlZFN0YXRlRnJvbUVycm9yKGVycm9yKSB7XG5cdFx0cmV0dXJuIHsgZXJyb3I6IFtlcnJvcl0gfTtcblx0fVxuXHRjb21wb25lbnREaWRDYXRjaChlcnJvciwgZXJyb3JJbmZvKSB7XG5cdFx0dGhpcy5wcm9wcy5vbkNhdGNoPy4oZXJyb3IsIGVycm9ySW5mbyk7XG5cdH1cblx0cmVuZGVyKCkge1xuXHRcdGNvbnN0IGVycm9yID0gdGhpcy5zdGF0ZS5lcnJvcjtcblx0XHRpZiAoZXJyb3IpIHtcblx0XHRcdGNvbnN0IGVsZW1lbnQgPSBSZWFjdCQxLmNyZWF0ZUVsZW1lbnQodGhpcy5wcm9wcy5lcnJvckNvbXBvbmVudCA/PyBFcnJvckNvbXBvbmVudCwge1xuXHRcdFx0XHRlcnJvcjogZXJyb3JbMF0sXG5cdFx0XHRcdHJlc2V0OiB0aGlzLnJlc2V0XG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyB3cmFwSW5Ob25Sb3V0ZUNvbXBvbmVudENvbnRleHQoZWxlbWVudCwgXCJlcnJvckNvbXBvbmVudFwiKSA6IGVsZW1lbnQ7XG5cdFx0fVxuXHRcdHJldHVybiB0aGlzLnByb3BzLmNoaWxkcmVuO1xuXHR9XG59O1xuZnVuY3Rpb24gRXJyb3JDb21wb25lbnQoeyBlcnJvciB9KSB7XG5cdGNvbnN0IFtzaG93LCBzZXRTaG93XSA9IFJlYWN0JDEudXNlU3RhdGUocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKTtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3hzKFwiZGl2XCIsIHtcblx0XHRzdHlsZToge1xuXHRcdFx0cGFkZGluZzogXCIuNXJlbVwiLFxuXHRcdFx0bWF4V2lkdGg6IFwiMTAwJVwiXG5cdFx0fSxcblx0XHRjaGlsZHJlbjogW1xuXHRcdFx0LyogQF9fUFVSRV9fICovIGpzeHMoXCJkaXZcIiwge1xuXHRcdFx0XHRzdHlsZToge1xuXHRcdFx0XHRcdGRpc3BsYXk6IFwiZmxleFwiLFxuXHRcdFx0XHRcdGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXG5cdFx0XHRcdFx0Z2FwOiBcIi41cmVtXCJcblx0XHRcdFx0fSxcblx0XHRcdFx0Y2hpbGRyZW46IFsvKiBAX19QVVJFX18gKi8ganN4KFwic3Ryb25nXCIsIHtcblx0XHRcdFx0XHRzdHlsZTogeyBmb250U2l6ZTogXCIxcmVtXCIgfSxcblx0XHRcdFx0XHRjaGlsZHJlbjogXCJTb21ldGhpbmcgd2VudCB3cm9uZyFcIlxuXHRcdFx0XHR9KSwgLyogQF9fUFVSRV9fICovIGpzeChcImJ1dHRvblwiLCB7XG5cdFx0XHRcdFx0c3R5bGU6IHtcblx0XHRcdFx0XHRcdGFwcGVhcmFuY2U6IFwibm9uZVwiLFxuXHRcdFx0XHRcdFx0Zm9udFNpemU6IFwiLjZlbVwiLFxuXHRcdFx0XHRcdFx0Ym9yZGVyOiBcIjFweCBzb2xpZCBjdXJyZW50Q29sb3JcIixcblx0XHRcdFx0XHRcdHBhZGRpbmc6IFwiLjFyZW0gLjJyZW1cIixcblx0XHRcdFx0XHRcdGZvbnRXZWlnaHQ6IFwiYm9sZFwiLFxuXHRcdFx0XHRcdFx0Ym9yZGVyUmFkaXVzOiBcIi4yNXJlbVwiXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRvbkNsaWNrOiAoKSA9PiBzZXRTaG93KChkKSA9PiAhZCksXG5cdFx0XHRcdFx0Y2hpbGRyZW46IHNob3cgPyBcIkhpZGUgRXJyb3JcIiA6IFwiU2hvdyBFcnJvclwiXG5cdFx0XHRcdH0pXVxuXHRcdFx0fSksXG5cdFx0XHQvKiBAX19QVVJFX18gKi8ganN4KFwiZGl2XCIsIHsgc3R5bGU6IHsgaGVpZ2h0OiBcIi4yNXJlbVwiIH0gfSksXG5cdFx0XHRzaG93ID8gLyogQF9fUFVSRV9fICovIGpzeChcImRpdlwiLCB7IGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4KFwicHJlXCIsIHtcblx0XHRcdFx0c3R5bGU6IHtcblx0XHRcdFx0XHRmb250U2l6ZTogXCIuN2VtXCIsXG5cdFx0XHRcdFx0Ym9yZGVyOiBcIjFweCBzb2xpZCByZWRcIixcblx0XHRcdFx0XHRib3JkZXJSYWRpdXM6IFwiLjI1cmVtXCIsXG5cdFx0XHRcdFx0cGFkZGluZzogXCIuM3JlbVwiLFxuXHRcdFx0XHRcdGNvbG9yOiBcInJlZFwiLFxuXHRcdFx0XHRcdG92ZXJmbG93OiBcImF1dG9cIlxuXHRcdFx0XHR9LFxuXHRcdFx0XHRjaGlsZHJlbjogZXJyb3I/Lm1lc3NhZ2UgPyAvKiBAX19QVVJFX18gKi8ganN4KFwiY29kZVwiLCB7IGNoaWxkcmVuOiBlcnJvci5tZXNzYWdlIH0pIDogbnVsbFxuXHRcdFx0fSkgfSkgOiBudWxsXG5cdFx0XVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgQ2F0Y2hCb3VuZGFyeSwgRXJyb3JDb21wb25lbnQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Q2F0Y2hCb3VuZGFyeS5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9DbGllbnRPbmx5LnRzeFxudmFyIGdldFNuYXBzaG90ID0gKCkgPT4gdHJ1ZTtcbnZhciBnZXRTZXJ2ZXJTbmFwc2hvdCA9ICgpID0+IGZhbHNlO1xuLyoqXG4qIFJlbmRlciB0aGUgY2hpbGRyZW4gb25seSBhZnRlciB0aGUgSlMgaGFzIGxvYWRlZCBjbGllbnQtc2lkZS4gVXNlIGFuIG9wdGlvbmFsXG4qIGZhbGxiYWNrIGNvbXBvbmVudCBpZiB0aGUgSlMgaXMgbm90IHlldCBsb2FkZWQuXG4qXG4qIEBleGFtcGxlXG4qIFJlbmRlciBhIENoYXJ0IGNvbXBvbmVudCBpZiBKUyBsb2FkcywgcmVuZGVycyBhIHNpbXBsZSBGYWtlQ2hhcnRcbiogY29tcG9uZW50IHNlcnZlci1zaWRlIG9yIGlmIHRoZXJlIGlzIG5vIEpTLiBUaGUgRmFrZUNoYXJ0IGNhbiBoYXZlIG9ubHkgdGhlXG4qIFVJIHdpdGhvdXQgdGhlIGJlaGF2aW9yIG9yIGJlIGEgbG9hZGluZyBzcGlubmVyIG9yIHNrZWxldG9uLlxuKlxuKiBgYGB0c3hcbiogcmV0dXJuIChcbiogICA8Q2xpZW50T25seSBmYWxsYmFjaz17PEZha2VDaGFydCAvPn0+XG4qICAgICA8Q2hhcnQgLz5cbiogICA8L0NsaWVudE9ubHk+XG4qIClcbiogYGBgXG4qL1xuZnVuY3Rpb24gQ2xpZW50T25seSh7IGNoaWxkcmVuLCBmYWxsYmFjayA9IG51bGwgfSkge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChSZWFjdC5GcmFnbWVudCwgeyBjaGlsZHJlbjogdXNlSHlkcmF0ZWQoKSA/IGNoaWxkcmVuIDogZmFsbGJhY2sgfSk7XG59XG4vKiogQGludGVybmFsICovXG5mdW5jdGlvbiB1c2VIeWRyYXRlZChlbmFibGVkID0gdHJ1ZSkge1xuXHRyZXR1cm4gUmVhY3QudXNlU3luY0V4dGVybmFsU3RvcmUoc3Vic2NyaWJlLCBnZXRTbmFwc2hvdCwgZW5hYmxlZCA/IGdldFNlcnZlclNuYXBzaG90IDogZ2V0U25hcHNob3QpO1xufVxuZnVuY3Rpb24gc3Vic2NyaWJlKCkge1xuXHRyZXR1cm4gKCkgPT4ge307XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IENsaWVudE9ubHksIHVzZUh5ZHJhdGVkIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUNsaWVudE9ubHkuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuLy8jcmVnaW9uIHNyYy9yb3V0ZXJDb250ZXh0LnRzeFxudmFyIHJvdXRlckNvbnRleHQgPSBSZWFjdCQxLmNyZWF0ZUNvbnRleHQobnVsbCk7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHJvdXRlckNvbnRleHQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cm91dGVyQ29udGV4dC5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHJvdXRlckNvbnRleHQgfSBmcm9tIFwiLi9yb3V0ZXJDb250ZXh0LmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuLy8jcmVnaW9uIHNyYy91c2VSb3V0ZXIudHN4XG4vKipcbiogQWNjZXNzIHRoZSBjdXJyZW50IFRhblN0YWNrIFJvdXRlciBpbnN0YW5jZSBmcm9tIFJlYWN0IGNvbnRleHQuXG4qIE11c3QgYmUgdXNlZCB3aXRoaW4gYSBgUm91dGVyUHJvdmlkZXJgLlxuKlxuKiBPcHRpb25zOlxuKiAtIGB3YXJuYDogTG9nIGEgd2FybmluZyBpZiBubyByb3V0ZXIgY29udGV4dCBpcyBmb3VuZCAoZGVmYXVsdDogdHJ1ZSkuXG4qXG4qIEByZXR1cm5zIFRoZSByZWdpc3RlcmVkIHJvdXRlciBpbnN0YW5jZS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL3VzZVJvdXRlckhvb2tcbiovXG5mdW5jdGlvbiB1c2VSb3V0ZXIob3B0cykge1xuXHRjb25zdCB2YWx1ZSA9IFJlYWN0JDEudXNlQ29udGV4dChyb3V0ZXJDb250ZXh0KTtcblx0aWYgKCF2YWx1ZSkgd2Fybk1pc3NpbmdSb3V0ZXIob3B0cyk7XG5cdHJldHVybiB2YWx1ZTtcbn1cbmZ1bmN0aW9uIHdhcm5NaXNzaW5nUm91dGVyKG9wdHMpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiAob3B0cz8ud2FybiA/PyB0cnVlKSkgY29uc29sZS53YXJuKFwiV2FybmluZzogdXNlUm91dGVyIG11c3QgYmUgdXNlZCBpbnNpZGUgYSA8Um91dGVyUHJvdmlkZXI+IGNvbXBvbmVudCFcIik7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZVJvdXRlciB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VSb3V0ZXIuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyBfaXNSb3V0ZURlcGFydGluZyB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG4vLyNyZWdpb24gc3JjL21hdGNoQ29udGV4dC50c3hcbmZ1bmN0aW9uIGNyZWF0ZUxpbmtTY29wZShyb3V0ZXIsIHJvdXRlSWQpIHtcblx0Y29uc3Qgc3RvcmUgPSByb3V0ZXIuc3RvcmVzLmxvY2F0aW9uO1xuXHRjb25zdCBsaXN0ZW5lcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRsZXQgc291cmNlO1xuXHRsZXQgdW5zdWJzY3JpYmU7XG5cdGNvbnN0IHVwZGF0ZSA9IChsb2NhdGlvbikgPT4ge1xuXHRcdGlmICghX2lzUm91dGVEZXBhcnRpbmcocm91dGVyLCByb3V0ZUlkLCBsb2NhdGlvbikpIHtcblx0XHRcdHNvdXJjZSA9IGxvY2F0aW9uO1xuXHRcdFx0bGlzdGVuZXJzLmZvckVhY2goKGxpc3RlbmVyKSA9PiBsaXN0ZW5lcigpKTtcblx0XHR9XG5cdH07XG5cdHJldHVybiBbKCkgPT4gc291cmNlID8/IHN0b3JlLmdldCgpLCAobGlzdGVuZXIpID0+IHtcblx0XHRpZiAoIWxpc3RlbmVycy5zaXplKSB7XG5cdFx0XHRzb3VyY2UgPSBzdG9yZS5nZXQoKTtcblx0XHRcdHVuc3Vic2NyaWJlID0gc3RvcmUuc3Vic2NyaWJlKHVwZGF0ZSkudW5zdWJzY3JpYmU7XG5cdFx0fVxuXHRcdGxpc3RlbmVycy5hZGQobGlzdGVuZXIpO1xuXHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRsaXN0ZW5lcnMuZGVsZXRlKGxpc3RlbmVyKTtcblx0XHRcdGlmICghbGlzdGVuZXJzLnNpemUpIHtcblx0XHRcdFx0dW5zdWJzY3JpYmUoKTtcblx0XHRcdFx0c291cmNlID0gdm9pZCAwO1xuXHRcdFx0fVxuXHRcdH07XG5cdH1dO1xufVxudmFyIG1hdGNoQ29udGV4dCA9IFJlYWN0JDEuY3JlYXRlQ29udGV4dCh2b2lkIDApO1xudmFyIGR1bW15TWF0Y2hDb250ZXh0ID0gUmVhY3QkMS5jcmVhdGVDb250ZXh0KHZvaWQgMCk7XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGNyZWF0ZUxpbmtTY29wZSwgZHVtbXlNYXRjaENvbnRleHQsIG1hdGNoQ29udGV4dCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1tYXRjaENvbnRleHQuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9hbGllbi50c1xuY29uc3QgTk9ORSA9IDA7XG5jb25zdCBNVVRBQkxFID0gMTtcbmNvbnN0IFdBVENISU5HID0gMjtcbmNvbnN0IFJFQ1VSU0VEX0NIRUNLID0gNDtcbmNvbnN0IFJFQ1VSU0VEID0gODtcbmNvbnN0IERJUlRZID0gMTY7XG5jb25zdCBQRU5ESU5HID0gMzI7XG4vKiBAX19OT19TSURFX0VGRkVDVFNfXyAqL1xuZnVuY3Rpb24gY3JlYXRlUmVhY3RpdmVTeXN0ZW0oeyB1cGRhdGUsIG5vdGlmeSwgdW53YXRjaGVkIH0pIHtcblx0cmV0dXJuIHtcblx0XHRsaW5rLFxuXHRcdHVubGluayxcblx0XHRwcm9wYWdhdGUsXG5cdFx0Y2hlY2tEaXJ0eSxcblx0XHRzaGFsbG93UHJvcGFnYXRlXG5cdH07XG5cdGZ1bmN0aW9uIGxpbmsoZGVwLCBzdWIsIHZlcnNpb24pIHtcblx0XHRjb25zdCBwcmV2RGVwID0gc3ViLmRlcHNUYWlsO1xuXHRcdGlmIChwcmV2RGVwICE9PSB2b2lkIDAgJiYgcHJldkRlcC5kZXAgPT09IGRlcCkgcmV0dXJuO1xuXHRcdGNvbnN0IG5leHREZXAgPSBwcmV2RGVwICE9PSB2b2lkIDAgPyBwcmV2RGVwLm5leHREZXAgOiBzdWIuZGVwcztcblx0XHRpZiAobmV4dERlcCAhPT0gdm9pZCAwICYmIG5leHREZXAuZGVwID09PSBkZXApIHtcblx0XHRcdG5leHREZXAudmVyc2lvbiA9IHZlcnNpb247XG5cdFx0XHRzdWIuZGVwc1RhaWwgPSBuZXh0RGVwO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRjb25zdCBwcmV2U3ViID0gZGVwLnN1YnNUYWlsO1xuXHRcdGlmIChwcmV2U3ViICE9PSB2b2lkIDAgJiYgcHJldlN1Yi52ZXJzaW9uID09PSB2ZXJzaW9uICYmIHByZXZTdWIuc3ViID09PSBzdWIpIHJldHVybjtcblx0XHRjb25zdCBuZXdMaW5rID0gc3ViLmRlcHNUYWlsID0gZGVwLnN1YnNUYWlsID0ge1xuXHRcdFx0dmVyc2lvbixcblx0XHRcdGRlcCxcblx0XHRcdHN1Yixcblx0XHRcdHByZXZEZXAsXG5cdFx0XHRuZXh0RGVwLFxuXHRcdFx0cHJldlN1Yixcblx0XHRcdG5leHRTdWI6IHZvaWQgMFxuXHRcdH07XG5cdFx0aWYgKG5leHREZXAgIT09IHZvaWQgMCkgbmV4dERlcC5wcmV2RGVwID0gbmV3TGluaztcblx0XHRpZiAocHJldkRlcCAhPT0gdm9pZCAwKSBwcmV2RGVwLm5leHREZXAgPSBuZXdMaW5rO1xuXHRcdGVsc2Ugc3ViLmRlcHMgPSBuZXdMaW5rO1xuXHRcdGlmIChwcmV2U3ViICE9PSB2b2lkIDApIHByZXZTdWIubmV4dFN1YiA9IG5ld0xpbms7XG5cdFx0ZWxzZSBkZXAuc3VicyA9IG5ld0xpbms7XG5cdH1cblx0ZnVuY3Rpb24gdW5saW5rKGxpbmssIHN1YiA9IGxpbmsuc3ViKSB7XG5cdFx0Y29uc3QgZGVwID0gbGluay5kZXA7XG5cdFx0Y29uc3QgcHJldkRlcCA9IGxpbmsucHJldkRlcDtcblx0XHRjb25zdCBuZXh0RGVwID0gbGluay5uZXh0RGVwO1xuXHRcdGNvbnN0IG5leHRTdWIgPSBsaW5rLm5leHRTdWI7XG5cdFx0Y29uc3QgcHJldlN1YiA9IGxpbmsucHJldlN1Yjtcblx0XHRpZiAobmV4dERlcCAhPT0gdm9pZCAwKSBuZXh0RGVwLnByZXZEZXAgPSBwcmV2RGVwO1xuXHRcdGVsc2Ugc3ViLmRlcHNUYWlsID0gcHJldkRlcDtcblx0XHRpZiAocHJldkRlcCAhPT0gdm9pZCAwKSBwcmV2RGVwLm5leHREZXAgPSBuZXh0RGVwO1xuXHRcdGVsc2Ugc3ViLmRlcHMgPSBuZXh0RGVwO1xuXHRcdGlmIChuZXh0U3ViICE9PSB2b2lkIDApIG5leHRTdWIucHJldlN1YiA9IHByZXZTdWI7XG5cdFx0ZWxzZSBkZXAuc3Vic1RhaWwgPSBwcmV2U3ViO1xuXHRcdGlmIChwcmV2U3ViICE9PSB2b2lkIDApIHByZXZTdWIubmV4dFN1YiA9IG5leHRTdWI7XG5cdFx0ZWxzZSBpZiAoKGRlcC5zdWJzID0gbmV4dFN1YikgPT09IHZvaWQgMCkgdW53YXRjaGVkKGRlcCk7XG5cdFx0cmV0dXJuIG5leHREZXA7XG5cdH1cblx0ZnVuY3Rpb24gcHJvcGFnYXRlKGxpbmspIHtcblx0XHRsZXQgbmV4dCA9IGxpbmsubmV4dFN1Yjtcblx0XHRsZXQgc3RhY2s7XG5cdFx0dG9wOiBkbyB7XG5cdFx0XHRjb25zdCBzdWIgPSBsaW5rLnN1Yjtcblx0XHRcdGxldCBmbGFncyA9IHN1Yi5mbGFncztcblx0XHRcdGlmICghKGZsYWdzICYgNjApKSBzdWIuZmxhZ3MgPSBmbGFncyB8IDMyO1xuXHRcdFx0ZWxzZSBpZiAoIShmbGFncyAmICg0IHwgOCkpKSBmbGFncyA9IDA7XG5cdFx0XHRlbHNlIGlmICghKGZsYWdzICYgNCkpIHN1Yi5mbGFncyA9IGZsYWdzICYgfjggfCAzMjtcblx0XHRcdGVsc2UgaWYgKCEoZmxhZ3MgJiAoMTYgfCAzMikpICYmIGlzVmFsaWRMaW5rKGxpbmssIHN1YikpIHtcblx0XHRcdFx0c3ViLmZsYWdzID0gZmxhZ3MgfCAoOCB8IDMyKTtcblx0XHRcdFx0ZmxhZ3MgJj0gMTtcblx0XHRcdH0gZWxzZSBmbGFncyA9IDA7XG5cdFx0XHRpZiAoZmxhZ3MgJiAyKSBub3RpZnkoc3ViKTtcblx0XHRcdGlmIChmbGFncyAmIDEpIHtcblx0XHRcdFx0Y29uc3Qgc3ViU3VicyA9IHN1Yi5zdWJzO1xuXHRcdFx0XHRpZiAoc3ViU3VicyAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdFx0Y29uc3QgbmV4dFN1YiA9IChsaW5rID0gc3ViU3VicykubmV4dFN1Yjtcblx0XHRcdFx0XHRpZiAobmV4dFN1YiAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdFx0XHRzdGFjayA9IHtcblx0XHRcdFx0XHRcdFx0dmFsdWU6IG5leHQsXG5cdFx0XHRcdFx0XHRcdHByZXY6IHN0YWNrXG5cdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0bmV4dCA9IG5leHRTdWI7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRpZiAoKGxpbmsgPSBuZXh0KSAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdG5leHQgPSBsaW5rLm5leHRTdWI7XG5cdFx0XHRcdGNvbnRpbnVlO1xuXHRcdFx0fVxuXHRcdFx0d2hpbGUgKHN0YWNrICE9PSB2b2lkIDApIHtcblx0XHRcdFx0bGluayA9IHN0YWNrLnZhbHVlO1xuXHRcdFx0XHRzdGFjayA9IHN0YWNrLnByZXY7XG5cdFx0XHRcdGlmIChsaW5rICE9PSB2b2lkIDApIHtcblx0XHRcdFx0XHRuZXh0ID0gbGluay5uZXh0U3ViO1xuXHRcdFx0XHRcdGNvbnRpbnVlIHRvcDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0YnJlYWs7XG5cdFx0fSB3aGlsZSAodHJ1ZSk7XG5cdH1cblx0ZnVuY3Rpb24gY2hlY2tEaXJ0eShsaW5rLCBzdWIpIHtcblx0XHRsZXQgc3RhY2s7XG5cdFx0bGV0IGNoZWNrRGVwdGggPSAwO1xuXHRcdGxldCBkaXJ0eSA9IGZhbHNlO1xuXHRcdHRvcDogZG8ge1xuXHRcdFx0Y29uc3QgZGVwID0gbGluay5kZXA7XG5cdFx0XHRjb25zdCBmbGFncyA9IGRlcC5mbGFncztcblx0XHRcdGlmIChzdWIuZmxhZ3MgJiAxNikgZGlydHkgPSB0cnVlO1xuXHRcdFx0ZWxzZSBpZiAoKGZsYWdzICYgKDEgfCAxNikpID09PSAoMSB8IDE2KSkge1xuXHRcdFx0XHRpZiAodXBkYXRlKGRlcCkpIHtcblx0XHRcdFx0XHRjb25zdCBzdWJzID0gZGVwLnN1YnM7XG5cdFx0XHRcdFx0aWYgKHN1YnMubmV4dFN1YiAhPT0gdm9pZCAwKSBzaGFsbG93UHJvcGFnYXRlKHN1YnMpO1xuXHRcdFx0XHRcdGRpcnR5ID0gdHJ1ZTtcblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIGlmICgoZmxhZ3MgJiAoMSB8IDMyKSkgPT09ICgxIHwgMzIpKSB7XG5cdFx0XHRcdGlmIChsaW5rLm5leHRTdWIgIT09IHZvaWQgMCB8fCBsaW5rLnByZXZTdWIgIT09IHZvaWQgMCkgc3RhY2sgPSB7XG5cdFx0XHRcdFx0dmFsdWU6IGxpbmssXG5cdFx0XHRcdFx0cHJldjogc3RhY2tcblx0XHRcdFx0fTtcblx0XHRcdFx0bGluayA9IGRlcC5kZXBzO1xuXHRcdFx0XHRzdWIgPSBkZXA7XG5cdFx0XHRcdCsrY2hlY2tEZXB0aDtcblx0XHRcdFx0Y29udGludWU7XG5cdFx0XHR9XG5cdFx0XHRpZiAoIWRpcnR5KSB7XG5cdFx0XHRcdGNvbnN0IG5leHREZXAgPSBsaW5rLm5leHREZXA7XG5cdFx0XHRcdGlmIChuZXh0RGVwICE9PSB2b2lkIDApIHtcblx0XHRcdFx0XHRsaW5rID0gbmV4dERlcDtcblx0XHRcdFx0XHRjb250aW51ZTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0d2hpbGUgKGNoZWNrRGVwdGgtLSkge1xuXHRcdFx0XHRjb25zdCBmaXJzdFN1YiA9IHN1Yi5zdWJzO1xuXHRcdFx0XHRjb25zdCBoYXNNdWx0aXBsZVN1YnMgPSBmaXJzdFN1Yi5uZXh0U3ViICE9PSB2b2lkIDA7XG5cdFx0XHRcdGlmIChoYXNNdWx0aXBsZVN1YnMpIHtcblx0XHRcdFx0XHRsaW5rID0gc3RhY2sudmFsdWU7XG5cdFx0XHRcdFx0c3RhY2sgPSBzdGFjay5wcmV2O1xuXHRcdFx0XHR9IGVsc2UgbGluayA9IGZpcnN0U3ViO1xuXHRcdFx0XHRpZiAoZGlydHkpIHtcblx0XHRcdFx0XHRpZiAodXBkYXRlKHN1YikpIHtcblx0XHRcdFx0XHRcdGlmIChoYXNNdWx0aXBsZVN1YnMpIHNoYWxsb3dQcm9wYWdhdGUoZmlyc3RTdWIpO1xuXHRcdFx0XHRcdFx0c3ViID0gbGluay5zdWI7XG5cdFx0XHRcdFx0XHRjb250aW51ZTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0ZGlydHkgPSBmYWxzZTtcblx0XHRcdFx0fSBlbHNlIHN1Yi5mbGFncyAmPSB+MzI7XG5cdFx0XHRcdHN1YiA9IGxpbmsuc3ViO1xuXHRcdFx0XHRjb25zdCBuZXh0RGVwID0gbGluay5uZXh0RGVwO1xuXHRcdFx0XHRpZiAobmV4dERlcCAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdFx0bGluayA9IG5leHREZXA7XG5cdFx0XHRcdFx0Y29udGludWUgdG9wO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZGlydHk7XG5cdFx0fSB3aGlsZSAodHJ1ZSk7XG5cdH1cblx0ZnVuY3Rpb24gc2hhbGxvd1Byb3BhZ2F0ZShsaW5rKSB7XG5cdFx0ZG8ge1xuXHRcdFx0Y29uc3Qgc3ViID0gbGluay5zdWI7XG5cdFx0XHRjb25zdCBmbGFncyA9IHN1Yi5mbGFncztcblx0XHRcdGlmICgoZmxhZ3MgJiAoMzIgfCAxNikpID09PSAzMikge1xuXHRcdFx0XHRzdWIuZmxhZ3MgPSBmbGFncyB8IDE2O1xuXHRcdFx0XHRpZiAoKGZsYWdzICYgKDIgfCA0KSkgPT09IDIpIG5vdGlmeShzdWIpO1xuXHRcdFx0fVxuXHRcdH0gd2hpbGUgKChsaW5rID0gbGluay5uZXh0U3ViKSAhPT0gdm9pZCAwKTtcblx0fVxuXHRmdW5jdGlvbiBpc1ZhbGlkTGluayhjaGVja0xpbmssIHN1Yikge1xuXHRcdGxldCBsaW5rID0gc3ViLmRlcHNUYWlsO1xuXHRcdHdoaWxlIChsaW5rICE9PSB2b2lkIDApIHtcblx0XHRcdGlmIChsaW5rID09PSBjaGVja0xpbmspIHJldHVybiB0cnVlO1xuXHRcdFx0bGluayA9IGxpbmsucHJldkRlcDtcblx0XHR9XG5cdFx0cmV0dXJuIGZhbHNlO1xuXHR9XG59XG5cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgY3JlYXRlUmVhY3RpdmVTeXN0ZW0gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFsaWVuLmpzLm1hcCIsImltcG9ydCB7IGNyZWF0ZVJlYWN0aXZlU3lzdGVtIH0gZnJvbSBcIi4vYWxpZW4uanNcIjtcblxuLy8jcmVnaW9uIHNyYy9hdG9tLnRzXG5mdW5jdGlvbiB0b09ic2VydmVyKG5leHRIYW5kbGVyLCBlcnJvckhhbmRsZXIsIGNvbXBsZXRpb25IYW5kbGVyKSB7XG5cdGNvbnN0IGlzT2JzZXJ2ZXIgPSB0eXBlb2YgbmV4dEhhbmRsZXIgPT09IFwib2JqZWN0XCI7XG5cdGNvbnN0IHNlbGYgPSBpc09ic2VydmVyID8gbmV4dEhhbmRsZXIgOiB2b2lkIDA7XG5cdHJldHVybiB7XG5cdFx0bmV4dDogKGlzT2JzZXJ2ZXIgPyBuZXh0SGFuZGxlci5uZXh0IDogbmV4dEhhbmRsZXIpPy5iaW5kKHNlbGYpLFxuXHRcdGVycm9yOiAoaXNPYnNlcnZlciA/IG5leHRIYW5kbGVyLmVycm9yIDogZXJyb3JIYW5kbGVyKT8uYmluZChzZWxmKSxcblx0XHRjb21wbGV0ZTogKGlzT2JzZXJ2ZXIgPyBuZXh0SGFuZGxlci5jb21wbGV0ZSA6IGNvbXBsZXRpb25IYW5kbGVyKT8uYmluZChzZWxmKVxuXHR9O1xufVxuY29uc3QgcXVldWVkRWZmZWN0cyA9IFtdO1xubGV0IGN5Y2xlID0gMDtcbmNvbnN0IHsgbGluaywgdW5saW5rLCBwcm9wYWdhdGUsIGNoZWNrRGlydHksIHNoYWxsb3dQcm9wYWdhdGUgfSA9IC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVSZWFjdGl2ZVN5c3RlbSh7XG5cdHVwZGF0ZShhdG9tKSB7XG5cdFx0cmV0dXJuIGF0b20uX3VwZGF0ZSgpO1xuXHR9LFxuXHRub3RpZnkoZWZmZWN0KSB7XG5cdFx0cXVldWVkRWZmZWN0c1txdWV1ZWRFZmZlY3RzTGVuZ3RoKytdID0gZWZmZWN0O1xuXHRcdGVmZmVjdC5mbGFncyAmPSB+Mjtcblx0fSxcblx0dW53YXRjaGVkKGF0b20pIHtcblx0XHRpZiAoYXRvbS5kZXBzVGFpbCAhPT0gdm9pZCAwKSB7XG5cdFx0XHRhdG9tLmRlcHNUYWlsID0gdm9pZCAwO1xuXHRcdFx0YXRvbS5mbGFncyA9IDEgfCAxNjtcblx0XHRcdHB1cmdlRGVwcyhhdG9tKTtcblx0XHR9XG5cdH1cbn0pO1xubGV0IG5vdGlmeUluZGV4ID0gMDtcbmxldCBxdWV1ZWRFZmZlY3RzTGVuZ3RoID0gMDtcbmxldCBhY3RpdmVTdWI7XG5sZXQgYmF0Y2hEZXB0aCA9IDA7XG5mdW5jdGlvbiBiYXRjaChmbikge1xuXHR0cnkge1xuXHRcdCsrYmF0Y2hEZXB0aDtcblx0XHRmbigpO1xuXHR9IGZpbmFsbHkge1xuXHRcdGlmICghLS1iYXRjaERlcHRoKSBmbHVzaCgpO1xuXHR9XG59XG5mdW5jdGlvbiBwdXJnZURlcHMoc3ViKSB7XG5cdGNvbnN0IGRlcHNUYWlsID0gc3ViLmRlcHNUYWlsO1xuXHRsZXQgZGVwID0gZGVwc1RhaWwgIT09IHZvaWQgMCA/IGRlcHNUYWlsLm5leHREZXAgOiBzdWIuZGVwcztcblx0d2hpbGUgKGRlcCAhPT0gdm9pZCAwKSBkZXAgPSB1bmxpbmsoZGVwLCBzdWIpO1xufVxuZnVuY3Rpb24gZmx1c2goKSB7XG5cdGlmIChiYXRjaERlcHRoID4gMCkgcmV0dXJuO1xuXHR3aGlsZSAobm90aWZ5SW5kZXggPCBxdWV1ZWRFZmZlY3RzTGVuZ3RoKSB7XG5cdFx0Y29uc3QgZWZmZWN0ID0gcXVldWVkRWZmZWN0c1tub3RpZnlJbmRleF07XG5cdFx0cXVldWVkRWZmZWN0c1tub3RpZnlJbmRleCsrXSA9IHZvaWQgMDtcblx0XHRlZmZlY3Qubm90aWZ5KCk7XG5cdH1cblx0bm90aWZ5SW5kZXggPSAwO1xuXHRxdWV1ZWRFZmZlY3RzTGVuZ3RoID0gMDtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUFzeW5jQXRvbShnZXRWYWx1ZSwgb3B0aW9ucykge1xuXHRjb25zdCByZWYgPSB7fTtcblx0Y29uc3QgYXRvbSA9IGNyZWF0ZUF0b20oKCkgPT4ge1xuXHRcdGdldFZhbHVlKCkudGhlbigoZGF0YSkgPT4ge1xuXHRcdFx0Y29uc3QgaW50ZXJuYWxBdG9tID0gcmVmLmN1cnJlbnQ7XG5cdFx0XHRpZiAoaW50ZXJuYWxBdG9tLl91cGRhdGUoe1xuXHRcdFx0XHRzdGF0dXM6IFwiZG9uZVwiLFxuXHRcdFx0XHRkYXRhXG5cdFx0XHR9KSkge1xuXHRcdFx0XHRjb25zdCBzdWJzID0gaW50ZXJuYWxBdG9tLnN1YnM7XG5cdFx0XHRcdGlmIChzdWJzICE9PSB2b2lkIDApIHtcblx0XHRcdFx0XHRwcm9wYWdhdGUoc3Vicyk7XG5cdFx0XHRcdFx0c2hhbGxvd1Byb3BhZ2F0ZShzdWJzKTtcblx0XHRcdFx0XHRmbHVzaCgpO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSwgKGVycm9yKSA9PiB7XG5cdFx0XHRjb25zdCBpbnRlcm5hbEF0b20gPSByZWYuY3VycmVudDtcblx0XHRcdGlmIChpbnRlcm5hbEF0b20uX3VwZGF0ZSh7XG5cdFx0XHRcdHN0YXR1czogXCJlcnJvclwiLFxuXHRcdFx0XHRlcnJvclxuXHRcdFx0fSkpIHtcblx0XHRcdFx0Y29uc3Qgc3VicyA9IGludGVybmFsQXRvbS5zdWJzO1xuXHRcdFx0XHRpZiAoc3VicyAhPT0gdm9pZCAwKSB7XG5cdFx0XHRcdFx0cHJvcGFnYXRlKHN1YnMpO1xuXHRcdFx0XHRcdHNoYWxsb3dQcm9wYWdhdGUoc3Vicyk7XG5cdFx0XHRcdFx0Zmx1c2goKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0pO1xuXHRcdHJldHVybiB7IHN0YXR1czogXCJwZW5kaW5nXCIgfTtcblx0fSwgb3B0aW9ucyk7XG5cdHJlZi5jdXJyZW50ID0gYXRvbTtcblx0cmV0dXJuIGF0b207XG59XG5mdW5jdGlvbiBjcmVhdGVBdG9tKHZhbHVlT3JGbiwgb3B0aW9ucykge1xuXHRjb25zdCBpc0NvbXB1dGVkID0gdHlwZW9mIHZhbHVlT3JGbiA9PT0gXCJmdW5jdGlvblwiO1xuXHRjb25zdCBnZXR0ZXIgPSB2YWx1ZU9yRm47XG5cdGNvbnN0IGF0b20gPSB7XG5cdFx0X3NuYXBzaG90OiBpc0NvbXB1dGVkID8gdm9pZCAwIDogdmFsdWVPckZuLFxuXHRcdHN1YnM6IHZvaWQgMCxcblx0XHRzdWJzVGFpbDogdm9pZCAwLFxuXHRcdGRlcHM6IHZvaWQgMCxcblx0XHRkZXBzVGFpbDogdm9pZCAwLFxuXHRcdGZsYWdzOiBpc0NvbXB1dGVkID8gMCA6IDEsXG5cdFx0Z2V0KCkge1xuXHRcdFx0aWYgKGFjdGl2ZVN1YiAhPT0gdm9pZCAwKSBsaW5rKGF0b20sIGFjdGl2ZVN1YiwgY3ljbGUpO1xuXHRcdFx0cmV0dXJuIGF0b20uX3NuYXBzaG90O1xuXHRcdH0sXG5cdFx0c3Vic2NyaWJlKG9ic2VydmVyT3JGbikge1xuXHRcdFx0Y29uc3Qgb2JzID0gdG9PYnNlcnZlcihvYnNlcnZlck9yRm4pO1xuXHRcdFx0Y29uc3Qgb2JzZXJ2ZWQgPSB7IGN1cnJlbnQ6IGZhbHNlIH07XG5cdFx0XHRjb25zdCBlID0gZWZmZWN0KCgpID0+IHtcblx0XHRcdFx0YXRvbS5nZXQoKTtcblx0XHRcdFx0aWYgKCFvYnNlcnZlZC5jdXJyZW50KSBvYnNlcnZlZC5jdXJyZW50ID0gdHJ1ZTtcblx0XHRcdFx0ZWxzZSB7XG5cdFx0XHRcdFx0YWN0aXZlU3ViID0gdm9pZCAwO1xuXHRcdFx0XHRcdG9icy5uZXh0Py4oYXRvbS5fc25hcHNob3QpO1xuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHRcdHJldHVybiB7IHVuc3Vic2NyaWJlOiAoKSA9PiB7XG5cdFx0XHRcdGUuc3RvcCgpO1xuXHRcdFx0fSB9O1xuXHRcdH0sXG5cdFx0X3VwZGF0ZShnZXRWYWx1ZSkge1xuXHRcdFx0Y29uc3QgcHJldlN1YiA9IGFjdGl2ZVN1Yjtcblx0XHRcdGNvbnN0IGNvbXBhcmUgPSBvcHRpb25zPy5jb21wYXJlID8/IE9iamVjdC5pcztcblx0XHRcdGlmIChpc0NvbXB1dGVkKSB7XG5cdFx0XHRcdGFjdGl2ZVN1YiA9IGF0b207XG5cdFx0XHRcdCsrY3ljbGU7XG5cdFx0XHRcdGF0b20uZGVwc1RhaWwgPSB2b2lkIDA7XG5cdFx0XHR9IGVsc2UgaWYgKGdldFZhbHVlID09PSB2b2lkIDApIHJldHVybiBmYWxzZTtcblx0XHRcdGlmIChpc0NvbXB1dGVkKSBhdG9tLmZsYWdzID0gMSB8IDQ7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb25zdCBvbGRWYWx1ZSA9IGF0b20uX3NuYXBzaG90O1xuXHRcdFx0XHRjb25zdCBuZXdWYWx1ZSA9IHR5cGVvZiBnZXRWYWx1ZSA9PT0gXCJmdW5jdGlvblwiID8gZ2V0VmFsdWUob2xkVmFsdWUpIDogZ2V0VmFsdWUgPT09IHZvaWQgMCAmJiBpc0NvbXB1dGVkID8gZ2V0dGVyKG9sZFZhbHVlKSA6IGdldFZhbHVlO1xuXHRcdFx0XHRpZiAob2xkVmFsdWUgPT09IHZvaWQgMCB8fCAhY29tcGFyZShvbGRWYWx1ZSwgbmV3VmFsdWUpKSB7XG5cdFx0XHRcdFx0YXRvbS5fc25hcHNob3QgPSBuZXdWYWx1ZTtcblx0XHRcdFx0XHRyZXR1cm4gdHJ1ZTtcblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0XHR9IGZpbmFsbHkge1xuXHRcdFx0XHRhY3RpdmVTdWIgPSBwcmV2U3ViO1xuXHRcdFx0XHRpZiAoaXNDb21wdXRlZCkgYXRvbS5mbGFncyAmPSB+NDtcblx0XHRcdFx0cHVyZ2VEZXBzKGF0b20pO1xuXHRcdFx0fVxuXHRcdH1cblx0fTtcblx0aWYgKGlzQ29tcHV0ZWQpIHtcblx0XHRhdG9tLmZsYWdzID0gMSB8IDE2O1xuXHRcdGF0b20uZ2V0ID0gZnVuY3Rpb24oKSB7XG5cdFx0XHRjb25zdCBmbGFncyA9IGF0b20uZmxhZ3M7XG5cdFx0XHRpZiAoZmxhZ3MgJiAxNiB8fCBmbGFncyAmIDMyICYmIGNoZWNrRGlydHkoYXRvbS5kZXBzLCBhdG9tKSkge1xuXHRcdFx0XHRpZiAoYXRvbS5fdXBkYXRlKCkpIHtcblx0XHRcdFx0XHRjb25zdCBzdWJzID0gYXRvbS5zdWJzO1xuXHRcdFx0XHRcdGlmIChzdWJzICE9PSB2b2lkIDApIHNoYWxsb3dQcm9wYWdhdGUoc3Vicyk7XG5cdFx0XHRcdH1cblx0XHRcdH0gZWxzZSBpZiAoZmxhZ3MgJiAzMikgYXRvbS5mbGFncyA9IGZsYWdzICYgfjMyO1xuXHRcdFx0aWYgKGFjdGl2ZVN1YiAhPT0gdm9pZCAwKSBsaW5rKGF0b20sIGFjdGl2ZVN1YiwgY3ljbGUpO1xuXHRcdFx0cmV0dXJuIGF0b20uX3NuYXBzaG90O1xuXHRcdH07XG5cdH0gZWxzZSBhdG9tLnNldCA9IGZ1bmN0aW9uKHZhbHVlT3JGbikge1xuXHRcdGlmIChhdG9tLl91cGRhdGUodmFsdWVPckZuKSkge1xuXHRcdFx0Y29uc3Qgc3VicyA9IGF0b20uc3Vicztcblx0XHRcdGlmIChzdWJzICE9PSB2b2lkIDApIHtcblx0XHRcdFx0cHJvcGFnYXRlKHN1YnMpO1xuXHRcdFx0XHRzaGFsbG93UHJvcGFnYXRlKHN1YnMpO1xuXHRcdFx0XHRmbHVzaCgpO1xuXHRcdFx0fVxuXHRcdH1cblx0fTtcblx0cmV0dXJuIGF0b207XG59XG5mdW5jdGlvbiBlZmZlY3QoZm4pIHtcblx0Y29uc3QgcnVuID0gKCkgPT4ge1xuXHRcdGNvbnN0IHByZXZTdWIgPSBhY3RpdmVTdWI7XG5cdFx0YWN0aXZlU3ViID0gZWZmZWN0T2JqO1xuXHRcdCsrY3ljbGU7XG5cdFx0ZWZmZWN0T2JqLmRlcHNUYWlsID0gdm9pZCAwO1xuXHRcdGVmZmVjdE9iai5mbGFncyA9IDIgfCA0O1xuXHRcdHRyeSB7XG5cdFx0XHRyZXR1cm4gZm4oKTtcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0YWN0aXZlU3ViID0gcHJldlN1Yjtcblx0XHRcdGVmZmVjdE9iai5mbGFncyAmPSB+NDtcblx0XHRcdHB1cmdlRGVwcyhlZmZlY3RPYmopO1xuXHRcdH1cblx0fTtcblx0Y29uc3QgZWZmZWN0T2JqID0ge1xuXHRcdGRlcHM6IHZvaWQgMCxcblx0XHRkZXBzVGFpbDogdm9pZCAwLFxuXHRcdHN1YnM6IHZvaWQgMCxcblx0XHRzdWJzVGFpbDogdm9pZCAwLFxuXHRcdGZsYWdzOiAyIHwgNCxcblx0XHRub3RpZnkoKSB7XG5cdFx0XHRjb25zdCBmbGFncyA9IHRoaXMuZmxhZ3M7XG5cdFx0XHRpZiAoZmxhZ3MgJiAxNiB8fCBmbGFncyAmIDMyICYmIGNoZWNrRGlydHkodGhpcy5kZXBzLCB0aGlzKSkgcnVuKCk7XG5cdFx0XHRlbHNlIHRoaXMuZmxhZ3MgPSAyO1xuXHRcdH0sXG5cdFx0c3RvcCgpIHtcblx0XHRcdHRoaXMuZmxhZ3MgPSAwO1xuXHRcdFx0dGhpcy5kZXBzVGFpbCA9IHZvaWQgMDtcblx0XHRcdHB1cmdlRGVwcyh0aGlzKTtcblx0XHR9XG5cdH07XG5cdHJ1bigpO1xuXHRyZXR1cm4gZWZmZWN0T2JqO1xufVxuXG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGJhdGNoLCBjcmVhdGVBc3luY0F0b20sIGNyZWF0ZUF0b20sIGZsdXNoLCB0b09ic2VydmVyIH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1hdG9tLmpzLm1hcCIsImltcG9ydCB7IHVzZUNhbGxiYWNrIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyB1c2VTeW5jRXh0ZXJuYWxTdG9yZVdpdGhTZWxlY3RvciB9IGZyb20gXCJ1c2Utc3luYy1leHRlcm5hbC1zdG9yZS9zaGltL3dpdGgtc2VsZWN0b3JcIjtcblxuLy8jcmVnaW9uIHNyYy91c2VTZWxlY3Rvci50c1xuZnVuY3Rpb24gZGVmYXVsdENvbXBhcmUoYSwgYikge1xuXHRyZXR1cm4gYSA9PT0gYjtcbn1cbi8qKlxuKiBTZWxlY3RzIGEgc2xpY2Ugb2Ygc3RhdGUgZnJvbSBhbiBhdG9tIG9yIHN0b3JlIGFuZCBzdWJzY3JpYmVzIHRoZSBjb21wb25lbnRcbiogdG8gdGhhdCBzZWxlY3Rpb24uXG4qXG4qIFRoaXMgaXMgdGhlIHByaW1hcnkgUmVhY3QgcmVhZCBob29rIGZvciBUYW5TdGFjayBTdG9yZS4gSXQgd29ya3Mgd2l0aCBhbnlcbiogc291cmNlIHRoYXQgZXhwb3NlcyBgZ2V0KClgIGFuZCBgc3Vic2NyaWJlKClgLCBpbmNsdWRpbmcgYXRvbXMsIHJlYWRvbmx5XG4qIGF0b21zLCBzdG9yZXMsIGFuZCByZWFkb25seSBzdG9yZXMuXG4qXG4qIE9taXQgdGhlIHNlbGVjdG9yIHRvIHN1YnNjcmliZSB0byB0aGUgd2hvbGUgdmFsdWUuXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBjb25zdCBjb3VudCA9IHVzZVNlbGVjdG9yKGNvdW50ZXJTdG9yZSwgKHN0YXRlKSA9PiBzdGF0ZS5jb3VudClcbiogYGBgXG4qXG4qIEBleGFtcGxlXG4qIGBgYHRzeFxuKiBjb25zdCB2YWx1ZSA9IHVzZVNlbGVjdG9yKGNvdW50QXRvbSlcbiogYGBgXG4qL1xuZnVuY3Rpb24gdXNlU2VsZWN0b3Ioc291cmNlLCBzZWxlY3RvciA9IChzKSA9PiBzLCBvcHRpb25zKSB7XG5cdGNvbnN0IGNvbXBhcmUgPSBvcHRpb25zPy5jb21wYXJlID8/IGRlZmF1bHRDb21wYXJlO1xuXHRjb25zdCBzdWJzY3JpYmUgPSB1c2VDYWxsYmFjaygoaGFuZGxlU3RvcmVDaGFuZ2UpID0+IHtcblx0XHRjb25zdCB7IHVuc3Vic2NyaWJlIH0gPSBzb3VyY2Uuc3Vic2NyaWJlKGhhbmRsZVN0b3JlQ2hhbmdlKTtcblx0XHRyZXR1cm4gdW5zdWJzY3JpYmU7XG5cdH0sIFtzb3VyY2VdKTtcblx0Y29uc3QgZ2V0U25hcHNob3QgPSB1c2VDYWxsYmFjaygoKSA9PiBzb3VyY2UuZ2V0KCksIFtzb3VyY2VdKTtcblx0cmV0dXJuIHVzZVN5bmNFeHRlcm5hbFN0b3JlV2l0aFNlbGVjdG9yKHN1YnNjcmliZSwgZ2V0U25hcHNob3QsIGdldFNuYXBzaG90LCBzZWxlY3RvciwgY29tcGFyZSk7XG59XG5cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlU2VsZWN0b3IgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVNlbGVjdG9yLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgZHVtbXlNYXRjaENvbnRleHQsIG1hdGNoQ29udGV4dCB9IGZyb20gXCIuL21hdGNoQ29udGV4dC5qc1wiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBpbnZhcmlhbnQsIHJlcGxhY2VFcXVhbERlZXAgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtc3RvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlTWF0Y2gudHN4XG52YXIgZHVtbXlNYXRjaCA9IHt9O1xuZnVuY3Rpb24gdXNlU3RydWN0dXJhbFNoYXJpbmcob3B0cywgcm91dGVyKSB7XG5cdGNvbnN0IHByZXZpb3VzUmVzdWx0ID0gUmVhY3QkMS51c2VSZWYoKTtcblx0cmV0dXJuIChzbGljZSkgPT4ge1xuXHRcdGNvbnN0IHNlbGVjdGVkID0gb3B0cz8uc2VsZWN0ID8gb3B0cy5zZWxlY3Qoc2xpY2UpIDogc2xpY2U7XG5cdFx0aWYgKG9wdHM/LnN0cnVjdHVyYWxTaGFyaW5nID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRTdHJ1Y3R1cmFsU2hhcmluZykgcmV0dXJuIHByZXZpb3VzUmVzdWx0LmN1cnJlbnQgPSByZXBsYWNlRXF1YWxEZWVwKHByZXZpb3VzUmVzdWx0LmN1cnJlbnQsIHNlbGVjdGVkKTtcblx0XHRyZXR1cm4gc2VsZWN0ZWQ7XG5cdH07XG59XG4vKipcbiogUmVhZCBhbmQgc2VsZWN0IHRoZSBuZWFyZXN0IG9yIHRhcmdldGVkIHJvdXRlIG1hdGNoLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvdXNlTWF0Y2hIb29rXG4qL1xuZnVuY3Rpb24gdXNlTWF0Y2gob3B0cykge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0Y29uc3QgbmVhcmVzdFJvdXRlSWQgPSBSZWFjdCQxLnVzZUNvbnRleHQob3B0cy5mcm9tID8gZHVtbXlNYXRjaENvbnRleHQgOiBtYXRjaENvbnRleHQpO1xuXHRjb25zdCByb3V0ZUlkID0gb3B0cy5mcm9tID8/IG5lYXJlc3RSb3V0ZUlkO1xuXHRjb25zdCBtYXRjaFN0b3JlID0gcm91dGVyLnN0b3Jlcy5nZXRNYXRjaFN0b3JlKHJvdXRlSWQpO1xuXHRpZiAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSB7XG5cdFx0Y29uc3QgbWF0Y2ggPSBtYXRjaFN0b3JlLmdldCgpO1xuXHRcdGlmICghbWF0Y2gpIHtcblx0XHRcdGlmIChvcHRzLnNob3VsZFRocm93ID8/IHRydWUpIHtcblx0XHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgdGhyb3cgbmV3IEVycm9yKGBJbnZhcmlhbnQgZmFpbGVkOiBDb3VsZCBub3QgZmluZCAke29wdHMuZnJvbSA/IGBhbiBhY3RpdmUgbWF0Y2ggZnJvbSBcIiR7b3B0cy5mcm9tfVwiYCA6IFwiYSBuZWFyZXN0IG1hdGNoIVwifWApO1xuXHRcdFx0XHRpbnZhcmlhbnQoKTtcblx0XHRcdH1cblx0XHRcdHJldHVybjtcblx0XHR9XG5cdFx0cmV0dXJuIG9wdHMuc2VsZWN0ID8gb3B0cy5zZWxlY3QobWF0Y2gpIDogbWF0Y2g7XG5cdH1cblx0Y29uc3Qgc2VsZWN0b3IgPSB1c2VTdHJ1Y3R1cmFsU2hhcmluZyhvcHRzLCByb3V0ZXIpO1xuXHRjb25zdCBtYXRjaFNlbGVjdGlvbiA9IHVzZVNlbGVjdG9yKG1hdGNoU3RvcmUsIChtYXRjaCkgPT4gbWF0Y2ggPyBzZWxlY3RvcihtYXRjaCkgOiBkdW1teU1hdGNoKTtcblx0aWYgKG1hdGNoU2VsZWN0aW9uICE9PSBkdW1teU1hdGNoKSByZXR1cm4gbWF0Y2hTZWxlY3Rpb247XG5cdGlmIChvcHRzLnNob3VsZFRocm93ID8/IHRydWUpIHtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0aHJvdyBuZXcgRXJyb3IoYEludmFyaWFudCBmYWlsZWQ6IENvdWxkIG5vdCBmaW5kICR7b3B0cy5mcm9tID8gYGFuIGFjdGl2ZSBtYXRjaCBmcm9tIFwiJHtvcHRzLmZyb219XCJgIDogXCJhIG5lYXJlc3QgbWF0Y2ghXCJ9YCk7XG5cdFx0aW52YXJpYW50KCk7XG5cdH1cbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlTWF0Y2gsIHVzZVN0cnVjdHVyYWxTaGFyaW5nIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZU1hdGNoLmpzLm1hcCIsImltcG9ydCB7IHVzZU1hdGNoIH0gZnJvbSBcIi4vdXNlTWF0Y2guanNcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlTG9hZGVyRGF0YS50c3hcbi8qKlxuKiBSZWFkIGFuZCBzZWxlY3QgdGhlIGN1cnJlbnQgcm91dGUncyBsb2FkZXIgZGF0YSB3aXRoIHR5cGXigJFzYWZldHkuXG4qXG4qIE9wdGlvbnM6XG4qIC0gYGZyb21gL2BzdHJpY3RgOiBDaG9vc2Ugd2hpY2ggcm91dGUncyBkYXRhIHRvIHJlYWQgYW5kIHN0cmljdG5lc3NcbiogLSBgc2VsZWN0YDogTWFwIHRoZSBsb2FkZXIgZGF0YSB0byBhIGRlcml2ZWQgdmFsdWVcbiogLSBgc3RydWN0dXJhbFNoYXJpbmdgOiBFbmFibGUgc3RydWN0dXJhbCBzaGFyaW5nIGZvciBzdGFibGUgcmVmZXJlbmNlc1xuKlxuKiBAcmV0dXJucyBUaGUgbG9hZGVyIGRhdGEgKG9yIHNlbGVjdGVkIHZhbHVlKSBmb3IgdGhlIG1hdGNoZWQgcm91dGUuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci91c2VMb2FkZXJEYXRhSG9va1xuKi9cbmZ1bmN0aW9uIHVzZUxvYWRlckRhdGEob3B0cykge1xuXHRyZXR1cm4gdXNlTWF0Y2goe1xuXHRcdGZyb206IG9wdHMuZnJvbSxcblx0XHRzdHJpY3Q6IG9wdHMuc3RyaWN0LFxuXHRcdHN0cnVjdHVyYWxTaGFyaW5nOiBvcHRzLnN0cnVjdHVyYWxTaGFyaW5nLFxuXHRcdHNlbGVjdDogKG1hdGNoKSA9PiB7XG5cdFx0XHRyZXR1cm4gb3B0cy5zZWxlY3QgPyBvcHRzLnNlbGVjdChtYXRjaC5sb2FkZXJEYXRhKSA6IG1hdGNoLmxvYWRlckRhdGE7XG5cdFx0fVxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlTG9hZGVyRGF0YSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VMb2FkZXJEYXRhLmpzLm1hcCIsImltcG9ydCB7IHVzZU1hdGNoIH0gZnJvbSBcIi4vdXNlTWF0Y2guanNcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlTG9hZGVyRGVwcy50c3hcbi8qKlxuKiBSZWFkIGFuZCBzZWxlY3QgdGhlIGN1cnJlbnQgcm91dGUncyBsb2FkZXIgZGVwZW5kZW5jaWVzIG9iamVjdC5cbipcbiogT3B0aW9uczpcbiogLSBgZnJvbWA6IENob29zZSB3aGljaCByb3V0ZSdzIGxvYWRlciBkZXBzIHRvIHJlYWRcbiogLSBgc2VsZWN0YDogTWFwIHRoZSBkZXBzIHRvIGEgZGVyaXZlZCB2YWx1ZVxuKiAtIGBzdHJ1Y3R1cmFsU2hhcmluZ2A6IEVuYWJsZSBzdHJ1Y3R1cmFsIHNoYXJpbmcgZm9yIHN0YWJsZSByZWZlcmVuY2VzXG4qXG4qIEByZXR1cm5zIFRoZSBsb2FkZXIgZGVwcyAob3Igc2VsZWN0ZWQgdmFsdWUpIGZvciB0aGUgbWF0Y2hlZCByb3V0ZS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL3VzZUxvYWRlckRlcHNIb29rXG4qL1xuZnVuY3Rpb24gdXNlTG9hZGVyRGVwcyhvcHRzKSB7XG5cdGNvbnN0IHsgc2VsZWN0LCAuLi5yZXN0IH0gPSBvcHRzO1xuXHRyZXR1cm4gdXNlTWF0Y2goe1xuXHRcdC4uLnJlc3QsXG5cdFx0c2VsZWN0OiAobWF0Y2gpID0+IHtcblx0XHRcdHJldHVybiBzZWxlY3QgPyBzZWxlY3QobWF0Y2gubG9hZGVyRGVwcykgOiBtYXRjaC5sb2FkZXJEZXBzO1xuXHRcdH1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZUxvYWRlckRlcHMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlTG9hZGVyRGVwcy5qcy5tYXAiLCJpbXBvcnQgeyB1c2VNYXRjaCB9IGZyb20gXCIuL3VzZU1hdGNoLmpzXCI7XG4vLyNyZWdpb24gc3JjL3VzZVBhcmFtcy50c3hcbi8qKlxuKiBBY2Nlc3MgdGhlIGN1cnJlbnQgcm91dGUncyBwYXRoIHBhcmFtZXRlcnMgd2l0aCB0eXBlLXNhZmV0eS5cbipcbiogT3B0aW9uczpcbiogLSBgZnJvbWAvYHN0cmljdGA6IFNwZWNpZnkgdGhlIG1hdGNoZWQgcm91dGUgYW5kIHdoZXRoZXIgdG8gZW5mb3JjZSBzdHJpY3QgdHlwaW5nXG4qIC0gYHNlbGVjdGA6IFByb2plY3QgdGhlIHBhcmFtcyBvYmplY3QgdG8gYSBkZXJpdmVkIHZhbHVlIGZvciBtZW1vaXplZCByZW5kZXJzXG4qIC0gYHN0cnVjdHVyYWxTaGFyaW5nYDogRW5hYmxlIHN0cnVjdHVyYWwgc2hhcmluZyBmb3Igc3RhYmxlIHJlZmVyZW5jZXNcbiogLSBgc2hvdWxkVGhyb3dgOiBUaHJvdyBpZiB0aGUgcm91dGUgaXMgbm90IGZvdW5kIGluIHN0cmljdCBjb250ZXh0c1xuKlxuKiBAcmV0dXJucyBUaGUgcGFyYW1zIG9iamVjdCAob3Igc2VsZWN0ZWQgdmFsdWUpIGZvciB0aGUgbWF0Y2hlZCByb3V0ZS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL3VzZVBhcmFtc0hvb2tcbiovXG5mdW5jdGlvbiB1c2VQYXJhbXMob3B0cykge1xuXHRyZXR1cm4gdXNlTWF0Y2goe1xuXHRcdGZyb206IG9wdHMuZnJvbSxcblx0XHRzaG91bGRUaHJvdzogb3B0cy5zaG91bGRUaHJvdyxcblx0XHRzdHJ1Y3R1cmFsU2hhcmluZzogb3B0cy5zdHJ1Y3R1cmFsU2hhcmluZyxcblx0XHRzdHJpY3Q6IG9wdHMuc3RyaWN0LFxuXHRcdHNlbGVjdDogKG1hdGNoKSA9PiB7XG5cdFx0XHRjb25zdCBwYXJhbXMgPSBvcHRzLnN0cmljdCA9PT0gZmFsc2UgPyBtYXRjaC5wYXJhbXMgOiBtYXRjaC5fc3RyaWN0UGFyYW1zO1xuXHRcdFx0cmV0dXJuIG9wdHMuc2VsZWN0ID8gb3B0cy5zZWxlY3QocGFyYW1zKSA6IHBhcmFtcztcblx0XHR9XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VQYXJhbXMgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlUGFyYW1zLmpzLm1hcCIsImltcG9ydCB7IHVzZU1hdGNoIH0gZnJvbSBcIi4vdXNlTWF0Y2guanNcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlU2VhcmNoLnRzeFxuLyoqXG4qIFJlYWQgYW5kIHNlbGVjdCB0aGUgY3VycmVudCByb3V0ZSdzIHNlYXJjaCBwYXJhbWV0ZXJzIHdpdGggdHlwZS1zYWZldHkuXG4qXG4qIE9wdGlvbnM6XG4qIC0gYGZyb21gL2BzdHJpY3RgOiBDb250cm9sIHdoaWNoIHJvdXRlJ3Mgc2VhcmNoIGlzIHJlYWQgYW5kIGhvdyBzdHJpY3RseSBpdCdzIHR5cGVkXG4qIC0gYHNlbGVjdGA6IE1hcCB0aGUgc2VhcmNoIG9iamVjdCB0byBhIGRlcml2ZWQgdmFsdWUgZm9yIHJlbmRlciBvcHRpbWl6YXRpb25cbiogLSBgc3RydWN0dXJhbFNoYXJpbmdgOiBFbmFibGUgc3RydWN0dXJhbCBzaGFyaW5nIGZvciBzdGFibGUgcmVmZXJlbmNlc1xuKiAtIGBzaG91bGRUaHJvd2A6IFRocm93IHdoZW4gdGhlIHJvdXRlIGlzIG5vdCBmb3VuZCAoc3RyaWN0IGNvbnRleHRzKVxuKlxuKiBAcmV0dXJucyBUaGUgc2VhcmNoIG9iamVjdCAob3Igc2VsZWN0ZWQgdmFsdWUpIGZvciB0aGUgbWF0Y2hlZCByb3V0ZS5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL3VzZVNlYXJjaEhvb2tcbiovXG5mdW5jdGlvbiB1c2VTZWFyY2gob3B0cykge1xuXHRyZXR1cm4gdXNlTWF0Y2goe1xuXHRcdGZyb206IG9wdHMuZnJvbSxcblx0XHRzdHJpY3Q6IG9wdHMuc3RyaWN0LFxuXHRcdHNob3VsZFRocm93OiBvcHRzLnNob3VsZFRocm93LFxuXHRcdHN0cnVjdHVyYWxTaGFyaW5nOiBvcHRzLnN0cnVjdHVyYWxTaGFyaW5nLFxuXHRcdHNlbGVjdDogKG1hdGNoKSA9PiB7XG5cdFx0XHRyZXR1cm4gb3B0cy5zZWxlY3QgPyBvcHRzLnNlbGVjdChtYXRjaC5zZWFyY2gpIDogbWF0Y2guc2VhcmNoO1xuXHRcdH1cblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZVNlYXJjaCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VTZWFyY2guanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VMYXlvdXRFZmZlY3QgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuLy8jcmVnaW9uIHNyYy91c2VOYXZpZ2F0ZS50c3hcbi8qKlxuKiBJbXBlcmF0aXZlIG5hdmlnYXRpb24gaG9vay5cbipcbiogUmV0dXJucyBhIHN0YWJsZSBgbmF2aWdhdGUob3B0aW9ucylgIGZ1bmN0aW9uIHRvIGNoYW5nZSB0aGUgY3VycmVudCBsb2NhdGlvblxuKiBwcm9ncmFtbWF0aWNhbGx5LiBQcmVmZXIgdGhlIGBMaW5rYCBjb21wb25lbnQgZm9yIHVzZXItaW5pdGlhdGVkIG5hdmlnYXRpb24sXG4qIGFuZCB1c2UgdGhpcyBob29rIGZyb20gZWZmZWN0cywgY2FsbGJhY2tzLCBvciBoYW5kbGVycyB3aGVyZSBpbXBlcmF0aXZlXG4qIG5hdmlnYXRpb24gaXMgcmVxdWlyZWQuXG4qXG4qIE9wdGlvbnM6XG4qIC0gYGZyb21gOiBPcHRpb25hbCByb3V0ZSBiYXNlIHVzZWQgdG8gcmVzb2x2ZSByZWxhdGl2ZSBgdG9gIHBhdGhzLlxuKlxuKiBAcmV0dXJucyBBIGZ1bmN0aW9uIHRoYXQgYWNjZXB0cyBgTmF2aWdhdGVPcHRpb25zYC5cbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL3VzZU5hdmlnYXRlSG9va1xuKi9cbmZ1bmN0aW9uIHVzZU5hdmlnYXRlKF9kZWZhdWx0T3B0cykge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0cmV0dXJuIFJlYWN0JDEudXNlQ2FsbGJhY2soKG9wdGlvbnMpID0+IHtcblx0XHRyZXR1cm4gcm91dGVyLm5hdmlnYXRlKHtcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRmcm9tOiBvcHRpb25zLmZyb20gPz8gX2RlZmF1bHRPcHRzPy5mcm9tXG5cdFx0fSk7XG5cdH0sIFtfZGVmYXVsdE9wdHM/LmZyb20sIHJvdXRlcl0pO1xufVxuLyoqXG4qIENvbXBvbmVudCB0aGF0IHRyaWdnZXJzIGEgbmF2aWdhdGlvbiB3aGVuIHJlbmRlcmVkLiBOYXZpZ2F0aW9uIGV4ZWN1dGVzXG4qIGluIGFuIGVmZmVjdCBhZnRlciBtb3VudC91cGRhdGUuXG4qXG4qIFByb3BzIGFyZSB0aGUgc2FtZSBhcyBgTmF2aWdhdGVPcHRpb25zYCB1c2VkIGJ5IGBuYXZpZ2F0ZSgpYC5cbipcbiogQHJldHVybnMgbnVsbFxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvbmF2aWdhdGVDb21wb25lbnRcbiovXG5mdW5jdGlvbiBOYXZpZ2F0ZShwcm9wcykge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0Y29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xuXHRjb25zdCBwcmV2aW91c1Byb3BzUmVmID0gUmVhY3QkMS51c2VSZWYobnVsbCk7XG5cdHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XG5cdFx0aWYgKHByZXZpb3VzUHJvcHNSZWYuY3VycmVudCAhPT0gcHJvcHMpIHtcblx0XHRcdG5hdmlnYXRlKHByb3BzKTtcblx0XHRcdHByZXZpb3VzUHJvcHNSZWYuY3VycmVudCA9IHByb3BzO1xuXHRcdH1cblx0fSwgW1xuXHRcdHJvdXRlcixcblx0XHRwcm9wcyxcblx0XHRuYXZpZ2F0ZVxuXHRdKTtcblx0cmV0dXJuIG51bGw7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IE5hdmlnYXRlLCB1c2VOYXZpZ2F0ZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VOYXZpZ2F0ZS5qcy5tYXAiLCJpbXBvcnQgeyB1c2VNYXRjaCB9IGZyb20gXCIuL3VzZU1hdGNoLmpzXCI7XG4vLyNyZWdpb24gc3JjL3VzZVJvdXRlQ29udGV4dC50c1xuZnVuY3Rpb24gdXNlUm91dGVDb250ZXh0KG9wdHMpIHtcblx0cmV0dXJuIHVzZU1hdGNoKHtcblx0XHQuLi5vcHRzLFxuXHRcdHNlbGVjdDogKG1hdGNoKSA9PiBvcHRzLnNlbGVjdCA/IG9wdHMuc2VsZWN0KG1hdGNoLmNvbnRleHQpIDogbWF0Y2guY29udGV4dFxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlUm91dGVDb250ZXh0IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVJvdXRlQ29udGV4dC5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IGNyZWF0ZUxpbmtTY29wZSwgbWF0Y2hDb250ZXh0IH0gZnJvbSBcIi4vbWF0Y2hDb250ZXh0LmpzXCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IGRlZXBFcXVhbCwgZnVuY3Rpb25hbFVwZGF0ZSwgZ2V0VXJsU2NoZW1lLCBpc0Rhbmdlcm91c1Byb3RvY29sLCBwcmVsb2FkV2FybmluZywgcmVtb3ZlVHJhaWxpbmdTbGFzaCB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmUvaXNTZXJ2ZXJcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9saW5rLnRzeFxuZnVuY3Rpb24gdXNlU3RhYmxlVmFsdWVzKC4uLnZhbHVlcykge1xuXHRjb25zdCByZWYgPSBSZWFjdCQxLnVzZVJlZih2YWx1ZXMpO1xuXHRjb25zdCBzdGFibGUgPSByZWYuY3VycmVudDtcblx0dmFsdWVzLmZvckVhY2goKHZhbHVlLCBpbmRleCkgPT4ge1xuXHRcdGlmICghZGVlcEVxdWFsKHN0YWJsZVtpbmRleF0sIHZhbHVlLCBmYWxzZSwgdHJ1ZSkpIHN0YWJsZVtpbmRleF0gPSB2YWx1ZTtcblx0fSk7XG5cdHJldHVybiByZWYuY3VycmVudDtcbn1cbmZ1bmN0aW9uIHByZWxvYWRMaW5rKHJvdXRlciwgb3B0aW9ucykge1xuXHRyb3V0ZXIucHJlbG9hZFJvdXRlKG9wdGlvbnMpLmNhdGNoKChlcnIpID0+IHtcblx0XHRjb25zb2xlLndhcm4oZXJyKTtcblx0XHRjb25zb2xlLndhcm4ocHJlbG9hZFdhcm5pbmcpO1xuXHR9KTtcbn1cbmZ1bmN0aW9uIHJlc29sdmVFeHRlcm5hbExpbmsodG8sIHByb3RvY29sQWxsb3dsaXN0KSB7XG5cdGNvbnN0IHNjaGVtZSA9IHR5cGVvZiB0byA9PT0gXCJzdHJpbmdcIiAmJiBnZXRVcmxTY2hlbWUodG8pO1xuXHRpZiAoIXNjaGVtZSkgcmV0dXJuO1xuXHRpZiAoIXByb3RvY29sQWxsb3dsaXN0LmhhcyhzY2hlbWUpKSB7XG5cdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgY29uc29sZS53YXJuKGBCbG9ja2VkIExpbmsgd2l0aCBkYW5nZXJvdXMgcHJvdG9jb2w6ICR7dG99YCk7XG5cdFx0cmV0dXJuIG51bGw7XG5cdH1cblx0cmV0dXJuIHRvO1xufVxuZnVuY3Rpb24gcmVzb2x2ZUlzQWN0aXZlKGxvY2F0aW9uLCBuZXh0LCBhY3RpdmVPcHRpb25zLCBiYXNlcGF0aCkge1xuXHRjb25zdCBjdXJyZW50UGF0aCA9IHJlbW92ZVRyYWlsaW5nU2xhc2gobG9jYXRpb24ucGF0aG5hbWUsIGJhc2VwYXRoKTtcblx0Y29uc3QgbmV4dFBhdGggPSByZW1vdmVUcmFpbGluZ1NsYXNoKG5leHQucGF0aG5hbWUsIGJhc2VwYXRoKTtcblx0aWYgKGFjdGl2ZU9wdGlvbnM/LmV4YWN0ID8gY3VycmVudFBhdGggIT09IG5leHRQYXRoIDogIShjdXJyZW50UGF0aC5zdGFydHNXaXRoKG5leHRQYXRoKSAmJiAoY3VycmVudFBhdGgubGVuZ3RoID09PSBuZXh0UGF0aC5sZW5ndGggfHwgY3VycmVudFBhdGhbbmV4dFBhdGgubGVuZ3RoXSA9PT0gXCIvXCIpKSkgcmV0dXJuIGZhbHNlO1xuXHRpZiAoYWN0aXZlT3B0aW9ucz8uaW5jbHVkZVNlYXJjaCA/PyB0cnVlKSB7XG5cdFx0aWYgKCFkZWVwRXF1YWwobG9jYXRpb24uc2VhcmNoLCBuZXh0LnNlYXJjaCwgIWFjdGl2ZU9wdGlvbnM/LmV4YWN0LCBhY3RpdmVPcHRpb25zPy5leHBsaWNpdFVuZGVmaW5lZCkpIHJldHVybiBmYWxzZTtcblx0fVxuXHRyZXR1cm4gIWFjdGl2ZU9wdGlvbnM/LmluY2x1ZGVIYXNoIHx8IGxvY2F0aW9uLmhhc2ggPT09IG5leHQuaGFzaDtcbn1cbmZ1bmN0aW9uIHVzZUxpbmtQcm9wcyhvcHRpb25zLCBmb3J3YXJkZWRSZWYsIGhvc3QpIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHJldHVybiBnZXRTZXJ2ZXJMaW5rUHJvcHMocm91dGVyLCBvcHRpb25zLCBmb3J3YXJkZWRSZWYsIGhvc3QpO1xuXHRjb25zdCBpbm5lclJlZiA9IFJlYWN0JDEudXNlUmVmKG51bGwpO1xuXHRjb25zdCBtZXJnZWRSZWYgPSBSZWFjdCQxLnVzZUNhbGxiYWNrKChlbGVtZW50KSA9PiB7XG5cdFx0aW5uZXJSZWYuY3VycmVudCA9IGVsZW1lbnQ7XG5cdFx0aWYgKHR5cGVvZiBmb3J3YXJkZWRSZWYgPT09IFwiZnVuY3Rpb25cIikgcmV0dXJuIGZvcndhcmRlZFJlZihlbGVtZW50KTtcblx0XHRpZiAoZm9yd2FyZGVkUmVmKSBmb3J3YXJkZWRSZWYuY3VycmVudCA9IGVsZW1lbnQ7XG5cdH0sIFtmb3J3YXJkZWRSZWZdKTtcblx0Y29uc3QgeyBhY3RpdmVPcHRpb25zLCB0bywgcHJlbG9hZDogdXNlclByZWxvYWQsIHByZWxvYWREZWxheTogdXNlclByZWxvYWREZWxheSwgZGlzYWJsZWQsIHRhcmdldCwgb25DbGljaywgb25CbHVyLCBvbkZvY3VzLCBvbk1vdXNlRW50ZXIsIG9uTW91c2VMZWF2ZSwgb25Ub3VjaFN0YXJ0IH0gPSBvcHRpb25zO1xuXHRjb25zdCBbc3RhYmxlU2VhcmNoLCBzdGFibGVQYXJhbXMsIHN0YWJsZUFjdGl2ZU9wdGlvbnNdID0gdXNlU3RhYmxlVmFsdWVzKG9wdGlvbnMuc2VhcmNoLCBvcHRpb25zLnBhcmFtcywgYWN0aXZlT3B0aW9ucyk7XG5cdGNvbnN0IHJvdXRlSWQgPSBSZWFjdCQxLnVzZUNvbnRleHQobWF0Y2hDb250ZXh0KTtcblx0Y29uc3Qgc2NvcGUgPSAocm91dGVyLnN0b3Jlcy5fbGlua1Njb3BlcyA/Pz0ge30pW3JvdXRlSWRdID8/PSBjcmVhdGVMaW5rU2NvcGUocm91dGVyLCByb3V0ZUlkKTtcblx0Y29uc3QgW2Rlc3QsIGdldExpbmtTdGF0ZSwgZ2V0SHlkcmF0aW9uU3RhdGVdID0gUmVhY3QkMS51c2VNZW1vKCgpID0+IHtcblx0XHRjb25zdCBkaXJlY3RFeHRlcm5hbExpbmsgPSByZXNvbHZlRXh0ZXJuYWxMaW5rKHRvLCByb3V0ZXIucHJvdG9jb2xBbGxvd2xpc3QpO1xuXHRcdGlmIChkaXJlY3RFeHRlcm5hbExpbmsgIT09IHZvaWQgMCkge1xuXHRcdFx0Y29uc3Qgc3RhdGUgPSBbZGlyZWN0RXh0ZXJuYWxMaW5rID8/IHZvaWQgMF07XG5cdFx0XHRyZXR1cm4gW29wdGlvbnMsICgpID0+IHN0YXRlXTtcblx0XHR9XG5cdFx0Y29uc3QgZGVzdCA9IHsgLi4ub3B0aW9ucyB9O1xuXHRcdGxldCBzb3VyY2U7XG5cdFx0bGV0IHN0YXRlO1xuXHRcdGxldCBoeWRyYXRpb25TdGF0ZTtcblx0XHRjb25zdCBnZXRMaW5rU3RhdGUgPSAoKSA9PiB7XG5cdFx0XHRjb25zdCBsb2NhdGlvbiA9IHNjb3BlWzBdKCk7XG5cdFx0XHRpZiAobG9jYXRpb24gIT09IHNvdXJjZSkge1xuXHRcdFx0XHRkZXN0Ll9mcm9tTG9jYXRpb24gPSBsb2NhdGlvbjtcblx0XHRcdFx0Y29uc3QgbmV4dCA9IHJvdXRlci5idWlsZExvY2F0aW9uKGRlc3QpO1xuXHRcdFx0XHRjb25zdCBocmVmID0gZ2V0SHJlZk9wdGlvbihuZXh0LCByb3V0ZXIsIGRpc2FibGVkKTtcblx0XHRcdFx0Y29uc3QgaXNBY3RpdmUgPSBkaXNhYmxlZCB8fCBocmVmICYmICFnZXRVcmxTY2hlbWUoaHJlZikgPyByZXNvbHZlSXNBY3RpdmUobG9jYXRpb24sIG5leHQsIHN0YWJsZUFjdGl2ZU9wdGlvbnMsIHJvdXRlci5iYXNlcGF0aCkgOiB2b2lkIDA7XG5cdFx0XHRcdGlmICghc3RhdGUgfHwgc3RhdGVbMF0gIT09IGhyZWYgfHwgc3RhdGVbMV0gIT09IGlzQWN0aXZlKSBzdGF0ZSA9IFtocmVmLCBpc0FjdGl2ZV07XG5cdFx0XHRcdHNvdXJjZSA9IGxvY2F0aW9uO1xuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIHN0YXRlO1xuXHRcdH07XG5cdFx0cmV0dXJuIFtcblx0XHRcdGRlc3QsXG5cdFx0XHRnZXRMaW5rU3RhdGUsXG5cdFx0XHRzdGFibGVBY3RpdmVPcHRpb25zPy5pbmNsdWRlSGFzaCAmJiAoKCkgPT4ge1xuXHRcdFx0XHRjb25zdCBzdGF0ZSA9IGdldExpbmtTdGF0ZSgpO1xuXHRcdFx0XHRyZXR1cm4gc3RhdGVbMV0gPyBoeWRyYXRpb25TdGF0ZSA/Pz0gW3N0YXRlWzBdLCBmYWxzZV0gOiBzdGF0ZTtcblx0XHRcdH0pXG5cdFx0XTtcblx0fSwgW1xuXHRcdHJvdXRlcixcblx0XHRzY29wZSxcblx0XHRvcHRpb25zLmZyb20sXG5cdFx0b3B0aW9ucy5oYXNoLFxuXHRcdG9wdGlvbnMuaHJlZixcblx0XHR0byxcblx0XHRzdGFibGVTZWFyY2gsXG5cdFx0c3RhYmxlUGFyYW1zLFxuXHRcdG9wdGlvbnMuc3RhdGUsXG5cdFx0b3B0aW9ucy5tYXNrLFxuXHRcdG9wdGlvbnMudW5zYWZlUmVsYXRpdmUsXG5cdFx0c3RhYmxlQWN0aXZlT3B0aW9ucyxcblx0XHRkaXNhYmxlZFxuXHRdKTtcblx0Y29uc3QgW2hyZWYsIGlzQWN0aXZlXSA9IFJlYWN0JDEudXNlU3luY0V4dGVybmFsU3RvcmUoc2NvcGVbMV0sIGdldExpbmtTdGF0ZSwgZ2V0SHlkcmF0aW9uU3RhdGUgfHwgZ2V0TGlua1N0YXRlKTtcblx0Y29uc3QgZXh0ZXJuYWxMaW5rID0gaXNBY3RpdmUgPT09IHZvaWQgMCAmJiBocmVmO1xuXHRjb25zdCBsaW5rRGlzYWJsZWQgPSBkaXNhYmxlZCB8fCBocmVmID09PSB2b2lkIDA7XG5cdGNvbnN0IGhhc1JlbmRlckZldGNoZWQgPSBSZWFjdCQxLnVzZVJlZihmYWxzZSk7XG5cdGNvbnN0IHByZWxvYWQgPSBvcHRpb25zLnJlbG9hZERvY3VtZW50IHx8IGV4dGVybmFsTGluayB8fCBsaW5rRGlzYWJsZWQgPyBmYWxzZSA6IHVzZXJQcmVsb2FkID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRQcmVsb2FkO1xuXHRjb25zdCBwcmVsb2FkRGVsYXkgPSB1c2VyUHJlbG9hZERlbGF5ID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRQcmVsb2FkRGVsYXkgPz8gMDtcblx0Y29uc3QgZW5xdWV1ZVByZWxvYWQgPSBSZWFjdCQxLnVzZUNhbGxiYWNrKChlKSA9PiB7XG5cdFx0Y29uc3QgaXNJbnRlcnNlY3RpbmcgPSBlPy5pc0ludGVyc2VjdGluZztcblx0XHRpZiAoIShpc0ludGVyc2VjdGluZyA/PyBwcmVsb2FkID09PSBcImludGVudFwiKSkge1xuXHRcdFx0aWYgKGlzSW50ZXJzZWN0aW5nID09PSBmYWxzZSkgY2FuY2VsUHJlbG9hZChpbm5lclJlZik7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmICghcHJlbG9hZERlbGF5KSB7XG5cdFx0XHRwcmVsb2FkTGluayhyb3V0ZXIsIGRlc3QpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRpbm5lclJlZi50ID8/PSBzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdGlubmVyUmVmLnQgPSB2b2lkIDA7XG5cdFx0XHRwcmVsb2FkTGluayhyb3V0ZXIsIGRlc3QpO1xuXHRcdH0sIHByZWxvYWREZWxheSk7XG5cdH0sIFtcblx0XHRyb3V0ZXIsXG5cdFx0ZGVzdCxcblx0XHRpbm5lclJlZixcblx0XHRwcmVsb2FkLFxuXHRcdHByZWxvYWREZWxheVxuXHRdKTtcblx0UmVhY3QkMS51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGlmICghcHJlbG9hZCkgcmV0dXJuO1xuXHRcdGlmIChwcmVsb2FkID09PSBcInJlbmRlclwiICYmICFoYXNSZW5kZXJGZXRjaGVkLmN1cnJlbnQpIHtcblx0XHRcdGhhc1JlbmRlckZldGNoZWQuY3VycmVudCA9IHRydWU7XG5cdFx0XHRwcmVsb2FkTGluayhyb3V0ZXIsIGRlc3QpO1xuXHRcdH1cblx0XHRsZXQgYWN0aXZlID0gdHJ1ZTtcblx0XHRsZXQgb2JzZXJ2ZXI7XG5cdFx0aWYgKHByZWxvYWQgPT09IFwidmlld3BvcnRcIiAmJiBpbm5lclJlZi5jdXJyZW50ICYmIHR5cGVvZiBJbnRlcnNlY3Rpb25PYnNlcnZlciA9PT0gXCJmdW5jdGlvblwiKSB7XG5cdFx0XHRvYnNlcnZlciA9IG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcigoZW50cmllcykgPT4ge1xuXHRcdFx0XHRpZiAoYWN0aXZlKSBlbnF1ZXVlUHJlbG9hZChlbnRyaWVzLnBvcCgpKTtcblx0XHRcdH0sIHsgcm9vdE1hcmdpbjogXCIxMDBweFwiIH0pO1xuXHRcdFx0b2JzZXJ2ZXIub2JzZXJ2ZShpbm5lclJlZi5jdXJyZW50KTtcblx0XHR9XG5cdFx0cmV0dXJuICgpID0+IHtcblx0XHRcdGFjdGl2ZSA9IGZhbHNlO1xuXHRcdFx0b2JzZXJ2ZXI/LmRpc2Nvbm5lY3QoKTtcblx0XHRcdGNhbmNlbFByZWxvYWQoaW5uZXJSZWYpO1xuXHRcdH07XG5cdH0sIFtcblx0XHRyb3V0ZXIsXG5cdFx0ZGVzdCxcblx0XHRwcmVsb2FkLFxuXHRcdGVucXVldWVQcmVsb2FkLFxuXHRcdGlubmVyUmVmXG5cdF0pO1xuXHRjb25zdCBwcm9wcyA9IGNvbGxlY3RFbGVtZW50UHJvcHMob3B0aW9ucywgaG9zdCk7XG5cdHByb3BzLnJlZiA9IGZvcndhcmRlZFJlZiA/IG1lcmdlZFJlZiA6IGlubmVyUmVmO1xuXHRpZiAoZXh0ZXJuYWxMaW5rKSB7XG5cdFx0cHJvcHMuaHJlZiA9IGV4dGVybmFsTGluaztcblx0XHRyZXR1cm4gcHJvcHM7XG5cdH1cblx0Y29uc3QgaGFuZGxlQ2xpY2sgPSAoZSkgPT4ge1xuXHRcdGNvbnN0IGVmZmVjdGl2ZVRhcmdldCA9IHRhcmdldCA/PyBlLmN1cnJlbnRUYXJnZXQuZ2V0QXR0cmlidXRlKFwidGFyZ2V0XCIpO1xuXHRcdGlmICghbGlua0Rpc2FibGVkICYmICEoZS5tZXRhS2V5IHx8IGUuYWx0S2V5IHx8IGUuY3RybEtleSB8fCBlLnNoaWZ0S2V5KSAmJiAhZS5kZWZhdWx0UHJldmVudGVkICYmICghZWZmZWN0aXZlVGFyZ2V0IHx8IGVmZmVjdGl2ZVRhcmdldCA9PT0gXCJfc2VsZlwiKSAmJiBlLmJ1dHRvbiA9PT0gMCkge1xuXHRcdFx0ZS5wcmV2ZW50RGVmYXVsdCgpO1xuXHRcdFx0Y2FuY2VsUHJlbG9hZChpbm5lclJlZik7XG5cdFx0XHRyb3V0ZXIubmF2aWdhdGUoe1xuXHRcdFx0XHQuLi5vcHRpb25zLFxuXHRcdFx0XHRfZnJvbUxvY2F0aW9uOiBkZXN0Ll9mcm9tTG9jYXRpb25cblx0XHRcdH0pO1xuXHRcdH1cblx0fTtcblx0Y29uc3QgaGFuZGxlVG91Y2hTdGFydCA9ICgpID0+IHtcblx0XHRpZiAocHJlbG9hZCA9PT0gXCJpbnRlbnRcIikgcHJlbG9hZExpbmsocm91dGVyLCBkZXN0KTtcblx0fTtcblx0Y29uc3QgaGFuZGxlTGVhdmUgPSAoKSA9PiB7XG5cdFx0aWYgKHByZWxvYWQgPT09IFwiaW50ZW50XCIpIGNhbmNlbFByZWxvYWQoaW5uZXJSZWYpO1xuXHR9O1xuXHRwcm9wcy5vbkNsaWNrID0gY29tcG9zZUhhbmRsZXJzKG9uQ2xpY2ssIGhhbmRsZUNsaWNrKTtcblx0cHJvcHMub25CbHVyID0gY29tcG9zZUhhbmRsZXJzKG9uQmx1ciwgaGFuZGxlTGVhdmUpO1xuXHRwcm9wcy5vbkZvY3VzID0gY29tcG9zZUhhbmRsZXJzKG9uRm9jdXMsIGVucXVldWVQcmVsb2FkKTtcblx0cHJvcHMub25Nb3VzZUVudGVyID0gY29tcG9zZUhhbmRsZXJzKG9uTW91c2VFbnRlciwgZW5xdWV1ZVByZWxvYWQpO1xuXHRwcm9wcy5vbk1vdXNlTGVhdmUgPSBjb21wb3NlSGFuZGxlcnMob25Nb3VzZUxlYXZlLCBoYW5kbGVMZWF2ZSk7XG5cdHByb3BzLm9uVG91Y2hTdGFydCA9IGNvbXBvc2VIYW5kbGVycyhvblRvdWNoU3RhcnQsIGhhbmRsZVRvdWNoU3RhcnQpO1xuXHRyZXR1cm4gYXBwbHlMaW5rU3RhdGUocHJvcHMsIG9wdGlvbnMsIGlzQWN0aXZlLCBocmVmLCBsaW5rRGlzYWJsZWQsIGhvc3QpO1xufVxudmFyIFNUQVRJQ19FTVBUWV9PQkpFQ1QgPSB7fTtcbnZhciBTVEFUSUNfQUNUSVZFX09CSkVDVCA9IHsgY2xhc3NOYW1lOiBcImFjdGl2ZVwiIH07XG52YXIgUk9VVEVSX09QVElPTl9LRVlTID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW1xuXHRcInRvXCIsXG5cdFwicGFyYW1zXCIsXG5cdFwic2VhcmNoXCIsXG5cdFwiaGFzaFwiLFxuXHRcInN0YXRlXCIsXG5cdFwibWFza1wiLFxuXHRcImZyb21cIixcblx0XCJ1bnNhZmVSZWxhdGl2ZVwiLFxuXHRcInJlbG9hZERvY3VtZW50XCIsXG5cdFwicHJlbG9hZFwiLFxuXHRcInByZWxvYWREZWxheVwiLFxuXHRcInByZWxvYWRJbnRlbnRQcm94aW1pdHlcIixcblx0XCJoYXNoU2Nyb2xsSW50b1ZpZXdcIixcblx0XCJyZXBsYWNlXCIsXG5cdFwic3RhcnRUcmFuc2l0aW9uXCIsXG5cdFwicmVzZXRTY3JvbGxcIixcblx0XCJ2aWV3VHJhbnNpdGlvblwiLFxuXHRcImlnbm9yZUJsb2NrZXJcIixcblx0XCJhY3RpdmVQcm9wc1wiLFxuXHRcImluYWN0aXZlUHJvcHNcIixcblx0XCJhY3RpdmVPcHRpb25zXCIsXG5cdFwiX2FzQ2hpbGRcIlxuXSk7XG5mdW5jdGlvbiBjb2xsZWN0RWxlbWVudFByb3BzKG9wdGlvbnMsIGhvc3QpIHtcblx0Y29uc3QgcHJvcHMgPSB7fTtcblx0Zm9yIChjb25zdCBrZXkgaW4gb3B0aW9ucykge1xuXHRcdGlmIChST1VURVJfT1BUSU9OX0tFWVMuaGFzKGtleSkgfHwga2V5ID09PSBcInR5cGVcIiAmJiBob3N0ICE9PSB2b2lkIDAgfHwga2V5ID09PSBcImRpc2FibGVkXCIgJiYgaG9zdCA9PT0gXCJhXCIpIGNvbnRpbnVlO1xuXHRcdHByb3BzW2tleV0gPSBvcHRpb25zW2tleV07XG5cdH1cblx0cmV0dXJuIHByb3BzO1xufVxuZnVuY3Rpb24gYXBwbHlMaW5rU3RhdGUocHJvcHMsIG9wdGlvbnMsIGlzQWN0aXZlLCBocmVmLCBsaW5rRGlzYWJsZWQsIGhvc3QpIHtcblx0Y29uc3QgeyBhY3RpdmVQcm9wcywgaW5hY3RpdmVQcm9wcywgY2xhc3NOYW1lLCBzdHlsZSwgdGFyZ2V0IH0gPSBvcHRpb25zO1xuXHRjb25zdCBzdGF0ZVByb3BzID0gZnVuY3Rpb25hbFVwZGF0ZShpc0FjdGl2ZSA/IGFjdGl2ZVByb3BzIDogaW5hY3RpdmVQcm9wcywge30pID8/IChpc0FjdGl2ZSA/IFNUQVRJQ19BQ1RJVkVfT0JKRUNUIDogU1RBVElDX0VNUFRZX09CSkVDVCk7XG5cdE9iamVjdC5hc3NpZ24ocHJvcHMsIHN0YXRlUHJvcHMpO1xuXHRwcm9wcy5ocmVmID0gaHJlZjtcblx0aWYgKGhvc3QgIT09IFwiYVwiKSBwcm9wcy5kaXNhYmxlZCA9IGxpbmtEaXNhYmxlZDtcblx0cHJvcHMudGFyZ2V0ID0gdGFyZ2V0O1xuXHRjb25zdCBzdGF0ZVN0eWxlID0gc3RhdGVQcm9wcy5zdHlsZTtcblx0aWYgKHN0eWxlIHx8IHN0YXRlU3R5bGUpIHByb3BzLnN0eWxlID0gc3R5bGUgJiYgc3RhdGVTdHlsZSA/IHtcblx0XHQuLi5zdHlsZSxcblx0XHQuLi5zdGF0ZVN0eWxlXG5cdH0gOiBzdHlsZSB8fCBzdGF0ZVN0eWxlO1xuXHRjb25zdCBzdGF0ZUNsYXNzTmFtZSA9IHN0YXRlUHJvcHMuY2xhc3NOYW1lO1xuXHRpZiAoY2xhc3NOYW1lIHx8IHN0YXRlQ2xhc3NOYW1lKSBwcm9wcy5jbGFzc05hbWUgPSBjbGFzc05hbWUgPyBzdGF0ZUNsYXNzTmFtZSA/IGAke2NsYXNzTmFtZX0gJHtzdGF0ZUNsYXNzTmFtZX1gIDogY2xhc3NOYW1lIDogc3RhdGVDbGFzc05hbWU7XG5cdGlmIChsaW5rRGlzYWJsZWQpIHtcblx0XHRwcm9wcy5yb2xlID0gXCJsaW5rXCI7XG5cdFx0cHJvcHNbXCJhcmlhLWRpc2FibGVkXCJdID0gdHJ1ZTtcblx0fVxuXHRpZiAoaXNBY3RpdmUpIHtcblx0XHRwcm9wc1tcImRhdGEtc3RhdHVzXCJdID0gXCJhY3RpdmVcIjtcblx0XHRwcm9wc1tcImFyaWEtY3VycmVudFwiXSA9IFwicGFnZVwiO1xuXHR9XG5cdHJldHVybiBwcm9wcztcbn1cbmZ1bmN0aW9uIGdldFNlcnZlckxpbmtQcm9wcyhyb3V0ZXIsIG9wdGlvbnMsIGZvcndhcmRlZFJlZiwgaG9zdCkge1xuXHRjb25zdCB7IHRvLCBkaXNhYmxlZCwgYWN0aXZlT3B0aW9ucyB9ID0gb3B0aW9ucztcblx0Y29uc3QgZGlyZWN0RXh0ZXJuYWxMaW5rID0gcmVzb2x2ZUV4dGVybmFsTGluayh0bywgcm91dGVyLnByb3RvY29sQWxsb3dsaXN0KTtcblx0Y29uc3QgbmV4dCA9IGRpcmVjdEV4dGVybmFsTGluayA9PT0gdm9pZCAwID8gcm91dGVyLmJ1aWxkTG9jYXRpb24ob3B0aW9ucykgOiB2b2lkIDA7XG5cdGNvbnN0IGhyZWZPcHRpb24gPSBuZXh0ID8gZ2V0SHJlZk9wdGlvbihuZXh0LCByb3V0ZXIsIGRpc2FibGVkKSA6IGRpcmVjdEV4dGVybmFsTGluayA/PyB2b2lkIDA7XG5cdGNvbnN0IGxpbmtEaXNhYmxlZCA9IGRpc2FibGVkIHx8ICFocmVmT3B0aW9uO1xuXHRjb25zdCBleHRlcm5hbExpbmsgPSBkaXJlY3RFeHRlcm5hbExpbmsgPz8gKGhyZWZPcHRpb24gJiYgZ2V0VXJsU2NoZW1lKGhyZWZPcHRpb24pID8gaHJlZk9wdGlvbiA6IHZvaWQgMCk7XG5cdGNvbnN0IHByb3BzID0gY29sbGVjdEVsZW1lbnRQcm9wcyhvcHRpb25zLCBob3N0KTtcblx0cHJvcHMucmVmID0gZm9yd2FyZGVkUmVmO1xuXHRpZiAoZXh0ZXJuYWxMaW5rKSB7XG5cdFx0cHJvcHMuaHJlZiA9IGV4dGVybmFsTGluaztcblx0XHRyZXR1cm4gcHJvcHM7XG5cdH1cblx0cmV0dXJuIGFwcGx5TGlua1N0YXRlKHByb3BzLCBvcHRpb25zLCAhIW5leHQgJiYgISghZGlzYWJsZWQgJiYgIWhyZWZPcHRpb24pICYmICFhY3RpdmVPcHRpb25zPy5pbmNsdWRlSGFzaCAmJiByZXNvbHZlSXNBY3RpdmUocm91dGVyLnN0b3Jlcy5sb2NhdGlvbi5nZXQoKSwgbmV4dCwgYWN0aXZlT3B0aW9ucywgcm91dGVyLmJhc2VwYXRoKSwgaHJlZk9wdGlvbiwgbGlua0Rpc2FibGVkLCBob3N0KTtcbn1cbnZhciBjYW5jZWxQcmVsb2FkID0gKHJlZikgPT4ge1xuXHRjbGVhclRpbWVvdXQocmVmLnQpO1xuXHRyZWYudCA9IHZvaWQgMDtcbn07XG52YXIgY29tcG9zZUhhbmRsZXJzID0gKGZpcnN0LCBzZWNvbmQpID0+IHtcblx0aWYgKCFmaXJzdCkgcmV0dXJuIHNlY29uZDtcblx0cmV0dXJuIChldmVudCkgPT4gZXZlbnQuZGVmYXVsdFByZXZlbnRlZCB8fCAoZmlyc3QoZXZlbnQpLCBldmVudC5kZWZhdWx0UHJldmVudGVkIHx8IHNlY29uZChldmVudCkpO1xufTtcbmZ1bmN0aW9uIGdldEhyZWZPcHRpb24obmV4dCwgcm91dGVyLCBkaXNhYmxlZCkge1xuXHRpZiAoZGlzYWJsZWQpIHJldHVybjtcblx0Y29uc3QgbG9jYXRpb24gPSBuZXh0Lm1hc2tlZExvY2F0aW9uID8/IG5leHQ7XG5cdGNvbnN0IGhyZWYgPSBsb2NhdGlvbi5leHRlcm5hbCA/IGxvY2F0aW9uLnB1YmxpY0hyZWYgOiByb3V0ZXIuaGlzdG9yeS5jcmVhdGVIcmVmKGxvY2F0aW9uLnB1YmxpY0hyZWYpIHx8IFwiL1wiO1xuXHRpZiAoKGxvY2F0aW9uLmV4dGVybmFsIHx8IGhyZWYgIT09IGxvY2F0aW9uLnB1YmxpY0hyZWYpICYmIGlzRGFuZ2Vyb3VzUHJvdG9jb2woaHJlZiwgcm91dGVyLnByb3RvY29sQWxsb3dsaXN0KSkge1xuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIGNvbnNvbGUud2FybihgQmxvY2tlZCBMaW5rIHdpdGggZGFuZ2Vyb3VzIHByb3RvY29sOiAke2hyZWZ9YCk7XG5cdFx0cmV0dXJuO1xuXHR9XG5cdHJldHVybiBocmVmO1xufVxuLyoqXG4qIENyZWF0ZXMgYSB0eXBlZCBMaW5rLWxpa2UgY29tcG9uZW50IHRoYXQgcHJlc2VydmVzIFRhblN0YWNrIFJvdXRlcidzXG4qIG5hdmlnYXRpb24gc2VtYW50aWNzIGFuZCB0eXBlLXNhZmV0eSB3aGlsZSBkZWxlZ2F0aW5nIHJlbmRlcmluZyB0byB0aGVcbiogcHJvdmlkZWQgaG9zdCBjb21wb25lbnQuXG4qXG4qIFVzZWZ1bCBmb3IgaW50ZWdyYXRpbmcgZGVzaWduIHN5c3RlbSBhbmNob3JzL2J1dHRvbnMgd2hpbGUga2VlcGluZ1xuKiByb3V0ZXItYXdhcmUgcHJvcHMgKGVnLiBgdG9gLCBgcGFyYW1zYCwgYHNlYXJjaGAsIGBwcmVsb2FkYCkuXG4qXG4qIEBwYXJhbSBDb21wIFRoZSBob3N0IGNvbXBvbmVudCB0byByZW5kZXIgKGVnLiBhIGRlc2lnbi1zeXN0ZW0gTGluay9CdXR0b24pXG4qIEByZXR1cm5zIEEgcm91dGVyLWF3YXJlIGNvbXBvbmVudCB3aXRoIHRoZSBzYW1lIEFQSSBhcyBgTGlua2AuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvZ3VpZGUvY3VzdG9tLWxpbmtcbiovXG5mdW5jdGlvbiBjcmVhdGVMaW5rKENvbXApIHtcblx0cmV0dXJuIFJlYWN0JDEuZm9yd2FyZFJlZihmdW5jdGlvbiBDcmVhdGVkTGluayhwcm9wcywgcmVmKSB7XG5cdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goTGluaywge1xuXHRcdFx0Li4ucHJvcHMsXG5cdFx0XHRfYXNDaGlsZDogQ29tcCxcblx0XHRcdHJlZlxuXHRcdH0pO1xuXHR9KTtcbn1cbi8qKlxuKiBBIHN0cm9uZ2x5LXR5cGVkIGFuY2hvciBjb21wb25lbnQgZm9yIGRlY2xhcmF0aXZlIG5hdmlnYXRpb24uXG4qIEhhbmRsZXMgcGF0aCwgc2VhcmNoLCBoYXNoIGFuZCBzdGF0ZSB1cGRhdGVzIHdpdGggb3B0aW9uYWwgcm91dGUgcHJlbG9hZGluZ1xuKiBhbmQgYWN0aXZlLXN0YXRlIHN0eWxpbmcuXG4qXG4qIFByb3BzOlxuKiAtIGBwcmVsb2FkYDogQ29udHJvbHMgcm91dGUgcHJlbG9hZGluZyAoZWcuICdpbnRlbnQnLCAncmVuZGVyJywgJ3ZpZXdwb3J0JywgdHJ1ZS9mYWxzZSlcbiogLSBgcHJlbG9hZERlbGF5YDogRGVsYXkgaW4gbXMgYmVmb3JlIHByZWxvYWRpbmcgb24gZm9jdXMsIGhvdmVyLCBvciB2aWV3cG9ydCBlbnRyeVxuKiAtIGBhY3RpdmVQcm9wc2AvYGluYWN0aXZlUHJvcHNgOiBBZGRpdGlvbmFsIHByb3BzIG1lcmdlZCB3aGVuIGxpbmsgaXMgYWN0aXZlL2luYWN0aXZlXG4qIC0gYHJlc2V0U2Nyb2xsYC9gaGFzaFNjcm9sbEludG9WaWV3YDogQ29udHJvbCBzY3JvbGwgYmVoYXZpb3Igb24gbmF2aWdhdGlvblxuKiAtIGB2aWV3VHJhbnNpdGlvbmAvYHN0YXJ0VHJhbnNpdGlvbmA6IFVzZSBWaWV3IFRyYW5zaXRpb25zL1JlYWN0IHRyYW5zaXRpb25zIGZvciBuYXZpZ2F0aW9uXG4qIC0gYGlnbm9yZUJsb2NrZXJgOiBCeXBhc3MgcmVnaXN0ZXJlZCBibG9ja2Vyc1xuKlxuKiBAcmV0dXJucyBBbiBhbmNob3ItbGlrZSBlbGVtZW50IHRoYXQgbmF2aWdhdGVzIHdpdGhvdXQgZnVsbCBwYWdlIHJlbG9hZHMuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9saW5rQ29tcG9uZW50XG4qL1xudmFyIExpbmsgPSBSZWFjdCQxLm1lbW8oUmVhY3QkMS5mb3J3YXJkUmVmKChwcm9wcywgcmVmKSA9PiB7XG5cdGNvbnN0IGhvc3QgPSBwcm9wcy5fYXNDaGlsZCB8fCBcImFcIjtcblx0Y29uc3QgbGlua1Byb3BzID0gdXNlTGlua1Byb3BzKHByb3BzLCByZWYsIGhvc3QpO1xuXHRjb25zdCBjaGlsZHJlbiA9IHR5cGVvZiBwcm9wcy5jaGlsZHJlbiA9PT0gXCJmdW5jdGlvblwiID8gcHJvcHMuY2hpbGRyZW4oeyBpc0FjdGl2ZTogbGlua1Byb3BzW1wiZGF0YS1zdGF0dXNcIl0gPT09IFwiYWN0aXZlXCIgfSkgOiBwcm9wcy5jaGlsZHJlbjtcblx0cmV0dXJuIFJlYWN0JDEuY3JlYXRlRWxlbWVudChob3N0LCBsaW5rUHJvcHMsIGNoaWxkcmVuKTtcbn0pLCBhcmVMaW5rUHJvcHNFcXVhbCk7XG5mdW5jdGlvbiBhcmVMaW5rUHJvcHNFcXVhbChwcmV2LCBuZXh0KSB7XG5cdGxldCBleHRyYUtleXMgPSAwO1xuXHRmb3IgKGNvbnN0IGtleSBpbiBuZXh0KSB7XG5cdFx0ZXh0cmFLZXlzKys7XG5cdFx0aWYgKHByZXZba2V5XSA9PT0gbmV4dFtrZXldKSBjb250aW51ZTtcblx0XHRpZiAoIVJPVVRFUl9PUFRJT05fS0VZUy5oYXMoa2V5KSB8fCAhZGVlcEVxdWFsKHByZXZba2V5XSwgbmV4dFtrZXldLCBmYWxzZSwgdHJ1ZSkpIHJldHVybiBmYWxzZTtcblx0fVxuXHRmb3IgKGNvbnN0IF9rZXkgaW4gcHJldikgZXh0cmFLZXlzLS07XG5cdHJldHVybiBleHRyYUtleXMgPT09IDA7XG59XG4vKipcbiogVmFsaWRhdGUgYW5kIHJldXNlIG5hdmlnYXRpb24gb3B0aW9ucyBmb3IgYExpbmtgLCBgbmF2aWdhdGVgIG9yIGByZWRpcmVjdGAuXG4qIEFjY2VwdHMgYSBsaXRlcmFsIG9wdGlvbnMgb2JqZWN0IGFuZCByZXR1cm5zIGl0IHR5cGVkIGZvciBsYXRlciBzcHJlYWRpbmcuXG4qIEBleGFtcGxlXG4qIGNvbnN0IG9wdHMgPSBsaW5rT3B0aW9ucyh7IHRvOiAnL2Rhc2hib2FyZCcsIHNlYXJjaDogeyB0YWI6ICdob21lJyB9IH0pXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9saW5rT3B0aW9uc1xuKi9cbnZhciBsaW5rT3B0aW9ucyA9IChvcHRpb25zKSA9PiB7XG5cdHJldHVybiBvcHRpb25zO1xufTtcbi8qKlxuKiBUeXBlLWNoZWNrIGEgbGl0ZXJhbCBvYmplY3QgZm9yIHVzZSB3aXRoIGBMaW5rYCwgYG5hdmlnYXRlYCBvciBgcmVkaXJlY3RgLlxuKiBVc2UgdG8gdmFsaWRhdGUgYW5kIHJldXNlIG5hdmlnYXRpb24gb3B0aW9ucyBhY3Jvc3MgeW91ciBhcHAuXG4qIEBleGFtcGxlXG4qIGNvbnN0IG9wdHMgPSBsaW5rT3B0aW9ucyh7IHRvOiAnL2Rhc2hib2FyZCcsIHNlYXJjaDogeyB0YWI6ICdob21lJyB9IH0pXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9saW5rT3B0aW9uc1xuKi9cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgTGluaywgY29tcG9zZUhhbmRsZXJzLCBjcmVhdGVMaW5rLCBsaW5rT3B0aW9ucywgdXNlTGlua1Byb3BzIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWxpbmsuanMubWFwIiwiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VNYXRjaCB9IGZyb20gXCIuL3VzZU1hdGNoLmpzXCI7XG5pbXBvcnQgeyB1c2VMb2FkZXJEYXRhIH0gZnJvbSBcIi4vdXNlTG9hZGVyRGF0YS5qc1wiO1xuaW1wb3J0IHsgdXNlTG9hZGVyRGVwcyB9IGZyb20gXCIuL3VzZUxvYWRlckRlcHMuanNcIjtcbmltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gXCIuL3VzZVBhcmFtcy5qc1wiO1xuaW1wb3J0IHsgdXNlU2VhcmNoIH0gZnJvbSBcIi4vdXNlU2VhcmNoLmpzXCI7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCIuL3VzZU5hdmlnYXRlLmpzXCI7XG5pbXBvcnQgeyB1c2VSb3V0ZUNvbnRleHQgfSBmcm9tIFwiLi91c2VSb3V0ZUNvbnRleHQuanNcIjtcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwiLi9saW5rLmpzXCI7XG5pbXBvcnQgeyBCYXNlUm9vdFJvdXRlLCBCYXNlUm91dGUsIEJhc2VSb3V0ZUFwaSwgbm90Rm91bmQgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvcm91dGUudHN4XG4vKipcbiogUmV0dXJucyBhIHJvdXRlLXNwZWNpZmljIEFQSSB0aGF0IGV4cG9zZXMgdHlwZS1zYWZlIGhvb2tzIHByZS1ib3VuZFxuKiB0byBhIHNpbmdsZSByb3V0ZSBJRC4gVXNlZnVsIGZvciBjb25zdW1pbmcgYSByb3V0ZSdzIEFQSXMgZnJvbSBmaWxlc1xuKiB3aGVyZSB0aGUgcm91dGUgb2JqZWN0IGlzbid0IGRpcmVjdGx5IGltcG9ydGVkIChlLmcuIGNvZGUtc3BsaXQgZmlsZXMpLlxuKlxuKiBAcGFyYW0gaWQgUm91dGUgSUQgc3RyaW5nIGxpdGVyYWwgZm9yIHRoZSB0YXJnZXQgcm91dGUuXG4qIEByZXR1cm5zIEEgYFJvdXRlQXBpYCBpbnN0YW5jZSBib3VuZCB0byB0aGUgZ2l2ZW4gcm91dGUgSUQuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9nZXRSb3V0ZUFwaUZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gZ2V0Um91dGVBcGkoaWQpIHtcblx0cmV0dXJuIG5ldyBSb3V0ZUFwaSh7IGlkIH0pO1xufVxudmFyIFJvdXRlQXBpID0gY2xhc3MgZXh0ZW5kcyBCYXNlUm91dGVBcGkge1xuXHQvKipcblx0KiBAZGVwcmVjYXRlZCBVc2UgdGhlIGBnZXRSb3V0ZUFwaWAgZnVuY3Rpb24gaW5zdGVhZC5cblx0Ki9cblx0Y29uc3RydWN0b3IoeyBpZCB9KSB7XG5cdFx0c3VwZXIoeyBpZCB9KTtcblx0XHR0aGlzLnVzZU1hdGNoID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VNYXRjaCh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VSb3V0ZUNvbnRleHQgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZVJvdXRlQ29udGV4dCh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VTZWFyY2ggPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZVNlYXJjaCh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VQYXJhbXMgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZVBhcmFtcyh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VMb2FkZXJEZXBzID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VMb2FkZXJEZXBzKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZCxcblx0XHRcdFx0c3RyaWN0OiBmYWxzZVxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZUxvYWRlckRhdGEgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZUxvYWRlckRhdGEoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkLFxuXHRcdFx0XHRzdHJpY3Q6IGZhbHNlXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlTmF2aWdhdGUgPSAoKSA9PiB7XG5cdFx0XHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0XHRcdHJldHVybiB1c2VOYXZpZ2F0ZSh7IGZyb206IHJvdXRlci5yb3V0ZXNCeUlkW3RoaXMuaWRdLmZ1bGxQYXRoIH0pO1xuXHRcdH07XG5cdFx0dGhpcy5ub3RGb3VuZCA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gbm90Rm91bmQoe1xuXHRcdFx0XHRyb3V0ZUlkOiB0aGlzLmlkLFxuXHRcdFx0XHQuLi5vcHRzXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMuTGluayA9IFJlYWN0LmZvcndhcmRSZWYoKHByb3BzLCByZWYpID0+IHtcblx0XHRcdGNvbnN0IGZ1bGxQYXRoID0gdXNlUm91dGVyKCkucm91dGVzQnlJZFt0aGlzLmlkXS5mdWxsUGF0aDtcblx0XHRcdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KExpbmssIHtcblx0XHRcdFx0cmVmLFxuXHRcdFx0XHRmcm9tOiBmdWxsUGF0aCxcblx0XHRcdFx0Li4ucHJvcHNcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG59O1xudmFyIFJvdXRlID0gY2xhc3MgZXh0ZW5kcyBCYXNlUm91dGUge1xuXHQvKipcblx0KiBAZGVwcmVjYXRlZCBVc2UgdGhlIGBjcmVhdGVSb3V0ZWAgZnVuY3Rpb24gaW5zdGVhZC5cblx0Ki9cblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHN1cGVyKG9wdGlvbnMpO1xuXHRcdHRoaXMudXNlTWF0Y2ggPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZU1hdGNoKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZVJvdXRlQ29udGV4dCA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlUm91dGVDb250ZXh0KHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZVNlYXJjaCA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlU2VhcmNoKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZVBhcmFtcyA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlUGFyYW1zKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZUxvYWRlckRlcHMgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZUxvYWRlckRlcHMoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlTG9hZGVyRGF0YSA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlTG9hZGVyRGF0YSh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VOYXZpZ2F0ZSA9ICgpID0+IHtcblx0XHRcdHJldHVybiB1c2VOYXZpZ2F0ZSh7IGZyb206IHRoaXMuZnVsbFBhdGggfSk7XG5cdFx0fTtcblx0XHR0aGlzLkxpbmsgPSBSZWFjdC5mb3J3YXJkUmVmKChwcm9wcywgcmVmKSA9PiB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChMaW5rLCB7XG5cdFx0XHRcdHJlZixcblx0XHRcdFx0ZnJvbTogdGhpcy5mdWxsUGF0aCxcblx0XHRcdFx0Li4ucHJvcHNcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG59O1xuLyoqXG4qIENyZWF0ZXMgYSBub24tcm9vdCBSb3V0ZSBpbnN0YW5jZSBmb3IgY29kZS1iYXNlZCByb3V0aW5nLlxuKlxuKiBVc2UgdGhpcyB0byBkZWZpbmUgYSByb3V0ZSB0aGF0IHdpbGwgYmUgY29tcG9zZWQgaW50byBhIHJvdXRlIHRyZWVcbiogKHR5cGljYWxseSB2aWEgYSBwYXJlbnQgcm91dGUncyBgYWRkQ2hpbGRyZW5gKS4gSWYgeW91J3JlIHVzaW5nIGZpbGUtYmFzZWRcbiogcm91dGluZywgcHJlZmVyIGBjcmVhdGVGaWxlUm91dGVgLlxuKlxuKiBAcGFyYW0gb3B0aW9ucyBSb3V0ZSBvcHRpb25zIChwYXRoLCBjb21wb25lbnQsIGxvYWRlciwgY29udGV4dCwgZXRjLikuXG4qIEByZXR1cm5zIEEgUm91dGUgaW5zdGFuY2UgdG8gYmUgYXR0YWNoZWQgdG8gdGhlIHJvdXRlIHRyZWUuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9jcmVhdGVSb3V0ZUZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gY3JlYXRlUm91dGUob3B0aW9ucykge1xuXHRyZXR1cm4gbmV3IFJvdXRlKG9wdGlvbnMpO1xufVxuLyoqXG4qIENyZWF0ZXMgYSByb290IHJvdXRlIGZhY3RvcnkgdGhhdCByZXF1aXJlcyBhIHJvdXRlciBjb250ZXh0IHR5cGUuXG4qXG4qIFVzZSB3aGVuIHlvdXIgcm9vdCByb3V0ZSBleHBlY3RzIGBjb250ZXh0YCB0byBiZSBwcm92aWRlZCB0byBgY3JlYXRlUm91dGVyYC5cbiogVGhlIHJldHVybmVkIGZ1bmN0aW9uIGJlaGF2ZXMgbGlrZSBgY3JlYXRlUm9vdFJvdXRlYCBidXQgZW5mb3JjZXMgYSBjb250ZXh0IHR5cGUuXG4qXG4qIEByZXR1cm5zIEEgZmFjdG9yeSBmdW5jdGlvbiB0byBjb25maWd1cmUgYW5kIHJldHVybiBhIHJvb3Qgcm91dGUuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9jcmVhdGVSb290Um91dGVXaXRoQ29udGV4dEZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gY3JlYXRlUm9vdFJvdXRlV2l0aENvbnRleHQoKSB7XG5cdHJldHVybiAob3B0aW9ucykgPT4ge1xuXHRcdHJldHVybiBjcmVhdGVSb290Um91dGUob3B0aW9ucyk7XG5cdH07XG59XG4vKipcbiogQGRlcHJlY2F0ZWQgVXNlIHRoZSBgY3JlYXRlUm9vdFJvdXRlV2l0aENvbnRleHRgIGZ1bmN0aW9uIGluc3RlYWQuXG4qL1xudmFyIHJvb3RSb3V0ZVdpdGhDb250ZXh0ID0gY3JlYXRlUm9vdFJvdXRlV2l0aENvbnRleHQ7XG52YXIgUm9vdFJvdXRlID0gY2xhc3MgZXh0ZW5kcyBCYXNlUm9vdFJvdXRlIHtcblx0LyoqXG5cdCogQGRlcHJlY2F0ZWQgYFJvb3RSb3V0ZWAgaXMgbm93IGFuIGludGVybmFsIGltcGxlbWVudGF0aW9uIGRldGFpbC4gVXNlIGBjcmVhdGVSb290Um91dGUoKWAgaW5zdGVhZC5cblx0Ki9cblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHN1cGVyKG9wdGlvbnMpO1xuXHRcdHRoaXMudXNlTWF0Y2ggPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZU1hdGNoKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZVJvdXRlQ29udGV4dCA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlUm91dGVDb250ZXh0KHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZVNlYXJjaCA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlU2VhcmNoKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZVBhcmFtcyA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlUGFyYW1zKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZUxvYWRlckRlcHMgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZUxvYWRlckRlcHMoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlTG9hZGVyRGF0YSA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlTG9hZGVyRGF0YSh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VOYXZpZ2F0ZSA9ICgpID0+IHtcblx0XHRcdHJldHVybiB1c2VOYXZpZ2F0ZSh7IGZyb206IHRoaXMuZnVsbFBhdGggfSk7XG5cdFx0fTtcblx0XHR0aGlzLkxpbmsgPSBSZWFjdC5mb3J3YXJkUmVmKChwcm9wcywgcmVmKSA9PiB7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChMaW5rLCB7XG5cdFx0XHRcdHJlZixcblx0XHRcdFx0ZnJvbTogdGhpcy5mdWxsUGF0aCxcblx0XHRcdFx0Li4ucHJvcHNcblx0XHRcdH0pO1xuXHRcdH0pO1xuXHR9XG59O1xuLyoqXG4qIENyZWF0ZXMgYSByb290IFJvdXRlIGluc3RhbmNlIHVzZWQgdG8gYnVpbGQgeW91ciByb3V0ZSB0cmVlLlxuKlxuKiBUeXBpY2FsbHkgcGFpcmVkIHdpdGggYGNyZWF0ZVJvdXRlcih7IHJvdXRlVHJlZSB9KWAuIElmIHlvdSBuZWVkIHRvIHJlcXVpcmVcbiogYSB0eXBlZCByb3V0ZXIgY29udGV4dCwgdXNlIGBjcmVhdGVSb290Um91dGVXaXRoQ29udGV4dGAgaW5zdGVhZC5cbipcbiogQHBhcmFtIG9wdGlvbnMgUm9vdCByb3V0ZSBvcHRpb25zIChjb21wb25lbnQsIGVycm9yLCBwZW5kaW5nLCBldGMuKS5cbiogQHJldHVybnMgQSByb290IHJvdXRlIGluc3RhbmNlLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvY3JlYXRlUm9vdFJvdXRlRnVuY3Rpb25cbiovXG5mdW5jdGlvbiBjcmVhdGVSb290Um91dGUob3B0aW9ucykge1xuXHRyZXR1cm4gbmV3IFJvb3RSb3V0ZShvcHRpb25zKTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJvdXRlTWFzayhvcHRzKSB7XG5cdHJldHVybiBvcHRzO1xufVxudmFyIE5vdEZvdW5kUm91dGUgPSBjbGFzcyBleHRlbmRzIFJvdXRlIHtcblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHN1cGVyKHtcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRpZDogXCI0MDRcIlxuXHRcdH0pO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBOb3RGb3VuZFJvdXRlLCBSb290Um91dGUsIFJvdXRlLCBSb3V0ZUFwaSwgY3JlYXRlUm9vdFJvdXRlLCBjcmVhdGVSb290Um91dGVXaXRoQ29udGV4dCwgY3JlYXRlUm91dGUsIGNyZWF0ZVJvdXRlTWFzaywgZ2V0Um91dGVBcGksIHJvb3RSb3V0ZVdpdGhDb250ZXh0IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJvdXRlLmpzLm1hcCIsImltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgdXNlTWF0Y2ggfSBmcm9tIFwiLi91c2VNYXRjaC5qc1wiO1xuaW1wb3J0IHsgdXNlTG9hZGVyRGF0YSB9IGZyb20gXCIuL3VzZUxvYWRlckRhdGEuanNcIjtcbmltcG9ydCB7IHVzZUxvYWRlckRlcHMgfSBmcm9tIFwiLi91c2VMb2FkZXJEZXBzLmpzXCI7XG5pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tIFwiLi91c2VQYXJhbXMuanNcIjtcbmltcG9ydCB7IHVzZVNlYXJjaCB9IGZyb20gXCIuL3VzZVNlYXJjaC5qc1wiO1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwiLi91c2VOYXZpZ2F0ZS5qc1wiO1xuaW1wb3J0IHsgdXNlUm91dGVDb250ZXh0IH0gZnJvbSBcIi4vdXNlUm91dGVDb250ZXh0LmpzXCI7XG5pbXBvcnQgeyBjcmVhdGVSb3V0ZSB9IGZyb20gXCIuL3JvdXRlLmpzXCI7XG4vLyNyZWdpb24gc3JjL2ZpbGVSb3V0ZS50c1xuLyoqXG4qIENyZWF0ZXMgYSBmaWxlLWJhc2VkIFJvdXRlIGZhY3RvcnkgZm9yIGEgZ2l2ZW4gcGF0aC5cbipcbiogVXNlZCBieSBUYW5TdGFjayBSb3V0ZXIncyBmaWxlLWJhc2VkIHJvdXRpbmcgdG8gYXNzb2NpYXRlIGEgZmlsZSB3aXRoIGFcbiogcm91dGUuIFRoZSByZXR1cm5lZCBmdW5jdGlvbiBhY2NlcHRzIHN0YW5kYXJkIHJvdXRlIG9wdGlvbnMuIEluIG5vcm1hbCB1c2FnZVxuKiB0aGUgYHBhdGhgIHN0cmluZyBpcyBpbnNlcnRlZCBhbmQgbWFpbnRhaW5lZCBieSB0aGUgYHRzcmAgZ2VuZXJhdG9yLlxuKlxuKiBAcGFyYW0gcGF0aCBGaWxlIHBhdGggbGl0ZXJhbCBmb3IgdGhlIHJvdXRlICh1c3VhbGx5IGF1dG8tZ2VuZXJhdGVkKS5cbiogQHJldHVybnMgQSBmdW5jdGlvbiB0aGF0IGFjY2VwdHMgUm91dGUgb3B0aW9ucyBhbmQgcmV0dXJucyBhIFJvdXRlIGluc3RhbmNlLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvY3JlYXRlRmlsZVJvdXRlRnVuY3Rpb25cbiovXG5mdW5jdGlvbiBjcmVhdGVGaWxlUm91dGUocGF0aCkge1xuXHRyZXR1cm4gKG9wdGlvbnMpID0+IHtcblx0XHRjb25zdCByb3V0ZSA9IGNyZWF0ZVJvdXRlKG9wdGlvbnMpO1xuXHRcdHJvdXRlLmlzUm9vdCA9IGZhbHNlO1xuXHRcdHJldHVybiByb3V0ZTtcblx0fTtcbn1cbi8qKiBcbkBkZXByZWNhdGVkIEl0J3Mgbm8gbG9uZ2VyIHJlY29tbWVuZGVkIHRvIHVzZSB0aGUgYEZpbGVSb3V0ZWAgY2xhc3MgZGlyZWN0bHkuXG5JbnN0ZWFkLCB1c2UgYGNyZWF0ZUZpbGVSb3V0ZSgnL3BhdGgvdG8vZmlsZScpKG9wdGlvbnMpYCB0byBjcmVhdGUgYSBmaWxlIHJvdXRlLlxuKi9cbnZhciBGaWxlUm91dGUgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKHBhdGgsIF9vcHRzKSB7XG5cdFx0dGhpcy5wYXRoID0gcGF0aDtcblx0XHR0aGlzLmNyZWF0ZVJvdXRlID0gKG9wdGlvbnMpID0+IHtcblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdFx0aWYgKCF0aGlzLnNpbGVudCkgY29uc29sZS53YXJuKFwiV2FybmluZzogRmlsZVJvdXRlIGlzIGRlcHJlY2F0ZWQgYW5kIHdpbGwgYmUgcmVtb3ZlZCBpbiB0aGUgbmV4dCBtYWpvciB2ZXJzaW9uLiBVc2UgdGhlIGNyZWF0ZUZpbGVSb3V0ZShwYXRoKShvcHRpb25zKSBmdW5jdGlvbiBpbnN0ZWFkLlwiKTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IHJvdXRlID0gY3JlYXRlUm91dGUob3B0aW9ucyk7XG5cdFx0XHRyb3V0ZS5pc1Jvb3QgPSBmYWxzZTtcblx0XHRcdHJldHVybiByb3V0ZTtcblx0XHR9O1xuXHRcdHRoaXMuc2lsZW50ID0gX29wdHM/LnNpbGVudDtcblx0fVxufTtcbi8qKlxuQGRlcHJlY2F0ZWQgSXQncyByZWNvbW1lbmRlZCBub3QgdG8gc3BsaXQgbG9hZGVycyBpbnRvIHNlcGFyYXRlIGZpbGVzLlxuSW5zdGVhZCwgcGxhY2UgdGhlIGxvYWRlciBmdW5jdGlvbiBpbiB0aGUgbWFpbiByb3V0ZSBmaWxlIHZpYSBgY3JlYXRlRmlsZVJvdXRlYC5cbiovXG5mdW5jdGlvbiBGaWxlUm91dGVMb2FkZXIoX3BhdGgpIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikgY29uc29sZS53YXJuKGBXYXJuaW5nOiBGaWxlUm91dGVMb2FkZXIgaXMgZGVwcmVjYXRlZCBhbmQgd2lsbCBiZSByZW1vdmVkIGluIHRoZSBuZXh0IG1ham9yIHZlcnNpb24uIFBsZWFzZSBwbGFjZSB0aGUgbG9hZGVyIGZ1bmN0aW9uIGluIHRoZSBtYWluIHJvdXRlIGZpbGUsIGluc2lkZSB0aGUgXFxgY3JlYXRlRmlsZVJvdXRlKCcvcGF0aC90by9maWxlJykob3B0aW9ucylcXGAgb3B0aW9uc2ApO1xuXHRyZXR1cm4gKGxvYWRlckZuKSA9PiBsb2FkZXJGbjtcbn1cbnZhciBMYXp5Um91dGUgPSBjbGFzcyB7XG5cdGNvbnN0cnVjdG9yKG9wdHMpIHtcblx0XHR0aGlzLnVzZU1hdGNoID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VNYXRjaCh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMub3B0aW9ucy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZVJvdXRlQ29udGV4dCA9IChvcHRzKSA9PiB7XG5cdFx0XHRyZXR1cm4gdXNlUm91dGVDb250ZXh0KHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5vcHRpb25zLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlU2VhcmNoID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VTZWFyY2goe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLm9wdGlvbnMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VQYXJhbXMgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZVBhcmFtcyh7XG5cdFx0XHRcdC4uLm9wdHMsXG5cdFx0XHRcdGZyb206IHRoaXMub3B0aW9ucy5pZFxuXHRcdFx0fSk7XG5cdFx0fTtcblx0XHR0aGlzLnVzZUxvYWRlckRlcHMgPSAob3B0cykgPT4ge1xuXHRcdFx0cmV0dXJuIHVzZUxvYWRlckRlcHMoe1xuXHRcdFx0XHQuLi5vcHRzLFxuXHRcdFx0XHRmcm9tOiB0aGlzLm9wdGlvbnMuaWRcblx0XHRcdH0pO1xuXHRcdH07XG5cdFx0dGhpcy51c2VMb2FkZXJEYXRhID0gKG9wdHMpID0+IHtcblx0XHRcdHJldHVybiB1c2VMb2FkZXJEYXRhKHtcblx0XHRcdFx0Li4ub3B0cyxcblx0XHRcdFx0ZnJvbTogdGhpcy5vcHRpb25zLmlkXG5cdFx0XHR9KTtcblx0XHR9O1xuXHRcdHRoaXMudXNlTmF2aWdhdGUgPSAoKSA9PiB7XG5cdFx0XHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0XHRcdHJldHVybiB1c2VOYXZpZ2F0ZSh7IGZyb206IHJvdXRlci5yb3V0ZXNCeUlkW3RoaXMub3B0aW9ucy5pZF0uZnVsbFBhdGggfSk7XG5cdFx0fTtcblx0XHR0aGlzLm9wdGlvbnMgPSBvcHRzO1xuXHR9XG59O1xuLyoqXG4qIENyZWF0ZXMgYSBsYXppbHktY29uZmlndXJhYmxlIGNvZGUtYmFzZWQgcm91dGUgc3R1YiBieSBJRC5cbipcbiogVXNlIHRoaXMgZm9yIGNvZGUtc3BsaXR0aW5nIHdpdGggY29kZS1iYXNlZCByb3V0ZXMuIFRoZSByZXR1cm5lZCBmdW5jdGlvblxuKiBhY2NlcHRzIG9ubHkgbm9uLWNyaXRpY2FsIHJvdXRlIG9wdGlvbnMgbGlrZSBgY29tcG9uZW50YCwgYHBlbmRpbmdDb21wb25lbnRgLFxuKiBgZXJyb3JDb21wb25lbnRgLCBhbmQgYG5vdEZvdW5kQ29tcG9uZW50YCB3aGljaCBhcmUgYXBwbGllZCB3aGVuIHRoZSByb3V0ZVxuKiBpcyBtYXRjaGVkLlxuKlxuKiBAcGFyYW0gaWQgUm91dGUgSUQgc3RyaW5nIGxpdGVyYWwgdG8gYXNzb2NpYXRlIHdpdGggdGhlIGxhenkgcm91dGUuXG4qIEByZXR1cm5zIEEgZnVuY3Rpb24gdGhhdCBhY2NlcHRzIGxhenkgcm91dGUgb3B0aW9ucyBhbmQgcmV0dXJucyBhIGBMYXp5Um91dGVgLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvY3JlYXRlTGF6eVJvdXRlRnVuY3Rpb25cbiovXG5mdW5jdGlvbiBjcmVhdGVMYXp5Um91dGUoaWQpIHtcblx0cmV0dXJuIChvcHRzKSA9PiB7XG5cdFx0cmV0dXJuIG5ldyBMYXp5Um91dGUoe1xuXHRcdFx0aWQsXG5cdFx0XHQuLi5vcHRzXG5cdFx0fSk7XG5cdH07XG59XG4vKipcbiogQ3JlYXRlcyBhIGxhemlseS1jb25maWd1cmFibGUgZmlsZS1iYXNlZCByb3V0ZSBzdHViIGJ5IGZpbGUgcGF0aC5cbipcbiogVXNlIHRoaXMgZm9yIGNvZGUtc3BsaXR0aW5nIHdpdGggZmlsZS1iYXNlZCByb3V0ZXMgKGVnLiBgLmxhenkudHN4YCBmaWxlcykuXG4qIFRoZSByZXR1cm5lZCBmdW5jdGlvbiBhY2NlcHRzIG9ubHkgbm9uLWNyaXRpY2FsIHJvdXRlIG9wdGlvbnMgbGlrZVxuKiBgY29tcG9uZW50YCwgYHBlbmRpbmdDb21wb25lbnRgLCBgZXJyb3JDb21wb25lbnRgLCBhbmQgYG5vdEZvdW5kQ29tcG9uZW50YC5cbipcbiogQHBhcmFtIGlkIEZpbGUgcGF0aCBsaXRlcmFsIGZvciB0aGUgcm91dGUgZmlsZS5cbiogQHJldHVybnMgQSBmdW5jdGlvbiB0aGF0IGFjY2VwdHMgbGF6eSByb3V0ZSBvcHRpb25zIGFuZCByZXR1cm5zIGEgYExhenlSb3V0ZWAuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9jcmVhdGVMYXp5RmlsZVJvdXRlRnVuY3Rpb25cbiovXG5mdW5jdGlvbiBjcmVhdGVMYXp5RmlsZVJvdXRlKGlkKSB7XG5cdGlmICh0eXBlb2YgaWQgPT09IFwib2JqZWN0XCIpIHJldHVybiBuZXcgTGF6eVJvdXRlKGlkKTtcblx0cmV0dXJuIChvcHRzKSA9PiBuZXcgTGF6eVJvdXRlKHtcblx0XHRpZCxcblx0XHQuLi5vcHRzXG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBGaWxlUm91dGUsIEZpbGVSb3V0ZUxvYWRlciwgTGF6eVJvdXRlLCBjcmVhdGVGaWxlUm91dGUsIGNyZWF0ZUxhenlGaWxlUm91dGUsIGNyZWF0ZUxhenlSb3V0ZSB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1maWxlUm91dGUuanMubWFwIiwiaW1wb3J0IHsgcmVhY3RVc2UgfSBmcm9tIFwiLi91dGlscy5qc1wiO1xuaW1wb3J0IHsgaXNNb2R1bGVOb3RGb3VuZEVycm9yIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuLy8jcmVnaW9uIHNyYy9sYXp5Um91dGVDb21wb25lbnQudHN4XG4vKipcbiogV3JhcCBhIGR5bmFtaWMgaW1wb3J0IHRvIGNyZWF0ZSBhIHJvdXRlIGNvbXBvbmVudCB0aGF0IHN1cHBvcnRzXG4qIGAucHJlbG9hZCgpYCBhbmQgZnJpZW5kbHkgcmVsb2FkLW9uLW1vZHVsZS1taXNzaW5nIGJlaGF2aW9yLlxuKlxuKiBAcGFyYW0gaW1wb3J0ZXIgRnVuY3Rpb24gcmV0dXJuaW5nIGEgbW9kdWxlIHByb21pc2VcbiogQHBhcmFtIGV4cG9ydE5hbWUgTmFtZWQgZXhwb3J0IHRvIHVzZSAoZGVmYXVsdDogYGRlZmF1bHRgKVxuKiBAcmV0dXJucyBBIGxhenkgcm91dGUgY29tcG9uZW50IGNvbXBhdGlibGUgd2l0aCBUYW5TdGFjayBSb3V0ZXJcbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2xhenlSb3V0ZUNvbXBvbmVudEZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gbGF6eVJvdXRlQ29tcG9uZW50KGltcG9ydGVyLCBleHBvcnROYW1lKSB7XG5cdGxldCBsb2FkUHJvbWlzZTtcblx0bGV0IGNvbXA7XG5cdGxldCBlcnJvcjtcblx0Y29uc3QgbG9hZCA9ICgpID0+IHtcblx0XHRpZiAoIWxvYWRQcm9taXNlKSB7XG5cdFx0XHRlcnJvciA9IHZvaWQgMDtcblx0XHRcdGxvYWRQcm9taXNlID0gaW1wb3J0ZXIoKS50aGVuKChyZXMpID0+IHtcblx0XHRcdFx0aWYgKCEoaXNTZXJ2ZXIgPz8gdHlwZW9mIHdpbmRvdyA9PT0gXCJ1bmRlZmluZWRcIikpIHtcblx0XHRcdFx0XHRsb2FkUHJvbWlzZSA9IHZvaWQgMDtcblx0XHRcdFx0XHRsYXp5Q29tcC5wcmVsb2FkID0gdm9pZCAwO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGNvbXAgPSByZXNbZXhwb3J0TmFtZSA/PyBcImRlZmF1bHRcIl07XG5cdFx0XHR9KS5jYXRjaCgoZXJyKSA9PiB7XG5cdFx0XHRcdGxvYWRQcm9taXNlID0gdm9pZCAwO1xuXHRcdFx0XHRlcnJvciA9IGVycjtcblx0XHRcdH0pO1xuXHRcdH1cblx0XHRyZXR1cm4gbG9hZFByb21pc2U7XG5cdH07XG5cdGNvbnN0IGxhenlDb21wID0gZnVuY3Rpb24gTGF6eShwcm9wcykge1xuXHRcdGlmIChlcnJvcikge1xuXHRcdFx0aWYgKGlzTW9kdWxlTm90Rm91bmRFcnJvcihlcnJvcikgJiYgIShpc1NlcnZlciA/PyB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiKSAmJiB0eXBlb2Ygc2Vzc2lvblN0b3JhZ2UgIT09IFwidW5kZWZpbmVkXCIpIHtcblx0XHRcdFx0Y29uc3Qgc3RvcmFnZUtleSA9IGB0YW5zdGFja19yb3V0ZXJfcmVsb2FkOiR7ZXJyb3IubWVzc2FnZX1gO1xuXHRcdFx0XHRpZiAoIXNlc3Npb25TdG9yYWdlLmdldEl0ZW0oc3RvcmFnZUtleSkpIHtcblx0XHRcdFx0XHRzZXNzaW9uU3RvcmFnZS5zZXRJdGVtKHN0b3JhZ2VLZXksIFwiMVwiKTtcblx0XHRcdFx0XHR3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XG5cdFx0XHRcdFx0dGhyb3cgbmV3IFByb21pc2UoKCkgPT4ge30pO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHR0aHJvdyBlcnJvcjtcblx0XHR9XG5cdFx0aWYgKCFjb21wKSB7XG5cdFx0XHRpZiAocmVhY3RVc2UpIHJlYWN0VXNlKGxvYWQoKSk7XG5cdFx0XHRlbHNlIHRocm93IGxvYWQoKTtcblx0XHR9XG5cdFx0cmV0dXJuIFJlYWN0JDEuY3JlYXRlRWxlbWVudChjb21wLCBwcm9wcyk7XG5cdH07XG5cdGxhenlDb21wLnByZWxvYWQgPSBsb2FkO1xuXHRyZXR1cm4gbGF6eUNvbXA7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IGxhenlSb3V0ZUNvbXBvbmVudCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1sYXp5Um91dGVDb21wb25lbnQuanMubWFwIiwiaW1wb3J0IHsgQ2F0Y2hCb3VuZGFyeSB9IGZyb20gXCIuL0NhdGNoQm91bmRhcnkuanNcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgaXNOb3RGb3VuZCB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCBcInJlYWN0XCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmUvaXNTZXJ2ZXJcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuaW1wb3J0IHsgdXNlU2VsZWN0b3IgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXN0b3JlXCI7XG4vLyNyZWdpb24gc3JjL25vdC1mb3VuZC50c3hcbmZ1bmN0aW9uIENhdGNoTm90Rm91bmQocHJvcHMpIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHtcblx0XHRjb25zdCByZXNldEtleSA9IGBub3QtZm91bmQtJHtyb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLmdldCgpLnBhdGhuYW1lfS0ke3JvdXRlci5zdG9yZXMuc3RhdHVzLmdldCgpfWA7XG5cdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goQ2F0Y2hCb3VuZGFyeSwge1xuXHRcdFx0Z2V0UmVzZXRLZXk6ICgpID0+IHJlc2V0S2V5LFxuXHRcdFx0b25DYXRjaDogKGVycm9yLCBlcnJvckluZm8pID0+IHtcblx0XHRcdFx0aWYgKGlzTm90Rm91bmQoZXJyb3IpKSBwcm9wcy5vbkNhdGNoPy4oZXJyb3IsIGVycm9ySW5mbyk7XG5cdFx0XHRcdGVsc2UgdGhyb3cgZXJyb3I7XG5cdFx0XHR9LFxuXHRcdFx0ZXJyb3JDb21wb25lbnQ6ICh7IGVycm9yIH0pID0+IHtcblx0XHRcdFx0aWYgKGlzTm90Rm91bmQoZXJyb3IpKSByZXR1cm4gcHJvcHMuZmFsbGJhY2s/LihlcnJvcik7XG5cdFx0XHRcdGVsc2UgdGhyb3cgZXJyb3I7XG5cdFx0XHR9LFxuXHRcdFx0Y2hpbGRyZW46IHByb3BzLmNoaWxkcmVuXG5cdFx0fSk7XG5cdH1cblx0Y29uc3QgcmVzZXRLZXkgPSBgbm90LWZvdW5kLSR7dXNlU2VsZWN0b3Iocm91dGVyLnN0b3Jlcy5sb2NhdGlvbiwgKGxvY2F0aW9uKSA9PiBsb2NhdGlvbi5wYXRobmFtZSl9LSR7dXNlU2VsZWN0b3Iocm91dGVyLnN0b3Jlcy5zdGF0dXMpfWA7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KENhdGNoQm91bmRhcnksIHtcblx0XHRnZXRSZXNldEtleTogKCkgPT4gcmVzZXRLZXksXG5cdFx0b25DYXRjaDogKGVycm9yLCBlcnJvckluZm8pID0+IHtcblx0XHRcdGlmIChpc05vdEZvdW5kKGVycm9yKSkgcHJvcHMub25DYXRjaD8uKGVycm9yLCBlcnJvckluZm8pO1xuXHRcdFx0ZWxzZSB0aHJvdyBlcnJvcjtcblx0XHR9LFxuXHRcdGVycm9yQ29tcG9uZW50OiAoeyBlcnJvciB9KSA9PiB7XG5cdFx0XHRpZiAoaXNOb3RGb3VuZChlcnJvcikpIHJldHVybiBwcm9wcy5mYWxsYmFjaz8uKGVycm9yKTtcblx0XHRcdGVsc2UgdGhyb3cgZXJyb3I7XG5cdFx0fSxcblx0XHRjaGlsZHJlbjogcHJvcHMuY2hpbGRyZW5cblx0fSk7XG59XG5mdW5jdGlvbiBEZWZhdWx0R2xvYmFsTm90Rm91bmQoKSB7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFwicFwiLCB7IGNoaWxkcmVuOiBcIk5vdCBGb3VuZFwiIH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBDYXRjaE5vdEZvdW5kLCBEZWZhdWx0R2xvYmFsTm90Rm91bmQgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bm90LWZvdW5kLmpzLm1hcCIsImltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvU2NyaXB0T25jZS50c3hcbi8qKlxuKiBTZXJ2ZXItb25seSBoZWxwZXIgdG8gZW1pdCBhIHNjcmlwdCB0YWcgZXhhY3RseSBvbmNlIGR1cmluZyBTU1IuXG4qL1xuZnVuY3Rpb24gU2NyaXB0T25jZSh7IGNoaWxkcmVuIH0pIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGlmICghKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikpIHJldHVybiBudWxsO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcInNjcmlwdFwiLCB7XG5cdFx0bm9uY2U6IHJvdXRlci5vcHRpb25zLnNzcj8ubm9uY2UsXG5cdFx0ZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw6IHsgX19odG1sOiBjaGlsZHJlbiArIFwiO2RvY3VtZW50LmN1cnJlbnRTY3JpcHQucmVtb3ZlKClcIiB9XG5cdH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBTY3JpcHRPbmNlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVNjcmlwdE9uY2UuanMubWFwIiwiaW1wb3J0IHsgd3JhcEluTm9uUm91dGVDb21wb25lbnRDb250ZXh0IH0gZnJvbSBcIi4vbm9uUm91dGVDb21wb25lbnRDb250ZXh0LmpzXCI7XG5pbXBvcnQgeyBEZWZhdWx0R2xvYmFsTm90Rm91bmQgfSBmcm9tIFwiLi9ub3QtZm91bmQuanNcIjtcbmltcG9ydCBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvcmVuZGVyUm91dGVOb3RGb3VuZC50c3hcbi8qKlxuKiBSZW5kZXJzIGEgbm90IGZvdW5kIGNvbXBvbmVudCBmb3IgYSByb3V0ZSB3aGVuIG5vIG1hdGNoaW5nIHJvdXRlIGlzIGZvdW5kLlxuKlxuKiBAcGFyYW0gcm91dGVyIC0gVGhlIHJvdXRlciBpbnN0YW5jZSBjb250YWluaW5nIHRoZSByb3V0ZSBjb25maWd1cmF0aW9uXG4qIEBwYXJhbSByb3V0ZSAtIFRoZSByb3V0ZSB0aGF0IHRyaWdnZXJlZCB0aGUgbm90IGZvdW5kIHN0YXRlXG4qIEBwYXJhbSBkYXRhIC0gQWRkaXRpb25hbCBkYXRhIHRvIHBhc3MgdG8gdGhlIG5vdCBmb3VuZCBjb21wb25lbnRcbiogQHJldHVybnMgVGhlIHJlbmRlcmVkIG5vdCBmb3VuZCBjb21wb25lbnQgb3IgYSBkZWZhdWx0IGZhbGxiYWNrIGNvbXBvbmVudFxuKi9cbmZ1bmN0aW9uIHJlbmRlclJvdXRlTm90Rm91bmQocm91dGVyLCByb3V0ZSwgZGF0YSkge1xuXHRpZiAoIXJvdXRlLm9wdGlvbnMubm90Rm91bmRDb21wb25lbnQpIHtcblx0XHRpZiAocm91dGVyLm9wdGlvbnMuZGVmYXVsdE5vdEZvdW5kQ29tcG9uZW50KSB7XG5cdFx0XHRjb25zdCBub3RGb3VuZEVsZW1lbnQgPSAvKiBAX19QVVJFX18gKi8ganN4KHJvdXRlci5vcHRpb25zLmRlZmF1bHROb3RGb3VuZENvbXBvbmVudCwgeyAuLi5kYXRhIH0pO1xuXHRcdFx0cmV0dXJuIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IHdyYXBJbk5vblJvdXRlQ29tcG9uZW50Q29udGV4dChub3RGb3VuZEVsZW1lbnQsIFwibm90Rm91bmRDb21wb25lbnRcIikgOiBub3RGb3VuZEVsZW1lbnQ7XG5cdFx0fVxuXHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdGlmICghcm91dGUub3B0aW9ucy5ub3RGb3VuZENvbXBvbmVudCkgY29uc29sZS53YXJuKGBXYXJuaW5nOiBBIG5vdEZvdW5kRXJyb3Igd2FzIGVuY291bnRlcmVkIG9uIHRoZSByb3V0ZSB3aXRoIElEIFwiJHtyb3V0ZS5pZH1cIiwgYnV0IGEgbm90Rm91bmRDb21wb25lbnQgb3B0aW9uIHdhcyBub3QgY29uZmlndXJlZCwgbm9yIHdhcyBhIHJvdXRlciBsZXZlbCBkZWZhdWx0Tm90Rm91bmRDb21wb25lbnQgY29uZmlndXJlZC4gQ29uc2lkZXIgY29uZmlndXJpbmcgYXQgbGVhc3Qgb25lIG9mIHRoZXNlIHRvIGF2b2lkIFRhblN0YWNrIFJvdXRlcidzIG92ZXJseSBnZW5lcmljIGRlZmF1bHROb3RGb3VuZENvbXBvbmVudCAoPHA+Tm90IEZvdW5kPC9wPilgKTtcblx0XHR9XG5cdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goRGVmYXVsdEdsb2JhbE5vdEZvdW5kLCB7fSk7XG5cdH1cblx0Y29uc3Qgbm90Rm91bmRFbGVtZW50ID0gLyogQF9fUFVSRV9fICovIGpzeChyb3V0ZS5vcHRpb25zLm5vdEZvdW5kQ29tcG9uZW50LCB7IC4uLmRhdGEgfSk7XG5cdHJldHVybiBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyB3cmFwSW5Ob25Sb3V0ZUNvbXBvbmVudENvbnRleHQobm90Rm91bmRFbGVtZW50LCBcIm5vdEZvdW5kQ29tcG9uZW50XCIpIDogbm90Rm91bmRFbGVtZW50O1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyByZW5kZXJSb3V0ZU5vdEZvdW5kIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJlbmRlclJvdXRlTm90Rm91bmQuanMubWFwIiwiLy8jcmVnaW9uIHNyYy9zY3JvbGwtcmVzdG9yYXRpb24tc2NyaXB0L2NsaWVudC50c1xuZnVuY3Rpb24gZ2V0U2Nyb2xsUmVzdG9yYXRpb25TY3JpcHRGb3JSb3V0ZXIoX3JvdXRlcikge1xuXHRyZXR1cm4gbnVsbDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZ2V0U2Nyb2xsUmVzdG9yYXRpb25TY3JpcHRGb3JSb3V0ZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y2xpZW50LmpzLm1hcCIsImltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgU2NyaXB0T25jZSB9IGZyb20gXCIuL1NjcmlwdE9uY2UuanNcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuaW1wb3J0IHsgZ2V0U2Nyb2xsUmVzdG9yYXRpb25TY3JpcHRGb3JSb3V0ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL3Njcm9sbC1yZXN0b3JhdGlvbi1zY3JpcHRcIjtcbi8vI3JlZ2lvbiBzcmMvc2Nyb2xsLXJlc3RvcmF0aW9uLnRzeFxuZnVuY3Rpb24gU2Nyb2xsUmVzdG9yYXRpb24oKSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCBzY3JpcHQgPSBnZXRTY3JvbGxSZXN0b3JhdGlvblNjcmlwdEZvclJvdXRlcihyb3V0ZXIpO1xuXHRpZiAoIXNjcmlwdCkgcmV0dXJuIG51bGw7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFNjcmlwdE9uY2UsIHsgY2hpbGRyZW46IHNjcmlwdCB9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgU2Nyb2xsUmVzdG9yYXRpb24gfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c2Nyb2xsLXJlc3RvcmF0aW9uLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgbm9uUm91dGVDb21wb25lbnRDb250ZXh0LCB3cmFwSW5Ob25Sb3V0ZUNvbXBvbmVudENvbnRleHQgfSBmcm9tIFwiLi9ub25Sb3V0ZUNvbXBvbmVudENvbnRleHQuanNcIjtcbmltcG9ydCB7IENhdGNoQm91bmRhcnksIEVycm9yQ29tcG9uZW50IH0gZnJvbSBcIi4vQ2F0Y2hCb3VuZGFyeS5qc1wiO1xuaW1wb3J0IHsgQ2xpZW50T25seSB9IGZyb20gXCIuL0NsaWVudE9ubHkuanNcIjtcbmltcG9ydCB7IG1hdGNoQ29udGV4dCB9IGZyb20gXCIuL21hdGNoQ29udGV4dC5qc1wiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBDYXRjaE5vdEZvdW5kIH0gZnJvbSBcIi4vbm90LWZvdW5kLmpzXCI7XG5pbXBvcnQgeyByZW5kZXJSb3V0ZU5vdEZvdW5kIH0gZnJvbSBcIi4vcmVuZGVyUm91dGVOb3RGb3VuZC5qc1wiO1xuaW1wb3J0IHsgU2Nyb2xsUmVzdG9yYXRpb24gfSBmcm9tIFwiLi9zY3JvbGwtcmVzdG9yYXRpb24uanNcIjtcbmltcG9ydCB7IGlzTm90Rm91bmQsIHJvb3RSb3V0ZUlkIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZVwiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuaW1wb3J0IHsganN4LCBqc3hzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtc3RvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvTWF0Y2gudHN4XG5mdW5jdGlvbiByZW5kZXJQZW5kaW5nKHJvdXRlciwgcm91dGUpIHtcblx0Y29uc3QgUGVuZGluZ0NvbXBvbmVudCA9IHJvdXRlPy5vcHRpb25zLnBlbmRpbmdDb21wb25lbnQgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdFBlbmRpbmdDb21wb25lbnQ7XG5cdGlmICghUGVuZGluZ0NvbXBvbmVudCkgcmV0dXJuIG51bGw7XG5cdGNvbnN0IHBlbmRpbmdFbGVtZW50ID0gLyogQF9fUFVSRV9fICovIGpzeChQZW5kaW5nQ29tcG9uZW50LCB7fSk7XG5cdHJldHVybiBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyB3cmFwSW5Ob25Sb3V0ZUNvbXBvbmVudENvbnRleHQocGVuZGluZ0VsZW1lbnQsIFwicGVuZGluZ0NvbXBvbmVudFwiKSA6IHBlbmRpbmdFbGVtZW50O1xufVxudmFyIG91dGxldE1hdGNoU2VsZWN0aW9uRXF1YWwgPSAoYSwgYikgPT4gYVswXSA9PT0gYlswXSAmJiBhWzFdID09PSBiWzFdO1xudmFyIGNhbldyYXBJblN1c3BlbnNlID0gKHJvdXRlciwgcm91dGUsIHNzcikgPT4gIXJvdXRlLmlzUm9vdCB8fCByb3V0ZS5vcHRpb25zLnNoZWxsQ29tcG9uZW50IHx8IHJvdXRlLm9wdGlvbnMud3JhcEluU3VzcGVuc2UgfHwgc3NyID09PSBmYWxzZSB8fCBzc3IgPT09IFwiZGF0YS1vbmx5XCIgfHwgISgoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSB8fCByb3V0ZXIuc3NyKTtcbnZhciBNYXRjaCA9IFJlYWN0JDEubWVtbyhmdW5jdGlvbiBNYXRjaEltcGwoeyByb3V0ZUlkIH0pIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHJldHVybiBtYXRjaFZpZXcocm91dGVyLCByb3V0ZXIuc3RvcmVzLmJ5Um91dGUuZ2V0KHJvdXRlSWQpLmdldCgpKTtcblx0Y29uc3QgbWF0Y2hTdG9yZSA9IHJvdXRlci5zdG9yZXMuZ2V0TWF0Y2hTdG9yZShyb3V0ZUlkKTtcblx0cmV0dXJuIG1hdGNoVmlldyhyb3V0ZXIsIHVzZVNlbGVjdG9yKG1hdGNoU3RvcmUpKTtcbn0pO1xuZnVuY3Rpb24gbWF0Y2hWaWV3KHJvdXRlciwgbWF0Y2gpIHtcblx0Y29uc3Qgcm91dGUgPSByb3V0ZXIucm91dGVzQnlJZFttYXRjaC5yb3V0ZUlkXTtcblx0Y29uc3QgcGVuZGluZ0VsZW1lbnQgPSByZW5kZXJQZW5kaW5nKHJvdXRlciwgcm91dGUpO1xuXHRjb25zdCByb3V0ZUVycm9yQ29tcG9uZW50ID0gcm91dGUub3B0aW9ucy5lcnJvckNvbXBvbmVudCA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0RXJyb3JDb21wb25lbnQ7XG5cdGNvbnN0IHJvdXRlT25DYXRjaCA9IHJvdXRlLm9wdGlvbnMub25DYXRjaCA/PyByb3V0ZXIub3B0aW9ucy5kZWZhdWx0T25DYXRjaDtcblx0Y29uc3Qgcm91dGVOb3RGb3VuZENvbXBvbmVudCA9IHJvdXRlLmlzUm9vdCA/IHJvdXRlLm9wdGlvbnMubm90Rm91bmRDb21wb25lbnQgPz8gcm91dGVyLm9wdGlvbnMubm90Rm91bmRSb3V0ZT8ub3B0aW9ucy5jb21wb25lbnQgOiByb3V0ZS5vcHRpb25zLm5vdEZvdW5kQ29tcG9uZW50O1xuXHRjb25zdCByZXNvbHZlZE5vU3NyID0gbWF0Y2guc3NyID09PSBmYWxzZSB8fCBtYXRjaC5zc3IgPT09IFwiZGF0YS1vbmx5XCI7XG5cdGNvbnN0IHdyYXBJblN1c3BlbnNlID0gY2FuV3JhcEluU3VzcGVuc2Uocm91dGVyLCByb3V0ZSwgbWF0Y2guc3NyKSAmJiAocm91dGUub3B0aW9ucy53cmFwSW5TdXNwZW5zZSA/PyBwZW5kaW5nRWxlbWVudCA/PyAocm91dGUub3B0aW9ucy5lcnJvckNvbXBvbmVudD8ucHJlbG9hZCB8fCByZXNvbHZlZE5vU3NyKSk7XG5cdGxldCBjb250ZW50ID0gLyogQF9fUFVSRV9fICovIGpzeChNYXRjaElubmVyLCB7IG1hdGNoIH0pO1xuXHRpZiAocmVzb2x2ZWROb1NzcikgY29udGVudCA9IC8qIEBfX1BVUkVfXyAqLyBqc3goQ2xpZW50T25seSwge1xuXHRcdGZhbGxiYWNrOiBwZW5kaW5nRWxlbWVudCxcblx0XHRjaGlsZHJlbjogY29udGVudFxuXHR9KTtcblx0aWYgKHJvdXRlTm90Rm91bmRDb21wb25lbnQpIGNvbnRlbnQgPSAvKiBAX19QVVJFX18gKi8ganN4KENhdGNoTm90Rm91bmQsIHtcblx0XHRmYWxsYmFjazogKGVycm9yKSA9PiB7XG5cdFx0XHRlcnJvci5yb3V0ZUlkID8/PSBtYXRjaC5yb3V0ZUlkO1xuXHRcdFx0aWYgKGVycm9yLnJvdXRlSWQgIT09IG1hdGNoLnJvdXRlSWQpIHRocm93IGVycm9yO1xuXHRcdFx0Y29uc3Qgbm90Rm91bmRFbGVtZW50ID0gUmVhY3QkMS5jcmVhdGVFbGVtZW50KHJvdXRlTm90Rm91bmRDb21wb25lbnQsIGVycm9yKTtcblx0XHRcdHJldHVybiBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyB3cmFwSW5Ob25Sb3V0ZUNvbXBvbmVudENvbnRleHQobm90Rm91bmRFbGVtZW50LCBcIm5vdEZvdW5kQ29tcG9uZW50XCIpIDogbm90Rm91bmRFbGVtZW50O1xuXHRcdH0sXG5cdFx0Y2hpbGRyZW46IGNvbnRlbnRcblx0fSk7XG5cdGlmIChyb3V0ZUVycm9yQ29tcG9uZW50KSBjb250ZW50ID0gLyogQF9fUFVSRV9fICovIGpzeChDYXRjaEJvdW5kYXJ5LCB7XG5cdFx0Z2V0UmVzZXRLZXk6ICgpID0+IG1hdGNoLFxuXHRcdGVycm9yQ29tcG9uZW50OiByb3V0ZUVycm9yQ29tcG9uZW50LFxuXHRcdG9uQ2F0Y2g6IChlcnJvciwgZXJyb3JJbmZvKSA9PiB7XG5cdFx0XHRpZiAoaXNOb3RGb3VuZChlcnJvcikpIHtcblx0XHRcdFx0ZXJyb3Iucm91dGVJZCA/Pz0gbWF0Y2gucm91dGVJZDtcblx0XHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0XHR9XG5cdFx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSBjb25zb2xlLndhcm4oYFdhcm5pbmc6IEVycm9yIGluIHJvdXRlIG1hdGNoOiAke21hdGNoLmlkfWApO1xuXHRcdFx0cm91dGVPbkNhdGNoPy4oZXJyb3IsIGVycm9ySW5mbyk7XG5cdFx0fSxcblx0XHRjaGlsZHJlbjogY29udGVudFxuXHR9KTtcblx0aWYgKHdyYXBJblN1c3BlbnNlKSBjb250ZW50ID0gLyogQF9fUFVSRV9fICovIGpzeChSZWFjdCQxLlN1c3BlbnNlLCB7XG5cdFx0ZmFsbGJhY2s6IHBlbmRpbmdFbGVtZW50LFxuXHRcdGNoaWxkcmVuOiBjb250ZW50XG5cdH0pO1xuXHRjb25zdCBzY3JvbGxSZXN0b3JhdGlvbiA9IChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpICYmIHJvdXRlLnBhcmVudFJvdXRlPy5pZCA9PT0gcm9vdFJvdXRlSWQgJiYgcm91dGVyLm9wdGlvbnMuc2Nyb2xsUmVzdG9yYXRpb24gPyAvKiBAX19QVVJFX18gKi8ganN4KFNjcm9sbFJlc3RvcmF0aW9uLCB7fSkgOiBudWxsO1xuXHRjb25zdCBTaGVsbENvbXBvbmVudCA9IHJvdXRlLmlzUm9vdCAmJiByb3V0ZS5vcHRpb25zLnNoZWxsQ29tcG9uZW50O1xuXHRyZXR1cm4gU2hlbGxDb21wb25lbnQgPyAvKiBAX19QVVJFX18gKi8ganN4KG1hdGNoQ29udGV4dC5Qcm92aWRlciwge1xuXHRcdHZhbHVlOiBtYXRjaC5yb3V0ZUlkLFxuXHRcdGNoaWxkcmVuOiAvKiBAX19QVVJFX18gKi8ganN4cyhTaGVsbENvbXBvbmVudCwgeyBjaGlsZHJlbjogW2NvbnRlbnQsIHNjcm9sbFJlc3RvcmF0aW9uXSB9KVxuXHR9KSA6IC8qIEBfX1BVUkVfXyAqLyBqc3hzKG1hdGNoQ29udGV4dC5Qcm92aWRlciwge1xuXHRcdHZhbHVlOiBtYXRjaC5yb3V0ZUlkLFxuXHRcdGNoaWxkcmVuOiBbY29udGVudCwgc2Nyb2xsUmVzdG9yYXRpb25dXG5cdH0pO1xufVxudmFyIE1hdGNoSW5uZXIgPSBSZWFjdCQxLm1lbW8oZnVuY3Rpb24gTWF0Y2hJbm5lckltcGwoeyBtYXRjaCB9KSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCByb3V0ZUlkID0gbWF0Y2gucm91dGVJZDtcblx0Y29uc3Qgcm91dGUgPSByb3V0ZXIucm91dGVzQnlJZFtyb3V0ZUlkXTtcblx0Y29uc3Qga2V5ID0gUmVhY3QkMS51c2VNZW1vKCgpID0+IHtcblx0XHRjb25zdCByZW1vdW50RGVwcyA9IChyb3V0ZS5vcHRpb25zLnJlbW91bnREZXBzID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRSZW1vdW50RGVwcyk/Lih7XG5cdFx0XHRyb3V0ZUlkLFxuXHRcdFx0bG9hZGVyRGVwczogbWF0Y2gubG9hZGVyRGVwcyxcblx0XHRcdHBhcmFtczogbWF0Y2guX3N0cmljdFBhcmFtcyxcblx0XHRcdHNlYXJjaDogbWF0Y2guX3N0cmljdFNlYXJjaFxuXHRcdH0pO1xuXHRcdHJldHVybiByZW1vdW50RGVwcyA/IEpTT04uc3RyaW5naWZ5KHJlbW91bnREZXBzKSA6IHZvaWQgMDtcblx0fSwgW1xuXHRcdHJvdXRlSWQsXG5cdFx0bWF0Y2gubG9hZGVyRGVwcyxcblx0XHRtYXRjaC5fc3RyaWN0UGFyYW1zLFxuXHRcdG1hdGNoLl9zdHJpY3RTZWFyY2gsXG5cdFx0cm91dGUub3B0aW9ucy5yZW1vdW50RGVwcyxcblx0XHRyb3V0ZXIub3B0aW9ucy5kZWZhdWx0UmVtb3VudERlcHNcblx0XSk7XG5cdGNvbnN0IG91dCA9IFJlYWN0JDEudXNlTWVtbygoKSA9PiB7XG5cdFx0Y29uc3QgQ29tcCA9IHJvdXRlLm9wdGlvbnMuY29tcG9uZW50ID8/IHJvdXRlci5vcHRpb25zLmRlZmF1bHRDb21wb25lbnQ7XG5cdFx0cmV0dXJuIENvbXAgPyAvKiBAX19QVVJFX18gKi8ganN4KENvbXAsIHt9LCBrZXkpIDogLyogQF9fUFVSRV9fICovIGpzeChPdXRsZXQsIHt9KTtcblx0fSwgW1xuXHRcdGtleSxcblx0XHRyb3V0ZS5vcHRpb25zLmNvbXBvbmVudCxcblx0XHRyb3V0ZXIub3B0aW9ucy5kZWZhdWx0Q29tcG9uZW50XG5cdF0pO1xuXHRpZiAobWF0Y2guc3RhdHVzID09PSBcInBlbmRpbmdcIikge1xuXHRcdGlmIChyb3V0ZXIuc3NyICYmICFjYW5XcmFwSW5TdXNwZW5zZShyb3V0ZXIsIHJvdXRlLCBtYXRjaC5zc3IpKSByZXR1cm4gb3V0O1xuXHRcdGlmIChyb3V0ZXIuX3R4KSB0aHJvdyByb3V0ZXIuX3R4WzVdO1xuXHRcdHJldHVybiByZW5kZXJQZW5kaW5nKHJvdXRlciwgcm91dGUpO1xuXHR9XG5cdGlmIChtYXRjaC5zdGF0dXMgPT09IFwibm90Rm91bmRcIikgcmV0dXJuIHJlbmRlclJvdXRlTm90Rm91bmQocm91dGVyLCByb3V0ZSwgbWF0Y2guZXJyb3IpO1xuXHRpZiAobWF0Y2guc3RhdHVzID09PSBcImVycm9yXCIpIHtcblx0XHRpZiAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSB7XG5cdFx0XHRjb25zdCBSb3V0ZUVycm9yQ29tcG9uZW50ID0gKHJvdXRlLm9wdGlvbnMuZXJyb3JDb21wb25lbnQgPz8gcm91dGVyLm9wdGlvbnMuZGVmYXVsdEVycm9yQ29tcG9uZW50KSB8fCBFcnJvckNvbXBvbmVudDtcblx0XHRcdGNvbnN0IGVycm9yRWxlbWVudCA9IC8qIEBfX1BVUkVfXyAqLyBqc3goUm91dGVFcnJvckNvbXBvbmVudCwge1xuXHRcdFx0XHRlcnJvcjogbWF0Y2guZXJyb3IsXG5cdFx0XHRcdHJlc2V0OiB2b2lkIDAsXG5cdFx0XHRcdGluZm86IHsgY29tcG9uZW50U3RhY2s6IFwiXCIgfVxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gd3JhcEluTm9uUm91dGVDb21wb25lbnRDb250ZXh0KGVycm9yRWxlbWVudCwgXCJlcnJvckNvbXBvbmVudFwiKSA6IGVycm9yRWxlbWVudDtcblx0XHR9XG5cdFx0dGhyb3cgbWF0Y2guZXJyb3I7XG5cdH1cblx0cmV0dXJuIG91dDtcbn0pO1xuLyoqXG4qIFJlbmRlciB0aGUgbmV4dCBjaGlsZCBtYXRjaCBpbiB0aGUgcm91dGUgdHJlZS4gVHlwaWNhbGx5IHVzZWQgaW5zaWRlXG4qIGEgcm91dGUgY29tcG9uZW50IHRvIHJlbmRlciBuZXN0ZWQgcm91dGVzLlxuKlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvb3V0bGV0Q29tcG9uZW50XG4qL1xudmFyIE91dGxldCA9IFJlYWN0JDEubWVtbyhmdW5jdGlvbiBPdXRsZXRJbXBsKCkge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0Y29uc3Qgbm9uUm91dGVDb21wb25lbnQgPSBSZWFjdCQxLnVzZUNvbnRleHQobm9uUm91dGVDb21wb25lbnRDb250ZXh0KTtcblx0XHRpZiAobm9uUm91dGVDb21wb25lbnQpIGNvbnNvbGUud2FybihgV2FybmluZzogQW4gPE91dGxldCAvPiB3YXMgcmVuZGVyZWQgaW5zaWRlIGEgJHtub25Sb3V0ZUNvbXBvbmVudH0uIDxPdXRsZXQgLz4gc2hvdWxkIG9ubHkgYmUgcmVuZGVyZWQgaW5zaWRlIGEgcm91dGUgY29tcG9uZW50LmApO1xuXHR9XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCByb3V0ZUlkID0gUmVhY3QkMS51c2VDb250ZXh0KG1hdGNoQ29udGV4dCk7XG5cdGxldCBwYXJlbnRHbG9iYWxOb3RGb3VuZDtcblx0bGV0IHBhcmVudE5vdEZvdW5kRXJyb3I7XG5cdGxldCBjaGlsZFJvdXRlSWQ7XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHtcblx0XHRjb25zdCBtYXRjaGVzID0gcm91dGVyLnN0b3Jlcy5tYXRjaGVzLmdldCgpO1xuXHRcdGNvbnN0IHBhcmVudEluZGV4ID0gbWF0Y2hlcy5maW5kSW5kZXgoKG1hdGNoKSA9PiBtYXRjaC5yb3V0ZUlkID09PSByb3V0ZUlkKTtcblx0XHRjb25zdCBwYXJlbnRNYXRjaCA9IG1hdGNoZXNbcGFyZW50SW5kZXhdO1xuXHRcdHBhcmVudEdsb2JhbE5vdEZvdW5kID0gISFwYXJlbnRNYXRjaC5fbm90Rm91bmQ7XG5cdFx0cGFyZW50Tm90Rm91bmRFcnJvciA9IHBhcmVudE1hdGNoLmVycm9yO1xuXHRcdGNoaWxkUm91dGVJZCA9IG1hdGNoZXNbcGFyZW50SW5kZXggKyAxXT8ucm91dGVJZDtcblx0fSBlbHNlIHtcblx0XHRjb25zdCBwYXJlbnRNYXRjaFN0b3JlID0gcm91dGVyLnN0b3Jlcy5nZXRNYXRjaFN0b3JlKHJvdXRlSWQpO1xuXHRcdFtwYXJlbnRHbG9iYWxOb3RGb3VuZCwgcGFyZW50Tm90Rm91bmRFcnJvcl0gPSB1c2VTZWxlY3RvcihwYXJlbnRNYXRjaFN0b3JlLCAobWF0Y2gpID0+IFshIW1hdGNoLl9ub3RGb3VuZCwgbWF0Y2guZXJyb3JdLCB7IGNvbXBhcmU6IG91dGxldE1hdGNoU2VsZWN0aW9uRXF1YWwgfSk7XG5cdFx0Y2hpbGRSb3V0ZUlkID0gdXNlU2VsZWN0b3Iocm91dGVyLnN0b3Jlcy5pZHMsIChpZHMpID0+IHtcblx0XHRcdHJldHVybiBpZHNbaWRzLmluZGV4T2Yocm91dGVJZCkgKyAxXTtcblx0XHR9KTtcblx0fVxuXHRpZiAocGFyZW50R2xvYmFsTm90Rm91bmQpIHJldHVybiByZW5kZXJSb3V0ZU5vdEZvdW5kKHJvdXRlciwgcm91dGVyLnJvdXRlc0J5SWRbcm91dGVJZF0sIHBhcmVudE5vdEZvdW5kRXJyb3IpO1xuXHRpZiAoIWNoaWxkUm91dGVJZCkgcmV0dXJuIG51bGw7XG5cdGNvbnN0IG5leHRNYXRjaCA9IC8qIEBfX1BVUkVfXyAqLyBqc3goTWF0Y2gsIHsgcm91dGVJZDogY2hpbGRSb3V0ZUlkIH0pO1xuXHRpZiAocm91dGVJZCA9PT0gcm9vdFJvdXRlSWQpIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFJlYWN0JDEuU3VzcGVuc2UsIHtcblx0XHRmYWxsYmFjazogcmVuZGVyUGVuZGluZyhyb3V0ZXIpLFxuXHRcdGNoaWxkcmVuOiBuZXh0TWF0Y2hcblx0fSk7XG5cdHJldHVybiBuZXh0TWF0Y2g7XG59KTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgTWF0Y2gsIE1hdGNoSW5uZXIsIE91dGxldCwgcmVuZGVyUGVuZGluZyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1NYXRjaC5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZUxheW91dEVmZmVjdCB9IGZyb20gXCIuL3V0aWxzLmpzXCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IGdldExvY2F0aW9uQ2hhbmdlSW5mbywgdHJpbVBhdGhSaWdodCB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG4vLyNyZWdpb24gc3JjL1RyYW5zaXRpb25lci50c3hcbmZ1bmN0aW9uIHNldHRsZU93bmVyKG93bmVyLCByZW5kZXJlZCkge1xuXHRjb25zdCBzZXR0bGUgPSBvd25lclsxXTtcblx0b3duZXIubGVuZ3RoID0gMDtcblx0c2V0dGxlPy4ocmVuZGVyZWQpO1xufVxuZnVuY3Rpb24gVHJhbnNpdGlvbmVyKHsgdCB9KSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCBhY2tub3dsZWRnZW1lbnQgPSByb3V0ZXIuX3JlbmRlcmVkID8/PSBbXTtcblx0Y29uc3QgbW91bnRlZCA9IHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiA/IFJlYWN0JDEudXNlUmVmKGZhbHNlKSA6IHZvaWQgMDtcblx0cm91dGVyLnN0YXJ0VHJhbnNpdGlvbiA9IChmbiwgZXhwZWN0ZWQpID0+IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0c2V0dGxlT3duZXIoYWNrbm93bGVkZ2VtZW50LCBmYWxzZSk7XG5cdFx0YWNrbm93bGVkZ2VtZW50LnB1c2goZXhwZWN0ZWQsIHJlc29sdmUpO1xuXHRcdHQocm91dGVyKTtcblx0XHRSZWFjdCQxLnN0YXJ0VHJhbnNpdGlvbihmbik7XG5cdH0pO1xuXHR1c2VMYXlvdXRFZmZlY3QoKCkgPT4ge1xuXHRcdGNvbnN0IHVuc3ViID0gcm91dGVyLmhpc3Rvcnkuc3Vic2NyaWJlKHJvdXRlci5sb2FkKTtcblx0XHRpZiAobW91bnRlZD8uY3VycmVudCkgcmV0dXJuIHVuc3ViO1xuXHRcdGlmIChtb3VudGVkKSBtb3VudGVkLmN1cnJlbnQgPSB0cnVlO1xuXHRcdHJvdXRlci51cGRhdGVMYXRlc3RMb2NhdGlvbigpO1xuXHRcdGNvbnN0IGxvY2F0aW9uID0gcm91dGVyLmxhdGVzdExvY2F0aW9uO1xuXHRcdGNvbnN0IG5leHRMb2NhdGlvbiA9IHJvdXRlci5idWlsZExvY2F0aW9uKHtcblx0XHRcdHRvOiBsb2NhdGlvbi5wYXRobmFtZSxcblx0XHRcdHNlYXJjaDogdHJ1ZSxcblx0XHRcdHBhcmFtczogdHJ1ZSxcblx0XHRcdGhhc2g6IHRydWUsXG5cdFx0XHRzdGF0ZTogdHJ1ZSxcblx0XHRcdF9pbmNsdWRlVmFsaWRhdGVTZWFyY2g6IHRydWVcblx0XHR9KTtcblx0XHRpZiAodHJpbVBhdGhSaWdodChsb2NhdGlvbi5wdWJsaWNIcmVmKSAhPT0gdHJpbVBhdGhSaWdodChuZXh0TG9jYXRpb24ucHVibGljSHJlZikpIHtcblx0XHRcdHJvdXRlci5jb21taXRMb2NhdGlvbih7XG5cdFx0XHRcdC4uLm5leHRMb2NhdGlvbixcblx0XHRcdFx0cmVwbGFjZTogdHJ1ZSxcblx0XHRcdFx0aWdub3JlQmxvY2tlcjogdHJ1ZVxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gdW5zdWI7XG5cdFx0fVxuXHRcdGNvbnN0IHJlc29sdmVkTG9jYXRpb24gPSByb3V0ZXIuc3RvcmVzLnJlc29sdmVkTG9jYXRpb24uZ2V0KCk7XG5cdFx0aWYgKHJlc29sdmVkTG9jYXRpb24/LmhyZWYgPT09IGxvY2F0aW9uLmhyZWYgJiYgcmVzb2x2ZWRMb2NhdGlvbi5zdGF0ZS5fX1RTUl9rZXkgPT09IGxvY2F0aW9uLnN0YXRlLl9fVFNSX2tleSkgYWNrbm93bGVkZ2VtZW50LnB1c2gocm91dGVyLnN0b3Jlcy5tYXRjaGVzLmdldCgpLCAocmVuZGVyZWQpID0+IHtcblx0XHRcdGlmIChyZW5kZXJlZCkgcm91dGVyLmVtaXQoe1xuXHRcdFx0XHR0eXBlOiBcIm9uUmVuZGVyZWRcIixcblx0XHRcdFx0Li4uZ2V0TG9jYXRpb25DaGFuZ2VJbmZvKHJlc29sdmVkTG9jYXRpb24sIHJlc29sdmVkTG9jYXRpb24pXG5cdFx0XHR9KTtcblx0XHR9KTtcblx0XHRlbHNlIGlmICghcm91dGVyLl90eCkgcm91dGVyLmxvYWQoeyBzeW5jOiB0cnVlIH0pLmNhdGNoKGNvbnNvbGUuZXJyb3IpO1xuXHRcdHJldHVybiB1bnN1Yjtcblx0fSwgW3JvdXRlciwgcm91dGVyLmhpc3RvcnldKTtcblx0cmV0dXJuIG51bGw7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFRyYW5zaXRpb25lciwgc2V0dGxlT3duZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9VHJhbnNpdGlvbmVyLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlTGF5b3V0RWZmZWN0IH0gZnJvbSBcIi4vdXRpbHMuanNcIjtcbmltcG9ydCB7IENhdGNoQm91bmRhcnkgfSBmcm9tIFwiLi9DYXRjaEJvdW5kYXJ5LmpzXCI7XG5pbXBvcnQgeyBtYXRjaENvbnRleHQgfSBmcm9tIFwiLi9tYXRjaENvbnRleHQuanNcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgdXNlU3RydWN0dXJhbFNoYXJpbmcgfSBmcm9tIFwiLi91c2VNYXRjaC5qc1wiO1xuaW1wb3J0IHsgVHJhbnNpdGlvbmVyLCBzZXR0bGVPd25lciB9IGZyb20gXCIuL1RyYW5zaXRpb25lci5qc1wiO1xuaW1wb3J0IHsgTWF0Y2gsIHJlbmRlclBlbmRpbmcgfSBmcm9tIFwiLi9NYXRjaC5qc1wiO1xuaW1wb3J0IHsgcm9vdFJvdXRlSWQgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG5pbXBvcnQgKiBhcyBSZWFjdCQxIGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyBGcmFnbWVudCwganN4LCBqc3hzIH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtc3RvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvTWF0Y2hlcy50c3hcbi8qKlxuKiBJbnRlcm5hbCBjb21wb25lbnQgdGhhdCByZW5kZXJzIHRoZSByb3V0ZXIncyBhY3RpdmUgbWF0Y2ggdHJlZSB3aXRoXG4qIHN1c3BlbnNlLCBlcnJvciwgYW5kIG5vdC1mb3VuZCBib3VuZGFyaWVzLiBSZW5kZXJlZCBieSBgUm91dGVyUHJvdmlkZXJgLlxuKi9cbmZ1bmN0aW9uIE1hdGNoZXMoKSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCByb290Um91dGUgPSByb3V0ZXIucm91dGVzQnlJZFtyb290Um91dGVJZF07XG5cdGNvbnN0IHBlbmRpbmdFbGVtZW50ID0gcmVuZGVyUGVuZGluZyhyb3V0ZXIsIHJvb3RSb3V0ZSk7XG5cdGNvbnN0IGlubmVyID0gLyogQF9fUFVSRV9fICovIGpzeHMoRnJhZ21lbnQsIHsgY2hpbGRyZW46IFshKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikgJiYgLyogQF9fUFVSRV9fICovIGpzeChUcmFuc2l0aW9uZXIsIHsgdDogUmVhY3QkMS51c2VTdGF0ZSgpWzFdIH0pLCAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSB8fCByb3V0ZXIuc3NyID8gLyogQF9fUFVSRV9fICovIGpzeChNYXRjaGVzSW5uZXIsIHt9KSA6IC8qIEBfX1BVUkVfXyAqLyBqc3goUmVhY3QkMS5TdXNwZW5zZSwge1xuXHRcdGZhbGxiYWNrOiBwZW5kaW5nRWxlbWVudCxcblx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChNYXRjaGVzSW5uZXIsIHt9KVxuXHR9KV0gfSk7XG5cdHJldHVybiByb3V0ZXIub3B0aW9ucy5Jbm5lcldyYXAgPyAvKiBAX19QVVJFX18gKi8ganN4KHJvdXRlci5vcHRpb25zLklubmVyV3JhcCwgeyBjaGlsZHJlbjogaW5uZXIgfSkgOiBpbm5lcjtcbn1cbmZ1bmN0aW9uIE1hdGNoZXNJbm5lcigpIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGNvbnN0IGFja25vd2xlZGdlbWVudCA9IHJvdXRlci5fcmVuZGVyZWQ7XG5cdGNvbnN0IG1hdGNoZXMgPSBpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIgPyByb3V0ZXIuc3RvcmVzLm1hdGNoZXMuZ2V0KCkgOiB1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLm1hdGNoZXMsICh2YWx1ZSkgPT4gYWNrbm93bGVkZ2VtZW50WzBdID8/IHZhbHVlKTtcblx0Y29uc3QgbWF0Y2ggPSBtYXRjaGVzWzBdO1xuXHRjb25zdCByb3V0ZUlkID0gbWF0Y2g/LnJvdXRlSWQ7XG5cdHVzZUxheW91dEVmZmVjdCgoKSA9PiB7XG5cdFx0aWYgKGFja25vd2xlZGdlbWVudFswXSA9PT0gbWF0Y2hlcykgc2V0dGxlT3duZXIoYWNrbm93bGVkZ2VtZW50LCB0cnVlKTtcblx0fSwgW2Fja25vd2xlZGdlbWVudCwgbWF0Y2hlc10pO1xuXHRjb25zdCBtYXRjaENvbXBvbmVudCA9IHJvdXRlSWQgPyAvKiBAX19QVVJFX18gKi8ganN4KE1hdGNoLCB7IHJvdXRlSWQgfSkgOiBudWxsO1xuXHRyZXR1cm4gcm91dGVyLm9wdGlvbnMuZGlzYWJsZUdsb2JhbENhdGNoQm91bmRhcnkgPyBtYXRjaENvbXBvbmVudCA6IC8qIEBfX1BVUkVfXyAqLyBqc3goQ2F0Y2hCb3VuZGFyeSwge1xuXHRcdGdldFJlc2V0S2V5OiAoKSA9PiBtYXRjaCxcblx0XHRvbkNhdGNoOiBwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgPyAoZXJyb3IpID0+IHtcblx0XHRcdGNvbnNvbGUud2FybihgV2FybmluZzogVGhlIGZvbGxvd2luZyBlcnJvciB3YXNuJ3QgY2F1Z2h0IGJ5IGFueSByb3V0ZSEgQXQgdGhlIHZlcnkgbGVhc3QsIGNvbnNpZGVyIHNldHRpbmcgYW4gJ2Vycm9yQ29tcG9uZW50JyBpbiB5b3VyIFJvb3RSb3V0ZSFgKTtcblx0XHRcdGNvbnNvbGUud2FybihcIldhcm5pbmc6XCIsIGVycm9yKTtcblx0XHR9IDogdm9pZCAwLFxuXHRcdGNoaWxkcmVuOiBtYXRjaENvbXBvbmVudFxuXHR9KTtcbn1cbi8qKlxuKiBDcmVhdGUgYSBtYXRjaGVyIGZ1bmN0aW9uIGZvciB0ZXN0aW5nIGxvY2F0aW9ucyBhZ2FpbnN0IHJvdXRlIGRlZmluaXRpb25zLlxuKlxuKiBUaGUgcmV0dXJuZWQgZnVuY3Rpb24gYWNjZXB0cyBzdGFuZGFyZCBuYXZpZ2F0aW9uIG9wdGlvbnMgKGB0b2AsIGBwYXJhbXNgLFxuKiBgc2VhcmNoYCwgZXRjLikgYW5kIHJldHVybnMgZWl0aGVyIGBmYWxzZWAgKG5vIG1hdGNoKSBvciB0aGUgbWF0Y2hlZCBwYXJhbXNcbiogb2JqZWN0IHdoZW4gdGhlIHJvdXRlIG1hdGNoZXMgdGhlIGN1cnJlbnQgb3IgcGVuZGluZyBsb2NhdGlvbi5cbipcbiogVXNlZnVsIGZvciBjb25kaXRpb25hbCByZW5kZXJpbmcgYW5kIGFjdGl2ZSBVSSBzdGF0ZXMgYmVjYXVzZSBpdCBzdWJzY3JpYmVzXG4qIHRoZSBjb21wb25lbnQgdG8gdGhlIHJvdXRlciBzdGF0ZSB1c2VkIGZvciBtYXRjaGluZy4gVGhlIHJldHVybmVkIGZ1bmN0aW9uJ3NcbiogaWRlbnRpdHkgY2hhbmdlcyB3aGVuIHRoYXQgc3RhdGUgY2hhbmdlcy4gRm9yIGltcGVyYXRpdmUgY2hlY2tzIGluIGV2ZW50XG4qIGhhbmRsZXJzLCBnZXQgdGhlIHJvdXRlciB3aXRoIGB1c2VSb3V0ZXJgIGFuZCBjYWxsIGByb3V0ZXIubWF0Y2hSb3V0ZSguLi4pYFxuKiB0byBhdm9pZCB0aGF0IHN1YnNjcmlwdGlvbi5cbipcbiogQHJldHVybnMgQSBgbWF0Y2hSb3V0ZShvcHRpb25zKWAgZnVuY3Rpb24gdGhhdCByZXR1cm5zIGBmYWxzZWAgb3IgcGFyYW1zLlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvdXNlTWF0Y2hSb3V0ZUhvb2tcbiovXG5mdW5jdGlvbiB1c2VNYXRjaFJvdXRlKCkge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0aWYgKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikgcmV0dXJuIChvcHRzKSA9PiB7XG5cdFx0Y29uc3QgeyBwZW5kaW5nLCBjYXNlU2Vuc2l0aXZlLCBmdXp6eSwgaW5jbHVkZVNlYXJjaCwgLi4ucmVzdCB9ID0gb3B0cztcblx0XHRyZXR1cm4gcm91dGVyLm1hdGNoUm91dGUocmVzdCwge1xuXHRcdFx0cGVuZGluZyxcblx0XHRcdGNhc2VTZW5zaXRpdmUsXG5cdFx0XHRmdXp6eSxcblx0XHRcdGluY2x1ZGVTZWFyY2hcblx0XHR9KTtcblx0fTtcblx0cmV0dXJuIFJlYWN0JDEudXNlQ2FsbGJhY2soKG9wdHMpID0+IHtcblx0XHRjb25zdCB7IHBlbmRpbmcsIGNhc2VTZW5zaXRpdmUsIGZ1enp5LCBpbmNsdWRlU2VhcmNoLCAuLi5yZXN0IH0gPSBvcHRzO1xuXHRcdHJldHVybiByb3V0ZXIubWF0Y2hSb3V0ZShyZXN0LCB7XG5cdFx0XHRwZW5kaW5nLFxuXHRcdFx0Y2FzZVNlbnNpdGl2ZSxcblx0XHRcdGZ1enp5LFxuXHRcdFx0aW5jbHVkZVNlYXJjaFxuXHRcdH0pO1xuXHR9LCBbXG5cdFx0cm91dGVyLFxuXHRcdHVzZVNlbGVjdG9yKHJvdXRlci5zdG9yZXMubG9jYXRpb24sIChsb2NhdGlvbikgPT4gbG9jYXRpb24uaHJlZiksXG5cdFx0dXNlU2VsZWN0b3Iocm91dGVyLnN0b3Jlcy5yZXNvbHZlZExvY2F0aW9uLCAobG9jYXRpb24pID0+IGxvY2F0aW9uPy5ocmVmKSxcblx0XHR1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLnN0YXR1cylcblx0XSk7XG59XG4vKipcbiogQ29tcG9uZW50IHRoYXQgY29uZGl0aW9uYWxseSByZW5kZXJzIGl0cyBjaGlsZHJlbiBiYXNlZCBvbiB3aGV0aGVyIGEgcm91dGVcbiogbWF0Y2hlcyB0aGUgcHJvdmlkZWQgYGZyb21gL2B0b2Agb3B0aW9ucy4gSWYgYGNoaWxkcmVuYCBpcyBhIGZ1bmN0aW9uLCBpdFxuKiByZWNlaXZlcyB0aGUgbWF0Y2hlZCBwYXJhbXMgb2JqZWN0LlxuKlxuKiBAbGluayBodHRwczovL3RhbnN0YWNrLmNvbS9yb3V0ZXIvbGF0ZXN0L2RvY3MvZnJhbWV3b3JrL3JlYWN0L2FwaS9yb3V0ZXIvbWF0Y2hSb3V0ZUNvbXBvbmVudFxuKi9cbmZ1bmN0aW9uIE1hdGNoUm91dGUocHJvcHMpIHtcblx0Y29uc3QgcGFyYW1zID0gdXNlTWF0Y2hSb3V0ZSgpKHByb3BzKTtcblx0aWYgKHR5cGVvZiBwcm9wcy5jaGlsZHJlbiA9PT0gXCJmdW5jdGlvblwiKSByZXR1cm4gcHJvcHMuY2hpbGRyZW4ocGFyYW1zKTtcblx0cmV0dXJuIHBhcmFtcyA/IHByb3BzLmNoaWxkcmVuIDogbnVsbDtcbn1cbmZ1bmN0aW9uIHVzZU1hdGNoZXMob3B0cykge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0aWYgKGlzU2VydmVyID8/IHJvdXRlci5pc1NlcnZlcikge1xuXHRcdGNvbnN0IG1hdGNoZXMgPSByb3V0ZXIuc3RvcmVzLm1hdGNoZXMuZ2V0KCk7XG5cdFx0cmV0dXJuIG9wdHM/LnNlbGVjdCA/IG9wdHMuc2VsZWN0KG1hdGNoZXMpIDogbWF0Y2hlcztcblx0fVxuXHRyZXR1cm4gdXNlU2VsZWN0b3Iocm91dGVyLnN0b3Jlcy5tYXRjaGVzLCB1c2VTdHJ1Y3R1cmFsU2hhcmluZyhvcHRzLCByb3V0ZXIpKTtcbn1cbi8qKlxuKiBSZWFkIHRoZSBwcmVzZW50ZWQgcm91dGUgbWF0Y2hlcyBhYm92ZSB0aGUgY3VycmVudCBtYXRjaCwgb3Igc2VsZWN0IGFcbiogZGVyaXZlZCB2YWx1ZSBmcm9tIHRoZW0uXG4qL1xuZnVuY3Rpb24gdXNlUGFyZW50TWF0Y2hlcyhvcHRzKSB7XG5cdGNvbnN0IGNvbnRleHRSb3V0ZUlkID0gUmVhY3QkMS51c2VDb250ZXh0KG1hdGNoQ29udGV4dCk7XG5cdHJldHVybiB1c2VNYXRjaGVzKHtcblx0XHRzZWxlY3Q6IChtYXRjaGVzKSA9PiB7XG5cdFx0XHRtYXRjaGVzID0gbWF0Y2hlcy5zbGljZSgwLCBtYXRjaGVzLmZpbmRJbmRleCgoZCkgPT4gZC5yb3V0ZUlkID09PSBjb250ZXh0Um91dGVJZCkpO1xuXHRcdFx0cmV0dXJuIG9wdHM/LnNlbGVjdCA/IG9wdHMuc2VsZWN0KG1hdGNoZXMpIDogbWF0Y2hlcztcblx0XHR9LFxuXHRcdHN0cnVjdHVyYWxTaGFyaW5nOiBvcHRzPy5zdHJ1Y3R1cmFsU2hhcmluZ1xuXHR9KTtcbn1cbi8qKlxuKiBSZWFkIHRoZSBwcmVzZW50ZWQgcm91dGUgbWF0Y2hlcyBiZWxvdyB0aGUgY3VycmVudCBtYXRjaCwgb3Igc2VsZWN0IGFcbiogZGVyaXZlZCB2YWx1ZSBmcm9tIHRoZW0uXG4qL1xuZnVuY3Rpb24gdXNlQ2hpbGRNYXRjaGVzKG9wdHMpIHtcblx0Y29uc3QgY29udGV4dFJvdXRlSWQgPSBSZWFjdCQxLnVzZUNvbnRleHQobWF0Y2hDb250ZXh0KTtcblx0cmV0dXJuIHVzZU1hdGNoZXMoe1xuXHRcdHNlbGVjdDogKG1hdGNoZXMpID0+IHtcblx0XHRcdG1hdGNoZXMgPSBtYXRjaGVzLnNsaWNlKG1hdGNoZXMuZmluZEluZGV4KChkKSA9PiBkLnJvdXRlSWQgPT09IGNvbnRleHRSb3V0ZUlkKSArIDEpO1xuXHRcdFx0cmV0dXJuIG9wdHM/LnNlbGVjdCA/IG9wdHMuc2VsZWN0KG1hdGNoZXMpIDogbWF0Y2hlcztcblx0XHR9LFxuXHRcdHN0cnVjdHVyYWxTaGFyaW5nOiBvcHRzPy5zdHJ1Y3R1cmFsU2hhcmluZ1xuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgTWF0Y2hSb3V0ZSwgTWF0Y2hlcywgdXNlQ2hpbGRNYXRjaGVzLCB1c2VNYXRjaFJvdXRlLCB1c2VNYXRjaGVzLCB1c2VQYXJlbnRNYXRjaGVzIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPU1hdGNoZXMuanMubWFwIiwiaW1wb3J0IHsgY3JlYXRlTm9uUmVhY3RpdmVNdXRhYmxlU3RvcmUsIGNyZWF0ZU5vblJlYWN0aXZlUmVhZG9ubHlTdG9yZSB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuaW1wb3J0IHsgYmF0Y2gsIGNyZWF0ZUF0b20gfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXN0b3JlXCI7XG4vLyNyZWdpb24gc3JjL3JvdXRlclN0b3Jlcy50c1xudmFyIGdldFN0b3JlRmFjdG9yeSA9IChvcHRzKSA9PiB7XG5cdGlmIChpc1NlcnZlciA/PyBvcHRzLmlzU2VydmVyKSByZXR1cm4ge1xuXHRcdGNyZWF0ZU11dGFibGVTdG9yZTogY3JlYXRlTm9uUmVhY3RpdmVNdXRhYmxlU3RvcmUsXG5cdFx0Y3JlYXRlUmVhZG9ubHlTdG9yZTogY3JlYXRlTm9uUmVhY3RpdmVSZWFkb25seVN0b3JlLFxuXHRcdGJhdGNoOiAoZm4pID0+IGZuKClcblx0fTtcblx0cmV0dXJuIHtcblx0XHRjcmVhdGVNdXRhYmxlU3RvcmU6IGNyZWF0ZUF0b20sXG5cdFx0Y3JlYXRlUmVhZG9ubHlTdG9yZTogY3JlYXRlQXRvbSxcblx0XHRiYXRjaFxuXHR9O1xufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgZ2V0U3RvcmVGYWN0b3J5IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJvdXRlclN0b3Jlcy5qcy5tYXAiLCJpbXBvcnQgeyBnZXRTdG9yZUZhY3RvcnkgfSBmcm9tIFwiLi9yb3V0ZXJTdG9yZXMuanNcIjtcbmltcG9ydCB7IFJvdXRlckNvcmUgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlXCI7XG4vLyNyZWdpb24gc3JjL3JvdXRlci50c1xuLyoqXG4qIENyZWF0ZXMgYSBuZXcgUm91dGVyIGluc3RhbmNlIGZvciBSZWFjdC5cbipcbiogUGFzcyB0aGUgcmV0dXJuZWQgcm91dGVyIHRvIGBSb3V0ZXJQcm92aWRlcmAgdG8gZW5hYmxlIHJvdXRpbmcuXG4qIE5vdGFibGUgb3B0aW9uczogYHJvdXRlVHJlZWAgKHlvdXIgcm91dGUgZGVmaW5pdGlvbnMpIGFuZCBgY29udGV4dGBcbiogKHJlcXVpcmVkIGlmIHRoZSByb290IHJvdXRlIHdhcyBjcmVhdGVkIHdpdGggYGNyZWF0ZVJvb3RSb3V0ZVdpdGhDb250ZXh0YCkuXG4qXG4qIEBwYXJhbSBvcHRpb25zIFJvdXRlciBvcHRpb25zIHVzZWQgdG8gY29uZmlndXJlIHRoZSByb3V0ZXIuXG4qIEByZXR1cm5zIEEgUm91dGVyIGluc3RhbmNlIHRvIGJlIHByb3ZpZGVkIHRvIGBSb3V0ZXJQcm92aWRlcmAuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci9jcmVhdGVSb3V0ZXJGdW5jdGlvblxuKi9cbnZhciBjcmVhdGVSb3V0ZXIgPSAob3B0aW9ucykgPT4ge1xuXHRyZXR1cm4gbmV3IFJvdXRlcihvcHRpb25zKTtcbn07XG52YXIgUm91dGVyID0gY2xhc3MgZXh0ZW5kcyBSb3V0ZXJDb3JlIHtcblx0Y29uc3RydWN0b3Iob3B0aW9ucykge1xuXHRcdHN1cGVyKG9wdGlvbnMsIGdldFN0b3JlRmFjdG9yeSk7XG5cdH1cbn07XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFJvdXRlciwgY3JlYXRlUm91dGVyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJvdXRlci5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHJvdXRlckNvbnRleHQgfSBmcm9tIFwiLi9yb3V0ZXJDb250ZXh0LmpzXCI7XG5pbXBvcnQgeyBNYXRjaGVzIH0gZnJvbSBcIi4vTWF0Y2hlcy5qc1wiO1xuaW1wb3J0IHsgaGFzS2V5cyB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCBcInJlYWN0XCI7XG5pbXBvcnQgeyBqc3ggfSBmcm9tIFwicmVhY3QvanN4LXJ1bnRpbWVcIjtcbi8vI3JlZ2lvbiBzcmMvUm91dGVyUHJvdmlkZXIudHN4XG4vKipcbiogTG93LWxldmVsIHByb3ZpZGVyIHRoYXQgcGxhY2VzIHRoZSByb3V0ZXIgaW50byBSZWFjdCBjb250ZXh0IGFuZCBvcHRpb25hbGx5XG4qIHVwZGF0ZXMgcm91dGVyIG9wdGlvbnMgZnJvbSBwcm9wcy4gTW9zdCBhcHBzIHNob3VsZCB1c2UgYFJvdXRlclByb3ZpZGVyYC5cbiovXG5mdW5jdGlvbiBSb3V0ZXJDb250ZXh0UHJvdmlkZXIoeyByb3V0ZXIsIGNoaWxkcmVuLCAuLi5yZXN0IH0pIHtcblx0aWYgKGhhc0tleXMocmVzdCkpIHJvdXRlci51cGRhdGUoe1xuXHRcdC4uLnJvdXRlci5vcHRpb25zLFxuXHRcdC4uLnJlc3QsXG5cdFx0Y29udGV4dDoge1xuXHRcdFx0Li4ucm91dGVyLm9wdGlvbnMuY29udGV4dCxcblx0XHRcdC4uLnJlc3QuY29udGV4dFxuXHRcdH1cblx0fSk7XG5cdGNvbnN0IHByb3ZpZGVyID0gLyogQF9fUFVSRV9fICovIGpzeChyb3V0ZXJDb250ZXh0LlByb3ZpZGVyLCB7XG5cdFx0dmFsdWU6IHJvdXRlcixcblx0XHRjaGlsZHJlblxuXHR9KTtcblx0aWYgKHJvdXRlci5vcHRpb25zLldyYXApIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KHJvdXRlci5vcHRpb25zLldyYXAsIHsgY2hpbGRyZW46IHByb3ZpZGVyIH0pO1xuXHRyZXR1cm4gcHJvdmlkZXI7XG59XG4vKipcbiogUmVuZGVycyB0aGUgY3VycmVudCBtYXRjaCBwcmVzZW50YXRpb24gYW5kIHByb3ZpZGVzIHRoZSByb3V0ZXIgdG8gdGhlIFJlYWN0XG4qIHRyZWUgdmlhIGNvbnRleHQuXG4qXG4qIEFjY2VwdHMgbXV0YWJsZSByb3V0ZXIgb3B0aW9ucyB2aWEgcHJvcHMuIENvbmZpZ3VyZSBpbml0aWFsaXphdGlvbi1vbmx5XG4qIG9wdGlvbnMgd2l0aCBgY3JlYXRlUm91dGVyYC5cbipcbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9hcGkvcm91dGVyL2NyZWF0ZVJvdXRlckZ1bmN0aW9uXG4qL1xuZnVuY3Rpb24gUm91dGVyUHJvdmlkZXIoeyByb3V0ZXIsIC4uLnJlc3QgfSkge1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChSb3V0ZXJDb250ZXh0UHJvdmlkZXIsIHtcblx0XHRyb3V0ZXIsXG5cdFx0Li4ucmVzdCxcblx0XHRjaGlsZHJlbjogLyogQF9fUFVSRV9fICovIGpzeChNYXRjaGVzLCB7fSlcblx0fSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IFJvdXRlckNvbnRleHRQcm92aWRlciwgUm91dGVyUHJvdmlkZXIgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Um91dGVyUHJvdmlkZXIuanMubWFwIiwiaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyBnZXRFbGVtZW50U2Nyb2xsUmVzdG9yYXRpb25FbnRyeSwgc2V0dXBTY3JvbGxSZXN0b3JhdGlvbiB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvU2Nyb2xsUmVzdG9yYXRpb24udHN4XG5mdW5jdGlvbiB1c2VTY3JvbGxSZXN0b3JhdGlvbigpIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdHNldHVwU2Nyb2xsUmVzdG9yYXRpb24ocm91dGVyLCB0cnVlKTtcbn1cbi8qKlxuKiBAZGVwcmVjYXRlZCBVc2UgdGhlIGBzY3JvbGxSZXN0b3JhdGlvbmAgcm91dGVyIG9wdGlvbiBpbnN0ZWFkLlxuKi9cbmZ1bmN0aW9uIFNjcm9sbFJlc3RvcmF0aW9uKF9wcm9wcykge1xuXHR1c2VTY3JvbGxSZXN0b3JhdGlvbigpO1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwiZGV2ZWxvcG1lbnRcIikgY29uc29sZS53YXJuKFwiVGhlIFNjcm9sbFJlc3RvcmF0aW9uIGNvbXBvbmVudCBpcyBkZXByZWNhdGVkLiBVc2UgY3JlYXRlUm91dGVyJ3MgYHNjcm9sbFJlc3RvcmF0aW9uYCBvcHRpb24gaW5zdGVhZC5cIik7XG5cdHJldHVybiBudWxsO1xufVxuZnVuY3Rpb24gdXNlRWxlbWVudFNjcm9sbFJlc3RvcmF0aW9uKG9wdGlvbnMpIHtcblx0dXNlU2Nyb2xsUmVzdG9yYXRpb24oKTtcblx0cmV0dXJuIGdldEVsZW1lbnRTY3JvbGxSZXN0b3JhdGlvbkVudHJ5KHVzZVJvdXRlcigpLCBvcHRpb25zKTtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgU2Nyb2xsUmVzdG9yYXRpb24sIHVzZUVsZW1lbnRTY3JvbGxSZXN0b3JhdGlvbiB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1TY3JvbGxSZXN0b3JhdGlvbi5qcy5tYXAiLCJcInVzZSBjbGllbnRcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0ICogYXMgUmVhY3QkMSBmcm9tIFwicmVhY3RcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlQmxvY2tlci50c3hcbmZ1bmN0aW9uIF9yZXNvbHZlQmxvY2tlck9wdHMob3B0cywgY29uZGl0aW9uKSB7XG5cdGlmIChvcHRzID09PSB2b2lkIDApIHJldHVybiB7XG5cdFx0c2hvdWxkQmxvY2tGbjogKCkgPT4gdHJ1ZSxcblx0XHR3aXRoUmVzb2x2ZXI6IGZhbHNlXG5cdH07XG5cdGlmIChcInNob3VsZEJsb2NrRm5cIiBpbiBvcHRzKSByZXR1cm4gb3B0cztcblx0aWYgKHR5cGVvZiBvcHRzID09PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRjb25zdCBzaG91bGRCbG9jayA9IEJvb2xlYW4oY29uZGl0aW9uID8/IHRydWUpO1xuXHRcdGNvbnN0IF9jdXN0b21CbG9ja2VyRm4gPSBhc3luYyAoKSA9PiB7XG5cdFx0XHRpZiAoc2hvdWxkQmxvY2spIHJldHVybiBhd2FpdCBvcHRzKCk7XG5cdFx0XHRyZXR1cm4gZmFsc2U7XG5cdFx0fTtcblx0XHRyZXR1cm4ge1xuXHRcdFx0c2hvdWxkQmxvY2tGbjogX2N1c3RvbUJsb2NrZXJGbixcblx0XHRcdGVuYWJsZUJlZm9yZVVubG9hZDogc2hvdWxkQmxvY2ssXG5cdFx0XHR3aXRoUmVzb2x2ZXI6IGZhbHNlXG5cdFx0fTtcblx0fVxuXHRjb25zdCBzaG91bGRCbG9jayA9IEJvb2xlYW4ob3B0cy5jb25kaXRpb24gPz8gdHJ1ZSk7XG5cdGNvbnN0IGZuID0gb3B0cy5ibG9ja2VyRm47XG5cdGNvbnN0IF9jdXN0b21CbG9ja2VyRm4gPSBhc3luYyAoKSA9PiB7XG5cdFx0aWYgKHNob3VsZEJsb2NrICYmIGZuICE9PSB2b2lkIDApIHJldHVybiBhd2FpdCBmbigpO1xuXHRcdHJldHVybiBzaG91bGRCbG9jaztcblx0fTtcblx0cmV0dXJuIHtcblx0XHRzaG91bGRCbG9ja0ZuOiBfY3VzdG9tQmxvY2tlckZuLFxuXHRcdGVuYWJsZUJlZm9yZVVubG9hZDogc2hvdWxkQmxvY2ssXG5cdFx0d2l0aFJlc29sdmVyOiBmbiA9PT0gdm9pZCAwXG5cdH07XG59XG5mdW5jdGlvbiB1c2VCbG9ja2VyKG9wdHMsIGNvbmRpdGlvbikge1xuXHRjb25zdCB7IHNob3VsZEJsb2NrRm4sIGVuYWJsZUJlZm9yZVVubG9hZCA9IHRydWUsIGRpc2FibGVkID0gZmFsc2UsIHdpdGhSZXNvbHZlciA9IGZhbHNlIH0gPSBfcmVzb2x2ZUJsb2NrZXJPcHRzKG9wdHMsIGNvbmRpdGlvbik7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRjb25zdCB7IGhpc3RvcnkgfSA9IHJvdXRlcjtcblx0Y29uc3QgW3Jlc29sdmVyLCBzZXRSZXNvbHZlcl0gPSBSZWFjdCQxLnVzZVN0YXRlKHtcblx0XHRzdGF0dXM6IFwiaWRsZVwiLFxuXHRcdGN1cnJlbnQ6IHZvaWQgMCxcblx0XHRuZXh0OiB2b2lkIDAsXG5cdFx0YWN0aW9uOiB2b2lkIDAsXG5cdFx0cHJvY2VlZDogdm9pZCAwLFxuXHRcdHJlc2V0OiB2b2lkIDBcblx0fSk7XG5cdFJlYWN0JDEudXNlRWZmZWN0KCgpID0+IHtcblx0XHRjb25zdCBibG9ja2VyRm5Db21wb3NlZCA9IGFzeW5jIChibG9ja2VyRm5BcmdzKSA9PiB7XG5cdFx0XHRmdW5jdGlvbiBnZXRMb2NhdGlvbihsb2NhdGlvbikge1xuXHRcdFx0XHRjb25zdCBwYXJzZWRMb2NhdGlvbiA9IHJvdXRlci5wYXJzZUxvY2F0aW9uKGxvY2F0aW9uKTtcblx0XHRcdFx0Y29uc3QgWywgcmF3UGFyYW1zLCBmb3VuZFJvdXRlXSA9IHJvdXRlci5nZXRNYXRjaGVkUm91dGVzKHBhcnNlZExvY2F0aW9uLnBhdGhuYW1lKTtcblx0XHRcdFx0aWYgKGZvdW5kUm91dGUgPT09IHZvaWQgMCkgcmV0dXJuIHtcblx0XHRcdFx0XHRyb3V0ZUlkOiBcIl9fbm90Rm91bmRfX1wiLFxuXHRcdFx0XHRcdGZ1bGxQYXRoOiBwYXJzZWRMb2NhdGlvbi5wYXRobmFtZSxcblx0XHRcdFx0XHRwYXRobmFtZTogcGFyc2VkTG9jYXRpb24ucGF0aG5hbWUsXG5cdFx0XHRcdFx0cGFyYW1zOiByYXdQYXJhbXMsXG5cdFx0XHRcdFx0c2VhcmNoOiByb3V0ZXIub3B0aW9ucy5wYXJzZVNlYXJjaChsb2NhdGlvbi5zZWFyY2gpXG5cdFx0XHRcdH07XG5cdFx0XHRcdHJldHVybiB7XG5cdFx0XHRcdFx0cm91dGVJZDogZm91bmRSb3V0ZS5pZCxcblx0XHRcdFx0XHRmdWxsUGF0aDogZm91bmRSb3V0ZS5mdWxsUGF0aCxcblx0XHRcdFx0XHRwYXRobmFtZTogcGFyc2VkTG9jYXRpb24ucGF0aG5hbWUsXG5cdFx0XHRcdFx0cGFyYW1zOiByYXdQYXJhbXMsXG5cdFx0XHRcdFx0c2VhcmNoOiByb3V0ZXIub3B0aW9ucy5wYXJzZVNlYXJjaChsb2NhdGlvbi5zZWFyY2gpXG5cdFx0XHRcdH07XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBjdXJyZW50ID0gZ2V0TG9jYXRpb24oYmxvY2tlckZuQXJncy5jdXJyZW50TG9jYXRpb24pO1xuXHRcdFx0Y29uc3QgbmV4dCA9IGdldExvY2F0aW9uKGJsb2NrZXJGbkFyZ3MubmV4dExvY2F0aW9uKTtcblx0XHRcdGlmIChjdXJyZW50LnJvdXRlSWQgPT09IFwiX19ub3RGb3VuZF9fXCIgJiYgbmV4dC5yb3V0ZUlkICE9PSBcIl9fbm90Rm91bmRfX1wiKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRjb25zdCBzaG91bGRCbG9jayA9IGF3YWl0IHNob3VsZEJsb2NrRm4oe1xuXHRcdFx0XHRhY3Rpb246IGJsb2NrZXJGbkFyZ3MuYWN0aW9uLFxuXHRcdFx0XHRjdXJyZW50LFxuXHRcdFx0XHRuZXh0XG5cdFx0XHR9KTtcblx0XHRcdGlmICghd2l0aFJlc29sdmVyKSByZXR1cm4gc2hvdWxkQmxvY2s7XG5cdFx0XHRpZiAoIXNob3VsZEJsb2NrKSByZXR1cm4gZmFsc2U7XG5cdFx0XHRjb25zdCBjYW5OYXZpZ2F0ZUFzeW5jID0gYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcblx0XHRcdFx0c2V0UmVzb2x2ZXIoe1xuXHRcdFx0XHRcdHN0YXR1czogXCJibG9ja2VkXCIsXG5cdFx0XHRcdFx0Y3VycmVudCxcblx0XHRcdFx0XHRuZXh0LFxuXHRcdFx0XHRcdGFjdGlvbjogYmxvY2tlckZuQXJncy5hY3Rpb24sXG5cdFx0XHRcdFx0cHJvY2VlZDogKCkgPT4gcmVzb2x2ZShmYWxzZSksXG5cdFx0XHRcdFx0cmVzZXQ6ICgpID0+IHJlc29sdmUodHJ1ZSlcblx0XHRcdFx0fSk7XG5cdFx0XHR9KTtcblx0XHRcdHNldFJlc29sdmVyKHtcblx0XHRcdFx0c3RhdHVzOiBcImlkbGVcIixcblx0XHRcdFx0Y3VycmVudDogdm9pZCAwLFxuXHRcdFx0XHRuZXh0OiB2b2lkIDAsXG5cdFx0XHRcdGFjdGlvbjogdm9pZCAwLFxuXHRcdFx0XHRwcm9jZWVkOiB2b2lkIDAsXG5cdFx0XHRcdHJlc2V0OiB2b2lkIDBcblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIGNhbk5hdmlnYXRlQXN5bmM7XG5cdFx0fTtcblx0XHRyZXR1cm4gZGlzYWJsZWQgPyB2b2lkIDAgOiBoaXN0b3J5LmJsb2NrKHtcblx0XHRcdGJsb2NrZXJGbjogYmxvY2tlckZuQ29tcG9zZWQsXG5cdFx0XHRlbmFibGVCZWZvcmVVbmxvYWRcblx0XHR9KTtcblx0fSwgW1xuXHRcdHNob3VsZEJsb2NrRm4sXG5cdFx0ZW5hYmxlQmVmb3JlVW5sb2FkLFxuXHRcdGRpc2FibGVkLFxuXHRcdHdpdGhSZXNvbHZlcixcblx0XHRoaXN0b3J5LFxuXHRcdHJvdXRlclxuXHRdKTtcblx0cmV0dXJuIHJlc29sdmVyO1xufVxudmFyIF9yZXNvbHZlUHJvbXB0QmxvY2tlckFyZ3MgPSAocHJvcHMpID0+IHtcblx0aWYgKFwic2hvdWxkQmxvY2tGblwiIGluIHByb3BzKSByZXR1cm4geyAuLi5wcm9wcyB9O1xuXHRjb25zdCBzaG91bGRCbG9jayA9IEJvb2xlYW4ocHJvcHMuY29uZGl0aW9uID8/IHRydWUpO1xuXHRjb25zdCBmbiA9IHByb3BzLmJsb2NrZXJGbjtcblx0Y29uc3QgX2N1c3RvbUJsb2NrZXJGbiA9IGFzeW5jICgpID0+IHtcblx0XHRpZiAoc2hvdWxkQmxvY2sgJiYgZm4gIT09IHZvaWQgMCkgcmV0dXJuIGF3YWl0IGZuKCk7XG5cdFx0cmV0dXJuIHNob3VsZEJsb2NrO1xuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdHNob3VsZEJsb2NrRm46IF9jdXN0b21CbG9ja2VyRm4sXG5cdFx0ZW5hYmxlQmVmb3JlVW5sb2FkOiBzaG91bGRCbG9jayxcblx0XHR3aXRoUmVzb2x2ZXI6IGZuID09PSB2b2lkIDBcblx0fTtcbn07XG5mdW5jdGlvbiBCbG9jayhvcHRzKSB7XG5cdGNvbnN0IHsgY2hpbGRyZW4sIC4uLnJlc3QgfSA9IG9wdHM7XG5cdGNvbnN0IHJlc29sdmVyID0gdXNlQmxvY2tlcihfcmVzb2x2ZVByb21wdEJsb2NrZXJBcmdzKHJlc3QpKTtcblx0cmV0dXJuIGNoaWxkcmVuID8gdHlwZW9mIGNoaWxkcmVuID09PSBcImZ1bmN0aW9uXCIgPyBjaGlsZHJlbihyZXNvbHZlcikgOiBjaGlsZHJlbiA6IG51bGw7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEJsb2NrLCB1c2VCbG9ja2VyIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUJsb2NrZXIuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IHVzZVN0cnVjdHVyYWxTaGFyaW5nIH0gZnJvbSBcIi4vdXNlTWF0Y2guanNcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuaW1wb3J0IHsgdXNlU2VsZWN0b3IgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXN0b3JlXCI7XG4vLyNyZWdpb24gc3JjL3VzZVJvdXRlclN0YXRlLnRzeFxuLyoqXG4qIFN1YnNjcmliZSB0byB0aGUgcm91dGVyJ3Mgc3RhdGUgc3RvcmUgd2l0aCBvcHRpb25hbCBzZWxlY3Rpb24gYW5kXG4qIHN0cnVjdHVyYWwgc2hhcmluZyBmb3IgcmVuZGVyIG9wdGltaXphdGlvbi5cbipcbiogT3B0aW9uczpcbiogLSBgc2VsZWN0YDogUHJvamVjdCB0aGUgZnVsbCByb3V0ZXIgc3RhdGUgdG8gYSBkZXJpdmVkIHNsaWNlXG4qIC0gYHN0cnVjdHVyYWxTaGFyaW5nYDogUmVwbGFjZS1lcXVhbCBzZW1hbnRpY3MgZm9yIHN0YWJsZSByZWZlcmVuY2VzXG4qIC0gYHJvdXRlcmA6IFJlYWQgc3RhdGUgZnJvbSBhIHNwZWNpZmljIHJvdXRlciBpbnN0YW5jZSBpbnN0ZWFkIG9mIGNvbnRleHRcbipcbiogQHJldHVybnMgVGhlIHNlbGVjdGVkIHJvdXRlciBzdGF0ZSAob3IgdGhlIGZ1bGwgc3RhdGUgYnkgZGVmYXVsdCkuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci91c2VSb3V0ZXJTdGF0ZUhvb2tcbiovXG5mdW5jdGlvbiB1c2VSb3V0ZXJTdGF0ZShvcHRzKSB7XG5cdGNvbnN0IGNvbnRleHRSb3V0ZXIgPSB1c2VSb3V0ZXIoeyB3YXJuOiBvcHRzPy5yb3V0ZXIgPT09IHZvaWQgMCB9KTtcblx0Y29uc3Qgcm91dGVyID0gb3B0cz8ucm91dGVyIHx8IGNvbnRleHRSb3V0ZXI7XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHtcblx0XHRjb25zdCBzdGF0ZSA9IHJvdXRlci5zdG9yZXMuX19zdG9yZS5nZXQoKTtcblx0XHRyZXR1cm4gb3B0cz8uc2VsZWN0ID8gb3B0cy5zZWxlY3Qoc3RhdGUpIDogc3RhdGU7XG5cdH1cblx0cmV0dXJuIHVzZVNlbGVjdG9yKHJvdXRlci5zdG9yZXMuX19zdG9yZSwgdXNlU3RydWN0dXJhbFNoYXJpbmcob3B0cywgcm91dGVyKSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZVJvdXRlclN0YXRlIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZVJvdXRlclN0YXRlLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSBcIi4vdXNlUm91dGVyLmpzXCI7XG5pbXBvcnQgeyB1c2VTdHJ1Y3R1cmFsU2hhcmluZyB9IGZyb20gXCIuL3VzZU1hdGNoLmpzXCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmUvaXNTZXJ2ZXJcIjtcbmltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1zdG9yZVwiO1xuLy8jcmVnaW9uIHNyYy91c2VMb2NhdGlvbi50c3hcbi8qKlxuKiBSZWFkIHRoZSBjdXJyZW50IGxvY2F0aW9uIGZyb20gdGhlIHJvdXRlciBzdGF0ZSB3aXRoIG9wdGlvbmFsIHNlbGVjdGlvbi5cbiogVXNlZnVsIGZvciBzdWJzY3JpYmluZyB0byBqdXN0IHRoZSBwaWVjZXMgb2YgbG9jYXRpb24geW91IGNhcmUgYWJvdXQuXG4qXG4qIE9wdGlvbnM6XG4qIC0gYHNlbGVjdGA6IFByb2plY3QgdGhlIGBsb2NhdGlvbmAgb2JqZWN0IHRvIGEgZGVyaXZlZCB2YWx1ZVxuKiAtIGBzdHJ1Y3R1cmFsU2hhcmluZ2A6IEVuYWJsZSBzdHJ1Y3R1cmFsIHNoYXJpbmcgZm9yIHN0YWJsZSByZWZlcmVuY2VzXG4qXG4qIEByZXR1cm5zIFRoZSBjdXJyZW50IGxvY2F0aW9uIChvciBzZWxlY3RlZCB2YWx1ZSkuXG4qIEBsaW5rIGh0dHBzOi8vdGFuc3RhY2suY29tL3JvdXRlci9sYXRlc3QvZG9jcy9mcmFtZXdvcmsvcmVhY3QvYXBpL3JvdXRlci91c2VMb2NhdGlvbkhvb2tcbiovXG5mdW5jdGlvbiB1c2VMb2NhdGlvbihvcHRzKSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRpZiAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSB7XG5cdFx0Y29uc3QgbG9jYXRpb24gPSByb3V0ZXIuc3RvcmVzLmxvY2F0aW9uLmdldCgpO1xuXHRcdHJldHVybiBvcHRzPy5zZWxlY3QgPyBvcHRzLnNlbGVjdChsb2NhdGlvbikgOiBsb2NhdGlvbjtcblx0fVxuXHRyZXR1cm4gdXNlU2VsZWN0b3Iocm91dGVyLnN0b3Jlcy5sb2NhdGlvbiwgdXNlU3RydWN0dXJhbFNoYXJpbmcob3B0cywgcm91dGVyKSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IHVzZUxvY2F0aW9uIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXVzZUxvY2F0aW9uLmpzLm1hcCIsImltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgaXNTZXJ2ZXIgfSBmcm9tIFwiQHRhbnN0YWNrL3JvdXRlci1jb3JlL2lzU2VydmVyXCI7XG5pbXBvcnQgeyB1c2VTZWxlY3RvciB9IGZyb20gXCJAdGFuc3RhY2svcmVhY3Qtc3RvcmVcIjtcbi8vI3JlZ2lvbiBzcmMvdXNlQ2FuR29CYWNrLnRzXG5mdW5jdGlvbiB1c2VDYW5Hb0JhY2soKSB7XG5cdGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpO1xuXHRpZiAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSByZXR1cm4gcm91dGVyLnN0b3Jlcy5sb2NhdGlvbi5nZXQoKS5zdGF0ZS5fX1RTUl9pbmRleCAhPT0gMDtcblx0cmV0dXJuIHVzZVNlbGVjdG9yKHJvdXRlci5zdG9yZXMubG9jYXRpb24sIChsb2NhdGlvbikgPT4gbG9jYXRpb24uc3RhdGUuX19UU1JfaW5kZXggIT09IDApO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyB1c2VDYW5Hb0JhY2sgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9dXNlQ2FuR29CYWNrLmpzLm1hcCIsIlwidXNlIGNsaWVudFwiO1xuaW1wb3J0IHsgdXNlSHlkcmF0ZWQgfSBmcm9tIFwiLi9DbGllbnRPbmx5LmpzXCI7XG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmUvaXNTZXJ2ZXJcIjtcbmltcG9ydCB7IGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuLy8jcmVnaW9uIHNyYy9Bc3NldC50c3hcbnZhciBJTkxJTkVfQ1NTX0hZRFJBVElPTl9BVFRSID0gXCJkYXRhLXRzci1pbmxpbmUtY3NzXCI7XG52YXIgbm9vcFNjcmlwdEhhbmRsZXIgPSAoKSA9PiB7fTtcbmZ1bmN0aW9uIHNldFNjcmlwdEF0dHJzKHNjcmlwdCwgYXR0cnMpIHtcblx0aWYgKCFhdHRycykgcmV0dXJuO1xuXHRmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhhdHRycykpIGlmIChrZXkgIT09IFwic3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nXCIgJiYgdmFsdWUgIT09IHZvaWQgMCAmJiB2YWx1ZSAhPT0gZmFsc2UpIHNjcmlwdC5zZXRBdHRyaWJ1dGUoa2V5LCB0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiID8gXCJcIiA6IFN0cmluZyh2YWx1ZSkpO1xufVxuZnVuY3Rpb24gQXNzZXQoYXNzZXQpIHtcblx0Y29uc3QgeyBhdHRycywgY2hpbGRyZW4sIG5vbmNlLCBwcmV2ZW50U2NyaXB0SG9pc3QgfSA9IGFzc2V0O1xuXHRjb25zdCBpbm5lckhUTUwgPSBSZWFjdCQxLnVzZU1lbW8oKCkgPT4gY2hpbGRyZW4gPT09IHZvaWQgMCA/IHZvaWQgMCA6IHsgX19odG1sOiBjaGlsZHJlbiB9LCBbY2hpbGRyZW5dKTtcblx0c3dpdGNoIChhc3NldC50YWcpIHtcblx0XHRjYXNlIFwidGl0bGVcIjogcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXCJ0aXRsZVwiLCB7XG5cdFx0XHQuLi5hdHRycyxcblx0XHRcdHN1cHByZXNzSHlkcmF0aW9uV2FybmluZzogdHJ1ZSxcblx0XHRcdGNoaWxkcmVuXG5cdFx0fSk7XG5cdFx0Y2FzZSBcIm1ldGFcIjogcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXCJtZXRhXCIsIHtcblx0XHRcdC4uLmF0dHJzLFxuXHRcdFx0c3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nOiB0cnVlXG5cdFx0fSk7XG5cdFx0Y2FzZSBcImxpbmtcIjogcmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXCJsaW5rXCIsIHtcblx0XHRcdC4uLmF0dHJzLFxuXHRcdFx0cHJlY2VkZW5jZTogYXR0cnM/LnByZWNlZGVuY2UgPz8gKGF0dHJzPy5yZWwgPT09IFwic3R5bGVzaGVldFwiID8gXCJkZWZhdWx0XCIgOiB2b2lkIDApLFxuXHRcdFx0bm9uY2UsXG5cdFx0XHRzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWVcblx0XHR9KTtcblx0XHRjYXNlIFwic3R5bGVcIjpcblx0XHRcdGlmIChhc3NldC5pbmxpbmVDc3MgJiYgKHByb2Nlc3MuZW52LlRTU19JTkxJTkVfQ1NTX0VOQUJMRUQgPT09IFwidHJ1ZVwiIHx8IHByb2Nlc3MuZW52LlRTU19JTkxJTkVfQ1NTX0VOQUJMRUQgPT09IHZvaWQgMCAmJiBpc1NlcnZlcikpIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KElubGluZUNzc1N0eWxlLCB7XG5cdFx0XHRcdGF0dHJzLFxuXHRcdFx0XHRub25jZSxcblx0XHRcdFx0Y2hpbGRyZW5cblx0XHRcdH0pO1xuXHRcdFx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goXCJzdHlsZVwiLCB7XG5cdFx0XHRcdC4uLmF0dHJzLFxuXHRcdFx0XHRkYW5nZXJvdXNseVNldElubmVySFRNTDogaW5uZXJIVE1MLFxuXHRcdFx0XHRub25jZVxuXHRcdFx0fSk7XG5cdFx0Y2FzZSBcInNjcmlwdFwiOiByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChTY3JpcHQsIHtcblx0XHRcdGF0dHJzLFxuXHRcdFx0cHJldmVudFNjcmlwdEhvaXN0LFxuXHRcdFx0Y2hpbGRyZW5cblx0XHR9KTtcblx0XHRkZWZhdWx0OiByZXR1cm4gbnVsbDtcblx0fVxufVxuZnVuY3Rpb24gSW5saW5lQ3NzU3R5bGUoeyBhdHRycywgY2hpbGRyZW4sIG5vbmNlIH0pIHtcblx0Y29uc3QgaXNJbmxpbmVDc3NQbGFjZWhvbGRlciA9IGNoaWxkcmVuID09PSB2b2lkIDA7XG5cdGNvbnN0IFtoeWRyYXRlZElubGluZUNzc10gPSBSZWFjdCQxLnVzZVN0YXRlKCgpID0+IHtcblx0XHRpZiAoIWlzSW5saW5lQ3NzUGxhY2Vob2xkZXIgfHwgdHlwZW9mIGRvY3VtZW50ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm47XG5cdFx0cmV0dXJuIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoYHN0eWxlWyR7SU5MSU5FX0NTU19IWURSQVRJT05fQVRUUn1dYCk/LnRleHRDb250ZW50ID8/IHZvaWQgMDtcblx0fSk7XG5cdGNvbnN0IGh0bWwgPSBpc0lubGluZUNzc1BsYWNlaG9sZGVyID8gaHlkcmF0ZWRJbmxpbmVDc3MgPz8gXCJcIiA6IGNoaWxkcmVuID8/IFwiXCI7XG5cdGNvbnN0IGlubmVySFRNTCA9IFJlYWN0JDEudXNlTWVtbygoKSA9PiAoeyBfX2h0bWw6IGh0bWwgfSksIFtodG1sXSk7XG5cdHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFwic3R5bGVcIiwge1xuXHRcdC4uLmF0dHJzLFxuXHRcdFtJTkxJTkVfQ1NTX0hZRFJBVElPTl9BVFRSXTogXCJcIixcblx0XHRkYW5nZXJvdXNseVNldElubmVySFRNTDogaW5uZXJIVE1MLFxuXHRcdG5vbmNlLFxuXHRcdHN1cHByZXNzSHlkcmF0aW9uV2FybmluZzogdHJ1ZVxuXHR9KTtcbn1cbmZ1bmN0aW9uIFNjcmlwdCh7IGF0dHJzLCBjaGlsZHJlbiwgcHJldmVudFNjcmlwdEhvaXN0IH0pIHtcblx0Y29uc3Qgcm91dGVyID0gdXNlUm91dGVyKCk7XG5cdGNvbnN0IGh5ZHJhdGVkID0gdXNlSHlkcmF0ZWQoKTtcblx0Y29uc3QgaW5uZXJIVE1MID0gUmVhY3QkMS51c2VNZW1vKCgpID0+IGNoaWxkcmVuID09PSB2b2lkIDAgPyB2b2lkIDAgOiB7IF9faHRtbDogY2hpbGRyZW4gfSwgW2NoaWxkcmVuXSk7XG5cdGNvbnN0IGRhdGFTY3JpcHQgPSB0eXBlb2YgYXR0cnM/LnR5cGUgPT09IFwic3RyaW5nXCIgJiYgYXR0cnMudHlwZSAhPT0gXCJcIiAmJiBhdHRycy50eXBlICE9PSBcInRleHQvamF2YXNjcmlwdFwiICYmIGF0dHJzLnR5cGUgIT09IFwibW9kdWxlXCI7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgYXR0cnM/LnNyYyAmJiB0eXBlb2YgY2hpbGRyZW4gPT09IFwic3RyaW5nXCIgJiYgY2hpbGRyZW4udHJpbSgpLmxlbmd0aCkgY29uc29sZS53YXJuKFwiW1RhblN0YWNrIFJvdXRlcl0gPFNjcmlwdD4gcmVjZWl2ZWQgYm90aCBgc3JjYCBhbmQgYGNoaWxkcmVuYC4gVGhlIGBjaGlsZHJlbmAgY29udGVudCB3aWxsIGJlIGlnbm9yZWQuIFJlbW92ZSBgY2hpbGRyZW5gIG9yIHJlbW92ZSBgc3JjYC5cIik7XG5cdFJlYWN0JDEudXNlRWZmZWN0KCgpID0+IHtcblx0XHRpZiAoZGF0YVNjcmlwdCkgcmV0dXJuO1xuXHRcdGlmIChhdHRycz8uc3JjKSB7XG5cdFx0XHRjb25zdCBsaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImFcIik7XG5cdFx0XHRsaW5rLmhyZWYgPSBhdHRycy5zcmM7XG5cdFx0XHRjb25zdCBub3JtU3JjID0gbGluay5ocmVmO1xuXHRcdFx0Zm9yIChjb25zdCBlbCBvZiBkb2N1bWVudC5zY3JpcHRzKSBpZiAoZWwuc3JjID09PSBub3JtU3JjKSByZXR1cm47XG5cdFx0XHRjb25zdCBzY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic2NyaXB0XCIpO1xuXHRcdFx0c2V0U2NyaXB0QXR0cnMoc2NyaXB0LCBhdHRycyk7XG5cdFx0XHRkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHNjcmlwdCk7XG5cdFx0XHRyZXR1cm4gKCkgPT4gc2NyaXB0LnJlbW92ZSgpO1xuXHRcdH1cblx0XHRpZiAodHlwZW9mIGNoaWxkcmVuID09PSBcInN0cmluZ1wiKSB7XG5cdFx0XHRjb25zdCB0eXBlQXR0ciA9IHR5cGVvZiBhdHRycz8udHlwZSA9PT0gXCJzdHJpbmdcIiA/IGF0dHJzLnR5cGUgOiBcInRleHQvamF2YXNjcmlwdFwiO1xuXHRcdFx0Y29uc3Qgbm9uY2VBdHRyID0gdHlwZW9mIGF0dHJzPy5ub25jZSA9PT0gXCJzdHJpbmdcIiA/IGF0dHJzLm5vbmNlIDogdm9pZCAwO1xuXHRcdFx0Zm9yIChjb25zdCBlbCBvZiBkb2N1bWVudC5zY3JpcHRzKSB7XG5cdFx0XHRcdGlmIChlbC5oYXNBdHRyaWJ1dGUoXCJzcmNcIikpIGNvbnRpbnVlO1xuXHRcdFx0XHRjb25zdCBzVHlwZSA9IGVsLmdldEF0dHJpYnV0ZShcInR5cGVcIikgPz8gXCJ0ZXh0L2phdmFzY3JpcHRcIjtcblx0XHRcdFx0Y29uc3Qgc05vbmNlID0gZWwuZ2V0QXR0cmlidXRlKFwibm9uY2VcIikgPz8gdm9pZCAwO1xuXHRcdFx0XHRpZiAoZWwudGV4dENvbnRlbnQgPT09IGNoaWxkcmVuICYmIHNUeXBlID09PSB0eXBlQXR0ciAmJiBzTm9uY2UgPT09IG5vbmNlQXR0cikgcmV0dXJuO1xuXHRcdFx0fVxuXHRcdFx0Y29uc3Qgc2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcInNjcmlwdFwiKTtcblx0XHRcdHNjcmlwdC50ZXh0Q29udGVudCA9IGNoaWxkcmVuO1xuXHRcdFx0c2V0U2NyaXB0QXR0cnMoc2NyaXB0LCBhdHRycyk7XG5cdFx0XHRkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHNjcmlwdCk7XG5cdFx0XHRyZXR1cm4gKCkgPT4gc2NyaXB0LnJlbW92ZSgpO1xuXHRcdH1cblx0fSwgW1xuXHRcdGF0dHJzLFxuXHRcdGNoaWxkcmVuLFxuXHRcdGRhdGFTY3JpcHRcblx0XSk7XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHtcblx0XHRpZiAoYXR0cnM/LnNyYykge1xuXHRcdFx0aWYgKCFwcmV2ZW50U2NyaXB0SG9pc3QpIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFwic2NyaXB0XCIsIHtcblx0XHRcdFx0Li4uYXR0cnMsXG5cdFx0XHRcdHN1cHByZXNzSHlkcmF0aW9uV2FybmluZzogdHJ1ZVxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcInNjcmlwdFwiLCB7XG5cdFx0XHRcdC4uLmF0dHJzLFxuXHRcdFx0XHRvbkxvYWQ6IG5vb3BTY3JpcHRIYW5kbGVyLFxuXHRcdFx0XHRzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWVcblx0XHRcdH0pO1xuXHRcdH1cblx0XHRpZiAodHlwZW9mIGNoaWxkcmVuID09PSBcInN0cmluZ1wiKSByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcInNjcmlwdFwiLCB7XG5cdFx0XHQuLi5hdHRycyxcblx0XHRcdGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MOiBpbm5lckhUTUwsXG5cdFx0XHRzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWVcblx0XHR9KTtcblx0XHRyZXR1cm4gbnVsbDtcblx0fVxuXHRpZiAoZGF0YVNjcmlwdCAmJiB0eXBlb2YgY2hpbGRyZW4gPT09IFwic3RyaW5nXCIpIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFwic2NyaXB0XCIsIHtcblx0XHQuLi5hdHRycyxcblx0XHRzdXBwcmVzc0h5ZHJhdGlvbldhcm5pbmc6IHRydWUsXG5cdFx0ZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw6IGlubmVySFRNTFxuXHR9KTtcblx0aWYgKCFoeWRyYXRlZCkge1xuXHRcdGlmIChhdHRycz8uc3JjKSByZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChcInNjcmlwdFwiLCB7XG5cdFx0XHQuLi5hdHRycyxcblx0XHRcdHN1cHByZXNzSHlkcmF0aW9uV2FybmluZzogdHJ1ZVxuXHRcdH0pO1xuXHRcdGlmICh0eXBlb2YgY2hpbGRyZW4gPT09IFwic3RyaW5nXCIpIHJldHVybiAvKiBAX19QVVJFX18gKi8ganN4KFwic2NyaXB0XCIsIHtcblx0XHRcdC4uLmF0dHJzLFxuXHRcdFx0ZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw6IGlubmVySFRNTCxcblx0XHRcdHN1cHByZXNzSHlkcmF0aW9uV2FybmluZzogdHJ1ZVxuXHRcdH0pO1xuXHR9XG5cdHJldHVybiBudWxsO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBBc3NldCB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1Bc3NldC5qcy5tYXAiLCJpbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tIFwiLi91c2VSb3V0ZXIuanNcIjtcbmltcG9ydCB7IF9nZXRBc3NldE1hdGNoZXMsIGFwcGVuZFVuaXF1ZVVzZXJUYWdzLCBkZWVwRXF1YWwsIGVzY2FwZUh0bWwsIGdldEFzc2V0Q3Jvc3NPcmlnaW4sIGdldFNjcmlwdFByZWxvYWRBdHRycywgcmVzb2x2ZU1hbmlmZXN0Q3NzTGluayB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBpc1NlcnZlciB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmUvaXNTZXJ2ZXJcIjtcbmltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSBcIkB0YW5zdGFjay9yZWFjdC1zdG9yZVwiO1xuLy8jcmVnaW9uIHNyYy9oZWFkQ29udGVudFV0aWxzLnRzeFxuZnVuY3Rpb24gYnVpbGRUYWdzRnJvbU1hdGNoZXMocm91dGVyLCBub25jZSwgbWF0Y2hlcywgYXNzZXRDcm9zc09yaWdpbikge1xuXHRtYXRjaGVzID0gX2dldEFzc2V0TWF0Y2hlcyhtYXRjaGVzKTtcblx0Y29uc3Qgcm91dGVNZXRhID0gbWF0Y2hlcy5tYXAoKG1hdGNoKSA9PiBtYXRjaC5tZXRhKS5maWx0ZXIoKG1ldGEpID0+IG1ldGEgIT09IHZvaWQgMCk7XG5cdGNvbnN0IHJlc3VsdE1ldGEgPSBbXTtcblx0Y29uc3QgbWV0YUJ5QXR0cmlidXRlID0ge307XG5cdGxldCB0aXRsZTtcblx0Zm9yIChsZXQgaSA9IHJvdXRlTWV0YS5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuXHRcdGNvbnN0IG1ldGFzID0gcm91dGVNZXRhW2ldO1xuXHRcdGZvciAobGV0IGogPSBtZXRhcy5sZW5ndGggLSAxOyBqID49IDA7IGotLSkge1xuXHRcdFx0Y29uc3QgbSA9IG1ldGFzW2pdO1xuXHRcdFx0aWYgKCFtKSBjb250aW51ZTtcblx0XHRcdGlmIChtLnRpdGxlKSB7XG5cdFx0XHRcdGlmICghdGl0bGUpIHRpdGxlID0ge1xuXHRcdFx0XHRcdHRhZzogXCJ0aXRsZVwiLFxuXHRcdFx0XHRcdGNoaWxkcmVuOiBtLnRpdGxlXG5cdFx0XHRcdH07XG5cdFx0XHR9IGVsc2UgaWYgKFwic2NyaXB0OmxkK2pzb25cIiBpbiBtKSB0cnkge1xuXHRcdFx0XHRjb25zdCBqc29uID0gSlNPTi5zdHJpbmdpZnkobVtcInNjcmlwdDpsZCtqc29uXCJdKTtcblx0XHRcdFx0cmVzdWx0TWV0YS5wdXNoKHtcblx0XHRcdFx0XHR0YWc6IFwic2NyaXB0XCIsXG5cdFx0XHRcdFx0YXR0cnM6IHsgdHlwZTogXCJhcHBsaWNhdGlvbi9sZCtqc29uXCIgfSxcblx0XHRcdFx0XHRjaGlsZHJlbjogZXNjYXBlSHRtbChqc29uKVxuXHRcdFx0XHR9KTtcblx0XHRcdH0gY2F0Y2gge31cblx0XHRcdGVsc2Uge1xuXHRcdFx0XHRjb25zdCBhdHRyaWJ1dGUgPSBtLm5hbWUgPz8gbS5wcm9wZXJ0eTtcblx0XHRcdFx0aWYgKGF0dHJpYnV0ZSkge1xuXHRcdFx0XHRcdGlmIChtZXRhQnlBdHRyaWJ1dGVbYXR0cmlidXRlXSkgY29udGludWU7XG5cdFx0XHRcdFx0ZWxzZSBtZXRhQnlBdHRyaWJ1dGVbYXR0cmlidXRlXSA9IHRydWU7XG5cdFx0XHRcdH1cblx0XHRcdFx0cmVzdWx0TWV0YS5wdXNoKHtcblx0XHRcdFx0XHR0YWc6IFwibWV0YVwiLFxuXHRcdFx0XHRcdGF0dHJzOiB7XG5cdFx0XHRcdFx0XHQuLi5tLFxuXHRcdFx0XHRcdFx0bm9uY2Vcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0pO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXHRpZiAodGl0bGUpIHJlc3VsdE1ldGEucHVzaCh0aXRsZSk7XG5cdGlmIChub25jZSkgcmVzdWx0TWV0YS5wdXNoKHtcblx0XHR0YWc6IFwibWV0YVwiLFxuXHRcdGF0dHJzOiB7XG5cdFx0XHRwcm9wZXJ0eTogXCJjc3Atbm9uY2VcIixcblx0XHRcdGNvbnRlbnQ6IG5vbmNlXG5cdFx0fVxuXHR9KTtcblx0cmVzdWx0TWV0YS5yZXZlcnNlKCk7XG5cdGNvbnN0IGNvbnN0cnVjdGVkTGlua3MgPSBtYXRjaGVzLmZsYXRNYXAoKG1hdGNoKSA9PiBtYXRjaC5saW5rcyA/PyBbXSkuZmlsdGVyKChsaW5rKSA9PiBsaW5rICE9PSB2b2lkIDApLm1hcCgobGluaykgPT4gKHtcblx0XHR0YWc6IFwibGlua1wiLFxuXHRcdGF0dHJzOiB7XG5cdFx0XHQuLi5saW5rLFxuXHRcdFx0bm9uY2Vcblx0XHR9XG5cdH0pKTtcblx0Y29uc3QgbWFuaWZlc3QgPSByb3V0ZXIuc3NyPy5tYW5pZmVzdDtcblx0Y29uc3QgbWFuaWZlc3RDc3NUYWdzID0gW107XG5cdGlmIChtYW5pZmVzdCkge1xuXHRcdG1hdGNoZXMuZm9yRWFjaCgobWF0Y2gpID0+IHtcblx0XHRcdChtYW5pZmVzdC5yb3V0ZXNbbWF0Y2gucm91dGVJZF0/LmNzcyk/LmZvckVhY2goKGxpbmspID0+IHtcblx0XHRcdFx0Y29uc3QgcmVzb2x2ZWRMaW5rID0gcmVzb2x2ZU1hbmlmZXN0Q3NzTGluayhsaW5rKTtcblx0XHRcdFx0bWFuaWZlc3RDc3NUYWdzLnB1c2goe1xuXHRcdFx0XHRcdHRhZzogXCJsaW5rXCIsXG5cdFx0XHRcdFx0YXR0cnM6IHtcblx0XHRcdFx0XHRcdHJlbDogXCJzdHlsZXNoZWV0XCIsXG5cdFx0XHRcdFx0XHQuLi5yZXNvbHZlZExpbmssXG5cdFx0XHRcdFx0XHRjcm9zc09yaWdpbjogZ2V0QXNzZXRDcm9zc09yaWdpbihhc3NldENyb3NzT3JpZ2luLCBcInN0eWxlc2hlZXRcIikgPz8gcmVzb2x2ZWRMaW5rLmNyb3NzT3JpZ2luLFxuXHRcdFx0XHRcdFx0c3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nOiB0cnVlLFxuXHRcdFx0XHRcdFx0bm9uY2Vcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0pO1xuXHRcdFx0fSk7XG5cdFx0fSk7XG5cdFx0aWYgKG1hbmlmZXN0LmlubGluZVN0eWxlKSBtYW5pZmVzdENzc1RhZ3MucHVzaCh7XG5cdFx0XHR0YWc6IFwic3R5bGVcIixcblx0XHRcdGF0dHJzOiB7XG5cdFx0XHRcdC4uLm1hbmlmZXN0LmlubGluZVN0eWxlLmF0dHJzLFxuXHRcdFx0XHRub25jZVxuXHRcdFx0fSxcblx0XHRcdGNoaWxkcmVuOiBtYW5pZmVzdC5pbmxpbmVTdHlsZS5jaGlsZHJlbixcblx0XHRcdGlubGluZUNzczogdHJ1ZVxuXHRcdH0pO1xuXHR9XG5cdGNvbnN0IHByZWxvYWRMaW5rcyA9IFtdO1xuXHRpZiAobWFuaWZlc3QpIG1hdGNoZXMuZm9yRWFjaCgobWF0Y2gpID0+IHtcblx0XHRtYW5pZmVzdC5yb3V0ZXNbbWF0Y2gucm91dGVJZF0/LnByZWxvYWRzPy5mb3JFYWNoKChwcmVsb2FkKSA9PiB7XG5cdFx0XHRwcmVsb2FkTGlua3MucHVzaCh7XG5cdFx0XHRcdHRhZzogXCJsaW5rXCIsXG5cdFx0XHRcdGF0dHJzOiB7XG5cdFx0XHRcdFx0Li4uZ2V0U2NyaXB0UHJlbG9hZEF0dHJzKG1hbmlmZXN0LCBwcmVsb2FkLCBhc3NldENyb3NzT3JpZ2luKSxcblx0XHRcdFx0XHRub25jZVxuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHR9KTtcblx0fSk7XG5cdGNvbnN0IHN0eWxlcyA9IG1hdGNoZXMuZmxhdE1hcCgobWF0Y2gpID0+IG1hdGNoLnN0eWxlcyA/PyBbXSkuZmlsdGVyKChzdHlsZSkgPT4gc3R5bGUgIT09IHZvaWQgMCkubWFwKCh7IGNoaWxkcmVuLCAuLi5hdHRycyB9KSA9PiAoe1xuXHRcdHRhZzogXCJzdHlsZVwiLFxuXHRcdGF0dHJzOiB7XG5cdFx0XHQuLi5hdHRycyxcblx0XHRcdG5vbmNlXG5cdFx0fSxcblx0XHRjaGlsZHJlblxuXHR9KSk7XG5cdGNvbnN0IGhlYWRTY3JpcHRzID0gbWF0Y2hlcy5mbGF0TWFwKChtYXRjaCkgPT4gbWF0Y2guaGVhZFNjcmlwdHMgPz8gW10pLmZpbHRlcigoc2NyaXB0KSA9PiBzY3JpcHQgIT09IHZvaWQgMCkubWFwKCh7IGNoaWxkcmVuLCAuLi5zY3JpcHQgfSkgPT4gKHtcblx0XHR0YWc6IFwic2NyaXB0XCIsXG5cdFx0YXR0cnM6IHtcblx0XHRcdC4uLnNjcmlwdCxcblx0XHRcdG5vbmNlXG5cdFx0fSxcblx0XHRjaGlsZHJlblxuXHR9KSk7XG5cdGNvbnN0IHRhZ3MgPSBbXTtcblx0YXBwZW5kVW5pcXVlVXNlclRhZ3ModGFncywgcmVzdWx0TWV0YSk7XG5cdHRhZ3MucHVzaCguLi5wcmVsb2FkTGlua3MpO1xuXHRhcHBlbmRVbmlxdWVVc2VyVGFncyh0YWdzLCBjb25zdHJ1Y3RlZExpbmtzKTtcblx0dGFncy5wdXNoKC4uLm1hbmlmZXN0Q3NzVGFncyk7XG5cdGFwcGVuZFVuaXF1ZVVzZXJUYWdzKHRhZ3MsIHN0eWxlcyk7XG5cdGFwcGVuZFVuaXF1ZVVzZXJUYWdzKHRhZ3MsIGhlYWRTY3JpcHRzKTtcblx0cmV0dXJuIHRhZ3M7XG59XG4vKipcbiogQnVpbGQgdGhlIGhlYWQvbGluay9tZXRhL3NjcmlwdCB0YWdzIGZyb20gdGhlIHJlbmRlcmFibGUgcHJlc2VudGVkIHByZWZpeC5cbiogVXNlZCBpbnRlcm5hbGx5IGJ5IGBIZWFkQ29udGVudGAuXG4qL1xudmFyIHVzZVRhZ3MgPSAoYXNzZXRDcm9zc09yaWdpbikgPT4ge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0Y29uc3Qgbm9uY2UgPSByb3V0ZXIub3B0aW9ucy5zc3I/Lm5vbmNlO1xuXHRpZiAoaXNTZXJ2ZXIgPz8gcm91dGVyLmlzU2VydmVyKSByZXR1cm4gYnVpbGRUYWdzRnJvbU1hdGNoZXMocm91dGVyLCBub25jZSwgcm91dGVyLnN0b3Jlcy5tYXRjaGVzLmdldCgpLCBhc3NldENyb3NzT3JpZ2luKTtcblx0Y29uc3Qgc2VsZWN0VGFncyA9IFJlYWN0JDEudXNlQ2FsbGJhY2soKG1hdGNoZXMpID0+IGJ1aWxkVGFnc0Zyb21NYXRjaGVzKHJvdXRlciwgbm9uY2UsIG1hdGNoZXMsIGFzc2V0Q3Jvc3NPcmlnaW4pLCBbXG5cdFx0YXNzZXRDcm9zc09yaWdpbixcblx0XHRub25jZSxcblx0XHRyb3V0ZXJcblx0XSk7XG5cdHJldHVybiB1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLm1hdGNoZXMsIHNlbGVjdFRhZ3MsIHsgY29tcGFyZTogZGVlcEVxdWFsIH0pO1xufTtcbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgdXNlVGFncyB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1oZWFkQ29udGVudFV0aWxzLmpzLm1hcCIsImltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgQXNzZXQgfSBmcm9tIFwiLi9Bc3NldC5qc1wiO1xuaW1wb3J0IHsgY29tcG9zZVNzckJvZHlTY3JpcHRzLCBkZWVwRXF1YWwsIGdldFNzckJvZHlTY3JpcHRQYXJ0cyB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCB7IGNyZWF0ZUVsZW1lbnQgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IGlzU2VydmVyIH0gZnJvbSBcIkB0YW5zdGFjay9yb3V0ZXItY29yZS9pc1NlcnZlclwiO1xuaW1wb3J0IHsgRnJhZ21lbnQsIGpzeCB9IGZyb20gXCJyZWFjdC9qc3gtcnVudGltZVwiO1xuaW1wb3J0IHsgdXNlU2VsZWN0b3IgfSBmcm9tIFwiQHRhbnN0YWNrL3JlYWN0LXN0b3JlXCI7XG4vLyNyZWdpb24gc3JjL1NjcmlwdHMudHN4XG52YXIgcm91dGVTY3JpcHRBdHRycyA9IHsgc3VwcHJlc3NIeWRyYXRpb25XYXJuaW5nOiB0cnVlIH07XG4vKipcbiogUmVuZGVyIGJvZHkgc2NyaXB0IHRhZ3MgY29sbGVjdGVkIGZyb20gcm91dGUgbWF0Y2hlcyBhbmQgU1NSIG1hbmlmZXN0cy5cbiogRHVyaW5nIHN0cmVhbWluZyBTU1IsIGA8U2NyaXB0cz5gIG1hcmtzIHdoZXJlIGxhdGUgaHlkcmF0aW9uIHNjcmlwdHMgbWF5XG4qIGJlZ2luIHRvIGJlIGluc2VydGVkLlxuKi9cbnZhciBTY3JpcHRzID0gKCkgPT4ge1xuXHRjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcblx0Y29uc3Qgbm9uY2UgPSByb3V0ZXIub3B0aW9ucy5zc3I/Lm5vbmNlO1xuXHRjb25zdCBnZXRQYXJ0cyA9IChtYXRjaGVzKSA9PiB7XG5cdFx0Y29uc3QgcGFydHMgPSBnZXRTc3JCb2R5U2NyaXB0UGFydHMobWF0Y2hlcywgcm91dGVyLnNzcj8ubWFuaWZlc3QsIG5vbmNlLCByb3V0ZVNjcmlwdEF0dHJzKTtcblx0XHRmb3IgKGNvbnN0IHNjcmlwdCBvZiBwYXJ0c1sxXSkgaWYgKHR5cGVvZiBzY3JpcHQuYXR0cnM/LnNyYyA9PT0gXCJzdHJpbmdcIikge1xuXHRcdFx0Y29uc3Qgc2NyaXB0V2l0aEhvaXN0ID0gc2NyaXB0O1xuXHRcdFx0c2NyaXB0V2l0aEhvaXN0LnByZXZlbnRTY3JpcHRIb2lzdCA9IHRydWU7XG5cdFx0fVxuXHRcdHJldHVybiBwYXJ0cztcblx0fTtcblx0Y29uc3QgZ2V0U2NyaXB0cyA9IChtYXRjaGVzKSA9PiB7XG5cdFx0cmV0dXJuIGNvbXBvc2VTc3JCb2R5U2NyaXB0cyhnZXRQYXJ0cyhtYXRjaGVzKSk7XG5cdH07XG5cdGlmIChpc1NlcnZlciA/PyByb3V0ZXIuaXNTZXJ2ZXIpIHtcblx0XHRjb25zdCBhY3RpdmVNYXRjaGVzID0gcm91dGVyLnN0b3Jlcy5tYXRjaGVzLmdldCgpO1xuXHRcdHJldHVybiByZW5kZXJTY3JpcHRzKGNvbXBvc2VTc3JCb2R5U2NyaXB0cyhnZXRQYXJ0cyhhY3RpdmVNYXRjaGVzKSwgcm91dGVyLnNlcnZlclNzcj8udGFrZUluaXRpYWxIeWRyYXRpb25TY3JpcHRUYWdzKCkpKTtcblx0fVxuXHRyZXR1cm4gcmVuZGVyU2NyaXB0cyh1c2VTZWxlY3Rvcihyb3V0ZXIuc3RvcmVzLm1hdGNoZXMsIGdldFNjcmlwdHMsIHsgY29tcGFyZTogZGVlcEVxdWFsIH0pKTtcbn07XG5mdW5jdGlvbiByZW5kZXJTY3JpcHRzKHNjcmlwdHMpIHtcblx0cmV0dXJuIC8qIEBfX1BVUkVfXyAqLyBqc3goRnJhZ21lbnQsIHsgY2hpbGRyZW46IHNjcmlwdHMubWFwKChhc3NldCwgaSkgPT4gLyogQF9fUFVSRV9fICovIGNyZWF0ZUVsZW1lbnQoQXNzZXQsIHtcblx0XHQuLi5hc3NldCxcblx0XHRrZXk6IGB0c3Itc2NyaXB0cy0ke2Fzc2V0LnRhZ30tJHtpfWBcblx0fSkpIH0pO1xufVxuLy8jZW5kcmVnaW9uXG5leHBvcnQgeyBTY3JpcHRzIH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVNjcmlwdHMuanMubWFwIiwiXCJ1c2UgY2xpZW50XCI7XG5pbXBvcnQgeyB1c2VIeWRyYXRlZCB9IGZyb20gXCIuL0NsaWVudE9ubHkuanNcIjtcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCIuL3VzZVJvdXRlci5qc1wiO1xuaW1wb3J0IHsgQXNzZXQgfSBmcm9tIFwiLi9Bc3NldC5qc1wiO1xuaW1wb3J0IHsgdXNlVGFncyB9IGZyb20gXCIuL2hlYWRDb250ZW50VXRpbHMuanNcIjtcbmltcG9ydCB7IERFVl9TVFlMRVNfQVRUUiB9IGZyb20gXCJAdGFuc3RhY2svcm91dGVyLWNvcmVcIjtcbmltcG9ydCAqIGFzIFJlYWN0JDEgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBjcmVhdGVFbGVtZW50IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBGcmFnbWVudCwganN4IH0gZnJvbSBcInJlYWN0L2pzeC1ydW50aW1lXCI7XG4vLyNyZWdpb24gc3JjL0hlYWRDb250ZW50LmRldi50c3hcbi8qKlxuKiBSZW5kZXIgcm91dGUtbWFuYWdlZCBoZWFkIHRhZ3MgKHRpdGxlLCBtZXRhLCBsaW5rcywgc3R5bGVzLCBoZWFkIHNjcmlwdHMpLlxuKiBQbGFjZSBpbnNpZGUgdGhlIGRvY3VtZW50IGhlYWQgb2YgeW91ciBhcHAgc2hlbGwuXG4qXG4qIERldmVsb3BtZW50IHZlcnNpb246IGZpbHRlcnMgb3V0IGRldiBzdHlsZXMgbGluayBhZnRlciBoeWRyYXRpb24gYW5kXG4qIGluY2x1ZGVzIGEgZmFsbGJhY2sgY2xlYW51cCBlZmZlY3QgZm9yIGh5ZHJhdGlvbiBtaXNtYXRjaCBjYXNlcy5cbipcbiogQGxpbmsgaHR0cHM6Ly90YW5zdGFjay5jb20vcm91dGVyL2xhdGVzdC9kb2NzL2ZyYW1ld29yay9yZWFjdC9ndWlkZS9kb2N1bWVudC1oZWFkLW1hbmFnZW1lbnRcbiovXG5mdW5jdGlvbiBIZWFkQ29udGVudChwcm9wcykge1xuXHRjb25zdCB0YWdzID0gdXNlVGFncyhwcm9wcy5hc3NldENyb3NzT3JpZ2luKTtcblx0Y29uc3Qgbm9uY2UgPSB1c2VSb3V0ZXIoKS5vcHRpb25zLnNzcj8ubm9uY2U7XG5cdGNvbnN0IGh5ZHJhdGVkID0gdXNlSHlkcmF0ZWQoKTtcblx0UmVhY3QkMS51c2VFZmZlY3QoKCkgPT4ge1xuXHRcdGlmIChoeWRyYXRlZCkgZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChgbGlua1ske0RFVl9TVFlMRVNfQVRUUn1dYCkuZm9yRWFjaCgoZWwpID0+IGVsLnJlbW92ZSgpKTtcblx0fSwgW2h5ZHJhdGVkXSk7XG5cdGNvbnN0IGZpbHRlcmVkVGFncyA9IGh5ZHJhdGVkID8gdGFncy5maWx0ZXIoKHRhZykgPT4gdGFnLnRhZyAhPT0gXCJsaW5rXCIgfHwgdGFnLmF0dHJzPy5bREVWX1NUWUxFU19BVFRSXSAhPT0gdHJ1ZSkgOiB0YWdzO1xuXHRyZXR1cm4gLyogQF9fUFVSRV9fICovIGpzeChGcmFnbWVudCwgeyBjaGlsZHJlbjogZmlsdGVyZWRUYWdzLm1hcCgodGFnKSA9PiAvKiBAX19QVVJFX18gKi8gY3JlYXRlRWxlbWVudChBc3NldCwge1xuXHRcdC4uLnRhZyxcblx0XHRrZXk6IGB0c3ItbWV0YS0ke0pTT04uc3RyaW5naWZ5KHRhZyl9YCxcblx0XHRub25jZVxuXHR9KSkgfSk7XG59XG4vLyNlbmRyZWdpb25cbmV4cG9ydCB7IEhlYWRDb250ZW50IH07XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPUhlYWRDb250ZW50LmRldi5qcy5tYXAiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBWUEsU0FBUyxTQUFTLFVBQVUsQ0FBQyxHQUFHO0NBQy9CLFFBQVEsYUFBYTtDQUNyQixJQUFJLFFBQVEsT0FBTyxNQUFNO0NBQ3pCLE9BQU87QUFDUjs7QUFFQSxTQUFTLFdBQVcsS0FBSztDQUN4QixPQUFPLEtBQUssZUFBZTtBQUM1Qjs7O0FDbEJBLElBQU0sY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2dCcEIsU0FBUyxTQUFTLE1BQU07Q0FDdkIsS0FBSyxhQUFhLEtBQUssY0FBYyxLQUFLLFFBQVE7Q0FDbEQsTUFBTSxVQUFVLElBQUksUUFBUSxLQUFLLE9BQU87Q0FDeEMsSUFBSSxLQUFLLFFBQVEsUUFBUSxJQUFJLFVBQVUsTUFBTSxNQUFNLFFBQVEsSUFBSSxZQUFZLEtBQUssSUFBSTtDQUNwRixNQUFNLFdBQVcsSUFBSSxTQUFTLE1BQU07RUFDbkMsUUFBUSxLQUFLO0VBQ2I7Q0FDRCxDQUFDO0NBQ0QsU0FBUyxVQUFVO0NBQ25CLElBQUksS0FBSyxPQUFPLE1BQU07Q0FDdEIsT0FBTztBQUNSOztBQUVBLFNBQVMsV0FBVyxLQUFLO0NBQ3hCLE9BQU8sZUFBZSxZQUFZLENBQUMsQ0FBQyxJQUFJO0FBQ3pDOzs7Ozs7QUMzQkEsU0FBUyxLQUFLLEtBQUs7Q0FDbEIsT0FBTyxJQUFJLElBQUksU0FBUztBQUN6Qjs7Ozs7QUFLQSxTQUFTLGlCQUFpQixTQUFTLFVBQVU7Q0FDNUMsSUFBSSxPQUFPLFlBQVksWUFBWSxPQUFPLFFBQVEsUUFBUTtDQUMxRCxPQUFPO0FBQ1I7QUFDQSxJQUFNLFNBQVMsT0FBTyxVQUFVO0FBQ2hDLFNBQVMsUUFBUSxLQUFLO0NBQ3JCLEtBQUssTUFBTSxPQUFPLEtBQUssSUFBSSxPQUFPLEtBQUssS0FBSyxHQUFHLEdBQUcsT0FBTztDQUN6RCxPQUFPO0FBQ1I7QUFDQSxJQUFNLG1CQUFtQixPQUFPLE9BQU8sSUFBSTtBQUMzQyxJQUFNLHdCQUF3QixNQUFNLFNBQVMsaUJBQWlCLE1BQU0sTUFBTSxJQUFJO0FBQzlFLFNBQVMsaUJBQWlCLE1BQU0sTUFBTSxZQUFZLFNBQVMsR0FBRztDQUU3RCxJQUFJLFNBQVMsTUFBTSxPQUFPO0NBQzFCLElBQUksV0FBVyxLQUFLLE9BQU87Q0FDM0IsTUFBTSxRQUFRLE1BQU0sUUFBUSxJQUFJLEtBQUssTUFBTSxRQUFRLElBQUk7Q0FDdkQsSUFBSSxDQUFDLFNBQVMsRUFBRSxjQUFjLElBQUksS0FBSyxjQUFjLElBQUksSUFBSSxPQUFPO0NBQ3BFLE1BQU0sV0FBVyxPQUFPLEtBQUssSUFBSTtDQUNqQyxNQUFNLGdCQUFnQixTQUFTO0NBQy9CLE1BQU0sV0FBVyxPQUFPLEtBQUssSUFBSTtDQUNqQyxNQUFNLFNBQVMsU0FBUztDQUN4QixJQUFJLFFBQVEsa0JBQWtCLEtBQUssVUFBVSxXQUFXLEtBQUssVUFBVSxpQkFBaUIsS0FBSyxRQUFRLE1BQU0sR0FBRyxnQkFBZ0IsT0FBTyxVQUFVLEtBQUssUUFBUSxNQUFNLEdBQUcsU0FBUyxNQUFNLGtCQUFrQixPQUFPLG9CQUFvQixJQUFJLENBQUMsQ0FBQyxVQUFVLFdBQVcsT0FBTyxvQkFBb0IsSUFBSSxDQUFDLENBQUMsVUFBVSxPQUFPLHNCQUFzQixJQUFJLENBQUMsQ0FBQyxRQUFRLE9BQU87Q0FDelYsSUFBSSxJQUFJO0NBQ1IsSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSSxPQUFPO0VBQ1YsT0FBTyxJQUFJLFFBQVEsS0FBSztHQUN2QixNQUFNO0dBQ04sV0FBVyxLQUFLO0dBQ2hCLFFBQVEsS0FBSztHQUNiLFFBQVEsYUFBYSxRQUFRLFdBQVcsT0FBTyxhQUFhLFdBQVcsaUJBQWlCLFVBQVUsT0FBTyxZQUFZLE1BQU0sSUFBSTtHQUMvSCxJQUFJLFVBQVUsVUFBVTtFQUN6QjtFQUNBLElBQUksTUFBTSxVQUFVLGtCQUFrQixRQUFRLE9BQU87Q0FDdEQsT0FBTztFQUNOLElBQUksUUFBUSxrQkFBa0I7RUFDOUIsSUFBSSxZQUFZO0VBQ2hCLE9BQU8sSUFBSSxRQUFRLEtBQUs7R0FDdkIsTUFBTSxTQUFTO0dBQ2YsV0FBVyxLQUFLO0dBQ2hCLE1BQU0sV0FBVyxLQUFLO0dBQ3RCLFFBQVEsYUFBYSxXQUFXLFdBQVcsT0FBTyxhQUFhLFdBQVcsaUJBQWlCLFVBQVUsVUFBVSxZQUFZLE1BQU0sSUFBSTtHQUNySSxVQUFVLFVBQVUsYUFBYSxTQUFTLE9BQU8sT0FBTyxPQUFPLEtBQUssTUFBTSxHQUFHO0dBQzdFLGNBQWMsT0FBTyxHQUFHLE9BQU8sUUFBUTtHQUN2QyxTQUFTLEtBQUs7RUFDZjtFQUNBLElBQUksT0FBTyxPQUFPLE9BQU8sc0JBQXNCLElBQUksQ0FBQyxDQUFDLFNBQVMsT0FBTztFQUNyRSxJQUFJLFdBQVcsT0FBTztDQUN2QjtDQUNBLE1BQU0sT0FBTyxRQUFRLFNBQVMsS0FBSyxDQUFDLElBQUksYUFBYSxXQUFXLElBQUksQ0FBQztDQUNyRSxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUFLO0VBQ2hDLE1BQU0sUUFBUSxJQUFJLFNBQVM7RUFDM0IsSUFBSSxPQUFPO0dBQ1YsV0FBVyxLQUFLO0dBQ2hCLElBQUksSUFBSSxHQUFHO0lBQ1YsUUFBUSxLQUFLO0lBQ2IsUUFBUSxhQUFhLFFBQVEsV0FBVyxPQUFPLGFBQWEsV0FBVyxpQkFBaUIsVUFBVSxPQUFPLFlBQVksTUFBTSxJQUFJO0dBQ2hJO0dBQ0EsS0FBSyxPQUFPLElBQUksSUFBSSxXQUFXO0VBQ2hDLE9BQU8sS0FBSyxPQUFPLFNBQVM7Q0FDN0I7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLGNBQWMsR0FBRztDQUN6QixJQUFJLENBQUMsS0FBSyxPQUFPLE1BQU0sVUFBVSxPQUFPO0NBQ3hDLFFBQVEsT0FBTyxlQUFlLENBQUMsQ0FBQyxFQUFFLGVBQWUsWUFBWTtBQUM5RDs7Ozs7Ozs7OztBQVVBLFNBQVMsVUFBVSxHQUFHLEdBQUcsU0FBUyxtQkFBbUI7Q0FDcEQsSUFBSSxNQUFNLEdBQUcsT0FBTztDQUNwQixJQUFJLE1BQU0sUUFBUSxDQUFDLEtBQUssTUFBTSxRQUFRLENBQUMsR0FBRztFQUN6QyxJQUFJLEVBQUUsV0FBVyxFQUFFLFFBQVEsT0FBTztFQUNsQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLElBQUksR0FBRyxLQUFLO0dBQ3pDLE1BQU0sS0FBSyxFQUFFO0dBQ2IsTUFBTSxLQUFLLEVBQUU7R0FDYixJQUFJLE9BQU8sTUFBTSxDQUFDLFVBQVUsSUFBSSxJQUFJLFNBQVMsaUJBQWlCLEdBQUcsT0FBTztFQUN6RTtFQUNBLE9BQU87Q0FDUjtDQUNBLElBQUksY0FBYyxDQUFDLEtBQUssY0FBYyxDQUFDLEdBQUc7RUFDekMsSUFBSSxTQUFTO0dBQ1osS0FBSyxNQUFNLEtBQUssR0FBRyxJQUFJLHFCQUFxQixFQUFFLE9BQU8sS0FBSyxHQUNyRDtRQUFBLENBQUMsVUFBVSxFQUFFLElBQUksRUFBRSxJQUFJLFNBQVMsaUJBQWlCLEdBQUcsT0FBTztHQUFBO0dBRWhFLE9BQU87RUFDUjtFQUNBLElBQUksU0FBUztFQUNiLElBQUksbUJBQW1CLFNBQVMsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDO09BQzFDLEtBQUssTUFBTSxLQUFLLEdBQUcsSUFBSSxFQUFFLE9BQU8sS0FBSyxHQUFHO0VBQzdDLEtBQUssTUFBTSxLQUFLLEdBQUcsSUFBSSxxQkFBcUIsRUFBRSxPQUFPLEtBQUssR0FDckQ7T0FBQSxhQUFhLEtBQUssQ0FBQyxVQUFVLEVBQUUsSUFBSSxFQUFFLElBQUksU0FBUyxpQkFBaUIsR0FBRyxPQUFPO0VBQUE7RUFFbEYsT0FBTyxXQUFXO0NBQ25CO0NBQ0EsT0FBTztBQUNSOzs7OztBQUtBLFNBQVMsd0JBQXdCLFdBQVc7Q0FDM0MsSUFBSTtDQUNKLElBQUk7Q0FDSixNQUFNLG9CQUFvQixJQUFJLFNBQVMsU0FBUyxXQUFXO0VBQzFELHFCQUFxQjtFQUNyQixvQkFBb0I7Q0FDckIsQ0FBQztDQUNELGtCQUFrQixTQUFTO0NBQzNCLGtCQUFrQixXQUFXLFVBQVU7RUFDdEMsa0JBQWtCLFNBQVM7RUFDM0Isa0JBQWtCLFFBQVE7RUFDMUIsbUJBQW1CLEtBQUs7RUFDeEIsWUFBWSxLQUFLO0NBQ2xCO0NBQ0Esa0JBQWtCLFVBQVUsTUFBTTtFQUNqQyxrQkFBa0IsU0FBUztFQUMzQixrQkFBa0IsQ0FBQztDQUNwQjtDQUNBLE9BQU87QUFDUjs7Ozs7QUFLQSxTQUFTLHNCQUFzQixPQUFPO0NBQ3JDLElBQUksT0FBTyxPQUFPLFlBQVksVUFBVSxPQUFPO0NBQy9DLE9BQU8sTUFBTSxRQUFRLFdBQVcsNkNBQTZDLEtBQUssTUFBTSxRQUFRLFdBQVcsMkNBQTJDLEtBQUssTUFBTSxRQUFRLFdBQVcsa0NBQWtDO0FBQ3ZOO0FBSUEsU0FBUyxTQUFTLE9BQU8sV0FBVztDQUNuQyxLQUFLLElBQUksSUFBSSxNQUFNLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztFQUMzQyxNQUFNLE9BQU8sTUFBTTtFQUNuQixJQUFJLFVBQVUsSUFBSSxHQUFHLE9BQU87Q0FDN0I7QUFDRDs7Ozs7Ozs7Ozs7Ozs7QUFjQSxJQUFNLGlCQUFpQjtBQUN2QixTQUFTLG9CQUFvQixTQUFTO0NBQ3JDLE9BQU8sUUFBUSxRQUFRLGlCQUFpQixPQUFPLE1BQU0sR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQztBQUNsSDtBQUNBLFNBQVMsY0FBYyxTQUFTO0NBQy9CLElBQUk7Q0FDSixJQUFJO0VBQ0gsVUFBVSxVQUFVLE9BQU87Q0FDNUIsUUFBUTtFQUNQLFVBQVUsUUFBUSxXQUFXLG1CQUFtQixVQUFVO0dBQ3pELElBQUk7SUFDSCxPQUFPLFVBQVUsS0FBSztHQUN2QixRQUFRO0lBQ1AsT0FBTztHQUNSO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsT0FBTyxvQkFBb0IsT0FBTztBQUNuQzs7Ozs7QUFLQSxJQUFNLDZCQUE2QjtDQUNsQztDQUNBO0NBQ0E7Q0FDQTtBQUNEOzs7Ozs7OztBQVFBLFNBQVMsYUFBYSxLQUFLO0NBQzFCLElBQUksSUFBSSxPQUFPLEtBQUs7Q0FDcEIsSUFBSSxDQUFDLElBQUksU0FBUyxHQUFHLEdBQUc7Q0FDeEIsT0FBTywwQ0FBMEMsS0FBSyxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQUUsUUFBUSxhQUFhLEVBQUUsQ0FBQyxDQUFDLFlBQVk7QUFDdkc7QUFDQSxJQUFNLDhCQUE4Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CcEMsU0FBUyxvQkFBb0IsS0FBSyxXQUFXO0NBQzVDLElBQUksQ0FBQyxLQUFLLE9BQU87Q0FDakIsSUFBSSw0QkFBNEIsS0FBSyxHQUFHLEdBQUcsT0FBTztDQUNsRCxNQUFNLFNBQVMsYUFBYSxHQUFHO0NBQy9CLE9BQU8sU0FBUyxDQUFDLFVBQVUsSUFBSSxNQUFNLElBQUk7QUFDMUM7QUFDQSxJQUFNLHFCQUFxQjtDQUMxQixLQUFLO0NBQ0wsS0FBSztDQUNMLEtBQUs7Q0FDTCxVQUFVO0NBQ1YsVUFBVTtBQUNYO0FBQ0EsSUFBTSxvQkFBb0I7Ozs7Ozs7O0FBUTFCLFNBQVMsV0FBVyxLQUFLO0NBQ3hCLE9BQU8sSUFBSSxRQUFRLG9CQUFvQixVQUFVLG1CQUFtQixNQUFNO0FBQzNFO0FBQ0EsU0FBUyxXQUFXLE1BQU07Q0FDekIsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUNsQixJQUFJLFNBQVM7Q0FDYixJQUFJLHFCQUFxQixLQUFLLElBQUksR0FBRztFQUNwQyxNQUFNLEtBQUs7RUFDWCxJQUFJLFNBQVM7RUFDYixJQUFJO0VBQ0osU0FBUztFQUNULE9BQU8sVUFBVSxRQUFRLEdBQUcsS0FBSyxJQUFJLElBQUk7R0FDeEMsVUFBVSxjQUFjLEtBQUssTUFBTSxRQUFRLE1BQU0sS0FBSyxDQUFDLElBQUksTUFBTTtHQUNqRSxTQUFTLEdBQUc7RUFDYjtFQUNBLFVBQVUsY0FBYyxTQUFTLEtBQUssTUFBTSxNQUFNLElBQUksSUFBSTtDQUMzRDtDQUNBLE9BQU87QUFDUjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFvQkEsU0FBUyxrQkFBa0IsTUFBTTtDQUNoQyxJQUFJLENBQUMsb0JBQW9CLEtBQUssSUFBSSxHQUFHLE9BQU87Q0FDNUMsT0FBTyxLQUFLLFFBQVEseUJBQXlCLGtCQUFrQjtBQUNoRTtBQWNBLFNBQVMsWUFBWSxHQUFHLEdBQUc7Q0FDMUIsSUFBSSxNQUFNLEdBQUcsT0FBTztDQUNwQixJQUFJLEVBQUUsV0FBVyxFQUFFLFFBQVEsT0FBTztDQUNsQyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksRUFBRSxRQUFRLEtBQUssSUFBSSxFQUFFLE9BQU8sRUFBRSxJQUFJLE9BQU87Q0FDN0QsT0FBTztBQUNSOzs7QUN0VEEsU0FBUyxVQUFVLE9BQU87Q0FDekIsT0FBTyxVQUFVLE1BQU0sUUFBUSxRQUFRO0VBQ3RDLE9BQU8sUUFBUSxLQUFLO0NBQ3JCLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDO0FBQ2I7O0FBRUEsU0FBUyxVQUFVLE1BQU07Q0FDeEIsT0FBTyxLQUFLLFFBQVEsV0FBVyxHQUFHO0FBQ25DOztBQUVBLFNBQVMsYUFBYSxNQUFNO0NBQzNCLE9BQU8sU0FBUyxNQUFNLE9BQU8sS0FBSyxRQUFRLFFBQVEsRUFBRTtBQUNyRDs7QUFFQSxTQUFTLGNBQWMsTUFBTTtDQUM1QixNQUFNLE1BQU0sS0FBSztDQUNqQixPQUFPLE1BQU0sS0FBSyxLQUFLLE1BQU0sT0FBTyxNQUFNLEtBQUssUUFBUSxRQUFRLEVBQUUsSUFBSTtBQUN0RTs7QUFFQSxTQUFTLFNBQVMsTUFBTTtDQUN2QixPQUFPLGNBQWMsYUFBYSxJQUFJLENBQUM7QUFDeEM7O0FBRUEsU0FBUyxvQkFBb0IsT0FBTyxVQUFVO0NBQzdDLElBQUksT0FBTyxTQUFTLEdBQUcsS0FBSyxVQUFVLE9BQU8sVUFBVSxHQUFHLFNBQVMsSUFBSSxPQUFPLE1BQU0sTUFBTSxHQUFHLEVBQUU7Q0FDL0YsT0FBTztBQUNSOzs7Ozs7OztBQWVBLFNBQVMsWUFBWSxNQUFNLElBQUksZ0JBQWdCLFNBQVMsT0FBTztDQUM5RCxJQUFJLEdBQUcsU0FBUyxJQUFJLEdBQUcsS0FBSyxVQUFVLEVBQUU7Q0FDeEMsSUFBSSxHQUFHLFdBQVcsR0FBRyxHQUFHO0VBQ3ZCLElBQUksR0FBRyxXQUFXLEtBQUssa0JBQWtCLFlBQVksT0FBTztFQUM1RCxJQUFJLGtCQUFrQixVQUFVLE9BQU8sR0FBRyxTQUFTLEdBQUcsSUFBSSxLQUFLLEdBQUcsR0FBRztFQUNyRSxPQUFPLEdBQUcsU0FBUyxHQUFHLElBQUksR0FBRyxNQUFNLEdBQUcsRUFBRSxJQUFJO0NBQzdDO0NBQ0EsTUFBTSxTQUFTLE9BQU87Q0FDdEIsSUFBSTtDQUNKLElBQUksT0FBTztFQUNWLE1BQU0sU0FBUyxPQUFPLE9BQU8sT0FBTztFQUNwQyxNQUFNLFNBQVMsTUFBTSxJQUFJLEdBQUc7RUFDNUIsSUFBSSxRQUFRLE9BQU87Q0FDcEI7Q0FDQSxJQUFJO0NBQ0osSUFBSSxRQUFRLGVBQWUsS0FBSyxNQUFNLEdBQUc7TUFDcEM7RUFDSixJQUFJLEtBQUssU0FBUyxJQUFJLEdBQUcsT0FBTyxVQUFVLElBQUk7RUFDOUMsZUFBZSxLQUFLLE1BQU0sR0FBRztFQUM3QixPQUFPLGFBQWEsU0FBUyxLQUFLLEtBQUssWUFBWSxNQUFNLElBQUksYUFBYSxJQUFJO0VBQzlFLE1BQU0sYUFBYSxHQUFHLE1BQU0sR0FBRztFQUMvQixLQUFLLElBQUksUUFBUSxHQUFHLFNBQVMsV0FBVyxRQUFRLFFBQVEsUUFBUSxTQUFTO0dBQ3hFLE1BQU0sUUFBUSxXQUFXO0dBQ3pCLElBQUksVUFBVSxJQUFJO0lBQ2pCLElBQUksQ0FBQyxPQUFPLGVBQWUsQ0FBQyxLQUFLO1NBQzVCLElBQUksVUFBVSxTQUFTLEdBQUcsYUFBYSxLQUFLLEtBQUs7R0FDdkQsT0FBTyxJQUFJLFVBQVUsTUFBTTtJQUMxQixJQUFJLGFBQWEsU0FBUyxHQUFHLGFBQWEsSUFBSTtTQUN6QyxlQUFlLENBQUMsRUFBRTtHQUN4QixPQUFPLElBQUksVUFBVSxLQUFLLENBQUMsT0FBTyxhQUFhLEtBQUssS0FBSztFQUMxRDtDQUNEO0NBQ0EsSUFBSSxhQUFhLFNBQVMsR0FBRztFQUM1QixJQUFJLEtBQUssWUFBWSxNQUFNLElBQ3RCO09BQUEsa0JBQWtCLFNBQVMsYUFBYSxJQUFJO0VBQUEsT0FDMUMsSUFBSSxrQkFBa0IsVUFBVSxhQUFhLEtBQUssRUFBRTtDQUM1RDtDQUNBLE1BQU0sU0FBUyxhQUFhLEtBQUssR0FBRztDQUNwQyxNQUFNLFVBQVUsU0FBUyxVQUFVLE1BQU0sSUFBSSxXQUFXO0NBQ3hELElBQUksT0FBTyxPQUFPLE1BQU0sSUFBSSxLQUFLLE1BQU07Q0FDdkMsT0FBTztBQUNSOzs7OztBQUtBLFNBQVMscUJBQXFCLDZCQUE2QjtDQUMxRCxNQUFNLFVBQVUsSUFBSSxJQUFJLDRCQUE0QixLQUFLLFNBQVMsQ0FBQyxtQkFBbUIsSUFBSSxHQUFHLElBQUksQ0FBQyxDQUFDO0NBQ25HLE1BQU0sUUFBUSxJQUFJLE9BQU8sQ0FBQyxHQUFHLFFBQVEsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLFFBQVEsV0FBVyxNQUFNLEdBQUcsR0FBRztDQUN0RixRQUFRLFlBQVksUUFBUSxRQUFRLFFBQVEsVUFBVSxRQUFRLElBQUksS0FBSyxLQUFLLEtBQUs7QUFDbEY7O0FBS0EsU0FBUyxlQUFlLE9BQU87Q0FDOUIsT0FBTyxTQUFTLFFBQVEsVUFBVTtBQUNuQztBQVNBLFNBQVMsWUFBWSxLQUFLLE9BQU8sU0FBUztDQUN6QyxJQUFJLE9BQU8sVUFBVSxVQUFVLE9BQU8sTUFBTSxTQUFTLEtBQUs7Q0FDMUQsTUFBTSxRQUFRLFFBQVE7Q0FDdEIsSUFBSSxVQUFVLENBQUMsU0FBUyx3QkFBd0IsS0FBSyxLQUFLLElBQUksT0FBTztDQUNyRSxJQUFJLFVBQVUsbUJBQW1CLEtBQUs7Q0FDdEMsSUFBSSxPQUFPLFVBQVUsUUFBUSxXQUFXLE9BQU8sR0FBRztDQUNsRCxPQUFPLFVBQVUsUUFBUSxPQUFPLElBQUk7QUFDckM7O0FBRUEsU0FBUyxnQkFBZ0IsTUFBTSxVQUFVLFFBQVEsU0FBUyxZQUFZO0NBQ3JFLE1BQU0sZ0JBQWdCLEtBQUssU0FBUyxHQUFHLElBQUksTUFBTTtDQUNqRCxJQUFJLFNBQVM7Q0FDYixLQUFLLE1BQU0sUUFBUSxVQUFVO0VBQzVCLElBQUksT0FBTyxTQUFTLFVBQVU7R0FDN0IsVUFBVTtHQUNWO0VBQ0Q7RUFDQSxNQUFNLENBQUMsTUFBTSxLQUFLLFFBQVEsYUFBYTtFQUN2QyxNQUFNLFFBQVEsU0FBUztFQUN2QixNQUFNLFNBQVMsU0FBUyxjQUFjLEtBQUssSUFBSSxZQUFZLGdCQUFnQjtFQUMzRSxJQUFJLGFBQWEsT0FBTztFQUN4QixJQUFJLFNBQVMsS0FBSyxjQUFjLE1BQU07RUFDdEMsSUFBSSxZQUFZO0dBQ2YsV0FBVyxPQUFPO0dBQ2xCLElBQUksT0FBTyxXQUFXLE9BQU87RUFDOUI7RUFDQSxJQUFJLFNBQVMsZUFBZSxVQUFVLEdBQUc7R0FDeEMsSUFBSSxXQUFXLE9BQU8sQ0FBQyxRQUFRO0dBQy9CLGFBQWE7RUFDZDtFQUNBLFVBQVUsU0FBUyxZQUFZLEtBQUssWUFBWSxPQUFPLEtBQUssVUFBVTtDQUN2RTtDQUNBLE9BQU8sU0FBUyxpQkFBaUI7QUFDbEM7Ozs7Ozs7Ozs7Ozs7O0FDbElBLFNBQVMsaUJBQWlCLEtBQUs7Q0FDOUIsTUFBTSx3QkFBd0IsSUFBSSxJQUFJO0NBQ3RDLElBQUk7Q0FDSixJQUFJO0NBQ0osT0FBTztFQUNOLElBQUksS0FBSztHQUNSLE1BQU0sUUFBUSxNQUFNLElBQUksR0FBRztHQUMzQixJQUFJLENBQUMsT0FBTztHQUNaLE1BQU0sVUFBVTtHQUNoQixPQUFPLE1BQU07RUFDZDtFQUNBLElBQUksS0FBSyxPQUFPO0dBQ2YsTUFBTSxXQUFXLE1BQU0sSUFBSSxHQUFHO0dBQzlCLElBQUksVUFBVTtJQUNiLFNBQVMsUUFBUTtJQUNqQjtHQUNEO0dBQ0EsSUFBSSxNQUFNLFFBQVEsS0FBSztJQUN0QixJQUFJLE9BQU8sTUFBTSxLQUFLLENBQUMsQ0FBQztJQUN4QixPQUFPLENBQUMsUUFBUSxLQUFLLFNBQVM7S0FDN0IsSUFBSSxNQUFNLEtBQUssVUFBVTtVQUNwQixPQUFPLE1BQU0sT0FBTztLQUN6QixPQUFPLEtBQUssS0FBSyxDQUFDLENBQUM7SUFDcEI7SUFDQSxJQUFJLFNBQVMsUUFBUSxPQUFPLEtBQUs7SUFDakMsTUFBTSxPQUFPLEtBQUssR0FBRztHQUN0QjtHQUNBLE1BQU0sUUFBUTtJQUNiO0lBQ0E7SUFDQSxTQUFTO0dBQ1Y7R0FDQSxTQUFTO0dBQ1QsTUFBTSxJQUFJLEtBQUssS0FBSztFQUNyQjtFQUNBLFFBQVE7R0FDUCxNQUFNLE1BQU07R0FDWixPQUFPLEtBQUs7R0FDWixTQUFTLEtBQUs7RUFDZjtDQUNEO0FBQ0Q7O0FDbERBLElBQU0scUJBQXFCO0FBQzNCLElBQU0sd0JBQXdCO0FBQzlCLFNBQVMsY0FBYyxNQUFNO0NBQzVCLE1BQU0sU0FBUyxLQUFLO0NBQ3BCLElBQUksUUFBUSxPQUFPO0NBQ25CLE1BQU0sT0FBTyxDQUFDO0NBQ2QsS0FBSyxNQUFNLFdBQVcsTUFBTSxJQUFJLE9BQU8sWUFBWSxVQUFVLEtBQUssS0FBSyxRQUFRLEVBQUU7Q0FDakYsT0FBTyxLQUFLLFFBQVE7QUFDckI7O0FBRUEsU0FBUyxhQUFhLE1BQU0sT0FBTyxLQUFLO0NBQ3ZDLE1BQU0sT0FBTyxLQUFLLE1BQU0sT0FBTyxHQUFHO0NBQ2xDLElBQUksS0FBSyxXQUFXLENBQUMsTUFBTSxJQUFJLE9BQU8sS0FBSyxXQUFXLElBQUk7RUFDekQ7RUFDQTtFQUNBO0VBQ0EsS0FBSztDQUNOLElBQUk7RUFDSDtFQUNBLEtBQUssTUFBTSxDQUFDO0VBQ1o7RUFDQTtDQUNEO0NBQ0EsTUFBTSxPQUFPLEtBQUssUUFBUSxHQUFHO0NBQzdCLElBQUksUUFBUSxHQUFHO0VBQ2QsTUFBTSxRQUFRLEtBQUssUUFBUSxLQUFLLElBQUk7RUFDcEMsTUFBTSxXQUFXLEtBQUssV0FBVyxPQUFPLENBQUMsTUFBTTtFQUMvQyxNQUFNLFlBQVksUUFBUSxXQUFXLElBQUk7RUFDekMsSUFBSSxTQUFTLEtBQUssS0FBSyxXQUFXLFlBQVksQ0FBQyxNQUFNLE9BQU8sQ0FBQyxZQUFZLFlBQVksUUFBUTtHQUM1RixNQUFNLE1BQU0sS0FBSyxNQUFNLFdBQVcsS0FBSztHQUN2QyxPQUFPO0lBQ04sV0FBVyxJQUFJLE1BQU0sSUFBSTtJQUN6QixPQUFPO0lBQ1AsS0FBSyxNQUFNLEdBQUcsSUFBSTtJQUNsQixLQUFLLE1BQU0sUUFBUSxRQUFRLEdBQUcsTUFBTSxNQUFNLEtBQUssTUFBTTtHQUN0RDtFQUNEO0NBQ0Q7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLGNBQWMsc0JBQXNCLE9BQU8sT0FBTyxNQUFNLG9CQUFvQixxQkFBcUI7Q0FDekcsSUFBSSxTQUFTO0NBQ2IsTUFBTSxPQUFPLE1BQU0sWUFBWSxNQUFNO0NBQ3JDLE1BQU0sVUFBVSxNQUFNO0NBQ3RCLE1BQU0sU0FBUyxLQUFLO0NBQ3BCLE1BQU0sYUFBYSxLQUFLLFNBQVMsR0FBRyxJQUFJLFNBQVMsSUFBSTtDQUNyRCxNQUFNLGdCQUFnQixTQUFTLGlCQUFpQjtDQUNoRCxNQUFNLGNBQWMsU0FBUyxRQUFRLFNBQVMsU0FBUztDQUN2RCxJQUFJO0NBQ0osSUFBSSxlQUFlLHNCQUFzQixRQUFRLElBQUk7Q0FDckQsSUFBSSxDQUFDLFFBQVEsS0FBSyxTQUFTLEdBQUcsR0FBRztFQUNoQyxnQkFBZ0IscUJBQXFCLE1BQU0sS0FBSyxDQUFDO0VBQ2pELE1BQU0sT0FBTyxLQUFLLGFBQWE7RUFDL0IsSUFBSSxRQUFRLE9BQU8sU0FBUyxZQUFZLEtBQUssT0FBTyxHQUFHO0dBQ3RELGNBQWMsY0FBYyxTQUFTLEtBQUs7SUFDekMsS0FBSztJQUNMLEtBQUs7SUFDTCxLQUFLO0lBQ0wsS0FBSyxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksS0FBSyxLQUFLLEtBQUssVUFBVSxTQUFTLEtBQUssUUFBUSxPQUFPLE1BQU0sSUFBSSxJQUFJLFVBQVU7R0FDN0c7R0FDQSxlQUFlO0VBQ2hCO0NBQ0Q7Q0FDQSxPQUFPLFNBQVMsUUFBUTtFQUN2QixNQUFNLFFBQVE7RUFDZCxNQUFNLE9BQU8sS0FBSyxRQUFRLEtBQUssS0FBSztFQUNwQyxJQUFJLE1BQU0sU0FBUyxLQUFLLFNBQVM7RUFDakMsTUFBTSxVQUFVLGFBQWEsTUFBTSxPQUFPLEdBQUc7RUFDN0MsU0FBUyxNQUFNO0VBQ2YsSUFBSTtFQUNKLElBQUksT0FBTyxZQUFZLFVBQVU7R0FDaEMsSUFBSSxDQUFDLE1BQU07R0FDWCxJQUFJLE9BQU87R0FDWCxJQUFJO0dBQ0osSUFBSSxlQUFlLGlCQUFpQixLQUFLLDJCQUEyQixJQUFJLElBQUk7UUFDdkU7SUFDSixPQUFPLFFBQVEsWUFBWTtJQUMzQixpQkFBaUIsS0FBSyxzQ0FBc0MsSUFBSSxJQUFJO0dBQ3JFO0dBQ0EsTUFBTSxlQUFlLGVBQWUsSUFBSSxJQUFJO0dBQzVDLElBQUksY0FBYyxXQUFXO1FBQ3hCO0lBQ0osTUFBTSxPQUFPLGtCQUFrQixJQUFJO0lBQ25DLFdBQVc7SUFDWCxlQUFlLElBQUksTUFBTSxJQUFJO0dBQzlCO0VBQ0QsT0FBTztHQUNOLE1BQU0sT0FBTyxRQUFRO0dBQ3JCLElBQUksU0FBUyxRQUFRO0dBQ3JCLElBQUksU0FBUyxRQUFRLE1BQU07R0FDM0IsSUFBSSxTQUFTLEdBQUc7SUFDZixNQUFNO0lBQ04sU0FBUyxNQUFNO0dBQ2hCO0dBQ0EsSUFBSSxpQkFBaUIsZUFBZSxLQUFLO0lBQ3hDLElBQUksZUFBZSxRQUFRLEdBQUcsY0FBYyxLQUFLLEtBQUssTUFBTSxjQUFjLFFBQVEsQ0FBQyxDQUFDO0lBQ3BGLFFBQVEsS0FBSyxNQUFNO0lBQ25CLElBQUksU0FBUyxLQUFLLFFBQVEsT0FBTyxLQUFLLEtBQUssYUFBYSxRQUFRLFFBQVEsS0FBSyxPQUFPLE1BQU0sR0FBRyxFQUFFO0lBQy9GLGNBQWMsS0FBSyxPQUFPO0lBQzFCLGVBQWU7R0FDaEI7R0FDQSxJQUFJLENBQUMsTUFBTTtHQUNYLE1BQU0sd0JBQXdCLGlCQUFpQixDQUFDLEVBQUUsVUFBVTtHQUM1RCxJQUFJLENBQUMsZUFBZTtJQUNuQixTQUFTLE9BQU8sWUFBWTtJQUM1QixTQUFTLE9BQU8sWUFBWTtHQUM3QjtHQUNBLE1BQU0sV0FBVyxTQUFTLElBQUksS0FBSyxZQUFZLENBQUMsSUFBSSxTQUFTLElBQUksS0FBSyxhQUFhLENBQUMsSUFBSSxLQUFLLGFBQWEsQ0FBQztHQUMzRyxNQUFNLGVBQWUsU0FBUyxLQUFLLENBQUMsZUFBZSxTQUFTLE1BQU0sTUFBTSxDQUFDLEVBQUUsU0FBUyxFQUFFLGtCQUFrQix5QkFBeUIsRUFBRSxXQUFXLFVBQVUsRUFBRSxXQUFXLE1BQU07R0FDM0ssSUFBSSxjQUFjLFdBQVc7UUFDeEI7SUFDSixNQUFNLE9BQU8sa0JBQWtCLE1BQU0sTUFBTSx1QkFBdUIsUUFBUSxNQUFNO0lBQ2hGLFdBQVc7SUFDWCxTQUFTLEtBQUssSUFBSTtJQUNsQixJQUFJLFNBQVMsV0FBVyxHQUFHLG9CQUFvQixLQUFLLFFBQVE7R0FDN0Q7RUFDRDtFQUNBLE9BQU87Q0FDUjtDQUNBLElBQUksaUJBQWlCLGVBQWUsWUFBWSxjQUFjLEtBQUssS0FBSyxNQUFNLGNBQWMsVUFBVSxDQUFDO0NBQ3ZHLE1BQU0sY0FBYyxlQUFlLE1BQU07Q0FDekMsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUNsQixJQUFJLGVBQWUsTUFBTSxZQUFZLENBQUMsTUFBTSxVQUFVLE1BQU0sTUFBTSxNQUFNLEdBQUcsV0FBVyxNQUFNLEdBQUcsWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLElBQUk7RUFDNUgsTUFBTSxlQUFlLGtCQUFrQixNQUFNLHFCQUFxQjtFQUNsRSxDQUFDLEtBQUssYUFBYSxDQUFDLEVBQUEsQ0FBRyxLQUFLLFlBQVk7RUFDeEMsT0FBTztDQUNSO0NBQ0EsTUFBTSxVQUFVLE1BQU0sUUFBUSxDQUFDLE1BQU0sYUFBYSxDQUFDLE1BQU07Q0FDekQsSUFBSSxVQUFVLGFBQWEsUUFBUTtFQUNsQyxNQUFNLFlBQVksa0JBQWtCLE1BQU0sa0JBQWtCO0VBQzVELEtBQUssUUFBUTtFQUNiLE9BQU87Q0FDUjtDQUNBLEtBQUssUUFBUSxlQUFlO0NBQzVCLEtBQUssV0FBVyxTQUFTLFFBQVEsWUFBWTtDQUM3QyxJQUFJLENBQUMsS0FBSyxPQUFPO0VBQ2hCLEtBQUssT0FBTztFQUNaLElBQUksUUFBUSxLQUFLLFFBQVE7Q0FDMUI7Q0FDQSxPQUFPO0VBQ047RUFDQTtFQUNBO0NBQ0Q7QUFDRDtBQUNBLFNBQVMsWUFBWSxHQUFHLEdBQUc7Q0FDMUIsSUFBSSxFQUFFLFNBQVMsQ0FBQyxFQUFFLE9BQU8sT0FBTztDQUNoQyxJQUFJLENBQUMsRUFBRSxTQUFTLEVBQUUsT0FBTyxPQUFPO0NBQ2hDLElBQUksRUFBRSxTQUFTLEVBQUUsVUFBVSxFQUFFLFlBQVksRUFBRSxXQUFXLE9BQU8sRUFBRSxXQUFXLEVBQUU7Q0FDNUUsSUFBSSxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsV0FBVyxFQUFFLFFBQVE7RUFDbEQsSUFBSSxFQUFFLE9BQU8sV0FBVyxFQUFFLE1BQU0sR0FBRyxPQUFPO0VBQzFDLElBQUksRUFBRSxPQUFPLFdBQVcsRUFBRSxNQUFNLEdBQUcsT0FBTztDQUMzQztDQUNBLElBQUksRUFBRSxVQUFVLEVBQUUsVUFBVSxFQUFFLFdBQVcsRUFBRSxRQUFRO0VBQ2xELElBQUksRUFBRSxPQUFPLFNBQVMsRUFBRSxNQUFNLEdBQUcsT0FBTztFQUN4QyxJQUFJLEVBQUUsT0FBTyxTQUFTLEVBQUUsTUFBTSxHQUFHLE9BQU87Q0FDekM7Q0FDQSxJQUFJLEVBQUUsVUFBVSxDQUFDLEVBQUUsUUFBUSxPQUFPO0NBQ2xDLElBQUksQ0FBQyxFQUFFLFVBQVUsRUFBRSxRQUFRLE9BQU87Q0FDbEMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxFQUFFLFFBQVEsT0FBTztDQUNsQyxJQUFJLENBQUMsRUFBRSxVQUFVLEVBQUUsUUFBUSxPQUFPO0NBQ2xDLElBQUksRUFBRSxpQkFBaUIsQ0FBQyxFQUFFLGVBQWUsT0FBTztDQUNoRCxJQUFJLENBQUMsRUFBRSxpQkFBaUIsRUFBRSxlQUFlLE9BQU87Q0FDaEQsT0FBTztBQUNSO0FBQ0EsU0FBUyxrQkFBa0IsUUFBUSxPQUFPLEdBQUcsZUFBZSxRQUFRLFFBQVE7Q0FDM0UsT0FBTztFQUNOO0VBQ0EsT0FBTyxTQUFTLE9BQU8sUUFBUSxJQUFJO0VBQ25DLFVBQVU7RUFDVixPQUFPO0VBQ1AsUUFBUTtFQUNSLG1CQUFtQjtFQUNuQixTQUFTO0VBQ1QsVUFBVTtFQUNWLFVBQVU7RUFDVixPQUFPO0VBQ1AsTUFBTSxLQUFLO0VBQ1g7RUFDQSxPQUFPO0VBQ1AsVUFBVTtFQUNWO0VBQ0E7RUFDQTtDQUNEO0FBQ0Q7QUFDQSxTQUFTLGtCQUFrQixXQUFXLGVBQWU7Q0FDcEQsTUFBTSxjQUFjLGtCQUFrQjtDQUN0QyxNQUFNLHFCQUFxQixDQUFDO0NBQzVCLFNBQVMsTUFBTSxPQUFPLE9BQU8sWUFBWSxxQkFBcUI7RUFDN0QsTUFBTSxDQUFDLE1BQU0sUUFBUSxZQUFZLGNBQWMsT0FBTyxPQUFPLE9BQU8sWUFBWSxvQkFBb0IsbUJBQW1CO0VBQ3ZILElBQUksTUFBTSxVQUFVLEtBQUssTUFBTSxTQUFTLE1BQU0sVUFBVSxNQUFNLE9BQU8sUUFBUSxNQUFNLFFBQVE7Q0FDNUY7Q0FDQSxLQUFLLE1BQU0sU0FBUyxXQUFXLE1BQU0sT0FBTyxHQUFHLFdBQVc7Q0FDMUQsS0FBSyxNQUFNLFNBQVMsb0JBQW9CLE1BQU0sS0FBSyxXQUFXO0NBQzlELGNBQWMsWUFBWTtDQUMxQixjQUFjLFlBQVksaUJBQWlCLEdBQUc7QUFDL0M7Ozs7QUFJQSxTQUFTLGNBQWMsTUFBTSxlQUFlO0NBQzNDLFNBQVM7Q0FDVCxNQUFNLFNBQVMsY0FBYyxVQUFVLElBQUksSUFBSTtDQUMvQyxJQUFJLFdBQVcsS0FBSyxHQUFHLE9BQU87Q0FDOUIsTUFBTSxTQUFTLFVBQVUsTUFBTSxjQUFjLFNBQVM7Q0FDdEQsY0FBYyxVQUFVLElBQUksTUFBTSxNQUFNO0NBQ3hDLE9BQU87QUFDUjs7OztBQUlBLFNBQVMsZ0JBQWdCLE1BQU0sZUFBZSxPQUFPLE1BQU0sZUFBZTtDQUN6RSxTQUFTO0NBQ1QsU0FBUztDQUNULE1BQU0sTUFBTSxnQkFBZ0IsU0FBUyxTQUFTO0NBQzlDLElBQUksT0FBTyxjQUFjLFlBQVksSUFBSSxHQUFHO0NBQzVDLElBQUksQ0FBQyxNQUFNO0VBQ1YsT0FBTyxrQkFBa0I7RUFDekIsY0FBYyxlQUFlLEVBQUUsS0FBSyxHQUFHLEdBQUcsSUFBSTtFQUM5QyxjQUFjLFlBQVksSUFBSSxLQUFLLElBQUk7Q0FDeEM7Q0FDQSxPQUFPLFVBQVUsTUFBTSxNQUFNLEtBQUs7QUFDbkM7QUFDQSxTQUFTLGVBQWUsTUFBTSxlQUFlLFFBQVEsT0FBTztDQUMzRCxNQUFNLE1BQU0sUUFBUSxPQUFPLFdBQVc7Q0FDdEMsTUFBTSxTQUFTLGNBQWMsV0FBVyxJQUFJLEdBQUc7Q0FDL0MsSUFBSSxXQUFXLEtBQUssR0FBRyxPQUFPO0NBQzlCLFNBQVM7Q0FDVCxJQUFJO0NBQ0osSUFBSTtFQUNILFNBQVMsVUFBVSxNQUFNLGNBQWMsYUFBYSxLQUFLO0NBQzFELFNBQVMsS0FBSztFQUNiLElBQUksZUFBZSxVQUFVLFNBQVM7T0FDakMsTUFBTTtDQUNaO0NBQ0EsSUFBSSxRQUFRLE9BQU8sU0FBUyxpQkFBaUIsT0FBTyxLQUFLO0NBQ3pELGNBQWMsV0FBVyxJQUFJLEtBQUssTUFBTTtDQUN4QyxPQUFPO0FBQ1I7Ozs7O0FBS0EsU0FBUyxpQkFBaUIsV0FBVyxnQkFBZ0IsT0FBTztDQUMzRCxNQUFNLGNBQWMsa0JBQWtCO0NBQ3RDLE1BQU0scUJBQXFCLENBQUM7Q0FDNUIsTUFBTSxhQUFhLENBQUM7Q0FDcEIsTUFBTSxlQUFlLENBQUM7Q0FDdEIsSUFBSSxRQUFRO0NBQ1osU0FBUyxNQUFNLE9BQU8sT0FBTyxZQUFZLHFCQUFxQjtFQUM3RCxNQUFNLEtBQUssS0FBSztFQUNoQixJQUFJLE1BQU0sTUFBTSxZQUM0QixNQUFNLElBQUksTUFBTSxxREFBcUQsT0FBTyxNQUFNLEVBQUUsR0FBRztFQUduSSxXQUFXLE1BQU0sTUFBTTtFQUN2QixJQUFJLFVBQVUsS0FBSyxNQUFNLE1BQU07R0FDOUIsTUFBTSxrQkFBa0IsY0FBYyxNQUFNLFFBQVE7R0FDcEQsSUFBSSxDQUFDLGFBQWEsb0JBQW9CLE1BQU0sU0FBUyxTQUFTLEdBQUcsR0FBRyxhQUFhLG1CQUFtQjtFQUNyRztFQUNBO0VBQ0EsTUFBTSxDQUFDLE1BQU0sUUFBUSxZQUFZLGNBQWMsZUFBZSxPQUFPLE9BQU8sWUFBWSxvQkFBb0IsbUJBQW1CO0VBQy9ILE1BQU0saUJBQWlCO0VBQ3ZCLElBQUksTUFBTSxVQUFVLEtBQUssTUFBTSxTQUFTLE1BQU0sVUFBVSxNQUFNLE9BQU8sUUFBUSxNQUFNLFFBQVE7Q0FDNUY7Q0FDQSxNQUFNLFdBQVcsR0FBRyxXQUFXO0NBQy9CLEtBQUssTUFBTSxTQUFTLG9CQUFvQixNQUFNLEtBQUssV0FBVztDQUM5RCxPQUFPO0VBQ04sZUFBZTtHQUNkO0dBQ0EsYUFBYSxpQkFBaUIsR0FBRztHQUNqQyxZQUFZLGlCQUFpQixHQUFHO0dBQ2hDLFdBQVc7R0FDWCxXQUFXO0VBQ1o7RUFDQTtFQUNBO0NBQ0Q7QUFDRDtBQUNBLFNBQVMsVUFBVSxNQUFNLGFBQWEsUUFBUSxPQUFPO0NBQ3BELE1BQU0sUUFBUSxLQUFLLE1BQU0sR0FBRztDQUM1QixNQUFNLE9BQU8sYUFBYSxNQUFNLE9BQU8sYUFBYSxLQUFLO0NBQ3pELElBQUksQ0FBQyxNQUFNLE9BQU87Q0FDbEIsTUFBTSxDQUFDLGFBQWEsY0FBYyxNQUFNLE9BQU8sSUFBSTtDQUNuRCxPQUFPO0VBQ04sT0FBTyxLQUFLLEtBQUs7RUFDakI7Q0FDRDtBQUNEOzs7Ozs7OztBQVFBLFNBQVMsY0FBYyxNQUFNLE9BQU8sTUFBTTtDQUN6QyxNQUFNLE9BQU8sWUFBWSxLQUFLLElBQUk7Q0FDbEMsTUFBTSxRQUFRLEtBQUssS0FBSyxRQUFRLGNBQWMsS0FBSyxLQUFLLElBQUk7Q0FDNUQsTUFBTSxZQUFZLE9BQU8sT0FBTyxJQUFJOztDQUVwQyxJQUFJLFlBQVksS0FBSyxTQUFTLFFBQVE7O0NBRXRDLElBQUksWUFBWSxLQUFLLFNBQVMsUUFBUTs7Q0FFdEMsSUFBSSxZQUFZLEtBQUssU0FBUyxRQUFROztDQUV0QyxJQUFJLGFBQWEsS0FBSyxTQUFTLFNBQVM7Q0FDeEMsT0FBTyxZQUFZLEtBQUssUUFBUSxhQUFhLGFBQWEsYUFBYTtFQUN0RSxNQUFNLE9BQU8sS0FBSztFQUNsQixJQUFJLEtBQUssU0FBUyxvQkFBb0I7RUFDdEMsSUFBSSxLQUFLLFNBQVMsdUJBQXVCO0dBQ3hDO0dBQ0E7R0FDQTtFQUNEO0VBQ0EsTUFBTSxPQUFPLE1BQU07RUFDbkIsTUFBTSxtQkFBbUI7RUFDekIsSUFBSSxNQUFNLGFBQWEsS0FBSztFQUM1QixJQUFJLEtBQUssU0FBUyxLQUFLLEtBQUssU0FBUyxHQUFHO0dBQ3ZDLE1BQU0sT0FBTyxNQUFNO0dBQ25CLElBQUksS0FBSyxTQUFTLEtBQUssS0FBSyxVQUFVLEtBQUssV0FBVztJQUNyRDtJQUNBLFlBQVksbUJBQW1CO0lBQy9CO0dBQ0Q7R0FDQSxNQUFNLFFBQVEsS0FBSyxVQUFVLEtBQUssU0FBUyxLQUFLLFVBQVUsS0FBSyxPQUFPLFFBQVEsS0FBSyxTQUFTLEtBQUssT0FBTyxNQUFNLElBQUk7R0FDbEgsSUFBSSxTQUFTLEtBQUssU0FBUyxHQUFHLFVBQVUsUUFBUSxtQkFBbUIsS0FBSztFQUN6RSxPQUFPLElBQUksS0FBSyxTQUFTLEdBQUc7R0FDM0IsTUFBTSxJQUFJO0dBQ1YsTUFBTSxRQUFRLEtBQUssVUFBVSxtQkFBbUIsRUFBRSxPQUFPLFFBQVEsS0FBSyxTQUFTLEVBQUUsT0FBTyxNQUFNO0dBQzlGLE1BQU0sUUFBUSxtQkFBbUIsS0FBSztHQUN0QyxVQUFVLE9BQU87R0FDakIsVUFBVSxTQUFTO0dBQ25CO0VBQ0Q7Q0FDRDtDQUNBLElBQUksS0FBSyxXQUFXLE9BQU8sT0FBTyxXQUFXLEtBQUssU0FBUztDQUMzRCxPQUFPLENBQUMsV0FBVztFQUNsQixNQUFNO0VBQ04sTUFBTTtFQUNOLE1BQU07RUFDTixPQUFPO0NBQ1IsQ0FBQztBQUNGO0FBQ0EsU0FBUyxpQkFBaUIsT0FBTztDQUNoQyxNQUFNLE9BQU8sQ0FBQyxLQUFLO0NBQ25CLE9BQU8sTUFBTSxhQUFhO0VBQ3pCLFFBQVEsTUFBTTtFQUNkLEtBQUssS0FBSyxLQUFLO0NBQ2hCO0NBQ0EsS0FBSyxRQUFRO0NBQ2IsT0FBTztBQUNSO0FBQ0EsU0FBUyxZQUFZLE1BQU07Q0FDMUIsTUFBTSxPQUFPLE1BQU0sS0FBSyxRQUFRLENBQUM7Q0FDakMsR0FBRztFQUNGLEtBQUssS0FBSyxTQUFTO0VBQ25CLE9BQU8sS0FBSztDQUNiLFNBQVM7Q0FDVCxPQUFPO0FBQ1I7QUFDQSxTQUFTLGFBQWEsTUFBTSxPQUFPLGFBQWEsT0FBTztDQUN0RCxJQUFJLFNBQVMsT0FBTyxZQUFZLE9BQU8sT0FBTztFQUM3QyxNQUFNLFlBQVk7RUFDbEIsU0FBUztDQUNWO0NBQ0EsTUFBTSxnQkFBZ0IsQ0FBQyxLQUFLLEtBQUs7Q0FDakMsTUFBTSxjQUFjLGlCQUFpQixTQUFTO0NBQzlDLE1BQU0sY0FBYyxNQUFNLFVBQVUsZ0JBQWdCLElBQUk7Q0FDeEQsTUFBTSxRQUFRLENBQUM7RUFDZCxNQUFNO0VBQ04sT0FBTztFQUNQLFNBQVM7RUFDVCxTQUFTO0VBQ1QsVUFBVTtFQUNWLFdBQVc7Q0FDWixDQUFDO0NBQ0QsSUFBSSxZQUFZO0NBQ2hCLElBQUksWUFBWTtDQUNoQixPQUFPLE1BQU0sUUFBUTtFQUNwQixNQUFNLFFBQVEsTUFBTSxJQUFJO0VBQ3hCLE1BQU0sRUFBRSxNQUFNLE9BQU8sU0FBUyxTQUFTLFVBQVUsY0FBYztFQUMvRCxJQUFJLEVBQUUsU0FBUyxjQUFjO0VBQzdCLElBQUksS0FBSyxTQUFTLEtBQUssS0FBSyxTQUFTLENBQUMsb0JBQW9CLFdBQVcsS0FBSyxHQUFHO0VBQzdFLElBQUksS0FBSyxPQUFPO0dBQ2YsSUFBSSxDQUFDLG9CQUFvQixNQUFNLE9BQU8sS0FBSyxHQUFHO0dBQzlDLFlBQVksTUFBTTtHQUNsQixVQUFVLE1BQU07RUFDakI7RUFDQSxJQUFJLFNBQVMsS0FBSyxTQUFTLEtBQUssU0FBUyxzQkFBc0Isb0JBQW9CLFdBQVcsS0FBSyxHQUFHLFlBQVk7RUFDbEgsTUFBTSxlQUFlLFVBQVU7RUFDL0IsSUFBSSxjQUFjO0dBQ2pCLElBQUksS0FBSyxVQUFVLENBQUMsZUFBZSxLQUFLLFNBQVMsc0JBQXNCLEtBQUssU0FBUyxNQUFNLG9CQUFvQixXQUFXLEtBQUssR0FBRyxZQUFZO0dBQzlJLElBQUksQ0FBQyxLQUFLLFlBQVksQ0FBQyxLQUFLLFlBQVksQ0FBQyxLQUFLLFNBQVMsQ0FBQyxLQUFLLFVBQVU7RUFDeEU7RUFDQSxNQUFNLE9BQU8sZUFBZSxLQUFLLElBQUksTUFBTTtFQUMzQyxJQUFJO0VBQ0osSUFBSSxnQkFBZ0IsS0FBSyxPQUFPO0dBQy9CLE1BQU0sYUFBYTtJQUNsQixNQUFNLEtBQUs7SUFDWDtJQUNBO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtHQUNEO0dBQ0EsSUFBSSxhQUFhO0dBQ2pCLElBQUksS0FBSyxNQUFNLE9BQ1Y7UUFBQSxDQUFDLG9CQUFvQixNQUFNLE9BQU8sVUFBVSxHQUFHLGFBQWE7R0FBQTtHQUVqRSxJQUFJLFlBQVk7SUFDZixJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxXQUFXLHFCQUFxQixTQUFTLFdBQVcsR0FBRyxPQUFPO0lBQzlGLElBQUksb0JBQW9CLFdBQVcsVUFBVSxHQUFHLFlBQVk7R0FDN0Q7RUFDRDtFQUNBLElBQUksS0FBSyxVQUFVLEtBQUssSUFBSSxJQUFJLEtBQUssU0FBUyxTQUFTLEdBQUcsS0FBSyxHQUFHLEtBQUs7R0FDdEUsTUFBTSxVQUFVLEtBQUssU0FBUztHQUM5QixNQUFNLEVBQUUsUUFBUSxXQUFXO0dBQzNCLElBQUksUUFBUTtJQUNYLElBQUksY0FBYztJQUNsQixJQUFJLEVBQUUsUUFBUSxnQkFBZ0IsT0FBTyxjQUFjLEtBQUssWUFBWSxFQUFBLENBQUcsV0FBVyxNQUFNLEdBQUc7R0FDNUY7R0FDQSxJQUFJLFFBQVE7SUFDWCxJQUFJLGNBQWM7SUFDbEIsTUFBTSxNQUFNLE1BQU0sTUFBTSxLQUFLLENBQUMsQ0FBQyxLQUFLLEdBQUc7SUFDdkMsTUFBTSxhQUFhLElBQUksTUFBTSxDQUFDLE9BQU8sTUFBTTtJQUMzQyxLQUFLLFFBQVEsZ0JBQWdCLGFBQWEsV0FBVyxZQUFZLE9BQU8sVUFBVSxJQUFJLFNBQVMsT0FBTyxTQUFTLE9BQU8sUUFBUTtHQUMvSDtHQUNBLE1BQU0sS0FBSztJQUNWLE1BQU07SUFDTixPQUFPO0lBQ1A7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0QsQ0FBQztFQUNGO0VBQ0EsSUFBSSxLQUFLLFVBQVU7R0FDbEIsTUFBTSxjQUFjLFVBQVUsS0FBSyxLQUFLLFFBQVE7R0FDaEQsS0FBSyxJQUFJLElBQUksS0FBSyxTQUFTLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztJQUNuRCxNQUFNLFVBQVUsS0FBSyxTQUFTO0lBQzlCLE1BQU0sS0FBSztLQUNWLE1BQU07S0FDTjtLQUNBLFNBQVM7S0FDVDtLQUNBO0tBQ0E7S0FDQTtLQUNBO0lBQ0QsQ0FBQztHQUNGO0dBQ0EsSUFBSSxDQUFDLGNBQWMsS0FBSyxJQUFJLElBQUksS0FBSyxTQUFTLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztJQUN0RSxNQUFNLFVBQVUsS0FBSyxTQUFTO0lBQzlCLE1BQU0sRUFBRSxRQUFRLFdBQVc7SUFDM0IsSUFBSSxVQUFVLFFBQVE7S0FDckIsTUFBTSxXQUFXLFFBQVEsZ0JBQWdCLE9BQU8sY0FBYyxLQUFLLFlBQVk7S0FDL0UsSUFBSSxVQUFVLENBQUMsU0FBUyxXQUFXLE1BQU0sR0FBRztLQUM1QyxJQUFJLFVBQVUsU0FBUyxRQUFRLFFBQVEsU0FBUyxTQUFTLE9BQU8sTUFBTSxJQUFJLE9BQU8sUUFBUTtJQUMxRjtJQUNBLE1BQU0sS0FBSztLQUNWLE1BQU07S0FDTixPQUFPLFFBQVE7S0FDZjtLQUNBO0tBQ0E7S0FDQSxXQUFXLFlBQVksYUFBYSxhQUFhLEtBQUs7S0FDdEQ7S0FDQTtJQUNELENBQUM7R0FDRjtFQUNEO0VBQ0EsSUFBSSxDQUFDLGdCQUFnQixLQUFLLFdBQVcsTUFBTSxLQUFLLElBQUksSUFBSSxLQUFLLFFBQVEsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQzdGLE1BQU0sVUFBVSxLQUFLLFFBQVE7R0FDN0IsTUFBTSxFQUFFLFFBQVEsV0FBVztHQUMzQixJQUFJLFVBQVUsUUFBUTtJQUNyQixNQUFNLFdBQVcsUUFBUSxnQkFBZ0IsT0FBTyxjQUFjLEtBQUssWUFBWTtJQUMvRSxJQUFJLFVBQVUsQ0FBQyxTQUFTLFdBQVcsTUFBTSxHQUFHO0lBQzVDLElBQUksVUFBVSxTQUFTLFFBQVEsUUFBUSxTQUFTLFNBQVMsT0FBTyxNQUFNLElBQUksT0FBTyxRQUFRO0dBQzFGO0dBQ0EsTUFBTSxLQUFLO0lBQ1YsTUFBTTtJQUNOLE9BQU8sUUFBUTtJQUNmO0lBQ0E7SUFDQSxVQUFVLFdBQVcsYUFBYSxhQUFhLEtBQUs7SUFDcEQ7SUFDQTtJQUNBO0dBQ0QsQ0FBQztFQUNGO0VBQ0EsSUFBSSxDQUFDLGdCQUFnQixLQUFLLG1CQUFtQjtHQUM1QyxNQUFNLFFBQVEsS0FBSyxrQkFBa0IsSUFBSSxjQUFjLEtBQUssWUFBWSxDQUFDO0dBQ3pFLElBQUksT0FBTyxNQUFNLEtBQUs7SUFDckIsTUFBTTtJQUNOLE9BQU8sUUFBUTtJQUNmO0lBQ0EsU0FBUyxVQUFVLGFBQWEsYUFBYSxLQUFLO0lBQ2xEO0lBQ0E7SUFDQTtJQUNBO0dBQ0QsQ0FBQztFQUNGO0VBQ0EsSUFBSSxDQUFDLGdCQUFnQixLQUFLLFFBQVE7R0FDakMsTUFBTSxRQUFRLEtBQUssT0FBTyxJQUFJLElBQUk7R0FDbEMsSUFBSSxPQUFPLE1BQU0sS0FBSztJQUNyQixNQUFNO0lBQ04sT0FBTyxRQUFRO0lBQ2Y7SUFDQSxTQUFTLFVBQVUsYUFBYSxhQUFhLEtBQUs7SUFDbEQ7SUFDQTtJQUNBO0lBQ0E7R0FDRCxDQUFDO0VBQ0Y7RUFDQSxJQUFJLEtBQUssVUFBVSxLQUFLLElBQUksSUFBSSxLQUFLLFNBQVMsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQ3RFLE1BQU0sVUFBVSxLQUFLLFNBQVM7R0FDOUIsTUFBTSxLQUFLO0lBQ1YsTUFBTTtJQUNOO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0QsQ0FBQztFQUNGO0NBQ0Q7Q0FDQSxJQUFJLFdBQVcsT0FBTztDQUN0QixJQUFJLFNBQVMsV0FBVztFQUN2QixJQUFJLGFBQWEsVUFBVTtFQUMzQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksVUFBVSxPQUFPLEtBQUssY0FBYyxNQUFNLEVBQUUsQ0FBQztFQUNqRSxNQUFNLFFBQVEsZUFBZSxLQUFLLFNBQVMsTUFBTSxLQUFLLE1BQU0sVUFBVTtFQUN0RSxVQUFVLGNBQWMsT0FBTyxPQUFPLElBQUk7RUFDMUMsVUFBVSxVQUFVLFFBQVEsbUJBQW1CLEtBQUs7RUFDcEQsT0FBTztDQUNSO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxhQUFhLGFBQWEsT0FBTztDQUN6QyxPQUFPLE1BQU0sY0FBYyxRQUFRO0FBQ3BDO0FBQ0EsU0FBUyxxQkFBcUIsU0FBUyxhQUFhO0NBQ25ELE9BQU8sWUFBWSxNQUFNLGNBQWMsS0FBSztBQUM3QztBQUNBLFNBQVMsb0JBQW9CLE1BQU0sT0FBTyxPQUFPO0NBQ2hELElBQUk7Q0FDSixJQUFJO0NBQ0osSUFBSTtFQUNILENBQUMsV0FBVyxTQUFTLGNBQWMsTUFBTSxPQUFPLEtBQUs7Q0FDdEQsUUFBUTtFQUNQLE9BQU87Q0FDUjtDQUNBLE1BQU0sWUFBWTtDQUNsQixNQUFNLFVBQVU7Q0FDaEIsSUFBSSxDQUFDLE1BQU0sS0FBSyxPQUFPLE9BQU87Q0FDOUIsSUFBSTtFQUNILElBQUksTUFBTSxLQUFLLE1BQU0sU0FBUyxNQUFNLE9BQU8sT0FBTztDQUNuRCxRQUFRLENBQUM7Q0FDVCxPQUFPO0FBQ1I7QUFDQSxTQUFTLG9CQUFvQixNQUFNLE1BQU07Q0FDeEMsSUFBSSxDQUFDLE1BQU0sT0FBTztDQUNsQixPQUFPLEtBQUssVUFBVSxLQUFLLFdBQVcsS0FBSyxZQUFZLEtBQUssWUFBWSxLQUFLLFdBQVcsS0FBSyxZQUFZLEtBQUssYUFBYSxLQUFLLGFBQWEsS0FBSyxZQUFZLEtBQUssYUFBYSxLQUFLLGNBQWMsS0FBSyxlQUFlLEtBQUssS0FBSyxTQUFTLHVCQUF1QixLQUFLLEtBQUssU0FBUyx1QkFBdUIsS0FBSyxLQUFLLFNBQVMsd0JBQXdCLEtBQUssS0FBSyxTQUFTLHVCQUF1QixLQUFLLEtBQUssUUFBUSxLQUFLLEtBQUs7QUFDN1o7O0FDL2pCQSxTQUFTLHdCQUF3QjtDQUNoQyxJQUFJO0VBQ0gsT0FBTztDQUNSLFFBQVE7RUFDUDtDQUNEO0FBQ0Q7QUFDQSxJQUFNLGFBQWE7QUFDbkIsSUFBTSxxQkFBcUIsc0JBQXNCO0FBQ2pELFNBQVMsK0JBQStCO0NBQ3ZDLElBQUk7RUFDSCxPQUFPLEtBQUssTUFBTSxvQkFBb0IsUUFBUSw2QkFBNkIsS0FBSyxJQUFJO0NBQ3JGLFFBQVE7RUFDUCxPQUFPLENBQUM7Q0FDVDtBQUNEO0FBQ0EsSUFBTSx5QkFBeUMsNkNBQTZCO0FBQzVFLElBQU0sK0JBQStCOzs7Ozs7O0FBT3JDLElBQU0sa0NBQWtDLGFBQWE7Q0FDcEQsT0FBTyxTQUFTLE1BQU0sYUFBYSxTQUFTO0FBQzdDO0FBQ0EsU0FBUyw2QkFBNkIsU0FBUztDQUM5QyxNQUFNLFNBQVMsUUFBUSxhQUFhLDRCQUE0QjtDQUNoRSxJQUFJLFFBQVEsT0FBTyxJQUFJLDZCQUE2QixJQUFJLE9BQU87Q0FDL0QsSUFBSSxXQUFXO0NBQ2YsSUFBSSxLQUFLO0NBQ1QsSUFBSTtDQUNKLE9BQU8sU0FBUyxHQUFHLFlBQVk7RUFDOUIsSUFBSSxRQUFRO0VBQ1osSUFBSSxVQUFVO0VBQ2QsT0FBTyxVQUFVLFFBQVEsd0JBQXdCO0VBQ2pELE1BQU0sT0FBTyxHQUFHLEdBQUcsVUFBVSxhQUFhLE1BQU07RUFDaEQsV0FBVyxXQUFXLEdBQUcsS0FBSyxLQUFLLGFBQWE7RUFDaEQsS0FBSztDQUNOO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxpQ0FBaUMsUUFBUSxTQUFTO0NBRTFELE1BQU0sVUFBVSx3QkFESSxRQUFRLFVBQVUsK0JBQUEsQ0FBZ0MsT0FBTyxjQUN0QztDQUN2QyxJQUFJLENBQUMsU0FBUztDQUNkLElBQUksUUFBUSxJQUFJLE9BQU8sUUFBUSxJQUFJLDZCQUE2QixJQUFJLFFBQVEsR0FBRztDQUMvRSxNQUFNLFVBQVUsUUFBUSxhQUFhO0NBQ3JDLElBQUksQ0FBQyxTQUFTO0NBQ2QsT0FBTyxRQUFRLFlBQVksU0FBUyxxQkFBcUIsNkJBQTZCLE9BQU87QUFDOUY7QUFDQSxJQUFJLGVBQWU7QUFDbkIsSUFBTSxxQkFBcUI7QUFDM0IsU0FBUyxXQUFXLFVBQVU7Q0FDN0IsSUFBSTtFQUNILE9BQU8sT0FBTyxhQUFhLGFBQWEsU0FBUyxJQUFJLFNBQVMsY0FBYyxRQUFRO0NBQ3JGLFFBQVEsQ0FBQztBQUNWO0FBQ0EsU0FBUyx1QkFBdUIsc0JBQXNCO0NBQ3JELE1BQU0sMkJBQTJCLElBQUksSUFBSTtDQUN6QyxLQUFLLE1BQU0sWUFBWSxzQkFBc0I7RUFDNUMsSUFBSSxhQUFhLG9CQUFvQjtFQUNyQyxNQUFNLFVBQVUsV0FBVyxRQUFRO0VBQ25DLElBQUksU0FBUyxTQUFTLElBQUksT0FBTztDQUNsQztDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsdUJBQXVCLFFBQVEsT0FBTztDQUM5QyxNQUFNLCtCQUErQixTQUFTLE9BQU8sUUFBUTtDQUM3RCxNQUFNLFNBQVMsT0FBTztDQUN0QixJQUFJLDhCQUE4QixPQUFPLElBQUk7Q0FDN0MsSUFBZ0IsT0FBTyxVQUFVO0NBQ2pDLE1BQU0sU0FBUyxPQUFPLFFBQVEsMkJBQTJCO0NBQ3pELE1BQU0sdUNBQXVDLElBQUksSUFBSTtDQUNyRCxNQUFNLGdDQUFnQyxlQUFlO0VBQ3BELE1BQU0sV0FBVyx1QkFBdUIsZ0JBQWdCLENBQUM7RUFDekQsS0FBSyxNQUFNLFVBQVUsc0JBQXNCLElBQUksV0FBVyxVQUFVLFNBQVMsc0JBQXNCO0dBQ2xHO0dBQ0E7RUFDRDtPQUNLLElBQUksT0FBTyxhQUFhLFNBQVMsNkJBQTZCLE1BQU0sS0FBSztHQUM3RSxTQUFTLE9BQU87R0FDaEIsU0FBUyxPQUFPO0VBQ2pCO0NBQ0Q7Q0FDQSxJQUFJLGdDQUFnQyxDQUFDLE9BQU8sR0FBRztFQUM5QyxPQUFPLElBQUk7RUFDWCxlQUFlO0VBQ2YsUUFBUSxvQkFBb0I7RUFDNUIsU0FBUyxpQkFBaUIsV0FBVyxVQUFVO0dBQzlDLElBQUksY0FBYztHQUNsQixxQkFBcUIsSUFBSSxNQUFNLE1BQU07RUFDdEMsR0FBRyxJQUFJO0VBQ1AsT0FBTyxVQUFVLGlCQUFpQixVQUFVO0dBQzNDLElBQUksTUFBTSxjQUFjLDZCQUE2QixPQUFPLE1BQU0sWUFBWSxDQUFDO0dBQy9FLHFCQUFxQixNQUFNO0VBQzVCLENBQUM7RUFDRCxpQkFBaUIsa0JBQWtCO0dBQ2xDLFFBQVEsb0JBQW9CO0dBQzVCLDZCQUE2QixPQUFPLE9BQU8sT0FBTyxpQkFBaUIsSUFBSSxLQUFLLE9BQU8sT0FBTyxTQUFTLElBQUksQ0FBQyxDQUFDO0dBQ3pHLElBQUk7SUFDSCxvQkFBb0IsUUFBUSxZQUFZLEtBQUssVUFBVSxzQkFBc0IsQ0FBQztHQUMvRSxRQUFRO0lBQ29DLFFBQVEsS0FBSywyRUFBMkU7R0FDcEk7RUFDRCxDQUFDO0VBQ0QsaUJBQWlCLGFBQWEsVUFBVTtHQUN2QyxJQUFJLE1BQU0sV0FBVyxRQUFRLG9CQUFvQjtFQUNsRCxDQUFDO0NBQ0Y7Q0FDQSxJQUFJLE9BQU8sR0FBRztDQUNkLE9BQU8sSUFBSTtDQUNYLE9BQU8sVUFBVSxlQUFlLFVBQVU7RUFDekMsTUFBTSxXQUFXLE9BQU8sUUFBUTtFQUNoQyxNQUFNLHVCQUF1QixPQUFPLFFBQVE7RUFDNUMsTUFBTSxvQkFBb0IsT0FBTztFQUNqQyxNQUFNLGlCQUFpQixPQUFPO0VBQzlCLElBQUk7RUFDSixxQkFBcUIsTUFBTTtFQUMzQixPQUFPLElBQUk7RUFDWCxPQUFPLElBQUk7RUFDWCxJQUFJLE9BQU8sT0FBTyxRQUFRLHNCQUFzQixjQUFjLENBQUMsT0FBTyxRQUFRLGtCQUFrQixFQUFFLFVBQVUsT0FBTyxlQUFlLENBQUMsR0FBRztFQUN0SSxNQUFNLFdBQVcsT0FBTyxNQUFNLFVBQVU7RUFDeEMsTUFBTSxlQUFlLE1BQU0sZ0JBQWdCLE9BQU8sTUFBTSxZQUFZO0VBQ3BFLElBQUksT0FBTyxLQUFLLGdCQUFnQixpQkFBaUIsVUFBVTtHQUMxRCxNQUFNLHFCQUFxQix1QkFBdUI7R0FDbEQsSUFBSSxvQkFBb0I7SUFDdkIsSUFBSSxtQkFBbUIsdUJBQXVCO0lBQzlDLEtBQUssTUFBTSxtQkFBbUIsb0JBQW9CO0tBQ2pELElBQUksb0JBQW9CLG9CQUNuQjtVQUFBLG1CQUFtQjtLQUFBLE9BQ2pCO01BQ04sTUFBTSxVQUFVLFdBQVcsZUFBZTtNQUMxQyxJQUFJLENBQUMsU0FBUztNQUNkLElBQUkscUJBQXFCLHNCQUFzQjtPQUM5Qyx3QkFBd0IsdUJBQXVCLG9CQUFvQjtPQUNuRSxJQUFJLG9CQUFvQixJQUFJLE9BQU8sR0FBRztNQUN2QztLQUNEO0tBQ0EsSUFBSSxDQUFDLGtCQUFrQixtQkFBbUIsdUJBQXVCLFlBQVksQ0FBQztLQUM5RSxpQkFBaUIscUJBQXFCLG1CQUFtQjtJQUMxRDtHQUNEO0VBQ0Q7RUFDQSxlQUFlO0VBQ2YsSUFBSTtHQUNILE1BQU0sT0FBTyxNQUFNLFdBQVc7R0FDOUIsTUFBTSw0QkFBNEIsTUFBTSxXQUFXLE1BQU0sK0JBQStCO0dBQ3hGLElBQUksaUJBQWlCO0dBQ3JCLElBQUksbUJBQW1CO0lBQ3RCLElBQUksQ0FBQyxRQUFRLHNCQUFzQix3QkFBd0IsdUJBQXVCLG9CQUFvQjtJQUN0RyxNQUFNLG9CQUFvQixRQUFRLDZCQUE2QjtJQUMvRCxNQUFNLGlCQUFpQixPQUFPLElBQUksdUJBQXVCLFlBQVksS0FBSztJQUMxRSxJQUFJLGdCQUFnQixLQUFLLE1BQU0sbUJBQW1CLGdCQUFnQjtLQUNqRSxNQUFNLEVBQUUsU0FBUyxZQUFZLGVBQWU7S0FDNUMsSUFBSSxvQkFBb0Isb0JBQW9CO01BQzNDLElBQUksbUJBQW1CO01BQ3ZCLFNBQVM7T0FDUixLQUFLO09BQ0wsTUFBTTtPQUNOO01BQ0QsQ0FBQztNQUNELGlCQUFpQjtLQUNsQixPQUFPO01BQ04sTUFBTSxVQUFVLFdBQVcsZUFBZTtNQUMxQyxJQUFJLFNBQVM7T0FDWixRQUFRLGFBQWE7T0FDckIsUUFBUSxZQUFZO09BQ3BCLHFCQUFxQixPQUFPLE9BQU87TUFDcEM7S0FDRDtJQUNEO0lBQ0EsSUFBSSxDQUFDLE1BQU07S0FDVixNQUFNLGdCQUFnQjtNQUNyQixLQUFLO01BQ0wsTUFBTTtNQUNOO0tBQ0Q7S0FDQSxJQUFJLENBQUMsZ0JBQWdCLFNBQVMsYUFBYTtLQUMzQyxJQUFJLHFCQUFxQixLQUFLLE1BQU0sV0FBVyxxQkFBcUIsUUFBUSxTQUFTLGFBQWE7SUFDbkc7R0FDRDtHQUNBLElBQUksQ0FBQyxrQkFBa0IsUUFBUSwyQkFBMkIsU0FBUyxlQUFlLElBQUksQ0FBQyxFQUFFLGVBQWUseUJBQXlCO0VBQ2xJLFVBQVU7R0FDVCxlQUFlO0VBQ2hCO0NBQ0QsQ0FBQztBQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEtBLFNBQVMsT0FBTyxLQUFLLFlBQVksUUFBUTtDQUN4QyxJQUFJO0NBQ0osS0FBSyxNQUFNLE9BQU8sS0FBSztFQUN0QixNQUFNLE1BQU0sSUFBSTtFQUNoQixJQUFJLFFBQVEsS0FBSyxHQUFHLENBQUMsV0FBVyxJQUFJLGdCQUFnQixFQUFBLENBQUcsSUFBSSxLQUFLLFVBQVUsR0FBRyxDQUFDO0NBQy9FO0NBQ0EsT0FBTyxTQUFTLE9BQU8sU0FBUyxJQUFJO0FBQ3JDOzs7Ozs7Ozs7QUFTQSxTQUFTLFFBQVEsS0FBSztDQUNyQixJQUFJLENBQUMsS0FBSyxPQUFPO0NBQ2pCLElBQUksUUFBUSxTQUFTLE9BQU87Q0FDNUIsSUFBSSxRQUFRLFFBQVEsT0FBTztDQUMzQixPQUFPLENBQUMsTUFBTSxNQUFNLEtBQUssQ0FBQyxNQUFNLE9BQU8sTUFBTSxDQUFDLE1BQU07QUFDckQ7Ozs7Ozs7OztBQVNBLFNBQVMsT0FBTyxLQUFLO0NBQ3BCLE1BQU0sZUFBZSxJQUFJLGdCQUFnQixHQUFHO0NBQzVDLE1BQU0sU0FBUyxPQUFPLE9BQU8sSUFBSTtDQUNqQyxLQUFLLE1BQU0sQ0FBQyxLQUFLLFVBQVUsYUFBYSxRQUFRLEdBQUc7RUFDbEQsTUFBTSxnQkFBZ0IsT0FBTztFQUM3QixJQUFJLGlCQUFpQixNQUFNLE9BQU8sT0FBTyxRQUFRLEtBQUs7T0FDakQsSUFBSSxNQUFNLFFBQVEsYUFBYSxHQUFHLGNBQWMsS0FBSyxRQUFRLEtBQUssQ0FBQztPQUNuRSxPQUFPLE9BQU8sQ0FBQyxlQUFlLFFBQVEsS0FBSyxDQUFDO0NBQ2xEO0NBQ0EsT0FBTztBQUNSOztBQzlEQSxJQUFNLFlBQVk7O0FBRWxCLElBQU0scUJBQXFCLGdCQUFnQixLQUFLLEtBQUs7O0FBRXJELElBQU0seUJBQXlCLG9CQUFvQixLQUFLLFdBQVcsS0FBSyxLQUFLOzs7Ozs7Ozs7OztBQVc3RSxTQUFTLGdCQUFnQixRQUFRO0NBQ2hDLE1BQU0sZUFBZSxXQUFXLEtBQUs7Q0FDckMsUUFBUSxjQUFjO0VBQ3JCLElBQUksVUFBVSxPQUFPLEtBQUssWUFBWSxVQUFVLE1BQU0sQ0FBQztFQUN2RCxNQUFNLFFBQVEsT0FBTyxTQUFTO0VBQzlCLEtBQUssTUFBTSxPQUFPLE9BQU87R0FDeEIsTUFBTSxRQUFRLE1BQU07R0FDcEIsSUFBSSxPQUFPLFVBQVUsVUFBVTtJQUM5QixJQUFJLGdCQUFnQixDQUFDLFVBQVUsS0FBSyxLQUFLLEdBQUc7SUFDNUMsSUFBSTtLQUNILE1BQU0sT0FBTyxPQUFPLEtBQUs7SUFDMUIsU0FBUyxNQUFNLENBQUM7R0FDakI7RUFDRDtFQUNBLE9BQU87Q0FDUjtBQUNEOzs7Ozs7Ozs7Ozs7O0FBYUEsU0FBUyxvQkFBb0IsV0FBVyxRQUFRO0NBQy9DLE1BQU0sZUFBZSxXQUFXLEtBQUs7Q0FDckMsU0FBUyxlQUFlLEtBQUs7RUFDNUIsSUFBSSxPQUFPLE9BQU8sUUFBUSxVQUFVLElBQUk7R0FDdkMsT0FBTyxVQUFVLEdBQUc7RUFDckIsU0FBUyxNQUFNLENBQUM7T0FDWCxJQUFJLFVBQVUsT0FBTyxRQUFRLFVBQVU7R0FDM0MsSUFBSSxnQkFBZ0IsQ0FBQyxVQUFVLEtBQUssR0FBRyxHQUFHLE9BQU87R0FDakQsSUFBSTtJQUNILE9BQU8sR0FBRztJQUNWLE9BQU8sVUFBVSxHQUFHO0dBQ3JCLFNBQVMsTUFBTSxDQUFDO0VBQ2pCO0VBQ0EsT0FBTztDQUNSO0NBQ0EsUUFBUSxXQUFXO0VBQ2xCLE1BQU0sWUFBWSxPQUFPLFFBQVEsY0FBYztFQUMvQyxPQUFPLFlBQVksSUFBSSxjQUFjO0NBQ3RDO0FBQ0Q7OztBQzlEQSxTQUFTLGdCQUFnQixVQUFVO0NBQ2xDLE9BQU87RUFDTixRQUFRLEVBQUUsVUFBVTtHQUNuQixLQUFLLE1BQU0sV0FBVyxVQUFVLE1BQU0sb0JBQW9CLFNBQVMsR0FBRztHQUN0RSxPQUFPO0VBQ1I7RUFDQSxTQUFTLEVBQUUsVUFBVTtHQUNwQixLQUFLLElBQUksSUFBSSxTQUFTLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSyxNQUFNLHFCQUFxQixTQUFTLElBQUksR0FBRztHQUMxRixPQUFPO0VBQ1I7Q0FDRDtBQUNEOztBQUVBLFNBQVMsZ0JBQWdCLFVBQVUsZUFBZSxTQUFTO0NBQzFELE1BQU0sa0JBQWtCLFNBQVMsUUFBUTtDQUN6QyxNQUFNLHFCQUFxQixJQUFJO0NBQy9CLE1BQU0sZ0JBQWdCLGdCQUFnQixxQkFBcUIsbUJBQW1CLFlBQVk7Q0FDMUYsTUFBTSx5QkFBeUIsR0FBRyxjQUFjO0NBQ2hELE1BQU0sa0JBQWtCO0VBQ3ZCLFFBQVEsRUFBRSxVQUFVO0dBQ25CLE1BQU0sV0FBVyxnQkFBZ0IsSUFBSSxXQUFXLElBQUksU0FBUyxZQUFZO0dBQ3pFLElBQUksYUFBYSxlQUFlLElBQUksV0FBVztRQUMxQyxJQUFJLFNBQVMsV0FBVyxzQkFBc0IsR0FBRyxJQUFJLFdBQVcsSUFBSSxTQUFTLE1BQU0sbUJBQW1CLE1BQU07R0FDakgsT0FBTztFQUNSO0VBQ0EsU0FBUyxFQUFFLFVBQVU7R0FDcEIsSUFBSSxXQUFXLFVBQVUsSUFBSSxrQkFBa0IsSUFBSSxVQUFVO0dBQzdELE9BQU87RUFDUjtDQUNEO0NBQ0EsT0FBTyxVQUFVO0VBQ2hCLFFBQVEsRUFBRSxVQUFVLG9CQUFvQixTQUFTLGdCQUFnQixNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUM7RUFDL0UsU0FBUyxFQUFFLFVBQVUsZ0JBQWdCLE9BQU8sRUFBRSxLQUFLLHFCQUFxQixTQUFTLEdBQUcsRUFBRSxDQUFDO0NBQ3hGLElBQUk7QUFDTDs7QUFFQSxTQUFTLG9CQUFvQixTQUFTLEtBQUs7Q0FDMUMsTUFBTSxNQUFNLFNBQVMsUUFBUSxFQUFFLElBQUksQ0FBQztDQUNwQyxJQUFJLEtBQUs7RUFDUixJQUFJLE9BQU8sUUFBUSxVQUFVLE9BQU8sSUFBSSxJQUFJLEdBQUc7T0FDMUMsSUFBSSxlQUFlLEtBQUssT0FBTztDQUNyQztDQUNBLE9BQU87QUFDUjs7QUFFQSxTQUFTLHFCQUFxQixTQUFTLEtBQUs7Q0FDM0MsTUFBTSxNQUFNLFNBQVMsU0FBUyxFQUFFLElBQUksQ0FBQztDQUNyQyxJQUFJLEtBQUs7RUFDUixJQUFJLE9BQU8sUUFBUSxVQUFVLE9BQU8sSUFBSSxJQUFJLEdBQUc7T0FDMUMsSUFBSSxlQUFlLEtBQUssT0FBTztDQUNyQztDQUNBLE9BQU87QUFDUjs7O0FDcERBLFNBQVMsOEJBQThCLGNBQWM7Q0FDcEQsSUFBSSxRQUFRO0NBQ1osT0FBTztFQUNOLE1BQU07R0FDTCxPQUFPO0VBQ1I7RUFDQSxJQUFJLGVBQWU7R0FDbEIsUUFBUSxpQkFBaUIsZUFBZSxLQUFLO0VBQzlDO0NBQ0Q7QUFDRDs7QUFFQSxTQUFTLCtCQUErQixNQUFNO0NBQzdDLE9BQU8sRUFBRSxNQUFNO0VBQ2QsT0FBTyxLQUFLO0NBQ2IsRUFBRTtBQUNIO0FBQ0EsU0FBUyxtQkFBbUIsaUJBQWlCLFFBQVE7Q0FDcEQsTUFBTSxFQUFFLG9CQUFvQixxQkFBcUIsVUFBVTtDQUMzRCxNQUFNLDBCQUEwQixJQUFJLElBQUk7Q0FDeEMsTUFBTSxTQUFTLG1CQUFtQixNQUFNO0NBQ3hDLE1BQU0sV0FBVyxtQkFBbUIsZUFBZTtDQUNuRCxNQUFNLG1CQUFtQixtQkFBbUIsS0FBSyxDQUFDO0NBQ2xELE1BQU0sTUFBTSxtQkFBbUIsQ0FBQyxDQUFDO0NBQ2pDLE1BQU0sVUFBVSwwQkFBMEIsSUFBSSxJQUFJLENBQUMsQ0FBQyxLQUFLLE9BQU8sUUFBUSxJQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDO0NBQ3RGLE1BQU0sVUFBVSwyQkFBMkI7RUFDMUMsUUFBUSxPQUFPLElBQUk7RUFDbkIsV0FBVyxPQUFPLElBQUksTUFBTTtFQUM1QixTQUFTLFFBQVEsSUFBSTtFQUNyQixVQUFVLFNBQVMsSUFBSTtFQUN2QixrQkFBa0IsaUJBQWlCLElBQUk7Q0FDeEMsRUFBRTtDQUNGLFNBQVMsY0FBYyxTQUFTO0VBQy9CLElBQUksYUFBYSxRQUFRLElBQUksT0FBTztFQUNwQyxJQUFJLENBQUMsWUFBWTtHQUNoQixhQUFhLG1CQUFtQixLQUFLLENBQUM7R0FDdEMsUUFBUSxJQUFJLFNBQVMsVUFBVTtFQUNoQztFQUNBLE9BQU87Q0FDUjtDQUNBLE1BQU0sUUFBUTtFQUNiO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNEO0NBQ0EsU0FBUyxXQUFXLGFBQWE7RUFDaEMsTUFBTSxjQUFjLElBQUksSUFBSTtFQUM1QixNQUFNLFVBQVUsWUFBWSxLQUFLLFVBQVUsTUFBTSxPQUFPO0VBQ3hELFlBQVk7R0FDWCxJQUFJLENBQUMsWUFBWSxhQUFhLE9BQU8sR0FBRyxJQUFJLElBQUksT0FBTztHQUN2RCxLQUFLLE1BQU0sTUFBTSxhQUFhLElBQUksQ0FBQyxRQUFRLFNBQVMsRUFBRSxHQUFHLFFBQVEsSUFBSSxFQUFFLENBQUMsQ0FBQyxVQUFVLEtBQUssQ0FBQztHQUN6RixLQUFLLE1BQU0sYUFBYSxhQUFhO0lBQ3BDLE1BQU0sYUFBYSxjQUFjLFVBQVUsT0FBTztJQUNsRCxJQUFJLFdBQVcsSUFBSSxNQUFNLFdBQVcsV0FBVyxJQUFJLFNBQVM7R0FDN0Q7RUFDRCxDQUFDO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1I7O0FDbEVBLElBQUksZ0JBQWdCO0FBQ3BCLElBQUksZ0JBQWdCO0FBQ3BCLElBQUksb0JBQW9COzs7Ozs7Ozs7O0FBVXhCLElBQUkseUJBQXlCO0FBQzdCLFNBQVMsMEJBQTBCLEtBQUs7Q0FDdkMsTUFBTSxRQUFRLHVCQUF1QixLQUFLLEdBQUc7Q0FDN0MsT0FBTyxRQUFRLE1BQU0sSUFBSSxNQUFNLE1BQU0sRUFBRSxDQUFDLE1BQU0sSUFBSTtBQUNuRDtBQUNBLFNBQVMsY0FBYyxNQUFNO0NBQzVCLElBQUksa0JBQWtCLEtBQUssSUFBSSxHQUFHLE9BQU8sS0FBSyxRQUFRLHFCQUFxQixjQUFjLFFBQVEsU0FBUyxTQUFTLElBQUksS0FBSyxtQkFBbUIsU0FBUyxDQUFDO0NBQ3pKLE9BQU8sMEJBQTBCLElBQUk7QUFDdEM7QUFDQSxTQUFTLGNBQWMsTUFBTTtDQUM1QixJQUFJLFdBQVcsS0FBSyxZQUFZO0NBQ2hDLE1BQU0sOEJBQThCLElBQUksSUFBSTtDQUM1QyxNQUFNLFVBQVUsV0FBVztFQUMxQixXQUFXLEtBQUssWUFBWTtFQUM1QixZQUFZLFNBQVMsZUFBZSxXQUFXO0dBQzlDO0dBQ0E7RUFDRCxDQUFDLENBQUM7Q0FDSDtDQUNBLE1BQU0scUJBQXFCLFdBQVc7RUFDckMsSUFBSSxLQUFLLHVCQUF1QixNQUFNLE9BQU8sTUFBTTtPQUM5QyxXQUFXLEtBQUssWUFBWTtDQUNsQztDQUNBLE1BQU0sZ0JBQWdCLE9BQU8sU0FBUztFQUNyQyxNQUFNLFdBQVcsS0FBSyxjQUFjLGdCQUFnQixLQUFLLElBQUksS0FBSyxjQUFjO0VBQ2hGLElBQUksT0FBTyxhQUFhLGVBQWUsVUFBVSxXQUFXLEtBQUssU0FBUyxVQUFVLEtBQUssU0FBUyxZQUFZLEtBQUssTUFBTSxXQUFXLFVBQVU7R0FDN0ksTUFBTSxlQUFlLFVBQVUsS0FBSyxNQUFNLEtBQUssS0FBSztHQUNwRCxJQUFJLE1BQU0sUUFBUSxVQUFVO0lBQzNCLGlCQUFpQjtJQUNqQjtJQUNBLFFBQVEsS0FBSztHQUNkLENBQUMsR0FBRztJQUNILEtBQUssWUFBWTtJQUNqQjtHQUNEO0VBQ0Q7RUFDQSxLQUFLLEtBQUs7Q0FDWDtDQUNBLE9BQU87RUFDTixJQUFJLFdBQVc7R0FDZCxPQUFPO0VBQ1I7RUFDQSxJQUFJLFNBQVM7R0FDWixPQUFPLEtBQUssVUFBVTtFQUN2QjtFQUNBO0VBQ0EsWUFBWSxPQUFPO0dBQ2xCLFlBQVksSUFBSSxFQUFFO0dBQ2xCLGFBQWE7SUFDWixZQUFZLE9BQU8sRUFBRTtHQUN0QjtFQUNEO0VBQ0EsT0FBTyxNQUFNLE9BQU8saUJBQWlCO0dBQ3BDLE1BQU0sZUFBZSxTQUFTLE1BQU07R0FDcEMsUUFBUSxrQkFBa0IsZUFBZSxHQUFHLEtBQUs7R0FDakQsY0FBYztJQUNiLFlBQVk7S0FDWCxLQUFLLFVBQVUsTUFBTSxLQUFLO0tBQzFCLE9BQU8sRUFBRSxNQUFNLE9BQU8sQ0FBQztJQUN4QjtJQUNBO0lBQ0EsTUFBTTtJQUNOO0lBQ0E7R0FDRCxDQUFDO0VBQ0Y7RUFDQSxVQUFVLE1BQU0sT0FBTyxpQkFBaUI7R0FDdkMsTUFBTSxlQUFlLFNBQVMsTUFBTTtHQUNwQyxRQUFRLGtCQUFrQixjQUFjLEtBQUs7R0FDN0MsY0FBYztJQUNiLFlBQVk7S0FDWCxLQUFLLGFBQWEsTUFBTSxLQUFLO0tBQzdCLE9BQU8sRUFBRSxNQUFNLFVBQVUsQ0FBQztJQUMzQjtJQUNBO0lBQ0EsTUFBTTtJQUNOO0lBQ0E7R0FDRCxDQUFDO0VBQ0Y7RUFDQSxLQUFLLE9BQU8saUJBQWlCO0dBQzVCLGNBQWM7SUFDYixZQUFZO0tBQ1gsS0FBSyxHQUFHLE9BQU8sY0FBYyxpQkFBaUIsS0FBSztLQUNuRCxrQkFBa0I7TUFDakIsTUFBTTtNQUNOO0tBQ0QsQ0FBQztJQUNGO0lBQ0E7SUFDQSxNQUFNO0dBQ1AsQ0FBQztFQUNGO0VBQ0EsT0FBTyxpQkFBaUI7R0FDdkIsY0FBYztJQUNiLFlBQVk7S0FDWCxLQUFLLEtBQUssY0FBYyxpQkFBaUIsS0FBSztLQUM5QyxrQkFBa0IsRUFBRSxNQUFNLE9BQU8sQ0FBQztJQUNuQztJQUNBO0lBQ0EsTUFBTTtHQUNQLENBQUM7RUFDRjtFQUNBLFVBQVUsaUJBQWlCO0dBQzFCLGNBQWM7SUFDYixZQUFZO0tBQ1gsS0FBSyxRQUFRLGNBQWMsaUJBQWlCLEtBQUs7S0FDakQsa0JBQWtCLEVBQUUsTUFBTSxVQUFVLENBQUM7SUFDdEM7SUFDQTtJQUNBLE1BQU07R0FDUCxDQUFDO0VBQ0Y7RUFDQSxpQkFBaUIsU0FBUyxNQUFNLG1CQUFtQjtFQUNuRCxhQUFhLFFBQVEsS0FBSyxXQUFXLEdBQUc7RUFDeEMsUUFBUSxZQUFZO0dBQ25CLElBQUksQ0FBQyxLQUFLLGFBQWEsYUFBYSxDQUFDO0dBQ3JDLE1BQU0sV0FBVyxLQUFLLGNBQWMsS0FBSyxDQUFDO0dBQzFDLEtBQUssWUFBWSxDQUFDLEdBQUcsVUFBVSxPQUFPLENBQUM7R0FDdkMsYUFBYTtJQUNaLE1BQU0sV0FBVyxLQUFLLGNBQWMsS0FBSyxDQUFDO0lBQzFDLEtBQUssY0FBYyxTQUFTLFFBQVEsTUFBTSxNQUFNLE9BQU8sQ0FBQztHQUN6RDtFQUNEO0VBQ0EsYUFBYSxLQUFLLFFBQVE7RUFDMUIsZUFBZSxLQUFLLFVBQVU7RUFDOUI7RUFDQSxvQkFBb0IsS0FBSyxjQUFjLEtBQUssQ0FBQztDQUM5QztBQUNEO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTyxPQUFPO0NBQ3hDLE1BQU0sTUFBTSxnQkFBZ0I7Q0FDNUIsT0FBTztFQUNOLEdBQUc7RUFDSDtFQUNBLFdBQVc7R0FDVixnQkFBZ0I7Q0FDbEI7QUFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQkEsU0FBUyxxQkFBcUIsTUFBTTtDQUNuQyxNQUFNLE1BQU0sTUFBTSxXQUFXLE9BQU8sYUFBYSxjQUFjLFNBQVMsS0FBSztDQUM3RSxNQUFNLG9CQUFvQixJQUFJLFFBQVE7Q0FDdEMsTUFBTSx1QkFBdUIsSUFBSSxRQUFRO0NBQ3pDLElBQUksV0FBVyxDQUFDO0NBQ2hCLE1BQU0scUJBQXFCO0NBQzNCLE1BQU0sZ0JBQWdCLGdCQUFnQixXQUFXO0NBQ2pELE1BQU0sY0FBYyxTQUFTLGNBQWMsTUFBTSxhQUFhLEtBQUssV0FBVyxJQUFJLElBQUksSUFBSTtDQUMxRixNQUFNLGdCQUFnQixNQUFNLHdCQUF3QixVQUFVLEdBQUcsSUFBSSxTQUFTLFdBQVcsSUFBSSxTQUFTLFNBQVMsSUFBSSxTQUFTLFFBQVEsSUFBSSxRQUFRLEtBQUs7Q0FDckosSUFBSSxDQUFDLElBQUksUUFBUSxPQUFPLGFBQWEsQ0FBQyxJQUFJLFFBQVEsT0FBTyxLQUFLO0VBQzdELE1BQU0sV0FBVyxnQkFBZ0I7RUFDakMsSUFBSSxRQUFRLGFBQWE7SUFDdkIsZ0JBQWdCO0dBQ2pCLEtBQUs7R0FDTCxXQUFXO0VBQ1osR0FBRyxFQUFFO0NBQ047Q0FDQSxJQUFJLGtCQUFrQixjQUFjO0NBQ3BDLElBQUk7Q0FDSixJQUFJLGNBQWM7Q0FDbEIsSUFBSSxnQkFBZ0I7Q0FDcEIsSUFBSSxxQkFBcUI7Q0FDekIsSUFBSSx5QkFBeUI7Q0FDN0IsTUFBTSxvQkFBb0I7Q0FDMUIsSUFBSTtDQUNKLE1BQU0sY0FBYztFQUNuQixJQUFJLENBQUMsTUFBTTtFQUNYLFFBQVEscUJBQXFCO0VBQzdCLENBQUMsS0FBSyxLQUFLLElBQUksUUFBUSxZQUFZLElBQUksUUFBUSxhQUFBLENBQWMsS0FBSyxJQUFJLElBQUksS0FBSyxFQUFFO0VBQ2pGLFFBQVEscUJBQXFCO0VBQzdCLE9BQU8sS0FBSztFQUNaLG1CQUFtQixLQUFLO0NBQ3pCO0NBQ0EsTUFBTSxzQkFBc0IsUUFBUSxVQUFVLFVBQVU7RUFDdkQsTUFBTSxPQUFPLE1BQU0sYUFBYSxXQUFXLFFBQVEsSUFBSSxLQUFLO0VBQzVELE1BQU0sbUJBQW1CLENBQUMsQ0FBQztFQUMzQixJQUFJLENBQUMsa0JBQWtCLG1CQUFtQjtFQUMxQyxrQkFBa0IsVUFBVSxVQUFVLEtBQUs7RUFDM0MsT0FBTztHQUNOLFFBQVEsZ0JBQWdCO0dBQ3hCO0dBQ0EsT0FBTyxNQUFNO0VBQ2Q7RUFDQSxJQUFJLENBQUMsa0JBQWtCLHFCQUFxQixNQUFNLENBQUM7Q0FDcEQ7Q0FDQSxNQUFNLGFBQWEsU0FBUztFQUMzQixrQkFBa0IsY0FBYztFQUNoQyxRQUFRLE9BQU8sRUFBRSxLQUFLLENBQUM7Q0FDeEI7Q0FDQSxNQUFNLGlCQUFpQixZQUFZO0VBQ2xDLHlCQUF5QjtFQUN6QixJQUFJLGVBQWU7R0FDbEIsZ0JBQWdCO0dBQ2hCO0VBQ0Q7RUFDQSxNQUFNLGVBQWUsY0FBYztFQUNuQyxNQUFNLFFBQVEsYUFBYSxNQUFNLGlCQUFpQixnQkFBZ0IsTUFBTTtFQUN4RSxNQUFNLFlBQVksVUFBVTtFQUM1QixNQUFNLFNBQVMsVUFBVTtFQUN6QixNQUFNLE9BQU8sQ0FBQyxhQUFhLENBQUMsVUFBVTtFQUN0QyxjQUFjO0VBQ2QsTUFBTSxTQUFTLE9BQU8sT0FBTyxTQUFTLFNBQVM7RUFDL0MsTUFBTSxTQUFTLE9BQU87R0FDckIsTUFBTTtHQUNOLE9BQU87RUFDUixJQUFJLEVBQUUsTUFBTSxTQUFTLFNBQVMsVUFBVTtFQUN4QyxJQUFJLG9CQUFvQixxQkFBcUI7T0FDeEM7R0FDSixNQUFNLFdBQVcsYUFBYTtHQUM5QixJQUFJLE9BQU8sYUFBYSxlQUFlLFNBQVMsUUFDMUM7U0FBQSxNQUFNLFdBQVcsVUFBVSxJQUFJLE1BQU0sUUFBUSxVQUFVO0tBQzNEO0tBQ0E7S0FDQTtJQUNELENBQUMsR0FBRztLQUNILGdCQUFnQjtLQUNoQixJQUFJLFFBQVEsR0FBRyxDQUFDLEtBQUs7S0FDckIsUUFBUSxPQUFPLE1BQU07S0FDckI7SUFDRDs7RUFFRjtFQUNBLGtCQUFrQixjQUFjO0VBQ2hDLFFBQVEsT0FBTyxNQUFNO0NBQ3RCO0NBQ0EsTUFBTSxrQkFBa0IsTUFBTTtFQUM3QixJQUFJLHdCQUF3QjtHQUMzQix5QkFBeUI7R0FDekI7RUFDRDtFQUNBLElBQUksY0FBYztFQUNsQixNQUFNLFdBQVcsYUFBYTtFQUM5QixJQUFJLE9BQU8sYUFBYSxlQUFlLFNBQVMsUUFBUSxLQUFLLE1BQU0sV0FBVyxVQUFVO0dBQ3ZGLE1BQU0seUJBQXlCLFFBQVEsc0JBQXNCO0dBQzdELElBQUksMkJBQTJCLE1BQU07SUFDcEMsY0FBYztJQUNkO0dBQ0Q7R0FDQSxJQUFJLE9BQU8sMkJBQTJCLGNBQWMsdUJBQXVCLE1BQU0sTUFBTTtJQUN0RixjQUFjO0lBQ2Q7R0FDRDtFQUNEO0VBQ0EsSUFBSSxhQUFhO0dBQ2hCLEVBQUUsZUFBZTtHQUNqQixPQUFPLEVBQUUsY0FBYztFQUN4QjtDQUNEO0NBQ0EsTUFBTSxVQUFVLGNBQWM7RUFDN0I7RUFDQSxpQkFBaUIsSUFBSSxRQUFRO0VBQzdCLFlBQVksTUFBTSxVQUFVLG1CQUFtQixNQUFNLE1BQU0sS0FBSztFQUNoRSxlQUFlLE1BQU0sVUFBVSxtQkFBbUIsT0FBTyxNQUFNLEtBQUs7RUFDcEUsT0FBTyxrQkFBa0I7R0FDeEIsSUFBSSxlQUFlO0lBQ2xCLHFCQUFxQjtJQUNyQix5QkFBeUI7R0FDMUI7R0FDQSxPQUFPLElBQUksUUFBUSxLQUFLO0VBQ3pCO0VBQ0EsVUFBVSxrQkFBa0I7R0FDM0IsSUFBSSxlQUFlO0lBQ2xCLHFCQUFxQjtJQUNyQix5QkFBeUI7R0FDMUI7R0FDQSxJQUFJLFFBQVEsUUFBUTtFQUNyQjtFQUNBLEtBQUssR0FBRyxrQkFBa0I7R0FDekIsY0FBYztHQUNkLElBQUksZUFBZTtJQUNsQixxQkFBcUI7SUFDckIseUJBQXlCO0dBQzFCO0dBQ0EsSUFBSSxRQUFRLEdBQUcsQ0FBQztFQUNqQjtFQUNBO0VBQ0E7RUFDQSxlQUFlO0dBQ2QsSUFBSSxRQUFRLFlBQVk7R0FDeEIsSUFBSSxRQUFRLGVBQWU7R0FDM0IsSUFBSSxvQkFBb0IsbUJBQW1CLGdCQUFnQixFQUFFLFNBQVMsS0FBSyxDQUFDO0dBQzVFLElBQUksb0JBQW9CLGVBQWUsY0FBYztFQUN0RDtFQUNBLGlCQUFpQjtHQUNoQixJQUFJLG9CQUFvQixvQkFBb0Isa0JBQWtCLGtCQUFrQjtFQUNqRjtFQUNBLGFBQWE7RUFDYixhQUFhO0VBQ2IscUJBQXFCO0NBQ3RCLENBQUM7Q0FDRCxRQUFRLDJCQUEyQixTQUFTO0VBQzNDLHlCQUF5QjtFQUN6QixJQUFJO0dBQ0gsT0FBTyxJQUFJLElBQUksTUFBTSxJQUFJLFNBQVMsT0FBTyxDQUFDLENBQUM7R0FDM0MseUJBQXlCLFdBQVcsS0FBSyxJQUFJLE1BQU0sQ0FBQyxLQUFLLFNBQVMsR0FBRyxLQUFLLEtBQUssTUFBTSxHQUFHLENBQUMsQ0FBQyxPQUFPLElBQUksU0FBUyxLQUFLLE1BQU0sR0FBRyxDQUFDLENBQUM7RUFDL0gsUUFBUSxDQUFDO0NBQ1Y7Q0FDQSxJQUFJLGlCQUFpQixtQkFBbUIsZ0JBQWdCLEVBQUUsU0FBUyxLQUFLLENBQUM7Q0FDekUsSUFBSSxpQkFBaUIsZUFBZSxjQUFjO0NBQ2xELElBQUksUUFBUSxZQUFZLFNBQVMsR0FBRyxNQUFNO0VBQ3pDLE1BQU0sTUFBTSxrQkFBa0IsTUFBTSxJQUFJLFNBQVMsSUFBSTtFQUNyRCxJQUFJLENBQUMsUUFBUSxvQkFBb0IsVUFBVSxNQUFNO0VBQ2pELE9BQU87Q0FDUjtDQUNBLElBQUksUUFBUSxlQUFlLFNBQVMsR0FBRyxNQUFNO0VBQzVDLE1BQU0sTUFBTSxxQkFBcUIsTUFBTSxJQUFJLFNBQVMsSUFBSTtFQUN4RCxJQUFJLENBQUMsUUFBUSxvQkFBb0IsVUFBVSxTQUFTO0VBQ3BELE9BQU87Q0FDUjtDQUNBLE9BQU87QUFDUjs7Ozs7O0FBTUEsU0FBUyxrQkFBa0IsTUFBTTtDQUNoQyxNQUFNLE1BQU0sTUFBTSxXQUFXLE9BQU8sYUFBYSxjQUFjLFNBQVMsS0FBSztDQUM3RSxPQUFPLHFCQUFxQjtFQUMzQixRQUFRO0VBQ1IscUJBQXFCO0dBQ3BCLE1BQU0sT0FBTyxJQUFJLFNBQVM7R0FDMUIsSUFBSSxZQUFZLEtBQUssUUFBUSxLQUFLLENBQUM7R0FDbkMsSUFBSSxZQUFZLEdBQUcsWUFBWSxLQUFLO0dBQ3BDLE9BQU8sVUFBVSxHQUFHLE9BQU8sS0FBSyxNQUFNLEdBQUcsU0FBUyxJQUFJLE1BQU0sSUFBSSxTQUFTLFNBQVMsS0FBSyxNQUFNLFNBQVMsS0FBSyxJQUFJLFFBQVEsS0FBSztFQUM3SDtFQUNBLGFBQWEsU0FBUyxHQUFHLElBQUksU0FBUyxXQUFXLElBQUksU0FBUyxPQUFPLEdBQUc7Q0FDekUsQ0FBQztBQUNGOzs7Ozs7QUFNQSxTQUFTLG9CQUFvQixPQUFPLEVBQUUsZ0JBQWdCLENBQUMsR0FBRyxFQUFFLEdBQUc7Q0FDOUQsTUFBTSxVQUFVLEtBQUs7Q0FDckIsSUFBSSxRQUFRLEtBQUssZUFBZSxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssY0FBYyxDQUFDLEdBQUcsUUFBUSxTQUFTLENBQUMsSUFBSSxRQUFRLFNBQVM7Q0FDaEgsTUFBTSxTQUFTLFFBQVEsS0FBSyxRQUFRLFVBQVUsa0JBQWtCLE9BQU8sS0FBSyxDQUFDLENBQUM7Q0FDOUUsTUFBTSxvQkFBb0IsVUFBVSxRQUFRLFFBQVEsT0FBTyxNQUFNO0NBQ2pFLElBQUksV0FBVyxDQUFDO0NBQ2hCLE1BQU0scUJBQXFCO0NBQzNCLE1BQU0sZ0JBQWdCLGdCQUFnQixXQUFXO0NBQ2pELE9BQU8sY0FBYztFQUNwQjtFQUNBLGlCQUFpQixRQUFRO0VBQ3pCLFlBQVksTUFBTSxVQUFVO0dBQzNCLFFBQVEsUUFBUSxRQUFRLFNBQVMsSUFBSSxRQUFRLElBQUksUUFBUTtHQUN6RCxPQUFPLFNBQVM7R0FDaEIsUUFBUSxTQUFTO0dBQ2pCLElBQUksUUFBUSxRQUFRLFNBQVMsR0FBRztJQUMvQixRQUFRLFNBQVMsUUFBUTtJQUN6QixPQUFPLFNBQVMsUUFBUTtHQUN6QjtFQUNEO0VBQ0EsZUFBZSxNQUFNLFVBQVU7R0FDOUIsT0FBTyxTQUFTO0dBQ2hCLFFBQVEsU0FBUztFQUNsQjtFQUNBLFlBQVk7R0FDWCxRQUFRLEtBQUssSUFBSSxRQUFRLEdBQUcsQ0FBQztFQUM5QjtFQUNBLGVBQWU7R0FDZCxRQUFRLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxTQUFTLENBQUM7RUFDL0M7RUFDQSxLQUFLLE1BQU07R0FDVixRQUFRLEtBQUssSUFBSSxLQUFLLElBQUksUUFBUSxHQUFHLENBQUMsR0FBRyxRQUFRLFNBQVMsQ0FBQztFQUM1RDtFQUNBLFlBQVk7RUFDWixhQUFhO0VBQ2IsYUFBYTtDQUNkLENBQUM7QUFDRjtBQXdDQSxTQUFTLFVBQVUsTUFBTSxPQUFPO0NBQy9CLE1BQU0sZ0JBQWdCLGNBQWMsSUFBSTtDQUN4QyxNQUFNLFlBQVksY0FBYyxRQUFRLEdBQUc7Q0FDM0MsTUFBTSxjQUFjLGNBQWMsUUFBUSxHQUFHO0NBQzdDLElBQUksQ0FBQyxPQUFPO0VBQ1gsTUFBTSxNQUFNLGdCQUFnQjtFQUM1QixRQUFRO0lBQ04sZ0JBQWdCO0dBQ2pCO0dBQ0EsV0FBVztFQUNaO0NBQ0Q7Q0FDQSxPQUFPO0VBQ04sTUFBTTtFQUNOLFVBQVUsY0FBYyxNQUFNLEdBQUcsWUFBWSxLQUFLLGNBQWMsS0FBSyxLQUFLLElBQUksV0FBVyxXQUFXLElBQUksWUFBWSxjQUFjLEtBQUssY0FBYyxjQUFjLE1BQU07RUFDekssTUFBTSxZQUFZLEtBQUssY0FBYyxNQUFNLFNBQVMsSUFBSTtFQUN4RCxRQUFRLGNBQWMsS0FBSyxjQUFjLE1BQU0sYUFBYSxjQUFjLEtBQUssS0FBSyxJQUFJLFNBQVMsSUFBSTtFQUNyRztDQUNEO0FBQ0Q7QUFDQSxTQUFTLGtCQUFrQjtDQUMxQixRQUFRLEtBQUssT0FBTyxJQUFJLEVBQUEsQ0FBRyxTQUFTLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQztBQUNoRDs7QUM5YkEsU0FBUyxjQUFjLEtBQUssUUFBUTtDQUNuQyxPQUFPLElBQUksYUFBYSxXQUFXLElBQUksYUFBYSxZQUFZLElBQUksV0FBVyxVQUFVLENBQUMsQ0FBQyxJQUFJLFlBQVksQ0FBQyxDQUFDLElBQUk7QUFDbEg7QUFDQSxTQUFTLFdBQVcsS0FBSztDQUN4QixPQUFPLElBQUksV0FBVyxJQUFJLFNBQVMsSUFBSTtBQUN4QztBQUNBLFNBQVMsZUFBZSxPQUFPO0NBQzlCLE9BQU8sTUFBTSxRQUFRLFVBQVUsTUFBTSxRQUFRLGNBQWMsTUFBTSxVQUFVLE1BQU0sUUFBUSxXQUFXLFdBQVcsTUFBTSxRQUFRLGtCQUFrQjtBQUNoSjs7Ozs7QUFLQSxTQUFTLHNCQUFzQixLQUFLO0NBQ25DLElBQUksZUFBZSxPQUFPO0VBQ3pCLE1BQU0sTUFBTTtHQUNYLE1BQU0sSUFBSTtHQUNWLFNBQVMsSUFBSTtFQUNkO0VBQzRDLElBQUksUUFBUSxJQUFJO0VBQzVELE9BQU87Q0FDUjtDQUNBLE9BQU8sRUFBRSxNQUFNLElBQUk7QUFDcEI7Ozs7O0FBV0EsU0FBUyxzQkFBc0IsVUFBVSxrQkFBa0I7Q0FDMUQsT0FBTztFQUNOLGNBQWM7RUFDZCxZQUFZO0VBQ1osYUFBYSxrQkFBa0IsYUFBYSxTQUFTO0VBQ3JELGFBQWEsa0JBQWtCLFNBQVMsU0FBUztFQUNqRCxhQUFhLGtCQUFrQixTQUFTLFNBQVM7Q0FDbEQ7QUFDRDs7Ozs7O0FBTUEsU0FBUyxxQkFBcUIsRUFBRSxLQUFLLE1BQU0sV0FBVyxTQUFTLGFBQWEsV0FBVyw2QkFBNkIsYUFBYSxHQUFHLFNBQVM7Q0FDNUksT0FBTztBQUNSO0FBQ0EsU0FBUyxhQUFhLFNBQVM7Q0FDOUIsT0FBTyxRQUFRLFdBQVcsVUFBVSxNQUFNLFdBQVcsV0FBVyxNQUFNLFdBQVcsY0FBYyxNQUFNLFNBQVMsSUFBSTtBQUNuSDs7QUFFQSxTQUFTLGtCQUFrQixRQUFRLFVBQVUsU0FBUyxhQUFhLFNBQVMsT0FBTztDQUNsRixJQUFJLGFBQWEsV0FBVyxTQUFTLE1BQU0sR0FBRyxXQUFXO0NBQ3pELElBQUksU0FBUyxVQUFVLFFBQVEsTUFBTSxHQUFHLE9BQU87Q0FDL0MsS0FBSyxNQUFNLFNBQVMsVUFBVTtFQUM3QixJQUFJLFNBQVMsT0FBTyxRQUFRLE9BQU87RUFDbkMsSUFBSSxDQUFDLFFBQVEsTUFBTSxjQUFjLFVBQVUsWUFBWSxNQUFNLE9BQU8sR0FBRyxPQUFPLFdBQVcsTUFBTSxRQUFRLENBQUMsUUFBUSxVQUFVLEtBQUs7Q0FDaEk7Q0FDQSxLQUFLLE1BQU0sU0FBUyxTQUFTO0VBQzVCLElBQUksU0FBUyxPQUFPLFFBQVEsT0FBTztFQUNuQyxPQUFPLFdBQVcsTUFBTSxRQUFRLENBQUMsUUFBUSxTQUFTLE1BQU0sY0FBYyxVQUFVLFlBQVksTUFBTSxPQUFPLElBQUksV0FBVyxVQUFVLEdBQUcsS0FBSztDQUMzSTtBQUNEOzs7Ozs7Ozs7O0FBVUEsSUFBSSxhQUFhLE1BQU07Ozs7Q0FJdEIsWUFBWSxTQUFTLGdCQUFnQjtFQUNwQyxLQUFLLGtCQUFrQixHQUFHLEtBQUssTUFBTSxLQUFLLE9BQU8sSUFBSSxHQUFHO0VBQ3hELEtBQUssVUFBVSxFQUFFLEdBQUcsS0FBSztFQUN6QixLQUFLLDhCQUE4QixJQUFJLElBQUk7RUFDM0MsS0FBSyx5QkFBeUIsSUFBSSxJQUFJO0VBQ3RDLEtBQUssYUFBYSxDQUFDO0VBQ25CLEtBQUssa0JBQWtCLE9BQU8sT0FBTztHQUNwQyxHQUFHO0dBQ0gsT0FBTztFQUNSO0VBQ0EsS0FBSyxVQUFVLGVBQWU7R0FFNUIsSUFBSSxXQUFXLGVBQWUsUUFBUSxLQUFLLCtNQUErTTtHQUUzUCxNQUFNLGNBQWMsS0FBSztHQUN6QixLQUFLLFVBQVU7SUFDZCxHQUFHO0lBQ0gsR0FBRztHQUNKO0dBQ0EsS0FBSyxXQUFXLEtBQUssUUFBUSxZQUFBLEtBQUEsS0FBd0IsT0FBTyxhQUFhO0dBQ3pFLElBQUksQ0FBYyxLQUFLLFVBQVcsS0FBSyxrQ0FBa0MsSUFBSSxRQUFRO0dBQ3JGLEtBQUssb0JBQW9CLElBQUksSUFBSSxLQUFLLFFBQVEsaUJBQWlCO0dBQy9ELElBQUksQ0FBQyxLQUFLLFdBQVcsS0FBSyxRQUFRLFdBQVcsS0FBSyxRQUFRLFlBQVksS0FBSyxTQUFTO0lBQ25GLElBQUksQ0FBQyxLQUFLLFFBQVEsU0FDYjtTQUFBLENBQWMsS0FBSyxVQUFXLEtBQUssVUFBVSxxQkFBcUI7SUFBQSxPQUNoRSxLQUFLLFVBQVUsS0FBSyxRQUFRO0dBQ3BDO0dBQ0EsS0FBSyxTQUFTLEtBQUssUUFBUTtHQUMzQixJQUFJLENBQUMsS0FBSyxRQUFRO0lBQ2pCLElBQUksQ0FBYyxLQUFLLFlBQWEsUUFBUSxVQUFVLE9BQU8sV0FBVyxRQUFRLEtBQUssU0FBUyxPQUFPO1NBQ2hHLEtBQUssU0FBUztHQUNwQjtHQUNBLE1BQU0sZUFBZSxLQUFLLFFBQVEsWUFBWTtHQUM5QyxNQUFNLG9CQUFvQixLQUFLLFFBQVE7R0FDdkMsTUFBTSxpQkFBaUIsS0FBSyxhQUFhLGdCQUFnQixhQUFhLFlBQVkscUJBQXFCLGFBQWEsa0JBQWtCLEtBQUssUUFBUTtHQUNuSixJQUFJLGdCQUFnQjtJQUNuQixLQUFLLFdBQVc7SUFDaEIsS0FBSyxVQUFVLGlCQUFpQixPQUFPLFNBQVMsWUFBWSxJQUFJLGdCQUFnQixjQUFjLEtBQUssUUFBUSxlQUFlLGlCQUFpQixJQUFJO0dBQ2hKO0dBQ0EsSUFBSSxLQUFLLFNBQVMsS0FBSyxxQkFBcUI7R0FDNUMsSUFBSSxLQUFLLFFBQVEsY0FBYyxLQUFLLGFBQTBCLEtBQUssWUFBYSxhQUFhLGtCQUFrQixLQUFLLFFBQVEsZUFBZTtJQUMxSSxLQUFLLFlBQVksS0FBSyxRQUFRO0lBQzlCLElBQUk7SUFHSCx5QkFBeUIsS0FBSyxlQUFlO0lBTzlDLEtBQUssVUFBVSxzQkFBc0I7R0FDdEM7R0FDQSxJQUFJLENBQUMsS0FBSyxRQUNMO1FBQUEsS0FBSyxnQkFBZ0I7S0FDeEIsTUFBTSxTQUFTLEtBQUssZUFBZSxJQUFJO0tBQ3ZDLEtBQUssUUFBUSxPQUFPO0tBQ3BCLEtBQUssU0FBUyxtQkFBbUIsS0FBSyxnQkFBZ0IsTUFBTTtLQUM1RCxJQUFJLENBQWMsS0FBSyxVQUFXLHVCQUF1QixJQUFJO0lBQzlEO1VBQ00sSUFBSSxnQkFBZ0IsS0FBSyxPQUFPLFNBQVMsSUFBSSxLQUFLLGNBQWM7RUFDeEU7RUFDQSxLQUFLLDZCQUE2QjtHQUNqQyxLQUFLLGlCQUFpQixLQUFLLGNBQWMsS0FBSyxRQUFRLFVBQVUsS0FBSyxjQUFjO0VBQ3BGO0VBQ0EsS0FBSyx1QkFBdUI7R0FDM0IsTUFBTSxTQUFTLGlCQUFpQixLQUFLLFdBQVcsS0FBSyxRQUFRLGFBQWE7R0FDMUUsSUFBSSxLQUFLLFFBQVEsWUFBWSxrQkFBa0IsS0FBSyxRQUFRLFlBQVksT0FBTyxhQUFhO0dBQzVGLE9BQU87SUFDTixHQUFHO0lBQ0gsa0JBQWtCLGlCQUFpQixHQUFHO0dBQ3ZDO0VBQ0Q7RUFDQSxLQUFLLGFBQWEsV0FBVyxPQUFPO0dBQ25DLE1BQU0sV0FBVztJQUNoQjtJQUNBO0dBQ0Q7R0FDQSxLQUFLLFlBQVksSUFBSSxRQUFRO0dBQzdCLGFBQWE7SUFDWixLQUFLLFlBQVksT0FBTyxRQUFRO0dBQ2pDO0VBQ0Q7RUFDQSxLQUFLLFFBQVEsZ0JBQWdCO0dBQzVCLEtBQUssTUFBTSxZQUFZLEtBQUssYUFBYSxJQUFJLFNBQVMsY0FBYyxZQUFZLE1BQU0sSUFBSTtJQUN6RixTQUFTLEdBQUcsV0FBVztHQUN4QixTQUFTLEdBQUc7SUFDWCxRQUFRLE1BQU0sQ0FBQztHQUNoQjtFQUNEO0VBQ0EsS0FBSyxpQkFBaUIsaUJBQWlCLHFCQUFxQjtHQUMzRCxNQUFNLFNBQVMsRUFBRSxVQUFVLFFBQVEsTUFBTSxRQUFRLFVBQVU7SUFDMUQsSUFBSSxDQUFDLEtBQUssV0FBVyxDQUFDLGdDQUFnQyxLQUFLLFFBQVEsR0FBRztLQUNyRSxNQUFNLGVBQWUsS0FBSyxRQUFRLFlBQVksTUFBTTtLQUNwRCxNQUFNLFlBQVksS0FBSyxRQUFRLGdCQUFnQixZQUFZO0tBQzNELE9BQU87TUFDTixNQUFNLFdBQVcsWUFBWTtNQUM3QixZQUFZLFdBQVcsWUFBWTtNQUNuQyxVQUFVLFdBQVcsUUFBUTtNQUM3QixVQUFVO01BQ1Y7TUFDQSxRQUFRLHFCQUFxQixrQkFBa0IsUUFBUSxZQUFZO01BQ25FLE1BQU0sV0FBVyxLQUFLLE1BQU0sQ0FBQyxDQUFDO01BQzlCLE9BQU8saUJBQWlCLGtCQUFrQixPQUFPLEtBQUs7S0FDdkQ7SUFDRDtJQUNBLE1BQU0sTUFBTSxvQkFBb0IsS0FBSyxTQUFTLElBQUksSUFBSSxNQUFNLEtBQUssTUFBTSxDQUFDO0lBQ3hFLE1BQU0sZUFBZSxLQUFLLFFBQVEsWUFBWSxJQUFJLE1BQU07SUFDeEQsTUFBTSxZQUFZLEtBQUssUUFBUSxnQkFBZ0IsWUFBWTtJQUMzRCxJQUFJLFNBQVM7SUFDYixPQUFPO0tBQ04sTUFBTSxJQUFJLEtBQUssUUFBUSxJQUFJLFFBQVEsRUFBRTtLQUNyQyxZQUFZO0tBQ1osVUFBVSxXQUFXLDBCQUEwQixJQUFJLFFBQVEsQ0FBQztLQUM1RCxVQUFVLENBQUMsQ0FBQyxLQUFLLFdBQVcsY0FBYyxLQUFLLEtBQUssTUFBTTtLQUMxRDtLQUNBLFFBQVEscUJBQXFCLGtCQUFrQixRQUFRLFlBQVk7S0FDbkUsTUFBTSxXQUFXLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQztLQUNsQyxPQUFPLGlCQUFpQixrQkFBa0IsT0FBTyxLQUFLO0lBQ3ZEO0dBQ0Q7R0FDQSxNQUFNLFdBQVcsTUFBTSxpQkFBaUIsZ0JBQWdCLEtBQUs7R0FDN0QsTUFBTSxFQUFFLGdCQUFnQixjQUFjLFNBQVM7R0FDL0MsSUFBSSxtQkFBbUIsQ0FBQyxhQUFhLGNBQWMsS0FBSyxrQkFBa0I7SUFDekUsTUFBTSxxQkFBcUIsTUFBTSxnQkFBZ0I7S0FDaEQsR0FBRyxlQUFlO0tBQ2xCLGdCQUFnQixLQUFLO0tBQ3JCLEtBQUssU0FBUyxNQUFNO0tBQ3BCLFdBQVcsU0FBUyxNQUFNO0lBQzNCLENBQUM7SUFDRCxtQkFBbUIsaUJBQWlCO0lBQ3BDLE9BQU87R0FDUjtHQUNBLE9BQU87RUFDUjtFQUNBLEtBQUssZUFBZSxnQkFBZ0Isc0JBQXNCLFNBQVM7R0FDbEUsSUFBSSxPQUFPLG1CQUFtQixVQUFVLE9BQU8sS0FBSyxvQkFBb0I7SUFDdkUsVUFBVTtJQUNWLFFBQVE7R0FDVCxHQUFHLElBQUk7R0FDUCxPQUFPLEtBQUssb0JBQW9CLGdCQUFnQixvQkFBb0I7RUFDckU7RUFDQSxLQUFLLG9CQUFvQixhQUFhO0dBQ3JDLE1BQU0sWUFBWSxPQUFPLE9BQU8sSUFBSTtHQUNwQyxNQUFNLFFBQVEsZUFBZSxjQUFjLFFBQVEsR0FBRyxLQUFLLGVBQWUsSUFBSTtHQUM5RSxJQUFJLE9BQU8sT0FBTyxPQUFPLFdBQVcsTUFBTSxTQUFTO0dBQ25ELE9BQU87SUFDTixPQUFPLFVBQVUsQ0FBQyxLQUFLLFdBQVcsV0FBVztJQUM3QztJQUNBLE9BQU87R0FDUjtFQUNEO0VBQ0EsS0FBSyxpQkFBaUIsU0FBUztHQUM5QixJQUFJLENBQWMsS0FBSyxVQUFXO0lBQ2pDLE1BQU0sU0FBUyxLQUFLLGdCQUFnQixJQUFJLElBQUk7SUFDNUMsSUFBSSxRQUFRLE9BQU87R0FDcEI7R0FDQSxJQUFJLGNBQWM7R0FDbEIsTUFBTSxTQUFTLE9BQU8sQ0FBQyxNQUFNO0lBQzVCLElBQUksS0FBSyxNQUFNO0tBQ2QsTUFBTSxTQUFTLFVBQVUsS0FBSyxNQUFNLENBQUMsQ0FBQztLQUN0QyxPQUFPO01BQ04sR0FBRztNQUNILElBQUksb0JBQW9CLEtBQUssU0FBUyxJQUFJLElBQUksT0FBTyxVQUFVLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQztNQUM3RSxRQUFRLEtBQUssUUFBUSxZQUFZLE9BQU8sTUFBTTtNQUM5QyxNQUFNLE9BQU8sS0FBSyxNQUFNLENBQUM7S0FDMUI7SUFDRDtJQUNBLE1BQU0sa0JBQWtCLEtBQUssaUJBQWlCLEtBQUssb0JBQW9CLEtBQUs7SUFDNUUsSUFBSTtJQUNKLE1BQU0sZ0JBQWdCO0tBQ3JCLGNBQWM7S0FDZCxPQUFPO0lBQ1I7SUFDQSxNQUFNLHFCQUFxQixnQkFBZ0IsS0FBSyx1QkFBdUIsUUFBUSxDQUFDO0lBQ2hGLElBQTZDLEtBQUssUUFBUSxLQUFLLGFBQWE7S0FDM0UsTUFBTSxDQUFDLGtCQUFrQixLQUFLLGlCQUFpQixLQUFLLElBQUk7S0FDeEQsTUFBTSxDQUFDLGVBQWUsWUFBWSxhQUFhO0tBQy9DLE1BQU0sY0FBYyxTQUFTLGdCQUFnQixNQUFNO01BQ2xELE9BQU8sYUFBYSxFQUFFLFVBQVUsS0FBSyxJQUFJO0tBQzFDLENBQUM7S0FDRCxNQUFNLGlCQUFpQixTQUFTLGlCQUFpQixNQUFNO01BQ3RELE9BQU8sYUFBYSxFQUFFLFVBQVUsUUFBUTtLQUN6QyxDQUFDO0tBQ0QsSUFBSSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsUUFBUSxLQUFLLGtDQUFrQyxLQUFLLE1BQU07SUFDaEc7SUFDQSxNQUFNLEtBQUssS0FBSyxLQUFLLEdBQUcsS0FBSyxPQUFPO0lBQ3BDLE1BQU0sU0FBUyxZQUFZLEdBQUcsT0FBTyxNQUFNLEtBQUssS0FBSyxtQkFBbUIsU0FBUyxRQUFRLENBQUMsQ0FBQyxXQUFXLEtBQUssUUFBUSxhQUFhLENBQUMsQ0FBQyxJQUFJLElBQUksS0FBSyxRQUFRLGVBQWUsS0FBSyxnQkFBZ0I7SUFDM0wsTUFBTSxZQUFZLEtBQUssYUFBYSxjQUFjLE1BQU07SUFDeEQsTUFBTSxhQUFhLE9BQU8sU0FBUyxHQUFHO0lBQ3RDLElBQUk7SUFDSixJQUFJLFdBQVcsYUFBYSxVQUFVLFlBQVksaUJBQWlCLFNBQVM7U0FDdkUsSUFBSSxZQUFZLGFBQWEsQ0FBQztTQUM5QjtLQUNKLE1BQU0sQ0FBQyxlQUFlLFdBQVcsY0FBYyxLQUFLLGlCQUFpQixNQUFNO0tBQzNFLGFBQWE7S0FDYixJQUFJLEtBQUssUUFBUSxrQkFBa0IsQ0FBQyxjQUFjLFdBQVcsU0FBUyxPQUFPLFVBQVUsUUFBUSxhQUFhLENBQUMsR0FBRyxZQUFZLEtBQUssUUFBUSxhQUFhO0lBQ3ZKO0lBQ0EsTUFBTSxnQkFBZ0IsYUFBYSxXQUFXLGtCQUFrQixjQUFjLE9BQU8sRUFBRSxVQUFVLE9BQU8sR0FBRyxDQUFDLElBQUksS0FBSztJQUNySCxJQUFJO0lBQ0osS0FBSyxNQUFNLFNBQVMsWUFBWTtLQUMvQixNQUFNLEtBQUssTUFBTSxRQUFRLFFBQVEsYUFBYSxNQUFNLFFBQVE7S0FDNUQsSUFBSSxJQUFJO01BQ1AsTUFBTSxhQUFhLGFBQWEsQ0FBQyxDQUFDO01BQ2xDLGVBQWUsa0JBQWtCLEtBQUssUUFBUSxVQUFVO01BQ3hELElBQUksQ0FBQyxRQUFRLFVBQVUsR0FBRztNQUMxQixJQUFJLGVBQWUsWUFBWSxhQUFhLE9BQU8sT0FBTyxXQUFXLEdBQUcsVUFBVTtNQUNsRixJQUFJO09BQ0gsT0FBTyxPQUFPLFlBQVksR0FBRyxVQUFVLENBQUM7TUFDekMsUUFBUSxDQUFDO0tBQ1Y7SUFDRDtJQUNBLGVBQWUsa0JBQWtCLEtBQUssUUFBUSxxQkFBcUIsS0FBSyxRQUFRLGFBQWEsSUFBSSxhQUFhLENBQUMsQ0FBQyxLQUFLLFlBQVk7SUFDakksTUFBTSxlQUFlLEtBQUssY0FBYyxTQUFTLDBCQUEwQixXQUFXLGdCQUFnQixnQkFBZ0IsUUFBUSxlQUFlLFlBQVksS0FBSyxpQkFBaUIsSUFBSSxNQUFNLENBQUM7SUFDMUwsSUFBNkMsYUFBYSxDQUFDLEtBQUssYUFBYSxJQUFJO0tBQ2hGLE1BQU0sYUFBYSxLQUFLLGlCQUFpQixZQUFZLENBQUMsQ0FBQztLQUN2RCxJQUFJLFlBQVksT0FBTyxVQUFVLElBQUksUUFBUSxLQUFLLG1CQUFtQixhQUFhLGVBQWUsVUFBVSxHQUFHLG1CQUFtQixZQUFZLEdBQUcsb01BQW9NO0lBQ3JWLFFBQVEsQ0FBQztJQUNULE1BQU0sY0FBYyxxQkFBcUIsWUFBWSxLQUFLLHNCQUFzQjtJQUNoRixNQUFNLG1CQUFtQjtLQUN4QixJQUFJLFNBQVMsYUFBYSxDQUFDLENBQUM7S0FDNUIsSUFBSSxLQUFLLDBCQUEwQixLQUFLLFFBQVEsUUFBUSxRQUFRO01BQy9ELE1BQU0sa0JBQWtCLENBQUM7TUFDekIsV0FBVyxTQUFTLFVBQVU7T0FDN0IsSUFBSSxNQUFNLFFBQVEsZ0JBQWdCLElBQUk7UUFDckMsT0FBTyxPQUFPLGlCQUFpQixlQUFlLE1BQU0sUUFBUSxnQkFBZ0I7U0FDM0UsR0FBRztTQUNILEdBQUc7UUFDSixDQUFDLENBQUM7T0FDSCxRQUFRLENBQUM7TUFDVixDQUFDO01BQ0QsU0FBUztLQUNWO0tBQ0EsT0FBTztJQUNSO0lBQ0EsTUFBTSxhQUFhLFlBQVksU0FBUyxzQkFBc0IsYUFBYSxXQUFXLEdBQUcsSUFBSSxJQUFJLEtBQUssV0FBVyxPQUFPLFdBQVcsSUFBSSxPQUFPLEtBQUssV0FBVyxhQUFhLEtBQUssT0FBTyxXQUFXLENBQUMsSUFBSSxLQUFLLFVBQVU7SUFDdE4sTUFBTSxZQUFZLEtBQUssUUFBUSxnQkFBZ0IsVUFBVTtJQUN6RCxNQUFNLE9BQU8sS0FBSyxTQUFTLE9BQU8sUUFBUSxDQUFDLENBQUMsT0FBTyxPQUFPLEtBQUssU0FBUyxhQUFhLEtBQUssS0FBSyxRQUFRLENBQUMsQ0FBQyxJQUFJLElBQUksS0FBSyxRQUFRLEtBQUs7SUFDbkksTUFBTSxVQUFVLE9BQU8sSUFBSSxTQUFTO0lBQ3BDLE1BQU0sWUFBWSxDQUFDLEtBQUssUUFBUSxlQUFlLEtBQUssVUFBVSxPQUFPLFFBQVEsQ0FBQyxDQUFDLFFBQVEsT0FBTyxLQUFLLFVBQVUsYUFBYSxLQUFLLE1BQU0sUUFBUSxDQUFDLENBQUMsS0FBSyxJQUFJLEtBQUs7SUFDN0osTUFBTSxXQUFXLEdBQUcsZUFBZSxZQUFZO0lBQy9DLElBQUk7SUFDSixJQUFJO0lBQ0osSUFBSSxXQUFXO0lBQ2YsSUFBSSxLQUFLLFNBQVM7S0FDakIsTUFBTSxNQUFNLElBQUksSUFBSSxVQUFVLEtBQUssTUFBTTtLQUN6QyxNQUFNLFNBQVMsSUFBSTtLQUNuQixNQUFNLGVBQWUscUJBQXFCLEtBQUssU0FBUyxHQUFHO0tBQzNELE9BQU8sV0FBVyxHQUFHO0tBQ3JCLElBQUksY0FBYyxjQUFjLE1BQU0sR0FBRztNQUN4QyxhQUFhLGFBQWE7TUFDMUIsV0FBVztLQUNaLE9BQU8sYUFBYSwwQkFBMEIsV0FBVyxZQUFZLENBQUM7SUFDdkUsT0FBTztLQUNOLE9BQU8sa0JBQWtCLFFBQVE7S0FDakMsYUFBYTtJQUNkO0lBQ0EsT0FBTztLQUNOO0tBQ0E7S0FDQSxVQUFVO0tBQ1YsUUFBUTtLQUNSO0tBQ0EsT0FBTztLQUNQLE1BQU0sUUFBUTtLQUNkO0tBQ0EsZ0JBQWdCLEtBQUs7SUFDdEI7R0FDRDtHQUNBLE1BQU0sT0FBTyxNQUFNLElBQUk7R0FDdkIsSUFBSSxLQUFLLE1BQU0sS0FBSyxpQkFBaUIsTUFBTTtJQUMxQyxNQUFNLEtBQUs7SUFDWCxHQUFHLEtBQUs7R0FDVCxDQUFDO1FBQ0ksSUFBSSxLQUFLLFFBQVEsWUFBWTtJQUNqQyxNQUFNLFFBQVEsY0FBYyxLQUFLLFVBQVUsS0FBSyxhQUFhO0lBQzdELElBQUksT0FBTztLQUNWLE1BQU0sU0FBUyxPQUFPLE9BQU8sV0FBVyxHQUFHLE1BQU0sU0FBUztLQUMxRCxNQUFNLEVBQUUsTUFBTSxPQUFPLFFBQVEsWUFBWSxHQUFHLGNBQWMsTUFBTTtLQUNoRSxNQUFNLGFBQWEsa0JBQWtCLFlBQVksTUFBTTtLQUN2RCxLQUFLLGlCQUFpQixNQUFNO01BQzNCLE1BQU0sS0FBSztNQUNYLEdBQUc7TUFDSCxRQUFRO0tBQ1QsQ0FBQztJQUNGO0dBQ0Q7R0FDQSxJQUFJLENBQWMsS0FBSyxZQUFhLENBQUMsZUFBZSxLQUFLLGVBQWUsS0FBSyxnQkFBZ0IsSUFBSSxNQUFNLElBQUk7R0FDM0csT0FBTztFQUNSO0VBQ0EsS0FBSyxpQkFBaUIsT0FBTyxFQUFFLGdCQUFnQixlQUFlLEdBQUcsV0FBVztHQUMzRSxJQUFnQixLQUFLLFVBQVU7R0FDL0IsTUFBTSxlQUFlLEtBQUssa0JBQWtCO0dBQzVDLElBQUksYUFBYSxZQUFZLENBQWMsS0FBSyxVQUFXLE9BQU8sbUJBQW1CLE1BQU0sYUFBYSxZQUFZO0lBQ25ILFNBQVMsS0FBSztJQUNkO0dBQ0QsQ0FBQztHQUNELElBQUk7R0FDSixNQUFNLGlCQUFpQixjQUFjLEtBQUssZUFBZSxJQUFJLE1BQU0sY0FBYyxLQUFLLElBQUksS0FBSyxVQUFVLHFCQUFxQixLQUFLLEtBQUssR0FBRyxxQkFBcUIsS0FBSyxlQUFlLEtBQUssQ0FBQztHQUMxTCxNQUFNLHdCQUF3QixLQUFLO0dBQ25DLElBQUk7R0FDSixNQUFNLGdCQUFnQixJQUFJLFNBQVMsU0FBUztJQUMzQyxVQUFVO0dBQ1gsQ0FBQztHQUNELGNBQWMsZ0JBQWdCO0lBQzdCLFFBQVE7SUFDUix1QkFBdUIsUUFBUTtHQUNoQztHQUNBLEtBQUssaUJBQWlCO0dBQ3RCLElBQUksZ0JBQWdCLEtBQUssS0FBSztRQUN6QjtJQUNKLElBQUksRUFBRSxnQkFBZ0Isb0JBQW9CLEdBQUcsZ0JBQWdCO0lBQzdELElBQUksZ0JBQWdCO0tBQ25CLGNBQWM7TUFDYixHQUFHO01BQ0gsT0FBTztPQUNOLEdBQUcsZUFBZTtPQUNsQixXQUFXLEtBQUs7T0FDaEIsZ0JBQWdCO1FBQ2YsR0FBRztRQUNILFFBQVEsWUFBWTtRQUNwQixPQUFPO1NBQ04sR0FBRyxZQUFZO1NBQ2YsV0FBVyxLQUFLO1NBQ2hCLGdCQUFnQixLQUFLO1NBQ3JCLFdBQVcsS0FBSztTQUNoQixLQUFLLEtBQUs7UUFDWDtPQUNEO01BQ0Q7S0FDRDtLQUNBLElBQUksWUFBWSxrQkFBa0IsS0FBSyxRQUFRLGtCQUFrQixPQUFPLFlBQVksTUFBTSxZQUFZLEtBQUs7SUFDNUc7SUFDQSxZQUFZLFFBQVE7S0FDbkIsR0FBRyxZQUFZO0tBQ2YsNkJBQTZCLHNCQUFzQixLQUFLLFFBQVEsNkJBQTZCO0lBQzlGO0lBQ0EsS0FBSyx1QkFBdUI7SUFDNUIsZ0JBQWdCLEtBQUssVUFBVSxZQUFZO0lBQzNDLEtBQUssUUFBUSxrQkFBa0IsWUFBWSxZQUFZLE9BQU8sQ0FBQyxZQUFZLFlBQVksWUFBWSxPQUFPLEVBQUUsY0FBYyxDQUFDO0lBQzNILElBQUksQ0FBQyxLQUFLLFFBQVEsWUFBWSxNQUFNLEtBQUssS0FBSyxFQUFFLFFBQVEsRUFBRSxNQUFNLGNBQWMsRUFBRSxDQUFDO0dBQ2xGO0dBQ0EsS0FBSyxRQUFRLElBQUksS0FBSyxlQUFlO0dBQ3JDLE9BQU8sS0FBSztFQUNiO0VBQ0EsS0FBSywwQkFBMEIsRUFBRSxTQUFTLGFBQWEsb0JBQW9CLGdCQUFnQixlQUFlLEdBQUcsU0FBUyxDQUFDLE1BQU07R0FDNUgsSUFBZ0IsS0FBSyxVQUFVLE9BQU8sUUFBUSxRQUFRO0dBQ3RELE1BQU0sV0FBVyxLQUFLLGNBQWM7SUFDbkMsR0FBRztJQUNILHdCQUF3QjtHQUN6QixDQUFDO0dBQ0QsS0FBSyxtQkFBbUI7R0FDeEIsTUFBTSxnQkFBZ0IsS0FBSyxlQUFlO0lBQ3pDLEdBQUc7SUFDSDtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0QsQ0FBQztHQUNELHFCQUFxQjtJQUNwQixJQUFJLEtBQUsscUJBQXFCLFVBQVUsS0FBSyxtQkFBbUIsS0FBSztHQUN0RSxDQUFDO0dBQ0QsT0FBTztFQUNSO0VBQ0EsS0FBSyxXQUFXLE9BQU8sRUFBRSxJQUFJLGdCQUFnQixNQUFNLFlBQVksR0FBRyxXQUFXO0dBQzVFLElBQWdCLEtBQUssVUFBVTtHQUMvQixNQUFNLGFBQWEsT0FBTyxhQUFhLElBQUksSUFBSSxLQUFLO0dBQ3BELElBQUksY0FBYyxnQkFBZ0I7SUFDakMsSUFBSSxPQUFPLEtBQUssS0FBSyxDQUFDLE1BQU07S0FDM0IsTUFBTSxXQUFXLEtBQUssY0FBYztNQUNuQztNQUNBLEdBQUc7S0FDSixDQUFDO0tBQ0QsTUFBTSxpQkFBaUIsU0FBUyxrQkFBa0I7S0FDbEQsU0FBUyxlQUFlO0tBQ3hCLGVBQWUsZUFBZTtJQUMvQjtJQUNBLE1BQU0sYUFBYSxDQUFDLGNBQWMsYUFBYSxhQUFhO0lBQzVELE9BQU8sbUJBQW1CLE1BQU0sWUFBWSxJQUFJO0dBQ2pEO0dBQ0EsT0FBTyxLQUFLLHVCQUF1QjtJQUNsQyxHQUFHO0lBQ0g7SUFDQTtJQUNBLGFBQWE7R0FDZCxDQUFDO0VBQ0Y7RUFDQSxLQUFLLE9BQU8sT0FBTyxTQUFTO0dBQzNCLElBQWdCLEtBQUssVUFBVSxPQUFPLGdCQUFnQixNQUFNLElBQUk7R0FDaEUsS0FBSyxxQkFBcUI7R0FDMUIsSUFBSSxNQUFNLFFBQVEsS0FBSyxRQUFRLElBQUksS0FBSyxPQUFPLFNBQVMsVUFBVSxLQUFLLE9BQU8sU0FBUztHQUN2RixNQUFNLGdCQUFnQixNQUFNLElBQUk7RUFDakM7RUFDQSxLQUFLLHVCQUF1QixPQUFPO0dBQ2xDLE1BQU0sdUJBQXVCLEtBQUssd0JBQXdCLEtBQUssUUFBUTtHQUN2RSxLQUFLLHVCQUF1QixLQUFLO0dBQ2pDLElBQUksd0JBQXdCLEVBQWMsT0FBTyxhQUFhLGdCQUFnQixPQUFPLFNBQVMsd0JBQXdCLFlBQVk7SUFDakksSUFBSTtJQUNKLElBQUksT0FBTyx5QkFBeUIsWUFBWSxPQUFPLEtBQUssV0FBVywyQ0FBMkMsR0FBRztLQUNwSCxNQUFNLE9BQU8sS0FBSztLQUNsQixNQUFNLGVBQWUsS0FBSyxPQUFPLGlCQUFpQixJQUFJO0tBQ3RELE1BQU0sOEJBQThCLE9BQU8scUJBQXFCLFVBQVUsYUFBYSxxQkFBcUIsTUFBTSxzQkFBc0IsTUFBTSxZQUFZLENBQUMsSUFBSSxxQkFBcUI7S0FDcEwsSUFBSSxnQ0FBZ0MsT0FBTyxPQUFPLEdBQUc7S0FDckQsNEJBQTRCO01BQzNCLFFBQVE7TUFDUixPQUFPO0tBQ1I7SUFDRCxPQUFPLDRCQUE0QjtJQUNuQyxPQUFPLFNBQVMsb0JBQW9CLHlCQUF5QixDQUFDLENBQUM7R0FDaEU7R0FDQSxPQUFPLEdBQUc7RUFDWDtFQUNBLEtBQUssY0FBYyxTQUFTO0dBQzNCLE1BQU0sbUJBQW1CLEtBQUs7R0FDOUIsTUFBTSxTQUFTLE1BQU07R0FDckIsTUFBTSxXQUFXLEtBQUs7R0FDdEIsTUFBTSw2QkFBNkIsSUFBSSxJQUFJO0dBQzNDLE1BQU0sWUFBWSxVQUFVO0lBQzNCLElBQUksQ0FBQyxVQUFVLE9BQU8sS0FBSyxHQUFHLFdBQVcsSUFBSSxNQUFNLEVBQUU7R0FDdEQ7R0FDQSxpQkFBaUIsUUFBUSxRQUFRO0dBQ2pDLEtBQUssT0FBTyxRQUFRLFFBQVE7R0FDNUIsVUFBVSxTQUFTLFlBQVksUUFBUSxRQUFRLFFBQVEsQ0FBQztHQUN4RCxLQUFLLE1BQU0sRUFBRSxDQUFDLFFBQVEsUUFBUTtHQUM5QixNQUFNLFFBQVEsQ0FBQztHQUNmLEtBQUssTUFBTSxDQUFDLFlBQVksWUFBWSxZQUFZLENBQUMsR0FBRyxJQUFJLFFBQVEsTUFBTSxVQUFVLFdBQVcsSUFBSSxNQUFNLEVBQUUsQ0FBQyxHQUFHO0lBQzFHLFNBQVMsT0FBTyxVQUFVO0lBQzFCLE1BQU0sS0FBSyxVQUFVO0dBQ3RCO0dBQ0EsTUFBTSxjQUFjLE1BQU07SUFDekIsSUFBSSxXQUFXLElBQUksRUFBRSxFQUFFLEdBQUc7S0FDekIsTUFBTSxRQUFRLEtBQUssV0FBVyxFQUFFO0tBQ2hDLE1BQU0sT0FBTztNQUNaLEdBQUc7TUFDSCxTQUFTO01BQ1QsSUFBSSxNQUFNLGdCQUFnQixFQUFFLFdBQVcsV0FBVyxFQUFFLFdBQVcsZUFBZSxlQUFlLEtBQUssSUFBSTtPQUNyRyxRQUFRO09BQ1IsT0FBTyxLQUFLO01BQ2IsSUFBSSxLQUFLO0tBQ1Y7S0FDQSxFQUFFLFVBQVUsS0FBSztLQUNqQixPQUFPO0lBQ1I7SUFDQSxPQUFPO0dBQ1I7R0FDQSxLQUFLLGFBQWEsaUJBQWlCLElBQUksVUFBVTtHQUNqRCxLQUFLLE1BQU0sQ0FBQyxJQUFJLFVBQVUsS0FBSyxRQUFRLElBQUksV0FBVyxJQUFJLEVBQUUsR0FBRztJQUM5RCxNQUFNLFVBQVU7SUFDaEIsSUFBSSxNQUFNLGNBQWMsTUFBTSxTQUFTO0dBQ3hDO0dBQ0EsS0FBSyxNQUFNLE1BQU0sWUFBWTtJQUM1QixNQUFNLFNBQVMsS0FBSyxVQUFVLElBQUksRUFBRTtJQUNwQyxLQUFLLFVBQVUsT0FBTyxFQUFFO0lBQ3hCLElBQUksVUFBVSxDQUFDLE9BQU8sSUFBSSxNQUFNLEtBQUssT0FBTyxFQUFFO0dBQy9DO0dBQ0EsS0FBSyxNQUFNLGNBQWMsT0FBTyxXQUFXLE1BQU07R0FDakQsS0FBSyx1QkFBdUI7R0FDNUIsT0FBTyxLQUFLLEtBQUssRUFBRSxNQUFNLE1BQU0sS0FBSyxDQUFDO0VBQ3RDO0VBQ0EsS0FBSyxtQkFBbUIsYUFBYTtHQUNwQyxNQUFNLFVBQVUsU0FBUztHQUN6QixJQUFJLE9BQU8sU0FBUyxRQUFRLElBQUksVUFBVSxLQUFLLFFBQVE7R0FDdkQsSUFBSSxDQUFDLE1BQU07SUFDVixNQUFNLFdBQVcsS0FBSyxjQUFjLE9BQU87SUFDM0MsUUFBUSxTQUFTLGtCQUFrQixTQUFBLENBQVUsY0FBYztHQUM1RDtHQUNBLElBQUk7R0FDSixJQUFJLDRCQUE0QixLQUFLLElBQUksTUFBTSxTQUFTLGFBQWEsSUFBSSxNQUFNLENBQUMsS0FBSyxrQkFBa0IsSUFBSSxNQUFNLEdBQUcsTUFBTSxJQUFJLE1BQThDLDhDQUE4QyxLQUFLLHdCQUF3QixNQUFNLEtBQUssS0FBSyxpQkFBaUIsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFLEVBQXdDO0dBQzdVLElBQUksV0FBVyxXQUFXLFdBQVcsVUFBVTtJQUM5QyxNQUFNLE1BQU0sSUFBSSxJQUFJLElBQUk7SUFDeEIsSUFBSSxJQUFJLFNBQVMsV0FBVyxJQUFJLEdBQUcsT0FBTyxJQUFJO1NBQ3pDLElBQUksQ0FBQyxjQUFjLEtBQUssS0FBSyxNQUFNLEdBQUc7S0FDMUMsT0FBTyxXQUFXLEdBQUc7S0FDckIsU0FBUyxLQUFLO0lBQ2Y7R0FDRDtHQUNBLElBQUksUUFBUSxRQUFRLGlCQUFpQjtHQUNyQyxRQUFRLE9BQU87R0FDZixTQUFTLFFBQVEsSUFBSSxZQUFZLElBQUk7R0FDckMsT0FBTztFQUNSO0VBQ0EsS0FBSyxjQUFjLFNBQVM7R0FDM0IsTUFBTSxTQUFTLEtBQUs7R0FDcEIsTUFBTSxXQUFXLEtBQUs7R0FDdEIsTUFBTSxTQUFTLE1BQU07R0FDckIsTUFBTSxZQUFZLENBQUM7R0FDbkIsTUFBTSxlQUFlLENBQUM7R0FDdEIsS0FBSyxNQUFNLENBQUMsSUFBSSxVQUFVLFFBQVEsSUFBSSxDQUFDLFVBQVUsT0FBTyxLQUFLLEdBQUc7SUFDL0QsYUFBYSxLQUFLLEVBQUU7SUFDcEIsVUFBVSxLQUFLLEtBQUs7R0FDckI7R0FDQSxNQUFNLFFBQVEsQ0FBQztHQUNmLEtBQUssTUFBTSxDQUFDLFlBQVksWUFBWSxZQUFZLENBQUMsR0FBRyxJQUFJLENBQUMsVUFBVSxRQUFRLEtBQUssTUFBTSxHQUFHO0lBQ3hGLE1BQU0sS0FBSyxVQUFVO0lBQ3JCLFVBQVUsS0FBSyxHQUFHLE9BQU87R0FDMUI7R0FDQSxLQUFLLE1BQU0sTUFBTSxjQUFjLE9BQU8sT0FBTyxFQUFFO0dBQy9DLEtBQUssTUFBTSxjQUFjLE9BQU8sU0FBUyxPQUFPLFVBQVU7R0FDMUQsS0FBSyxNQUFNLFNBQVMsV0FBVztJQUM5QixNQUFNLFNBQVMsTUFBTTtJQUNyQixNQUFNLFVBQVUsS0FBSztJQUNyQixJQUFJLFVBQVUsQ0FBQyxFQUFFLE9BQU8sSUFBSTtLQUMzQixJQUFJLEtBQUssVUFBVSxJQUFJLE1BQU0sRUFBRSxNQUFNLFFBQVEsS0FBSyxTQUFTLE9BQU8sTUFBTSxFQUFFO0tBQzFFLE1BQU0sS0FBSyxPQUFPLEVBQUU7SUFDckI7R0FDRDtHQUNBLEtBQUssTUFBTSxjQUFjLE9BQU8sV0FBVyxNQUFNO0VBQ2xEO0VBQ0EsS0FBSyxpQkFBaUI7RUFDdEIsS0FBSyxnQkFBZ0IsU0FBUyxtQkFBbUIsTUFBTSxJQUFJO0VBQzNELEtBQUssY0FBYyxVQUFVLFNBQVM7R0FDckMsTUFBTSxnQkFBZ0I7SUFDckIsR0FBRztJQUNILElBQUksU0FBUyxLQUFLLFlBQVksU0FBUyxRQUFRLElBQUksU0FBUyxJQUFJLEtBQUssUUFBUSxlQUFlLEtBQUssZ0JBQWdCLElBQUksS0FBSztJQUMxSCxRQUFRLFNBQVMsVUFBVSxDQUFDO0lBQzVCLGFBQWE7R0FDZDtHQUNBLE1BQU0sT0FBTyxLQUFLLGNBQWMsYUFBYTtHQUM3QyxNQUFNLFlBQVksS0FBSyxPQUFPLE9BQU8sSUFBSSxNQUFNO0dBQy9DLElBQUksTUFBTSxXQUFXLENBQUMsV0FBVyxPQUFPO0dBQ3hDLE1BQU0sZUFBZSxNQUFNLFdBQVcsQ0FBQyxZQUFZLEtBQUssaUJBQWlCLEtBQUssT0FBTyxpQkFBaUIsSUFBSSxLQUFLLEtBQUssT0FBTyxTQUFTLElBQUk7R0FDeEksTUFBTSxRQUFRLGdCQUFnQixLQUFLLFVBQVUsTUFBTSxpQkFBaUIsT0FBTyxNQUFNLFNBQVMsT0FBTyxhQUFhLFVBQVUsS0FBSyxhQUFhO0dBQzFJLElBQUksQ0FBQyxPQUFPLE9BQU87R0FDbkIsSUFBSSxTQUFTLFFBQ1I7UUFBQSxDQUFDLFVBQVUsTUFBTSxXQUFXLFNBQVMsUUFBUSxJQUFJLEdBQUcsT0FBTztHQUFBO0dBRWhFLElBQUksTUFBTSxpQkFBaUIsTUFBTSxPQUFPLFVBQVUsYUFBYSxRQUFRLEtBQUssUUFBUSxJQUFJLElBQUksTUFBTSxZQUFZO0dBQzlHLE9BQU8sTUFBTTtFQUNkO0VBQ0EsS0FBSyxpQkFBaUI7RUFDdEIsSUFBSSxRQUFRLDZCQUE2QixRQUFRLEtBQUssb0JBQW9CLHFCQUFxQixRQUFRLDJCQUEyQjtFQUNsSSxLQUFLLE9BQU87R0FDWCxxQkFBcUI7R0FDckIsa0JBQWtCO0dBQ2xCLHFCQUFxQjtHQUNyQixTQUFTLEtBQUs7R0FDZCxHQUFHO0dBQ0gsZUFBZSxRQUFRLGlCQUFpQjtHQUN4QyxjQUFjLFFBQVEsZ0JBQWdCO0dBQ3RDLGlCQUFpQixRQUFRLG1CQUFtQjtHQUM1QyxhQUFhLFFBQVEsZUFBZTtHQUNwQyxtQkFBbUIsUUFBUSxxQkFBcUI7RUFDakQsQ0FBQztFQUNELElBQUksRUFBYyxPQUFPLGFBQWEsY0FBYyxLQUFLLGlCQUFpQjtDQUMzRTtDQUNBLFVBQVU7RUFDVCxPQUFPLENBQUMsQ0FBQyxLQUFLLFFBQVE7Q0FDdkI7Q0FDQSxJQUFJLFFBQVE7RUFDWCxPQUFPLEtBQUssT0FBTyxRQUFRLElBQUk7Q0FDaEM7Q0FDQSxVQUFVLFFBQVE7RUFDakIsT0FBTyxPQUFPLE1BQU0sTUFBTTtFQUMxQixLQUFLLG1DQUFtQyxJQUFJLFFBQVE7RUFDcEQsSUFBSSxDQUFjLEtBQUssVUFBVyxLQUFLLGtDQUFrQyxJQUFJLFFBQVE7RUFDckYsTUFBTSxnQkFBZ0IsS0FBSyxRQUFRO0VBQ25DLElBQUksZUFBZTtHQUNsQixjQUFjLEtBQUssV0FBVztHQUM5QixJQUFJLEtBQUssV0FBVyxjQUFjLFFBQVEsZUFBZSxjQUFjLGlCQUFpQixjQUFjLE9BQU8sZUFBZSxDQUFDO0dBQzdILEtBQUssV0FBVyxjQUFjLE1BQU07RUFDckM7Q0FDRDtDQUNBLG9CQUFvQixNQUFNLE1BQU07RUFDL0IsTUFBTSxDQUFDLHNCQUFzQixXQUFXLGNBQWMsS0FBSyxpQkFBaUIsS0FBSyxRQUFRO0VBQ3pGLElBQUksZ0JBQWdCO0VBQ3BCLElBQUksbUJBQW1CO0VBQ3ZCLElBQUksYUFBYSxXQUFXLFNBQVMsT0FBTyxVQUFVLFFBQVEsY0FBYyxLQUFLLFFBQVEsR0FBRztHQUMzRixJQUFJLEtBQUssUUFBUSxlQUFlLGdCQUFnQixDQUFDLEdBQUcsZUFBZSxLQUFLLFFBQVEsYUFBYTtRQUN4RixtQkFBbUI7RUFDekI7RUFDQSxNQUFNLG1CQUFtQixtQkFBbUIsMEJBQTBCLEtBQUssUUFBUSxjQUFjLGFBQWEsSUFBSSxLQUFLO0VBQ3ZILE1BQU0sVUFBVSxJQUFJLE1BQU0sY0FBYyxNQUFNO0VBQzlDLE1BQU0sWUFBWSxLQUFLO0VBQ3ZCLE1BQU0sY0FBYyxPQUFPLFVBQVU7R0FDcEMsTUFBTSxRQUFRLFVBQVU7R0FDeEIsT0FBTyxPQUFPLFlBQVksTUFBTSxLQUFLLFFBQVEsVUFBVSxLQUFLLFFBQVEsZ0JBQWdCLFVBQVUsTUFBTSxjQUFjLFVBQVUsWUFBWSxNQUFNLEVBQUUsSUFBSSxLQUFLO0VBQzFKO0VBQ0EsSUFBSTtFQUNKLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxjQUFjLFFBQVEsU0FBUztHQUMxRCxNQUFNLFFBQVEsY0FBYztHQUM1QixNQUFNLGNBQWMsUUFBUSxRQUFRO0dBQ3BDLElBQUk7R0FDSixJQUFJO0dBQ0osSUFBSTtHQUNKO0lBQ0MsTUFBTSxlQUFlLGFBQWEsVUFBVSxLQUFLO0lBQ2pELE1BQU0scUJBQXFCLGFBQWEsaUJBQWlCLEtBQUs7SUFDOUQsSUFBSTtLQUNILE1BQU0sZUFBZSxlQUFlLE1BQU0sUUFBUSxnQkFBZ0IsRUFBRSxHQUFHLGFBQWEsQ0FBQyxLQUFLLEtBQUs7S0FDL0YsaUJBQWlCO01BQ2hCLEdBQUc7TUFDSCxHQUFHO0tBQ0o7S0FDQSxvQkFBb0I7TUFDbkIsR0FBRztNQUNILEdBQUc7S0FDSjtJQUNELFNBQVMsS0FBSztLQUNiLElBQUksbUJBQW1CO0tBQ3ZCLElBQUksRUFBRSxlQUFlLG1CQUFtQixtQkFBbUIsSUFBSSxpQkFBaUIsSUFBSSxTQUFTLEVBQUUsT0FBTyxJQUFJLENBQUM7S0FDM0csSUFBSSxNQUFNLGNBQWMsTUFBTTtLQUM5QixpQkFBaUI7S0FDakIsb0JBQW9CLENBQUM7S0FDckIsY0FBYztJQUNmO0dBQ0Q7R0FDQSxJQUFJLGFBQWE7R0FDakIsSUFBSSxpQkFBaUI7R0FDckIsSUFBSTtJQUNILGFBQWEsTUFBTSxRQUFRLGFBQWEsRUFBRSxRQUFRLGVBQWUsQ0FBQyxLQUFLO0lBQ3ZFLGlCQUFpQixhQUFhLEtBQUssVUFBVSxVQUFVLEtBQUssS0FBSztHQUNsRSxTQUFTLE9BQU87SUFDZixJQUFJLE1BQU0sY0FBYyxNQUFNO0lBQzlCLGdCQUFnQjtHQUNqQjtHQUNBLE1BQU0sYUFBYSxXQUFXO0dBQzlCLE1BQU0sbUJBQW1CLE1BQU0saUJBQWlCLGdCQUFnQixNQUFNLFVBQVUsTUFBTSxnQkFBZ0IsV0FBVyxLQUFLLG1CQUFtQixVQUFVLElBQUksTUFBTTtHQUM3SixNQUFNLFVBQVUsTUFBTSxLQUFLLG1CQUFtQjtHQUM5QyxNQUFNLGdCQUFnQixXQUFXLE9BQU8sS0FBSztHQUM3QyxNQUFNLGdCQUF5RCxNQUFNLGlCQUFpQixLQUFLLElBQUksS0FBSyxPQUFPLElBQUksT0FBTyxNQUFNLGVBQWUsT0FBTyxVQUFVLGdCQUFnQixLQUFLO0dBQ2pMLGVBQWUsZUFBZSxpQkFBaUIsT0FBTyxPQUFPLFlBQVksWUFBWTtHQUNyRixJQUFJO0dBQ0osSUFBSSxDQUFDLGVBQWUsSUFBSTtJQUN2QixvQkFBb0IsT0FBTyxZQUFZO0dBQ3hDLFNBQVMsS0FBSztJQUNiLElBQUksV0FBVyxHQUFHLEtBQUssV0FBVyxHQUFHLEdBQUcsY0FBYztTQUNqRCxjQUFjLElBQUksZUFBZSxJQUFJLFNBQVMsRUFBRSxPQUFPLElBQUksQ0FBQztJQUNqRSxJQUFJLE1BQU0sY0FBYyxNQUFNO0dBQy9CO0dBQ0EsTUFBTSxRQUFRLGdCQUFnQixTQUFTO0dBQ3ZDLElBQUk7R0FDSixJQUFJLGVBQWUsUUFBUTtJQUMxQixHQUFHO0lBQ0g7SUFDQSxRQUFRLGdCQUFnQixxQkFBcUIsY0FBYyxRQUFRLGNBQWMsSUFBSSxxQkFBcUIsY0FBYyxRQUFRLGNBQWM7SUFDOUksZUFBZTtJQUNmO0dBQ0Q7UUFDSztJQUNKLE1BQU0sU0FBUyxlQUFlLEtBQUssSUFBSSxZQUFZO0lBQ25ELFFBQVE7S0FDUCxJQUFJO0tBQ0osS0FBaUIsS0FBSyxXQUFXLEtBQUssSUFBSSxNQUFNLFFBQVE7S0FDeEQ7S0FDQSxTQUFTLE1BQU07S0FDZixRQUFRLGVBQWUsVUFBVTtLQUNqQyxlQUFlO0tBQ2YsVUFBVTtLQUNWLFdBQVcsS0FBSyxJQUFJO0tBQ3BCLFFBQVEsZ0JBQWdCLHFCQUFxQixjQUFjLFFBQVEsY0FBYyxJQUFJO0tBQ3JGLGVBQWU7S0FDZjtLQUNBO0tBQ0EsWUFBWTtLQUNaLE9BQU8sS0FBSztLQUNaO0tBQ0EsU0FBUyxDQUFDO0tBQ1YsaUJBQWlCLE1BQU0sZUFBZSxJQUFJLGdCQUFnQjtLQUMxRDtLQUNBLFlBQVksZ0JBQWdCLGlCQUFpQixjQUFjLFlBQVksVUFBVSxJQUFJO0tBQ3JGLFNBQVM7S0FDVCxTQUFTO0tBQ1QsWUFBWSxNQUFNLFFBQVEsY0FBYyxDQUFDO0tBQ3pDLFVBQVUsTUFBTTtJQUNqQjtHQUNEO0dBQ0EsTUFBTSxZQUFZLHFCQUFxQixNQUFNO0dBQzdDLElBQUksTUFBTSxhQUFhLENBQUMsV0FBVyxNQUFNLFFBQVEsS0FBSztHQUN0RCxNQUFNLFlBQVk7R0FDbEIsUUFBUSxTQUFTO0VBQ2xCO0VBQ0EsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLFFBQVEsUUFBUSxTQUFTO0dBQ3BELE1BQU0sUUFBUSxRQUFRO0dBQ3RCLE1BQU0sU0FBUyxNQUFNLFVBQVUsU0FBUyxxQkFBcUIsTUFBTSxRQUFRLFlBQVksSUFBSTtHQUMzRixJQUFJLE1BQU0sYUFBYSxNQUFNLFVBQVUsQ0FBQztFQUN6QztFQUNBLE9BQU87Q0FDUjs7Ozs7O0NBTUEsdUJBQXVCLFVBQVU7RUFDaEMsTUFBTSxjQUFjLEtBQUssS0FBSyxPQUFPLElBQUksSUFBSSxDQUFDO0VBQzlDLE1BQU0saUJBQWlCLGNBQWMsS0FBSyxPQUFPLFFBQVEsSUFBSSxXQUFXLENBQUMsQ0FBQyxJQUFJLElBQUksS0FBSztFQUN2RixNQUFNLG1CQUFtQixnQkFBZ0I7RUFDekMsTUFBTSxTQUFTLEtBQUssaUJBQWlCLElBQUksUUFBUTtFQUNqRCxJQUFJLFVBQVUsT0FBTyxPQUFPLGtCQUFrQixPQUFPLE9BQU87RUFDNUQsTUFBTSxDQUFDLGVBQWUsYUFBYSxLQUFLLGlCQUFpQixTQUFTLFFBQVE7RUFDMUUsTUFBTSxZQUFZLEtBQUssYUFBYTtFQUNwQyxNQUFNLG9CQUFvQixFQUFFLEdBQUcsU0FBUyxPQUFPO0VBQy9DLEtBQUssTUFBTSxTQUFTLGVBQWUsSUFBSTtHQUN0QyxPQUFPLE9BQU8sbUJBQW1CLGVBQWUsTUFBTSxRQUFRLGdCQUFnQixpQkFBaUIsQ0FBQztFQUNqRyxRQUFRLENBQUM7RUFDVCxNQUFNLGlCQUFpQixrQkFBa0IsZUFBZSxZQUFZLFVBQVUsTUFBTSxlQUFlLGFBQWEsU0FBUztFQUN6SCxJQUFJO0VBQ0osSUFBSSxnQkFBZ0IsU0FBUyxlQUFlO09BQ3ZDO0dBQ0osTUFBTSxlQUFlO0dBQ3JCLEtBQUssTUFBTSxTQUFTLGVBQWUsSUFBSTtJQUN0QyxvQkFBb0IsT0FBTyxZQUFZO0dBQ3hDLFFBQVEsQ0FBQztHQUNULFNBQVM7RUFDVjtFQUNBLE1BQU0sU0FBUztHQUNkO0dBQ0EsVUFBVTtHQUNWO0dBQ0E7RUFDRDtFQUNBLEtBQUssaUJBQWlCLElBQUksVUFBVSxDQUFDLGtCQUFrQixNQUFNLENBQUM7RUFDOUQsT0FBTztDQUNSO0FBQ0Q7QUFDQSxlQUFlLG1CQUFtQixRQUFRLE1BQU0sRUFBRSxTQUFTLGlCQUFpQjtDQUMzRSxJQUFJLG9CQUFvQixNQUFNLE9BQU8saUJBQWlCLEdBQUc7RUFDYixRQUFRLEtBQUssNkNBQTZDLE1BQU07RUFDM0c7Q0FDRDtDQUNBLElBQUksQ0FBQyxlQUFlO0VBQ25CLE1BQU0sV0FBVyxPQUFPLFFBQVEsYUFBYTtFQUM3QyxLQUFLLE1BQU0sV0FBVyxVQUFVLElBQUksU0FBUyxXQUN4QztPQUFBLE1BQU0sUUFBUSxVQUFVO0lBQzNCLGlCQUFpQixPQUFPLFFBQVE7SUFDaEMsY0FBYyxPQUFPLFFBQVE7SUFDN0IsUUFBUSxVQUFVLFlBQVk7R0FDL0IsQ0FBQyxHQUFHO0VBQUE7Q0FFTjtDQUNBLE9BQU8sUUFBUSwwQkFBMEIsSUFBSTtDQUM3QyxJQUFJLFNBQVMsT0FBTyxTQUFTLFFBQVEsSUFBSTtNQUNwQyxPQUFPLFNBQVMsT0FBTztBQUM3QjtBQU9DLFdBQVcsVUFBVSxxQkFBcUI7QUFDMUMsV0FBVyxVQUFVLGdCQUFnQixpQkFBaUI7Q0FDckQsS0FBSyxnQkFBZ0IsS0FBSztDQUMxQixLQUFLLHFCQUFxQjtDQUMxQixNQUFNLG1CQUFtQixJQUFJO0FBQzlCOztBQUdELElBQUksbUJBQW1CLGNBQWMsTUFBTSxDQUFDOztBQUU1QyxJQUFJLGlCQUFpQixjQUFjLE1BQU0sQ0FBQztBQUMxQyxJQUFNQSxlQUFhLFFBQVEsSUFBSSxTQUFTLEdBQUcsS0FBSyxJQUFJLFNBQVMsSUFBSSxJQUFJLE1BQU0sR0FBRyxFQUFFLElBQUk7QUFDcEYsU0FBUyxhQUFhLEdBQUcsR0FBRztDQUMzQixPQUFPQSxZQUFVLENBQUMsTUFBTUEsWUFBVSxDQUFDO0FBQ3BDOzs7OztBQUtBLFNBQVMsT0FBTyxJQUFJLEtBQUs7Q0FDeEIsT0FBTyxPQUFPLEdBQUcsU0FBUztFQUN6QixRQUFRLE1BQU0sR0FBRyxFQUFBLENBQUcsT0FBTyxVQUFVLENBQUMsR0FBRyxJQUFJO0NBQzlDO0FBQ0Q7QUFXQSxTQUFTLGVBQWUsZ0JBQWdCLE9BQU87Q0FDOUMsSUFBSSxrQkFBa0IsTUFBTSxPQUFPLENBQUM7Q0FDcEMsSUFBSSxlQUFlLGdCQUFnQjtFQUNsQyxNQUFNLFNBQVMsZUFBZSxZQUFZLENBQUMsU0FBUyxLQUFLO0VBQ3pELElBQUksa0JBQWtCLFNBQVMsTUFBTSxJQUFJLGlCQUFpQixnQ0FBZ0M7RUFDMUYsSUFBSSxPQUFPLFFBQVEsTUFBTSxJQUFJLGlCQUFpQixLQUFLLFVBQVUsT0FBTyxRQUFRLEtBQUssR0FBRyxDQUFDLEdBQUcsRUFBRSxPQUFPLE9BQU8sQ0FBQztFQUN6RyxPQUFPLE9BQU87Q0FDZjtDQUNBLElBQUksV0FBVyxnQkFBZ0IsT0FBTyxlQUFlLE1BQU0sS0FBSztDQUNoRSxJQUFJLE9BQU8sbUJBQW1CLFlBQVksT0FBTyxlQUFlLEtBQUs7Q0FDckUsT0FBTyxDQUFDO0FBQ1Q7QUFDQSxTQUFTLGtCQUFrQixNQUFNLE1BQU07Q0FDdEMsSUFBSSxTQUFTLEtBQUssS0FBSyxTQUFTLE1BQU0sT0FBTztDQUM3QyxNQUFNLE9BQU8sT0FBTyxPQUFPLElBQUk7Q0FDL0IsSUFBSSxTQUFTLFNBQVMsU0FBUyxNQUFNLE9BQU87Q0FDNUMsSUFBSSxPQUFPLFNBQVMsWUFBWTtFQUMvQixPQUFPLE9BQU8sTUFBTSxJQUFJO0VBQ3hCLE9BQU8sT0FBTyxPQUFPLE1BQU0sS0FBSyxJQUFJLENBQUM7Q0FDdEM7Q0FDQSxPQUFPLE9BQU8sT0FBTyxNQUFNLE1BQU0sSUFBSTtBQUN0QztBQUNBLFNBQVMscUJBQXFCLE1BQU0sZUFBZTtDQUNsRCxJQUFJLE9BQU8sU0FBUyxZQUFZLE9BQU87Q0FDdkMsSUFBSSxDQUFDLGlCQUFpQixTQUFTLFNBQVMsU0FBUyxNQUFNLE9BQU87Q0FDOUQsT0FBTyxTQUFTLEtBQUssS0FBSyxTQUFTLFFBQVEsY0FBYyxNQUFNLFNBQVMsT0FBTyxTQUFTLFlBQVksQ0FBQyxPQUFPLEtBQUssTUFBTSxLQUFLLEVBQUUsQ0FBQztBQUNoSTtBQUNBLElBQU0sZUFBZSxPQUFPLE9BQU8sQ0FBQyxDQUFDO0FBQ3JDLFNBQVMscUJBQXFCLFlBQVksdUJBQXVCO0NBQ2hFLE1BQU0sY0FBYyxDQUFDO0NBQ3JCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsS0FBSztFQUMzQyxNQUFNLGVBQWUsV0FBVyxFQUFFLENBQUM7RUFDbkMsSUFBSSxZQUFZLGNBQ1g7T0FBQSxhQUFhLFFBQVEsYUFBYSxZQUFZLEtBQUssR0FBRyxhQUFhLE9BQU8sV0FBVztFQUFBLE9BQ25GLElBQUksYUFBYSxvQkFBb0IsYUFBYSxtQkFBbUI7R0FDM0UsTUFBTSxvQkFBb0IsRUFBRSxRQUFRLFdBQVc7SUFDOUMsTUFBTSxTQUFTLEtBQUssYUFBYSxtQkFBbUIsYUFBYSxpQkFBaUIsUUFBUSxNQUFNLFNBQVMsS0FBSyxJQUFJLEdBQUcsTUFBTSxJQUFJLE1BQU07SUFDckksT0FBTyxhQUFhLG9CQUFvQixhQUFhLGtCQUFrQixRQUFRLE1BQU0sU0FBUyxLQUFLLElBQUksR0FBRyxNQUFNLElBQUk7R0FDckg7R0FDQSxZQUFZLEtBQUssZ0JBQWdCO0VBQ2xDO0VBQ0EsTUFBTSxzQkFBc0IsYUFBYTtFQUN6QyxJQUFJLHlCQUF5QixxQkFBcUI7R0FDakQsTUFBTSxZQUFZLEVBQUUsUUFBUSxNQUFNLFdBQVc7SUFDNUMsTUFBTSxTQUFTLEtBQUssTUFBTTtJQUMxQixJQUFJO0tBQ0gsTUFBTSxZQUFZLGVBQWUscUJBQXFCLE1BQU07S0FDNUQsSUFBSSxRQUFRLFdBQ047V0FBQSxNQUFNLE9BQU8sV0FBVyxJQUFJLEVBQUUsT0FBTyxTQUFTLENBQUMsS0FBSyw4QkFBOEIsSUFBSSxJQUFJLEVBQUEsQ0FBRyxJQUFJLEtBQUssVUFBVSxJQUFJO0tBQUE7S0FFMUgsT0FBTztNQUNOLEdBQUc7TUFDSCxHQUFHO0tBQ0o7SUFDRCxRQUFRLENBQUM7SUFDVCxPQUFPO0dBQ1I7R0FDQSxZQUFZLEtBQUssUUFBUTtFQUMxQjtDQUNEO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxzQkFBc0IsYUFBYSxRQUFRLE1BQU07Q0FDekQsTUFBTSxhQUFhLE9BQU8sZUFBZSxTQUFTO0VBQ2pELElBQUksU0FBUyxZQUFZLFFBQVE7R0FDaEMsSUFBSSxDQUFDLEtBQUssUUFBUSxPQUFPLENBQUM7R0FDMUIsSUFBSSxLQUFLLFdBQVcsTUFBTSxPQUFPO0dBQ2pDLE1BQU0sU0FBUyxpQkFBaUIsS0FBSyxRQUFRLGFBQWE7R0FDMUQsSUFBSSxNQUFNLEtBQUssV0FBVztHQUMxQixPQUFPO0VBQ1I7RUFDQSxNQUFNLFFBQVEsV0FBVyxnQkFBZ0I7R0FDeEMsSUFBSSxhQUFhO0lBQ2hCLE1BQU0sV0FBVyxRQUFRLENBQUM7SUFDMUIsT0FBTztLQUNOLFFBQVEsVUFBVSxRQUFRLEdBQUcsV0FBVyxRQUFRO0tBQ2hELE1BQU07SUFDUDtHQUNEO0dBQ0EsT0FBTyxVQUFVLFFBQVEsR0FBRyxXQUFXLElBQUk7RUFDNUM7RUFDQSxPQUFPLFlBQVksTUFBTSxDQUFDO0dBQ3pCLFFBQVE7R0FDUjtHQUNBO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsT0FBTyxVQUFVLEdBQUcsTUFBTTtBQUMzQjtBQUNBLFNBQVMsMEJBQTBCLGNBQWMsUUFBUTtDQUN4RCxJQUFJLGlCQUFpQixRQUFRO0VBQzVCLElBQUk7RUFDSixLQUFLLElBQUksSUFBSSxPQUFPLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztHQUM1QyxNQUFNLFFBQVEsT0FBTztHQUNyQixJQUFJLE1BQU0sUUFBUSxtQkFBbUIsT0FBTyxNQUFNO0dBQ2xELGFBQWEsTUFBTSxZQUFZLE1BQU07RUFDdEM7RUFDQSxJQUFJLFVBQVUsT0FBTztDQUN0QjtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsb0JBQW9CLE9BQU8sbUJBQW1CO0NBQ3RELE1BQU0sY0FBYyxNQUFNLFFBQVEsUUFBUSxTQUFTLE1BQU0sUUFBUTtDQUNqRSxJQUFJLGFBQWEsT0FBTyxPQUFPLG1CQUFtQixZQUFZLGlCQUFpQixDQUFDO0FBQ2pGOztBQzE4QkEsU0FBUyxrQkFBa0IsT0FBTyxRQUFRO0NBQ3pDLE1BQU0sU0FBUyxVQUFVLE1BQU07Q0FDL0IsTUFBTSxRQUFRLEtBQUs7QUFDcEI7QUFDQSxTQUFTLGlCQUFpQixPQUFPLE1BQU07Q0FDdEMsT0FBTyxNQUFNLFFBQVEsS0FBSyxFQUFFLFVBQVU7QUFDdkM7QUFDQSxTQUFTLGVBQWUsT0FBTyxnQkFBZ0I7Q0FDOUMsTUFBTSxZQUFZLGlCQUFpQixPQUFPLFdBQVc7Q0FDckQsSUFBSSxVQUFVLGlCQUFpQixPQUFPLGtCQUFrQjtDQUN4RCxJQUFJLGdCQUFnQjtFQUNuQixJQUFJLFNBQVMsVUFBVSxRQUFRLEtBQUssY0FBYztPQUM3QyxlQUFlO0NBQ3JCO0NBQ0EsSUFBSSxhQUFhLFNBQVMsT0FBTyxRQUFRLElBQUksQ0FBQyxXQUFXLE9BQU8sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7Q0FDaEYsT0FBTyxhQUFhO0FBQ3JCO0FBQ0EsU0FBUyxlQUFlLE9BQU8sZUFBZSxnQkFBZ0I7Q0FDN0QsTUFBTSxrQkFBa0Isa0JBQWtCLFFBQVEsS0FBSyxJQUFJLGdCQUFnQixpQkFBaUIsT0FBTyxhQUFhLElBQUksZUFBZSxPQUFPLGNBQWM7Q0FDeEosTUFBTSxVQUFVLE1BQU07Q0FDdEIsSUFBSSxTQUFTLE9BQU8sWUFBWSxPQUFPLFVBQVUsSUFBSSxRQUFRLEtBQUssU0FBUztDQUMzRSxJQUFJLENBQUMsTUFBTSxRQUFRLE9BQU8sVUFBVTtDQUNwQyxNQUFNLFVBQVUsTUFBTSxPQUFPLENBQUMsQ0FBQyxNQUFNLGNBQWM7RUFDbEQsSUFBNkMsTUFBTSxVQUFVLFNBQVM7R0FDckUsTUFBTSxFQUFFLElBQUksS0FBSyxHQUFHLFlBQVksVUFBVTtHQUMxQyxPQUFPLE9BQU8sTUFBTSxTQUFTLE9BQU87R0FDcEMsTUFBTSxRQUFRO0VBQ2Y7Q0FDRCxJQUFJLFVBQVU7RUFDYixJQUE2QyxNQUFNLFVBQVUsU0FBUyxNQUFNLFFBQVEsS0FBSztFQUN6RixNQUFNO0NBQ1AsQ0FBQztDQUNELE1BQU0sUUFBUTtDQUNkLE9BQU8sUUFBUSxLQUFLLFNBQVM7QUFDOUI7O0FBRUEsU0FBUyxvQkFBb0IsU0FBUztDQUNyQyxNQUFNLE1BQU0sUUFBUSxXQUFXLFVBQVUsTUFBTSxXQUFXLGFBQWEsTUFBTSxTQUFTLElBQUk7Q0FDMUYsT0FBTyxPQUFPLE1BQU0sUUFBUSxTQUFTLFFBQVEsTUFBTSxHQUFHLEdBQUcsSUFBSTtBQUM5RDs7Ozs7Ozs7OztBQVVBLFNBQVMsa0JBQWtCLFFBQVEsU0FBUyxVQUFVO0NBQ3JELE1BQU0sS0FBSyxPQUFPO0NBQ2xCLE9BQU8sV0FBVyxLQUFLLE9BQU8sWUFBWSxDQUFDLEdBQUcsRUFBRSxDQUFDLE1BQU0sVUFBVSxNQUFNLFlBQVksT0FBTztBQUMzRjs7QUFFQSxTQUFTLGlCQUFpQixTQUFTO0NBQ2xDLElBQUksTUFBTSxRQUFRO0NBQ2xCLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxLQUFLLFNBQVM7RUFDekMsTUFBTSxRQUFRLFFBQVE7RUFDdEIsSUFBSSxNQUFNLGNBQWMsS0FBSyxHQUFHO0dBQy9CLE1BQU0sS0FBSyxJQUFJLEtBQUssS0FBSyxJQUFJLFFBQVEsR0FBRyxNQUFNLFNBQVMsQ0FBQztHQUN4RDtFQUNEO0VBQ0EsSUFBSSxNQUFNLFdBQVcsYUFBYSxNQUFNLFdBQVc7R0FDbEQsTUFBTSxRQUFRO0dBQ2Q7RUFDRDtDQUNEO0NBQ0EsT0FBTyxNQUFNLFFBQVEsU0FBUyxRQUFRLE1BQU0sR0FBRyxHQUFHLElBQUk7QUFDdkQ7QUFDQSxJQUFNQyxZQUFVO0FBQ2hCLElBQU1DLFVBQVE7QUFDZCxJQUFNQyxjQUFZO0FBQ2xCLElBQU1DLGVBQWE7QUFDbkIsSUFBTSxtQkFBbUIsQ0FBQyxDQUFDO0FBQzNCLFNBQVMsVUFBVSxRQUFRO0NBQzFCLE9BQU8sT0FBTyxPQUFPLE9BQU87QUFDN0I7QUFDQSxTQUFTQyxVQUFRLE9BQU8sUUFBUTtDQUMvQixJQUFJLE9BQU8sU0FBUyxPQUFPLFFBQVEsS0FBSyxDQUFDLFFBQVEsT0FBTyxNQUFNLEdBQUcsS0FBSyxDQUFDO0NBQ3ZFLE9BQU8sSUFBSSxTQUFTLFNBQVMsV0FBVztFQUN2QyxNQUFNLGNBQWMsT0FBTyxNQUFNO0VBQ2pDLE9BQU8saUJBQWlCLFNBQVMsT0FBTyxFQUFFLE1BQU0sS0FBSyxDQUFDO0VBQ3RELFFBQVEsUUFBUSxLQUFLLENBQUMsQ0FBQyxLQUFLLFNBQVMsTUFBTSxDQUFDLENBQUMsV0FBVyxPQUFPLG9CQUFvQixTQUFTLEtBQUssQ0FBQztDQUNuRyxDQUFDO0FBQ0Y7QUFDQSxTQUFTQyxXQUFTLFFBQVEsT0FBTztDQUNoQyxPQUFPLE9BQU8sV0FBVyxNQUFNO0FBQ2hDO0FBQ0EsU0FBU0MsWUFBVSxPQUFPLFVBQVUsU0FBUztDQUM1QyxJQUFJLFdBQVcsS0FBSyxHQUFHLE9BQU8sQ0FBQ0gsY0FBWSxLQUFLO0NBQ2hELElBQUksV0FBVyxLQUFLLEdBQUc7RUFDdEIsTUFBTSxZQUFZO0VBQ2xCLE9BQU8sQ0FBQ0QsYUFBVyxLQUFLO0NBQ3pCO0NBQ0EsSUFBSSxDQUFDLFVBQVUsT0FBTyxDQUFDRixXQUFTLEtBQUs7Q0FDckMsSUFBSSxPQUFPLE9BQU8sU0FBUyxZQUFZLFFBQVEsSUFBSSxNQUFNLHdCQUF3QixFQUFFLE9BQU8sTUFBTSxDQUFDO0NBQ2pHLE9BQU8sQ0FBQ0MsU0FBTyxLQUFLO0FBQ3JCO0FBQ0EsU0FBU00saUJBQWUsT0FBTyxPQUFPO0NBQ3JDLElBQUksVUFBVUQsWUFBVSxPQUFPLE1BQU0sTUFBTSxFQUFFO0NBQzdDLElBQUksUUFBUSxPQUFPTCxTQUFPLE9BQU87Q0FDakMsSUFBSTtFQUNILE1BQU0sUUFBUSxVQUFVLFFBQVEsRUFBRTtDQUNuQyxTQUFTLGNBQWM7RUFDdEIsVUFBVUssWUFBVSxjQUFjLE1BQU0sTUFBTSxFQUFFO0NBQ2pEO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxtQkFBbUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxTQUFTO0NBQ2hFLElBQUksUUFBUSxFQUFFLENBQUMsT0FBTyxTQUFTLE9BQU87Q0FDdEMsT0FBT0Usc0JBQW9CLFFBQVEsTUFBTSxPQUFPRCxpQkFBZSxPQUFPLEtBQUssR0FBRyxPQUFPO0FBQ3RGO0FBQ0EsZUFBZUUsZ0JBQWMsUUFBUSxNQUFNLFNBQVMsS0FBSyxvQkFBb0IsYUFBYTtDQUN6RixNQUFNLENBQUMsVUFBVSxXQUFXO0NBQzVCLE1BQU0sU0FBUyxRQUFRLEVBQUUsQ0FBQztDQUMxQixNQUFNLFVBQVUsQ0FBQyxDQUFDLFFBQVE7Q0FDMUIsS0FBSyxJQUFJLFFBQVEsUUFBUSxNQUFNLEdBQUcsUUFBUSxLQUFLLFNBQVM7RUFDdkQsTUFBTSxRQUFRLFFBQVE7RUFDdEIsTUFBTSxRQUFRSixXQUFTLFFBQVEsS0FBSztFQUNwQyxNQUFNLGtCQUFrQixRQUFRO0VBQ2hDLE1BQU0sZ0JBQWdCLFFBQVEsUUFBUSxFQUFFLEVBQUUsV0FBVyxPQUFPLFFBQVEsV0FBVyxDQUFDO0VBQ2hGLE1BQU0sU0FBUztHQUNkLFFBQVEsTUFBTTtHQUNkO0dBQ0EsV0FBVyxTQUFTLE9BQU8sU0FBUztJQUNuQyxHQUFHO0lBQ0gsZUFBZTtHQUNoQixDQUFDO0dBQ0QsZUFBZSxPQUFPO0dBQ3RCLE9BQU8sVUFBVSxZQUFZLE1BQU07R0FDbkMsaUJBQWlCLFFBQVE7R0FDekI7R0FDQTtHQUNBLFNBQVMsTUFBTTtFQUNoQjtFQUNBLElBQUk7R0FDSCxNQUFNLGVBQWUsTUFBTSxTQUFTLE1BQU0sUUFBUSxVQUFVLE1BQU0sUUFBUSxRQUFRO0lBQ2pGLEdBQUc7SUFDSCxNQUFNLE1BQU07SUFDWixTQUFTO0dBQ1YsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLO0dBQ2hCLE1BQU0sVUFBVTtJQUNmLEdBQUc7SUFDSCxHQUFHO0dBQ0o7RUFDRCxTQUFTLE9BQU87R0FDZixjQUFjLFFBQVEsS0FBSztHQUMzQixPQUFPLENBQUMsT0FBTyxtQkFBbUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxPQUFPLENBQUM7RUFDdkU7RUFDQSxJQUFJLE9BQU8sU0FBUyxPQUFPLENBQUMsT0FBTyxnQkFBZ0I7RUFDbkQsTUFBTSxrQkFBa0IsTUFBTSxlQUFlLE1BQU07RUFDbkQsSUFBSSxvQkFBb0IsS0FBSyxHQUFHO0dBQy9CLGNBQWMsUUFBUSxLQUFLO0dBQzNCLE9BQU8sQ0FBQyxPQUFPLG1CQUFtQixRQUFRLE1BQU0sT0FBTyxpQkFBaUIsT0FBTyxDQUFDO0VBQ2pGO0VBQ0EsTUFBTSxhQUFhLE1BQU0sUUFBUTtFQUNqQyxJQUFJLENBQUMsWUFBWTtFQUNqQixNQUFNLGlCQUFpQixNQUFNO0VBQzdCLElBQUksU0FBUyxhQUFhO0dBQ3pCLE1BQU0sU0FBUztHQUNmLFFBQVEsRUFBRSxHQUFHO0VBQ2Q7RUFDQSxJQUFJO0dBQ0gsWUFBWSxRQUFRLE9BQU8sY0FBYyxRQUFRLEVBQUU7R0FDbkQsTUFBTSxRQUFRLFdBQVc7SUFDeEIsR0FBRztJQUNILFFBQVEsTUFBTTtJQUNkLFNBQVMsTUFBTTtJQUNmLEdBQUcsT0FBTyxRQUFRO0dBQ25CLENBQUM7R0FDRCxNQUFNLFNBQVMsT0FBTyxPQUFPLE9BQU8sU0FBUyxhQUFhRCxVQUFRLE9BQU8sTUFBTSxJQUFJO0dBQ25GLElBQUksT0FBTyxTQUFTLE9BQU8sQ0FBQyxPQUFPLGdCQUFnQjtHQUNuRCxNQUFNLFVBQVVJLHNCQUFvQixRQUFRLE1BQU0sT0FBT0YsWUFBVSxRQUFRLE9BQU8sTUFBTSxFQUFFLEdBQUcsT0FBTztHQUNwRyxJQUFJLFFBQVEsT0FBT04sV0FBUztJQUMzQixjQUFjLFFBQVEsS0FBSztJQUMzQixPQUFPLENBQUMsT0FBTyxPQUFPO0dBQ3ZCO0dBQ0EsTUFBTSxVQUFVO0lBQ2YsR0FBRyxNQUFNO0lBQ1QsR0FBRztHQUNKO0VBQ0QsU0FBUyxPQUFPO0dBQ2YsY0FBYyxRQUFRLEtBQUs7R0FDM0IsT0FBTyxDQUFDLE9BQU8sbUJBQW1CLFFBQVEsTUFBTSxPQUFPLE9BQU8sT0FBTyxDQUFDO0VBQ3ZFLFVBQVU7R0FDVCxNQUFNLFNBQVM7R0FDZixZQUFZLFFBQVEsT0FBTyxPQUFPLFFBQVEsRUFBRTtFQUM3QztDQUNEO0NBQ0EsbUJBQW1CO0FBQ3BCO0FBQ0EsU0FBUyxtQkFBbUIsUUFBUSxPQUFPLFFBQVE7Q0FDbEQsSUFBSSxDQUFDLFVBQVUsRUFBRSxPQUFPLElBQUk7Q0FDNUIsSUFBSSxPQUFPLFVBQVUsSUFBSSxNQUFNLEVBQUUsTUFBTSxRQUFRO0VBQzlDLE1BQU0sVUFBVSxPQUFPO0VBQ3ZCLElBQUksV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDLFNBQVMsS0FBSyxLQUFLLFFBQVEsRUFBRSxDQUFDLE1BQU0sY0FBYyxVQUFVLE9BQU8sTUFBTSxFQUFFLEtBQUssUUFBUSxFQUFFLENBQUMsTUFBTSxjQUFjLFVBQVUsZUFBZSxZQUFZLEdBQUc7RUFDaE4sT0FBTyxTQUFTLE9BQU8sTUFBTSxFQUFFO0NBQ2hDO0NBQ0EsT0FBTyxPQUFPO0FBQ2Y7QUFDQSxTQUFTLGNBQWMsUUFBUSxPQUFPO0NBQ3JDLE1BQU0sU0FBUyxNQUFNO0NBQ3JCLE1BQU0sVUFBVSxLQUFLO0NBQ3JCLG1CQUFtQixRQUFRLE9BQU8sTUFBTSxDQUFDLEVBQUUsTUFBTTtBQUNsRDs7Ozs7QUFLQSxTQUFTLHVCQUF1QixRQUFRLFVBQVUsTUFBTSxtQkFBbUI7Q0FDMUUsTUFBTSxRQUFRLENBQUM7Q0FDZixLQUFLLE1BQU0sU0FBUyxVQUFVLElBQUksQ0FBQyxNQUFNLFNBQVMsS0FBSyxHQUFHO0VBQ3pELE1BQU0sU0FBUyxNQUFNO0VBQ3JCLE1BQU0sVUFBVSxLQUFLO0VBQ3JCLElBQUkscUJBQXFCLFNBQVMsT0FBTyxLQUFLLE9BQU8sVUFBVSxJQUFJLE1BQU0sRUFBRSxNQUFNLFVBQVUsTUFBTSxNQUFNLGNBQWMsVUFBVSxPQUFPLE1BQU0sRUFBRSxHQUFHLE9BQU8sS0FBSztPQUN4SjtHQUNKLE1BQU0sYUFBYSxtQkFBbUIsUUFBUSxPQUFPLE1BQU07R0FDM0QsSUFBSSxZQUFZLE1BQU0sS0FBSyxVQUFVO0VBQ3RDO0NBQ0Q7Q0FDQSxLQUFLLE1BQU0sY0FBYyxPQUFPLFdBQVcsTUFBTTtBQUNsRDtBQUNBLFNBQVMsc0JBQXNCLFNBQVM7Q0FDdkMsS0FBSyxNQUFNLFNBQVMsU0FBUztFQUM1QixNQUFNLFNBQVMsTUFBTTtFQUNyQixJQUFJLFFBQVEsT0FBTyxFQUFFO0NBQ3RCO0FBQ0Q7QUFDQSxTQUFTLFlBQVksUUFBUSxPQUFPLE9BQU8sT0FBTztDQUNqRCxNQUFNLGFBQWE7Q0FDbkIsSUFBSSxTQUFTLE9BQU8sTUFBTSxPQUFPLE9BQU87Q0FDeEMsTUFBTSxRQUFRLE9BQU8sT0FBTyxRQUFRLElBQUksTUFBTSxPQUFPO0NBQ3JELE1BQU0sWUFBWSxPQUFPLElBQUk7Q0FDN0IsSUFBSSxXQUFXLE9BQU8sTUFBTSxJQUFJLE1BQU0sSUFBSTtFQUN6QyxHQUFHO0VBQ0gsWUFBWTtDQUNiLENBQUM7QUFDRjtBQUNBLFNBQVNVLG1CQUFpQixRQUFRLE1BQU0sT0FBTyxPQUFPLFlBQVksb0JBQW9CLFNBQVM7Q0FDOUYsTUFBTSxXQUFXLEtBQUs7Q0FDdEIsT0FBTztFQUNOLFFBQVEsTUFBTTtFQUNkO0VBQ0EsV0FBVyxTQUFTLE9BQU8sU0FBUztHQUNuQyxHQUFHO0dBQ0gsZUFBZTtFQUNoQixDQUFDO0VBQ0QsT0FBTyxVQUFVLFlBQVksTUFBTTtFQUNuQyxpQkFBaUI7RUFDakI7RUFDQSxNQUFNLE1BQU07RUFDWjtFQUNBLFNBQVMsTUFBTTtFQUNmO0VBQ0EsR0FBRyxPQUFPLFFBQVE7Q0FDbkI7QUFDRDtBQUNBLGVBQWUsYUFBYSxRQUFRLE1BQU0sT0FBTyxPQUFPLFFBQVEsb0JBQW9CLFNBQVM7Q0FDNUYsTUFBTSxRQUFRLFFBQVE7Q0FDdEIsTUFBTSxTQUFTLE1BQU07Q0FDckIsSUFBSSxPQUFPLFNBQVMsT0FBTztDQUMzQixJQUFJLENBQUMsUUFBUSxPQUFPLENBQUNWLFdBQVMsS0FBSyxDQUFDO0NBQ3BDLElBQUksU0FBUyxNQUFNO0NBQ25CLFlBQVksUUFBUSxPQUFPLFVBQVUsS0FBSztDQUMxQyxJQUFJO0VBQ0gsSUFBSSxDQUFDLFFBQVE7R0FDWixNQUFNLGFBQWEsSUFBSSxnQkFBZ0I7R0FDdkMsU0FBUztJQUNSLFFBQVEsUUFBUSxDQUFDLENBQUMsV0FBVyxPQUFPVSxtQkFBaUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxZQUFZLG9CQUFvQixDQUFDLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxVQUFVSixZQUFVLE9BQU8sT0FBTyxNQUFNLEVBQUUsSUFBSSxVQUFVQSxZQUFVLE9BQU8sTUFBTSxNQUFNLEVBQUUsQ0FBQyxDQUFDLENBQUMsTUFBTSxXQUFXO0tBQ2pQLElBQUksT0FBTyxPQUFPTixhQUFXLE9BQU8sVUFBVSxJQUFJLE1BQU0sRUFBRSxNQUFNLFFBQVE7TUFDdkUsT0FBTyxTQUFTLE9BQU8sTUFBTSxFQUFFO01BQy9CLElBQUksQ0FBQyxPQUFPLElBQUksV0FBVyxNQUFNO0tBQ2xDO0tBQ0EsT0FBTyxPQUFPLE9BQU9DLFdBQVMsT0FBTyxLQUFLTSxpQkFBZSxPQUFPLE9BQU8sRUFBRSxJQUFJO0lBQzlFLENBQUM7SUFDRDtJQUNBO0dBQ0Q7R0FDQSxDQUFDLE9BQU8sNkJBQTZCLElBQUksSUFBSSxFQUFBLENBQUcsSUFBSSxNQUFNLElBQUksTUFBTTtFQUNyRTtFQUNBLE1BQU0sVUFBVTtFQUNoQixNQUFNLGtCQUFrQixPQUFPO0VBQy9CLE9BQU9DLHNCQUFvQixRQUFRLE1BQU0sT0FBTyxNQUFNSixVQUFRLE9BQU8sSUFBSSxNQUFNLEdBQUcsT0FBTztDQUMxRixTQUFTLE9BQU87RUFDZixJQUFJLFVBQVUsVUFBVSxDQUFDLE9BQU8sU0FBUyxNQUFNO0VBQy9DLGNBQWMsUUFBUSxLQUFLO0VBQzNCLE9BQU87Q0FDUixVQUFVO0VBQ1QsWUFBWSxRQUFRLE9BQU8sT0FBTyxLQUFLO0NBQ3hDO0FBQ0Q7QUFDQSxTQUFTLFdBQVcsT0FBTyxRQUFRLFNBQVM7Q0FDM0MsSUFBSSxPQUFPLE9BQU9ELGNBQVk7Q0FDOUIsTUFBTSxTQUFTO0NBQ2YsTUFBTSxRQUFRLEtBQUs7Q0FDbkIsSUFBSSxPQUFPLE9BQU9ILFdBQVM7RUFDMUIsTUFBTSxhQUFhLE9BQU87RUFDMUIsTUFBTSxVQUFVO0VBQ2hCLE1BQU0sWUFBWSxLQUFLLElBQUk7RUFDM0IsTUFBTSxVQUFVO0NBQ2pCLE9BQU8sTUFBTSxVQUFVO0FBQ3hCO0FBQ0EsU0FBUyxpQkFBaUIsUUFBUSxPQUFPLFNBQVM7Q0FDakQsTUFBTSxVQUFVLE9BQU8sT0FBTyxJQUFJLE1BQU0sRUFBRTtDQUMxQyxJQUFJLFlBQVksV0FBVyxPQUFPLFdBQVcsTUFBTSxjQUFjLFVBQVUsT0FBTyxNQUFNLE1BQU0sVUFBVSxZQUFZLE1BQU0sT0FBTyxHQUFHO0NBQ3BJLE1BQU0sU0FBUztFQUNkLEdBQUc7RUFDSCxXQUFXLEtBQUs7RUFDaEIsU0FBUyxDQUFDO0NBQ1g7Q0FDQSxJQUFJLE9BQU8sU0FBUyxPQUFPLFFBQVEsRUFBRTtDQUNyQyxPQUFPLE9BQU8sSUFBSSxNQUFNLElBQUksTUFBTTtDQUNsQyxJQUFJLFNBQVMsY0FBYyxRQUFRLE9BQU87QUFDM0M7QUFDQSxTQUFTLGtCQUFrQixPQUFPLFNBQVM7Q0FDMUMsSUFBSSxRQUFRLE9BQU9DLFdBQVMsUUFBUSxPQUFPQyxhQUFXLE9BQU87RUFDNUQsR0FBRztFQUNILFFBQVEsUUFBUSxPQUFPRCxVQUFRLFVBQVU7RUFDekMsT0FBTyxRQUFRO0VBQ2YsU0FBUyxLQUFLO0NBQ2Y7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTVSxtQkFBaUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxnQkFBZ0IsU0FBUyxhQUFhO0NBQzNGLE1BQU0sUUFBUSxLQUFLLEVBQUUsQ0FBQztDQUN0QixNQUFNLFFBQVFOLFdBQVMsUUFBUSxLQUFLO0NBQ3BDLE1BQU0sVUFBVSxDQUFDLENBQUMsUUFBUTtDQUMxQixNQUFNLG9CQUFvQixPQUFPLE9BQU8sSUFBSSxNQUFNLEVBQUU7Q0FDcEQsSUFBSTtDQUNKLElBQUksU0FBUztDQUNiLElBQUk7Q0FDSixJQUFJO0VBQ0gsSUFBSSxNQUFNLFdBQVcsV0FBVztHQUMvQixhQUFhLE1BQU0sUUFBUTtHQUMzQixJQUFJLE9BQU8sZUFBZSxZQUFZLGFBQWEsV0FBV0ssbUJBQWlCLFFBQVEsTUFBTSxPQUFPLE9BQU8sUUFBUSxJQUFJLGdCQUFnQixPQUFPLENBQUM7R0FDL0ksSUFBSSxRQUFRLEVBQUUsQ0FBQyxPQUFPLFNBQVMsZ0JBQWdCO0VBQ2hEO0VBQ0EsSUFBSSxDQUFDLGVBQWU7R0FDbkIsSUFBSSxNQUFNLFdBQVcsV0FBVyxTQUFTO1FBQ3BDO0lBQ0osTUFBTSxXQUFXLFdBQVcsTUFBTSxVQUFVLE1BQU0sUUFBUSxvQkFBb0IsT0FBTyxRQUFRLDJCQUEyQixNQUFNLE1BQU0sUUFBUSxhQUFhLE9BQU8sUUFBUSxvQkFBb0I7SUFDNUwsU0FBUyxDQUFDLEVBQUUsTUFBTSxXQUFXLGNBQWMsZUFBZSxLQUFLLEtBQUssS0FBSyxJQUFJLElBQUksTUFBTSxhQUFhLGFBQWEsUUFBUSxNQUFNLE1BQU0sVUFBVSxXQUFXLFFBQVEsRUFBRSxDQUFDLE1BQU0sY0FBYyxVQUFVLFlBQVksTUFBTSxXQUFXLFVBQVUsT0FBTyxNQUFNLEVBQUU7R0FDMVA7RUFDRDtDQUNELFNBQVMsT0FBTztFQUNmLE1BQU0sVUFBVTtFQUNoQixjQUFjLFFBQVEsS0FBSztFQUMzQixnQkFBZ0IsbUJBQW1CLFFBQVEsTUFBTSxPQUFPLE9BQU8sT0FBTztDQUN2RTtDQUNBLE1BQU0sY0FBYyxNQUFNLFFBQVE7Q0FDbEMsTUFBTSxhQUFhLE9BQU8sZ0JBQWdCO0NBQzFDLE1BQU0sU0FBUyxhQUFhLGNBQWMsYUFBYTtDQUN2RCxNQUFNLGNBQWMsQ0FBQyxXQUFXLE1BQU0sUUFBUSxZQUFZO0NBQzFELElBQUksUUFBUSxlQUFlLGVBQWUsQ0FBMkMsT0FBTyxNQUFNLEtBQU0sT0FBTyxVQUFVLElBQUksTUFBTSxFQUFFLElBQUksS0FBSztDQUM5SSxJQUFJLFVBQVUsTUFBTSxXQUFXLGVBQWUsUUFBUSxLQUFLO01BQ3RELElBQUksU0FBUyxDQUFDLFVBQVUsQ0FBQyxXQUFXLGVBQWUsS0FBSyxHQUFHLFNBQVM7TUFDcEUsSUFBSSxDQUFDLFFBQVEsUUFBUSxLQUFLO0NBQy9CLE1BQU0sYUFBYSxDQUFDLEVBQUUsZUFBZSxVQUFVLE1BQU0sV0FBVyxhQUFhLENBQUMsV0FBVyxDQUFDLFFBQVEsUUFBUSxhQUFhLEtBQUssSUFBSSxZQUFZLG9CQUFvQixPQUFPLFFBQVEsNEJBQTRCO0NBQzNNLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sV0FBVyxVQUFVLENBQUMsZUFBZSxNQUFNLFdBQVcsYUFBYSxDQUFDLENBQUM7Q0FDM0UsTUFBTSxVQUFVLFNBQVMsY0FBYyxRQUFRLEtBQUssS0FBSztDQUN6RCxNQUFNLGNBQWMsTUFBTSxVQUFVLE1BQU0sVUFBVSxPQUFPLFVBQVUsS0FBSztDQUMxRSxJQUFJLFVBQVUsQ0FBQyxhQUFhO0VBQzNCLE1BQU0sVUFBVTtFQUNoQixNQUFNLFlBQVksS0FBSyxJQUFJO0NBQzVCO0NBQ0EsSUFBSSxPQUFPLE1BQU0sRUFBRTtDQUNuQixJQUFJLFVBQVU7RUFDYixNQUFNLGlCQUFpQixNQUFNO0VBQzdCLE1BQU0sVUFBVTtFQUNoQixtQkFBbUIsUUFBUSxPQUFPLGNBQWMsQ0FBQyxFQUFFLE1BQU07RUFDekQsSUFBSSxTQUFTLGFBQWEsTUFBTSxTQUFTO0VBQ3pDLFVBQVU7Q0FDWDtDQUNBLElBQUksQ0FBQyxRQUFRLE1BQU0sYUFBYTtDQUNoQyxNQUFNLFVBQVUsQ0FBQyxpQkFBaUIsV0FBVyxhQUFhLFFBQVEsTUFBTSxPQUFPLE9BQU8sUUFBUSxnQkFBZ0IsT0FBTyxDQUFDLENBQUMsTUFBTSxXQUFXO0VBQ3ZJLFdBQVcsT0FBTyxRQUFRLE9BQU87RUFDakMsSUFBSSxPQUFPLE9BQU9WLFdBQVM7R0FDMUIsSUFBSSxlQUFlLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxTQUFTLGlCQUFpQixRQUFRLE9BQU8saUJBQWlCO0dBQ2hHLElBQUksU0FBUyxhQUFhLE1BQU0sU0FBUztFQUMxQztFQUNBLE9BQU87Q0FDUixDQUFDLElBQUksUUFBUSxRQUFRLGlCQUFpQixDQUFDQSxXQUFTLE1BQU0sVUFBVSxDQUFDO0NBQ2pFLE1BQU0sZ0JBQWdCLFlBQVk7RUFDakMsSUFBSTtHQUNILE1BQU0sUUFBUSxlQUFlLE9BQU8sS0FBSyxHQUFHLFdBQVc7R0FDdkQsSUFBSSxPQUFPLE1BQU1JLFVBQVEsT0FBTyxRQUFRLEVBQUUsQ0FBQyxNQUFNO0VBQ2xELFNBQVMsT0FBTztHQUNmLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxNQUFNLFdBQVcsbUJBQW1CLGtCQUFrQixVQUFVLFVBQVUsV0FBVyxXQUFXLFVBQVUsV0FBVyxjQUFjLFVBQVUsVUFBVSxHQUFHLE9BQU8sQ0FBQyxPQUFPLG1CQUFtQixRQUFRLE1BQU0sT0FBTyxPQUFPLE9BQU8sQ0FBQztFQUM5TztFQUNBLE1BQU0sU0FBUyxNQUFNO0VBQ3JCLElBQUksWUFBWSxPQUFPLE9BQU9KLGFBQVcsTUFBTSxXQUFXLGFBQWEsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLFNBQVM7R0FDbEcsTUFBTSxTQUFTO0dBQ2YsVUFBVTtFQUNYO0NBQ0QsRUFBQSxDQUFHO0NBQ0gsTUFBTSxLQUFLO0VBQ1Y7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELElBQUksQ0FBQyxZQUFZLE9BQU8sUUFBUSxNQUFNLFdBQVcsa0JBQWtCLE9BQU8sTUFBTSxDQUFDO0NBQ2pGLE1BQU0sWUFBWTtFQUNqQixHQUFHO0VBQ0gsUUFBUTtFQUNSLFNBQVM7RUFDVCxTQUFTO0NBQ1Y7Q0FDQSxNQUFNLFVBQVU7Q0FDaEIsTUFBTSxhQUFhO0NBQ25CLE1BQU0sb0JBQW9CLGFBQWEsUUFBUSxNQUFNLFdBQVcsT0FBTyxRQUFRLGdCQUFnQixPQUFPLENBQUMsQ0FBQyxNQUFNLFdBQVc7RUFDeEgsTUFBTSxhQUFhO0VBQ25CLFdBQVcsV0FBVyxRQUFRLEtBQUs7RUFDbkMsT0FBTztDQUNSLENBQUM7Q0FDRCxDQUFDLEtBQUssT0FBTyxDQUFDLEVBQUEsQ0FBRyxLQUFLO0VBQ3JCO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELE9BQU8sa0JBQWtCLE1BQU0sV0FBVyxrQkFBa0IsV0FBVyxNQUFNLENBQUM7QUFDL0U7QUFDQSxlQUFlWSxzQkFBb0IsUUFBUSxTQUFTLFNBQVMsUUFBUSxXQUFXLEdBQUc7Q0FDbEYsTUFBTSxRQUFRLFVBQVUsRUFBRSxDQUFDO0NBQzNCLElBQUksUUFBUSxPQUFPLFVBQVUsUUFBUSxXQUFXLFVBQVUsTUFBTSxZQUFZLE1BQU0sT0FBTyxJQUFJLFVBQVUsTUFBTSxRQUFRLFNBQVM7Q0FDOUgsSUFBSSxRQUFRLEdBQUcsUUFBUTtDQUN2QixLQUFLLElBQUksSUFBSSxPQUFPLEtBQUssR0FBRyxLQUFLO0VBQ2hDLE1BQU0sUUFBUVAsV0FBUyxRQUFRLFFBQVEsRUFBRTtFQUN6QyxJQUFJO0dBQ0gsTUFBTSxVQUFVLGVBQWUsT0FBTyxLQUFLO0dBQzNDLElBQUksU0FBUyxNQUFNRCxVQUFRLFNBQVMsTUFBTTtFQUMzQyxTQUFTLE9BQU87R0FDZixJQUFJLFVBQVUsVUFBVSxPQUFPLFNBQVMsTUFBTTtFQUMvQztFQUNBLElBQUksTUFBTSxRQUFRLG1CQUFtQixPQUFPO0NBQzdDO0NBQ0EsT0FBTyxPQUFPLFVBQVUsUUFBUTtBQUNqQztBQUNBLFNBQVMsa0JBQWtCLFFBQVEsTUFBTTtDQUN4QyxJQUFJLEtBQUssSUFBSTtFQUNaLHVCQUF1QixRQUFRLEtBQUssRUFBRSxDQUFDLEtBQUssU0FBUyxLQUFLLEVBQUUsQ0FBQztFQUM3RCxLQUFLLEtBQUssS0FBSztDQUNoQjtBQUNEO0FBQ0EsZUFBZSxZQUFZLE9BQU8sZUFBZSxlQUFlLE1BQU07Q0FDckUsSUFBSTtDQUNKLElBQUk7RUFDSCxNQUFNLFFBQVEsSUFBSSxNQUFNLEtBQUssU0FBUyxLQUFLLEVBQUUsQ0FBQyxLQUFLLE9BQU8sWUFBWTtHQUNyRSxNQUFNLFlBQVksS0FBSztHQUN2QixJQUFJLFFBQVEsYUFBYSxNQUFNLE1BQU07R0FDckMsSUFBSSxRQUFRLE1BQU1ELGNBQVksTUFBTSxDQUFDLFdBQVcsT0FBTztHQUN2RCxJQUFJLENBQUMsaUJBQWlCLFFBQVEsT0FBT0gsV0FBUztJQUM3QyxnQkFBZ0IsQ0FBQyxXQUFXLE9BQU87SUFDbkMsTUFBTSxRQUFRLEtBQUssaUJBQWlCLENBQUMsRUFBQSxDQUFHLEtBQUssYUFBYTtLQUN6RCxJQUFJLFNBQVMsTUFBTSxXQUFXO0tBQzlCLE9BQU8sU0FBUyxFQUFFLENBQUMsTUFBTSxnQkFBZ0I7TUFDeEMsSUFBSSxZQUFZLE9BQU9HLGNBQVksTUFBTSxDQUFDLFNBQVMsSUFBSSxXQUFXO0tBQ25FLENBQUM7SUFDRixDQUFDLENBQUM7R0FDSDtFQUNELENBQUMsQ0FBQyxDQUFDO0NBQ0osU0FBUyxPQUFPO0VBQ2YsT0FBTztDQUNSO0NBQ0EsT0FBTyxpQkFBaUI7QUFDekI7QUFDQSxTQUFTSyxzQkFBb0IsUUFBUSxNQUFNLE9BQU8sU0FBUyxTQUFTLFFBQVE7Q0FDM0UsT0FBTyxRQUFRLE9BQU9MLGNBQVk7RUFDakMsTUFBTSxXQUFXLFFBQVE7RUFDekIsTUFBTSxrQkFBa0IsU0FBUztFQUNqQyxJQUFJO0dBQ0gsSUFBSSxnQkFBZ0IsUUFBUSxTQUFTLFFBQVEsSUFBSSxVQUFVLEdBQUc7SUFDN0QsT0FBTyxnQkFBZ0IsUUFBUTtJQUMvQixJQUFJLGdCQUFnQixnQkFBZ0IsT0FBTztHQUM1QztHQUNBLElBQUksZ0JBQWdCLGlCQUFpQixRQUFRLEtBQUssUUFBUSxNQUFNLElBQUksT0FBTztHQUMzRSxNQUFNLFdBQVcsT0FBTyxjQUFjO0lBQ3JDLEdBQUc7SUFDSCxlQUFlLEtBQUs7SUFDcEIsd0JBQXdCO0dBQ3pCLENBQUM7R0FDRCxNQUFNLGlCQUFpQixTQUFTLGtCQUFrQjtHQUNsRCxJQUFJLGVBQWUsVUFBVTtJQUM1QixNQUFNLFdBQVcsU0FBUyxNQUFNO0lBQ2hDLFNBQVMsVUFBVSxFQUFFLEdBQUcsZ0JBQWdCO0lBQ3hDLFNBQVMsUUFBUSxJQUFJLFlBQVksZUFBZSxVQUFVO0lBQzFELE9BQU8sZ0JBQWdCLFFBQVE7SUFDL0IsT0FBTyxRQUFRLEtBQUssQ0FBQ0EsY0FBWSxRQUFRLElBQUk7S0FDNUNBO0tBQ0E7S0FDQTtJQUNEO0dBQ0Q7R0FDQSxPQUFPO0lBQ05BO0lBQ0E7SUFDQTtHQUNEO0VBQ0QsU0FBUyxPQUFPO0dBQ2YsVUFBVSxTQUFTLENBQUNGLFNBQU8sS0FBSyxJQUFJTSxpQkFBZSxPQUFPLEtBQUs7R0FDL0QsU0FBUztFQUNWO0NBQ0Q7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxlQUFlLFdBQVcsUUFBUSxNQUFNLE9BQU8sWUFBWSxZQUFZLFNBQVM7Q0FDL0UsTUFBTSxVQUFVLEtBQUs7Q0FDckIsSUFBSSxVQUFVLE1BQU07Q0FDcEIsSUFBSSx3QkFBd0I7Q0FDNUIsTUFBTSxrQkFBa0IsUUFBUSxXQUFXLFVBQVUsTUFBTSxTQUFTO0NBQ3BFLE1BQU0sY0FBYyxVQUFVLE1BQU0sRUFBRSxDQUFDLE9BQU9MLGNBQVlVLHNCQUFvQixRQUFRLFNBQVMsT0FBTyxXQUFXLE1BQU0sSUFBSSxNQUFNO0NBQ2pJLElBQUksZUFBZSxrQkFBa0IsSUFBSSxRQUFRLFNBQVM7Q0FDMUQsS0FBSyxVQUFVLEVBQUUsQ0FBQyxNQUFNLE1BQU1ULGNBQVksZUFBZTtNQUNwRCxJQUFJLFNBQVM7RUFDakIsZUFBZSxRQUFRLE9BQU8sTUFBTSxXQUFXLE9BQU87RUFDdEQsS0FBSyxNQUFNLFFBQVEsT0FBTztHQUN6QixJQUFJLEtBQUssTUFBTSxjQUFjO0dBQzdCLE1BQU0sVUFBVSxNQUFNLEtBQUs7R0FDM0IsSUFBSSxRQUFRLE9BQU9ILGFBQVcsUUFBUSxLQUFLRyxnQkFBYyxFQUFFLGdCQUFnQixRQUFRLEtBQUssTUFBTTtJQUM3RixVQUFVLENBQUMsS0FBSyxJQUFJLE9BQU87SUFDM0IsZUFBZSxRQUFRLEtBQUssTUFBTSxXQUFXLE9BQU87SUFDcEQ7R0FDRDtFQUNEO0NBQ0Q7Q0FDQSxLQUFLLE1BQU0sUUFBUSxPQUFPO0VBQ3pCLElBQUksS0FBSyxNQUFNLGNBQWM7RUFDN0IsTUFBTSxlQUFlLE1BQU0sS0FBSztFQUNoQyxJQUFJLENBQUMsY0FBYztFQUNuQixVQUFVO0VBQ1Y7Q0FDRDtDQUNBLEtBQUssVUFBVSxFQUFFLENBQUMsTUFBTSxNQUFNQSxjQUFZO0VBQ3pDLE1BQU0sVUFBVSxRQUFRO0VBQ3hCLElBQUksUUFBUSxPQUFPQSxnQkFBYyxRQUFRLEVBQUUsQ0FBQyxRQUFRLGtCQUFrQixRQUFRLElBQUk7R0FDakYsa0JBQWtCLFFBQVEsSUFBSTtHQUM5QixPQUFPO0VBQ1I7RUFDQSx3QkFBd0I7RUFDeEIsVUFBVSxDQUFDLEdBQUcsQ0FBQ0YseUJBQXVCLElBQUksTUFBTSxvQkFBb0IsQ0FBQyxDQUFDO0NBQ3ZFO0NBQ0EsTUFBTSxXQUFXLFVBQVUsUUFBUSxNQUFNLE1BQU0sV0FBVyxPQUFPLElBQUk7Q0FDckUsSUFBSSxZQUFZLEdBQUc7RUFDbEIsTUFBTSxVQUFVLFVBQVU7RUFDMUIsTUFBTSxPQUFPLFVBQVU7RUFDdkIsTUFBTSxRQUFRLFFBQVE7RUFDdEIsTUFBTSxRQUFRLFVBQVU7RUFDeEIsTUFBTSxnQkFBZ0I7R0FDckIsSUFBSSxTQUFTO0lBQ1osTUFBTSxZQUFZLEtBQUs7SUFDdkIsSUFBSSxTQUFTQSxTQUFPLE1BQU0sU0FBUztTQUM5QjtLQUNKLE1BQU0sVUFBVSxNQUFNO0tBQ3RCLElBQUksTUFBTSxZQUFZLE9BQU8sVUFBVSxJQUFJO01BQzFDLE1BQU0sU0FBUztNQUNmLE1BQU0sWUFBWTtLQUNuQixPQUFPLE1BQU0sU0FBUztJQUN2QjtJQUNBLE1BQU0sUUFBUTtJQUNkLE1BQU0sYUFBYTtHQUNwQjtFQUNEO0VBQ0EsUUFBUTtFQUNSLElBQUksQ0FBQyxTQUFTLFVBQVU7RUFDeEIsTUFBTSxRQUFRSSxXQUFTLFFBQVEsS0FBSztFQUNwQyxJQUFJO0dBQ0gsTUFBTUQsVUFBUSxVQUFVLFFBQVEsUUFBUSxDQUFDLENBQUMsV0FBVyxlQUFlLE9BQU8sU0FBU0gsVUFBUSxtQkFBbUIsbUJBQW1CLENBQUMsSUFBSSxRQUFRLElBQUksQ0FBQyxlQUFlLEtBQUssR0FBRyxlQUFlLE9BQU8sbUJBQW1CLENBQUMsQ0FBQyxHQUFHLFdBQVcsTUFBTTtFQUMzTyxTQUFTLE9BQU87R0FDZixJQUFJLFVBQVUsV0FBVyxVQUFVLFdBQVcsT0FBTyxTQUFTO0lBQzdELGtCQUFrQixRQUFRLElBQUk7SUFDOUIsT0FBTztHQUNSO0VBQ0Q7RUFDQSxJQUFJLENBQUMsU0FBUyxNQUFNLFNBQVM7T0FDeEIsSUFBSSx1QkFBdUI7R0FDL0IsV0FBVyxNQUFNO0dBQ2pCLE1BQU0sUUFBUSxJQUFJO0lBQ2pCLEdBQUcsTUFBTSxLQUFLLFNBQVMsS0FBSyxFQUFFO0lBQzlCLEdBQUcsTUFBTSxLQUFLLFNBQVMsS0FBSyxFQUFFO0lBQzlCLElBQUksS0FBSyxNQUFNLENBQUMsRUFBQSxDQUFHLEtBQUssU0FBUyxLQUFLLEVBQUU7R0FDekMsQ0FBQztHQUNELGtCQUFrQixRQUFRLElBQUk7R0FDOUIsdUJBQXVCLFFBQVEsT0FBTztHQUN0QyxRQUFRO0VBQ1Q7Q0FDRDtDQUNBLE9BQU87QUFDUjtBQUNBLGVBQWVZLGNBQVksUUFBUSxNQUFNLFFBQVEsUUFBUSxHQUFHLE1BQU0sS0FBSyxFQUFFLENBQUMsUUFBUTtDQUNqRixNQUFNLFVBQVUsS0FBSztDQUNyQixLQUFLLElBQUksUUFBUSxPQUFPLFFBQVEsS0FBSyxTQUFTO0VBQzdDLE1BQU0sUUFBUSxRQUFRO0VBQ3RCLE1BQU0sZUFBZVIsV0FBUyxRQUFRLEtBQUssQ0FBQyxDQUFDO0VBQzdDLElBQUksYUFBYSxRQUFRLGFBQWEsU0FBUyxJQUFJO0dBQ2xELE1BQU0sVUFBVTtJQUNmLEtBQUssT0FBTyxRQUFRO0lBQ3BCO0lBQ0E7SUFDQSxRQUFRLE1BQU07SUFDZCxZQUFZLE1BQU07R0FDbkI7R0FDQSxNQUFNLENBQUMsTUFBTSxXQUFXLE1BQU1ELFVBQVEsUUFBUSxJQUFJLENBQUMsYUFBYSxPQUFPLE9BQU8sR0FBRyxhQUFhLFVBQVUsT0FBTyxDQUFDLENBQUMsR0FBRyxNQUFNO0dBQzFILE1BQU0sT0FBTyxNQUFNO0dBQ25CLE1BQU0sUUFBUSxNQUFNO0dBQ3BCLE1BQU0sY0FBYyxNQUFNO0dBQzFCLE1BQU0sU0FBUyxNQUFNO0dBQ3JCLE1BQU0sVUFBVTtFQUNqQixTQUFTLE9BQU87R0FDZixJQUFJLFVBQVUsVUFBVSxPQUFPLFNBQVM7R0FDeEMsUUFBUSxNQUFNLEtBQUs7RUFDcEI7RUFDQSxJQUFJLE1BQU0sV0FBVyxhQUFhLE1BQU0sV0FBVztDQUNwRDtDQUNBLE9BQU87QUFDUjtBQUNBLGVBQWUsa0JBQWtCLFFBQVEsVUFBVSxTQUFTLFNBQVM7Q0FDcEUsTUFBTSxVQUFVLENBQUMsVUFBVSxPQUFPO0NBQ2xDLE1BQU0sU0FBUyxRQUFRLEVBQUUsQ0FBQztDQUMxQixJQUFJO0NBQ0osSUFBSTtFQUNILE1BQU0sWUFBWSxPQUFPLE9BQU8sUUFBUSxJQUFJO0VBQzVDLElBQUksa0JBQWtCLFFBQVEsV0FBVyxVQUFVLE1BQU0sU0FBUztFQUNsRSxJQUFJLE9BQU8sUUFBUSxpQkFBaUIsVUFBVSxtQkFBbUIsR0FBRztHQUNuRSxNQUFNLFdBQVcsTUFBTVEsc0JBQW9CLFFBQVEsU0FBUyxLQUFLLEdBQUcsUUFBUSxlQUFlO0dBQzNGLFFBQVEsZ0JBQWdCLENBQUMsWUFBWSxLQUFLO0dBQzFDLFFBQVEsU0FBUyxDQUFDLFlBQVk7R0FDOUIsa0JBQWtCO0VBQ25CO0VBQ0EsSUFBSSxNQUFNLGtCQUFrQixJQUFJLFFBQVEsU0FBUyxrQkFBa0I7RUFDbkUsSUFBSSxjQUFjO0VBQ2xCLE9BQU8sY0FBYyxPQUFPLGdCQUFnQixpQkFBaUI7R0FDNUQsTUFBTSxRQUFRLFFBQVE7R0FDdEIsTUFBTSxZQUFZLFFBQVEsRUFBRSxDQUFDO0dBQzdCLE1BQU0sVUFBVSxVQUFVO0dBQzFCLElBQUksV0FBVyxPQUFPLE1BQU0sTUFBTSxVQUFVLFdBQVcsYUFBYSxNQUFNLFdBQVcsU0FBUyxPQUFPLE1BQU0sTUFBTSxRQUFRLFdBQVcsV0FBVztHQUMvSTtHQUNBLElBQUksVUFBVSxhQUFhLFFBQVEsV0FBVztFQUMvQztFQUNBLE1BQU0sUUFBUSxDQUFDO0VBQ2YsTUFBTSxRQUFRLFFBQVEsTUFBTTtFQUM1QixJQUFJLGlCQUFpQixRQUFRLFFBQVEsUUFBUSxRQUFRLFFBQVEsRUFBRSxJQUFJLEtBQUs7RUFDeEUsTUFBTSwyQkFBMkI7R0FDaEMsS0FBSyxJQUFJLFFBQVEsT0FBTyxRQUFRLEtBQUssU0FBUztJQUM3QyxJQUFJLE9BQU8sU0FBUztJQUNwQixpQkFBaUJELG1CQUFpQixRQUFRLFNBQVMsT0FBTyxPQUFPLGdCQUFnQixTQUFTLFdBQVc7R0FDdEc7RUFDRDtFQUNBLE1BQU0sVUFBVSxNQUFNRixnQkFBYyxRQUFRLFNBQVMsU0FBUyxLQUFLLG9CQUFvQixXQUFXO0VBQ2xHLElBQUksU0FBUztHQUNaLFFBQVEsS0FBSztHQUNiLE1BQU0sUUFBUTtHQUNkLElBQUksUUFBUSxFQUFFLENBQUMsT0FBT1AsYUFBVztJQUNoQyxNQUFNLFdBQVcsTUFBTVUsc0JBQW9CLFFBQVEsU0FBUyxTQUFTLE1BQU07SUFDM0UsUUFBUSxLQUFLO0lBQ2IsTUFBTSxLQUFLLElBQUksS0FBSyxXQUFXLENBQUM7R0FDakMsT0FBTyxJQUFJLFFBQVEsRUFBRSxDQUFDLE1BQU1ULGNBQVksTUFBTTtHQUM5QyxtQkFBbUI7RUFDcEI7RUFDQSxJQUFJLENBQUMsT0FBTyxXQUFXLENBQUMsUUFBUSxJQUFJO0dBQ25DLE1BQU0sUUFBUSxDQUFDO0dBQ2YsS0FBSyxNQUFNLENBQUMsSUFBSSxXQUFXLE9BQU8sWUFBWSxDQUFDLEdBQUcsSUFBSSxDQUFDLE9BQU8sSUFBSTtJQUNqRSxPQUFPLFNBQVMsT0FBTyxFQUFFO0lBQ3pCLE1BQU0sS0FBSyxPQUFPLEVBQUU7R0FDckI7R0FDQSxLQUFLLE1BQU0sY0FBYyxPQUFPLFdBQVcsTUFBTTtFQUNsRDtFQUNBLE1BQU0sWUFBWSxXQUFXLFFBQVEsU0FBUyxPQUFPLFFBQVEsSUFBSSxZQUFZLE9BQU8sU0FBUyxRQUFRLEVBQUUsR0FBRyxRQUFRLEVBQUU7RUFDcEgsSUFBSSxRQUFRLEVBQUUsRUFBRSxRQUFRLFFBQVEsS0FBSyxZQUFZLFFBQVEsSUFBSSxLQUFLLEdBQUcsS0FBSyxHQUFHLFVBQVUsTUFBTSxlQUFlLFVBQVUsVUFBVSxJQUFJLElBQUksb0JBQW9CLE9BQU8sQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDO0VBQ3JMLFVBQVUsTUFBTTtDQUNqQixTQUFTLE9BQU87RUFDZixrQkFBa0IsUUFBUSxPQUFPO0VBQ2pDLElBQUksVUFBVSxVQUFVLE9BQU8sU0FBUyxPQUFPO0VBQy9DLE1BQU07Q0FDUDtDQUNBLElBQUksVUFBVSxPQUFPLEdBQUcsT0FBTztDQUMvQixPQUFPVSxjQUFZLFFBQVEsU0FBUyxRQUFRLFFBQVEsT0FBTyxRQUFRLFNBQVMsUUFBUSxLQUFLLENBQUM7QUFDM0Y7Ozs7Ozs7QUFPQSxTQUFTLGFBQWEsUUFBUSxJQUFJO0NBQ2pDLElBQUksT0FBTyxRQUFRLElBQUk7Q0FDdkIsTUFBTSxVQUFVLEdBQUc7Q0FDbkIsTUFBTSxZQUFZLE9BQU8sT0FBTyxRQUFRLElBQUk7Q0FDNUMsSUFBSSxVQUFVLE9BQU87Q0FDckIsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLFFBQVEsUUFBUSxTQUFTO0VBQ3BELE1BQU0sUUFBUSxRQUFRO0VBQ3RCLE1BQU0sVUFBVSxNQUFNLFdBQVcsYUFBYSxDQUFDLE1BQU07RUFDckQsTUFBTSxtQkFBbUIsVUFBVSxNQUFNLEVBQUUsT0FBTyxNQUFNLE1BQU0sVUFBVSxNQUFNLEVBQUUsV0FBVztFQUMzRixJQUFJLFdBQVcsQ0FBQyxrQkFBa0I7RUFDbEMsTUFBTSxRQUFRUixXQUFTLFFBQVEsS0FBSztFQUNwQyxNQUFNLFFBQVEsV0FBVyxNQUFNLFVBQVUsSUFBSSxNQUFNLFFBQVEsYUFBYSxPQUFPLFFBQVE7RUFDdkYsTUFBTSxZQUFZLE1BQU0sUUFBUSxvQkFBb0IsT0FBTyxRQUFRO0VBQ25FLElBQUksQ0FBQyxhQUFhLE9BQU8sVUFBVSxZQUFZLFVBQVUsVUFBVTtHQUNsRSxJQUFJLFNBQVM7SUFDWixRQUFRLEtBQUs7SUFDYixRQUFRLEtBQUs7SUFDYixRQUFRLEtBQUs7R0FDZDtHQUNBO0VBQ0Q7RUFDQSxNQUFNLE1BQU0sTUFBTSxRQUFRLGdCQUFnQixPQUFPLFFBQVEsdUJBQXVCO0VBQ2hGLElBQUksV0FBVztFQUNmLElBQUksVUFBVSxPQUFPLE1BQU0sSUFBSTtHQUM5QixXQUFXLFFBQVEsT0FBTztHQUMxQixRQUFRLEtBQUs7RUFDZCxPQUFPO0dBQ04sYUFBYSxVQUFVLEVBQUU7R0FDekIsT0FBTyxXQUFXLFVBQVUsS0FBSztFQUNsQztFQUNBLElBQUksQ0FBQyxTQUFTLE9BQU8sV0FBVyxVQUFVO0dBQ3pDO0dBQ0EsTUFBTTtHQUNOLG1CQUFtQixLQUFLLElBQUksSUFBSSxNQUFNLEdBQUcsS0FBSztHQUM5QyxLQUFLO0dBQ0wsb0JBQW9CLEtBQUs7R0FDekI7RUFDRDtFQUNBLElBQUksUUFBUSxNQUFNLENBQUMsWUFBWSxRQUFRLE9BQU8sV0FBVztFQUN6RCxRQUFRLEtBQUs7RUFDYixJQUFJLENBQUMsUUFBUSxJQUFJO0dBQ2hCLGFBQWEsUUFBUSxFQUFFO0dBQ3ZCLE1BQU0sWUFBWSxRQUFRLEtBQUssS0FBSyxJQUFJO0dBQ3hDLElBQUksWUFBWSxHQUFHO0lBQ2xCLFFBQVEsS0FBSyxpQkFBaUIsYUFBYSxRQUFRLEVBQUUsR0FBRyxTQUFTO0lBQ2pFO0dBQ0Q7R0FDQSxRQUFRLEtBQUs7RUFDZDtFQUNBLE1BQU0sVUFBVSxRQUFRLEtBQUssV0FBVztHQUN2QyxHQUFHO0dBQ0gsU0FBUyxLQUFLO0VBQ2YsRUFBRTtFQUNGLFFBQVEsTUFBTSxDQUFDLFNBQVM7RUFDeEIsTUFBTSxNQUFNLFFBQVEsS0FBSyxPQUFPLHNCQUFzQixPQUFPLE9BQU8sV0FBVyxPQUFPLEdBQUcsT0FBTyxDQUFDLENBQUMsTUFBTSxhQUFhO0dBQ3BILElBQUksWUFBWSxPQUFPLGFBQWEsV0FBVyxRQUFRLE9BQU8sT0FBTyxDQUFDLFFBQVEsSUFBSSxRQUFRLEtBQUssS0FBSyxJQUFJLElBQUk7R0FDNUcsT0FBTztFQUNSLENBQUM7RUFDRDtDQUNEO0FBQ0Q7Ozs7O0FBS0EsU0FBUyxjQUFjLFFBQVEsSUFBSTtDQUNsQyxNQUFNLFVBQVUsT0FBTztDQUN2QixJQUFJLE9BQU8sUUFBUSxNQUFNLENBQUMsT0FBTyxNQUFNLEVBQUUsQ0FBQyxNQUFNLFVBQVUsTUFBTSxPQUFPLFVBQVUsRUFBRSxHQUFHO0VBQ3JGLGFBQWEsVUFBVSxFQUFFO0VBQ3pCLE9BQU8sV0FBVyxLQUFLO0NBQ3hCO0FBQ0Q7QUFDQSxlQUFlLG9CQUFvQixRQUFRLElBQUk7Q0FDOUMsTUFBTSxVQUFVLE9BQU87Q0FDdkIsSUFBSSxDQUFDLFNBQVM7Q0FDZCxhQUFhLFFBQVEsRUFBRTtDQUN2QixNQUFNLFlBQVksUUFBUSxLQUFLLEtBQUssSUFBSTtDQUN4QyxJQUFJLENBQUMsUUFBUSxNQUFNLGFBQWEsS0FBSyxDQUFDLG9CQUFvQixHQUFHLEVBQUUsQ0FBQyxDQUFDLE1BQU0sVUFBVSxNQUFNLE9BQU8sUUFBUSxFQUFFLEdBQUc7Q0FDM0csSUFBSTtDQUNKLElBQUk7RUFDSCxNQUFNRCxVQUFRLElBQUksU0FBUyxZQUFZO0dBQ3RDLFFBQVEsV0FBVyxTQUFTLFNBQVM7RUFDdEMsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLE1BQU07Q0FDakIsUUFBUSxDQUFDO0NBQ1QsYUFBYSxLQUFLO0FBQ25CO0FBQ0EsU0FBUyxlQUFlLFFBQVEsU0FBUztDQUN4QyxPQUFPLGFBQWE7Q0FDcEIsT0FBTyxPQUFPLFdBQVcsT0FBTztBQUNqQztBQUNBLFNBQVMsY0FBYyxRQUFRLElBQUksU0FBUyxnQkFBZ0I7Q0FDM0QsTUFBTSxXQUFXLE9BQU87Q0FDeEIsTUFBTSxjQUFjLE9BQU87Q0FDM0IsTUFBTSxpQkFBaUIsT0FBTztDQUM5QixLQUFLLE1BQU0sU0FBUyxTQUFTO0VBQzVCLE1BQU0sVUFBVTtFQUNoQixJQUFJLGdCQUFnQixNQUFNLFlBQVksS0FBSztDQUM1QztDQUNBLE1BQU0sTUFBTSxvQkFBb0IsT0FBTyxDQUFDLENBQUM7Q0FDekMsTUFBTSx5QkFBeUIsSUFBSSxJQUFJO0NBQ3ZDLElBQTZDLENBQUMsR0FBRyxJQUFJO0VBQ3BELE1BQU0sTUFBTSxLQUFLLElBQUk7RUFDckIsTUFBTSw2QkFBNkIsSUFBSSxJQUFJO0VBQzNDLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxRQUFRLFFBQVEsU0FBUztHQUNwRCxNQUFNLFFBQVEsUUFBUTtHQUN0QixJQUFJLFFBQVEsT0FBTyxNQUFNLFdBQVcsV0FBVyxXQUFXLElBQUksTUFBTSxFQUFFO0VBQ3ZFO0VBQ0EsS0FBSyxNQUFNLFNBQVMsQ0FBQyxHQUFHLFVBQVUsR0FBRyxlQUFlLE9BQU8sQ0FBQyxHQUFHO0dBQzlELElBQUksTUFBTSxXQUFXLGFBQWEsV0FBVyxJQUFJLE1BQU0sRUFBRSxHQUFHO0dBQzVELE1BQU0sUUFBUUMsV0FBUyxRQUFRLEtBQUs7R0FDcEMsSUFBSSxDQUFDLE1BQU0sUUFBUSxVQUFVLE1BQU0sTUFBTSxjQUFjLE1BQU0sVUFBVSxNQUFNLFFBQVEsaUJBQWlCLE9BQU8sUUFBUSx3QkFBd0IsTUFBTSxNQUFNLFFBQVEsVUFBVSxPQUFPLFFBQVEsaUJBQWlCLE1BQU07R0FDak4sT0FBTyxJQUFJLE1BQU0sSUFBSSxlQUFlLElBQUksTUFBTSxFQUFFLE1BQU0sUUFBUSxRQUFRO0lBQ3JFLEdBQUc7SUFDSCxTQUFTLEtBQUs7SUFDZCxZQUFZO0lBQ1osU0FBUyxDQUFDO0dBQ1gsQ0FBQztFQUNGO0NBQ0Q7Q0FDQSxHQUFHLEtBQUssQ0FBQztDQUNULE9BQU8sU0FBUztDQUNoQixNQUFNLFVBQVUsT0FBTyxnQkFBZ0IsYUFBYSxPQUFPO0NBQzNELGVBQWUsUUFBUSxPQUFPO0NBQzlCLHVCQUF1QixRQUFRLENBQUMsR0FBRyxlQUFlLE9BQU8sR0FBRyxHQUFHLFFBQVEsQ0FBQyxDQUFDLFFBQVEsVUFBVSxNQUFNLFdBQVcsT0FBTyxJQUFJLE1BQU0sRUFBRSxNQUFNLEtBQUssR0FBRyxPQUFPO0NBQ3pHO0VBQzFDLE1BQU0sVUFBVSxHQUFHLEVBQUUsR0FBRztFQUN4QixJQUFJLFdBQVcsT0FBTyxhQUFhLFNBQVMsUUFBUSxFQUFFLENBQUM7Q0FDeEQ7Q0FDQSxrQkFBa0IsUUFBUSxVQUFVLFNBQVMsYUFBYSxTQUFTLEVBQUU7QUFDdEU7Ozs7OztBQU1BLGVBQWUsYUFBYSxRQUFRLE9BQU87Q0FDMUMsSUFBSSxVQUFVLE9BQU87Q0FDckIsT0FBTyxXQUFXLFlBQVksT0FBTztFQUNwQyxRQUFRO0VBQ1IsTUFBTSxRQUFRO0VBQ2QsVUFBVSxPQUFPO0NBQ2xCO0FBQ0Q7QUFDQSxTQUFTLGVBQWUsUUFBUSxJQUFJLFNBQVM7Q0FDNUMsTUFBTSxVQUFVLFFBQVEsRUFBRSxDQUFDO0NBQzNCLE1BQU0sV0FBVyxRQUFRO0NBQ3pCLElBQUksQ0FBQyxVQUFVLE9BQU8sT0FBTyxTQUFTO0VBQ3JDLEdBQUc7RUFDSCxTQUFTO0VBQ1QsZUFBZTtDQUNoQixDQUFDO0NBQ0QsSUFBSSxRQUFRLGdCQUFnQixPQUFPLE9BQU8sU0FBUztFQUNsRCxPQUFPLFNBQVMsa0JBQWtCLFNBQUEsQ0FBVTtFQUM1QyxnQkFBZ0I7RUFDaEIsU0FBUztFQUNULGVBQWU7Q0FDaEIsQ0FBQztDQUNELFNBQVMsYUFBYSxHQUFHLEtBQUs7Q0FDOUIsT0FBTyxtQkFBbUI7Q0FDMUIsTUFBTSxZQUFZLE9BQU8sZUFBZTtFQUN2QyxHQUFHO0VBQ0gsZ0JBQWdCLFFBQVE7RUFDeEIsU0FBUztFQUNULGFBQWEsUUFBUTtFQUNyQixvQkFBb0IsUUFBUTtFQUM1QixlQUFlO0NBQ2hCLENBQUM7Q0FDRCxxQkFBcUI7RUFDcEIsSUFBSSxPQUFPLHFCQUFxQixVQUFVLE9BQU8sbUJBQW1CLEtBQUs7Q0FDMUUsQ0FBQztDQUNELE9BQU87QUFDUjtBQUNBLGVBQWUsY0FBYyxRQUFRLElBQUksTUFBTSxPQUFPLFlBQVk7Q0FDakUsTUFBTSxPQUFPLEtBQUssS0FBSyxXQUFXLEVBQUUsR0FBRyxNQUFNLEVBQUU7Q0FDL0Msc0JBQXNCLElBQUk7Q0FDMUIsS0FBSyxNQUFNLFFBQVEsT0FBTztFQUN6QixjQUFjLFFBQVEsS0FBSyxLQUFLLEdBQUc7RUFDbkMsS0FBSyxLQUFLLE1BQU0sS0FBSztDQUN0QjtDQUNBLE1BQU0sT0FBTyxDQUFDLEdBQUcsSUFBSSxJQUFJO0NBQ3pCLElBQUk7Q0FDSixJQUFJO0VBQ0gsVUFBVSxNQUFNLFdBQVcsUUFBUSxNQUFNLE9BQU8sR0FBRyxJQUFJLFVBQVU7Q0FDbEUsU0FBUyxPQUFPO0VBQ2YsdUJBQXVCLFFBQVEsSUFBSTtFQUNuQyxNQUFNO0NBQ1A7Q0FDQSxJQUFJLFVBQVUsT0FBTyxHQUFHO0VBQ3ZCLHVCQUF1QixRQUFRLElBQUk7RUFDbkMsSUFBSSxRQUFRLE9BQU9GLGdCQUFjLE9BQU8sUUFBUSxNQUFNLE9BQU8sZUFBZSxNQUFNLE1BQU0sZUFBZSxRQUFRLElBQUksT0FBTztFQUMxSDtDQUNEO0NBQ0EsTUFBTVUsY0FBWSxRQUFRLFNBQVMsR0FBRyxFQUFFLENBQUMsTUFBTTtDQUMvQyxJQUFJLE9BQU8sUUFBUSxNQUFNLE9BQU8sZUFBZSxNQUFNO0VBQ3BELHVCQUF1QixRQUFRLElBQUk7RUFDbkM7Q0FDRDtDQUNBLEtBQUssTUFBTSxTQUFTLE1BQU07RUFDekIsTUFBTSxTQUFTLE9BQU8sT0FBTyxJQUFJLE1BQU0sRUFBRTtFQUN6QyxJQUFJLFFBQVEsV0FBVyxPQUFPLFlBQVksTUFBTSxTQUFTO0dBQ3hELE9BQU8sT0FBTyxPQUFPLE1BQU0sRUFBRTtHQUM3QixjQUFjLFFBQVEsTUFBTTtFQUM3QjtDQUNEO0NBQ0EsZUFBZSxRQUFRLElBQUk7Q0FDM0IsdUJBQXVCLFFBQVEsTUFBTSxJQUFJO0FBQzFDO0FBQ0EsZUFBZSxxQkFBcUIsUUFBUSxJQUFJLGtCQUFrQixTQUFTLE1BQU0sZ0JBQWdCO0NBQ2hHLE1BQU0sU0FBUyxNQUFNLGtCQUFrQixRQUFRLEdBQUcsSUFBSSxHQUFHLElBQUk7RUFDNUQsR0FBRztFQUNILEdBQUc7RUFDSCxPQUFPO0VBQ1AsS0FBSztFQUNMO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELElBQUksVUFBVSxNQUFNLEdBQUc7RUFDdEIsTUFBTSxTQUFTLE9BQU8sT0FBT1YsZ0JBQWMsT0FBTyxRQUFRO0VBQzFELElBQUksQ0FBQyxVQUFVLE9BQU8sRUFBRSxDQUFDLFFBQVEsZ0JBQWdCLGNBQWMsUUFBUSxFQUFFO0VBQ3pFLHVCQUF1QixRQUFRLEdBQUcsRUFBRTtFQUNwQyxHQUFHLEtBQUssQ0FBQztFQUNULElBQUksQ0FBQyxRQUFRO0VBQ2IsSUFBSSxPQUFPLFFBQVEsSUFBSTtHQUN0QixjQUFjLFFBQVEsRUFBRTtHQUN4QjtFQUNEO0VBQ0EsSUFBNkMsR0FBRyxJQUFJLE9BQU8sbUJBQW1CO0VBQzlFLE1BQU0sZUFBZSxRQUFRLElBQUksTUFBTTtFQUN2QztDQUNEO0NBQ0EsTUFBTSxVQUFVLE9BQU87Q0FDdkIsSUFBSSxPQUFPLFFBQVEsSUFBSSxNQUFNLG9CQUFvQixRQUFRLEVBQUU7Q0FDM0QsSUFBSSxPQUFPLFFBQVEsSUFBSTtFQUN0QixjQUFjLFFBQVEsRUFBRTtFQUN4Qix1QkFBdUIsUUFBUSxPQUFPO0VBQ3RDLGtCQUFrQixRQUFRLE1BQU07RUFDaEM7Q0FDRDtDQUNBLE1BQU0sYUFBYSxHQUFHO0NBQ3RCLE1BQU0sYUFBYSxzQkFBc0IsWUFBWSxPQUFPLE9BQU8saUJBQWlCLElBQUksQ0FBQztDQUN6RixNQUFNLGFBQWEsT0FBTztDQUMxQixNQUFNLE9BQU8sb0JBQW9CLFlBQVk7RUFDNUMsSUFBSSxPQUFPLFFBQVEsSUFBSSxNQUFNLG9CQUFvQixRQUFRLEVBQUU7RUFDM0QsSUFBSSxPQUFPLFFBQVEsSUFBSTtHQUN0QixjQUFjLFFBQVEsRUFBRTtHQUN4Qix1QkFBdUIsUUFBUSxPQUFPO0dBQ3RDLGtCQUFrQixRQUFRLE1BQU07R0FDaEM7RUFDRDtFQUNBLE1BQU0sZUFBZTtHQUNwQixjQUFjLFFBQVEsRUFBRTtHQUN4QixjQUFjLFFBQVEsSUFBSSxTQUFTLGNBQWM7R0FDakQsSUFBSSxPQUFPLFFBQVEsSUFBSTtHQUN2QixPQUFPLEtBQUs7SUFDWCxNQUFNO0lBQ04sR0FBRztHQUNKLENBQUM7R0FDRCxJQUFJLE9BQU8sUUFBUSxJQUFJLE9BQU8sS0FBSztJQUNsQyxNQUFNO0lBQ04sR0FBRztHQUNKLENBQUM7RUFDRjtFQUNBLE1BQU0sV0FBVyxNQUFNLE9BQU8sZ0JBQWdCLFFBQVEsT0FBTztFQUM3RCxJQUE2QyxHQUFHLElBQUksR0FBRyxLQUFLLEtBQUs7RUFDakUsSUFBSSxPQUFPLFFBQVEsSUFBSTtHQUN0QixrQkFBa0IsUUFBUSxNQUFNO0dBQ2hDO0VBQ0Q7RUFDQSxJQUFJLFlBQVksUUFBUSxjQUFjLFFBQVEsSUFBSSxTQUFTLFlBQVksT0FBTyxFQUFFLENBQUMsQ0FBQyxNQUFNLFFBQVEsS0FBSztFQUNyRyxPQUFPLFlBQVk7R0FDbEIsT0FBTyxPQUFPLGlCQUFpQixJQUFJLFVBQVU7R0FDN0MsT0FBTyxPQUFPLE9BQU8sSUFBSSxNQUFNO0dBQy9CLElBQUksT0FBTyxRQUFRLElBQUksT0FBTyxLQUFLO0lBQ2xDLE1BQU07SUFDTixHQUFHO0dBQ0osQ0FBQztHQUNELElBQUksWUFBWSxPQUFPLFFBQVEsSUFBSSxPQUFPLEtBQUs7SUFDOUMsTUFBTTtJQUNOLEdBQUc7R0FDSixDQUFDO0VBQ0YsQ0FBQztFQUNELElBQUksT0FBTyxRQUFRLElBQUk7RUFDdkIsT0FBTyxnQkFBZ0IsUUFBUTtFQUMvQixPQUFPLGlCQUFpQixLQUFLO0NBQzlCLENBQUM7QUFDRjtBQUNBLGVBQWUsZ0JBQWdCLFFBQVEsTUFBTTtDQUM1QyxJQUFJLGdCQUFnQjtDQUN1QixnQkFBZ0IsQ0FBQyxDQUFDLE9BQU8sb0JBQW9CLENBQUMsQ0FBQyxPQUFPLE1BQU07Q0FDdkcsTUFBTSxnQkFBZ0IsT0FBTztDQUM3QixNQUFNLG1CQUFtQixPQUFPLE9BQU8saUJBQWlCLElBQUk7Q0FDNUQsTUFBTSxtQkFBbUIsb0JBQW9CLE9BQU8sT0FBTyxTQUFTLElBQUk7Q0FDeEUsTUFBTSxXQUFXLE9BQU87Q0FDeEIsTUFBTSxrQkFBa0IsT0FBTztDQUMvQixNQUFNLFlBQVksaUJBQWlCLFNBQVMsU0FBUyxPQUFPLGdCQUFnQixjQUFjLElBQUk7Q0FDOUYsTUFBTSxVQUFVLE9BQU87Q0FDdkIsTUFBTSxzQkFBc0IsZ0JBQWdCLEtBQUssSUFBSSxVQUFVLEVBQUUsQ0FBQztDQUNsRSxNQUFNLFlBQVksSUFBSSxnQkFBZ0I7Q0FDdEMsTUFBTSxvQkFBb0IsT0FBTztDQUNqQyxPQUFPLGFBQWE7Q0FDcEIsSUFBSSxDQUFDLGlCQUFpQixDQUFDLHFCQUFxQixVQUFVLEVBQUUsQ0FBQztDQUN6RCxtQkFBbUIsTUFBTTtDQUN6QixJQUFJLENBQUMsVUFBVSxPQUFPLFNBQVM7RUFDOUIsTUFBTSxhQUFhLHNCQUFzQixVQUFVLGdCQUFnQjtFQUNuRSxPQUFPLEtBQUs7R0FDWCxNQUFNO0dBQ04sR0FBRztFQUNKLENBQUM7RUFDRCxJQUFJLENBQUMsVUFBVSxPQUFPLFNBQVMsT0FBTyxLQUFLO0dBQzFDLE1BQU07R0FDTixHQUFHO0VBQ0osQ0FBQztDQUNGO0NBQ0EsSUFBSSxVQUFVLE9BQU8sU0FBUztFQUM3QixNQUFNLGFBQWEsUUFBUSxhQUFhO0VBQ3hDO0NBQ0Q7Q0FDQSxNQUFNLFdBQVcsaUJBQWlCLFNBQVMsU0FBUztDQUNwRCxJQUFJLGFBQWE7Q0FDakIsTUFBTSxVQUFtRCxnQkFBZ0IsT0FBTyxZQUFZLFVBQVU7RUFDckcsYUFBYTtFQUNiLGdCQUFnQjtDQUNqQixDQUFDLElBQUksT0FBTyxZQUFZLFVBQVUsRUFBRSxhQUFhLFVBQVUsQ0FBQztDQUM1RCxzQkFBc0IsT0FBTztDQUM3QixNQUFNLGlCQUFpQixzQkFBc0IsUUFBUSxFQUFFLENBQUMsT0FBTyxJQUFJLEtBQUs7Q0FDeEUsSUFBSSxnQkFBZ0IsYUFBYTtNQUM1QixxQkFBcUIsTUFBTTtDQUNoQyxJQUFJLFVBQVUsT0FBTyxTQUFTO0VBQzdCLHVCQUF1QixRQUFRLE9BQU87RUFDdEMsTUFBTSxhQUFhLFFBQVEsYUFBYTtFQUN4QztDQUNEO0NBQ0EsT0FBTyxhQUFhLEtBQUs7Q0FDekIsSUFBSTtDQUNKLE1BQU0sWUFBWSxxQkFBcUIsUUFBUSxJQUFJLGdCQUFnQixhQUFhLFFBQVEsRUFBRSxHQUFHLE1BQU0sTUFBTSxjQUFjO0NBQ3ZILE1BQU0sT0FBTyxNQUFNLE9BQU8sSUFBSSxTQUFTLFlBQVksU0FBUyxPQUFPLElBQUksUUFBUSxRQUFRLENBQUMsQ0FBQyxLQUFLLEdBQUc7Q0FDakcsTUFBTSxLQUFLO0VBQ1Y7RUFDQTtFQUNBO0VBQ0E7RUFDQSxLQUFLLElBQUk7RUFDVCxLQUFLLFdBQVcsYUFBYSxRQUFRLEVBQUUsQ0FBQztDQUN6QztDQUNBLElBQTZDLGVBQWU7RUFDM0QsR0FBRyxLQUFLLENBQUMsT0FBTztFQUNoQixPQUFPLG1CQUFtQixLQUFLO0NBQ2hDO0NBQ0EsT0FBTyxNQUFNO0NBQ2IsSUFBSSxlQUFlO0VBQ2xCLEtBQUssTUFBTSxTQUFTLE9BQU8sT0FBTyxRQUFRLElBQUksR0FBRztHQUNoRCxJQUFJLE9BQU8sUUFBUSxJQUFJO0dBQ3ZCLElBQUksTUFBTSxZQUFZLFlBQVksUUFBUSxPQUFPLEtBQUs7RUFDdkQ7RUFDQSxjQUFjLEVBQUUsQ0FBQyxNQUFNO0VBQ3ZCLHVCQUF1QixRQUFRLGNBQWMsSUFBSSxHQUFHLElBQUksSUFBSTtDQUM3RDtDQUNBLElBQUksT0FBTyxRQUFRLElBQUk7RUFDdEIsdUJBQXVCLFFBQVEsR0FBRyxFQUFFO0VBQ3BDLEdBQUcsS0FBSyxDQUFDO0VBQ1QsU0FBUztFQUNULE1BQU0sYUFBYSxRQUFRLEVBQUU7RUFDN0I7Q0FDRDtDQUNBLE9BQU8sWUFBWTtFQUNsQixPQUFPLE9BQU8sT0FBTyxJQUFJLFNBQVM7RUFDbEMsT0FBTyxPQUFPLFNBQVMsSUFBSSxRQUFRO0NBQ3BDLENBQUM7Q0FDRCxJQUFJLGtCQUFrQixDQUFDLE9BQU8sV0FBVyxVQUFVLFFBQVEsRUFBRSxFQUFFLFdBQVcsYUFBYSxDQUFDLFFBQVEsTUFBTSxVQUFVLE1BQU0sU0FBUyxHQUFHLGFBQWEsUUFBUSxFQUFFO0NBQ3pKLFNBQVMsSUFBSSxDQUFDO0NBQ2QsTUFBTSxHQUFHO0FBQ1Y7QUFDQSxlQUFlLG1CQUFtQixRQUFRO0NBQ3pDLE1BQU0sVUFBVSxPQUFPO0NBQ3ZCLElBQUksV0FBVyxDQUFDLFFBQVEsTUFBTSxPQUFPLE9BQU8sT0FBTyxJQUFJLE1BQU0sV0FBVztFQUN2RSxNQUFNLFFBQVE7RUFDZCxJQUFJLE9BQU8sUUFBUSxTQUFTLE1BQU0sYUFBYSxRQUFRLE9BQU87Q0FDL0Q7Q0FDQSxPQUFPLFVBQVUsTUFBTTtDQUN2QixPQUFPLFdBQVc7Q0FDbEIsT0FBTyxtQkFBbUI7Q0FDMUIsTUFBTSxnQkFBZ0IsUUFBUSxFQUFFLE1BQU0sS0FBSyxDQUFDO0FBQzdDO0FBQ0EsZUFBZSxtQkFBbUIsUUFBUSxNQUFNO0NBQy9DLElBQThDLE9BQU8sb0JBQW9CLE9BQU8sTUFBTSxJQUFLO0NBQzNGLElBQUksV0FBVyxPQUFPLGNBQWMsSUFBSTtDQUN4QyxLQUFLLElBQUksWUFBWSxJQUFJLGFBQWE7RUFDckMsTUFBTSxPQUFPLE9BQU87RUFDcEIsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0VBQ3ZDLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7R0FDSCxJQUFJO0lBQ0gsVUFBVSxPQUFPLFlBQVksVUFBVSxFQUFFLGFBQWEsV0FBVyxDQUFDO0lBQ2xFLHNCQUFzQixPQUFPO0lBQzdCLFVBQVUsT0FBTyw4QkFBOEIsSUFBSSxJQUFJLEVBQUEsQ0FBRyxJQUFJLFlBQVksT0FBTztJQUNqRixTQUFTLE1BQU0sa0JBQWtCLFFBQVEsVUFBVSxTQUFTO0tBQzNEO0tBQ0E7S0FDQTtLQUNBO0lBQ0QsQ0FBQztHQUNGLFVBQVU7SUFDVCxJQUFJLFFBQVE7S0FDWCxTQUFTLE9BQU8sT0FBTyxVQUFVO0tBQ2pDLHVCQUF1QixRQUFRLE9BQU87SUFDdkM7SUFDQSxXQUFXLE1BQU07R0FDbEI7R0FDQSxJQUFJLENBQUMsVUFBVSxNQUFNLEdBQUcsT0FBTyxPQUFPO0dBQ3RDLElBQUksQ0FBQyxVQUFVLE9BQU8sU0FBUyxLQUErQyxPQUFPLG9CQUFvQixPQUFPLE1BQU0sSUFBSztHQUMzSCxXQUFXLE9BQU87RUFDbkIsU0FBUyxPQUFPO0dBQ2YsSUFBSSxDQUFDLFdBQVcsS0FBSyxHQUFHLFFBQVEsTUFBTSxLQUFLO0dBQzNDO0VBQ0Q7Q0FDRDtBQUNEOztBQ3BsQ0EsU0FBUyxZQUFZLFVBQVUsT0FBTztDQUNyQyxJQUFJLENBQUMsVUFBVTtDQUNmLElBQUk7RUFDSCxNQUFNLFNBQVMsU0FBUyxLQUFLO0VBQzdCLElBQUksV0FBVyxLQUFLLEdBQUcsUUFBUSxRQUFRLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxDQUFDO0NBQzlELFFBQVEsQ0FBQztBQUNWOzs7Ozs7OztBQVFBLFNBQVMsY0FBYyxPQUFPLFFBQVEsUUFBUSxhQUFhO0NBQzFELE1BQU0sVUFBVSxRQUFRLFFBQVEsS0FBSztDQUNyQyxJQUFJLE9BQU8sU0FBUztFQUNuQixRQUFRLE1BQU0sV0FBVyxZQUFZLFFBQVEsTUFBTSxJQUFJLFVBQVUsWUFBWSxhQUFhLEtBQUssQ0FBQztFQUNoRyxPQUFPLFFBQVEsT0FBTyxPQUFPLE1BQU07Q0FDcEM7Q0FDQSxPQUFPLElBQUksU0FBUyxTQUFTLFdBQVc7RUFDdkMsTUFBTSxjQUFjLE9BQU8sT0FBTyxNQUFNO0VBQ3hDLE9BQU8saUJBQWlCLFNBQVMsT0FBTyxFQUFFLE1BQU0sS0FBSyxDQUFDO0VBQ3RELFFBQVEsTUFBTSxXQUFXO0dBQ3hCLE9BQU8sb0JBQW9CLFNBQVMsS0FBSztHQUN6QyxJQUFJLE9BQU8sU0FBUyxZQUFZLFFBQVEsTUFBTTtRQUN6QyxRQUFRLE1BQU07RUFDcEIsSUFBSSxVQUFVO0dBQ2IsT0FBTyxvQkFBb0IsU0FBUyxLQUFLO0dBQ3pDLElBQUksT0FBTyxTQUFTLFlBQVksYUFBYSxLQUFLO1FBQzdDLE9BQU8sS0FBSztFQUNsQixDQUFDO0NBQ0YsQ0FBQztBQUNGOztBQzNCQSxJQUFNLFVBQVU7QUFDaEIsSUFBTSxRQUFRO0FBQ2QsSUFBTSxZQUFZO0FBQ2xCLElBQU0sYUFBYTtBQUNuQixJQUFNLFVBQVU7QUFDaEIsSUFBTSw2QkFBNkIsT0FBTyxPQUFPO0NBQ2hELE1BQU07Q0FDTixTQUFTO0FBQ1YsQ0FBQztBQUNELElBQU0sd0JBQXdCLE9BQU8sT0FBTztDQUMzQyxNQUFNO0NBQ04sU0FBUztBQUNWLENBQUM7QUFDRCxTQUFTLFNBQVMsUUFBUSxPQUFPO0NBQ2hDLE9BQU8sT0FBTyxXQUFXLE1BQU07QUFDaEM7QUFDQSxTQUFTLFVBQVUsT0FBTyxVQUFVO0NBQ25DLElBQUksV0FBVyxLQUFLLEdBQUcsT0FBTyxDQUFDLFlBQVksS0FBSztDQUNoRCxJQUFJLFdBQVcsS0FBSyxHQUFHLE9BQU8sQ0FBQyxXQUFXLEtBQUs7Q0FDL0MsSUFBSSxZQUFZLE9BQU8sT0FBTyxTQUFTLFlBQVksUUFBUSxJQUFJLE1BQU0sd0JBQXdCLEVBQUUsT0FBTyxNQUFNLENBQUM7Q0FDN0csT0FBTyxXQUFXLENBQUMsT0FBTyxLQUFLLElBQUksQ0FBQyxTQUFTLEtBQUs7QUFDbkQ7QUFDQSxTQUFTLGVBQWUsUUFBUSxNQUFNLE9BQU8sT0FBTyxRQUFRLFNBQVMsTUFBTTtDQUMxRSxRQUFRLGVBQWU7Q0FDdkIsSUFBSSxVQUFVLFVBQVUsT0FBTyxJQUFJO0NBQ25DLElBQUksUUFBUSxPQUFPLE9BQU8sT0FBTyxvQkFBb0IsUUFBUSxNQUFNLE9BQU8sU0FBUyxRQUFRLE1BQU07Q0FDakcsSUFBSTtFQUNILE1BQU0sUUFBUSxVQUFVLFFBQVEsRUFBRTtDQUNuQyxTQUFTLGNBQWM7RUFDdEIsVUFBVSxVQUFVLGNBQWMsSUFBSTtDQUN2QztDQUNBLFFBQVEsZUFBZTtDQUN2QixPQUFPLG9CQUFvQixRQUFRLE1BQU0sT0FBTyxTQUFTLFFBQVEsTUFBTTtBQUN4RTtBQUNBLFNBQVMsb0JBQW9CLFFBQVEsTUFBTSxPQUFPLFNBQVMsUUFBUSxTQUFTLE1BQU07Q0FDakYsSUFBSSxRQUFRLE9BQU8sWUFBWSxPQUFPO0NBQ3RDLFFBQVEsZUFBZTtDQUN2QixJQUFJO0VBQ0gsUUFBUSxFQUFFLENBQUMsUUFBUSxnQkFBZ0IsS0FBSztFQUN4QyxPQUFPLGdCQUFnQixRQUFRLEVBQUU7RUFDakMsUUFBUSxlQUFlO0VBQ3ZCLE9BQU87Q0FDUixTQUFTLE9BQU87RUFDZixRQUFRLGVBQWU7RUFDdkIsT0FBTyxTQUFTLGVBQWUsUUFBUSxNQUFNLE9BQU8sT0FBTyxRQUFRLEtBQUssSUFBSSxDQUFDLE9BQU8sS0FBSztDQUMxRjtBQUNEO0FBQ0EsU0FBUyxNQUFNLE9BQU8sT0FBTztDQUM1QixJQUFJLFVBQVUsS0FBSyxHQUFHLE9BQU87RUFDNUIsUUFBUTtFQUNSLE9BQU87Q0FDUjtDQUNBLE9BQU87RUFDTixRQUFRO0VBQ1I7Q0FDRDtBQUNEO0FBQ0EsU0FBUyxhQUFhLFFBQVEsVUFBVTtDQUN2QyxRQUFRLFlBQVksT0FBTyxTQUFTO0VBQ25DLEdBQUc7RUFDSCxlQUFlO0NBQ2hCLENBQUM7QUFDRjtBQUNBLFNBQVMsUUFBUSxPQUFPLFFBQVE7Q0FDL0IsT0FBTyxTQUFTLGNBQWMsT0FBTyxNQUFNLElBQUk7QUFDaEQ7QUFDQSxTQUFTLFdBQVcsUUFBUSxNQUFNLE9BQU87Q0FDeEMsTUFBTSxRQUFRLEtBQUssUUFBUTtDQUMzQixNQUFNLFFBQVEsU0FBUyxRQUFRLEtBQUs7Q0FDcEMsTUFBTSxZQUFZLEtBQUssUUFBUSxRQUFRLEVBQUUsRUFBRTtDQUMzQyxJQUFJLE9BQU8sUUFBUSxHQUFHLE9BQU8sTUFBTSxPQUFPO0NBQzFDLElBQUksY0FBYyxPQUFPLE9BQU87Q0FDaEMsTUFBTSxXQUFXLFVBQVU7RUFDMUIsT0FBTyxVQUFVLFFBQVEsY0FBYyxjQUFjLGNBQWM7Q0FDcEU7Q0FDQSxNQUFNLGFBQWEsT0FBTyxRQUFRLGNBQWM7Q0FDaEQsTUFBTSxtQkFBbUIsUUFBUSxVQUFVO0NBQzNDLE1BQU0sTUFBTTtDQUNaLE1BQU0sU0FBUyxNQUFNLFFBQVE7Q0FDN0IsSUFBSSxXQUFXLEtBQUssR0FBRyxPQUFPO0NBQzlCLElBQUksT0FBTyxXQUFXLFlBQVksT0FBTyxRQUFRLE1BQU07Q0FDdkQsTUFBTSxVQUFVO0VBQ2YsUUFBUSxNQUFNLE1BQU0sUUFBUSxNQUFNLFdBQVc7RUFDN0MsUUFBUSxNQUFNLE1BQU0sUUFBUSxNQUFNLFdBQVc7RUFDN0MsVUFBVSxLQUFLO0VBQ2YsU0FBUyxLQUFLLFFBQVEsS0FBSyxlQUFlO0dBQ3pDLE9BQU8sVUFBVTtHQUNqQixVQUFVLFVBQVU7R0FDcEIsVUFBVSxVQUFVO0dBQ3BCLFlBQVksVUFBVTtHQUN0QixJQUFJLFVBQVU7R0FDZCxTQUFTLFVBQVU7R0FDbkIsUUFBUSxNQUFNLFVBQVUsUUFBUSxVQUFVLFdBQVc7R0FDckQsUUFBUSxNQUFNLFVBQVUsUUFBUSxVQUFVLFdBQVc7R0FDckQsS0FBSyxVQUFVO0VBQ2hCLEVBQUU7Q0FDSDtDQUNBLElBQUk7RUFDSCxPQUFPLFFBQVEsUUFBUSxPQUFPLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxVQUFVLFFBQVEsU0FBUyxVQUFVLENBQUM7Q0FDckYsU0FBUyxPQUFPO0VBQ2YsT0FBTyxRQUFRLE9BQU8sS0FBSztDQUM1QjtBQUNEO0FBQ0EsU0FBUyxjQUFjLE9BQU8sU0FBUztDQUN0QyxJQUFJLFFBQVEsT0FBTyxhQUFhLENBQUMsUUFBUSxFQUFFLENBQUMsU0FBUyxRQUFRLEVBQUUsQ0FBQyxVQUFVLE1BQU07Q0FDaEYsT0FBTztBQUNSO0FBQ0EsZUFBZSxjQUFjLFFBQVEsTUFBTSxRQUFRO0NBQ2xELE1BQU0saUJBQWlCLEtBQUssUUFBUSxXQUFXLFVBQVUsTUFBTSxTQUFTO0NBQ3hFLElBQUksTUFBTSxpQkFBaUIsSUFBSSxLQUFLLFFBQVEsU0FBUyxpQkFBaUI7Q0FDdEUsSUFBSTtDQUNKLElBQUksZ0JBQWdCLEVBQUUsR0FBRyxPQUFPLFFBQVEsV0FBVyxDQUFDLEVBQUU7Q0FDdEQsS0FBSyxJQUFJLFFBQVEsR0FBRyxRQUFRLEtBQUssU0FBUztFQUN6QyxNQUFNLFFBQVEsS0FBSyxRQUFRO0VBQzNCLE1BQU0sUUFBUSxTQUFTLFFBQVEsS0FBSztFQUNwQyxJQUFJO0dBQ0gsTUFBTSxNQUFNLFdBQVcsUUFBUSxNQUFNLEtBQUs7R0FDMUMsTUFBTSxNQUFNLGVBQWUsVUFBVSxNQUFNLE1BQU07RUFDbEQsU0FBUyxPQUFPO0dBQ2YsUUFBUSxlQUFlO0dBQ3ZCLFVBQVUsQ0FBQyxPQUFPLGNBQWMsT0FBTyxlQUFlLFFBQVEsTUFBTSxPQUFPLE9BQU8sTUFBTSxDQUFDLENBQUM7R0FDMUYsTUFBTTtFQUNQO0VBQ0EsUUFBUSxlQUFlO0VBQ3ZCLElBQUksVUFBVSxFQUFFLENBQUMsT0FBTyxZQUFZO0VBQ3BDLE1BQU0sc0JBQXNCLEtBQUs7RUFDakMsSUFBSSxVQUFVO0VBQ2QsSUFBSTtHQUNILElBQUk7R0FDSixJQUFJLE1BQU0sUUFBUSxTQUFTO0lBQzFCLE1BQU0sc0JBQXNCO0tBQzNCLE1BQU0sTUFBTTtLQUNaLFFBQVEsTUFBTTtLQUNkLFNBQVM7S0FDVCxVQUFVLEtBQUs7S0FDZixVQUFVLGFBQWEsUUFBUSxLQUFLLFFBQVE7S0FDNUMsZUFBZSxPQUFPO0tBQ3RCLE9BQU8sTUFBTTtLQUNiLGlCQUFpQixNQUFNO0tBQ3ZCLFNBQVM7S0FDVCxTQUFTLEtBQUs7S0FDZCxTQUFTLE1BQU07SUFDaEI7SUFDQSxlQUFlLE1BQU0sUUFBUSxRQUFRLG1CQUFtQixLQUFLLEtBQUs7R0FDbkU7R0FDQSxVQUFVO0lBQ1QsR0FBRztJQUNILEdBQUc7R0FDSjtHQUNBLE1BQU0sVUFBVTtFQUNqQixTQUFTLE9BQU87R0FDZixRQUFRLGVBQWU7R0FDdkIsSUFBSSxDQUFDLFNBQVMsVUFBVSxDQUFDLE9BQU8sY0FBYyxPQUFPLGVBQWUsUUFBUSxNQUFNLE9BQU8sT0FBTyxNQUFNLENBQUMsQ0FBQztHQUN4RyxNQUFNO0dBQ047RUFDRDtFQUNBLFFBQVEsZUFBZTtFQUN2QixJQUFJLFNBQVM7RUFDYixNQUFNLGtCQUFrQixNQUFNLGVBQWUsTUFBTTtFQUNuRCxJQUFJLG9CQUFvQixLQUFLLEdBQUc7R0FDL0IsVUFBVSxDQUFDLE9BQU8sY0FBYyxPQUFPLGVBQWUsUUFBUSxNQUFNLE9BQU8saUJBQWlCLE1BQU0sQ0FBQyxDQUFDO0dBQ3BHLE1BQU07R0FDTjtFQUNEO0VBQ0EsUUFBUSxlQUFlO0VBQ3ZCLElBQUksTUFBTSxRQUFRLFNBQVMsQ0FBQyxNQUFNLFFBQVEsWUFBWTtHQUNyRCxnQkFBZ0I7R0FDaEI7RUFDRDtFQUNBLE1BQU0sa0JBQWtCLE1BQU07RUFDOUIsTUFBTSxVQUFVO0dBQ2YsUUFBUSxNQUFNO0dBQ2Q7R0FDQSxRQUFRLE1BQU07R0FDZCxTQUFTO0dBQ1Q7R0FDQSxVQUFVLEtBQUs7R0FDZixVQUFVLGFBQWEsUUFBUSxLQUFLLFFBQVE7R0FDNUMsZUFBZSxPQUFPO0dBQ3RCLE9BQU8sTUFBTTtHQUNiLFNBQVMsS0FBSztHQUNkLFNBQVMsTUFBTTtHQUNmLEdBQUcsT0FBTyxRQUFRO0VBQ25CO0VBQ0EsSUFBSTtHQUNILE1BQU0sb0JBQW9CLE1BQU0sTUFBTSxRQUFRLFdBQVcsT0FBTztHQUNoRSxRQUFRLGVBQWU7R0FDdkIsTUFBTSxVQUFVLGNBQWMsT0FBTyxvQkFBb0IsUUFBUSxNQUFNLE9BQU8sVUFBVSxtQkFBbUIsS0FBSyxHQUFHLE1BQU0sQ0FBQztHQUMxSCxJQUFJLFFBQVEsT0FBTyxTQUFTO0lBQzNCLFVBQVUsQ0FBQyxPQUFPLE9BQU87SUFDekIsTUFBTTtJQUNOO0dBQ0Q7R0FDQSxNQUFNLHNCQUFzQjtHQUM1QixNQUFNLFVBQVU7SUFDZixHQUFHO0lBQ0gsR0FBRztHQUNKO0dBQ0EsZ0JBQWdCLE1BQU07RUFDdkIsU0FBUyxPQUFPO0dBQ2YsUUFBUSxlQUFlO0dBQ3ZCLFVBQVUsQ0FBQyxPQUFPLGNBQWMsT0FBTyxlQUFlLFFBQVEsTUFBTSxPQUFPLE9BQU8sTUFBTSxDQUFDLENBQUM7R0FDMUYsTUFBTTtHQUNOO0VBQ0Q7Q0FDRDtDQUNBLE9BQU87RUFDTixVQUFVLEtBQUs7RUFDZixTQUFTLEtBQUs7RUFDZDtFQUNBO0NBQ0Q7QUFDRDtBQUNBLFNBQVMsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLE9BQU8sT0FBTyxPQUFPO0NBQ25FLE9BQU87RUFDTixRQUFRLE1BQU07RUFDZCxNQUFNLE1BQU07RUFDWixTQUFTO0VBQ1Qsb0JBQW9CLE1BQU0sUUFBUSxFQUFFLEVBQUU7RUFDdEMsaUJBQWlCLE1BQU07RUFDdkIsU0FBUyxNQUFNO0VBQ2YsVUFBVSxLQUFLO0VBQ2YsVUFBVSxhQUFhLFFBQVEsS0FBSyxRQUFRO0VBQzVDLE9BQU8sTUFBTTtFQUNiO0VBQ0EsR0FBRyxPQUFPLFFBQVE7Q0FDbkI7QUFDRDtBQUNBLFNBQVMsaUJBQWlCLFFBQVEsTUFBTSxPQUFPLE9BQU8sUUFBUTtDQUM3RCxNQUFNLFFBQVEsS0FBSyxRQUFRO0NBQzNCLE1BQU0sUUFBUSxTQUFTLFFBQVEsS0FBSztDQUNwQyxJQUFJO0NBQ0osSUFBSSxNQUFNLFFBQVEsT0FBTyxVQUFVLFFBQVEsUUFBUSxDQUFDLE9BQU8sQ0FBQztNQUN2RDtFQUNKLE1BQU0sY0FBYyxNQUFNLFFBQVE7RUFDbEMsTUFBTSxTQUFTLE9BQU8sZ0JBQWdCLGFBQWEsY0FBYyxhQUFhO0VBQzlFLElBQUksQ0FBQyxRQUFRLFVBQVUsUUFBUSxRQUFRLENBQUMsU0FBUyxLQUFLLENBQUMsQ0FBQztPQUNuRCxVQUFVLFFBQVEsUUFBUSxDQUFDLENBQUMsV0FBVyxPQUFPLGlCQUFpQixRQUFRLE1BQU0sT0FBTyxPQUFPLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sV0FBVyxVQUFVLFFBQVEsS0FBSyxJQUFJLFVBQVUsVUFBVSxPQUFPLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxXQUFXO0dBQzlNLElBQUksUUFBUSxXQUFXLE1BQU0sZ0JBQWdCLE9BQU8sV0FBVyx1QkFBdUIsT0FBTyxDQUFDLE9BQU87R0FDckcsSUFBSSxPQUFPLE9BQU8sT0FBTyxTQUFTLGVBQWUsUUFBUSxNQUFNLE9BQU8sT0FBTyxJQUFJLE1BQU07UUFDbEYsU0FBUyxvQkFBb0IsUUFBUSxNQUFNLE9BQU8sUUFBUSxNQUFNO0dBQ3JFLE9BQU8sY0FBYyxPQUFPLE1BQU07RUFDbkMsQ0FBQztDQUNGO0NBQ0EsTUFBTSxjQUFjLFFBQVEsTUFBTSxXQUFXO0VBQzVDLE1BQU0sV0FBVyxFQUFFLEdBQUcsTUFBTTtFQUM1QixJQUFJLE9BQU8sT0FBTyxTQUFTO0dBQzFCLFNBQVMsYUFBYSxPQUFPO0dBQzdCLFNBQVMsU0FBUztHQUNsQixTQUFTLFFBQVEsS0FBSztHQUN0QixTQUFTLFVBQVU7R0FDbkIsU0FBUyxhQUFhO0VBQ3ZCLE9BQU8sSUFBSSxPQUFPLE9BQU8sT0FBTztHQUMvQixTQUFTLFNBQVM7R0FDbEIsU0FBUyxRQUFRLE9BQU87RUFDekIsT0FBTyxJQUFJLE9BQU8sT0FBTyxXQUFXO0dBQ25DLFNBQVMsU0FBUztHQUNsQixTQUFTLFFBQVEsT0FBTztFQUN6QjtFQUNBLE9BQU87Q0FDUixDQUFDO0NBQ0QsT0FBTztFQUNOO0VBQ0E7RUFDQSxPQUFPO0NBQ1I7QUFDRDtBQUNBLGVBQWUsb0JBQW9CLFFBQVEsU0FBUyxTQUFTLFFBQVEsV0FBVyxHQUFHO0NBQ2xGLE1BQU0sUUFBUSxVQUFVLEVBQUUsQ0FBQztDQUMzQixJQUFJLFFBQVEsT0FBTyxVQUFVLFFBQVEsV0FBVyxVQUFVLE1BQU0sWUFBWSxNQUFNLE9BQU8sSUFBSSxVQUFVLE1BQU0sUUFBUSxTQUFTO0NBQzlILElBQUksUUFBUSxHQUFHLFFBQVE7Q0FDdkIsS0FBSyxJQUFJLFlBQVksT0FBTyxhQUFhLEdBQUcsYUFBYTtFQUN4RCxNQUFNLFFBQVEsU0FBUyxRQUFRLFFBQVEsVUFBVTtFQUNqRCxJQUFJO0dBQ0gsTUFBTSxVQUFVLGVBQWUsT0FBTyxLQUFLO0dBQzNDLElBQUksU0FBUyxNQUFNO0VBQ3BCLFFBQVE7R0FDUCxRQUFRLGVBQWU7RUFDeEI7RUFDQSxRQUFRLGVBQWU7RUFDdkIsSUFBSSxNQUFNLFFBQVEsbUJBQW1CLE9BQU87Q0FDN0M7Q0FDQSxPQUFPLE9BQU8sVUFBVSxRQUFRO0FBQ2pDO0FBQ0EsU0FBUyxhQUFhLFNBQVMsUUFBUSxHQUFHLFNBQVMsNEJBQTRCO0NBQzlFLEtBQUssSUFBSSxRQUFRLE9BQU8sUUFBUSxRQUFRLFFBQVEsU0FBUyxRQUFRLE1BQU0sQ0FBQyxnQkFBZ0IsTUFBTSxNQUFNO0FBQ3JHO0FBQ0EsZUFBZSxhQUFhLFFBQVEsTUFBTSxTQUFTLFFBQVE7Q0FDMUQsSUFBSSxDQUFDLFNBQVM7RUFDYixNQUFNLFdBQVcsS0FBSyxRQUFRLFdBQVcsVUFBVSxNQUFNLFNBQVM7RUFDbEUsSUFBSSxZQUFZLEdBQUc7R0FDbEIsYUFBYSxLQUFLLFNBQVMsV0FBVyxDQUFDO0dBQ3ZDLE9BQU87SUFDTixRQUFRO0lBQ1I7SUFDQSxNQUFNO0dBQ1A7RUFDRDtFQUNBLE9BQU8sRUFBRSxRQUFRLElBQUk7Q0FDdEI7Q0FDQSxNQUFNLENBQUMsT0FBTyxXQUFXO0NBQ3pCLElBQUksUUFBUSxPQUFPLE9BQU87RUFDekIsTUFBTSxRQUFRLEtBQUssUUFBUTtFQUMzQixNQUFNLFlBQVksS0FBSztFQUN2QixNQUFNLFNBQVM7RUFDZixNQUFNLFFBQVEsUUFBUTtFQUN0QixNQUFNLGFBQWE7RUFDbkIsYUFBYSxLQUFLLFNBQVMsUUFBUSxDQUFDO0VBQ3BDLE9BQU87R0FDTixRQUFRO0dBQ1IsVUFBVTtHQUNWLE1BQU07RUFDUDtDQUNEO0NBQ0EsTUFBTSxXQUFXLFFBQVEsTUFBTSxNQUFNLG9CQUFvQixRQUFRLEtBQUssU0FBUyxTQUFTLE1BQU07Q0FDOUYsTUFBTSxRQUFRLEtBQUssUUFBUTtDQUMzQixNQUFNLFFBQVEsUUFBUTtDQUN0QixNQUFNLFVBQVUsTUFBTTtDQUN0QixNQUFNLFlBQVksS0FBSztDQUN2QixJQUFJLE1BQU0sWUFBWSxPQUFPLFVBQVUsSUFBSTtFQUMxQyxNQUFNLFNBQVM7RUFDZixNQUFNLFlBQVk7RUFDbEIsTUFBTSxRQUFRO0NBQ2YsT0FBTztFQUNOLE1BQU0sU0FBUztFQUNmLE1BQU0sUUFBUTtDQUNmO0NBQ0EsTUFBTSxhQUFhO0NBQ25CLGFBQWEsS0FBSyxTQUFTLFdBQVcsQ0FBQztDQUN2QyxPQUFPO0VBQ04sUUFBUTtFQUNSO0VBQ0EsTUFBTTtDQUNQO0FBQ0Q7QUFDQSxlQUFlLGlCQUFpQixRQUFRLE1BQU0sS0FBSyxRQUFRO0NBQzFELE1BQU0sU0FBUyxDQUFDO0NBQ2hCLEtBQUssSUFBSSxRQUFRLEdBQUcsUUFBUSxLQUFLLFFBQVEsUUFBUSxTQUFTO0VBQ3pELE1BQU0sUUFBUSxLQUFLLFFBQVE7RUFDM0IsSUFBSSxTQUFTLE9BQU8sTUFBTSxRQUFRLFFBQVEsTUFBTSxXQUFXLFdBQVc7RUFDdEUsTUFBTSxRQUFRLFNBQVMsUUFBUSxLQUFLO0VBQ3BDLElBQUk7R0FDSCxNQUFNLFVBQVUsZUFBZSxLQUFLO0dBQ3BDLElBQUksU0FBUztJQUNaLE1BQU0sUUFBUSxRQUFRLFdBQVc7S0FDaEMsUUFBUSxlQUFlO0lBQ3hCLElBQUksVUFBVTtLQUNiLFFBQVEsZUFBZTtLQUN2QixPQUFPLENBQUMsT0FBTyxjQUFjLE9BQU8sZUFBZSxRQUFRLE1BQU0sT0FBTyxPQUFPLE1BQU0sQ0FBQyxDQUFDO0lBQ3hGLENBQUM7SUFDRCxNQUFNLFlBQVksQ0FBQyxDQUFDO0lBQ3BCLE9BQU8sS0FBSyxLQUFLO0dBQ2xCO0VBQ0QsU0FBUyxPQUFPO0dBQ2YsUUFBUSxlQUFlO0dBQ3ZCLE9BQU8sS0FBSyxDQUFDLE9BQU8sY0FBYyxPQUFPLGVBQWUsUUFBUSxNQUFNLE9BQU8sT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDO0VBQzlGO0NBQ0Q7Q0FDQSxLQUFLLE1BQU0sU0FBUyxRQUFRO0VBQzNCLE1BQU0sVUFBVSxNQUFNLFFBQVEsS0FBSyxJQUFJLFFBQVEsTUFBTTtFQUNyRCxJQUFJLFNBQVMsT0FBTztDQUNyQjtBQUNEO0FBQ0EsZUFBZSxZQUFZLFFBQVEsTUFBTSxRQUFRO0NBQ2hELEtBQUssTUFBTSxTQUFTLEtBQUssU0FBUztFQUNqQyxNQUFNLGVBQWUsU0FBUyxRQUFRLEtBQUssQ0FBQyxDQUFDO0VBQzdDLElBQUksYUFBYSxRQUFRLGFBQWEsV0FBVyxhQUFhLFNBQVM7R0FDdEUsTUFBTSxVQUFVO0lBQ2YsS0FBSyxPQUFPLFFBQVE7SUFDcEIsU0FBUyxLQUFLO0lBQ2Q7SUFDQSxRQUFRLE1BQU07SUFDZCxZQUFZLE1BQU07R0FDbkI7R0FDQSxJQUFJO0lBQ0gsTUFBTSxDQUFDLE1BQU0sU0FBUyxXQUFXLE1BQU0sUUFBUSxJQUFJO0tBQ2xELGFBQWEsT0FBTyxPQUFPO0tBQzNCLGFBQWEsVUFBVSxPQUFPO0tBQzlCLGFBQWEsVUFBVSxPQUFPO0lBQy9CLENBQUM7SUFDRCxRQUFRLGVBQWU7SUFDdkIsTUFBTSxPQUFPLE1BQU07SUFDbkIsTUFBTSxRQUFRLE1BQU07SUFDcEIsTUFBTSxjQUFjLE1BQU07SUFDMUIsTUFBTSxTQUFTLE1BQU07SUFDckIsTUFBTSxVQUFVO0lBQ2hCLE1BQU0sVUFBVTtHQUNqQixTQUFTLE9BQU87SUFDZixRQUFRLGVBQWU7SUFDdkIsUUFBUSxNQUFNLEtBQUs7R0FDcEI7RUFDRDtFQUNBLElBQUksTUFBTSxRQUFRLFNBQVMsTUFBTSxXQUFXLGFBQWEsTUFBTSxXQUFXO0NBQzNFO0FBQ0Q7QUFDQSxlQUFlLGtCQUFrQixRQUFRLFVBQVUsZ0JBQWdCLFFBQVE7Q0FDMUUsTUFBTSxVQUFVO0VBQ2Y7RUFDQSxTQUFTLGVBQWUsS0FBSyxXQUFXO0dBQ3ZDLEdBQUc7R0FDSCxxQkFBcUIsS0FBSztHQUMxQixTQUFTLENBQUM7R0FDVixZQUFZO0dBQ1osaUJBQWlCLElBQUksZ0JBQWdCO0VBQ3RDLEVBQUU7Q0FDSDtDQUNBLE1BQU0sa0JBQWtCLGFBQWEsUUFBUSxTQUFTLEdBQUcsUUFBUSxVQUFVLDBCQUEwQjtDQUNyRyxJQUFJLFFBQVEsU0FBUztFQUNwQixVQUFVO0VBQ1YsT0FBTyxlQUFlO0NBQ3ZCO0NBQ0EsUUFBUSxpQkFBaUIsU0FBUyxXQUFXLEVBQUUsTUFBTSxLQUFLLENBQUM7Q0FDM0QsSUFBSTtFQUNILE1BQU0sd0JBQXdCLFFBQVEsUUFBUSxXQUFXLFVBQVUsTUFBTSxTQUFTO0VBQ2xGLElBQUksT0FBTyxRQUFRLGlCQUFpQixVQUFVLHlCQUF5QixHQUFHO0dBQ3pFLE1BQU0sV0FBVyxNQUFNLG9CQUFvQixRQUFRLFFBQVEsU0FBUyxLQUFLLEdBQUcsUUFBUSxxQkFBcUI7R0FDekcsSUFBSSxhQUFhLHVCQUF1QjtJQUN2QyxRQUFRLFFBQVEsc0JBQXNCLENBQUMsWUFBWSxLQUFLO0lBQ3hELFFBQVEsUUFBUSxTQUFTLENBQUMsWUFBWTtHQUN2QztFQUNEO0VBQ0EsTUFBTSxPQUFPLE1BQU0sY0FBYyxRQUFRLFNBQVMsTUFBTTtFQUN4RCxRQUFRLGVBQWU7RUFDdkIsSUFBSSxZQUFZLEtBQUs7RUFDckIsSUFBSSxLQUFLLFVBQVUsRUFBRSxDQUFDLE9BQU8sWUFBWSxZQUFZO09BQ2hELElBQUksS0FBSyxVQUFVLEVBQUUsQ0FBQyxPQUFPLFdBQVc7R0FDNUMsS0FBSyxRQUFRLEtBQUssTUFBTSxvQkFBb0IsUUFBUSxLQUFLLFNBQVMsS0FBSyxTQUFTLE1BQU07R0FDdEYsWUFBWSxLQUFLLElBQUksV0FBVyxLQUFLLFFBQVEsS0FBSyxDQUFDO0VBQ3BEO0VBQ0EsTUFBTSxRQUFRLENBQUM7RUFDZixLQUFLLElBQUksUUFBUSxHQUFHLFFBQVEsV0FBVyxTQUFTO0dBQy9DLE1BQU0sT0FBTyxpQkFBaUIsUUFBUSxNQUFNLE9BQU8sT0FBTyxNQUFNO0dBQ2hFLE1BQU0sS0FBSyxJQUFJO0VBQ2hCO0VBQ0EsSUFBSTtFQUNKLElBQUksVUFBVSxLQUFLLFVBQVUsRUFBRSxDQUFDLE9BQU8sYUFBYSxLQUFLLFVBQVUsS0FBSztFQUN4RSxJQUFJO0dBQ0gsTUFBTSxRQUFRLElBQUksTUFBTSxLQUFLLFNBQVMsS0FBSyxRQUFRLE1BQU0sa0JBQWtCO0lBQzFFLE1BQU0sUUFBUSxLQUFLLFFBQVEsS0FBSztJQUNoQyxNQUFNLFVBQVU7SUFDaEIsSUFBSSxRQUFRLE9BQU8sU0FBUztLQUMzQixNQUFNLGFBQWEsUUFBUTtLQUMzQixNQUFNLFNBQVM7S0FDZixNQUFNLFFBQVEsS0FBSztLQUNuQixNQUFNLFVBQVU7S0FDaEIsTUFBTSxhQUFhO0tBQ25CLE1BQU0sWUFBWSxLQUFLLElBQUk7SUFDNUIsT0FBTyxJQUFJLFFBQVEsT0FBTyxZQUFZO0tBQ3JDLFVBQVUsQ0FBQyxLQUFLLE9BQU8sT0FBTztLQUM5QixNQUFNO0lBQ1AsT0FBTztLQUNOLElBQUksTUFBTSxRQUFRLE9BQU87TUFDeEIsTUFBTSxTQUFTO01BQ2YsTUFBTSxRQUFRLEtBQUs7TUFDbkIsTUFBTSxVQUFVO01BQ2hCLE1BQU0sYUFBYTtLQUNwQjtLQUNBLElBQUksQ0FBQyxpQkFBaUIsUUFBUSxPQUFPLFNBQVMsZ0JBQWdCLENBQUMsS0FBSyxPQUFPLE9BQU87SUFDbkY7R0FDRCxDQUFDLENBQUMsQ0FBQztFQUNKLFNBQVMsT0FBTztHQUNmLElBQUksQ0FBQyxNQUFNLFFBQVEsS0FBSyxHQUFHLE1BQU07R0FDakMsVUFBVTtFQUNYO0VBQ0EsUUFBUSxlQUFlO0VBQ3ZCLElBQUksVUFBVSxFQUFFLENBQUMsT0FBTyxZQUFZO0dBQ25DLGFBQWEsS0FBSyxTQUFTLEdBQUcscUJBQXFCO0dBQ25ELE9BQU87SUFDTixNQUFNO0lBQ04sVUFBVSxRQUFRLEVBQUUsQ0FBQztHQUN0QjtFQUNEO0VBQ0EsSUFBSSxVQUFVLEtBQUssV0FBVztFQUM5QixNQUFNLGtCQUFrQixLQUFLLFFBQVEsV0FBVyxVQUFVLE1BQU0sU0FBUztFQUN6RSxJQUFJO0VBQ0osSUFBSSxTQUFTO0dBQ1osTUFBTSxhQUFhLFFBQVEsT0FBTyxRQUFRLEVBQUUsQ0FBQyxPQUFPLFlBQVksTUFBTSxvQkFBb0IsUUFBUSxLQUFLLFNBQVMsU0FBUyxNQUFNLElBQUksUUFBUTtHQUMzSSxLQUFLLE1BQU0sUUFBUSxPQUFPO0lBQ3pCLElBQUksS0FBSyxTQUFTLFlBQVk7SUFDOUIsTUFBTSxVQUFVLE1BQU0sS0FBSztJQUMzQixJQUFJLFFBQVEsT0FBTyxXQUFXLFFBQVEsS0FBSyxjQUFjLEVBQUUsZ0JBQWdCLEtBQUssUUFBUSxLQUFLLFNBQVM7S0FDckcsVUFBVSxDQUFDLEtBQUssT0FBTyxPQUFPO0tBQzlCLFFBQVEsS0FBSyxRQUFRLE9BQU8sWUFBWSxNQUFNLG9CQUFvQixRQUFRLEtBQUssU0FBUyxTQUFTLE1BQU0sSUFBSSxLQUFLO0tBQ2hIO0lBQ0Q7R0FDRDtHQUNBLGVBQWUsUUFBUTtFQUN4QixPQUFPLGVBQWUsa0JBQWtCLElBQUksS0FBSyxRQUFRLFNBQVM7RUFDbEUsTUFBTSxrQkFBa0IsTUFBTSxpQkFBaUIsUUFBUSxNQUFNLGNBQWMsTUFBTTtFQUNqRixRQUFRLGVBQWU7RUFDdkIsSUFBSSxpQkFBaUI7R0FDcEIsSUFBSSxnQkFBZ0IsRUFBRSxDQUFDLE9BQU8sWUFBWTtJQUN6QyxhQUFhLEtBQUssU0FBUyxHQUFHLHFCQUFxQjtJQUNuRCxPQUFPO0tBQ04sTUFBTTtLQUNOLFVBQVUsZ0JBQWdCLEVBQUUsQ0FBQztJQUM5QjtHQUNEO0dBQ0EsVUFBVTtFQUNYO0VBQ0EsTUFBTSxXQUFXLE1BQU0sYUFBYSxRQUFRLE1BQU0sU0FBUyxNQUFNO0VBQ2pFLElBQUksU0FBUyxhQUFhLEtBQUssR0FBRztHQUNqQyxNQUFNLFFBQVEsS0FBSyxRQUFRLFNBQVM7R0FDcEMsSUFBSSxNQUFNLFFBQVEsTUFBTTtJQUN2QixNQUFNLFFBQVEsU0FBUyxRQUFRLEtBQUs7SUFDcEMsSUFBSTtLQUNILElBQUksU0FBUyxTQUFTLE9BQU8sTUFBTSxlQUFlLE9BQU8sZ0JBQWdCO1VBQ3BFLElBQUksTUFBTSxXQUFXLE1BQU0sUUFBUSxJQUFJLENBQUMsZUFBZSxLQUFLLEdBQUcsZUFBZSxPQUFPLG1CQUFtQixDQUFDLENBQUM7VUFDMUcsTUFBTSxlQUFlLE9BQU8sbUJBQW1CO0lBQ3JELFFBQVEsQ0FBQztJQUNULFFBQVEsZUFBZTtHQUN4QjtFQUNEO0VBQ0EsUUFBUSxlQUFlO0VBQ3ZCLE1BQU0sWUFBWSxRQUFRO0dBQ3pCLFVBQVUsS0FBSztHQUNmLFNBQVMsS0FBSztFQUNmLEdBQUcsTUFBTTtFQUNULFFBQVEsZUFBZTtFQUN2QixPQUFPLFdBQVcsV0FBVyxZQUFZO0dBQ3hDLElBQUksQ0FBQyxTQUFTLFVBQVU7RUFDekIsQ0FBQztFQUNELE9BQU87R0FDTixNQUFNO0dBQ04sUUFBUSxTQUFTO0dBQ2pCLFNBQVMsS0FBSztFQUNmO0NBQ0QsVUFBVTtFQUNULFFBQVEsb0JBQW9CLFNBQVMsU0FBUztDQUMvQztBQUNEO0FBQ0EsZUFBZSxnQkFBZ0IsUUFBUSxNQUFNO0NBQzVDLElBQUksQ0FBQyxNQUFNLHFCQUFxQixPQUFPLHFCQUFxQjtDQUM1RCxNQUFNLE9BQU8sT0FBTztDQUNwQixNQUFNLFdBQVcsT0FBTztDQUN4QixNQUFNLGNBQWMsT0FBTztDQUMzQixJQUFJO0NBQ0osSUFBSTtFQUNILE1BQU0sWUFBWSxPQUFPLGNBQWM7R0FDdEMsSUFBSSxLQUFLO0dBQ1QsUUFBUTtHQUNSLFFBQVE7R0FDUixNQUFNO0dBQ04sT0FBTztHQUNQLHdCQUF3QjtFQUN6QixDQUFDO0VBQ0QsSUFBSSxLQUFLLGVBQWUsVUFBVSxZQUVqQyxNQUFNLFNBQVMsRUFBRSxNQURKLFVBQVUsY0FBYyxJQUNmLENBQUM7RUFHeEIsTUFBTSxhQUFhLHNCQUFzQixNQURwQixPQUFPLE9BQU8saUJBQWlCLElBQ0wsQ0FBWTtFQUMzRCxPQUFPLEtBQUs7R0FDWCxNQUFNO0dBQ04sR0FBRztFQUNKLENBQUM7RUFDRCxPQUFPLEtBQUs7R0FDWCxNQUFNO0dBQ04sR0FBRztFQUNKLENBQUM7RUFDRCxNQUFNLFNBQVMsZUFBZTtFQUM5QixTQUFTLE1BQU0sUUFBUSxrQkFBa0IsUUFBUSxNQUFNLE9BQU8sWUFBWSxJQUFJLEdBQUcsTUFBTSxPQUFPLEdBQUcsTUFBTSxPQUFPO0VBQzlHLE1BQU0sU0FBUyxlQUFlO0NBQy9CLFNBQVMsT0FBTztFQUNmLE1BQU0sU0FBUyxlQUFlO0VBQzlCLElBQUksQ0FBQyxXQUFXLEtBQUssR0FBRyxNQUFNO0VBQzlCLE1BQU0sUUFBUSxnQkFBZ0I7RUFDOUIsU0FBUztHQUNSLE1BQU07R0FDTixVQUFVLE9BQU8sZ0JBQWdCLEtBQUs7RUFDdkM7Q0FDRDtDQUNBLE9BQU8sZ0JBQWdCO0NBQ3ZCLElBQUksVUFBVTtDQUNkLE9BQU8sWUFBWTtFQUNsQixPQUFPLE9BQU8sU0FBUyxJQUFJLElBQUk7RUFDL0IsT0FBTyxPQUFPLE9BQU8sSUFBSSxNQUFNO0VBQy9CLElBQUksT0FBTyxTQUFTLFVBQVU7R0FDN0IsT0FBTyxhQUFhLE9BQU87R0FDM0IsVUFBVSxPQUFPLGdCQUFnQixhQUFhLE9BQU8sT0FBTztHQUM1RCxPQUFPLE9BQU8sV0FBVyxPQUFPLE9BQU87R0FDdkMsT0FBTyxPQUFPLGlCQUFpQixJQUFJLElBQUk7RUFDeEM7Q0FDRCxDQUFDO0NBQ0QsSUFBSSxPQUFPLFNBQVMsVUFBVSxrQkFBa0IsUUFBUSxVQUFVLE9BQU8sU0FBUyxhQUFhLE9BQU87Q0FDdEcsT0FBTyxnQkFBZ0IsUUFBUTtDQUMvQixPQUFPLGlCQUFpQixLQUFLO0FBQzlCOzs7Ozs7O0FDM2tCQSxJQUFJLFdBQUEsYUFBbUJXO0FBQ3ZCLElBQUksa0JBQThCLE9BQU8sV0FBVyxjQUFBLGFBQXNCLFlBQUEsYUFBb0I7Ozs7Ozs7QUNEOUYsSUFBTSx1QkFBdUIsT0FBTyxJQUFJLHNCQUFzQjs7Ozs7Ozs7Ozs7OztBQWE5RCxTQUFTLE1BQU0sVUFBVSxTQUFTO0NBQ2pDLE1BQU0sVUFBVTtDQUNoQixJQUFJLFFBQVEsdUJBQXVCLE9BQU87Q0FDMUMsUUFBUSx3QkFBd0IsRUFBRSxRQUFRLFVBQVU7Q0FDcEQsUUFBUSxNQUFNLFNBQVM7RUFDdEIsUUFBUSxxQkFBcUIsQ0FBQyxTQUFTO0VBQ3ZDLFFBQVEscUJBQXFCLENBQUMsT0FBTztDQUN0QyxDQUFDLENBQUMsQ0FBQyxPQUFPLFVBQVU7RUFDbkIsUUFBUSxxQkFBcUIsQ0FBQyxTQUFTO0VBQ3ZDLFFBQVEscUJBQXFCLENBQUMsUUFBUTtHQUNyQyxPQUFPLFNBQVMsa0JBQWtCLHNCQUFBLENBQXVCLEtBQUs7R0FDOUQsaUJBQWlCO0VBQ2xCO0NBQ0QsQ0FBQztDQUNELE9BQU87QUFDUjs7QUNsQ0EsSUFBTSxpQkFBaUI7O0FDQXZCLElBQU0sa0JBQWtCO0FBQ3hCLFNBQVMsb0JBQW9CLGtCQUFrQixNQUFNO0NBQ3BELElBQUksQ0FBQyxrQkFBa0I7Q0FDdkIsSUFBSSxPQUFPLHFCQUFxQixVQUFVLE9BQU87Q0FDakQsT0FBTyxpQkFBaUI7QUFDekI7QUFDQSxTQUFTLHdCQUF3QixVQUFVO0NBQzFDLE9BQU8sVUFBVSxnQkFBZ0I7QUFDbEM7QUFDQSxTQUFTLHNCQUFzQixVQUFVLE1BQU0sa0JBQWtCO0NBQ2hFLE1BQU0sY0FBYyx5QkFBeUIsSUFBSTtDQUNqRCxNQUFNLGNBQWMsb0JBQW9CLGtCQUFrQixRQUFRLEtBQUssWUFBWTtDQUNuRixPQUFPO0VBQ04sR0FBRyx3QkFBd0IsUUFBUSxNQUFNLFNBQVM7R0FDakQsS0FBSztHQUNMLElBQUk7RUFDTCxJQUFJLEVBQUUsS0FBSyxnQkFBZ0I7RUFDM0IsTUFBTSxZQUFZO0VBQ2xCLGVBQWU7RUFDZixHQUFHLGNBQWMsRUFBRSxZQUFZLElBQUksQ0FBQztDQUNyQztBQUNEO0FBQ0EsU0FBUyx5QkFBeUIsTUFBTTtDQUN2QyxJQUFJLE9BQU8sU0FBUyxVQUFVLE9BQU87RUFDcEMsTUFBTTtFQUNOLGFBQWEsS0FBSztDQUNuQjtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMscUJBQXFCLFFBQVEsTUFBTTtDQUMzQyxJQUFJLEtBQUssV0FBVyxHQUFHO0NBQ3ZCLElBQUksS0FBSyxXQUFXLEdBQUc7RUFDdEIsT0FBTyxLQUFLLEtBQUssRUFBRTtFQUNuQjtDQUNEO0NBQ0EsTUFBTSx1QkFBdUIsSUFBSSxJQUFJO0NBQ3JDLEtBQUssTUFBTSxPQUFPLE1BQU07RUFDdkIsTUFBTSxNQUFNLEtBQUssVUFBVSxHQUFHO0VBQzlCLElBQUksS0FBSyxJQUFJLEdBQUcsR0FBRztFQUNuQixLQUFLLElBQUksR0FBRztFQUNaLE9BQU8sS0FBSyxHQUFHO0NBQ2hCO0FBQ0Q7QUFJQSxTQUFTLHVCQUF1QixNQUFNO0NBQ3JDLElBQUksT0FBTyxTQUFTLFVBQVUsT0FBTztFQUNwQyxNQUFNO0VBQ04sYUFBYSxLQUFLO0NBQ25CO0NBQ0EsT0FBTztBQUNSOzs7Ozs7QUNoREEsSUFBTSxXQUFXLE9BQU8sU0FBUztDQUNoQyxNQUFNLFFBQVEsS0FBSyxNQUFNLEdBQUc7Q0FDNUIsSUFBSTtDQUNKLElBQUksSUFBSTtDQUNSLElBQUksUUFBUTtDQUNaLFFBQVEsT0FBTyxNQUFNLFNBQVMsUUFBUSxTQUFTLE1BQU0sUUFBUSxNQUFNO0NBQ25FLE9BQU8sU0FBUztBQUNqQjs7QUNWQSxTQUFTLHNCQUFzQixTQUFTLFVBQVUsT0FBTyxrQkFBa0I7Q0FDMUUsTUFBTSxlQUFlLGlCQUFpQixPQUFPO0NBQzdDLE1BQU0sZUFBZSxDQUFDO0NBQ3RCLE1BQU0sa0JBQWtCLENBQUM7Q0FDekIsS0FBSyxNQUFNLFNBQVMsY0FBYyxLQUFLLE1BQU0sVUFBVSxNQUFNLFFBQVEsTUFBTSxPQUFPLElBQUksTUFBTSxVQUFVLENBQUMsR0FBRztFQUN6RyxJQUFJLENBQUMsUUFBUTtFQUNiLE1BQU0sRUFBRSxVQUFVLEdBQUcsVUFBVTtFQUMvQixhQUFhLEtBQUs7R0FDakIsS0FBSztHQUNMLE9BQU87SUFDTixHQUFHO0lBQ0gsR0FBRztJQUNIO0dBQ0Q7R0FDQTtFQUNELENBQUM7Q0FDRjtDQUNBLElBQUksVUFBVSxLQUFLLE1BQU0sU0FBUyxjQUFjLEtBQUssTUFBTSxTQUFTLFNBQVMsT0FBTyxNQUFNLFFBQVEsRUFBRSxXQUFXLENBQUMsR0FBRyxnQkFBZ0IsS0FBSztFQUN2SSxLQUFLO0VBQ0wsT0FBTztHQUNOLEdBQUcsTUFBTTtHQUNUO0VBQ0Q7RUFDQSxVQUFVLE1BQU07Q0FDakIsQ0FBQztDQUNELE9BQU8sQ0FBQyxjQUFjLGVBQWU7QUFDdEM7QUFDQSxTQUFTLHNCQUFzQixDQUFDLGNBQWMsa0JBQWtCLHlCQUF5QjtDQUN4RixJQUFJLENBQUMseUJBQXlCLE9BQU8sQ0FBQyxHQUFHLGNBQWMsR0FBRyxlQUFlO0NBQ3pFLE9BQU87RUFDTixHQUFHLHdCQUF3QjtFQUMzQixHQUFHO0VBQ0gsR0FBRztFQUNILHdCQUF3QjtDQUN6QjtBQUNEOztBQy9CQSxJQUFJLFlBQVksTUFBTTtDQUNyQixJQUFJLEtBQUs7RUFDUixPQUFPLEtBQUs7Q0FDYjtDQUNBLElBQUksS0FBSztFQUNSLE9BQU8sS0FBSztDQUNiO0NBQ0EsSUFBSSxPQUFPO0VBQ1YsT0FBTyxLQUFLO0NBQ2I7Q0FDQSxJQUFJLFdBQVc7RUFDZCxPQUFPLEtBQUs7Q0FDYjtDQUNBLFlBQVksU0FBUztFQUNwQixLQUFLLFFBQVEsa0JBQWtCO0dBQzlCLEtBQUssZ0JBQWdCO0dBQ3JCLEtBQUssVUFBVSxLQUFLO0dBQ3BCLE1BQU0sVUFBVSxLQUFLO0dBQ3JCLE1BQU0sU0FBUyxDQUFDLFNBQVMsUUFBUSxDQUFDLFNBQVM7R0FDM0MsS0FBSyxjQUFjLEtBQUssUUFBUSxpQkFBaUI7R0FDakQsSUFBSSxRQUFRLEtBQUssUUFBUTtRQUNwQixJQUFJLENBQUMsS0FBSyxhQUM2QixNQUFNLElBQUksTUFBTSwrSEFBK0g7R0FHM0wsSUFBSSxPQUFPLFNBQVMsY0FBYyxTQUFTO0dBQzNDLElBQUksUUFBUSxTQUFTLEtBQUssT0FBTyxhQUFhLElBQUk7R0FDbEQsTUFBTSxXQUFXLFNBQVMsTUFBTTtHQUNoQyxNQUFNLEtBQUssU0FBUyxjQUFjLFdBQVcsS0FBSyxZQUFZLE9BQU8sYUFBYSxLQUFLLEtBQUssWUFBWSxNQUFNLE9BQU8sWUFBWSxHQUFHO0dBQ3BJLElBQUksU0FBUyxZQUFZLE9BQU87R0FDaEMsTUFBTSxXQUFXLE9BQU8sYUFBYSxNQUFNLFNBQVMsS0FBSyxJQUFJLEtBQUssWUFBWSxXQUFXLFVBQVUsS0FBSyxZQUFZLFdBQVcsTUFBTSxJQUFJO0dBQ3pJLEtBQUssUUFBUTtHQUNiLEtBQUssTUFBTTtHQUNYLEtBQUssWUFBWTtHQUNqQixLQUFLLE1BQU0sY0FBYyxRQUFRO0VBQ2xDO0VBQ0EsS0FBSyxlQUFlLGFBQWE7R0FDaEMsT0FBTyxLQUFLLGlCQUFpQixRQUFRO0VBQ3RDO0VBQ0EsS0FBSyxvQkFBb0IsYUFBYTtHQUNyQyxJQUFJLE1BQU0sUUFBUSxRQUFRLEdBQUcsS0FBSyxXQUFXO0dBQzdDLElBQUksT0FBTyxhQUFhLFlBQVksYUFBYSxNQUFNLEtBQUssV0FBVyxPQUFPLE9BQU8sUUFBUTtHQUM3RixPQUFPO0VBQ1I7RUFDQSxLQUFLLHNCQUFzQjtHQUMxQixPQUFPO0VBQ1I7RUFDQSxLQUFLLGdCQUFnQixZQUFZO0dBQ2hDLE9BQU8sT0FBTyxLQUFLLFNBQVMsT0FBTztHQUNuQyxPQUFPO0VBQ1I7RUFDQSxLQUFLLFVBQVUsWUFBWTtHQUMxQixPQUFPLE9BQU8sS0FBSyxTQUFTLE9BQU87R0FDbkMsT0FBTztFQUNSO0VBQ0EsS0FBSyxRQUFRLFdBQVc7R0FDdkIsS0FBSyxTQUFTO0dBQ2QsT0FBTztFQUNSO0VBQ0EsS0FBSyxZQUFZLFNBQVMsU0FBUztHQUNsQyxNQUFNLEtBQUs7R0FDWCxHQUFHO0VBQ0osQ0FBQztFQUNELEtBQUssVUFBVSxXQUFXLENBQUM7RUFDM0IsS0FBSyxTQUFTLENBQUMsU0FBUztFQUN4QixJQUFJLFNBQVMsTUFBTSxTQUFTLE1BQU0sTUFBTSxJQUFJLE1BQU0scURBQXFEO0NBQ3hHO0FBQ0Q7QUFDQSxJQUFJLGVBQWUsTUFBTTtDQUN4QixZQUFZLEVBQUUsTUFBTTtFQUNuQixLQUFLLFlBQVksU0FBUztHQUN6QixPQUFPLFNBQVM7SUFDZixTQUFTLEtBQUs7SUFDZCxHQUFHO0dBQ0osQ0FBQztFQUNGO0VBQ0EsS0FBSyxZQUFZLFNBQVMsU0FBUztHQUNsQyxNQUFNLEtBQUs7R0FDWCxHQUFHO0VBQ0osQ0FBQztFQUNELEtBQUssS0FBSztDQUNYO0FBQ0Q7QUFDQSxJQUFJLGdCQUFnQixjQUFjLFVBQVU7Q0FDM0MsWUFBWSxTQUFTO0VBQ3BCLE1BQU0sT0FBTztDQUNkO0FBQ0Q7O0FDNUZBLElBQU0sc0JBQXNCLFlBQVk7Q0FDdkMsT0FBTztFQUNOLHVCQUF1QixRQUFRO0VBQy9CLFlBQVksUUFBUTtDQUNyQjtBQUNEOzs7Ozs7Ozs7Ozs7QUNNQSxTQUFTLG1CQUFtQixNQUFNO0NBQ2pDLFFBQVEsRUFBRSxRQUFRLFdBQVc7RUFDNUIsTUFBTSxFQUFFLFFBQVEsY0FBYyxTQUFTLEtBQUssUUFBUSxJQUFJO0VBQ3hELElBQUksU0FBUyxNQUFNO0dBQ2xCLE1BQU0sT0FBTztJQUNaLEdBQUc7SUFDSCxHQUFHO0dBQ0o7R0FDQSxNQUFNLFVBQVUsS0FBSztHQUNyQixNQUFNLFdBQVcsS0FBSztHQUN0QixLQUFLLE1BQU0sT0FBTyxTQUFTLEtBQUssS0FBSyxDQUFDLEdBQUcsSUFBSSxZQUFZLE9BQU8sS0FBSyxVQUFVLEdBQUcsS0FBSyxVQUFVLE9BQU8sTUFBTSxRQUFRLElBQUksR0FBRyxDQUFDLEdBQUcsT0FBTyxLQUFLO0dBQzdJLEtBQUssTUFBTSxPQUFPLEtBQUssY0FBYyxDQUFDLEdBQUcsT0FBTyxLQUFLO0dBQ3JELEtBQUssTUFBTSxPQUFPLEtBQUssV0FBVyxLQUFLLEtBQUssQ0FBQyxHQUFHLElBQUksT0FBTyxVQUFVLENBQUMsS0FBSyxZQUFZLElBQUksR0FBRyxLQUFLLEVBQUUsS0FBSyxTQUFTLElBQUksR0FBRyxNQUFNLFlBQVksT0FBTyxLQUFLLFVBQVUsR0FBRyxLQUFLLFVBQVUsT0FBTyxNQUFNLEtBQUssUUFBUSxJQUFJLEdBQUcsQ0FBQyxLQUFLLEtBQUssT0FBTyxPQUFPO0dBQzlPLE9BQU87RUFDUjtFQUNBLE1BQU0sT0FBTyxFQUFFLEdBQUcsYUFBYTtFQUMvQixNQUFNLFdBQVcsS0FBSztFQUN0QixLQUFLLE1BQU0sT0FBTyxNQUFNO0dBQ3ZCLE1BQU0sWUFBWTtHQUNsQixJQUFJLEVBQUUsS0FBSyxZQUFZLElBQUksU0FBUyxLQUFLLEtBQUssU0FBUyxJQUFJLFNBQVMsTUFBTSxZQUFZLE9BQU8sS0FBSyxVQUFVLFNBQVMsS0FBSyxVQUFVLE9BQU8sTUFBTSxLQUFLLFFBQVEsSUFBSSxTQUFTLENBQUMsUUFBUSxFQUFFLE9BQU8sU0FBUyxPQUFPLFVBQVUsS0FBSyxXQUFXLElBQUksU0FBUyxLQUFLLFVBQVUsS0FBSyxNQUFNLEtBQUssVUFBVSxJQUFJLFNBQVMsQ0FBQyxJQUFJLEtBQUssT0FBTyxPQUFPO0VBQ25VO0VBQ0EsT0FBTztDQUNSO0FBQ0Q7Ozs7Ozs7Ozs7O0FBV0EsU0FBUyxrQkFBa0IsT0FBTztDQUNqQyxTQUFTLEVBQUUsUUFBUSxNQUFNLFdBQVc7RUFDbkMsSUFBSSxVQUFVLE1BQU07R0FDbkIsT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFNBQVMsUUFBUTtJQUNwQyxJQUFJLE1BQU0sQ0FBQyxLQUFLLCtCQUErQixJQUFJLElBQUksRUFBQSxDQUFHLElBQUksR0FBRztHQUNsRSxDQUFDO0dBQ0QsT0FBTyxDQUFDO0VBQ1Q7RUFDQSxNQUFNLFNBQVMsRUFBRSxHQUFHLEtBQUssTUFBTSxFQUFFO0VBQ2pDLElBQUksTUFBTSxRQUFRLEtBQUssR0FBRyxNQUFNLFNBQVMsUUFBUTtHQUNoRCxPQUFPLE9BQU87R0FDZCxJQUFJLE1BQU0sQ0FBQyxLQUFLLCtCQUErQixJQUFJLElBQUksRUFBQSxDQUFHLElBQUksR0FBRztFQUNsRSxDQUFDO09BQ0ksT0FBTyxRQUFRLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxLQUFLLFdBQVc7R0FDcEQsSUFBSSxVQUFVLE9BQU8sTUFBTSxLQUFLLEdBQUc7SUFDbEMsT0FBTyxPQUFPO0lBQ2QsSUFBSSxNQUFNLENBQUMsS0FBSyw0QkFBNEIsSUFBSSxJQUFJLEVBQUEsQ0FBRyxJQUFJLEtBQUssS0FBSztHQUN0RTtFQUNELENBQUM7RUFDRCxPQUFPO0NBQ1I7QUFDRDs7Ozs7O0FDOURBLFNBQVMsMkJBQTJCLE1BQU07Q0FFeEMsSUFBSSxDQUFDLEtBQUssT0FBTyw4Q0FBOEMsS0FBSyxLQUFLLEdBQUcsR0FBRyxNQUFNLElBQUksTUFBTSxtQ0FBbUMsS0FBSyxVQUFVLEtBQUssR0FBRyxFQUFFLHNLQUFzSztDQUVsVSxPQUFPO0FBQ1I7Ozs7QUNKQSxTQUFTLFdBQVcsRUFBRSxTQUFTLFlBQVk7Q0FDMUMsSUFBSSxVQUFVLE9BQU8sU0FBUyxRQUFRO0NBQ3RDLE1BQU0sVUFBVSxNQUFNLFFBQVE7Q0FDOUIsSUFBSSxRQUFRLHFCQUFxQixDQUFDLFdBQVcsV0FBVyxNQUFNO0NBQzlELElBQUksUUFBUSxxQkFBcUIsQ0FBQyxXQUFXLFNBQVMsTUFBTSxRQUFRLHFCQUFxQixDQUFDO0NBQzFGLE9BQU8sUUFBUSxxQkFBcUIsQ0FBQztBQUN0Qzs7Ozs7QUFLQSxTQUFTLE1BQU0sT0FBTztDQUNyQixNQUFNLFFBQXdCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFlBQVksRUFBRSxHQUFHLE1BQU0sQ0FBQztDQUMxRCxJQUFJLE1BQU0sVUFBVSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBQSxhQUFZLFVBQVU7RUFDaEUsVUFBVSxNQUFNO0VBQ2hCLFVBQVU7Q0FDWCxDQUFDO0NBQ0QsT0FBTztBQUNSO0FBQ0EsU0FBUyxXQUFXLE9BQU87Q0FDMUIsTUFBTSxPQUFPLFdBQVcsS0FBSztDQUM3QixPQUFPLE1BQU0sU0FBUyxJQUFJO0FBQzNCOztBQ3hCQSxJQUFJLDJCQUFBLGFBQTJFLGNBQWMsS0FBSyxDQUFDO0FBQ25HLFNBQVMsK0JBQStCLFNBQVMsV0FBVztDQUMzRCxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSx5QkFBeUIsVUFBVTtFQUM3RCxPQUFPO0VBQ1AsVUFBVTtDQUNYLENBQUM7QUFDRjs7QUNMQSxJQUFJLGdCQUFnQixjQUFBLGFBQXNCLFVBQVU7Q0FDbkQsWUFBWSxHQUFHLE9BQU87RUFDckIsTUFBTSxHQUFHLEtBQUs7RUFDZCxLQUFLLFFBQVEsRUFBRSxPQUFPLEVBQUU7RUFDeEIsS0FBSyxjQUFjO0dBQ2xCLEtBQUssU0FBUyxFQUFFLE9BQU8sRUFBRSxDQUFDO0VBQzNCO0NBQ0Q7Q0FDQSxPQUFPLHlCQUF5QixPQUFPLE9BQU87RUFDN0MsTUFBTSxXQUFXLE1BQU0sWUFBWTtFQUNuQyxJQUFJLE1BQU0sU0FBUyxNQUFNLGFBQWEsVUFBVSxPQUFPO0dBQ3REO0dBQ0EsT0FBTztFQUNSO0VBQ0EsT0FBTyxFQUFFLFNBQVM7Q0FDbkI7Q0FDQSxPQUFPLHlCQUF5QixPQUFPO0VBQ3RDLE9BQU8sRUFBRSxPQUFPLENBQUMsS0FBSyxFQUFFO0NBQ3pCO0NBQ0Esa0JBQWtCLE9BQU8sV0FBVztFQUNuQyxLQUFLLE1BQU0sVUFBVSxPQUFPLFNBQVM7Q0FDdEM7Q0FDQSxTQUFTO0VBQ1IsTUFBTSxRQUFRLEtBQUssTUFBTTtFQUN6QixJQUFJLE9BS0gsT0FBK0MsK0JBSnpDLGFBQWtCLGNBQWMsS0FBSyxNQUFNLGtCQUFrQixnQkFBZ0I7R0FDbEYsT0FBTyxNQUFNO0dBQ2IsT0FBTyxLQUFLO0VBQ2IsQ0FDOEUsR0FBUyxnQkFBZ0I7RUFFeEcsT0FBTyxLQUFLLE1BQU07Q0FDbkI7QUFDRDtBQUNBLFNBQVMsZUFBZSxFQUFFLFNBQVM7Q0FDbEMsTUFBTSxDQUFDLE1BQU0sV0FBQSxhQUFtQixTQUFTLElBQXFDO0NBQzlFLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsS0FBQSxDQUFLLE9BQU87RUFDbEMsT0FBTztHQUNOLFNBQVM7R0FDVCxVQUFVO0VBQ1g7RUFDQSxVQUFVO0dBQ08saUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUssT0FBTztJQUMzQixPQUFPO0tBQ04sU0FBUztLQUNULFlBQVk7S0FDWixLQUFLO0lBQ047SUFDQSxVQUFVLENBQWlCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFVBQVU7S0FDeEMsT0FBTyxFQUFFLFVBQVUsT0FBTztLQUMxQixVQUFVO0lBQ1gsQ0FBQyxHQUFtQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVO0tBQ2pDLE9BQU87TUFDTixZQUFZO01BQ1osVUFBVTtNQUNWLFFBQVE7TUFDUixTQUFTO01BQ1QsWUFBWTtNQUNaLGNBQWM7S0FDZjtLQUNBLGVBQWUsU0FBUyxNQUFNLENBQUMsQ0FBQztLQUNoQyxVQUFVLE9BQU8sZUFBZTtJQUNqQyxDQUFDLENBQUM7R0FDSCxDQUFDO0dBQ2UsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksT0FBTyxFQUFFLE9BQU8sRUFBRSxRQUFRLFNBQVMsRUFBRSxDQUFDO0dBQzFELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLE9BQU8sRUFBRSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxPQUFPO0lBQ3hFLE9BQU87S0FDTixVQUFVO0tBQ1YsUUFBUTtLQUNSLGNBQWM7S0FDZCxTQUFTO0tBQ1QsT0FBTztLQUNQLFVBQVU7SUFDWDtJQUNBLFVBQVUsT0FBTyxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxRQUFRLEVBQUUsVUFBVSxNQUFNLFFBQVEsQ0FBQyxJQUFJO0dBQ3ZGLENBQUMsRUFBRSxDQUFDLElBQUk7RUFDVDtDQUNELENBQUM7QUFDRjs7QUMvRUEsSUFBSSxvQkFBb0I7QUFDeEIsSUFBSSwwQkFBMEI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQWtCOUIsU0FBUyxXQUFXLEVBQUUsVUFBVSxXQUFXLFFBQVE7Q0FDbEQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUEsYUFBVSxVQUFVLEVBQUUsVUFBVSxZQUFZLElBQUksV0FBVyxTQUFTLENBQUM7QUFDN0Y7O0FBRUEsU0FBUyxZQUFZLFVBQVUsTUFBTTtDQUNwQyxPQUFBLGFBQWEscUJBQXFCLFdBQVcsYUFBYSxVQUFVLG9CQUFvQixXQUFXO0FBQ3BHO0FBQ0EsU0FBUyxZQUFZO0NBQ3BCLGFBQWEsQ0FBQztBQUNmOztBQzdCQSxJQUFJLGdCQUFBLGFBQXdCLGNBQWMsSUFBSTs7Ozs7Ozs7Ozs7O0FDVzlDLFNBQVMsVUFBVSxNQUFNO0NBQ3hCLE1BQU0sUUFBQSxhQUFnQixXQUFXLGFBQWE7Q0FDOUMsSUFBSSxDQUFDLE9BQU8sa0JBQWtCLElBQUk7Q0FDbEMsT0FBTztBQUNSO0FBQ0EsU0FBUyxrQkFBa0IsTUFBTTtDQUNoQyxJQUE4QyxNQUFNLFFBQVEsTUFBTyxRQUFRLEtBQUssc0VBQXNFO0FBQ3ZKOztBQ2pCQSxTQUFTLGdCQUFnQixRQUFRLFNBQVM7Q0FDekMsTUFBTSxRQUFRLE9BQU8sT0FBTztDQUM1QixNQUFNLDRCQUE0QixJQUFJLElBQUk7Q0FDMUMsSUFBSTtDQUNKLElBQUk7Q0FDSixNQUFNLFVBQVUsYUFBYTtFQUM1QixJQUFJLENBQUMsa0JBQWtCLFFBQVEsU0FBUyxRQUFRLEdBQUc7R0FDbEQsU0FBUztHQUNULFVBQVUsU0FBUyxhQUFhLFNBQVMsQ0FBQztFQUMzQztDQUNEO0NBQ0EsT0FBTyxPQUFPLFVBQVUsTUFBTSxJQUFJLElBQUksYUFBYTtFQUNsRCxJQUFJLENBQUMsVUFBVSxNQUFNO0dBQ3BCLFNBQVMsTUFBTSxJQUFJO0dBQ25CLGNBQWMsTUFBTSxVQUFVLE1BQU0sQ0FBQyxDQUFDO0VBQ3ZDO0VBQ0EsVUFBVSxJQUFJLFFBQVE7RUFDdEIsYUFBYTtHQUNaLFVBQVUsT0FBTyxRQUFRO0dBQ3pCLElBQUksQ0FBQyxVQUFVLE1BQU07SUFDcEIsWUFBWTtJQUNaLFNBQVMsS0FBSztHQUNmO0VBQ0Q7Q0FDRCxDQUFDO0FBQ0Y7QUFDQSxJQUFJLGVBQUEsYUFBdUIsY0FBYyxLQUFLLENBQUM7QUFDL0MsSUFBSSxvQkFBQSxhQUE0QixjQUFjLEtBQUssQ0FBQzs7O0FDdEJwRCxTQUFTLHFCQUFxQixFQUFFLFFBQVEsUUFBUSxhQUFhO0NBQzVELE9BQU87RUFDTjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0Q7Q0FDQSxTQUFTLEtBQUssS0FBSyxLQUFLLFNBQVM7RUFDaEMsTUFBTSxVQUFVLElBQUk7RUFDcEIsSUFBSSxZQUFZLEtBQUssS0FBSyxRQUFRLFFBQVEsS0FBSztFQUMvQyxNQUFNLFVBQVUsWUFBWSxLQUFLLElBQUksUUFBUSxVQUFVLElBQUk7RUFDM0QsSUFBSSxZQUFZLEtBQUssS0FBSyxRQUFRLFFBQVEsS0FBSztHQUM5QyxRQUFRLFVBQVU7R0FDbEIsSUFBSSxXQUFXO0dBQ2Y7RUFDRDtFQUNBLE1BQU0sVUFBVSxJQUFJO0VBQ3BCLElBQUksWUFBWSxLQUFLLEtBQUssUUFBUSxZQUFZLFdBQVcsUUFBUSxRQUFRLEtBQUs7RUFDOUUsTUFBTSxVQUFVLElBQUksV0FBVyxJQUFJLFdBQVc7R0FDN0M7R0FDQTtHQUNBO0dBQ0E7R0FDQTtHQUNBO0dBQ0EsU0FBUyxLQUFLO0VBQ2Y7RUFDQSxJQUFJLFlBQVksS0FBSyxHQUFHLFFBQVEsVUFBVTtFQUMxQyxJQUFJLFlBQVksS0FBSyxHQUFHLFFBQVEsVUFBVTtPQUNyQyxJQUFJLE9BQU87RUFDaEIsSUFBSSxZQUFZLEtBQUssR0FBRyxRQUFRLFVBQVU7T0FDckMsSUFBSSxPQUFPO0NBQ2pCO0NBQ0EsU0FBUyxPQUFPLE1BQU0sTUFBTSxLQUFLLEtBQUs7RUFDckMsTUFBTSxNQUFNLEtBQUs7RUFDakIsTUFBTSxVQUFVLEtBQUs7RUFDckIsTUFBTSxVQUFVLEtBQUs7RUFDckIsTUFBTSxVQUFVLEtBQUs7RUFDckIsTUFBTSxVQUFVLEtBQUs7RUFDckIsSUFBSSxZQUFZLEtBQUssR0FBRyxRQUFRLFVBQVU7T0FDckMsSUFBSSxXQUFXO0VBQ3BCLElBQUksWUFBWSxLQUFLLEdBQUcsUUFBUSxVQUFVO09BQ3JDLElBQUksT0FBTztFQUNoQixJQUFJLFlBQVksS0FBSyxHQUFHLFFBQVEsVUFBVTtPQUNyQyxJQUFJLFdBQVc7RUFDcEIsSUFBSSxZQUFZLEtBQUssR0FBRyxRQUFRLFVBQVU7T0FDckMsS0FBSyxJQUFJLE9BQU8sYUFBYSxLQUFLLEdBQUcsVUFBVSxHQUFHO0VBQ3ZELE9BQU87Q0FDUjtDQUNBLFNBQVMsVUFBVSxNQUFNO0VBQ3hCLElBQUksT0FBTyxLQUFLO0VBQ2hCLElBQUk7RUFDSixLQUFLLEdBQUc7R0FDUCxNQUFNLE1BQU0sS0FBSztHQUNqQixJQUFJLFFBQVEsSUFBSTtHQUNoQixJQUFJLEVBQUUsUUFBUSxLQUFLLElBQUksUUFBUSxRQUFRO1FBQ2xDLElBQUksRUFBRSxRQUFTLEtBQVMsUUFBUTtRQUNoQyxJQUFJLEVBQUUsUUFBUSxJQUFJLElBQUksUUFBUSxRQUFRLEtBQUs7UUFDM0MsSUFBSSxFQUFFLFFBQVMsT0FBYSxZQUFZLE1BQU0sR0FBRyxHQUFHO0lBQ3hELElBQUksUUFBUSxRQUFTO0lBQ3JCLFNBQVM7R0FDVixPQUFPLFFBQVE7R0FDZixJQUFJLFFBQVEsR0FBRyxPQUFPLEdBQUc7R0FDekIsSUFBSSxRQUFRLEdBQUc7SUFDZCxNQUFNLFVBQVUsSUFBSTtJQUNwQixJQUFJLFlBQVksS0FBSyxHQUFHO0tBQ3ZCLE1BQU0sV0FBVyxPQUFPLFFBQUEsQ0FBUztLQUNqQyxJQUFJLFlBQVksS0FBSyxHQUFHO01BQ3ZCLFFBQVE7T0FDUCxPQUFPO09BQ1AsTUFBTTtNQUNQO01BQ0EsT0FBTztLQUNSO0tBQ0E7SUFDRDtHQUNEO0dBQ0EsS0FBSyxPQUFPLFVBQVUsS0FBSyxHQUFHO0lBQzdCLE9BQU8sS0FBSztJQUNaO0dBQ0Q7R0FDQSxPQUFPLFVBQVUsS0FBSyxHQUFHO0lBQ3hCLE9BQU8sTUFBTTtJQUNiLFFBQVEsTUFBTTtJQUNkLElBQUksU0FBUyxLQUFLLEdBQUc7S0FDcEIsT0FBTyxLQUFLO0tBQ1osU0FBUztJQUNWO0dBQ0Q7R0FDQTtFQUNELFNBQVM7Q0FDVjtDQUNBLFNBQVMsV0FBVyxNQUFNLEtBQUs7RUFDOUIsSUFBSTtFQUNKLElBQUksYUFBYTtFQUNqQixJQUFJLFFBQVE7RUFDWixLQUFLLEdBQUc7R0FDUCxNQUFNLE1BQU0sS0FBSztHQUNqQixNQUFNLFFBQVEsSUFBSTtHQUNsQixJQUFJLElBQUksUUFBUSxJQUFJLFFBQVE7UUFDdkIsS0FBSyxRQUFTLFFBQWMsSUFDNUI7UUFBQSxPQUFPLEdBQUcsR0FBRztLQUNoQixNQUFNLE9BQU8sSUFBSTtLQUNqQixJQUFJLEtBQUssWUFBWSxLQUFLLEdBQUcsaUJBQWlCLElBQUk7S0FDbEQsUUFBUTtJQUNUO1VBQ00sS0FBSyxRQUFTLFFBQWMsSUFBUztJQUMzQyxJQUFJLEtBQUssWUFBWSxLQUFLLEtBQUssS0FBSyxZQUFZLEtBQUssR0FBRyxRQUFRO0tBQy9ELE9BQU87S0FDUCxNQUFNO0lBQ1A7SUFDQSxPQUFPLElBQUk7SUFDWCxNQUFNO0lBQ04sRUFBRTtJQUNGO0dBQ0Q7R0FDQSxJQUFJLENBQUMsT0FBTztJQUNYLE1BQU0sVUFBVSxLQUFLO0lBQ3JCLElBQUksWUFBWSxLQUFLLEdBQUc7S0FDdkIsT0FBTztLQUNQO0lBQ0Q7R0FDRDtHQUNBLE9BQU8sY0FBYztJQUNwQixNQUFNLFdBQVcsSUFBSTtJQUNyQixNQUFNLGtCQUFrQixTQUFTLFlBQVksS0FBSztJQUNsRCxJQUFJLGlCQUFpQjtLQUNwQixPQUFPLE1BQU07S0FDYixRQUFRLE1BQU07SUFDZixPQUFPLE9BQU87SUFDZCxJQUFJLE9BQU87S0FDVixJQUFJLE9BQU8sR0FBRyxHQUFHO01BQ2hCLElBQUksaUJBQWlCLGlCQUFpQixRQUFRO01BQzlDLE1BQU0sS0FBSztNQUNYO0tBQ0Q7S0FDQSxRQUFRO0lBQ1QsT0FBTyxJQUFJLFNBQVM7SUFDcEIsTUFBTSxLQUFLO0lBQ1gsTUFBTSxVQUFVLEtBQUs7SUFDckIsSUFBSSxZQUFZLEtBQUssR0FBRztLQUN2QixPQUFPO0tBQ1AsU0FBUztJQUNWO0dBQ0Q7R0FDQSxPQUFPO0VBQ1IsU0FBUztDQUNWO0NBQ0EsU0FBUyxpQkFBaUIsTUFBTTtFQUMvQixHQUFHO0dBQ0YsTUFBTSxNQUFNLEtBQUs7R0FDakIsTUFBTSxRQUFRLElBQUk7R0FDbEIsS0FBSyxRQUFTLFFBQWMsSUFBSTtJQUMvQixJQUFJLFFBQVEsUUFBUTtJQUNwQixLQUFLLFFBQVMsT0FBWSxHQUFHLE9BQU8sR0FBRztHQUN4QztFQUNELFVBQVUsT0FBTyxLQUFLLGFBQWEsS0FBSztDQUN6QztDQUNBLFNBQVMsWUFBWSxXQUFXLEtBQUs7RUFDcEMsSUFBSSxPQUFPLElBQUk7RUFDZixPQUFPLFNBQVMsS0FBSyxHQUFHO0dBQ3ZCLElBQUksU0FBUyxXQUFXLE9BQU87R0FDL0IsT0FBTyxLQUFLO0VBQ2I7RUFDQSxPQUFPO0NBQ1I7QUFDRDs7QUM3S0EsU0FBUyxXQUFXLGFBQWEsY0FBYyxtQkFBbUI7Q0FDakUsTUFBTSxhQUFhLE9BQU8sZ0JBQWdCO0NBQzFDLE1BQU0sT0FBTyxhQUFhLGNBQWMsS0FBSztDQUM3QyxPQUFPO0VBQ04sT0FBTyxhQUFhLFlBQVksT0FBTyxZQUFBLEVBQWMsS0FBSyxJQUFJO0VBQzlELFFBQVEsYUFBYSxZQUFZLFFBQVEsYUFBQSxFQUFlLEtBQUssSUFBSTtFQUNqRSxXQUFXLGFBQWEsWUFBWSxXQUFXLGtCQUFBLEVBQW9CLEtBQUssSUFBSTtDQUM3RTtBQUNEO0FBQ0EsSUFBTSxnQkFBZ0IsQ0FBQztBQUN2QixJQUFJLFFBQVE7QUFDWixJQUFNLEVBQUUsTUFBTSxRQUFRLFdBQVcsWUFBWSxxQkFBcUMscUNBQXFCO0NBQ3RHLE9BQU8sTUFBTTtFQUNaLE9BQU8sS0FBSyxRQUFRO0NBQ3JCO0NBQ0EsT0FBTyxRQUFRO0VBQ2QsY0FBYyx5QkFBeUI7RUFDdkMsT0FBTyxTQUFTO0NBQ2pCO0NBQ0EsVUFBVSxNQUFNO0VBQ2YsSUFBSSxLQUFLLGFBQWEsS0FBSyxHQUFHO0dBQzdCLEtBQUssV0FBVyxLQUFLO0dBQ3JCLEtBQUssUUFBUTtHQUNiLFVBQVUsSUFBSTtFQUNmO0NBQ0Q7QUFDRCxDQUFDO0FBQ0QsSUFBSSxjQUFjO0FBQ2xCLElBQUksc0JBQXNCO0FBQzFCLElBQUk7QUFDSixJQUFJLGFBQWE7QUFDakIsU0FBUyxNQUFNLElBQUk7Q0FDbEIsSUFBSTtFQUNILEVBQUU7RUFDRixHQUFHO0NBQ0osVUFBVTtFQUNULElBQUksQ0FBQyxFQUFFLFlBQVksTUFBTTtDQUMxQjtBQUNEO0FBQ0EsU0FBUyxVQUFVLEtBQUs7Q0FDdkIsTUFBTSxXQUFXLElBQUk7Q0FDckIsSUFBSSxNQUFNLGFBQWEsS0FBSyxJQUFJLFNBQVMsVUFBVSxJQUFJO0NBQ3ZELE9BQU8sUUFBUSxLQUFLLEdBQUcsTUFBTSxPQUFPLEtBQUssR0FBRztBQUM3QztBQUNBLFNBQVMsUUFBUTtDQUNoQixJQUFJLGFBQWEsR0FBRztDQUNwQixPQUFPLGNBQWMscUJBQXFCO0VBQ3pDLE1BQU0sU0FBUyxjQUFjO0VBQzdCLGNBQWMsaUJBQWlCLEtBQUs7RUFDcEMsT0FBTyxPQUFPO0NBQ2Y7Q0FDQSxjQUFjO0NBQ2Qsc0JBQXNCO0FBQ3ZCO0FBb0NBLFNBQVMsV0FBVyxXQUFXLFNBQVM7Q0FDdkMsTUFBTSxhQUFhLE9BQU8sY0FBYztDQUN4QyxNQUFNLFNBQVM7Q0FDZixNQUFNLE9BQU87RUFDWixXQUFXLGFBQWEsS0FBSyxJQUFJO0VBQ2pDLE1BQU0sS0FBSztFQUNYLFVBQVUsS0FBSztFQUNmLE1BQU0sS0FBSztFQUNYLFVBQVUsS0FBSztFQUNmLE9BQU8sYUFBYSxJQUFJO0VBQ3hCLE1BQU07R0FDTCxJQUFJLGNBQWMsS0FBSyxHQUFHLEtBQUssTUFBTSxXQUFXLEtBQUs7R0FDckQsT0FBTyxLQUFLO0VBQ2I7RUFDQSxVQUFVLGNBQWM7R0FDdkIsTUFBTSxNQUFNLFdBQVcsWUFBWTtHQUNuQyxNQUFNLFdBQVcsRUFBRSxTQUFTLE1BQU07R0FDbEMsTUFBTSxJQUFJLGFBQWE7SUFDdEIsS0FBSyxJQUFJO0lBQ1QsSUFBSSxDQUFDLFNBQVMsU0FBUyxTQUFTLFVBQVU7U0FDckM7S0FDSixZQUFZLEtBQUs7S0FDakIsSUFBSSxPQUFPLEtBQUssU0FBUztJQUMxQjtHQUNELENBQUM7R0FDRCxPQUFPLEVBQUUsbUJBQW1CO0lBQzNCLEVBQUUsS0FBSztHQUNSLEVBQUU7RUFDSDtFQUNBLFFBQVEsVUFBVTtHQUNqQixNQUFNLFVBQVU7R0FDaEIsTUFBTSxVQUFVLFNBQVMsV0FBVyxPQUFPO0dBQzNDLElBQUksWUFBWTtJQUNmLFlBQVk7SUFDWixFQUFFO0lBQ0YsS0FBSyxXQUFXLEtBQUs7R0FDdEIsT0FBTyxJQUFJLGFBQWEsS0FBSyxHQUFHLE9BQU87R0FDdkMsSUFBSSxZQUFZLEtBQUssUUFBUTtHQUM3QixJQUFJO0lBQ0gsTUFBTSxXQUFXLEtBQUs7SUFDdEIsTUFBTSxXQUFXLE9BQU8sYUFBYSxhQUFhLFNBQVMsUUFBUSxJQUFJLGFBQWEsS0FBSyxLQUFLLGFBQWEsT0FBTyxRQUFRLElBQUk7SUFDOUgsSUFBSSxhQUFhLEtBQUssS0FBSyxDQUFDLFFBQVEsVUFBVSxRQUFRLEdBQUc7S0FDeEQsS0FBSyxZQUFZO0tBQ2pCLE9BQU87SUFDUjtJQUNBLE9BQU87R0FDUixVQUFVO0lBQ1QsWUFBWTtJQUNaLElBQUksWUFBWSxLQUFLLFNBQVM7SUFDOUIsVUFBVSxJQUFJO0dBQ2Y7RUFDRDtDQUNEO0NBQ0EsSUFBSSxZQUFZO0VBQ2YsS0FBSyxRQUFRO0VBQ2IsS0FBSyxNQUFNLFdBQVc7R0FDckIsTUFBTSxRQUFRLEtBQUs7R0FDbkIsSUFBSSxRQUFRLE1BQU0sUUFBUSxNQUFNLFdBQVcsS0FBSyxNQUFNLElBQUksR0FDckQ7UUFBQSxLQUFLLFFBQVEsR0FBRztLQUNuQixNQUFNLE9BQU8sS0FBSztLQUNsQixJQUFJLFNBQVMsS0FBSyxHQUFHLGlCQUFpQixJQUFJO0lBQzNDO1VBQ00sSUFBSSxRQUFRLElBQUksS0FBSyxRQUFRLFFBQVE7R0FDNUMsSUFBSSxjQUFjLEtBQUssR0FBRyxLQUFLLE1BQU0sV0FBVyxLQUFLO0dBQ3JELE9BQU8sS0FBSztFQUNiO0NBQ0QsT0FBTyxLQUFLLE1BQU0sU0FBUyxXQUFXO0VBQ3JDLElBQUksS0FBSyxRQUFRLFNBQVMsR0FBRztHQUM1QixNQUFNLE9BQU8sS0FBSztHQUNsQixJQUFJLFNBQVMsS0FBSyxHQUFHO0lBQ3BCLFVBQVUsSUFBSTtJQUNkLGlCQUFpQixJQUFJO0lBQ3JCLE1BQU07R0FDUDtFQUNEO0NBQ0Q7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLE9BQU8sSUFBSTtDQUNuQixNQUFNLFlBQVk7RUFDakIsTUFBTSxVQUFVO0VBQ2hCLFlBQVk7RUFDWixFQUFFO0VBQ0YsVUFBVSxXQUFXLEtBQUs7RUFDMUIsVUFBVSxRQUFRO0VBQ2xCLElBQUk7R0FDSCxPQUFPLEdBQUc7RUFDWCxVQUFVO0dBQ1QsWUFBWTtHQUNaLFVBQVUsU0FBUztHQUNuQixVQUFVLFNBQVM7RUFDcEI7Q0FDRDtDQUNBLE1BQU0sWUFBWTtFQUNqQixNQUFNLEtBQUs7RUFDWCxVQUFVLEtBQUs7RUFDZixNQUFNLEtBQUs7RUFDWCxVQUFVLEtBQUs7RUFDZixPQUFPO0VBQ1AsU0FBUztHQUNSLE1BQU0sUUFBUSxLQUFLO0dBQ25CLElBQUksUUFBUSxNQUFNLFFBQVEsTUFBTSxXQUFXLEtBQUssTUFBTSxJQUFJLEdBQUcsSUFBSTtRQUM1RCxLQUFLLFFBQVE7RUFDbkI7RUFDQSxPQUFPO0dBQ04sS0FBSyxRQUFRO0dBQ2IsS0FBSyxXQUFXLEtBQUs7R0FDckIsVUFBVSxJQUFJO0VBQ2Y7Q0FDRDtDQUNBLElBQUk7Q0FDSixPQUFPO0FBQ1I7OztBQ3hNQSxTQUFTLGVBQWUsR0FBRyxHQUFHO0NBQzdCLE9BQU8sTUFBTTtBQUNkOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQkEsU0FBUyxZQUFZLFFBQVEsWUFBWSxNQUFNLEdBQUcsU0FBUztDQUMxRCxNQUFNLFVBQVUsU0FBUyxXQUFXO0NBQ3BDLE1BQU0sYUFBQSxHQUFZQyxhQUFBQSxZQUFBQSxFQUFhLHNCQUFzQjtFQUNwRCxNQUFNLEVBQUUsZ0JBQWdCLE9BQU8sVUFBVSxpQkFBaUI7RUFDMUQsT0FBTztDQUNSLEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FDWCxNQUFNLGVBQUEsR0FBY0EsYUFBQUEsWUFBQUEsT0FBa0IsT0FBTyxJQUFJLEdBQUcsQ0FBQyxNQUFNLENBQUM7Q0FDNUQsUUFBQSxHQUFPQyxxQkFBQUEsaUNBQUFBLENBQWlDLFdBQVcsYUFBYSxhQUFhLFVBQVUsT0FBTztBQUMvRjs7QUMzQkEsSUFBSSxhQUFhLENBQUM7QUFDbEIsU0FBUyxxQkFBcUIsTUFBTSxRQUFRO0NBQzNDLE1BQU0saUJBQUEsYUFBeUIsT0FBTztDQUN0QyxRQUFRLFVBQVU7RUFDakIsTUFBTSxXQUFXLE1BQU0sU0FBUyxLQUFLLE9BQU8sS0FBSyxJQUFJO0VBQ3JELElBQUksTUFBTSxxQkFBcUIsT0FBTyxRQUFRLDBCQUEwQixPQUFPLGVBQWUsVUFBVSxpQkFBaUIsZUFBZSxTQUFTLFFBQVE7RUFDekosT0FBTztDQUNSO0FBQ0Q7Ozs7O0FBS0EsU0FBUyxTQUFTLE1BQU07Q0FDdkIsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxpQkFBQSxhQUF5QixXQUFXLEtBQUssT0FBTyxvQkFBb0IsWUFBWTtDQUN0RixNQUFNLFVBQVUsS0FBSyxRQUFRO0NBQzdCLE1BQU0sYUFBYSxPQUFPLE9BQU8sY0FBYyxPQUFPO0NBQ3RELElBQWdCLE9BQU8sVUFBVTtFQUNoQyxNQUFNLFFBQVEsV0FBVyxJQUFJO0VBQzdCLElBQUksQ0FBQyxPQUFPO0dBQ1gsSUFBSSxLQUFLLGVBQWUsTUFDb0IsTUFBTSxJQUFJLE1BQU0sb0NBQW9DLEtBQUssT0FBTyx5QkFBeUIsS0FBSyxLQUFLLEtBQUssb0JBQW9CO0dBR3hLO0VBQ0Q7RUFDQSxPQUFPLEtBQUssU0FBUyxLQUFLLE9BQU8sS0FBSyxJQUFJO0NBQzNDO0NBQ0EsTUFBTSxXQUFXLHFCQUFxQixNQUFNLE1BQU07Q0FDbEQsTUFBTSxpQkFBaUIsWUFBWSxhQUFhLFVBQVUsUUFBUSxTQUFTLEtBQUssSUFBSSxVQUFVO0NBQzlGLElBQUksbUJBQW1CLFlBQVksT0FBTztDQUMxQyxJQUFJLEtBQUssZUFBZSxNQUNvQixNQUFNLElBQUksTUFBTSxvQ0FBb0MsS0FBSyxPQUFPLHlCQUF5QixLQUFLLEtBQUssS0FBSyxvQkFBb0I7QUFHeks7Ozs7Ozs7Ozs7Ozs7QUMvQkEsU0FBUyxjQUFjLE1BQU07Q0FDNUIsT0FBTyxTQUFTO0VBQ2YsTUFBTSxLQUFLO0VBQ1gsUUFBUSxLQUFLO0VBQ2IsbUJBQW1CLEtBQUs7RUFDeEIsU0FBUyxVQUFVO0dBQ2xCLE9BQU8sS0FBSyxTQUFTLEtBQUssT0FBTyxNQUFNLFVBQVUsSUFBSSxNQUFNO0VBQzVEO0NBQ0QsQ0FBQztBQUNGOzs7Ozs7Ozs7Ozs7O0FDVEEsU0FBUyxjQUFjLE1BQU07Q0FDNUIsTUFBTSxFQUFFLFFBQVEsR0FBRyxTQUFTO0NBQzVCLE9BQU8sU0FBUztFQUNmLEdBQUc7RUFDSCxTQUFTLFVBQVU7R0FDbEIsT0FBTyxTQUFTLE9BQU8sTUFBTSxVQUFVLElBQUksTUFBTTtFQUNsRDtDQUNELENBQUM7QUFDRjs7Ozs7Ozs7Ozs7Ozs7QUNQQSxTQUFTLFVBQVUsTUFBTTtDQUN4QixPQUFPLFNBQVM7RUFDZixNQUFNLEtBQUs7RUFDWCxhQUFhLEtBQUs7RUFDbEIsbUJBQW1CLEtBQUs7RUFDeEIsUUFBUSxLQUFLO0VBQ2IsU0FBUyxVQUFVO0dBQ2xCLE1BQU0sU0FBUyxLQUFLLFdBQVcsUUFBUSxNQUFNLFNBQVMsTUFBTTtHQUM1RCxPQUFPLEtBQUssU0FBUyxLQUFLLE9BQU8sTUFBTSxJQUFJO0VBQzVDO0NBQ0QsQ0FBQztBQUNGOzs7Ozs7Ozs7Ozs7OztBQ1hBLFNBQVMsVUFBVSxNQUFNO0NBQ3hCLE9BQU8sU0FBUztFQUNmLE1BQU0sS0FBSztFQUNYLFFBQVEsS0FBSztFQUNiLGFBQWEsS0FBSztFQUNsQixtQkFBbUIsS0FBSztFQUN4QixTQUFTLFVBQVU7R0FDbEIsT0FBTyxLQUFLLFNBQVMsS0FBSyxPQUFPLE1BQU0sTUFBTSxJQUFJLE1BQU07RUFDeEQ7Q0FDRCxDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7QUNMQSxTQUFTLFlBQVksY0FBYztDQUNsQyxNQUFNLFNBQVMsVUFBVTtDQUN6QixPQUFBLGFBQWUsYUFBYSxZQUFZO0VBQ3ZDLE9BQU8sT0FBTyxTQUFTO0dBQ3RCLEdBQUc7R0FDSCxNQUFNLFFBQVEsUUFBUSxjQUFjO0VBQ3JDLENBQUM7Q0FDRixHQUFHLENBQUMsY0FBYyxNQUFNLE1BQU0sQ0FBQztBQUNoQzs7Ozs7Ozs7OztBQVVBLFNBQVMsU0FBUyxPQUFPO0NBQ3hCLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sbUJBQUEsYUFBMkIsT0FBTyxJQUFJO0NBQzVDLHNCQUFzQjtFQUNyQixJQUFJLGlCQUFpQixZQUFZLE9BQU87R0FDdkMsU0FBUyxLQUFLO0dBQ2QsaUJBQWlCLFVBQVU7RUFDNUI7Q0FDRCxHQUFHO0VBQ0Y7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELE9BQU87QUFDUjs7QUNsREEsU0FBUyxnQkFBZ0IsTUFBTTtDQUM5QixPQUFPLFNBQVM7RUFDZixHQUFHO0VBQ0gsU0FBUyxVQUFVLEtBQUssU0FBUyxLQUFLLE9BQU8sTUFBTSxPQUFPLElBQUksTUFBTTtDQUNyRSxDQUFDO0FBQ0Y7O0FDQ0EsU0FBUyxnQkFBZ0IsR0FBRyxRQUFRO0NBQ25DLE1BQU0sTUFBQSxhQUFjLE9BQU8sTUFBTTtDQUNqQyxNQUFNLFNBQVMsSUFBSTtDQUNuQixPQUFPLFNBQVMsT0FBTyxVQUFVO0VBQ2hDLElBQUksQ0FBQyxVQUFVLE9BQU8sUUFBUSxPQUFPLE9BQU8sSUFBSSxHQUFHLE9BQU8sU0FBUztDQUNwRSxDQUFDO0NBQ0QsT0FBTyxJQUFJO0FBQ1o7QUFDQSxTQUFTLFlBQVksUUFBUSxTQUFTO0NBQ3JDLE9BQU8sYUFBYSxPQUFPLENBQUMsQ0FBQyxPQUFPLFFBQVE7RUFDM0MsUUFBUSxLQUFLLEdBQUc7RUFDaEIsUUFBUSxLQUFLLGNBQWM7Q0FDNUIsQ0FBQztBQUNGO0FBQ0EsU0FBUyxvQkFBb0IsSUFBSSxtQkFBbUI7Q0FDbkQsTUFBTSxTQUFTLE9BQU8sT0FBTyxZQUFZLGFBQWEsRUFBRTtDQUN4RCxJQUFJLENBQUMsUUFBUTtDQUNiLElBQUksQ0FBQyxrQkFBa0IsSUFBSSxNQUFNLEdBQUc7RUFDUSxRQUFRLEtBQUsseUNBQXlDLElBQUk7RUFDckcsT0FBTztDQUNSO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxnQkFBZ0IsVUFBVSxNQUFNLGVBQWUsVUFBVTtDQUNqRSxNQUFNLGNBQWMsb0JBQW9CLFNBQVMsVUFBVSxRQUFRO0NBQ25FLE1BQU0sV0FBVyxvQkFBb0IsS0FBSyxVQUFVLFFBQVE7Q0FDNUQsSUFBSSxlQUFlLFFBQVEsZ0JBQWdCLFdBQVcsRUFBRSxZQUFZLFdBQVcsUUFBUSxNQUFNLFlBQVksV0FBVyxTQUFTLFVBQVUsWUFBWSxTQUFTLFlBQVksT0FBTyxPQUFPO0NBQ3RMLElBQUksZUFBZSxpQkFBaUIsTUFDL0I7TUFBQSxDQUFDLFVBQVUsU0FBUyxRQUFRLEtBQUssUUFBUSxDQUFDLGVBQWUsT0FBTyxlQUFlLGlCQUFpQixHQUFHLE9BQU87Q0FBQTtDQUUvRyxPQUFPLENBQUMsZUFBZSxlQUFlLFNBQVMsU0FBUyxLQUFLO0FBQzlEO0FBQ0EsU0FBUyxhQUFhLFNBQVMsY0FBYyxNQUFNO0NBQ2xELE1BQU0sU0FBUyxVQUFVO0NBQ3pCLElBQWdCLE9BQU8sVUFBVSxPQUFPLG1CQUFtQixRQUFRLFNBQVMsY0FBYyxJQUFJO0NBQzlGLE1BQU0sV0FBQSxhQUFtQixPQUFPLElBQUk7Q0FDcEMsTUFBTSxZQUFBLGFBQW9CLGFBQWEsWUFBWTtFQUNsRCxTQUFTLFVBQVU7RUFDbkIsSUFBSSxPQUFPLGlCQUFpQixZQUFZLE9BQU8sYUFBYSxPQUFPO0VBQ25FLElBQUksY0FBYyxhQUFhLFVBQVU7Q0FDMUMsR0FBRyxDQUFDLFlBQVksQ0FBQztDQUNqQixNQUFNLEVBQUUsZUFBZSxJQUFJLFNBQVMsYUFBYSxjQUFjLGtCQUFrQixVQUFVLFFBQVEsU0FBUyxRQUFRLFNBQVMsY0FBYyxjQUFjLGlCQUFpQjtDQUMxSyxNQUFNLENBQUMsY0FBYyxjQUFjLHVCQUF1QixnQkFBZ0IsUUFBUSxRQUFRLFFBQVEsUUFBUSxhQUFhO0NBQ3ZILE1BQU0sVUFBQSxhQUFrQixXQUFXLFlBQVk7Q0FDL0MsTUFBTSxRQUFRLENBQUMsT0FBTyxPQUFPLGdCQUFnQixDQUFDLEVBQUEsQ0FBRyxhQUFhLGdCQUFnQixRQUFRLE9BQU87Q0FDN0YsTUFBTSxDQUFDLE1BQU0sY0FBYyxxQkFBQSxhQUE2QixjQUFjO0VBQ3JFLE1BQU0scUJBQXFCLG9CQUFvQixJQUFJLE9BQU8saUJBQWlCO0VBQzNFLElBQUksdUJBQXVCLEtBQUssR0FBRztHQUNsQyxNQUFNLFFBQVEsQ0FBQyxzQkFBc0IsS0FBSyxDQUFDO0dBQzNDLE9BQU8sQ0FBQyxlQUFlLEtBQUs7RUFDN0I7RUFDQSxNQUFNLE9BQU8sRUFBRSxHQUFHLFFBQVE7RUFDMUIsSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJO0VBQ0osTUFBTSxxQkFBcUI7R0FDMUIsTUFBTSxXQUFXLE1BQU0sRUFBRSxDQUFDO0dBQzFCLElBQUksYUFBYSxRQUFRO0lBQ3hCLEtBQUssZ0JBQWdCO0lBQ3JCLE1BQU0sT0FBTyxPQUFPLGNBQWMsSUFBSTtJQUN0QyxNQUFNLE9BQU8sY0FBYyxNQUFNLFFBQVEsUUFBUTtJQUNqRCxNQUFNLFdBQVcsWUFBWSxRQUFRLENBQUMsYUFBYSxJQUFJLElBQUksZ0JBQWdCLFVBQVUsTUFBTSxxQkFBcUIsT0FBTyxRQUFRLElBQUksS0FBSztJQUN4SSxJQUFJLENBQUMsU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLE9BQU8sVUFBVSxRQUFRLENBQUMsTUFBTSxRQUFRO0lBQ2pGLFNBQVM7R0FDVjtHQUNBLE9BQU87RUFDUjtFQUNBLE9BQU87R0FDTjtHQUNBO0dBQ0EscUJBQXFCLHNCQUFzQjtJQUMxQyxNQUFNLFFBQVEsYUFBYTtJQUMzQixPQUFPLE1BQU0sS0FBSyxtQkFBbUIsQ0FBQyxNQUFNLElBQUksS0FBSyxJQUFJO0dBQzFEO0VBQ0Q7Q0FDRCxHQUFHO0VBQ0Y7RUFDQTtFQUNBLFFBQVE7RUFDUixRQUFRO0VBQ1IsUUFBUTtFQUNSO0VBQ0E7RUFDQTtFQUNBLFFBQVE7RUFDUixRQUFRO0VBQ1IsUUFBUTtFQUNSO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsTUFBTSxDQUFDLE1BQU0sWUFBQSxhQUFvQixxQkFBcUIsTUFBTSxJQUFJLGNBQWMscUJBQXFCLFlBQVk7Q0FDL0csTUFBTSxlQUFlLGFBQWEsS0FBSyxLQUFLO0NBQzVDLE1BQU0sZUFBZSxZQUFZLFNBQVMsS0FBSztDQUMvQyxNQUFNLG1CQUFBLGFBQTJCLE9BQU8sS0FBSztDQUM3QyxNQUFNLFVBQVUsUUFBUSxrQkFBa0IsZ0JBQWdCLGVBQWUsUUFBUSxlQUFlLE9BQU8sUUFBUTtDQUMvRyxNQUFNLGVBQWUsb0JBQW9CLE9BQU8sUUFBUSx1QkFBdUI7Q0FDL0UsTUFBTSxpQkFBQSxhQUF5QixhQUFhLE1BQU07RUFDakQsTUFBTSxpQkFBaUIsR0FBRztFQUMxQixJQUFJLEVBQUUsa0JBQWtCLFlBQVksV0FBVztHQUM5QyxJQUFJLG1CQUFtQixPQUFPLGNBQWMsUUFBUTtHQUNwRDtFQUNEO0VBQ0EsSUFBSSxDQUFDLGNBQWM7R0FDbEIsWUFBWSxRQUFRLElBQUk7R0FDeEI7RUFDRDtFQUNBLFNBQVMsTUFBTSxpQkFBaUI7R0FDL0IsU0FBUyxJQUFJLEtBQUs7R0FDbEIsWUFBWSxRQUFRLElBQUk7RUFDekIsR0FBRyxZQUFZO0NBQ2hCLEdBQUc7RUFDRjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0NBQ0QsQ0FBQztDQUNELGFBQVEsZ0JBQWdCO0VBQ3ZCLElBQUksQ0FBQyxTQUFTO0VBQ2QsSUFBSSxZQUFZLFlBQVksQ0FBQyxpQkFBaUIsU0FBUztHQUN0RCxpQkFBaUIsVUFBVTtHQUMzQixZQUFZLFFBQVEsSUFBSTtFQUN6QjtFQUNBLElBQUksU0FBUztFQUNiLElBQUk7RUFDSixJQUFJLFlBQVksY0FBYyxTQUFTLFdBQVcsT0FBTyx5QkFBeUIsWUFBWTtHQUM3RixXQUFXLElBQUksc0JBQXNCLFlBQVk7SUFDaEQsSUFBSSxRQUFRLGVBQWUsUUFBUSxJQUFJLENBQUM7R0FDekMsR0FBRyxFQUFFLFlBQVksUUFBUSxDQUFDO0dBQzFCLFNBQVMsUUFBUSxTQUFTLE9BQU87RUFDbEM7RUFDQSxhQUFhO0dBQ1osU0FBUztHQUNULFVBQVUsV0FBVztHQUNyQixjQUFjLFFBQVE7RUFDdkI7Q0FDRCxHQUFHO0VBQ0Y7RUFDQTtFQUNBO0VBQ0E7RUFDQTtDQUNELENBQUM7Q0FDRCxNQUFNLFFBQVEsb0JBQW9CLFNBQVMsSUFBSTtDQUMvQyxNQUFNLE1BQU0sZUFBZSxZQUFZO0NBQ3ZDLElBQUksY0FBYztFQUNqQixNQUFNLE9BQU87RUFDYixPQUFPO0NBQ1I7Q0FDQSxNQUFNLGVBQWUsTUFBTTtFQUMxQixNQUFNLGtCQUFrQixVQUFVLEVBQUUsY0FBYyxhQUFhLFFBQVE7RUFDdkUsSUFBSSxDQUFDLGdCQUFnQixFQUFFLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsYUFBYSxDQUFDLEVBQUUscUJBQXFCLENBQUMsbUJBQW1CLG9CQUFvQixZQUFZLEVBQUUsV0FBVyxHQUFHO0dBQ3ZLLEVBQUUsZUFBZTtHQUNqQixjQUFjLFFBQVE7R0FDdEIsT0FBTyxTQUFTO0lBQ2YsR0FBRztJQUNILGVBQWUsS0FBSztHQUNyQixDQUFDO0VBQ0Y7Q0FDRDtDQUNBLE1BQU0seUJBQXlCO0VBQzlCLElBQUksWUFBWSxVQUFVLFlBQVksUUFBUSxJQUFJO0NBQ25EO0NBQ0EsTUFBTSxvQkFBb0I7RUFDekIsSUFBSSxZQUFZLFVBQVUsY0FBYyxRQUFRO0NBQ2pEO0NBQ0EsTUFBTSxVQUFVLGdCQUFnQixTQUFTLFdBQVc7Q0FDcEQsTUFBTSxTQUFTLGdCQUFnQixRQUFRLFdBQVc7Q0FDbEQsTUFBTSxVQUFVLGdCQUFnQixTQUFTLGNBQWM7Q0FDdkQsTUFBTSxlQUFlLGdCQUFnQixjQUFjLGNBQWM7Q0FDakUsTUFBTSxlQUFlLGdCQUFnQixjQUFjLFdBQVc7Q0FDOUQsTUFBTSxlQUFlLGdCQUFnQixjQUFjLGdCQUFnQjtDQUNuRSxPQUFPLGVBQWUsT0FBTyxTQUFTLFVBQVUsTUFBTSxjQUFjLElBQUk7QUFDekU7QUFDQSxJQUFJLHNCQUFzQixDQUFDO0FBQzNCLElBQUksdUJBQXVCLEVBQUUsV0FBVyxTQUFTO0FBQ2pELElBQUkscUNBQXFDLElBQUksSUFBSTtDQUNoRDtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNELENBQUM7QUFDRCxTQUFTLG9CQUFvQixTQUFTLE1BQU07Q0FDM0MsTUFBTSxRQUFRLENBQUM7Q0FDZixLQUFLLE1BQU0sT0FBTyxTQUFTO0VBQzFCLElBQUksbUJBQW1CLElBQUksR0FBRyxLQUFLLFFBQVEsVUFBVSxTQUFTLEtBQUssS0FBSyxRQUFRLGNBQWMsU0FBUyxLQUFLO0VBQzVHLE1BQU0sT0FBTyxRQUFRO0NBQ3RCO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxlQUFlLE9BQU8sU0FBUyxVQUFVLE1BQU0sY0FBYyxNQUFNO0NBQzNFLE1BQU0sRUFBRSxhQUFhLGVBQWUsV0FBVyxPQUFPLFdBQVc7Q0FDakUsTUFBTSxhQUFhLGlCQUFpQixXQUFXLGNBQWMsZUFBZSxDQUFDLENBQUMsTUFBTSxXQUFXLHVCQUF1QjtDQUN0SCxPQUFPLE9BQU8sT0FBTyxVQUFVO0NBQy9CLE1BQU0sT0FBTztDQUNiLElBQUksU0FBUyxLQUFLLE1BQU0sV0FBVztDQUNuQyxNQUFNLFNBQVM7Q0FDZixNQUFNLGFBQWEsV0FBVztDQUM5QixJQUFJLFNBQVMsWUFBWSxNQUFNLFFBQVEsU0FBUyxhQUFhO0VBQzVELEdBQUc7RUFDSCxHQUFHO0NBQ0osSUFBSSxTQUFTO0NBQ2IsTUFBTSxpQkFBaUIsV0FBVztDQUNsQyxJQUFJLGFBQWEsZ0JBQWdCLE1BQU0sWUFBWSxZQUFZLGlCQUFpQixHQUFHLFVBQVUsR0FBRyxtQkFBbUIsWUFBWTtDQUMvSCxJQUFJLGNBQWM7RUFDakIsTUFBTSxPQUFPO0VBQ2IsTUFBTSxtQkFBbUI7Q0FDMUI7Q0FDQSxJQUFJLFVBQVU7RUFDYixNQUFNLGlCQUFpQjtFQUN2QixNQUFNLGtCQUFrQjtDQUN6QjtDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsbUJBQW1CLFFBQVEsU0FBUyxjQUFjLE1BQU07Q0FDaEUsTUFBTSxFQUFFLElBQUksVUFBVSxrQkFBa0I7Q0FDeEMsTUFBTSxxQkFBcUIsb0JBQW9CLElBQUksT0FBTyxpQkFBaUI7Q0FDM0UsTUFBTSxPQUFPLHVCQUF1QixLQUFLLElBQUksT0FBTyxjQUFjLE9BQU8sSUFBSSxLQUFLO0NBQ2xGLE1BQU0sYUFBYSxPQUFPLGNBQWMsTUFBTSxRQUFRLFFBQVEsSUFBSSxzQkFBc0IsS0FBSztDQUM3RixNQUFNLGVBQWUsWUFBWSxDQUFDO0NBQ2xDLE1BQU0sZUFBZSx1QkFBdUIsY0FBYyxhQUFhLFVBQVUsSUFBSSxhQUFhLEtBQUs7Q0FDdkcsTUFBTSxRQUFRLG9CQUFvQixTQUFTLElBQUk7Q0FDL0MsTUFBTSxNQUFNO0NBQ1osSUFBSSxjQUFjO0VBQ2pCLE1BQU0sT0FBTztFQUNiLE9BQU87Q0FDUjtDQUNBLE9BQU8sZUFBZSxPQUFPLFNBQVMsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsZUFBZSxlQUFlLGdCQUFnQixPQUFPLE9BQU8sU0FBUyxJQUFJLEdBQUcsTUFBTSxlQUFlLE9BQU8sUUFBUSxHQUFHLFlBQVksY0FBYyxJQUFJO0FBQ2xPO0FBQ0EsSUFBSSxpQkFBaUIsUUFBUTtDQUM1QixhQUFhLElBQUksQ0FBQztDQUNsQixJQUFJLElBQUksS0FBSztBQUNkO0FBQ0EsSUFBSSxtQkFBbUIsT0FBTyxXQUFXO0NBQ3hDLElBQUksQ0FBQyxPQUFPLE9BQU87Q0FDbkIsUUFBUSxVQUFVLE1BQU0scUJBQXFCLE1BQU0sS0FBSyxHQUFHLE1BQU0sb0JBQW9CLE9BQU8sS0FBSztBQUNsRztBQUNBLFNBQVMsY0FBYyxNQUFNLFFBQVEsVUFBVTtDQUM5QyxJQUFJLFVBQVU7Q0FDZCxNQUFNLFdBQVcsS0FBSyxrQkFBa0I7Q0FDeEMsTUFBTSxPQUFPLFNBQVMsV0FBVyxTQUFTLGFBQWEsT0FBTyxRQUFRLFdBQVcsU0FBUyxVQUFVLEtBQUs7Q0FDekcsS0FBSyxTQUFTLFlBQVksU0FBUyxTQUFTLGVBQWUsb0JBQW9CLE1BQU0sT0FBTyxpQkFBaUIsR0FBRztFQUNwRSxRQUFRLEtBQUsseUNBQXlDLE1BQU07RUFDdkc7Q0FDRDtDQUNBLE9BQU87QUFDUjs7Ozs7Ozs7Ozs7OztBQWFBLFNBQVMsV0FBVyxNQUFNO0NBQ3pCLE9BQUEsYUFBZSxXQUFXLFNBQVMsWUFBWSxPQUFPLEtBQUs7RUFDMUQsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksTUFBTTtHQUNoQyxHQUFHO0dBQ0gsVUFBVTtHQUNWO0VBQ0QsQ0FBQztDQUNGLENBQUM7QUFDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQkEsSUFBSSxPQUFBLGFBQWUsS0FBQSxhQUFhLFlBQVksT0FBTyxRQUFRO0NBQzFELE1BQU0sT0FBTyxNQUFNLFlBQVk7Q0FDL0IsTUFBTSxZQUFZLGFBQWEsT0FBTyxLQUFLLElBQUk7Q0FDL0MsTUFBTSxXQUFXLE9BQU8sTUFBTSxhQUFhLGFBQWEsTUFBTSxTQUFTLEVBQUUsVUFBVSxVQUFVLG1CQUFtQixTQUFTLENBQUMsSUFBSSxNQUFNO0NBQ3BJLE9BQUEsYUFBZSxjQUFjLE1BQU0sV0FBVyxRQUFRO0FBQ3ZELENBQUMsR0FBRyxpQkFBaUI7QUFDckIsU0FBUyxrQkFBa0IsTUFBTSxNQUFNO0NBQ3RDLElBQUksWUFBWTtDQUNoQixLQUFLLE1BQU0sT0FBTyxNQUFNO0VBQ3ZCO0VBQ0EsSUFBSSxLQUFLLFNBQVMsS0FBSyxNQUFNO0VBQzdCLElBQUksQ0FBQyxtQkFBbUIsSUFBSSxHQUFHLEtBQUssQ0FBQyxVQUFVLEtBQUssTUFBTSxLQUFLLE1BQU0sT0FBTyxJQUFJLEdBQUcsT0FBTztDQUMzRjtDQUNBLEtBQUssTUFBTSxRQUFRLE1BQU07Q0FDekIsT0FBTyxjQUFjO0FBQ3RCOzs7Ozs7OztBQVFBLElBQUksZUFBZSxZQUFZO0NBQzlCLE9BQU87QUFDUjs7Ozs7Ozs7Ozs7QUN6VEEsU0FBUyxZQUFZLElBQUk7Q0FDeEIsT0FBTyxJQUFJLFNBQVMsRUFBRSxHQUFHLENBQUM7QUFDM0I7QUFDQSxJQUFJLFdBQVcsY0FBYyxhQUFhOzs7O0NBSXpDLFlBQVksRUFBRSxNQUFNO0VBQ25CLE1BQU0sRUFBRSxHQUFHLENBQUM7RUFDWixLQUFLLFlBQVksU0FBUztHQUN6QixPQUFPLFNBQVM7SUFDZixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxtQkFBbUIsU0FBUztHQUNoQyxPQUFPLGdCQUFnQjtJQUN0QixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxhQUFhLFNBQVM7R0FDMUIsT0FBTyxVQUFVO0lBQ2hCLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLGFBQWEsU0FBUztHQUMxQixPQUFPLFVBQVU7SUFDaEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssaUJBQWlCLFNBQVM7R0FDOUIsT0FBTyxjQUFjO0lBQ3BCLEdBQUc7SUFDSCxNQUFNLEtBQUs7SUFDWCxRQUFRO0dBQ1QsQ0FBQztFQUNGO0VBQ0EsS0FBSyxpQkFBaUIsU0FBUztHQUM5QixPQUFPLGNBQWM7SUFDcEIsR0FBRztJQUNILE1BQU0sS0FBSztJQUNYLFFBQVE7R0FDVCxDQUFDO0VBQ0Y7RUFDQSxLQUFLLG9CQUFvQjtHQUV4QixPQUFPLFlBQVksRUFBRSxNQUROLFVBQ1ksQ0FBQSxDQUFPLFdBQVcsS0FBSyxHQUFHLENBQUMsU0FBUyxDQUFDO0VBQ2pFO0VBQ0EsS0FBSyxZQUFZLFNBQVM7R0FDekIsT0FBTyxTQUFTO0lBQ2YsU0FBUyxLQUFLO0lBQ2QsR0FBRztHQUNKLENBQUM7RUFDRjtFQUNBLEtBQUssT0FBQSxhQUFhLFlBQVksT0FBTyxRQUFRO0dBQzVDLE1BQU0sV0FBVyxVQUFVLENBQUMsQ0FBQyxXQUFXLEtBQUssR0FBRyxDQUFDO0dBQ2pELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLE1BQU07SUFDaEM7SUFDQSxNQUFNO0lBQ04sR0FBRztHQUNKLENBQUM7RUFDRixDQUFDO0NBQ0Y7QUFDRDtBQUNBLElBQUksUUFBUSxjQUFjLFVBQVU7Ozs7Q0FJbkMsWUFBWSxTQUFTO0VBQ3BCLE1BQU0sT0FBTztFQUNiLEtBQUssWUFBWSxTQUFTO0dBQ3pCLE9BQU8sU0FBUztJQUNmLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLG1CQUFtQixTQUFTO0dBQ2hDLE9BQU8sZ0JBQWdCO0lBQ3RCLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLGFBQWEsU0FBUztHQUMxQixPQUFPLFVBQVU7SUFDaEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssYUFBYSxTQUFTO0dBQzFCLE9BQU8sVUFBVTtJQUNoQixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxpQkFBaUIsU0FBUztHQUM5QixPQUFPLGNBQWM7SUFDcEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssaUJBQWlCLFNBQVM7R0FDOUIsT0FBTyxjQUFjO0lBQ3BCLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLG9CQUFvQjtHQUN4QixPQUFPLFlBQVksRUFBRSxNQUFNLEtBQUssU0FBUyxDQUFDO0VBQzNDO0VBQ0EsS0FBSyxPQUFBLGFBQWEsWUFBWSxPQUFPLFFBQVE7R0FDNUMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksTUFBTTtJQUNoQztJQUNBLE1BQU0sS0FBSztJQUNYLEdBQUc7R0FDSixDQUFDO0VBQ0YsQ0FBQztDQUNGO0FBQ0Q7Ozs7Ozs7Ozs7OztBQVlBLFNBQVMsWUFBWSxTQUFTO0NBQzdCLE9BQU8sSUFBSSxNQUFNLE9BQU87QUFDekI7Ozs7Ozs7Ozs7QUFVQSxTQUFTLDZCQUE2QjtDQUNyQyxRQUFRLFlBQVk7RUFDbkIsT0FBTyxnQkFBZ0IsT0FBTztDQUMvQjtBQUNEOzs7O0FBSUEsSUFBSSx1QkFBdUI7QUFDM0IsSUFBSSxZQUFZLGNBQWMsY0FBYzs7OztDQUkzQyxZQUFZLFNBQVM7RUFDcEIsTUFBTSxPQUFPO0VBQ2IsS0FBSyxZQUFZLFNBQVM7R0FDekIsT0FBTyxTQUFTO0lBQ2YsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssbUJBQW1CLFNBQVM7R0FDaEMsT0FBTyxnQkFBZ0I7SUFDdEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssYUFBYSxTQUFTO0dBQzFCLE9BQU8sVUFBVTtJQUNoQixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxhQUFhLFNBQVM7R0FDMUIsT0FBTyxVQUFVO0lBQ2hCLEdBQUc7SUFDSCxNQUFNLEtBQUs7R0FDWixDQUFDO0VBQ0Y7RUFDQSxLQUFLLGlCQUFpQixTQUFTO0dBQzlCLE9BQU8sY0FBYztJQUNwQixHQUFHO0lBQ0gsTUFBTSxLQUFLO0dBQ1osQ0FBQztFQUNGO0VBQ0EsS0FBSyxpQkFBaUIsU0FBUztHQUM5QixPQUFPLGNBQWM7SUFDcEIsR0FBRztJQUNILE1BQU0sS0FBSztHQUNaLENBQUM7RUFDRjtFQUNBLEtBQUssb0JBQW9CO0dBQ3hCLE9BQU8sWUFBWSxFQUFFLE1BQU0sS0FBSyxTQUFTLENBQUM7RUFDM0M7RUFDQSxLQUFLLE9BQUEsYUFBYSxZQUFZLE9BQU8sUUFBUTtHQUM1QyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxNQUFNO0lBQ2hDO0lBQ0EsTUFBTSxLQUFLO0lBQ1gsR0FBRztHQUNKLENBQUM7RUFDRixDQUFDO0NBQ0Y7QUFDRDs7Ozs7Ozs7Ozs7QUFXQSxTQUFTLGdCQUFnQixTQUFTO0NBQ2pDLE9BQU8sSUFBSSxVQUFVLE9BQU87QUFDN0I7QUFDQSxTQUFTLGdCQUFnQixNQUFNO0NBQzlCLE9BQU87QUFDUjtBQUNBLElBQUksZ0JBQWdCLGNBQWMsTUFBTTtDQUN2QyxZQUFZLFNBQVM7RUFDcEIsTUFBTTtHQUNMLEdBQUc7R0FDSCxJQUFJO0VBQ0wsQ0FBQztDQUNGO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7QUN2T0EsU0FBUyxnQkFBZ0IsTUFBTTtDQUM5QixRQUFRLFlBQVk7RUFDbkIsTUFBTSxRQUFRLFlBQVksT0FBTztFQUNqQyxNQUFNLFNBQVM7RUFDZixPQUFPO0NBQ1I7QUFDRDs7Ozs7QUFLQSxJQUFJLFlBQVksTUFBTTtDQUNyQixZQUFZLE1BQU0sT0FBTztFQUN4QixLQUFLLE9BQU87RUFDWixLQUFLLGVBQWUsWUFBWTtHQUU5QixJQUFJLENBQUMsS0FBSyxRQUFRLFFBQVEsS0FBSywwSUFBMEk7R0FFMUssTUFBTSxRQUFRLFlBQVksT0FBTztHQUNqQyxNQUFNLFNBQVM7R0FDZixPQUFPO0VBQ1I7RUFDQSxLQUFLLFNBQVMsT0FBTztDQUN0QjtBQUNEOzs7OztBQUtBLFNBQVMsZ0JBQWdCLE9BQU87Q0FDWSxRQUFRLEtBQUssaU5BQWlOO0NBQ3pRLFFBQVEsYUFBYTtBQUN0QjtBQUNBLElBQUksWUFBWSxNQUFNO0NBQ3JCLFlBQVksTUFBTTtFQUNqQixLQUFLLFlBQVksU0FBUztHQUN6QixPQUFPLFNBQVM7SUFDZixHQUFHO0lBQ0gsTUFBTSxLQUFLLFFBQVE7R0FDcEIsQ0FBQztFQUNGO0VBQ0EsS0FBSyxtQkFBbUIsU0FBUztHQUNoQyxPQUFPLGdCQUFnQjtJQUN0QixHQUFHO0lBQ0gsTUFBTSxLQUFLLFFBQVE7R0FDcEIsQ0FBQztFQUNGO0VBQ0EsS0FBSyxhQUFhLFNBQVM7R0FDMUIsT0FBTyxVQUFVO0lBQ2hCLEdBQUc7SUFDSCxNQUFNLEtBQUssUUFBUTtHQUNwQixDQUFDO0VBQ0Y7RUFDQSxLQUFLLGFBQWEsU0FBUztHQUMxQixPQUFPLFVBQVU7SUFDaEIsR0FBRztJQUNILE1BQU0sS0FBSyxRQUFRO0dBQ3BCLENBQUM7RUFDRjtFQUNBLEtBQUssaUJBQWlCLFNBQVM7R0FDOUIsT0FBTyxjQUFjO0lBQ3BCLEdBQUc7SUFDSCxNQUFNLEtBQUssUUFBUTtHQUNwQixDQUFDO0VBQ0Y7RUFDQSxLQUFLLGlCQUFpQixTQUFTO0dBQzlCLE9BQU8sY0FBYztJQUNwQixHQUFHO0lBQ0gsTUFBTSxLQUFLLFFBQVE7R0FDcEIsQ0FBQztFQUNGO0VBQ0EsS0FBSyxvQkFBb0I7R0FFeEIsT0FBTyxZQUFZLEVBQUUsTUFETixVQUNZLENBQUEsQ0FBTyxXQUFXLEtBQUssUUFBUSxHQUFHLENBQUMsU0FBUyxDQUFDO0VBQ3pFO0VBQ0EsS0FBSyxVQUFVO0NBQ2hCO0FBQ0Q7Ozs7Ozs7Ozs7Ozs7QUFhQSxTQUFTLGdCQUFnQixJQUFJO0NBQzVCLFFBQVEsU0FBUztFQUNoQixPQUFPLElBQUksVUFBVTtHQUNwQjtHQUNBLEdBQUc7RUFDSixDQUFDO0NBQ0Y7QUFDRDs7Ozs7Ozs7Ozs7O0FBWUEsU0FBUyxvQkFBb0IsSUFBSTtDQUNoQyxJQUFJLE9BQU8sT0FBTyxVQUFVLE9BQU8sSUFBSSxVQUFVLEVBQUU7Q0FDbkQsUUFBUSxTQUFTLElBQUksVUFBVTtFQUM5QjtFQUNBLEdBQUc7Q0FDSixDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7O0FDMUhBLFNBQVMsbUJBQW1CLFVBQVUsWUFBWTtDQUNqRCxJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixNQUFNLGFBQWE7RUFDbEIsSUFBSSxDQUFDLGFBQWE7R0FDakIsUUFBUSxLQUFLO0dBQ2IsY0FBYyxTQUFTLENBQUMsQ0FBQyxNQUFNLFFBQVE7SUFDdEMsSUFBSSxFQUFjLE9BQU8sV0FBVyxjQUFjO0tBQ2pELGNBQWMsS0FBSztLQUNuQixTQUFTLFVBQVUsS0FBSztJQUN6QjtJQUNBLE9BQU8sSUFBSSxjQUFjO0dBQzFCLENBQUMsQ0FBQyxDQUFDLE9BQU8sUUFBUTtJQUNqQixjQUFjLEtBQUs7SUFDbkIsUUFBUTtHQUNULENBQUM7RUFDRjtFQUNBLE9BQU87Q0FDUjtDQUNBLE1BQU0sV0FBVyxTQUFTLEtBQUssT0FBTztFQUNyQyxJQUFJLE9BQU87R0FDVixJQUFJLHNCQUFzQixLQUFLLEtBQUssRUFBYyxPQUFPLFdBQVcsZ0JBQWdCLE9BQU8sbUJBQW1CLGFBQWE7SUFDMUgsTUFBTSxhQUFhLDBCQUEwQixNQUFNO0lBQ25ELElBQUksQ0FBQyxlQUFlLFFBQVEsVUFBVSxHQUFHO0tBQ3hDLGVBQWUsUUFBUSxZQUFZLEdBQUc7S0FDdEMsT0FBTyxTQUFTLE9BQU87S0FDdkIsTUFBTSxJQUFJLGNBQWMsQ0FBQyxDQUFDO0lBQzNCO0dBQ0Q7R0FDQSxNQUFNO0VBQ1A7RUFDQSxJQUFJLENBQUMsTUFBTTtHQUNWLElBQUksVUFBVSxTQUFTLEtBQUssQ0FBQztRQUN4QixNQUFNLEtBQUs7RUFDakI7RUFDQSxPQUFBLGFBQWUsY0FBYyxNQUFNLEtBQUs7Q0FDekM7Q0FDQSxTQUFTLFVBQVU7Q0FDbkIsT0FBTztBQUNSOztBQzlDQSxTQUFTLGNBQWMsT0FBTztDQUM3QixNQUFNLFNBQVMsVUFBVTtDQUN6QixJQUFnQixPQUFPLFVBQVU7RUFDaEMsTUFBTSxXQUFXLGFBQWEsT0FBTyxPQUFPLFNBQVMsSUFBSSxDQUFDLENBQUMsU0FBUyxHQUFHLE9BQU8sT0FBTyxPQUFPLElBQUk7RUFDaEcsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksZUFBZTtHQUN6QyxtQkFBbUI7R0FDbkIsVUFBVSxPQUFPLGNBQWM7SUFDOUIsSUFBSSxXQUFXLEtBQUssR0FBRyxNQUFNLFVBQVUsT0FBTyxTQUFTO1NBQ2xELE1BQU07R0FDWjtHQUNBLGlCQUFpQixFQUFFLFlBQVk7SUFDOUIsSUFBSSxXQUFXLEtBQUssR0FBRyxPQUFPLE1BQU0sV0FBVyxLQUFLO1NBQy9DLE1BQU07R0FDWjtHQUNBLFVBQVUsTUFBTTtFQUNqQixDQUFDO0NBQ0Y7Q0FDQSxNQUFNLFdBQVcsYUFBYSxZQUFZLE9BQU8sT0FBTyxXQUFXLGFBQWEsU0FBUyxRQUFRLEVBQUUsR0FBRyxZQUFZLE9BQU8sT0FBTyxNQUFNO0NBQ3RJLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLGVBQWU7RUFDekMsbUJBQW1CO0VBQ25CLFVBQVUsT0FBTyxjQUFjO0dBQzlCLElBQUksV0FBVyxLQUFLLEdBQUcsTUFBTSxVQUFVLE9BQU8sU0FBUztRQUNsRCxNQUFNO0VBQ1o7RUFDQSxpQkFBaUIsRUFBRSxZQUFZO0dBQzlCLElBQUksV0FBVyxLQUFLLEdBQUcsT0FBTyxNQUFNLFdBQVcsS0FBSztRQUMvQyxNQUFNO0VBQ1o7RUFDQSxVQUFVLE1BQU07Q0FDakIsQ0FBQztBQUNGO0FBQ0EsU0FBUyx3QkFBd0I7Q0FDaEMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksS0FBSyxFQUFFLFVBQVUsWUFBWSxDQUFDO0FBQzFEOzs7OztBQ2xDQSxTQUFTLFdBQVcsRUFBRSxZQUFZO0NBQ2pDLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLElBQUksQ0FBYyxPQUFPLFVBQVcsT0FBTztDQUMzQyxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVO0VBQ3BDLE9BQU8sT0FBTyxRQUFRLEtBQUs7RUFDM0IseUJBQXlCLEVBQUUsUUFBUSxXQUFXLG1DQUFtQztDQUNsRixDQUFDO0FBQ0Y7Ozs7Ozs7Ozs7QUNEQSxTQUFTLG9CQUFvQixRQUFRLE9BQU8sTUFBTTtDQUNqRCxJQUFJLENBQUMsTUFBTSxRQUFRLG1CQUFtQjtFQUNyQyxJQUFJLE9BQU8sUUFBUSwwQkFFbEIsT0FBK0MsK0JBQStCLGlCQUR0QyxHQUFBLG1CQUFBLElBQUEsQ0FBSSxPQUFPLFFBQVEsMEJBQTBCLEVBQUUsR0FBRyxLQUFLLENBQ2pCLEdBQWlCLG1CQUFtQjtFQUdsSCxJQUFJLENBQUMsTUFBTSxRQUFRLG1CQUFtQixRQUFRLEtBQUssa0VBQWtFLE1BQU0sR0FBRyxtUEFBbVA7RUFFbFgsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksdUJBQXVCLENBQUMsQ0FBQztDQUNyRDtDQUVBLE9BQStDLCtCQUErQixpQkFEdEMsR0FBQSxtQkFBQSxJQUFBLENBQUksTUFBTSxRQUFRLG1CQUFtQixFQUFFLEdBQUcsS0FBSyxDQUNULEdBQWlCLG1CQUFtQjtBQUNuSDs7QUN6QkEsU0FBUyxvQ0FBb0MsU0FBUztDQUNyRCxPQUFPO0FBQ1I7O0FDRUEsU0FBU0Msc0JBQW9CO0NBRTVCLE1BQU0sU0FBUyxvQ0FEQSxVQUNvQyxDQUFNO0NBQ3pELElBQUksQ0FBQyxRQUFRLE9BQU87Q0FDcEIsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksWUFBWSxFQUFFLFVBQVUsT0FBTyxDQUFDO0FBQzVEOztBQ0tBLFNBQVMsY0FBYyxRQUFRLE9BQU87Q0FDckMsTUFBTSxtQkFBbUIsT0FBTyxRQUFRLG9CQUFvQixPQUFPLFFBQVE7Q0FDM0UsSUFBSSxDQUFDLGtCQUFrQixPQUFPO0NBRTlCLE9BQStDLCtCQUErQixpQkFBQSxHQUR2Q0MsbUJBQUFBLElBQUFBLENBQUksa0JBQWtCLENBQUMsQ0FDNkIsR0FBRyxrQkFBa0I7QUFDakg7QUFDQSxJQUFJLDZCQUE2QixHQUFHLE1BQU0sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRTtBQUN0RSxJQUFJLHFCQUFxQixRQUFRLE9BQU8sUUFBUSxDQUFDLE1BQU0sVUFBVSxNQUFNLFFBQVEsa0JBQWtCLE1BQU0sUUFBUSxrQkFBa0IsUUFBUSxTQUFTLFFBQVEsZUFBZSxFQUFlLE9BQU8sWUFBYSxPQUFPO0FBQ25OLElBQUksUUFBQSxhQUFnQixLQUFLLFNBQVMsVUFBVSxFQUFFLFdBQVc7Q0FDeEQsTUFBTSxTQUFTLFVBQVU7Q0FDekIsSUFBZ0IsT0FBTyxVQUFVLE9BQU8sVUFBVSxRQUFRLE9BQU8sT0FBTyxRQUFRLElBQUksT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDO0NBRWxHLE9BQU8sVUFBVSxRQUFRLFlBRE4sT0FBTyxPQUFPLGNBQWMsT0FDVixDQUFVLENBQUM7QUFDakQsQ0FBQztBQUNELFNBQVMsVUFBVSxRQUFRLE9BQU87Q0FDakMsTUFBTSxRQUFRLE9BQU8sV0FBVyxNQUFNO0NBQ3RDLE1BQU0saUJBQWlCLGNBQWMsUUFBUSxLQUFLO0NBQ2xELE1BQU0sc0JBQXNCLE1BQU0sUUFBUSxrQkFBa0IsT0FBTyxRQUFRO0NBQzNFLE1BQU0sZUFBZSxNQUFNLFFBQVEsV0FBVyxPQUFPLFFBQVE7Q0FDN0QsTUFBTSx5QkFBeUIsTUFBTSxTQUFTLE1BQU0sUUFBUSxxQkFBcUIsT0FBTyxRQUFRLGVBQWUsUUFBUSxZQUFZLE1BQU0sUUFBUTtDQUNqSixNQUFNLGdCQUFnQixNQUFNLFFBQVEsU0FBUyxNQUFNLFFBQVE7Q0FDM0QsTUFBTSxpQkFBaUIsa0JBQWtCLFFBQVEsT0FBTyxNQUFNLEdBQUcsTUFBTSxNQUFNLFFBQVEsa0JBQWtCLG1CQUFtQixNQUFNLFFBQVEsZ0JBQWdCLFdBQVc7Q0FDbkssSUFBSSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxZQUFZLEVBQUUsTUFBTSxDQUFDO0NBQ3ZELElBQUksZUFBZSxVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxZQUFZO0VBQzVELFVBQVU7RUFDVixVQUFVO0NBQ1gsQ0FBQztDQUNELElBQUksd0JBQXdCLFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLGVBQWU7RUFDeEUsV0FBVyxVQUFVO0dBQ3BCLE1BQU0sWUFBWSxNQUFNO0dBQ3hCLElBQUksTUFBTSxZQUFZLE1BQU0sU0FBUyxNQUFNO0dBRTNDLE9BQStDLCtCQUR6QyxhQUEwQixjQUFjLHdCQUF3QixLQUNRLEdBQWlCLG1CQUFtQjtFQUNuSDtFQUNBLFVBQVU7Q0FDWCxDQUFDO0NBQ0QsSUFBSSxxQkFBcUIsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksZUFBZTtFQUNyRSxtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLFVBQVUsT0FBTyxjQUFjO0dBQzlCLElBQUksV0FBVyxLQUFLLEdBQUc7SUFDdEIsTUFBTSxZQUFZLE1BQU07SUFDeEIsTUFBTTtHQUNQO0dBQzJDLFFBQVEsS0FBSyxrQ0FBa0MsTUFBTSxJQUFJO0dBQ3BHLGVBQWUsT0FBTyxTQUFTO0VBQ2hDO0VBQ0EsVUFBVTtDQUNYLENBQUM7Q0FDRCxJQUFJLGdCQUFnQixVQUEwQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBQSxhQUFZLFVBQVU7RUFDbkUsVUFBVTtFQUNWLFVBQVU7Q0FDWCxDQUFDO0NBQ0QsTUFBTSxvQkFBaUMsT0FBTyxZQUFhLE1BQU0sYUFBYSxPQUFBLGNBQXNCLE9BQU8sUUFBUSxvQkFBb0MsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUlDLHFCQUFtQixDQUFDLENBQUMsSUFBSTtDQUNwTCxNQUFNLGlCQUFpQixNQUFNLFVBQVUsTUFBTSxRQUFRO0NBQ3JELE9BQU8saUJBQWlDLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLGFBQWEsVUFBVTtFQUNsRSxPQUFPLE1BQU07RUFDYixVQUEwQixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBSyxnQkFBZ0IsRUFBRSxVQUFVLENBQUMsU0FBUyxpQkFBaUIsRUFBRSxDQUFDO0NBQzFGLENBQUMsSUFBb0IsaUJBQUEsR0FBQSxtQkFBQSxLQUFBLENBQUssYUFBYSxVQUFVO0VBQ2hELE9BQU8sTUFBTTtFQUNiLFVBQVUsQ0FBQyxTQUFTLGlCQUFpQjtDQUN0QyxDQUFDO0FBQ0Y7QUFDQSxJQUFJLGFBQUEsYUFBcUIsS0FBSyxTQUFTLGVBQWUsRUFBRSxTQUFTO0NBQ2hFLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sVUFBVSxNQUFNO0NBQ3RCLE1BQU0sUUFBUSxPQUFPLFdBQVc7Q0FDaEMsTUFBTSxNQUFBLGFBQWMsY0FBYztFQUNqQyxNQUFNLGVBQWUsTUFBTSxRQUFRLGVBQWUsT0FBTyxRQUFRLG1CQUFBLEdBQXNCO0dBQ3RGO0dBQ0EsWUFBWSxNQUFNO0dBQ2xCLFFBQVEsTUFBTTtHQUNkLFFBQVEsTUFBTTtFQUNmLENBQUM7RUFDRCxPQUFPLGNBQWMsS0FBSyxVQUFVLFdBQVcsSUFBSSxLQUFLO0NBQ3pELEdBQUc7RUFDRjtFQUNBLE1BQU07RUFDTixNQUFNO0VBQ04sTUFBTTtFQUNOLE1BQU0sUUFBUTtFQUNkLE9BQU8sUUFBUTtDQUNoQixDQUFDO0NBQ0QsTUFBTSxNQUFBLGFBQWMsY0FBYztFQUNqQyxNQUFNLE9BQU8sTUFBTSxRQUFRLGFBQWEsT0FBTyxRQUFRO0VBQ3ZELE9BQU8sT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksTUFBTSxDQUFDLEdBQUcsR0FBRyxJQUFvQixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxRQUFRLENBQUMsQ0FBQztDQUNsRixHQUFHO0VBQ0Y7RUFDQSxNQUFNLFFBQVE7RUFDZCxPQUFPLFFBQVE7Q0FDaEIsQ0FBQztDQUNELElBQUksTUFBTSxXQUFXLFdBQVc7RUFDL0IsSUFBSSxPQUFPLE9BQU8sQ0FBQyxrQkFBa0IsUUFBUSxPQUFPLE1BQU0sR0FBRyxHQUFHLE9BQU87RUFDdkUsSUFBSSxPQUFPLEtBQUssTUFBTSxPQUFPLElBQUk7RUFDakMsT0FBTyxjQUFjLFFBQVEsS0FBSztDQUNuQztDQUNBLElBQUksTUFBTSxXQUFXLFlBQVksT0FBTyxvQkFBb0IsUUFBUSxPQUFPLE1BQU0sS0FBSztDQUN0RixJQUFJLE1BQU0sV0FBVyxTQUFTO0VBQzdCLElBQWdCLE9BQU8sVUFBVTtHQUNoQyxNQUFNLHVCQUF1QixNQUFNLFFBQVEsa0JBQWtCLE9BQU8sUUFBUSwwQkFBMEI7R0FNdEcsT0FBK0MsK0JBQStCLGlCQUx6QyxHQUFBLG1CQUFBLElBQUEsQ0FBSSxxQkFBcUI7SUFDN0QsT0FBTyxNQUFNO0lBQ2IsT0FBTyxLQUFLO0lBQ1osTUFBTSxFQUFFLGdCQUFnQixHQUFHO0dBQzVCLENBQzhFLEdBQWMsZ0JBQWdCO0VBQzdHO0VBQ0EsTUFBTSxNQUFNO0NBQ2I7Q0FDQSxPQUFPO0FBQ1IsQ0FBQzs7Ozs7OztBQU9ELElBQUksU0FBQSxhQUFpQixLQUFLLFNBQVMsYUFBYTtDQUNKO0VBQzFDLE1BQU0sb0JBQUEsYUFBNEIsV0FBVyx3QkFBd0I7RUFDckUsSUFBSSxtQkFBbUIsUUFBUSxLQUFLLGdEQUFnRCxrQkFBa0IsK0RBQStEO0NBQ3RLO0NBQ0EsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxVQUFBLGFBQWtCLFdBQVcsWUFBWTtDQUMvQyxJQUFJO0NBQ0osSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFnQixPQUFPLFVBQVU7RUFDaEMsTUFBTSxVQUFVLE9BQU8sT0FBTyxRQUFRLElBQUk7RUFDMUMsTUFBTSxjQUFjLFFBQVEsV0FBVyxVQUFVLE1BQU0sWUFBWSxPQUFPO0VBQzFFLE1BQU0sY0FBYyxRQUFRO0VBQzVCLHVCQUF1QixDQUFDLENBQUMsWUFBWTtFQUNyQyxzQkFBc0IsWUFBWTtFQUNsQyxlQUFlLFFBQVEsY0FBYyxFQUFFLEVBQUU7Q0FDMUMsT0FBTztFQUNOLE1BQU0sbUJBQW1CLE9BQU8sT0FBTyxjQUFjLE9BQU87RUFDNUQsQ0FBQyxzQkFBc0IsdUJBQXVCLFlBQVksbUJBQW1CLFVBQVUsQ0FBQyxDQUFDLENBQUMsTUFBTSxXQUFXLE1BQU0sS0FBSyxHQUFHLEVBQUUsU0FBUywwQkFBMEIsQ0FBQztFQUMvSixlQUFlLFlBQVksT0FBTyxPQUFPLE1BQU0sUUFBUTtHQUN0RCxPQUFPLElBQUksSUFBSSxRQUFRLE9BQU8sSUFBSTtFQUNuQyxDQUFDO0NBQ0Y7Q0FDQSxJQUFJLHNCQUFzQixPQUFPLG9CQUFvQixRQUFRLE9BQU8sV0FBVyxVQUFVLG1CQUFtQjtDQUM1RyxJQUFJLENBQUMsY0FBYyxPQUFPO0NBQzFCLE1BQU0sWUFBNEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksT0FBTyxFQUFFLFNBQVMsYUFBYSxDQUFDO0NBQ3RFLElBQUksWUFBQSxZQUF5QixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBQSxhQUFZLFVBQVU7RUFDekUsVUFBVSxjQUFjLE1BQU07RUFDOUIsVUFBVTtDQUNYLENBQUM7Q0FDRCxPQUFPO0FBQ1IsQ0FBQzs7QUM5SkQsU0FBUyxZQUFZLE9BQU8sVUFBVTtDQUNyQyxNQUFNLFNBQVMsTUFBTTtDQUNyQixNQUFNLFNBQVM7Q0FDZixTQUFTLFFBQVE7QUFDbEI7QUFDQSxTQUFTLGFBQWEsRUFBRSxLQUFLO0NBQzVCLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sa0JBQWtCLE9BQU8sY0FBYyxDQUFDO0NBQzlDLE1BQU0sVUFBQSxhQUEwRCxPQUFPLEtBQUs7Q0FDNUUsT0FBTyxtQkFBbUIsSUFBSSxhQUFhLElBQUksU0FBUyxZQUFZO0VBQ25FLFlBQVksaUJBQWlCLEtBQUs7RUFDbEMsZ0JBQWdCLEtBQUssVUFBVSxPQUFPO0VBQ3RDLEVBQUUsTUFBTTtFQUNSLGFBQVEsZ0JBQWdCLEVBQUU7Q0FDM0IsQ0FBQztDQUNELHNCQUFzQjtFQUNyQixNQUFNLFFBQVEsT0FBTyxRQUFRLFVBQVUsT0FBTyxJQUFJO0VBQ2xELElBQUksU0FBUyxTQUFTLE9BQU87RUFDN0IsSUFBSSxTQUFTLFFBQVEsVUFBVTtFQUMvQixPQUFPLHFCQUFxQjtFQUM1QixNQUFNLFdBQVcsT0FBTztFQUN4QixNQUFNLGVBQWUsT0FBTyxjQUFjO0dBQ3pDLElBQUksU0FBUztHQUNiLFFBQVE7R0FDUixRQUFRO0dBQ1IsTUFBTTtHQUNOLE9BQU87R0FDUCx3QkFBd0I7RUFDekIsQ0FBQztFQUNELElBQUksY0FBYyxTQUFTLFVBQVUsTUFBTSxjQUFjLGFBQWEsVUFBVSxHQUFHO0dBQ2xGLE9BQU8sZUFBZTtJQUNyQixHQUFHO0lBQ0gsU0FBUztJQUNULGVBQWU7R0FDaEIsQ0FBQztHQUNELE9BQU87RUFDUjtFQUNBLE1BQU0sbUJBQW1CLE9BQU8sT0FBTyxpQkFBaUIsSUFBSTtFQUM1RCxJQUFJLGtCQUFrQixTQUFTLFNBQVMsUUFBUSxpQkFBaUIsTUFBTSxjQUFjLFNBQVMsTUFBTSxXQUFXLGdCQUFnQixLQUFLLE9BQU8sT0FBTyxRQUFRLElBQUksSUFBSSxhQUFhO0dBQzlLLElBQUksVUFBVSxPQUFPLEtBQUs7SUFDekIsTUFBTTtJQUNOLEdBQUcsc0JBQXNCLGtCQUFrQixnQkFBZ0I7R0FDNUQsQ0FBQztFQUNGLENBQUM7T0FDSSxJQUFJLENBQUMsT0FBTyxLQUFLLE9BQU8sS0FBSyxFQUFFLE1BQU0sS0FBSyxDQUFDLENBQUMsQ0FBQyxNQUFNLFFBQVEsS0FBSztFQUNyRSxPQUFPO0NBQ1IsR0FBRyxDQUFDLFFBQVEsT0FBTyxPQUFPLENBQUM7Q0FDM0IsT0FBTztBQUNSOzs7Ozs7QUNwQ0EsU0FBUyxVQUFVO0NBQ2xCLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sWUFBWSxPQUFPLFdBQVc7Q0FDcEMsTUFBTSxpQkFBaUIsY0FBYyxRQUFRLFNBQVM7Q0FDdEQsTUFBTSxRQUF3QixpQkFBQSxHQUFBLG1CQUFBLEtBQUEsQ0FBS0MsbUJBQUFBLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBYyxPQUFPLFlBQTZCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLGNBQWMsRUFBRSxHQUFBLGFBQVcsU0FBUyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQWdCLE9BQU8sWUFBYSxPQUFPLE1BQXNCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLGNBQWMsQ0FBQyxDQUFDLElBQW9CLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFBLGFBQVksVUFBVTtFQUN4UixVQUFVO0VBQ1YsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksY0FBYyxDQUFDLENBQUM7Q0FDL0MsQ0FBQyxDQUFDLEVBQUUsQ0FBQztDQUNMLE9BQU8sT0FBTyxRQUFRLFlBQTRCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLE9BQU8sUUFBUSxXQUFXLEVBQUUsVUFBVSxNQUFNLENBQUMsSUFBSTtBQUN4RztBQUNBLFNBQVMsZUFBZTtDQUN2QixNQUFNLFNBQVMsVUFBVTtDQUN6QixNQUFNLGtCQUFrQixPQUFPO0NBQy9CLE1BQU0sVUFBc0IsT0FBTyxXQUFXLE9BQU8sT0FBTyxRQUFRLElBQUksSUFBSSxZQUFZLE9BQU8sT0FBTyxVQUFVLFVBQVUsZ0JBQWdCLE1BQU0sS0FBSztDQUNySixNQUFNLFFBQVEsUUFBUTtDQUN0QixNQUFNLFVBQVUsT0FBTztDQUN2QixzQkFBc0I7RUFDckIsSUFBSSxnQkFBZ0IsT0FBTyxTQUFTLFlBQVksaUJBQWlCLElBQUk7Q0FDdEUsR0FBRyxDQUFDLGlCQUFpQixPQUFPLENBQUM7Q0FDN0IsTUFBTSxpQkFBaUIsVUFBMEIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksT0FBTyxFQUFFLFFBQVEsQ0FBQyxJQUFJO0NBQzNFLE9BQU8sT0FBTyxRQUFRLDZCQUE2QixpQkFBaUMsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksZUFBZTtFQUN0RyxtQkFBbUI7RUFDbkIsVUFBa0QsVUFBVTtHQUMzRCxRQUFRLEtBQUsscUlBQXFJO0dBQ2xKLFFBQVEsS0FBSyxZQUFZLEtBQUs7RUFDL0I7RUFDQSxVQUFVO0NBQ1gsQ0FBQztBQUNGOzs7Ozs7Ozs7Ozs7Ozs7OztBQWlCQSxTQUFTLGdCQUFnQjtDQUN4QixNQUFNLFNBQVMsVUFBVTtDQUN6QixJQUFnQixPQUFPLFVBQVUsUUFBUSxTQUFTO0VBQ2pELE1BQU0sRUFBRSxTQUFTLGVBQWUsT0FBTyxlQUFlLEdBQUcsU0FBUztFQUNsRSxPQUFPLE9BQU8sV0FBVyxNQUFNO0dBQzlCO0dBQ0E7R0FDQTtHQUNBO0VBQ0QsQ0FBQztDQUNGO0NBQ0EsT0FBQSxhQUFlLGFBQWEsU0FBUztFQUNwQyxNQUFNLEVBQUUsU0FBUyxlQUFlLE9BQU8sZUFBZSxHQUFHLFNBQVM7RUFDbEUsT0FBTyxPQUFPLFdBQVcsTUFBTTtHQUM5QjtHQUNBO0dBQ0E7R0FDQTtFQUNELENBQUM7Q0FDRixHQUFHO0VBQ0Y7RUFDQSxZQUFZLE9BQU8sT0FBTyxXQUFXLGFBQWEsU0FBUyxJQUFJO0VBQy9ELFlBQVksT0FBTyxPQUFPLG1CQUFtQixhQUFhLFVBQVUsSUFBSTtFQUN4RSxZQUFZLE9BQU8sT0FBTyxNQUFNO0NBQ2pDLENBQUM7QUFDRjs7Ozs7Ozs7QUFRQSxTQUFTLFdBQVcsT0FBTztDQUMxQixNQUFNLFNBQVMsY0FBYyxDQUFDLENBQUMsS0FBSztDQUNwQyxJQUFJLE9BQU8sTUFBTSxhQUFhLFlBQVksT0FBTyxNQUFNLFNBQVMsTUFBTTtDQUN0RSxPQUFPLFNBQVMsTUFBTSxXQUFXO0FBQ2xDO0FBQ0EsU0FBUyxXQUFXLE1BQU07Q0FDekIsTUFBTSxTQUFTLFVBQVU7Q0FDekIsSUFBZ0IsT0FBTyxVQUFVO0VBQ2hDLE1BQU0sVUFBVSxPQUFPLE9BQU8sUUFBUSxJQUFJO0VBQzFDLE9BQU8sTUFBTSxTQUFTLEtBQUssT0FBTyxPQUFPLElBQUk7Q0FDOUM7Q0FDQSxPQUFPLFlBQVksT0FBTyxPQUFPLFNBQVMscUJBQXFCLE1BQU0sTUFBTSxDQUFDO0FBQzdFOzs7OztBQUtBLFNBQVMsaUJBQWlCLE1BQU07Q0FDL0IsTUFBTSxpQkFBQSxhQUF5QixXQUFXLFlBQVk7Q0FDdEQsT0FBTyxXQUFXO0VBQ2pCLFNBQVMsWUFBWTtHQUNwQixVQUFVLFFBQVEsTUFBTSxHQUFHLFFBQVEsV0FBVyxNQUFNLEVBQUUsWUFBWSxjQUFjLENBQUM7R0FDakYsT0FBTyxNQUFNLFNBQVMsS0FBSyxPQUFPLE9BQU8sSUFBSTtFQUM5QztFQUNBLG1CQUFtQixNQUFNO0NBQzFCLENBQUM7QUFDRjs7Ozs7QUFLQSxTQUFTLGdCQUFnQixNQUFNO0NBQzlCLE1BQU0saUJBQUEsYUFBeUIsV0FBVyxZQUFZO0NBQ3RELE9BQU8sV0FBVztFQUNqQixTQUFTLFlBQVk7R0FDcEIsVUFBVSxRQUFRLE1BQU0sUUFBUSxXQUFXLE1BQU0sRUFBRSxZQUFZLGNBQWMsSUFBSSxDQUFDO0dBQ2xGLE9BQU8sTUFBTSxTQUFTLEtBQUssT0FBTyxPQUFPLElBQUk7RUFDOUM7RUFDQSxtQkFBbUIsTUFBTTtDQUMxQixDQUFDO0FBQ0Y7O0FDcElBLElBQUksbUJBQW1CLFNBQVM7Q0FDL0IsSUFBZ0IsS0FBSyxVQUFVLE9BQU87RUFDckMsb0JBQW9CO0VBQ3BCLHFCQUFxQjtFQUNyQixRQUFRLE9BQU8sR0FBRztDQUNuQjtDQUNBLE9BQU87RUFDTixvQkFBb0I7RUFDcEIscUJBQXFCO0VBQ3JCO0NBQ0Q7QUFDRDs7Ozs7Ozs7Ozs7OztBQ0RBLElBQUksZ0JBQWdCLFlBQVk7Q0FDL0IsT0FBTyxJQUFJLE9BQU8sT0FBTztBQUMxQjtBQUNBLElBQUksU0FBUyxjQUFjLFdBQVc7Q0FDckMsWUFBWSxTQUFTO0VBQ3BCLE1BQU0sU0FBUyxlQUFlO0NBQy9CO0FBQ0Q7Ozs7OztBQ1ZBLFNBQVMsc0JBQXNCLEVBQUUsUUFBUSxVQUFVLEdBQUcsUUFBUTtDQUM3RCxJQUFJLFFBQVEsSUFBSSxHQUFHLE9BQU8sT0FBTztFQUNoQyxHQUFHLE9BQU87RUFDVixHQUFHO0VBQ0gsU0FBUztHQUNSLEdBQUcsT0FBTyxRQUFRO0dBQ2xCLEdBQUcsS0FBSztFQUNUO0NBQ0QsQ0FBQztDQUNELE1BQU0sV0FBMkIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksY0FBYyxVQUFVO0VBQzVELE9BQU87RUFDUDtDQUNELENBQUM7Q0FDRCxJQUFJLE9BQU8sUUFBUSxNQUFNLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLE9BQU8sUUFBUSxNQUFNLEVBQUUsVUFBVSxTQUFTLENBQUM7Q0FDL0YsT0FBTztBQUNSOzs7Ozs7Ozs7O0FBVUEsU0FBUyxlQUFlLEVBQUUsUUFBUSxHQUFHLFFBQVE7Q0FDNUMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksdUJBQXVCO0VBQ2pEO0VBQ0EsR0FBRztFQUNILFVBQTBCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFNBQVMsQ0FBQyxDQUFDO0NBQzFDLENBQUM7QUFDRjs7QUN2Q0EsU0FBUyx1QkFBdUI7Q0FFL0IsdUJBRGUsVUFDUSxHQUFRLElBQUk7QUFDcEM7Ozs7QUFJQSxTQUFTLGtCQUFrQixRQUFRO0NBQ2xDLHFCQUFxQjtDQUN1QixRQUFRLEtBQUssdUdBQXVHO0NBQ2hLLE9BQU87QUFDUjtBQUNBLFNBQVMsNEJBQTRCLFNBQVM7Q0FDN0MscUJBQXFCO0NBQ3JCLE9BQU8saUNBQWlDLFVBQVUsR0FBRyxPQUFPO0FBQzdEOztBQ2RBLFNBQVMsb0JBQW9CLE1BQU0sV0FBVztDQUM3QyxJQUFJLFNBQVMsS0FBSyxHQUFHLE9BQU87RUFDM0IscUJBQXFCO0VBQ3JCLGNBQWM7Q0FDZjtDQUNBLElBQUksbUJBQW1CLE1BQU0sT0FBTztDQUNwQyxJQUFJLE9BQU8sU0FBUyxZQUFZO0VBQy9CLE1BQU0sY0FBYyxRQUFRLGFBQWEsSUFBSTtFQUM3QyxNQUFNLG1CQUFtQixZQUFZO0dBQ3BDLElBQUksYUFBYSxPQUFPLE1BQU0sS0FBSztHQUNuQyxPQUFPO0VBQ1I7RUFDQSxPQUFPO0dBQ04sZUFBZTtHQUNmLG9CQUFvQjtHQUNwQixjQUFjO0VBQ2Y7Q0FDRDtDQUNBLE1BQU0sY0FBYyxRQUFRLEtBQUssYUFBYSxJQUFJO0NBQ2xELE1BQU0sS0FBSyxLQUFLO0NBQ2hCLE1BQU0sbUJBQW1CLFlBQVk7RUFDcEMsSUFBSSxlQUFlLE9BQU8sS0FBSyxHQUFHLE9BQU8sTUFBTSxHQUFHO0VBQ2xELE9BQU87Q0FDUjtDQUNBLE9BQU87RUFDTixlQUFlO0VBQ2Ysb0JBQW9CO0VBQ3BCLGNBQWMsT0FBTyxLQUFLO0NBQzNCO0FBQ0Q7QUFDQSxTQUFTLFdBQVcsTUFBTSxXQUFXO0NBQ3BDLE1BQU0sRUFBRSxlQUFlLHFCQUFxQixNQUFNLFdBQVcsT0FBTyxlQUFlLFVBQVUsb0JBQW9CLE1BQU0sU0FBUztDQUNoSSxNQUFNLFNBQVMsVUFBVTtDQUN6QixNQUFNLEVBQUUsWUFBWTtDQUNwQixNQUFNLENBQUMsVUFBVSxlQUFBLGFBQXVCLFNBQVM7RUFDaEQsUUFBUTtFQUNSLFNBQVMsS0FBSztFQUNkLE1BQU0sS0FBSztFQUNYLFFBQVEsS0FBSztFQUNiLFNBQVMsS0FBSztFQUNkLE9BQU8sS0FBSztDQUNiLENBQUM7Q0FDRCxhQUFRLGdCQUFnQjtFQUN2QixNQUFNLG9CQUFvQixPQUFPLGtCQUFrQjtHQUNsRCxTQUFTLFlBQVksVUFBVTtJQUM5QixNQUFNLGlCQUFpQixPQUFPLGNBQWMsUUFBUTtJQUNwRCxNQUFNLEdBQUcsV0FBVyxjQUFjLE9BQU8saUJBQWlCLGVBQWUsUUFBUTtJQUNqRixJQUFJLGVBQWUsS0FBSyxHQUFHLE9BQU87S0FDakMsU0FBUztLQUNULFVBQVUsZUFBZTtLQUN6QixVQUFVLGVBQWU7S0FDekIsUUFBUTtLQUNSLFFBQVEsT0FBTyxRQUFRLFlBQVksU0FBUyxNQUFNO0lBQ25EO0lBQ0EsT0FBTztLQUNOLFNBQVMsV0FBVztLQUNwQixVQUFVLFdBQVc7S0FDckIsVUFBVSxlQUFlO0tBQ3pCLFFBQVE7S0FDUixRQUFRLE9BQU8sUUFBUSxZQUFZLFNBQVMsTUFBTTtJQUNuRDtHQUNEO0dBQ0EsTUFBTSxVQUFVLFlBQVksY0FBYyxlQUFlO0dBQ3pELE1BQU0sT0FBTyxZQUFZLGNBQWMsWUFBWTtHQUNuRCxJQUFJLFFBQVEsWUFBWSxrQkFBa0IsS0FBSyxZQUFZLGdCQUFnQixPQUFPO0dBQ2xGLE1BQU0sY0FBYyxNQUFNLGNBQWM7SUFDdkMsUUFBUSxjQUFjO0lBQ3RCO0lBQ0E7R0FDRCxDQUFDO0dBQ0QsSUFBSSxDQUFDLGNBQWMsT0FBTztHQUMxQixJQUFJLENBQUMsYUFBYSxPQUFPO0dBQ3pCLE1BQU0sbUJBQW1CLE1BQU0sSUFBSSxTQUFTLFlBQVk7SUFDdkQsWUFBWTtLQUNYLFFBQVE7S0FDUjtLQUNBO0tBQ0EsUUFBUSxjQUFjO0tBQ3RCLGVBQWUsUUFBUSxLQUFLO0tBQzVCLGFBQWEsUUFBUSxJQUFJO0lBQzFCLENBQUM7R0FDRixDQUFDO0dBQ0QsWUFBWTtJQUNYLFFBQVE7SUFDUixTQUFTLEtBQUs7SUFDZCxNQUFNLEtBQUs7SUFDWCxRQUFRLEtBQUs7SUFDYixTQUFTLEtBQUs7SUFDZCxPQUFPLEtBQUs7R0FDYixDQUFDO0dBQ0QsT0FBTztFQUNSO0VBQ0EsT0FBTyxXQUFXLEtBQUssSUFBSSxRQUFRLE1BQU07R0FDeEMsV0FBVztHQUNYO0VBQ0QsQ0FBQztDQUNGLEdBQUc7RUFDRjtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsT0FBTztBQUNSO0FBQ0EsSUFBSSw2QkFBNkIsVUFBVTtDQUMxQyxJQUFJLG1CQUFtQixPQUFPLE9BQU8sRUFBRSxHQUFHLE1BQU07Q0FDaEQsTUFBTSxjQUFjLFFBQVEsTUFBTSxhQUFhLElBQUk7Q0FDbkQsTUFBTSxLQUFLLE1BQU07Q0FDakIsTUFBTSxtQkFBbUIsWUFBWTtFQUNwQyxJQUFJLGVBQWUsT0FBTyxLQUFLLEdBQUcsT0FBTyxNQUFNLEdBQUc7RUFDbEQsT0FBTztDQUNSO0NBQ0EsT0FBTztFQUNOLGVBQWU7RUFDZixvQkFBb0I7RUFDcEIsY0FBYyxPQUFPLEtBQUs7Q0FDM0I7QUFDRDtBQUNBLFNBQVMsTUFBTSxNQUFNO0NBQ3BCLE1BQU0sRUFBRSxVQUFVLEdBQUcsU0FBUztDQUM5QixNQUFNLFdBQVcsV0FBVywwQkFBMEIsSUFBSSxDQUFDO0NBQzNELE9BQU8sV0FBVyxPQUFPLGFBQWEsYUFBYSxTQUFTLFFBQVEsSUFBSSxXQUFXO0FBQ3BGOzs7Ozs7Ozs7Ozs7OztBQzlHQSxTQUFTLGVBQWUsTUFBTTtDQUM3QixNQUFNLGdCQUFnQixVQUFVLEVBQUUsTUFBTSxNQUFNLFdBQVcsS0FBSyxFQUFFLENBQUM7Q0FDakUsTUFBTSxTQUFTLE1BQU0sVUFBVTtDQUMvQixJQUFnQixPQUFPLFVBQVU7RUFDaEMsTUFBTSxRQUFRLE9BQU8sT0FBTyxRQUFRLElBQUk7RUFDeEMsT0FBTyxNQUFNLFNBQVMsS0FBSyxPQUFPLEtBQUssSUFBSTtDQUM1QztDQUNBLE9BQU8sWUFBWSxPQUFPLE9BQU8sU0FBUyxxQkFBcUIsTUFBTSxNQUFNLENBQUM7QUFDN0U7Ozs7Ozs7Ozs7Ozs7QUNUQSxTQUFTLFlBQVksTUFBTTtDQUMxQixNQUFNLFNBQVMsVUFBVTtDQUN6QixJQUFnQixPQUFPLFVBQVU7RUFDaEMsTUFBTSxXQUFXLE9BQU8sT0FBTyxTQUFTLElBQUk7RUFDNUMsT0FBTyxNQUFNLFNBQVMsS0FBSyxPQUFPLFFBQVEsSUFBSTtDQUMvQztDQUNBLE9BQU8sWUFBWSxPQUFPLE9BQU8sVUFBVSxxQkFBcUIsTUFBTSxNQUFNLENBQUM7QUFDOUU7O0FDcEJBLFNBQVMsZUFBZTtDQUN2QixNQUFNLFNBQVMsVUFBVTtDQUN6QixJQUFnQixPQUFPLFVBQVUsT0FBTyxPQUFPLE9BQU8sU0FBUyxJQUFJLENBQUMsQ0FBQyxNQUFNLGdCQUFnQjtDQUMzRixPQUFPLFlBQVksT0FBTyxPQUFPLFdBQVcsYUFBYSxTQUFTLE1BQU0sZ0JBQWdCLENBQUM7QUFDMUY7O0FDREEsSUFBSSw0QkFBNEI7QUFDaEMsSUFBSSwwQkFBMEIsQ0FBQztBQUMvQixTQUFTLGVBQWUsUUFBUSxPQUFPO0NBQ3RDLElBQUksQ0FBQyxPQUFPO0NBQ1osS0FBSyxNQUFNLENBQUMsS0FBSyxVQUFVLE9BQU8sUUFBUSxLQUFLLEdBQUcsSUFBSSxRQUFRLDhCQUE4QixVQUFVLEtBQUssS0FBSyxVQUFVLE9BQU8sT0FBTyxhQUFhLEtBQUssT0FBTyxVQUFVLFlBQVksS0FBSyxPQUFPLEtBQUssQ0FBQztBQUMxTTtBQUNBLFNBQVMsTUFBTSxPQUFPO0NBQ3JCLE1BQU0sRUFBRSxPQUFPLFVBQVUsT0FBTyx1QkFBdUI7Q0FDdkQsTUFBTSxZQUFBLGFBQW9CLGNBQWMsYUFBYSxLQUFLLElBQUksS0FBSyxJQUFJLEVBQUUsUUFBUSxTQUFTLEdBQUcsQ0FBQyxRQUFRLENBQUM7Q0FDdkcsUUFBUSxNQUFNLEtBQWQ7RUFDQyxLQUFLLFNBQVMsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksU0FBUztHQUNqRCxHQUFHO0dBQ0gsMEJBQTBCO0dBQzFCO0VBQ0QsQ0FBQztFQUNELEtBQUssUUFBUSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxRQUFRO0dBQy9DLEdBQUc7R0FDSCwwQkFBMEI7RUFDM0IsQ0FBQztFQUNELEtBQUssUUFBUSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxRQUFRO0dBQy9DLEdBQUc7R0FDSCxZQUFZLE9BQU8sZUFBZSxPQUFPLFFBQVEsZUFBZSxZQUFZLEtBQUs7R0FDakY7R0FDQSwwQkFBMEI7RUFDM0IsQ0FBQztFQUNELEtBQUs7R0FDSixJQUFJLE1BQU0sY0FBYyxRQUFRLElBQUksMkJBQTJCLFVBQVUsUUFBUSxJQUFJLDJCQUEyQixLQUFLLEtBQUEsS0FBQSxJQUFnQixPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxnQkFBZ0I7SUFDL0s7SUFDQTtJQUNBO0dBQ0QsQ0FBQztHQUNELE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFNBQVM7SUFDbkMsR0FBRztJQUNILHlCQUF5QjtJQUN6QjtHQUNELENBQUM7RUFDRixLQUFLLFVBQVUsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksUUFBUTtHQUNqRDtHQUNBO0dBQ0E7RUFDRCxDQUFDO0VBQ0QsU0FBUyxPQUFPO0NBQ2pCO0FBQ0Q7QUFDQSxTQUFTLGVBQWUsRUFBRSxPQUFPLFVBQVUsU0FBUztDQUNuRCxNQUFNLHlCQUF5QixhQUFhLEtBQUs7Q0FDakQsTUFBTSxDQUFDLHFCQUFBLGFBQTZCLGVBQWU7RUFDbEQsSUFBSSxDQUFDLDBCQUEwQixPQUFPLGFBQWEsYUFBYTtFQUNoRSxPQUFPLFNBQVMsY0FBYyxTQUFTLDBCQUEwQixFQUFFLENBQUMsRUFBRSxlQUFlLEtBQUs7Q0FDM0YsQ0FBQztDQUNELE1BQU0sT0FBTyx5QkFBeUIscUJBQXFCLEtBQUssWUFBWTtDQUM1RSxNQUFNLFlBQUEsYUFBb0IsZUFBZSxFQUFFLFFBQVEsS0FBSyxJQUFJLENBQUMsSUFBSSxDQUFDO0NBQ2xFLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFNBQVM7RUFDbkMsR0FBRztHQUNGLDRCQUE0QjtFQUM3Qix5QkFBeUI7RUFDekI7RUFDQSwwQkFBMEI7Q0FDM0IsQ0FBQztBQUNGO0FBQ0EsU0FBUyxPQUFPLEVBQUUsT0FBTyxVQUFVLHNCQUFzQjtDQUN4RCxNQUFNLFNBQVMsVUFBVTtDQUN6QixNQUFNLFdBQVcsWUFBWTtDQUM3QixNQUFNLFlBQUEsYUFBb0IsY0FBYyxhQUFhLEtBQUssSUFBSSxLQUFLLElBQUksRUFBRSxRQUFRLFNBQVMsR0FBRyxDQUFDLFFBQVEsQ0FBQztDQUN2RyxNQUFNLGFBQWEsT0FBTyxPQUFPLFNBQVMsWUFBWSxNQUFNLFNBQVMsTUFBTSxNQUFNLFNBQVMscUJBQXFCLE1BQU0sU0FBUztDQUM5SCxJQUE2QyxPQUFPLE9BQU8sT0FBTyxhQUFhLFlBQVksU0FBUyxLQUFLLENBQUMsQ0FBQyxRQUFRLFFBQVEsS0FBSywySUFBMkk7Q0FDM1EsYUFBUSxnQkFBZ0I7RUFDdkIsSUFBSSxZQUFZO0VBQ2hCLElBQUksT0FBTyxLQUFLO0dBQ2YsTUFBTSxPQUFPLFNBQVMsY0FBYyxHQUFHO0dBQ3ZDLEtBQUssT0FBTyxNQUFNO0dBQ2xCLE1BQU0sVUFBVSxLQUFLO0dBQ3JCLEtBQUssTUFBTSxNQUFNLFNBQVMsU0FBUyxJQUFJLEdBQUcsUUFBUSxTQUFTO0dBQzNELE1BQU0sU0FBUyxTQUFTLGNBQWMsUUFBUTtHQUM5QyxlQUFlLFFBQVEsS0FBSztHQUM1QixTQUFTLEtBQUssWUFBWSxNQUFNO0dBQ2hDLGFBQWEsT0FBTyxPQUFPO0VBQzVCO0VBQ0EsSUFBSSxPQUFPLGFBQWEsVUFBVTtHQUNqQyxNQUFNLFdBQVcsT0FBTyxPQUFPLFNBQVMsV0FBVyxNQUFNLE9BQU87R0FDaEUsTUFBTSxZQUFZLE9BQU8sT0FBTyxVQUFVLFdBQVcsTUFBTSxRQUFRLEtBQUs7R0FDeEUsS0FBSyxNQUFNLE1BQU0sU0FBUyxTQUFTO0lBQ2xDLElBQUksR0FBRyxhQUFhLEtBQUssR0FBRztJQUM1QixNQUFNLFFBQVEsR0FBRyxhQUFhLE1BQU0sS0FBSztJQUN6QyxNQUFNLFNBQVMsR0FBRyxhQUFhLE9BQU8sS0FBSyxLQUFLO0lBQ2hELElBQUksR0FBRyxnQkFBZ0IsWUFBWSxVQUFVLFlBQVksV0FBVyxXQUFXO0dBQ2hGO0dBQ0EsTUFBTSxTQUFTLFNBQVMsY0FBYyxRQUFRO0dBQzlDLE9BQU8sY0FBYztHQUNyQixlQUFlLFFBQVEsS0FBSztHQUM1QixTQUFTLEtBQUssWUFBWSxNQUFNO0dBQ2hDLGFBQWEsT0FBTyxPQUFPO0VBQzVCO0NBQ0QsR0FBRztFQUNGO0VBQ0E7RUFDQTtDQUNELENBQUM7Q0FDRCxJQUFnQixPQUFPLFVBQVU7RUFDaEMsSUFBSSxPQUFPLEtBQUs7R0FDZixJQUFJLENBQUMsb0JBQW9CLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFVBQVU7SUFDN0QsR0FBRztJQUNILDBCQUEwQjtHQUMzQixDQUFDO0dBQ0QsT0FBdUIsaUJBQUEsR0FBQSxtQkFBQSxJQUFBLENBQUksVUFBVTtJQUNwQyxHQUFHO0lBQ0gsUUFBUTtJQUNSLDBCQUEwQjtHQUMzQixDQUFDO0VBQ0Y7RUFDQSxJQUFJLE9BQU8sYUFBYSxVQUFVLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFVBQVU7R0FDdEUsR0FBRztHQUNILHlCQUF5QjtHQUN6QiwwQkFBMEI7RUFDM0IsQ0FBQztFQUNELE9BQU87Q0FDUjtDQUNBLElBQUksY0FBYyxPQUFPLGFBQWEsVUFBVSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVO0VBQ3BGLEdBQUc7RUFDSCwwQkFBMEI7RUFDMUIseUJBQXlCO0NBQzFCLENBQUM7Q0FDRCxJQUFJLENBQUMsVUFBVTtFQUNkLElBQUksT0FBTyxLQUFLLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJLFVBQVU7R0FDcEQsR0FBRztHQUNILDBCQUEwQjtFQUMzQixDQUFDO0VBQ0QsSUFBSSxPQUFPLGFBQWEsVUFBVSxPQUF1QixpQkFBQSxHQUFBLG1CQUFBLElBQUEsQ0FBSSxVQUFVO0dBQ3RFLEdBQUc7R0FDSCx5QkFBeUI7R0FDekIsMEJBQTBCO0VBQzNCLENBQUM7Q0FDRjtDQUNBLE9BQU87QUFDUjs7QUN2SUEsU0FBUyxxQkFBcUIsUUFBUSxPQUFPLFNBQVMsa0JBQWtCO0NBQ3ZFLFVBQVUsaUJBQWlCLE9BQU87Q0FDbEMsTUFBTSxZQUFZLFFBQVEsS0FBSyxVQUFVLE1BQU0sSUFBSSxDQUFDLENBQUMsUUFBUSxTQUFTLFNBQVMsS0FBSyxDQUFDO0NBQ3JGLE1BQU0sYUFBYSxDQUFDO0NBQ3BCLE1BQU0sa0JBQWtCLENBQUM7Q0FDekIsSUFBSTtDQUNKLEtBQUssSUFBSSxJQUFJLFVBQVUsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0VBQy9DLE1BQU0sUUFBUSxVQUFVO0VBQ3hCLEtBQUssSUFBSSxJQUFJLE1BQU0sU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQzNDLE1BQU0sSUFBSSxNQUFNO0dBQ2hCLElBQUksQ0FBQyxHQUFHO0dBQ1IsSUFBSSxFQUFFLE9BQ0Q7UUFBQSxDQUFDLE9BQU8sUUFBUTtLQUNuQixLQUFLO0tBQ0wsVUFBVSxFQUFFO0lBQ2I7R0FBQSxPQUNNLElBQUksb0JBQW9CLEdBQUcsSUFBSTtJQUNyQyxNQUFNLE9BQU8sS0FBSyxVQUFVLEVBQUUsaUJBQWlCO0lBQy9DLFdBQVcsS0FBSztLQUNmLEtBQUs7S0FDTCxPQUFPLEVBQUUsTUFBTSxzQkFBc0I7S0FDckMsVUFBVSxXQUFXLElBQUk7SUFDMUIsQ0FBQztHQUNGLFFBQVEsQ0FBQztRQUNKO0lBQ0osTUFBTSxZQUFZLEVBQUUsUUFBUSxFQUFFO0lBQzlCLElBQUksV0FBVztLQUNkLElBQUksZ0JBQWdCLFlBQVk7VUFDM0IsZ0JBQWdCLGFBQWE7SUFDbkM7SUFDQSxXQUFXLEtBQUs7S0FDZixLQUFLO0tBQ0wsT0FBTztNQUNOLEdBQUc7TUFDSDtLQUNEO0lBQ0QsQ0FBQztHQUNGO0VBQ0Q7Q0FDRDtDQUNBLElBQUksT0FBTyxXQUFXLEtBQUssS0FBSztDQUNoQyxJQUFJLE9BQU8sV0FBVyxLQUFLO0VBQzFCLEtBQUs7RUFDTCxPQUFPO0dBQ04sVUFBVTtHQUNWLFNBQVM7RUFDVjtDQUNELENBQUM7Q0FDRCxXQUFXLFFBQVE7Q0FDbkIsTUFBTSxtQkFBbUIsUUFBUSxTQUFTLFVBQVUsTUFBTSxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxTQUFTLFNBQVMsS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLFVBQVU7RUFDdkgsS0FBSztFQUNMLE9BQU87R0FDTixHQUFHO0dBQ0g7RUFDRDtDQUNELEVBQUU7Q0FDRixNQUFNLFdBQVcsT0FBTyxLQUFLO0NBQzdCLE1BQU0sa0JBQWtCLENBQUM7Q0FDekIsSUFBSSxVQUFVO0VBQ2IsUUFBUSxTQUFTLFVBQVU7R0FDMUIsQ0FBQyxTQUFTLE9BQU8sTUFBTSxRQUFRLEVBQUUsSUFBQSxFQUFNLFNBQVMsU0FBUztJQUN4RCxNQUFNLGVBQWUsdUJBQXVCLElBQUk7SUFDaEQsZ0JBQWdCLEtBQUs7S0FDcEIsS0FBSztLQUNMLE9BQU87TUFDTixLQUFLO01BQ0wsR0FBRztNQUNILGFBQWEsb0JBQW9CLGtCQUFrQixZQUFZLEtBQUssYUFBYTtNQUNqRiwwQkFBMEI7TUFDMUI7S0FDRDtJQUNELENBQUM7R0FDRixDQUFDO0VBQ0YsQ0FBQztFQUNELElBQUksU0FBUyxhQUFhLGdCQUFnQixLQUFLO0dBQzlDLEtBQUs7R0FDTCxPQUFPO0lBQ04sR0FBRyxTQUFTLFlBQVk7SUFDeEI7R0FDRDtHQUNBLFVBQVUsU0FBUyxZQUFZO0dBQy9CLFdBQVc7RUFDWixDQUFDO0NBQ0Y7Q0FDQSxNQUFNLGVBQWUsQ0FBQztDQUN0QixJQUFJLFVBQVUsUUFBUSxTQUFTLFVBQVU7RUFDeEMsU0FBUyxPQUFPLE1BQU0sUUFBUSxFQUFFLFVBQVUsU0FBUyxZQUFZO0dBQzlELGFBQWEsS0FBSztJQUNqQixLQUFLO0lBQ0wsT0FBTztLQUNOLEdBQUcsc0JBQXNCLFVBQVUsU0FBUyxnQkFBZ0I7S0FDNUQ7SUFDRDtHQUNELENBQUM7RUFDRixDQUFDO0NBQ0YsQ0FBQztDQUNELE1BQU0sU0FBUyxRQUFRLFNBQVMsVUFBVSxNQUFNLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLFVBQVUsVUFBVSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxVQUFVLEdBQUcsYUFBYTtFQUNsSSxLQUFLO0VBQ0wsT0FBTztHQUNOLEdBQUc7R0FDSDtFQUNEO0VBQ0E7Q0FDRCxFQUFFO0NBQ0YsTUFBTSxjQUFjLFFBQVEsU0FBUyxVQUFVLE1BQU0sZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsV0FBVyxXQUFXLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLFVBQVUsR0FBRyxjQUFjO0VBQy9JLEtBQUs7RUFDTCxPQUFPO0dBQ04sR0FBRztHQUNIO0VBQ0Q7RUFDQTtDQUNELEVBQUU7Q0FDRixNQUFNLE9BQU8sQ0FBQztDQUNkLHFCQUFxQixNQUFNLFVBQVU7Q0FDckMsS0FBSyxLQUFLLEdBQUcsWUFBWTtDQUN6QixxQkFBcUIsTUFBTSxnQkFBZ0I7Q0FDM0MsS0FBSyxLQUFLLEdBQUcsZUFBZTtDQUM1QixxQkFBcUIsTUFBTSxNQUFNO0NBQ2pDLHFCQUFxQixNQUFNLFdBQVc7Q0FDdEMsT0FBTztBQUNSOzs7OztBQUtBLElBQUksV0FBVyxxQkFBcUI7Q0FDbkMsTUFBTSxTQUFTLFVBQVU7Q0FDekIsTUFBTSxRQUFRLE9BQU8sUUFBUSxLQUFLO0NBQ2xDLElBQWdCLE9BQU8sVUFBVSxPQUFPLHFCQUFxQixRQUFRLE9BQU8sT0FBTyxPQUFPLFFBQVEsSUFBSSxHQUFHLGdCQUFnQjtDQUN6SCxNQUFNLGFBQUEsYUFBcUIsYUFBYSxZQUFZLHFCQUFxQixRQUFRLE9BQU8sU0FBUyxnQkFBZ0IsR0FBRztFQUNuSDtFQUNBO0VBQ0E7Q0FDRCxDQUFDO0NBQ0QsT0FBTyxZQUFZLE9BQU8sT0FBTyxTQUFTLFlBQVksRUFBRSxTQUFTLFVBQVUsQ0FBQztBQUM3RTs7QUNySUEsSUFBSSxtQkFBbUIsRUFBRSwwQkFBMEIsS0FBSzs7Ozs7O0FBTXhELElBQUksZ0JBQWdCO0NBQ25CLE1BQU0sU0FBUyxVQUFVO0NBQ3pCLE1BQU0sUUFBUSxPQUFPLFFBQVEsS0FBSztDQUNsQyxNQUFNLFlBQVksWUFBWTtFQUM3QixNQUFNLFFBQVEsc0JBQXNCLFNBQVMsT0FBTyxLQUFLLFVBQVUsT0FBTyxnQkFBZ0I7RUFDMUYsS0FBSyxNQUFNLFVBQVUsTUFBTSxJQUFJLElBQUksT0FBTyxPQUFPLE9BQU8sUUFBUSxVQUFVO0dBQ3pFLE1BQU0sa0JBQWtCO0dBQ3hCLGdCQUFnQixxQkFBcUI7RUFDdEM7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxNQUFNLGNBQWMsWUFBWTtFQUMvQixPQUFPLHNCQUFzQixTQUFTLE9BQU8sQ0FBQztDQUMvQztDQUNBLElBQWdCLE9BQU8sVUFFdEIsT0FBTyxjQUFjLHNCQUFzQixTQURyQixPQUFPLE9BQU8sUUFBUSxJQUNRLENBQWEsR0FBRyxPQUFPLFdBQVcsK0JBQStCLENBQUMsQ0FBQztDQUV4SCxPQUFPLGNBQWMsWUFBWSxPQUFPLE9BQU8sU0FBUyxZQUFZLEVBQUUsU0FBUyxVQUFVLENBQUMsQ0FBQztBQUM1RjtBQUNBLFNBQVMsY0FBYyxTQUFTO0NBQy9CLE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJQyxtQkFBQUEsVUFBVSxFQUFFLFVBQVUsUUFBUSxLQUFLLE9BQU8sTUFBc0IsaUJBQUEsR0FBQSxhQUFBLGNBQUEsQ0FBYyxPQUFPO0VBQy9HLEdBQUc7RUFDSCxLQUFLLGVBQWUsTUFBTSxJQUFJLEdBQUc7Q0FDbEMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNOOzs7Ozs7Ozs7OztBQ3BCQSxTQUFTLFlBQVksT0FBTztDQUMzQixNQUFNLE9BQU8sUUFBUSxNQUFNLGdCQUFnQjtDQUMzQyxNQUFNLFFBQVEsVUFBVSxDQUFDLENBQUMsUUFBUSxLQUFLO0NBQ3ZDLE1BQU0sV0FBVyxZQUFZO0NBQzdCLGFBQVEsZ0JBQWdCO0VBQ3ZCLElBQUksVUFBVSxTQUFTLGlCQUFpQixRQUFRLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxTQUFTLE9BQU8sR0FBRyxPQUFPLENBQUM7Q0FDaEcsR0FBRyxDQUFDLFFBQVEsQ0FBQztDQUNiLE1BQU0sZUFBZSxXQUFXLEtBQUssUUFBUSxRQUFRLElBQUksUUFBUSxVQUFVLElBQUksUUFBQSx1Q0FBNkIsSUFBSSxJQUFJO0NBQ3BILE9BQXVCLGlCQUFBLEdBQUEsbUJBQUEsSUFBQSxDQUFJQyxtQkFBQUEsVUFBVSxFQUFFLFVBQVUsYUFBYSxLQUFLLFFBQXdCLGlCQUFBLEdBQUEsYUFBQSxjQUFBLENBQWMsT0FBTztFQUMvRyxHQUFHO0VBQ0gsS0FBSyxZQUFZLEtBQUssVUFBVSxHQUFHO0VBQ25DO0NBQ0QsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNOIiwieF9nb29nbGVfaWdub3JlTGlzdCI6WzAsMSwyLDMsNCw1LDYsNyw4LDksMTAsMTEsMTIsMTMsMTQsMTUsMTYsMTcsMTgsMTksMjAsMjEsMjIsMjMsMjQsMjUsMjYsMjcsMjgsMjksMzAsMzEsMzIsMzMsMzQsMzUsMzYsMzcsMzgsMzksNDAsNDEsNDIsNDMsNDQsNDUsNDYsNDcsNDgsNDksNTAsNTEsNTIsNTMsNTQsNTUsNTYsNTcsNTgsNTksNjAsNjEsNjIsNjMsNjQsNjUsNjYsNjddfQ==