import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/nft/favorite-button.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Heart } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { Button } from "/src/components/ui/button.tsx";
import { Tooltip, TooltipContent, TooltipTrigger } from "/src/components/ui/tooltip.tsx";
import { useToggleFavoriteNFT } from "/src/hooks/use-nfts.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/nft/favorite-button.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
export function FavoriteButton(t0) {
	_s();
	const $ = _c(27);
	if ($[0] !== "0592a1f5761da62c4d1daf958bdc5e0e7554ca4dba8d9f5981d3e33aa4cf9c3f") {
		for (let $i = 0; $i < 27; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "0592a1f5761da62c4d1daf958bdc5e0e7554ca4dba8d9f5981d3e33aa4cf9c3f";
	}
	const { nftId, nftName, isFavorited, likes, className } = t0;
	const toggleFavorite = useToggleFavoriteNFT();
	const label = isFavorited ? `Remover ${nftName} dos favoritos` : `Favoritar ${nftName}`;
	let t1;
	if ($[1] !== nftId || $[2] !== toggleFavorite) {
		t1 = (e) => {
			e.preventDefault();
			e.stopPropagation();
			toggleFavorite.mutate(nftId);
		};
		$[1] = nftId;
		$[2] = toggleFavorite;
		$[3] = t1;
	} else {
		t1 = $[3];
	}
	const t2 = isFavorited && "text-destructive";
	let t3;
	if ($[4] !== className || $[5] !== t2) {
		t3 = cn("gap-1.5 rounded-full bg-background/90 px-2.5 shadow-xs backdrop-blur-sm hover:bg-background", t2, className);
		$[4] = className;
		$[5] = t2;
		$[6] = t3;
	} else {
		t3 = $[6];
	}
	let t4;
	if ($[7] !== isFavorited || $[8] !== label || $[9] !== t1 || $[10] !== t3) {
		t4 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			variant: "secondary",
			size: "sm",
			"aria-label": label,
			"aria-pressed": isFavorited,
			onClick: t1,
			className: t3
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 10
		}, this);
		$[7] = isFavorited;
		$[8] = label;
		$[9] = t1;
		$[10] = t3;
		$[11] = t4;
	} else {
		t4 = $[11];
	}
	const t5 = isFavorited && "scale-110 fill-current";
	let t6;
	if ($[12] !== t5) {
		t6 = cn("size-3.5 transition-transform motion-reduce:transition-none", t5);
		$[12] = t5;
		$[13] = t6;
	} else {
		t6 = $[13];
	}
	let t7;
	if ($[14] !== t6) {
		t7 = /* @__PURE__ */ _jsxDEV(Heart, {
			className: t6,
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 76,
			columnNumber: 10
		}, this);
		$[14] = t6;
		$[15] = t7;
	} else {
		t7 = $[15];
	}
	let t8;
	if ($[16] !== likes) {
		t8 = /* @__PURE__ */ _jsxDEV("span", {
			className: "font-mono text-xs tabular-nums",
			children: likes
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 84,
			columnNumber: 10
		}, this);
		$[16] = likes;
		$[17] = t8;
	} else {
		t8 = $[17];
	}
	let t9;
	if ($[18] !== t4 || $[19] !== t7 || $[20] !== t8) {
		t9 = /* @__PURE__ */ _jsxDEV(TooltipTrigger, {
			render: t4,
			children: [t7, t8]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 92,
			columnNumber: 10
		}, this);
		$[18] = t4;
		$[19] = t7;
		$[20] = t8;
		$[21] = t9;
	} else {
		t9 = $[21];
	}
	let t10;
	if ($[22] !== label) {
		t10 = /* @__PURE__ */ _jsxDEV(TooltipContent, { children: label }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 102,
			columnNumber: 11
		}, this);
		$[22] = label;
		$[23] = t10;
	} else {
		t10 = $[23];
	}
	let t11;
	if ($[24] !== t10 || $[25] !== t9) {
		t11 = /* @__PURE__ */ _jsxDEV(Tooltip, { children: [t9, t10] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 110,
			columnNumber: 11
		}, this);
		$[24] = t10;
		$[25] = t9;
		$[26] = t11;
	} else {
		t11 = $[26];
	}
	return t11;
}
_s(FavoriteButton, "I7+4W+eAvzUOa6fHjLt67kUpg/0=", false, function() {
	return [useToggleFavoriteNFT];
});
_c2 = FavoriteButton;
var _c2;
$RefreshReg$(_c2, "FavoriteButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/nft/favorite-button.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/nft/favorite-button.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/nft/favorite-button.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/nft/favorite-button.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGFBQWE7QUFDdEIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxTQUFTQyxnQkFBZ0JDLHNCQUFzQjtBQUN4RCxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsVUFBVTs7OztBQVVuQixPQUFPLFNBQUFDLGVBQUFDLElBQUE7O0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQXdCLFFBQUFLLE9BQUFDLFNBQUFDLGFBQUFDLE9BQUFDLGNBQUFWO0NBTzdCLE1BQUFXLGlCQUF1QmQscUJBQXFCO0NBQzVDLE1BQUFlLFFBQWNKLGNBQUEsV0FBeUJELFFBQU8sa0JBQWhDLGFBQWdFQTtDQUFTLElBQUFNO0NBQUEsSUFBQVosRUFBQSxPQUFBSyxTQUFBTCxFQUFBLE9BQUFVLGdCQUFBO0VBWXBFRSxNQUFBQyxNQUFBO0dBQ1BBLEVBQUNDLGVBQWdCO0dBQ2pCRCxFQUFDRSxnQkFBaUI7R0FDbEJMLGVBQWNNLE9BQVFYLEtBQUs7RUFBQztFQUM3QkwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFVO0VBQUFWLEVBQUEsS0FBQVk7Q0FBQTtFQUFBQSxLQUFBWixFQUFBO0NBQUE7Q0FHQyxNQUFBaUIsS0FBQVYsZUFBQTtDQUFpQyxJQUFBVztDQUFBLElBQUFsQixFQUFBLE9BQUFTLGFBQUFULEVBQUEsT0FBQWlCLElBQUE7RUFGeEJDLEtBQUFyQixHQUNULCtGQUNBb0IsSUFDQVIsU0FDRjtFQUFDVCxFQUFBLEtBQUFTO0VBQUFULEVBQUEsS0FBQWlCO0VBQUFqQixFQUFBLEtBQUFrQjtDQUFBO0VBQUFBLEtBQUFsQixFQUFBO0NBQUE7Q0FBQSxJQUFBbUI7Q0FBQSxJQUFBbkIsRUFBQSxPQUFBTyxlQUFBUCxFQUFBLE9BQUFXLFNBQUFYLEVBQUEsT0FBQVksTUFBQVosRUFBQSxRQUFBa0IsSUFBQTtFQWZIQyxLQUFBLHdCQUFDLFFBQUQ7R0FDTztHQUNHO0dBQ0g7R0FDT1I7R0FDRUo7R0FDTCxTQUFBSztHQUtFLFdBQUFNO0VBSVY7Ozs7O0VBQ0RsQixFQUFBLEtBQUFPO0VBQUFQLEVBQUEsS0FBQVc7RUFBQVgsRUFBQSxLQUFBWTtFQUFBWixFQUFBLE1BQUFrQjtFQUFBbEIsRUFBQSxNQUFBbUI7Q0FBQTtFQUFBQSxLQUFBbkIsRUFBQTtDQUFBO0NBTUEsTUFBQW9CLEtBQUFiLGVBQUE7Q0FBdUMsSUFBQWM7Q0FBQSxJQUFBckIsRUFBQSxRQUFBb0IsSUFBQTtFQUY5QkMsS0FBQXhCLEdBQ1QsK0RBQ0F1QixFQUNGO0VBQUNwQixFQUFBLE1BQUFvQjtFQUFBcEIsRUFBQSxNQUFBcUI7Q0FBQTtFQUFBQSxLQUFBckIsRUFBQTtDQUFBO0NBQUEsSUFBQXNCO0NBQUEsSUFBQXRCLEVBQUEsUUFBQXFCLElBQUE7RUFKSEMsS0FBQSx3QkFBQyxPQUFEO0dBQ2EsV0FBQUQ7R0FJQztFQUFNOzs7OztFQUNsQnJCLEVBQUEsTUFBQXFCO0VBQUFyQixFQUFBLE1BQUFzQjtDQUFBO0VBQUFBLEtBQUF0QixFQUFBO0NBQUE7Q0FBQSxJQUFBdUI7Q0FBQSxJQUFBdkIsRUFBQSxRQUFBUSxPQUFBO0VBQ0ZlLEtBQUE7R0FBZ0I7YUFBa0NmO0VBQWE7Ozs7O0VBQUFSLEVBQUEsTUFBQVE7RUFBQVIsRUFBQSxNQUFBdUI7Q0FBQTtFQUFBQSxLQUFBdkIsRUFBQTtDQUFBO0NBQUEsSUFBQXdCO0NBQUEsSUFBQXhCLEVBQUEsUUFBQW1CLE1BQUFuQixFQUFBLFFBQUFzQixNQUFBdEIsRUFBQSxRQUFBdUIsSUFBQTtFQTVCakVDLEtBQUEsd0JBQUMsZ0JBQUQ7R0FFSSxRQUFBTDthQUZKLENBcUJFRyxJQU9BQyxFQTVCYTs7Ozs7O0VBNkJFdkIsRUFBQSxNQUFBbUI7RUFBQW5CLEVBQUEsTUFBQXNCO0VBQUF0QixFQUFBLE1BQUF1QjtFQUFBdkIsRUFBQSxNQUFBd0I7Q0FBQTtFQUFBQSxLQUFBeEIsRUFBQTtDQUFBO0NBQUEsSUFBQXlCO0NBQUEsSUFBQXpCLEVBQUEsUUFBQVcsT0FBQTtFQUNqQmMsTUFBQSx3QkFBQyxnQkFBRCxZQUFpQmQsTUFBRjs7Ozs7RUFBeUJYLEVBQUEsTUFBQVc7RUFBQVgsRUFBQSxNQUFBeUI7Q0FBQTtFQUFBQSxNQUFBekIsRUFBQTtDQUFBO0NBQUEsSUFBQTBCO0NBQUEsSUFBQTFCLEVBQUEsUUFBQXlCLE9BQUF6QixFQUFBLFFBQUF3QixJQUFBO0VBL0IxQ0UsTUFBQSx3QkFBQyxTQUFELGFBQ0VGLElBOEJBQyxHQS9CTTs7Ozs7RUFnQ0V6QixFQUFBLE1BQUF5QjtFQUFBekIsRUFBQSxNQUFBd0I7RUFBQXhCLEVBQUEsTUFBQTBCO0NBQUE7RUFBQUEsTUFBQTFCLEVBQUE7Q0FBQTtDQUFBLE9BaENWMEI7QUFnQ1UiLCJuYW1lcyI6WyJIZWFydCIsIkJ1dHRvbiIsIlRvb2x0aXAiLCJUb29sdGlwQ29udGVudCIsIlRvb2x0aXBUcmlnZ2VyIiwidXNlVG9nZ2xlRmF2b3JpdGVORlQiLCJjbiIsIkZhdm9yaXRlQnV0dG9uIiwidDAiLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsIm5mdElkIiwibmZ0TmFtZSIsImlzRmF2b3JpdGVkIiwibGlrZXMiLCJjbGFzc05hbWUiLCJ0b2dnbGVGYXZvcml0ZSIsImxhYmVsIiwidDEiLCJlIiwicHJldmVudERlZmF1bHQiLCJzdG9wUHJvcGFnYXRpb24iLCJtdXRhdGUiLCJ0MiIsInQzIiwidDQiLCJ0NSIsInQ2IiwidDciLCJ0OCIsInQ5IiwidDEwIiwidDExIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImZhdm9yaXRlLWJ1dHRvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSGVhcnQgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuaW1wb3J0IHsgVG9vbHRpcCwgVG9vbHRpcENvbnRlbnQsIFRvb2x0aXBUcmlnZ2VyIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL3Rvb2x0aXAnXG5pbXBvcnQgeyB1c2VUb2dnbGVGYXZvcml0ZU5GVCB9IGZyb20gJ0AvaG9va3MvdXNlLW5mdHMnXG5pbXBvcnQgeyBjbiB9IGZyb20gJ0AvbGliL3V0aWxzJ1xuXG5pbnRlcmZhY2UgRmF2b3JpdGVCdXR0b25Qcm9wcyB7XG4gIG5mdElkOiBzdHJpbmdcbiAgbmZ0TmFtZTogc3RyaW5nXG4gIGlzRmF2b3JpdGVkOiBib29sZWFuXG4gIGxpa2VzOiBudW1iZXJcbiAgY2xhc3NOYW1lPzogc3RyaW5nXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBGYXZvcml0ZUJ1dHRvbih7XG4gIG5mdElkLFxuICBuZnROYW1lLFxuICBpc0Zhdm9yaXRlZCxcbiAgbGlrZXMsXG4gIGNsYXNzTmFtZSxcbn06IEZhdm9yaXRlQnV0dG9uUHJvcHMpIHtcbiAgY29uc3QgdG9nZ2xlRmF2b3JpdGUgPSB1c2VUb2dnbGVGYXZvcml0ZU5GVCgpXG4gIGNvbnN0IGxhYmVsID0gaXNGYXZvcml0ZWQgPyBgUmVtb3ZlciAke25mdE5hbWV9IGRvcyBmYXZvcml0b3NgIDogYEZhdm9yaXRhciAke25mdE5hbWV9YFxuXG4gIHJldHVybiAoXG4gICAgPFRvb2x0aXA+XG4gICAgICA8VG9vbHRpcFRyaWdnZXJcbiAgICAgICAgcmVuZGVyPXtcbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIHZhcmlhbnQ9XCJzZWNvbmRhcnlcIlxuICAgICAgICAgICAgc2l6ZT1cInNtXCJcbiAgICAgICAgICAgIGFyaWEtbGFiZWw9e2xhYmVsfVxuICAgICAgICAgICAgYXJpYS1wcmVzc2VkPXtpc0Zhdm9yaXRlZH1cbiAgICAgICAgICAgIG9uQ2xpY2s9eyhlKSA9PiB7XG4gICAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKVxuICAgICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbigpXG4gICAgICAgICAgICAgIHRvZ2dsZUZhdm9yaXRlLm11dGF0ZShuZnRJZClcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICAgICAgICAnZ2FwLTEuNSByb3VuZGVkLWZ1bGwgYmctYmFja2dyb3VuZC85MCBweC0yLjUgc2hhZG93LXhzIGJhY2tkcm9wLWJsdXItc20gaG92ZXI6YmctYmFja2dyb3VuZCcsXG4gICAgICAgICAgICAgIGlzRmF2b3JpdGVkICYmICd0ZXh0LWRlc3RydWN0aXZlJyxcbiAgICAgICAgICAgICAgY2xhc3NOYW1lLFxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAvPlxuICAgICAgICB9XG4gICAgICA+XG4gICAgICAgIDxIZWFydFxuICAgICAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgICAgICAnc2l6ZS0zLjUgdHJhbnNpdGlvbi10cmFuc2Zvcm0gbW90aW9uLXJlZHVjZTp0cmFuc2l0aW9uLW5vbmUnLFxuICAgICAgICAgICAgaXNGYXZvcml0ZWQgJiYgJ3NjYWxlLTExMCBmaWxsLWN1cnJlbnQnLFxuICAgICAgICAgICl9XG4gICAgICAgICAgYXJpYS1oaWRkZW49XCJ0cnVlXCJcbiAgICAgICAgLz5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1tb25vIHRleHQteHMgdGFidWxhci1udW1zXCI+e2xpa2VzfTwvc3Bhbj5cbiAgICAgIDwvVG9vbHRpcFRyaWdnZXI+XG4gICAgICA8VG9vbHRpcENvbnRlbnQ+e2xhYmVsfTwvVG9vbHRpcENvbnRlbnQ+XG4gICAgPC9Ub29sdGlwPlxuICApXG59XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9jb21wb25lbnRzL25mdC9mYXZvcml0ZS1idXR0b24udHN4In0=