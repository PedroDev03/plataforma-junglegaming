import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/switch.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];"use client";
import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Switch as SwitchPrimitive } from "/node_modules/.vite/deps/@base-ui_react_switch.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/switch.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
function Switch(t0) {
	const $ = _c(12);
	if ($[0] !== "1ed33e8c07e606eb0f9a17b58315a56848bd3cd1768145f3c30a8fceada15e2a") {
		for (let $i = 0; $i < 12; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "1ed33e8c07e606eb0f9a17b58315a56848bd3cd1768145f3c30a8fceada15e2a";
	}
	let className;
	let props;
	let t1;
	if ($[1] !== t0) {
		({className, size: t1, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
		$[4] = t1;
	} else {
		className = $[2];
		props = $[3];
		t1 = $[4];
	}
	const size = t1 === undefined ? "default" : t1;
	let t2;
	if ($[5] !== className) {
		t2 = cn("peer group/switch relative inline-flex shrink-0 items-center rounded-full border border-transparent transition-all outline-none group-has-[:focus-visible]/field-label:border-transparent group-has-[:focus-visible]/field-label:ring-0 after:absolute after:-inset-x-3 after:-inset-y-2 focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 data-[size=default]:h-[18.4px] data-[size=default]:w-[32px] data-[size=sm]:h-[14px] data-[size=sm]:w-[24px] dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 data-checked:bg-primary data-unchecked:bg-input dark:data-unchecked:bg-input/80 data-disabled:cursor-not-allowed data-disabled:opacity-50", className);
		$[5] = className;
		$[6] = t2;
	} else {
		t2 = $[6];
	}
	let t3;
	if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = /* @__PURE__ */ _jsxDEV(SwitchPrimitive.Thumb, {
			"data-slot": "switch-thumb",
			className: "pointer-events-none block rounded-full bg-background ring-0 transition-transform group-data-[size=default]/switch:size-4 group-data-[size=sm]/switch:size-3 group-data-[size=default]/switch:data-checked:translate-x-[calc(100%-2px)] group-data-[size=sm]/switch:data-checked:translate-x-[calc(100%-2px)] dark:data-checked:bg-primary-foreground group-data-[size=default]/switch:data-unchecked:translate-x-0 group-data-[size=sm]/switch:data-unchecked:translate-x-0 dark:data-unchecked:bg-foreground"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 10
		}, this);
		$[7] = t3;
	} else {
		t3 = $[7];
	}
	let t4;
	if ($[8] !== props || $[9] !== size || $[10] !== t2) {
		t4 = /* @__PURE__ */ _jsxDEV(SwitchPrimitive.Root, {
			"data-slot": "switch",
			"data-size": size,
			className: t2,
			...props,
			children: t3
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 10
		}, this);
		$[8] = props;
		$[9] = size;
		$[10] = t2;
		$[11] = t4;
	} else {
		t4 = $[11];
	}
	return t4;
}
_c2 = Switch;
export { Switch };
var _c2;
$RefreshReg$(_c2, "Switch");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/switch.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/switch.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/switch.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/switch.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBQUE7QUFBWSxTQUFBQSxLQUFBQyxVQUFBO0FBRVosU0FBU0MsVUFBVUMsdUJBQXVCO0FBQzFDLFNBQVNDLFVBQVU7OztBQUVuQixTQUFBRixPQUFBRyxJQUFBO0NBQUEsTUFBQUMsSUFBQUwsR0FBQTtDQUFBLElBQUFLLEVBQUE7RUFBQSxTQUFBQyxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRCxFQUFBQyxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUgsRUFBQTtDQUFBO0NBQUEsSUFBQUk7Q0FBQSxJQUFBQztDQUFBLElBQUFDO0NBQUEsSUFBQU4sRUFBQSxPQUFBRCxJQUFBO0VBQWdCLEVBQUFLLFdBQUFHLE1BQUFELElBQUEsR0FBQUQsU0FBQU47RUFNZkMsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFJO0VBQUFKLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtDQUFBO0VBQUFGLFlBQUFKLEVBQUE7RUFBQUssUUFBQUwsRUFBQTtFQUFBTSxLQUFBTixFQUFBO0NBQUE7Q0FKQyxNQUFBTyxPQUFBRCxPQUFBRSxZQUFBLFlBQUFGO0NBQWdCLElBQUFHO0NBQUEsSUFBQVQsRUFBQSxPQUFBSSxXQUFBO0VBU0RLLEtBQUFYLEdBQ1QsK3ZCQUNBTSxTQUNGO0VBQUNKLEVBQUEsS0FBQUk7RUFBQUosRUFBQSxLQUFBUztDQUFBO0VBQUFBLEtBQUFULEVBQUE7Q0FBQTtDQUFBLElBQUFVO0NBQUEsSUFBQVYsRUFBQSxPQUFBRSxPQUFBQyxJQUFBO0VBR0RPLEtBQUE7R0FDWTtHQUNBO0VBQStlOzs7OztFQUN6ZlYsRUFBQSxLQUFBVTtDQUFBO0VBQUFBLEtBQUFWLEVBQUE7Q0FBQTtDQUFBLElBQUFXO0NBQUEsSUFBQVgsRUFBQSxPQUFBSyxTQUFBTCxFQUFBLE9BQUFPLFFBQUFQLEVBQUEsUUFBQVMsSUFBQTtFQVpKRSxLQUFBO0dBQ1k7R0FDQ0o7R0FDQSxXQUFBRTtHQUdWLEdBQ0dKO2FBRUpLO0VBSUY7Ozs7O0VBQXVCVixFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxNQUFBUztFQUFBVCxFQUFBLE1BQUFXO0NBQUE7RUFBQUEsS0FBQVgsRUFBQTtDQUFBO0NBQUEsT0FidkJXO0FBYXVCOztBQUkzQixTQUFTZiIsIm5hbWVzIjpbImMiLCJfYyIsIlN3aXRjaCIsIlN3aXRjaFByaW1pdGl2ZSIsImNuIiwidDAiLCIkIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJjbGFzc05hbWUiLCJwcm9wcyIsInQxIiwic2l6ZSIsInVuZGVmaW5lZCIsInQyIiwidDMiLCJ0NCJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJzd2l0Y2gudHN4Il0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIGNsaWVudFwiXG5cbmltcG9ydCB7IFN3aXRjaCBhcyBTd2l0Y2hQcmltaXRpdmUgfSBmcm9tIFwiQGJhc2UtdWkvcmVhY3Qvc3dpdGNoXCJcbmltcG9ydCB7IGNuIH0gZnJvbSBcImNuXCJcblxuZnVuY3Rpb24gU3dpdGNoKHtcbiAgY2xhc3NOYW1lLFxuICBzaXplID0gXCJkZWZhdWx0XCIsXG4gIC4uLnByb3BzXG59OiBTd2l0Y2hQcmltaXRpdmUuUm9vdC5Qcm9wcyAmIHtcbiAgc2l6ZT86IFwic21cIiB8IFwiZGVmYXVsdFwiXG59KSB7XG4gIHJldHVybiAoXG4gICAgPFN3aXRjaFByaW1pdGl2ZS5Sb290XG4gICAgICBkYXRhLXNsb3Q9XCJzd2l0Y2hcIlxuICAgICAgZGF0YS1zaXplPXtzaXplfVxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJwZWVyIGdyb3VwL3N3aXRjaCByZWxhdGl2ZSBpbmxpbmUtZmxleCBzaHJpbmstMCBpdGVtcy1jZW50ZXIgcm91bmRlZC1mdWxsIGJvcmRlciBib3JkZXItdHJhbnNwYXJlbnQgdHJhbnNpdGlvbi1hbGwgb3V0bGluZS1ub25lIGdyb3VwLWhhcy1bOmZvY3VzLXZpc2libGVdL2ZpZWxkLWxhYmVsOmJvcmRlci10cmFuc3BhcmVudCBncm91cC1oYXMtWzpmb2N1cy12aXNpYmxlXS9maWVsZC1sYWJlbDpyaW5nLTAgYWZ0ZXI6YWJzb2x1dGUgYWZ0ZXI6LWluc2V0LXgtMyBhZnRlcjotaW5zZXQteS0yIGZvY3VzLXZpc2libGU6Ym9yZGVyLXJpbmcgZm9jdXMtdmlzaWJsZTpyaW5nLTMgZm9jdXMtdmlzaWJsZTpyaW5nLXJpbmcvNTAgYXJpYS1pbnZhbGlkOmJvcmRlci1kZXN0cnVjdGl2ZSBhcmlhLWludmFsaWQ6cmluZy0zIGFyaWEtaW52YWxpZDpyaW5nLWRlc3RydWN0aXZlLzIwIGRhdGEtW3NpemU9ZGVmYXVsdF06aC1bMTguNHB4XSBkYXRhLVtzaXplPWRlZmF1bHRdOnctWzMycHhdIGRhdGEtW3NpemU9c21dOmgtWzE0cHhdIGRhdGEtW3NpemU9c21dOnctWzI0cHhdIGRhcms6YXJpYS1pbnZhbGlkOmJvcmRlci1kZXN0cnVjdGl2ZS81MCBkYXJrOmFyaWEtaW52YWxpZDpyaW5nLWRlc3RydWN0aXZlLzQwIGRhdGEtY2hlY2tlZDpiZy1wcmltYXJ5IGRhdGEtdW5jaGVja2VkOmJnLWlucHV0IGRhcms6ZGF0YS11bmNoZWNrZWQ6YmctaW5wdXQvODAgZGF0YS1kaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGF0YS1kaXNhYmxlZDpvcGFjaXR5LTUwXCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8U3dpdGNoUHJpbWl0aXZlLlRodW1iXG4gICAgICAgIGRhdGEtc2xvdD1cInN3aXRjaC10aHVtYlwiXG4gICAgICAgIGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLW5vbmUgYmxvY2sgcm91bmRlZC1mdWxsIGJnLWJhY2tncm91bmQgcmluZy0wIHRyYW5zaXRpb24tdHJhbnNmb3JtIGdyb3VwLWRhdGEtW3NpemU9ZGVmYXVsdF0vc3dpdGNoOnNpemUtNCBncm91cC1kYXRhLVtzaXplPXNtXS9zd2l0Y2g6c2l6ZS0zIGdyb3VwLWRhdGEtW3NpemU9ZGVmYXVsdF0vc3dpdGNoOmRhdGEtY2hlY2tlZDp0cmFuc2xhdGUteC1bY2FsYygxMDAlLTJweCldIGdyb3VwLWRhdGEtW3NpemU9c21dL3N3aXRjaDpkYXRhLWNoZWNrZWQ6dHJhbnNsYXRlLXgtW2NhbGMoMTAwJS0ycHgpXSBkYXJrOmRhdGEtY2hlY2tlZDpiZy1wcmltYXJ5LWZvcmVncm91bmQgZ3JvdXAtZGF0YS1bc2l6ZT1kZWZhdWx0XS9zd2l0Y2g6ZGF0YS11bmNoZWNrZWQ6dHJhbnNsYXRlLXgtMCBncm91cC1kYXRhLVtzaXplPXNtXS9zd2l0Y2g6ZGF0YS11bmNoZWNrZWQ6dHJhbnNsYXRlLXgtMCBkYXJrOmRhdGEtdW5jaGVja2VkOmJnLWZvcmVncm91bmRcIlxuICAgICAgLz5cbiAgICA8L1N3aXRjaFByaW1pdGl2ZS5Sb290PlxuICApXG59XG5cbmV4cG9ydCB7IFN3aXRjaCB9XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9jb21wb25lbnRzL3VpL3N3aXRjaC50c3gifQ==