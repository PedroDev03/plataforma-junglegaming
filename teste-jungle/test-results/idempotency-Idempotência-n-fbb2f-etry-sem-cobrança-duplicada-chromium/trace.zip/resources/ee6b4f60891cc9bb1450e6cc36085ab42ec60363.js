import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/nft/nft-pagination.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { ChevronLeft, ChevronRight } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { Button } from "/src/components/ui/button.tsx";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-pagination.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
export function NftPagination(t0) {
	const $ = _c(38);
	if ($[0] !== "acc40670ad277d362eea367f2c7c5a417c54a1bc7317d08eb6d9717f5b3e579e") {
		for (let $i = 0; $i < 38; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "acc40670ad277d362eea367f2c7c5a417c54a1bc7317d08eb6d9717f5b3e579e";
	}
	const { page, totalPages, totalItems, onPageChange } = t0;
	if (totalPages <= 1) {
		return null;
	}
	let t1;
	if ($[1] !== totalPages) {
		t1 = Array.from({ length: totalPages }, _temp);
		$[1] = totalPages;
		$[2] = t1;
	} else {
		t1 = $[2];
	}
	const pages = t1;
	let t2;
	if ($[3] !== page) {
		t2 = /* @__PURE__ */ _jsxDEV("span", {
			className: "font-semibold text-foreground",
			children: page
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 40,
			columnNumber: 10
		}, this);
		$[3] = page;
		$[4] = t2;
	} else {
		t2 = $[4];
	}
	let t3;
	if ($[5] !== totalPages) {
		t3 = /* @__PURE__ */ _jsxDEV("span", {
			className: "font-semibold text-foreground",
			children: totalPages
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 10
		}, this);
		$[5] = totalPages;
		$[6] = t3;
	} else {
		t3 = $[6];
	}
	let t4;
	if ($[7] !== t2 || $[8] !== t3 || $[9] !== totalItems) {
		t4 = /* @__PURE__ */ _jsxDEV("p", {
			className: "text-xs text-muted-foreground",
			children: [
				"Página ",
				t2,
				" de",
				" ",
				t3,
				" (",
				totalItems,
				" NFTs)"
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 10
		}, this);
		$[7] = t2;
		$[8] = t3;
		$[9] = totalItems;
		$[10] = t4;
	} else {
		t4 = $[10];
	}
	const t5 = page <= 1;
	let t6;
	if ($[11] !== onPageChange || $[12] !== page) {
		t6 = () => onPageChange(page - 1);
		$[11] = onPageChange;
		$[12] = page;
		$[13] = t6;
	} else {
		t6 = $[13];
	}
	let t7;
	let t8;
	if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = /* @__PURE__ */ _jsxDEV(ChevronLeft, {
			className: "size-4",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 77,
			columnNumber: 10
		}, this);
		t8 = /* @__PURE__ */ _jsxDEV("span", {
			className: "hidden sm:inline",
			children: "Anterior"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 78,
			columnNumber: 10
		}, this);
		$[14] = t7;
		$[15] = t8;
	} else {
		t7 = $[14];
		t8 = $[15];
	}
	let t9;
	if ($[16] !== t5 || $[17] !== t6) {
		t9 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			variant: "outline",
			size: "sm",
			disabled: t5,
			"aria-label": "Página anterior",
			onClick: t6,
			children: [t7, t8]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 87,
			columnNumber: 10
		}, this);
		$[16] = t5;
		$[17] = t6;
		$[18] = t9;
	} else {
		t9 = $[18];
	}
	let t10;
	if ($[19] !== onPageChange || $[20] !== page || $[21] !== pages) {
		t10 = pages.map((pageNumber) => {
			const isCurrent = pageNumber === page;
			return /* @__PURE__ */ _jsxDEV(Button, {
				type: "button",
				variant: isCurrent ? "default" : "outline",
				size: "sm",
				"aria-label": `Ir para a página ${pageNumber}`,
				"aria-current": isCurrent ? "page" : undefined,
				onClick: () => onPageChange(pageNumber),
				className: "min-w-8 tabular-nums",
				children: pageNumber
			}, pageNumber, false, {
				fileName: _jsxFileName,
				lineNumber: 98,
				columnNumber: 14
			}, this);
		});
		$[19] = onPageChange;
		$[20] = page;
		$[21] = pages;
		$[22] = t10;
	} else {
		t10 = $[22];
	}
	const t11 = page >= totalPages;
	let t12;
	if ($[23] !== onPageChange || $[24] !== page) {
		t12 = () => onPageChange(page + 1);
		$[23] = onPageChange;
		$[24] = page;
		$[25] = t12;
	} else {
		t12 = $[25];
	}
	let t13;
	let t14;
	if ($[26] === Symbol.for("react.memo_cache_sentinel")) {
		t13 = /* @__PURE__ */ _jsxDEV("span", {
			className: "hidden sm:inline",
			children: "Próxima"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 120,
			columnNumber: 11
		}, this);
		t14 = /* @__PURE__ */ _jsxDEV(ChevronRight, {
			className: "size-4",
			"aria-hidden": "true"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 121,
			columnNumber: 11
		}, this);
		$[26] = t13;
		$[27] = t14;
	} else {
		t13 = $[26];
		t14 = $[27];
	}
	let t15;
	if ($[28] !== t11 || $[29] !== t12) {
		t15 = /* @__PURE__ */ _jsxDEV(Button, {
			type: "button",
			variant: "outline",
			size: "sm",
			disabled: t11,
			"aria-label": "Próxima página",
			onClick: t12,
			children: [t13, t14]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 130,
			columnNumber: 11
		}, this);
		$[28] = t11;
		$[29] = t12;
		$[30] = t15;
	} else {
		t15 = $[30];
	}
	let t16;
	if ($[31] !== t10 || $[32] !== t15 || $[33] !== t9) {
		t16 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-1.5",
			children: [
				t9,
				t10,
				t15
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 139,
			columnNumber: 11
		}, this);
		$[31] = t10;
		$[32] = t15;
		$[33] = t9;
		$[34] = t16;
	} else {
		t16 = $[34];
	}
	let t17;
	if ($[35] !== t16 || $[36] !== t4) {
		t17 = /* @__PURE__ */ _jsxDEV("nav", {
			"aria-label": "Paginação do catálogo",
			className: "flex flex-wrap items-center justify-between gap-4 border-t pt-6",
			children: [t4, t16]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 149,
			columnNumber: 11
		}, this);
		$[35] = t16;
		$[36] = t4;
		$[37] = t17;
	} else {
		t17 = $[37];
	}
	return t17;
}
_c2 = NftPagination;
function _temp(_, index) {
	return index + 1;
}
var _c2;
$RefreshReg$(_c2, "NftPagination");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/nft/nft-pagination.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-pagination.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-pagination.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/nft/nft-pagination.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGFBQWFDLG9CQUFvQjtBQUMxQyxTQUFTQyxjQUFjOzs7QUFTdkIsT0FBTyxTQUFBQyxjQUFBQyxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQXVCLFFBQUFLLE1BQUFDLFlBQUFDLFlBQUFDLGlCQUFBVDtDQU01QixJQUFJTyxjQUFjLEdBQUM7RUFBQSxPQUFTO0NBQUk7Q0FBQSxJQUFBRztDQUFBLElBQUFULEVBQUEsT0FBQU0sWUFBQTtFQUVsQkcsS0FBQUMsTUFBS0MsS0FBTSxFQUFBQyxRQUFVTixXQUFXLEdBQUdPLEtBQXVCO0VBQUNiLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBUztDQUFBO0VBQUFBLEtBQUFULEVBQUE7Q0FBQTtDQUF6RSxNQUFBYyxRQUFjTDtDQUEyRCxJQUFBTTtDQUFBLElBQUFmLEVBQUEsT0FBQUssTUFBQTtFQVE1RFUsS0FBQTtHQUFnQjthQUFpQ1Y7RUFBWTs7Ozs7RUFBQUwsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFlO0NBQUE7RUFBQUEsS0FBQWYsRUFBQTtDQUFBO0NBQUEsSUFBQWdCO0NBQUEsSUFBQWhCLEVBQUEsT0FBQU0sWUFBQTtFQUNwRVUsS0FBQTtHQUFnQjthQUFpQ1Y7RUFBa0I7Ozs7O0VBQUFOLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBZ0I7Q0FBQTtFQUFBQSxLQUFBaEIsRUFBQTtDQUFBO0NBQUEsSUFBQWlCO0NBQUEsSUFBQWpCLEVBQUEsT0FBQWUsTUFBQWYsRUFBQSxPQUFBZ0IsTUFBQWhCLEVBQUEsT0FBQU8sWUFBQTtFQUZyRVUsS0FBQTtHQUFhO2FBQWI7SUFBNkM7SUFDcENGO0lBQTZEO0lBQUk7SUFDeEVDO0lBQW1FO0lBQUdUO0lBQVc7R0FDL0U7Ozs7OztFQUFBUCxFQUFBLEtBQUFlO0VBQUFmLEVBQUEsS0FBQWdCO0VBQUFoQixFQUFBLEtBQUFPO0VBQUFQLEVBQUEsTUFBQWlCO0NBQUE7RUFBQUEsS0FBQWpCLEVBQUE7Q0FBQTtDQU9VLE1BQUFrQixLQUFBYixRQUFRO0NBQUMsSUFBQWM7Q0FBQSxJQUFBbkIsRUFBQSxRQUFBUSxnQkFBQVIsRUFBQSxRQUFBSyxNQUFBO0VBRVZjLFdBQU1YLGFBQWFILE9BQU8sQ0FBQztFQUFDTCxFQUFBLE1BQUFRO0VBQUFSLEVBQUEsTUFBQUs7RUFBQUwsRUFBQSxNQUFBbUI7Q0FBQTtFQUFBQSxLQUFBbkIsRUFBQTtDQUFBO0NBQUEsSUFBQW9CO0NBQUEsSUFBQUM7Q0FBQSxJQUFBckIsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBRXJDZ0IsS0FBQSx3QkFBQyxhQUFEO0dBQXVCO0dBQXFCO0VBQU07Ozs7O0VBQ2xEQyxLQUFBO0dBQWdCO2FBQW1CO0VBQWU7Ozs7O0VBQUFyQixFQUFBLE1BQUFvQjtFQUFBcEIsRUFBQSxNQUFBcUI7Q0FBQTtFQUFBRCxLQUFBcEIsRUFBQTtFQUFBcUIsS0FBQXJCLEVBQUE7Q0FBQTtDQUFBLElBQUFzQjtDQUFBLElBQUF0QixFQUFBLFFBQUFrQixNQUFBbEIsRUFBQSxRQUFBbUIsSUFBQTtFQVRwREcsS0FBQSx3QkFBQyxRQUFEO0dBQ087R0FDRztHQUNIO0dBQ0ssVUFBQUo7R0FDQztHQUNGLFNBQUFDO2FBTlgsQ0FRRUMsSUFDQUMsRUFUSzs7Ozs7O0VBVUVyQixFQUFBLE1BQUFrQjtFQUFBbEIsRUFBQSxNQUFBbUI7RUFBQW5CLEVBQUEsTUFBQXNCO0NBQUE7RUFBQUEsS0FBQXRCLEVBQUE7Q0FBQTtDQUFBLElBQUF1QjtDQUFBLElBQUF2QixFQUFBLFFBQUFRLGdCQUFBUixFQUFBLFFBQUFLLFFBQUFMLEVBQUEsUUFBQWMsT0FBQTtFQUVSUyxNQUFBVCxNQUFLVSxLQUFLQyxlQUFBO0dBQ1QsTUFBQUMsWUFBa0JELGVBQWVwQjtHQUFJLE9BRW5DLHdCQUFDLFFBQUQ7SUFFTztJQUNJLFNBQUFxQixZQUFBO0lBQ0o7SUFDTyxrQ0FBb0JEO0lBQ2xCLGdCQUFBQyxZQUFBLFNBQUFDO0lBQ0wsZUFBTW5CLGFBQWFpQixVQUFVO0lBQzVCO2NBRVRBO0dBVkksR0FDQUE7Ozs7VUFEQTtFQVdFLENBRVo7RUFBQ3pCLEVBQUEsTUFBQVE7RUFBQVIsRUFBQSxNQUFBSztFQUFBTCxFQUFBLE1BQUFjO0VBQUFkLEVBQUEsTUFBQXVCO0NBQUE7RUFBQUEsTUFBQXZCLEVBQUE7Q0FBQTtDQU1VLE1BQUE0QixNQUFBdkIsUUFBUUM7Q0FBVSxJQUFBdUI7Q0FBQSxJQUFBN0IsRUFBQSxRQUFBUSxnQkFBQVIsRUFBQSxRQUFBSyxNQUFBO0VBRW5Cd0IsWUFBTXJCLGFBQWFILE9BQU8sQ0FBQztFQUFDTCxFQUFBLE1BQUFRO0VBQUFSLEVBQUEsTUFBQUs7RUFBQUwsRUFBQSxNQUFBNkI7Q0FBQTtFQUFBQSxNQUFBN0IsRUFBQTtDQUFBO0NBQUEsSUFBQThCO0NBQUEsSUFBQUM7Q0FBQSxJQUFBL0IsRUFBQSxRQUFBRyxPQUFBQyxJQUFBO0VBRXJDMEIsTUFBQTtHQUFnQjthQUFtQjtFQUFjOzs7OztFQUNqREMsTUFBQSx3QkFBQyxjQUFEO0dBQXdCO0dBQXFCO0VBQU07Ozs7O0VBQUcvQixFQUFBLE1BQUE4QjtFQUFBOUIsRUFBQSxNQUFBK0I7Q0FBQTtFQUFBRCxNQUFBOUIsRUFBQTtFQUFBK0IsTUFBQS9CLEVBQUE7Q0FBQTtDQUFBLElBQUFnQztDQUFBLElBQUFoQyxFQUFBLFFBQUE0QixPQUFBNUIsRUFBQSxRQUFBNkIsS0FBQTtFQVR4REcsTUFBQSx3QkFBQyxRQUFEO0dBQ087R0FDRztHQUNIO0dBQ0ssVUFBQUo7R0FDQztHQUNGLFNBQUFDO2FBTlgsQ0FRRUMsS0FDQUMsR0FUSzs7Ozs7O0VBVUUvQixFQUFBLE1BQUE0QjtFQUFBNUIsRUFBQSxNQUFBNkI7RUFBQTdCLEVBQUEsTUFBQWdDO0NBQUE7RUFBQUEsTUFBQWhDLEVBQUE7Q0FBQTtDQUFBLElBQUFpQztDQUFBLElBQUFqQyxFQUFBLFFBQUF1QixPQUFBdkIsRUFBQSxRQUFBZ0MsT0FBQWhDLEVBQUEsUUFBQXNCLElBQUE7RUF6Q1hXLE1BQUE7R0FBZTthQUFmO0lBQ0VYO0lBWUNDO0lBa0JEUztHQVdJOzs7Ozs7RUFBQWhDLEVBQUEsTUFBQXVCO0VBQUF2QixFQUFBLE1BQUFnQztFQUFBaEMsRUFBQSxNQUFBc0I7RUFBQXRCLEVBQUEsTUFBQWlDO0NBQUE7RUFBQUEsTUFBQWpDLEVBQUE7Q0FBQTtDQUFBLElBQUFrQztDQUFBLElBQUFsQyxFQUFBLFFBQUFpQyxPQUFBakMsRUFBQSxRQUFBaUIsSUFBQTtFQW5EUmlCLE1BQUE7R0FDYTtHQUNEO2FBRlosQ0FJRWpCLElBS0FnQixHQTJDSTs7Ozs7O0VBQUFqQyxFQUFBLE1BQUFpQztFQUFBakMsRUFBQSxNQUFBaUI7RUFBQWpCLEVBQUEsTUFBQWtDO0NBQUE7RUFBQUEsTUFBQWxDLEVBQUE7Q0FBQTtDQUFBLE9BcEROa0M7QUFvRE07O0FBL0RILFNBQUFyQixNQUFBc0IsR0FBQUMsT0FBQTtDQUFBLE9BUTBEQSxRQUFRO0FBQUMiLCJuYW1lcyI6WyJDaGV2cm9uTGVmdCIsIkNoZXZyb25SaWdodCIsIkJ1dHRvbiIsIk5mdFBhZ2luYXRpb24iLCJ0MCIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwicGFnZSIsInRvdGFsUGFnZXMiLCJ0b3RhbEl0ZW1zIiwib25QYWdlQ2hhbmdlIiwidDEiLCJBcnJheSIsImZyb20iLCJsZW5ndGgiLCJfdGVtcCIsInBhZ2VzIiwidDIiLCJ0MyIsInQ0IiwidDUiLCJ0NiIsInQ3IiwidDgiLCJ0OSIsInQxMCIsIm1hcCIsInBhZ2VOdW1iZXIiLCJpc0N1cnJlbnQiLCJ1bmRlZmluZWQiLCJ0MTEiLCJ0MTIiLCJ0MTMiLCJ0MTQiLCJ0MTUiLCJ0MTYiLCJ0MTciLCJfIiwiaW5kZXgiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZXMiOlsibmZ0LXBhZ2luYXRpb24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENoZXZyb25MZWZ0LCBDaGV2cm9uUmlnaHQgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBCdXR0b24gfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYnV0dG9uJ1xuXG5pbnRlcmZhY2UgTmZ0UGFnaW5hdGlvblByb3BzIHtcbiAgcGFnZTogbnVtYmVyXG4gIHRvdGFsUGFnZXM6IG51bWJlclxuICB0b3RhbEl0ZW1zOiBudW1iZXJcbiAgb25QYWdlQ2hhbmdlOiAobmV4dFBhZ2U6IG51bWJlcikgPT4gdm9pZFxufVxuXG5leHBvcnQgZnVuY3Rpb24gTmZ0UGFnaW5hdGlvbih7XG4gIHBhZ2UsXG4gIHRvdGFsUGFnZXMsXG4gIHRvdGFsSXRlbXMsXG4gIG9uUGFnZUNoYW5nZSxcbn06IE5mdFBhZ2luYXRpb25Qcm9wcykge1xuICBpZiAodG90YWxQYWdlcyA8PSAxKSByZXR1cm4gbnVsbFxuXG4gIGNvbnN0IHBhZ2VzID0gQXJyYXkuZnJvbSh7IGxlbmd0aDogdG90YWxQYWdlcyB9LCAoXywgaW5kZXgpID0+IGluZGV4ICsgMSlcblxuICByZXR1cm4gKFxuICAgIDxuYXZcbiAgICAgIGFyaWEtbGFiZWw9XCJQYWdpbmHDp8OjbyBkbyBjYXTDoWxvZ29cIlxuICAgICAgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtNCBib3JkZXItdCBwdC02XCJcbiAgICA+XG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiPlxuICAgICAgICBQw6FnaW5hIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+e3BhZ2V9PC9zcGFuPiBkZXsnICd9XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGQgdGV4dC1mb3JlZ3JvdW5kXCI+e3RvdGFsUGFnZXN9PC9zcGFuPiAoe3RvdGFsSXRlbXN9IE5GVHMpXG4gICAgICA8L3A+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiPlxuICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UgPD0gMX1cbiAgICAgICAgICBhcmlhLWxhYmVsPVwiUMOhZ2luYSBhbnRlcmlvclwiXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb25QYWdlQ2hhbmdlKHBhZ2UgLSAxKX1cbiAgICAgICAgPlxuICAgICAgICAgIDxDaGV2cm9uTGVmdCBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImhpZGRlbiBzbTppbmxpbmVcIj5BbnRlcmlvcjwvc3Bhbj5cbiAgICAgICAgPC9CdXR0b24+XG5cbiAgICAgICAge3BhZ2VzLm1hcCgocGFnZU51bWJlcikgPT4ge1xuICAgICAgICAgIGNvbnN0IGlzQ3VycmVudCA9IHBhZ2VOdW1iZXIgPT09IHBhZ2VcbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICBrZXk9e3BhZ2VOdW1iZXJ9XG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgICAgICB2YXJpYW50PXtpc0N1cnJlbnQgPyAnZGVmYXVsdCcgOiAnb3V0bGluZSd9XG4gICAgICAgICAgICAgIHNpemU9XCJzbVwiXG4gICAgICAgICAgICAgIGFyaWEtbGFiZWw9e2BJciBwYXJhIGEgcMOhZ2luYSAke3BhZ2VOdW1iZXJ9YH1cbiAgICAgICAgICAgICAgYXJpYS1jdXJyZW50PXtpc0N1cnJlbnQgPyAncGFnZScgOiB1bmRlZmluZWR9XG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uUGFnZUNoYW5nZShwYWdlTnVtYmVyKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibWluLXctOCB0YWJ1bGFyLW51bXNcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7cGFnZU51bWJlcn1cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIClcbiAgICAgICAgfSl9XG5cbiAgICAgICAgPEJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lXCJcbiAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgIGRpc2FibGVkPXtwYWdlID49IHRvdGFsUGFnZXN9XG4gICAgICAgICAgYXJpYS1sYWJlbD1cIlByw7N4aW1hIHDDoWdpbmFcIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uUGFnZUNoYW5nZShwYWdlICsgMSl9XG4gICAgICAgID5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206aW5saW5lXCI+UHLDs3hpbWE8L3NwYW4+XG4gICAgICAgICAgPENoZXZyb25SaWdodCBjbGFzc05hbWU9XCJzaXplLTRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvbmF2PlxuICApXG59XG4iXSwiZmlsZSI6IkU6L0Rvd25sb2Fkcy90ZXN0ZS1qdW5nbGUvdGVzdGUtanVuZ2xlL3NyYy9jb21wb25lbnRzL25mdC9uZnQtcGFnaW5hdGlvbi50c3gifQ==