import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ui/select.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const React = ((m, n) => n || !m?.__esModule ? {	...typeof m === "object" && !Array.isArray(m) || typeof m === "function" ? m : {},	default: m} : m)(__vite__cjsImport1_react, 1);const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=e9f94b2e";
import { Select as SelectPrimitive } from "/node_modules/.vite/deps/@base-ui_react_select.js?v=e9f94b2e";
import { cn } from "/node_modules/.vite/deps/cn.js?v=e9f94b2e";
import { ChevronDownIcon, CheckIcon, ChevronUpIcon } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/select.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
const Select = SelectPrimitive.Root;
function SelectGroup(t0) {
	const $ = _c(9);
	if ($[0] !== "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("scroll-my-1 p-1", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(SelectPrimitive.Group, {
			"data-slot": "select-group",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c2 = SelectGroup;
function SelectValue(t0) {
	const $ = _c(9);
	if ($[0] !== "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("flex flex-1 text-left", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(SelectPrimitive.Value, {
			"data-slot": "select-value",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c3 = SelectValue;
function SelectTrigger(t0) {
	const $ = _c(14);
	if ($[0] !== "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f") {
		for (let $i = 0; $i < 14; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f";
	}
	let children;
	let className;
	let props;
	let t1;
	if ($[1] !== t0) {
		({className, size: t1, children, ...props} = t0);
		$[1] = t0;
		$[2] = children;
		$[3] = className;
		$[4] = props;
		$[5] = t1;
	} else {
		children = $[2];
		className = $[3];
		props = $[4];
		t1 = $[5];
	}
	const size = t1 === undefined ? "default" : t1;
	let t2;
	if ($[6] !== className) {
		t2 = cn("flex w-fit items-center justify-between gap-1.5 rounded-lg border border-input bg-transparent py-2 pr-2 pl-2.5 text-sm whitespace-nowrap transition-colors outline-none select-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 data-placeholder:text-muted-foreground data-[size=default]:h-8 data-[size=sm]:h-7 data-[size=sm]:rounded-[min(var(--radius-md),10px)] *:data-[slot=select-value]:line-clamp-1 *:data-[slot=select-value]:flex *:data-[slot=select-value]:items-center *:data-[slot=select-value]:gap-1.5 dark:bg-input/30 dark:hover:bg-input/50 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", className);
		$[6] = className;
		$[7] = t2;
	} else {
		t2 = $[7];
	}
	let t3;
	if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = /* @__PURE__ */ _jsxDEV(SelectPrimitive.Icon, { render: /* @__PURE__ */ _jsxDEV(ChevronDownIcon, { className: "pointer-events-none size-4 text-muted-foreground" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 130,
			columnNumber: 40
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 130,
			columnNumber: 10
		}, this);
		$[8] = t3;
	} else {
		t3 = $[8];
	}
	let t4;
	if ($[9] !== children || $[10] !== props || $[11] !== size || $[12] !== t2) {
		t4 = /* @__PURE__ */ _jsxDEV(SelectPrimitive.Trigger, {
			"data-slot": "select-trigger",
			"data-size": size,
			className: t2,
			...props,
			children: [children, t3]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 137,
			columnNumber: 10
		}, this);
		$[9] = children;
		$[10] = props;
		$[11] = size;
		$[12] = t2;
		$[13] = t4;
	} else {
		t4 = $[13];
	}
	return t4;
}
_c4 = SelectTrigger;
function SelectContent(t0) {
	const $ = _c(28);
	if ($[0] !== "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f") {
		for (let $i = 0; $i < 28; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f";
	}
	let children;
	let className;
	let props;
	let t1;
	let t2;
	let t3;
	let t4;
	let t5;
	if ($[1] !== t0) {
		({className, children, side: t1, sideOffset: t2, align: t3, alignOffset: t4, alignItemWithTrigger: t5, ...props} = t0);
		$[1] = t0;
		$[2] = children;
		$[3] = className;
		$[4] = props;
		$[5] = t1;
		$[6] = t2;
		$[7] = t3;
		$[8] = t4;
		$[9] = t5;
	} else {
		children = $[2];
		className = $[3];
		props = $[4];
		t1 = $[5];
		t2 = $[6];
		t3 = $[7];
		t4 = $[8];
		t5 = $[9];
	}
	const side = t1 === undefined ? "bottom" : t1;
	const sideOffset = t2 === undefined ? 4 : t2;
	const align = t3 === undefined ? "center" : t3;
	const alignOffset = t4 === undefined ? 0 : t4;
	const alignItemWithTrigger = t5 === undefined ? true : t5;
	let t6;
	if ($[10] !== className) {
		t6 = cn("relative isolate z-50 max-h-(--available-height) w-(--anchor-width) min-w-36 origin-(--transform-origin) overflow-x-hidden overflow-y-auto rounded-lg bg-popover text-popover-foreground shadow-md ring-1 ring-foreground/10 duration-100 data-[align-trigger=true]:animate-none data-[side=bottom]:slide-in-from-top-2 data-[side=inline-end]:slide-in-from-left-2 data-[side=inline-start]:slide-in-from-right-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 data-open:animate-in data-open:fade-in-0 data-open:zoom-in-95 data-closed:animate-out data-closed:fade-out-0 data-closed:zoom-out-95", className);
		$[10] = className;
		$[11] = t6;
	} else {
		t6 = $[11];
	}
	let t7;
	if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
		t7 = /* @__PURE__ */ _jsxDEV(SelectScrollUpButton, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 209,
			columnNumber: 10
		}, this);
		$[12] = t7;
	} else {
		t7 = $[12];
	}
	let t8;
	if ($[13] !== children) {
		t8 = /* @__PURE__ */ _jsxDEV(SelectPrimitive.List, { children }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 216,
			columnNumber: 10
		}, this);
		$[13] = children;
		$[14] = t8;
	} else {
		t8 = $[14];
	}
	let t9;
	if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
		t9 = /* @__PURE__ */ _jsxDEV(SelectScrollDownButton, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 224,
			columnNumber: 10
		}, this);
		$[15] = t9;
	} else {
		t9 = $[15];
	}
	let t10;
	if ($[16] !== alignItemWithTrigger || $[17] !== props || $[18] !== t6 || $[19] !== t8) {
		t10 = /* @__PURE__ */ _jsxDEV(SelectPrimitive.Popup, {
			"data-slot": "select-content",
			"data-align-trigger": alignItemWithTrigger,
			className: t6,
			...props,
			children: [
				t7,
				t8,
				t9
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 231,
			columnNumber: 11
		}, this);
		$[16] = alignItemWithTrigger;
		$[17] = props;
		$[18] = t6;
		$[19] = t8;
		$[20] = t10;
	} else {
		t10 = $[20];
	}
	let t11;
	if ($[21] !== align || $[22] !== alignItemWithTrigger || $[23] !== alignOffset || $[24] !== side || $[25] !== sideOffset || $[26] !== t10) {
		t11 = /* @__PURE__ */ _jsxDEV(SelectPrimitive.Portal, { children: /* @__PURE__ */ _jsxDEV(SelectPrimitive.Positioner, {
			side,
			sideOffset,
			align,
			alignOffset,
			alignItemWithTrigger,
			className: "isolate z-50",
			children: t10
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 242,
			columnNumber: 35
		}, this) }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 242,
			columnNumber: 11
		}, this);
		$[21] = align;
		$[22] = alignItemWithTrigger;
		$[23] = alignOffset;
		$[24] = side;
		$[25] = sideOffset;
		$[26] = t10;
		$[27] = t11;
	} else {
		t11 = $[27];
	}
	return t11;
}
_c5 = SelectContent;
function SelectLabel(t0) {
	const $ = _c(9);
	if ($[0] !== "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("px-1.5 py-1 text-xs text-muted-foreground", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(SelectPrimitive.GroupLabel, {
			"data-slot": "select-label",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 287,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c6 = SelectLabel;
function SelectItem(t0) {
	const $ = _c(14);
	if ($[0] !== "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f") {
		for (let $i = 0; $i < 14; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f";
	}
	let children;
	let className;
	let props;
	if ($[1] !== t0) {
		({className, children, ...props} = t0);
		$[1] = t0;
		$[2] = children;
		$[3] = className;
		$[4] = props;
	} else {
		children = $[2];
		className = $[3];
		props = $[4];
	}
	let t1;
	if ($[5] !== className) {
		t1 = cn("relative flex w-full cursor-default items-center gap-1.5 rounded-md py-1 pr-8 pl-1.5 text-sm outline-hidden select-none focus:bg-accent focus:text-accent-foreground not-data-[variant=destructive]:focus:**:text-accent-foreground data-disabled:pointer-events-none data-disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 *:[span]:last:flex *:[span]:last:items-center *:[span]:last:gap-2", className);
		$[5] = className;
		$[6] = t1;
	} else {
		t1 = $[6];
	}
	let t2;
	if ($[7] !== children) {
		t2 = /* @__PURE__ */ _jsxDEV(SelectPrimitive.ItemText, {
			className: "flex flex-1 shrink-0 gap-2 whitespace-nowrap",
			children
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 332,
			columnNumber: 10
		}, this);
		$[7] = children;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	let t3;
	if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = /* @__PURE__ */ _jsxDEV(SelectPrimitive.ItemIndicator, {
			render: /* @__PURE__ */ _jsxDEV("span", { className: "pointer-events-none absolute right-2 flex size-4 items-center justify-center" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 340,
				columnNumber: 49
			}, this),
			children: /* @__PURE__ */ _jsxDEV(CheckIcon, { className: "pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 340,
				columnNumber: 148
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 340,
			columnNumber: 10
		}, this);
		$[9] = t3;
	} else {
		t3 = $[9];
	}
	let t4;
	if ($[10] !== props || $[11] !== t1 || $[12] !== t2) {
		t4 = /* @__PURE__ */ _jsxDEV(SelectPrimitive.Item, {
			"data-slot": "select-item",
			className: t1,
			...props,
			children: [t2, t3]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 347,
			columnNumber: 10
		}, this);
		$[10] = props;
		$[11] = t1;
		$[12] = t2;
		$[13] = t4;
	} else {
		t4 = $[13];
	}
	return t4;
}
_c7 = SelectItem;
function SelectSeparator(t0) {
	const $ = _c(9);
	if ($[0] !== "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f") {
		for (let $i = 0; $i < 9; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("pointer-events-none -mx-1 my-1 h-px bg-border", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] !== props || $[7] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV(SelectPrimitive.Separator, {
			"data-slot": "select-separator",
			className: t1,
			...props
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 389,
			columnNumber: 10
		}, this);
		$[6] = props;
		$[7] = t1;
		$[8] = t2;
	} else {
		t2 = $[8];
	}
	return t2;
}
_c8 = SelectSeparator;
function SelectScrollUpButton(t0) {
	const $ = _c(10);
	if ($[0] !== "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f") {
		for (let $i = 0; $i < 10; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("top-0 z-10 flex w-full cursor-default items-center justify-center bg-popover py-1 [&_svg:not([class*='size-'])]:size-4", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV(ChevronUpIcon, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 430,
			columnNumber: 10
		}, this);
		$[6] = t2;
	} else {
		t2 = $[6];
	}
	let t3;
	if ($[7] !== props || $[8] !== t1) {
		t3 = /* @__PURE__ */ _jsxDEV(SelectPrimitive.ScrollUpArrow, {
			"data-slot": "select-scroll-up-button",
			className: t1,
			...props,
			children: t2
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 437,
			columnNumber: 10
		}, this);
		$[7] = props;
		$[8] = t1;
		$[9] = t3;
	} else {
		t3 = $[9];
	}
	return t3;
}
_c9 = SelectScrollUpButton;
function SelectScrollDownButton(t0) {
	const $ = _c(10);
	if ($[0] !== "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f") {
		for (let $i = 0; $i < 10; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "3943c9211cf1386a39cf20d3c18b26ea8fd5560c4e56aeff341d9906031f1a8f";
	}
	let className;
	let props;
	if ($[1] !== t0) {
		({className, ...props} = t0);
		$[1] = t0;
		$[2] = className;
		$[3] = props;
	} else {
		className = $[2];
		props = $[3];
	}
	let t1;
	if ($[4] !== className) {
		t1 = cn("bottom-0 z-10 flex w-full cursor-default items-center justify-center bg-popover py-1 [&_svg:not([class*='size-'])]:size-4", className);
		$[4] = className;
		$[5] = t1;
	} else {
		t1 = $[5];
	}
	let t2;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t2 = /* @__PURE__ */ _jsxDEV(ChevronDownIcon, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 478,
			columnNumber: 10
		}, this);
		$[6] = t2;
	} else {
		t2 = $[6];
	}
	let t3;
	if ($[7] !== props || $[8] !== t1) {
		t3 = /* @__PURE__ */ _jsxDEV(SelectPrimitive.ScrollDownArrow, {
			"data-slot": "select-scroll-down-button",
			className: t1,
			...props,
			children: t2
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 485,
			columnNumber: 10
		}, this);
		$[7] = props;
		$[8] = t1;
		$[9] = t3;
	} else {
		t3 = $[9];
	}
	return t3;
}
_c10 = SelectScrollDownButton;
export { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectScrollDownButton, SelectScrollUpButton, SelectSeparator, SelectTrigger, SelectValue };
var _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10;
$RefreshReg$(_c2, "SelectGroup");
$RefreshReg$(_c3, "SelectValue");
$RefreshReg$(_c4, "SelectTrigger");
$RefreshReg$(_c5, "SelectContent");
$RefreshReg$(_c6, "SelectLabel");
$RefreshReg$(_c7, "SelectItem");
$RefreshReg$(_c8, "SelectSeparator");
$RefreshReg$(_c9, "SelectScrollUpButton");
$RefreshReg$(_c10, "SelectScrollDownButton");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ui/select.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/select.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/ui/select.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/ui/select.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFlBQVlBLFdBQVc7QUFDdkIsU0FBU0MsVUFBVUMsdUJBQXVCO0FBQzFDLFNBQVNDLFVBQVU7QUFDbkIsU0FBU0MsaUJBQWlCQyxXQUFXQyxxQkFBcUI7OztBQUUxRCxNQUFNTCxTQUFTQyxnQkFBZ0JLO0FBRS9CLFNBQUFDLFlBQUFDLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBSztDQUFBLElBQUFDO0NBQUEsSUFBQU4sRUFBQSxPQUFBRCxJQUFBO0VBQXFCLEVBQUFNLFdBQUEsR0FBQUMsU0FBQVA7RUFBb0RDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0NBQUE7RUFBQUQsWUFBQUwsRUFBQTtFQUFBTSxRQUFBTixFQUFBO0NBQUE7Q0FBQSxJQUFBTztDQUFBLElBQUFQLEVBQUEsT0FBQUssV0FBQTtFQUl4REUsS0FBQWQsR0FBRyxtQkFBbUJZLFNBQVM7RUFBQ0wsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFPO0NBQUE7RUFBQUEsS0FBQVAsRUFBQTtDQUFBO0NBQUEsSUFBQVE7Q0FBQSxJQUFBUixFQUFBLE9BQUFNLFNBQUFOLEVBQUEsT0FBQU8sSUFBQTtFQUY3Q0MsS0FBQTtHQUNZO0dBQ0MsV0FBQUQ7R0FBZ0MsR0FDdkNEO0VBQUs7Ozs7O0VBQ1ROLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBTztFQUFBUCxFQUFBLEtBQUFRO0NBQUE7RUFBQUEsS0FBQVIsRUFBQTtDQUFBO0NBQUEsT0FKRlE7QUFJRTs7QUFJTixTQUFBQyxZQUFBVixJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBQztDQUFBLElBQUFOLEVBQUEsT0FBQUQsSUFBQTtFQUFxQixFQUFBTSxXQUFBLEdBQUFDLFNBQUFQO0VBQW9EQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtDQUFBO0VBQUFELFlBQUFMLEVBQUE7RUFBQU0sUUFBQU4sRUFBQTtDQUFBO0NBQUEsSUFBQU87Q0FBQSxJQUFBUCxFQUFBLE9BQUFLLFdBQUE7RUFJeERFLEtBQUFkLEdBQUcseUJBQXlCWSxTQUFTO0VBQUNMLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTztDQUFBO0VBQUFBLEtBQUFQLEVBQUE7Q0FBQTtDQUFBLElBQUFRO0NBQUEsSUFBQVIsRUFBQSxPQUFBTSxTQUFBTixFQUFBLE9BQUFPLElBQUE7RUFGbkRDLEtBQUE7R0FDWTtHQUNDLFdBQUFEO0dBQXNDLEdBQzdDRDtFQUFLOzs7OztFQUNUTixFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBUTtDQUFBO0VBQUFBLEtBQUFSLEVBQUE7Q0FBQTtDQUFBLE9BSkZRO0FBSUU7O0FBSU4sU0FBQUUsY0FBQVgsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLElBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFXO0NBQUEsSUFBQU47Q0FBQSxJQUFBQztDQUFBLElBQUFDO0NBQUEsSUFBQVAsRUFBQSxPQUFBRCxJQUFBO0VBQXVCLEVBQUFNLFdBQUFPLE1BQUFMLElBQUFJLFVBQUEsR0FBQUwsU0FBQVA7RUFPdEJDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBVztFQUFBWCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBTztDQUFBO0VBQUFJLFdBQUFYLEVBQUE7RUFBQUssWUFBQUwsRUFBQTtFQUFBTSxRQUFBTixFQUFBO0VBQUFPLEtBQUFQLEVBQUE7Q0FBQTtDQUxDLE1BQUFZLE9BQUFMLE9BQUFNLFlBQUEsWUFBQU47Q0FBZ0IsSUFBQUM7Q0FBQSxJQUFBUixFQUFBLE9BQUFLLFdBQUE7RUFVREcsS0FBQWYsR0FDVCx1MkJBQ0FZLFNBQ0Y7RUFBQ0wsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFRO0NBQUE7RUFBQUEsS0FBQVIsRUFBQTtDQUFBO0NBQUEsSUFBQWM7Q0FBQSxJQUFBZCxFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFJRFUsS0FBQSxnREFFSSxnQ0FBQyxpQkFBRCxFQUEyQiw4REFBa0Q7Ozs7V0FBRzs7Ozs7RUFFbEZkLEVBQUEsS0FBQWM7Q0FBQTtFQUFBQSxLQUFBZCxFQUFBO0NBQUE7Q0FBQSxJQUFBZTtDQUFBLElBQUFmLEVBQUEsT0FBQVcsWUFBQVgsRUFBQSxRQUFBTSxTQUFBTixFQUFBLFFBQUFZLFFBQUFaLEVBQUEsUUFBQVEsSUFBQTtFQWRKTyxLQUFBO0dBQ1k7R0FDQ0g7R0FDQSxXQUFBSjtHQUdWLEdBQ0dGO2FBUE4sQ0FTR0ssVUFDREcsRUFLRjs7Ozs7O0VBQTBCZCxFQUFBLEtBQUFXO0VBQUFYLEVBQUEsTUFBQU07RUFBQU4sRUFBQSxNQUFBWTtFQUFBWixFQUFBLE1BQUFRO0VBQUFSLEVBQUEsTUFBQWU7Q0FBQTtFQUFBQSxLQUFBZixFQUFBO0NBQUE7Q0FBQSxPQWYxQmU7QUFlMEI7O0FBSTlCLFNBQUFDLGNBQUFqQixJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQVc7Q0FBQSxJQUFBTjtDQUFBLElBQUFDO0NBQUEsSUFBQUM7Q0FBQSxJQUFBQztDQUFBLElBQUFNO0NBQUEsSUFBQUM7Q0FBQSxJQUFBRTtDQUFBLElBQUFqQixFQUFBLE9BQUFELElBQUE7RUFBdUIsRUFBQU0sV0FBQU0sVUFBQU8sTUFBQVgsSUFBQVksWUFBQVgsSUFBQVksT0FBQU4sSUFBQU8sYUFBQU4sSUFBQU8sc0JBQUFMLElBQUEsR0FBQVgsU0FBQVA7RUFhcEJDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBVztFQUFBWCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBTztFQUFBUCxFQUFBLEtBQUFRO0VBQUFSLEVBQUEsS0FBQWM7RUFBQWQsRUFBQSxLQUFBZTtFQUFBZixFQUFBLEtBQUFpQjtDQUFBO0VBQUFOLFdBQUFYLEVBQUE7RUFBQUssWUFBQUwsRUFBQTtFQUFBTSxRQUFBTixFQUFBO0VBQUFPLEtBQUFQLEVBQUE7RUFBQVEsS0FBQVIsRUFBQTtFQUFBYyxLQUFBZCxFQUFBO0VBQUFlLEtBQUFmLEVBQUE7RUFBQWlCLEtBQUFqQixFQUFBO0NBQUE7Q0FWRCxNQUFBa0IsT0FBQVgsT0FBQU0sWUFBQSxXQUFBTjtDQUNBLE1BQUFZLGFBQUFYLE9BQUFLLFlBQUEsSUFBQUw7Q0FDQSxNQUFBWSxRQUFBTixPQUFBRCxZQUFBLFdBQUFDO0NBQ0EsTUFBQU8sY0FBQU4sT0FBQUYsWUFBQSxJQUFBRTtDQUNBLE1BQUFPLHVCQUFBTCxPQUFBSixZQUFBLE9BQUFJO0NBQTJCLElBQUFNO0NBQUEsSUFBQXZCLEVBQUEsUUFBQUssV0FBQTtFQW9CUmtCLEtBQUE5QixHQUFHLGdwQkFBZ3BCWSxTQUFVO0VBQUNMLEVBQUEsTUFBQUs7RUFBQUwsRUFBQSxNQUFBdUI7Q0FBQTtFQUFBQSxLQUFBdkIsRUFBQTtDQUFBO0NBQUEsSUFBQXdCO0NBQUEsSUFBQXhCLEVBQUEsUUFBQUcsT0FBQUMsSUFBQTtFQUd6cUJvQixLQUFBLHdCQUFDLHNCQUFELENBQXFCOzs7OztFQUFHeEIsRUFBQSxNQUFBd0I7Q0FBQTtFQUFBQSxLQUFBeEIsRUFBQTtDQUFBO0NBQUEsSUFBQXlCO0NBQUEsSUFBQXpCLEVBQUEsUUFBQVcsVUFBQTtFQUN4QmMsS0FBQSxnREFBdUJkLFNBQVM7Ozs7O0VBQXVCWCxFQUFBLE1BQUFXO0VBQUFYLEVBQUEsTUFBQXlCO0NBQUE7RUFBQUEsS0FBQXpCLEVBQUE7Q0FBQTtDQUFBLElBQUEwQjtDQUFBLElBQUExQixFQUFBLFFBQUFHLE9BQUFDLElBQUE7RUFDdkRzQixLQUFBLHdCQUFDLHdCQUFELENBQXVCOzs7OztFQUFHMUIsRUFBQSxNQUFBMEI7Q0FBQTtFQUFBQSxLQUFBMUIsRUFBQTtDQUFBO0NBQUEsSUFBQTJCO0NBQUEsSUFBQTNCLEVBQUEsUUFBQXNCLHdCQUFBdEIsRUFBQSxRQUFBTSxTQUFBTixFQUFBLFFBQUF1QixNQUFBdkIsRUFBQSxRQUFBeUIsSUFBQTtFQVI1QkUsTUFBQTtHQUNZO0dBQ1VMO0dBQ1QsV0FBQUM7R0FBOHBCLEdBQ3JxQmpCO2FBSk47SUFNRWtCO0lBQ0FDO0lBQ0FDO0dBQ0Y7Ozs7OztFQUF3QjFCLEVBQUEsTUFBQXNCO0VBQUF0QixFQUFBLE1BQUFNO0VBQUFOLEVBQUEsTUFBQXVCO0VBQUF2QixFQUFBLE1BQUF5QjtFQUFBekIsRUFBQSxNQUFBMkI7Q0FBQTtFQUFBQSxNQUFBM0IsRUFBQTtDQUFBO0NBQUEsSUFBQTRCO0NBQUEsSUFBQTVCLEVBQUEsUUFBQW9CLFNBQUFwQixFQUFBLFFBQUFzQix3QkFBQXRCLEVBQUEsUUFBQXFCLGVBQUFyQixFQUFBLFFBQUFrQixRQUFBbEIsRUFBQSxRQUFBbUIsY0FBQW5CLEVBQUEsUUFBQTJCLEtBQUE7RUFsQjVCQyxNQUFBLDREQUNFO0dBQ1FWO0dBQ01DO0dBQ0xDO0dBQ01DO0dBQ1NDO0dBQ1o7YUFFVks7RUFVRjs7OztXQUNGOzs7OztFQUF5QjNCLEVBQUEsTUFBQW9CO0VBQUFwQixFQUFBLE1BQUFzQjtFQUFBdEIsRUFBQSxNQUFBcUI7RUFBQXJCLEVBQUEsTUFBQWtCO0VBQUFsQixFQUFBLE1BQUFtQjtFQUFBbkIsRUFBQSxNQUFBMkI7RUFBQTNCLEVBQUEsTUFBQTRCO0NBQUE7RUFBQUEsTUFBQTVCLEVBQUE7Q0FBQTtDQUFBLE9BcEJ6QjRCO0FBb0J5Qjs7QUFJN0IsU0FBQUMsWUFBQTlCLElBQUE7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxJQUFBSztDQUFBLElBQUFDO0NBQUEsSUFBQU4sRUFBQSxPQUFBRCxJQUFBO0VBQXFCLEVBQUFNLFdBQUEsR0FBQUMsU0FBQVA7RUFHY0MsRUFBQSxLQUFBRDtFQUFBQyxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07Q0FBQTtFQUFBRCxZQUFBTCxFQUFBO0VBQUFNLFFBQUFOLEVBQUE7Q0FBQTtDQUFBLElBQUFPO0NBQUEsSUFBQVAsRUFBQSxPQUFBSyxXQUFBO0VBSWxCRSxLQUFBZCxHQUFHLDZDQUE2Q1ksU0FBUztFQUFDTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU87Q0FBQTtFQUFBQSxLQUFBUCxFQUFBO0NBQUE7Q0FBQSxJQUFBUTtDQUFBLElBQUFSLEVBQUEsT0FBQU0sU0FBQU4sRUFBQSxPQUFBTyxJQUFBO0VBRnZFQyxLQUFBO0dBQ1k7R0FDQyxXQUFBRDtHQUEwRCxHQUNqRUQ7RUFBSzs7Ozs7RUFDVE4sRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFPO0VBQUFQLEVBQUEsS0FBQVE7Q0FBQTtFQUFBQSxLQUFBUixFQUFBO0NBQUE7Q0FBQSxPQUpGUTtBQUlFOztBQUlOLFNBQUFzQixXQUFBL0IsSUFBQTtDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLElBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFBLElBQUFXO0NBQUEsSUFBQU47Q0FBQSxJQUFBQztDQUFBLElBQUFOLEVBQUEsT0FBQUQsSUFBQTtFQUFvQixFQUFBTSxXQUFBTSxVQUFBLEdBQUFMLFNBQUFQO0VBSVNDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBVztFQUFBWCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU07Q0FBQTtFQUFBSyxXQUFBWCxFQUFBO0VBQUFLLFlBQUFMLEVBQUE7RUFBQU0sUUFBQU4sRUFBQTtDQUFBO0NBQUEsSUFBQU87Q0FBQSxJQUFBUCxFQUFBLE9BQUFLLFdBQUE7RUFJWkUsS0FBQWQsR0FDVCxzYkFDQVksU0FDRjtFQUFDTCxFQUFBLEtBQUFLO0VBQUFMLEVBQUEsS0FBQU87Q0FBQTtFQUFBQSxLQUFBUCxFQUFBO0NBQUE7Q0FBQSxJQUFBUTtDQUFBLElBQUFSLEVBQUEsT0FBQVcsVUFBQTtFQUdESCxLQUFBO0dBQW9DO0dBQ2pDRztFQUNIOzs7OztFQUEyQlgsRUFBQSxLQUFBVztFQUFBWCxFQUFBLEtBQUFRO0NBQUE7RUFBQUEsS0FBQVIsRUFBQTtDQUFBO0NBQUEsSUFBQWM7Q0FBQSxJQUFBZCxFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFDM0JVLEtBQUE7R0FFSSwwQ0FBZ0IsMEZBQThFOzs7OzthQUdoRyx3QkFBQyxXQUFELEVBQXFCLGlDQUFxQjs7Ozs7RUFDNUM7Ozs7O0VBQWdDZCxFQUFBLEtBQUFjO0NBQUE7RUFBQUEsS0FBQWQsRUFBQTtDQUFBO0NBQUEsSUFBQWU7Q0FBQSxJQUFBZixFQUFBLFFBQUFNLFNBQUFOLEVBQUEsUUFBQU8sTUFBQVAsRUFBQSxRQUFBUSxJQUFBO0VBakJsQ08sS0FBQTtHQUNZO0dBQ0MsV0FBQVI7R0FHVixHQUNHRDthQU5OLENBUUVFLElBR0FNLEVBT0Y7Ozs7OztFQUF1QmQsRUFBQSxNQUFBTTtFQUFBTixFQUFBLE1BQUFPO0VBQUFQLEVBQUEsTUFBQVE7RUFBQVIsRUFBQSxNQUFBZTtDQUFBO0VBQUFBLEtBQUFmLEVBQUE7Q0FBQTtDQUFBLE9BbEJ2QmU7QUFrQnVCOztBQUkzQixTQUFBZ0IsZ0JBQUFoQyxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBQztDQUFBLElBQUFOLEVBQUEsT0FBQUQsSUFBQTtFQUF5QixFQUFBTSxXQUFBLEdBQUFDLFNBQUFQO0VBR1NDLEVBQUEsS0FBQUQ7RUFBQUMsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFNO0NBQUE7RUFBQUQsWUFBQUwsRUFBQTtFQUFBTSxRQUFBTixFQUFBO0NBQUE7Q0FBQSxJQUFBTztDQUFBLElBQUFQLEVBQUEsT0FBQUssV0FBQTtFQUlqQkUsS0FBQWQsR0FBRyxpREFBaURZLFNBQVM7RUFBQ0wsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFPO0NBQUE7RUFBQUEsS0FBQVAsRUFBQTtDQUFBO0NBQUEsSUFBQVE7Q0FBQSxJQUFBUixFQUFBLE9BQUFNLFNBQUFOLEVBQUEsT0FBQU8sSUFBQTtFQUYzRUMsS0FBQTtHQUNZO0dBQ0MsV0FBQUQ7R0FBOEQsR0FDckVEO0VBQUs7Ozs7O0VBQ1ROLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBTztFQUFBUCxFQUFBLEtBQUFRO0NBQUE7RUFBQUEsS0FBQVIsRUFBQTtDQUFBO0NBQUEsT0FKRlE7QUFJRTs7QUFJTixTQUFBd0IscUJBQUFqQyxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBQztDQUFBLElBQUFOLEVBQUEsT0FBQUQsSUFBQTtFQUE4QixFQUFBTSxXQUFBLEdBQUFDLFNBQUFQO0VBRytCQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtDQUFBO0VBQUFELFlBQUFMLEVBQUE7RUFBQU0sUUFBQU4sRUFBQTtDQUFBO0NBQUEsSUFBQU87Q0FBQSxJQUFBUCxFQUFBLE9BQUFLLFdBQUE7RUFJNUNFLEtBQUFkLEdBQ1QsMEhBQ0FZLFNBQ0Y7RUFBQ0wsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFPO0NBQUE7RUFBQUEsS0FBQVAsRUFBQTtDQUFBO0NBQUEsSUFBQVE7Q0FBQSxJQUFBUixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFHREksS0FBQSx3QkFBQyxlQUFELENBQWM7Ozs7O0VBQ1pSLEVBQUEsS0FBQVE7Q0FBQTtFQUFBQSxLQUFBUixFQUFBO0NBQUE7Q0FBQSxJQUFBYztDQUFBLElBQUFkLEVBQUEsT0FBQU0sU0FBQU4sRUFBQSxPQUFBTyxJQUFBO0VBVEpPLEtBQUE7R0FDWTtHQUNDLFdBQUFQO0dBR1YsR0FDR0Q7YUFFSkU7RUFFRjs7Ozs7RUFBZ0NSLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBTztFQUFBUCxFQUFBLEtBQUFjO0NBQUE7RUFBQUEsS0FBQWQsRUFBQTtDQUFBO0NBQUEsT0FWaENjO0FBVWdDOztBQUlwQyxTQUFBbUIsdUJBQUFsQyxJQUFBO0NBQUEsTUFBQUMsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsSUFBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBQztDQUFBLElBQUFOLEVBQUEsT0FBQUQsSUFBQTtFQUFnQyxFQUFBTSxXQUFBLEdBQUFDLFNBQUFQO0VBRytCQyxFQUFBLEtBQUFEO0VBQUFDLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTTtDQUFBO0VBQUFELFlBQUFMLEVBQUE7RUFBQU0sUUFBQU4sRUFBQTtDQUFBO0NBQUEsSUFBQU87Q0FBQSxJQUFBUCxFQUFBLE9BQUFLLFdBQUE7RUFJOUNFLEtBQUFkLEdBQ1QsNkhBQ0FZLFNBQ0Y7RUFBQ0wsRUFBQSxLQUFBSztFQUFBTCxFQUFBLEtBQUFPO0NBQUE7RUFBQUEsS0FBQVAsRUFBQTtDQUFBO0NBQUEsSUFBQVE7Q0FBQSxJQUFBUixFQUFBLE9BQUFHLE9BQUFDLElBQUE7RUFHREksS0FBQSx3QkFBQyxpQkFBRCxDQUFnQjs7Ozs7RUFDZFIsRUFBQSxLQUFBUTtDQUFBO0VBQUFBLEtBQUFSLEVBQUE7Q0FBQTtDQUFBLElBQUFjO0NBQUEsSUFBQWQsRUFBQSxPQUFBTSxTQUFBTixFQUFBLE9BQUFPLElBQUE7RUFUSk8sS0FBQTtHQUNZO0dBQ0MsV0FBQVA7R0FHVixHQUNHRDthQUVKRTtFQUVGOzs7OztFQUFrQ1IsRUFBQSxLQUFBTTtFQUFBTixFQUFBLEtBQUFPO0VBQUFQLEVBQUEsS0FBQWM7Q0FBQTtFQUFBQSxLQUFBZCxFQUFBO0NBQUE7Q0FBQSxPQVZsQ2M7QUFVa0M7O0FBSXRDLFNBQ0V2QixRQUNBeUIsZUFDQWxCLGFBQ0FnQyxZQUNBRCxhQUNBSSx3QkFDQUQsc0JBQ0FELGlCQUNBckIsZUFDQUQiLCJuYW1lcyI6WyJSZWFjdCIsIlNlbGVjdCIsIlNlbGVjdFByaW1pdGl2ZSIsImNuIiwiQ2hldnJvbkRvd25JY29uIiwiQ2hlY2tJY29uIiwiQ2hldnJvblVwSWNvbiIsIlJvb3QiLCJTZWxlY3RHcm91cCIsInQwIiwiJCIsIl9jIiwiJGkiLCJTeW1ib2wiLCJmb3IiLCJjbGFzc05hbWUiLCJwcm9wcyIsInQxIiwidDIiLCJTZWxlY3RWYWx1ZSIsIlNlbGVjdFRyaWdnZXIiLCJjaGlsZHJlbiIsInNpemUiLCJ1bmRlZmluZWQiLCJ0MyIsInQ0IiwiU2VsZWN0Q29udGVudCIsInQ1Iiwic2lkZSIsInNpZGVPZmZzZXQiLCJhbGlnbiIsImFsaWduT2Zmc2V0IiwiYWxpZ25JdGVtV2l0aFRyaWdnZXIiLCJ0NiIsInQ3IiwidDgiLCJ0OSIsInQxMCIsInQxMSIsIlNlbGVjdExhYmVsIiwiU2VsZWN0SXRlbSIsIlNlbGVjdFNlcGFyYXRvciIsIlNlbGVjdFNjcm9sbFVwQnV0dG9uIiwiU2VsZWN0U2Nyb2xsRG93bkJ1dHRvbiJdLCJpZ25vcmVMaXN0IjpbXSwic291cmNlcyI6WyJzZWxlY3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiXG5pbXBvcnQgeyBTZWxlY3QgYXMgU2VsZWN0UHJpbWl0aXZlIH0gZnJvbSBcIkBiYXNlLXVpL3JlYWN0L3NlbGVjdFwiXG5pbXBvcnQgeyBjbiB9IGZyb20gXCJjblwiXG5pbXBvcnQgeyBDaGV2cm9uRG93bkljb24sIENoZWNrSWNvbiwgQ2hldnJvblVwSWNvbiB9IGZyb20gXCJsdWNpZGUtcmVhY3RcIlxuXG5jb25zdCBTZWxlY3QgPSBTZWxlY3RQcmltaXRpdmUuUm9vdFxuXG5mdW5jdGlvbiBTZWxlY3RHcm91cCh7IGNsYXNzTmFtZSwgLi4ucHJvcHMgfTogU2VsZWN0UHJpbWl0aXZlLkdyb3VwLlByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPFNlbGVjdFByaW1pdGl2ZS5Hcm91cFxuICAgICAgZGF0YS1zbG90PVwic2VsZWN0LWdyb3VwXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXCJzY3JvbGwtbXktMSBwLTFcIiwgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIFNlbGVjdFZhbHVlKHsgY2xhc3NOYW1lLCAuLi5wcm9wcyB9OiBTZWxlY3RQcmltaXRpdmUuVmFsdWUuUHJvcHMpIHtcbiAgcmV0dXJuIChcbiAgICA8U2VsZWN0UHJpbWl0aXZlLlZhbHVlXG4gICAgICBkYXRhLXNsb3Q9XCJzZWxlY3QtdmFsdWVcIlxuICAgICAgY2xhc3NOYW1lPXtjbihcImZsZXggZmxleC0xIHRleHQtbGVmdFwiLCBjbGFzc05hbWUpfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZnVuY3Rpb24gU2VsZWN0VHJpZ2dlcih7XG4gIGNsYXNzTmFtZSxcbiAgc2l6ZSA9IFwiZGVmYXVsdFwiLFxuICBjaGlsZHJlbixcbiAgLi4ucHJvcHNcbn06IFNlbGVjdFByaW1pdGl2ZS5UcmlnZ2VyLlByb3BzICYge1xuICBzaXplPzogXCJzbVwiIHwgXCJkZWZhdWx0XCJcbn0pIHtcbiAgcmV0dXJuIChcbiAgICA8U2VsZWN0UHJpbWl0aXZlLlRyaWdnZXJcbiAgICAgIGRhdGEtc2xvdD1cInNlbGVjdC10cmlnZ2VyXCJcbiAgICAgIGRhdGEtc2l6ZT17c2l6ZX1cbiAgICAgIGNsYXNzTmFtZT17Y24oXG4gICAgICAgIFwiZmxleCB3LWZpdCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0xLjUgcm91bmRlZC1sZyBib3JkZXIgYm9yZGVyLWlucHV0IGJnLXRyYW5zcGFyZW50IHB5LTIgcHItMiBwbC0yLjUgdGV4dC1zbSB3aGl0ZXNwYWNlLW5vd3JhcCB0cmFuc2l0aW9uLWNvbG9ycyBvdXRsaW5lLW5vbmUgc2VsZWN0LW5vbmUgZm9jdXMtdmlzaWJsZTpib3JkZXItcmluZyBmb2N1cy12aXNpYmxlOnJpbmctMyBmb2N1cy12aXNpYmxlOnJpbmctcmluZy81MCBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQgZGlzYWJsZWQ6b3BhY2l0eS01MCBhcmlhLWludmFsaWQ6Ym9yZGVyLWRlc3RydWN0aXZlIGFyaWEtaW52YWxpZDpyaW5nLTMgYXJpYS1pbnZhbGlkOnJpbmctZGVzdHJ1Y3RpdmUvMjAgZGF0YS1wbGFjZWhvbGRlcjp0ZXh0LW11dGVkLWZvcmVncm91bmQgZGF0YS1bc2l6ZT1kZWZhdWx0XTpoLTggZGF0YS1bc2l6ZT1zbV06aC03IGRhdGEtW3NpemU9c21dOnJvdW5kZWQtW21pbih2YXIoLS1yYWRpdXMtbWQpLDEwcHgpXSAqOmRhdGEtW3Nsb3Q9c2VsZWN0LXZhbHVlXTpsaW5lLWNsYW1wLTEgKjpkYXRhLVtzbG90PXNlbGVjdC12YWx1ZV06ZmxleCAqOmRhdGEtW3Nsb3Q9c2VsZWN0LXZhbHVlXTppdGVtcy1jZW50ZXIgKjpkYXRhLVtzbG90PXNlbGVjdC12YWx1ZV06Z2FwLTEuNSBkYXJrOmJnLWlucHV0LzMwIGRhcms6aG92ZXI6YmctaW5wdXQvNTAgZGFyazphcmlhLWludmFsaWQ6Ym9yZGVyLWRlc3RydWN0aXZlLzUwIGRhcms6YXJpYS1pbnZhbGlkOnJpbmctZGVzdHJ1Y3RpdmUvNDAgWyZfc3ZnXTpwb2ludGVyLWV2ZW50cy1ub25lIFsmX3N2Z106c2hyaW5rLTAgWyZfc3ZnOm5vdChbY2xhc3MqPSdzaXplLSddKV06c2l6ZS00XCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgICA8U2VsZWN0UHJpbWl0aXZlLkljb25cbiAgICAgICAgcmVuZGVyPXtcbiAgICAgICAgICA8Q2hldnJvbkRvd25JY29uIGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLW5vbmUgc2l6ZS00IHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiIC8+XG4gICAgICAgIH1cbiAgICAgIC8+XG4gICAgPC9TZWxlY3RQcmltaXRpdmUuVHJpZ2dlcj5cbiAgKVxufVxuXG5mdW5jdGlvbiBTZWxlY3RDb250ZW50KHtcbiAgY2xhc3NOYW1lLFxuICBjaGlsZHJlbixcbiAgc2lkZSA9IFwiYm90dG9tXCIsXG4gIHNpZGVPZmZzZXQgPSA0LFxuICBhbGlnbiA9IFwiY2VudGVyXCIsXG4gIGFsaWduT2Zmc2V0ID0gMCxcbiAgYWxpZ25JdGVtV2l0aFRyaWdnZXIgPSB0cnVlLFxuICAuLi5wcm9wc1xufTogU2VsZWN0UHJpbWl0aXZlLlBvcHVwLlByb3BzICZcbiAgUGljazxcbiAgICBTZWxlY3RQcmltaXRpdmUuUG9zaXRpb25lci5Qcm9wcyxcbiAgICBcImFsaWduXCIgfCBcImFsaWduT2Zmc2V0XCIgfCBcInNpZGVcIiB8IFwic2lkZU9mZnNldFwiIHwgXCJhbGlnbkl0ZW1XaXRoVHJpZ2dlclwiXG4gID4pIHtcbiAgcmV0dXJuIChcbiAgICA8U2VsZWN0UHJpbWl0aXZlLlBvcnRhbD5cbiAgICAgIDxTZWxlY3RQcmltaXRpdmUuUG9zaXRpb25lclxuICAgICAgICBzaWRlPXtzaWRlfVxuICAgICAgICBzaWRlT2Zmc2V0PXtzaWRlT2Zmc2V0fVxuICAgICAgICBhbGlnbj17YWxpZ259XG4gICAgICAgIGFsaWduT2Zmc2V0PXthbGlnbk9mZnNldH1cbiAgICAgICAgYWxpZ25JdGVtV2l0aFRyaWdnZXI9e2FsaWduSXRlbVdpdGhUcmlnZ2VyfVxuICAgICAgICBjbGFzc05hbWU9XCJpc29sYXRlIHotNTBcIlxuICAgICAgPlxuICAgICAgICA8U2VsZWN0UHJpbWl0aXZlLlBvcHVwXG4gICAgICAgICAgZGF0YS1zbG90PVwic2VsZWN0LWNvbnRlbnRcIlxuICAgICAgICAgIGRhdGEtYWxpZ24tdHJpZ2dlcj17YWxpZ25JdGVtV2l0aFRyaWdnZXJ9XG4gICAgICAgICAgY2xhc3NOYW1lPXtjbihcInJlbGF0aXZlIGlzb2xhdGUgei01MCBtYXgtaC0oLS1hdmFpbGFibGUtaGVpZ2h0KSB3LSgtLWFuY2hvci13aWR0aCkgbWluLXctMzYgb3JpZ2luLSgtLXRyYW5zZm9ybS1vcmlnaW4pIG92ZXJmbG93LXgtaGlkZGVuIG92ZXJmbG93LXktYXV0byByb3VuZGVkLWxnIGJnLXBvcG92ZXIgdGV4dC1wb3BvdmVyLWZvcmVncm91bmQgc2hhZG93LW1kIHJpbmctMSByaW5nLWZvcmVncm91bmQvMTAgZHVyYXRpb24tMTAwIGRhdGEtW2FsaWduLXRyaWdnZXI9dHJ1ZV06YW5pbWF0ZS1ub25lIGRhdGEtW3NpZGU9Ym90dG9tXTpzbGlkZS1pbi1mcm9tLXRvcC0yIGRhdGEtW3NpZGU9aW5saW5lLWVuZF06c2xpZGUtaW4tZnJvbS1sZWZ0LTIgZGF0YS1bc2lkZT1pbmxpbmUtc3RhcnRdOnNsaWRlLWluLWZyb20tcmlnaHQtMiBkYXRhLVtzaWRlPWxlZnRdOnNsaWRlLWluLWZyb20tcmlnaHQtMiBkYXRhLVtzaWRlPXJpZ2h0XTpzbGlkZS1pbi1mcm9tLWxlZnQtMiBkYXRhLVtzaWRlPXRvcF06c2xpZGUtaW4tZnJvbS1ib3R0b20tMiBkYXRhLW9wZW46YW5pbWF0ZS1pbiBkYXRhLW9wZW46ZmFkZS1pbi0wIGRhdGEtb3Blbjp6b29tLWluLTk1IGRhdGEtY2xvc2VkOmFuaW1hdGUtb3V0IGRhdGEtY2xvc2VkOmZhZGUtb3V0LTAgZGF0YS1jbG9zZWQ6em9vbS1vdXQtOTVcIiwgY2xhc3NOYW1lICl9XG4gICAgICAgICAgey4uLnByb3BzfVxuICAgICAgICA+XG4gICAgICAgICAgPFNlbGVjdFNjcm9sbFVwQnV0dG9uIC8+XG4gICAgICAgICAgPFNlbGVjdFByaW1pdGl2ZS5MaXN0PntjaGlsZHJlbn08L1NlbGVjdFByaW1pdGl2ZS5MaXN0PlxuICAgICAgICAgIDxTZWxlY3RTY3JvbGxEb3duQnV0dG9uIC8+XG4gICAgICAgIDwvU2VsZWN0UHJpbWl0aXZlLlBvcHVwPlxuICAgICAgPC9TZWxlY3RQcmltaXRpdmUuUG9zaXRpb25lcj5cbiAgICA8L1NlbGVjdFByaW1pdGl2ZS5Qb3J0YWw+XG4gIClcbn1cblxuZnVuY3Rpb24gU2VsZWN0TGFiZWwoe1xuICBjbGFzc05hbWUsXG4gIC4uLnByb3BzXG59OiBTZWxlY3RQcmltaXRpdmUuR3JvdXBMYWJlbC5Qcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxTZWxlY3RQcmltaXRpdmUuR3JvdXBMYWJlbFxuICAgICAgZGF0YS1zbG90PVwic2VsZWN0LWxhYmVsXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXCJweC0xLjUgcHktMSB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZFwiLCBjbGFzc05hbWUpfVxuICAgICAgey4uLnByb3BzfVxuICAgIC8+XG4gIClcbn1cblxuZnVuY3Rpb24gU2VsZWN0SXRlbSh7XG4gIGNsYXNzTmFtZSxcbiAgY2hpbGRyZW4sXG4gIC4uLnByb3BzXG59OiBTZWxlY3RQcmltaXRpdmUuSXRlbS5Qcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxTZWxlY3RQcmltaXRpdmUuSXRlbVxuICAgICAgZGF0YS1zbG90PVwic2VsZWN0LWl0ZW1cIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJyZWxhdGl2ZSBmbGV4IHctZnVsbCBjdXJzb3ItZGVmYXVsdCBpdGVtcy1jZW50ZXIgZ2FwLTEuNSByb3VuZGVkLW1kIHB5LTEgcHItOCBwbC0xLjUgdGV4dC1zbSBvdXRsaW5lLWhpZGRlbiBzZWxlY3Qtbm9uZSBmb2N1czpiZy1hY2NlbnQgZm9jdXM6dGV4dC1hY2NlbnQtZm9yZWdyb3VuZCBub3QtZGF0YS1bdmFyaWFudD1kZXN0cnVjdGl2ZV06Zm9jdXM6Kio6dGV4dC1hY2NlbnQtZm9yZWdyb3VuZCBkYXRhLWRpc2FibGVkOnBvaW50ZXItZXZlbnRzLW5vbmUgZGF0YS1kaXNhYmxlZDpvcGFjaXR5LTUwIFsmX3N2Z106cG9pbnRlci1ldmVudHMtbm9uZSBbJl9zdmddOnNocmluay0wIFsmX3N2Zzpub3QoW2NsYXNzKj0nc2l6ZS0nXSldOnNpemUtNCAqOltzcGFuXTpsYXN0OmZsZXggKjpbc3Bhbl06bGFzdDppdGVtcy1jZW50ZXIgKjpbc3Bhbl06bGFzdDpnYXAtMlwiLFxuICAgICAgICBjbGFzc05hbWVcbiAgICAgICl9XG4gICAgICB7Li4ucHJvcHN9XG4gICAgPlxuICAgICAgPFNlbGVjdFByaW1pdGl2ZS5JdGVtVGV4dCBjbGFzc05hbWU9XCJmbGV4IGZsZXgtMSBzaHJpbmstMCBnYXAtMiB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxuICAgICAgICB7Y2hpbGRyZW59XG4gICAgICA8L1NlbGVjdFByaW1pdGl2ZS5JdGVtVGV4dD5cbiAgICAgIDxTZWxlY3RQcmltaXRpdmUuSXRlbUluZGljYXRvclxuICAgICAgICByZW5kZXI9e1xuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInBvaW50ZXItZXZlbnRzLW5vbmUgYWJzb2x1dGUgcmlnaHQtMiBmbGV4IHNpemUtNCBpdGVtcy1jZW50ZXIganVzdGlmeS1jZW50ZXJcIiAvPlxuICAgICAgICB9XG4gICAgICA+XG4gICAgICAgIDxDaGVja0ljb24gY2xhc3NOYW1lPVwicG9pbnRlci1ldmVudHMtbm9uZVwiIC8+XG4gICAgICA8L1NlbGVjdFByaW1pdGl2ZS5JdGVtSW5kaWNhdG9yPlxuICAgIDwvU2VsZWN0UHJpbWl0aXZlLkl0ZW0+XG4gIClcbn1cblxuZnVuY3Rpb24gU2VsZWN0U2VwYXJhdG9yKHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogU2VsZWN0UHJpbWl0aXZlLlNlcGFyYXRvci5Qcm9wcykge1xuICByZXR1cm4gKFxuICAgIDxTZWxlY3RQcmltaXRpdmUuU2VwYXJhdG9yXG4gICAgICBkYXRhLXNsb3Q9XCJzZWxlY3Qtc2VwYXJhdG9yXCJcbiAgICAgIGNsYXNzTmFtZT17Y24oXCJwb2ludGVyLWV2ZW50cy1ub25lIC1teC0xIG15LTEgaC1weCBiZy1ib3JkZXJcIiwgY2xhc3NOYW1lKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICAvPlxuICApXG59XG5cbmZ1bmN0aW9uIFNlbGVjdFNjcm9sbFVwQnV0dG9uKHtcbiAgY2xhc3NOYW1lLFxuICAuLi5wcm9wc1xufTogUmVhY3QuQ29tcG9uZW50UHJvcHM8dHlwZW9mIFNlbGVjdFByaW1pdGl2ZS5TY3JvbGxVcEFycm93Pikge1xuICByZXR1cm4gKFxuICAgIDxTZWxlY3RQcmltaXRpdmUuU2Nyb2xsVXBBcnJvd1xuICAgICAgZGF0YS1zbG90PVwic2VsZWN0LXNjcm9sbC11cC1idXR0b25cIlxuICAgICAgY2xhc3NOYW1lPXtjbihcbiAgICAgICAgXCJ0b3AtMCB6LTEwIGZsZXggdy1mdWxsIGN1cnNvci1kZWZhdWx0IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBiZy1wb3BvdmVyIHB5LTEgWyZfc3ZnOm5vdChbY2xhc3MqPSdzaXplLSddKV06c2l6ZS00XCIsXG4gICAgICAgIGNsYXNzTmFtZVxuICAgICAgKX1cbiAgICAgIHsuLi5wcm9wc31cbiAgICA+XG4gICAgICA8Q2hldnJvblVwSWNvblxuICAgICAgLz5cbiAgICA8L1NlbGVjdFByaW1pdGl2ZS5TY3JvbGxVcEFycm93PlxuICApXG59XG5cbmZ1bmN0aW9uIFNlbGVjdFNjcm9sbERvd25CdXR0b24oe1xuICBjbGFzc05hbWUsXG4gIC4uLnByb3BzXG59OiBSZWFjdC5Db21wb25lbnRQcm9wczx0eXBlb2YgU2VsZWN0UHJpbWl0aXZlLlNjcm9sbERvd25BcnJvdz4pIHtcbiAgcmV0dXJuIChcbiAgICA8U2VsZWN0UHJpbWl0aXZlLlNjcm9sbERvd25BcnJvd1xuICAgICAgZGF0YS1zbG90PVwic2VsZWN0LXNjcm9sbC1kb3duLWJ1dHRvblwiXG4gICAgICBjbGFzc05hbWU9e2NuKFxuICAgICAgICBcImJvdHRvbS0wIHotMTAgZmxleCB3LWZ1bGwgY3Vyc29yLWRlZmF1bHQgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGJnLXBvcG92ZXIgcHktMSBbJl9zdmc6bm90KFtjbGFzcyo9J3NpemUtJ10pXTpzaXplLTRcIixcbiAgICAgICAgY2xhc3NOYW1lXG4gICAgICApfVxuICAgICAgey4uLnByb3BzfVxuICAgID5cbiAgICAgIDxDaGV2cm9uRG93bkljb25cbiAgICAgIC8+XG4gICAgPC9TZWxlY3RQcmltaXRpdmUuU2Nyb2xsRG93bkFycm93PlxuICApXG59XG5cbmV4cG9ydCB7XG4gIFNlbGVjdCxcbiAgU2VsZWN0Q29udGVudCxcbiAgU2VsZWN0R3JvdXAsXG4gIFNlbGVjdEl0ZW0sXG4gIFNlbGVjdExhYmVsLFxuICBTZWxlY3RTY3JvbGxEb3duQnV0dG9uLFxuICBTZWxlY3RTY3JvbGxVcEJ1dHRvbixcbiAgU2VsZWN0U2VwYXJhdG9yLFxuICBTZWxlY3RUcmlnZ2VyLFxuICBTZWxlY3RWYWx1ZSxcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL2NvbXBvbmVudHMvdWkvc2VsZWN0LnRzeCJ9