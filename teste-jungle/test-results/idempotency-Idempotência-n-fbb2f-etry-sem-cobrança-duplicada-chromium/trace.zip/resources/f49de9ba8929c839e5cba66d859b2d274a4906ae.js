const _c = __vite__cjsImport0_react_compilerRuntime["c"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { queryOptions, useMutation, useQuery, useQueryClient, useSuspenseQuery } from "/node_modules/.vite/deps/@tanstack_react-query.js?v=e9f94b2e";
import { queryKeys } from "/src/lib/query-keys.ts";
import { orderService } from "/src/services/order.service.ts";
export const orderDetailQueryOptions = (orderId) => queryOptions({
	queryKey: queryKeys.orders.detail(orderId),
	queryFn: () => orderService.getOrderById(orderId),
	// Recibo é um snapshot estático imutável
	staleTime: Number.POSITIVE_INFINITY
});
export const ordersListQueryOptions = queryOptions({
	queryKey: queryKeys.orders.list(),
	queryFn: orderService.listOrders,
	staleTime: 3e4
});
export function useSuspenseOrder(orderId) {
	const $ = _c(3);
	if ($[0] !== "a98a804bfe29312539ab55dfdd9cbe41ca2e8983597891ffe7675e2938af6c65") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "a98a804bfe29312539ab55dfdd9cbe41ca2e8983597891ffe7675e2938af6c65";
	}
	let t0;
	if ($[1] !== orderId) {
		t0 = orderDetailQueryOptions(orderId);
		$[1] = orderId;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return useSuspenseQuery(t0);
}
export function useGetOrders() {
	const $ = _c(1);
	if ($[0] !== "a98a804bfe29312539ab55dfdd9cbe41ca2e8983597891ffe7675e2938af6c65") {
		for (let $i = 0; $i < 1; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "a98a804bfe29312539ab55dfdd9cbe41ca2e8983597891ffe7675e2938af6c65";
	}
	return useQuery(ordersListQueryOptions);
}
export function useValidateCheckout() {
	const $ = _c(3);
	if ($[0] !== "a98a804bfe29312539ab55dfdd9cbe41ca2e8983597891ffe7675e2938af6c65") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "a98a804bfe29312539ab55dfdd9cbe41ca2e8983597891ffe7675e2938af6c65";
	}
	const queryClient = useQueryClient();
	let t0;
	if ($[1] !== queryClient) {
		t0 = {
			mutationFn: orderService.validateCheckout,
			onSuccess: (result) => {
				queryClient.setQueryData(queryKeys.cart.all, result.cart);
			}
		};
		$[1] = queryClient;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return useMutation(t0);
}
export function useCreateOrder() {
	const $ = _c(3);
	if ($[0] !== "a98a804bfe29312539ab55dfdd9cbe41ca2e8983597891ffe7675e2938af6c65") {
		for (let $i = 0; $i < 3; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "a98a804bfe29312539ab55dfdd9cbe41ca2e8983597891ffe7675e2938af6c65";
	}
	const queryClient = useQueryClient();
	let t0;
	if ($[1] !== queryClient) {
		t0 = {
			mutationFn: orderService.createOrder,
			retry: 0,
			onSuccess: (order) => {
				queryClient.setQueryData(queryKeys.orders.detail(order.id), order);
				queryClient.invalidateQueries({ queryKey: queryKeys.cart.all });
				queryClient.invalidateQueries({ queryKey: queryKeys.auth.me() });
				queryClient.invalidateQueries({ queryKey: queryKeys.orders.all });
			}
		};
		$[1] = queryClient;
		$[2] = t0;
	} else {
		t0 = $[2];
	}
	return useMutation(t0);
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQ0VBLGNBQ0FDLGFBQ0FDLFVBQ0FDLGdCQUNBQyx3QkFDSztBQUNQLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxvQkFBb0I7QUFFN0IsT0FBTyxNQUFNQywyQkFBMkJDLFlBQ3RDUixhQUFhO0NBQ1hTLFVBQVVKLFVBQVVLLE9BQU9DLE9BQU9ILE9BQU87Q0FDekNJLGVBQWVOLGFBQWFPLGFBQWFMLE9BQU87O0NBRWhETSxXQUFXQyxPQUFPQztBQUNwQixDQUFDO0FBRUgsT0FBTyxNQUFNQyx5QkFBeUJqQixhQUFhO0NBQ2pEUyxVQUFVSixVQUFVSyxPQUFPUSxLQUFLO0NBQ2hDTixTQUFTTixhQUFhYTtDQUN0QkwsV0FBVztBQUNiLENBQUM7QUFFRCxPQUFPLFNBQUFNLGlCQUFBWixTQUFBO0NBQUEsTUFBQWEsSUFBQUMsR0FBQTtDQUFBLElBQUFELEVBQUE7RUFBQSxTQUFBRSxLQUFBLEdBQUFBLEtBQUEsR0FBQUEsTUFBQTtHQUFBRixFQUFBRSxNQUFBQyxPQUFBQyxJQUFBO0VBQUE7RUFBQUosRUFBQTtDQUFBO0NBQUEsSUFBQUs7Q0FBQSxJQUFBTCxFQUFBLE9BQUFiLFNBQUE7RUFDbUJrQixLQUFBbkIsd0JBQXdCQyxPQUFPO0VBQUNhLEVBQUEsS0FBQWI7RUFBQWEsRUFBQSxLQUFBSztDQUFBO0VBQUFBLEtBQUFMLEVBQUE7Q0FBQTtDQUFBLE9BQWpEakIsaUJBQWlCc0IsRUFBZ0M7QUFBQztBQUczRCxPQUFPLFNBQUFDLGVBQUE7Q0FBQSxNQUFBTixJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxHQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FBQSxPQUNFbkIsU0FBU2Usc0JBQXNCO0FBQUM7QUFHekMsT0FBTyxTQUFBVyxzQkFBQTtDQUFBLE1BQUFQLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUNMLE1BQUFRLGNBQW9CMUIsZUFBZTtDQUFDLElBQUF1QjtDQUFBLElBQUFMLEVBQUEsT0FBQVEsYUFBQTtFQUNqQkgsS0FBQTtHQUFBSSxZQUNMeEIsYUFBWXlCO0dBQWlCQyxZQUM5QkMsV0FBQTtJQUNUSixZQUFXSyxhQUFjN0IsVUFBUzhCLEtBQUtDLEtBQU1ILE9BQU1FLElBQUs7R0FBQztFQUU3RDtFQUFDZCxFQUFBLEtBQUFRO0VBQUFSLEVBQUEsS0FBQUs7Q0FBQTtFQUFBQSxLQUFBTCxFQUFBO0NBQUE7Q0FBQSxPQUxNcEIsWUFBWXlCLEVBS2xCO0FBQUM7QUFHSixPQUFPLFNBQUFXLGlCQUFBO0NBQUEsTUFBQWhCLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLEdBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUNMLE1BQUFRLGNBQW9CMUIsZUFBZTtDQUFDLElBQUF1QjtDQUFBLElBQUFMLEVBQUEsT0FBQVEsYUFBQTtFQUVqQkgsS0FBQTtHQUFBSSxZQUNMeEIsYUFBWWdDO0dBQVlDLE9BRTdCO0dBQUNQLFlBQ0dRLFVBQUE7SUFDVFgsWUFBV0ssYUFBYzdCLFVBQVNLLE9BQU9DLE9BQVE2QixNQUFLQyxFQUFHLEdBQUdELEtBQUs7SUFDNURYLFlBQVdhLGtCQUFtQixFQUFBakMsVUFBWUosVUFBUzhCLEtBQUtDLElBQUssQ0FBQztJQUM5RFAsWUFBV2Esa0JBQW1CLEVBQUFqQyxVQUFZSixVQUFTc0MsS0FBS0MsR0FBSSxFQUFFLENBQUM7SUFDL0RmLFlBQVdhLGtCQUFtQixFQUFBakMsVUFBWUosVUFBU0ssT0FBTzBCLElBQUssQ0FBQztHQUFDO0VBRTFFO0VBQUNmLEVBQUEsS0FBQVE7RUFBQVIsRUFBQSxLQUFBSztDQUFBO0VBQUFBLEtBQUFMLEVBQUE7Q0FBQTtDQUFBLE9BVk1wQixZQUFZeUIsRUFVbEI7QUFBQyIsIm5hbWVzIjpbInF1ZXJ5T3B0aW9ucyIsInVzZU11dGF0aW9uIiwidXNlUXVlcnkiLCJ1c2VRdWVyeUNsaWVudCIsInVzZVN1c3BlbnNlUXVlcnkiLCJxdWVyeUtleXMiLCJvcmRlclNlcnZpY2UiLCJvcmRlckRldGFpbFF1ZXJ5T3B0aW9ucyIsIm9yZGVySWQiLCJxdWVyeUtleSIsIm9yZGVycyIsImRldGFpbCIsInF1ZXJ5Rm4iLCJnZXRPcmRlckJ5SWQiLCJzdGFsZVRpbWUiLCJOdW1iZXIiLCJQT1NJVElWRV9JTkZJTklUWSIsIm9yZGVyc0xpc3RRdWVyeU9wdGlvbnMiLCJsaXN0IiwibGlzdE9yZGVycyIsInVzZVN1c3BlbnNlT3JkZXIiLCIkIiwiX2MiLCIkaSIsIlN5bWJvbCIsImZvciIsInQwIiwidXNlR2V0T3JkZXJzIiwidXNlVmFsaWRhdGVDaGVja291dCIsInF1ZXJ5Q2xpZW50IiwibXV0YXRpb25GbiIsInZhbGlkYXRlQ2hlY2tvdXQiLCJvblN1Y2Nlc3MiLCJyZXN1bHQiLCJzZXRRdWVyeURhdGEiLCJjYXJ0IiwiYWxsIiwidXNlQ3JlYXRlT3JkZXIiLCJjcmVhdGVPcmRlciIsInJldHJ5Iiwib3JkZXIiLCJpZCIsImludmFsaWRhdGVRdWVyaWVzIiwiYXV0aCIsIm1lIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbInVzZS1vcmRlcnMudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgcXVlcnlPcHRpb25zLFxuICB1c2VNdXRhdGlvbixcbiAgdXNlUXVlcnksXG4gIHVzZVF1ZXJ5Q2xpZW50LFxuICB1c2VTdXNwZW5zZVF1ZXJ5LFxufSBmcm9tICdAdGFuc3RhY2svcmVhY3QtcXVlcnknXG5pbXBvcnQgeyBxdWVyeUtleXMgfSBmcm9tICdAL2xpYi9xdWVyeS1rZXlzJ1xuaW1wb3J0IHsgb3JkZXJTZXJ2aWNlIH0gZnJvbSAnQC9zZXJ2aWNlcy9vcmRlci5zZXJ2aWNlJ1xuXG5leHBvcnQgY29uc3Qgb3JkZXJEZXRhaWxRdWVyeU9wdGlvbnMgPSAob3JkZXJJZDogc3RyaW5nKSA9PlxuICBxdWVyeU9wdGlvbnMoe1xuICAgIHF1ZXJ5S2V5OiBxdWVyeUtleXMub3JkZXJzLmRldGFpbChvcmRlcklkKSxcbiAgICBxdWVyeUZuOiAoKSA9PiBvcmRlclNlcnZpY2UuZ2V0T3JkZXJCeUlkKG9yZGVySWQpLFxuICAgIC8vIFJlY2libyDDqSB1bSBzbmFwc2hvdCBlc3TDoXRpY28gaW11dMOhdmVsXG4gICAgc3RhbGVUaW1lOiBOdW1iZXIuUE9TSVRJVkVfSU5GSU5JVFksXG4gIH0pXG5cbmV4cG9ydCBjb25zdCBvcmRlcnNMaXN0UXVlcnlPcHRpb25zID0gcXVlcnlPcHRpb25zKHtcbiAgcXVlcnlLZXk6IHF1ZXJ5S2V5cy5vcmRlcnMubGlzdCgpLFxuICBxdWVyeUZuOiBvcmRlclNlcnZpY2UubGlzdE9yZGVycyxcbiAgc3RhbGVUaW1lOiAzMF8wMDAsXG59KVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlU3VzcGVuc2VPcmRlcihvcmRlcklkOiBzdHJpbmcpIHtcbiAgcmV0dXJuIHVzZVN1c3BlbnNlUXVlcnkob3JkZXJEZXRhaWxRdWVyeU9wdGlvbnMob3JkZXJJZCkpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VHZXRPcmRlcnMoKSB7XG4gIHJldHVybiB1c2VRdWVyeShvcmRlcnNMaXN0UXVlcnlPcHRpb25zKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlVmFsaWRhdGVDaGVja291dCgpIHtcbiAgY29uc3QgcXVlcnlDbGllbnQgPSB1c2VRdWVyeUNsaWVudCgpXG4gIHJldHVybiB1c2VNdXRhdGlvbih7XG4gICAgbXV0YXRpb25Gbjogb3JkZXJTZXJ2aWNlLnZhbGlkYXRlQ2hlY2tvdXQsXG4gICAgb25TdWNjZXNzOiAocmVzdWx0KSA9PiB7XG4gICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGEocXVlcnlLZXlzLmNhcnQuYWxsLCByZXN1bHQuY2FydClcbiAgICB9LFxuICB9KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdXNlQ3JlYXRlT3JkZXIoKSB7XG4gIGNvbnN0IHF1ZXJ5Q2xpZW50ID0gdXNlUXVlcnlDbGllbnQoKVxuXG4gIHJldHVybiB1c2VNdXRhdGlvbih7XG4gICAgbXV0YXRpb25Gbjogb3JkZXJTZXJ2aWNlLmNyZWF0ZU9yZGVyLFxuICAgIC8vIERlc2FiaWxpdGEgcmV0cnkgYXV0b23DoXRpY28gcGFyYSBleHBvciBvIGNvbnRyb2xlIGV4cGzDrWNpdG8gZGUgcmVlbnZpbyBpZGVtcG90ZW50ZSBuYSBVSVxuICAgIHJldHJ5OiAwLFxuICAgIG9uU3VjY2VzczogKG9yZGVyKSA9PiB7XG4gICAgICBxdWVyeUNsaWVudC5zZXRRdWVyeURhdGEocXVlcnlLZXlzLm9yZGVycy5kZXRhaWwob3JkZXIuaWQpLCBvcmRlcilcbiAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogcXVlcnlLZXlzLmNhcnQuYWxsIH0pXG4gICAgICB2b2lkIHF1ZXJ5Q2xpZW50LmludmFsaWRhdGVRdWVyaWVzKHsgcXVlcnlLZXk6IHF1ZXJ5S2V5cy5hdXRoLm1lKCkgfSlcbiAgICAgIHZvaWQgcXVlcnlDbGllbnQuaW52YWxpZGF0ZVF1ZXJpZXMoeyBxdWVyeUtleTogcXVlcnlLZXlzLm9yZGVycy5hbGwgfSlcbiAgICB9LFxuICB9KVxufVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvaG9va3MvdXNlLW9yZGVycy50cyJ9