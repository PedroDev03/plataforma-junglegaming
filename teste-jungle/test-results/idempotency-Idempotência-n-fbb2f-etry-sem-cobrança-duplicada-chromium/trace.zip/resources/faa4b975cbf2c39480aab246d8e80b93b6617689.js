import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/cart/coupon-form.tsx");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport10_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { useForm } from "/node_modules/.vite/deps/react-hook-form.js?v=e9f94b2e";
import { zodResolver } from "/node_modules/.vite/deps/@hookform_resolvers_zod.js?v=e9f94b2e";
import { Ticket, X } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { SubmitButton } from "/src/components/form/submit-button.tsx";
import { TextField } from "/src/components/form/text-field.tsx";
import { Button } from "/src/components/ui/button.tsx";
import { useApplyCoupon, useRemoveCoupon } from "/src/hooks/use-cart.ts";
import { getErrorMessage } from "/src/lib/api.ts";
import { couponSchema } from "/src/schemas/cart.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/components/cart/coupon-form.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
const SUGGESTED_COUPONS = [
	"JUNGLE10",
	"WEB3VIP",
	"ETH5"
];
export function CouponForm(t0) {
	_s();
	const $ = _c(16);
	if ($[0] !== "c792dc40f2f6ba9016dc12c0c8a4a3c5ae153d424a9b74847657f22119b46c69") {
		for (let $i = 0; $i < 16; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "c792dc40f2f6ba9016dc12c0c8a4a3c5ae153d424a9b74847657f22119b46c69";
	}
	const { activeCoupon, discountPercent } = t0;
	const applyCoupon = useApplyCoupon();
	const removeCoupon = useRemoveCoupon();
	let t1;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t1 = {
			resolver: zodResolver(couponSchema),
			defaultValues: { code: "" }
		};
		$[1] = t1;
	} else {
		t1 = $[1];
	}
	const { register, handleSubmit, setError, setValue, reset, formState: t2 } = useForm(t1);
	const { errors } = t2;
	let t3;
	if ($[2] !== applyCoupon || $[3] !== reset || $[4] !== setError) {
		t3 = (values) => {
			applyCoupon.mutate({ code: values.code }, {
				onSuccess: () => reset({ code: "" }),
				onError: (error) => {
					setError("code", { message: getErrorMessage(error) });
				}
			});
		};
		$[2] = applyCoupon;
		$[3] = reset;
		$[4] = setError;
		$[5] = t3;
	} else {
		t3 = $[5];
	}
	const onSubmit = t3;
	let t4;
	if ($[6] !== activeCoupon || $[7] !== applyCoupon || $[8] !== discountPercent || $[9] !== errors || $[10] !== handleSubmit || $[11] !== onSubmit || $[12] !== register || $[13] !== removeCoupon || $[14] !== setValue) {
		t4 = /* @__PURE__ */ _jsxDEV("div", {
			className: "grid gap-3",
			children: activeCoupon ? /* @__PURE__ */ _jsxDEV("div", {
				role: "status",
				"aria-live": "polite",
				className: "flex items-center justify-between gap-2 rounded-lg border bg-muted/50 px-3 py-2",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ _jsxDEV(Ticket, {
						className: "size-4 text-primary",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 225
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "text-xs font-medium",
						children: [
							"Cupom ",
							/* @__PURE__ */ _jsxDEV("strong", {
								className: "font-mono",
								children: activeCoupon
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 79,
								columnNumber: 330
							}, this),
							" (",
							discountPercent,
							"% OFF)"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 286
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 184
				}, this), /* @__PURE__ */ _jsxDEV(Button, {
					type: "button",
					variant: "ghost",
					size: "icon-xs",
					disabled: removeCoupon.isPending,
					"aria-label": `Remover cupom ${activeCoupon}`,
					onClick: () => removeCoupon.mutate(),
					children: /* @__PURE__ */ _jsxDEV(X, {
						className: "size-3.5",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 591
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 421
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 54
			}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit(onSubmit),
				noValidate: true,
				className: "grid gap-2",
				children: [/* @__PURE__ */ _jsxDEV(TextField, {
					label: "Cupom de desconto",
					placeholder: "Ex: JUNGLE10",
					autoComplete: "off",
					hint: "Experimente JUNGLE10 (10%), WEB3VIP (20%) ou ETH5 (5%).",
					error: errors.code?.message,
					...register("code")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 737
				}, this), /* @__PURE__ */ _jsxDEV(SubmitButton, {
					isPending: applyCoupon.isPending,
					pendingText: "Validando...",
					variant: "outline",
					size: "sm",
					className: "w-full",
					children: [/* @__PURE__ */ _jsxDEV(Ticket, {
						className: "size-3.5",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 1058
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Aplicar cupom" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 79,
						columnNumber: 1108
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 936
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 656
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				role: "group",
				"aria-label": "Cupons sugeridos",
				className: "flex flex-wrap items-center gap-1.5",
				children: [/* @__PURE__ */ _jsxDEV("span", {
					className: "text-xs text-muted-foreground",
					children: "Sugestões:"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 1252
				}, this), SUGGESTED_COUPONS.map((code) => /* @__PURE__ */ _jsxDEV(Button, {
					type: "button",
					variant: "outline",
					size: "xs",
					"aria-label": `Preencher cupom ${code}`,
					className: "font-mono",
					onClick: () => {
						setValue("code", code, { shouldValidate: true });
					},
					children: code
				}, code, false, {
					fileName: _jsxFileName,
					lineNumber: 79,
					columnNumber: 1348
				}, this))]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 1156
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 654
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 79,
			columnNumber: 10
		}, this);
		$[6] = activeCoupon;
		$[7] = applyCoupon;
		$[8] = discountPercent;
		$[9] = errors;
		$[10] = handleSubmit;
		$[11] = onSubmit;
		$[12] = register;
		$[13] = removeCoupon;
		$[14] = setValue;
		$[15] = t4;
	} else {
		t4 = $[15];
	}
	return t4;
}
_s(CouponForm, "ECUEZKY5gwXXTuqas1MK4cIJjJc=", false, function() {
	return [
		useApplyCoupon,
		useRemoveCoupon,
		useForm
	];
});
_c2 = CouponForm;
var _c2;
$RefreshReg$(_c2, "CouponForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/cart/coupon-form.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/components/cart/coupon-form.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/components/cart/coupon-form.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/components/cart/coupon-form.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQVNBLGVBQWU7QUFDeEIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLFFBQVFDLFNBQVM7QUFDMUIsU0FBU0Msb0JBQW9CO0FBQzdCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGdCQUFnQkMsdUJBQXVCO0FBQ2hELFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyxvQkFBMkM7Ozs7QUFPcEQsTUFBTUMsb0JBQW9CO0NBQUM7Q0FBWTtDQUFXO0FBQU07QUFFeEQsT0FBTyxTQUFBQyxXQUFBQyxJQUFBOztDQUFBLE1BQUFDLElBQUFDLEdBQUE7Q0FBQSxJQUFBRCxFQUFBO0VBQUEsU0FBQUUsS0FBQSxHQUFBQSxLQUFBLElBQUFBLE1BQUE7R0FBQUYsRUFBQUUsTUFBQUMsT0FBQUMsSUFBQTtFQUFBO0VBQUFKLEVBQUE7Q0FBQTtDQUFvQixRQUFBSyxjQUFBQyxvQkFBQVA7Q0FDekIsTUFBQVEsY0FBb0JkLGVBQWU7Q0FDbkMsTUFBQWUsZUFBcUJkLGdCQUFnQjtDQUFDLElBQUFlO0NBQUEsSUFBQVQsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBU1JLLEtBQUE7R0FBQUMsVUFDbEJ2QixZQUFZUyxZQUFZO0dBQUNlLGVBQ3BCLEVBQUFDLE1BQVEsR0FBRztFQUM1QjtFQUFDWixFQUFBLEtBQUFTO0NBQUE7RUFBQUEsS0FBQVQsRUFBQTtDQUFBO0NBVkQsUUFBQWEsVUFBQUMsY0FBQUMsVUFBQUMsVUFBQUMsT0FBQUMsV0FBQUMsT0FPSWpDLFFBQTBCdUIsRUFHN0I7Q0FKWSxRQUFBVyxXQUFBRDtDQUFVLElBQUFFO0NBQUEsSUFBQXJCLEVBQUEsT0FBQU8sZUFBQVAsRUFBQSxPQUFBaUIsU0FBQWpCLEVBQUEsT0FBQWUsVUFBQTtFQU1OTSxNQUFBQyxXQUFBO0dBQ2ZmLFlBQVdnQixPQUNULEVBQUFYLE1BQVFVLE9BQU1WLEtBQU0sR0FDcEI7SUFBQVksaUJBQ21CUCxNQUFNLEVBQUFMLE1BQVEsR0FBRyxDQUFDO0lBQUNhLFVBQzNCQyxVQUFBO0tBQ1BYLFNBQVMsUUFBUSxFQUFBWSxTQUFXaEMsZ0JBQWdCK0IsS0FBSyxFQUFFLENBQUM7SUFBQztHQUV6RCxDQUNGO0VBQUM7RUFDRjFCLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxLQUFBaUI7RUFBQWpCLEVBQUEsS0FBQWU7RUFBQWYsRUFBQSxLQUFBcUI7Q0FBQTtFQUFBQSxLQUFBckIsRUFBQTtDQUFBO0NBVkQsTUFBQTRCLFdBQWlCUDtDQVVoQixJQUFBUTtDQUFBLElBQUE3QixFQUFBLE9BQUFLLGdCQUFBTCxFQUFBLE9BQUFPLGVBQUFQLEVBQUEsT0FBQU0sbUJBQUFOLEVBQUEsT0FBQW9CLFVBQUFwQixFQUFBLFFBQUFjLGdCQUFBZCxFQUFBLFFBQUE0QixZQUFBNUIsRUFBQSxRQUFBYSxZQUFBYixFQUFBLFFBQUFRLGdCQUFBUixFQUFBLFFBQUFnQixVQUFBO0VBR0NhLEtBQUE7R0FBZTthQUNaeEIsZUFDQztJQUNPO0lBQ0s7SUFDQTtjQUhaLENBS0U7S0FBZTtlQUFmLENBQ0Usd0JBQUMsUUFBRDtNQUFrQjtNQUFrQztLQUFNOzs7O2VBQzFEO01BQWdCO2dCQUFoQjtPQUFzQztPQUM5QjtRQUFrQjtrQkFBYUE7T0FBc0I7Ozs7O09BQUE7T0FBR0M7T0FBZ0I7TUFDekU7Ozs7O2FBQ0g7Ozs7O2NBQ04sd0JBQUMsUUFBRDtLQUNPO0tBQ0c7S0FDSDtLQUNLLFVBQUFFLGFBQVlzQjtLQUNWLCtCQUFpQnpCO0tBQ3BCLGVBQU1HLGFBQVllLE9BQVE7ZUFFbkMsd0JBQUMsR0FBRDtNQUFhO01BQXVCO0tBQU07Ozs7O0lBUnJDOzs7O1lBVUg7Ozs7O2NBdEJQLGdEQXlCRztJQUFnQixVQUFBVCxhQUFhYyxRQUFRO0lBQUc7SUFBcUI7Y0FBN0QsQ0FDRSx3QkFBQyxXQUFEO0tBQ1E7S0FDTTtLQUNDO0tBQ1I7S0FDRSxPQUFBUixPQUFNUixNQUFjZTtLQUFBLEdBQ3ZCZCxTQUFTLE1BQU07SUFBQzs7OztjQUV0Qix3QkFBQyxjQUFEO0tBQ2EsV0FBQU4sWUFBV3VCO0tBQ1Y7S0FDSjtLQUNIO0tBQ0s7ZUFMWixDQU9FLHdCQUFDLFFBQUQ7TUFBa0I7TUFBdUI7S0FBTTs7OztlQUMvQyw0Q0FBTSxnQkFBb0I7Ozs7YUFSZjs7Ozs7WUFVUjs7Ozs7YUFFUDtJQUNPO0lBQ007SUFDRDtjQUhaLENBS0U7S0FBZ0I7ZUFBZ0M7SUFBaUI7Ozs7Y0FDaEVqQyxrQkFBaUJrQyxLQUFLbkIsU0FDckIsd0JBQUMsUUFBRDtLQUVPO0tBQ0c7S0FDSDtLQUNPLGlDQUFtQkE7S0FDckI7S0FDRDtNQUNQSSxTQUFTLFFBQVFKLE1BQU0sRUFBQW9CLGdCQUFrQixLQUFLLENBQUM7S0FBQztlQUdqRHBCO0lBWEksR0FDQUE7Ozs7V0FEQSxDQWFSLENBQ0c7Ozs7O1dBQUE7Ozs7O0VBR047Ozs7O0VBQUFaLEVBQUEsS0FBQUs7RUFBQUwsRUFBQSxLQUFBTztFQUFBUCxFQUFBLEtBQUFNO0VBQUFOLEVBQUEsS0FBQW9CO0VBQUFwQixFQUFBLE1BQUFjO0VBQUFkLEVBQUEsTUFBQTRCO0VBQUE1QixFQUFBLE1BQUFhO0VBQUFiLEVBQUEsTUFBQVE7RUFBQVIsRUFBQSxNQUFBZ0I7RUFBQWhCLEVBQUEsTUFBQTZCO0NBQUE7RUFBQUEsS0FBQTdCLEVBQUE7Q0FBQTtDQUFBLE9BdkVONkI7QUF1RU0iLCJuYW1lcyI6WyJ1c2VGb3JtIiwiem9kUmVzb2x2ZXIiLCJUaWNrZXQiLCJYIiwiU3VibWl0QnV0dG9uIiwiVGV4dEZpZWxkIiwiQnV0dG9uIiwidXNlQXBwbHlDb3Vwb24iLCJ1c2VSZW1vdmVDb3Vwb24iLCJnZXRFcnJvck1lc3NhZ2UiLCJjb3Vwb25TY2hlbWEiLCJTVUdHRVNURURfQ09VUE9OUyIsIkNvdXBvbkZvcm0iLCJ0MCIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwiYWN0aXZlQ291cG9uIiwiZGlzY291bnRQZXJjZW50IiwiYXBwbHlDb3Vwb24iLCJyZW1vdmVDb3Vwb24iLCJ0MSIsInJlc29sdmVyIiwiZGVmYXVsdFZhbHVlcyIsImNvZGUiLCJyZWdpc3RlciIsImhhbmRsZVN1Ym1pdCIsInNldEVycm9yIiwic2V0VmFsdWUiLCJyZXNldCIsImZvcm1TdGF0ZSIsInQyIiwiZXJyb3JzIiwidDMiLCJ2YWx1ZXMiLCJtdXRhdGUiLCJvblN1Y2Nlc3MiLCJvbkVycm9yIiwiZXJyb3IiLCJtZXNzYWdlIiwib25TdWJtaXQiLCJ0NCIsImlzUGVuZGluZyIsIm1hcCIsInNob3VsZFZhbGlkYXRlIl0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImNvdXBvbi1mb3JtLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VGb3JtIH0gZnJvbSAncmVhY3QtaG9vay1mb3JtJ1xuaW1wb3J0IHsgem9kUmVzb2x2ZXIgfSBmcm9tICdAaG9va2Zvcm0vcmVzb2x2ZXJzL3pvZCdcbmltcG9ydCB7IFRpY2tldCwgWCB9IGZyb20gJ2x1Y2lkZS1yZWFjdCdcbmltcG9ydCB7IFN1Ym1pdEJ1dHRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy9mb3JtL3N1Ym1pdC1idXR0b24nXG5pbXBvcnQgeyBUZXh0RmllbGQgfSBmcm9tICdAL2NvbXBvbmVudHMvZm9ybS90ZXh0LWZpZWxkJ1xuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcbmltcG9ydCB7IHVzZUFwcGx5Q291cG9uLCB1c2VSZW1vdmVDb3Vwb24gfSBmcm9tICdAL2hvb2tzL3VzZS1jYXJ0J1xuaW1wb3J0IHsgZ2V0RXJyb3JNZXNzYWdlIH0gZnJvbSAnQC9saWIvYXBpJ1xuaW1wb3J0IHsgY291cG9uU2NoZW1hLCB0eXBlIENvdXBvbkZvcm1WYWx1ZXMgfSBmcm9tICdAL3NjaGVtYXMvY2FydCdcblxuaW50ZXJmYWNlIENvdXBvbkZvcm1Qcm9wcyB7XG4gIGFjdGl2ZUNvdXBvbjogc3RyaW5nIHwgbnVsbFxuICBkaXNjb3VudFBlcmNlbnQ6IG51bWJlclxufVxuXG5jb25zdCBTVUdHRVNURURfQ09VUE9OUyA9IFsnSlVOR0xFMTAnLCAnV0VCM1ZJUCcsICdFVEg1J10gYXMgY29uc3RcblxuZXhwb3J0IGZ1bmN0aW9uIENvdXBvbkZvcm0oeyBhY3RpdmVDb3Vwb24sIGRpc2NvdW50UGVyY2VudCB9OiBDb3Vwb25Gb3JtUHJvcHMpIHtcbiAgY29uc3QgYXBwbHlDb3Vwb24gPSB1c2VBcHBseUNvdXBvbigpXG4gIGNvbnN0IHJlbW92ZUNvdXBvbiA9IHVzZVJlbW92ZUNvdXBvbigpXG5cbiAgY29uc3Qge1xuICAgIHJlZ2lzdGVyLFxuICAgIGhhbmRsZVN1Ym1pdCxcbiAgICBzZXRFcnJvcixcbiAgICBzZXRWYWx1ZSxcbiAgICByZXNldCxcbiAgICBmb3JtU3RhdGU6IHsgZXJyb3JzIH0sXG4gIH0gPSB1c2VGb3JtPENvdXBvbkZvcm1WYWx1ZXM+KHtcbiAgICByZXNvbHZlcjogem9kUmVzb2x2ZXIoY291cG9uU2NoZW1hKSxcbiAgICBkZWZhdWx0VmFsdWVzOiB7IGNvZGU6ICcnIH0sXG4gIH0pXG5cbiAgY29uc3Qgb25TdWJtaXQgPSAodmFsdWVzOiBDb3Vwb25Gb3JtVmFsdWVzKSA9PiB7XG4gICAgYXBwbHlDb3Vwb24ubXV0YXRlKFxuICAgICAgeyBjb2RlOiB2YWx1ZXMuY29kZSB9LFxuICAgICAge1xuICAgICAgICBvblN1Y2Nlc3M6ICgpID0+IHJlc2V0KHsgY29kZTogJycgfSksXG4gICAgICAgIG9uRXJyb3I6IChlcnJvcikgPT4ge1xuICAgICAgICAgIHNldEVycm9yKCdjb2RlJywgeyBtZXNzYWdlOiBnZXRFcnJvck1lc3NhZ2UoZXJyb3IpIH0pXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIClcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdhcC0zXCI+XG4gICAgICB7YWN0aXZlQ291cG9uID8gKFxuICAgICAgICA8ZGl2XG4gICAgICAgICAgcm9sZT1cInN0YXR1c1wiXG4gICAgICAgICAgYXJpYS1saXZlPVwicG9saXRlXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTIgcm91bmRlZC1sZyBib3JkZXIgYmctbXV0ZWQvNTAgcHgtMyBweS0yXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxUaWNrZXQgY2xhc3NOYW1lPVwic2l6ZS00IHRleHQtcHJpbWFyeVwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXhzIGZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICAgIEN1cG9tIDxzdHJvbmcgY2xhc3NOYW1lPVwiZm9udC1tb25vXCI+e2FjdGl2ZUNvdXBvbn08L3N0cm9uZz4gKHtkaXNjb3VudFBlcmNlbnR9JSBPRkYpXG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICB2YXJpYW50PVwiZ2hvc3RcIlxuICAgICAgICAgICAgc2l6ZT1cImljb24teHNcIlxuICAgICAgICAgICAgZGlzYWJsZWQ9e3JlbW92ZUNvdXBvbi5pc1BlbmRpbmd9XG4gICAgICAgICAgICBhcmlhLWxhYmVsPXtgUmVtb3ZlciBjdXBvbSAke2FjdGl2ZUNvdXBvbn1gfVxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gcmVtb3ZlQ291cG9uLm11dGF0ZSgpfVxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxYIGNsYXNzTmFtZT1cInNpemUtMy41XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICApIDogKFxuICAgICAgICA8PlxuICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXQob25TdWJtaXQpfSBub1ZhbGlkYXRlIGNsYXNzTmFtZT1cImdyaWQgZ2FwLTJcIj5cbiAgICAgICAgICAgIDxUZXh0RmllbGRcbiAgICAgICAgICAgICAgbGFiZWw9XCJDdXBvbSBkZSBkZXNjb250b1wiXG4gICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRXg6IEpVTkdMRTEwXCJcbiAgICAgICAgICAgICAgYXV0b0NvbXBsZXRlPVwib2ZmXCJcbiAgICAgICAgICAgICAgaGludD1cIkV4cGVyaW1lbnRlIEpVTkdMRTEwICgxMCUpLCBXRUIzVklQICgyMCUpIG91IEVUSDUgKDUlKS5cIlxuICAgICAgICAgICAgICBlcnJvcj17ZXJyb3JzLmNvZGU/Lm1lc3NhZ2V9XG4gICAgICAgICAgICAgIHsuLi5yZWdpc3RlcignY29kZScpfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxTdWJtaXRCdXR0b25cbiAgICAgICAgICAgICAgaXNQZW5kaW5nPXthcHBseUNvdXBvbi5pc1BlbmRpbmd9XG4gICAgICAgICAgICAgIHBlbmRpbmdUZXh0PVwiVmFsaWRhbmRvLi4uXCJcbiAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVcIlxuICAgICAgICAgICAgICBzaXplPVwic21cIlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ3LWZ1bGxcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8VGlja2V0IGNsYXNzTmFtZT1cInNpemUtMy41XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+QXBsaWNhciBjdXBvbTwvc3Bhbj5cbiAgICAgICAgICAgIDwvU3VibWl0QnV0dG9uPlxuICAgICAgICAgIDwvZm9ybT5cblxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIHJvbGU9XCJncm91cFwiXG4gICAgICAgICAgICBhcmlhLWxhYmVsPVwiQ3Vwb25zIHN1Z2VyaWRvc1wiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIgZ2FwLTEuNVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LW11dGVkLWZvcmVncm91bmRcIj5TdWdlc3TDtWVzOjwvc3Bhbj5cbiAgICAgICAgICAgIHtTVUdHRVNURURfQ09VUE9OUy5tYXAoKGNvZGUpID0+IChcbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIGtleT17Y29kZX1cbiAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZVwiXG4gICAgICAgICAgICAgICAgc2l6ZT1cInhzXCJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgUHJlZW5jaGVyIGN1cG9tICR7Y29kZX1gfVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtbW9ub1wiXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgICAgICAgc2V0VmFsdWUoJ2NvZGUnLCBjb2RlLCB7IHNob3VsZFZhbGlkYXRlOiB0cnVlIH0pXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIHtjb2RlfVxuICAgICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICAgICkpfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8Lz5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdLCJmaWxlIjoiRTovRG93bmxvYWRzL3Rlc3RlLWp1bmdsZS90ZXN0ZS1qdW5nbGUvc3JjL2NvbXBvbmVudHMvY2FydC9jb3Vwb24tZm9ybS50c3gifQ==