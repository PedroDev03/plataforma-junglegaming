import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/_authenticated/cart.tsx?tsr-split=component");const _c = __vite__cjsImport0_react_compilerRuntime["c"];const _jsxDEV = __vite__cjsImport13_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react_compilerRuntime from "/node_modules/.vite/deps/react_compiler-runtime.js?v=e9f94b2e";
import { Link } from "/node_modules/.vite/deps/@tanstack_react-router.js?v=e9f94b2e";
import { AlertCircle, ArrowLeft, RefreshCw, ShoppingBag } from "/node_modules/.vite/deps/lucide-react.js?v=e9f94b2e";
import { CartItemRow } from "/src/components/cart/cart-item-row.tsx";
import { CartSummary } from "/src/components/cart/cart-summary.tsx";
import { Alert, AlertDescription, AlertTitle } from "/src/components/ui/alert.tsx";
import { Badge } from "/src/components/ui/badge.tsx";
import { Button, buttonVariants } from "/src/components/ui/button.tsx";
import { Card, CardContent } from "/src/components/ui/card.tsx";
import { Skeleton } from "/src/components/ui/skeleton.tsx";
import { useCart } from "/src/hooks/use-cart.ts";
import { getErrorMessage } from "/src/lib/api.ts";
import { cn } from "/src/lib/utils.ts";
var _jsxFileName = "E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated/cart.tsx?tsr-split=component";
import __vite__cjsImport13_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=e9f94b2e";
var _s = $RefreshSig$();
function CartPage() {
	_s();
	const $ = _c(29);
	if ($[0] !== "cd84ba86a5805a43b299bf9ec0051b160ab05d66b5cab416d5fb50a70b72fbbd") {
		for (let $i = 0; $i < 29; $i += 1) {
			$[$i] = Symbol.for("react.memo_cache_sentinel");
		}
		$[0] = "cd84ba86a5805a43b299bf9ec0051b160ab05d66b5cab416d5fb50a70b72fbbd";
	}
	const { data: cart, isLoading, isError, error, refetch } = useCart();
	let t0;
	if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
		t0 = /* @__PURE__ */ _jsxDEV("h1", {
			className: "text-2xl font-bold tracking-tight sm:text-3xl",
			children: "Carrinho de Compras"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 31,
			columnNumber: 10
		}, this);
		$[1] = t0;
	} else {
		t0 = $[1];
	}
	let t1;
	if ($[2] !== cart) {
		t1 = cart && cart.totalItems > 0 && /* @__PURE__ */ _jsxDEV(Badge, {
			variant: "secondary",
			className: "font-mono tabular-nums",
			children: [
				cart.totalItems,
				" ",
				cart.totalItems === 1 ? "item" : "itens"
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 38,
			columnNumber: 41
		}, this);
		$[2] = cart;
		$[3] = t1;
	} else {
		t1 = $[3];
	}
	let t2;
	if ($[4] !== t1) {
		t2 = /* @__PURE__ */ _jsxDEV("div", {
			className: "flex items-center gap-3",
			children: [t0, t1]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 46,
			columnNumber: 10
		}, this);
		$[4] = t1;
		$[5] = t2;
	} else {
		t2 = $[5];
	}
	let t3;
	if ($[6] === Symbol.for("react.memo_cache_sentinel")) {
		t3 = /* @__PURE__ */ _jsxDEV(Link, {
			to: "/",
			className: cn(buttonVariants({
				variant: "ghost",
				size: "sm"
			})),
			children: [/* @__PURE__ */ _jsxDEV(ArrowLeft, {
				className: "size-4",
				"aria-hidden": "true"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 10
			}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Continuar explorando" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 61
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 54,
			columnNumber: 10
		}, this);
		$[6] = t3;
	} else {
		t3 = $[6];
	}
	let t4;
	if ($[7] !== t2) {
		t4 = /* @__PURE__ */ _jsxDEV("header", {
			className: "flex flex-wrap items-center justify-between gap-3",
			children: [t2, t3]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 10
		}, this);
		$[7] = t2;
		$[8] = t4;
	} else {
		t4 = $[8];
	}
	let t5;
	if ($[9] !== isLoading) {
		t5 = isLoading && /* @__PURE__ */ _jsxDEV("div", {
			"aria-busy": "true",
			"aria-label": "Carregando carrinho de compras",
			className: "grid gap-6 lg:grid-cols-12",
			children: [/* @__PURE__ */ _jsxDEV("div", {
				className: "grid gap-3 lg:col-span-7",
				children: [/* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-28 w-full rounded-xl" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 170
				}, this), /* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-28 w-full rounded-xl" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 217
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 128
			}, this), /* @__PURE__ */ _jsxDEV("div", {
				className: "lg:col-span-5",
				children: /* @__PURE__ */ _jsxDEV(Skeleton, { className: "h-80 w-full rounded-xl" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 301
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 270
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 72,
			columnNumber: 23
		}, this);
		$[9] = isLoading;
		$[10] = t5;
	} else {
		t5 = $[10];
	}
	let t6;
	if ($[11] !== error || $[12] !== isError || $[13] !== refetch) {
		t6 = isError && /* @__PURE__ */ _jsxDEV(Alert, {
			variant: "destructive",
			role: "alert",
			children: [
				/* @__PURE__ */ _jsxDEV(AlertCircle, {
					className: "size-4",
					"aria-hidden": "true"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 63
				}, this),
				/* @__PURE__ */ _jsxDEV(AlertTitle, { children: "Não foi possível carregar seu carrinho" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 116
				}, this),
				/* @__PURE__ */ _jsxDEV(AlertDescription, {
					className: "mt-2 flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: getErrorMessage(error) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 264
					}, this), /* @__PURE__ */ _jsxDEV(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						onClick: () => void refetch(),
						children: [/* @__PURE__ */ _jsxDEV(RefreshCw, {
							className: "size-3.5",
							"aria-hidden": "true"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 382
						}, this), /* @__PURE__ */ _jsxDEV("span", { children: "Tentar novamente" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 435
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 80,
						columnNumber: 301
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 179
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 21
		}, this);
		$[11] = error;
		$[12] = isError;
		$[13] = refetch;
		$[14] = t6;
	} else {
		t6 = $[14];
	}
	let t7;
	if ($[15] !== cart || $[16] !== isError || $[17] !== isLoading) {
		t7 = !isLoading && !isError && (!cart || cart.items.length === 0) && /* @__PURE__ */ _jsxDEV(Card, {
			className: "border-dashed",
			children: /* @__PURE__ */ _jsxDEV(CardContent, {
				className: "flex flex-col items-center justify-center gap-3 py-16 text-center",
				children: [
					/* @__PURE__ */ _jsxDEV(ShoppingBag, {
						className: "size-10 text-muted-foreground",
						"aria-hidden": "true"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 197
					}, this),
					/* @__PURE__ */ _jsxDEV("h2", {
						className: "text-lg font-semibold",
						children: "Seu carrinho está vazio"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 273
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "max-w-md text-xs text-muted-foreground sm:text-sm",
						children: "Navegue pelo catálogo para descobrir colecionáveis digitais verificados e adicioná-los ao seu carrinho."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 339
					}, this),
					/* @__PURE__ */ _jsxDEV(Link, {
						to: "/",
						className: cn(buttonVariants({
							variant: "default",
							size: "default"
						})),
						children: "Explorar catálogo de NFTs"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 511
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 90,
				columnNumber: 106
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 74
		}, this);
		$[15] = cart;
		$[16] = isError;
		$[17] = isLoading;
		$[18] = t7;
	} else {
		t7 = $[18];
	}
	let t8;
	if ($[19] !== cart || $[20] !== isError || $[21] !== isLoading) {
		t8 = !isLoading && !isError && cart && cart.items.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
			className: "grid items-start gap-6 lg:grid-cols-12",
			children: [/* @__PURE__ */ _jsxDEV("section", {
				"aria-label": "Itens do carrinho",
				className: "grid gap-3 lg:col-span-7",
				children: cart.items.map(_temp)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 103,
				columnNumber: 125
			}, this), /* @__PURE__ */ _jsxDEV("aside", {
				"aria-label": "Resumo financeiro",
				className: "lg:col-span-5",
				children: /* @__PURE__ */ _jsxDEV(CartSummary, { cart }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 103,
					columnNumber: 299
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 103,
				columnNumber: 235
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 103,
			columnNumber: 69
		}, this);
		$[19] = cart;
		$[20] = isError;
		$[21] = isLoading;
		$[22] = t8;
	} else {
		t8 = $[22];
	}
	let t9;
	if ($[23] !== t4 || $[24] !== t5 || $[25] !== t6 || $[26] !== t7 || $[27] !== t8) {
		t9 = /* @__PURE__ */ _jsxDEV("main", {
			id: "main-content",
			tabIndex: -1,
			className: "mx-auto grid w-full max-w-6xl gap-6 px-4 py-6 outline-none sm:px-6 md:py-10 lg:px-8",
			children: [
				t4,
				t5,
				t6,
				t7,
				t8
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 113,
			columnNumber: 10
		}, this);
		$[23] = t4;
		$[24] = t5;
		$[25] = t6;
		$[26] = t7;
		$[27] = t8;
		$[28] = t9;
	} else {
		t9 = $[28];
	}
	return t9;
}
_s(CartPage, "01Plqe2rGNxO3dyh81FQjY2/Nig=", false, function() {
	return [useCart];
});
_c2 = CartPage;
function _temp(item) {
	return /* @__PURE__ */ _jsxDEV(CartItemRow, { item }, item.id, false, {
		fileName: _jsxFileName,
		lineNumber: 126,
		columnNumber: 10
	}, this);
}
export { CartPage as component };
var _c2;
$RefreshReg$(_c2, "CartPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/_authenticated/cart.tsx?tsr-split=component";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated/cart.tsx?tsr-split=component", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated/cart.tsx?tsr-split=component", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "E:/Downloads/teste-jungle/teste-jungle/src/routes/_authenticated/cart.tsx?tsr-split=component" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IjtBQUFBLFNBQTBCQSxZQUFZO0FBQ3RDLFNBQVNDLGFBQWFDLFdBQVdDLFdBQVdDLG1CQUFtQjtBQUMvRCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLE9BQU9DLGtCQUFrQkMsa0JBQWtCO0FBQ3BELFNBQVNDLGFBQWE7QUFDdEIsU0FBU0MsUUFBUUMsc0JBQXNCO0FBQ3ZDLFNBQVNDLE1BQU1DLG1CQUFtQjtBQUNsQyxTQUFTQyxnQkFBZ0I7QUFDekIsU0FBMkJDLGVBQWU7QUFDMUMsU0FBU0MsdUJBQXVCO0FBQ2hDLFNBQVNDLFVBQVU7Ozs7QUFPbkIsU0FBQUMsV0FBQTs7Q0FBQSxNQUFBQyxJQUFBQyxHQUFBO0NBQUEsSUFBQUQsRUFBQTtFQUFBLFNBQUFFLEtBQUEsR0FBQUEsS0FBQSxJQUFBQSxNQUFBO0dBQUFGLEVBQUFFLE1BQUFDLE9BQUFDLElBQUE7RUFBQTtFQUFBSixFQUFBO0NBQUE7Q0FDRSxRQUFBSyxNQUFBQyxNQUFBQyxXQUFBQyxTQUFBQyxPQUFBQyxZQUEyRGQsUUFBUTtDQUFDLElBQUFlO0NBQUEsSUFBQVgsRUFBQSxPQUFBRyxPQUFBQyxJQUFBO0VBVTVETyxLQUFBO0dBQWM7YUFBZ0Q7RUFBdUI7Ozs7O0VBQUFYLEVBQUEsS0FBQVc7Q0FBQTtFQUFBQSxLQUFBWCxFQUFBO0NBQUE7Q0FBQSxJQUFBWTtDQUFBLElBQUFaLEVBQUEsT0FBQU0sTUFBQTtFQUNwRkEsYUFBUUEsS0FBSU8sYUFBYyxLQUN6Qix3QkFBQyxPQUFEO0dBQWU7R0FBc0I7YUFBckM7SUFDR1AsS0FBSU87SUFBWTtJQUFFUCxLQUFJTyxlQUFnQixJQUFwQlA7R0FEZjs7Ozs7O0VBR1BOLEVBQUEsS0FBQU07RUFBQU4sRUFBQSxLQUFBWTtDQUFBO0VBQUFBLEtBQUFaLEVBQUE7Q0FBQTtDQUFBLElBQUFjO0NBQUEsSUFBQWQsRUFBQSxPQUFBWSxJQUFBO0VBTkhFLEtBQUE7R0FBZTthQUFmLENBQ0VILElBQ0NMLEVBS0U7Ozs7OztFQUFBTixFQUFBLEtBQUFZO0VBQUFaLEVBQUEsS0FBQWM7Q0FBQTtFQUFBQSxLQUFBZCxFQUFBO0NBQUE7Q0FBQSxJQUFBZTtDQUFBLElBQUFmLEVBQUEsT0FBQUcsT0FBQUMsSUFBQTtFQUVMVyxLQUFBLHdCQUFDLE1BQUQ7R0FBUztHQUFlakIsY0FBR04sZUFBZTtJQUFBd0IsU0FBVztJQUFPQyxNQUFRO0dBQUssQ0FBQyxDQUFDO2FBQTNFLENBQ0Usd0JBQUMsV0FBRDtJQUFxQjtJQUFxQjtHQUFNOzs7O2FBQ2hELDRDQUFNLHVCQUEwQjs7OztXQUY3Qjs7Ozs7O0VBR0NqQixFQUFBLEtBQUFlO0NBQUE7RUFBQUEsS0FBQWYsRUFBQTtDQUFBO0NBQUEsSUFBQWtCO0NBQUEsSUFBQWxCLEVBQUEsT0FBQWMsSUFBQTtFQWJSSSxLQUFBO0dBQWtCO2FBQWxCLENBQ0VKLElBU0FDLEVBSU07Ozs7OztFQUFBZixFQUFBLEtBQUFjO0VBQUFkLEVBQUEsS0FBQWtCO0NBQUE7RUFBQUEsS0FBQWxCLEVBQUE7Q0FBQTtDQUFBLElBQUFtQjtDQUFBLElBQUFuQixFQUFBLE9BQUFPLFdBQUE7RUFFUEEsa0JBQ0M7R0FDWTtHQUNDO0dBQ0Q7YUFIWixDQUtFO0lBQWU7Y0FBZixDQUNFLHdCQUFDLFVBQUQsRUFBb0Isb0NBQXdCOzs7O2NBQzVDLHdCQUFDLFVBQUQsRUFBb0Isb0NBQXdCOzs7O1lBQ3pDOzs7OzthQUNMO0lBQWU7Y0FDYix3QkFBQyxVQUFELEVBQW9CLG9DQUF3Qjs7Ozs7R0FDekM7Ozs7V0FFUjs7Ozs7O0VBQUFQLEVBQUEsS0FBQU87RUFBQVAsRUFBQSxNQUFBbUI7Q0FBQTtFQUFBQSxLQUFBbkIsRUFBQTtDQUFBO0NBQUEsSUFBQW9CO0NBQUEsSUFBQXBCLEVBQUEsUUFBQVMsU0FBQVQsRUFBQSxRQUFBUSxXQUFBUixFQUFBLFFBQUFVLFNBQUE7RUFFQUYsZ0JBQ0Msd0JBQUMsT0FBRDtHQUFlO0dBQW1CO2FBQWxDO0lBQ0Usd0JBQUMsYUFBRDtLQUF1QjtLQUFxQjtJQUFNOzs7OztJQUNsRCx3QkFBQyxZQUFELFlBQVkseUNBQUQ7Ozs7O0lBQ1gsd0JBQUMsa0JBQUQ7S0FBNEI7ZUFBNUIsQ0FDRSw0Q0FBT1gsZ0JBQWdCWSxLQUFLLEVBQVE7Ozs7ZUFDcEMsd0JBQUMsUUFBRDtNQUFhO01BQWlCO01BQWU7TUFBYyxlQUFNLEtBQUtDLFFBQVE7Z0JBQTlFLENBQ0Usd0JBQUMsV0FBRDtPQUFxQjtPQUF1QjtNQUFNOzs7O2dCQUNsRCw0Q0FBTSxtQkFBc0I7Ozs7Y0FGdkI7Ozs7O2FBRlE7Ozs7OztHQUhiOzs7Ozs7RUFXUFYsRUFBQSxNQUFBUztFQUFBVCxFQUFBLE1BQUFRO0VBQUFSLEVBQUEsTUFBQVU7RUFBQVYsRUFBQSxNQUFBb0I7Q0FBQTtFQUFBQSxLQUFBcEIsRUFBQTtDQUFBO0NBQUEsSUFBQXFCO0NBQUEsSUFBQXJCLEVBQUEsUUFBQU0sUUFBQU4sRUFBQSxRQUFBUSxXQUFBUixFQUFBLFFBQUFPLFdBQUE7RUFFQWMsS0FBQSxDQUFDZCxhQUFELENBQWVDLFlBQVksQ0FBQ0YsUUFBUUEsS0FBSWdCLE1BQU1DLFdBQVksTUFDekQsd0JBQUMsTUFBRDtHQUFnQjthQUNkLHdCQUFDLGFBQUQ7SUFBdUI7Y0FBdkI7S0FDRSx3QkFBQyxhQUFEO01BQXVCO01BQTRDO0tBQU07Ozs7O0tBQ3pFO01BQWM7Z0JBQXdCO0tBQTJCOzs7OztLQUNqRTtNQUFhO2dCQUFtRDtLQUc3RDs7Ozs7S0FDSCx3QkFBQyxNQUFEO01BQVM7TUFBZXpCLGNBQUdOLGVBQWU7T0FBQXdCLFNBQVc7T0FBU0MsTUFBUTtNQUFVLENBQUMsQ0FBQztnQkFBRTtLQUEvRTs7Ozs7SUFQSzs7Ozs7O0VBRFQ7Ozs7O0VBYU5qQixFQUFBLE1BQUFNO0VBQUFOLEVBQUEsTUFBQVE7RUFBQVIsRUFBQSxNQUFBTztFQUFBUCxFQUFBLE1BQUFxQjtDQUFBO0VBQUFBLEtBQUFyQixFQUFBO0NBQUE7Q0FBQSxJQUFBd0I7Q0FBQSxJQUFBeEIsRUFBQSxRQUFBTSxRQUFBTixFQUFBLFFBQUFRLFdBQUFSLEVBQUEsUUFBQU8sV0FBQTtFQUVBaUIsS0FBQSxDQUFDakIsYUFBRCxDQUFlQyxXQUFmRixRQUFrQ0EsS0FBSWdCLE1BQU1DLFNBQVUsS0FDckQ7R0FBZTthQUFmLENBQ0U7SUFBb0I7SUFBOEI7Y0FDL0NqQixLQUFJZ0IsTUFBTUcsSUFBTUMsS0FFaEI7R0FDTTs7OzthQUVUO0lBQWtCO0lBQThCO2NBQzlDLHdCQUFDLGFBQUQsRUFBbUJwQixLQUFJOzs7OztHQUNsQjs7OztXQUVWOzs7Ozs7RUFBQU4sRUFBQSxNQUFBTTtFQUFBTixFQUFBLE1BQUFRO0VBQUFSLEVBQUEsTUFBQU87RUFBQVAsRUFBQSxNQUFBd0I7Q0FBQTtFQUFBQSxLQUFBeEIsRUFBQTtDQUFBO0NBQUEsSUFBQTJCO0NBQUEsSUFBQTNCLEVBQUEsUUFBQWtCLE1BQUFsQixFQUFBLFFBQUFtQixNQUFBbkIsRUFBQSxRQUFBb0IsTUFBQXBCLEVBQUEsUUFBQXFCLE1BQUFyQixFQUFBLFFBQUF3QixJQUFBO0VBL0VIRyxLQUFBO0dBQ0s7R0FDTztHQUNBO2FBSFo7SUFLRVQ7SUFnQkNYO0lBZ0JBQztJQWNBYTtJQWdCQUc7R0FhSTs7Ozs7O0VBQUF4QixFQUFBLE1BQUFrQjtFQUFBbEIsRUFBQSxNQUFBbUI7RUFBQW5CLEVBQUEsTUFBQW9CO0VBQUFwQixFQUFBLE1BQUFxQjtFQUFBckIsRUFBQSxNQUFBd0I7RUFBQXhCLEVBQUEsTUFBQTJCO0NBQUE7RUFBQUEsS0FBQTNCLEVBQUE7Q0FBQTtDQUFBLE9BaEZQMkI7QUFnRk87Ozs7O0FBcEZYLFNBQUFDLE1BQUFGLE1BQUE7Q0FBQSxPQTJFYyx3QkFBQyxhQUFELEVBQWlDQSxLQUFJLEdBQW5CQSxLQUFJRzs7OztRQUFlO0FBQ3RDO0FBVVosU0FBQTlCLFlBQUErQiIsIm5hbWVzIjpbIkxpbmsiLCJBbGVydENpcmNsZSIsIkFycm93TGVmdCIsIlJlZnJlc2hDdyIsIlNob3BwaW5nQmFnIiwiQ2FydEl0ZW1Sb3ciLCJDYXJ0U3VtbWFyeSIsIkFsZXJ0IiwiQWxlcnREZXNjcmlwdGlvbiIsIkFsZXJ0VGl0bGUiLCJCYWRnZSIsIkJ1dHRvbiIsImJ1dHRvblZhcmlhbnRzIiwiQ2FyZCIsIkNhcmRDb250ZW50IiwiU2tlbGV0b24iLCJ1c2VDYXJ0IiwiZ2V0RXJyb3JNZXNzYWdlIiwiY24iLCJDYXJ0UGFnZSIsIiQiLCJfYyIsIiRpIiwiU3ltYm9sIiwiZm9yIiwiZGF0YSIsImNhcnQiLCJpc0xvYWRpbmciLCJpc0Vycm9yIiwiZXJyb3IiLCJyZWZldGNoIiwidDAiLCJ0MSIsInRvdGFsSXRlbXMiLCJ0MiIsInQzIiwidmFyaWFudCIsInNpemUiLCJ0NCIsInQ1IiwidDYiLCJ0NyIsIml0ZW1zIiwibGVuZ3RoIiwidDgiLCJtYXAiLCJpdGVtIiwidDkiLCJfdGVtcCIsImlkIiwiY29tcG9uZW50Il0sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VzIjpbImNhcnQudHN4P3Rzci1zcGxpdD1jb21wb25lbnQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgY3JlYXRlRmlsZVJvdXRlLCBMaW5rIH0gZnJvbSAnQHRhbnN0YWNrL3JlYWN0LXJvdXRlcidcbmltcG9ydCB7IEFsZXJ0Q2lyY2xlLCBBcnJvd0xlZnQsIFJlZnJlc2hDdywgU2hvcHBpbmdCYWcgfSBmcm9tICdsdWNpZGUtcmVhY3QnXG5pbXBvcnQgeyBDYXJ0SXRlbVJvdyB9IGZyb20gJ0AvY29tcG9uZW50cy9jYXJ0L2NhcnQtaXRlbS1yb3cnXG5pbXBvcnQgeyBDYXJ0U3VtbWFyeSB9IGZyb20gJ0AvY29tcG9uZW50cy9jYXJ0L2NhcnQtc3VtbWFyeSdcbmltcG9ydCB7IEFsZXJ0LCBBbGVydERlc2NyaXB0aW9uLCBBbGVydFRpdGxlIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2FsZXJ0J1xuaW1wb3J0IHsgQmFkZ2UgfSBmcm9tICdAL2NvbXBvbmVudHMvdWkvYmFkZ2UnXG5pbXBvcnQgeyBCdXR0b24sIGJ1dHRvblZhcmlhbnRzIH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2J1dHRvbidcbmltcG9ydCB7IENhcmQsIENhcmRDb250ZW50IH0gZnJvbSAnQC9jb21wb25lbnRzL3VpL2NhcmQnXG5pbXBvcnQgeyBTa2VsZXRvbiB9IGZyb20gJ0AvY29tcG9uZW50cy91aS9za2VsZXRvbidcbmltcG9ydCB7IGNhcnRRdWVyeU9wdGlvbnMsIHVzZUNhcnQgfSBmcm9tICdAL2hvb2tzL3VzZS1jYXJ0J1xuaW1wb3J0IHsgZ2V0RXJyb3JNZXNzYWdlIH0gZnJvbSAnQC9saWIvYXBpJ1xuaW1wb3J0IHsgY24gfSBmcm9tICdAL2xpYi91dGlscydcblxuZXhwb3J0IGNvbnN0IFJvdXRlID0gY3JlYXRlRmlsZVJvdXRlKCcvX2F1dGhlbnRpY2F0ZWQvY2FydCcpKHtcbiAgbG9hZGVyOiAoeyBjb250ZXh0IH0pID0+IGNvbnRleHQucXVlcnlDbGllbnQucHJlZmV0Y2hRdWVyeShjYXJ0UXVlcnlPcHRpb25zKSxcbiAgY29tcG9uZW50OiBDYXJ0UGFnZSxcbn0pXG5cbmZ1bmN0aW9uIENhcnRQYWdlKCkge1xuICBjb25zdCB7IGRhdGE6IGNhcnQsIGlzTG9hZGluZywgaXNFcnJvciwgZXJyb3IsIHJlZmV0Y2ggfSA9IHVzZUNhcnQoKVxuXG4gIHJldHVybiAoXG4gICAgPG1haW5cbiAgICAgIGlkPVwibWFpbi1jb250ZW50XCJcbiAgICAgIHRhYkluZGV4PXstMX1cbiAgICAgIGNsYXNzTmFtZT1cIm14LWF1dG8gZ3JpZCB3LWZ1bGwgbWF4LXctNnhsIGdhcC02IHB4LTQgcHktNiBvdXRsaW5lLW5vbmUgc206cHgtNiBtZDpweS0xMCBsZzpweC04XCJcbiAgICA+XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtM1wiPlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LTJ4bCBmb250LWJvbGQgdHJhY2tpbmctdGlnaHQgc206dGV4dC0zeGxcIj5DYXJyaW5obyBkZSBDb21wcmFzPC9oMT5cbiAgICAgICAgICB7Y2FydCAmJiBjYXJ0LnRvdGFsSXRlbXMgPiAwICYmIChcbiAgICAgICAgICAgIDxCYWRnZSB2YXJpYW50PVwic2Vjb25kYXJ5XCIgY2xhc3NOYW1lPVwiZm9udC1tb25vIHRhYnVsYXItbnVtc1wiPlxuICAgICAgICAgICAgICB7Y2FydC50b3RhbEl0ZW1zfSB7Y2FydC50b3RhbEl0ZW1zID09PSAxID8gJ2l0ZW0nIDogJ2l0ZW5zJ31cbiAgICAgICAgICAgIDwvQmFkZ2U+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPExpbmsgdG89XCIvXCIgY2xhc3NOYW1lPXtjbihidXR0b25WYXJpYW50cyh7IHZhcmlhbnQ6ICdnaG9zdCcsIHNpemU6ICdzbScgfSkpfT5cbiAgICAgICAgICA8QXJyb3dMZWZ0IGNsYXNzTmFtZT1cInNpemUtNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgPHNwYW4+Q29udGludWFyIGV4cGxvcmFuZG88L3NwYW4+XG4gICAgICAgIDwvTGluaz5cbiAgICAgIDwvaGVhZGVyPlxuXG4gICAgICB7aXNMb2FkaW5nICYmIChcbiAgICAgICAgPGRpdlxuICAgICAgICAgIGFyaWEtYnVzeT1cInRydWVcIlxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJDYXJyZWdhbmRvIGNhcnJpbmhvIGRlIGNvbXByYXNcIlxuICAgICAgICAgIGNsYXNzTmFtZT1cImdyaWQgZ2FwLTYgbGc6Z3JpZC1jb2xzLTEyXCJcbiAgICAgICAgPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBnYXAtMyBsZzpjb2wtc3Bhbi03XCI+XG4gICAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC0yOCB3LWZ1bGwgcm91bmRlZC14bFwiIC8+XG4gICAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC0yOCB3LWZ1bGwgcm91bmRlZC14bFwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsZzpjb2wtc3Bhbi01XCI+XG4gICAgICAgICAgICA8U2tlbGV0b24gY2xhc3NOYW1lPVwiaC04MCB3LWZ1bGwgcm91bmRlZC14bFwiIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cblxuICAgICAge2lzRXJyb3IgJiYgKFxuICAgICAgICA8QWxlcnQgdmFyaWFudD1cImRlc3RydWN0aXZlXCIgcm9sZT1cImFsZXJ0XCI+XG4gICAgICAgICAgPEFsZXJ0Q2lyY2xlIGNsYXNzTmFtZT1cInNpemUtNFwiIGFyaWEtaGlkZGVuPVwidHJ1ZVwiIC8+XG4gICAgICAgICAgPEFsZXJ0VGl0bGU+TsOjbyBmb2kgcG9zc8OtdmVsIGNhcnJlZ2FyIHNldSBjYXJyaW5obzwvQWxlcnRUaXRsZT5cbiAgICAgICAgICA8QWxlcnREZXNjcmlwdGlvbiBjbGFzc05hbWU9XCJtdC0yIGZsZXggZmxleC13cmFwIGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTNcIj5cbiAgICAgICAgICAgIDxzcGFuPntnZXRFcnJvck1lc3NhZ2UoZXJyb3IpfTwvc3Bhbj5cbiAgICAgICAgICAgIDxCdXR0b24gdHlwZT1cImJ1dHRvblwiIHZhcmlhbnQ9XCJvdXRsaW5lXCIgc2l6ZT1cInNtXCIgb25DbGljaz17KCkgPT4gdm9pZCByZWZldGNoKCl9PlxuICAgICAgICAgICAgICA8UmVmcmVzaEN3IGNsYXNzTmFtZT1cInNpemUtMy41XCIgYXJpYS1oaWRkZW49XCJ0cnVlXCIgLz5cbiAgICAgICAgICAgICAgPHNwYW4+VGVudGFyIG5vdmFtZW50ZTwvc3Bhbj5cbiAgICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICAgIDwvQWxlcnREZXNjcmlwdGlvbj5cbiAgICAgICAgPC9BbGVydD5cbiAgICAgICl9XG5cbiAgICAgIHshaXNMb2FkaW5nICYmICFpc0Vycm9yICYmICghY2FydCB8fCBjYXJ0Lml0ZW1zLmxlbmd0aCA9PT0gMCkgJiYgKFxuICAgICAgICA8Q2FyZCBjbGFzc05hbWU9XCJib3JkZXItZGFzaGVkXCI+XG4gICAgICAgICAgPENhcmRDb250ZW50IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGdhcC0zIHB5LTE2IHRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICA8U2hvcHBpbmdCYWcgY2xhc3NOYW1lPVwic2l6ZS0xMCB0ZXh0LW11dGVkLWZvcmVncm91bmRcIiBhcmlhLWhpZGRlbj1cInRydWVcIiAvPlxuICAgICAgICAgICAgPGgyIGNsYXNzTmFtZT1cInRleHQtbGcgZm9udC1zZW1pYm9sZFwiPlNldSBjYXJyaW5obyBlc3TDoSB2YXppbzwvaDI+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtYXgtdy1tZCB0ZXh0LXhzIHRleHQtbXV0ZWQtZm9yZWdyb3VuZCBzbTp0ZXh0LXNtXCI+XG4gICAgICAgICAgICAgIE5hdmVndWUgcGVsbyBjYXTDoWxvZ28gcGFyYSBkZXNjb2JyaXIgY29sZWNpb27DoXZlaXMgZGlnaXRhaXMgdmVyaWZpY2Fkb3MgZSBhZGljaW9uw6EtbG9zXG4gICAgICAgICAgICAgIGFvIHNldSBjYXJyaW5oby5cbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgIDxMaW5rIHRvPVwiL1wiIGNsYXNzTmFtZT17Y24oYnV0dG9uVmFyaWFudHMoeyB2YXJpYW50OiAnZGVmYXVsdCcsIHNpemU6ICdkZWZhdWx0JyB9KSl9PlxuICAgICAgICAgICAgICBFeHBsb3JhciBjYXTDoWxvZ28gZGUgTkZUc1xuICAgICAgICAgICAgPC9MaW5rPlxuICAgICAgICAgIDwvQ2FyZENvbnRlbnQ+XG4gICAgICAgIDwvQ2FyZD5cbiAgICAgICl9XG5cbiAgICAgIHshaXNMb2FkaW5nICYmICFpc0Vycm9yICYmIGNhcnQgJiYgY2FydC5pdGVtcy5sZW5ndGggPiAwICYmIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGl0ZW1zLXN0YXJ0IGdhcC02IGxnOmdyaWQtY29scy0xMlwiPlxuICAgICAgICAgIDxzZWN0aW9uIGFyaWEtbGFiZWw9XCJJdGVucyBkbyBjYXJyaW5ob1wiIGNsYXNzTmFtZT1cImdyaWQgZ2FwLTMgbGc6Y29sLXNwYW4tN1wiPlxuICAgICAgICAgICAge2NhcnQuaXRlbXMubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgICAgIDxDYXJ0SXRlbVJvdyBrZXk9e2l0ZW0uaWR9IGl0ZW09e2l0ZW19IC8+XG4gICAgICAgICAgICApKX1cbiAgICAgICAgICA8L3NlY3Rpb24+XG5cbiAgICAgICAgICA8YXNpZGUgYXJpYS1sYWJlbD1cIlJlc3VtbyBmaW5hbmNlaXJvXCIgY2xhc3NOYW1lPVwibGc6Y29sLXNwYW4tNVwiPlxuICAgICAgICAgICAgPENhcnRTdW1tYXJ5IGNhcnQ9e2NhcnR9IC8+XG4gICAgICAgICAgPC9hc2lkZT5cbiAgICAgICAgPC9kaXY+XG4gICAgICApfVxuICAgIDwvbWFpbj5cbiAgKVxufVxuIl0sImZpbGUiOiJFOi9Eb3dubG9hZHMvdGVzdGUtanVuZ2xlL3Rlc3RlLWp1bmdsZS9zcmMvcm91dGVzL19hdXRoZW50aWNhdGVkL2NhcnQudHN4In0=